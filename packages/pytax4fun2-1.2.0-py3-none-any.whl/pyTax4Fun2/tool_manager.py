"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Tool discovery and management for pyTax4Fun2.
Fully cross-platform: works on Linux, macOS, and Windows.
"""

import os
import sys
import shutil
import platform
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Any, Union
import warnings


class ToolManager:
    """Manages discovery and verification of external tools across all platforms."""
    
    # Tool definitions with platform-specific executable names
    TOOLS = {
        "blastn": {
            "executables": {
                "windows": ["blastn.exe", "blastn"],
                "linux": ["blastn"],
                "darwin": ["blastn"],  # macOS
            },
            "conda_package": "blast",
            "description": "BLAST+ nucleotide search",
            "version_flags": ["-version"],
        },
        "makeblastdb": {
            "executables": {
                "windows": ["makeblastdb.exe", "makeblastdb"],
                "linux": ["makeblastdb"],
                "darwin": ["makeblastdb"],
            },
            "conda_package": "blast",
            "description": "BLAST database creation",
            "version_flags": ["-version"],
        },
        "diamond": {
            "executables": {
                "windows": ["diamond.exe", "diamond"],
                "linux": ["diamond", "diamond.linux"],
                "darwin": ["diamond", "diamond.macos", "diamond.darwin"],
            },
            "conda_package": "diamond",
            "description": "DIAMOND protein aligner",
            "version_flags": ["--version"],
        },
        "prodigal": {
            "executables": {
                "windows": ["prodigal.exe", "prodigal"],
                "linux": ["prodigal", "prodigal.linux"],
                "darwin": ["prodigal", "prodigal.macos", "prodigal.darwin"],
            },
            "conda_package": "prodigal",
            "description": "Prodigal gene predictor",
            "version_flags": ["-v"],
        },
        "vsearch": {
            "executables": {
                "windows": ["vsearch.exe", "vsearch"],
                "linux": ["vsearch", "vsearch.linux"],
                "darwin": ["vsearch", "vsearch.macos", "vsearch.darwin"],
            },
            "conda_package": "vsearch",
            "description": "VSEARCH clustering tool",
            "version_flags": ["--version"],
        },
    }
    
    # Common installation paths for different platforms
    COMMON_PATHS = {
        "windows": [
            Path("C:/Program Files"),
            Path("C:/Program Files (x86)"),
            Path.home() / "AppData/Local/Programs",
            Path.home() / "AppData/Local",
            Path.home() / "bin",
        ],
        "linux": [
            Path("/usr/local/bin"),
            Path("/usr/bin"),
            Path("/bin"),
            Path.home() / "bin",
            Path.home() / ".local/bin",
            Path.home() / "miniconda3/bin",
            Path.home() / "anaconda3/bin",
            Path.home() / "mambaforge/bin",
        ],
        "darwin": [  # macOS
            Path("/usr/local/bin"),
            Path("/usr/bin"),
            Path("/bin"),
            Path("/opt/homebrew/bin"),  # Apple Silicon Homebrew
            Path("/opt/local/bin"),      # MacPorts
            Path.home() / "bin",
            Path.home() / ".local/bin",
            Path.home() / "miniconda3/bin",
            Path.home() / "anaconda3/bin",
            Path.home() / "mambaforge/bin",
        ],
    }
    
    def __init__(self, reference_data_path: Optional[Union[str, Path]] = None):
        """
        Initialize tool manager.
        
        Args:
            reference_data_path: Path to pyTax4Fun2_ReferenceData directory
        """
        self.reference_data_path = Path(reference_data_path) if reference_data_path else None
        self.system = platform.system().lower()
        self._tool_cache = {}
        self._path_extensions = self._get_path_extensions()
        
        # Validate system support
        if self.system not in self.TOOLS["blastn"]["executables"]:
            supported = list(self.TOOLS["blastn"]["executables"].keys())
            raise RuntimeError(
                f"Unsupported operating system: {self.system}. "
                f"Supported: {', '.join(supported)}"
            )
    
    def _get_path_extensions(self) -> List[str]:
        """Get platform-specific PATH extensions."""
        if self.system == "windows":
            return [".exe", ".bat", ".cmd", ".ps1", ""]
        else:
            return [""]  # Linux/macOS don't rely on extensions
    
    def _check_file_executable(self, file_path: Path) -> bool:
        """
        Check if a file exists and is executable.
        Cross-platform compatible.
        """
        if not file_path.exists():
            return False
        
        # On Windows, any file can be "executable" if it has the right extension
        if self.system == "windows":
            return file_path.suffix.lower() in [".exe", ".bat", ".cmd", ".ps1"] or os.access(file_path, os.X_OK)
        else:
            # On Unix-like systems, check executable permission
            return os.access(file_path, os.X_OK)
    
    def _get_tool_executables(self, tool_name: str) -> List[str]:
        """Get platform-specific executable names for a tool."""
        if tool_name not in self.TOOLS:
            return []
        
        return self.TOOLS[tool_name]["executables"].get(self.system, [])
    
    def find_tool(self, tool_name: str) -> Optional[Path]:
        """
        Find a tool executable in multiple locations:
        1. System PATH (conda environment)
        2. Reference data TOOLS directory
        3. Common installation locations
        4. Current working directory
        
        Args:
            tool_name: Name of tool (blastn, diamond, prodigal, etc.)
            
        Returns:
            Path to tool executable or None if not found
        """
        if tool_name not in self.TOOLS:
            raise ValueError(f"Unknown tool: {tool_name}")
        
        # Check cache first
        if tool_name in self._tool_cache:
            return self._tool_cache[tool_name]
        
        executables = self._get_tool_executables(tool_name)
        if not executables:
            self._tool_cache[tool_name] = None
            return None
        
        found_path = None
        
        # Priority 1: System PATH (conda environment)
        found_path = self._check_system_path(executables)
        if found_path:
            self._tool_cache[tool_name] = found_path
            return found_path
        
        # Priority 2: Reference data TOOLS directory
        if self.reference_data_path:
            found_path = self._check_tools_directory(tool_name, executables)
            if found_path:
                self._tool_cache[tool_name] = found_path
                return found_path
        
        # Priority 3: Common installation locations
        found_path = self._check_common_locations(executables)
        if found_path:
            self._tool_cache[tool_name] = found_path
            return found_path
        
        # Priority 4: Current working directory
        found_path = self._check_current_directory(executables)
        if found_path:
            self._tool_cache[tool_name] = found_path
            return found_path
        
        # Tool not found
        self._tool_cache[tool_name] = None
        return None
    
    def _check_system_path(self, executables: List[str]) -> Optional[Path]:
        """Check if tool exists in system PATH (works on all platforms)."""
        for exe_name in executables:
            # shutil.which works on all platforms
            path = shutil.which(exe_name)
            if path:
                return Path(path)
            
            # On Windows, also try without extension if it has one
            if self.system == "windows" and '.' in exe_name:
                base_name = exe_name.split('.')[0]
                path = shutil.which(base_name)
                if path:
                    return Path(path)
        
        return None
    
    def _check_tools_directory(self, tool_name: str, executables: List[str]) -> Optional[Path]:
        """Check reference data TOOLS directory for tool."""
        if not self.reference_data_path:
            return None
        
        tools_dir = self.reference_data_path / "TOOLS"
        if not tools_dir.exists():
            return None
        
        # Look in version-specific directories
        pattern = f"*{tool_name}*"
        for tool_dir in tools_dir.glob(pattern):
            if not tool_dir.is_dir():
                continue
            
            # Check in main directory
            for exe_name in executables:
                tool_path = tool_dir / exe_name
                if self._check_file_executable(tool_path):
                    return tool_path
                
                # Check in bin subdirectory
                bin_path = tool_dir / "bin" / exe_name
                if self._check_file_executable(bin_path):
                    return bin_path
                
                # On Windows, also check for .exe in bin
                if self.system == "windows" and not exe_name.endswith('.exe'):
                    exe_with_ext = f"{exe_name}.exe"
                    bin_path_exe = tool_dir / "bin" / exe_with_ext
                    if self._check_file_executable(bin_path_exe):
                        return bin_path_exe
        
        return None
    
    def _check_common_locations(self, executables: List[str]) -> Optional[Path]:
        """Check common installation locations for the platform."""
        common_paths = self.COMMON_PATHS.get(self.system, [])
        
        # Add conda environment path if in conda
        if "CONDA_PREFIX" in os.environ:
            conda_bin = Path(os.environ["CONDA_PREFIX"]) / "bin"
            if conda_bin not in common_paths:
                common_paths.append(conda_bin)
        
        # On Windows, also check Program Files
        if self.system == "windows":
            program_files = os.environ.get("ProgramFiles", "C:/Program Files")
            program_files_x86 = os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)")
            common_paths.extend([
                Path(program_files),
                Path(program_files_x86),
            ])
        
        for base_path in common_paths:
            if not base_path.exists():
                continue
            
            for exe_name in executables:
                # Check directly in base path
                tool_path = base_path / exe_name
                if self._check_file_executable(tool_path):
                    return tool_path
                
                # Check in subdirectories (for Windows Program Files)
                if self.system == "windows":
                    for subdir in base_path.iterdir():
                        if subdir.is_dir():
                            subdir_tool = subdir / exe_name
                            if self._check_file_executable(subdir_tool):
                                return subdir_tool
                            
                            # Check bin subdirectory
                            bin_tool = subdir / "bin" / exe_name
                            if self._check_file_executable(bin_tool):
                                return bin_tool
        
        return None
    
    def _check_current_directory(self, executables: List[str]) -> Optional[Path]:
        """Check current working directory for tool."""
        cwd = Path.cwd()
        
        for exe_name in executables:
            tool_path = cwd / exe_name
            if self._check_file_executable(tool_path):
                return tool_path
            
            # On Windows, also try with .exe
            if self.system == "windows" and not exe_name.endswith('.exe'):
                tool_path_exe = cwd / f"{exe_name}.exe"
                if self._check_file_executable(tool_path_exe):
                    return tool_path_exe
        
        return None

    def verify_tool(self, tool_name: str) -> Dict[str, Any]:
        """
        Verify that a tool works by running its version command.
        Cross-platform compatible.
        
        Returns:
            Dict with verification results
        """
        tool_path = self.find_tool(tool_name)
        if not tool_path:
            return {
                "found": False,
                "working": False,
                "path": None,
                "version": None,
                "error": f"{tool_name} not found"
            }
        
        # Get version flags for this tool
        version_flags = self.TOOLS[tool_name].get("version_flags", ["--version"])
        
        try:
            # Try each version flag
            for flags in version_flags:
                try:
                    cmd = [str(tool_path)]
                    if isinstance(flags, str):
                        cmd.append(flags)
                    else:
                        cmd.extend(flags)
                    
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=5,
                        shell=False
                    )
                    
                    # Check both stdout and stderr
                    stdout = result.stdout or ""
                    stderr = result.stderr or ""
                    
                    # Combine outputs
                    version_output = stdout + "\n" + stderr
                    
                    if version_output.strip():
                        # Parse version based on tool
                        if tool_name == "vsearch":
                            # vsearch specific parsing
                            lines = version_output.strip().split('\n')
                            version = "unknown"
                            
                            # First pass: look for line with "vsearch v"
                            for line in lines:
                                line = line.strip()
                                if "vsearch v" in line.lower():
                                    # Extract before first comma
                                    if ',' in line:
                                        version = line.split(',')[0].strip()
                                    else:
                                        version = line
                                    break
                            
                            # Second pass: look for line with version-like pattern
                            if version == "unknown":
                                for line in lines:
                                    line = line.strip()
                                    # Check if line has version pattern (starts with vsearch and has numbers)
                                    if line.lower().startswith("vsearch") and any(c.isdigit() for c in line):
                                        if ',' in line:
                                            version = line.split(',')[0].strip()
                                        else:
                                            version = line
                                        break
                            
                            # Third pass: look for line without citation markers
                            if version == "unknown":
                                for line in lines:
                                    line = line.strip()
                                    if (line and 
                                        "Rognes" not in line and 
                                        "PeerJ" not in line and 
                                        "doi.org" not in line and
                                        "https://" not in line and
                                        "zlib" not in line and
                                        "Compiled" not in line):
                                        if ',' in line:
                                            version = line.split(',')[0].strip()
                                        else:
                                            version = line
                                        break
                            
                            # Last resort: first non-empty line
                            if version == "unknown":
                                for line in lines:
                                    if line.strip():
                                        version = line.strip()
                                        break
                        
                        elif tool_name == "blastn" or tool_name == "makeblastdb":
                            # BLAST tools output "toolname: version"
                            lines = version_output.strip().split('\n')
                            version = lines[0].strip() if lines else "unknown"
                        
                        elif tool_name == "diamond":
                            # DIAMOND outputs "diamond version X.Y.Z"
                            lines = version_output.strip().split('\n')
                            version = lines[0].strip() if lines else "unknown"
                        
                        elif tool_name == "prodigal":
                            # Prodigal outputs "Prodigal VX.Y.Z: Month, Year"
                            lines = version_output.strip().split('\n')
                            version = lines[0].strip() if lines else "unknown"
                        
                        else:
                            # Default: take first non-empty line
                            lines = [l for l in version_output.strip().split('\n') if l.strip()]
                            version = lines[0] if lines else "unknown"
                        
                        return {
                            "found": True,
                            "working": True,
                            "path": tool_path,
                            "version": version,
                            "error": None
                        }
                        
                except (subprocess.SubprocessError, FileNotFoundError) as e:
                    continue
            
            # If all flag attempts failed, try running without arguments
            try:
                result = subprocess.run(
                    [str(tool_path)],
                    capture_output=True,
                    text=True,
                    timeout=2,
                    shell=False
                )
                return {
                    "found": True,
                    "working": True,
                    "path": tool_path,
                    "version": "unknown (runs but version unknown)",
                    "error": None
                }
            except Exception:
                pass
            
            return {
                "found": True,
                "working": False,
                "path": tool_path,
                "version": None,
                "error": "Tool found but failed to execute"
            }
            
        except Exception as e:
            return {
                "found": True,
                "working": False,
                "path": tool_path,
                "version": None,
                "error": str(e)
            }
        
    def get_all_tools_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all required tools."""
        status = {}
        for tool_name in self.TOOLS:
            status[tool_name] = self.verify_tool(tool_name)
        return status
    
    def suggest_installation(self, missing_tools: List[str]) -> str:
        """Suggest installation commands for missing tools based on platform."""
        suggestions = []
        
        # Platform-specific package managers
        if self.system == "linux":
            suggestions.append("\nLinux installation options:")
            suggestions.append("  # Using conda (recommended):")
            for tool in missing_tools:
                tool_info = self.TOOLS[tool]
                conda_pkg = tool_info["conda_package"]
                suggestions.append(f"  conda install -c bioconda {conda_pkg}")
            
            suggestions.append("\n  # Using apt (Ubuntu/Debian):")
            apt_packages = {
                "blastn": "ncbi-blast+",
                "makeblastdb": "ncbi-blast+",
                "diamond": "diamond-aligner",
                "prodigal": "prodigal",
                "vsearch": "vsearch",
            }
            apt_cmds = []
            for tool in missing_tools:
                if tool in apt_packages:
                    apt_cmds.append(apt_packages[tool])
            if apt_cmds:
                suggestions.append(f"  sudo apt install {' '.join(set(apt_cmds))}")
        
        elif self.system == "darwin":  # macOS
            suggestions.append("\nmacOS installation options:")
            suggestions.append("  # Using conda (recommended):")
            for tool in missing_tools:
                tool_info = self.TOOLS[tool]
                conda_pkg = tool_info["conda_package"]
                suggestions.append(f"  conda install -c bioconda {conda_pkg}")
            
            suggestions.append("\n  # Using Homebrew:")
            brew_packages = {
                "blastn": "blast",
                "makeblastdb": "blast",
                "diamond": "diamond",
                "prodigal": "prodigal",
                "vsearch": "vsearch",
            }
            brew_cmds = []
            for tool in missing_tools:
                if tool in brew_packages:
                    brew_cmds.append(brew_packages[tool])
            if brew_cmds:
                suggestions.append(f"  brew install {' '.join(set(brew_cmds))}")
        
        elif self.system == "windows":
            suggestions.append("\nWindows installation options:")
            suggestions.append("  # Using conda (recommended):")
            for tool in missing_tools:
                tool_info = self.TOOLS[tool]
                conda_pkg = tool_info["conda_package"]
                suggestions.append(f"  conda install -c bioconda {conda_pkg}")
            
            suggestions.append("\n  # Manual downloads:")
            suggestions.append("  BLAST+: https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST/")
            suggestions.append("  DIAMOND: https://github.com/bbuchfink/diamond/releases")
            suggestions.append("  Prodigal: https://github.com/hyattpd/Prodigal/releases")
            suggestions.append("  VSEARCH: https://github.com/torognes/vsearch/releases")
            
            suggestions.append("\n  # After downloading, add to PATH or place in:")
            suggestions.append(f"  {self.reference_data_path / 'TOOLS' if self.reference_data_path else 'Your reference data TOOLS directory'}")
        
        suggestions.append("\n  # Or manually place executables in:")
        if self.reference_data_path:
            tool_dir = self.reference_data_path / 'TOOLS' / '[tool_name]_vX.X.X'
            suggestions.append(f"  {tool_dir}/")
        else:
            suggestions.append("  Your reference data TOOLS directory/[tool_name]_vX.X.X/")
        suggestions.append("  Make sure the file is executable (on Linux/macOS: chmod +x)")
        
        return "\n".join(suggestions)
    
    def add_to_path(self, tool_name: str) -> bool:
        """
        Add tool directory to PATH (Windows only, or Unix with appropriate permissions).
        Returns True if successful.
        """
        tool_path = self.find_tool(tool_name)
        if not tool_path:
            return False
        
        tool_dir = str(tool_path.parent)
        
        if self.system == "windows":
            # On Windows, we can modify the user PATH
            try:
                import winreg
                
                # Open the registry key for user environment variables
                key = winreg.OpenKey(
                    winreg.HKEY_CURRENT_USER,
                    "Environment",
                    0,
                    winreg.KEY_SET_VALUE
                )
                
                # Get current PATH
                try:
                    current_path, _ = winreg.QueryValueEx(key, "PATH")
                except FileNotFoundError:
                    current_path = ""
                
                # Add tool directory if not already in PATH
                if tool_dir not in current_path:
                    new_path = f"{tool_dir};{current_path}" if current_path else tool_dir
                    winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
                    
                    # Notify system of change
                    import ctypes
                    HWND_BROADCAST = 0xFFFF
                    WM_SETTINGCHANGE = 0x001A
                    ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, "Environment")
                    
                    return True
            except Exception as e:
                warnings.warn(f"Failed to add to PATH: {str(e)}")
                return False
        else:
            # On Unix, we can suggest adding to PATH
            warnings.warn(
                f"To add {tool_dir} to your PATH permanently, add this line to your ~/.bashrc or ~/.zshrc:\n"
                f'export PATH="{tool_dir}:$PATH"'
            )
            return False


# Singleton instance
_tool_manager = None


def get_tool_manager(reference_data_path: Optional[Union[str, Path]] = None) -> ToolManager:
    """Get or create the global ToolManager instance."""
    global _tool_manager
    if _tool_manager is None:
        _tool_manager = ToolManager(reference_data_path)
    return _tool_manager


# Convenience functions
def find_tool(tool_name: str, reference_data_path: Optional[Union[str, Path]] = None) -> Optional[Path]:
    """Convenience function to find a tool."""
    return get_tool_manager(reference_data_path).find_tool(tool_name)


def verify_tool(tool_name: str, reference_data_path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
    """Convenience function to verify a tool."""
    return get_tool_manager(reference_data_path).verify_tool(tool_name)


def get_system_info() -> Dict[str, str]:
    """Get system information for debugging."""
    return {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "cpu_count": str(os.cpu_count()),
        "conda_prefix": os.environ.get("CONDA_PREFIX", "Not in conda"),
        "path": os.environ.get("PATH", ""),
    }
    