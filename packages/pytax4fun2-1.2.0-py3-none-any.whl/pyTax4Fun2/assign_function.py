"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Assign functional profiles to genomes using DIAMOND and Prodigal.
Uses polars-bio for efficient FASTA operations.
"""

import subprocess
import warnings
from pathlib import Path
from typing import Optional, List, Union, Dict, Any
from datetime import datetime

import polars as pl
import numpy as np

from .utils import (
    validate_file, validate_directory, get_tool_path, test_tool,
    normalize_extension, run_command, pyTax4Fun2Error,
    read_fasta_polars, write_fasta_polars, fasta_stats,
    extract_sequences_from_fasta, merge_fasta_files
)


def assign_function(
    genome_folder: str = "",
    genome_file: str = "",
    file_extension: str = "fasta",
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    num_of_threads: int = 1,
    fast: bool = False,
    path_to_diamond_binary_mac: str = "",
    output_format: str = "tsv",  # "tsv" or "csv"
    keep_temp_files: bool = False,
    chunk_size: int = 10000,
    min_protein_length: int = 100,
    tool_preference: str = "auto"  # ← ADD THIS LINE
) -> Dict[str, Any]:
    """
    Assign functional profiles to genomes using DIAMOND and Prodigal.
    
    Args:
        genome_folder: Path to folder containing genome files
        genome_file: Path to a single genome file
        file_extension: File extension of genome files
        path_to_reference_data: Path to pyTax4Fun2 reference data
        num_of_threads: Number of threads for DIAMOND
        fast: Use fast DIAMOND mode
        path_to_diamond_binary_mac: Alternative DIAMOND binary for macOS
        output_format: Output format ("tsv" or "csv")
        keep_temp_files: Keep temporary files for debugging
        chunk_size: Chunk size for processing large genomes
        min_protein_length: Minimum protein length to keep
        tool_preference: Tool discovery preference
            - "conda": Prefer tools from conda environment
            - "reference": Prefer tools from reference data directory
            - "auto": Try conda first, then reference
        
    Returns:
        Dict with results summary
        
    Raises:
        pyTax4Fun2Error: If inputs are invalid or processing fails
    """
    # Validate inputs
    if not file_extension:
        raise pyTax4Fun2Error("File extension must be specified")
    
    if genome_folder and genome_file:
        raise pyTax4Fun2Error("Specify either genome_folder OR genome_file, not both")
    
    if not genome_folder and not genome_file:
        raise pyTax4Fun2Error("Either genome_folder or genome_file must be specified")
    
    if num_of_threads < 1:
        raise pyTax4Fun2Error("num_of_threads must be >= 1")
    
    file_extension = normalize_extension(file_extension)
    
    # Get list of genome files
    genome_files = []
    if genome_file:
        validate_file(genome_file, "Genome file")
        genome_files = [Path(genome_file)]
    else:
        validate_directory(genome_folder, "Genome folder")
        genome_path = Path(genome_folder)
        
        # Find genome files with the specified extension
        genome_files = list(genome_path.glob(f"*{file_extension}"))
        if not genome_files:
            # Try without leading dot
            genome_files = list(genome_path.glob(f"*{file_extension.lstrip('.')}"))
        
        if not genome_files:
            raise pyTax4Fun2Error(
                f"No files found with extension '{file_extension}' in {genome_folder}"
            )
    
        # Get tool paths using new system
    from .tool_manager import get_tool_manager
    
    ref_path = Path(path_to_reference_data)
    tool_mgr = get_tool_manager(ref_path)
    
    # Find tools based on preference
    prodigal_path = None
    diamond_path = None
    
    if tool_preference == "conda" or tool_preference == "auto":
        # Try conda first
        prodigal_path = tool_mgr.find_tool("prodigal")
        diamond_path = tool_mgr.find_tool("diamond")
        
        if tool_preference == "auto" and (not prodigal_path or not diamond_path):
            # Fall back to reference directory
            prodigal_path = tool_mgr._check_tools_directory("prodigal", ["prodigal", "prodigal.exe"])
            diamond_path = tool_mgr._check_tools_directory("diamond", ["diamond", "diamond.exe"])
    else:
        # Try reference directory first
        prodigal_path = tool_mgr._check_tools_directory("prodigal", ["prodigal", "prodigal.exe"])
        diamond_path = tool_mgr._check_tools_directory("diamond", ["diamond", "diamond.exe"])
        
        if not prodigal_path or not diamond_path:
            # Fall back to conda
            if not prodigal_path:
                prodigal_path = tool_mgr.find_tool("prodigal")
            if not diamond_path:
                diamond_path = tool_mgr.find_tool("diamond")
    
    # Validate found tools
    if not prodigal_path:
        raise pyTax4Fun2Error(
            "Prodigal not found. Install with: conda install -c bioconda prodigal"
        )
    if not diamond_path:
        raise pyTax4Fun2Error(
            "DIAMOND not found. Install with: conda install -c bioconda diamond"
        )
    
    # Test tools
    if not test_tool(prodigal_path):
        raise pyTax4Fun2Error(f"Prodigal not working: {prodigal_path}")
    if not test_tool(diamond_path):
        raise pyTax4Fun2Error(f"DIAMOND not working: {diamond_path}")
    
    
    # # Get tool paths
    # try:
        # prodigal_path = get_tool_path("prodigal", path_to_reference_data)
        # diamond_path = get_tool_path("diamond", path_to_reference_data)
    # except Exception as e:
        # raise pyTax4Fun2Error(f"Failed to get tool paths: {str(e)}")
    
    # # Test tools
    # if not test_tool(prodigal_path):
        # raise pyTax4Fun2Error(f"Prodigal not executable: {prodigal_path}")
    # if not test_tool(diamond_path):
        # raise pyTax4Fun2Error(f"DIAMOND not executable: {diamond_path}")
    
    # KEGG database path
    kegg_db = Path(path_to_reference_data) / "KEGG" / "prokaryotes.dmnd"
    if not kegg_db.exists():
        raise pyTax4Fun2Error(f"KEGG database not found: {kegg_db}")
    
    # Process each genome
    results = {
        "total_genomes": len(genome_files),
        "processed_genomes": 0,
        "failed_genomes": 0,
        "total_proteins": 0,
        "total_kos": 0,
        "processing_time": 0,
        "output_files": []
    }
    
    start_time = datetime.now()
    
    for genome_idx, genome in enumerate(genome_files, 1):
        print(f"[{genome_idx}/{len(genome_files)}] Processing: {genome.name}")
        
        try:
            # Get genome statistics
            genome_stats = fasta_stats(genome)
            print(f"  Genome stats: {genome_stats['num_sequences']} contigs, "
                  f"{genome_stats['total_length']:,} bp, "
                  f"GC: {genome_stats['gc_content']:.1f}%")
            
            # Process genome
            genome_result = _process_single_genome(
                genome=genome,
                prodigal_path=prodigal_path,
                diamond_path=diamond_path,
                kegg_db=kegg_db,
                num_of_threads=num_of_threads,
                fast=fast,
                output_format=output_format,
                keep_temp_files=keep_temp_files,
                min_protein_length=min_protein_length
            )
            
            # Update results
            results["processed_genomes"] += 1
            results["total_proteins"] += genome_result.get("proteins_found", 0)
            results["total_kos"] += genome_result.get("kos_found", 0)
            results["output_files"].append(genome_result.get("output_file", ""))
            
            print(f"  Result: {genome_result.get('proteins_found', 0)} proteins, "
                  f"{genome_result.get('kos_found', 0)} KOs assigned")
            
        except Exception as e:
            warnings.warn(f"Failed to process {genome.name}: {str(e)}")
            results["failed_genomes"] += 1
            continue
    
    # Calculate processing time
    end_time = datetime.now()
    results["processing_time"] = (end_time - start_time).total_seconds()
    
    # Print summary
    print(f"\nFunctional assignment complete!")
    print(f"Summary:")
    print(f"  Total genomes: {results['total_genomes']}")
    print(f"  Processed: {results['processed_genomes']}")
    print(f"  Failed: {results['failed_genomes']}")
    print(f"  Total proteins: {results['total_proteins']:,}")
    print(f"  Total KOs: {results['total_kos']:,}")
    print(f"  Processing time: {results['processing_time']:.1f} seconds")
    
    if results["output_files"]:
        print(f"\nOutput files:")
        for output_file in results["output_files"]:
            if output_file:
                print(f"  - {Path(output_file).name}")
    
    return results


def _process_single_genome(
    genome: Path,
    prodigal_path: Path,
    diamond_path: Path,
    kegg_db: Path,
    num_of_threads: int = 1,
    fast: bool = False,
    output_format: str = "tsv",
    keep_temp_files: bool = False,
    min_protein_length: int = 100
) -> Dict[str, Any]:
    """
    Process a single genome file.
    
    Args:
        genome: Path to genome file
        prodigal_path: Path to Prodigal executable
        diamond_path: Path to DIAMOND executable
        kegg_db: Path to KEGG database
        num_of_threads: Number of threads
        fast: Use fast DIAMOND mode
        output_format: Output format
        keep_temp_files: Keep temporary files
        min_protein_length: Minimum protein length
        
    Returns:
        Dictionary with processing results
    """
    result = {
        "genome": str(genome),
        "proteins_found": 0,
        "kos_found": 0,
        "output_file": ""
    }
    
    # Create temporary directory for this genome
    temp_dir = genome.parent / f"{genome.stem}_temp"
    temp_dir.mkdir(exist_ok=True)
    
    # Use stem for filename handling
    stem = genome.stem
    faa_file = temp_dir / f"{stem}.faa"
    blast_file = temp_dir / f"{stem}.blast"
    output_file = genome.parent / f"{stem}_funPro.txt"
    
    try:
        # ============= STEP 1: Run Prodigal to predict proteins =============
        print(f"  Running Prodigal...")
        
        # Remove -q flag to see errors, use same command that works manually
        prodigal_cmd = [
            str(prodigal_path),
            "-i", str(genome),
            "-a", str(faa_file),
            "-o", str(temp_dir / "prodigal.out"),
            "-f", "gff",
            "-p", "single"
        ]
        
        returncode, stdout, stderr = run_command(prodigal_cmd, verbose=False)
        
        # Check if Prodigal succeeded
        if returncode != 0:
            print(f"  Prodigal stderr: {stderr[:500]}")
            raise pyTax4Fun2Error(f"Prodigal failed: {stderr}")
        
        # Verify the FASTA file was created
        if not faa_file.exists():
            print(f"  ERROR: Prodigal did not create {faa_file}")
            print(f"  stdout: {stdout[:500]}")
            raise pyTax4Fun2Error("Prodigal failed to create protein FASTA file")
        
        if faa_file.stat().st_size == 0:
            raise pyTax4Fun2Error("Prodigal created empty FASTA file")
        
        # Count proteins for reporting
        protein_count = sum(1 for _ in open(faa_file) if _.startswith('>'))
        print(f"  Predicted {protein_count} proteins")
        
        # ============= STEP 2: Filter proteins by length =============
        proteins_df = _filter_protein_sequences(faa_file, min_protein_length)
        result["proteins_found"] = proteins_df.height
        
        if proteins_df.height == 0:
            warnings.warn(f"No proteins > {min_protein_length} aa found in {genome.name}")
            _write_empty_output(output_file, output_format)
            result["output_file"] = str(output_file)
            return result
        
        print(f"  Filtered to {proteins_df.height} proteins (>= {min_protein_length} aa)")
        
        # Write filtered proteins
        filtered_faa = temp_dir / f"{stem}_filtered.faa"
        write_fasta_polars(proteins_df, filtered_faa)
        
        # ============= STEP 3: Run DIAMOND BLASTp =============
        print(f"  Running DIAMOND BLASTp...")
        diamond_mode = "--fast" if fast else "--sensitive"
        
        diamond_cmd = [
            str(diamond_path), "blastp", diamond_mode,
            "-p", str(num_of_threads),
            "-e", "1e-10",
            "-k", "1",
            "--max-target-seqs", "1",
            "-d", str(kegg_db),
            "-q", str(filtered_faa),
            "-o", str(blast_file),
            "--outfmt", "6", "qseqid", "sseqid", "pident", "length",
            "mismatch", "gapopen", "qstart", "qend", "sstart",
            "send", "evalue", "bitscore"
        ]
        
        returncode, stdout, stderr = run_command(diamond_cmd, verbose=False)
        if returncode != 0:
            warnings.warn(f"DIAMOND had non-zero exit: {stderr}")
        
        # ============= STEP 4: Process BLAST results =============
        print(f"  Processing BLAST results...")
        
        if not blast_file.exists() or blast_file.stat().st_size == 0:
            warnings.warn(f"No BLAST hits for {genome.name}")
            _write_empty_output(output_file, output_format)
            result["output_file"] = str(output_file)
            return result
        
        # Parse BLAST results and extract KOs
        try:
            kos_df = _parse_diamond_results(blast_file)
            result["kos_found"] = kos_df.height
        except Exception as e:
            warnings.warn(f"Failed to parse BLAST results for {genome.name}: {str(e)}")
            _write_empty_output(output_file, output_format)
            result["output_file"] = str(output_file)
            return result
        
        if kos_df.height == 0:
            warnings.warn(f"No KOs extracted from BLAST results for {genome.name}")
            _write_empty_output(output_file, output_format)
            result["output_file"] = str(output_file)
            return result
        
        print(f"  Extracted {kos_df.height} unique KOs")
        
        # ============= STEP 5: Write output =============
        print(f"  Writing output...")
        _write_ko_output(kos_df, output_file, output_format)
        result["output_file"] = str(output_file)
        
        # ============= STEP 6: Clean up temporary files =============
        if not keep_temp_files:
            _cleanup_temp_files(temp_dir, [faa_file, filtered_faa, blast_file])
        else:
            print(f"  Temporary files kept in: {temp_dir}")
        
        return result
        
    except Exception as e:
        # Clean up on error
        if not keep_temp_files and temp_dir.exists():
            import shutil
            shutil.rmtree(temp_dir)
        raise e        


def _filter_protein_sequences(
    faa_file: Path,
    min_length: int = 100
) -> pl.DataFrame:
    """
    Filter protein sequences by length.
    
    Args:
        faa_file: Path to FASTA file with protein sequences
        min_length: Minimum protein length
        
    Returns:
        DataFrame with filtered protein sequences
    """
    # Read protein sequences using polars_bio
    proteins_df = read_fasta_polars(faa_file)
    
    if proteins_df.is_empty():
        return proteins_df
    
    # Filter by length
    proteins_df = proteins_df.with_columns(
        pl.col("sequence").str.len_bytes().alias("length")
    )
    
    filtered_df = proteins_df.filter(pl.col("length") >= min_length)
    
    return filtered_df.drop("length")


def _parse_diamond_results(blast_file: Path) -> pl.DataFrame:
    """
    Parse DIAMOND BLAST results and extract KOs.
    """
    try:
        blast_df = pl.read_csv(
            blast_file,
            separator="\t",
            has_header=False,
            new_columns=[
                "qseqid", "sseqid", "pident", "length", "mismatch", "gapopen",
                "qstart", "qend", "sstart", "send", "evalue", "bitscore"
            ],
            schema_overrides={
                "qseqid": pl.Utf8,
                "sseqid": pl.Utf8,
                "pident": pl.Float64,
                "length": pl.Int64,
                "mismatch": pl.Int64,
                "gapopen": pl.Int64,
                "qstart": pl.Int64,
                "qend": pl.Int64,
                "sstart": pl.Int64,
                "send": pl.Int64,
                "evalue": pl.Float64,
                "bitscore": pl.Float64,
            },
            ignore_errors=True,
            truncate_ragged_lines=True
        )
    except Exception as e:
        print(f"  Warning: CSV parsing failed, trying manual parsing: {e}")
        blast_df = _parse_blast_manual(blast_file)
    
    if blast_df.is_empty():
        return pl.DataFrame({"KO": [], "Count": []})
    
    # Extract KOs from sseqid column
    def extract_kos(sseqid: str) -> List[str]:
        """Extract KOs from sseqid string."""
        if not isinstance(sseqid, str):
            return []
        
        # Try different KO patterns
        import re
        # Pattern: ko:K12345 or K12345
        ko_pattern = r'ko:?(K\d{5})'
        matches = re.findall(ko_pattern, sseqid)
        if matches:
            return matches
        
        # Split by colon and look for K numbers
        parts = sseqid.split(':')
        kos = []
        for part in parts:
            if part.startswith('K') and len(part) >= 6 and part[1:6].isdigit():
                kos.append(part[:6])
            elif part.startswith('ko:') and len(part) > 3:
                ko_part = part[3:]
                if ko_part.startswith('K') and len(ko_part) >= 6:
                    kos.append(ko_part[:6])
        return kos
    
    # Extract KOs
    kos_list = []
    for sseqid in blast_df["sseqid"].to_list():
        kos = extract_kos(sseqid)
        kos_list.extend(kos)
    
    if not kos_list:
        return pl.DataFrame({"KO": [], "Count": []})
    
    # Create DataFrame and count KOs
    kos_df = pl.DataFrame({"KO": kos_list})
    ko_counts = kos_df.group_by("KO").agg(
        pl.len().alias("Count")
    ).sort("Count", descending=True)
    
    return ko_counts


def _parse_blast_manual(blast_file: Path) -> pl.DataFrame:
    """
    Manually parse BLAST output with robust error handling.
    
    Args:
        blast_file: Path to BLAST output file
        
    Returns:
        DataFrame with parsed results
    """
    data = []
    skipped_lines = 0
    
    with open(blast_file, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            
            parts = line.split('\t')
            
            # Skip if not enough columns
            if len(parts) < 12:
                skipped_lines += 1
                continue
            
            try:
                # Parse each column with proper type conversion
                row = [
                    parts[0],  # qseqid (string)
                    parts[1],  # sseqid (string)
                    float(parts[2]) if parts[2] else 0.0,  # pident
                    int(float(parts[3])) if parts[3] else 0,  # length
                    int(float(parts[4])) if parts[4] else 0,  # mismatch
                    int(float(parts[5])) if parts[5] else 0,  # gapopen
                    int(float(parts[6])) if parts[6] else 0,  # qstart
                    int(float(parts[7])) if parts[7] else 0,  # qend
                    int(float(parts[8])) if parts[8] else 0,  # sstart
                    int(float(parts[9])) if parts[9] else 0,  # send
                    float(parts[10]) if parts[10] else 0.0,  # evalue
                    float(parts[11]) if parts[11] else 0.0,  # bitscore
                ]
                data.append(row)
                
            except (ValueError, IndexError) as e:
                skipped_lines += 1
                # Silently skip problematic lines
                continue
    
    if skipped_lines > 0:
        print(f"    Skipped {skipped_lines} problematic lines in BLAST output")
    
    if not data:
        return pl.DataFrame()
    
    # Create DataFrame with proper schema
    return pl.DataFrame(
        data,
        schema={
            "qseqid": pl.Utf8,
            "sseqid": pl.Utf8,
            "pident": pl.Float64,
            "length": pl.Int64,
            "mismatch": pl.Int64,
            "gapopen": pl.Int64,
            "qstart": pl.Int64,
            "qend": pl.Int64,
            "sstart": pl.Int64,
            "send": pl.Int64,
            "evalue": pl.Float64,
            "bitscore": pl.Float64,
        }
    )


def _write_ko_output(
    ko_df: pl.DataFrame,
    output_file: Path,
    output_format: str = "tsv"
) -> None:
    """
    Write KO counts to output file.
    
    Args:
        ko_df: DataFrame with KO counts
        output_file: Output file path
        output_format: Output format ("tsv" or "csv")
    """
    if ko_df.is_empty():
        _write_empty_output(output_file, output_format)
        return
    
    # Ensure required columns exist
    required_cols = ["KO", "Count"]
    for col in required_cols:
        if col not in ko_df.columns:
            warnings.warn(f"Missing required column '{col}' in KO DataFrame")
            _write_empty_output(output_file, output_format)
            return
    
    # Add KO descriptions if not present
    if "Description" not in ko_df.columns:
        ko_df = ko_df.with_columns(
            pl.lit("").alias("Description")
        )
    
    # Ensure Count is integer type
    if ko_df["Count"].dtype not in [pl.Int64, pl.Int32, pl.UInt64, pl.UInt32]:
        try:
            ko_df = ko_df.with_columns(
                pl.col("Count").cast(pl.Int64)
            )
        except Exception as e:
            warnings.warn(f"Failed to convert Count to integer: {str(e)}")
    
    # Write output
    try:
        if output_format.lower() == "csv":
            ko_df.write_csv(output_file)
        else:  # Default to TSV
            ko_df.write_csv(output_file, separator="\t")
        
        print(f"    -> Written: {output_file.name} ({ko_df.height} KOs)")
        
    except Exception as e:
        warnings.warn(f"Failed to write output file {output_file.name}: {str(e)}")
        
        # Fallback: try writing with pandas if polars fails
        try:
            import pandas as pd
            pdf = ko_df.to_pandas()
            if output_format.lower() == "csv":
                pdf.to_csv(output_file, index=False)
            else:
                pdf.to_csv(output_file, sep="\t", index=False)
            print(f"    -> Written (fallback): {output_file.name} ({ko_df.height} KOs)")
        except Exception as e2:
            warnings.warn(f"Fallback also failed: {str(e2)}")
            raise pyTax4Fun2Error(f"Cannot write output file: {output_file}")


def _write_empty_output(
    output_file: Path,
    output_format: str = "tsv"
) -> None:
    """
    Write empty output file.
    
    Args:
        output_file: Output file path
        output_format: Output format
    """
    # Create empty DataFrame with proper structure
    empty_df = pl.DataFrame({
        "KO": [],
        "Count": [],
        "Description": []
    })
    
    # Write output based on format
    try:
        if output_format.lower() == "csv":
            empty_df.write_csv(output_file)
        else:  # Default to TSV
            empty_df.write_csv(output_file, separator="\t")
        
        print(f"    -> Written empty file: {output_file.name}")
        
    except Exception as e:
        warnings.warn(f"Failed to write empty output file {output_file.name}: {str(e)}")
        # Fallback: create an empty file with headers
        try:
            with open(output_file, 'w') as f:
                if output_format.lower() == "csv":
                    f.write("KO,Count,Description\n")
                else:
                    f.write("KO\tCount\tDescription\n")
            print(f"    -> Written empty file (fallback): {output_file.name}")
        except Exception as e2:
            warnings.warn(f"Failed to create empty file {output_file.name}: {str(e2)}")
            

def _cleanup_temp_files(
    temp_dir: Path,
    files_to_remove: List[Path]
) -> None:
    """
    Clean up temporary files.
    
    Args:
        temp_dir: Temporary directory
        files_to_remove: List of files to remove
    """
    for file_path in files_to_remove:
        if file_path.exists():
            file_path.unlink()
    
    # Remove empty temp directory
    try:
        temp_dir.rmdir()
    except:
        pass


def assign_function_batch(
    genome_files: List[Path],
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    output_dir: Optional[Path] = None,
    num_of_threads: int = 4,
    max_workers: int = 4,
    chunk_size: int = 10000
) -> Dict[str, Any]:
    """
    Assign functional profiles to multiple genomes in batch mode.
    
    Args:
        genome_files: List of genome files
        path_to_reference_data: Path to reference data
        output_dir: Output directory (default: same as input)
        num_of_threads: DIAMOND threads per genome
        max_workers: Maximum parallel genomes to process
        chunk_size: Chunk size for processing
        
    Returns:
        Dictionary with batch results
    """
    import concurrent.futures
    from functools import partial
    
    if not genome_files:
        raise pyTax4Fun2Error("No genome files provided")
    
    # Set output directory
    if output_dir is None:
        output_dir = genome_files[0].parent
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Get tool paths once
    try:
        prodigal_path = get_tool_path("prodigal", path_to_reference_data)
        diamond_path = get_tool_path("diamond", path_to_reference_data)
    except Exception as e:
        raise pyTax4Fun2Error(f"Failed to get tool paths: {str(e)}")
    
    # KEGG database path
    kegg_db = Path(path_to_reference_data) / "KEGG" / "prokaryotes.dmnd"
    if not kegg_db.exists():
        raise pyTax4Fun2Error(f"KEGG database not found: {kegg_db}")
    
    # Prepare processing function
    process_func = partial(
        _process_genome_batch,
        prodigal_path=prodigal_path,
        diamond_path=diamond_path,
        kegg_db=kegg_db,
        output_dir=output_dir,
        num_of_threads=num_of_threads,
        chunk_size=chunk_size
    )
    
    # Process in parallel
    results = {
        "total": len(genome_files),
        "successful": 0,
        "failed": 0,
        "output_files": [],
        "processing_times": []
    }
    
    print(f"Processing {len(genome_files)} genomes with {max_workers} workers...")
    
    with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as executor:
        # Submit all jobs
        future_to_genome = {
            executor.submit(process_func, genome): genome 
            for genome in genome_files
        }
        
        # Process results as they complete
        for future in concurrent.futures.as_completed(future_to_genome):
            genome = future_to_genome[future]
            try:
                genome_result = future.result(timeout=3600)  # 1 hour timeout
                
                if genome_result.get("success", False):
                    results["successful"] += 1
                    results["output_files"].append(genome_result.get("output_file", ""))
                    results["processing_times"].append(genome_result.get("processing_time", 0))
                    
                    print(f"✓ {genome.name}: {genome_result.get('kos_found', 0)} KOs, "
                          f"{genome_result.get('processing_time', 0):.1f}s")
                else:
                    results["failed"] += 1
                    print(f"✗ {genome.name}: Failed")
                    
            except concurrent.futures.TimeoutError:
                results["failed"] += 1
                print(f"✗ {genome.name}: Timeout")
            except Exception as e:
                results["failed"] += 1
                print(f"✗ {genome.name}: {str(e)}")
    
    # Calculate statistics
    if results["successful"] > 0:
        results["avg_processing_time"] = np.mean(results["processing_times"])
        results["total_kos"] = sum(
            1 for f in results["output_files"] 
            if Path(f).exists() and Path(f).stat().st_size > 0
        )
    else:
        results["avg_processing_time"] = 0
        results["total_kos"] = 0
    
    print(f"\nBatch processing complete!")
    print(f"  Successful: {results['successful']}/{results['total']}")
    print(f"  Failed: {results['failed']}/{results['total']}")
    print(f"  Average time per genome: {results['avg_processing_time']:.1f}s")
    
    return results


def _process_genome_batch(
    genome: Path,
    prodigal_path: Path,
    diamond_path: Path,
    kegg_db: Path,
    output_dir: Path,
    num_of_threads: int = 1,
    chunk_size: int = 10000
) -> Dict[str, Any]:
    """
    Process a single genome in batch mode.
    
    Args:
        genome: Genome file path
        prodigal_path: Prodigal executable path
        diamond_path: DIAMOND executable path
        kegg_db: KEGG database path
        output_dir: Output directory
        num_of_threads: Number of threads
        chunk_size: Chunk size
        
    Returns:
        Processing results
    """
    import time
    
    start_time = time.time()
    
    try:
        # Create output filename
        output_file = output_dir / f"{genome.stem}_funPro.txt"
        
        # Process genome
        result = _process_single_genome(
            genome=genome,
            prodigal_path=prodigal_path,
            diamond_path=diamond_path,
            kegg_db=kegg_db,
            num_of_threads=num_of_threads,
            fast=True,  # Use fast mode for batch processing
            output_format="tsv",
            keep_temp_files=False,
            min_protein_length=100
        )
        
        # Move output to target directory if needed
        if Path(result["output_file"]) != output_file:
            import shutil
            shutil.move(result["output_file"], output_file)
            result["output_file"] = str(output_file)
        
        result["success"] = True
        result["processing_time"] = time.time() - start_time
        
        return result
        
    except Exception as e:
        return {
            "genome": str(genome),
            "success": False,
            "error": str(e),
            "processing_time": time.time() - start_time
        }


def merge_functional_profiles(
    profile_files: List[Path],
    output_file: Path,
    output_format: str = "tsv"
) -> pl.DataFrame:
    """
    Merge multiple functional profile files.
    
    Args:
        profile_files: List of functional profile files
        output_file: Output file path
        output_format: Output format
        
    Returns:
        Merged DataFrame
    """
    if not profile_files:
        raise pyTax4Fun2Error("No profile files provided")
    
    # Read all profile files
    all_profiles = []
    
    for profile_file in profile_files:
        if not profile_file.exists():
            warnings.warn(f"Profile file not found: {profile_file}")
            continue
        
        try:
            # Try different separators
            for sep in ["\t", ",", " "]:
                try:
                    df = pl.read_csv(profile_file, separator=sep)
                    if df.height > 0:
                        # Add genome identifier
                        genome_name = profile_file.stem.replace("_funPro", "")
                        df = df.with_columns(
                            pl.lit(genome_name).alias("Genome")
                        )
                        all_profiles.append(df)
                        break
                except:
                    continue
        except Exception as e:
            warnings.warn(f"Error reading profile file {profile_file}: {str(e)}")
    
    if not all_profiles:
        raise pyTax4Fun2Error("No valid profile data found")
    
    # Merge all profiles
    merged_df = pl.concat(all_profiles)
    
    # Pivot to wide format (KOs × Genomes)
    if "Genome" in merged_df.columns and "KO" in merged_df.columns and "Count" in merged_df.columns:
        # Create pivot table
        pivot_df = merged_df.pivot(
            values="Count",
            index="KO",
            columns="Genome",
            aggregate_function="sum"
        ).fill_null(0)
        
        # Add description column if available
        if "Description" in merged_df.columns:
            # Get first description for each KO
            desc_df = merged_df.select(["KO", "Description"]).unique(subset=["KO"], keep="first")
            pivot_df = pivot_df.join(desc_df, on="KO", how="left")
    
    # Write merged output
    if output_format.lower() == "csv":
        pivot_df.write_csv(output_file)
    else:
        pivot_df.write_csv(output_file, separator="\t")
    
    print(f"Merged {len(profile_files)} profiles into {output_file.name}")
    print(f"Total KOs: {pivot_df.height}, Genomes: {len(pivot_df.columns) - 1}")
    
    return pivot_df


def analyze_functional_profiles(
    profile_file: Path,
    min_occurrence: int = 1,
    min_total_count: int = 10
) -> Dict[str, Any]:
    """
    Analyze functional profile statistics.
    
    Args:
        profile_file: Functional profile file
        min_occurrence: Minimum genomes a KO must appear in
        min_total_count: Minimum total count for a KO
        
    Returns:
        Analysis results
    """
    if not profile_file.exists():
        raise pyTax4Fun2Error(f"Profile file not found: {profile_file}")
    
    # Read profile file
    try:
        # Try different separators
        for sep in ["\t", ",", " "]:
            try:
                df = pl.read_csv(profile_file, separator=sep)
                if df.height > 0:
                    break
            except:
                continue
    except Exception as e:
        raise pyTax4Fun2Error(f"Error reading profile file: {str(e)}")
    
    if df.is_empty():
        return {
            "total_kos": 0,
            "total_counts": 0,
            "kos_per_genome": {},
            "common_kos": []
        }
    
    # Extract KO column and count columns
    ko_col = None
    count_cols = []
    
    for col in df.columns:
        if col.upper() in ["KO", "KEGG", "GENE"]:
            ko_col = col
        elif col != "Description" and col != "Genome":
            # Assume numeric columns are count columns
            count_cols.append(col)
    
    if not ko_col:
        raise pyTax4Fun2Error("Could not find KO column in profile file")
    
    if not count_cols:
        # Try to identify numeric columns
        numeric_cols = df.select(pl.col(pl.NUMERIC_DTYPES)).columns
        count_cols = [c for c in numeric_cols if c != ko_col]
    
    # Calculate statistics
    total_counts = df.select(count_cols).sum().row(0)
    total_kos = df.height
    
    # Calculate occurrence per genome
    occurrence_stats = {}
    for col in count_cols:
        present = df.filter(pl.col(col) > 0).height
        occurrence_stats[col] = present
    
    # Find common KOs
    common_kos = []
    if count_cols:
        # KOs present in at least min_occurrence genomes
        occurrence_expr = sum(pl.col(col) > 0 for col in count_cols)
        common_df = df.filter(occurrence_expr >= min_occurrence)
        
        # Further filter by total count
        total_count_expr = sum(pl.col(col) for col in count_cols)
        common_df = common_df.filter(total_count_expr >= min_total_count)
        
        common_kos = common_df[ko_col].to_list()
    
    results = {
        "total_kos": total_kos,
        "total_counts": sum(total_counts),
        "kos_per_genome": occurrence_stats,
        "common_kos": common_kos,
        "common_kos_count": len(common_kos),
        "genome_count": len(count_cols)
    }
    
    # Print summary
    print(f"Functional profile analysis for {profile_file.name}:")
    print(f"  Total KOs: {results['total_kos']:,}")
    print(f"  Total counts: {results['total_counts']:,}")
    print(f"  Genomes: {results['genome_count']}")
    print(f"  Common KOs (in ≥{min_occurrence} genomes, ≥{min_total_count} total): {results['common_kos_count']}")
    
    if results['common_kos_count'] > 0:
        print(f"  First 10 common KOs: {results['common_kos'][:10]}")
    
    return results


def main():
    """Command-line interface for assign_function."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Assign functional profiles to genomes using DIAMOND and Prodigal"
    )
    
    parser.add_argument(
        "--genome-folder", "-f",
        help="Path to folder containing genome files"
    )
    parser.add_argument(
        "--genome-file", "-i",
        help="Path to a single genome file"
    )
    parser.add_argument(
        "--extension", "-e",
        default="fasta",
        help="File extension of genome files (default: fasta)"
    )
    parser.add_argument(
        "--reference-data", "-r",
        default="pyTax4Fun2_ReferenceData",
        help="Path to reference data directory"
    )
    parser.add_argument(
        "--threads", "-t",
        type=int,
        default=1,
        help="Number of threads for DIAMOND (default: 1)"
    )
    parser.add_argument(
        "--fast",
        action="store_true",
        help="Use fast DIAMOND mode (less sensitive but faster)"
    )
    parser.add_argument(
        "--output-format",
        choices=["tsv", "csv"],
        default="tsv",
        help="Output format (default: tsv)"
    )
    parser.add_argument(
        "--keep-temp",
        action="store_true",
        help="Keep temporary files for debugging"
    )
    parser.add_argument(
        "--min-protein-length",
        type=int,
        default=100,
        help="Minimum protein length to keep (default: 100)"
    )
    parser.add_argument(
        "--batch",
        action="store_true",
        help="Process all files in folder as batch"
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=4,
        help="Maximum parallel genomes for batch processing (default: 4)"
    )
    
    args = parser.parse_args()
    
    try:
        if args.batch and args.genome_folder:
            # Batch processing
            genome_path = Path(args.genome_folder)
            genome_files = list(genome_path.glob(f"*{args.extension}"))
            
            if not genome_files:
                print(f"No files found with extension '{args.extension}' in {args.genome_folder}")
                return
            
            print(f"Found {len(genome_files)} genome files for batch processing")
            
            results = assign_function_batch(
                genome_files=genome_files,
                path_to_reference_data=args.reference_data,
                num_of_threads=args.threads,
                max_workers=args.max_workers
            )
            
        else:
            # Single or folder processing
            results = assign_function(
                genome_folder=args.genome_folder,
                genome_file=args.genome_file,
                file_extension=args.extension,
                path_to_reference_data=args.reference_data,
                num_of_threads=args.threads,
                fast=args.fast,
                output_format=args.output_format,
                keep_temp_files=args.keep_temp,
                min_protein_length=args.min_protein_length
            )
        
        print("\n✅ Functional assignment completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
    