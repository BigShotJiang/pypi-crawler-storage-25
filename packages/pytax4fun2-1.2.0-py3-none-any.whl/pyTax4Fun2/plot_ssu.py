"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Visualizations for 16S rRNA extraction results.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pathlib import Path
import polars as pl

def plot_16s_extraction_summary(
    genome_folder: str,
    output_file: Optional[str] = None,
    figsize: tuple = (15, 10)
):
    """
    Visualize 16S rRNA extraction results across genomes.
    
    Args:
        genome_folder: Folder containing genome files and extracted 16S
        output_file: Output file path
        figsize: Figure size
    """
    from .utils import read_fasta_polars, fasta_stats
    
    genome_path = Path(genome_folder)
    
    # Find all 16S files
    ssu_files = list(genome_path.glob("*_16SrRNA.ffn"))
    
    if not ssu_files:
        print("No 16S rRNA files found")
        return
    
    # Collect statistics
    stats = []
    for ssu_file in ssu_files:
        genome_name = ssu_file.stem.replace('_16SrRNA', '')
        try:
            ssu_stats = fasta_stats(ssu_file)
            stats.append({
                'genome': genome_name,
                'num_16s': ssu_stats['num_sequences'],
                'avg_length': ssu_stats['avg_length'],
                'gc_content': ssu_stats['gc_content']
            })
        except Exception as e:
            print(f"Error processing {ssu_file.name}: {e}")
    
    if not stats:
        print("No valid 16S files found")
        return
    
    # Convert to DataFrame
    stats_df = pl.DataFrame(stats).to_pandas()
    
    # Create plots
    fig, axes = plt.subplots(2, 2, figsize=figsize)
    
    # 1. Number of 16S copies per genome
    stats_df.sort_values('num_16s', ascending=False).plot(
        x='genome', y='num_16s', kind='bar', ax=axes[0, 0],
        color='skyblue', edgecolor='black'
    )
    axes[0, 0].set_xlabel('Genome')
    axes[0, 0].set_ylabel('Number of 16S Copies')
    axes[0, 0].set_title('16S rRNA Copy Numbers')
    axes[0, 0].tick_params(axis='x', rotation=45)
    
    # 2. Distribution of copy numbers
    axes[0, 1].hist(stats_df['num_16s'], bins=20, alpha=0.7, 
                    color='green', edgecolor='black')
    axes[0, 1].set_xlabel('16S Copy Number')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].set_title('Distribution of 16S Copy Numbers')
    axes[0, 1].axvline(stats_df['num_16s'].mean(), color='red', 
                       linestyle='--', label=f"Mean: {stats_df['num_16s'].mean():.1f}")
    axes[0, 1].legend()
    
    # 3. Average sequence length by genome
    stats_df.plot(x='genome', y='avg_length', kind='bar', ax=axes[1, 0],
                  color='orange', edgecolor='black')
    axes[1, 0].set_xlabel('Genome')
    axes[1, 0].set_ylabel('Average Length (bp)')
    axes[1, 0].set_title('Average 16S Sequence Length')
    axes[1, 0].tick_params(axis='x', rotation=45)
    
    # 4. GC content distribution
    axes[1, 1].hist(stats_df['gc_content'], bins=20, alpha=0.7,
                    color='purple', edgecolor='black')
    axes[1, 1].set_xlabel('GC Content (%)')
    axes[1, 1].set_ylabel('Frequency')
    axes[1, 1].set_title('GC Content Distribution')
    axes[1, 1].axvline(stats_df['gc_content'].mean(), color='red',
                       linestyle='--', label=f"Mean: {stats_df['gc_content'].mean():.1f}%")
    axes[1, 1].legend()
    
    plt.suptitle('16S rRNA Extraction Summary', y=1.02, fontsize=16)
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()
    
    return stats_df


def plot_16s_quality_control(
    ssu_file: str,
    output_file: Optional[str] = None,
    figsize: tuple = (12, 8)
):
    """
    Visualize quality metrics for extracted 16S sequences.
    
    Args:
        ssu_file: Path to 16S FASTA file
        output_file: Output file path
        figsize: Figure size
    """
    from .utils import read_fasta_polars
    
    # Read sequences
    df = read_fasta_polars(ssu_file)
    
    if df.is_empty():
        print(f"No sequences in {ssu_file}")
        return
    
    # Calculate metrics
    df = df.with_columns([
        pl.col("sequence").str.len_bytes().alias("length"),
        (pl.col("sequence").str.count_matches(r"[GCgc]") / 
         pl.col("sequence").str.len_bytes() * 100).alias("gc_content")
    ])
    
    # Convert to pandas for plotting
    pdf = df.to_pandas()
    
    fig, axes = plt.subplots(2, 2, figsize=figsize)
    
    # 1. Length distribution
    axes[0, 0].hist(pdf['length'], bins=50, alpha=0.7, color='blue', edgecolor='black')
    axes[0, 0].axvline(pdf['length'].mean(), color='red', linestyle='--',
                       label=f"Mean: {pdf['length'].mean():.0f} bp")
    axes[0, 0].axvline(1200, color='green', linestyle=':', label='Min expected (1200 bp)')
    axes[0, 0].axvline(1800, color='green', linestyle=':', label='Max expected (1800 bp)')
    axes[0, 0].set_xlabel('Sequence Length (bp)')
    axes[0, 0].set_ylabel('Frequency')
    axes[0, 0].set_title('16S Sequence Length Distribution')
    axes[0, 0].legend()
    
    # 2. GC content distribution
    axes[0, 1].hist(pdf['gc_content'], bins=50, alpha=0.7, color='purple', edgecolor='black')
    axes[0, 1].axvline(pdf['gc_content'].mean(), color='red', linestyle='--',
                       label=f"Mean: {pdf['gc_content'].mean():.1f}%")
    axes[0, 1].set_xlabel('GC Content (%)')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].set_title('GC Content Distribution')
    axes[0, 1].legend()
    
    # 3. Length vs GC content scatter
    axes[1, 0].scatter(pdf['length'], pdf['gc_content'], alpha=0.5, s=10)
    axes[1, 0].set_xlabel('Sequence Length (bp)')
    axes[1, 0].set_ylabel('GC Content (%)')
    axes[1, 0].set_title('Length vs GC Content')
    
    # 4. Cumulative distribution
    pdf_sorted = pdf.sort_values('length')
    cumulative = np.arange(1, len(pdf_sorted) + 1) / len(pdf_sorted)
    axes[1, 1].plot(pdf_sorted['length'], cumulative, 'b-', linewidth=2)
    axes[1, 1].axvline(1200, color='green', linestyle=':', label='Min expected')
    axes[1, 1].axvline(1800, color='green', linestyle=':', label='Max expected')
    axes[1, 1].set_xlabel('Sequence Length (bp)')
    axes[1, 1].set_ylabel('Cumulative Proportion')
    axes[1, 1].set_title('Cumulative Length Distribution')
    axes[1, 1].grid(True, alpha=0.3)
    axes[1, 1].legend()
    
    plt.suptitle(f'16S rRNA Quality Control: {Path(ssu_file).name}', fontsize=14)
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()
    
    return pdf
	