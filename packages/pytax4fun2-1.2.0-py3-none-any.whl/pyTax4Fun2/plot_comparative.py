"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Comparative analysis visualizations for multiple samples/groups.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

def plot_differential_abundance(
    functional_profiles: pl.DataFrame,
    group1_samples: List[str],
    group2_samples: List[str],
    group1_name: str = "Group1",
    group2_name: str = "Group2",
    output_file: Optional[str] = None,
    figsize: tuple = (14, 8),
    pvalue_threshold: float = 0.05,
    log2fc_threshold: float = 1.0
):
    """
    Create volcano plot for differential abundance analysis.
    
    Args:
        functional_profiles: Functional prediction DataFrame
        group1_samples: List of sample names in group 1
        group2_samples: List of sample names in group 2
        group1_name: Name for group 1
        group2_name: Name for group 2
        output_file: Output file path
        figsize: Figure size
        pvalue_threshold: P-value significance threshold
        log2fc_threshold: Log2 fold change threshold
    """
    # Prepare data
    pdf = functional_profiles.to_pandas()
    
    if 'KO' in pdf.columns:
        pdf.set_index('KO', inplace=True)
    
    # Extract group data
    group1_data = pdf[group1_samples].values
    group2_data = pdf[group2_samples].values
    
    # Calculate statistics
    results = []
    for i in range(len(pdf)):
        # Calculate mean abundances
        mean1 = np.mean(group1_data[i, :])
        mean2 = np.mean(group2_data[i, :])
        
        # Log2 fold change
        if mean1 > 0 and mean2 > 0:
            log2fc = np.log2(mean2 / mean1)
        elif mean2 > 0:
            log2fc = 10  # High enrichment in group2
        elif mean1 > 0:
            log2fc = -10  # High enrichment in group1
        else:
            log2fc = 0
        
        # T-test
        if np.std(group1_data[i, :]) > 0 and np.std(group2_data[i, :]) > 0:
            t_stat, p_value = stats.ttest_ind(group1_data[i, :], group2_data[i, :])
        else:
            t_stat, p_value = 0, 1.0
        
        results.append({
            'KO': pdf.index[i],
            'log2fc': log2fc,
            'pvalue': p_value,
            'mean1': mean1,
            'mean2': mean2
        })
    
    # Convert to DataFrame
    results_df = pd.DataFrame(results)
    
    # Adjust p-values
    results_df['padj'] = multipletests(results_df['pvalue'], method='fdr_bh')[1]
    results_df['-log10_padj'] = -np.log10(results_df['padj'] + 1e-10)
    
    # Determine significance
    results_df['significant'] = (
        (results_df['padj'] < pvalue_threshold) & 
        (np.abs(results_df['log2fc']) > log2fc_threshold)
    )
    
    # Create volcano plot
    fig, ax = plt.subplots(figsize=figsize)
    
    # Plot non-significant points
    nonsig = results_df[~results_df['significant']]
    ax.scatter(nonsig['log2fc'], nonsig['-log10_padj'], 
               alpha=0.5, s=20, color='gray', label='Not significant')
    
    # Plot significant points (colored by direction)
    sig_up = results_df[(results_df['significant']) & (results_df['log2fc'] > 0)]
    sig_down = results_df[(results_df['significant']) & (results_df['log2fc'] < 0)]
    
    ax.scatter(sig_up['log2fc'], sig_up['-log10_padj'], 
               alpha=0.8, s=50, color='red', label=f'Higher in {group2_name}')
    ax.scatter(sig_down['log2fc'], sig_down['-log10_padj'], 
               alpha=0.8, s=50, color='blue', label=f'Higher in {group1_name}')
    
    # Add threshold lines
    ax.axhline(-np.log10(pvalue_threshold), color='gray', linestyle='--', alpha=0.5)
    ax.axvline(log2fc_threshold, color='gray', linestyle='--', alpha=0.5)
    ax.axvline(-log2fc_threshold, color='gray', linestyle='--', alpha=0.5)
    
    # Label top significant KOs
    top_kos = results_df.nlargest(10, '-log10_padj')
    for _, row in top_kos.iterrows():
        ax.annotate(row['KO'], (row['log2fc'], row['-log10_padj']),
                   fontsize=8, alpha=0.7)
    
    ax.set_xlabel('Log2 Fold Change')
    ax.set_ylabel('-Log10(Adjusted P-value)')
    ax.set_title(f'Differential Abundance: {group1_name} vs {group2_name}')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()
    
    return results_df


def plot_correlation_network(
    functional_profiles: pl.DataFrame,
    correlation_threshold: float = 0.7,
    output_file: Optional[str] = None,
    figsize: tuple = (12, 12)
):
    """
    Create correlation network of KOs.
    
    Args:
        functional_profiles: Functional prediction DataFrame
        correlation_threshold: Minimum correlation to show edges
        output_file: Output file path
        figsize: Figure size
    """
    import networkx as nx
    
    # Prepare data
    pdf = functional_profiles.to_pandas()
    
    if 'KO' in pdf.columns:
        pdf.set_index('KO', inplace=True)
    
    # Identify sample columns
    sample_cols = [c for c in pdf.columns if pd.api.types.is_numeric_dtype(pdf[c])]
    
    # Calculate correlation matrix for top KOs
    # Limit to top 100 KOs for visualization
    ko_abundance = pdf[sample_cols].sum(axis=1)
    top_kos = ko_abundance.nlargest(100).index
    
    corr_matrix = pdf.loc[top_kos, sample_cols].T.corr()
    
    # Create network
    G = nx.Graph()
    
    # Add nodes
    for ko in corr_matrix.index:
        G.add_node(ko, size=ko_abundance[ko])
    
    # Add edges for strong correlations
    for i, ko1 in enumerate(corr_matrix.index):
        for j, ko2 in enumerate(corr_matrix.columns):
            if i < j:  # Avoid duplicates
                corr = corr_matrix.loc[ko1, ko2]
                if abs(corr) >= correlation_threshold:
                    G.add_edge(ko1, ko2, weight=abs(corr), correlation=corr)
    
    # Create plot
    fig, ax = plt.subplots(figsize=figsize)
    
    # Position nodes using force-directed layout
    pos = nx.spring_layout(G, k=2, iterations=50)
    
    # Draw nodes (size based on abundance)
    node_sizes = [G.nodes[node]['size'] * 10 for node in G.nodes()]
    nx.draw_networkx_nodes(G, pos, node_size=node_sizes, 
                          node_color='lightblue', alpha=0.8, ax=ax)
    
    # Draw edges (color based on correlation, width based on strength)
    positive_edges = [(u, v) for u, v, d in G.edges(data=True) if d['correlation'] > 0]
    negative_edges = [(u, v) for u, v, d in G.edges(data=True) if d['correlation'] < 0]
    
    nx.draw_networkx_edges(G, pos, edgelist=positive_edges, 
                          edge_color='red', alpha=0.3, width=1, ax=ax)
    nx.draw_networkx_edges(G, pos, edgelist=negative_edges, 
                          edge_color='blue', alpha=0.3, width=1, ax=ax)
    
    # Add labels for highly connected nodes
    labels = {}
    for node in G.nodes():
        if G.degree(node) > 5:
            labels[node] = node
    
    nx.draw_networkx_labels(G, pos, labels, font_size=8, ax=ax)
    
    ax.set_title(f'KO Correlation Network (|r| ≥ {correlation_threshold})')
    ax.axis('off')
    
    # Add legend
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], color='red', lw=2, alpha=0.3, label='Positive correlation'),
        Line2D([0], [0], color='blue', lw=2, alpha=0.3, label='Negative correlation')
    ]
    ax.legend(handles=legend_elements, loc='upper right')
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()
    
    return G
	