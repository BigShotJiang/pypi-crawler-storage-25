"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Generate clustered user-specific reference data.
"""

import subprocess
import shutil
from pathlib import Path
from typing import Optional, Union, List, Dict, Any
import warnings
import numpy as np
import polars as pl

from .utils import (
    validate_directory, validate_file, normalize_extension,
    read_fasta_polars, write_fasta_polars, read_kegg_profile,
    get_tool_path, test_tool, run_command, pyTax4Fun2Error,
    fasta_stats, merge_fasta_files
)


def generate_user_data_by_clustering(
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    path_to_user_data: str = "",
    name_of_user_data: str = "",
    SSU_file_extension: str = '_16SrRNA.ffn',
    KEGG_file_extension: str = '_funPro.txt',
    use_force: bool = True,
    similarity_threshold: float = 0.99,
    chunk_size: int = 10000
) -> Dict[str, Any]:
    """
    Generate clustered user-specific reference data.
    
    Args:
        path_to_reference_data: Path to reference data directory
        path_to_user_data: Path to user genome files directory
        name_of_user_data: Name for user database
        SSU_file_extension: File extension for 16S rRNA files
        KEGG_file_extension: File extension for functional profile files
        use_force: Overwrite existing output
        similarity_threshold: Clustering similarity (0-1 or 0-100)
        chunk_size: Chunk size for processing large files
        
    Returns:
        Dict with output directory, clusters, and copy numbers
        
    Raises:
        pyTax4Fun2Error: If inputs are invalid or processing fails
    """
    # Validate inputs
    if not path_to_user_data:
        raise pyTax4Fun2Error("path_to_user_data must be specified")
    
    validate_directory(path_to_user_data, "User data directory")
    validate_directory(path_to_reference_data, "Reference data directory")
    
    if not SSU_file_extension:
        raise pyTax4Fun2Error("SSU_file_extension must be specified")
    
    # Generate default name if not provided
    if not name_of_user_data:
        from datetime import datetime
        name_of_user_data = f"UserData_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # Normalize extensions
    SSU_ext = normalize_extension(SSU_file_extension, add_dot=False)
    KEGG_ext = normalize_extension(KEGG_file_extension, add_dot=False)
    
    if SSU_ext == KEGG_ext:
        raise pyTax4Fun2Error("SSU_file_extension and KEGG_file_extension must be different")
    
    # Validate similarity threshold
    if similarity_threshold > 1:
        similarity_threshold = similarity_threshold / 100
    
    if similarity_threshold < 0 or similarity_threshold > 1:
        raise pyTax4Fun2Error("similarity_threshold must be between 0 and 1 (or 0 and 100)")
    
    # Find SSU files
    user_path = Path(path_to_user_data)
    ssu_files = list(user_path.glob(f"*{SSU_ext}"))
    if not ssu_files:
        raise pyTax4Fun2Error(f"No SSU files found with extension '{SSU_ext}' in {path_to_user_data}")
    
    # Find KEGG files if extension provided
    kegg_files = []
    if KEGG_ext:
        kegg_files = list(user_path.glob(f"*{KEGG_ext}"))
        
        if len(ssu_files) != len(kegg_files):
            warnings.warn(
                f"Unequal number of SSU ({len(ssu_files)}) and KEGG ({len(kegg_files)}) files"
            )
    
    # Create output directory
    output_dir = user_path / name_of_user_data
    
    if output_dir.exists():
        if use_force:
            print(f"Removing existing user data directory: {output_dir}")
            shutil.rmtree(output_dir)
        else:
            raise pyTax4Fun2Error(
                f"Output directory exists: {output_dir}. Use use_force=True to overwrite."
            )
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Get VSEARCH path
    try:
        vsearch_path = get_tool_path("vsearch", path_to_reference_data)
        if not test_tool(vsearch_path):
            raise pyTax4Fun2Error(f"VSEARCH not executable: {vsearch_path}")
    except Exception as e:
        raise pyTax4Fun2Error(f"Failed to get VSEARCH: {str(e)}")
    
    # Step 1: Concatenate all sequences efficiently
    print("Step 1: Concatenating sequences...")
    
    copy_numbers = []
    all_sequence_dfs = []
    
    for ssu_file in ssu_files:
        genome_name = ssu_file.stem.replace(SSU_ext, "").rstrip(".")
        
        try:
            # Read sequences using polars_bio
            sequences_df = read_fasta_polars(ssu_file)
            num_sequences = sequences_df.height
            
            if num_sequences == 0:
                warnings.warn(f"No sequences in: {ssu_file.name}")
                continue
            
            # Store copy number
            copy_numbers.append({
                "gid": genome_name,
                "cn": num_sequences
            })
            
            # Create unique sequence IDs
            modified_df = sequences_df.with_columns(
                pl.Series(
                    "id",
                    [f"{genome_name}_{j}" for j in range(1, num_sequences + 1)]
                )
            )
            all_sequence_dfs.append(modified_df)
            
            print(f"  Added: {genome_name} ({num_sequences} sequences)")
            
        except Exception as e:
            warnings.warn(f"Error processing {ssu_file.name}: {str(e)}")
            continue
    
    if not all_sequence_dfs:
        raise pyTax4Fun2Error("No valid sequences found in any SSU files")
    
    # Concatenate all sequences
    concatenated_df = pl.concat(all_sequence_dfs)
    concatenated_fasta = output_dir / "joined.fasta"
    
    # Write concatenated file using polars_bio
    write_fasta_polars(concatenated_df, concatenated_fasta)
    
    # Step 2: Cluster sequences with VSEARCH
    print(f"\nStep 2: Clustering sequences at {similarity_threshold:.1%} similarity...")
    
    vsearch_output = output_dir / "joined.uc"
    centroids_file = output_dir / "centroids.fasta"
    
    vsearch_cmd = [
        str(vsearch_path),
        "--cluster_fast", str(concatenated_fasta),
        "--id", str(similarity_threshold),
        "--uc", str(vsearch_output),
        "--centroids", str(centroids_file),
        "--threads", "1"  # Single thread for consistent ordering
    ]
    
    returncode, stdout, stderr = run_command(vsearch_cmd, verbose=False)
    if returncode != 0:
        raise pyTax4Fun2Error(f"VSEARCH clustering failed: {stderr}")
    
    if not vsearch_output.exists() or vsearch_output.stat().st_size == 0:
        raise pyTax4Fun2Error("VSEARCH clustering produced no output")
    
    # Step 3: Process clustering results using Polars
    print("Step 3: Processing clustering results...")
    
    # Read UC file
    uc_columns = [
        "type", "cluster", "size", "percent_similarity", "strand",
        "qlo", "qhi", "tlo", "thi", "query", "target"
    ]
    
    uc_df = pl.read_csv(
        vsearch_output,
        separator="\t",
        has_header=False,
        new_columns=uc_columns[:11]
    )
    
    # Filter for cluster records (type H or S)
    cluster_data = uc_df.filter(pl.col("type").is_in(["H", "S"]))
    
    if cluster_data.is_empty():
        raise pyTax4Fun2Error("No valid clusters found in VSEARCH output")
    
    # Process clusters using Polars operations
    # Get representative sequences (type S or first of each cluster)
    rep_seqs = cluster_data.filter(
        (pl.col("type") == "S") |
        (pl.col("cluster") != pl.col("cluster").shift(1))
    ).select(["query", "cluster"])
    
    # Create sequence ID to genome name mapping
    seq_to_genome = {}
    for seq_id in concatenated_df["id"].to_list():
        if "_" in seq_id:
            genome_name = seq_id.rsplit("_", 1)[0]
            seq_to_genome[seq_id] = genome_name
    
    # Process each cluster
    cluster_info = []
    for cluster_id in cluster_data["cluster"].unique().to_list():
        cluster_members = cluster_data.filter(pl.col("cluster") == cluster_id)
        seq_ids = cluster_members["query"].to_list()
        
        # Get genome names from sequence IDs
        genome_names = [seq_to_genome.get(seq_id, "unknown") for seq_id in seq_ids]
        unique_genomes = list(set([g for g in genome_names if g != "unknown"]))
        
        # Get representative sequence
        rep_seq_info = rep_seqs.filter(pl.col("cluster") == cluster_id)
        rep_seq = rep_seq_info[0, "query"] if not rep_seq_info.is_empty() else seq_ids[0]
        
        cluster_info.append({
            "cluster_id": cluster_id,
            "rep_seq": rep_seq,
            "assigned_genome_ids": ",".join(unique_genomes),
            "num_genomes": len(unique_genomes),
            "num_sequences": len(seq_ids)
        })
    
    # Write cluster mapping file
    mapping_file = output_dir / "id2seq.txt"
    mapping_df = pl.DataFrame(cluster_info).select([
        "cluster_id", "rep_seq", "assigned_genome_ids"
    ])
    mapping_df.write_csv(mapping_file, separator="\t")
    
    print(f"  Found {len(cluster_info)} clusters")
    cluster_sizes = [c["num_sequences"] for c in cluster_info]
    print(f"  Cluster sizes: {min(cluster_sizes)} - {max(cluster_sizes)} sequences")
    
    # Step 4: Create representative sequence file
    print("\nStep 4: Creating representative sequence file...")
    
    # Extract representative sequences
    rep_seq_ids = [c["rep_seq"] for c in cluster_info]
    rep_seqs_df = concatenated_df.filter(pl.col("id").is_in(rep_seq_ids))
    
    # Rename with user IDs
    rep_seqs_df = rep_seqs_df.with_columns(
        pl.Series(
            "id",
            [f"user{cluster_info[i]['cluster_id']}_1" for i in range(len(rep_seq_ids))]
        )
    )
    
    rep_fasta = output_dir / "USER.fasta"
    write_fasta_polars(rep_seqs_df, rep_fasta)
    
    # Clean up temporary files
    concatenated_fasta.unlink()
    vsearch_output.unlink()
    
    # Step 5: Generate functional profiles
    if kegg_files:
        print("\nStep 5: Generating functional profiles...")
        
        # Load KEGG reference data
        ko_list_file = Path(path_to_reference_data) / "KEGG" / "ko.txt"
        if not ko_list_file.exists():
            raise pyTax4Fun2Error(f"KEGG KO list not found: {ko_list_file}")
        
        ko_df = pl.read_csv(ko_list_file, separator="\t")
        n_ko = ko_df.height
        
        # Create lookup for KEGG files
        kegg_lookup = {}
        for kegg_file in kegg_files:
            genome_name = kegg_file.stem.replace(KEGG_ext, "").rstrip(".")
            kegg_lookup[genome_name] = kegg_file
        
        # Create copy number lookup
        cn_lookup = {row["gid"]: row["cn"] for row in copy_numbers}
        
        # Process each cluster
        for cluster in cluster_info:
            cluster_id = cluster["cluster_id"]
            user_id = f"user{cluster_id}"
            
            # Get genome IDs in this cluster
            genome_ids = cluster["assigned_genome_ids"].split(",")
            
            # Initialize profile matrices
            uu_matrices = []
            un_matrices = []
            
            # Collect profiles for each genome in the cluster
            for genome_name in genome_ids:
                if genome_name in kegg_lookup:
                    kegg_file = kegg_lookup[genome_name]
                    
                    try:
                        profile_df = read_kegg_profile(kegg_file, ko_df)
                        
                        if profile_df.height == n_ko:
                            copy_num = cn_lookup.get(genome_name, 1)
                            
                            uu_array = profile_df["Freq"].to_numpy().astype(np.float32)
                            uu_matrices.append(uu_array)
                            
                            un_array = uu_array / copy_num if copy_num > 0 else np.zeros_like(uu_array)
                            un_matrices.append(un_array)
                    except Exception as e:
                        warnings.warn(f"Error reading KEGG profile for {genome_name}: {str(e)}")
            
            # Average profiles across genomes in cluster
            if uu_matrices:
                uu_avg = np.mean(uu_matrices, axis=0)
                un_avg = np.mean(un_matrices, axis=0)
            else:
                uu_avg = np.zeros(n_ko, dtype=np.float32)
                un_avg = np.zeros(n_ko, dtype=np.float32)
            
            # Create complete profile (du/dn are zeros for user data)
            functional_profile = pl.DataFrame({
                "du": np.zeros(n_ko, dtype=np.float32),
                "dn": np.zeros(n_ko, dtype=np.float32),
                "uu": uu_avg,
                "un": un_avg
            })
            
            # Write profile file
            profile_file = output_dir / f"{user_id}.tbl"
            functional_profile.write_csv(profile_file, separator="\t")
        
        print(f"  Generated {len(cluster_info)} functional profiles")
    else:
        print("\nStep 5: Creating empty functional profiles (no KEGG files provided)...")
        
        # Load KEGG reference data for dimension
        ko_list_file = Path(path_to_reference_data) / "KEGG" / "ko.txt"
        if not ko_list_file.exists():
            raise pyTax4Fun2Error(f"KEGG KO list not found: {ko_list_file}")
        
        ko_df = pl.read_csv(ko_list_file, separator="\t")
        n_ko = ko_df.height
        
        # Create empty profiles
        for cluster in cluster_info:
            user_id = f"user{cluster['cluster_id']}"
            
            empty_profile = pl.DataFrame({
                "du": np.zeros(n_ko, dtype=np.float32),
                "dn": np.zeros(n_ko, dtype=np.float32),
                "uu": np.zeros(n_ko, dtype=np.float32),
                "un": np.zeros(n_ko, dtype=np.float32)
            })
            
            profile_file = output_dir / f"{user_id}.tbl"
            empty_profile.write_csv(profile_file, separator="\t")
    
    print(f"\nClustered user data generation complete!")
    print(f"Output directory: {output_dir}")
    print(f"Clusters created: {len(cluster_info)}")
    
    return {
        "output_dir": str(output_dir),
        "clusters": cluster_info,
        "copy_numbers": copy_numbers,
        "total_sequences": concatenated_df.height
    }
    