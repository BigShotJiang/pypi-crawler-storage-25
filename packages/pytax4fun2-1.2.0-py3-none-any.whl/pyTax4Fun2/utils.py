"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Utility functions for pyTax4Fun2 Python implementation.
Uses Polars for DataFrame operations and optimized for performance.
"""

import os
import sys
import subprocess
import shutil
import hashlib
import tarfile
import zipfile
import warnings
import time
from pathlib import Path
from typing import Optional, Union, List, Dict, Any, Tuple, Iterator
from urllib.request import urlretrieve
from urllib.error import URLError
import concurrent.futures

import polars as pl
import numpy as np
from Bio import SeqIO  # Keep for compatibility
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
import requests
from tqdm import tqdm

# Try to import polars_bio, fall back to BioPython
try:
    import polars_bio as plb
    HAS_POLARS_BIO = True
except ImportError:
    HAS_POLARS_BIO = False
    warnings.warn(
        "polars_bio not installed. Install with: pip install polars-bio\n"
        "Falling back to BioPython (slower for large files)."
    )

from .tool_manager import get_tool_manager

# Configuration for tool versions (added for consistency)
TOOL_VERSIONS = {
    "diamond": "0.9.24",
    "prodigal": "2.6.3",
    "vsearch": "2.14.1",
    "blast": "2.14.0+"
}

# Default configuration
DEFAULT_CONFIG = {
    "blast_url_base": "https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST",
    "reference_data_urls": {
        "KEGG": "https://zenodo.org/records/19020935/files/KEGG.zip",
        "Ref99NR": "https://zenodo.org/records/19020935/files/Ref99NR.zip",
        "Ref100NR": "https://zenodo.org/records/19020935/files/Ref100NR.zip",
        "SILVA": "https://zenodo.org/records/19020935/files/SILVA.zip",
        "TOOLS": "https://zenodo.org/records/19020935/files/TOOLS.zip"
    }
}


class pyTax4Fun2Error(Exception):
    """Base exception for pyTax4Fun2 errors."""
    pass


def validate_file(filepath: Union[str, Path], file_type: str = "file") -> bool:
    """
    Validate that a file exists.
    
    Args:
        filepath: Path to file
        file_type: Description of file type for error message
        
    Returns:
        bool: True if file exists
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"{file_type} not found: {path.absolute()}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {path.absolute()}")
    return True


def validate_directory(dirpath: Union[str, Path], 
                       create: bool = False, 
                       writable: bool = False,
                       dir_type: str = "directory") -> bool:
    """
    Validate that a directory exists and optionally is writable.
    
    Args:
        dirpath: Path to directory
        create: Create directory if it doesn't exist
        writable: Check if directory is writable
        dir_type: Description of directory type for error message
        
    Returns:
        bool: True if directory is valid
        
    Raises:
        FileNotFoundError: If directory doesn't exist
        PermissionError: If directory is not writable
    """
    path = Path(dirpath)
    
    if not path.exists():
        if create:
            path.mkdir(parents=True, exist_ok=True)
        else:
            raise FileNotFoundError(f"{dir_type} not found: {path.absolute()}")
    
    if writable:
        # Check write permission by trying to create a temp file
        test_file = path / ".write_test"
        try:
            test_file.touch()
            test_file.unlink()
        except PermissionError:
            raise PermissionError(f"No write permission in directory: {path.absolute()}")
    
    return True


def download_with_checksum(url: str,
                          destfile: Union[str, Path],
                          expected_md5: Optional[str] = None,
                          max_retries: int = 3,
                          show_progress: bool = True) -> bool:
    """
    Download file with retries and MD5 checksum verification.
    
    Args:
        url: Download URL
        destfile: Destination file path
        expected_md5: Expected MD5 checksum (optional)
        max_retries: Maximum number of retry attempts
        show_progress: Show download progress bar
        
    Returns:
        bool: True if download successful
        
    Raises:
        RuntimeError: If download fails after all retries
    """
    dest_path = Path(destfile)
    
    # Validate URL format (basic check)
    if not url.startswith(('http://', 'https://')):
        raise ValueError(f"Invalid URL format: {url}")
    
    for attempt in range(1, max_retries + 1):
        try:
            print(f"Download attempt {attempt}/{max_retries}: {url}")
            
            # Create parent directory if it doesn't exist
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Download with progress bar
            if show_progress:
                response = requests.get(url, stream=True, timeout=30)
                response.raise_for_status()
                
                total_size = int(response.headers.get('content-length', 0))
                chunk_size = 8192
                
                with open(dest_path, 'wb') as f, \
                     tqdm(total=total_size, unit='B', 
                          unit_scale=True, desc=dest_path.name) as pbar:
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            f.write(chunk)
                            pbar.update(len(chunk))
            else:
                # Use urlretrieve with timeout
                import socket
                socket.setdefaulttimeout(30)
                urlretrieve(url, dest_path)
            
            # Verify file exists and has content
            if not dest_path.exists():
                raise RuntimeError("Downloaded file does not exist")
            
            file_size = dest_path.stat().st_size
            if file_size == 0:
                raise RuntimeError("Downloaded file is empty")
            
            # Verify checksum if provided
            if expected_md5:
                actual_md5 = calculate_md5(dest_path)
                if actual_md5 != expected_md5:
                    raise RuntimeError(
                        f"MD5 mismatch. Expected: {expected_md5}, Got: {actual_md5}. "
                        f"File may be corrupted."
                    )
            
            print(f"Download successful ({file_size:,} bytes)")
            return True
            
        except Exception as e:
            print(f"Attempt {attempt} failed: {str(e)}")
            
            # Clean up failed download
            if dest_path.exists():
                try:
                    dest_path.unlink()
                except:
                    pass
            
            if attempt == max_retries:
                raise RuntimeError(f"Failed after {max_retries} attempts: {str(e)}")
            
            # Exponential backoff
            wait_time = min(2 ** attempt, 60)  # Cap at 60 seconds
            time.sleep(wait_time)
    
    return False


def calculate_md5(filepath: Union[str, Path], chunk_size: int = 8192) -> str:
    """
    Calculate MD5 checksum of a file.
    
    Args:
        filepath: Path to file
        chunk_size: Size of chunks to read
        
    Returns:
        str: MD5 checksum in hex format
    """
    md5_hash = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            md5_hash.update(chunk)
    return md5_hash.hexdigest()


def normalize_extension(extension: str, add_dot: bool = True) -> str:
    """
    Normalize file extension.
    """
    if not extension:
        raise ValueError("File extension cannot be empty")
    
    extension = extension.strip()
    
    if add_dot and not extension.startswith("."):
        extension = "." + extension
    
    return extension  # ← Remove .lower()
    

def read_fasta_sequences(filepath: Union[str, Path]) -> List[SeqRecord]:
    """
    Read sequences from FASTA file.
    
    Args:
        filepath: Path to FASTA file
        
    Returns:
        List[SeqRecord]: List of sequence records
        
    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file is empty or invalid
    """
    filepath = Path(filepath)
    validate_file(filepath, "FASTA file")
    
    try:
        sequences = list(SeqIO.parse(filepath, "fasta"))
    except Exception as e:
        raise ValueError(f"Error parsing FASTA file {filepath}: {str(e)}")
    
    if not sequences:
        raise ValueError(f"No sequences found in: {filepath}")
    
    return sequences


def write_fasta_sequences(sequences: List[SeqRecord],
                         filepath: Union[str, Path],
                         mode: str = "w") -> None:
    """
    Write sequences to FASTA file.
    
    Args:
        sequences: List of sequence records
        filepath: Output file path
        mode: Write mode ('w' for write, 'a' for append)
    """
    with open(filepath, mode) as handle:
        SeqIO.write(sequences, handle, "fasta")


def read_fasta_polars(filepath: Union[str, Path]) -> pl.DataFrame:
    """
    Read FASTA file using polars_bio for better performance.
    
    Args:
        filepath: Path to FASTA file
        
    Returns:
        pl.DataFrame: DataFrame with columns: ['id', 'description', 'sequence']
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    filepath = Path(filepath)
    validate_file(filepath, "FASTA file")
    
    if HAS_POLARS_BIO:
        try:
            # polars_bio.read_fasta returns a DataFrame with columns 'id', 'description', 'sequence'
            return plb.read_fasta(filepath)
        except Exception as e:
            warnings.warn(f"polars_bio failed, falling back to BioPython: {str(e)}")
    
    # Fall back to BioPython
    sequences = read_fasta_sequences(filepath)
    
    # Convert to DataFrame
    data = []
    for seq in sequences:
        data.append({
            'id': seq.id,
            'description': seq.description,
            'sequence': str(seq.seq)
        })
    
    return pl.DataFrame(data)


def write_fasta_polars(df: pl.DataFrame, 
                      filepath: Union[str, Path],
                      id_col: str = 'id',
                      seq_col: str = 'sequence',
                      desc_col: Optional[str] = None,
                      mode: str = 'w') -> None:
    """
    Write DataFrame to FASTA file.
    
    Note: polars_bio does not have a write_fasta function, so we always use BioPython.
    
    Args:
        df: DataFrame with sequence data
        filepath: Output FASTA file path
        id_col: Column name for sequence IDs
        seq_col: Column name for sequences
        desc_col: Column name for descriptions (optional)
        mode: Write mode ('w' for write, 'a' for append)
    """
    filepath = Path(filepath)
    
    # Always use BioPython for writing (more reliable)
    sequences = []
    
    for row in df.iter_rows(named=True):
        seq_id = row[id_col]
        sequence = row[seq_col]
        description = row[desc_col] if desc_col and desc_col in row else ""
        
        seq_record = SeqRecord(
            Seq(sequence),
            id=seq_id,
            description=description
        )
        sequences.append(seq_record)
    
    # Determine write mode
    if mode == 'a':
        # Append mode - need to handle existing file
        if filepath.exists():
            # Read existing sequences and combine
            try:
                existing = list(SeqIO.parse(filepath, "fasta"))
                sequences = existing + sequences
            except:
                pass
    
    write_fasta_sequences(sequences, filepath, mode='w' if mode == 'a' else mode)


def read_fasta_streaming(filepath: Union[str, Path], 
                        chunk_size: int = 1000) -> Iterator[pl.DataFrame]:
    """
    Stream FASTA file in chunks for memory efficiency.
    
    Args:
        filepath: Path to FASTA file
        chunk_size: Number of sequences per chunk
        
    Yields:
        pl.DataFrame: Chunks of sequence data
    """
    filepath = Path(filepath)
    validate_file(filepath, "FASTA file")
    
    # Use BioPython streaming for reliability
    chunk = []
    
    for record in SeqIO.parse(filepath, "fasta"):
        chunk.append({
            'id': record.id,
            'description': record.description,
            'sequence': str(record.seq)
        })
        
        if len(chunk) >= chunk_size:
            yield pl.DataFrame(chunk)
            chunk = []
    
    if chunk:
        yield pl.DataFrame(chunk)


def fasta_stats(filepath: Union[str, Path]) -> Dict[str, Any]:
    """
    Get statistics about FASTA file using efficient methods.
    
    Args:
        filepath: Path to FASTA file
        
    Returns:
        Dict: Statistics about the FASTA file
    """
    filepath = Path(filepath)
    validate_file(filepath, "FASTA file")
    
    stats = {
        "num_sequences": 0,
        "total_length": 0,
        "min_length": float('inf'),
        "max_length": 0,
        "avg_length": 0,
        "gc_content": 0,
        "file_size_mb": filepath.stat().st_size / (1024 * 1024)
    }
    
    # Try polars_bio first
    if HAS_POLARS_BIO:
        try:
            df = plb.read_fasta(filepath)
            
            if df.height == 0:
                return stats
            
            # Calculate sequence lengths
            df = df.with_columns(
                pl.col("sequence").str.len_bytes().alias("length")
            )
            
            stats["num_sequences"] = df.height
            stats["total_length"] = df["length"].sum()
            stats["min_length"] = df["length"].min()
            stats["max_length"] = df["length"].max()
            stats["avg_length"] = stats["total_length"] / stats["num_sequences"]
            
            # Calculate GC content
            gc_counts = df["sequence"].str.count_matches(r"[GCgc]")
            total_bases = stats["total_length"]
            if total_bases > 0:
                stats["gc_content"] = gc_counts.sum() / total_bases * 100
            
            return stats
        except Exception as e:
            warnings.warn(f"polars_bio stats failed: {str(e)}")
    
    # Fall back to BioPython
    total_gc = 0
    
    for record in SeqIO.parse(filepath, "fasta"):
        stats["num_sequences"] += 1
        length = len(record.seq)
        stats["total_length"] += length
        stats["min_length"] = min(stats["min_length"], length)
        stats["max_length"] = max(stats["max_length"], length)
        
        # Calculate GC
        gc_count = sum(1 for base in str(record.seq).upper() if base in 'GC')
        total_gc += gc_count
    
    if stats["num_sequences"] > 0:
        stats["avg_length"] = stats["total_length"] / stats["num_sequences"]
        if stats["total_length"] > 0:
            stats["gc_content"] = (total_gc / stats["total_length"]) * 100
    
    return stats


def extract_sequences_from_fasta(
    filepath: Union[str, Path],
    seq_ids: List[str],
    output_path: Optional[Union[str, Path]] = None
) -> pl.DataFrame:
    """
    Extract specific sequences from FASTA file by ID.
    
    Args:
        filepath: Path to FASTA file
        seq_ids: List of sequence IDs to extract
        output_path: Optional path to write extracted sequences
        
    Returns:
        pl.DataFrame: Extracted sequences
    """
    filepath = Path(filepath)
    validate_file(filepath, "FASTA file")
    
    # Use polars_bio for filtering if available
    if HAS_POLARS_BIO:
        try:
            df = plb.read_fasta(filepath)
            extracted = df.filter(pl.col("id").is_in(seq_ids))
            
            if output_path:
                write_fasta_polars(extracted, output_path)
            
            return extracted
        except Exception as e:
            warnings.warn(f"polars_bio extraction failed: {str(e)}")
    
    # Fall back to BioPython
    extracted_data = []
    seq_ids_set = set(seq_ids)
    
    for record in SeqIO.parse(filepath, "fasta"):
        if record.id in seq_ids_set:
            extracted_data.append({
                'id': record.id,
                'description': record.description,
                'sequence': str(record.seq)
            })
    
    extracted_df = pl.DataFrame(extracted_data)
    
    if output_path and not extracted_df.is_empty():
        write_fasta_polars(extracted_df, output_path)
    
    return extracted_df


def merge_fasta_files(
    input_paths: List[Union[str, Path]],
    output_path: Union[str, Path],
    deduplicate: bool = True
) -> pl.DataFrame:
    """
    Merge multiple FASTA files.
    
    Args:
        input_paths: List of input FASTA files
        output_path: Output FASTA file path
        deduplicate: Remove duplicate sequences by ID
        
    Returns:
        pl.DataFrame: Merged sequences
    """
    all_dfs = []
    
    for input_path in input_paths:
        input_path = Path(input_path)
        if input_path.exists():
            df = read_fasta_polars(input_path)
            all_dfs.append(df)
    
    if not all_dfs:
        raise ValueError("No valid input files provided")
    
    # Combine all DataFrames
    merged_df = pl.concat(all_dfs)
    
    if deduplicate:
        merged_df = merged_df.unique(subset=['id'], keep='first')
    
    # Write output
    write_fasta_polars(merged_df, output_path)
    
    return merged_df


def read_blast_output(filepath: Union[str, Path]) -> pl.DataFrame:
    """
    Read BLAST output in tabular format (outfmt 6).
    
    Args:
        filepath: Path to BLAST output file
        
    Returns:
        pl.DataFrame: BLAST results
        
    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file is empty
    """
    filepath = Path(filepath)
    validate_file(filepath, "BLAST output file")
    
    # BLAST tabular format (outfmt 6) columns
    columns = [
        "qseqid", "sseqid", "pident", "length", "mismatch", "gapopen",
        "qstart", "qend", "sstart", "send", "evalue", "bitscore"
    ]
    
    try:
        # Try to read as tab-separated
        df = pl.read_csv(filepath, 
                        separator="\t",
                        has_header=False,
                        new_columns=columns,
                        infer_schema_length=10000)
        return df
    except Exception as e:
        # Fallback: read as text and parse
        try:
            with open(filepath) as f:
                lines = f.readlines()
        except Exception as read_error:
            raise ValueError(f"Cannot read BLAST file {filepath}: {str(read_error)}")
        
        if not lines:
            raise ValueError(f"Empty BLAST file: {filepath}")
        
        # Parse manually
        data = []
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if line and not line.startswith("#"):
                parts = line.split("\t")
                if len(parts) >= 12:  # Minimum required columns
                    data.append(parts[:12])
                elif len(parts) >= 3:  # At least qseqid, sseqid, pident
                    # Pad with zeros for missing columns
                    padded = parts + ["0"] * (12 - len(parts))
                    data.append(padded)
                else:
                    warnings.warn(f"Line {line_num} in {filepath.name} has insufficient columns")
        
        if not data:
            raise ValueError(f"No valid data in BLAST file: {filepath}")
        
        df = pl.DataFrame(data, schema=columns)
        
        # Convert numeric columns
        numeric_cols = ["pident", "length", "mismatch", "gapopen", 
                       "qstart", "qend", "sstart", "send", "evalue", "bitscore"]
        for col in numeric_cols:
            if col in df.columns:
                df = df.with_columns(pl.col(col).cast(pl.Float64))
        
        return df


def read_kegg_profile(filepath: Union[str, Path], 
                     ko_list: pl.DataFrame) -> pl.DataFrame:
    """
    Read KEGG profile file and merge with KO list.
    
    This function reads a KEGG functional profile file (typically *_funPro.txt)
    and merges it with a complete KO list to create a frequency vector for all KOs.
    
    Args:
        filepath: Path to KEGG profile file (e.g., genome_funPro.txt)
        ko_list: DataFrame with all KOs from ko.txt (columns: ko, description, ptw_count)
        
    Returns:
        pl.DataFrame: KO list with added 'Freq' column containing counts from the profile
        
    Raises:
        Warning: If file cannot be read, returns zeros for all KOs
    """
    filepath = Path(filepath)
    
    # Return zeros if file doesn't exist
    if not filepath.exists():
        warnings.warn(f"KEGG file not found: {filepath}")
        return ko_list.with_columns(pl.lit(0).alias("Freq"))
    
    try:
        # Attempt to read the file as TSV
        profile = pl.read_csv(filepath, separator="\t")
        
        # ============= FORMAT 1: pyTax4Fun2 _funPro.txt format =============
        # Format: KO, Count, Description (with header)
        if "KO" in profile.columns and "Count" in profile.columns:
            # Create mapping dictionary from KO to Count
            ko_to_count = {}
            for row in profile.iter_rows():
                # Find the KO column index
                ko_idx = profile.columns.index("KO")
                count_idx = profile.columns.index("Count")
                
                ko = row[ko_idx]
                count = row[count_idx]
                
                # Handle potential string counts (convert to int)
                if isinstance(count, str):
                    try:
                        count = int(count)
                    except ValueError:
                        count = 0
                elif isinstance(count, (float, int)):
                    count = int(count)
                else:
                    count = 0
                
                ko_to_count[ko] = count
            
            # Build Freq column for all KOs in ko_list
            freq_list = []
            for ko_row in ko_list.iter_rows():
                ko = ko_row[0]  # First column is KO ID
                freq = ko_to_count.get(ko, 0)
                freq_list.append(freq)
            
            # Add Freq column to result
            result = ko_list.with_columns(pl.Series("Freq", freq_list))
            return result
        
        # ============= FORMAT 2: Two-column format without header =============
        # Format: KO<TAB>Count (no header)
        elif profile.shape[1] == 2:
            # Rename columns
            profile = profile.rename({"column_1": "ko", "column_2": "count"})
            
            # Convert count to integer
            try:
                profile = profile.with_columns(pl.col("count").cast(pl.Int64))
            except Exception:
                # Try to extract numbers from strings
                profile = profile.with_columns(
                    pl.col("count")
                    .str.extract(r"(\d+)")
                    .cast(pl.Int64)
                    .alias("count")
                )
            
            # Handle multiple KOs separated by colons (e.g., "ko:K12345:K23456")
            if profile["ko"].str.contains(":").any():
                expanded_rows = []
                for row in profile.iter_rows(named=True):
                    kos = row["ko"].split(":")
                    for ko in kos:
                        # Remove 'ko:' prefix if present
                        if ko.startswith("ko:"):
                            ko = ko[3:]
                        if ko.strip() and ko.startswith("K"):
                            expanded_rows.append({
                                "ko": ko.strip(),
                                "count": row["count"]
                            })
                expanded = pl.DataFrame(expanded_rows)
            else:
                expanded = profile
            
            # Aggregate counts by KO (sum if multiple entries)
            agg_profile = expanded.group_by("ko").agg(
                pl.col("count").sum().alias("Freq")
            )
            
            # Merge with full KO list (left join to keep all KOs)
            result = ko_list.join(
                agg_profile, 
                left_on=ko_list.columns[0], 
                right_on="ko", 
                how="left"
            )
            result = result.with_columns(
                pl.col("Freq").fill_null(0)
            )
            return result
        
        # ============= FORMAT 3: Original Tax4Fun2 format =============
        # Format: KO:count (with ko: prefix, possibly multiple per line)
        elif profile.shape[1] == 1:
            # Parse single column format
            ko_counts = {}
            for row in profile.iter_rows():
                line = row[0]
                if isinstance(line, str):
                    parts = line.split(":")
                    if len(parts) >= 2 and parts[0] == "ko":
                        ko = parts[1]
                        count = 1  # Default count
                        if len(parts) > 2:
                            # Multiple KOs
                            for i in range(1, len(parts)):
                                ko_part = parts[i]
                                if ko_part.startswith("K"):
                                    ko_counts[ko_part] = ko_counts.get(ko_part, 0) + 1
                        else:
                            ko_counts[ko] = ko_counts.get(ko, 0) + count
            
            # Build Freq column
            freq_list = []
            for ko_row in ko_list.iter_rows():
                ko = ko_row[0]
                freq = ko_counts.get(ko, 0)
                freq_list.append(freq)
            
            result = ko_list.with_columns(pl.Series("Freq", freq_list))
            return result
        
        # ============= UNKNOWN FORMAT =============
        else:
            warnings.warn(
                f"Unexpected KEGG profile format in {filepath}. "
                f"Expected columns: 'KO' and 'Count', or 2 columns without header. "
                f"Got {profile.shape[1]} columns: {profile.columns}"
            )
            return ko_list.with_columns(pl.lit(0).alias("Freq"))
            
    except Exception as e:
        warnings.warn(f"Error reading KEGG profile {filepath}: {str(e)}")
        # Return zeros for all KOs on error
        return ko_list.with_columns(pl.lit(0).alias("Freq"))
        
        
def filter_unique_blast_hits(blast_df: pl.DataFrame) -> pl.DataFrame:
    """
    Filter BLAST results to keep only best hit per query.
    
    Args:
        blast_df: BLAST results DataFrame
        
    Returns:
        pl.DataFrame: Filtered results with unique hits per query
    """
    if blast_df.is_empty():
        return blast_df
    
    # Check if required columns exist
    required_cols = ["qseqid", "bitscore", "evalue"]
    for col in required_cols:
        if col not in blast_df.columns:
            warnings.warn(f"Missing column {col} in BLAST results")
            return blast_df
    
    # Sort by bitscore (descending) and evalue (ascending)
    sorted_df = blast_df.sort(["bitscore", "evalue"], descending=[True, False])
    
    # Keep first occurrence of each qseqid (best hit)
    unique_df = sorted_df.unique(subset=["qseqid"], keep="first")
    
    return unique_df


def run_command(cmd: Union[str, List[str]], 
                verbose: bool = False, 
                timeout: Optional[int] = None,
                cwd: Optional[Union[str, Path]] = None) -> Tuple[int, str, str]:
    """
    Run shell command with error handling.
    
    Args:
        cmd: Command to run (string or list)
        verbose: Print command output
        timeout: Command timeout in seconds
        cwd: Working directory for command
        
    Returns:
        Tuple[int, str, str]: (returncode, stdout, stderr)
        
    Raises:
        subprocess.SubprocessError: If command fails
    """
    # Always use shell=False for security unless explicitly needed
    shell = False
    
    if isinstance(cmd, str):
        # Check if string command contains shell features
        if any(char in cmd for char in ['|', '>', '<', '&', ';', '$', '`']):
            shell = True
            warnings.warn("Using shell=True for command with shell features. "
                         "Consider refactoring to use list format for security.")
        else:
            # Split simple string command
            import shlex
            cmd = shlex.split(cmd)
    else:
        cmd = [str(c) for c in cmd]  # Ensure all parts are strings
    
    if verbose:
        cmd_str = " ".join(cmd) if isinstance(cmd, list) else cmd
        print(f"Running command: {cmd_str}")
    
    try:
        result = subprocess.run(
            cmd,
            shell=shell,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd
        )
        
        if verbose:
            if result.stdout:
                print("STDOUT:", result.stdout[:500])  # First 500 chars
            if result.stderr:
                print("STDERR:", result.stderr[:500])
        
        return result.returncode, result.stdout, result.stderr
        
    except subprocess.TimeoutExpired as e:
        raise subprocess.SubprocessError(f"Command timed out after {timeout} seconds: {cmd}")
    except FileNotFoundError as e:
        raise subprocess.SubprocessError(f"Command not found: {cmd[0] if isinstance(cmd, list) else cmd}")
    except Exception as e:
        raise subprocess.SubprocessError(f"Command failed: {cmd}. Error: {str(e)}")


def parallel_apply(data: List[Any], 
                   func: callable, 
                   n_jobs: int = -1,
                   desc: str = "Processing",
                   **kwargs) -> List[Any]:
    """
    Apply function to list of items in parallel.
    
    Args:
        data: List of items to process
        func: Function to apply to each item
        n_jobs: Number of parallel jobs (-1 for all cores)
        desc: Description for progress bar
        **kwargs: Additional arguments to pass to function
        
    Returns:
        List[Any]: Results in same order as input
    """
    if n_jobs == -1:
        n_jobs = os.cpu_count() or 1
    
    # For small datasets, just process sequentially
    if len(data) <= 1 or n_jobs == 1:
        results = []
        for item in tqdm(data, desc=desc):
            results.append(func(item, **kwargs))
        return results
    
    # Use ThreadPoolExecutor for I/O bound tasks, ProcessPoolExecutor for CPU bound
    # Default to ThreadPoolExecutor as most tasks are I/O bound
    Executor = concurrent.futures.ThreadPoolExecutor
    
    with Executor(max_workers=n_jobs) as executor:
        # Submit all tasks
        futures = {executor.submit(func, item, **kwargs): i 
                  for i, item in enumerate(data)}
        
        # Collect results in order
        results = [None] * len(data)
        for future in tqdm(concurrent.futures.as_completed(futures), 
                          total=len(futures), 
                          desc=desc):
            idx = futures[future]
            try:
                results[idx] = future.result()
            except Exception as e:
                warnings.warn(f"Task {idx} failed: {str(e)}")
                results[idx] = None
    
    return results


def setup_logging(log_file: Optional[Union[str, Path]] = None,
                  level: str = "INFO") -> None:
    """
    Setup logging for pyTax4Fun2.
    
    Args:
        log_file: Optional log file path
        level: Logging level
    """
    import logging
    
    log_level = getattr(logging, level.upper())
    
    # Configure root logger
    logger = logging.getLogger("pyTax4Fun2")
    logger.setLevel(log_level)
    
    # Remove existing handlers
    logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_format = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)
    
    # File handler if specified
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(log_level)
        file_format = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    
    logger.propagate = False


def memory_usage() -> Dict[str, float]:
    """
    Get current memory usage.
    
    Returns:
        Dict[str, float]: Memory usage in MB
    """
    try:
        import psutil
        process = psutil.Process(os.getpid())
        mem_info = process.memory_info()
        
        return {
            "rss_mb": mem_info.rss / 1024 / 1024,  # Resident Set Size
            "vms_mb": mem_info.vms / 1024 / 1024,  # Virtual Memory Size
            "percent": process.memory_percent(),
        }
    except ImportError:
        warnings.warn("psutil not installed, cannot get memory usage")
        return {"rss_mb": 0, "vms_mb": 0, "percent": 0}


def chunk_dataframe(df: pl.DataFrame, chunk_size: int = 10000):
    """
    Generator to yield chunks of a Polars DataFrame.
    
    Args:
        df: Input DataFrame
        chunk_size: Size of each chunk
        
    Yields:
        pl.DataFrame: Chunk of the DataFrame
    """
    n_rows = df.height
    for start in range(0, n_rows, chunk_size):
        end = min(start + chunk_size, n_rows)
        yield df[start:end]


def check_memory_available(required_gb: float) -> bool:
    """
    Check if there's enough available memory.
    
    Args:
        required_gb: Required memory in GB
        
    Returns:
        bool: True if enough memory is available
    """
    try:
        import psutil
        available_gb = psutil.virtual_memory().available / (1024**3)
        return available_gb >= required_gb
    except ImportError:
        warnings.warn("psutil not installed, cannot check memory")
        return True  # Assume enough memory if we can't check


def get_system_info() -> Dict[str, str]:
    """
    Get system information for debugging.
    
    Returns:
        Dict[str, str]: System information
    """
    import platform
    
    return {
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "cpu_count": str(os.cpu_count()),
    }


def create_config_file(config_path: Union[str, Path], 
                      overwrite: bool = False) -> Path:
    """
    Create a default configuration file.
    
    Args:
        config_path: Path to config file
        overwrite: Overwrite existing file
        
    Returns:
        Path: Path to created config file
    """
    config_path = Path(config_path)
    
    if config_path.exists() and not overwrite:
        raise FileExistsError(f"Config file already exists: {config_path}")
    
    config_data = {
        "tool_versions": TOOL_VERSIONS,
        "urls": DEFAULT_CONFIG,
        "default_paths": {
            "reference_data": "pyTax4Fun2_ReferenceData",
            "temp_folder": "pyTax4Fun2_prediction",
            "user_data": "UserData"
        },
        "performance": {
            "num_threads": max(1, os.cpu_count() // 2),  # Use half of available cores
            "chunk_size": 10000,
            "max_memory_gb": 8  # Maximum memory to use in GB
        }
    }
    
    import json
    with open(config_path, 'w') as f:
        json.dump(config_data, f, indent=2)
    
    return config_path


def get_tool_path(tool_name: str, reference_data_path: Optional[Union[str, Path]] = None) -> Path:
    """
    Get path to external tool executable with improved discovery.
    
    Args:
        tool_name: Name of tool (prodigal, diamond, vsearch, blastn, makeblastdb)
        reference_data_path: Path to reference data directory
        
    Returns:
        Path: Path to tool executable
        
    Raises:
        pyTax4Fun2Error: If tool not found
    """
    ref_path = Path(reference_data_path) if reference_data_path else None
    tool_mgr = get_tool_manager(ref_path)
    
    tool_path = tool_mgr.find_tool(tool_name)
    
    if not tool_path:
        # Get helpful error message
        status = tool_mgr.verify_tool(tool_name)
        missing_tools = [tool_name]
        
        error_msg = [
            f"Tool not found: {tool_name}",
            f"Looked in: System PATH, {ref_path}/TOOLS/, common locations",
            "",
            "Installation options:",
            tool_mgr.suggest_installation(missing_tools),
            "",
            "Or manually download and place in:",
            f"  {ref_path}/TOOLS/{tool_name}_vX.X.X/" if ref_path else "  Your reference data TOOLS directory"
        ]
        
        raise pyTax4Fun2Error("\n".join(error_msg))
    
    return tool_path


def test_tool(tool_name_or_path: Union[str, Path], 
              reference_data_path: Optional[Union[str, Path]] = None) -> bool:
    """
    Test if a tool executable works.
    
    Args:
        tool_name_or_path: Tool name or path to executable
        reference_data_path: Path to reference data (if tool name provided)
        
    Returns:
        bool: True if tool works
    """
    import subprocess
    
    if isinstance(tool_name_or_path, Path) or Path(tool_name_or_path).exists():
        # It's a path
        tool_path = Path(tool_name_or_path)
    else:
        # It's a name, try to find it
        try:
            tool_path = get_tool_path(tool_name_or_path, reference_data_path)
        except pyTax4Fun2Error:
            return False
    
    try:
        # Try common help/version flags
        for flag in ["--version", "-version", "-v", "--help", "-h"]:
            try:
                result = subprocess.run(
                    [str(tool_path), flag],
                    capture_output=True,
                    text=True,
                    timeout=3,
                    shell=False
                )
                # If we get output or return code 0, tool is likely working
                if result.returncode == 0 or result.stdout or result.stderr:
                    return True
            except (subprocess.SubprocessError, FileNotFoundError):
                continue
        
        # If no flag worked, try running without arguments
        result = subprocess.run(
            [str(tool_path)],
            capture_output=True,
            text=True,
            timeout=2,
            shell=False
        )
        # Most tools will exit with error but still run
        return True
        
    except Exception:
        return False


def verify_all_tools(reference_data_path: Optional[Union[str, Path]] = None) -> Dict[str, Dict]:
    """
    Verify all required tools are available.
    
    Returns:
        Dict with status for each tool
    """
    ref_path = Path(reference_data_path) if reference_data_path else None
    tool_mgr = get_tool_manager(ref_path)
    return tool_mgr.get_all_tools_status()
    