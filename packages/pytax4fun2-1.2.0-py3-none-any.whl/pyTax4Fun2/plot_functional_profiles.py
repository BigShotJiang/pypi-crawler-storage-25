"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Visualization functions for functional profiles and KEGG pathways.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional, List, Dict, Union
import polars as pl

def plot_heatmap(
    functional_profiles: Union[str, Path, pl.DataFrame],
    output_file: Optional[str] = None,
    top_n_kos: int = 50,
    figsize: tuple = (12, 10),
    cluster_samples: bool = True,
    cluster_kos: bool = True,
    cmap: str = "viridis"
):
    """
    Create heatmap of KO abundances across samples.
    
    Args:
        functional_profiles: Path to functional prediction file or DataFrame
        output_file: Output file path (PNG, PDF, SVG)
        top_n_kos: Show only top N most abundant KOs
        figsize: Figure size (width, height)
        cluster_samples: Hierarchically cluster samples
        cluster_kos: Hierarchically cluster KOs
        cmap: Colormap for heatmap
    """
    # Read data
    if isinstance(functional_profiles, (str, Path)):
        df = pl.read_csv(functional_profiles, separator="\t")
    else:
        df = functional_profiles
    
    # Identify KO column and sample columns
    ko_col = df.columns[0] if df.columns[0].upper() in ['KO', 'KEGG', 'GENE'] else None
    if ko_col is None:
        ko_col = df.columns[0]  # Assume first column is KO
    
    # Get sample columns (numeric columns except KO and description)
    sample_cols = [c for c in df.columns if c not in [ko_col, 'description'] 
                   and df[c].dtype in [pl.Float64, pl.Float32, pl.Int64]]
    
    if not sample_cols:
        raise ValueError("No sample columns found")
    
    # Get top N KOs by total abundance
    ko_abundance = df.select([ko_col] + sample_cols).to_pandas()
    ko_abundance.set_index(ko_col, inplace=True)
    
    if len(ko_abundance) > top_n_kos:
        ko_abundance['total'] = ko_abundance.sum(axis=1)
        ko_abundance = ko_abundance.nlargest(top_n_kos, 'total').drop('total', axis=1)
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=figsize)
    
    # Cluster if requested
    if cluster_samples or cluster_kos:
        sns.clustermap(
            ko_abundance,
            method='average',
            col_cluster=cluster_samples,
            row_cluster=cluster_kos,
            cmap=cmap,
            figsize=figsize,
            cbar_pos=(0.02, 0.83, 0.03, 0.18),
            linewidths=0.5,
            xticklabels=True,
            yticklabels=True
        )
    else:
        sns.heatmap(
            ko_abundance,
            cmap=cmap,
            ax=ax,
            cbar_kws={'label': 'Relative Abundance'},
            linewidths=0.5,
            square=False
        )
        plt.title(f'Top {top_n_kos} KO Abundance Heatmap')
        plt.xlabel('Samples')
        plt.ylabel('KEGG Orthologs (KOs)')
        plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    
    import matplotlib
    if matplotlib.get_backend() != 'Agg':
        plt.show()
       
    return fig


def plot_functional_redundancy(
    fri_results: Dict,
    output_file: Optional[str] = None,
    figsize: tuple = (12, 8)
):
    """
    Visualize functional redundancy indices.
    
    Args:
        fri_results: Results from calculate_functional_redundancy()
        output_file: Output file path
        figsize: Figure size
    """
    abs_fri = fri_results['absolute_fri'].to_pandas()
    rel_fri = fri_results['relative_fri'].to_pandas()
    
    fig, axes = plt.subplots(2, 2, figsize=figsize)
    
    # 1. Distribution of absolute FRI
    axes[0, 0].hist(abs_fri.iloc[:, 1:-1].values.flatten(), bins=50, alpha=0.7)
    axes[0, 0].set_xlabel('Absolute FRI')
    axes[0, 0].set_ylabel('Frequency')
    axes[0, 0].set_title('Distribution of Absolute FRI')
    
    # 2. Distribution of relative FRI
    axes[0, 1].hist(rel_fri.iloc[:, 1:-1].values.flatten(), bins=50, alpha=0.7, color='orange')
    axes[0, 1].set_xlabel('Relative FRI')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].set_title('Distribution of Relative FRI')
    
    # 3. Boxplot of absolute FRI by sample
    abs_sample_data = abs_fri.iloc[:, 1:-1]
    axes[1, 0].boxplot(abs_sample_data.values, labels=abs_sample_data.columns)
    axes[1, 0].set_xlabel('Samples')
    axes[1, 0].set_ylabel('Absolute FRI')
    axes[1, 0].set_title('Absolute FRI by Sample')
    axes[1, 0].tick_params(axis='x', rotation=45)
    
    # 4. Unknown fractions pie chart
    unknown = fri_results['unknown_fractions']
    if unknown:
        labels = list(unknown.keys())
        values = list(unknown.values())
        axes[1, 1].pie(values, labels=labels, autopct='%1.1f%%')
        axes[1, 1].set_title('Unknown Fractions')
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    
    import matplotlib
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    
    return fig


def plot_pathway_abundance(
    pathway_predictions: Union[str, Path, pl.DataFrame],
    output_file: Optional[str] = None,
    top_n_pathways: int = 20,
    figsize: tuple = (14, 10)
):
    """
    Create bar plot of top pathway abundances.
    
    Args:
        pathway_predictions: Pathway prediction file or DataFrame
        output_file: Output file path
        top_n_pathways: Number of top pathways to show
        figsize: Figure size
    """
    # Read data
    if isinstance(pathway_predictions, (str, Path)):
        df = pl.read_csv(pathway_predictions, separator="\t")
    else:
        df = pathway_predictions
    
    # Identify pathway column and sample columns
    pathway_col = 'pathway' if 'pathway' in df.columns else df.columns[0]
    sample_cols = [c for c in df.columns if c not in [pathway_col, 'description'] 
                   and df[c].dtype in [pl.Float64, pl.Float32, pl.Int64]]
    
    # Convert to pandas for plotting
    pdf = df.select([pathway_col] + sample_cols).to_pandas()
    pdf.set_index(pathway_col, inplace=True)
    
    # Get top N pathways by total abundance
    pdf['total'] = pdf.sum(axis=1)
    pdf = pdf.nlargest(top_n_pathways, 'total').drop('total', axis=1)
    
    # Create grouped bar plot
    fig, ax = plt.subplots(figsize=figsize)
    
    x = np.arange(len(pdf))
    width = 0.8 / len(sample_cols)
    
    for i, sample in enumerate(sample_cols):
        offset = (i - len(sample_cols)/2 + 0.5) * width
        bars = ax.bar(x + offset, pdf[sample], width, label=sample)
    
    ax.set_xlabel('Pathways')
    ax.set_ylabel('Relative Abundance')
    ax.set_title(f'Top {top_n_pathways} Pathway Abundances')
    ax.set_xticks(x)
    ax.set_xticklabels(pdf.index, rotation=45, ha='right')
    ax.legend()
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')

    import matplotlib
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    
    return fig
