"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Extract 16S rRNA genes from genomes using BLAST against SILVA database.
"""

import subprocess
import warnings
from pathlib import Path
from typing import Optional, List, Tuple, Dict, Any
import polars as pl
import numpy as np

from .utils import (
    validate_file, validate_directory, get_tool_path, test_tool,
    normalize_extension, read_fasta_polars, write_fasta_polars,
    run_command, pyTax4Fun2Error, TOOL_VERSIONS, extract_sequences_from_fasta
)


def extract_ssu(
    genome_folder: str = "",
    genome_file: str = "",
    file_extension: str = "fasta",
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    use_vsearch: bool = False,
    num_threads: int = 1,
    chunk_size: int = 10000
) -> None:
    """
    Extract 16S rRNA genes from genomes using BLAST against SILVA database.
    
    Args:
        genome_folder: Path to folder containing genome files
        genome_file: Path to a single genome file
        file_extension: File extension of genome files
        path_to_reference_data: Path to reference data
        use_vsearch: Use VSEARCH instead of BLAST (not implemented)
        num_threads: Number of threads for BLAST
        chunk_size: Size of chunks for processing large genomes
        
    Returns:
        None. Writes _16SrRNA.ffn files for each genome.
        
    Raises:
        pyTax4Fun2Error: If inputs are invalid or extraction fails
    """
    # Validate inputs
    if not file_extension:
        raise pyTax4Fun2Error("File extension must be specified")
    
    if genome_folder and genome_file:
        raise pyTax4Fun2Error("Specify either genome_folder OR genome_file, not both")
    
    if not genome_folder and not genome_file:
        raise pyTax4Fun2Error("Either genome_folder or genome_file must be specified")
    
    if num_threads < 1:
        raise pyTax4Fun2Error("num_threads must be >= 1")
    
    file_extension = normalize_extension(file_extension)
    ref_path = Path(path_to_reference_data)
    validate_directory(ref_path, "Reference data directory")
    
    # Get BLAST binaries
    try:
        blast_path = get_tool_path("blastn", path_to_reference_data)
        makeblastdb_path = get_tool_path("makeblastdb", path_to_reference_data)
    except Exception as e:
        raise pyTax4Fun2Error(f"Failed to get BLAST tools: {str(e)}")
    
    # Test tools
    if not test_tool(blast_path):
        raise pyTax4Fun2Error(f"blastn not executable: {blast_path}")
    if not test_tool(makeblastdb_path):
        raise pyTax4Fun2Error(f"makeblastdb not executable: {makeblastdb_path}")
    
    # Check SILVA database
    silva_db = ref_path / "SILVA" / "SILVA_132_SSURef_NR90.fasta"
    if not silva_db.exists():
        # Try alternative naming
        silva_candidates = list(ref_path.glob("SILVA/**/*.fasta")) + \
                          list(ref_path.glob("SILVA/**/*.fa"))
        if silva_candidates:
            silva_db = silva_candidates[0]
            print(f"Using SILVA database: {silva_db.name}")
        else:
            raise pyTax4Fun2Error(f"SILVA database not found in: {ref_path / 'SILVA'}")
    
    # ============= MODIFIED SECTION: Check for BLAST database with both naming conventions =============
    # Build BLAST database if needed
    db_extensions = ['.nsq', '.nin', '.nhr', '.ndb', '.nog', '.nos', '.not']
    
    # Check for database files with .fasta suffix (code's expected naming)
    db_files_with_fasta = [silva_db.with_suffix(ext) for ext in db_extensions]
    
    # Check for database files without .fasta suffix (BLAST's default naming)
    silva_base = ref_path / "SILVA" / "SILVA_132_SSURef_NR90"
    db_files_without_fasta = [Path(str(silva_base) + ext) for ext in db_extensions]
    
    # Also check for files with .fasta. prefix (alternative naming)
    db_files_with_fasta_dot = [ref_path / "SILVA" / f"SILVA_132_SSURef_NR90.fasta{ext}" for ext in db_extensions]
    
    # Check if any database files exist
    db_exists = (any(f.exists() for f in db_files_with_fasta) or 
                 any(f.exists() for f in db_files_without_fasta) or
                 any(f.exists() for f in db_files_with_fasta_dot))
    
    if not db_exists:
        print("Building BLAST database from SILVA sequences...")
        cmd = [
            str(makeblastdb_path), '-dbtype', 'nucl',
            '-in', str(silva_db)
        ]
        returncode, stdout, stderr = run_command(cmd, verbose=False)
        if returncode != 0:
            raise pyTax4Fun2Error(f"Failed to create BLAST database: {stderr}")
        
        # Verify database creation
        if not any(f.exists() for f in db_files_with_fasta[:3]):
            raise pyTax4Fun2Error("Failed to create BLAST database files")
        print("BLAST database created successfully")
    else:
        print("BLAST database already exists")
    # ============= END MODIFIED SECTION =============
    
    # Get list of genome files
    if genome_file:
        validate_file(genome_file, "Genome file")
        genome_list = [Path(genome_file)]
    else:
        validate_directory(genome_folder, "Genome folder")
        genome_path = Path(genome_folder)
        
        # Try multiple extension patterns
        genome_list = list(genome_path.glob(f"*{file_extension}"))
        if not genome_list:
            # Try without dot
            genome_list = list(genome_path.glob(f"*{file_extension.lstrip('.')}"))
        if not genome_list:
            # Try common variants
            for ext in [file_extension, f".{file_extension}", f".{file_extension.lstrip('.')}"]:
                genome_list = list(genome_path.glob(f"*{ext}"))
                if genome_list:
                    break
        
        if not genome_list:
            raise pyTax4Fun2Error(
                f"No files found with extension '{file_extension}' in {genome_folder}. "
                f"Files found: {list(genome_path.glob('*'))[:10]}..."
            )
    
    # Process each genome
    # Process each genome
    total_genomes = len(genome_list)
    print(f"Processing {total_genomes} genome(s)...")
    
    for idx, genome in enumerate(genome_list, 1):
        print(f"[{idx}/{total_genomes}] Processing: {genome.name}")
        
        # ============= FIX: Handle output filename correctly =============
        # Get the stem (filename without any extensions)
        # e.g., "Methanosarcina_barkeri_MS.fasta" -> "Methanosarcina_barkeri_MS"
        stem = genome.stem
        base_name = genome.parent / stem
        blast_file = base_name.with_suffix(".blast")
        output_file = genome.parent / f"{stem}_16SrRNA.ffn"
        # ============= END FIX =============
        
        try:
            # Run BLAST with optimized parameters
            # Determine which database path to use (try to find existing one)
            blast_db = str(silva_db)
            
            # Check which naming convention exists
            if any(f.exists() for f in db_files_without_fasta):
                blast_db = str(silva_base)
            elif any(f.exists() for f in db_files_with_fasta_dot):
                blast_db = str(ref_path / "SILVA" / "SILVA_132_SSURef_NR90.fasta")
            
            blast_cmd = [
                str(blast_path), '-db', blast_db,
                '-query', str(genome),
                '-evalue', '1e-10',
                '-num_threads', str(num_threads),
                '-max_target_seqs', '10',  # Limit to top hits
                '-outfmt', '6',
                '-out', str(blast_file)
            ]
            
            returncode, stdout, stderr = run_command(blast_cmd, verbose=False)
            if returncode != 0:
                warnings.warn(f"BLAST command had non-zero exit for {genome.name}: {stderr}")
            
            # Process BLAST results if file exists and has content
            if not blast_file.exists() or blast_file.stat().st_size == 0:
                warnings.warn(f"No BLAST hits for: {genome.name}")
                continue
            
            # Read and process BLAST results using efficient method
            extract_regions_from_blast_polars(
                blast_file=blast_file,
                genome_file=genome,
                output_file=output_file,
                min_alignment_length=300,
                chunk_size=chunk_size
            )
            
            # Clean up BLAST file
            if blast_file.exists():
                blast_file.unlink()
                
        except Exception as e:
            warnings.warn(f"Error processing {genome.name}: {str(e)}")
            # Clean up on error
            if blast_file.exists():
                blast_file.unlink()
            continue
    
    print("16S rRNA extraction complete")


def extract_regions_from_blast_polars(
    blast_file: Path,
    genome_file: Path,
    output_file: Path,
    min_alignment_length: int = 300,
    chunk_size: int = 10000
) -> None:
    """
    Extract genomic regions based on BLAST hits using polars_bio.
    
    Args:
        blast_file: Path to BLAST output file
        genome_file: Path to genome FASTA file
        output_file: Output FASTA file for extracted sequences
        min_alignment_length: Minimum alignment length to consider
        chunk_size: Chunk size for processing large genomes
        
    Returns:
        None. Writes extracted sequences to output file.
    """
    # Read BLAST results
    try:
        blast_df = pl.read_csv(
            blast_file,
            separator="\t",
            has_header=False,
            new_columns=["qseqid", "sseqid", "pident", "length", 
                        "mismatch", "gapopen", "qstart", "qend",
                        "sstart", "send", "evalue", "bitscore"]
        )
    except Exception as e:
        warnings.warn(f"Error reading BLAST file {blast_file}: {str(e)}")
        return
    
    # Filter by alignment length
    blast_df = blast_df.filter(pl.col("length") >= min_alignment_length)
    
    if blast_df.is_empty():
        warnings.warn(f"No significant BLAST hits (>={min_alignment_length} bp)")
        return
    
    # Group hits by contig and merge overlapping regions
    regions = merge_blast_hits_polars(blast_df)
    
    if not regions:
        warnings.warn("No valid regions extracted")
        return
    
    # Extract sequences using efficient method
    extract_sequences_by_regions(
        genome_file=genome_file,
        regions=regions,
        output_file=output_file,
        min_alignment_length=min_alignment_length
    )


def merge_blast_hits_polars(blast_df: pl.DataFrame) -> List[Tuple[str, int, int]]:
    """
    Merge overlapping BLAST hits into non-overlapping regions using Polars.
    
    Args:
        blast_df: BLAST results DataFrame
        
    Returns:
        List[Tuple[str, int, int]]: List of (contig, start, end) regions
    """
    if blast_df.is_empty():
        return []
    
    # Calculate start and end positions
    blast_df = blast_df.with_columns(
        pl.when(pl.col("sstart") < pl.col("send"))
        .then(pl.col("sstart"))
        .otherwise(pl.col("send"))
        .alias("start"),
        pl.when(pl.col("sstart") > pl.col("send"))
        .then(pl.col("sstart"))
        .otherwise(pl.col("send"))
        .alias("end")
    )
    
    # Sort by contig and start position
    blast_df = blast_df.sort(["qseqid", "start"])
    
    merged_regions = []
    
    # Process each contig separately using Polars group_by
    for contig in blast_df["qseqid"].unique().to_list():
        contig_hits = blast_df.filter(pl.col("qseqid") == contig)
        
        if contig_hits.is_empty():
            continue
        
        # Initialize with first hit
        current_start = contig_hits[0, "start"]
        current_end = contig_hits[0, "end"]
        
        # Iterate through hits for this contig
        for row in contig_hits.iter_rows(named=True):
            hit_start = row["start"]
            hit_end = row["end"]
            
            # Check for overlap (allow some gap)
            if hit_start <= current_end + 100:  # Allow 100bp gap
                current_end = max(current_end, hit_end)
            else:
                # No overlap, save current region and start new one
                merged_regions.append((contig, current_start, current_end))
                current_start = hit_start
                current_end = hit_end
        
        # Save last region
        merged_regions.append((contig, current_start, current_end))
    
    return merged_regions


def extract_sequences_by_regions(
    genome_file: Path,
    regions: List[Tuple[str, int, int]],
    output_file: Path,
    min_alignment_length: int = 300
) -> None:
    """
    Extract sequences from genome based on regions using efficient methods.
    
    Args:
        genome_file: Path to genome FASTA file
        regions: List of (contig, start, end) regions
        output_file: Output FASTA file
        min_alignment_length: Minimum sequence length
    """
    # Group regions by contig for efficient extraction
    regions_by_contig = {}
    for contig, start, end in regions:
        if contig not in regions_by_contig:
            regions_by_contig[contig] = []
        regions_by_contig[contig].append((start, end))
    
    # Read genome in streaming mode for efficiency
    extracted_data = []
    seq_count = 0
    
    # Process each contig
    for contig, region_list in regions_by_contig.items():
        # Extract this contig's sequence
        contig_df = extract_sequences_from_fasta(
            filepath=genome_file,
            seq_ids=[contig]
        )
        
        if contig_df.is_empty():
            warnings.warn(f"Contig not found in genome: {contig}")
            continue
        
        contig_sequence = contig_df[0, "sequence"]
        seq_length = len(contig_sequence)
        
        # Extract each region from this contig
        for start, end in region_list:
            # Validate coordinates
            if start < 1 or end > seq_length or start > end:
                warnings.warn(f"Invalid coordinates for {contig}: {start}-{end} (length: {seq_length})")
                continue
            
            # Extract subsequence (0-based indexing for Python)
            subseq = contig_sequence[start-1:end]
            
            if len(subseq) < min_alignment_length:
                warnings.warn(f"Extracted sequence too short: {len(subseq)} bp")
                continue
            
            # Store extracted sequence
            seq_count += 1
            extracted_data.append({
                'id': f"{output_file.stem}_16S_{seq_count}",
                'description': f"extracted from {contig}:{start}-{end}",
                'sequence': subseq
            })
    
    if extracted_data:
        # Write all extracted sequences at once
        extracted_df = pl.DataFrame(extracted_data)
        write_fasta_polars(extracted_df, output_file)
        print(f"  -> Extracted {len(extracted_data)} 16S sequences to: {output_file.name}")
    else:
        warnings.warn("No valid sequences extracted")


def extract_ssu_batch_polars(
    genome_files: List[Path],
    silva_db: Path,
    output_dir: Path,
    threads: int = 1,
    min_identity: float = 97.0,
    min_coverage: float = 80.0,
    chunk_size: int = 10000
) -> Dict[Path, Path]:
    """
    Extract 16S rRNA genes from multiple genomes in batch mode using polars_bio.
    
    Args:
        genome_files: List of genome FASTA files
        silva_db: Path to SILVA database
        output_dir: Output directory for extracted sequences
        threads: Number of threads for parallel processing
        min_identity: Minimum identity percentage
        min_coverage: Minimum coverage percentage
        chunk_size: Chunk size for processing
        
    Returns:
        Dict[Path, Path]: Mapping from input genomes to output files
    """
    import concurrent.futures
    from functools import partial
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Prepare function with fixed arguments
    extract_func = partial(
        _extract_single_genome_polars,
        silva_db=silva_db,
        output_dir=output_dir,
        min_identity=min_identity,
        min_coverage=min_coverage,
        chunk_size=chunk_size
    )
    
    # Process in parallel
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
        future_to_genome = {
            executor.submit(extract_func, genome): genome 
            for genome in genome_files
        }
        
        for future in concurrent.futures.as_completed(future_to_genome):
            genome = future_to_genome[future]
            try:
                output_file = future.result()
                results[genome] = output_file
                print(f"Completed: {genome.name} -> {output_file.name}")
            except Exception as e:
                warnings.warn(f"Failed to extract from {genome.name}: {str(e)}")
                results[genome] = None
    
    return results


def _extract_single_genome_polars(
    genome_file: Path,
    silva_db: Path,
    output_dir: Path,
    min_identity: float,
    min_coverage: float,
    chunk_size: int
) -> Path:
    """
    Helper function to extract 16S from a single genome using polars_bio.
    """
    # Generate output filename
    output_file = output_dir / f"{genome_file.stem}_16S.fasta"
    
    # Run BLAST
    blast_file = output_dir / f"{genome_file.stem}.blast"
    
    # Get BLAST path
    try:
        blast_path = get_tool_path("blastn", "pyTax4Fun2_ReferenceData")
    except:
        blast_path = "blastn"
    
    blast_cmd = [
        str(blast_path), "-db", str(silva_db),
        "-query", str(genome_file),
        "-evalue", "1e-10",
        "-perc_identity", str(min_identity),
        "-qcov_hsp_perc", str(min_coverage),
        "-outfmt", "6",
        "-out", str(blast_file)
    ]
    
    subprocess.run(blast_cmd, capture_output=True, check=True, shell=False)
    
    # Process results
    if blast_file.exists() and blast_file.stat().st_size > 0:
        extract_regions_from_blast_polars(
            blast_file=blast_file,
            genome_file=genome_file,
            output_file=output_file,
            min_alignment_length=300,
            chunk_size=chunk_size
        )
    
    # Clean up
    if blast_file.exists():
        blast_file.unlink()
    
    return output_file


def validate_16s_sequences_polars(
    sequences_df: pl.DataFrame,
    min_length: int = 1200,
    max_length: int = 1800,
    gc_range: Tuple[float, float] = (40.0, 60.0)
) -> Tuple[pl.DataFrame, pl.DataFrame]:
    """
    Validate extracted 16S sequences based on length and GC content.
    
    Args:
        sequences_df: DataFrame with sequence data
        min_length: Minimum sequence length
        max_length: Maximum sequence length
        gc_range: Acceptable GC content range (min, max)
        
    Returns:
        Tuple[pl.DataFrame, pl.DataFrame]: (valid_sequences, invalid_sequences)
    """
    if sequences_df.is_empty():
        return pl.DataFrame(), pl.DataFrame()
    
    # Calculate sequence lengths
    sequences_df = sequences_df.with_columns(
        pl.col("sequence").str.len_bytes().alias("length")
    )
    
    # Calculate GC content using polars string operations
    sequences_df = sequences_df.with_columns(
        (pl.col("sequence").str.count_matches(r"[GCgc]") / pl.col("length") * 100)
        .alias("gc_percent")
    )
    
    # Apply validation criteria
    valid_mask = (
        (pl.col("length") >= min_length) &
        (pl.col("length") <= max_length) &
        (pl.col("gc_percent") >= gc_range[0]) &
        (pl.col("gc_percent") <= gc_range[1])
    )
    
    # Split into valid and invalid
    valid_df = sequences_df.filter(valid_mask).drop(["length", "gc_percent"])
    invalid_df = sequences_df.filter(~valid_mask)
    
    # Add rejection reasons to invalid sequences
    if not invalid_df.is_empty():
        rejection_reasons = []
        
        for row in invalid_df.iter_rows(named=True):
            reasons = []
            if row["length"] < min_length or row["length"] > max_length:
                reasons.append(f"length={row['length']}")
            if row["gc_percent"] < gc_range[0] or row["gc_percent"] > gc_range[1]:
                reasons.append(f"GC={row['gc_percent']:.1f}%")
            
            rejection_reasons.append(f"rejected: {', '.join(reasons)}")
        
        invalid_df = invalid_df.with_columns(
            pl.Series("rejection_reason", rejection_reasons)
        )
        invalid_df = invalid_df.with_columns(
            (pl.col("description") + " | " + pl.col("rejection_reason")).alias("description")
        ).drop(["length", "gc_percent", "rejection_reason"])
    
    return valid_df, invalid_df


def cluster_16s_sequences_polars(
    sequences_df: pl.DataFrame,
    output_dir: Path,
    similarity: float = 0.97,
    threads: int = 1
) -> Dict[str, pl.DataFrame]:
    """
    Cluster 16S sequences to remove redundancy using VSEARCH.
    
    Args:
        sequences_df: DataFrame with sequence data
        output_dir: Output directory
        similarity: Clustering similarity threshold
        threads: Number of threads
        
    Returns:
        Dict[str, pl.DataFrame]: Dictionary of cluster_id -> sequences DataFrame
    """
    from .utils import get_tool_path
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Write sequences to a file
    input_file = output_dir / "all_16s.fasta"
    write_fasta_polars(sequences_df, input_file)
    
    # Get VSEARCH path
    try:
        vsearch_path = get_tool_path("vsearch", "pyTax4Fun2_ReferenceData")
    except:
        # Try system vsearch
        vsearch_path = "vsearch"
    
    # Run clustering
    uc_file = output_dir / "clusters.uc"
    centroids_file = output_dir / "centroids.fasta"
    
    vsearch_cmd = [
        str(vsearch_path),
        "--cluster_fast", str(input_file),
        "--id", str(similarity),
        "--centroids", str(centroids_file),
        "--uc", str(uc_file),
        "--threads", str(threads)
    ]
    
    returncode, stdout, stderr = run_command(vsearch_cmd, verbose=False)
    if returncode != 0:
        raise pyTax4Fun2Error(f"VSEARCH clustering failed: {stderr}")
    
    # Parse clustering results
    clusters = parse_uc_file_polars(uc_file, sequences_df)
    
    return clusters


def parse_uc_file_polars(
    uc_file: Path,
    sequences_df: pl.DataFrame
) -> Dict[str, pl.DataFrame]:
    """
    Parse VSEARCH UC file and group sequences by cluster.
    
    Args:
        uc_file: Path to UC file
        sequences_df: Original sequence DataFrame
        
    Returns:
        Dict[str, pl.DataFrame]: Cluster assignments
    """
    # Read UC file
    try:
        uc_df = pl.read_csv(
            uc_file,
            separator="\t",
            has_header=False,
            new_columns=[
                "type", "cluster", "size", "percent_similarity", "strand",
                "qlo", "qhi", "tlo", "thi", "query", "target"
            ]
        )
    except Exception as e:
        raise pyTax4Fun2Error(f"Error reading UC file: {str(e)}")
    
    # Filter for cluster records (type H or S)
    cluster_data = uc_df.filter(pl.col("type").is_in(["H", "S"]))
    
    if cluster_data.is_empty():
        return {}
    
    # Create mapping from sequence ID to cluster
    seq_to_cluster = {}
    for row in cluster_data.iter_rows(named=True):
        seq_to_cluster[row["query"]] = row["cluster"]
    
    # Add cluster information to sequences
    sequences_df = sequences_df.with_columns(
        pl.col("id").map_dict(seq_to_cluster, default=None).alias("cluster_id")
    )
    
    # Group by cluster
    clusters = {}
    for cluster_id in sequences_df["cluster_id"].unique().to_list():
        if cluster_id is not None:
            cluster_df = sequences_df.filter(pl.col("cluster_id") == cluster_id)
            clusters[cluster_id] = cluster_df.drop("cluster_id")
    
    return clusters
    