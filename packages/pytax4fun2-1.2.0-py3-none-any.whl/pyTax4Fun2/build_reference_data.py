"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Build the pyTax4Fun2 reference database.
"""

import os
import sys
import shutil
import zipfile
import tempfile
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import warnings

import polars as pl
import requests
from tqdm import tqdm

from .utils import (
    validate_directory, download_with_checksum, calculate_md5,
    run_command, pyTax4Fun2Error, setup_logging
)


def build_reference_data(
    path_to_working_directory: str = ".",
    use_force: bool = False,
    install_suggested_packages: bool = False,  # Default to False now
    show_progress: bool = True,
    skip_checksum_verification: bool = False,
    resume: bool = True
) -> str:
    """
    Build the pyTax4Fun2 reference database.
    
    Args:
        path_to_working_directory: Working directory for download
        use_force: Overwrite existing data (DANGEROUS - will delete everything!)
        install_suggested_packages: Install required Python packages
        show_progress: Show download progress
        skip_checksum_verification: Skip MD5 checksum verification
        resume: Resume download by checking existing files (default: True)
        
    Returns:
        str: Path to reference data directory
    """
    # Setup logging
    setup_logging()
    
    # Define paths
    working_dir = Path(path_to_working_directory)
    validate_directory(working_dir, create=True, writable=True)
    
    # Use the correct directory name
    path_to_reference_data = working_dir / "pyTax4Fun2_ReferenceData"
    
    # IMPORTANT: Only remove if use_force is True AND user really wants to
    if path_to_reference_data.exists() and use_force:
        print(f"⚠ WARNING: Force mode enabled. This will DELETE: {path_to_reference_data}")
        response = input("Are you sure you want to delete everything and start over? (y/N): ").lower()
        if response == 'y':
            print(f"Removing existing reference data directory: {path_to_reference_data}")
            shutil.rmtree(path_to_reference_data)
        else:
            print("Force mode cancelled. Using existing directory.")
            use_force = False
    
    # Create directory if it doesn't exist (never delete without force)
    path_to_reference_data.mkdir(parents=True, exist_ok=True)
    print(f"Using reference data directory: {path_to_reference_data}")
    
    # Define download components with correct checksums
    components = [
        {
            "name": "KEGG",
            "url": "https://zenodo.org/records/19020935/files/KEGG.zip",
            "md5": "854d2c4534e56fafe920f23fc9e27d45",
            "zip_file": "KEGG.zip",
            "extract_dir": "KEGG",
            "expected_files": ["ko.txt", "ko2ptw.txt", "prokaryotes.dmnd", "ptw.txt"]
        },
        {
            "name": "Ref99NR",
            "url": "https://zenodo.org/records/19020935/files/Ref99NR.zip",
            "md5": "ade0ba49289fc87947305d68651f5ee3",
            "zip_file": "Ref99NR.zip",
            "extract_dir": "Ref99NR",
            "expected_files": ["Ref99NR.fasta", "Ref99NR.tre"]
        },
        {
            "name": "Ref100NR",
            "url": "https://zenodo.org/records/19020935/files/Ref100NR.zip",
            "md5": "3f45477da3cfa9a10454fcf7faed633f",
            "zip_file": "Ref100NR.zip",
            "extract_dir": "Ref100NR",
            "expected_files": ["Ref100NR.fasta", "Ref100NR.tre"]
        },
        {
            "name": "SILVA",
            "url": "https://zenodo.org/records/19020935/files/SILVA.zip",
            "md5": "a8ec15a70066e51bb249ecf14382bbc6",
            "zip_file": "SILVA.zip",
            "extract_dir": "SILVA",
            "expected_files": ["SILVA_132_SSURef_NR90.fasta"]
        },
        {
            "name": "TOOLS",
            "url": "https://zenodo.org/records/19020935/files/TOOLS.zip",
            "md5": "eb719b85f441cb96dc377de743338c03",
            "zip_file": "TOOLS.zip",
            "extract_dir": "TOOLS",
            "expected_files": []
        }
    ]
        
    # Track what needs to be done
    all_complete = True
    components_to_download = []
    
    # Check each component
    print("\nChecking existing components...")
    for comp in components:
        component_dir = path_to_reference_data / comp["extract_dir"]
        zip_path = path_to_reference_data / comp["zip_file"]
        
        # Check if component is already extracted and valid
        if component_dir.exists():
            expected_files = [component_dir / f for f in comp.get("expected_files", [])]
            if expected_files and all(f.exists() for f in expected_files):
                print(f"  ✓ {comp['name']}: already installed and complete")
                continue
            elif expected_files:
                print(f"  ⚠ {comp['name']}: directory exists but incomplete")
                all_complete = False
                components_to_download.append(comp)
            else:
                # No expected files list, just check if directory has contents
                if any(component_dir.iterdir()):
                    print(f"  ✓ {comp['name']}: already installed")
                    continue
                else:
                    print(f"  ⚠ {comp['name']}: empty directory")
                    all_complete = False
                    components_to_download.append(comp)
        else:
            print(f"  ✗ {comp['name']}: not installed")
            all_complete = False
            components_to_download.append(comp)
    
    # If everything is complete, we're done
    if all_complete:
        print("\n✓ All components are already installed and complete!")
    else:
        # Download missing components
        print(f"\nNeed to download {len(components_to_download)} component(s)")
        
        for i, comp in enumerate(components_to_download, 1):
            print(f"\n[{i}/{len(components_to_download)}] Processing {comp['name']}...")
            
            zip_path = path_to_reference_data / comp["zip_file"]
            component_dir = path_to_reference_data / comp["extract_dir"]
            
            # Check if zip file already exists
            if zip_path.exists() and not use_force:
                print(f"  Zip file already exists: {zip_path.name}")
                
                # Verify zip file integrity if checksum available
                if not skip_checksum_verification and comp.get("md5"):
                    print(f"  Verifying existing zip file...")
                    actual_md5 = calculate_md5(zip_path)
                    if actual_md5 == comp["md5"]:
                        print(f"  ✓ Zip file is valid")
                    else:
                        print(f"  ⚠ Zip file is corrupted (MD5 mismatch)")
                        print(f"    Expected: {comp['md5']}")
                        print(f"    Got: {actual_md5}")
                        print(f"    Re-downloading...")
                        zip_path.unlink()  # Remove corrupted file
                        # Download fresh copy
                        expected_md5 = None if skip_checksum_verification else comp["md5"]
                        download_with_checksum(
                            url=comp["url"],
                            destfile=zip_path,
                            expected_md5=expected_md5,
                            show_progress=show_progress
                        )
            else:
                # Download the zip file
                print(f"  Downloading {comp['name']}...")
                expected_md5 = None if skip_checksum_verification else comp["md5"]
                download_with_checksum(
                    url=comp["url"],
                    destfile=zip_path,
                    expected_md5=expected_md5,
                    show_progress=show_progress
                )
            
            # Extract the zip file (always extract if directory doesn't exist or is incomplete)
            if not component_dir.exists() or not all((component_dir / f).exists() for f in comp.get("expected_files", [])):
                print(f"  Extracting {comp['name']}...")
                
                # Create component directory if it doesn't exist
                component_dir.mkdir(exist_ok=True)
                
                # Extract zip file
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    file_list = zip_ref.namelist()
                    if show_progress:
                        from tqdm import tqdm
                        for file in tqdm(file_list, desc=f"Extracting {comp['name']}"):
                            zip_ref.extract(file, path_to_reference_data)
                    else:
                        zip_ref.extractall(path_to_reference_data)
                
                print(f"  ✓ {comp['name']} extracted successfully")
            else:
                print(f"  ✓ {comp['name']} already extracted")
            
            # Optionally remove zip file after successful extraction
            # Keep it by default in case user wants to verify later
            # zip_path.unlink()  # Uncomment if you want to delete zips
    
    # Validate the installation
    print("\nValidating reference data installation...")
    try:
        test_result = test_reference_data(str(path_to_reference_data))
        
        if test_result["success"]:
            print("✓ All files validated successfully")
        else:
            print("⚠ Some files failed validation. Check the installation.")
            if test_result.get("failed"):
                print(f"  Issues found: {len(test_result['failed'])}")
                if len(test_result['failed']) <= 10:
                    for item in test_result['failed']:
                        print(f"    - {item}")
    except Exception as e:
        print(f"⚠ Validation skipped: {str(e)}")
    
    # Skip Python package installation (handled by other commands)
    if install_suggested_packages:
        print("\nNote: Python package installation is now handled by separate commands.")
        print("Use 'pyTax4Fun2cli install-deps' for dependencies.")
    
    print("\n" + "="*50)
    print("pyTax4Fun2 reference data operation complete!")
    print(f"Reference data path: {path_to_reference_data}")
    print("="*50)
    
    return str(path_to_reference_data)


# DEPRECATED: Test connectivity deprecated
# def test_reference_data(
    # path_to_reference_data: str = "pyTax4Fun2_ReferenceData"
# ) -> Dict:
    # """
    # Test reference data integrity.
    
    # Args:
        # path_to_reference_data: Path to reference data directory
        
    # Returns:
        # Dict: Test results with keys: success, failed, message
    # """
    # ref_path = Path(path_to_reference_data)
    
    # if not ref_path.exists():
        # return {
            # "success": False,
            # "failed": [],
            # "message": f"Reference data directory not found: {ref_path}"
        # }
    
    # Download file list with checksums
    # list_url = "https://cloudstor.aarnet.edu.au/plus/s/EpS8jMFeLlbueyM/download"
    # list_file = ref_path / "fileList.txt"
    
    # try:
        # # Download file list
        # response = requests.get(list_url)
        # response.raise_for_status()
        
        # with open(list_file, 'wb') as f:
            # f.write(response.content)
        
        # if not list_file.exists():
            # return {
                # "success": False,
                # "failed": [],
                # "message": "Failed to download file list"
            # }
        
        # # Read file list (tab-separated: filename, md5sum)
        # # The file might have different formats, try to parse it
        # file_data = []
        # with open(list_file, 'r') as f:
            # for line in f:
                # line = line.strip()
                # if line and not line.startswith("#"):
                    # parts = line.split()
                    # if len(parts) >= 2:
                        # filename = parts[0]
                        # md5sum = parts[1]
                        # file_data.append((filename, md5sum))
        
        # # Remove temporary file
        # list_file.unlink()
        
        # # Validate each file
        # failed_files = []
        
        # for filename, expected_md5 in tqdm(file_data, desc="Validating files"):
            # filepath = ref_path / filename
            # print(f"Checking {filename:60}", end="")
            
            # if not filepath.exists():
                # print(" MISSING")
                # failed_files.append(filename)
            # else:
                # try:
                    # actual_md5 = calculate_md5(filepath)
                    # if actual_md5 == expected_md5:
                        # print(" OK")
                    # else:
                        # print(" CORRUPTED")
                        # failed_files.append(filename)
                # except Exception as e:
                    # print(f" ERROR: {str(e)}")
                    # failed_files.append(filename)
        
        # if not failed_files:
            # return {
                # "success": True,
                # "failed": [],
                # "message": "All files validated successfully"
            # }
        # else:
            # return {
                # "success": False,
                # "failed": failed_files,
                # "message": f"{len(failed_files)} files failed validation"
            # }
        
    # except Exception as e:
        # return {
            # "success": False,
            # "failed": [],
            # "message": str(e)
        # }


def test_reference_data(ref_path):
    """
    Simple test function for reference data.
    
    Args:
        ref_path: Path to reference data directory
        
    Returns:
        Dict with test results
    """
    ref_path = Path(ref_path)
    
    if not ref_path.exists():
        return {
            "success": False,
            "failed": [],
            "message": f"Reference data directory not found: {ref_path}"
        }
    
    # Check required directories
    required_dirs = ["KEGG", "Ref99NR", "Ref100NR", "SILVA", "TOOLS"]
    missing_dirs = []
    
    for dir_name in required_dirs:
        if not (ref_path / dir_name).exists():
            missing_dirs.append(dir_name)
    
    if missing_dirs:
        return {
            "success": False,
            "failed": missing_dirs,
            "message": f"Missing directories: {', '.join(missing_dirs)}"
        }
    
    # Check some key files
    key_files = [
        "KEGG/ko.txt",
        "KEGG/prokaryotes.dmnd",
        "Ref99NR/Ref99NR.fasta",
        "Ref100NR/Ref100NR.fasta",
        "SILVA/SILVA_132_SSURef_NR90.fasta"
    ]
    
    missing_files = []
    for file in key_files:
        if not (ref_path / file).exists():
            missing_files.append(file)
    
    if missing_files:
        return {
            "success": False,
            "failed": missing_files,
            "message": f"Missing files: {', '.join(missing_files)}"
        }
    
    return {
        "success": True,
        "failed": [],
        "message": "All required directories and key files found"
    }


def install_suggested_packages_func():
    """Install suggested Python packages."""
    import subprocess
    import sys
    
    required_packages = [
        "polars>=0.20.0",
        "numpy>=1.21.0",
        "biopython>=1.79",
        "requests>=2.28.0",
        "tqdm>=4.64.0"
    ]
    
    print("\nInstalling suggested Python packages...")
    
    for pkg in required_packages:
        try:
            import importlib
            pkg_name = pkg.split(">=")[0].split("[")[0]
            importlib.import_module(pkg_name)
            print(f"  ✓ {pkg_name} already installed")
        except ImportError:
            print(f"  Installing {pkg}...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
                print(f"  ✓ {pkg} installed")
            except Exception as e:
                print(f"  ⚠ Failed to install {pkg}: {str(e)}")


def check_disk_space(path: Path, required_gb: float = 10.0) -> bool:
    """
    Check if there's enough disk space.
    
    Args:
        path: Path to check disk space
        required_gb: Required space in GB
        
    Returns:
        bool: True if enough space
    """
    try:
        import shutil
        total, used, free = shutil.disk_usage(path)
        free_gb = free / (1024**3)
        
        if free_gb < required_gb:
            warnings.warn(
                f"Low disk space: {free_gb:.1f} GB free, "
                f"{required_gb:.1f} GB required at {path}"
            )
            return False
        return True
    except Exception:
        # If we can't check, assume it's OK
        return True


def download_component_parallel(
    components: List[Dict],
    output_dir: Path,
    max_workers: int = 3,
    show_progress: bool = True
) -> Dict[str, bool]:
    """
    Download multiple components in parallel.
    
    Args:
        components: List of component dictionaries
        output_dir: Output directory
        max_workers: Maximum number of parallel downloads
        show_progress: Show progress bars
        
    Returns:
        Dict[str, bool]: Dictionary mapping component names to success status
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    
    results = {}
    
    def download_single(comp: Dict) -> Tuple[str, bool]:
        """Download a single component."""
        try:
            zip_path = output_dir / comp["zip_file"]
            download_with_checksum(
                url=comp["url"],
                destfile=zip_path,
                expected_md5=comp["md5"],
                show_progress=False  # Don't show nested progress bars
            )
            
            # Extract
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(output_dir)
            
            # Clean up
            zip_path.unlink()
            
            return comp["name"], True
        except Exception as e:
            warnings.warn(f"Failed to download {comp['name']}: {str(e)}")
            return comp["name"], False
    
    # Download in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all download tasks
        future_to_name = {
            executor.submit(download_single, comp): comp["name"]
            for comp in components
        }
        
        # Process results as they complete
        if show_progress:
            futures = tqdm(as_completed(future_to_name), 
                          total=len(components),
                          desc="Downloading components")
        else:
            futures = as_completed(future_to_name)
        
        for future in futures:
            name, success = future.result()
            results[name] = success
    
    return results


def verify_directory_structure(ref_path: Path) -> List[str]:
    """
    Verify that all required directories exist.
    
    Args:
        ref_path: Path to reference data directory
        
    Returns:
        List[str]: List of missing directories
    """
    required_dirs = [
        "KEGG",
        "Ref99NR",
        "Ref100NR",
        "SILVA",
        "TOOLS"
    ]
    
    missing_dirs = []
    for dir_name in required_dirs:
        dir_path = ref_path / dir_name
        if not dir_path.exists() or not dir_path.is_dir():
            missing_dirs.append(dir_name)
    
    return missing_dirs


def create_reference_index(ref_path: Path) -> None:
    """
    Create an index file of all reference files for quick lookup.
    
    Args:
        ref_path: Path to reference data directory
    """
    import json
    from datetime import datetime
    
    index_data = {
        "created": datetime.now().isoformat(),
        "version": "1.2",
        "files": {}
    }
    
    # Walk through directory and index files
    for root, dirs, files in os.walk(ref_path):
        for file in files:
            file_path = Path(root) / file
            rel_path = file_path.relative_to(ref_path)
            
            try:
                file_size = file_path.stat().st_size
                file_md5 = calculate_md5(file_path)
                
                index_data["files"][str(rel_path)] = {
                    "size": file_size,
                    "md5": file_md5,
                    "modified": file_path.stat().st_mtime
                }
            except Exception:
                # Skip files we can't read
                continue
    
    # Save index
    index_file = ref_path / "index.json"
    with open(index_file, 'w') as f:
        json.dump(index_data, f, indent=2)
    
    print(f"Created reference index: {index_file}")


def main():
    """Command-line interface for building reference data."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Build pyTax4Fun2 reference database"
    )
    parser.add_argument(
        "--working-dir", "-w",
        default=".",
        help="Working directory for download (default: current directory)"
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Overwrite existing reference data"
    )
    parser.add_argument(
        "--no-packages",
        action="store_true",
        help="Skip installation of suggested Python packages"
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Hide progress bars"
    )
    parser.add_argument(
        "--skip-checksum",
        action="store_true",
        help="Skip MD5 checksum verification (faster)"
    )
    parser.add_argument(
        "--parallel", "-p",
        type=int,
        default=3,
        help="Number of parallel downloads (default: 3)"
    )
    
    args = parser.parse_args()
    
    try:
        ref_path = build_reference_data(
            path_to_working_directory=args.working_dir,
            use_force=args.force,
            install_suggested_packages=not args.no_packages,
            show_progress=not args.no_progress,
            skip_checksum_verification=args.skip_checksum
        )
        
        print(f"\nReference data successfully installed at: {ref_path}")
        print("\nNext steps:")
        print("1. Install dependencies: python -m pyTax4Fun2.build_dependencies")
        print("2. Test installation: python -m pyTax4Fun2.test_reference_data")
        print("3. Run example: python -m pyTax4Fun2.get_example_data")
        
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
	