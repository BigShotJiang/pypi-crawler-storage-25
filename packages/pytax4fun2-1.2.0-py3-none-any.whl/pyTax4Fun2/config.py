"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Configuration for pyTax4Fun2.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any
from .utils import TOOL_VERSIONS, DEFAULT_CONFIG


class pyTax4Fun2Config:
    """Configuration manager for pyTax4Fun2."""
    
    def __init__(self, config_path: Path = None):
        self.config_path = config_path or Path.home() / ".pyTax4Fun2" / "config.json"
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default."""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    return json.load(f)
            except:
                return self._create_default_config()
        else:
            return self._create_default_config()
    
    def _create_default_config(self) -> Dict[str, Any]:
        """Create default configuration."""
        return {
            "tool_versions": TOOL_VERSIONS,
            "urls": DEFAULT_CONFIG,
            "default_paths": {
                "reference_data": "pyTax4Fun2_ReferenceData",
                "temp_folder": "pyTax4Fun2_prediction",
                "user_data": "UserData"
            },
            "performance": {
                "num_threads": max(1, os.cpu_count() // 2),
                "chunk_size": 10000,
                "max_memory_gb": 8
            }
        }
    
    def save(self):
        """Save configuration to file."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def get(self, key: str, default=None):
        """Get configuration value."""
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value."""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
        self.save()


# Global configuration instance
config = pyTax4Fun2Config()
