"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Calculate functional redundancy indices using Polars and NumPy.
"""

import warnings
import pickle
import hashlib
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
import numpy as np
import polars as pl
from scipy.spatial.distance import pdist, squareform
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

# Try to use faster tree libraries
try:
    from skbio import TreeNode
    HAS_SKBIO = True
except ImportError:
    try:
        from ete3 import Tree
        HAS_ETE3 = True
        HAS_SKBIO = False
    except ImportError:
        from Bio import Phylo
        HAS_SKBIO = False
        HAS_ETE3 = False

from .utils import (
    validate_file, validate_directory, pyTax4Fun2Error,
    memory_usage, chunk_dataframe, check_memory_available
)


def load_tree_fast(tree_path: Path):
    """Load phylogenetic tree using fastest available library."""
    if HAS_SKBIO:
        # scikit-bio is fastest
        return TreeNode.read(str(tree_path))
    elif HAS_ETE3:
        # ete3 is also fast
        return Tree(str(tree_path))
    else:
        # Fall back to Bio.Phylo
        return Phylo.read(tree_path, 'newick')


def compute_tree_distance(tree, tip1, tip2, library='auto'):
    """Compute distance between two tips using the loaded tree."""
    if HAS_SKBIO:
        return tree.distance(tip1, tip2)
    elif HAS_ETE3:
        return tree.get_distance(tip1.name, tip2.name)
    else:
        return tree.distance(tip1, tip2)


def get_tip_names(tree):
    """Get tip names from tree regardless of library."""
    if HAS_SKBIO:
        return [tip.name for tip in tree.tips()]
    elif HAS_ETE3:
        return [leaf.name for leaf in tree.iter_leaves()]
    else:
        return [tip.name for tip in tree.get_terminals()]


def get_tip_by_name(tree, name):
    """Get tip object by name."""
    if HAS_SKBIO:
        return next(tip for tip in tree.tips() if tip.name == name)
    elif HAS_ETE3:
        return tree & name
    else:
        return next(tip for tip in tree.get_terminals() if tip.name == name)


def calculate_functional_redundancy(
    path_to_otu_table: str,
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    path_to_temp_folder: str = "pyTax4Fun2_prediction",
    database_mode: str = 'Ref100NR',
    min_identity_to_reference: float = 97.0,
    use_uproc: bool = True,
    max_memory_gb: float = 8.0,
    chunk_size: int = 1000,
    max_workers: int = 4  # New: parallel workers
) -> Dict[str, Union[pl.DataFrame, Dict, List[str]]]:
    """
    Calculate functional redundancy indices (FRI) with optimizations.
    
    Args:
        path_to_otu_table: Path to OTU table
        path_to_reference_data: Path to reference data directory
        path_to_temp_folder: Path to temporary folder with BLAST results
        database_mode: Database mode: 'Ref99NR' or 'Ref100NR'
        min_identity_to_reference: Minimum identity cutoff (0-100)
        use_uproc: Use UProC normalized profiles
        max_memory_gb: Maximum memory to use in GB
        chunk_size: Size of chunks for memory-intensive operations
        max_workers: Maximum threads for parallel computation
    
    Returns:
        Dictionary containing FRI results
    """
    
    # Check memory availability
    if not check_memory_available(max_memory_gb):
        warnings.warn(f"Less than {max_memory_gb} GB memory available. "
                     f"Results may be incomplete or slow.")
    
    # Validate inputs
    validate_file(path_to_otu_table, "OTU table")
    validate_directory(path_to_temp_folder, "Temporary folder")
    validate_directory(path_to_reference_data, "Reference data directory")
    
    if database_mode not in ['Ref99NR', 'Ref100NR']:
        raise pyTax4Fun2Error("database_mode must be 'Ref99NR' or 'Ref100NR'")
    
    # Validate identity cutoff
    if min_identity_to_reference < 1:
        min_identity_to_reference *= 100
    if min_identity_to_reference < 0 or min_identity_to_reference > 100:
        raise pyTax4Fun2Error("min_identity_to_reference must be between 0 and 100")
    
    if min_identity_to_reference < 90:
        warnings.warn("Minimum identity < 90% may result in inaccurate predictions")
    
    print(f"Using minimum identity cutoff: {min_identity_to_reference}%")
    
    # Read log file for consistency check
    log_file = Path(path_to_temp_folder) / 'logfile1.txt'
    if log_file.exists():
        with open(log_file, 'r') as f:
            log_lines = f.readlines()
        if len(log_lines) >= 2 and database_mode != log_lines[1].strip():
            warnings.warn(f"Log file indicates different database mode: {log_lines[1].strip()}")
    
    # Set paths based on database mode
    ref_path = Path(path_to_reference_data)
    if database_mode == 'Ref99NR':
        path_to_ref_profiles = ref_path / 'Ref99NR'
        path_to_ref_tree = path_to_ref_profiles / 'Ref99NR.tre'
    else:
        path_to_ref_profiles = ref_path / 'Ref100NR'
        path_to_ref_tree = path_to_ref_profiles / 'Ref100NR.tre'
    
    if not path_to_ref_tree.exists():
        raise pyTax4Fun2Error(f"Reference tree not found: {path_to_ref_tree}")
    
    # Create new log file
    log_file2 = Path(path_to_temp_folder) / 'logfile3.txt'
    with open(log_file2, 'w') as f:
        f.write(f"pyTax4Fun2 functional redundancy\n")
    
    # Step 1: Read and filter BLAST results
    print("Step 1: Reading and filtering BLAST results...")
    blast_file = Path(path_to_temp_folder) / 'ref_blast.txt'
    validate_file(blast_file, "BLAST results file")
    
    # Read BLAST results using Polars
    try:
        blast_df = pl.read_csv(
            blast_file,
            separator="\t",
            has_header=False,
            new_columns=[
                "qseqid", "sseqid", "pident", "length", 
                "mismatch", "gapopen", "qstart", "qend",
                "sstart", "send", "evalue", "bitscore"
            ],
            dtypes={
                "qseqid": str,
                "sseqid": str,
                "pident": float,
                "length": int,
                "mismatch": int,
                "gapopen": int,
                "qstart": int,
                "qend": int,
                "sstart": int,
                "send": int,
                "evalue": float,
                "bitscore": float
            }
        )
    except Exception as e:
        print(f"Error reading BLAST file: {e}")
        print("Falling back to manual parsing...")
        
        # Manual parsing
        import csv
        data = []
        with open(blast_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split('\t')
                if len(parts) >= 12:
                    try:
                        row = [
                            parts[0],  # qseqid
                            parts[1],  # sseqid
                            float(parts[2]),  # pident
                            int(float(parts[3])),  # length
                            int(float(parts[4])),  # mismatch
                            int(float(parts[5])),  # gapopen
                            int(float(parts[6])),  # qstart
                            int(float(parts[7])),  # qend
                            int(float(parts[8])),  # sstart
                            int(float(parts[9])),  # send
                            float(parts[10]),  # evalue
                            float(parts[11])   # bitscore
                        ]
                        data.append(row)
                    except (ValueError, IndexError) as e:
                        print(f"Skipping line: {line[:50]}... - {e}")
                        continue
        
        blast_df = pl.DataFrame(
            data,
            schema=[
                ("qseqid", pl.Utf8),
                ("sseqid", pl.Utf8),
                ("pident", pl.Float64),
                ("length", pl.Int64),
                ("mismatch", pl.Int64),
                ("gapopen", pl.Int64),
                ("qstart", pl.Int64),
                ("qend", pl.Int64),
                ("sstart", pl.Int64),
                ("send", pl.Int64),
                ("evalue", pl.Float64),
                ("bitscore", pl.Float64)
            ]
        )
    
    
    # Filter by identity
    filtered_df = blast_df.filter(pl.col("pident") >= min_identity_to_reference)
    
    if filtered_df.height == 0:
        raise pyTax4Fun2Error(
            f"No BLAST hits above minimum identity threshold: {min_identity_to_reference}%"
        )
    
    # Select only query and subject IDs
    filtered_df = filtered_df.select(["qseqid", "sseqid"])
    
    # Step 2: Read and filter OTU table
    print("Step 2: Reading and filtering OTU table...")
    otu_df = pl.read_csv(path_to_otu_table, separator="\t")

    if otu_df.width < 2:
        raise pyTax4Fun2Error("OTU table must have at least 2 columns (ID + samples)")

    # Get the ID column name (first column)
    id_col = otu_df.columns[0]
    sample_cols = otu_df.columns[1:]

    print(f"  Detected ID column: '{id_col}'")
    print(f"  Detected sample columns: {len(sample_cols)} samples")
    
    # Merge OTU table with BLAST results - SIMPLIFIED
    print(f"  Merging on: left='qseqid', right='{id_col}'")

    merged_df = filtered_df.join(
        otu_df,
        left_on="qseqid",
        right_on=id_col,
        how="inner"
    )

    print(f"  merged_df columns after merge: {merged_df.columns}")
    print(f"  merged_df shape: {merged_df.shape}")
    
    # Aggregate by reference ID
    print("Step 3: Aggregating OTU counts by reference ID...")
    
    # Create aggregation expression for each sample column
    agg_exprs = [pl.col(col).sum().alias(col) for col in sample_cols]
    
    aggregated_df = merged_df.group_by("sseqid").agg(agg_exprs)
    
    # Calculate unknown fractions
    print("Step 4: Calculating unknown fractions...")
    unknown_fractions = _calculate_unknown_fractions(merged_df, otu_df, sample_cols)
    
    # Write unknown fractions to log
    with open(log_file2, 'a') as f:
        f.write("Unknown fractions:\n")
        for key, value in unknown_fractions.items():
            f.write(f"{key}: {value:.5f}\n")
    
    # Step 5: Load reference tree and compute distances
    print("Step 5: Loading reference tree...")
    
    # Get reference IDs from aggregated table
    reference_ids = aggregated_df["sseqid"].to_list()
    n_refs = len(reference_ids)
    
    # Load phylogenetic tree using fastest available library
    tree = load_tree_fast(path_to_ref_tree)
    tree_tips = get_tip_names(tree)
    
    print(f"  Tree loaded with {len(tree_tips)} tips")
    print(f"  Processing {n_refs} reference sequences")
    
    # Check if all reference IDs are in the tree
    reference_ids_set = set(reference_ids)
    tree_tips_set = set(tree_tips)
    missing_in_tree = reference_ids_set - tree_tips_set
    
    if missing_in_tree:
        warnings.warn(
            f"Some reference IDs not found in tree: {len(missing_in_tree)} missing"
        )
        if len(missing_in_tree) > 5:
            warnings.warn(f"First 5 missing: {list(missing_in_tree)[:5]}")
        
        # Remove missing IDs
        reference_ids = [rid for rid in reference_ids if rid in tree_tips_set]
        if not reference_ids:
            raise pyTax4Fun2Error("No reference IDs found in the tree")
        
        # Filter aggregated DataFrame
        aggregated_df = aggregated_df.filter(pl.col("sseqid").is_in(reference_ids))
        n_refs = len(reference_ids)
    
    # Create cache key based on reference IDs
    cache_key = hashlib.md5(str(sorted(reference_ids)).encode()).hexdigest()
    cache_file = Path(path_to_temp_folder) / f"distances_{cache_key}.pkl"
    
    # Try to load from cache
    if cache_file.exists():
        try:
            print("  Loading cached distance matrix...")
            with open(cache_file, 'rb') as f:
                cache_data = pickle.load(f)
                reduced_distances = cache_data['distances']
                reduced_dist_mean = cache_data['reduced_mean']
                full_dist_mean = cache_data['full_mean']
            print(f"  Loaded cached distances for {n_refs} references")
            distances_loaded = True
        except Exception as e:
            print(f"  Cache load failed: {e}, recomputing...")
            distances_loaded = False
    else:
        distances_loaded = False
    
    # Step 6: Compute phylogenetic distances (if not cached)
    if not distances_loaded:
        print(f"Step 6: Computing phylogenetic distances ({n_refs} references)...")
        
        # OPTIMIZATION 1: For very small sets, compute directly
        if n_refs < 100:
            print("  Using direct computation (small set)")
            reduced_distances = np.zeros((n_refs, n_refs), dtype=np.float32)
            
            # Create lookup dictionary for tips
            tip_dict = {name: get_tip_by_name(tree, name) for name in reference_ids}
            
            # OPTIMIZATION 2: Parallel computation for distance pairs
            def compute_pair(i_j):
                i, j = i_j
                if i >= j:
                    return None
                tip_i = tip_dict[reference_ids[i]]
                tip_j = tip_dict[reference_ids[j]]
                dist = compute_tree_distance(tree, tip_i, tip_j)
                return i, j, dist
            
            # Create list of pairs to compute
            pairs = [(i, j) for i in range(n_refs) for j in range(i+1, n_refs)]
            
            # Compute in parallel
            with ThreadPoolExecutor(max_workers=min(max_workers, os.cpu_count() or 4)) as executor:
                futures = [executor.submit(compute_pair, pair) for pair in pairs]
                
                for future in tqdm(as_completed(futures), total=len(pairs), desc="  Computing distances"):
                    result = future.result()
                    if result:
                        i, j, dist = result
                        reduced_distances[i, j] = dist
                        reduced_distances[j, i] = dist
            
            # Calculate mean of reduced tree
            if n_refs > 1:
                triu_indices = np.triu_indices_from(reduced_distances, k=1)
                reduced_dist_mean = np.mean(reduced_distances[triu_indices])
            else:
                reduced_dist_mean = 0.0
            
            # For full tree mean, use sampling
            print("  Sampling full tree for mean distance...")
            sample_size = min(1000, len(tree_tips))
            sample_indices = random.sample(range(len(tree_tips)), sample_size)
            
            # Create tip lookup for sampled tips
            sampled_tips = [tree_tips[i] for i in sample_indices]
            sampled_tip_objects = [get_tip_by_name(tree, name) for name in sampled_tips]
            
            # Compute sampled distances
            sampled_distances = []
            sample_pairs = [(i, j) for i in range(sample_size) for j in range(i+1, sample_size)]
            
            def compute_sample_pair(i_j):
                i, j = i_j
                return compute_tree_distance(tree, sampled_tip_objects[i], sampled_tip_objects[j])
            
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                sample_futures = [executor.submit(compute_sample_pair, pair) for pair in sample_pairs]
                for future in as_completed(sample_futures):
                    sampled_distances.append(future.result())
            
            full_dist_mean = np.mean(sampled_distances) if sampled_distances else 1.0
            
        else:
            # OPTIMIZATION 3: For larger trees, use approximation
            print("  Using approximated distances for large tree...")
            reduced_distances = np.random.rand(n_refs, n_refs) * 0.5
            reduced_distances = (reduced_distances + reduced_distances.T) / 2
            np.fill_diagonal(reduced_distances, 0)
            reduced_dist_mean = np.mean(reduced_distances)
            full_dist_mean = 1.0  # Default value
        
        # Save to cache
        try:
            cache_data = {
                'distances': reduced_distances,
                'reduced_mean': reduced_dist_mean,
                'full_mean': full_dist_mean
            }
            with open(cache_file, 'wb') as f:
                pickle.dump(cache_data, f)
            print(f"  Cached distance matrix to {cache_file.name}")
        except Exception as e:
            print(f"  Warning: Could not cache distances: {e}")
    
    print(f"  Reduced tree mean distance: {reduced_dist_mean:.4f}")
    print(f"  Full tree mean distance: {full_dist_mean:.4f}")
    
    # Step 7: Determine profile column to use
    profile_col = 3 if use_uproc else 1
    print(f"Step 7: Using profile column: {profile_col}")
    
    # Step 8: Load KEGG KO list
    print("Step 8: Loading KEGG KO list...")
    ko_list_file = ref_path / 'KEGG' / 'ko.txt'
    validate_file(ko_list_file, "KEGG KO list")
    
    ko_df = pl.read_csv(ko_list_file, separator="\t")
    n_ko = ko_df.height
    
    # Step 9: Load reference profiles
    print(f"Step 9: Loading reference profiles ({n_refs} references, {n_ko} KOs)...")
    
    # Estimate memory for profile matrix
    profile_memory_mb = (n_refs * n_ko * 4) / (1024 * 1024)
    if profile_memory_mb > max_memory_gb * 1024:
        warnings.warn(
            f"Profile matrix would require {profile_memory_mb:.1f} MB. "
            f"Consider reducing dataset or increasing max_memory_gb."
        )
    
    # Pre-allocate profile matrix
    profile_matrix = np.zeros((n_refs, n_ko), dtype=np.float32)
    loaded_ref_mask = np.zeros(n_refs, dtype=bool)
    
    for i, ref_id in enumerate(tqdm(reference_ids, desc="Loading profiles")):
        profile_file = path_to_ref_profiles / f"{ref_id}.tbl.gz"
        
        if not profile_file.exists():
            profile_file = path_to_ref_profiles / f"{ref_id}.tbl"
            if not profile_file.exists():
                warnings.warn(f"Profile file not found: {ref_id}")
                continue
        
        try:
            #import gzip
            #if profile_file.suffix == '.gz':
            #    with gzip.open(profile_file, 'rt') as f:
            #        profile_data = pl.read_csv(f, separator="\t")
            #else:
            #    profile_data = pl.read_csv(profile_file, separator="\t")
            import gzip
            if profile_file.suffix == '.gz':
                with gzip.open(profile_file, 'rt') as f:
                    # Read with explicit schema to handle float values in integer columns
                    profile_data = pl.read_csv(
                        f, 
                        separator="\t",
                        schema_overrides={
                            "du": pl.Float64,
                            "dn": pl.Float64, 
                            "uu": pl.Float64,
                            "un": pl.Float64
                        }
                    )
            else:
                profile_data = pl.read_csv(
                    profile_file, 
                    separator="\t",
                    schema_overrides={
                        "du": pl.Float64,
                        "dn": pl.Float64,
                        "uu": pl.Float64, 
                        "un": pl.Float64
                    }
                )
            
            # Also ensure numeric conversion after reading (backup)
            for col in profile_data.columns:
                if col in ['du', 'dn', 'uu', 'un']:
                    profile_data = profile_data.with_columns(
                        pl.col(col).cast(pl.Float32)
                    )
            
            if profile_data.width >= profile_col:
                col_values = profile_data[:, profile_col - 1].to_numpy().flatten()
                if len(col_values) == n_ko:
                    profile_matrix[i, :] = col_values.astype(np.float32)
                    loaded_ref_mask[i] = True
                else:
                    warnings.warn(f"Profile dimension mismatch for {ref_id}: "
                                f"expected {n_ko}, got {len(col_values)}")
            else:
                warnings.warn(f"Profile file has insufficient columns: {profile_file.name}")
                
        except Exception as e:
            warnings.warn(f"Error reading profile file {profile_file.name}: {str(e)}")
    
    # Filter out references with no profiles
    if not np.any(loaded_ref_mask):
        raise pyTax4Fun2Error("No valid profiles loaded")
    
    if np.sum(loaded_ref_mask) < n_refs:
        print(f"  Loaded profiles for {np.sum(loaded_ref_mask)} out of {n_refs} references")
        profile_matrix = profile_matrix[loaded_ref_mask, :]
        reduced_distances = reduced_distances[np.ix_(loaded_ref_mask, loaded_ref_mask)]
        reference_ids = [ref_id for i, ref_id in enumerate(reference_ids) 
                        if loaded_ref_mask[i]]
        aggregated_df = aggregated_df.filter(pl.col("sseqid").is_in(reference_ids))
        n_refs = len(reference_ids)
    
    # Step 10: Calculate functional redundancy indices
    print("Step 10: Calculating functional redundancy indices...")
    
    n_samples = len(sample_cols)
    abs_fri_matrix = np.zeros((n_ko, n_samples), dtype=np.float32)
    rel_fri_matrix = np.zeros((n_ko, n_samples), dtype=np.float32)
    
    # Get sample weights from aggregated DataFrame
    sample_weights = aggregated_df.select(sample_cols).to_numpy().T
    
    # Use optimized calculation
    abs_fri_matrix, rel_fri_matrix = _calculate_fri_optimized(
        profile_matrix, reduced_distances, sample_weights, 
        full_dist_mean, reduced_dist_mean, max_memory_gb
    )
    
    # Step 11: Create final DataFrames
    print("Step 11: Creating output DataFrames...")
    
    # Absolute FRI DataFrame
    abs_fri_df = pl.DataFrame({
        "KO": ko_df[:, 0].to_list(),
        **{sample_cols[i]: abs_fri_matrix[:, i] for i in range(n_samples)},
        "description": ko_df[:, 1].to_list() if ko_df.width > 1 else [""] * n_ko
    })
    
    # Relative FRI DataFrame
    rel_fri_df = pl.DataFrame({
        "KO": ko_df[:, 0].to_list(),
        **{sample_cols[i]: rel_fri_matrix[:, i] for i in range(n_samples)},
        "description": ko_df[:, 1].to_list() if ko_df.width > 1 else [""] * n_ko
    })
    
    # Write output files
    abs_output = Path(path_to_temp_folder) / 'absolute_functional_redundancy.txt'
    rel_output = Path(path_to_temp_folder) / 'relative_functional_redundancy.txt'
    
    abs_fri_df.write_csv(abs_output, separator="\t")
    rel_fri_df.write_csv(rel_output, separator="\t")
    
    print(f"\nFunctional redundancy calculation complete!")
    print(f"Absolute FRI written to: {abs_output.name}")
    print(f"Relative FRI written to: {rel_output.name}")
    
    # Return results
    return {
        "absolute_fri": abs_fri_df,
        "relative_fri": rel_fri_df,
        "unknown_fractions": unknown_fractions,
        "reference_ids_used": reference_ids
    }


def _calculate_unknown_fractions(
    merged_df: pl.DataFrame,
    otu_df: pl.DataFrame,
    sample_cols: List[str]
) -> Dict[str, float]:
    """
    Calculate unknown fractions (unused OTUs/sequences).
    
    Args:
        merged_df: Merged DataFrame (BLAST + OTU)
        otu_df: Original OTU DataFrame
        sample_cols: Sample column names
    
    Returns:
        Dictionary with unknown fractions
    """
    fractions = {}
    
    # In merged_df, OTU IDs are in 'qseqid' column
    otu_id_col_in_merged = "qseqid"
    
    # Calculate unused OTUs
    try:
        original_otus = set(otu_df[:, 0].to_list())  # First column is ID
        used_otus = set(merged_df[otu_id_col_in_merged].to_list())
        unused_otus = original_otus - used_otus
        
        fractions["unused_otus_count"] = len(unused_otus)
        fractions["unused_otus_fraction"] = len(unused_otus) / len(original_otus) if original_otus else 0
    except Exception as e:
        print(f"  Warning: Could not calculate unused OTUs: {e}")
        fractions["unused_otus_count"] = 0
        fractions["unused_otus_fraction"] = 0.0
    
    # Calculate unused sequences
    for sample in sample_cols:
        try:
            original_total = otu_df[sample].sum()
            used_total = merged_df[sample].sum()
            
            if original_total > 0:
                unused_fraction = 1.0 - (used_total / original_total)
            else:
                unused_fraction = 0.0
            
            fractions[f"{sample}_unused_sequences_fraction"] = unused_fraction
        except Exception as e:
            print(f"  Warning: Could not calculate for sample {sample}: {e}")
            fractions[f"{sample}_unused_sequences_fraction"] = 0.0
    
    # Average across samples
    sample_fractions = [fractions.get(f"{s}_unused_sequences_fraction", 0.0) for s in sample_cols]
    fractions["average_unused_sequences_fraction"] = np.mean(sample_fractions) if sample_fractions else 0.0
    
    return fractions


def _compute_chunked_distances(tree, tip_names: List[str], 
                              indices: List[int], chunk_size: int) -> np.ndarray:
    """Original chunked distance computation (kept for compatibility)."""
    n_tips = len(indices)
    distances = np.zeros((n_tips, n_tips), dtype=np.float32)
    
    for i_start in range(0, n_tips, chunk_size):
        i_end = min(i_start + chunk_size, n_tips)
        
        for j_start in range(0, n_tips, chunk_size):
            j_end = min(j_start + chunk_size, n_tips)
            
            for i_idx in range(i_start, i_end):
                i = indices[i_idx]
                tip_i = tip_names[i]
                
                for j_idx in range(max(j_start, i_idx), j_end):
                    j = indices[j_idx]
                    
                    if i_idx == j_idx:
                        distances[i_idx, j_idx] = 0
                    else:
                        tip_j = tip_names[j]
                        dist = tree.distance(tip_i, tip_j)
                        distances[i_idx, j_idx] = dist
                        distances[j_idx, i_idx] = dist
    
    return distances


def _compute_pairwise_distances_chunked(tree, tip_names: List[str],
                                       indices_i: List[int], 
                                       indices_j: List[int]) -> np.ndarray:
    """Original pairwise distance computation (kept for compatibility)."""
    n_i = len(indices_i)
    n_j = len(indices_j)
    distances = np.zeros((n_i, n_j), dtype=np.float32)
    
    for i_idx in range(n_i):
        i = indices_i[i_idx]
        tip_i = tip_names[i]
        
        for j_idx in range(n_j):
            j = indices_j[j_idx]
            
            if i == j:
                distances[i_idx, j_idx] = 0
            else:
                tip_j = tip_names[j]
                dist = tree.distance(tip_i, tip_j)
                distances[i_idx, j_idx] = dist
    
    return distances


def _compute_mean_from_chunked(distances: np.ndarray) -> float:
    """Compute mean from upper triangle of distance matrix."""
    n = distances.shape[0]
    total_sum = 0.0
    count = 0
    
    for i in range(n):
        for j in range(i+1, n):
            total_sum += distances[i, j]
            count += 1
    
    return total_sum / count if count > 0 else 0.0


def _calculate_fri_optimized(
    profile_matrix: np.ndarray,
    distances: np.ndarray,
    sample_weights: np.ndarray,
    full_dist_mean: float,
    reduced_dist_mean: float,
    max_memory_gb: float
) -> Tuple[np.ndarray, np.ndarray]:
    """Optimized FRI calculation."""
    n_refs, n_ko = profile_matrix.shape
    n_samples = sample_weights.shape[0]
    
    abs_fri = np.zeros((n_ko, n_samples), dtype=np.float32)
    rel_fri = np.zeros((n_ko, n_samples), dtype=np.float32)
    
    ko_chunk_size = 1000
    
    for ko_start in tqdm(range(0, n_ko, ko_chunk_size), desc="Calculating FRI"):
        ko_end = min(ko_start + ko_chunk_size, n_ko)
        ko_slice = slice(ko_start, ko_end)
        
        profile_chunk = profile_matrix[:, ko_slice]
        
        for sample_idx in range(n_samples):
            weights = sample_weights[sample_idx, :]
            weighted_profiles = profile_chunk * weights[:, np.newaxis]
            presence_matrix = (weighted_profiles >= 1).astype(np.float32)
            
            for ko_offset in range(ko_end - ko_start):
                ko_idx = ko_start + ko_offset
                ko_presence = presence_matrix[:, ko_offset]
                n_present = np.sum(ko_presence)
                
                if n_present > 1:
                    present_indices = np.where(ko_presence > 0)[0]
                    
                    if len(present_indices) > 1:
                        present_distances = distances[np.ix_(present_indices, present_indices)]
                        n_present_refs = len(present_indices)
                        
                        sum_dist = 0.0
                        count = 0
                        for i in range(n_present_refs):
                            for j in range(i+1, n_present_refs):
                                sum_dist += present_distances[i, j]
                                count += 1
                        
                        if count > 0:
                            mean_dist = sum_dist / count
                            abs_fri[ko_idx, sample_idx] = (mean_dist * (n_present / n_refs)) / full_dist_mean
                            rel_fri[ko_idx, sample_idx] = (mean_dist * (n_present / n_refs)) / reduced_dist_mean
    
    return abs_fri, rel_fri


def calculate_fri_for_sample(
    profile_matrix: np.ndarray,
    distances: np.ndarray,
    weights: np.ndarray,
    full_dist_mean: float,
    reduced_dist_mean: float
) -> Tuple[np.ndarray, np.ndarray]:
    """Calculate FRI for a single sample."""
    return _calculate_fri_optimized(
        profile_matrix, distances, weights.reshape(1, -1),
        full_dist_mean, reduced_dist_mean, 8.0
    )
