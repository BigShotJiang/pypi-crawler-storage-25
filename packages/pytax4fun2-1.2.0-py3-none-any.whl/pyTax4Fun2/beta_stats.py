"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Statistical tests for beta diversity analysis.
PERMANOVA (adonis), PERMDISP, and clustering quality metrics for distance matrices implementations with both non-phylogenetic and phylogenetic beta diversity.
"""

import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform
from scipy.stats import f_oneway
import warnings

# All available distance metrics from custom metrics + scipy' non-phylogenetic metrics + scikit-bio' phylogenetic metrics
SCIPY_DISTANCE_METRICS = [
    'braycurtis', 'canberra', 'chebyshev', 'cityblock', 'correlation',
    'cosine', 'dice', 'euclidean', 'hamming', 'jaccard', 'jensenshannon',
    'mahalanobis', 'matching', 'minkowski', 'rogerstanimoto',
    'russellrao', 'seuclidean', 'sokalmichener', 'sokalsneath', 'sqeuclidean',
    'yule'
]

# Custom metrics implemented here
CUSTOM_DISTANCE_METRICS = ['aitchison', 'kulczynski1']

# Phylogenetic beta diversity metrics (require tree)
PHYLOGENETIC_DISTANCE_METRICS = ['unweighted_unifrac', 'weighted_unifrac', 'unweighted_unifrac_normalized', 'weighted_unifrac_normalized']

# Combined list of all metrics
ALL_DISTANCE_METRICS = CUSTOM_DISTANCE_METRICS + SCIPY_DISTANCE_METRICS + PHYLOGENETIC_DISTANCE_METRICS

# Combined list for CLI
ALL_NON_PHYLOGENETIC_DISTANCE_METRICS = CUSTOM_DISTANCE_METRICS + SCIPY_DISTANCE_METRICS

# Try importing scikit-bio for phylogenetic metrics and PERMANOVA/PERMDISP
try:
    from skbio.diversity import beta as skbio_beta
    from skbio import DistanceMatrix
    from skbio.stats.distance import permanova, permdisp
    HAS_SKBIO = True
except ImportError:
    HAS_SKBIO = False
    warnings.warn("scikit-bio not installed. Install with: pip install scikit-bio")

# Try importing sklearn for clustering metrics
try:
    from sklearn.metrics import silhouette_score, silhouette_samples
    from sklearn.metrics import calinski_harabasz_score, davies_bouldin_score
    from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False
    warnings.warn("scikit-learn not installed. Some clustering metrics will be unavailable.")


def aitchison_distance(x, y):
    """
    Calculate Aitchison distance between two compositional vectors.
    
    Aitchison distance is the Euclidean distance between centered log-ratio (clr) 
    transformed compositions. It's the standard distance for compositional data
    like OTU tables and functional profiles.
    
    Args:
        x, y: 1-D arrays of compositional counts (same length)
        
    Returns:
        float: Aitchison distance
    """
    # Check for zeros - Aitchison requires positive values
    if np.any(x <= 0) or np.any(y <= 0):
        # Add small pseudocount (multiplicative replacement)
        # Using 0.65 * min positive value as recommended
        min_pos = min(x[x > 0].min(), y[y > 0].min()) if np.any(x > 0) and np.any(y > 0) else 1
        pseudocount = 0.65 * min_pos
        x = np.where(x <= 0, pseudocount, x)
        y = np.where(y <= 0, pseudocount, y)
    
    # Convert to relative abundances
    x_rel = x / x.sum()
    y_rel = y / y.sum()
    
    # Centered log-ratio transform
    x_clr = np.log(x_rel) - np.log(x_rel).mean()
    y_clr = np.log(y_rel) - np.log(y_rel).mean()
    
    # Euclidean distance of clr-transformed vectors
    return np.sqrt(np.sum((x_clr - y_clr) ** 2))


def aitchison_pairwise(X):
    """
    Compute pairwise Aitchison distance matrix.
    
    Args:
        X: 2-D array of shape (n_samples, n_features) with compositional counts
        
    Returns:
        condensed distance array (same format as pdist)
    """
    n_samples = X.shape[0]
    n_pairs = n_samples * (n_samples - 1) // 2
    distances = np.zeros(n_pairs)
    
    idx = 0
    for i in range(n_samples):
        for j in range(i + 1, n_samples):
            distances[idx] = aitchison_distance(X[i], X[j])
            idx += 1
    
    return distances


def kulczynski1_distance(u, v, w=None, binary_mode=False):
    """
    Compute Kulczynski 1 dissimilarity with support for both binary and abundance data.
    
    For binary data (OTU presence/absence): matches SciPy's deprecated implementation.
    For abundance data (functional profiles): preserves quantitative information.
    
    Parameters
    ----------
    u, v : array_like
        Input vectors
    w : array_like, optional
        Weights for each value (kept for API compatibility)
    binary_mode : bool, default=False
        If True, treat as binary/presence-absence data (OTU tables).
        If False, preserve abundance information (functional profiles).
        
    Returns
    -------
    float
        Kulczynski 1 dissimilarity (0 = identical, 1 = completely dissimilar)
    
    Notes
    -----
    For binary mode, this matches SciPy's deprecated implementation.
    For abundance mode, uses: 1 - (Σ min(u_i, v_i)) / (Σ u_i + Σ v_i)
    """
    u = np.asarray(u, dtype=np.float64)
    v = np.asarray(v, dtype=np.float64)
    
    if binary_mode:
        # Binary mode: matches SciPy's deprecated implementation
        # Convert to binary (presence/absence)
        u_bin = (u > 0).astype(np.float64)
        v_bin = (v > 0).astype(np.float64)
        
        if w is not None:
            w = np.asarray(w, dtype=np.float64)
            not_u = w * (1.0 - u_bin)
            not_v = w * (1.0 - v_bin)
            u_w = w * u_bin
            v_w = w * v_bin
        else:
            not_u = 1.0 - u_bin
            not_v = 1.0 - v_bin
            u_w = u_bin
            v_w = v_bin
        
        nft = np.sum(not_u * v_w)   # u=0, v=1
        ntf = np.sum(u_w * not_v)   # u=1, v=0
        ntt = np.sum(u_w * v_w)     # u=1, v=1
        
        # Kulczynski similarity = ntt / (ntf + nft)
        if (ntf + nft) == 0:
            return 0.0
        
        similarity = ntt / (ntf + nft)
        # Clip to [0, 1] to avoid floating point issues
        similarity = np.clip(similarity, 0.0, 1.0)
        return 1.0 - similarity
    
    else:
        # Abundance mode: preserve quantitative information
        # Formula: 1 - (Σ min(u_i, v_i)) / (Σ u_i + Σ v_i)
        shared = np.sum(np.minimum(u, v))
        total = np.sum(u) + np.sum(v)
        
        if total == 0:
            return 0.0
        
        return 1.0 - (shared / total)


def kulczynski1_pairwise(X, binary_mode=False):
    """
    Compute pairwise Kulczynski 1 distance matrix.
    
    Parameters
    ----------
    X : 2-D array, shape (n_samples, n_features)
        Input data matrix
    binary_mode : bool, default=False
        If True, treat as binary/presence-absence data (OTU tables).
        If False, preserve abundance information (functional profiles).
        
    Returns
    -------
    condensed distance array
    """
    n_samples = X.shape[0]
    n_pairs = n_samples * (n_samples - 1) // 2
    distances = np.zeros(n_pairs, dtype=np.float64)
    
    idx = 0
    for i in range(n_samples):
        for j in range(i + 1, n_samples):
            distances[idx] = kulczynski1_distance(X[i], X[j], binary_mode=binary_mode)
            idx += 1
    
    return distances


def weighted_unifrac_pairwise(counts, tree, sample_ids=None, taxa_ids=None, normalized=False):
    """
    Compute pairwise weighted UniFrac distances using scikit-bio.
    
    Args:
        counts: 2-D array of shape (n_samples, n_features) with counts
        tree: Phylogenetic tree (skbio.TreeNode)
        sample_ids: List of sample IDs (optional)
        taxa_ids: List of taxon/OTU IDs (must match tree tip names)
        normalized: If True, normalize distances to [0, 1]
        
    Returns:
        condensed distance array
    """
    if not HAS_SKBIO:
        raise ImportError("scikit-bio required for UniFrac calculations")
    
    from skbio.diversity import beta as skbio_beta
    from tqdm import tqdm
    
    n_samples = counts.shape[0]
    
    # Get taxon IDs (feature names)
    if taxa_ids is None:
        if hasattr(counts, 'columns') and hasattr(counts, 'index'):
            taxa_ids = list(counts.columns)
        else:
            taxa_ids = [f"OTU_{i}" for i in range(counts.shape[1])]
    
    # Ensure taxa_ids match tree tip names
    tree_tips = set(tip.name.strip() for tip in tree.tips())
    
    # Filter to matching taxa
    matched_indices = []
    matched_taxa = []
    for i, taxon in enumerate(taxa_ids):
        taxon_clean = taxon.strip()
        if taxon_clean in tree_tips:
            matched_indices.append(i)
            matched_taxa.append(taxon_clean)
    
    if not matched_indices:
        # Try case-insensitive matching
        tree_tips_lower = {tip.lower() for tip in tree_tips}
        for i, taxon in enumerate(taxa_ids):
            taxon_lower = taxon.strip().lower()
            if taxon_lower in tree_tips_lower:
                for tip in tree_tips:
                    if tip.lower() == taxon_lower:
                        matched_indices.append(i)
                        matched_taxa.append(tip)
                        break
        
        if not matched_indices:
            raise ValueError("No matching taxa found between OTU table and tree tips")
    
    # Filter counts to matched taxa
    counts = counts[:, matched_indices]
    taxa_ids = matched_taxa
    
    print(f"  Retained {len(taxa_ids)}/{len(matched_taxa)} taxa after matching")
    
    # Compute all pairwise distances
    n_pairs = n_samples * (n_samples - 1) // 2
    distances = np.zeros(n_pairs, dtype=np.float64)
    
    pair_idx = 0
    with tqdm(total=n_pairs, desc=f"Computing {'weighted' if normalized else 'weighted'} UniFrac distances") as pbar:
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                u_counts = counts[i, :].astype(float)
                v_counts = counts[j, :].astype(float)
                
                if np.sum(u_counts) == 0 or np.sum(v_counts) == 0:
                    distances[pair_idx] = 1.0
                else:
                    try:
                        dist = skbio_beta.weighted_unifrac(
                            u_counts, v_counts, taxa_ids, tree, normalized=normalized
                        )
                        distances[pair_idx] = dist
                    except Exception as e:
                        distances[pair_idx] = 1.0
                
                pair_idx += 1
                pbar.update(1)
    
    return distances


def unweighted_unifrac_pairwise(counts, tree, sample_ids=None, taxa_ids=None):
    """
    Compute pairwise unweighted UniFrac distances.
    """
    if not HAS_SKBIO:
        raise ImportError("scikit-bio required for UniFrac calculations")
    
    from skbio.diversity import beta as skbio_beta
    from tqdm import tqdm
    
    n_samples = counts.shape[0]
    
    # Get taxon IDs
    if taxa_ids is None:
        if hasattr(counts, 'columns') and hasattr(counts, 'index'):
            taxa_ids = list(counts.columns)
        else:
            taxa_ids = [f"OTU_{i}" for i in range(counts.shape[1])]
    
    # Ensure taxa_ids match tree tip names
    tree_tips = set(tip.name for tip in tree.tips())
    keep_idx = [i for i, taxon in enumerate(taxa_ids) if taxon in tree_tips]
    
    if not keep_idx:
        raise ValueError("No matching taxa found between OTU table and tree tips")
    
    counts = counts[:, keep_idx]
    taxa_ids = [taxa_ids[i] for i in keep_idx]
    
    # Compute all pairwise distances
    n_pairs = n_samples * (n_samples - 1) // 2
    distances = np.zeros(n_pairs, dtype=np.float64)
    
    pair_idx = 0
    for i in tqdm(range(n_samples), desc="Computing unweighted UniFrac distances"):
        for j in range(i + 1, n_samples):
            u_counts = counts[i, :]
            v_counts = counts[j, :]
            
            try:
                dist = skbio_beta.unweighted_unifrac(u_counts, v_counts, taxa_ids, tree)
                distances[pair_idx] = dist
            except Exception as e:
                distances[pair_idx] = 1.0
            
            pair_idx += 1
    
    return distances


def unweighted_unifrac_normalized_pairwise(counts, tree, sample_ids=None, taxa_ids=None):
    """
    Compute pairwise normalized unweighted UniFrac distances.
    """
    distances = unweighted_unifrac_pairwise(counts, tree, sample_ids, taxa_ids)
    
    # Normalize by total branch length
    total_branch_length = sum(node.length for node in tree.traverse() if node.length is not None)
    
    if total_branch_length > 0:
        distances = distances / total_branch_length
    
    return distances


def weighted_unifrac_normalized_pairwise(counts, tree, sample_ids=None, taxa_ids=None):
    """
    Compute pairwise normalized weighted UniFrac distances.
    """
    return weighted_unifrac_pairwise(counts, tree, sample_ids, taxa_ids, normalized=True)


# Custom distance dispatcher
def get_distance_function(metric, input_type='auto'):
    """
    Get distance function for given metric name.
    
    Args:
        metric: Distance metric name
        input_type: 'functional', 'otu', or 'auto' - determines binary vs abundance mode
            for metrics that support both (like kulczynski1)
        
    Returns:
        function: Distance function that takes X and returns condensed distances
    """
    if metric == 'aitchison':
        return aitchison_pairwise
    elif metric == 'kulczynski1':
        # Determine mode based on input_type
        binary_mode = (input_type == 'otu')
        return lambda X: kulczynski1_pairwise(X, binary_mode=binary_mode)
    elif metric == 'unweighted_unifrac':
        return unweighted_unifrac_pairwise
    elif metric == 'unweighted_unifrac_normalized':
        return unweighted_unifrac_normalized_pairwise
    elif metric == 'weighted_unifrac':
        return weighted_unifrac_pairwise
    elif metric == 'weighted_unifrac_normalized':
        return weighted_unifrac_normalized_pairwise
    else:
        # For scipy metrics, we'll use pdist with the metric name
        return None  # Signal to use pdist directly


def silhouette_from_distance_matrix(distance_matrix, labels, metric='precomputed'):
    """
    Calculate silhouette score from a precomputed distance matrix.
    
    Args:
        distance_matrix: Square distance matrix (n_samples × n_samples)
        labels: Array of cluster labels
        metric: Must be 'precomputed' for distance matrix
        
    Returns:
        float: Silhouette score (-1 to 1, higher is better)
    """
    if not HAS_SKLEARN:
        raise ImportError("scikit-learn required for silhouette score")
    
    # Check if we have at least 2 clusters
    unique_labels = np.unique(labels)
    if len(unique_labels) < 2:
        return 0.0  # Silhouette undefined for single cluster
    
    # Check if any cluster has only 1 sample
    from collections import Counter
    label_counts = Counter(labels)
    if any(count == 1 for count in label_counts.values()):
        # Silhouette requires at least 2 samples per cluster
        # Return a default value or handle appropriately
        return 0.0
    
    try:
        return silhouette_score(distance_matrix, labels, metric=metric)
    except Exception as e:
        print(f"    Silhouette calculation failed: {str(e)}")
        return 0.0


def silhouette_samples_from_distance_matrix(distance_matrix, labels):
    """
    Calculate per-sample silhouette scores from a distance matrix.
    
    Args:
        distance_matrix: Square distance matrix
        labels: Array of cluster labels
        
    Returns:
        np.ndarray: Silhouette values for each sample
    """
    if not HAS_SKLEARN:
        raise ImportError("scikit-learn required for silhouette score")
    
    return silhouette_samples(distance_matrix, labels, metric='precomputed')


def calinski_harabasz_from_distance_matrix(distance_matrix, labels):
    """
    Calculate Calinski-Harabasz index from distance matrix.
    Note: This requires coordinates, not just distances.
    For distance matrices, we need to use PCoA first.
    
    Args:
        distance_matrix: Square distance matrix
        labels: Array of cluster labels
        
    Returns:
        float: Calinski-Harabasz score (higher is better)
    """
    if not HAS_SKLEARN:
        raise ImportError("scikit-learn required for Calinski-Harabasz score")
    
    # Use metric MDS to get coordinates
    from sklearn.manifold import MDS
    
    # Reduce to 2D for CH index
    mds = MDS(n_components=min(distance_matrix.shape[0] - 1, 10), 
              dissimilarity='precomputed', random_state=42)
    coords = mds.fit_transform(distance_matrix)
    
    return calinski_harabasz_score(coords, labels)


def davies_bouldin_from_distance_matrix(distance_matrix, labels):
    """
    Calculate Davies-Bouldin index from distance matrix.
    Note: This requires coordinates, not just distances.
    
    Args:
        distance_matrix: Square distance matrix
        labels: Array of cluster labels
        
    Returns:
        float: Davies-Bouldin index (lower is better)
    """
    if not HAS_SKLEARN:
        raise ImportError("scikit-learn required for Davies-Bouldin score")
    
    # Use metric MDS to get coordinates
    from sklearn.manifold import MDS
    
    mds = MDS(n_components=min(distance_matrix.shape[0] - 1, 10), 
              dissimilarity='precomputed', random_state=42)
    coords = mds.fit_transform(distance_matrix)
    
    return davies_bouldin_score(coords, labels)


def cluster_quality_from_distance_matrix(distance_matrix, labels, sample_names=None):
    """
    Compute comprehensive clustering quality metrics from distance matrix.
    
    Args:
        distance_matrix: Square distance matrix
        labels: Array of cluster labels
        sample_names: Optional list of sample names
        
    Returns:
        dict: Dictionary with clustering quality metrics
    """
    results = {}
    
    # Silhouette score (works directly with distance matrix)
    try:
        results['silhouette'] = silhouette_from_distance_matrix(distance_matrix, labels)
        
        # Per-sample silhouette
        silhouette_vals = silhouette_samples_from_distance_matrix(distance_matrix, labels)
        if sample_names:
            results['silhouette_per_sample'] = dict(zip(sample_names, silhouette_vals))
        else:
            results['silhouette_per_sample'] = silhouette_vals.tolist()
            
    except Exception as e:
        results['silhouette_error'] = str(e)
    
    # Calinski-Harabasz and Davies-Bouldin require coordinates
    try:
        results['calinski_harabasz'] = calinski_harabasz_from_distance_matrix(distance_matrix, labels)
        results['davies_bouldin'] = davies_bouldin_from_distance_matrix(distance_matrix, labels)
    except Exception as e:
        results['coordinates_metrics_error'] = str(e)
    
    # Within-group and between-group distance ratios
    unique_labels = np.unique(labels)
    
    within_distances = []
    between_distances = []
    
    for i, label in enumerate(unique_labels):
        mask_i = labels == label
        indices_i = np.where(mask_i)[0]
        
        if len(indices_i) > 1:
            # Within-group distances
            submatrix = distance_matrix[np.ix_(indices_i, indices_i)]
            upper_tri = submatrix[np.triu_indices_from(submatrix, k=1)]
            if len(upper_tri) > 0:
                within_distances.extend(upper_tri.tolist())
        
        # Between-group distances (to other groups)
        for j, other_label in enumerate(unique_labels):
            if i >= j:
                continue
            mask_j = labels == other_label
            indices_j = np.where(mask_j)[0]
            
            between_submatrix = distance_matrix[np.ix_(indices_i, indices_j)]
            between_distances.extend(between_submatrix.flatten().tolist())
    
    results['within_group_mean_distance'] = np.mean(within_distances) if within_distances else 0
    results['between_group_mean_distance'] = np.mean(between_distances) if between_distances else 0
    results['ratio_between_within'] = (results['between_group_mean_distance'] / 
                                        results['within_group_mean_distance']) if results['within_group_mean_distance'] > 0 else 0
    
    return results


class BetaStatistics:
    """Calculate beta diversity statistics."""
    
    def __init__(self, distance_matrix=None, metadata=None, distance_metric=None, tree=None):
        """
        Initialize with distance matrix and metadata.
        
        Args:
            distance_matrix: Square distance matrix (samples × samples)
            metadata: DataFrame with sample metadata (samples as index)
            distance_metric: The metric used (for reference)
            tree: Phylogenetic tree (required for UniFrac metrics)
        """
        self.distance_matrix = distance_matrix
        self.metadata = metadata
        self.distance_metric = distance_metric
        self.tree = tree
        self.results = {}
        self.ordination_coords = None
    
    def add_ordination_coords(self, coords, sample_names):
        """
        Add ordination coordinates for enhanced PERMDISP calculation.
        
        Args:
            coords: DataFrame or array of coordinates (samples × dimensions)
            sample_names: List of sample names (or index of coords)
        """
        if isinstance(coords, pd.DataFrame):
            self.ordination_coords = coords
        else:
            self.ordination_coords = pd.DataFrame(coords, index=sample_names)
    
    def compute_distance_matrix(self, abundance_matrix, metric, sample_names=None, tree=None, input_type='auto', **kwargs):
        """
        Compute distance matrix using specified metric, with OTU data support.
        
        Args:
            abundance_matrix: Samples × features abundance matrix
            metric: Distance metric name
            sample_names: List of sample names
            tree: Phylogenetic tree (required for UniFrac)
            input_type: 'auto', 'functional', or 'otu'
            **kwargs: Additional arguments
            
        Returns:
            square distance matrix
        """
        # Detect input type if auto
        if input_type == 'auto':
            # Simple heuristic: if tree is provided, assume OTU data
            input_type = 'otu' if tree is not None else 'functional'
        
        # Check phylogenetic metric compatibility
        if metric in PHYLOGENETIC_DISTANCE_METRICS:
            if input_type == 'functional':
                raise ValueError(
                    f"Metric '{metric}' is phylogenetic and not applicable to functional data. "
                    f"Use non-phylogenetic metrics like braycurtis or aitchison."
                )
            if tree is None:
                raise ValueError(f"Phylogenetic tree required for metric: {metric}")
        
        # Get distance function with appropriate mode
        dist_func = get_distance_function(metric, input_type)
        
        if dist_func is not None:
            # Custom metric (aitchison, kulczynski1, or UniFrac)
            if metric in PHYLOGENETIC_DISTANCE_METRICS:
                # UniFrac metrics require tree
                if metric == 'unweighted_unifrac':
                    dist_array = unweighted_unifrac_pairwise(abundance_matrix, tree, sample_names)
                elif metric == 'unweighted_unifrac_normalized':
                    dist_array = unweighted_unifrac_normalized_pairwise(abundance_matrix, tree, sample_names)
                elif metric == 'weighted_unifrac':
                    dist_array = weighted_unifrac_pairwise(abundance_matrix, tree, sample_names, normalized=False)
                elif metric == 'weighted_unifrac_normalized':
                    dist_array = weighted_unifrac_normalized_pairwise(abundance_matrix, tree, sample_names)
                else:
                    raise ValueError(f"Unknown phylogenetic metric: {metric}")
            else:
                # Aitchison or Kulczynski1
                dist_array = dist_func(abundance_matrix)
            
            n_samples = abundance_matrix.shape[0]
            self.distance_matrix = squareform(dist_array)
            self.distance_metric = metric
            
        else:
            # Non-phylogenetic metrics - work for both functional and OTU
            condensed_distances = pdist(abundance_matrix, metric=metric)
            self.distance_matrix = squareform(condensed_distances)
            self.distance_metric = metric
        
        return self.distance_matrix
    
    def calculate_permanova(self, formula, grouping_column=None, permutations=999):
        """
        Perform PERMANOVA (adonis) test.
        
        Args:
            formula: R-style formula (e.g., 'treatment + depth') OR None for simple grouping
            grouping_column: If using simple grouping, column name in metadata
            permutations: Number of permutations
        """
        if not HAS_SKBIO:
            raise ImportError("scikit-bio required for PERMANOVA")
        
        if self.distance_matrix is None:
            raise ValueError("Distance matrix not provided")
        
        if self.metadata is None:
            raise ValueError("Metadata required for PERMANOVA")
        
        # Convert to scikit-bio DistanceMatrix
        dm = DistanceMatrix(self.distance_matrix, ids=self.metadata.index.tolist())
        
        # Handle simple grouping or formula
        if grouping_column and (formula is None or formula == ''):
            if grouping_column not in self.metadata.columns:
                raise ValueError(f"Column '{grouping_column}' not found in metadata")
            
            grouping = self.metadata[grouping_column]
            
            # Run PERMANOVA
            result = permanova(
                distance_matrix=dm,
                grouping=grouping,
                permutations=permutations
            )
            
            self.results['permanova'] = {
                'method': 'simple',
                'grouping_column': grouping_column,
                'distance_metric': self.distance_metric,
                'test_statistic': result['test statistic'],
                'p_value': result['p-value'],
                'permutations': result['number of permutations'],
                'sample_size': result['sample size']
            }
        else:
            # Use formula (requires patsy)
            try:
                import patsy
                
                # Parse formula
                y, X = patsy.dmatrices(formula, self.metadata, return_type='dataframe')
                
                # Run PERMANOVA with formula
                result = permanova(
                    distance_matrix=dm,
                    grouping=X,
                    permutations=permutations
                )
                
                self.results['permanova'] = {
                    'method': 'formula',
                    'formula': formula,
                    'distance_metric': self.distance_metric,
                    'test_statistic': result['test statistic'],
                    'p_value': result['p-value'],
                    'permutations': result['number of permutations'],
                    'sample_size': result['sample size']
                }
            except ImportError:
                raise ImportError("patsy required for formula-based PERMANOVA")
        
        return self.results['permanova']
    
    def calculate_pairwise_permanova(self, grouping_column, permutations=999):
        """
        Perform pairwise PERMANOVA between all groups.
        
        Args:
            grouping_column: Column name in metadata with groups
            permutations: Number of permutations
            
        Returns:
            DataFrame with pairwise results
        """
        if not HAS_SKBIO:
            raise ImportError("scikit-bio required for PERMANOVA")
        
        if grouping_column not in self.metadata.columns:
            raise ValueError(f"Column '{grouping_column}' not found in metadata")
        
        groups = self.metadata[grouping_column].unique()
        n_groups = len(groups)
        
        if n_groups < 2:
            raise ValueError("Need at least 2 groups for pairwise comparison")
        
        # Initialize results matrix
        pairwise_results = pd.DataFrame(
            index=groups,
            columns=groups,
            dtype=float
        )
        pairwise_pvalues = pd.DataFrame(
            index=groups,
            columns=groups,
            dtype=float
        )
        
        dm = DistanceMatrix(self.distance_matrix, ids=self.metadata.index.tolist())
        
        # Calculate pairwise PERMANOVA
        from itertools import combinations
        
        for group1, group2 in combinations(groups, 2):
            # Get samples in these groups
            samples1 = self.metadata[self.metadata[grouping_column] == group1].index
            samples2 = self.metadata[self.metadata[grouping_column] == group2].index
            
            if len(samples1) < 2 or len(samples2) < 2:
                warnings.warn(f"Groups {group1} or {group2} have <2 samples, skipping")
                pairwise_results.loc[group1, group2] = np.nan
                pairwise_pvalues.loc[group1, group2] = np.nan
                continue
            
            # Subset distance matrix
            subset_ids = samples1.tolist() + samples2.tolist()
            subset_dm = dm.filter(subset_ids, strict=False)
            
            # Create grouping vector
            grouping = pd.Series(
                [group1] * len(samples1) + [group2] * len(samples2),
                index=subset_ids
            )
            
            # Run PERMANOVA
            result = permanova(
                distance_matrix=subset_dm,
                grouping=grouping,
                permutations=permutations
            )
            
            pairwise_results.loc[group1, group2] = result['test statistic']
            pairwise_pvalues.loc[group1, group2] = result['p-value']
            pairwise_results.loc[group2, group1] = result['test statistic']
            pairwise_pvalues.loc[group2, group1] = result['p-value']
        
        self.results['pairwise_permanova'] = {
            'test_statistic': pairwise_results,
            'p_value': pairwise_pvalues,
            'distance_metric': self.distance_metric
        }
        
        return self.results['pairwise_permanova']
    
    def calculate_permdisp(self, grouping_column, permutations=999):
        """
        Perform PERMDISP (test for homogeneity of dispersion).
        
        Args:
            grouping_column: Column name in metadata with groups
            permutations: Number of permutations
            
        Returns:
            Dictionary with PERMDISP results
        """
        if not HAS_SKBIO:
            raise ImportError("scikit-bio required for PERMDISP")
        
        if grouping_column not in self.metadata.columns:
            raise ValueError(f"Column '{grouping_column}' not found in metadata")
        
        grouping = self.metadata[grouping_column]
        dm = DistanceMatrix(self.distance_matrix, ids=self.metadata.index.tolist())
        
        # Run PERMDISP
        result = permdisp(
            distance_matrix=dm,
            grouping=grouping,
            permutations=permutations
        )
        
        self.results['permdisp'] = {
            'grouping_column': grouping_column,
            'distance_metric': self.distance_metric,
            'test_statistic': result['test statistic'],
            'p_value': result['p-value'],
            'permutations': result['number of permutations'],
            'method': result.get('method', 'permdisp') 
        }
        
        # Calculate group-wise dispersions
        unique_groups = grouping.unique()
        group_dispersions = {}
        
        for group in unique_groups:
            group_samples = grouping[grouping == group].index
            group_dm = dm.filter(group_samples.tolist(), strict=False)
            
            # Calculate centroid and distances to centroid
            distances = []
            
            # Simplified: use mean of coordinates if available
            if hasattr(self, 'ordination_coords') and self.ordination_coords is not None:
                group_coords = self.ordination_coords.loc[group_samples]
                centroid = group_coords.mean()
                for sample in group_samples:
                    dist = np.linalg.norm(
                        self.ordination_coords.loc[sample] - centroid
                    )
                    distances.append(dist)
                mean_disp = np.mean(distances) if distances else 0
            else:
                # Fallback: use average pairwise distance within group
                if len(group_samples) > 1:
                    group_indices = [self.metadata.index.get_loc(s) for s in group_samples]
                    group_distances = self.distance_matrix[np.ix_(group_indices, group_indices)]
                    # Get upper triangle
                    triu = group_distances[np.triu_indices_from(group_distances, k=1)]
                    mean_disp = np.mean(triu) if len(triu) > 0 else 0
                else:
                    mean_disp = 0
            
            group_dispersions[group] = {
                'mean_distance_to_centroid': mean_disp,
                'n_samples': len(group_samples)
            }
        
        self.results['permdisp']['group_dispersions'] = group_dispersions
        
        return self.results['permdisp']
    
    def calculate_beta_diversity_metrics(self, grouping_column=None):
        """
        Calculate various beta diversity metrics.
        
        Args:
            grouping_column: Optional grouping column for group-wise metrics
            
        Returns:
            Dictionary with beta diversity metrics
        """
        if self.distance_matrix is None:
            raise ValueError("Distance matrix not provided")
        
        metrics = {}
        
        # Overall beta diversity
        upper_tri = self.distance_matrix[np.triu_indices_from(self.distance_matrix, k=1)]
        
        metrics['overall'] = {
            'mean_beta_diversity': np.mean(upper_tri),
            'median_beta_diversity': np.median(upper_tri),
            'std_beta_diversity': np.std(upper_tri),
            'min_beta_diversity': np.min(upper_tri),
            'max_beta_diversity': np.max(upper_tri),
            'range_beta_diversity': np.max(upper_tri) - np.min(upper_tri),
            'distance_metric': self.distance_metric
        }
        
        # Sample-wise mean beta diversity
        sample_means = []
        for i in range(len(self.distance_matrix)):
            # Mean distance to all other samples
            others = np.concatenate([self.distance_matrix[i, :i], 
                                     self.distance_matrix[i, i+1:]])
            sample_means.append(np.mean(others))
        
        metrics['sample_means'] = pd.Series(
            sample_means, 
            index=self.metadata.index if self.metadata is not None else None,
            name=f'mean_distance_{self.distance_metric}'
        )
        
        # Group-wise metrics if grouping provided
        if grouping_column and self.metadata is not None:
            if grouping_column not in self.metadata.columns:
                raise ValueError(f"Column '{grouping_column}' not found in metadata")
            
            groups = self.metadata[grouping_column].unique()
            group_metrics = {}
            
            for group in groups:
                group_samples = self.metadata[self.metadata[grouping_column] == group].index
                sample_indices = [self.metadata.index.get_loc(s) for s in group_samples]
                
                if len(sample_indices) > 1:
                    # Within-group distances
                    group_distances = self.distance_matrix[
                        np.ix_(sample_indices, sample_indices)
                    ]
                    upper_tri_group = group_distances[np.triu_indices_from(group_distances, k=1)]
                    
                    # Between-group distances (to other groups)
                    other_indices = [i for i in range(len(self.distance_matrix)) 
                                   if i not in sample_indices]
                    between_distances = self.distance_matrix[
                        np.ix_(sample_indices, other_indices)
                    ].flatten()
                    
                    group_metrics[group] = {
                        'within_group_mean': np.mean(upper_tri_group) if len(upper_tri_group) > 0 else 0,
                        'within_group_std': np.std(upper_tri_group) if len(upper_tri_group) > 0 else 0,
                        'between_group_mean': np.mean(between_distances) if len(between_distances) > 0 else 0,
                        'between_group_std': np.std(between_distances) if len(between_distances) > 0 else 0,
                        'n_samples': len(group_samples)
                    }
                else:
                    group_metrics[group] = {
                        'within_group_mean': 0,
                        'within_group_std': 0,
                        'between_group_mean': np.mean(self.distance_matrix[sample_indices[0], :]),
                        'between_group_std': np.std(self.distance_matrix[sample_indices[0], :]),
                        'n_samples': 1
                    }
            
            metrics['group_metrics'] = group_metrics
        
        self.results['beta_metrics'] = metrics
        return metrics
    
    def summary(self):
        """Print summary of all results."""
        if not self.results:
            print("No results calculated yet.")
            return
        
        print("\n" + "="*60)
        print("BETA DIVERSITY STATISTICS SUMMARY")
        print("="*60)
        
        if 'beta_metrics' in self.results:
            print("\n Overall Beta Diversity:")
            metrics = self.results['beta_metrics']['overall']
            print(f"  Distance metric: {metrics.get('distance_metric', 'unknown')}")
            print(f"  Mean: {metrics['mean_beta_diversity']:.4f}")
            print(f"  Median: {metrics['median_beta_diversity']:.4f}")
            print(f"  Std: {metrics['std_beta_diversity']:.4f}")
            print(f"  Range: {metrics['range_beta_diversity']:.4f}")
        
        if 'permanova' in self.results:
            print("\n PERMANOVA (adonis):")
            perm = self.results['permanova']
            print(f"  Distance metric: {perm.get('distance_metric', 'unknown')}")
            if perm['method'] == 'simple':
                print(f"  Grouping: {perm['grouping_column']}")
            else:
                print(f"  Formula: {perm['formula']}")
            print(f"  F-statistic: {perm['test_statistic']:.4f}")
            print(f"  P-value: {perm['p_value']:.4f}")
            print(f"  Permutations: {perm['permutations']}")
        
        if 'pairwise_permanova' in self.results:
            print("\n Pairwise PERMANOVA:")
            print(f"  Distance metric: {self.results['pairwise_permanova'].get('distance_metric', 'unknown')}")
            pairwise = self.results['pairwise_permanova']['p_value']
            print("  P-values:")
            print(pairwise.round(4))
        
        if 'permdisp' in self.results:
            print("\n PERMDISP (Homogeneity of Dispersion):")
            disp = self.results['permdisp']
            print(f"  Distance metric: {disp.get('distance_metric', 'unknown')}")
            print(f"  Grouping: {disp['grouping_column']}")
            print(f"  F-statistic: {disp['test_statistic']:.4f}")
            print(f"  P-value: {disp['p_value']:.4f}")
            
            if 'group_dispersions' in disp:
                print("\n  Group-wise dispersion:")
                for group, values in disp['group_dispersions'].items():
                    print(f"    {group}: {values['mean_distance_to_centroid']:.4f} (n={values['n_samples']})")
        
        if 'group_metrics' in self.results:
            print("\n Group-wise Beta Diversity:")
            for group, metrics in self.results['group_metrics'].items():
                print(f"\n  {group}:")
                print(f"    Within-group: {metrics['within_group_mean']:.4f} ± {metrics['within_group_std']:.4f}")
                print(f"    Between-group: {metrics['between_group_mean']:.4f} ± {metrics['between_group_std']:.4f}")
    
    def calculate_clustering_quality(self, grouping_column, permutations=999, outlier_threshold=0):
        """
        Calculate clustering quality metrics for groups defined by metadata.
        
        Args:
            grouping_column: Column name in metadata with group labels
            permutations: Number of permutations for significance testing
            outlier_threshold: Threshold for outlier detection (silhouette < threshold)
        
        Returns:
            dict: Clustering quality metrics
        """
        if grouping_column not in self.metadata.columns:
            raise ValueError(f"Column '{grouping_column}' not found in metadata")
        
        labels = self.metadata[grouping_column].values
        sample_names = self.metadata.index.tolist()
        
        # Encode labels if they're strings
        if labels.dtype == 'object':
            from sklearn.preprocessing import LabelEncoder
            le = LabelEncoder()
            labels_encoded = le.fit_transform(labels)
            label_mapping = dict(zip(le.transform(le.classes_), le.classes_))
        else:
            labels_encoded = labels
            label_mapping = None
        
        # Calculate clustering metrics
        results = cluster_quality_from_distance_matrix(
            self.distance_matrix, 
            labels_encoded,
            sample_names
        )
        
        # Add outlier threshold to results
        results['outlier_threshold'] = outlier_threshold
        
        # Add label mapping for interpretation
        if label_mapping:
            results['label_mapping'] = {int(k): v for k, v in label_mapping.items()}
        
        # Add silhouette significance test (permutation test)
        if HAS_SKLEARN and permutations > 0:
            silhouette_original = results['silhouette']
            silhouette_permuted = []
            
            for _ in range(permutations):
                permuted_labels = np.random.permutation(labels_encoded)
                try:
                    s = silhouette_from_distance_matrix(self.distance_matrix, permuted_labels)
                    silhouette_permuted.append(s)
                except:
                    continue
            
            if silhouette_permuted:
                results['silhouette_p_value'] = (
                    np.mean(np.array(silhouette_permuted) >= silhouette_original)
                )
            else:
                results['silhouette_p_value'] = np.nan  # Set to NaN if all attempts fail
        else:
            results['silhouette_p_value'] = np.nan  # Set to NaN if test not run
        
        self.results['clustering_quality'] = results
        return results
    
    def find_optimal_clusters(self, max_clusters=10, method='silhouette'):
        """
        Find optimal number of clusters using silhouette score.
        
        Args:
            max_clusters: Maximum number of clusters to test
            method: Method for optimal cluster selection ('silhouette', 'gap', 'elbow')
            
        Returns:
            dict: Optimal cluster counts and scores
        """
        if not HAS_SKLEARN:
            raise ImportError("scikit-learn required for optimal cluster finding")
        
        from sklearn.cluster import AgglomerativeClustering
        
        n_samples = self.distance_matrix.shape[0]
        
        if max_clusters >= n_samples:
            max_clusters = n_samples - 1
        
        results = {
            'n_clusters': list(range(2, min(max_clusters + 1, n_samples))),
            'silhouette_scores': [],
            'calinski_harabasz_scores': [],
            'davies_bouldin_scores': []
        }
        
        for k in results['n_clusters']:
            # Hierarchical clustering with precomputed distance
            clustering = AgglomerativeClustering(
                n_clusters=k, 
                metric='precomputed', 
                linkage='average'
            )
            labels = clustering.fit_predict(self.distance_matrix)
            
            try:
                s = silhouette_from_distance_matrix(self.distance_matrix, labels)
                results['silhouette_scores'].append(s)
            except:
                results['silhouette_scores'].append(np.nan)
            
            try:
                ch = calinski_harabasz_from_distance_matrix(self.distance_matrix, labels)
                results['calinski_harabasz_scores'].append(ch)
            except:
                results['calinski_harabasz_scores'].append(np.nan)
            
            try:
                db = davies_bouldin_from_distance_matrix(self.distance_matrix, labels)
                results['davies_bouldin_scores'].append(db)
            except:
                results['davies_bouldin_scores'].append(np.nan)
        
        # Find optimal k based on method
        if method == 'silhouette':
            valid_scores = [(k, s) for k, s in zip(results['n_clusters'], results['silhouette_scores']) 
                          if not np.isnan(s)]
            if valid_scores:
                optimal_k = max(valid_scores, key=lambda x: x[1])[0]
            else:
                optimal_k = 2
        elif method == 'calinski_harabasz':
            valid_scores = [(k, s) for k, s in zip(results['n_clusters'], results['calinski_harabasz_scores']) 
                          if not np.isnan(s)]
            if valid_scores:
                optimal_k = max(valid_scores, key=lambda x: x[1])[0]
            else:
                optimal_k = 2
        elif method == 'davies_bouldin':
            valid_scores = [(k, s) for k, s in zip(results['n_clusters'], results['davies_bouldin_scores']) 
                          if not np.isnan(s)]
            if valid_scores:
                optimal_k = min(valid_scores, key=lambda x: x[1])[0]
            else:
                optimal_k = 2
        else:
            raise ValueError(f"Unknown method: {method}")
        
        results['optimal_n_clusters'] = optimal_k
        results['optimal_method'] = method
        
        self.results['optimal_clusters'] = results
        return results

    def print_clustering_report(self, grouping_column):
        """
        Print formatted clustering quality report.
        
        Args:
            grouping_column: Column name in metadata with group labels
        """
        if 'clustering_quality' not in self.results:
            self.calculate_clustering_quality(grouping_column)
        
        results = self.results['clustering_quality']
        report = format_clustering_report(results)
        print(report)
        return report


def interpret_clustering_quality(results, outlier_threshold=0):
    """
    Provide interpretative text for clustering quality metrics.
    
    Args:
        results: Dictionary from cluster_quality_from_distance_matrix()
        outlier_threshold: Threshold for outlier detection (default: 0)
    
    Returns:
        list: Interpretive statements about clustering quality
        dict: Summary scores with categories
    """
    interpretations = []
    summary = {
        'silhouette_category': None,
        'ratio_category': None,
        'significance_category': None,
        'overall_quality': None
    }
    
    # Silhouette interpretation
    s = results.get('silhouette', 0)
    if s > 0.7:
        interpretations.append(f"✓ Excellent clustering (silhouette={s:.3f}): Groups are very well-separated")
        summary['silhouette_category'] = 'excellent'
    elif s > 0.5:
        interpretations.append(f"✓ Good clustering (silhouette={s:.3f}): Groups show clear separation")
        summary['silhouette_category'] = 'good'
    elif s > 0.25:
        interpretations.append(f"⚠ Fair clustering (silhouette={s:.3f}): Groups show moderate overlap")
        summary['silhouette_category'] = 'fair'
    elif s > 0:
        interpretations.append(f"⚠ Poor clustering (silhouette={s:.3f}): Groups substantially overlap")
        summary['silhouette_category'] = 'poor'
    else:
        interpretations.append(f"✗ Very poor clustering (silhouette={s:.3f}): Samples may be misclassified")
        summary['silhouette_category'] = 'very_poor'
    
    # Calinski-Harabasz interpretation (if available)
    ch = results.get('calinski_harabasz')
    if ch is not None:
        if ch > 1000:
            interpretations.append(f"✓ Excellent separation (CH={ch:.1f}): Very strong cluster structure")
        elif ch > 100:
            interpretations.append(f"✓ Good separation (CH={ch:.1f}): Clear cluster structure")
        elif ch > 10:
            interpretations.append(f"⚠ Moderate separation (CH={ch:.1f}): Some cluster structure")
        else:
            interpretations.append(f"⚠ Weak separation (CH={ch:.1f}): Limited cluster structure")
    
    # Davies-Bouldin interpretation (if available)
    db = results.get('davies_bouldin')
    if db is not None:
        if db < 0.5:
            interpretations.append(f"✓ Excellent compactness (DB={db:.3f}): Very well-defined clusters")
        elif db < 1.0:
            interpretations.append(f"✓ Good compactness (DB={db:.3f}): Well-defined clusters")
        elif db < 1.5:
            interpretations.append(f"⚠ Fair compactness (DB={db:.3f}): Some cluster overlap")
        else:
            interpretations.append(f"⚠ Poor compactness (DB={db:.3f}): Substantial cluster overlap")
    
    # Within/Between ratio interpretation
    ratio = results.get('ratio_between_within', 0)
    if ratio > 2:
        interpretations.append(f"✓ Strong separation (ratio={ratio:.2f}): Between-group distances > 2× within-group")
        summary['ratio_category'] = 'excellent'
    elif ratio > 1.5:
        interpretations.append(f"✓ Good separation (ratio={ratio:.2f}): Groups are clearly distinct")
        summary['ratio_category'] = 'good'
    elif ratio > 1.1:
        interpretations.append(f"⚠ Moderate separation (ratio={ratio:.2f}): Groups show some overlap")
        summary['ratio_category'] = 'fair'
    else:
        interpretations.append(f"⚠ Poor separation (ratio={ratio:.2f}): Groups not well-separated")
        summary['ratio_category'] = 'poor'
    
    # Statistical significance
    p = results.get('silhouette_p_value', 1)
    if p < 0.001:
        interpretations.append(f"✓ Highly significant (p={p:.4f}): Group structure is very robust")
        summary['significance_category'] = 'highly_significant'
    elif p < 0.01:
        interpretations.append(f"✓ Very significant (p={p:.4f}): Strong statistical support")
        summary['significance_category'] = 'very_significant'
    elif p < 0.05:
        interpretations.append(f"✓ Significant (p={p:.4f}): Statistically supported")
        summary['significance_category'] = 'significant'
    elif p < 0.10:
        interpretations.append(f"⚠ Marginally significant (p={p:.4f}): Weak statistical support")
        summary['significance_category'] = 'marginal'
    else:
        interpretations.append(f"⚠ Not significant (p={p:.4f}): Group structure may be random")
        summary['significance_category'] = 'not_significant'
    
    # Overall quality assessment
    if (summary['silhouette_category'] in ['excellent', 'good'] and 
        summary['ratio_category'] in ['excellent', 'good'] and
        summary['significance_category'] in ['highly_significant', 'very_significant', 'significant']):
        summary['overall_quality'] = 'high_confidence'
        interpretations.insert(0, "✓ Overall: HIGH CONFIDENCE clustering - groups are well-separated and statistically robust")
    elif (summary['silhouette_category'] in ['fair'] or 
          summary['ratio_category'] in ['fair'] or
          summary['significance_category'] in ['marginal']):
        summary['overall_quality'] = 'moderate_confidence'
        interpretations.insert(0, "⚠ Overall: MODERATE CONFIDENCE clustering - groups show some structure but with overlap")
    else:
        summary['overall_quality'] = 'low_confidence'
        interpretations.insert(0, "⚠ Overall: LOW CONFIDENCE clustering - groups are poorly separated or not significant")
    
    return interpretations, summary


def format_clustering_report(results, outlier_threshold=0):
    """
    Format clustering quality results as a readable report string.
    
    Args:
        results: Dictionary from cluster_quality_from_distance_matrix()
        outlier_threshold: Threshold for outlier detection (samples with silhouette < threshold)
    
    Returns:
        str: Formatted report
    """
    interpretations, summary = interpret_clustering_quality(results, outlier_threshold)
    
    report = []
    report.append("\n" + "="*70)
    report.append("CLUSTERING QUALITY ASSESSMENT REPORT")
    report.append("="*70)
    
    # Main metrics table
    report.append("\n KEY METRICS:")
    report.append("-" * 50)
    report.append(f"  Silhouette score:        {results.get('silhouette', 0):.4f}  ({summary['silhouette_category']})")
    if results.get('calinski_harabasz'):
        report.append(f"  Calinski-Harabasz:       {results.get('calinski_harabasz', 0):.2f}")
    if results.get('davies_bouldin'):
        report.append(f"  Davies-Bouldin:          {results.get('davies_bouldin', 0):.4f}")
    report.append(f"  Between/Within ratio:    {results.get('ratio_between_within', 0):.2f}  ({summary['ratio_category']})")
    report.append(f"  Significance (p-value):  {results.get('silhouette_p_value', 1):.6f}  ({summary['significance_category']})")
    
    # Interpretations
    report.append("\n DETAILED INTERPRETATION:")
    report.append("-" * 50)
    for interp in interpretations[1:]:  # Skip the overall line we already added
        report.append(f"  {interp}")
    
    # Outlier detection using the passed threshold
    if results.get('silhouette_per_sample'):
        # Use the passed outlier_threshold
        negative_samples = [(s, sc) for s, sc in results['silhouette_per_sample'].items() if sc < outlier_threshold]
        
        if negative_samples:
            report.append("\n⚠ OUTLIER DETECTION:")
            report.append("-" * 50)
            report.append(f"  Found {len(negative_samples)} sample(s) with silhouette < {outlier_threshold} (potentially misclassified):")
            for sample, score in sorted(negative_samples, key=lambda x: x[1])[:5]:
                report.append(f"    • {sample}: {score:.4f}")
            if len(negative_samples) > 5:
                report.append(f"    ... and {len(negative_samples) - 5} more")
        
        # Also show low samples if threshold > 0 and we want to distinguish
        if outlier_threshold < 0.2 and outlier_threshold > 0:
            low_samples = [(s, sc) for s, sc in results['silhouette_per_sample'].items() 
                          if 0 <= sc < 0.2 and sc >= outlier_threshold]
            if low_samples:
                report.append("\n⚠ BOUNDARY CASES:")
                report.append("-" * 50)
                report.append(f"  Found {len(low_samples)} sample(s) with weak cluster assignment (0 ≤ silhouette < 0.2):")
                for sample, score in sorted(low_samples, key=lambda x: x[1])[:5]:
                    report.append(f"    • {sample}: {score:.4f}")
    
    # Recommendations
    report.append("\n RECOMMENDATIONS:")
    report.append("-" * 50)
    
    if summary['overall_quality'] == 'high_confidence':
        report.append("  ✓ Groups are well-defined and statistically robust")
        report.append("  ✓ Proceed with downstream analyses (differential abundance, etc.)")
        report.append("  ✓ Consider using these groups as factors in PERMANOVA")
    elif summary['overall_quality'] == 'moderate_confidence':
        report.append("  ⚠ Groups show some structure but with overlap")
        report.append("  ⚠ Consider alternative grouping strategies or additional metadata")
        report.append("  ⚠ Validate with independent methods (e.g., random forest classification)")
    else:
        report.append("  ✗ Groups are poorly separated or not statistically significant")
        report.append("  ✗ Consider: alternative distance metrics, different clustering methods")
        report.append("  ✗ Consider: removing outliers, adding more samples, or revising group definitions")
    
    # Recommendations based on specific metrics
    if results.get('silhouette', 0) < 0.25 and results.get('ratio_between_within', 0) < 1.2:
        report.append("  ✗ Clustering may not be meaningful - groups may not represent distinct communities")
    
    if results.get('silhouette_p_value', 1) > 0.05 and results.get('silhouette', 0) < 0.5:
        report.append("  ✗ Statistical support is weak - consider larger sample sizes")
    
    report.append("\n" + "="*70)
    
    return "\n".join(report)
    