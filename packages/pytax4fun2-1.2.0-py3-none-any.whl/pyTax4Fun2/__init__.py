"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.
"""

__version__ = "1.2.0"
__author__ = "Ninda Rachmadani, Maulana Malik Nashrulloh, Irfan Mustafa, Brian Rahardi, Choirul Ainiyati, Khalid Hafazallah, Reza Raihandhany, Muhammad Badrut Tamam"
__maintainer__ = "Maulana Malik Nashrulloh"
__maintainer_email__ = "maulana@genbinesia.or.id"

from .assign_function import assign_function, assign_function_batch, merge_functional_profiles
from .build_dependencies import build_dependencies, build_dependencies_bioconda
from .build_reference_data import build_reference_data
from .calculate_functional_redundancy import calculate_functional_redundancy
from .citation import pyTax4Fun2_citation, Tax4Fun2_original_citation, generate_citation_report
from .config import pyTax4Fun2Config, config
from .extract_ssu import extract_ssu, validate_16s_sequences_polars
from .fasta_utils import *
from .generate_user_data import generate_user_data
from .generate_user_data_by_clustering import generate_user_data_by_clustering

from .make_functional_prediction import make_functional_prediction
from .run_ref_blast import run_ref_blast
from .tool_manager import ToolManager, get_tool_manager
from .utils import *

# Visualization imports
try:
    from .plot_functional_profiles import (
        plot_heatmap, plot_functional_redundancy, plot_pathway_abundance
    )
    from .plot_diversity import (
        plot_alpha_diversity, 
        plot_beta_diversity,
        plot_alpha_diversity_rarefaction,  # New
        ALPHA_METRIC_GROUPS                 # New
    )
    from .plot_ssu import plot_16s_extraction_summary, plot_16s_quality_control
    from .plot_comparative import plot_differential_abundance, plot_correlation_network
    
    HAS_VISUALIZATION = True
except ImportError as e:
    HAS_VISUALIZATION = False
    warnings.warn(
        f"Visualization modules not available: {e}\n"
        "Install required packages: pip install matplotlib seaborn scikit-learn umap-learn networkx"
    )

__all__ = [
    # Main functions
    "assign_function",
    "assign_function_batch",
    "merge_functional_profiles",
    "build_dependencies",
    "build_dependencies_bioconda",
    "build_reference_data",
    "test_reference_data",
    "calculate_functional_redundancy",
    "pyTax4Fun2_citation",
    "Tax4Fun2_original_citation",
    "generate_citation_report",
    "pyTax4Fun2Config",
    "config",
    "extract_ssu",
    "validate_16s_sequences_polars",
    "generate_user_data",
    "generate_user_data_by_clustering",
    "create_minimal_example_data",
    "make_functional_prediction",
    "run_ref_blast",
    "plot_alpha_diversity",
    "plot_alpha_diversity_rarefaction",  # New
    "plot_beta_diversity",
    "ALPHA_METRIC_GROUPS",  # New
    
    # Tool management
    "ToolManager",
    "get_tool_manager",
    "verify_all_tools",
    "get_tool_path",
    "test_tool",
    
    # FASTA utilities
    "read_fasta_polars",
    "write_fasta_polars",
    "fasta_stats",
    "extract_sequences_from_fasta",
    "merge_fasta_files",
    
    # Error classes
    "pyTax4Fun2Error",
    
    # Version
    "__version__",
]
