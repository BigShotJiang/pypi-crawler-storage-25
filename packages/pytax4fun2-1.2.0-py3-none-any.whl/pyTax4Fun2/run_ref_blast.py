"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Run BLAST search against reference databases with optimizations.
"""

import subprocess
import shutil
from pathlib import Path
from typing import Optional, Union, List, Dict
import tempfile
import concurrent.futures
import warnings

import polars as pl
import numpy as np

from .utils import (
    validate_file, validate_directory, get_tool_path, test_tool,
    filter_unique_blast_hits, run_command, pyTax4Fun2Error,
    check_memory_available, parallel_apply
)


def run_ref_blast(
    path_to_otus: str,
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    path_to_temp_folder: str = "pyTax4Fun2_prediction",
    database_mode: str = 'Ref100NR',
    use_force: bool = False,
    num_threads: int = 1,
    include_user_data: bool = False,
    path_to_user_data: str = '',
    name_of_user_data: str = "",
    evalue: float = 1e-20,
    max_target_seqs: int = 1000000,
    query_chunk_size: int = 1000,  # New: Split large query files
    parallel_blasts: bool = True,  # New: Run BLASTs in parallel
    blast_mode: str = "normal",  # New: "normal", "megablast", "dc-megablast"
    output_format: str = "6",  # New: Allow different output formats
    extra_blast_params: Optional[List[str]] = None  # New: Custom BLAST params
) -> Dict[str, Union[str, int, List[str]]]:
    """
    Run BLAST search against reference databases with optimizations.
    
    Args:
        path_to_otus: Path to OTU sequences (FASTA format)
        path_to_reference_data: Path to reference data
        path_to_temp_folder: Path for temporary files
        database_mode: Database mode: 'Ref99NR' or 'Ref100NR'
        use_force: Overwrite existing temporary folder
        num_threads: Number of threads for BLAST
        include_user_data: Include user-defined reference data
        path_to_user_data: Path to user data directory
        name_of_user_data: Name of user data directory
        evalue: BLAST e-value cutoff
        max_target_seqs: Maximum number of target sequences
        query_chunk_size: Split large query files into chunks
        parallel_blasts: Run reference and user BLAST in parallel
        blast_mode: BLAST algorithm mode
        output_format: BLAST output format
        extra_blast_params: Additional BLAST parameters
        
    Returns:
        Dict with results metadata
    """
    # Validate inputs
    validate_file(path_to_otus, "OTU sequences file")
    validate_directory(path_to_reference_data, "Reference data directory")
    
    if database_mode not in ['Ref99NR', 'Ref100NR']:
        raise pyTax4Fun2Error("database_mode must be 'Ref99NR' or 'Ref100NR'")
    
    if num_threads < 1:
        raise pyTax4Fun2Error("num_threads must be >= 1")
    
    # Handle temporary folder
    temp_path = Path(path_to_temp_folder)
    if temp_path.exists():
        if use_force:
            shutil.rmtree(temp_path)
        else:
            raise pyTax4Fun2Error(
                f"Temporary folder exists: {temp_path}. Use use_force=True to overwrite."
            )
    
    temp_path.mkdir(parents=True, exist_ok=True)
    
    # Get BLAST binary paths
    try:
        blast_path = get_tool_path("blastn", path_to_reference_data)
        makeblastdb_path = get_tool_path("makeblastdb", path_to_reference_data)
    except Exception as e:
        raise pyTax4Fun2Error(f"Failed to get BLAST tools: {str(e)}")
    
    # Test tools
    if not test_tool(blast_path):
        raise pyTax4Fun2Error(f"blastn not executable: {blast_path}")
    if not test_tool(makeblastdb_path):
        raise pyTax4Fun2Error(f"makeblastdb not executable: {makeblastdb_path}")
    
    # Create log file with metadata
    log_file = temp_path / 'logfile1.txt'
    with open(log_file, 'w') as f:
        f.write(f"RefBlast\n{database_mode}\n{Path(path_to_otus).absolute()}\n")
        f.write(f"Threads: {num_threads}\n")
        f.write(f"E-value: {evalue}\n")
        f.write(f"Max target seqs: {max_target_seqs}\n")
        if include_user_data:
            f.write("User data will be included\n")
        else:
            f.write("No user data\n")
    
    # Check if we should split the query file
    query_size = Path(path_to_otus).stat().st_size
    split_queries = []
    
    if query_size > 50 * 1024 * 1024:  # > 50MB
        print(f"Large query file ({query_size/1024/1024:.1f} MB), splitting...")
        split_queries = split_query_file(path_to_otus, temp_path, query_chunk_size)
    else:
        split_queries = [Path(path_to_otus)]
    
    # Prepare databases
    ref_db_info = prepare_database(
        database_mode, path_to_reference_data, makeblastdb_path, "reference"
    )
    
    user_db_info = None
    if include_user_data:
        user_db_info = prepare_user_database(
            path_to_user_data, name_of_user_data, temp_path, makeblastdb_path
        )
    
    # Run BLAST searches
    results = {}
    
    if parallel_blasts and user_db_info:
        # Run reference and user BLAST in parallel
        print("Running reference and user BLAST searches in parallel...")
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            # Submit reference BLAST
            ref_future = executor.submit(
                run_blast_search,
                split_queries, ref_db_info, blast_path, temp_path,
                evalue, max_target_seqs, num_threads, blast_mode,
                output_format, extra_blast_params, "ref"
            )
            
            # Submit user BLAST
            user_future = executor.submit(
                run_blast_search,
                split_queries, user_db_info, blast_path, temp_path,
                evalue, max_target_seqs, num_threads, blast_mode,
                output_format, extra_blast_params, "user"
            )
            
            # Get results
            ref_results = ref_future.result()
            user_results = user_future.result()
            
            results["reference"] = ref_results
            results["user"] = user_results
            
    else:
        # Run sequentially
        print("Running reference BLAST search...")
        ref_results = run_blast_search(
            split_queries, ref_db_info, blast_path, temp_path,
            evalue, max_target_seqs, num_threads, blast_mode,
            output_format, extra_blast_params, "ref"
        )
        results["reference"] = ref_results
        
        if user_db_info:
            print("Running user BLAST search...")
            user_results = run_blast_search(
                split_queries, user_db_info, blast_path, temp_path,
                evalue, max_target_seqs, num_threads, blast_mode,
                output_format, extra_blast_params, "user"
            )
            results["user"] = user_results
    
    # Merge results if we split queries
    if len(split_queries) > 1:
        merge_blast_results(temp_path, results)
    
    # Clean up split query files
    for query_file in split_queries[1:]:  # Skip original
        if query_file.exists():
            query_file.unlink()
    
    # Generate summary statistics
    summary = generate_blast_summary(temp_path, results)
    
    print(f"\nBLAST search complete! Results in: {temp_path}")
    # print(f"Total hits: {summary.get('total_hits', 0)}")
    # print(f"Unique queries with hits: {summary.get('unique_queries', 0)}") #TODO This thing buggy somehow, idk
    
    return {
        "temp_directory": str(temp_path),
        "results": results,
        "summary": summary,
        "parameters": {
            "database_mode": database_mode,
            "evalue": evalue,
            "threads": num_threads,
            "max_target_seqs": max_target_seqs
        }
    }


def split_query_file(
    query_path: str,
    temp_dir: Path,
    chunk_size: int = 1000
) -> List[Path]:
    """
    Split large query FASTA file into smaller chunks.
    
    Args:
        query_path: Path to query FASTA file
        temp_dir: Temporary directory for chunks
        chunk_size: Sequences per chunk
        
    Returns:
        List[Path]: Paths to chunk files
    """
    from Bio import SeqIO
    import itertools
    
    query_path = Path(query_path)
    chunk_files = []
    
    with open(query_path) as f:
        records = SeqIO.parse(f, "fasta")
        
        for chunk_num, chunk in enumerate(iter(lambda: list(itertools.islice(records, chunk_size)), []), 1):
            if not chunk:
                break
            
            chunk_file = temp_dir / f"query_chunk_{chunk_num}.fasta"
            SeqIO.write(chunk, chunk_file, "fasta")
            chunk_files.append(chunk_file)
    
    return chunk_files


def prepare_database(
    database_mode: str,
    ref_path: str,
    makeblastdb_path: Path,
    db_type: str = "reference"
) -> Dict:
    """
    Prepare BLAST database and return metadata.
    
    Args:
        database_mode: 'Ref99NR' or 'Ref100NR'
        ref_path: Path to reference data
        makeblastdb_path: Path to makeblastdb
        db_type: Type of database
        
    Returns:
        Dict: Database information
    """
    ref_path = Path(ref_path)
    
    if database_mode == 'Ref99NR':
        ref_db_fasta = ref_path / 'Ref99NR' / 'Ref99NR.fasta'
        db_name = "Ref99NR"
    else:
        ref_db_fasta = ref_path / 'Ref100NR' / 'Ref100NR.fasta'
        db_name = "Ref100NR"
    
    if not ref_db_fasta.exists():
        raise pyTax4Fun2Error(f"{db_type} database not found: {ref_db_fasta}")
    
    # Check if BLAST database already exists
    db_extensions = ['.nsq', '.nin', '.nhr']
    db_files = [ref_db_fasta.with_suffix(ext) for ext in db_extensions]
    
    if not all(f.exists() for f in db_files):
        print(f"  Creating BLAST database for {db_name}...")
        makeblastdb_cmd = [
            str(makeblastdb_path), '-dbtype', 'nucl',
            '-in', str(ref_db_fasta),
            '-parse_seqids'  # Better for large databases
        ]
        returncode, stdout, stderr = run_command(makeblastdb_cmd, verbose=False)
        if returncode != 0:
            raise pyTax4Fun2Error(f"Failed to create BLAST database: {stderr}")
        print(f"  BLAST database created for {db_name}")
    else:
        print(f"  Using existing BLAST database for {db_name}")
    
    return {
        "path": ref_db_fasta,
        "name": db_name,
        "type": db_type,
        "size": ref_db_fasta.stat().st_size
    }


def prepare_user_database(
    path_to_user_data: str,
    name_of_user_data: str,
    temp_dir: Path,
    makeblastdb_path: Path
) -> Optional[Dict]:
    """
    Prepare user database for BLAST.
    
    Args:
        path_to_user_data: Path to user data directory
        name_of_user_data: Name of user data directory
        temp_dir: Temporary directory
        makeblastdb_path: Path to makeblastdb
        
    Returns:
        Optional[Dict]: User database info or None
    """
    if not path_to_user_data or not name_of_user_data:
        return None
    
    user_data_dir = Path(path_to_user_data) / name_of_user_data
    if not user_data_dir.exists():
        raise pyTax4Fun2Error(f"User data directory not found: {user_data_dir}")
    
    user_db_fasta = user_data_dir / 'USER.fasta'
    if not user_db_fasta.exists():
        raise pyTax4Fun2Error(f"User database not found: {user_db_fasta}")
    
    # Copy to temporary location
    user_db_temp = temp_dir / 'user_blast.fasta'
    shutil.copy2(user_db_fasta, user_db_temp)
    
    # Create BLAST database
    print("  Creating user BLAST database...")
    makeblastdb_cmd = [
        str(makeblastdb_path), '-dbtype', 'nucl',
        '-in', str(user_db_temp),
        '-parse_seqids'
    ]
    returncode, stdout, stderr = run_command(makeblastdb_cmd, verbose=False)
    if returncode != 0:
        raise pyTax4Fun2Error(f"Failed to create user BLAST database: {stderr}")
    
    return {
        "path": user_db_temp,
        "name": "USER",
        "type": "user",
        "size": user_db_temp.stat().st_size
    }


def run_blast_search(
    query_files: List[Path],
    db_info: Dict,
    blast_path: Path,
    temp_dir: Path,
    evalue: float,
    max_target_seqs: int,
    num_threads: int,
    blast_mode: str,
    output_format: str,
    extra_params: Optional[List[str]],
    prefix: str
) -> Dict:
    """
    Run BLAST search for a set of query files.
    
    Args:
        query_files: List of query FASTA files
        db_info: Database information
        blast_path: Path to blastn
        temp_dir: Temporary directory
        evalue: E-value cutoff
        max_target_seqs: Max target sequences
        num_threads: Number of threads
        blast_mode: BLAST mode
        output_format: Output format
        extra_params: Extra BLAST parameters
        prefix: Output file prefix
        
    Returns:
        Dict: BLAST results metadata
    """
    results = []
    
    for query_file in query_files:
        # Determine output file name
        if len(query_files) == 1:
            output_file = temp_dir / f'{prefix}_blast.txt'
        else:
            chunk_num = query_file.stem.split('_')[-1]
            output_file = temp_dir / f'{prefix}_blast_chunk{chunk_num}.txt'
        
        # Build BLAST command
        blast_cmd = [
            str(blast_path),
            '-db', str(db_info["path"]),
            '-query', str(query_file),
            '-evalue', str(evalue),
            '-max_target_seqs', str(max_target_seqs),
            '-outfmt', output_format,
            '-out', str(output_file),
            '-num_threads', str(num_threads),
            '-strand', 'both'  # ← ADD THIS LINE
        ]
        
        # Add blast mode
        if blast_mode == "megablast":
            blast_cmd.append('-task')
            blast_cmd.append('megablast')
        elif blast_mode == "dc-megablast":
            blast_cmd.append('-task')
            blast_cmd.append('dc-megablast')
        
        # Add extra parameters if provided
        if extra_params:
            blast_cmd.extend(extra_params)
        
        # Run BLAST
        returncode, stdout, stderr = run_command(blast_cmd, verbose=False)
        
        if returncode != 0:
            warnings.warn(f"BLAST command had non-zero exit: {stderr}")
        
        # Process results if file exists
        if output_file.exists() and output_file.stat().st_size > 0:
            try:
                blast_df = pl.read_csv(
                    output_file,
                    separator="\t",
                    has_header=False,
                    new_columns=["qseqid", "sseqid", "pident", "length", 
                                "mismatch", "gapopen", "qstart", "qend",
                                "sstart", "send", "evalue", "bitscore"],
                    schema_overrides={
                        # String columns
                        "qseqid": pl.Utf8,
                        "sseqid": pl.Utf8,
                        
                        # Float columns
                        "pident": pl.Float64,
                        "evalue": pl.Float64,
                        "bitscore": pl.Float64,  # ← This was the problem
                        
                        # Integer columns
                        "length": pl.Int64,
                        "mismatch": pl.Int64,
                        "gapopen": pl.Int64,
                        "qstart": pl.Int64,
                        "qend": pl.Int64,
                        "sstart": pl.Int64,
                        "send": pl.Int64,
                    },
                    ignore_errors=True,  # Skip problematic rows
                    infer_schema_length=10000
                )
                
                # Filter unique hits
                unique_df = filter_unique_blast_hits(blast_df)
                unique_df.write_csv(output_file, separator="\t", include_header=False)
                
            except Exception as e:
                warnings.warn(f"Error processing BLAST results {output_file}: {str(e)}")
                results.append({
                    "file": output_file,
                    "error": str(e),
                    "chunk": query_file.name
                })
        else:
            warnings.warn(f"No BLAST output generated: {output_file}")
            results.append({
                "file": output_file,
                "error": "Empty output",
                "chunk": query_file.name
            })
    
    return {
        "database": db_info["name"],
        "type": db_info["type"],
        "chunk_results": results,
        "total_hits": sum(r.get("total_hits", 0) for r in results),  # ← Fix: use "total_hits"
        "unique_hits": sum(r.get("unique_hits", 0) for r in results),  # ← Add this for reference
        "total_chunks": len(results)
    }   


def merge_blast_results(temp_dir: Path, results: Dict) -> None:
    """
    Merge BLAST results from multiple chunks.
    
    Args:
        temp_dir: Temporary directory
        results: BLAST results dictionary
    """
    for db_type in ["reference", "user"]:
        if db_type in results:
            chunk_results = results[db_type]["chunk_results"]
            
            if len(chunk_results) > 1:
                # Combine all chunk files
                all_dfs = []
                for chunk_info in chunk_results:
                    chunk_file = chunk_info.get("file")
                    if chunk_file and chunk_file.exists():
                        try:
                            df = pl.read_csv(chunk_file, separator="\t", has_header=False)
                            all_dfs.append(df)
                        except Exception as e:
                            warnings.warn(f"Error reading chunk {chunk_file}: {str(e)}")
                
                if all_dfs:
                    # Concatenate and deduplicate
                    combined_df = pl.concat(all_dfs)
                    unique_df = filter_unique_blast_hits(combined_df)
                    
                    # Write final file
                    final_file = temp_dir / f'{db_type}_blast.txt'
                    unique_df.write_csv(final_file, separator="\t", include_header=False)
                    
                    # Update results
                    results[db_type]["final_file"] = str(final_file)
                    results[db_type]["final_hits"] = unique_df.height
                    
                    # Clean up chunk files
                    for chunk_info in chunk_results:
                        chunk_file = chunk_info.get("file")
                        if chunk_file and chunk_file.exists() and chunk_file != final_file:
                            chunk_file.unlink()


def generate_blast_summary(temp_dir: Path, results: Dict) -> Dict:
    summary = {
        "total_hits": 0,
        "unique_queries": set(),
        "databases_used": [],
        "output_files": [],
        "unique_queries_count": 0
    }
    
    for db_type, db_results in results.items():
        # Check if we have chunk results with hit counts
        if isinstance(db_results, dict) and "chunk_results" in db_results:
            for chunk in db_results["chunk_results"]:
                if "total_hits" in chunk:
                    summary["total_hits"] += chunk["total_hits"]
                if "file" in chunk:
                    summary["output_files"].append(str(chunk["file"]))
        
        # Also check for final file
        if "final_file" in db_results:
            final_file = Path(db_results["final_file"])
            summary["output_files"].append(str(final_file))
            
            if final_file.exists() and final_file.stat().st_size > 0:
                try:
                    # Simple line count (fast)
                    with open(final_file, 'r') as f:
                        line_count = sum(1 for line in f if line.strip())
                    
                    # Use the larger of the two counts
                    if line_count > summary["total_hits"]:
                        summary["total_hits"] = line_count
                    
                    # Get unique queries (first column)
                    queries = set()
                    with open(final_file, 'r') as f:
                        for line in f:
                            if line.strip():
                                queries.add(line.split('\t')[0])
                    
                    summary["unique_queries"] = queries
                    summary["unique_queries_count"] = len(queries)
                    
                    # Add database info
                    summary["databases_used"].append({
                        "name": db_results.get("database", db_type),
                        "type": db_results.get("type", "unknown"),
                        "hits": line_count
                    })
                    
                except Exception as e:
                    warnings.warn(f"Error reading final file for stats: {str(e)}")
    
    summary["unique_queries_count"] = len(summary["unique_queries"])
    return summary
