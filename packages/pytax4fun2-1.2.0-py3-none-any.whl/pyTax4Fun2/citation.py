"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Citation information for pyTax4Fun2 with enhanced features.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Union
from datetime import datetime


def pyTax4Fun2_citation(
    format: str = "text",
    version: str = "1.2",
    return_only: bool = False,
    include_dependencies: bool = False,  # New: Include citations for dependencies
    output_file: Optional[Union[str, Path]] = None,  # New: Write to file
    bibtex_key: Optional[str] = None  # New: Custom BibTeX key
) -> Union[str, Dict]:
    """
    Return citation information for pyTax4Fun2 with enhanced features.
    
    Args:
        format: Citation format: "text", "bibtex", "apa", "ris", "json"
        version: Software version
        return_only: If True, returns citation without printing
        include_dependencies: Include citations for dependencies
        output_file: Write citation to file
        bibtex_key: Custom BibTeX citation key
        
    Returns:
        str or Dict: Citation string or dictionary
    """
    # Default BibTeX key
    if bibtex_key is None:
        bibtex_key = f"pyTax4Fun2_{version.replace('.', '_')}"
    
    # Main citation
    citations = {
        "text": f"""
================================================================================
pyTax4Fun2: A Python Tool for functional profiling and redundancy analysis 
of bacterial communities via 16S rRNA gene sequences, featuring
Polars for efficient processing of Large genomic datasets

Authors:   Maulana Malik Nashrulloh, Brian Rahardi
Version:   {version}
Preprint:  -
DOI:       -
Year:      2026

Please cite this work if you use pyTax4Fun2 in your research.
For updates and documentation: https://gitlab.com/biomikalab/pyTax4Fun2
================================================================================
""",
        
        "bibtex": f"""@techreport{{{bibtex_key},
  title = {{pyTax4Fun2: A Python Tool for functional profiling and redundancy analysis of bacterial communities via 16S rRNA gene sequences, featuring Polars for efficient processing of large genomic datasets}},
  author = {{Nashrulloh, Maulana Malik and Rahardi, Brian}},
  year = {{2026}},
  type = {{Technical Report}},
  number = {{GBR-TR-BIOMIKA-02/Genbinesia/I/2026}},
  institution = {{Generasi Biologi Indonesia Foundation}},
  address = {{Gresik, Indonesia}}
}}""",
        
        "apa": """Nashrulloh, M. M., & Rahardi, B. (2026). 
        pyTax4Fun2: A Python tool for functional profiling and redundancy analysis of bacterial communities via 16S rRNA gene sequences, featuring Polars for efficient processing of large genomic datasets 
        (Technical Report No. GBR-TR-BIOMIKA-02/Genbinesia/I/2026). 
        Generasi Biologi Indonesia Foundation.""",
        
        "ris": """TY  - TECH
AU  - Nashrulloh, Maulana Malik
AU  - Rahardi, Brian
PY  - 2026
TI  - pyTax4Fun2: A Python Tool for functional profiling and redundancy analysis of bacterial communities via 16S rRNA gene sequences, featuring Polars for efficient processing of Large genomic datasets
T2  - Technical Report
AB  - A Python tool for functional profiling and redundancy analysis of bacterial communities using 16S rRNA gene sequences, featuring the Polars module for efficient processing of large genomic datasets
IS  - GBR-TR-BIOMIKA-02/Genbinesia/I/2026
PB  - Generasi Biologi Indonesia Foundation
CY  - Gresik, Indonesia
ER  -""",
        
        "json": {
            "type": "techreport",
            "title": "pyTax4Fun2: A Python Tool for functional profiling and redundancy analysis of bacterial communities via 16S rRNA gene sequences, featuring Polars for efficient processing of Large genomic datasets",
            "authors": [
                {
                    "family": "Nashrulloh",
                    "given": "Maulana Malik"
                    },
                {
                    "family": "Rahardi",
                    "given": "Brian"
                    }
                ],
            "issued": {
                "date-parts": [[2026]]
                },
            "publisher": "Generasi Biologi Indonesia Foundation",
            "publisher-place": "Gresik, Indonesia",
            "number": "GBR-TR-BIOMIKA-02/Genbinesia/I/2026",
            "genre": "Technical Report",
            "version": version,
            "retrieved": datetime.now().isoformat()
        }
    }
    
    # Add dependency citations if requested
    if include_dependencies:
        deps_citation = _get_dependency_citations(format)
        if format == "text":
            citations[format] += "\n\n" + deps_citation
        elif format == "bibtex":
            citations[format] += "\n\n" + deps_citation
        elif format == "json":
            citations[format]["dependencies"] = json.loads(deps_citation) if deps_citation.startswith("{") else deps_citation
    
    # Validate format
    if format not in citations:
        print(f"WARNING: Format '{format}' not recognized. Using 'text'.")
        format = "text"
    
    citation_content = citations[format]
    
    # Write to file if requested
    if output_file:
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == "json":
            with open(output_path, 'w') as f:
                json.dump(citation_content, f, indent=2)
        else:
            with open(output_path, 'w') as f:
                f.write(citation_content if isinstance(citation_content, str) else str(citation_content))
        
        print(f"Citation written to: {output_path}")
    
    # Print if not return_only
    if not return_only and format != "json":
        print(citation_content if isinstance(citation_content, str) else str(citation_content))
    
    return citation_content

def Tax4Fun2_original_citation(
    format: str = "text",
    version: str = "1.1.5",
    return_only: bool = False,
    include_dependencies: bool = False,  # New: Include citations for dependencies
    output_file: Optional[Union[str, Path]] = None,  # New: Write to file
    bibtex_key: Optional[str] = None  # New: Custom BibTeX key
) -> Union[str, Dict]:
    """
    Return citation information for pyTax4Fun2 with enhanced features.
    
    Args:
        format: Citation format: "text", "bibtex", "apa", "ris", "json"
        version: Software version
        return_only: If True, returns citation without printing
        include_dependencies: Include citations for dependencies
        output_file: Write citation to file
        bibtex_key: Custom BibTeX citation key
        
    Returns:
        str or Dict: Citation string or dictionary
    """
    # Default BibTeX key
    if bibtex_key is None:
        bibtex_key = f"pyTax4Fun2_{version.replace('.', '_')}"
    
    # Main citation
    citations = {
        "text": f"""
================================================================================
Tax4Fun2: prediction of habitat-specific functional profiles and functional
redundancy based on 16S rRNA gene sequences

Authors:   Franziska Wemheuer, Jessica A. Taylor, Rolf Daniel,
           Emma Johnston, Peter Meinicke, Torsten Thomas, Bernd Wemheuer
Version:   {version}
Journal:  Environmental Microbiome 15:11
DOI:       https://doi.org/10.1186/s40793-020-00358-7
Year:      2020

Please cite that work if you use Tax4Fun2 in your research or referring them.
Original Github: https://github.com/bwemheu/Tax4Fun2

Since 20 February 2024, however, the link had since dead,
But original last version Tax4Fun2 (v1.1.5) and its database can be located and 
accessed at https://zenodo.org/records/10035668 (Thanks to Weizhi Song) 
================================================================================
""",
        
        "bibtex": f"""@article{{{bibtex_key},
  title = {{Tax4Fun2: prediction of habitat-specific functional profiles and functional redundancy based on 16S rRNA marker gene sequences}},
  author = {{Wemheuer, Franziska and Taylor, Jessica A and Daniel, Rolf and Johnston, Emma and Meinicke, Peter and Thomas, Torsten and Wemheuer, Bernd}},
  journal = {{Environmental Microbiome}},
  volume = {{15}},
  issue = {{1}},
  pages = {{11}},
  year = {{2020}},
  publisher = {{Springer Nature}},
  doi = {{10.1186/s40793-020-00358-7}},
  url = {{https://doi.org/10.1186/s40793-020-00358-7}}
}}""",
        
        "apa": """Wemheuer, F., Taylor, J. A., Daniel, R., Johnston, E., Meinicke, P., 
Thomas, T., & Wemheuer, B. (2020). Tax4Fun2: prediction of 
habitat-specific functional profiles and functional redundancy based on 
16S rRNA marker gene sequences. Environmental Microbiome, 15:11. 
https://doi.org/10.1186/s40793-020-00358-7""",
        
        "ris": """TY  - JOUR
AU  - Wemheuer, Franziska
AU  - Taylor, Jessica A.
AU  - Daniel, Rolf
AU  - Johnston, Emma
AU  - Meinicke, Peter
AU  - Thomas, Torsten
AU  - Wemheuer, Bernd
PY  - 2020
DA  - 2020/05/18
TI  - Tax4Fun2: prediction of habitat-specific functional profiles and functional redundancy based on 16S rRNA gene sequences
JO  - Environmental Microbiome
SP  - 11
VL  - 15
IS  - 1
AB  - Sequencing of 16S rRNA genes has become a powerful technique to study microbial communities and their responses towards changing environmental conditions in various ecosystems. Several tools have been developed for the prediction of functional profiles from 16S rRNA gene sequencing data, because numerous questions in ecosystem ecology require knowledge of community functions in addition to taxonomic composition. However, the accuracy of these tools relies on functional information derived from genomes available in public databases, which are often not representative of the microorganisms present in the studied ecosystem. In addition, there is also a lack of tools to predict functional gene redundancy in microbial communities.
SN  - 2524-6372
UR  - https://doi.org/10.1186/s40793-020-00358-7
DO  - 10.1186/s40793-020-00358-7
ID  - Wemheuer2020
ER  - """,
        
        "json": {
            "title": "pyTax4Fun2: prediction of habitat-specific functional profiles and functional redundancy based on 16S rRNA marker gene sequences",
            "authors": [
                "Wemheuer, Franziska",
                "Taylor, Jessica A",
                "Daniel, Rolf",
                "Johnston, Emma",
                "Meinicke, Peter",
                "Thomas, Torsten",
                "Wemheuer, Bernd"
            ],
            "year": 2020,
            "journal": "Environmental Microbiome",
            "volume": "15",
            "issue": "1",
            "pages": "11",
            "doi": "10.1186/s40793-020-00358-7",
            "url": "https://doi.org/10.1186/s40793-020-00358-7",
            "version": version,
            "retrieved": datetime.now().isoformat()
        }
    }
    
    # Add dependency citations if requested
    if include_dependencies:
        deps_citation = _get_dependency_citations(format)
        if format == "text":
            citations[format] += "\n\n" + deps_citation
        elif format == "bibtex":
            citations[format] += "\n\n" + deps_citation
        elif format == "json":
            citations[format]["dependencies"] = json.loads(deps_citation) if deps_citation.startswith("{") else deps_citation
    
    # Validate format
    if format not in citations:
        print(f"WARNING: Format '{format}' not recognized. Using 'text'.")
        format = "text"
    
    citation_content = citations[format]
    
    # Write to file if requested
    if output_file:
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == "json":
            with open(output_path, 'w') as f:
                json.dump(citation_content, f, indent=2)
        else:
            with open(output_path, 'w') as f:
                f.write(citation_content if isinstance(citation_content, str) else str(citation_content))
        
        print(f"Citation written to: {output_path}")
    
    # Print if not return_only
    if not return_only and format != "json":
        print(citation_content if isinstance(citation_content, str) else str(citation_content))
    
    return citation_content


def _get_dependency_citations(format: str) -> str:
    """
    Get citations for dependencies.
    
    Args:
        format: Citation format
        
    Returns:
        str: Dependency citations
    """
    deps = {
        "BLAST+": {
            "text": "Camacho C., et al. (2009) BLAST+: architecture and applications. BMC Bioinformatics 10:421. doi: 10.1186/1471-2105-10-421",
            "bibtex": """@article{blastplus,
  title = {BLAST+: architecture and applications},
  author = {Camacho, Christiam and Coulouris, George and Avagyan, Vahram and Ma, Ning and Papadopoulos, Jason and Bealer, Kevin and Madden, Thomas L},
  journal = {BMC Bioinformatics},
  volume = {10},
  number = {1},
  pages = {421},
  year = {2009},
  publisher = {BioMed Central},
  doi = {10.1186/1471-2105-10-421}
}""",
            "ris": """TY  - JOUR
TI  - BLAST+: architecture and applications
AU  - Camacho, Christiam
AU  - Coulouris, George
AU  - Avagyan, Vahram
AU  - Ma, Ning
AU  - Papadopoulos, Jason
AU  - Bealer, Kevin
AU  - Madden, Thomas L
PY  - 2009
JO  - BMC Bioinformatics
VL  - 10
IS  - 1
SP  - 421
DO  - 10.1186/1471-2105-10-421
ER  -"""
        },
        "DIAMOND": {
            "text": "Buchfink B., et al. (2015) Fast and sensitive protein alignment using DIAMOND. Nature Methods 12:59-60. doi: 10.1038/nmeth.3176",
            "bibtex": """@article{diamond,
  title = {Fast and sensitive protein alignment using DIAMOND},
  author = {Buchfink, Benjamin and Xie, Chao and Huson, Daniel H},
  journal = {Nature Methods},
  volume = {12},
  number = {1},
  pages = {59--60},
  year = {2015},
  publisher = {Nature Publishing Group},
  doi = {10.1038/nmeth.3176}
}""",
            "ris": """TY  - JOUR
TI  - Fast and sensitive protein alignment using DIAMOND
AU  - Buchfink, Benjamin
AU  - Xie, Chao
AU  - Huson, Daniel H
PY  - 2015
JO  - Nature Methods
VL  - 12
IS  - 1
SP  - 59
EP  - 60
DO  - 10.1038/nmeth.3176
ER  -"""
        },
        "VSEARCH": {
            "text": "Rognes T., et al. (2016) VSEARCH: a versatile open source tool for metagenomics. PeerJ 4:e2584. doi: 10.7717/peerj.2584",
            "bibtex": """@article{vsearch,
  title = {VSEARCH: a versatile open source tool for metagenomics},
  author = {Rognes, Torbjørn and Flouri, Tomáš and Nichols, Ben and Quince, Christopher and Mahé, Frédéric},
  journal = {PeerJ},
  volume = {4},
  pages = {e2584},
  year = {2016},
  publisher = {PeerJ Inc.},
  doi = {10.7717/peerj.2584}
}""",
            "ris": """TY  - JOUR
TI  - VSEARCH: a versatile open source tool for metagenomics
AU  - Rognes, Torbjørn
AU  - Flouri, Tomáš
AU  - Nichols, Ben
AU  - Quince, Christopher
AU  - Mahé, Frédéric
PY  - 2016
JO  - PeerJ
VL  - 4
SP  - e2584
DO  - 10.7717/peerj.2584
ER  -"""
        },
        "Prodigal": {
            "text": "Hyatt D., et al. (2010) Prodigal: prokaryotic gene recognition and translation initiation site identification. BMC Bioinformatics 11:119. doi: 10.1186/1471-2105-11-119",
            "bibtex": """@article{prodigal,
  title = {Prodigal: prokaryotic gene recognition and translation initiation site identification},
  author = {Hyatt, Doug and Chen, Gwo-Liang and LoCascio, Philip F and Land, Miriam L and Larimer, Frank W and Hauser, Loren J},
  journal = {BMC Bioinformatics},
  volume = {11},
  number = {1},
  pages = {119},
  year = {2010},
  publisher = {BioMed Central},
  doi = {10.1186/1471-2105-11-119}
}""",
            "ris": """TY  - JOUR
TI  - Prodigal: prokaryotic gene recognition and translation initiation site identification
AU  - Hyatt, Doug
AU  - Chen, Gwo-Liang
AU  - LoCascio, Philip F
AU  - Land, Miriam L
AU  - Larimer, Frank W
AU  - Hauser, Loren J
PY  - 2010
JO  - BMC Bioinformatics
VL  - 11
IS  - 1
SP  - 119
DO  - 10.1186/1471-2105-11-119
ER  -"""
        },
# Python libraries (alphabetically arranged)
"BioPython": {
    "text": "Cock P.J.A., et al. (2009) Biopython: freely available Python tools for computational molecular biology and bioinformatics. Bioinformatics 25(11):1422-1423. doi: 10.1093/bioinformatics/btp163",
    "bibtex": """@article{biopython,
  title = {Biopython: freely available Python tools for computational molecular biology and bioinformatics},
  author = {Cock, Peter JA and Antao, Tiago and Chang, Jeffrey T and Chapman, Brad A and Cox, Cymon J and Dalke, Andrew and Friedberg, Iddo and Hamelryck, Thomas and Kauff, Frank and Wilczynski, Bartek and others},
  journal = {Bioinformatics},
  volume = {25},
  number = {11},
  pages = {1422--1423},
  year = {2009},
  publisher = {Oxford University Press},
  doi = {10.1093/bioinformatics/btp163}
}""",
    "ris": """TY  - JOUR
TI  - Biopython: freely available Python tools for computational molecular biology and bioinformatics
AU  - Cock, Peter JA
AU  - Antao, Tiago
AU  - Chang, Jeffrey T
AU  - Chapman, Brad A
AU  - Cox, Cymon J
AU  - Dalke, Andrew
AU  - Friedberg, Iddo
AU  - Hamelryck, Thomas
AU  - Kauff, Frank
AU  - Wilczynski, Bartek
AU  - de Hoon, Michiel JL
PY  - 2009
JO  - Bioinformatics
VL  - 25
IS  - 11
SP  - 1422
EP  - 1423
DO  - 10.1093/bioinformatics/btp163
ER  -"""
},
"cogent3": {
    "text": "Knight R., et al. (2007) PyCogent: a toolkit for making sense from sequence. Genome Biology 8(8):R171. doi:10.1186/gb-2007-8-8-r171",
    "bibtex": """@article{cogent,
  title = {PyCogent: a toolkit for making sense from sequence},
  author = {Knight, Rob and Maxwell, Peter and Birmingham, Amanda and Carnes, Jason and Caporaso, J Gregory and Easton, Brett C and Eaton, Michael and Hamady, Micah and Lindsay, Helen and Liu, Zongzhi and Lozupone, Catherine and McDonald, Daniel and Robeson, Michael and Sammut, Raymond and Smit, Sandra and Wakefield, Matthew J and Widmann, Jeremy and Wikman, Shandy and Wilson, Stephanie and Ying, Hua and Huttley, Gavin A},
  journal = {Genome Biology},
  volume = {8},
  number = {8},
  pages = {R171},
  year = {2007},
  publisher = {BioMed Central},
  doi = {10.1186/gb-2007-8-8-r171}
}""",
    "ris": """TY  - JOUR
TI  - PyCogent: a toolkit for making sense from sequence
AU  - Knight, Rob
AU  - Maxwell, Peter
AU  - Birmingham, Amanda
AU  - Carnes, Jason
AU  - Caporaso, J Gregory
AU  - Easton, Brett C
AU  - Eaton, Michael
AU  - Hamady, Micah
AU  - Lindsay, Helen
AU  - Liu, Zongzhi
AU  - Lozupone, Catherine
AU  - McDonald, Daniel
AU  - Robeson, Michael
AU  - Sammut, Raymond
AU  - Smit, Sandra
AU  - Wakefield, Matthew J
AU  - Widmann, Jeremy
AU  - Wikman, Shandy
AU  - Wilson, Stephanie
AU  - Ying, Hua
AU  - Huttley, Gavin A
PY  - 2007
JO  - Genome Biology
VL  - 8
IS  - 8
SP  - R171
DO  - 10.1186/gb-2007-8-8-r171
ER  -"""
},
"ETE3": {
    "text": "Huerta-Cepas J., et al. (2016) ETE 3: Reconstruction, Analysis, and Visualization of Phylogenomic Data. Molecular Biology and Evolution 33(6):1635–1638. doi:10.1093/molbev/msw046",
    "bibtex": """@article{ete3,
  title = {ETE 3: Reconstruction, Analysis, and Visualization of Phylogenomic Data},
  author = {Huerta-Cepas, Jaime and Serra, François and Bork, Peer},
  journal = {Molecular Biology and Evolution},
  volume = {33},
  number = {6},
  pages = {1635--1638},
  year = {2016},
  publisher = {Oxford University Press},
  doi = {10.1093/molbev/msw046}
}""",
    "ris": """TY  - JOUR
TI  - ETE 3: Reconstruction, Analysis, and Visualization of Phylogenomic Data
AU  - Huerta-Cepas, Jaime
AU  - Serra, François
AU  - Bork, Peer
PY  - 2016
JO  - Molecular Biology and Evolution
VL  - 33
IS  - 6
SP  - 1635
EP  - 1638
DO  - 10.1093/molbev/msw046
ER  -"""
},
"loguru": {
    "text": "Delgan D. (2024) loguru: Python logging made (stupidly) simple. https://github.com/Delgan/loguru",
    "bibtex": """@software{loguru,
  title = {loguru: Python logging made (stupidly) simple},
  author = {Delgan, D.},
  year = {2024},
  publisher = {GitHub},
  url = {https://github.com/Delgan/loguru}
}""",
    "ris": """TY  - COMP
TI  - loguru: Python logging made (stupidly) simple
AU  - Delgan, D.
PY  - 2024
UR  - https://github.com/Delgan/loguru
ER  -"""
},
"Matplotlib": {
    "text": "Hunter J.D. (2007) Matplotlib: A 2D Graphics Environment. Computing in Science and Engineering 9(3):90-95. doi:10.1109/MCSE.2007.55",
    "bibtex": """@article{matplotlib,
  title = {Matplotlib: A 2D Graphics Environment},
  author = {Hunter, John D.},
  journal = {Computing in Science and Engineering},
  volume = {9},
  number = {3},
  pages = {90--95},
  year = {2007},
  publisher = {IEEE},
  doi = {10.1109/MCSE.2007.55}
}""",
    "ris": """TY  - JOUR
TI  - Matplotlib: A 2D Graphics Environment
AU  - Hunter, John D.
PY  - 2007
JO  - Computing in Science and Engineering
VL  - 9
IS  - 3
SP  - 90
EP  - 95
DO  - 10.1109/MCSE.2007.55
ER  -"""
},
"NetworkX": {
    "text": "Hagberg A.A., et al. (2008) Exploring network structure, dynamics, and function using NetworkX. Proceedings of the 7th Python in Science Conference (SciPy2008). Pasadena, California, USA. 11–15. doi:10.25080/TCWV9851",
    "bibtex": """@inproceedings{networkx,
  title = {Exploring network structure, dynamics, and function using {NetworkX}},
  author = {Hagberg, Aric A. and Schult, Daniel A. and Swart, Pieter J.},
  booktitle = {Proceedings of the 7th Python in Science Conference (SciPy2008)},
  editor = {Varoquaux, Gaël and Vaught, Travis and Millman, Jarrod},
  pages = {11--15},
  address = {Pasadena, California, USA},
  year = {2008},
  doi = {10.25080/TCWV9851}
}""",
    "ris": """TY  - CONF
TI  - Exploring network structure, dynamics, and function using NetworkX
AU  - Hagberg, Aric A.
AU  - Schult, Daniel A.
AU  - Swart, Pieter J.
PY  - 2008
T2  - Proceedings of the 7th Python in Science Conference (SciPy2008)
SP  - 11
EP  - 15
DO  - 10.25080/TCWV9851
ER  -"""
},
"NumPy": {
    "text": "Harris C.R., et al. (2020) Array programming with NumPy. Nature 585:357–362. doi:10.1038/s41586-020-2649-2",
    "bibtex": """@article{numpy,
  title = {Array programming with {NumPy}},
  author = {Harris, Charles R. and Millman, K. Jarrod and van der Walt, Stéfan J. and Gommers, Ralf and Virtanen, Pauli and Cournapeau, David and Wieser, Eric and Taylor, Julian and Berg, Sebastian and Smith, Nathaniel J. and Kern, Robert and Picus, Matti and Hoyer, Stephan and van Kerkwijk, Marten H. and Brett, Matthew and Haldane, Allan and del Río, Jaime Fernández and Wiebe, Mark and Peterson, Pearu and Gérard-Marchant, Pierre and Sheppard, Kevin and Reddy, Tyler and Weckesser, Warren and Abbasi, Hameer and Gohlke, Christoph and Oliphant, Travis E.},
  journal = {Nature},
  volume = {585},
  pages = {357--362},
  year = {2020},
  publisher = {Springer Nature},
  doi = {10.1038/s41586-020-2649-2}
}""",
    "ris": """TY  - JOUR
TI  - Array programming with NumPy
AU  - Harris, Charles R.
AU  - Millman, K. Jarrod
AU  - van der Walt, Stéfan J.
AU  - Gommers, Ralf
AU  - Virtanen, Pauli
AU  - Cournapeau, David
AU  - Wieser, Eric
AU  - Taylor, Julian
AU  - Berg, Sebastian
AU  - Smith, Nathaniel J.
AU  - Kern, Robert
AU  - Picus, Matti
AU  - Hoyer, Stephan
AU  - van Kerkwijk, Marten H.
AU  - Brett, Matthew
AU  - Haldane, Allan
AU  - del Río, Jaime Fernández
AU  - Wiebe, Mark
AU  - Peterson, Pearu
AU  - Gérard-Marchant, Pierre
AU  - Sheppard, Kevin
AU  - Reddy, Tyler
AU  - Weckesser, Warren
AU  - Abbasi, Hameer
AU  - Gohlke, Christoph
AU  - Oliphant, Travis E.
PY  - 2020
JO  - Nature
VL  - 585
SP  - 357
EP  - 362
DO  - 10.1038/s41586-020-2649-2
ER  -"""
},
"pbr": {
    "text": "Taylor M., et al. (2025) pbr: Python Build Reasonableness. https://github.com/openstack/pbr",
    "bibtex": """@software{pbr,
  title = {pbr: Python Build Reasonableness},
  author = {Taylor, Monty and Finucane, Stephen and Boylan, Clark and McLoughlin, Mark and Stanley, Jeremy and Hellmann, Doug and Collins, Robert and Bray, E.M. and King, Sachi and Danjou, Julien and Nemec, Ben and Kölker, Jason and Wienand, Ian and Beraud, Hervé and OpenStack Community Contributors},
  year = {2025},
  publisher = {OpenStack},
  url = {https://github.com/openstack/pbr}
}""",
    "ris": """TY  - COMP
TI  - pbr: Python Build Reasonableness
AU  - Taylor, Monty
AU  - Finucane, Stephen
AU  - Boylan, Clark
AU  - McLoughlin, Mark
AU  - Stanley, Jeremy
AU  - Hellmann, Doug
AU  - Collins, Robert
AU  - Bray, E.M.
AU  - King, Sachi
AU  - Danjou, Julien
AU  - Nemec, Ben
AU  - Kölker, Jason
AU  - Wienand, Ian
AU  - Beraud, Hervé
AU  - OpenStack Community Contributors
PY  - 2025
UR  - https://github.com/openstack/pbr
ER  -"""
},
"Polars": {
    "text": "Vink R., et al. (2024) polars: Extremely fast Query Engine for DataFrames, written in Rust. Zenodo. doi:10.5281/zenodo.7697217",
    "bibtex": """@software{polars,
  title = {polars: Extremely fast Query Engine for DataFrames, written in Rust},
  author = {Vink, Ritchie and de Gooijer, Stijn and Beedie, Alexander and Burghoorn, Gijs and Peters, Orson and Lin, Simon 'nameexhaustion' and Gorelli, Marco Edward and Guo, Wei Jie 'reswqa' and van Zundert, Jeroen and Crumiller, Marshall and Hulselmans, Gert and Grinstead, Cory and Polars Contributors},
  year = {2024},
  publisher = {Zenodo},
  version = {0.20.0+},
  doi = {10.5281/zenodo.7697217},
  url = {https://doi.org/10.5281/zenodo.7697217}
}""",
    "ris": """TY  - COMP
TI  - polars: Extremely fast Query Engine for DataFrames, written in Rust
AU  - Vink, Ritchie
AU  - de Gooijer, Stijn
AU  - Beedie, Alexander
AU  - Burghoorn, Gijs
AU  - Peters, Orson
AU  - Lin, Simon 'nameexhaustion'
AU  - Gorelli, Marco Edward
AU  - Guo, Wei Jie 'reswqa'
AU  - van Zundert, Jeroen
AU  - Crumiller, Marshall
AU  - Hulselmans, Gert
AU  - Grinstead, Cory
AU  - Polars Contributors
PY  - 2024
PB  - Zenodo
DO  - 10.5281/zenodo.7697217
UR  - https://doi.org/10.5281/zenodo.7697217
ER  -"""
},
"Polars-bio": {
    "text": "Wiewiórka M., et al. (2025) polars-bio: Fast, scalable, and out-of-core operations on large genomic interval datasets. Bioinformatics 41(12):btaf640. doi:10.1093/bioinformatics/btaf640",
    "bibtex": """@article{polarsbio,
  title = {polars-bio: Fast, scalable, and out-of-core operations on large genomic interval datasets},
  author = {Wiewiórka, Marek and Khamutou, Pavel and Zbysiński, Marek and Gambin, Tomasz},
  journal = {Bioinformatics},
  volume = {41},
  number = {12},
  pages = {btaf640},
  year = {2025},
  publisher = {Oxford University Press},
  doi = {10.1093/bioinformatics/btaf640},
  url = {https://doi.org/10.1093/bioinformatics/btaf640}
}""",
    "ris": """TY  - JOUR
TI  - polars-bio: Fast, scalable, and out-of-core operations on large genomic interval datasets
AU  - Wiewiórka, Marek
AU  - Khamutou, Pavel
AU  - Zbysiński, Marek
AU  - Gambin, Tomasz
PY  - 2025
JO  - Bioinformatics
VL  - 41
IS  - 12
SP  - btaf640
DO  - 10.1093/bioinformatics/btaf640
ER  -"""
},
"psutil": {
    "text": "Rodola G. (2008) psutil: Cross-platform lib for process and system monitoring in Python. https://github.com/giampaolo/psutil",
    "bibtex": """@software{psutil,
  title = {psutil: Cross-platform lib for process and system monitoring in Python},
  author = {Rodola, Giampaolo},
  year = {2008},
  publisher = {GitHub},
  url = {https://github.com/giampaolo/psutil}
}""",
    "ris": """TY  - COMP
TI  - psutil: Cross-platform lib for process and system monitoring in Python
AU  - Rodola, Giampaolo
PY  - 2008
UR  - https://github.com/giampaolo/psutil
ER  -"""
},
"pyarrow": {
    "text": "Mecum B., et al. (2025) pyArrow: Python library for Apache Arrow. https://pypi.org/project/pyarrow/",
    "bibtex": """@software{arrow,
  title = {Python library for Apache Arrow},
  author = {Mecum, Bryce and Cloud, Charles and Cutler, Bryan and Carleitao, Jorge and van den Bossche, Joris and Szucs, Krisztian and Cumplido, Raúl and McKinney, Wes and Korn, Uwe L. and Apache Arrow Project and Apache Arrow Contributors},
  year = {2025},
  publisher = {Apache Software Foundation},
  url = {https://pypi.org/project/pyarrow/}
}""",
    "ris": """TY  - COMP
TI  - Python library for Apache Arrow
AU  - Mecum, Bryce
AU  - Cloud, Charles
AU  - Cutler, Bryan
AU  - Carleitao, Jorge
AU  - van den Bossche, Joris
AU  - Szucs, Krisztian
AU  - Cumplido, Raúl
AU  - McKinney, Wes
AU  - Korn, Uwe L.
AU  - Apache Arrow Project
AU  - Apache Arrow Contributors
PY  - 2025
UR  - https://pypi.org/project/pyarrow/
ER  -"""
},
"PyYAML": {
    "text": "Simonov K., et al. (2025) PyYAML: A full-featured YAML processing framework for Python. https://github.com/yaml/pyyaml",
    "bibtex": """@software{pyyaml,
  title = {PyYAML: A full-featured YAML processing framework for Python},
  author = {Simonov, Kirill and Mahone, Nitz and döt Net, Ingy and Müller, Tina and Dufresne, Jon and Murphy, Peter K. and Smith, Thomas and Stufft, Donald and Antoniou, Pantelis and Clauss, Christian and Gaynor, Alex and van Kemenade, Hugo and Salo, Filip and Wilk, Jakub},
  year = {2025},
  publisher = {YAML Project},
  url = {https://github.com/yaml/pyyaml}
}""",
    "ris": """TY  - COMP
TI  - PyYAML: A full-featured YAML processing framework for Python
AU  - Simonov, Kirill
AU  - Mahone, Nitz
AU  - döt Net, Ingy
AU  - Müller, Tina
AU  - Dufresne, Jon
AU  - Murphy, Peter K.
AU  - Smith, Thomas
AU  - Stufft, Donald
AU  - Antoniou, Pantelis
AU  - Clauss, Christian
AU  - Gaynor, Alex
AU  - van Kemenade, Hugo
AU  - Salo, Filip
AU  - Wilk, Jakub
PY  - 2025
UR  - https://github.com/yaml/pyyaml
ER  -"""
},
"requests": {
    "text": "Cordasco I.S., et al. (2025) requests: A simple, yet elegant, HTTP library. https://github.com/psf/requests",
    "bibtex": """@software{requests,
  title = {requests: A simple, yet elegant, HTTP library},
  author = {Cordasco, Ian Stapleton and Lukasa, Cory Benfield and Prewitt, Nate and Python Software Foundation Contributors},
  year = {2025},
  publisher = {Python Software Foundation},
  url = {https://github.com/psf/requests}
}""",
    "ris": """TY  - COMP
TI  - requests: A simple, yet elegant, HTTP library
AU  - Cordasco, Ian Stapleton
AU  - Lukasa, Cory Benfield
AU  - Prewitt, Nate
AU  - Python Software Foundation Contributors
PY  - 2025
UR  - https://github.com/psf/requests
ER  -"""
},
"scikit-bio": {
    "text": "Aton M., et al. (2026) Scikit-bio: a fundamental Python library for biological omic data analysis. Nature Methods 23:274–276. doi:10.1038/s41592-025-02981-z",
    "bibtex": """@article{scikit-bio,
  title = {Scikit-bio: a fundamental Python library for biological omic data analysis},
  author = {Aton, Matthew and McDonald, Daniel and Cañardo Alastuey, Jorge and Azom, Raeed and Batra, Paarth and Bezshapkin, Valentyn and Bolyen, Evan and Cagle, Alexander and Caporaso, J. Gregory and Debelius, Justine W. and Gorlick, Kestrel and Hamsanipally, Nirmitha and Hunger, Lars and Keluskar, Aryan and Liao, Disen and Lu, Yang Young and Navas-Molina, Jose A. and Pitman, Anders and Rideout, Jai Ram and Sazonov, Anton and Sathappan, Bharath and Schwarzberg Lipson, Karen and Sfiligoi, Igor and Tapo, Chris and Vázquez-Baeza, Yoshiki and Wu, Zijun and Xu, Zhenjiang Zech and Ye, Mingsong Sam and Zhao, Jianshu and Knight, Rob and Morton, James T. and Zhu, Qiyun},
  journal = {Nature Methods},
  volume = {23},
  pages = {274--276},
  year = {2026},
  publisher = {Springer Nature},
  doi = {10.1038/s41592-025-02981-z}
}""",
    "ris": """TY  - JOUR
TI  - Scikit-bio: a fundamental Python library for biological omic data analysis
AU  - Aton, Matthew
AU  - McDonald, Daniel
AU  - Cañardo Alastuey, Jorge
AU  - Azom, Raeed
AU  - Batra, Paarth
AU  - Bezshapkin, Valentyn
AU  - Bolyen, Evan
AU  - Cagle, Alexander
AU  - Caporaso, J. Gregory
AU  - Debelius, Justine W.
AU  - Gorlick, Kestrel
AU  - Hamsanipally, Nirmitha
AU  - Hunger, Lars
AU  - Keluskar, Aryan
AU  - Liao, Disen
AU  - Lu, Yang Young
AU  - Navas-Molina, Jose A.
AU  - Pitman, Anders
AU  - Rideout, Jai Ram
AU  - Sazonov, Anton
AU  - Sathappan, Bharath
AU  - Schwarzberg Lipson, Karen
AU  - Sfiligoi, Igor
AU  - Tapo, Chris
AU  - Vázquez-Baeza, Yoshiki
AU  - Wu, Zijun
AU  - Xu, Zhenjiang Zech
AU  - Ye, Mingsong Sam
AU  - Zhao, Jianshu
AU  - Knight, Rob
AU  - Morton, James T.
AU  - Zhu, Qiyun
PY  - 2026
JO  - Nature Methods
VL  - 23
SP  - 274
EP  - 276
DO  - 10.1038/s41592-025-02981-z
ER  -"""
},
"Scikit-learn": {
    "text": "Pedregosa F., et al. (2011) Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research 12(85):2825−2830. doi: 10.5555/1953048.2078195",
    "bibtex": """@article{scikit-learn,
  title = {Scikit-learn: Machine Learning in {Python}},
  author = {Pedregosa, Fabian and Varoquaux, Gaël and Gramfort, Alexandre and Michel, Vincent and Thirion, Bertrand and Grisel, Olivier and Blondel, Mathieu and Prettenhofer, Peter and Weiss, Ron and Dubourg, Vincent and Vanderplas, Jake and Passos, Alexandre and Cournapeau, David and Brucher, Matthieu and Perrot, Matthieu and Duchesnay, Édouard},
  journal = {Journal of Machine Learning Research},
  volume = {12},
  number = {85},
  pages = {2825--2830},
  year = {2011},
  doi = {10.5555/1953048.2078195}
}""",
    "ris": """TY  - JOUR
TI  - Scikit-learn: Machine Learning in Python
AU  - Pedregosa, Fabian
AU  - Varoquaux, Gaël
AU  - Gramfort, Alexandre
AU  - Michel, Vincent
AU  - Thirion, Bertrand
AU  - Grisel, Olivier
AU  - Blondel, Mathieu
AU  - Prettenhofer, Peter
AU  - Weiss, Ron
AU  - Dubourg, Vincent
AU  - Vanderplas, Jake
AU  - Passos, Alexandre
AU  - Cournapeau, David
AU  - Brucher, Matthieu
AU  - Perrot, Matthieu
AU  - Duchesnay, Édouard
PY  - 2011
JO  - Journal of Machine Learning Research
VL  - 12
IS  - 85
SP  - 2825
EP  - 2830
DO  - 10.5555/1953048.2078195
ER  -"""
},
"SciPy": {
    "text": "Virtanen P., et al. (2020) SciPy 1.0: Fundamental algorithms for scientific computing in Python. Nature Methods 17:261–272. doi:10.1038/s41592-019-0686-2",
    "bibtex": """@article{scipy,
  title = {{SciPy} 1.0: Fundamental algorithms for scientific computing in {Python}},
  author = {Virtanen, Pauli and Gommers, Ralf and Oliphant, Travis E. and Haberland, Matt and Reddy, Tyler and Cournapeau, David and Burovski, Evgeni and Peterson, Pearu and Weckesser, Warren and Bright, Jonathan and van der Walt, Stéfan J. and Brett, Matthew and Wilson, Joshua and Millman, K. Jarrod and Mayorov, Nikolay and Nelson, Andrew R. J. and Jones, Eric and Kern, Robert and Larson, Eric and Carey, C J and Polat, İlhan and Feng, Yu and Moore, Eric W. and VanderPlas, Jake and Laxalde, Denis and Perktold, Josef and Cimrman, Robert and Henriksen, Ian and Quintero, E. A. and Harris, Charles R. and Archibald, Anne M. and Ribeiro, Antônio H. and Pedregosa, Fabian and van Mulbregt, Paul and SciPy 1.0 Contributors},
  journal = {Nature Methods},
  volume = {17},
  pages = {261--272},
  year = {2020},
  publisher = {Springer Nature},
  doi = {10.1038/s41592-019-0686-2}
}""",
    "ris": """TY  - JOUR
TI  - SciPy 1.0: Fundamental algorithms for scientific computing in Python
AU  - Virtanen, Pauli
AU  - Gommers, Ralf
AU  - Oliphant, Travis E.
AU  - Haberland, Matt
AU  - Reddy, Tyler
AU  - Cournapeau, David
AU  - Burovski, Evgeni
AU  - Peterson, Pearu
AU  - Weckesser, Warren
AU  - Bright, Jonathan
AU  - van der Walt, Stéfan J.
AU  - Brett, Matthew
AU  - Wilson, Joshua
AU  - Millman, K. Jarrod
AU  - Mayorov, Nikolay
AU  - Nelson, Andrew R. J.
AU  - Jones, Eric
AU  - Kern, Robert
AU  - Larson, Eric
AU  - Carey, C J
AU  - Polat, İlhan
AU  - Feng, Yu
AU  - Moore, Eric W.
AU  - VanderPlas, Jake
AU  - Laxalde, Denis
AU  - Perktold, Josef
AU  - Cimrman, Robert
AU  - Henriksen, Ian
AU  - Quintero, E. A.
AU  - Harris, Charles R.
AU  - Archibald, Anne M.
AU  - Ribeiro, Antônio H.
AU  - Pedregosa, Fabian
AU  - van Mulbregt, Paul
AU  - SciPy 1.0 Contributors
PY  - 2020
JO  - Nature Methods
VL  - 17
SP  - 261
EP  - 272
DO  - 10.1038/s41592-019-0686-2
ER  -"""
},
"Seaborn": {
    "text": "Waskom M.L. (2021) seaborn: statistical data visualization. Journal of Open Source Software 6(60):3021. doi:10.21105/joss.03021",
    "bibtex": """@article{seaborn,
  title = {seaborn: statistical data visualization},
  author = {Waskom, Michael L.},
  journal = {Journal of Open Source Software},
  volume = {6},
  number = {60},
  pages = {3021},
  year = {2021},
  publisher = {Open Journals},
  doi = {10.21105/joss.03021}
}""",
    "ris": """TY  - JOUR
TI  - seaborn: statistical data visualization
AU  - Waskom, Michael L.
PY  - 2021
JO  - Journal of Open Source Software
VL  - 6
IS  - 60
SP  - 3021
DO  - 10.21105/joss.03021
ER  -"""
},
"statsmodels": {
    "text": "Seabold S., Perktold J. (2010) statsmodels: Econometric and Statistical Modeling with Python. Proceedings of the 9th Python in Science Conference (SciPy2010). Austin, Texas, USA. 92–96. doi:10.25080/Majora-92bf1922-011",
    "bibtex": """@inproceedings{statsmodels,
  title = {statsmodels: Econometric and Statistical Modeling with {Python}},
  author = {Seabold, Skipper and Perktold, Josef},
  booktitle = {Proceedings of the 9th Python in Science Conference (SciPy2010)},
  editor = {van der Walt, Stéfan and Millman, Jarrod},
  pages = {92--96},
  address = {Austin, Texas, USA},
  year = {2010},
  doi = {10.25080/Majora-92bf1922-011}
}""",
    "ris": """TY  - CONF
TI  - statsmodels: Econometric and Statistical Modeling with Python
AU  - Seabold, Skipper
AU  - Perktold, Josef
PY  - 2010
T2  - Proceedings of the 9th Python in Science Conference (SciPy2010)
SP  - 92
EP  - 96
DO  - 10.25080/Majora-92bf1922-011
ER  -"""
},
"stevedore": {
    "text": "Hellmann D., et al. (2025) stevedore: Manage dynamic plugins for Python applications. https://github.com/openstack/stevedore",
    "bibtex": """@software{stevedore,
  title = {stevedore: Manage dynamic plugins for Python applications},
  author = {Hellmann, Doug and Finucane, Stephen and Kajinami, Takashi and Rocco, Daniel and Guo, Chang Bo and Danjou, Julien and Bechtold, Thomas and Beraud, Hervé and Jaeger, Andreas and Harlow, Joshua and Srinivas, Davanum and McGinnis, Sean and Turner, Wes and OpenStack Community Contributors},
  year = {2025},
  publisher = {OpenStack},
  url = {https://github.com/openstack/stevedore}
}""",
    "ris": """TY  - COMP
TI  - stevedore: Manage dynamic plugins for Python applications
AU  - Hellmann, Doug
AU  - Finucane, Stephen
AU  - Kajinami, Takashi
AU  - Rocco, Daniel
AU  - Guo, Chang Bo
AU  - Danjou, Julien
AU  - Bechtold, Thomas
AU  - Beraud, Hervé 
AU  - Jaeger, Andreas
AU  - Harlow, Joshua
AU  - Srinivas, Davanum
AU  - McGinnis, Sean
AU  - Turner, Wes
AU  - OpenStack Community Contributors
PY  - 2025
UR  - https://github.com/openstack/stevedore
ER  -"""
},
"TinyDB": {
    "text": "Siemens M. (2024) TinyDB: Lightweight document oriented database optimized for your happiness. https://github.com/msiemens/tinydb",
    "bibtex": """@software{tinydb,
  title = {TinyDB: Lightweight document oriented database optimized for your happiness},
  author = {Siemens, Markus},
  year = {2024},
  publisher = {GitHub},
  url = {https://github.com/msiemens/tinydb}
}""",
    "ris": """TY  - COMP
TI  - TinyDB: Lightweight document oriented database optimized for your happiness
AU  - Siemens, Markus
PY  - 2024
UR  - https://github.com/msiemens/tinydb
ER  -"""
},
"tqdm": {
    "text": "da Costa-Luis C., et al. (2025) tqdm: A Fast, Extensible Progress Bar for Python and CLI. https://github.com/tqdm/tqdm",
    "bibtex": """@software{tqdm,
  title = {tqdm: A Fast, Extensible Progress Bar for Python and CLI},
  author = {da Costa-Luis, Casper and Larroque, Stephen Karl and Mary, Hadrien and Altendorf, Kyle and Sheridan, Richard and Korobov, Mikhail and Raphael, Noam and Ivanov, Ivan and Bargull, Marcel and Cheng, Shawn and Rodrigues, Nishant and Górny, Michał and Dektiarev, Mikhail and tqdm Contributors},
  year = {2025},
  publisher = {GitHub},
  url = {https://github.com/tqdm/tqdm}
}""",
    "ris": """TY  - COMP
TI  - tqdm: A Fast, Extensible Progress Bar for Python and CLI
AU  - da Costa-Luis, Casper
AU  - Larroque, Stephen Karl
AU  - Mary, Hadrien
AU  - Altendorf, Kyle
AU  - Sheridan, Richard
AU  - Korobov, Mikhail
AU  - Raphael, Noam
AU  - Ivanov, Ivan
AU  - Bargull, Marcel
AU  - Cheng, Shawn
AU  - Rodrigues, Nishant
AU  - Górny, Michał
AU  - Dektiarev, Mikhail
AU  - tqdm Contributors
PY  - 2025
UR  - https://github.com/tqdm/tqdm
ER  -"""
},
"UMAP": {
    "text": "McInnes L., et al. (2018) UMAP: Uniform Manifold Approximation and Projection. Journal of Open Source Software 3(29):861. doi:10.21105/joss.00861",
    "bibtex": """@article{umap,
  title = {UMAP: Uniform Manifold Approximation and Projection},
  author = {McInnes, Leland and Healy, John and Saul, Nathaniel and Großberger, Lukas},
  journal = {Journal of Open Source Software},
  volume = {3},
  number = {29},
  pages = {861},
  year = {2018},
  publisher = {Open Journals},
  doi = {10.21105/joss.00861}
}""",
    "ris": """TY  - JOUR
TI  - UMAP: Uniform Manifold Approximation and Projection
AU  - McInnes, Leland
AU  - Healy, John
AU  - Saul, Nathaniel
AU  - Großberger, Lukas
PY  - 2018
JO  - Journal of Open Source Software
VL  - 3
IS  - 29
SP  - 861
DO  - 10.21105/joss.00861
ER  -"""
}
}
    
    if format == "text":
        result = ["\nDependency Citations:"]
        for name, citation in deps.items():
            if "text" in citation:
                result.append(f"\n{name}: {citation['text']}")
        return "\n".join(result)
    
    elif format == "bibtex":
        result = []
        for name, citation in deps.items():
            if "bibtex" in citation:
                result.append(citation["bibtex"])
        return "\n\n".join(result)
    
    elif format == "ris":
        result = []
        for name, citation in deps.items():
            if "ris" in citation:
                result.append(citation["ris"])
        return "\n\n".join(result)
    
    elif format == "json":
        import json
        return json.dumps({
            "dependencies": {
                name: {
                    "citation": citation.get("text", ""),
                    "doi": citation.get("doi", "")
                }
                for name, citation in deps.items()
            }
        }, indent=2)
    
    return ""


def generate_citation_report(
    output_dir: Union[str, Path] = ".",
    formats: List[str] = None
) -> Dict[str, Path]:
    """
    Generate citation files in multiple formats.
    
    Args:
        output_dir: Output directory
        formats: List of formats to generate
        
    Returns:
        Dict: Mapping of format to file path
    """
    if formats is None:
        formats = ["text", "bibtex", "apa", "ris", "json"]
    
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_files = {}
    
    for fmt in formats:
        filename = f"pyTax4Fun2_citation.{'txt' if fmt != 'json' else 'json'}"
        if fmt == "bibtex":
            filename = "pyTax4Fun2_citation.bib"
        elif fmt == "ris":
            filename = "pyTax4Fun2_citation.ris"
        
        output_path = output_dir / filename
        
        pyTax4Fun2_citation(
            format=fmt,
            return_only=True,
            output_file=output_path,
            include_dependencies=True
        )
        
        output_files[fmt] = output_path
    
    print(f"Citation files generated in: {output_dir}")
    return output_files


# def check_citation_compliance(
    # manuscript_file: Optional[Union[str, Path]] = None
# ) -> Dict[str, bool]:
    # """
    # Check if pyTax4Fun2 is properly cited in a manuscript.
    
    # Args:
        # manuscript_file: Path to manuscript text file
        
    # Returns:
        # Dict: Compliance check results
    # """
    # keywords = [
        # "pyTax4Fun2",
        # "Nashrulloh",
        # "functional prediction",
        # "16S rRNA",
        # "2026"
    # ]
    
    # results = {
        # "pyTax4Fun2_mentioned": False,
        # "authors_mentioned": False,
        # "doi_mentioned": False,
        # "preprint_mentioned": False,
        # "year_mentioned": False
    # }
    
    # if manuscript_file:
        # manuscript_path = Path(manuscript_file)
        # if manuscript_path.exists():
            # try:
                # with open(manuscript_path, 'r') as f:
                    # content = f.read().lower()
                
                # results["pyTax4Fun2_mentioned"] = any(
                    # kw.lower() in content for kw in ["pyTax4Fun2", "pyTax4Fun2"]
                # )
                # results["authors_mentioned"] = "Nashrulloh" in content
                # #results["doi_mentioned"] = "10.xxxx/xxxxx" in content
                # #results["preprint_mentioned"] = "xxxxx" in content
                # results["year_mentioned"] = "2026" in content
                
            # except Exception as e:
                # print(f"Error reading manuscript file: {str(e)}")
    
    # return results
    