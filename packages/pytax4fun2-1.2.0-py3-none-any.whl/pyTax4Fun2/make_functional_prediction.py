"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Make functional predictions from OTU tables.
"""

import warnings
from pathlib import Path
from typing import Dict, List, Optional, Union, Tuple
from io import StringIO

import polars as pl
import numpy as np
from scipy.spatial.distance import pdist, squareform

from .utils import (
    validate_file, validate_directory, read_blast_output, read_kegg_profile,
    pyTax4Fun2Error, check_memory_available
)


def row_sum_polars(df, columns):
    """Calculate row-wise sum for polars DataFrame."""
    return df.select(pl.sum_horizontal([pl.col(col) for col in columns])).to_series()

def make_functional_prediction(
    path_to_otu_table: str,
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    path_to_temp_folder: str = "pyTax4Fun2_prediction",
    database_mode: str = 'Ref100NR',
    normalize_by_copy_number: bool = True,
    min_identity_to_reference: float = 97,
    include_user_data: bool = False,
    path_to_user_data: str = '',
    name_of_user_data: str = "",
    use_uproc: bool = True,
    normalize_pathways: bool = True, #Set False to not normalize it, but you can't explore pathways. Only explore functional only
    write_counts: bool = False,
    max_memory_gb: float = 8.0
) -> Dict[str, Union[pl.DataFrame, Dict, List, str]]:
    """
    Predict functional profiles and pathways from OTU tables.
    
    Args:
        path_to_otu_table: Path to OTU table
        path_to_reference_data: Path to reference data
        path_to_temp_folder: Path to temporary folder with BLAST results
        database_mode: Database mode: 'Ref99NR' or 'Ref100NR'
        normalize_by_copy_number: Normalize by 16S copy number
        min_identity_to_reference: Minimum identity cutoff (0-100 or 0-1)
        include_user_data: Include user-defined reference data
        path_to_user_data: Path to user data directory
        name_of_user_data: Name of user data directory
        use_uproc: Use UProC profiles
        normalize_pathways: Normalize pathway predictions
        write_counts: Write count tables in addition to proportions
        max_memory_gb: Maximum memory to use in GB
        
    Returns:
        Dict with functional and pathway predictions
        
    Raises:
        pyTax4Fun2Error: If prediction fails
    """
    # Check memory availability before starting
    if not check_memory_available(max_memory_gb):
        warnings.warn(f"Less than {max_memory_gb} GB memory available. "
                     f"Consider reducing max_memory_gb parameter.")
    
    # Validate inputs
    validate_file(path_to_otu_table, "OTU table")
    temp_path = Path(path_to_temp_folder)
    validate_directory(temp_path, "Temporary folder")
    ref_path = Path(path_to_reference_data)
    validate_directory(ref_path, "Reference data directory")
    
    if database_mode not in ['Ref99NR', 'Ref100NR']:
        raise pyTax4Fun2Error("database_mode must be 'Ref99NR' or 'Ref100NR'")
    
    # Normalize identity threshold
    if min_identity_to_reference < 1:
        min_identity_to_reference *= 100
    
    if min_identity_to_reference < 90:
        warnings.warn("Minimum identity < 90% may result in inaccurate predictions")
    
    print(f"Using minimum identity cutoff: {min_identity_to_reference}%")
    
    # Read and filter BLAST results
    ref_blast_file = temp_path / 'ref_blast.txt'
    if not ref_blast_file.exists():
        raise pyTax4Fun2Error(f"BLAST results not found: {ref_blast_file}")
    
    blast_df = read_blast_output(ref_blast_file)
    
    # Filter by identity
    if "pident" not in blast_df.columns:
        raise pyTax4Fun2Error("BLAST results missing pident column")
    
    filtered_blast = blast_df.filter(
        pl.col("pident") >= min_identity_to_reference
    ).select(["qseqid", "sseqid"])
    
    if filtered_blast.is_empty():
        raise pyTax4Fun2Error(
            f"No BLAST hits above identity threshold: {min_identity_to_reference}%"
        )
    
    # Process user BLAST results if included
    if include_user_data:
        if not path_to_user_data or not name_of_user_data:
            raise pyTax4Fun2Error(
                "path_to_user_data and name_of_user_data must be specified "
                "when include_user_data=True"
            )
        
        user_blast_file = temp_path / 'user_blast.txt'
        if not user_blast_file.exists():
            warnings.warn(f"User BLAST file not found: {user_blast_file}")
            include_user_data = False
        else:
            user_blast = read_blast_output(user_blast_file)
            user_filtered = user_blast.filter(
                pl.col("pident") >= min_identity_to_reference
            ).select(["qseqid", "sseqid"])
            
            # Merge with reference BLAST results
            # User hits override reference hits for same query
            filtered_blast = pl.concat([
                filtered_blast.filter(
                    ~pl.col("qseqid").is_in(user_filtered["qseqid"])
                ),
                user_filtered
            ])
    
    # Read OTU table
    try:
        # Try to read as tab-separated
        otu_df = pl.read_csv(path_to_otu_table, separator="\t")
    except Exception as e:
        # Try comma-separated
        try:
            otu_df = pl.read_csv(path_to_otu_table)
        except Exception as e2:
            raise pyTax4Fun2Error(
                f"Cannot read OTU table {path_to_otu_table}. "
                f"Error: {str(e2)}"
            )
    
    if otu_df.shape[1] < 2:
        raise pyTax4Fun2Error("OTU table must have at least 2 columns (ID + samples)")
    
    id_col = otu_df.columns[0]
    sample_cols = otu_df.columns[1:]
    
    # Merge OTU table with BLAST results
    merged = filtered_blast.join(
        otu_df,
        left_on="qseqid",
        right_on=id_col,
        how="inner"
    ).drop("qseqid")
    
    if merged.is_empty():
        raise pyTax4Fun2Error("No overlap between BLAST results and OTU table")
    
    # Aggregate by reference ID
    aggregated = merged.group_by("sseqid").agg(
        [pl.col(col).sum() for col in sample_cols]
    )
    
    # Calculate unknown fractions
    total_otus = otu_df.select(sample_cols).sum()
    used_otus = merged.select(sample_cols).sum()
    
    # Avoid division by zero and ensure non-negative percentages
    unused_fraction = {}
    for col in sample_cols:
        total = float(total_otus[col].item())
        used = float(used_otus[col].item())
        
        if total > 0:
            # Ensure used doesn't exceed total (due to floating point)
            used = min(used, total)
            fraction = 1 - (used / total)
            # Ensure fraction is between 0 and 1
            fraction = max(0.0, min(1.0, fraction))
            unused_fraction[col] = fraction
        else:
            unused_fraction[col] = 0.0
    
    print("Unknown fractions:")
    for col in sample_cols:
        frac = unused_fraction.get(col, 0.0)
        print(f"  {col}: {frac:.3%}")
    
    # Determine profile column to use (1-based indexing like R)
    # R code: n = 1; if(use_uproc) n = 3; if(normalize_by_copy_number) n = n + 1
    profile_col = 1  # Default: "du" column
    if use_uproc:
        profile_col = 3  # "uu" column
    if normalize_by_copy_number:
        profile_col += 1  # +1 gives "dn" (2) or "un" (4)
    
    print(f"Using profile column index: {profile_col}")
    
    # Load KEGG KO list (has header: ko, description, ptw_count)
    ko_list_file = ref_path / 'KEGG' / 'ko.txt'
    if not ko_list_file.exists():
        raise pyTax4Fun2Error(f"KEGG KO list not found: {ko_list_file}")
    
    # Read with header - ko.txt has header row
    ko_list = pl.read_csv(ko_list_file, separator="\t")
    n_ko = ko_list.height  # This gives the number of data rows (21620)
    print(f"KO list has {n_ko} KOs (plus header)")
    
    # Get KO IDs and descriptions
    ko_ids = ko_list[:, 0].to_list()
    ko_descriptions = ko_list[:, 1].to_list() if ko_list.shape[1] > 1 else [""] * n_ko
    
    # Load reference profiles
    print("Loading reference profiles...")
    reference_ids = aggregated["sseqid"].to_list()
    
    # Set path based on database mode
    if database_mode == 'Ref99NR':
        ref_profile_dir = ref_path / 'Ref99NR'
    else:
        ref_profile_dir = ref_path / 'Ref100NR'
    
    # Initialize profile matrix
    n_ref = len(reference_ids)
    
    # Check memory requirements
    estimated_memory_mb = (n_ref * n_ko * 4) / (1024 * 1024)
    if estimated_memory_mb > max_memory_gb * 1024:
        warnings.warn(
            f"Estimated memory requirement: {estimated_memory_mb:.1f} MB. "
            f"Consider reducing dataset size or increasing max_memory_gb."
        )
    
    profile_matrix = np.zeros((n_ref, n_ko), dtype=np.float64)
    loaded_refs = []
    valid_indices = []
    
    for i, ref_id in enumerate(reference_ids):
        # Determine if this is a user reference
        if ref_id.startswith("user"):
            if not include_user_data:
                warnings.warn(f"User reference found but include_user_data=False: {ref_id}")
                continue
            
            # Clean user ID (remove _number suffix)
            user_id = ref_id.split("_")[0]
            profile_file = Path(path_to_user_data) / name_of_user_data / f"{user_id}.tbl"
        else:
            profile_file = ref_profile_dir / f"{ref_id}.tbl.gz"
        
        if not profile_file.exists():
            # Try without .gz
            profile_file = ref_profile_dir / f"{ref_id}.tbl"
            if not profile_file.exists():
                warnings.warn(f"Profile file not found: {profile_file.name}")
                continue
        
        try:
            import gzip
            
            # Read file and filter out empty lines to handle trailing blank line
            if str(profile_file).endswith('.gz'):
                with gzip.open(profile_file, 'rt') as f:
                    # Read all lines and keep only non-empty lines
                    lines = [line for line in f.readlines() if line.strip()]
            else:
                with open(profile_file, 'r') as f:
                    lines = [line for line in f.readlines() if line.strip()]
            
            # Convert filtered lines back to string for Polars
            content = ''.join(lines)
            
            # Read profile data with explicit schema to handle float values
            profile_data = pl.read_csv(
                StringIO(content), 
                separator="\t",
                schema_overrides={
                    "du": pl.Float64,
                    "dn": pl.Float64,
                    "uu": pl.Float64,
                    "un": pl.Float64
                }
            )
            
            # Ensure all profile columns are Float64 (backup)
            for col in profile_data.columns:
                if col in ['du', 'dn', 'uu', 'un']:
                    profile_data = profile_data.with_columns(
                        pl.col(col).cast(pl.Float64)
                    )
            
            # ===== FIX: Handle header correctly =====
            # Check if the profile has header + data (n_ko + 1 rows) or just data (n_ko rows)
            col_index = profile_col - 1  # Convert to 0-based
            
            if col_index >= len(profile_data.columns):
                warnings.warn(f"Profile column index {profile_col} out of range for {profile_file.name}")
                continue
            
            col_name = profile_data.columns[col_index]
            
            # Determine if first row is header (check if first row values are strings or numbers)
            first_row = profile_data.row(0)
            first_row_is_header = any(isinstance(val, str) and not val.replace('.', '').replace('-', '').isdigit() 
                                      for val in first_row)
            
            if profile_data.height == n_ko + 1 or first_row_is_header:
                # File has header row - skip first row
                profile_values = profile_data[1:, col_index].to_numpy().flatten()
                # print(f"  Profile {ref_id} has header, using rows 2-{profile_data.height}")
            elif profile_data.height == n_ko:
                # File has no header
                profile_values = profile_data[:, col_index].to_numpy().flatten()
                # print(f"  Profile {ref_id} has no header, using all {profile_data.height} rows")
            else:
                warnings.warn(f"Profile dimension mismatch for {ref_id}: "
                            f"expected {n_ko} or {n_ko+1} rows, got {profile_data.height}")
                continue
            
            # Verify we have the correct number of KOs
            if len(profile_values) != n_ko:
                warnings.warn(f"Profile {profile_file.name} has {len(profile_values)} data rows, expected {n_ko}")
                continue
            
            # Check if profile has any non-zero values
            if np.all(profile_values == 0):
                warnings.warn(f"Profile {ref_id} has all zero values, skipping")
                continue
            
            # Valid profile - add to matrix
            profile_matrix[i, :] = profile_values.astype(np.float64)
            loaded_refs.append(ref_id)
            valid_indices.append(i)
            
            # Debug info for first few profiles
            if len(loaded_refs) <= 5:
                non_zero = (profile_values > 0).sum()
                print(f"  Loaded {ref_id}: {non_zero} non-zero KOs, sum={profile_values.sum():.2f}")
            
        except Exception as e:
            warnings.warn(f"Error reading profile file {profile_file.name}: {str(e)}")
            continue
    
    # Remove references with all-zero profiles or failed loading
    if not valid_indices:
        raise pyTax4Fun2Error("No valid reference profiles found")
    
    profile_matrix = profile_matrix[valid_indices, :]
    loaded_refs = [reference_ids[i] for i in valid_indices]
    aggregated = aggregated.filter(pl.col("sseqid").is_in(loaded_refs))
    
    print(f"Successfully loaded {len(loaded_refs)} reference profiles")
    
    # Calculate functional predictions
    print("Generating functional predictions...")
    n_samples = len(sample_cols)
    
    # Extract sample abundances as numpy array
    sample_matrix = aggregated.select(sample_cols).to_numpy()
    
    # Calculate weighted profiles using numpy for efficiency
    # profile_matrix: n_ref × n_ko
    # sample_matrix: n_ref × n_samples
    # result: n_ko × n_samples
    func_predictions = np.dot(profile_matrix.T, sample_matrix)
    
    # Normalize to proportions
    column_sums = np.sum(func_predictions, axis=0)
    column_sums[column_sums == 0] = 1  # Avoid division by zero
    func_proportions = func_predictions / column_sums
    
    # Create output DataFrames
    func_output = pl.DataFrame({
        "KO": ko_ids,
        **{col: func_proportions[:, i] for i, col in enumerate(sample_cols)},
        "description": ko_descriptions
    })
    
    # Remove KOs with zero abundance in all samples
    non_zero_kos = np.any(func_proportions > 0, axis=1)
    func_output = func_output.filter(pl.Series(non_zero_kos))
    
    if func_output.is_empty():
        raise pyTax4Fun2Error("No functional predictions generated - all KOs have zero abundance")
    
    # Write output
    func_output_file = temp_path / 'functional_prediction.txt'
    func_output.write_csv(func_output_file, separator="\t")
    print(f"Functional predictions written to: {func_output_file.name}")
    
    # Write counts if requested
    if write_counts:
        counts_output = pl.DataFrame({
            "KO": ko_ids,
            **{col: func_predictions[:, i] for i, col in enumerate(sample_cols)},
            "description": ko_descriptions
        }).filter(pl.Series(non_zero_kos))
        
        counts_output_file = temp_path / 'functional_prediction_counts.txt'
        counts_output.write_csv(counts_output_file, separator="\t")
        print(f"Functional counts written to: {counts_output_file.name}")
    
    # Convert to pathway predictions (skip if normalize_pathways=False)
    if not normalize_pathways:
        print("Pathway conversion skipped (normalize_pathways=False)")
        pathway_final = None
    else:
        print("Converting to pathway predictions...")
        
        ko2ptw_file = ref_path / 'KEGG' / 'ko2ptw.txt'
        if not ko2ptw_file.exists():
            raise pyTax4Fun2Error(f"KO to pathway mapping not found: {ko2ptw_file}")
        
        ko2ptw = pl.read_csv(ko2ptw_file, separator="\t")
        
        # Check if we have pathway mapping for our KOs
        if ko_list.columns[0] not in ko2ptw.columns:
            # Try to find the correct column
            ko_col = None
            for col in ko2ptw.columns:
                if col.lower() in ['ko', 'kegg', 'gene']:
                    ko_col = col
                    break
            
            if ko_col is None:
                raise pyTax4Fun2Error("Cannot find KO column in pathway mapping file")
        else:
            ko_col = ko_list.columns[0]
        
        # Merge KO list with pathway mapping
        ko_with_pathways = ko_list.join(
            ko2ptw.select([ko_col, "ptw"]),
            left_on=ko_list.columns[0],
            right_on=ko_col,
            how="left"
        )
        
        # Prepare data for aggregation
        if write_counts:
            pred_data = func_predictions
        else:
            pred_data = func_proportions
        
        # Create a mapping from KO index to pathway
        ko_to_pathway = ko_with_pathways["ptw"].to_list()
        
        # Get unique pathways
        unique_pathways = [p for p in set(ko_to_pathway) if p is not None]
        
        if not unique_pathways:
            warnings.warn("No pathway mappings found for KOs")
            pathway_final = None
        else:
            # Initialize pathway prediction matrix
            n_pathways = len(unique_pathways)
            pathway_pred_matrix = np.zeros((n_pathways, n_samples), dtype=np.float64)
            
            # Create pathway index mapping
            pathway_to_idx = {p: i for i, p in enumerate(unique_pathways)}
            
            # Aggregate by pathway
            for ko_idx, pathway in enumerate(ko_to_pathway):
                if pathway is not None and pathway in pathway_to_idx:
                    p_idx = pathway_to_idx[pathway]
                    # Make sure ko_idx is within bounds
                    if ko_idx < pred_data.shape[0]:
                        pathway_pred_matrix[p_idx, :] += pred_data[ko_idx, :]
            
            # Create pathway DataFrame
            pathway_pred = pl.DataFrame({
                "pathway": unique_pathways,
                **{col: pathway_pred_matrix[:, i] for i, col in enumerate(sample_cols)}
            })
            
            # Normalize pathway predictions if not writing counts
            if not write_counts:
                # Use sum_horizontal for row-wise sums in Polars
                row_sum_expr = pl.sum_horizontal([pl.col(col) for col in sample_cols])
                
                # Add row sum as a temporary column
                pathway_pred = pathway_pred.with_columns(
                    row_sum_expr.alias("__row_sum")
                )
                
                # Replace zeros with 1 to avoid division by zero
                pathway_pred = pathway_pred.with_columns(
                    pl.when(pl.col("__row_sum") == 0)
                    .then(1)
                    .otherwise(pl.col("__row_sum"))
                    .alias("__row_sum")
                )
                
                # Normalize each sample column
                for col in sample_cols:
                    pathway_pred = pathway_pred.with_columns(
                        (pl.col(col) / pl.col("__row_sum")).alias(col)
                    )
                
                # Drop the temporary row sum column
                pathway_pred = pathway_pred.drop("__row_sum")
            
            # Remove pathways with zero abundance
            pathway_nonzero = pl.sum_horizontal([pl.col(col) for col in sample_cols]) > 0
            pathway_pred = pathway_pred.filter(pathway_nonzero)

            if pathway_pred.is_empty():
                warnings.warn("No pathway predictions generated")
                pathway_final = None
            else:
                # Add pathway descriptions
                ptw_desc_file = ref_path / 'KEGG' / 'ptw.txt'
                if not ptw_desc_file.exists():
                    warnings.warn(f"Pathway descriptions not found: {ptw_desc_file}")
                    pathway_final = pathway_pred
                else:
                    ptw_desc = pl.read_csv(ptw_desc_file, separator="\t")
                    pathway_final = pathway_pred.join(
                        ptw_desc,
                        left_on="pathway",
                        right_on="pathway",
                        how="left"
                    )
                
                # Write pathway predictions
                pathway_output_file = temp_path / 'pathway_prediction.txt'
                pathway_final.write_csv(pathway_output_file, separator="\t")
                print(f"Pathway predictions written to: {pathway_output_file.name}")
                
                # Write pathway counts if requested
                if write_counts:
                    pathway_counts_file = temp_path / 'pathway_prediction_counts.txt'
                    pathway_pred.write_csv(pathway_counts_file, separator="\t")
                    print(f"Pathway counts written to: {pathway_counts_file.name}")
            
    print("\nFunctional prediction complete!")
    
    # Return results with proper typing
    return {
        "functional_predictions": func_output,
        "pathway_predictions": pathway_final,
        "unknown_fractions": unused_fraction,
        "references_used": loaded_refs,
        "output_directory": str(temp_path)
    }
    