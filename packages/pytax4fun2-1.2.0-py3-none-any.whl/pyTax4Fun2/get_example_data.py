"""
Download example data for pyTax4Fun2 with enhanced features.
"""

import zipfile
import shutil
import datetime
from pathlib import Path
from typing import Optional, Dict, List
import warnings

from .utils import (
    validate_directory, download_with_checksum, pyTax4Fun2Error,
    read_fasta_polars, write_fasta_polars, fasta_stats,
    extract_sequences_from_fasta, merge_fasta_files
)


def get_example_data(
    path_to_working_directory: str = ".",
    use_force: bool = False,
    show_progress: bool = True,
    verify_download: bool = True,
    extract_only: bool = False
) -> str:
    """
    Download example datasets for testing and demonstration.
    
    Args:
        path_to_working_directory: Working directory for download
        use_force: Overwrite existing example data
        show_progress: Show download progress
        verify_download: Verify downloaded files
        extract_only: Only extract without downloading (if zip exists)
        
    Returns:
        str: Path to example data directory
        
    Raises:
        pyTax4Fun2Error: If download or extraction fails
    """
    # Validate and create working directory
    work_dir = Path(path_to_working_directory)
    validate_directory(work_dir, create=True, writable=True)
    
    # Define paths
    example_dir = work_dir / "ExampleData"
    zip_file = work_dir / "ExampleData.zip"
    
    # Check if example data already exists
    if example_dir.exists():
        if use_force:
            print(f"Removing existing example data directory: {example_dir}")
            try:
                shutil.rmtree(example_dir)
            except Exception as e:
                raise pyTax4Fun2Error(f"Failed to remove existing directory: {str(e)}")
        else:
            raise pyTax4Fun2Error(
                f"ExampleData directory already exists: {example_dir}. "
                f"Use use_force=True to overwrite."
            )
    
    # Example data URL and checksum
    example_url = "https://cloudstor.aarnet.edu.au/plus/s/WC2t7AkLpqzwblE/download"
    expected_md5 = "baaec067ccafdf0621e5bf1b1fcc704f"
    
    try:
        # Download example data unless extract_only is True
        if not extract_only:
            print("Downloading pyTax4Fun2 example data...")
            download_with_checksum(
                url=example_url,
                destfile=zip_file,
                expected_md5=expected_md5 if verify_download else None,
                max_retries=3,
                show_progress=show_progress
            )
        elif not zip_file.exists():
            raise pyTax4Fun2Error(f"Zip file not found for extraction: {zip_file}")
        
        # Extract files
        print("Extracting example data...")
        extract_zip_with_validation(zip_file, work_dir, show_progress)
        
        # Verify extraction
        if not example_dir.exists():
            raise pyTax4Fun2Error("Extraction failed - ExampleData directory not created")
        
        # Clean up zip file if we downloaded it
        if not extract_only and zip_file.exists():
            zip_file.unlink()
        
        # Analyze extracted data
        print("\nAnalyzing example data...")
        analysis_results = analyze_example_data(example_dir)
        
        # Display summary
        print_summary(example_dir, analysis_results)
        
        # Create README file
        create_readme_file(example_dir, analysis_results)
        
        # Return path for programmatic use
        return str(example_dir)
        
    except Exception as e:
        # Clean up on error
        if zip_file.exists():
            try:
                zip_file.unlink()
            except:
                pass
        if example_dir.exists():
            try:
                shutil.rmtree(example_dir)
            except:
                pass
        raise pyTax4Fun2Error(f"Failed to get example data: {str(e)}")


def extract_zip_with_validation(
    zip_file: Path,
    extract_dir: Path,
    show_progress: bool = True
) -> None:
    """
    Extract zip file with validation and progress tracking.
    
    Args:
        zip_file: Path to zip file
        extract_dir: Directory to extract to
        show_progress: Show extraction progress
        
    Raises:
        pyTax4Fun2Error: If extraction fails
    """
    try:
        # Verify zip file
        if not zip_file.exists():
            raise pyTax4Fun2Error(f"Zip file not found: {zip_file}")
        
        if zip_file.stat().st_size == 0:
            raise pyTax4Fun2Error(f"Zip file is empty: {zip_file}")
        
        # Extract with progress bar
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            # Get total number of files and total size for progress tracking
            file_list = zip_ref.namelist()
            total_files = len(file_list)
            
            if show_progress:
                from tqdm import tqdm
                
                # Create progress bar
                with tqdm(total=total_files, desc="Extracting files") as pbar:
                    for file in file_list:
                        # Extract file
                        zip_ref.extract(file, extract_dir)
                        
                        # Update progress
                        pbar.update(1)
                        
                        # Optional: verify each file was extracted
                        extracted_path = extract_dir / file
                        if not extracted_path.exists():
                            warnings.warn(f"File not extracted: {file}")
            else:
                # Extract all files without progress bar
                zip_ref.extractall(extract_dir)
        
        print(f"Extracted {total_files} files from {zip_file.name}")
        
    except zipfile.BadZipFile:
        raise pyTax4Fun2Error(f"Invalid zip file: {zip_file}")
    except Exception as e:
        raise pyTax4Fun2Error(f"Failed to extract zip file: {str(e)}")


def analyze_example_data(example_dir: Path) -> Dict[str, any]:
    """
    Analyze example data directory structure and content.
    
    Args:
        example_dir: Path to example data directory
        
    Returns:
        Dictionary with analysis results
    """
    analysis = {
        "total_files": 0,
        "total_size_mb": 0,
        "file_types": {},
        "fasta_files": [],
        "fasta_stats": {},
        "directory_structure": []
    }
    
    # Walk through directory
    for item in example_dir.rglob("*"):
        if item.is_file():
            analysis["total_files"] += 1
            file_size_mb = item.stat().st_size / (1024 * 1024)
            analysis["total_size_mb"] += file_size_mb
            
            # Track file types
            ext = item.suffix.lower()
            analysis["file_types"][ext] = analysis["file_types"].get(ext, 0) + 1
            
            # Track FASTA files
            if ext in ['.fasta', '.fa', '.fna', '.ffn']:
                analysis["fasta_files"].append(item)
        
        # Record directory structure (first few levels)
        rel_path = item.relative_to(example_dir)
        depth = len(rel_path.parts)
        if depth <= 3:  # Only show first few levels
            analysis["directory_structure"].append(str(rel_path))
    
    # Analyze FASTA files if any
    if analysis["fasta_files"]:
        print(f"  Found {len(analysis['fasta_files'])} FASTA files")
        
        # Analyze first few FASTA files
        for i, fasta_file in enumerate(analysis["fasta_files"][:3], 1):
            try:
                stats = fasta_stats(fasta_file)
                analysis["fasta_stats"][fasta_file.name] = stats
                print(f"    {i}. {fasta_file.name}: {stats['num_sequences']} sequences")
            except Exception as e:
                warnings.warn(f"Could not analyze {fasta_file.name}: {str(e)}")
    
    return analysis


def print_summary(example_dir: Path, analysis: Dict[str, any]) -> None:
    """
    Print summary of downloaded example data.
    
    Args:
        example_dir: Path to example data directory
        analysis: Analysis results
    """
    print(f"\n{'='*60}")
    print("EXAMPLE DATA DOWNLOAD SUMMARY")
    print(f"{'='*60}")
    print(f"Location: {example_dir.absolute()}")
    print(f"Total files: {analysis['total_files']}")
    print(f"Total size: {analysis['total_size_mb']:.2f} MB")
    
    if analysis['file_types']:
        print("\nFile types:")
        for ext, count in sorted(analysis['file_types'].items()):
            if ext:  # Skip empty extensions
                print(f"  {ext}: {count} files")
    
    if analysis['directory_structure']:
        print("\nDirectory structure (top levels):")
        for path in sorted(analysis['directory_structure'])[:20]:  # Limit output
            print(f"  {path}")
        if len(analysis['directory_structure']) > 20:
            print(f"  ... and {len(analysis['directory_structure']) - 20} more items")
    
    if analysis['fasta_stats']:
        print("\nFASTA file statistics:")
        for filename, stats in analysis['fasta_stats'].items():
            print(f"  {filename}:")
            print(f"    Sequences: {stats['num_sequences']}")
            print(f"    Total length: {stats['total_length']:,} bp")
            print(f"    Avg length: {stats['avg_length']:.1f} bp")
            print(f"    GC content: {stats['gc_content']:.1f}%")
    
    print(f"\n{'='*60}")
    print("Example data ready for use!")
    print("Next steps:")
    print("1. Test installation: python -c 'import pyTax4Fun2; print(\"Import successful\")'")
    print("2. Run example analysis using the provided scripts")
    print("3. Check documentation for tutorial examples")
    print(f"{'='*60}")


def create_readme_file(example_dir: Path, analysis: Dict[str, any]) -> None:
    """
    Create a README file in the example data directory.
    
    Args:
        example_dir: Path to example data directory
        analysis: Analysis results
    """
    readme_path = example_dir / "README.txt"
    
    readme_content = f"""pyTax4Fun2 Example Data
{'='*60}

This directory contains example data for testing and learning pyTax4Fun2.

Summary:
- Total files: {analysis['total_files']}
- Total size: {analysis['total_size_mb']:.2f} MB
- Downloaded on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Directory Structure:
{chr(10).join(f"  {path}" for path in sorted(analysis['directory_structure'])[:30])}

File Types:
{chr(10).join(f"  {ext}: {count}" for ext, count in sorted(analysis['file_types'].items()) if ext)}

FASTA Files:
"""
    
    if analysis['fasta_stats']:
        for filename, stats in analysis['fasta_stats'].items():
            readme_content += f"""
{filename}:
  - Sequences: {stats['num_sequences']}
  - Total length: {stats['total_length']:,} bp
  - Average length: {stats['avg_length']:.1f} bp
  - GC content: {stats['gc_content']:.1f}%
  - Min length: {stats['min_length']} bp
  - Max length: {stats['max_length']} bp
"""
    
    readme_content += f"""
Usage Examples:
1. Extract 16S rRNA from genomes:
   python -c "from pyTax4Fun2 import extract_ssu; extract_ssu(genome_folder='genomes/')"

2. Generate functional predictions:
   python -c "from pyTax4Fun2 import make_functional_prediction; result = make_functional_prediction(path_to_otu_table='otu_table.txt')"

3. Create user database:
   python -c "from pyTax4Fun2 import generate_user_data; generate_user_data(path_to_user_data='.')"

For more examples and documentation, visit:
https://github.com/bwemheu/pyTax4Fun2

Note: This is example data for testing purposes only.
"""

    with open(readme_path, 'w') as f:
        f.write(readme_content)
    
    print(f"README file created: {readme_path.name}")


def validate_example_data(example_dir: Path) -> Dict[str, bool]:
    """
    Validate example data structure and files.
    
    Args:
        example_dir: Path to example data directory
        
    Returns:
        Dictionary with validation results
    """
    validation = {
        "directory_exists": False,
        "has_fasta_files": False,
        "has_otu_table": False,
        "has_genome_files": False,
        "all_files_readable": True,
        "fasta_files_valid": True
    }
    
    if not example_dir.exists():
        return validation
    
    validation["directory_exists"] = True
    
    # Check for expected files
    fasta_files = list(example_dir.rglob("*.fasta")) + list(example_dir.rglob("*.fa"))
    otu_tables = list(example_dir.rglob("*otu*")) + list(example_dir.rglob("*OTU*"))
    genome_files = list(example_dir.rglob("*genome*")) + list(example_dir.rglob("*16S*"))
    
    validation["has_fasta_files"] = len(fasta_files) > 0
    validation["has_otu_table"] = len(otu_tables) > 0
    validation["has_genome_files"] = len(genome_files) > 0
    
    # Validate FASTA files
    if fasta_files:
        for fasta_file in fasta_files[:5]:  # Check first 5 files
            try:
                # Try to read the FASTA file
                df = read_fasta_polars(fasta_file)
                if df.is_empty():
                    validation["fasta_files_valid"] = False
                    warnings.warn(f"Empty FASTA file: {fasta_file.name}")
            except Exception as e:
                validation["fasta_files_valid"] = False
                validation["all_files_readable"] = False
                warnings.warn(f"Invalid FASTA file {fasta_file.name}: {str(e)}")
    
    return validation


def get_example_data_info(example_dir: Optional[Path] = None) -> Dict[str, any]:
    """
    Get information about example data without downloading.
    
    Args:
        example_dir: Optional path to existing example data directory
        
    Returns:
        Dictionary with example data information
    """
    if example_dir is None:
        # Return information about what will be downloaded
        return {
            "name": "pyTax4Fun2 Example Data",
            "description": "Example datasets for testing pyTax4Fun2 functionality",
            "size_mb": "~50 MB (compressed), ~150 MB (extracted)",
            "contents": [
                "Sample genome FASTA files",
                "Example OTU tables",
                "16S rRNA sequences",
                "Reference data samples",
                "Documentation and scripts"
            ],
            "url": "https://cloudstor.aarnet.edu.au/plus/s/WC2t7AkLpqzwblE/download",
            "md5_checksum": "baaec067ccafdf0621e5bf1b1fcc704f"
        }
    else:
        # Analyze existing example data
        if not example_dir.exists():
            raise pyTax4Fun2Error(f"Example data directory not found: {example_dir}")
        
        return analyze_example_data(example_dir)


def create_minimal_example_data(output_dir: Path) -> str:
    """
    Create minimal example data for quick testing.
    
    Args:
        output_dir: Output directory for minimal example data
        
    Returns:
        str: Path to created example data directory
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Create minimal OTU table
    otu_table_content = """OTU_ID\tSample1\tSample2\tSample3
OTU_001\t100\t50\t25
OTU_002\t50\t100\t75
OTU_003\t25\t75\t100
OTU_004\t10\t20\t30
OTU_005\t5\t10\t15
"""
    
    otu_table_path = output_dir / "minimal_otu_table.txt"
    with open(otu_table_path, 'w') as f:
        f.write(otu_table_content)
    
    # Create minimal FASTA file (16S sequences)
    fasta_content = """>OTU_001
ACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGT
ACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGT
>OTU_002
TGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCA
TGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCAATGCA
>OTU_003
CGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTA
CGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTA
>OTU_004
GCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCAT
GCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCAT
>OTU_005
TACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACG
TACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACG
"""
    
    fasta_path = output_dir / "minimal_16s.fasta"
    with open(fasta_path, 'w') as f:
        f.write(fasta_content)
    
    # Create configuration file
    config_content = """# Minimal pyTax4Fun2 Example Configuration
# This is a minimal dataset for testing pyTax4Fun2

[data]
otu_table = "minimal_otu_table.txt"
16s_sequences = "minimal_16s.fasta"

[analysis]
min_identity = 97.0
database_mode = "Ref100NR"

[output]
directory = "minimal_output"
"""
    
    config_path = output_dir / "minimal_config.txt"
    with open(config_path, 'w') as f:
        f.write(config_content)
    
    # Create README
    readme_content = """Minimal pyTax4Fun2 Example Data
====================================

This directory contains minimal example data for testing pyTax4Fun2.

Files:
1. minimal_otu_table.txt - Example OTU table with 5 OTUs and 3 samples
2. minimal_16s.fasta - Corresponding 16S rRNA sequences
3. minimal_config.txt - Configuration file for analysis
4. README.txt - This file

Usage:
1. Place reference data in Tax4Fun2_ReferenceData_v2 directory
2. Run: python -c "from pyTax4Fun2 import make_functional_prediction; result = make_functional_prediction(path_to_otu_table='minimal_otu_table.txt')"

Note: This is minimal test data. For comprehensive examples, use get_example_data().
"""
    
    readme_path = output_dir / "README.txt"
    with open(readme_path, 'w') as f:
        f.write(readme_content)
    
    print(f"\nMinimal example data created at: {output_dir}")
    print(f"Files created:")
    print(f"  - {otu_table_path.name} (OTU table)")
    print(f"  - {fasta_path.name} (16S sequences)")
    print(f"  - {config_path.name} (configuration)")
    print(f"  - {readme_path.name} (documentation)")
    
    return str(output_dir)


def main():
    """Command-line interface for getting example data."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Download example data for pyTax4Fun2"
    )
    parser.add_argument(
        "--working-dir", "-w",
        default=".",
        help="Working directory for download (default: current directory)"
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Overwrite existing example data"
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Hide progress bars"
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="Skip MD5 checksum verification"
    )
    parser.add_argument(
        "--extract-only",
        action="store_true",
        help="Only extract existing zip file (don't download)"
    )
    parser.add_argument(
        "--info",
        action="store_true",
        help="Show information about example data without downloading"
    )
    parser.add_argument(
        "--validate",
        metavar="PATH",
        help="Validate existing example data directory"
    )
    parser.add_argument(
        "--minimal",
        action="store_true",
        help="Create minimal example data for quick testing"
    )
    parser.add_argument(
        "--output-dir",
        default="MinimalExampleData",
        help="Output directory for minimal example data (default: MinimalExampleData)"
    )
    
    args = parser.parse_args()
    
    try:
        if args.info:
            # Show information without downloading
            info = get_example_data_info()
            print("pyTax4Fun2 Example Data Information:")
            print(f"  Name: {info['name']}")
            print(f"  Description: {info['description']}")
            print(f"  Size: {info['size_mb']}")
            print(f"  URL: {info['url']}")
            print(f"  MD5 Checksum: {info['md5_checksum']}")
            print("\nContents:")
            for item in info['contents']:
                print(f"  - {item}")
        
        elif args.validate:
            # Validate existing example data
            example_dir = Path(args.validate)
            validation = validate_example_data(example_dir)
            
            print(f"Validating example data at: {example_dir}")
            print(f"  Directory exists: {'✓' if validation['directory_exists'] else '✗'}")
            print(f"  Has FASTA files: {'✓' if validation['has_fasta_files'] else '✗'}")
            print(f"  Has OTU table: {'✓' if validation['has_otu_table'] else '✗'}")
            print(f"  Has genome files: {'✓' if validation['has_genome_files'] else '✗'}")
            print(f"  All files readable: {'✓' if validation['all_files_readable'] else '✗'}")
            print(f"  FASTA files valid: {'✓' if validation['fasta_files_valid'] else '✗'}")
            
            if all(validation.values()):
                print("\n✅ Example data validation passed!")
            else:
                print("\n⚠️  Example data validation failed or incomplete")
        
        elif args.minimal:
            # Create minimal example data
            output_dir = Path(args.working_dir) / args.output_dir
            path = create_minimal_example_data(output_dir)
            print(f"\n✅ Minimal example data created at: {path}")
        
        else:
            # Download example data
            path = get_example_data(
                path_to_working_directory=args.working_dir,
                use_force=args.force,
                show_progress=not args.no_progress,
                verify_download=not args.no_verify,
                extract_only=args.extract_only
            )
            print(f"\n✅ Example data ready at: {path}")
            
    except Exception as e:
        print(f"\n❌ Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    import sys
    main()
