# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi
"""Execution session helpers for core logic."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from bijux_canon_index.core.errors import InvariantError
from bijux_canon_index.core.identity.ids import fingerprint
from bijux_canon_index.core.runtime.execution_plan import ExecutionPlan
from bijux_canon_index.core.runtime.vector_execution import (
    RandomnessProfile,
    VectorExecution,
)
from bijux_canon_index.core.types import ExecutionArtifact, ExecutionRequest


class ExecutionState(StrEnum):
    """Enumeration of execution state."""

    CREATED = "created"
    PLANNED = "planned"
    RUNNING = "running"
    COMMITTED = "committed"
    FINALIZED = "finalized"

    def can_transition_to(self, target: ExecutionState) -> bool:
        """Handle can transition to."""
        allowed = {
            ExecutionState.CREATED: {ExecutionState.PLANNED},
            ExecutionState.PLANNED: {ExecutionState.RUNNING},
            ExecutionState.RUNNING: {
                ExecutionState.COMMITTED,
                ExecutionState.FINALIZED,
            },
            ExecutionState.COMMITTED: {ExecutionState.FINALIZED},
            ExecutionState.FINALIZED: set(),
        }
        return target in allowed[self]


def enforce_transition(
    current: ExecutionState, target: ExecutionState
) -> ExecutionState:
    """Enforce transition."""
    if not current.can_transition_to(target):
        raise InvariantError(
            message=f"Illegal execution state transition {current.value} -> {target.value}"
        )
    return target


@dataclass(frozen=True)
class ExecutionSession:
    """Immutable execution session: the only boundary allowed to run executions."""

    session_id: str
    artifact: ExecutionArtifact
    request: ExecutionRequest
    plan: ExecutionPlan
    execution: VectorExecution
    randomness: RandomnessProfile | None
    budget: dict[str, int | float]
    state: ExecutionState = ExecutionState.CREATED


def derive_session_id(
    artifact: ExecutionArtifact,
    request: ExecutionRequest,
    plan: ExecutionPlan,
    execution: VectorExecution,
    randomness: RandomnessProfile | None,
    budget: dict[str, int | float],
    state: ExecutionState = ExecutionState.CREATED,
) -> str:
    """Derive session ID."""
    payload = {
        "artifact": artifact.artifact_id,
        "execution_id": execution.execution_id,
        "plan_fp": plan.fingerprint,
        "contract": request.execution_contract.value,
        "mode": request.execution_mode.value
        if hasattr(request.execution_mode, "value")
        else request.execution_mode,
        "budget": tuple(sorted(budget.items())),
        "randomness": tuple(randomness.sources) if randomness else (),
        "state": state.value,
    }
    return fingerprint(payload)


__all__ = [
    "ExecutionSession",
    "derive_session_id",
    "ExecutionState",
    "enforce_transition",
]
