# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi
"""Config helpers for core logic."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass


@dataclass(frozen=True)
class VectorStoreConfig:
    """Represents vector store config."""

    backend: str | None = None
    uri: str | None = None
    options: Mapping[str, str] | None = None


@dataclass(frozen=True)
class EmbeddingCacheConfig:
    """Represents embedding cache config."""

    backend: str | None = None
    uri: str | None = None
    options: Mapping[str, str] | None = None


@dataclass(frozen=True)
class EmbeddingConfig:
    """Represents embedding config."""

    provider: str | None = None
    model: str | None = None
    cache: EmbeddingCacheConfig | None = None


@dataclass(frozen=True)
class ExecutionConfig:
    """Represents execution config."""

    vector_store: VectorStoreConfig | None = None
    embeddings: EmbeddingConfig | None = None
    resource_limits: ResourceLimits | None = None


@dataclass(frozen=True)
class ResourceLimits:
    """Represents resource limits."""

    max_vectors_per_ingest: int | None = None
    max_k: int | None = None
    max_query_size: int | None = None
    max_execution_time_ms: int | None = None


__all__ = [
    "VectorStoreConfig",
    "EmbeddingCacheConfig",
    "EmbeddingConfig",
    "ExecutionConfig",
    "ResourceLimits",
]
