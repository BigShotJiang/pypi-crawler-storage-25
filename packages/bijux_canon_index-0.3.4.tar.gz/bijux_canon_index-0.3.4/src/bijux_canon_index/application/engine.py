# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi
"""Engine helpers for application workflows."""

from __future__ import annotations

from bijux_canon_index.application.orchestrator import Orchestrator
from bijux_canon_index.core.contracts.execution_abi import assert_execution_abi


class VectorExecutionEngine(Orchestrator):
    """Thin wrapper aliasing Orchestrator to the public engine name."""

    # Explicit pass-throughs to keep public surface stable and testable
    def list_artifacts(
        self, *, limit: int | None = None, offset: int = 0
    ) -> dict[str, object]:
        """List artifacts."""
        return super().list_artifacts(limit=limit, offset=offset)

    def capabilities(self) -> dict[str, object]:
        """Handle capabilities."""
        return super().capabilities()


assert_execution_abi()

__all__ = ["VectorExecutionEngine"]
