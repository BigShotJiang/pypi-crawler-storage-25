# ----------------------------------------------------------------------------
# Description    : Sequencer Real Mode related validators
# Git repository : https://gitlab.com/qblox/packages/software/qblox_instruments.git
# Copyright (C) Qblox BV (2025)
# ----------------------------------------------------------------------------
from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from qcodes.validators import Validator

if TYPE_CHECKING:
    from qblox_instruments.qcodes_drivers.sequencer import Sequencer


T = TypeVar("T")


class RealModeCompatibleValidator(Validator[T]):
    """
    Validator for parameters that can conflict with `real_mode_en`.

    Parameters
    ----------
    sequencer : Sequencer
        Sequencer object used to get the value of `real_mode_en`.
    valid_value : T
        When `real_mode_en` is enabled, this setting defines the allowed parameter value if `invert`
        is True, or the forbidden value if `invert` is False.
    invert : bool
        Invert the validity check.

    """

    def __init__(self, sequencer: Sequencer, valid_value: T, invert: bool) -> None:
        super().__init__()
        self._sequencer = sequencer
        self._valid_value = valid_value
        self._invert = invert

    def validate(self, value: T, context: str = "") -> None:
        # Value is
        if self._sequencer._get_cached_qcodes_parameter("real_mode_en") and (
            (value != self._valid_value) ^ self._invert
        ):
            raise ValueError(
                f"Can{'not' if self._invert else ' only'} set this parameter to "
                f"{self._valid_value} when 'real_mode_en=True'"
            )
