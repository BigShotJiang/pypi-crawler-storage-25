# ----------------------------------------------------------------------------
# Description    : Miscellaneous validators
# Git repository : https://gitlab.com/qblox/packages/software/qblox_instruments.git
# Copyright (C) Qblox BV (2026)
# ----------------------------------------------------------------------------
from __future__ import annotations

from typing_extensions import TypeVarTuple, Unpack

from qcodes.validators import Validator

Ts = TypeVarTuple("Ts")


class TupleValidator(Validator[tuple[Unpack[Ts]]]):
    """
    Validator for parameters that can conflict with `real_mode_en`.

    Parameters
    ----------
    sequencer : Sequencer
        Sequencer object used to get the value of `real_mode_en`.
    valid_value : T
        When `real_mode_en` is enabled, this setting defines the allowed parameter value if `invert`
        is True, or the forbidden value if `invert` is False.
    invert : bool
        Invert the validity check.

    """

    def __init__(self, validators: tuple[Validator, ...]) -> None:
        super().__init__()
        self._validators = validators
        self._valid_value = (tuple(val._valid_values[0] for val in validators),)

    def validate(self, value: tuple[Unpack[Ts]], context: str = "") -> None:
        if not isinstance(value, list):
            raise TypeError(f"{value!r} is not a tuple; {context}")
        if len(value) != len(self._validators):
            raise TypeError(
                f"{value!r} is of wrong arity {len(value)}, should be {len(self._validators)}; "
                + context
            )

        for elt, val in zip(value, self._validators):
            val.validate(elt)
