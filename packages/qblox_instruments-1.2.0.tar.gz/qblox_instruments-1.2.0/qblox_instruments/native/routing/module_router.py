# --------------------------------------------------------------------------
# Description    : Module routing logic
# Git repository : https://gitlab.com/qblox/packages/software/qblox_instruments_private.git
# Copyright (C) Qblox BV (2026)
# --------------------------------------------------------------------------

from typing import (
    Any,
    Optional,
)

from qblox_instruments.types import (
    HasSeqIdx,
    HasSlotIdx,
    ModuleConfigType,
    ModuleSource,
    RouterConfig,
    RouterID,
    TargetInput,
)


class SMFModuleRouter:
    """
    Calculates internal routing configurations for Qblox Modules.
    Ensures all targets belong to the same physical module.
    """

    def get_compiled_routes(
        self,
        targets: Optional[TargetInput] = None,
        source: Optional[ModuleSource] = None,
        config_type: ModuleConfigType = ModuleConfigType.BOTH,
    ) -> list[RouterConfig]:
        """
        Generates the routing configuration list.

        Parameters
        ----------
        targets : Optional[TargetInput]
            Single Module/Sequencer or list of them.
            Required if config_type is SCATTER or BOTH.
        source : Optional[ModuleSource]
            Input Source selection.
            Required if config_type is GATHER or BOTH.
        config_type : ModuleConfigType
            Which part of the router to configure (default: BOTH).

        Returns
        -------
        list[RouterConfig]
            JSON-serializable list of router configurations.
            Example: [{"router_id": 1, "mask": 5}, ...]

        """
        results: list[RouterConfig] = []

        # Handle Gather router (Router ID 1)
        if config_type in (ModuleConfigType.GATHER, ModuleConfigType.BOTH):
            if source is None:
                raise ValueError("Argument 'source' is required for GATHER configuration.")

            results.append({"router_id": RouterID.GATHER, "mask": int(source)})

        # Handle Scatter router (Router ID 2)
        if config_type in (ModuleConfigType.SCATTER, ModuleConfigType.BOTH):
            if targets is None:
                raise ValueError("Argument 'targets' is required for SCATTER configuration.")

            scatter_mask = self._resolve_combined_scatter_mask(targets)

            results.append({"router_id": RouterID.SCATTER, "mask": scatter_mask})

        return results

    def _resolve_combined_scatter_mask(self, targets: TargetInput) -> int:
        """
        Iterates over all targets, validates they are on the same module,
        and combines their bitmasks.
        """
        total_mask = 0
        reference_slot: Optional[int] = None

        # Normalize input to a list
        target_list = [targets] if not isinstance(targets, (list, tuple)) else targets

        for obj in target_list:
            mask, slot = self._resolve_single_target(obj)

            # Validation: Ensure all targets are on the same module
            if reference_slot is None:
                reference_slot = slot
            elif slot != reference_slot:
                raise ValueError(
                    f"Target consistency error: Targets belong to different modules "
                    f"(Slot {reference_slot} vs Slot {slot}). "
                    "Internal routing must be within a single module."
                )

            total_mask |= mask

        return total_mask

    def _resolve_single_target(self, obj: Any) -> tuple[int, int]:
        """
        Resolves a single object to (Bitmask, SlotIndex).
        """
        # Sequencer Object
        if isinstance(obj, HasSeqIdx) or hasattr(obj, "seq_idx"):
            # Get Index
            val = obj.seq_idx
            idx = val() if callable(val) else val

            # Get Parent Module
            parent = getattr(obj, "parent", None) or getattr(obj, "_parent", None)

            if not parent:
                raise ValueError(f"Could not determine parent module for Sequencer {obj}")

            # Validate Bounds
            limit = self._get_sequencer_count(parent)
            if idx >= limit:
                raise ValueError(f"Sequencer index {idx} out of bounds (Limit: {limit}).")

            # Get Slot Index (for consistency check)
            slot = parent.slot_idx() if callable(parent.slot_idx) else parent.slot_idx

            return (1 << idx), slot

        # Module Object
        if isinstance(obj, HasSlotIdx) or hasattr(obj, "slot_idx"):
            # Get Slot Index
            slot = obj.slot_idx() if callable(obj.slot_idx) else obj.slot_idx

            # Calculate All Sequencers Mask
            num_seq = self._get_sequencer_count(obj)
            mask = (1 << num_seq) - 1

            return mask, slot

        raise TypeError(f"Invalid target type: {type(obj)}. Expected Sequencer or Module.")

    def _get_sequencer_count(self, module: Any) -> int:
        """Helper to determine the number of sequencers on a module."""
        # Try constant lookup
        if hasattr(module, "_get_module_constants"):
            try:
                constants = module._get_module_constants()
                if hasattr(constants, "NUM_SEQ"):
                    return constants.NUM_SEQ
            except Exception:
                pass

        # Try 'sequencers' attribute
        if hasattr(module, "sequencers"):
            return len(module.sequencers)

        # Default fallback
        return 6
