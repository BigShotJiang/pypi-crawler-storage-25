# --------------------------------------------------------------------------
# Description    : Cluster routing logic
# Git repository : https://gitlab.com/qblox/packages/software/qblox_instruments_private.git
# Copyright (C) Qblox BV (2026)
# --------------------------------------------------------------------------

from collections import defaultdict
from dataclasses import dataclass
from typing import (
    ClassVar,
    Optional,
    Union,
)

from qblox_instruments.types import (
    HasSeqIdx,
    HasSlotIdx,
    RouterConfig,
    RouterInputItem,
    RouterInputPair,
)


class _RouterProgram:
    """
    Accumulates bitmask activations for all routers.
    Handles the merging of multiple requests (e.g., if G1 uses pin 0 and pin 1).
    """

    def __init__(self, router_specs: dict[str, tuple[int, int]]) -> None:
        self._outputs = defaultdict(set)
        self._specs = router_specs

    def activate(self, router_name: str, output_idx: int) -> None:
        self._outputs[router_name].add(output_idx)

    def get_compiled_codes(self) -> list[tuple[str, int]]:
        """Converts accumulated output indices into integer bitmasks."""
        results = []
        for name, indices in self._outputs.items():
            if name not in self._specs:
                continue
            _, num_outputs = self._specs[name]

            mask = 0
            for idx in indices:
                if 0 <= idx < num_outputs:
                    mask |= 1 << idx
            results.append((name, mask))
        return results


@dataclass(frozen=True)
class _PathOption:
    """Represents a potential path from a Gather router to a destination."""

    g_out: int
    path: list[tuple[str, int]]
    bypass: bool
    next_hop: str


class _BaseRouter:
    def __init__(self, name: str, specs: dict[str, tuple[int, int]]) -> None:
        self.name = name
        self.num_inputs, self.num_outputs = specs[name]


class _Scatter(_BaseRouter):
    """
    Final stage router (S1-S7).
    Knows which physical module ports ("1A", "9", etc.) it is connected to.
    """

    def __init__(
        self, name: str, physical_outputs: list[str], specs: dict[str, tuple[int, int]]
    ) -> None:
        super().__init__(name, specs)
        self.physical_outputs = physical_outputs

    def get_output_index_for_target(self, target_port: str) -> Optional[int]:
        """Returns the output pin index if this Scatter router connects to the target."""
        try:
            return self.physical_outputs.index(target_port)
        except ValueError:
            return None


class _Central(_BaseRouter):
    """
    Middle stage router (A-D).
    Knows how to route to Scatter routers.
    """

    def __init__(
        self, name: str, connections: dict[int, tuple[str, int]], specs: dict[str, tuple[int, int]]
    ) -> None:
        super().__init__(name, specs)
        self.connections = connections  # {OutputPin: (ScatterName, ScatterInputPin)}

    def resolve_path_to_scatter(
        self, target_port: str, scatters: dict[str, "_Scatter"]
    ) -> Optional[list[tuple[str, int]]]:
        """
        Checks if this Central router can reach the target via any connected Scatter router.
        Returns: [(CentralName, CentralOutPin), (ScatterName, ScatterOutPin)] or None.
        """
        for central_out, (scatter_name, scatter_in) in self.connections.items():
            scatter_router = scatters.get(scatter_name)

            # Validation: Ensure scatter exists and input pin is valid
            if scatter_router and 0 <= scatter_in < scatter_router.num_inputs:
                scatter_out = scatter_router.get_output_index_for_target(target_port)

                if scatter_out is not None:
                    # Path found!
                    return [(self.name, central_out), (scatter_name, scatter_out)]
        return None


class _Gather(_BaseRouter):
    """
    First stage router (G1-G7).
    Knows the inputs from modules and connects to Central or Scatter routers.
    Implements the main Load Balancing and Bypass logic.
    """

    def __init__(
        self,
        name: str,
        physical_inputs: list[str],
        connections: dict[int, tuple[str, int]],
        specs: dict[str, tuple[int, int]],
    ) -> None:
        super().__init__(name, specs)
        self.physical_inputs = physical_inputs
        self.connections = connections

    def has_input_port(self, port: str) -> bool:
        return port in self.physical_inputs

    def _find_best_route_single(
        self, target_port: str, centrals: dict[str, _Central], scatters: dict[str, _Scatter]
    ) -> Optional[_PathOption]:
        """Internal helper to find routes for a single target."""
        possible_paths: list[_PathOption] = []

        # Iterate through all outgoing connections from this Gather router
        for g_out_idx, (dest_name, dest_in_idx) in self.connections.items():
            # Bypass Logic (Gather -> Scatter)
            if dest_name.startswith("S"):
                scatter = scatters.get(dest_name)
                if scatter and 0 <= dest_in_idx < scatter.num_inputs:
                    s_out_idx = scatter.get_output_index_for_target(target_port)
                    if s_out_idx is not None:
                        # Found a valid bypass!
                        possible_paths.append(
                            _PathOption(
                                g_out=g_out_idx,
                                path=[(dest_name, s_out_idx)],
                                bypass=True,
                                next_hop=dest_name,
                            )
                        )

            # Central Logic (Gather -> Central -> Scatter)
            elif dest_name in centrals:
                # Standard Path: Ask Central router to find the rest of the way
                central = centrals[dest_name]
                c_path = central.resolve_path_to_scatter(target_port, scatters)

                if c_path:
                    possible_paths.append(
                        _PathOption(
                            g_out=g_out_idx,
                            path=c_path,
                            bypass=False,
                            next_hop=dest_name,
                        )
                    )

        if not possible_paths:
            return None

        # Path Selection: Prefer Bypass (True > False), then lowest Gather Output Index
        return min(possible_paths, key=lambda p: (not p.bypass, p.g_out))

    def resolve_batch_routes(
        self, targets: list[str], centrals: dict[str, _Central], scatters: dict[str, _Scatter]
    ) -> list[tuple[str, int]]:
        """
        Resolves routes for multiple targets from this single Gather source.
        Performs 'Path Consolidation': If any target requires a Central router,
        it attempts to route bypass-capable targets through that same Central
        router to avoid activating multiple output pins for the same signal.
        """
        initial_results = []
        required_centrals = set()

        # Calculate best individual routes
        for target in targets:
            best_route = self._find_best_route_single(target, centrals, scatters)
            if not best_route:
                raise ValueError(f"No routing path found from '{self.name}' to '{target}'.")

            route_data = {
                "target": target,
                "path": [(self.name, best_route.g_out), *best_route.path],
                "is_bypass": best_route.bypass,
                "central_used": None,
            }

            if not best_route.bypass:
                # It used a Central router
                central_name = best_route.next_hop
                route_data["central_used"] = central_name
                required_centrals.add(central_name)

            initial_results.append(route_data)

        # Consolidate paths if needed
        # If we are forced to use a Central router for at least one target,
        # try to move the bypass targets to that Central router as well.
        if required_centrals:
            # Pick the first required central
            primary_central_name = sorted(required_centrals)[0]
            primary_central = centrals[primary_central_name]

            # Find which Gather output connects to this Central
            gather_out_idx = next(
                idx for idx, conn in self.connections.items() if conn[0] == primary_central_name
            )

            for res in initial_results:
                # If this target was using a bypass, try to upgrade it to Central
                if res["is_bypass"]:
                    new_subpath = primary_central.resolve_path_to_scatter(res["target"], scatters)
                    if new_subpath:
                        # Success! Reroute via Central
                        res["path"] = [(self.name, gather_out_idx), *new_subpath]
                        res["is_bypass"] = False
                        res["central_used"] = primary_central_name

        # Flatten results
        final_activations = []
        for res in initial_results:
            final_activations.extend(res["path"])

        return final_activations


class SMFCMMRouter:
    """
    Manages the routing logic for the SMF.

    It abstracts the internal topology of Gather (G), Central (A-D), and Scatter (S) routers
    to provide a high-level interface for connecting modules.
    """

    # Force usage of "A" ports only for slots 1-8.
    # If True, Slot 1 always maps to '1A', ignoring '1B'.
    _USE_ONLY_A_PORTS = True

    # --- Router Specifications & Topology Definitions ---

    # RouterName: (NoOfInputPins, NoOfOutputPins)
    _ROUTER_SPECS: ClassVar[dict[str, tuple[int, int]]] = {
        # Gather Routers (Gx)
        "G1": (4, 5),
        "G2": (4, 3),
        "G3": (4, 5),
        "G4": (4, 3),
        "G5": (4, 5),
        "G6": (4, 5),
        "G7": (4, 5),
        # Central Routers (A-D)
        "A": (5, 6),
        "B": (7, 8),
        "C": (6, 5),
        "D": (8, 7),
        # Scatter Routers (Sx)
        "S1": (5, 4),
        "S2": (3, 4),
        "S3": (5, 4),
        "S4": (3, 4),
        "S5": (5, 4),
        "S6": (5, 4),
        "S7": (5, 4),
    }

    # Inputs connected to the GX (Which Gather router serves which module port)
    _GATHER_INPUTS: ClassVar[dict[str, list[str]]] = {
        "G1": [f"{i}A" for i in range(1, 5)],  # Slots 1-4 A-side
        "G2": [f"{i}B" for i in range(1, 5)],  # Slots 1-4 B-side
        "G3": [f"{i}A" for i in range(5, 9)],  # Slots 5-8 A-side
        "G4": [f"{i}B" for i in range(5, 9)],  # Slots 5-8 B-side
        "G5": [str(i) for i in range(9, 13)],  # Slots 9-12
        "G6": [str(i) for i in range(13, 17)],  # Slots 13-16
        "G7": [str(i) for i in range(17, 21)],  # Slots 17-20
    }

    # Outputs connected to SX (Which Scatter router connects to which module port)
    _SCATTER_OUTPUTS: ClassVar[dict[str, list[str]]] = {
        "S1": [f"{i}A" for i in range(1, 5)],
        "S2": [f"{i}B" for i in range(1, 5)],
        "S3": [f"{i}A" for i in range(5, 9)],
        "S4": [f"{i}B" for i in range(5, 9)],
        "S5": [str(i) for i in range(9, 13)],
        "S6": [str(i) for i in range(13, 17)],
        "S7": [str(i) for i in range(17, 21)],
    }

    # --- Internal Connections ---

    # Gather (Gx) -> Next Hop.
    # Format: { OutputPin: (DestRouterName, DestInputPin) }
    _GATHER_CONNECTIONS: ClassVar[dict[str, dict[int, tuple[str, int]]]] = {
        "G1": {0: ("A", 0), 1: ("B", 0), 2: ("C", 1), 3: ("D", 0), 4: ("S1", 4)},
        "G2": {0: ("B", 1), 1: ("D", 2), 2: ("S2", 2)},
        "G3": {0: ("A", 1), 1: ("B", 2), 2: ("C", 2), 3: ("D", 3), 4: ("S3", 4)},
        "G4": {0: ("B", 3), 1: ("D", 4), 2: ("S4", 2)},
        "G5": {0: ("A", 2), 1: ("B", 4), 2: ("C", 3), 3: ("D", 5), 4: ("S5", 4)},
        "G6": {0: ("A", 3), 1: ("B", 5), 2: ("C", 4), 3: ("D", 6), 4: ("S6", 4)},
        "G7": {0: ("A", 4), 1: ("B", 6), 2: ("C", 5), 3: ("D", 7), 4: ("S7", 4)},
    }

    # Central (A-D) -> Scatter (Sx).
    # Format: { OutputPin: (ScatterName, ScatterInputPin) }
    _CENTRAL_CONNECTIONS: ClassVar[dict[str, dict[int, tuple[str, int]]]] = {
        "A": {1: ("S1", 0), 2: ("S3", 0), 3: ("S5", 0), 4: ("S6", 0), 5: ("S7", 0)},
        "B": {
            0: ("S1", 1),
            2: ("S2", 1),
            3: ("S3", 1),
            4: ("S4", 1),
            5: ("S5", 1),
            6: ("S6", 1),
            7: ("S7", 1),
        },
        "C": {0: ("S1", 2), 1: ("S3", 2), 2: ("S5", 2), 3: ("S6", 2), 4: ("S7", 2)},
        "D": {
            0: ("S1", 3),
            1: ("S2", 2),
            2: ("S3", 3),
            3: ("S4", 2),
            4: ("S5", 3),
            5: ("S6", 3),
            6: ("S7", 3),
        },
    }

    # Mapping from router names to numeric IDs for final JSON output
    _ROUTER_NAME_TO_ID_MAP: ClassVar[dict[str, int]] = {
        **{f"G{i}": i for i in range(1, 8)},  # G1-G7 -> 1-7
        "A": 8,
        "B": 9,
        "C": 10,
        "D": 11,
        **{f"S{i}": i + 11 for i in range(1, 8)},  # S1-S7 -> 12-18
    }

    def __init__(self) -> None:
        self._initialize_topology()

    def get_compiled_routes(
        self,
        *requests: Union[RouterInputPair, list[RouterInputPair]],
    ) -> list[RouterConfig]:
        """
        Compiles source-destination pairs into configuration masks.

        Parameters
        ----------
        *requests : Union[RouterInputPair, list[RouterInputPair]]
            Connection pairs passed as:
            get_compiled_routes((src1, [dst1, dst2]), (src2, [dst3, dst4]))
            OR as a single list:
            get_compiled_routes([(src1, [dst1, dst2]), (src2, [dst3, dst4])])

        Returns
        -------
        list[RouterConfig]
            JSON-serializable list of router configurations.
            Example: [{"router_id": 1, "mask": 5}, ...]

        """
        # Flatten input: handle both *args of pairs and a single list of pairs
        if len(requests) == 1 and isinstance(requests[0], list):
            actual_requests = requests[0]
        else:
            actual_requests = list(requests)

        normalized_requests = []

        for src, dst in actual_requests:
            # Handle source as single or list
            src_list = (
                src
                if isinstance(src, (list, tuple))
                and not hasattr(src, "slot_idx")
                and not hasattr(src, "seq_idx")
                else [src]
            )
            dst_list = dst if isinstance(dst, list) else [dst]

            for s in src_list:
                phy_src = self._resolve_port(s)
                phy_dsts = [self._resolve_port(d) for d in dst_list]
                normalized_requests.append((phy_src, phy_dsts))

        # Execute Routing Algorithm
        try:
            router_configs = self._solve(normalized_requests)
        except ValueError as e:
            # Re-wrap error for clarity
            raise ValueError(f"Routing failed: {e}")

        # Format Output
        return [{"router_id": self._ROUTER_NAME_TO_ID_MAP[n], "mask": m} for n, m in router_configs]

    def _resolve_port(self, obj: RouterInputItem) -> str:
        """
        Smart Resolver with strict type checks.
        """
        slot_idx: Optional[int] = None

        # Check Module Protocol
        if isinstance(obj, HasSlotIdx) or hasattr(obj, "slot_idx"):
            val = obj.slot_idx
            slot_idx = val() if callable(val) else val

        # Check Sequencer Protocol
        elif isinstance(obj, HasSeqIdx) or hasattr(obj, "seq_idx"):
            parent = getattr(obj, "parent", None) or getattr(obj, "_parent", None)

            if not parent or (not hasattr(parent, "slot_idx")):
                raise ValueError(f"Could not determine parent module slot for Sequencer {obj}")

            val = parent.slot_idx
            slot_idx = val() if callable(val) else val

        if slot_idx is None:
            raise TypeError(
                f"Invalid object for routing: '{obj}' (type: {type(obj).__name__}).\n"
                "Expected an object matching one of these protocols:\n"
                "  1. Module: Has a 'slot_idx' property.\n"
                "  2. Sequencer: Has a 'seq_idx' property and a parent Module."
            )
        # Map Slot ID to Port String
        elif slot_idx <= 8:
            # Slots 1-8 have 'A' and 'B' sides.
            # Configuration: Force 'A' if requested.
            if self._USE_ONLY_A_PORTS:
                return f"{slot_idx}A"
            else:
                # At the moment, we're only using phy A.
                raise NotImplementedError("Load balancing is not implemented!")
        else:
            # Slots 9+ are single ports
            return str(slot_idx)

    def _initialize_topology(self) -> None:
        """Builds the internal object graph of Gather, Central, and Scatter routers."""
        self.scatters = {
            name: _Scatter(name, outputs, self._ROUTER_SPECS)
            for name, outputs in self._SCATTER_OUTPUTS.items()
        }
        self.centrals = {
            name: _Central(name, conns, self._ROUTER_SPECS)
            for name, conns in self._CENTRAL_CONNECTIONS.items()
        }
        self.gathers = {
            name: _Gather(
                name,
                self._GATHER_INPUTS[name],
                self._GATHER_CONNECTIONS[name],
                self._ROUTER_SPECS,
            )
            for name in self._GATHER_INPUTS
        }

    def _solve(self, reqs: list[tuple[str, list[str]]]) -> list[tuple[str, int]]:
        """
        Core Solver Loop.
        Iterates through requests and accumulates router activations.
        """
        program = _RouterProgram(self._ROUTER_SPECS)

        for start_port, target_ports in reqs:
            # Identify Start Gather Router
            gather_router = next(
                (g for g in self.gathers.values() if g.has_input_port(start_port)), None
            )

            if not gather_router:
                raise ValueError(
                    f"Start port '{start_port}' invalid or not found on any Gather router."
                )

            # Resolve Routes
            try:
                activations = gather_router.resolve_batch_routes(
                    target_ports, self.centrals, self.scatters
                )

            except ValueError as e:
                raise ValueError(f"Routing failed for source '{start_port}': {e}")

            for router_name, output_idx in activations:
                program.activate(router_name, output_idx)

        return program.get_compiled_codes()
