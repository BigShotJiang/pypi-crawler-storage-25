# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.0] - 2026-04-10

### Added

- Add `--auto-migrate` argument to `qblox-cfg update` used with Qblox OS packages to automatically
  migrate modules still on Pulsar OS. (!550)
- Add `is_dc_cluster` and `bp_serial_number` info to `qblox-cfg describe`. (!567)
- Expose the Real Sequencer Mode via the QCoDeS parameter `real_mode_en`, defined on QRM and QCM
  sequencers. When this mode is enabled, path 0 is simply amplitude-modulated with the NCO, while
  path 1 bypasses the NCO and is summed with path 0 after modulation. The combined path is usable as
  the I path in the channel mapping, while the Q path is not used. (!549, !557)
- Add LINQ-based feedback commands for communication between sequencers in the same module, between
  modules and later between clusters. (!584)
- Add `Cluster.get_sequencer_registers`, `Cluster.set_sequencer_registers`,
  `Sequencer.get_register`, `Sequencer.get_registers`, `Sequencer.set_register`,
  `Sequencer.set_registers`, which allow the user to dynamically set and get register values of the
  Q1 processor. Note this feature is only supported for clusters running firmware v2.0.0 and higher.
  (!559)

### Changed

- Constrain `slew_rate` for QSM IO channels to a range between 19 mV/s and 19999 V/s. (!596)
- Increase cluster firmware update timeout from 240 to 480 seconds to accommodate complex module
  configurations. (!550)

### Fixed

- Error when connecting to a cluster containing only a CMM and no other modules. (!561)
- In `Cluster` objects with a dummy connection, `io_channel.get_scope_data()` on a QTM IO channel
  will now return a mock value of the correct type. (!566)
- Outdated parameter values incorrectly persisting after automatic mixer calibration. (!563)
- Unresponsive QRC module preventing initialization of `Cluster` objects. (!570)
- Handle empty responses during firmware update polling; now raises a descriptive `ConnectionError`
  with recovery steps if a module becomes unresponsive. (!580)

### Compatibility

- Cluster: Compatible with firmware versions
  [>=0.13.0, \<3](https://gitlab.com/qblox/releases/cluster_releases/-/releases/).
- Includes all features from firmware
  [v1.0.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v1.0.0).

## [1.1.1] - 2026-02-02

### Fixed

- Make SCPI commands discoverable by the `Cluster` class (e.g. `get_system_error`,
  `get_num_system_error`, `check_error_queue`, `clear_error_queue`, `identify`, and all
  `get_xxx_temperature` commands were not discoverable). (!554)

### Compatibility

- Cluster: Compatible with firmware versions
  [>=0.13.0, \<3](https://gitlab.com/qblox/releases/cluster_releases/-/releases/).
- Includes all features from firmware
  [v1.0.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v1.0.0).

## [1.1.0] - 2026-01-29

### Added

- Extend support for additional firmware versions. As of v1.1.0, `qblox-instruments` versions are no
  longer strictly tied to cluster firmware versions. You may now independently update
  `qblox-instruments` to `>=1.1.0` and cluster firmware to `>=0.13.0` without breaking code or
  experiments. Access to new features will still require updating one or both. (!485)
- Add support for our new quantum readout & control module (the QRC).
- Add mac address to `DeviceInfo`. This information can be retrieved via the method
  `Cluster.get_json_description()["mac_address"]` or via `qblox-cfg <ip> describe`. (!524)
- Add `--skip-version-check` to `qblox-cfg` to skip update compatibility checks. (!544)

### Changed

- **BREAKING:** Support dynamic loading of SCPI commands from the cluster. (!506)

  To support dynamic loading of SCPI commands, `qblox_instruments.native.Cluster` uses
  **composition** instead of **inheritance** from `qblox_instruments.scpi.Cluster`. This change is
  breaking for users that create custom `native.Cluster` subclasses that override commands from the
  SCPI layer such as `_write` or `_read`. To achieve the same behavior, these methods will now need
  to be monkey patched, e.g.:

  ```python
  class SuperCluster(Cluster):
      def __init__(self, *args, **kwargs):
          super().__init__(*args, **kwargs)
          self._scpi._write = self._write

      def _write(self, *args, **kwargs):
          pass
  ```

  Alternatively, we provided a `qblox_instruments.native.ClusterLegacy` class that behaves as
  `native.Cluster` in `qblox-instruments==1.0` that supports inheritance. Note that this legacy
  class is not compatible with the new QRC module.

### Fixed

- Allow users to install `qblox-instruments` using poetry. (!542)

### Compatibility

- Cluster: Compatible with firmware versions
  [>=0.13.0, \<3](https://gitlab.com/qblox/releases/cluster_releases/-/releases/).
- Includes all features from firmware
  [v1.0.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v1.0.0).

## [1.0.3] - 2025-12-15

### Fixed

- Modules no longer report QCoDeS parameters and methods that belong to other modules. (!490, !503)

### Compatibility

- Cluster: compatible with device firmware
  [v0.13.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.13.0).

## [1.0.2] - 2025-11-11

### Added

- Download and install the latest cluster firmware when running `qblox-cfg <ip> update` without
  specifying a firmware file. (!476)
- Issue a warning when a Cluster has an invalid serial number when running `qblox-pnp list`. (!458)
- Expose set config functions for the QSM along with input validation. (!464)

### Fixed

- Add a missing `INITIALIZE` flag to prevent a `KeyError` that was sometimes raised on
  `Cluster.get_system_status()` shortly after boot. (!479)
- Handle `"modules": null` when connecting to an empty cluster. (!471)
- Correctly handle .zip files when updating firmware. (!482)

### Compatibility

- Cluster: compatible with device firmware
  [v0.13.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.13.0).

## [1.0.1] - 2025-11-03

### Compatibility

- Cluster: compatible with device firmware
  [v0.13.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.13.0).

## [1.0.0] - 2025-10-29

### Added

- Add `Sequence.update_sequence` method to send partial updates to a previously set sequence. This
  can drastically reduce experiment runtime. (!433)
- Add option `as_numpy` to `Cluster.get_waveforms`, `Cluster.get_weights`,
  `Cluster.get_acquisitions` to return data as NumPy arrays instead of Python lists. Passing
  `as_numpy=True` can reduce experiment runtime. (!433)
- Add `Module.toggle_all_lo` method to toggle all local oscillators on the module. (!401)
- Add option `epoch` to the accepted `io_channel.binned_acq_time_ref` QCoDeS parameter set values.
  (!457)

### Changed

- Improve performance of acquisition retrieval by up to a factor of two. (!433)
- Improve readability of `print_readable_snapshot` by increasing spacing. (!447)
- Improve `Module.__repr__` to display a human-readable string when printing a module directly or
  with `Cluster.get_connected_modules()`. (!204)

### Fixed

- Resolve an issue that caused firmware updates to fail on some clusters running 0.9.x firmware.
  (!461)
- Allow non-ASCII characters as comments in Q1ASM programs. (!444)
- Allow connecting to a cluster without any modules present. (!471)
- Ensure that `connected` and `present` QCoDeS parameters always return a consistent value in
  snapshots, without sending unnecessary SCPI commands. (!447)
- Register unknown system status flags as `UNKNOWN`. (!453)
- Fail gracefully when connecting to a cluster with an unknown module in `DebugLevel.NO_CHECK` mode.
  (!472)
- `RecursionError` unintentionally being raised under certain circumstances with python 3.10 and
  below. (!483)

### Compatibility

- Cluster: compatible with device firmware
  [v0.13.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.13.0).

______________________________________________________________________

#### Historical Records

Looking for changes prior to version 1.0.0?\
Detailed logs for the **0.x series** are maintained in [HISTORY_v0.rst](./HISTORY_v0.rst).

[1.0.0]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/tags/v1.0.0
[1.0.1]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/compare/v1.0.0...v1.0.1
[1.0.2]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/compare/v1.0.1...v1.0.2
[1.0.3]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/compare/v1.0.2...v1.0.3
[1.1.0]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/compare/v1.0.3...v1.1.0
[1.1.1]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/compare/v1.1.0...v1.1.1
[1.2.0]: https://gitlab.com/qblox/packages/software/qblox_instruments/-/compare/v1.1.1...v1.2.0
