# --------------------------------------------------------------------------
# Description    : Unit tests for routing logic
# Git repository : https://gitlab.com/qblox/packages/software/qblox_instruments_private.git
# Copyright (C) Qblox BV (2026)
# --------------------------------------------------------------------------

from typing import Callable, Union

import pytest

from qblox_instruments.native.routing.cmm_router import SMFCMMRouter
from qblox_instruments.native.routing.module_router import SMFModuleRouter
from qblox_instruments.types import (
    ModuleConfigType,
    ModuleSource,
)

# -- Mock Classes ------------------------------------------------------------

# The full functionality of the module or the sequensers is not needed for these tests.
# We only need to know the slot index and the number of sequencers.


class MockModule:
    def __init__(self, slot_idx: Union[int, Callable[[], int]], num_seq: int = 6):
        self.slot_idx = slot_idx
        self.num_seq = num_seq

    def _get_module_constants(self):
        class Constants:
            def __init__(self, num_seq):
                self.NUM_SEQ = num_seq

        return Constants(self.num_seq)


class MockSequencer:
    def __init__(self, parent: MockModule, seq_idx: Union[int, Callable[[], int]]):
        self.parent = parent
        self.seq_idx = seq_idx


# -- Helpers -----------------------------------------------------------------


def get_router_config(results, router_name):
    """
    Helper to get a specific router's config from the results list.
    """
    router_id = SMFCMMRouter._ROUTER_NAME_TO_ID_MAP.get(router_name)

    for entry in results:
        if entry["router_id"] == router_id:
            return entry["mask"]
    return None


# -- Tests for SMFCMMRouter --------------------------------------------------


class TestSMFCMMRouter:
    @pytest.fixture
    def router(self):
        return SMFCMMRouter()

    def test_simple_one_to_one(self, router):
        module5 = MockModule(5)
        module9 = MockModule(9)

        requests = [(module9, module5)]
        results = router.get_compiled_routes(requests)

        assert get_router_config(results, "G5") == 0b00001
        assert get_router_config(results, "A") == 0b000100
        assert get_router_config(results, "S3") == 0b0001
        assert len(results) == 3

        module1 = MockModule(1)

        requests = [(module1, module5)]
        results = router.get_compiled_routes(requests)

        assert get_router_config(results, "G1") == 0b00001
        assert get_router_config(results, "A") == 0b000100
        assert get_router_config(results, "S3") == 0b0001
        assert len(results) == 3

    def test_one_to_many(self, router):
        module5 = MockModule(5)
        module9 = MockModule(9)
        module10 = MockModule(10)

        requests = [(module9, [module5, module10])]
        results = router.get_compiled_routes(requests)

        assert get_router_config(results, "G5") == 0b00001
        assert get_router_config(results, "A") == 0b001100
        assert get_router_config(results, "S3") == 0b0001
        assert get_router_config(results, "S5") == 0b0010
        assert len(results) == 4

    def test_many_to_many(self, router):
        module1 = MockModule(1)
        module4 = MockModule(4)
        module5 = MockModule(5)
        module9 = MockModule(9)
        module10 = MockModule(10)

        requests = [(module9, [module5, module10]), (module1, module4)]
        results = router.get_compiled_routes(requests)

        assert get_router_config(results, "G1") == 0b10000
        assert get_router_config(results, "G5") == 0b00001
        assert get_router_config(results, "A") == 0b001100
        assert get_router_config(results, "S1") == 0b1000
        assert get_router_config(results, "S3") == 0b0001
        assert get_router_config(results, "S5") == 0b0010
        assert len(results) == 6

    def test_using_central_onver_bypass(self, router):
        module8 = MockModule(8)
        module13 = MockModule(13)

        requests = [([module8, module13], [module8, module13])]
        results = router.get_compiled_routes(requests)

        assert get_router_config(results, "G3") == 0b00001
        assert get_router_config(results, "G6") == 0b00001
        assert get_router_config(results, "A") == 0b010100
        assert get_router_config(results, "S3") == 0b1000
        assert get_router_config(results, "S6") == 0b0001
        assert len(results) == 5

    def test_nonexistent_start(self, router):
        module9 = MockModule(9)

        requests_bad_target = [("Test", module9)]
        with pytest.raises(TypeError) as excinfo:
            router.get_compiled_routes(*requests_bad_target)
        assert "invalid object for routing" in str(excinfo.value).lower()

    def test_non_nonexistent_target(self, router):
        module9 = MockModule(9)

        requests_bad_target = [(module9, "Test")]
        with pytest.raises(TypeError) as excinfo:
            router.get_compiled_routes(*requests_bad_target)
        assert "invalid object for routing" in str(excinfo.value).lower()

    def test_invalid_start_index(self, router):
        bad_module = MockModule(99)
        module10 = MockModule(10)
        module5 = MockModule(5)

        with pytest.raises(ValueError, match="Start port '99' invalid"):
            router.get_compiled_routes((bad_module, module5))

        with pytest.raises(ValueError) as excinfo:
            router.get_compiled_routes([(module10, bad_module)])
        assert (
            "routing failed for source '10': no routing path found from 'g5' to '99'"
            in str(excinfo.value).lower()
        )

    def test_multiple_starts_share_central_router_different_outputs(self, router):
        module1 = MockModule(1)
        module5 = MockModule(5)
        module9 = MockModule(9)

        requests = [
            (module1, module5),
            (module5, module9),
        ]
        results = router.get_compiled_routes(*requests)

        assert get_router_config(results, "G1") == 0b00001
        assert get_router_config(results, "G3") == 0b00001
        assert get_router_config(results, "A") == 0b001100
        assert get_router_config(results, "S3") == 0b0001
        assert get_router_config(results, "S5") == 0b0001
        assert len(results) == 5

    def test_one_to_many_targets_all_bypass(self, router):
        module1 = MockModule(1)
        module2 = MockModule(2)
        module3 = MockModule(3)

        requests = [(module1, [module2, module3])]
        results = router.get_compiled_routes(*requests)

        assert get_router_config(results, "G1") == 0b10000
        assert get_router_config(results, "S1") == 0b0110
        assert len(results) == 2

    def test_sequencer_support(self, router):
        module1 = MockModule(1)
        module5 = MockModule(5)
        module9 = MockModule(9)

        sequencer0 = MockSequencer(module1, 0)

        requests = [(sequencer0, module5), (module5, module9)]
        results = router.get_compiled_routes(*requests)

        assert get_router_config(results, "G1") == 0b00001
        assert get_router_config(results, "G3") == 0b00001
        assert get_router_config(results, "A") == 0b001100
        assert get_router_config(results, "S3") == 0b0001
        assert get_router_config(results, "S5") == 0b0001

    def test_resolve_port_module(self, router):
        # Test int slot_idx
        m1 = MockModule(slot_idx=1)
        assert router._resolve_port(m1) == "1A"

        # Test callable slot_idx
        m9 = MockModule(slot_idx=lambda: 9)
        assert router._resolve_port(m9) == "9"

    def test_resolve_port_sequencer(self, router):
        m1 = MockModule(slot_idx=1)
        s1 = MockSequencer(parent=m1, seq_idx=0)
        assert router._resolve_port(s1) == "1A"

        m17 = MockModule(slot_idx=17)
        s17 = MockSequencer(parent=m17, seq_idx=5)
        assert router._resolve_port(s17) == "17"

    def test_resolve_port_error(self, router):
        with pytest.raises(TypeError, match="Invalid object for routing"):
            router._resolve_port("invalid")

        s_no_parent = MockSequencer(parent=None, seq_idx=0)
        with pytest.raises(ValueError, match="Could not determine parent module slot"):
            router._resolve_port(s_no_parent)

    def test_compiled_routes_single(self, router):
        m1 = MockModule(slot_idx=1)
        m9 = MockModule(slot_idx=9)

        # Route from Slot 1A to Slot 9
        routes = router.get_compiled_routes((m1, m9))

        # Check if G1 and S5 are in the results (G1 handles 1A, S5 handles 9)
        router_ids = [r["router_id"] for r in routes]
        assert router._ROUTER_NAME_TO_ID_MAP["G1"] in router_ids
        assert router._ROUTER_NAME_TO_ID_MAP["S5"] in router_ids

    def test_compiled_routes_multiple_targets(self, router):
        m1 = MockModule(slot_idx=1)
        m8 = MockModule(slot_idx=8)
        m9 = MockModule(slot_idx=9)

        routes = router.get_compiled_routes((m1, [m8, m9]))

        g1_id = router._ROUTER_NAME_TO_ID_MAP["G1"]
        g1_config = next(r for r in routes if r["router_id"] == g1_id)

        # G1 input 0 is 1A (bit 0), input 1 is 2A (bit 1).
        # Both route to 9, so both bits should be set in G1 mask if they are active.
        assert g1_config["mask"] > 0

    def test_compiled_routes_explicit_output(self, router):
        """
        Verify that a specific routing request results in a deterministic bitmask configuration.
        Example: Route Slot 1A (G1) to Slot 9 (S5).
        Path: G1 -> A -> S5
        G1 output 0 -> A input 0
        A output 3 -> S5 input 0
        S5 output 0 -> Slot 9.
        """
        m1 = MockModule(slot_idx=1)
        m9 = MockModule(slot_idx=9)

        routes = router.get_compiled_routes((m1, m9))

        expected = [
            {"router_id": 1, "mask": 1},
            {"router_id": 8, "mask": 8},
            {"router_id": 16, "mask": 1},
        ]

        # Sort by router_id for comparison
        routes.sort(key=lambda x: x["router_id"])
        expected.sort(key=lambda x: x["router_id"])

        assert routes == expected

    def test_routing_logic_bypass(self, router):
        m1 = MockModule(slot_idx=1)
        m4 = MockModule(slot_idx=4)

        routes = router.get_compiled_routes((m1, m4))
        router_ids = [r["router_id"] for r in routes]
        assert router._ROUTER_NAME_TO_ID_MAP["G1"] in router_ids
        assert router._ROUTER_NAME_TO_ID_MAP["S1"] in router_ids
        # Central routers (A, B, C, D) should NOT be here if it's a bypass.
        for name in ["A", "B", "C", "D"]:
            assert router._ROUTER_NAME_TO_ID_MAP[name] not in router_ids


# -- Tests for SMFModuleRouter -----------------------------------------------


class TestSMFModuleRouter:
    @pytest.fixture
    def router(self):
        return SMFModuleRouter()

    def test_config_both(self, router):
        module1 = MockModule(1)
        seq0 = MockSequencer(module1, 0)

        res = router.get_compiled_routes(targets=seq0, source=ModuleSource.PHY_A)

        assert res == [
            {"router_id": 1, "mask": 2},
            {"router_id": 2, "mask": 1},
        ]

    def test_config_gather_only(self, router):
        res = router.get_compiled_routes(
            source=ModuleSource.SELF_CAST,
            config_type=ModuleConfigType.GATHER,
        )

        expected = [
            {"router_id": 1, "mask": 1},
        ]
        assert res == expected

    def test_config_scatter_only(self, router):
        module2 = MockModule(2)
        seq3 = MockSequencer(module2, 3)

        res = router.get_compiled_routes(targets=seq3, config_type=ModuleConfigType.SCATTER)
        expected = [
            {"router_id": 2, "mask": 0b1000},
        ]
        assert res == expected

    def test_error_missing_args(self, router):
        with pytest.raises(ValueError, match="source' is required"):
            router.get_compiled_routes(config_type=ModuleConfigType.GATHER)

        with pytest.raises(ValueError, match="targets' is required"):
            router.get_compiled_routes(config_type=ModuleConfigType.SCATTER)

    def test_config_multiple_sequencers(self, router):
        module5 = MockModule(5)
        seq0 = MockSequencer(module5, 0)
        seq3 = MockSequencer(module5, 3)

        res = router.get_compiled_routes(targets=(seq0, seq3), source=ModuleSource.PHY_A)

        expected = [
            {"router_id": 1, "mask": 2},
            {"router_id": 2, "mask": 0b1001},
        ]
        assert res == expected
