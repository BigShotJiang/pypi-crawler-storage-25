[<img src="https://docs.qblox.com/en/main/_images/qblox_instruments.svg" width="500px" alt="Qblox" />](https://qblox.com)\
[![Documentation](https://img.shields.io/badge/documentation-grey)](https://docs.qblox.com/en/main/)
[![Pipelines](https://gitlab.com/qblox/packages/software/qblox_instruments/badges/main/pipeline.svg)](https://gitlab.com/qblox/packages/software/qblox_instruments/pipelines/)
[![Coverage](https://gitlab.com/qblox/packages/software/qblox_instruments/badges/main/coverage.svg)](https://gitlab.com/qblox/packages/software/qblox_instruments/pipelines/)
[![PyPi](https://img.shields.io/pypi/v/qblox-instruments.svg)](https://pypi.org/pypi/qblox-instruments)
[![License](https://img.shields.io/badge/License-BSD%204--Clause-blue.svg)](https://gitlab.com/qblox/packages/software/qblox_instruments/-/blob/main/LICENSE)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

<br />

## Welcome to Qblox Instruments

The `qblox-instruments` package provides everything you need to interface with Qblox hardware,
including Python drivers, [documentation and tutorials](https://docs.qblox.com/en/main/).\
For a detailed history of changes, please refer to the
[CHANGELOG.md](https://gitlab.com/qblox/packages/software/qblox_instruments/-/blob/main/CHANGELOG.md).

## Compatibility Matrix

| qblox-instruments releases                                                                                                                                                                                                                     | Cluster firmware releases                                                           |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| [>= 1.1.0, \<2.0.0](https://pypi.org/project/qblox-instruments/#history)                                                                                                                                                                       | [>= 0.13.0, \<3.0.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases) |
| [1.0.0](https://pypi.org/project/qblox-instruments/1.0.0/), [1.0.1](https://pypi.org/project/qblox-instruments/1.0.1/), [1.0.2](https://pypi.org/project/qblox-instruments/1.0.2/), [1.0.3](https://pypi.org/project/qblox-instruments/1.0.3/) | [0.13.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.13.0)     |
| [0.17.1](https://pypi.org/project/qblox-instruments/0.17.1/)                                                                                                                                                                                   | [0.12.1](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.12.1)     |
| [0.17.0](https://pypi.org/project/qblox-instruments/0.17.0/)                                                                                                                                                                                   | [0.12.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.12.0)     |
| [0.16.0](https://pypi.org/project/qblox-instruments/0.16.0/)                                                                                                                                                                                   | [0.11.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.11.0)     |
| [0.15.0](https://pypi.org/project/qblox-instruments/0.15.0/)                                                                                                                                                                                   | [0.10.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.10.0)     |
| [0.14.1](https://pypi.org/project/qblox-instruments/0.14.1/)                                                                                                                                                                                   | [0.9.1](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.9.1)       |
| [0.14.0](https://pypi.org/project/qblox-instruments/0.14.0/)                                                                                                                                                                                   | [0.9.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.9.0)       |
| [0.13.0](https://pypi.org/project/qblox-instruments/0.13.0/)                                                                                                                                                                                   | [0.8.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.8.0)       |
| [0.12.0](https://pypi.org/project/qblox-instruments/0.12.0/)                                                                                                                                                                                   | [0.7.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.7.0)       |
| [0.11.2](https://pypi.org/project/qblox-instruments/0.11.2/)                                                                                                                                                                                   | [0.6.2](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.6.2)       |
| [0.11.1](https://pypi.org/project/qblox-instruments/0.11.1/)                                                                                                                                                                                   | [0.6.1](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.6.1)       |
| [0.11.0](https://pypi.org/project/qblox-instruments/0.11.0/)                                                                                                                                                                                   | [0.6.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.6.0)       |
| [0.10.1](https://pypi.org/project/qblox-instruments/0.10.1/)                                                                                                                                                                                   | [0.5.1](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.5.1)       |
| [0.10.0](https://pypi.org/project/qblox-instruments/0.10.0/)                                                                                                                                                                                   | [0.5.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.5.0)       |
| [0.9.0](https://pypi.org/project/qblox-instruments/0.9.0/)                                                                                                                                                                                     | [0.4.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.4.0)       |
| [0.8.2](https://pypi.org/project/qblox-instruments/0.8.2/)                                                                                                                                                                                     | [0.3.1](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.3.1)       |
| [0.8.1](https://pypi.org/project/qblox-instruments/0.8.1/)                                                                                                                                                                                     | [0.3.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.3.0)       |
| [0.8.0](https://pypi.org/project/qblox-instruments/0.8.0/)                                                                                                                                                                                     | [0.3.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.3.0)       |
| [0.7.1](https://pypi.org/project/qblox-instruments/0.7.1/)                                                                                                                                                                                     | [0.2.3](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.2.3)       |
| [0.7.0](https://pypi.org/project/qblox-instruments/0.7.0/)                                                                                                                                                                                     | [0.2.2](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.2.2)       |
| [0.6.1](https://pypi.org/project/qblox-instruments/0.6.1/)                                                                                                                                                                                     | [0.2.1](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.2.1)       |
| [0.6.0](https://pypi.org/project/qblox-instruments/0.6.0/)                                                                                                                                                                                     | [0.2.0](https://gitlab.com/qblox/releases/cluster_releases/-/releases/v0.2.0)       |

______________________________________________________________________

This software is free to use under the terms outlined in the
[LICENSE](https://gitlab.com/qblox/packages/software/qblox_instruments/-/blob/main/LICENSE).\
For further information, please contact us at [support@qblox.com](mailto:support@qblox.com).
