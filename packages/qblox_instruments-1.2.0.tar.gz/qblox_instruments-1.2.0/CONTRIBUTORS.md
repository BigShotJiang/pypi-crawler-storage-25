# Developers and Contributors

We would like to thank the following individuals and teams for their contributions to this project:

### Core Team
* **Qblox team**

### External Contributors
* **Pieter Eendebak**
