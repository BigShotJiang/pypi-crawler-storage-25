# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.1] - 2026-05-17

### Added

- **Config Generator GUI** (`config-gen`): New interactive form for generating vba-edit TOML configuration files without manually editing text
  - Available as a subcommand on all four apps: `excel-vba config-gen`, `word-vba config-gen`, `access-vba config-gen`, `powerpoint-vba config-gen`
  - App-aware form: file picker filters, xlwings toggle (Excel only), UserForms notice (Access)
  - Live TOML preview updates as you fill in the form, with a draggable divider to resize the preview area
  - Open and edit an existing config file directly in the form
  - Save the generated config as a `.toml` file ready to use with `--conf`
  - GUI framework (`ttkbootstrap`) is included in the standard install — no extras required

### Changed

- **App-Specific Icons**: Windows executables and Config Generator windows now use distinct icons for Excel, Word, PowerPoint, and Access
  - The generic `vba-edit` icon remains the fallback for shared/package contexts
  - Makes downloaded `.exe` files easier to distinguish in File Explorer, the taskbar, and window lists

### Fixed

- **References Not Saved to Disk**: `references add`, `references import`, and `references remove` now save the document after making changes, so reference updates survive the next time the file is opened ([Issue #99](https://github.com/markuskiller/vba-edit/issues/99))
  - Previously the document was closed with `SaveChanges=False`, silently discarding every reference change

- **UserForm Export Error on Same-Directory Workbooks**: Fixed `[WinError 32]` crash when exporting from a workbook located in the same folder as the VBA output directory ([Issue #93](https://github.com/markuskiller/vba-edit/issues/93), related: [#83](https://github.com/markuskiller/vba-edit/issues/83))
  - The v0.4.4 fix only covered the import path; export had the same problem when `vba-dir` equals the workbook directory
  - Export now detects when source and target `.frx` are the same file and skips the redundant copy

## [0.5.0] - 2026-04-05

### Added

- **VBA Reference Manager**: New `references` command to manage VBA library references across all Office apps
  - `references list` — Display all references with name, GUID, version, path, and status
  - `references export` — Save references to a shareable TOML file (default: `{document}_refs.toml`)
  - `references import` — Add references from a TOML file to replicate setups across documents or machines
  - Supports both GUID-based references (installed COM libraries) and file-path references (custom templates, add-ins)
  - Default references without a GUID (like Word's Normal) are automatically excluded from export with a clear note
  - Use `--refs-file / -r` to specify a custom TOML file path
  - Works with all four Office apps: Excel, Word, PowerPoint, and Access
  - Makes reference dependencies trackable in version control alongside VBA code
- **Reference Classification & Filtering**: References are now classified as `default`, `installed`, or `custom` with composable filters
  - `--no-default` — Hide default references (VBA, host app, stdole, Office, Normal)
  - `--no-installed` — Hide installed COM library references (registered on the system)
  - `--no-custom` — Hide custom file-path references (e.g. `.docm`/`.dotm` templates)
  - Category tags displayed next to each reference in `references list` output
  - When filters are active, output shows which filters are applied and how many references are hidden (e.g. "5 of 7 shown, filters: --no-default")
- **Reference Validation**: New `references validate` subcommand to check for broken or missing references
- **Add & Remove References**: New subcommands for direct reference management
  - `references add LIBRARY` — Add a reference by file path (e.g. `.xlam`, `.dotm`, `.dll`)
  - `references remove NAME` — Remove a reference by name
- **Automatic Reference Sync** (`--with-references`): Opt-in flag to include VBA references alongside code during `export`, `import`, and `edit` operations
  - On `export`: saves references to a TOML file alongside your VBA code files
  - On `import`: restores references from the TOML file before importing code
  - On `edit`: watches the TOML file for changes and syncs references back to Office on save
  - TOML file includes metadata (version, timestamp, source document, active filters) for traceability
- **Reference Sync Mode** (`--sync` on `references import`): Make a document's references match a TOML file exactly — adds missing references and removes extras
  - Default references (VBA, host app, stdole) are protected and never removed unless `--force-overwrite` is also specified
  - Refuses to sync from a filtered TOML export unless `--force-overwrite` is used, preventing accidental removal of excluded categories
- **Skip Empty Modules** (`--skip-empty`): New flag for `export` and `import` commands to skip modules with no code ([Issue #63](https://github.com/markuskiller/vba-edit/issues/63))
  - Particularly useful for Excel workbooks where every worksheet creates a module — even empty ones
  - On `export`: modules with no code (e.g. `Sheet2`, `Sheet3`) are not written to files
  - On `import`: files that contain only a module header and no actual code are skipped
  - Has no effect on `edit` mode
- **Configuration File Support for References**: Reference filter options (`--refs-file`, `--no-default`, `--no-installed`, `--no-custom`) can now be set in configuration files using a new `[references]` section
- **Extended Configuration Keys**: Added `skip_empty`, `force_overwrite`, `save_metadata`, `detect_encoding`, and `with_references` to the `[general]` section of configuration files

### Changed

- **Development Status**: Project classifier updated from Alpha to Beta on PyPI, reflecting growing stability and adoption
- **Robust Config Merging**: Command-line arguments now reliably override configuration file settings for all option types, including boolean flags like `--verbose` and `--rubberduck-folders`

### Removed

- **Legacy Configuration Placeholders**: Removed deprecated placeholders `{general.file.name}`, `{general.file.fullname}`, `{general.file.path}`, and `{vbaproject}` — use `{file.name}`, `{file.fullname}`, `{file.path}`, and `{file.vbaproject}` instead (deprecated since v0.4.1)

### Fixed

- **Encoding Detection**: ASCII-only VBA files are no longer misidentified as UTF-8
  - Files containing only ASCII characters (the majority of English-language VBA code) now correctly report the Windows system code page (e.g. `cp1252`) rather than `utf-8`
  - Prevents potential encoding mismatches when files are shared or re-imported

### Security

- **Trusted Publishers**: PyPI and TestPyPI uploads use OpenID Connect (OIDC) authentication
- **PEP 740 Attestations**: Every published package includes cryptographically signed provenance, proving it was built by the official GitHub Actions workflow
- **Supply Chain Hardening**: Added `pip-audit` security scan to the publish pipeline and `--no-upx` to binary builds to reduce antivirus false positives

## [0.4.4] - 2026-03-13

### Added

- **`uvx` Support via Satellite Entry-Point Packages**: All four tools are now available on PyPI as standalone packages — `excel-vba`, `word-vba`, `powerpoint-vba`, `access-vba`
  - Run any tool instantly without installing: `uvx excel-vba edit`, `uvx word-vba edit`, etc.
  - Each package automatically pulls in the `vba-edit` core — no separate install step needed
  - Ideal for one-off use, scripts, and CI/CD pipelines
- **VS Code Settings Guidance**: Added recommended VS Code configuration to README
  - Correct encoding (`windows1252`) and file-type associations for `.bas`, `.cls`, `.frm` files

### Fixed

- **UserForm Import Error on Same-Directory Workbooks**: Fixed `[WinError 32]` crash when importing from a workbook located in the same folder as the executable (or when `vba-dir` equals the workbook directory) ([Issue #83](https://github.com/markuskiller/vba-edit/issues/83))
  - Excel locks `.frx` binary files while open; the tool now detects when source and target are the same file and skips the redundant copy
  - Thanks to [@erikvanhimbergen](https://github.com/erikvanhimbergen) for the report and fix ([PR #84](https://github.com/markuskiller/vba-edit/pull/84))

## [0.4.3] - 2026-03-07

### Changed

- **Python 3.9 Support Dropped**: Python 3.9 reached end-of-life in October 2025 and is no longer supported
  - Minimum supported version is now Python 3.10
- **Improved CLI Consistency**: All four Office tools (Excel, Word, PowerPoint, Access) now share a unified command-line handling layer
  - Commands, options, and their behaviour are more consistent across tools
  - Improves code maintainability and simplifies future cli feature enhancements
  - Many thanks to [@onderhold](https://github.com/onderhold)

### Fixed

- **Configuration File Precedence**: Config file values are no longer silently ignored when CLI arguments have defaults ([Issue #61](https://github.com/markuskiller/vba-edit/issues/61))
  - Settings in a config file (e.g. `in-file-headers = true`) now take effect as expected when not overridden on the command line
  - Explicitly passing a conflicting flag on the command line still correctly takes precedence over the config file

### Security

- **Dependency Update**: Updated `filelock` to resolve a known vulnerability ([GHSA-w853-jp5j-5j7f](https://github.com/advisories/GHSA-w853-jp5j-5j7f))

## [0.4.2] - 2025-11-27

### Fixed

- **Rich Markup Error**: Fixed crash when processing file paths containing brackets ([Issue #43](https://github.com/markuskiller/vba-edit/issues/43), [Issue #46](https://github.com/markuskiller/vba-edit/issues/46))
  - Application no longer crashes with Rich markup errors during file operations
  - Excel binary workbook format (.xlsb) now works correctly ([Issue #46](https://github.com/markuskiller/vba-edit/issues/46) specific case)
  - All macro-enabled formats (.xlsm, .xlsb, .xls) function properly
  - Thanks to [@DjunaPix](https://github.com/DjunaPix) for reporting [Issue #46](https://github.com/markuskiller/vba-edit/issues/46)
- **Import Messages**: Reduced duplicate "Document has been saved" messages
  - Now displays once instead of three times during import operations
  - Makes import output cleaner and less confusing

## [0.4.1] - 2025-10-17

### Added

- **Support for Python 3.14**: Full compatibility with the latest Python release ([Issue #23](https://github.com/markuskiller/vba-edit/issues/23))
- **Windows Binaries**: Pre-built executables for instant use without Python
  - Four separate tools: `excel-vba.exe`, `word-vba.exe`, `access-vba.exe`, `powerpoint-vba.exe`
  - SHA256 checksums and GitHub Attestations for security verification
  - Software Bill of Materials (SBOM) included with each release
  - See **[Issue #24](https://github.com/markuskiller/vba-edit/issues/24)** about expected antivirus warnings for unsigned binaries
- **Colorized Terminal Output**: Professional CLI appearance with uv/ruff-style colors
  - Success messages in green with checkmarks (✓)
  - Error messages in red with X marks (✗)
  - Warning messages in yellow with warning symbols (⚠)
  - Syntax highlighting in help text for better readability
  - Technical terms (TOML, JSON, VBA) highlighted in cyan
  - Example commands shown in dim gray for easy scanning
  - Automatically disabled when piped or redirected
  - Use `--no-color` flag to disable manually
  - Works reasonably well for `--help` texts but is still experimental for console logging output (`RichFormatter` presets interfere with custom color pattern)
- **Automatic Header Detection**: Import command now works without manual header flags
  - Automatically detects VBA headers in code files (VERSION/BEGIN/Attribute lines)
  - Falls back to separate `.header` files when needed
  - Creates minimal headers automatically if neither format exists
  - Warns about conflicting configurations when both formats present
- **Improved Help Display**: Redesigned help output for better usability
  - Options organized into clear groups (File Options, Configuration, Encoding, etc.)
  - Design by [@onderhold](https://github.com/onderhold)
  - Main help shows concise overview with practical examples
  - Command-specific help displays only relevant options
- **UserForm Protection**: Automatic safeguards prevent accidental corruption of UserForm binary files
  - Exported `.frx` files are marked read-only to prevent accidental modification
  - Clear warnings displayed when UserForms are exported
  - Edit mode ignores `.frx` files during file watching
  - Seamless re-export workflow when forms are modified in Office VBA editor
  - Prevents permanent UserForm deletion caused by corrupted binary files
- **Security Documentation**: Comprehensive guides for secure usage
  - Binary verification instructions with multiple methods
  - Vulnerability reporting process documented
  - Best practices for secure usage included

### Changed

- **Export Behavior**: Documents now close automatically after export completes
  - Prevents accumulation of open Office windows during batch operations
  - Use `--keep-open` flag to keep document open for VBA editor inspection
  - Only affects `export` command (edit/import commands keep documents open as before)
  - Makes export workflow cleaner and more CI/CD friendly
- **Metadata Saving**: `-m/--save-metadata` option now available in both `edit` and `export` commands
  - Previously only available in `edit` mode
  - Makes workflows more consistent across commands
- **Configuration Placeholders**: Simplified placeholder names for config files
  - Use `{file.name}`, `{file.fullname}`, `{file.path}` instead of `{general.file.*}`
  - Use `{file.vbaproject}` instead of `{vbaproject}`
  - Old placeholders still work (will be removed in v0.5.0)
- **Option Visibility**: Options now only appear on commands where they're actually used
  - Folder options (`--rubberduck-folders`, `--open-folder`) only show on relevant commands
  - `--open-folder` now works with `edit`, `import`, and `export` commands
  - Reduces clutter and confusion in help output

### Fixed

- **[Issue #20](https://github.com/markuskiller/vba-edit/issues/20)**: Fixed crash when running `check` command
  - All entry points now handle `check` command correctly
- **[Issue #21](https://github.com/markuskiller/vba-edit/issues/21)**: Commands no longer show irrelevant options
  - Each command displays only options that work with it
- **CI/CD Reliability**: Improved test stability on GitHub Actions
  - Added subprocess timeouts to prevent intermittent hangs
  - Increased test timeouts for slower CI runners

### Security

- **Automated Dependency Updates**: Dependabot monitors for security issues
  - Weekly checks for outdated dependencies
  - Automatic pull requests for security updates
- **GitHub Actions Security**: Workflows use minimal required permissions
  - Follows principle of least privilege
  - Reduces risk if workflow is compromised
- **Binary Verification**: Multiple methods to verify download authenticity
  - SHA256 checksums included with releases
  - GitHub Attestations prove binaries built by official workflow
  - SBOM documents all included dependencies
- **Vulnerability Reporting**: Clear process for security issues
  - Response within 48 hours
  - Private disclosure via GitHub Security Advisories
  - Documented timeline for fixes

## [0.4.0] - 2025-10-06

### Added
- new option `--in-file-headers`: embedding VBA headers in code files ([@onderhold](https://github.com/onderhold))
- new option `--rubberduck-folders`: support for RubberduckVBA-style `@Folder` annotations and folder organization ([Issue #9](https://github.com/markuskiller/vba-edit/issues/9)) ([@onderhold](https://github.com/onderhold))
- new option `--conf`: support for config files  ([@onderhold](https://github.com/onderhold))
- new option `--force-overwrite`: skip safety prompts for automated exports (CI/CD friendly)
- Automatic warnings before overwriting existing VBA files
- Detection and warning when header storage mode changes between exports
- Automatic cleanup of orphaned `.header` files when switching modes
- Enhanced UserForm validation - prevents export without proper header handling (`--in-file-headers` or `--save-headers`)
- Better support for VBA class modules with custom attributes ([@onderhold](https://github.com/onderhold))
- Enhanced `VB_PredeclaredId` handling for class modules ([@onderhold](https://github.com/onderhold))
- Support for macro-enabled MS PowerPoint documents
- `check all` subcommand for cli entry points, which processes all suported MS Office apps in a single call (replaces calling `python -m vba_edit.utils`)
- Option to show program's version number and exit added to all cli interfaces (`--version`)
- Metadata tracking: exports now save `header_mode` to detect configuration changes between runs
- **Build**: Added version file generation support to `create_binaries.py` for Windows executables

### Changed
- Improved version control compatibility with embedded headers ([@onderhold](https://github.com/onderhold))
- Streamlined project setup by extending pyproject.toml and .gitignore, while reducing requirements.txt to the bare minimum that VS Code needs. Thus setup.cfg became superfluous. ([@onderhold](https://github.com/onderhold))
- Some refactoring: handling common cli options now in separate module cli_common.py ([@onderhold](https://github.com/onderhold))
- Refactored warning handling logic into centralized helper function (`handle_export_with_warnings()` in `cli_common.py`)
- Core logic (`office_vba.py`) now raises `VBAExportWarning` exceptions instead of handling user interaction
- CLI layer handles all user prompts via shared helper, eliminating code duplication across entry points
- **[Issue #14](https://github.com/markuskiller/vba-edit/issues/14)**: The watchgod library is no longer actively developed and has been superseded by watchfiles. The dependency has been replaced with watchfiles ([@onderhold](https://github.com/onderhold))

### Fixed
- **[Issue #16](https://github.com/markuskiller/vba-edit/issues/16)**: Hidden member attributes (VB_VarHelpID, VB_VarDescription, VB_UserMemId) no longer appear in VBA editor after import. These attributes are legal in exported VBA files but cause syntax errors when written directly into modules. Solution: filter all member-level Attribute lines from code sections before calling AddFromString(). (Reported by [@takutta](https://github.com/takutta), [@loehnertj](https://github.com/loehnertj))
- **[Issue #11](https://github.com/markuskiller/vba-edit/issues/11)**: Verified `--in-file-headers` feature works correctly for LSP tool compatibility (VBA Pro extension support)
- **UserForm parsing**: Fixed case-sensitive BEGIN block matching - now handles both "BEGIN" (class modules) and "Begin {GUID} FormName" (UserForms) correctly
- fix check for form safety on `export` (if edit command is run without `--save-headers` option, forms cannot be processed correctly -> check for forms and abort if `--save-headers` is not enabled)
- fix header file handling (`--save-headers`) in already populated `--vba-directory` (only 1 header file was created rather than one per *.cls, *.bas or *.frm file) - calling it on empty `--vba-directory` worked as expected
- `--in-file-headers` validation now correctly allows UserForm exports (was incorrectly rejected even when flag was set)
- Boolean logic error in `_check_form_safety()` that caused false rejections

### Data loss prevention
- Export operations now require explicit user confirmation when:
  - Overwriting existing VBA files (prevents accidental data loss)
  - Changing header storage modes (prevents configuration drift and orphaned files)
- Confirmation prompts can be bypassed with `--force-overwrite` flag for automation or for backward compatibility scenarios with `vba-edit<0.4.0` or `xlwings vba edit`

## [0.3.0] - 2025-01-19

### Added

- new command ``check``: e.g. ``word-vba check`` detects if 'Trust Access to Word VBA project object model' is enabled (available for all entry points)
- ACCESS: basic support for MS Access databases (standard modules ``*.bas`` and class modules ``*.cls`` are supported)
- ``--save-headers`` command-line option, supporting a comprehensive handling of headers ([Issue #11](https://github.com/markuskiller/vba-edit/issues/11))
- new files created in ``--vba-directory`` are now automatically synced back to MS Office VBA editor in ``*-vba edit`` mode (previously, only file deletions were monitored and synced)
- better tests for utils.py and office_vba.py

### Fixed

- Bug Fix for [Issue #10](https://github.com/markuskiller/vba-edit/issues/10): Different VBA types are now properly recognised and minimal header sections generated before importing code back into the MS Office VBA editor ensures correct placement of 'Document modules' and 'Class modules' which are all exported as ``.cls`` files. (thanks to [@takutta](https://github.com/takutta) for testing and reporting)
- In previous versions ``.frm`` were exported and code could be edited, however, when imported back to MS Office VBA editor, forms were not processed correctly due to a lack of header handling

## [0.2.1] - 2024-12-09

### Fixed

- WORD: fixed removing of headers before saving exported file to disk and making sure that there is no attempt at removing headers when changed file is reimported`
- While ``excel-vba`` edit does not overwrite files in ``edit`` mode (>=v0.2.0), ``word-vba edit`` still did. That's fixed now.
- WORD & EXCEL: when files are deleted from ``--vba-directory`` in ``edit`` mode those files are now also deleted in VBA editor of the respective office application (which aligns with ``xlwings vba edit`` implementation)
- improved credit to original ``xlwings`` project by adding an inline comment closer to OfficeVBAHandler, which contains the core VBA interaction logic that was inspired by ``xlwings``

## [0.2.0] - 2024-12-08

### Added

- basic tests for entry points ``word-vba`` & ``excel-vba``
- introducing binary distribution cli tools on Windows
- ``excel-vba`` no longer relies on xlwings being installed
- ``xlwings`` is now an optional import
- ``--xlwings|-x`` command-line option to be able to use ``xlwings`` if installed

### Fixed

- on ``*-vba edit`` files are no longer overwritten if ``vba-directory`` is
  already populated (trying to achieve similar behaviour compared to ``xlwings``;
  TODO: files which are deleted from  ``vba-directory`` are not
  automatically deleted in Office VBA editor just yet.)

## [0.1.2] - 2024-12-05

### Added

- Initial release (``word-vba edit|export|import`` & ``excel-vba edit|export|import``: wrapper for ``xlwings vba edit|export|import``)
- Providing semantically consistent entry points for future integration of other MS Office applications (e.g. ``access-vba``, ``powerpoint-vba``, ...)
- (0.1.1) -> (0.1.2) Fix badges and 1 dependency (``chardet``)
