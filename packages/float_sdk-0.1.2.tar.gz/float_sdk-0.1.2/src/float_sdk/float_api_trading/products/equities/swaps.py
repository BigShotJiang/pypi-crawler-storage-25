#!/usr/bin/env python
# pyright: basic

"""
Equity Swap Specifications

Includes both composable equity swaps (EqSwapFixed, EqSwapFloat) and
flat variance/volatility swap models aligned with market termsheets.
"""

from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.base import AssetId
from float_sdk.float_api.assets.equities.baskets import EqBasketModel
from float_sdk.float_api.assets.equities.equities import EquityModel, IndexModel
from float_sdk.float_api.base.references import EquityId, IndexId
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.equities.payouts import EquityPerformancePayoutModel
from float_sdk.float_api_trading.products.rates.cashflows import FixedRateCashflowSeriesModel, FloatingRateCashflowSeriesModel
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel
from float_sdk.float_api_trading.products.volatility.swaps import VarianceVolatilitySwapBaseModel
from float_sdk.float_api_trading.products.volatility.terms import (
    CorrelationReturnTermsModel,
    VarianceReturnTermsModel,
    VolatilityReturnTermsModel,
)
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class DividendReinvestment(Enum):
    APPLICABLE = "APPLICABLE"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class DividendEntitlement(Enum):
    """
    The enumerated values to specify the date on which the receiver of the equity payout is entitled to the dividend.

    Attributes
    ----------
    EX_DATE : Dividend entitlement is on the dividend ex-date.
    RECORD_DATE : Dividend entitlement is on the dividend record date.

    """

    EX_DATE = "EX_DATE"
    RECORD_DATE = "RECORD_DATE"


class DividendPeriodEnum(Enum):
    """
    2002 ISDA Equity Derivatives Definitions: First Period, Second Period

    Attributes
    ----------
    FIRST_PERIOD : 2002 ISDA Equity Derivatives Definitions: First Period means each period from, and including, one Cash Settlement Payment Date or Settlement Date, as the case may be, to, but excluding, the next following Cash Settlement Payment Date or Settlement Date, as the case may be, except that (i) the initial Dividend Period will commence on, and include, the Clearance System Business Day that is one Settlement Cycle following the Trade Date and (ii) the final Dividend Period will end on, but exclude, the final Cash Settlement Payment Date or Settlement Date, as the case may be.
    SECOND_PERIOD : 2002 ISDA Equity Derivatives Definitions: Second Period means each period from, but excluding, one Valuation Date to, and including, the next Valuation Date, except that (i) the initial Dividend Period will commence on, but exclude, the Trade Date and (ii) the final Dividend Period will end on, and include, the final Valuation Date or, in respect of a Physically-settled Forward Transaction to which Variable Obligation is not applicable, the date that is one Settlement Cycle prior to the Settlement Date.
    """

    FIRST_PERIOD = "FIRST_PERIOD"
    SECOND_PERIOD = "SECOND_PERIOD"


# Deprecated: EqVolatilitySwapModel removed - use EqVolatilitySwap instead
# The old EQ_VOL_SWAP ProductType has been consolidated into EQ_VOLATILITY_SWAP


# New composable equity swap models aligned with ISDA CDM


class EqSwapFixedModel(ContractualProductModel):
    """
    Equity Swap with Fixed Rate Leg - Composable Structure

    Modern equity swap model using composable payouts.
    Combines an equity performance payout with a fixed rate cashflow series.

    Attributes
    ----------
    equity_amounts : EquityPerformancePayoutModel
        The equity performance payout leg specifying equity return calculation
    fixed_amounts : FixedRateCashflowSeriesModel
        The fixed rate payout leg specifying fixed interest payments
    """

    product_type: ProductType = Field(
        ProductType.EQ_SWAP_FIXED, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    equity_amounts: EquityPerformancePayoutModel | None = Field(  # noqa: F821
        default=None,
        title="Equity Amounts",
        description="Equity performance payout leg specifying underlier, return type, valuation, and payment terms",
    )

    fixed_amounts: FixedRateCashflowSeriesModel | None = Field(  # noqa: F821
        default=None, title="Fixed Amounts", description="Fixed rate payout leg specifying fixed rate, notional, and payment schedule"
    )

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms including settlement currency and payment date",
    )

    semantic_type: Literal["EQ_SWAP_FIXED"] = Field(default="EQ_SWAP_FIXED", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Swap (Fixed)",
            "description": "Equity swap using composable payout structure aligned with ISDA CDM. One party pays equity performance return while the other pays fixed interest rate. The equity leg uses EquityPerformancePayout for flexible specification of underlier, return type (price/total), dividend treatment, valuation schedule, and FX features (quanto/composite). The fixed leg uses FixedRateCashflowSeries for fixed rate payments.",
            "example": {
                "equityAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "asset": "RTY Index",
                    "numberOfUnits": 100.0,
                    "returnTerms": {
                        "returnType": "TOTAL_RETURN",
                        "dividendReturnTerms": {
                            "dividendPayoutRatio": 1.0,
                            "dividendReinvestment": False,
                            "dividendEntitlement": "EX_DATE",
                            "semanticType": "DIVIDEND_RETURN_TERMS",
                        },
                        "semanticType": "RETURN_TERMS",
                    },
                    "valuation": {
                        "valuationPriceInitial": 4500.0,
                        "semanticType": "EQUITY_VALUATION",
                    },
                    "calculationPeriodDates": {
                        "effectiveDate": "2025-01-15",
                        "terminationDate": "2026-01-15",
                        "frequency": {"period": "M", "multiplier": 3},
                        "businessDayConvention": "FOLLOWING",
                        "businessDays": "USNY",
                        "semanticType": "CALCULATION_DATE_SCHEDULE",
                    },
                    "paymentDates": {
                        "payRelativeTo": "CALCULATION_PERIOD_END_DATE",
                        "paymentDaysOffset": 2,
                        "paymentFrequency": "QUARTERLY",
                        "semanticType": "PAYMENT_DATES",
                    },
                    "semanticType": "EQUITY_PERFORMANCE_PAYOUT",
                },
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalAmount": 1000000.0,
                    "notionalCurrency": "USD",
                    "fixedRate": {"rate": 0.035, "semanticType": "FIXED_RATE"},
                    "calculationPeriodDates": {
                        "effectiveDate": "2025-01-15",
                        "terminationDate": "2026-01-15",
                        "frequency": {"period": "M", "multiplier": 3},
                        "semanticType": "CALCULATION_DATE_SCHEDULE",
                    },
                    "dayCountConvention": "30/360",
                    "semanticType": "IR_FIXED_CASHFLOW_SERIES",
                    "productType": "IR_FIXED_CASHFLOW",
                },
                "effectiveDate": "2025-01-15",
                "terminationDate": "2026-01-15",
                "semanticType": "EQ_SWAP_FIXED",
            },
        }


class EqSwapFloatModel(ContractualProductModel):
    """
    Equity Swap with Floating Rate Leg - Composable Structure

    Modern equity swap model using composable payouts.
    Combines an equity performance payout with a floating rate cashflow series.

    Attributes
    ----------
    equity_amounts : EquityPerformancePayoutModel
        The equity performance payout leg specifying equity return calculation
    floating_amounts : FloatingRateCashflowSeriesModel
        The floating rate payout leg specifying floating rate index and spread
    """

    product_type: ProductType = Field(
        ProductType.EQ_SWAP_FLOAT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    equity_amounts: "EquityPerformancePayoutModel | None" = Field(  # noqa: F821
        default=None,
        title="Equity Amounts",
        description="Equity performance payout leg specifying underlier, return type, valuation, and payment terms",
    )

    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating rate payout leg specifying floating rate index, spread, reset dates, and payment schedule",
    )

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms including settlement currency and payment date",
    )

    semantic_type: Literal["EQ_SWAP_FLOAT"] = Field(default="EQ_SWAP_FLOAT", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Swap (Floating)",
            "description": "Equity swap using composable payout structure aligned with ISDA CDM. One party pays equity performance return while the other pays floating interest rate. The equity leg uses EquityPerformancePayout for flexible specification of underlier, return type (price/total), dividend treatment, valuation schedule, and FX features (quanto/composite). The floating leg uses FloatingRateCashflowSeries for floating rate payments based on an index (e.g., SOFR) plus spread.",
            "example": {
                "equityAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "asset": "RTY Index",
                    "numberOfUnits": 100.0,
                    "returnTerms": {
                        "returnType": "TOTAL_RETURN",
                        "dividendReturnTerms": {
                            "dividendPayoutRatio": 1.0,
                            "dividendReinvestment": False,
                            "dividendEntitlement": "EX_DATE",
                            "semanticType": "DIVIDEND_RETURN_TERMS",
                        },
                        "semanticType": "RETURN_TERMS",
                    },
                    "valuation": {
                        "valuationPriceInitial": 4500.0,
                        "semanticType": "EQUITY_VALUATION",
                    },
                    "calculationPeriodDates": {
                        "effectiveDate": "2025-01-15",
                        "terminationDate": "2026-01-15",
                        "frequency": {"period": "M", "multiplier": 3},
                        "businessDayConvention": "FOLLOWING",
                        "businessDays": "USNY",
                        "semanticType": "CALCULATION_DATE_SCHEDULE",
                    },
                    "paymentDates": {
                        "payRelativeTo": "CALCULATION_PERIOD_END_DATE",
                        "paymentDaysOffset": 2,
                        "paymentFrequency": "QUARTERLY",
                        "semanticType": "PAYMENT_DATES",
                    },
                    "semanticType": "EQUITY_PERFORMANCE_PAYOUT",
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalAmount": 1000000.0,
                    "notionalCurrency": "USD",
                    "floatingRate": {
                        "rateOption": "USD-SOFR-COMPOUND",
                        "spread": 0.0025,
                        "semanticType": "FLOATING_RATE",
                    },
                    "calculationPeriodDates": {
                        "effectiveDate": "2025-01-15",
                        "terminationDate": "2026-01-15",
                        "frequency": {"period": "M", "multiplier": 3},
                        "semanticType": "CALCULATION_DATE_SCHEDULE",
                    },
                    "resetDatesSpecification": {
                        "resetRelativeTo": "CALCULATION_PERIOD_START_DATE",
                        "semanticType": "RESET_DATES_SPECIFICATION",
                    },
                    "dayCountConvention": "ACT/360",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                    "productType": "IR_FLOATING_CASHFLOW",
                },
                "effectiveDate": "2025-01-15",
                "terminationDate": "2026-01-15",
                "semanticType": "EQ_SWAP_FLOAT",
            },
        }


class EqVarianceSwapModel(VarianceVolatilitySwapBaseModel):
    """
    Equity Variance Swap - Flat Structure.

    An equity variance swap allows investors to trade the variance (squared volatility) of an equity or index.
    One party pays realized variance, the other pays a fixed variance strike/premium.

    Flat structure aligned with market termsheets - all fields at product level instead of
    nested payout abstractions. Variance swaps are single-leg products, not composable.

    Key Fields
    ----------
    asset : AssetId | str | IndexModel | EquityModel
        Underlying equity or index (e.g., "RTY Index", "TSLA")
    variance_amount : float
        Variance notional amount (primary notional, not vega notional)
    return_terms : VarianceReturnTermsModel
        Variance calculation terms (strike, expected N, caps/floors, etc.)
    """

    product_type: ProductType = Field(
        ProductType.EQ_VARIANCE_SWAP,
        title="Product Type",
        description="Equity Variance Swap",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="Party buying realized variance (receiving variance leg)",
    )

    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="Party selling realized variance (paying variance leg)",
    )

    # Asset and Notional
    asset: EquityId | IndexId | str | IndexModel | EquityModel | None = Field(
        default=None,
        title="Asset",
        description="Underlying equity or index (e.g., 'RTY Index', 'TSLA')",
    )

    variance_amount: float | None = Field(
        default=None,
        title="Variance Amount",
        description="Variance notional amount (primary notional, not vega notional)",
        gt=0,
    )

    # Return Calculation
    return_terms: VarianceReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Variance return terms with strike, expected N, annualization, caps/floors",
    )

    semantic_type: Literal["EQ_VARIANCE_SWAP"] = Field(default="EQ_VARIANCE_SWAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Variance Swap",
            "description": "Equity variance swap with flat structure aligned with market termsheets. Buyer receives realized variance, seller pays fixed variance strike. Payout is quadratic to equity moves.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "RTY Index",
                "varianceAmount": 100000.0,
                "valuationDate": "2025-12-31",
                "valuationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                    "semanticType": "TIME_LOCATION",
                },
                "returnTerms": {
                    "varianceStrikePrice": 0.04,
                    "vegaNotionalAmount": 50000.0,
                    "expectedN": 252,
                    "annualizationFactor": 252,
                    "initialLevel": 4500.0,
                    "initialLevelSource": "CLOSING_PRICE",
                    "varianceCapFloor": {
                        "varianceCap": True,
                        "unadjustedVarianceCap": 2.5,
                        "semanticType": "VARIANCE_CAP_FLOOR",
                    },
                    "semanticType": "VARIANCE_RETURN_TERMS",
                },
                "observationDates": {
                    "effectiveDate": "2025-01-01",
                    "terminationDate": "2025-12-31",
                    "dateRollRule": {"period": "B", "multiplier": 1},
                    "businessDayConvention": "FOLLOWING",
                    "businessDays": "USNY",
                    "semanticType": "CALCULATION_DATES_SCHEDULE",
                },
                "settlementTerms": {
                    "settlementDate": "2026-01-05",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "EQ_VARIANCE_SWAP",
            },
        }


class EqVolatilitySwapModel(VarianceVolatilitySwapBaseModel):
    """
    Equity Volatility Swap - Flat Structure.

    An equity volatility swap allows investors to trade the volatility of an equity or index.
    One party pays realized volatility, the other pays a fixed volatility strike/premium.

    Flat structure aligned with market termsheets - all fields at product level instead of
    nested payout abstractions. Volatility swaps are single-leg products, not composable.
    Payout is linear to realized volatility (not variance).

    Key Fields
    ----------
    asset : AssetId | str | IndexModel | EquityModel
        Underlying equity or index (e.g., "RTY Index", "TSLA")
    vega_notional : float
        Vega notional amount (for vol swaps, notional is in volatility units)
    return_terms : VolatilityReturnTermsModel
        Volatility calculation terms (strike, mean adjustment, expected N, caps/floors, etc.)
    """

    product_type: ProductType = Field(
        ProductType.EQ_VOLATILITY_SWAP,
        title="Product Type",
        description="Equity Volatility Swap",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="Party buying realized volatility (receiving volatility leg)",
    )

    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="Party selling realized volatility (paying volatility leg)",
    )

    # Asset and Notional
    asset: AssetId | str | IndexModel | EquityModel | None = Field(
        default=None,
        title="Asset",
        description="Underlying equity or index (e.g., 'RTY Index', 'TSLA')",
    )

    vega_notional: float | None = Field(
        default=None,
        title="Vega Notional",
        description="Vega notional amount (notional in volatility units for vol swaps)",
        gt=0,
    )

    # Return Calculation
    return_terms: VolatilityReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Volatility return terms with strike, mean adjustment, expected N, annualization, caps/floors",
    )

    semantic_type: Literal["EQ_VOLATILITY_SWAP"] = Field(default="EQ_VOLATILITY_SWAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Volatility Swap",
            "description": "Equity volatility swap with flat structure aligned with market termsheets. Buyer receives realized volatility, seller pays fixed volatility strike. Payout is linear to volatility.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "RTY Index",
                "vegaNotional": 100000.0,
                "valuationDate": "2025-12-31",
                "valuationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                    "semanticType": "TIME_LOCATION",
                },
                "returnTerms": {
                    "volatilityStrikePrice": 0.20,
                    "vegaNotionalAmount": 50000.0,
                    "meanAdjustment": False,
                    "expectedN": 252,
                    "annualizationFactor": 252,
                    "initialLevel": 4500.0,
                    "initialLevelSource": "CLOSING_PRICE",
                    "volatilityCapFloor": {
                        "applicable": True,
                        "volatilityCapFactor": 2.5,
                        "semanticType": "VOLATILITY_CAP_FLOOR",
                    },
                    "semanticType": "VOLATILITY_RETURN_TERMS",
                },
                "observationDates": {
                    "effectiveDate": "2025-01-01",
                    "terminationDate": "2025-12-31",
                    "dateRollRule": {"period": "B", "multiplier": 1},
                    "businessDayConvention": "FOLLOWING",
                    "businessDays": "USNY",
                    "semanticType": "CALCULATION_DATES_SCHEDULE",
                },
                "settlementTerms": {
                    "settlementDate": "2026-01-05",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "EQ_VOLATILITY_SWAP",
            },
        }


class EqCorrelationSwapModel(VarianceVolatilitySwapBaseModel):
    """
    Equity Correlation Swap - Flat Structure.

    An equity correlation swap allows investors to trade the realized correlation between
    a basket of equities/indices vs a fixed correlation strike.
    Payout = Notional × (Realized Correlation - Strike Correlation)

    Flat structure aligned with market termsheets - all fields at product level instead of
    nested payout abstractions. Correlation swaps are single-leg products, not composable.

    Key Fields
    ----------
    asset : EquityBasketModel
        Basket of equities/indices with weights and quantities for correlation calculation
    notional_amount : float
        Correlation notional (sensitivity to 1% correlation change)
    return_terms : CorrelationReturnTermsModel
        Correlation calculation terms (strike, expected N, correlation type, etc.)
    """

    product_type: ProductType = Field(
        ProductType.EQ_CORRELATION_SWAP,
        title="Product Type",
        description="Equity Correlation Swap",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="Party buying realized correlation (receiving correlation leg)",
    )

    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="Party selling realized correlation (paying correlation leg)",
    )

    # Asset (Basket) and Notional
    asset: EqBasketModel | None = Field(
        default=None,
        title="Asset",
        description="Basket of equities/indices for correlation calculation (minimum 2 constituents)",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Correlation notional (sensitivity to 1% correlation change)",
        gt=0,
    )

    # Return Calculation
    return_terms: CorrelationReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Correlation calculation terms with strike, expected N, and correlation type",
    )

    semantic_type: Literal["EQ_CORRELATION_SWAP"] = Field(default="EQ_CORRELATION_SWAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Correlation Swap",
            "description": "Equity correlation swap with flat structure aligned with market termsheets. Buyer receives realized correlation, seller pays fixed correlation strike. Payout is linear to correlation.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "basket": {
                    "constituents": [
                        {
                            "asset": "SPX Index",
                            "initialLevel": 4500.0,
                            "weight": 0.5,
                            "semanticType": "BASKET_CONSTITUENT",
                        },
                        {
                            "asset": "RTY Index",
                            "initialLevel": 2000.0,
                            "weight": 0.5,
                            "semanticType": "BASKET_CONSTITUENT",
                        },
                    ],
                    "weightingScheme": "CUSTOM_WEIGHTED",
                    "semanticType": "BASKET",
                },
                "notionalAmount": 100000.0,
                "valuationDate": "2025-12-31",
                "valuationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                    "semanticType": "TIME_LOCATION",
                },
                "returnTerms": {
                    "correlationStrikePrice": 0.65,
                    "expectedN": 252,
                    "annualizationFactor": 252,
                    "correlationType": "PAIRWISE_AVERAGE",
                    "meanAdjustment": False,
                    "semanticType": "CORRELATION_RETURN_TERMS",
                },
                "observationDates": {
                    "effectiveDate": "2025-01-01",
                    "terminationDate": "2025-12-31",
                    "dateRollRule": {"period": "B", "multiplier": 1},
                    "businessDayConvention": "FOLLOWING",
                    "businessDays": "USNY",
                    "semanticType": "CALCULATION_DATES_SCHEDULE",
                },
                "settlementTerms": {
                    "settlementDate": "2026-01-05",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "EQ_CORRELATION_SWAP",
            },
        }


# Rebuild models to ensure schemas are fully built (Pydantic v2 requirement for inheritance)
EqVarianceSwapModel.model_rebuild()
EqVolatilitySwapModel.model_rebuild()
EqCorrelationSwapModel.model_rebuild()
