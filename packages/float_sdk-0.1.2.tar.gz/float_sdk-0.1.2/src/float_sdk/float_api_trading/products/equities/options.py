#!/usr/bin/env python
# pyright: basic

"""
Equity Option Specifications

"""

from datetime import date, time
from typing import Literal

from pydantic import Field, computed_field
from pydantic.json_schema import SkipJsonSchema

from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.assets.equities.baskets import EqBasketModel
from float_sdk.float_api.assets.equities.equities import EquityModel, IndexModel
from float_sdk.float_api.base.references import EquityId, IndexId
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.contractual import (
    AveragingTermsModel,
    BarrierEventType,
    ContractualProductModel,
    LookbackTermsModel,
    OptionType,
    SingleBarrierModel,
    TriggerTimeType,
    TriggerType,
)
from float_sdk.float_api_trading.products.base.options import BarrierOptionBaseModel, BinaryOptionBaseModel, OptionBaseModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class EqContractualProductBaseModel(ContractualProductModel):
    buyer: CounterpartyRole | None = Field(
        default=None, title="Buyer", description="The party which will pay the premium to the seller on premmium payment date."
    )
    seller: CounterpartyRole | None = Field(
        None, title="Seller", description="The party which will receieve the premium from the buyer on premmium payment date."
    )

    # underlier: IndexId | StockId | None = Field(default=None, title="Underlier", description="The underlying stock or index which is delivered or referenced for cash settlement under the contract terms.")
    # exchange: ExchangeId | None = Field(default=None, title="Exchange", description="The exchange on which the underlier is traded for reference pricing and delivery.")
    # related_exchange: ExchangeId | None = Field(default=None, title="Exchange", description="The exchange on which the underlier is traded for reference pricing and delivery.")

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.EQUITY


class EqForwardModel(EqContractualProductBaseModel):
    product_type: ProductType = Field(
        ProductType.EQ_FORWARD, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.EQ_ONE_DELTA

    expiration_date: date | None = Field(default=None, title="Expiration Date", description="The date on which the contract expires or matures.")
    forward_price: float | None = Field(default=None, title="Forward Price", description="The agreed forward price at which the contract is priced.")
    multiplier: float | None = Field(
        None, title="Multiplier", description="Multiplier to use if the option cash settlement amount is based on a percentage of the underlier performance."
    )
    variable_obligation: bool | None = Field(
        None,
        title="Variable Obligation",
        description="Variable obligation means that the payment or settlement amount is contingent on the performance of an underlying asset, index, or benchmark",
    )

    prepayment: bool | None = Field(default=None, title="Prepayment", description="Is prepayment applicable")
    prepayment_amount: float | None = Field(default=None, title="Prepayment Amount", description="Amount to be prepayed")
    prepayment_date: date | None = Field(default=None, title="Prepayment Date", description="The date on which prepayment should occur.")

    semantic_type: Literal["EQ_FORWARD"] = Field(
        default="EQ_FORWARD", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Forward",
            "description": "An equity forward contract is a customized financial derivative agreement between two parties to buy or sell a specified quantity of an underlying equity asset at a predetermined price on a future date. Unlike standardized futures contracts, equity forwards are over-the-counter (OTC) instruments, allowing for tailored terms such as contract size, expiration date, and settlement conditions. The forward price is calculated based on the spot price of the underlying asset, adjusted for factors such as the risk-free interest rate, dividends, and the time to maturity. At maturity, the contract is typically settled in cash, with the difference between the agreed forward price and the spot price of the equity determining the cash flow to the parties involved. These contracts are commonly used for hedging equity exposure or speculating on future price movements.",
            "example": {
                "name": "EQF SPX 5250.00 15JUL24",
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "SPX Index",
                "forwardPrice": 5250,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementDate": "2024-07-17",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_FORWARD",
                "productFamily": "EQ_ONE_DELTA",
                "semanticType": "EQ_FORWARD",
            },
        }


class EqBarrierForwardModel(EqForwardModel):
    product_type: ProductType = Field(
        ProductType.EQ_BARRIER_FORWARD, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    # knock_in_reference_security: IndexId = Field(default=None, title="", description="")
    # knock_in_determination_days: None = Field(default=None, title="", description="")
    knock_in_valuation_time_type: TriggerTimeType | None = Field(
        None,
        title="Knock In Valuation Ttime Type",
        description="Defines how the knock in barrier is observed, for example on the close or continuous observation.",
    )
    knock_in_valuation_time: time | None = Field(default=None, title="Knock in Valuation Time", description="")

    knock_out_event: TriggerType | None = Field(default=None, title="Knock Out Event", description="Does the option have a knock out feature")
    knock_out_price: float | None = Field(default=None, title="Knock Out Price", description="Price level at which the option knocks out.")
    # knock_out_reference_security: IndexId = Field(default=None, title="", description="")
    # knock_out_determination_days: None = Field(default=None, title="", description="")
    knock_out_valuation_time_type: TriggerTimeType | None = Field(
        None,
        title="Knock Out Valuation Ttime Type",
        description="Defines how the knock out barrier is observed, for example on the close or continuous observation.",
    )
    knock_out_valuation_time: time | None = Field(default=None, title="", description="")

    semantic_type: Literal["EQ_BARRIER_FORWARD"] = Field(
        default="EQ_BARRIER_FORWARD", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Barrier Forward",
            "description": "An equity barrier forward contract is an advanced derivative instrument that combines the features of an equity forward contract with those of a barrier option. This contract stipulates the purchase or sale of a specified quantity of an underlying equity asset at a predetermined forward price on a future date, contingent on the underlying asset's price reaching or not reaching a specific barrier level during the contract's term. The barrier can be either an up-barrier or a down-barrier, triggering the activation or deactivation of the forward contract. If the barrier is breached, the contract's terms may either come into effect (knock-in) or be nullified (knock-out). These contracts are structured over-the-counter (OTC), allowing for customization in terms of notional amount, barrier level, expiration date, and settlement conditions, providing sophisticated strategies for hedging and speculative purposes.",
            "example": {
                "name": "EQKOF SPX 5250.00 KO 5300 15JUL24",
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "underlier": "SPX Index",
                "forwardPrice": 5250,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "terminationDate": "2024-07-15",
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 5300,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2024-07-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "productType": "EQ_BARRIER_FORWARD",
                "productFamily": "EQ_ONE_DELTA",
                "semanticType": "EQ_BARRIER_FORWARD",
            },
        }


class EqOptionBaseModel(OptionBaseModel):
    asset: EquityId | IndexId | str | EquityModel | IndexModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX option"
    )
    number_of_options: float | None = Field(default=None, title="Number of Options", description="Quantity expressed in number of options.")
    multiplier: float | None = Field(
        None, title="Multiplier", description="Multiplier to use if the option cash settlement amount is based on a percentage of the underlier performance."
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.EQUITY

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.EQ_OPTIONS


class EqOptionModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        ProductType.EQ_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["EQ_OPTION"] = Field(
        default="EQ_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Option",
            "description": "An OTC equity option is a bilateral, non-standardized derivative contract in which the buyer obtains the right, but not the obligation, to buy (call) or sell (put) a specified quantity of an underlying equity at a predetermined strike price on or before a defined expiration date. Unlike exchange-traded options, OTC equity options are privately negotiated between counterparties, allowing for customized terms including expiry, strike methodology, settlement type (physical or cash), corporate action adjustments, and volatility surface modeling. These contracts are typically settled via ISDA agreements and may incorporate bespoke risk management features such as defined exercise window, settlement terms, or other features.",
            "example": {
                "name": "EQO SPX CALL 5250.00 15JUL24",
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "SPX Index",
                "numberOfOptions": 100,
                "multiplier": 1,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 5250,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                },
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 125000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2024-07-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "productType": "EQ_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_OPTION",
            },
        }


class EqBasketOptionModel(EqOptionBaseModel):
    """
    Equity Basket Option Model.

    A vanilla option on a basket of equities/indices, allowing investors to trade the performance
    of a weighted basket of stocks or indices with a single strike and expiration.
    """

    product_type: ProductType = Field(
        ProductType.EQ_BASKET_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    asset: EqBasketModel | None = Field(default=None, title="Asset", description="Basket of equities/indices for the basket option (minimum 2 constituents)")

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement based on the basket performance vs strike price"
    )

    semantic_type: Literal["EQ_BASKET_OPTION"] = Field(
        default="EQ_BASKET_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Basket Option",
            "description": "An equity basket option is a derivative that gives the holder the right, but not the obligation, to buy or sell a basket of equities or indices at a predetermined strike price on or before expiration.",
            "example": {
                "name": "EQBO USTECHGIANT CALL 100.00 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": {
                    "name": "Tech Giants Basket",
                    "shortName": "USTECHGIANT",
                    "weightingScheme": "WEIGHT",
                    "constituents": [
                        {"asset": "AAPL US Equity", "weight": 0.3},
                        {"asset": "MSFT US Equity", "weight": 0.3},
                        {"asset": "GOOGL US Equity", "weight": 0.2},
                        {"asset": "AMZN US Equity", "weight": 0.2},
                    ],
                    "semanticType": "EQ_BASKET",
                },
                "numberOfOptions": 1000,
                "multiplier": 1,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 100.0,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "16:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 50000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {"settlementCurrency": "USD", "semanticType": "CASH_SETTLEMENT_TERMS"},
                "productType": "EQ_BASKET_OPTION",
                "productFamily": "EQ_OPTIONS",
            },
        }


class EqBinaryOptionModel(BinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: EquityId | IndexId | str | EquityModel | IndexModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX option"
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    option_type: OptionType | None = Field(default=None, title="Option Type", description="Claim type of the option (e.g. Call, Put, Binary, etc.)")
    strike_price: float | None = Field(default=None, title="Strike Price", description="Price at which the binary payout is triggered.")

    semantic_type: Literal["EQ_BINARY_OPTION"] = Field(
        default="EQ_BINARY_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.EQUITY

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.EQ_OPTIONS

    class Config:
        json_schema_extra = {
            "title": "Equity Binary Option",
            "description": "An equity binary option is a financial derivative that pays out a fixed amount or nothing based on the price of an underlying equity asset reaching or exceeding a predetermined threshold (strike price) at expiration. The terms include the underlying asset (the specific equity), strike price (the price level the underlying must reach), expiration date (the date by which the condition must be met), and payout amount (the fixed amount paid if the condition is satisfied). The binary nature means the outcome is all-or-nothing, with no intermediate payouts.",
            "example": {
                "name": "EQB SPX CALL 5300 15JUL24",
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "SPX Index",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                },
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 125000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 5300,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementDate": "2024-07-17",
                    "settlementCurrency": "USD",
                    "settlementAmount": 1000000,
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_BINARY_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_BINARY_OPTION",
            },
        }


class EqBarrierOptionModel(BarrierOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_BARRIER_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: EquityId | IndexId | str | EquityModel | IndexModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX option"
    )
    number_of_options: float | None = Field(default=None, title="Number of Options", description="Quantity expressed in number of options.")
    multiplier: float | None = Field(
        None, title="Multiplier", description="Multiplier to use if the option cash settlement amount is based on a percentage of the underlier performance."
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.EQUITY

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.EQ_OPTIONS

    semantic_type: Literal["EQ_BARRIER_OPTION"] = Field(
        default="EQ_BARRIER_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Barrier Option",
            "description": "An equity barrier option is a path-dependent derivative where the option's validity or payout is contingent on the underlying asset crossing a predefined price level (barrier) during the option's life. These options can be classified as knock-in (which activate upon breaching the barrier) or knock-out (which become worthless if the barrier is breached). They may also feature additional conditions such as rebates or windowed barriers that apply only within specific timeframes. Barrier options are commonly used in OTC markets due to their customization in strike, barrier levels, expiration, and settlement structures, often priced using stochastic volatility models and Monte Carlo simulations to account for the probability of barrier breaches and associated Greeks behavior.",
            "example": {
                "name": "EQKO SPX CALL 6000.00 15MAR23",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "underlier": "SPX Index",
                "numberOfOptions": 100,
                "multiplier": 1,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 6000,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                },
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 6200,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "productType": "EQ_BARRIER_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_BARRIER_OPTION",
            },
        }


class EqVolatilityKnockoutModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_VOLATILITY_KNOCKOUT, title="Product Type", description="The type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The barrier terms which define the knockin or knockout event.")

    semantic_type: Literal["EQ_VOLATILITY_KNOCKOUT"] = Field(
        default="EQ_VOLATILITY_KNOCKOUT", title="Semantic Type", description="The type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Volatility Knockout",
            "description": "An Equity volatility knockout (or knockin) option is a type of exotic equity option whose activation (knockin) or deactivation "
            "(knockout) depends on the realized volatility of the underlying equity asset. For a volatility knockout option, the contract becomes void if the "
            "volatility of the underlying asset returns crosses a pre-defined threshold during the option's life. In a knockin version, the option is triggered and "
            "becomes active only if the volatility crosses the barrier, allowing the holder to hedge or speculate based on market volatility behavior without "
            "affecting the asset's price directly.",
            "example": {
                "name": "EQVKO SPX CALL 6000.00 KO VOL >= 0.4 15MAR24",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "SPX Index",
                "numberOfOptions": 25000,
                "multiplier": 1,
                "optionType": "CALL",
                "optionPayout": "VANILLA",
                "optionStyle": "EUROPEAN",
                "strikePrice": 6000,
                "effectiveDate": "2023-03-15",
                "expirationDate": "2024-03-15",
                "expirationTime": {
                    "time": "16:00:00",
                    "location": "USNY",
                },
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2023-03-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-03-15",
                        "eventPeriodEndDate": "2024-03-15",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "referenceVolatility": 0.4,
                        "direction": "UP",
                        "semanticType": "VOLATILITY_BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2024-03-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_VOLATILITY_KNOCKOUT",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_VOLATILITY_KNOCKOUT",
            },
        }


class EqLookbackOptionModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_LOOKBACK_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    lookback_terms: LookbackTermsModel | None = Field(
        default=None, title="Lookback Terms", description="The lookback terms defining the strike or settlement behavior."
    )
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement terms. Lookback options are always cash-settled."
    )

    semantic_type: Literal["EQ_LOOKBACK_OPTION"] = Field(
        default="EQ_LOOKBACK_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Lookback Option",
            "description": "An equity lookback option is a path-dependent exotic option where the payoff depends on the maximum or minimum price reached by the underlying equity during the life of the option. In a floating-strike lookback call, the strike is set to the minimum observed price, guaranteeing the holder buys at the lowest point. In a fixed-strike lookback, the settlement price is set to the maximum (call) or minimum (put) observed price. Lookback options eliminate timing risk by allowing the holder to 'look back' over the observation period for the optimal price.",
            "example": {
                "name": "EQLB SPX CALL 6000.00 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "SPX Index",
                "numberOfOptions": 100,
                "multiplier": 1,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 6000,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "16:00:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "lookbackTerms": {
                    "lookbackType": "FLOATING_STRIKE",
                    "initialPrice": 6000,
                    "strikePercentage": 1.0,
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-01-15",
                        "eventPeriodEndDate": "2025-01-15",
                        "eventTimeType": "CLOSING",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "LOOKBACK_TERMS",
                },
                "premiumTerms": {
                    "premium": 500000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2025-01-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_LOOKBACK_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_LOOKBACK_OPTION",
            },
        }


class EqAsianOptionModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_ASIAN_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    averaging_terms: AveragingTermsModel | None = Field(
        default=None, title="Averaging Terms", description="The averaging terms defining the calculation method and observation schedule."
    )
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement terms. Asian options are always cash-settled."
    )

    semantic_type: Literal["EQ_ASIAN_OPTION"] = Field(
        default="EQ_ASIAN_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Asian Option",
            "description": "An equity Asian option is a path-dependent exotic option where the payoff depends on the average price of the underlying equity over a specified observation period rather than the spot price at expiration. Average-rate (averaging-out) options use the average as the settlement price against a fixed strike. Average-strike (averaging-in) options use the average as the effective strike against the spot at expiry. Asian options reduce the impact of price manipulation and short-term volatility, making them popular for hedging exposures tied to periodic pricing.",
            "example": {
                "name": "EQAS SPX CALL 6000.00 OUT 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "SPX Index",
                "numberOfOptions": 100,
                "multiplier": 1,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 6000,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "16:00:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "averagingTerms": {
                    "averagingInOut": "OUT",
                    "calculationMethod": "ARITHMETIC",
                    "initialPrice": 6000,
                    "strikeFactor": 1.0,
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-01-15",
                        "eventPeriodEndDate": "2025-01-15",
                        "eventTimeType": "CLOSING",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "AVERAGING_TERMS",
                },
                "premiumTerms": {
                    "premium": 400000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2025-01-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_ASIAN_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_ASIAN_OPTION",
            },
        }


class PerformanceLegModel(DataModel):
    asset: EquityId | IndexId | str | EquityModel | IndexModel | None = Field(
        default=None, title="Asset", description="The underlying equity or index for this performance leg."
    )
    initial_price: float | None = Field(
        default=None,
        title="Initial Price",
        description="The reference price at trade inception used as the baseline for return calculation. Aligns with FpML returnLeg/rateOfReturn/initialPrice and CDM PortfolioReturnTerms.initialValuationPrice.",
    )

    semantic_type: Literal["PERFORMANCE_LEG"] = Field(default="PERFORMANCE_LEG", title="Semantic Type")


class EqOutperformanceOptionModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_OUTPERFORMANCE_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    # Not applicable — outperformance options are notional-based (notional_amount / notional_currency)
    number_of_options: SkipJsonSchema[float | None] = Field(default=None, exclude=True)
    multiplier: SkipJsonSchema[float | None] = Field(default=None, exclude=True)
    asset: PerformanceLegModel | None = Field(default=None, title="Asset", description="The outperforming asset leg with initial price reference.")
    benchmark: PerformanceLegModel | None = Field(default=None, title="Benchmark", description="The benchmark asset leg with initial price reference.")
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement terms. Outperformance options are always cash-settled."
    )

    semantic_type: Literal["EQ_OUTPERFORMANCE_OPTION"] = Field(
        default="EQ_OUTPERFORMANCE_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Outperformance Option",
            "description": "A spread option where the payoff depends on the relative performance between two equity underlyings. The holder profits if the first asset (outperformer) returns more than the second asset (benchmark) by more than the strike spread. Payoff at expiry is max(Return(Asset) - Return(Benchmark) - Strike, 0) x Notional. European exercise and cash settlement. Each performance leg carries its own initial price reference for return calculation, aligned with ISDA CDM PortfolioReturnTerms and FpML returnLeg structures.",
            "example": {
                "name": "EQOP SPX/NDX CALL 0.00 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": {
                    "asset": "SPX Index",
                    "initialPrice": 6000,
                    "semanticType": "PERFORMANCE_LEG",
                },
                "benchmark": {
                    "asset": "NDX Index",
                    "initialPrice": 18000,
                    "semanticType": "PERFORMANCE_LEG",
                },
                "notionalAmount": 10000000,
                "notionalCurrency": "USD",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 0.0,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "16:00:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 300000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2025-01-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_OUTPERFORMANCE_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_OUTPERFORMANCE_OPTION",
            },
        }


class EqBarrierOutperformanceOptionModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_BARRIER_OUTPERFORMANCE_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    # Not applicable — outperformance options are notional-based (notional_amount / notional_currency)
    number_of_options: SkipJsonSchema[float | None] = Field(default=None, exclude=True)
    multiplier: SkipJsonSchema[float | None] = Field(default=None, exclude=True)
    asset: PerformanceLegModel | None = Field(default=None, title="Asset", description="The outperforming asset leg with initial price reference.")
    benchmark: PerformanceLegModel | None = Field(default=None, title="Benchmark", description="The benchmark asset leg with initial price reference.")
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The barrier terms which define the knockin or knockout event.")
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement terms. Barrier outperformance options are always cash-settled."
    )

    semantic_type: Literal["EQ_BARRIER_OUTPERFORMANCE_OPTION"] = Field(
        default="EQ_BARRIER_OUTPERFORMANCE_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Barrier Outperformance Option",
            "description": "A spread option where the payoff depends on the relative performance between two equity underlyings, combined with a barrier feature that activates (knock-in) or deactivates (knock-out) the option if a specified level is breached. Payoff at expiry is max(Return(Asset) - Return(Benchmark) - Strike, 0) x Notional, contingent on the barrier condition. Each performance leg carries its own initial price reference for return calculation. European exercise and cash settlement.",
            "example": {
                "name": "EQBOP SPX/NDX CALL 0.00 KO 6500 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": {
                    "asset": "SPX Index",
                    "initialPrice": 6000,
                    "semanticType": "PERFORMANCE_LEG",
                },
                "benchmark": {
                    "asset": "NDX Index",
                    "initialPrice": 18000,
                    "semanticType": "PERFORMANCE_LEG",
                },
                "notionalAmount": 10000000,
                "notionalCurrency": "USD",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 0.0,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "16:00:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.2,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-01-15",
                        "eventPeriodEndDate": "2025-01-15",
                        "eventTimeType": "CLOSING",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 250000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2025-01-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_BARRIER_OUTPERFORMANCE_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_BARRIER_OUTPERFORMANCE_OPTION",
            },
        }


class EqBarrierLookbackOptionModel(EqOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.EQ_BARRIER_LOOKBACK_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    lookback_terms: LookbackTermsModel | None = Field(
        default=None, title="Lookback Terms", description="The lookback terms defining the strike or settlement behavior."
    )
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The barrier terms which define the knockin or knockout event.")
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement terms. Barrier lookback options are always cash-settled."
    )

    semantic_type: Literal["EQ_BARRIER_LOOKBACK_OPTION"] = Field(
        default="EQ_BARRIER_LOOKBACK_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Equity Barrier Lookback Option",
            "description": "An equity barrier lookback option combines a path-dependent lookback payoff with a barrier feature. The lookback determines the strike or settlement price from the extreme (min/max) price observed during the option's life, while the barrier activates (knock-in) or deactivates (knock-out) the option if the underlying crosses a specified level. The barrier cheapens the premium versus a pure lookback by limiting the seller's exposure. The barrier and lookback observation periods can differ, allowing structures where the barrier is monitored continuously while the lookback window covers a specific sub-period.",
            "example": {
                "name": "EQBLB SPX CALL 6000.00 KO 6500 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "SPX Index",
                "numberOfOptions": 100,
                "multiplier": 1,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 6000,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "16:00:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "lookbackTerms": {
                    "lookbackType": "FLOATING_STRIKE",
                    "initialPrice": 6000,
                    "strikePercentage": 1.0,
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-01-15",
                        "eventPeriodEndDate": "2025-01-15",
                        "eventTimeType": "CLOSING",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "LOOKBACK_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 6500,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-01-15",
                        "eventPeriodEndDate": "2025-01-15",
                        "eventTimeType": "CLOSING",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 350000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2025-01-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "EQ_BARRIER_LOOKBACK_OPTION",
                "productFamily": "EQ_OPTIONS",
                "semanticType": "EQ_BARRIER_LOOKBACK_OPTION",
            },
        }
