#!/usr/bin/env python
# pyright: basic

"""
Equity Performance Payout Models

Defines equity performance payout structures for equity swaps and derivatives.
Aligned with ISDA CDM PerformancePayout structure.
"""

from datetime import date
from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.base.cashflows import CalculationDateScheduleModel
from float_sdk.float_api.assets.base.settlement import DeterminationMethod
from float_sdk.float_api.assets.equities.equities import EquityModel, IndexModel
from float_sdk.float_api.assets.equities.terms import EquityReturnTermsModel
from float_sdk.float_api.base.references import EquityId, IndexId
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.fx_features import FxFeatureModel
from float_sdk.float_api_trading.products.base.returns import NotionalResetTermsModel
from float_sdk.float_api_trading.products.rates.cashflows import PaymentDateScheduleModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class PerformanceValuationDatesModel(DataModel):
    """
    Valuation date specification for a specific valuation period (initial, interim, or final).

    Aligned with ISDA CDM PerformanceValuationDates type.

    Attributes
    ----------
    valuation_dates : list[date], optional
        Explicitly specified valuation dates.
        CDM: valuationDates.adjustableOrRelativeDates (0..*)
    determination_method : DeterminationMethod, optional
        Method for determining valuation (e.g., CLOSING_PRICE, TWAP, VWAP).
        CDM: determinationMethod (0..1)
    """

    valuation_dates: list[date] | None = Field(
        default=None,
        title="Valuation Dates",
        description="Explicitly specified valuation dates for this period",
    )

    determination_method: DeterminationMethod | None = Field(
        default=None,
        title="Determination Method",
        description="Method for determining valuation (e.g., CLOSING_PRICE, TWAP, VWAP)",
    )

    semantic_type: Literal["PERFORMANCE_VALUATION_DATES"] = "PERFORMANCE_VALUATION_DATES"


class ValuationDatesModel(DataModel):
    """
    Complete valuation date structure for equity performance payouts.

    Defines initial, interim, and final valuation dates per ISDA CDM structure.
    Aligned with ISDA CDM ValuationDates type.

    Attributes
    ----------
    valuation_dates_initial : PerformanceValuationDatesModel, optional
        Initial valuation dates (typically trade date or effective date).
        CDM: valuationDatesInitial (0..1)
    valuation_dates_interim : PerformanceValuationDatesModel, optional
        Interim valuation dates for period-based swaps.
        CDM: valuationDatesInterim (0..1)
    valuation_dates_final : PerformanceValuationDatesModel, optional
        Final valuation dates (typically at maturity).
        CDM: valuationDatesFinal (1..1) - Required in CDM but optional here
    futures_price_valuation : bool, optional
        Whether the underlier equity is a futures contract.
        Affects valuation methodology and pricing calculations.
        CDM: futuresPriceValuation (0..1)
    """

    valuation_dates_initial: PerformanceValuationDatesModel | None = Field(
        default=None,
        title="Valuation Dates Initial",
        description="Initial valuation dates (typically trade date or effective date)",
    )

    valuation_dates_interim: PerformanceValuationDatesModel | None = Field(
        default=None,
        title="Valuation Dates Interim",
        description="Interim valuation dates for period-based swaps",
    )

    valuation_dates_final: PerformanceValuationDatesModel | None = Field(
        default=None,
        title="Valuation Dates Final",
        description="Final valuation dates (typically at maturity)",
    )

    futures_price_valuation: bool | None = Field(
        default=None,
        title="Futures Price Valuation",
        description="Whether the underlier equity is a futures contract, affecting valuation methodology",
    )

    semantic_type: Literal["VALUATION_DATES"] = "VALUATION_DATES"


# Backward compatibility alias - use NotionalResetTermsModel for new code
EquityNotionalResetModel = NotionalResetTermsModel


class PerformancePayoutModel(DataModel):
    """
    Base model for all performance payouts (equity, FX, commodity variance/volatility).

    Abstract base class containing shared fields for all performance-based payouts.
    Aligned with ISDA CDM PerformancePayout structure.

    This class is not used directly - it's inherited by specific payout models.
    """

    # Payer/Receiver
    payer: CounterpartyRole | None = Field(
        default=None,
        title="Payer",
        description="Party paying the performance return",
    )

    receiver: CounterpartyRole | None = Field(
        default=None,
        title="Receiver",
        description="Party receiving the performance return",
    )

    # Valuation Dates
    valuation_dates: ValuationDatesModel | None = Field(
        default=None,
        title="Valuation Dates",
        description="Valuation date structure with initial, interim, and final valuation dates",
    )

    # Calculation Schedule
    calculation_period_dates: CalculationDateScheduleModel | None = Field(
        default=None,
        title="Calculation Period Dates",
        description="Schedule specification for valuation/calculation periods",
    )

    # Payment Schedule
    payment_dates: PaymentDateScheduleModel | None = Field(
        default=None,
        title="Payment Dates",
        description="Payment date schedule specification",
    )

    semantic_type: Literal["PERFORMANCE_PAYOUT"] = "PERFORMANCE_PAYOUT"


class EquityPerformanceMixinModel(DataModel):
    """
    Mixin for equity-specific fields in performance payouts.

    Contains asset identification and equity features.
    Used by equity swaps, equity variance swaps, and equity volatility swaps.

    This is an abstract mixin - not used directly, only through inheritance.
    """

    # Asset
    asset: IndexId | EquityId | str | IndexModel | EquityModel | None = Field(
        default=None,
        title="Asset",
        description="The equity asset (index, stock, basket) for performance calculation",
    )

    # Equity-specific features
    fx_feature: FxFeatureModel | None = Field(
        default=None,
        title="FX Feature",
        description="FX feature for quanto/composite/cross-currency derivatives",
    )

    notional_reset: NotionalResetTermsModel | None = Field(
        default=None,
        title="Notional Reset",
        description="Notional reset terms defining if and how notional adjusts",
    )


class EquityPerformancePayoutModel(PerformancePayoutModel, EquityPerformanceMixinModel):
    """
    Equity performance payout for regular equity swaps with price/dividend returns.

    Used by EqSwapFloat and EqSwapFixed. Combines PerformancePayoutModel base fields
    with EquityPerformanceMixin fields, adding EquityReturnTermsModel for return calculation.

    Inherits from PerformancePayoutModel: payer, receiver, valuation_dates, calculation_period_dates, payment_dates
    Inherits from EquityPerformanceMixin: asset, fx_feature, notional_reset
    """

    # Quantity - number of shares/units for regular equity swaps
    number_of_units: float | None = Field(
        default=None,
        title="Number of Units",
        description="Number of units/shares of the asset",
        gt=0,
    )

    # Return Terms - specific to equity swaps (price + dividend)
    return_terms: EquityReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Equity return terms with price and dividend specifications",
    )

    semantic_type: Literal["EQUITY_PERFORMANCE_PAYOUT"] = "EQUITY_PERFORMANCE_PAYOUT"

    @computed_field
    @property
    def notional_amount(self) -> float | None:
        """
        Calculated notional amount: number_of_units × valuation_price_initial.

        Notional is derived from physical quantity and price per FPML standard.
        Valuation price is sourced from return_terms.price_return_terms.valuation_price_initial.
        """
        if self.number_of_units and self.return_terms and self.return_terms.price_return_terms and self.return_terms.price_return_terms.valuation_price_initial:
            return self.number_of_units * self.return_terms.price_return_terms.valuation_price_initial
        return None

    @computed_field
    @property
    def has_notional_reset(self) -> bool:
        """Check if notional reset is applicable."""
        return self.notional_reset is not None and self.notional_reset.is_applicable is True

    @computed_field
    @property
    def is_quanto(self) -> bool:
        """Check if this is a quanto payout (has Quanto FX feature)."""
        if self.fx_feature:
            return self.fx_feature.semantic_type == "QUANTO"
        return False

    class Config:
        json_schema_extra = {
            "title": "Equity Performance Payout",
            "description": "Composable equity performance leg for equity swaps and derivatives. Can be combined with fixed or floating rate legs to create complete swap products.",
            "example": {
                "payer": "PARTY_2",
                "receiver": "PARTY_1",
                "asset": "SPX Index",
                "numberOfUnits": 100.0,
                "notionalCurrency": "USD",
                "returnTerms": {
                    "returnType": "TOTAL_RETURN",
                    "dividendReturnTerms": {
                        "dividendPayoutRatio": 1.0,
                        "dividendReinvestment": False,
                        "dividendEntitlement": "EX_DATE",
                        "semanticType": "DIVIDEND_RETURN_TERMS",
                    },
                    "semanticType": "RETURN_TERMS",
                },
                "valuation": {
                    "valuationPriceInitial": 4500.0,
                    "semanticType": "EQUITY_VALUATION",
                },
                "calculationPeriodDates": {
                    "effectiveDate": "2025-01-15",
                    "terminationDate": "2026-01-15",
                    "frequency": {"period": "M", "multiplier": 3},
                    "semanticType": "CALCULATION_DATE_SCHEDULE",
                },
                "paymentDates": {
                    "payRelativeTo": "CALCULATION_PERIOD_END_DATE",
                    "paymentDaysOffset": 2,
                    "paymentFrequency": "QUARTERLY",
                    "semanticType": "PAYMENT_DATES",
                },
                "dayCountConvention": "ACT/365",
                "businessDayConvention": "FOLLOWING",
                "businessDays": "USNY",
                "semanticType": "EQUITY_PERFORMANCE_PAYOUT",
            },
        }
