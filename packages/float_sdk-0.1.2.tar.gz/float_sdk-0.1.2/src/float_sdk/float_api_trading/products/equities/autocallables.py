# pyright: basic

from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.cashflows import CalculationDateScheduleModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.equities.baskets import EqBasketModel
from float_sdk.float_api.assets.equities.equities import EquityModel, IndexModel
from float_sdk.float_api.assets.rates.rates import FixedRateModel
from float_sdk.float_api.base.references import CurrencyId, EquityId, IndexId
from float_sdk.float_api.datetime.conventions import DayCountConvention
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.contractual import BarrierTermsModel, ContractualProductModel, OptionStyle, OptionType
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.rates.cashflows import FloatingRateCashflowSeriesModel
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel, PremiumTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class AutocallCouponTermsModel(DataModel):
    payer: CounterpartyRole | None = Field(
        default=None,
        title="Payer",
        description="Party paying the coupon",
    )

    receiver: CounterpartyRole | None = Field(
        default=None,
        title="Receiver",
        description="Party receiving the coupon",
    )

    rate: FixedRateModel | None = Field(
        default=None,
        title="Rate",
        description="Fixed coupon rate specification",
    )

    day_count_convention: DayCountConvention | None = Field(
        default=None,
        title="Day Count Convention",
        description="Day count convention for coupon accrual calculation",
    )

    coupon_barrier_terms: BarrierTermsModel | None = Field(
        default=None,
        title="Coupon Barrier Terms",
        description="Barrier terms for conditional coupon payment (e.g., knock-in barrier that must be breached for coupon to be paid)",
    )

    semantic_type: Literal["AUTOCALL_COUPON_TERMS"] = "AUTOCALL_COUPON_TERMS"


class AutocallTermsModel(DataModel):
    """
    Nested container for autocall mechanics: knock-in/knock-out barriers,
    conditional coupon specification, and observation schedule.
    Shared by all autocallable product types.
    """

    knock_out_barrier: BarrierTermsModel | None = Field(
        default=None,
        title="Knock-Out Barrier",
        description="Autocall knock-out barrier — if breached, the note is called early and redeemed at par",
    )

    knock_in_barrier: BarrierTermsModel | None = Field(
        default=None,
        title="Knock-In Barrier",
        description="Downside knock-in barrier — if breached, the investor is exposed to the underlying performance",
    )

    coupon_terms: AutocallCouponTermsModel | None = Field(
        default=None,
        title="Coupon Terms",
        description="Conditional coupon terms specifying rate, day count, and payer/receiver",
    )

    observation_terms: CalculationDateScheduleModel | None = Field(
        default=None,
        title="Observation Terms",
        description="Observation schedule for barrier determination dates including frequency, roll convention, and business day adjustments",
    )

    semantic_type: Literal["AUTOCALL_TERMS"] = "AUTOCALL_TERMS"


class EqAutocallableModel(ContractualProductModel):
    """
    Equity Autocallable structured product on a single underlying.

    A structured note with an embedded put option, autocall (knock-out) barrier for
    early redemption, downside knock-in barrier, conditional coupons, and a floating
    rate leg. Computed in notional terms.
    """

    product_type: ProductType = Field(
        ProductType.EQ_AUTOCALLABLE,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="Party buying the autocallable note (paying premium, receiving coupons)",
    )

    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="Party selling the autocallable note (receiving premium, paying coupons)",
    )

    asset: IndexId | EquityId | str | IndexModel | EquityModel | None = Field(
        default=None,
        title="Asset",
        description="Underlying equity or index for the autocallable",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Notional amount of the autocallable note",
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency of the notional amount",
    )

    initial_price: float | None = Field(
        default=None,
        title="Initial Price",
        description="Initial reference price of the underlying asset used to compute absolute barrier levels",
    )

    option_type: OptionType | None = Field(
        default=OptionType.PUT,
        title="Option Type",
        description="Option type for the embedded put (always PUT for autocallables)",
        json_schema_extra={"readOnly": True},
    )

    option_style: OptionStyle | None = Field(
        default=None,
        title="Option Style",
        description="Exercise style of the embedded option (European, American, Bermudan)",
    )

    strike_price: float | None = Field(
        default=None,
        title="Strike Price",
        description="Strike price of the embedded put option as a fraction of initial price",
    )

    autocall_terms: AutocallTermsModel | None = Field(
        default=None,
        title="Autocall Terms",
        description="Autocall mechanics including knock-in/knock-out barriers, observation schedule, and conditional coupon specification",
    )

    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating rate payout leg specifying floating rate index, spread, reset dates, and payment schedule",
    )

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms including settlement currency and payment date",
    )

    semantic_type: Literal["EQ_AUTOCALLABLE"] = Field(default="EQ_AUTOCALLABLE", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Autocallable",
            "description": "Equity autocallable structured product on a single underlying. Features an embedded put option, autocall knock-out barriers for early redemption, downside knock-in protection, conditional coupons, and a floating rate leg.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "SPX Index",
                "notionalAmount": 5000000.0,
                "notionalCurrency": "USD",
                "initialPrice": 5000.0,
                "optionType": "PUT",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.0,
                "autocallTerms": {
                    "knockOutBarrier": {
                        "triggerType": "EQUAL_OR_GREATER",
                        "eventType": "KNOCK_OUT",
                        "level": 1.0,
                        "semanticType": "BARRIER_TERMS",
                    },
                    "knockInBarrier": {
                        "triggerType": "EQUAL_OR_LESS",
                        "eventType": "KNOCK_IN",
                        "level": 0.7,
                        "semanticType": "BARRIER_TERMS",
                    },
                    "couponTerms": {
                        "payer": "PARTY_2",
                        "receiver": "PARTY_1",
                        "rate": {"rate": 0.10, "semanticType": "FIXED_RATE"},
                        "dayCountConvention": "30/360",
                        "semanticType": "AUTOCALL_COUPON_TERMS",
                    },
                    "semanticType": "AUTOCALL_TERMS",
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalAmount": 5000000.0,
                    "notionalCurrency": "USD",
                    "floatingRate": {
                        "rateOption": "USD-SOFR-COMPOUND",
                        "spread": 0.005,
                        "semanticType": "FLOATING_RATE",
                    },
                    "dayCountConvention": "ACT/360",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "settlementTerms": {
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "effectiveDate": "2025-01-15",
                "terminationDate": "2026-01-15",
                "semanticType": "EQ_AUTOCALLABLE",
            },
        }


EqAutocallableModel.model_rebuild()


class EqWorstOfBasketAutocallableModel(ContractualProductModel):
    """
    Equity Worst-Of Basket Autocallable.

    A structured product on a basket of underlyings where the payoff is determined
    by the worst-performing constituent. Features autocall (knock-out) barriers,
    downside knock-in barriers, conditional coupons, and floating rate leg.
    """

    product_type: ProductType = Field(
        ProductType.EQ_WORST_OF_BASKET_AUTOCALLABLE,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="Party buying the autocallable note (paying premium, receiving coupons)",
    )

    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="Party selling the autocallable note (receiving premium, paying coupons)",
    )

    asset: EqBasketModel | None = Field(
        default=None,
        title="Asset",
        description="Basket of equities/indices for worst-of determination (minimum 2 constituents)",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Notional amount of the autocallable note",
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency of the notional amount",
    )

    option_type: OptionType | None = Field(
        default=OptionType.PUT,
        title="Option Type",
        description="Option type for the embedded put (always PUT for autocallables)",
        json_schema_extra={"readOnly": True},
    )

    option_style: OptionStyle | None = Field(
        default=None,
        title="Option Style",
        description="Exercise style of the embedded option (European, American, Bermudan)",
    )

    strike_price: float | None = Field(
        default=None,
        title="Strike Price",
        description="Strike price of the embedded put option as a fraction of initial price",
    )

    autocall_terms: AutocallTermsModel | None = Field(
        default=None,
        title="Autocall Terms",
        description="Autocall mechanics including knock-in/knock-out barriers, observation schedule, and conditional coupon specification",
    )

    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating rate payout leg specifying floating rate index, spread, reset dates, and payment schedule",
    )

    premium_terms: PremiumTermsModel | None = Field(
        default=None,
        title="Premium Terms",
        description="Upfront premium terms for the autocallable note",
    )

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms including settlement currency and payment date",
    )

    semantic_type: Literal["EQ_WORST_OF_BASKET_AUTOCALLABLE"] = Field(default="EQ_WORST_OF_BASKET_AUTOCALLABLE", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Worst-Of Basket Autocallable",
            "description": "Worst-of basket autocallable structured product. Payoff determined by the worst-performing constituent in the basket. Features autocall knock-out barriers, downside knock-in protection, and conditional coupons.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": {
                    "constituents": [
                        {"asset": "SPX Index", "weight": 1.0, "semanticType": "BASKET_CONSTITUENT"},
                        {"asset": "SX5E Index", "weight": 1.0, "semanticType": "BASKET_CONSTITUENT"},
                        {"asset": "NKY Index", "weight": 1.0, "semanticType": "BASKET_CONSTITUENT"},
                    ],
                    "semanticType": "EQ_BASKET",
                },
                "notionalAmount": 10000000.0,
                "notionalCurrency": "USD",
                "optionType": "PUT",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.0,
                "autocallTerms": {
                    "knockOutBarrier": {
                        "triggerType": "EQUAL_OR_GREATER",
                        "eventType": "KNOCK_OUT",
                        "level": 1.0,
                        "semanticType": "BARRIER_TERMS",
                    },
                    "knockInBarrier": {
                        "triggerType": "EQUAL_OR_LESS",
                        "eventType": "KNOCK_IN",
                        "level": 0.6,
                        "semanticType": "BARRIER_TERMS",
                    },
                    "couponTerms": {
                        "payer": "PARTY_2",
                        "receiver": "PARTY_1",
                        "rate": {"rate": 0.10, "semanticType": "FIXED_RATE"},
                        "dayCountConvention": "30/360",
                        "couponBarrierTerms": {
                            "triggerType": "EQUAL_OR_GREATER",
                            "eventType": "KNOCK_IN",
                            "level": 0.7,
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "AUTOCALL_COUPON_TERMS",
                    },
                    "semanticType": "AUTOCALL_TERMS",
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalAmount": 10000000.0,
                    "notionalCurrency": "USD",
                    "floatingRate": {
                        "rateOption": "USD-SOFR-COMPOUND",
                        "spread": 0.005,
                        "semanticType": "FLOATING_RATE",
                    },
                    "dayCountConvention": "ACT/360",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "premiumTerms": {
                    "premium": 10000000.0,
                    "premiumCurrency": "USD",
                    "premiumPaymentDate": "2025-01-17",
                    "premiumPayer": "PARTY_1",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "effectiveDate": "2025-01-15",
                "terminationDate": "2028-01-15",
                "semanticType": "EQ_WORST_OF_BASKET_AUTOCALLABLE",
            },
        }


EqWorstOfBasketAutocallableModel.model_rebuild()
