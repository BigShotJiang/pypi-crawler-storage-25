#!/usr/bin/env python
# pyright: basic

"""
Equity Cash Instruments

"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api_trading.products.base.securities import ProductType, SecurityProductModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class EqStockModel(SecurityProductModel):
    product_type: ProductType = Field(
        ProductType.EQ_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    buyer: CounterpartyRole | None = Field(
        default=None, title="Buyer", description="The party which will pay the premium to the seller on premmium payment date."
    )
    seller: CounterpartyRole | None = Field(
        None, title="Seller", description="The party which will receieve the premium from the buyer on premmium payment date."
    )
    quantity: float | None = Field(default=None, title="Quantity", description="Quantity expressed in number of options.")

    # stock: IndexId | StockId | None = Field(default=None, title="Underlier", description="The underlying stock or index which is delivered or referenced for cash settlement under the contract terms.")
    # exchange: ExchangeId | None = Field(default=None, title="Exchange", description="The exchange on which the underlier is traded for reference pricing and delivery.")

    traded_price: float | None = Field(default=None, title="Traded Price", description="Price at which the stock is transacted.")

    semantic_type: Literal["EQ_STOCK"] = Field(default="EQ_STOCK", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Equity Stock",
            "description": "A stock transaction involves the buying or selling of shares in a publicly traded company between a buyer and a seller through a stock exchange or over-the-counter market. This transaction specifies the number of shares, the agreed-upon price per share, and the settlement date when the ownership of the shares and payment are exchanged. The transaction can be initiated by individual investors, institutional investors, or trading algorithms, and it is facilitated by brokers or electronic trading platforms that ensure the trade's execution and regulatory compliance.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "stock": "AAPL",
                "exchange": "XNAS",
                "quantity": 10000,
                "tradedPrice": 188,
            },
        }
