#!/usr/bin/env python
# pyright: basic

"""
Hybrid Option Specifications

"""

from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.all import BarrierAssetUnion
from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.contractual import BarrierEventType, DoubleBarrierModel, SingleBarrierModel
from float_sdk.float_api_trading.products.base.options import BarrierOptionBaseModel, BinaryOptionBaseModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class HybridKnockoutModel(BarrierOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.HYBRID_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: BarrierAssetUnion = Field(default=None, title="Asset", description="The underlying asset (FX, Equity, Index, Commodity, Future, or Rate)")

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.CROSS_ASSET

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.HYBRID_OPTIONS

    semantic_type: Literal["HYBRID_KNOCKOUT"] = Field(
        default="HYBRID_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Hybrid Knockout",
            "description": "A hybrid knockout (knockin) option is a barrier option that terminates and becomes worthless if the underlying asset level hits a specified barrier level during the contract's life. For a knockout option, this means the option is voided if the underlier level breaches the barrier, with up-and-out or down-and-out structures based on whether the rate moves upward or downward, respectively. Conversely, a hybrid knock-in option activates only if the barrier is reached, becoming a standard option after the barrier is triggered, with up-and-in or down-and-in variations. These options offer tailored risk exposures and typically have lower premiums than vanilla options due to the barrier feature.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "asset": "375ff7eded784ab8bf59db9a81292a77",
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 6000.00,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "HYBRID_KNOCKOUT",
            },
        }


class HybridDoubleKnockoutModel(BarrierOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.HYBRID_DOUBLE_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: BarrierAssetUnion = Field(default=None, title="Asset", description="The underlying asset (FX, Equity, Index, Commodity, Future, or Rate)")

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.CROSS_ASSET

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.HYBRID_OPTIONS

    semantic_type: Literal["HYBRID_DOUBLE_KNOCKOUT"] = Field(
        default="HYBRID_DOUBLE_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Hybrid Double Knockout Option",
            "description": 'A double knockout option is a barrier option that ceases to exist if the underlying asset level hits either of two specified barrier levels, one above and one below the current underlier level, at any time during the option\'s life. These barriers create a range, and if the underlier level moves outside this range (either up or down), the option is "knocked out" and becomes worthless. Conversely, a double knockin option only activates as a standard option if the FX rate breaches one of the two barrier levels, either upward or downward. These options allow for more precise risk control and generally feature lower premiums, as the likelihood of the option being exercised is reduced due to the presence of two knockout/knockin barriers.',
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "asset": "375ff7eded784ab8bf59db9a81292a77",
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 6000.00,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "HYBRID_DOUBLE_KNOCKOUT",
            },
        }


class MultiAssetBinaryOptionModel(BinaryOptionBaseModel):
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event.")

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.CROSS_ASSET

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.HYBRID_OPTIONS


class DualBinaryOptionModel(MultiAssetBinaryOptionModel):
    product_type: ProductType = Field(
        default=ProductType.DUAL_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    barriers: list[SingleBarrierModel | DoubleBarrierModel] | None = Field(
        default=None, title="Barriers", description="The terms of the barrier event for each FX cross currency pair."
    )

    semantic_type: Literal["DUAL_BINARY_OPTION"] = Field(
        default="DUAL_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Dual Binary Option",
            "description": 'A dual binary option is a type of exotic option that offers a fixed payout if a specified condition is met by the two underlying assets at expiration. If the condition is not met, the option expires worthless. Dual binary options are commonly used in structured products and hedging strategies due to their simple "all-or-nothing" payout structure and are popular in markets like foreign exchange and equity derivatives. They provide an efficient way to gain leveraged exposure to directional moves with clearly defined risk and reward profiles.',
            "example": {
                "name": "DBO GBPUSD >= 1.3575 EURUSD >= 1.0875 15JUL24",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionType": "BINARY",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barriers": [
                    {
                        "asset": "GBPUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodStartDate": "2024-07-15",
                            "eventPeriodEndDate": "2024-07-15",
                            "rateOption": "WM_REUTERS_MID_WMR03_GBLO_1600",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.3575,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "SINGLE_BARRIER_MODEL",
                    },
                    {
                        "asset": "EURUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodStartDate": "2024-07-15",
                            "eventPeriodEndDate": "2024-07-15",
                            "rateOption": "WM_REUTERS_MID_WMR03_USNY_1000",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.0875,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "SINGLE_BARRIER_MODEL",
                    },
                ],
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "DUAL_BINARY_OPTION",
            },
        }


class TripleBinaryOptionModel(MultiAssetBinaryOptionModel):
    product_type: ProductType = Field(
        default=ProductType.TRIPLE_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event.")
    barriers: list[SingleBarrierModel | DoubleBarrierModel] | None = Field(
        default=None, title="Barriers", description="The terms of the barrier event for each asset.", min_length=3
    )

    semantic_type: Literal["TRIPLE_BINARY_OPTION"] = Field(
        default="TRIPLE_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Triple Binary Option",
            "description": 'A triple binary option is a type of exotic option that offers a fixed payout if a specified condition is met by the three underlying assets at expiration. If the condition is not met, the option expires worthless. Dual binary options are commonly used in structured products and hedging strategies due to their simple "all-or-nothing" payout structure and are popular in markets like foreign exchange and equity derivatives. They provide an efficient way to gain leveraged exposure to directional moves with clearly defined risk and reward profiles.',
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionType": "BINARY",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barriers": [
                    {
                        "asset": "GBPUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-07-15",
                            "eventPeriodStartDate": "2024-07-15",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.3575,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "SINGLE_BARRIER_MODEL",
                    },
                    {
                        "asset": "EURUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-07-15",
                            "eventPeriodStartDate": "2024-07-15",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.0875,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "SINGLE_BARRIER_MODEL",
                    },
                    {
                        "asset": "USDJPY",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-07-15",
                            "eventPeriodStartDate": "2024-07-15",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 65.00,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                    },
                ],
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "TRIPLE_BINARY_OPTION",
            },
        }


class BinaryKnockoutLegModel(DataModel):
    """
    Single leg of a multi-asset binary knockout option.

    Each leg represents one asset with:
    - Trigger barrier: Observed at expiration (European) to determine payout condition
    - Knockout barrier: Observed continuously (American) that terminates the entire option if touched
    """

    asset: BarrierAssetUnion = Field(
        default=None,
        title="Asset",
        description="The underlying asset for this leg (FX, Equity, Index, Commodity, Future, or Rate)",
    )

    barrier: SingleBarrierModel | None = Field(
        default=None,
        title="Trigger Barrier",
        description="The trigger barrier observed at expiration (European observation). Determines if payout condition is met at expiry.",
    )

    knockout_barrier: SingleBarrierModel | DoubleBarrierModel | None = Field(
        default=None,
        title="Knockout Barrier",
        description="The knockout barrier observed continuously (American/touch observation). Terminates the option if touched during observation period.",
    )

    semantic_type: Literal["BINARY_KNOCKOUT_LEG"] = Field(
        default="BINARY_KNOCKOUT_LEG",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
    )


class DualBinaryKnockoutModel(MultiAssetBinaryOptionModel):
    """
    Dual Binary Knockout Option

    A two-asset binary option where each leg has its own trigger and knockout barriers.
    All trigger barriers must be satisfied at expiry for payout.
    Any knockout barrier touched during observation period terminates the option.

    Example:
    - Leg 1: EUR/USD >= 1.1000 at expiry (trigger), knocks out if touches 1.1500
    - Leg 2: GBP/USD >= 1.2500 at expiry (trigger), knocks out if touches 1.3000
    - Payout $1M if both triggers satisfied and no knockout touched
    """

    product_type: ProductType = Field(
        default=ProductType.DUAL_BINARY_KNOCKOUT,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    legs: list[BinaryKnockoutLegModel] | None = Field(
        default=None,
        title="Legs",
        description="The binary knockout legs, one per asset.",
        min_length=2,
        max_length=2,
    )

    semantic_type: Literal["DUAL_BINARY_KNOCKOUT"] = Field(
        default="DUAL_BINARY_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Dual Binary Knockout",
            "description": 'A dual binary knockout option is a type of exotic option that offers a fixed payout if specified conditions are met by both underlying assets at expiration, and neither knockout barrier is touched before expiry. Each leg has a trigger barrier (observed at expiry) and a knockout barrier (continuously observed). If any knockout barrier is touched, the entire option terminates. If all trigger conditions are met at expiry and no knockouts occurred, the fixed payout is made. These options combine the "all-or-nothing" payout structure of binary options with knockout features for risk management.',
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "legs": [
                    {
                        "asset": "EURUSD",
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_IN",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 1.1000,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "CLOSING",
                                "eventPeriodStartDate": "2024-07-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "knockoutBarrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 1.1500,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "ANYTIME",
                                "eventPeriodStartDate": "2024-04-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "semanticType": "BINARY_KNOCKOUT_LEG",
                    },
                    {
                        "asset": "GBPUSD",
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_IN",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 1.2500,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "CLOSING",
                                "eventPeriodStartDate": "2024-07-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "knockoutBarrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 1.3000,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "ANYTIME",
                                "eventPeriodStartDate": "2024-04-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "semanticType": "BINARY_KNOCKOUT_LEG",
                    },
                ],
                "premiumTerms": {
                    "premium": 500000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementDate": "2024-07-17",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "DUAL_BINARY_KNOCKOUT",
            },
        }


class TripleBinaryKnockoutModel(MultiAssetBinaryOptionModel):
    """
    Triple Binary Knockout Option

    A three-asset binary option where each leg has its own trigger and knockout barriers.
    All trigger barriers must be satisfied at expiry for payout.
    Any knockout barrier touched during observation period terminates the option.

    Example:
    - Leg 1: USD/CNH >= 7.0 at expiry (trigger), knocks out if touches 7.5
    - Leg 2: USD/MXN <= 20.0 at expiry (trigger), knocks out if touches 19.0
    - Leg 3: USD/BRL <= 5.5 at expiry (trigger), knocks out if touches 5.0
    - Payout $50M if all triggers satisfied and no knockout touched
    """

    product_type: ProductType = Field(
        default=ProductType.TRIPLE_BINARY_KNOCKOUT,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    legs: list[BinaryKnockoutLegModel] = Field(
        ...,
        title="Legs",
        description="The binary knockout legs, one per asset.",
        min_length=3,
    )

    semantic_type: Literal["TRIPLE_BINARY_KNOCKOUT"] = Field(
        default="TRIPLE_BINARY_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Triple Binary Knockout",
            "description": 'A triple binary knockout option is a type of exotic option that offers a fixed payout if specified conditions are met by all three underlying assets at expiration, and no knockout barriers are touched before expiry. Each leg has a trigger barrier (observed at expiry) and a knockout barrier (continuously observed). If any knockout barrier is touched, the entire option terminates. If all trigger conditions are met at expiry and no knockouts occurred, the fixed payout is made. These options combine the "all-or-nothing" payout structure of binary options with knockout features for risk management across multiple assets.',
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "legs": [
                    {
                        "asset": "USDCNH",
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_IN",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 7.0,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "CLOSING",
                                "eventPeriodStartDate": "2024-07-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "knockoutBarrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 7.5,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "ANYTIME",
                                "eventPeriodStartDate": "2024-04-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "semanticType": "BINARY_KNOCKOUT_LEG",
                    },
                    {
                        "asset": "USDMXN",
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_IN",
                                "triggerType": "EQUAL_OR_LESS",
                                "level": 20.0,
                                "direction": "DOWN",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "CLOSING",
                                "eventPeriodStartDate": "2024-07-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "knockoutBarrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_LESS",
                                "level": 19.0,
                                "direction": "DOWN",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "ANYTIME",
                                "eventPeriodStartDate": "2024-04-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "semanticType": "BINARY_KNOCKOUT_LEG",
                    },
                    {
                        "asset": "USDBRL",
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_IN",
                                "triggerType": "EQUAL_OR_LESS",
                                "level": 5.5,
                                "direction": "DOWN",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "CLOSING",
                                "eventPeriodStartDate": "2024-07-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "knockoutBarrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_LESS",
                                "level": 5.0,
                                "direction": "DOWN",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "observationTerms": {
                                "eventTimeType": "ANYTIME",
                                "eventPeriodStartDate": "2024-04-15",
                                "eventPeriodEndDate": "2024-07-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                        "semanticType": "BINARY_KNOCKOUT_LEG",
                    },
                ],
                "premiumTerms": {
                    "premium": 10100000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementAmount": 50000000,
                    "settlementCurrency": "USD",
                    "settlementDate": "2024-07-17",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "TRIPLE_BINARY_KNOCKOUT",
            },
        }
