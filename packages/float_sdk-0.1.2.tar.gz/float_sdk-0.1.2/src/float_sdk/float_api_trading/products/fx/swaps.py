#!/usr/bin/env python
# pyright: basic

"""
FX Variance and Volatility Swap Models

Flat structure for FX variance/volatility swaps aligned with market termsheets.
Direct fields instead of nested payout abstractions for single-leg products.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.currencies.baskets import FXBasketModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyId, CurrencyModel, ExchangeRateModel
from float_sdk.float_api.base.references import ExchangeRateId
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.volatility.swaps import VarianceVolatilitySwapBaseModel
from float_sdk.float_api_trading.products.volatility.terms import (
    CorrelationReturnTermsModel,
    VarianceReturnTermsModel,
    VolatilityReturnTermsModel,
)
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class FXVarianceSwapModel(VarianceVolatilitySwapBaseModel):
    """
    FX Variance Swap - Flat Structure.

    An FX variance swap allows investors to trade the variance (squared volatility) of a currency pair.
    One party pays realized variance, the other pays a fixed variance strike/premium.

    Flat structure aligned with market termsheets - all fields at product level instead of
    nested payout abstractions. Variance swaps are single-leg products, not composable.

    Key Fields
    ----------
    asset : str | ExchangeRateModel
        Currency pair (e.g., "EURUSD" or "EUR/USD")
    notional_amount : float
        Variance notional amount (not vega notional)
    notional_currency : Currency
        Currency in which notional is denominated
    return_terms : VarianceReturnTermsModel
        Variance calculation terms (strike, expected N, caps/floors, etc.)
    """

    product_type: ProductType = Field(
        ProductType.FX_VARIANCE_SWAP,
        title="Product Type",
        description="FX Variance Swap",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    payer: CounterpartyRole | None = Field(
        default=None,
        title="Payer",
        description="Party paying realized variance",
    )

    receiver: CounterpartyRole | None = Field(
        default=None,
        title="Receiver",
        description="Party receiving realized variance",
    )

    # Asset and Notional
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None,
        title="Asset",
        description="Currency pair (e.g., 'EURUSD' or 'USDBRL')",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Variance notional amount (primary notional, not vega notional)",
        gt=0,
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency in which the notional is denominated",
    )

    # Return Calculation
    return_terms: VarianceReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Variance return terms with strike, expected N, annualization, caps/floors",
    )

    semantic_type: Literal["FX_VARIANCE_SWAP"] = Field(default="FX_VARIANCE_SWAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "FX Variance Swap",
            "description": "FX variance swap with flat structure aligned with market termsheets. Buyer receives realized variance, seller pays fixed variance strike. Payout is quadratic to spot moves.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "EURUSD",
                "notionalAmount": 10000000.0,
                "notionalCurrency": "USD",
                "valuationDate": "2027-12-25",
                "valuationTime": {
                    "time": "16:00:00",
                    "location": "GBLO",
                    "semanticType": "TIME_LOCATION",
                },
                "returnTerms": {
                    "varianceStrikePrice": 0.000625,
                    "vegaNotionalAmount": 50000.0,
                    "expectedN": 252,
                    "annualizationFactor": 252,
                    "semanticType": "VARIANCE_RETURN_TERMS",
                },
                "observationDates": {
                    "effectiveDate": "2026-12-26",
                    "terminationDate": "2027-12-25",
                    "dateRollRule": {"period": "B", "multiplier": 1},
                    "businessDayConvention": "FOLLOWING",
                    "businessDays": "GBLO",
                    "semanticType": "CALCULATION_DATES_SCHEDULE",
                },
                "premiumTerms": {
                    "premium": 60000.0,
                    "premiumCurrency": "USD",
                    "premiumPaymentDate": "2025-11-28",
                    "premiumPayer": "PARTY_2",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementDate": "2027-12-29",
                    "settlementCurrency": "USD",
                    "settlementRateOption": "WM_REUTERS_MID",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_VARIANCE_SWAP",
            },
        }


class FXVolatilitySwapModel(VarianceVolatilitySwapBaseModel):
    """
    FX Volatility Swap - Flat Structure.

    An FX volatility swap allows investors to trade the volatility of a currency pair.
    One party pays realized volatility, the other pays a fixed volatility strike/premium.

    Flat structure aligned with market termsheets - all fields at product level instead of
    nested payout abstractions. Volatility swaps are single-leg products, not composable.
    Payout is linear to realized volatility (not variance).

    Key Fields
    ----------
    asset : str | ExchangeRateModel
        Currency pair (e.g., "EURUSD" or "EUR/USD")
    notional_amount : float
        Vega notional amount (for vol swaps, notional is in volatility units)
    notional_currency : Currency
        Currency in which notional is denominated
    return_terms : VolatilityReturnTermsModel
        Volatility calculation terms (strike, mean adjustment, expected N, caps/floors, etc.)
    """

    product_type: ProductType = Field(
        default=ProductType.FX_VOLATILITY_SWAP,
        title="Product Type",
        description="FX Volatility Swap",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    payer: CounterpartyRole | None = Field(
        default=None,
        title="Payer",
        description="Party paying realized volatility",
    )

    receiver: CounterpartyRole | None = Field(
        default=None,
        title="Receiver",
        description="Party receiving realized volatility",
    )

    # Asset and Notional
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None,
        title="Asset",
        description="Currency pair (e.g., 'EURUSD' or 'EUR/USD')",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Vega notional amount (notional in volatility units for vol swaps)",
        gt=0,
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency in which the notional is denominated",
    )

    # Return Calculation
    return_terms: VolatilityReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Volatility return terms with strike, mean adjustment, expected N, annualization, caps/floors",
    )

    semantic_type: Literal["FX_VOLATILITY_SWAP"] = Field(default="FX_VOLATILITY_SWAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "FX Volatility Swap",
            "description": "FX volatility swap with flat structure aligned with market termsheets. Buyer receives realized volatility, seller pays fixed volatility strike. Payout is linear to volatility.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "EURUSD",
                "notionalAmount": 5000000.0,
                "notionalCurrency": "USD",
                "valuationDate": "2026-12-25",
                "valuationTime": {
                    "time": "16:00:00",
                    "location": "GBLO",
                    "semanticType": "TIME_LOCATION",
                },
                "returnTerms": {
                    "vegaNotionalAmount": 50000.0,
                    "volatilityStrikePrice": 0.0744,
                    "meanAdjustment": False,
                    "expectedN": 257,
                    "annualizationFactor": 252,
                    "semanticType": "VOLATILITY_RETURN_TERMS",
                },
                "observationDates": {
                    "effectiveDate": "2026-12-26",
                    "terminationDate": "2027-12-25",
                    "dateRollRule": {"period": "B", "multiplier": 1},
                    "businessDayConvention": "FOLLOWING",
                    "businessDays": "GBLO",
                    "semanticType": "CALCULATION_DATES_SCHEDULE",
                },
                "premiumTerms": {
                    "premium": 60000.0,
                    "premiumCurrency": "USD",
                    "premiumPaymentDate": "2025-11-28",
                    "premiumPayer": "PARTY_2",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementDate": "2026-09-29",
                    "settlementCurrency": "USD",
                    "settlementRateOption": "WM_REUTERS_MID_WMR03_GBLO_1600",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_VOLATILITY_SWAP",
            },
        }


class FXCorrelationSwapModel(VarianceVolatilitySwapBaseModel):
    """
    FX Correlation Swap - Flat Structure.

    An FX correlation swap allows investors to trade the realized correlation between
    a basket of FX pairs vs a fixed correlation strike.
    Payout = Notional × (Realized Correlation - Strike Correlation)

    Flat structure aligned with market termsheets - all fields at product level instead of
    nested payout abstractions. Correlation swaps are single-leg products, not composable.

    Key Fields
    ----------
    asset : FXBasketModel
        Basket of FX pairs with weights for correlation calculation
    notional_amount : float
        Correlation notional (sensitivity to 1% correlation change)
    notional_currency : CurrencyId | str | CurrencyModel
        Currency in which notional is denominated
    return_terms : CorrelationReturnTermsModel
        Correlation calculation terms (strike, expected N, correlation type, etc.)
    """

    product_type: ProductType = Field(
        ProductType.FX_CORRELATION_SWAP,
        title="Product Type",
        description="FX Correlation Swap",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="Buyer of correlation (receives realized correlation)",
    )

    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="Seller of correlation (pays realized correlation)",
    )

    # Asset (Basket) and Notional
    asset: FXBasketModel | None = Field(
        default=None,
        title="Asset",
        description="Basket of FX pairs for correlation calculation (minimum 2 constituents)",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Correlation notional (sensitivity to 1% correlation change)",
        gt=0,
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency in which the notional is denominated",
    )

    # Return Calculation
    return_terms: CorrelationReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Correlation calculation terms with strike, expected N, and correlation type",
    )

    semantic_type: Literal["FX_CORRELATION_SWAP"] = Field(default="FX_CORRELATION_SWAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "FX Correlation Swap",
            "description": "FX correlation swap with flat structure aligned with market termsheets. Buyer receives realized correlation, seller pays fixed correlation strike. Payout is linear to correlation.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "basket": {
                    "constituents": [
                        {
                            "asset": "EURUSD",
                            "initialLevel": 1.08,
                            "weight": 0.5,
                            "semanticType": "BASKET_CONSTITUENT",
                        },
                        {
                            "asset": "GBPUSD",
                            "initialLevel": 1.27,
                            "weight": 0.5,
                            "semanticType": "BASKET_CONSTITUENT",
                        },
                    ],
                    "weightingScheme": "CUSTOM_WEIGHTED",
                    "currency": "USD",
                    "semanticType": "BASKET",
                },
                "notionalAmount": 1000000.0,
                "notionalCurrency": "USD",
                "valuationDate": "2026-12-31",
                "valuationTime": {
                    "time": "16:00:00",
                    "location": "GBLO",
                    "semanticType": "TIME_LOCATION",
                },
                "returnTerms": {
                    "correlationStrikePrice": 0.70,
                    "expectedN": 252,
                    "annualizationFactor": 252,
                    "correlationType": "PAIRWISE_AVERAGE",
                    "meanAdjustment": False,
                    "semanticType": "CORRELATION_RETURN_TERMS",
                },
                "observationDates": {
                    "effectiveDate": "2026-01-01",
                    "terminationDate": "2026-12-31",
                    "dateRollRule": {"period": "B", "multiplier": 1},
                    "businessDayConvention": "FOLLOWING",
                    "businessDays": "GBLO",
                    "semanticType": "CALCULATION_DATES_SCHEDULE",
                },
                "settlementTerms": {
                    "settlementDate": "2027-01-05",
                    "settlementCurrency": "USD",
                    "settlementRateOption": "WM_REUTERS_MID",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_CORRELATION_SWAP",
            },
        }


# Rebuild models to ensure schemas are fully built (Pydantic v2 requirement for inheritance)
FXVarianceSwapModel.model_rebuild()
FXVolatilitySwapModel.model_rebuild()
FXCorrelationSwapModel.model_rebuild()
