#!/usr/bin/env python
# pyright: basic

from datetime import date
from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel, ExchangeRateModel
from float_sdk.float_api.base.references import CurrencyId, ExchangeRateId
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.settlement.terms import PhysicalSettlementTermsModel, ValidSettlementTypes
from float_sdk.float_api_trading.trading.parties import CounterpartyRole


class FXSpotModel(ContractualProductModel):
    product_type: ProductType = Field(
        default=ProductType.FX_SPOT, title="Product Type", description="Type of financial instrument.", frozen=True, json_schema_extra={"readOnly": True}
    )

    buyer: CounterpartyRole | None = Field(default=None, title="Buyer", description="The party which is the buyer of the reference currency.")
    seller: CounterpartyRole | None = Field(default=None, title="Seller", description="The party which is the seller of the reference currency.")

    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        None, title="Asset", description="The exchange rate or currency pair for the FX spot transaction"
    )

    notional_amount: float | None = Field(
        None,
        title="Notional Amount",
        description="The reference currency notional amount is the quantity of Settlement Currency used to determine the payment amount. If the Reference Currency Notional Amount is not specified in the it is the amount equal to the Reference Currency Notional Amount divided by the Forward Rate",
    )
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(None, title="Notional Currency", description="The currency of the notional amount.")

    spot_rate: float | None = Field(
        None,
        title="Spot Rate",
        description="The spot rate in the context of an FX spot transaction is the agreed-upon exchange rate at which two parties will exchange currencies on the spot settlement date. This rate is determined at the inception of the forward contract and is derived from the current spot rate",
    )

    settlement_terms: PhysicalSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Settlement terms for the underlying asset."
    )

    semantic_type: Literal["FX_SPOT"] = Field(
        default="FX_SPOT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        frozen=True,
        json_schema_extra={"readOnly": True},
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_ONE_DELTA

    class Config:
        json_schema_extra = {
            "title": "FX Spot",
            "description": "An FX spot transaction is a binding agreement between two counterparties to exchange a specified amount of one currency for another at a given exchange rate (the spot rate) on the spot settlement date, typically used for hedging or speculative purposes. The notional amounts, spot rate, and settlement date are agreed upon at the inception of the contract. On the settlement date, the counterparties exchange the currencies at the agreed-upon spot rate.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 100000000,
                "notionalCurrency": "EUR",
                "spotRate": 1.10,
                "effectiveDate": "2024-04-15",
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2024-04-17",
                },
                "productType": "FX_SPOT",
                "semanticType": "FX_SPOT",
            },
        }


class FXForwardModel(ContractualProductModel):
    product_type: ProductType = Field(
        default=ProductType.FX_FORWARD, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    buyer: CounterpartyRole | None = Field(default=None, title="Buyer", description="The party which is the buyer of the reference currency.")
    seller: CounterpartyRole | None = Field(default=None, title="Seller", description="The party which is the seller of the reference currency.")

    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        None, title="Asset", description="The exchange rate or currency pair for the FX forward transaction"
    )

    notional_amount: float | None = Field(
        None,
        title="Notional Amount",
        description="The reference currency notional amount is the quantity of Settlement Currency used to determine the payment amount. If the Reference Currency Notional Amount is not specified in the it is the amount equal to the Reference Currency Notional Amount divided by the Forward Rate",
    )
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(None, title="Notional Currency", description="The currency of the notional amount.")

    forward_rate: float | None = Field(
        None,
        title="Forward Rate",
        description="The forward rate in the context of an FX forward transaction is the agreed-upon exchange rate at which two parties will exchange currencies at the future valuation date, beyond the spot settlement date. This rate is determined at the inception of the forward contract and is derived from the current spot rate adjusted for the interest rate differential between the two currencies over the contract period.",
    )
    spot_rate: float | None = Field(
        None,
        title="Spot Rate",
        description="The spot rate component of the forward rate at the time of trade.",
    )
    forward_points: float | None = Field(
        None,
        title="Forward Points",
        description="The forward points (swap points) representing the interest rate differential between the two currencies over the contract period.",
    )

    valuation_date: date | None = Field(
        None,
        title="Valuation Date",
        description="The Valuation Date is the date that the “Spot Rate” for a Non-Deliverable Transaction is determined. As discussed in Paragraph 2 above, if the Valuation Date is not a Business Day, it is adjusted to the next preceding Business Day. If the parties do not specify a Valuation Date in their Confirmation, the Valuation Date will be (i) in the case of a Non-Deliverable FX Transaction, two Business Days prior to the Settlement Date",
    )

    settlement_terms: ValidSettlementTypes | None = Field(default=None, title="Settlement Terms", description="Settlement terms for the underlying asset.")

    semantic_type: Literal["FX_FORWARD"] = Field(
        default="FX_FORWARD", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_ONE_DELTA

    class Config:
        json_schema_extra = {
            "title": "FX Forward",
            "description": "An FX forward transaction is a binding agreement between two counterparties to exchange a specified amount of one currency for another at a predetermined exchange rate (the forward rate) on a future date beyond the spot settlement date, typically used for hedging or speculative purposes. The forward rate is calculated by adjusting the current spot rate by the interest rate differential between the two currencies over the contract period. The notional amounts, forward rate, valuation and settlement date are agreed upon at the inception of the contract, with no upfront payment required. On the settlement date, the counterparties exchange the currencies at the agreed-upon forward rate, regardless of the prevailing spot rate, thereby locking in the future exchange rate to mitigate the risk of adverse currency movements.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 100000000,
                "notionalCurrency": "EUR",
                "forwardRate": 1.10,
                "effectiveDate": "2024-04-15",
                "valuationDate": "2024-07-15",
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2024-07-17",
                },
                "prductType": "FX_FORWARD",
                "semanticType": "FX_FORWARD",
            },
        }


class FXSwapModel(ContractualProductModel):
    product_type: ProductType | None = Field(
        default=ProductType.FX_SWAP, title="FX Swap", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    near_leg: FXSpotModel | FXForwardModel | None = Field(
        default=None, title="Near Leg", description="The near leg of the FX swap representing the initial exchange of currencies."
    )
    far_leg: FXForwardModel | None = Field(
        default=None, title="Far Leg", description="The far leg of the FX swap representing the reverse exchange of currencies at a future date."
    )

    @computed_field
    def asset(self) -> ExchangeRateId | str | ExchangeRateModel | None:
        near = self.near_leg.asset if self.near_leg else None
        far = self.far_leg.asset if self.far_leg else None

        return near if near == far else None

    @computed_field
    def notional_amount(self) -> float | None:
        near = self.near_leg.notional_amount if self.near_leg else None
        far = self.far_leg.notional_amount if self.far_leg else None

        return near if near == far else None

    @computed_field
    def notional_currency(self) -> CurrencyId | str | CurrencyModel | None:
        near = self.near_leg.notional_currency if self.near_leg else None
        far = self.far_leg.notional_currency if self.far_leg else None

        return near if near == far else None

    @computed_field
    def buyer(self) -> CounterpartyRole | None:
        return self.near_leg.buyer if self.near_leg else None

    @computed_field
    def seller(self) -> CounterpartyRole | None:
        return self.near_leg.seller if self.near_leg else None

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_ONE_DELTA

    class Config:
        json_schema_extra = {
            "title": "FX Swap",
            "description": "An FX swap transaction is a binding agreement between two counterparties to simultaneously exchange a specified amount of one currency for another on an initial date (near leg) and to reverse the exchange at a predetermined rate on a future date (far leg). The FX swap consists of two legs: the near leg, which is typically an FX spot transaction, and the far leg, which is typically an FX forward transaction. FX swaps are commonly used for hedging currency risk, managing liquidity, or taking advantage of interest rate differentials between currencies. The notional amounts, exchange rates, and settlement dates for both legs are agreed upon at the inception of the contract.",
            "effectiveDate": "2024-04-15",
            "terminationDate": "2024-07-17",
            "example": {
                "nearLeg": {
                    "buyer": "PARTY_2",
                    "seller": "PARTY_1",
                    "asset": "EURUSD",
                    "effectiveDate": "2024-04-15",
                    "notionalAmount": 100000000,
                    "notionalCurrency": "EUR",
                    "spotRate": 1.1500,
                    "settlementTerms": {
                        "settlementType": "PHYSICAL",
                        "settlementDate": "2024-04-17",
                    },
                    "terminationDate": "2024-04-17",
                    "semanticType": "FX_SPOT",
                },
                "farLeg": {
                    "buyer": "PARTY_1",
                    "seller": "PARTY_2",
                    "asset": "EURUSD",
                    "effectiveDate": "2024-04-15",
                    "notionalAmount": 100000000,
                    "notionalCurrency": "EUR",
                    "forwardRate": 1.1525,
                    "valuationDate": "2024-07-15",
                    "settlementTerms": {
                        "settlementType": "PHYSICAL",
                        "settlementDate": "2024-07-17",
                    },
                    "terminationDate": "2024-07-17",
                    "semanticType": "FX_FORWARD",
                },
                "productType": "FX_SWAP",
                "semanticType": "FX_SWAP",
            },
        }
