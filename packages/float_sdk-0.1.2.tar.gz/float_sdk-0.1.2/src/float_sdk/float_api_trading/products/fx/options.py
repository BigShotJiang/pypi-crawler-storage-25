#!/usr/bin/env python
# pyright: basic

"""
FX Option Specifications

"""

from datetime import date, datetime, time
from typing import List, Literal

from pydantic import Field, computed_field, field_validator

from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.assets.currencies.baskets import FXBasketModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel, ExchangeRateModel
from float_sdk.float_api.assets.rates.rates import SettlementRateOptionModel, SyntheticSettlementRateOptionModel
from float_sdk.float_api.base.references import CurrencyId, ExchangeRateId, SettlementRateOptionId
from float_sdk.float_api.datetime.schedule import BusinessDateModel, RelativeDateModel
from float_sdk.float_api.locations.location import TimeLocationModel
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api_trading.products.base.contractual import (
    BarrierEventType,
    DoubleBarrierModel,
    OptionPayout,
    OptionStyle,
    OptionType,
    PayoutStyle,
    SingleBarrierModel,
    TouchCondition,
    similarity_score,
)
from float_sdk.float_api_trading.products.base.options import BarrierOptionBaseModel, BinaryOptionBaseModel, OptionBaseModel, OptionPayoutBaseModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class ExpirationCut(DisplayEnum):
    ALMATY_11_00 = "Almaty 11:00"
    BOGOTA_10_30 = "Bogota 10:30"
    BRUSSELS_12_00 = "Brussels 12:00"
    BUENOS_AIRES_15_00 = "Buenos Aires 15:00"
    BUDAPEST_12_00 = "Budapest 12:00"
    CAIRO_12_00 = "Cairo 12:00"
    HONG_KONG_09_15 = "Hong Kong 09:15"
    HONG_KONG_11_30 = "Hong Kong 11:30"
    JAKARTA_4_15 = "Jakarta 04:15"
    JAKARTA_12_00 = "Jakarta 12:00"
    JAKARTA_14_30 = "Jakarta 14:30"
    JAKARTA_16_15 = "Jakarta 16:15"
    JAKARTA_16_30 = "Jakarta 16:30"
    KUALA_LUMPUR_11_00 = "Kuala Lumpur 11:00"
    KUALA_LUMPUR_15_30 = "Kuala Lumpur 15:30"
    LAGOS_12_00 = "Lagos 12:00"
    LIMA_14_00 = "Lima 14:00"
    LONDON_07_00 = "London 07:00"
    LONDON_08_00 = "London 08:00"
    LONDON_09_00 = "London 09:00"
    LONDON_10_00 = "London 10:00"
    LONDON_10_15 = "London 10:15"
    LONDON_10_30 = "London 10:30"
    LONDON_11_00 = "London 11:00"
    LONDON_12_00 = "London 12:00"
    LONDON_13_00 = "London 13:00"
    LONDON_14_00 = "London 14:00"
    LONDON_15_00 = "London 15:00"
    LONDON_15_30 = "London 15:30"
    LONDON_16_00 = "London 16:00"
    MANILA_11_30 = "Manila 11:30"
    MUMBAI_13_30 = "Mumbai 13:30"
    NEW_YORK_10_00 = "New York 10:00"
    NEW_YORK_11_00 = "New York 11:00"
    NEW_YORK_12_30 = "New York 12:30"
    SAO_PAULO_13_15 = "Sao Paulo 13:15"
    SANTIAGO_10_30 = "Santiago 10:30"
    SEOUL_15_00 = "Seoul 15:00"
    SEOUL_15_30 = "Seoul 15:30"
    SINGAPORE_11_00 = "Singapore 11:00"
    TAIPEI_11_00 = "Taipei 11:00"
    TEL_AVIV_12_00 = "Tel Aviv 12:00"
    TOKYO_12_00 = "Tokyo 12:00"
    TOKYO_14_00 = "Tokyo 14:00"
    TOKYO_15_00 = "Tokyo 15:00"
    TOKYO_15_30 = "Tokyo 15:30"

    def display_names(self) -> dict[str, str]:
        return {ec.value: ec.value for ec in ExpirationCut}


class FXOptionBaseModel(OptionBaseModel):
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX option"
    )
    fixing_source: SettlementRateOptionId | str | SettlementRateOptionModel | SyntheticSettlementRateOptionModel | None = Field(
        default=None,
        title="Fixing Source",
        description="The settlement rate option used to determine the spot fixing rate at expiry for calculating the exercise amount.",
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_OPTIONS


class FXOptionModel(FXOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    semantic_type: Literal["FX_OPTION"] = Field(
        default="FX_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "FX Option",
            "description": "A foreign exchange option (FX option) is a financial derivative that gives the holder the right, but not the obligation, to exchange "
            "a specified amount of one currency for another at a predetermined exchange rate on or before a specified expiration date. These options are used by "
            "investors and companies to hedge against potential adverse movements in exchange rates or to speculate on future currency fluctuations.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_OPTION",
            },
        }


class FXBasketOptionModel(FXOptionBaseModel):
    """
    FX Basket Option Model.

    A vanilla option on a basket of FX pairs, allowing investors to trade the performance
    of a weighted basket of currency pairs with a single strike and expiration.
    """

    product_type: ProductType = Field(
        default=ProductType.FX_BASKET_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    asset: FXBasketModel | None = Field(default=None, title="Asset", description="Basket of FX pairs for the basket option (minimum 2 constituents)")

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement based on the basket performance vs strike price"
    )

    semantic_type: Literal["FX_BASKET_OPTION"] = Field(
        default="FX_BASKET_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Basket Option",
            "description": "An FX basket option is a derivative that gives the holder the right, but not the obligation, to buy or sell a basket of currency pairs at a predetermined strike price on or before expiration.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": {
                    "name": "EM Asia FX Basket",
                    "weightingScheme": "WEIGHT",
                    "constituents": [
                        {"asset": "USDKRW", "weight": 0.4},
                        {"asset": "USDSGD", "weight": 0.3},
                        {"asset": "USDTWD", "weight": 0.3},
                    ],
                    "semanticType": "FX_BASKET",
                },
                "notionalAmount": 10000000,
                "notionalCurrency": "USD",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 100.0,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 250000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {"settlementCurrency": "USD", "semanticType": "CASH_SETTLEMENT_TERMS"},
            },
        }


class FXForwardVolatilityAgreementModel(FXOptionModel):
    product_type: ProductType = Field(
        default=ProductType.FX_FORWARD_VOLATILITY_AGREEMENT,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    strike_fixing_date: date | None = Field(default=None, title="Strike Fixing Date", description="The date on which the strike price is fixed.")
    strike_fixing_time: time | TimeLocationModel | None = Field(
        default=None, title="Strike Fixing Time", description="The time on which the strike price is fixed."
    )
    forward_volatility: float | None = Field(
        default=None, title="Forward Volatility", description="The forward volatility level to be applied on the strike fixing date."
    )

    semantic_type: Literal["FX_FORWARD_VOLATILITY_AGREEMENT"] = Field(
        default="FX_FORWARD_VOLATILITY_AGREEMENT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Forward Volatility Agreement",
            "description": "A Forward Volatility Agreement (FVA) is a financial derivative that allows investors to trade the implied volatility of an underlying "
            "exchange rate over a specified future period. Unlike a standard option, which provides exposure to realized volatility, an FVA settles based on the "
            "implied volatility of the underlying exchange rate at a predetermined future date (the strike fixing date, also known as FVA or step date). The "
            "contract specifies a strike volatility level, a reference option maturity, and a settlement methodology, typically based on the implied volatility "
            "quoted in the options market at expiry. FVAs are used for hedging or speculating on changes in forward volatility surfaces without direct exposure "
            "to directional price movements, making them valuable tools for volatility traders, structured product desks, and macro investors seeking to express "
            "views on term structure dynamics and volatility risk premia.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "10:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "strikeFixingDate": "2022-06-15",
                "strikeFixingTime": "10:00",
                "forwardVolatility": 0.06,
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_FORWARD_VOLATILITY_AGREEMENT",
            },
        }


class FXKnockoutForwardVolatilityAgreementModel(FXOptionModel):
    product_type: ProductType = Field(
        default=ProductType.FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    strike_fixing_date: date | None = Field(default=None, title="Strike Fixing Date", description="The date on which the strike price is fixed.")
    strike_fixing_time: time | TimeLocationModel | None = Field(
        default=None, title="Strike Fixing Time", description="The time on which the strike price is fixed."
    )
    forward_volatility: float | None = Field(
        default=None, title="Forward Volatility", description="The forward volatility level to be applied on the strike fixing date."
    )
    barrier: SingleBarrierModel | DoubleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier event.")

    semantic_type: Literal[
        "FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT",
        # "FX_KNCKOUT_FORWARD_VOLATILITY_AGREEMENT",
    ] = Field(default="FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT", title="Semantic Type", description="The type of resource which is being serialized.")

    class Config:
        json_schema_extra = {
            "title": "FX Knockout Forward Volatility Agreement",
            "description": "A Knockout Forward Volatility Agreement (FVA) is a financial derivative that allows investors to trade the implied volatility of an underlying exchange rate over a specified future period, but with an additional contingency that the option is knocked in or out if the exchange rate hits a specified barrier level. Unlike a standard option, which provides exposure to realized volatility, an FVA settles based on the implied volatility of the underlying exchange rate at a predetermined future date (the strike fixing date, also known as FVA or step date). The contract specifies a strike volatility level, a reference option maturity, and a settlement methodology, typically based on the implied volatility quoted in the options market at expiry. FVAs are used for hedging or speculating on changes in forward volatility surfaces without direct exposure to directional price movements, making them valuable tools for volatility traders, structured product desks, and macro investors seeking to express views on term structure dynamics and volatility risk premia.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "strikeFixingDate": "2022-06-15",
                "strikeFixingTime": "10:00",
                "forwardVolatility": 0.06,
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.3575,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT",
            },
        }


class FXKnockoutModel(BarrierOptionBaseModel):
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX option"
    )
    fixing_source: SettlementRateOptionId | str | SettlementRateOptionModel | SyntheticSettlementRateOptionModel | None = Field(
        default=None,
        title="Fixing Source",
        description="The settlement rate option used to determine the spot fixing rate at expiry for calculating the exercise amount.",
    )
    product_type: ProductType = Field(
        default=ProductType.FX_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["FX_KNOCKOUT"] = Field(
        default="FX_KNOCKOUT", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_OPTIONS

    class Config:
        json_schema_extra = {
            "title": "FX Knockout",
            "description": "An FX knockout (knockin) option is a barrier option that terminates and becomes worthless if the exchange rate hits a specified barrier level during the contract's life. For a knockout option, this means the option is voided if the rate breaches the barrier, with up-and-out or down-and-out structures based on whether the rate moves upward or downward, respectively. Conversely, an FX knock-in option activates only if the barrier is reached, becoming a standard option after the barrier is triggered, with up-and-in or down-and-in variations. These options offer tailored risk exposures and typically have lower premiums than vanilla options due to the barrier feature.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.3575,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_KNOCKOUT",
            },
        }


class FXDoubleKnockoutModel(FXOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_DOUBLE_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barrier: DoubleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier events.")

    semantic_type: Literal["FX_DOUBLE_KNOCKOUT"] = Field(
        default="FX_DOUBLE_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Double Knockout",
            "description": 'A double knockout option is a barrier option that ceases to exist if the underlying FX rate hits either of two specified barrier levels, one above and one below the current rate, at any time during the option\'s life. These barriers create a range, and if the rate moves outside this range (either up or down), the option is "knocked out" and becomes worthless. Conversely, a double knockin option only activates as a standard option if the FX rate breaches one of the two barrier levels, either upward or downward. These options allow for more precise risk control and generally feature lower premiums, as the likelihood of the option being exercised is reduced due to the presence of two knockout/knockin barriers.',
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "callAmount": 127000000,
                "putAmount": 160000000,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "lowerBarrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.3000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "upperBarrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.4000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "DOUBLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                },
                "semanticType": "FX_DOUBLE_KNOCKOUT",
            },
        }


class FXWindowKnockoutModel(FXOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_WINDOW_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier event.")

    semantic_type: Literal["FX_WINDOW_KNOCKOUT"] = Field(
        default="FX_WINDOW_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Window Knockout",
            "description": "A window knockout option is a type of barrier option where the knockout feature applies only during a specified time window within the "
            "life of the option. If the underlying FX rate hits or breaches the barrier during this window, the option ceases to exist. Outside of this window, the "
            "barrier feature does not apply, and the option functions like a standard option. Similarly, a window knockin option activates as a regular option only "
            "if the FX rate reaches the barrier within the designated window. These options offer more flexibility by confining the barrier event to a specific period, "
            "which can lower premiums and better align with certain risk management strategies.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "callAmount": 127000000,
                "putAmount": 160000000,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-05-15",
                        "eventPeriodStartDate": "2024-07-15",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.3575,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_WINDOW_KNOCKOUT",
            },
        }


class FXWindowDoubleKnockoutModel(FXOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_WINDOW_DOUBLE_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barrier: DoubleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier event.")

    semantic_type: Literal["FX_DOUBLE_WINDOW_KNOCKOUT"] = Field(
        default="FX_DOUBLE_WINDOW_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Window Double Knockout",
            "description": "A window double knockout option is a type of barrier option that becomes void if the underlying FX rate hits either of two predefined "
            "barrier levels (one above and one below the current rate) during a specified time window within the option's life. If the rate breaches either barrier "
            'within this window, the option is "knocked out" and ceases to exist. Outside the window, the barriers are inactive, and the option behaves like a '
            "vanilla option. These options allow for precise control over exposure within a certain range and timeframe, generally offering lower premiums due to "
            "the presence of both the time-limited and double-barrier features.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalAmount": 127000000,
                "notionalCurrency": "EUR",
                "callAmount": 127000000,
                "putAmount": 160000000,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "eventType": "DOUBLE_KNOCK_OUT",
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-05-15",
                        "eventPeriodStartDate": "2024-07-15",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "lowerBarrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.3000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "upperBarrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.4000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "DOUBLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_DOUBLE_WINDOW_KNOCKOUT",
            },
        }


class FXBinaryOptionBaseModel(BinaryOptionBaseModel):
    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_OPTIONS


class FXBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX binary option", json_schema_extra={"readOnly": True}
    )

    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier event.")

    ## These fields are deprecated
    #
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event", exclude=True)
    option_type: OptionType | None = Field(
        default=None, title="Option Type", description="Claim type of the option (e.g. Call, Put, Binary, etc.)", exclude=True
    )
    strike_price: float | None = Field(default=None, title="Strike Price", description="Price at which the binary payout is triggered.", exclude=True)
    #
    ## End deprecated fields

    semantic_type: Literal["FX_BINARY_OPTION"] = Field(
        default="FX_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Binary Option",
            "description": "A binary option, often synonymous with a binary option, is a type of exotic option that offers a fixed payout if a specified condition "
            "is met by the underlying asset at expiration. The condition typically involves the asset's price crossing a certain strike level. If the condition is "
            "fulfilled, the holder receives the fixed payout, regardless of how far beyond the strike the asset's price has moved; if the condition is not met, "
            'the option expires worthless. Binary options are commonly used in structured products and hedging strategies due to their simple "all-or-nothing" '
            "payout structure and are popular in markets like foreign exchange and equity derivatives. They provide an efficient way to gain leveraged exposure "
            "to directional moves with clearly defined risk and reward profiles.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.1200,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-04-15",
                        "eventPeriodStartDate": "2024-07-15",
                        "rateOption": "WM_REUTERS_MID_WMR03_GBLO_1600",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_BINARY_OPTION",
            },
        }


class FXBinaryKnockoutModel(FXBinaryOptionBaseModel):
    """
    FX Binary Knockout

    A binary option with a knockout barrier that can terminate the option before expiry.
    Combines a trigger barrier (European - observed at expiration) with a knockout barrier
    (continuous observation - American touch).

    The trigger barrier determines the payout condition at expiry (e.g., EUR >= 1.1200).
    The knockout barrier terminates the option if touched before expiry (e.g., EUR touches 1.1500).

    Based on FpML 5.5+ barrier structures and ISDA 2005 FX Barrier Options Supplement.
    Supports single or double knockout barriers with continuous (ANYTIME) observation.
    """

    product_type: ProductType = Field(
        default=ProductType.FX_BINARY_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX binary knockout option"
    )

    barrier: SingleBarrierModel | None = Field(
        default=None,
        title="Trigger Barrier",
        description="The trigger barrier observed at expiration (European observation). Determines if payout condition is met at expiry.",
    )

    knockout_barrier: SingleBarrierModel | DoubleBarrierModel | None = Field(
        default=None,
        title="Knockout Barrier",
        description="The knockout barrier observed continuously (American/touch observation). Terminates the option if touched during observation period.",
    )

    semantic_type: Literal["FX_BINARY_KNOCKOUT"] = Field(
        default="FX_BINARY_KNOCKOUT",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Binary Knockout",
            "description": "A binary option with both a trigger barrier (European) and a knockout barrier (continuous observation). "
            "The trigger determines the payout condition at expiry, while the knockout can terminate the option early if touched. "
            "Common structure: pays fixed amount if spot >= trigger at expiry AND spot hasn't touched knockout level during observation period.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.1200,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventTimeType": "CLOSING",
                        "eventPeriodEndDate": "2024-07-15",
                        "rateOption": "WM_REUTERS_MID_WMR03_GBLO_1600",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "knockoutBarrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.1500,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventTimeType": "ANYTIME",
                        "eventPeriodStartDate": "2024-04-15",
                        "eventPeriodEndDate": "2024-07-15",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_BINARY_KNOCKOUT",
            },
        }


class FXDoubleBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        ProductType.FX_DOUBLE_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barrier: DoubleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier event.")

    semantic_type: Literal["FX_DOUBLE_BINARY_OPTION"] = Field(
        default="FX_DOUBLE_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Double Binary Option",
            "description": "A binary option, often synonymous with a binary option, is a type of exotic option that offers a fixed payout if a specified condition "
            "is met by the underlying asset at expiration. The condition typically involves the asset's price crossing a certain strike level. If the condition is "
            "fulfilled, the holder receives the fixed payout, regardless of how far beyond the strike the asset's price has moved; if the condition is not met, the "
            'option expires worthless. Binary options are commonly used in structured products and hedging strategies due to their simple "all-or-nothing" payout '
            "structure and are popular in markets like foreign exchange and equity derivatives. They provide an efficient way to gain leveraged exposure to "
            "directional moves with clearly defined risk and reward profiles.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionType": "BINARY",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-07-15",
                        "eventPeriodEndDate": "2024-07-15",
                        "rateOption": "WM_REUTERS_MID_WMR03_GBLO_1600",
                        "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "lowerBarrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.3000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "upperBarrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.4000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_DOUBLE_BINARY_OPTION",
            },
        }


class FXOneTouchBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_ONE_TOUCH_BINARY_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(default=None, title="Asset", description="The exchange rate or currency pair")

    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The barrier level that must be touched (or not touched) for payout")

    payout_style: PayoutStyle | None = Field(
        default=None,
        title="Payout Style",
        description="Per ISDA 2005 FX Barrier Option Definitions, specifies the settlement timing when the barrier is triggered. IMMEDIATE: settlement on spot date (T+2) from trigger date. DEFERRED: settlement deferred to the original value date (T+2 from expiry). Only applicable to one-touch options; not applicable to no-touch options.",
    )

    @computed_field(title="Touch Condition", description="Whether this is a touch (knock-in) or no-touch (knock-out) option, computed from barrier event_type")
    @property
    def touch_condition(self) -> TouchCondition | None:
        """Computed from barrier.barrier_terms.event_type"""
        if self.barrier and self.barrier.barrier_terms:
            return TouchCondition.from_knock_type(self.barrier.barrier_terms.event_type)
        return None

    @computed_field(
        title="Event Type",
        description="The barrier event type (ONE_TOUCH_BINARY or NO_TOUCH_BINARY), computed from barrier",
    )
    @property
    def event_type(self) -> BarrierEventType | None:
        """Computed from touch_condition"""
        tc = self.touch_condition
        if tc is None:
            return None
        return BarrierEventType.ONE_TOUCH_BINARY if tc == TouchCondition.TOUCH else BarrierEventType.NO_TOUCH_BINARY

    semantic_type: Literal["FX_ONE_TOUCH_BINARY_OPTION"] = Field(
        default="FX_ONE_TOUCH_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX One Touch Binary Option",
            "description": "A one-touch binary option pays a fixed amount if the underlying exchange rate "
            "touches a specified barrier level at any time during the observation period. A no-touch "
            "binary option pays a fixed amount if the barrier is NOT touched.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "barrier": {
                    "asset": "EURUSD",
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.1200,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-04-15",
                        "eventPeriodEndDate": "2024-07-15",
                        "eventTimeType": "ANYTIME",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 250000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "payoutStyle": "IMMEDIATE",
                "touchCondition": "TOUCH",
                "eventType": "ONE_TOUCH_BINARY",
                "semanticType": "FX_ONE_TOUCH_BINARY_OPTION",
            },
        }


class FXDoubleOneTouchBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_DOUBLE_ONE_TOUCH_BINARY_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    barrier: DoubleBarrierModel | None = Field(
        default=None, title="Barrier", description="The barrier conditions which must be touched (or not touched) for payout"
    )

    payout_style: PayoutStyle | None = Field(
        default=None,
        title="Payout Style",
        description="Per ISDA 2005 FX Barrier Option Definitions, specifies the settlement timing when the barrier is triggered. IMMEDIATE: settlement on spot date (T+2) from trigger date. DEFERRED: settlement deferred to the original value date (T+2 from expiry). Only applicable to one-touch options; not applicable to no-touch options.",
    )

    @computed_field(
        title="Touch Condition",
        description="Whether this is a double-one-touch or double-no-touch option, computed from barrier event_type",
    )
    @property
    def touch_condition(self) -> TouchCondition | None:
        """Computed from barrier.lower_barrier_terms.event_type"""
        if self.barrier and self.barrier.lower_barrier_terms:
            return TouchCondition.from_knock_type(self.barrier.lower_barrier_terms.event_type)
        return None

    @computed_field(
        title="Event Type",
        description="The barrier event type (DOUBLE_ONE_TOUCH_BINARY or DOUBLE_NO_TOUCH_BINARY)",
    )
    @property
    def event_type(self) -> BarrierEventType | None:
        """Computed from touch_condition"""
        tc = self.touch_condition
        if tc is None:
            return None
        return BarrierEventType.DOUBLE_ONE_TOUCH_BINARY if tc == TouchCondition.TOUCH else BarrierEventType.DOUBLE_NO_TOUCH_BINARY

    semantic_type: Literal["FX_DOUBLE_ONE_TOUCH_BINARY_OPTION"] = Field(
        default="FX_DOUBLE_ONE_TOUCH_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Double One Touch Binary Option",
            "description": "A double one-touch binary option pays a fixed amount if either of two barrier "
            "levels is touched. A double no-touch pays if neither barrier is touched.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "barrier": {
                    "asset": "EURUSD",
                    "barrierDeterminationAgent": "PARTY_1",
                    "lowerBarrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_LESS",
                        "level": 1.0500,
                        "direction": "DOWN",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "upperBarrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1.1500,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-04-15",
                        "eventPeriodEndDate": "2024-07-15",
                        "eventTimeType": "ANYTIME",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "DOUBLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 150000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "payoutStyle": "DEFERRED",
                "touchCondition": "TOUCH",
                "eventType": "DOUBLE_ONE_TOUCH_BINARY",
                "semanticType": "FX_DOUBLE_ONE_TOUCH_BINARY_OPTION",
            },
        }


class FXMultiBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_MULTI_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX binary option"
    )

    barriers: List[SingleBarrierModel | DoubleBarrierModel] | None = Field(default=None, title="Barrier", description="The terms for the each barrier event.")

    semantic_type: Literal["FX_MULTI_BINARY_OPTION"] = Field(
        default="FX_MULTI_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Multi Binary Option",
            "description": "A binary option with multiple barriers, is a type of exotic option that offers a fixed payout if a set of specified conditions "
            "are met by the underlying asset at expiration or over a defined observation period. The condition typically involves the asset's price crossing "
            "a certain strike level. If the condition is fulfilled, the holder receives the fixed payout, regardless of how far beyond the strike the asset's "
            "price has moved; if the condition is not met, the option expires worthless.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {"time": "16:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barriers": [
                    {
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodStartDate": "2024-07-15",
                            "eventPeriodEndDate": "2024-07-15",
                            "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.3000,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                    },
                    {
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodStartDate": "2024-04-15",
                            "eventPeriodEndDate": "2024-07-15",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_OUT",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.3500,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                    },
                ],
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_DOUBLE_BINARY_OPTION",
            },
        }


class FXDualBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_DUAL_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barriers: list[SingleBarrierModel | DoubleBarrierModel] | None = Field(
        default=None, title="Barriers", description="The terms of the barrier event for each FX cross currency pair."
    )
    semantic_type: Literal["FX_DUAL_BINARY_OPTION"] = Field(
        default="FX_DUAL_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Dual Binary Option",
            "description": "A dual binary option is a type of exotic option that offers a fixed payout if a specified condition is met by the two underlying assets "
            "at expiration. If the condition is not met, the option expires worthless. Dual binary options are commonly used in structured products and hedging "
            'strategies due to their simple "all-or-nothing" payout structure and are popular in markets like foreign exchange and equity derivatives. They provide '
            "an efficient way to gain leveraged exposure to directional moves with clearly defined risk and reward profiles.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionType": "BINARY",
                "optionStyle": "EUROPEAN",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barriers": [
                    {
                        "asset": "GBPUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-07-15",
                            "eventPeriodStartDate": "2024-07-15",
                            "rateSource": "GBPUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.3575,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "SINGLE_BARRIER_MODEL",
                    },
                    {
                        "asset": "EURUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-07-15",
                            "eventPeriodStartDate": "2024-07-15",
                            "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "barrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.0875,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "SINGLE_BARRIER_MODEL",
                    },
                ],
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_DUAL_BINARY_OPTION",
            },
        }


class DualDoubleBinaryLegModel(DataModel):  # DEPRECATED
    asset: str | CurrencyId | ExchangeRateId | None = Field(default=None, title="Asset", description="The asset to which the barrier applies.")
    lower_barrier_terms: None = Field(default=None, title="Lower Barrier Terms", description="The terms for the lower barrier event.")
    upper_barrier_terms: None = Field(default=None, title="Upper Barrier Terms", description="The terms for the upper barrier event.")

    semantic_type: Literal["DUAL_DOUBLE_BINARY_LEG"] = Field(default="DUAL_DOUBLE_BINARY_LEG", title="Semantic Type")


class FXDualDoubleBinaryOptionModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_DUAL_DOUBLE_BINARY_OPTION,
        title="Product Type",
        description="The type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barriers: list[DoubleBarrierModel] | None = Field(
        default=None, title="Barriers", description="The terms of the barrier event for each FX cross currency pair."
    )

    semantic_type: Literal["FX_DUAL_DOUBLE_BINARY_OPTION"] = Field(
        default="FX_DUAL_DOUBLE_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Dual Double Binary Option",
            "description": "A dual double binary option is a type of exotic option that offers a fixed payout if a two barrier conditions are met with respect to each "
            "asset at expiration. If the condition is not met, the option expires worthless. Dual binary options are commonly used in structured products and hedging "
            'strategies due to their simple "all-or-nothing" payout structure and are popular in markets like foreign exchange and equity derivatives. They provide an '
            "efficient way to gain leveraged exposure to directional moves with clearly defined risk and reward profiles.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionStyle": "EUROPEAN",
                "optionType": "BINARY",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barriers": [
                    {
                        "asset": "GBPUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-03-15",
                            "eventPeriodStartDate": "2024-03-15",
                            "rateSource": "GBPUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "lowerBarrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.3000,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "upperBarrierTerms": {
                            "eventType": "KNOCK_OUT",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.4000,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "DOUBLE_BARRIER_MODEL",
                    },
                    {
                        "asset": "EURUSD",
                        "barrierDeterminationAgent": "PARTY_1",
                        "observationTerms": {
                            "eventPeriodEndDate": "2024-03-15",
                            "eventPeriodStartDate": "2024-03-15",
                            "rateSource": "EURUSD_WM_REUTERS_MID_WMR03_GBLO_1600",
                            "semanticType": "OBSERVATION_TERMS",
                        },
                        "lowerBarrierTerms": {
                            "eventType": "KNOCK_IN",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.0500,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "upperBarrierTerms": {
                            "eventType": "KNOCK_OUT",
                            "triggerType": "EQUAL_OR_GREATER",
                            "level": 1.0557,
                            "direction": "UP",
                            "semanticType": "BARRIER_TERMS",
                        },
                        "semanticType": "DOUBLE_BARRIER_MODEL",
                    },
                ],
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_DUAL_DOUBLE_BINARY_OPTION",
            },
        }


class FXVolatilityKnockoutModel(FXOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_VOLATILITY_KNOCKOUT, title="Product Type", description="The type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The barrier terms which define the knockin or knockout event.")

    semantic_type: Literal["FX_VOLATILITY_KNOCKOUT"] = Field(
        default="FX_VOLATILITY_KNOCKOUT",
        title="Semantic Type",
        description="The type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Volatility Knockout",
            "description": "An FX volatility knockout (or knockin) option is a type of exotic foreign exchange option whose activation (knockin) or deactivation "
            "(knockout) depends on the realized volatility of the underlying currency pair. For a volatility knockout option, the contract becomes void if the "
            "volatility of the underlying currency crosses a pre-defined threshold during the option's life. In a knockin version, the option is triggered and "
            "becomes active only if the volatility crosses the barrier, allowing the holder to hedge or speculate based on market volatility behavior without "
            "affecting the asset's price directly.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "EURUSD",
                "notionalCurrency": "EUR",
                "notionalAmount": 10e6,
                "optionType": "CALL",
                "optionPayout": "VANILLA",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1.27354,
                "effectiveDate": "2022-03-15",
                "expirationDate": "2023-03-15",
                "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "referenceVolatility": 0.2,
                        "direction": "UP",
                        "semanticType": "VOLATILITY_BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {"settlementType": "PHYSICAL", "settlementDate": "2023-03-17", "semanticType": "PHYSICAL_SETTLEMENT_TERMS"},
                "semanticType": "FX_VOLATILITY_KNOCKOUT",
            },
        }


class FXBinaryVolatilityKnockoutModel(FXBinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_BINARY_VOLATILITY_KNOCKOUT,
        title="Product Type",
        description="The type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX binary volatility knockout option"
    )

    barrier: SingleBarrierModel | None = Field(
        default=None,
        title="Trigger Barrier",
        description="The trigger barrier observed at expiration (European observation). Determines if payout condition is met at expiry.",
    )

    knockout_barrier: SingleBarrierModel | None = Field(
        default=None,
        title="Knockout Barrier",
        description="The volatility knockout barrier observed continuously. Terminates the option if volatility hits the barrier level.",
    )

    semantic_type: Literal["FX_BINARY_VOLATILITY_KNOCKOUT"] = Field(default="FX_BINARY_VOLATILITY_KNOCKOUT", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "FX Binary Volatility Knockout",
            "description": "A binary volatility knockout option is a specialized exotic option that provides a fixed payout if the underlying asset's volatility "
            "either remains below or exceeds a certain level during the option's life or at expiration (as defined by the observation window). If the realized "
            "volatility hits or crosses a pre-defined volatility barrier, the option is deactivated (knocked out) and becomes worthless. The binary nature means "
            "the payout is all-or-nothing, depending solely on whether the volatility barrier is breached, making it a useful tool for traders aiming to hedge or "
            "speculate based on volatility movements rather than price.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionPayout": "BINARY",
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "terminationDate": "2024-07-15",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "asset": "EURUSD",
                    "barrierDeterminationAgent": "PARTY_1",
                    "observationTerms": {
                        "eventPeriodEndDate": "2024-03-15",
                        "eventPeriodStartDate": "2024-03-15",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "referenceVolatility": 0.2,
                        "direction": "UP",
                        "semanticType": "VOLATILITY_BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementAmount": 1000000,
                    "settlementCurrency": "USD",
                    "settlementType": "CASH",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_BINARY_VOLATILITY_KNOCKOUT",
            },
        }


class FXOptionLegModel(DataModel):
    asset: ExchangeRateModel | str | ExchangeRateId | None = Field(
        default=None, title="Asset", description="The exchange rate or currency pair for the FX option"
    )
    notional_amount: float | None = Field(default=None, title="Notional Amount", description="The notional amount of the option")
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Notional Currency", description="The currency of the notional amount"
    )
    option_type: OptionType | None = Field(default=None, title="Option Type", description="Claim type of the option (e.g. Call, Put, etc.)")
    option_style: OptionStyle | None = Field(default=None, title="Option Style", description="Exercise style of option (e.g. European, American, etc.)")
    strike_price: float | None = Field(
        default=None, title="Strike Price", description="Price at which the buyer is obliged to buy or sell the underlying asset."
    )

    effective_date: date | BusinessDateModel | None = Field(
        default=None, title="Effective Date", description="The date on which the event contractually takes effect"
    )
    expiration_date: date | BusinessDateModel | RelativeDateModel | None = Field(
        default=None,
        title="Expiration Date",
        description="The last day of the terms of the trade. This date may be subject to adjustments in accordance with the business day convention. It can also be specified in relation to another scheduled date (e.g. the last payment date).",
    )
    expiration_time: time | TimeLocationModel | None = Field(default=None, title="Expiration Time", description="Expiration time of option")

    fixing_source: SettlementRateOptionId | str | SettlementRateOptionModel | SyntheticSettlementRateOptionModel | None = Field(
        default=None,
        title="Fixing Source",
        description="The settlement rate option used to determine the spot fixing rate at expiry for calculating the exercise amount.",
    )

    semantic_type: Literal["FX_OPTION_LEG"] = Field(default="FX_OPTION_LEG", title="Semantic Type", description="The type of financial instrument.")

    @field_validator("expiration_time", mode="before")
    def datetime_to_time(cls, v):
        if isinstance(v, datetime):
            return v.time()
        return v

    def match_score(self, other: "FXOptionLegModel") -> float:
        score = 1 if self.asset == other.asset else 0
        score += 1 if self.option_style == other.option_style else 0

        level_score = similarity_score(self.strike_price, other.strike_price)

        return score + level_score


class FXWorstOfOptionModel(OptionPayoutBaseModel):
    product_type: ProductType = Field(
        default=ProductType.FX_WORST_OF_OPTION, title="Product Type", description="The type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    option_style: OptionStyle | None = Field(default=None, title="Option Style", description="The style of the option.")
    option_payout: OptionPayout | None = Field(
        default=None, title="Option Payout", description="The payout style of the option (e.g. Vanilla, Binary, etc.)", json_schema_extra={"readOnly": True}
    )
    notional_amount: float | None = Field(default=None, title="Notional Amount", description="The notional amount of the option.")
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Notional Currency", description="The currency of the notional amount."
    )
    legs: List[FXOptionLegModel] | None = Field(default=None, title="Legs", description="The legs of the option.")

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.FOREIGN_EXCHANGE

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.FX_OPTIONS

    semantic_type: Literal["FX_WORST_OF_OPTION"] = Field(
        default="FX_WORST_OF_OPTION", title="Semantic Type", description="The type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "FX Worst of Option",
            "description": "An FX volatility knockout (or knockin) option is a type of exotic foreign exchange option whose activation (knockin) or deactivation (knockout) depends on the realized volatility of the underlying currency pair. For a volatility knockout option, the contract becomes void if the volatility of the underlying currency crosses a pre-defined threshold during the option's life. In a knockin version, the option is triggered and becomes active only if the volatility crosses the barrier, allowing the holder to hedge or speculate based on market volatility behavior without affecting the asset's price directly.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "productType": "FX_WORST_OF_OPTION",
                "eventType": "KNOCK_OUT",
                "legs": [
                    {
                        "asset": "EURUSD",
                        "notionalCurrency": "EUR",
                        "notionalAmount": 127000000,
                        "optionType": "CALL",
                        "optionStyle": "EUROPEAN",
                        "strikePrice": 1.0500,
                        "effectiveDate": "2022-03-15",
                        "expirationDate": "2023-03-15",
                        "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                    },
                    {
                        "asset": "GBPUSD",
                        "notionalCurrency": "GBP",
                        "notionalAmount": 100000000,
                        "optionType": "CALL",
                        "optionStyle": "EUROPEAN",
                        "strikePrice": 1.27354,
                        "effectiveDate": "2022-03-15",
                        "expirationDate": "2023-03-15",
                        "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                    },
                ],
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_WORST_OF_OPTION",
            },
        }


class FXKnockoutLegModel(FXOptionLegModel):
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier Terms", description="The terms for the knock event.")
    semantic_type: Literal["FX_KNOCKOUT_LEG"] = Field(default="FX_KNOCKOUT_LEG", title="Semantic Type", description="The type of financial instrument.")


class FXWorstOfKnockoutModel(FXWorstOfOptionModel):
    product_type: ProductType = Field(
        default=ProductType.FX_WORST_OF_KNOCKOUT, title="Product Type", description="The type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    legs: List[FXKnockoutLegModel] | None = Field(default=None, title="Legs", description="The option legs which define the worst of best of payout.")

    semantic_type: Literal["FX_WORST_OF_KNOCKOUT"] = Field(
        default="FX_WORST_OF_KNOCKOUT",
        title="Semantic Type",
        description="The type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "FX Worst of Knockout",
            "description": "An FX volatility knockout (or knockin) option is a type of exotic foreign exchange option whose activation (knockin) or deactivation (knockout) depends on the realized volatility of the underlying currency pair. For a volatility knockout option, the contract becomes void if the volatility of the underlying currency crosses a pre-defined threshold during the option's life. In a knockin version, the option is triggered and becomes active only if the volatility crosses the barrier, allowing the holder to hedge or speculate based on market volatility behavior without affecting the asset's price directly.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "premiumTerms": {
                    "premium": 6250000,
                    "premiumCurrency": "GBP",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2022-03-15",
                    "semanticType": "PREMIUM_TERMS",
                },
                "productType": "FX_WORST_OF_KNOCKOUT",
                "legs": [
                    {
                        "asset": "GBPUSD",
                        "notionalCurrency": "GBP",
                        "notionalAmount": 100e6,
                        "optionType": "CALL",
                        "optionStyle": "EUROPEAN",
                        "strikePrice": 1.27354,
                        "effectiveDate": "2022-03-15",
                        "expirationDate": "2023-03-15",
                        "expirationTime": {"time": "10:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "observationTerms": {
                                "eventPeriodEndDate": "2024-03-15",
                                "eventPeriodStartDate": "2024-03-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 1.3575,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                    },
                    {
                        "asset": "EURUSD",
                        "notionalCurrency": "EUR",
                        "notionalAmount": 100e6,
                        "optionType": "CALL",
                        "optionStyle": "EUROPEAN",
                        "strikePrice": 1.0783,
                        "effectiveDate": "2022-03-15",
                        "expirationDate": "2023-03-15",
                        "expirationTime": {"time": "10:00", "location": "USNY", "semanticType": "TIME_LOCATION"},
                        "barrier": {
                            "barrierDeterminationAgent": "PARTY_1",
                            "observationTerms": {
                                "eventPeriodEndDate": "2024-03-15",
                                "eventPeriodStartDate": "2024-03-15",
                                "semanticType": "OBSERVATION_TERMS",
                            },
                            "barrierTerms": {
                                "eventType": "KNOCK_OUT",
                                "triggerType": "EQUAL_OR_GREATER",
                                "level": 1.0603,
                                "direction": "UP",
                                "semanticType": "BARRIER_TERMS",
                            },
                            "semanticType": "SINGLE_BARRIER_MODEL",
                        },
                    },
                ],
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2023-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "semanticType": "FX_WORST_OF_KNOCKOUT",
            },
        }
