#!/usr/bin/env python
# pyright: basic

"""
Settlement Terms Models

"""

from datetime import date
from enum import Enum
from typing import Annotated, Literal, Optional, Union

from pydantic import Field, field_validator

from float_sdk.float_api.assets.base.settlement import SettlementType
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.rates.rates import RateSourceModel, SettlementRateOptionModel, SyntheticSettlementRateOptionModel
from float_sdk.float_api.base.references import CurrencyId, RateSourceId, SettlementRateOptionId
from float_sdk.float_api.datetime.conventions import BusinessDayConvention
from float_sdk.float_api.locations.business_centers import BusinessCenter
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DeliveryType(DisplayEnum):
    """
    The enumeration values to specify how the option is to be settled when exercised.

    Attributes
    ----------
    DELIVERABLE : A deliverable FX transaction is one in which each party is obligated to deliver the
        full notional amount of the agreed currency to the other party on the settlement date.
    NON_DELIVERABLE : A non-deliverable FX transaction is one in which no exchange of principal amounts
        takes place. Instead, the transaction is settled by a single net cash payment.
    """

    DELIVERABLE = "DELIVERABLE"  # Deprecated, see below
    NON_DELIVERABLE = "NON_DELIVERABLE"  # Deprecated, see below

    def display_names(self) -> dict[str, str]:
        return {"DELIVERABLE": "Deliverable", "NON_DELIVERABLE": "Non Deliverable"}


class TransferSettlement(Enum):
    """
    The enumeration values to specify how the transfer will settle, e.g. DvP.

    Attributes
    ----------
    DELIVERY_VERSUS_DELIVERY : Simultaneous transfer of two assets, typically securities, as a way to avoid settlement risk.
    DELIVERY_VERSUS_PAYMENT : Settlement in which the transfer of the asset and the cash settlement are simultaneous.
    PAYMENT_VERSUS_PAYMENT : Simultaneous transfer of cashflows.
    NOT_CENTRAL_SETTLEMENT : No central settlement.

    """

    DELIVERY_VERSUS_DELIVERY = "DELIVERY_VERSUS_DELIVERY"
    DELIVERY_VERSUS_PAYMENT = "DELIVERY_VERSUS_PAYMENT"
    PAYMENT_VERSUS_PAYMENT = "PAYMENT_VERSUS_PAYMENT"
    NOT_CENTRAL_SETTLEMENT = "NOT_CENTRAL_SETTLEMENT"


class SettlementCentre(Enum):
    """
    Defines the settlement centre for a securities transaction.


    Attributes
    ----------
    EUROCLEAR_BANK : Euroclear Bank
    CLEARSTREAM_BANKING_LUXEMBOURG : ClearStream Banking Luxembourg

    """

    EUROCLEAR_BANK = "EUROCLEAR_BANK"
    CLEARSTREAM_BANKING_LUXEMBOURG = "CLEARSTREAM_BANKIG_LUXEMBOURG"


class StandardSettlementStyle(Enum):
    """
    The enumerated values to specify whether a trade is settling using standard settlement instructions as well as whether it is a candidate for settlement netting.


    Attributes
    ----------
    STANDARD : This trade will settle using standard predetermined funds settlement instructions.
    NET : This trade is a candidate for settlement netting.
    STANDARD_AND_NET : This trade will settle using standard predetermined funds settlement instructions and is a candidate for settlement netting.
    PAIR_AND_NET : These trades have been paired and are a candidate for settlement netting.

    """

    NET = "NET"
    STANDARD = "STANDARD"
    STANDARD_AND_NET = "STANDARD_AND_NET"
    PAIR_AND_NET = "PAIR_AND_NET"


class PremiumTermsModel(DataModel):
    premium: float | None = Field(default=None, title="Premium", description="The premium for the trade")
    premium_currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Premium Currency", description="Currency of the premium")
    premium_payment_date: date | None = Field(default=None, title="Premium Payment Date", description="Payment date for premium transfer.")
    premium_payer: CounterpartyRole | None = Field(default=None, title="Premium Payer", description="Party which is paying the premium")

    semantic_type: Literal["PREMIUM_TERMS"] = Field(default="PREMIUM_TERMS", title="Semantic Type")


class TerminationFeeTermsModel(DataModel):
    termination_fee: float | None = Field(default=None, title="Termination Fee", description="The termination fee for the trade")
    termination_fee_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Termination Fee Currency", description="Currency of the termination fee"
    )
    termination_fee_payment_date: date | None = Field(
        default=None, title="Termination Fee Payment Date", description="Payment date for termination fee transfer."
    )
    termination_fee_payer: CounterpartyRole | None = Field(default=None, title="Termination Fee Payer", description="Party which is paying the termination fee")

    semantic_type: Literal["TERMINATION_FEE_TERMS"] = Field(default="TERMINATION_FEE_TERMS", title="Semantic Type")


class SettlementTermsBaseModel(DataModel):
    """
    Settlement Terms Base
    """

    settlement_date: Optional[date] = Field(
        default=None,
        title="Settlement Date",
        description="Date on which the settlement amount will be paid, subject to adjustment in accordance with any applicable business day convention.",
    )
    settlement_business_days: BusinessCenter | list[BusinessCenter] | None = Field(
        default=None,
        title="Settlement Business Days",
        description="Business day center(s) for settlement date adjustments.",
    )
    settlement_business_day_convention: BusinessDayConvention | None = Field(
        default=None,
        title="Settlement Business Day Convention",
        description="Business day convention for settlement date adjustments.",
    )


class SettlementTermsModel(SettlementTermsBaseModel):
    """
    Settlement Terms

    Defines the settlement terms which apply to transfers of cash or securities
    to satisfy obligations around trading events. For example, delivery versus
    payment of a securities execution, or settlement of option premium or exercies.
    """

    settlement_currency: CurrencyId | str | None = Field(default=None, title="Settlement Currency", description="Currency in which the settlement occurs.")
    settlement_amount: float | None = Field(default=None, title="Settlement Amount", description="Amount to be settled in settlement currency.")

    settlement_type: SettlementType | None = Field(
        default=None, title="Settlement Type", description="Whether the settlement is cash, physical, by election, ..."
    )
    settlement_centre: SettlementCentre | None = Field(
        default=None, title="Settlement Centre", description="Optional settlement centre as an enumerated list: Euroclear, Clearstream."
    )
    transfer_settlement_type: TransferSettlement | None = Field(
        default=None, title="Transfer Settlement", description="The qualification as to how the transfer will settle, e.g. DvP."
    )
    standard_settlement_style: StandardSettlementStyle | None = Field(default=None, title="Standard Settlement Style", description="Settlement Style.")

    semantic_type: Literal["SETTLEMENT_TERMS"] = Field(default="SETTLEMENT_TERMS", title="Semantic Type")


class CashSettlementMethod(DisplayEnum):
    """
    Defines the different cash settlement methods for a product where cash settlement is applicable.

    Each member corresponds to an ISDA-defined cash settlement method used for the determination
    of the applicable cash settlement amount (see 2006 ISDA Definitions, Section 18.3 and
    2021 ISDA Definitions, Section 18.2 where referenced).

    Members
    -------
    CASH_PRICE_METHOD
        An ISDA defined cash settlement method used for the determination of the applicable cash
        settlement amount. Defined in the 2006 ISDA Definitions, Section 18.3(a).
    CASH_PRICE_ALTERNATE_METHOD
        ISDA defined cash settlement method as described in 2006 ISDA Definitions, Section 18.3(b).
    PAR_YIELD_CURVE_ADJUSTED_METHOD
        ISDA defined cash settlement method as described in 2006 ISDA Definitions, Section 18.3(c).
    ZERO_COUPON_YIELD_ADJUSTED_METHOD
        ISDA defined cash settlement method as described in 2006 ISDA Definitions, Section 18.3(d).
    PAR_YIELD_CURVE_UNADJUSTED_METHOD
        ISDA defined cash settlement method as described in 2006 ISDA Definitions, Section 18.3(e).
    CROSS_CURRENCY_METHOD
        ISDA defined cash settlement method as described in 2006 ISDA Definitions, Section 18.3(f)
        (published in Supplement number 23).
    COLLATERALIZED_CASH_PRICE_METHOD
        ISDA defined (yield curve) cash settlement method as described in 2006 ISDA Definitions,
        Section 18.3(g) (published in Supplement number 28) and in the 2021 ISDA Definitions,
        Section 18.2.6.
    MID_MARKET_INDICATIVE_QUOTATIONS
        ISDA defined cash settlement method described in the 2021 ISDA Definitions, Section 18.2.1.
    MID_MARKET_INDICATIVE_QUOTATIONS_ALTERNATE
        ISDA defined cash settlement method described in the 2021 ISDA Definitions, Section 18.2.2.
    MID_MARKET_CALCULATION_AGENT_DETERMINATION
        ISDA defined cash settlement method described in the 2021 ISDA Definitions, Section 18.2.3.
    REPLACEMENT_VALUE_FIRM_QUOTATIONS
        ISDA defined cash settlement method described in the 2021 ISDA Definitions, Section 18.2.4.
    REPLACEMENT_VALUE_CALCULATION_AGENT_DETERMINATION
        ISDA defined cash settlement method described in the 2021 ISDA Definitions, Section 18.2.5.
    """

    CASH_PRICE_METHOD = "CASH_PRICE_METHOD"
    CASH_PRICE_ALTERNATE_METHOD = "CASH_PRICE_ALTERNATE_METHOD"
    PAR_YIELD_CURVE_ADJUSTED_METHOD = "PAR_YIELD_CURVE_ADJUSTED_METHOD"
    ZERO_COUPON_YIELD_ADJUSTED_METHOD = "ZERO_COUPON_YIELD_ADJUSTED_METHOD"
    PAR_YIELD_CURVE_UNADJUSTED_METHOD = "PAR_YIELD_CURVE_UNADJUSTED_METHOD"
    CROSS_CURRENCY_METHOD = "CROSS_CURRENCY_METHOD"
    COLLATERALIZED_CASH_PRICE_METHOD = "COLLATERALIZED_CASH_PRICE_METHOD"
    MID_MARKET_INDICATIVE_QUOTATIONS = "MID_MARKET_INDICATIVE_QUOTATIONS"
    MID_MARKET_INDICATIVE_QUOTATIONS_ALTERNATE = "MID_MARKET_INDICATIVE_QUOTATIONS_ALTERNATE"
    MID_MARKET_CALCULATION_AGENT_DETERMINATION = "MID_MARKET_CALCULATION_AGENT_DETERMINATION"
    REPLACEMENT_VALUE_FIRM_QUOTATIONS = "REPLACEMENT_VALUE_FIRM_QUOTATIONS"
    REPLACEMENT_VALUE_CALCULATION_AGENT_DETERMINATION = "REPLACEMENT_VALUE_CALCULATION_AGENT_DETERMINATION"

    def display_names(self) -> dict[str, str]:
        return {
            "CASH_PRICE_METHOD": "Cash Price",
            "CASH_PRICE_ALTERNATE_METHOD": "Cash Price (Alternate)",
            "PAR_YIELD_CURVE_ADJUSTED_METHOD": "Par Yield Curve (Adjusted)",
            "ZERO_COUPON_YIELD_ADJUSTED_METHOD": "Zero Coupon Yield (Adjusted)",
            "PAR_YIELD_CURVE_UNADJUSTED_METHOD": "Par Yield Curve (Unadjusted)",
            "CROSS_CURRENCY_METHOD": "Cross Currency",
            "COLLATERALIZED_CASH_PRICE_METHOD": "Collateralized Cash Price",
            "MID_MARKET_INDICATIVE_QUOTATIONS": "Mid-Market Indicative Quotations",
            "MID_MARKET_INDICATIVE_QUOTATIONS_ALTERNATE": "Mid-Market Indicative Quotations (Alternate)",
            "MID_MARKET_CALCULATION_AGENT_DETERMINATION": "Mid-Market (Calculation Agent Determination)",
            "REPLACEMENT_VALUE_FIRM_QUOTATIONS": "Replacement Value (Firm Quotations)",
            "REPLACEMENT_VALUE_CALCULATION_AGENT_DETERMINATION": "Replacement Value (Calculation Agent Determination)",
        }


class CashSettlementTermsModel(SettlementTermsBaseModel):
    """
    Cash Settlement Terms

    Defines the cash settlement terms which apply to transfers of cash
    to satisfy obligations around derivatives settlement.
    """

    settlement_type: SettlementType = Field(
        default=SettlementType.CASH, title="Settlement Type", description="Whether the settlement is cash, physical, by election", frozen=True
    )
    settlement_currency: CurrencyId | str | None = Field(default=None, title="Settlement Currency", description="Currency in which the settlement occurs.")
    settlement_amount: float | None = Field(default=None, title="Settlement Amount", description="Amount to be settled in settlement currency.")
    settlement_rate_option: SettlementRateOptionId | str | SettlementRateOptionModel | SyntheticSettlementRateOptionModel | None = Field(
        default=None, title="Settlement Rate Option", description="Settlement rate option"
    )
    settlement_rate_source: RateSourceId | str | RateSourceModel | None = Field(
        default=None, title="Settlement Rate Source", description="The rate source which provides the settlement rate used to compute the settlement amount."
    )
    settlement_method: CashSettlementMethod | None = Field(
        default=None, title="Settlement Method", description="The cash settlement method used to determine the settlement amount."
    )

    @field_validator("settlement_type", mode="before")
    def validate_settlement_type(cls, v):
        if v != SettlementType.CASH and v != SettlementType.CASH.value:
            raise ValueError("Settlement type must be CASH")
        return SettlementType.CASH

    semantic_type: Literal["CASH_SETTLEMENT_TERMS"] = Field(default="CASH_SETTLEMENT_TERMS", title="Semantic Type")


class PhysicalSettlementTermsModel(SettlementTermsBaseModel):
    """
    Physical Settlement Terms

    Defines the physical settlement terms which apply to transfers of securities or
    other assets to satisfy obligations around derivatives settlement.
    """

    settlement_type: SettlementType = Field(
        default=SettlementType.PHYSICAL, title="Settlement Type", description="Whether the settlement is cash, physical, by election", frozen=True
    )
    cleared_physical_settlement: bool | None = Field(
        default=None,
        title="Cleared Physical Settlement",
        description="Specifies whether the swap resulting from physical settlement of the swaption transaction will clear through a clearing house. The meaning of Cleared Physical Settlement is defined in the 2006 ISDA Definitions, Section 15.2 (published in Supplement number 28).",
    )

    @field_validator("settlement_type", mode="before")
    def validate_settlement_type(cls, v):
        if v != SettlementType.PHYSICAL and v != SettlementType.PHYSICAL.value:
            raise ValueError("Settlement type must be PHYSICAL")
        return SettlementType.PHYSICAL

    semantic_type: Literal["PHYSICAL_SETTLEMENT_TERMS"] = Field(default="PHYSICAL_SETTLEMENT_TERMS", title="Semantic Type")


ValidSettlementTypes = Annotated[
    Union[CashSettlementTermsModel, PhysicalSettlementTermsModel, SettlementTermsModel],
    Field(discriminator="semantic_type"),
]
