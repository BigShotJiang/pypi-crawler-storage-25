#!/usr/bin/env python
# pyright: strict

"""
Calculation Attributes

"""

from datetime import date
from enum import Enum
from typing import Literal, Optional

from pydantic import Field

from float_sdk.float_api.assets.base.cashflows import StubPeriodType
from float_sdk.float_api.base.math import RoundingModel
from float_sdk.float_api.datetime.conventions import DayCountConvention
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class AveragingCalculationMethodType(Enum):
    """
    Specifies enumerations for the type of averaging calculation.

    Attributes
    ----------
    ARITHMETIC : Refers to the calculation of an average by taking the sum of observations divided by the count of observations.
    GEOMETRIC :  Refers to the calculation of an average by taking the nth root of the product of n observations
    HARMONIC : Refers to the calculation of an average by taking the reciprocal of the arithmetic mean of the reciprocals of the observations.

    """

    ARITHMETIC = "ARITHMETIC"
    GEOMETRIC = "GEOMETRIC"
    HARMONIC = "HARMONIC"


class AveragingCalculationMethodModel(DataModel):
    """
    Defines the ways in which multiple values can be aggregated into a single value.

    Attributes
    ----------
    isWeighted: bool
        Identifies whether the average values will be weighted or unweighted.
    calculationMethod: AveragingCalculationMethodEnum
        Identifies which of the Pythagorean means is being used to compute an average value.
    """

    is_weighted: bool = Field(..., title="Is Weighted", description="Identifies whether the average values will be weighted or unweighted")
    calculation_method: AveragingCalculationMethodType = Field(
        ..., title="Calculation Method", description="Identifies which of the Pythagorean means is being used to compute an average value"
    )

    semantic_type: Literal["AVERAGING_CALCULATION_METHOD"] = "AVERAGING_CALCULATION_METHOD"


class AveragingCalculation:
    """
    Defines Attributes for use in cases when a valuation or other term is based on an average of market observations.

    Attributes
    ----------
    averagingMethod: AveragingCalculationMethod
        Specifies enumerations for the type of averaging calculation.
    precision: RoundingModel
        Rounding applied to the average calculation.
    """

    averaging_method: AveragingCalculationMethodModel
    precision: RoundingModel


class CompoundingMethod(Enum):
    """
    The enumerated values to specify the type of compounding, e.g. flat, straight.
    """

    FLAT = "FLAT"  # Flat compounding. Compounding excludes the spread. Note that the first compounding period has it's interest calculated including any spread then subsequent periods compound this at a rate excluding the spread."
    NONE = "NONE"  # No compounding is to be applied."
    STRAIGHT = "STRAIGHT"  # "Straight compounding. Compounding includes the spread."
    SPREAD_EXCLUSIVE = "SPREAD_EXCLUSIVE"  # "Spread Exclusive compounding."


class DiscountingType(Enum):
    """
    The enumerated values to specify the method of calculating discounted payment amounts. This enumerations combines the FpML DiscountingTypeEnum and FraDiscountingEnum enumerations.
    """

    STANDARD = "STANDARD"  # As specified by the 2006 ISDA Definitions, Section 8.4. Discounting, paragraph (a).
    FRA = "FRA"  # As specified by the 2006 ISDA Definitions, Section 8.4. Discounting, paragraph (b)."
    FRA_YIELD = "FRA_YIELD"  # As specified by the 2006 ISDA Definitions, Section 8.4. Discounting, paragraph (e)."
    AFMA = "AFMA"  # As specified by the Australian Financial Markets Association (AFMA) OTC Financial Product Conventions. This discounting method should not be used for a trade documented under a legal framework where the 2006 ISDA Definitions have been incorporated."


class DiscountingMethod:
    """
    A data defining:  discounting information. The 2000 ISDA definitions, section 8.4. discounting (related to the calculation of a discounted fixed amount or floating amount) apply. This type must only be included if discounting applies.

    Attributes
    ----------
    discountingType: DiscountingTypeEnum
        The discounting method that is applicable.
    discountRate: float, optional
        A discount rate, expressed as a decimal, to be used in the calculation of a discounted amount. A discount amount of 5% would be represented as 0.05.
    discountRateDayCountFraction: DayCountFractionEnum, optional
        A discount day count fraction to be used in the calculation of a discounted amount.
    """

    discounting_type: DiscountingType
    discount_rate: float | None = Field(
        default=None,
        title="Discount Rate",
        description="A discount rate, expressed as a decimal, to be used in the calculation of a discounted amount. A discount amount of 5% would be represented as 0.05.",
    )
    discount_rate_day_count_fraction: DayCountConvention | None = Field(default=None, title="Discount Rate Day Count Fraction")


class CalculationPeriodModel(DataModel):
    start_date_adjusted: date = Field(..., title="Adjusted Start Date", description="Adjusted start date of the calculation period")
    end_date_adjusted: date = Field(..., title="Adjusted End Date", description="Adjusted end date of the calculation period")
    start_date_unadjusted: date = Field(..., title="Unadjusted Start Date", description="Unadjusted start date of the calculation period")
    end_date_unadjusted: date = Field(..., title="Unadjusted End Date", description="Unadjusted end date of the calculation period")
    days: int = Field(..., title="Days in Period", description="Number of days in the period")
    day_count: int = Field(..., title="Day Count", description="Day count for the period")
    day_count_denominator: float = Field(..., title="Day Count Denominator", description="Denominator used in day count fraction calculation")
    day_count_fraction: float = Field(..., title="Day Count Fraction", description="Fraction of the year represented by the period")
    period_type: StubPeriodType = Field(..., title="Period Type", description="Type of the calculation period")
    frequency: str = Field(..., title="Frequency", description="Frequency of the period")
    calculation_amount: float = Field(..., title="Calculation Amount", description="Amount used for calculation in the period")
    amount: Optional[float] = Field(None, title="Amount", description="Optional amount for the period")
