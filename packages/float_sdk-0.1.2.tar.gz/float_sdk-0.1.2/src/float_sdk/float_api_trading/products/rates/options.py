#!/usr/bin/env python
# pyright: basic

"""
Interest Rate Option Specifications

"""

from typing import Literal

from pydantic import Field, computed_field, model_validator

from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.serialization.model import DisplayEnum
from float_sdk.float_api_trading.products.base.contractual import (
    ContractualProductModel,
    DoubleBarrierModel,
    SingleBarrierModel,
)
from float_sdk.float_api_trading.products.base.options import OptionBaseModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.rates.cashflows import FixedCashflowModel, FloatingRateCashflowModel, FloatingRateCashflowSeriesModel
from float_sdk.float_api_trading.products.rates.swaps import IRSwapModel
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel, PhysicalSettlementTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class IROptionType(DisplayEnum):
    CAP = "CAP"
    FLOOR = "FLOOR"
    STRADDLE = "STRADDLE"
    PAYER = "PAYER"
    RECEIVER = "RECEIVER"

    def display_names(self) -> dict[str, str]:
        return {
            "CAP": "Cap",
            "FLOOR": "Floor",
            "STRADDLE": "Straddle",
            "PAYER": "Payer",
            "RECEIVER": "Receiver",
        }


######################################################################################
## BASE CLASSES
######################################################################################


class IROptionBaseModel(ContractualProductModel):
    option_type: IROptionType | None = Field(default=None, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    fixed_amounts: FixedCashflowModel | None = Field(default=None, title="Fixed Amounts", description="Fixed payment or premium for the option")

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.IR_OPTIONS


class IRCMSOptionBaseModel(IROptionBaseModel):
    pass


class IRCMSOneLookOptionModel(IRCMSOptionBaseModel):
    """Model for CMS OneLook options (single observation, single CMS rate)"""

    floating_amounts: FloatingRateCashflowModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating payment definition based on a single CMS rate observation",
    )
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_ONE_LOOK_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["IR_CMS_ONE_LOOK_OPTION"] = Field(default="IR_CMS_ONE_LOOK_OPTION", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "IR CMS One Look Option",
            "description": "An interest rate CMS option with a single observation date and payment based on a constant maturity swap (CMS) rate. The holder pays an upfront premium and receives a payment at maturity based on the difference between the observed CMS rate and the strike rate. The option type (CAP, FLOOR, or STRADDLE) determines the payout structure.",
            "example": {
                "optionType": "CAP",
                "productType": "IR_CMS_ONE_LOOK_OPTION",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "USD",
                    "effectiveDate": "2022-03-15",
                    "businessDays": "USNY",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "USD_SOFR_ICE_SWAP_RATE_10Y", "cap": 0.045, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_ONE_LOOK_OPTION",
            },
        }


class IRCMSOneLookBarrierOptionModel(IRCMSOneLookOptionModel):
    """
    Model for CMS OneLook Barrier options (single observation, single CMS rate, with barrier).

    A barrier CMS option where the payout is contingent on a barrier condition being met.
    The barrier can reference a different rate than the payout rate (e.g., barrier monitors
    2Y CMS while payout is based on 10Y CMS).

    References:
    - FpML OptionFeature with barrier at product level
    - ISDA CDM barrier types and trigger events
    """

    barrier: SingleBarrierModel | None = Field(
        default=None,
        title="Barrier",
        description="Barrier terms monitoring a CMS rate or floating rate index. "
        "Knock-out barriers extinguish the option if breached. "
        "Knock-in barriers activate the option if breached. "
        "The barrier can reference a different rate than the payout rate.",
    )

    product_type: ProductType = Field(
        default=ProductType.IR_CMS_ONE_LOOK_BARRIER_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    semantic_type: Literal["IR_CMS_ONE_LOOK_BARRIER_OPTION"] = Field(default="IR_CMS_ONE_LOOK_BARRIER_OPTION", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "IR CMS One Look Barrier Option",
            "description": "An interest rate CMS option with a single observation date and a barrier condition. "
            "The payout is contingent on both the option being in-the-money and the barrier condition. "
            "The barrier can monitor a different CMS rate than the payout rate, enabling strategies like "
            "paying based on 10Y CMS only if 2Y CMS breaches a level.",
            "example": {
                "optionType": "CAP",
                "productType": "IR_CMS_ONE_LOOK_BARRIER_OPTION",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "USD",
                    "effectiveDate": "2022-03-15",
                    "businessDays": "USNY",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "USD_SOFR_ICE_SWAP_RATE_10Y", "cap": 0.045, "semanticType": "FLOATING_RATE"},
                },
                "barrier": {
                    "barrierTerms": {
                        "level": 0.035,
                        "triggerType": "AMERICAN",
                        "eventType": "KNOCK_IN",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "asset": "USD_SOFR_ICE_SWAP_RATE_2Y",
                    "semanticType": "SINGLE_BARRIER",
                },
                "semanticType": "IR_CMS_ONE_LOOK_BARRIER_OPTION",
            },
        }


class IRCMSMultiLookOptionModel(IRCMSOptionBaseModel):
    """Model for CMS MultiLook options (multiple observations, single CMS rate)"""

    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating payment definition based on multiple CMS rate observations",
    )
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_MULTI_LOOK_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["IR_CMS_MULTI_LOOK_OPTION"] = Field(default="IR_CMS_MULTI_LOOK_OPTION", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "IR CMS Multi Look Option",
            "description": "An interest rate CMS option with multiple observation dates and periodic payments based on a constant maturity swap (CMS) rate. The holder pays an upfront premium and receives periodic payments based on the difference between the observed CMS rate and the strike rate at each observation. The option type (CAP, FLOOR, or STRADDLE) determines the payout structure for each period.",
            "example": {
                "optionType": "CAP",
                "productType": "IR_CMS_MULTI_LOOK_OPTION",
                "effectiveDate": "2022-03-15",
                "terminationDate": "2027-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 500000,
                    "paymentDate": "2022-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2027-03-15",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "USD",
                    "dayCountConvention": "ACT/360",
                    "floatingRate": {"rateOption": "USD_SOFR_ICE_SWAP_RATE_10Y", "cap": 0.045, "semanticType": "FLOATING_RATE"},
                    "calculationPeriodDates": {
                        "businessDays": "USNY",
                        "businessDayConvention": "MODFOLLOWING",
                        "dateRollRule": {
                            "frequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                            "dayOfMonth": 15,
                        },
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                        "semanticType": "PAYMENT_DATES_SPECIFICATION",
                    },
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "semanticType": "IR_CMS_MULTI_LOOK_OPTION",
            },
        }


class IRCMSCurveOptionBaseModel(IRCMSOptionBaseModel):
    """Base model for CMS Curve options (spread between two CMS rates)"""

    pass


class IRCMSCurveOneLookOptionModel(IRCMSCurveOptionBaseModel):
    floating_amounts: FloatingRateCashflowModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating payment definition. For a CMS Spread Option this is the difference between the strike rate and CMS index spread",
    )
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_ONE_LOOK_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    semantic_type: Literal["IR_CMS_CURVE_ONE_LOOK_OPTION"] = Field(default="IR_CMS_CURVE_ONE_LOOK_OPTION", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "IR CMS Curve One Look Option",
            "description": "An interest rate CMS curve option with a single observation date and payment based on the spread between two constant maturity swap (CMS) rates. The holder pays an upfront premium and receives a payment at maturity based on the difference between the observed CMS spread and the strike spread. The option type (CAP, FLOOR, or STRADDLE) determines the payout structure.",
            "example": {
                "optionType": "CAP",
                "productType": "IR_CMS_CURVE_ONE_LOOK_OPTION",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "EUR",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "EUR",
                    "effectiveDate": "2022-03-15",
                    "businessDays": "EUTA",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.0025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_ONE_LOOK_OPTION",
            },
        }


class IRCMSCurveOneLookBarrierOptionModel(IRCMSCurveOneLookOptionModel):
    """
    Model for CMS Curve OneLook Barrier options (single observation, CMS spread, with barrier).

    A barrier CMS curve option where the payout is contingent on a barrier condition being met.
    The payout is based on the spread between two CMS rates, while the barrier can monitor
    a different rate (e.g., barrier monitors 2Y CMS while payout is based on 10Y-2Y spread).

    References:
    - FpML OptionFeature with barrier at product level
    - ISDA CDM barrier types and trigger events
    """

    barrier: SingleBarrierModel | None = Field(
        default=None,
        title="Barrier",
        description="Barrier terms monitoring a CMS rate or floating rate index. "
        "Knock-out barriers extinguish the option if breached. "
        "Knock-in barriers activate the option if breached. "
        "The barrier can reference a different rate than the payout spread rates.",
    )

    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    semantic_type: Literal["IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION"] = Field(default="IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "IR CMS Curve One Look Barrier Option",
            "description": "An interest rate CMS curve option with a single observation date, payout based on the "
            "spread between two CMS rates, and a barrier condition. The payout is contingent on both "
            "the option being in-the-money and the barrier condition. The barrier can monitor a "
            "different CMS rate than the spread rates, enabling complex contingent strategies.",
            "example": {
                "optionType": "CAP",
                "productType": "IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "EUR",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "EUR",
                    "effectiveDate": "2022-03-15",
                    "businessDays": "EUTA",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.0025, "semanticType": "FLOATING_RATE"},
                },
                "barrier": {
                    "barrierTerms": {
                        "level": 0.025,
                        "triggerType": "AMERICAN",
                        "eventType": "KNOCK_IN",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "asset": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_2Y",
                    "semanticType": "SINGLE_BARRIER",
                },
                "semanticType": "IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION",
            },
        }


class IRCMSCurveMultiLookOptionModel(IRCMSCurveOptionBaseModel):
    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating payment definition. For a CMS Spread Option this is the difference between the strike rate and CMS index spread",
    )
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_MULTI_LOOK_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    semantic_type: Literal["IR_CMS_CURVE_MULTI_LOOK_OPTION"] = Field(default="IR_CMS_CURVE_MULTI_LOOK_OPTION", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "IR CMS Curve Multi Look Option",
            "description": "An interest rate CMS curve option with multiple observation dates and periodic payments based on the spread between two constant maturity swap (CMS) rates. This instrument allows the holder to gain exposure to movements in the CMS curve spread over multiple periods, with payments calculated at regular intervals throughout the option's life. It is commonly used for hedging or speculating on the shape of the yield curve.",
            "example": {
                "optionType": "CAP",
                "productType": "IR_CMS_CURVE_MULTI_LOOK_OPTION",
                "effectiveDate": "2022-03-15",
                "terminationDate": "2027-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "EUR",
                    "amount": 250000,
                    "paymentDate": "2022-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2027-03-15",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "EUR",
                    "dayCountConvention": "ACT/360",
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.0025, "semanticType": "FLOATING_RATE"},
                    "calculationPeriodDates": {
                        "effectiveDate": "2022-03-15",
                        "terminationDate": "2027-03-15",
                        "calculationFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "businessDayConvention": "MODFOLLOWING",
                        "businessDayCalendar": "EUTA",
                        "semanticType": "CALCULATION_PERIOD_DATES",
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                        "semanticType": "PAYMENT_DATE_SCHEDULE",
                    },
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "semanticType": "IR_CMS_CURVE_MULTI_LOOK_OPTION",
            },
        }


######################################################################################
## One Look CMS Curve Options
######################################################################################


class IRCMSCurveOneLookCapModel(IRCMSCurveOneLookOptionModel):
    option_type: IROptionType = Field(default=IROptionType.CAP, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_ONE_LOOK_CAP, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["IR_CMS_CURVE_ONE_LOOK_CAP"] = Field(default="IR_CMS_CURVE_ONE_LOOK_CAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "hidden": True,
            "title": "IR CMS Curve One Look Cap",
            "description": "An interest rate CMS curve cap option is a financial derivative that provides the holder with the right, but not the obligation, to receive payments based on the positive difference between a specified strike rate and the observed CMS curve spread at a single observation date. This instrument is typically used to hedge or gain exposure to movements in the spread between two constant maturity swap (CMS) rates. The cap option pays out if the CMS curve spread exceeds the strike rate, and its terms specify the notional amount, payment conventions, and settlement details.",
            "example": {
                "name": "IRCMS CAP EURIBOR 10Y-2Y 13MAR23",
                "productType": "IR_CMS_CURVE_ONE_LOOK_CAP",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "USD",
                    "effectiveDate": "2022-03-15",
                    "businessDays": "EUTA",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.0025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_ONE_LOOK_CAP",
            },
        }


class IRCMSCurveOneLookFloorModel(IRCMSCurveOneLookOptionModel):
    option_type: IROptionType = Field(default=IROptionType.FLOOR, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_ONE_LOOK_FLOOR, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["IR_CMS_CURVE_ONE_LOOK_FLOOR"] = Field(default="IR_CMS_CURVE_ONE_LOOK_FLOOR", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "hidden": True,
            "title": "IR CMS Curve One Look Floor",
            "description": "An interest rate CMS curve floor option is a financial derivative that provides the holder with the right, but not the obligation, to receive payments based on the positive difference between a specified strike rate and the observed CMS curve spread at a single observation date, but only if the spread is below the strike rate. This instrument is typically used to hedge or gain exposure to movements in the spread between two constant maturity swap (CMS) rates. The floor option pays out if the CMS curve spread falls below the strike rate, and its terms specify the notional amount, payment conventions, and settlement details.",
            "example": {
                "name": "IRCMS FLOOR EURIBOR 10Y-2Y 13MAR23",
                "productType": "IR_CMS_CURVE_ONE_LOOK_FLOOR",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "USD",
                    "effectiveDate": "2022-03-15",
                    "businessDays": "EUTA",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "floor": 0.0025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_ONE_LOOK_FLOOR",
            },
        }


class IRCMSCurveOneLookStraddleModel(IRCMSCurveOneLookOptionModel):
    option_type: IROptionType = Field(default=IROptionType.STRADDLE, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_ONE_LOOK_STRADDLE,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    semantic_type: Literal["IR_CMS_CURVE_ONE_LOOK_STRADDLE"] = Field(default="IR_CMS_CURVE_ONE_LOOK_STRADDLE", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "hidden": True,
            "title": "IR CMS Curve One Look Straddle",
            "description": "An interest rate CMS curve straddle option is a financial derivative that provides the holder with the right, but not the obligation, to receive payments based on the absolute difference between a specified strike rate and the observed CMS curve spread at a single observation date. This instrument is typically used to hedge or gain exposure to volatility in the spread between two constant maturity swap (CMS) rates. The straddle option pays out if the CMS curve spread deviates from the strike rate, and its terms specify the notional amount, payment conventions, and settlement details.",
            "example": {
                "name": "IRCMS STRADDLE EURIBOR 10Y-2Y 13MAR23",
                "productType": "IR_CMS_CURVE_ONE_LOOK_STRADDLE",
                "effectiveDate": "2022-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-15",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalAmount": 50000000.0,
                    "notionalCurrency": "USD",
                    "effectiveDate": "2022-03-17",
                    "businessDays": "EUTA",
                    "determinationDate": "2023-03-13",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                    "dayCountConvention": "1/1",
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.0025, "floor": 0.0025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_ONE_LOOK_STRADDLE",
            },
        }


######################################################################################
## Multi Look CMS Curve Options
######################################################################################


class IRCMSCurveMultiLookCapModel(IRCMSCurveMultiLookOptionModel):
    option_type: IROptionType = Field(default=IROptionType.CAP, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_MULTI_LOOK_CAP, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["IR_CMS_CURVE_MULTI_LOOK_CAP"] = Field(default="IR_CMS_CURVE_MULTI_LOOK_CAP", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "hidden": True,
            "title": "IR CMS Curve Multi Look Cap",
            "description": "An interest rate CMS curve cap option is a financial derivative that provides the holder with the right, but not the obligation, to receive payments based on the difference between a specified cap strike rate and the observed CMS curve spread at multiple dates as defined by the calculation schedule. This instrument is typically used to hedge or gain exposure to movements in the spread between two constant maturity swap (CMS) rates. The cap option pays out if the CMS curve spread exceeds the strike rate, and its terms specify the notional amount, payment conventions, and settlement details.",
            "example": {
                "name": "IRCMS CAP EURIBOR 10Y-2Y 13MAR23",
                "productType": "IR_CMS_CURVE_MULTI_LOOK_CAP",
                "effectiveDate": "2022-03-15",
                "terminationDate": "2023-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "name": "IRFLT EUR EURIBOR 10Y-2Y 1/1 15MAR23",
                    "description": "IRFLT EUR EURIBOR 10Y-2Y 1/1 15MAR23",
                    "productType": "IR_FLOATING_CASHFLOW_SERIES",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "dayCountConvention": "1/1",
                    "notionalAmount": 100000000.0,
                    "notionalCurrency": "EUR",
                    "calculationPeriodDates": {
                        "businessDays": "EUTA",
                        "businessDayConvention": "MODFOLLOWING",
                        "dateRollRule": {
                            "frequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                            "dayOfMonth": 15,
                        },
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "semanticType": "PAYMENT_DATES_SPECIFICATION",
                    },
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_MULTI_LOOK_CAP",
            },
        }


class IRCMSCurveMultiLookFloorModel(IRCMSCurveMultiLookOptionModel):
    option_type: IROptionType = Field(default=IROptionType.FLOOR, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_MULTI_LOOK_FLOOR,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    semantic_type: Literal["IR_CMS_CURVE_MULTI_LOOK_FLOOR"] = Field(default="IR_CMS_CURVE_MULTI_LOOK_FLOOR", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "hidden": True,
            "title": "IR CMS Curve Multi Look Floor",
            "description": "An interest rate CMS curve cap option is a financial derivative that provides the holder with the right, but not the obligation, to receive payments based on the difference between a specified floor strike rate and the observed CMS curve spread at multiple dates as defined by the calculation schedule. This instrument is typically used to hedge or gain exposure to movements in the spread between two constant maturity swap (CMS) rates. The floor option pays out if the CMS curve spread is below the strike rate, and its terms specify the notional amount, payment conventions, and settlement details.",
            "example": {
                "name": "IRCMS FLOOR EURIBOR 10Y-2Y 13MAR23",
                "productType": "IR_CMS_CURVE_MULTI_LOOK_FLOOR",
                "effectiveDate": "2022-03-15",
                "terminationDate": "2023-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "name": "IRFLT EUR EURIBOR 10Y-2Y 1/1 15MAR23",
                    "description": "IRFLT EUR EURIBOR 10Y-2Y 1/1 15MAR23",
                    "productType": "IR_FLOATING_CASHFLOW_SERIES",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "dayCountConvention": "1/1",
                    "notionalAmount": 100000000.0,
                    "notionalCurrency": "EUR",
                    "calculationPeriodDates": {
                        "businessDays": "EUTA",
                        "businessDayConvention": "MODFOLLOWING",
                        "dateRollRule": {
                            "frequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                            "dayOfMonth": 15,
                        },
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "payRelativeTo": "CALCULATION_PERIOD_END_DATE",
                        "semanticType": "PAYMENT_DATES_SPECIFICATION",
                    },
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "floor": 0.025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_MULTI_LOOK_FLOOR",
            },
        }


class IRCMSCurveMultiLookStraddleModel(IRCMSCurveMultiLookOptionModel):
    option_type: IROptionType = Field(default=IROptionType.STRADDLE, title="Option Type", description="Type of option: CAP, FLOOR, or STRADDLE")
    product_type: ProductType = Field(
        default=ProductType.IR_CMS_CURVE_MULTI_LOOK_STRADDLE,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    semantic_type: Literal["IR_CMS_CURVE_MULTI_LOOK_STRADDLE"] = Field(default="IR_CMS_CURVE_MULTI_LOOK_STRADDLE", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "hidden": True,
            "title": "IR CMS Curve Multi Look Straddle",
            "description": "An interest rate CMS curve cap option is a financial derivative that provides the holder with the right, but not the obligation, to receive payments based on the absolute difference between a specified floor strike rate and the observed CMS curve spread at multiple dates as defined by the calculation schedule. This instrument is typically used to hedge or gain exposure to movements in the spread between two constant maturity swap (CMS) rates. The floor option pays out if the CMS curve spread is below the strike rate, and its terms specify the notional amount, payment conventions, and settlement details.",
            "example": {
                "name": "IRCMS STRADDLE EURIBOR 10Y-2Y 13MAR23",
                "productType": "IR_CMS_CURVE_MULTI_LOOK_STRADDLE",
                "effectiveDate": "2022-03-15",
                "terminationDate": "2023-03-15",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 125000,
                    "paymentDate": "2023-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "name": "IRFLT EUR EURIBOR 10Y-2Y 1/1 15MAR23",
                    "description": "IRFLT EUR EURIBOR 10Y-2Y 1/1 15MAR23",
                    "productType": "IR_FLOATING_CASHFLOW_SERIES",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "dayCountConvention": "1/1",
                    "notionalAmount": 100000000.0,
                    "notionalCurrency": "EUR",
                    "calculationPeriodDates": {
                        "businessDays": "EUTA",
                        "businessDayConvention": "MODFOLLOWING",
                        "dateRollRule": {
                            "frequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                            "dayOfMonth": 15,
                        },
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "payRelativeTo": "CALCULATION_PERIOD_END_DATE",
                        "semanticType": "PAYMENT_DATES_SPECIFICATION",
                    },
                    "floatingRate": {"rateOption": "EUR_EURIBOR_ICE_SWAP_RATE_11_00_10Y_2Y", "cap": 0.025, "floor": 0.025, "semanticType": "FLOATING_RATE"},
                },
                "semanticType": "IR_CMS_CURVE_MULTI_LOOK_SRADDLE",
            },
        }


class IRSwaptionModel(OptionBaseModel):
    """
    Interest Rate Swaption Model (Pydantic)

    An interest rate swaption is an over-the-counter option granting the right
    but not the obligation to enter into an underlying interest rate swap.

    The buyer pays a premium for the optionality, and upon exercise (if conditions
    are favorable), enters into the swap with terms predetermined at trade inception.

    Key terminology:
    - Payer Swaption: buyer has the right to be the fixed rate payer (buyer == payer)
    - Receiver Swaption: buyer has the right to be the fixed rate receiver (buyer == receiver)

    References:
    - FPML 5.10: Swaption complex type
    - ISDA CDM: InterestRate_Option_Swaption product qualification
    - ISDA 2006 Definitions: Article 12 (Swaption provisions)
    """

    product_type: ProductType = Field(
        default=ProductType.IR_SWAPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    option_type: IROptionType | None = Field(
        default=None,
        title="Option Type",
        description="Type of swaption: PAYER (right to pay fixed) or RECEIVER (right to receive fixed).",
    )

    # The underlying interest rate swap
    swap: IRSwapModel | None = Field(
        default=None,
        title="Swap",
        description="The interest rate swap that will come into effect if the option is exercised. Per FPML, this is named 'swap' and contains the full economic terms of the underlying swap.",
    )

    # Strike for swaptions is typically expressed as a fixed rate
    strike_price: float | None = Field(
        default=None,
        title="Strike Rate",
        description="The fixed rate of the underlying swap, expressed as a decimal (e.g., 0.0350 for 3.50%). This is the strike of the swaption.",
    )

    # Settlement terms - only cash or physical, not base class
    settlement_terms: CashSettlementTermsModel | PhysicalSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Settlement terms for the swaption. Typically physical settlement (enter the swap) or cash settlement.",
    )

    # Computed fields - reference properties on underlying swap
    # Note: notional_amount and notional_currency are inherited from OptionBaseModel
    # They should be set to match the underlying swap's values

    @model_validator(mode="after")
    def sync_from_swap(self) -> "IRSwaptionModel":
        """Sync notional values from swap if not explicitly set"""
        if self.swap:
            if self.notional_amount is None:
                self.notional_amount = self.swap.notional_amount
            if self.notional_currency is None:
                self.notional_currency = self.swap.notional_currency
        return self

    @computed_field
    @property
    def payer(self) -> CounterpartyRole | None:
        """
        Party that will pay fixed rate in the underlying swap.

        If buyer == payer, this is a "payer swaption" (buyer has right to pay fixed).
        Follows the same pattern as IRSwapModel.payer for consistency.
        """
        return self.swap.payer if self.swap else None

    @computed_field
    @property
    def receiver(self) -> CounterpartyRole | None:
        """
        Party that will receive fixed rate in the underlying swap.

        If buyer == receiver, this is a "receiver swaption" (buyer has right to receive fixed).
        Follows the same pattern as IRSwapModel.receiver for consistency.
        """
        return self.swap.receiver if self.swap else None

    semantic_type: Literal["IR_SWAPTION"] = Field(
        default="IR_SWAPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    @computed_field
    @property
    def asset_class(self) -> AssetClass:
        return AssetClass.INTEREST_RATE

    @computed_field
    @property
    def product_family(self) -> ProductFamily:
        return ProductFamily.IR_OPTIONS

    class Config:
        json_schema_extra = {
            "title": "IR Swaption",
            "description": "An interest rate swaption is an OTC option that gives the buyer the right, but not the obligation, to enter into an interest rate swap agreement at a specified strike rate on or before the expiration date. The buyer/seller represent the option counterparties. The payer/receiver (from the underlying swap) indicate the swap positions upon exercise. A payer swaption means buyer will pay fixed (buyer == payer), while a receiver swaption means buyer will receive fixed (buyer == receiver). Upon exercise, the option holder enters into the predetermined swap with the option seller as counterparty. Swaptions are widely used to hedge future interest rate exposure, lock in financing costs, or gain exposure to interest rate volatility.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionStyle": "EUROPEAN",
                "notionalAmount": 50000000.0,
                "notionalCurrency": "USD",
                "strikePrice": 0.035,
                "effectiveDate": "2024-03-15",
                "expirationDate": "2025-03-15",
                "expirationTime": {
                    "time": "11:00:00",
                    "location": "USNY",
                    "semanticType": "TIME_LOCATION",
                },
                "premiumTerms": {
                    "premium": 500000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-03-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2025-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "swap": {
                    "productType": "IR_SWAP",
                    "effectiveDate": "2025-03-17",
                    "terminationDate": "2030-03-17",
                    "fixedAmounts": {
                        "payer": "PARTY_2",
                        "receiver": "PARTY_1",
                        "notionalAmount": 50000000.0,
                        "notionalCurrency": "USD",
                        "dayCountConvention": "30/360",
                        "fixedRate": {"rate": 0.035},
                        "calculationDateSchedule": {
                            "frequency": {"period": "M", "multiplier": 6},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                        },
                        "semanticType": "IR_FIXED_CASHFLOW_SERIES",
                    },
                    "floatingAmounts": {
                        "payer": "PARTY_1",
                        "receiver": "PARTY_2",
                        "notionalAmount": 50000000.0,
                        "notionalCurrency": "USD",
                        "dayCountConvention": "ACT/360",
                        "floatingRate": {"rateOption": "USD_SOFR_ICE_SWAP_RATE"},
                        "calculationDateSchedule": {
                            "frequency": {"period": "M", "multiplier": 3},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                        },
                        "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                    },
                    "semanticType": "IR_SWAP",
                },
                "semanticType": "IR_SWAPTION",
            },
        }


class IRBarrierSwaptionModel(IRSwaptionModel):
    """
    Barrier Interest Rate Swaption Model (Pydantic)

    A barrier swaption with knock-in or knock-out features based on observation
    of market swap rates or floating rate indices. The barrier monitors market
    rates during the observation period and can knock out (extinguish) or knock in
    (activate) the swaption option.

    The barrier applies to the swaption itself (the option), not the underlying swap.
    If not knocked out and exercised, the holder enters the pre-defined swap.

    References:
    - Based on FPML barrier features (primarily FX-focused)
    - ISDA CDM barrier types and trigger events
    """

    barrier: SingleBarrierModel | DoubleBarrierModel | None = Field(
        default=None,
        title="Barrier",
        description="Barrier terms monitoring swap rate or floating rate index. "
        "Knock-out barriers extinguish the option if breached. "
        "Knock-in barriers activate the option if breached.",
    )

    product_type: ProductType = Field(
        default=ProductType.IR_BARRIER_SWAPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    semantic_type: Literal["IR_BARRIER_SWAPTION"] = Field(
        default="IR_BARRIER_SWAPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "IR Barrier Swaption",
            "description": "A barrier swaption with knock-in or knock-out features. The barrier monitors market swap rates during the observation period and can knock out (extinguish) or knock in (activate) the swaption option based on barrier breach conditions. The barrier applies to the swaption itself (the option), not the underlying swap. If not knocked out and exercised, the holder enters the pre-defined swap. This product combines traditional swaption features with barrier options, commonly used to reduce premium costs or implement conditional hedging strategies.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "optionStyle": "EUROPEAN",
                "notionalAmount": 50000000.0,
                "notionalCurrency": "USD",
                "strikePrice": 0.035,
                "effectiveDate": "2024-03-15",
                "expirationDate": "2025-03-15",
                "expirationTime": {
                    "time": "11:00:00",
                    "location": "USNY",
                    "semanticType": "TIME_LOCATION",
                },
                "premiumTerms": {
                    "premium": 400000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-03-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2025-03-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "barrier": {
                    "barrierTerms": {
                        "barrierType": "KNOCKOUT",
                        "barrierDirection": "UP",
                        "barrierLevel": 0.045,
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "swap": {
                    "productType": "IR_SWAP",
                    "effectiveDate": "2025-03-17",
                    "terminationDate": "2030-03-17",
                    "fixedAmounts": {
                        "payer": "PARTY_2",
                        "receiver": "PARTY_1",
                        "notionalAmount": 50000000.0,
                        "notionalCurrency": "USD",
                        "dayCountConvention": "30/360",
                        "fixedRate": {"rate": 0.035},
                        "calculationDateSchedule": {
                            "frequency": {"period": "M", "multiplier": 6},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                        },
                        "semanticType": "IR_FIXED_CASHFLOW_SERIES",
                    },
                    "floatingAmounts": {
                        "payer": "PARTY_1",
                        "receiver": "PARTY_2",
                        "notionalAmount": 50000000.0,
                        "notionalCurrency": "USD",
                        "dayCountConvention": "ACT/360",
                        "calculationDateSchedule": {
                            "frequency": {"period": "M", "multiplier": 3},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                        },
                        "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                    },
                    "semanticType": "IR_SWAP",
                },
                "semanticType": "IR_BARRIER_SWAPTION",
            },
        }
