#!/usr/bin/env python
# pyright: basic

"""
Deprecated Swap Models

"""

from datetime import date
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId, HolidayCalendarId, IndexId
from float_sdk.float_api.datetime.calendars import HolidayCalendarModel
from float_sdk.float_api.datetime.conventions import BusinessDayConvention, DayCountConvention
from float_sdk.float_api.datetime.schedule import ValidRollRuleModels
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.trading.parties import CounterpartyRole


class VanillaInterestRateSwapModel(ContractualProductModel):
    ## General terms
    #
    product_type: ProductType = Field(
        ProductType.IR_SWAP_OLD, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        None, title="Notional Currency", description="Currency for the specified notional and related accrual calulations."
    )
    notional_quantity: float | None = Field(
        None, title="Notional Quantity", description="Reference quantity expressed as a notional amount which is used to compute payment amounts."
    )
    effective_date: date | None = Field(default=None, title="Effective Date", description="The date on which the event contractually takes effect")
    termination_date: date | None = Field(
        default=None,
        title="Termination Date",
        description="The last day of the terms of the trade. This date may be subject to adjustments in accordance with the business day convention. It can also be specified in relation to another scheduled date (e.g. the last payment date).",
    )

    ## Fixed leg
    #
    fixed_rate_payer: CounterpartyRole | None = Field(
        None, title="Fixed Rate Payer", description="Party which is paying the fixed amount (receiving floating rate payments)."
    )
    fixed_rate: float | None = Field(
        None,
        title="Fixed Rate",
        description="The fixed rate or fixed rate specification expressed as explicit fixed rates and dates.",
    )
    fixed_periods: ValidRollRuleModels | None = Field(
        None,
        title="Fixed Periods",
        description="Fixed leg calculation periods, expressed as a date roll specification (e.g. EOM, IMM, or a fixed day of the week or month).",
    )
    fixed_payments: ValidRollRuleModels | None = Field(
        None,
        title="Fixed Payments",
        description="Fixed leg payment periods, expressed as a date roll specification (e.g. EOM, IMM, or a fixed day of the week or month).",
    )
    fixed_holidays: HolidayCalendarId | str | HolidayCalendarModel | None = Field(
        None, title="Fixed Holidays", description="Fixed leg holiday calendar, used for business date adjustments."
    )
    fixed_business_day_convention: BusinessDayConvention | None = Field(
        None,
        title="Fixed BDC",
        description="Convention to adjust a date to a valid business day if it falls on a weekend or holiday day per a given holiday calendar. ",
    )
    fixed_day_count_convention: DayCountConvention | None = Field(
        None, title="Fixed Day Count Convention", description="Day count convention for fixed rate leg accrual calculations. "
    )

    ## Floating leg
    #
    floating_rate_payer: CounterpartyRole | None = Field(
        None, title="Fixed Rate Payer", description="Party which is paying the floating amount (receiving fixed rate payments)."
    )
    floating_rate_index: IndexId | str | None = Field(
        None, title="Floating Rate Index", description="Floating rate index used to calculate floating leg payments."
    )
    floating_periods: ValidRollRuleModels | None = Field(
        None,
        title="Floating Periods",
        description="Floating leg calculation periods, expressed as a date roll specification (e.g. EOM, IMM, or a fixed day of the week or month).",
    )
    floating_payments: ValidRollRuleModels | None = Field(
        None,
        title="Floating Payments",
        description="Fixed leg payment periods, expressed as a date roll specification (e.g. EOM, IMM, or a fixed day of the week or month).",
    )
    floating_holidays: HolidayCalendarId | str | HolidayCalendarModel | None = Field(
        None, title="Floating Holidays", description="Floating leg holiday calendar, used for business date adjustments."
    )
    floating_business_day_convention: BusinessDayConvention | None = Field(
        None,
        title="Floating BDC",
        description="Convention to adjust a date to a valid business day if it falls on a weekend or holiday day per a given holiday calendar. ",
    )
    floating_day_count_convention: DayCountConvention | None = Field(
        None, title="Floating Day Count Convention", description="Day count convention for floating rate leg accrual calculations. "
    )

    class Config:
        json_schema_extra = {
            "title": "Interest Rate Swap",
            "description": "An interest rate swap is a financial contract between two parties to exchange interest rate cash flows over a specified period. Typically, one party agrees to pay a fixed interest rate, while the other pays a floating rate based on a reference rate, such as SOFR or SONIA. The fixed-rate payer often seeks to hedge against interest rate fluctuations, while the floating-rate payer may aim to reduce financing costs or manage exposure to interest rate changes. At regular intervals, the parties exchange payments based on the agreed-upon terms, with the net amount settled between them.",
            "example": {
                "productType": "IR_SWAP",
                "effectiveDate": "2022-03-15",
                "terminationDate": "2023-03-15",
                "notionalCurrency": "USD",
                "notionalQuantity": 50000000.0,
                "fixedRatePayer": "PARTY_1",
                "fixedRate": 0.06,
                "fixedPeriods": {"frequency": {"semanticType": "DATE_RELATIVE", "period": "M", "multiplier": 3}},
                "fixedPayments": {"frequency": {"semanticType": "DATE_RELATIVE", "period": "M", "multiplier": 3}},
                "fixedHolidays": "USNY",
                "fixedBusinessDayConvention": "MODFOLLOWING",
                "fixedDayCountConvention": "ACT/360",
                "floatingRatePayer": "PARTY_2",
                "floatingRateIndex": "USD_SOFR",
                "floatingPeriods": {"frequency": {"semanticType": "DATE_RELATIVE", "period": "M", "multiplier": 3}},
                "floatingPayments": {"frequency": {"semanticType": "DATE_RELATIVE", "period": "M", "multiplier": 3}},
                "floatingHolidays": "USNY",
                "floatingBusinessDayConvention": "MODFOLLOWING",
                "floatingDayCountConvention": "30/360",
                "semanticType": "IR_SWAP",
            },
        }

    semantic_type: Literal["IR_SWAP"] = Field(default="IR_SWAP", json_schema_extra={"readOnly": True})
