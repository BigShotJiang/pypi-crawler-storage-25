#!/usr/bin/env python
# pyright: basic

"""
Swap Product Definitions

"""

from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.rates.cashflows import (
    FixedCashflowModel,
    FixedRateCashflowSeriesModel,
    FloatingRateCashflowSeriesModel,
    InflationRateCashflowModel,
    InflationRateCashflowSeriesModel,
)
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class IRSwapModel(ContractualProductModel):
    product_type: ProductType = Field(
        default=ProductType.IR_SWAP, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_amounts: FixedRateCashflowSeriesModel | None = Field(
        default=None, title="Fixed Amounts", description="Terms of the fixed leg of the interest rate swap"
    )
    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None, title="Floating Amounts", description="Terms of the floating leg of the interest rate swap"
    )

    @computed_field
    @property
    def notional_amount(self) -> float | None:
        """Notional amount from the fixed leg"""
        if self.fixed_amounts:
            return self.fixed_amounts.notional_amount
        return None

    @computed_field
    @property
    def notional_currency(self) -> CurrencyId | str | CurrencyModel | None:
        """Notional currency from the fixed leg"""
        if self.fixed_amounts:
            return self.fixed_amounts.notional_currency
        return None

    @computed_field
    @property
    def payer(self) -> CounterpartyRole | None:
        """Party that pays fixed rate (payer in fixed_amounts)"""
        if self.fixed_amounts:
            return self.fixed_amounts.payer
        return None

    @computed_field
    @property
    def receiver(self) -> CounterpartyRole | None:
        """Party that receives fixed rate (receiver in fixed_amounts)"""
        if self.fixed_amounts:
            return self.fixed_amounts.receiver
        return None

    class Config:
        json_schema_extra = {
            "title": "IR Swap",
            "description": "An interest rate swap is a financial contract between two parties to exchange interest rate cash flows over a specified period. Typically, one party agrees to pay a fixed interest rate, while the other pays a floating rate based on a reference rate, such as SOFR or SONIA. The fixed-rate payer often seeks to hedge against interest rate fluctuations, while the floating-rate payer may aim to reduce financing costs or manage exposure to interest rate changes. At regular intervals, the parties exchange payments based on the agreed-upon terms, with the net amount settled between them.",
            "example": {
                "productType": "IR_SWAP",
                "fixedAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "notionalCurrency": "USD",
                    "notionalQuantity": 50000000.0,
                    "holidayCalendar": "USDNY",
                    "businessDayConvention": "MODFOLLOWING",
                    "dayCountConvention": "ACT/360",
                    "fixedRate": {
                        "rate": 0.06,
                    },
                    "calculationDateSchedule": {"dayOfMonth": 15, "frequency": {"period": "M", "multiplier": 3}, "semanticType": "DATE_ROLL_DAY_OF_MONTH"},
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2},
                    },
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "notionalCurrency": "USD",
                    "notionalQuantity": 50000000.0,
                    "holidayCalendar": "USDNY",
                    "businessDayConvention": "MODFOLLOWING",
                    "dayCountConvention": "30/360",
                    "floatingRate": {
                        "rateOption": "USD_SOFR_ICE_SWAP_RATE_10Y",
                    },
                },
                "semanticType": "IR_SWAP",
            },
        }

    semantic_type: Literal["IR_SWAP"] = Field(default="IR_SWAP", json_schema_extra={"readOnly": True})


class IRInflationSwapZCModel(ContractualProductModel):
    """
    Zero-Coupon Inflation Swap

    A swap agreement where both legs have a single payment at maturity.
    The fixed leg pays N × [(1 + r)^T - 1] and the inflation leg pays
    N × [I(T)/I_base - 1] where the inflation return is compounded over the full tenor.

    Per FpML: productType = "InflationSwap" with zero-coupon structure
    Per ISDA CDM: Qualify_InterestRate_InflationSwap_FixedFloat_ZeroCoupon
    """

    product_type: ProductType = Field(
        default=ProductType.IR_INFLATION_SWAP_ZC, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_amounts: FixedCashflowModel | None = Field(default=None, title="Fixed Amounts", description="Single fixed payment at maturity")
    floating_amounts: InflationRateCashflowModel | None = Field(
        default=None, title="Floating Amounts", description="Single inflation-linked payment at maturity"
    )

    @computed_field
    @property
    def notional_amount(self) -> float | None:
        """Notional amount from the floating leg"""
        if self.floating_amounts:
            return self.floating_amounts.notional_amount
        return None

    @computed_field
    @property
    def notional_currency(self) -> CurrencyId | str | CurrencyModel | None:
        """Notional currency from the floating leg"""
        if self.floating_amounts:
            return self.floating_amounts.notional_currency
        return None

    @computed_field
    @property
    def payer(self) -> CounterpartyRole | None:
        """Party that pays fixed rate (payer in fixed_amounts)"""
        if self.fixed_amounts:
            return self.fixed_amounts.payer
        return None

    @computed_field
    @property
    def receiver(self) -> CounterpartyRole | None:
        """Party that receives fixed rate (receiver in fixed_amounts)"""
        if self.fixed_amounts:
            return self.fixed_amounts.receiver
        return None

    class Config:
        json_schema_extra = {
            "title": "IR Inflation Swap ZC",
            "description": (
                "A zero-coupon inflation swap involves a single payment at maturity from each party. "
                "The fixed leg pays N x [(1 + r)^T - 1] where r is the agreed zero-coupon swap rate and T is the tenor. "
                "The inflation leg pays N x [I(T)/I_base - 1] where I(T) is the CPI index level at maturity and "
                "I_base is the reference index level at inception. Per FpML, this uses productType='InflationSwap' "
                "with a zero-coupon structure (single payment period with compounding)."
            ),
            "example": {
                "productType": "IR_INFLATION_SWAP_ZC",
                "fixedAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalCurrency": "USD",
                    "notionalAmount": 10000000.0,
                    "effectiveDate": "2023-01-15",
                    "terminationDate": "2033-01-15",
                    "paymentDate": "2033-01-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalCurrency": "USD",
                    "notionalAmount": 10000000.0,
                    "effectiveDate": "2023-01-15",
                    "terminationDate": "2033-01-15",
                    "inflationRate": {
                        "rateIndex": "USD_CPI_U",
                        "inflationLag": {"period": "M", "multiplier": 3},
                        "semanticType": "INFLATION_RATE",
                    },
                    "initialIndexLevel": 292.655,
                    "interpolationMethod": "LINEAR",
                    "paymentDaysOffset": {"period": "B", "multiplier": 2},
                    "businessDayConvention": "MODFOLLOWING",
                    "semanticType": "INFLATION_RATE_CASHFLOW",
                },
            },
        }

    semantic_type: Literal["IR_INFLATION_SWAP_ZC"] = Field(default="IR_INFLATION_SWAP_ZC", json_schema_extra={"readOnly": True})


class IRInflationSwapYoYModel(ContractualProductModel):
    """
    Year-on-Year Inflation Swap

    A swap agreement where payments are exchanged periodically (typically annually).
    The fixed leg pays a fixed rate and the inflation leg pays based on the annual
    inflation rate for each period.

    Per FpML: productType = "InflationSwap" with year-on-year structure
    Per ISDA CDM: Qualify_InterestRate_InflationSwap_FixedFloat
    """

    product_type: ProductType = Field(
        default=ProductType.IR_INFLATION_SWAP_YOY, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_amounts: FixedRateCashflowSeriesModel | None = Field(default=None, title="Fixed Amounts", description="Periodic fixed rate payments")
    floating_amounts: InflationRateCashflowSeriesModel | None = Field(default=None, title="Floating Amounts", description="Periodic inflation-linked payments")

    @computed_field
    @property
    def notional_amount(self) -> float | None:
        """Notional amount from the fixed leg"""
        if self.fixed_amounts:
            return self.fixed_amounts.notional_amount
        return None

    @computed_field
    @property
    def notional_currency(self) -> CurrencyId | str | CurrencyModel | None:
        """Notional currency from the fixed leg"""
        if self.fixed_amounts:
            return self.fixed_amounts.notional_currency
        return None

    @computed_field
    @property
    def payer(self) -> CounterpartyRole | None:
        """Party that pays fixed rate (payer in fixed_amounts)"""
        if self.fixed_amounts:
            return self.fixed_amounts.payer
        return None

    @computed_field
    @property
    def receiver(self) -> CounterpartyRole | None:
        """Party that receives fixed rate (receiver in fixed_amounts)"""
        if self.fixed_amounts:
            return self.fixed_amounts.receiver
        return None

    class Config:
        json_schema_extra = {
            "title": "IR Inflation Swap YoY",
            "description": (
                "A year-on-year inflation swap involves periodic payments (typically annual) throughout the swap's life. "
                "The fixed leg pays a fixed rate on each payment date, while the inflation leg pays based on the annual "
                "inflation rate observed for each period. Per FpML, this uses productType='InflationSwap' with a "
                "year-on-year structure (periodic resets and payments)."
            ),
            "example": {
                "productType": "IR_INFLATION_SWAP_YOY",
                "fixedAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "notionalCurrency": "USD",
                    "notionalAmount": 10000000.0,
                    "effectiveDate": "2023-01-15",
                    "terminationDate": "2028-01-15",
                    "fixedRate": {"rate": 0.025},
                    "calculationDateSchedule": {
                        "dayOfMonth": 15,
                        "frequency": {"period": "Y", "multiplier": 1},
                        "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "Y", "multiplier": 1},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2},
                    },
                    "businessDayConvention": "MODFOLLOWING",
                    "dayCountConvention": "ACT/ACT",
                    "semanticType": "FIXED_RATE_CASHFLOW_SERIES",
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalCurrency": "USD",
                    "notionalAmount": 10000000.0,
                    "effectiveDate": "2023-01-15",
                    "terminationDate": "2028-01-15",
                    "inflationRate": {
                        "rateIndex": "USD_CPI_U",
                        "inflationLag": {"period": "M", "multiplier": 3},
                        "semanticType": "INFLATION_RATE",
                    },
                    "interpolationMethod": "LINEAR",
                    "calculationDateSchedule": {
                        "dayOfMonth": 15,
                        "frequency": {"period": "Y", "multiplier": 1},
                        "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "Y", "multiplier": 1},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2},
                    },
                    "businessDayConvention": "MODFOLLOWING",
                    "dayCountConvention": "ACT/ACT",
                    "semanticType": "INFLATION_RATE_CASHFLOW_SERIES",
                },
            },
        }

    semantic_type: Literal["IR_INFLATION_SWAP_YOY"] = Field(default="IR_INFLATION_SWAP_YOY", json_schema_extra={"readOnly": True})


class IRSwapFixedFixedModel(ContractualProductModel):
    product_type: ProductType = Field(
        default=ProductType.IR_SWAP_FIXED_FIXED, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_amounts_1: FixedRateCashflowSeriesModel | None = Field(
        default=None, title="Fixed Amounts 1", description="Terms of the first fixed leg of the interest rate swap"
    )
    fixed_amounts_2: FixedRateCashflowSeriesModel | None = Field(
        default=None, title="Fixed Amounts 2", description="Terms of the second fixed leg of the interest rate swap"
    )

    class Config:
        json_schema_extra = {
            "title": "IR Swap (Fixed-Fixed)",
            "description": "An interest rate swap is a financial contract between two parties to exchange interest payments over a specified period. In a fixed-for-fixed interest rate swap, both parties agree to pay each other fixed interest rates, but on different notional amounts or currencies. Unlike the more common fixed-for-floating swap, where one leg pays a fixed rate and the other pays a floating rate, a fixed-fixed swap involves exchanging fixed payments, often to manage basis risk or currency exposure. Payments are exchanged at regular intervals, with the net difference settled between the parties according to the agreed schedule and terms.",
            "example": {
                "productType": "IR_SWAP_FIXED_FIXED",
                "fixedAmounts1": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "notionalCurrency": "USD",
                    "notionalQuantity": 50000000.0,
                    "holidayCalendar": "USDNY",
                    "businessDayConvention": "MODFOLLOWING",
                    "dayCountConvention": "ACT/360",
                    "fixedRate": {
                        "rate": 0.06,
                    },
                    "calculationDateSchedule": {"dayOfMonth": 15, "frequency": {"period": "M", "multiplier": 3}, "semanticType": "DATE_ROLL_DAY_OF_MONTH"},
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2},
                    },
                },
                "fixedAmounts2": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2023-03-15",
                    "notionalCurrency": "USD",
                    "notionalQuantity": 50000000.0,
                    "holidayCalendar": "USDNY",
                    "businessDayConvention": "MODFOLLOWING",
                    "dayCountConvention": "ACT/360",
                    "fixedRate": {
                        "rate": 0.05,
                    },
                    "calculationDateSchedule": {"dayOfMonth": 15, "frequency": {"period": "M", "multiplier": 3}, "semanticType": "DATE_ROLL_DAY_OF_MONTH"},
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2},
                    },
                },
                "semanticType": "IR_SWAP_FIXED_FIXED",
            },
        }

    semantic_type: Literal["IR_SWAP_FIXED_FIXED"] = Field(default="IR_SWAP_FIXED_FIXED", json_schema_extra={"readOnly": True})


class IRCapModel(ContractualProductModel):
    product_type: ProductType = Field(
        default=ProductType.IR_CAP, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_amounts: FixedCashflowModel | None = Field(
        default=None, title="Fixed Amounts", description="Premium payment from buyer to seller. Typically a single upfront payment."
    )
    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None, title="Floating Amounts", description="Capped floating rate cashflow series. Seller pays max(Rate - Strike, 0) per period."
    )

    class Config:
        json_schema_extra = {
            "title": "IR Cap",
            "description": "An interest rate cap is a derivative contract where the buyer pays an upfront premium and receives payments when the reference floating rate exceeds the cap strike rate. The cap effectively limits the buyer's exposure to rising interest rates. Each period's payment equals max(Rate - Strike, 0) multiplied by the notional and day count fraction. Caps are commonly used to hedge floating rate borrowing costs or limit interest rate risk on variable rate loans.",
            "example": {
                "productType": "IR_CAP",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 500000,
                    "paymentDate": "2022-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2027-03-15",
                    "notionalCurrency": "USD",
                    "notionalAmount": 50000000.0,
                    "dayCountConvention": "ACT/360",
                    "floatingRate": {"rateOption": "USD_SOFR_OIS_COMPOUND", "cap": 0.05, "semanticType": "FLOATING_RATE"},
                    "calculationPeriodDates": {
                        "businessDays": "USNY",
                        "businessDayConvention": "MODFOLLOWING",
                        "dateRollRule": {
                            "frequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                            "dayOfMonth": 15,
                        },
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                        "semanticType": "PAYMENT_DATES_SPECIFICATION",
                    },
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "semanticType": "IR_CAP",
            },
        }

    semantic_type: Literal["IR_CAP"] = Field(default="IR_CAP", json_schema_extra={"readOnly": True})


class IRFloorModel(ContractualProductModel):
    product_type: ProductType = Field(
        default=ProductType.IR_FLOOR, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_amounts: FixedCashflowModel | None = Field(
        default=None, title="Fixed Amounts", description="Premium payment from buyer to seller. Typically a single upfront payment."
    )
    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None, title="Floating Amounts", description="Floored floating rate cashflow series. Seller pays max(Strike - Rate, 0) per period."
    )

    class Config:
        json_schema_extra = {
            "title": "IR Floor",
            "description": "An interest rate floor is a derivative contract where the buyer pays an upfront premium and receives payments when the reference floating rate falls below the floor strike rate. The floor provides a minimum rate guarantee, protecting the buyer against declining interest rates. Each period's payment equals max(Strike - Rate, 0) multiplied by the notional and day count fraction. Floors are commonly used by investors to hedge floating rate investment returns or ensure minimum yields on variable rate assets.",
            "example": {
                "productType": "IR_FLOOR",
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "type": "FIXED_RATE_RETURN",
                    "currency": "USD",
                    "amount": 250000,
                    "paymentDate": "2022-03-17",
                    "semanticType": "FIXED_CASHFLOW",
                },
                "floatingAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "effectiveDate": "2022-03-15",
                    "terminationDate": "2027-03-15",
                    "notionalCurrency": "USD",
                    "notionalAmount": 50000000.0,
                    "dayCountConvention": "ACT/360",
                    "floatingRate": {"rateOption": "USD_SOFR_OIS_COMPOUND", "floor": 0.01, "semanticType": "FLOATING_RATE"},
                    "calculationPeriodDates": {
                        "businessDays": "USNY",
                        "businessDayConvention": "MODFOLLOWING",
                        "dateRollRule": {
                            "frequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                            "semanticType": "DATE_ROLL_DAY_OF_MONTH",
                            "dayOfMonth": 15,
                        },
                    },
                    "paymentDateSchedule": {
                        "paymentFrequency": {"period": "M", "multiplier": 3, "semanticType": "DATE_RELATIVE"},
                        "paymentDaysOffset": {"period": "B", "multiplier": 2, "semanticType": "DATE_RELATIVE"},
                        "semanticType": "PAYMENT_DATES_SPECIFICATION",
                    },
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "semanticType": "IR_FLOOR",
            },
        }

    semantic_type: Literal["IR_FLOOR"] = Field(default="IR_FLOOR", json_schema_extra={"readOnly": True})
