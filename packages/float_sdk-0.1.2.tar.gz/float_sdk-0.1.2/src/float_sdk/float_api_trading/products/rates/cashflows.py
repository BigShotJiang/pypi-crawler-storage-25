#!/usr/bin/env python
# pyright: basic

"""
Cashflow Attributes and Results

"""

from datetime import date
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.assets.base.cashflows import (
    CalculationDateScheduleModel,
    CashflowModel,
    CashflowType,
    NotionalScheduleModel,
    NotionalScheduleRuleModel,
    PaymentDateScheduleModel,
    ResetDatesSpecificationModel,
)
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.rates.rates import FixedRateModel, FloatingRateModel, InflationRateModel
from float_sdk.float_api.base.references import CurrencyId, InflationRateIndexId
from float_sdk.float_api.datetime.conventions import BusinessDayConvention, DayCountConvention
from float_sdk.float_api.datetime.schedule import RelativeDateModel
from float_sdk.float_api.locations.business_centers import BusinessCenter
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.rates.calculations import CalculationPeriodModel, CompoundingMethod
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class ObservableCalculationPeriodModel(CalculationPeriodModel):
    reset_dates: List[date]
    # spread: float
    # multiplier: float


class PaymentPeriodModel(DataModel):
    start_date: date = Field(..., title="Start Date", description="Start date of the payment period")
    end_date: date = Field(..., title="End Date", description="End date of the payment period")
    day_count_fraction: float = Field(..., title="Day Count Fraction", description="Fraction of year for the payment period")
    reference_date: date = Field(..., title="Reference Date", description="Reference date used to compute payment")
    payment_date: date = Field(..., title="Payment Date", description="Date when payment is made")
    calculation_periods: List[CalculationPeriodModel] = Field(
        ..., title="Calculation Periods", description="List of calculation periods included in this payment period"
    )
    amount: float = Field(..., title="Amount", description="Amount to be paid for this payment period")


class CashflowSeriesModel(ContractualProductModel):
    # General terms
    payer: CounterpartyRole | None = Field(default=None, title="Payer", description="Which party is paying recurring cashflows")
    receiver: CounterpartyRole | None = Field(default=None, title="Receiver", description="Which party is receiving recurring cashflows")
    day_count_convention: DayCountConvention | None = Field(
        default=None, title="Day Count Convention", description="Day count convention used for payment calculations"
    )

    # Price quantity
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Notional Currency", description="Notional currency used for recurring cashflows"
    )
    notional_amount: float | None = Field(default=None, title="Notional Amount", description="Base notional amount used to compute cashflows")

    # Notional schedule (optional - for amortizing/accreting notionals)
    notional_schedule_rule: NotionalScheduleRuleModel | None = Field(
        default=None,
        title="Notional Schedule Rule",
        description="Rule specification for generating notional schedule. Preserved for audit trail and regeneration.",
    )
    notional_schedule: NotionalScheduleModel | None = Field(
        default=None,
        title="Notional Schedule",
        description="Locked resolved notional schedule with factors. Factors multiply the base notional_amount.",
    )

    # Calculation period dates
    calculation_period_dates: CalculationDateScheduleModel | None = Field(
        default=None, title="Calculation Period Rule", description="Rule for calculation period frequency and roll"
    )
    # Payment date specification
    payment_date_schedule: PaymentDateScheduleModel | None = Field(
        default=None, title="Payment Date Schedule", description="Payment date schedule specification"
    )

    compounding_method: CompoundingMethod | None = Field(
        default=None,
        title="Compounding Method",
        description="Method for compounding interest across calculation periods within a payment period",
    )


class FixedCashflowModel(CashflowModel):
    payer: CounterpartyRole | None = Field(
        default=None, title="Payer", description="Counterparty which is paying the designated amount to satisfy this cashflow."
    )
    receiver: CounterpartyRole | None = Field(
        default=None, title="Payer", description="Counterparty which is receiving the designated amount to satisfy this cashflow."
    )
    currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Currency", description="The currency in which the cashflow is being paid.")

    type: CashflowType = Field(
        default=CashflowType.FIXED_RATE_RETURN, title="Cashflow Type", description="The type of cashflow which specifies why it is being paid."
    )

    semantic_type: Literal["FIXED_CASHFLOW"] = "FIXED_CASHFLOW"


class FloatingRateCashflowModel(DataModel):
    # General terms
    payer: CounterpartyRole | None = Field(default=None, title="Payer", description="Which party is paying recurring cashflows")
    receiver: CounterpartyRole | None = Field(default=None, title="Receiver", description="Which party is receiving recurring cashflows")

    # Price quantity
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Notional Currency", description="Notional currency used for recurring cashflows"
    )
    notional_amount: float | None = Field(default=None, title="Notional Quantity", description="Notional quantity amount used to compute cashflows")

    # Calculation period dates
    effective_date: date | None = Field(default=None, title="Effective Date", description="Effective date of the contract, used to compute payment schedule")
    termination_date: date | None = Field(default=None, title="Termination Date", description="Date when the contract terminates")

    business_days: BusinessCenter | list[BusinessCenter] | None = Field(
        default=None, title="Business Days", description="Business days for holiday calendar adjustments"
    )
    business_day_convention: BusinessDayConvention | None = Field(
        default=None, title="Business Day Convention", description="Convention for adjusting dates to business days"
    )

    determination_date: date | None = Field(default=None, title="Determination Date", description="Date on which the floating rate cashflow is determined")
    payment_days_offset: RelativeDateModel | None = Field(
        default=None, title="Payment Days Offset", description="Relative date period by which the payment date is computee from the valuation date."
    )

    floating_rate: FloatingRateModel | None = Field(
        default=None,
        title="Floating Rate",
        description="Specification for floating rate, including the rate option, spread, additional cap or floor features, etc. ",
    )

    semantic_type: Literal["IR_FLOATING_CASHFLOW"] = "IR_FLOATING_CASHFLOW"


class FixedRateCashflowSeriesModel(CashflowSeriesModel):
    product_type: ProductType = Field(
        ProductType.IR_FIXED_CASHFLOW, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    fixed_rate: FixedRateModel | None = Field(
        default=None, title="Fixed Rate", description="Specification for fixed rate, including the rate, rounding rules, etc. "
    )
    semantic_type: Literal["IR_FIXED_CASHFLOW_SERIES"] = Field(default="IR_FIXED_CASHFLOW_SERIES", json_schema_extra={"readOnly": True})


class FloatingRateCashflowSeriesModel(CashflowSeriesModel):
    product_type: ProductType = Field(
        ProductType.IR_FLOATING_CASHFLOW, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    floating_rate: FloatingRateModel | None = Field(
        default=None,
        title="Floating Rate",
        description="Specification for floating rate, including the rate option, spread, additional cap or floor features, etc. ",
    )

    reset_dates_specification: ResetDatesSpecificationModel | None = Field(
        default=None, title="Reset Dates Specification", description="Specifies the rules around rate resets as part of the floating rates calculation"
    )

    semantic_type: Literal["IR_FLOATING_CASHFLOW_SERIES"] = Field(default="IR_FLOATING_CASHFLOW_SERIES", json_schema_extra={"readOnly": True})


class InterpolationMethod(DisplayEnum):
    """
    Interpolation Method

    Method for interpolating inflation index values between monthly observations.
    Per FpML specification, linear interpolation is the most common method.

    Attributes
    ----------
    LINEAR : Linear interpolation between two monthly index values
    NONE : No interpolation, use the month's index value directly
    """

    LINEAR = "LINEAR"
    NONE = "NONE"

    def display_names(self) -> dict[str, str]:
        return {
            "LINEAR": "Linear Interpolation",
            "NONE": "No Interpolation",
        }


class InflationRateCashflowModel(FloatingRateCashflowModel):
    """
    Inflation Rate Cashflow

    Single cashflow linked to an inflation index observation.
    Extends FloatingRateCashflowModel following FpML's pattern where
    InflationRateCalculation extends FloatingRateCalculation.

    Per FpML: "Inflation Rate = (Index Final/Index Initial – 1) × 100%"
    """

    inflation_rate: InflationRateModel | None = Field(
        default=None,
        title="Inflation Rate Index",
        description="Specification for inflation rate, including rate index, inflation lag, spread, cap/floor features, etc.",
    )

    initial_index_level: float | None = Field(
        default=None,
        title="Initial Index Level",
        description=(
            "Pre-known index value at trade inception. "
            "Used for zero-coupon inflation swaps where the initial index is fixed at trade date rather than observed with lag."
        ),
    )

    interpolation_method: InterpolationMethod | None = Field(
        default=None,
        title="Interpolation Method",
        description=(
            "Method for interpolating between monthly inflation index values when payment dates don't align with index publication dates. "
            "Typically LINEAR interpolation per market conventions."
        ),
    )

    fallback_bond_applicable: bool | None = Field(
        default=None,
        title="Fallback Bond Applicable",
        description=(
            "Whether fallback bond provisions apply per ISDA 2006 Inflation Derivatives Definitions. "
            "If true, fallback to a referenced inflation-linked bond occurs if the index ceases publication."
        ),
    )

    semantic_type: Literal["IR_INFLATION_CASHFLOW"] = "IR_INFLATION_CASHFLOW"


class InflationRateCashflowSeriesModel(FloatingRateCashflowSeriesModel):
    """
    Inflation Rate Cashflow Series

    Series of cashflows linked to inflation index observations.
    Extends FloatingRateCashflowSeriesModel following FpML's pattern.

    Structure determines swap type (inferred from payment frequency and calculation periods):
    - Zero-Coupon: Single payment at maturity (payment_frequency = termination_date - effective_date)
    - Year-on-Year: Periodic payments (payment_frequency = 1Y, typically)

    Per FpML, the presence of compounding/formula indicates zero-coupon structure,
    while periodic resets indicate year-on-year structure.
    """

    inflation_rate_index: InflationRateIndexId | str | InflationRateModel | None = Field(
        default=None,
        title="Inflation Rate Index",
        description="Specification for inflation rate index, including rate option, inflation lag, spread, cap/floor features, etc.",
    )

    initial_index_level: float | None = Field(
        default=None,
        title="Initial Index Level",
        description=(
            "Pre-known index value at trade inception. "
            "Required for zero-coupon inflation swaps. For year-on-year swaps, the initial index is typically observed with lag."
        ),
    )

    interpolation_method: InterpolationMethod | None = Field(
        default=None,
        title="Interpolation Method",
        description=(
            "Method for interpolating between monthly inflation index values. "
            "Applied when calculation or payment dates don't align with index publication dates."
        ),
    )

    fallback_bond_applicable: bool | None = Field(
        default=None,
        title="Fallback Bond Applicable",
        description="Whether fallback bond provisions apply per ISDA 2006 Inflation Derivatives Definitions.",
    )

    semantic_type: Literal["IR_INFLATION_CASHFLOW_SERIES"] = "IR_INFLATION_CASHFLOW_SERIES"
