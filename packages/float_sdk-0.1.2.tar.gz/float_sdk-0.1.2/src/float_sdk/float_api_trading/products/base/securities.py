#!/usr/bin/env python
# pyright: basic


"""
Cashflow Attributes and Results

"""

from typing import Optional

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.serialization.model import DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class ProductFamily(DisplayEnum):
    """
    Product Family Enumeration
    """

    BOND_ONE_DELTA = "BOND_ONE_DELTA"
    BOND_SWAPS = "BOND_SWAPS"
    BOND_OPTIONS = "BOND_OPTIONS"
    COMMOD_OPTIONS = "COMMOD_OPTIONS"
    EQ_ONE_DELTA = "EQ_ONE_DELTA"
    EQ_OPTIONS = "EQ_OPTIONS"
    EQ_SWAPS = "EQ_SWAPS"
    EQ_STRUCTURED_PRODUCTS = "EQ_STRUCTURED_PRODUCTS"
    FX_ONE_DELTA = "FX_ONE_DELTA"
    FX_SWAPS = "FX_SWAPS"
    FX_OPTIONS = "FX_OPTIONS"
    IR_SWAPS = "IR_SWAPS"
    IR_OPTIONS = "IR_OPTIONS"
    HYBRID_OPTIONS = "HYBRID_OPTIONS"
    GENERIC = "GENERIC"

    # Software
    SOFTWARE = "SOFTWARE"

    def display_names(self) -> dict[str, str]:
        return {
            "BOND_ONE_DELTA": "Bond One Delta",
            "BOND_SWAPS": "Bond Swaps",
            "BOND_OPTIONS": "Bond Options",
            "COMMOD_OPTIONS": "Commodity Options",
            "EQ_ONE_DELTA": "Equity One Delta",
            "EQ_OPTIONS": "Equity Options",
            "EQ_SWAPS": "Equity Swaps",
            "EQ_STRUCTURED_PRODUCTS": "Equity Structured Products",
            "FX_ONE_DELTA": "FX One Delta",
            "FX_OPTIONS": "FX Options",
            "FX_SWAPS": "FX Swaps",
            "IR_OPTIONS": "Interest Rate Options",
            "IR_SWAPS": "Interest Rate Swaps",
            "HYBRID_OPTIONS": "Hybrid Options",
            "GENERIC": "Generic",
            "SOFTWARE": "Software",
        }


class ProductType(DisplayEnum):
    """
    Product Type Enumeration
    """

    ## Equity
    #
    EQ_FORWARD = "EQ_FORWARD"
    EQ_BARRIER_FORWARD = "EQ_BARRIER_FORWARD"
    EQ_OPTION = "EQ_OPTION"
    EQ_BASKET_OPTION = "EQ_BASKET_OPTION"
    EQ_BINARY_OPTION = "EQ_BINARY_OPTION"
    EQ_BARRIER_OPTION = "EQ_BARRIER_OPTION"
    EQ_SWAP_FLOAT = "EQ_SWAP_FLOAT"
    EQ_SWAP_FIXED = "EQ_SWAP_FIXED"
    EQ_VOLATILITY_KNOCKOUT = "EQ_VOLATILITY_KNOCKOUT"
    EQ_VARIANCE_SWAP = "EQ_VARIANCE_SWAP"
    EQ_VOLATILITY_SWAP = "EQ_VOLATILITY_SWAP"
    EQ_CORRELATION_SWAP = "EQ_CORRELATION_SWAP"
    EQ_CONVERTIBLE_ASSET_OPTION = "EQ_CONVERTIBLE_ASSET_OPTION"
    EQ_LOOKBACK_OPTION = "EQ_LOOKBACK_OPTION"
    EQ_ASIAN_OPTION = "EQ_ASIAN_OPTION"
    EQ_BARRIER_LOOKBACK_OPTION = "EQ_BARRIER_LOOKBACK_OPTION"
    EQ_OUTPERFORMANCE_OPTION = "EQ_OUTPERFORMANCE_OPTION"
    EQ_BARRIER_OUTPERFORMANCE_OPTION = "EQ_BARRIER_OUTPERFORMANCE_OPTION"
    EQ_AUTOCALLABLE = "EQ_AUTOCALLABLE"
    EQ_WORST_OF_BASKET_AUTOCALLABLE = "EQ_WORST_OF_BASKET_AUTOCALLABLE"

    ## Commodity
    #
    COMMOD_OPTION = "COMMOD_OPTION"
    COMMOD_BARRIER_OPTION = "COMMOD_BARRIER_OPTION"
    COMMOD_ASIAN_OPTION = "COMMOD_ASIAN_OPTION"
    COMMOD_BINARY_OPTION = "COMMOD_BINARY_OPTION"

    ## FX
    #
    FX_SPOT = "FX_SPOT"
    FX_FORWARD = "FX_FORWARD"
    FX_SWAP = "FX_SWAP"
    FX_OPTION = "FX_OPTION"
    FX_BASKET_OPTION = "FX_BASKET_OPTION"
    FX_KNOCKOUT = "FX_KNOCKOUT"
    FX_DOUBLE_KNOCKOUT = "FX_DOUBLE_KNOCKOUT"
    FX_WINDOW_KNOCKOUT = "FX_WINDOW_KNOCKOUT"
    FX_WINDOW_DOUBLE_KNOCKOUT = "FX_WINDOW_DOUBLE_KNOCKOUT"
    FX_FORWARD_VOLATILITY_AGREEMENT = "FX_FORWARD_VOLATILITY_AGREEMENT"
    FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT = "FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT"
    FX_VOLATILITY_SWAP = "FX_VOLATILITY_SWAP"
    FX_VARIANCE_SWAP = "FX_VARIANCE_SWAP"
    FX_CORRELATION_SWAP = "FX_CORRELATION_SWAP"
    FX_VOLATILITY_KNOCKOUT = "FX_VOLATILITY_KNOCKOUT"

    FX_BINARY_OPTION = "FX_BINARY_OPTION"
    FX_BINARY_KNOCKOUT = "FX_BINARY_KNOCKOUT"
    FX_DOUBLE_BINARY_OPTION = "FX_DOUBLE_BINARY_OPTION"
    FX_MULTI_BINARY_OPTION = "FX_MULTI_BINARY_OPTION"
    FX_BINARY_VOLATILITY_KNOCKOUT = "FX_BINARY_VOLATILITY_KNOCKOUT"
    FX_ONE_TOUCH_BINARY_OPTION = "FX_ONE_TOUCH_BINARY_OPTION"
    FX_DOUBLE_ONE_TOUCH_BINARY_OPTION = "FX_DOUBLE_ONE_TOUCH_BINARY_OPTION"
    FX_DUAL_BINARY_OPTION = "FX_DUAL_BINARY_OPTION"
    FX_DUAL_DOUBLE_BINARY_OPTION = "FX_DUAL_DOUBLE_BINARY_OPTION"
    FX_WORST_OF_OPTION = "FX_WORST_OF_OPTION"
    FX_WORST_OF_KNOCKOUT = "FX_WORST_OF_KNOCKOUT"

    ## RATES
    #
    IR_FIXED_CASHFLOW = "IR_FIXED_CASHFLOW"
    IR_FLOATING_CASHFLOW = "IR_FLOATING_CASHFLOW"
    IR_FIXED_CASHFLOW_SERIES = "IR_FIXED_CASHFLOW_SERIES"
    IR_FLOATING_CASHFLOW_SERIES = "IR_FLOATING_CASHFLOW_SERIES"
    IR_SWAP = "IR_SWAP"
    IR_SWAP_FIXED_FIXED = "IR_SWAP_FIXED_FIXED"
    IR_INFLATION_SWAP_ZC = "IR_INFLATION_SWAP_ZC"
    IR_INFLATION_SWAP_YOY = "IR_INFLATION_SWAP_YOY"
    IR_CAP = "IR_CAP"
    IR_FLOOR = "IR_FLOOR"
    IR_CMS_ONE_LOOK_OPTION = "IR_CMS_ONE_LOOK_OPTION"
    IR_CMS_ONE_LOOK_BARRIER_OPTION = "IR_CMS_ONE_LOOK_BARRIER_OPTION"
    IR_CMS_MULTI_LOOK_OPTION = "IR_CMS_MULTI_LOOK_OPTION"
    IR_CMS_CURVE_ONE_LOOK_OPTION = "IR_CMS_CURVE_ONE_LOOK_OPTION"
    IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION = "IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION"
    IR_CMS_CURVE_ONE_LOOK_CAP = "IR_CMS_CURVE_ONE_LOOK_CAP"
    IR_CMS_CURVE_ONE_LOOK_FLOOR = "IR_CMS_CURVE_ONE_LOOK_FLOOR"
    IR_CMS_CURVE_ONE_LOOK_STRADDLE = "IR_CMS_CURVE_ONE_LOOK_STRADDLE"
    IR_CMS_CURVE_MULTI_LOOK_OPTION = "IR_CMS_CURVE_MULTI_LOOK_OPTION"
    IR_CMS_CURVE_MULTI_LOOK_CAP = "IR_CMS_CURVE_MULTI_LOOK_CAP"
    IR_CMS_CURVE_MULTI_LOOK_FLOOR = "IR_CMS_CURVE_MULTI_LOOK_FLOOR"
    IR_CMS_CURVE_MULTI_LOOK_STRADDLE = "IR_CMS_CURVE_MULTI_LOOK_STRADDLE"
    BOND_FORWARD = "BOND_FORWARD"
    BOND_OPTION = "BOND_OPTION"
    BOND_SWAP_FIXED = "BOND_SWAP_FIXED"
    BOND_SWAP_FLOAT = "BOND_SWAP_FLOAT"
    IR_SWAPTION = "IR_SWAPTION"
    IR_BARRIER_SWAPTION = "IR_BARRIER_SWAPTION"

    ## HYBRID
    #
    HYBRID_KNOCKOUT = "HYBRID_KNOCKOUT"
    HYBRID_DOUBLE_KNOCKOUT = "HYBRID_DOUBLE_KNOCKOUT"
    DUAL_BINARY_OPTION = "DUAL_BINARY_OPTION"
    TRIPLE_BINARY_OPTION = "TRIPLE_BINARY_OPTION"
    DUAL_BINARY_KNOCKOUT = "DUAL_BINARY_KNOCKOUT"
    TRIPLE_BINARY_KNOCKOUT = "TRIPLE_BINARY_KNOCKOUT"

    ## SYSTEM
    #
    GENERIC_PRODUCT = "GENERIC_PRODUCT"
    MULTI_LEG_PRODUCT = "MULTI_LEG_PRODUCT"

    ## TECH
    #
    SOFTWARE_LICENSE_FIXED = "SOFTWARE_LICENSE_FIXED"

    ## DEPRECATED
    IR_SWAP_OLD = "IR_SWAP_OLD"

    def display_names(self) -> dict[str, str]:
        return {
            "GENERIC_PRODUCT": "Generic Product",
            "MULTI_LEG_PRODUCT": "Multi Leg Product",
            #
            # Equity
            #
            "EQ_FORWARD": "Equity Forward",
            "EQ_BARRIER_FORWARD": "Equity Barrier Forward",
            "EQ_OPTION": "Equity Option",
            "EQ_BASKET_OPTION": "Equity Basket Option",
            "EQ_BINARY_OPTION": "Equity Binary Option",
            "EQ_BARRIER_OPTION": "Equity Barrier Option",
            "EQ_SWAP_FLOAT": "Equity Swap Floating",
            "EQ_SWAP_FIXED": "Equity Swap Fixed",
            "EQ_VOLATILITY_KNOCKOUT": "Equity Volatility Knockout",
            "EQ_VARIANCE_SWAP": "Equity Variance Swap",
            "EQ_VOLATILITY_SWAP": "Equity Volatility Swap",
            "EQ_CORRELATION_SWAP": "Equity Correlation Swap",
            "EQ_CONVERTIBLE_ASSET_OPTION": "Equity Convertible Asset Option",
            "EQ_LOOKBACK_OPTION": "Equity Lookback Option",
            "EQ_ASIAN_OPTION": "Equity Asian Option",
            "EQ_BARRIER_LOOKBACK_OPTION": "Equity Barrier Lookback Option",
            "EQ_OUTPERFORMANCE_OPTION": "Equity Outperformance Option",
            "EQ_BARRIER_OUTPERFORMANCE_OPTION": "Equity Barrier Outperformance Option",
            "EQ_AUTOCALLABLE": "Equity Autocallable",
            "EQ_WORST_OF_BASKET_AUTOCALLABLE": "Equity Worst-Of Basket Autocallable",
            #
            # Commodity
            #
            "COMMOD_OPTION": "Commodity Option",
            "COMMOD_BARRIER_OPTION": "Commodity Barrier Option",
            "COMMOD_ASIAN_OPTION": "Commodity Asian Option",
            "COMMOD_BINARY_OPTION": "Commodity Binary Option",
            #
            # FX
            #
            "FX_SPOT": "FX Spot",
            "FX_FORWARD": "FX Forward",
            "FX_SWAP": "FX Swap",
            "FX_OPTION": "FX Option",
            "FX_BASKET_OPTION": "FX Basket Option",
            "FX_BINARY_OPTION": "FX Binary Option",
            "FX_BINARY_KNOCKOUT": "FX Binary Knockout",
            "FX_ONE_TOUCH_BINARY_OPTION": "FX One Touch Binary Option",
            "FX_DOUBLE_ONE_TOUCH_BINARY_OPTION": "FX Double One Touch Binary Option",
            "FX_KNOCKOUT": "FX Knockout",
            "FX_DOUBLE_KNOCKOUT": "FX Double Knockout",
            "FX_WINDOW_KNOCKOUT": "FX Window Knockout",
            "FX_WINDOW_DOUBLE_KNOCKOUT": "FX Window Double Knockout",
            "FX_VOLATILITY_KNOCKOUT": "FX Volatility Knockout",
            "FX_FORWARD_VOLATILITY_AGREEMENT": "FX FVA",
            "FX_KNOCKOUT_FORWARD_VOLATILITY_AGREEMENT": "FX Knockout FVA",
            "FX_VOLATILITY_SWAP": "FX Volatility Swap",
            "FX_VARIANCE_SWAP": "FX Variance Swap",
            "FX_CORRELATION_SWAP": "FX Correlation Swap",
            "FX_BINARY_VOLATILITY_KNOCKOUT": "FX Binary Volatility Knockout",
            "FX_DOUBLE_BINARY_OPTION": "FX Double Binary Option",
            "FX_DUAL_BINARY_OPTION": "FX Dual Binary Option",
            "FX_DUAL_DOUBLE_BINARY_OPTION": "FX Dual Double Binary Option",
            "FX_MULTI_BINARY_OPTION": "FX Multi Binary Option",
            "FX_WORST_OF_OPTION": "FX Worst Of Option",
            "FX_WORST_OF_KNOCKOUT": "FX Worst Of Knockout",
            #
            # Rates
            #
            "IR_FIXED_CASHFLOW": "IR Fixed Cashflow",
            "IR_FLOATING_CASHFLOW": "IR Floating Cashflow",
            "IR_FIXED_CASHFLOW_SERIES": "IR Fixed Cashflow Series",
            "IR_FLOATING_CASHFLOW_SERIES": "IR Floating Cashflow Series",
            "IR_SWAP": "IR Swap",
            "IR_SWAP_FIXED_FIXED": "IR Swap Fixed-Fixed",
            "IR_INFLATION_SWAP_ZC": "IR Inflation Swap Zero Coupon",
            "IR_INFLATION_SWAP_YOY": "IR Inflation Swap Year-on-Year",
            "IR_CAP": "IR Cap",
            "IR_FLOOR": "IR Floor",
            "IR_CMS_ONE_LOOK_OPTION": "IR CMS One Look Option",
            "IR_CMS_ONE_LOOK_BARRIER_OPTION": "IR CMS One Look Barrier Option",
            "IR_CMS_MULTI_LOOK_OPTION": "IR CMS Multi Look Option",
            "IR_CMS_CURVE_ONE_LOOK_OPTION": "IR CMS Curve One Look Option",
            "IR_CMS_CURVE_ONE_LOOK_BARRIER_OPTION": "IR CMS Curve One Look Barrier Option",
            "IR_CMS_CURVE_ONE_LOOK_CAP": "IR CMS Curve One Look Cap",
            "IR_CMS_CURVE_ONE_LOOK_FLOOR": "IR CMS Curve One Look Floor",
            "IR_CMS_CURVE_ONE_LOOK_STRADDLE": "IR CMS Curve One Look Straddle",
            "IR_CMS_CURVE_MULTI_LOOK_OPTION": "IR CMS Curve Multi Look Option",
            "IR_CMS_CURVE_MULTI_LOOK_CAP": "IR CMS Curve Multi Look Cap",
            "IR_CMS_CURVE_MULTI_LOOK_FLOOR": "IR CMS Curve Multi Look Floor",
            "IR_CMS_CURVE_MULTI_LOOK_STRADDLE": "IR CMS Curve Multi Look Straddle",
            "BOND_FORWARD": "Bond Forward",
            "BOND_OPTION": "Bond Option",
            "BOND_SWAP_FIXED": "Bond Swap Fixed",
            "BOND_SWAP_FLOAT": "Bond Swap Floating",
            "IR_SWAPTION": "IR Swaption",
            "IR_BARRIER_SWAPTION": "IR Barrier Swaption",
            #
            # Hybrids
            #
            "HYBRID_KNOCKOUT": "Hybrid Knockout",
            "HYBRID_DOUBLE_KNOCKOUT": "Hybrid Double Knockout",
            "DUAL_BINARY_OPTION": "Dual Binary Option",
            "TRIPLE_BINARY_OPTION": "Triple Binary Option",
            "DUAL_BINARY_KNOCKOUT": "Dual Binary Knockout",
            "TRIPLE_BINARY_KNOCKOUT": "Triple Binary Knockout",
            #
            # Technology
            #
            "SOFTWARE_LICENSE_FIXED": "Software License (Fixed)",
        }


class SecurityProductModel(ResourceModel):
    name: Optional[str] = Field(default=None, description="Name or title of the resource.")
    description: Optional[str] = Field(default=None, description="Text which describes the resource, which can be useful for discovery.")

    product_type: ProductType
