#!/usr/bin/env python
# pyright: basic

"""
Base Option Specifications

"""

from datetime import date, datetime, time
from typing import Literal

from pydantic import Field, computed_field, field_validator, model_validator
from pydash import get

from float_sdk.float_api.assets.base.cashflows import CalculationDateScheduleModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId
from float_sdk.float_api.datetime.schedule import BusinessDateModel, RelativeDateModel
from float_sdk.float_api.locations.location import TimeLocationModel
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.contractual import BarrierEventType, ContractualProductModel, OptionPayout, OptionStyle, OptionType, SingleBarrierModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.settlement.terms import (
    PremiumTermsModel,
    ValidSettlementTypes,
)
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 202, Float Technologies Inc."
__email__ = "andy@float.tech"


class ExerciseTermsModel(DataModel):
    automatic_exercise: bool | None = Field(default=False, title="Automatic Exercise", description="Whether the option is automatically exercised.")


class EuropeanExerciseTermsModel(ExerciseTermsModel):
    semantic_type: Literal["EUROPEAN_EXERCISE_TERMS"] = Field(
        default="EUROPEAN_EXERCISE_TERMS", title="Semantic Type", description="The type of financial instrument."
    )


class AmericanExerciseTermsModel(ExerciseTermsModel):
    first_exercise_date: date | None = Field(default=None, title="First Exercise Date", description="The first date the option is available to be exercised.")
    last_exercise_date: date | None = Field(default=None, title="Last Exercise Date", description="The last date the option is available to be exercised.")

    earliest_exercise_time: TimeLocationModel | None = Field(
        default=None, title="Earliest Exercise Time", description="The earliest time the option can be exercised."
    )
    latest_exercise_time: TimeLocationModel | None = Field(
        default=None, title="Latest Exercise Time", description="The latest time the option can be exercised."
    )
    semantic_type: Literal["AMERICAN_EXERCISE_TERMS"] = Field(
        default="AMERICAN_EXERCISE_TERMS", title="Semantic Type", description="The type of financial instrument."
    )


class BermudanExerciseTermsModel(ExerciseTermsModel):
    """
    Exercise terms for Bermudan-style options.

    Bermudan options can be exercised on predetermined dates during the exercise period.
    Dates can be specified either as an explicit list OR via a calculation schedule.

    For swaptions, exercise dates often align with the underlying swap's calculation
    period dates (e.g., quarterly reset dates).

    Based on ISDA CDM BermudaExercise and FpML BermudaExercise types.

    References:
    - ISDA CDM: BermudaExercise.bermudaExerciseDates (AdjustableOrRelativeDates)
    - FpML 5.x: BermudaExercise complex type
    """

    exercise_dates: list[date] | None = Field(
        default=None,
        title="Exercise Dates",
        description=(
            "Explicit list of Bermuda exercise dates. The last date is the expiration date. "
            "Mutually exclusive with exercise_date_schedule. "
            "Per ISDA CDM bermudaExerciseDates (adjustableDates variant)."
        ),
    )

    exercise_date_schedule: CalculationDateScheduleModel | None = Field(
        default=None,
        title="Exercise Date Schedule",
        description=(
            "Schedule specification to generate exercise dates (e.g., quarterly on the 15th). "
            "Generated schedule periods define when the option can be exercised. "
            "Mutually exclusive with exercise_dates."
        ),
    )

    earliest_exercise_time: TimeLocationModel | None = Field(
        default=None,
        title="Earliest Exercise Time",
        description=(
            "The earliest time at which notice of exercise can be given by the buyer "
            "to the seller on each Bermuda exercise date. "
            "Per ISDA CDM earliestExerciseTime (required)."
        ),
    )

    latest_exercise_time: TimeLocationModel | None = Field(
        default=None,
        title="Latest Exercise Time",
        description=(
            "The latest time on an exercise business day (excluding the expiration date) "
            "when notice can be given. Notice after this time is deemed given on the next "
            "exercise business day. Per ISDA CDM latestExerciseTime (optional)."
        ),
    )

    multiple_exercise: bool | None = Field(
        default=None,
        title="Multiple Exercise",
        description=(
            "Whether the buyer can exercise all or less than all the unexercised "
            "notional amount on one or more exercise dates, subject to min/max constraints. "
            "Per ISDA 2000 Definitions Section 12.4 and ISDA CDM multipleExercise (optional)."
        ),
    )

    semantic_type: Literal["BERMUDAN_EXERCISE_TERMS"] = Field(
        default="BERMUDAN_EXERCISE_TERMS", title="Semantic Type", description="The type of exercise terms."
    )


class OptionPayoutBaseModel(ContractualProductModel):
    buyer: CounterpartyRole | None = Field(
        default=None, title="Buyer", description="The party which will pay the premium to the seller on premmium payment date."
    )
    seller: CounterpartyRole | None = Field(
        default=None, title="Seller", description="The party which will receieve the premium from the buyer on premmium payment date."
    )

    effective_date: date | BusinessDateModel | None = Field(
        default=None, title="Effective Date", description="The date on which the event contractually takes effect"
    )
    expiration_date: date | BusinessDateModel | RelativeDateModel | None = Field(
        default=None,
        title="Expiration Date",
        description="The last day of the terms of the trade. This date may be subject to adjustments in accordance with the business day convention. It can also be specified in relation to another scheduled date (e.g. the last payment date).",
    )
    expiration_time: time | TimeLocationModel | None = Field(default=None, title="Expiration Time", description="Expiration time of option")

    premium_terms: PremiumTermsModel | None = Field(default=None, title="Premium Terms", description="Details of the premium terms.")
    settlement_terms: ValidSettlementTypes | None = Field(default=None, title="Settlement Terms", description="Settlement terms for the underlying asset.")

    @field_validator("expiration_time", mode="before")
    def datetime_to_time(cls, v):
        if isinstance(v, datetime):
            return v.time()
        return v


class OptionBaseModel(OptionPayoutBaseModel):
    notional_amount: float | None = Field(default=None, title="Notional Amount", description="The notional amount of the option")
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Notional Currency", description="The currency of the notional amount"
    )
    option_type: OptionType | None = Field(default=None, title="Option Type", description="Claim type of the option (e.g. Call, Put, etc.)")
    option_style: OptionStyle | None = Field(default=None, title="Option Style", description="Exercise style of option (e.g. European, American, etc.)")
    option_payout: OptionPayout | None = Field(
        default=None, title="Option Payout", description="The payout style of the option (e.g. Vanilla, Binary, etc.)", json_schema_extra={"readOnly": True}
    )
    strike_price: float | None = Field(
        default=None, title="Strike Price", description="Price at which the buyer is obliged to buy or sell the underlying asset."
    )
    exercise_terms: AmericanExerciseTermsModel | EuropeanExerciseTermsModel | BermudanExerciseTermsModel | None = Field(
        default=None,
        title="Exercise Terms",
        description="The terms for exercising the option, which define the exercise procedures for a given option style (e.g. European, American, Bermudan), e.g. manual or automatic exercise, exercise dates, earliest/latest exercise times, etc.",
    )


class BarrierOptionBaseModel(OptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.HYBRID_KNOCKOUT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event")
    barrier: SingleBarrierModel | None = Field(default=None, title="Barrier", description="The terms for the barrier event.")


class BinaryOptionBaseModel(OptionPayoutBaseModel):
    option_style: OptionStyle | None = Field(default=None, title="Option Style", description="The style of the option (e.g. European, American, etc.)")
    option_payout: OptionPayout | None = Field(
        default=OptionPayout.BINARY,
        title="Option Payout",
        description="The payout style of the option (e.g. Vanilla, Binary, etc.)",
        json_schema_extra={"readOnly": True},
    )
    settlement_terms: ValidSettlementTypes | None = Field(default=None, title="Settlement Terms", description="Settlement terms for the underlying asset.")

    @model_validator(mode="before")
    @classmethod
    def convert_legacy_settlement_terms(cls, data):
        """
        Convert legacy SETTLEMENT_TERMS to CASH_SETTLEMENT_TERMS for backward compatibility.

        Binary options always use cash settlement, so any legacy SETTLEMENT_TERMS
        semantic type is automatically converted to CASH_SETTLEMENT_TERMS.
        """
        if isinstance(data, dict):
            settlement_terms = data.get("settlement_terms") or data.get("settlementTerms")
            if isinstance(settlement_terms, dict):
                semantic_type = settlement_terms.get("semantic_type") or settlement_terms.get("semanticType")
                if semantic_type == "SETTLEMENT_TERMS":
                    # Convert to CASH_SETTLEMENT_TERMS
                    settlement_terms["semantic_type"] = "CASH_SETTLEMENT_TERMS"
                    settlement_terms["semanticType"] = "CASH_SETTLEMENT_TERMS"

        return data

    ## Calc fields for reporting
    #
    @computed_field(title="Notional Amount", description="The notional amount of the option, which is equal to the settlement amount.")
    @property
    def notional_amount(self) -> float | None:
        return get(self, "settlement_terms.settlement_amount")

    @computed_field(title="Notional Currency", description="The currency of the option, which is equal to the settlement currency.")
    @property
    def notional_currency(self) -> CurrencyId | str | None:
        return get(self, "settlement_terms.settlement_currency")
