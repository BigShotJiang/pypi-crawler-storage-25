#!/usr/bin/env python
# pyright: basic

"""
Generic product model

"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId, ProductId
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel, QuantityUnit
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.settlement.terms import PremiumTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class GenericProductModel(ContractualProductModel):
    buyer: CounterpartyRole | None = Field(
        default=None, title="Buyer", description="The party which will pay the premium to the seller on premmium payment date."
    )
    seller: CounterpartyRole | None = Field(
        default=None, title="Seller", description="The party which will receieve the premium from the buyer on premmium payment date."
    )
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None, title="Notional Currency", description="The currency of the notional value of the product"
    )
    notional_amount: float | None = Field(default=None, title="Notional Amount", description="The notional value of the product")
    quantity_amount: float | None = Field(
        default=None, title="Quantity Amount", description="The quantity of units (shares, contracts, etc.) for non-notional products"
    )
    unit: QuantityUnit | None = Field(default=None, title="Quantity Unit", description="The unit of measure for the product quantity")
    premium_terms: PremiumTermsModel | None = Field(default=None, title="Premium Terms", description="Premium terms associated wih the product")
    product_type: ProductType = Field(
        default=ProductType.GENERIC_PRODUCT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    product_family: ProductFamily = Field(default=ProductFamily.GENERIC, title="Product Family", description="Family of financial instrument.")

    semantic_type: Literal["GENERIC_PRODUCT"] = Field(
        default="GENERIC_PRODUCT", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Generic Product",
            "description": "A generic product is a baseline instrument that can be used to represent the high level terms a trade which hasn't been mapped to a defined instrument model.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "notionalAmount": 90000000.0,
                "notionalCurrency": "AUD",
                "effectiveDate": "2026-08-21",
                "terminationDate": "2026-10-15",
                "premiumTerms": {
                    "premium": 86000.0,
                    "premiumCurrency": "AUD",
                    "premiumPaymentDate": "2026-08-23",
                    "premiumPayer": "PARTY_2",
                    "semanticType": "PREMIUM_TERMS",
                },
                "productType": "GENERIC_PRODUCT",
                "semanticType": "GENERIC_PRODUCT",
            },
        }


class MultiLegProductModel(NamedResourceModel):
    __uri_path__ = "products"

    product_type: ProductType = Field(
        ProductType.MULTI_LEG_PRODUCT, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    legs: list["ValidProductModel"] = Field(  # pyright: ignore
        default_factory=list, title="Legs", description="List of contractual product models that make up the structured product."
    )

    semantic_type: Literal["MULTI_LEG_PRODUCT"] = Field(
        default="MULTI_LEG_PRODUCT", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    @classmethod
    def init_forward_hints(cls):
        from float_sdk.float_api_trading.products.products import ValidProductModel

        return {"ValidProductModel": ValidProductModel}

    @property
    def resource_id(self) -> ProductId:
        return ProductId(id=self.id, name=self.name, version=self.version, model=self.get_semantic_type())
