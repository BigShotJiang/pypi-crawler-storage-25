# pyright: basic
#!/usr/bin/env python

"""
FX Features for Cross-Asset Derivatives

Defines FX-related features for derivatives products including quanto, composite, and cross-currency FX terms.
Aligned with ISDA CDM FxFeature structure with required choice constraint.

Used across multiple asset classes:
- Equity swaps (PerformancePayout)
- Commodity swaps (CommodityPayout)
- Options (OptionPayout)
"""

from enum import Enum
from typing import Annotated, Literal, Union

from pydantic import Field

from float_sdk.float_api.assets.base.settlement import DeterminationMethod
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel, ExchangeRateModel
from float_sdk.float_api.assets.rates.rates import RateSourceModel, SettlementRateOptionModel, SyntheticSettlementRateOptionModel
from float_sdk.float_api.base.references import CurrencyId, ExchangeRateId, RateSourceId, SettlementRateOptionId
from float_sdk.float_api.locations.location import TimeLocationModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class FxFeatureType(Enum):
    QUANTO = "QUANTO"
    COMPOSITE = "COMPOSITE"
    CROSS_CURRENCY = "CROSS_CURRENCY"


class FxRateModel(DataModel):
    """
    FX exchange rate with currency pair context.

    Aligned with ISDA CDM FxRate type.
    Simplified to use Float's ExchangeRate model for the currency pair.

    CDM Structure:
    - quotedCurrencyPair: QuotedCurrencyPair (required)
    - rate: float (optional)

    Float Structure:
    - exchange_rate: ExchangeRateId | ExchangeRateModel (defines currency pair)
    - rate: float (the actual exchange rate value)
    """

    exchange_rate: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None,
        title="Exchange Rate",
        description="The exchange rate (currency pair) this rate applies to",
    )

    rate: float | None = Field(
        default=None,
        title="Rate",
        description="The rate of exchange between the two currencies",
        gt=0,
    )

    semantic_type: Literal["FX_RATE"] = Field("FX_RATE", title="Semantic Type")

    class Config:
        json_schema_extra = {
            "title": "FX Rate",
            "description": "FX exchange rate with currency pair context",
            "example": {
                "exchangeRate": "JPY/USD",
                "rate": 110.0,
                "semanticType": "FX_RATE",
            },
        }


class FxFeatureBaseModel(DataModel):
    """
    Base class for FX feature types.

    Contains common attributes shared by Quanto, Composite, and CrossCurrency FX mechanisms.
    Used in both pricing and settlement of cross-currency derivatives.

    Attributes
    ----------
    reference_currency : CurrencyId, optional
        The reference currency of the trade (typically the settlement currency)
    rate_option : str, optional
        Standard settlement rate option code (e.g., "EUR/USD-ECB" for ECB FX rate fixing)
    rate_source : RateSourceId | RateSourceModel, optional
        Full rate source specification including fixing time and location
        Used when rate_option is not sufficient or for custom rate sources
    fixing_time : TimeLocationModel, optional
        The time and location at which the FX rate is observed/fixed
    """

    reference_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Reference Currency",
        description="The reference currency of the trade (typically the settlement currency)",
    )

    rate_option: str | None = Field(
        default=None,
        title="Rate Option",
        description="Standard settlement rate option code (e.g., 'EUR/USD-ECB', 'USD/JPY-TOKYO'). Used for officially published FX fixing rates.",
    )

    rate_source: RateSourceId | str | RateSourceModel | None = Field(
        default=None,
        title="Rate Source",
        description="Full rate source specification with fixing time and location. Alternative to rate_option for custom or detailed rate source definitions.",
    )

    fixing_time: TimeLocationModel | None = Field(
        default=None,
        title="Fixing Time",
        description="The time and location at which the FX rate is observed",
    )


class QuantoModel(FxFeatureBaseModel):
    """
    Quanto FX feature - fixes FX rate(s) for cross-currency return calculation.

    Determines the currency rate that the seller of the equity/commodity amounts
    will apply at each valuation date for converting the respective amounts into
    a currency that is different from the currency denomination of the underlier.

    Aligned with ISDA CDM Quanto type.

    CDM Structure: fxRate: FxRate (0..*) - list of FX rates for different periods/pairs

    Example: Japanese equity swap where returns are paid in USD at fixed FX rate(s).
    """

    fx_rates: list[FxRateModel] | None = Field(
        default=None,
        title="FX Rates",
        description="List of fixed FX rates for currency conversion. Each rate includes the currency pair and rate value. Typically one rate, but can have multiple for different periods or reset dates.",
    )

    semantic_type: Literal["QUANTO"] = Field("QUANTO", title="Semantic Type")

    class Config:
        json_schema_extra = {
            "title": "Quanto",
            "description": "Fixed FX rate feature for quanto derivatives, where foreign underlier returns are settled in domestic currency at predetermined exchange rates.",
            "example": {
                "referenceCurrency": "USD",
                "fxRates": [
                    {
                        "exchangeRate": "JPY/USD",
                        "rate": 110.0,
                        "semanticType": "FX_RATE",
                    }
                ],
                "semanticType": "QUANTO",
            },
        }


class CompositeModel(FxFeatureBaseModel):
    """
    Composite FX feature - uses variable FX rates for cross-currency conversion.

    Used when FX rate varies based on market observations rather than being fixed.
    Aligned with ISDA CDM Composite type.

    Typically used for composite settlement where FX conversion uses observed market rates.
    """

    determination_method: DeterminationMethod | None = Field(
        default=None,
        title="Determination Method",
        description="Method for determining FX rate (e.g., VALUATION_TIME, CLOSING_PRICE, TWAP_PRICE, VWAP_PRICE)",
    )

    semantic_type: Literal["COMPOSITE"] = Field("COMPOSITE", title="Semantic Type")

    class Config:
        json_schema_extra = {
            "title": "Composite",
            "description": "Variable FX rate feature for composite FX derivatives, where FX conversion uses observed market rates.",
            "example": {
                "referenceCurrency": "USD",
                "determinationMethod": "CLOSING_PRICE",
                "semanticType": "COMPOSITE",
            },
        }


class CrossCurrencyModel(FxFeatureBaseModel):
    """
    Cross-Currency FX feature - similar to composite but for cross-currency swaps.

    Uses same structure as Composite but represents cross-currency settlement pattern.
    Aligned with ISDA CDM crossCurrency field (which uses Composite type).

    Typically used for cross-currency interest rate swaps and cross-currency equity swaps.
    """

    rate_option: SettlementRateOptionId | str | SettlementRateOptionModel | SyntheticSettlementRateOptionModel | None = Field(
        default=None,
        title="Rate Option",
        description="Settlement rate option for determining the FX fixing rate.",
    )

    determination_method: DeterminationMethod | None = Field(
        default=None,
        title="Determination Method",
        description="Method for determining FX rate (e.g., VALUATION_TIME, CLOSING_PRICE, TWAP_PRICE, VWAP_PRICE)",
    )

    semantic_type: Literal["CROSS_CURRENCY"] = Field("CROSS_CURRENCY", title="Semantic Type")

    class Config:
        json_schema_extra = {
            "title": "Cross-Currency",
            "description": "Cross-currency FX feature for cross-currency derivatives, where FX conversion uses observed market rates.",
            "example": {
                "referenceCurrency": "USD",
                "determinationMethod": "CLOSING_PRICE",
                "semanticType": "CROSS_CURRENCY",
            },
        }


# Discriminated union of FX feature types
# Direct union without wrapper - fx_feature can be Quanto | Composite | CrossCurrency
FxFeatureModel = Annotated[
    Union[QuantoModel, CompositeModel, CrossCurrencyModel],
    Field(discriminator="semantic_type"),
]
