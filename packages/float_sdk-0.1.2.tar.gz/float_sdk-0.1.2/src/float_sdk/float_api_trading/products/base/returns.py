# pyright: basic

"""
Shared Return Terms Models

Common models for performance payouts across asset classes (equity, bonds, FX).
Aligned with ISDA CDM structures.
"""

from datetime import date
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.equities.terms import ReturnType
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"

__all__ = ["ReturnType", "NotionalResetTermsModel"]


######################################################################################
## Notional Reset Terms
######################################################################################


class NotionalResetTermsModel(DataModel):
    """
    Notional reset terms for performance swaps.

    Defines whether and how the notional amount resets based on asset performance.
    Applicable to equity swaps, bond swaps, and other performance-based products.

    Aligned with ISDA CDM notionalReset pattern.

    Attributes
    ----------
    is_applicable : bool, optional
        Whether notional reset is applicable for this payout.
        When true, notional adjusts based on asset price changes at reset dates.
    reset_dates : list[date], optional
        Explicitly specified reset dates when notional is recalculated.
    valuation_price_reset : bool, optional
        Whether to reset the valuation price at each reset date.
        Typically true for notional resetting swaps.
    """

    is_applicable: bool | None = Field(
        default=None,
        title="Is Applicable",
        description="Whether notional reset is applicable. When true, notional adjusts based on asset price changes",
    )

    reset_dates: list[date] | None = Field(
        default=None,
        title="Reset Dates",
        description="Dates when notional amount is recalculated based on asset performance",
    )

    valuation_price_reset: bool | None = Field(
        default=None,
        title="Valuation Price Reset",
        description="Whether to reset the valuation price at each reset date",
    )

    semantic_type: Literal["NOTIONAL_RESET_TERMS"] = "NOTIONAL_RESET_TERMS"
