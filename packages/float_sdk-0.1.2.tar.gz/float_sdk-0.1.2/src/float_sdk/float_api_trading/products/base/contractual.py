#!/usr/bin/env python
# pyright: basic

"""
Contractual product terms

"""

import math
from datetime import date
from enum import Enum
from typing import Literal

from pydantic import Field, computed_field
from pydantic.json_schema import SkipJsonSchema
from pydash import get

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.assets.all import BarrierAssetUnion
from float_sdk.float_api.assets.rates.rates import (
    RateSourceModel,
    SettlementRateOptionModel,
    SyntheticSettlementRateOptionModel,
)
from float_sdk.float_api.base.references import (
    ProductId,
    RateSourceId,
    SettlementRateOptionId,
)
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


def similarity_score(level_1: float | None, level_2: float | None) -> float:
    if level_1 is None or level_2 is None:
        return 0.0

    return math.exp(-abs(level_1 - level_2) / max(abs(level_1), abs(level_2), 1e-9))


class QuantityUnit(DisplayEnum):
    NOTIONAL = "NOTIONAL"
    SHARES = "SHARES"
    OPTIONS = "OPTIONS"
    CONTRACTS = "CONTRACTS"

    def display_names(self) -> dict[str, str]:
        return {
            "NOTIONAL": "Notional",
            "SHARES": "Shares",
            "OPTIONS": "Options",
            "CONTRACTS": "Contracts",
        }


class ContractualProductModel(NamedResourceModel):
    __uri_path__ = "products"

    data_origin: SkipJsonSchema[None] = Field(default=None, exclude=True)

    # Product metadata

    product_type: ProductType = Field(
        ...,
        title="Product Type",
        description="The instrument type, or payoff, which defines the economic structure of the product.",
        json_schema_extra={"readOnly": True},
    )

    # Key Dates
    effective_date: date | None = Field(default=None, title="Effective Date", description="The date on which obligations under the contract become effective.")
    termination_date: date | None = Field(
        default=None, title="Termination Date", description="The date on which obligations under the contract are terminated."
    )

    semantic_type: Literal["CONTRACTUAL_PRODUCT"] = Field(default="CONTRACTUAL_PRODUCT", json_schema_extra={"readOnly": True})

    @property
    def resource_id(self) -> ProductId:
        return ProductId(id=self.id, name=self.name, version=self.version, model=self.get_semantic_type())


class PayReceive(DisplayEnum):
    """
    The Pay Receive enumberation identifies if the party is obligated to pay, or entitled to receive, cashflows

    Attributes
    ----------
    Pay :  Current party / Party 1 pays cashflows
    Receive :  Current party / Party 1 recieves cashflows
    Counterparty (Party 2) has inverse economics
    """

    PAY = "PAY"
    RECEIVE = "RECEIVE"

    def display_names(self) -> dict[str, str]:
        return {
            "PAY": "Pay",
            "RECEIVE": "Receive",
        }

    def inverse(self):
        """
        Inverse
        Return the inverse of the current cashflow direction
        """
        return PayReceive.RECEIVE if self == PayReceive.PAY else PayReceive.PAY


class BuySell(DisplayEnum):
    """
    Identifies if the party is buying or selling the product

    Attributes
    ----------
    BUY : The party buys this instrument, i.e. pays for this instrument and receives
        the rights defined by it.
    SELL : The party that sells ('writes') this instrument, i.e. that grants the rights
        defined by this instrument and in return receives a payment for it.
    """

    BUY = "BUY"
    SELL = "SELL"

    def display_names(self) -> dict[str, str]:
        return {
            "BUY": "Buy",
            "SELL": "Sell",
        }


class OptionType(DisplayEnum):
    """
    Claim type for the option.

    Attributes
    ----------
    CALL : A call option gives the holder the right to buy the underlying asset by a certain date for a certain price.
    PUT : A put option gives the holder the right to sell the underlying asset by a certain date for a certain price.
    """

    CALL = "CALL"
    PUT = "PUT"
    BINARY = "BINARY"  # deprecated

    def display_names(self) -> dict[str, str]:
        return {
            "CALL": "Call",
            "PUT": "Put",
        }


class OptionStyle(DisplayEnum):
    """
    Exercise style of option

    Attributes
    ----------
    EUROPEAN : "European" means a style of the option transaction pursuant to which the right or rights granted are exercisable only on the Expiration Date.
    AMERICAN : "American" means a style of Government Bond Option Transaction pursuant to which the right or rights granted are exercisable during an Exercise Period that consists of more than one day.
    """

    EUROPEAN = "EUROPEAN"
    AMERICAN = "AMERICAN"
    BERMUDAN = "BERMUDAN"

    def display_names(self) -> dict[str, str]:
        return {
            "BERMUDAN": "Bermudan",
            "AMERICAN": "American",
            "EUROPEAN": "European",
        }


class OptionPayout(DisplayEnum):
    """
    Payout style of option

    Attributes
    ----------
    VANILLA : Vanilla Option
    BINARY: Binary Option
    """

    VANILLA = "VANILLA"
    BINARY = "BINARY"

    def display_names(self) -> dict[str, str]:
        return {
            "VANILLA": "Vanilla",
            "BINARY": "Binary",
        }


class TriggerType(DisplayEnum):
    """
    Specifies whether an option will trigger or expire depending upon whether the spot rate is above or below the barrier rate.

    Attributes
    ----------
    EQUAL_OR_LESS : The underlier price must be equal to or less than the Trigger level.
    EQUAL_OR_GREATER : The underlier price must be equal to or greater than the Trigger level.
    EQUAL : The underlier price must be equal to the Trigger level.
    LESS : The underlier price must be less than the Trigger level.
    GREATER : The underlier price must be greater than the Trigger level.
    """

    EQUAL_OR_LESS = "EQUAL_OR_LESS"
    EQUAL_OR_GREATER = "EQUAL_OR_GREATER"
    EQUAL = "EQUAL"
    LESS = "LESS"
    GREATER = "GREATER"

    @property
    def short_name(self) -> str | None:
        map = {
            TriggerType.EQUAL_OR_LESS: "<=",
            TriggerType.EQUAL_OR_GREATER: ">=",
            TriggerType.EQUAL: "=",
            TriggerType.LESS: "<",
            TriggerType.GREATER: ">",
        }

        return map.get(self, None)

    def display_names(self) -> dict[str, str]:
        return {
            "EQUAL_OR_LESS": "Less or Equal",
            "EQUAL_OR_GREATER": "Greater or Equal",
            "EQUAL": "Equal",
            "LESS": "Less",
            "GREATER": "Greater",
        }


class TriggerTimeType(DisplayEnum):
    """
    Specifies the time of day which would be considered for valuing the knock event.

    Attributes
    ----------
    CLOSING : The close of trading on a day would be considered for valuation.
    ANYTIME : At any time during the Knock Determination period (continuous barrier).
    """

    CLOSING = "CLOSING"
    ANYTIME = "ANYTIME"

    def display_names(self) -> dict[str, str]:
        return {
            "CLOSING": "Closing",
            "ANYTIME": "Anytime",
        }


class BarrierType(DisplayEnum):
    SINGLE = "SINGLE"
    DOUBLE = "DOUBLE"

    def display_names(self) -> dict[str, str]:
        return {
            "SINGLE": "Single",
            "DOUBLE": "Double",
        }


class KnockType(DisplayEnum):
    """
    The enumerated values to specify the type of knock.
    """

    KNOCK_IN = "KNOCK_IN"
    KNOCK_OUT = "KNOCK_OUT"

    def display_names(self) -> dict[str, str]:
        return {
            "KNOCK_IN": "Knock In",
            "KNOCK_OUT": "Knock Out",
        }

    def short_name(self) -> str | None:
        map = {
            KnockType.KNOCK_IN: "KI",
            KnockType.KNOCK_OUT: "KO",
        }

        return map.get(self, None)


class BarrierEventType(Enum):
    """
    The enumerated values to specify the type of barrier event.
    """

    KNOCK_IN = "KNOCK_IN"
    KNOCK_OUT = "KNOCK_OUT"
    DOUBLE_KNOCK_IN = "DOUBLE_KNOCK_IN"
    DOUBLE_KNOCK_OUT = "DOUBLE_KNOCK_OUT"
    TRIPLE_KNOCK_IN = "TRIPLE_KNOCK_IN"
    TRIPLE_KNOCK_OUT = "TRIPLE_KNOCK_OUT"
    NO_TOUCH_BINARY = "NO_TOUCH_BINARY"
    ONE_TOUCH_BINARY = "ONE_TOUCH_BINARY"
    DOUBLE_NO_TOUCH_BINARY = "DOUBLE_NO_TOUCH_BINARY"
    DOUBLE_ONE_TOUCH_BINARY = "DOUBLE_ONE_TOUCH_BINARY"

    def short_name(self) -> str | None:
        map = {
            BarrierEventType.KNOCK_IN: "KI",
            BarrierEventType.KNOCK_OUT: "KO",
            BarrierEventType.DOUBLE_KNOCK_IN: "DKI",
            BarrierEventType.DOUBLE_KNOCK_OUT: "DKO",
            BarrierEventType.TRIPLE_KNOCK_IN: "TKI",
            BarrierEventType.TRIPLE_KNOCK_OUT: "TKO",
            BarrierEventType.NO_TOUCH_BINARY: "NT",
            BarrierEventType.ONE_TOUCH_BINARY: "1T",
            BarrierEventType.DOUBLE_NO_TOUCH_BINARY: "DNT",
            BarrierEventType.DOUBLE_ONE_TOUCH_BINARY: "D1T",
        }

        return map.get(self, None)


class ObservationTermsModel(DataModel):
    event_time_type: TriggerTimeType | None = Field(
        default=None,
        title="Event Time Type",
        description="The type of observation to determine the barrier event rate.",
    )
    event_period_start_date: date | None = Field(
        default=None,
        title="Event Period Start Date",
        description="The start date of the period during which the barrier event occurs.",
    )
    event_period_end_date: date | None = Field(
        default=None,
        title="Event Period End Date",
        description="The end date of the period during which the barrier event occurs.",
    )
    rate_option: SettlementRateOptionId | str | SettlementRateOptionModel | SyntheticSettlementRateOptionModel | None = Field(
        default=None, title="Rate Option", description="Settlement rate option to use to observe a fixing for this barrier"
    )
    rate_source: RateSourceId | str | RateSourceModel | None = Field(
        default=None, title="Rate Source", description="Settlement rate source to use to observe a fixing for this barrier"
    )

    semantic_type: Literal["OBSERVATION_TERMS"] = Field(default="OBSERVATION_TERMS", title="Semantic Type")


class BarrierDirection(Enum):
    UP = "UP"
    DOWN = "DOWN"


class TouchCondition(DisplayEnum):
    """
    Specifies whether a touch binary option pays out on touching or not touching the barrier.
    Aligns with FpML touchCondition enumeration.

    Attributes
    ----------
    TOUCH : The option pays out if the barrier is touched during the observation period (knock-in behavior)
    NO_TOUCH : The option pays out if the barrier is not touched during the observation period (knock-out behavior)
    """

    TOUCH = "TOUCH"
    NO_TOUCH = "NO_TOUCH"

    def display_names(self) -> dict[str, str]:
        return {
            "TOUCH": "Touch",
            "NO_TOUCH": "No Touch",
        }

    def to_knock_type(self) -> KnockType:
        """Convert TouchCondition to KnockType for barrier terms"""
        return KnockType.KNOCK_IN if self == TouchCondition.TOUCH else KnockType.KNOCK_OUT

    @classmethod
    def from_knock_type(cls, knock_type: KnockType | None) -> "TouchCondition | None":
        """Convert KnockType to TouchCondition"""
        if knock_type is None:
            return None
        return cls.TOUCH if knock_type == KnockType.KNOCK_IN else cls.NO_TOUCH


class PayoutStyle(DisplayEnum):
    """
    Specifies the timing of payout for touch binary options when the trigger condition is met.
    Aligns with FpML PayoutEnum.

    Only applicable to TOUCH options (one-touch, double-one-touch) where a barrier can be
    triggered during the observation period, providing the choice between immediate settlement
    or deferred settlement to the original value date.

    Not applicable to NO_TOUCH options, which can only be confirmed at expiry.

    Attributes
    ----------
    IMMEDIATE : Payout occurs spot (T+2) from the trigger date when barrier is touched
    DEFERRED : Payout is deferred to the original option's value date (T+2 from expiry)
    """

    IMMEDIATE = "IMMEDIATE"
    DEFERRED = "DEFERRED"

    def display_names(self) -> dict[str, str]:
        return {
            "IMMEDIATE": "Immediate",
            "DEFERRED": "Deferred",
        }


class BaseBarrierTermsModel(DataModel):
    trigger_type: TriggerType | None = Field(default=None, title="Trigger Type", description="Type of the trigger")
    event_type: KnockType | None = Field(default=None, title="Knock Type", description="The type of knock")

    @computed_field(title="Barrier Direction", description="Barrier direction (trade up or down through the barrier)")
    @property
    def direction(self) -> BarrierDirection | None:
        if self.trigger_type in [TriggerType.EQUAL_OR_GREATER, TriggerType.GREATER]:
            return BarrierDirection.UP
        elif self.trigger_type in [TriggerType.EQUAL_OR_LESS, TriggerType.LESS]:
            return BarrierDirection.DOWN
        else:
            return None


class BarrierTermsModel(BaseBarrierTermsModel):
    level: float | None = Field(
        default=None, title="Barrier Level", description="The barrier level, which the underlying asset price must touch / cross to trigger the barrier event."
    )
    semantic_type: Literal["BARRIER_TERMS"] = Field(default="BARRIER_TERMS", title="Semantic Type")

    def match_score(self, other: object) -> float:
        return similarity_score(self.level, get(other, "level"))


class VolatilityBarrierTermsModel(BaseBarrierTermsModel):
    """
    Volatility Barrier

    A volatility barrier is a type of threshold used in financial derivatives, typically in options trading,
    where the option is triggered or deactivated based on the underlying asset's volatility reaching or
    crossing a specified level. For barrier options, volatility barriers determine if and when the option
    becomes active (knock-in) or inactive (knock-out). They are often used in complex risk management strategies,
    helping to control exposure to extreme volatility events without the asset price crossing a specific barrier.
    """

    reference_volatility: float | None = Field(
        default=None,
        title="Reference Volatility",
        description="The reference volatility level at which the barrier is triggered.",
    )

    # https://www.newyorkfed.org/medialibrary/microsites/fxc/files/2011/fxc060811d.pdf

    mean_adjustment: bool | None = Field(
        default=None,
        title="Mean Adjustment",
        description="Adjusts the returns used in the realized volatility calculation by subtracting the mean return over the obsercation period",
    )

    expected_n: int | None = Field(default=None, title="Expected N", description="Expected number of trading days over the observation period.")
    annualization_factor: int | None = Field(
        default=None,
        title="Annualization Factor",
        description="This specifies the numerator of an annualization factor. Frequently this number is equal to the number of observations of prices in a year e.g. 252, or weeks in a year, e.g. 52.",
    )

    def match_score(self, other: object) -> float:
        return 1 if self.reference_volatility == get(other, "reference_volatility") else 0

    semantic_type: Literal["VOLATILITY_BARRIER_TERMS"] = Field(default="VOLATILITY_BARRIER_TERMS", title="Semantic Type")


class BaseBarrierModel(DataModel):
    asset: BarrierAssetUnion = Field(default=None, title="Asset", description="The asset to be observed for the barrier event.")

    observation_terms: ObservationTermsModel | None = Field(default=None, title="Observation Terms", description="The terms for the observation of the event.")
    barrier_determination_agent: CounterpartyRole | None = Field(
        default=None,
        title="Barrier Determination Agent",
        description="The party that determines whether specific conditions related to the barrier event have been met.",
    )

    def match_score(self, other: "BaseBarrierModel") -> float:
        return 1 if self.asset == other.asset else 0


class SingleBarrierModel(BaseBarrierModel):
    barrier_terms: BarrierTermsModel | VolatilityBarrierTermsModel | None = Field(
        default=None, title="Barrier Terms", description="The terms for the barrier event."
    )

    def match_score(self, other: "BaseBarrierModel") -> float:
        score = super().match_score(other)

        if isinstance(other, SingleBarrierModel):
            score += self.barrier_terms.match_score(other.barrier_terms) if self.barrier_terms else 0

        return score

    semantic_type: Literal["SINGLE_BARRIER_MODEL"] = Field(default="SINGLE_BARRIER_MODEL", title="Semantic Type")


class DoubleBarrierModel(BaseBarrierModel):
    upper_barrier_terms: BarrierTermsModel | None = Field(default=None, title="Upper Barrier Terms", description="The terms for the upper barrier event.")
    lower_barrier_terms: BarrierTermsModel | None = Field(default=None, title="Lower Barrier Terms", description="The terms for the lower barrier event.")

    def match_score(self, other: "BaseBarrierModel") -> float:
        score = super().match_score(other)

        if isinstance(other, DoubleBarrierModel):
            score += self.lower_barrier_terms.match_score(other.lower_barrier_terms) if self.lower_barrier_terms else 0
            score += self.upper_barrier_terms.match_score(other.upper_barrier_terms) if self.upper_barrier_terms else 0

        return score

    semantic_type: Literal["DOUBLE_BARRIER_MODEL"] = Field(default="DOUBLE_BARRIER_MODEL", title="Semantic Type")


class LookbackType(DisplayEnum):
    FLOATING_STRIKE = "FLOATING_STRIKE"
    FIXED_STRIKE = "FIXED_STRIKE"

    def display_names(self) -> dict[str, str]:
        return {
            "FLOATING_STRIKE": "Floating Strike",
            "FIXED_STRIKE": "Fixed Strike",
        }


class AveragingInOut(DisplayEnum):
    IN = "IN"
    OUT = "OUT"
    BOTH = "BOTH"

    def display_names(self) -> dict[str, str]:
        return {
            "IN": "In",
            "OUT": "Out",
            "BOTH": "Both",
        }


class AveragingCalculationMethod(DisplayEnum):
    ARITHMETIC = "ARITHMETIC"
    GEOMETRIC = "GEOMETRIC"
    HARMONIC = "HARMONIC"

    def display_names(self) -> dict[str, str]:
        return {
            "ARITHMETIC": "Arithmetic",
            "GEOMETRIC": "Geometric",
            "HARMONIC": "Harmonic",
        }


class LookbackTermsModel(DataModel):
    lookback_type: LookbackType | None = Field(
        default=None,
        title="Lookback Type",
        description="Specifies whether the lookback option uses a floating strike or fixed strike.",
    )
    initial_price: float | None = Field(
        default=None,
        title="Initial Price",
        description="The reference price at trade inception used as the baseline for the lookback observation. Aligns with FpML equityValuation/initialPrice and CDM PriceReturnTerms.initialPrice.",
    )
    strike_percentage: float | None = Field(
        default=None,
        title="Strike Percentage",
        description="The percentage of the extreme price used to determine the strike (e.g., 1.0 = 100% of observed min/max).",
    )
    observation_terms: ObservationTermsModel | None = Field(
        default=None,
        title="Observation Terms",
        description="The terms governing the observation period and timing for the lookback.",
    )

    semantic_type: Literal["LOOKBACK_TERMS"] = Field(default="LOOKBACK_TERMS", title="Semantic Type")


class AveragingTermsModel(DataModel):
    averaging_in_out: AveragingInOut | None = Field(
        default=None,
        title="Averaging In/Out",
        description="Specifies whether averaging applies to the strike (IN), the settlement price (OUT), or both.",
    )
    calculation_method: AveragingCalculationMethod | None = Field(
        default=None,
        title="Calculation Method",
        description="The method used to compute the average (arithmetic, geometric, or harmonic).",
    )
    initial_price: float | None = Field(
        default=None,
        title="Initial Price",
        description="The reference price at trade inception used as the baseline for the averaging calculation. Aligns with FpML equityValuation/initialPrice and CDM PriceReturnTerms.initialPrice.",
    )
    strike_factor: float | None = Field(
        default=None,
        title="Strike Factor",
        description="A factor applied to the average price to determine the effective strike or settlement level.",
    )
    observation_terms: ObservationTermsModel | None = Field(
        default=None,
        title="Observation Terms",
        description="The terms governing the observation period and timing for the averaging.",
    )

    semantic_type: Literal["AVERAGING_TERMS"] = Field(default="AVERAGING_TERMS", title="Semantic Type")


class DeterminationMethod(Enum):
    """
    Method for determining FX rate in composite or cross-currency features.

    Aligned with ISDA CDM DeterminationMethodEnum (subset of most common values).

    Full CDM enum location: isda_cdm/distribution/observable/common/enum.py
    Full CDM has 15 values - we include the most relevant for equity/commodity derivatives.

    Attributes
    ----------
    VALUATION_TIME : Price determined at valuation time
    CLOSING_PRICE : Official closing price
    TWAP_PRICE : Official TWAP (Time-Weighted Average Price)
    VWAP_PRICE : Official VWAP (Volume-Weighted Average Price)
    CALCULATION_AGENT : Determined by the calculation agent
    HEDGE_EXECUTION : Determined by the hedging party
    """

    VALUATION_TIME = "VALUATION_TIME"
    CLOSING_PRICE = "CLOSING_PRICE"
    TWAP_PRICE = "TWAP_PRICE"
    VWAP_PRICE = "VWAP_PRICE"
    CALCULATION_AGENT = "CALCULATION_AGENT"
    HEDGE_EXECUTION = "HEDGE_EXECUTION"
