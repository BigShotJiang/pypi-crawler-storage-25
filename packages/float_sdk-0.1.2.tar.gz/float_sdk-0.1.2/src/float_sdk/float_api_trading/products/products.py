#!/usr/bin/env python
# pyright: basic

"""
Product Types

"""

from typing import Annotated, Literal, Self, Union

from pydantic import Field
from pydash import get

from float_sdk.float_api.assets.rates.rates import FloatingRateOptionModel, InflationRateOptionModel
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.generic import GenericProductModel, MultiLegProductModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.commodities.options import (
    CommodityAsianOptionModel,
    CommodityBarrierOptionModel,
    CommodityBinaryOptionModel,
    CommodityOptionModel,
)
from float_sdk.float_api_trading.products.credit.bonds import BondForwardModel
from float_sdk.float_api_trading.products.credit.options import BondOptionModel
from float_sdk.float_api_trading.products.credit.swaps import BondSwapFixedModel, BondSwapFloatModel
from float_sdk.float_api_trading.products.equities.autocallables import EqAutocallableModel, EqWorstOfBasketAutocallableModel
from float_sdk.float_api_trading.products.equities.options import (
    EqAsianOptionModel,
    EqBarrierForwardModel,
    EqBarrierLookbackOptionModel,
    EqBarrierOptionModel,
    EqBarrierOutperformanceOptionModel,
    EqBasketOptionModel,
    EqBinaryOptionModel,
    EqForwardModel,
    EqLookbackOptionModel,
    EqOptionModel,
    EqOutperformanceOptionModel,
    EqVolatilityKnockoutModel,
)
from float_sdk.float_api_trading.products.equities.swaps import (
    EqCorrelationSwapModel,
    EqSwapFixedModel,
    EqSwapFloatModel,
    EqVarianceSwapModel,
    EqVolatilitySwapModel,
)
from float_sdk.float_api_trading.products.fx.delta_one import FXForwardModel, FXSpotModel, FXSwapModel
from float_sdk.float_api_trading.products.fx.options import (
    FXBasketOptionModel,
    FXBinaryKnockoutModel,
    FXBinaryOptionModel,
    FXBinaryVolatilityKnockoutModel,
    FXDoubleBinaryOptionModel,
    FXDoubleKnockoutModel,
    FXDoubleOneTouchBinaryOptionModel,
    FXDualBinaryOptionModel,
    FXDualDoubleBinaryOptionModel,
    FXForwardVolatilityAgreementModel,
    FXKnockoutForwardVolatilityAgreementModel,
    FXKnockoutModel,
    FXMultiBinaryOptionModel,
    FXOneTouchBinaryOptionModel,
    FXOptionModel,
    FXVolatilityKnockoutModel,
    FXWindowDoubleKnockoutModel,
    FXWindowKnockoutModel,
    FXWorstOfKnockoutModel,
    FXWorstOfOptionModel,
)
from float_sdk.float_api_trading.products.fx.swaps import FXCorrelationSwapModel, FXVarianceSwapModel, FXVolatilitySwapModel
from float_sdk.float_api_trading.products.hybrid.options import (
    DualBinaryKnockoutModel,
    DualBinaryOptionModel,
    HybridDoubleKnockoutModel,
    HybridKnockoutModel,
    TripleBinaryKnockoutModel,
    TripleBinaryOptionModel,
)
from float_sdk.float_api_trading.products.rates.cashflows import (
    FixedRateCashflowSeriesModel,
    FloatingRateCashflowSeriesModel,
)
from float_sdk.float_api_trading.products.rates.options import (
    IRBarrierSwaptionModel,
    IRCMSCurveMultiLookCapModel,
    IRCMSCurveMultiLookFloorModel,
    IRCMSCurveMultiLookOptionModel,
    IRCMSCurveMultiLookStraddleModel,
    IRCMSCurveOneLookBarrierOptionModel,
    IRCMSCurveOneLookCapModel,
    IRCMSCurveOneLookFloorModel,
    IRCMSCurveOneLookOptionModel,
    IRCMSCurveOneLookStraddleModel,
    IRCMSMultiLookOptionModel,
    IRCMSOneLookBarrierOptionModel,
    IRCMSOneLookOptionModel,
    IRSwaptionModel,
)
from float_sdk.float_api_trading.products.rates.swaps import IRCapModel, IRFloorModel, IRInflationSwapYoYModel, IRInflationSwapZCModel, IRSwapModel
from float_sdk.float_api_trading.products.tech.software import SoftwareLicenseFixedModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


ValidObservable = Annotated[Union[FloatingRateOptionModel, InflationRateOptionModel], Field(discriminator="semantic_type")]

ValidProductModelUnion = Union[
    GenericProductModel,
    MultiLegProductModel,
    #
    ## Equities
    #
    # EqStockModel,
    EqForwardModel,
    EqBarrierForwardModel,
    EqSwapFloatModel,
    EqSwapFixedModel,
    EqOptionModel,
    EqBasketOptionModel,
    EqBinaryOptionModel,
    EqBarrierOptionModel,
    EqVolatilityKnockoutModel,
    EqLookbackOptionModel,
    EqAsianOptionModel,
    EqBarrierLookbackOptionModel,
    EqOutperformanceOptionModel,
    EqBarrierOutperformanceOptionModel,
    EqVarianceSwapModel,
    EqVolatilitySwapModel,
    EqCorrelationSwapModel,
    EqAutocallableModel,
    EqWorstOfBasketAutocallableModel,
    #
    ## FX
    #
    FXSpotModel,
    FXForwardModel,
    FXSwapModel,
    FXOptionModel,
    FXBasketOptionModel,
    FXKnockoutModel,
    FXDoubleKnockoutModel,
    FXWindowKnockoutModel,
    FXWindowDoubleKnockoutModel,
    FXForwardVolatilityAgreementModel,
    FXKnockoutForwardVolatilityAgreementModel,
    FXBinaryOptionModel,
    FXBinaryKnockoutModel,
    FXOneTouchBinaryOptionModel,
    FXDoubleOneTouchBinaryOptionModel,
    FXDoubleBinaryOptionModel,
    FXMultiBinaryOptionModel,
    FXDualBinaryOptionModel,
    FXDualDoubleBinaryOptionModel,
    FXVolatilityKnockoutModel,
    FXBinaryVolatilityKnockoutModel,
    FXWorstOfOptionModel,
    FXWorstOfKnockoutModel,
    FXVarianceSwapModel,
    FXVolatilitySwapModel,
    FXCorrelationSwapModel,
    #
    ## Rates
    #
    FixedRateCashflowSeriesModel,
    FloatingRateCashflowSeriesModel,
    IRSwapModel,
    IRInflationSwapZCModel,
    IRInflationSwapYoYModel,
    IRCapModel,
    IRFloorModel,
    IRSwaptionModel,
    IRBarrierSwaptionModel,
    IRCMSOneLookOptionModel,
    IRCMSOneLookBarrierOptionModel,
    IRCMSMultiLookOptionModel,
    IRCMSCurveOneLookOptionModel,
    IRCMSCurveOneLookBarrierOptionModel,
    IRCMSCurveOneLookCapModel,
    IRCMSCurveOneLookFloorModel,
    IRCMSCurveOneLookStraddleModel,
    IRCMSCurveMultiLookOptionModel,
    IRCMSCurveMultiLookCapModel,
    IRCMSCurveMultiLookFloorModel,
    IRCMSCurveMultiLookStraddleModel,
    #
    ## Commodities
    #
    CommodityOptionModel,
    CommodityBarrierOptionModel,
    CommodityAsianOptionModel,
    CommodityBinaryOptionModel,
    #
    ## Credit
    #
    BondForwardModel,
    BondOptionModel,
    BondSwapFixedModel,
    BondSwapFloatModel,
    #
    ## Tech
    #
    SoftwareLicenseFixedModel,
    #
    ## Hybrid
    #
    DualBinaryOptionModel,
    TripleBinaryOptionModel,
    DualBinaryKnockoutModel,
    TripleBinaryKnockoutModel,
    HybridKnockoutModel,
    HybridDoubleKnockoutModel,
]

ValidProductModel = Annotated[
    ValidProductModelUnion,
    Field(discriminator="semantic_type"),
]


class ProductDefinitionModel(DataModel):
    name: str | None = Field(default=None, title="Name", description="The name of the product")
    description: str | None = Field(default=None, title="Description", description="The description of the product")
    product_type: ProductType | None = Field(default=None, title="Product Type", description="The type of product")

    semantic_type: Literal["PRODUCT_DEFINITION"] = "PRODUCT_DEFINITION"

    @classmethod
    def from_product_model(cls, product_model: ValidProductModel) -> Self:
        config = get(product_model, "Config.json_schema_extra")

        return cls(
            name=get(config, "title"),
            description=get(config, "description"),
            product_type=product_model.model_fields["product_type"].default,
        )
