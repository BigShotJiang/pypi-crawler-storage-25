# pyright: basic
#!/usr/bin/env python

"""
Collateral Terms

"""

from datetime import date
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class IndependentAmountModel(DataModel):
    """
    Indepdendent Amount Terms

    Defines the payment terms which apply to transfers of an initial margin payment
    """

    payment_date: date | None = Field(default=None, title="Payment Date", description="Date of the payment")
    payment_amount: float | None = Field(default=None, title="Payment Amount", description="Amount of the payment")
    payment_currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Payment Currency", description="Currency of the payment")
    payer: CounterpartyRole | None = Field(default=None, title="Premium Payer", description="Party which is paying the premium")

    semantic_type: Literal["INDEPENDENT_AMOUNT", "INDEPDENENT_AMOUNT"] = Field(default="INDEPENDENT_AMOUNT", title="Semantic Type")


class CollateralTermsModel(DataModel):
    """
    Collateral Terms

    Defines the collateral terms which apply to transfers of cash or securities
    to satisfy margin requirements for contractual trades. For example, payment
    of an Independent Amount (IA)
    """

    independent_amount: IndependentAmountModel | None = Field(default=None, title="Independent Amount", description="Terms for Independent Amount")

    semantic_type: Literal["COLLATERAL_TERMS"] = Field(default="COLLATERAL_TERMS", title="Semantic Type")
