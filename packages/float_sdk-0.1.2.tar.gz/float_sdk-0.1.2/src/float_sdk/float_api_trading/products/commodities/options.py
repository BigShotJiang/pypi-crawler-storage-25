# pyright: basic
#!/usr/bin/env python
# pyright: basic

"""
Commodity Option Specifications

"""

from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.assets.commodities.commodities import CommodityModel, CommodityReferencePrice
from float_sdk.float_api.base.references import CommodityId
from float_sdk.float_api.base.units import ValidUnit
from float_sdk.float_api_trading.products.base.contractual import (
    AveragingTermsModel,
    BarrierEventType,
    OptionType,
)
from float_sdk.float_api_trading.products.base.options import BarrierOptionBaseModel, BinaryOptionBaseModel, OptionBaseModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class CommodityOptionBaseModel(OptionBaseModel):
    buyer: CounterpartyRole | None = Field(
        default=None, title="Buyer", description="The party which will pay the premium to the seller on premium payment date."
    )
    seller: CounterpartyRole | None = Field(
        default=None, title="Seller", description="The party which will receive the premium from the buyer on premium payment date."
    )

    asset: CommodityId | str | CommodityModel | None = Field(default=None, title="Asset", description="The underlying commodity for the option.")
    notional_quantity: float | None = Field(
        default=None,
        title="Notional Quantity",
        description="The notional quantity of the commodity, expressed in Units of Commodity (ISDA 2005 Commodity Definitions).",
    )
    quantity_unit: ValidUnit | None = Field(
        default=None, title="Quantity Unit", description="The unit of measurement for the notional quantity (e.g., barrels, troy ounces, MWh)."
    )
    fixing_source: CommodityReferencePrice | None = Field(
        default=None, title="Fixing Source", description="The ISDA commodity reference price benchmark used for settlement or fixing."
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.COMMODITY

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.COMMOD_OPTIONS


class CommodityOptionModel(CommodityOptionBaseModel):
    product_type: ProductType = Field(
        ProductType.COMMOD_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    semantic_type: Literal["COMMOD_OPTION"] = Field(
        default="COMMOD_OPTION", title="Semantic Type", description="The type of resource which is being serialized.", json_schema_extra={"readOnly": True}
    )

    class Config:
        json_schema_extra = {
            "title": "Commodity Option",
            "description": "An OTC commodity option is a bilateral derivative contract in which the buyer obtains the right, but not the obligation, to buy (call) or sell (put) a specified quantity of a commodity at a predetermined strike price per unit on or before a defined expiration date. Unlike exchange-traded options, OTC commodity options are privately negotiated between counterparties, allowing for customized terms including quantity, delivery point, pricing source, and settlement conditions. These contracts are typically governed by ISDA 2005 Commodity Definitions and may be cash-settled against a commodity reference price or physically settled.",
            "example": {
                "name": "CMO GOLD CALL 1850.00 15JUL24",
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "Gold",
                "notionalQuantity": 1000,
                "quantityUnit": "oz t",
                "fixingSource": "GOLD-P.M. FIX",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1850.00,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {
                    "time": "15:00:00",
                    "location": "GBLO",
                },
                "premiumTerms": {
                    "premium": 125000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_1",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementDate": "2024-07-17",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "COMMOD_OPTION",
                "productFamily": "COMMOD_OPTIONS",
                "semanticType": "COMMOD_OPTION",
            },
        }


class CommodityBarrierOptionModel(BarrierOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.COMMOD_BARRIER_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: CommodityId | str | CommodityModel | None = Field(default=None, title="Asset", description="The underlying commodity for the option.")
    notional_quantity: float | None = Field(
        default=None,
        title="Notional Quantity",
        description="The notional quantity of the commodity, expressed in Units of Commodity (ISDA 2005 Commodity Definitions).",
    )
    quantity_unit: ValidUnit | None = Field(
        default=None, title="Quantity Unit", description="The unit of measurement for the notional quantity (e.g., barrels, troy ounces, MWh)."
    )
    fixing_source: CommodityReferencePrice | None = Field(
        default=None, title="Fixing Source", description="The ISDA commodity reference price benchmark used for settlement or fixing."
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.COMMODITY

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.COMMOD_OPTIONS

    semantic_type: Literal["COMMOD_BARRIER_OPTION"] = Field(
        default="COMMOD_BARRIER_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Commodity Barrier Option",
            "description": "A commodity barrier option is a path-dependent derivative where the option's validity or payout is contingent on the underlying commodity price crossing a predefined barrier level during the option's life. These options can be knock-in (activating upon breaching the barrier) or knock-out (becoming worthless if the barrier is breached). Commonly used for energy, metals, and agricultural commodities, barrier options are typically OTC instruments governed by ISDA 2005 Commodity Definitions with customized barrier levels, observation periods, and settlement terms.",
            "example": {
                "name": "CMKO GOLD CALL 1850.00 KO 2000 15JUL24",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "Gold",
                "notionalQuantity": 1000,
                "quantityUnit": "oz t",
                "fixingSource": "GOLD-P.M. FIX",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1850.00,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {
                    "time": "15:00:00",
                    "location": "GBLO",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_OUT",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 2000,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "premiumTerms": {
                    "premium": 90000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementDate": "2024-07-17",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "COMMOD_BARRIER_OPTION",
                "productFamily": "COMMOD_OPTIONS",
                "semanticType": "COMMOD_BARRIER_OPTION",
            },
        }


class CommodityAsianOptionModel(CommodityOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.COMMOD_ASIAN_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    averaging_terms: AveragingTermsModel | None = Field(
        default=None, title="Averaging Terms", description="The averaging terms defining the calculation method and observation schedule."
    )
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None, title="Settlement Terms", description="Cash settlement terms. Asian options are always cash-settled."
    )

    semantic_type: Literal["COMMOD_ASIAN_OPTION"] = Field(
        default="COMMOD_ASIAN_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Commodity Asian Option",
            "description": "A commodity Asian option is a path-dependent exotic option where the payoff depends on the average price of the underlying commodity over a specified observation period rather than the spot price at expiration. Average-price options are extremely common in commodity markets (oil, metals, natural gas) because producers and consumers often hedge exposures tied to periodic pricing (e.g., monthly average oil price). Asian options reduce the impact of price manipulation and short-term volatility. Governed by ISDA 2005 Commodity Definitions.",
            "example": {
                "name": "CMAS GOLD CALL 1850.00 OUT 15JAN25",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "Gold",
                "notionalQuantity": 1000,
                "quantityUnit": "oz t",
                "fixingSource": "GOLD-P.M. FIX",
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 1850.00,
                "effectiveDate": "2024-01-15",
                "expirationDate": "2025-01-15",
                "expirationTime": {"time": "15:00:00", "location": "GBLO", "semanticType": "TIME_LOCATION"},
                "averagingTerms": {
                    "averagingInOut": "OUT",
                    "calculationMethod": "ARITHMETIC",
                    "initialPrice": 1850.00,
                    "strikeFactor": 1.0,
                    "observationTerms": {
                        "eventPeriodStartDate": "2024-01-15",
                        "eventPeriodEndDate": "2025-01-15",
                        "eventTimeType": "CLOSING",
                        "semanticType": "OBSERVATION_TERMS",
                    },
                    "semanticType": "AVERAGING_TERMS",
                },
                "premiumTerms": {
                    "premium": 80000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-01-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementCurrency": "USD",
                    "settlementDate": "2025-01-17",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "COMMOD_ASIAN_OPTION",
                "productFamily": "COMMOD_OPTIONS",
                "semanticType": "COMMOD_ASIAN_OPTION",
            },
        }


class CommodityBinaryOptionModel(BinaryOptionBaseModel):
    product_type: ProductType = Field(
        default=ProductType.COMMOD_BINARY_OPTION, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )
    asset: CommodityId | str | CommodityModel | None = Field(default=None, title="Asset", description="The underlying commodity for the option.")
    notional_quantity: float | None = Field(
        default=None,
        title="Notional Quantity",
        description="The notional quantity of the commodity, expressed in Units of Commodity (ISDA 2005 Commodity Definitions).",
    )
    quantity_unit: ValidUnit | None = Field(
        default=None, title="Quantity Unit", description="The unit of measurement for the notional quantity (e.g., barrels, troy ounces, MWh)."
    )
    fixing_source: CommodityReferencePrice | None = Field(
        default=None, title="Fixing Source", description="The ISDA commodity reference price benchmark used for settlement or fixing."
    )
    event_type: BarrierEventType | None = Field(default=None, title="Event Type", description="The type of barrier event.")
    option_type: OptionType | None = Field(default=None, title="Option Type", description="Claim type of the option (e.g. Call, Put, etc.)")
    strike_price: float | None = Field(default=None, title="Strike Price", description="Price per unit at which the binary payout is triggered.")

    semantic_type: Literal["COMMOD_BINARY_OPTION"] = Field(
        default="COMMOD_BINARY_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.COMMODITY

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.COMMOD_OPTIONS

    class Config:
        json_schema_extra = {
            "title": "Commodity Binary Option",
            "description": "A commodity binary option is a financial derivative that pays out a fixed amount or nothing based on the price of an underlying commodity reaching or exceeding a predetermined threshold (strike price) at expiration. The binary nature means the outcome is all-or-nothing, with no intermediate payouts. Common for energy and metals markets where binary payoff structures are used for event-driven hedging.",
            "example": {
                "name": "CMB GOLD CALL 1900 15JUL24",
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "asset": "Gold",
                "fixingSource": "GOLD-P.M. FIX",
                "optionType": "CALL",
                "strikePrice": 1900.00,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {
                    "time": "15:00:00",
                    "location": "GBLO",
                },
                "premiumTerms": {
                    "premium": 50000,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_1",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "barrier": {
                    "barrierDeterminationAgent": "PARTY_1",
                    "barrierTerms": {
                        "eventType": "KNOCK_IN",
                        "triggerType": "EQUAL_OR_GREATER",
                        "level": 1900,
                        "direction": "UP",
                        "semanticType": "BARRIER_TERMS",
                    },
                    "semanticType": "SINGLE_BARRIER_MODEL",
                },
                "settlementTerms": {
                    "settlementType": "CASH",
                    "settlementDate": "2024-07-17",
                    "settlementCurrency": "USD",
                    "settlementAmount": 1000000,
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "productType": "COMMOD_BINARY_OPTION",
                "productFamily": "COMMOD_OPTIONS",
                "semanticType": "COMMOD_BINARY_OPTION",
            },
        }
