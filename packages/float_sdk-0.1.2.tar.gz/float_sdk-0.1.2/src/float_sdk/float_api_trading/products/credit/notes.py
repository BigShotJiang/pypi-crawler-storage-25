# pyright: basic

"""
Promissory Notes

"""

from datetime import date
from typing import Optional, Union

from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.measures.market import Notional
from float_sdk.float_api.base.references import CurrencyId, HolidayCalendarId
from float_sdk.float_api.datetime.calendars import HolidayCalendarModel
from float_sdk.float_api.datetime.conventions import BusinessDayConvention, DayCountConvention
from float_sdk.float_api.datetime.schedule import BusinessDateModel, RelativeDateModel
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel, PayReceive

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class PromissoryNoteModel(ContractualProductModel):
    # General terms
    pay_receive: Optional[PayReceive] = None
    day_count_convention: Optional[DayCountConvention] = None

    # Price quantity
    currency: Optional[Union[CurrencyId, CurrencyModel]] = None
    quantity: Optional[Union[Notional, float]] = None

    # Calculation period dates
    effective_date: Optional[Union[date, BusinessDateModel]] = None
    termination_date: Optional[Union[date, BusinessDateModel, RelativeDateModel]] = None
    holiday_calendar: Optional[Union[HolidayCalendarId, HolidayCalendarModel]] = None
    business_day_convention: Optional[BusinessDayConvention] = None
