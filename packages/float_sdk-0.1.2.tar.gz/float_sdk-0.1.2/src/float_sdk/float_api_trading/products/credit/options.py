# pyright: basic

"""
Bond Option Specifications

Bond option models following the ISDA 1997 Government Bond Option Definitions.
"""

from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.assets.bonds.bonds import BondModel
from float_sdk.float_api.base.references import BondId
from float_sdk.float_api_trading.products.base.options import OptionBaseModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class BondOptionBaseModel(OptionBaseModel):
    asset: BondId | str | BondModel | None = Field(
        default=None,
        title="Asset",
        description="The underlying bond for the option.",
    )
    number_of_options: float | None = Field(
        default=None,
        title="Number of Options",
        description="Number of Options means the number specified as such in the related Confirmation, being the number of Options comprised in the relevant Government Bond Option Transaction.",
    )

    @computed_field
    def asset_class(self) -> AssetClass:
        return AssetClass.CREDIT

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.BOND_OPTIONS


class BondOptionModel(BondOptionBaseModel):
    product_type: ProductType = Field(
        ProductType.BOND_OPTION,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )
    semantic_type: Literal["BOND_OPTION"] = Field(
        default="BOND_OPTION",
        title="Semantic Type",
        description="The type of resource which is being serialized.",
        json_schema_extra={"readOnly": True},
    )

    class Config:
        json_schema_extra = {
            "title": "Bond Option",
            "description": "A bond option is a financial derivative that grants the holder the right, but not the obligation, to buy (call option) or sell (put option) a specific bond at a predetermined strike price on or before a specified expiration date. The underlying asset is a bond, which may be government, corporate, or municipal. The option's terms are governed by the ISDA 1997 Government Bond Option Definitions, which outline the contractual framework for the execution, settlement, and obligations of the parties involved.",
            "example": {
                "name": "BDO T 2.875 05/28 CALL 99.50 15JUL24",
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "BBG019V17VS6",
                "numberOfOptions": 100,
                "optionType": "CALL",
                "optionStyle": "EUROPEAN",
                "strikePrice": 99.5,
                "effectiveDate": "2024-04-15",
                "expirationDate": "2024-07-15",
                "expirationTime": {
                    "time": "12:00:00",
                    "location": "GBLO",
                },
                "premiumTerms": {
                    "premium": 62500,
                    "premiumCurrency": "USD",
                    "premiumPayer": "PARTY_2",
                    "premiumPaymentDate": "2024-04-17",
                    "semanticType": "PREMIUM_TERMS",
                },
                "settlementTerms": {
                    "settlementType": "PHYSICAL",
                    "settlementDate": "2024-07-17",
                    "semanticType": "PHYSICAL_SETTLEMENT_TERMS",
                },
                "productType": "BOND_OPTION",
                "productFamily": "BOND_OPTIONS",
                "semanticType": "BOND_OPTION",
            },
        }
