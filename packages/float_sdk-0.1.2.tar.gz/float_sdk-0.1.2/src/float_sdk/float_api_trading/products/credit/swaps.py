# pyright: basic

"""
Credit Swap Specifications

Bond Total Return Swaps (TRS) - composable models aligned with ISDA CDM.
One party pays the total return of a bond (coupons + price appreciation/depreciation)
while the other pays a fixed or floating funding rate.
"""

from enum import Enum
from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.bonds.bonds import BondModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import BondId, CurrencyId
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.fx_features import FxFeatureModel
from float_sdk.float_api_trading.products.base.returns import NotionalResetTermsModel, ReturnType
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.equities.payouts import PerformancePayoutModel
from float_sdk.float_api_trading.products.rates.cashflows import (
    FixedRateCashflowSeriesModel,
    FloatingRateCashflowSeriesModel,
)
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


######################################################################################
## Enums
######################################################################################


class CleanOrDirtyPrice(Enum):
    """
    ISDA CDM: How price is quoted for bond valuations.

    Determines whether accrued interest is included in the price.

    Attributes
    ----------
    CLEAN : Price excludes accrued interest; accrued settled separately.
    DIRTY : Price includes accrued interest (full price).
    """

    CLEAN = "CLEAN"
    DIRTY = "DIRTY"


######################################################################################
## Return Terms (Nested Structure - mirrors Equity)
######################################################################################


class BondPriceReturnTermsModel(DataModel):
    """
    Price return terms for bond performance payouts.

    Analogous to PriceReturnTermsModel for equities, with addition of
    clean_or_dirty_price for bond-specific accrued interest handling.

    Attributes
    ----------
    return_type : ReturnType
        TOTAL (coupons + price) or PRICE (price only).
    valuation_price_initial : float, optional
        Initial bond price per unit of face value.
    valuation_price_final : float, optional
        Final bond price for performance calculation.
    clean_or_dirty_price : CleanOrDirtyPrice, optional
        Whether prices are quoted clean or dirty (ISDA CDM).
    """

    return_type: ReturnType = Field(
        default=ReturnType.TOTAL,
        title="Return Type",
        description="TOTAL (coupons + price) or PRICE (price only)",
    )

    valuation_price_initial: float | None = Field(
        default=None,
        title="Valuation Price Initial",
        description="Initial bond price per unit of face value",
        gt=0,
    )

    valuation_price_final: float | None = Field(
        default=None,
        title="Valuation Price Final",
        description="Final bond price for performance calculation",
        gt=0,
    )

    clean_or_dirty_price: CleanOrDirtyPrice | None = Field(
        default=None,
        title="Clean Or Dirty Price",
        description="Whether prices are quoted clean or dirty (ISDA CDM)",
    )

    semantic_type: Literal["BOND_PRICE_RETURN_TERMS"] = "BOND_PRICE_RETURN_TERMS"


class CouponReturnTermsModel(DataModel):
    """
    Coupon treatment terms for bond total return swaps.

    Analogous to DividendReturnTermsModel for equities.
    Specifies how bond coupons pass through the swap.

    Attributes
    ----------
    coupon_payout_ratio : float, optional
        Percentage of coupon payments passed through (default 1.0 = 100%).
        May be <1.0 for certain tax-driven structures.
    """

    coupon_payout_ratio: float | None = Field(
        default=1.0,
        title="Coupon Payout Ratio",
        description="Percentage of coupons passed through (1.0 = 100%)",
        ge=0.0,
        le=1.0,
    )

    semantic_type: Literal["COUPON_RETURN_TERMS"] = "COUPON_RETURN_TERMS"


class BondReturnTermsModel(DataModel):
    """
    Complete return terms for bond total return swaps.

    Container for price return terms and coupon treatment.
    Mirrors EquityReturnTermsModel structure (price_return_terms + dividend_return_terms).

    Attributes
    ----------
    price_return_terms : BondPriceReturnTermsModel, optional
        Price return specification including return type, valuation prices, clean/dirty.
    coupon_return_terms : CouponReturnTermsModel, optional
        Coupon treatment terms. Only applicable for TOTAL return swaps.
    """

    price_return_terms: BondPriceReturnTermsModel | None = Field(
        default=None,
        title="Price Return Terms",
        description="Price return specification for bond swaps",
    )

    coupon_return_terms: CouponReturnTermsModel | None = Field(
        default=None,
        title="Coupon Return Terms",
        description="Coupon treatment. Only applicable for TOTAL return swaps.",
    )

    semantic_type: Literal["BOND_RETURN_TERMS"] = "BOND_RETURN_TERMS"


######################################################################################
## Bond Performance Payout
######################################################################################


class BondPerformancePayoutModel(PerformancePayoutModel):
    """
    Bond performance payout for bond total return swaps.

    Represents the return leg of a Bond TRS where one party pays/receives
    the total return of a bond (coupons + price appreciation/depreciation).

    Similar structure to EquityPerformancePayoutModel.

    Inherits from PerformancePayoutModel:
        payer, receiver, valuation_dates, calculation_period_dates, payment_dates

    Attributes
    ----------
    asset : BondId | str | BondModel
        The underlying bond for performance calculation.
    notional_amount : float
        Face value / par value of the bond position.
    notional_currency : CurrencyId | str | CurrencyModel
        Currency of the notional amount.
    return_terms : BondReturnTermsModel
        Bond return terms with price and coupon specifications.
    notional_reset : NotionalResetTermsModel
        Notional reset terms if applicable.
    fx_feature : FxFeatureModel
        FX feature for cross-currency swaps.
    """

    asset: BondId | str | BondModel | None = Field(
        default=None,
        title="Asset",
        description="The underlying bond",
    )

    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Face value / par value of the bond position",
        gt=0,
    )

    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency of the notional amount",
    )

    return_terms: BondReturnTermsModel | None = Field(
        default=None,
        title="Return Terms",
        description="Bond return terms with price and coupon specifications",
    )

    notional_reset: NotionalResetTermsModel | None = Field(
        default=None,
        title="Notional Reset",
        description="Notional reset terms if applicable",
    )

    fx_feature: FxFeatureModel | None = Field(
        default=None,
        title="FX Feature",
        description="FX feature for cross-currency bond swaps",
    )

    semantic_type: Literal["BOND_PERFORMANCE_PAYOUT"] = "BOND_PERFORMANCE_PAYOUT"

    @computed_field
    @property
    def market_value(self) -> float | None:
        """
        Calculated market value: notional_amount × (valuation_price_initial / 100).

        Returns the market value of the bond position at inception.
        Bond prices are quoted as percentage of par (e.g., 98.0 = 98% of face value).
        """
        if self.notional_amount and self.return_terms and self.return_terms.price_return_terms and self.return_terms.price_return_terms.valuation_price_initial:
            return self.notional_amount * (self.return_terms.price_return_terms.valuation_price_initial / 100)
        return None

    @computed_field
    @property
    def has_notional_reset(self) -> bool:
        """Check if notional reset is applicable."""
        return self.notional_reset is not None and self.notional_reset.is_applicable is True

    class Config:
        json_schema_extra = {
            "title": "Bond Performance Payout",
            "description": "Return leg for bond total return swaps. Pays the total return of a bond including coupons and price appreciation/depreciation.",
            "example": {
                "payer": "PARTY_1",
                "receiver": "PARTY_2",
                "asset": "US912810TH25",
                "notionalAmount": 10000000.0,
                "notionalCurrency": "USD",
                "returnTerms": {
                    "priceReturnTerms": {
                        "returnType": "TOTAL",
                        "valuationPriceInitial": 0.98,
                        "cleanOrDirtyPrice": "CLEAN",
                        "semanticType": "BOND_PRICE_RETURN_TERMS",
                    },
                    "couponReturnTerms": {
                        "couponPayoutRatio": 1.0,
                        "semanticType": "COUPON_RETURN_TERMS",
                    },
                    "semanticType": "BOND_RETURN_TERMS",
                },
                "calculationPeriodDates": {
                    "effectiveDate": "2025-01-15",
                    "terminationDate": "2026-01-15",
                    "frequency": {"period": "M", "multiplier": 3},
                    "semanticType": "CALCULATION_DATE_SCHEDULE",
                },
                "paymentDates": {
                    "payRelativeTo": "CALCULATION_PERIOD_END_DATE",
                    "paymentDaysOffset": 2,
                    "semanticType": "PAYMENT_DATES",
                },
                "semanticType": "BOND_PERFORMANCE_PAYOUT",
            },
        }


######################################################################################
## Bond Swap Models (Composable)
######################################################################################


class BondSwapBaseModel(ContractualProductModel):
    """
    Base model for bond total return swaps.

    Provides shared fields and properties for both fixed and floating
    rate funding leg variants.
    """

    bond_amounts: BondPerformancePayoutModel | None = Field(
        default=None,
        title="Bond Amounts",
        description="Bond performance payout leg specifying underlier, return type, and payment terms",
    )

    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms for the swap",
    )

    @computed_field
    @property
    def product_family(self) -> ProductFamily:
        return ProductFamily.BOND_SWAPS

    @computed_field
    @property
    def buyer(self) -> CounterpartyRole | None:
        return self.bond_amounts.receiver if self.bond_amounts else None

    @computed_field
    @property
    def seller(self) -> CounterpartyRole | None:
        return self.bond_amounts.payer if self.bond_amounts else None


class BondSwapFixedModel(BondSwapBaseModel):
    """
    Bond Total Return Swap with Fixed Rate Funding Leg.

    Composable structure combining a bond performance payout with a
    fixed rate cashflow series. One party pays bond total return,
    the other pays a fixed funding rate.

    Attributes
    ----------
    bond_amounts : BondPerformancePayoutModel
        The bond performance payout leg.
    fixed_amounts : FixedRateCashflowSeriesModel
        The fixed rate funding leg.
    """

    product_type: ProductType = Field(
        ProductType.BOND_SWAP_FIXED,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    fixed_amounts: FixedRateCashflowSeriesModel | None = Field(
        default=None,
        title="Fixed Amounts",
        description="Fixed rate funding leg specifying fixed rate, notional, and payment schedule",
    )

    semantic_type: Literal["BOND_SWAP_FIXED"] = Field(default="BOND_SWAP_FIXED", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Bond Swap (Fixed)",
            "description": "Bond total return swap with fixed rate funding. One party pays bond total return (coupons + price changes) while the other pays a fixed funding rate.",
            "example": {
                "bondAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "asset": "US912810TH25",
                    "notionalAmount": 10000000.0,
                    "notionalCurrency": "USD",
                    "returnTerms": {
                        "priceReturnTerms": {
                            "returnType": "TOTAL",
                            "valuationPriceInitial": 0.98,
                            "semanticType": "BOND_PRICE_RETURN_TERMS",
                        },
                        "couponReturnTerms": {
                            "couponPayoutRatio": 1.0,
                            "semanticType": "COUPON_RETURN_TERMS",
                        },
                        "semanticType": "BOND_RETURN_TERMS",
                    },
                    "semanticType": "BOND_PERFORMANCE_PAYOUT",
                },
                "fixedAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalAmount": 9800000.0,
                    "notionalCurrency": "USD",
                    "fixedRate": {"rate": 0.045, "semanticType": "FIXED_RATE"},
                    "dayCountConvention": "ACT/360",
                    "semanticType": "IR_FIXED_CASHFLOW_SERIES",
                },
                "effectiveDate": "2025-01-15",
                "terminationDate": "2026-01-15",
                "semanticType": "BOND_SWAP_FIXED",
            },
        }


class BondSwapFloatModel(BondSwapBaseModel):
    """
    Bond Total Return Swap with Floating Rate Funding Leg.

    Composable structure combining a bond performance payout with a
    floating rate cashflow series. One party pays bond total return,
    the other pays a floating funding rate (e.g., SOFR + spread).

    This is the most common structure for bond TRS as the funding leg
    typically references an overnight rate plus a credit spread.

    Attributes
    ----------
    bond_amounts : BondPerformancePayoutModel
        The bond performance payout leg.
    floating_amounts : FloatingRateCashflowSeriesModel
        The floating rate funding leg (e.g., SOFR + spread).
    """

    product_type: ProductType = Field(
        ProductType.BOND_SWAP_FLOAT,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    floating_amounts: FloatingRateCashflowSeriesModel | None = Field(
        default=None,
        title="Floating Amounts",
        description="Floating rate funding leg specifying rate index, spread, and payment schedule",
    )

    semantic_type: Literal["BOND_SWAP_FLOAT"] = Field(default="BOND_SWAP_FLOAT", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Bond Swap (Floating)",
            "description": "Bond total return swap with floating rate funding. One party pays bond total return (coupons + price changes) while the other pays a floating rate (e.g., SOFR + spread).",
            "example": {
                "bondAmounts": {
                    "payer": "PARTY_1",
                    "receiver": "PARTY_2",
                    "asset": "US912810TH25",
                    "notionalAmount": 10000000.0,
                    "notionalCurrency": "USD",
                    "returnTerms": {
                        "priceReturnTerms": {
                            "returnType": "TOTAL",
                            "valuationPriceInitial": 0.98,
                            "semanticType": "BOND_PRICE_RETURN_TERMS",
                        },
                        "couponReturnTerms": {
                            "couponPayoutRatio": 1.0,
                            "semanticType": "COUPON_RETURN_TERMS",
                        },
                        "semanticType": "BOND_RETURN_TERMS",
                    },
                    "semanticType": "BOND_PERFORMANCE_PAYOUT",
                },
                "floatingAmounts": {
                    "payer": "PARTY_2",
                    "receiver": "PARTY_1",
                    "notionalAmount": 9800000.0,
                    "notionalCurrency": "USD",
                    "floatingRate": {
                        "rateOption": "USD-SOFR-COMPOUND",
                        "spread": 0.0050,
                        "semanticType": "FLOATING_RATE",
                    },
                    "resetDatesSpecification": {
                        "resetRelativeTo": "CALCULATION_PERIOD_START_DATE",
                        "semanticType": "RESET_DATES_SPECIFICATION",
                    },
                    "dayCountConvention": "ACT/360",
                    "semanticType": "IR_FLOATING_CASHFLOW_SERIES",
                },
                "effectiveDate": "2025-01-15",
                "terminationDate": "2026-01-15",
                "semanticType": "BOND_SWAP_FLOAT",
            },
        }


######################################################################################
## Model Rebuild
######################################################################################

BondPriceReturnTermsModel.model_rebuild()
BondReturnTermsModel.model_rebuild()
BondPerformancePayoutModel.model_rebuild()
BondSwapBaseModel.model_rebuild()
BondSwapFixedModel.model_rebuild()
BondSwapFloatModel.model_rebuild()
