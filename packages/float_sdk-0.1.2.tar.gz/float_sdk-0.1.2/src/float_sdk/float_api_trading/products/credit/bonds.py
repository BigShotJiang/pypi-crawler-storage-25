# pyright: basic

"""
Bond Products

Bond forward models.
"""

from datetime import date
from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.bonds.bonds import BondModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import BondId, CurrencyId
from float_sdk.float_api.datetime.conventions import BusinessDayConvention
from float_sdk.float_api.locations.business_centers import BusinessCenter
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductFamily, ProductType
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class BondForwardModel(ContractualProductModel):
    """
    Bond Forward Model

    Cash-settled bond forward contract.
    Aligned with FXForward pattern - cash settlement only.
    """

    product_type: ProductType = Field(
        default=ProductType.BOND_FORWARD,
        title="Product Type",
        description="Type of financial instrument.",
        json_schema_extra={"readOnly": True},
    )

    # Counterparties
    buyer: CounterpartyRole | None = Field(
        default=None,
        title="Buyer",
        description="The party which is the buyer of the bond forward.",
    )
    seller: CounterpartyRole | None = Field(
        default=None,
        title="Seller",
        description="The party which is the seller of the bond forward.",
    )

    # Underlier - Bond reference (follows FXForward asset pattern)
    asset: BondId | str | BondModel | None = Field(
        default=None,
        title="Asset",
        description="The underlying bond.",
    )

    # Economics (aligned with FXForward)
    forward_price: float | None = Field(
        default=None,
        title="Forward Price",
        description="Forward price per unit of face value.",
    )
    notional_amount: float | None = Field(
        default=None,
        title="Notional Amount",
        description="Face value / notional amount.",
    )
    notional_currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Notional Currency",
        description="Currency of the notional amount.",
    )

    # Valuation (aligned with FXForward valuation_date for NDFs)
    valuation_date: date | None = Field(
        default=None,
        title="Valuation Date",
        description="Date for determining settlement amount.",
    )
    valuation_business_days: BusinessCenter | list[BusinessCenter] | None = Field(
        default=None,
        title="Valuation Business Days",
        description="Business day center(s) for valuation date adjustments.",
    )
    valuation_business_day_convention: BusinessDayConvention | None = Field(
        default=None,
        title="Valuation Business Day Convention",
        description="Business day convention for valuation date adjustments.",
    )

    # Settlement - Cash only
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms for the bond forward.",
    )

    semantic_type: Literal["BOND_FORWARD"] = Field(default="BOND_FORWARD", json_schema_extra={"readOnly": True})

    @computed_field
    def product_family(self) -> ProductFamily:
        return ProductFamily.BOND_ONE_DELTA

    class Config:
        json_schema_extra = {
            "title": "Bond Forward",
            "description": "A bond forward is a cash-settled derivative contract where one party agrees to buy and another to sell a bond at a predetermined forward price on a future settlement date. Settlement is based on the difference between the forward price and the bond's market price at valuation.",
            "example": {
                "buyer": "PARTY_2",
                "seller": "PARTY_1",
                "asset": "US912810TH25",
                "forwardPrice": 0.985,
                "notionalAmount": 10000000.0,
                "notionalCurrency": "USD",
                "effectiveDate": "2025-01-15",
                "valuationDate": "2025-06-15",
                "settlementTerms": {
                    "settlementDate": "2025-06-17",
                    "settlementCurrency": "USD",
                    "semanticType": "CASH_SETTLEMENT_TERMS",
                },
                "semanticType": "BOND_FORWARD",
            },
        }
