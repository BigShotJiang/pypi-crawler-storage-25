# pyright: basic

"""
Credit Products

Bond forwards, bond swaps (TRS), and other credit product models.
"""

from float_sdk.float_api_trading.products.credit.bonds import BondForwardModel
from float_sdk.float_api_trading.products.credit.notes import PromissoryNoteModel
from float_sdk.float_api_trading.products.credit.options import BondOptionModel
from float_sdk.float_api_trading.products.credit.swaps import (
    BondPerformancePayoutModel,
    BondPriceReturnTermsModel,
    BondReturnTermsModel,
    BondSwapFixedModel,
    BondSwapFloatModel,
    CleanOrDirtyPrice,
    CouponReturnTermsModel,
)

__all__ = [
    "BondForwardModel",
    "BondOptionModel",
    "PromissoryNoteModel",
    # Bond Swap / TRS
    "BondPerformancePayoutModel",
    "BondPriceReturnTermsModel",
    "BondReturnTermsModel",
    "BondSwapFixedModel",
    "BondSwapFloatModel",
    "CleanOrDirtyPrice",
    "CouponReturnTermsModel",
]
