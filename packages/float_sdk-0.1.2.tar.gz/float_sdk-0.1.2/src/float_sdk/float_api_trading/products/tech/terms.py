#!/usr/bin/env python
# pyright: basic

"""
Software License Term Models

Data models for software license terms including fee terms, payment terms,
and service modification terms.
"""

import datetime as dt

from pydantic import Field

from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.rates.rates import InflationRateIndexModel
from float_sdk.float_api.base.references import CurrencyId, InflationRateIndexId
from float_sdk.float_api.datetime.conventions import DayCountConvention
from float_sdk.float_api.datetime.schedule import RelativeDateModel
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api_trading.valuations.valuations import ValuationUnit

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2026, Float Technologies Inc."
__email__ = "andy@float.tech"


class LateFeeTermsModel(DataModel):
    """
    Late Fee Model

    Defines late fee parameters for software license payments.
    For example: late fee of 1% applied every month.

    """

    amount: float | None = Field(default=None, title="Late Fee Amount", description="Amount of late fee applied after grace period.")
    unit: ValuationUnit | None = Field(default=None, title="Late Fee Unit", description="Unit of late fee amount (e.g. percentage, fixed amount).")
    accrual_period: RelativeDateModel | None = Field(
        default=None, title="Late Fee Period", description="Frequency of late fee application (e.g. per month unpaid)."
    )


class PaymentTermsModel(DataModel):
    """
    Payment Terms for Software Licenses

    Defines payment terms such as late fees, grace periods, etc.

    """

    payment_due: RelativeDateModel | None = Field(default=None, title="Payment Due", description="When is payment due following invoice date.")
    late_fee_terms: LateFeeTermsModel | None = Field(default=None, title="Late Fee", description="Late fee parameters for overdue payments.")
    day_count_convention: DayCountConvention | None = Field(default=None, title="Day Count Convention", description="Day count convention for calculations.")


class FeeChangeLevelType(DisplayEnum):
    """
    Fee Change Level Type

    Attributes
    ----------
    NONE : No fee change level
    AMOUNT : Fixed amount
    RATE_INDEX : Rate index
    LESSER_OF : Lesser of amount or rate index
    GREATER_OF : Greater of amount or rate index
    """

    NONE = "NONE"
    AMOUNT = "AMOUNT"
    RATE_INDEX = "RATE_INDEX"
    LESSER_OF = "LESSER_OF"
    GREATER_OF = "GREATER_OF"

    def display_names(self) -> dict[str, str]:
        return {
            "NONE": "None",
            "AMOUNT": "Amount",
            "RATE_INDEX": "Rate Index",
            "LESSER_OF": "Lesser Of",
            "GREATER_OF": "Greater Of",
        }


class FeeChangeLevelModel(DataModel):
    """
    Fee Change Conditions

    Defines conditions under which fees can be changed.

    """

    index: InflationRateIndexId | str | InflationRateIndexModel | None = Field(
        default=None, title="Asset", description="Asset which provides rate increase (e.g. US CPI)."
    )

    amount: float | None = Field(default=None, title="Fee Change Amount", description="Amount by which the fee can be changed.")
    type: FeeChangeLevelType | None = Field(default=None, title="Comparison Operator", description="Operator to compare index change against amount.")


class FeeChangeTermsModel(DataModel):
    """
    Fee Change Terms

    Defines terms for changing the fee structure under the software license.

    """

    effective_date: dt.date | None = Field(default=None, title="Effective Date", description="Effective date of fee change.")
    notice_period: RelativeDateModel | None = Field(default=None, title="Notice Period", description="Notice period required for fee changes.")
    frequency: RelativeDateModel | None = Field(default=None, title="Fee Change Frequency", description="Frequency at which fees can be changed.")
    minimum: FeeChangeLevelModel | None = Field(default=None, title="Minimum Fee Change", description="Minimum fee amount change.")
    maximum: FeeChangeLevelModel | None = Field(default=None, title="Maximum Fee Change", description="Maximum fee amount change.")


class FeeTermsModel(DataModel):
    """
    Fee Terms Model

    Defines fee parameters for software licenses.

    """

    fee_amount: float | None = Field(default=None, title="Fee Amount", description="Amount of fees to be paid per period.")
    fee_currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Fee Currency", description="Currency of fee payments.")
    fee_change_terms: FeeChangeTermsModel | None = Field(default=None, title="Fee Change Terms", description="Terms for changing the fee structure.")


class ServiceModificationTermsModel(DataModel):
    """
    Service Modification Terms

    Defines terms for modifying the service under the software license.

    """

    notice_period: RelativeDateModel | None = Field(default=None, title="Notice Period", description="Notice period required for service modifications.")
