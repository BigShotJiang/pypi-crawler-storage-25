#!/usr/bin/env python
# pyright: basic

"""
Software License Models

"""

from typing import Literal

from pydantic import Field, computed_field

from float_sdk.float_api.assets.base.cashflows import DiscountScheduleModel
from float_sdk.float_api.assets.base.services import SoftwareServiceModel
from float_sdk.float_api.base.references import SoftwareServiceId
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.rates.cashflows import CalculationDateScheduleModel, PaymentDateScheduleModel
from float_sdk.float_api_trading.products.tech.terms import FeeTermsModel, PaymentTermsModel, ServiceModificationTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2026, Float Technologies Inc."
__email__ = "andy@float.tech"


class SoftwareLicenseFixedModel(ContractualProductModel):
    product_type: ProductType = Field(
        ProductType.SOFTWARE_LICENSE_FIXED, title="Product Type", description="Type of financial instrument.", json_schema_extra={"readOnly": True}
    )

    service: SoftwareServiceId | str | SoftwareServiceModel | None = Field(default=None, title="Service", description="The service being provided.")

    buyer: CounterpartyRole | None = Field(
        default=CounterpartyRole.PARTY_2, title="Buyer", description="The party which is receiving the service and paying fees."
    )
    seller: CounterpartyRole | None = Field(default=CounterpartyRole.PARTY_1, title="Seller", description="The party which is providing the service.")

    fee_terms: FeeTermsModel | None = Field(default=None, title="Fee Terms", description="Fee payment terms including amount, currency, and change rules.")
    discount_schedule: DiscountScheduleModel | None = Field(
        default=None, title="Discount Schedule", description="Schedule of discount factors applied to the fee amount."
    )
    payment_schedule: PaymentDateScheduleModel | None = Field(default=None, title="Payment Schedule", description="Schedule for fee payments.")
    payment_terms: PaymentTermsModel | None = Field(default=None, title="Payment Terms", description="Payment terms including due dates and late fees.")
    service_modification_terms: ServiceModificationTermsModel | None = Field(
        default=None, title="Service Modification Terms", description="Terms for modifying the service."
    )

    calculation_schedule: CalculationDateScheduleModel | None = Field(
        default=None, title="Calculation Schedule", description="Schedule for calculating fee periods."
    )

    @computed_field
    @property
    def payer(self) -> CounterpartyRole | None:
        """Payer is the buyer (buyer pays fees)"""
        return self.buyer

    @computed_field
    @property
    def receiver(self) -> CounterpartyRole | None:
        """Receiver is the seller (seller receives fees)"""
        return self.seller

    semantic_type: Literal["SOFTWARE_LICENSE_FIXED"] = Field(default="SOFTWARE_LICENSE_FIXED", json_schema_extra={"readOnly": True})

    class Config:
        json_schema_extra = {
            "title": "Software License",
            "description": "A software license is a type of contract that grants the recipient the right to use a software product based on the terms of the license. The software license contract is typically used to grant the right to use a software product for a specific period of time, after which the license is typically revoked. Software licenses are typically used in the context of software-as-a-service (SaaS) models, where the software product is provided to the user on a subscription basis.",
            "example": {
                "buyer": "PARTY_1",
                "seller": "PARTY_2",
                "effectiveDate": "2018-04-27",
                "terminationDate": "2025-04-27",
                "service": "FLCONFIRM",
                "feeTerms": {
                    "feeAmount": 1000000,
                    "feeCurrency": "USD",
                },
                "paymentTerms": {
                    "dayCountConvention": "30/360",
                },
                "calculationSchedule": {
                    "calculationPeriodFrequency": {"period": "M", "periodMultiplier": 1},
                    "dateRollConvention": "EOM",
                },
                "paymentSchedule": {"paymentFrequency": {"period": "M", "periodMultiplier": 1}, "payDaysOffset": 0},
                "semanticType": "SOFTWARE_LICENSE_FIXED",
            },
        }
