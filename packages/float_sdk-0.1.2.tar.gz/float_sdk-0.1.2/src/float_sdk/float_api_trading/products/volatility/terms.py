# pyright: basic
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.settlement import DeterminationMethod
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum


class VolatilityCapFloorModel(DataModel):
    """
    Volatility cap and floor specifications.

    Aligned with ISDA CDM VolatilityCapFloor type.
    Per ISDA 2011 Equity Derivatives Definitions.

    Attributes
    ----------
    applicable : bool
        Indicates whether the volatility cap is applicable.
        If False: No Volatility Cap applied.
        If True: Volatility Cap election, then totalVolatilityCap or volatilityCapFactor should be provided.
        CDM: applicable (1..1)
    total_volatility_cap : float, optional
        Volatility Cap Amount as an absolute number (e.g., 50.0 for 50% vol).
        CDM: totalVolatilityCap (0..1)
    volatility_cap_factor : float, optional
        Cap as multiple of strike (e.g., 2.5 means cap at 2.5× strike).
        Defaults to 2.5 if applicable is True and no values provided.
        CDM: volatilityCapFactor (0..1)
    """

    applicable: bool = Field(..., title="Applicable", description="Whether volatility cap/floor is applicable. Per ISDA 2011 Equity Derivatives Definitions.")

    total_volatility_cap: float | None = Field(
        default=None, title="Total Volatility Cap", description="Volatility Cap Amount as absolute level (e.g., 50.0 for 50% vol). CDM: totalVolatilityCap"
    )

    volatility_cap_factor: float | None = Field(
        default=None,
        title="Volatility Cap Factor",
        description="Cap as multiple of strike (e.g., 2.5). Defaults to 2.5 if applicable=True. CDM: volatilityCapFactor",
    )

    semantic_type: Literal["VOLATILITY_CAP_FLOOR"] = "VOLATILITY_CAP_FLOOR"


class BoundedVarianceModel(DataModel):
    """
    Bounded variance structure defining price-based barriers.

    Aligned with ISDA CDM BoundedVariance type.
    Conditions which bound variance - observations outside barriers are excluded.

    Attributes
    ----------
    realised_variance_method : str, optional
        Which price must satisfy the boundary condition.
        Values: PREVIOUS (T-1), LAST (T), BOTH (T and T-1)
        CDM: realisedVarianceMethod (1..1)
    days_in_range_adjustment : bool, optional
        Whether to scale notional by (Days in Range / Expected N).
        CDM: daysInRangeAdjustment (1..1)
    upper_barrier : float, optional
        Observations above this price level excluded from variance calculation.
        CDM: upperBarrier (0..1)
    lower_barrier : float, optional
        Observations below this price level excluded from variance calculation.
        CDM: lowerBarrier (0..1)
    """

    realised_variance_method: str | None = Field(
        default=None,
        title="Realised Variance Method",
        description="Which price must satisfy boundary: PREVIOUS (T-1), LAST (T), or BOTH. CDM: realisedVarianceMethod",
    )

    days_in_range_adjustment: bool | None = Field(
        default=None, title="Days In Range Adjustment", description="Scale notional by (Days in Range / Expected N). CDM: daysInRangeAdjustment"
    )

    upper_barrier: float | None = Field(default=None, title="Upper Barrier", description="Observations above this price excluded. CDM: upperBarrier", gt=0)
    lower_barrier: float | None = Field(default=None, title="Lower Barrier", description="Observations below this price excluded. CDM: lowerBarrier", gt=0)

    semantic_type: Literal["BOUNDED_VARIANCE"] = "BOUNDED_VARIANCE"


class VolatilityReturnTermsBaseModel(DataModel):
    """
    Base class for return terms across variance, volatility, and correlation swaps.

    Contains common fields from ISDA CDM ReturnTermsBase type.
    These fields are shared across all return term types per ISDA 2011 Equity Derivatives Definitions.

    Attributes
    ----------
    expected_n : int
        Expected number of observations in observation period.
        CDM: ReturnTermsBase.expectedN (1..1)
    annualization_factor : int, optional
        Number of periods per year (e.g., 252 for trading days, 365 for calendar days).
        CDM: ReturnTermsBase.annualizationFactor (0..1)
    mean_adjustment : bool, optional
        Whether mean adjustment is applicable in realized calculation.
        CDM: ReturnTermsBase.meanAdjustment (0..1)
    """

    expected_n: int | None = Field(
        default=None,
        title="Expected N",
        description="Expected number of observations. CDM: ReturnTermsBase.expectedN",
        gt=0,
    )

    annualization_factor: int | None = Field(
        default=None,
        title="Annualization Factor",
        description="Periods per year (e.g., 252, 365). CDM: ReturnTermsBase.annualizationFactor",
        gt=0,
    )

    mean_adjustment: bool | None = Field(
        default=None,
        title="Mean Adjustment",
        description="Apply mean adjustment to calculation. CDM: ReturnTermsBase.meanAdjustment",
    )


class VarianceCapFloorModel(DataModel):
    """
    Variance cap and floor specifications.

    Aligned with ISDA CDM VarianceCapFloor type.
    Variance swaps have different capping mechanics than volatility swaps.

    Attributes
    ----------
    variance_cap : bool
        If true, variance cap is applicable.
        CDM: varianceCap (1..1)
    unadjusted_variance_cap : float, optional
        Scaling factor for variance cap (European markets).
        E.g., 2.5 means cap at (2.5)² × Variance Strike.
        CDM: unadjustedVarianceCap (0..1)
    bounded_variance : BoundedVarianceModel, optional
        Price-based boundary conditions (corridor/conditional structures).
        CDM: boundedVariance (0..1)
    """

    variance_cap: bool = Field(..., title="Variance Cap", description="If true, variance cap is applicable. CDM: varianceCap")

    unadjusted_variance_cap: float | None = Field(
        default=None, title="Unadjusted Variance Cap", description="Scaling factor (e.g., 2.5 means cap at 2.5² × strike). CDM: unadjustedVarianceCap", gt=0
    )

    bounded_variance: BoundedVarianceModel | None = Field(
        default=None, title="Bounded Variance", description="Price-based barriers for conditional/corridor variance. CDM: boundedVariance"
    )

    semantic_type: Literal["VARIANCE_CAP_FLOOR"] = "VARIANCE_CAP_FLOOR"


class VarianceReturnTermsModel(VolatilityReturnTermsBaseModel):
    """
    Variance return terms for variance swap products.

    Aligned with ISDA CDM VarianceReturnTerms type.
    Contains variance-specific calculation parameters per ISDA 2011 Equity Derivatives Definitions.

    Note: Does NOT contain asset, notional, payer/receiver, or dates.
    Those are specified in the parent EquityPerformancePayoutModel.

    Attributes
    ----------
    variance_strike_price : float, optional
        Strike as variance (e.g., 0.04 = 20% vol squared).
        CDM: varianceStrikePrice (0..1)
    initial_level : float, optional
        Initial price level for variance calculation.
        CDM: ReturnTermsBase.initialLevel (0..1)
    initial_level_source : DeterminationMethod, optional
        Method for determining initial level (CLOSE, OPEN, TWAP, etc.).
        CDM: ReturnTermsBase.initialLevelSource (0..1)
    share_price_dividend_adjustment : bool, optional
        Adjust share prices for dividends in variance calculation.
        CDM: ReturnTermsBase.sharePriceDividendAdjustment (0..1)
    variance_cap_floor : VarianceCapFloorModel, optional
        Variance-based and price-based barriers.
        CDM: varianceCapFloor (0..1)
    vega_notional_amount : float, optional
        Approximate vega notional for informational purposes.
        Vega Notional ≈ Variance Notional × 2 × Strike Vol.
        CDM: vegaNotionalAmount (0..1)

    Inherited from ReturnTermsBaseModel:
        expected_n, annualization_factor, mean_adjustment
    """

    # Strike
    variance_strike_price: float | None = Field(
        default=None, title="Variance Strike Price", description="Strike as variance (e.g., 0.04 for 20% vol). CDM: varianceStrikePrice", gt=0
    )

    initial_level: float | None = Field(default=None, title="Initial Level", description="Initial price level. CDM: ReturnTermsBase.initialLevel", gt=0)

    initial_level_source: DeterminationMethod | None = Field(
        default=None, title="Initial Level Source", description="Method for determining initial level. CDM: ReturnTermsBase.initialLevelSource"
    )

    share_price_dividend_adjustment: bool | None = Field(
        default=None, title="Share Price Dividend Adjustment", description="Adjust prices for dividends. CDM: ReturnTermsBase.sharePriceDividendAdjustment"
    )

    # Caps/Floors
    variance_cap_floor: VarianceCapFloorModel | None = Field(
        default=None, title="Variance Cap Floor", description="Variance-based barriers. CDM: varianceCapFloor"
    )

    # Informational vega notional
    vega_notional_amount: float | None = Field(
        default=None, title="Vega Notional Amount", description="Approximate vega notional (informational). CDM: vegaNotionalAmount", gt=0
    )

    semantic_type: Literal["VARIANCE_RETURN_TERMS"] = "VARIANCE_RETURN_TERMS"


class VolatilityReturnTermsModel(VolatilityReturnTermsBaseModel):
    """
    Volatility return terms for volatility swap products.

    Aligned with ISDA CDM VolatilityReturnTerms type.
    Similar to VarianceReturnTerms but for volatility swaps (linear to volatility, not variance).

    Attributes
    ----------
    volatility_strike_price : float
        Strike volatility level (e.g., 20.0 for 20% vol).
        CDM: volatilityStrikePrice (1..1)
    initial_level : float, optional
        Initial price level.
        CDM: ReturnTermsBase.initialLevel (0..1)
    initial_level_source : DeterminationMethod, optional
        Method for determining initial level.
        CDM: ReturnTermsBase.initialLevelSource (0..1)
    share_price_dividend_adjustment : bool, optional
        Adjust prices for dividends.
        CDM: ReturnTermsBase.sharePriceDividendAdjustment (0..1)
    volatility_cap_floor : VolatilityCapFloorModel, optional
        Volatility-based barriers.
        CDM: volatilityCapFloor (0..1)

    Inherited from ReturnTermsBaseModel:
        expected_n, annualization_factor, mean_adjustment
    """

    volatility_strike_price: float | None = Field(
        default=None, title="Volatility Strike Price", description="Strike volatility (e.g., 20.0). CDM: volatilityStrikePrice", gt=0
    )

    initial_level: float | None = Field(default=None, title="Initial Level", description="Initial price level. CDM: ReturnTermsBase.initialLevel", gt=0)

    initial_level_source: DeterminationMethod | None = Field(
        default=None, title="Initial Level Source", description="Determination method. CDM: ReturnTermsBase.initialLevelSource"
    )

    share_price_dividend_adjustment: bool | None = Field(
        default=None, title="Share Price Dividend Adjustment", description="Adjust for dividends. CDM: ReturnTermsBase.sharePriceDividendAdjustment"
    )

    volatility_cap_floor: VolatilityCapFloorModel | None = Field(
        default=None, title="Volatility Cap Floor", description="Volatility barriers. CDM: volatilityCapFloor"
    )

    semantic_type: Literal["VOLATILITY_RETURN_TERMS"] = "VOLATILITY_RETURN_TERMS"


class CorrelationType(DisplayEnum):
    """
    Method for calculating correlation across N > 2 assets.

    Defines how realized correlation is calculated when there are more than two assets in the basket.

    NOTE: This is a Float-specific extension. ISDA CDM and FpML do not define a standard
    enumeration for correlation calculation methods. Market practice typically uses pairwise
    average correlation, but the specific methodology is not standardized across the industry.
    """

    PAIRWISE_AVERAGE = "PAIRWISE_AVERAGE"
    WEIGHTED_AVERAGE = "WEIGHTED_AVERAGE"
    SPECIFIED_PAIR = "SPECIFIED_PAIR"

    def display_names(self) -> dict[str, str]:
        return {
            "PAIRWISE_AVERAGE": "Pairwise Average",
            "WEIGHTED_AVERAGE": "Weighted Average",
            "SPECIFIED_PAIR": "Specified Pair",
        }


class CorrelationReturnTermsModel(VolatilityReturnTermsBaseModel):
    """
    Correlation return terms for correlation swap products.

    Aligned with ISDA CDM structure for correlation swaps.
    Specifies strike, calculation methodology, and optional caps/floors.

    Attributes
    ----------
    correlation_strike_price : float
        Fixed correlation strike (-1.0 to 1.0, e.g., 0.65 for 65% correlation)
        CDM: correlationStrikePrice (1..1)
    correlation_type : CorrelationType, optional
        Method for calculating correlation across multiple assets
        Defaults to PAIRWISE_AVERAGE

    Inherited from ReturnTermsBaseModel:
        expected_n, annualization_factor, mean_adjustment
    """

    correlation_strike_price: float | None = Field(
        default=None,
        title="Correlation Strike Price",
        description="Fixed correlation strike (-1.0 to 1.0, e.g., 0.65 for 65%)",
        ge=-1.0,
        le=1.0,
    )

    correlation_type: CorrelationType | None = Field(
        default=CorrelationType.PAIRWISE_AVERAGE,
        title="Correlation Type",
        description="Method for calculating correlation across multiple assets",
    )

    semantic_type: Literal["CORRELATION_RETURN_TERMS"] = "CORRELATION_RETURN_TERMS"
