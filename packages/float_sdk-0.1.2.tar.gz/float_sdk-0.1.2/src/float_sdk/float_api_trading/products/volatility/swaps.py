# pyright: basic
#!/usr/bin/env python

"""
Swap Product Definitions

Base classes and legacy models for variance and volatility swaps.
"""

from datetime import date

from pydantic import Field

from float_sdk.float_api.assets.base.cashflows import CalculationDateScheduleModel
from float_sdk.float_api.locations.location import TimeLocationModel
from float_sdk.float_api_trading.products.base.contractual import ContractualProductModel
from float_sdk.float_api_trading.products.settlement.terms import CashSettlementTermsModel, PremiumTermsModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class VarianceVolatilitySwapBaseModel(ContractualProductModel):
    """
    Base class for Variance and Volatility Swaps.

    Provides shared structure for equity and FX variance/volatility swaps.
    Flat structure aligned with market termsheets - all fields at product level.

    Subclasses define specific counterparty fields, notional fields, return terms,
    and product types.
    """

    # Valuation
    valuation_date: date | None = Field(
        default=None,
        title="Valuation Date",
        description="Final settlement valuation date",
    )

    valuation_time: TimeLocationModel | None = Field(
        default=None,
        title="Valuation Time",
        description="Time and location of fixing/closing price",
    )

    # Observation Schedule
    observation_dates: CalculationDateScheduleModel | None = Field(
        default=None,
        title="Observation Dates",
        description="Daily (or periodic) observation schedule for realized variance/volatility calculation",
    )

    # Optional Premium
    premium_terms: PremiumTermsModel | None = Field(
        default=None,
        title="Premium Terms",
        description="Optional upfront premium for non-zero-cost structures",
    )

    # Settlement
    settlement_terms: CashSettlementTermsModel | None = Field(
        default=None,
        title="Settlement Terms",
        description="Cash settlement terms including settlement currency and payment date",
    )


# Rebuild base model to ensure schema is fully built (Pydantic v2 requirement)
VarianceVolatilitySwapBaseModel.model_rebuild()
