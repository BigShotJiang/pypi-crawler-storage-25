# pyright: basic
#!/usr/bin/env python

"""
Valuation Models

"""

import datetime as dt
from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.base.references import CurrencyId, DealId, OrganizationId, ValuationId
from float_sdk.float_api.serialization.model import DisplayEnum


class ValuationMeasure(Enum):
    """
    Valuation measures represent the financial value and risk characteristics of a trade, deal,
    or portfolio as of a specific date. These measures include net present value (NPV), sensitivities
    (e.g., delta, vega), and market data inputs (e.g., curves, vol surfaces) used in the valuation process.
    """

    NOTIONAL = "NOTIONAL"
    MARKET_VALUE = "MARKET_VALUE"
    DELTA = "DELTA"
    VEGA = "VEGA"
    THETA = "THETA"
    RHO = "RHO"


class ValuationUnit(DisplayEnum):
    """
    Valuation units represent the type of measure being reported in a valuation.
    Common units include CURRENCY for monetary values and PERCENTAGE for relative measures.
    """

    CURRENCY = "CURRENCY"
    PERCENTAGE = "PERCENTAGE"
    BASIS_POINTS = "BASIS_POINTS"

    def display_names(self) -> dict[str, str]:
        return {
            ValuationUnit.CURRENCY.value: "Currency",
            ValuationUnit.PERCENTAGE.value: "Percentage",
            ValuationUnit.BASIS_POINTS.value: "Basis Points",
        }


class ValuationModel(ResourceModel):
    """
    A valuation represents the assessed financial value and risk characteristics of a trade, deal,
    or portfolio as of a specific date, typically produced by a pricing or risk system. It includes
    calculated measures such as net present value (NPV), sensitivities (e.g., delta, vega), and
    market data inputs (e.g., curves, vol surfaces) used in the valuation process.

    The valuation is normally reported by a given counterparty, prime broker, or third party valuation
    agent. The valuation specifies the party responsible for producing the figures. This enables
    consistent communication of pricing, risk, and exposure information between institutions.
    """

    __uri_path__ = "valuations"
    __resource_id__ = ValuationId

    deal: DealId | str | None = Field(default=None, title="Deal", description="The Float deal identifier of the deal which is being valued")
    organization: OrganizationId | str | None = Field(
        default=None, title="Organization", description="The organization to which this valuation belongs. Must be provided when submitting any valuation."
    )

    # report: str | None = None  # Link to the ValuationReport
    value: float | None = Field(default=None, title="Value", description="The numerical value of the valuation measure.")
    measure: ValuationMeasure | None = Field(default=None, title="Measure", description="The type of valuation measure (e.g., NPV, delta, vega).")
    currency: CurrencyId | str | None = Field(default=None, title="Currency", description="The currency in which the valuation is reported.")
    valuation_date: dt.date = Field(title="Valuation Date", description="The date as of which the valuation is computed.")
    valuation_time: dt.datetime | None = Field(
        default=None, title="Valuation Time", description="The time at which the valuation was computed (effective time)."
    )
    unit: ValuationUnit | None = Field(default=None, title="Unit", description="The unit of the valuation measure (e.g., currency, percentage).")
    created_time: dt.datetime | None = Field(default=None, title="Created Time", description="Timestamp when the valuation was created.")
    updated_time: dt.datetime | None = Field(default=None, title="Updated Time", description="Timestamp when the valuation was last updated.")

    semantic_type: Literal["VALUATION"] = "VALUATION"

    @property
    def resource_id(self) -> ValuationId:
        return ValuationId(id=self.id, version=self.version)
