#!/usr/bin/env python
# pyright: basic

"""

Trading Templates

Defines configuration for differnt trade types.

"""

from typing import Annotated, Any, Literal, Union

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import ContactId, GroupId, OrganizationId, PlatformId, TradeTemplateId, WorkflowDefinitionId
from float_sdk.float_api.data.fields import DataFieldPropertiesModel
from float_sdk.float_api.data.query import DataQueryModel
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import ContactModel
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.products import ValidProductModel
from float_sdk.float_api_trading.trading.processing import AffirmationType, ConfirmationType

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class TradeBaseWorkflowModel(DataModel):
    enabled: bool | None = Field(default=False, title="Enabled", description="Is this workflow enabled for this trade type")
    platform: PlatformId | str | None = Field(default=None, title="Platform", description="Platform used for this workflow")


class TradeBookingWorkflowModel(TradeBaseWorkflowModel):
    semantic_type: Literal["TRADE_BOOKING_WORKFLOW"] = "TRADE_BOOKING_WORKFLOW"


class TradeConfirmationWorkflowModel(TradeBaseWorkflowModel):
    confirmation_type: ConfirmationType | None = Field(
        default=None, title="Confirmation Type", description="By what mechanism are trades of this type to be confirmed."
    )
    semantic_type: Literal["TRADE_CONFIRMATION_WORKFLOW"] = "TRADE_CONFIRMATION_WORKFLOW"


class EmailAffirmationSettingsModel(DataModel):
    auto_send: bool | None = Field(default=None, title="Auto Send", description="Whether to automatically send affirmation emails.")
    cc_contacts: list[ContactId | str | ContactModel] | None = Field(default=None, title="CC Contacts", description="Contacts to CC on affirmation emails.")
    semantic_type: Literal["EMAIL_AFFIRMATION_SETTINGS"] = "EMAIL_AFFIRMATION_SETTINGS"


class ElectronicAffirmationSettingsModel(DataModel):
    semantic_type: Literal["ELECTRONIC_AFFIRMATION_SETTINGS"] = "ELECTRONIC_AFFIRMATION_SETTINGS"


ValidAffirmationSettings = Annotated[
    Union[EmailAffirmationSettingsModel, ElectronicAffirmationSettingsModel],
    Field(discriminator="semantic_type"),
]


class TradeAffirmationWorkflowModel(TradeBaseWorkflowModel):
    affirmation_type: AffirmationType | None = Field(
        default=None, title="Affirmation Type", description="By what mechanism are trades of this type to be affirmed."
    )
    affirmation_settings: ValidAffirmationSettings | None = Field(
        default=None, title="Affirmation Settings", description="Type-specific settings for the affirmation workflow."
    )
    semantic_type: Literal["TRADE_AFFIRMATION_WORKFLOW"] = "TRADE_AFFIRMATION_WORKFLOW"


class MatchFieldPropertiesModel(DataModel):
    enabled: bool | None = Field(default=None, title="Enabled", description="Whether the field is included when computing match")
    semantic_type: Literal["MATCH_FIELD_PROPERTIES"] = "MATCH_FIELD_PROPERTIES"


class ProductFieldAttributesModel(DataModel):
    id: str = Field(..., title="Field Id", description="Identifier of the product field")
    properties: DataFieldPropertiesModel | None = Field(
        default=None, title="Properties", description="Field level properties which drives allowed actions and user interface properties"
    )
    affirmation: MatchFieldPropertiesModel | None = Field(default=None, title="Affirmation", description="Include field when computing affirmation match")
    confirmation: MatchFieldPropertiesModel | None = Field(default=None, title="Confirmation", description="Include field when computing confirmation match")
    matching: MatchFieldPropertiesModel | None = Field(default=None, title="Matching", description="Include field when computing template match")

    semantic_type: Literal["PRODUCT_FIELD_ATTRIBUTES"] = "PRODUCT_FIELD_ATTRIBUTES"


class ProductConfigurationModel(DataModel):
    default: ValidProductModel | None = Field(default=None, title="Product", description="Default product associated with this trade template")
    fields: dict[str, ProductFieldAttributesModel] | None = Field(default=None, title="Fields", description="Field configuration")

    semantic_type: Literal["PRODUCT_CONFIGURATION"] = "PRODUCT_CONFIGURATION"

    @classmethod
    def init_forward_hints(cls) -> dict[str, Any]:
        from float_sdk.float_api_trading.products.products import ValidProductModel

        return {"ValidProductModel": ValidProductModel}


class TradeFieldAttributesModel(DataModel):
    id: str = Field(..., title="Field Id", description="Identifier of the trade field")
    properties: DataFieldPropertiesModel | None = Field(
        default=None, title="Properties", description="Field level properties which drives allowed actions and user interface properties"
    )
    affirmation: MatchFieldPropertiesModel | None = Field(default=None, title="Affirmation", description="Include field when computing affirmation match")
    confirmation: MatchFieldPropertiesModel | None = Field(default=None, title="Confirmation", description="Include field when computing confirmation match")
    matching: MatchFieldPropertiesModel | None = Field(default=None, title="Matching", description="Include field when computing template match")

    semantic_type: Literal["TRADE_FIELD_ATTRIBUTES"] = "TRADE_FIELD_ATTRIBUTES"


class TradeConfigurationModel(DataModel):
    fields: dict[str, TradeFieldAttributesModel] | None = Field(default=None, title="Fields", description="Trade field configuration")

    semantic_type: Literal["TRADE_CONFIGURATION"] = "TRADE_CONFIGURATION"


class PartyAttributesModel(DataModel):
    enabled: bool | None = Field(default=None, title="Enabled", description="Is this counterparty onboarded and enabled for this template")
    booking: TradeBookingWorkflowModel | None = Field(default=None, title="Trade Booking", description="Configuration related to trade booking")
    affirmation: TradeAffirmationWorkflowModel | None = Field(default=None, title="Affirmation", description="Configuration related to affirmation")
    confirmation: TradeConfirmationWorkflowModel | None = Field(default=None, title="Confirmation", description="Configuration related to confirmation")

    semantic_type: Literal["PARTY_ATTRIBUTES"] = "PARTY_ATTRIBUTES"


class PartyConfigurationModel(DataModel):
    entities: dict[str, PartyAttributesModel] | None = Field(default=None, title="Entities", description="Entity configuration")
    counterparties: dict[str, PartyAttributesModel] | None = Field(default=None, title="Counterparties", description="Counterparty configuration")

    semantic_type: Literal["PARTY_CONFIGURATION"] = "PARTY_CONFIGURATION"


class TradeTemplateModel(NamedResourceModel):
    __uri_path__ = "trading/templates"
    __resource_id__ = TradeTemplateId

    @classmethod
    def init_forward_hints(cls) -> dict[str, Any]:
        return {}

    ######################################################################################
    ## STRATEGIC TERMS
    ######################################################################################

    organization: OrganizationId | str | OrganizationModel | None = Field(
        ..., title="Organization", description="Parent organization for the trading template."
    )
    group: GroupId | str | None = Field(default=None, title="Group", description="Group which is used for entitlement management.")

    parent: TradeTemplateId | str | None = Field(
        default=None, title="Parent Template", description="Parent trade template from which to inherit configuration."
    )

    trade: TradeConfigurationModel | None = Field(default=None, title="Trade", description="Trade level configuration")
    product: ProductConfigurationModel | None = Field(default=None, title="Product", description="Product level configuration")
    booking: TradeBookingWorkflowModel | None = Field(default=None, title="Booking", description="Configuration for trade booking workflow.")
    affirmation: TradeAffirmationWorkflowModel | None = Field(default=None, title="Affirmation", description="Configuration for trade affirmation workflow.")
    confirmation: TradeConfirmationWorkflowModel | None = Field(
        default=None, title="Confirmation", description="Configuration for trade confirmation workflow."
    )

    ######################################################################################
    ## LEGACY BELOW
    ######################################################################################

    trade_query: DataQueryModel | None = Field(default=None, title="Query", description="Query to filter trades to match the trading template.")
    contacts: list[ContactId | str | ContactModel] | None = Field(
        default=None, title="Contacts", description="Contact information associated with this trade type."
    )

    workflow_definition: WorkflowDefinitionId | str | None = Field(
        default=None, title="Workflow Definition", description="Workflow definition associated with this trade template."
    )
    auto_match: bool | None = Field(default=None, title="Auto Match", description="Whether or not to automatically match trades that use this template.")
    auto_return: bool | None = Field(default=None, title="Auto Return", description="Whether or not to auto return documents to the dealer after signing.")
    enable_affirmation: bool | None = Field(
        default=None, title="Enable Affirmation", description="Whether or not to enable affirmation for this trade template."
    )

    semantic_type: Literal["TRADE_TEMPLATE"] = "TRADE_TEMPLATE"

    @property
    def resource_id(self) -> TradeTemplateId:
        return TradeTemplateId(id=self.id, version=self.version, name=self.name)
