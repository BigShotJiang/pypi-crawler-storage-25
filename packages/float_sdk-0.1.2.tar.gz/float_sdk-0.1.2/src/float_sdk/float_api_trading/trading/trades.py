#!/usr/bin/env python
# pyright: basic

"""
Trade Models

"""

from datetime import date, datetime
from enum import Enum
from typing import TYPE_CHECKING, List, Literal, Union

from pydantic import Field, computed_field

from float_sdk.float_api.api.messaging import FloatMessageContext, MessageDataType
from float_sdk.float_api.api.resource import ResourceIdentifierModel, ResourceModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.measures.dates import DateDimension
from float_sdk.float_api.base.measures.market import Notional, NotionalQuantityModel
from float_sdk.float_api.base.references import ApplicationId, CurrencyId, DealId, ExchangeId, OrganizationId, PersonId, ProductId, TradeId, TradeMatchId
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import ApplicationModel, PersonModel
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api_trading.products.base.contractual import QuantityUnit
from float_sdk.float_api_trading.products.collateral.terms import CollateralTermsModel
from float_sdk.float_api_trading.products.products import ValidProductModel
from float_sdk.float_api_trading.products.settlement.terms import TerminationFeeTermsModel
from float_sdk.float_api_trading.trading.parties import CounterpartyRole, PartyModel
from float_sdk.float_api_trading.trading.processing import TradeProcessingModel

if TYPE_CHECKING:
    pass


__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."


class TradeIdentifierType(DisplayEnum):
    TRADE_ID = "TRADE_ID"
    CONTRACT_ID = "CONTRACT_ID"
    GROUP_ID = "GROUP_ID"
    TRADE_NAME = "TRADE_NAME"
    TRADE_VERSION = "TRADE_VERSION"
    DEAL_ID = "DEAL_ID"
    UNIQUE_PRODUCT_IDENTIFIER = "UNIQUE_PRODUCT_IDENTIFIER"
    UNIQUE_SWAP_IDENTIFIER = "UNIQUE_SWAP_IDENTIFIER"
    UNIQUE_TRANSACTION_IDENTIFIER = "UNIQUE_TRANSACTION_IDENTIFIER"
    EXECUTION_ID = "EXECUTION_ID"
    QUOTE_ID = "QUOTE_ID"
    ORDER_ID = "ORDER_ID"
    TRADE_CAPTURE_ID = "TRADE_CAPTURE_ID"

    def display_names(self) -> dict[str, str]:
        return {
            "TRADE_ID": "Trade ID",
            "CONTRACT_ID": "Contract ID",
            "TRADE_NAME": "Trade Name",
            "TRADE_VERSION": "Trade Version",
            "EXECUTION_ID": "Execution ID",
            "QUOTE_ID": "Quote ID",
            "UNIQUE_SWAP_IDENTIFIER": "Unique Swap Identifier",
            "UNIQUE_TRANSACTION_IDENTIFIER": "Unique Transaction Identifier",
            "UNIQUE_PRODUCT_IDENTIFIER": "Unique Product Identifier",
            "TRADE_CAPTURE_ID": "Trade Capture ID",
        }


class TradeIdentifier(ResourceIdentifierModel):
    type: TradeIdentifierType = TradeIdentifierType.TRADE_ID
    side: CounterpartyRole | None = None


class DealIdentifierType(Enum):
    CONTRACT_ID = "CONTRACT_ID"


class DealIdentifier(ResourceIdentifierModel):
    type: DealIdentifierType = Field(default=..., description="The type of identifier")
    side: CounterpartyRole | None = None


class TradeStatus(DisplayEnum):
    DRAFT = "DRAFT"
    BACKFILLED = "BACKFILLED"
    LIVE = "LIVE"
    DELETED = "DELETED"
    CANCELLED = "CANCELLED"

    def display_names(self) -> dict[str, str]:
        return {
            "DRAFT": "Draft",
            "BACKFILLED": "Backfilled",
            "LIVE": "Live",
            "DELETED": "Deleted",
            "CANCELLED": "Cancelled",
        }


class TradeType(DisplayEnum):
    EXECUTION = "EXECUTION"
    PARTIAL_UNWIND = "PARTIAL_UNWIND"
    FULL_UNWIND = "FULL_UNWIND"
    NOVATION = "NOVATION"
    PARTIAL_NOVATION = "PARTIAL_NOVATION"
    FULL_NOVATION = "FULL_NOVATION"
    AMENDMENT = "AMENDMENT"
    BARRIER_EVENT = "BARRIER_EVENT"
    BARRIER_BREACH = "BARRIER_BREACH"
    EXERCISE = "EXERCISE"
    EXPIRE = "EXPIRE"
    UPSIZE = "UPSIZE"
    PAYMENT = "PAYMENT"

    def display_names(self) -> dict[str, str]:
        return {
            "EXECUTION": "Execution",
            "FULL_UNWIND": "Full Unwind",
            "PARTIAL_UNWIND": "Partial Unwind",
            "UPSIZE": "Upsize",
            "AMENDMENT": "Amendment",
            "NOVATION": "Novation",
            "BARRIER_EVENT": "Barrier Event",
            "EXERCISE": "Exercise",
            "EXPIRE": "Expire",
            "PAYMENT": "Payment",
        }


class AllowedTradeEventModel(DataModel):
    """Model representing an allowed trade event type for a deal"""

    tradeType: TradeType = Field(..., description="The trade type/event that is allowed")
    name: str = Field(..., description="Display name for the trade event")

    semantic_type: Literal["ALLOWED_TRADE_EVENT"] = "ALLOWED_TRADE_EVENT"


class ExecutionType(DisplayEnum):
    """

    ELECTRONIC : Execution via electronic execution facility, derivatives contract market, or other electronic message such as an instant message.
    OFF_FACILITY : Bilateral execution between counterparties not pursuant to the rules of a SEF or DCM.
    ON_VENUE : Execution via a platform that may or may not be covered by a regulatory defintion. OnVenue is intended to distinguish trades executed on a trading platform from those executed via phone, email or messaging apps. The role and details of the venue are included in the party attribute of the trade. The general rule is that if the parties utilitzed the services of the platform to execute the trade then it would be considered OnVenue.

    """

    ELECTRONIC = "ELECTRONIC"
    OFF_FACILITY = "OFF_FACILITY"
    ON_VENUE = "ON_VENUE"

    def display_names(self) -> dict[str, str]:
        return {
            "ELECTRONIC": "Electronic",
            "OFF_FACILITY": "Off Facility",
            "ON_VENUE": "On Venue",
        }


class TradeUpdateAction(Enum):
    NEW = "NEW"
    CANCEL = "CANCEL"
    REPLACE = "REPLACE"


class TradeUpdateModel(DataModel):
    action: TradeUpdateAction = Field(..., title="Action", description="The type of update being made to the trade.")
    update_time: datetime | None = Field(default=None, title="Update Time", description="The time at which the trade was updated")
    cancellation_date: date | None = Field(default=None, title="Cancellation Date", description="Cancellation date of the trade.")
    cancellation_time: datetime | None = Field(default=None, title="Cancellation Time", description="Cancellation time of the trade.")
    comment: str | None = Field(default=None, title="Comment", description="A comment associated with the trade update.")

    semantic_type: Literal["TRADE_UPDATE"] = "TRADE_UPDATE"


class TradingEventModel(DataModel):
    """Base model for trade lifecycle events (executions, novations, terminations, etc.)."""

    ...


class ExecutionDetailsModel(DataModel):
    execution_type: ExecutionType | None = Field(default=None)
    execution_venue: ExchangeId | None = Field(default=None, title="Execution Venue", description="The venue where the execution took place.")

    semantic_type: Literal["EXECUTION_DETAILS"] = "EXECUTION_DETAILS"


class QuantityChangeEvent(TradingEventModel):
    buyer: CounterpartyRole | None = Field(default=None, title="Buyer", description="Which party is buyer on this trade event")
    seller: CounterpartyRole | None = Field(default=None, title="Seller", description="Which party is seller on this trade event")
    quantity: float | None = Field(default=None, title="Quantity", description="Quantity change on the trade event")
    currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Currency", description="Currency of the quantity change")
    unit: QuantityUnit | None = Field(default=None, title="Units")
    execution_details: ExecutionDetailsModel | None = Field(
        default=None, title="Execution Details", description="Nature of the execution, for example whether it was traded voice or electronic."
    )


class ExecutionModel(QuantityChangeEvent):
    # Price / Quantity
    # price_quantity: NotionalQuantityModel

    # Execution
    execution_date: date | None = Field(default=None, title="Execution Date", description="The date on which the execution took place.")
    collateral_terms: CollateralTermsModel | None = Field(default=None, title="Collateral Terms", description="Terms of the collateral payment.")

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            execution_date = DateDimension(value=self.execution_date).serialize() if self.execution_date and isinstance(self.execution_date, date) else ""
            currency: CurrencyId | None = self.currency if isinstance(self.currency, CurrencyId) else None
            notional_quantity = NotionalQuantityModel(currency=currency, notional=Notional(value=self.quantity)).serialize()

        return f"EXECUTE {notional_quantity} {execution_date}".strip()

    semantic_type: Literal["EXECUTION"] = "EXECUTION"


class NovationModel(TradingEventModel):
    novation_date: date | None = Field(default=None, title="Novation Date", description="Date the novation event was executed.")
    novation_amount: float | None = Field(default=None, title="Novation Amount", description="Amount of the novation event.")
    novation_currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Novation Currency", description="Currency of the novation event.")
    unit: QuantityUnit | None = Field(default=None, title="Units")
    transferor: PartyModel | None = Field(default=None, title="Transferor", description="The party that is transferring the trade to the transferee.")
    transferee: PartyModel | None = Field(default=None, title="Transferee", description="The party that is receiving the trade from the transferrer.")
    remaining_party: PartyModel | None = Field(default=None, title="Remaining Party", description="The party that is remaining after the transfer.")
    fee_terms: TerminationFeeTermsModel | None = Field(default=None, title="Termination Fee Terms", description="The terms for the termination fee.")
    execution_details: ExecutionDetailsModel | None = Field(
        default=None, title="Execution Details", description="Nature of the execution, for example whether it was traded voice or electronic."
    )

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            novation_date = DateDimension(value=self.novation_date).serialize() if self.novation_date and isinstance(self.novation_date, date) else ""
            novation_currency: CurrencyId | None = self.novation_currency if isinstance(self.novation_currency, CurrencyId) else None
            notional_quantity = NotionalQuantityModel(currency=novation_currency, notional=Notional(value=self.novation_amount)).serialize()

        return f"NOVATE {notional_quantity} {novation_date}"

    semantic_type: Literal["NOVATION"] = "NOVATION"


class FullNovationModel(NovationModel):
    semantic_type: Literal["FULL_NOVATION"] = "FULL_NOVATION"


class PartialNovationModel(NovationModel):
    semantic_type: Literal["PARTIAL_NOVATION"] = "PARTIAL_NOVATION"


class TerminationModel(QuantityChangeEvent):
    termination_date: date | None = Field(default=None, title="Termination Date", description="The date on which the event is terminated.")
    fee_terms: TerminationFeeTermsModel | None = Field(default=None, title="Termination Fee Terms", description="The terms for the termination fee.")

    def event_name(self) -> str: ...

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            termination_date = (
                DateDimension(value=self.termination_date).serialize() if self.termination_date and isinstance(self.termination_date, date) else ""
            )
            currency: CurrencyId | None = self.currency if isinstance(self.currency, CurrencyId) else None
            quantity = NotionalQuantityModel(currency=currency, notional=Notional(value=self.quantity)).serialize() if self.quantity else ""

        return f"{self.event_name()} {quantity} {termination_date}".strip()


class FullUnwindModel(TerminationModel):
    def event_name(self) -> str:
        return "FULL UNWIND"

    semantic_type: Literal["FULL_UNWIND"] = "FULL_UNWIND"


class PartialUnwindModel(TerminationModel):
    def event_name(self) -> str:
        return "PARTIAL UNWIND"

    semantic_type: Literal["PARTIAL_UNWIND"] = "PARTIAL_UNWIND"


class UpsizeModel(QuantityChangeEvent):
    upsize_date: date | None = Field(default=None, title="Upsize Date", description="The date on which the upsize takes effect.")
    fee_terms: TerminationFeeTermsModel | None = Field(default=None, title="Fee Terms", description="The terms for any fees associated with the upsize.")

    def event_name(self) -> str:
        return "UPSIZE"

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            upsize_date = DateDimension(value=self.upsize_date).serialize() if self.upsize_date and isinstance(self.upsize_date, date) else ""
            currency: CurrencyId | None = self.currency if isinstance(self.currency, CurrencyId) else None
            quantity = NotionalQuantityModel(currency=currency, notional=Notional(value=self.quantity)).serialize() if self.quantity else ""

        return f"{self.event_name()} {quantity} {upsize_date}".strip()

    semantic_type: Literal["UPSIZE"] = "UPSIZE"


class ExerciseModel(TradingEventModel):
    exercise_date: date | None = Field(default=None, title="Exercise Date", description="The date on which the option is exercised.")

    def event_name(self) -> str:
        return "EXERCISE"

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            exercise_date = DateDimension(value=self.exercise_date).serialize() if self.exercise_date and isinstance(self.exercise_date, date) else ""

        return f"{self.event_name()} {exercise_date}".strip()

    semantic_type: Literal["EXERCISE"] = "EXERCISE"


class PartialExerciseModel(TradingEventModel):
    exercise_date: date | None = Field(default=None, title="Exercise Date", description="The date on which the option is exercised.")

    def event_name(self) -> str:
        return "PARTIAL EXERCISE"

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            exercise_date = DateDimension(value=self.exercise_date).serialize() if self.exercise_date and isinstance(self.exercise_date, date) else ""

        return f"{self.event_name()} {exercise_date}".strip()

    semantic_type: Literal["PARTIAL_EXERCISE"] = "PARTIAL_EXERCISE"


class FullExerciseModel(TradingEventModel):
    exercise_date: date | None = Field(default=None, title="Exercise Date", description="The date on which the option is exercised.")

    def event_name(self) -> str:
        return "FULL EXERCISE"

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            exercise_date = DateDimension(value=self.exercise_date).serialize() if self.exercise_date and isinstance(self.exercise_date, date) else ""

        return f"{self.event_name()} {exercise_date}".strip()

    semantic_type: Literal["FULL_EXERCISE"] = "FULL_EXERCISE"


class ExpireModel(TradingEventModel):
    expiration_date: date | None = Field(default=None, title="Expiration Date", description="The date on which the option expired.")

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            expiration_date = DateDimension(value=self.expiration_date).serialize() if self.expiration_date and isinstance(self.expiration_date, date) else ""

        return f"EXPIRE {expiration_date}".strip()

    semantic_type: Literal["EXPIRE"] = "EXPIRE"


class BarrierEventModel(TradingEventModel):
    event_date: date | None = Field(default=None, title="Event Date", description="The date on which the barrier event occurred.")

    semantic_type: Literal["BARRIER_EVENT"] = "BARRIER_EVENT"


class BarrierBreachModel(TradingEventModel):  # DEPRECATED
    semantic_type: Literal["BARRIER_BREACH"] = "BARRIER_BREACH"


class AmendmentModel(TradingEventModel):
    semantic_type: Literal["AMENDMENT"] = "AMENDMENT"


class CancelModel(TradingEventModel):
    cancellation_date: date | None = Field(default=None, title="Cancellation Date", description="Cancellation date of the trade.")
    cancellation_time: datetime | None = Field(default=None, title="Cancellation Time", description="The time at which the trade was cancelled.")
    cancellation_reason: str | None = Field(default=None, title="Cancellation Reason", description="The reason for the cancellation.")

    @computed_field
    @property
    def name(self) -> str | None:
        with FloatMessageContext(message_type=MessageDataType.STRING):
            cancellation_date = (
                DateDimension(value=self.cancellation_date).serialize() if self.cancellation_date and isinstance(self.cancellation_date, date) else ""
            )

        return f"CANCEL {cancellation_date}".strip()

    semantic_type: Literal["CANCEL"] = "CANCEL"


TradeEventModels = Union[
    ExecutionModel,
    PartialUnwindModel,
    FullUnwindModel,
    UpsizeModel,
    PartialNovationModel,
    FullNovationModel,
    NovationModel,
    BarrierEventModel,
    BarrierBreachModel,
    AmendmentModel,
    ExerciseModel,
    PartialExerciseModel,
    FullExerciseModel,
    ExpireModel,
    CancelModel,
]


class MatchStatus(Enum):
    MATCHED = "MATCHED"
    CONFIRMED = "CONFIRMED"


class MatchType(Enum):
    CONFIRMATION = "CONFIRMATION"
    AFFIRMATION = "AFFIRMATION"
    VALUATION = "VALUATION"
    MATCHING = "MATCHING"
    TEMPLATE = "TEMPLATE"


class DealState(Enum):
    LIVE = "LIVE"
    ALLOCATED = "ALLOCATED"
    TERMINATED = "TERMINATED"
    CANCELLED = "CANCELLED"
    EXERCISED = "EXERCISED"
    EXPIRED = "EXPIRED"
    NOVATED = "NOVATED"
    MATURED = "MATURED"


class TradeMatchMetricsModel(DataModel):
    recommended_match: bool | None = Field(
        default=None,
        title="Recommended Match",
        description="Indicates if the trade selected was the trade recommended for matching to the user. If true, the trade was the recommended match when presented to the user.",
    )

    suggested_match: bool | None = Field(
        default=None,
        title="Suggested Match",
        description="Indicates if the trade selected was one of the trades suggested for matching. If true, the trade was suggested as a match and selected by the user.",
    )

    auto_matched: bool | None = Field(
        default=None,
        title="Auto Matched",
        description="Indicates if the trades were automatically matched. If true, the trades was matched automatically by the system. If false, the trade was matched manually by a human.",
    )

    match_rank: int | None = Field(
        default=None,
        title="Match Rank",
        description="The rank of the trade match. The rank represents the sequence it was suggested as a match candidate, with 1 being the suggested match. A higher rank indicates a better match.",
    )

    fields_matched: int | None = Field(
        default=None,
        title="Fields Matched",
        description="The number of fields that were matched between the two trades. A higher number indicates a better match.",
    )
    fields_not_matched: int | None = Field(
        default=None,
        title="Fields Not Matched",
        description="The number of fields that were not matched between the two trades. A higher number indicates a worse match.",
    )
    fields_ignored: int | None = Field(
        default=None,
        title="Fields Ignored",
        description="The number of fields that were ignored during the matching process as they were not appliable to this trade or product type.",
    )

    match_score: float | None = Field(
        default=None,
        title="Match Score",
        description="The match score of the trades at point of trade match. The match score is a value between 0 and 1 that indicates how closely the trade matches with another trade. A higher match score indicates a better match., with 1 meaning a perfect match across all economic terms.",
    )

    semantic_type: Literal["TRADE_MATCH_METRICS"] = "TRADE_MATCH_METRICS"


class TradeMatchModel(ResourceModel):
    __uri_path__ = "trading/trades/match"
    __resource_id__ = TradeMatchId

    status: MatchStatus | None = Field(default=None, title="Status", description="The status of the match")
    match_type: MatchType | None = Field(default=None, title="Type", description="The type of trade match")
    matched_time: datetime | None = Field(default=None, title="Matched Time", description="Time at which the trades were matched")
    matched_by: PersonId | str | PersonModel | ApplicationId | ApplicationModel | None = Field(
        default=None, title="Matched By", description="The user who matched the trades"
    )

    trade_1: TradeId | str | None = Field(default=None, title="Trade 1", description="The party 1 trade that was matched")
    trade_2: TradeId | str | None = Field(default=None, title="Trade 2", description="The party 2 trade that was matched")
    deal_1: DealId | str | None = Field(default=None, title="Deal 1", description="The party 1 deal that was matched")
    deal_2: DealId | str | None = Field(default=None, title="Deal 2", description="The party 2 deal that was matched")

    organization: OrganizationId | str | OrganizationModel | None = Field(
        default=None, title="Organization", description="The organization which owns this match"
    )

    metrics: TradeMatchMetricsModel | None = Field(default=None, title="Metrics", description="Trade matching metrics for the trade match event")

    confirmed_time: datetime | None = Field(default=None, title="Confirmed Time", description="Time at which the trade was confirmed")
    confirmed_by: PersonId | str | PersonModel | ApplicationId | ApplicationModel | None = Field(default=None, title="The user who confirmed the trade")
    workflow: str | None = Field(default=None, title="Workflow", description="The workflow associated with the trade match")

    semantic_type: Literal["TRADE_MATCH"] = "TRADE_MATCH"

    @property
    def resource_id(self) -> TradeMatchId:
        return TradeMatchId(id=self.id, version=self.version)


class TradeModel(ResourceModel):
    __uri_path__ = "trading/trades"
    __resource_id__ = TradeId

    # Trade entry details
    #
    trade_date: date | None = Field(default=None, title="Trade Date", description="Date the trade was executed.")
    trade_time: datetime | None = Field(
        default=None,
        title="Trade Time",
        description="Time at which the trade was executed. This is the trade execution time rather than the entry time. For example, if the trade was executed at 10:00 and the entry time was 11:00, the trade time would be 10:00. This can be used to sequence trade events, as well as for various reporting purposes.",
    )
    trade_type: TradeType | None = Field(
        default=None,
        title="Trade Type",
        description="The type of trade, which defines the contractual terms and settlement terms.",
    )
    status: TradeStatus | None = Field(
        default=None,
        title="Trade Status",
        description="The status of the trade. Trades can be created in DRAFT status, which indicates they are not to be included in any live process (for example, not rolled up into positions or matched with other trades). LIVE trades are active and applied to position or other updates. Trades can be in DELETED status, which means they are queryable but no longer contribute to the live position. ",
    )
    event: TradeEventModels | None = Field(
        default=None,
        title="Event",
        description="The details of the event which triggered the trade. The event details will be specific to the trade type. For example, an execution trade will have details on traded quantity, buyer seller, etc.",
    )
    update: TradeUpdateModel | None = Field(
        default=None,
        title="Event",
        description="Details of trade update.",
    )

    product: ProductId | ValidProductModel | str | None = Field(
        default=None,
        title="Product",
        description="Financial product which defines the contractual terms or security which is created or modified as a result of the transaction. The product should represent the contractual state after the trade effects have been applied (e.g. the new trade state).",
    )

    # Counterparty information
    #
    party_1: PartyModel | None = Field(
        default=None,
        title="Party 1",
        description="First counterparty on the trade. This will generally be the party which is responsible for quoting and issuing a confirmation for the trade, usually a dealer.",
    )
    party_2: PartyModel | None = Field(
        default=None,
        title="Party 2",
        description="Second counterparty on the trade. This is generally the counterparty to the trade, usually a buy side firm who is executing with the dealer. ",
    )
    additional_parties: List[PartyModel] | None = Field(
        default=None,
        title="Additional Parties",
        description="Additional counterparties involved in the transaction. For example, brokers, clearing houses, etc. Defines the relevant entity, account, and people involved in the trade along with associated roles",
    )

    # Identifiers
    #
    deal: DealId | str | None = Field(
        default=None,
        title="Deal",
        description="The deal which this trade is part of. This is a unique identifier created by Float when a new contractual agreement is created. This attribute must be provided when submitting any live lifecycle trades (for example an upsize), which must link back to the original trade through the deal id. ",
    )
    organization: OrganizationId | str | None = Field(
        default=None, title="Organization", description="The organization to which this trade belongs. Must be provided when submitting any trade.."
    )

    identifiers: List[TradeIdentifier] | None = Field(
        default=None,
        title="Identifiers",
        description="Identifiers associated with the trade, which allow tracking of various identifiers used by the organizations and systems which interact with the trade.",
    )

    ## Matching
    #
    side: CounterpartyRole | None = Field(
        default=None, title="Side", description="The side of the trade. Defines which counterparty submitted the record for matching purposes"
    )

    ## Processing
    #
    trade_processing: TradeProcessingModel | None = Field(
        default=None, title="Trade Processing", description="Trade processing workflow details for various workflow types"
    )

    semantic_type: Literal["TRADE"] = "TRADE"

    @classmethod
    def init_forward_hints(cls):
        from float_sdk.float_api_trading.products.products import ValidProductModel

        return {"ValidProductModel": ValidProductModel}

    @property
    def resource_id(self) -> TradeId:
        return TradeId(id=self.id, version=self.version)

    def context(self) -> str:
        return self.to_json(indent=2)


class DealModel(ResourceModel):
    __resource_id__ = DealId
    __uri_path__ = "trading/deals"

    organization: OrganizationId | str | None = Field(default=None, title="Organization", description="The organization which this trade is part of.")
    identifiers: List[DealIdentifier] | None = Field(default=None, title="Identifiers", description="Identifiers for the deal")
    live_trade: TradeId | str | None = Field(default=None, title="Live Trade", description="The trade which is the current live trade for the deal")
    state: DealState | None = Field(default=None, title="State", description="The current state of the deal")

    semantic_type: Literal["DEAL"] = "DEAL"

    @property
    def resource_id(self) -> DealId:
        return DealId(id=self.id, version=self.version)
