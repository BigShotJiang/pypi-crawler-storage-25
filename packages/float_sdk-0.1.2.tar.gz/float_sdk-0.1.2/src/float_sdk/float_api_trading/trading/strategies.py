# pyright: basic
#!/usr/bin/env python

"""
Trading Strategy Models

"""

from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import OrganizationId, StrategyId
from float_sdk.float_api.organizations.organization import OrganizationModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2024, Float Technologies Inc."
__email__ = "andy@float.tech"


class StrategyStatus(Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class StrategyModel(NamedResourceModel):
    __uri_path__ = "trading/strategies"
    __resource_id__ = StrategyId

    # Identifiers
    #
    short_code: str | None = Field(default=None, title="Short Code", description="Short code for the strategy which is unique to this organization.")
    # identifiers: List[StrategyIdentifier] | None = Field(default=None, title="Identifiers", description="Identifiers associated with the strategy.")
    name: str | None = Field(default=None, title="Name", description="The name of the strategy.")
    organization: OrganizationId | str | OrganizationModel | None = Field(
        default=None, title="Organization", description="The organization which this strategy belongs."
    )
    status: StrategyStatus | None = Field(default=None, title="Status", description="Current status of the strategy.")

    semantic_type: Literal["STRATEGY"] = "STRATEGY"

    @property
    def resource_id(self) -> StrategyId:
        return StrategyId(id=self.id, version=self.version)
