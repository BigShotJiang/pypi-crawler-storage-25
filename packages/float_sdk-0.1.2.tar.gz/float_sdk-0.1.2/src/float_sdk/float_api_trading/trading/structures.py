# pyright: basic
#!/usr/bin/env python

"""
Structuring Models
"""

import contextvars
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.api.validation import ValidationResultsModel
from float_sdk.float_api.base.references import (
    ApplicationId,
    DealId,
    OrganizationId,
    PersonId,
    StructureId,
    TradeId,
    TradeTemplateId,
)
from float_sdk.float_api.data.query import DataQueryTypedResultsModel
from float_sdk.float_api.data.schema import DataSchemaModel
from float_sdk.float_api.organizations.people import ApplicationModel, PersonModel
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api_trading.products.base.securities import ProductType
from float_sdk.float_api_trading.products.products import ProductDefinitionModel
from float_sdk.float_api_trading.trading.trades import TradeModel, TradeType

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."

_structuring_context_var = contextvars.ContextVar("structuring_context")


class CompareResult(Enum):
    MATCHED = "MATCHED"
    NOT_MATCHED = "NOT_MATCHED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class CompareFieldResultModel(DataModel):
    compare_result: CompareResult | None = Field(
        default=None,
        title="Match",
        description="True if the trade matches the structure, false otherwise.",
    )
    values: list[str | None] | None = Field(
        default=None,
        title="Values",
        description="Field values from each side of the comparison.",
    )

    semantic_type: Literal["COMPARE_FIELD_RESULT"] = "COMPARE_FIELD_RESULT"


class CompareMetricsModel(DataModel):
    matching: int | None = Field(default=None, title="Matching", description="Number of fields matching")
    total: int | None = Field(default=None, title="Total", description="Total number of fields")
    match_score: float | None = Field(default=None, title="Match Score", description="Match score for the structure")
    field_metrics: Dict[str, CompareFieldResultModel] | None = Field(
        default=None,
        title="Field Metrics",
        description="Metrics for each field in the trades",
    )

    semantic_type: Literal["COMPARE_METRICS"] = "COMPARE_METRICS"


class StructureModel(NamedResourceModel):
    __uri_path__ = "trading/structures"
    __resource_id__ = StructureId

    @classmethod
    def init_forward_hints(cls) -> dict[str, Any]:
        return {}

    organization: OrganizationId | str | None = Field(
        default=None, title="Organization", description="The organization to which this structure belongs. Must be provided when structuring new trades."
    )
    trades: List[TradeModel] | None = Field(default=None, description="List of trades associated with this structure")
    data_schema: DataSchemaModel | None = Field(default=None, description="Data schema for the structure")
    data_schemas: List[DataSchemaModel] | None = Field(default=None, description="Per-trade data schemas for the structure")
    data_rows: List[Any] | None = Field(default=None, description="Data rows for the structure")
    created_time: datetime | None = Field(default=None, title="Created Time", description="The time the structure was created (UTC).")
    created_by: PersonId | str | PersonModel | ApplicationId | ApplicationModel | None = Field(
        default=None, description="The identifier of the person who created the structure."
    )
    last_updated_time: datetime | None = Field(default=None, title="Last Updated Time", description="The last time the structure was updated (UTC).")
    last_updated_by: PersonId | str | PersonModel | ApplicationId | ApplicationModel | None = Field(
        default=None, description="The identifier of the person who last updated the structure."
    )
    compare_metrics: CompareMetricsModel | None = None
    validation_results: list[ValidationResultsModel] | None = Field(
        default=None, title="Validation Results", description="Validation results for the structure's trades"
    )
    semantic_type: Literal["STRUCTURE"] = "STRUCTURE"


class StructuringMode(Enum):
    NONE = "NONE"
    PATCH = "PATCH"
    REFRESH = "REFRESH"


class StructuringContextMeta(type):
    @property
    def current(cls):
        return _structuring_context_var.get(None) or StructuringContext(StructuringMode.NONE)


class StructuringContext(metaclass=StructuringContextMeta):
    def __init__(self, mode: StructuringMode, data_rows: list[dict[str, Any]] | None = None):
        self.mode = mode
        self.data_rows = data_rows
        self._token: contextvars.Token | None = None

    def __enter__(self):
        self._token = _structuring_context_var.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._token is not None:
            _structuring_context_var.reset(self._token)

    @staticmethod
    def current() -> "StructuringContext":
        return _structuring_context_var.get(None) or StructuringContext(StructuringMode.NONE)


class StructureActionModelType(Enum):
    DEAL = "DEAL"
    TRADE = "TRADE"
    PRODUCT = "PRODUCT"
    TRADE_TYPE = "TRADE_TYPE"
    TEMPLATE = "TEMPLATE"


class StructureActionCommand(Enum):
    NEW = "NEW"
    PARTIAL_NOVATION = "PARTIAL_NOVATION"
    FULL_NOVATION = "FULL_NOVATION"
    PARTIAL_UNWIND = "PARTIAL_UNWIND"
    FULL_UNWIND = "FULL_UNWIND"
    UPSIZE = "UPSIZE"
    CANCEL = "CANCEL"


class StructureAction(Enum):
    """Actions that can be performed on a structure's trades"""

    ## Additions
    ADD_TRADE = "ADD_TRADE"
    ADD_PRODUCT = "ADD_PRODUCT"
    ADD_HEDGE = "ADD_HEDGE"

    ## Actions
    BOOK = "BOOK"
    DUPLICATE = "DUPLICATE"
    REMOVE = "REMOVE"
    EDIT = "EDIT"
    CANCEL = "CANCEL"
    CANCEL_REBOOK = "CANCEL_REBOOK"
    GROUP = "GROUP"
    UNGROUP = "UNGROUP"

    ## No Structure
    ACCEPT_TRADE = "ACCEPT_TRADE"


class StructureCreateActionModel(DataModel):
    name: str | None = Field(default=None, title="Name", description="The name of the action")
    type: StructureActionModelType | None = Field(default=None, title="Type", description="The type of action to perform")
    id: TradeId | DealId | TradeType | TradeTemplateId | ProductType | str = Field(
        ..., title="Id", description="The id of the underlying trade, product, or trade on which the action is to be performed"
    )
    command: StructureActionCommand | None = Field(default=None, title="Command", description="The command to perform")

    ## Embedded results
    #
    trade: TradeId | TradeModel | None = Field(default=None, title="Trade", description="The trade on which to perform the action")
    product: ProductDefinitionModel | None = Field(default=None, title="Product", description="The product on which to perform the action")

    semantic_type: Literal["STRUCTURE_CREATE_ACTION"] = "STRUCTURE_CREATE_ACTION"


StructureCreateActionResultsModel = DataQueryTypedResultsModel[StructureCreateActionModel]
