#!/usr/bin/env python
# pyright: basic

"""
Trade Processing Models

"""

from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.base.references import PlatformId, TradeTemplateId
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."


class TradeProcessingDetailModel(DataModel):
    eligible: bool | None = Field(default=None, title="Eligible", description="Whether the trade is eligible for this workflow")
    platform: PlatformId | str | None = Field(default=None, title="Platform", description="Platform used for this workflow")

    semantic_type: Literal["TRADE_PROCESSING_DETAIL"] = "TRADE_PROCESSING_DETAIL"


class AffirmationType(Enum):
    """
    Enumeration of affirmation workflow types.

    Attributes:
        ELECTRONIC: The trade will be confirmed through and electronic confirmation platform
        PAPER: The trade will be confirmed through a paper documentation process
    """

    ELECTRONIC = "ELECTORNIC"
    EMAIL = "EMAIL"


class AffirmationProcessingDetailModel(TradeProcessingDetailModel):
    affirmation_type: AffirmationType | None = Field(default=None, title="Affirmation Type", description="By what mechanism the trade is to be affirmed.")
    semantic_type: Literal["AFFIRMATION_PROCESSING_DETAIL"] = "AFFIRMATION_PROCESSING_DETAIL"


class ConfirmationType(Enum):
    """
    Enumeration of confirmation types for trading processes.

    Attributes:
        ELECTRONIC: The trade will be confirmed through and electronic confirmation platform
        PAPER: The trade will be confirmed through a paper documentation process
    """

    ELECTRONIC = "ELECTORNIC"
    PAPER = "PAPER"


class ConfirmationProcessingDetailModel(TradeProcessingDetailModel):
    confirmation_type: ConfirmationType | None = Field(default=None, title="Confirmation Type", description="By what mechanism the trade is to be confirmed.")
    semantic_type: Literal["CONFIRMATION_PROCESSING_DETAIL"] = "CONFIRMATION_PROCESSING_DETAIL"


class TradeProcessingModel(DataModel):
    template: TradeTemplateId | str | None = Field(default=None, title="Template", description="The trade template from which this trade was booked")
    affirmation: AffirmationProcessingDetailModel | None = Field(
        default=None, title="Affirmation", description="Details for the affirmation workflow for this trade"
    )

    confirmation: ConfirmationProcessingDetailModel | None = Field(
        default=None, title="Confirmation", description="Details for the confirmation workflow for this trade"
    )

    semantic_type: Literal["TRADE_PROCESSING"] = "TRADE_PROCESSING"
