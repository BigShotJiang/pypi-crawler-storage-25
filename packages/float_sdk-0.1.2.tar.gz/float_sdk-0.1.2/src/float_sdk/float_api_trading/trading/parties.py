#!/usr/bin/env python
# pyright: basic

"""
Parties to Financial Transactions

"""

from enum import Enum
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.base.references import CounterpartyRelationshipId, CredentialsId, EntityId, OrganizationId, PersonId, PortfolioId, StrategyId, TradingAccountId
from float_sdk.float_api.iam.identity import CredentialsModel
from float_sdk.float_api.organizations.account import TradingAccountModel
from float_sdk.float_api.organizations.contact import ContactInfoModel
from float_sdk.float_api.organizations.legal import EntityModel
from float_sdk.float_api.organizations.party_role import PartyRole
from float_sdk.float_api.organizations.people import PersonIdentifier, PersonModel
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api.trading.parties import CounterpartyRole
from float_sdk.float_api_trading.portfolios.portfolios import PortfolioModel
from float_sdk.float_api_trading.trading.strategies import StrategyModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class NaturalPersonRole(Enum):
    """
    Natural Person Role
    Roles of an individual person with respect to a transaction.

    This is taken from CDM with the exception for BUYER/SELLER which are dependent on party view
    Attributes
    ----------
    BUYER : Acquirer of the legal title to the financial instrument.
    DECISION_MAKER : The party or person with legal responsibility for authorization of the execution of the transaction.
    EXECUTION_WITHIN_FIRM : Person within the firm who is responsible for execution of the transaction.
    INVESTMENT_DECISION_MAKER : Person who is responsible for making the investment decision, for example the portfolio
        manager in the context of a buy-side institution with separate execution desk.
    TRADER : The person who executed the trade.
    """

    BROKER = "BROKER"
    DECISION_MAKER = "DECISION_MAKER"
    EXECUTION_WITHIN_FIRM = "EXECUTION_WITHIN_FIRM"
    INVESTMENT_DECISION_MAKER = "INVESTMENT_DECISION_MAKER"
    SELLER = "SELLER"
    TRADER = "TRADER"
    SALES_PERSON = "SALES_PERSON"


class PersonInvolvedModel(DataModel):
    semantic_type: Literal["PERSON_INVOLVED"] = "PERSON_INVOLVED"
    person: PersonId | str | PersonModel | None = Field(default=None, title="Person", description="The person involved in the transaction.")
    role: NaturalPersonRole | None = Field(default=None, title="Role", description="Role of the person involved in the transaction")
    identifiers: List[PersonIdentifier] | None = Field(default=None, title="Identifiers", description="Identifiers of the person involved in the transaction")


class PartyModel(DataModel):
    entity: EntityId | str | EntityModel | None = Field(
        default=None,
        title="Entity",
        description="The legal entity on behalf of which the trader executed the transaction, which will be used in the confirmation.",
    )
    people: list[PersonInvolvedModel] | None = Field(
        default=None,
        title="People",
        description="Optional information about people involved in a transaction or business process. (These are employees of the party, for example trader, portfolio manager, salesperson, etc.)",
    )
    role: CounterpartyRole | PartyRole | None = Field(
        default=None,
        title="Role",
        description="The category of the relationship. The fixed payment account can only be specified as a party role for additional parties.",
    )
    portfolio: PortfolioId | str | PortfolioModel | None = Field(
        default=None,
        title="Portfolio",
        description="Portfolio at time of booking.",
    )
    account: TradingAccountId | str | TradingAccountModel | None = Field(
        default=None, title="Account", description="Optional account information that could be associated to the event."
    )
    strategies: list[StrategyId | str | StrategyModel] | None = Field(
        default=None,
        title="Strategies",
        description="Strategies tagged on this trade, which allow traders to group individual transactions which are related to defined trading strategies for portfolio rollups.",
    )
    contact_info: ContactInfoModel | None = None
    short_code: str | None = None
    organization: OrganizationId | str | None = Field(
        default=None, title="Organization", description="The organization to which this party belongs. Comes from the entity."
    )

    semantic_type: Literal["PARTY"] = "PARTY"


class CounterpartyRelationshipModel(ResourceModel):
    __uri_path__ = "counterparties"
    __resource_id__ = CounterpartyRelationshipId

    party_1: EntityId | str | EntityModel | None = Field(
        default=None, title="Party 1", description="This is the entity within your organization which holds the relationship with the counterparty."
    )
    party_2: EntityId | str | EntityModel | None = Field(
        default=None, title="Party 2", description="This is the entity of the counterparty which holds the relationship with your entity."
    )
    organization: OrganizationId | str | None = Field(default=None, title="Organization", description="Organization which owns the counterparty relationship.")
    short_code: str | None = Field(default=None, title="Short Code", description="Short code assigned by your organization to the counterparty.")
    owner: PersonId | str | PersonModel | None = Field(default=None, title="Owner", description="Individual who owns the counterparty relationship.")
    authorized_signatory: PersonId | str | PersonModel | None = Field(
        default=None, title="Authorized Signatory", description="Default individual who is authorized to sign for this counterparty."
    )

    ## THIS NEEDS TO BE PARTY_2_OFFICE
    #
    party_1_office: str | None = Field(default=None, title="Party 2 Office", description="The office name for this counterparty relationship if required.")
    role: PartyRole | None = Field(
        default=None,
        title="Role",
        description="Role of this counterparty with respect to the organization or entity (e.g. Executing Broker, Prime Broker, etc).",
    )

    credentials: list[CredentialsId | str | CredentialsModel] | None = Field(
        default=None,
        title="Credentials",
        description="List of credentials",
    )

    semantic_type: Literal["COUNTERPARTY_RELATIONSHIP"] = "COUNTERPARTY_RELATIONSHIP"

    @property
    def resource_id(self) -> CounterpartyRelationshipId:
        return CounterpartyRelationshipId(
            id=self.id,
        )
