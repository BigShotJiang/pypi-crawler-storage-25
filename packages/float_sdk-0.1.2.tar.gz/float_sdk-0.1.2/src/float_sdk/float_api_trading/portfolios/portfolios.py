# pyright: basic
#!/usr/bin/env python

"""
Portfolio Models

"""

from enum import Enum
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel, ResourceIdentifierModel
from float_sdk.float_api.base.references import OrganizationId, PersonId, PortfolioId, TradingAccountId
from float_sdk.float_api.organizations.contact import EmailContactModel
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import PersonModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2024, Float Technologies Inc."
__email__ = "andy@float.tech"


class PortfolioIdentifierType(Enum):
    PORTFOLIO_ID = "PORTFOLIO_ID"


class PortfolioIdentifier(ResourceIdentifierModel):
    type: PortfolioIdentifierType = Field(default=PortfolioIdentifierType.PORTFOLIO_ID, title="Type", description="The type of identifier.")


class PortfolioStatus(Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class PortfolioModel(NamedResourceModel):
    __resource_id__ = PortfolioId

    # Identifiers
    #

    short_code: str | None = Field(default=None, title="Short Code", description="Short code for the portfolio which is unique to this organization.")
    identifiers: List[PortfolioIdentifier] | None = Field(default=None, title="Identifiers", description="Identifiers associated with the portfolio.")
    owner: PersonId | str | PersonModel | None = Field(default=None, title="Owner", description="The owner of this portfolio.")
    notifyees: List[EmailContactModel] | None = Field(default=None, title="Notifyees", description="The notifyees for this portfolio.")
    accounts: List[TradingAccountId | str] | None = Field(
        default=None, title="Trading Accounts", description="Trading accounts associated with this portfolio."
    )
    organization: OrganizationId | str | OrganizationModel | None = Field(
        default=None, title="Organization", description="The organization which this portfolio belongs."
    )
    status: PortfolioStatus | None = Field(default=None, title="Status", description="Current status of the portfolio.")

    semantic_type: Literal["PORTFOLIO"] = "PORTFOLIO"

    @property
    def resource_id(self) -> PortfolioId:
        return PortfolioId(id=self.id, version=self.version)
