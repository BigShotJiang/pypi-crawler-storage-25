from typing import Any

from float_sdk.client.auth import OAuth2ClientCredentials, base_url
from float_sdk.client.environment import Environment
from float_sdk.client.http import AsyncHttpClient, SyncHttpClient
from float_sdk.client.trading.client import AsyncTradingClient, TradingClient


class FloatClient:
    """Synchronous Float API client.

    Example:
        client = FloatClient()
        trade = client.trading.create(trade)
    """

    def __init__(
        self,
        environment: Environment = Environment.PROD,
        client_id: str | None = None,
        client_secret: str | None = None,
        access_token: str | None = None,
        organization_id: str | None = None,
        timeout: float = 60,
    ) -> None:
        auth = OAuth2ClientCredentials(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
            access_token=access_token,
            organization_id=organization_id,
        )
        self._http = SyncHttpClient(base_url=base_url(environment), auth=auth, timeout=timeout)
        self.trading = TradingClient(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "FloatClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


class FloatClientAsync:
    """Asynchronous Float API client.

    Example:
        async with FloatClientAsync() as client:
            trade = await client.trading.create(trade)
    """

    def __init__(
        self,
        environment: Environment = Environment.DEV,
        client_id: str | None = None,
        client_secret: str | None = None,
        access_token: str | None = None,
        organization_id: str | None = None,
        timeout: float = 30,
    ) -> None:
        auth = OAuth2ClientCredentials(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
            access_token=access_token,
            organization_id=organization_id,
        )
        self._http = AsyncHttpClient(base_url=base_url(environment), auth=auth, timeout=timeout)
        self.trading = AsyncTradingClient(self._http)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "FloatClientAsync":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()
