import json
from typing import Any
from urllib.parse import quote

import httpx
from loguru import logger
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential

from float_sdk._version import USER_AGENT
from float_sdk.client.auth import OAuth2ClientCredentials
from float_sdk.client.exceptions import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    make_status_error,
)
from float_sdk.float_api.api.requests import build_query_string

__all__ = ["SyncHttpClient", "AsyncHttpClient"]


def _retry_request(value: BaseException) -> bool:
    if isinstance(value, APIStatusError):
        if value.status_code in (502, 503):
            logger.warning(f"retrying after {value.status_code}")
            return True
        return False
    if isinstance(value, APITimeoutError):
        logger.warning("retrying after timeout")
        return True
    return False


def _encode_body(body: dict | str | bytes | None) -> bytes | None:
    if body is None:
        return None
    if isinstance(body, bytes):
        return body
    if isinstance(body, str):
        return body.encode("utf-8")
    return json.dumps(body).encode("utf-8")


def _parse_response(response: httpx.Response) -> Any:
    content_type = response.headers.get("Content-Type", "")
    if "application/json" in content_type:
        return json.loads(response.text)
    return response.content


def _raise_for_status(response: httpx.Response) -> None:
    if response.status_code // 100 == 2:
        return
    raise make_status_error(response)


class SyncHttpClient:
    def __init__(self, base_url: str, auth: OAuth2ClientCredentials, timeout: float = 30) -> None:
        self._base_url = base_url
        self._auth = auth
        self._client = httpx.Client(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    def close(self) -> None:
        self._client.close()

    def _url(self, path: str) -> str:
        return f"{self._base_url}{quote(path)}"

    def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        try:
            return self._client.request(method, url, **kwargs)
        except httpx.TimeoutException as exc:
            raise APITimeoutError(request=exc.request) from exc
        except httpx.RequestError as exc:
            raise APIConnectionError(request=exc.request) from exc

    def get(self, path: str, params: dict | None = None) -> Any:
        url = f"{self._url(path)}{build_query_string(params)}"
        response = self._request("GET", url, headers=self._auth.headers())
        _raise_for_status(response)
        return _parse_response(response)

    @retry(
        retry=retry_if_exception(_retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    def post(
        self,
        path: str,
        body: dict | str | None = None,
        files: dict | None = None,
        content_type: str | None = "application/json; charset=utf-8",
    ) -> Any:
        url = self._url(path)
        headers = self._auth.headers(content_type=content_type)
        if files:
            response = self._request("POST", url, headers=headers, files=files)
        else:
            response = self._request("POST", url, headers=headers, content=_encode_body(body))
        _raise_for_status(response)
        return _parse_response(response)

    @retry(
        retry=retry_if_exception(_retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    def put(self, path: str, body: dict | str, content_type: str | None = "application/json; charset=utf-8") -> Any:
        url = self._url(path)
        response = self._request(
            "PUT",
            url,
            headers=self._auth.headers(content_type=content_type),
            content=_encode_body(body),
        )
        _raise_for_status(response)
        return _parse_response(response)

    def delete(self, path: str) -> None:
        response = self._request("DELETE", self._url(path), headers=self._auth.headers())
        _raise_for_status(response)

    def __enter__(self) -> "SyncHttpClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


class AsyncHttpClient:
    def __init__(self, base_url: str, auth: OAuth2ClientCredentials, timeout: float = 30) -> None:
        self._base_url = base_url
        self._auth = auth
        self._client = httpx.AsyncClient(base_url=base_url, timeout=timeout, headers={"User-Agent": USER_AGENT})

    async def aclose(self) -> None:
        await self._client.aclose()

    def _url(self, path: str) -> str:
        return f"{self._base_url}{quote(path)}"

    async def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        try:
            return await self._client.request(method, url, **kwargs)
        except httpx.TimeoutException as exc:
            raise APITimeoutError(request=exc.request) from exc
        except httpx.RequestError as exc:
            raise APIConnectionError(request=exc.request) from exc

    @retry(
        retry=retry_if_exception(_retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    async def get(self, path: str, params: dict | None = None) -> Any:
        url = f"{self._url(path)}{build_query_string(params)}"
        response = await self._request("GET", url, headers=await self._auth_headers())
        _raise_for_status(response)
        return _parse_response(response)

    @retry(
        retry=retry_if_exception(_retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    async def post(
        self,
        path: str,
        body: dict | str | None = None,
        files: dict | None = None,
        content_type: str | None = "application/json; charset=utf-8",
    ) -> Any:
        url = self._url(path)
        headers = await self._auth_headers(content_type=content_type)
        if files:
            response = await self._request("POST", url, headers=headers, files=files)
        else:
            response = await self._request("POST", url, headers=headers, content=_encode_body(body))
        _raise_for_status(response)
        return _parse_response(response)

    @retry(
        retry=retry_if_exception(_retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    async def put(
        self, path: str, body: dict | str, content_type: str | None = "application/json; charset=utf-8"
    ) -> Any:
        url = self._url(path)
        response = await self._request(
            "PUT",
            url,
            headers=await self._auth_headers(content_type=content_type),
            content=_encode_body(body),
        )
        _raise_for_status(response)
        return _parse_response(response)

    async def delete(self, path: str) -> None:
        response = await self._request("DELETE", self._url(path), headers=await self._auth_headers())
        _raise_for_status(response)

    async def _auth_headers(self, content_type: str | None = "application/json; charset=utf-8") -> dict[str, str]:
        await self._auth.token_async()
        return self._auth.headers(content_type=content_type)

    async def __aenter__(self) -> "AsyncHttpClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()
