from float_sdk.client.http import AsyncHttpClient, SyncHttpClient
from float_sdk.client.trading.resources.deals import AsyncDealsResource, DealsResource
from float_sdk.client.trading.resources.trades import AsyncTradesResource, TradesResource


class TradingClient:
    """Synchronous namespace for trading resources.

    Exposes ``.trades`` and ``.deals`` sub-resources, each providing CRUD
    operations against the corresponding ``/v1/trading/*`` endpoints.
    """

    def __init__(self, http: SyncHttpClient) -> None:
        self.trades = TradesResource(http)
        self.deals = DealsResource(http)


class AsyncTradingClient:
    """Asynchronous namespace for trading resources. See :class:`TradingClient`."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self.trades = AsyncTradesResource(http)
        self.deals = AsyncDealsResource(http)
