from typing import Any

from float_sdk.client.http import AsyncHttpClient, SyncHttpClient
from float_sdk.float_api.data.query import DataQueryResultsModel
from float_sdk.float_api.serialization.types import Serializer
from float_sdk.float_api_trading.trading.parties import CounterpartyRole
from float_sdk.float_api_trading.trading.trades import TradeIdentifierType, TradeModel, TradeType

_PATH = "trading/trades"


def _ensure_trade(value: Any) -> TradeModel:
    result = Serializer.deserialize(value, TradeModel)
    if not isinstance(result, TradeModel):
        raise TypeError(f"Expected TradeModel, got {type(result).__name__}")
    return result


def _ensure_results(value: Any) -> DataQueryResultsModel:
    result = Serializer.deserialize(value, DataQueryResultsModel)
    if not isinstance(result, DataQueryResultsModel):
        raise TypeError(f"Expected DataQueryResultsModel, got {type(result).__name__}")
    return result


def _enum_values(values: list[Any] | None) -> list[str] | None:
    if not values:
        return None
    return [v.value if hasattr(v, "value") else str(v) for v in values]


def _build_list_params(
    ids: list[str] | None,
    limit: int,
    offset: int,
    expand: list[str] | None,
    type: list[TradeType] | None,
    deal: list[str] | None,
    view: str | None,
    side: list[CounterpartyRole] | None,
    identifier: list[str] | None,
    identifier_type: list[TradeIdentifierType] | None,
    organization: list[str] | None,
) -> dict[str, Any]:
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    if ids:
        params["ids"] = ids
    if expand:
        params["expand"] = expand
    if type:
        params["type"] = _enum_values(type)
    if deal:
        params["deal"] = deal
    if view:
        params["view"] = view
    if side:
        params["side"] = _enum_values(side)
    if identifier:
        params["identifier"] = identifier
    if identifier_type:
        params["identifierType"] = _enum_values(identifier_type)
    if organization:
        params["organization"] = organization
    return params


class TradesResource:
    """Synchronous CRUD operations for trades.

    Wraps the ``/v1/trading/trades`` endpoints. A trade is a record of a
    financial transaction executed to buy or sell an asset, encapsulating
    attributes like the asset/contractual product definition, quantity,
    trade price or notional, trade and settlement dates, counterparties,
    and execution details.
    """

    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def create(self, trade: TradeModel) -> TradeModel:
        """Create a new trade.

        Args:
            trade: The trade to create.

        Returns:
            The created trade as returned by the server (with assigned id and version).
        """
        response = self._http.post(_PATH, body=trade.to_json())
        return _ensure_trade(response)

    def get(self, trade_id: str) -> TradeModel:
        """Get a trade by unique identifier.

        Args:
            trade_id: The trade's unique identifier.

        Returns:
            The trade.

        Raises:
            NotFoundError: If no trade exists with that id.
            PermissionDeniedError: If the caller is not entitled to access the trade.
        """
        response = self._http.get(f"{_PATH}/{trade_id}")
        return _ensure_trade(response)

    def list(
        self,
        *,
        ids: list[str] | None = None,
        limit: int = 100,
        offset: int = 0,
        expand: list[str] | None = None,
        type: list[TradeType] | None = None,
        deal: list[str] | None = None,
        view: str | None = None,
        side: list[CounterpartyRole] | None = None,
        identifier: list[str] | None = None,
        identifier_type: list[TradeIdentifierType] | None = None,
        organization: list[str] | None = None,
    ) -> DataQueryResultsModel:
        """Enumerate trades with optional filtering, pagination, and expansion.

        Args:
            ids: List of trade ids by which to filter.
            limit: Maximum number of results to return per page.
            offset: Offset of the first page to return (indexed from 0).
            expand: Paths of attributes to expand. Nested attributes are
                delimited by dot, e.g. ``"attribute.sub_attribute"``.
            type: Trade types to query, e.g. ``EXECUTION``, ``PARTIAL_UNWIND``.
            deal: List of deal ids by which to filter.
            view: Return trades based on a specific view, which is a projection
                of trades meeting a given set of criteria. If a view id is
                provided it overrides any other query parameters.
            side: List of counterparty sides to filter by.
            identifier: List of trade identifiers by which to filter results.
            identifier_type: List of trade identifier types by which to match
                ``identifier`` values (sent as ``identifierType``).
            organization: List of organization ids by which to filter.

        Returns:
            A page of results plus pagination metadata.
        """
        params = _build_list_params(
            ids,
            limit,
            offset,
            expand,
            type,
            deal,
            view,
            side,
            identifier,
            identifier_type,
            organization,
        )
        response = self._http.get(_PATH, params=params)
        return _ensure_results(response)

    def update(self, trade: TradeModel) -> TradeModel:
        """Replace an existing trade.

        Performs a full update — any attributes not provided will be removed
        from the object.

        Args:
            trade: The trade to update. ``trade.id`` must be set.

        Returns:
            The updated trade.

        Raises:
            ValueError: If ``trade.id`` is missing.
            NotFoundError: If no trade exists with that id.
        """
        if not trade.id:
            raise ValueError("trade.id is required for update")
        response = self._http.put(f"{_PATH}/{trade.id}", body=trade.to_json())
        return _ensure_trade(response)

    def delete(self, trade_id: str) -> None:
        """Delete a trade by unique identifier.

        Removes the trade from the platform and modifies the transaction
        lifecycle accordingly.

        Args:
            trade_id: The trade's unique identifier.

        Raises:
            NotFoundError: If no trade exists with that id.
        """
        self._http.delete(f"{_PATH}/{trade_id}")

    def cancel(self, trade_id: str) -> None:
        """Cancel a trade asynchronously via the OMS.

        Args:
            trade_id: The trade's unique identifier.
        """
        raise NotImplementedError("cancel is not implemented")


class AsyncTradesResource:
    """Asynchronous CRUD operations for trades. See :class:`TradesResource`."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, trade: TradeModel) -> TradeModel:
        """Create a new trade. See :meth:`TradesResource.create`."""
        response = await self._http.post(_PATH, body=trade.to_json())
        return _ensure_trade(response)

    async def get(self, trade_id: str) -> TradeModel:
        """Get a trade by unique identifier. See :meth:`TradesResource.get`."""
        response = await self._http.get(f"{_PATH}/{trade_id}")
        return _ensure_trade(response)

    async def list(
        self,
        *,
        ids: list[str] | None = None,
        limit: int = 100,
        offset: int = 0,
        expand: list[str] | None = None,
        type: list[TradeType] | None = None,
        deal: list[str] | None = None,
        view: str | None = None,
        side: list[CounterpartyRole] | None = None,
        identifier: list[str] | None = None,
        identifier_type: list[TradeIdentifierType] | None = None,
        organization: list[str] | None = None,
    ) -> DataQueryResultsModel:
        """Enumerate trades. See :meth:`TradesResource.list`."""
        params = _build_list_params(
            ids,
            limit,
            offset,
            expand,
            type,
            deal,
            view,
            side,
            identifier,
            identifier_type,
            organization,
        )
        response = await self._http.get(_PATH, params=params)
        return _ensure_results(response)

    async def update(self, trade: TradeModel) -> TradeModel:
        """Replace an existing trade. See :meth:`TradesResource.update`."""
        if not trade.id:
            raise ValueError("trade.id is required for update")
        response = await self._http.put(f"{_PATH}/{trade.id}", body=trade.to_json())
        return _ensure_trade(response)

    async def delete(self, trade_id: str) -> None:
        """Delete a trade. See :meth:`TradesResource.delete`."""
        await self._http.delete(f"{_PATH}/{trade_id}")

    async def cancel(self, trade_id: str) -> None:
        """Cancel a trade. See :meth:`TradesResource.cancel`."""
        raise NotImplementedError("cancel is not implemented")
