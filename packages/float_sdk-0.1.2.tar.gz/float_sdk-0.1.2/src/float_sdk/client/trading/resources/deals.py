from typing import Any

from float_sdk.client.http import AsyncHttpClient, SyncHttpClient
from float_sdk.float_api.data.query import DataQueryResultsModel
from float_sdk.float_api.serialization.types import Serializer
from float_sdk.float_api_trading.trading.trades import DealModel

_PATH = "trading/deals"


def _ensure_deal(value: Any) -> DealModel:
    result = Serializer.deserialize(value, DealModel)
    if not isinstance(result, DealModel):
        raise TypeError(f"Expected DealModel, got {type(result).__name__}")
    return result


def _ensure_results(value: Any) -> DataQueryResultsModel:
    result = Serializer.deserialize(value, DataQueryResultsModel)
    if not isinstance(result, DataQueryResultsModel):
        raise TypeError(f"Expected DataQueryResultsModel, got {type(result).__name__}")
    return result


def _build_list_params(
    ids: list[str] | None,
    limit: int,
    offset: int,
    expand: list[str] | None,
    organization: list[str] | None,
) -> dict[str, Any]:
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    if ids:
        params["ids"] = ids
    if expand:
        params["expand"] = expand
    if organization:
        params["organization"] = organization
    return params


class DealsResource:
    """Synchronous CRUD operations for deals.

    Wraps the ``/v1/trading/deals`` endpoints. A deal groups together related
    trades that represent the lifecycle of a single transaction (e.g. an
    initial execution and any subsequent unwinds, novations, or amendments).
    """

    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def create(self, deal: DealModel) -> DealModel:
        """Create a new deal.

        Args:
            deal: The deal to create.

        Returns:
            The created deal as returned by the server.
        """
        response = self._http.post(_PATH, body=deal.to_json())
        return _ensure_deal(response)

    def get(self, deal_id: str) -> DealModel:
        """Get a deal by unique identifier.

        Args:
            deal_id: The deal's unique identifier.

        Returns:
            The deal.

        Raises:
            NotFoundError: If no deal exists with that id.
            PermissionDeniedError: If the caller is not entitled to access the deal.
        """
        response = self._http.get(f"{_PATH}/{deal_id}")
        return _ensure_deal(response)

    def list(
        self,
        *,
        ids: list[str] | None = None,
        limit: int = 100,
        offset: int = 0,
        expand: list[str] | None = None,
        organization: list[str] | None = None,
    ) -> DataQueryResultsModel:
        """Enumerate deals with optional filtering, pagination, and expansion.

        Args:
            ids: List of deal ids by which to filter.
            limit: Maximum number of results to return per page.
            offset: Offset of the first page to return (indexed from 0).
            expand: Paths of attributes to expand. Nested attributes are
                delimited by dot, e.g. ``"attribute.sub_attribute"``.
            organization: List of organization ids by which to filter.

        Returns:
            A page of results plus pagination metadata.
        """
        params = _build_list_params(ids, limit, offset, expand, organization)
        response = self._http.get(_PATH, params=params)
        return _ensure_results(response)

    def update(self, deal: DealModel) -> DealModel:
        """Replace an existing deal.

        Performs a full update — any attributes not provided will be removed
        from the object.

        Args:
            deal: The deal to update. ``deal.id`` must be set.

        Returns:
            The updated deal.

        Raises:
            ValueError: If ``deal.id`` is missing.
            NotFoundError: If no deal exists with that id.
        """
        if not deal.id:
            raise ValueError("deal.id is required for update")
        response = self._http.put(f"{_PATH}/{deal.id}", body=deal.to_json())
        return _ensure_deal(response)

    def delete(self, deal_id: str) -> None:
        """Delete a deal by unique identifier.

        Args:
            deal_id: The deal's unique identifier.

        Raises:
            NotFoundError: If no deal exists with that id.
        """
        self._http.delete(f"{_PATH}/{deal_id}")


class AsyncDealsResource:
    """Asynchronous CRUD operations for deals. See :class:`DealsResource`."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, deal: DealModel) -> DealModel:
        """Create a new deal. See :meth:`DealsResource.create`."""
        response = await self._http.post(_PATH, body=deal.to_json())
        return _ensure_deal(response)

    async def get(self, deal_id: str) -> DealModel:
        """Get a deal by unique identifier. See :meth:`DealsResource.get`."""
        response = await self._http.get(f"{_PATH}/{deal_id}")
        return _ensure_deal(response)

    async def list(
        self,
        *,
        ids: list[str] | None = None,
        limit: int = 100,
        offset: int = 0,
        expand: list[str] | None = None,
        organization: list[str] | None = None,
    ) -> DataQueryResultsModel:
        """Enumerate deals. See :meth:`DealsResource.list`."""
        params = _build_list_params(ids, limit, offset, expand, organization)
        response = await self._http.get(_PATH, params=params)
        return _ensure_results(response)

    async def update(self, deal: DealModel) -> DealModel:
        """Replace an existing deal. See :meth:`DealsResource.update`."""
        if not deal.id:
            raise ValueError("deal.id is required for update")
        response = await self._http.put(f"{_PATH}/{deal.id}", body=deal.to_json())
        return _ensure_deal(response)

    async def delete(self, deal_id: str) -> None:
        """Delete a deal. See :meth:`DealsResource.delete`."""
        await self._http.delete(f"{_PATH}/{deal_id}")
