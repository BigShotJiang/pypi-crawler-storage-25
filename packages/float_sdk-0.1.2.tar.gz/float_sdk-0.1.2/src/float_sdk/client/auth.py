import datetime as dt
import json
import logging
import os

import httpx
from loguru import logger
from tenacity import after_log, retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from float_sdk.client.environment import Environment
from float_sdk.client.exceptions import AuthenticationError, FloatError, make_status_error

_tenacity_logger = logging.getLogger(__name__)


def _auth_url(environment: Environment) -> str:
    if environment in (Environment.LOCAL, Environment.TEST, Environment.DEV):
        return "https://login-dev.float.tech"
    if environment in (Environment.PROD, Environment.UAT):
        return "https://login.float.tech"
    raise ValueError(f"Invalid environment for auth: {environment}")


def base_url(environment: Environment) -> str:
    if environment == Environment.LOCAL:
        base = "http://localhost:80"
    elif environment == Environment.DEV:
        base = "https://api-dev.float.tech"
    elif environment in (Environment.PROD, Environment.UAT):
        base = "https://api.float.tech"
    else:
        raise ValueError(f"Invalid environment: {environment}")
    return f"{base}/v1/"


class OAuth2ClientCredentials:
    def __init__(
        self,
        environment: Environment,
        client_id: str | None = None,
        client_secret: str | None = None,
        access_token: str | None = None,
        organization_id: str | None = None,
    ) -> None:
        self.environment = environment
        self.client_id = client_id or os.getenv("client_id")
        self.client_secret = client_secret or os.getenv("client_secret")
        self.organization_id = organization_id

        self._access_token: str | None = access_token
        self._expires_at: dt.datetime | None = (
            dt.datetime.now(dt.UTC) + dt.timedelta(hours=1) if access_token else None
        )

    def _is_token_valid(self) -> bool:
        return bool(self._access_token and self._expires_at and dt.datetime.now(dt.UTC) < self._expires_at)

    @retry(
        retry=retry_if_exception_type(httpx.TransportError),
        wait=wait_exponential(multiplier=2, min=4, max=60),
        after=after_log(_tenacity_logger, logging.INFO),
        stop=stop_after_attempt(3),
    )
    def _fetch_token(self) -> dict:
        if not self.client_id or not self.client_secret:
            raise FloatError("Credentials not provided, missing client_id or secret")

        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "audience": os.getenv("auth0_api_audience"),
            "grant_type": "client_credentials",
        }

        url = f"{_auth_url(self.environment)}/oauth/token"
        response = httpx.post(url, json=payload, headers={"content-type": "application/json"})
        if response.status_code != 200:
            if response.status_code == 401:
                raise AuthenticationError(f"Auth failed: {response.text}", response=response)
            raise make_status_error(response)
        return json.loads(response.text)

    def token(self) -> str:
        if not self._is_token_valid():
            data = self._fetch_token()
            self._access_token = data["access_token"]
            self._expires_at = dt.datetime.now(dt.UTC) + dt.timedelta(seconds=data["expires_in"])
            logger.debug("Refreshed Float access token")
        assert self._access_token is not None
        return self._access_token

    async def token_async(self) -> str:
        return self.token()

    def headers(self, content_type: str | None = "application/json; charset=utf-8") -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.token()}", "X-Application": "float-sdk"}
        if content_type:
            headers["Content-Type"] = content_type
        if self.organization_id:
            headers["X-Float-Organization"] = self.organization_id
        return headers
