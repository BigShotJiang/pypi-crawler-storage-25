from typing import Any

import httpx


class FloatError(Exception):
    pass


class APIError(FloatError):
    detail: str
    request: httpx.Request | None

    def __init__(self, detail: str, request: httpx.Request | None = None) -> None:
        super().__init__(detail)
        self.detail = detail
        self.request = request


class APIConnectionError(APIError):
    def __init__(self, detail: str = "Connection error.", request: httpx.Request | None = None) -> None:
        super().__init__(detail, request)


class APITimeoutError(APIConnectionError):
    def __init__(self, request: httpx.Request | None = None) -> None:
        super().__init__("Request timed out.", request)


class APIStatusError(APIError):
    response: httpx.Response
    status_code: int

    def __init__(self, detail: str, *, response: httpx.Response) -> None:
        super().__init__(detail, response.request)
        self.response = response
        self.status_code = response.status_code


class BadRequestError(APIStatusError):
    status_code: int = 400


class AuthenticationError(APIStatusError):
    status_code: int = 401


class PermissionDeniedError(APIStatusError):
    status_code: int = 403


class NotFoundError(APIStatusError):
    status_code: int = 404


class ConflictError(APIStatusError):
    status_code: int = 409


class UnprocessableEntityError(APIStatusError):
    status_code: int = 422


class RateLimitError(APIStatusError):
    status_code: int = 429


class InternalServerError(APIStatusError):
    pass


_STATUS_TO_EXC: dict[int, type[APIStatusError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: UnprocessableEntityError,
    429: RateLimitError,
}


def make_status_error(response: httpx.Response) -> APIStatusError:
    code = response.status_code
    cls = _STATUS_TO_EXC.get(code)
    if cls is None:
        cls = InternalServerError if code >= 500 else APIStatusError
    detail = _format_detail(response) or response.text or f"HTTP {code}"
    return cls(detail, response=response)


def _format_detail(response: httpx.Response) -> str | None:
    try:
        body = response.json()
    except ValueError:
        return None
    if not isinstance(body, dict):
        return None
    raw = body.get("detail")
    if isinstance(raw, str):
        return raw
    if isinstance(raw, list):
        return "; ".join(_format_validation_error(item) for item in raw)
    return None


def _format_validation_error(item: Any) -> str:
    if not isinstance(item, dict):
        return str(item)
    msg = item.get("msg", "validation error")
    loc = item.get("loc")
    if isinstance(loc, list) and loc:
        return f"{'.'.join(str(p) for p in loc)}: {msg}"
    return str(msg)
