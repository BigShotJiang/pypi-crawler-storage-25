from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("float-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

USER_AGENT = f"float-sdk-python/{__version__}"
