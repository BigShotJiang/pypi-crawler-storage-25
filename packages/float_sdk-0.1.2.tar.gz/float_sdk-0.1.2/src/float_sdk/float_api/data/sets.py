#!/usr/bin/env python
# pyright: basic

"""
Datsets


A dataset is a structured collection of data points or observations typically organized in a tabular format,
where each row represents an individual obseration, and each column corresponds to a specific attribute.


"""

from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import DataConnectionId, DatasetId, GroupId, OrganizationId, PersonId
from float_sdk.float_api.data.connections import DataConnectionModel
from float_sdk.float_api.data.fields import DataFieldModel
from float_sdk.float_api.data.query import DataQueryOperatorModel, DataQuerySearchModel
from float_sdk.float_api.data.schema import DataSchemaModel
from float_sdk.float_api.datetime.schedule import ScheduleModel
from float_sdk.float_api.organizations.contact import EmailContactModel
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import GroupModel, PersonModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DataFrequency(Enum):
    INTRADAY = "INTRADAY"
    DAILY = "DAILY"
    PERIODIC = "PERIODIC"
    PERPETUAL = "PERPETUAL"
    AD_HOC = "AD_HOC"


class DatasetType(Enum):
    RELATIONAL = "RELATIONAL"
    TIMESERIES = "TIMESERIES"
    DOCUMENT = "DOCUMENT"


class DatasetModel(NamedResourceModel):
    """
    A Dataset defines access to a data resource, describing the metadata,
    schema, data connection, frequency of updates, etc.
    """

    __uri_path__ = "data/datasets"
    __resource_id__ = DatasetId

    # policy: Optional[EntitlementPolicyModel] = Field(default=None, description="Entitlement policy to define incremental users or groups with access to the resource.")

    type: DatasetType = Field(..., description="The type of data, e.g. document, relational, timeseries.")
    product: str | None = Field(default=None, description="Identifier of the data product to which this dataset belongs.")
    frequency: DataFrequency | None = Field(default=None, description="Frequency of updates to this dataset.")
    schedule: ScheduleModel | None = Field(default=None, description="Schedule object which defines the timing of delivery if the frequency is recurring.")
    # driver: Optional[DataDriverClass] = None
    connection: DataConnectionId | str | DataConnectionModel | None = Field(default=None, description="Identifier of data connection where data is stored.")
    data_schema: DataSchemaModel | None = Field(
        default=None, description="Schema for the dataset which defines the structure, including available fields and format."
    )
    data_filter: DataQueryOperatorModel | None = Field(default=None, description="Base filter to apply to the dataset prior to a user query.")
    search_config: DataQuerySearchModel | None = Field(
        default=None, description="Default search configuration for fuzzy/autocomplete search. The query field is overridden at search time."
    )
    owner: PersonId | str | PersonModel | None = Field(default=None, description="Identifier of the person who owns this dataset.")
    group: GroupId | str | GroupModel | None = Field(default=None, description="Identifier of the group which can access this dataset.")
    organization: OrganizationId | str | OrganizationModel | None = Field(default=None, description="Identifier of the organization which owns this dataset.")
    notifyees: list[EmailContactModel] | None = Field(default=None, title="To", description="Recipients of the notification.")

    semantic_type: Literal["DATASET"] = Field("DATASET", exclude=True)

    @property
    def resource_id(self) -> DatasetId:
        return DatasetId(id=self.id, name=self.name, version=self.version)


class DatasetFieldModel(DataFieldModel):
    """
    Dataset Field Model

    Represents a field which contains an embedded dataset with
    its own sub-schema. This can be thought of as a join with
    another dataset where the results can be returned inline,
    embedded within the parent results using a sub-schema.

    """

    data_type: DatasetModel
    semantic_type: Literal["DATASET_FIELD"] = Field(default="DATASET_FIELD", exclude=True)


class PlatformDatasets(Enum):
    ## Reference Data
    #
    FLOAT_ASSET_DATA = "FLOAT_ASSET_DATA"
    FLOAT_EXCHANGE_DATA = "FLOAT_EXCHANGE_DATA"

    ## Data & Analytics
    #
    FLOAT_CONFIRM_DOCUMENT_DATA = "FLOAT_CONFIRM_DOCUMENT_DATA"
    FLOAT_CONFIRM_TEMPLATE_DOCUMENT_DATA = "FLOAT_CONFIRM_TEMPLATE_DOCUMENT_DATA"
    FLOAT_MCA_DOCUMENT_DATA = "FLOAT_MCA_DOCUMENT_DATA"
    FLOAT_ISDA_DEFINITIONS_DOCUMENT_DATA = "FLOAT_ISDA_DEFINITIONS_DOCUMENT_DATA"
    FLOAT_NDA_DOCUMENT_DATA = "FLOAT_NDA_DOCUMENT_DATA"
    FLOAT_MASTER_AGREEMENT_DOCUMENT_DATA = "FLOAT_MASTER_AGREEMENT_DOCUMENT_DATA"
    FLOAT_CONFIRMS_INBOX = "FLOAT_CONFIRMS_INBOX"
    FLOAT_RECAPS_INBOX = "FLOAT_RECAPS_INBOX"
    FLOAT_DOCUMENT_DATA = "FLOAT_DOCUMENT_DATA"
    FLOAT_DOCUMENT_BACKFILLED_DATA = "FLOAT_DOCUMENT_BACKFILLED_DATA"

    ## Portfolio & Account Data
    #
    FLOAT_PORTFOLIO_REFERENCE_DATA = "FLOAT_PORTFOLIO_REFERENCE_DATA"
    FLOAT_ACCOUNT_DATA = "FLOAT_ACCOUNT_DATA"

    ## Valuations Data
    #
    FLOAT_VALUATIONS_DATA = "FLOAT_VALUATIONS_DATA"
    FLOAT_DEAL_VALUATIONS_DATA = "FLOAT_DEAL_VALUATIONS_DATA"

    ## Trade Data
    #
    FLOAT_TRADE_DATA = "FLOAT_TRADE_DATA"
    FLOAT_DEALER_TRADE_DATA = "FLOAT_DEALER_TRADE_DATA"
    FLOAT_TRADE_ALLEGED_DATA = "FLOAT_TRADE_ALLEGED_DATA"
    FLOAT_VALUATION_TRADE_DATA = "FLOAT_VALUATION_TRADE_DATA"
    FLOAT_TRADE_BACKFILL_DATA = "FLOAT_TRADE_BACKFILL_DATA"
    FLOAT_TRADE_CANCELLED_DATA = "FLOAT_TRADE_CANCELLED_DATA"
    FLOAT_TRADE_METRICS_DATA = "FLOAT_TRADE_METRICS_DATA"
    FLOAT_TRADE_MATCH_DATA = "FLOAT_TRADE_MATCH_DATA"
    FLOAT_TRADE_ODMV_DATA = "FLOAT_TRADE_ODMV_DATA"
    FLOAT_TRADE_FEED_DATA = "FLOAT_TRADE_FEED_DATA"

    ## Workflows & Automation
    #
    FLOAT_AUTOMATION_DATA = "FLOAT_AUTOMATION_DATA"
    FLOAT_CONFIRM_WORKFLOW_DATA = "FLOAT_CONFIRM_WORKFLOW_DATA"
    FLOAT_WORKFLOW_TASK_DATA = "FLOAT_WORKFLOW_TASK_DATA"

    ## Collaboration
    #
    FLOAT_COMMENTS_DATASET = "FLOAT_COMMENTS_DATASET"
    FLOAT_INITIATIVE_DATA = "FLOAT_INITIATIVE_DATA"
    FLOAT_PROJECT_DATA = "FLOAT_PROJECT_DATA"
    FLOAT_ISSUE_DATA = "FLOAT_ISSUE_DATA"
    FLOAT_ISSUES_LIST_DATA = "FLOAT_ISSUES_LIST_DATA"
    FLOAT_OPPORTUNITY_DATA = "FLOAT_OPPORTUNITY_DATA"

    ## FIX Service
    #
    FLOAT_FIX_LOG_DATA = "FLOAT_FIX_LOG_DATA"
    FLOAT_FIX_LOG_DATA_UAT = "FLOAT_FIX_LOG_DATA_UAT"

    ## API Logs
    #
    FLOAT_API_LOGS_DATA = "FLOAT_API_LOGS_DATA"

    ## Market Data
    #
    FLOAT_EXCHANGE_RATE_DATA = "FLOAT_EXCHANGE_RATE_DATA"
