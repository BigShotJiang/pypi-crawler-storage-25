# pyright: strict

from typing import Any

from float_sdk.float_api.data.query import (
    DataQueryOperatorModel,
    DataQueryOperatorType,
    DataQuerySelectorModel,
    DataQuerySelectorType,
    DataQuerySortDirection,
    DataQuerySortModel,
)


def elem_match(array_field: str, match_fields: dict[str, Any]) -> DataQuerySelectorModel:
    elem_match_components: list[DataQuerySelectorModel | DataQueryOperatorModel] = []
    for key, value in match_fields.items():
        elem_match_components.append(eq(key, value))
    return DataQuerySelectorModel(field=array_field, type=DataQuerySelectorType.MATCH_ELEMENT, value=and_op(*elem_match_components))


def eq(key: str, value: Any, tolerance: int | float | None = None) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.EQUAL, field=key, value=value, tolerance=tolerance)


def in_op(key: str, values: list[Any]) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.IN, field=key, value=values)


def or_op(*args: DataQuerySelectorModel | DataQueryOperatorModel) -> DataQueryOperatorModel:
    return DataQueryOperatorModel(type=DataQueryOperatorType.OR, query=list(args))


def and_op(*args: DataQuerySelectorModel | DataQueryOperatorModel) -> DataQueryOperatorModel:
    return DataQueryOperatorModel(type=DataQueryOperatorType.AND, query=list(args))


def ne(key: str, value: Any) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.NOT_EQUAL, field=key, value=value)


def gt(key: str, value: Any, tolerance: int | float | None = None) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.GREATER_THAN, field=key, value=value, tolerance=tolerance)


def gte(key: str, value: Any, tolerance: int | float | None = None) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.GREATER_THAN_OR_EQUAL, field=key, value=value, tolerance=tolerance)


def lt(key: str, value: Any, tolerance: int | float | None = None) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.LESS_THAN, field=key, value=value, tolerance=tolerance)


def lte(key: str, value: Any, tolerance: int | float | None = None) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.LESS_THAN_OR_EQUAL, field=key, value=value, tolerance=tolerance)


def not_in_op(key: str, values: list[Any]) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.NOT_IN, field=key, value=values)


def regex(key: str, pattern: str) -> DataQuerySelectorModel:
    return DataQuerySelectorModel(type=DataQuerySelectorType.REGEX, field=key, value=pattern)


def sort(key: str, direction: DataQuerySortDirection = DataQuerySortDirection.ASCENDING) -> DataQuerySortModel:
    return DataQuerySortModel(field=key, direction=direction)
