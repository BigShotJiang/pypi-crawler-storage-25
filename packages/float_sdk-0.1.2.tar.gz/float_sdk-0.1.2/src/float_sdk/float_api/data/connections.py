# pyright: basic
#!/usr/bin/env python

"""
Data Connections

Data connections provide connectivity to cloud data and document stores,
which can be used for integration of data feeds, automation, amd analytics.

"""

import datetime as dt
from abc import ABC
from enum import Enum
from typing import Annotated, List, Literal, Optional, Union

from pydantic import Field, computed_field, field_validator

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import CredentialsId, DataConnectionId, OrganizationId, PersonId
from float_sdk.float_api.iam.identity import CredentialsModel, UserCredentialsModel
from float_sdk.float_api.organizations.contact import EmailContactModel
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import PersonModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class AWSRegion(Enum):
    US_EAST_1 = "us-east-1"
    US_EAST_2 = "us-east-2"
    US_WEST_1 = "us-west-1"
    US_WEST_2 = "us-west-2"
    CA_CENTRAL_1 = "ca-central-1"
    EU_WEST_1 = "eu-west-1"
    EU_WEST_2 = "eu-west-2"
    EU_WEST_3 = "eu-west-3"
    EU_CENTRAL_1 = "eu-central-1"
    AP_SOUTH_1 = "ap-south-1"
    AP_SOUTHEAST_1 = "ap-southeast-1"
    AP_SOUTHEAST_2 = "ap-southeast-2"
    AP_NORTHEAST_1 = "ap-northeast-1"
    AP_NORTHEAST_2 = "ap-northeast-2"
    AP_EAST_1 = "ap-east-1"
    SA_EAST_1 = "sa-east-1"
    ME_SOUTH_1 = "me-south-1"
    AF_SOUTH_1 = "af-south-1"


class MailboxPurpose(Enum):
    CONFIRM = "CONFIRM"
    GENERAL = "GENERAL"
    RECAP = "RECAP"


class SocketAddressModel(DataModel):
    host: str = Field(..., title="Host", description="The host name or IP address of the FIX server.")
    port: int = Field(..., title="Port", description="The port number of the FIX server.")

    semantic_type: Literal["SOCKET_ADDRESS"] = "SOCKET_ADDRESS"


class IntegrationConnectionModel(DataModel, ABC):
    credentials: CredentialsId | CredentialsModel | UserCredentialsModel | str | None = Field(
        default=None, title="Credentials", description="The credentials required for the connection."
    )


class DatabaseConnectionModel(IntegrationConnectionModel, ABC):
    pass


class DriveConnectionModel(IntegrationConnectionModel):
    path: str
    semantic_type: Literal["DRIVE_CONNECTION"] = "DRIVE_CONNECTION"


class MongoDbConnectionModel(DatabaseConnectionModel):
    deployment: str = Field(..., title="Deployment", description="The MongoDb deployment id.")

    semantic_type: Literal["MONGO_CONNECTION"] = "MONGO_CONNECTION"


class SnowflakeConnectionModel(DatabaseConnectionModel):
    account_name: str = Field(..., title="Account Name", description="The Snowflake account name.")
    warehouse: str = Field(..., title="Warehouse Name", description="The Snowflake data warehouse name.")

    semantic_type: Literal["SNOWFLAKE_CONNECTION"] = "SNOWFLAKE_CONNECTION"


class AmazonS3ConnectionModel(IntegrationConnectionModel):
    bucket_name: str = Field(..., title="Bucket Name", description="The name of the S3 bucket to which to connect.")
    aws_region: AWSRegion = Field(..., title="AWS Region", description="The AWS Region on which the queue is hosted.")
    base_path: str | None = Field(default=None, title="Base Path", description="Base path prefix within the bucket (e.g., tenant folder).")

    semantic_type: Literal["S3_CONNECTION"] = "S3_CONNECTION"


class AmazonSQSConnectionModel(IntegrationConnectionModel):
    queue_url: str = Field(..., title="SQS Queue URL", description="The URL for the AWS Simple Queue Service.")
    aws_region: AWSRegion = Field(..., title="AWS Region", description="The AWS Region on which the queue is hosted.")

    semantic_type: Literal["SQS_CONNECTION"] = "SQS_CONNECTION"


class SFTPConnectionModel(IntegrationConnectionModel):
    host: str = Field(..., title="Host", description="SFTP server hostname.")
    port: int = Field(default=22, title="Port", description="SFTP server port.")
    base_path: str | None = Field(default=None, title="Base Path", description="Base directory on the remote server.")

    semantic_type: Literal["SFTP_CONNECTION"] = "SFTP_CONNECTION"


class SlackTextObjectModel(DataModel):
    type: Literal["plain_text", "mrkdwn"] = Field(..., description="The type of text object.")
    text: str = Field(..., description="The text content.")

    semantic_type: Literal["SLACK_TEXT_OBJECT"] = "SLACK_TEXT_OBJECT"


class SlackBlockModel(DataModel):
    type: Literal["header", "section", "divider", "context", "actions", "image"] = Field(..., description="The type of Slack block.")
    text: SlackTextObjectModel | None = Field(default=None, description="Text content for header/section blocks.")
    block_id: str | None = Field(default=None, description="Optional unique identifier for the block.")

    semantic_type: Literal["SLACK_BLOCK"] = "SLACK_BLOCK"


class SlackMessageModel(DataModel):
    text: str = Field(..., description="Fallback text shown in notifications and non-block-supporting clients.")
    blocks: List[SlackBlockModel] | None = Field(default=None, description="Slack Block Kit blocks for rich formatting.")
    channel: str | None = Field(default=None, description="Target channel name or ID (used with SDK mode).")

    semantic_type: Literal["SLACK_MESSAGE"] = "SLACK_MESSAGE"


class SlackConnectionModel(IntegrationConnectionModel):
    webhook_url: str | None = Field(default=None, title="Webhook URL", description="Slack incoming webhook URL.")

    semantic_type: Literal["SLACK_CONNECTION"] = "SLACK_CONNECTION"


class AWSKMSConnectionModel(IntegrationConnectionModel):
    aws_region: AWSRegion = Field(..., title="AWS Region", description="The AWS Region for the KMS service.")
    tenant_id: str = Field(..., title="Tenant ID", description="The tenant identifier for multi-tenant KMS operations.")

    semantic_type: Literal["KMS_CONNECTION"] = "KMS_CONNECTION"


class MailboxModel(str):
    ...
    semantic_type: Literal["Mailbox"] = "Mailbox"


class MicrosoftExchangeConnectionModel(DatabaseConnectionModel):
    tenant_id: str = Field(..., title="Tenant Id", description="The Microsoft Exchange server tenant id.")
    mailboxes: Optional[List[str]] = Field(default=None, title="Mailboxes", description="List of Exchange mailbox names to monitor.")
    mailbox_purpose: Optional[MailboxPurpose] = Field(
        default=None, title="Mailbox Purpose", description="The purpose of the monitored mailboxes, which can be used to apply different processing rules."
    )
    ignore_senders: Optional[List[EmailContactModel]] = Field(default=None, title="Ignore Senders", description="List of sender email addresses to ignore.")

    semantic_type: Literal["EXCHANGE_CONNECTION"] = "EXCHANGE_CONNECTION"


class FIXConnectionMetricsModel(DataModel):
    last_heartbeat_time: dt.datetime | None = Field(default=None, title="Last Seen", description="The last time the FIX connection was seen.")
    last_message_time: dt.datetime | None = Field(default=None, title="Last Message", description="The last time a message was received on the FIX connection.")
    last_login_time: dt.datetime | None = Field(default=None, title="Last Login", description="The last time the FIX connection was logged in.")
    number_of_issues: int | None = Field(default=None, title="Number of Issues", description="The number of issues with the FIX connection.")
    is_active: bool = Field(default=True, title="Is Active", description="Whether the FIX connection is currently active.")

    semantic_type: Literal["FIX_CONNECTION_METRICS"] = "FIX_CONNECTION_METRICS"


class MessageGeneratorSettingsModel(DataModel):
    enabled: bool = Field(default=False, title="Enabled", description="Whether the message generator is enabled.")
    time_interval_ms: int | None = Field(default=None, title="Time Interval (ms)", description="The time interval in milliseconds between generated messages.")

    semantic_type: Literal["MESSAGE_GENERATOR_SETTINGS"] = "MESSAGE_GENERATOR_SETTINGS"


class FIXConnectionModel(DatabaseConnectionModel):
    begin_string: str
    socket_connect_addresses: List[SocketAddressModel] | None = Field(
        default=None, title="Socket Connect Addresses", description="List of addresses to connect to for the FIX connection."
    )

    sender_comp_id: str = Field(..., title="Sender Comp ID", description="The sender component ID for the FIX connection.")
    target_comp_id: str = Field(..., title="Target Comp ID", description="The target component ID for the FIX connection.")
    start_time: dt.time | None = Field(default=None, title="Start Time", description="The start time for the FIX connection.")
    end_time: dt.time | None = Field(default=None, title="End Time", description="The end time for the FIX connection.")
    heartbeat_interval: int | None = Field(default=None, title="Heartbeat Interval", description="The heartbeat interval in seconds.")
    reconnect_interval: int | None = Field(default=None, title="Reconnect Interval", description="The reconnect interval in seconds.")

    ## Runtime metrics
    #
    metrics: FIXConnectionMetricsModel | None = Field(default=None, title="Metrics", description="The metrics for the FIX connection.")
    message_generator_settings: MessageGeneratorSettingsModel | None = Field(
        default=None, title="Message Generator Settings", description="Settings for the FIX message generator."
    )

    ack_enabled: bool | None = Field(default=None, title="ACK Enabled", description="Whether ACK messages are enabled for the FIX connection.")
    ack_timeout_seconds: int | None = Field(
        default=None, title="ACK Timeout", description="The timeout in seconds to wait, before message that is unacknowledged will be resent."
    )
    include_in_activity: bool | None = Field(
        default=None, title="Include in Activity", description="Whether to include actions happening in this activity in activity timelines"
    )

    semantic_type: Literal["FIX_CONNECTION"] = "FIX_CONNECTION"

    @computed_field
    @property
    def session_id(self) -> str:
        """
        Returns a unique session ID for the FIX connection based on the sender and target component IDs.
        """
        return f"{self.begin_string}:{self.sender_comp_id}->{self.target_comp_id}"

    @field_validator("start_time", "end_time", mode="before")
    def datetime_to_time(cls, v):
        if isinstance(v, dt.datetime):
            return v.time()
        return v


ValidDataConnections = Annotated[
    Union[
        DriveConnectionModel,
        SnowflakeConnectionModel,
        AmazonS3ConnectionModel,
        AmazonSQSConnectionModel,
        AWSKMSConnectionModel,
        MicrosoftExchangeConnectionModel,
        FIXConnectionModel,
        SFTPConnectionModel,
        SlackConnectionModel,
    ],
    Field(discriminator="semantic_type"),
]


class IntegrationProviderModel(NamedResourceModel, ABC):
    pass


class DataConnectionModel(IntegrationProviderModel):
    """
    Data connections provide the details required to connect to a remote
    data source, for example a cloud database, object storage or data
    warehouse. Data connections allow an organization to read and write
    data from shared or proprietary data sources.

    Data connections contain metadata, credentials (which are stored
    securely in a cloud credential manager), and the parameters to
    connect to the data source. Parameters vary based on the type of the
    data source (e.g. S3, Snowflake, etc.)
    """

    __uri_path__ = "data/connections"
    __resource_id__ = DataConnectionId

    database: ValidDataConnections = Field(..., description="The database parameters, which are defined per source type.")
    owner: PersonId | str | PersonModel | None = Field(default=None, description="The identifier of the person who owns the data connection.")
    organization: OrganizationId | str | OrganizationModel | None = Field(
        default=None, description="The identifier of the organization who owns the data connection."
    )

    semantic_type: Literal["DATA_CONNECTION"] = "DATA_CONNECTION"

    @property
    def resource_id(self) -> DataConnectionId:
        return DataConnectionId(id=self.id, name=self.name, version=self.version)
