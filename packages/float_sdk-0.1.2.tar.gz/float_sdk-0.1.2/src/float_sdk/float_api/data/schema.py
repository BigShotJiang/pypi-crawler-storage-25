# pyright: basic
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.data.fields import DataFieldCategoryModel, DataFieldModel


class DataSchemaModel(ResourceModel):
    """
    A data schema is a structured representation of the organization and attributes
    of a given dataset. It defines the data types and constraints for each field,
    outlining the logical structure and relationships. The data schema serves as a
    blueprint for organizing and storing data in a specific format, ensuring integrity
    and facilitating efficient querying.
    """

    fields: List[DataFieldModel] = Field(..., title="Fields", description="Array of field definitions.")
    data_model: str | list[str] | None = Field(default=None, title="Data Model", description="Float data model for underlying data table (optional)")
    database: str | None = Field(default=None, title="Database", description="Database id where the table resides.")
    schema_version: str | None = Field(default=None, title="Schema Version", description="User-defined semantic version of the data schema")
    categories: List[DataFieldCategoryModel] | None = Field(default=None, title="Categories", description="Array of field category definitions.")

    semantic_type: Literal["DATA_SCHEMA"] = "DATA_SCHEMA"
