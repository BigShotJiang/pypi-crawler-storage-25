# pyright: basic
#!/usr/bin/env python

"""
Data providers and standards

"""

from datetime import date
from enum import Enum
from typing import List, Literal, Optional

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import EntityId, OrganizationId
from float_sdk.float_api.organizations.contact import WebPageModel
from float_sdk.float_api.serialization.types import TypeModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies"
__email__ = "andy@float.tech"


class PublicationStatus(Enum):
    PUBLISHED = "Published"
    DRAFT = "Draft"


class SchemeType(Enum):
    FPML = "FPML"


class Scheme(TypeModel):
    type: SchemeType = SchemeType.FPML
    uri: str = ""


class StandardModel(NamedResourceModel):
    publication_date: Optional[date] = None
    organization: Optional[OrganizationId] = None
    issuing_entity: Optional[EntityId] = None
    technical_committee: Optional[str] = None
    ics: Optional[str] = None
    edition: int = 1
    status: PublicationStatus = PublicationStatus.DRAFT
    schemes: Optional[List[Scheme]] = None
    web_pages: Optional[List[WebPageModel]] = None

    semantic_type: Literal["STANDARD"] = "STANDARD"
