# pyright: basic
#!/usr/bin/env python

"""
Data Products

"""

from typing import Literal, Optional, Union

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.assets.base.base import AssetClass
from float_sdk.float_api.base.references import DataCategoryId, EntityId
from float_sdk.float_api.organizations.contact import ContactInfoModel
from float_sdk.float_api.organizations.legal import EntityModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DataCategoryModel(NamedResourceModel):
    __uri_path__ = "data/categories"

    semantic_type: Literal["DATA_CATEGORY"] = "DATA_CATEGORY"


class DataProductModel(NamedResourceModel):
    __uri_path__ = "data/products"

    category: Optional[Union[DataCategoryId, DataCategoryModel]] = None
    asset_class: Optional[AssetClass] = None
    vendor: Optional[Union[EntityId, EntityModel]] = None
    carrier: Optional[Union[EntityId, EntityModel]] = None
    market: Optional[Union[EntityId, EntityModel]] = None
    contact_info: Optional[ContactInfoModel] = None

    semantic_type: Literal["DATA_PRODUCT"] = "DATA_PRODUCT"
