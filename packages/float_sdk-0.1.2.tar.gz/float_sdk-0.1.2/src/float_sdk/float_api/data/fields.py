#!/usr/bin/env python
# pyright: basic

"""
Object Serialization.

Provides decorators for classes to allow serialization
to and from JSON format. Uses type information to map
attributes automatically.
"""

from typing import Any, Literal, Optional

from pydantic import Field

from float_sdk.float_api.assets.base.base import AssetReferenceTypes
from float_sdk.float_api.base.references import ReferenceTypes
from float_sdk.float_api.base.types import PrimitiveTypes
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api.trading.parties import PartyReferenceTypes

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


_DATA_FIELD_TYPES = PrimitiveTypes | ReferenceTypes | AssetReferenceTypes | PartyReferenceTypes | None


class DataFieldCategoryModel(DataModel):
    """
    Data Field Category

    Defines a category for a data field, which can be used to group related fields
    together. This can be useful for organizing and categorizing data fields in a
    dataset schema.

    Attributes
    ----------
    id : str
        The unique identifier of the category.
    name : str
        The display name of the category.
    description : str, optional
        A description of the category.
    """

    id: str = Field(..., title="Id", description="Unique identifier of the category.")
    name: str = Field(..., title="Name", description="Display name of the category.")
    description: str | None = Field(default=None, title="Description", description="Description of the category.")

    semantic_type: Literal["DATA_FIELD_CATEGORY"] = "DATA_FIELD_CATEGORY"


class DataFieldPropertiesModel(DataModel):
    """
    Data Field Properties

    Defines properties of the field, for example whether it is visible
    by default, read-only, required, etc.
    """

    read_only: bool | None = Field(default=False, title="Read Only", description="Whether the field is read-only.")
    visible: bool | None = Field(default=True, title="Visible", description="Whether the field is visible by default.")
    ignore_match: bool | None = Field(default=False, title="Ignore Match", description="Whether to ignore the field when matching.")
    required: bool | None = Field(default=False, title="Required", description="Whether the field is required.")
    modified: bool | None = Field(default=False, title="Modified", description="Whether the field has been modified.")

    semantic_type: Literal["DATA_FIELD_PROPERTIES"] = "DATA_FIELD_PROPERTIES"


class DataFieldModel(DataModel):
    """
    Data Field

    Defines a data field specification as part of a dataset schema. Data field attributes
    specify the id, name, type, and other attributes of the field, which can be used to
    query data stores or render datasets.

    """

    id: str = Field(..., title="Id", description="User defined field identifier. Often the column name in the table.")
    name: Optional[str] = Field(default=None, title="Name", description="Display name of the field.")
    description: Optional[str] = Field(default=None, title="Description", description="Description of the field.")
    data_type: _DATA_FIELD_TYPES = Field(default=None, title="Data Type", description="Data type of the field.")
    field_path: str | None = Field(default=None, title="Field Path", description="Path to the field in the data store.")
    default: Optional[Any] = Field(default=None, title="Default", description="Default value of field, if required")
    category: str | None = Field(default=None, title="Category", description="Category, which is used to group related fields.")
    params: dict[str, Any] | None = Field(default=None, title="Params", description="Parameters for the field.")

    properties: DataFieldPropertiesModel | None = Field(default=None, title="Properties", description="Properties of the field.")

    semantic_type: Literal["DATA_FIELD"] = "DATA_FIELD"
