#!/usr/bin/env python
# pyright: basic

"""
Data Views

Manage data views / data queries

"""

from enum import Enum
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import ApplicationId, DatasetId, DataViewId, DataWorkspaceId, GroupId, OrganizationId, PersonId
from float_sdk.float_api.data.query import DataQueryModel
from float_sdk.float_api.data.sets import DatasetModel
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import ApplicationModel, GroupModel, PersonModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class DataViewCategory(Enum):
    # Reference data
    #
    HOME = "HOME"
    ASSETS = "ASSETS"
    VENUES = "VENUES"
    DATA = "DATA"
    FEEDS = "FEEDS"

    ## Library
    #
    DOCUMENTS = "DOCUMENTS"  # Legacy
    DOCUMENTS_CONFIRMATIONS = "DOCUMENTS_CONFIRMATIONS"
    DOCUMENTS_MCAS = "DOCUMENTS_MCAS"
    DOCUMENTS_ISDA_DEFINITIONS = "DOCUMENTS_ISDA_DEFINITIONS"
    DOCUMENTS_NDAS = "DOCUMENTS_NDAS"
    DOCUMENTS_MASTER_AGREEMENTS = "DOCUMENTS_MASTER_AGREEMENTS"
    DOCUMENTS_TEMPLATES = "DOCUMENTS_TEMPLATES"
    INBOX_CONFIRMATIONS = "INBOX_CONFIRMATIONS"
    INBOX_RECAPS = "INBOX_RECAPS"

    # Organization
    #
    ACCOUNTS = "ACCOUNTS"

    # Trading / FIX
    #
    FIX = "FIX"
    TRADES = "TRADES"
    TRADES_ALLEGED = "TRADES_ALLEGED"
    VALUATION_TRADES = "VALUATION_TRADES"
    VALUATIONS = "VALUATIONS"

    # Automation / Workflows
    #
    WORKFLOWS = "WORKFLOWS"
    AUTOMATION = "AUTOMATION"
    TASKS = "TASKS"

    # Network / CRM
    #
    INITIATIVES = "INITIATIVES"
    PROJECTS = "PROJECTS"
    ISSUES = "ISSUES"
    TRACK = "TRACK"
    OPPORTUNITIES = "OPPORTUNITIES"

    # System / Observability
    #
    OBSERVABILITY = "OBSERVABILITY"

    ## Market Data
    #
    MARKET_DATA = "MARKET_DATA"


class DataViewFieldModel(DataModel):
    """
    Data Fields are used to provide a view a list of fields available to it.
    By default, all fields in the dataset schema are provided.
    """

    id: str | None = Field(default=None, title="Id", description="The ID of the field")
    name: str | None = Field(default=None, title="Name", description="The Name of the field")

    semantic_type: Literal["DATA_VIEW_FIELD"] = "DATA_VIEW_FIELD"


class DataViewModel(NamedResourceModel):
    """
    Data sheet defines a view on a dataset, includig the sheet name,
    query, and other similar properties.
    """

    __uri_path__ = "data/views"
    __resource_id__ = DataViewId

    query: DataQueryModel | None = Field(default=None, title="Query", description="Query to be executed")
    fields: List[DataViewFieldModel] | None = Field(default=None, title="Fields", description="List of fields the view can be filtered by")
    dataset: DatasetId | str | DatasetModel | None = Field(default=None, title="Dataset", description="Dataset to be executed")
    category: DataViewCategory | None = Field(default=None, title="Category", description="Category of the view")
    page_size: int | None = Field(default=None, title="Page Size", description="Number of rows per page in the view")

    # Ownership
    organization: OrganizationId | str | OrganizationModel | None = Field(
        None, title="Organization", description="Organization to which the data query belongs"
    )
    group: GroupId | str | GroupModel | None = Field(default=None, title="Group", description="Group to which the data query belongs")
    owner: PersonId | ApplicationId | str | PersonModel | ApplicationModel | None = Field(
        None, title="Owner", description="Person or application who owns the data query"
    )

    ## Derived data (query time)
    row_count: int | None = Field(default=None, title="Row Count", description="Number of rows in the sheet")

    semantic_type: Literal["DATA_VIEW"] = "DATA_VIEW"


class DataWorkspaceModel(NamedResourceModel):
    """
    Data view defines a view configuration for multiple sheets / tabs on one or more datasets.
    """

    __uri_path__ = "data/workspaces"
    __resource_id__ = DataWorkspaceId

    organization: OrganizationId | str | OrganizationModel | None = Field(
        None, title="Organization", description="Organization to which the data workspace belongs"
    )
    owner: PersonId | str | PersonModel | ApplicationId | ApplicationModel | None = Field(default=None, title="Owner", description="Owner of the view")
    group: GroupId | str | GroupModel | None = Field(default=None, title="Group", description="Group to which the view belongs")
    category: DataViewCategory | None = Field(default=None, title="Category", description="Category of the view")
    views: List[DataViewModel | str | DataViewId] | None = Field(default=None, title="Views", description="Data views available in workspace")

    semantic_type: Literal["DATA_WORKSPACE"] = "DATA_WORKSPACE"


class PlatformWorkspaces(Enum):
    FLOAT_ASSETS_WORKSPACE = "FLOAT_ASSETS_WORKSPACE"
    FLOAT_DOCUMENTS_WORKSPACE = "FLOAT_DOCUMENTS_WORKSPACE"
    FLOAT_INBOX_CONFIRMS_WORKSPACE = "FLOAT_INBOX_CONFIRMS_WORKSPACE"
    FLOAT_INBOX_RECAPS_WORKSPACE = "FLOAT_INBOX_RECAPS_WORKSPACE"
    FLOAT_DOCUMENTS_CONFIRMS_WORKSPACE = "FLOAT_DOCUMENTS_CONFIRMS_WORKSPACE"
    FLOAT_TRADES_WORKSPACE = "FLOAT_TRADES_WORKSPACE"
    FLOAT_TRADES_ALLEGED_WORKSPACE = "FLOAT_TRADES_ALLEGED_WORKSPACE"
    FLOAT_WORKFLOWS_WORKSPACE = "FLOAT_WORKFLOWS_WORKSPACE"
    FLOAT_TASKS_WORKSPACE = "FLOAT_TASKS_WORKSPACE"
    FLOAT_DATA_WORKSPACE = "FLOAT_DATA_WORKSPACE"
    FLOAT_FEEDS_WORKSPACE = "FLOAT_FEEDS_WORKSPACE"
    FLOAT_FIX_WORKSPACE = "FLOAT_FIX_WORKSPACE"
    FLOAT_HOME_WORKSPACE = "FLOAT_HOME_WORKSPACE"
