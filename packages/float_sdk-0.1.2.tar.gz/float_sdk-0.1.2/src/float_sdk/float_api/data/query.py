# pyright: basic
#!/usr/bin/env python

"""
Data Query Model

Provides data model to define a query against a given
dataset defined by a data schema.
"""

from typing import Any, Generic, List, Literal, Optional, TypeVar, Union

from pydantic import Field

from float_sdk.float_api.data.schema import DataSchemaModel
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DataQuerySelectorType(DisplayEnum):
    EQUAL = "EQUAL"
    NOT_EQUAL = "NOT_EQUAL"
    GREATER_THAN = "GREATER_THAN"
    GREATER_THAN_OR_EQUAL = "GREATER_THAN_OR_EQUAL"
    LESS_THAN = "LESS_THAN"
    LESS_THAN_OR_EQUAL = "LESS_THAN_OR_EQUAL"
    IN = "IN"
    NOT_IN = "NOT_IN"
    MATCH_ELEMENT = "MATCH_ELEMENT"
    REGEX = "REGEX"

    def display_names(self) -> dict[str, str]:
        return {
            "EQUAL": "Equal",
            "NOT_EQUAL": "Not equal",
            "GREATER_THAN": "Greater than",
            "GREATER_THAN_OR_EQUAL": "Greater than or equal",
            "LESS_THAN": "Less than",
            "LESS_THAN_OR_EQUAL": "Less than or equal",
            "IN": "In",
            "NOT_IN": "Not in",
            "MATCH_ELEMENT": "Match element",
            "REGEX": "Regular Expression",
        }


class DataQuerySelectorModel(DataModel):
    type: DataQuerySelectorType
    field: str | None = None
    value: Any | None = None
    tolerance: int | float | None = None

    semantic_type: Literal["DATA_QUERY_SELECTOR"] = "DATA_QUERY_SELECTOR"

    def describe(self) -> str:
        if isinstance(self.value, DataQueryOperatorModel):
            return f"{self.field} {self.type.value} {self.value.describe()}"
        else:
            return f"{self.field} {self.type.value} {self.value}"


class DataQueryOperatorType(DisplayEnum):
    AND = "AND"
    OR = "OR"

    def display_names(self) -> dict[str, str]:
        return {
            "AND": "And",
            "OR": "Or",
        }


class DataQueryOperatorModel(DataModel):
    type: DataQueryOperatorType
    query: List[Union[DataQuerySelectorModel, "DataQueryOperatorModel"]]

    semantic_type: Literal["DATA_QUERY_OPERATOR"] = "DATA_QUERY_OPERATOR"

    @classmethod
    def init_forward_hints(cls):  # type: ignore
        return {"DataQueryOperatorModel": cls}

    def describe(self) -> str:
        query_desc = [q.describe() for q in self.query]
        query_desc = f" {self.type.value} ".join(query_desc)
        return f"({query_desc})"


class DataQuerySortDirection(DisplayEnum):
    ASCENDING = "ASCENDING"
    DESCENDING = "DESCENDING"

    def display_names(self) -> dict[str, str]:
        return {
            "ASCENDING": "Ascending",
            "DESCENDING": "Descending",
        }


class DataQuerySortModel(DataModel):
    field: str = Field(..., title="Field", description="Field to sort by")
    direction: DataQuerySortDirection = Field(..., title="Direction", description="Direction in which to sort")


class DataQueryGroupExpression(DisplayEnum):
    LAST = "LAST"
    FIRST = "FIRST"
    SUM = "SUM"

    def display_names(self) -> dict[str, str]:
        return {
            "LAST": "Last",
            "FIRST": "First",
            "SUM": "Sum",
        }


class DataQueryGroupOperatorModel(DataModel):
    name: str = Field(..., title="Name", description="Name of the new column")
    field: str = Field(..., title="Field", description="Field to group by")
    expression: DataQueryGroupExpression

    semantic_type: Literal["DATA_QUERY_GROUP_OPERATOR"] = "DATA_QUERY_GROUP_OPERATOR"


class DataQueryGroupModel(DataModel):
    id: str = Field(..., title="Id", description="Column by which to group")
    operators: List[DataQueryGroupOperatorModel] = Field(..., title="Operators", description="List of operators expressions")

    semantic_type: Literal["DATA_QUERY_GROUP"] = "DATA_QUERY_GROUP"


class FuzzySearchModel(DataModel):
    max_edits: int = Field(default=2, ge=0, le=2, title="Max Edits", description="Maximum edit distance for fuzzy matching (0-2)")
    prefix_length: int = Field(default=0, ge=0, title="Prefix Length", description="Number of characters at start that must match exactly")

    semantic_type: Literal["FUZZY_SEARCH_MODEL"] = "FUZZY_SEARCH_MODEL"


class DataQuerySearchModel(DataModel):
    query: str | None = Field(default=None, title="Query", description="Search text to match")
    fields: List[str] | None = Field(default=None, title="Fields", description="List of fields to search across")
    index_name: str | None = Field(default=None, title="Index Name", description="Search index name")
    fuzzy: FuzzySearchModel | None = Field(default=None, title="Fuzzy Search", description="Fuzzy matching configuration (optional)")
    min_score: float | None = Field(default=None, title="Minimum Score", description="Minimum relevance score threshold to filter weak matches")

    semantic_type: Literal["DATA_QUERY_SEARCH"] = "DATA_QUERY_SEARCH"


class DataQueryModel(DataModel):
    fields: List[str] | dict[str, str] | None = Field(default=None, title="Fields", description="List of fields to return, or map of field name to field path")
    query: DataQuerySelectorModel | DataQueryOperatorModel | None = Field(default=None, title="Query", description="Query to filter results")
    search: DataQuerySearchModel | None = Field(
        default=None,
        title="Search",
        description="Search configuration. Values not provided are merged from the dataset's search_config.",
    )
    sort: List[DataQuerySortModel] | None = Field(default=None, title="Sort", description="List of sort criteria")
    group: DataQueryGroupModel | None = Field(default=None, title="Group", description="Group by criteria")

    # Pagination
    limit: int | None = Field(default=None, title="Limit", description="Maximum number of results to return")
    offset: int | None = Field(default=None, title="Offset", description="Offset of the first page to return")

    semantic_type: Literal["DATA_QUERY"] = "DATA_QUERY"

    @property
    def query_fields(self) -> List[str]:
        if not self.fields:
            return []

        if isinstance(self.fields, dict):
            return list(self.fields.keys())

        return self.fields


class DataQueryResultModel(DataModel):
    result: Any = Field(default=None, title="Result", description="Result of query")
    data_schema: Optional[DataSchemaModel] = Field(default=None, title="Data Schema", description="Data schema for result table")

    semantic_type: Literal["DATA_QUERY_RESULT"] = "DATA_QUERY_RESULT"


class DataTableModel(DataModel):
    data: List[Any] = Field(..., title="Data", description="Data table")

    semantic_type: Literal["DATA_TABLE"] = "DATA_TABLE"


class DataQueryResultsModel(DataModel):
    results: List[Any] = Field(..., title="Results", description="Results of data query")  # Results can be any valid model, enforced by schema.row_model
    total_results: int = Field(..., title="Total Results", description="Total number of results available on the server")
    limit: int | None = Field(default=None, title="Limit", description="Maximum number of results to return per page")
    offset: int | None = Field(default=None, title="Page offset to start result set (0 is first page)")
    number_returned: int = Field(..., title="Number Returned", description="Number of results returned in this result set (page)")

    data_schema: DataSchemaModel | None = Field(default=None, title="Data Schema", description="Data schema of returned results")

    semantic_type: Literal["DATA_QUERY_RESULTS"] = "DATA_QUERY_RESULTS"

    def context(self) -> str:
        lines: list[str] = []
        lines.append(f"Total Results: {self.total_results} | Returned: {self.number_returned}")
        if self.limit is not None or self.offset is not None:
            lines.append(f"Limit: {self.limit} | Offset: {self.offset}")

        if not self.results:
            lines.append("\nNo results.")
            return "\n".join(lines)

        if self.data_schema and self.data_schema.fields:
            headers = [f.name or f.id for f in self.data_schema.fields]
            field_ids = [f.id for f in self.data_schema.fields]
        else:
            first = self.results[0]
            if isinstance(first, dict):
                field_ids = list(first.keys())
            elif hasattr(first, "model_dump"):
                field_ids = list(first.model_dump().keys())
            else:
                field_ids = list(vars(first).keys()) if hasattr(first, "__dict__") else []
            headers = field_ids

        if not headers:
            lines.append("\nNo fields to display.")
            return "\n".join(lines)

        def get_value(row: Any, field_id: str) -> str:
            if isinstance(row, dict):
                val = row.get(field_id)
            elif hasattr(row, field_id):
                val = getattr(row, field_id)
            else:
                val = ""
            if val is None:
                return ""
            return str(val)

        rows: list[list[str]] = []
        for row in self.results[:10]:
            rows.append([get_value(row, fid) for fid in field_ids])

        col_widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(cell))

        header_line = "| " + " | ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers)) + " |"
        separator = "|-" + "-|-".join("-" * w for w in col_widths) + "-|"

        lines.append("")
        lines.append(header_line)
        lines.append(separator)
        for row in rows:
            lines.append("| " + " | ".join(cell.ljust(col_widths[i]) for i, cell in enumerate(row)) + " |")

        return "\n".join(lines)


T = TypeVar("T", bound=Any)


class DataQueryTypedResultsModel(DataQueryResultsModel, Generic[T]):
    results: List[T] = Field(..., title="Results", description="Results of data query")  # Results can be any valid model, enforced by schema.row_model
