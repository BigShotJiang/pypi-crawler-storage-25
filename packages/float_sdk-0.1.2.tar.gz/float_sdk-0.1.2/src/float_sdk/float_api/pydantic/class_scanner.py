# pyright: strict

import ast
import importlib
import sys
from pathlib import Path

from loguru import logger


class ClassScanner:
    @staticmethod
    def scan_and_import(base_class_name: str, root: Path | None = None) -> list[str]:
        if root is None:
            root = Path(__file__).resolve().parents[2]

        package_dirs = sorted(root.glob("float*/"))
        py_files: list[tuple[Path, str]] = []
        for pkg_dir in package_dirs:
            if not (pkg_dir / "__init__.py").exists():
                continue
            for py_file in pkg_dir.rglob("*.py"):
                source = py_file.read_text(encoding="utf-8")
                py_files.append((py_file, source))

        module_names = ClassScanner._find_subclass_modules(py_files, base_class_name, root)

        imported: list[str] = []
        already_loaded: list[str] = []
        newly_imported: list[str] = []
        for module_name in module_names:
            if module_name in sys.modules:
                already_loaded.append(module_name)
                imported.append(module_name)
                continue
            try:
                importlib.import_module(module_name)
                newly_imported.append(module_name)
                imported.append(module_name)
            except Exception as e:
                logger.warning(f"Failed to import {module_name}: {e}")

        logger.debug(
            f"scan_and_import({base_class_name}): "
            f"{len(already_loaded)} already in sys.modules, "
            f"{len(newly_imported)} newly imported, "
            f"{len(module_names) - len(imported)} failed"
        )
        if already_loaded:
            logger.debug(f"Already loaded: {already_loaded}")
        if newly_imported:
            logger.debug(f"Newly imported: {newly_imported}")
        return imported

    @staticmethod
    def _find_subclass_modules(
        py_files: list[tuple[Path, str]],
        base_class_name: str,
        root: Path,
    ) -> list[str]:
        known_names: set[str] = {base_class_name}
        scanned: set[Path] = set()
        import_paths: set[Path] = set()
        changed = True

        while changed:
            changed = False
            for py_file, source in py_files:
                if py_file in scanned:
                    continue
                if not any(name in source for name in known_names):
                    continue
                new_names = ClassScanner._extract_subclass_names(source, known_names)
                if new_names:
                    scanned.add(py_file)
                    known_names.update(new_names)
                    changed = True
                    if "init_forward_hints" in source:
                        import_paths.add(py_file)

        modules: list[str] = []
        for py_file in sorted(import_paths):
            rel = py_file.relative_to(root)
            modules.append(str(rel.with_suffix("")).replace("/", "."))
        return modules

    @staticmethod
    def _extract_subclass_names(source: str, known_bases: set[str]) -> set[str]:
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return set()

        found: set[str] = set()
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            for base in node.bases:
                base_name = ClassScanner._resolve_base_name(base)
                if base_name and base_name in known_bases:
                    found.add(node.name)
                    break
        return found

    @staticmethod
    def _resolve_base_name(node: ast.expr) -> str | None:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        if isinstance(node, ast.Subscript):
            return ClassScanner._resolve_base_name(node.value)
        return None
