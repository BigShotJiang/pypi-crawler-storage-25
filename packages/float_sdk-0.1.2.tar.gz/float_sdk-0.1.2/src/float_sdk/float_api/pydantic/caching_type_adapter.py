# pyright: basic
import inspect
from typing import Any

from cachetools import LRUCache
from pydantic import BaseModel, TypeAdapter

from float_sdk.float_api.api.reflection import get_all_types
from float_sdk.float_api.pydantic.rebuilding_metaclass import RebuildingBaseModelMetaclass


def _get_all_models_from_type(clazz: Any) -> list[type[BaseModel]]:
    """Extract all BaseModel classes from a type hierarchy (handles generics, unions, etc.)."""
    # Get all types referenced by this type (handles generics, unions, Annotated, etc.)
    all_types = get_all_types(clazz)

    # Find all BaseModel subclasses in the type hierarchy
    models: list[type[BaseModel]] = []
    for t in all_types:
        try:
            if inspect.isclass(t) and issubclass(t, BaseModel):
                models.append(t)
        except TypeError:
            # Some types can't be checked with issubclass
            continue

    return models


class CachingTypeAdapter:
    _cache: LRUCache = LRUCache(maxsize=1024)

    @classmethod
    def create_type_adapter(cls, clazz: Any) -> TypeAdapter[Any]:
        cache_key = str(clazz)

        # Fast path: return cached adapter if available
        # Once a TypeAdapter is created and cached, it should remain stable
        # to avoid breaking FastAPI's response serialization
        if cache_key in cls._cache:
            return cls._cache[cache_key]
        RebuildingBaseModelMetaclass.rebuild(clazz)
        adapter = TypeAdapter(clazz)
        cls._cache[cache_key] = adapter
        return adapter
