# pyright: strict

import inspect
import time
import traceback
from abc import ABC, abstractmethod
from typing import Any, get_type_hints

import loguru
from pydantic import PydanticUndefinedAnnotation, PydanticUserError
from pydantic._internal._model_construction import ModelMetaclass

from float_sdk.float_api.api.reflection import full_type_name, get_all_types


class ClassVisitor:
    class Visitor(ABC):
        @abstractmethod
        def visit(self, clazz: Any, path: list[str]): ...

        @abstractmethod
        def should_visit(self, clazz: Any, path: list[str]) -> bool: ...

    @staticmethod
    def visit(clazz: Any, visitor: Visitor, visited: set[type], path: list[str] | None = None) -> None:
        if clazz in visited:
            return

        if not visitor.should_visit(clazz, path or []):
            return

        loguru.logger.debug(f"Visitor: {visitor.__class__.__name__} Visiting {clazz} in {path}")

        visited.add(clazz)

        if path is None:
            path = []

        full_class_name = full_type_name(clazz)

        path.append(full_class_name)
        try:
            t0 = time.perf_counter()
            all_implied_types = get_all_types(clazz)
            for k in reversed(clazz.__mro__[:-1]):
                all_implied_types.update(get_all_types(k))
            t1 = time.perf_counter()
            loguru.logger.debug(f"  [{full_class_name}] get_all_types + MRO: {(t1 - t0) * 1000:.1f}ms ({len(all_implied_types)} types)")

            mro_hints = FwdHintsCache.get_and_collect_mro_hints(clazz)
            t2 = time.perf_counter()
            loguru.logger.debug(f"  [{full_class_name}] collect_mro_hints: {(t2 - t1) * 1000:.1f}ms ({len(mro_hints)} hints)")

            module = inspect.getmodule(clazz)
            module_globals = vars(module) if module else {}
            t3 = time.perf_counter()

            children = get_type_hints(clazz, globalns=module_globals, localns=FwdHintsCache.get_all_fwd_hints())
            t4 = time.perf_counter()
            loguru.logger.debug(f"  [{full_class_name}] get_type_hints: {(t4 - t3) * 1000:.1f}ms ({len(children)} children)")

            for child in children.values():
                all_implied_types.update(get_all_types(child))

            for hint in mro_hints.values():
                all_implied_types.update(get_all_types(hint))
            t5 = time.perf_counter()
            loguru.logger.debug(f"  [{full_class_name}] expand children + hints: {(t5 - t4) * 1000:.1f}ms ({len(all_implied_types)} total types)")

            for t in all_implied_types:
                ClassVisitor.visit(t, visitor, visited=visited, path=path)
            t6 = time.perf_counter()
            loguru.logger.debug(f"  [{full_class_name}] recursive visit: {(t6 - t5) * 1000:.1f}ms")

            visitor.visit(clazz, path)
            loguru.logger.debug(f"  [{full_class_name}] total: {(time.perf_counter() - t0) * 1000:.1f}ms")
        finally:
            path.pop()


class FwdHintsCache:
    _collected: set[type] = set()
    _hints: dict[str, Any] = {}
    _mro_hints_cache: dict[type, dict[str, Any]] = {}

    class _FwdHintVisitor(ClassVisitor.Visitor):
        def __init__(self, force: bool = False) -> None:
            self.collected_hints: dict[str, Any] = {}
            self._force = force

        def should_visit(self, clazz: Any, path: list[str]) -> bool:
            if FwdHintsCache.is_collected(clazz) and not self._force:
                return False

            if not RebuildingBaseModelMetaclass.eligible_for_rebuild(clazz, force=self._force):
                return False

            return True

        def visit(self, clazz: Any, path: list[str]) -> None:
            FwdHintsCache._collect_single(clazz)
            hints = FwdHintsCache.get_fwd_hints(clazz)
            if hints:
                self.collected_hints.update(hints)

    @classmethod
    def get_all_fwd_hints(cls) -> dict[str, Any]:
        return cls._hints

    @classmethod
    def get_fwd_hints(cls, clazz: Any) -> dict[str, Any] | None:
        if "init_forward_hints" in vars(clazz):
            return clazz.init_forward_hints()
        return None

    @classmethod
    def _collect_single(cls, clazz: Any) -> None:
        if clazz in cls._collected:
            return
        cls._collected.add(clazz)
        hints = cls.get_fwd_hints(clazz)
        if hints:
            cls._hints.update(hints)

    @classmethod
    def collect(cls, clazz: Any, force: bool = False) -> dict[str, Any]:
        start = time.perf_counter()
        visitor = cls._FwdHintVisitor(force=force)
        ClassVisitor.visit(clazz, visitor, visited=set())
        elapsed_ms = (time.perf_counter() - start) * 1000
        loguru.logger.debug(f"Collected {len(visitor.collected_hints)} forward hints for {full_type_name(clazz)} in {elapsed_ms:.1f}ms")
        return visitor.collected_hints

    @classmethod
    def is_collected(cls, clazz: Any) -> bool:
        return clazz in cls._collected

    @classmethod
    def get_and_collect_mro_hints(cls, clazz: Any) -> dict[str, Any]:
        cached = cls._mro_hints_cache.get(clazz)
        if cached is not None:
            return cached
        mro_hints: dict[str, Any] = {}
        for klass in reversed(clazz.__mro__):
            cls._collect_single(klass)
            hints = cls.get_fwd_hints(klass)
            if hints:
                mro_hints.update(hints)
        cls._hints.update(mro_hints)
        cls._mro_hints_cache[clazz] = mro_hints
        return mro_hints


class RebuildingBaseModelMetaclass(ModelMetaclass):
    """
    Meta class that extends ModelMetaclass with additional functionality of rebuilding model on demand using forward hints.
    Rebuild recursive traverse type definition, rebuilding leaf models and collecting namespace, passing it to parent
    and rebuilding
    """

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        try:
            return super().__call__(*args, **kwargs)
        except (TypeError, PydanticUserError, PydanticUndefinedAnnotation) as e1:
            stack_trace = "".join(traceback.format_stack()[:-1])
            loguru.logger.opt(exception=e1).info(f"Rebuilding model: {full_type_name(cls)} on demand\n{stack_trace}")
            try:
                RebuildingBaseModelMetaclass._rebuild(cls)
                return super().__call__(*args, **kwargs)
            except (TypeError, PydanticUserError, PydanticUndefinedAnnotation) as e2:
                loguru.logger.opt(exception=e2).info(f"Failed to create instance of {full_type_name(cls)} after rebuild, forcing rebuild")
                RebuildingBaseModelMetaclass._rebuild(cls, force=True)
                return super().__call__(*args, **kwargs)

    def rebuild(cls):
        loguru.logger.info(f"Rebuilding model: {full_type_name(cls)}")
        try:
            RebuildingBaseModelMetaclass._rebuild(cls)
        except (TypeError, PydanticUserError, PydanticUndefinedAnnotation) as e2:
            loguru.logger.opt(exception=e2).info(f"Failed to create instance of {full_type_name(cls)} after rebuild, forcing rebuild")
            RebuildingBaseModelMetaclass._rebuild(cls, force=True)

    @classmethod
    def _rebuild(cls, clazz: Any, force: bool = False) -> None:
        if cls.is_pydantic_complete(clazz):
            return

        start = time.perf_counter()
        all_types = get_all_types(clazz)
        eligible = [t for t in all_types if cls.eligible_for_rebuild(t, force=force)]

        if len(eligible) > 0:
            for t in eligible:
                FwdHintsCache.collect(t, force=force)
            for t in eligible:
                if cls.is_pydantic_complete(t):
                    continue
                t.model_rebuild(_types_namespace=FwdHintsCache.get_all_fwd_hints())  # type: ignore
                if not cls.is_pydantic_complete(t):
                    raise RuntimeError(f"Model {full_type_name(t)} is not complete after rebuild")
            elapsed_ms = (time.perf_counter() - start) * 1000
            loguru.logger.debug(f"Rebuilt {full_type_name(clazz)} in {elapsed_ms:.1f}ms")

    @classmethod
    def eligible_for_rebuild(cls, clazz: Any, force: bool = False) -> bool:
        from float_sdk.float_api.serialization.model import TypeModel

        if not inspect.isclass(clazz) or not issubclass(clazz, TypeModel):
            return False
        generic_meta = getattr(clazz, "__pydantic_generic_metadata__", None)
        if generic_meta and generic_meta.get("args"):
            return False
        if FwdHintsCache.get_fwd_hints(clazz) is None and not force:
            return False
        return True

    @classmethod
    def rebuild_all_type_models(cls) -> int:
        from float_sdk.float_api.api.reflection import get_all_subclasses
        from float_sdk.float_api.pydantic.class_scanner import ClassScanner
        from float_sdk.float_api.serialization.model import TypeModel

        stack_trace = "".join(traceback.format_stack()[:-1])
        loguru.logger.info(f"rebuild_all_type_models called from:\n{stack_trace}")

        total_start = time.perf_counter()

        import_start = time.perf_counter()
        ClassScanner.scan_and_import(base_class_name="TypeModel")
        import_ms = (time.perf_counter() - import_start) * 1000
        loguru.logger.info(f"Imported all TypeModel modules in {import_ms:.1f}ms")

        all_models = get_all_subclasses(TypeModel)
        eligible_models = [m for m in all_models if cls.eligible_for_rebuild(m)]

        hints_start = time.perf_counter()
        for model in eligible_models:
            FwdHintsCache.collect(model)
        hints_ms = (time.perf_counter() - hints_start) * 1000
        loguru.logger.info(f"Collected {len(FwdHintsCache.get_all_fwd_hints())} forward hints from {len(eligible_models)} models in {hints_ms:.1f}ms")

        rebuild_start = time.perf_counter()
        rebuilt_count = 0
        skipped_count = 0
        for model in eligible_models:
            try:
                if cls.is_pydantic_complete(model):
                    skipped_count += 1
                    continue
                model.model_rebuild(_types_namespace=FwdHintsCache.get_all_fwd_hints())
                if not cls.is_pydantic_complete(model):
                    raise RuntimeError(f"Model {full_type_name(model)} is not complete after rebuild")
                rebuilt_count += 1
            except Exception as e:
                loguru.logger.error(f"Failed to rebuild model {model.__name__}: {e}")
        rebuild_ms = (time.perf_counter() - rebuild_start) * 1000

        total_ms = (time.perf_counter() - total_start) * 1000
        loguru.logger.info(
            f"Rebuilt {rebuilt_count} models, skipped {skipped_count} already complete "
            f"(of {len(eligible_models)} eligible) in {rebuild_ms:.1f}ms (total {total_ms:.1f}ms)"
        )
        return rebuilt_count

    @classmethod
    def is_pydantic_complete(cls, clazz: Any) -> bool:
        return getattr(clazz, "__pydantic_complete__", False)
