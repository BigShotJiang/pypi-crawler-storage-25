# pyright: basic
#!/usr/bin/env python

"""
Location Information

"""

import datetime as dt
from enum import Enum
from typing import List, Literal

from pydantic import Field, field_validator

from float_sdk.float_api.api.resource import NamedResourceModel, ResourceIdentifierModel
from float_sdk.float_api.base.references import (
    CountryId,
    CurrencyId,
    GroupId,
    HolidayCalendarId,
    JurisdictionId,
    LocationId,
    OrganizationId,
)
from float_sdk.float_api.datetime.calendars import HolidayCalendarModel
from float_sdk.float_api.organizations.contact import AddressModel, TelephoneModel
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api.serialization.types import TimezoneType

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class CoordinatesModel(DataModel):
    """
    Longitude and latitude of a location.
    """

    longitude: float = Field(..., description="Longitude of coordinate.")
    latitude: float = Field(..., description="Latitude of coordinate.")


class LocationType(Enum):
    """
    Type of location, whether it represents an office location, business center, etc.
    """

    OFFICE_LOCATION = "OFFICE_LOCATION"
    BUSINESS_CENTER = "BUSINESS_CENTER"


class LocationIdentifierType(Enum):
    IATA_CODE = "IATA_CODE"


class LocationIdentifier(ResourceIdentifierModel):
    type: LocationIdentifierType


class LocationModel(NamedResourceModel):
    """
    An organization location, which represents an office or workplace. People are assigned to a
    location which can be used for managing global workflows, timezones, etc.
    """

    model_config = dict(arbitrary_types_allowed=True)

    short_name: str | None = Field(default=None, description="Short hand name for the location (e.g. LDN)")
    address: AddressModel | None = Field(default=None, description="Physical address for the location, if applicable.")
    telephones: List[TelephoneModel] | None = Field(default=None, description="List of telephone numbers assoviated with the location.")
    is_headquarters: bool | None = Field(default=None, description="Is the location a headquarters for the organization.")
    coordinates: CoordinatesModel | None = Field(default=None, description="Geocoordinates (longitude and lattitude) of the location.")
    timezone: TimezoneType = Field(default=None, title="Timezone", description="Timezone of the specified location (IANA timezone format)")
    holiday_calendar: HolidayCalendarId | str | HolidayCalendarModel | None = Field(
        default=None, title="Holiday Calendar", description="Holiday calendar for this location"
    )
    organization: OrganizationId | str | None = Field(default=None, description="The identifier of the organization which ")
    group: GroupId | str | None = Field(default=None, description="Identifier of the group which can access this dataset.")
    type: LocationType | None = Field(default=None, description="Type of location, whether it represents an office location, business center, etc.")

    identifiers: List[LocationIdentifier] | None = Field(default=None, description="List of other identifiers for this location")

    semantic_type: Literal["LOCATION"] = "LOCATION"

    @classmethod
    def init_forward_hints(cls):  # type: ignore
        from float_sdk.float_api.organizations.people import GroupModel as _GroupModel

        return {"GroupModel": _GroupModel}

    @property
    def resource_id(self) -> LocationId:
        return LocationId(id=self.id, name=self.name)


class TimeLocationModel(DataModel):
    """
    Time with location information.

    Attributes
    ----------
    time: time
        The specified time
    location: LocationId
        The location of the time
    """

    @field_validator("time", mode="before")
    def datetime_to_time(cls, v):
        if isinstance(v, dt.datetime):
            return v.time()
        return v

    time: dt.time | None = Field(default=None, description="The specified time")
    location: LocationId | str | None = Field(default=None, description="The location of the time")

    semantic_type: Literal["TIME_LOCATION"] = "TIME_LOCATION"


class CountryModel(NamedResourceModel):
    """
    A country is a sovereign state characterized by a defined territory, population, and government.
    It maintains control over its internal and external affairs, including the enforcement of laws,
    regulation of economic activity, and representation in international relations. Countries vary
    in size, culture, political system, and level of development, but all exercise authority over
    their territories and populations.
    """

    capital: str | None = Field(default=None, description="Name of capital city.")
    currency: CurrencyId | str | None = Field(default=None, description="Circulating currency, or Legal tender for this country.")
    phone_prefix: str | None = Field(default=None, description="Telephone prefix to dial this country internationally.")
    iso3_code: str | None = Field(default=None, description="ISO 3 code for the country.")

    semantic_type: Literal["COUNTRY"] = "COUNTRY"

    @property
    def resource_id(self) -> CountryId:
        return CountryId(id=self.id, name=self.name)


class JurisdictionModel(NamedResourceModel):
    """
    Jurisdiction refers to the authority or power of a legal entity, such as a court or government,
    to hear and decide legal cases, enforce laws, and administer justice within a defined geographic
    area or subject matter. It delineates the boundaries within which a particular legal system operates
    and exercises control over individuals, organizations, and disputes.

    Jurisdiction can be based on various factors, including territorial boundaries, the subject matter
    of the case, the parties involved, or agreements between different legal entities. It plays a crucial
    role in ensuring the orderly resolution of legal matters and upholding the rule of law within a society.
    """

    country: CountryId | str | None = Field(default=None, description="Country reference for this jurisdiction.")

    semantic_type: Literal["JURISDICTION"] = "JURISDICTION"

    @property
    def resource_id(self) -> JurisdictionId:
        return JurisdictionId(id=self.id, name=self.name)
