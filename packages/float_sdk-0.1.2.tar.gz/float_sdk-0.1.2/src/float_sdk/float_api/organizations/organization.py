# pyright: basic
#!/usr/bin/env python

"""
Organization Model

"""

from datetime import date
from enum import Enum
from typing import List, Literal, Optional, Union

from pydantic import Field

from float_sdk.float_api.api.context import Environment
from float_sdk.float_api.api.resource import (
    NamedResourceModel,
    ResourceIdentifierModel,
    ResourceModel,
)
from float_sdk.float_api.base.references import (
    BusinessId,
    EntityId,
    GroupId,
    JurisdictionId,
    LocationId,
    OrganizationId,
    PersonId,
)
from float_sdk.float_api.base.values import DenominatedDatedValueModel
from float_sdk.float_api.organizations.contact import ContactInfoModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class OrganizationType(Enum):
    TECHNOLOGY = "TECHNOLOGY"
    HEDGE_FUND = "HEDGE_FUND"
    INVESTMENT_BANK = "INVESTMENT_BANK"
    INTERDEALER_BROKER = "INTERDEALER_BROKER"
    ASSET_MANAGER = "ASSET_MANAGER"
    SOVEREIGN_WEALTH_FUND = "SOVEREIGN_WEALTH_FUND"
    INDUSTRY_GROUP = "INDUSTRY_GROUP"


class OrganizationIdentifierType(Enum):
    SHORT_CODE = "SHORT_CODE"


class OrganizationModel(NamedResourceModel):
    """
    An organization is a structured entity, typically comprising individuals or groups,
    established to pursue specific objectives or goals. It delineates roles, responsibilities,
    and hierarchical relationships to facilitate efficient coordination and decision-making.
    They exist to achieve collective aims through the coordination of human, financial, and
    material resources, often guided by formalized processes and systems.

    Organizations in Float are the fundamental construct used to onboard a company and manage
    uesrs, businesses, and permissions.

    """

    short_code: str | None = Field(
        default=None,
        title="Short Code",
        description="Globally unique short code assigned to an organization, which is used to create readable ids for organization related resources",
    )
    type: OrganizationType | None = Field(
        default=None,
        description="The organization type. Specifies the nature of business the organization conducts, which is used to categorize the producers of various products and services on the platform.",
    )
    name: str | None = Field(default=None, description="The full name of the organization.")
    founded: date | int | None = Field(default=None, description="The date or year the organization was founded.")
    contact_info: ContactInfoModel | None = Field(default=None, description="Contact information for the organization.")
    email_domains: list[str] | None = Field(default=None, description="The email domains associated with the organization.")
    short_name: str | None = Field(default=None, description="The short name associated with the organization.")
    sso_id: str | None = Field(
        default=None,
        description="The ID of the associated SSO connection with the organization.",
    )

    group: GroupId | str | None = Field(default=None, description="Group identifier to drive entitlements and visibility rules")

    environment: Environment | None = Field(default=None, title="Environment", description="Environment of organization")

    aum: DenominatedDatedValueModel | None = Field(default=None, title="AUM", description="Assets under management.")

    semantic_type: Literal["ORGANIZATION"] = "ORGANIZATION"

    @classmethod
    def init_forward_hints(cls):  # type: ignore
        from float_sdk.float_api.organizations.people import GroupModel

        return {"GroupModel": GroupModel}

    @property
    def resource_id(self) -> OrganizationId:
        return OrganizationId(id=self.id, name=self.name, version=self.version)

    @property
    def context(self) -> str:
        return f"""Name: {self.name}
"ID: {self.id}
Short Code: {self.short_code}
Type: {self.type.value if self.type else "N/A"}
Counterparty Role {"Party 2" if self.type in [OrganizationType.HEDGE_FUND] else "Party 1"}"""


class CurrentOrganizationModel(ResourceModel):
    """
    The current organization set for a given person. This determines the organization on which to operate if the
    user is a member of multiple organizations. Drives the organization shown on login, or used when querying the
    various APIs which access organizational data.
    """

    person: PersonId | str | None = Field(default=None, description="Person identifier for whom to set current organization.")
    organization: Union[OrganizationId, str] = Field(..., description="Identifier of organization to set as current.")
    coverage_mode: bool | None = Field(default=None, title="Coverage Mode", description="Is coverage mode (all clients view) enabled)")
    impersonate: PersonId | str | None = Field(
        default=None,
        title="Impersonate",
        description="Person ID to impersonate. When set, the authenticated user acts as this person. Only available to FLOAT_ADMIN and FLOAT_COVERAGE roles.",
        json_schema_extra={"exclude": True},
    )

    semantic_type: Literal["CURRENT_ORGANIZATION"] = "CURRENT_ORGANIZATION"


class BusinessModel(NamedResourceModel):
    organization: Optional[OrganizationId] = Field(default=None, description="Organization to which the business belongs.")
    jurisdiction: Optional[JurisdictionId] = Field(default=None, description="Jurisdiction of the business.")
    parent: Optional[BusinessId] = Field(default=None, description="Parent business identifier.")
    contact_info: Optional[ContactInfoModel] = Field(default=None, description="Contact information for this business unit.")
    identifiers: Optional[List[ResourceIdentifierModel]] = Field(default=None, description="Additional identifiers for the business unit.")

    semantic_type: Literal["BUSINESS"] = "BUSINESS"

    @property
    def resource_id(self) -> BusinessId:
        return BusinessId(
            id=self.id,
            name=self.name,
            version=self.version,
        )


class EmploymentStatus(Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"
    LEAVE = "Leave"


class EmploymentContractType(Enum):
    FULL_TIME = "Full-Time"
    PART_TIME = "Part-Time"
    SELF_EMPLOYED = "Self-Employed"
    FREELANCE = "Freelance"
    CONTRACT = "Contract"
    INTERNSHIP = "Internship"
    APPRENTICESHIP = "Apprenticeship"
    SEASONAL = "Seasonal"


class EmploymentRoleModel(ResourceModel):
    person: Optional[PersonId] = None
    organization: Optional[OrganizationId] = None
    entity: Optional[EntityId] = None
    role: str = ""
    title: str = ""
    description: str = ""
    location: Optional[LocationId] = None
    location_type: str = ""
    start_date: str = ""
    end_date: str = ""
    status: EmploymentStatus = EmploymentStatus.ACTIVE
    contract_type: EmploymentContractType = EmploymentContractType.FULL_TIME

    semantic_type: Literal["EMPLOYMENT_ROLE"] = "EMPLOYMENT_ROLE"
