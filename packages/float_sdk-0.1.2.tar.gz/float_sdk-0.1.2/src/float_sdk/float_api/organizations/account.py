#!/usr/bin/env python
# pyright: basic

"""
Bank Account Info

"""

import datetime as dt
from datetime import date
from enum import Enum
from typing import List, Literal, Optional

from pydantic import Field, computed_field

from float_sdk.float_api.api.reflection import unopt
from float_sdk.float_api.api.resource import NamedResourceModel, unpack_resource_id
from float_sdk.float_api.base.references import ApplicationId, CurrencyId, EntityId, OrganizationId, PersonId, StrategyId, TradingAccountId
from float_sdk.float_api.organizations.legal import EntityModel
from float_sdk.float_api.organizations.party_role import PartyRole
from float_sdk.float_api.organizations.people import ApplicationModel, PersonModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class AccountClassification(Enum):
    ASSET = "ASSET"
    EQUITY = "EQUITY"
    EXPENSE = "EXPENSE"
    LIABILITY = "LIABILITY"
    REVENUE = "REVENUE"


class AccountType(Enum):
    ## Asset

    BANK = "BANK"
    CURRENT_ASSET = "CURRENT_ASSET"
    FIXED_ASSET = "FIXED_ASSET"
    OTHER_ASSET = "OTHER_ASSET"
    ACCOUNTS_RECEIVABLE = "ACCOUNTS_RECEIVABLE"

    ## Equity

    EQUITY = "EQUITY"

    ## Expense

    EXPENSE = "EXPENSE"
    COST_OF_GOODS_SOLD = "COST_OF_GOODS_SOLD"

    ## Liability

    ACCOUNTS_PAYABLE = "ACCOUNTS_PAYABLE"
    CREDIT_CARD = "CREDIT_CARD"

    ## Revenue

    INCOME = "INCOME"


class BankAccountSubType(Enum):
    CASH_ON_HAND = "CASH_ON_HAND"
    CHECKING = "CHECKING"
    SAVING = "SAVINGS"


class AccountStatus(Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    SUSPENDED = "SUSPENDED"


class BeneficiaryType(Enum):
    """
    Beneficiary Types"""

    OWNER = "OWNER"
    PRIMARY = "PRIMARY"
    CONTINGENT = "CONTINGENT"


class BeneficiaryRelationship(Enum):
    """
    Beneficiary Relationship

    Relationship of a given beneficiary to the account owner
    """

    SPOUSE = "SPOUSE"
    CHILD = "CHILD"
    RELATIVE = "RELATIVE"


class AccountBeneficiaryModel(NamedResourceModel):
    beneficiary: EntityId | str | None = Field(default=None, title="Beneficiary", description="Beneficiary entity")
    beneficiary_type: BeneficiaryType = Field(title="Beneficiary Type", description="Type of beneficiary")
    relationship: Optional[BeneficiaryRelationship] = Field(
        default=None, title="Relationship", description="Relationship of the beneficiary to the account owner"
    )

    semantic_type: Literal["ACCOUNT_BENEFICIARY"] = "ACCOUNT_BENEFICIARY"


class AccountModel(NamedResourceModel):
    short_code: Optional[str] = Field(default=None, title="Short Code", description="Short code for the account which is unique to this organization")
    currency: CurrencyId | str = Field(..., title="Currency", description="Currency of the account")
    status: AccountStatus = Field(default=AccountStatus.OPEN, title="Status", description="Status of the account")
    organization: OrganizationId | str | None = Field(default=None, title="Organization", description="Organization of the account")

    classification: AccountClassification | None = Field(
        default=None, title="Account Classification", description="Accounting classification (typically ASSET for trading accounts per ASC 320)"
    )
    type: AccountType | None = Field(
        default=None, title="Account Type", description="Account type (typically CURRENT_ASSET for trading securities per ASC 320)"
    )


class AccountPartyModel(DataModel):
    """
    Party associated with a trading account.

    Defines relationships between the trading account and entities:
    - COUNTERPARTY: The client entity this account is set up for (required)
    - PRIME_BROKER: The prime broker for give-up accounts (optional)
    - CLEARING_ORGANIZATION: The CCP/clearer (optional)
    - CUSTODIAN: The custodian (optional)
    """

    entity: EntityId | str | EntityModel = Field(..., title="Entity", description="The legal entity associated with this account relationship")
    role: PartyRole = Field(..., title="Role", description="The role of this party (COUNTERPARTY, PRIME_BROKER, etc.)")

    semantic_type: Literal["ACCOUNT_PARTY"] = "ACCOUNT_PARTY"

    # Audit fields
    created_time: dt.datetime | None = Field(default=None, title="Created Time", description="Time the account was created (UTC).")
    created_by: PersonId | str | PersonModel | ApplicationId | ApplicationModel | None = Field(
        default=None, title="Created By", description="The person or application who created the account."
    )


class BankAccountModel(AccountModel):
    sub_type: BankAccountSubType | None = Field(default=None, title="Sub Type", description="Sub type of the account")
    account_number: str = Field(..., title="Account Number", description="Account number of the account")
    routing_code: str = Field(..., title="Routing Code", description="Routing code of the account")
    entity: EntityId | str | None = Field(default=None, title="Entity", description="Entity of the account")
    opened: date | None = Field(default=None, title="Opened", description="Date the account was opened")
    beneficiaries: List[AccountBeneficiaryModel] | None = Field(default=None, title="Beneficiaries", description="Beneficiaries of the account")

    semantic_type: Literal["BANK_ACCOUNT"] = "BANK_ACCOUNT"


class TradingAccountModel(AccountModel):
    __uri_path__ = "accounts/trading"
    __resource_id__ = TradingAccountId

    currency: CurrencyId | str | None = Field(default=None, title="Currency", description="Currency of the trading account")

    strategies: List[StrategyId | str] | None = Field(default=None, title="Strategies", description="Strategies associated with this account.")
    parties: List[AccountPartyModel] | None = Field(
        default=None, title="Parties", description="Entities associated with this account and their roles (e.g., counterparty, prime broker)"
    )
    semantic_type: Literal["TRADING_ACCOUNT"] = "TRADING_ACCOUNT"

    @computed_field
    @property
    def counterparty(self) -> EntityId | str | EntityModel | None:
        return self.get_party_entity_id(PartyRole.COUNTERPARTY)

    @computed_field
    @property
    def executing_broker(self) -> EntityId | str | EntityModel | None:
        return self.get_party_entity_id(PartyRole.EXECUTING_BROKER)

    @computed_field
    @property
    def executing_broker_id(self) -> str | None:
        return unpack_resource_id(self.executing_broker) if self.executing_broker else None

    @computed_field
    @property
    def prime_broker(self) -> EntityId | str | EntityModel | None:
        return self.get_party_entity_id(PartyRole.PRIME_BROKER)

    @computed_field
    @property
    def is_prime_broker_giveup(self) -> bool:
        """
        Check if this is a prime broker give-up account.
        Determined by presence of a PRIME_BROKER party.
        """
        return self.prime_broker is not None

    @computed_field
    @property
    def counterparty_id(self) -> str | None:
        return unpack_resource_id(self.counterparty) if self.counterparty else None

    @computed_field
    @property
    def prime_broker_id(self) -> str | None:
        return unpack_resource_id(self.prime_broker) if self.prime_broker else None

    def get_party(self, party_role: PartyRole) -> AccountPartyModel | None:
        if not self.parties:
            return None
        for party in self.parties:
            if party.role == party_role:
                return party
        return None

    def get_party_entity_id(self, party_role: PartyRole) -> EntityId | str | EntityModel | None:
        party = self.get_party(party_role)
        if party is not None:
            return party.entity
        else:
            return None

    def add_party_entity(self, party_role: PartyRole, entity_id: EntityId) -> None:
        party = self.get_party_by_entity_id_and_role(unopt(entity_id.id), party_role)
        if party is not None:
            return
        else:
            if self.parties is None:
                self.parties = []
            self.parties.append(AccountPartyModel(entity=entity_id, role=party_role))

    def get_party_id(self, party_role: PartyRole) -> str | None:
        party = self.get_party(party_role)
        if party is not None:
            return unpack_resource_id(party.entity)

    def get_party_by_entity_id_and_role(self, party_entity_id: str, party_role: PartyRole) -> AccountPartyModel | None:
        if not self.parties:
            return None
        for party in self.parties:
            if unpack_resource_id(party.entity) == party_entity_id and party.role == party_role:
                return party
        return None

    class Config:
        json_schema_extra = {
            "title": "Trading Account",
            "description": "A trading account used to record trades with specific counterparties. Under GAAP (ASC 320), trading positions are marked to market and classified as current assets.",
            "example": {
                "name": "Hedge Fund Alpha Account",
                "description": "GS trading account for Hedge Fund Alpha",
                "classification": "ASSET",
                "type": "CURRENT_ASSET",
                "status": "OPEN",
                "currency": "USD",
                "organization": "gs_org_id",
                "parties": [{"entity": "hedge_fund_alpha_entity_id", "role": "COUNTERPARTY"}],
                "semanticType": "TRADING_ACCOUNT",
            },
        }

    @property
    def resource_id(self) -> TradingAccountId:
        return TradingAccountId(id=self.id, version=self.version, name=self.name)
