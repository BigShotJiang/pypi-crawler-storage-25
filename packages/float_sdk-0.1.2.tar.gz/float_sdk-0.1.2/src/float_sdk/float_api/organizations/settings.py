# pyright: basic
#!/usr/bin/env python

"""
Organization Settings Models

Settings and configuration for organizations.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.base.references import OrganizationId
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class ConfirmationSettingsModel(DataModel):
    """
    Confirmation Settings

    Settings for trade confirmation document generation and processing.
    """

    document_name_mask: str | None = Field(
        default=None,
        description="Template mask for naming confirmation documents. Supports variable substitution for dynamic naming.",
    )

    semantic_type: Literal["CONFIRMATION_SETTINGS"] = "CONFIRMATION_SETTINGS"


class OrganizationSettingsModel(ResourceModel):
    """
    Organization Settings

    Configuration and preferences for an organization. These settings control
    various aspects of organization behavior including document generation,
    workflow preferences, and system defaults.

    Note: OrganizationSettings is a sub-resource scoped to an organization.
    Use OrganizationSettingsManager for CRUD operations instead of the generic
    Resource save_async/get_async/delete_async methods.
    """

    organization: OrganizationId | str = Field(..., description="Identifier of the organization these settings belong to.")
    confirmation: ConfirmationSettingsModel | None = Field(
        default=None,
        description="Settings for trade confirmation generation and processing.",
    )

    semantic_type: Literal["ORGANIZATION_SETTINGS"] = "ORGANIZATION_SETTINGS"
