# pyright: basic
from enum import Enum


class PartyRole(Enum):
    """
    Party Role
    The set of defined roles to which can be parties (e.g. legal entities) can be
    ascribed for a given transaction. If the party role is counterparty, each of
    the counterparties will also have a counterparty role (e.g. PARTY_1 or PARTY_2)
    Attributes
    ----------
    ALLOCATION_AGENT : The organization responsible for managing allocation schemes and supplying
        allocations for a trade which will be allocated to multiple accounts / entities (funds).
    ARRANGING_BROKER : TThe organization that arranged the trade, i.e. brought together the counterparties.
        Synonyms: Inter-dealer broker, agent."
    BOOKING_PARTY : The entity for which the organization supporting the trade's processing has booked
        and recorded the trade. This is used in non-reporting workflows situations in which the trade
        doesn't need to be reported but a firm still wants to specify their own side.
    CALCULATION_AGENT_INDEPENDENT : Specifies the party responsible for performing calculation agent
        duties as defined in the applicable product definition.
    CLEARING_FIRM : Organization that submits the trade to a clearing house on behalf of
        the counterparties. Synonyms: Futures Commission Merchant (FCM), Clearing Broker,
        Clearing Member Firm. Some implementations use 'Clearing Broker' as synonym."
    CLEARING_ORGANIZATION : The organization that acts as a central counterparty to clear
        a derivatives contract.  This is used to represent the role of Central Counterparties
        (CCPs) or Derivative Clearing Organizations (DCOs).  Sometimes called 'ClearingService'.
        Some implementations also use the term 'Clearer'.
    CONFIRMATION_PLATFORM : Organization serving as a financial intermediary for the purposes of
        electronic confirmation or providing services for post-processing of transactional data.
    COUNTER_PARTY_AFFILIATE : Organization officially attached to the counterparty. e.g. partner, branch,
        subsidiary, or orther legal affiliate.
    COUNTER_PARTY_ULTIMATE_PARENT : The topmost entity or organization, within the corporate hierarchy,
        which is ultimately responsible for the reporting party.
    COUNTERPARTY : A counterparty to the transaction, who will take on market, credit
        or other economic risk as part of the contract.
    CUSTODIAN : Organization that maintains custody of the asset represented by the trade on behalf of
        the owner or counterparty.
    DOCUMENT_REPOSITORY : The organization which provides a central repository for the documents
        associated with the transaction, for example master agreements, CSA agreements, confirms, etc.
    EXECUTING_BROKER : The (generally sell-side) organization that executed the trade; which is usually
        the price-making party, or PARTY_2 in the event of a transaction initiated by the buy-side.
    EXECUTION_FACILITY The facility, exchange, or market where the transaction was executed.
        Synonym: Swap Execution Facility, Designated Contract Market, Execution Venue.
    PRIME_BROKER : The organization that takes on or took on the credit risk for this trade by stepping
        in between the two economic parties (without a central counterparty clearing mechanism).
    SETTLEMENT_AGENT : The organization that makes or receives payments on behalf of the counterparties.
    EXECUTING_ENTITY : Entity executing the transaction. If the transaction is executed directly by the
        reporting party, it will be the reporting party. If it is executed by an execution agent or an
        affiliated party on behalf of the reporting party, it will be that affiliate or agent.
    """

    ALLOCATION_AGENT = "ALLOCATION_AGENT"
    ARRANGING_BROKER = "ARRANGING_BROKER"
    BOOKING_PARTY = "BOOKING_PARTY"
    CALCULATION_AGENT_INDEPENDENT = "CALCULATION_AGENT_INDEPENDENT"
    CLEARING_FIRM = "CLEARING_FIRM"
    CLEARING_ORGANIZATION = "CLEARING_ORGANIZATION"
    CONFIRMATION_PLATFORM = "CONFIRMATION_PLATFORM"
    COUNTER_PARTY_AFFILIATE = "COUNTER_PARTY_AFFILIATE"
    COUNTER_PARTY_ULTIMATE_PARENT = "COUNTER_PARTY_ULTIMATE_PARENT"
    COUNTERPARTY = "COUNTERPARTY"
    CUSTODIAN = "CUSTODIAN"
    DOCUMENT_REPOSITORY = "DOCUMENT_REPOSITORY"
    EXECUTING_BROKER = "EXECUTING_BROKER"
    EXECUTION_FACILITY = "EXECUTION_FACILITY"
    PRIME_BROKER = "PRIME_BROKER"
    SETTLEMENT_AGENT = "SETTLEMENT_AGENT"
    EXECUTING_ENTITY = "EXECUTING_ENTITY"
