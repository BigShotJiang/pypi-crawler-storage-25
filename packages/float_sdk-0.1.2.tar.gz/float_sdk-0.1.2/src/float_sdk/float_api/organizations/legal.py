#!/usr/bin/env python
# pyright: basic

"""
Legal Entities

"""

from enum import Enum
from typing import List, Literal, Optional, Union

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceIdentifierModel, ResourceModel
from float_sdk.float_api.base.references import EntityId, GroupId, JurisdictionId, LocationId, OrganizationId
from float_sdk.float_api.locations.location import LocationModel
from float_sdk.float_api.organizations.organization import OrganizationType
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"

FLOAT_LEGAL_ENTITY_ID = "2549003ZKU3OLGAQT765"
GS_GROUP_LEGAL_ENTITY_ID = "784F5XWPLTWKTBV3E584"


class EntityType(Enum):
    """
    Entity Type

    Defines the possible structures for legal entities, which vary by region.
    """

    NATURAL_PERSON = "PERSON"
    SOLE_PROPRIETORSHIP = "SOLE_PROPRIETORSHIP"
    PARTNERSHIP = "PARTNERSHIP"
    LLC = "LLC"
    PLC = "PLC"
    CORPORATION = "CORPORATION"
    S_CORPORATION = "S_CORPORATION"
    NON_PROFIT = "NON_PROFIT"


class EntityStatus(Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class EntityIdentifierType(Enum):
    FLOAT_ID = "FLOAT_ID"
    LEI = "LEI"
    EIN = "EIN"
    SP_GLOBAL_ID = "SPC"
    MIC_CODE = "MIC"
    BIC_CODE = "BIC"
    REG_CODE = "REG"


class EntityIdentifier(ResourceIdentifierModel):
    type: Optional[EntityIdentifierType] = None

    semantic_type: Literal["ENTITY_IDENTIFIER"] = "ENTITY_IDENTIFIER"


class EntityLocationType(Enum):
    LEGAL = "LEGAL"
    HEADQUARTERS = "HEADQUARTERS"


class EntityLocationModel(DataModel):
    type: EntityLocationType = EntityLocationType.HEADQUARTERS
    location: Optional[Union[LocationId, str, LocationModel]] = None

    semantic_type: Literal["ENTITY_LOCATION"] = "ENTITY_LOCATION"


class LegalEntityModel(ResourceModel):
    """
    Legal Entity

    Legal person or structure that is organized under the laws of any jurisdiction.

    Examples of eligible entities include, without limitation:

    * All financial intermediaries
    * Banks and finance companies
    * All entities that issue equity, debt or other securities for other capital structures
    * All entities listed on an exchange
    * Al entities that trade stock or debt, investment vehicles, including mutual funds, pension funds
      and alternative investment vehicles constituted as corporate entities or collective investment
      agreements (including umbrella funds, as well as funds under an umbrella structure,
      hedge funds, private equity funds, etc.),
    * All entities under the purview of a financial regulator and their affiliates, subsidiaries
      and holding companies
    * Counterparties to financial transactions.

    """

    legal_type: Optional[EntityType] = None


class EntityModel(LegalEntityModel):
    name: str = ""
    description: str | None = None
    short_code: str | None = None
    type: OrganizationType | None = None
    organization: Optional[Union[OrganizationId, str]] = Field(default=None, description="Identifier of organization which owns this entity.")
    locations: Optional[List[EntityLocationModel]] = Field(default=None, description="List of entity locations.")
    jurisdiction: Optional[Union[JurisdictionId, str]] = Field(default=None, description="Jurisdiction in which the entity is registered.")
    parent: Optional[Union[EntityId, str]] = Field(default=None, description="Identifier of parent entity (if applicable)")
    ultimate_parent: Optional[EntityId] = Field(default=None, description="Identifier of ultimate or top level parent entity (if applicable)")
    status: Optional[EntityStatus] = Field(EntityStatus.ACTIVE, description="Indicates whether the entity is still in active use.")
    identifiers: Optional[List[EntityIdentifier]] = Field(default=None, description="List of alternative identifiers for this entity.")
    group: GroupId | str | None = Field(default=None, title="Group", description="Group to specify access level for this user")

    semantic_type: Literal["ENTITY"] = "ENTITY"

    @property
    def resource_id(self) -> EntityId:
        return EntityId(id=self.id, name=self.name)

    def get_lei(self) -> str | None:
        all_leis = [identifier.value for identifier in self.identifiers or [] if identifier.type == EntityIdentifierType.LEI and identifier.value is not None]
        if len(all_leis) > 1:
            raise ValueError(f"Entity {self.id} has multiple LEIs: {all_leis}")
        if len(all_leis) == 0:
            return None
        return all_leis[0]

    @property
    def lei(self) -> str | None:
        return self.get_lei()
