#!/usr/bin/env python
# pyright: basic

"""
People and Network

"""

import re
from abc import ABC, abstractmethod
from datetime import date
from enum import Enum
from typing import Final, List, Literal, Optional, Union

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel, ResourceIdentifierModel, ResourceModel
from float_sdk.float_api.base.references import ApplicationId, ContactId, EntityId, GroupId, LocationId, OrganizationId, PersonId
from float_sdk.float_api.locations.location import LocationModel
from float_sdk.float_api.organizations.contact import ContactInfoModel
from float_sdk.float_api.organizations.legal import EntityModel, LegalEntityModel
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class ContactType(Enum):
    CONFIRMATION = "CONFIRMATION"
    AFFIRMATION = "AFFIRMATION"
    EMAIL = "EMAIL"


class ContactModel(NamedResourceModel):
    """
    Provides contact information for a person or orgainzation.
    """

    __resource_id__ = ContactId
    __uri_path__ = "collaboration/contacts"

    organization: OrganizationId | str | OrganizationModel | None = Field(default=None, description="Organization who manages this contact information.")
    entity: EntityId | str | EntityModel | None = Field(default=None, description="Entity which owns the contact.")
    group: GroupId | str | None = Field(
        default=None, description="Group which defines visibility for the contact (optional, defaults to organization visibility)."
    )

    contact_info: ContactInfoModel | None = Field(default=None, description="Contact information.")
    contact_type: ContactType | None = Field(default=None, description="The type of communication this contact is used for.")

    semantic_type: Literal["CONTACT"] = "CONTACT"


class PersonIdentifierType(Enum):
    """
    Various identifier types for a person.
    """

    EMAIL = "EMAIL"
    OKTA_ID = "OKTA_ID"
    PERSON_ID = "PERSON_ID"


class PersonIdentifier(ResourceIdentifierModel):
    semantic_type: Literal["PERSON_IDENTIFIER"] = "PERSON_IDENTIFIER"

    type: Optional[PersonIdentifierType] = Field(default=None, description="Type of identifier, e.g. SSN.")


class PersonModel(LegalEntityModel):
    username: str = Field(..., description="Unique username for the person, which is usually corporate email address.")
    name: str | None = Field(default=None, description="Full name of person.")
    honorific: str | None = Field(default=None, description="Title of individual, e.g. Mr, Mrs, Dr, etc.")
    first_name: str | None = Field(default=None, description="First name of person.")
    middle_name: str | None = Field(default=None, description="Middle name of person.")
    initial: str | None = Field(default=None, description="Initial of person.")
    last_name: str | None = Field(default=None, description="Last name of person")
    suffix: str | None = Field(default=None, description="Name suffix, for example: Jr or II")
    bio: str | None = Field(
        default=None,
        description="Biography of the person which provides details of their professional background and experience.",
    )

    date_of_birth: date | None = Field(default=None, description="Date of birth. ")
    contact_info: ContactInfoModel | None = Field(default=None, description="Contact information for person.")
    identifiers: List[PersonIdentifier] | None = Field(default=None, description="Other identifiers associated with the person.")
    organization: OrganizationId | str | None = Field(default=None, description="Primary organization of this user.")

    group: GroupId | str | None = Field(default=None, title="Group", description="Group to specify access level for this user")
    location: LocationId | str | LocationModel | None = Field(default=None, description="Location of the user within the primary organization.")

    semantic_type: Literal["PERSON"] = "PERSON"

    @classmethod
    def init_forward_hints(cls) -> dict[str, type]:
        return {"GroupModel": GroupModel}

    @property
    def resource_id(self) -> PersonId:
        return PersonId(id=self.id, version=self.version, name=self.name)

    @property
    def email(self) -> str | None:
        # 1. Check PersonIdentifiers with type EMAIL
        if self.identifiers:
            for identifier in self.identifiers:
                if identifier.type == PersonIdentifierType.EMAIL and identifier.value:
                    return identifier.value

        # 2. Check if username matches email regex
        email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if re.match(email_pattern, self.username):
            return self.username

        # 3. Check contactInfo email
        if self.contact_info and self.contact_info.emails:
            for email_obj in self.contact_info.emails:
                if email_obj.address:
                    return email_obj.address

        return None

    @property
    def context(self) -> str:
        return f"""Name: {self.name}"""


class ApplicationIdentifierType(Enum):
    """
    Identifier types for developer applications.
    """

    OKTA_ID = "OKTA_ID"


class ApplicationIdentifier(ResourceIdentifierModel):
    """
    Additional identifiers for a developer application.
    """

    semantic_type: Literal["APPLICATION_IDENTIFIER"] = "APPLICATION_IDENTIFIER"

    type: Optional[ApplicationIdentifierType] = None


class ApplicationModel(NamedResourceModel):
    """
    A developer application manages an API key, a unique identifier provided to allow
    developers to access and utilize the Float application programming interfaces (APIs).

    It serves as a form of authentication, allowing developers to make authorized requests to
    the provider's services or data. API keys enable developers to integrate third-party
    functionality into their own applications, facilitating interoperability and extending the
    capabilities of their software. Applications are identities which can be entitled to
    various capabilities within an organization through role or entitlement assignment.
    """

    client_id: str | None = Field(
        None,
        description="Client id is a unique identifier assigned to a client application by a server, typically used for authentication and authorization purposes in client-server communication protocols such as OAuth.",
    )
    client_secret: str | None = Field(
        None,
        description="A client secret is a confidential piece of information, such as a password or cryptographic key, used by a client application to authenticate itself to a server and establish a secure connection during communication protocols like OAuth.",
    )
    owner: Optional[Union[PersonId, str]] = Field(default=None, description="Person who owns this application account.")
    organization: Optional[Union[OrganizationId, str]] = Field(default=None, description="Organization which owns this application account.")
    group: GroupId | str | None = Field(default=None, title="Group", description="Group to specify access level for this application")
    identifiers: Optional[List[ApplicationIdentifier]] = Field(default=None, description="Additional identifiers for the application.")

    semantic_type: Literal["APPLICATION"] = "APPLICATION"

    @classmethod
    def init_forward_hints(cls) -> dict[str, type]:
        return {"GroupModel": GroupModel}

    @property
    def resource_id(self) -> ApplicationId:
        return ApplicationId(id=self.id, version=self.version, name=self.name)


class GroupType(Enum):
    """
    Classification of a group, which can be used to organize users (people or applications) into logical teams
    or memebership groups in order to define shared capabilities and entitlements.
    """

    FLOAT_MEMBERSHIP = "FLOAT_MEMBERSHIP"
    ORGANIZATION_MEMBERSHIP = "ORGANIZATION_MEMBERSHIP"
    ORGANIZATION_TEAM = "ORGANIZATION_TEAM"


class GroupModel(NamedResourceModel):
    """
    Groups are used to organize users (people or applications) into logical teams
    or memebership groups in order to define shared capabilities and entitlements.
    """

    organization: OrganizationId | str | None = Field(default=None, description="Identifier of organization which owns this group.")
    type: GroupType = Field(..., description="Type of group, which determines membership rules.")
    short_name: str | None = Field(default=None, description="The short name associated with this group.")
    people: List[PersonModel] | None = Field(default=None, title="People", description="List of people who are members of the group.")
    contacts: list[ContactId | str | ContactModel] | None = Field(default=None, title="Contacts", description="Contact information associated with this group.")

    semantic_type: Literal["GROUP"] = "GROUP"

    @property
    def resource_id(self) -> GroupId:
        return GroupId(
            id=self.id,
            version=self.version,
            name=self.name,
        )


class MembershipStatus(Enum):
    """
    Defines the status of membership within a group or organization. Users can
    request membership, or be invited to join groups, which can be approved or
    declined.
    """

    INVITED = "INVITED"
    JOINED = "JOINED"
    DECLINED = "DECLINED"


class PlatformGroups(Enum):
    FLOAT_PLATFORM_MEMBERS = "FLOAT_PLATFORM_MEMBERS"


class PlatformRole(Enum):
    """
    Defines the roles which a user can have with respect to the Float platform.
    """

    # Platform level roles for users

    FLOAT_ADMIN = "FLOAT_ADMIN"
    FLOAT_MEMBER = "FLOAT_MEMBER"
    FLOAT_COVERAGE = "FLOAT_COVERAGE"

    # Platform level roles for applications

    FLOAT_APPLICATION = "FLOAT_APPLICATION"
    FLOAT_ADMIN_APPLICATION = "FLOAT_ADMIN_APPLICATION"


COVERAGE_ROLES: Final = [PlatformRole.FLOAT_COVERAGE, PlatformRole.FLOAT_ADMIN]


class OrganizationPersonRole(Enum):
    """
    Defines the roles which a user can have with respect to an organization.
    """

    ORGANIZATION_ADMIN = "ORGANIZATION_ADMIN"
    ORGANIZATION_MEMBER = "ORGANIZATION_MEMBER"
    ORGANIZATION_TRADER = "ORGANIZATION_TRADER"
    ORGANIZATION_FUND_ADMIN = "ORGANIZATION_FUND_ADMIN"
    ORGANIZATION_DEVELOPER = "ORGANIZATION_DEVELOPER"
    ORGANIZATION_DOCUMENTATION = "ORGANIZATION_DOCUMENTATION"
    ORGANIZATION_SUPPORT = "ORGANIZATION_SUPPORT"


class OrganizationPersonCoverageRole(Enum):
    ORGANIZATION_SALES_COVERAGE = "ORGANIZATION_SALES_COVERAGE"


class OrganizationApplicationRole(Enum):
    VIEW_ONLY = "VIEW_ONLY"
    READ_WRITE = "READ_WRITE"
    AI_AGENT = "AI_AGENT"


class TeamRole(Enum):
    TEAM_ADMIN = "TEAM_ADMIN"
    TEAM_MEMBER = "TEAM_MEMBER"


GroupValidRoles = Union[
    PlatformRole,
    OrganizationPersonRole,
    OrganizationPersonCoverageRole,  # Coverage can view org but not join
    OrganizationApplicationRole,
    TeamRole,
]

# Deprecated: Use specific role types (GroupValidRoles, ConversationMemberRole, etc.) instead
ValidMembershipRoles = GroupValidRoles


class UserMembershipModel(ResourceModel):
    pass


class PersonMembershipModel(UserMembershipModel):
    person: Union[PersonId, PersonModel, str] = Field(..., title="Person", description="The unique identifier of the person who is a member of the group.")
    role: OrganizationPersonRole | OrganizationPersonCoverageRole | PlatformRole = Field(
        ...,
        title="Role",
        description="The assigned role of the user within this group, which defines resource entitlement policies.",
    )
    send_welcome_email: bool | None = Field(default=True, title="Send Welcome Email", description="Send a welcome email when inviting a person to a group")

    @property
    def user(self) -> Union[PersonId, PersonModel, str]:
        return self.person

    @property
    def user_id(self) -> str | None:
        return self.person if isinstance(self.person, str) else self.person.id

    @user.setter
    def user(self, user: Union[PersonId, PersonModel]):
        self.person = user


class ApplicationMembershipModel(UserMembershipModel):
    application: Union[ApplicationId, ApplicationModel, str] = Field(
        ...,
        title="Application",
        description="The unique identifier of the developer application which is a member of the group.",
    )
    role: OrganizationApplicationRole | PlatformRole = Field(
        ...,
        title="Role",
        description="The assigned role of the application within this group, which defines resource entitlement policies.",
    )

    @property
    def user(self) -> Union[ApplicationId, ApplicationModel, str]:
        return self.application

    @property
    def user_id(self) -> str | None:
        return self.application if isinstance(self.application, str) else self.application.id

    @user.setter
    def user(self, user: Union[ApplicationId, ApplicationModel]):
        self.application = user


class UserType(Enum):
    PERSON = "PERSON"
    APPLICATION = "APPLICATION"


class BaseMembershipModel(DataModel, ABC):
    """
    Base model for membership in groups and conversations.
    Provides common fields for tracking user/application membership.
    """

    person: PersonId | PersonModel | None = Field(default=None, title="Person", description="The unique identifier of the person who is a member.")
    application: ApplicationId | ApplicationModel | None = Field(
        default=None,
        title="Application",
        description="The unique identifier of the developer application which is a member.",
    )
    type: UserType | None = Field(default=None, title="Type", description="The type of user (person or application).")
    organization: OrganizationId | None = Field(default=None, title="Organization", description="The organization to which the membership belongs.")
    status: MembershipStatus = Field(..., title="Status", description="The status of the membership request.")

    @property
    @abstractmethod
    def target_resource(self) -> str:
        """The field name in the membership model that references the parent resource (e.g., 'conversation', 'group')"""
        ...


class GroupMembershipModel(PersonMembershipModel, BaseMembershipModel):
    person: PersonId | PersonModel | None = Field(default=None, title="Person", description="The unique identifier of the person who is a member of the group.")
    application: ApplicationId | ApplicationModel | None = Field(
        default=None,
        title="Application",
        description="The unique identifier of the developer application which is a member of the group.",
    )
    type: UserType | None = Field(default=None, title="Type", description="The type of user (person or application).")
    role: GroupValidRoles = Field(
        ...,
        title="Role",
        description="The assigned role of the user within this group, which defines resource entitlement policies.",
    )
    organization: OrganizationId | None = Field(default=None, title="Organization", description="The organization to which the group membership belongs.")
    group: GroupId | str | GroupModel = Field(
        ...,
        title="Group",
        description="The unique iedntifier of the group to which this membership subscription applies.",
    )
    status: MembershipStatus = Field(..., title="Status", description="The status of the membership request.")

    semantic_type: Literal["GROUP_MEMBERSHIP"] = "GROUP_MEMBERSHIP"

    @property
    def target_resource(self) -> str:
        return "group"

    @property
    def user(self) -> ApplicationId | ApplicationModel | PersonId | PersonModel | None:
        return self.application if self.type == UserType.APPLICATION else self.person

    @user.setter
    def user(self, user: PersonId | PersonModel | ApplicationId | ApplicationModel):
        if isinstance(user, PersonModel) or isinstance(user, PersonId):
            self.type = UserType.PERSON
            self.person = user
        elif isinstance(user, ApplicationModel) or isinstance(user, ApplicationId):
            self.type = UserType.APPLICATION
            self.application = user
        else:
            raise Exception(f"Attempting to set group membership with invalid type: {type(user)}")

    @property
    def external(self) -> PersonMembershipModel | ApplicationMembershipModel:
        if self.type == UserType.APPLICATION:
            if not self.application:
                raise Exception(f"Application is not set on membership: {self.id}")

            if self.role in PlatformRole:
                role = PlatformRole(self.role)
            elif self.role in OrganizationApplicationRole:
                role = OrganizationApplicationRole(self.role)
            else:
                raise Exception(f"Invalid role {self.role} on membership: {self.id}")

            return ApplicationMembershipModel(id=self.id, version=self.version, application=self.application, role=role)
        else:
            if not self.person:
                raise Exception(f"Person is not set on membership: {self.id}")

            if self.role in PlatformRole:
                role = PlatformRole(self.role)
            elif self.role in OrganizationPersonRole:
                role = OrganizationPersonRole(self.role)
            elif self.role in OrganizationPersonCoverageRole:
                role = OrganizationPersonCoverageRole(self.role)
            else:
                raise Exception(f"Invalid role {self.role} on membership: {self.id}")

            return PersonMembershipModel(id=self.id, version=self.version, person=self.person, role=role)


class MemberInviteModel(DataModel):
    emails: List[str]
    role: OrganizationPersonRole | OrganizationPersonCoverageRole

    semantic_type: Literal["MEMBER_INVITE"] = "MEMBER_INVITE"


class OrganizationMembershipStatusModel(DataModel):
    memberships: List[GroupMembershipModel] = Field(..., title="Memberships", description="List of all valid organization memberships for this user")
    current_organization: OrganizationId | str | None = Field(
        default=None, title="Current Organization", description="The organization into which the authenticated user has switched."
    )
    coverage_mode: bool = Field(default=False, title="Coverage Mode", description="Is coverage mode (all organizations) enabled")
    impersonate: PersonId | str | None = Field(default=None, title="Impersonate", description="Person ID being impersonated by the authenticated user, if any")
    authenticated_user: PersonId | str | None = Field(
        default=None, title="Authenticated User", description="The authenticated user ID (always populated, same as user ID when not impersonating)"
    )


class PersonPreferencesModel(DataModel): ...
