# pyright: basic
#!/usr/bin/env python

"""
Contact Information

"""

from enum import Enum
from typing import List, Literal, Optional, Union

from pydantic import Field

from float_sdk.float_api.base.references import CountryId, EntityId
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class AddressModel(DataModel):
    """
    Address

    The address of an organization or individual.
    """

    attention: Optional[str] = Field(default=None, description="A specified individual or department to which to route any requests")
    street: Optional[str] = Field(default=None, description="Address line 1, usually street, PO Box, or similar.")
    apartment: Optional[str] = Field(default=None, description="Address line 2, usually house or apartment number, unit, etc.")
    city: Optional[str] = Field(default=None, description="City, town, village, or equivalent.")
    state: Optional[str] = Field(default=None, description="State, county, province, or administrative region.")
    country: Optional[Union[CountryId, str]] = Field(default=None, description="Country identifier, which is the two letter ISO 3166-1 alpha-2 code.")
    postal_code: Optional[str] = Field(default=None, description="Postal code or ZIP.")

    semantic_type: Literal["CONTACT_ADDRESS"] = "CONTACT_ADDRESS"


class TelephoneType(Enum):
    """
    Telephone Type

    Type of telephone number.
    """

    OFFICE = "OFFICE"
    FAX = "FAX"
    WORK = "WORK"
    MOBILE = "MOBILE"
    SUPPORT = "SUPPORT"


class TelephoneModel(DataModel):
    """
    Telephone

    Encapsulates telephone number and type.
    """

    type: TelephoneType = Field(TelephoneType.WORK, description="Type of the telephone number.")
    number: str = Field(..., description="Full telephone number with international prefix.")

    semantic_type: Literal["CONTACT_TELEPHONE"] = "CONTACT_TELEPHONE"


class EmailType(Enum):
    """
    Email Type

    Type of email address.
    """

    CORPORATE = "CORPORATE"
    PERSONAL = "PERSONAL"


class EmailContactModel(DataModel):
    """
    Email

    Email address, type, and issuer information.
    """

    type: EmailType = Field(default=EmailType.CORPORATE, description="Type of email address.")
    address: str = Field(..., description="Email address, e.g. name@example.com")
    issuing_entity: EntityId | str | None = Field(default=None, description="Identifier of entity which issued this email address.")

    semantic_type: Literal["CONTACT_EMAIL"] = "CONTACT_EMAIL"


class SocialType(Enum):
    """
    Social Type

    Social media handle type.
    """

    LINKEDIN = "LINKEDIN"
    TWITTER = "TWITTER"
    FACEBOOK = "FACEBOOK"
    YOUTUBE = "YOUTUBE"
    INSTAGRAM = "INSTAGRAM"
    SPOTIFY = "SPOTIFY"


class SocialModel(DataModel):
    """
    Social

    Social media handle.
    """

    type: SocialType = Field(SocialType.LINKEDIN, description="Type of social media handle.")
    handle: str | None = Field(default=None, description="The social media handle (unique identifier).")
    issuing_entity: EntityId | str | None = Field(default=None, description="Identifier of entity which issued this email address.")

    semantic_type: Literal["CONTACT_SOCIAL"] = "CONTACT_SOCIAL"


class WebPageType(Enum):
    """
    Web Page Type

    The type of a web page link.
    """

    BUSINESS = "BUSINESS"
    PERSONAL = "PERSONAL"
    SUPPORT = "SUPPORT"
    STATUS = "STATUS"
    RSS = "RSS"
    METHODOLOGY = "METHODOLOGY"


class WebPageModel(DataModel):
    """
    Web Page

    Link to a web page.
    """

    type: WebPageType = Field(WebPageType.BUSINESS, description="Type of web page link.")
    url: str = Field(..., description="Url of webpage.")

    semantic_type: Literal["CONTACT_WEB_PAGE"] = "CONTACT_WEB_PAGE"


class ContactInfoModel(DataModel):
    """
    Contact Info

    Provides contact information for a person or orgainzation.
    """

    addresses: List[AddressModel] | None = Field(default=None, description="List of valid address objects.")
    telephones: List[TelephoneModel] | None = Field(default=None, description="List of telephone number objects.")
    emails: List[EmailContactModel] | None = Field(default=None, description="List of email objects.")
    socials: List[SocialModel] | None = Field(default=None, description="List of social objects.")
    web_pages: List[WebPageModel] | None = Field(default=None, description="List of web page links.")

    semantic_type: Literal["CONTACT_INFO"] = "CONTACT_INFO"
