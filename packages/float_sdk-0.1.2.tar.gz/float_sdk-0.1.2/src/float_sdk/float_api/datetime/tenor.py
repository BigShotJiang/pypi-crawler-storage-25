#!/usr/bin/env python
# pyright: basic

"""
Tenor

Tenor of an instrument

"""

from typing import Literal, Self, cast

from pydantic import Field

from float_sdk.float_api.datetime.schedule import RelativeDatePeriod
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class TenorPeriod(DisplayEnum):
    ON = "ON"
    T = "T"
    D = "D"
    B = "B"
    W = "W"
    M = "M"
    Y = "Y"

    def display_names(self) -> dict[str, str]:
        return {
            "ON": "Overnight",
            "T": "Termination",
            "D": "Days",
            "B": "Business Days",
            "W": "Weeks",
            "M": "Months",
            "Y": "Years",
        }

    def to_relative_date_period(self) -> RelativeDatePeriod:
        """
        Convert TenorPeriod to RelativeDatePeriod.

        ON (overnight) tenor converts to B (business day) period.
        T (termination) has no RelativeDatePeriod equivalent.
        All other periods map directly by value.
        """
        if self == TenorPeriod.ON:
            return RelativeDatePeriod.B
        elif self == TenorPeriod.T:
            raise ValueError("Termination tenor (T) has no RelativeDatePeriod equivalent")
        else:
            return RelativeDatePeriod(self.value)

    @classmethod
    def from_string(cls, value: str) -> Self:
        """
        Parse a tenor period string.

        Handles special cases of "ON" for overnight tenor and "T" for termination tenor.
        """
        if value == "ON":
            return cast(Self, cls.ON)
        elif value == "T":
            return cast(Self, cls.T)
        else:
            return cast(Self, cls(value))


class TenorModel(DataModel):
    """
    Tenor

    Represents a designated maturity period (e.g. 1M, 3M, 6M, 1Y) used to specify the
    term of a floating rate observation per the ISDA 2021 Interest Rate Definitions.
    """

    tenor_period: TenorPeriod = Field(..., title="Tenor Period", description="Specified period for tenor (e.g. days, months, etc.)")
    multiplier: int | None = Field(default=None, title="Multiplier", description="Number of periods, for example 3 months.")
    semantic_type: Literal["DATE_TENOR"] = "DATE_TENOR"

    @property
    def period(self) -> RelativeDatePeriod:
        return self.tenor_period.to_relative_date_period()
