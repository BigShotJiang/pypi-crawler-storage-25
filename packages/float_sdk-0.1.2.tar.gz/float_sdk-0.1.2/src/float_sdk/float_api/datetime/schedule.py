#!/usr/bin/env python
# pyright: basic

"""
Schedules
"""

from abc import ABC
from datetime import date
from enum import Enum
from typing import Literal, Optional, Union

from pydantic import Field

from float_sdk.float_api.base.references import HolidayCalendarId
from float_sdk.float_api.datetime.calendars import HolidayCalendarModel
from float_sdk.float_api.datetime.conventions import BusinessDayConvention
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class BusinessDateModel(DataModel):
    semantic_type: Literal["DATE_BUSINESS"] = "DATE_BUSINESS"

    unadjusted_date: Optional[date] = None
    holiday_calendar: Optional[Union[HolidayCalendarId, HolidayCalendarModel]] = None
    business_day_convention: Optional[BusinessDayConvention] = None


class RelativeDatePeriod(DisplayEnum):
    D = "D"
    B = "B"
    W = "W"
    M = "M"
    Y = "Y"

    def display_names(self) -> dict[str, str]:
        return {
            "D": "Days",
            "B": "Business Days",
            "W": "Weeks",
            "M": "Months",
            "Y": "Years",
        }


class RelativeDateModel(DataModel):
    period: RelativeDatePeriod | None = Field(
        default=None,
        title="Period",
        description="The period definition used for the date offse, for example days (D), business days (B), weeks (W), months (M), years (Y).",
    )
    multiplier: int | None = Field(
        default=None,
        title="Multiplier",
        description="The number of periods which comprise the offset. Three months would have a period of months, and multiplier of 3.",
    )

    semantic_type: Literal["DATE_RELATIVE"] = "DATE_RELATIVE"


class RelativeBusinessDateModel(DataModel):
    semantic_type: Literal["DATE_RELATIVE_BUSINESS"] = "DATE_RELATIVE_BUSINESS"

    relative_date: RelativeDateModel = Field(..., title="Relative Date", description="Relative date offset")
    holiday_calendar: HolidayCalendarModel = Field(..., title="Holiday Calendar", description="Holiday calendar to use for adjustements")
    business_day_convention: BusinessDayConvention | None = Field(
        default=None, title="Business Day Convention", description="Business day convention to use for date adjustment if the date falls on a holiday"
    )


class DateRollRuleModel(DataModel, ABC):
    frequency: RelativeDateModel


class RelativeDateRollModel(DateRollRuleModel):
    semantic_type: Literal["DATE_ROLL_RELATIVE"] = "DATE_ROLL_RELATIVE"


class EndOfMonthDateRollModel(DateRollRuleModel):
    semantic_type: Literal["DATE_ROLL_EOM"] = "DATE_ROLL_EOM"


class DayOfMonthDateRollModel(DateRollRuleModel):
    semantic_type: Literal["DATE_ROLL_DAY_OF_MONTH"] = "DATE_ROLL_DAY_OF_MONTH"
    day_of_month: int | None = Field(default=None, title="Day of Month", description="Day of month to roll per schedule")


class DayOfWeekDateRollModel(DateRollRuleModel):
    semantic_type: Literal["DATE_ROLL_DAY_OF_WEEK"] = "DATE_ROLL_DAY_OF_WEEK"
    day_of_week: int | None = Field(default=None, title="Day of Week", description="Day of week to roll per schedule")


class NthWeekdayDateRollModel(DateRollRuleModel):
    semantic_type: Literal["DATE_ROLL_NTH_WEEKDAY"] = "DATE_ROLL_NTH_WEEKDAY"
    weekday: int | None = Field(default=None, title="Weekday", description="Day of week to roll per schedule")


class IMMDateRollModel(DateRollRuleModel):
    semantic_type: Literal["DATE_ROLL_IMM"] = "DATE_ROLL_IMM"


ValidRollRuleModels = Union[
    RelativeDateRollModel, EndOfMonthDateRollModel, DayOfMonthDateRollModel, DayOfWeekDateRollModel, NthWeekdayDateRollModel, IMMDateRollModel
]


class DateGenerationDirection(Enum):
    """
    Determines the direction in which to generate dates.

    Forwards: Generate dates forward from the unadjusted start date
    Backwards: Generate dates backwards from the unadjusted end date
    """

    FORWARDS = "FORWARDS"
    BACKWARDS = "BACKWARDS"


class ScheduleModel(DataModel):
    """
    Defines rules for schedule generation. Based on these rules, can a schedule of dates can be generated
    which start and end on specified dates, rolling (i.e. creating new period) based on the specified
    roll rules. Holiday calendar is used to adjust dates per the business day convention.
    """

    start_date: date = Field(..., description="Start date for schedule generation (unadjusted, inclusive)")
    end_date: Optional[date] = Field(..., description="End date for schedule generation (unadjusted, inclusive)")
    roll: Optional[Union[RelativeDateModel, ValidRollRuleModels]] = Field(
        None, description="Roll rule, which defines the date on which to start and end regular periods (e.g. end of month)"
    )
    calendar: Optional[Union[HolidayCalendarId, HolidayCalendarModel]] = Field(
        default=None, description="Reference to holiday calendar to use for schedule generation"
    )
    convention: BusinessDayConvention = Field(..., description="Business day convention used to adjust holiday dates.")
    date_generation_direction: DateGenerationDirection = Field(..., description="Defines direction of date generation.")
    first_regular_period_start_date: Optional[date] = Field(default=None, description="Start date of first regular (or non-stub) period.")
    last_regular_period_end_date: Optional[date] = Field(default=None, description="End date of last regular (or non-stub) period.")
    strict_stubs: Optional[bool] = Field(
        True, description="If strict, error if the regular schedule generation does not fall on a roll date. Otherwise will create an interim irregular period."
    )

    semantic_type: Literal["SCHEDULE"] = "SCHEDULE"
