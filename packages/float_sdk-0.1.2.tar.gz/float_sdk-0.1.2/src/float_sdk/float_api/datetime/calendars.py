#!/usr/bin/env python
# pyright: basic
"""
Holiday Calendars

"""

import datetime as dt
from enum import Enum
from typing import Literal, Optional, Union

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import CountryId, HolidayCalendarId
from float_sdk.float_api.serialization.types import TypeModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class HolidayType(Enum):
    PUBLIC = "PUBLIC"  # All individuals and businesses respect holiday
    BANK = "BANK"  # Banks and offices are closed
    SCHOOL = "SCHOOL"  # Schools are closed
    AUTHORITIES = "AUTHORITIES"  # Authorities are closed
    OPTIONAL = "OPTIONAL"  # Many people and businesses elect to take holiday
    OBSERVANCE = "OBSERVANCE"  # No paid holiday, but some may observe


class HolidayModel(NamedResourceModel):
    date: dt.date = Field(..., title="Date", description="Date on which holiday occurs.")
    local_name: Optional[str] = Field(default=None, title="Local Name", description="Local name for the holiday.")
    types: Optional[list[HolidayType]] = Field(default=None, title="Types", description="Hoiday types (public, bank, etc.)")
    country: Optional[Union[str, CountryId]] = Field(default=None, title="Country", description="Country is which the holiday is effective.")
    fixed_date: bool = Field(False, title="Fixed Date", description="Is the holiday on a fixed date each year.")
    all_divisions: Optional[bool] = Field(True, title="All Divisions", description="Does the holiday apply to all subdivisions (e.g. country level)")
    divisions: Optional[list[str]] = Field(default=None, title="Divisions", description="Specific divisions to which the holiday applies.")
    launch_year: Optional[int] = Field(default=None, title="Launch Year", description="Year in which the holiday was launched.")
    calendar: Optional[Union[str, HolidayCalendarId]] = Field(
        default=None, title="Calendar", description="Holiday calendar this holiday belongs to (used for static providers)."
    )

    semantic_type: Literal["HOLIDAY"] = "HOLIDAY"


class HolidayCalendarProviderType(Enum):
    JURISDICTION = "JURISDICTION"
    STATIC = "STATIC"
    HOLIDAYS_PACKAGE = "HOLIDAYS_PACKAGE"


class JurisdictionProvider(TypeModel):
    type: HolidayCalendarProviderType = Field(
        HolidayCalendarProviderType.JURISDICTION, title="Type", description="Holiday calendar provider type (e.g. Jurisdiction, Exchange, etc)"
    )
    jurisdiction: Optional[str] = Field(default=None, title="Jurisdiction", description="Jurisdiction from which to map holidays.")


class StaticProvider(TypeModel):
    type: HolidayCalendarProviderType = Field(
        HolidayCalendarProviderType.STATIC, title="Type", description="Static holiday calendar provider (holidays loaded by calendar ID)."
    )


class HolidaysPackageProvider(TypeModel):
    type: HolidayCalendarProviderType = Field(
        HolidayCalendarProviderType.HOLIDAYS_PACKAGE,
        title="Type",
        description="Holiday calendar provider using the holidays Python package for rule-based generation.",
    )
    country: Optional[str] = Field(default=None, title="Country", description="ISO 3166-1 alpha-2 country code (e.g. 'US', 'GB', 'JP').")
    subdivision: Optional[str] = Field(default=None, title="Subdivision", description="Country subdivision code (e.g. 'NSW', 'ON').")
    categories: Optional[list[str]] = Field(default=None, title="Categories", description="Holiday categories to include (e.g. ['PUBLIC', 'BANK']).")
    financial_market: Optional[str] = Field(
        default=None, title="Financial Market", description="Financial market code (e.g. 'XECB', 'NYSE'). Mutually exclusive with country."
    )


class HolidayCalendarModel(NamedResourceModel):
    __uri_path__ = "calendars"
    __resource_id__ = HolidayCalendarId

    short_name: str | None = Field(default=None, title="Short Name", description="Short name for the index.")
    start_date: Optional[dt.date] = Field(default=None, title="Start Date", description="Start date, or first date from which holidays are available.")
    end_date: Optional[dt.date] = Field(default=None, title="End Date", description="End date, or last date from which holidays are available.")
    weekends: set[int] = Field(
        set(), title="Weekends", description="Weekend mask for holiday specification which defines weekend days per week (indexed from zero on Monday)."
    )
    providers: list[JurisdictionProvider | StaticProvider | HolidaysPackageProvider] = Field(
        [], title="Providers", description="Available holiday calendar providers for this calendar."
    )

    @property
    def resource_id(self) -> HolidayCalendarId:
        return HolidayCalendarId(id=self.id, version=self.version, name=self.name)

    semantic_type: Literal["HOLIDAY_CALENDAR"] = "HOLIDAY_CALENDAR"


class BusinessDayCombinationRule(Enum):
    UNION = "UNION"
    INTERSECTION = "INTERSECTION"
