#!/usr/bin/env python
# pyright: basic

"""
Business day conventions

Conventions for adjusting dates to valid business day per a specified holiday calendar.
"""

from float_sdk.float_api.serialization.model import DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class BusinessDayConvention(DisplayEnum):
    """
    Business day convention

    Convention to adjust a date to a valid business day if it falls on a weekend or
    holiday day per a given holiday calendar.

    Options
    -------
    UNADJUSTED: Days are not adjusted to the business calendar
    FOLLOWING: Days are adjusted to the next business day
    PRECEDING: Days are adjusted to the previous business day
    MODIFIED_FOLLOWING: Days are adjusted to the next business day, unless the day
        falls on the next calendar month, in which case it will be previous business
        day in the same month
    MODIFIED_PRECEDING: Days are adjusted to the previous business day, unless the
        day falls on the previous calendar month, in which case it will be next
        business day in the same month
    NEAREST:
        Days are adjusted to the nearest available business day
    """

    UNADJUSTED = "UNADJUSTED"
    FOLLOWING = "FOLLOWING"
    PRECEDING = "PRECEDING"
    MODIFIED_FOLLOWING = "MODFOLLOWING"
    MODIFIED_PRECEDING = "MODPRECEDING"
    NEAREST = "NEAREST"

    def display_names(self) -> dict[str, str]:
        return {
            "UNADJUSTED": "Unadjusted",
            "FOLLOWING": "Following",
            "PRECEDING": "Preceding",
            "MODIFIED_FOLLOWING": "Modified Following",
            "MODIFIED_PRECEDING": "Modified Preceding",
            "NEAREST": "Nearest",
        }


class DayCountConvention(DisplayEnum):
    """
    Enumeration of Day Count Conventions
    Provides an enumeration of all valid day count conventions.
    """

    ONE_ONE = "1/1"
    ACT_360 = "ACT/360"
    ACT_364 = "ACT/364"
    ACT_365_F = "ACT/365.FIXED"
    ACT_365_L = "ACT/365L"
    ACT_365_25 = "ACT/365.25"
    _30_360 = "30/360"
    _30E_360 = "30E/360"
    _30_E_360_ISDA = "30E/360.ISDA"

    def display_names(self) -> dict[str, str]:
        return {
            "ONE_ONE": "One/One",
            "ACT_360": "Actual/360",
            "ACT_364": "Actual/364",
            "ACT_365_F": "Actual/365 Fixed",
            "ACT_365_L": "Actual/365L",
            "ACT_365_25": "Actual/365.25",
            "_30_360": "30/360",
            "_30E_360": "30E/360",
            "_30_E_360_ISDA": "30E/360 ISDA",
        }
