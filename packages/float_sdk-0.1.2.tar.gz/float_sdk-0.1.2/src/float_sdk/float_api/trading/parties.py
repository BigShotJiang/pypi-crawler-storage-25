# pyright: basic

"""
Parties to Financial Transactions

Core party identification and counterparty role enums used across
assets, data, and trading modules.
"""

from typing import Annotated, List, Literal, Union

from pydantic import Field

from float_sdk.float_api.base.measures.text import FloatId
from float_sdk.float_api.organizations.party_role import PartyRole
from float_sdk.float_api.serialization.model import DisplayEnum


class PartyId(FloatId):
    party_roles: List[PartyRole] | None = Field(default=None, title="Party Types", description="List of available party types for this identifier")
    semantic_type: Literal["PARTY_ID"] = "PARTY_ID"


PartyReferenceTypes = Annotated[
    Union[PartyId],
    Field(discriminator="semantic_type"),
]


class CounterpartyRole(DisplayEnum):
    """
    Counterparty Role
    Defines the role of each counterparty in a transaction. Note that either party
    may be buyer or seller, or for an interest paying instrument, payer or receiver.
    Attributes
    ----------
    PARTY_1 : Party 1: The liquidity provider and originator of the trade confirmation.
    PARTY_2 : Party 2: The liquidity taker and recipient of the trade confirmation.
    """

    PARTY_1 = "PARTY_1"
    PARTY_2 = "PARTY_2"

    def inverse(self):
        """
        Inverse
        Return the inverse of the current counterparty enumerated value
        """
        return CounterpartyRole.PARTY_1 if self == CounterpartyRole.PARTY_2 else CounterpartyRole.PARTY_2

    def display_names(self) -> dict[str, str]:
        return {
            "PARTY_1": "Party 1",
            "PARTY_2": "Party 2",
        }
