#!/usr/bin/env python
# pyright: basic
import copy
import dataclasses
import datetime
import inspect
import re
import types
import typing
from collections.abc import Sequence
from decimal import Decimal
from enum import Enum
from typing import get_origin

import inflection
from pydantic import BaseModel

AllType: typing.TypeAlias = type | types.UnionType | typing.Annotated

ALL_PRIMITIVE_TYPES = (str, int, float, bool, datetime.datetime, datetime.date, datetime.time, Decimal)

T = typing.TypeVar("T")


@dataclasses.dataclass(frozen=True, slots=True, eq=False)
class TypeId:
    type_val: type
    type_id: str

    @staticmethod
    def create(t: type) -> "TypeId":
        return TypeId(type_val=t, type_id=full_type_name(t))

    def __eq__(self, __value):
        return self.type_id == __value.type_id

    def __hash__(self):
        return hash(self.type_id)


def is_union_type(t: AllType):
    origin = unpack_type(typing.get_origin(t))
    return origin is typing.Union or origin is types.UnionType


def unpack_union(t: AllType) -> list[type]:
    """Unpacks a union type, returning a list of its inner types."""
    t = unpack_type(t)
    ret: list[type] = []
    for arg in typing.get_args(t):
        unpacked_arg = unpack_type(arg)
        if is_union_type(unpacked_arg):
            ret.extend(unpack_union(unpacked_arg))
        else:
            ret.append(unpacked_arg)
    return ret


def deep_copy(obj: typing.Any) -> typing.Any:
    if isinstance(obj, BaseModel):
        return obj.model_copy(deep=True)
    else:
        return copy.deepcopy(obj)


def unpack_type(t: typing.Any) -> typing.Any:
    """
    Unpacks a type, removing any Annotated wrappers, or Type[Type] wrappers or Final[Type]
    Should support all unpacks, to get to the core type
    """
    if t == types.NoneType or t is None:
        return t

    base_type = get_origin(t)
    if base_type is typing.Annotated or base_type is typing.Final or full_type_name(t) == "typing.Type":
        origin_type = typing.get_args(t)[0]
        return unpack_type(origin_type)
    else:
        return t


def full_type_name(t: typing.Any) -> str:
    if get_origin(t) == types.UnionType:
        return "types.UnionType"
    else:
        name = getattr(t, "__qualname__", None)
        if not name:
            name = getattr(t, "__name__", None)
        module = getattr(t, "__module__", None)
        if not module:
            module = "unknown"
        return f"{module}.{name}"


def is_primitive(t: type) -> bool:
    t = unpack_type(t)
    """Checks if a type is a primitive or core type."""
    return t in ALL_PRIMITIVE_TYPES


def is_enum(t: type) -> bool:
    t = unpack_type(t)
    """Checks if a type is an Enum."""
    return inspect.isclass(t) and issubclass(t, Enum)


def is_list(t: type[typing.Any]) -> bool:
    """Checks if a type is a list."""
    return get_type_or_origin_type(t) in (list, typing.List)


def is_sequence(t: type) -> bool:
    """Checks if a type is a sequence."""
    return get_type_or_origin_type(t) in {Sequence, typing.Sequence}


def is_optional_type(t: AllType) -> bool:
    origin = get_origin(t)
    if origin is typing.Union or origin is types.UnionType:
        args = typing.get_args(t)
        return len(args) == 2 and types.NoneType in args
    return False


def unpack_optional(t: AllType) -> type:
    """Unpacks an optional type, returning the inner type if it's optional."""
    if is_union_type(t):
        args = typing.get_args(t)
        if len(args) == 2:
            return args[0] if args[1] is types.NoneType else args[1]
    raise TypeError(f"Type {t} is not an optional type")


def is_set(t: type) -> bool:
    """Checks if a type is a set."""
    return get_type_or_origin_type(t) in (set, typing.Set)


def is_dict(t: type) -> bool:
    """Checks if a type is a dict."""
    unpack_type(t)
    return get_type_or_origin_type(t) in (dict, typing.Dict)


def is_tuple(t: type) -> bool:
    """Checks if a type is a dict."""
    unpack_type(t)
    return get_type_or_origin_type(t) in (tuple, typing.Tuple)


def is_iter(t: type) -> bool:
    """Checks if type is iterable."""
    return inspect.isclass(t) and issubclass(t, typing.Iterable)


def get_assignable_type_or_none(from_type: type, to_type: AllType) -> type | None:
    to_type = unpack_type(to_type)
    if is_union_type(to_type):
        for arg in unpack_union(to_type):
            t = get_assignable_type_or_none(from_type, arg)
            if t is not None:
                return t
    elif inspect.isclass(from_type) and inspect.isclass(to_type) and issubclass(from_type, to_type):
        return typing.cast(type, to_type)
    return None


def can_be_assigned(from_type: type, to_type: AllType) -> bool:
    to_type = unpack_type(to_type)
    return get_assignable_type_or_none(from_type, to_type) is not None


def get_type_or_origin_type(t: type) -> type:
    """Returns the type or its origin if it's a generic type."""
    t = unpack_type(t)
    origin = get_origin(t)
    return t if origin is None else origin


def get_all_subclasses(cls: type) -> set[type[BaseModel]]:
    return set(cls.__subclasses__()).union([s for c in cls.__subclasses__() for s in get_all_subclasses(c)])


def _resolve_self(tp: typing.Any, cls: type) -> typing.Any:
    if tp is typing.Self:
        return cls
    if isinstance(tp, types.UnionType):
        resolved = tuple(_resolve_self(a, cls) for a in typing.get_args(tp))
        result = resolved[0]
        for a in resolved[1:]:
            result = result | a
        return result
    origin = typing.get_origin(tp)
    if origin is not None:
        args = typing.get_args(tp)
        resolved = tuple(_resolve_self(a, cls) for a in args)
        return origin[resolved]
    return tp


def get_constructor_args(t: type, fwd_refs: dict[str, type] | None = None) -> dict[str, type]:
    module = inspect.getmodule(t)
    module_globals = vars(module) if module else {}
    local_ns: dict[str, typing.Any] = {**(fwd_refs or {}), "Self": t}
    args = typing.get_type_hints(t.__init__, globalns=module_globals, localns=local_ns)
    if "return" in args:
        del args["return"]
    if "self" in args:
        del args["self"]
    return {k: _resolve_self(v, t) for k, v in args.items()}


def strict_cast(t: type[T], val: typing.Any) -> T:
    if isinstance(val, t):
        return typing.cast(T, val)
    else:
        raise ValueError(f"Cannot cast {type(val)} to {t}")


def get_all_types(t: type) -> set[type]:
    """
    Gets all types referneced by this type
    1. If Union Type, expand Union and recurse
    2. If generic type, get all generic args and recurse
    3  If option unpack option, else
    4. return type itself
    """
    # Handle None type
    if t == types.NoneType or t is None:
        return {types.NoneType}

    # Handle literal type
    if t == typing.Literal:
        return {t}

    # exclude type var
    if isinstance(t, typing.TypeVar):
        return set()

    if t == typing.TypeVar:
        return set()

    result: set[type] = set()

    # 1. If Union Type, expand Union and recurse
    if is_union_type(t):
        for arg in unpack_union(t):
            result.update(get_all_types(arg))
        return result

    if is_optional_type(t):
        t = unpack_optional(t)
        return get_all_types(t)

    if is_primitive(t):
        return {t}

    t = unpack_type(t)
    args = typing.get_args(t)
    if args:
        origin = get_origin(t)
        if origin is not None:
            result.add(origin)

        for arg in args:
            result.update(get_all_types(arg))
        return result

    result.add(t)

    return result


def flatten(arg: typing.Any) -> list[typing.Any]:
    ret: list[typing.Any] = []
    arg_type = type(arg)
    if is_list(arg_type) or is_set(arg_type) or is_sequence(arg_type) or is_tuple(arg_type):
        for item in arg:
            ret.extend(flatten(item))
    elif is_dict(arg_type):
        for item in arg.values():
            ret.extend(flatten(item))
    else:
        ret.append(arg)
    return ret


def get_function_defaults(func: typing.Callable) -> dict[str, typing.Any]:
    """Returns a dictionary of default values for function parameters."""
    signature = inspect.signature(func)
    defaults = {}
    for param in signature.parameters.values():
        if param.default is not inspect.Parameter.empty:
            defaults[param.name] = param.default
    return defaults


def unopt(opt: typing.Optional[T], msg: str | None = None) -> T:
    if opt is None:
        if msg is not None:
            raise ValueError(msg)
        else:
            raise ValueError("Optional value is None")
    return opt


def capitalize_first_letter(s):
    return s[:1].upper() + s[1:]


_ID_SUFFIX = "id"


def camel_to_title(s: str) -> str:
    suffix = _ID_SUFFIX if s.endswith(_ID_SUFFIX) and s != _ID_SUFFIX else None

    # Convert camel case to underscored form
    s = re.sub(r"(?<!^)(?=[A-Z])", "_", s)

    # Use inflection to titleize
    title = inflection.titleize(s)

    # Re-add the suffix if it exists
    if suffix:
        title = f"{title} {_ID_SUFFIX.capitalize()}"

    return title


def compare_resource(resource1: typing.Any, resource2: typing.Any) -> bool:
    """
    Compare two resources by their ID.

    Handles different resource types:
    - None: Returns True if both are None
    - BaseModel (Pydantic): Compares by .id attribute
    - Objects with .id: Compares by .id attribute
    - str: Compares directly as string IDs

    Args:
        resource1: First resource to compare
        resource2: Second resource to compare

    Returns:
        bool: True if resources have the same ID (or both are None), False otherwise

    Examples:
        >>> compare_resource(None, None)
        True
        >>> compare_resource(org1, org2)  # Where org1.id == org2.id
        True
        >>> compare_resource("org-123", org)  # Where org.id == "org-123"
        True
    """
    # Both None
    if resource1 is None and resource2 is None:
        return True

    # One is None
    if resource1 is None or resource2 is None:
        return False

    # Extract IDs
    id1 = getattr(resource1, "id", None) if not isinstance(resource1, str) else resource1
    id2 = getattr(resource2, "id", None) if not isinstance(resource2, str) else resource2

    return id1 == id2


def rgetattr(obj: typing.Any, attr: str, default: typing.Any = None) -> typing.Any:
    from float_sdk.float_api.serialization.types import TypeModel

    if obj is None:
        return None

    # Handle lists - recursively apply to each element
    if isinstance(obj, list):
        return [rgetattr(item, attr, default) for item in obj]

    # Split path and traverse each part
    parts = attr.split(".")
    # Try to convert to python_name if TypeModel is available
    parts = list(map(lambda x: TypeModel.python_name(x), parts))

    current: typing.Any = obj

    for part in parts:
        if current is None:
            return None
        current = getattr(current, part, None)
    return current or default


def rsetattr(obj: typing.Any, attr: str, value: typing.Any) -> None:
    from float_sdk.float_api.serialization.types import TypeModel

    if obj is None:
        return

    # Handle lists - recursively apply to each element
    if isinstance(obj, list):
        for item in obj:
            rsetattr(item, attr, value)
        return

    # Split path and traverse to parent
    parts = attr.split(".")
    parts = list(map(lambda x: TypeModel.python_name(x), parts))

    current: typing.Any = obj

    # Navigate to parent object (all parts except the last)
    for part in parts[:-1]:
        if current is None:
            return
        current = getattr(current, part, None)

    # Set the final attribute
    if current is not None:
        setattr(current, parts[-1], value)
