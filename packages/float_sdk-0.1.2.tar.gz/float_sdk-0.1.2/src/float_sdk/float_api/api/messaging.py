# pyright: basic
#!/usr/bin/env python

"""
Messaging primitives

"""

import contextvars
from enum import Enum
from typing import Optional

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"

from float_sdk.float_api.api.context import ContextMeta, ContextMetaInterface

_message_context_var = contextvars.ContextVar("message_context")


class MessageDataType(Enum):
    DATE = "DATE"
    TIME = "TIME"
    STRING = "STRING"
    NUMBER = "NUMBER"
    OBJECT = "OBJECT"
    TABLE = "TABLE"
    NONE = "NONE"


class MessageException(Exception):
    """
    Raised when there is a reference error
    in the message context. For example,
    when trying to deference a global key
    which does not exist
    """

    def __init__(self, id: str):
        self.id = id
        self.message = f"Identifier [{self.id}] not found in message references]"
        super().__init__(self.message)


class FloatMessageContext(ContextMetaInterface, metaclass=ContextMeta):
    """
    Float message context
    Message context for float serialization.
    """

    def __init__(self, message_type: Optional[MessageDataType] = None) -> None:
        self.message_type = message_type
