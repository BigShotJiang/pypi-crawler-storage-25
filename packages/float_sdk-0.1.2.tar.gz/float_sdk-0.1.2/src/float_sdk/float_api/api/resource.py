#!/usr/bin/env python
# pyright: basic

"""
Resource Serialization

Definintion of serializable object status, versioning and audit trail.
"""

import uuid
from abc import ABC, abstractmethod
from enum import Enum
from functools import lru_cache
from http import HTTPStatus
from types import NoneType, UnionType
from typing import Any, List, Optional, Self, Type, cast, get_type_hints, overload

from cachetools import TTLCache
from inflection import pluralize
from pydantic import Field

from float_sdk.float_api.api.origin import ValidDataOriginModel
from float_sdk.float_api.api.reflection import get_all_subclasses, is_optional_type, is_union_type, unpack_optional, unpack_union
from float_sdk.float_api.api.requests import FloatAPIException, Session
from float_sdk.float_api.base.measures.primitive import ReferencedObject, ResourceId
from float_sdk.float_api.base.references import EntityId
from float_sdk.float_api.serialization.model import DataModel
from float_sdk.float_api.serialization.types import Serializer, TypeModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


_PATH = "__uri_path__"
_RESOURCE_ID = "__resource_id__"


def is_resource_id_type(t: type | UnionType) -> bool:
    if is_union_type(t):
        types = unpack_union(t)
    else:
        types = [t]

    valid = False

    for _type in types:
        if _type is str or _type is NoneType:
            continue
        if isinstance(_type, type):
            if issubclass(_type, ResourceId):
                valid = True
            elif not issubclass(_type, ResourceModel):
                valid = False

    return valid


def get_resource_id_type(t: type | UnionType) -> Type[ResourceId] | None:
    if is_union_type(t):
        types = unpack_union(t)
    else:
        types = [t]

    for _type in types:
        if isinstance(_type, type) and issubclass(_type, ResourceId):
            return _type

    return None


def is_resource_type(t: type):
    if is_optional_type(t):
        t = unpack_optional(t)
    if is_union_type(t):
        types = unpack_union(t)
        return all([is_resource_type(t) for t in types])

    return isinstance(t, type) and issubclass(t, ResourceModel)


def unpack_resource_id(resource_id: Any) -> str | None:
    if resource_id is None:
        return None
    if isinstance(resource_id, ResourceId) or isinstance(resource_id, ResourceModel):
        return resource_id.id
    if isinstance(resource_id, str):
        return resource_id
    if isinstance(resource_id, ReferencedObject):
        return resource_id.resource_id.id

    raise ValueError(f"invalid id type: {resource_id}")


def get_resource_organization(resource: Any) -> Any:
    if not isinstance(resource, ResourceModel):
        raise ValueError(f"Expected ResourceModel, got {type(resource)}")
    organization = getattr(resource, "organization", None)
    if organization is None:
        raise ValueError(f"Resource {type(resource).__name__} does not have organization")
    return organization


def get_resource_organization_id(resource: Any) -> str:
    organization = get_resource_organization(resource)
    org_id = unpack_resource_id(organization)
    if org_id is None:
        raise ValueError(f"Resource {type(resource).__name__} has None organization id")
    return org_id


class ResourceStatus(Enum):
    """
    Resource Status

    The resource status of an object on the platform refers to the current state
    or condition of that object within the system. It provides information about
    the availability, accessibility, and usability of the object for various
    operations and transactions.
    """

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class ResourceHealth(Enum):
    """
    Resource Health

    Indicates the current status of a given resource with respect to operational
    workflow. The health is used to indicate if workflows are processing correctly,
    if action is required or overdue, or if something has failed.
    """

    NORMAL = "NORMAL"
    HAS_ISSUE = "HAS_ISSUE"
    REQUIRES_ATTENTION = "REQUIRES_ATTENTION"


class ResourceInfo(TypeModel):
    """
    Resource Info

    The resource information of an object on the platform provides information
    on the data type, version and status on the platform. This manages state
    information, audit trail, and versioning in a consistent way across all
    resources. This allows a consistent API for audit information.
    """

    status: ResourceStatus = ResourceStatus.ACTIVE
    version: int = 0
    type: str = ""


class ResourceIdentifierModel(DataModel):
    """
    Identifier for a given resource. Maps the Entity which issues each identifier,
    along with the identifier type and value

    Subclass implementation should add identifier type enumeration.
    """

    value: str | None = None
    issuing_entity: EntityId | str | None = None


class ResourceAction(Enum):
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    RESTART = "RESTART"


class ResourceCache:
    _cache = TTLCache(maxsize=1000, ttl=30)

    @classmethod
    def get(cls, key: str) -> Any:
        return cls._cache.get(key)

    @classmethod
    def set(cls, key: str, value: Any):
        cls._cache[key] = value

    @classmethod
    def clear(cls):
        cls._cache.clear()


def _get_uuid() -> str:
    return uuid.uuid4().hex


SEMANTIC_TYPE_FIELD = "semanticType"


def resource_semantic_types(resource: type | UnionType) -> str | list[str]:
    """Returns the semantic type(s) for a resource type or union of resource types."""
    if is_union_type(resource):
        return [t.model_fields["semantic_type"].default for t in unpack_union(resource)]
    return resource.model_fields["semantic_type"].default  # type: ignore[union-attr]


class ResourceModel(DataModel, ReferencedObject):
    """
    Resource Base Model

    Base class for a serialization model for an object which can be persisted through
    the Float API. Has an identifier and version which locates the object, tracks status
    and version conflicts while providing an audit trail in a consistent way.
    """

    id: str | None = Field(default=None, title="Id", description="Unique identifier for the resource.")
    version: str | None = Field(
        default=None,
        title="Version",
        description="Unique version identifier for the resource.",
        json_schema_extra={"readOnly": True},
    )
    data_origin: ValidDataOriginModel | None = Field(
        default=None, title="Data Origin", description="Identifies the source from which this resource originated."
    )

    def uuid(self) -> str:
        return _get_uuid()

    @classmethod
    def resource_id_type(cls) -> type[ResourceId]:
        if hasattr(cls, _RESOURCE_ID) and getattr(cls, _RESOURCE_ID):
            return getattr(cls, _RESOURCE_ID)
        else:
            return get_type_hints(cls.resource_id.fget)["return"]

    @property
    def resource_id(self) -> ResourceId:
        id_class = self.__class__.resource_id_type()
        return id_class(id=self.id, version=self.version)

    @classmethod
    def model_field_default(cls, field: str) -> Any:
        return cls.model_fields[field].default

    @classmethod
    @lru_cache(maxsize=65536)
    def get_uri_path(cls) -> str:
        if hasattr(cls, _PATH):
            return getattr(cls, _PATH)
        else:
            return pluralize(cls.model_display_name()).lower()

    @classmethod
    def get_uri(cls, id: str | None = None) -> str:
        object_path = cls.get_uri_path()
        return f"{object_path}/{id}" if id else object_path

    @classmethod
    def get(cls, id: str, reload=False, throw_on_missing: bool = True) -> Self | None:
        uri = cls.get_uri(id)
        cache_key = f"{cls.__name__}/{uri}"
        cached = ResourceCache.get(cache_key)

        if cached and not reload:
            return cached

        response = Session.current.get(uri, throw_on_missing=throw_on_missing)

        if response and isinstance(response, dict):
            model = Serializer.deserialize(response, cls)
        else:
            model = None

        ResourceCache.set(cache_key, model)
        return model

    @overload
    @classmethod
    async def get_async(cls, id: str, reload=False, throw_on_missing: bool = True, params: dict | None = None) -> Self: ...

    @overload
    @classmethod
    async def get_async(cls, id: str, reload=False, throw_on_missing: bool = False, params: dict | None = None) -> Self | None: ...

    @classmethod
    async def get_async(cls, id: str, reload=False, throw_on_missing: bool = True, params: dict | None = None) -> Self | None:
        uri = cls.get_uri(id)
        cache_key = f"{cls.__name__}/{uri}"
        cached = ResourceCache.get(cache_key)

        if cached and not (reload or params):
            return cached

        response = await Session.current.get_async(uri, throw_on_missing=throw_on_missing, params=params)

        if response and not isinstance(response, dict):
            raise FloatAPIException(status_code=HTTPStatus.NOT_IMPLEMENTED, message="Invalid response type")

        response_semantic_type = response.get("semanticType") if response else None
        if response_semantic_type and response_semantic_type != cls.get_semantic_type():
            return None

        if response and isinstance(response, dict):
            model = Serializer.deserialize(response, cls)
        else:
            model = None

        if not params:
            ResourceCache.set(cache_key, model)

        return model

    @classmethod
    def get_many_by_ids(cls, ids: List[str], reload=False) -> List[Self | None]:
        load = []
        cache: dict[str, Self] = {}

        for id in ids:
            cached = ResourceCache.get(cls.get_uri(id))

            if cached and not reload:
                cache[id] = cached
            else:
                load.append(id)

        uri = cls.get_uri_path()

        results = Session.current.get(uri, {"ids": ids})["results"]

        for result in results:
            model = cast(Self, Serializer.deserialize(result, cls))
            ResourceCache.set(cls.get_uri(result["id"]), model)
            cache[result["id"]] = model

        return [cache.get(id) for id in ids]

    @classmethod
    def get_many(cls, params: dict[str, str | list[str] | float | list[float]] | None = None, reload: bool = False) -> List[Self]:
        uri = cls.get_uri_path()

        params = params or {}
        response = Session.current.get(uri, params)
        results = response["results"]

        if not isinstance(results, list):
            raise FloatAPIException(status_code=HTTPStatus.NOT_IMPLEMENTED, message="Expected list of results")

        return Serializer.deserialize(results, cls)

    @classmethod
    async def get_many_async(cls, params: dict[str, str | List[str]] | None = None, reload: bool = False) -> List[Self]:
        uri = cls.get_uri_path()

        params = params or {}
        response = await Session.current.get_async(uri, params)
        results = response["results"]

        if not isinstance(results, list):
            raise FloatAPIException(status_code=HTTPStatus.NOT_IMPLEMENTED, message="Expected list of results")

        return Serializer.deserialize(results, cls)

    def get_endpoint(self, path: str, model: type) -> Any:
        uri = self.get_uri(f"{self.id}{path}")
        result = Session.current.get(uri)
        return Serializer.deserialize(result, model)

    async def get_endpoint_async(self, path: str, model: type) -> Any:
        uri = self.get_uri(f"{self.id}{path}")
        result = await Session.current.get_async(uri)
        return Serializer.deserialize(result, model)

    @classmethod
    def post_async(cls, path: str, model: "ResourceModel"):
        uri = cls.get_uri(path)
        return Session.current.post_async(uri, model.to_json())

    @classmethod
    def put_async(cls, path: str, model: "ResourceModel"):
        uri = cls.get_uri(path)
        return Session.current.put_async(uri, model.to_json())

    @classmethod
    def post(cls, path: str, model: DataModel):
        uri = cls.get_uri(path)
        return Session.current.post(uri, model.to_json())

    @classmethod
    def put(cls, path: str, model: DataModel):
        uri = cls.get_uri(path)
        return Session.current.put(uri, model.to_json())

    @classmethod
    def save(cls, model: "ResourceModel") -> "ResourceModel":
        if model.version:
            response = cls.put(f"{model.id}", model)
        else:
            response = cls.post("", model)

        response = Serializer.deserialize(response, model.__class__)

        if not isinstance(response, model.__class__):
            raise FloatAPIException(f"Expected {model.__class__.__name__} but got {response.__class__.__name__}")

        return response

    @classmethod
    async def save_async(cls, model: "ResourceModel"):
        if model.version:
            response = await cls.put_async(f"{model.id}", model)
        else:
            response = await cls.post_async("", model)

        response = Serializer.deserialize(response, model.__class__)

        if not isinstance(response, model.__class__):
            raise FloatAPIException(f"Expected {model.__class__.__name__} but got {response.__class__.__name__}")

        return response

    @classmethod
    def delete(cls, id: str) -> None:
        uri = cls.get_uri(id)
        Session.current.delete(uri)

    @classmethod
    async def delete_async(cls, id: str) -> None:
        uri = cls.get_uri(id)
        await Session.current.delete_async(uri)

    @classmethod
    def get_semantic_type(cls) -> str | None:
        field = cls.model_fields.get("semantic_type")
        if field is not None:
            return getattr(field, "default", None)
        return None

    @classmethod
    def get_type_from_resource_id(cls, resource_id_type: Type[ResourceId]) -> Optional[type]:
        """
        Get the parent class type from the resource id type. Note that this will only
        map types which have been imported, so do not call on anything which isnt correctly
        imported and scoped
        """

        all_subclasses = get_all_subclasses(cls)

        for subclass in all_subclasses:
            subclass_id_type = subclass.resource_id_type()  # pyright: ignore
            if subclass_id_type == resource_id_type:
                return subclass

        return None


class ResourceRepository(ABC):
    """
    Data Access Object (DAO) to access resources from underlying storage
    """

    @abstractmethod
    async def get_resources_by_id(
        self, resource_ids: set[str], entitlements_check: bool = True, use_cache: bool = True, force_reload: bool = False
    ) -> dict[str, ResourceModel]: ...

    @abstractmethod
    def key(self) -> str:
        """
        Key that uniquely identifies this resource repository.
        """
        ...

    def __eq__(self, __value):
        return self.key() == __value.key()

    def __repr__(self):
        return self.key()

    def __hash__(self):
        return hash(self.key())


class NamedResourceModel(ResourceModel):
    """
    Named Resource Model

    Base class for a serialization model for an object which can be persisted through
    the Float API. Resource has name and description.
    """

    name: Optional[str] = Field(default=None, description="Name or title of the resource.", json_schema_extra={"audit": True})
    description: Optional[str] = Field(
        default=None, description="Text which describes the resource, which can be useful for discovery.", json_schema_extra={"audit": True}
    )

    @property
    def resource_id(self) -> ResourceId:
        return ResourceId(id=self.id, name=self.name, version=self.version)
