# pyright: basic
#!/usr/bin/env python

"""
Request Context Management

"""

import contextvars
import inspect
from enum import Enum
from typing import Any

import loguru

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies Inc."
__email__ = "andy@float.tech"


class Environment(Enum):
    TEST = "TEST"
    LOCAL = "LOCAL"
    DEV = "DEV"
    UAT = "UAT"
    PROD = "PROD"


def _get_context_var_from_bases(bases: list[type]) -> contextvars.ContextVar:
    for base in bases:
        parents = inspect.getmro(base)
        # We are iterating in order and find first parent
        for parent in parents:
            context_var = getattr(parent, _CONTEXT_VAR_NAME, None)
            if context_var is not None:
                return context_var
    raise Exception(f"Failed to find context_var in bases: {bases}")


def _get_context_var_from_class(cls) -> contextvars.ContextVar:
    context_var = getattr(cls, _CONTEXT_VAR_NAME, None)
    if context_var is not None:
        return context_var
    raise Exception(f"Failed to find context_var in class: {cls}")


def _get_context_var(bases: list[type], attrs: Any) -> contextvars.ContextVar:
    if _CONTEXT_VAR_NAME in attrs:
        resolved_var = attrs[_CONTEXT_VAR_NAME]
    else:
        resolved_var = _get_context_var_from_bases(bases)
        attrs[_CONTEXT_VAR_NAME] = resolved_var
    return resolved_var


class ContextMetaInterface:
    """
    Marker interface for context class, to help with type checking
    """

    @property
    def parent(self) -> "ContextMetaInterface | None":
        return None

    @property
    def origin(self) -> "ContextMetaInterface":
        return self

    @property
    def depth(self) -> int:
        return 0

    @property
    def is_active(self) -> bool:
        return False

    def __enter__(self):
        pass

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any):
        pass


_CONTEXT_VAR_NAME = "_$context_var"
_NO_DEFAULT_FLAG_VAR_NAME = "_$no_parent"


class ContextMeta(type):
    @property
    def current(cls) -> Any:
        context_var = _get_context_var_from_class(cls)
        cur_ctx = context_var.get()
        no_default_flag: bool = getattr(cls, _NO_DEFAULT_FLAG_VAR_NAME, False)
        if not no_default_flag and cur_ctx is None:
            cur_ctx = cls()
            context_var.set(cls())
        return cur_ctx

    @current.setter
    def current(cls, value):
        context_var = _get_context_var_from_class(cls)
        context_var.set(value)

    @property
    def stack(cls) -> list[Any]:
        context_var = _get_context_var_from_class(cls)
        result: list[Any] = []
        current = context_var.get(None)
        while current is not None:
            result.append(current)
            current = getattr(current, "_context_parent", None)
        result.reverse()
        return result

    def __new__(cls, name, bases, attrs, **kwargs):
        use_parent_context: bool = "use_parent_context" in kwargs and kwargs["use_parent_context"]
        attrs[_NO_DEFAULT_FLAG_VAR_NAME] = "no_default" in kwargs and kwargs["no_default"]
        if not use_parent_context:
            attrs[_CONTEXT_VAR_NAME] = contextvars.ContextVar(_CONTEXT_VAR_NAME, default=None)

        cur_enter_fn = attrs.get("__enter__")
        cur_exit_fn = attrs.get("__exit__")
        context_var = _get_context_var(bases, attrs)

        def _enter(self):
            self._context_parent = context_var.get(None)
            self._context_active = True
            self._context_var_token = context_var.set(self)
            if cur_enter_fn is not None:
                try:
                    cur_enter_fn(self)
                except Exception as e:
                    loguru.logger.exception("Unexpected error in context enter", exc_info=e)
                    raise e

        def _exit(self, exc_type, exc_value, traceback):
            if not self._context_var_token:
                raise RuntimeError("Context exit called without a valid context token. Unexpected error")
            self._context_active = False
            context_var.reset(self._context_var_token)
            if cur_exit_fn is not None:
                try:
                    cur_exit_fn(self, exc_type, exc_value, traceback)
                except Exception as e:
                    loguru.logger.exception("Unexpected error in context exit", exc_info=e)
                    raise e

        attrs["__enter__"] = _enter
        attrs["__exit__"] = _exit

        if "parent" not in attrs and not any(hasattr(b, "parent") for b in bases if b is not ContextMetaInterface):
            attrs["parent"] = property(lambda self: getattr(self, "_context_parent", None))

        if "origin" not in attrs and not any(hasattr(b, "origin") for b in bases if b is not ContextMetaInterface):

            def _origin(self):
                ctx = self
                while ctx.parent is not None:
                    ctx = ctx.parent
                return ctx

            attrs["origin"] = property(_origin)

        if "depth" not in attrs and not any(hasattr(b, "depth") for b in bases if b is not ContextMetaInterface):

            def _depth(self):
                d = 0
                ctx = self.parent
                while ctx is not None:
                    d += 1
                    ctx = ctx.parent
                return d

            attrs["depth"] = property(_depth)

        if "is_active" not in attrs and not any(hasattr(b, "is_active") for b in bases if b is not ContextMetaInterface):
            attrs["is_active"] = property(lambda self: getattr(self, "_context_active", False))

        return super().__new__(cls, name, bases, attrs)


class SingletonMeta(type):
    def is_initialized(cls):
        return getattr(cls, "_INSTANCE", None) is not None

    @property
    def current(cls):
        instance = getattr(cls, "_INSTANCE", None)  # pyright: ignore
        if instance is None:  # pyright: ignore
            instance = cls()
            setattr(cls, "_INSTANCE", instance)

        return instance

    @current.setter
    def current(cls, value):
        setattr(cls, "_INSTANCE", value)

    def __new__(cls, name, bases, attrs, **kwargs):
        old__init__ = attrs["__init__"]

        def new__init__(self, *a, **k):
            clz = getattr(self, "__class__")
            instance = getattr(clz, "_INSTANCE", None)
            if not instance:
                old__init__(self, *a, **k)
                setattr(clz, "_INSTANCE", self)
            else:
                raise ValueError("This is a singleton, Cannot create more than one instance of this class")

        attrs["__init__"] = new__init__
        return super().__new__(cls, name, bases, attrs)
