# pyright: basic
import asyncio
from collections.abc import Awaitable, Coroutine, Iterable
from typing import Any, TypeVar

R = TypeVar("R")


async def limited_gather(tasks: Iterable[Awaitable[Any]], limit: int = 10) -> list[Any]:
    semaphore = asyncio.Semaphore(limit)

    async def sem_task(task):
        async with semaphore:
            return await task

    return await asyncio.gather(*(sem_task(task) for task in tasks))


def asyncio_run(future: Coroutine[Any, Any, R] | asyncio.Future[R] | asyncio.Task[R]) -> R:
    """
    A better implementation of `asyncio.run` that handles both coroutines and futures.

    :param future: A coroutine, future, or task to run.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(_ensure_coroutine(future))
    else:
        return loop.run_until_complete(future)


def _ensure_coroutine(future: Coroutine[Any, Any, R] | asyncio.Future[R] | asyncio.Task[R]) -> Coroutine[Any, Any, R]:
    if asyncio.iscoroutine(future):
        return future

    async def _await_future() -> Any:
        return await future

    return _await_future()
