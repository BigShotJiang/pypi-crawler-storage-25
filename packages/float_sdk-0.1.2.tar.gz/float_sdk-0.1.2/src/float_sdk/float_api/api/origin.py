# pyright: strict
#!/usr/bin/env python

"""
Data Origin
"""

from typing import Annotated, Literal, Union

from pydantic import Field

from float_sdk.float_api.base.references import ApplicationId, DataConnectionId, DocumentId, PlatformId
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class DataOriginModel(DataModel):
    """
    Data Origin

    Identifies the source of a resource in the Float platform

    Example:

    | Resource  | Connection     | Platform                |
    | Trade     | GLOBO_FIX      | GLOBO FX MAKET MAKING   |
    | Trade     | HTTP           | FIS FRONT ARENA         |
    | Valuation | CLIENT_SFTP_1  | CLIENT_VALUATION_ENGINE |
    |

    """

    platform: PlatformId | str | None = Field(
        default=None, title="Platform", description="Identifies the platform on which the resource was created or received"
    )
    connection: DataConnectionId | str | None = Field(
        default=None, title="Connection", description="Identifies the channel over which the resource was received"
    )


class FIXDataOriginModel(DataOriginModel):
    session_instance_id: str | None = Field(default=None, title="Session Instance ID", description="Identifies the FIX session instance")
    sequence_number: int | None = Field(default=None, title="Sequence Number", description="FIX message sequence number")

    semantic_type: Literal["FIX_DATA_ORIGIN"] = "FIX_DATA_ORIGIN"


class APIDataOriginModel(DataOriginModel):
    application: ApplicationId | str | None = Field(default=None, title="Application", description="Application which originated the resource")
    request_id: str | None = Field(default=None, title="Request ID", description="HTTP request ID")

    semantic_type: Literal["API_DATA_ORIGIN"] = "API_DATA_ORIGIN"


class SFTPDataOriginModel(DataOriginModel):
    document: DocumentId | str | None = Field(default=None, title="Document", description="Document received over SFTP")

    semantic_type: Literal["SFTP_DATA_ORIGIN"] = "SFTP_DATA_ORIGIN"


ValidDataOriginModel = Annotated[
    Union[FIXDataOriginModel, APIDataOriginModel, SFTPDataOriginModel],
    Field(discriminator="semantic_type"),
]
