# pyright: basic
#!/usr/bin/env python

"""
API Request implementation

"""

import datetime as dt
import json
import logging
import os
from http import HTTPStatus
from typing import Optional, Union
from urllib.parse import quote

import httpcore
import httpx
import requests
from httpx import AsyncClient
from loguru import logger
from pydantic import BaseModel
from pydash import get
from tenacity import after_log, retry, retry_if_exception, retry_if_exception_type, stop_after_attempt, wait_exponential

from float_sdk.float_api.api.context import ContextMeta, ContextMetaInterface, Environment

_tenacity_logger = logging.getLogger(__name__)

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


_API_VERSION = 1
_SESSION = "_session"


def retry_request(value) -> bool:
    if isinstance(value, FloatAPIException) and value.status_code in [502, 503]:
        logger.warning(f"retry_request error, retrying (status_code: {value.status_code}, path: {getattr(value, 'request_path', 'unknown')})")
        return True
    if isinstance(value, (httpx.TimeoutException, httpcore.ReadTimeout)):
        logger.warning(f"retry_request timeout, retrying (path: {getattr(value, 'request_path', 'unknown')})")
        return True
    return False


class FloatAPIException(Exception):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self._detail = message  # for backward compat
        self._status_code = status_code

    @property
    def status_code(self) -> int | None:
        return self._status_code

    @property
    def detail(self) -> str:
        return self._detail


class APIErrorModel(BaseModel):
    """
    API Error

    Returned by the API server on error with detail about the issue
    """

    detail: str


def build_query_string(params: dict | None = None) -> str:
    query_string = ""

    if params:
        qs = []

        for name, value in params.items():
            values = value if isinstance(value, list) else [value]
            for value in values:
                qs.append(f"{name}={value}")

        query_string = f"?{'&'.join(qs)}"

    return query_string


class Session(ContextMetaInterface, metaclass=ContextMeta, no_default=True):
    __async_client = None

    def __init__(
        self,
        api_env: Environment | None = None,
        client_id: str | None = None,
        client_secret: str | None = None,
        access_token: str | None = None,
        current_organization_id: str | None = None,
    ) -> None:
        self.environment = api_env

        self.client_id = client_id if client_id else os.getenv("client_id", None)
        self.client_secret = client_secret if client_secret else os.getenv("client_secret", None)
        self.current_organization_id = current_organization_id

        if access_token:
            self.token = {"access_token": access_token, "expires": dt.datetime.now(dt.UTC) + dt.timedelta(seconds=60 * 60)}

    def get_async_client(self):
        if not self.__async_client:
            self.__async_client = AsyncClient(base_url=self._base_url(), timeout=30)
        return self.__async_client

    def _base_url(self) -> str:
        if self.environment == Environment.LOCAL:
            base = "http://localhost:80"
        elif self.environment in [Environment.DEV, Environment.LOCAL]:
            base = "https://api-dev.float.tech"
        elif self.environment in [Environment.PROD, Environment.UAT]:
            base = "https://api.float.tech"
        else:
            raise ValueError("Invalid Session environment")
        return f"{base}/v{_API_VERSION}/"

    def _auth_url(self) -> str:
        if self.environment in [Environment.LOCAL, Environment.TEST, Environment.DEV]:
            return "https://login-dev.float.tech"
        elif self.environment in [Environment.PROD, Environment.UAT]:
            return "https://login.float.tech"
        raise ValueError("Invalid Session environment")

    @retry(
        retry=retry_if_exception_type((httpx.TransportError)),
        wait=wait_exponential(multiplier=2, min=4, max=60),
        after=after_log(_tenacity_logger, logging.INFO),
        stop=stop_after_attempt(3),
    )
    def authenticate(self):
        if not self.client_id or not self.client_secret:
            raise FloatAPIException(status_code=HTTPStatus.UNAUTHORIZED, message="Credentials not provided, missing client_id or secret")

        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "audience": os.getenv("auth0_api_audience"),
            "grant_type": "client_credentials",
        }

        auth_url = f"{self._auth_url()}/oauth/token"
        headers = {"content-type": "application/json"}

        response = httpx.post(url=auth_url, json=payload, headers=headers)
        if response.status_code not in [200]:
            raise FloatAPIException(status_code=response.status_code, message=f"GET failed: {response.text}")

        return json.loads(response.text)

    def auth_token(self) -> str:
        token = getattr(self, "token", None)

        if not token or dt.datetime.now(dt.UTC) > self.token["expires"]:
            self.token = self.authenticate()
            self.token["expires"] = dt.datetime.now(dt.UTC) + dt.timedelta(seconds=self.token["expires_in"])

        return self.token["access_token"]

    def headers(self, content_type: str | None = "application/json; charset=utf-8") -> dict:
        headers = {"Authorization": f"Bearer {self.auth_token()}", "X-Application": "float-sdk"}

        if content_type:
            headers["Content-Type"] = content_type

        if self.current_organization_id:
            headers["X-Float-Organization"] = self.current_organization_id

        return headers

    @classmethod
    def use(
        cls,
        environment=Environment.DEV,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        access_token: str | None = None,
        current_organization_id: str | None = None,
    ):
        session = Session(
            api_env=environment, client_id=client_id, client_secret=client_secret, access_token=access_token, current_organization_id=current_organization_id
        )

        init_session = False
        if Session.current is not None:
            if get(Session.current, "token") is None or (
                (client_id and Session.current.client_id != client_id)
                or (client_secret and Session.current.client_secret != client_secret)
                or Session.current.environment != environment
            ):
                init_session = True
        else:
            init_session = True

        if init_session:
            session.authenticate()
            session.auth_token()  # sets the token
            Session.current = session

        Session.current.current_organization_id = current_organization_id

    def get(self, path: str, params: dict | None = None, throw_on_missing: bool = True) -> dict | bytes | None:
        """
        GET

        Make a get request to the Float API
        """
        base = self._base_url()
        qs = build_query_string(params)
        url = f"{base}{quote(path)}{qs}"

        headers = self.headers()
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            if 400 <= response.status_code < 500 and not throw_on_missing:
                return None
            raise FloatAPIException(status_code=response.status_code, message=f"GET failed: {response.text}")

        if response.headers["Content-Type"] == "application/json":
            return json.loads(response.text)
        else:
            return response.content

    @retry(
        retry=retry_if_exception(retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    async def get_async(self, path: str, params: dict | None = None, throw_on_missing: bool = True) -> dict | bytes | None:
        base = self._base_url()
        qs = build_query_string(params)
        url = f"{base}{quote(path)}{qs}"

        headers = self.headers()
        response = await self.get_async_client().get(url, headers=headers)

        if response.status_code != 200:
            if 400 <= response.status_code < 500 and not throw_on_missing:
                return None
            raise FloatAPIException(status_code=response.status_code, message=f"GET failed: {response.text}")

        if response.headers["Content-Type"] == "application/json":
            return json.loads(response.text)
        else:
            return response.content

    def post(self, path: str, body: dict | str | None = None, files: dict | None = None, content_type: str | None = "application/json; charset=utf-8"):
        """
        POST

        Execute a POST to Float API
        """

        url = f"{self._base_url()}{quote(path)}"

        headers = self.headers(content_type=content_type)
        body_json = json.dumps(body) if type(body) is dict else body

        if files:
            response = requests.post(url, headers=headers, files=files, verify=True)
        else:
            body_json = json.dumps(body) if type(body) is dict else body
            data = body_json.encode("utf-8") if isinstance(body_json, str) else body_json

            response = requests.post(url, data=data, headers=headers, verify=True)

        if response.status_code // 100 == 2:
            return json.loads(response.text)
        else:
            raise FloatAPIException(status_code=response.status_code, message=f"POST failed: {response.text}")

    @retry(
        retry=retry_if_exception(retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    async def post_async(
        self, path: str, body: Optional[Union[dict, str]] = None, files: Optional[dict] = None, content_type: str | None = "application/json; charset=utf-8"
    ):
        """
        POST (Async)

        Execute an async POST to Float API using httpx
        """
        url = f"{self._base_url()}{quote(path)}"
        headers = self.headers(content_type=content_type)

        if files:
            response = await self.get_async_client().post(url, headers=headers, files=files)
        else:
            body_json = json.dumps(body) if type(body) is dict else body
            data = body_json.encode("utf-8") if isinstance(body_json, str) else body_json
            response = await self.get_async_client().post(url, content=data, headers=headers)

        if response.status_code // 100 == 2:
            return json.loads(response.text)
        else:
            raise FloatAPIException(status_code=response.status_code, message=f"POST failed: {response.text}")

    @retry(
        retry=retry_if_exception(retry_request),
        wait=wait_exponential(multiplier=2, min=2, max=32),
        stop=stop_after_attempt(5),
        reraise=True,
    )
    async def put_async(self, path: str, body: dict | str, content_type: str | None = "application/json; charset=utf-8"):
        """
        PUT (Async)

        Execute an async PUT to Float API using httpx
        """
        url = f"{self._base_url()}{quote(path)}"
        headers = self.headers(content_type=content_type)
        body_json = json.dumps(body) if type(body) is dict else body
        data = body_json.encode("utf-8") if isinstance(body_json, str) else body_json

        response = await self.get_async_client().put(url, content=data, headers=headers)

        if response.status_code == 200:
            return json.loads(response.text)
        else:
            raise FloatAPIException(status_code=response.status_code, message=f"PUT failed: {response.text}")

    def put(self, path: str, body: dict | str, content_type: str | None = "application/json; charset=utf-8"):
        """
        PUT

        Execute a PUT to Float API
        """

        url = f"{self._base_url()}{quote(path)}"
        headers = self.headers(content_type=content_type)
        body_json = json.dumps(body) if type(body) is dict else body
        data = body_json.encode("utf-8") if isinstance(body_json, str) else body_json

        response = requests.put(url, data=data, headers=headers)

        if response.status_code == 200:
            return json.loads(response.text)
        else:
            raise FloatAPIException(status_code=response.status_code, message=f"PUT failed: {response.text}")

    def delete(self, path: str):
        """
        DELETE

        Execute a DELETE request to Float API
        """

        url = f"{self._base_url()}{quote(path)}"
        headers = self.headers()
        response = requests.delete(url, headers=headers)

        if response.status_code != 204:
            raise FloatAPIException(status_code=response.status_code, message=f"DELETE failed: {response.text}")
