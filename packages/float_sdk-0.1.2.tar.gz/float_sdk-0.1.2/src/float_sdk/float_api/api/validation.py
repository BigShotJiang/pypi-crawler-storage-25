# pyright: basic
#!/usr/bin/env python

"""
Validation Models

"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."


class ValidationStatus(DisplayEnum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    SUCCESS = "SUCCESS"

    def display_names(self) -> dict[str, str]:
        return {
            "ERROR": "Error",
            "WARNING": "Warning",
            "SUCCESS": "Success",
        }


class ValidationResultModel(DataModel):
    field: str = Field(..., title="Field", description="The field that was validated")
    status: ValidationStatus = Field(..., title="Status", description="The status of the validation")
    message: str = Field(..., title="Message", description="The message associated with the validation error")

    semantic_type: Literal["VALIDATION_RESULT"] = "VALIDATION_RESULT"


class ValidationResultsModel(DataModel):
    results: list[ValidationResultModel] | None = Field(default=None, title="Results", description="The list of validation results")

    semantic_type: Literal["VALIDATION_RESULTS"] = "VALIDATION_RESULTS"
