#!/usr/bin/env python
# pyright: basic

"""
Trading venues, exchanges, and related functions
"""

from abc import ABC
from enum import Enum
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel, ResourceIdentifierModel
from float_sdk.float_api.base.references import CountryId, EntityId, ExchangeId
from float_sdk.float_api.organizations.contact import WebPageModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class VenueIdentifierType(Enum):
    MIC_CODE = "MIC_CODE"
    OP_MIC_CODE = "OP_MIC_CODE"
    BBG_EXCHANGE_CODE = "BBG_EXCHANGE_CODE"
    BBG_COMPOSITE_CODE = "BBG_COMPOSITE_CODE"
    LEI = "LEI"


class VenueIdentifier(ResourceIdentifierModel):
    type: VenueIdentifierType = Field(..., title="Type", description="The type of identifier.")


class VenueModel(NamedResourceModel, ABC):
    identifiers: List[VenueIdentifier] = Field(description="The identifiers associated with the venue.")


class VenueStatus(Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class ListingRules:
    pass


class OperatingSegment(Enum):
    """
    Indicates whether the venue represents an operating MIC or a market segment MIC
    """

    OPRT = "OPRT"
    SGMT = "SGMT"


class MarketCategoryCode(Enum):
    """
    Parameters
    ----------
    ATSS : Alternative Trading System
    APPA : Approved Publication Arrangement
    ARMS : Approved Reporting Mechanism
    CTPS : Consolidated Tape Provider
    CASP : Crypto Asset Services Provider
    DCMS : Designated Contract Market
    IDQS : Inter-Dealer Quotation System
    MLTF : Multilateral Trading Facility
    NSPD : Not Specified
    OTFS : Organised Trading Facility
    OTHR : Other
    RMOS : Recognised Market Operator
    RMKT : Regulated Market
    SEFS : Swap Execution Facility
    SINT : Systematic Internaliser
    TRFS : Trade Reporting Facility
    """

    ATSS = "ATSS"
    APPA = "APPA"
    ARMS = "ARMS"
    CTPS = "CTPS"
    CASP = "CASP"
    DCMS = "DCMS"
    IDQS = "IDQS"
    MLTF = "MLTF"
    NSPD = "NSPD"
    OTFS = "OTFS"
    OTHR = "OTHR"
    RMOS = "RMOS"
    RMKT = "RMKT"
    SEFS = "SEFS"
    SINT = "SINT"
    TRFS = "TRFS"


class ExchangeModel(VenueModel):
    __resource_id__ = ExchangeId
    __uri_path__ = "venues/exchanges"

    entity: EntityId | str | None = Field(default=None, description="The entity which owns and operatesthe exchange.")
    country: CountryId | str | None = Field(default=None, description="The country where the exchange operates.")
    city: str | None = Field(default=None, description="The city where the exchange operates.")
    operating_segment: OperatingSegment = Field(default=OperatingSegment.OPRT, description="The operating segment of the exchange.")

    timezone: str | None = Field(default=None, description="Exchange timezone in IANA format (e.g., America/New_York).")
    market_category_code: MarketCategoryCode | None = Field(default=None, description="The market category code for the exchange.")

    colo: bool | None = Field(default=None, description="Indicates whether the exchange offers colocated servers.")
    web_pages: List[WebPageModel] | None = Field(default=None, description="The web pages associated with the exchange.")

    ## Exchange audit information
    #
    status: VenueStatus | None = Field(default=None, description="The status of the exchange.")

    semantic_type: Literal["EXCHANGE"] = "EXCHANGE"

    class Config:
        json_schema_extra = {
            "title": "Exchange",
            "description": "An exchange is a marketplace where securities, commodities, derivatives and other financial instruments are traded. Exchanges provide a centralized platform for price discovery, facilitate liquidity, and ensure fair and orderly trading.",
            "example": {
                "id": "XNYS",
                "version": "v1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d",
                "name": "New York Stock Exchange Inc",
                "shortName": "NYSE",
                "description": "The New York Stock Exchange is the world's largest stock exchange by market capitalization of its listed companies.",
                "country": "US",
                "city": "New York",
                "timezone": "America/New_York",
                "identifiers": [
                    {"type": "MIC_CODE", "value": "XNYS"},
                    {"type": "OPERATING_MIC", "value": "XNYS"},
                    {"type": "BBG_EXCHANGE_CODE", "value": "UN"},
                    {"type": "BBG_COMPOSITE_CODE", "value": "US"},
                ],
                "operatingSegment": "OPRT",
                "marketCategoryCode": "RMKT",
                "status": "ACTIVE",
                "colo": True,
                "webPages": [
                    {"url": "https://www.nyse.com", "type": "PRIMARY"},
                    {"url": "https://www.nyse.com/markets/hours-calendars", "type": "MARKET_HOURS"},
                ],
            },
        }
