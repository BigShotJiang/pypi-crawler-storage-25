#!/usr/bin/env python
# pyright: basic

"""
Futures Markets and Contracts

Models for exchange-traded futures markets and individual futures contract instances.
Includes contract specifications (size, tick, settlement), price quotation conventions,
and standard month codes used in futures symbology.
"""

from datetime import date
from enum import Enum
from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.assets.base.base import AssetClassificationModel, AssetIdentifier, SecurityBaseModel
from float_sdk.float_api.assets.base.settlement import SettlementType
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId, ExchangeId, FutureId, FuturesMarketId, GroupId
from float_sdk.float_api.base.units import ValidUnit
from float_sdk.float_api.markets.venues import ExchangeModel
from float_sdk.float_api.organizations.contact import ContactInfoModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class FuturesMonthCode(Enum):
    """
    Standard single-letter month codes used in futures contract symbology
    (e.g. F=Jan, G=Feb, H=Mar). Used across Bloomberg tickers, exchange symbols,
    and CME/ICE contract identifiers.
    """

    JAN = "F"
    FEB = "G"
    MAR = "H"
    APR = "J"
    MAY = "K"
    JUN = "M"
    JUL = "N"
    AUG = "Q"
    SEP = "U"
    OCT = "V"
    NOV = "X"
    DEC = "Z"

    @classmethod
    def from_month(cls, month: int) -> "FuturesMonthCode | None":
        """
        Get the month code for a given month number (1-12).

        Args:
            month: Month number (1=January, 12=December)

        Returns:
            FuturesMonthCode enum value or None if month is invalid
        """
        month_map = {
            1: cls.JAN,
            2: cls.FEB,
            3: cls.MAR,
            4: cls.APR,
            5: cls.MAY,
            6: cls.JUN,
            7: cls.JUL,
            8: cls.AUG,
            9: cls.SEP,
            10: cls.OCT,
            11: cls.NOV,
            12: cls.DEC,
        }
        return month_map.get(month)


class PriceQuotationModel(DataModel):
    """
    Price Quotation

    Defines how the futures contract price is quoted.
    """

    currency: CurrencyId | str | CurrencyModel = Field(..., description="Currency in which the price is quoted (e.g., USD).")
    unit: ValidUnit = Field(..., description="Unit for price quotation (e.g., per barrel, per ounce, per bushel).")
    description: str | None = Field(default=None, description="Human-readable description (e.g., 'U.S. dollars and cents per barrel').")

    semantic_type: Literal["PRICE_QUOTATION_MODEL"] = "PRICE_QUOTATION_MODEL"


class TickSpecificationModel(DataModel):
    """
    Tick Specification

    Defines the minimum price fluctuation (tick) and its value.
    """

    tick_size: float = Field(..., description="Minimum price fluctuation per unit (e.g., 0.01 for $0.01 per barrel).", gt=0)
    tick_value: float = Field(..., description="Dollar value of one tick per contract (e.g., 10.00 for $10 per contract).", gt=0)
    currency: CurrencyId | str | CurrencyModel = Field(..., description="Currency of the tick value.")

    semantic_type: Literal["TICK_SPECIFICATION_MODEL"] = "TICK_SPECIFICATION_MODEL"


class TradingHoursModel(DataModel):
    """
    Trading Hours

    Defines when the contract can be traded.
    """

    description: str = Field(..., description="Description of trading hours (e.g., 'Sunday - Friday 6:00 p.m. - 5:00 p.m. ET').")
    timezone: str | None = Field(default=None, description="Timezone identifier (e.g., 'America/New_York', 'America/Chicago').")

    semantic_type: Literal["TRADING_HOURS_MODEL"] = "TRADING_HOURS_MODEL"


class FuturesContractSpecificationModel(DataModel):
    """
    Futures Contract Specification

    Complete specification for a standardized futures contract including contract size,
    pricing, trading hours, settlement, and delivery terms.
    """

    # Core Contract Details
    contract_unit: ValidUnit | None = Field(default=None, description="Unit of measure for the contract (e.g., barrel, troy ounce, bushel).")
    contract_size: float | None = Field(default=None, description="Number of contract units per contract (e.g., 1000 for 1000 barrels).", gt=0)

    # Pricing
    price_quotation: PriceQuotationModel | None = Field(default=None, description="How the price is quoted (e.g., USD per barrel).")
    tick_specification: TickSpecificationModel | None = Field(default=None, description="Minimum price fluctuation (tick) details.")

    # Settlement & Delivery
    settlement_type: SettlementType | None = Field(default=None, description="Details about settlement method (e.g. CASH or PHYSICAL delivery procedures).")

    # Position Limits & Rules
    block_trade_minimum: int | None = Field(default=None, description="Minimum quantity for block trades.", gt=0)
    exchange_rule_reference: str | None = Field(default=None, description="Reference to exchange rule chapter or section.")

    # Additional Information
    notes: str | None = Field(default=None, description="Additional notes or special provisions about the contract.")

    semantic_type: Literal["FUTURES_CONTRACT_SPECIFICATION"] = "FUTURES_CONTRACT_SPECIFICATION"


class FuturesMarketModel(NamedResourceModel):
    """
    Futures Market

    Represents a futures market (contract series) that defines the standardized specifications
    for a class of futures contracts, including the underlying asset, contract size, tick size,
    delivery terms, and trading venue. Individual FutureModel instances reference a FuturesMarket
    for their contract specifications.
    """

    __resource_id__ = FuturesMarketId
    __uri_path__ = "assets/futures/markets"

    short_name: str | None = Field(default=None, title="Short Name", description="Short name for the futures market.")
    identifiers: List[AssetIdentifier] | None = Field(default=None, title="Identifiers", description="The identifiers associated with the futures market.")
    group: GroupId | str | None = Field(default=None, description="Identifier of the group which can access this dataset.")
    contract_root: str | None = Field(default=None, title="Contract Root", description="The futures contract root symbol (e.g., ES, CL, NQ).")
    primary_exchange: ExchangeId | str | ExchangeModel | None = Field(
        default=None, title="Primary Exchange", description="The primary exchange where the futures market is traded."
    )
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")
    contract_specification: FuturesContractSpecificationModel | None = Field(
        default=None, title="Contract Specification", description="Detailed contract specifications including size, tick, trading hours, etc."
    )
    contact_info: ContactInfoModel | None = Field(
        default=None, title="Contact Info", description="Contact information including links to exchange contract specifications."
    )

    semantic_type: Literal["FUTURES_MARKET"] = "FUTURES_MARKET"

    class Config:
        json_schema_extra = {
            "title": "Futures Market",
            "description": "A futures market represents the standardized specifications for a class of futures contracts, defining the underlying asset, contract size, tick size, delivery terms, and trading venue. It serves as the template for individual futures contracts with specific expiration dates.",
            "example": {
                "id": "ES",
                "version": "7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e",
                "name": "E-Mini S&P 500 Futures",
                "description": "S&P 500 E-Mini Futures Market",
                "shortName": "ES",
                "identifiers": [{"value": "ES", "type": "TICKER"}, {"value": "ES Index", "type": "BBG_CODE"}, {"value": "BBG000DQGR23", "type": "FIGI"}],
                "group": "FLOAT_PLATFORM_MEMBERS",
                "semanticType": "FUTURES_MARKET",
                "classification": {"assetClass": "EQUITY", "marketSector": "INDEX", "assetType": "FUTURE"},
                "contractRoot": "ES",
                "primaryExchange": "XCME",
            },
        }


class FutureModel(SecurityBaseModel):
    """
    Future

    A specific futures contract instance for a given expiry date (e.g. ESH25 for
    S&P 500 E-Mini March 2025). References a FuturesMarket for standardized contract
    specifications. Identified by exchange ticker, Bloomberg code, and FIGI.
    """

    __resource_id__ = FutureId
    __uri_path__ = "assets/futures"

    currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Currency", description="The currency of the future.")
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")
    exchange: ExchangeId | str | ExchangeModel | None = Field(default=None, title="Exchange", description="The exchange where the future is traded.")
    futures_market: FuturesMarketId | str | FuturesMarketModel | None = Field(
        default=None, title="Futures Market", description="The futures market that defines this contract's specifications."
    )
    expiration_date: date | None = Field(default=None, title="Expiration Date", description="The expiration/maturity date of the futures contract.")

    semantic_type: Literal["FUTURE"] = "FUTURE"

    class Config:
        json_schema_extra = {
            "title": "Future",
            "description": "A futures contract is a standardized legal agreement to buy or sell a specific asset at a predetermined price at a specified time in the future. Futures are traded on exchanges and are used for hedging risk or speculative purposes across various asset classes including equities, commodities, currencies, and interest rates.",
            "example": {
                "id": "3f8e9d2a1b4c5e7f9a0d1c2b3a4e5f6d",
                "version": "1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d",
                "name": "ES1 Comdty",
                "description": "S&P 500 E-Mini Futures March 2025",
                "shortName": "ESH25",
                "identifiers": [
                    {"value": "ESH25", "type": "TICKER"},
                    {"value": "ESH25 Comdty", "type": "BBG_CODE"},
                    {"value": "BBG00ZN8NTS0", "type": "FIGI"},
                ],
                "group": "FLOAT_PLATFORM_MEMBERS",
                "semanticType": "FUTURE",
                "classification": {"assetClass": "EQUITY", "marketSector": "INDEX", "assetType": "FUTURE"},
                "currency": "USD",
                "exchange": "XCME",
                "futuresMarket": "XCME_ES",
                "expirationDate": "2025-03-21",
            },
        }
