# pyright: basic

"""
Bond Enums

Bond-specific enumeration types.
Includes enums adapted from ISDA CDM for debt instrument classification.
"""

from float_sdk.float_api.serialization.model import DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


######################################################################################
## ISDA CDM Enums (adapted from isda_cdm.distribution.base.staticdata.asset.common.enum)
######################################################################################


class IssuerType(DisplayEnum):
    """
    Issuer Type

    Identifies the type of entity issuing the asset.
    Adapted from ISDA CDM.
    """

    SUPRA_NATIONAL = "SUPRA_NATIONAL"
    SOVEREIGN_CENTRAL_BANK = "SOVEREIGN_CENTRAL_BANK"
    QUASI_GOVERNMENT = "QUASI_GOVERNMENT"
    REGIONAL_GOVERNMENT = "REGIONAL_GOVERNMENT"
    CORPORATE = "CORPORATE"
    FUND = "FUND"
    SPECIAL_PURPOSE_VEHICLE = "SPECIAL_PURPOSE_VEHICLE"

    def display_names(self) -> dict[str, str]:
        return {
            "SUPRA_NATIONAL": "Supra National",
            "SOVEREIGN_CENTRAL_BANK": "Sovereign / Central Bank",
            "QUASI_GOVERNMENT": "Quasi Government",
            "REGIONAL_GOVERNMENT": "Regional Government",
            "CORPORATE": "Corporate",
            "FUND": "Fund",
            "SPECIAL_PURPOSE_VEHICLE": "Special Purpose Vehicle",
        }


class DebtClass(DisplayEnum):
    """
    Debt Class

    Identifies the type of debt instrument.
    Adapted from ISDA CDM.
    """

    VANILLA = "VANILLA"
    ASSET_BACKED = "ASSET_BACKED"
    CONVERTIBLE = "CONVERTIBLE"
    HOLDER_CONVERTIBLE = "HOLDER_CONVERTIBLE"
    HOLDER_EXCHANGEABLE = "HOLDER_EXCHANGEABLE"
    ISSUER_CONVERTIBLE = "ISSUER_CONVERTIBLE"
    ISSUER_EXCHANGEABLE = "ISSUER_EXCHANGEABLE"
    REG_CAP = "REG_CAP"
    STRUCTURED = "STRUCTURED"

    def display_names(self) -> dict[str, str]:
        return {
            "VANILLA": "Vanilla",
            "ASSET_BACKED": "Asset Backed",
            "CONVERTIBLE": "Convertible",
            "HOLDER_CONVERTIBLE": "Holder Convertible",
            "HOLDER_EXCHANGEABLE": "Holder Exchangeable",
            "ISSUER_CONVERTIBLE": "Issuer Convertible",
            "ISSUER_EXCHANGEABLE": "Issuer Exchangeable",
            "REG_CAP": "Regulatory Capital",
            "STRUCTURED": "Structured",
        }


class DebtSeniority(DisplayEnum):
    """
    Debt Seniority

    Order of repayment in event of sale or bankruptcy of issuer or guarantor.
    Adapted from ISDA CDM.
    """

    SECURED = "SECURED"
    SENIOR = "SENIOR"
    SUBORDINATED = "SUBORDINATED"

    def display_names(self) -> dict[str, str]:
        return {
            "SECURED": "Secured",
            "SENIOR": "Senior",
            "SUBORDINATED": "Subordinated",
        }


class DebtInterest(DisplayEnum):
    """
    Debt Interest

    General rule for periodic interest rate payment.
    Adapted from ISDA CDM.
    """

    FIXED = "FIXED"
    FLOATING = "FLOATING"
    INFLATION_LINKED = "INFLATION_LINKED"
    INDEX_LINKED = "INDEX_LINKED"
    INVERSE_FLOATING = "INVERSE_FLOATING"
    ZERO_COUPON = "ZERO_COUPON"
    INTEREST_ONLY = "INTEREST_ONLY"
    OTHER_STRUCTURED = "OTHER_STRUCTURED"

    def display_names(self) -> dict[str, str]:
        return {
            "FIXED": "Fixed",
            "FLOATING": "Floating",
            "INFLATION_LINKED": "Inflation Linked",
            "INDEX_LINKED": "Index Linked",
            "INVERSE_FLOATING": "Inverse Floating",
            "ZERO_COUPON": "Zero Coupon",
            "INTEREST_ONLY": "Interest Only",
            "OTHER_STRUCTURED": "Other Structured",
        }


class DebtPrincipal(DisplayEnum):
    """
    Debt Principal

    General rule for repayment of principal.
    Adapted from ISDA CDM.
    """

    BULLET = "BULLET"
    CALLABLE = "CALLABLE"
    PUTTABLE = "PUTTABLE"
    AMORTISING = "AMORTISING"
    INFLATION_LINKED = "INFLATION_LINKED"
    INDEX_LINKED = "INDEX_LINKED"
    PRINCIPAL_ONLY = "PRINCIPAL_ONLY"
    OTHER_STRUCTURED = "OTHER_STRUCTURED"

    def display_names(self) -> dict[str, str]:
        return {
            "BULLET": "Bullet",
            "CALLABLE": "Callable",
            "PUTTABLE": "Puttable",
            "AMORTISING": "Amortising",
            "INFLATION_LINKED": "Inflation Linked",
            "INDEX_LINKED": "Index Linked",
            "PRINCIPAL_ONLY": "Principal Only",
            "OTHER_STRUCTURED": "Other Structured",
        }


######################################################################################
## Bond-Specific Enums
######################################################################################


class BondPartyRole(DisplayEnum):
    """
    Bond Party Role

    Roles that parties play with respect to a bond issuance.
    """

    ISSUER = "ISSUER"
    GUARANTOR = "GUARANTOR"
    PAYING_AGENT = "PAYING_AGENT"
    FISCAL_AGENT = "FISCAL_AGENT"
    TRUSTEE = "TRUSTEE"
    REGISTRAR = "REGISTRAR"
    TRANSFER_AGENT = "TRANSFER_AGENT"
    CALCULATION_AGENT = "CALCULATION_AGENT"

    def display_names(self) -> dict[str, str]:
        return {
            "ISSUER": "Issuer",
            "GUARANTOR": "Guarantor",
            "PAYING_AGENT": "Paying Agent",
            "FISCAL_AGENT": "Fiscal Agent",
            "TRUSTEE": "Trustee",
            "REGISTRAR": "Registrar",
            "TRANSFER_AGENT": "Transfer Agent",
            "CALCULATION_AGENT": "Calculation Agent",
        }


class BondStatus(DisplayEnum):
    """
    Bond Status

    Lifecycle status of a bond.
    """

    ACTIVE = "ACTIVE"
    MATURED = "MATURED"
    CALLED = "CALLED"
    DEFAULTED = "DEFAULTED"
    TENDERED = "TENDERED"
    CONVERTED = "CONVERTED"

    def display_names(self) -> dict[str, str]:
        return {
            "ACTIVE": "Active",
            "MATURED": "Matured",
            "CALLED": "Called",
            "DEFAULTED": "Defaulted",
            "TENDERED": "Tendered",
            "CONVERTED": "Converted",
        }


class CreditRatingAgency(DisplayEnum):
    """
    Credit Rating Agency

    Credit rating agencies.
    Adapted from ISDA CDM.
    """

    AM_BEST = "AM_BEST"
    CBRS = "CBRS"
    DBRS = "DBRS"
    FITCH = "FITCH"
    JAPANAGENCY = "JAPANAGENCY"
    KROLL = "KROLL"
    MOODYS = "MOODYS"
    RATING_AND_INVESTMENT_INFORMATION = "RATING_AND_INVESTMENT_INFORMATION"
    STANDARD_AND_POORS = "STANDARD_AND_POORS"

    def display_names(self) -> dict[str, str]:
        return {
            "AM_BEST": "A.M. Best",
            "CBRS": "Canadian Bond Rating Service",
            "DBRS": "DBRS",
            "FITCH": "Fitch",
            "JAPANAGENCY": "Japan Credit Rating Agency",
            "KROLL": "Kroll",
            "MOODYS": "Moody's",
            "RATING_AND_INVESTMENT_INFORMATION": "R&I",
            "STANDARD_AND_POORS": "S&P",
        }


class CreditRatingOutlook(DisplayEnum):
    """
    Credit Rating Outlook

    Credit rating outlook indicators.
    Adapted from ISDA CDM.
    """

    POSITIVE = "POSITIVE"
    NEGATIVE = "NEGATIVE"
    STABLE = "STABLE"
    DEVELOPING = "DEVELOPING"

    def display_names(self) -> dict[str, str]:
        return {
            "POSITIVE": "Positive",
            "NEGATIVE": "Negative",
            "STABLE": "Stable",
            "DEVELOPING": "Developing",
        }


class CreditRatingCreditWatch(DisplayEnum):
    """
    Credit Rating Credit Watch

    Credit watch status.
    Adapted from ISDA CDM.
    """

    POSITIVE = "POSITIVE"
    NEGATIVE = "NEGATIVE"
    DEVELOPING = "DEVELOPING"

    def display_names(self) -> dict[str, str]:
        return {
            "POSITIVE": "Positive",
            "NEGATIVE": "Negative",
            "DEVELOPING": "Developing",
        }
