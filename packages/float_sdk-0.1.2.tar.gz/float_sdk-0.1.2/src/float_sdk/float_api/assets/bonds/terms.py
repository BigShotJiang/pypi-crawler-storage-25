# pyright: basic

"""
Bond Terms

Nested term models for bonds, organized by functional area.
These models can be used across all bond types (corporate, sovereign, agency, etc.).
"""

from datetime import date
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.cashflows import CalculationDateScheduleModel, PaymentDateScheduleModel, ResetDatesSpecificationModel
from float_sdk.float_api.assets.bonds.enums import (
    BondPartyRole,
    CreditRatingAgency,
    CreditRatingOutlook,
    DebtClass,
    DebtInterest,
    DebtPrincipal,
    DebtSeniority,
    IssuerType,
)
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.rates.rates import FixedRateModel, FloatingRateModel
from float_sdk.float_api.base.references import CurrencyId, EntityId
from float_sdk.float_api.datetime.conventions import DayCountConvention
from float_sdk.float_api.organizations.legal import EntityModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


######################################################################################
## 1. Bond Classification
######################################################################################


class BondClassificationModel(DataModel):
    """
    Bond Classification

    Classifies the bond by issuer type, debt structure, and capital position.
    Uses ISDA CDM enums for standardization.
    """

    issuer_type: IssuerType | None = Field(
        default=None,
        title="Issuer Type",
        description="Classification of the issuing entity: SOVEREIGN for government bonds, "
        "CORPORATE for company debt, AGENCY for government-sponsored enterprises, "
        "MUNICIPAL for local government bonds, or SUPRANATIONAL for multilateral institutions.",
    )
    debt_class: DebtClass | None = Field(
        default=None,
        title="Debt Class",
        description="Structural classification of the debt: VANILLA for standard bonds, "
        "CONVERTIBLE for bonds convertible to equity, ASSET_BACKED for securitized debt, "
        "or COVERED for bonds backed by a cover pool.",
    )
    seniority: DebtSeniority | None = Field(
        default=None,
        title="Seniority",
        description="Priority of claim in the capital structure: SENIOR for highest priority, "
        "SUBORDINATED for lower priority claims, or MEZZANINE for intermediate positions. "
        "Determines recovery rates in default scenarios.",
    )
    secured: bool | None = Field(
        default=None,
        title="Secured",
        description="Indicates whether the bond is backed by specific collateral or assets. "
        "Secured bonds have higher recovery rates but typically lower yields.",
    )

    semantic_type: Literal["BOND_CLASSIFICATION"] = "BOND_CLASSIFICATION"


######################################################################################
## 2. Bond Parties
######################################################################################


class BondPartyRoleModel(DataModel):
    """
    Bond Party Role

    A party involved with the bond and their role.
    Uses role-based design (not hardcoded entity types) to support:
    - Sovereigns: Issuer = Government entity
    - SPVs: Issuer = SPV, Guarantor = Parent
    - Guaranteed bonds: Explicit guarantor relationship
    """

    entity: EntityId | str | EntityModel | None = Field(
        default=None,
        title="Entity",
        description="Reference to the legal entity involved with the bond. Can be specified as an EntityId, entity name string, or full EntityModel.",
    )
    role: BondPartyRole | None = Field(
        default=None,
        title="Role",
        description="The party's role in the bond transaction: ISSUER for the borrower, "
        "GUARANTOR for credit enhancement provider, TRUSTEE for bondholder representative, "
        "or PAYING_AGENT for payment processing.",
    )

    semantic_type: Literal["BOND_PARTY_ROLE"] = "BOND_PARTY_ROLE"


class BondPartiesModel(DataModel):
    """
    Bond Parties

    All parties involved with the bond issuance.
    """

    parties: list[BondPartyRoleModel] | None = Field(
        default=None,
        title="Parties",
        description="All parties involved in the bond structure with their respective roles. "
        "Typically includes the issuer, and may include guarantors, trustees, and paying agents.",
    )

    semantic_type: Literal["BOND_PARTIES"] = "BOND_PARTIES"


######################################################################################
## 3. Issue Information
######################################################################################


class IssueTermsModel(DataModel):
    """
    Issue Information

    Static information from the bond's original issuance.
    """

    issue_date: date | None = Field(
        default=None,
        title="Issue Date",
        description="Settlement date of the primary issuance when bonds were first delivered to investors.",
    )
    issue_price: float | None = Field(
        default=None,
        title="Issue Price",
        description="Original offering price as a percentage of par value. For example, 99.5 means 99.5% of face value, or $995 per $1000 bond.",
    )
    original_face_amount: float | None = Field(
        default=None,
        title="Original Face Amount",
        description="Total aggregate principal amount of the bond issuance in denomination currency.",
    )
    amount_outstanding: float | None = Field(
        default=None,
        title="Amount Outstanding",
        description="Current outstanding principal amount, which may differ from original face "
        "for amortizing bonds, sinking fund provisions, or partial redemptions.",
    )
    first_coupon_date: date | None = Field(
        default=None,
        title="First Coupon Date",
        description="Payment date of the first coupon. May result in a short or long first coupon period if different from regular coupon schedule.",
    )
    dated_date: date | None = Field(
        default=None,
        title="Dated Date",
        description="Date from which interest begins to accrue, which may precede the issue date for bonds issued with accrued interest.",
    )

    semantic_type: Literal["BOND_ISSUE_INFORMATION"] = "BOND_ISSUE_INFORMATION"


######################################################################################
## 4. Bond Denomination
######################################################################################


class BondDenominationModel(DataModel):
    """
    Bond Denomination

    Trading and settlement denomination details.
    """

    face_value: float | None = Field(
        default=None,
        title="Face Value",
        description="Par value per bond unit in denomination currency. "
        "Standard values are 1000 (USD corporates), 100 (EUR sovereigns), or 1000000 (institutional).",
    )
    currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Currency",
        description="Currency in which the bond is denominated and coupon/principal payments are made.",
    )
    minimum_denomination: float | None = Field(
        default=None,
        title="Minimum Denomination",
        description="Minimum face value for trading or settlement. For example, $2000 minimum for many corporate bonds, €100000 for some institutional bonds.",
    )
    denomination_increment: float | None = Field(
        default=None,
        title="Denomination Increment",
        description="Permissible increment above minimum denomination for trading. Trades must be in minimum plus whole multiples of this increment.",
    )

    semantic_type: Literal["BOND_DENOMINATION"] = "BOND_DENOMINATION"


######################################################################################
## 5. Coupon Terms
######################################################################################


class CouponTermsModel(DataModel):
    """
    Coupon Terms

    Coupon payment mechanics for the bond.
    Aligned with IR Swap infrastructure for consistent cashflow generation.
    """

    coupon_type: DebtInterest | None = Field(
        default=None,
        title="Coupon Type",
        description="Interest payment structure: FIXED for constant rate, FLOATING for index-linked rate, "
        "ZERO_COUPON for discount bonds, INFLATION_LINKED for real return bonds, "
        "or STEP_UP for bonds with scheduled rate increases.",
    )

    rate: FixedRateModel | FloatingRateModel | None = Field(
        default=None,
        title="Rate",
        description="Rate specification containing either a FixedRate (with rate as annual decimal, "
        "e.g., 0.05 for 5%) or FloatingRate (with index reference and spread in basis points).",
    )

    day_count_convention: DayCountConvention | None = Field(
        default=None,
        title="Day Count Convention",
        description="Convention for calculating accrued interest: ACT_360, ACT_365_FIXED, "
        "30_360, ACT_ACT_ISDA, etc. Determines the day count fraction for coupon periods.",
    )

    calculation_period_dates: CalculationDateScheduleModel | None = Field(
        default=None,
        title="Calculation Period Dates",
        description="Schedule defining interest accrual periods. Optional for vanilla bonds "
        "where periods are derived from payment frequency and maturity. Required for bonds "
        "with irregular periods or complex structures.",
    )
    payment_date_schedule: PaymentDateScheduleModel | None = Field(
        default=None,
        title="Payment Date Schedule",
        description="Schedule specification for coupon payment dates, including frequency, business day adjustment rules, and payment date roll conventions.",
    )
    reset_dates_specification: ResetDatesSpecificationModel | None = Field(
        default=None,
        title="Reset Dates Specification",
        description="For floating rate notes: specification of rate reset dates relative to "
        "calculation periods, including reset frequency, fixing lag, and averaging rules.",
    )

    semantic_type: Literal["BOND_COUPON_TERMS"] = "BOND_COUPON_TERMS"


######################################################################################
## 6. Redemption Terms
######################################################################################


class CallPutScheduleEntryModel(DataModel):
    """
    Call/Put Schedule Entry

    A single entry in a call or put schedule.
    """

    effective_date: date | None = Field(
        default=None,
        title="Effective Date",
        description="Date from which this call or put price becomes effective. "
        "The issuer (call) or holder (put) may exercise at this price on or after this date.",
    )
    price: float | None = Field(
        default=None,
        title="Price",
        description="Exercise price as a percentage of par value. For example, 104.25 means "
        "the bond can be redeemed at 104.25% of face value (a 4.25 point premium to par).",
    )

    semantic_type: Literal["CALL_PUT_SCHEDULE_ENTRY"] = "CALL_PUT_SCHEDULE_ENTRY"


class RedemptionTermsModel(DataModel):
    """
    Redemption Terms

    Maturity and early redemption features.
    """

    maturity_date: date | None = Field(
        default=None,
        title="Maturity Date",
        description="Final maturity date when outstanding principal is repaid. For perpetual bonds, this field is null.",
    )
    redemption_type: DebtPrincipal | None = Field(
        default=None,
        title="Redemption Type",
        description="Principal repayment structure: BULLET for single payment at maturity, "
        "AMORTISING for scheduled principal reductions, CALLABLE for issuer redemption option, "
        "PUTTABLE for holder redemption option, or SINKING_FUND for mandatory redemption schedule.",
    )

    callable: bool | None = Field(
        default=None,
        title="Callable",
        description="Indicates whether the issuer has the right to redeem the bond prior to maturity. If true, see call_schedule or make_whole_call for terms.",
    )
    call_schedule: list[CallPutScheduleEntryModel] | None = Field(
        default=None,
        title="Call Schedule",
        description="Discrete schedule of call dates and prices, typically declining toward par "
        "as the bond approaches maturity. Each entry specifies when a new call price becomes effective.",
    )

    puttable: bool | None = Field(
        default=None,
        title="Puttable",
        description="Indicates whether the bondholder has the right to require early redemption. If true, see put_schedule for terms.",
    )
    put_schedule: list[CallPutScheduleEntryModel] | None = Field(
        default=None,
        title="Put Schedule",
        description="Schedule of dates when bondholders may put the bond back to the issuer, with the corresponding redemption prices.",
    )

    make_whole_call: bool | None = Field(
        default=None,
        title="Make-Whole Call",
        description="Indicates a make-whole call provision where the issuer must pay the present value "
        "of remaining cashflows discounted at a treasury rate plus spread, compensating holders fully.",
    )
    make_whole_spread: float | None = Field(
        default=None,
        title="Make-Whole Spread",
        description="Spread over the reference treasury rate used to discount remaining cashflows "
        "for make-whole call calculations. Expressed as a decimal (e.g., 0.0015 for 15 basis points).",
    )

    semantic_type: Literal["BOND_REDEMPTION_TERMS"] = "BOND_REDEMPTION_TERMS"


######################################################################################
## 7. Bond Ratings
######################################################################################


class CreditRatingModel(DataModel):
    """
    Credit Rating

    A credit rating from a single agency.
    """

    agency: CreditRatingAgency | None = Field(
        default=None,
        title="Agency",
        description="Credit rating agency identifier: STANDARD_AND_POORS, MOODYS, FITCH, DBRS, or OTHER for non-major agencies.",
    )
    agency_entity: EntityId | str | EntityModel | None = Field(
        default=None,
        title="Agency Entity",
        description="Reference to the rating agency as a legal entity, useful for non-standard agencies or when additional agency details are needed.",
    )
    rating: str | None = Field(
        default=None,
        title="Rating",
        description="The credit rating in the agency's notation. Examples: 'AAA', 'AA+', 'A-' (S&P/Fitch) "
        "or 'Aaa', 'Aa1', 'A3' (Moody's). Investment grade is BBB-/Baa3 or higher.",
    )
    outlook: CreditRatingOutlook | None = Field(
        default=None,
        title="Outlook",
        description="Forward-looking assessment of rating direction: POSITIVE (potential upgrade), "
        "NEGATIVE (potential downgrade), STABLE (no change expected), or DEVELOPING (uncertain direction).",
    )
    rating_date: date | None = Field(
        default=None,
        title="Rating Date",
        description="Date when the rating was assigned or last affirmed by the agency.",
    )

    semantic_type: Literal["CREDIT_RATING"] = "CREDIT_RATING"


class BondRatingsModel(DataModel):
    """
    Bond Ratings

    Credit ratings for the bond from various agencies.
    """

    ratings: list[CreditRatingModel] | None = Field(
        default=None,
        title="Ratings",
        description="Collection of credit ratings from multiple agencies. Most bonds have ratings "
        "from at least two major agencies (S&P, Moody's, Fitch) for investor due diligence.",
    )

    semantic_type: Literal["BOND_RATINGS"] = "BOND_RATINGS"
