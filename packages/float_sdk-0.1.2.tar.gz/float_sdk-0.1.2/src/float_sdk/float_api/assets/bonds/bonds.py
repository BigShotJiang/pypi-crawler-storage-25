# pyright: basic

"""
Bond Model

Main bond asset model that aggregates all term sections.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.base import (
    AssetClass,
    AssetClassificationModel,
    AssetType,
    MarketSector,
    SecurityBaseModel,
)
from float_sdk.float_api.assets.bonds.enums import BondStatus
from float_sdk.float_api.assets.bonds.terms import (
    BondClassificationModel,
    BondDenominationModel,
    BondPartiesModel,
    BondRatingsModel,
    CouponTermsModel,
    IssueTermsModel,
    RedemptionTermsModel,
)
from float_sdk.float_api.base.references import BondId

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class BondModel(SecurityBaseModel):
    """
    Bond

    Represents a fixed income security with standardized terms. Supports all bond types:
    corporate, sovereign, agency, municipal, and structured. Structure follows industry
    standards (Bloomberg, Refinitiv) and the ISDA CDM debt instrument taxonomy for
    classification, seniority, and coupon type enumerations.

    Identifiers (ISIN, CUSIP, SEDOL, etc.) are inherited from ObservableModel.
    """

    __resource_id__ = BondId
    __uri_path__ = "assets/bonds"

    # Default classification for bonds
    classification: AssetClassificationModel | None = Field(
        default_factory=lambda: AssetClassificationModel(
            asset_class=AssetClass.CREDIT,
            market_sector=MarketSector.FIXED_INCOME,
            asset_type=AssetType.BOND,
        ),
        title="Classification",
        description="Asset classification.",
    )

    ######################################################################################
    ## Bond Terms Section
    ######################################################################################

    bond_classification: BondClassificationModel | None = Field(
        default=None,
        title="Bond Classification",
        description="Issuer type, debt class, seniority classification.",
    )

    parties: BondPartiesModel | None = Field(
        default=None,
        title="Parties",
        description="Parties involved (issuer, guarantor, agents, etc.).",
    )

    issue_information: IssueTermsModel | None = Field(
        default=None,
        title="Issue Information",
        description="Original issuance details (date, price, amounts).",
    )

    denomination: BondDenominationModel | None = Field(
        default=None,
        title="Denomination",
        description="Face value, currency, and trading denomination.",
    )

    coupon_terms: CouponTermsModel | None = Field(
        default=None,
        title="Coupon Terms",
        description="Coupon type, rate, frequency, and day count.",
    )

    redemption_terms: RedemptionTermsModel | None = Field(
        default=None,
        title="Redemption Terms",
        description="Maturity, call/put features, and early redemption.",
    )

    ratings: BondRatingsModel | None = Field(
        default=None,
        title="Ratings",
        description="Credit ratings from various agencies.",
    )

    # Lifecycle status
    status: BondStatus | None = Field(
        default=None,
        title="Status",
        description="Lifecycle status (Active, Matured, Called, Defaulted, etc.).",
    )

    semantic_type: Literal["BOND"] = "BOND"
