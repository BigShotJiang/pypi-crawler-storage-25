# pyright: basic

"""
Bond Assets

Bond securities and related models.
"""

from float_sdk.float_api.assets.bonds.bonds import BondModel
from float_sdk.float_api.assets.bonds.enums import (
    BondPartyRole,
    BondStatus,
    CreditRatingAgency,
    CreditRatingCreditWatch,
    CreditRatingOutlook,
    DebtClass,
    DebtInterest,
    DebtPrincipal,
    DebtSeniority,
    IssuerType,
)
from float_sdk.float_api.assets.bonds.terms import (
    BondClassificationModel,
    BondDenominationModel,
    BondPartiesModel,
    BondPartyRoleModel,
    BondRatingsModel,
    CallPutScheduleEntryModel,
    CouponTermsModel,
    CreditRatingModel,
    IssueTermsModel,
    RedemptionTermsModel,
)

__all__ = [
    # Main model
    "BondModel",
    # Enums
    "IssuerType",
    "DebtClass",
    "DebtSeniority",
    "DebtInterest",
    "DebtPrincipal",
    "BondPartyRole",
    "BondStatus",
    "CreditRatingAgency",
    "CreditRatingOutlook",
    "CreditRatingCreditWatch",
    # Term models
    "BondClassificationModel",
    "BondPartyRoleModel",
    "BondPartiesModel",
    "IssueTermsModel",
    "BondDenominationModel",
    "CouponTermsModel",
    "CallPutScheduleEntryModel",
    "RedemptionTermsModel",
    "CreditRatingModel",
    "BondRatingsModel",
]
