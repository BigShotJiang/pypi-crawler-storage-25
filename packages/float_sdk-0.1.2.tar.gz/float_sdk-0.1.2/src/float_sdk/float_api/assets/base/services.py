#!/usr/bin/env python
# pyright: strict

"""
Software Services

Models for technology and software service assets that can be referenced
within the platform's asset framework.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel
from float_sdk.float_api.base.references import GroupId


class ServiceModel(NamedResourceModel):
    short_name: str | None = Field(default=None, title="Short Name", description="Short name for the observable.")
    group: GroupId | str | None = Field(default=None, description="Identifier of the group which can access this dataset.")


class SoftwareServiceModel(ServiceModel):
    semantic_type: Literal["SOFTWARE_SERVICE"] = "SOFTWARE_SERVICE"
