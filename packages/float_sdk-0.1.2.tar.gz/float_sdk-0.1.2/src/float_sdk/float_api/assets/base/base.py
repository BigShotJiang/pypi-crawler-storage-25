#!/usr/bin/env python
# pyright: basic

"""
Financial Observables and Assets

Base models for financial observables and tradable assets. Provides the foundational
classification taxonomy (asset class, market sector, asset type), identifier framework,
and base observable/security models used across all asset types.
"""

from datetime import date, datetime
from enum import Enum
from typing import Annotated, Any, List, Literal, Union

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel, ResourceIdentifierModel
from float_sdk.float_api.base.identifiers import AssetIdentifierType as AssetIdentifierType
from float_sdk.float_api.base.measures.text import FloatId
from float_sdk.float_api.base.references import GroupId
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class AssetIdentifier(ResourceIdentifierModel):
    type: AssetIdentifierType = Field(..., title="Type", description="The type of identifier.")


class AssetClass(DisplayEnum):
    COMMODITY = "COMMODITY"
    CREDIT = "CREDIT"
    EQUITY = "EQUITY"
    FOREIGN_EXCHANGE = "FOREIGN_EXCHANGE"
    INTEREST_RATE = "INTEREST_RATE"
    MONEY_MARKET = "MONEY_MARKET"
    CROSS_ASSET = "CROSS_ASSET"

    def display_names(self) -> dict[str, str]:
        return {
            "COMMODITY": "Commodity",
            "CREDIT": "Credit",
            "EQUITY": "Equity",
            "FOREIGN_EXCHANGE": "Foreign Exchange",
            "INTEREST_RATE": "Interest Rate",
            "MONEY_MARKET": "Money Market",
            "CROSS_ASSET": "Cross Asset",
        }


class MarketSector(DisplayEnum):
    COMMOD = "COMMOD"
    CRYPTO = "CRYPTO"
    CURRENCY = "CURRENCY"
    EQUITY = "EQUITY"
    FIXED_INCOME = "FIXED_INCOME"
    INDEX = "INDEX"
    FUTURE = "FUTURE"
    OPTION = "OPTION"
    RATE = "RATE"

    def display_names(self) -> dict[str, str]:
        return {
            "COMMOD": "Commod",
            "CRYPTO": "Crypto",
            "CURRENCY": "Currency",
            "EQUITY": "Equity",
            "FIXED_INCOME": "Fixed Income",
            "INDEX": "Index",
            "FUTURE": "Future",
            "OPTION": "Option",
            "RATE": "Rate",
        }


class AssetType(DisplayEnum):
    #
    # Currencies
    #
    CURRENCY = "CURRENCY"
    DIGITAL_ASSET = "DIGITAL_ASSET"
    #
    # Commodities
    #
    COMMODITY = "COMMODITY"
    #
    # FX
    #
    EXCHANGE_RATE = "EXCHANGE_RATE"
    #
    # Rates
    #
    INTEREST_RATE_INDEX = "INTEREST_RATE_INDEX"
    INFLATION_RATE_INDEX = "INFLATION_RATE_INDEX"
    INTEREST_RATE_OPTION = "INTEREST_RATE_OPTION"
    INFLATION_RATE_OPTION = "INFLATION_RATE_OPTION"
    INTEREST_RATE_SPREAD = "INTEREST_RATE_SPREAD"
    SETTLEMENT_RATE_OPTION = "SETTLEMENT_RATE_OPTION"
    RATE_SOURCE = "RATE_SOURCE"
    #
    # Stocks
    #
    COMMON_STOCK = "COMMON_STOCK"
    PREFERRED_STOCK = "PREFERRED_STOCK"
    #
    # Funds
    #
    EXCHANGE_TRADED_FUND = "EXCHANGE_TRADED_FUND"
    MONEY_MARKET_FUND = "MONEY_MARKET_FUND"
    MUTUAL_FUND = "MUTUAL_FUND"
    #
    # Indices
    #
    INDEX = "INDEX"
    CUSTOM_INDEX = "CUSTOM_INDEX"
    CUSTOM_BASKET = "CUSTOM_BASKET"
    #
    # Listed derivatives
    #
    FUTURES_MARKET = "FUTURES_MARKET"
    WARRANT = "WARRANT"
    FUTURE = "FUTURE"
    OPTION = "OPTION"
    #
    # Fixed Income
    #
    BOND = "BOND"
    #
    # Services
    #
    SOFTWARE_SERVICE = "SOFTWARE_SERVICE"

    def display_names(self) -> dict[str, str]:
        return {
            "CURRENCY": "Currency",
            "DIGITAL_ASSET": "Digital Asset",
            "COMMODITY": "Commodity",
            "EXCHANGE_RATE": "Exchange Rate",
            "INTEREST_RATE_INDEX": "Interest Rate Index",
            "INFLATION_RATE_INDEX": "Inflation Rate Index",
            "INTEREST_RATE_OPTION": "Interest Rate Option",
            "INFLATION_RATE_OPTION": "Inflation Rate Option",
            "INTEREST_RATE_SPREAD": "Interest Rate Spread",
            "SETTLEMENT_RATE_OPTION": "Settlement Rate Option",
            "RATE_SOURCE": "Rate Source",
            "COMMON_STOCK": "Common Stock",
            "PREFERRED_STOCK": "Preferred Stock",
            "EXCHANGE_TRADED_FUND": "Exchange Traded Fund",
            "MONEY_MARKET_FUND": "Money Market Fund",
            "MUTUAL_FUND": "Mutual Fund",
            "FUTURES_MARKET": "Futures Market",
            "WARRANT": "Warrant",
            "FUTURE": "Future",
            "OPTION": "Option",
            "INDEX": "Index",
            "CUSTOM_INDEX": "Custom Index",
            "CUSTOM_BASKET": "Custom Basket",
            "BOND": "Bond",
            "SOFTWARE_SERVICE": "Software Service",
        }


class AssetClassificationModel(DataModel):
    asset_class: AssetClass = Field(..., title="Asset Class", description="The asset class, which categorises top level organisational holdings.")
    market_sector: MarketSector = Field(..., title="Market Sector", description="The market sector, which categorises the asset.")
    asset_type: AssetType = Field(..., title="Asset Type", description="The asset type, which categorises the asset.")


class ObservableModel(NamedResourceModel):
    short_name: str | None = Field(default=None, title="Short Name", description="Short name for the observable.")
    identifiers: List[AssetIdentifier] | None = Field(default=None, title="Identifiers", description="The identifiers associated with the index.")
    group: GroupId | str | None = Field(default=None, description="Identifier of the group which can access this dataset.")

    semantic_type: Literal["OBSERVABLE"] = "OBSERVABLE"

    def get_identifier(self, t: AssetIdentifierType) -> str | None:
        if not self.identifiers:
            return None
        for i in self.identifiers:
            if i.type == t:
                return i.value
        return None


class SecurityBaseModel(ObservableModel):
    """
    Base model for tradable securities (equities, bonds, futures, options, etc.)

    Securities are exchange-traded or OTC-traded assets with standardized terms
    and external identifiers (ISIN, CUSIP, SEDOL, FIGI, Bloomberg ticker, etc.).
    """

    pass


class ObservationStatus(Enum):
    """
    Whether a rate or price observation for a given date is known or still pending.
    """

    KNOWN = "KNOWN"
    UNKNOWN = "UNKNOWN"


class ObservationModel(DataModel):
    observable: str
    observation_date: date
    observation_time: datetime
    value: Any = None
    status: ObservationStatus


class AssetId(FloatId):
    asset_types: List[AssetType] | None = Field(default=None, title="Asset Types", description="List of available asset types for this identifier")
    semantic_type: Literal["ASSET_ID"] = "ASSET_ID"


AssetReferenceTypes = Annotated[
    Union[AssetId],
    Field(discriminator="semantic_type"),
]
