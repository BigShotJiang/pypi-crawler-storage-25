#!/usr/bin/env python
# pyright: basic

"""
Settlement Rate Options

Models and codes for FX settlement rate options used to determine fixing rates for
non-deliverable and cash-settled FX transactions. Settlement rate options are defined
in Annex A of the ISDA 1998 FX and Currency Option Definitions.
"""

from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.base import AssetClassificationModel, ObservableModel
from float_sdk.float_api.base.references import SettlementRateOptionId
from float_sdk.float_api.locations.location import TimeLocationModel
from float_sdk.float_api.organizations.contact import ContactInfoModel
from float_sdk.float_api.serialization.model import DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class SettlementType(DisplayEnum):
    """
    The enumeration values to specify how the option is to be settled when exercised.

    Attributes
    ----------
    CASH : The intrinsic value of the option will be delivered by way of a cash settlement
        amount determined, (i) by reference to the differential between the strike price and
        the settlement price; or (ii) in accordance with a bilateral agreement between the parties.
    PHYSICAL : The securities underlying the transaction will be delivered by (i) in the case of
        a call, the seller to the buyer, or (ii) in the case of a put, the buyer to the seller
        versus a settlement amount equivalent to the strike price per share.
    """

    CASH = "CASH"
    PHYSICAL = "PHYSICAL"
    # ELECTION = "ELECTION"
    # CASH_OR_PHYSICAL = "CASH_OR_PHYSICAL"
    DELIVERABLE = "DELIVERABLE"  # Deprecated, see below
    NON_DELIVERABLE = "NON_DELIVERABLE"  # Deprecated, see below

    def display_names(self) -> dict[str, str]:
        return {
            "CASH": "Cash",
            "PHYSICAL": "Physical",
            # "ELECTION": "Election",
            # "CASH_OR_PHYSICAL": "Cash or Physical",
            # "DELIVERABLE": "Deliverable",
            # "NON_DELIVERABLE": "Non-Deliverable",
        }


class DeterminationMethod(DisplayEnum):
    """
    Method for determining a valuation amount or date
    Attributes
    __________
    AGREED_INITIAL_PRICE : Agreed separately between the parties
    AS_SPECIFIED_IN_MASTER_CONFIRMATION : As specified in Master Confirmation.
    CALCULATION_AGENT : Determined by the Calculation Agent.
    CLOSING_PRICE : Official Closing Price.
    DIVIDEND_CURRENCY : Determined by the Currency of Equity Dividends.
    EXPIRING_CONTRACT_LEVEL : The initial Index Level is the level of the Expiring Contract as provided in the Master Confirmation.
    HEDGE_EXECUTION : Determined by the Hedging Party.
    ISSUER_PAYMENT_CURRENCY : Issuer Payment Currency.
    NAV : Net Asset Value.
    OPEN_PRICE : Opening Price of the Market.
    OSP_PRICE : OSP Price.
    SETTLEMENT_CURRENCY : Settlement Currency.
    STRIKE_DATE_DETERMINATION : Date on which the strike is determined in respect of a forward starting swap.
    TWAP_PRICE : Official TWAP Price.
    VALUATION_TIME : Price determined at valuation time.
    VWAP_PRICE : Official VWAP Price.
    """

    AGREED_INITIAL_PRICE = "AGREED_INITIAL_PRICE"
    AS_SPECIFIED_IN_MASTER_CONFIRMATION = "AS_SPECIFIED_IN_MASTER_CONFIRMATION"
    CALCULATION_AGENT = "CALCULATION_AGENT"
    CLOSING_PRICE = "CLOSING_PRICE"
    DIVIDEND_CURRENCY = "DIVIDEND_CURRENCY"
    EXPIRING_CONTRACT_LEVEL = "EXPIRING_CONTRACT_LEVEL"
    HEDGE_EXECUTION = "HEDGE_EXECUTION"
    ISSUER_PAYMENT_CURRENCY = "ISSUER_PAYMENT_CURRENCY"
    NAV = "NAV"
    OPEN_PRICE = "OPEN_PRICE"
    OSP_PRICE = "OSP_PRICE"
    SETTLEMENT_CURRENCY = "SETTLEMENT_CURRENCY"
    STRIKE_DATE_DETERMINATION = "STRIKE_DATE_DETERMINATION"
    TWAP_PRICE = "TWAP_PRICE"
    VALUATION_TIME = "VALUATION_TIME"
    VWAP_PRICE = "VWAP_PRICE"

    def display_names(self) -> dict[str, str]:
        return {
            "AGREED_INITIAL_PRICE": "Agreed Initial Price",
            "AS_SPECIFIED_IN_MASTER_CONFIRMATION": "As Specified in Master Confirmation",
            "CALCULATION_AGENT": "Calculation Agent",
            "CLOSING_PRICE": "Closing Price",
            "DIVIDEND_CURRENCY": "Dividend Currency",
            "EXPIRING_CONTRACT_LEVEL": "Expiring Contract Level",
            "HEDGE_EXECUTION": "Hedge Execution",
            "ISSUER_PAYMENT_CURRENCY": "Issuer Payment Currency",
            "NAV": "Net Asset Value (NAV)",
            "OPEN_PRICE": "Opening Price",
            "OSP_PRICE": "OSP Price",
            "SETTLEMENT_CURRENCY": "Settlement Currency",
            "STRIKE_DATE_DETERMINATION": "Strike Date Determination",
            "TWAP_PRICE": "TWAP Price",
            "VALUATION_TIME": "Valuation Time",
            "VWAP_PRICE": "VWAP Price",
        }


class SettlementRateOptionBaseModel(ObservableModel):
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")

    fixing_time: TimeLocationModel | None = Field(
        default=None,
        title="Fixing Time",
        description="The time and location as of which the fixing source is actually calculated. This is the official time the rate is deteminated as of the relevant fixing sources.",
    )

    cutoff_time: TimeLocationModel | None = Field(
        default=None,
        title="Cutoff Time",
        description="the deadline by which participants must submit trade requests, orders, or rate-setting instructions to be eligible for that fixing. This is an operational concept for market participants and settlement systems.",
    )


class SettlementRateOptionModel(SettlementRateOptionBaseModel):
    """
    Settlement Rate Option

    A settlement rate option as defined in Annex A of the ISDA 1998 FX and Currency
    Option Definitions. Settlement rate options identify the rate source, methodology,
    and terms used to determine fixing rates for non-deliverable and cash-settled FX
    forwards and options, as well as barrier determination rates.

    A settlement rate option may explicitly define a given asset (e.g. exchange rate)
    and fixing time and location, or it may provide a general definition of rate provider
    and terms, which must be combined with a specific asset and fixing time to determine
    the settlement rate. See RateSource for information on available observable sources
    of settlement rates.
    """

    __resource_id__ = SettlementRateOptionId
    __uri_path__ = "assets/rates/options/settlement"

    contact_info: ContactInfoModel | None = Field(default=None, title="Contact Info", description="Contact info for provider.")

    semantic_type: Literal["SETTLEMENT_RATE_OPTION"] = "SETTLEMENT_RATE_OPTION"


class SyntheticSettlementRateOptionModel(SettlementRateOptionBaseModel):
    """
    Synthetic Settlement Rate Option

    A synthetic settlement rate option derives a fixing rate from multiple other rate options
    where no direct fixing source exists for a given currency pair. This follows the ISDA 1998
    FX and Currency Option Definitions methodology for synthetic rate construction.

    Commonly used to create a synthetic fixing from the corresponding USD crosses for two
    different exchange rates (e.g. EUR/BRL derived from EUR/USD and USD/BRL fixings).
    """

    __resource_id__ = SettlementRateOptionId
    __uri_path__ = "assets/rates/options/settlement/synthetic"

    rate_option_1: SettlementRateOptionId | str | SettlementRateOptionModel | None = Field(
        default=None, title="Rate Option 1", description="The first settlement rate option used to compute the fixing."
    )
    rate_option_2: SettlementRateOptionId | str | SettlementRateOptionModel | None = Field(
        default=None, title="Rate Option 2", description="The second settlement rate option used to compute the fixing."
    )

    semantic_type: Literal["SYNTHETIC_SETTLEMENT_RATE_OPTION"] = "SYNTHETIC_SETTLEMENT_RATE_OPTION"


class SettlementRateOptionCode(Enum):
    """
    Settlement rate option codes as defined in Annex A of the ISDA 1998 FX and Currency Option Definitions
    and subsequent supplements. Each code identifies a specific rate source, fixing time, and location
    used to determine settlement rates for non-deliverable and cash-settled FX transactions.

    Codes are aligned to the ISDA Common Domain Model (CDM) enumerations where possible. For emerging
    market (EM) rate options, the code implicitly defines the fixing time and location (e.g. ARS_MAE_ARS05
    fixes at 3:00 PM Buenos Aires). For WM Reuters (WMR) and Bloomberg BFIX benchmarks, multiple fixing
    times and locations are supported across a wide range of currencies, and the code explicitly encodes
    the location and time (e.g. WM_REUTERS_MID_WMR03_GBLO_1600 for WMR London 4PM).
    """

    ARS_MAE_ARS05 = "ARS_MAE_ARS05"
    BLOOMBERG_MID_BFX03_CAOT_1230 = "BLOOMBERG_MID_BFX03_CAOT_1230"
    BLOOMBERG_MID_BFX03_CNBE_0930 = "BLOOMBERG_MID_BFX03_CNBE_0930"
    BLOOMBERG_MID_BFX03_DEFR_1400 = "BLOOMBERG_MID_BFX03_DEFR_1400"
    BLOOMBERG_MID_BFX03_GBLO_1600 = "BLOOMBERG_MID_BFX03_GBLO_1600"
    BLOOMBERG_MID_BFX03_IDJA_1100 = "BLOOMBERG_MID_BFX03_IDJA_1100"
    BLOOMBERG_MID_BFX03_INMU_1200 = "BLOOMBERG_MID_BFX03_INMU_1200"
    BLOOMBERG_MID_BFX03_JPTO_1200 = "BLOOMBERG_MID_BFX03_JPTO_1200"
    BLOOMBERG_MID_BFX03_JPTO_1400 = "BLOOMBERG_MID_BFX03_JPTO_1400"
    BLOOMBERG_MID_BFX03_JPTO_1500 = "BLOOMBERG_MID_BFX03_JPTO_1500"
    BLOOMBERG_MID_BFX03_JPTO_1530 = "BLOOMBERG_MID_BFX03_JPTO_1530"
    BLOOMBERG_MID_BFX03_KRSE_1400 = "BLOOMBERG_MID_BFX03_KRSE_1400"
    BLOOMBERG_MID_BFX03_PHMA_1130 = "BLOOMBERG_MID_BFX03_PHMA_1130"
    BLOOMBERG_MID_BFX03_SGSI_1100 = "BLOOMBERG_MID_BFX03_SGSI_1100"
    BLOOMBERG_MID_BFX03_USNY_0930 = "BLOOMBERG_MID_BFX03_USNY_0930"
    BLOOMBERG_MID_BFX03_USNY_1230 = "BLOOMBERG_MID_BFX03_USNY_1230"
    BLOOMBERG_MID_BFX03_USNY_1700 = "BLOOMBERG_MID_BFX03_USNY_1700"
    BRL_PTAX_BRL09 = "BRL_PTAX_BRL09"
    CLP_DOLAR_OBS_CLP10 = "CLP_DOLAR_OBS_CLP10"
    CNY_CNHHK_CNY03 = "CNY_CNHHK_CNY03"
    CNY_SAEC_CNY01 = "CNY_SAEC_CNY01"
    COP_TRM_COP02 = "COP_TRM_COP02"
    EGP_FEMF_EGP01 = "EGP_FEMF_EGP01"
    HUF_EUR_OFFICIAL_HUF02_HUBU_1100 = "HUF_EUR_OFFICIAL_HUF02_HUBU_1100"
    HUF_EUR_OFFICIAL_HUF02_HUBU_1200 = "HUF_EUR_OFFICIAL_HUF02_HUBU_1200"
    HUF_USD_OFFICIAL_HUF01_HUBU_1100 = "HUF_USD_OFFICIAL_HUF01_HUBU_1100"
    HUF_USD_OFFICIAL_HUF01_HUBU_1200 = "HUF_USD_OFFICIAL_HUF01_HUBU_1200"
    IDR_JISDOR_IDR04 = "IDR_JISDOR_IDR04"
    INR_FBIL_INR01 = "INR_FBIL_INR01"
    KRW_KFTC18_KRW02 = "KRW_KFTC18_KRW02"
    KRW_KFTC30_KRW05 = "KRW_KFTC30_KRW05"
    KZT_KASE_KZT01 = "KZT_KASE_KZT01"
    MYR_ABS_MYR01 = "MYR_ABS_MYR01"
    MYR_KL_REF_MYR04 = "MYR_KL_REF_MYR04"
    MYR_PPKM_MYR03 = "MYR_PPKM_MYR03"
    NGN_NAFEX_NGN03 = "NGN_NAFEX_NGN03"
    PEN_INTERBANK_AVE_PEN05 = "PEN_INTERBANK_AVE_PEN05"
    PHP_BAPPESO_PHP06 = "PHP_BAPPESO_PHP06"
    PKR_SBPK_PKR01 = "PKR_SBPK_PKR01"
    TWD_TAIFX1_TWD03 = "TWD_TAIFX1_TWD03"
    WM_REUTERS_MID_WMR03_GBLO_0700 = "WM_REUTERS_MID_WMR03_GBLO_0700"
    WM_REUTERS_MID_WMR03_GBLO_0800 = "WM_REUTERS_MID_WMR03_GBLO_0800"
    WM_REUTERS_MID_WMR03_GBLO_0900 = "WM_REUTERS_MID_WMR03_GBLO_0900"
    WM_REUTERS_MID_WMR03_GBLO_1000 = "WM_REUTERS_MID_WMR03_GBLO_1000"
    WM_REUTERS_MID_WMR03_GBLO_1100 = "WM_REUTERS_MID_WMR03_GBLO_1100"
    WM_REUTERS_MID_WMR03_GBLO_1200 = "WM_REUTERS_MID_WMR03_GBLO_1200"
    WM_REUTERS_MID_WMR03_GBLO_1300 = "WM_REUTERS_MID_WMR03_GBLO_1300"
    WM_REUTERS_MID_WMR03_GBLO_1400 = "WM_REUTERS_MID_WMR03_GBLO_1400"
    WM_REUTERS_MID_WMR03_GBLO_1500 = "WM_REUTERS_MID_WMR03_GBLO_1500"
    WM_REUTERS_MID_WMR03_GBLO_1600 = "WM_REUTERS_MID_WMR03_GBLO_1600"
    WM_REUTERS_MID_WMR03_USNY_1000 = "WM_REUTERS_MID_WMR03_USNY_1000"
