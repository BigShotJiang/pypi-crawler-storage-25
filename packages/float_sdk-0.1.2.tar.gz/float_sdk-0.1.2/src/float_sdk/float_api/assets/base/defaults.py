# pyright: basic

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2026, Float Technologies Inc."
__email__ = "andy@float.tech"

from typing import Literal

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.base.references import (
    AssetMarketDefaultsId,
    CommodityId,
    EquityId,
    ExchangeRateId,
    FloatingRateOptionId,
    FutureId,
    GroupId,
    IndexId,
    OrganizationId,
    RateOptionSpreadId,
)
from float_sdk.float_api.organizations.organization import OrganizationModel
from float_sdk.float_api.organizations.people import GroupModel

ValidAssetIdRef = ExchangeRateId | IndexId | EquityId | FloatingRateOptionId | RateOptionSpreadId | CommodityId | FutureId


class AssetMarketDefaultsModel(ResourceModel):
    __resource_id__ = AssetMarketDefaultsId
    __uri_path__ = "assets/defaults"

    semantic_type: Literal["ASSET_MARKET_DEFAULTS"] = "ASSET_MARKET_DEFAULTS"

    organization: OrganizationId | str | OrganizationModel | None = Field(
        default=None,
        title="Organization",
        description="The organization these market defaults belong to.",
    )

    asset: ValidAssetIdRef | str | None = Field(
        default=None,
        title="Asset",
        description="The asset these market defaults apply to.",
    )

    group: GroupId | str | GroupModel | None = Field(
        default=None,
        description="Identifier of the group which can access this dataset.",
    )
