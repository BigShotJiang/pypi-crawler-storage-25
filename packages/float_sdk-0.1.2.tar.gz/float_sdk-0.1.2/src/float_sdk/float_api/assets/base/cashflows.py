#!/usr/bin/env python
# pyright: basic

"""
Cashflow Models

Cashflow, payment schedule, and notional schedule models for financial contracts.
Includes calculation period scheduling, payment date generation, reset date specification,
and notional amortization/accretion. Aligned with ISDA CDM cashflow and schedule concepts.
"""

import datetime as dt
from enum import Enum
from typing import Literal

from pydantic import Field, field_validator, model_validator

from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.math import ProgressionType
from float_sdk.float_api.base.references import CurrencyId
from float_sdk.float_api.base.values import DatedValueModel
from float_sdk.float_api.datetime.conventions import BusinessDayConvention
from float_sdk.float_api.datetime.schedule import RelativeDateModel, ValidRollRuleModels
from float_sdk.float_api.datetime.tenor import TenorModel
from float_sdk.float_api.locations.business_centers import BusinessCenter
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum
from float_sdk.float_api.trading.parties import CounterpartyRole

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class CashflowType(Enum):
    PERFORMANCE = "PERFORMANCE"
    FIXED_RATE_RETURN = "FIXED_RATE_RETURN"
    FLOATING_RATE_RETURN = "FLOATING_RATE_RETURN"
    PREMIUM_PAYMENT = "PREMIUM_PAYMENT"
    PRINCIPAL_PAYMENT = "PRINCIPAL_PAYMENT"
    FEE_PAYMENT = "FEE_PAYMENT"


class CashflowModel(DataModel):
    """
    Represents a single cashflow payment between two counterparties.

    A cashflow is a discrete payment obligation arising from a financial contract,
    specifying who pays, who receives, the amount, currency, and settlement date.

    Attributes:
        payer: Counterparty responsible for making the payment.
        receiver: Counterparty entitled to receive the payment.
        type: Classification of the cashflow (e.g., premium, fee, interest).
        currency: Currency denomination of the payment.
        amount: Monetary value of the cashflow payment.
        payment_date: Date on which the cashflow is to be settled.
    """

    payer: CounterpartyRole = Field(..., title="Payer", description="Counterparty which is paying the designated amount to satisfy this cashflow.")
    receiver: CounterpartyRole = Field(..., title="Receiver", description="Counterparty which is receiving the designated amount to satisfy this cashflow.")
    type: CashflowType = Field(..., title="Cashflow Type", description="The type of cashflow which specifies why it is being paid.")
    currency: CurrencyId | str | CurrencyModel = Field(..., title="Currency", description="The currency in which the cashflow is being paid.")
    amount: float | None = Field(default=None, title="Amount", description="The amount being paid to settle this cashflow.")
    payment_date: dt.date | None = Field(default=None, title="Payment Date", description="The date the payment is to be settled.")

    semantic_type: Literal["CASHFLOW"] = "CASHFLOW"


class PremiumCashflowModel(CashflowModel):
    """
    Premium cashflow for upfront or scheduled premium payments on options,
    swaptions, and other premium-bearing instruments.
    """

    semantic_type: Literal["PREMIUM_PAYMENT"] = Field(default="PREMIUM_PAYMENT", title="Semantic Type")


class AccrualCashflowModel(CashflowModel):
    start_date: dt.date = Field(..., title="Start Date", description="Start date of the accrual period.")
    end_date: dt.date = Field(..., title="End Date", description="End date of the accrual period.")
    day_count_fraction: float = Field(..., title="Day Count Fraction", description="Day count fraction (or number of years) over the accrual period.")

    semantic_type: Literal["ACCRUAL_CASHFLOW"] = "ACCRUAL_CASHFLOW"


class StubPeriodType(Enum):
    """
    Stub period type for irregular calculation periods in a payment schedule,
    as defined in the ISDA 2006 Definitions (Section 4.7).

    REGULAR: Regular calculation period as defined by frequency and roll convention.
    SHORT_INITIAL: Initial stub period shorter than the schedule frequency.
    LONG_INITIAL: Initial stub period longer than the schedule frequency.
    SHORT_FINAL: Final stub period shorter than the schedule frequency.
    LONG_FINAL: Final stub period longer than the schedule frequency.
    SHORT_INTERVAL: Interim stub period shorter than the schedule frequency.
    LONG_INTERVAL: Interim stub period longer than the schedule frequency.
    """

    REGULAR = "REGULAR"
    SHORT_INITIAL = "SHORT_INITIAL"
    LONG_INITIAL = "LONG_INITIAL"
    SHORT_FINAL = "SHORT_FINAL"
    LONG_FINAL = "LONG_FINAL"
    SHORT_INTERVAL = "SHORT_INTERVAL"
    LONG_INTERVAL = "LONG_INTERVAL"


class CalculationDateScheduleModel(DataModel):
    """
    Represents the schedule of calculation dates for a financial contract.

    Attributes:
        effective_date (date | None): Effective date of the calculation schedule (start date).
        termination_date (date | None): Date when the calculation schedule terminates (end date).
        business_days (BusinessCenter | None): Business days for holiday calendar adjustments.
        business_day_convention (BusinessDayConvention | None): Convention for adjusting dates to business days.
        date_roll_rule (ValidRollRuleModels | None): Rule for calculation period frequency and roll.
        stub_period_type (PeriodType | None): Type of stub period at start or end.
        first_regular_period_start_date (date | None): Start date of first regular calculation period.
        last_regular_period_end_date (date | None): End date of last regular calculation period.
    """

    effective_date: dt.date | None = Field(default=None, title="Effective Date", description="Effective date of the contract, used to compute payment schedule")
    termination_date: dt.date | None = Field(default=None, title="Termination Date", description="Date when the contract terminates")
    business_days: BusinessCenter | list[BusinessCenter] | None = Field(
        default=None, title="Business Days", description="Business days for holiday calendar adjustments"
    )
    business_day_convention: BusinessDayConvention | None = Field(
        default=None, title="Business Day Convention", description="Convention for adjusting dates to business days"
    )
    date_roll_rule: ValidRollRuleModels | None = Field(
        default=None, title="Calculation Period Rule", description="Rule for calculation period frequency and roll"
    )
    stub_period_type: StubPeriodType | None = Field(default=None, title="Stub Period Type", description="Type of stub period at start or end")
    first_regular_period_start_date: dt.date | None = Field(
        default=None, title="First Regular Period Start Date", description="Start date of first regular calculation period"
    )
    last_regular_period_end_date: dt.date | None = Field(
        default=None, title="Last Regular Period End Date", description="End date of last regular calculation period"
    )

    semantic_type: Literal["CALCULATION_DATES_SCHEDULE"] = "CALCULATION_DATES_SCHEDULE"


# === Notional Schedule Models ===


class AmortizationType(DisplayEnum):
    """Type of notional amortization for swap schedules, aligned with ISDA CDM."""

    CONSTANT = "CONSTANT"
    AMORTIZING = "AMORTIZING"
    ACCRETING = "ACCRETING"

    def display_names(self) -> dict[str, str]:
        return {
            "CONSTANT": "Constant",
            "AMORTIZING": "Amortizing (Step Down)",
            "ACCRETING": "Accreting (Step Up)",
        }


class NotionalScheduleRuleModel(DataModel):
    """
    Rule-based specification for generating a notional schedule.

    Schedule generation rules for swaps with amortizing or accreting notional, which can be geometric (e.g. increase by factor 1.05 each interval)
    or arithmetic (e.g. increase by 20,000,000 each interval)

    The rule generates the resolved schedule by applying the increment at the specified frequency.

    """

    amortization_type: AmortizationType | None = Field(default=None, title="Amortization Type", description="The type of notional change over time.")

    start_date: dt.date | None = Field(default=None, title="Start Date", description="The date when the notional schedule begins.")
    end_date: dt.date | None = Field(default=None, title="End Date", description="The date when the notional schedule ends.")

    step_frequency: RelativeDateModel | None = Field(
        default=None,
        title="Step Frequency",
        description="The frequency at which notional steps occur, relative to calculation periods. E.g., '3M' for quarterly steps.",
    )

    increment: float | None = Field(
        default=None, ge=0, title="Increment", description="The factor increment to apply at each step. To increase by 105% each interval, specify 1.05"
    )

    progression_type: ProgressionType | None = Field(
        default=None, title="Progression Type", description="The type of mathematical progression (arithmetic or geometric)."
    )

    semantic_type: Literal["NOTIONAL_SCHEDULE_RULE"] = "NOTIONAL_SCHEDULE_RULE"

    @model_validator(mode="after")
    def validate_non_constant_requirements(self) -> "NotionalScheduleRuleModel":
        """Validate that non-constant amortization types require increment and progression_type."""
        if self.amortization_type and self.amortization_type != AmortizationType.CONSTANT:
            if self.increment is None:
                raise ValueError("increment is required for non-constant amortization types")
            if self.progression_type is None:
                raise ValueError("progression_type is required for non-constant amortization types")
        return self


class DatedValueScheduleModel(DataModel):
    """
    Base class for schedules with explicit date/value pairs.

    Values are resolved using ISDA CDM pattern: find the most recent entry where
    entry.date <= target_date.
    """

    values: list[DatedValueModel] = Field(..., min_length=1, title="Values", description="Time series of dated values.")

    @field_validator("values")
    def validate_values_chronological(cls, v):
        """Ensure values are in chronological order."""
        if len(v) > 1:
            dates = [value.date for value in v]
            if dates != sorted(dates):
                raise ValueError("Schedule values must be in chronological order")
        return v


class NotionalScheduleModel(DatedValueScheduleModel):
    """
    Resolved notional schedule with explicit date/factor pairs.

    This is the LOCKED schedule that applies to the trade, containing factors that multiply
    the base notional_amount. Either generated from a NotionalScheduleRule or entered manually.

    The notional for any calculation period is determined by finding the most recent
    entry where entry.date <= period_start_date (ISDA CDM resolution pattern).
    """

    semantic_type: Literal["NOTIONAL_SCHEDULE"] = "NOTIONAL_SCHEDULE"


class DiscountScheduleModel(DatedValueScheduleModel):
    """
    Resolved discount schedule with explicit date/factor pairs.

    Contains discount factors that multiply the base amount (e.g., fee amount).
    Factors typically range from 0.0 to 1.0, where 1.0 means no discount.
    """

    semantic_type: Literal["DISCOUNT_SCHEDULE"] = "DISCOUNT_SCHEDULE"


class PayRelativeTo(DisplayEnum):
    """
    Defines how payment dates are calculated relative to accrual or valuation dates,
    per the ISDA 2006 Definitions (Section 4.11).

    CALCULATION_PERIOD_START_DATE : Payment date is relative to the start date of each calculation period.
    CALCULATION_PERIOD_END_DATE : Payment date is relative to the end date of each calculation period.
    VALUATION_DATE : Payments will occur relative to the valuation date.
    """

    CALCULATION_PERIOD_START_DATE = "CALCULATION_PERIOD_START_DATE"
    CALCULATION_PERIOD_END_DATE = "CALCULATION_PERIOD_END_DATE"
    VALUATION_DATE = "VALUATION_DATE"

    def display_names(self) -> dict[str, str]:
        return {
            "CALCULATION_PERIOD_START_DATE": "Calc Period Start Date",
            "CALCULATION_PERIOD_END_DATE": "Calc Period End Date",
            "VALUATION_DATE": "Valuation Date",
        }


class ResetRelativeTo(DisplayEnum):
    """
    Determines if the reset dates are computed relative to the start date or end date of the
    corresponding calculation period, per the ISDA 2006 Definitions (Section 6.2).

    CALCULATION_PERIOD_START_DATE : Resets occur relative to the first day of a calculation period.
    CALCULATION_PERIOD_END_DATE : Resets occur relative to the last day of a calculation period.
    """

    CALCULATION_PERIOD_START_DATE = "CALCULATION_PERIOD_START_DATE"
    CALCULATION_PERIOD_END_DATE = "CALCULATION_PERIOD_END_DATE"

    def display_names(self) -> dict[str, str]:
        return {"CALCULATION_PERIOD_START_DATE": "Calc Period Start Date", "CALCULATION_PERIOD_END_DATE": "Calc Period End Date"}


class PaymentDateScheduleModel(DataModel):
    payment_frequency: RelativeDateModel | TenorModel | None = Field(
        default=None, title="Payment Frequency", description="Frequency of payments (e.g. monthly, quarterly, or 1T for single payment at termination)"
    )
    business_days: BusinessCenter | list[BusinessCenter] | None = Field(
        default=None, title="Business Days", description="Business days for holiday calendar adjustments"
    )
    business_day_convention: BusinessDayConvention | None = Field(
        default=None, title="Business Day Convention", description="Convention for adjusting payment dates to business days"
    )
    payment_days_offset: RelativeDateModel | None = Field(
        default=None, title="Payment Days Offset", description="Offset for payment days relative to calculation period"
    )
    pay_relative_to: PayRelativeTo | None = Field(
        default=None, title="Pay Relative To", description="Specifies how payment dates are calculated relative to accrual or valuation dates"
    )

    semantic_type: Literal["PAYMENT_DATES_SPECIFICATION"] = "PAYMENT_DATES_SPECIFICATION"


class ResetDatesSpecificationModel(DataModel):
    reset_frequency: RelativeDateModel | None = Field(
        default=None, title="Reset Frequency", description="Frequency at which the interest rate is reset for the calculation period accrual"
    )
    business_days: BusinessCenter | list[BusinessCenter] | None = Field(
        default=None, title="Business Days", description="Business days for date adjustment of reset date schedule"
    )
    fixing_dates: RelativeDateModel | None = Field(
        default=None,
        title="Fixing Dates",
        description="the dates on which the index values are observed. The fixing dates are specified by reference to the reset date through business days offset and an associated set of financial business centers. Normally these offset calculation rules will be those specified in the ISDA definition for the relevant floating rate index (ISDA's Floating Rate Option). However, non-standard offset calculation rules may apply for a trade if mutually agreed by the principal parties to the transaction.",
    )
    reset_relative_to: ResetRelativeTo | None = Field(
        default=None,
        title="Reset Relative To",
        description="Specifies whether the reset dates are determined with respect to each adjusted calculation period start date or adjusted calculation period end date. If the reset frequency is specified as daily this element must not be included.",
    )

    semantic_type: Literal["RESET_DATES_SPECIFICATION"] = "RESET_DATES_SPECIFICATION"
