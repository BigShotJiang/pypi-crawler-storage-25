# pyright: basic

"""
Base Basket Models

Generic basket models for multi-asset products like correlation swaps,
basket options, and dispersion swaps.
"""

from typing import Generic, Literal, TypeVar

from pydantic import Field, computed_field

from float_sdk.float_api.assets.base.base import AssetId, ObservableModel
from float_sdk.float_api.assets.base.settlement import DeterminationMethod
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.base.references import CurrencyId
from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"

# TypeVar for asset types that can be in a basket
AssetModelType = TypeVar(
    "AssetModelType",
)


class WeightingScheme(DisplayEnum):
    """
    Basket weighting methodology.

    Determines how constituent weights are calculated or specified.

    - EQUAL: Equal weight for all constituents (1/N each)
    - MARKET_CAP: Weighted by market capitalization of constituents
    - QUANTITY: Weighted by quantity/notional of each constituent
    - WEIGHT: Custom explicit weights specified for each constituent
    - NOTIONAL: Weighted by notional amount of each constituent
    """

    EQUAL = "EQUAL"
    MARKET_CAP = "MARKET_CAP"
    QUANTITY = "QUANTITY"
    WEIGHT = "WEIGHT"
    NOTIONAL = "NOTIONAL"

    def display_names(self) -> dict[str, str]:
        return {
            "EQUAL": "Equal Weighted",
            "MARKET_CAP": "Market Cap Weighted",
            "QUANTITY": "Quantity Weighted",
            "WEIGHT": "Custom Weighted",
            "NOTIONAL": "Notional Weighted",
        }


class BasketConstituentModel(DataModel, Generic[AssetModelType]):
    """
    Single constituent within a basket of assets.

    Generic over asset type to enable type-safe baskets:
    - Equity baskets contain IndexModel | EquityModel
    - FX baskets contain ExchangeRateModel

    Attributes
    ----------
    asset : AssetId | str | AssetModelType | None
        The underlying asset (type depends on basket usage)
        Optional to allow empty constituents during UI construction
    quantity : float | None
        Number of units of this asset (for quantity-weighted baskets)
    weight : float | None
        Weight of this asset in the basket (0.0 to 1.0)
        If None and weighting_scheme is CUSTOM_WEIGHTED, validation will fail
    initial_level : float | None
        Initial price/level for this asset (for correlation calculation)
    initial_level_source : str | None
        Source for initial level (e.g., "CLOSING_PRICE", "OFFICIAL_SETTLEMENT")
    """

    asset: AssetId | str | AssetModelType | None = Field(
        default=None,
        title="Asset",
        description="Underlying asset (equity, index, or FX pair)",
    )

    quantity: float | None = Field(
        default=None,
        title="Quantity",
        description="Number of units of this asset (for quantity-weighted baskets)",
        gt=0,
    )

    weight: float | None = Field(
        default=None,
        title="Weight",
        description="Weight of this asset in basket (0.0 to 1.0)",
        ge=0.0,
        le=1.0,
    )

    initial_level: float | None = Field(
        default=None,
        title="Initial Level",
        description="Initial price/level for basket constituent calculation",
        gt=0,
    )

    initial_level_source: DeterminationMethod | None = Field(
        default=None,
        title="Initial Level Source",
        description="Source for initial level determination (e.g., CLOSING_PRICE, VWAP_PRICE)",
    )

    semantic_type: Literal["BASKET_CONSTITUENT"] = "BASKET_CONSTITUENT"


class BasketModel(ObservableModel, Generic[AssetModelType]):
    """
    Basket of assets with constituents, weights, and metadata.

    Generic over asset type for type safety:
    - BasketModel[IndexModel | EquityModel] for equity baskets
    - BasketModel[ExchangeRateModel] for FX baskets

    Reusable across basket products: correlation swaps, basket options,
    dispersion swaps, custom indices, etc.

    Attributes
    ----------
    id : str | None
        Unique identifier for the basket (from ObservableModel)
    name : str | None
        Name of the basket (from ObservableModel)
    version : str | None
        Version identifier (from ObservableModel)
    description : str | None
        Description of the basket (from ObservableModel)
    short_name : str | None
        Short name for the basket (from ObservableModel)
    identifiers : List[AssetIdentifier] | None
        Identifiers for the basket (from ObservableModel)
    group : GroupId | str | None
        Group access control (from ObservableModel)
    constituents : list[BasketConstituentModel[AssetModelType]]
        List of basket constituents (minimum 2)
    weighting_scheme : WeightingScheme
        How basket weights are determined
    currency : CurrencyId | str | CurrencyModel | None
        Reference currency for the basket
    """

    constituents: list[BasketConstituentModel[AssetModelType]] = Field(
        ...,
        title="Constituents",
        description="List of basket constituents with quantities and weights",
        min_length=2,
    )

    weighting_scheme: WeightingScheme = Field(
        default=WeightingScheme.EQUAL,
        title="Weighting Scheme",
        description="How basket weights are determined",
    )

    currency: CurrencyId | str | CurrencyModel | None = Field(
        default=None,
        title="Currency",
        description="Reference currency for the basket",
    )

    semantic_type: Literal["BASKET"] = "BASKET"

    @computed_field(title="Number of Constituents", description="Number of assets in the basket", json_schema_extra={"readOnly": True})
    @property
    def number_of_constituents(self) -> int:
        """Number of assets in the basket."""
        return len(self.constituents)

    @computed_field(
        title="Total Weight", description="Total weight across all constituents (should sum to 1.0 for WEIGHT scheme)", json_schema_extra={"readOnly": True}
    )
    @property
    def total_weight(self) -> float:
        """Total weight across all constituents (should sum to 1.0 for WEIGHT scheme)."""
        weights = [c.weight for c in self.constituents if c.weight is not None]
        return sum(weights) if weights else 0.0
