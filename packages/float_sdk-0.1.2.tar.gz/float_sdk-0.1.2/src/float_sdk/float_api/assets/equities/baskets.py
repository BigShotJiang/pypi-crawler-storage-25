#!/usr/bin/env python
# pyright: basic

"""
Equity Basket Models

Models for equity baskets used in equity correlation swaps,
basket options, and dispersion swaps.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.baskets import BasketConstituentModel, BasketModel
from float_sdk.float_api.assets.equities.equities import EquityModel, IndexModel
from float_sdk.float_api.assets.equities.terms import EquityReturnTermsModel
from float_sdk.float_api.base.references import EquityId, IndexId

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class EqBasketConstituentModel(BasketConstituentModel[IndexModel | EquityModel]):
    """
    Equity Basket Constituent Model

    Type-safe constituent for equity baskets.
    Asset must be IndexModel or EquityModel (or None for empty constituents).
    """

    asset: IndexId | EquityId | str | IndexModel | EquityModel | None = Field(
        default=None,
        title="Asset",
        description="Underlying equity or index asset",
    )

    semantic_type: Literal["EQ_BASKET_CONSTITUENT"] = "EQ_BASKET_CONSTITUENT"


class EqBasketModel(BasketModel[IndexModel | EquityModel]):
    """
    Equity Basket Model

    Basket of equity indices and stocks for equity correlation swaps,
    basket options, and dispersion swaps.

    Type-safe: constituents can only be IndexModel or EquityModel.
    """

    constituents: list[EqBasketConstituentModel] = Field(
        ...,
        title="Constituents",
        description="List of equity basket constituents with quantities and weights",
        min_length=2,
    )
    return_terms: EquityReturnTermsModel | None = Field(
        None,
        title="Return Terms",
        description="Equity return terms for the basket",
    )

    semantic_type: Literal["EQ_BASKET"] = "EQ_BASKET"
