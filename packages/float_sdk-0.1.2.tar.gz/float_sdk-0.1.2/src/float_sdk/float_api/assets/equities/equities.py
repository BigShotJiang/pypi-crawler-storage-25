#!/usr/bin/env python
# pyright: basic

"""
Equity Assets and Indices

Equity asset models including stocks, warrants, and equity indices. Supports
common stock, preferred stock, and exchange-traded instruments listed on
public venues such as stock exchanges.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.base import AssetClassificationModel, ObservableModel, SecurityBaseModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.equities.terms import ReturnType
from float_sdk.float_api.base.references import CurrencyId, EquityId, ExchangeId, IndexId, OrganizationId
from float_sdk.float_api.markets.venues import ExchangeModel
from float_sdk.float_api.organizations.organization import OrganizationModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class EquityObservableModel(ObservableModel):
    currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Currency", description="The currency of the equity.")
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")


class EquityModel(SecurityBaseModel):
    """
    Equity

    Represents an equity security (common stock, preferred stock) issued by a corporation.
    Equities listed on an exchange are referenced by standard identifiers (ISIN, SEDOL,
    FIGI, Bloomberg ticker). Serves as the underlying asset for equity derivatives
    including swaps, options, and futures as defined in the ISDA 2002 Equity Definitions.
    """

    __resource_id__ = EquityId
    __uri_path__ = "assets/equities"

    currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Currency", description="The currency of the equity.")
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")
    exchange: ExchangeId | str | ExchangeModel | None = Field(default=None, title="Exchange", description="The exchange where the equity is traded.")

    semantic_type: Literal["EQUITY"] = "EQUITY"


class IndexModel(EquityObservableModel):
    """
    Equity Index

    Represents an equity index comprising a basket of equity instruments, periodically
    rebalanced to reflect market changes. Serves as the underlying for index derivatives
    (futures, options, swaps) per the ISDA 2002 Equity Definitions. Supports both
    standard published indices and custom/proprietary indices.
    """

    __resource_id__ = IndexId
    __uri_path__ = "assets/indices/equities"

    return_type: ReturnType | None = Field(default=None, title="Return Type", description="The return type of the index (price or total return).")
    organization: OrganizationId | str | OrganizationModel | None = Field(
        default=None, title="Organization", description="The organization that owns the custom index."
    )

    semantic_type: Literal["INDEX"] = "INDEX"
