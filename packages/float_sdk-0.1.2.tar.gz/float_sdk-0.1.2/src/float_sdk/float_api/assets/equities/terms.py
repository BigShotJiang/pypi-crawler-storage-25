# pyright: basic
#!/usr/bin/env python

"""
Equity-Specific Terms Business Logic Classes

Implements business logic for equity-specific terms including dividend treatment,
return specifications, and payment terms.
"""

from enum import Enum
from typing import Literal

from pydantic import Field

from float_sdk.float_api.serialization.model import DataModel, DisplayEnum


class ReturnType(DisplayEnum):
    """
    Return type for performance payouts.

    Determines whether income (dividends/coupons) is included in the return.

    Attributes
    ----------
    PRICE : Price return only, excluding income (dividends/coupons).
    TOTAL : Total return, including both price and income components.
    """

    PRICE = "PRICE"
    TOTAL = "TOTAL"

    def display_names(self) -> dict[str, str]:
        return {"PRICE": "Price Return", "TOTAL": "Total Return"}


__all__ = [
    "ReturnType",
    "DividendEntitlement",
    "PriceReturnTermsModel",
    "DividendReturnTermsModel",
    "EquityReturnTermsModel",
]


class DividendEntitlement(Enum):
    """
    Date on which the receiver of the equity payout is entitled to the dividend,
    per the ISDA 2002 Equity Definitions and aligned with ISDA CDM DividendEntitlementEnum.

    EX_DATE : Dividend entitlement is on the dividend ex-date.
    RECORD_DATE : Dividend entitlement is on the dividend record date.
    """

    EX_DATE = "EX_DATE"
    RECORD_DATE = "RECORD_DATE"


class PriceReturnTermsModel(DataModel):
    """
    Price return terms for equity performance payouts per the ISDA 2002 Equity Definitions.

    Aligned with ISDA CDM PriceReturnTerms type.
    Contains return type and initial/final valuation prices per CDM structure.

    Attributes
    ----------
    return_type : ReturnType
        The type of return calculation (e.g., PRICE_RETURN, TOTAL_RETURN).
        CDM: returnType (1..1) - Required in PriceReturnTerms
    valuation_price_initial : float, optional
        The initial valuation price of the underlier.
        Used to calculate notional and performance return.
        CDM: valuationPriceInitial (0..1)
    valuation_price_final : float, optional
        The final valuation price of the underlier.
        Used to calculate final performance return.
        CDM: valuationPriceFinal (0..1)
    """

    return_type: ReturnType | None = Field(
        default=None,
        title="Return Type",
        description="The type of return calculation (PRICE_RETURN, TOTAL_RETURN, etc.)",
    )

    valuation_price_initial: float | None = Field(
        default=None,
        title="Valuation Price Initial",
        description="The initial valuation price of the asset. Used to calculate notional and performance.",
        gt=0,
    )

    valuation_price_final: float | None = Field(
        default=None,
        title="Valuation Price Final",
        description="The final valuation price of the asset. Used to calculate final performance return.",
        gt=0,
    )

    semantic_type: Literal["PRICE_RETURN_TERMS"] = "PRICE_RETURN_TERMS"


class DividendReturnTermsModel(DataModel):
    """
    Dividend treatment terms for equity performance payouts per the ISDA 2002 Equity Definitions.

    Aligned with ISDA CDM DividendReturnTerms type.

    Attributes
    ----------
    dividend_payout_ratio : float, optional
        The payout ratio for cash dividends, expressed as a decimal percentage.
        E.g., 0.75 means 75% of dividends are paid through the swap.
        CDM: dividendPayoutRatio (0..1)
    dividend_reinvestment : bool, optional
        Whether dividends are reinvested into the underlier.
        CDM: dividendReinvestment (0..1)
    dividend_entitlement : DividendEntitlement, optional
        The date on which the receiver of the equity payout is entitled to dividends.
        CDM: dividendEntitlement (0..1)
    """

    dividend_payout_ratio: float | None = Field(
        default=None,
        title="Dividend Payout Ratio",
        description="The payout ratio for cash dividends, expressed as a decimal percentage (e.g., 0.75 for 75%)",
        ge=0.0,
        le=1.0,
    )

    dividend_reinvestment: bool | None = Field(
        default=None,
        title="Dividend Reinvestment",
        description="Whether dividends are reinvested into the underlier",
    )

    dividend_entitlement: DividendEntitlement | None = Field(
        default=None,
        title="Dividend Entitlement",
        description="The date on which the receiver of the equity payout is entitled to dividends (ex-date or record date)",
    )

    semantic_type: Literal["DIVIDEND_RETURN_TERMS"] = "DIVIDEND_RETURN_TERMS"


class EquityReturnTermsModel(DataModel):
    """
    Equity return terms for regular equity swaps (price/dividend returns) per the
    ISDA 2002 Equity Definitions.

    Used ONLY by EquityPerformancePayoutModel for regular equity swaps.
    Does NOT include variance/volatility terms - those use VarianceReturnTermsModel
    and VolatilityReturnTermsModel directly in their respective payout models.

    Aligned with ISDA CDM ReturnTerms structure.

    Attributes
    ----------
    price_return_terms : PriceReturnTermsModel, optional
        Price return specification for equity swaps.
        CDM: priceReturnTerms (0..1)
    dividend_return_terms : DividendReturnTermsModel, optional
        Dividend treatment terms.
        Only applicable when price_return_terms.return_type is TOTAL_RETURN.
        CDM: dividendReturnTerms (0..1)
    """

    price_return_terms: PriceReturnTermsModel | None = Field(
        default=None,
        title="Price Return Terms",
        description="Price return specification for equity swaps. CDM: priceReturnTerms",
    )

    dividend_return_terms: DividendReturnTermsModel | None = Field(
        default=None,
        title="Dividend Return Terms",
        description="Dividend treatment. Only with TOTAL_RETURN. CDM: dividendReturnTerms",
    )

    semantic_type: Literal["EQUITY_RETURN_TERMS"] = "EQUITY_RETURN_TERMS"
