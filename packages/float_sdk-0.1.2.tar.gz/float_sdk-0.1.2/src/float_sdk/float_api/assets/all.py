#!/usr/bin/env python
# pyright: basic

"""
Asset Type Unions

Discriminated unions and type aliases for all supported asset models and asset ID types.
Used for polymorphic asset references in transactions, barriers, and product definitions.
"""

from typing import Annotated, Union

from pydantic import Field

from float_sdk.float_api.assets.bonds.bonds import BondModel
from float_sdk.float_api.assets.commodities.commodities import CommodityModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel, ExchangeRateModel
from float_sdk.float_api.assets.equities.equities import EquityModel, IndexModel
from float_sdk.float_api.assets.futures.futures import FutureModel
from float_sdk.float_api.assets.rates.rates import (
    FloatingRateIndexModel,
    FloatingRateOptionModel,
    InflationRateIndexModel,
    RateOptionSpreadModel,
    RateSourceModel,
    SettlementRateOptionModel,
    SyntheticSettlementRateOptionModel,
)
from float_sdk.float_api.base.references import (
    BondId,
    CommodityId,
    EquityId,
    ExchangeRateId,
    FloatingRateOptionId,
    FutureId,
    IndexId,
    RateOptionSpreadId,
)

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2026, Float Technologies Inc."
__email__ = "andy@float.tech"


ValidAssetsModelUnion = Union[
    BondModel,
    EquityModel,
    FutureModel,
    IndexModel,
    CurrencyModel,
    CommodityModel,
    ExchangeRateModel,
    FloatingRateIndexModel,
    FloatingRateOptionModel,
    InflationRateIndexModel,
    RateOptionSpreadModel,
    SettlementRateOptionModel,
    SyntheticSettlementRateOptionModel,
    RateSourceModel,
]
ValidAssetsModel = Annotated[
    ValidAssetsModelUnion,
    Field(discriminator="semantic_type"),
]

# Asset ID types that can be used to reference assets (includes str for flexibility)
ValidAssetIdsUnion = Union[
    BondId,
    ExchangeRateId,
    IndexId,
    EquityId,
    FloatingRateOptionId,
    RateOptionSpreadId,
    CommodityId,
    FutureId,
    str,
]

# Complete union for barrier assets: Models + IDs + str + None
# Used by barrier models that need to accept asset references in multiple forms
BarrierAssetUnion = Union[
    ValidAssetsModelUnion,
    ValidAssetIdsUnion,
    None,
]

_EXTERNAL_ASSETS = [BondModel, EquityModel, FutureModel, IndexModel, FutureModel]
