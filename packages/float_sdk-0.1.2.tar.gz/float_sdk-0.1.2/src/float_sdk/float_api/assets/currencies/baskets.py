#!/usr/bin/env python
# pyright: basic

"""
FX Basket Models

Models for FX baskets used in FX correlation swaps,
basket options, and dispersion swaps.
"""

from typing import Literal

from pydantic import Field

from float_sdk.float_api.assets.base.baskets import BasketConstituentModel, BasketModel
from float_sdk.float_api.assets.currencies.currencies import ExchangeRateModel
from float_sdk.float_api.base.references import ExchangeRateId

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class FXBasketConstituentModel(BasketConstituentModel[ExchangeRateModel]):
    """
    FX Basket Constituent Model

    Type-safe constituent for FX baskets.
    Asset must be ExchangeRateModel (or None for empty constituents).
    """

    asset: ExchangeRateId | str | ExchangeRateModel | None = Field(
        default=None,
        title="Asset",
        description="Underlying exchange rate (FX pair)",
    )

    semantic_type: Literal["FX_BASKET_CONSTITUENT"] = "FX_BASKET_CONSTITUENT"


class FXBasketModel(BasketModel[ExchangeRateModel]):
    """
    FX Basket Model

    Basket of foreign exchange rates for FX correlation swaps,
    basket options, and dispersion swaps.

    Type-safe: constituents can only be ExchangeRateModel.
    """

    constituents: list[FXBasketConstituentModel] = Field(
        ...,
        title="Constituents",
        description="List of FX basket constituents with quantities and weights",
        min_length=2,
    )

    semantic_type: Literal["FX_BASKET"] = "FX_BASKET"
