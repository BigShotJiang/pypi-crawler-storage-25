#!/usr/bin/env python
# pyright: basic

"""
Currencies and Exchange Rates

Currency and exchange rate asset models. Includes ISO 4217 currency codes, extended
currency codes for non-ISO currencies (e.g. CNH, BTC), and exchange rate models for
spot and fixing rates used across FX derivative transactions.
"""

from datetime import date
from enum import Enum
from typing import Annotated, List, Literal, Union

from pydantic import Field, computed_field

from float_sdk.float_api.api.requests import Session
from float_sdk.float_api.assets.base.base import AssetClass, AssetClassificationModel, AssetIdentifier, AssetType, MarketSector, ObservableModel
from float_sdk.float_api.assets.base.defaults import AssetMarketDefaultsModel
from float_sdk.float_api.assets.base.settlement import SettlementRateOptionModel
from float_sdk.float_api.base.references import AssetMarketDefaultsId, CurrencyId, ExchangeRateId, SettlementRateOptionId
from float_sdk.float_api.serialization.types import Serializer, TypeModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class ISOCurrencyCode(Enum):
    """
    ISO Currency Code

    ISO currency codes, as defined by the International Organization for Standardization (ISO),
    are three-letter alphabetic or numeric codes that uniquely represent currencies used worldwide.
    These standardized codes are an essential part of international finance and commerce, facilitating
    accurate and consistent currency identification across borders.

    Each currency code is composed of three letters, where the first two letters represent the country
    or geographical area and the third letter represents the currency itself. For example, "USD" stands
    for the United States Dollar, while "EUR" represents the Euro. These codes play a crucial role in
    financial transactions, currency exchange, and global economic reporting, ensuring seamless
    communication and transparency in the international monetary system.

    ISO Standard 4217 (https://www.currency-iso.org/en/home/tables/table-a1.html

    Attributes
    ----------
    AED : United Arab Emirates Dirham
    AFN : Afghanistan Afghani
    ALL : Albanian Lek
    AMD : Armenia Dram
    ANG : Netherlands Antillean Guilder
    AOA : Angolan Kwanza
    ARS : Argentine Peso
    AUD : Australian Dollar
    AWG : Aruban Florin
    AZN : Azerbaijan Manat
    BAM : Bosnia And Herzegovina Mark
    BBD : Barbados Dollar
    BDT : Bangladeshi Taka
    BGN : Bulgarian Lev
    BHD : Bahraini Dinar
    BIF : Burundi Franc
    BMD : Bermudian Dollar
    BND : Brunei Dollar
    BOB : Bolivian Boliviano
    BOV : Bolivian Mvdol
    BRL : Brazilian Real
    BSD : Bahamian Dollar
    BTN : Bhutanese Ngultrum
    BWP : Botwsana Pula
    BYN : Belarusian Ruble
    BZD : Belize Dollar
    CAD : Canadian Dollar
    CDF : Congolese Franc
    CHE : Wirtschaftsring Euro
    CHF : Swiss Franc
    CHW : Wirtschaftsring Franc
    CLF : Chilean Unidad de Fomento
    CLP : Chilean Peso
    CNY : Chinese Yuan Renminbi
    COP : Colombian Peso
    COU : Colombian Unidad de Valor Real
    CRC : Costa Rican Colon
    CUC : Cuban Peso Convertible
    CUP : Cuban Peso
    CVE : Cabo Verde Escudo
    CZK : Czech Koruna
    DJF : Djibouti Franc
    DKK : Danish Krone
    DOP : Dominican Peso
    DZD : Algerian Dinar
    EGP : Egyptian Pound
    ERN : Eritrean Nakfa
    ETB : Ethiopian Birr
    EUR : Euro
    FJD : Fijian Dollar
    FKP : Falkland Islands Pound
    GBP : British Pound Sterling
    GEL : Georgian Lari
    GHS : Ghana Cedi
    GIP : Gibraltar Pound
    GMD : Gambian Dalasi
    GNF : Guinean Franc
    GTQ : Guatemalan Quetzal
    GYD : Guyanese Dollar
    HKD : Hong Kong Dollar
    HNL : Honduran Lempira
    HRK : Croatian Kuna
    HTG : Haitian Gourde
    HUF : Hungarian Forint
    IDR : Indonesian Rupiah
    ILS : New Israeli Sheqel
    INR : Indian Rupee
    IQD : Iraqi Dinar
    IRR : Iranian Rial
    ISK : Icelandic Krona
    JMD : Jamaican Dollar
    JOD : Jordanian Dinar
    JPY : Japanese Yen
    KES : Kenyan Shilling
    KGS : Kyrgyzstani Som
    KHR : Cambodian Riel
    KMF : Comorian Franc
    KPW : North Korean Won
    KRW : South Korean Won
    KWD : Kuwaiti Dinar
    KYD : Cayman Islands Dollar
    KZT : Kazakhstani Tenge
    LAK : Laotian Kip
    LBP : Lebanese Pound
    LKR : Sri Lankan Rupee
    LRD : Liberian Dollar
    LSL : Lesotho Loti
    LYD : Libyan Dinar
    MAD : Moroccan Dirham
    MDL : Moldovan Leu
    MGA : Malagasy Ariary
    MKD : Macedonian Denar
    MMK : Myanmar Kyat
    MNT : Mongolian Tugrik
    MOP : Macanese Pataca
    MRU : Mauritanian Ouguiya
    MUR : Mauritian Rupee
    MVR : Maldivian Rufiyaa
    MWK : Malawian Kwacha
    MXN : Mexican Peso
    MXV : Mexican Unidad de Inversion (UDI)
    MYR : Malaysian Ringgit
    MZN : Mozambique Metical
    NAD : Namibia Dollar
    NGN : Nigerian Naira
    NIO : Nicaraguan Cordoba Oro
    NOK : Norwegian Krone
    NPR : Nepalese Rupee
    NZD : New Zealand Dollar
    OMR : Omani Rial
    PAB : Panamanian Balboa
    PEN : Peruvian Sol
    PGK : Papua New Guinean Kina
    PHP : Philippine Peso
    PKR : Pakistani Rupee
    PLN : Polish Zloty
    PYG : Paraguayan Guarani
    QAR : Qatari Rial
    RON : Romanian Leu
    RSD : Serbian Dinar
    RUB : Russian Ruble
    RWF : Rwandan Franc
    SAR : Saudi Riyal
    SBD : Solomon Islands Dollar
    SCR : Seychellois Rupee
    SDG : Sudanese Pound
    SEK : Swedish Krona
    SGD : Singapore Dollar
    SHP : Saint Helena Pound
    SLL : Sierra Leonean Leone
    SOS : Somali Shilling
    SRD : Surinam Dollar
    SSP : South Sudanese Pound
    STN : Sao Tomean Dobra
    SVC : El Salvadoran Colon
    SYP : Syrian Pound
    SZL : Swazi Lilangeni
    THB : Thai Baht
    TJS : Tajikistani Somoni
    TMT : Turkmenistan New Manat
    TND : Tunisian Dinar
    TOP : Tongan Pa'anga
    TRY : Turkish Lira
    TTD : Trinidad and Tobago Dollar
    TWD : New Taiwan Dollar
    TZS : Tanzanian Shilling
    UAH : Ukrainian Hryvnia
    UGX : Ugandan Shilling
    USD : United States Dollar
    USN : US Dollar (Next day)
    UYI : Uruguayan Peso en Unidades Indexadas (UI)
    UYU : Uruguayan Peso
    UYW : Uruguayan Unidad Previsional
    UZS : Uzbekistani Som
    VES : Venezuelan Bolívar Soberano
    VND : Vietnamese Dong
    VUV : Vanuatu Vatu
    WST : Samoan Tala
    XAF : Central African CFA Franc
    XAG : Silver
    XAU : Gold
    XBA : Bond Markets Unit European Composite Unit (EURCO)
    XBB : Bond Markets Unit European Monetary Unit (E.M.U.-6)
    XBC : Bond Markets Unit European Unit of Account 9 (E.U.A.-9)
    XBD : Bond Markets Unit European Unit of Account 17 (E.U.A.-17)
    XBT : Bitcoin
    XCD : East Caribbean Dollar
    XDR : SDR (Special Drawing Right)
    XOF : West African CFA Franc
    XPD : Palladium
    XPF : CFP (French Polynesian) Franc
    XPT : Platinum
    XSU : Bolivarian Alliance for the Americas Sucre
    XUA : African Development Bank Unit of Account
    XXX : The codes assigned for transactions where no currency is involved
    YER : Yemeni Rial
    ZAR : South African Rand
    ZMW : Zambian Kwacha
    ZWL : Zimbabwean Dollar
    """

    AED = "AED"  # United Arab Emirates Dirham
    AFN = "AFN"  # Afghanistan Afghani
    ALL = "ALL"  # Albanian Lek
    AMD = "AMD"  # Armenia Dram
    ANG = "ANG"  # Netherlands Antillean Guilder
    AOA = "AOA"  # Angolan Kwanza
    ARS = "ARS"  # Argentine Peso
    AUD = "AUD"  # Australian Dollar
    AWG = "AWG"  # Aruban Florin
    AZN = "AZN"  # Azerbaijan Manat
    BAM = "BAM"  # Bosnia And Herzegovina Mark
    BBD = "BBD"  # Barbados Dollar
    BDT = "BDT"  # Bangladeshi Taka
    BGN = "BGN"  # Bulgarian Lev
    BHD = "BHD"  # Bahraini Dinar
    BIF = "BIF"  # Burundi Franc
    BMD = "BMD"  # Bermudian Dollar
    BND = "BND"  # Brunei Dollar
    BOB = "BOB"  # Bolivian Boliviano
    BOV = "BOV"  # Bolivian Mvdol
    BRL = "BRL"  # Brazilian Real
    BSD = "BSD"  # Bahamian Dollar
    BTN = "BTN"  # Bhutanese Ngultrum
    BWP = "BWP"  # Botwsana Pula
    BYN = "BYN"  # Belarusian Ruble
    BZD = "BZD"  # Belize Dollar
    CAD = "CAD"  # Canadian Dollar
    CDF = "CDF"  # Congolese Franc
    CHE = "CHE"  # Wirtschaftsring Euro
    CHF = "CHF"  # Swiss Franc
    CHW = "CHW"  # Wirtschaftsring Franc
    CLF = "CLF"  # Chilean Unidad de Fomento
    CLP = "CLP"  # Chilean Peso
    CNY = "CNY"  # Chinese Yuan Renminbi
    COP = "COP"  # Colombian Peso
    COU = "COU"  # Colombian Unidad de Valor Real
    CRC = "CRC"  # Costa Rican Colon
    CUC = "CUC"  # Cuban Peso Convertible
    CUP = "CUP"  # Cuban Peso
    CVE = "CVE"  # Cabo Verde Escudo
    CZK = "CZK"  # Czech Koruna
    DJF = "DJF"  # Djibouti Franc
    DKK = "DKK"  # Danish Krone
    DOP = "DOP"  # Dominican Peso
    DZD = "DZD"  # Algerian Dinar
    EGP = "EGP"  # Egyptian Pound
    ERN = "ERN"  # Eritrean Nakfa
    ETB = "ETB"  # Ethiopian Birr
    EUR = "EUR"  # Euro
    FJD = "FJD"  # Fijian Dollar
    FKP = "FKP"  # Falkland Islands Pound
    GBP = "GBP"  # British Pound Sterling
    GEL = "GEL"  # Georgian Lari
    GHS = "GHS"  # Ghana Cedi
    GIP = "GIP"  # Gibraltar Pound
    GMD = "GMD"  # Gambian Dalasi
    GNF = "GNF"  # Guinean Franc
    GTQ = "GTQ"  # Guatemalan Quetzal
    GYD = "GYD"  # Guyanese Dollar
    HKD = "HKD"  # Hong Kong Dollar
    HNL = "HNL"  # Honduran Lempira
    HRK = "HRK"  # Croatian Kuna
    HTG = "HTG"  # Haitian Gourde
    HUF = "HUF"  # Hungarian Forint
    IDR = "IDR"  # Indonesian Rupiah
    ILS = "ILS"  # New Israeli Sheqel
    INR = "INR"  # Indian Rupee
    IQD = "IQD"  # Iraqi Dinar
    IRR = "IRR"  # Iranian Rial
    ISK = "ISK"  # Icelandic Krona
    JMD = "JMD"  # Jamaican Dollar
    JOD = "JOD"  # Jordanian Dinar
    JPY = "JPY"  # Japanese Yen
    KES = "KES"  # Kenyan Shilling
    KGS = "KGS"  # Kyrgyzstani Som
    KHR = "KHR"  # Cambodian Riel
    KMF = "KMF"  # Comorian Franc
    KPW = "KPW"  # North Korean Won
    KRW = "KRW"  # South Korean Won
    KWD = "KWD"  # Kuwaiti Dinar
    KYD = "KYD"  # Cayman Islands Dollar
    KZT = "KZT"  # Kazakhstani Tenge
    LAK = "LAK"  # Laotian Kip
    LBP = "LBP"  # Lebanese Pound
    LKR = "LKR"  # Sri Lankan Rupee
    LRD = "LRD"  # Liberian Dollar
    LSL = "LSL"  # Lesotho Loti
    LYD = "LYD"  # Libyan Dinar
    MAD = "MAD"  # Moroccan Dirham
    MDL = "MDL"  # Moldovan Leu
    MGA = "MGA"  # Malagasy Ariary
    MKD = "MKD"  # Macedonian Denar
    MMK = "MMK"  # Myanmar Kyat
    MNT = "MNT"  # Mongolian Tugrik
    MOP = "MOP"  # Macanese Pataca
    MRU = "MRU"  # Mauritanian Ouguiya
    MUR = "MUR"  # Mauritian Rupee
    MVR = "MVR"  # Maldivian Rufiyaa
    MWK = "MWK"  # Malawian Kwacha
    MXN = "MXN"  # Mexican Peso
    MXV = "MXV"  # Mexican Unidad de Inversion (UDI)
    MYR = "MYR"  # Malaysian Ringgit
    MZN = "MZN"  # Mozambique Metical
    NAD = "NAD"  # Namibia Dollar
    NGN = "NGN"  # Nigerian Naira
    NIO = "NIO"  # Nicaraguan Cordoba Oro
    NOK = "NOK"  # Norwegian Krone
    NPR = "NPR"  # Nepalese Rupee
    NZD = "NZD"  # New Zealand Dollar
    OMR = "OMR"  # Omani Rial
    PAB = "PAB"  # Panamanian Balboa
    PEN = "PEN"  # Peruvian Sol
    PGK = "PGK"  # Papua New Guinean Kina
    PHP = "PHP"  # Philippine Peso
    PKR = "PKR"  # Pakistani Rupee
    PLN = "PLN"  # Polish Zloty
    PYG = "PYG"  # Paraguayan Guarani
    QAR = "QAR"  # Qatari Rial
    RON = "RON"  # Romanian Leu
    RSD = "RSD"  # Serbian Dinar
    RUB = "RUB"  # Russian Ruble
    RWF = "RWF"  # Rwandan Franc
    SAR = "SAR"  # Saudi Riyal
    SBD = "SBD"  # Solomon Islands Dollar
    SCR = "SCR"  # Seychellois Rupee
    SDG = "SDG"  # Sudanese Pound
    SEK = "SEK"  # Swedish Krona
    SGD = "SGD"  # Singapore Dollar
    SHP = "SHP"  # Saint Helena Pound
    SLL = "SLL"  # Sierra Leonean Leone
    SOS = "SOS"  # Somali Shilling
    SRD = "SRD"  # Surinam Dollar
    SSP = "SSP"  # South Sudanese Pound
    STN = "STN"  # Sao Tomean Dobra
    SVC = "SVC"  # El Salvadoran Colon
    SYP = "SYP"  # Syrian Pound
    SZL = "SZL"  # Swazi Lilangeni
    THB = "THB"  # Thai Baht
    TJS = "TJS"  # Tajikistani Somoni
    TMT = "TMT"  # Turkmenistan New Manat
    TND = "TND"  # Tunisian Dinar
    TOP = "TOP"  # Tongan Pa'anga
    TRY = "TRY"  # Turkish Lira
    TTD = "TTD"  # Trinidad and Tobago Dollar
    TWD = "TWD"  # New Taiwan Dollar
    TZS = "TZS"  # Tanzanian Shilling
    UAH = "UAH"  # Ukrainian Hryvnia
    UGX = "UGX"  # Ugandan Shilling
    USD = "USD"  # United States Dollar
    USN = "USN"  # US Dollar (Next day)
    UYI = "UYI"  # Uruguayan Peso en Unidades Indexadas (UI)
    UYU = "UYU"  # Uruguayan Peso
    UYW = "UYW"  # Uruguayan Unidad Previsional
    UZS = "UZS"  # Uzbekistani Som
    VES = "VES"  # Venezuelan Bolívar Soberano
    VND = "VND"  # Vietnamese Dong
    VUV = "VUV"  # Vanuatu Vatu
    WST = "WST"  # Samoan Tala
    XAF = "XAF"  # Central African CFA Franc
    XAG = "XAG"  # Silver
    XAU = "XAU"  # Gold
    XBA = "XBA"  # Bond Markets Unit European Composite Unit (EURCO)
    XBB = "XBB"  # Bond Markets Unit European Monetary Unit (E.M.U.-6)
    XBC = "XBC"  # Bond Markets Unit European Unit of Account 9 (E.U.A.-9)
    XBD = "XBD"  # Bond Markets Unit European Unit of Account 17 (E.U.A.-17)
    XBT = "XBT"  # Bitcoin
    XCD = "XCD"  # East Caribbean Dollar
    XDR = "XDR"  # SDR (Special Drawing Right)
    XOF = "XOF"  # West African CFA Franc
    XPD = "XPD"  # Palladium
    XPF = "XPF"  # CFP (French Polynesian) Franc
    XPT = "XPT"  # Platinum
    XSU = "XSU"  # Bolivarian Alliance for the Americas Sucre
    XUA = "XUA"  # African Development Bank Unit of Account
    XXX = "XXX"  # The codes assigned for transactions where no currency is involved
    YER = "YER"  # Yemeni Rial
    ZAR = "ZAR"  # South African Rand
    ZMW = "ZMW"  # Zambian Kwacha
    ZWL = "ZWL"  # Zimbabwean Dollar


class CurrencyCode(Enum):
    """
    Currency Code

    Currency codes, including those defined by the International Organization for Standardization (ISO),
    are three-letter alphabetic or numeric codes that uniquely represent currencies used worldwide.
    These standardized codes are an essential part of international finance and commerce, facilitating
    accurate and consistent currency identification across borders. This enumeration also includes
    a number of other currency codes which are used within financial transactions but are not part of
    the ISO standard (for example Offshore Chinese Yuan)

    Each currency code is composed of three letters, where the first two letters represent the country
    or geographical area and the third letter represents the currency itself. For example, "USD" stands
    for the United States Dollar, while "EUR" represents the Euro. These codes play a crucial role in
    financial transactions, currency exchange, and global economic reporting, ensuring seamless
    communication and transparency in the international monetary system.

    ISO Standard 4217 (https://www.currency-iso.org/en/home/tables/table-a1.html

    Attributes
    ----------
    AED : United Arab Emirates Dirham
    AFN : Afghanistan Afghani
    ALL : Albanian Lek
    AMD : Armenia Dram
    ANG : Netherlands Antillean Guilder
    AOA : Angolan Kwanza
    ARS : Argentine Peso
    AUD : Australian Dollar
    AWG : Aruban Florin
    AZN : Azerbaijan Manat
    BAM : Bosnia And Herzegovina Mark
    BBD : Barbados Dollar
    BDT : Bangladeshi Taka
    BGN : Bulgarian Lev
    BHD : Bahraini Dinar
    BIF : Burundi Franc
    BMD : Bermudian Dollar
    BND : Brunei Dollar
    BOB : Bolivian Boliviano
    BOV : Bolivian Mvdol
    BRL : Brazilian Real
    BSD : Bahamian Dollar
    BTC : Bitcoin
    BTN : Bhutanese Ngultrum
    BWP : Botwsana Pula
    BYN : Belarusian Ruble
    BZD : Belize Dollar
    CAD : Canadian Dollar
    CDF : Congolese Franc
    CHE : Wirtschaftsring Euro
    CHF : Swiss Franc
    CHW : Wirtschaftsring Franc
    CLF : Chilean Unidad de Fomento
    CLP : Chilean Peso
    CNH : Offshore Chinese Yuan traded in Hong Kong.
    CNT : Offshore Chinese Yuan traded in Taiwan.
    CNY : Chinese Yuan Renminbi
    COP : Colombian Peso
    COU : Colombian Unidad de Valor Real
    CRC : Costa Rican Colon
    CUC : Cuban Peso Convertible
    CUP : Cuban Peso
    CVE : Cabo Verde Escudo
    CZK : Czech Koruna
    DJF : Djibouti Franc
    DKK : Danish Krone
    DOP : Dominican Peso
    DZD : Algerian Dinar
    EGP : Egyptian Pound
    ERN : Eritrean Nakfa
    ETB : Ethiopian Birr
    EUR : Euro
    FJD : Fijian Dollar
    FKP : Falkland Islands Pound
    GBP : British Pound Sterling
    GEL : Georgian Lari
    GGP : Guernsey Pound.
    GHS : Ghana Cedi
    GIP : Gibraltar Pound
    GMD : Gambian Dalasi
    GNF : Guinean Franc
    GTQ : Guatemalan Quetzal
    GYD : Guyanese Dollar
    HKD : Hong Kong Dollar
    HNL : Honduran Lempira
    HRK : Croatian Kuna
    HTG : Haitian Gourde
    HUF : Hungarian Forint
    IDR : Indonesian Rupiah
    ILS : New Israeli Sheqel
    IMP : Isle of Man Pound
    INR : Indian Rupee
    IQD : Iraqi Dinar
    IRR : Iranian Rial
    ISK : Icelandic Krona
    JEP : Jersey Pound
    JMD : Jamaican Dollar
    JOD : Jordanian Dinar
    JPY : Japanese Yen
    KES : Kenyan Shilling
    KGS : Kyrgyzstani Som
    KHR : Cambodian Riel
    KID : Tuvaluan Dollar
    KMF : Comorian Franc
    KPW : North Korean Won
    KRW : South Korean Won
    KWD : Kuwaiti Dinar
    KYD : Cayman Islands Dollar
    KZT : Kazakhstani Tenge
    LAK : Laotian Kip
    LBP : Lebanese Pound
    LKR : Sri Lankan Rupee
    LRD : Liberian Dollar
    LSL : Lesotho Loti
    LYD : Libyan Dinar
    MAD : Moroccan Dirham
    MCF : Monegasque Franc
    MDL : Moldovan Leu
    MGA : Malagasy Ariary
    MKD : Macedonian Denar
    MMK : Myanmar Kyat
    MNT : Mongolian Tugrik
    MOP : Macanese Pataca
    MRU : Mauritanian Ouguiya
    MUR : Mauritian Rupee
    MVR : Maldivian Rufiyaa
    MWK : Malawian Kwacha
    MXN : Mexican Peso
    MXV : Mexican Unidad de Inversion (UDI)
    MYR : Malaysian Ringgit
    MZN : Mozambique Metical
    NAD : Namibia Dollar
    NGN : Nigerian Naira
    NIO : Nicaraguan Cordoba Oro
    NOK : Norwegian Krone
    NPR : Nepalese Rupee
    NZD : New Zealand Dollar
    OMR : Omani Rial
    PAB : Panamanian Balboa
    PEN : Peruvian Sol
    PGK : Papua New Guinean Kina
    PHP : Philippine Peso
    PKR : Pakistani Rupee
    PLN : Polish Zloty
    PYG : Paraguayan Guarani
    QAR : Qatari Rial
    RON : Romanian Leu
    RSD : Serbian Dinar
    RUB : Russian Ruble
    RWF : Rwandan Franc
    SAR : Saudi Riyal
    SBD : Solomon Islands Dollar
    SCR : Seychellois Rupee
    SDG : Sudanese Pound
    SEK : Swedish Krona
    SGD : Singapore Dollar
    SHP : Saint Helena Pound
    SLL : Sierra Leonean Leone
    SML : Sammarinese Lira.
    SOS : Somali Shilling
    SRD : Surinam Dollar
    SSP : South Sudanese Pound
    STN : Sao Tomean Dobra
    SVC : El Salvadoran Colon
    SYP : Syrian Pound
    SZL : Swazi Lilangeni
    THB : Thai Baht
    TJS : Tajikistani Somoni
    TMT : Turkmenistan New Manat
    TND : Tunisian Dinar
    TOP : Tongan Pa’anga
    TRY : Turkish Lira
    TTD : Trinidad and Tobago Dollar
    TWD : New Taiwan Dollar
    TZS : Tanzanian Shilling
    UAH : Ukrainian Hryvnia
    UGX : Ugandan Shilling
    USD : United States Dollar
    USN : US Dollar (Next day)
    UYI : Uruguayan Peso en Unidades Indexadas (UI)
    UYU : Uruguayan Peso
    UYW : Uruguayan Unidad Previsional
    UZS : Uzbekistani Som
    VAL : Vatican Lira.
    VES : Venezuelan Bolívar Soberano
    VND : Vietnamese Dong
    VUV : Vanuatu Vatu
    WST : Samoan Tala
    XAF : Central African CFA Franc
    XAG : Silver
    XAU : Gold
    XBA : Bond Markets Unit European Composite Unit (EURCO)
    XBB : Bond Markets Unit European Monetary Unit (E.M.U.-6)
    XBC : Bond Markets Unit European Unit of Account 9 (E.U.A.-9)
    XBD : Bond Markets Unit European Unit of Account 17 (E.U.A.-17)
    XBT : Bitcoin
    XCD : East Caribbean Dollar
    XDR : SDR (Special Drawing Right)
    XOF : West African CFA Franc
    XPD : Palladium
    XPF : CFP (French Polynesian) Franc
    XPT : Platinum
    XSU : Bolivarian Alliance for the Americas Sucre
    XUA : African Development Bank Unit of Account
    XXX : The codes assigned for transactions where no currency is involved
    YER : Yemeni Rial
    ZAR : South African Rand
    ZMW : Zambian Kwacha
    ZWL : Zimbabwean Dollar
    """

    AED = "AED"  # United Arab Emirates Dirham
    AFN = "AFN"  # Afghanistan Afghani
    ALL = "ALL"  # Albanian Lek
    AMD = "AMD"  # Armenia Dram
    ANG = "ANG"  # Netherlands Antillean Guilder
    AOA = "AOA"  # Angolan Kwanza
    ARS = "ARS"  # Argentine Peso
    AUD = "AUD"  # Australian Dollar
    AWG = "AWG"  # Aruban Florin
    AZN = "AZN"  # Azerbaijan Manat
    BAM = "BAM"  # Bosnia And Herzegovina Mark
    BBD = "BBD"  # Barbados Dollar
    BDT = "BDT"  # Bangladeshi Taka
    BGN = "BGN"  # Bulgarian Lev
    BHD = "BHD"  # Bahraini Dinar
    BIF = "BIF"  # Burundi Franc
    BMD = "BMD"  # Bermudian Dollar
    BND = "BND"  # Brunei Dollar
    BOB = "BOB"  # Bolivian Boliviano
    BOV = "BOV"  # Bolivian Mvdol
    BRL = "BRL"  # Brazilian Real
    BSD = "BSD"  # Bahamian Dollar
    BTC = "BTC"  # Bitcoin
    BTN = "BTN"  # Bhutanese Ngultrum
    BWP = "BWP"  # Botwsana Pula
    BYN = "BYN"  # Belarusian Ruble
    BZD = "BZD"  # Belize Dollar
    CAD = "CAD"  # Canadian Dollar
    CDF = "CDF"  # Congolese Franc
    CHE = "CHE"  # Wirtschaftsring Euro
    CHF = "CHF"  # Swiss Franc
    CHW = "CHW"  # Wirtschaftsring Franc
    CLF = "CLF"  # Chilean Unidad de Fomento
    CLP = "CLP"  # Chilean Peso
    CNH = "CNH"  # Offshore Chinese Yuan traded in Hong Kong.
    CNT = "CNT"  # Offshore Chinese Yuan traded in Taiwan.
    CNY = "CNY"  # Chinese Yuan Renminbi
    COP = "COP"  # Colombian Peso
    COU = "COU"  # Colombian Unidad de Valor Real
    CRC = "CRC"  # Costa Rican Colon
    CUC = "CUC"  # Cuban Peso Convertible
    CUP = "CUP"  # Cuban Peso
    CVE = "CVE"  # Cabo Verde Escudo
    CZK = "CZK"  # Czech Koruna
    DJF = "DJF"  # Djibouti Franc
    DKK = "DKK"  # Danish Krone
    DOP = "DOP"  # Dominican Peso
    DZD = "DZD"  # Algerian Dinar
    EGP = "EGP"  # Egyptian Pound
    ERN = "ERN"  # Eritrean Nakfa
    ETB = "ETB"  # Ethiopian Birr
    EUR = "EUR"  # Euro
    FJD = "FJD"  # Fijian Dollar
    FKP = "FKP"  # Falkland Islands Pound
    GBP = "GBP"  # British Pound Sterling
    GEL = "GEL"  # Georgian Lari
    GGP = "GGP"  # Guernsey Pound.
    GHS = "GHS"  # Ghana Cedi
    GIP = "GIP"  # Gibraltar Pound
    GMD = "GMD"  # Gambian Dalasi
    GNF = "GNF"  # Guinean Franc
    GTQ = "GTQ"  # Guatemalan Quetzal
    GYD = "GYD"  # Guyanese Dollar
    HKD = "HKD"  # Hong Kong Dollar
    HNL = "HNL"  # Honduran Lempira
    HRK = "HRK"  # Croatian Kuna
    HTG = "HTG"  # Haitian Gourde
    HUF = "HUF"  # Hungarian Forint
    IDR = "IDR"  # Indonesian Rupiah
    ILS = "ILS"  # New Israeli Sheqel
    IMP = "IMP"  # Isle of Man Pound.
    INR = "INR"  # Indian Rupee
    IQD = "IQD"  # Iraqi Dinar
    IRR = "IRR"  # Iranian Rial
    ISK = "ISK"  # Icelandic Krona
    JEP = "JEP"  # Jersey Pound.
    JMD = "JMD"  # Jamaican Dollar
    JOD = "JOD"  # Jordanian Dinar
    JPY = "JPY"  # Japanese Yen
    KES = "KES"  # Kenyan Shilling
    KGS = "KGS"  # Kyrgyzstani Som
    KHR = "KHR"  # Cambodian Riel
    KID = "KID"  # Tuvaluan Dollar
    KMF = "KMF"  # Comorian Franc
    KPW = "KPW"  # North Korean Won
    KRW = "KRW"  # South Korean Won
    KWD = "KWD"  # Kuwaiti Dinar
    KYD = "KYD"  # Cayman Islands Dollar
    KZT = "KZT"  # Kazakhstani Tenge
    LAK = "LAK"  # Laotian Kip
    LBP = "LBP"  # Lebanese Pound
    LKR = "LKR"  # Sri Lankan Rupee
    LRD = "LRD"  # Liberian Dollar
    LSL = "LSL"  # Lesotho Loti
    LYD = "LYD"  # Libyan Dinar
    MAD = "MAD"  # Moroccan Dirham
    MCF = "MCF"  # Monegasque Franc
    MDL = "MDL"  # Moldovan Leu
    MGA = "MGA"  # Malagasy Ariary
    MKD = "MKD"  # Macedonian Denar
    MMK = "MMK"  # Myanmar Kyat
    MNT = "MNT"  # Mongolian Tugrik
    MOP = "MOP"  # Macanese Pataca
    MRU = "MRU"  # Mauritanian Ouguiya
    MUR = "MUR"  # Mauritian Rupee
    MVR = "MVR"  # Maldivian Rufiyaa
    MWK = "MWK"  # Malawian Kwacha
    MXN = "MXN"  # Mexican Peso
    MXV = "MXV"  # Mexican Unidad de Inversion (UDI)
    MYR = "MYR"  # Malaysian Ringgit
    MZN = "MZN"  # Mozambique Metical
    NAD = "NAD"  # Namibia Dollar
    NGN = "NGN"  # Nigerian Naira
    NIO = "NIO"  # Nicaraguan Cordoba Oro
    NOK = "NOK"  # Norwegian Krone
    NPR = "NPR"  # Nepalese Rupee
    NZD = "NZD"  # New Zealand Dollar
    OMR = "OMR"  # Omani Rial
    PAB = "PAB"  # Panamanian Balboa
    PEN = "PEN"  # Peruvian Sol
    PGK = "PGK"  # Papua New Guinean Kina
    PHP = "PHP"  # Philippine Peso
    PKR = "PKR"  # Pakistani Rupee
    PLN = "PLN"  # Polish Zloty
    PYG = "PYG"  # Paraguayan Guarani
    QAR = "QAR"  # Qatari Rial
    RON = "RON"  # Romanian Leu
    RSD = "RSD"  # Serbian Dinar
    RUB = "RUB"  # Russian Ruble
    RWF = "RWF"  # Rwandan Franc
    SAR = "SAR"  # Saudi Riyal
    SBD = "SBD"  # Solomon Islands Dollar
    SCR = "SCR"  # Seychellois Rupee
    SDG = "SDG"  # Sudanese Pound
    SEK = "SEK"  # Swedish Krona
    SGD = "SGD"  # Singapore Dollar
    SHP = "SHP"  # Saint Helena Pound
    SLL = "SLL"  # Sierra Leonean Leone
    SML = "SML"  # Sammarinese Lira.
    SOS = "SOS"  # Somali Shilling
    SRD = "SRD"  # Surinam Dollar
    SSP = "SSP"  # South Sudanese Pound
    STN = "STN"  # Sao Tomean Dobra
    SVC = "SVC"  # El Salvadoran Colon
    SYP = "SYP"  # Syrian Pound
    SZL = "SZL"  # Swazi Lilangeni
    THB = "THB"  # Thai Baht
    TJS = "TJS"  # Tajikistani Somoni
    TMT = "TMT"  # Turkmenistan New Manat
    TND = "TND"  # Tunisian Dinar
    TOP = "TOP"  # Tongan Pa'anga
    TRY = "TRY"  # Turkish Lira
    TTD = "TTD"  # Trinidad and Tobago Dollar
    TWD = "TWD"  # New Taiwan Dollar
    TZS = "TZS"  # Tanzanian Shilling
    UAH = "UAH"  # Ukrainian Hryvnia
    UGX = "UGX"  # Ugandan Shilling
    USD = "USD"  # United States Dollar
    USN = "USN"  # US Dollar (Next day)
    UYI = "UYI"  # Uruguayan Peso en Unidades Indexadas (UI)
    UYU = "UYU"  # Uruguayan Peso
    UYW = "UYW"  # Uruguayan Unidad Previsional
    UZS = "UZS"  # Uzbekistani Som
    VAL = "VAL"  # Vatican Lira.
    VES = "VES"  # Venezuelan Bolívar Soberano
    VND = "VND"  # Vietnamese Dong
    VUV = "VUV"  # Vanuatu Vatu
    WST = "WST"  # Samoan Tala
    XAF = "XAF"  # Central African CFA Franc
    XAG = "XAG"  # Silver
    XAU = "XAU"  # Gold
    XBA = "XBA"  # Bond Markets Unit European Composite Unit (EURCO)
    XBB = "XBB"  # Bond Markets Unit European Monetary Unit (E.M.U.-6)
    XBC = "XBC"  # Bond Markets Unit European Unit of Account 9 (E.U.A.-9)
    XBD = "XBD"  # Bond Markets Unit European Unit of Account 17 (E.U.A.-17)
    XBT = "XBT"  # Bitcoin
    XCD = "XCD"  # East Caribbean Dollar
    XDR = "XDR"  # SDR (Special Drawing Right)
    XOF = "XOF"  # West African CFA Franc
    XPD = "XPD"  # Palladium
    XPF = "XPF"  # CFP (French Polynesian) Franc
    XPT = "XPT"  # Platinum
    XSU = "XSU"  # Bolivarian Alliance for the Americas Sucre
    XUA = "XUA"  # African Development Bank Unit of Account
    XXX = "XXX"  # The codes assigned for transactions where no currency is involved
    YER = "YER"  # Yemeni Rial
    ZAR = "ZAR"  # South African Rand
    ZMW = "ZMW"  # Zambian Kwacha
    ZWL = "ZWL"  # Zimbabwean Dollar


class Denomination(TypeModel):
    name: str = Field(..., title="Name", description="The name of the denomination (e.g. Cents)")
    unit: float = Field(..., title="Unit", description="The ratio of this denominated unit relative to the major currency unit.")
    symbol: str | None = Field(
        default=None, title="Symbol", description="A currency symbol or currency sign is a graphic symbol used to denote a currency unit."
    )
    quote: bool = Field(False, title="Quote", description="Is this denomination a quotable unit (e.g. Cents), or used only for cash division (e.g. Dime)")


class CurrencyModel(ObservableModel):
    """
    Currency

    Represents a currency as defined by ISO 4217, including alpha/numeric codes,
    decimal precision, denomination structure, and deliverability status for FX
    settlement purposes.
    """

    __resource_id__ = CurrencyId

    alpha_code: str | None = Field(
        None,
        title="Alpha Code",
        description="ISO 4217 alphanumeric currency code, which is the ISO 3166 alpha-2 country code plus a letter which signifies the denomination.",
    )
    numeric_code: int | None = Field(
        None,
        title="Numeric Code",
        description="ISO 4217 three-digit numeric code assigned to the currency. This numeric code is usually the same as the numeric code assigned to the corresponding country by ISO 3166-1",
    )
    decimals: int | None = Field(
        default=2,
        title="Decimals",
        description="The default decimal precision for the currency, normally driven by the ratio of major to minor denominated unit.",
    )
    introduced: date | None = Field(default=None, title="Introduced", description="The year the currency was introduced into circulation.")
    denominations: List[Denomination] | None = Field(default=None, title="Denominations", description="The available denominated units of the currency.")
    deliverable: bool = Field(
        default=True,
        title="Deliverable",
        description="Whether the currency can be physically delivered in FX transactions.",
    )

    semantic_type: Literal["CURRENCY"] = "CURRENCY"

    @computed_field(
        title="Classification",
        return_type=AssetClassificationModel,
        description="Classification of asset in terms of asset class, market sector and asset type.",
    )
    def classification(self) -> AssetClassificationModel:
        return AssetClassificationModel(asset_class=AssetClass.MONEY_MARKET, market_sector=MarketSector.CURRENCY, asset_type=AssetType.CURRENCY)

    @property
    def resource_id(self) -> CurrencyId:
        return CurrencyId(id=self.id, name=self.name)


class ExchangeRateModel(ObservableModel):
    """
    Exchange Rate

    Represents a currency pair quoted as the value of one currency (unit) expressed
    in terms of another (per). Exchange rates serve as the underlying asset for FX
    derivatives including forwards, options, and swaps, as defined in the ISDA 1998
    FX and Currency Option Definitions.

    Supports both spot rates and fixing rates. Fixing rates are benchmark rates
    published at specific times (e.g. WM Reuters 4PM London, Bloomberg BFIX) used
    to settle non-deliverable forwards, value portfolios, and determine barrier events.
    """

    __resource_id__ = ExchangeRateId
    __uri_path__ = "assets/exchange-rates"

    unit: str | CurrencyId | CurrencyModel = Field(..., title="Unit", description="The currency unit of the exchange rate.")
    per: str | CurrencyId | CurrencyModel = Field(..., title="Per", description="The currency denominated by the exchange rate.")

    identifiers: List[AssetIdentifier] | None = Field(default=None, title="Identifiers", description="The identifiers associated with the exchange rate.")
    classification: AssetClassificationModel = Field(
        default=AssetClassificationModel(asset_class=AssetClass.FOREIGN_EXCHANGE, market_sector=MarketSector.CURRENCY, asset_type=AssetType.EXCHANGE_RATE),
        title="Classification",
        description="The classification of the asset.",
    )
    inverted: bool | None = Field(
        default=None,
        title="Inverted",
        description="Is the exchange rate quoted in the inverted format (e.g. USD/EUR instead of EUR/USD).",
    )

    semantic_type: Literal["EXCHANGE_RATE"] = "EXCHANGE_RATE"

    @property
    def resource_id(self) -> ExchangeRateId:
        return ExchangeRateId(id=self.id, name=self.name, version=self.version)


class ExchangeRateMarketDefaultsModel(AssetMarketDefaultsModel):
    semantic_type: Literal["EXCHANGE_RATE_MARKET_DEFAULTS"] = "EXCHANGE_RATE_MARKET_DEFAULTS"

    asset: ExchangeRateId | str | None = Field(
        default=None,
        title="Asset",
        description="The exchange rate these market defaults apply to.",
    )

    @property
    def resource_id(self) -> AssetMarketDefaultsId:
        return AssetMarketDefaultsId(id=self.id, version=self.version)

    fixing_sources: list[SettlementRateOptionId | str | SettlementRateOptionModel] | None = Field(
        default=None,
        title="Fixing Sources",
        description="Ordered list of default fixing sources for this asset.",
    )

    @classmethod
    def get_uri(cls, id: str | None = None) -> str:
        asset_id = id.split("_", 1)[1] if id and "_" in id else id
        return f"assets/exchange-rates/{asset_id}/defaults" if asset_id else "assets/exchange-rates"

    @classmethod
    def save(cls, model: "ExchangeRateMarketDefaultsModel") -> "ExchangeRateMarketDefaultsModel":
        uri = cls.get_uri(model.id)
        if model.version:
            response = Session.current.put(uri, model.to_json())
        else:
            response = Session.current.post(uri, model.to_json())
        result: ExchangeRateMarketDefaultsModel = Serializer.deserialize(response, cls)  # type: ignore[assignment]
        return result


ValidAssetDefaultModelUnion = Union[ExchangeRateMarketDefaultsModel,]
ValidAssetDefaultModel = Annotated[
    ValidAssetDefaultModelUnion,
    Field(discriminator="semantic_type"),
]
