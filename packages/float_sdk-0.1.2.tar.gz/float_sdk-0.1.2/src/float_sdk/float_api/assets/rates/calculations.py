# pyright: basic

"""
Rate Calculation Enums

Enums for interest rate calculation methods including averaging and
negative rate treatment, per ISDA 2000/2021 Definitions.
"""

from enum import Enum


class AveragingWeightingMethod(Enum):
    """
    Averaging Weighting Method

    The enumerated values to specify the method of calculation to be used when averaging rates.
    Per ISDA 2000 Definitions, Section 6.2. Certain Definitions Relating to Floating Amounts.

    Attributes
    ----------
    UNWEIGHTED : The arithmetic mean of the relevant rates for each reset date.
    WEIGHTED : The arithmetic mean of the relevant rates in effect for each day in a calculation
        period calculated by multiplying each relevant rate by the number of days such relevant
        rate is in effect, determining the sum of such products and dividing such sum by the
        number of days in the calculation period..
    """

    UNWEIGHTED = "UNWEIGHTED"
    WEIGHTED = "WEIGHTED"


class NegativeInterestRateTreatment(Enum):
    """
    Negative Interest Rate Treatment

    The enumerated values to specify the method of calculating payment obligations when a
    floating rate is negative (either due to a quoted negative floating rate or by operation
    of a spread that is subtracted from the floating rate).

    Attributes
    ----------
    NEGATIVE_INTEREST_RATE_METHOD : Negative Interest Rate Method. Allows interest rates to go
        negative, and these rates will be used in any subsequent cashflow calcuation. In this
        case a party to the transaction may receieve payments where they would normally pay.
        Per 2000 ISDA Definitions, Section 6.4 Negative Interest Rates, paragraphs (b) and (c).
    ZERO_INTEREST_RATE_METHOD : Zero Interest Rate Method. Floors the rate (including spread)
        at zero, so that there are no inverse payments.
        Per 2000 ISDA Definitions, Section 6.4. Negative Interest Rates, paragraphs (d) and (e).
    ZERO_INTEREST_RATE_EXCLUDING_SPREAD_METHOD : Zero Interest Rate Excluding Spread Mothod.
        Floors the rate (excluding spread) at zero. The spread is applied to the floored rate.
        Per 2021 ISDA Definitions section 6.8.6

    """

    NEGATIVE_INTEREST_RATE_METHOD = "NEGATIVE_INTEREST_RATE_METHOD"
    ZERO_INTEREST_RATE_METHOD = "ZERO_INTEREST_RATE_METHOD"
    ZERO_INTEREST_RATE_EXCLUDING_SPREAD_METHOD = "ZERO_INTEREST_RATE_EXCLUDING_SPREAD_METHOD"
