# pyright: basic

"""
Rate Asset Models

Exports for rate models - fixed rates, floating rates, rate indices, etc.
"""

from float_sdk.float_api.assets.base.settlement import (
    SettlementRateOptionBaseModel,
    SettlementRateOptionModel,
    SyntheticSettlementRateOptionModel,
)
from float_sdk.float_api.assets.rates.rates import (
    FixedRateModel,
    FloatingRateIndexModel,
    FloatingRateModel,
    FloatingRateOptionModel,
    InflationRateIndexModel,
    InflationRateModel,
    InflationRateOptionModel,
    RateIndexModel,
    RateOptionModel,
    RateOptionSpreadModel,
    RateSourceModel,
    ResetInfoModel,
    SyntheticRateSourceModel,
    TenorModel,
)

__all__ = [
    "FixedRateModel",
    "FloatingRateIndexModel",
    "FloatingRateModel",
    "FloatingRateOptionModel",
    "InflationRateIndexModel",
    "InflationRateModel",
    "InflationRateOptionModel",
    "RateIndexModel",
    "RateOptionModel",
    "RateOptionSpreadModel",
    "RateSourceModel",
    "ResetInfoModel",
    "SettlementRateOptionBaseModel",
    "SettlementRateOptionModel",
    "SyntheticRateSourceModel",
    "SyntheticSettlementRateOptionModel",
    "TenorModel",
]
