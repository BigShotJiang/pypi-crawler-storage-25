#!/usr/bin/env python
# pyright: basic

"""
Interest Rate Assets and Observables

Models for interest rate indices, floating rate options, inflation indices, rate sources,
and settlement rate options. Floating rate options and index classifications are aligned
with the ISDA 2021 Interest Rate Definitions. Settlement rate options and rate sources
follow the ISDA 1998 FX and Currency Option Definitions.
"""

from datetime import date, datetime, time
from enum import Enum
from typing import Annotated, List, Literal, Optional, Union

from pydantic import Field, field_validator

from float_sdk.float_api.assets.base.base import AssetClassificationModel, ObservableModel
from float_sdk.float_api.assets.base.settlement import SettlementRateOptionModel, SyntheticSettlementRateOptionModel
from float_sdk.float_api.assets.currencies.currencies import CurrencyModel
from float_sdk.float_api.assets.rates.calculations import (
    AveragingWeightingMethod,
    NegativeInterestRateTreatment,
)
from float_sdk.float_api.base.math import RoundingModel
from float_sdk.float_api.base.references import (
    CurrencyId,
    EntityId,
    ExchangeRateId,
    FloatingRateIndexId,
    FloatingRateOptionId,
    HolidayCalendarId,
    IndexId,
    InflationRateIndexId,
    JurisdictionId,
    RateOptionSpreadId,
    RateSourceId,
    SettlementRateOptionId,
    SyntheticRateSourceId,
)
from float_sdk.float_api.datetime.calendars import HolidayCalendarModel
from float_sdk.float_api.datetime.conventions import BusinessDayConvention, DayCountConvention
from float_sdk.float_api.datetime.schedule import RelativeDateModel
from float_sdk.float_api.datetime.tenor import TenorModel
from float_sdk.float_api.locations.location import TimeLocationModel
from float_sdk.float_api.organizations.legal import EntityModel
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DesignatedMaturityModel(DataModel):
    """
    Designated Maturity

    The set of available tenors for a floating rate index as of a given effective date,
    per the ISDA 2021 Interest Rate Definitions. For example, SOFR Term rates may be
    published for 1M, 3M, 6M, and 12M tenors.
    """

    effective_date: date = Field(..., title="Effective Date", description="Date on which the maturities were available for use.")
    maturities: List[TenorModel | str] | None = Field(default=None, title="Maturities", description="List of available maturities.")


class FixedRateModel(DataModel):
    rate: float | None = Field(default=None, title="Rate", description="The specified fixed interest rate.")
    rounding: RoundingModel | None = Field(
        default=None, title="Rounding", description="Number of decimal places to round the interest rate prior to computing cashflows."
    )
    negative_rate_treatment: NegativeInterestRateTreatment | None = Field(
        None, title="Negative Rate Treatment", description="Specification of how to handle negative interest rates."
    )

    semantic_type: Literal["FIXED_RATE"] = "FIXED_RATE"


class FixingModel(DataModel):
    """
    Floating Rate Fixing

    Publication and determination timing for a floating rate index fixing, including
    the official fixing time, publication time, and determination window. Aligned with
    the fixing time specifications in the ISDA 2021 Interest Rate Definitions.
    """

    @field_validator("fixing_time", "publication_time", "availability", "determination_start", "determination_end", mode="before")
    def datetime_to_time(cls, v):
        if isinstance(v, datetime):
            return v.time()
        return v

    jurisdiction: JurisdictionId | str | None = Field(default=None, title="Jurisdiction", description="Jurisdiction where the fixing is calculated.")
    fixing_time: time = Field(..., title="Fixing Time", description="Time at the specified jurisdiction to compute rate fixing.")
    publication_time: time | None = Field(default=None, title="Publication Time", description="Time at which the fixing is published.")
    availability: time | None = Field(default=None, title="Availability", description="Time at which the fixing is generally available.")
    determination_start: time | None = Field(
        None, title="Determination Start", description="Start of determination period, if computed over a specified range."
    )
    determination_end: time | None = Field(
        default=None, title="Determination End", description="End of determination period, if computed over a specified range."
    )


class ResetInfoModel(DataModel):
    reset_to_fixing: RelativeDateModel = Field(..., title="Reset To Fixing", description="Reset to fixing date rules.")


class FloatingRateIndexCategory(Enum):
    """
    Top-level ISDA floating rate option category as defined in the
    ISDA 2021 Interest Rate Definitions.

    Attributes
    ----------
    SCREEN_RATE : The rate is observed directly from a screen.
    CALCULATED : The rate is calculated by the calculation agents from multiple observations.
    REFERENCE_BANKS : The rate is obtained by polling several other banks.
    """

    SCREEN_RATE = "Screen Rate"
    CALCULATED = "Calculated Rate"
    REFERENCE_BANKS = "Reference Banks Rate"


class FloatingRateIndexStyle(Enum):
    """
    Index calculation style for floating rate indices as defined in the
    ISDA 2021 Interest Rate Definitions.

    AVERAGE_FRO : An ISDA-defined calculated rate done using arithmetic averaging.
    COMPOUNDED_FRO : Compounding over a given period using defined rules.
    COMPOUNDED_INDEX : A published index calculated using compounding.
    INDEX : A published index using a methodology defined by the publisher, e.g. S&P 500.
    OTHER : An alternative calculation methodology.
    OVERNIGHT : An overnight published rate.
    PUBLISHED_AVERAGE : A published rate computed using an averaging methodology.
    SWAP_RATE : A rate representing the market rate for swaps of a given maturity.
    TERM_RATE : A rate specified over a given term, such as a LIBOR-type rate.
    """

    AVERAGE_FRO = "Average FRO"
    COMPOUNDED_FRO = "COMPOUNDED_FRO"
    COMPOUNDED_INDEX = "Compounded Index"
    INDEX = "Index"
    OTHER = "Other FRO"
    OVERNIGHT = "Overnight Rate"
    PUBLISHED_AVERAGE = "Published Average Rate"
    SWAP_RATE = "Swap Rate"
    TERM_RATE = "Term Rate"


class FloatingRateIndexCalculationMethod(Enum):
    """
    Floating rate index calculation method per the ISDA 2021 Interest Rate Definitions.

    OIS_COMPOUND : A calculation methodology using the ISDA-defined OIS compounding formula.
    AVERAGE : A calculation methodology using the arithmetic mean.
    """

    OIS_COMPOUND = "OIS Compounding"
    AVERAGE = "Overnight Average"


class RateIndexModel(ObservableModel):
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")

    ## Publication information
    #
    introduced: date | int | None = Field(default=None, title="Introduced", description="When the rate index was introduced to the market.")
    administrator: EntityId | str | EntityModel | None = Field(
        None, title="Administrator", description="Entity which administors the rate calculation and publication."
    )

    ## Economics
    #
    currency: CurrencyId | str | CurrencyModel | None = Field(default=None, title="Currency", description="Currency of the index.")
    calendar: HolidayCalendarId | str | HolidayCalendarModel | None = Field(
        default=None, title="Calendar", description="Business days of rate index publication."
    )
    day_count_convention: DayCountConvention | None = Field(
        default=None, title="Day Count Convention", description="Default day count convention for rate accrual."
    )
    business_day_convention: BusinessDayConvention | None = Field(
        default=None, title="Business Day Convention", description="Default business day convention for rate accrual."
    )
    fixing_time: TimeLocationModel | None = Field(default=None, title="Fixing Time", description="Time and location for the rate fixing.")
    reset_info: Optional[ResetInfoModel] = Field(default=None, title="Reset Info", description="Specification for reset to fixing lag.")


class FloatingRateIndexModel(RateIndexModel):
    """
    Floating Rate Index

    A published benchmark interest rate (e.g. SOFR, EURIBOR, SONIA, TONA) that serves
    as the reference for floating rate instruments. Floating rate indices are defined in
    the ISDA 2021 Interest Rate Definitions and classified by category (screen rate,
    calculated, reference banks), style (overnight, term, compounded), and calculation
    method (OIS compounding, arithmetic averaging).
    """

    __uri_path__ = "assets/indices/rates"

    category: FloatingRateIndexCategory | None = Field(default=None, title="Category", description="Top level ISDA floating rate option category")
    style: FloatingRateIndexStyle | None = Field(default=None, title="Category", description="Top level ISDA floating rate option category")
    calculation_method: FloatingRateIndexCalculationMethod | None = Field(
        default=None, title="Calculation Method", description="Calculation method per ISDA definitions used to compute index fixing."
    )
    designated_maturity_applicable: bool | None = Field(
        default=None,
        title="Designated Maturity Applicable",
        description="Whether this rate index requires a floating rate option with defined designated maturity to be specified to observe a rate fixing.",
    )

    semantic_type: Literal["FLOATING_RATE_INDEX"] = "FLOATING_RATE_INDEX"

    @property
    def resource_id(self) -> FloatingRateIndexId:
        return FloatingRateIndexId(id=self.id, name=self.name)


class InflationRateIndexModel(RateIndexModel):
    """
    Inflation Rate Index

    A published price index (e.g. US CPI-U, UK RPI, EUR HICP) that tracks changes in
    the general price level of goods and services. Used as the reference for inflation-linked
    derivatives (zero-coupon inflation swaps, year-on-year inflation swaps, inflation caps/floors)
    per the ISDA 2008 Inflation Definitions.
    """

    __uri_path__ = "assets/indices/inflation"

    semantic_type: Literal["INFLATION_RATE_INDEX"] = "INFLATION_RATE_INDEX"

    @property
    def resource_id(self) -> InflationRateIndexId:
        return InflationRateIndexId(id=self.id, name=self.name)


class RateOptionModel(ObservableModel):
    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")

    index: IndexId | str = Field(..., title="Index", description="Identifier of the rate index.")
    tenor: TenorModel = Field(..., title="Tenor", description="Designated maturity of the rate option.")

    semantic_type: Literal["RATE_OPTION"] = "RATE_OPTION"


class FloatingRateOptionModel(RateOptionModel):
    """
    Floating Rate Option

    An ISDA floating rate option as defined in the ISDA 2021 Interest Rate Definitions.
    Combines a floating rate index (e.g. SOFR, EURIBOR) with a designated maturity tenor
    (e.g. 1M, 3M) to specify the exact rate observation used for calculating floating
    interest rate payments in swaps, FRNs, and other interest rate derivatives.
    """

    __uri_path__ = "assets/indices/options"

    index: FloatingRateIndexId | str = Field(..., title="Index", description="Identifier of the rate index.")
    semantic_type: Literal["FLOATING_RATE_OPTION"] = "FLOATING_RATE_OPTION"

    @property
    def resource_id(self) -> FloatingRateOptionId:
        return FloatingRateOptionId(id=self.id, name=self.name)


class InflationRateOptionModel(RateOptionModel):
    """
    Inflation Rate Option

    An ISDA inflation rate option as defined in the ISDA 2008 Inflation Definitions.
    Combines an inflation rate index (e.g. US CPI-U, UK RPI) with a designated maturity
    to specify the rate observation used for calculating inflation-linked payments.
    """

    semantic_type: Literal["INFLATION_RATE_OPTION"] = "INFLATION_RATE_OPTION"


class RateOptionSpreadModel(ObservableModel):
    """
    Rate Option Spread

    A spread interest rate asset represents the difference between two distinct interest rate
    instruments, typically defined by their underlying index and tenor. This asset is
    constructed by taking a long position in one rate and a short position in another,
    capturing relative value dynamics between maturities, currencies, or rate structures.
    For example, the USD 30-year swap rate minus the USD 5-year swap rate measures the
    steepness of the swap curve and reflects market expectations of long-term versus
    short-term interest rate movements. Such spreads are commonly used in macroeconomic
    positioning, relative value trading, and hedging strategies, offering exposure to
    shifts in yield curves, monetary policy changes, and liquidity conditions.

    The pricing and risk characteristics of these instruments are driven by factors such
    as forward rate expectations, volatility term structures, and central bank policy outlooks.
    """

    __uri_path__ = "assets/indices/options/spreads"

    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")

    long_leg: FloatingRateOptionId | str | FloatingRateOptionModel = Field(..., title="Long Leg", description="The long leg (or front leg) of the spread")
    short_leg: FloatingRateOptionId | str | FloatingRateOptionModel = Field(..., title="Short Leg", description="The short leg (or back leg) of the spread")

    semantic_type: Literal["RATE_OPTION_SPREAD"] = "RATE_OPTION_SPREAD"

    @property
    def resource_id(self) -> RateOptionSpreadId:
        return RateOptionSpreadId(id=self.id, name=self.name)


class FloatingRateModel(DataModel):
    """
    Floating Rate

    Specification of a floating interest rate referencing a rate option (e.g. SOFR, EURIBOR)
    with optional spread, multiplier, cap/floor, and averaging method. Used within interest
    rate swap legs and floating rate note coupons per the ISDA 2021 Interest Rate Definitions.
    """

    rate_option: FloatingRateOptionId | RateOptionSpreadId | str | FloatingRateOptionModel | RateOptionSpreadModel | None = Field(
        default=None, title="Rate Option", description="The floating rate option associated with this floating rate."
    )
    rounding: RoundingModel | None = Field(
        default=None, title="Rounding", description="Number of decimal places to round the interest rate prior to computing cashflows."
    )
    negative_rate_treatment: NegativeInterestRateTreatment | None = Field(
        default=None, title="Negative Rate Treatment", description="Specification of how to handle negative interest rates."
    )
    spread: float | None = Field(default=None, title="Spread", description="The spread to be added to the floating rate.")
    multiplier: float | None = Field(default=None, title="Multiplier", description="A multiplier applied to the floating rate.")
    cap: float | None = Field(default=None, title="Cap", description="The maximum value (cap) for the floating rate.")
    floor: float | None = Field(default=None, title="Floor", description="The minimum value (floor) for the floating rate.")
    averaging_method: AveragingWeightingMethod | None = Field(
        default=None, title="Averaging Method", description="The method used to average rate fixings over a period."
    )

    semantic_type: Literal["FLOATING_RATE"] = "FLOATING_RATE"


class InflationRateModel(DataModel):
    """
    Inflation Rate

    Rate specification for inflation-linked cashflows per the ISDA 2008 Inflation
    Definitions. References an inflation index (e.g. CPI, RPI) with an inflation lag
    that determines the reference period for index observation relative to payment dates.
    """

    rate_index: InflationRateIndexId | str | InflationRateIndexModel | None = Field(
        default=None,
        title="Rate Index",
        description="The inflation index (e.g., CPI, RPI) used for calculating inflation-linked payments. Unlike floating rate options, this does not include a tenor.",
    )
    inflation_lag: RelativeDateModel | None = Field(
        default=None,
        title="Inflation Lag",
        description="An off-setting period from the payment date which determines the reference period for which the inflation index is observed.",
    )
    spread: float | None = Field(default=None, title="Spread", description="The spread to be added to the inflation rate.")
    semantic_type: Literal["INFLATION_RATE"] = "INFLATION_RATE"


# Discriminated union for Settlement Rate Option models (used in SyntheticSettlementRateOptionModel fields)
SettlementRateOptionModels = Annotated[
    Union[SettlementRateOptionModel, SyntheticSettlementRateOptionModel],
    Field(discriminator="semantic_type"),
]

# Discriminated union of all Rate Option Model types (used in RateSourceModel)
ValidRateOptionModels = Annotated[
    Union[SettlementRateOptionModel, SyntheticSettlementRateOptionModel, FloatingRateOptionModel],
    Field(discriminator="semantic_type"),
]

# Overall union including ID types, str, and the discriminated models
ValidRateOptionFieldTypes = Union[
    SettlementRateOptionId,
    FloatingRateOptionId,
    str,
    ValidRateOptionModels,
]


class RateSourceModel(ObservableModel):
    """
    Rate Source

    An observable fixing source that combines a settlement rate option with a specific
    asset (e.g. exchange rate) and fixing time/location. Rate sources are the concrete
    observables used to determine settlement rates for non-deliverable and cash-settled
    FX transactions per the ISDA 1998 FX and Currency Option Definitions.
    """

    __resource_id__ = RateSourceId
    __uri_path__ = "assets/rates/sources"

    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")

    rate_option: ValidRateOptionFieldTypes | None = Field(
        default=None, title="Rate Option", description="The settlement rate option associated with the fixing source."
    )
    asset: ExchangeRateId | str | None = Field(
        default=None,
        title="Asset",
        description="The asset for which the fixing source provides rates. This is typically an exchange rate or interest rate option.",
    )
    fixing_time: TimeLocationModel = Field(
        ...,
        title="Time Location",
        description="The time and location at which the fixing source provides rates. This is typically a specific time and location for the exchange rate or interest rate option.",
    )

    semantic_type: Literal["RATE_SOURCE"] = "RATE_SOURCE"


class SyntheticRateSourceModel(ObservableModel):
    """
    Synthetic Rate Source

    A rate source that derives a fixing rate from two other rate sources where no direct
    fixing exists for a given currency pair, per the ISDA 1998 FX and Currency Option
    Definitions. Commonly used to construct cross-rate fixings from corresponding USD
    crosses (e.g. EUR/BRL derived from EUR/USD and USD/BRL rate sources).
    """

    __resource_id__ = SyntheticRateSourceId
    __uri_path__ = "assets/rates/sources/synthetic"

    classification: AssetClassificationModel | None = Field(default=None, title="Classification", description="The classification of the asset.")

    asset: ExchangeRateId = Field(
        ...,
        title="Asset",
        description="The asset for which the synthetic fixing source provides rates. This is typically an exchange rate or interest rate option.",
    )

    rate_option_1: SettlementRateOptionId | str | SettlementRateOptionModel | None = Field(
        default=None, title="Rate Option 1", description="The settlement rate option associated with the synthetic fixing source."
    )

    rate_option_2: SettlementRateOptionId | str | SettlementRateOptionModel | None = Field(
        default=None, title="Rate Option 2", description="The settlement rate option associated with the synthetic fixing source."
    )

    semantic_type: Literal["SYNTHETIC_RATE_SOURCE"] = "SYNTHETIC_RATE_SOURCE"
