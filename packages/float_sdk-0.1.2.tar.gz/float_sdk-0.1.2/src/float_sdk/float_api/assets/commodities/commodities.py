#!/usr/bin/env python
# pyright: basic

"""
Commodity Assets

Commodity asset models and reference prices for financial derivative transactions.
Commodity reference prices are aligned to the 2005 ISDA Commodity Definitions.
"""

from typing import List, Literal

from pydantic import Field

from float_sdk.float_api.assets.base.base import AssetClass, AssetClassificationModel, AssetIdentifier, AssetType, MarketSector, ObservableModel
from float_sdk.float_api.base.references import CommodityId
from float_sdk.float_api.serialization.model import DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class CommodityModel(ObservableModel):
    """
    Commodity

    A commodity asset used as the underlying for derivative instruments such as futures, options,
    and swaps, as defined in the 2005 ISDA Commodity Definitions. Includes energy products
    (e.g. crude oil, natural gas), metals (e.g. gold, silver, copper), and agricultural goods
    (e.g. wheat, coffee), standardized for trading on regulated exchanges or OTC markets.
    """

    __resource_id__ = CommodityId
    __uri_path__ = "assets/commodities"

    identifiers: List[AssetIdentifier] | None = Field(default=None, title="Identifiers", description="The identifiers associated with the exchange rate.")
    classification: AssetClassificationModel = Field(
        default=AssetClassificationModel(asset_class=AssetClass.COMMODITY, market_sector=MarketSector.COMMOD, asset_type=AssetType.COMMODITY),
        title="Classification",
        description="The classification of the asset.",
    )

    semantic_type: Literal["COMMODITY"] = "COMMODITY"


class CommodityReferencePrice(DisplayEnum):
    """
    Commodity reference price codes as defined in the Annex to the 2005 ISDA Commodity Definitions.
    Each code identifies a specific benchmark price source used to determine settlement rates
    for commodity derivative transactions.
    """

    GOLD_A_M___FIX = "GOLD-A.M. FIX"
    GOLD_P_M___FIX = "GOLD-P.M. FIX"
    SILVER_FIX = "SILVER-FIX"
    CME_CF_BITCOIN_REFERENCE_RATE = "CME CF Bitcoin Reference Rate"

    def display_names(self) -> dict[str, str]:
        return {
            "GOLD_A_M___FIX": "GOLD-A.M. FIX",
            "GOLD_P_M___FIX": "GOLD-P.M. FIX",
            "SILVER_FIX": "SILVER-FIX",
            "CME_CF_BITCOIN_REFERENCE_RATE": "CME CF Bitcoin Reference Rate",
        }
