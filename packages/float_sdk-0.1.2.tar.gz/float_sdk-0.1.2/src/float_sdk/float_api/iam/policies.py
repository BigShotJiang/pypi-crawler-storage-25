#!/usr/bin/env python
# pyright: strict

"""
Entitlements Policies

"""

from enum import Enum
from typing import List, Literal, Optional

from pydantic import Field

from float_sdk.float_api.api.resource import ResourceModel
from float_sdk.float_api.base.references import OrganizationId, ReferenceTypes
from float_sdk.float_api.organizations.people import OrganizationApplicationRole, OrganizationPersonRole, PlatformRole
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class Entitlement(Enum):
    """
    The entitlement enumeration defines the nature of the policy rule being
    applied against a given resource. This defines whether a given rule is
    permissive (allow) or disallows access (deny). Any deny rule on a given
    resource will take precedence over previously granted permissive rules.
    """

    ALLOW = "ALLOW"
    # DENY = "DENY"


class EntitlementAction(Enum):
    """
    Defines the action the principal user (person or group) is attempting to
    perform on a given resource. Entitlement policies define collections of
    rules which can specify different permissions per action on a resource.

    For example, a policy may allow the ability to view a resource, but not
    manage the resource (update or delete).
    """

    VIEW = "VIEW"
    MANAGE = "MANAGE"
    QUERY = "QUERY"


class ResourceEntitlementRuleModel(DataModel):
    """
    An entitlement rule, which defines the ability for a given identify to
    perform a defined action on a resource which matches the given attribute.
    """

    entitlement: Entitlement = Field(..., title="Entitlement", description="The access rule (e.g. allow / deny)")
    action: EntitlementAction = Field(..., title="Action", description="The action the user wants to perform (e.g. view, manage)")
    resource: str = Field(..., title="Resource", description="The resource on which access is being requested.")
    match_value: Optional[ReferenceTypes] = Field(
        default=None, title="Match Value", description="The value to match against on the resource (e.g. an organization or person id)"
    )
    match_field: str | None = Field(default=None, title="Match Field", description="The field on the resource to match against (e.g. 'organization.id')")
    description: str | None = Field(default=None, title="Description", description="Description of the rule")

    semantic_type: Literal["RESOURCE_ENTITLEMENT_RULE"] = "RESOURCE_ENTITLEMENT_RULE"


class EntitlementPolicyModel(DataModel):
    """
    An entitlement policy, which enumerates a set of rules for the ability to
    perform various actions on a set of resources.
    """

    rules: List[ResourceEntitlementRuleModel] = Field([], title="Rules", description="The list of entitlememnt rules.")

    semantic_type: Literal["ENTITLEMENT_POLICY"] = "ENTITLEMENT_POLICY"


class RolePolicyModel(ResourceModel):
    organization: OrganizationId | str | None = Field(default=None, title="Organization", description="The organization this role policy belongs to.")
    role: OrganizationPersonRole | OrganizationApplicationRole | PlatformRole = Field(
        ..., title="Role", description="The role for which this policy override applies."
    )
    enabled: bool = Field(default=True, title="Enabled", description="Whether this role policy is enabled for the organization.")
    policy: EntitlementPolicyModel = Field(..., title="Policy", description="The entitlement policy for this role.")

    semantic_type: Literal["ROLE_POLICY"] = "ROLE_POLICY"
