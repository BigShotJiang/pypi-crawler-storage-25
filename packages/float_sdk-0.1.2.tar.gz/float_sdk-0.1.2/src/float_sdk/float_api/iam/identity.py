#!/usr/bin/env python
# pyright: basic

"""
Identity Models

"""

from datetime import datetime
from enum import Enum
from typing import List, Literal, Optional

from pydantic import Field

from float_sdk.float_api.api.resource import NamedResourceModel, ResourceIdentifierModel
from float_sdk.float_api.base.document import DocumentType
from float_sdk.float_api.base.references import CredentialsId, EntityId, OrganizationId, PersonId
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Tyler Evans"
__copyright__ = "Copyright 2023, Float Technologies"
__email__ = "tyler.evans@floattechnologies.io"


class IdentityModel(NamedResourceModel):
    pass


class UserModel(IdentityModel):
    id: str = ""
    type: str = ""
    domain: str = ""
    person: PersonId
    organization: OrganizationId
    email: str = ""


class CredentialIdentifierType(Enum):
    ARN = "ARN"


class CredentialIdentifier(ResourceIdentifierModel):
    type: CredentialIdentifierType = Field(..., title="Type", description="The type of credential identifier (e.g. ARN).")


class DocumentCredentialsDataModel(DataModel):
    password: str | None = Field(default=None, title="Password", description="The plaintext password (only present in decrypted responses).")
    encrypted_password: str | None = Field(default=None, title="Encrypted Password", description="The encrypted password blob stored in AWS KMS.")
    encrypted_key: str | None = Field(default=None, title="Encrypted Key", description="The encrypted data key used to encrypt the password.")
    document_type: DocumentType | None = Field(default=None, title="Document Type", description="The type of document these credentials are used to access.")

    semantic_type: Literal["DOCUMENT_CREDENTIALS_DATA"] = "DOCUMENT_CREDENTIALS_DATA"


class UserCredentialsDataModel(DataModel):
    username: str | None = Field(default=None, title="Username", description="The username for authentication.")
    password: str | None = Field(default=None, title="Password", description="The plaintext password (only present in decrypted responses).")
    encrypted_password: str | None = Field(default=None, title="Encrypted Password", description="The encrypted password blob stored in AWS KMS.")
    encrypted_key: str | None = Field(default=None, title="Encrypted Key", description="The encrypted data key used to encrypt the password.")

    semantic_type: Literal["USER_CREDENTIALS_DATA"] = "USER_CREDENTIALS_DATA"


CredentialsDataModel = DocumentCredentialsDataModel | UserCredentialsDataModel | None


class CredentialsModel(IdentityModel):
    """
    Base credentials model for storing encrypted passwords
    """

    __uri_path__ = "auth/credentials"
    __resource_id__ = CredentialsId

    issuing_entity: EntityId | str | None = Field(default=None, title="Issuing Entity", description="The legal entity that issued these credentials.")
    identifiers: list[CredentialIdentifier] | None = Field(
        default=None, title="Identifiers", description="External identifiers for the credentials (e.g. AWS Secrets Manager ARN)."
    )

    organization: OrganizationId | str | None = Field(default=None, title="Organization", description="The organization that owns these credentials.")
    expiry_time: datetime | None = Field(default=None, title="Expiry Time", description="The date and time when the credentials expire.")

    data: CredentialsDataModel = Field(default=None, title="Data", description="The credentials data payload containing authentication details.")

    semantic_type: Literal["CREDENTIALS"] = "CREDENTIALS"

    class Config:
        json_schema_extra = {
            "title": "Credentials",
            "description": "Credentials encapsulate the details required to authenticate to a resource or service. Credentials are stored securely using encryption.",
            "example": {
                "id": "c8031aadfb7847f787829d2f569c8a4c",
                "version": "477dae742b954d52b3332d87e7be9e21",
                "name": "Example Client SFTP",
                "description": "SFTP credentials for market data feed",
                "data": {
                    "username": "sftp_user",
                    "semanticType": "USER_CREDENTIALS_DATA",
                },
                "identifiers": [
                    {
                        "value": "arn:aws:secretsmanager:us-east-1:123456789012:secret:example-sftp-creds-abc123",
                        "type": "ARN",
                    }
                ],
                "organization": "0c3e666eb46c448786e2cab0cf0f49b5",
                "semanticType": "CREDENTIALS",
            },
        }

    @property
    def resource_id(self) -> CredentialsId:
        return CredentialsId(id=self.id, name=self.name, version=self.version)

    @property
    def password(self) -> str | None:
        return self.data.password if self.data is not None else None

    @property
    def username(self) -> str | None:
        if isinstance(self.data, UserCredentialsDataModel):
            return self.data.username
        return None

    @property
    def encrypted(self) -> bool:
        if not self.data:
            return False
        return bool(self.data.encrypted_key and self.data.encrypted_password)


# keeping this for backwards compatibility
class UserCredentialsModel(IdentityModel):
    username: str | None = None
    password: str | None = None
    issuing_entity: EntityId | str | None = None
    identifiers: Optional[List[CredentialIdentifier]] = None

    semantic_type: Literal["USER_CREDENTIALS"] = "USER_CREDENTIALS"
