#!/usr/bin/env python
# pyright: basic

"""
Object Serialization.

Provides decorators for classes to allow serialization
to and from JSON format. Uses type information to map
attributes automatically.
"""

from float_sdk.float_api.base.enums import DisplayEnum as DisplayEnum
from float_sdk.float_api.serialization.types import TypeModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DataModel(TypeModel):
    def serialize(self) -> dict:
        return self.to_dict()
