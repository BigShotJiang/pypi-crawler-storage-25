#!/usr/bin/env python
# pyright: basic

"""
Object Serialization.

Provides decorators for classes to allow serialization
to and from JSON format. Uses type information to map
attributes automatically.
"""

import json
import re
from datetime import date, datetime, time
from enum import Enum
from functools import lru_cache
from keyword import iskeyword
from typing import Annotated, Any, Generic, List, Type, TypeVar, overload
from zoneinfo import ZoneInfo

import inflection
from inflection import camelize, underscore
from pydantic import BaseModel, BeforeValidator, ConfigDict, PlainSerializer, WithJsonSchema

from float_sdk.float_api.api.context import ContextMeta, ContextMetaInterface
from float_sdk.float_api.api.requests import FloatAPIException
from float_sdk.float_api.base.identifiers import AssetIdentifierType
from float_sdk.float_api.pydantic.caching_type_adapter import CachingTypeAdapter
from float_sdk.float_api.pydantic.rebuilding_metaclass import RebuildingBaseModelMetaclass

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


_KEYWORD_SUFFIX = "_value"
_ORIGIN = "__origin__"
_MODEL_SUFFIX = "Model"


class SerializationMode(Enum):
    PYTHON = "python"
    JSON = "json"
    NATIVE = "native"
    MONGO = "mongo"


# Allow serialization of ZoneInfo type to string
def parse_zoneinfo(v):
    if v is None or isinstance(v, ZoneInfo):
        return v
    try:
        return ZoneInfo(v)
    except Exception:
        raise ValueError(f"Invalid timezone: {v}")


TimezoneType = Annotated[
    ZoneInfo | None,
    BeforeValidator(parse_zoneinfo),
    PlainSerializer(lambda v: v.key if v else None, return_type=str),
    WithJsonSchema(
        {
            "type": "string",
            "format": "timezone",
            "description": "Timezone in IANA format.",
            "examples": ["Europe/London", "Asia/Tokyo"],
            "nullable": True,
        }
    ),
]


@lru_cache(maxsize=65536)
def _to_json_attribute_name(name: str) -> str:
    """
    Jsonic and safe attribute name
    Maps back to python keyword names and
    makes jsonic attributes
    """

    match = re.match(rf"(([\w]*)){_KEYWORD_SUFFIX}", name)
    if match and iskeyword(match[1]):
        name = match[1]

    return camelize(name, False)


def _to_python_attribtute_name(name: str):
    """Pythonic and safe attribute name
    Adjusts keyword names, makes pythonic_attributes
    """
    if iskeyword(name):
        name = f"{name}{_KEYWORD_SUFFIX}"

    name = re.sub(r"([a-z\d])([0-9])", r"\1_\2", name)
    return underscore(name)


def _is_subclass(child_type, parent_type):
    """Returns True if field is List"""
    return child_type is parent_type or hasattr(child_type, _ORIGIN) and getattr(child_type, _ORIGIN) is parent_type


def is_serializable(obj):
    """Returns True if obj is serializable."""

    return isinstance(obj, TypeModel)


def _to_dict(obj, mode: SerializationMode = SerializationMode.NATIVE):
    fields = vars(obj)

    if isinstance(obj, TypeModel):
        computed_fields = obj.model_computed_fields
        fields.update(computed_fields)

    res: dict[str, Any] = {}

    for key in fields:
        dict_key = _to_json_attribute_name(key)
        value = getattr(obj, key)

        if value or value == 0:
            res[dict_key] = _obj_to_dict(value, mode=mode)

    # Handle DataRow field path mapping for MONGO mode
    # Check for _fields attribute (DataRow duck typing) to avoid circular import
    if mode == SerializationMode.MONGO and "DataSchema" in obj.__class__.__name__:  # type: ignore[attr-defined]
        restructured = {}
        schema_field_ids = set()

        # Map schema fields according to their field_paths
        if hasattr(obj, "_fields"):
            for field in obj._fields:  # type: ignore[attr-defined]
                schema_field_ids.add(field.id)
                if field.id in res:
                    value = res[field.id]
                    path = field.field_path or field.id

                    # Handle nested paths like "metadata.exchangeRateId"
                    parts = path.split(".")
                    current = restructured

                    for i, part in enumerate(parts):
                        if i == len(parts) - 1:
                            # Last part - set the value
                            current[part] = value
                        else:
                            # Intermediate part - create nested dict if needed
                            if part not in current:
                                current[part] = {}
                            current = current[part]

        # Preserve fields not in schema (like id, system fields, etc.)
        for key, value in res.items():
            if key not in schema_field_ids:
                restructured[key] = value

        return restructured

    return res


def _obj_to_dict(obj, mode: SerializationMode = SerializationMode.NATIVE):
    if is_serializable(obj):
        return obj.to_dict(mode=mode)
    elif isinstance(obj, BaseModel):
        obj.__class__ = TypeModel
        return obj.to_dict(mode=mode)  # type: ignore[assignment]
    elif isinstance(obj, set):
        return list(obj)
    elif isinstance(obj, Enum):
        return obj.value
    elif isinstance(obj, ZoneInfo):
        return obj.key
    elif isinstance(obj, List):
        return list(map(lambda x: _obj_to_dict(x, mode=mode), obj))
    elif isinstance(obj, dict):
        return {_obj_to_dict(k, mode=mode): _obj_to_dict(v, mode=mode) for k, v in obj.items()}
    else:
        if mode == SerializationMode.NATIVE:
            if isinstance(obj, date):
                obj = str(obj)
        elif mode == SerializationMode.MONGO:
            if type(obj) is date:
                obj = datetime.combine(obj, datetime.min.time())
            if type(obj) is time:
                obj = datetime.combine(date.min, obj)

        return obj


class TypeModel(BaseModel, metaclass=RebuildingBaseModelMetaclass):
    model_config = ConfigDict(
        alias_generator=_to_json_attribute_name,
        use_enum_values=False,  # DO NOT CHANGE !
        populate_by_name=True,
    )

    def to_dict(self, mode: SerializationMode = SerializationMode.PYTHON):
        if mode in [SerializationMode.NATIVE, SerializationMode.MONGO]:
            return _to_dict(self, mode=mode)
        else:
            return self.model_dump(mode=mode.value, by_alias=True, exclude_none=True)

    def to_json(self, indent: int | None = None):
        return self.model_dump_json(by_alias=True, exclude_none=True, indent=indent)

    @classmethod
    def json_name(cls, name: str) -> str:
        return _to_json_attribute_name(name)

    @classmethod
    @lru_cache(maxsize=65536)
    def python_name(cls, name: str) -> str:
        return _to_python_attribtute_name(name)

    @classmethod
    @lru_cache(maxsize=65536)
    def model_name(cls, value: Any = None) -> str:
        value = value if value else cls
        model_name = value.__name__ if isinstance(value, type) else value.__class__.__name__
        model_name = model_name[: -len(_MODEL_SUFFIX)] if model_name.endswith(_MODEL_SUFFIX) else model_name

        return cls.python_name(model_name).upper()

    @classmethod
    @lru_cache(maxsize=65536)
    def model_display_name(cls, value: Any = None) -> str:
        model_name = cls.model_name(value)
        return inflection.titleize(model_name)

    @classmethod
    def from_dict(cls, obj: dict):
        return cls(**obj)

    @classmethod
    def from_json(cls, msg: str):
        d = json.loads(msg)
        return cls(**d)


T = TypeVar("T", bound=TypeModel)


class SerializationContext(ContextMetaInterface, metaclass=ContextMeta):
    def __init__(self, asset_identifier_type: AssetIdentifierType | None = None) -> None:
        self.asset_identifier_type = asset_identifier_type


class Serializer(Generic[T]):
    """Serialize and deserialize objects
    This class can create objects based on wire format.
    It will try to infer the correct types automatically
    based on the serialized message.
    """

    @overload
    @classmethod
    def deserialize(cls, message: List, var_type: Type[T]) -> List[T]: ...

    @overload
    @classmethod
    def deserialize(cls, message: dict[str, Any] | str | T, var_type: Type[T]) -> T: ...

    @classmethod
    def deserialize(cls, message: List | dict[str, Any] | str | T, var_type: Type[T]) -> T | List[T] | None:
        """
        Create object instance from message.
        Takes a json message or dict and constructs an
        object of the given type.
        """

        if message is None:
            return None
        elif isinstance(message, List):
            return CachingTypeAdapter.create_type_adapter(list[var_type]).validate_python(message)

        if isinstance(message, str):
            message = json.loads(message)

        if isinstance(message, dict):
            return CachingTypeAdapter.create_type_adapter(var_type).validate_python(message)

        if isinstance(message, var_type):
            return message
        else:
            raise FloatAPIException(message=f"Unsupported message type: {type(message)}")

    @classmethod
    def serialize(cls, obj: Any) -> dict | list[dict]:
        """
        Create message from object
        Takes a python object and constructs a serialized
        message in the relevant format (e.g. JSON)
        """

        if type(obj) is list:
            return list(map(lambda el: el.to_dict() if is_serializable(el) else el, obj))
        else:
            return obj.to_dict(mode=SerializationMode.JSON) if is_serializable(obj) else obj
