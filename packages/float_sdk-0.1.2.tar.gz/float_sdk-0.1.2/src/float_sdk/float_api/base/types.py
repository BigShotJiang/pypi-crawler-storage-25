# pyright: basic
#!/usr/bin/env python

"""
Semantic Date Types

Base semantic types which are used to provide additional context to primitive
type declarations. For example, representing an interest rate as a float loses
relevant context about how the type can be used in arithmetic, precision, and
display formatting.

"""

from typing import Annotated, Union

from pydantic import Field

from float_sdk.float_api.base.markup import MarkupDimension
from float_sdk.float_api.base.measures.base import ObjectDimension
from float_sdk.float_api.base.measures.dates import DateDimension, DateListDimension, DatetimeDimension, RelativeDateDimension, TenorDimension, TimeDimension
from float_sdk.float_api.base.measures.market import (
    Correlation,
    InterestRate,
    InterestRateSpread,
    MarketValue,
    Notional,
    NotionalQuantityModel,
    Price,
    Quantity,
    SpotRate,
    Spread,
    Variance,
    Volatility,
)
from float_sdk.float_api.base.measures.math import (
    BooleanDimension,
    IntegerMeasure,
    NumericMeasure,
    NumericMultiplier,
)
from float_sdk.float_api.base.measures.risk import Delta, Gamma, Rho, Theta, Vega
from float_sdk.float_api.base.measures.text import (
    EmailDimension,
    EnumDimension,
    EnumListDimension,
    FloatId,
    LabelDimension,
    StringDimension,
)

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


PrimitiveTypes = Annotated[
    Union[
        ## String types
        StringDimension,
        FloatId,
        EnumDimension,
        EnumListDimension,
        EmailDimension,
        LabelDimension,
        ## Date types
        DateDimension,
        DateListDimension,
        TimeDimension,
        DatetimeDimension,
        RelativeDateDimension,
        TenorDimension,
        ## Numeric types
        IntegerMeasure,
        BooleanDimension,
        NumericMeasure,
        ## Object types
        ObjectDimension,
        #
        ## Price and risk measures
        Price,
        Quantity,
        Volatility,
        Variance,
        InterestRate,
        InterestRateSpread,
        Notional,
        NotionalQuantityModel,
        NumericMultiplier,
        MarketValue,
        Correlation,
        Delta,
        SpotRate,
        Spread,
        Vega,
        Theta,
        Rho,
        Gamma,
        ## Markup types
        MarkupDimension,
    ],
    Field(discriminator="semantic_type"),
]
