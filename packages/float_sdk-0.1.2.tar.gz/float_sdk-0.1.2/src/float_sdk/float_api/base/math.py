# pyright: basic
#!/usr/bin/env python

"""
Math

Basic mathematical and numnerical operators

"""

from enum import Enum

from pydantic import Field

from float_sdk.float_api.serialization.model import DataModel, DisplayEnum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


class ProgressionType(DisplayEnum):
    """
    Type of mathematical progression for step-based calculations.

    Attributes
    ----------
    ARITHMETIC : Linear progression using addition/subtraction
    GEOMETRIC : Exponential progression using multiplication/division
    """

    ARITHMETIC = "ARITHMETIC"
    GEOMETRIC = "GEOMETRIC"

    def display_names(self) -> dict[str, str]:
        return {
            "ARITHMETIC": "Arithmetic",
            "GEOMETRIC": "Geometric",
        }


class RoundingDirection(Enum):
    """
    The enumerated values to specify the rounding direction to be used for numerical values.

    Attributes
    ----------
    UP : Round number up to the next integer. 1.2 rounds to 2
    DOWN : Round number down to the nearest integer. 1.7 rounds to 1
    NEAREST : Round to nearest integer. x.5 or above rounds up.
    """

    UP = "UP"
    DOWN = "DOWN"
    NEAREST = "NEAREST"


class RoundingModel(DataModel):
    """
    Rounding Specification

    Specification for how to round a floating point number.

    Attributes
    ----------
    rounding_direction: RoundingDirection
        Specifies the direction to round to the nearest integer
    precision : int
        Specifies the numnber of decimal places to which to round the number. Note that this is
        defined per the number in floating point form, not in percentage terms. So to round a
        percentage to 2.d.p (e.g. 2.57%) would require rouding precision of 4 for the floating
        point representation of 0.02573234

    """

    rounding_direction: RoundingDirection = Field(..., description="Rounding direction to use.")
    precision: int = Field(..., description="Precision to which to round.")
