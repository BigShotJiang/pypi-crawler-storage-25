# pyright: basic

from float_sdk.float_api.base.enums import DisplayEnum


class AssetIdentifierType(DisplayEnum):
    """
    Provides the enumerated values to specify the product identifier source.

    Attributes
    ----------
    FIGI : Issued under the guidelines of the Object Management Group, the Financial Instrument Global Identifier (FIGI) is a 12 character,
        alphanumeric, randomly generated ID covering hundreds of millions of active and inactive instruments. The identifier acts as a Uniform
        Resource Identifier (URI) to link to a set of metadata that uniquely and clearly describes the instrument.
    FIGI_COMPOSITE : Composite-level FIGI, representing a composite of all share classes for an issuer.
    FIGI_SHARE_CLASS : Share class-level FIGI, representing a specific share class of an issuer.
    RIC : Issued by Refinitiv (formerly Reuters), the Reuters Instrument Code (RIC) uniquely identifies financial instruments, including where they are traded.
    BBG_TICKER : Published by Bloomberg as a short code to identify publicly traded shares of a particular stock on a specific exchange.
    BBG_CODE : Bloomberg code, a unique identifier for a security in Bloomberg systems.
    BBG_EXCHANGE_CODE : Bloomberg exchange code, representing the exchange on which the security is listed.
    BBG_COMPOSITE_CODE : Bloomberg composite code, representing the composite ticker identifier.
    BBG_MARKET_SECTOR : Bloomberg market sector, indicating the sector classification of the security.
    TICKER : Ticker symbol, a short code used to uniquely identify a traded security.
    CROSS : Cross currency pair identifier, e.g., EURUSD.
    CUSIP : Committee on Uniform Securities Identification Procedures number, a 9-character alphanumeric code identifying North American securities.
    ISIN : International Securities Identification Number, a 12-character alphanumeric code that uniquely identifies a specific security.
    ISDA_NAME : ISDA standard name for rates and indices, e.g., EUR-ISDA-EURIBOR Swap Rate-11:00.
    TRADING_VIEW_ID : TradingView symbol identifier, used to uniquely identify securities on the TradingView platform.
    ASSET_ID : Internal asset identifier for a given organization.
    """

    FIGI = "FIGI"  # BBG000C6CH10
    FIGI_COMPOSITE = "FIGI_COMPOSITE"  # BBG000C6CFJ5
    FIGI_SHARE_CLASS = "FIGI_SHARE_CLASS"  # BBG001SC07Z6
    RIC = "RIC"  # GS.N
    BBG_TICKER = "BBG_TICKER"  # GS UN
    BBG_CODE = "BBG_CODE"  # GS UN Equity
    BBG_EXCHANGE_CODE = "BBG_EXCHANGE_CODE"  # UN
    BBG_COMPOSITE_CODE = "BBG_COMPOSITE_CODE"  # US
    BBG_MARKET_SECTOR = "BBG_MARKET_SECTOR"  # Equity
    TICKER = "TICKER"  # GS
    CROSS = "CROSS"  # EURUSD
    CUSIP = "CUSIP"  # 38141G104
    ISIN = "ISIN"  # US38141G1040
    ISDA_NAME = "ISDA_NAME"  # EUR-ISDA-EURIBOR Swap Rate-11:00
    TRADING_VIEW_ID = "TRADING_VIEW_ID"  # NYMEX:CLH25
    ASSET_ID = "ASSET_ID"
    FLOAT_ID = "FLOAT_ID"

    def display_names(self) -> dict[str, str]:
        return {
            "FIGI": "FIGI",
            "FIGI_COMPOSITE": "FIGI Composite",
            "FIGI_SHARE_CLASS": "FIGI Share Class",
            "RIC": "RIC",
            "BBG_TICKER": "Bloomberg Ticker",
            "BBG_CODE": "Bloomberg Code",
            "BBG_EXCHANGE_CODE": "Bloomberg Exchange Code",
            "BBG_COMPOSITE_CODE": "Bloomberg Composite Code",
            "BBG_MARKET_SECTOR": "Bloomberg Market Sector",
            "TICKER": "Ticker",
            "CROSS": "Cross",
            "CUSIP": "CUSIP",
            "ISIN": "ISIN",
            "ISDA_NAME": "ISDA Name",
            "TRADING_VIEW_ID": "TradingView",
            "ASSET_ID": "Asset ID",
            "FLOAT_ID": "Float ID",
        }
