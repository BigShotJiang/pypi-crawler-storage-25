# pyright: basic

import datetime
from typing import Literal

from pydantic import Field

from float_sdk.float_api.base.references import CurrencyId
from float_sdk.float_api.serialization.model import DataModel


class DatedValueModel(DataModel):
    """A value associated with a specific date."""

    date: datetime.date = Field(..., title="Date", description="The date when this value becomes effective.")
    value: float = Field(..., title="Value", description="The value that becomes effective on the associated date.")

    semantic_type: Literal["DATED_VALUE"] = "DATED_VALUE"


class DenominatedDatedValueModel(DatedValueModel):
    """A value associated with a specific date, denominated in a currency."""

    currency: CurrencyId | str | None = Field(default=None, title="Currency", description="The currency in which the value is denominated.")

    semantic_type: Literal["DENOMINATED_DATED_VALUE"] = "DENOMINATED_DATED_VALUE"  # type: ignore[assignment]
