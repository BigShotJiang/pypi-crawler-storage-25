# pyright: basic

from float_sdk.float_api.serialization.model import DisplayEnum


class DocumentType(DisplayEnum):
    ATTACHMENT = "ATTACHMENT"
    CONFIRM = "CONFIRM"
    CONFIRM_TEMPLATE = "CONFIRM_TEMPLATE"
    RECAP = "RECAP"
    SIGNATURE = "SIGNATURE"
    VALUATION_FILE = "VALUATION_FILE"
    TRADE_FILE = "TRADE_FILE"
    PORTFOLIO_REFERENCE_DATA_FILE = "PORTFOLIO_REFERENCE_DATA_FILE"
    MARKET_DATA_FILE = "MARKET_DATA_FILE"
    MASTER_CONFIRMATION = "MASTER_CONFIRMATION"
    ISDA_DEFINITIONS = "ISDA_DEFINITIONS"
    NDA = "NDA"
    MASTER_AGREEMENT = "MASTER_AGREEMENT"

    def display_names(self) -> dict[str, str]:
        return {
            "ATTACHMENT": "Attachment",
            "CONFIRM": "Confirmation",
            "CONFIRM_TEMPLATE": "Confirmation Template",
            "RECAP": "Recap",
            "SIGNATURE": "Signature",
            "VALUATION_FILE": "Valuation File",
            "TRADE_FILE": "Trade File",
            "PORTFOLIO_REFERENCE_DATA_FILE": "Portfolio Reference Data File",
            "MARKET_DATA_FILE": "Market Data File",
            "MASTER_CONFIRMATION": "Master Confirmation",
            "ISDA_DEFINITIONS": "ISDA Definitions",
            "NDA": "Non-Disclosure Agreement",
            "MASTER_AGREEMENT": "Master Agreement",
        }
