#!/usr/bin/env python
# pyright: basic

"""
Risk Measures

This module defines risk measures for financial instruments.

"""

from typing import Literal

from float_sdk.float_api.base.measures.math import NumericFormatStyle, NumericMeasure

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class Delta(NumericMeasure):
    """
    Delta

    Represents the sensitivity of the price of a financial instrument to changes in the price of the underlying asset.

    """

    semantic_type: Literal["NUMBER_DELTA"] = "NUMBER_DELTA"
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL
    precision: int | None = 4


class Vega(NumericMeasure):
    """
    Vega

    Represents the sensitivity of the price of a financial instrument to changes in the volatility of the underlying asset.

    """

    semantic_type: Literal["NUMBER_VEGA"] = "NUMBER_VEGA"
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL
    precision: int | None = 4


class Theta(NumericMeasure):
    """
    Theta

    Represents the sensitivity of the price of a financial instrument to the passage of time, also known as time decay.

    """

    semantic_type: Literal["NUMBER_THETA"] = "NUMBER_THETA"
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL
    precision: int | None = 4


class Rho(NumericMeasure):
    """
    Rho

    Represents the sensitivity of the price of a financial instrument to changes in interest rates.

    """

    semantic_type: Literal["NUMBER_RHO"] = "NUMBER_RHO"
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL
    precision: int | None = 4


class Gamma(NumericMeasure):
    """
    Gamma

    Represents the sensitivity of the delta of a financial instrument to changes in the price of the underlying asset.

    """

    semantic_type: Literal["NUMBER_GAMMA"] = "NUMBER_GAMMA"
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL
    precision: int | None = 4
