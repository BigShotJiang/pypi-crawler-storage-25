#!/usr/bin/env python
# pyright: strict

"""
Measure Types

Base numerical types which are used to provide additional context to primitive
type declarations. For example, representing an interest rate as a float loses
relevant context about how the type can be used in arithmetic, precision, and
display formatting.

"""

from abc import ABC, abstractmethod
from typing import Any, Literal, Union, cast, get_args

from pydantic import Field, model_serializer

from float_sdk.float_api.api.messaging import FloatMessageContext, MessageDataType
from float_sdk.float_api.serialization.types import (
    SerializationMode,
    TypeModel,
    is_serializable,  # type: ignore[reportUnknownVariableType]
)

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2024, Float Technologies, Inc."
__email__ = "andy@float.tech"


class DataTypeModel(TypeModel, ABC):
    """
    Base Data Type
    Base class for all semantic types. Semantic types refer to categories or labels that are
    assigned to data elements based on their meaning or interpretation rather than their raw
    data type. These types provide additional context and understanding to the data, enabling
    better analysis, interpretation, and integration across different sources.
    """

    @property
    def message_type(self) -> MessageDataType:
        msg_context = FloatMessageContext.current
        ctx_type = msg_context.message_type if msg_context else None
        return ctx_type if ctx_type else MessageDataType.OBJECT

    @property
    def python_type(self) -> type:
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return type(self)
        else:
            types = get_args(self.__class__.model_fields["value"].annotation)
            return Union[types] if len(types) > 1 else types  # type: ignore[return-value]

    @abstractmethod
    def serialize(self) -> str | dict[str, Any] | None: ...

    @model_serializer
    def model_serialize(self) -> Any:
        return self.serialize() if is_serializable(self) else self  # type: ignore[arg-type]

    def parse(self, value: Any) -> Any:
        return value


class DimensionMeasureBase(DataTypeModel, ABC):
    value: Any | None = Field(default=None, description="The value of the dimension.")

    def __str__(self) -> str:
        return str(self.value) if self.value is not None else ""

    def parse(self, value: Any) -> Any:
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE] and type(value) is not type(self):
            return {"value": value}
        else:
            return value

    def serialize(self) -> str | dict[str, Any] | None:
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            return self.value


class DimensionBase(DimensionMeasureBase, ABC):
    pass


class MeasureBase(DimensionMeasureBase, ABC):
    pass


class ObjectDimension(DimensionBase):
    semantic_type: Literal["OBJECT"] = "OBJECT"
    value: dict[str, Any] | None = Field(default=None, description="The object/dictionary value.")

    def serialize(self) -> str | dict[str, Any] | None:
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            return self.value
