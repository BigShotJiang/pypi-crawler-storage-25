#!/usr/bin/env python
# pyright: basic

"""
Semantic Date Types

Base semantic types which are used to provide additional context to primative
type declarations. For example, representing an interest rate as a float loses
relevant context about how the type can be used in arithmetic, precision, and
display formatting.

"""

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


from datetime import date, datetime, time
from types import UnionType
from typing import Any, Dict, List, Literal, Optional, cast

from dateutil import parser
from pydantic import Field

from float_sdk.float_api.api.messaging import MessageDataType
from float_sdk.float_api.base.measures.base import DimensionBase
from float_sdk.float_api.datetime.schedule import RelativeDatePeriod
from float_sdk.float_api.datetime.tenor import TenorPeriod
from float_sdk.float_api.serialization.types import SerializationMode


class DateDimensionBase(DimensionBase):
    value: date | None = Field(default=None, description="The date value.")
    format: str | List[str] | None = Field(default=None, description="The date format.")
    null_values: List[str] | None = Field(default=None, description="The null values.")

    def parse_string(self, value: str) -> datetime | None:
        if value == "":
            return None

        if self.format:
            if self.null_values and value in self.null_values:
                return None

            format = self.format
            if not isinstance(format, list):
                format = [format]

            for idx, format_el in enumerate(format):
                try:
                    format_string = format_el.replace("YYYY", "%Y").replace("YY", "%y").replace("MM", "%m").replace("DD", "%d")
                    return datetime.strptime(value.strip(), format_string)
                except ValueError:
                    if idx == len(format) - 1:
                        raise ValueError(f"Invalid date format: {value}")
        else:
            try:
                return parser.parse(value, yearfirst=True, dayfirst=False)
            except ValueError as ex:
                raise ValueError(f"Invalid date format: {value}") from ex

        raise ValueError(f"Invalid date format: {value}")

    def serialize(self) -> str | Dict[str, Any] | str | None:
        out = super().serialize()

        if self.message_type == MessageDataType.STRING and out:
            out = self.value.strftime("%d%b%y").upper() if self.value else ""

        return out


class DateDimension(DateDimensionBase):
    """
    Date Type
    Default date type which will handle parsing common date formats and serialize to ISO 8601
    """

    value: date | None = Field(default=None, description="The date value.")
    semantic_type: Literal["DATE"] = "DATE"

    def parse(self, value: date | str) -> date | dict:
        if value is None or isinstance(value, date):
            parsed = value
        else:
            parsed = self.parse_string(value)
            parsed = parsed.date() if parsed else None

        return super().parse(parsed)


class CurrentDate(DateDimension):
    """
    Dynamically resolves to the current date
    """

    semantic_type: Literal["CURRENT_DATE"] = "CURRENT_DATE"  # type: ignore[assignment]


class TimeDimension(DateDimensionBase):
    """
    Time type
    Default time type which will handle parsing common time formats and serialize to ISO 8601
    """

    value: time | None = None
    semantic_type: Literal["TIME"] = "TIME"

    def parse(self, value: time | str) -> time | dict:
        if value is None or isinstance(value, time):
            parsed = value
        else:
            parsed = self.parse_string(value)

        return super().parse(parsed)


class DatetimeDimension(DateDimensionBase):
    """
    Datetime Type
    Default date type which will handle parsing common date formats and serialize to ISO 8601
    """

    value: datetime | None = Field(default=None, description="The datetime value.")
    semantic_type: Literal["DATETIME"] = "DATETIME"

    def parse(self, value: datetime | str) -> datetime | dict:
        if value is None or isinstance(value, datetime):
            parsed = value
        else:
            parsed = self.parse_string(value)

        return super().parse(parsed)


class DateListDimension(DateDimensionBase):
    semantic_type: Literal["DATE_LIST"] = "DATE_LIST"
    value: list[date] | None = Field(default=None, description="A list of date values.")

    @property
    def python_type(self) -> type | UnionType:  # type: ignore[override]
        return list[date] | None

    def serialize(self) -> list[str] | Dict[str, Any] | None:  # type: ignore[override]
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(Dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            if not self.value:
                return None
            return [d.isoformat() for d in self.value]

    def parse(self, value: Any) -> Any:
        if value is not None and not isinstance(value, list):
            if isinstance(value, str):
                value = [v.strip() for v in value.split(",")]
            else:
                value = [value]
        if value is not None:
            parsed = []
            for v in value:
                if isinstance(v, date):
                    parsed.append(v)
                elif isinstance(v, str):
                    p = self.parse_string(v)
                    parsed.append(p.date() if p else None)
                else:
                    parsed.append(v)
            value = [d for d in parsed if d is not None]
        return super().parse(value)


class RelativeDateDimension(DimensionBase):
    """
    Relative Date Type
    """

    period: Optional[RelativeDatePeriod] = Field(None, description="The relative date period.")
    multiplier: Optional[int] = Field(None, description="The relative date multiplier.")

    semantic_type: Literal["DATE_RELATIVE"] = "DATE_RELATIVE"

    def serialize(self) -> str | Dict[str, Any] | str | None:
        if self.message_type == MessageDataType.STRING:
            # out = f"{self.multiplier}{self.period.value}"
            pass
        else:
            return super().serialize()

    def parse(self, value: Any):
        if isinstance(value, RelativeDateDimension):
            return value
        elif hasattr(value, "period") and hasattr(value, "multiplier"):
            return RelativeDateDimension(period=value.period, multiplier=value.multiplier)


class TenorDimension(DimensionBase):
    """
    Tenor Date Type
    """

    tenor_period: Optional[TenorPeriod] = Field(None, description="The tenor period.")
    multiplier: Optional[int] = Field(None, description="The tenor multiplier.")

    semantic_type: Literal["DATE_TENOR"] = "DATE_TENOR"

    def serialize(self) -> str | Dict[str, Any] | str | None:
        if self.message_type == MessageDataType.STRING:
            # out = f"{self.multiplier}{self.tenor_period.value}"
            pass
        else:
            return super().serialize()

    def parse(self, value: Any):
        if isinstance(value, TenorDimension):
            return value
        elif hasattr(value, "tenor_period") and hasattr(value, "multiplier"):
            return TenorDimension(tenor_period=value.tenor_period, multiplier=value.multiplier)
