#!/usr/bin/env python
# pyright: strict

"""
Text Based Dimensions and Measures


"""

from enum import Enum
from types import UnionType
from typing import Any, Generic, List, Literal, TypeVar, cast

from pydantic import Field

from float_sdk.float_api.api.messaging import MessageDataType
from float_sdk.float_api.base.measures.base import DimensionBase
from float_sdk.float_api.serialization.model import DisplayEnum
from float_sdk.float_api.serialization.types import SerializationMode, TypeModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies Inc."
__email__ = "andy@float.tech"


class StringDimension(DimensionBase):
    semantic_type: Literal["STRING"] = "STRING"
    value: str | None = Field(default=None, description="The string value.")
    null_values: list[str] | None = None

    def parse(self, value: Any) -> Any:
        if self.null_values and value in self.null_values:
            return None
        return super().parse(value)


class StringListDimension(DimensionBase):
    semantic_type: Literal["STRING_LIST"] = "STRING_LIST"
    value: list[str] | None = Field(default=None, description="A list of string values.")

    @property
    def python_type(self) -> type | UnionType:  # type: ignore[override]
        return list[str] | None

    def serialize(self) -> list[str] | dict[str, Any] | None:  # type: ignore[override]
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            return self.value

    def parse(self, value: Any) -> Any:
        if value is not None and not isinstance(value, list):
            value = [value]
        return super().parse(value)


class LabelDimension(DimensionBase):
    """
    Label Dimension - for static read-only labels/titles in UI that have no value.
    Used for section headers and grouping elements.
    """

    semantic_type: Literal["LABEL"] = "LABEL"
    value: Literal[None] = Field(default=None, description="Labels have no value.")

    @property
    def python_type(self) -> type | UnionType:  # type: ignore[override]
        """Return Optional[str] for Pydantic schema generation compatibility"""
        return str | None

    def __str__(self) -> str:
        return ""

    def parse(self, value: Any) -> None:
        return None

    def serialize(self) -> dict[str, Any] | None:
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            return None


class EmailDimension(DimensionBase):
    semantic_type: Literal["EMAIL"] = "EMAIL"
    value: str | None = Field(default=None, description="The email address.")


ET = TypeVar("ET", bound=Enum)


class EnumOption(TypeModel):
    name: str | None = Field(default=None, description="The name of the enum option.")
    value: Any = Field(default=None, description="The value of the enum option.")


EnumOptions = List[EnumOption]


class EnumDimension(StringDimension, Generic[ET]):
    semantic_type: Literal["ENUM"] = "ENUM"  # type: ignore[assignment]
    data_model: str | None = None
    _enum_type: type[ET] | None = None  # have to store actual type for runtime mapping (i know)
    value: ET | str | None = None  # type: ignore[assignment]
    enum: EnumOptions | None = None
    null_values: list[str] | None = None

    @property
    def python_type(self) -> type | UnionType:  # type: ignore[override]
        # If we know the enum_type at runtime, return a proper union
        if self._enum_type:
            return self._enum_type | None  # type: ignore[return-value]
        else:
            # Fallback to base implementation
            return super().python_type

    def serialize(self) -> str | dict[str, Any] | None:
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            if not self.value or isinstance(self.value, str):
                return self.value
            else:
                return self.value.value if self.message_type == MessageDataType.STRING else super().serialize()

    def parse(self, value: Any) -> Any:
        if self.null_values and value in self.null_values:
            return None

        val = super().parse(value)

        if self.message_type == MessageDataType.TABLE:
            val["data_model"] = self.__class__.model_name(value)

        return val

    @classmethod
    def from_enum(cls, enum: type[ET], null_values: list[str] | None = None, display_only: bool = False) -> "EnumDimension[ET]":
        if issubclass(enum, DisplayEnum):
            options = [EnumOption(name=e.display_name(), value=e.value) for e in enum if not display_only or e.has_display_name()]
        else:
            options = [EnumOption(name=e.name, value=e.value) for e in enum]

        instance = cls(data_model=EnumDimension.python_name(enum.__name__).upper(), null_values=null_values, enum=options)
        instance._enum_type = enum
        return instance


class EnumListDimension(DimensionBase, Generic[ET]):
    semantic_type: Literal["ENUM_LIST"] = "ENUM_LIST"
    data_model: str | None = None
    _enum_type: type[ET] | None = None
    value: list[ET | str] | None = None
    enum: EnumOptions | None = None
    null_values: list[str] | None = None

    @property
    def python_type(self) -> type | UnionType:  # type: ignore[override]
        if self._enum_type:
            return list[self._enum_type] | self._enum_type | None  # type: ignore[return-value]
        else:
            return super().python_type

    def serialize(self) -> list[str] | dict[str, Any] | None:  # type: ignore[override]
        if self.message_type in [MessageDataType.OBJECT, MessageDataType.TABLE]:
            return cast(dict[str, Any], self.to_dict(SerializationMode.NATIVE))
        else:
            if not self.value:
                return None
            else:
                return [v.value if isinstance(v, Enum) else v for v in self.value]

    def parse(self, value: Any) -> Any:
        if self.null_values and value in self.null_values:
            return None

        if value is not None and not isinstance(value, list):
            value = [value]

        val = super().parse(value)

        if self.message_type == MessageDataType.TABLE:
            if isinstance(val, dict):
                val["data_model"] = self.__class__.model_name(cast(Any, value))

        return cast(Any, val)

    @classmethod
    def from_enum(cls, enum: type[ET], null_values: list[str] | None = None, display_only: bool = False) -> "EnumListDimension[ET]":
        if issubclass(enum, DisplayEnum):
            options = [EnumOption(name=e.display_name(), value=e.value) for e in enum if not display_only or e.has_display_name()]
        else:
            options = [EnumOption(name=e.name, value=e.value) for e in enum]

        instance = cls(data_model=EnumListDimension.python_name(enum.__name__).upper(), null_values=null_values, enum=options)
        instance._enum_type = enum
        return instance


class FloatId(StringDimension):
    data_model: str | None = Field(default=None, title="Data Model", description="Data model which the id references (resource semantic type)")
    semantic_type: Literal["FLOAT_ID"] = "FLOAT_ID"  # type: ignore[assignment]


class CurrentOrganizationId(StringDimension):
    """
    Dynamically resolves to the current organization id
    """

    semantic_type: Literal["CURRENT_ORGANIZATION_ID"] = "CURRENT_ORGANIZATION_ID"  # type: ignore[assignment]


class CurrentUserId(StringDimension):
    """
    Dynamically resolves to the current user id
    """

    semantic_type: Literal["CURRENT_USER_ID"] = "CURRENT_USER_ID"  # type: ignore[assignment]
