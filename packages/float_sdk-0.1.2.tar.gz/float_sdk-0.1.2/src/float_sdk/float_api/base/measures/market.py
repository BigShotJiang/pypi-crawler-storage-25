#!/usr/bin/env python
# pyright: strict

"""
Market Measures

Numeric measures related to market prices, notional values, volatility,
interest rates, spreads, and multipliers. These measures provide context
for financial instruments and their associated values, enabling better
analysis and understanding of market dynamics.

"""

from typing import Any, Literal

from float_sdk.float_api.api.messaging import MessageDataType
from float_sdk.float_api.base.measures.base import DataTypeModel
from float_sdk.float_api.base.measures.math import NumericFormatStyle, NumericMeasure, NumericRangeModel
from float_sdk.float_api.base.references import CurrencyId

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2024, Float Technologies, Inc."
__email__ = "andy@float.tech"


class Price(NumericMeasure):
    """
    Refers to the monetary value assigned to a financial instrument or asset,
    representing the amount at which it can be bought or sold in the market.
    This price is determined through trading in various financial market venues
    or by market makers directly to potential customers.

    For example, the price of a stock is generally implied by the last traded
    price on an exchange, and the price of an over the counter derivative is
    based on a model calibrated by market observable levels or quotations.

    Parameters
    ----------
    precision : int
        Default display or calculation precision of the price.
    """

    semantic_type: Literal["NUMBER_PRICE"] = "NUMBER_PRICE"  # type: ignore[assignment]
    precision: int | None = 2


class Notional(NumericMeasure):
    """
    Notional

    The nominal or face value of a derivative contract or financial product,
    representing the total value of the underlying asset on which the contract
    is based.  The notional value does not represent the actual amount of money
    exchanged but serves as a reference for calculating contractual obligations,
    such as interest payments or the final settlement amount.

    For example, in the case of an interest rate swap contract, the notional
    value is the reference amount used to compute cashflow payments based on the
    reference interest rate. The notional influences the magnitude of payments
    on the derivative, but is not normally exchanged at inception of the contracl.

    Parameters
    ----------
    precision : int
        Default display or calculation precision of the notional amount.
    """

    semantic_type: Literal["NUMBER_NOTIONAL"] = "NUMBER_NOTIONAL"  # type: ignore[assignment]
    precision: int | None = 2
    format: NumericFormatStyle | str | None = NumericFormatStyle.DECIMAL


class Quantity(NumericMeasure):
    """
    Quantity

    A unit holding of a given asset, representing the number of units held
    in a position or transaction. This is commonly used to express the number
    of shares, index units, contracts, or other countable financial instruments.

    For example, the quantity of shares in an equity position, the number of
    index units in an equity swap, or the number of contracts in a futures trade.

    Parameters
    ----------
    precision : int
        Default display or calculation precision of the quantity.
    """

    semantic_type: Literal["NUMBER_QUANTITY"] = "NUMBER_QUANTITY"  # type: ignore[assignment]
    precision: int | None = 2
    format: NumericFormatStyle | str | None = NumericFormatStyle.DECIMAL


class MarketValue(NumericMeasure):
    """
    Market Value

    The current value of a financial instrument or asset in the market, which is
    determined in terms of the theoretical and counterparty agnostic value of the
    instrument or position.


    Parameters
    ----------
    precision : int
        Default display or calculation precision of the market value.
    """

    semantic_type: Literal["NUMBER_MARKET_VALUE"] = "NUMBER_MARKET_VALUE"  # type: ignore[assignment]
    precision: int | None = 2


class Volatility(NumericMeasure):
    format: NumericFormatStyle | str | None = NumericFormatStyle.PERCENT
    semantic_type: Literal["NUMBER_VOLATILITY"] = "NUMBER_VOLATILITY"  # type: ignore[assignment]


class Variance(NumericMeasure):
    """
    Variance

    A measure of dispersion representing the square of volatility. Used in variance
    swaps and variance calculations. Variance is expressed as a percentage (e.g., 0.04
    displays as 4%, which corresponds to 20% volatility).

    Parameters
    ----------
    precision : int
        Default display or calculation precision of the variance measure.
    """

    format: NumericFormatStyle | str | None = NumericFormatStyle.PERCENT
    precision: int | None = 4
    semantic_type: Literal["NUMBER_VARIANCE"] = "NUMBER_VARIANCE"  # type: ignore[assignment]


class Correlation(NumericMeasure):
    """
    Correlation

    A measure of correlation between assets, ranging from -1 to 1. Used in correlation
    swaps. Displayed as percentage (e.g., 0.65 = 65% correlation).

    Parameters
    ----------
    precision : int
        Default display precision (default: 2 for percentages like 65.00%)
    range : NumericRangeModel | None
        Valid range from -1.0 to 1.0
    """

    format: NumericFormatStyle | str | None = NumericFormatStyle.PERCENT
    precision: int | None = 2
    range: NumericRangeModel | None = NumericRangeModel(min=-1.0, max=1.0)
    semantic_type: Literal["NUMBER_CORRELATION"] = "NUMBER_CORRELATION"  # type: ignore[assignment]


class SpotRate(NumericMeasure):
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL  # type: ignore[assignment]
    precision: int | None = 7

    semantic_type: Literal["NUMBER_SPOT_RATE"] = "NUMBER_SPOT_RATE"  # type: ignore[assignment]


class InterestRate(NumericMeasure):
    semantic_type: Literal["NUMBER_INTEREST_RATE"] = "NUMBER_INTEREST_RATE"  # type: ignore[assignment]
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL  # type: ignore[assignment]
    precision: int | None = 7

    @property
    def format_str(self) -> str:
        if self.precision and not self.format:
            return "{:0." + str(self.precision - 2) + "%}"
        else:
            return super().format_str


class Spread(NumericMeasure):
    """
    Spread

    The difference between two interest rates, yields, or prices, often used to
    measure the relative value of financial instruments. It can refer to the
    difference between the bid and ask price of a security, the yield spread
    between two bonds, or the difference in interest rates between two loans.

    Parameters
    ----------
    precision : int
        Default display or calculation precision of the spread.
    """

    semantic_type: Literal["NUMBER_SPREAD"] = "NUMBER_SPREAD"  # type: ignore[assignment]
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL  # type: ignore[assignment]
    precision: int | None = 7


class InterestRateSpread(Spread):
    semantic_type: Literal["NUMBER_INTEREST_RATE_SPREAD"] = "NUMBER_INTEREST_RATE_SPREAD"  # type: ignore[assignment]
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL  # type: ignore[assignment]
    precision: int | None = 7


class NotionalQuantityModel(DataTypeModel):
    semantic_type: Literal["NUMBER_NOTIONAL_QUANTITY"] = "NUMBER_NOTIONAL_QUANTITY"

    currency: CurrencyId | str | None = None
    notional: Notional | None = None

    def serialize(self) -> str | dict[str, Any] | float | None:  # type: ignore[override]
        notional = self.notional.serialize() if self.notional else None
        if self.message_type == MessageDataType.STRING:
            currency_code = self.currency.serialize() if isinstance(self.currency, CurrencyId) else self.currency
            return f"{currency_code} {notional}"
        elif self.message_type == MessageDataType.NUMBER:
            return notional
        else:
            return {
                "notional": notional,
                "currency": self.currency.serialize() if isinstance(self.currency, CurrencyId) else self.notional,
                "semanticType": self.semantic_type,
            }
