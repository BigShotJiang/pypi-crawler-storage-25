#!/usr/bin/env python
# pyright: basic

"""
Semantic Types

Base semantic types which are used to provide additional context to primitive
type declarations. For example, representing an interest rate as a float loses
relevant context about how the type can be used in arithmetic, precision, and
display formatting.

"""

from abc import ABC, abstractmethod
from functools import total_ordering
from types import UnionType
from typing import TYPE_CHECKING, Any, Dict, Literal, Type

from pydantic import Field

from float_sdk.float_api.api.messaging import MessageDataType
from float_sdk.float_api.base.measures.base import DataTypeModel
from float_sdk.float_api.serialization.types import SerializationMode

if TYPE_CHECKING:
    from float_sdk.float_api.base.measures.text import FloatId

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


"""
Basic Types

Adapt data to basic python types.


Notes on serialization: 
https://blog.devgenius.io/deserialize-child-classes-with-pydantic-that-gonna-work-784230e1cf83
https://typethepipe.com/post/pydantic-discriminated-union/

"""


## Any class which implements resource_id


class ReferencedObject(ABC):
    @property
    @abstractmethod
    def resource_id(self) -> "ResourceId": ...


@total_ordering
class ResourceId(DataTypeModel):
    id: str | None = Field(default=None, description="The id of the resource.")
    name: str | None = Field(default=None, description="The name of the resource.")
    version: str | None = Field(default=None, description="The version of the resource.")

    semantic_type: Literal["RESOURCE_ID"] = "RESOURCE_ID"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, self.__class__) and hasattr(other, "id") and self.id == other.id

    def __lt__(self, other: object):
        if not isinstance(other, self.__class__):
            raise TypeError(f"Cannot compare {self.__class__.__name__} with {other.__class__.__name__}")
        return self.id < other.id if self.id and other.id else False

    def __repr__(self):
        return f"{self.__class__.__name__}={self.id}>"

    def __hash__(self):
        return hash(f"{self.id}:{self.version}")

    @property
    def data_model(self) -> str:
        data_model = self.model_name()
        return data_model[: -len("_ID")] if data_model.endswith("_ID") else data_model

    @property
    def python_type(self) -> type | UnionType:
        if self.message_type == MessageDataType.TABLE:
            return super().python_type
        else:
            return Type[str] | None

    @property
    def float_id(self) -> "FloatId":
        from float_sdk.float_api.base.measures.text import FloatId

        return FloatId(value=self.id, data_model=self.semantic_type)

    def parse(self, value: Any) -> Any:
        if type(value) is dict:
            return ResourceId(id=value["id"], name=value["name"], version=value.get("version", None))
        elif isinstance(value, ResourceId):
            return value
        elif isinstance(value, ReferencedObject):
            return value.resource_id
        else:
            return value

    def serialize(self) -> str | Dict[str, Any] | None:
        if self.message_type == MessageDataType.TABLE:
            dict = self.to_dict(SerializationMode.NATIVE)
            dict["dataModel"] = self.data_model
            return dict
        elif self.message_type == MessageDataType.NONE:
            return self.to_dict(SerializationMode.NATIVE)
        else:
            return self.id
