#!/usr/bin/env python
# pyright: strict

"""
Mathematical Measures

This module defines mathematical measures.

"""

import locale
import math
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Any, Literal

from float_sdk.float_api.api.messaging import MessageDataType
from float_sdk.float_api.base.math import RoundingDirection
from float_sdk.float_api.base.measures.base import DimensionBase, MeasureBase
from float_sdk.float_api.base.units import ValidUnit
from float_sdk.float_api.serialization.model import DataModel

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2025, Float Technologies, Inc."
__email__ = "andy@float.tech"


class NumericRangeModel(DataModel):
    semantic_type: Literal["NUMERIC_RANGE"] = "NUMERIC_RANGE"
    min: float | None = None
    max: float | None = None


class NumericFormatStyle(Enum):
    """
    Formatting styles for numeric values

    DECIMAL: 1234.56 -> 1,234.56
    INTEGER: 1234.56 -> 1,234
    PERCENT: 0.5623 -> 56.23%

    """

    DECIMAL = "DECIMAL"  # 1234.56 -> 1,234.56
    INTEGER = "INTEGER"  # 1234.56 -> 1,234
    AGE = "AGE"  # 1234.56 -> 1234.56 days
    DURATION = "DURATION"  # 1234.56 -> 1234.56 days
    PERCENT = "PERCENT"  # 0.5623 -> 56.23%
    SCIENTIFIC = "SCIENTIFIC"  # 1234.56 -> 1.23456e+03


class NumericMeasure(MeasureBase):
    semantic_type: Literal["NUMBER"] = "NUMBER"
    value: float | None = None

    ## Formatting options
    #
    precision: int | None = None
    rounding_direction: RoundingDirection | None = None
    format: NumericFormatStyle | str | None = None  # TODO: Remove string after migrating dataset
    unit: ValidUnit | None = None

    ## Validation constraints
    #
    range: NumericRangeModel | None = None

    def __float__(self) -> float:
        return float(self.value) if self.value else float("nan")

    def __str__(self) -> str:
        val = self.treated_value

        if val is None:
            return ""

        if self.format == NumericFormatStyle.PERCENT:
            val = val * 100

        if self.format_str:
            return self.format_str.format(val)
        else:
            return str(val)

    @property
    def treated_value(self) -> float | None:
        val = self.value

        if val is None:
            return None

        rounding = self.rounding_direction if self.rounding_direction else RoundingDirection.NEAREST

        if self.precision:
            if rounding == RoundingDirection.NEAREST:
                val = round(val, self.precision)
            elif rounding == RoundingDirection.UP:
                if self.precision == 0:
                    val = math.ceil(val)
                elif self.precision > 0:
                    factor = 10**self.precision
                    val = math.ceil(factor * val) / factor
                else:
                    raise Exception(f"Invalid rounding precision: {self.precision}")
            else:
                if self.precision == 0:
                    val = math.floor(val)
                elif self.precision > 0:
                    factor = 10**self.precision
                    val = math.floor(factor * val) / factor
                else:
                    raise Exception(f"Invalid rounding precision: {self.precision}")

        return val

    @property
    def format_str(self) -> str:
        precision = self.precision or 12  # Roughly the python default

        if self.format:
            if self.format == NumericFormatStyle.DECIMAL:
                return f"{{:,.{precision}f}}"
            elif self.format == NumericFormatStyle.INTEGER:
                return "{:,}"
            elif self.format == NumericFormatStyle.PERCENT:
                return f"{{:,.{precision}f}}%"
            elif self.format == NumericFormatStyle.SCIENTIFIC:
                return f"{{:,.{precision}e}}"
            elif self.format == NumericFormatStyle.AGE:
                return "{:,.2d}"
            elif self.format == NumericFormatStyle.DURATION:
                return "{:,.2d}"

        return f"{{:,.{precision}g}}"

    def parse(self, value: float | str) -> "float | NumericMeasure | None":
        if isinstance(value, type(self)):
            return value
        elif isinstance(value, float):
            parsed = value
        elif isinstance(value, str):
            mul = 1
            value = value.replace(",", "")
            if "%" in value:
                value = value.replace("%", "")
                mul = 0.01
            locale.setlocale(locale.LC_NUMERIC, "en_US.UTF-8")
            try:
                parsed = float(Decimal(value) * Decimal(str(mul)))
            except (ValueError, TypeError, InvalidOperation):
                parsed = None
        else:
            parsed = value

        return super().parse(parsed)

    def serialize(self) -> str | dict[str, Any] | float | None:  # type: ignore[override]
        if self.message_type == MessageDataType.STRING:
            return str(self)
        elif self.message_type == MessageDataType.NUMBER:
            return self.value
        else:
            return {
                "semanticType": self.semantic_type,
                "value": self.value,
                "treatedValue": self.treated_value,
                "precision": self.precision,
                "rounding": self.rounding_direction,
                "format": self.format,
                "range": {"min": self.range.min, "max": self.range.max} if self.range else None,
            }


class IntegerMeasure(NumericMeasure):
    semantic_type: Literal["INTEGER", "NUMBER_INTEGER"] = "NUMBER_INTEGER"  # type: ignore[assignment]
    format: NumericFormatStyle = NumericFormatStyle.INTEGER  # type: ignore[assignment]
    value: int | None = None  # type: ignore[assignment]


class Probability(NumericMeasure):
    """
    Probability

    Probability of an occurance, between 0 and 1

    """

    semantic_type: Literal["NUMBER_PROBABILITY"] = "NUMBER_PROBABILITY"  # type: ignore[assignment]
    format: NumericFormatStyle | None = NumericFormatStyle.PERCENT  # type: ignore[assignment]
    precision: int | None = 4


class NumericMultiplier(NumericMeasure):
    semantic_type: Literal["NUMBER_MULTIPLIER"] = "NUMBER_MULTIPLIER"  # type: ignore[assignment]
    format: NumericFormatStyle | None = NumericFormatStyle.DECIMAL  # type: ignore[assignment]
    precision: int | None = 5

    def serialize(self) -> str | dict[str, Any] | float | None:  # type: ignore[override]
        out = super().serialize()

        if self.message_type == MessageDataType.STRING:
            out = f"{out}x"

        return out


class BooleanDimension(DimensionBase):
    semantic_type: Literal["BOOLEAN"] = "BOOLEAN"
    value: bool | None = None

    def __str__(self) -> str:
        if self.value is None:
            return ""
        else:
            return "true" if self.value else "false"

    def parse(self, value: float | str | bool) -> bool | None:
        if isinstance(value, bool):
            parsed = value
        elif isinstance(value, str):
            if value.lower() == "true":
                parsed = True
            elif value.lower() == "false":
                parsed = False
            elif value.lower() == "yes":
                parsed = True
            elif value.lower() == "no":
                parsed = False
            elif value == "1":
                parsed = True
            elif value == "0":
                parsed = False
            elif value.strip().upper() in ["", "NULL"]:
                parsed = None
            else:
                raise ValueError(f"Invalid boolean value: {value}")
        else:
            parsed = value

        return super().parse(parsed)

    def serialize(self) -> str | dict[str, Any] | bool | int | None:  # type: ignore[override]
        if self.message_type == MessageDataType.STRING:
            return str(self)
        elif self.message_type == MessageDataType.NUMBER:
            return 1 if self.value else 0
        else:
            return {
                "semanticType": self.semantic_type,
                "value": self.value,
            }
