# pyright: basic
#!/usr/bin/env python

"""
Units

Units of measure for quantities

https://ucum.org/ucum
UCUM: Unified Code for Units of Measure
"""

from enum import Enum

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2024, Float Technologies, Inc."
__email__ = "andy@float.tech"


class TimeUnit(Enum):
    """Time units following UCUM standard"""

    SECONDS = "SECONDS"
    MINUTES = "MINUTES"
    HOURS = "HOURS"
    DAYS = "DAYS"
    WEEKS = "WEEKS"
    MONTHS = "MONTHS"
    YEARS = "YEARS"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            TimeUnit.SECONDS: "s",
            TimeUnit.MINUTES: "min",
            TimeUnit.HOURS: "h",
            TimeUnit.DAYS: "d",
            TimeUnit.WEEKS: "wk",
            TimeUnit.MONTHS: "mo",
            TimeUnit.YEARS: "a",
        }
        return _ucum_map[self]


class VolumeUnit(Enum):
    """Volume units following UCUM standard"""

    # Metric
    LITER = "LITER"
    MILLILITER = "MILLILITER"
    CUBIC_METER = "CUBIC_METER"

    # US Customary
    BARREL_US = "BARREL_US"
    GALLON_US = "GALLON_US"
    FLUID_OUNCE_US = "FLUID_OUNCE_US"
    BUSHEL_US = "BUSHEL_US"

    # British Imperial
    GALLON_BR = "GALLON_BR"
    FLUID_OUNCE_BR = "FLUID_OUNCE_BR"
    BUSHEL_BR = "BUSHEL_BR"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            VolumeUnit.LITER: "L",
            VolumeUnit.MILLILITER: "mL",
            VolumeUnit.CUBIC_METER: "m3",
            VolumeUnit.BARREL_US: "[bbl_us]",
            VolumeUnit.GALLON_US: "[gal_us]",
            VolumeUnit.FLUID_OUNCE_US: "[foz_us]",
            VolumeUnit.BUSHEL_US: "[bu_us]",
            VolumeUnit.GALLON_BR: "[gal_br]",
            VolumeUnit.FLUID_OUNCE_BR: "[foz_br]",
            VolumeUnit.BUSHEL_BR: "[bu_br]",
        }
        return _ucum_map[self]


class MassUnit(Enum):
    """Mass/Weight units following UCUM standard"""

    # Metric
    GRAM = "GRAM"
    KILOGRAM = "KILOGRAM"
    TONNE = "TONNE"

    # US/British Customary (Avoirdupois)
    OUNCE = "OUNCE"
    POUND = "POUND"
    SHORT_TON = "SHORT_TON"
    LONG_TON = "LONG_TON"

    # Troy (precious metals)
    TROY_OUNCE = "TROY_OUNCE"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            MassUnit.GRAM: "g",
            MassUnit.KILOGRAM: "kg",
            MassUnit.TONNE: "t",
            MassUnit.OUNCE: "[oz_av]",
            MassUnit.POUND: "[lb_av]",
            MassUnit.SHORT_TON: "[ston_av]",
            MassUnit.LONG_TON: "[lton_av]",
            MassUnit.TROY_OUNCE: "[oz_tr]",
        }
        return _ucum_map[self]


class LengthUnit(Enum):
    """Length/Distance units following UCUM standard"""

    # Metric
    METER = "METER"
    CENTIMETER = "CENTIMETER"
    MILLIMETER = "MILLIMETER"
    KILOMETER = "KILOMETER"

    # US/British Customary (International)
    INCH = "INCH"
    FOOT = "FOOT"
    YARD = "YARD"
    MILE = "MILE"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            LengthUnit.METER: "m",
            LengthUnit.CENTIMETER: "cm",
            LengthUnit.MILLIMETER: "mm",
            LengthUnit.KILOMETER: "km",
            LengthUnit.INCH: "[in_i]",
            LengthUnit.FOOT: "[ft_i]",
            LengthUnit.YARD: "[yd_i]",
            LengthUnit.MILE: "[mi_i]",
        }
        return _ucum_map[self]


class AreaUnit(Enum):
    """Area units following UCUM standard"""

    # Metric
    SQUARE_METER = "SQUARE_METER"
    HECTARE = "HECTARE"

    # US Customary
    ACRE = "ACRE"
    SQUARE_FOOT = "SQUARE_FOOT"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            AreaUnit.SQUARE_METER: "m2",
            AreaUnit.HECTARE: "har",
            AreaUnit.ACRE: "[acr_us]",
            AreaUnit.SQUARE_FOOT: "[sft_i]",
        }
        return _ucum_map[self]


class EnergyUnit(Enum):
    """Energy units following UCUM standard"""

    # Standard
    JOULE = "JOULE"
    MEGAJOULE = "MEGAJOULE"

    # Thermal
    BTU = "BTU"
    THERM_US = "THERM_US"
    MILLION_BTU = "MILLION_BTU"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            EnergyUnit.JOULE: "J",
            EnergyUnit.MEGAJOULE: "MJ",
            EnergyUnit.BTU: "[Btu]",
            EnergyUnit.THERM_US: "[thm_us]",
            EnergyUnit.MILLION_BTU: "MMBtu",
        }
        return _ucum_map[self]


class CountUnit(Enum):
    """Count/Quantity units"""

    UNIT = "UNIT"
    CONTRACT = "CONTRACT"
    SHARE = "SHARE"
    LOT = "LOT"

    def ucum_code(self) -> str:
        """Get the UCUM code for this unit"""
        _ucum_map = {
            CountUnit.UNIT: "unit",
            CountUnit.CONTRACT: "contract",
            CountUnit.SHARE: "share",
            CountUnit.LOT: "lot",
        }
        return _ucum_map[self]


ValidUnit = TimeUnit | VolumeUnit | MassUnit | LengthUnit | AreaUnit | EnergyUnit | CountUnit
