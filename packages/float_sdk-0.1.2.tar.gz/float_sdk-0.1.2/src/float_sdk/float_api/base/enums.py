# pyright: basic
"""
Shared Enums

Base enums that are used across multiple modules.
"""

from enum import Enum

from inflection import titleize


class DisplayEnum(Enum):
    def display_names(self) -> dict[str, str]:
        return {}

    def has_display_name(self) -> bool:
        return self.value in self.display_names()

    def display_name(self) -> str:
        return self.display_names().get(self.name, self.name if self.name.isupper() and "_" not in self.name else titleize(self.name))


class MessageFormat(Enum):
    TEXT = "TEXT"
    MARKDOWN = "MARKDOWN"
    HTML = "HTML"
