# pyright: basic
from enum import Enum
from typing import Literal, Optional

from float_sdk.float_api.base.measures.base import DimensionBase


class MarkupFormatter(Enum):
    HTML = "HTML"
    MARKDOWN = "MARKDOWN"
    TEXT = "TEXT"


class MarkupDimension(DimensionBase):
    formatter: MarkupFormatter | None = None
    value: Optional[str] = None

    semantic_type: Literal["MARKUP"] = "MARKUP"
