#!/usr/bin/env python
# pyright: basic

"""
Resource Identifiers

These are semantic identifier types which refer to resources
accessible through the Float API. These identifiers can be
used to access linked resources at runtime.

"""

from typing import Annotated, Literal, Union

from pydantic import Field

from float_sdk.float_api.base.measures.primitive import ResourceId
from float_sdk.float_api.base.measures.text import FloatId

__author__ = "Andy Phillips"
__copyright__ = "Copyright 2023, Float Technologies, Inc."
__email__ = "andy@float.tech"


## Identity and access management references


class ApplicationId(ResourceId):
    semantic_type: Literal["APPLICATION_ID"] = "APPLICATION_ID"


class UserId(ResourceId):
    semantic_type: Literal["USER_ID"] = "USER_ID"


class GroupId(ResourceId):
    semantic_type: Literal["GROUP_ID"] = "GROUP_ID"


class PolicyId(ResourceId):
    semantic_type: Literal["POLICY_ID"] = "POLICY_ID"


class DocumentId(ResourceId):
    semantic_type: Literal["DOCUMENT_ID"] = "DOCUMENT_ID"


class DocumentLinkId(ResourceId):
    semantic_type: Literal["DOCUMENT_LINK_ID"] = "DOCUMENT_LINK_ID"


class CredentialsId(ResourceId):
    semantic_type: Literal["CREDENTIALS_ID"] = "CREDENTIALS_ID"


## Organization Data Model References


class OrganizationId(ResourceId):
    semantic_type: Literal["ORGANIZATION_ID"] = "ORGANIZATION_ID"


class ContactId(ResourceId):
    semantic_type: Literal["CONTACT_ID"] = "CONTACT_ID"


class BusinessId(ResourceId):
    semantic_type: Literal["BUSINESS_ID"] = "BUSINESS_ID"


class PersonId(ResourceId):
    semantic_type: Literal["PERSON_ID"] = "PERSON_ID"


class EntityId(ResourceId):
    semantic_type: Literal["ENTITY_ID"] = "ENTITY_ID"


class AccountId(ResourceId):
    semantic_type: Literal["ACCOUNT_ID"] = "ACCOUNT_ID"


class GroupMembershipId(ResourceId):
    semantic_type: Literal["GROUP_MEMBERSHIP_ID"] = "GROUP_MEMBERSHIP_ID"


class CounterpartyRelationshipId(ResourceId):
    semantic_type: Literal["COUNTERPARTY_RELATIONSHIP_ID"] = "COUNTERPARTY_RELATIONSHIP_ID"


## Reference Data Model References


class LocationId(ResourceId):
    semantic_type: Literal["LOCATION_ID"] = "LOCATION_ID"


class CountryId(ResourceId):
    semantic_type: Literal["COUNTRY_ID"] = "COUNTRY_ID"


class JurisdictionId(ResourceId):
    semantic_type: Literal["JURISDICTION_ID"] = "JURISDICTION_ID"


class ExchangeId(ResourceId):
    semantic_type: Literal["EXCHANGE_ID"] = "EXCHANGE_ID"


class HolidayCalendarId(ResourceId):
    semantic_type: Literal["CALENDAR_ID"] = "CALENDAR_ID"


## Asset and observable references
class EquityId(ResourceId):
    semantic_type: Literal["EQUITY_ID"] = "EQUITY_ID"


class FutureId(ResourceId):
    semantic_type: Literal["FUTURE_ID"] = "FUTURE_ID"


class FuturesMarketId(ResourceId):
    semantic_type: Literal["FUTURES_MARKET_ID"] = "FUTURES_MARKET_ID"


class IndexId(ResourceId):
    semantic_type: Literal["INDEX_ID"] = "INDEX_ID"


class CurrencyId(ResourceId):
    semantic_type: Literal["CURRENCY_ID"] = "CURRENCY_ID"


class ExchangeRateId(ResourceId):
    semantic_type: Literal["EXCHANGE_RATE_ID"] = "EXCHANGE_RATE_ID"


class CommodityId(ResourceId):
    semantic_type: Literal["COMMODITY_ID"] = "COMMODITY_ID"


class BondId(ResourceId):
    semantic_type: Literal["BOND_ID"] = "BOND_ID"


class FloatingRateOptionId(ResourceId):
    semantic_type: Literal["FLOATING_RATE_OPTION_ID"] = "FLOATING_RATE_OPTION_ID"


class RateOptionSpreadId(ResourceId):
    semantic_type: Literal["RATE_OPTION_ID"] = "RATE_OPTION_ID"


class FloatingRateIndexId(ResourceId):
    semantic_type: Literal["FLOATING_RATE_INDEX_ID"] = "FLOATING_RATE_INDEX_ID"


class InflationRateIndexId(ResourceId):
    semantic_type: Literal["INFLATION_RATE_INDEX_ID"] = "INFLATION_RATE_INDEX_ID"


class SettlementRateOptionId(ResourceId):
    semantic_type: Literal["SETTLEMENT_RATE_OPTION_ID"] = "SETTLEMENT_RATE_OPTION_ID"


class RateSourceId(ResourceId):
    semantic_type: Literal["FIXING_SOURCE_ID"] = "FIXING_SOURCE_ID"


class SyntheticRateSourceId(ResourceId):
    semantic_type: Literal["SYNTHETIC_RATE_SOURCE_ID"] = "SYNTHETIC_RATE_SOURCE_ID"


class AssetMarketDefaultsId(ResourceId):
    semantic_type: Literal["ASSET_MARKET_DEFAULTS_ID"] = "ASSET_MARKET_DEFAULTS_ID"


## Market Data Model References


class DataProductId(ResourceId):
    semantic_type: Literal["DATA_PRODUCT_ID"] = "DATA_PRODUCT_ID"


class DataCategoryId(ResourceId):
    semantic_type: Literal["DATA_CATEGORY_ID"] = "DATA_CATEGORY_ID"


class DatasetId(ResourceId):
    semantic_type: Literal["DATASET_ID"] = "DATASET_ID"


class DataConnectionId(ResourceId):
    semantic_type: Literal["DATABASE_CONNECTION_ID"] = "DATABASE_CONNECTION_ID"


class DataViewId(ResourceId):
    semantic_type: Literal["DATA_VIEW_ID"] = "DATA_VIEW_ID"


class DataWorkspaceId(ResourceId):
    semantic_type: Literal["DATA_WORKSPACE_ID"] = "DATA_WORKSPACE_ID"


class DataFieldId(ResourceId):
    semantic_type: Literal["DATA_FIELD_ID"] = "DATA_FIELD_ID"


## Analytics Models


class AnalyticsProviderId(ResourceId):
    semantic_type: Literal["ANALYTICS_PROVIDER_ID"] = "ANALYTICS_PROVIDER_ID"


class WorkflowId(ResourceId):
    semantic_type: Literal["WORKFLOW_ID"] = "WORKFLOW_ID"


class WorkflowTaskId(ResourceId):
    semantic_type: Literal["WORKFLOW_TASK_ID"] = "WORKFLOW_TASK_ID"


class WorkflowActionId(ResourceId):
    semantic_type: Literal["WORKFLOW_ACTION_ID"] = "WORKFLOW_ACTION_ID"


class WorkflowDefinitionId(ResourceId):
    semantic_type: Literal["WORKFLOW_DEFINITION_ID"] = "WORKFLOW_DEFINITION_ID"


## Trading Data Model References


class OrderId(ResourceId):
    semantic_type: Literal["ORDER_ID"] = "ORDER_ID"


class TransactionId(ResourceId):
    semantic_type: Literal["TRANSACTION_ID"] = "TRANSACTION_ID"


class TradingAccountId(ResourceId):
    semantic_type: Literal["TRADING_ACCOUNT_ID"] = "TRADING_ACCOUNT_ID"


class PortfolioId(ResourceId):
    semantic_type: Literal["PORTFOLIO_ID"] = "PORTFOLIO_ID"


class StrategyId(ResourceId):
    semantic_type: Literal["STRATEGY_ID"] = "STRATEGY_ID"


class TradeId(ResourceId):
    semantic_type: Literal["TRADE_ID"] = "TRADE_ID"


class TradeMatchId(ResourceId):
    semantic_type: Literal["TRADE_MATCH_ID"] = "TRADE_MATCH_ID"


class TradeTemplateId(ResourceId):
    semantic_type: Literal["TRADE_TEMPLATE_ID"] = "TRADE_TEMPLATE_ID"


class DealId(ResourceId):
    semantic_type: Literal["DEAL_ID"] = "DEAL_ID"


class ProductId(ResourceId):
    model: str | None = None
    semantic_type: Literal["PRODUCT_ID"] = "PRODUCT_ID"

    @property
    def data_model(self) -> str:
        return self.model if self.model else super().data_model


class StructureId(ResourceId):
    semantic_type: Literal["STRUCTURE_ID"] = "STRUCTURE_ID"


class ValuationId(ResourceId):
    semantic_type: Literal["VALUATION_ID"] = "VALUATION_ID"


class FIXMessageId(ResourceId):
    semantic_type: Literal["FIX_MESSAGE_ID"] = "FIX_MESSAGE_ID"


class FIXLogId(ResourceId):
    semantic_type: Literal["FIX_LOG_ID"] = "FIX_LOG_ID"


## Collaboration Models


class ConversationId(ResourceId):
    """Identifier for a conversation (channel, DM, group chat, or AI chat)"""

    semantic_type: Literal["CONVERSATION_ID"] = "CONVERSATION_ID"


class ChatMessageId(ResourceId):
    """Identifier for a chat message in a conversation"""

    semantic_type: Literal["CHAT_MESSAGE_ID"] = "CHAT_MESSAGE_ID"


class ConversationEventId(ResourceId):
    """Identifier for a conversation event"""

    semantic_type: Literal["CONVERSATION_EVENT_ID"] = "CONVERSATION_EVENT_ID"


class CommentId(ResourceId):
    semantic_type: Literal["COMMENT_ID"] = "COMMENT_ID"


class NotificationId(ResourceId):
    semantic_type: Literal["NOTIFICATION_ID"] = "NOTIFICATION_ID"


class EmailMessageId(ResourceId):
    semantic_type: Literal["EMAIL_MESSAGE_ID"] = "EMAIL_MESSAGE_ID"


class EmailFolderId(ResourceId):
    semantic_type: Literal["EMAIL_FOLDER_ID"] = "EMAIL_FOLDER_ID"


class InitiativeId(ResourceId):
    semantic_type: Literal["INITIATIVE_ID"] = "INITIATIVE_ID"


class ProjectId(ResourceId):
    semantic_type: Literal["PROJECT_ID"] = "PROJECT_ID"


class IssueId(ResourceId):
    semantic_type: Literal["ISSUE_ID"] = "ISSUE_ID"


class LabelId(ResourceId):
    semantic_type: Literal["LABEL_ID"] = "LABEL_ID"


class OpportunityId(ResourceId):
    semantic_type: Literal["OPPORTUNITY_ID"] = "OPPORTUNITY_ID"


class OpportunityStatusId(ResourceId):
    semantic_type: Literal["OPPORTUNITY_STATUS_ID"] = "OPPORTUNITY_STATUS_ID"


class ReactionId(ResourceId):
    semantic_type: Literal["REACTION_ID"] = "REACTION_ID"


class PlatformId(ResourceId):
    semantic_type: Literal["PLATFORM_ID"] = "PLATFORM_ID"


class ApiLogEntryId(ResourceId):
    semantic_type: Literal["API_LOG_ENTRY_ID"] = "API_LOG_ENTRY_ID"


class SoftwareServiceId(ResourceId):
    semantic_type: Literal["SOFTWARE_SERVICE_ID"] = "SOFTWARE_SERVICE_ID"


ReferenceTypes = Annotated[
    Union[
        ## Core references
        ResourceId,
        FloatId,
        # Organizations
        OrganizationId,
        BusinessId,
        PersonId,
        GroupId,
        GroupMembershipId,
        EntityId,
        AccountId,
        ## Reference Data
        LocationId,
        CountryId,
        JurisdictionId,
        HolidayCalendarId,
        ## Asset and Observable
        CurrencyId,
        IndexId,
        BondId,
        FloatingRateOptionId,
        FloatingRateIndexId,
        RateOptionSpreadId,
        ## Enterprise Data
        DatasetId,
        DataCategoryId,
        DataProductId,
        DataConnectionId,
        DataViewId,
        DocumentId,
        ## Automation
        AnalyticsProviderId,
        WorkflowId,
        WorkflowTaskId,
        WorkflowActionId,
        WorkflowDefinitionId,
        ## Transactions
        OrderId,
        TransactionId,
        ProductId,
        ValuationId,
        TradeId,
        DealId,
        ## Collaboration
        CommentId,
        NotificationId,
        ConversationEventId,
        EmailMessageId,
        EmailFolderId,
        InitiativeId,
        ProjectId,
        IssueId,
        OpportunityId,
        ReactionId,
        ## Platforms
        PlatformId,
        ApiLogEntryId,
        ## Services
        SoftwareServiceId,
    ],
    Field(discriminator="semantic_type"),
]
