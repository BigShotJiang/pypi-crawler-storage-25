import inspect
from collections.abc import Callable, Mapping, Sequence
from typing import Any, TypeVar

from tiozin import config

T = TypeVar("T")


def get(obj: Mapping | Sequence | object, field: str | int) -> Any:
    """
    Get a field from a dict, list, or object.

    Args:
        obj: The dict, list, or object to get the field from. Must not be None.
        field: The field name (str) or index (int) to retrieve.

    Returns:
        The field value.

    Raises:
        ValueError: If obj is None.
        KeyError: If field not found or index out of range.

    Examples:
        >>> get({"name": "John"}, "name")
        "John"
        >>> get(["a", "b", "c"], 1)
        "b"
        >>> from types import SimpleNamespace
        >>> get(SimpleNamespace(age=30), "age")
        30
        >>> get({"name": "John"}, "age")
        KeyError: Field 'age' not found in dict
        >>> get(None, "field")
        ValueError: Cannot get field from None object
    """
    if obj is None:
        raise ValueError("Cannot get field from None object")

    try:
        if isinstance(obj, (Mapping, Sequence)):
            return obj[field]
        return getattr(obj, field)
    except (KeyError, IndexError, AttributeError) as e:
        raise KeyError(f"Field '{field}' not found in {type(obj).__name__}") from e


def try_get(obj: Mapping | Sequence | object, field: str | int, default: Any = None) -> Any:
    """
    Safely get a field from a dict, list, or object.

    Args:
        obj: The dict, list, or object to get the field from. Must not be None.
        field: The field name (str) or index (int) to retrieve.
        default: The value to return if the field is not found.

    Returns:
        The field value if found, otherwise the default value.

    Raises:
        ValueError: If obj is None.

    Examples:
        >>> try_get({"name": "John"}, "name")
        "John"
        >>> try_get({"name": "John"}, "age")
        None
        >>> try_get({"name": "John"}, "age", 0)
        0
        >>> try_get(["a", "b", "c"], 1)
        "b"
        >>> try_get(["a", "b"], 5, "default")
        "default"
        >>> from types import SimpleNamespace
        >>> try_get(SimpleNamespace(name="Jane"), "name")
        "Jane"
        >>> try_get(None, "field")
        ValueError: Cannot get field from None object
    """
    if obj is None:
        raise ValueError("Cannot get field from None object")

    try:
        if isinstance(obj, Mapping):
            return obj.get(field, default)
        if isinstance(obj, Sequence):
            return obj[field]
        return getattr(obj, field, default)
    except (IndexError, KeyError, AttributeError):
        return default


def set_field(obj: Mapping | Sequence | object, field: str | int, value: Any) -> None:
    """
    Set a field on a dict, list, or object.

    Args:
        obj: The dict, list, or object to set the field on. Must not be None.
        field: The field name (str) or index (int) to set.
        value: The value to set.

    Raises:
        ValueError: If obj is None.

    Examples:
        >>> obj = {"name": "John"}
        >>> set_field(obj, "age", 30)
        >>> obj
        {"name": "John", "age": 30}
        >>> obj = ["a", "b", "c"]
        >>> set_field(obj, 1, "x")
        >>> obj
        ["a", "x", "c"]
        >>> from types import SimpleNamespace
        >>> obj = SimpleNamespace(name="Jane")
        >>> set_field(obj, "age", 25)
        >>> obj.age
        25
        >>> set_field(None, "field", "value")
        ValueError: Cannot set field on None object
    """
    if obj is None:
        raise ValueError("Cannot set field on None object")

    if isinstance(obj, (Mapping, Sequence)):
        obj[field] = value
    else:
        setattr(obj, field, value)


def try_set_field(obj: Mapping | Sequence | object, field: str | int, value: Any) -> None:
    """
    Safely set a field on a dict, list, or object.

    Unlike set_field(), this function does not raise exceptions if the field
    cannot be set (e.g., on immutable objects), making it safe for
    optional updates.

    Args:
        obj: The dict, list, or object to set the field on. Must not be None.
        field: The field name (str) or index (int) to set.
        value: The value to set.

    Raises:
        ValueError: If obj is None.

    Examples:
        >>> obj = {"name": "John"}
        >>> try_set_field(obj, "age", 30)
        >>> obj
        {"name": "John", "age": 30}
        >>> obj = ["a", "b", "c"]
        >>> try_set_field(obj, 1, "x")
        >>> obj
        ["a", "x", "c"]
        >>> try_set_field(None, "field", "value")
        ValueError: Cannot set field on None object
        >>> from types import SimpleNamespace
        >>> obj = SimpleNamespace(name="Jane")
        >>> try_set_field(obj, "age", 25)
        >>> obj.age
        25
    """
    if obj is None:
        raise ValueError("Cannot set field on None object")

    try:
        if isinstance(obj, (Mapping, Sequence)):
            obj[field] = value
        else:
            setattr(obj, field, value)
    except Exception:
        pass


def try_get_public_setter(obj: Any, method_name: str) -> Callable | None:
    """
    Get a method if it's a valid public setter, otherwise return None.

    Public setters are callable methods that accept exactly one parameter
    (excluding self) and have names that don't start with underscore.

    Args:
        obj: The object to get the method from.
        method_name: The name of the method to retrieve.

    Returns:
        The method if it's a valid public setter, otherwise None.

    Examples:
        >>> class Person:
        ...     def set_name(self, name): self.name = name
        ...     def _set_age(self, age): self.age = age
        ...     def get_name(self): return self.name
        >>> person = Person()
        >>> try_get_public_setter(person, "set_name")
        <bound method Person.set_name...>
        >>> try_get_public_setter(person, "_set_age")
        None
        >>> try_get_public_setter(person, "get_name")
        None
    """
    if method_name.startswith("_"):
        return None

    method = getattr(obj, method_name, None)
    if not callable(method):
        return None

    sig = inspect.signature(method)
    if len(sig.parameters) != 1:
        return None

    return method


def is_package(obj: Any) -> bool:
    """
    Check if an object is a Python package.
    """
    return inspect.ismodule(obj) and hasattr(obj, "__path__")


def is_tiozin(clazz: Any) -> bool:
    """
    Check if an object is a valid and pluggable Tiozin class.
    """
    from tiozin.api import Tiozin

    return (
        inspect.isclass(clazz)
        and issubclass(clazz, Tiozin)
        and not inspect.isabstract(clazz)
        and clazz is not Tiozin
        and clazz is not clazz.tiozin_role_class
    )


def detect_tiozin_role(tiozin: type) -> type:
    """
    Detect the role of a Tiozin plugin class.

    The role is the first Tiozin subclass in the MRO that is not the Tiozin
    base class itself. It identifies what the plugin does in the pipeline:
    Input, Output, Transform, Runner, Job, or Registry.

    Args:
        tiozin: The Tiozin plugin class to inspect.

    Returns:
        The role class (e.g., Input, Output, Transform).

    Examples:
        >>> from tiozin.api.runtime import Input
        >>> class MyInput(Input): pass
        >>> detect_role(MyInput)
        <class 'tiozin.api.runtime.input.Input'>
    """
    from tiozin.api import Tiozin

    if not (inspect.isclass(tiozin) and issubclass(tiozin, Tiozin)):
        raise TypeError(f"Expected a Tiozin subclass, got {tiozin!r}")

    for clazz in reversed(tiozin.__mro__):
        if clazz is not Tiozin and issubclass(clazz, Tiozin):
            return clazz


def detect_family_name(tiozin: type) -> str:
    """
    Detect the family (Tio/Tia) of a Tiozin plugin class.

    Inspects the module path to find which provider family the plugin belongs
    to, based on configured prefixes (e.g., ``tio_``, ``tia_``).

    Args:
        tiozin: The Tiozin plugin class to inspect.

    Returns:
        The family name (e.g., ``"tio_spark"``, ``"tio_duckdb"``).
        Falls back to the configured unknown family name if no match is found.

    Examples:
        >>> detect_family(SparkFileInput)
        "tio_spark"
    """
    module_path: list[str] = tiozin.__module__.split(".")
    prefixes = tuple(config.tiozin_family_prefixes)

    for part in module_path:
        if part.startswith(prefixes):
            return part

    return config.tiozin_family_unknown
