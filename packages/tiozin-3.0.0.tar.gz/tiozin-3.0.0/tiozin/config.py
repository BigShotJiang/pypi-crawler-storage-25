import logging
from pathlib import Path
from tempfile import gettempdir
from zoneinfo import ZoneInfo

from single_source import get_version

from . import env

# ===============================================
#           General
# ===============================================
artifact_name = __package__
artifact_version = get_version(artifact_name, Path(__file__).parent.parent)

# ===============================================
#           API
# ===============================================
app_name = "tiozin"
app_title = "Tiozin"
app_version = artifact_version
app_identifier = f"{app_name}/{app_version}"
app_host = env.HOSTNAME
app_description = "Tiozin, your friendly ETL framework"
app_timezone = ZoneInfo("UTC")
app_temp_workdir = Path(gettempdir()) / app_name
app_temp_workdir.mkdir(parents=True, exist_ok=True)

# ===============================================
#           Logging
# ===============================================
log_level = env.LOG_LEVEL
log_level_name = logging._levelToName[log_level]
log_date_format = env.TIO_LOG_DATE_FORMAT
log_json = env.TIO_LOG_JSON
log_json_ensure_ascii = env.TIO_LOG_JSON_ENSURE_ASCII
log_show_locals = env.TIO_LOG_SHOW_LOCALS
log_redact_min_length = env.TIO_LOG_REDACT_MIN_LENGTH
# ===============================================
#           Tiozin Plugins
# ===============================================
tiozin_family_group = "tiozin.family"
tiozin_family_prefixes = ["tio_", "tia_"]
tiozin_family_unknown = "tio_unknown"

# ===============================================
#           Registry Defaults
# ===============================================
registry_default_timeout = 3
registry_default_readonly = False
registry_default_cache = False
registry_default_failfast = False

default_job_registry = "tio_kernel:FileJobRegistry"
default_setting_registry = "tio_kernel:FileSettingRegistry"
default_secret_registry = "tio_kernel:EnvSecretRegistry"

default_schema_registry = "tio_kernel:FileSchemaRegistry"
default_schema_show_schema = False
default_schema_default_version = "latest"
default_schema_subject_template = (
    "{{org}}.{{region}}.{{domain}}.{{subdomain}}.{{layer}}.{{product}}.{{model}}"
)

default_lineage_registry = "tio_kernel:NoOpLineageRegistry"
default_lineage_emit_level = "JOB"

default_transaction_registry = "tio_kernel:NoOpTransactionRegistry"
default_metric_registry = "tio_kernel:NoOpMetricRegistry"

# ===============================================
#           Tiozin Customizations
# ===============================================
tiozin_namespace_template = env.TIO_NAMESPACE_TEMPLATE
tiozin_settings_search_paths = (
    # Project-level
    "tiozin.yaml",
    # User-level
    Path.home() / "tiozin.yaml",
    Path.home() / ".config/tiozin" / "tiozin.yaml",
    # Container-level
    Path("/etc/tiozin") / "tiozin.yaml",
    Path("/tiozin") / "tiozin.yaml",
    Path("/config") / "tiozin.yaml",
    Path("/") / "tiozin.yaml",
)
