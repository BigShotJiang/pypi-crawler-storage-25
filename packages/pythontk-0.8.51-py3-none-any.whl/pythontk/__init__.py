# !/usr/bin/python
# coding=utf-8
from pythontk.core_utils.module_resolver import bootstrap_package

__package__ = "pythontk"
__version__ = "0.8.51"

"""Expose toolkit utilities with explicit resolver include maps for clarity."""


DEFAULT_INCLUDE = {
    "audio_utils._audio_utils": "AudioUtils",
    "img_utils._img_utils": "*",
    "img_utils.map_factory": ["MapFactory"],
    "img_utils.map_registry": "MapRegistry",
    "img_utils.map_compositor": ["MapCompositor", "BatchResult", "NormalOutputMode"],
    "img_utils.map_optimizer": ["MapOptimizer", "Op"],
    "str_utils._str_utils": "*",
    "vid_utils._vid_utils": "*",
    "vid_utils.frame_extractor": ["FrameExtractor", "extract_frames"],
    "file_utils._file_utils": "*",
    "file_utils.metadata": "Metadata",
    "file_utils.mesh_convert._mesh_convert": "MeshConvert",
    "iter_utils._iter_utils": "*",
    "math_utils._math_utils": "*",
    "math_utils.progression": "ProgressionCurves",
    "core_utils._core_utils": "*",
    "core_utils.help_mixin": "HelpMixin",
    "core_utils.package_manager": "PackageManager",
    "core_utils.git": "Git",
    "core_utils.class_property": "ClassProperty",
    "core_utils.logging_mixin": "LoggingMixin",
    "core_utils.table_mixin": "TableMixin",
    "core_utils.namespace_handler": "NamespaceHandler",
    "core_utils.namedtuple_container": "NamedTupleContainer",
    "core_utils.hierarchy_diff": "HierarchyDiff",
    "core_utils.singleton_mixin": "SingletonMixin",
    "core_utils.module_reloader": ["ModuleReloader", "reload_package"],
    "core_utils.execution_monitor._execution_monitor": "ExecutionMonitor",
    "core_utils.app_launcher": "AppLauncher",
    "core_utils.app_installer": "AppInstaller",
    "core_utils.cli": "CLI",
    # Hierarchy utils
    "core_utils.hierarchy_utils.hierarchy_indexer": "HierarchyIndexer",
    "core_utils.hierarchy_utils.hierarchy_matching": "HierarchyMatching",
    "core_utils.hierarchy_utils.hierarchy_analyzer": [
        "HierarchyDifference",
        "HierarchyAnalyzer",
    ],
    "net_utils.ssh_client": "SSHClient",
    "net_utils.credentials": "Credentials",
    "net_utils._net_utils": "NetUtils",
    "net_utils.rpc.client": "RpcClient",
    "net_utils.rpc.installer": [
        "install_plugin",
        "uninstall_plugin",
        "is_plugin_installed",
    ],
    "net_utils.rpc.job": ["Call", "Result", "run_batch"],
    "str_utils.fuzzy_matcher": "FuzzyMatcher",
    "color_utils._color_utils": ["Color", "ColorPair", "Palette"],
}


bootstrap_package(globals(), include=DEFAULT_INCLUDE)


__all__ = [
    "CoreUtils",
    "AppLauncher",
    "AppInstaller",
    "HelpMixin",
    "LoggingMixin",
    "TableMixin",
    "NamespaceHandler",
    "NamedTupleContainer",
    "SingletonMixin",
    "PackageManager",
    "ClassProperty",
    "HierarchyDiff",
    "ModuleReloader",
    "reload_package",
    "ExecutionMonitor",
    "CLI",
    "SSHClient",
    "Credentials",
    "NetUtils",
    "FileUtils",
    "Metadata",
    "MeshConvert",
    "ImgUtils",
    "MapCompositor",
    "BatchResult",
    "NormalOutputMode",
    "MapOptimizer",
    "FrameExtractor",
    "extract_frames",
    "IterUtils",
    "MathUtils",
    "ProgressionCurves",
    "StrUtils",
    "FuzzyMatcher",
    "AudioUtils",
    "VidUtils",
    "Color",
    "ColorPair",
    "Palette",
]
# Test: 222117
