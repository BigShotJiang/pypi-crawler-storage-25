from pathlib import Path
from importlib import metadata

# ANSI colors
ANSI_RESET = "\033[0m"
ANSI_ORANGE = "\033[38;5;208m"
ANSI_WHITE = "\033[97m"
ANSI_GREEN = "\033[92m"
ANSI_BLUE = "\033[94m"
ANSI_YELLOW = "\033[93m"
ANSI_RED = "\033[91m"
ANSI_DIM = "\033[90m"
ANSI_BOLD = "\033[1m"


def _getCliVersion() -> str:
    try:
        return metadata.version("digital-immortality")
    except metadata.PackageNotFoundError:
        return "unknown"


WELCOME_BANNER = (
    f"{ANSI_ORANGE}*{ANSI_RESET} "
    f"{ANSI_WHITE}{ANSI_BOLD}Welcome to IMMORTALITY CLI{ANSI_RESET}\n"
    f"{ANSI_ORANGE} {ANSI_RESET} "
    f"{ANSI_DIM}Version {_getCliVersion()}{ANSI_RESET}"
)

IMMORTALITY_LOGO = f"""{ANSI_ORANGE}{ANSI_BOLD}
██╗███╗   ███╗███╗   ███╗ ██████╗ ██████╗ ████████╗ █████╗ ██╗     ██╗████████╗██╗   ██╗
██║████╗ ████║████╗ ████║██╔═══██╗██╔══██╗╚══██╔══╝██╔══██╗██║     ██║╚══██╔══╝╚██╗ ██╔╝
██║██╔████╔██║██╔████╔██║██║   ██║██████╔╝   ██║   ███████║██║     ██║   ██║    ╚████╔╝
██║██║╚██╔╝██║██║╚██╔╝██║██║   ██║██╔══██╗   ██║   ██╔══██║██║     ██║   ██║     ╚██╔╝
██║██║ ╚═╝ ██║██║ ╚═╝ ██║╚██████╔╝██║  ██║   ██║   ██║  ██║███████╗██║   ██║      ██║
╚═╝╚═╝     ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝   ╚═╝      ╚═╝
{ANSI_RESET}"""

IMMORTALITY_HOME_DIR = Path.home() / ".immortality"
IMMORTALITY_ENV_PATH = IMMORTALITY_HOME_DIR / ".env"
