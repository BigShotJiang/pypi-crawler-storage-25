"""Configuration management module.

Handles loading, parsing, and validation of Boomarr configuration.
"""

import logging
import os
import sys
import zoneinfo
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar

import typer
import yaml
from pydantic import BaseModel, Field, ValidationError, field_validator

from boomarr.const import (
    APP_NAME,
    CONF_CONFIG_DIR,
    CONF_GENERAL_TZ,
    CONF_GENERAL_UMASK,
    CONF_LOGGING,
    CONF_LOGGING_DIR,
    CONF_LOGGING_FILE_NAME,
    CONF_LOGGING_LEVEL,
    DEFAULT_LOG_COLOR,
    DEFAULT_LOG_DATE_FORMAT,
    DEFAULT_LOG_DIR,
    DEFAULT_LOG_FILE_NAME,
    DEFAULT_LOG_FORMAT,
    DEFAULT_LOG_LEVEL,
    DEFAULT_LOG_ROTATION_BACKUP_COUNT,
    DEFAULT_LOG_ROTATION_ENABLED,
    DEFAULT_LOG_ROTATION_MAX_BYTES,
    DEFAULT_LOG_ROTATION_ROTATE_ON_START,
    DEFAULT_PGID,
    DEFAULT_PUID,
    DEFAULT_TZ,
    DEFAULT_UMASK,
    ENV_PREFIX_GENERAL,
    ENV_PREFIX_LOG_ROTATION,
    ENV_PREFIX_LOGGING,
    LogLevel,
)

_LOGGER = logging.getLogger(APP_NAME)


class GeneralConfig(BaseModel):
    """General sub-configuration for timezone, user/group IDs, and umask."""

    _env_prefix: ClassVar[str] = ENV_PREFIX_GENERAL

    tz: str = Field(default=DEFAULT_TZ, validate_default=True)
    puid: int = Field(default=DEFAULT_PUID, validate_default=True)
    pgid: int = Field(default=DEFAULT_PGID, validate_default=True)
    umask: str = Field(default=DEFAULT_UMASK, validate_default=True)

    @field_validator(CONF_GENERAL_TZ, mode="before")
    @classmethod
    def _coerce_tz(cls, v: object) -> object:
        """Treat empty/whitespace-only strings as None (falls back to default)."""
        if isinstance(v, str) and not v.strip():
            return DEFAULT_TZ
        return v

    @field_validator(CONF_GENERAL_TZ, mode="after")
    @classmethod
    def _validate_tz(cls, v: str) -> str:
        """Validate that the timezone is a known IANA timezone."""
        try:
            zoneinfo.ZoneInfo(v)
        except KeyError:
            raise ValueError(f"Invalid timezone: '{v}'")
        return v

    @field_validator(CONF_GENERAL_UMASK, mode="before")
    @classmethod
    def _coerce_umask(cls, v: object) -> object:
        """Convert integer umask values (from YAML) to zero-padded strings."""
        if isinstance(v, int):
            return f"{v:03d}"
        return v

    @field_validator(CONF_GENERAL_UMASK, mode="after")
    @classmethod
    def _validate_umask(cls, v: str) -> str:
        """Validate that the umask is a valid octal string in range 000-777."""
        try:
            val = int(v, 8)
        except ValueError:
            raise ValueError(
                f"Invalid umask '{v}': must be a valid octal string (e.g. '022')"
            )
        if val < 0 or val > 0o777:
            raise ValueError(f"Umask value '{v}' out of range (000-777)")
        return v


class LogRotationConfig(BaseModel):
    """Log file rotation sub-configuration."""

    _env_prefix: ClassVar[str] = ENV_PREFIX_LOG_ROTATION

    enabled: bool = Field(default=DEFAULT_LOG_ROTATION_ENABLED, validate_default=True)
    max_bytes: int = Field(
        default=DEFAULT_LOG_ROTATION_MAX_BYTES, validate_default=True
    )
    backup_count: int = Field(
        default=DEFAULT_LOG_ROTATION_BACKUP_COUNT, validate_default=True
    )
    rotate_on_start: bool = Field(
        default=DEFAULT_LOG_ROTATION_ROTATE_ON_START, validate_default=True
    )


class LoggingConfig(BaseModel):
    """Logging sub-configuration."""

    _env_prefix: ClassVar[str] = ENV_PREFIX_LOGGING
    _yaml_excluded: ClassVar[frozenset[str]] = frozenset({CONF_LOGGING_DIR})

    level: LogLevel = Field(default=DEFAULT_LOG_LEVEL, validate_default=True)
    format: str = Field(default=DEFAULT_LOG_FORMAT, validate_default=True)
    date_format: str = Field(default=DEFAULT_LOG_DATE_FORMAT, validate_default=True)
    dir: Path | None = Field(default=DEFAULT_LOG_DIR, validate_default=True)
    file_name: str | None = Field(default=DEFAULT_LOG_FILE_NAME, validate_default=True)
    color: bool = Field(default=DEFAULT_LOG_COLOR, validate_default=True)
    rotation: LogRotationConfig = Field(
        default_factory=LogRotationConfig, validate_default=True
    )

    @property
    def log_file(self) -> Path | None:
        """Return the resolved log file path, or None if file logging is disabled."""
        if self.dir is None or self.file_name is None:
            return None
        return self.dir / self.file_name

    @field_validator(CONF_LOGGING_LEVEL, mode="before")
    @classmethod
    def _coerce_level(cls, v: object) -> object:
        if isinstance(v, str):
            return v.upper()
        return v

    @field_validator(CONF_LOGGING_DIR, CONF_LOGGING_FILE_NAME, mode="before")
    @classmethod
    def _coerce_nullable_str(cls, v: object) -> object:
        """Treat empty-string values as None (disables file logging)."""
        if isinstance(v, str) and not v.strip():
            return None
        return v

    @field_validator(CONF_LOGGING_DIR, mode="after")
    @classmethod
    def _resolve_dir_to_absolute(cls, v: Path | None) -> Path | None:
        if v is not None:
            return v.resolve()
        return v


class Config(BaseModel):
    """Boomarr root configuration."""

    config_dir: Path
    config_file: str
    general: GeneralConfig
    logging: LoggingConfig

    @field_validator(CONF_CONFIG_DIR, mode="after")
    @classmethod
    def _resolve_config_dir_to_absolute(cls, v: Path) -> Path:
        """Convert config directory path to absolute."""
        return v.resolve()


_config: Config | None = None


def get_config() -> Config:
    """Return the loaded Config singleton.

    Raises:
        RuntimeError: If load_config() has not been called yet.
    """
    if _config is None:
        raise RuntimeError("Config has not been loaded yet. Call load_config() first.")
    return _config


def _to_yaml_serializable(obj: Any) -> Any:
    """Recursively convert enums and other non-YAML types to YAML-serializable forms."""
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, dict):
        return {k: _to_yaml_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_yaml_serializable(v) for v in obj]
    return obj


def _apply_env_vars(
    model_cls: type[BaseModel],
    yaml_data: dict[str, Any],
    config_file_name: str,
    field_name: str,
) -> dict[str, Any]:
    """Overlay environment variables onto ``yaml_data`` for ``model_cls``.

    The env var prefix is read from the model class's ``_env_prefix`` attribute
    if present, otherwise defaults to the field name in uppercase.
    Field names are derived as ``f"{prefix}_{field_name}".upper()``.

    Warns when the same field is supplied by both the config file
    and an env var (the env var wins).

    Args:
        model_cls: The Pydantic model whose fields to inspect.
        yaml_data: Values already loaded from the config file.
        config_file_name: File name used in the warning message.
        field_name: The name of the field in the parent config class.

    Returns:
        A new dict with env var values overlaid on top of yaml_data.
    """
    prefix: str = getattr(model_cls, "_env_prefix", field_name.upper())
    merged = dict(yaml_data)
    for name, field_info in model_cls.model_fields.items():
        if isinstance(field_info.annotation, type) and issubclass(
            field_info.annotation, BaseModel
        ):
            nested_yaml = merged.get(name) or {}
            merged[name] = _apply_env_vars(
                field_info.annotation, nested_yaml, config_file_name, name
            )
            continue
        env_var = f"{prefix}_{name}".upper() if prefix else name.upper()
        env_value = os.environ.get(env_var)
        if env_value is not None:
            if name in yaml_data:
                display_prefix = prefix if prefix else field_name.upper()
                _LOGGER.warning(
                    "'%s %s' is set in both '%s' (%r) and %s (%r). Env var takes precedence.",
                    display_prefix,
                    name,
                    config_file_name,
                    yaml_data[name],
                    env_var,
                    env_value,
                )
            merged[name] = env_value
    return merged


def load_config(
    config_dir: Path,
    config_file_name: str,
    log_level: LogLevel | None = None,
    log_dir: Path | None = None,
    log_file_name: str | None = None,
) -> Config:
    """Load and validate configuration from all sources.

    Exits:
        Calls sys.exit() with a human-readable error on validation failure.

    Returns:
        The validated Config singleton.
    """
    global _config

    config_path = config_dir / config_file_name
    cli_values: dict[str, dict[str, Any]] = {}
    logging_cli: dict[str, Any] = {}
    if log_level is not None:
        logging_cli[CONF_LOGGING_LEVEL] = log_level
    if log_dir is not None:
        logging_cli[CONF_LOGGING_DIR] = log_dir
    if log_file_name is not None:
        logging_cli[CONF_LOGGING_FILE_NAME] = log_file_name
    if logging_cli:
        cli_values[CONF_LOGGING] = logging_cli

    if not config_path.is_file():
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.touch(exist_ok=True)
        # TODO: Write template config file

    with config_path.open(encoding="utf-8") as config_file:
        yaml_data = yaml.safe_load(config_file) or {}

    sub_configs: dict[str, Any] = {}
    for field_name, field_info in Config.model_fields.items():
        if not (
            isinstance(field_info.annotation, type)
            and issubclass(field_info.annotation, BaseModel)
        ):
            continue
        yaml_sub = yaml_data.get(field_name) or {}
        yaml_excluded: frozenset[str] = getattr(
            field_info.annotation, "_yaml_excluded", frozenset()
        )
        yaml_sub = {k: v for k, v in yaml_sub.items() if k not in yaml_excluded}
        sub_merged = _apply_env_vars(
            field_info.annotation, yaml_sub, config_file_name, field_name
        )
        sub_merged.update(cli_values.get(field_name) or {})
        sub_configs[field_name] = sub_merged

    try:
        _config = Config(
            config_dir=config_dir,
            config_file=config_file_name,
            **sub_configs,
        )
    except ValidationError as exc:
        typer.echo(f"Error validating config file '{config_path}':", err=True)
        typer.echo(exc, err=True)
        sys.exit(1)

    return _config
