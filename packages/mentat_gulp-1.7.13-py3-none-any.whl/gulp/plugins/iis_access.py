"""
IIS access log processor plugin for Gulp.

This module provides a plugin for ingesting and processing Microsoft Internet Information Services (IIS)
access log files. It parses the standard IIS log format and converts records into structured GulpDocument
objects for indexing.

Features:
- Parses comma-separated IIS log entries with standard fields
- Converts timestamps using configurable date formats
- Preserves original log entries while extracting structured fields
- Handles file processing asynchronously with proper error handling

Usage:
This plugin is registered as a GulpPluginType.INGESTION plugin and can be used
to process IIS access logs through the Gulp ingestion pipeline.
"""

import datetime
import os
from typing import Any, override

import aiofiles
from muty.log import MutyLogger
from sqlalchemy.ext.asyncio import AsyncSession

from gulp.api.collab.stats import (
    GulpRequestStats,
    RequestCanceledError,
    SourceCanceledError,
)
from gulp.api.collab.structs import GulpRequestStatus
from gulp.api.opensearch.filters import GulpIngestionFilter
from gulp.api.opensearch.structs import GulpDocument
from gulp.plugin import GulpPluginBase, GulpPluginType
from gulp.structs import GulpPluginCustomParameter, GulpPluginParameters


class Plugin(GulpPluginBase):
    """
    IIS access logs file processor.
    """

    def type(self) -> GulpPluginType:
        return GulpPluginType.INGESTION

    @override
    def desc(self) -> str:
        return "IIS access logs file processor."

    def display_name(self) -> str:
        return "iis_access"

    @override
    async def _record_to_gulp_document(
        self, record: Any, record_idx: int, **kwargs
    ) -> GulpDocument:
        date_format = kwargs.get("date_format")
        event: dict = {}
        fields = record.split(",")
        header = [
            "ClientIP",
            "Username",
            "Date",
            "Time",
            "Service",
            "ServerName",
            "ServerIP",
            "TimeTaken",
            "ClientBytesSent",
            "ServerBytesSent",
            "ServiceStatusCode",
            "WindowsStatusCode",
            "RequestType",
            "TargetOfOperation",
            "Parameters",
        ]

        for k in header:
            i = header.index(k)
            event[k] = fields[i].lstrip()

        d = {}
  
        # map timestamp manually
        time_str = " ".join([event["Date"], event["Time"]])
        timestamp: str = datetime.datetime.strptime(time_str, date_format).isoformat()

        # map
        for k, v in event.items():
            mapped = await self._process_key(k, v, d, **kwargs)
            d.update(mapped)

        return GulpDocument(
            self,
            operation_id=self._operation_id,
            context_id=self._context_id,
            source_id=self._source_id,
            timestamp=timestamp,
            event_original=record,
            event_sequence=record_idx,
            log_file_path=self._original_file_path or os.path.basename(self._file_path),
            **d,
        )

    @override
    async def ingest_file(
        self,
        sess: AsyncSession,
        stats: GulpRequestStats,
        user_id: str,
        req_id: str,
        ws_id: str,
        index: str,
        operation_id: str,
        context_id: str,
        source_id: str,
        file_path: str,
        original_file_path: str = None,
        flt: GulpIngestionFilter = None,
        plugin_params: GulpPluginParameters = None,
        **kwargs,
    ) -> GulpRequestStatus:

        await super().ingest_file(
            sess=sess,
            stats=stats,
            user_id=user_id,
            req_id=req_id,
            ws_id=ws_id,
            index=index,
            operation_id=operation_id,
            context_id=context_id,
            source_id=source_id,
            file_path=file_path,
            original_file_path=original_file_path,
            plugin_params=plugin_params,
            flt=flt,
            **kwargs,
        )

        # get the timestamp format to be used, or use a default
        date_format = self._get_timestamp_format_for_default_timestamp() or "%m/%d/%y %H:%M:%S"
        doc_idx = 0

        async with aiofiles.open(file_path, "r", encoding="utf8") as log_src:
            async for l in log_src:
                # if log_format == "w3c" and l.startswith("#"):
                # TODO: parse header, skip other comments, is this needed/useful info, other than the fields part?
                # continue

                await self.process_record(l, doc_idx, flt=flt, date_format=date_format)

                doc_idx += 1
            return stats.status
