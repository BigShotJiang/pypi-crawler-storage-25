"""
Apache Error Log Common Log Format (CLF) Parser Plugin for Gulp

This module provides a plugin for parsing Apache error logs in Common Log Format.
It extracts key information such as timestamp, log level, process ID, thread ID,
client details, IP addresses, and error messages from Apache error log entries.

The plugin implements the GulpPluginBase and supports the ingestion pipeline
to transform raw log entries into structured GulpDocument objects that can be
indexed and searched.

Example log format parsed:
[Fri Sep 09 10:42:29.902022 2011] [core:error] [pid 35708:tid 4328636416] [client 72.15.99.187] File does not exist: /usr/local/apache2/htdocs/favicon.ico
"""

import os
import re
from typing import Any, override

import aiofiles
import muty.time
from muty.log import MutyLogger
from sqlalchemy.ext.asyncio import AsyncSession

from gulp.api.collab.stats import (
    GulpRequestStats,
    RequestCanceledError,
    SourceCanceledError,
)
from gulp.api.collab.structs import GulpRequestStatus
from gulp.api.opensearch.filters import GulpIngestionFilter
from gulp.api.opensearch.structs import GulpDocument
from gulp.plugin import GulpPluginBase, GulpPluginType
from gulp.structs import GulpMappingParameters, GulpPluginParameters


class Plugin(GulpPluginBase):
    def type(self) -> GulpPluginType:
        return GulpPluginType.INGESTION

    @override
    def desc(self) -> str:
        return "Apache error.log CLF file processor."

    def display_name(self) -> str:
        return "apache_error_clf"

    @override
    async def _record_to_gulp_document(
        self, record: Any, record_idx: int, **kwargs
    ) -> GulpDocument:
        # ^\[(?P<timestamp>[^\]]+)\]\s\[(?P<loglevel>[^\]]+)\]\s\[(?P<pid>[^\]:]+)((?=:):(?P<tid>[^\]]+)|)\]\s((?=\[)(\[(?P<client>[^\]]+)\s(?P<ip>[^\]]+)\]\s(?P<message>.*))|(?!=\[)(?P<message_x>.*))$
        # [Fri Sep 09 10:42:29.902022 2011] [core:error] [pid 35708:tid 4328636416] [client 72.15.99.187] File does not exist: /usr/local/apache2/htdocs/favicon.ico
        parts = [
            r"^\[(?P<date>[^\]]+)\]",
            r"\[(?P<loglevel>[^\]]+)\]",
            r"\[(?P<pid>[^\]]+)((?=:):(?P<tid>[^\]]+)|)\]",
            r"((?=\[)(\[(?P<client>[^\]]+)\s(?P<ip>[^\]]+)\]\s(?P<message>.*))|(?!=\[)(?P<message_only>.*))$",
        ]
        pattern = re.compile(r"\s+".join(parts))
        matches = pattern.match(record.strip("\n"))

        # if matches is None:
        #     print(matches)
        #     print(record)
        #     print("*" * 1000)

        client = matches.groupdict().get("client", "")
        ip = matches.groupdict().get("ip", "")
        message = matches.groupdict().get("message", None)
        message_only = matches.groupdict().get("message_only", "")

        if message is None:
            message = message_only

        event = {
            "date": matches["date"],
            "loglevel": matches["loglevel"],
            "pid": matches["pid"],
            "tid": matches["tid"],
            "client": client,
            "ip": ip,
            "message": message,
        }

        d: dict = {}

        # map timestamp manually
        time_str = event.pop("date")
        time_str = muty.time.ensure_iso8601(time_str)

        # map
        for k, v in event.items():
            mapped = await self._process_key(k, v, d, **kwargs)
            d.update(mapped)

        return GulpDocument(
            self,
            operation_id=self._operation_id,
            context_id=self._context_id,
            source_id=self._source_id,
            timestamp=time_str,
            event_original=record,
            event_sequence=record_idx,
            log_file_path=self._original_file_path or os.path.basename(self._file_path),
            **d,
        )

    @override
    async def ingest_file(
        self,
        sess: AsyncSession,
        stats: GulpRequestStats,
        user_id: str,
        req_id: str,
        ws_id: str,
        index: str,
        operation_id: str,
        context_id: str,
        source_id: str,
        file_path: str,
        original_file_path: str = None,
        flt: GulpIngestionFilter = None,
        plugin_params: GulpPluginParameters = None,
        **kwargs,
    ) -> GulpRequestStatus:

        plugin_params = self._ensure_plugin_params(
            plugin_params, mapping_file="apache_error_clf.json"
        )

        await super().ingest_file(
            sess=sess,
            stats=stats,
            user_id=user_id,
            req_id=req_id,
            ws_id=ws_id,
            index=index,
            operation_id=operation_id,
            context_id=context_id,
            source_id=source_id,
            file_path=file_path,
            original_file_path=original_file_path,
            flt=flt,
            plugin_params=plugin_params,
            **kwargs,
        )

        doc_idx = 0
        async with aiofiles.open(file_path, "r", encoding="utf8") as log_src:
            async for l in log_src:
                l = l.strip()
                if not l:
                    continue
                await self.process_record(l, doc_idx, flt=flt)

                doc_idx += 1
        return stats.status
