"""
This module provides classes for handling user sessions in the Gulp application.

The `GulpUserSession` class represents a user session for a logged-in user, maintaining
the relationship between sessions and users, and providing mechanisms for session validation,
permission checking, and access control.

Key features include:
- Session management with expiration handling
- Permission-based access control for resources
- Special handling for admin sessions
- Token validation with configurable permission requirements

This module works in conjunction with the user management system to provide
authentication and authorization services throughout the application.
"""

from typing import TYPE_CHECKING, Optional, override

from muty.log import MutyLogger
import muty.string
from sqlalchemy import BIGINT, ForeignKey
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column, relationship

from gulp.api.collab.structs import (
    COLLABTYPE_USER_SESSION,
    GulpCollabBase,
    GulpCollabFilter,
    GulpUserPermission,
    MissingPermission,
    T,
)
from gulp.config import GulpConfig
from gulp.structs import ObjectNotFound

# if TYPE_CHECKING:
from gulp.api.collab.user import GulpUser


class GulpUserSession(GulpCollabBase, type=COLLABTYPE_USER_SESSION):
    """
    Represents a user session (logged user).
    """

    session_user_id: Mapped[str] = mapped_column(
        ForeignKey("user.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
        doc="The ID of the user associated with this session.",
    )
    user: Mapped["GulpUser"] = relationship(
        "GulpUser",
        back_populates="session",
        uselist=False,
        foreign_keys=[session_user_id],
        lazy="joined",
    )
    time_expire: Mapped[Optional[int]] = mapped_column(
        BIGINT,
        default=0,
        doc="The time when the session expires, in milliseconds from unix epoch.",
    )

    @override
    @classmethod
    def example(cls) -> dict:
        d = super().example()
        d["session_user_id"] = "user_id"
        d["time_expire"] = 0
        return d

    @override
    @classmethod
    async def create(
        cls,
        *args,
        **kwargs,
    ) -> T:
        """
        uninmplemented, use GulpUser.login() to create a session.
        """
        raise NotImplementedError("use GulpUser.login() to create a session.")

    @staticmethod
    async def get_logged_users(sess: AsyncSession) -> list[dict]:
        """
        Get all user sessions (currently logged users).

        Args:
            sess (AsyncSession): The database session to use.
        Returns:
            list[dict]: A list of user sessions as dictionaries.
        """
        rows = await GulpUserSession.get_by_filter(sess, throw_if_not_found=True)
        return [r.to_dict() for r in rows] if rows else []

    @staticmethod
    async def _get_admin_session(sess: AsyncSession) -> "GulpUserSession":
        """
        Get an admin session (which never expires), for debugging purposes only

        Args:
            sess (AsyncSession): The database session to use.

        Returns:
            GulpUserSession: The admin session object.
        """
        try:
            from gulp.api.collab.user import GulpUser

            # the "admin" user always exists
            admin_user: GulpUser = await GulpUser.get_by_id(sess, obj_id="admin")
            if admin_user.session:
                # already exists
                return admin_user.session

            # create a new permanent admin session
            admin_session: GulpUserSession = await GulpUserSession.create_internal(
                sess, admin_user.id, time_expire=0, session_user_id=admin_user.id
            )
            # MutyLogger.get_instance().debug("created new admin session: %s" % (admin_session.to_dict()))
            return admin_session
        finally:
            pass
    
    async def get_by_user_id(sess: AsyncSession, user_id: str, throw_if_not_found: bool = True) -> Optional["GulpUserSession"]:
        """
        Get the session for a given user ID.

        Args:
            sess (AsyncSession): The database session to use.
            user_id (str): The ID of the user whose session to retrieve.
            throw_if_not_found (bool, optional): If True, raises an exception if no session is found for the user. Defaults to True.
        Returns:
            Optional[GulpUserSession]: The user session object if found, or None if not found and throw_if_not_found is False.
        Raises:
            ObjectNotFound: If no session is found for the user and throw_if_not_found is True.
        """
        l: list[GulpUserSession] = await GulpUserSession.get_by_filter(
            sess,
            flt=GulpCollabFilter(session_user_id=user_id),
            user_id=user_id,
            throw_if_not_found=throw_if_not_found,
        )
        if l:
            return l[0]
        return None

    async def update_expiration_time(
        self, sess: AsyncSession, is_admin: bool, update_id: bool = False
    ) -> None:
        """
        Update the expiration time, and possibly token id, of the session.

        NOTE: the session is committed

        Args:
            sess (AsyncSession): The database session to use.
            is_admin (bool): Whether the user is an admin.
            update_id (bool): If True, also updates the session ID to a new unique value (renew token)
        """
        # get expiration time
        time_expire = GulpConfig.get_instance().token_expiration_time(is_admin=is_admin)
        if update_id:
            # update the session ID if requested
            if GulpConfig.get_instance().is_integration_test():
                token_id: str = "token_" + self.user.id
            else:
                # autogenerated
                token_id: str = muty.string.generate_unique()
            MutyLogger.get_instance().debug(
                "updating token id for existing session, previous= %s, new=%s"
                % (self.id, token_id)
            )
            self.id = token_id

        MutyLogger.get_instance().debug(
            "session expiration time updated for user_id=%s, previous= %s, new=%s"
            % (self.user.id, self.time_expire, time_expire)
        )
        self.time_expire = time_expire
        await sess.commit()

    async def check_permissions(
        self,
        sess: AsyncSession,
        permission: list[GulpUserPermission] | GulpUserPermission = None,
        obj: Optional[GulpCollabBase] = None,
        throw_on_no_permission: bool = True,
        enforce_owner: bool = False,
    ) -> "GulpUserSession":
        """
        Check if the user represented by this session has the required permissions.

        - if user is an admin, the function will always grant access.
        - if no obj is provided, the function will just check if the user has the required permission/s.
        - if obj is provided, the function will check the user permissions against the object to access it.
            - check GulpUser.check_object_access() for details.

        Args:
            sess (AsyncSession): The database session to use.
            permission (list[GulpUserPermission]|GulpUserPermission, optional): The permission(s) required to access the object. Defaults to None (just check for READ permission, which every token has: basically it just checks if the token exists).
            obj (Optional[GulpCollabBase], optional): The object to check the permissions against, for access. Defaults to None.
            throw_on_no_permission (bool, optional): If True, raises an exception if the user does not have the required permissions (or if he's not logged on). Defaults to True.
            enforce_owner (bool, optional): If True, the user must be the owner of the object to access it (or administrator
        Returns:
            GulpUserSession: The user session object (includes GulpUser object) or None if the user does not have the required permissions and throw_on_no_permission is False.
        Raises:
            MissingPermission: If the user does not have the required permissions.
        """
        if not permission:
            # assume read permission is requested if not provided
            permission = [GulpUserPermission.READ]

        if isinstance(permission, GulpUserPermission):
            # allow single permission as string
            permission = [permission]

        is_admin: bool = False
        try:
            if self.user.is_admin():
                # admin user can access any object and always have permission
                is_admin = True
                return self

            if not obj:
                # check if the user have the required permission (owner always have permission)
                if self.user.has_permission(permission):
                    # access granted
                    return self

                if throw_on_no_permission:
                    raise MissingPermission(
                        f"user={self.user.id} does not have the required permissions {permission} to perform this operation."
                    )
                return None

            # check if the user has access (the user, or the user's groups, have access to the object, or the object is public (no grants set))
            if self.user.check_object_access(
                obj,
                throw_on_no_permission=throw_on_no_permission,
                enforce_owner=enforce_owner,
            ):
                # check if the user have the required permission (owner always have permission)
                if self.user.has_permission(permission) or obj.is_owner(self.user.id):
                    # access granted
                    return self

            if throw_on_no_permission:
                raise MissingPermission(
                    f"user={self.session_user_id} does not have the required permissions {permission} to perform this operation, obj={obj.id if obj else None}, obj_owner={obj.user_id if obj else None}."
                )
            return None
        finally:
            # finally, update user session's expiration time
            await self.update_expiration_time(sess, is_admin=is_admin)

    @staticmethod
    async def check_token(
        sess: AsyncSession,
        token: str,
        permission: list[GulpUserPermission] | GulpUserPermission = None,
        obj: Optional[GulpCollabBase] = None,
        throw_on_no_permission: bool = True,
        enforce_owner: bool = False,
    ) -> "GulpUserSession":
        """
        static method which checks if the provided token is valid and has the required permissions (calls GulpUserSession.check())

        Args:
            sess (AsyncSession): The database session to use.
            token (str): The session token to check.
            permission (list[GulpUserPermission]|GulpUserPermission, optional): The permission(s
                required to access the object. Defaults to None (just check for READ permission, which every token has: basically it checks if the token exists).
            obj (Optional[GulpCollabBase], optional): The object to check the permissions against, for access. Defaults to None.
            throw_on_no_permission (bool, optional): If True, raises an exception if the user does not have the required permissions (or if he's not logged on). Defaults to True.
            enforce_owner (bool, optional): If True, the user must be the owner of the object to access it (or administrator
        Returns:
            GulpUserSession: The user session object (includes GulpUser object) or None if the user does not have the required permissions and throw_on_no_permission is False.
        Raises:
            MissingPermission: If the user does not have the required permissions.
        """
        MutyLogger.get_instance().debug(
            "---> check_token_permission: token=%s, permission=%s, sess=%s ..."
            % (token, permission, sess)
        )

        if GulpConfig.get_instance().debug_allow_any_token_as_admin():
            # session expiration time is not taken into account in this case
            return await GulpUserSession._get_admin_session(sess)

        try:
            user_session: GulpUserSession = await GulpUserSession.get_by_id(
                sess, obj_id=token, throw_if_not_found=throw_on_no_permission
            )
            # MutyLogger.get_instance().debug("got user session for token %s: %s" % (token, user_session.to_dict()))
        except ObjectNotFound as ex:
            raise MissingPermission('token "%s" not logged in' % (token)) from ex

        return await user_session.check_permissions(
            sess,
            permission=permission,
            obj=obj,
            throw_on_no_permission=throw_on_no_permission,
            enforce_owner=enforce_owner,
        )
