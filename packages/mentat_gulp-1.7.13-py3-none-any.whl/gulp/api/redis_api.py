"""
This module provides a singleton class `GulpRedis` for managing asynchronous Redis operations, including WebSocket metadata storage, pub/sub messaging, and a task queue.
"""

import asyncio
import time
import zlib
from typing import Annotated, Any, Callable, Optional
from urllib.parse import urlparse

import muty.string
import orjson
import redis.asyncio as redis
from muty.log import MutyLogger
from pydantic import BaseModel, Field
from redis.asyncio.client import PubSub
from redis.exceptions import ConnectionError as RedisConnectionError, ResponseError
from gulp.api.prometheus_api import GulpMetrics
from gulp.config import GulpConfig


class GulpWsMetadata(BaseModel):
    """
    Metadata for a WebSocket connection stored in Redis
    """

    ws_id: Annotated[str, Field(description="The websocket id")]
    server_id: Annotated[
        str, Field(description="The server instance id that owns this websocket")
    ]
    types: Annotated[
        list[str],
        Field(
            description="List of GulpWsData.type this websocket is interested in, default is an empty list(all)",
            default_factory=list,
        ),
    ]
    operation_ids: Annotated[
        list[str],
        Field(
            description="List of `operation_id` this websocket is interested in, default is an empty list(all)",
            default_factory=list,
        ),
    ]
    socket_type: Annotated[
        str, Field(description="The socket type (default, ingest, client_data)")
    ]


# module-local Redis channel names (class-level constants removed; use GulpRedisChannel as canonical source)
_MAIN_REDIS_CHANNEL = "gulpredis"
_CLIENT_DATA_REDIS_CHANNEL = "gulpredis:client_data"


class GulpRedis:
    """
    Singleton class to manage Redis connections and operations.
    """

    _instance: "GulpRedis" = None
    # redis set key to track known task types (members are task_type strings)
    TASK_TYPES_SET = "gulp:queue:types"
    # redis stream key prefix for task streams (one stream per task_type)
    STREAM_TASK_PREFIX = "gulp:stream:tasks"
    # consumer group name for task streams
    STREAM_CONSUMER_GROUP = "gulp:stream:group:tasks"
    # redis key for broadcasting aggregate websocket queue utilization from main to workers
    WS_QUEUE_UTILIZATION_KEY = "gulp:ws:queue_utilization"
    # how often (seconds) the main process updates the utilization key
    WS_QUEUE_UTILIZATION_UPDATE_INTERVAL: float = 1.0
    # idle time (ms) after which a pending message can be auto-claimed by another consumer
    TASK_AUTOCLAIM_IDLE_MS: int = 60_000  # 60 seconds
    # approximate max length for task streams (trimmed on XADD)
    STREAM_TASK_MAXLEN: int = 10_000
    # heartbeat key prefix and TTL for node liveness detection
    HEARTBEAT_KEY_PREFIX: str = "gulp:heartbeat"
    HEARTBEAT_TTL: int = 30  # seconds — key expires if not refreshed
    HEARTBEAT_INTERVAL: float = 10.0  # seconds between heartbeat updates
    # TTL for websocket metadata and lookup keys (seconds)
    WS_KEY_TTL: int = 300  # 5 minutes, refreshed periodically by live connections

    def __init__(self):
        self._redis: redis.Redis = None
        self._pubsub: PubSub = None
        self._subscriber_task: asyncio.Task = None
        self._subscriber_callback: Callable[[dict], Any] | None = None
        self._pubsub_lock: asyncio.Lock = asyncio.Lock()
        self.server_id: str = None
        # list of roles assigned to this server instance (e.g. ['ingest', 'query'])
        self._instance_roles: list[str] = []
        # simple task queue (list) key
        self._task_queue_key: str = "gulp:queue:tasks"
        # ttl for stored large payloads (seconds)
        self.PUBLISH_LARGE_PAYLOAD_TTL: int = (
            5 * 60
        )  # 5 min, it should be consumed quickly
        self._publish_rate_limit: int = 100  # msgs per second

        # Token-bucket for publish backpressure (replaces sliding-window sleep behavior)
        # - `_token_bucket_rate` : refill rate (tokens/sec) — defaults to `_publish_rate_limit`
        # - `_token_bucket_capacity` : max burst capacity (tokens)
        # - `_token_bucket_tokens` : current available tokens (float)
        # - `_token_bucket_last` : last refill timestamp
        self._token_bucket_rate: float = float(self._publish_rate_limit)
        self._token_bucket_capacity: float = max(
            1.0, float(self._publish_rate_limit) * 2.0
        )
        self._token_bucket_tokens: float = float(self._token_bucket_capacity)
        self._token_bucket_last: float = time.monotonic()

        # timestamp of last aggregate utilization update (main process only)
        self._last_utilization_update: float = 0.0
        # timestamp of last heartbeat update (main process only)
        self._last_heartbeat_update: float = 0.0
        # timestamp of last autoclaim sweep (main process only)
        self._last_autoclaim_time: float = 0.0
        # cached utilization value for workers (read from Redis)
        self._cached_queue_utilization: float = 0.0
        self._cached_queue_utilization_time: float = 0.0
        # semaphore to limit concurrent message handler tasks in subscriber loop
        self._handler_semaphore: asyncio.Semaphore = asyncio.Semaphore(16)
        # track in-flight handler tasks for cleanup
        self._handler_tasks: set[asyncio.Task] = set()

    def __new__(cls):
        """
        Create a new instance of the class.
        """
        if not cls._instance:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def get_instance(cls) -> "GulpRedis":
        """
        returns the singleton instance of the Redis client.

        Returns:
            GulpRedis: The singleton instance of the Redis client.
        """
        if not cls._instance:
            cls._instance = cls()
        return cls._instance

    def client(self) -> redis.Redis:
        """
        Get the underlying Redis (async) client.

        Returns:
            redis.Redis: The Redis (async) client instance.

        Throws:
            RuntimeError: If initialize() has not been called yet.
        """
        if not self._redis:
            raise RuntimeError("initialize() must be called first!")
        return self._redis

    def initialize(self, server_id: str, main_process: bool = True) -> None:
        """
        Initialize Redis pub/sub connections.

        Args:
            server_id (str): The unique server instance ID
        """
        self.server_id = server_id

        # determine instance roles from configuration
        self._instance_roles = GulpConfig.get_instance().instance_roles()

        # load configurable Redis constants
        cfg = GulpConfig.get_instance()
        GulpRedis.TASK_AUTOCLAIM_IDLE_MS = cfg.redis_task_autoclaim_idle_ms()
        GulpRedis.STREAM_TASK_MAXLEN = cfg.redis_stream_task_maxlen()
        GulpRedis.HEARTBEAT_TTL = cfg.redis_heartbeat_ttl()
        GulpRedis.HEARTBEAT_INTERVAL = cfg.redis_heartbeat_interval()
        GulpRedis.WS_KEY_TTL = cfg.redis_ws_key_ttl()

        # create redis client
        url: str = GulpConfig.get_instance().redis_url()
        max_connections = cfg.redis_max_connections()
        redis_kwargs: dict[str, Any] = {"decode_responses": False}
        if max_connections > 0:
            redis_kwargs["max_connections"] = max_connections
        self._redis = redis.Redis.from_url(url, **redis_kwargs)
        url_parts = urlparse(url)
        MutyLogger.get_instance().info(
            "client %s connected to Redis at %s:%d (max_connections=%s)",
            self._redis,
            url_parts.hostname,
            url_parts.port,
            max_connections if max_connections > 0 else "unlimited",
        )

        if main_process:
            # create pub/sub connection
            self._pubsub = self._redis.pubsub()

            MutyLogger.get_instance().info(
                "initialized Redis pub/sub for server_id=%s", server_id
            )

    async def shutdown(self) -> None:
        """
        close Redis connections and cleanup.
        """
        from gulp.process import GulpProcess

        main_process = GulpProcess.get_instance().is_main_process()

        if main_process:
            try:
                await self.unsubscribe()
            except Exception:
                MutyLogger.get_instance().exception(
                    "error closing pubsub during shutdown!"
                )

        # close redis client
        try:
            await self._redis.close()
            MutyLogger.get_instance().info(
                "Redis client %s connection closed, redis shutdown DONE!, main_process=%r",
                self._redis,
                main_process,
            )
        except Exception as ex:
            MutyLogger.get_instance().exception("error closing redis client!")

    def _get_ws_metadata_key(self, ws_id: str) -> str:
        """Get Redis key for websocket metadata."""
        return f"gulp:ws:metadata:{self.server_id}:{ws_id}"

    def _get_ws_lookup_key(self, ws_id: str) -> str:
        """Get Redis key for quick ws_id to server_id lookup."""
        return f"gulp:ws:lookup:{ws_id}"

    async def ws_register(
        self,
        ws_id: str,
        types: list[str] = None,
        operation_ids: list[str] = None,
        socket_type: str = "default",
    ) -> bool:
        """
        Register a websocket in Redis.

        Args:
            ws_id (str): The websocket id
            types (list[str], optional): List of message types this ws is interested in
            operation_ids (list[str], optional): List of operation_ids this ws is interested in
            socket_type (str): The socket type
            ttl (int): Time to live in seconds

        Returns:
            bool: True if registered successfully
        """
        metadata = GulpWsMetadata(
            ws_id=ws_id,
            server_id=self.server_id,
            types=types or [],
            operation_ids=operation_ids or [],
            socket_type=socket_type,
        )

        # store metadata
        metadata_key = self._get_ws_metadata_key(ws_id)
        await self._redis.set(
            metadata_key,
            orjson.dumps(metadata.model_dump()),
            ex=self.WS_KEY_TTL,
        )

        # store ws_id -> server_id lookup mapping
        lookup_key = self._get_ws_lookup_key(ws_id)
        await self._redis.set(lookup_key, self.server_id.encode(), ex=self.WS_KEY_TTL)

        MutyLogger.get_instance().debug(
            "registered websocket: ws_id=%s, server_id=%s",
            ws_id,
            self.server_id,
        )
        return True

    async def ws_unregister(self, ws_id: str) -> bool:
        """
        Unregister a websocket from Redis.

        Args:
            ws_id (str): The websocket id

        Returns:
            bool: True if unregistered successfully
        """
        lookup_key = self._get_ws_lookup_key(ws_id)

        deleted_total = 0
        try:
            # delete any metadata keys for this ws_id across all server instances
            pattern = f"gulp:ws:metadata:*:{ws_id}"
            cursor = 0
            keys_to_delete: list[str] = []
            while True:
                cursor, keys = await self._redis.scan(
                    cursor=cursor, match=pattern, count=200
                )
                if keys:
                    keys_to_delete.extend(keys)
                if cursor == 0:
                    break

            if keys_to_delete:
                try:
                    deleted = await self._redis.delete(*keys_to_delete)
                    if isinstance(deleted, int):
                        deleted_total += deleted
                except Exception:
                    MutyLogger.get_instance().exception(
                        "failed to delete ws metadata keys"
                    )

            # delete the lookup mapping ws_id -> server_id
            try:
                deleted = await self._redis.delete(lookup_key)
                if isinstance(deleted, int):
                    deleted_total += deleted
            except Exception:
                MutyLogger.get_instance().exception("failed to delete ws lookup key")

        except Exception:
            MutyLogger.get_instance().exception(
                "error during ws_unregister scan/delete"
            )

        MutyLogger.get_instance().debug(
            "unregistered websocket: ws_id=%s, deleted=%d",
            ws_id,
            deleted_total,
        )
        return deleted_total > 0

    async def ws_refresh_ttl(self, ws_id: str) -> None:
        """
        Refresh the TTL on websocket metadata and lookup keys for a live connection.

        Args:
            ws_id (str): The websocket id
        """
        try:
            metadata_key = self._get_ws_metadata_key(ws_id)
            lookup_key = self._get_ws_lookup_key(ws_id)
            pipe = self._redis.pipeline(transaction=False)
            pipe.expire(metadata_key, self.WS_KEY_TTL)
            pipe.expire(lookup_key, self.WS_KEY_TTL)
            await pipe.execute()
        except Exception:
            MutyLogger.get_instance().exception(
                "error refreshing TTL for ws_id=%s", ws_id
            )

    async def ws_refresh_all_ttls(self) -> None:
        """
        Refresh TTLs for all websocket keys owned by this server.
        Called periodically by the main process.
        """
        pattern = f"gulp:ws:metadata:{self.server_id}:*"
        try:
            cursor = 0
            while True:
                cursor, keys = await self._redis.scan(
                    cursor=cursor, match=pattern, count=200
                )
                if keys:
                    pipe = self._redis.pipeline(transaction=False)
                    for key in keys:
                        pipe.expire(key, self.WS_KEY_TTL)
                        # also refresh the lookup key
                        # extract ws_id from metadata key: gulp:ws:metadata:{server_id}:{ws_id}
                        try:
                            key_str = key.decode() if isinstance(key, bytes) else key
                            ws_id = key_str.rsplit(":", 1)[-1]
                            lookup_key = self._get_ws_lookup_key(ws_id)
                            pipe.expire(lookup_key, self.WS_KEY_TTL)
                        except Exception:
                            pass
                    await pipe.execute()
                if cursor == 0:
                    break
        except Exception:
            MutyLogger.get_instance().exception("error refreshing ws key TTLs")

    async def ws_get_server(self, ws_id: str) -> str:
        """
        Get the server_id that owns a websocket.

        Args:
            ws_id (str): The websocket id

        Returns:
            str: The server_id or None if not found
        """
        lookup_key = self._get_ws_lookup_key(ws_id)
        server_id: bytes = await self._redis.get(lookup_key)
        return server_id.decode() if server_id else None

    async def ws_get_metadata(self, ws_id: str) -> Optional[GulpWsMetadata]:
        """
        Get websocket metadata.

        Args:
            ws_id (str): The websocket id

        Returns:
            Optional[GulpWsMetadata]: The metadata or None if not found
        """
        metadata_key = self._get_ws_metadata_key(ws_id)
        data = await self._redis.get(metadata_key)

        if data:
            return GulpWsMetadata.model_validate(orjson.loads(data))
        return None

    def worker_to_main_channel(self, server_id: str | None = None) -> str:
        """Return the targeted pub/sub channel used to hand messages to a server's main process."""
        target_server_id = server_id or self.server_id
        if not target_server_id:
            return _MAIN_REDIS_CHANNEL
        return f"{_MAIN_REDIS_CHANNEL}:server:{target_server_id}"

    def _pubsub_channels(self) -> list[str]:
        """Return the channels the main-process subscriber must keep attached to."""
        channels = [_MAIN_REDIS_CHANNEL, _CLIENT_DATA_REDIS_CHANNEL]
        if self.server_id:
            channels.append(self.worker_to_main_channel(self.server_id))
        return channels

    def _has_active_pubsub_subscriptions(self, pubsub: PubSub | None = None) -> bool:
        """Return whether the pubsub object currently tracks any active subscriptions."""
        active_pubsub = pubsub or self._pubsub
        if active_pubsub is None:
            return False

        channels = getattr(active_pubsub, "channels", None) or {}
        patterns = getattr(active_pubsub, "patterns", None) or {}
        return bool(channels or patterns)

    def _ensure_pubsub(self) -> PubSub:
        """Create a pubsub object lazily when the main process subscribes."""
        if self._pubsub is None:
            self._pubsub = self._redis.pubsub()
        return self._pubsub

    async def publish(self, message: dict, channel: str | None = None) -> None:
        """
        Publish a message on redis pubsub.

        Args:
            message (dict): The message to publish (must be a GulpWsData dict)
            channel (str|None): Redis pubsub channel name to publish to. If None, uses main channel.
        """
        # determine redis channel name
        channel_to_use = channel or _MAIN_REDIS_CHANNEL

        # serialize message
        payload = orjson.dumps(message)
        compression_threshold: int = (
            GulpConfig.get_instance().redis_compression_threshold() * 1024
        )
        pubsub_max_chunk_size: int = (
            GulpConfig.get_instance().redis_pubsub_max_chunk_size() * 1024
        )

        await self._apply_publish_backpressure()

        if GulpConfig.get_instance().prometheus_enabled():
            # update Prometheus counters
            try:
                GulpMetrics.redis_publish_total.inc()
                GulpMetrics.redis_publish_bytes_total.inc(len(payload))
                if ":server:" in channel_to_use:
                    GulpMetrics.redis_targeted_publish_total.inc()
            except Exception:
                pass

        # if payload is too large, compress, chunk and store it in Redis then publish a small pointer
        try:
            if len(payload) > compression_threshold:
                # decide whether to compress payload based on configuration
                compress_payload = GulpConfig.get_instance().redis_compression_enabled()

                if compress_payload:
                    # compress the serialized payload to reduce storage and network size
                    try:
                        stored_bytes = zlib.compress(payload)
                        compressed_flag = True
                    except Exception:
                        MutyLogger.get_instance().exception(
                            "failed to compress large payload, falling back to direct publish"
                        )
                        await self._redis.publish(channel_to_use, payload)
                        return
                else:
                    # store uncompressed bytes
                    stored_bytes = payload
                    compressed_flag = False

                # split bytes into chunks
                chunks = [
                    stored_bytes[i : i + pubsub_max_chunk_size]
                    for i in range(0, len(stored_bytes), pubsub_max_chunk_size)
                ]
                num_chunks = len(chunks)

                # include server_id in base key to prevent cross-node chunk retrieval
                base_key = (
                    f"gulp:pub:payload:{self.server_id}:{muty.string.generate_unique()}"
                )
                chunk_keys = [f"{base_key}:{i}" for i in range(num_chunks)]

                # pointer metadata to publish on pubsub
                pointer_message = dict(message)
                pointer_message["payload"] = {
                    "__pointer_key": base_key,
                    "__chunks": num_chunks,
                    "__compressed": compressed_flag,
                    "__orig_len": len(payload),
                    "__server_id": self.server_id,  # track which server stored the chunks
                }
                pointer_bytes = orjson.dumps(pointer_message)

                # use a pipelined SET+EX calls followed by PUBLISH instead of Lua to avoid per-message
                # Lua script compilation overhead. Pipelines give similar atomicity for our use case
                # (all commands executed together) and are faster in practice.
                try:
                    pipe = self._redis.pipeline(transaction=True)
                    for i, c in enumerate(chunks):
                        pipe.set(chunk_keys[i], c, ex=self.PUBLISH_LARGE_PAYLOAD_TTL)
                    pipe.publish(channel_to_use, pointer_bytes)
                    await pipe.execute()

                    if GulpConfig.get_instance().prometheus_enabled():
                        # update Prometheus counter for chunked publishes
                        try:
                            GulpMetrics.redis_chunked_publish_total.inc()
                        except Exception:
                            pass
                    MutyLogger.get_instance().warning(
                        "published large %s message stored in %d chunks base=%s total_size=%d bytes (stored=%d)",
                        "compressed" if compressed_flag else "uncompressed",
                        num_chunks,
                        base_key,
                        len(payload),
                        len(stored_bytes),
                    )
                    return
                except Exception:
                    MutyLogger.get_instance().exception(
                        "pipeline store/publish failed for chunked payload, attempting non-transactional fallback"
                    )
                    # fallback: best-effort non-transactional pipeline (may succeed on partial failures)
                    try:
                        pipe = self._redis.pipeline(transaction=False)
                        for i, c in enumerate(chunks):
                            pipe.set(
                                chunk_keys[i], c, ex=self.PUBLISH_LARGE_PAYLOAD_TTL
                            )
                        pipe.publish(channel_to_use, pointer_bytes)
                        await pipe.execute()
                        MutyLogger.get_instance().warning(
                            "published large %s message stored (fallback non-atomic) in %d chunks base=%s",
                            "compressed" if compressed_flag else "uncompressed",
                            num_chunks,
                            base_key,
                        )
                        return
                    except Exception:
                        MutyLogger.get_instance().exception(
                            "failed to store chunked payload in Redis (pipeline fallback), falling back to direct publish"
                        )

        except Exception:
            MutyLogger.get_instance().exception("error handling large publish payload")

        # default: publish inline
        await self._redis.publish(channel_to_use, payload)

    async def _apply_publish_backpressure(self) -> None:
        """Token-bucket rate limiter to avoid flooding Redis pubsub.

        Replenishes tokens at `_token_bucket_rate` per second up to
        `_token_bucket_capacity`. Each publish consumes one token. If no
        token is available the coroutine waits (non-busy) until enough
        tokens accumulate. This provides smooth steady-state rate
        limiting with bounded bursts.
        """
        now = time.monotonic()

        # refill tokens based on elapsed time
        elapsed = now - self._token_bucket_last
        if elapsed > 0:
            self._token_bucket_tokens = min(
                self._token_bucket_capacity,
                self._token_bucket_tokens + elapsed * self._token_bucket_rate,
            )
            self._token_bucket_last = now

        # check aggregate websocket queue utilization and apply end-to-end throttling
        try:
            depth = await self._get_queue_utilization()
            throttle_threshold = GulpConfig.get_instance().ws_throttle_threshold()
            if depth > throttle_threshold:
                # progressive delay up to ws_throttle_max_delay() based on pressure above threshold
                max_delay = GulpConfig.get_instance().ws_throttle_max_delay()
                pressure_above = (depth - throttle_threshold) / (
                    1.0 - throttle_threshold
                )
                delay = max_delay * pressure_above
                MutyLogger.get_instance().warning(
                    "publish backpressure throttling: agg_queue_util=%.2f threshold=%.2f delay=%.3fs",
                    depth,
                    throttle_threshold,
                    delay,
                )
                await asyncio.sleep(delay)
        except Exception:
            # best-effort: if we can't inspect socket queues, proceed with normal token-bucket
            MutyLogger.get_instance().exception(
                "failed to evaluate aggregate queue utilization for backpressure"
            )

        # if token available, consume and return immediately
        if self._token_bucket_tokens >= 1.0:
            self._token_bucket_tokens -= 1.0
            return

        # compute time to wait until next token is available
        needed = 1.0 - self._token_bucket_tokens
        wait_time = (
            needed / self._token_bucket_rate if self._token_bucket_rate > 0 else 0.01
        )

        # wait (in small increments to be responsive to wakeups)
        # cap single sleep to 0.1s to remain responsive under contention
        while self._token_bucket_tokens < 1.0:
            await asyncio.sleep(min(wait_time, 0.1))
            now = time.monotonic()
            elapsed = now - self._token_bucket_last
            if elapsed > 0:
                self._token_bucket_tokens = min(
                    self._token_bucket_capacity,
                    self._token_bucket_tokens + elapsed * self._token_bucket_rate,
                )
                self._token_bucket_last = now
            # recompute remaining wait_time
            needed = max(0.0, 1.0 - self._token_bucket_tokens)
            wait_time = (
                needed / self._token_bucket_rate
                if self._token_bucket_rate > 0
                else 0.01
            )

        # consume token and continue
        self._token_bucket_tokens -= 1.0

    async def _get_queue_utilization(self) -> float:
        """Get aggregate websocket queue utilization.

        In the main process, reads directly from GulpConnectedSockets.
        In worker processes, reads the shared Redis key published by the main process.

        Returns:
            float: utilization between 0.0 and 1.0
        """
        from gulp.process import GulpProcess

        if GulpProcess.get_instance().is_main_process():
            from gulp.api.ws_api import GulpConnectedSockets

            return GulpConnectedSockets.get_instance().aggregate_queue_utilization()

        return self._cached_queue_utilization

    async def _update_queue_utilization_key(self) -> None:
        """Write the current aggregate websocket queue utilization to Redis.

        Called periodically from the main process subscriber loop so that
        worker processes can read the value for end-to-end backpressure.
        """
        now = time.monotonic()
        if (
            now - self._last_utilization_update
            < self.WS_QUEUE_UTILIZATION_UPDATE_INTERVAL
        ):
            return

        self._last_utilization_update = now
        try:
            from gulp.api.ws_api import GulpConnectedSockets

            depth = GulpConnectedSockets.get_instance().aggregate_queue_utilization()
            # SET with short TTL so stale values expire if main process dies
            await self._redis.set(
                self.WS_QUEUE_UTILIZATION_KEY,
                str(depth),
                ex=10,
            )
        except Exception:
            # best-effort
            pass

    async def _update_heartbeat(self) -> None:
        """Update the heartbeat key for this server instance.

        Called periodically from the main process subscriber loop so that
        other nodes can detect liveness.
        """
        now = time.monotonic()
        if now - self._last_heartbeat_update < self.HEARTBEAT_INTERVAL:
            return

        self._last_heartbeat_update = now
        try:
            key = f"{self.HEARTBEAT_KEY_PREFIX}:{self.server_id}"
            await self._redis.set(key, b"1", ex=self.HEARTBEAT_TTL)
        except Exception:
            # best-effort
            pass

    async def is_server_alive(self, server_id: str) -> bool:
        """Check if a server instance is alive by checking its heartbeat key.

        Args:
            server_id (str): The server instance ID to check.

        Returns:
            bool: True if the server's heartbeat key exists.
        """
        try:
            key = f"{self.HEARTBEAT_KEY_PREFIX}:{server_id}"
            return bool(await self._redis.exists(key))
        except Exception:
            return False

    async def _periodic_ws_ttl_refresh(self) -> None:
        """Periodically refresh TTLs on all ws keys owned by this server.

        Runs at half the WS_KEY_TTL interval to ensure keys don't expire
        while connections are still alive.
        """
        now = time.monotonic()
        # refresh at half the TTL interval
        refresh_interval = self.WS_KEY_TTL / 2.0
        if not hasattr(self, "_last_ws_ttl_refresh"):
            self._last_ws_ttl_refresh = 0.0
        if now - self._last_ws_ttl_refresh < refresh_interval:
            return

        self._last_ws_ttl_refresh = now
        try:
            await self.ws_refresh_all_ttls()
        except Exception:
            # best-effort
            pass

    async def unsubscribe(self) -> None:
        """
        unsubscribe from the redis pubsub channel
        """
        async with self._pubsub_lock:
            task = self._subscriber_task
            pubsub = self._pubsub
            channels = self._pubsub_channels()

            self._subscriber_task = None
            self._subscriber_callback = None
            self._pubsub = None

        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        if not pubsub:
            MutyLogger.get_instance().debug(
                "unsubscribe requested with no active pubsub, server_id=%s",
                self.server_id,
            )
            return

        try:
            if self._has_active_pubsub_subscriptions(pubsub):
                await pubsub.unsubscribe(*channels)
        except Exception:
            MutyLogger.get_instance().exception("error unsubscribing pubsub channels")

        try:
            await pubsub.close()
        except Exception:
            MutyLogger.get_instance().exception(
                "error closing pubsub after unsubscribe"
            )

        MutyLogger.get_instance().info(
            "unsubscribed from channels: %s, server_id=%s",
            channels,
            self.server_id,
        )

    async def subscribe(
        self,
        callback: Callable[[dict], Any],
    ) -> None:
        """
        subscribe to the redis pubsub channel

        Args:
            callback: Async function fun(d: dict) to call with each message dict
        """
        # subscribe to main channel and client_data channel;
        async with self._pubsub_lock:
            if self._subscriber_task and self._subscriber_task.done():
                self._subscriber_task = None

            if self._subscriber_task:
                MutyLogger.get_instance().warning(
                    "subscribe requested while subscriber loop is already running, server_id=%s",
                    self.server_id,
                )
                return

            self._subscriber_callback = callback
            pubsub = self._ensure_pubsub()
            channels = self._pubsub_channels()

            if not self._has_active_pubsub_subscriptions(pubsub):
                await pubsub.subscribe(*channels)

            task = asyncio.create_task(
                self._subscriber_loop("subscriber", callback),
                name=f"gulpredis-sub-{self.server_id}",
            )
            self._subscriber_task = task

        MutyLogger.get_instance().info(
            "subscribed to channels: %s, server_id=%s",
            channels,
            self.server_id,
        )

    async def _recreate_pubsub(self) -> None:
        """Recreate pubsub connection and resubscribe after errors."""
        if GulpConfig.get_instance().prometheus_enabled():
            # update Prometheus counter for pubsub reconnects
            try:
                GulpMetrics.redis_pubsub_reconnect_total.inc()
            except Exception:
                pass

        async with self._pubsub_lock:
            if self._subscriber_callback is None:
                MutyLogger.get_instance().debug(
                    "skipping pubsub recreation because subscriber is shutting down"
                )
                return

            old_pubsub = self._pubsub
            self._pubsub = self._redis.pubsub()
            channels = self._pubsub_channels()

            try:
                if old_pubsub:
                    await old_pubsub.close()
            except Exception:
                MutyLogger.get_instance().exception(
                    "error closing pubsub before recreate"
                )

            await self._pubsub.subscribe(*channels)

        MutyLogger.get_instance().warning(
            "pubsub connection recreated and resubscribed: %s", channels
        )

    async def _subscriber_loop(
        self,
        channel_name: str,
        callback: Callable[[dict], Any],
    ) -> None:
        """
        Internal loop for processing Redis pub/sub messages from multiple channels.

        Args:
            channel_name (str): Descriptive name for logging (e.g., "subscriber")
            callback: Function to call with each message
        """
        MutyLogger.get_instance().debug(
            "starting subscriber loop for channels: %s, %s",
            _MAIN_REDIS_CHANNEL,
            _CLIENT_DATA_REDIS_CHANNEL,
        )

        try:
            backoff: float = 1.0
            while True:
                try:
                    current_task = asyncio.current_task()
                    if self._subscriber_task is not current_task:
                        MutyLogger.get_instance().debug(
                            "stopping stale subscriber loop for server_id=%s",
                            self.server_id,
                        )
                        return

                    pubsub = self._pubsub
                    if pubsub is None or not self._has_active_pubsub_subscriptions(
                        pubsub
                    ):
                        MutyLogger.get_instance().warning(
                            "subscriber loop stopping because no pubsub subscriptions are active, server_id=%s",
                            self.server_id,
                        )
                        return

                    message: dict = await pubsub.get_message(
                        ignore_subscribe_messages=True, timeout=0.25
                    )
                    if message:
                        actual_channel = message.get("channel")
                        if isinstance(actual_channel, bytes):
                            actual_channel = actual_channel.decode("utf-8")

                        try:
                            d: dict = orjson.loads(message["data"])
                            d["__redis_channel__"] = actual_channel
                            # dispatch as concurrent task to avoid head-of-line blocking
                            await self._handler_semaphore.acquire()
                            # calls _handle_pubsub_message releasing the lock in the end
                            task = asyncio.create_task(
                                self._guarded_callback(callback, d, actual_channel)
                            )
                            self._handler_tasks.add(task)
                            task.add_done_callback(self._handler_tasks.discard)
                        except Exception as ex:
                            if GulpConfig.get_instance().prometheus_enabled():
                                # update Prometheus counter for subscriber callback errors
                                try:
                                    GulpMetrics.redis_subscriber_errors_total.inc()
                                except Exception:
                                    pass
                            MutyLogger.get_instance().exception(
                                "ERROR in subscriber callback for channel %s: %s",
                                actual_channel,
                                ex,
                            )
                            # Continue processing instead of terminating the loop

                    backoff = 1.0

                    # periodically publish aggregate queue utilization for worker backpressure
                    await self._update_queue_utilization_key()

                    # periodically refresh heartbeat and ws key TTLs
                    await self._update_heartbeat()
                    await self._periodic_ws_ttl_refresh()

                except asyncio.CancelledError:
                    MutyLogger.get_instance().debug("subscriber loop cancelled")
                    raise
                except RuntimeError as ex:
                    if "pubsub connection not set" not in str(ex).lower():
                        raise

                    if self._subscriber_task is not asyncio.current_task():
                        MutyLogger.get_instance().debug(
                            "stale subscriber loop exiting after pubsub detach, server_id=%s",
                            self.server_id,
                        )
                        return

                    if self._subscriber_callback is None:
                        MutyLogger.get_instance().info(
                            "subscriber loop exiting because shutdown detached pubsub, server_id=%s",
                            self.server_id,
                        )
                        return

                    MutyLogger.get_instance().warning(
                        "redis pubsub lost its subscribed connection, recreating: %s",
                        ex,
                    )
                    try:
                        await self._recreate_pubsub()
                    except Exception:
                        MutyLogger.get_instance().exception("failed to recreate pubsub")
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2.0, 30.0)
                except (RedisConnectionError, asyncio.IncompleteReadError) as ex:
                    MutyLogger.get_instance().warning(
                        "redis pubsub connection error, will reconnect: %s", ex
                    )
                    try:
                        await self._recreate_pubsub()
                    except Exception:
                        MutyLogger.get_instance().exception("failed to recreate pubsub")
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2.0, 30.0)
                except Exception as ex:
                    MutyLogger.get_instance().exception(
                        "error in subscriber loop: %s", ex
                    )
                    await asyncio.sleep(1.0)

        except asyncio.CancelledError:
            MutyLogger.get_instance().info(
                "subscriber loop stopped for channels: %s, %s",
                _MAIN_REDIS_CHANNEL,
                _CLIENT_DATA_REDIS_CHANNEL,
            )
            # wait for in-flight handler tasks to finish
            if self._handler_tasks:
                await asyncio.gather(*self._handler_tasks, return_exceptions=True)

    async def _guarded_callback(
        self, callback: Callable[[dict], Any], d: dict, channel: str
    ) -> None:
        """Run callback under semaphore guard, releasing on completion."""
        try:
            await callback(d)
        except Exception as ex:
            if GulpConfig.get_instance().prometheus_enabled():
                # update Prometheus counter for subscriber callback errors
                try:
                    GulpMetrics.redis_subscriber_errors_total.inc()
                except Exception:
                    pass
            MutyLogger.get_instance().exception(
                "ERROR in subscriber callback for channel %s: %s",
                channel,
                ex,
            )
        finally:
            self._handler_semaphore.release()

    def task_queue_key(self) -> str:
        """Return the Redis key used for the task queue."""
        return self._task_queue_key

    async def task_enqueue(self, task: dict) -> None:
        """
        Enqueue a task onto the Redis list queue.

        Args:
            task (dict): JSON-serializable task with fields like
              {"task_type": str, "operation_id": str, "user_id": str, "ws_id": str, "req_id": str, "params": dict}
        """
        payload: bytes = orjson.dumps(task)

        # tasks must have a task_type; push only to the type-specific stream
        ttype = task.get("task_type")
        if not ttype:
            MutyLogger.get_instance().error(
                "task missing 'task_type', not enqueued: %s", task
            )
            return

        # stream key per task type
        stream_key = f"{GulpRedis.STREAM_TASK_PREFIX}:{ttype}"
        try:
            # add to stream under field 'data'
            await self._redis.xadd(
                stream_key,
                {"data": payload},
                maxlen=self.STREAM_TASK_MAXLEN,
                approximate=True,
            )
            # record known task type
            await self._redis.sadd(GulpRedis.TASK_TYPES_SET, ttype)
        except Exception:
            # best-effort: log and continue
            MutyLogger.get_instance().exception(
                "failed to push task into role-specific stream '%s'", stream_key
            )

        MutyLogger.get_instance().debug(
            "enqueued task_type=%s on %s, task=%s",
            ttype,
            stream_key,
            muty.string.make_shorter(str(task), max_len=260),
        )

    async def task_dequeue_batch(self, max_items: int) -> list[dict]:
        """
        Pop up to max_items tasks from the Redis list queue.

        Args:
            max_items (int): Maximum number of tasks to pop.

        Returns:
            list[dict]: Decoded task dicts.
        """
        items: list[dict] = []

        # determine stream keys to poll (per-type streams)
        keys: list[str] = []
        if self._instance_roles:
            for r in self._instance_roles:
                keys.append(f"{GulpRedis.STREAM_TASK_PREFIX}:{r}")
        else:
            # get all known task types from redis set
            try:
                types = await self._redis.smembers(GulpRedis.TASK_TYPES_SET)
                if types:
                    for t in types:
                        if isinstance(t, bytes):
                            t = t.decode()
                        keys.append(f"{GulpRedis.STREAM_TASK_PREFIX}:{t}")
            except Exception:
                MutyLogger.get_instance().exception(
                    "failed to read known task types from %s", GulpRedis.TASK_TYPES_SET
                )

        if not keys:
            return []

        # ensure consumer group exists for each stream
        for stream in keys:
            try:
                # create group starting from the beginning so existing entries are consumable
                await self._redis.xgroup_create(
                    stream, GulpRedis.STREAM_CONSUMER_GROUP, id="0", mkstream=True
                )
            except Exception:
                # ignore if group exists or other recoverable errors
                pass

        # build streams dict for xreadgroup: {stream: '>'}
        streams_dict = {k: ">" for k in keys}

        try:
            # read up to max_items across streams (non-blocking)
            entries = await self._redis.xreadgroup(
                GulpRedis.STREAM_CONSUMER_GROUP,
                self.server_id,
                streams=streams_dict,
                count=max_items,
                block=None,
                noack=False,
            )
        except Exception as ex:
            MutyLogger.get_instance().exception("error reading from streams: %s", ex)
            return []

        # entries: list of (stream, [(id, {field: value}), ...])
        ids_to_del: dict[str, list[str]] = {}
        for stream_name, msgs in entries:
            for msg_id, fields in msgs:
                raw = (
                    fields.get(b"data")
                    if isinstance(fields, dict)
                    else fields.get("data")
                )
                if raw is None:
                    continue
                try:
                    # raw may be bytes
                    if isinstance(raw, bytes):
                        d = orjson.loads(raw)
                    else:
                        d = orjson.loads(raw)
                    items.append(d)
                    ids_to_del.setdefault(stream_name, []).append(msg_id)
                except Exception as ex:
                    MutyLogger.get_instance().error(
                        "invalid task payload in stream %s: %s", stream_name, ex
                    )

        # acknowledge and delete read entries to emulate destructive pop semantics
        # batch xack/xdel operations in a single pipeline to reduce round trips
        if ids_to_del:
            try:
                pipe = self._redis.pipeline(transaction=False)
                for stream_name, ids in ids_to_del.items():
                    try:
                        pipe.xack(stream_name, GulpRedis.STREAM_CONSUMER_GROUP, *ids)
                        pipe.xdel(stream_name, *ids)
                    except Exception:
                        # if building pipeline entries fails for this stream, log and continue
                        MutyLogger.get_instance().exception(
                            "failed to queue xack/xdel in pipeline for %s", stream_name
                        )
                # execute all ack/del commands together
                await pipe.execute()
            except Exception:
                MutyLogger.get_instance().exception(
                    "failed to execute pipeline for xack/xdel"
                )

        return items

    async def task_pop_blocking(self, timeout: int = 5) -> Optional[dict]:
        """
        Blocking pop for a single task from the Redis list queue.

        Args:
            timeout (int): Seconds to wait before returning None if queue is empty.

        Returns:
            Optional[dict]: Decoded task dict or None if timed out.
        """
        try:
            # build stream keys to read from
            keys: list[str] = []
            if self._instance_roles:
                for r in self._instance_roles:
                    keys.append(f"{GulpRedis.STREAM_TASK_PREFIX}:{r}")
            else:
                try:
                    types = await self._redis.smembers(GulpRedis.TASK_TYPES_SET)
                    if types:
                        for t in types:
                            if isinstance(t, bytes):
                                t = t.decode()
                            keys.append(f"{GulpRedis.STREAM_TASK_PREFIX}:{t}")
                except Exception:
                    MutyLogger.get_instance().exception(
                        "failed to read known task types from %s",
                        GulpRedis.TASK_TYPES_SET,
                    )

            if not keys:
                return None

            # ensure consumer group exists for each stream
            for stream in keys:
                try:
                    # create group starting from the beginning so existing entries are consumable
                    await self._redis.xgroup_create(
                        stream, GulpRedis.STREAM_CONSUMER_GROUP, id="0", mkstream=True
                    )
                except Exception:
                    pass

            streams_dict = {k: ">" for k in keys}
            # block is in milliseconds
            block_ms = int(timeout * 1000) if timeout else 0
            res = await self._redis.xreadgroup(
                GulpRedis.STREAM_CONSUMER_GROUP,
                self.server_id,
                streams=streams_dict,
                count=1,
                block=block_ms,
                noack=False,
            )
            if not res:
                return None

            # pick first message found
            for stream_name, msgs in res:
                for msg_id, fields in msgs:
                    raw = (
                        fields.get(b"data")
                        if isinstance(fields, dict)
                        else fields.get("data")
                    )
                    try:
                        d = orjson.loads(raw)
                        # acknowledge and delete entry to emulate destructive pop
                        try:
                            # batch ack + del in a small pipeline for this single message
                            pipe = self._redis.pipeline(transaction=False)
                            pipe.xack(
                                stream_name, GulpRedis.STREAM_CONSUMER_GROUP, msg_id
                            )
                            pipe.xdel(stream_name, msg_id)
                            await pipe.execute()
                        except Exception:
                            MutyLogger.get_instance().exception(
                                "failed to xack/xdel %s %s", stream_name, msg_id
                            )

                        return d
                    except Exception as ex:
                        MutyLogger.get_instance().error(
                            "invalid task payload on XREADGROUP, skipping: %s", ex
                        )
                        continue
            return None
        except asyncio.CancelledError:
            raise
        except Exception as ex:
            MutyLogger.get_instance().exception("error in task_pop_blocking: %s", ex)
            await asyncio.sleep(0.5)
            return None

    async def task_autoclaim_stale(self) -> list[dict]:
        """
        Reclaim pending messages that have been idle longer than TASK_AUTOCLAIM_IDLE_MS
        from dead or slow consumers, using XAUTOCLAIM.

        Returns:
            list[dict]: Decoded task dicts that were reclaimed.
        """
        items: list[dict] = []

        # determine streams to check
        keys: list[str] = []
        if self._instance_roles:
            for r in self._instance_roles:
                keys.append(f"{GulpRedis.STREAM_TASK_PREFIX}:{r}")
        else:
            try:
                types = await self._redis.smembers(GulpRedis.TASK_TYPES_SET)
                if types:
                    for t in types:
                        if isinstance(t, bytes):
                            t = t.decode()
                        keys.append(f"{GulpRedis.STREAM_TASK_PREFIX}:{t}")
            except Exception:
                pass

        for stream in keys:
            try:
                # XAUTOCLAIM: claim idle messages and return them to this consumer
                # Returns (next_start_id, [(msg_id, fields), ...], [deleted_ids])
                result = await self._redis.xautoclaim(
                    stream,
                    GulpRedis.STREAM_CONSUMER_GROUP,
                    self.server_id,
                    min_idle_time=GulpRedis.TASK_AUTOCLAIM_IDLE_MS,
                    start_id="0-0",
                    count=50,
                )
                if not result or not result[1]:
                    continue

                claimed_msgs = result[1]
                ids_to_del: list = []
                for msg_id, fields in claimed_msgs:
                    if not fields:
                        # message was deleted from stream but still in PEL; skip
                        continue
                    raw = (
                        fields.get(b"data")
                        if isinstance(fields, dict)
                        else fields.get("data")
                    )
                    if raw is None:
                        ids_to_del.append(msg_id)
                        continue
                    try:
                        d = orjson.loads(raw)
                        items.append(d)
                        ids_to_del.append(msg_id)
                    except Exception:
                        MutyLogger.get_instance().error(
                            "invalid payload in autoclaimed message %s on %s",
                            msg_id,
                            stream,
                        )
                        ids_to_del.append(msg_id)

                # ack + del reclaimed messages (they'll be re-dispatched by caller)
                if ids_to_del:
                    try:
                        pipe = self._redis.pipeline(transaction=False)
                        pipe.xack(stream, GulpRedis.STREAM_CONSUMER_GROUP, *ids_to_del)
                        pipe.xdel(stream, *ids_to_del)
                        await pipe.execute()
                    except Exception:
                        MutyLogger.get_instance().exception(
                            "failed to ack/del autoclaimed messages on %s", stream
                        )

                if claimed_msgs:
                    MutyLogger.get_instance().warning(
                        "autoclaimed %d stale message(s) from stream %s (idle > %dms)",
                        len(claimed_msgs),
                        stream,
                        GulpRedis.TASK_AUTOCLAIM_IDLE_MS,
                    )

            except ResponseError as ex:
                if "NOGROUP" in str(ex):
                    pass  # group doesn't exist yet, nothing to reclaim
                else:
                    MutyLogger.get_instance().exception(
                        "error during xautoclaim on %s: %s", stream, ex
                    )
            except Exception:
                MutyLogger.get_instance().exception(
                    "error during task_autoclaim_stale on %s", stream
                )

        return items

    async def task_purge_by_filter(
        self, operation_id: str | None = None, req_id: str | None = None
    ) -> int:
        """
        Remove queued tasks matching the provided filter from the Redis list queue.

        Args:
            operation_id (str|None): If set, only remove tasks for this operation_id.
            req_id (str|None): If set, only remove tasks for this req_id.

        Returns:
            int: Number of removed tasks.
        """
        # purge matching tasks from all type-specific streams known in TASK_TYPES_SET
        removed_total: int = 0

        try:
            types = await self._redis.smembers(GulpRedis.TASK_TYPES_SET)
        except Exception:
            types = None

        if not types:
            return 0

        for t in types:
            if isinstance(t, bytes):
                t = t.decode()
            stream = f"{GulpRedis.STREAM_TASK_PREFIX}:{t}"
            try:
                entries = await self._redis.xrange(stream, min="-", max="+")
            except Exception:
                entries = None
            if not entries:
                continue

            removed: int = 0
            ids_to_del: list[str] = []
            for msg_id, fields in entries:
                raw = (
                    fields.get(b"data")
                    if isinstance(fields, dict)
                    else fields.get("data")
                )
                if raw is None:
                    continue
                try:
                    d = orjson.loads(raw)
                except Exception:
                    # skip malformed
                    continue

                cond_ok = True
                if operation_id is not None and d.get("operation_id") != operation_id:
                    cond_ok = False
                if req_id is not None and d.get("req_id") != req_id:
                    cond_ok = False

                if cond_ok:
                    ids_to_del.append(msg_id)
                    removed += 1

            if ids_to_del:
                try:
                    await self._redis.xdel(stream, *ids_to_del)
                    MutyLogger.get_instance().debug(
                        "purged %d task(s) from %s", removed, stream
                    )
                    removed_total += removed
                except Exception:
                    MutyLogger.get_instance().exception(
                        "failed to xdel ids on %s", stream
                    )

        return removed_total

    async def cleanup_redis(self) -> int:
        """
        Destroy all keys under the `gulp:*` namespace used by this application.

        Returns:
            int: Number of keys removed.
        """
        total_deleted = 0
        cursor = 0
        pattern = "gulp:*"
        try:
            # iterate over keys matching the gulp prefix and delete them in batches
            while True:
                cursor, keys = await self._redis.scan(
                    cursor=cursor, match=pattern, count=200
                )
                if keys:
                    try:
                        # redis.delete accepts varargs of keys
                        deleted = await self._redis.delete(*keys)
                        if isinstance(deleted, int):
                            total_deleted += deleted
                    except Exception:
                        MutyLogger.get_instance().exception(
                            "failed to delete key batch during cleanup"
                        )
                if cursor == 0:
                    break
        except Exception:
            MutyLogger.get_instance().exception(
                "error during cleanup_redis scan/delete"
            )

        MutyLogger.get_instance().info("cleanup_redis removed %d keys", total_deleted)
        return total_deleted

    async def cleanup_consumers_for_server(self, server_id: str) -> None:
        """
        Remove this server's consumer entries from all task streams' consumer groups.

        For each known task-type stream, attempt to remove the consumer named
        `server_id` from the `STREAM_CONSUMER_GROUP`.

        Args:
            server_id (str): The server instance ID whose consumers should be removed.
        """
        try:
            types = await self._redis.smembers(GulpRedis.TASK_TYPES_SET)
        except Exception:
            types = None

        if not types:
            return

        for t in types:
            if isinstance(t, bytes):
                t = t.decode()
            stream = f"{GulpRedis.STREAM_TASK_PREFIX}:{t}"
            try:
                # remove this consumer from the group; returns number of pending messages
                try:
                    await self._redis.xgroup_delconsumer(
                        stream, GulpRedis.STREAM_CONSUMER_GROUP, server_id
                    )
                except Exception:
                    # ignore failures (group may not exist yet)
                    pass

                # inspect group info: if group exists and has zero consumers and zero pending,
                # destroy the group and cleanup stream
                try:
                    groups = await self._redis.xinfo_groups(stream)
                except Exception:
                    groups = None

                if groups:
                    for g in groups:
                        # g is a dict-like mapping returned by redis-py
                        name = (
                            g.get(b"name")
                            if isinstance(g, dict) and b"name" in g
                            else g.get("name")
                        )
                        if (
                            name
                            and (name.decode() if isinstance(name, bytes) else name)
                            == GulpRedis.STREAM_CONSUMER_GROUP
                        ):
                            consumers = (
                                g.get(b"consumers")
                                if isinstance(g, dict) and b"consumers" in g
                                else g.get("consumers")
                            )
                            pending = (
                                g.get(b"pending")
                                if isinstance(g, dict) and b"pending" in g
                                else g.get("pending")
                            )
                            try:
                                consumers = int(consumers)
                            except Exception:
                                consumers = 0
                            try:
                                pending = int(pending)
                            except Exception:
                                pending = 0

                            if consumers == 0 and pending == 0:
                                try:
                                    await self._redis.xgroup_destroy(
                                        stream, GulpRedis.STREAM_CONSUMER_GROUP
                                    )
                                except Exception:
                                    pass
                            break
            except Exception:
                MutyLogger.get_instance().exception(
                    "error cleaning consumer for stream %s", stream
                )
