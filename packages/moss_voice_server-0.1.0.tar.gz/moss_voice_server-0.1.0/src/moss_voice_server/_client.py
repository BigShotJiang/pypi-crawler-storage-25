"""Async ``MossVoiceServer`` — mints LiveKit JWTs from Moss-issued credentials."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Optional
from urllib.parse import quote

import httpx
from livekit.api import AccessToken, RoomAgentDispatch, RoomConfiguration, VideoGrants

DEFAULT_API_URL = "https://service.usemoss.dev"
_CREDENTIALS_PATH = "/api/voice-agent/get-voice-agent"
_TOKEN_TTL = timedelta(minutes=15)
_FETCH_TIMEOUT_SECONDS = 10.0
_CREDENTIAL_FIELDS = (
    "voice_agent_url",
    "voice_agent_api_key",
    "voice_agent_api_secret",
    "voice_agent_name",
)


@dataclass(frozen=True)
class ParticipantInfo:
    """Identity and optional metadata for the participant the token is minted for."""

    identity: str
    name: Optional[str] = None
    metadata: Optional[str] = None
    attributes: Optional[dict[str, str]] = field(default=None)


@dataclass(frozen=True)
class _Credentials:
    voice_agent_url: str
    voice_agent_api_key: str
    voice_agent_api_secret: str
    voice_agent_name: str


class _MossVoiceServerBase:
    """Shared sync surface for both async and sync flavors of the server.

    Subclasses are responsible for populating ``self._credentials`` via either
    an async or sync fetch implementation. Everything else — validation,
    request URL building, token minting — is sync and lives here.
    """

    def __init__(
        self,
        project_id: str,
        project_key: str,
        voice_agent_id: str,
        api_url: str = DEFAULT_API_URL,
    ) -> None:
        if not project_id or not project_key or not voice_agent_id:
            raise ValueError("project_id, project_key, and voice_agent_id are required")
        self._project_id = project_id
        self._project_key = project_key
        self._voice_agent_id = voice_agent_id
        self._api_url = api_url.rstrip("/")
        self._credentials: Optional[_Credentials] = None

    def get_server_url(self) -> str:
        """LiveKit WebSocket URL the client should connect to."""
        return self._require_credentials().voice_agent_url

    def get_agent_name(self) -> str:
        """Configured voice agent name."""
        return self._require_credentials().voice_agent_name

    def create_participant_token(
        self,
        participant: ParticipantInfo,
        room_name: str,
        agent_name: Optional[str] = None,
    ) -> str:
        """Mint a signed LiveKit JWT for a participant joining ``room_name``.

        The token is valid for 15 minutes. Pass ``agent_name`` only to override
        the default agent; otherwise LiveKit dispatch rules handle agent joining.
        """
        creds = self._require_credentials()

        token = (
            AccessToken(creds.voice_agent_api_key, creds.voice_agent_api_secret)
            .with_identity(participant.identity)
            .with_ttl(_TOKEN_TTL)
            .with_grants(
                VideoGrants(
                    room=room_name,
                    room_join=True,
                    can_publish=True,
                    can_publish_data=True,
                    can_subscribe=True,
                )
            )
        )
        if participant.name is not None:
            token = token.with_name(participant.name)
        if participant.metadata is not None:
            token = token.with_metadata(participant.metadata)
        if participant.attributes is not None:
            token = token.with_attributes(participant.attributes)

        if agent_name:
            token = token.with_room_config(
                RoomConfiguration(agents=[RoomAgentDispatch(agent_name=agent_name)])
            )

        return token.to_jwt()

    def _credentials_endpoint(self) -> str:
        return f"{self._api_url}{_CREDENTIALS_PATH}?voice_agent_id={quote(self._voice_agent_id)}"

    def _auth_headers(self) -> dict[str, str]:
        return {
            "X-Project-Id": self._project_id,
            "X-Project-Key": self._project_key,
        }

    def _require_credentials(self) -> _Credentials:
        if self._credentials is None:
            raise RuntimeError(
                f"{type(self).__name__} not initialized — call {type(self).__name__}.create()"
            )
        return self._credentials


class MossVoiceServer(_MossVoiceServerBase):
    """Backend client that mints LiveKit participant tokens for voice agents.

    Fetch credentials once at app startup via :meth:`create`, then mint per-user
    tokens on demand. Credentials never leave the server.

    Example::

        server = await MossVoiceServer.create(
            project_id=os.environ["MOSS_PROJECT_ID"],
            project_key=os.environ["MOSS_PROJECT_KEY"],
            voice_agent_id=os.environ["MOSS_VOICE_AGENT_ID"],
        )

        url = server.get_server_url()
        token = server.create_participant_token(
            ParticipantInfo(identity="user_123", name="John"),
            room_name="support_room_456",
        )
    """

    @classmethod
    async def create(
        cls,
        project_id: str,
        project_key: str,
        voice_agent_id: str,
        api_url: str = DEFAULT_API_URL,
    ) -> "MossVoiceServer":
        """Create and initialize a server instance by fetching credentials."""
        instance = cls(project_id, project_key, voice_agent_id, api_url)
        await instance._initialize()
        return instance

    async def _initialize(self) -> None:
        try:
            async with httpx.AsyncClient(timeout=_FETCH_TIMEOUT_SECONDS) as client:
                response = await client.get(
                    self._credentials_endpoint(),
                    headers=self._auth_headers(),
                )
                self._credentials = _parse_credentials_response(response)
        except httpx.TimeoutException as exc:
            raise RuntimeError(
                "Failed to initialize MossVoiceServer: request timed out after 10 seconds"
            ) from exc
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Failed to initialize MossVoiceServer: {exc}") from exc


def _parse_credentials_response(response: httpx.Response) -> _Credentials:
    if response.status_code >= 400:
        raise RuntimeError(
            f"Failed to fetch credentials: {response.status_code} {response.text}"
        )
    try:
        data = response.json()
    except ValueError as exc:
        raise RuntimeError(
            f"Moss API returned non-JSON response: {response.text!r}"
        ) from exc
    if not isinstance(data, dict):
        raise RuntimeError(f"Moss API returned unexpected response shape: {data!r}")
    missing = [field for field in _CREDENTIAL_FIELDS if field not in data]
    if missing:
        raise RuntimeError(
            f"Moss API response missing field(s): {', '.join(missing)}"
        )
    return _Credentials(
        voice_agent_url=data["voice_agent_url"],
        voice_agent_api_key=data["voice_agent_api_key"],
        voice_agent_api_secret=data["voice_agent_api_secret"],
        voice_agent_name=data["voice_agent_name"],
    )
