"""Sync wrapper for ``MossVoiceServer`` — for Flask, Django, and other sync frameworks."""

from __future__ import annotations

import httpx

from ._client import (
    DEFAULT_API_URL,
    ParticipantInfo,
    _FETCH_TIMEOUT_SECONDS,
    _MossVoiceServerBase,
    _parse_credentials_response,
)


class MossVoiceServerSync(_MossVoiceServerBase):
    """Sync flavor of :class:`MossVoiceServer`.

    Initialization performs a single blocking HTTP request. After that, token
    minting is purely CPU work (JWT signing).

    Example::

        server = MossVoiceServerSync.create(
            project_id=os.environ["MOSS_PROJECT_ID"],
            project_key=os.environ["MOSS_PROJECT_KEY"],
            voice_agent_id=os.environ["MOSS_VOICE_AGENT_ID"],
        )

        token = server.create_participant_token(
            ParticipantInfo(identity="user_123"),
            room_name="support_room_456",
        )
    """

    @classmethod
    def create(
        cls,
        project_id: str,
        project_key: str,
        voice_agent_id: str,
        api_url: str = DEFAULT_API_URL,
    ) -> "MossVoiceServerSync":
        instance = cls(project_id, project_key, voice_agent_id, api_url)
        instance._initialize_sync()
        return instance

    def _initialize_sync(self) -> None:
        try:
            with httpx.Client(timeout=_FETCH_TIMEOUT_SECONDS) as client:
                response = client.get(
                    self._credentials_endpoint(),
                    headers=self._auth_headers(),
                )
                self._credentials = _parse_credentials_response(response)
        except httpx.TimeoutException as exc:
            raise RuntimeError(
                "Failed to initialize MossVoiceServerSync: request timed out after 10 seconds"
            ) from exc
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Failed to initialize MossVoiceServerSync: {exc}") from exc


__all__ = ["MossVoiceServerSync", "ParticipantInfo"]
