"""Smoke tests for the public API surface.

Integration tests against the live Moss API require real credentials and are
not run here. The token-minting logic is covered by a fake-response unit test.
"""

from __future__ import annotations

import json

import httpx
import pytest

import moss_voice_server
from moss_voice_server import MossVoiceServer, MossVoiceServerSync, ParticipantInfo


def test_public_api_exports() -> None:
    assert sorted(moss_voice_server.__all__) == [
        "MossVoiceServer",
        "MossVoiceServerSync",
        "ParticipantInfo",
    ]


def test_required_args_validation() -> None:
    with pytest.raises(ValueError):
        MossVoiceServer(project_id="", project_key="k", voice_agent_id="v")
    with pytest.raises(ValueError):
        MossVoiceServerSync(project_id="p", project_key="", voice_agent_id="v")


def test_missing_credential_field_raises_descriptive_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Response missing voice_agent_api_secret
    bad_response = {
        "voice_agent_url": "wss://example.livekit.cloud",
        "voice_agent_api_key": "APItest",
        "voice_agent_name": "moss-agent",
    }

    transport = httpx.MockTransport(lambda _: httpx.Response(200, json=bad_response))
    original_client = httpx.Client

    def patched_client(*args: object, **kwargs: object) -> httpx.Client:
        kwargs["transport"] = transport
        return original_client(*args, **kwargs)  # type: ignore[arg-type]

    monkeypatch.setattr(httpx, "Client", patched_client)

    with pytest.raises(RuntimeError, match="voice_agent_api_secret"):
        MossVoiceServerSync.create(project_id="p", project_key="k", voice_agent_id="v")


def test_sync_class_does_not_expose_async_create() -> None:
    # MossVoiceServerSync.create must be a plain sync classmethod — not async.
    import inspect

    assert not inspect.iscoroutinefunction(MossVoiceServerSync.create)


def test_create_participant_token_signs_jwt(monkeypatch: pytest.MonkeyPatch) -> None:
    fake_creds = {
        "voice_agent_url": "wss://example.livekit.cloud",
        "voice_agent_api_key": "APItest",
        "voice_agent_api_secret": "secret_value_long_enough_for_hmac",
        "voice_agent_name": "moss-agent",
    }

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["X-Project-Id"] == "p"
        assert request.headers["X-Project-Key"] == "k"
        assert "voice_agent_id=v" in str(request.url)
        return httpx.Response(200, json=fake_creds)

    transport = httpx.MockTransport(handler)

    # Patch httpx.Client to use the mock transport (sync path)
    original_client = httpx.Client

    def patched_client(*args: object, **kwargs: object) -> httpx.Client:
        kwargs["transport"] = transport
        return original_client(*args, **kwargs)  # type: ignore[arg-type]

    monkeypatch.setattr(httpx, "Client", patched_client)

    server = MossVoiceServerSync.create(project_id="p", project_key="k", voice_agent_id="v")

    assert server.get_server_url() == "wss://example.livekit.cloud"
    assert server.get_agent_name() == "moss-agent"

    token = server.create_participant_token(
        ParticipantInfo(identity="user_123", name="Jane"),
        room_name="room_abc",
    )

    assert isinstance(token, str)
    # JWT is three base64url segments separated by dots
    assert token.count(".") == 2

    # Decode payload (middle segment) — base64url, no padding
    import base64

    payload_segment = token.split(".")[1]
    payload_segment += "=" * (-len(payload_segment) % 4)
    payload = json.loads(base64.urlsafe_b64decode(payload_segment))
    assert payload["sub"] == "user_123"
    assert payload["name"] == "Jane"
    assert payload["video"]["room"] == "room_abc"
    assert payload["video"]["roomJoin"] is True
