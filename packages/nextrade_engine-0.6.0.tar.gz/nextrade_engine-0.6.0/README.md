# NexTrade 🧠

**AI Trading Engine — Ringan, Multi-Market, Bisa di HP**

NexTrade adalah library Python untuk trading AI yang dirancang seperti cara trader manusia berpikir. Ringan, cepat, dan bisa jalan di HP sekalipun.

## Instalasi

```bash
pip install nextrade
```

## Cara Pakai

```python
import nextrade

# Sinyal trading real time
nextrade.start("momentum", market="BTCUSD")
nextrade.start("adaptive", market="EURUSD", timeframe="H4")

# Scan banyak market sekaligus
nextrade.scan(["BTCUSD", "EURUSD", "XAUUSD", "AAPL"])

# Backtest strategi
nextrade.backtest("momentum", market="BTCUSD", timeframe="D1")

# Latih AI brain
nextrade.train("hybrid", market="BTCUSD")

# Status otak AI
nextrade.brain_status()

# Set agresivitas sinyal
nextrade.set_agresivitas(20)  # konservatif
nextrade.set_agresivitas(80)  # agresif
```

## Fitur

- **Multi-Market** — Forex, Crypto, Saham, Indeks
- **AI Brain** — IQ model, neuron aktif, 3 mode learning
- **Backtest Engine** — test jutaan bar, ringan di HP
- **Market Scanner** — scan banyak market sekaligus
- **Adaptive Indicators** — indikator yang menyesuaikan kondisi pasar
- **Terminal Wizard** — panduan otomatis muncul saat import

## Market Tersedia

**Forex:** EURUSD, GBPUSD, USDJPY, XAUUSD (Gold), dan lainnya

**Crypto:** BTCUSD, ETHUSD, BNBUSD, SOLUSD, dan lainnya

**Saham:** AAPL, TSLA, GOOGL, NVDA, BBCA, BBRI, dan lainnya

**Indeks:** SPX500, NASDAQ, IHSG, NIKKEI

## Timeframe

M1 · M5 · M15 · M30 · H1 · H4 · D1 · W1

## Requirements

- Python 3.8+
- numpy
- yfinance

## License

MIT License
