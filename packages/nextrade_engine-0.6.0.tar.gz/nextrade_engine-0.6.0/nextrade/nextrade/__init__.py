"""
NexTrade — AI Trading Engine
import nextrade  →  wizard muncul otomatis di terminal
"""

from nextrade.lang import set_language, list_languages, get, current as _lang
from nextrade.utils.terminal_ui import (
    print_welcome, print_signal, print_error,
    print_loading, print_success, list_strategies, STRATEGIES
)
from nextrade.indicators.confluence import confluence_score
from nextrade.core.regime import detect_regime
from nextrade.core.brain import Brain
from nextrade.data.fetcher import fetch, fetch_multi, list_markets
import numpy as np

__version__ = "0.6.0"
__author__  = "NexTrade"

# Tampilkan wizard saat pertama kali import
print_welcome()

# Instance brain global
_brain = Brain.__new__(Brain)
_brain.state = None

def _get_brain():
    global _brain
    if _brain.state is None:
        _brain = Brain()
    return _brain

# ─────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────

def start(strategy: str = "adaptive",
          market: str = "BTCUSD",
          timeframe: str = "H1",
          data: dict = None):
    """
    Jalankan NexTrade dengan strategi pilihan.

    Contoh:
        nextrade.start("momentum", market="BTCUSD")
        nextrade.start("reversal", market="EURUSD", timeframe="H4")
    """
    strategy = strategy.lower().strip()

    if strategy not in STRATEGIES:
        print_error(f"{get('error_strategy')}: {', '.join(STRATEGIES)}")
        list_strategies()
        return

    print_loading(f"{get('loading_strategy')} {strategy.upper()}...")

    if data is None:
        data = fetch(market, timeframe, bars=500)
        if data is None:
            print_error(get('error_data'))
            return

    print_loading(f"{get('loading_indicators')}...")

    result = confluence_score(
        opens  = data["open"],
        highs  = data["high"],
        lows   = data["low"],
        closes = data["close"],
    )

    brain      = _get_brain()
    threshold  = brain.get_confidence_threshold()
    confidence = result["confidence"]

    if confidence >= threshold and result["details"]["pattern"]["direction"] != "bear":
        signal = "BUY"
    elif confidence <= (100 - threshold) or result["details"]["pattern"]["direction"] == "bear":
        signal = "SELL"
    else:
        signal = "HOLD"

    print_signal(signal=signal, confidence=confidence,
                 strategy=strategy, market=market)

    regime = result["details"]["regime"]["regime"]
    rsi    = result["details"]["rsi"]
    mom    = result["details"]["momentum"]
    price  = data["price_now"]

    print(f"  \033[2m{get('detail_analysis')}:\033[0m")
    print(f"  \033[36m{get('price_now'):<18}:\033[0m  {price:,.5f}")
    print(f"  \033[36m{get('market_condition'):<18}:\033[0m  {get(regime)}")
    print(f"  \033[36mRSI Adaptif       :\033[0m  {rsi:.1f}")
    print(f"  \033[36m{get('iq_model'):<18}:\033[0m  {brain.state['iq']} / 100")
    print(f"  \033[36m{get('agresivitas'):<18}:\033[0m  {brain.state['agresivitas']}%")
    print()

    return {**result, "signal": signal, "market": market,
            "price": price, "strategy": strategy}


def train(mode: str = "hybrid", market: str = "BTCUSD",
          timeframe: str = "D1", bars: int = 1000):
    """Latih brain NexTrade dengan data real market."""
    print(f"\n  \033[1m\033[37m Training NexTrade Brain\033[0m")
    print(f"  \033[36m{'─' * 40}\033[0m")
    data = fetch(market, timeframe, bars=bars)
    if data is None:
        print_error(get('error_data'))
        return
    _get_brain().train(mode=mode, data=data)


def brain_status():
    """Tampilkan status otak NexTrade."""
    _get_brain().status()


def set_agresivitas(pct: int):
    """Set agresivitas sinyal (0-100)."""
    _get_brain().set_agresivitas(pct)


def scan(markets: list = None, timeframe: str = "H1"):
    """Scan banyak market sekaligus."""
    if markets is None:
        markets = ["BTCUSD", "EURUSD", "XAUUSD", "AAPL", "TSLA"]

    print(f"\n  \033[1m\033[37m NexTrade Market Scanner\033[0m")
    print(f"  \033[36m{'─' * 55}\033[0m")
    print(f"  \033[2m{'MARKET':<12} {'HARGA':>14} {get('signal'):>8} "
          f"{'CONFIDENCE':>12} {get('market_condition')}\033[0m")
    print(f"  \033[36m{'─' * 55}\033[0m")

    results = []
    for market in markets:
        data = fetch(market, timeframe, bars=300, silent=True)
        if data is None: continue
        result = confluence_score(
            opens=data["open"], highs=data["high"],
            lows=data["low"],   closes=data["close"],
        )
        signal     = result["signal"]
        confidence = result["confidence"]
        regime     = result["details"]["regime"]["regime"]
        price      = data["price_now"]
        sc = "\033[32m" if signal=="BUY" else "\033[31m" if signal=="SELL" else "\033[33m"
        print(f"  {market:<12} {price:>14,.5f} {sc}{signal:>8}\033[0m "
              f"{confidence:>10.1f}%  \033[2m{regime}\033[0m")
        results.append({**result, "market": market, "price": price})

    print(f"  \033[36m{'─' * 55}\033[0m\n")
    buys  = [r for r in results if r["signal"]=="BUY"]
    sells = [r for r in results if r["signal"]=="SELL"]
    if buys:
        best = max(buys,  key=lambda x: x["confidence"])
        print(f"  \033[32m★  BUY  : {best['market']} ({best['confidence']:.1f}%)\033[0m")
    if sells:
        best = max(sells, key=lambda x: x["confidence"])
        print(f"  \033[31m★  SELL : {best['market']} ({best['confidence']:.1f}%)\033[0m")
    print()
    return results


def backtest(strategy: str = "adaptive", market: str = "BTCUSD",
             timeframe: str = "D1", bars: int = 500,
             agresivitas: int = 30, sl_pct: float = 2.0, tp_pct: float = 4.0):
    """Backtest strategi dengan data real historis."""
    from nextrade.backtest.engine import run as _run
    data = fetch(market, timeframe, bars=bars)
    if data is None:
        print_error(get('error_data'))
        return
    return _run(data=data, strategy=strategy, agresivitas=agresivitas,
                sl_pct=sl_pct, tp_pct=tp_pct)


def info():
    """Tampilkan semua strategi dan market."""
    list_strategies()
    list_markets()


def regime(market: str = "BTCUSD", timeframe: str = "H1") -> dict:
    """Deteksi kondisi pasar saat ini."""
    data = fetch(market, timeframe, bars=100, silent=True)
    if data is None: return {}
    return detect_regime(data["close"])


def language():
    """Tampilkan semua bahasa yang tersedia."""
    list_languages()