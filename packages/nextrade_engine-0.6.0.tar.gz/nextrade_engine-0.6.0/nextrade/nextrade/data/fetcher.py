"""
NexTrade — Data Fetcher
Ambil data real market gratis tanpa API key.
Support: Forex, Crypto, Saham, Indeks
"""

import numpy as np
from datetime import datetime

# Market symbols yang tersedia
MARKETS = {
    "forex": {
        "EURUSD" : "EURUSD=X",
        "GBPUSD" : "GBPUSD=X",
        "USDJPY" : "USDJPY=X",
        "AUDUSD" : "AUDUSD=X",
        "USDCAD" : "USDCAD=X",
        "XAUUSD" : "GC=F",      # Gold
        "XAGUSD" : "SI=F",      # Silver
    },
    "crypto": {
        "BTCUSD" : "BTC-USD",
        "ETHUSD" : "ETH-USD",
        "BNBUSD" : "BNB-USD",
        "SOLUSD" : "SOL-USD",
        "XRPUSD" : "XRP-USD",
        "DOGEUSD": "DOGE-USD",
    },
    "saham": {
        "AAPL"   : "AAPL",
        "TSLA"   : "TSLA",
        "GOOGL"  : "GOOGL",
        "MSFT"   : "MSFT",
        "NVDA"   : "NVDA",
        "BBCA"   : "BBCA.JK",   # BCA Indonesia
        "BBRI"   : "BBRI.JK",   # BRI Indonesia
        "TLKM"   : "TLKM.JK",   # Telkom Indonesia
    },
    "indeks": {
        "SPX500" : "^GSPC",
        "NASDAQ" : "^IXIC",
        "IHSG"   : "^JKSE",
        "NIKKEI" : "^N225",
    }
}

TIMEFRAMES = {
    "M1"  : ("1d",  "1m"),
    "M5"  : ("5d",  "5m"),
    "M15" : ("5d",  "15m"),
    "M30" : ("1mo", "30m"),
    "H1"  : ("1mo", "1h"),
    "H4"  : ("3mo", "4h"),
    "D1"  : ("1y",  "1d"),
    "W1"  : ("2y",  "1wk"),
}

def _get_symbol(market: str) -> str:
    """Cari ticker Yahoo Finance dari nama market."""
    market = market.upper().replace("/", "")
    for category in MARKETS.values():
        if market in category:
            return category[market]
    # Kalau tidak ketemu, coba langsung pakai sebagai ticker
    return market

def fetch(market: str = "BTCUSD", timeframe: str = "H1",
          bars: int = 500, silent: bool = False) -> dict:
    """
    Ambil data OHLCV dari market manapun.

    Contoh:
        data = fetch("BTCUSD", "H1")
        data = fetch("EURUSD", "M15", bars=200)
        data = fetch("AAPL", "D1")

    Returns dict: { open, high, low, close, volume, symbol, timeframe, bars }
    """
    try:
        import yfinance as yf
    except ImportError:
        _print_error("yfinance belum terinstall. Jalankan: pip install yfinance")
        return None

    symbol = _get_symbol(market)
    tf_config = TIMEFRAMES.get(timeframe.upper(), ("1mo", "1h"))
    period, interval = tf_config

    if not silent:
        _print_loading(f"Mengambil data {market} ({timeframe}) dari market...")

    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=period, interval=interval)

        if df.empty:
            if not silent:
                _print_error(f"Data kosong untuk {market}. Cek nama market.")
            return None

        # Ambil N bars terakhir
        df = df.tail(bars)

        result = {
            "open"      : np.array(df["Open"].values,   dtype=float),
            "high"      : np.array(df["High"].values,   dtype=float),
            "low"       : np.array(df["Low"].values,    dtype=float),
            "close"     : np.array(df["Close"].values,  dtype=float),
            "volume"    : np.array(df["Volume"].values, dtype=float),
            "symbol"    : market,
            "timeframe" : timeframe,
            "bars"      : len(df),
            "from"      : str(df.index[0])[:10],
            "to"        : str(df.index[-1])[:10],
            "price_now" : round(float(df["Close"].iloc[-1]), 5),
        }

        if not silent:
            _print_success(result)

        return result

    except Exception as e:
        if not silent:
            _print_error(f"Gagal ambil data: {str(e)}")
        return None

def fetch_multi(markets: list, timeframe: str = "H1") -> dict:
    """
    Ambil data beberapa market sekaligus.

    Contoh:
        data = fetch_multi(["BTCUSD", "EURUSD", "AAPL"], "H1")
    """
    results = {}
    print(f"\n  \033[36m⠿\033[0m  Mengambil {len(markets)} market...\n")
    for market in markets:
        data = fetch(market, timeframe, silent=True)
        if data:
            results[market] = data
            print(f"  \033[32m✓\033[0m  {market:<10} {data['price_now']:>12.5f}  "
                  f"\033[2m{data['bars']} bars  {data['from']} → {data['to']}\033[0m")
        else:
            print(f"  \033[31m✗\033[0m  {market:<10} gagal diambil")
    print()
    return results

def list_markets():
    """Tampilkan semua market yang tersedia."""
    print(f"\n  \033[1m\033[37m  Market tersedia di NexTrade:\033[0m\n")
    for category, symbols in MARKETS.items():
        print(f"  \033[36m\033[1m{category.upper()}\033[0m")
        for name in symbols:
            print(f"    \033[33m{name}\033[0m")
        print()
    print(f"  \033[1mTimeframe:\033[0m  M1 M5 M15 M30 H1 H4 D1 W1\n")

# ─── Internal helpers ───────────────────

def _print_loading(text: str):
    print(f"\n  \033[36m⠿\033[0m  {text}")

def _print_success(data: dict):
    print(f"  \033[32m✓\033[0m  Data berhasil diambil!")
    print(f"\n  \033[36m{'─' * 48}\033[0m")
    print(f"  \033[1mMarket    :\033[0m  {data['symbol']}  ({data['timeframe']})")
    print(f"  \033[1mHarga Now :\033[0m  \033[33m{data['price_now']:,.5f}\033[0m")
    print(f"  \033[1mTotal Bars:\033[0m  {data['bars']:,} candle")
    print(f"  \033[1mPeriode   :\033[0m  {data['from']}  →  {data['to']}")
    print(f"  \033[36m{'─' * 48}\033[0m\n")

def _print_error(msg: str):
    print(f"\n  \033[31m✗\033[0m  {msg}\n")
