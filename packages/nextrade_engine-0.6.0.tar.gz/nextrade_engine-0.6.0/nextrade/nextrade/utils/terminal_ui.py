"""
NexTrade — Terminal UI
Semua tampilan, warna, dan wizard di terminal.
Support multi-bahasa via lang.py
"""
import sys
import time
from nextrade.lang import get, current

class Color:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RED    = "\033[31m"
    GREEN  = "\033[32m"
    YELLOW = "\033[33m"
    CYAN   = "\033[36m"
    WHITE  = "\033[37m"

C = Color()

STRATEGIES = ["momentum", "reversal", "scalping", "swing", "adaptive"]

SEP  = "─" * 68
SEP2 = "─" * 50

def print_banner():
    print(f"""
{C.CYAN}{C.BOLD}
 ███╗   ██╗███████╗██╗  ██╗████████╗██████╗  █████╗ ██████╗ ███████╗
 ████╗  ██║██╔════╝╚██╗██╔╝╚══██╔══╝██╔══██╗██╔══██╗██╔══██╗██╔════╝
 ██╔██╗ ██║█████╗   ╚███╔╝    ██║   ██████╔╝███████║██║  ██║█████╗
 ██║╚██╗██║██╔══╝   ██╔██╗    ██║   ██╔══██╗██╔══██║██║  ██║██╔══╝
 ██║ ╚████║███████╗██╔╝ ██╗   ██║   ██║  ██║██║  ██║██████╔╝███████╗
 ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝
{C.RESET}{C.DIM}  AI Trading Engine · Ringan · Multi-Market · Bisa di HP{C.RESET}
{C.CYAN}{SEP}{C.RESET}""")

def print_welcome():
    print_banner()
    print(f"{C.BOLD}{C.WHITE}  {get('welcome_title')}{C.RESET}")
    print(f"{C.DIM}  {get('welcome_sub')}{C.RESET}\n")
    print(f"{C.CYAN}  ┌─ {get('strategies_title')} ──────────────────────────────┐{C.RESET}")
    for i, name in enumerate(STRATEGIES, 1):
        desc = get(name)
        print(f"{C.CYAN}  │{C.RESET}  {C.BOLD}{C.YELLOW}{i}. {name:<12}{C.RESET} {C.DIM}-> {desc}{C.RESET}")
    print(f"{C.CYAN}  └─────────────────────────────────────────────────────┘{C.RESET}\n")
    print(f"  {C.DIM}{get('how_to_start')}:{C.RESET}")
    print(f"  {C.GREEN}nextrade.start(\"momentum\"){C.RESET}   {C.DIM}# {get('cmd_start')}{C.RESET}")
    print(f"  {C.GREEN}nextrade.backtest(\"momentum\"){C.RESET} {C.DIM}# {get('cmd_backtest')}{C.RESET}")
    print(f"  {C.GREEN}nextrade.info(){C.RESET}               {C.DIM}# {get('cmd_info')}{C.RESET}\n")

def print_loading(text: str, delay: float = 0.03):
    steps = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
    for i in range(15):
        sys.stdout.write(f"\r  {C.CYAN}{steps[i % len(steps)]}{C.RESET}  {text}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write(f"\r  {C.GREEN}✓{C.RESET}  {text}\n")
    sys.stdout.flush()

def print_signal(signal: str, confidence: float,
                 strategy: str, market: str = ""):
    color = C.GREEN if signal == "BUY" else C.RED if signal == "SELL" else C.YELLOW
    bar_len = int(confidence / 5)
    bar = "█" * bar_len + "░" * (20 - bar_len)
    print(f"\n{C.CYAN}{SEP2}{C.RESET}")
    print(f"  {C.BOLD}{get('strategy'):<14}:{C.RESET} {strategy}")
    if market:
        print(f"  {C.BOLD}{get('market'):<14}:{C.RESET} {market}")
    print(f"  {C.BOLD}{get('signal'):<14}:{C.RESET} {color}{C.BOLD} {signal} {C.RESET}")
    print(f"  {C.BOLD}{get('confidence'):<14}:{C.RESET} {color}{bar}{C.RESET} {confidence:.1f}%")
    print(f"{C.CYAN}{SEP2}{C.RESET}\n")

def print_error(msg: str):
    print(f"\n  {C.RED}✗  {C.RESET}{msg}\n")

def print_success(msg: str):
    print(f"  {C.GREEN}✓{C.RESET}  {msg}")

def list_strategies():
    print(f"\n{C.BOLD}{C.WHITE}  {get('strategies_title')}:{C.RESET}\n")
    for name in STRATEGIES:
        print(f"  {C.YELLOW}{C.BOLD}{name:<14}{C.RESET} {get(name)}")
    print()