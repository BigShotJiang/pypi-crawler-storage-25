"""
NexTrade — Language System
Support: Indonesia (id), English (en), Melayu (my), Arab (ar)
"""

LANGUAGES = {
    "id": "Indonesia",
    "en": "English", 
    "my": "Melayu",
    "ar": "العربية",
}

TRANSLATIONS = {

    # ── WELCOME ───────────────────────────────────────────
    "welcome_title": {
        "id": "Selamat datang di NexTrade!",
        "en": "Welcome to NexTrade!",
        "my": "Selamat datang ke NexTrade!",
        "ar": "!مرحباً بك في NexTrade",
    },
    "welcome_sub": {
        "id": "Engine AI trading ringan yang bisa jalan di HP sekalipun.",
        "en": "Lightweight AI trading engine that runs even on mobile.",
        "my": "Enjin dagangan AI ringan yang boleh berjalan di telefon.",
        "ar": ".محرك تداول ذكاء اصطناعي خفيف يعمل حتى على الهاتف",
    },
    "strategies_title": {
        "id": "Strategi tersedia",
        "en": "Available strategies",
        "my": "Strategi tersedia",
        "ar": "الاستراتيجيات المتاحة",
    },

    # ── STRATEGI ──────────────────────────────────────────
    "momentum": {
        "id": "Ikut tren kuat · cocok market trending",
        "en": "Follow strong trends · best for trending markets",
        "my": "Ikut tren kuat · sesuai pasaran trending",
        "ar": "اتبع الاتجاهات القوية · مناسب للأسواق المتجهة",
    },
    "reversal": {
        "id": "Cari pembalikan arah · counter-trend",
        "en": "Seek reversals · counter-trend strategy",
        "my": "Cari pembalikan arah · strategi counter-trend",
        "ar": "ابحث عن الانعكاسات · استراتيجية معاكسة للاتجاه",
    },
    "scalping": {
        "id": "Entry cepat · target kecil · frekuensi tinggi",
        "en": "Quick entries · small targets · high frequency",
        "my": "Masuk cepat · sasaran kecil · frekuensi tinggi",
        "ar": "دخول سريع · أهداف صغيرة · تكرار عالي",
    },
    "swing": {
        "id": "Hold beberapa jam/hari · ikut swing besar",
        "en": "Hold hours/days · follow major swings",
        "my": "Tahan beberapa jam/hari · ikut swing besar",
        "ar": "احتفظ لساعات/أيام · اتبع التأرجحات الكبيرة",
    },
    "adaptive": {
        "id": "AI pilih strategi otomatis sesuai kondisi pasar",
        "en": "AI auto-selects strategy based on market conditions",
        "my": "AI pilih strategi secara automatik mengikut pasaran",
        "ar": "الذكاء الاصطناعي يختار الاستراتيجية تلقائياً",
    },

    # ── HOW TO START ──────────────────────────────────────
    "how_to_start": {
        "id": "Cara mulai",
        "en": "How to start",
        "my": "Cara untuk mulakan",
        "ar": "كيفية البدء",
    },
    "cmd_start": {
        "id": "# langsung pakai strategi",
        "en": "# use a strategy directly",
        "my": "# guna strategi terus",
        "ar": "# استخدم الاستراتيجية مباشرة",
    },
    "cmd_backtest": {
        "id": "# test dulu sebelum live",
        "en": "# test before going live",
        "my": "# uji dahulu sebelum live",
        "ar": "# اختبر قبل التداول الحي",
    },
    "cmd_info": {
        "id": "# lihat semua pilihan",
        "en": "# view all options",
        "my": "# lihat semua pilihan",
        "ar": "# عرض جميع الخيارات",
    },

    # ── SIGNAL ────────────────────────────────────────────
    "signal": {
        "id": "Sinyal",
        "en": "Signal",
        "my": "Isyarat",
        "ar": "إشارة",
    },
    "confidence": {
        "id": "Kepercayaan",
        "en": "Confidence",
        "my": "Keyakinan",
        "ar": "الثقة",
    },
    "strategy": {
        "id": "Strategi",
        "en": "Strategy",
        "my": "Strategi",
        "ar": "الاستراتيجية",
    },
    "market": {
        "id": "Market",
        "en": "Market",
        "my": "Pasaran",
        "ar": "السوق",
    },

    # ── DETAIL ANALISIS ───────────────────────────────────
    "detail_analysis": {
        "id": "Detail Analisis",
        "en": "Analysis Detail",
        "my": "Butiran Analisis",
        "ar": "تفاصيل التحليل",
    },
    "price_now": {
        "id": "Harga Sekarang",
        "en": "Current Price",
        "my": "Harga Semasa",
        "ar": "السعر الحالي",
    },
    "market_condition": {
        "id": "Kondisi Pasar",
        "en": "Market Condition",
        "my": "Keadaan Pasaran",
        "ar": "حالة السوق",
    },
    "iq_model": {
        "id": "IQ Model",
        "en": "Model IQ",
        "my": "IQ Model",
        "ar": "ذكاء النموذج",
    },
    "agresivitas": {
        "id": "Agresivitas",
        "en": "Aggressiveness",
        "my": "Keagresifan",
        "ar": "العدوانية",
    },

    # ── BRAIN ─────────────────────────────────────────────
    "brain_title": {
        "id": "NexTrade Brain — Status Model",
        "en": "NexTrade Brain — Model Status",
        "my": "NexTrade Brain — Status Model",
        "ar": "NexTrade Brain — حالة النموذج",
    },
    "neurons_active": {
        "id": "Neuron Aktif",
        "en": "Active Neurons",
        "my": "Neuron Aktif",
        "ar": "الخلايا العصبية النشطة",
    },
    "last_trained": {
        "id": "Terakhir Belajar",
        "en": "Last Trained",
        "my": "Latihan Terakhir",
        "ar": "آخر تدريب",
    },
    "winrate": {
        "id": "Winrate",
        "en": "Win Rate",
        "my": "Kadar Menang",
        "ar": "معدل الفوز",
    },

    # ── LOADING ───────────────────────────────────────────
    "loading_strategy": {
        "id": "Memuat strategi",
        "en": "Loading strategy",
        "my": "Memuatkan strategi",
        "ar": "جارٍ تحميل الاستراتيجية",
    },
    "loading_indicators": {
        "id": "Menghitung indikator AI",
        "en": "Calculating AI indicators",
        "my": "Mengira penunjuk AI",
        "ar": "جارٍ حساب مؤشرات الذكاء الاصطناعي",
    },
    "loading_data": {
        "id": "Mengambil data",
        "en": "Fetching data",
        "my": "Mengambil data",
        "ar": "جارٍ جلب البيانات",
    },
    "data_success": {
        "id": "Data berhasil diambil",
        "en": "Data fetched successfully",
        "my": "Data berjaya diambil",
        "ar": "تم جلب البيانات بنجاح",
    },

    # ── MARKET CONDITIONS ─────────────────────────────────
    "TRENDING": {
        "id": "TRENDING — Pasar sedang bergerak kuat",
        "en": "TRENDING — Market moving strongly",
        "my": "TRENDING — Pasaran bergerak kuat",
        "ar": "TRENDING — السوق يتحرك بقوة",
    },
    "RANGING": {
        "id": "RANGING — Pasar sedang sideways",
        "en": "RANGING — Market moving sideways",
        "my": "RANGING — Pasaran bergerak mendatar",
        "ar": "RANGING — السوق يتحرك جانبياً",
    },
    "VOLATILE": {
        "id": "VOLATILE — Pasar sedang tidak stabil",
        "en": "VOLATILE — Market is unstable",
        "my": "VOLATILE — Pasaran tidak stabil",
        "ar": "VOLATILE — السوق غير مستقر",
    },

    # ── ERRORS ────────────────────────────────────────────
    "error_strategy": {
        "id": "Strategi tidak ditemukan. Pilih",
        "en": "Strategy not found. Choose from",
        "my": "Strategi tidak dijumpai. Pilih dari",
        "ar": "الاستراتيجية غير موجودة. اختر من",
    },
    "error_data": {
        "id": "Gagal ambil data market. Cek koneksi internet.",
        "en": "Failed to fetch market data. Check your internet connection.",
        "my": "Gagal mendapatkan data pasaran. Semak sambungan internet.",
        "ar": "فشل في جلب بيانات السوق. تحقق من اتصالك بالإنترنت.",
    },

    # ── SET LANGUAGE ──────────────────────────────────────
    "language_set": {
        "id": "Bahasa diubah ke",
        "en": "Language changed to",
        "my": "Bahasa ditukar ke",
        "ar": "تم تغيير اللغة إلى",
    },
    "language_invalid": {
        "id": "Bahasa tidak tersedia. Pilih",
        "en": "Language not available. Choose from",
        "my": "Bahasa tidak tersedia. Pilih dari",
        "ar": "اللغة غير متاحة. اختر من",
    },

    # ── BACKTEST ──────────────────────────────────────────
    "backtest_title": {
        "id": "NexTrade Backtest Engine",
        "en": "NexTrade Backtest Engine",
        "my": "NexTrade Enjin Ujian Balik",
        "ar": "محرك الاختبار الخلفي NexTrade",
    },
    "total_trades": {
        "id": "Total Trade",
        "en": "Total Trades",
        "my": "Jumlah Dagangan",
        "ar": "إجمالي الصفقات",
    },
    "total_return": {
        "id": "Total Return",
        "en": "Total Return",
        "my": "Jumlah Pulangan",
        "ar": "إجمالي العائد",
    },
    "max_drawdown": {
        "id": "Max Drawdown",
        "en": "Max Drawdown",
        "my": "Susutan Maksimum",
        "ar": "أقصى تراجع",
    },
    "grade": {
        "id": "Grade Model",
        "en": "Model Grade",
        "my": "Gred Model",
        "ar": "تقييم النموذج",
    },
}

# ── State bahasa aktif ─────────────────────────────────────
_current_lang = "id"  # default Indonesia

def set_language(lang: str) -> bool:
    """
    Set bahasa NexTrade.
    lang: 'id' | 'en' | 'my' | 'ar'
    """
    global _current_lang
    lang = lang.lower().strip()
    if lang not in LANGUAGES:
        available = ", ".join([f"'{k}' ({v})" for k, v in LANGUAGES.items()])
        print(f"\n  \033[31m✗\033[0m  {get('language_invalid')}: {available}\n")
        return False
    _current_lang = lang
    lang_name = LANGUAGES[lang]
    print(f"\n  \033[32m✓\033[0m  {get('language_set')}: \033[1m{lang_name}\033[0m\n")
    return True

def get(key: str, lang: str = None) -> str:
    """Ambil teks dalam bahasa aktif."""
    lang = lang or _current_lang
    if key not in TRANSLATIONS:
        return key
    return TRANSLATIONS[key].get(lang, TRANSLATIONS[key].get("en", key))

def current() -> str:
    """Return kode bahasa aktif."""
    return _current_lang

def list_languages():
    """Tampilkan semua bahasa yang tersedia."""
    print(f"\n  \033[1m\033[37m  Bahasa tersedia / Available languages:\033[0m\n")
    for code, name in LANGUAGES.items():
        active = " \033[32m← aktif\033[0m" if code == _current_lang else ""
        print(f"  \033[33mnextrade.set_language('{code}')\033[0m  →  {name}{active}")
    print()
