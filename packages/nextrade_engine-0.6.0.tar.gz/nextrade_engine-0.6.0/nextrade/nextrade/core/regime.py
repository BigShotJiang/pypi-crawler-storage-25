"""
NexTrade — Regime Detector
Deteksi kondisi pasar: TRENDING / RANGING / VOLATILE
Ini fondasi semua indikator AI NexTrade.
"""
import numpy as np

class MarketRegime:
    TRENDING  = "TRENDING"
    RANGING   = "RANGING"
    VOLATILE  = "VOLATILE"

def detect_regime(close: np.ndarray, period: int = 20) -> dict:
    """
    Deteksi regime pasar dari array harga penutupan.
    Returns dict: { regime, trend_strength, volatility, score }
    """
    if len(close) < period + 1:
        return {"regime": MarketRegime.RANGING, "trend_strength": 0.0,
                "volatility": 0.0, "score": 0.0}

    window = close[-period:]

    # 1. ADX proxy — kemiringan linear vs deviasi
    x = np.arange(period, dtype=float)
    slope, intercept = np.polyfit(x, window, 1)
    fitted = slope * x + intercept
    residuals = window - fitted
    trend_strength = abs(slope) / (np.std(window) + 1e-9)

    # 2. Volatility — ATR proxy pakai std returns
    returns = np.diff(window) / (window[:-1] + 1e-9)
    volatility = np.std(returns) * 100  # dalam persen

    # 3. Range ratio — seberapa besar range vs body rata-rata
    price_range = (np.max(window) - np.min(window)) / (np.mean(window) + 1e-9) * 100

    # Scoring
    if volatility > 2.0 and trend_strength < 0.5:
        regime = MarketRegime.VOLATILE
    elif trend_strength > 1.0:
        regime = MarketRegime.TRENDING
    else:
        regime = MarketRegime.RANGING

    return {
        "regime"        : regime,
        "trend_strength": round(float(trend_strength), 4),
        "volatility"    : round(float(volatility), 4),
        "price_range"   : round(float(price_range), 4),
        "slope"         : round(float(slope), 6),
    }

def detect_regime_series(close: np.ndarray, period: int = 20) -> np.ndarray:
    """
    Deteksi regime untuk seluruh series (untuk backtest).
    Returns array string label.
    """
    regimes = np.full(len(close), MarketRegime.RANGING, dtype=object)
    for i in range(period, len(close)):
        r = detect_regime(close[max(0, i-period):i+1], period)
        regimes[i] = r["regime"]
    return regimes
