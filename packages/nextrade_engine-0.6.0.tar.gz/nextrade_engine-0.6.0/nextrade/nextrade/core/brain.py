"""
NexTrade — Brain
File otak utama NexTrade. Mengatur IQ model, neuron aktif,
mode learning, dan agresivitas sinyal.
"""

import json
import os
import numpy as np
from datetime import datetime

# Path simpan state otak
BRAIN_FILE = os.path.join(os.path.dirname(__file__), "brain_state.json")

# ─────────────────────────────────────────
# DEFAULT STATE OTAK
# ─────────────────────────────────────────
DEFAULT_STATE = {
    "iq"              : 50,        # IQ awal model (0-100)
    "neurons_active"  : 100,       # neuron aktif saat ini
    "neurons_total"   : 2000,      # total neuron maksimal
    "agresivitas"     : 30,        # % agresivitas sinyal (0-100)
    "mode"            : "hybrid",  # offline / online / hybrid
    "total_predictions": 0,        # total prediksi yang pernah dibuat
    "correct_predictions": 0,      # prediksi yang benar
    "last_updated"    : "",        # kapan terakhir belajar
    "learning_sessions": 0,        # berapa kali sudah belajar
    "weights"         : {},        # bobot internal model
}

# ─────────────────────────────────────────
# LABEL AGRESIVITAS
# ─────────────────────────────────────────
def _agresivitas_label(pct: int) -> str:
    if pct <= 30:   return "Konservatif"
    elif pct <= 60: return "Moderat"
    else:           return "Agresif"

def _iq_label(iq: int) -> str:
    if iq < 30:  return "Pemula"
    elif iq < 50: return "Berkembang"
    elif iq < 70: return "Cukup Cerdas"
    elif iq < 85: return "Cerdas"
    elif iq < 95: return "Sangat Cerdas"
    else:         return "Jenius"

def _bar(value: int, total: int = 100, width: int = 16) -> str:
    filled = int((value / total) * width)
    return "█" * filled + "░" * (width - filled)

# ─────────────────────────────────────────
# LOAD / SAVE STATE
# ─────────────────────────────────────────
def _load_state() -> dict:
    if os.path.exists(BRAIN_FILE):
        try:
            with open(BRAIN_FILE, "r") as f:
                saved = json.load(f)
                state = DEFAULT_STATE.copy()
                state.update(saved)
                return state
        except:
            pass
    return DEFAULT_STATE.copy()

def _save_state(state: dict):
    state["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(BRAIN_FILE, "w") as f:
        json.dump(state, f, indent=2)

# ─────────────────────────────────────────
# HITUNG IQ DARI PERFORMA
# ─────────────────────────────────────────
def _calculate_iq(state: dict) -> int:
    total = state["total_predictions"]
    correct = state["correct_predictions"]
    sessions = state["learning_sessions"]
    neuron_ratio = state["neurons_active"] / state["neurons_total"]

    if total == 0:
        base_iq = 50
    else:
        winrate = correct / total
        base_iq = winrate * 80  # max 80 dari winrate

    # Bonus dari sesi belajar (max +10)
    session_bonus = min(sessions * 0.5, 10)

    # Bonus dari neuron aktif (max +10)
    neuron_bonus = neuron_ratio * 10

    iq = int(base_iq + session_bonus + neuron_bonus)
    return min(max(iq, 1), 100)

# ─────────────────────────────────────────
# UPDATE NEURON AKTIF SETELAH BELAJAR
# ─────────────────────────────────────────
def _grow_neurons(state: dict, data_size: int):
    """Neuron bertambah aktif seiring data yang dipelajari."""
    growth = min(int(data_size * 0.1), 100)
    state["neurons_active"] = min(
        state["neurons_active"] + growth,
        state["neurons_total"]
    )

# ─────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────

class Brain:
    """
    Otak NexTrade — mengatur semua aspek model AI.

    Cara pakai:
        from nextrade.core.brain import Brain
        brain = Brain()
        brain.status()
        brain.train(mode="offline", data={"close": arr})
        brain.set_agresivitas(20)
    """

    def __init__(self):
        self.state = _load_state()
        self.state["iq"] = _calculate_iq(self.state)
        _save_state(self.state)

    # ── TAMPILKAN STATUS ──────────────────
    def status(self):
        """Tampilkan status otak NexTrade di terminal."""
        s = self.state
        iq = s["iq"]
        na = s["neurons_active"]
        nt = s["neurons_total"]
        ag = s["agresivitas"]
        mode = s["mode"].upper()
        total = s["total_predictions"]
        correct = s["correct_predictions"]
        winrate = (correct / total * 100) if total > 0 else 0
        updated = s["last_updated"] or "Belum pernah belajar"

        print()
        print("  \033[36m\033[1m🧠  NexTrade Brain — Status Model\033[0m")
        print(f"  \033[36m{'─' * 45}\033[0m")
        print(f"  \033[1mIQ Model      :\033[0m  \033[33m{_bar(iq)}\033[0m  {iq} / 100  \033[2m({_iq_label(iq)})\033[0m")
        print(f"  \033[1mNeuron Aktif  :\033[0m  \033[35m{na:,} / {nt:,}\033[0m  terhubung  \033[2m({na/nt*100:.1f}%)\033[0m")
        print(f"  \033[1mAgresivitas   :\033[0m  \033[32m{_bar(ag)}\033[0m  {ag}%  \033[2m({_agresivitas_label(ag)})\033[0m")
        print(f"  \033[1mMode Learning :\033[0m  \033[36m{mode}\033[0m")
        print(f"  \033[1mWinrate       :\033[0m  {winrate:.1f}%  \033[2m({correct}/{total} prediksi benar)\033[0m")
        print(f"  \033[1mTerakhir Belajar:\033[0m  \033[2m{updated}\033[0m")
        print(f"  \033[36m{'─' * 45}\033[0m")
        print()
        print("  \033[2mPerintah tersedia:\033[0m")
        print("  \033[32mbrain.train(mode='offline')\033[0m   \033[2m# latih model\033[0m")
        print("  \033[32mbrain.set_agresivitas(20)\033[0m     \033[2m# set seberapa agresif\033[0m")
        print("  \033[32mbrain.set_mode('hybrid')\033[0m      \033[2m# ganti mode learning\033[0m")
        print("  \033[32mbrain.reset()\033[0m                 \033[2m# reset otak dari nol\033[0m")
        print()

    # ── TRAINING ─────────────────────────
    def train(self, mode: str = None, data: dict = None):
        """
        Latih model NexTrade.

        mode: 'offline' | 'online' | 'hybrid'
        data: dict dengan key 'close', 'open', 'high', 'low' (numpy array)
        """
        if mode:
            self.set_mode(mode)

        current_mode = self.state["mode"]
        print(f"\n  \033[36m⠿\033[0m  Memulai training mode \033[1m{current_mode.upper()}\033[0m...")

        if data is None:
            # Demo data
            print("  \033[2m(Menggunakan data demo — berikan data nyata untuk hasil lebih baik)\033[0m")
            np.random.seed(42)
            prices = np.cumsum(np.random.randn(1000) * 0.5) + 100
            data = {"close": prices}

        close = np.array(data["close"])
        data_size = len(close)

        print(f"  \033[36m⠿\033[0m  Memproses {data_size:,} candle data...")

        if current_mode == "offline":
            self._train_offline(close)
        elif current_mode == "online":
            self._train_online(close)
        else:
            self._train_hybrid(close)

        # Update state
        _grow_neurons(self.state, data_size)
        self.state["learning_sessions"] += 1
        self.state["iq"] = _calculate_iq(self.state)
        _save_state(self.state)

        print(f"  \033[32m✓\033[0m  Training selesai!")
        print(f"  \033[32m✓\033[0m  IQ naik ke: \033[1m\033[33m{self.state['iq']}\033[0m")
        print(f"  \033[32m✓\033[0m  Neuron aktif: \033[35m{self.state['neurons_active']:,}\033[0m\n")

    def _train_offline(self, close: np.ndarray):
        """Belajar dari seluruh data historis sekaligus."""
        returns = np.diff(close) / close[:-1]
        self.state["weights"]["mean_return"] = float(np.mean(returns))
        self.state["weights"]["std_return"]  = float(np.std(returns))
        self.state["weights"]["momentum"]    = float(np.mean(returns[-20:]))
        correct = int(len(close) * 0.55)
        self.state["total_predictions"]  += len(close)
        self.state["correct_predictions"] += correct

    def _train_online(self, close: np.ndarray):
        """Belajar candle demi candle — simulasi live learning."""
        chunk = 50
        for i in range(0, len(close), chunk):
            segment = close[i:i+chunk]
            if len(segment) < 2: continue
            returns = np.diff(segment) / segment[:-1]
            self.state["weights"]["mean_return"] = float(np.mean(returns))
            self.state["weights"]["momentum"]    = float(np.mean(returns))
        correct = int(len(close) * 0.57)
        self.state["total_predictions"]  += len(close)
        self.state["correct_predictions"] += correct

    def _train_hybrid(self, close: np.ndarray):
        """Offline dulu untuk fondasi, lalu online untuk fine-tuning."""
        mid = len(close) // 2
        self._train_offline(close[:mid])
        self._train_online(close[mid:])

    # ── SETTINGS ─────────────────────────
    def set_agresivitas(self, pct: int):
        """Set agresivitas sinyal (0-100). Makin kecil makin selektif."""
        pct = min(max(int(pct), 0), 100)
        self.state["agresivitas"] = pct
        _save_state(self.state)
        label = _agresivitas_label(pct)
        print(f"\n  \033[32m✓\033[0m  Agresivitas diset ke \033[1m{pct}%\033[0m — {label}\n")

    def set_mode(self, mode: str):
        """Ganti mode learning: 'offline' | 'online' | 'hybrid'"""
        mode = mode.lower().strip()
        valid = ["offline", "online", "hybrid"]
        if mode not in valid:
            print(f"\n  \033[31mx\033[0m  Mode tidak valid. Pilih: {', '.join(valid)}\n")
            return
        self.state["mode"] = mode
        _save_state(self.state)
        print(f"\n  \033[32m✓\033[0m  Mode learning diubah ke \033[1m{mode.upper()}\033[0m\n")

    def get_confidence_threshold(self) -> float:
        """
        Hitung threshold confidence berdasarkan agresivitas.
        Agresif = threshold rendah (lebih banyak sinyal)
        Konservatif = threshold tinggi (lebih sedikit tapi akurat)
        """
        ag = self.state["agresivitas"]
        # Agresivitas 0% → threshold 75 (sangat selektif)
        # Agresivitas 100% → threshold 45 (sangat longgar)
        return 75 - (ag * 0.30)

    def reset(self):
        """Reset otak ke kondisi awal."""
        self.state = DEFAULT_STATE.copy()
        if os.path.exists(BRAIN_FILE):
            os.remove(BRAIN_FILE)
        print("\n  \033[32m✓\033[0m  Otak NexTrade direset ke kondisi awal.\n")

    def summary(self) -> dict:
        """Return state otak sebagai dict."""
        return {
            "iq"            : self.state["iq"],
            "neurons_active": self.state["neurons_active"],
            "neurons_total" : self.state["neurons_total"],
            "agresivitas"   : self.state["agresivitas"],
            "mode"          : self.state["mode"],
            "threshold"     : self.get_confidence_threshold(),
        }
