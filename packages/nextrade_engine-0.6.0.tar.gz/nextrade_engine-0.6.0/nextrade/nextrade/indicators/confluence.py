"""
NexTrade — Confluence Score
Gabungkan semua indikator AI menjadi 1 skor sinyal final.
"""
import numpy as np
from nextrade.core.regime import detect_regime, MarketRegime
from nextrade.indicators.adaptive import adaptive_rsi, momentum_score
from nextrade.indicators.pattern import pattern_score

def confluence_score(opens: np.ndarray, highs: np.ndarray,
                     lows: np.ndarray, closes: np.ndarray) -> dict:
    """
    Hitung confluence score dari semua indikator AI.
    Returns: { signal, confidence, regime, details }
    """
    close = closes

    # Layer 1: Regime
    regime_data = detect_regime(close)
    regime = regime_data["regime"]

    # Layer 2: Momentum
    mom = momentum_score(close)
    rsi = adaptive_rsi(close)

    # Layer 3: Pattern
    pat = pattern_score(opens, highs, lows, closes)

    # Bobot berdasarkan regime
    if regime == MarketRegime.TRENDING:
        w_mom, w_pat, w_rsi = 0.5, 0.3, 0.2
    elif regime == MarketRegime.RANGING:
        w_mom, w_pat, w_rsi = 0.2, 0.5, 0.3
    else:  # VOLATILE
        w_mom, w_pat, w_rsi = 0.3, 0.4, 0.3

    # Normalisasi RSI ke 0-100 bull/bear
    rsi_score = rsi  # sudah 0-100, > 50 = bullish

    raw = mom * w_mom + pat["total"] * w_pat + rsi_score * w_rsi
    confidence = round(float(min(max(raw, 0), 100)), 2)

    # Tentukan sinyal
    if confidence >= 62 and pat["direction"] != "bear":
        signal = "BUY"
    elif confidence <= 38 or pat["direction"] == "bear":
        signal = "SELL"
    else:
        signal = "HOLD"

    return {
        "signal"    : signal,
        "confidence": confidence,
        "regime"    : regime,
        "details"   : {
            "momentum" : round(mom, 2),
            "rsi"      : round(rsi, 2),
            "pattern"  : pat,
            "regime"   : regime_data,
        }
    }
