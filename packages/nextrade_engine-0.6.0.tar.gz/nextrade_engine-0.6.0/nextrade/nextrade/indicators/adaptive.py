"""
NexTrade — Adaptive Indicators
Indikator khas AI yang menyesuaikan diri dengan kondisi pasar.
"""
import numpy as np
from nextrade.core.regime import detect_regime, MarketRegime

def adaptive_period(close: np.ndarray, base: int = 14, 
                    min_p: int = 5, max_p: int = 30) -> int:
    """Hitung periode optimal berdasarkan volatilitas pasar saat ini."""
    r = detect_regime(close)
    vol = r["volatility"]
    # Volatile → periode pendek (lebih responsif)
    # Tenang   → periode panjang (lebih halus)
    if vol > 2.0:
        return min_p
    elif vol < 0.5:
        return max_p
    else:
        # Interpolasi linear
        ratio = (vol - 0.5) / (2.0 - 0.5)
        return int(max_p - ratio * (max_p - min_p))

def adaptive_rsi(close: np.ndarray) -> float:
    """RSI dengan periode adaptif berdasarkan volatilitas."""
    period = adaptive_period(close)
    if len(close) < period + 1:
        return 50.0
    delta = np.diff(close[-period-1:])
    gain = np.where(delta > 0, delta, 0.0)
    loss = np.where(delta < 0, -delta, 0.0)
    avg_gain = np.mean(gain) + 1e-9
    avg_loss = np.mean(loss) + 1e-9
    rs = avg_gain / avg_loss
    return round(float(100 - 100 / (1 + rs)), 2)

def adaptive_ema(close: np.ndarray) -> float:
    """EMA dengan periode adaptif."""
    period = adaptive_period(close)
    if len(close) < period:
        return float(close[-1])
    k = 2 / (period + 1)
    ema = float(close[-period])
    for price in close[-period+1:]:
        ema = price * k + ema * (1 - k)
    return round(ema, 6)

def momentum_score(close: np.ndarray) -> float:
    """
    Skor momentum 0-100 berdasarkan:
    - Adaptive RSI
    - Posisi harga vs EMA
    - Kecepatan pergerakan (Rate of Change)
    """
    rsi = adaptive_rsi(close)
    ema = adaptive_ema(close)
    price = float(close[-1])

    # Price vs EMA score (0-100)
    pct_from_ema = (price - ema) / (ema + 1e-9) * 100
    ema_score = min(max(50 + pct_from_ema * 10, 0), 100)

    # Rate of Change score
    period = max(5, len(close) // 10)
    if len(close) > period:
        roc = (price - float(close[-period])) / (float(close[-period]) + 1e-9) * 100
        roc_score = min(max(50 + roc * 5, 0), 100)
    else:
        roc_score = 50.0

    # Gabungkan: RSI 40% + EMA 30% + ROC 30%
    score = rsi * 0.4 + ema_score * 0.3 + roc_score * 0.3
    return round(float(score), 2)
