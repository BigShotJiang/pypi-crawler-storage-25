"""
NexTrade — Pattern Scorer
Beri skor kekuatan pola candlestick, bukan hanya deteksi ya/tidak.
"""
import numpy as np

def _body(o, c): return abs(c - o)
def _upper(o, c, h): return h - max(o, c)
def _lower(o, c, l): return min(o, c) - l
def _range(h, l): return h - l + 1e-9

def hammer_score(open_: float, high: float, low: float, close: float) -> float:
    """Skor pola hammer / pin bar bawah (0-100)."""
    body = _body(open_, close)
    lower = _lower(open_, close, low)
    upper = _upper(open_, close, high)
    rng = _range(high, low)
    if rng == 0: return 0.0
    lower_ratio = lower / rng
    body_ratio  = body / rng
    # Hammer ideal: lower > 60% range, body < 30%, upper < 10%
    score = 0.0
    score += min(lower_ratio / 0.6, 1.0) * 50   # lower shadow besar
    score += max(1 - body_ratio / 0.3, 0) * 30  # body kecil
    score += max(1 - upper / (rng * 0.1 + 1e-9), 0) * 20  # upper shadow kecil
    return round(min(score, 100.0), 2)

def engulfing_score(prev_o: float, prev_c: float,
                    curr_o: float, curr_c: float) -> tuple:
    """
    Skor pola engulfing bullish / bearish.
    Returns (score, direction) — direction: 'bull' atau 'bear'
    """
    prev_body = _body(prev_o, prev_c)
    curr_body = _body(curr_o, curr_c)
    if prev_body == 0: return 0.0, "none"

    ratio = curr_body / (prev_body + 1e-9)
    is_bull = prev_c < prev_o and curr_c > curr_o and curr_o < prev_c and curr_c > prev_o
    is_bear = prev_c > prev_o and curr_c < curr_o and curr_o > prev_c and curr_c < prev_o

    if not (is_bull or is_bear): return 0.0, "none"
    score = min(ratio * 60, 80) + 20  # minimum 20 kalau valid
    direction = "bull" if is_bull else "bear"
    return round(min(score, 100.0), 2), direction

def pattern_score(opens: np.ndarray, highs: np.ndarray,
                  lows: np.ndarray, closes: np.ndarray) -> dict:
    """
    Gabungan skor semua pola pada candle terbaru.
    Returns dict dengan skor tiap pola dan skor total.
    """
    if len(closes) < 2:
        return {"total": 50.0, "hammer": 0.0, "engulfing": 0.0, "direction": "neutral"}

    o, h, l, c = opens[-1], highs[-1], lows[-1], closes[-1]
    po, pc = opens[-2], closes[-2]

    h_score = hammer_score(o, h, l, c)
    e_score, e_dir = engulfing_score(po, pc, o, c)

    # Tentukan arah dominan
    if e_dir == "bull" or (h_score > 50 and c > o):
        direction = "bull"
    elif e_dir == "bear" or (h_score > 50 and c < o):
        direction = "bear"
    else:
        direction = "neutral"

    total = max(h_score, e_score)
    return {
        "total"     : total,
        "hammer"    : h_score,
        "engulfing" : e_score,
        "direction" : direction,
    }
