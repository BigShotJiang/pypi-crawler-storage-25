"""
NexTrade — Backtest Engine
Vectorized backtest engine — cepat, ringan, bisa jutaan bar di HP.
"""

import numpy as np
from nextrade.indicators.confluence import confluence_score
from nextrade.core.regime import detect_regime_series

def run(data: dict,
        strategy: str   = "adaptive",
        agresivitas: int = 30,
        sl_pct: float   = 2.0,
        tp_pct: float   = 4.0,
        silent: bool    = False) -> dict:
    """
    Jalankan backtest pada data historis.

    data        : dict { open, high, low, close, volume }
    strategy    : nama strategi
    agresivitas : 0-100, makin tinggi makin banyak sinyal
    sl_pct      : stop loss dalam % (default 2%)
    tp_pct      : take profit dalam % (default 4%)

    Returns dict lengkap hasil backtest.
    """
    opens  = np.array(data["open"],  dtype=float)
    highs  = np.array(data["high"],  dtype=float)
    lows   = np.array(data["low"],   dtype=float)
    closes = np.array(data["close"], dtype=float)
    n      = len(closes)

    if not silent:
        _print_start(n, strategy, agresivitas, sl_pct, tp_pct)

    # Threshold berdasarkan agresivitas
    threshold = 75 - (agresivitas * 0.30)

    # ── GENERATE SINYAL UNTUK SETIAP BAR ──────────────────
    signals    = np.full(n, "HOLD", dtype=object)
    confidences = np.zeros(n, dtype=float)
    window = 50  # minimum window untuk kalkulasi

    for i in range(window, n):
        result = confluence_score(
            opens  = opens[max(0, i-window):i+1],
            highs  = highs[max(0, i-window):i+1],
            lows   = lows[max(0, i-window):i+1],
            closes = closes[max(0, i-window):i+1],
        )
        conf = result["confidence"]
        confidences[i] = conf
        pat_dir = result["details"]["pattern"]["direction"]

        if conf >= threshold and pat_dir != "bear":
            signals[i] = "BUY"
        elif conf <= (100 - threshold) or pat_dir == "bear":
            signals[i] = "SELL"
        else:
            signals[i] = "HOLD"

        if not silent and i % 100 == 0:
            pct = (i / n) * 100
            bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
            print(f"\r  \033[36m⠿\033[0m  Menghitung sinyal...  "
                  f"\033[33m{bar}\033[0m  {pct:.0f}%", end="", flush=True)

    if not silent:
        print(f"\r  \033[32m✓\033[0m  Sinyal selesai dihitung!              ")

    # ── SIMULASI TRADE ─────────────────────────────────────
    trades      = []
    in_trade    = False
    entry_price = 0.0
    entry_idx   = 0
    trade_dir   = ""
    balance     = 10000.0   # modal awal $10,000
    peak_balance = balance
    max_drawdown = 0.0

    for i in range(window, n):
        price = closes[i]

        if not in_trade:
            if signals[i] == "BUY":
                in_trade    = True
                entry_price = price
                entry_idx   = i
                trade_dir   = "BUY"
            elif signals[i] == "SELL":
                in_trade    = True
                entry_price = price
                entry_idx   = i
                trade_dir   = "SELL"
        else:
            # Hitung pergerakan harga
            if trade_dir == "BUY":
                pnl_pct = (price - entry_price) / entry_price * 100
            else:
                pnl_pct = (entry_price - price) / entry_price * 100

            # Cek SL / TP / exit signal
            hit_sl     = pnl_pct <= -sl_pct
            hit_tp     = pnl_pct >= tp_pct
            exit_signal = (trade_dir == "BUY"  and signals[i] == "SELL") or \
                          (trade_dir == "SELL" and signals[i] == "BUY")

            if hit_sl or hit_tp or exit_signal:
                pnl_dollar = balance * (pnl_pct / 100)
                balance   += pnl_dollar
                if balance > peak_balance:
                    peak_balance = balance
                dd = (peak_balance - balance) / peak_balance * 100
                if dd > max_drawdown:
                    max_drawdown = dd

                trades.append({
                    "entry_idx"  : entry_idx,
                    "exit_idx"   : i,
                    "direction"  : trade_dir,
                    "entry_price": round(entry_price, 5),
                    "exit_price" : round(price, 5),
                    "pnl_pct"    : round(pnl_pct, 4),
                    "pnl_dollar" : round(pnl_dollar, 2),
                    "result"     : "WIN" if pnl_pct > 0 else "LOSS",
                    "exit_reason": "TP" if hit_tp else "SL" if hit_sl else "SIGNAL",
                    "balance"    : round(balance, 2),
                })
                in_trade = False

    # ── HITUNG STATISTIK ───────────────────────────────────
    total_trades = len(trades)
    if total_trades == 0:
        if not silent:
            print("  \033[33m⚠\033[0m  Tidak ada trade yang terjadi. "
                  "Coba turunkan agresivitas.\n")
        return {"trades": [], "stats": {}}

    wins    = [t for t in trades if t["result"] == "WIN"]
    losses  = [t for t in trades if t["result"] == "LOSS"]
    winrate = len(wins) / total_trades * 100

    total_pnl    = sum(t["pnl_dollar"] for t in trades)
    avg_win      = np.mean([t["pnl_pct"] for t in wins])   if wins   else 0
    avg_loss     = np.mean([t["pnl_pct"] for t in losses]) if losses else 0
    profit_factor = (sum(t["pnl_dollar"] for t in wins) /
                     abs(sum(t["pnl_dollar"] for t in losses)) + 1e-9) if losses else 999

    rr_ratio     = abs(avg_win / avg_loss) if avg_loss != 0 else 999
    final_balance = balance
    total_return  = (final_balance - 10000) / 10000 * 100

    stats = {
        "total_trades"  : total_trades,
        "wins"          : len(wins),
        "losses"        : len(losses),
        "winrate"       : round(winrate, 2),
        "total_return"  : round(total_return, 2),
        "final_balance" : round(final_balance, 2),
        "profit_factor" : round(profit_factor, 2),
        "max_drawdown"  : round(max_drawdown, 2),
        "avg_win_pct"   : round(avg_win, 4),
        "avg_loss_pct"  : round(avg_loss, 4),
        "rr_ratio"      : round(rr_ratio, 2),
        "strategy"      : strategy,
        "bars_tested"   : n,
        "sl_pct"        : sl_pct,
        "tp_pct"        : tp_pct,
        "agresivitas"   : agresivitas,
    }

    if not silent:
        _print_report(stats, trades[-5:])

    return {"trades": trades, "stats": stats}


# ── DISPLAY HELPERS ────────────────────────────────────────

def _print_start(n, strategy, agresivitas, sl_pct, tp_pct):
    print(f"\n  \033[1m\033[37m NexTrade Backtest Engine\033[0m")
    print(f"  \033[36m{'─' * 48}\033[0m")
    print(f"  \033[1mStrategi    :\033[0m  {strategy}")
    print(f"  \033[1mTotal Bar   :\033[0m  {n:,} candle")
    print(f"  \033[1mModal Awal  :\033[0m  $10,000")
    print(f"  \033[1mStop Loss   :\033[0m  {sl_pct}%")
    print(f"  \033[1mTake Profit :\033[0m  {tp_pct}%")
    print(f"  \033[1mAgresivitas :\033[0m  {agresivitas}%")
    print(f"  \033[36m{'─' * 48}\033[0m\n")

def _print_report(stats: dict, last_trades: list):
    wr    = stats["winrate"]
    ret   = stats["total_return"]
    bal   = stats["final_balance"]
    pf    = stats["profit_factor"]
    dd    = stats["max_drawdown"]
    rr    = stats["rr_ratio"]

    ret_color = "\033[32m" if ret >= 0 else "\033[31m"
    wr_color  = "\033[32m" if wr  >= 50 else "\033[31m"

    print(f"\n  \033[1m\033[37m Hasil Backtest\033[0m")
    print(f"  \033[36m{'─' * 48}\033[0m")
    print(f"  \033[1mTotal Trade    :\033[0m  {stats['total_trades']}")
    print(f"  \033[1mWin / Loss     :\033[0m  {stats['wins']} / {stats['losses']}")
    print(f"  \033[1mWinrate        :\033[0m  {wr_color}{wr:.1f}%\033[0m")
    print(f"  \033[1mTotal Return   :\033[0m  {ret_color}{ret:+.2f}%\033[0m  "
          f"(${bal:,.2f})")
    print(f"  \033[1mProfit Factor  :\033[0m  {pf:.2f}  \033[2m(>1.5 = bagus)\033[0m")
    print(f"  \033[1mMax Drawdown   :\033[0m  \033[31m{dd:.2f}%\033[0m")
    print(f"  \033[1mRisk:Reward    :\033[0m  1 : {rr:.2f}")
    print(f"  \033[36m{'─' * 48}\033[0m")

    # Grade otomatis
    grade, color = _grade(wr, ret, dd, pf)
    print(f"\n  \033[1mGrade Model    :\033[0m  {color}{grade}\033[0m\n")

    # 5 trade terakhir
    if last_trades:
        print(f"  \033[2m5 Trade Terakhir:\033[0m")
        for t in last_trades:
            c = "\033[32m" if t["result"] == "WIN" else "\033[31m"
            print(f"  {c}{t['result']:<5}\033[0m  {t['direction']:<5}  "
                  f"{t['pnl_pct']:+.2f}%  ${t['pnl_dollar']:+.2f}  "
                  f"\033[2m({t['exit_reason']})\033[0m")
    print()

def _grade(winrate, total_return, max_dd, profit_factor):
    score = 0
    if winrate >= 60: score += 3
    elif winrate >= 50: score += 2
    elif winrate >= 40: score += 1

    if total_return >= 30: score += 3
    elif total_return >= 10: score += 2
    elif total_return >= 0: score += 1

    if max_dd <= 10: score += 3
    elif max_dd <= 20: score += 2
    elif max_dd <= 30: score += 1

    if profit_factor >= 2: score += 2
    elif profit_factor >= 1.5: score += 1

    if score >= 10: return "S  — Luar Biasa! 🏆", "\033[33m"
    elif score >= 8: return "A  — Sangat Bagus ⭐", "\033[32m"
    elif score >= 6: return "B  — Bagus, bisa dipakai", "\033[32m"
    elif score >= 4: return "C  — Perlu optimasi", "\033[33m"
    else:            return "D  — Perlu banyak perbaikan", "\033[31m"
