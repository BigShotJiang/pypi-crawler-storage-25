# input: upload config, usage records, stdlib json/urllib, shared background executor, and package version metadata
# output: fire-and-forget POSTs of sanitized usage payloads to the aistatus upload API with silent failure semantics
# pos: bridges local usage tracking to remote leaderboard ingestion without blocking SDK request flows
# >>> 一旦我被更新，务必更新我的开头注释，以及所属文件夹的 CLAUDE.md <<<

from __future__ import annotations

import atexit
import json
import threading
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from . import __version__
from .config import AIStatusConfig


class UsageUploader:
    _shared_executor: ThreadPoolExecutor | None = None
    _shared_lock = threading.Lock()

    def __init__(self, config: AIStatusConfig):
        self.config = config
        self._base_url = config.base_url.rstrip("/")
        self._ensure_executor()

    @classmethod
    def _ensure_executor(cls) -> None:
        if cls._shared_executor is not None:
            return
        with cls._shared_lock:
            if cls._shared_executor is not None:
                return
            cls._shared_executor = ThreadPoolExecutor(
                max_workers=2, thread_name_prefix="aistatus-upload",
            )
            atexit.register(lambda: cls._shared_executor.shutdown(wait=False))

    def upload(self, record: dict[str, Any]) -> None:
        if not self.config.upload_enabled:
            return
        if not self.config.name or not self.config.email:
            return
        payload = {
            "records": [
                {
                    "ts": record["ts"],
                    "name": self._truncate(self.config.name, 200),
                    "organization": self._truncate(self.config.organization, 200),
                    "email": self._truncate(self.config.email, 254),
                    "provider": record["provider"],
                    "model": record["model"],
                    "input_tokens": record.get("in", 0),
                    "output_tokens": record.get("out", 0),
                    "cache_creation_input_tokens": record.get("cache_creation_in", 0),
                    "cache_read_input_tokens": record.get("cache_read_in", 0),
                    "cost_usd": record.get("cost", 0),
                    "latency_ms": record.get("latency_ms", 0),
                }
            ],
            "sdk_version": __version__,
        }
        self._shared_executor.submit(self._post, payload)

    def _post(self, payload: dict[str, Any]) -> None:
        try:
            urllib.request.urlopen(
                urllib.request.Request(
                    f"{self._base_url}/api/usage/upload",
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                ),
                timeout=5,
            )
        except Exception:
            pass

    @staticmethod
    def _truncate(value: str | None, limit: int) -> str:
        if not value:
            return ""
        return value[:limit]
