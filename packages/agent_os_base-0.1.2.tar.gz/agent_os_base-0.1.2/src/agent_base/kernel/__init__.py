from .adk_agent import ADKAgent
from .agent_config import AgentConfig


class Kernel(object):
    def __init__(self, agent_config: AgentConfig) -> None:
        if agent_config.agent_framework == "adk":
            self.agent = ADKAgent(agent_config=agent_config)
        elif agent_config.agent_framework == "maf":
            raise ValueError("Microsoft Agent Framework is not yet supported")
        else:
            raise ValueError(f"No such framework {agent_config.agent_framework}")