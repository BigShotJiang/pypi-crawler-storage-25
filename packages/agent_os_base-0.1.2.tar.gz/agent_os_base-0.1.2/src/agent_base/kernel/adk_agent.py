# !/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Router

Authors: fubo
Date: 2026/03/19 00:00:00
"""
import os
import sys
import logging
import pathlib
from typing import List, Dict
import importlib.util
import inspect

from google.adk.agents.llm_agent import Agent
from google.adk.models.lite_llm import LiteLlm
from google.adk.skills import load_skill_from_dir
from google.adk.tools import skill_toolset, mcp_tool, load_memory
from google.adk.code_executors.unsafe_local_code_executor import UnsafeLocalCodeExecutor

from .agent_config import AgentConfig, AgentMCPToolConfig

class ADKAgent(Agent):
    def __init__(self, agent_config: AgentConfig):
        super().__init__(
            model=LiteLlm(
                model=agent_config.provider.model_name,
                api_key=agent_config.provider.model_api_key,
                base_url=agent_config.provider.model_base_url,
                temperature=agent_config.provider.model_temperature
            ),
            name=agent_config.agent_name,
            description=agent_config.description,
            instruction=agent_config.instruction,
            tools=ADKAgent.load_local_function_toolsets(
                f"{agent_config.agent_root_path}/{agent_config.agent_name}/local-functions"
            ) + ADKAgent.load_skills(
                f"{agent_config.agent_root_path}/{agent_config.agent_name}/skills"
            ) + ADKAgent.load_remote_mcp_toolsets(
                f"{agent_config.agent_root_path}/{agent_config.agent_name}/mcp-toolsets"
            ) + [load_memory] if agent_config.use_memory else [],
            output_key=f"{agent_config.agent_name}-result"
        )

    @staticmethod
    def load_functions_from_py_code(code_file_path: str) -> Dict:
        # 1. 检查文件是否存在
        if not os.path.isfile(code_file_path):
            raise FileNotFoundError(f"No such file: {code_file_path}")

        # 2. 生成一个唯一的模块名（避免与已加载模块冲突）
        base_name = os.path.splitext(os.path.basename(code_file_path))[0]
        unique_suffix = str(hash(os.path.abspath(code_file_path))).replace('-', '_')
        module_name = f"{base_name}_{unique_suffix}"

        # 3. 创建模块 spec
        spec = importlib.util.spec_from_file_location(module_name, code_file_path)
        if spec is None:
            raise ImportError(f"Create sepc from {code_file_path}")

        # 4. 创建模块对象并加入 sys.modules
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module

        # 5. 执行模块代码
        try:
            spec.loader.exec_module(module)
        except Exception as e:
            raise ImportError(f"Error when load module {module_name}: {e}")

        # 6. 收集模块中定义的顶层函数
        functions = {}
        for name, obj in inspect.getmembers(module, inspect.isfunction):
            # 只取 __module__ 等于当前模块名的函数（即在该模块内定义，非导入）
            if obj.__module__ == module.__name__:
                functions[name] = obj

        return functions

    @staticmethod
    def load_skills(skills_path: str = None) -> List[skill_toolset.SkillToolset]:
        """Load skills from the skills path."""
        if skills_path is None:
            logging.warning(f"The skills path is {skills_path}. No skills will be loaded.")
            return []

        if not os.path.exists(skills_path):
            logging.warning(f"No such path named {skills_path}. No skills will be loaded.")
            return []

        logging.info(f"Loading skills from {skills_path}")
        skills = []
        for skill in os.listdir(skills_path):
            if skill.startswith("."):
                continue
            logging.info(f"Loading Skill {skill}")
            skills.append(load_skill_from_dir(pathlib.Path(skills_path) / skill))
        skills_toolsets = [
            skill_toolset.SkillToolset(skills=skills, code_executor=UnsafeLocalCodeExecutor())
        ]
        logging.info(f"All skills were loaded count {len(skills)}")

        return skills_toolsets

    @staticmethod
    def load_local_function_toolsets(local_function_path: str = None) -> List:
        """加载本地代码函数工具"""
        functions = []
        if local_function_path is None:
            logging.warning(f"The local function code file is {local_function_path}. No function will be loaded.")
            return []

        if not os.path.exists(local_function_path):
            logging.warning(f"No such path named {local_function_path}. No functions will be loaded.")
            return []
        logging.info(f"Loading local functions from {local_function_path}")
        for code_file in os.listdir(local_function_path):
            if not code_file.endswith(".py"):
                continue
            functions = functions + list(
                ADKAgent.load_functions_from_py_code(f"{local_function_path}/{code_file}").values()
            )
        logging.info(f"All local functions were loaded function count {len(functions)}")
        return functions

    @staticmethod
    def load_remote_mcp_toolsets(mcp_toolset_path: str = None) -> List[mcp_tool.McpToolset]:
        """加载远端的MCP服务"""
        toolsets = []
        if mcp_toolset_path is None:
            logging.warning(f"The mcp-toolsets is {mcp_toolset_path}. No remote MCP tools will be loaded.")
            return []

        if not os.path.exists(mcp_toolset_path):
            logging.warning(f"No such path named {mcp_toolset_path}. No remote MCP tools will be loaded.")
            return []

        logging.info(f"Loading remote mcp toolsets from {mcp_toolset_path}")
        for toolset_config_file in os.listdir(mcp_toolset_path):
            if not toolset_config_file.endswith(".json"):
                continue
            # 解析工具集参数
            logging.info(f"Loading MCP toolset files {toolset_config_file}")
            toolset_config = AgentMCPToolConfig.parse_file(f"{mcp_toolset_path}/{toolset_config_file}")
            # 构建mcp工具集
            if toolset_config.server_type.lower() == "sse":
                if toolset_config.auth_token is not None and toolset_config.auth_token != "":
                    toolset = mcp_tool.McpToolset(
                        connection_params=mcp_tool.mcp_session_manager.SseServerParams(
                            url=toolset_config.url,
                            headers=dict(Authorization=f'Bearer {toolset_config.auth_token}')
                        ),
                        errlog=None
                    )
                else:
                    toolset = mcp_tool.McpToolset(
                        connection_params=mcp_tool.mcp_session_manager.SseServerParams(url=toolset_config.url),
                        errlog=None
                    )

            elif toolset_config.server_type.lower() == "streamablehttp":
                if toolset_config.auth_token is not None and toolset_config.auth_token != "":
                    toolset = mcp_tool.McpToolset(
                        connection_params=mcp_tool.mcp_session_manager.StreamableHTTPServerParams(
                            url=toolset_config.url,
                            headers=dict(Authorization=f'Bearer {toolset_config.auth_token}')
                        ),
                        errlog=None
                    )
                else:
                    toolset = mcp_tool.McpToolset(
                        connection_params=mcp_tool.mcp_session_manager.StreamableHTTPServerParams(
                            url=toolset_config.url
                        ),
                        errlog=None
                    )
            else:
                toolset = None

            if toolset is not None:
                toolsets.append(toolset)

        logging.info(f"All MCP toolsets were loaded count {len(toolsets)}")

        return toolsets
