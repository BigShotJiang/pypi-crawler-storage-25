# !/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Router

Authors: fubo
Date: 2026/03/19 00:00:00
"""
from pydantic import BaseModel

class AgentMCPToolConfig(BaseModel):
    # toolse name
    name: str
    # Server URL
    url: str
    # 服务类型
    server_type: str = "StreamableHTTP"
    # Auth
    auth_token: str = ""

class ModelProvider(BaseModel):
    # 使用的模型名
    model_name: str
    # 模型api key
    model_api_key: str
    # 模型base url
    model_base_url: str
    # 模型参数温度
    model_temperature: float = 0.0

class AgentConfig(BaseModel):
    # 智能体所在路径
    agent_root_path: str
    # 智能体框架
    agent_framework: str
    # 智能体名
    agent_name: str
    # 智能体描述
    description: str = ""
    # 智能体instruction
    instruction: str = ""
    # LLM配置
    provider: ModelProvider
    # 是否智能体入口
    is_entrypoint: bool = False
    # 是否使用memory
    use_memory: bool = False
