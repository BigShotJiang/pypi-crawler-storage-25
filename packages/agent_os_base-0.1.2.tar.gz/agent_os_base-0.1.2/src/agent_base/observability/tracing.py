def setup_tracing(endpoint_host: str, experiment_id: int):
    from opentelemetry import trace
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("test-span"):
        print("trace test")
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = TracerProvider()

    exporter = OTLPSpanExporter(
        endpoint=f"{endpoint_host}/v1/traces",
        headers={"x-mlflow-experiment-id": str(experiment_id)}
    )
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)