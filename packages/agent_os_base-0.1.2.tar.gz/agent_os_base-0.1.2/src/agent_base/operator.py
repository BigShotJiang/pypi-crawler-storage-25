# !/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Router

Authors: fubo
Date: 2026/03/19 00:00:00
"""
import os
import json
import logging
from .kernel.agent_config import AgentConfig, AgentMCPToolConfig

class Operator:
    @staticmethod
    def replace_placeholder(file_name: str, replacement_data: dict) -> str:
        with open(file_name, "r") as fp:
            content = fp.read()
        for key in replacement_data:
            content = content.replace(key, replacement_data[key])
        return content

    @staticmethod
    def create_agent(agent_config: AgentConfig):
        logging.info(f"Creating agent from config: {agent_config}")

        # # 这里调用 google-adk 相关逻辑
        agent_root_path = f"./{agent_config.agent_name}"
        template_file_path = os.path.dirname(os.path.abspath(__file__)) + "/templates"

        # 构建Agent文件夹
        os.system(f"mkdir {agent_root_path}")
        os.system(f"touch {agent_root_path}/.env")
        os.system(f"mkdir -p {agent_root_path}/skills")
        os.system(f"mkdir -p {agent_root_path}/local-functions")
        os.system(f"mkdir -p {agent_root_path}/mcp-toolsets")

        # 添加local-function的代码文件
        os.system(f"touch {agent_root_path}/local-functions/function_toolset.py")

        # 写入智能体代码
        os.system(f'echo "from . import agent" >> {agent_root_path}/__init__.py')
        agent_py_code_template_file = template_file_path + "/agent.py.template"
        open(f"{agent_root_path}/agent.py", "w").write(
            Operator.replace_placeholder(
                agent_py_code_template_file,
                {"#[OpentelemetryTraceLine] ": ""}
            ) if not(agent_config.trace_endpoint_host is None or agent_config.trace_endpoint_host == "") else Operator.replace_placeholder(
                agent_py_code_template_file,
                {}
            )
        )

        # os.system(f"cp {agent_py_code_template_file} {agent_root_path}/agent.py")
        dotenv_template_file = template_file_path + "/env.template"
        with open(f"{agent_root_path}/.env", "w") as fp:
            fp.write(
                Operator.replace_placeholder(
                    dotenv_template_file,
                    {
                        "[agent-framework]": agent_config.agent_framework,
                        "[agent-name]": agent_config.agent_name,
                        "[agent-description]": agent_config.description,
                        "[agent-instruction]": agent_config.instruction,
                        "[model-base-url]": agent_config.provider.model_base_url,
                        "[model-name]": agent_config.provider.model_name,
                        "[model-temperature]": str(agent_config.provider.model_temperature),
                        "[model-api-key]": agent_config.provider.model_api_key,
                        "[is-entrypoint]": agent_config.is_entrypoint,
                        "[use-memory]": agent_config.use_memory,
                    }
                )
            )

    @staticmethod
    def create_skill_tool(config_file):
        """创建技能和工具"""
        pass

    @staticmethod
    def create_local_function_tool(config_file):
        """创建本地函数工具"""

    @staticmethod
    def create_mcp_toolset(agent_name: str, agent_mcp_toolset_config: AgentMCPToolConfig):
        """为智能体创建MCP工具集配置文件"""
        toolsets_path = f"./{agent_name}/mcp-toolsets"
        logging.info(f"Add MCP Toolset{agent_mcp_toolset_config.name}.json to {toolsets_path}")
        if not os.path.exists(toolsets_path):
            logging.error(f"No such agent and agent mcp-toolsets {toolsets_path}")
            return

        open(
            f"{toolsets_path}/{agent_mcp_toolset_config.name}.json", "w"
        ).write(
            json.dumps(agent_mcp_toolset_config.dict(), ensure_ascii=False)
        )
