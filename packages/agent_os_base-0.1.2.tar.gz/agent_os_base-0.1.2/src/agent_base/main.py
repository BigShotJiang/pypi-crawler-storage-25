# !/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Router

Authors: fubo
Date: 2026/03/19 00:00:00
"""

import sys
import argparse

from .kernel.agent_config import AgentConfig, ModelProvider, AgentMCPToolConfig
from .operator import Operator

def commander():
    parser = argparse.ArgumentParser(description="智能体系统构建")
    parser.add_argument("-an", "--agent-name", required=True, help="智能体名称")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # create-agent 子命令
    parser_create_agent = subparsers.add_parser("create-agent", help="创建智能体")
    parser_create_agent.add_argument(
        "-af", "--agent_framework",
        required=True, help="智能体框架（adk/maf）"
    )
    parser_create_agent.add_argument(
        "-ad", "--agent-description",
        required=True, help="智能体描述信息"
    )
    parser_create_agent.add_argument(
        "-ai", "--agent-instruction",
        required=True, help="智能体instruction"
    )
    parser_create_agent.add_argument(
        "-mdu", "--model-url",
        required=True, help="智能体使用的模型base url"
    )
    parser_create_agent.add_argument(
        "-mdn", "--model-name",
        required=True, help="智能体使用的模型名称"
    )
    parser_create_agent.add_argument(
        "-mdk", "--model-api-key",
        required=True, help="智能体使用的模型服务API-KEY"
    )
    parser_create_agent.add_argument(
        "-mdt", "--model-temperature",
        type=float, required=False, default=0.0, help="智能体使用的模型温度"
    )
    parser_create_agent.add_argument(
        "-ie", "--is-entrypoint",
        type=bool, required=True, default=False, help="该智能体是否入口智能体"
    )
    parser_create_agent.add_argument(
        "-um", "--use-memory",
        type=bool, required=True, default=False, help="智能体是否使用长期记忆"
    )

    # create-skill 子命令
    parser_create_skill_tool = subparsers.add_parser("create-skill", help="创建智能体skill")
    parser_create_skill_tool.add_argument(
        "-c", "--config",
        required=True, help="智能体配置文件agent_config.yml"
    )

    # create-local-function-tools 子命令
    parser_create_local_function_tool = subparsers.add_parser(
        "create-local-function-tool",
        help="创建智能体本地函数工具"
    )
    parser_create_local_function_tool.add_argument(
        "-c", "--config",
        required=True, help="智能体配置文件agent_config.yml"
    )

    # create-mcp-toolset 子命令
    parser_create_mcp_tool = subparsers.add_parser("create-mcp-toolset", help="创建智能体mcp工具集")
    parser_create_mcp_tool.add_argument(
        "-mpn", "--mcp-name",
        required=True, help="MCP工具集名"
    )
    parser_create_mcp_tool.add_argument(
        "-mpu", "--mcp-url",
        required=True, help="MCP工具集url"
    )
    parser_create_mcp_tool.add_argument(
        "-mpst", "--mcp-server-type",
        required=True, help="MCP工具集服务类型SSE/StreamableHTTP"
    )
    parser_create_mcp_tool.add_argument(
        "-mpat", "--mcp-auth-token",
        required=False, default="", help="MCP工具集auth token"
    )

    return parser


def command_parser(parser: argparse.ArgumentParser):
    # main_args_parser: argparse.ArgumentParser,
    args = parser.parse_args()
    if args.command == "create-agent":
        Operator.create_agent(
            AgentConfig(
                agent_root_path="./",
                agent_framework=args.agent_framework,
                agent_name=args.agent_name,
                description=args.agent_description,
                instruction=args.agent_instruction,
                provider=ModelProvider(
                    model_base_url=args.model_url,
                    model_name=args.model_name,
                    model_api_key=args.model_api_key,
                    model_temperature=args.model_temperature
                ),
                is_entrypoint=args.is_entrypoint,
                use_memory=args.use_memory,
            )
        )
    elif args.command == "create-skill":
        Operator.create_skill_tool(args.config)
    elif args.command == "create-local-function-tool":
        Operator.create_local_function_tool(args.config)
    elif args.command == "create-mcp-toolset":
        Operator.create_mcp_toolset(
            agent_name=args.agent_name,
            agent_mcp_toolset_config=AgentMCPToolConfig(
                name=args.mcp_name,
                url=args.mcp_url,
                server_type=args.mcp_server_type,
                auth_token=args.mcp_auth_token
            )
        )

    else:
        parser.print_help()
        sys.exit(1)

def main():
    command_parser(commander())

if __name__ == "__main__":
    main()
