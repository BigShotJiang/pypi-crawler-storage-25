from ag_ui_adk import ADKAgent
from .kernel.agent_config import AgentConfig, ModelProvider
from .kernel import Kernel

def create_agent(
        agent_root_path: str,
        agent_framework: str,
        agent_name:str,
        agent_description:str,
        agent_instruction: str,
        model_name: str,
        model_base_url: str,
        model_api_key: str,
        model_temperature: float,
        is_entrypoint: bool = False,
        use_memory: bool = False
):
    # 生成agent配置文件
    agent_config = AgentConfig(
        agent_root_path=agent_root_path if not (agent_root_path is None or agent_root_path == "") else "./",
        agent_framework=agent_framework if agent_framework in ["adk"] else "adk",
        agent_name=agent_name if not (agent_name is None or agent_name == "") else "default_agent",
        description=agent_description if not (
                    agent_description is None or agent_description == "") else "这是一个默认的智能体",
        instruction=agent_instruction if not (
                    agent_instruction is None or agent_instruction == "") else "你是一个乐于助人的智能体助手",
        provider=ModelProvider(
            model_name=model_name if not (model_name is None or model_name == "") else "qwen3",
            model_base_url=model_base_url if not (
                        model_base_url is None or model_base_url == "") else "http://localhost:8080/v1",
            model_api_key=model_api_key if not (model_base_url is None or model_base_url == "") else "sk-test",
            model_temperature=model_temperature
        ),
        is_entrypoint=is_entrypoint,
        use_memory=use_memory
    )

    # 生成Agent
    agent_kernel = Kernel(agent_config=agent_config)
    return agent_kernel.agent
