# OpenAI schema package
