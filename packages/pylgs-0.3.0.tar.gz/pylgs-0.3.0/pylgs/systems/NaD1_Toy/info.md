#### Atomic levels

$\text{3S} _{1/2}$, $\text{3P} _{1/2}$

#### Pump transitions

1. $\text{3S} _{1/2}\to \text{3P} _{1/2}$

#### Transition wavelengths

- $\text{3P} _{1/2}\to \text{3S} _{1/2}$: 589.756 nm

#### Substructure

- Hyperfine structure neglected
- Zeeman structure neglected
- 2 total sublevels

#### Density matrix elements

- All populations included
- Optical coherences (between different levels) included for pump transitions only
- 4 total density matrix elements

#### Input parameters

- BeamTransitRatePerS
- RecoilParameter
- TemperatureK
- VccRatePerS
- DetuningHz1
-                         149896229 Pi
Sqrt[IntensitySI1] Sqrt[------------]
                             10
-------------------------------------
                 250
- LaserWidthHz1