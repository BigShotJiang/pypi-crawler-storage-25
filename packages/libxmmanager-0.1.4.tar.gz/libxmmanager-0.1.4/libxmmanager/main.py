import subprocess
import sys
import logging

logger = logging.getLogger(__name__)


def init(filename="xmmanager.log"):
    logging.basicConfig(filename, level=logging.INFO)
    logger.info("Initialized logger")


def xmrig_start(xmrig_path, args):
    subprocess.Popen(xmrig_path + " -B " + args, shell=True)
    logger.info("Started XMRig")
    return True


def xmrig_stop(kill_command):
    subprocess.Popen(kill_command, shell=True)
    logger.info("Stopped XMRig")
    return False


def mining_controller(xmrig_path, args, kill_command):
    global xmrig_status
    if xmrig_status:
        xmrig_status = xmrig_start(xmrig_path, args)
        logger.info("Toggled XMRig on")
    elif not xmrig_status:
        xmrig_status = xmrig_stop(kill_command)
        logger.info("Toggled XMRig off")


def quit():
    global xmrig_status
    xmrig_status = xmrig_stop(xmrig_status)
    logger.info("Stopped XMRig")
    logger.info("Exiting...")
    sys.exit()
