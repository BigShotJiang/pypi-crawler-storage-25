"""Internal warning surfaces — sync-in-async guard, framework-extras notice,
telemetry env namespace.

Three warning classes share the same three-lever silencing precedence:
constructor kwarg > env var > stdlib ``warnings.filterwarnings``. All
three subclass ``Warning`` directly (NOT ``UserWarning``) so CI shops
setting ``warnings.filterwarnings("error", category=UserWarning)`` do
NOT hard-fail on these informational paths.
"""

from __future__ import annotations

import os
import warnings

from . import _docs


class SyncInAsyncWarning(Warning):
    """Emitted when sync ``Memory`` is called from inside a running asyncio loop.

    This will block the event loop for the duration of the request. Use
    ``AsyncMemory`` instead. Silenceable three ways:

      1. ``Memory(suppress_async_warning=True)`` — constructor, per-instance, highest
      2. ``ATLASO_ASYNC_WARNINGS=0``              — env var, per-process
      3. ``warnings.filterwarnings("ignore", category=SyncInAsyncWarning)``
    """


class FrameworkExtraReservedWarning(Warning):
    """Emitted once per process when a framework extra was installed but
    no Atlaso adapter for that framework ships in this version.

    The framework extras (``atlaso[langchain]``, ``atlaso[llamaindex]``, etc.)
    reserve the namespace; real adapters land once usage signal warrants
    (PyPI install count + GitHub issue volume). Until then, wrap Atlaso
    into your framework manually using a recipe under ``docs/recipes/``.
    """


# --- Env-var parsing ----------------------------------------------

_FALSY = {"0", "false", "no", "off"}


def _env_disabled(name: str) -> bool:
    """True if env var is set to one of the falsy strings.

    Empty string, unset, or unrecognized values default-on (no silent
    disable on typo).
    """
    raw = os.environ.get(name)
    if raw is None:
        return False
    return raw.strip().lower() in _FALSY


def async_warnings_enabled(constructor_kwarg: bool | None) -> bool:
    """Resolve the three-lever precedence for SyncInAsyncWarning.

    Constructor kwarg is ``suppress_async_warning: bool`` — invert.
    """
    if constructor_kwarg is not None:
        return not constructor_kwarg
    return not _env_disabled("ATLASO_ASYNC_WARNINGS")


# --- Stub framework extras probe ----------------------------------

_STUB_EXTRAS = ("langchain", "llamaindex", "crewai", "openai-agents", "dspy")
_STUB_PROBE_DONE = False


def warn_about_stub_extras_once() -> None:
    """Probe installed dependencies; emit one warning per process if any
    framework module is importable in this environment.

    Conservative — false negatives are fine (we only warn when a framework
    is clearly present). Heuristic: a framework extra is "active" iff a
    key dep of the framework is importable.
    """
    global _STUB_PROBE_DONE
    if _STUB_PROBE_DONE:
        return
    _STUB_PROBE_DONE = True

    framework_probe = {
        "langchain": "langchain_core",
        "llamaindex": "llama_index",
        "crewai": "crewai",
        "openai-agents": "agents",
        "dspy": "dspy",
    }
    detected: list[str] = []
    for stub, probe_module in framework_probe.items():
        try:
            __import__(probe_module)
            detected.append(stub)
        except ImportError:
            continue

    if not detected:
        return

    msg = (
        f"FrameworkExtraReservedWarning: detected installed framework(s) "
        f"{detected!r} but Atlaso v0.1 ships no framework adapter code. "
        "The `atlaso[<framework>]` extras reserve the namespace; real "
        "adapters land once usage signal warrants. Until then, wrap "
        "Atlaso into your framework manually using one of the recipes "
        f"at {_docs.FRAMEWORK_ROADMAP}. "
        "Silence: this warning fires once per process; "
        f"warnings.filterwarnings('ignore', category=FrameworkExtraReservedWarning)."
    )
    warnings.warn(msg, FrameworkExtraReservedWarning, stacklevel=3)


# --- ATLASO_TELEMETRY namespace claim -----------------------------

def warn_telemetry_env_is_noop() -> None:
    """If ``ATLASO_TELEMETRY`` is set to a truthy value, log once that it has
    no effect — Atlaso ships zero telemetry and the variable is reserved
    for an opt-in path in v0.2+. Setting it falsy/empty is silently
    honored (the explicit "off" state).
    """
    raw = os.environ.get("ATLASO_TELEMETRY")
    if raw is None or raw.strip().lower() in {*_FALSY, ""}:
        return
    msg = (
        "ATLASO_TELEMETRY is set but has no effect in this version. Atlaso "
        "ships zero telemetry, ever — the variable name is reserved for "
        "an opt-in path in a future version. To explicitly disable for "
        "forward-compat, set ATLASO_TELEMETRY=0."
    )
    warnings.warn(msg, UserWarning, stacklevel=3)


# --- Sync-in-async loop guard -------------------------------------

def emit_async_loop_warning(method_name: str) -> None:
    """Emit SyncInAsyncWarning when sync method called from async context."""
    msg = (
        f"Memory.{method_name}() called from inside a running asyncio loop "
        f"will block the event loop for the duration of the request. "
        f"Use AsyncMemory.{method_name}() instead, "
        f"or pass Memory(suppress_async_warning=True) to silence. "
        f"See {_docs.ASYNC_GUIDE}"
    )
    warnings.warn(msg, SyncInAsyncWarning, stacklevel=3)


# --- Helpers for callers without natural keys --------------------

def idempotency_key(*parts: str | int | float | bool) -> str:
    """Content-hash helper for ``add_many`` callers without natural keys.

    >>> from atlaso import idempotency_key
    >>> idempotency_key("alice", "prefers oat milk", 2026)
    'ak_a3f2c8b6...'   # stable across runs

    This is a pure helper — no per-call state, no side effects. Suitable
    for streaming sources where every row needs a stable key derived
    from its content.
    """
    import hashlib

    h = hashlib.blake2b(digest_size=16)
    for part in parts:
        h.update(str(part).encode("utf-8"))
        h.update(b"\x00")
    return f"ak_{h.hexdigest()}"
