"""Async mirror of Memory for SaaS / FastAPI / Starlette / aiohttp / Django-async.

(D9 + D11. Both surfaces ship in v0.1; sync is the front door for the quickstart,
async is the production path for HTTP servers. Single source of truth for
transport logic in ``atlaso._core.transport``; the two public classes are
thin shells that differ only at the I/O boundary.)
"""

from __future__ import annotations

import os
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import httpx

from . import _docs
from ._validation import check_evidence_grade, check_polarity, check_user_id_shape
from .compat import (
    async_warnings_enabled,
    warn_about_stub_extras_once,
    warn_telemetry_env_is_noop,
)
from .errors import ConfigValidationError, InputValidationError

if TYPE_CHECKING:
    from ._types import EvidenceGrade, Polarity, Scope
    from .handle import AsyncUserHandle
    from .results import (
        AddItem,
        AddManyResult,
        AddResult,
        Deposit,
        Diagnostics,
        PeekView,
        RetractResult,
        SearchResults,
    )


_DEFAULT_BASE_URL = "https://api.atlaso.dev"
_DEFAULT_TIMEOUT = 10.0
_DEFAULT_MAX_RETRIES = 2


class AsyncMemory:
    """Async Atlaso memory client. Use this from FastAPI / aiohttp / asyncio handlers.

    Shape mirrors ``Memory`` 1:1 — every method has an ``async def`` counterpart;
    ``for_user(user_id)`` is sync on both classes (it just returns a handle —
    no I/O). The handle's methods change shape (sync vs async).

    Use ``async with AsyncMemory(...) as m:`` for clean lifecycle in handlers
    and worker tasks::

        from atlaso import AsyncMemory
        from fastapi import FastAPI, Depends

        memory = AsyncMemory(api_key="...")
        app = FastAPI()

        @app.post("/remember")
        async def remember(text: str, user = Depends(current_user)):
            handle = memory.for_user(user.id)
            return await handle.add(text)

    No ``SyncInAsyncWarning`` analog: AsyncMemory called from sync code raises
    immediately (not warns). Use the right type — there is no auto-bridging
    policy.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        path: str | os.PathLike[str] | None = None,
        validate_user_id: Callable[[str], None] | None = None,
        timeout: float | httpx.Timeout = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        suppress_async_warning: bool | None = None,  # accepted for symmetry; no-op on async
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        # Mirror of Memory's transport contract — but async transport here.
        if transport is not None and isinstance(transport, httpx.AsyncClient):
            raise ConfigValidationError(
                "transport= must be an httpx.AsyncBaseTransport, NOT an httpx.AsyncClient. "
                "Sharing an httpx.AsyncClient across two AsyncMemory instances with "
                "different api_keys silently leaks Authorization headers across tenants. "
                f"See {_docs.WIRE_SCHEMA}."
            )

        self._api_key = api_key or os.environ.get("ATLASO_API_KEY")
        self._base_url = (
            base_url
            or os.environ.get("ATLASO_BASE_URL")
            or _DEFAULT_BASE_URL
        )
        self._path = path
        self._validate_user_id = validate_user_id
        self._timeout = timeout
        self._max_retries = max_retries
        # async_warnings is a no-op on AsyncMemory; accepted for symmetry.
        _ = async_warnings_enabled(suppress_async_warning)
        self._user_transport = transport

        self._client: httpx.AsyncClient | None = None

        # D12: ATLASO_TELEMETRY no-op probe. D13: stub-framework extras probe.
        warn_telemetry_env_is_noop()
        warn_about_stub_extras_once()

    def __repr__(self) -> str:
        path = self._path or os.environ.get("ATLASO_PATH") or "<auto-resolved on first write>"
        return f"AsyncMemory(path={path!r})"

    # --- Lifecycle ----------------------------------------------------
    # aclose() is defined later in the Backend resolution section; it closes
    # both the local backend (if open) and the httpx async client (if used by
    # the future remote backend in v0.2). Caller's transport, if injected, is
    # NEVER closed by us.

    async def __aenter__(self) -> AsyncMemory:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    # --- Recommended path: per-user binding (sync) -------------------

    def for_user(self, user_id: str) -> AsyncUserHandle:
        """Bind this client to an authenticated user identity.

        Sync — returns a handle without I/O. The handle's methods are async.
        """
        from .handle import AsyncUserHandle

        self._authorize(user_id)
        return AsyncUserHandle(_client=self, _user_id=user_id)

    # --- Lower-level surface: explicit user_id per call --------------

    async def add(
        self,
        text: str,
        *,
        user_id: str,
        polarity: Polarity = "open",
        evidence_grade: EvidenceGrade = "anecdotal",
        scope: Scope | None = None,
        tags: list[str] | None = None,
        contradicts: list[str] | None = None,
        author: str | None = None,
    ) -> AddResult:
        self._authorize(user_id)
        check_polarity(polarity)
        check_evidence_grade(evidence_grade)
        return await self._transport_add(
            text,
            user_id=user_id,
            polarity=polarity,
            evidence_grade=evidence_grade,
            scope=scope,
            tags=tuple(tags or ()),
            contradicts=tuple(contradicts or ()),
            author=author,
        )

    async def recall(
        self,
        query: str,
        *,
        user_id: str,
        limit: int = 10,
        scope: Scope | None = None,
    ) -> SearchResults:
        self._authorize(user_id)
        if not isinstance(limit, int) or not (1 <= limit <= 1000):
            raise InputValidationError(f"limit must be an int in [1, 1000], got {limit!r}")
        return await self._transport_recall(
            query, user_id=user_id, limit=limit, scope=scope
        )

    async def get(self, deposit_id: str, *, user_id: str) -> Deposit | None:
        self._authorize(user_id)
        return await self._transport_get(deposit_id, user_id=user_id)

    async def peek(self, user_id: str, *, limit: int = 10) -> PeekView:
        """Async mirror of ``Memory.peek`` — wraps sync engine in to_thread."""
        import asyncio as _asyncio

        self._authorize(user_id)
        if not isinstance(limit, int) or not (1 <= limit <= 200):
            raise InputValidationError(
                f"limit must be an int in [1, 200], got {limit!r}"
            )
        return await _asyncio.to_thread(
            self._backend().peek, user_id=user_id, limit=limit
        )

    async def list_recent(
        self,
        *,
        user_id: str,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Deposit]:
        self._authorize(user_id)
        if not isinstance(limit, int) or not (1 <= limit <= 1000):
            raise InputValidationError(f"limit must be an int in [1, 1000], got {limit!r}")
        if not isinstance(offset, int) or offset < 0:
            raise InputValidationError(f"offset must be a non-negative int, got {offset!r}")
        return await self._transport_list_recent(
            user_id=user_id, limit=limit, offset=offset
        )

    async def contradict(
        self,
        new_text: str,
        contradicts: list[str],
        *,
        reason: str,
        user_id: str,
    ) -> AddResult:
        self._authorize(user_id)
        if not contradicts:
            raise InputValidationError(
                "contradict() requires at least one deposit_id in contradicts=[...]"
            )
        if not reason or not reason.strip():
            raise InputValidationError(
                "contradict() requires reason='...' to keep the audit trail meaningful."
            )
        return await self._transport_contradict(
            new_text,
            contradicts=tuple(contradicts),
            reason=reason,
            user_id=user_id,
        )

    async def retract(
        self,
        deposit_id: str,
        *,
        reason: str,
        user_id: str,
        hard_delete: bool = False,
        force: bool = False,
    ) -> RetractResult:
        self._authorize(user_id)
        if not reason or not reason.strip():
            raise InputValidationError(
                "retract() needs reason=... because Atlaso keeps a retraction trail; "
                'use m.retract(deposit_id, reason="wrong fact") for normal corrections, '
                "or hard_delete=True only for PII/GDPR deletion."
            )
        return await self._transport_retract(
            deposit_id,
            reason=reason,
            hard_delete=hard_delete,
            force=force,
            user_id=user_id,
        )

    async def health(self, *, user_id: str, window_days: int = 30) -> Diagnostics:
        self._authorize(user_id)
        if not isinstance(window_days, int) or not (1 <= window_days <= 365):
            raise InputValidationError(
                f"window_days must be an int in [1, 365], got {window_days!r}"
            )
        return await self._transport_health(user_id=user_id, window_days=window_days)

    async def add_many(
        self,
        items: list[AddItem],
        *,
        user_id: str,
        on_gate_reject: str = "skip",
    ) -> AddManyResult:
        self._authorize(user_id)
        if not isinstance(items, list) or not items:
            raise InputValidationError("add_many() requires a non-empty list[AddItem]")
        if on_gate_reject not in {"skip", "raise"}:
            raise InputValidationError(
                f"on_gate_reject must be 'skip' or 'raise', got {on_gate_reject!r}"
            )
        return await self._transport_add_many(
            items, user_id=user_id, on_gate_reject=on_gate_reject
        )

    # --- update is REFUSED ------------------------------------------

    def update(self, *args: Any, **kwargs: Any) -> Any:
        raise AttributeError(
            "Atlaso deposits are immutable evidence. To revise an earlier "
            "finding, deposit a new one with contradicts=[old_id] and an "
            f"explicit polarity. See: {_docs.CONTRADICT_GUIDE}"
        )

    # --- Internals --------------------------------------------------

    def _authorize(self, user_id: str) -> None:
        check_user_id_shape(user_id)
        if self._validate_user_id is not None:
            self._validate_user_id(user_id)

    # --- Backend resolution + transport delegations ---------------
    # v0.1: SQLite has no native async API — wrap sync local backend calls
    # in asyncio.to_thread(). v0.2 adds a true async backend when the remote
    # REST API ships at api.atlaso.dev.

    def _backend(self) -> Any:
        if hasattr(self, "_backend_instance"):
            return self._backend_instance
        from ._local import LocalBackend
        from ._path_resolver import resolve_storage_path

        base = self._path or resolve_storage_path()
        self._backend_instance = LocalBackend(base)
        return self._backend_instance

    async def aclose(self) -> None:
        """Close the backend if open. Caller's transport is NOT closed."""
        import asyncio as _asyncio

        if hasattr(self, "_backend_instance"):
            await _asyncio.to_thread(self._backend_instance.close)
            del self._backend_instance
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _transport_add(self, text: str, **kw: Any) -> AddResult:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().add, text, **kw)

    async def _transport_recall(self, query: str, **kw: Any) -> SearchResults:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().recall, query, **kw)

    async def _transport_get(self, deposit_id: str, **kw: Any) -> Deposit | None:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().get, deposit_id, **kw)

    async def _transport_list_recent(self, **kw: Any) -> list[Deposit]:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().list_recent, **kw)

    async def _transport_contradict(self, new_text: str, **kw: Any) -> AddResult:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().contradict, new_text, **kw)

    async def _transport_retract(self, deposit_id: str, **kw: Any) -> RetractResult:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().retract, deposit_id, **kw)

    async def _transport_health(self, **kw: Any) -> Diagnostics:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().health, **kw)

    async def _transport_add_many(self, items: list[Any], **kw: Any) -> AddManyResult:
        import asyncio as _asyncio

        return await _asyncio.to_thread(self._backend().add_many, items, **kw)
