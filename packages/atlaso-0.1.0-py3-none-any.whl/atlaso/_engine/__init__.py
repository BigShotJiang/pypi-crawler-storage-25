"""Field 3.0 engine — internal snapshot bundled with the Atlaso SDK.

This is an independent vendored snapshot. The Atlaso desktop app ships its
own snapshot (in atlaso-app/) that may be at a different version. Both
products evolve at their own pace; drift is intentional.

When you fix a bug here, check whether the same fix belongs in the app's
copy at atlaso-app/src-tauri/resources/field/engine/field/ and bump the
field_engine_version constant if you sync them.

See ../FIELD_ENGINE.md for the maintainer note.
"""

field_engine_version = "0.1.0"
"""Snapshot version of the Field 3.0 engine bundled with this SDK release."""
