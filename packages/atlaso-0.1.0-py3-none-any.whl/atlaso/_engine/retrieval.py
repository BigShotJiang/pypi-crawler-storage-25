"""Polarity-aware retrieval with freshness decay and contradiction expansion."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import timezone, datetime
from typing import Iterable

from .store import Deposit, FieldStore, Polarity

# Half-lives in days. Negative/cautionary findings stay fresh ~6x longer
# than positive/open ones — a known failure is a constraint, not stale gossip.
_HALF_LIVES: dict[Polarity, float] = {
    "positive": 14.0,
    "open": 14.0,
    "negative": 90.0,
    "cautionary": 90.0,
}

_AGENT_PREAMBLE = (
    "Treat FAILED/WARNINGS as constraints, not supporting evidence."
)


@dataclass
class RetrievalResult:
    positive: list[Deposit] = field(default_factory=list)
    negative: list[Deposit] = field(default_factory=list)
    cautionary: list[Deposit] = field(default_factory=list)
    open: list[Deposit] = field(default_factory=list)
    contradictions: dict[str, list[Deposit]] = field(default_factory=dict)

    def format_for_agent(self) -> str:
        lines: list[str] = [_AGENT_PREAMBLE]
        lines.append("<CONFIRMED>")
        lines.extend(_render_bucket(self.positive))
        lines.append("</CONFIRMED>")
        lines.append("<FAILED_OR_NEGATIVE>")
        lines.extend(_render_bucket(self.negative))
        lines.append("</FAILED_OR_NEGATIVE>")
        lines.append("<WARNINGS>")
        lines.extend(_render_bucket(self.cautionary))
        lines.append("</WARNINGS>")
        lines.append("<OPEN_QUESTIONS>")
        lines.extend(_render_bucket(self.open))
        lines.append("</OPEN_QUESTIONS>")
        if self.contradictions:
            lines.append("<CONTRADICTIONS>")
            lines.extend(_render_contradictions(self.contradictions))
            lines.append("</CONTRADICTIONS>")
        return "\n".join(lines)


def _render_bucket(deposits: Iterable[Deposit]) -> list[str]:
    out: list[str] = []
    for d in deposits:
        scope = d.scope.note or "-"
        out.append(
            f"  [{d.id[:8]}] ({d.evidence_grade}) {d.content} :: scope={scope}"
        )
    return out


def _render_contradictions(contradictions: dict[str, list[Deposit]]) -> list[str]:
    out: list[str] = []
    for primary_id, linked in contradictions.items():
        out.append(f"  [{primary_id[:8]}]")
        for d in linked:
            scope = d.scope.note or "-"
            out.append(
                f"    [{d.id[:8]}] ({d.polarity}/{d.evidence_grade}) {d.content} :: scope={scope}"
            )
    return out


def _decay(bm25: float, created_at: datetime, now: datetime, half_life_days: float) -> float:
    age_days = max(0.0, (now - created_at).total_seconds() / 86400.0)
    return bm25 * math.exp(-age_days * math.log(2) / half_life_days)


def retrieve_for_query(
    store: FieldStore,
    query: str,
    *,
    k_positive: int = 3,
    k_negative: int = 3,
    k_cautionary: int = 2,
    k_open: int = 2,
    now: datetime | None = None,
) -> RetrievalResult:
    now = now or datetime.now(timezone.utc)

    buckets: dict[Polarity, list[tuple[Deposit, float]]] = {}
    for polarity, k in (
        ("positive", k_positive),
        ("negative", k_negative),
        ("cautionary", k_cautionary),
        ("open", k_open),
    ):
        candidate_limit = max(50, k * 10)
        items = [
            (deposit, _decay(score, deposit.created_at, now, _HALF_LIVES[polarity]))
            for deposit, score in store.search_bm25(query, limit=candidate_limit, polarity=polarity)
        ]
        items.sort(key=lambda pair: pair[1], reverse=True)
        buckets[polarity] = items

    result = RetrievalResult()
    result.positive = [d for d, _ in buckets["positive"][:k_positive]]
    result.negative = [d for d, _ in buckets["negative"][:k_negative]]
    result.cautionary = [d for d, _ in buckets["cautionary"][:k_cautionary]]
    result.open = [d for d, _ in buckets["open"][:k_open]]

    # Contradiction expansion: pull linked deposits for everything we picked,
    # even if they didn't make it into their own bucket. Dedupe so a deposit
    # never shows up twice in its own polarity bucket.
    seen_ids = {
        d.id
        for bucket in (result.positive, result.negative, result.cautionary, result.open)
        for d in bucket
    }
    for source in list(seen_ids):
        linked = store.get_contradictions(source)
        if not linked:
            continue
        result.contradictions[source] = linked
        for d in linked:
            if d.id in seen_ids:
                continue
            # Don't double-count: only expansion deposits not already shown go
            # nowhere except the contradictions map. They're displayed via the
            # map, not added to the per-polarity buckets.
            seen_ids.add(d.id)

    return result


__all__ = ["RetrievalResult", "retrieve_for_query"]
