-- Field core schema. Append-only deposits with an FTS5 mirror and a
-- separate contradictions edge table.

CREATE TABLE IF NOT EXISTS deposits (
    id              TEXT PRIMARY KEY,
    content         TEXT NOT NULL,
    polarity        TEXT NOT NULL CHECK (polarity IN ('positive','negative','cautionary','open')),
    evidence_grade  TEXT NOT NULL CHECK (evidence_grade IN ('anecdotal','observed','replicated','verified')),
    author          TEXT NOT NULL,
    task_id         TEXT,
    repro_status    TEXT NOT NULL CHECK (repro_status IN ('unreplicated','replicated','failed_repro')),
    created_at      TEXT NOT NULL,
    -- structured scope facets (kept as columns so we can filter cheaply)
    scope_note      TEXT NOT NULL,
    scope_model     TEXT,
    scope_dataset   TEXT,
    scope_env       TEXT,
    scope_version   TEXT,
    scope_n         INTEGER,
    scope_seed      INTEGER,
    -- list-shaped data lives in JSON columns
    tags_json           TEXT NOT NULL,
    artifact_refs_json  TEXT NOT NULL,
    -- author_role: short role slug used by the gate for evidence-grade
    -- modifiers. Free-form TEXT (no CHECK) so future roles land without a
    -- schema migration. Conventions in use: principal_scientist, theorist,
    -- red_team, statistician, litsurveyor, experimentalist, repro_specialist,
    -- scribe. NULL for historical rows predating this column (2026-04-20).
    author_role    TEXT
);

CREATE INDEX IF NOT EXISTS deposits_created_at_idx ON deposits(created_at);
CREATE INDEX IF NOT EXISTS deposits_polarity_idx ON deposits(polarity);

-- Contentless FTS5 table over content, tags, scope.note merged into one column.
CREATE VIRTUAL TABLE IF NOT EXISTS deposits_fts USING fts5(
    body,
    content=''
);

CREATE TABLE IF NOT EXISTS contradictions (
    from_deposit_id TEXT NOT NULL,
    to_deposit_id   TEXT NOT NULL,
    reason          TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    PRIMARY KEY (from_deposit_id, to_deposit_id),
    FOREIGN KEY (from_deposit_id) REFERENCES deposits(id),
    FOREIGN KEY (to_deposit_id)   REFERENCES deposits(id)
);

CREATE INDEX IF NOT EXISTS contradictions_to_idx ON contradictions(to_deposit_id);

-- Consultations log: one row per `contact_agent` call. Lets us see who asked
-- whom what after the fact, and powers the UI's consultation panel.
-- NOTE: for dbs that predate slice 8b the `task_id` column is added via an
-- ALTER TABLE migration in FieldStore.__init__, and the task_id index is
-- created there too (it cannot live in schema.sql because executescript
-- would fail on the index before the migration runs on old dbs).
CREATE TABLE IF NOT EXISTS consultations (
    id           TEXT PRIMARY KEY,
    caller       TEXT NOT NULL,
    callee       TEXT NOT NULL,
    message      TEXT NOT NULL,
    response     TEXT,
    status       TEXT NOT NULL CHECK (status IN ('ok','error')),
    duration_ms  INTEGER NOT NULL,
    created_at   TEXT NOT NULL,
    task_id      TEXT
);
CREATE INDEX IF NOT EXISTS consultations_created_at_idx ON consultations(created_at);

-- Tasks log: one row per user-dispatched task. A task is one PS turn run in
-- task-mode (not a conversation). The runner streams PS's output to the UI
-- and, when PS emits its final report, stores it here.
CREATE TABLE IF NOT EXISTS tasks (
    id            TEXT PRIMARY KEY,
    description   TEXT NOT NULL,
    status        TEXT NOT NULL CHECK (status IN ('running','completed','failed')),
    started_at    TEXT NOT NULL,
    finished_at   TEXT,
    duration_ms   INTEGER,
    final_report  TEXT,
    final_summary TEXT,
    error         TEXT
);
CREATE INDEX IF NOT EXISTS tasks_status_idx ON tasks(status);
CREATE INDEX IF NOT EXISTS tasks_started_at_idx ON tasks(started_at);

-- Messages inbox: one row per PS-initiated note to the Director. These are
-- posted either explicitly by PS via the `message_director` MCP tool during
-- a task, or automatically by the task runner when a task reaches a
-- terminal state (completed/failed). The Director does not reply here —
-- the command channel is the outer Claude Code conversation (via MCP),
-- and this table is a one-way inbox.
CREATE TABLE IF NOT EXISTS messages (
    id           TEXT PRIMARY KEY,
    from_agent   TEXT NOT NULL,
    text         TEXT NOT NULL,
    priority     TEXT NOT NULL CHECK (priority IN ('info','review_needed','blocked')),
    topic        TEXT NOT NULL,
    task_id      TEXT,
    deposit_ids  TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    read_at      TEXT
);
CREATE INDEX IF NOT EXISTS messages_created_at_idx ON messages(created_at);
CREATE INDEX IF NOT EXISTS messages_read_at_idx ON messages(read_at);
CREATE INDEX IF NOT EXISTS messages_task_id_idx ON messages(task_id);

-- Query log: one row per field_query_aware call. Used by maturity.py to
-- compute Coverage — what fraction of recent queries hit a confident bag.
-- No PII, no query text; just the calibration shape of each retrieval.
CREATE TABLE IF NOT EXISTS query_log (
    id           TEXT PRIMARY KEY,
    created_at   TEXT NOT NULL,
    bag_key      TEXT NOT NULL,       -- JSON-serialized scope bag
    is_confident INTEGER NOT NULL,    -- 0/1
    has_conflict INTEGER NOT NULL,    -- 0/1
    is_single_sample INTEGER NOT NULL, -- 0/1
    bag_size     INTEGER NOT NULL,
    result_count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS query_log_created_at_idx ON query_log(created_at);

