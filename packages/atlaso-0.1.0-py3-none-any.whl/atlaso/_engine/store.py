"""SQLite-backed FieldStore with FTS5 BM25 search.

Append-only. Contradictions are recorded as edges in a separate table so a
single deposit can be refuted by many later observations without rewriting
history.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from dataclasses import asdict, dataclass, field
from datetime import timezone, datetime, timedelta
from pathlib import Path
from typing import Any, Literal

Polarity = Literal["positive", "negative", "cautionary", "open"]
EvidenceGrade = Literal["anecdotal", "observed", "replicated", "verified"]
ReproStatus = Literal["unreplicated", "replicated", "failed_repro"]

_SCHEMA_PATH = Path(__file__).with_name("schema.sql")


@dataclass
class Scope:
    note: str
    model: str | None = None
    dataset: str | None = None
    env: str | None = None
    version: str | None = None
    n: int | None = None
    seed: int | None = None


@dataclass
class Deposit:
    id: str
    content: str
    polarity: Polarity
    evidence_grade: EvidenceGrade
    scope: Scope
    author: str
    task_id: str | None
    tags: list[str] = field(default_factory=list)
    artifact_refs: list[str] = field(default_factory=list)
    repro_status: ReproStatus = "unreplicated"
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    # Short role slug used by the gate for evidence-grade modifiers
    # (see gate.evaluate_deposit_request). Free-form TEXT at the DB layer;
    # NULL for historical rows that predate the column — see
    # ``FieldStore._run_migrations``. Conventions in use: principal_scientist,
    # theorist, red_team, statistician, litsurveyor, experimentalist,
    # repro_specialist, scribe.
    author_role: str | None = None


ConsultationStatus = Literal["ok", "error"]
TaskStatus = Literal["running", "completed", "failed"]
MessagePriority = Literal["info", "review_needed", "blocked"]


@dataclass
class Consultation:
    id: str
    caller: str
    callee: str
    message: str
    response: str | None
    status: ConsultationStatus
    duration_ms: int
    created_at: datetime
    task_id: str | None = None


@dataclass
class Task:
    id: str
    description: str
    status: TaskStatus
    started_at: datetime
    finished_at: datetime | None
    duration_ms: int | None
    final_report: str | None
    final_summary: str | None
    error: str | None


@dataclass
class Message:
    id: str
    from_agent: str
    text: str
    priority: MessagePriority
    topic: str
    task_id: str | None
    deposit_ids: list[str]
    created_at: datetime
    read_at: datetime | None


def _iso(dt: datetime) -> str:
    return dt.replace(microsecond=dt.microsecond).isoformat()


def _from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s)


def _row_to_deposit(row: sqlite3.Row) -> Deposit:
    scope = Scope(
        note=row["scope_note"],
        model=row["scope_model"],
        dataset=row["scope_dataset"],
        env=row["scope_env"],
        version=row["scope_version"],
        n=row["scope_n"],
        seed=row["scope_seed"],
    )
    return Deposit(
        id=row["id"],
        content=row["content"],
        polarity=row["polarity"],
        evidence_grade=row["evidence_grade"],
        scope=scope,
        author=row["author"],
        task_id=row["task_id"],
        tags=json.loads(row["tags_json"]),
        artifact_refs=json.loads(row["artifact_refs_json"]),
        repro_status=row["repro_status"],
        created_at=_from_iso(row["created_at"]),
        # author_role column was added 2026-04-20; older rows lack the key
        # entirely (pre-migration) or have a NULL value (post-migration).
        author_role=(
            row["author_role"] if "author_role" in row.keys() else None
        ),
    )


class FieldStore:
    """Append-only deposit store with FTS5 search and contradiction edges."""

    def __init__(self, db_path: str | Path):
        self._db_path = str(db_path)
        # Keep one shared connection and serialize DB access with a lock.
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(_SCHEMA_PATH.read_text())
        self._conn.commit()
        self._run_migrations()

    def _run_migrations(self) -> None:
        """Idempotent schema migrations for dbs created before later slices.

        SQLite's ``CREATE TABLE IF NOT EXISTS`` cannot add columns to existing
        tables, so columns introduced in later slices are retrofitted here
        via ALTER TABLE wrapped in a try/except. Indexes on migrated columns
        also live here because they cannot safely run from schema.sql
        (``executescript`` would fail on old dbs before the ALTER runs).
        """
        with self._lock:
            # slice 8b: `task_id` on consultations so consults made during a
            # task-dispatch run can be grouped by task.
            try:
                self._conn.execute(
                    "ALTER TABLE consultations ADD COLUMN task_id TEXT"
                )
                self._conn.commit()
            except sqlite3.OperationalError:
                # Column already present; ALTER is idempotent-via-try.
                pass
            # Index creation is separate so it runs even when the ALTER
            # short-circuits on a db that already has the column.
            try:
                self._conn.execute(
                    "CREATE INDEX IF NOT EXISTS consultations_task_id_idx "
                    "ON consultations(task_id)"
                )
                self._conn.commit()
            except sqlite3.OperationalError:
                pass

            # 2026-04-20: `author_role` on deposits. The gate already reads
            # author_role at deposit-check time (see gate.py); this column
            # persists the value so future retrieval can filter by role
            # without parsing the free-form author name.
            #
            # Race-safe: PRAGMA + ALTER is non-atomic, so two concurrent
            # FieldStore(path) opens (e.g. daemon + sidecar at startup) can
            # both see "no author_role" before either writes. The loser's
            # ALTER raises `sqlite3.OperationalError: duplicate column name`
            # — catch that specific case; the post-condition (column exists)
            # is satisfied either way.
            cur = self._conn.execute("PRAGMA table_info(deposits)")
            cols = {row[1] for row in cur.fetchall()}
            if "author_role" not in cols:
                try:
                    self._conn.execute(
                        "ALTER TABLE deposits ADD COLUMN author_role TEXT"
                    )
                    self._conn.commit()
                except sqlite3.OperationalError as exc:
                    if "duplicate column" not in str(exc).lower():
                        raise
                    # Another opener won the race. Column is there. Proceed.

    # ------------------------------------------------------------------ writes

    def deposit(
        self,
        *,
        content: str,
        polarity: Polarity,
        evidence_grade: EvidenceGrade,
        scope: Scope,
        author: str,
        task_id: str | None = None,
        tags: list[str] | None = None,
        artifact_refs: list[str] | None = None,
        repro_status: ReproStatus = "unreplicated",
        contradicts: list[str] | None = None,
        author_role: str | None = None,
    ) -> str:
        """Insert a deposit and return its id.

        `contradicts` is a list of deposit ids that this deposit refutes. The
        per-edge `reason` is taken from the depositing record's `content` —
        we deliberately keep the API surface narrow rather than asking
        callers to supply a parallel list of justifications. The full
        contradicting deposit is always retrievable via get(), so the edge's
        reason text is just a pointer back to that row's content.

        `author_role` is the short role slug the gate uses for evidence-grade
        modifiers (e.g. "red_team" gets +1 on negatives/cautionaries). It is
        persisted alongside the free-form `author` so downstream retrieval
        can filter by role without parsing the author name.
        """
        deposit_id = str(uuid.uuid4())
        created = datetime.now(timezone.utc)
        tags = tags or []
        artifact_refs = artifact_refs or []

        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    INSERT INTO deposits (
                        id, content, polarity, evidence_grade, author, task_id,
                        repro_status, created_at,
                        scope_note, scope_model, scope_dataset, scope_env,
                        scope_version, scope_n, scope_seed,
                        tags_json, artifact_refs_json, author_role
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        deposit_id,
                        content,
                        polarity,
                        evidence_grade,
                        author,
                        task_id,
                        repro_status,
                        _iso(created),
                        scope.note,
                        scope.model,
                        scope.dataset,
                        scope.env,
                        scope.version,
                        scope.n,
                        scope.seed,
                        json.dumps(tags),
                        json.dumps(artifact_refs),
                        author_role,
                    ),
                )
                # FTS body merges content + tags + scope.note for one-shot search.
                body = " ".join([content, " ".join(tags), scope.note])
                self._conn.execute(
                    "INSERT INTO deposits_fts(rowid, body) VALUES ((SELECT rowid FROM deposits WHERE id = ?), ?)",
                    (deposit_id, body),
                )
                for target in contradicts or []:
                    self._conn.execute(
                        """
                        INSERT INTO contradictions (
                            from_deposit_id, to_deposit_id, reason, created_at
                        ) VALUES (?, ?, ?, ?)
                        """,
                        (deposit_id, target, content, _iso(created)),
                    )
        return deposit_id

    # ------------------------------------------------------------------- reads

    def get(self, deposit_id: str) -> Deposit | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM deposits WHERE id = ?", (deposit_id,)
            ).fetchone()
        return _row_to_deposit(row) if row else None

    def list_recent(self, limit: int = 20) -> list[Deposit]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM deposits ORDER BY created_at DESC, id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [_row_to_deposit(r) for r in rows]

    def search_bm25(
        self,
        query: str,
        limit: int = 50,
        polarity: Polarity | None = None,
    ) -> list[tuple[Deposit, float]]:
        """FTS5 BM25 search. Returns (deposit, score) with highest score first.

        FTS5 `bm25()` returns a *lower-is-better* score, so we negate it so
        the public API stays "higher is better".
        """
        sql = (
            "SELECT d.*, bm25(deposits_fts) AS raw_score "
            "FROM deposits_fts JOIN deposits d ON d.rowid = deposits_fts.rowid "
            "WHERE deposits_fts MATCH ?"
        )
        params: list[object] = [query]
        if polarity is not None:
            sql += " AND d.polarity = ?"
            params.append(polarity)
        sql += " ORDER BY raw_score ASC LIMIT ?"
        params.append(limit)

        try:
            with self._lock:
                rows = self._conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            # Malformed FTS query (e.g. empty after tokenization). Treat as no hits.
            return []
        return [(_row_to_deposit(r), -float(r["raw_score"])) for r in rows]

    def get_contradictions(self, deposit_id: str) -> list[Deposit]:
        """Deposits linked by a contradiction edge in either direction."""
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT d.* FROM deposits d
                WHERE d.id IN (
                    SELECT to_deposit_id   FROM contradictions WHERE from_deposit_id = ?
                    UNION
                    SELECT from_deposit_id FROM contradictions WHERE to_deposit_id   = ?
                )
                """,
                (deposit_id, deposit_id),
            ).fetchall()
        return [_row_to_deposit(r) for r in rows]

    def count(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM deposits").fetchone()[0])

    # ------------------------------------------------------------ consultations

    def log_consultation(
        self,
        *,
        caller: str,
        callee: str,
        message: str,
        response: str | None,
        status: ConsultationStatus,
        duration_ms: int,
        task_id: str | None = None,
    ) -> str:
        """Record one `contact_agent` call. Returns the new consultation id."""
        cid = str(uuid.uuid4())
        created = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    INSERT INTO consultations (
                        id, caller, callee, message, response, status,
                        duration_ms, created_at, task_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cid,
                        caller,
                        callee,
                        message,
                        response,
                        status,
                        duration_ms,
                        _iso(created),
                        task_id,
                    ),
                )
        return cid

    def _row_to_consultation(self, r: sqlite3.Row) -> Consultation:
        return Consultation(
            id=r["id"],
            caller=r["caller"],
            callee=r["callee"],
            message=r["message"],
            response=r["response"],
            status=r["status"],
            duration_ms=int(r["duration_ms"]),
            created_at=_from_iso(r["created_at"]),
            # task_id column was added in slice 8b migration; older rows get None.
            task_id=r["task_id"] if "task_id" in r.keys() else None,
        )

    def list_consultations(self, limit: int = 50) -> list[Consultation]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM consultations ORDER BY created_at DESC, id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_consultation(r) for r in rows]

    def list_consultations_by_task(self, task_id: str) -> list[Consultation]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM consultations WHERE task_id = ? ORDER BY created_at ASC, id ASC",
                (task_id,),
            ).fetchall()
        return [self._row_to_consultation(r) for r in rows]

    def list_deposits_by_task(self, task_id: str) -> list[Deposit]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM deposits WHERE task_id = ? ORDER BY created_at ASC, id ASC",
                (task_id,),
            ).fetchall()
        return [_row_to_deposit(r) for r in rows]

    # -------------------------------------------------------------------- tasks

    def create_task(self, *, description: str) -> str:
        """Insert a new task row with status='running'. Returns the task id."""
        task_id = str(uuid.uuid4())
        started = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    INSERT INTO tasks (id, description, status, started_at)
                    VALUES (?, ?, 'running', ?)
                    """,
                    (task_id, description, _iso(started)),
                )
        return task_id

    def complete_task(
        self,
        task_id: str,
        *,
        final_report: str,
        final_summary: str,
        duration_ms: int,
    ) -> None:
        finished = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    UPDATE tasks
                    SET status = 'completed',
                        finished_at = ?,
                        duration_ms = ?,
                        final_report = ?,
                        final_summary = ?
                    WHERE id = ?
                    """,
                    (_iso(finished), duration_ms, final_report, final_summary, task_id),
                )

    def cancel_running_task(
        self,
        task_id: str,
        *,
        error: str,
        duration_ms: int,
    ) -> bool:
        """Atomically transition a ``running`` task to ``failed``.

        Returns ``True`` if the row was updated (i.e. the task was still
        running when this was called), ``False`` otherwise. This lets the
        caller distinguish "cancelled" from "already completed" races.
        """
        finished = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                cur = self._conn.execute(
                    """
                    UPDATE tasks
                    SET status = 'failed',
                        finished_at = ?,
                        duration_ms = ?,
                        error = ?
                    WHERE id = ? AND status = 'running'
                    """,
                    (_iso(finished), duration_ms, error, task_id),
                )
                return int(cur.rowcount or 0) > 0

    def fail_task(
        self,
        task_id: str,
        *,
        error: str,
        duration_ms: int,
    ) -> None:
        finished = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    UPDATE tasks
                    SET status = 'failed',
                        finished_at = ?,
                        duration_ms = ?,
                        error = ?
                    WHERE id = ?
                    """,
                    (_iso(finished), duration_ms, error, task_id),
                )

    def _row_to_task(self, r: sqlite3.Row) -> Task:
        return Task(
            id=r["id"],
            description=r["description"],
            status=r["status"],
            started_at=_from_iso(r["started_at"]),
            finished_at=_from_iso(r["finished_at"]) if r["finished_at"] else None,
            duration_ms=int(r["duration_ms"]) if r["duration_ms"] is not None else None,
            final_report=r["final_report"],
            final_summary=r["final_summary"],
            error=r["error"],
        )

    def get_task(self, task_id: str) -> Task | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
        return self._row_to_task(row) if row else None

    def list_tasks(self, limit: int = 50) -> list[Task]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM tasks ORDER BY started_at DESC, id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def count_tasks(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0])

    # -------------------------------------------------------- dashboard stats

    def polarity_distribution(self) -> dict[str, int]:
        """Return count of deposits grouped by polarity."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT polarity, COUNT(*) as n FROM deposits GROUP BY polarity"
            ).fetchall()
        out = {"positive": 0, "negative": 0, "cautionary": 0, "open": 0}
        for r in rows:
            out[r["polarity"]] = int(r["n"])
        return out

    def evidence_grade_distribution(self) -> dict[str, int]:
        """Return count of deposits grouped by evidence_grade."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT evidence_grade, COUNT(*) as n FROM deposits GROUP BY evidence_grade"
            ).fetchall()
        out = {"anecdotal": 0, "observed": 0, "replicated": 0, "verified": 0}
        for r in rows:
            out[r["evidence_grade"]] = int(r["n"])
        return out

    def contradictions_total(self) -> int:
        with self._lock:
            return int(
                self._conn.execute("SELECT COUNT(*) FROM contradictions").fetchone()[0]
            )

    def recent_contradiction_pairs(self, limit: int = 5) -> list[tuple[Deposit, Deposit]]:
        """Return up to `limit` most-recent (from, to) contradiction pairs."""
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT from_deposit_id, to_deposit_id, created_at
                FROM contradictions
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        pairs: list[tuple[Deposit, Deposit]] = []
        for r in rows:
            frm = self.get(r["from_deposit_id"])
            to = self.get(r["to_deposit_id"])
            if frm and to:
                pairs.append((frm, to))
        return pairs

    def deposits_per_day(self, days: int = 14) -> list[dict[str, Any]]:
        """Return `days` entries of daily deposit counts, ending today.

        Missing days are zero-filled so the frontend can render a dense
        sparkline without per-day gap handling.
        """
        return self._daily_counts(
            "SELECT date(created_at) AS d, COUNT(*) AS n FROM deposits "
            "WHERE created_at >= ? GROUP BY d",
            days=days,
        )

    def consultations_per_day(self, days: int = 14) -> list[dict[str, Any]]:
        return self._daily_counts(
            "SELECT date(created_at) AS d, COUNT(*) AS n FROM consultations "
            "WHERE created_at >= ? GROUP BY d",
            days=days,
        )

    def tasks_per_day(self, days: int = 14) -> list[dict[str, Any]]:
        return self._daily_counts(
            "SELECT date(started_at) AS d, COUNT(*) AS n FROM tasks "
            "WHERE started_at >= ? GROUP BY d",
            days=days,
        )

    def _daily_counts(self, sql: str, *, days: int) -> list[dict[str, Any]]:
        """Run a daily-bucket query and zero-fill missing days in the window."""
        now = datetime.now(timezone.utc)
        start = now - timedelta(days=days - 1)
        start_iso = start.strftime("%Y-%m-%d")
        with self._lock:
            rows = self._conn.execute(sql, (start_iso + " 00:00:00",)).fetchall()
        raw = {r["d"]: int(r["n"]) for r in rows}
        out: list[dict[str, Any]] = []
        for i in range(days):
            day = (start + timedelta(days=i)).strftime("%Y-%m-%d")
            out.append({"date": day, "count": raw.get(day, 0)})
        return out

    def deposit_count_by_author(self) -> dict[str, int]:
        """Return lifetime deposit counts grouped by author."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT author, COUNT(*) AS n FROM deposits GROUP BY author"
            ).fetchall()
        return {r["author"]: int(r["n"]) for r in rows}

    def consultation_count_by_callee(
        self,
        *,
        since: datetime | None = None,
        status: str | None = None,
    ) -> dict[str, int]:
        """Return consultation counts grouped by callee, optionally filtered
        by a ``created_at >= since`` cutoff and/or a ``status`` value.
        """
        sql = "SELECT callee, COUNT(*) AS n FROM consultations"
        conds: list[str] = []
        params: list[Any] = []
        if since is not None:
            conds.append("created_at >= ?")
            params.append(_iso(since))
        if status is not None:
            conds.append("status = ?")
            params.append(status)
        if conds:
            sql += " WHERE " + " AND ".join(conds)
        sql += " GROUP BY callee"
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return {r["callee"]: int(r["n"]) for r in rows}

    def last_consulted_by_callee(self) -> dict[str, datetime]:
        """Return the most-recent ``created_at`` per callee."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT callee, MAX(created_at) AS last_at FROM consultations GROUP BY callee"
            ).fetchall()
        return {r["callee"]: _from_iso(r["last_at"]) for r in rows}

    def top_task_callee(self) -> tuple[str, int] | None:
        """Return (callee, count) of the most-consulted specialist across
        task-scoped consultations only (ignores chat-mode consults).

        Used by the Task insights card so "most called: …" reflects work
        done inside task runs, not casual PS chats.
        """
        with self._lock:
            row = self._conn.execute(
                """
                SELECT callee, COUNT(*) AS n
                FROM consultations
                WHERE task_id IS NOT NULL
                GROUP BY callee
                ORDER BY n DESC, callee ASC
                LIMIT 1
                """
            ).fetchone()
        if row is None:
            return None
        return (row["callee"], int(row["n"]))

    def get_active_running_task(self) -> Task | None:
        """Return the most-recent task still in status='running', if any."""
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM tasks WHERE status = 'running' "
                "ORDER BY started_at DESC LIMIT 1"
            ).fetchone()
        return self._row_to_task(row) if row else None

    def get_last_completed_task(self) -> Task | None:
        """Return the most-recently finished completed task, if any."""
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM tasks WHERE status = 'completed' "
                "ORDER BY finished_at DESC LIMIT 1"
            ).fetchone()
        return self._row_to_task(row) if row else None

    def mark_orphaned_running_tasks_failed(self) -> int:
        """Mark every task in status='running' as failed.

        Called once at server startup. In-memory runtime state (queue +
        background asyncio task) only exists for the lifetime of the
        process, so any row still marked 'running' when a new process
        starts is an orphan from a crashed/killed run. Without this sweep
        those rows would stay 'running' forever in the DB and poison the
        ``/lab/tasks`` list.
        """
        finished = _iso(datetime.now(timezone.utc))
        with self._lock:
            with self._conn:
                cur = self._conn.execute(
                    """
                    UPDATE tasks
                    SET status = 'failed',
                        finished_at = ?,
                        duration_ms = 0,
                        error = 'process died before task completion'
                    WHERE status = 'running'
                    """,
                    (finished,),
                )
                return int(cur.rowcount or 0)

    # ----------------------------------------------------------------- messages

    def _row_to_message(self, r: sqlite3.Row) -> Message:
        return Message(
            id=r["id"],
            from_agent=r["from_agent"],
            text=r["text"],
            priority=r["priority"],
            topic=r["topic"],
            task_id=r["task_id"],
            deposit_ids=json.loads(r["deposit_ids"]),
            created_at=_from_iso(r["created_at"]),
            read_at=_from_iso(r["read_at"]) if r["read_at"] else None,
        )

    def create_message(
        self,
        *,
        from_agent: str,
        text: str,
        priority: MessagePriority,
        topic: str,
        task_id: str | None = None,
        deposit_ids: list[str] | None = None,
    ) -> str:
        message_id = str(uuid.uuid4())
        created = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    INSERT INTO messages (
                        id, from_agent, text, priority, topic,
                        task_id, deposit_ids, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        message_id,
                        from_agent,
                        text,
                        priority,
                        topic,
                        task_id,
                        json.dumps(deposit_ids or []),
                        _iso(created),
                    ),
                )
        return message_id

    def list_messages(
        self, limit: int = 50, unread_only: bool = False
    ) -> list[Message]:
        sql = "SELECT * FROM messages"
        if unread_only:
            sql += " WHERE read_at IS NULL"
        sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
        with self._lock:
            rows = self._conn.execute(sql, (limit,)).fetchall()
        return [self._row_to_message(r) for r in rows]

    def get_message(self, message_id: str) -> Message | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM messages WHERE id = ?", (message_id,)
            ).fetchone()
        return self._row_to_message(row) if row else None

    def mark_message_read(self, message_id: str) -> bool:
        read_at = _iso(datetime.now(timezone.utc))
        with self._lock:
            with self._conn:
                cur = self._conn.execute(
                    "UPDATE messages SET read_at = ? WHERE id = ? AND read_at IS NULL",
                    (read_at, message_id),
                )
                return int(cur.rowcount or 0) > 0

    def mark_all_messages_read(self) -> int:
        read_at = _iso(datetime.now(timezone.utc))
        with self._lock:
            with self._conn:
                cur = self._conn.execute(
                    "UPDATE messages SET read_at = ? WHERE read_at IS NULL",
                    (read_at,),
                )
                return int(cur.rowcount or 0)

    def count_unread_messages(self) -> int:
        with self._lock:
            return int(
                self._conn.execute(
                    "SELECT COUNT(*) FROM messages WHERE read_at IS NULL"
                ).fetchone()[0]
            )

    # -------------------------------------------------------------- query_log

    def log_query(
        self,
        *,
        bag_key: str,
        is_confident: bool,
        has_conflict: bool,
        is_single_sample: bool,
        bag_size: int,
        result_count: int,
    ) -> str:
        """Record one ``field_query_aware`` call's calibration shape.

        Powers Coverage in the Field Maturity Index (``maturity.py``). No
        query text, no author, no PII — just the per-hit confidence shape
        so we can compute rolling hit-rate-of-confident-bags later.
        """
        qid = str(uuid.uuid4())
        created = datetime.now(timezone.utc)
        with self._lock:
            with self._conn:
                self._conn.execute(
                    """
                    INSERT INTO query_log (
                        id, created_at, bag_key, is_confident, has_conflict,
                        is_single_sample, bag_size, result_count
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        qid,
                        _iso(created),
                        bag_key,
                        1 if is_confident else 0,
                        1 if has_conflict else 0,
                        1 if is_single_sample else 0,
                        int(bag_size),
                        int(result_count),
                    ),
                )
        return qid

    def count_queries_since(self, since: datetime) -> tuple[int, int]:
        """Return ``(total_queries, confident_queries)`` with
        ``created_at >= since`` on the query_log. Used by maturity.coverage.
        """
        since_iso = _iso(since)
        with self._lock:
            row = self._conn.execute(
                """
                SELECT
                    COUNT(*)                                     AS total,
                    COALESCE(SUM(is_confident), 0)               AS confident
                FROM query_log
                WHERE created_at >= ?
                """,
                (since_iso,),
            ).fetchone()
        if row is None:
            return (0, 0)
        return (int(row["total"]), int(row["confident"]))

    def contradicted_target_ids(self) -> set[str]:
        """Return the set of deposit ids that are the *target* of at least
        one contradictions edge (``to_deposit_id``). Used by
        ``maturity.resolution`` to detect conflict bags that have been
        metabolized by an explicit refutation edge.
        """
        with self._lock:
            rows = self._conn.execute(
                "SELECT DISTINCT to_deposit_id FROM contradictions"
            ).fetchall()
        return {r["to_deposit_id"] for r in rows}

    # -------------------------------------------------------------- lifecycle

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def __enter__(self) -> "FieldStore":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


__all__ = [
    "Deposit",
    "EvidenceGrade",
    "FieldStore",
    "Message",
    "MessagePriority",
    "Polarity",
    "ReproStatus",
    "Scope",
]
