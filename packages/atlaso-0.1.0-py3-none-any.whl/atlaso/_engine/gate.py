"""Deposit gate policy.

The bar is `expected_harm × scope_breadth`, not polarity. A broad positive
claim ("X always works") needs replicated evidence; a narrow negative claim
needs provenance so the field doesn't fill with "didn't work on my machine"
sludge (search collapse). Open questions are always cheap to record.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

from .store import EvidenceGrade, Polarity, ReproStatus, Scope

_GRADE_ORDER: dict[EvidenceGrade, int] = {
    "anecdotal": 0,
    "observed": 1,
    "replicated": 2,
    "verified": 3,
}

Breadth = Literal["narrow", "broad"]


@dataclass
class GateDecision:
    accept: bool
    reason: str
    required_fields: list[str] = field(default_factory=list)


def _scope_breadth(scope: Scope) -> Breadth:
    facets = [scope.model, scope.dataset, scope.env, scope.version, scope.n, scope.seed]
    filled = sum(1 for f in facets if f is not None)
    return "narrow" if filled >= 2 else "broad"


def _grade_at_least(actual: EvidenceGrade, required: EvidenceGrade) -> bool:
    return _GRADE_ORDER[actual] >= _GRADE_ORDER[required]


def _normalize_role(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def evaluate_deposit_request(
    *,
    content: str,
    polarity: Polarity,
    evidence_grade: EvidenceGrade,
    scope: Scope,
    author: str,
    author_role: str,
    repro_status: ReproStatus,
    artifact_refs: list[str],
    tags: list[str],
    contradicts: list[str] | None = None,
) -> GateDecision:
    breadth = _scope_breadth(scope)

    # Role modifier: RedTeam gets +1 evidence credit on negative/cautionary.
    effective_grade: EvidenceGrade = evidence_grade
    if _normalize_role(author_role) == "redteam" and polarity in ("negative", "cautionary"):
        bumped = min(_GRADE_ORDER[evidence_grade] + 1, _GRADE_ORDER["verified"])
        for grade, idx in _GRADE_ORDER.items():
            if idx == bumped:
                effective_grade = grade
                break

    if polarity == "open":
        return GateDecision(accept=True, reason="open questions are always recordable")

    if polarity == "positive":
        if breadth == "broad":
            if _grade_at_least(effective_grade, "replicated"):
                return GateDecision(accept=True, reason="broad positive with replicated evidence")
            return GateDecision(
                accept=False,
                reason="broad positive claims require replicated evidence",
                required_fields=["evidence_grade>=replicated"],
            )
        # narrow positive
        if _grade_at_least(effective_grade, "observed"):
            return GateDecision(accept=True, reason="narrow positive with observed evidence")
        return GateDecision(
            accept=False,
            reason="narrow positive claims require at least observed evidence",
            required_fields=["evidence_grade>=observed"],
        )

    if polarity == "negative":
        if breadth == "broad":
            if _grade_at_least(effective_grade, "observed"):
                return GateDecision(accept=True, reason="broad negative with observed evidence")
            return GateDecision(
                accept=False,
                reason="broad negative claims require at least observed evidence",
                required_fields=["evidence_grade>=observed"],
            )
        # narrow negative: provenance is the gate, not grade.
        has_provenance = bool(artifact_refs) or scope.env is not None or scope.version is not None
        if has_provenance:
            return GateDecision(accept=True, reason="narrow negative with provenance")
        return GateDecision(
            accept=False,
            reason="narrow negative needs provenance to avoid search collapse",
            required_fields=["artifact_refs", "scope.env", "scope.version"],
        )

    if polarity == "cautionary":
        has_provenance = bool(artifact_refs) or scope.env is not None or scope.version is not None
        if has_provenance:
            return GateDecision(accept=True, reason="cautionary with provenance")
        return GateDecision(
            accept=False,
            reason="cautionary deposits need provenance",
            required_fields=["artifact_refs", "scope.env", "scope.version"],
        )

    # Unknown polarity slips through as a reject so callers see a clear error.
    return GateDecision(
        accept=False,
        reason=f"unknown polarity: {polarity}",
        required_fields=["polarity"],
    )


__all__ = ["GateDecision", "evaluate_deposit_request"]
