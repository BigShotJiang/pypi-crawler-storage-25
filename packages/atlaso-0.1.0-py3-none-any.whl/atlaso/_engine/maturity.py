"""Field Maturity Index (FMI) — a single 0–100 progress score.

Formula (geometric mean of four bounded components in [0, 1]):

    FMI = 100 × (Coverage × Precision × Resolution × Density) ** (1/4)

A weak component pulls FMI down — this is intentional. The four components:

  * Coverage C    — rolling 30-day hit rate of ``is_confident=True`` across
                    logged ``field_query_aware`` calls. Requires the
                    ``query_log`` table (populated by ``aware.query_aware``).
                    Empty log → 0.0.
  * Precision P   — ``AVG(bag_precision)`` over scope bags with size ≥ 2.
                    Single-sample bags have undefined precision at n=1 and
                    are excluded. No multi-sample bags → vacuously 1.0.
  * Resolution R  — ``resolved_conflicts / total_conflicts_ever``. A conflict
                    bag is "resolved" when at least one of its members is the
                    target of a ``contradicts=[id]`` edge (either direction
                    suffices — the bag has been metabolized). No historical
                    conflicts → vacuously 1.0.
  * Density D     — ``1 − (singleton_bags / total_bags)``. Measures whether
                    the field is replicated, not just listed. Empty field →
                    0.0.

Pure SQL over the field DB; zero model queries. Stub-safe: if the store is
the in-memory stub (``FIELD_ALLOW_STUB=1``), ``compute_maturity`` returns a
zero-filled ``MaturityReport`` without crashing.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timezone, datetime, timedelta
from typing import Any

from .aware import compute_all_bag_stats

__all__ = ["MaturityReport", "compute_maturity"]


@dataclass
class MaturityReport:
    """Immutable snapshot of the field's current maturity shape.

    All four components are in ``[0, 1]``; ``fmi`` is the scaled geometric
    mean in ``[0, 100]``. Extra counts are exposed so the UI can render a
    breakdown next to the single-number progress bar without recomputing.
    """

    fmi: float
    coverage: float
    precision: float
    resolution: float
    density: float
    total_deposits: int
    total_bags: int
    multi_deposit_bags: int
    singleton_bags: int
    conflict_bags: int
    resolved_conflict_bags: int
    recent_queries: int
    confident_queries: int


def compute_maturity(store: Any, *, window_days: int = 30) -> MaturityReport:
    """Compute the Field Maturity Index from the current store contents.

    Pure read path: four read-only queries plus one in-memory bag roll-up.
    Stub-safe — any missing method on ``store`` (in-memory stub) degrades
    gracefully to a zero-filled report rather than crashing.
    """

    # --- bag roll-up: drives Precision and Density -----------------------
    try:
        bag_stats = compute_all_bag_stats(store, limit=10_000)
    except Exception:
        # Stub without enough shape, or a real store that choked on the
        # roll-up. Either way, the caller just gets a zeroed report — the
        # tool must never raise into the MCP surface.
        bag_stats = {}

    total_bags = len(bag_stats)
    multi_deposit_bags = sum(1 for s in bag_stats.values() if not s.is_single_sample)
    singleton_bags = sum(1 for s in bag_stats.values() if s.is_single_sample)
    conflict_bags_list = [s for s in bag_stats.values() if s.has_polarity_conflict]
    conflict_bags = len(conflict_bags_list)

    multi_precisions = [
        s.precision for s in bag_stats.values() if not s.is_single_sample
    ]

    # --- Precision: average per-bag dominant-polarity fraction -----------
    # Vacuous-true when there are no multi-sample bags: we can't claim the
    # field is imprecise if it has never been asked to agree with itself.
    precision = (
        sum(multi_precisions) / len(multi_precisions)
        if multi_precisions
        else 1.0
    )

    # --- Density: 1 − singleton share ------------------------------------
    if total_bags == 0:
        density = 0.0
    else:
        density = 1.0 - (singleton_bags / total_bags)

    # --- Resolution: share of historical conflict bags metabolized -------
    # A conflict bag is resolved iff at least one of its members is the
    # target of a contradicts edge. We count the TARGETS across the whole
    # contradictions table once, then intersect with each conflict bag's
    # member set. No conflicts ever → vacuously 1.0.
    try:
        target_ids: set[str] = store.contradicted_target_ids()
    except Exception:
        target_ids = set()

    resolved_conflict_bags = 0
    for bag in conflict_bags_list:
        if any(d.id in target_ids for d in bag.deposits):
            resolved_conflict_bags += 1

    if conflict_bags == 0:
        resolution = 1.0
    else:
        resolution = resolved_conflict_bags / conflict_bags

    # --- Coverage: rolling 30-day confident-query share ------------------
    since = datetime.now(timezone.utc) - timedelta(days=max(1, int(window_days)))
    recent_queries = 0
    confident_queries = 0
    try:
        recent_queries, confident_queries = store.count_queries_since(since)
    except Exception:
        # Stub or pre-migration DB — treat as "no queries logged".
        pass

    if recent_queries == 0:
        coverage = 0.0
    else:
        coverage = confident_queries / recent_queries

    # --- Total deposits (cheap informational count) ----------------------
    try:
        total_deposits = int(store.count())
    except Exception:
        total_deposits = sum(s.size for s in bag_stats.values())

    # --- Geometric mean → FMI --------------------------------------------
    product = coverage * precision * resolution * density
    # Clamp defensively — floats are fine, but callers expect [0, 100].
    if product <= 0.0:
        fmi = 0.0
    else:
        fmi = 100.0 * (product ** 0.25)
    fmi = max(0.0, min(100.0, fmi))

    return MaturityReport(
        fmi=round(fmi, 2),
        coverage=round(coverage, 4),
        precision=round(precision, 4),
        resolution=round(resolution, 4),
        density=round(density, 4),
        total_deposits=total_deposits,
        total_bags=total_bags,
        multi_deposit_bags=multi_deposit_bags,
        singleton_bags=singleton_bags,
        conflict_bags=conflict_bags,
        resolved_conflict_bags=resolved_conflict_bags,
        recent_queries=recent_queries,
        confident_queries=confident_queries,
    )
