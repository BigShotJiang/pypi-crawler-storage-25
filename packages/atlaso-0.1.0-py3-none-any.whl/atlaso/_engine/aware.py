"""Dispersion-aware retrieval for the research-lab field.

Two mechanisms that validated against RedTeam's collision-test falsifier:

  1. Empirical bag precision — group deposits by their scope bag (the six
     scope_* columns) and report per-bag precision as the fraction of
     deposits agreeing on the dominant directional polarity. Singletons
     are flagged separately (precision is undefined at n=1). The naive
     'precision = 1.0 by schema construction' claim is explicitly rejected;
     callers get measured dispersion instead.

  2. Dispersion-aware retrieval — when a bag contains directionally
     conflicting polarities (positive vs negative, positive vs cautionary,
     etc. — `open` is not directional), the retriever returns ALL members
     of the bag plus a `has_conflict=True` flag instead of silently picking
     one. Silent false authority becomes explicit uncertainty.

Mechanism 3 (schema-growable scope via token-diff promotion) is DELIBERATELY
OMITTED from this module. The cross-bag transfer test showed token-diff
rules do not generalize (35.7% accuracy vs 20% null baseline); see deposit
bca4a4be. A human-in-the-loop variant may return later.

All logic is domain-agnostic below the store adapter layer.
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from datetime import timezone, datetime
from typing import Any

from .retrieval import _HALF_LIVES, _decay
from .store import Deposit, FieldStore


# ────────────────────────────────────────────────────────────────── core


def scope_bag(dep: Deposit) -> tuple[tuple[str, Any], ...]:
    """Hashable scope bag keyed on the six structured facets only.
    `scope.note` is prose and explicitly excluded — it's provenance,
    not a facet. Keys are alphabetically sorted so the tuple is
    canonical (query_aware also sorts, so lookups match)."""
    s = dep.scope
    return tuple(sorted([
        ("model", s.model),
        ("dataset", s.dataset),
        ("env", s.env),
        ("version", s.version),
        ("n", s.n),
        ("seed", s.seed),
    ]))


_DIRECTIONAL = frozenset({"positive", "negative", "cautionary"})


@dataclass
class BagStats:
    """Empirical stats for one scope bag. Built from the current field
    contents, recomputed on every query (cheap: 116 deposits → ~60 bags)."""

    deposits: list[Deposit]

    @property
    def size(self) -> int:
        return len(self.deposits)

    @property
    def polarity_counts(self) -> dict[str, int]:
        return dict(Counter(d.polarity for d in self.deposits))

    @property
    def precision(self) -> float:
        """Dominant-polarity fraction. Returns 1.0 for singletons by
        convention but has_single_sample separately signals that the 1.0
        is n=1, not n>=2 unanimous."""
        if not self.deposits:
            return 0.0
        counts = Counter(d.polarity for d in self.deposits)
        return max(counts.values()) / len(self.deposits)

    @property
    def is_single_sample(self) -> bool:
        return self.size == 1

    @property
    def has_polarity_conflict(self) -> bool:
        """True iff the bag contains >=2 directional polarities. `open`
        deposits (unresolved questions) do NOT count as conflict."""
        pols = {d.polarity for d in self.deposits}
        directional = pols & _DIRECTIONAL
        return len(directional) >= 2


def compute_all_bag_stats(store: FieldStore, *, limit: int = 1000) -> dict[tuple, BagStats]:
    """Group every deposit in the store by scope bag. Runs in one SELECT
    + one in-memory group-by. At 116 deposits this is ~200 µs."""
    deposits = store.list_recent(limit=limit)
    buckets: dict[tuple, BagStats] = {}
    for d in deposits:
        key = scope_bag(d)
        if key not in buckets:
            buckets[key] = BagStats(deposits=[])
        buckets[key].deposits.append(d)
    return buckets


# ──────────────────────────────────────────────────────────────── retrieval


@dataclass
class AwareRetrieval:
    """One retrieval result with honest confidence accounting."""

    deposits: list[Deposit]
    bag_precision: float
    is_single_sample: bool
    has_conflict: bool
    conflict_peers: list[str]  # deposit ids of directional conflict members

    @property
    def is_confident(self) -> bool:
        """Confident = multi-sample agreeing bag. Singletons and conflict
        bags are never confident, even if precision shows 1.0."""
        return (
            self.bag_precision >= 0.99
            and not self.is_single_sample
            and not self.has_conflict
        )


def query_aware(
    store: FieldStore,
    *,
    query_text: str | None = None,
    scope_filter: dict[str, Any] | None = None,
    limit: int = 10,
) -> dict[str, Any]:
    """Dispersion-aware retrieval endpoint.

    If ``scope_filter`` is provided, returns deposits whose scope bag matches
    (exact facet values, None meaning 'facet not specified by the filter').
    If ``query_text`` is provided and scope_filter is empty, falls back to
    BM25 text search and then annotates each returned deposit with its bag's
    empirical stats.

    Every deposit in the result is wrapped in its bag's precision/conflict
    accounting — the caller gets 'here is this deposit AND the confidence
    you should attach to it given the other deposits sharing its scope',
    never 'here is the answer' with an implicit precision=1.0.
    """
    bag_stats = compute_all_bag_stats(store, limit=1000)

    results: list[AwareRetrieval] = []

    if scope_filter:
        # Exact-match scope retrieval with dispersion awareness
        q_bag = tuple(sorted(
            (k, scope_filter.get(k)) for k in
            ("model", "dataset", "env", "version", "n", "seed")
        ))
        stats = bag_stats.get(q_bag)
        if stats is not None:
            conflict_peers = [
                d.id for d in stats.deposits
                if d.polarity in _DIRECTIONAL
            ] if stats.has_polarity_conflict else []
            results.append(AwareRetrieval(
                deposits=stats.deposits,
                bag_precision=stats.precision,
                is_single_sample=stats.is_single_sample,
                has_conflict=stats.has_polarity_conflict,
                conflict_peers=conflict_peers,
            ))
    elif query_text:
        # Per-polarity BM25 with freshness decay, mirroring retrieve_for_query's
        # ranking. Without this, a flat BM25 fallback saturates on whichever
        # cluster has the most deposits — surfacing as topic-switch drift in
        # production once a workspace accumulates a dominant cluster. The
        # research-validated lift comes from scope_filter retrieval (above);
        # this BM25 branch is the lab-app's free-text path and needs the same
        # ranking discipline as the legacy retrieve_for_query.
        # Per-polarity k scales with the caller's limit so a request for
        # limit=N still has room to yield up to N bags (otherwise the
        # hardcoded 3+3+2+2 ceiling would silently cap any limit > 10).
        # The 30/30/20/20 distribution preserves retrieve_for_query's
        # default shape at limit=10 (3,3,2,2).
        k_positive = max(1, int(limit * 0.3))
        k_negative = max(1, int(limit * 0.3))
        k_cautionary = max(1, int(limit * 0.2))
        k_open = max(1, int(limit * 0.2))
        now_dt = datetime.now(timezone.utc)
        selected: list[tuple[Deposit, float]] = []
        for polarity_name, k in (
            ("positive", k_positive),
            ("negative", k_negative),
            ("cautionary", k_cautionary),
            ("open", k_open),
        ):
            candidate_limit = max(50, k * 10)
            scored = [
                (d, _decay(score, d.created_at, now_dt, _HALF_LIVES[polarity_name]))
                for d, score in store.search_bm25(
                    query_text, limit=candidate_limit, polarity=polarity_name
                )
            ]
            scored.sort(key=lambda pair: pair[1], reverse=True)
            selected.extend(scored[:k])

        # Cross-polarity sort by decayed score, then bag-dedupe. Polarity
        # slots above guarantee anti-starvation; ranking by decayed score
        # picks the freshest/most-relevant survivor across slots.
        selected.sort(key=lambda pair: pair[1], reverse=True)
        seen_bags: set[tuple] = set()
        for dep, _decayed in selected:
            bag = scope_bag(dep)
            if bag in seen_bags:
                continue
            seen_bags.add(bag)
            stats = bag_stats.get(bag)
            if stats is None:
                continue
            conflict_peers = [
                d.id for d in stats.deposits
                if d.polarity in _DIRECTIONAL
            ] if stats.has_polarity_conflict else []
            results.append(AwareRetrieval(
                deposits=stats.deposits,
                bag_precision=stats.precision,
                is_single_sample=stats.is_single_sample,
                has_conflict=stats.has_polarity_conflict,
                conflict_peers=conflict_peers,
            ))
            if len(results) >= limit:
                break

    # Global health: how calibrated is the field right now?
    all_conflict = sum(1 for s in bag_stats.values() if s.has_polarity_conflict)
    all_multi = sum(1 for s in bag_stats.values() if not s.is_single_sample)
    all_single = sum(1 for s in bag_stats.values() if s.is_single_sample)
    multi_precisions = [
        s.precision for s in bag_stats.values() if not s.is_single_sample
    ]
    avg_multi_precision = (
        sum(multi_precisions) / len(multi_precisions) if multi_precisions else 1.0
    )

    # ── Log exactly ONE row per call, summarizing the top hit. Coverage in
    # maturity.py wants "how often does the field answer the caller", not
    # "how many bags were touched", so per-call granularity is the right
    # unit. A call with zero results is logged as a miss (bag_size=0) so
    # unanswered queries correctly drag coverage down. Best-effort only —
    # any logging failure is swallowed so the retrieval path stays clean.
    try:
        if results:
            top = results[0]
            top_bag_key = json.dumps(
                [[k, v] for (k, v) in scope_bag(top.deposits[0])],
                separators=(",", ":"),
            )
            store.log_query(
                bag_key=top_bag_key,
                is_confident=top.is_confident,
                has_conflict=top.has_conflict,
                is_single_sample=top.is_single_sample,
                bag_size=len(top.deposits),
                result_count=len(results),
            )
        else:
            store.log_query(
                bag_key="",
                is_confident=False,
                has_conflict=False,
                is_single_sample=False,
                bag_size=0,
                result_count=0,
            )
    except Exception:
        # log_query may not exist on the in-memory stub, and we never want
        # logging to break a retrieval. Swallow and move on.
        pass

    return {
        "results": [_aware_to_dict(r) for r in results],
        "field_health": {
            "total_bags": len(bag_stats),
            "singleton_bags": all_single,
            "multi_deposit_bags": all_multi,
            "conflict_bags": all_conflict,
            "avg_multi_precision": round(avg_multi_precision, 3),
        },
    }


# ─────────────────────────────────────────────────────── serialization


def _aware_to_dict(r: AwareRetrieval) -> dict[str, Any]:
    return {
        "bag_precision": round(r.bag_precision, 3),
        "is_single_sample": r.is_single_sample,
        "has_conflict": r.has_conflict,
        "is_confident": r.is_confident,
        "conflict_peers": r.conflict_peers,
        "deposits": [
            {
                "id": d.id,
                "polarity": d.polarity,
                "evidence_grade": d.evidence_grade,
                "author": d.author,
                "content": d.content,
                "scope": {
                    "note": d.scope.note,
                    "model": d.scope.model,
                    "dataset": d.scope.dataset,
                    "env": d.scope.env,
                    "version": d.scope.version,
                    "n": d.scope.n,
                    "seed": d.scope.seed,
                },
                "tags": d.tags,
                "created_at": d.created_at.isoformat(),
            }
            for d in r.deposits
        ],
    }
