"""Centralized docs URLs.

Every `https://docs.atlaso.dev/...` URL referenced anywhere in the SDK
(errors, warnings, docstrings, README) lives here as a named constant.
The CI gate `tools/check_docs_links.py` fetches each URL on release tag
and asserts HTTP 200 + the named fragment anchor exists in the response.

Failing PRs cannot merge; failing release tags cannot publish.
(D11: docs-url-gate. D9: docs URL must exist on day one or warnings are
worse than the original TypeError.)
"""

from __future__ import annotations

DOCS_BASE = "https://docs.atlaso.dev"

# --- Authorization / multi-tenancy ----------------------------------
AUTHORIZATION = f"{DOCS_BASE}/sdk/authorization"
"""Where `for_user()` should be called from (auth layer, never request body)."""

# --- Async safety (D9) ----------------------------------------------
ASYNC_GUIDE = f"{DOCS_BASE}/sdk/async"
"""Linked from SyncInAsyncWarning when sync Memory is called inside an event loop."""

# --- Wire schema (D8) -----------------------------------------------
WIRE_SCHEMA = f"{DOCS_BASE}/sdk/wire-schema"
"""The to_dict() flat-top + 'kind' discriminator contract."""

# --- Field 3.0 mechanism guides (D5, D8, D10) -----------------------
DISPERSION_GUIDE = f"{DOCS_BASE}/sdk/dispersion"
"""is_confident / has_conflict / bag_precision semantics."""

CONTRADICT_GUIDE = f"{DOCS_BASE}/sdk/contradict"
"""Linked from the educational AttributeError on m.update."""

RETRACT_GUIDE = f"{DOCS_BASE}/sdk/retract"
"""Soft tombstones vs hard_delete; reason field; FMI behavior."""

# --- MCP (D11) ------------------------------------------------------
MCP_GUIDE = f"{DOCS_BASE}/sdk/mcp"
"""How to point Claude Code / Cursor / Codex / Windsurf at atlaso[mcp]."""

# --- Framework integrations (D13) -----------------------------------
FRAMEWORK_ROADMAP = f"{DOCS_BASE}/sdk/integrations#roadmap"
"""Linked from the 'this extra is reserved' warning on stub framework extras."""

# All URLs as a flat list — the docs-url-gate iterates this list on every release.
ALL_URLS: tuple[str, ...] = (
    AUTHORIZATION,
    ASYNC_GUIDE,
    WIRE_SCHEMA,
    DISPERSION_GUIDE,
    CONTRADICT_GUIDE,
    RETRACT_GUIDE,
    MCP_GUIDE,
    FRAMEWORK_ROADMAP,
)
