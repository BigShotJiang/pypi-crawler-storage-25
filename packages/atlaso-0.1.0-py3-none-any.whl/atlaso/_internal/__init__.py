"""Internal helpers — NOT part of the public API.

``dataclasses.asdict(deposit)`` and ``dataclasses.asdict(search_result)``
are used by the storage layer and by tests. They are intentionally NOT
stable. Anything that crosses a process boundary must use ``.to_dict()``
instead.

The ``internal-asdict-gate`` CI test fails the build if ``asdict(`` appears
in any module under ``atlaso.api.*``, ``atlaso.adapters.*``, ``atlaso.compat.*``,
or any public re-exported module. (D8 + D11.)
"""
