"""User-bound handles for safe per-user calls.

(D9. The recommended SaaS pattern is ``m.for_user(authenticated_id)`` — a
frozen handle bound at construction; all per-user calls go through it.
There is no ``rebind()`` method. Re-bind by calling ``for_user()`` again.

The handle's existence does NOT add ambient state to the underlying ``Memory``
instance. Each call still passes ``user_id`` explicitly to the transport
layer; the handle is just a per-user view that pre-fills the kwarg.)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._types import EvidenceGrade, Polarity, Scope
    from .async_memory import AsyncMemory
    from .memory import Memory
    from .results import (
        AddItem,
        AddManyResult,
        AddResult,
        Deposit,
        Diagnostics,
        PeekView,
        RetractResult,
        SearchResults,
    )


@dataclass(frozen=True, slots=True)
class UserHandle:
    """A ``Memory`` view bound to one authenticated ``user_id``.

    Construct via ``Memory.for_user(authenticated_id)``. The user_id is
    frozen at construction time; every method on this handle uses that
    bound id. Pass values from your auth layer (``request.session["user_id"]``,
    ``auth.user.id``, etc.), NEVER from request bodies — see
    ``https://docs.atlaso.dev/sdk/authorization``.
    """

    _client: Memory
    _user_id: str

    @property
    def user_id(self) -> str:
        return self._user_id

    def __repr__(self) -> str:
        return f"UserHandle(user_id={self._user_id!r})"

    def add(
        self,
        text: str,
        *,
        polarity: Polarity = "open",
        evidence_grade: EvidenceGrade = "anecdotal",
        scope: Scope | None = None,
        tags: list[str] | None = None,
        contradicts: list[str] | None = None,
        author: str | None = None,
    ) -> AddResult:
        return self._client.add(
            text,
            user_id=self._user_id,
            polarity=polarity,
            evidence_grade=evidence_grade,
            scope=scope,
            tags=tags,
            contradicts=contradicts,
            author=author,
        )

    def recall(
        self,
        query: str,
        *,
        limit: int = 10,
        scope: Scope | None = None,
    ) -> SearchResults:
        return self._client.recall(
            query,
            user_id=self._user_id,
            limit=limit,
            scope=scope,
        )

    def get(self, deposit_id: str) -> Deposit | None:
        return self._client.get(deposit_id, user_id=self._user_id)

    def peek(self, *, limit: int = 10) -> PeekView:
        return self._client.peek(self._user_id, limit=limit)

    def list_recent(self, *, limit: int = 20, offset: int = 0) -> list[Deposit]:
        return self._client.list_recent(
            user_id=self._user_id, limit=limit, offset=offset
        )

    def contradict(
        self,
        new_text: str,
        contradicts: list[str],
        *,
        reason: str,
    ) -> AddResult:
        return self._client.contradict(
            new_text,
            contradicts=contradicts,
            reason=reason,
            user_id=self._user_id,
        )

    def retract(
        self,
        deposit_id: str,
        *,
        reason: str,
        hard_delete: bool = False,
        force: bool = False,
    ) -> RetractResult:
        return self._client.retract(
            deposit_id,
            reason=reason,
            hard_delete=hard_delete,
            force=force,
            user_id=self._user_id,
        )

    def health(self, *, window_days: int = 30) -> Diagnostics:
        return self._client.health(
            user_id=self._user_id, window_days=window_days
        )

    def add_many(
        self,
        items: list[AddItem],
        *,
        on_gate_reject: str = "skip",
    ) -> AddManyResult:
        return self._client.add_many(
            items, user_id=self._user_id, on_gate_reject=on_gate_reject
        )


@dataclass(frozen=True, slots=True)
class AsyncUserHandle:
    """Async mirror of UserHandle. Bound to one user_id; methods are async."""

    _client: AsyncMemory
    _user_id: str

    @property
    def user_id(self) -> str:
        return self._user_id

    def __repr__(self) -> str:
        return f"AsyncUserHandle(user_id={self._user_id!r})"

    async def add(
        self,
        text: str,
        *,
        polarity: Polarity = "open",
        evidence_grade: EvidenceGrade = "anecdotal",
        scope: Scope | None = None,
        tags: list[str] | None = None,
        contradicts: list[str] | None = None,
        author: str | None = None,
    ) -> AddResult:
        return await self._client.add(
            text,
            user_id=self._user_id,
            polarity=polarity,
            evidence_grade=evidence_grade,
            scope=scope,
            tags=tags,
            contradicts=contradicts,
            author=author,
        )

    async def recall(
        self,
        query: str,
        *,
        limit: int = 10,
        scope: Scope | None = None,
    ) -> SearchResults:
        return await self._client.recall(
            query,
            user_id=self._user_id,
            limit=limit,
            scope=scope,
        )

    async def get(self, deposit_id: str) -> Deposit | None:
        return await self._client.get(deposit_id, user_id=self._user_id)

    async def peek(self, *, limit: int = 10) -> PeekView:
        return await self._client.peek(self._user_id, limit=limit)

    async def list_recent(
        self, *, limit: int = 20, offset: int = 0
    ) -> list[Deposit]:
        return await self._client.list_recent(
            user_id=self._user_id, limit=limit, offset=offset
        )

    async def contradict(
        self,
        new_text: str,
        contradicts: list[str],
        *,
        reason: str,
    ) -> AddResult:
        return await self._client.contradict(
            new_text,
            contradicts=contradicts,
            reason=reason,
            user_id=self._user_id,
        )

    async def retract(
        self,
        deposit_id: str,
        *,
        reason: str,
        hard_delete: bool = False,
        force: bool = False,
    ) -> RetractResult:
        return await self._client.retract(
            deposit_id,
            reason=reason,
            hard_delete=hard_delete,
            force=force,
            user_id=self._user_id,
        )

    async def health(self, *, window_days: int = 30) -> Diagnostics:
        return await self._client.health(
            user_id=self._user_id, window_days=window_days
        )

    async def add_many(
        self,
        items: list[AddItem],
        *,
        on_gate_reject: str = "skip",
    ) -> AddManyResult:
        return await self._client.add_many(
            items, user_id=self._user_id, on_gate_reject=on_gate_reject
        )
