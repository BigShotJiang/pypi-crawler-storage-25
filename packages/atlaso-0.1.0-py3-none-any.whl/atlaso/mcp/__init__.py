"""MCP server for Atlaso. Loaded only with the ``[mcp]`` extra installed.

(D11. Same Field 3.0 vocabulary as the Python API, exposed over stdio MCP
so any MCP client — Claude Code, Cursor, Codex, Windsurf, Cline — gets
Atlaso for free with zero per-framework code.)
"""

from __future__ import annotations

try:
    from .server import build_server, main, run

    __all__ = ["build_server", "main", "run"]
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "atlaso.mcp requires the [mcp] extra. Install with:\n"
        "    pip install atlaso[mcp]"
    ) from e
