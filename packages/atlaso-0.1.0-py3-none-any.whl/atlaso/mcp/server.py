"""FastMCP wrapper exposing the Atlaso public API as MCP tools.

(D11. Engine ≠ transport — the lab-app has its own MCP wrapper for the
Tauri sidecar; this is a separate vanilla FastMCP stdio server for any
MCP client.)

Run with::

    pip install atlaso[mcp]
    python -m atlaso mcp                  # stdio MCP server

In a Claude Code config::

    {
      "mcpServers": {
        "atlaso": {
          "command": "python",
          "args": ["-m", "atlaso", "mcp"],
          "env": {"ATLASO_API_KEY": "..."}
        }
      }
    }
"""

from __future__ import annotations

import os
import sys
from typing import Any

try:
    from fastmcp import FastMCP
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "atlaso.mcp requires the [mcp] extra. Install with:\n"
        "    pip install atlaso[mcp]"
    ) from e

from ..memory import Memory


def build_server(memory: Memory | None = None) -> FastMCP:
    """Build the FastMCP server with the seven Atlaso verbs registered as tools.

    If ``memory`` is None, builds a default ``Memory()`` reading config from
    env vars (``ATLASO_API_KEY``, ``ATLASO_BASE_URL``).
    """
    server: FastMCP = FastMCP("atlaso")
    mem = memory or Memory()

    @server.tool()
    def add(
        content: str,
        user_id: str,
        polarity: str = "open",
        evidence_grade: str = "anecdotal",
        scope_note: str = "",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Write a new memory deposit.

        polarity: positive | negative | cautionary | open  (default: open)
        evidence_grade: anecdotal | observed | replicated | verified  (default: anecdotal)
        """
        from .._types import Scope

        result = mem.add(
            content,
            user_id=user_id,
            polarity=polarity,  # type: ignore[arg-type]
            evidence_grade=evidence_grade,  # type: ignore[arg-type]
            scope=Scope(note=scope_note) if scope_note else None,
            tags=tags or [],
        )
        return result.to_dict()

    @server.tool()
    def recall(
        query: str,
        user_id: str,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Retrieve memories with dispersion-aware results.

        Each result carries is_confident, has_disagreement, agreement_score,
        conflict_peers — the +10pp benchmark mechanism.
        """
        results = mem.recall(query, user_id=user_id, limit=limit)
        return {
            "kind": "search_results",
            "items": [r.to_dict() for r in results],
            "explanation": results.explain(),
            "has_disagreement": results.has_disagreement,
            "is_confident": results.is_confident,
        }

    @server.tool()
    def get(deposit_id: str, user_id: str) -> dict[str, Any] | None:
        """Fetch a single deposit by id. Returns None on miss."""
        d = mem.get(deposit_id, user_id=user_id)
        return d.to_dict() if d is not None else None

    @server.tool()
    def list_recent(user_id: str, limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
        """Newest-first list of recent deposits."""
        return [d.to_dict() for d in mem.list_recent(user_id=user_id, limit=limit, offset=offset)]

    @server.tool()
    def contradict(
        new_text: str,
        contradicts: list[str],
        reason: str,
        user_id: str,
    ) -> dict[str, Any]:
        """Deposit a new finding that supersedes existing ones, atomically."""
        result = mem.contradict(
            new_text,
            contradicts=contradicts,
            reason=reason,
            user_id=user_id,
        )
        return result.to_dict()

    @server.tool()
    def retract(
        deposit_id: str,
        reason: str,
        user_id: str,
        hard_delete: bool = False,
    ) -> dict[str, Any]:
        """Retract a deposit. Soft tombstone by default."""
        result = mem.retract(
            deposit_id,
            reason=reason,
            hard_delete=hard_delete,
            user_id=user_id,
        )
        return result.to_dict()

    @server.tool()
    def health(user_id: str, window_days: int = 30) -> dict[str, Any]:
        """Field Maturity Index snapshot for one user."""
        d = mem.health(user_id=user_id, window_days=window_days)
        return {**d.to_dict(), "explanation": d.explain()}

    @server.tool()
    def peek(user_id: str, limit: int = 10) -> dict[str, Any]:
        """Snapshot of a user's recent deposits — what's in the field for this user."""
        view = mem.peek(user_id, limit=limit)
        return {
            "kind": "peek_view",
            "user_id": view.user_id,
            "total_count": view.total_count,
            "fmi": view.fmi,
            "has_recent_disagreements": view.has_recent_disagreements,
            "deposits": [d.to_dict() for d in view.deposits],
        }

    @server.tool()
    def add_many(
        user_id: str,
        items: list[dict[str, Any]],
        on_gate_reject: str = "skip",
    ) -> dict[str, Any]:
        """Bulk-add deposits with per-item idempotency keys.

        Each item is a dict with at least 'content' and 'idempotency_key';
        optional 'polarity', 'evidence_grade', 'tags', 'contradicts'.
        """
        from .._types import Scope as _Scope
        from ..results import AddItem as _AddItem

        bulk_items = [
            _AddItem(
                content=it["content"],
                idempotency_key=it["idempotency_key"],
                polarity=it.get("polarity", "open"),  # type: ignore[arg-type]
                evidence_grade=it.get("evidence_grade", "anecdotal"),  # type: ignore[arg-type]
                scope=_Scope(note=it["scope_note"]) if it.get("scope_note") else None,
                tags=tuple(it.get("tags") or ()),
                contradicts=tuple(it.get("contradicts") or ()),
            )
            for it in items
        ]
        result = mem.add_many(bulk_items, user_id=user_id, on_gate_reject=on_gate_reject)
        return {
            "kind": "add_many_result",
            "committed": [d.to_dict() for d in result.committed],
            "duplicates": [d.to_dict() for d in result.duplicates],
            "failed": [
                {"index": r.index, "error": str(r.error), "content": r.item.content}
                for r in result.failed
            ],
            "is_partial": result.is_partial,
        }

    return server


def run(memory: Memory | None = None) -> None:
    """Run the MCP server over stdio. Blocks until the client disconnects."""
    build_server(memory).run()


def main(argv: list[str] | None = None) -> int:
    """``python -m atlaso mcp`` entry point. Returns 0 on clean exit."""
    _ = argv  # reserved for future flags
    if not os.environ.get("ATLASO_API_KEY"):
        print(
            "atlaso[mcp]: ATLASO_API_KEY is not set. The MCP server will start "
            "but every tool call will fail with AuthenticationError until you "
            "set it. See https://docs.atlaso.dev/sdk/mcp for setup.",
            file=sys.stderr,
        )
    run()
    return 0
