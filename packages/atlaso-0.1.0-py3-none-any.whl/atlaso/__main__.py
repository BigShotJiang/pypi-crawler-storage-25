"""Atlaso CLI entry point.

Once ``pip install atlaso`` is in place, the ``atlaso`` command is on
PATH and these subcommands are usable directly from bash::

    atlaso add "Alice prefers oat milk" --user alice
    atlaso recall "coffee" --user alice
    atlaso peek alice
    atlaso health alice
    atlaso list-recent alice
    atlaso get <deposit_id> --user alice
    atlaso contradict <new_text> <old_id> --user alice --reason "..."
    atlaso retract <deposit_id> --user alice --reason "..." [--hard]
    atlaso doctor
    atlaso mcp
    atlaso demo

Add ``--json`` to most commands to get machine-parseable output for
piping into ``jq`` or other scripts.

Until ``pip install atlaso`` lands you can also call::

    python -m atlaso <command> [args...]

The same dispatcher serves both invocations.
"""

from __future__ import annotations

import argparse
import json as _json
import os
import sys
from typing import Any, NoReturn

# --- Helpers ------------------------------------------------------

def _emit(value: Any, json_out: bool) -> None:
    """Print either a human-readable form or a JSON dict, depending on flag."""
    if json_out:
        if hasattr(value, "to_dict"):
            print(_json.dumps(value.to_dict(), indent=2, default=str))
        elif isinstance(value, list):
            print(_json.dumps(
                [v.to_dict() if hasattr(v, "to_dict") else v for v in value],
                indent=2,
                default=str,
            ))
        else:
            print(_json.dumps(value, indent=2, default=str))
        return
    print(value)


def _print_help() -> None:
    print(__doc__ or "atlaso CLI", file=sys.stderr)


# --- Subcommand handlers -----------------------------------------

def _cmd_version(args: argparse.Namespace) -> int:
    from importlib.metadata import version

    try:
        print(version("atlaso"))
    except Exception:
        from . import __version__

        print(f"{__version__} (development)")
    return 0


def _cmd_check(args: argparse.Namespace) -> int:
    from . import __version__

    print(f"atlaso {__version__} — install OK")
    try:
        import atlaso.mcp  # noqa: F401

        print("  atlaso[mcp]: available")
    except ImportError:
        print("  atlaso[mcp]: not installed (pip install atlaso[mcp])")
    return 0


def _cmd_add(args: argparse.Namespace) -> int:
    from . import Memory, Scope

    m = Memory()
    scope = Scope(note=args.scope_note) if args.scope_note else None
    result = m.add(
        args.text,
        user_id=args.user,
        polarity=args.polarity,
        evidence_grade=args.evidence,
        scope=scope,
        tags=list(args.tag or ()),
    )
    if args.json:
        _emit(result, json_out=True)
    else:
        print(f"saved deposit {result.id}")
    return 0


def _cmd_recall(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    hits = m.recall(args.query, user_id=args.user, limit=args.limit)
    if args.json:
        print(_json.dumps(
            {
                "verdict": hits.explain(),
                "has_disagreement": hits.has_disagreement,
                "is_confident": hits.is_confident,
                "items": [h.to_dict() for h in hits],
            },
            indent=2,
            default=str,
        ))
        return 0
    print(hits.explain())
    for h in hits:
        marker = "⚠" if h.has_disagreement else ("✓" if h.is_confident else "·")
        print(f"  {marker} {h.content}")
        if args.explain:
            print(f"    └─ {h.explain()}")
    return 0


def _cmd_get(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    dep = m.get(args.deposit_id, user_id=args.user)
    if dep is None:
        print(f"deposit {args.deposit_id!r} not found", file=sys.stderr)
        return 1
    _emit(dep, json_out=args.json)
    return 0


def _cmd_list_recent(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    rows = m.list_recent(user_id=args.user, limit=args.limit, offset=args.offset)
    if args.json:
        print(_json.dumps([d.to_dict() for d in rows], indent=2, default=str))
        return 0
    if not rows:
        print(f"(no deposits for user_id={args.user!r})")
        return 0
    for d in rows:
        preview = (d.content[:80] + "…") if len(d.content) > 80 else d.content
        print(f"{d.id[:8]}…  [{d.polarity:11s}]  {preview}")
    return 0


def _cmd_peek(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    view = m.peek(args.user, limit=args.limit)
    if args.json:
        _emit(
            {
                "user_id": view.user_id,
                "total_count": view.total_count,
                "fmi": view.fmi,
                "deposits": [d.to_dict() for d in view],
            },
            json_out=True,
        )
        return 0
    print(view)
    return 0


def _cmd_health(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    diag = m.health(user_id=args.user, window_days=args.window)
    if args.json:
        out = diag.to_dict()
        out["verdict"] = diag.explain()
        print(_json.dumps(out, indent=2, default=str))
        return 0
    print(diag)
    print()
    print(diag.explain())
    return 0


def _cmd_contradict(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    result = m.contradict(
        args.new_text,
        contradicts=args.contradicts,
        reason=args.reason,
        user_id=args.user,
    )
    if args.json:
        _emit(result, json_out=True)
    else:
        print(f"recorded as deposit {result.id}; old deposit(s) marked as superseded.")
    return 0


def _cmd_retract(args: argparse.Namespace) -> int:
    from . import Memory

    m = Memory()
    result = m.retract(
        args.deposit_id,
        user_id=args.user,
        reason=args.reason,
        hard_delete=args.hard,
    )
    if args.json:
        _emit(result, json_out=True)
    else:
        print(f"{result.deposit_id} retracted ({result.mode})")
    return 0


def _cmd_doctor(args: argparse.Namespace) -> int:
    return _doctor()


def _doctor() -> int:
    """End-to-end install + storage + engine health check."""
    import tempfile
    from pathlib import Path

    failures: list[str] = []

    print("atlaso doctor")
    print("─" * 50)

    try:
        from . import __version__

        print(f"  ✓ atlaso {__version__} importable")
    except Exception as e:
        print(f"  ✗ atlaso import failed: {e}")
        return 1

    try:
        from ._engine import store  # noqa: F401

        print("  ✓ Field 3.0 engine vendored")
    except ImportError as e:
        print(f"  ✗ engine missing: {e}")
        print("    fix: re-vendor with `python tools/vendor_engine.py`")
        failures.append("engine")

    try:
        from ._path_resolver import resolve_storage_path

        resolved = resolve_storage_path()
        env_path = os.environ.get("ATLASO_PATH")
        source = "ATLASO_PATH env" if env_path else "auto-resolved"
        print(f"  ✓ storage path: {resolved}  ({source})")
    except Exception as e:
        print(f"  ✗ path resolution failed: {e}")
        failures.append("path")

    try:
        from . import Memory

        with tempfile.TemporaryDirectory() as td:
            m = Memory(path=Path(td) / "doctor")
            r = m.add("doctor smoke test", user_id="_doctor")
            assert r.id, "add() returned no id"
            hits = m.recall("doctor", user_id="_doctor")
            assert any("doctor smoke" in h.content for h in hits), "recall did not find the deposit"
            m.retract(r.id, reason="doctor cleanup", user_id="_doctor")
        print("  ✓ engine round-trip (add → recall → retract)")
    except Exception as e:
        print(f"  ✗ engine round-trip failed: {type(e).__name__}: {e}")
        failures.append("round-trip")

    try:
        import atlaso.mcp  # noqa: F401

        print("  ✓ atlaso[mcp] installed (run: atlaso mcp)")
    except ImportError:
        print("  · atlaso[mcp] not installed (optional; pip install atlaso[mcp])")

    if os.environ.get("ATLASO_TELEMETRY"):
        raw = os.environ.get("ATLASO_TELEMETRY", "")
        print(f"  · ATLASO_TELEMETRY={raw!r} (no-op in this version)")

    print("─" * 50)
    if failures:
        print(f"FAIL: {len(failures)} check(s) failed: {failures}")
        return 1
    print("OK — atlaso is healthy.")
    return 0


def _cmd_mcp(args: argparse.Namespace) -> int:
    try:
        from .mcp.server import main as mcp_main
    except ImportError:
        print(
            "atlaso[mcp] is not installed. Install with:\n"
            "    pip install atlaso[mcp]",
            file=sys.stderr,
        )
        return 1
    return mcp_main([])


def _cmd_install_hooks(args: argparse.Namespace) -> int:
    """Wire Atlaso into Claude Code via UserPromptSubmit + Stop hooks.

    Merges into ~/.claude/settings.json (or .claude/settings.json with
    --scope=project) non-destructively — preserves any existing hooks.
    """
    import shutil
    from pathlib import Path

    # 1. Locate the hook scripts (ship with the SDK source, fall back to
    #    a per-user copy if running from an installed wheel).
    here = Path(__file__).resolve().parent
    candidates = [
        here.parent.parent.parent / "examples" / "hooks",  # checkout
        here.parent.parent / "examples" / "hooks",          # alternate
        Path.home() / ".atlaso" / "hooks",                  # installed location
    ]
    src_hooks = next((p for p in candidates if p.is_dir()), None)
    if src_hooks is None:
        print(
            "atlaso install-hooks: could not find hook scripts. "
            "Either run from a source checkout or copy them manually from "
            "atlaso/sdk/examples/hooks/.",
            file=sys.stderr,
        )
        return 1

    # 2. Copy scripts to a stable per-user location so they survive
    #    moves of the source repo.
    install_dir = Path.home() / ".atlaso" / "hooks"
    install_dir.mkdir(parents=True, exist_ok=True)
    recall_script = install_dir / "atlaso_recall_hook.sh"
    deposit_script = install_dir / "atlaso_deposit_hook.sh"
    shutil.copy2(src_hooks / "atlaso_recall_hook.sh", recall_script)
    shutil.copy2(src_hooks / "atlaso_deposit_hook.sh", deposit_script)
    recall_script.chmod(0o755)
    deposit_script.chmod(0o755)

    # 3. Locate target settings.json (per scope)
    if args.scope == "project":
        target = Path(args.project_dir or os.getcwd()) / ".claude" / "settings.json"
    else:
        target = Path.home() / ".claude" / "settings.json"
    target.parent.mkdir(parents=True, exist_ok=True)

    # 4. Merge hook entries into settings.json non-destructively.
    if target.exists():
        with open(target) as f:
            settings = _json.load(f)
    else:
        settings = {}

    settings.setdefault("hooks", {})
    hooks = settings["hooks"]

    # Idempotency marker — skip if already installed
    marker = "atlaso_recall_hook.sh"

    def _has_atlaso(event: str) -> bool:
        for entry in hooks.get(event, []):
            for h in entry.get("hooks", []):
                if marker in h.get("command", "") or "atlaso_deposit_hook" in h.get("command", ""):
                    return True
        return False

    # UserPromptSubmit — recall (sync, blocks the agent until context lands)
    if not _has_atlaso("UserPromptSubmit"):
        hooks.setdefault("UserPromptSubmit", []).append({
            "hooks": [
                {
                    "type": "command",
                    "command": str(recall_script),
                    "timeout": 15,
                }
            ]
        })

    # Stop — deposit (async, never blocks the user)
    if not _has_atlaso("Stop"):
        hooks.setdefault("Stop", []).append({
            "hooks": [
                {
                    "type": "command",
                    "command": str(deposit_script),
                    "timeout": 10,
                    "async": True,
                }
            ]
        })

    with open(target, "w") as f:
        _json.dump(settings, f, indent=2)
        f.write("\n")

    print(f"✓ Installed hook scripts to: {install_dir}")
    print(f"✓ Wired into:                {target}")
    print()
    print(f"user_id resolution: ATLASO_USER env var, fallback to $USER ({os.environ.get('USER', 'me')!r})")
    print()
    print("Restart Claude Code to activate. Then in any session:")
    print("  - Every user prompt → atlaso recall <prompt> → results injected as context")
    print("  - Every turn end → atlaso add <last text> --tag claude-code (async)")
    print()
    print("To uninstall: atlaso uninstall-hooks")
    return 0


def _cmd_uninstall_hooks(args: argparse.Namespace) -> int:
    """Remove Atlaso hook entries from settings.json (leaves other hooks alone)."""
    from pathlib import Path

    if args.scope == "project":
        target = Path(args.project_dir or os.getcwd()) / ".claude" / "settings.json"
    else:
        target = Path.home() / ".claude" / "settings.json"
    if not target.exists():
        print(f"(no {target} found — nothing to uninstall)")
        return 0

    with open(target) as f:
        settings = _json.load(f)

    hooks = settings.get("hooks", {})
    removed = 0
    for event in list(hooks.keys()):
        entries = hooks[event]
        new_entries = []
        for entry in entries:
            sub_hooks = entry.get("hooks", [])
            filtered = [
                h for h in sub_hooks
                if "atlaso_recall_hook" not in h.get("command", "")
                and "atlaso_deposit_hook" not in h.get("command", "")
            ]
            removed += len(sub_hooks) - len(filtered)
            if filtered:
                new_entries.append({**entry, "hooks": filtered})
        if new_entries:
            hooks[event] = new_entries
        else:
            del hooks[event]

    if not hooks:
        settings.pop("hooks", None)

    with open(target, "w") as f:
        _json.dump(settings, f, indent=2)
        f.write("\n")

    print(f"✓ Removed {removed} atlaso hook(s) from {target}")
    print("  (hook scripts at ~/.atlaso/hooks/ left in place; delete manually if you want)")
    return 0


def _cmd_demo(args: argparse.Namespace) -> int:
    import importlib.util
    from pathlib import Path

    here = Path(__file__).resolve().parent
    candidates = [
        here.parent.parent.parent / "demo.py",
        here.parent.parent / "demo.py",
        Path.cwd() / "demo.py",
    ]
    demo_path = next((p for p in candidates if p.exists()), None)
    if demo_path is None:
        print(
            "atlaso demo: could not find demo.py. "
            "Clone the source repo or copy demo.py from the docs.",
            file=sys.stderr,
        )
        return 1
    spec = importlib.util.spec_from_file_location("_atlaso_demo", demo_path)
    if spec is None or spec.loader is None:
        return 1
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return int(mod.main())


# --- Argparse plumbing -------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="atlaso",
        description=(
            "Atlaso CLI — interact with your memory store from the shell. "
            "Every subcommand mirrors a Memory() method and an MCP tool."
        ),
    )
    sub = parser.add_subparsers(dest="cmd", metavar="COMMAND")

    # version / check / doctor / mcp / demo (no per-user args)
    sub.add_parser("version", help="Print SDK version").set_defaults(fn=_cmd_version)
    sub.add_parser("check", help="Sanity check the install").set_defaults(fn=_cmd_check)
    sub.add_parser("doctor", help="Diagnose install + storage + engine health").set_defaults(fn=_cmd_doctor)
    sub.add_parser("mcp", help="Run the FastMCP stdio server (requires [mcp] extra)").set_defaults(fn=_cmd_mcp)
    sub.add_parser("demo", help="Run the end-to-end narrated demo").set_defaults(fn=_cmd_demo)

    # install-hooks / uninstall-hooks
    p_install = sub.add_parser(
        "install-hooks",
        help="Wire Atlaso into Claude Code (auto-recall before prompts, "
             "auto-deposit after turns)",
    )
    p_install.add_argument("--scope", choices=("user", "project"), default="user",
                           help="user = ~/.claude/settings.json (default); "
                                "project = .claude/settings.json in --project-dir")
    p_install.add_argument("--project-dir", default=None,
                           help="Project root for --scope=project (default: cwd)")
    p_install.set_defaults(fn=_cmd_install_hooks)

    p_uninstall = sub.add_parser(
        "uninstall-hooks", help="Remove Atlaso hook entries from settings.json"
    )
    p_uninstall.add_argument("--scope", choices=("user", "project"), default="user")
    p_uninstall.add_argument("--project-dir", default=None)
    p_uninstall.set_defaults(fn=_cmd_uninstall_hooks)

    # add
    p_add = sub.add_parser("add", help="Save a memory deposit")
    p_add.add_argument("text", help="The fact to remember")
    p_add.add_argument("--user", required=True, help="user_id (your auth identity)")
    p_add.add_argument("--polarity", default="open",
                       choices=("positive", "negative", "cautionary", "open"))
    p_add.add_argument("--evidence", default="anecdotal",
                       choices=("anecdotal", "observed", "replicated", "verified"))
    p_add.add_argument("--scope-note", default=None,
                       help="Optional scope note (free text describing context)")
    p_add.add_argument("--tag", action="append",
                       help="Tag (repeat for multiple)")
    p_add.add_argument("--json", action="store_true", help="Output JSON")
    p_add.set_defaults(fn=_cmd_add)

    # recall
    p_recall = sub.add_parser("recall", help="Search memory; results carry confidence flags")
    p_recall.add_argument("query", help="Natural-language query")
    p_recall.add_argument("--user", required=True)
    p_recall.add_argument("--limit", type=int, default=10)
    p_recall.add_argument("--explain", action="store_true",
                          help="Print hit.explain() for each result")
    p_recall.add_argument("--json", action="store_true")
    p_recall.set_defaults(fn=_cmd_recall)

    # get
    p_get = sub.add_parser("get", help="Fetch a deposit by id")
    p_get.add_argument("deposit_id")
    p_get.add_argument("--user", required=True)
    p_get.add_argument("--json", action="store_true")
    p_get.set_defaults(fn=_cmd_get)

    # list-recent
    p_list = sub.add_parser("list-recent", help="Newest-first list of deposits")
    p_list.add_argument("--user", required=True)
    p_list.add_argument("--limit", type=int, default=20)
    p_list.add_argument("--offset", type=int, default=0)
    p_list.add_argument("--json", action="store_true")
    p_list.set_defaults(fn=_cmd_list_recent)

    # peek (positional user_id for fast typing)
    p_peek = sub.add_parser("peek", help="Snapshot of recent deposits + FMI")
    p_peek.add_argument("user", help="user_id to peek at")
    p_peek.add_argument("--limit", type=int, default=10)
    p_peek.add_argument("--json", action="store_true")
    p_peek.set_defaults(fn=_cmd_peek)

    # health (positional user_id)
    p_health = sub.add_parser("health", help="Field Maturity Index for one user")
    p_health.add_argument("user")
    p_health.add_argument("--window", type=int, default=30,
                          help="Look-back window in days (default 30)")
    p_health.add_argument("--json", action="store_true")
    p_health.set_defaults(fn=_cmd_health)

    # contradict
    p_contra = sub.add_parser("contradict", help="Deposit a finding that supersedes existing ones")
    p_contra.add_argument("new_text", help="The new claim")
    p_contra.add_argument("contradicts", nargs="+",
                          help="Deposit id(s) being superseded")
    p_contra.add_argument("--user", required=True)
    p_contra.add_argument("--reason", required=True,
                          help="Audit-trail reason (required)")
    p_contra.add_argument("--json", action="store_true")
    p_contra.set_defaults(fn=_cmd_contradict)

    # retract
    p_ret = sub.add_parser("retract", help="Retract a deposit (soft tombstone by default)")
    p_ret.add_argument("deposit_id")
    p_ret.add_argument("--user", required=True)
    p_ret.add_argument("--reason", required=True,
                       help="Audit-trail reason (required)")
    p_ret.add_argument("--hard", action="store_true",
                       help="Hard delete (GDPR/PII escape — purges FTS index too)")
    p_ret.add_argument("--json", action="store_true")
    p_ret.set_defaults(fn=_cmd_retract)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "fn", None):
        parser.print_help()
        return 2
    try:
        return int(args.fn(args))
    except SystemExit:
        raise
    except Exception as e:
        # Pedagogical: print the error type + message, NOT a stack trace,
        # for shell-friendly UX. Use --json with a wrapping `set -e` if you
        # need machine-readable failure semantics.
        print(f"atlaso {args.cmd}: {type(e).__name__}: {e}", file=sys.stderr)
        return 1


def _entry() -> NoReturn:  # pragma: no cover
    sys.exit(main())


if __name__ == "__main__":  # pragma: no cover
    _entry()
