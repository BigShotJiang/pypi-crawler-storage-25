"""Public dataclasses returned by Memory.add / .recall / .health.

(D8 + D10. Composition over inheritance — ``isinstance(SearchResult, Deposit)``
is False on purpose. ``to_dict()`` is the public wire format with flat-top
keys + ``"kind"`` discriminator. ``dataclasses.asdict()`` is internal-only,
enforced by the ``internal-asdict-gate`` CI grep.)
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ._types import EvidenceGrade, Polarity, ReproStatus, Scope

# --- Deposit (the immutable evidence record) ----------------------

@dataclass(frozen=True, slots=True)
class Deposit:
    """A Field 3.0 memory record.

    Returned by ``m.add()``, ``m.contradict()``, and accessible via
    ``SearchResult.deposit``. Immutable (`frozen=True`) — Atlaso has no
    ``update()``; revise by depositing a new finding with
    ``contradicts=[old_id]``.
    """

    id: str
    """Stable, unique deposit id assigned by the engine."""

    content: str
    """The text claim itself."""

    polarity: Polarity
    """One of ``"positive" | "negative" | "cautionary" | "open"``."""

    evidence_grade: EvidenceGrade
    """One of ``"anecdotal" | "observed" | "replicated" | "verified"``."""

    scope: Scope
    """The six experimental scope facets."""

    user_id: str
    """The user_id this deposit belongs to (D9 identity column)."""

    tags: tuple[str, ...] = ()
    """Free-form labels (strings) attached to this deposit. Used for filtering."""

    contradicts: tuple[str, ...] = ()
    """Deposit ids this finding refutes / supersedes."""

    artifact_refs: tuple[str, ...] = ()
    """External artifact pointers (file paths, URLs, etc.)."""

    created_at: datetime = field(default_factory=datetime.utcnow)
    """ISO-8601 timestamp at engine commit."""

    author: str | None = None
    """Optional author identifier."""

    author_role: str | None = None
    """Field 3.0 author role: lab_director, sdk_architect, etc."""

    repro_status: ReproStatus = "unreplicated"
    """Reproducibility status for pipeline-level claims (D8 invariant)."""

    task_id: str | None = None
    """Optional task linkage — groups deposits made during a task-mode run."""

    def to_dict(self) -> dict[str, Any]:
        """Stable flat wire representation. Pin to SDK major version.

        Use this everywhere the payload leaves Atlaso: MCP adapters, REST
        bodies, queue messages, audit logs, row caches.

        ``dataclasses.asdict(self)`` is internal-only and not stable — the
        ``internal-asdict-gate`` CI test fails the build if ``asdict(`` appears
        in any module under ``atlaso.api.*``, ``atlaso.adapters.*``, or
        ``atlaso.compat.*``.
        """
        return {
            "kind": "deposit",
            "id": self.id,
            "content": self.content,
            "polarity": self.polarity,
            "evidence_grade": self.evidence_grade,
            "scope": {
                "note": self.scope.note,
                "model": self.scope.model,
                "dataset": self.scope.dataset,
                "env": self.scope.env,
                "version": self.scope.version,
                "n": self.scope.n,
                "seed": self.scope.seed,
            },
            "user_id": self.user_id,
            "tags": list(self.tags),
            "author": self.author,
            "author_role": self.author_role,
            "repro_status": self.repro_status,
            "task_id": self.task_id,
            "contradicts": list(self.contradicts),
            "artifact_refs": list(self.artifact_refs),
            "created_at": self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        """REPL/Jupyter-friendly compact rendering."""
        preview = (self.content[:57] + "...") if len(self.content) > 60 else self.content
        return (
            f"Deposit(id={self.id[:8]}…, polarity={self.polarity!r}, "
            f"evidence={self.evidence_grade!r}, content={preview!r})"
        )


# --- SearchResult (one retrieval hit, NOT a Deposit) --------------

@dataclass(frozen=True, slots=True)
class SearchResult:
    """A single retrieval hit. Wraps a ``Deposit`` (Has-A, NOT Is-A).

    ``isinstance(r, Deposit)`` is **False** on purpose — caches keyed on
    that check would otherwise silently drop the dispersion fields and
    turn a conflicted hit into an authoritative-looking row. The hot-path
    Deposit fields are forwarded via explicit ``@property`` aliases below.
    """

    deposit: Deposit
    """The underlying immutable deposit."""

    score: float
    """BM25 retrieval score."""

    is_confident: bool
    """Composite: multi-sample bag AND no conflict AND agreement_score ≥ 0.99."""

    has_disagreement: bool
    """At least 2 directional polarities in this scope-bag disagree.

    Renamed from ``has_conflict`` per D10 (less escalatory; contradiction
    edges in the data model are unaffected).
    """

    agreement_score: float
    """Dominant-polarity fraction in this scope-bag (0..1).

    Renamed from ``bag_precision`` per D10 (research-internal jargon →
    metric meaning travels).
    """

    is_thin_evidence: bool
    """This bag has only one deposit; treat as a lead, not a finding.

    Renamed from ``is_single_sample`` per D10 (statistician language →
    developer affordance).
    """

    conflict_peers: tuple[str, ...] = ()
    """Other deposit ids in the same bag that disagree with this one."""

    # --- Hot-path aliases — explicit, IDE-discoverable, no __getattr__ magic
    @property
    def id(self) -> str:
        return self.deposit.id

    @property
    def content(self) -> str:
        return self.deposit.content

    @property
    def polarity(self) -> Polarity:
        return self.deposit.polarity

    @property
    def evidence_grade(self) -> EvidenceGrade:
        return self.deposit.evidence_grade

    @property
    def scope(self) -> Scope:
        return self.deposit.scope

    @property
    def tags(self) -> tuple[str, ...]:
        return self.deposit.tags

    def to_dict(self) -> dict[str, Any]:
        """Stable flat wire representation — flattens deposit fields to top level.

        Includes the ``"kind"`` discriminator so a downstream router can tell
        a search result from a raw deposit without inferring from field
        presence.
        """
        return {
            "kind": "search_result",
            "id": self.deposit.id,
            "content": self.deposit.content,
            "polarity": self.deposit.polarity,
            "evidence_grade": self.deposit.evidence_grade,
            "scope": {
                "note": self.deposit.scope.note,
                "model": self.deposit.scope.model,
                "dataset": self.deposit.scope.dataset,
                "env": self.deposit.scope.env,
                "version": self.deposit.scope.version,
                "n": self.deposit.scope.n,
                "seed": self.deposit.scope.seed,
            },
            "user_id": self.deposit.user_id,
            "tags": list(self.deposit.tags),
            "contradicts": list(self.deposit.contradicts),
            "repro_status": self.deposit.repro_status,
            "task_id": self.deposit.task_id,
            "created_at": self.deposit.created_at.isoformat(),
            "is_confident": self.is_confident,
            "has_disagreement": self.has_disagreement,
            "is_thin_evidence": self.is_thin_evidence,
            "agreement_score": self.agreement_score,
            "conflict_peers": list(self.conflict_peers),
            "score": self.score,
        }

    def explain(self) -> str:
        """Plain-language verdict on a single hit.

        Tells the developer *why* this result was returned and whether to
        trust it: the match score, the scope-bag identity, the agreement
        signal, and what to do about it. No Field 3.0 jargon leaks — read
        like an answer to "should I act on this?"
        """
        scope_facets = []
        if self.scope.model:
            scope_facets.append(f"model={self.scope.model}")
        if self.scope.dataset:
            scope_facets.append(f"dataset={self.scope.dataset}")
        if self.scope.env:
            scope_facets.append(f"env={self.scope.env}")
        if self.scope.version:
            scope_facets.append(f"version={self.scope.version}")
        scope_str = ", ".join(scope_facets) if scope_facets else "no scope facets set"

        if self.has_disagreement:
            verdict = (
                f"⚠ Disagrees with other memories in the same context "
                f"({scope_str}). "
                f"This bag has agreement_score={self.agreement_score:.2f} — "
                f"read both sides before treating as fact. "
                f"Conflicting deposit ids: {list(self.conflict_peers)}."
            )
        elif self.is_thin_evidence:
            verdict = (
                f"This bag has only one deposit on the context "
                f"({scope_str}). Treat as a lead, not a settled finding."
            )
        elif self.is_confident:
            verdict = (
                f"✓ Multiple memories agree on this in the same context "
                f"({scope_str}); agreement_score={self.agreement_score:.2f}. "
                f"Safe to act on."
            )
        else:
            verdict = (
                f"Mixed evidence on the context ({scope_str}); "
                f"agreement_score={self.agreement_score:.2f}. "
                f"Verify before acting."
            )

        return (
            f"Returned because the text matched (BM25 score {self.score:.3f}). "
            f"Polarity: {self.polarity}. Evidence: {self.evidence_grade}. "
            f"{verdict}"
        )

    def __repr__(self) -> str:
        """REPL/Jupyter-friendly compact rendering with confidence marker."""
        marker = "⚠" if self.has_disagreement else ("✓" if self.is_confident else "·")
        preview = (self.content[:50] + "...") if len(self.content) > 53 else self.content
        return (
            f"SearchResult({marker} score={self.score:.3f} "
            f"is_confident={self.is_confident} content={preview!r})"
        )


# --- SearchResults (the iterable container with explain()) --------

@dataclass(frozen=True, slots=True)
class SearchResults:
    """Iterable container of SearchResult, with bag-level diagnostics.

    NOT a list subclass — that buried diagnostics in dunder methods and
    failed DXCritic's discoverability test. Iterate directly:

        for hit in m.recall("query", user_id="alice"):
            print(hit.content, hit.is_confident)

    Or call ``.explain()`` for an action-language summary.
    """

    items: tuple[SearchResult, ...] = ()
    has_disagreement: bool = False
    is_confident: bool = False

    def __iter__(self) -> Iterator[SearchResult]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, i: int) -> SearchResult:
        return self.items[i]

    def __bool__(self) -> bool:
        return bool(self.items)

    def __repr__(self) -> str:
        """REPL/Jupyter-friendly compact rendering."""
        n = len(self.items)
        if n == 0:
            return "SearchResults(empty)"
        verdict = (
            "⚠ disagreement" if self.has_disagreement
            else ("✓ confident" if self.is_confident else "· mixed")
        )
        previews = "; ".join(
            (r.content[:35] + "…") if len(r.content) > 38 else r.content
            for r in self.items[:3]
        )
        suffix = f"; +{n - 3} more" if n > 3 else ""
        return f"SearchResults(n={n}, {verdict}, [{previews}{suffix}])"

    def explain(self) -> str:
        """Action-language verdict on this result set.

        Empty / confident / disagreement / thin each get a one-sentence
        verdict in plain English. Field internals are not leaked.
        """
        n = len(self.items)
        if n == 0:
            return "No matching memories yet. This is a new question for this user."
        if self.has_disagreement:
            return (
                f"{n} matching memories disagree. "
                "Read both groups before using as fact."
            )
        if self.is_confident:
            return (
                f"{n} matching memories agree. "
                "Safe to use as high-confidence memory."
            )
        return (
            f"{n} matching memories with thin or mixed evidence. "
            "Treat as a lead — verify before acting."
        )


# --- AddResult (return of m.add() / m.contradict()) ----------------

@dataclass(frozen=True, slots=True)
class AddResult:
    """The outcome of a single ``m.add()`` or ``m.contradict()`` call.

    Carries the deposit and a few outcome flags. Flat ``.id`` accessor so the
    common case (``r.id``) is one keystroke; the full Deposit is at ``.deposit``.
    """

    deposit: Deposit
    """The newly-written deposit."""

    is_idempotent_replay: bool = False
    """True if this was a same-key+same-content replay returning the existing deposit."""

    @property
    def id(self) -> str:
        return self.deposit.id

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": "add_result",
            "deposit": self.deposit.to_dict(),
            "is_idempotent_replay": self.is_idempotent_replay,
        }


# --- RetractResult (return of m.retract()) ------------------------

@dataclass(frozen=True, slots=True)
class RetractResult:
    """The outcome of an ``m.retract()`` call."""

    deposit_id: str
    """The id that was retracted."""

    mode: str
    """Either ``"soft"`` (tombstone) or ``"hard"`` (permanent removal)."""

    contradicts_preserved: tuple[str, ...] = ()
    """Edges from other deposits that pointed at this one and remain valid
    (soft only — hard delete invalidates them)."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": "retract_result",
            "deposit_id": self.deposit_id,
            "mode": self.mode,
            "contradicts_preserved": list(self.contradicts_preserved),
        }


# --- BulkResult (return of m.add_many()) --------------------------

@dataclass(frozen=True, slots=True)
class AddItem:
    """One item passed to ``m.add_many()``. Per-item idempotency_key REQUIRED.

    (D10 + CodeRedTeam attack closure. Without per-item caller-supplied
    idempotency keys, transport failure after partial commit is unrecoverable.)
    """

    content: str
    idempotency_key: str
    polarity: Polarity = "open"
    evidence_grade: EvidenceGrade = "anecdotal"
    scope: Scope | None = None
    tags: tuple[str, ...] = ()
    contradicts: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BulkReject:
    """One rejected item from ``m.add_many()``."""

    item: AddItem
    """The input that failed."""

    error: Exception
    """The typed error from the ``atlaso.errors`` hierarchy."""

    index: int
    """Zero-based position in the input list (for log correlation)."""


@dataclass(frozen=True, slots=True)
class AddManyResult:
    """The outcome of ``m.add_many()``.

    Skip-and-report semantics: per-item gate failures land in ``.failed``
    (never raise), partial transport-level success is reflected in
    ``.is_partial``, idempotency replays land in ``.duplicates``.
    """

    committed: tuple[Deposit, ...] = ()
    """Deposits successfully written this call."""

    duplicates: tuple[Deposit, ...] = ()
    """Existing deposits returned via idempotency-key replay."""

    failed: tuple[BulkReject, ...] = ()
    """Per-item gate / validation failures."""

    is_partial: bool = False
    """True if the transport returned mid-batch and not all items reached the engine."""

    @property
    def total(self) -> int:
        return len(self.committed) + len(self.duplicates) + len(self.failed)

    @property
    def all_succeeded(self) -> bool:
        return not self.failed and not self.is_partial


# --- Diagnostics (return of m.health()) ---------------------------

@dataclass(frozen=True, slots=True)
class Diagnostics:
    """Health snapshot for one user's memory.

    ``fmi`` is the Field Maturity Index — a 0–100 geometric mean of four
    components (Coverage × Precision × Resolution × Density). It is preserved
    by name because it is a Field 3.0 metric you may also see in research-lab
    and the lab-app.
    """

    fmi: float
    coverage: float
    precision: float
    resolution: float
    density: float
    window_days: int
    deposit_count: int

    def explain(self) -> str:
        """Action-language verdict on memory health.

        (D10. ≥70 = healthy; 40-69 = building; <40 = thin.)
        """
        if self.fmi >= 70:
            return (
                f"Memory is healthy (FMI {self.fmi:.0f}/100). "
                "Searches are returning confident answers."
            )
        if self.fmi >= 40:
            return (
                f"Memory is building (FMI {self.fmi:.0f}/100). "
                "Add more notes to improve search confidence."
            )
        return (
            f"Memory is thin (FMI {self.fmi:.0f}/100). "
            "Too few notes for confident search yet."
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": "diagnostics",
            "fmi": self.fmi,
            "coverage": self.coverage,
            "precision": self.precision,
            "resolution": self.resolution,
            "density": self.density,
            "window_days": self.window_days,
            "deposit_count": self.deposit_count,
        }

    def __repr__(self) -> str:
        """REPL/Jupyter-friendly multi-line FMI breakdown."""
        return (
            f"Diagnostics(\n"
            f"  fmi={self.fmi:.0f}/100  ({self.deposit_count} deposits, "
            f"{self.window_days}d window)\n"
            f"  coverage={self.coverage:.2f}   precision={self.precision:.2f}\n"
            f"  resolution={self.resolution:.2f}  density={self.density:.2f}\n"
            f")"
        )


# --- PeekView (return of m.peek()) -------------------------------

@dataclass(frozen=True, slots=True)
class PeekView:
    """A friendly snapshot of a user's field — for "show me what's stored."

    Returned by ``m.peek(user_id)``. Iterates over recent deposits, prints
    a compact table by default, and exposes a one-call summary so a
    developer can see field state without writing a query.
    """

    user_id: str
    deposits: tuple[Deposit, ...]
    total_count: int
    fmi: int
    has_recent_disagreements: bool

    def __iter__(self) -> Iterator[Deposit]:
        return iter(self.deposits)

    def __len__(self) -> int:
        return len(self.deposits)

    def __getitem__(self, i: int) -> Deposit:
        return self.deposits[i]

    def __bool__(self) -> bool:
        return bool(self.deposits)

    def __repr__(self) -> str:
        """Compact table of recent deposits, suitable for REPL/Jupyter."""
        if not self.deposits:
            return (
                f"PeekView(user_id={self.user_id!r}, empty — "
                f"no deposits stored yet)"
            )
        warn = " ⚠ recent disagreements" if self.has_recent_disagreements else ""
        header = (
            f"PeekView(user_id={self.user_id!r}, "
            f"showing {len(self.deposits)} of {self.total_count}, "
            f"FMI {self.fmi}/100{warn}):"
        )
        rows = []
        for d in self.deposits:
            preview = (d.content[:55] + "…") if len(d.content) > 58 else d.content
            rows.append(f"  · [{d.polarity:11s}] {preview}")
        return header + "\n" + "\n".join(rows)

