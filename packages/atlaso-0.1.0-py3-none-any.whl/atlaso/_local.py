"""Local backend — adapts the vendored Field 3.0 engine to the SDK public API.

(D11 + D9. The engine is workspace-scoped (one field.db per workspace); the
SDK adds per-user isolation by hashing user_id into the DB path:

    <base>/users/<hex(sha256(user_id))[:16]>/field.db

This preserves engine parity (same bytes ship), gives perfect tenant
isolation (separate file per user), and keeps cross-tenant ops cheap
(iterate the users/ directory). Retract semantics are layered via a
tag-based tombstone (engine has no retract column today).
)
"""

from __future__ import annotations

import hashlib
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ._engine.aware import query_aware as engine_query_aware
from ._engine.gate import evaluate_deposit_request
from ._engine.maturity import compute_maturity
from ._engine.store import FieldStore
from ._engine.store import Scope as EngineScope
from ._types import EvidenceGrade, Polarity, Scope
from .errors import (
    ConfigValidationError,
    DepositRejectedError,
    IdempotencyKeyConflict,
    InputValidationError,
    NotFoundError,
)
from .results import (
    AddItem,
    AddManyResult,
    AddResult,
    BulkReject,
    Deposit,
    Diagnostics,
    PeekView,
    RetractResult,
    SearchResult,
    SearchResults,
)

_RETRACTED_TAG_PREFIX = "atlaso:retracted="

# FTS5 special characters that need to be stripped from natural-language
# queries. The default FTS5 query syntax interprets `:` as a column
# qualifier, `*` as a prefix wildcard, `"` as a phrase delimiter, and `?`
# is reserved. Without sanitization, a question like "what's coffee?"
# fails because of the trailing `?`, and a name like "alice@example.com"
# is parsed as a column qualifier.
_FTS5_SPECIAL = set('"():*?,;.@!#$%^&+=[]{}|\\<>~`')


def _sanitize_fts5_query(query: str) -> str | None:
    """Turn a natural-language query into a safe FTS5 OR-query.

    - Strips FTS5 special characters (?, :, *, ", etc.) that would
      otherwise be interpreted as query syntax.
    - Splits on whitespace, drops empty tokens.
    - Joins remaining tokens with `OR` so each contributes independently
      (FTS5 default is AND, which fails on natural-language questions
      like "what kind of coffee?").

    Returns None if no usable tokens remain (caller should treat as
    empty / no-query).
    """
    cleaned = "".join(c if c not in _FTS5_SPECIAL else " " for c in query)
    tokens = [t for t in cleaned.split() if t]
    if not tokens:
        return None
    if len(tokens) == 1:
        return tokens[0]
    return " OR ".join(tokens)

# Stripe-style idempotency dedup window (24 hours). Same (user_id, key) within
# the window with the SAME content → returns the existing AddResult (no double-write).
# Same key with DIFFERENT content → raises IdempotencyKeyConflict.
# (Codex external review 2026-05-09 caught the original implementation only
# checked within one batch, allowing replays across calls to silently dup.)
_IDEMPOTENCY_DB_NAME = "_idempotency.db"
_IDEMPOTENCY_TTL_SECONDS = 24 * 60 * 60


class LocalBackend:
    """In-process Field 3.0 backend backed by SQLite.

    One ``FieldStore`` per ``user_id`` (lazy, cached on this backend instance).
    Path layout::

        <base>/
        ├── users/
        │   ├── <hex(sha256("alice"))[:16]>/field.db
        │   ├── <hex(sha256("bob"))[:16]>/field.db
        │   └── ...
        ├── _unscoped/field.db        (atlaso.admin.add_unscoped writes here)
        └── _idempotency.db           (24h dedup window per D10)
    """

    def __init__(self, base_path: str | Path) -> None:
        self.base_path = Path(base_path).expanduser().resolve()
        self._lock = threading.Lock()
        self._stores: dict[str, FieldStore] = {}
        self._idem_lock = threading.Lock()
        self._idem_conn: Any = None  # lazy SQLite for idempotency keys

    # --- Path resolution -----------------------------------------

    def _user_db_path(self, user_id: str) -> Path:
        h = hashlib.sha256(user_id.encode("utf-8")).hexdigest()[:16]
        return self.base_path / "users" / h / "field.db"

    def _open_store(self, user_id: str) -> FieldStore:
        with self._lock:
            if user_id in self._stores:
                return self._stores[user_id]
            db_path = self._user_db_path(user_id)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            store = FieldStore(db_path)
            self._stores[user_id] = store
            return store

    def close(self) -> None:
        with self._lock:
            for store in self._stores.values():
                try:
                    store.close()
                except Exception:
                    pass
            self._stores.clear()
        with self._idem_lock:
            if self._idem_conn is not None:
                try:
                    self._idem_conn.close()
                except Exception:
                    pass
                self._idem_conn = None

    # --- Idempotency store (Stripe-style 24h window) -------------

    def _open_idempotency_db(self) -> Any:
        with self._idem_lock:
            if self._idem_conn is not None:
                return self._idem_conn
            import sqlite3

            db_path = self.base_path / _IDEMPOTENCY_DB_NAME
            db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(db_path), check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                "CREATE TABLE IF NOT EXISTS idempotency ("
                "  user_id TEXT NOT NULL,"
                "  idempotency_key TEXT NOT NULL,"
                "  content_hash TEXT NOT NULL,"
                "  deposit_id TEXT NOT NULL,"
                "  created_at INTEGER NOT NULL,"
                "  PRIMARY KEY (user_id, idempotency_key)"
                ")"
            )
            conn.commit()
            self._idem_conn = conn
            return conn

    def _idempotency_lookup(
        self, user_id: str, key: str, content_hash: str
    ) -> tuple[str | None, bool]:
        """Return (existing_deposit_id, is_conflict).

        - (id, False) — same key + same content within window → idempotent replay
        - (id, True)  — same key + different content within window → conflict
        - (None, False) — no record (or expired) → caller should write
        """
        import time

        conn = self._open_idempotency_db()
        with self._idem_lock:
            row = conn.execute(
                "SELECT content_hash, deposit_id, created_at FROM idempotency "
                "WHERE user_id = ? AND idempotency_key = ?",
                (user_id, key),
            ).fetchone()
            if row is None:
                return (None, False)
            stored_hash, deposit_id, created_at = row
            if int(time.time()) - int(created_at) > _IDEMPOTENCY_TTL_SECONDS:
                conn.execute(
                    "DELETE FROM idempotency WHERE user_id = ? AND idempotency_key = ?",
                    (user_id, key),
                )
                conn.commit()
                return (None, False)
            if stored_hash == content_hash:
                return (deposit_id, False)
            return (deposit_id, True)

    def _idempotency_record(
        self, user_id: str, key: str, content_hash: str, deposit_id: str
    ) -> None:
        import time

        conn = self._open_idempotency_db()
        with self._idem_lock:
            conn.execute(
                "INSERT OR REPLACE INTO idempotency "
                "(user_id, idempotency_key, content_hash, deposit_id, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (user_id, key, content_hash, deposit_id, int(time.time())),
            )
            conn.commit()

    # --- Type translation: engine → SDK --------------------------

    def _engine_scope_to_sdk(self, es: EngineScope) -> Scope:
        return Scope(
            note=es.note,
            model=es.model,
            dataset=es.dataset,
            env=es.env,
            version=es.version,
            n=es.n,
            seed=es.seed,
        )

    def _sdk_scope_to_engine(self, s: Scope | None) -> EngineScope:
        if s is None:
            return EngineScope(note="")
        return EngineScope(
            note=s.note,
            model=s.model,
            dataset=s.dataset,
            env=s.env,
            version=s.version,
            n=s.n,
            seed=s.seed,
        )

    def _engine_deposit_to_sdk(
        self,
        engine_dep: Any,
        user_id: str,
        contradicts: tuple[str, ...] = (),
    ) -> Deposit:
        # Engine deposit has no user_id; we know it from the caller's path.
        # Engine `tags` may include atlaso:retracted=<reason> as a tombstone marker.
        return Deposit(
            id=engine_dep.id,
            content=engine_dep.content,
            polarity=engine_dep.polarity,
            evidence_grade=engine_dep.evidence_grade,
            scope=self._engine_scope_to_sdk(engine_dep.scope),
            user_id=user_id,
            tags=tuple(engine_dep.tags),
            contradicts=contradicts,
            artifact_refs=tuple(engine_dep.artifact_refs),
            created_at=engine_dep.created_at,
            author=engine_dep.author,
            author_role=engine_dep.author_role,
            repro_status=engine_dep.repro_status,
            task_id=engine_dep.task_id,
        )

    def _is_retracted(self, engine_dep: Any) -> bool:
        return any(t.startswith(_RETRACTED_TAG_PREFIX) for t in engine_dep.tags)

    # --- add / contradict ----------------------------------------

    def add(
        self,
        text: str,
        *,
        user_id: str,
        polarity: Polarity = "open",
        evidence_grade: EvidenceGrade = "anecdotal",
        scope: Scope | None = None,
        tags: tuple[str, ...] = (),
        contradicts: tuple[str, ...] = (),
        artifact_refs: tuple[str, ...] = (),
        author: str | None = None,
        author_role: str | None = None,
    ) -> AddResult:
        store = self._open_store(user_id)
        engine_scope = self._sdk_scope_to_engine(scope)

        # Run the gate first — fail fast with DepositRejectedError carrying .gate_reason.
        decision = evaluate_deposit_request(
            content=text,
            polarity=polarity,
            evidence_grade=evidence_grade,
            scope=engine_scope,
            author=author or "user",
            author_role=author_role or "user",
            repro_status="unreplicated",
            artifact_refs=list(artifact_refs),
            tags=list(tags),
            contradicts=list(contradicts) if contradicts else None,
        )
        if not decision.accept:
            raise DepositRejectedError(
                f"Field 3.0 gate rejected this deposit: {decision.reason}",
                gate_reason=decision.reason,
            )

        deposit_id = store.deposit(
            content=text,
            polarity=polarity,
            evidence_grade=evidence_grade,
            scope=engine_scope,
            author=author or "user",
            tags=list(tags) if tags else None,
            artifact_refs=list(artifact_refs) if artifact_refs else None,
            contradicts=list(contradicts) if contradicts else None,
            author_role=author_role,
        )
        engine_dep = store.get(deposit_id)
        sdk_dep = self._engine_deposit_to_sdk(
            engine_dep, user_id=user_id, contradicts=contradicts
        )
        return AddResult(deposit=sdk_dep, is_idempotent_replay=False)

    def contradict(
        self,
        new_text: str,
        contradicts: tuple[str, ...],
        *,
        reason: str,
        user_id: str,
    ) -> AddResult:
        store = self._open_store(user_id)
        for cid in contradicts:
            if store.get(cid) is None:
                raise NotFoundError(
                    f"contradicts target {cid!r} not found for user_id={user_id!r}",
                    status_code=404,
                )
        # Encode the reason as a deposit tag so audit context survives.
        # The new finding is `negative` polarity by convention — supersedes the old.
        return self.add(
            new_text,
            user_id=user_id,
            polarity="negative",
            evidence_grade="observed",
            scope=Scope(note=f"contradict: {reason[:80]}"),
            tags=(f"atlaso:reason={reason[:120]}",),
            contradicts=contradicts,
        )

    # --- get / list_recent ---------------------------------------

    def get(self, deposit_id: str, *, user_id: str) -> Deposit | None:
        store = self._open_store(user_id)
        # Wrap engine call — a corrupted created_at on disk would otherwise
        # surface as a raw ValueError instead of None / a typed error.
        # (Codex external review 2026-05-09 caught this on `recall`; same
        # fix applied to `get` and `list_recent` for consistency.)
        try:
            engine_dep = store.get(deposit_id)
        except ValueError:
            return None
        if engine_dep is None:
            return None
        if self._is_retracted(engine_dep):
            return None
        return self._engine_deposit_to_sdk(engine_dep, user_id=user_id)

    def list_recent(
        self, *, user_id: str, limit: int = 20, offset: int = 0
    ) -> list[Deposit]:
        # Filter retracted rows BEFORE applying offset/limit. Otherwise
        # tombstones inside the window cause callers to get fewer items
        # than `limit` even when more active deposits exist further down.
        # Engine list_recent has no offset; fetch a generous window, drop
        # retracted, then slice. (Codex external review 2026-05-09.)
        store = self._open_store(user_id)
        # Conservative over-fetch — tombstones are uncommon in practice;
        # 4× window covers everything but pathological cases. We could
        # paginate inside the engine if this proves a hotspot.
        window = max((limit + offset) * 4, 100)
        # Engine raises ValueError on malformed created_at. To stay resilient
        # to corrupted-on-disk rows, fall back to a row-by-row strategy that
        # skips bad rows rather than crashing the entire list.
        try:
            rows = store.list_recent(limit=window)
        except ValueError:
            # One bad row poisoned the whole batch — fall back to scanning
            # ids and getting them one at a time, skipping the bad ones.
            rows = self._safe_list_recent_fallback(store, window)
        active = [r for r in rows if not self._is_retracted(r)]
        sliced = active[offset : offset + limit]
        return [self._engine_deposit_to_sdk(r, user_id=user_id) for r in sliced]

    def _safe_list_recent_fallback(self, store: FieldStore, limit: int) -> list[Any]:
        """Row-by-row fetch that skips rows with corrupted timestamps."""
        with store._lock:  # type: ignore[attr-defined]
            ids = [
                row[0]
                for row in store._conn.execute(  # type: ignore[attr-defined]
                    "SELECT id FROM deposits ORDER BY created_at DESC, id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            ]
        results: list[Any] = []
        for dep_id in ids:
            try:
                d = store.get(dep_id)
                if d is not None:
                    results.append(d)
            except ValueError:
                continue
        return results

    # --- recall (the +10pp mechanism) ----------------------------

    def recall(
        self,
        query: str,
        *,
        user_id: str,
        limit: int = 10,
        scope: Scope | None = None,
    ) -> SearchResults:
        store = self._open_store(user_id)
        scope_filter: dict[str, Any] | None = None
        if scope is not None:
            scope_filter = {
                k: v
                for k, v in {
                    "model": scope.model,
                    "dataset": scope.dataset,
                    "env": scope.env,
                    "version": scope.version,
                }.items()
                if v is not None
            } or None

        # Sanitize + tokenize the query for FTS5. Default FTS5 interprets
        # most punctuation as syntax (':' = column, '*' = prefix, etc.) and
        # treats whitespace-separated tokens as AND. For natural-language
        # questions ("what kind of coffee?"), this produces zero hits even
        # when the underlying word would match.
        # Fix: strip punctuation, split on whitespace, drop empties,
        # join with OR so each token contributes independently. Discovered
        # via integration testing 2026-05-09 (chat_app demo).
        sanitized_query = _sanitize_fts5_query(query) if query else None

        try:
            result = engine_query_aware(
                store,
                query_text=sanitized_query,
                scope_filter=scope_filter,
                limit=limit,
            )
        except ValueError:
            # Corrupted timestamp in the field — return empty rather than
            # leak the raw ValueError. The diagnostic path (m.peek + per-row
            # m.get) gives the developer a way to find the corrupted row.
            return SearchResults()
        bags = result.get("results", [])

        # CRITICAL: aggregate dispersion flags across ALL bags FIRST, before any
        # slicing. CodeRedTeam attack 2026-05-07 caught this: if one bag has more
        # deposits than `limit`, the per-deposit slice never visits later bags,
        # so a conflict bag can be returned by the engine but the SDK reports
        # has_disagreement=False / is_confident=True. That silently breaks the
        # +10pp dispersion-aware claim. The aggregate flags must reflect the
        # engine's full view, not what survived the slice.
        any_disagreement = any(bool(b.get("has_conflict", False)) for b in bags)
        any_confident_bag = any(bool(b.get("is_confident", False)) for b in bags)

        # When the engine returned ANY conflicting bag, prioritize its deposits
        # in the slice — the developer's most likely action is to inspect the
        # conflicting memories, not the high-volume agreed-upon bag.
        bags_in_priority_order = sorted(
            bags,
            key=lambda b: (
                0 if b.get("has_conflict", False) else 1,  # conflicts first
                -float(b.get("score", 0.0) or 0.0),         # then by score
            ),
        )

        # Each `bag` is a scope-bag (group of deposits sharing the same scope facets)
        # with bag-level dispersion fields. Flatten into per-deposit SearchResults,
        # copying the bag-level flags onto each result.
        sdk_items: list[SearchResult] = []

        for bag in bags_in_priority_order:
            has_disagreement = bool(bag.get("has_conflict", False))
            is_confident = bool(bag.get("is_confident", False))
            agreement_score = float(bag.get("bag_precision", 0.0) or 0.0)
            is_thin_evidence = bool(bag.get("is_single_sample", False))
            conflict_peers = tuple(bag.get("conflict_peers", []) or [])

            for raw_deposit in bag.get("deposits", []):
                # raw_deposit may be either an engine Deposit or a dict shape;
                # the engine usually serializes them as dicts at this boundary.
                if isinstance(raw_deposit, dict):
                    if any(t.startswith(_RETRACTED_TAG_PREFIX) for t in raw_deposit.get("tags", [])):
                        continue
                    raw_created = raw_deposit.get("created_at")
                    if isinstance(raw_created, datetime):
                        parsed_created = raw_created
                    elif isinstance(raw_created, str):
                        try:
                            parsed_created = datetime.fromisoformat(raw_created)
                        except ValueError:
                            # Malformed timestamp on a stored row — treat as a
                            # data-quality issue at the SDK boundary, not a
                            # ValueError up the call stack. Skip the row.
                            # (Codex external review 2026-05-09.)
                            continue
                    else:
                        parsed_created = datetime.now(timezone.utc)

                    sdk_dep = Deposit(
                        id=raw_deposit["id"],
                        content=raw_deposit["content"],
                        polarity=raw_deposit["polarity"],
                        evidence_grade=raw_deposit["evidence_grade"],
                        scope=Scope(**raw_deposit.get("scope", {"note": ""})),
                        user_id=user_id,
                        tags=tuple(raw_deposit.get("tags", [])),
                        contradicts=(),
                        artifact_refs=tuple(raw_deposit.get("artifact_refs", [])),
                        created_at=parsed_created,
                        author=raw_deposit.get("author"),
                        author_role=raw_deposit.get("author_role"),
                    )
                else:
                    if self._is_retracted(raw_deposit):
                        continue
                    sdk_dep = self._engine_deposit_to_sdk(raw_deposit, user_id=user_id)

                sdk_items.append(
                    SearchResult(
                        deposit=sdk_dep,
                        score=float(bag.get("score", 0.0) or 0.0),
                        is_confident=is_confident,
                        has_disagreement=has_disagreement,
                        agreement_score=agreement_score,
                        is_thin_evidence=is_thin_evidence,
                        conflict_peers=conflict_peers,
                    )
                )
                if len(sdk_items) >= limit:
                    break
            if len(sdk_items) >= limit:
                break

        return SearchResults(
            items=tuple(sdk_items),
            has_disagreement=any_disagreement,
            is_confident=any_confident_bag and not any_disagreement,
        )

    # --- retract (soft tombstone via tag) ------------------------

    def retract(
        self,
        deposit_id: str,
        *,
        reason: str,
        hard_delete: bool = False,
        force: bool = False,
        user_id: str,
    ) -> RetractResult:
        store = self._open_store(user_id)
        engine_dep = store.get(deposit_id)
        if engine_dep is None:
            raise NotFoundError(
                f"deposit {deposit_id!r} not found for user_id={user_id!r}",
                status_code=404,
            )

        # The engine exposes its sqlite3 connection as an attribute; serialize
        # writes via the engine's lock so we don't race the engine's own ops.
        conn = store._conn  # type: ignore[attr-defined]
        lock = store._lock  # type: ignore[attr-defined]

        if hard_delete:
            import json as _json

            with lock:
                # Reconstruct the body that was indexed so we can issue the
                # contentless-FTS5 'delete' command. Without this, GDPR/PII
                # hard deletion is incomplete — terms remain searchable in
                # the FTS index even though the deposits row is gone.
                # (Codex external review 2026-05-09 caught the issue;
                # contentless FTS5 needs the original body to DELETE.)
                row = conn.execute(
                    "SELECT rowid, content, tags_json, scope_note "
                    "FROM deposits WHERE id = ?",
                    (deposit_id,),
                ).fetchone()
                if row is None:
                    raise NotFoundError(
                        f"deposit {deposit_id!r} not found for user_id={user_id!r}",
                        status_code=404,
                    )
                rowid, content, tags_json, scope_note = row
                try:
                    tags = _json.loads(tags_json or "[]")
                except (TypeError, ValueError):
                    tags = []
                body = " ".join([content or "", " ".join(tags), scope_note or ""])
                # Order matters under PRAGMA foreign_keys=ON:
                #   1. Drop FTS index entry (contentless FTS5 'delete' command)
                #   2. Drop contradiction edges referencing this deposit
                #   3. Drop the deposits row
                # If we delete the deposits row before the contradictions
                # rows, the FK constraint fails — caught by CLI demo
                # 2026-05-09 (m.contradict followed by m.retract --hard).
                conn.execute(
                    "INSERT INTO deposits_fts(deposits_fts, rowid, body) "
                    "VALUES ('delete', ?, ?)",
                    (rowid, body),
                )
                conn.execute(
                    "DELETE FROM contradictions WHERE from_deposit_id = ? OR to_deposit_id = ?",
                    (deposit_id, deposit_id),
                )
                conn.execute("DELETE FROM deposits WHERE id = ?", (deposit_id,))
                conn.commit()
            return RetractResult(
                deposit_id=deposit_id,
                mode="hard",
                contradicts_preserved=(),
            )

        # Soft tombstone: append the retraction tag (idempotent).
        tag = f"{_RETRACTED_TAG_PREFIX}{reason[:200]}"
        existing_tags = list(engine_dep.tags)
        if not any(t.startswith(_RETRACTED_TAG_PREFIX) for t in existing_tags):
            existing_tags.append(tag)
            import json as _json

            with lock:
                conn.execute(
                    "UPDATE deposits SET tags_json = ? WHERE id = ?",
                    (_json.dumps(existing_tags), deposit_id),
                )
                conn.commit()

        # Preserve outgoing contradiction edges so they remain queryable.
        with lock:
            from_edges = [
                row[0]
                for row in conn.execute(
                    "SELECT to_deposit_id FROM contradictions WHERE from_deposit_id = ?",
                    (deposit_id,),
                ).fetchall()
            ]

        return RetractResult(
            deposit_id=deposit_id,
            mode="soft",
            contradicts_preserved=tuple(from_edges),
        )

    # --- health (FMI) --------------------------------------------

    def peek(self, *, user_id: str, limit: int = 10) -> PeekView:
        """Snapshot for inspection: recent active deposits + ACTIVE total + FMI.

        Total count excludes soft-retracted rows so the displayed number
        matches what `recall()` and `list_recent()` actually surface.
        (Codex external review 2026-05-09 caught the original including
        tombstoned rows in total_count.)
        """
        deposits = self.list_recent(user_id=user_id, limit=limit)
        store = self._open_store(user_id)
        # Count ACTIVE deposits — exclude tombstoned rows. The engine's
        # store.count() includes everything including soft-retracted; do
        # the active count via direct SQL on the same connection.
        try:
            with store._lock:  # type: ignore[attr-defined]
                row = store._conn.execute(  # type: ignore[attr-defined]
                    "SELECT COUNT(*) FROM deposits "
                    "WHERE NOT EXISTS ("
                    "  SELECT 1 FROM json_each(deposits.tags_json) "
                    "  WHERE json_each.value LIKE 'atlaso:retracted=%'"
                    ")"
                ).fetchone()
                total = int(row[0]) if row else len(deposits)
        except Exception:
            total = len(deposits)
        diag = self.health(user_id=user_id, window_days=30)
        return PeekView(
            user_id=user_id,
            deposits=tuple(deposits),
            total_count=total,
            fmi=int(diag.fmi),
            has_recent_disagreements=False,  # populated when bag-level audit lands
        )

    def health(self, *, user_id: str, window_days: int = 30) -> Diagnostics:
        store = self._open_store(user_id)
        report = compute_maturity(store, window_days=window_days)
        return Diagnostics(
            fmi=float(report.fmi),
            coverage=float(report.coverage),
            precision=float(report.precision),
            resolution=float(report.resolution),
            density=float(report.density),
            window_days=window_days,
            deposit_count=int(report.total_deposits),
        )

    # --- add_many (bulk with per-item idempotency keys) ----------

    def add_many(
        self,
        items: list[AddItem],
        *,
        user_id: str,
        on_gate_reject: str = "skip",
    ) -> AddManyResult:
        import hashlib

        committed: list[Deposit] = []
        duplicates: list[Deposit] = []
        failed: list[BulkReject] = []
        seen_keys_in_batch: set[str] = set()

        for idx, item in enumerate(items):
            # Intra-batch dedup: same key twice in the same call is always
            # a caller bug (regardless of content match).
            if item.idempotency_key in seen_keys_in_batch:
                failed.append(
                    BulkReject(
                        item=item,
                        error=IdempotencyKeyConflict(
                            "Duplicate idempotency_key in this batch",
                            idempotency_key=item.idempotency_key,
                            existing_id="",
                        ),
                        index=idx,
                    )
                )
                continue
            seen_keys_in_batch.add(item.idempotency_key)

            # Cross-call dedup: check the persistent idempotency table.
            content_hash = hashlib.blake2b(
                item.content.encode("utf-8"), digest_size=16
            ).hexdigest()
            existing_id, is_conflict = self._idempotency_lookup(
                user_id, item.idempotency_key, content_hash
            )

            if existing_id is not None and not is_conflict:
                # Same key + same content within window → idempotent replay.
                # Return the existing deposit as a duplicate, no new write.
                existing = self.get(existing_id, user_id=user_id)
                if existing is not None:
                    duplicates.append(existing)
                continue

            if is_conflict:
                failed.append(
                    BulkReject(
                        item=item,
                        error=IdempotencyKeyConflict(
                            f"idempotency_key={item.idempotency_key!r} was already used "
                            "within the last 24h with different content",
                            idempotency_key=item.idempotency_key,
                            existing_id=existing_id or "",
                        ),
                        index=idx,
                    )
                )
                continue

            try:
                result = self.add(
                    item.content,
                    user_id=user_id,
                    polarity=item.polarity,
                    evidence_grade=item.evidence_grade,
                    scope=item.scope,
                    tags=tuple(item.tags),
                    contradicts=tuple(item.contradicts),
                )
                committed.append(result.deposit)
                # Persist for cross-call replay safety.
                self._idempotency_record(
                    user_id, item.idempotency_key, content_hash, result.id
                )
            except DepositRejectedError as e:
                if on_gate_reject == "raise":
                    raise
                failed.append(BulkReject(item=item, error=e, index=idx))
            except (InputValidationError, ConfigValidationError) as e:
                failed.append(BulkReject(item=item, error=e, index=idx))

        return AddManyResult(
            committed=tuple(committed),
            duplicates=tuple(duplicates),
            failed=tuple(failed),
            is_partial=False,
        )
