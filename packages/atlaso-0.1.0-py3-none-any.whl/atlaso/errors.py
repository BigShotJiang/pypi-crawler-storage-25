"""Public exception hierarchy for atlaso.

(D9 + D11. The naming dodges every Python builtin shadow:
  - `ConnectError` not `ConnectionError`
  - `RequestTimeoutError` not `TimeoutError`
  - `PermissionDeniedError` not `PermissionError`
The CI gate `tools/builtin_shadow_gate.py` enforces this.)
"""

from __future__ import annotations

from typing import Any

# --- Base ----------------------------------------------------------

class AtlasoError(Exception):
    """Base for all SDK errors. Catch this to catch everything."""


# --- Caller-side problems (never retried) --------------------------

class ConfigurationError(AtlasoError):
    """SDK was constructed or called with bad inputs.

    No api_key, malformed base_url, missing path, transport is wrong type, etc.
    """


class ConfigValidationError(ConfigurationError):
    """A specific construction-time argument failed validation.

    Example: ``Memory(transport=httpx.Client(...))`` — transport must be a
    ``BaseTransport``, not a ``Client``. (See `_docs.WIRE_SCHEMA` and the
    ``transport-type-gate`` CI test.)
    """


class InputValidationError(ConfigurationError):
    """A call-time argument failed local validation.

    Examples: empty content, malformed user_id, polarity not in literal set,
    limit out of range. Distinct from ``ConfigValidationError`` so caller
    code can route remediation differently.
    """


class MissingContradictsError(InputValidationError):
    """A deposit narrows or refutes an existing claim but ``contradicts=[]``.

    Field 3.0 gate refused. Includes ``.candidate_parents`` listing the
    deposit ids the new claim appears to refute.
    """

    def __init__(
        self,
        message: str,
        *,
        candidate_parents: list[str] | None = None,
    ) -> None:
        super().__init__(message)
        self.candidate_parents: list[str] = candidate_parents or []


# --- Authentication / authorization (never retried) ---------------

class AuthenticationError(AtlasoError):
    """The Atlaso engine rejected the API key (HTTP 401).

    Distinct from PermissionDeniedError (403): this means *who you say you
    are* is wrong, not *what you tried to do* is forbidden.
    """


# --- Transport problems (some subclasses retried by default) ------

class TransportError(AtlasoError):
    """Base for network/HTTP failures.

    Some subclasses are retried automatically per the policy in
    ``Memory(max_retries=..., timeout=...)``. ``ConnectError``,
    ``RequestTimeoutError``, ``ServerError``, ``RateLimitError`` retry.
    Other ``APIStatusError`` subclasses do not.
    """


class ConnectError(TransportError):
    """Could not reach the engine (DNS, TCP, TLS).

    NOT named ``ConnectionError`` — that shadows a Python builtin. Retried.
    """


class RequestTimeoutError(TransportError):
    """Request exceeded the configured timeout.

    NOT named ``TimeoutError`` — Python 3.11+ added that as a builtin.
    Retried.
    """


class APIStatusError(TransportError):
    """Engine returned a non-2xx response.

    Carries ``.status_code``, ``.response`` (parsed body if JSON, else text),
    and ``.request_id`` (engine's correlation id, if returned in headers).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response: Any = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response
        self.request_id = request_id


class PermissionDeniedError(APIStatusError):
    """HTTP 401 or 403 — caller is not authorized for this operation.

    Renamed from ``AuthorizationError`` per DXCritic — easier to distinguish
    from ``AuthenticationError`` and avoids shadowing Python builtin
    ``PermissionError``. Also raised when the ``validate_user_id`` callback
    on ``Memory()`` rejects a user_id.

    Not retried.
    """


class NotFoundError(APIStatusError):
    """HTTP 404 — requested deposit / user / resource does not exist.

    Note: ``Memory.get()`` returns ``None`` rather than raising NotFoundError
    on missing deposits, by design (matches dict.get muscle memory). NotFoundError
    fires from ``retract``, ``contradict``, ``health``, etc. — paths where the
    caller intended to act on a specific id.

    Not retried.
    """


class RateLimitError(APIStatusError):
    """HTTP 429 — engine rate-limited this request.

    Carries ``.retry_after`` (seconds, or ``None`` if header was absent).
    Nested under ``APIStatusError`` (not a sibling) so a caller doing
    ``except APIStatusError as e: log(e.status_code)`` catches rate
    limits the same way it catches every other status error — sibling
    structure would silently leak 429s through tuple catches.

    Retried automatically, respects ``Retry-After`` header up to
    ``max(60s, 4 × backoff)``.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 429,
        retry_after: float | None = None,
        response: Any = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            response=response,
            request_id=request_id,
        )
        self.retry_after = retry_after


class ServerError(APIStatusError):
    """HTTP 5xx — engine had an internal failure.

    Retried.
    """


# --- Field 3.0 domain rejections (never retried) -------------------

class FieldError(AtlasoError):
    """Field 3.0 gate or invariant rejected an operation.

    Not a transport problem — the request reached the engine and was
    refused on Field 3.0 grounds (breadth × evidence gate, immutability,
    etc.).
    """


class DepositRejectedError(FieldError):
    """The Field 3.0 gate refused this deposit.

    Common reasons: broad-positive without ``evidence_grade="replicated"``,
    narrow without provenance, missing scope facets when claim spans multiple
    bags. Carries ``.gate_reason`` describing which rule fired.
    """

    def __init__(self, message: str, *, gate_reason: str | None = None) -> None:
        super().__init__(message)
        self.gate_reason = gate_reason


# --- Bulk-operation idempotency (D10) ------------------------------

class IdempotencyKeyConflict(AtlasoError):
    """Same idempotency key used with different content within the dedup window.

    Stripe-style 24h dedup window keyed by ``(user_id, idempotency_key)``.
    Same key + identical content → returns the existing AddResult silently.
    Same key + different content → this exception. Indicates a caller bug.
    """

    def __init__(
        self,
        message: str,
        *,
        idempotency_key: str,
        existing_id: str,
    ) -> None:
        super().__init__(message)
        self.idempotency_key = idempotency_key
        self.existing_id = existing_id
