"""atlaso — A memory store that flags its own conflicts before your agent does.

Quickstart::

    from atlaso import Memory

    m = Memory()
    m.add("Alice prefers dark mode", user_id="alice")

    for hit in m.recall("ui prefs", user_id="alice"):
        print(hit.content, "confident:", hit.is_confident)

For SaaS / FastAPI: use ``AsyncMemory`` and the ``m.for_user(authenticated_id)``
pattern. See the README and https://docs.atlaso.dev/sdk for the full guide.
"""

from __future__ import annotations

__version__ = "0.1.0"

# --- Public API surface -------------------------------------------

from ._types import EvidenceGrade, Polarity, ReproStatus, Scope
from .async_memory import AsyncMemory
from .compat import (
    FrameworkExtraReservedWarning,
    SyncInAsyncWarning,
    idempotency_key,
)
from .errors import (
    APIStatusError,
    AtlasoError,
    AuthenticationError,
    ConfigurationError,
    ConfigValidationError,
    ConnectError,
    DepositRejectedError,
    FieldError,
    IdempotencyKeyConflict,
    InputValidationError,
    MissingContradictsError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
    TransportError,
)
from .handle import AsyncUserHandle, UserHandle
from .memory import Memory
from .results import (
    AddItem,
    AddManyResult,
    AddResult,
    BulkReject,
    Deposit,
    Diagnostics,
    PeekView,
    RetractResult,
    SearchResult,
    SearchResults,
)

__all__ = [
    "APIStatusError",
    "AddItem",
    "AddManyResult",
    "AddResult",
    "AsyncMemory",
    "AsyncUserHandle",
    # Error hierarchy
    "AtlasoError",
    "AuthenticationError",
    "BulkReject",
    "ConfigValidationError",
    "ConfigurationError",
    "ConnectError",
    # Result shapes
    "Deposit",
    "DepositRejectedError",
    "Diagnostics",
    "EvidenceGrade",
    "FieldError",
    "FrameworkExtraReservedWarning",
    "IdempotencyKeyConflict",
    "InputValidationError",
    # Core clients
    "Memory",
    "MissingContradictsError",
    "NotFoundError",
    "PeekView",
    "PermissionDeniedError",
    # Field 3.0 vocabulary
    "Polarity",
    "RateLimitError",
    "ReproStatus",
    "RequestTimeoutError",
    "RetractResult",
    "Scope",
    "SearchResult",
    "SearchResults",
    "ServerError",
    "SyncInAsyncWarning",
    "TransportError",
    "UserHandle",
    "__version__",
    # Helpers
    "idempotency_key",
]
