"""The synchronous public Memory client.

Front door for quickstart and single-user / script use cases. SaaS apps
should use ``AsyncMemory`` instead — calling ``Memory`` from inside a
running asyncio loop emits ``SyncInAsyncWarning``.

This module is the *surface* for v0.1. The actual transport implementation
is in ``atlaso._core.transport`` (shared with ``AsyncMemory``); the engine
itself is vendored at wheel-build time per D11 Stage 1.
"""

from __future__ import annotations

import asyncio
import os
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import httpx

from . import _docs
from ._validation import check_evidence_grade, check_polarity, check_user_id_shape
from .compat import (
    async_warnings_enabled,
    emit_async_loop_warning,
    warn_about_stub_extras_once,
    warn_telemetry_env_is_noop,
)
from .errors import ConfigValidationError, InputValidationError

if TYPE_CHECKING:
    from ._types import EvidenceGrade, Polarity, Scope
    from .handle import UserHandle
    from .results import (
        AddItem,
        AddManyResult,
        AddResult,
        Deposit,
        Diagnostics,
        PeekView,
        RetractResult,
        SearchResults,
    )


_DEFAULT_BASE_URL = "https://api.atlaso.dev"
_DEFAULT_TIMEOUT = 10.0
_DEFAULT_MAX_RETRIES = 2


class Memory:
    """The synchronous Atlaso memory client.

    Recommended usage — bind to an authenticated identity once, call freely::

        from atlaso import Memory

        m = Memory()
        user = m.for_user(auth.user.id)        # bind to authenticated id
        user.add("user prefers dark mode")
        for hit in user.recall("ui prefs"):
            print(hit.content, "confident:", hit.is_confident)

    The lower-level ``m.recall(query, user_id="alice")`` accepts ``user_id``
    explicitly and is intended only for admin tooling, tests, and one-shot
    scripts. Never pass values from request bodies — see
    https://docs.atlaso.dev/sdk/authorization.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        path: str | os.PathLike[str] | None = None,
        validate_user_id: Callable[[str], None] | None = None,
        timeout: float | httpx.Timeout = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        suppress_async_warning: bool | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        # --- Transport injection contract (D9 / β.5) -----------------
        # Accept httpx.BaseTransport (connection-level: proxies, CAs,
        # retries, HTTP/2). REJECT httpx.Client — that's mutable and
        # carries auth headers, which would silently leak across tenants
        # if the same Client is shared between two Memory instances with
        # different api_keys. The transport-type-gate CI test enforces this.
        if transport is not None and isinstance(transport, httpx.Client):
            raise ConfigValidationError(
                "transport= must be an httpx.BaseTransport (e.g. httpx.HTTPTransport, "
                "httpx.WSGITransport), NOT an httpx.Client. Sharing an httpx.Client "
                "across two Memory instances with different api_keys silently leaks "
                "Authorization headers across tenants. "
                f"See {_docs.WIRE_SCHEMA}."
            )

        self._api_key = api_key or os.environ.get("ATLASO_API_KEY")
        self._base_url = (
            base_url
            or os.environ.get("ATLASO_BASE_URL")
            or _DEFAULT_BASE_URL
        )
        self._path = path
        self._validate_user_id = validate_user_id
        self._timeout = timeout
        self._max_retries = max_retries
        self._async_warnings = async_warnings_enabled(suppress_async_warning)
        self._user_transport = transport

        # The Client itself is built per-instance and OWNS the
        # Authorization header. Transport is shared safely; Client is not.
        self._client: httpx.Client | None = None

        # D12: ATLASO_TELEMETRY no-op probe. D13: stub-framework extras probe.
        warn_telemetry_env_is_noop()
        warn_about_stub_extras_once()

    def __repr__(self) -> str:
        """REPL/Jupyter-friendly summary."""
        path = self._path or os.environ.get("ATLASO_PATH") or "<auto-resolved on first write>"
        return f"Memory(path={path!r})"

    # --- Lifecycle ----------------------------------------------------
    # close() is defined later in the Backend resolution section; it closes
    # both the local backend (if open) and the httpx client (if used by the
    # future remote backend in v0.2). Caller's transport, if injected, is
    # NEVER closed by us.

    def __enter__(self) -> Memory:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # --- Recommended path: per-user binding ---------------------------

    def for_user(self, user_id: str) -> UserHandle:
        """Bind this client to an authenticated user identity.

        Pass values from your auth layer (e.g. ``auth.user.id``,
        ``request.session["user_id"]``). NEVER pass values sourced from
        the request body or query string — that lets a malicious request
        supply any user_id and read another tenant's memories through the
        ordinary recall path.

        If you supplied ``validate_user_id=`` on construction, it is called
        here and may raise to reject the binding.
        """
        from .handle import UserHandle

        self._authorize(user_id)
        return UserHandle(_client=self, _user_id=user_id)

    # --- Lower-level surface: explicit user_id per call ---------------

    def add(
        self,
        text: str,
        *,
        user_id: str,
        polarity: Polarity = "open",
        evidence_grade: EvidenceGrade = "anecdotal",
        scope: Scope | None = None,
        tags: list[str] | None = None,
        contradicts: list[str] | None = None,
        author: str | None = None,
    ) -> AddResult:
        """Write a new deposit to the field.

        ``user_id`` is required; pass an authenticated identity from your
        auth layer. ``polarity`` and ``evidence_grade`` default to ``"open"``
        / ``"anecdotal"`` so the simple call ``m.add(text, user_id=...)``
        works without ceremony; the full Field 3.0 vocabulary is available
        via the explicit kwargs.
        """
        self._guard_async_loop("add")
        self._authorize(user_id)
        check_polarity(polarity)
        check_evidence_grade(evidence_grade)

        return self._transport_add(
            text,
            user_id=user_id,
            polarity=polarity,
            evidence_grade=evidence_grade,
            scope=scope,
            tags=tuple(tags or ()),
            contradicts=tuple(contradicts or ()),
            author=author,
        )

    def recall(
        self,
        query: str,
        *,
        user_id: str,
        limit: int = 10,
        scope: Scope | None = None,
    ) -> SearchResults:
        """Retrieve memories with dispersion-aware results.

        Each result carries ``is_confident``, ``has_disagreement``,
        ``agreement_score``, ``conflict_peers``, ``is_thin_evidence`` —
        the mechanism that justifies the +10pp benchmark lift.
        """
        self._guard_async_loop("recall")
        self._authorize(user_id)

        if not isinstance(limit, int) or not (1 <= limit <= 1000):
            raise InputValidationError(f"limit must be an int in [1, 1000], got {limit!r}")

        return self._transport_recall(
            query, user_id=user_id, limit=limit, scope=scope
        )

    def get(self, deposit_id: str, *, user_id: str) -> Deposit | None:
        """Fetch a single deposit by id. Returns ``None`` on miss.

        (D10: matches dict.get muscle memory; ``NotFoundError`` reserved for
        verbs where the caller intended to act on the id — retract, contradict.)
        """
        self._guard_async_loop("get")
        self._authorize(user_id)
        return self._transport_get(deposit_id, user_id=user_id)

    def peek(self, user_id: str, *, limit: int = 10) -> PeekView:
        """Snapshot for "show me what's in there" without writing a query.

        Returns a ``PeekView`` that iterates like a list of deposits but
        also has a friendly REPL/Jupyter ``__repr__`` rendering the recent
        deposits in a table with FMI score and disagreement marker.

        >>> m = Memory()
        >>> m.add("Alice prefers oat milk", user_id="alice")
        >>> m.peek("alice")
        PeekView(user_id='alice', showing 1 of 1, FMI 0/100):
          · [open       ] Alice prefers oat milk
        """
        self._guard_async_loop("peek")
        self._authorize(user_id)
        if not isinstance(limit, int) or not (1 <= limit <= 200):
            raise InputValidationError(
                f"limit must be an int in [1, 200], got {limit!r}"
            )
        return self._backend().peek(user_id=user_id, limit=limit)

    def list_recent(
        self,
        *,
        user_id: str,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Deposit]:
        """Newest-first list of recent deposits for one user."""
        self._guard_async_loop("list_recent")
        self._authorize(user_id)
        if not isinstance(limit, int) or not (1 <= limit <= 1000):
            raise InputValidationError(f"limit must be an int in [1, 1000], got {limit!r}")
        if not isinstance(offset, int) or offset < 0:
            raise InputValidationError(f"offset must be a non-negative int, got {offset!r}")
        return self._transport_list_recent(user_id=user_id, limit=limit, offset=offset)

    def contradict(
        self,
        new_text: str,
        contradicts: list[str],
        *,
        reason: str,
        user_id: str,
    ) -> AddResult:
        """Deposit a new finding that supersedes existing ones, atomically.

        The recommended path for "this fact was wrong / has changed" — Atlaso
        has no ``update()``. The new deposit + contradiction edges are
        committed in one transaction.
        """
        self._guard_async_loop("contradict")
        self._authorize(user_id)
        if not contradicts:
            raise InputValidationError(
                "contradict() requires at least one deposit_id in contradicts=[...]"
            )
        if not reason or not reason.strip():
            raise InputValidationError(
                "contradict() requires reason='...' to keep the audit trail meaningful."
            )
        return self._transport_contradict(
            new_text,
            contradicts=tuple(contradicts),
            reason=reason,
            user_id=user_id,
        )

    def retract(
        self,
        deposit_id: str,
        *,
        reason: str,
        user_id: str,
        hard_delete: bool = False,
        force: bool = False,
    ) -> RetractResult:
        """Retract a deposit. Soft tombstone by default; ``hard_delete=True`` is the GDPR/PII escape.

        ``reason`` is REQUIRED — Atlaso keeps a retraction trail. Common
        examples: ``reason="this fact was wrong"``, ``reason="user requested deletion"``,
        ``reason="superseded by m.contradict()"``. Empty/whitespace raises.
        """
        self._guard_async_loop("retract")
        self._authorize(user_id)
        if not reason or not reason.strip():
            raise InputValidationError(
                "retract() needs reason=... because Atlaso keeps a retraction trail; "
                'use m.retract(deposit_id, reason="wrong fact") for normal corrections, '
                "or hard_delete=True only for PII/GDPR deletion."
            )
        return self._transport_retract(
            deposit_id,
            reason=reason,
            hard_delete=hard_delete,
            force=force,
            user_id=user_id,
        )

    def health(self, *, user_id: str, window_days: int = 30) -> Diagnostics:
        """Field Maturity Index (FMI) snapshot for one user.

        Returns a ``Diagnostics`` with ``.fmi`` (0..100), ``.coverage``,
        ``.precision``, ``.resolution``, ``.density``. Call ``.explain()``
        for a one-sentence action verdict.
        """
        self._guard_async_loop("health")
        self._authorize(user_id)
        if not isinstance(window_days, int) or not (1 <= window_days <= 365):
            raise InputValidationError(
                f"window_days must be an int in [1, 365], got {window_days!r}"
            )
        return self._transport_health(user_id=user_id, window_days=window_days)

    def add_many(
        self,
        items: list[AddItem],
        *,
        user_id: str,
        on_gate_reject: str = "skip",
    ) -> AddManyResult:
        """Bulk import. Per-item idempotency keys REQUIRED (D10).

        Skip-and-report semantics: per-item gate failures land in
        ``result.failed``, transport drops set ``result.is_partial=True``,
        idempotency replays land in ``result.duplicates``. The whole call
        only raises on ``ConnectError`` / ``RequestTimeoutError`` /
        ``AuthenticationError`` — anything else is per-item.
        """
        self._guard_async_loop("add_many")
        self._authorize(user_id)
        if not isinstance(items, list) or not items:
            raise InputValidationError("add_many() requires a non-empty list[AddItem]")
        if on_gate_reject not in {"skip", "raise"}:
            raise InputValidationError(
                f"on_gate_reject must be 'skip' or 'raise', got {on_gate_reject!r}"
            )
        return self._transport_add_many(
            items, user_id=user_id, on_gate_reject=on_gate_reject
        )

    # --- update is REFUSED ------------------------------------------

    def update(self, *args: Any, **kwargs: Any) -> Any:
        """Always raises — Atlaso deposits are immutable.

        See ``m.contradict(new_text, contradicts=[old_id], reason=...)``.
        """
        raise AttributeError(
            "Atlaso deposits are immutable evidence. To revise an earlier "
            "finding, deposit a new one with contradicts=[old_id] and an "
            f"explicit polarity. See: {_docs.CONTRADICT_GUIDE}"
        )

    # --- Internals --------------------------------------------------

    def _authorize(self, user_id: str) -> None:
        check_user_id_shape(user_id)
        if self._validate_user_id is not None:
            self._validate_user_id(user_id)

    def _guard_async_loop(self, method_name: str) -> None:
        if not self._async_warnings:
            return
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return
        emit_async_loop_warning(method_name)

    # --- Backend resolution ------------------------------------------

    def _backend(self) -> Any:
        """Resolve and cache the backing engine.

        v0.1: local-only — uses the vendored Field 3.0 engine against an on-disk
        SQLite at the resolved ``path``. v0.2 will add a remote backend when
        ``api_key=`` is set and ``api.atlaso.dev`` is live.
        """
        if hasattr(self, "_backend_instance"):
            return self._backend_instance
        from ._local import LocalBackend
        from ._path_resolver import resolve_storage_path

        base = self._path or resolve_storage_path()
        self._backend_instance = LocalBackend(base)
        return self._backend_instance

    def close(self) -> None:
        """Close the backend if open. Caller's transport (if any) is NOT closed."""
        if hasattr(self, "_backend_instance"):
            self._backend_instance.close()
            del self._backend_instance
        if self._client is not None:
            self._client.close()
            self._client = None

    # --- Transport delegations to local backend ----------------------

    def _transport_add(self, text: str, **kw: Any) -> AddResult:
        return self._backend().add(text, **kw)

    def _transport_recall(self, query: str, **kw: Any) -> SearchResults:
        return self._backend().recall(query, **kw)

    def _transport_get(self, deposit_id: str, **kw: Any) -> Deposit | None:
        return self._backend().get(deposit_id, **kw)

    def _transport_list_recent(self, **kw: Any) -> list[Deposit]:
        return self._backend().list_recent(**kw)

    def _transport_contradict(self, new_text: str, **kw: Any) -> AddResult:
        return self._backend().contradict(new_text, **kw)

    def _transport_retract(self, deposit_id: str, **kw: Any) -> RetractResult:
        return self._backend().retract(deposit_id, **kw)

    def _transport_health(self, **kw: Any) -> Diagnostics:
        return self._backend().health(**kw)

    def _transport_add_many(self, items: list[Any], **kw: Any) -> AddManyResult:
        return self._backend().add_many(items, **kw)
