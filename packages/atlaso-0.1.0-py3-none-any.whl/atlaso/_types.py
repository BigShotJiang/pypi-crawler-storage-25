"""Field 3.0 vocabulary types.

These literals MUST stay in sync with research-lab + lab-app + the Field 3.0
prompt contract. They are the data-model surface of the +10pp benchmark.
Renaming `polarity → stance` or `cautionary → qualified` was rejected per D10
because it would fork vocabulary between developer docs and research output.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

# --- The four polarity buckets — a bucket, not a spectrum ---------
Polarity = Literal["positive", "negative", "cautionary", "open"]
"""Field 3.0 polarity:

- ``positive``  — claim is supported.
- ``negative``  — claim is refuted; do not use this fact.
- ``cautionary`` — works under specific conditions; treat results with caution.
- ``open``      — undecided / question / hypothesis. The default for ``add()``.
"""

# --- The four evidence grades — gated by breadth ------------------
EvidenceGrade = Literal["anecdotal", "observed", "replicated", "verified"]
"""Field 3.0 evidence grade:

- ``anecdotal``   — one source, no measurement.
- ``observed``    — one careful measurement; default for ``add()``.
- ``replicated``  — multiple independent measurements agree.
- ``verified``    — independently checked against ground truth.

The Field 3.0 gate refuses broad-positive deposits at evidence_grade
below ``replicated``. (D8 ``DepositRejectedError`` carries ``.gate_reason``.)
"""

# --- Repro status for pipeline-level claims -----------------------
ReproStatus = Literal["unreplicated", "replicated", "failed_repro"]


@dataclass(frozen=True, slots=True)
class Scope:
    """The six experimental scope facets.

    Identity (``user_id`` / ``agent_id`` / ``run_id``) is NOT part of scope —
    that's a separate concept (D9). Scope answers *under what conditions* the
    claim holds; identity answers *whose claim it is*. Mixing them collapses
    the FMI Density component (D9).

    All facets are optional but structured. Multiple non-default facets =
    "narrow" claim (stricter evidence gate); few/none = "broad" claim
    (needs ``replicated`` evidence to clear the gate).
    """

    note: str = ""
    """Free-text scope note. Searchable. Use sparingly."""

    model: str | None = None
    """Model id (e.g. ``"qwen3.5-9b"``)."""

    dataset: str | None = None
    """Dataset id (e.g. ``"longmemeval_kutr"``)."""

    env: str | None = None
    """Environment id (e.g. ``"python"``, ``"production"``)."""

    version: str | None = None
    """Version id (e.g. ``"v0.1"``)."""

    n: int | None = None
    """Sample size."""

    seed: int | None = None
    """Random seed, if applicable."""
