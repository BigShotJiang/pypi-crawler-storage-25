"""Cross-tenant operations. Importing this module is a code-review event.

NEVER call from request handlers. NEVER expose on a public route.

These functions intentionally take a ``Memory`` instance as the first
positional arg so that ``m.search_all_users(...)`` is impossible — the
function lives on the module, not the class. They never appear on
``m.<TAB>`` autocomplete (D9).

Every function requires the literal kwarg ``confirm="I_UNDERSTAND_THIS_CROSSES_TENANTS"``.
This is not theatrics — it's the second wall:

  - Blind copy-paste from a SO answer hits a ``Literal`` type-check error.
  - Auditors ``grep "I_UNDERSTAND_THIS_CROSSES_TENANTS"`` to find every
    cross-tenant call site in the codebase.
  - Mypy/pyright catch missing or wrong literal at edit time.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from ..errors import InputValidationError

if TYPE_CHECKING:
    from ..async_memory import AsyncMemory
    from ..memory import Memory
    from ..results import Deposit


_ConfirmLiteral = Literal["I_UNDERSTAND_THIS_CROSSES_TENANTS"]


def _check_confirm(confirm: str) -> None:
    if confirm != "I_UNDERSTAND_THIS_CROSSES_TENANTS":
        raise InputValidationError(
            'atlaso.admin operations require '
            'confirm="I_UNDERSTAND_THIS_CROSSES_TENANTS" — this is a wall '
            "to keep cross-tenant reads/writes out of request handlers."
        )


def search_across_users(
    memory: Memory,
    query: str,
    *,
    confirm: _ConfirmLiteral,
    limit: int = 100,
) -> list[Deposit]:
    """Search across ALL users' memories. Admin/operator only — bypasses tenant boundary."""
    _check_confirm(confirm)
    raise NotImplementedError("v0.1.0a0: admin transport pending")


async def search_across_users_async(
    memory: AsyncMemory,
    query: str,
    *,
    confirm: _ConfirmLiteral,
    limit: int = 100,
) -> list[Deposit]:
    """Async mirror of search_across_users."""
    _check_confirm(confirm)
    raise NotImplementedError("v0.1.0a0: admin transport pending")


def list_all_user_ids(
    memory: Memory,
    *,
    confirm: _ConfirmLiteral,
) -> list[str]:
    """List every user_id that has at least one deposit."""
    _check_confirm(confirm)
    raise NotImplementedError("v0.1.0a0: admin transport pending")


def search_unscoped(
    memory: Memory,
    query: str,
    *,
    confirm: _ConfirmLiteral,
    limit: int = 100,
) -> list[Deposit]:
    """Search the global/shared deposit pool (added with add_unscoped)."""
    _check_confirm(confirm)
    raise NotImplementedError("v0.1.0a0: admin transport pending")


def add_unscoped(
    memory: Memory,
    text: str,
    *,
    confirm: _ConfirmLiteral,
) -> str:
    """Write to the global pool, not bound to any user_id.

    Returns the deposit_id. Useful for shared knowledge / system facts that
    apply to every tenant.
    """
    _check_confirm(confirm)
    raise NotImplementedError("v0.1.0a0: admin transport pending")
