"""Internal validation helpers — NOT public API.

Per D9: ``user_id`` accepts only non-empty strings of a constrained shape.
``None`` raises. This is the structural fix for CodeRedTeam's tri-state
attack — there is no ``None``-as-unscoped on the public API; pools have
their own methods (``m.add_global``, ``m.search_unscoped`` in
``atlaso.admin``).
"""

from __future__ import annotations

import re
from typing import Any

from .errors import InputValidationError

_USER_ID_RE = re.compile(r"^[A-Za-z0-9_\-:.@]{1,128}$")

_VALID_POLARITIES = ("positive", "negative", "cautionary", "open")
_VALID_EVIDENCE_GRADES = ("anecdotal", "observed", "replicated", "verified")


def check_polarity(polarity: Any) -> None:
    """Pedagogical check for the polarity literal."""
    if polarity in _VALID_POLARITIES:
        return
    raise InputValidationError(
        f"polarity must be one of {list(_VALID_POLARITIES)}, got {polarity!r}.\n"
        "Polarity is the stance of this fact:\n"
        "  · positive   — supported by the evidence you have\n"
        "  · negative   — refuted; do not use this fact going forward\n"
        "  · cautionary — works only under specific conditions\n"
        "  · open       — undecided / question / hypothesis (the default)"
    )


def check_evidence_grade(evidence_grade: Any) -> None:
    """Pedagogical check for the evidence_grade literal."""
    if evidence_grade in _VALID_EVIDENCE_GRADES:
        return
    raise InputValidationError(
        f"evidence_grade must be one of {list(_VALID_EVIDENCE_GRADES)}, got {evidence_grade!r}.\n"
        "Evidence grade is how strong the support is:\n"
        "  · anecdotal  — single source, no measurement (default for add())\n"
        "  · observed   — one careful measurement\n"
        "  · replicated — multiple independent measurements agree\n"
        "  · verified   — independently checked against ground truth"
    )


def check_user_id_shape(user_id: Any) -> None:
    """Raise InputValidationError if user_id is not a valid non-empty string.

    user_id rules:
      - 1–128 chars
      - alphabetic, digit, ``_``, ``-``, ``:``, ``.``, ``@``
      - non-empty
      - not ``None``

    The error messages are pedagogical — they tell the developer what to do
    next, not just what went wrong.
    """
    if user_id is None:
        raise InputValidationError(
            "user_id is required and cannot be None. "
            "Pass an authenticated identity from your auth layer, e.g.\n"
            "    m.add(text, user_id=auth.user.id)\n"
            "or use m.for_user(auth.user.id) once and call methods on the handle.\n"
            "See https://docs.atlaso.dev/sdk/authorization."
        )
    if not isinstance(user_id, str):
        raise InputValidationError(
            f"user_id must be a string (got {type(user_id).__name__}: {user_id!r}). "
            "If you have a numeric user id, convert it: user_id=str(user.id)."
        )
    if not user_id or not user_id.strip():
        raise InputValidationError(
            "user_id cannot be empty. Use the authenticated identity from "
            'your auth layer; for single-user scripts pass user_id="me".'
        )
    if not _USER_ID_RE.match(user_id):
        raise InputValidationError(
            f"user_id must be 1–128 characters of [A-Za-z0-9_-:.@]. Got {user_id!r}.\n"
            "Common fixes:\n"
            "  · slashes / spaces / quotes are not allowed — sanitize before passing\n"
            "  · email is fine: user_id=\"alice@example.com\"\n"
            "  · UUIDs are fine: user_id=str(uuid)\n"
            "If this value came from a request body, you have a tenant-isolation "
            "bug — see https://docs.atlaso.dev/sdk/authorization."
        )
