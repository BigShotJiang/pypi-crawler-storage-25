"""Storage path resolution for ``Memory()`` per D7 (Option A.2).

Resolution algorithm:

  1. Explicit override: if ``path=`` is passed to ``Memory()``, use it.
  2. ATLASO_PATH env var (12-factor escape hatch).
  3. Pass 1 — nearest ancestor ``.atlaso/`` directory wins.
  4. Pass 2 — nearest project root (closed allowlist:
     ``pyproject.toml``, ``package.json``, ``.git``, ``Cargo.toml``,
     ``go.mod``). Creates ``<root>/.atlaso/`` on first write.
  5. Pass 3 — cwd IS the project root. Creates ``<cwd>/.atlaso/``.
  6. **No `~/.atlaso/` fallback. Ever.**
  7. **No I/O in __init__.** First mutating call is the trigger.

Walk terminator: filesystem root or ``$HOME``, whichever comes first.
Symlinks resolved via ``realpath``; walk depth capped at 64.

(D7 deposit: 23d2a8f3-8a97-41c8-bc04-986bebfbe02d.)
"""

from __future__ import annotations

import os
from pathlib import Path

_PROJECT_MARKERS = (
    "pyproject.toml",
    "package.json",
    ".git",
    "Cargo.toml",
    "go.mod",
)
_MAX_WALK_DEPTH = 64


def resolve_storage_path() -> Path:
    """Resolve the ``.atlaso/`` directory per Option A.2."""
    # Rule 2 — ATLASO_PATH env var.
    env_path = os.environ.get("ATLASO_PATH")
    if env_path:
        return Path(env_path).expanduser().resolve()

    cwd = Path.cwd().resolve()
    home = Path.home().resolve()
    chain: list[Path] = [cwd]
    chain.extend(cwd.parents)
    chain = chain[:_MAX_WALK_DEPTH]

    # Pass 1 — nearest ancestor `.atlaso/`.
    for d in chain:
        if d == home or d.parent == d:  # stop at $HOME or filesystem root
            break
        if (d / ".atlaso").is_dir():
            return d / ".atlaso"
        if d == home:
            break

    # Pass 2 — nearest project root.
    for d in chain:
        if d == home and d.parent != d:  # walk INTO $HOME but not above
            break
        if any((d / m).exists() for m in _PROJECT_MARKERS):
            return d / ".atlaso"
        if d.parent == d:  # filesystem root
            break

    # Pass 3 — cwd IS the project root.
    return cwd / ".atlaso"
