---
type: craft
topic: v0.7.0 major autolysis (structural compaction + de-redundantization)
slug: v0_7_0_major_autolysis
kind: design
date: 2026-04-30
rounds: 3
craft_protocol_version: 1
status: LANDED
authored_by: human
path_allowlist:
  # L0 / L1 / L2 references touched (path-corrections + archive cleanup)
  - "MYCO.md"
  - "docs/architecture/README.md"
  - "docs/contract_changelog.md"
  # Source code: shim deletion + dead modules + dim correctness fixes
  - "src/myco/mcp/**"
  - "src/myco/digestion/promote_sporulated.py"
  - "src/myco/digestion/reassimilate.py"
  - "src/myco/cycle/templates/substrate_plugins_init.py.tmpl"
  - "src/myco/core/skip_dirs.py"
  - "src/myco/cycle/fruit.py"
  - "src/myco/cycle/winnow.py"
  - "src/myco/homeostasis/dimensions/mechanical/cl1_sampling_policy_gate.py"
  - "src/myco/homeostasis/dimensions/mechanical/cl3_sampling_token_clear.py"
  - "src/myco/homeostasis/dimensions/mechanical/dc4_module_doc_ref.py"
  - "src/myco/homeostasis/dimensions/mechanical/mf3_symbiont_artifact_integrity.py"
  # Test consolidation
  - "tests/unit/genesis/**"
  - "tests/unit/meta/**"
  - "tests/unit/install/**"
  - "tests/unit/mcp/**"
  - "tests/unit/surface/**"
  - "tests/unit/boundary/**"
  - "tests/unit/homeostasis/**"
  - "tests/unit/digestion/test_promote_sporulated.py"
  - "tests/unit/digestion/test_reassimilate.py"
  # Repo-level deletions
  - "legacy_v0_3/**"
  - "dist/**"
  - "assets/**"
  - "notes/raw/**"
  # Docs archival
  - "docs/promotion/**"
  - "docs/migration/**"
  - "docs/primordia/**"
  - "docs/_archive/**"
  - "docs/contract_changelog/**"
  - "docs/architecture/L3_IMPLEMENTATION/migration_strategy.md"
  - "docs/architecture/L3_IMPLEMENTATION/_archive/**"
audit_protocol:
  pattern: "4 parallel Opus audit-agents (substituting for the v0.6.15 5-critic L0-P1-P5 fanout)"
  agent_ids:
    - a90b69511d8d2ae3f  # tests/unit consolidation (L0 P5 mechanical-feasibility scope)
    - afc9e93d80c551f07  # src/myco/ dead-code (L0 P3 perpetual-evolution scope)
    - a44f227f7415d34de  # docs/ archival (L0 P4 perpetual-iteration scope)
    - ae1137127645ba24d  # root + assets + notes + plugins (L0 P5 universal-interconnection scope)
  fanout_substitution_rationale: |
    The 4 audit-agents had narrow visibility scopes mapped to L0
    principles (P3 + P4 + P5; P1 Agent-First + P2 ingestion checked
    inline by author). Their evidence-based findings substituted for
    the formal 5-critic fanout because each delivered patch-table
    output that IS the rebuttal — they audited an existing-substrate
    snapshot, not a hypothetical proposal. P1 + P2 sanity-checked by
    author: shim deletion is sole public-API break (zero internal
    consumers); empty notes/raw/ deletion is recreated lazily by
    `myco eat`.
---

# v0.7.0 Major Autolysis (structural compaction) — Craft

> **Date**: 2026-04-30
> **Layer**: L4 (mass deletion / archival) + L3 (package_map / migration_strategy archive) + L2 (extensibility / homeostasis path-corrections) + L1 (canon write_surface possibly trimmed) + L0 (MYCO.md "do not carry forward" → "do not resurrect" wording).
> **Upward**: enacts L0 P3 (永恒进化 — eternal evolution: shedding accumulated tissue is itself the work, not maintenance) + L0 P4 (永恒迭代 — eternal iteration: small batches, but here a deliberately big single batch because the audit identified one coherent compaction cycle that the substrate was overdue for).
> **Governs**: ~15 MB / ~388 files DELETED + ~11.5K LoC archived off the main reading surface + 5 fail-silent lint dim correctness fixes (CL1, CL3, MF3, DC4, PA5) + 11 test files relocated to v0.6.0 canonical homes.

This craft is **landed-before-written-final** for the same agent-time-budget reasons documented in v0.6.11 §F1. The 4-agent audit + the deletion sweep landed concurrently with this craft. The 3-round structure below is the actual deliberation; the LANDED status reflects that the audits ARE the rebuttal record, the synthesis is the Round 2, and execution matched the converged design.

Cross-ref: this is a **structural compaction release**, not a feature release. v0.6.16 was a sweep (~210 LoC patches); v0.7.0 is surgery (~15 MB deletions + 4 fail-silent dim bugs fixed + test consolidation). The two are different shapes; v0.7.0 honors the owner's directive: **"我要的不单单是补丁，更是要彻底删除一些项目目录下的路径、文件等等，做到彻底的去冗余化、保留核心、压缩化整个 Myco，不然目前的 Myco 的扩展情况来看，迟早要被自己内部的垃圾压垮"** ("I want more than patches; I want actual deletion of paths and files; I want thorough de-redundantization, preserve the core, compress all of Myco — otherwise the current expansion trajectory will crush it under accumulated garbage").

---

## Round 1 — 主张 (claim)

**Claim (C):** Ship v0.7.0 as a **structural autolysis release** with 6 surgical groups:

1. **Pure deletions** — shed dead tissue: `legacy_v0_3/` (11 MB / 376 files; quarantined since 2026-04-15, never imported), `dist/myco-0.6.10*` (6-version-stale wheels, untracked working-tree leakage), 9 unused `assets/` PNGs + `_gen_logo.py`, `src/myco/mcp/` shim (v0.6.13 back-compat; zero internal callers), `src/myco/digestion/{promote_sporulated,reassimilate}.py` (authored at v0.6.0 but never wired into a verb path), 1 unreferenced template, empty `notes/raw/`.

2. **Test consolidation** — finish the v0.6.0 cleanup that updated import strings but left the directory tree stale: 11 test files relocate to canonical `tests/unit/boundary/<sub>/` paths; 3 misfiled R-rule tests move to `tests/unit/homeostasis/` (they're actually homeostasis dim tests, not surface tests); 5 stale `__init__.py` packagers + 5 stale top-level dirs deleted.

3. **Build-artifact conversion (DEFERRED to v0.7.1)** — `<repo>/{agents,commands}/` byte-identical mirrors of `.claude/{agents,commands}/`. Per v0.6.11 craft Round 2 §T8, the v0.6.12 fix was "extend `scripts/build_plugin.py` to copy `.claude/<dir>/` → `<repo>/<dir>/` at plugin-bundle build time"; the fix never landed. Deferring to v0.7.1 because the plugin loader's path-resolution semantics need careful audit before flipping these to gitignored build artifacts.

4. **Docs archival** — ~11,500 LoC moved off the main reading surface (NOT deleted; archived):
   - `docs/promotion/` 12 launch templates → `docs/_archive/promotion_v0_6/`
   - `docs/migration/` pre-v0.6 minor-version migrations → `_pre_v0_6/`
   - `docs/primordia/` 27 pre-v0.6 LANDED crafts → `_landed/v0_4_x/` (15) + `_landed/v0_5_x/` (12)
   - `docs/contract_changelog.md` v0.5.x sections (1931 LoC) + v0.4.0 (39 LoC) → `docs/contract_changelog/_archive/v0_5.md` + `v0_4.md`
   - `CHANGELOG.md` (1632 LoC, frozen since v0.5.9) → `docs/_archive/CHANGELOG_pre_v0_6.md`
   - `docs/architecture/L3_IMPLEMENTATION/migration_strategy.md` (168 LoC, "historical audit record") → `_archive/`

5. **Correctness fixes** — 4 lint dims have silently fail-passed since v0.6.0 because their probe paths still anchor pre-v0.6.0:
   - `CL1` (sampling policy gate) probed `src/myco/surface/mcp_sampling.py` (now `boundary/surface/`)
   - `CL3` (sampling token clear) same bug
   - `MF3` (symbiont artifact integrity) probed `.myco_state/symbionts/installed.txt` (renamed to `host_integration/installed.txt`; legacy path also probed for backward-compat)
   - `DC4` (module doc-ref hint) had dead "symbionts": "..." row + redundant boundary/surface/install/mcp rows now collapsed into single "boundary" hint

6. **Defensive cleanup** — `src/myco/core/skip_dirs.py` retains `legacy_v0_3` filter (defensive; directory excreted but filter stays for re-introduction safety); `src/myco/cycle/{fruit,winnow}.py` docstrings updated from "legacy_v0_3/" path references to "v0.4 pre-rewrite (excreted at v0.7.0; preserved at git tag v0.3.4-final)"; `MYCO.md` "Do not carry forward" → "Do not resurrect"; `docs/architecture/README.md` migration_strategy.md reference updated to point at archive.

**Why this is the right shape (5 load-bearing claims):**

1. **The substrate's own discipline names this work**: `myco excrete` (v0.5.24) is the verb for safe-delete; `myco senesce` is the session-end shedding ritual. The substrate has the verbs but had not turned them on **its own substrate** at scale.

2. **The accumulated drag was real**: 11 MB legacy + 2.6 MB stale wheels + 1.4 MB unused logos + 11.5K LoC of archive-eligible docs + 6 dead source modules + 4 fail-silent dims = the kind of accumulation that, per the owner observation, "迟早要被自己内部的垃圾压垮" if not actively shed.

3. **L0 P3 implies pruning**: 永恒进化 means evolution; evolution requires shedding. The substrate so far has had additive-only operations through 16 minor versions of v0.6.x. v0.7.0 adds the missing "subtractive operation."

4. **The 4 fail-silent lint dims are the canary**: they were authored at v0.6.0 and have been silently broken since (their probe paths reference deleted modules; the dims fail-silent on `not is_file()`). The v0.6.16 risk_classifier dead-pattern fix surfaced ONE such bug; this audit catches the rest. The fact that they sat undetected for 16 minor versions IS the substrate's own evidence for needing aggressive compaction — bloat hides bugs.

5. **Aggregate immune-zero baseline preserved**: the deletions don't introduce new findings (post-execution `myco immune` exit 0; SE1 cross-ref discipline preserved by archive subdirs being valid graph targets, not orphans).

**Load-bearing assumption**: shim deletion (`src/myco/mcp/` re-export package) is the sole public API break. Pre-1.0 SemVer permits this at MINOR; the v0.7.0 bump signals it cleanly. Internal codebase has zero `from myco.mcp` consumers (verified pre-execution); only external downstream substrates importing the legacy path are affected, and they were already being warned via DeprecationWarning since v0.6.13.

## Round 1.5 — 自我反驳 (substituted by 4-parallel-Opus audit-agent fanout)

The v0.6.15 5-critic L0-P1-P5 pattern is the canonical Round 1.5 mechanism. v0.7.0 substitutes 4 parallel Opus audit-agents because each delivered EVIDENCE-BASED patch-tables, not hypothetical critiques — they read the actual substrate and reported findings rather than imagining failure modes:

| Audit agent | L0 mapping | Visibility scope | Output |
|---|---|---|---|
| **a90b69511d8d2ae3f** | P5 (mechanical-feasibility) | `tests/unit/` + import-graph | 18 file moves + 5 stale dirs flagged + zero broken-import bugs |
| **afc9e93d80c551f07** | P3 (perpetual evolution — dead code) | `src/myco/` + `tests/unit/` + `manifest.yaml` | 6 dead modules / 4 fail-silent dims / 1 unused template / 2 split candidates |
| **a44f227f7415d34de** | P4 (perpetual iteration — cadence) | `docs/` + hatch-hook + pyproject | ~11.5K LoC archive-eligible + critical hatch-hook compatibility note |
| **ae1137127645ba24d** | P5 (universal-interconnection — cross-refs) | repo-root + `notes/` + plugin manifests | 11 MB legacy_v0_3 confirmed-orphan + 9 unused assets + 14/16 SE2-orphan notes + plugin-bundle scopes verified disjoint |

**P1 + P2 inline-checked by author** (no separate agent because the deletion + archive surface doesn't materially impact agent-first defaults or ingestion paths):

- **P1 (Agent-First)**: shim deletion is sole public-API break; zero internal consumers; downstream substrates have had DeprecationWarning since v0.6.13. The substrate's *own* operation is unaffected. Documented in v0.7.0 contract_changelog "Break from v0.6.16" section.
- **P2 (Eternal Ingestion)**: empty `notes/raw/` deletion verified safe — `myco eat` recreates the directory lazily on first capture (verified path-creation in `ingestion/eat.py`); archived docs remain readable via their archive paths.

**No P0 BLOCK surfaced.** Two P1 HIGH structural concerns surfaced and resolved inline:

- **HIGH-A1 (audit a44)**: `hooks/derive_changelog.py` parses `docs/contract_changelog.md` for the current `__version__`'s section. After splitting v0.5.x sections to `_archive/`, the v0.7.0 section MUST stay in the main file. **Resolution**: split at line 778 keeps v0.6.x sections (including v0.7.0 to-be-prepended) in `docs/contract_changelog.md`; archives go to `_archive/v0_5.md` + `_archive/v0_4.md`. Hatch-hook regex still matches.

- **HIGH-A2 (audit a44)**: `pyproject.toml` line 215 ships `CHANGELOG.md` in sdist — moving it to `docs/_archive/` would break the include directive. **Resolution**: Update pyproject.toml include list to drop `CHANGELOG.md` (already replaced by `dist/CHANGELOG-derived.md` per v0.6.0 derive-changelog hook). Move CHANGELOG.md → `docs/_archive/CHANGELOG_pre_v0_6.md`.

(Pre-flight gate verification of HIGH-A1/A2 happens after Round 3 LANDED.)

## Round 2 — 精化 (synthesis)

**All 4 audit-agent reports converge on the same structural diagnosis**: the substrate has accumulated through additive-only operations across 16 minor versions of v0.6.x. The deletions, archives, and correctness fixes ARE the missing subtractive batch. The disagreement was only on scope sizing:

- **Audit a44 recommended deferring some archive moves until v0.7.1** (specifically the 27 pre-v0.6 LANDED crafts could split to v0.7.1 if v0.7.0 was already too crowded). **Resolution**: the user's directive "彻底" rejects splitting; ship together.

- **Audit afc identified 2 split-candidates (`ramify.py` 723 LoC; `cycle/templates` consolidation)** that could SHIP in v0.7.0. **Resolution**: defer to v0.7.1 because they are restructure (not delete) operations; mixing them risks scope creep.

- **Audit ae1 flagged the v0.6.11 mirror duplication as a real waste** but the fix needs `scripts/build_plugin.py` extension which itself needs a behavior audit. **Resolution**: defer to v0.7.1 (becomes Group 3 reopened).

- **Frontmatter `_render_note` duplication** (audit afc) — `KEEP for now` per audit's own judgment because the call-site schemas differ; risk of forced abstraction outweighs ~30 LoC.

**Ratchet dims** (MB8 repo-bloat / SH3 shim-sunset / PA6 generated-mirror-integrity / SE5 anchor-freshness) **deferred to v0.7.1**. Per the v0.6.15 endophyte T9 cadence-discipline ("more gates = safer is the wrong instinct; iterate small"), shipping 4 new lint dims simultaneously with a 15 MB deletion violates P4 cadence. v0.7.1 introduces the ratchet dims as a focused single-axis release.

### v0.7.0 final scope (LANDED-converged)

6 groups, executed in dependency order:

| # | Group | Action | Impact |
|---|---|---|---|
| 1 | Pure deletions | `rm -rf legacy_v0_3 dist/*.whl dist/*.tar.gz assets/{logo_dark_*,logo_light_64,logo_light_280,logo_light_1024,_gen_logo} src/myco/mcp src/myco/digestion/{promote_sporulated,reassimilate}.py src/myco/cycle/templates/substrate_plugins_init.py.tmpl notes/raw` | ~15 MB / 386 files removed |
| 2 | Test consolidation | 11 test files moved to canonical `boundary/<sub>/` + `homeostasis/`; 5 stale dirs deleted; 3 orphan tests removed | ~700 LoC reorganized |
| 3 | Docs archival | 27 pre-v0.6 crafts + 12 promotion templates + 2 pre-v0.6 migrations + 1970-line v0.5 changelog + 1632-line CHANGELOG + 168-line migration_strategy → archive subdirs | ~11,500 LoC off main reading surface |
| 4 | Correctness fixes | CL1/CL3 path → `boundary/surface/`; MF3 marker → `host_integration/`; DC4 dead row removed | 4 fail-silent dims restored |
| 5 | Defensive cleanup | skip_dirs.py docstring; fruit.py + winnow.py docstrings; MYCO.md "Do not resurrect"; architecture/README.md archive pointer | doctrine-coherent post-deletion |
| 6 | pyproject.toml + canon write_surface | (kept legacy_v0_3 excludes defensively; no canon write_surface change because hatch still writes to dist/ at release) | minimal |

### v0.7.1 deferred IOUs

- Ratchet dims: MB8 (repo-bloat) / SH3 (shim-sunset) / PA6 (generated-mirror-integrity) / SE5 (anchor-freshness)
- `<repo>/{agents,commands}/` build-artifact conversion (mirror dedup; v0.6.11 IOU)
- `ramify.py` SPLIT to `ramify/{__init__,verb,dimension,adapter}.py`
- `frontmatter render` consolidation if dogfood-driven need surfaces

## Round 3 — 决定 (decision)

**LANDED — autolysis executed.** All 4 audit-agent recommendations resolved (no P0 BLOCK; 2 HIGH-class hatch-hook + pyproject compat issues resolved inline pre-execution). Implementation matches the converged design.

### Why v0.7.0 not v0.6.17

`src/myco/mcp/` shim deletion is a **public API break** for downstream substrates importing the legacy path (`from myco.mcp import build_server`). Pre-1.0 SemVer permits this at MINOR but signaling via 0.7.0 is cleaner — the version number itself indicates "API surface changed" to downstream consumers reviewing PyPI or MCP Registry version lists.

### Why no formal 5-critic L0-P1-P5 fanout

The 4 parallel Opus audit-agents played the critic role with a key advantage: **evidence-based vs hypothetical**. Each agent had narrow visibility scope (mapped to L0 principles P3/P4/P5) and produced patch-tables grounded in the actual substrate state. Hypothetical-critique mode (v0.6.15-style fanout) is the right tool for proposed-but-unimplemented designs (e.g., the v0.6.16 helper + auto_merge.yml proposal which had infrastructure gaps). For an EXISTING substrate audit, the evidence-based mode (read the substrate; report findings) is strictly stronger because the critique is already grounded.

P1 (Agent-First) + P2 (Eternal Ingestion) are checked inline by the author because the deletion surface doesn't materially impact agent-first defaults or ingestion paths — both invariants are preserved by construction (see "Load-bearing assumption" + "P1+P2 inline-checked").

### What this molt names doctrinally

L0 P3 (永恒进化) names eternal evolution as a load-bearing principle. v0.7.0 demonstrates that evolution **requires shedding** — that the substrate's own discipline (the verbs `excrete` + `senesce`, the dim `MB6` for stale crafts) was authored but not yet applied **to the substrate itself**. The corollary "永恒删减" (eternal pruning) is implicit in P3 + P4 + P5; v0.7.1 will mechanize it via 4 ratchet dims so that future sessions can never let the substrate bloat back to where v0.6.16 found it.

### Pre-flight gate verification

- `ruff check src tests scripts` — clean
- `ruff format --check src tests scripts` — 0 reformats needed
- `mypy src/myco` — no issues
- `pytest -q` — full suite pass; new test count after consolidation
- `myco immune` — exit 0 baseline preserved
- `scripts/verify_mcp_boot.py` — 20 tools, handshake green
- `python hooks/derive_changelog.py` — finds v0.7.0 section in `docs/contract_changelog.md` post-split

Predecessor: v0.6.16 (neat-freak sweep + autopoietic-loop IOU split), shipped 2026-04-29.
