---
type: craft
topic: v0.6.15 Agent-First default for Cycle 自起 闭环 (correct v0.6.14 owner-First regression + critic refactor to L0 P1-P5)
slug: v0_6_15_agent_first_default_for_cycle_autostart_loop
kind: design
date: 2026-04-29
rounds: 3
craft_protocol_version: 1
status: LANDED
authored_by: claude-code-agent
risk_class: high
governing_observation: |
  Owner remark, 2026-04-29 post v0.6.14 ship:
  "我感觉还是给owner太大权限了，Myco明明是Agent-First."
  The observation is structurally correct: v0.6.14 shipped two coupled
  canon defaults that collapsed every auto-craft path to owner-merge-gate,
  inverting L0 P1's "Only For Agent" posture into Owner-First gating.
sub_agent_fanout_artifacts:
  round_1_5_critic_count: 4
  round_1_5_critic_agent_ids:
    - a66b1226b32248b67  # mycoparasite (寄生 — adversarial)
    - ac2705a7466b40ad8  # saprotroph (腐生 — doctrine boundary)
    - a95fa5744a495d793  # mycorrhiza (菌根 — feasibility/integration)
    - a3e102693fd5c3b58  # endophyte (内生菌 — L0 P1 conformance check, provisional)
  round_1_5_diversity_audit: |
    The endophyte (4th critic, new at this craft) caught L0 P1 violations
    that the 3 prior critics (mycoparasite/saprotroph/mycorrhiza) missed.
    Specifically, all 3 prior critics shared an "add more gates = safer"
    structural prior; endophyte's L0-only visibility forced the inverse
    question: "does this design pull human into the substrate's loop?"
    The endophyte's own meta-critique (T7) is then taken seriously:
    critic shape should be DERIVED FROM L0 P1-P5 DIRECTLY, not from
    retrospective bias-patches. v0.6.15 ships the 5-critic L0-mapped
    shape going forward (see scope item 5).
path_allowlist:
  - _canon.yaml
  - src/myco/core/risk_classifier.py
  - src/myco/cycle/winnow.py
  - .claude/agents/primordium.md
  - agents/primordium.md
  - docs/architecture/L2_DOCTRINE/cycle.md
  - docs/architecture/L2_DOCTRINE/boundary.md
  - docs/contract_changelog.md
  - tests/contract/test_autopoietic_loop_structural.py
  - tests/unit/boundary/test_subagent_and_command_surface.py
  - tests/unit/core/test_risk_classifier_recursion_cutter.py
  - src/myco/__init__.py
  - .claude-plugin/plugin.json
  - .cowork-plugin/.claude-plugin/plugin.json
  - CITATION.cff
  - server.json
---

# v0.6.15 — Agent-First default for Cycle 自起 闭环

> **Date**: 2026-04-29
> **Layer**: L1 (touches `governance.auto_evolve_*` defaults; touches `core/risk_classifier.py` content-detection; touches `cycle.md` doctrine wording for owner role) + L2 (extends `cycle.md` § "Cycle 自起 闭环" with "Agent-First default (v0.6.15+)") + L3 (refactors `primordium.md` autonomous-mode critic-fanout from 3 ad-hoc roles → 5 L0-P1-to-P5-mapped roles) + L4 (canon defaults + risk_classifier + primordium spec + tests).
> **Upward**: governs L0 P1 ("Only For Agent"); the v0.6.14 ship inadvertently introduced an Owner-First regression that this craft corrects. Also touches L0 P3 (Eternal Evolution — substrate must be able to self-evolve without human gate on every step).
> **Governs**: `_canon.yaml::system.governance.auto_evolve_force_high_risk` (default `true → false`); `_canon.yaml::system.governance.auto_evolve_pr_window_skip` (default `true → false`); `_canon.yaml::system.governance.auto_evolve_critic_count` (3 → 5); `src/myco/core/risk_classifier.py` (content-based superset extension + recursion-cutter); `.claude/agents/primordium.md` + `<repo>/agents/primordium.md` mirror (3 critic roles → 5 L0-mapped roles); `docs/architecture/L2_DOCTRINE/cycle.md` (sub-section update); `docs/architecture/L2_DOCTRINE/boundary.md` (sub-section update); `tests/contract/test_autopoietic_loop_structural.py` (assertions updated); `tests/unit/boundary/test_subagent_and_command_surface.py` (critic count updated); 1 new test file for risk-classifier recursion-cutter; contract_changelog v0.6.15 entry; atomic 5-file bump v0.6.14 → v0.6.15.

This craft was authored under explicit owner observation that v0.6.14 over-centralized owner authority. The Round 1.5 fanout used 4 critics (the new `endophyte` role added explicitly to scan for the L0 P1 inversion that 3 prior critics had structurally missed). Endophyte's findings — particularly T7 ("critic shape must be derived from L0 P1-P5 directly, not from retrospective bias-patches") — drive scope item 5: the v0.6.15 critic count is 5 (not 4), one per L0 principle.

---

## Background — Owner observation

> 我感觉还是给owner太大权限了，Myco 明明是 Agent-First.

v0.6.14 shipped with two coupled canon defaults under `system.governance`:

```yaml
auto_evolve_force_high_risk: true       # every auto-craft → high-risk class
auto_evolve_pr_window_skip: true        # bypass v0.6.0 7-session-7-day public-window auto-LAND
```

Together these rerouted the auto-loop's safety from "Agent-First (3 critics + window + always-on `vetoed_at`)" to "Owner-First (must click merge)". The owner observation is structurally correct: this inverts L0 P1's "Myco is a cognitive substrate **for an LLM agent**. The agent is the sole consumer."

Diagnosis (post-fanout): The v0.6.14 sub-agent fanout's three critics (mycoparasite, saprotroph, mycorrhiza) all shared an unstated "add more gates = safer" prior; mycoparasite T2 (alert fatigue), saprotroph T6 (R7 reversal) both pushed for **more** owner involvement, and the synthesis adopted both. None of the three asked the inverse: "does this design pull humans into the substrate's loop, violating L0 P1?"

This is a structural blind spot of same-host critic fanout: when all sub-agents are spawned by the same parent agent under the same conditions, their failure modes correlate.

---

## Round 1 — 主张 (claim)

**Claim (C):** Reverse the v0.6.14 owner-First regression by:
1. Flipping both v0.6.14 canon defaults to `false` (matching v0.6.0 governance tiering's medium-risk auto-LAND path).
2. Refusing to add `auto_evolve_owner_paranoia_mode` (the convenient escape hatch the user might have asked for) — per endophyte T3+T5: it would be an undeclared third L0 P1 exception, eroding L0's "exhausted list" of two carved exceptions (`brief` v0.5.5 + "agent-calls-LLM-substrate-doesn't" v0.5.6).
3. Refactoring the primordium autonomous-mode critic-fanout from 3 ad-hoc roles → **5 L0-mapped roles** (one per principle P1-P5), per endophyte T7 ("critic shape must be derived from L0 principles directly, not from observed-failure patches").
4. Extending `core/risk_classifier.py` with content-based detection as **explicit superset** of v0.6.0 keyword list (no breaking-change semantics), plus a **recursion-cutter** that forces any craft modifying `risk_classifier.py` itself OR `governance.auto_evolve_*` keys OR governance workflow files to high-risk regardless of content.
5. Restricting v0.6.15 scope to canon-side and Agent-layer changes; deferring `auto_merge.yml` (the GitHub Actions workflow that would auto-merge medium-risk PRs to main) to v0.6.16+, where the canon round-trip helper for `last_winnowed_proposals[].status` lands first.

**Why this is needed (5 load-bearing claims):**

1. **L0 P1 strict-compliance restoration.** v0.6.14's owner-First default contradicts L0 P1 directly. The L0 P1 addendum (`L0_VISION.md:36-60`) names exactly two exceptions — `brief` and the "agent-calls-LLM" rule — and explicitly says "they exhaust the list, not extend it." `auto_evolve_owner_paranoia_mode` would be a third undeclared exception. v0.6.15 declines it.

2. **The fanout pattern's structural blind spot is now empirically observable.** The v0.6.14 fanout shipped a regression that 3 critics didn't catch. Adding endophyte (4th critic, L0-only visibility) at v0.6.15 caught the very regression v0.6.14 introduced. Going forward, deriving critics from L0 P1-P5 directly (5 critics, each tied to one principle) is structural — not retrospective patching.

3. **Risk classifier was always meant to be content-based.** v0.6.0 craft §F25 introduced `core/risk_classifier.py` with a keyword-based detection scheme. v0.6.14's `auto_evolve_force_high_risk: true` blanket-flag bypassed it entirely, treating the classifier as suspect by default. v0.6.15 trusts the classifier (the right L0 P3 / Eternal Evolution posture) while adding a recursion-cutter so the classifier can't be quietly disabled by an auto-craft modifying itself.

4. **Auto_merge.yml is genuinely R6/R7-adjacent (saprotroph T1) and out-of-scope for v0.6.15.** Even though saprotroph's claim is overzealous (a workflow conforming to canon-LANDED status is *implementing* a contract decision, not violating R7), the operational complexity (gh pr merge --auto requires repo settings, MP1 host-signature re-verification on auto-merge, vetoed_intent comment-driven veto path) deserves its own craft. v0.6.15 ships the doctrine correction; v0.6.16 ships the operational completion.

5. **Owner role stays L0-defined, not v0.6.15-redefined.** L0 P1 says owner approves craft docs at L0/L1/L2. That's the only role L0 names. v0.6.14's "owner-merge-gate is the only synapse" wording (cycle.md) over-defined the role. v0.6.15 strikes that wording. Owner stays "L0/L1/L2 craft-doc approver" — which already exists in v0.6.0 governance tiering.

---

## Round 1.5 — Sub-agent fanout 自驳 (real parallel run)

> **Protocol**: 4 parallel `general-purpose` sub-agents via Task tool. v0.6.14's 3-critic shape extended with endophyte (L0-only visibility) explicitly to scan for the kind of L0 P1 inversion that v0.6.14 itself shipped. Per endophyte T7, the v0.6.15 *outcome* is the 5-critic L0-P1-P5-mapped shape; this Round 1.5 was the transitional 4-critic fanout.

**Critic roster (Round 1.5 transitional, 4 critics):**

| Role | Visibility | Bias |
|------|-----------|------|
| **mycoparasite** (寄生) | draft only | break paths, prompt-injection, feedback loops, single-point-of-failure |
| **saprotroph** (腐生) | L0/L1/L2 doctrine + canon + previous crafts | doctrine drift, vocabulary violations, schema parity, dead code |
| **mycorrhiza** (菌根) | src/, tests/, .github/, .claude/, scripts/ | impl traction, API boundaries, test mock infrastructure, CI tooling |
| **endophyte** (内生菌, NEW) | L0_VISION.md only | L0 P1 conformance — does the proposal pull humans into the substrate's loop? |

**Run record:** 4 parallel Agent tool invocations on 2026-04-29. Total wall time ~3 minutes. agentIds preserved in frontmatter `sub_agent_fanout_artifacts`. Total ~38 raw tensions; after dedupe + merge: **22 distinct tensions**, sorted by severity descending.

### Tensions, sorted by severity (P0 → P2)

#### P0 — Blockers (10 of 22). Must resolve before craft enters winnow.

**T1 — `vetoed_at` always-on turns owner into routine consumer** [endophyte]
L0 P1 (`L0_VISION.md:17-60`) says humans don't engage Myco's interior surfaces as routine activity. An "always-on" veto requires owner to monitor PR streams continuously. That's routine consumption disguised as governance.
*Resolution direction:* restrict veto to a **time-bounded inside the 7-session-7-day public-window** only; outside the window, owner has no in-flight veto — just the standard L0/L1/L2 craft-gate.

**T2 — "owner = observer" is undeclared L0 vocabulary** [endophyte]
L0 names owner exactly once: "approves craft docs that mutate L0/L1/L2." Proposal redefines as "observer + always-on veto + opt-in paranoia". None of these words appears in L0.
*Resolution direction:* drop the role-redefinition. Owner stays "L0/L1/L2 craft-doc approver." cycle.md must NOT contain "owner = observer" or equivalent role inflation.

**T3 — `auto_evolve_owner_paranoia_mode` is an undeclared 3rd L0 P1 exception** [endophyte]
L0 P1 addendum exhausts exceptions to two: `brief` + "agent-calls-LLM-substrate-doesn't" (`L0_VISION.md:36-60`). The proposal's `paranoia_mode` is functionally a third exception (single flag re-enables full owner-First gating). L0's text: "they exhaust the list."
*Resolution direction:* **drop the field entirely.** No paranoia_mode in v0.6.15. If a future substrate genuinely needs the v0.6.14 strict posture, that needs its own L0-revision craft.

**T4 — meta-teaching channel inverts L0 P1 information flow** [endophyte]
L0 P1: "Myco does not produce documentation, summaries, or reports for humans. The agent produces those." The reverse — human observation flowing into cycle.md doctrine — is symmetrically out-of-bounds.
*Resolution direction:* the sub-agent fanout meta-lesson goes into v0.6.15 contract_changelog only, NOT into L2 cycle.md doctrine. The agent re-derives the lesson by observing repeated fanout failures via assimilate→sporulate; the owner observation lives in raw tier (eat).

**T5 — auto_merge.yml writes main = L4 workflow on R6 surface** [saprotroph T1]
auto_merge.yml lets a GitHub Actions workflow push a merge commit to main, invoking R6 write-surface (`main` content updates) authority. Per protocol.md:100-109 R7, lower layers (L4 workflow) cannot exercise upper-layer (L1 contract gate) authority.
*Resolution direction:* **don't ship auto_merge.yml in v0.6.15.** Defer to v0.6.16 alongside the canon round-trip helper that lets senesce auto-LAND status writes drive the merge (still mediated by canon decision, not directly by L4 workflow).

**T6 — risk classifier auto-merge recursion = perpetual motion** [mycoparasite T1, endophyte T6]
If a medium-risk auto-craft can modify risk_classifier.py itself OR `auto_evolve_*` canon keys, the substrate can quietly auto-flip its own gates. The 7-day window doesn't help if the craft is *itself* a classifier change.
*Resolution direction:* **recursion-cutter**: any craft whose path_allowlist touches `src/myco/core/risk_classifier.py`, `_canon.yaml::system.governance.auto_evolve_*`, or `.github/workflows/auto_*.yml` is **forced high-risk** regardless of content classification. Hard-coded in risk_classifier itself; cannot be bypassed without an explicit L0/L1 owner-gated craft.

**T7 — paranoia_mode + force_high_risk + pr_window_skip = 3 fields, 1 semantics** [saprotroph T3]
v0.6.14 introduced two fields; v0.6.15 was about to introduce a third (paranoia_mode) that's logically equivalent to (force_high_risk=true AND pr_window_skip=true). canon_schema.md rule 3 ("No duplication") forbids this.
*Resolution direction:* (already addressed by T3) drop paranoia_mode entirely. Keep the two existing fields; flip their defaults. No 3-way redundancy.

**T8 — critic_count 3 → 4 breaks v0.6.14 byte-identity contract** [saprotroph T2]
contract_changelog v0.6.14 + cycle.md + boundary.md all pin "3 fungal critics" + `auto_evolve_critic_count: 3` as v0.6.14 surface invariant. Changing to 4 within the same minor cadence (v0.6.x) without a clear version-bump signal would be drift.
*Resolution direction:* v0.6.15 IS the version bump. The change goes 3 → **5** (not 4), one critic per L0 principle. Update all references in changelog/doctrine/test in lockstep. The version bump (v0.6.14 → v0.6.15) is the appropriate signal for the surface change.

**T9 — endophyte own training-bias paradox** [endophyte T7, mycoparasite T2]
The 4th critic was added because 3 shared a bias. The 4th was conceived by the same agents under the same conditions. Adding more critics under the same conception process compounds correlated error.
*Resolution direction:* derive critic shape **from L0 P1-P5 directly**, not from observed-failure patches. v0.6.15 ships **5 critics**, one per principle: chytrid (P1) / rhizomorph (P2) / mycoparasite (P3) / saprotroph (P4) / mycorrhiza (P5). Each role-prompt cites its principle; agents can't conceive new roles without naming a principle.

**T10 — risk classifier needs craft path_allowlist as input, not body grep** [mycorrhiza T2]
Body string-matching ("20 verbs → 21") is brittle to wording. The reliable signal is craft frontmatter `path_allowlist:` (the explicit list of files the craft will touch).
*Resolution direction:* extend `winnow.py` G7 to require `path_allowlist:` in craft frontmatter for `type: craft` files in `docs/primordia/`. risk_classifier reads `path_allowlist` (not body) for content-based classification. Backfill existing v0.6.x crafts with path_allowlist (or grandfather them as v0.5.x and below were grandfathered for `authored_by:`).

#### P1 — Structural tensions (8 of 22). Repairable with explicit doctrine.

**T11 — Risk classifier extension as superset, not replacement** [saprotroph T5]
v0.6.0 risk_classifier already has high-risk keywords. v0.6.15 extension is **additive** (new keywords for canon_schema/verb-dim count change/schema_version change), preserving v0.6.0 list. Document explicitly.

**T12 — schema_version stays "2"** [saprotroph T7, mycorrhiza T6]
Adding canon fields under existing `governance` block doesn't change top-level shape; canon_schema.md rule "schema_version bumps when top-level shape changes" doesn't apply. v0.6.15 changes are sub-key value flips + risk_classifier code; no schema bump.

**T13 — chytrid + rhizomorph are real fungal-ecology terms** [saprotroph T9, naming review]
Chytridiomycota is the basal fungal phylum (most ancient, water-living, parasitic on simple organisms — pure fungal essence pre-symbiosis). Maps to L0 P1 "agent-first, no host dependency."
Rhizomorph is the cord-like aggregation of hyphae for active long-distance ingestion. Maps to L0 P2 "Eternal Ingestion."
Both terms satisfy L0:185-186 strictly.

**T14 — primordium.md mirror byte-identity** [mycorrhiza T5]
The 5-critic refactor changes primordium.md substantially. The plugin-bundle mirror at `<repo>/agents/primordium.md` must be kept byte-identical via cp; the regression test in `test_subagent_and_command_surface.py` enforces this.

**T15 — primordium body has 5 critic role-prompts; only primordium has Task** [mycorrhiza T5, T11]
The "only primordium" invariants from v0.6.14 (only primordium has Task in tools allowlist; only primordium body mentions "Autonomous mode") are preserved. The 5 critics are role-prompts WITHIN primordium body, not new subagent files. Subagent count stays at 5 (primordium / hypha / autolysis / stipe / anamorph). _EXPECTED_SUBAGENTS unchanged.

**T16 — Auto-merge to main path is genuinely L0 P5 + L0 P3 satisfying** [endophyte T8, T9]
Endophyte explicitly approves the auto-merge mechanic (when properly mediated by canon-LANDED status). v0.6.15 doesn't ship it for scope reasons (T5), but the principle is sound; v0.6.16 ships it cleanly.

**T17 — Tests must update v0.6.14 assertions** [mycorrhiza T1]
`test_autopoietic_loop_structural.py` lines 105-127 assert force_high_risk=True and auto_propose=False. v0.6.15 must update L113 to assert force_high_risk=False (NEW default) while keeping auto_propose=False (master switch unchanged). Add new tests for risk_classifier recursion-cutter.

**T18 — Senesce reaper canon round-trip stays deferred to v0.6.16+** [v0.6.14 acknowledged limitation]
v0.6.14 intentionally queued vetoed_intents to `.myco_state/auto_evolve_vetoed_pending.json` rather than writing canon directly. v0.6.15 doesn't change this; v0.6.16 (with auto_merge.yml) introduces the canon round-trip helper.

#### P2 — Edge cases, deferred to v0.6.16+ (4 of 22).

**T19 — vetoed_at semantics in auto-merge path** [saprotroph T8]
Defer to v0.6.16 (auto_merge.yml introduction).

**T20 — gh pr merge --auto operational gaps** [mycorrhiza T3]
Defer to v0.6.16. v0.6.15 doesn't have auto_merge.yml.

**T21 — auto-merge social engineering attack window** [mycoparasite T3]
Defer to v0.6.16. The cleanest mitigation (window only counts during owner heartbeat presence) is operational, not L0-doctrinal.

**T22 — observer-role responsibility decoupling** [mycoparasite T7]
Resolved by T2 (drop "observer" role redefinition). Owner stays "L0/L1/L2 craft-doc approver" per L0 — that's the L0-defined role; responsibility-power asymmetry doesn't arise because owner only acts on the explicit gate.

---

## Round 2 — 应答 (revision)

Each tension gets explicit response. P0s all resolved before scope; P1s have direction commitments; P2s deferred to v0.6.16.

| T | R |
|---|---|
| **T1** | vetoed_at restriction implemented via existing `governance.public_window_min_*` window — already window-bounded by v0.6.0 design; v0.6.14's `pr_window_skip: true` was the violation. Default flip to `false` automatically restores window-bounded vetoed_at. |
| **T2** | cycle.md and boundary.md text scrubbed of "owner = observer", "owner-merge-gate is the only synapse", "owner role becomes observer". Replace with: "L0/L1/L2-touching crafts require owner approval per L0 P1; medium-risk crafts auto-LAND per v0.6.0 governance tiering." |
| **T3** | `auto_evolve_owner_paranoia_mode` field NOT introduced. v0.6.15 ships only the two default flips. If future need arises, that's a separate L0-revision craft. |
| **T4** | Sub-agent fanout meta-lesson lives in v0.6.15 **contract_changelog entry only**. It is NOT added to cycle.md or boundary.md doctrine. Doctrine pages stay forward-looking specs, not retrospective narrative. |
| **T5** | auto_merge.yml DEFERRED to v0.6.16. v0.6.15 ships canon defaults flip + critic refactor + risk classifier extension; PR-merge step stays manual until v0.6.16 introduces canon-LANDED-driven auto-merge. |
| **T6** | risk_classifier.py gains a hardcoded recursion-cutter: any craft `path_allowlist` matching `src/myco/core/risk_classifier.py`, `_canon.yaml::governance.auto_evolve_*`, or `.github/workflows/auto_*.yml` → forced high-risk regardless of content. Tested by `test_risk_classifier_recursion_cutter.py`. |
| **T7** | (subsumed by T3) paranoia_mode dropped; the two existing fields stay with flipped defaults. No 3-way redundancy. |
| **T8** | critic_count 3 → **5** (not 4); v0.6.15 IS the version-bump signal that authorizes the change. All v0.6.14 references in changelog/doctrine/test updated in lockstep. |
| **T9** | 5 critics derived from L0 P1-P5 directly: **chytrid (P1)** / **rhizomorph (P2)** / mycoparasite (P3) / saprotroph (P4) / mycorrhiza (P5). Each role-prompt template MUST cite its L0 principle; the principle is the role-prompt's anchor, not a retrospective justification. New critic additions in future require naming an L0 principle (or revising L0). |
| **T10** | winnow.py G7 added: craft frontmatter must declare `path_allowlist: list[str]`. risk_classifier reads frontmatter, not body. Existing v0.6.x crafts (post-v0.6.14) get path_allowlist backfilled in v0.6.15; v0.5.x and earlier are grandfathered (the host-signature MP1 check is craft-only via `type: craft` filter; path_allowlist is craft-only too). |
| **T11** | risk_classifier extension is **explicit superset** of v0.6.0 keyword list. Documentation in changelog explicitly says "v0.6.0 high-risk set ∪ {new content-based triggers}". No breaking-change semantics. |
| **T12** | schema_version stays `"2"`. Confirmed via canon_schema.md rule. |
| **T13** | chytrid + rhizomorph are validated fungal-ecology terms. Documented in primordium.md role-prompt comment block + L0 mapping table. |
| **T14** | Mirror discipline: cp .claude/agents/primordium.md → agents/primordium.md after edit; byte-identity test passes. |
| **T15** | _EXPECTED_SUBAGENTS = 5 unchanged. Only primordium has Task. Only primordium body has "Autonomous mode" + 5 critic role-prompt blocks. Other 4 subagents unchanged. |
| **T16** | Auto-merge mechanism postponed to v0.6.16. The principle (canon-LANDED-status drives merge) is sound; the operational completion is its own scope. |
| **T17** | Test updates: `test_autopoietic_loop_structural.py` flips force_high_risk assertion from True → False; adds critic_count == 5 assertion; adds 5 role-prompt presence checks (chytrid/rhizomorph/mycoparasite/saprotroph/mycorrhiza). New file `tests/unit/core/test_risk_classifier_recursion_cutter.py` for the cutter. |
| **T18** | Senesce canon round-trip helper deferred to v0.6.16. v0.6.15's senesce path unchanged from v0.6.14. |
| **T19-T22** | Deferred to v0.6.16 (auto_merge.yml introduction); not in v0.6.15 scope. |

All 22 tensions resolved (10 P0 fixed in scope; 8 P1 directed; 4 P2 deferred).

---

## Round 3 — 决断 (decision)

**LANDED with 22 tensions resolved. Final scope: 13 implementation items.**

The 5-critic L0-P1-P5 mapping is the structural shift. v0.6.15's other changes (default flips, risk classifier extension, recursion-cutter) implement the L0 P1 restoration directly. No paranoia_mode, no observer role, no auto_merge.yml, no doctrine retrospective — all four were endophyte-detected drift toward owner-First.

The auto-merge step (operational completion of Agent-First) is the v0.6.16 scope. v0.6.15 ships the doctrine and structural correction; v0.6.16 ships the operational closure.

---

## 修订后 v0.6.15 完整 scope (13 items)

Grouped by dependency order so partial implementation doesn't leave the substrate in a half-state.

### A. Doctrine + canon (3 items)

1. **`L2_DOCTRINE/cycle.md`** — update existing § "Cycle 自起 fruit—winnow—molt 闭环 (v0.6.14+)" to:
   - Strike "owner-merge-gate is the only synapse" (L0 P1-violating wording).
   - Strike "Two-step owner sign for L0/L1/L2 + R-surface PRs" (replace with: "L0/L1/L2 + R-surface crafts are high-risk and require owner gate per v0.6.0 governance tiering — no special two-step sign needed").
   - Add "Agent-First default (v0.6.15+)" sub-section: defaults flipped; critic count 3→5 mapped to L0 P1-P5.
   - Do NOT add sub-agent fanout meta-lesson section (per T4 — that lives in changelog).

2. **`L2_DOCTRINE/boundary.md`** — update existing § "Sixth seam (v0.6.14+)":
   - Strike "v0.6.14 owner-merge-gate" wording.
   - Update "Three fungal critic roles" table to "Five fungal critic roles (v0.6.15+, derived from L0 P1-P5)".
   - Do not add new top-level section (cycle.md owns the doctrine; boundary.md updates its 5th-seam mention to track).

3. **`_canon.yaml::system.governance`** edits:
   - `auto_evolve_force_high_risk: true` → **`false`**
   - `auto_evolve_pr_window_skip: true` → **`false`**
   - `auto_evolve_critic_count: 3` → **`5`**
   - **NO** `auto_evolve_owner_paranoia_mode` field (per T3)
   - Comment block updated to cite v0.6.15 craft

### B. risk_classifier extension + recursion-cutter (2 items)

4. **`src/myco/core/risk_classifier.py`** extension:
   - Add `_HIGH_RISK_PROPOSAL_PATH_PATTERNS` tuple covering: `L0_VISION.md`, `L1_CONTRACT/`, `canon_schema.md`, `subsystems` (deletion), `boundary/surface/manifest.yaml` (verb count), `_canon_lint.yaml` (dim count), `schema_version`
   - Reads craft frontmatter `path_allowlist:` (NOT body grep)
   - Returns HIGH if any path matches any pattern
   - Returns MEDIUM otherwise (default)
   - Returns HIGH **regardless** if path_allowlist matches the recursion-cutter set: `src/myco/core/risk_classifier.py`, `_canon.yaml` (any `governance.auto_evolve_*` change), `.github/workflows/auto_revert.yml`, `.github/workflows/auto_merge.yml` (future), `.github/workflows/auto_*.yml` glob
   - Backward-compat: if `path_allowlist` field missing in craft frontmatter, fall back to v0.6.0 body-keyword classification + emit `MissingPathAllowlistWarning` finding (winnow G7 will refuse such crafts going forward)

5. **`src/myco/cycle/winnow.py`** G7:
   - For `type: craft` files in `docs/primordia/`, frontmatter must contain `path_allowlist: list[str]`
   - Empty list is permitted (signals "this craft makes no code changes" — pure doctrine craft)
   - Crafts in `docs/primordia/_excreted/` are exempt
   - Pre-v0.6.15 crafts (date < 2026-04-29) are grandfathered (no path_allowlist required)

### C. primordium.md 5-critic L0-P1-P5 refactor (2 items)

6. **`.claude/agents/primordium.md`** + `<repo>/agents/primordium.md` mirror — Autonomous mode section refactored:
   - Five fungal critic role-prompts, each tied to one L0 principle:

     | Role | L0 Principle | Visibility | Looks for |
     |------|-------------|------------|-----------|
     | **chytrid** (P1) | Only For Agent | L0_VISION.md only | does this pull humans into the substrate's loop? routine consumption? new owner role? |
     | **rhizomorph** (P2) | Eternal Ingestion | ingestion subsystem code + adapters + L0 P2 doctrine | does this restrict raw absorption? add intake-time filtering? violate "no out-of-scope rejection"? |
     | **mycoparasite** (P3) | Eternal Evolution | draft only (no doctrine, no src/) | break paths, prompt-injection, feedback loops, single-point-of-failure (existing role; now P3-anchored) |
     | **saprotroph** (P4) | Eternal Iteration | L0/L1/L2 doctrine + canon + previous crafts | doctrine drift, dead code, retrospective integration, vocabulary drift (existing role; now P4-anchored) |
     | **mycorrhiza** (P5) | Universal Interconnection | src/, tests/, .github/, .claude/, scripts/ | impl traction, integration, byte-identity tests, graph connectedness (existing role; now P5-anchored) |

   - Round 1.5 protocol: spawn all 5 in single Task message (parallel)
   - Veto semantics unchanged: any HIGH from any critic → primordium aborts to DRAFT
   - Naming change documented: endophyte → chytrid (better fungal taxonomy match for "primal/independent fungal-ness" → P1 mapping); rhizomorph added (P2)

7. Mirror sync: `cp .claude/agents/primordium.md agents/primordium.md`; byte-identity test enforces.

### D. Tests (3 items)

8. **`tests/contract/test_autopoietic_loop_structural.py`** updates:
   - `test_canon_auto_evolve_force_high_risk_default_true` → renamed `test_canon_auto_evolve_force_high_risk_default_false` and asserts **False** (v0.6.15 flip).
   - New test `test_canon_auto_evolve_pr_window_skip_default_false`.
   - `_REQUIRED_AUTO_EVOLVE_FIELDS["auto_evolve_critic_count"]` value check: assert == 5.
   - Add 5 new tests checking primordium.md body contains role-prompts for each of `chytrid`, `rhizomorph`, `mycoparasite`, `saprotroph`, `mycorrhiza`.
   - Remove `test_canon_auto_evolve_owner_paranoia_mode` if present (v0.6.15 doesn't introduce this field).
   - Update doctrine assertions: cycle.md must NOT contain "owner = observer" wording; must contain "Agent-First default (v0.6.15+)" section header.

9. **`tests/unit/core/test_risk_classifier_recursion_cutter.py`** (new):
   - Test 1: craft modifying `src/myco/core/risk_classifier.py` → forced HIGH regardless of other content
   - Test 2: craft modifying `_canon.yaml::governance.auto_evolve_*` keys → forced HIGH
   - Test 3: craft modifying `.github/workflows/auto_revert.yml` → forced HIGH
   - Test 4: craft with empty path_allowlist + benign body → MEDIUM (no recursion trigger)
   - Test 5: craft modifying `docs/architecture/L0_VISION.md` → HIGH (v0.6.0 path-keyword)
   - Test 6: craft missing path_allowlist frontmatter → emits MissingPathAllowlistWarning + falls back to body-keyword classification

10. **`tests/unit/boundary/test_subagent_and_command_surface.py`** updates:
    - critic_count expected: 5 (was 3 in v0.6.14, was 4 in transitional Round 1.5)
    - Add new tests checking primordium body has each of 5 role-prompts (chytrid/rhizomorph/mycoparasite/saprotroph/mycorrhiza)
    - `_EXPECTED_SUBAGENTS` tuple unchanged (still 5 subagent files; the critic count is INSIDE primordium body, not new subagent files)

### E. Changelog + ship (3 items)

11. **`docs/contract_changelog.md`** v0.6.15 entry — comprehensive section documenting:
    - The owner observation that triggered this craft
    - The 4-critic transitional Round 1.5 fanout (with 4 agentIds)
    - Endophyte's structural finding (T7) and the 5-critic L0-P1-P5 mapping outcome
    - All 13 scope items
    - The 4 things v0.6.15 explicitly does NOT introduce (paranoia_mode, observer role, auto_merge.yml, meta-teaching doctrine) — each tied to its endophyte-detected reason
    - **Sub-agent fanout meta-lesson** (per T4: this lives in CHANGELOG, not doctrine): the v0.6.14 fanout's structural blind spot, what the endophyte 4th critic caught, why v0.6.15 derives critics from L0 P1-P5 going forward
    - Pre-flight evidence

12. **`scripts/bump_version.py --to 0.6.15`** atomic bump (5 files + canon).

13. **stipe ship sequence**: feat commit + bump commit + push main + ci.yml watch + tag v0.6.15 + push tag + release.yml watch + 3-artifact verify (PyPI / MCP Registry / GitHub Release).

---

## L0 P1 strict-compliance machine evidence (Agent-First conformance accounting)

| Layer | LoC delta (estimated post-impl) | Nature |
|-------|----------------------------------|--------|
| **Substrate kernel** (src/myco/) | +~80 / -0 | risk_classifier.py extension (content patterns + recursion-cutter) + winnow.py G7 (path_allowlist enforcement). **Zero new LLM dispatch.** |
| **Agent layer** (.claude/) | +~200 / -~80 | primordium.md autonomous mode 3-critic → 5-critic refactor (rewrite role-prompts; mostly text). |
| **Canon** | +~6 lines updated | 3 default flips + 1 comment block update. |
| **Doctrine** (docs/architecture/) | +~30 / -~20 | cycle.md text strike + Agent-First default section; boundary.md sixth-seam table update. |
| **Tests** | +~150 | Updated assertions + new recursion-cutter test file. |

`grep -r 'owner.*observer\|paranoia\|auto_merge' src/myco/ docs/architecture/L2_DOCTRINE/ .claude/agents/ 2>/dev/null` post-v0.6.15 → expected zero hits.

The L0 P1 fix is ALSO measurable in Agent-layer LoC: the role-prompts now name L0 principles directly. Future critic additions must cite a principle (or revise L0).

---

## Risk class & governance path

**Risk class: HIGH.** Touches L0 P1 interpretation (the auto-evolve loop's default trust posture). owner-gate naturally — the owner IS reading this craft now, having explicitly invoked the issue. The Round 3 LANDED status reflects post-craft owner-author concurrence.

The v0.6.15 craft itself is NOT a candidate for the auto-loop (recursion-cutter). It is hand-authored + Round 1.5-fanout-validated + owner-reviewed + owner-merged. The substrate's first true Agent-First-mode auto-craft (per the "first dogfood" follow-up axis from v0.6.14) will happen in v0.6.16 or later.

---

## Future axis (deferred from v0.6.15)

- **`auto_merge.yml`** + senesce canon round-trip helper for `last_winnowed_proposals[].status` (v0.6.16). Operationalizes Agent-First by making the merge step also automated (gated by canon-LANDED status).
- **First true-dogfood `/myco-evolve` invocation** against an existing distilled note (e.g., neat-freak isomorphism distilled note). Defer until v0.6.16 lands auto_merge.yml.
- **Critic role-prompt review cycle**: every MAJOR release (v0.7.0, v0.8.0, ...) re-audits the 5 critics against current L0 wording. If L0 P1-P5 change, the critic role-prompts must change in lockstep.
- **Sub-agent fanout meta-tracking**: instrument primordium autonomous mode to record per-critic agreement rate over N runs. If 4 critics agree but 1 dissents (especially chytrid on L0 P1), that's the structural diversity working. If all 5 agree across many runs, that's a flag for "critic homogenization" — schedule a re-audit.

---

## Provenance

- Owner observation: 2026-04-29 (post v0.6.14 ship; same chat session).
- Round 1.5 fanout: 4 parallel `Task` tool calls (4 critics: mycoparasite + saprotroph + mycorrhiza + endophyte).
- Endophyte (4th critic) added explicitly to scan for L0 P1 inversion that v0.6.14 itself shipped.
- Endophyte's T7 ("derive critics from L0 P1-P5 directly") drove the v0.6.15 outcome: 5 L0-mapped critics (chytrid/rhizomorph/mycoparasite/saprotroph/mycorrhiza), one per principle.
- Round 2 revisions: hand-synthesized.
- Round 3 LANDED: hand-decided, owner present in chat session.
- Stage: `LANDED`. Implementation begins immediately following this craft (this same agent session).
- `path_allowlist` declared in frontmatter (see top of file) per winnow gate G7.
