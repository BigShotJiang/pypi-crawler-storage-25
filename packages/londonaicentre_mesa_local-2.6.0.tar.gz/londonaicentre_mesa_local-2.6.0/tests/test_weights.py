from dataclasses import dataclass
from unittest.mock import MagicMock, Mock, mock_open
from pathlib import Path

import pytest
from pytest import MonkeyPatch
from pytest_mock import MockerFixture
from httpx import HTTPStatusError, RequestError

from tests.weights import TestWeights
from mesalocal.aws import AWS
from mesalocal.settings import WeightsConfig


@dataclass
class DownloadMocks:
    s3_populated: Mock
    get_weights: Mock
    unpack: Mock
    cache_to_s3: Mock


@dataclass
class S3PopulatedMocks:
    list_s3_directory: Mock


@dataclass
class CacheToS3Mocks:
    s3_populated: Mock
    list_path_entries: Mock
    upload_s3_file: Mock
    logger: Mock


@dataclass
class UnpackMocks:
    get_weights: Mock
    unzip_weights: Mock


@dataclass
class GetPresignedGenerationUrlMocks:
    weights_config: Mock


@dataclass
class GetWeightsMocks:
    isfile: Mock
    httpx_get: Mock
    httpx_stream: MagicMock
    file_open: Mock
    makedirs: Mock
    tqdm: Mock
    logger: Mock


@dataclass
class GetWeightsFromUriMocks:
    isfile: Mock
    list_s3_directory: Mock
    download_s3_file: Mock
    logger: Mock


@dataclass
class UnzipWeightsMocks:
    one_file: Mock
    untar: Mock
    logger: Mock


@pytest.fixture
def download_mocks() -> DownloadMocks:
    s3_populated: Mock = Mock()
    get_weights: Mock = Mock()
    unpack: Mock = Mock()
    cache_to_s3: Mock = Mock()
    return DownloadMocks(
        s3_populated=s3_populated,
        get_weights=get_weights,
        unpack=unpack,
        cache_to_s3=cache_to_s3,
    )


@pytest.fixture
def s3_populated_mocks(mocker: MockerFixture) -> S3PopulatedMocks:
    list_s3_directory: Mock = Mock()
    mocker.patch.object(AWS, "list_s3_directory", list_s3_directory)
    return S3PopulatedMocks(list_s3_directory=list_s3_directory)


@pytest.fixture
def cache_to_s3_mocks(mocker: MockerFixture) -> CacheToS3Mocks:
    s3_populated: Mock = Mock()
    list_path_entries: Mock = Mock()
    mocker.patch.object(AWS, "list_path_entries", list_path_entries)
    upload_s3_file: Mock = Mock()
    mocker.patch.object(AWS, "upload_s3_file", upload_s3_file)
    logger: Mock = mocker.patch("logging.getLogger").return_value
    return CacheToS3Mocks(
        s3_populated=s3_populated,
        list_path_entries=list_path_entries,
        upload_s3_file=upload_s3_file,
        logger=logger,
    )


@pytest.fixture
def unpack_mocks() -> UnpackMocks:
    get_weights: Mock = Mock()
    unzip_weights: Mock = Mock()
    return UnpackMocks(get_weights=get_weights, unzip_weights=unzip_weights)


@pytest.fixture
def get_presigned_generation_url_mocks() -> GetPresignedGenerationUrlMocks:
    weights_config: Mock = Mock(spec=WeightsConfig)
    weights_config.id = "foo123"
    weights_config.region = "bar-baz-1"
    return GetPresignedGenerationUrlMocks(weights_config=weights_config)


@pytest.fixture
def get_weights_mocks(mocker: MockerFixture) -> GetWeightsMocks:
    isfile: Mock = mocker.patch("os.path.isfile", return_value=False)
    httpx_get: Mock = mocker.patch(
        "httpx.get", return_value=Mock(json=Mock(return_value={"url": "foobar"}))
    )
    chunks: list[bytes] = [b"foo", b"bar", b"baz"]
    httpx_stream: MagicMock = mocker.patch(
        "httpx.stream",
        return_value=MagicMock(
            raise_for_status=MagicMock(return_value=None),
            headers={"content-length": str(sum(len(chunk) for chunk in chunks))},
            iter_bytes=MagicMock(return_value=chunks),
        ),
    )
    file_open: Mock = mocker.patch("builtins.open", mock_open())
    makedirs: Mock = mocker.patch("os.makedirs")
    tqdm_mock: Mock = mocker.patch("tqdm.tqdm")
    logger: Mock = mocker.patch("logging.getLogger").return_value
    return GetWeightsMocks(
        isfile=isfile,
        httpx_get=httpx_get,
        httpx_stream=httpx_stream,
        file_open=file_open,
        makedirs=makedirs,
        tqdm=tqdm_mock,
        logger=logger,
    )


@pytest.fixture
def get_weights_from_uri_mocks(mocker: MockerFixture) -> GetWeightsFromUriMocks:
    isfile: Mock = mocker.patch("os.path.isfile", return_value=False)
    list_s3_directory: Mock = Mock()
    mocker.patch.object(AWS, "list_s3_directory", list_s3_directory)
    download_s3_file: Mock = Mock()
    mocker.patch.object(AWS, "download_s3_file", download_s3_file)
    logger: Mock = mocker.patch("logging.getLogger").return_value
    return GetWeightsFromUriMocks(
        isfile=isfile,
        list_s3_directory=list_s3_directory,
        download_s3_file=download_s3_file,
        logger=logger,
    )


@pytest.fixture
def unzip_weights_mocks(mocker: MockerFixture) -> UnzipWeightsMocks:
    one_file: Mock = mocker.patch("mesalocal.utils.Utils.one_file")
    untar: Mock = mocker.patch("mesalocal.utils.Utils.untar")
    logger: Mock = mocker.patch("logging.getLogger").return_value
    return UnzipWeightsMocks(one_file=one_file, untar=untar, logger=logger)


class TestDownload:
    def _patch_download_methods(
        self, mocker: MockerFixture, weights: TestWeights, download_mocks: DownloadMocks
    ) -> None:
        mocker.patch.object(weights, "_s3_populated", download_mocks.s3_populated)
        mocker.patch.object(weights, "_get_weights", download_mocks.get_weights)
        mocker.patch.object(weights, "_unpack", download_mocks.unpack)
        mocker.patch.object(weights, "_cache_to_s3", download_mocks.cache_to_s3)

    @pytest.fixture
    def weights(
        self, mocker: MockerFixture, download_mocks: DownloadMocks
    ) -> TestWeights:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.uri = "s3://foo-bucket/bar-prefix/"
        weights_config.region = "baz-region-1"
        weights: TestWeights = TestWeights(weights_config=weights_config)
        self._patch_download_methods(mocker, weights, download_mocks)
        return weights

    def test_download_uri_and_s3_populated_calls_get_weights_returns_true(
        self, download_mocks: DownloadMocks, weights: TestWeights
    ) -> None:
        download_mocks.s3_populated.return_value = True
        download_mocks.get_weights.return_value = True
        assert weights.download()
        download_mocks.get_weights.assert_called_once_with(
            uri="s3://foo-bucket/bar-prefix/", region="baz-region-1"
        )
        download_mocks.unpack.assert_not_called()
        download_mocks.cache_to_s3.assert_not_called()

    def test_download_uri_and_s3_populated_get_weights_fails_returns_false(
        self, download_mocks: DownloadMocks, weights: TestWeights
    ) -> None:
        download_mocks.s3_populated.return_value = True
        download_mocks.get_weights.return_value = False
        assert not weights.download()

    def test_download_no_uri_calls_unpack_and_cache_returns_true(
        self, mocker: MockerFixture, download_mocks: DownloadMocks
    ) -> None:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.uri = None
        weights: TestWeights = TestWeights(weights_config=weights_config)
        self._patch_download_methods(mocker, weights, download_mocks)
        download_mocks.unpack.return_value = True
        download_mocks.cache_to_s3.return_value = True
        assert weights.download()
        download_mocks.s3_populated.assert_not_called()
        download_mocks.get_weights.assert_not_called()
        download_mocks.unpack.assert_called_once()
        download_mocks.cache_to_s3.assert_called_once()

    def test_download_uri_but_s3_not_populated_calls_unpack_and_cache_returns_true(
        self, download_mocks: DownloadMocks, weights: TestWeights
    ) -> None:
        download_mocks.s3_populated.return_value = False
        download_mocks.unpack.return_value = True
        download_mocks.cache_to_s3.return_value = True
        assert weights.download()
        download_mocks.get_weights.assert_not_called()
        download_mocks.unpack.assert_called_once()
        download_mocks.cache_to_s3.assert_called_once()

    def test_download_unpack_fails_returns_false(
        self, download_mocks: DownloadMocks, weights: TestWeights
    ) -> None:
        download_mocks.s3_populated.return_value = False
        download_mocks.unpack.return_value = False
        download_mocks.cache_to_s3.return_value = True
        assert not weights.download()
        download_mocks.cache_to_s3.assert_not_called()

    def test_download_cache_to_s3_fails_returns_false(
        self, download_mocks: DownloadMocks, weights: TestWeights
    ) -> None:
        download_mocks.s3_populated.return_value = False
        download_mocks.unpack.return_value = True
        download_mocks.cache_to_s3.return_value = False
        assert not weights.download()


class TestS3Populated:
    @pytest.mark.parametrize(
        "uri,directory_files,expected",
        [
            (None, [], False),
            ("", [], False),
            ("s3://foo/bar/", [], False),
            ("s3://foo/bar/", ["file1.bin"], True),
            ("s3://foo/bar/", ["file1.bin", "file2.json"], True),
        ],
    )
    def test_s3_populated_various_conditions_returns_expected(
        self,
        s3_populated_mocks: S3PopulatedMocks,
        uri: str | None,
        directory_files: list[str],
        expected: bool,
    ) -> None:
        s3_populated_mocks.list_s3_directory.return_value = directory_files
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.uri = uri
        weights: TestWeights = TestWeights(weights_config=weights_config)
        assert weights.s3_populated() == expected


class TestCacheToS3:
    @pytest.fixture
    def s3_weights(
        self, mocker: MockerFixture, cache_to_s3_mocks: CacheToS3Mocks, tmp_path: Path
    ) -> TestWeights:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.uri = "s3://foo-bucket/bar-prefix/"
        weights_config.region = "baz-region-1"
        weights: TestWeights = TestWeights(weights_config=weights_config)
        mocker.patch.object(weights, "get_model_folder", return_value=str(tmp_path))
        mocker.patch.object(weights, "_s3_populated", cache_to_s3_mocks.s3_populated)
        return weights

    def test_cache_to_s3_no_uri_returns_true(
        self, mocker: MockerFixture, cache_to_s3_mocks: CacheToS3Mocks
    ) -> None:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.uri = None
        weights: TestWeights = TestWeights(weights_config=weights_config)
        mocker.patch.object(weights, "_s3_populated", cache_to_s3_mocks.s3_populated)
        assert weights.cache_to_s3()
        cache_to_s3_mocks.s3_populated.assert_not_called()
        cache_to_s3_mocks.list_path_entries.assert_not_called()
        cache_to_s3_mocks.upload_s3_file.assert_not_called()

    def test_cache_to_s3_s3_already_populated_returns_true(
        self, cache_to_s3_mocks: CacheToS3Mocks, s3_weights: TestWeights
    ) -> None:
        cache_to_s3_mocks.s3_populated.return_value = True
        assert s3_weights.cache_to_s3()
        cache_to_s3_mocks.list_path_entries.assert_not_called()
        cache_to_s3_mocks.upload_s3_file.assert_not_called()

    def test_cache_to_s3_uploads_all_files_returns_true(
        self, cache_to_s3_mocks: CacheToS3Mocks, s3_weights: TestWeights, tmp_path: Path
    ) -> None:
        cache_to_s3_mocks.s3_populated.return_value = False
        cache_to_s3_mocks.list_path_entries.return_value = [
            "model.bin",
            "config.json",
            "tokenizer.json",
        ]
        assert s3_weights.cache_to_s3()
        assert cache_to_s3_mocks.upload_s3_file.call_count == 3
        cache_to_s3_mocks.upload_s3_file.assert_any_call(
            "foo-bucket",
            "bar-prefix/model.bin",
            tmp_path / "model.bin",
            "baz-region-1",
        )
        cache_to_s3_mocks.upload_s3_file.assert_any_call(
            "foo-bucket",
            "bar-prefix/config.json",
            tmp_path / "config.json",
            "baz-region-1",
        )
        cache_to_s3_mocks.upload_s3_file.assert_any_call(
            "foo-bucket",
            "bar-prefix/tokenizer.json",
            tmp_path / "tokenizer.json",
            "baz-region-1",
        )

    def test_cache_to_s3_empty_local_directory_returns_true(
        self, cache_to_s3_mocks: CacheToS3Mocks, s3_weights: TestWeights
    ) -> None:
        cache_to_s3_mocks.s3_populated.return_value = False
        cache_to_s3_mocks.list_path_entries.return_value = []
        assert s3_weights.cache_to_s3()
        cache_to_s3_mocks.upload_s3_file.assert_not_called()


class TestUnpack:
    @pytest.fixture
    def weights(self, mocker: MockerFixture, unpack_mocks: UnpackMocks) -> TestWeights:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.key = "foo-api-key"
        weights: TestWeights = TestWeights(weights_config=weights_config)
        mocker.patch.object(weights, "_get_weights", unpack_mocks.get_weights)
        mocker.patch.object(weights, "_unzip_weights", unpack_mocks.unzip_weights)
        return weights

    def test_unpack_both_succeed_returns_true(
        self, unpack_mocks: UnpackMocks, weights: TestWeights
    ) -> None:
        unpack_mocks.get_weights.return_value = True
        unpack_mocks.unzip_weights.return_value = True
        assert weights.unpack()
        unpack_mocks.get_weights.assert_called_once_with("foo-api-key")
        unpack_mocks.unzip_weights.assert_called_once()

    def test_unpack_get_weights_fails_returns_false(
        self, unpack_mocks: UnpackMocks, weights: TestWeights
    ) -> None:
        unpack_mocks.get_weights.return_value = False
        assert not weights.unpack()
        unpack_mocks.get_weights.assert_called_once_with("foo-api-key")
        unpack_mocks.unzip_weights.assert_not_called()

    def test_unpack_unzip_weights_fails_returns_false(
        self, unpack_mocks: UnpackMocks, weights: TestWeights
    ) -> None:
        unpack_mocks.get_weights.return_value = True
        unpack_mocks.unzip_weights.return_value = False
        assert not weights.unpack()
        unpack_mocks.get_weights.assert_called_once_with("foo-api-key")
        unpack_mocks.unzip_weights.assert_called_once()


class TestGetWeightsPath:
    def test_get_weights_path_returns_correct_path(self) -> None:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.assets_folder = "/foo/bar"
        weights: TestWeights = TestWeights(
            model_name="baz123", weights_config=weights_config
        )
        assert weights.get_weights_path() == "/foo/bar/baz123/model.tar.gz"


class TestGetModelFolder:
    def test_get_model_folder_returns_parent_directory(
        self, mocker: MockerFixture
    ) -> None:
        weights: TestWeights = TestWeights(
            weights_config=WeightsConfig(uri="s3://foo/bar")
        )
        mocker.patch.object(
            weights, "get_weights_path", return_value="/foo/bar/baz/model.tar.gz"
        )
        assert weights.get_model_folder() == "/foo/bar/baz"


class TestGetPresignedGenerationUrl:
    def test_get_presigned_generation_url_model_with_underscore_returns_correct_url(
        self, get_presigned_generation_url_mocks: GetPresignedGenerationUrlMocks
    ) -> None:
        weights: TestWeights = TestWeights(
            model_name="foo_bar123",
            weights_config=get_presigned_generation_url_mocks.weights_config,
        )
        assert (
            weights.get_presigned_generation_url()
            == "https://foo123.execute-api.bar-baz-1.amazonaws.com/dist/foo/foo_bar123.tar.gz"
        )

    def test_get_presigned_generation_url_model_with_digit_returns_correct_url(
        self, get_presigned_generation_url_mocks: GetPresignedGenerationUrlMocks
    ) -> None:
        weights: TestWeights = TestWeights(
            model_name="foobar7baz",
            weights_config=get_presigned_generation_url_mocks.weights_config,
        )
        assert (
            weights.get_presigned_generation_url()
            == "https://foo123.execute-api.bar-baz-1.amazonaws.com/dist/foobar/foobar7baz.tar.gz"
        )

    def test_get_presigned_generation_url_model_without_underscore_or_digit_returns_correct_url(
        self, get_presigned_generation_url_mocks: GetPresignedGenerationUrlMocks
    ) -> None:
        weights: TestWeights = TestWeights(
            model_name="foobar",
            weights_config=get_presigned_generation_url_mocks.weights_config,
        )
        assert (
            weights.get_presigned_generation_url()
            == "https://foo123.execute-api.bar-baz-1.amazonaws.com/dist/foobar/foobar.tar.gz"
        )

    def test_get_presigned_generation_url_model_with_multiple_underscores_returns_correct_url(
        self, get_presigned_generation_url_mocks: GetPresignedGenerationUrlMocks
    ) -> None:
        weights: TestWeights = TestWeights(
            model_name="foo_bar_baz",
            weights_config=get_presigned_generation_url_mocks.weights_config,
        )
        assert (
            weights.get_presigned_generation_url()
            == "https://foo123.execute-api.bar-baz-1.amazonaws.com/dist/foo/foo_bar_baz.tar.gz"
        )

    def test_get_presigned_generation_url_model_starting_with_digit_returns_correct_url(
        self, get_presigned_generation_url_mocks: GetPresignedGenerationUrlMocks
    ) -> None:
        weights: TestWeights = TestWeights(
            model_name="7foobar",
            weights_config=get_presigned_generation_url_mocks.weights_config,
        )
        assert (
            weights.get_presigned_generation_url()
            == "https://foo123.execute-api.bar-baz-1.amazonaws.com/dist//7foobar.tar.gz"
        )


class TestGetWeights:
    @pytest.fixture
    def server(self, monkeypatch: MonkeyPatch, mocker: MockerFixture) -> TestWeights:
        monkeypatch.setenv("WEIGHTS_ID", "foo")
        monkeypatch.setenv("WEIGHTS_KEY", "bar")
        server: TestWeights = TestWeights(weights_config=WeightsConfig())
        mocker.patch.object(
            server, "get_weights_path", return_value="/foo/bar/model.tar.gz"
        )
        mocker.patch.object(server, "get_model_folder", return_value="/foo/bar")
        mocker.patch.object(
            server,
            "_get_presigned_generation_url",
            return_value="https://foo.execute-api.bar.amazonaws.com/dist/baz/qux.tar.gz",
        )
        return server

    def test_get_weights_file_not_exists_downloads_and_saves(
        self, get_weights_mocks: GetWeightsMocks, server: TestWeights
    ) -> None:
        server.get_weights("foo")
        get_weights_mocks.httpx_get.assert_any_call(
            "https://foo.execute-api.bar.amazonaws.com/dist/baz/qux.tar.gz",
            headers={"x-api-key": "foo"},
        )
        get_weights_mocks.httpx_stream.assert_any_call("GET", "foobar")
        get_weights_mocks.file_open.assert_called_once_with(
            "/foo/bar/model.tar.gz", "wb"
        )

    def test_get_weights_unauthorized_api_key_returns_false(
        self, get_weights_mocks: GetWeightsMocks, server: TestWeights
    ) -> None:
        get_weights_mocks.httpx_get.side_effect = HTTPStatusError(
            "401 Unauthorized", request=Mock(), response=Mock(status_code=401)
        )
        assert not server.get_weights("foo")

    def test_get_weights_network_error_returns_false(
        self, get_weights_mocks: GetWeightsMocks, server: TestWeights
    ) -> None:
        get_weights_mocks.httpx_get.side_effect = RequestError("Network failure")
        assert not server.get_weights("foo")

    def test_get_weights_file_exists_returns_true_without_download(
        self, get_weights_mocks: GetWeightsMocks, server: TestWeights
    ) -> None:
        get_weights_mocks.isfile.return_value = True
        assert server._get_weights("foo")
        get_weights_mocks.httpx_get.assert_not_called()


class TestGetWeightsFromUri:
    @pytest.fixture
    def uri_weights(self, mocker: MockerFixture, tmp_path: Path) -> TestWeights:
        weights_config: Mock = Mock(spec=WeightsConfig)
        weights_config.uri = "s3://foo-bucket/bar-prefix/"
        weights_config.region = "baz-region-1"
        weights_config.assets_folder = str(tmp_path)
        weights: TestWeights = TestWeights(weights_config=weights_config)
        mocker.patch.object(weights, "get_model_folder", return_value=str(tmp_path))
        mocker.patch.object(
            weights, "get_weights_path", return_value=str(tmp_path / "model.tar.gz")
        )
        return weights

    def test_get_weights_from_uri_downloads_files(
        self,
        get_weights_from_uri_mocks: GetWeightsFromUriMocks,
        uri_weights: TestWeights,
        tmp_path: Path,
    ) -> None:
        get_weights_from_uri_mocks.list_s3_directory.return_value = [
            "model.bin",
            "config.json",
            "tokenizer.json",
        ]
        uri_weights.get_weights(
            uri="s3://my-bucket/models/my-model/", region="eu-west-2"
        )
        assert get_weights_from_uri_mocks.download_s3_file.call_count == 3
        get_weights_from_uri_mocks.download_s3_file.assert_any_call(
            "my-bucket",
            "models/my-model/model.bin",
            tmp_path / "model.bin",
            "eu-west-2",
        )

    def test_get_weights_from_uri_skips_existing_files(
        self,
        get_weights_from_uri_mocks: GetWeightsFromUriMocks,
        uri_weights: TestWeights,
        tmp_path: Path,
    ) -> None:
        (tmp_path / "model.bin").touch()
        get_weights_from_uri_mocks.list_s3_directory.return_value = [
            "model.bin",
            "config.json",
        ]
        uri_weights.get_weights(
            uri="s3://my-bucket/models/my-model/", region="eu-west-2"
        )
        assert get_weights_from_uri_mocks.download_s3_file.call_count == 1
        get_weights_from_uri_mocks.download_s3_file.assert_called_once_with(
            "my-bucket",
            "models/my-model/config.json",
            tmp_path / "config.json",
            "eu-west-2",
        )

    def test_get_weights_from_uri_empty_directory_returns_true(
        self,
        get_weights_from_uri_mocks: GetWeightsFromUriMocks,
        uri_weights: TestWeights,
    ) -> None:
        get_weights_from_uri_mocks.list_s3_directory.return_value = []
        assert uri_weights.get_weights(
            uri="s3://my-bucket/models/my-model/", region="eu-west-2"
        )
        get_weights_from_uri_mocks.download_s3_file.assert_not_called()


class TestUnzipWeights:
    @pytest.fixture
    def weights(
        self, mocker: MockerFixture, unzip_weights_mocks: UnzipWeightsMocks
    ) -> TestWeights:
        weights: TestWeights = TestWeights(
            weights_config=WeightsConfig(uri="s3://foo/bar")
        )
        mocker.patch.object(
            weights, "get_weights_path", return_value="/foo/bar/model.tar.gz"
        )
        return weights

    def test_unzip_weights_not_one_file_returns_true(
        self, unzip_weights_mocks: UnzipWeightsMocks, weights: TestWeights
    ) -> None:
        unzip_weights_mocks.one_file.return_value = False
        assert weights.unzip_weights()
        unzip_weights_mocks.untar.assert_not_called()

    def test_unzip_weights_one_file_unpacks_successfully_returns_true(
        self, unzip_weights_mocks: UnzipWeightsMocks, weights: TestWeights
    ) -> None:
        unzip_weights_mocks.one_file.return_value = True
        assert weights.unzip_weights()
        unzip_weights_mocks.untar.assert_called_once_with("/foo/bar/model.tar.gz")

    def test_unzip_weights_untar_raises_exception_returns_false(
        self, unzip_weights_mocks: UnzipWeightsMocks, weights: TestWeights
    ) -> None:
        unzip_weights_mocks.one_file.return_value = True
        unzip_weights_mocks.untar.side_effect = Exception("Extraction failed")
        assert not weights.unzip_weights()
        unzip_weights_mocks.logger.error.assert_called_once()
