import logging
import os

from databricks import sql as databricks_sql
from pyspark.sql import SparkSession

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



def execute_run_databricks(query, retrieve_result=True, load_data=False):
    result = None
    query = query.strip()

    try:
        server_hostname = os.getenv("DATABRICKS_SERVER_HOSTNAME")
        http_path = os.getenv("DATABRICKS_HTTP_PATH")
        access_token = os.getenv("DATABRICKS_ACCESS_TOKEN")

        if server_hostname and http_path and access_token:
            logger.info("Connecting to Databricks via SQL Connector...")

            conn = databricks_sql.connect(
                server_hostname=server_hostname,
                http_path=http_path,
                access_token=access_token
            )

            cursor = conn.cursor()

            if retrieve_result:
                cursor.execute(query)
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                result = [tuple(columns)] + rows  # Insert column names as first row

            elif load_data:
                return conn  # You can use this externally for bulk inserts

            else:
                # Run multiple queries split by semicolon
                for single_query in query.split(";"):
                    if single_query.strip():
                        cursor.execute(single_query)

            cursor.close()
            conn.close()
            return result

        else:
            # Fallback: Run inside Databricks notebook using SparkSession
            logger.info("No env vars. Running query using SparkSession in Databricks notebook...")
            spark = SparkSession.getActiveSession()

            if retrieve_result:
                df = spark.sql(query)
                columns = df.columns
                rows = df.collect()
                result = [tuple(columns)] + [tuple(row) for row in rows]
                return result
            else:
                spark.sql(query)
                return None

    except Exception as e:
        logger.error("Error occurred while executing query on Databricks")
        logger.exception(e)
        raise