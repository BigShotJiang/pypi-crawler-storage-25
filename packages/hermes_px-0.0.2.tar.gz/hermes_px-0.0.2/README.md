# 🏛️ Hermes — Secure AI Inference Proxy

**Hermes** is a production-grade Python SDK that provides a **1:1 drop-in replacement** for the OpenAI Python library. Instead of calling OpenAI's servers directly, Hermes routes all inference traffic through configurable **5-layer Tor proxy chains**, ensuring complete anonymity while maintaining full API compatibility.

> Named after the Greek god of messengers, travelers, and thieves — Hermes carries your payloads through hidden paths between realms.

---

## 📦 Installation

```bash
pip install hermes-px
```

**System requirement:** A running Tor daemon (default: `127.0.0.1:9050`)

```bash
# Ubuntu/Debian
sudo apt install tor && sudo systemctl start tor

# macOS
brew install tor && brew services start tor
```

---

## ⚡ Quick Start

```python
from hermes import Hermes

# Create a client — routes through Tor automatically
client = Hermes()

# Use exactly like openai.OpenAI()
response = client.chat.completions.create(
    model="OLYMPUS-1",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Write a Python function for binary search."}
    ]
)

# Access response identically to OpenAI SDK
print(response.choices[0].message.content)
print(response.model)   # "OLYMPUS-1"
print(response.id)      # "chatcmpl-abc123..."
```

### Context Manager (Recommended)

```python
from hermes import Hermes

with Hermes() as client:
    response = client.chat.completions.create(
        model="OLYMPUS-1",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    print(response.choices[0].message.content)
# Session is automatically closed
```

---

## 🔧 Configuration

### Client Options

| Parameter | Type | Default | Description |
|---|---|---|---|
| `tor_proxy` | `str` | `socks5h://127.0.0.1:9050` | SOCKS5 proxy URL for Tor routing |
| `use_5_layer_chain` | `bool` | `True` | Enable multi-layer Tor routing |
| `prompt_file` | `str` | Built-in (compressed) | Path to custom base system prompt |

```python
client = Hermes(
    tor_proxy="socks5h://10.0.0.1:9150",
    use_5_layer_chain=True,
    prompt_file="/path/to/custom_prompt.txt"
)
```

### Environment Variables

| Variable | Description | Default |
|---|---|---|
| `HERMES_LOG_LEVEL` | Logging level (`DEBUG`, `INFO`, `WARNING`, `ERROR`) | `INFO` |
| `HERMES_LOG_FILE` | Log file path | `hermes.log` |
| `HERMES_LOG_CONSOLE` | Enable console logging (`1` or `0`) | `0` |
| `RAG_DATA_DIR` | Directory for RAG document watching | `./Data` |
| `RAG_DB_DIR` | ChromaDB persistence directory | `./chroma_db` |
| `RAG_CHUNK_SIZE` | Tokens per chunk | `512` |
| `RAG_CHUNK_OVERLAP` | Overlap tokens between chunks | `64` |
| `RAG_EMBEDDING_MODEL` | Sentence-transformers model name | `all-MiniLM-L6-v2` |

---

## 🏗️ Architecture

```mermaid
sequenceDiagram
    participant App as Your Application
    participant H as Hermes Client
    participant Tor as Tor Proxy Chain
    participant Target as Upstream Engine

    App->>H: client.chat.completions.create(messages=[...])
    H->>H: Inject system schema + base prompt
    H->>Tor: Route through SOCKS5 proxy
    Tor->>Target: Deliver with Chrome 146 fingerprint
    Target-->>Tor: Return inference result
    Tor-->>H: Tunnel response
    H->>H: Parse into ChatCompletion dataclass
    H-->>App: Return typed response object
```

### Module Structure

```
src/hermes/
├── __init__.py          # Public API exports
├── client.py            # Hermes client class
├── completions.py       # Completions engine
├── models.py            # Response dataclasses (Message, Choice, ChatCompletion)
├── constants.py         # Obfuscated endpoints & defaults
├── telemetry.py         # Async Supabase telemetry
├── exceptions.py        # Exception hierarchy
├── _logger.py           # Centralized logging
├── base_prompt.pz       # Compressed system prompt
└── rag/
    ├── __init__.py      # RAGPipeline class
    ├── config.py        # Env-based configuration
    ├── embeddings.py    # Local sentence-transformers engine
    ├── ingest.py        # Document extraction & chunking
    ├── vectorstore.py   # ChromaDB persistence
    └── watcher.py       # Filesystem watcher (watchdog)
```

---

## 🔒 Error Handling

Hermes provides a structured exception hierarchy:

```python
from hermes import (
    Hermes,
    HermesError,            # Base — catches everything
    HermesConnectionError,  # Tor/proxy failures
    HermesTimeoutError,     # Request timeouts
    HermesResponseError,    # Malformed upstream responses
    HermesConfigError,      # Bad configuration
    RAGError,               # RAG pipeline errors
)

try:
    response = client.chat.completions.create(messages=[...])
except HermesConnectionError:
    print("Tor proxy is down — check your daemon.")
except HermesTimeoutError:
    print("Request took too long — try increasing timeout.")
except HermesResponseError:
    print("Upstream returned unexpected data.")
except HermesError:
    print("Something else went wrong.")
```

---

## 📚 RAG Pipeline

Hermes includes a built-in RAG (Retrieval-Augmented Generation) system with **fully local** embeddings — no API keys needed.

```python
from hermes.rag import pipeline

# Start watching a directory for documents
pipeline.start()

# Query the vector store
results = pipeline.query("What is binary search?", n_results=5)
print(results["documents"])

# Check status
print(f"Running: {pipeline.is_running}")
print(f"Documents: {pipeline.document_count} chunks")

# Stop the watcher
pipeline.stop()
```

**Supported file types:** PDF, TXT, MD, DOCX, JSON, JSONL, CSV, PNG, JPG, GIF (via OCR)

---

## 🖥️ CLI

Hermes ships with an interactive CLI:

```bash
python demo/hermes_cli.py
python demo/hermes_cli.py --model OLYMPUS-1 --system "You are a Python expert."
python demo/hermes_cli.py --proxy socks5h://127.0.0.1:9150
```

CLI commands: `/help`, `/clear`, `/save`, `/set`, `/show`, `/ping`, `/exit`

---

## 🧪 Testing

```bash
# Run unit tests
python -m pytest tests/ -v --ignore=tests/test_integration.py

# Run integration tests (requires live Tor)
HERMES_RUN_INTEGRATION=1 python -m pytest tests/test_integration.py -v -s
```

---

## 🔄 Migrating from OpenAI SDK

```diff
- from openai import OpenAI
+ from hermes import Hermes

- client = OpenAI(api_key="sk-...")
+ client = Hermes()

  response = client.chat.completions.create(
-     model="gpt-4",
+     model="OLYMPUS-1",
      messages=[{"role": "user", "content": "Hello!"}]
  )
  print(response.choices[0].message.content)  # Identical access pattern
```

---

*Hermes — Messenger of the gods, guide through hidden paths.* 🪽
