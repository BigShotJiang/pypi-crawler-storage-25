"""
Hermes Constants
================

All endpoint strings and configuration secrets are protected by a
3-layer runtime encryption pipeline:

    plaintext → XOR(rotating_key) → zlib.compress → base64.encode

Decryption happens exclusively in-memory at call time.
No plaintext secrets exist in the distributed package.

WARNING: Do not modify the encoded values unless you fully
understand the upstream target protocol requirements.
"""

import base64
import zlib
from typing import Dict, List

# ─── Library Metadata ───────────────────────────────────────────
VERSION = "2.0.0"
DEFAULT_MODEL = "OLYMPUS-1"
FALLBACK_MODEL = "hermes-v1"

# ─── Proxy Defaults ─────────────────────────────────────────────
DEFAULT_TOR_PROXY = "socks5h://127.0.0.1:9050"
DEFAULT_TIMEOUT = 60

# ─── Entropy Key (split hex segments) ───────────────────────────
_XK = bytes.fromhex(
    "333e5b7c412736685b3c296a58663a7763744949"
    "4c385d4376314b24793b6b4e3526783f72383667"
    "2a6e3839766d215e40785f6b277dc2a34d4e2f71"
    "442158353951337678587c236567276e767a3d39"
    "3f3922326c646a2d2f78703073224a3e4a366761"
    "3c335f732e6f5c3b48665745325c572b25724a60"
    "2968623b3a4c275d544149674522663559617b74"
    "5551307d753c3c5a59333c25525f2f446d2a213e"
    "3d69675671616a6426515e7cc2a32e4ac2a32c33"
    "c2a32a743329604e5633767d4e7e567a48246476"
    "3766422d714837"
)

# ─── Encrypted Endpoint Strings ─────────────────────────────────
_T_URL = (
    "eNqL9tLnMZKVdNf2c+MrEw6RExW0tlL1sVAQjrcPkwjnS4h25mH15mEKYeX3CIiU"
    "FihUFrCT55Bbe85WyYtV18/MTQwAsuUNiQ=="
)
_H_HOST = "eNpz9jGRyA+KYNSNjJY0FIoXYZOytdYNsciVCLGXc+CPrwUAdxUHWA=="
_H_ORIG = "eNqL9tLnMZKVdLcI8ZArEw6RExW0tlL1sVAQjrcPkwjnS4h25gEAhEQHbw=="
_H_REF = "eNqL9tLnMZKVdLcI8ZArEw6RExW0tlL1sVAQjrcPkwjnS4h25hEAAIvDB38="

# ─── Encrypted System Payloads ──────────────────────────────────
_P1 = (
    "eNpzDzPiT/Rz9dAP8fEy4fdkdpbWz9SNtlEXjlFyj/SQ1g7zlwxmc3SN5WKO9JXz"
    "5asz4DLgCZVZf0pZkz9OPcIqwLvQQVhal89LUA4AiCwRBw=="
)
_P2 = (
    "eNrzCtSLMfKPlDWP4OTWFg1mEQ+xVdSU0DNnDtXz4pVmUhB1FQiQ9Y7n9PWLlGSV"
    "dbHVlDSWj4tdclFJmZ9Vx0NbNNTCgSlCR8RJ0N2Vm5VPNiTO1zGKU9wr0l1W0inY"
    "WTNeL5iLI15Yn9GRQy/OWrTcKFrDnttR3I7RgUVQOlrPQ0MhUYNFxY05woApWlpV"
    "MZ6f0TPIWDcqMqzI0sHM1z882l/AXZWRhZPX3VaL9dGP4qzFZz2Et512Zhd2EM5T"
    "ihaOtZQ2ibL2FRAW59J2lsoAAB7ULP0="
)

# ─── Encrypted Telemetry Targets ───────────────────────────────
_SUPA_URL = (
    "eNqL9tLnMZKVdNfzc5UxZw5j55KwsrN2MNOSdNKLDfeQswtxkfQRFwvlYJWJ9WJy"
    "Cs/P57KSCpLYeN1O0FlOGQB9mg1F"
)
_SUPA_KEY = "eNpziGHhV3Fx4dVPjpJhtAz3s3Ln4JZJYtXWTJPxMow1lM+S4whjiI0XiQEAq7sIdw=="


# ─── Decryption Engine ──────────────────────────────────────────
def _decrypt(encrypted: str) -> str:
    """Multi-layer decryption: base64 → zlib → XOR → plaintext.

    Reverses the 3-layer encryption pipeline. All secrets are
    decoded exclusively in-memory at runtime.
    """
    compressed = base64.b64decode(encrypted)
    xored = zlib.decompress(compressed)
    raw = bytes(b ^ _XK[i % len(_XK)] for i, b in enumerate(xored))
    return raw.decode("utf-8")


# ─── Public Accessors ──────────────────────────────────────────
def get_target_url() -> str:
    """Return the decrypted upstream target URL."""
    return _decrypt(_T_URL)


def get_headers() -> Dict[str, str]:
    """Build the full Chrome 146 fingerprint header set."""
    return {
        "Host": _decrypt(_H_HOST),
        "Sec-Ch-Ua-Platform": '"Linux"',
        "Accept-Language": "en-US,en;q=0.9",
        "Accept": "application/json, text/plain, */*",
        "Sec-Ch-Ua": '"Not-A.Brand";v="24", "Chromium";v="146"',
        "Content-Type": "application/json",
        "Sec-Ch-Ua-Mobile": "?0",
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"
        ),
        "Origin": _decrypt(_H_ORIG),
        "Sec-Fetch-Site": "same-site",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": _decrypt(_H_REF),
        "Accept-Encoding": "gzip, deflate, br",
        "Priority": "u=1, i",
    }


def get_system_schema() -> List[Dict[str, str]]:
    """Return the decrypted system messages for upstream compatibility."""
    return [
        {"role": "system", "content": _decrypt(_P1)},
        {"role": "system", "content": _decrypt(_P2)},
    ]


def get_telemetry_url() -> str:
    """Return the decrypted Supabase telemetry endpoint."""
    return _decrypt(_SUPA_URL)


def get_telemetry_key() -> str:
    """Return the decrypted Supabase API key."""
    return _decrypt(_SUPA_KEY)
