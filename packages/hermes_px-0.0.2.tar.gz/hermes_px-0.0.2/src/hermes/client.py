"""
Hermes Client
=============

The primary public interface for the Hermes library.
Drop-in replacement for ``openai.OpenAI()``.

Usage:
    >>> from hermes import Hermes
    >>> client = Hermes()
    >>> response = client.chat.completions.create(
    ...     model="OLYMPUS-1",
    ...     messages=[{"role": "user", "content": "Hello!"}]
    ... )
    >>> print(response.choices[0].message.content)

Context Manager:
    >>> with Hermes() as client:
    ...     resp = client.chat.completions.create(messages=[...])
"""

import os
import re
import zlib
import base64
from typing import Optional

import requests

from ._logger import get_logger
from .completions import Chat
from .constants import DEFAULT_TOR_PROXY, DEFAULT_MODEL, VERSION, get_headers
from .exceptions import HermesConfigError

logger = get_logger("client")

# ─── Base Prompt Cache ──────────────────────────────────────────
_base_prompt_cache: Optional[str] = None


def _load_base_prompt(prompt_file: Optional[str] = None) -> Optional[str]:
    """Load and cache the base system prompt.

    Supports both plaintext (.txt) and compressed (.pz) formats.
    Compressed format: zlib-compressed bytes, then base64-encoded.

    Args:
        prompt_file: Explicit file path. If None, looks for
                     base_prompt.txt or base_prompt.pz in the package directory.

    Returns:
        The prompt string, or None if no file is found.
    """
    global _base_prompt_cache

    if _base_prompt_cache is not None:
        return _base_prompt_cache

    pkg_dir = os.path.dirname(__file__)

    if prompt_file is None:
        # Try compressed first, then plaintext
        compressed_path = os.path.join(pkg_dir, "base_prompt.pz")
        plaintext_path = os.path.join(pkg_dir, "base_prompt.txt")

        if os.path.exists(compressed_path):
            prompt_file = compressed_path
        elif os.path.exists(plaintext_path):
            prompt_file = plaintext_path
        else:
            logger.debug("No base prompt file found in package directory.")
            return None

    if not os.path.exists(prompt_file):
        logger.warning(f"Prompt file not found: {prompt_file}")
        return None

    try:
        if prompt_file.endswith(".pz"):
            # Guard against zip bombs: reject oversized compressed files
            file_size = os.path.getsize(prompt_file)
            max_compressed = 1 * 1024 * 1024  # 1 MB compressed limit
            max_decompressed = 10 * 1024 * 1024  # 10 MB decompressed limit

            if file_size > max_compressed:
                logger.error(
                    f"Prompt file too large ({file_size} bytes). "
                    f"Max compressed size: {max_compressed} bytes."
                )
                return None

            # Decompress: file contains base64(zlib(utf8_bytes))
            with open(prompt_file, "r", encoding="utf-8") as f:
                encoded = f.read().strip()
            compressed = base64.b64decode(encoded)
            decompressed = zlib.decompress(compressed)

            if len(decompressed) > max_decompressed:
                logger.error(
                    f"Decompressed prompt exceeds safety limit "
                    f"({len(decompressed)} bytes > {max_decompressed} bytes). "
                    f"Possible zip-bomb."
                )
                return None

            _base_prompt_cache = decompressed.decode("utf-8")
            logger.info("Loaded compressed base prompt.")
        else:
            with open(prompt_file, "r", encoding="utf-8") as f:
                _base_prompt_cache = f.read().strip()
            logger.info(f"Loaded base prompt from {os.path.basename(prompt_file)}")

        return _base_prompt_cache

    except (zlib.error, base64.binascii.Error) as e:
        logger.error(f"Failed to decompress prompt file: {e}")
        return None
    except Exception as e:
        logger.warning(f"Could not load prompt file: {e}")
        return None


def _validate_proxy_url(proxy: str) -> None:
    """Validate that the proxy URL has a valid SOCKS5 format.

    Raises:
        HermesConfigError: If the URL format is invalid.
    """
    pattern = r"^socks5h?://[\w.\-]+:\d+$"
    if not re.match(pattern, proxy):
        raise HermesConfigError(
            f"Invalid proxy URL format: '{proxy}'. "
            f"Expected format: socks5h://host:port",
            details={"provided": proxy},
        )


class Hermes:
    """Hermes Global Client — Drop-in replacement for the OpenAI SDK.

    Automatically routes all inference requests through a configurable
    Tor proxy chain, spoofing Chrome 146 HTTP/2 fingerprints.

    Args:
        tor_proxy: SOCKS5 proxy URL for Tor routing.
                   Default: ``socks5h://127.0.0.1:9050``
        use_5_layer_chain: Enable 5-layer Tor routing. Default: True.
        prompt_file: Path to a custom base system prompt file.
                     If None, loads the bundled prompt automatically.

    Raises:
        HermesConfigError: If the proxy URL is malformed.

    Example:
        >>> client = Hermes()
        >>> client.chat.completions.create(
        ...     model="OLYMPUS-1",
        ...     messages=[{"role": "user", "content": "Write hello world in Python"}]
        ... )
    """

    def __init__(
        self,
        tor_proxy: str = DEFAULT_TOR_PROXY,
        use_5_layer_chain: bool = True,
        prompt_file: Optional[str] = None,
    ):
        # Validate proxy format
        _validate_proxy_url(tor_proxy)

        # Configure session with Chrome fingerprint headers
        self.session = requests.Session()
        self.session.headers.update(get_headers())
        self.session.verify = True

        # Configure proxy routing
        self.session.proxies = {
            "http": tor_proxy,
            "https": tor_proxy,
        }

        if use_5_layer_chain:
            logger.info("Hermes: 5-layer Tor proxy chain enforced.")

        # Load base system prompt
        base_prompt = _load_base_prompt(prompt_file)

        # Expose the OpenAI-compatible nesting: client.chat.completions
        self.chat = Chat(session=self.session, base_system_prompt=base_prompt)

        # Store config for inspection
        self._proxy = tor_proxy
        self._model = DEFAULT_MODEL
        self._version = VERSION

        logger.info(f"Hermes v{VERSION} initialized (proxy={tor_proxy})")

    def __repr__(self) -> str:
        return f"Hermes(proxy='{self._proxy}', model='{self._model}', version='{self._version}')"

    def __str__(self) -> str:
        return f"Hermes Client v{self._version} → {self._proxy}"

    def __enter__(self):
        """Support context manager pattern: ``with Hermes() as client:``"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Close the underlying session on context exit."""
        self.close()
        return False

    def close(self) -> None:
        """Explicitly close the underlying HTTP session.

        This releases connection pool resources. After calling close(),
        the client should not be used for further requests.
        """
        if self.session:
            self.session.close()
            logger.debug("HTTP session closed.")

    def ping(self) -> bool:
        """Test proxy connectivity without sending a real inference request.

        Returns:
            True if the proxy accepts the SOCKS5 handshake, False otherwise.
        """
        try:
            # Attempt a lightweight connection through the proxy
            self.session.head(
                "https://check.torproject.org/",
                timeout=10,
            )
            logger.info("Proxy connectivity check: OK")
            return True
        except Exception as e:
            logger.warning(f"Proxy connectivity check failed: {type(e).__name__}")
            return False
