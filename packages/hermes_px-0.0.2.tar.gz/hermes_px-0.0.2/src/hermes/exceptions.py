"""
Hermes Exception Hierarchy
==========================

Structured exception classes for granular error handling across
the Hermes client, telemetry, and RAG subsystems.

All exceptions inherit from HermesError, enabling callers to catch
broad (HermesError) or narrow (HermesTimeoutError) as needed.
"""


class HermesError(Exception):
    """Base exception for all Hermes library errors.

    Attributes:
        message: Human-readable error description.
        details: Optional dict of contextual metadata (never includes
                 sensitive data like URLs or headers).
    """

    def __init__(self, message: str, details: dict = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)

    def __str__(self) -> str:
        if self.details:
            detail_str = ", ".join(f"{k}={v}" for k, v in self.details.items())
            return f"{self.message} [{detail_str}]"
        return self.message


class HermesConnectionError(HermesError):
    """Raised when the Tor proxy or upstream target is unreachable.

    Common causes:
        - Tor daemon not running on the configured port
        - SOCKS5 handshake failure
        - Network partition between proxy layers
    """
    pass


class HermesTimeoutError(HermesError):
    """Raised when a request exceeds the configured timeout threshold.

    Attributes:
        timeout_seconds: The timeout value that was exceeded.
    """

    def __init__(self, message: str, timeout_seconds: float = None, **kwargs):
        self.timeout_seconds = timeout_seconds
        details = kwargs.get("details", {})
        if timeout_seconds is not None:
            details["timeout_seconds"] = timeout_seconds
        super().__init__(message, details=details)


class HermesResponseError(HermesError):
    """Raised when the upstream returns a malformed or unexpected response.

    Common causes:
        - WAF interception returning HTML instead of JSON
        - Upstream service returning error payloads
        - Missing 'choices' key in response body
    """

    def __init__(self, message: str, status_code: int = None, **kwargs):
        self.status_code = status_code
        details = kwargs.get("details", {})
        if status_code is not None:
            details["status_code"] = status_code
        super().__init__(message, details=details)


class HermesConfigError(HermesError):
    """Raised when Hermes is initialized with invalid configuration.

    Common causes:
        - Malformed proxy URL
        - Missing required prompt file
        - Invalid environment variable values
    """
    pass


class RAGError(HermesError):
    """Raised when the RAG pipeline encounters an error.

    Common causes:
        - Embedding model not available
        - ChromaDB persistence failure
        - File extraction errors during ingestion
    """
    pass
