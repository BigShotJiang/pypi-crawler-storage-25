"""
Hermes Data Models
==================

Typed dataclasses that mirror the OpenAI SDK response structure.
These provide attribute-style access (response.choices[0].message.content)
identical to the official openai library, ensuring drop-in compatibility.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass(frozen=True)
class Message:
    """A single message in a chat completion response.

    Attributes:
        content: The text content of the message.
        role: The role of the message author (always 'assistant' for responses).
    """
    content: str
    role: str = "assistant"

    def to_dict(self) -> dict:
        """Serialize to a dictionary matching OpenAI format."""
        return {"role": self.role, "content": self.content}


@dataclass(frozen=True)
class Usage:
    """Token usage statistics for a completion.

    Attributes:
        prompt_tokens: Number of tokens in the prompt.
        completion_tokens: Number of tokens in the completion.
        total_tokens: Sum of prompt and completion tokens.
    """
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    def to_dict(self) -> dict:
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
        }


@dataclass(frozen=True)
class Choice:
    """A single completion choice from the model.

    Attributes:
        message: The message content of this choice.
        index: Position index of this choice in the response array.
        finish_reason: Why the model stopped generating ('stop', 'length', etc.).
    """
    message: Message
    index: int = 0
    finish_reason: str = "stop"

    def to_dict(self) -> dict:
        return {
            "message": self.message.to_dict(),
            "index": self.index,
            "finish_reason": self.finish_reason,
        }


@dataclass(frozen=True)
class ChatCompletion:
    """Complete chat completion response matching the OpenAI schema.

    This is the primary return type from `client.chat.completions.create()`.

    Attributes:
        id: Unique identifier for the completion (e.g., 'chatcmpl-abc123').
        choices: List of completion choices (typically 1).
        model: The model identifier used for the completion.
        object: Object type, always 'chat.completion'.
        usage: Optional token usage statistics.

    Example:
        >>> response = client.chat.completions.create(messages=[...])
        >>> print(response.choices[0].message.content)
        'Hello! How can I help you?'
        >>> print(response.model)
        'OLYMPUS-1'
    """
    id: str
    choices: List[Choice]
    model: str
    object: str = "chat.completion"
    usage: Optional[Usage] = None

    def to_dict(self) -> dict:
        """Serialize to a dictionary matching OpenAI response format."""
        result = {
            "id": self.id,
            "object": self.object,
            "model": self.model,
            "choices": [c.to_dict() for c in self.choices],
        }
        if self.usage:
            result["usage"] = self.usage.to_dict()
        return result
