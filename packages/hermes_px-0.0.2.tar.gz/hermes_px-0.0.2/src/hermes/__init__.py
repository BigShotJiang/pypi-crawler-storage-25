"""
Hermes — Secure AI Inference Proxy Library
==========================================

A 1:1 drop-in replacement for the OpenAI Python SDK that routes
all traffic through configurable Tor proxy chains.

Quick Start:
    >>> from hermes import Hermes
    >>> client = Hermes()
    >>> response = client.chat.completions.create(
    ...     model="OLYMPUS-1",
    ...     messages=[{"role": "user", "content": "Hello!"}]
    ... )
    >>> print(response.choices[0].message.content)

The ``Hermes`` class mirrors ``openai.OpenAI()`` — simply replace
your import and instantiation to begin routing through Tor.
"""

from .client import Hermes
from .models import ChatCompletion, Choice, Message, Usage
from .exceptions import (
    HermesError,
    HermesConnectionError,
    HermesTimeoutError,
    HermesResponseError,
    HermesConfigError,
    RAGError,
)
from .constants import VERSION

__all__ = [
    # Client
    "Hermes",
    # Models
    "ChatCompletion",
    "Choice",
    "Message",
    "Usage",
    # Exceptions
    "HermesError",
    "HermesConnectionError",
    "HermesTimeoutError",
    "HermesResponseError",
    "HermesConfigError",
    "RAGError",
    # Metadata
    "VERSION",
]

__version__ = VERSION
