"""
Hermes RAG — File Watcher
=========================

Uses watchdog to monitor the DATA_DIR for file changes.
Implements debounced ingestion to handle rapid-fire save events
without triggering duplicate processing.
"""

import os
import threading
from typing import Dict

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from .._logger import get_logger
from .config import DATA_DIR
from .ingest import process_file
from .vectorstore import vector_store

logger = get_logger("rag.watcher")

SUPPORTED_EXTENSIONS = {
    ".pdf", ".txt", ".md", ".docx", ".json",
    ".jsonl", ".csv", ".png", ".jpg", ".jpeg", ".gif",
}

# Debounce delay in seconds
_DEBOUNCE_DELAY = 1.0


class RAGFileHandler(FileSystemEventHandler):
    """Handles filesystem events with debounced ingestion.

    When a file is created or modified, a timer is set to delay
    processing by 1 second. If another event fires for the same
    file within that window, the timer resets. This prevents
    duplicate processing from editors that write multiple times.
    """

    def __init__(self):
        super().__init__()
        self._debounces: Dict[str, threading.Timer] = {}
        self._lock = threading.Lock()

    def _is_valid_file(self, path: str) -> bool:
        """Check if a file should be processed based on extension and name."""
        if os.path.isdir(path):
            return False

        filename = os.path.basename(path)
        if filename.startswith("."):
            return False

        ext = os.path.splitext(filename)[1].lower()
        return ext in SUPPORTED_EXTENSIONS

    def _execute_ingest(self, file_path: str) -> None:
        """Perform ingestion and clear the debounce tracker."""
        try:
            document_id = os.path.basename(file_path)
            # Remove existing chunks first (handles modifications)
            vector_store.delete_by_document_id(document_id)
            process_file(file_path)
        except Exception as e:
            logger.error(f"Ingestion error for {file_path}: {e}")
        finally:
            with self._lock:
                self._debounces.pop(file_path, None)

    def _debounce_ingest(self, file_path: str) -> None:
        """Schedule a delayed ingestion, cancelling any pending timer."""
        if not self._is_valid_file(file_path):
            return

        with self._lock:
            # Cancel active timer if rapid save
            existing = self._debounces.get(file_path)
            if existing is not None:
                existing.cancel()

            timer = threading.Timer(
                _DEBOUNCE_DELAY,
                self._execute_ingest,
                args=[file_path],
            )
            timer.daemon = True
            self._debounces[file_path] = timer
            timer.start()

    def on_created(self, event):
        if not event.is_directory:
            logger.info(f"Created: {event.src_path}")
            self._debounce_ingest(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            logger.info(f"Modified: {event.src_path}")
            self._debounce_ingest(event.src_path)

    def on_moved(self, event):
        if not event.is_directory:
            old_doc_id = os.path.basename(event.src_path)

            with self._lock:
                existing = self._debounces.pop(event.src_path, None)
                if existing is not None:
                    existing.cancel()

            logger.info(f"Moved: {old_doc_id} → {os.path.basename(event.dest_path)}")
            vector_store.delete_by_document_id(old_doc_id)
            self._debounce_ingest(event.dest_path)

    def on_deleted(self, event):
        if not event.is_directory:
            file_path = event.src_path
            document_id = os.path.basename(file_path)

            with self._lock:
                existing = self._debounces.pop(file_path, None)
                if existing is not None:
                    existing.cancel()

            logger.info(f"Deleted: {document_id}")
            vector_store.delete_by_document_id(document_id)


def start_watcher() -> Observer:
    """Start the watchdog observer on DATA_DIR.

    Returns:
        The running Observer instance (call .stop() to shut down).
    """
    logger.info(f"Starting file watcher on {DATA_DIR}...")
    event_handler = RAGFileHandler()
    observer = Observer()
    observer.schedule(event_handler, DATA_DIR, recursive=True)
    observer.daemon = True
    observer.start()
    return observer
