"""
Hermes RAG Pipeline
===================

Public interface for the Retrieval-Augmented Generation subsystem.

Usage:
    >>> from hermes.rag import pipeline
    >>> pipeline.start()       # Begin watching DATA_DIR for documents
    >>> results = pipeline.query("What is binary search?")
    >>> pipeline.stop()
"""

from .._logger import get_logger
from .watcher import start_watcher
from .vectorstore import vector_store
from .embeddings import embed_query

logger = get_logger("rag")


class RAGPipeline:
    """Manages the RAG lifecycle: watcher, ingestion, and querying.

    Attributes:
        observer: The watchdog Observer instance (None when stopped).
        vector_store: The underlying ChromaDB vector store.
    """

    def __init__(self):
        self.observer = None
        self.vector_store = vector_store

    def start(self) -> None:
        """Start the background file watcher daemon.

        Monitors DATA_DIR for new, modified, or deleted files
        and automatically ingests them into the vector store.
        """
        if self.observer is None:
            self.observer = start_watcher()
            logger.info("RAG pipeline activated.")
        else:
            logger.warning("RAG pipeline is already running.")

    def stop(self) -> None:
        """Stop the file watcher and release resources."""
        if self.observer:
            self.observer.stop()
            self.observer.join(timeout=5)
            self.observer = None
            logger.info("RAG pipeline stopped.")

    def query(self, query: str, n_results: int = 5) -> dict:
        """Query the vector store with a natural language string.

        Generates an embedding for the query locally, then searches
        the vector store for the most similar document chunks.

        Args:
            query: Natural language query string.
            n_results: Maximum number of results to return.

        Returns:
            ChromaDB results dict with 'documents', 'metadatas',
            'distances', and 'ids' keys.
        """
        if not query or not query.strip():
            logger.warning("Empty query received — returning no results.")
            return {}

        logger.info(f"RAG query: '{query[:80]}...'")

        query_embedding = embed_query(query)
        results = self.vector_store.query(query_embedding, n_results)
        return results

    @property
    def is_running(self) -> bool:
        """Check if the file watcher is currently active."""
        return self.observer is not None

    @property
    def document_count(self) -> int:
        """Return the total number of chunks in the vector store."""
        return self.vector_store.count()


# Module-level singleton
pipeline = RAGPipeline()
