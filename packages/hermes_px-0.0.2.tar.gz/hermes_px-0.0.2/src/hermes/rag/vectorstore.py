"""
Hermes RAG — Vector Store
=========================

ChromaDB-backed persistent vector store for document chunks.
Provides upsert, delete, and query operations against
locally stored embeddings.
"""

from typing import Any, Dict, List

import chromadb

from .._logger import get_logger
from .config import DB_DIR

logger = get_logger("rag.vectorstore")


class LocalVectorStore:
    """Persistent vector store backed by ChromaDB.

    Manages a single collection for all RAG document chunks.
    ChromaDB handles persistence automatically to the configured directory.

    Args:
        collection_name: Name of the ChromaDB collection.
    """

    def __init__(self, collection_name: str = "hermes_rag"):
        self.persist_directory = DB_DIR
        self.client = chromadb.PersistentClient(path=self.persist_directory)
        self.collection = self.client.get_or_create_collection(name=collection_name)
        logger.debug(f"Vector store initialized: {self.persist_directory}/{collection_name}")

    def upsert_chunks(
        self,
        document_id: str,
        chunks: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
    ) -> None:
        """Upsert document chunks into the vector store.

        Creates unique IDs per chunk using ``{document_id}_{index}`` format.

        Args:
            document_id: Unique identifier for the source document.
            chunks: List of text chunks.
            embeddings: Corresponding embedding vectors.
            metadatas: Metadata dicts for each chunk.
        """
        if not chunks:
            return

        ids = [f"{document_id}_{i}" for i in range(len(chunks))]

        self.collection.upsert(
            embeddings=embeddings,
            documents=chunks,
            metadatas=metadatas,
            ids=ids,
        )
        logger.info(f"Upserted {len(chunks)} chunks for '{document_id}'")

    def delete_by_document_id(self, document_id: str) -> None:
        """Delete all chunks associated with a document ID.

        Args:
            document_id: The source document identifier to purge.
        """
        try:
            self.collection.delete(where={"source_id": document_id})
            logger.info(f"Deleted chunks for '{document_id}'")
        except Exception as e:
            logger.error(f"Delete failed for '{document_id}': {e}")

    def query(
        self,
        query_embedding: List[float],
        n_results: int = 5,
    ) -> Dict[str, Any]:
        """Query the vector store for similar chunks.

        Args:
            query_embedding: The query vector to search against.
            n_results: Maximum number of results to return.

        Returns:
            ChromaDB query results dict with 'documents', 'metadatas',
            'distances', and 'ids' keys.
        """
        logger.debug(f"Vector query: n_results={n_results}")
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
        )
        return results

    def count(self) -> int:
        """Return the total number of chunks in the store."""
        return self.collection.count()


# Module-level singleton
vector_store = LocalVectorStore()
