"""
Hermes RAG — Document Ingestion Pipeline
=========================================

Handles file extraction, text chunking, embedding generation,
and vector store upsert for the RAG pipeline.

Supported file types:
    .txt, .md, .json, .jsonl, .csv — Text-based
    .pdf — Via PyMuPDF (fitz)
    .docx — Via python-docx
    .png, .jpg, .jpeg, .gif — Via Tesseract OCR
"""

import os
import json
import csv
import mimetypes
import time
from typing import List, Optional

import tiktoken

from .._logger import get_logger
from ..exceptions import RAGError
from .config import CHUNK_SIZE, CHUNK_OVERLAP, DATA_DIR
from .embeddings import embed_texts
from .vectorstore import vector_store

logger = get_logger("rag.ingest")

# Allowed file extensions (canonical list)
_ALLOWED_EXTENSIONS = {
    ".pdf", ".txt", ".md", ".docx", ".json", ".jsonl",
    ".csv", ".png", ".jpg", ".jpeg", ".gif",
}

# MIME types that are acceptable for ingestion
_ALLOWED_MIMES = {
    "application/pdf", "text/plain", "text/markdown", "text/csv",
    "application/json", "application/jsonlines",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/png", "image/jpeg", "image/gif",
}


def _validate_file_path(file_path: str) -> Optional[str]:
    """Validate a file path for security before ingestion.

    Checks:
        1. Resolves symlinks and normalizes the path
        2. Confirms the file is inside DATA_DIR (containment)
        3. Validates extension against the allow-list
        4. Cross-checks MIME type as a secondary defense

    Args:
        file_path: Raw path to validate.

    Returns:
        Resolved absolute path if valid, None if rejected.
    """
    resolved = os.path.realpath(file_path)
    data_dir_resolved = os.path.realpath(DATA_DIR)

    # Containment check: file must be inside DATA_DIR
    if not resolved.startswith(data_dir_resolved + os.sep) and resolved != data_dir_resolved:
        logger.warning(
            f"Path containment violation: {file_path} resolves outside "
            f"DATA_DIR ({data_dir_resolved})"
        )
        return None

    # Extension check
    ext = os.path.splitext(resolved)[1].lower()
    if ext not in _ALLOWED_EXTENSIONS:
        logger.debug(f"Rejected file with disallowed extension: {ext}")
        return None

    # MIME type cross-check (secondary defense)
    mime_type, _ = mimetypes.guess_type(resolved)
    if mime_type and mime_type not in _ALLOWED_MIMES:
        logger.warning(
            f"MIME type mismatch for {os.path.basename(resolved)}: "
            f"extension={ext}, detected={mime_type}"
        )
        return None

    return resolved

# ─── Optional Dependencies ──────────────────────────────────────
try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

try:
    import docx
except ImportError:
    docx = None

try:
    from PIL import Image
    import pytesseract
except ImportError:
    Image = None
    pytesseract = None


# ─── Tokenizer Cache ────────────────────────────────────────────
_tokenizer = None


def _get_tokenizer():
    """Get a cached tokenizer instance (cl100k_base)."""
    global _tokenizer
    if _tokenizer is None:
        _tokenizer = tiktoken.get_encoding("cl100k_base")
    return _tokenizer


# ─── Text Chunking ──────────────────────────────────────────────
def chunk_text(
    text: str,
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
) -> List[str]:
    """Split text into overlapping token-based chunks.

    Args:
        text: The text to chunk.
        chunk_size: Maximum tokens per chunk.
        chunk_overlap: Number of overlapping tokens between chunks.

    Returns:
        List of text chunks.
    """
    if not text.strip():
        return []

    tokenizer = _get_tokenizer()
    tokens = tokenizer.encode(text)

    if len(tokens) <= chunk_size:
        return [text]

    chunks = []
    step = max(1, chunk_size - chunk_overlap)
    i = 0
    while i < len(tokens):
        chunk_tokens = tokens[i : i + chunk_size]
        chunks.append(tokenizer.decode(chunk_tokens))
        i += step

    return chunks


# ─── File Extraction ────────────────────────────────────────────
def _extract_text_raw(file_path: str) -> str:
    """Extract text content from a file based on its extension.

    Args:
        file_path: Absolute or relative path to the file.

    Returns:
        Extracted text string.
    """
    ext = os.path.splitext(file_path)[1].lower()
    text = ""

    if ext in (".txt", ".md", ".jsonl"):
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()

    elif ext == ".json":
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            text = json.dumps(data, indent=2)

    elif ext == ".csv":
        with open(file_path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            lines = []
            for row in reader:
                lines.append(" ".join(row))
            text = "\n".join(lines)

    elif ext == ".pdf":
        if fitz:
            doc = fitz.open(file_path)
            pages = []
            for page in doc:
                pages.append(page.get_text())
            text = "\n".join(pages)
            doc.close()
        else:
            logger.warning("PyMuPDF (fitz) not installed — cannot parse PDF.")

    elif ext == ".docx":
        if docx:
            doc = docx.Document(file_path)
            text = "\n".join(para.text for para in doc.paragraphs)
        else:
            logger.warning("python-docx not installed — cannot parse DOCX.")

    elif ext in (".png", ".jpg", ".jpeg", ".gif"):
        if Image and pytesseract:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)
        else:
            logger.warning("Pillow/pytesseract not installed — cannot OCR images.")

    else:
        logger.debug(f"Unsupported file extension: {ext}")

    return text


def extract_text(file_path: str, retries: int = 3, delay: float = 0.5) -> str:
    """Extract text with retry logic for file lock race conditions.

    Args:
        file_path: Path to the file.
        retries: Maximum retry attempts on lock errors.
        delay: Seconds to wait between retries.

    Returns:
        Extracted text string, or empty string on failure.
    """
    for attempt in range(retries):
        try:
            return _extract_text_raw(file_path)
        except (PermissionError, BlockingIOError) as e:
            if attempt < retries - 1:
                logger.debug(f"File locked, retrying {file_path} in {delay}s...")
                time.sleep(delay)
            else:
                logger.error(f"Access failed after {retries} retries: {file_path} — {e}")
        except Exception as e:
            logger.error(f"Text extraction failed for {file_path}: {e}")
            break
    return ""


# ─── Ingestion Pipeline ─────────────────────────────────────────
def process_file(file_path: str) -> None:
    """Full ingestion pipeline: validate → extract → chunk → embed → store.

    Args:
        file_path: Path to the document to ingest.

    Raises:
        RAGError: If embedding generation fails critically.
    """
    # Step 0: Validate path security
    validated_path = _validate_file_path(file_path)
    if validated_path is None:
        logger.warning(f"Rejected by path validation: {file_path}")
        return

    logger.info(f"Ingesting: {validated_path}")

    # Step 1: Extract text
    text = extract_text(validated_path)
    if not text.strip():
        logger.warning(f"Empty extraction from {validated_path} — skipping.")
        return

    # Step 2: Chunk
    chunks = chunk_text(text)
    if not chunks:
        logger.warning(f"No chunks generated from {validated_path} — skipping.")
        return

    logger.debug(f"Generated {len(chunks)} chunks from {validated_path}")

    # Step 3: Embed
    try:
        embeddings = embed_texts(chunks)
    except RAGError as e:
        logger.error(f"Embedding failed for {validated_path}: {e}")
        raise

    if len(embeddings) != len(chunks):
        logger.error(
            f"Embedding count mismatch: {len(embeddings)} embeddings "
            f"for {len(chunks)} chunks — skipping {validated_path}"
        )
        return

    # Step 4: Store
    document_id = os.path.basename(validated_path)
    metadatas = [
        {"source_id": document_id, "path": validated_path, "chunk_index": i}
        for i in range(len(chunks))
    ]

    vector_store.upsert_chunks(document_id, chunks, embeddings, metadatas)
    logger.info(f"Ingested: {document_id} ({len(chunks)} chunks)")
