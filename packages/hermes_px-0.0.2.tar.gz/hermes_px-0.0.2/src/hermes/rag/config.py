"""
Hermes RAG — Configuration
==========================

Environment-based configuration for the RAG pipeline.
All values have sensible defaults and can be overridden via .env file.

Environment Variables:
    RAG_DATA_DIR: Directory to watch for documents. Default: ./Data
    RAG_DB_DIR: ChromaDB persistence directory. Default: ./chroma_db
    RAG_CHUNK_SIZE: Token count per chunk. Default: 512
    RAG_CHUNK_OVERLAP: Overlapping tokens between chunks. Default: 64
    RAG_EMBEDDING_MODEL: Sentence-transformers model name. Default: all-MiniLM-L6-v2
"""

import os
import stat
from dotenv import load_dotenv

from .._logger import get_logger
from ..exceptions import HermesConfigError

logger = get_logger("rag.config")

load_dotenv()


# ─── Path Security ──────────────────────────────────────────────
def _validate_directory(path: str, label: str) -> str:
    """Resolve and validate a directory path against traversal attacks.

    Args:
        path: Raw directory path from environment or default.
        label: Human-readable label for error messages.

    Returns:
        Resolved absolute path.

    Raises:
        HermesConfigError: If the path contains traversal sequences.
    """
    resolved = os.path.realpath(os.path.expanduser(path))

    if ".." in os.path.normpath(path).split(os.sep):
        raise HermesConfigError(
            f"{label} contains path traversal sequence '..': {path}",
            details={"path": path, "resolved": resolved},
        )

    return resolved


# ─── Directory Configuration ────────────────────────────────────
DATA_DIR = _validate_directory(os.getenv("RAG_DATA_DIR", "./Data"), "RAG_DATA_DIR")
DB_DIR = _validate_directory(os.getenv("RAG_DB_DIR", "./chroma_db"), "RAG_DB_DIR")

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# Ensure DB directory exists with restrictive permissions (owner-only)
os.makedirs(DB_DIR, mode=0o700, exist_ok=True)
try:
    os.chmod(DB_DIR, stat.S_IRWXU)  # rwx------
except OSError:
    logger.warning(f"Could not set restrictive permissions on {DB_DIR}")


# ─── Chunking Parameters ────────────────────────────────────────
try:
    CHUNK_SIZE = int(os.getenv("RAG_CHUNK_SIZE", "512"))
except ValueError:
    logger.warning("Invalid RAG_CHUNK_SIZE value, using default 512")
    CHUNK_SIZE = 512

try:
    CHUNK_OVERLAP = int(os.getenv("RAG_CHUNK_OVERLAP", "64"))
except ValueError:
    logger.warning("Invalid RAG_CHUNK_OVERLAP value, using default 64")
    CHUNK_OVERLAP = 64

# Validate chunk parameters
if CHUNK_SIZE < 1:
    logger.warning(f"RAG_CHUNK_SIZE={CHUNK_SIZE} invalid, using default 512")
    CHUNK_SIZE = 512

if CHUNK_OVERLAP < 0 or CHUNK_OVERLAP >= CHUNK_SIZE:
    logger.warning(
        f"RAG_CHUNK_OVERLAP={CHUNK_OVERLAP} invalid (must be 0..{CHUNK_SIZE-1}), "
        f"using default 64"
    )
    CHUNK_OVERLAP = 64


# ─── Embedding Configuration ────────────────────────────────────
EMBEDDING_MODEL = os.getenv("RAG_EMBEDDING_MODEL", "all-MiniLM-L6-v2")

logger.debug(
    f"RAG config loaded: data_dir={DATA_DIR}, db_dir={DB_DIR}, "
    f"chunk_size={CHUNK_SIZE}, overlap={CHUNK_OVERLAP}, model={EMBEDDING_MODEL}"
)
