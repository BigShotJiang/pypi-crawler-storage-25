"""
Hermes RAG — Local Embedding Engine
====================================

Generates text embeddings locally using sentence-transformers.
No API keys, no external network calls, fully offline operation.

Default model: all-MiniLM-L6-v2 (fast, 384-dimensional vectors)
Can be overridden via RAG_EMBEDDING_MODEL environment variable.
"""

from typing import List, Optional

from .._logger import get_logger
from ..exceptions import RAGError
from .config import EMBEDDING_MODEL

logger = get_logger("rag.embeddings")

# Lazy-loaded model singleton
_model = None
_model_name: Optional[str] = None


def _get_model():
    """Lazy-load the sentence-transformers model on first use.

    This avoids the import and model loading cost at package import time.
    The model is cached as a module-level singleton after first load.

    Returns:
        A SentenceTransformer model instance.

    Raises:
        RAGError: If sentence-transformers is not installed.
    """
    global _model, _model_name

    if _model is not None and _model_name == EMBEDDING_MODEL:
        return _model

    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        raise RAGError(
            "sentence-transformers is required for RAG embeddings. "
            "Install it with: pip install sentence-transformers"
        )

    logger.info(f"Loading embedding model: {EMBEDDING_MODEL}")
    try:
        _model = SentenceTransformer(EMBEDDING_MODEL)
        _model_name = EMBEDDING_MODEL
        logger.info(f"Embedding model '{EMBEDDING_MODEL}' loaded successfully.")
        return _model
    except Exception as e:
        raise RAGError(
            f"Failed to load embedding model '{EMBEDDING_MODEL}': {e}"
        )


def embed_texts(texts: List[str], batch_size: int = 64) -> List[List[float]]:
    """Generate embeddings for a list of text strings.

    Uses the locally loaded sentence-transformers model. Processing
    is done in batches to manage memory for large document sets.

    Args:
        texts: List of text strings to embed.
        batch_size: Number of texts to process at once. Default: 64.

    Returns:
        List of embedding vectors (each a list of floats).

    Raises:
        RAGError: If the model fails to generate embeddings.
        ValueError: If texts is empty.
    """
    if not texts:
        raise ValueError("Cannot embed an empty list of texts.")

    model = _get_model()

    try:
        logger.debug(f"Embedding {len(texts)} texts in batches of {batch_size}")
        embeddings = model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        # Convert numpy arrays to plain Python lists for ChromaDB compatibility
        result = [emb.tolist() for emb in embeddings]
        logger.debug(f"Generated {len(result)} embeddings (dim={len(result[0])})")
        return result

    except Exception as e:
        raise RAGError(f"Embedding generation failed: {e}")


def embed_query(text: str) -> List[float]:
    """Generate a single embedding for a query string.

    Convenience wrapper around embed_texts() for single queries.

    Args:
        text: The query string to embed.

    Returns:
        A single embedding vector (list of floats).
    """
    if not text or not text.strip():
        raise ValueError("Query text must not be empty.")

    results = embed_texts([text])
    return results[0]
