"""
Hermes Centralized Logging
==========================

Unified logging configuration for all Hermes subsystems.
Log level and output destination are configurable via environment variables.

Environment Variables:
    HERMES_LOG_LEVEL: Logging level (DEBUG, INFO, WARNING, ERROR). Default: INFO
    HERMES_LOG_FILE: Path to log file. Default: hermes.log
    HERMES_LOG_CONSOLE: Set to '1' to enable console output. Default: '0'
"""

import os
import sys
import logging
from typing import Optional

_LOG_FORMAT = "%(asctime)s [%(name)s] %(levelname)s — %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Track whether root logger has been configured to avoid duplicate handlers
_configured = False


def _get_log_level() -> int:
    """Read log level from environment, defaulting to INFO."""
    level_str = os.getenv("HERMES_LOG_LEVEL", "INFO").upper()
    return getattr(logging, level_str, logging.INFO)


def _configure_root_logger() -> None:
    """Configure the root 'hermes' logger once.

    This sets up file and optionally console handlers.
    Called lazily on first get_logger() invocation.
    """
    global _configured
    if _configured:
        return

    root = logging.getLogger("hermes")
    root.setLevel(_get_log_level())

    # Prevent propagation to the root Python logger
    root.propagate = False

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    # File handler
    log_file = os.getenv("HERMES_LOG_FILE", "hermes.log")
    try:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(_get_log_level())
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
    except (OSError, PermissionError):
        # If file logging fails (e.g., read-only filesystem), continue silently
        pass

    # Console handler (opt-in)
    if os.getenv("HERMES_LOG_CONSOLE", "0") == "1":
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(_get_log_level())
        console_handler.setFormatter(formatter)
        root.addHandler(console_handler)

    _configured = True


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Get a named logger under the 'hermes' namespace.

    Args:
        name: Optional sub-namespace (e.g., 'rag', 'client').
              Results in logger named 'hermes.rag', 'hermes.client', etc.

    Returns:
        A configured logging.Logger instance.

    Example:
        >>> from hermes._logger import get_logger
        >>> logger = get_logger("client")
        >>> logger.info("Session initialized")
    """
    _configure_root_logger()
    full_name = f"hermes.{name}" if name else "hermes"
    return logging.getLogger(full_name)
