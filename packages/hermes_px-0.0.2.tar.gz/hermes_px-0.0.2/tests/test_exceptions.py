"""Tests for hermes.exceptions — Hierarchy, messages, details."""

import pytest
from hermes.exceptions import (
    HermesError,
    HermesConnectionError,
    HermesTimeoutError,
    HermesResponseError,
    HermesConfigError,
    RAGError,
)


class TestHermesError:
    def test_basic_message(self):
        err = HermesError("Something went wrong")
        assert str(err) == "Something went wrong"
        assert err.message == "Something went wrong"
        assert err.details == {}

    def test_with_details(self):
        err = HermesError("Failed", details={"code": 500})
        assert "code=500" in str(err)
        assert err.details["code"] == 500

    def test_is_exception(self):
        with pytest.raises(HermesError):
            raise HermesError("test")

    def test_catches_all_subclasses(self):
        """HermesError should catch any library-specific exception."""
        for exc_class in [HermesConnectionError, HermesTimeoutError,
                          HermesResponseError, HermesConfigError, RAGError]:
            with pytest.raises(HermesError):
                raise exc_class("test")


class TestHermesConnectionError:
    def test_creation(self):
        err = HermesConnectionError("Tor proxy down")
        assert isinstance(err, HermesError)
        assert "Tor proxy down" in str(err)

    def test_with_proxy_detail(self):
        err = HermesConnectionError(
            "Connection refused",
            details={"proxy": "socks5h://127.0.0.1:9050"},
        )
        assert err.details["proxy"] == "socks5h://127.0.0.1:9050"


class TestHermesTimeoutError:
    def test_with_timeout_value(self):
        err = HermesTimeoutError("Timed out", timeout_seconds=30)
        assert err.timeout_seconds == 30
        assert "timeout_seconds=30" in str(err)

    def test_without_timeout_value(self):
        err = HermesTimeoutError("Timed out")
        assert err.timeout_seconds is None


class TestHermesResponseError:
    def test_with_status_code(self):
        err = HermesResponseError("Bad response", status_code=502)
        assert err.status_code == 502
        assert "status_code=502" in str(err)

    def test_without_status_code(self):
        err = HermesResponseError("Malformed JSON")
        assert err.status_code is None


class TestHermesConfigError:
    def test_creation(self):
        err = HermesConfigError("Invalid proxy URL")
        assert isinstance(err, HermesError)
        assert "Invalid proxy URL" in str(err)


class TestRAGError:
    def test_creation(self):
        err = RAGError("Embedding model not found")
        assert isinstance(err, HermesError)
        assert "Embedding model" in str(err)
