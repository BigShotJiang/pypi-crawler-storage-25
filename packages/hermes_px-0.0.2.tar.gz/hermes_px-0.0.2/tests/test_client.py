"""Tests for hermes.client — Initialization, proxy, context manager, ping."""

import pytest
from unittest.mock import patch, MagicMock
from hermes.client import Hermes, _validate_proxy_url, _load_base_prompt
from hermes.exceptions import HermesConfigError


class TestProxyValidation:
    def test_valid_socks5h(self):
        _validate_proxy_url("socks5h://127.0.0.1:9050")

    def test_valid_socks5(self):
        _validate_proxy_url("socks5://192.168.1.1:1080")

    def test_valid_hostname(self):
        _validate_proxy_url("socks5h://localhost:9050")

    def test_invalid_no_port(self):
        with pytest.raises(HermesConfigError):
            _validate_proxy_url("socks5h://127.0.0.1")

    def test_invalid_http_scheme(self):
        with pytest.raises(HermesConfigError):
            _validate_proxy_url("http://127.0.0.1:9050")

    def test_invalid_empty(self):
        with pytest.raises(HermesConfigError):
            _validate_proxy_url("")

    def test_invalid_garbage(self):
        with pytest.raises(HermesConfigError):
            _validate_proxy_url("not-a-url")


class TestHermesInit:
    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_default_initialization(self, mock_prompt):
        client = Hermes()
        assert client._proxy == "socks5h://127.0.0.1:9050"
        assert client.session is not None
        assert client.session.proxies["https"] == "socks5h://127.0.0.1:9050"
        assert client.session.verify is True
        client.close()

    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_custom_proxy(self, mock_prompt):
        client = Hermes(tor_proxy="socks5h://10.0.0.1:9150")
        assert client._proxy == "socks5h://10.0.0.1:9150"
        assert client.session.proxies["http"] == "socks5h://10.0.0.1:9150"
        client.close()

    def test_invalid_proxy_raises(self):
        with pytest.raises(HermesConfigError):
            Hermes(tor_proxy="http://bad:proxy")

    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_headers_set(self, mock_prompt):
        client = Hermes()
        headers = client.session.headers
        assert "Chrome/146" in headers.get("User-Agent", "")
        assert headers.get("Sec-Fetch-Mode") == "cors"
        client.close()

    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_repr(self, mock_prompt):
        client = Hermes()
        r = repr(client)
        assert "Hermes" in r
        assert "9050" in r
        client.close()

    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_str(self, mock_prompt):
        client = Hermes()
        s = str(client)
        assert "Hermes Client" in s
        client.close()


class TestContextManager:
    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_with_statement(self, mock_prompt):
        with Hermes() as client:
            assert client.session is not None
        # Session should still exist but close() was called

    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_close_called(self, mock_prompt):
        client = Hermes()
        client.session = MagicMock()
        client.__exit__(None, None, None)
        client.session.close.assert_called_once()


class TestPing:
    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_ping_success(self, mock_prompt):
        client = Hermes()
        client.session = MagicMock()
        client.session.head.return_value = MagicMock(status_code=200)
        assert client.ping() is True

    @patch("hermes.client._load_base_prompt", return_value=None)
    def test_ping_failure(self, mock_prompt):
        client = Hermes()
        client.session = MagicMock()
        client.session.head.side_effect = ConnectionError("refused")
        assert client.ping() is False


class TestBasePromptLoading:
    def test_loads_plaintext(self, tmp_path):
        f = tmp_path / "test_prompt.txt"
        f.write_text("You are a helpful assistant.")

        import hermes.client
        hermes.client._base_prompt_cache = None  # Reset cache
        result = _load_base_prompt(str(f))
        assert result == "You are a helpful assistant."
        hermes.client._base_prompt_cache = None  # Cleanup

    def test_loads_compressed(self, tmp_path):
        import zlib, base64
        original = "You are a compressed prompt."
        compressed = zlib.compress(original.encode("utf-8"), 9)
        encoded = base64.b64encode(compressed).decode("utf-8")

        f = tmp_path / "prompt.pz"
        f.write_text(encoded)

        import hermes.client
        hermes.client._base_prompt_cache = None
        result = _load_base_prompt(str(f))
        assert result == original
        hermes.client._base_prompt_cache = None

    def test_missing_file_returns_none(self):
        import hermes.client
        hermes.client._base_prompt_cache = None
        result = _load_base_prompt("/nonexistent/path/prompt.txt")
        assert result is None
        hermes.client._base_prompt_cache = None
