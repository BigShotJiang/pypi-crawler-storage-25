"""Tests for hermes.rag.ingest — Text extraction, chunking, pipeline."""

import pytest
import os
from hermes.rag.ingest import chunk_text, _extract_text_raw, extract_text


class TestChunkText:
    def test_empty_string(self):
        assert chunk_text("") == []

    def test_whitespace_only(self):
        assert chunk_text("   \n\t  ") == []

    def test_short_text_single_chunk(self):
        result = chunk_text("Hello world", chunk_size=100, chunk_overlap=10)
        assert len(result) == 1
        assert "Hello world" in result[0]

    def test_long_text_multiple_chunks(self):
        text = " ".join(["word"] * 500)
        result = chunk_text(text, chunk_size=50, chunk_overlap=10)
        assert len(result) > 1

    def test_overlap_produces_redundancy(self):
        text = " ".join(["token"] * 200)
        no_overlap = chunk_text(text, chunk_size=50, chunk_overlap=0)
        with_overlap = chunk_text(text, chunk_size=50, chunk_overlap=10)
        assert len(with_overlap) > len(no_overlap)

    def test_chunk_size_respected(self):
        text = " ".join(["word"] * 1000)
        result = chunk_text(text, chunk_size=100, chunk_overlap=20)
        for c in result:
            assert len(c) > 0  # Every chunk has content


class TestExtractTextRaw:
    def test_txt_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("Hello from a text file.", encoding="utf-8")
        result = _extract_text_raw(str(f))
        assert "Hello from a text file" in result

    def test_md_file(self, tmp_path):
        f = tmp_path / "doc.md"
        f.write_text("# Heading\nSome content.", encoding="utf-8")
        result = _extract_text_raw(str(f))
        assert "Heading" in result

    def test_json_file(self, tmp_path):
        import json
        f = tmp_path / "data.json"
        f.write_text(json.dumps({"key": "value"}), encoding="utf-8")
        result = _extract_text_raw(str(f))
        assert "key" in result
        assert "value" in result

    def test_csv_file(self, tmp_path):
        f = tmp_path / "data.csv"
        f.write_text("name,age\nAlice,30\nBob,25", encoding="utf-8")
        result = _extract_text_raw(str(f))
        assert "Alice" in result
        assert "Bob" in result

    def test_unsupported_extension(self, tmp_path):
        f = tmp_path / "data.xyz"
        f.write_text("unknown format")
        result = _extract_text_raw(str(f))
        assert result == ""

    def test_jsonl_file(self, tmp_path):
        f = tmp_path / "data.jsonl"
        f.write_text('{"line": 1}\n{"line": 2}\n', encoding="utf-8")
        result = _extract_text_raw(str(f))
        assert "line" in result


class TestExtractText:
    def test_successful_extraction(self, tmp_text_file):
        result = extract_text(tmp_text_file)
        assert "Binary search" in result

    def test_missing_file(self):
        result = extract_text("/nonexistent/path/file.txt")
        assert result == ""

    def test_permission_error_retries(self, tmp_path, monkeypatch):
        f = tmp_path / "locked.txt"
        f.write_text("content")
        call_count = {"n": 0}

        original_raw = _extract_text_raw

        def mock_raw(path):
            call_count["n"] += 1
            if call_count["n"] < 3:
                raise PermissionError("locked")
            return original_raw(path)

        monkeypatch.setattr("hermes.rag.ingest._extract_text_raw", mock_raw)
        result = extract_text(str(f), retries=3, delay=0.01)
        assert "content" in result
        assert call_count["n"] == 3
