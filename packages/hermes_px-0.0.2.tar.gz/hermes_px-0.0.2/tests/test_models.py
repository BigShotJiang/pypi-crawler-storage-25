"""Tests for hermes.models — Dataclass creation, serialization, edge cases."""

import pytest
from hermes.models import Message, Choice, ChatCompletion, Usage


class TestMessage:
    def test_creation_with_defaults(self):
        msg = Message(content="Hello")
        assert msg.content == "Hello"
        assert msg.role == "assistant"

    def test_creation_with_custom_role(self):
        msg = Message(content="Hi", role="user")
        assert msg.role == "user"

    def test_to_dict(self):
        msg = Message(content="Test", role="system")
        d = msg.to_dict()
        assert d == {"role": "system", "content": "Test"}

    def test_frozen_immutability(self):
        msg = Message(content="Immutable")
        with pytest.raises(AttributeError):
            msg.content = "Modified"

    def test_empty_content(self):
        msg = Message(content="")
        assert msg.content == ""
        assert msg.to_dict()["content"] == ""


class TestUsage:
    def test_creation_with_defaults(self):
        usage = Usage()
        assert usage.prompt_tokens == 0
        assert usage.completion_tokens == 0
        assert usage.total_tokens == 0

    def test_creation_with_values(self):
        usage = Usage(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        assert usage.total_tokens == 30

    def test_to_dict(self):
        usage = Usage(prompt_tokens=5, completion_tokens=15, total_tokens=20)
        d = usage.to_dict()
        assert d["prompt_tokens"] == 5
        assert d["total_tokens"] == 20


class TestChoice:
    def test_creation(self):
        msg = Message(content="Reply")
        choice = Choice(message=msg)
        assert choice.index == 0
        assert choice.finish_reason == "stop"
        assert choice.message.content == "Reply"

    def test_to_dict(self):
        msg = Message(content="Test")
        choice = Choice(message=msg, index=1, finish_reason="length")
        d = choice.to_dict()
        assert d["index"] == 1
        assert d["finish_reason"] == "length"
        assert d["message"]["content"] == "Test"


class TestChatCompletion:
    def test_creation(self):
        msg = Message(content="Hello!")
        choice = Choice(message=msg)
        completion = ChatCompletion(
            id="chatcmpl-abc123",
            choices=[choice],
            model="OLYMPUS-1",
        )
        assert completion.id == "chatcmpl-abc123"
        assert completion.model == "OLYMPUS-1"
        assert completion.object == "chat.completion"
        assert len(completion.choices) == 1

    def test_to_dict_without_usage(self):
        msg = Message(content="Hi")
        completion = ChatCompletion(
            id="test-id",
            choices=[Choice(message=msg)],
            model="hermes-v1",
        )
        d = completion.to_dict()
        assert d["id"] == "test-id"
        assert d["model"] == "hermes-v1"
        assert "usage" not in d
        assert len(d["choices"]) == 1

    def test_to_dict_with_usage(self):
        msg = Message(content="Hi")
        usage = Usage(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        completion = ChatCompletion(
            id="test-id",
            choices=[Choice(message=msg)],
            model="OLYMPUS-1",
            usage=usage,
        )
        d = completion.to_dict()
        assert "usage" in d
        assert d["usage"]["total_tokens"] == 30

    def test_access_pattern_matches_openai(self):
        """Verify the standard access pattern: response.choices[0].message.content"""
        msg = Message(content="The answer is 42.")
        completion = ChatCompletion(
            id="test",
            choices=[Choice(message=msg)],
            model="OLYMPUS-1",
        )
        assert completion.choices[0].message.content == "The answer is 42."
        assert completion.choices[0].message.role == "assistant"
        assert completion.choices[0].finish_reason == "stop"

    def test_frozen_immutability(self):
        msg = Message(content="Frozen")
        completion = ChatCompletion(id="x", choices=[Choice(message=msg)], model="m")
        with pytest.raises(AttributeError):
            completion.model = "changed"
