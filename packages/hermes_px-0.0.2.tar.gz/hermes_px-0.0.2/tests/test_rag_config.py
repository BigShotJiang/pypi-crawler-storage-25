"""Tests for hermes.rag.config — Environment variable parsing."""

import pytest
import os
from unittest.mock import patch


class TestRAGConfig:
    @patch.dict(os.environ, {}, clear=True)
    def test_default_values(self):
        # Force reimport to pick up patched env
        import importlib
        import hermes.rag.config as cfg
        importlib.reload(cfg)

        assert cfg.CHUNK_SIZE == 512
        assert cfg.CHUNK_OVERLAP == 64
        assert cfg.EMBEDDING_MODEL == "all-MiniLM-L6-v2"

    @patch.dict(os.environ, {
        "RAG_CHUNK_SIZE": "256",
        "RAG_CHUNK_OVERLAP": "32",
        "RAG_EMBEDDING_MODEL": "custom-model",
    })
    def test_custom_values(self):
        import importlib
        import hermes.rag.config as cfg
        importlib.reload(cfg)

        assert cfg.CHUNK_SIZE == 256
        assert cfg.CHUNK_OVERLAP == 32
        assert cfg.EMBEDDING_MODEL == "custom-model"

    @patch.dict(os.environ, {"RAG_CHUNK_SIZE": "not_a_number"})
    def test_invalid_chunk_size_falls_back(self):
        import importlib
        import hermes.rag.config as cfg
        importlib.reload(cfg)

        assert cfg.CHUNK_SIZE == 512  # Falls back to default
