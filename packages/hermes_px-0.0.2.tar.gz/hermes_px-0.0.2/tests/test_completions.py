"""Tests for hermes.completions — create(), error handling, input validation."""

import pytest
from unittest.mock import patch, MagicMock, PropertyMock
from requests.exceptions import ProxyError, Timeout, ConnectionError as ReqConnectionError

from hermes.completions import Completions
from hermes.models import ChatCompletion
from hermes.exceptions import (
    HermesConnectionError,
    HermesTimeoutError,
    HermesResponseError,
)


@pytest.fixture
def completions():
    """Create a Completions instance with a mocked session."""
    session = MagicMock()
    session.proxies = {"https": "socks5h://127.0.0.1:9050"}
    return Completions(session=session, base_system_prompt="You are helpful.")


class TestCreateSuccess:
    def test_successful_completion(self, completions, mock_upstream_response, sample_messages):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = mock_upstream_response
        completions._session.post.return_value = mock_resp

        result = completions.create(messages=sample_messages, model="OLYMPUS-1")

        assert isinstance(result, ChatCompletion)
        assert result.model == "OLYMPUS-1"
        assert "Hello" in result.choices[0].message.content
        assert result.id == "chatcmpl-test123"

    def test_uses_fallback_model(self, completions, mock_upstream_response, sample_messages):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = mock_upstream_response
        completions._session.post.return_value = mock_resp

        result = completions.create(messages=sample_messages)
        assert result.model == "hermes-v1"

    def test_parses_usage_stats(self, completions, mock_upstream_response, sample_messages):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = mock_upstream_response
        completions._session.post.return_value = mock_resp

        result = completions.create(messages=sample_messages)
        assert result.usage is not None
        assert result.usage.total_tokens == 55

    def test_injects_system_schema(self, completions, sample_messages):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = {
            "id": "test",
            "choices": [{"message": {"content": "OK"}}],
        }
        completions._session.post.return_value = mock_resp

        completions.create(messages=sample_messages)

        call_args = completions._session.post.call_args
        payload = call_args[1]["json"]
        messages = payload["messages"]
        # System schema (2) + base prompt (1) + user message (1) = 4
        assert len(messages) == 4
        assert messages[0]["role"] == "system"
        assert messages[2]["role"] == "system"  # base prompt
        assert messages[3]["role"] == "user"

    def test_handles_malformed_response(self, completions, malformed_response, sample_messages):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = malformed_response
        completions._session.post.return_value = mock_resp

        result = completions.create(messages=sample_messages)
        # Should stringify the raw response when choices is missing
        assert "error" in result.choices[0].message.content


class TestCreateErrors:
    def test_proxy_error(self, completions, sample_messages):
        completions._session.post.side_effect = ProxyError("SOCKS refused")
        with pytest.raises(HermesConnectionError, match="Tor proxy layer"):
            completions.create(messages=sample_messages)

    def test_timeout_error(self, completions, sample_messages):
        completions._session.post.side_effect = Timeout("timed out")
        with pytest.raises(HermesTimeoutError, match="timed out"):
            completions.create(messages=sample_messages)

    def test_connection_error(self, completions, sample_messages):
        completions._session.post.side_effect = ReqConnectionError("refused")
        with pytest.raises(HermesConnectionError, match="connection"):
            completions.create(messages=sample_messages)

    def test_http_error(self, completions, sample_messages):
        import requests
        mock_resp = MagicMock()
        http_err = requests.exceptions.HTTPError(response=MagicMock(status_code=502))
        mock_resp.raise_for_status.side_effect = http_err
        completions._session.post.return_value = mock_resp

        with pytest.raises(HermesResponseError, match="error response"):
            completions.create(messages=sample_messages)

    def test_json_parse_error(self, completions, sample_messages):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.side_effect = ValueError("No JSON")
        mock_resp.status_code = 200
        completions._session.post.return_value = mock_resp

        with pytest.raises(HermesResponseError, match="non-JSON"):
            completions.create(messages=sample_messages)


class TestInputValidation:
    def test_empty_messages_raises(self, completions):
        with pytest.raises(ValueError, match="non-empty list"):
            completions.create(messages=[])

    def test_none_messages_raises(self, completions):
        with pytest.raises(ValueError, match="non-empty list"):
            completions.create(messages=None)

    def test_invalid_message_format_raises(self, completions):
        with pytest.raises(ValueError, match="index 0"):
            completions.create(messages=[{"bad": "format"}])

    def test_string_instead_of_list_raises(self, completions):
        with pytest.raises(ValueError):
            completions.create(messages="not a list")
