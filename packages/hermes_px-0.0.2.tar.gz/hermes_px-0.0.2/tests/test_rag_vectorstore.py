"""Tests for hermes.rag.vectorstore — Upsert, delete, query, count."""

import pytest
from unittest.mock import patch, MagicMock


class TestLocalVectorStore:
    @patch("hermes.rag.vectorstore.chromadb.PersistentClient")
    def test_upsert_chunks(self, mock_client_cls):
        mock_collection = MagicMock()
        mock_client = MagicMock()
        mock_client.get_or_create_collection.return_value = mock_collection
        mock_client_cls.return_value = mock_client

        from hermes.rag.vectorstore import LocalVectorStore
        store = LocalVectorStore(collection_name="test_collection")

        chunks = ["chunk1", "chunk2"]
        embeddings = [[0.1, 0.2], [0.3, 0.4]]
        metadatas = [{"source_id": "doc1", "chunk_index": 0}, {"source_id": "doc1", "chunk_index": 1}]

        store.upsert_chunks("doc1", chunks, embeddings, metadatas)

        mock_collection.upsert.assert_called_once()
        call_kwargs = mock_collection.upsert.call_args[1]
        assert call_kwargs["documents"] == chunks
        assert call_kwargs["ids"] == ["doc1_0", "doc1_1"]

    @patch("hermes.rag.vectorstore.chromadb.PersistentClient")
    def test_upsert_empty_chunks(self, mock_client_cls):
        mock_collection = MagicMock()
        mock_client = MagicMock()
        mock_client.get_or_create_collection.return_value = mock_collection
        mock_client_cls.return_value = mock_client

        from hermes.rag.vectorstore import LocalVectorStore
        store = LocalVectorStore()
        store.upsert_chunks("doc1", [], [], [])
        mock_collection.upsert.assert_not_called()

    @patch("hermes.rag.vectorstore.chromadb.PersistentClient")
    def test_delete_by_document_id(self, mock_client_cls):
        mock_collection = MagicMock()
        mock_client = MagicMock()
        mock_client.get_or_create_collection.return_value = mock_collection
        mock_client_cls.return_value = mock_client

        from hermes.rag.vectorstore import LocalVectorStore
        store = LocalVectorStore()
        store.delete_by_document_id("doc1")
        mock_collection.delete.assert_called_once_with(where={"source_id": "doc1"})

    @patch("hermes.rag.vectorstore.chromadb.PersistentClient")
    def test_query(self, mock_client_cls):
        mock_collection = MagicMock()
        mock_collection.query.return_value = {
            "documents": [["chunk1"]],
            "ids": [["doc1_0"]],
            "distances": [[0.1]],
        }
        mock_client = MagicMock()
        mock_client.get_or_create_collection.return_value = mock_collection
        mock_client_cls.return_value = mock_client

        from hermes.rag.vectorstore import LocalVectorStore
        store = LocalVectorStore()
        results = store.query([0.1, 0.2], n_results=3)

        mock_collection.query.assert_called_once()
        assert "documents" in results

    @patch("hermes.rag.vectorstore.chromadb.PersistentClient")
    def test_count(self, mock_client_cls):
        mock_collection = MagicMock()
        mock_collection.count.return_value = 42
        mock_client = MagicMock()
        mock_client.get_or_create_collection.return_value = mock_collection
        mock_client_cls.return_value = mock_client

        from hermes.rag.vectorstore import LocalVectorStore
        store = LocalVectorStore()
        assert store.count() == 42
