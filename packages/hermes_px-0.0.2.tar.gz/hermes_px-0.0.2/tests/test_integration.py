"""
Integration test — Sends a real message through Tor.

This test requires:
    1. A running Tor daemon on 127.0.0.1:9050
    2. Network connectivity through the Tor circuit

Run with: pytest tests/test_integration.py -v -s
Skip with: pytest tests/ --ignore=tests/test_integration.py
"""

import pytest
import os

# Skip if no Tor is available (CI environments)
SKIP_REASON = "Integration test requires live Tor daemon (set HERMES_RUN_INTEGRATION=1)"
RUN_INTEGRATION = os.getenv("HERMES_RUN_INTEGRATION", "0") == "1"


@pytest.mark.skipif(not RUN_INTEGRATION, reason=SKIP_REASON)
class TestLiveIntegration:
    """End-to-end tests against the real upstream via Tor."""

    def test_ping_proxy(self):
        """Verify Tor proxy is reachable."""
        from hermes import Hermes
        client = Hermes()
        assert client.ping() is True
        client.close()

    def test_send_message(self):
        """Send a real message and verify response structure."""
        from hermes import Hermes

        with Hermes() as client:
            response = client.chat.completions.create(
                model="OLYMPUS-1",
                messages=[
                    {"role": "user", "content": "Say 'Hermes test successful' and nothing else."}
                ],
                timeout=30,
            )

        # Validate response structure
        assert response is not None
        assert response.id is not None
        assert len(response.choices) > 0
        assert response.choices[0].message.content is not None
        assert len(response.choices[0].message.content) > 0
        assert response.model == "OLYMPUS-1"

        print(f"\n✅ Live response received:")
        print(f"   ID: {response.id}")
        print(f"   Model: {response.model}")
        print(f"   Content: {response.choices[0].message.content[:200]}")

    def test_multi_turn_conversation(self):
        """Test a multi-turn conversation preserving history."""
        from hermes import Hermes

        messages = [
            {"role": "user", "content": "Remember the number 42."},
        ]

        with Hermes() as client:
            r1 = client.chat.completions.create(model="OLYMPUS-1", messages=messages, timeout=30)
            assert r1.choices[0].message.content

            messages.append({"role": "assistant", "content": r1.choices[0].message.content})
            messages.append({"role": "user", "content": "What number did I tell you to remember?"})

            r2 = client.chat.completions.create(model="OLYMPUS-1", messages=messages, timeout=30)
            assert r2.choices[0].message.content

        print(f"\n✅ Multi-turn test:")
        print(f"   R1: {r1.choices[0].message.content[:100]}")
        print(f"   R2: {r2.choices[0].message.content[:100]}")
