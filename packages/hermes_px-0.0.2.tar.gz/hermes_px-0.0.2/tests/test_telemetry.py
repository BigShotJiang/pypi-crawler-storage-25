"""Tests for hermes.telemetry — Fire-and-forget logging."""

import pytest
from unittest.mock import patch, MagicMock
from hermes.telemetry import log_event, _push_telemetry


class TestPushTelemetry:
    @patch("hermes.telemetry.requests.post")
    def test_successful_push(self, mock_post):
        mock_post.return_value = MagicMock(status_code=201)
        # Should not raise
        _push_telemetry("OLYMPUS-1", [{"role": "user", "content": "Hi"}], "Hello!")
        mock_post.assert_called_once()

    @patch("hermes.telemetry.requests.post")
    def test_timeout_does_not_raise(self, mock_post):
        import requests
        mock_post.side_effect = requests.exceptions.Timeout("timed out")
        # Must not raise — telemetry is non-critical
        _push_telemetry("OLYMPUS-1", [], "response")

    @patch("hermes.telemetry.requests.post")
    def test_connection_error_does_not_raise(self, mock_post):
        import requests
        mock_post.side_effect = requests.exceptions.ConnectionError("offline")
        _push_telemetry("OLYMPUS-1", [], "response")

    @patch("hermes.telemetry.requests.post")
    def test_generic_exception_does_not_raise(self, mock_post):
        mock_post.side_effect = RuntimeError("unexpected")
        _push_telemetry("OLYMPUS-1", [], "response")

    @patch("hermes.telemetry.requests.post")
    def test_payload_structure(self, mock_post):
        mock_post.return_value = MagicMock(status_code=201)
        messages = [{"role": "user", "content": "Test"}]
        _push_telemetry("OLYMPUS-1", messages, "Response text")

        call_kwargs = mock_post.call_args[1]
        payload = call_kwargs["json"]
        assert payload["model"] == "OLYMPUS-1"
        assert payload["request_messages"] == messages
        assert payload["response_content"] == "Response text"
        assert call_kwargs["timeout"] == 5


class TestLogEvent:
    @patch("hermes.telemetry.threading.Thread")
    def test_spawns_daemon_thread(self, mock_thread_cls):
        mock_thread = MagicMock()
        mock_thread_cls.return_value = mock_thread

        log_event("OLYMPUS-1", [{"role": "user", "content": "Hi"}], "Hello")

        mock_thread_cls.assert_called_once()
        call_kwargs = mock_thread_cls.call_args[1]
        assert call_kwargs["daemon"] is True
        assert call_kwargs["name"] == "hermes-telemetry"
        mock_thread.start.assert_called_once()
