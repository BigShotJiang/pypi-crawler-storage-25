"""Tests for hermes.rag.watcher — File event handling and debounce."""

import pytest
import time
from unittest.mock import patch, MagicMock
from hermes.rag.watcher import RAGFileHandler, SUPPORTED_EXTENSIONS


class TestRAGFileHandler:
    def setup_method(self):
        self.handler = RAGFileHandler()

    def test_valid_txt_file(self):
        assert self.handler._is_valid_file("/path/to/doc.txt") is True

    def test_valid_pdf_file(self):
        assert self.handler._is_valid_file("/path/report.pdf") is True

    def test_rejects_hidden_file(self):
        assert self.handler._is_valid_file("/path/.hidden.txt") is False

    def test_rejects_unsupported_extension(self):
        assert self.handler._is_valid_file("/path/file.exe") is False

    def test_rejects_directory(self, tmp_path):
        assert self.handler._is_valid_file(str(tmp_path)) is False

    def test_supported_extensions_complete(self):
        expected = {".pdf", ".txt", ".md", ".docx", ".json", ".jsonl",
                    ".csv", ".png", ".jpg", ".jpeg", ".gif"}
        assert SUPPORTED_EXTENSIONS == expected

    @patch("hermes.rag.watcher.process_file")
    @patch("hermes.rag.watcher.vector_store")
    def test_on_created_triggers_ingest(self, mock_store, mock_process):
        event = MagicMock()
        event.is_directory = False
        event.src_path = "/data/test.txt"

        with patch.object(self.handler, "_is_valid_file", return_value=True):
            self.handler.on_created(event)
            # Debounced — wait for timer
            time.sleep(1.5)

        mock_store.delete_by_document_id.assert_called()
        mock_process.assert_called_with("/data/test.txt")

    def test_on_created_ignores_directories(self):
        event = MagicMock()
        event.is_directory = True
        # Should not raise or trigger anything
        self.handler.on_created(event)

    @patch("hermes.rag.watcher.vector_store")
    def test_on_deleted_removes_chunks(self, mock_store):
        event = MagicMock()
        event.is_directory = False
        event.src_path = "/data/old_doc.pdf"

        self.handler.on_deleted(event)
        mock_store.delete_by_document_id.assert_called_once_with("old_doc.pdf")

    @patch("hermes.rag.watcher.vector_store")
    def test_on_moved_deletes_old_and_ingests_new(self, mock_store):
        event = MagicMock()
        event.is_directory = False
        event.src_path = "/data/old.txt"
        event.dest_path = "/data/new.txt"

        with patch.object(self.handler, "_debounce_ingest") as mock_debounce:
            self.handler.on_moved(event)

        mock_store.delete_by_document_id.assert_called_once_with("old.txt")
        mock_debounce.assert_called_once_with("/data/new.txt")

    @patch("hermes.rag.watcher.process_file")
    @patch("hermes.rag.watcher.vector_store")
    def test_debounce_cancels_rapid_saves(self, mock_store, mock_process):
        """Rapid saves should only trigger one ingestion."""
        with patch.object(self.handler, "_is_valid_file", return_value=True):
            self.handler._debounce_ingest("/data/doc.txt")
            self.handler._debounce_ingest("/data/doc.txt")
            self.handler._debounce_ingest("/data/doc.txt")
            time.sleep(1.5)

        # Should only have been called once despite 3 triggers
        assert mock_process.call_count == 1
