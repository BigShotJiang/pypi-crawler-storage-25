# Shafikul CLI

**Shafikul CLI** is a command-line tool to scaffold **FastAPI projects** quickly.  
It helps you generate routers, models, database connections, HTML templates, full complete application with proper folder structure and auto updates for `main.py` and `.env` file.

---

## Features

- ✅ Create FastAPI routers, models, and database modules  
- ✅ Auto-generate `main.py` with imports and DB setup  
- ✅ Auto-generate or update `.env` file  
- ✅ Create HTML templates (`index.html` or custom names)  
- ✅ Interactive CLI (numeric and text options)  
- ✅ Colored console output  
- ✅ Version commands (`--version, -v, -V`)  
- ✅ About commands (`--about, -a, -A`)  

---

## Installation

Install from PyPI:

```bash
pip install shafikul_cli
```

Or Locally (editable):
```sh
git clone https://github.com/build-with-shafikul/shafikul_cli.git
cd shafikul_cli
pip install -e .
```

## CLI help
```sh
shafikul_cli --help
```

## Show version
```sh
shafikul_cli --version
```

## About CLI
```sh
shafikul_cli --about
```

## Create resources
```sh
shafikul_cli create app
```

### Interactive Option
<code>
1: router <br/>
2: models <br/>
3: database <br/>
4: html <br/>
5: structure
</code>
<br/>
<br/>

You can select by number or by name
Example for HTML template: <br/>
<code>shafikul create app html <br/>
Enter file name default [index.html]: home.html</code>

Database creation also auto updates main.py and .env

# Project Structure
```sh
project_root/
│   .env
│   .gitignore
│   alembic.ini
│   main.py
│   README.md
│   requirements.txt
│   test.db
│   
├───app
│   │   database.py
│   │   models.py
│           
├───asset
│   ├───css
│   ├───images
│   └───js
├───migrations
│   │   env.py
│   │   README
│   │   
│   ├───versions
│   │   │   b6bbf47f6a8a_create_users_table.py
│           
├───router
│       users.py
│       __init__.py
│       
├───static
│   └───images
│           logo.png
│           
├───templates
│       index.html
│       notfound.html
│       
└───utility
        helper_function.py
```

# Development

If you want to contribute: <br/>
Fork the <a href="https://github.com/build-with-shafikul/shafikul_cli/fork">repo ↗</a> <br/> 
Create a feature branch: git checkout -b feature-name<br/>
Commit your changes: git commit -m "Add feature"<br/>
Push to the branch: git push origin feature-name<br/>
Open a Pull Request

# License
`MIT License`

# Author
Md Shafikul Islam
<a href="https://github.com/build-with-shafikul" target="_blank">GitHub ↗</a>