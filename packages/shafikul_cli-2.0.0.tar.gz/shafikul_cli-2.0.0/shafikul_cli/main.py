import os
import typer
import sys 
from typing import Optional
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from importlib.metadata import version as project_version
from shafikul_cli.utility.install_dependicy import install_dependencies, alembic_init, user_table_autogenerate
from shafikul_cli.utility.ensure_db import ensure_db_in_main
from shafikul_cli.utility.ensure_main import ensure_main_py
from shafikul_cli.utility.env_generate import ensure_env_file
from shafikul_cli.utility.create_html_file import create_html_file
from shafikul_cli.utility.create_file_structure import create_file_structure
from shafikul_cli.utility.create_file_content import file_inside_content
from shafikul_cli.utility.helper_function import edit_migration_env


app = typer.Typer(help="Shafikul CLI for FastAPI")
create_app_cli = typer.Typer(help="Create resources")
app.add_typer(create_app_cli, name="create")
console = Console()

# =========================================================
# 🎨 COLORED BANNER
# =========================================================
def show_banner():
    banner = Text("Shafikul CLI", style="bold cyan")
    subtitle = Text(f"Version v{project_version('shafikul-cli')} • FastAPI Toolkit", style="green")

    panel = Panel.fit(
        Text.assemble(banner, "\n", subtitle),
        border_style="bright_blue",
    )

    console.print(panel)


# =========================================================
# 📘 ABOUT & (--version) COMMAND
# =========================================================
@app.callback(invoke_without_command=True)
def show_option_command(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-V", "-v",
        help="Show CLI version",
        is_eager=True,
    ),
    about: bool = typer.Option(
        False, "--about", "-A", "-a",
        help="Show information about Shafikul CLI",
        is_eager=True,
    ),
):
    if version:
        console.print(f"[bold green]Shafikul CLI v{project_version("shafikul-cli")}[/]")
        raise typer.Exit()
    
    if about:
        show_banner()
        console.print("\n[bold]Author:[/] MD: Shafikul Islam")
        console.print("[bold]Purpose:[/] FastAPI project scaffolding")
        console.print("[bold]GitHub:[/] https://github.com/build-with-shafikul/shafikul_cli")
        console.print("[bold]License:[/] MIT License\n")
        raise typer.Exit()
    
    # 👉 যদি কোনো command না দেয়
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()
    

# =========================================================
# 🛠 CREATE APP
# =========================================================
@create_app_cli.command("app")
def create_app(
    target: Optional[str] = typer.Argument(None, help="router, models, database, html or structure")
):
    show_banner()
   
    if target is None:
        console.print("\n[bold cyan]Options:[/] \n 1: router \n 2: models \n 3: html \n 4: database  \n 5: structure" )
        target = typer.prompt("What do you want to create?")

    # normalize input
    target = str(target).strip().lower()

    # map numeric input to text
    num_map = {
        "1": "router",
        "2": "models",
        "3": "html",
        "4": "database",
        "5": "structure"
    }

    if target in num_map:
        target = num_map[target]

    if target == "router":
        content = """from fastapi import APIRouter

router = APIRouter(
    prefix="/api/users",
    tags=["users"]
)

@router.get("/")
def index():
    return {"message": "Router working"}
    """
        create_file_structure("router", "users.py", content)

        # ✅ NEW: ensure main.py exists and configured
        ensure_main_py()

    elif target == "models":
        content = """from sqlalchemy import Column, Integer, String, Boolean, DateTime
from datetime import datetime
from .database import Base

class User(Base):
    __tablename__ = "users" 

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, index=True)
    password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    slug = Column(String(250), nullable=True)
    
# add more table
"""
        create_file_structure("app", "models.py", content)

    elif target == "database":
        content = """import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

load_dotenv()

engine = create_engine(
    os.getenv("DATABASE_URL"),
    connect_args={
        "ssl": {
            "ca": os.getenv("SSL_PATH")
        }
    },
    pool_pre_ping=True,
    pool_recycle=300,
    pool_size=5,
    max_overflow=10
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
    """
        create_file_structure("app", "database.py", content)

        # ✅ NEW: inject DB into main.py
        ensure_db_in_main()

        # ✅ Create .env
        ensure_env_file()

        # ✅ Auto install deps
        install_dependencies([
            "fastapi",
            "uvicorn[standard]",
            "jinja2",
            "sqlalchemy",
            "python-dotenv"
        ])

       
        console.print(
    Panel(
        "[bold underline cyan]alembic init migrations[/]",
        title="🚀 Run This Command",
        border_style="green"
    ),
    Panel(
        "[bold underline cyan]alembic revision --autogenerate -m 'create users table'[/]",
        title="🚀 Run This Command",
        border_style="green"
    ),
    Panel(
        "[bold underline cyan]uvicorn main:app --reload[/]",
        title="🌐 Running Server",
        border_style="green"
    )
)

    elif target == "html":
        file_name = typer.prompt("Enter file name default", default="index.html").strip()
        if file_name == 'index.html':
            file_content = """
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shafikul FastAPI App</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Tailwind config for custom transitions or dark mode
        tailwind.config = {
            darkMode: 'class',
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>

<body class="bg-slate-100 dark:bg-slate-950 transition-colors duration-500">

    <div class="fixed inset-0 -z-10 overflow-hidden">
        <div class="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-purple-500/30 rounded-full blur-[120px] animate-pulse"></div>
        <div class="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-blue-500/30 rounded-full blur-[120px]"></div>
    </div>

    <!-- Main Container -->
    <div class="min-h-screen flex flex-col items-center justify-center p-6">
        
        <!-- Dark Mode Toggle -->
        <button onclick="document.documentElement.classList.toggle('dark')" class="absolute top-5 right-5 p-2 bg-white/20 dark:bg-gray-800/30 backdrop-blur-md border border-white/20 dark:border-white/10 rounded-full shadow-lg hover:scale-110 transition-transform">
            <span class="dark:hidden">🌙</span>
            <span class="hidden dark:inline">☀️</span>
        </button>

        <!-- Card -->
        <div class="w-full max-w-md p-8 md:p-10 rounded-3xl
                    bg-white/30 dark:bg-white/5 
                    backdrop-blur-xl backdrop-saturate-150
                    border border-white/40 dark:border-white/10
                    shadow-[0_8px_32px_0_rgba(31,38,135,0.2)]
                    text-center transform transition-all hover:shadow-2xl">
            
            <!-- Icon And Logo -->
            <div class="inline-flex p-3 rounded-2xl bg-indigo-500/20 mb-6">
                <svg class="w-10 h-10 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
            </div>

            <h1 class="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-300 dark:to-purple-300 bg-clip-text text-transparent mb-4">
                Shafikul FastAPI
            </h1>
            
            <p class="text-slate-600 dark:text-slate-300 mb-8 leading-relaxed">
                Build blazing fast APIs with the power of Python and modern UI design. High performance, easy to code, ready for production.
            </p>

            <div class="space-y-4">
                <a href="#" class="block w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-lg shadow-indigo-500/30 transition-all hover:-translate-y-1">
                    Get Started
                </a>
                
                <a href="#" class="block w-full py-3 px-6 bg-white/50 dark:bg-white/10 hover:bg-white/80 dark:hover:bg-white/20 text-slate-800 dark:text-white font-semibold rounded-xl border border-white/20 transition-all">
                    Documentation
                </a>
            </div>

            <!-- Status -->
            <div class="mt-8 flex justify-center gap-4">
                <div class="flex items-center gap-2 px-3 py-1 bg-green-500/20 rounded-full">
                    <span class="w-2 h-2 bg-green-500 rounded-full animate-ping"></span>
                    <span class="text-xs font-medium text-green-700 dark:text-green-400">API Live</span>
                </div>
                <div class="flex items-center gap-2 px-3 py-1 bg-blue-500/20 rounded-full text-blue-700 dark:text-blue-400">
                    <span class="text-xs font-medium italic underline">v1.0.0</span>
                </div>
            </div>
        </div>

        <p class="mt-8 text-slate-500 dark:text-slate-500 text-sm">
            © 2024 Shafikul. Made with ❤️
        </p>
    </div>

</body>
</html>
"""
        else:
            file_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shafikul FastAPI APP</title>
</head>
<body>
    <h1>Hello User</h1>
</body>
</html>
"""
        create_html_file(file_name, file_content)

    elif target == "structure":
        folders = [
            "app",
            "asset/css",
            "asset/images",
            "asset/js",
            "static/images",
            "router",
            "templates",
            "utility"
        ]

        files = [
            ".env",
            ".env.example",
            ".gitignore",
            "requirements.txt",
            "README.md",
            "main.py",
            "app/database.py",
            "app/models.py",
            "asset/css/style.css",
            "asset/images/icon.png",
            "static/images/logo.png",
            "asset/js/script.js",
            "router/users.py",
            "templates/index.html",
            "templates/notfound.html",
            "utility/helper_function.py"
        ]

        for folder in folders:
            console.print("[bold green]Creating Folder: [/] " + folder )
            os.makedirs(folder, exist_ok=True)

        for file in files:
            file_inside_content(file)

        console.print("\n[green]Project structure created successfully![/]")

        # ==========================================
        # Install Dependices
        # ==========================================
        install_dependencies([
            "python-dotenv",
            "fastapi",
            "uvicorn[standard]",
            "jinja2",
            "sqlalchemy"
        ])

        # ==========================================
        # sqlalchemy alembic initionalize
        # ==========================================
        alembic_init()

        # ==========================================
        # sqlalchemy Migration Env add .env file database url
        # ==========================================
        edit_migration_env()

        # ==========================================
        # User Table Create
        # ==========================================
        user_table_autogenerate()

        console.print(
   
    Panel(
        "[bold underline cyan]uvicorn main:app --reload[/]",
        title="🌐 Running Server",
        border_style="green"
    )
)


    else:
        console.print("[red]Please Provide Correct Name![/]")


if __name__ == "__main__":
    app()