from importlib.metadata import version
import shutil, os
from importlib.resources import files
from rich.console import Console


console = Console()

# ==========================================
# get version to pyproject.toml
# ==========================================
def get_version():
    return version("shafikul-cli")


# ==========================================
# .env file create
# ==========================================
def env(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
DATABASE_URL="sqlite:///./test.db"  
ALLOW_ORIGIN=[*]
ALLOW_METHODS=[*]
ALLOW_HEADERS=[*]
                    
""")


# ==========================================
# gitignore file create
# ==========================================
def gitignore(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
__pycache__/
.env
dist/
.venv/
alembic/
alembic.ini
""")
  
            
# ==========================================
# requirements.txt file create
# ==========================================
def requirements(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
sqlalchemy
fastapi
jinja2
uvicorn[standerd]
python-dotenv
""")


# ==========================================
# README.md file create
# ==========================================
def readme(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
# Shafikul CLI
""")


# ==========================================
# main.py file create
# ==========================================
def mainfile(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
import os
from fastapi import FastAPI,Request
from fastapi.responses import HTMLResponse,JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException
from dotenv import load_dotenv
from pathlib import Path
from router import users

load_dotenv()
app = FastAPI()

# =================================
# Add Middleware
# =================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOW_ORIGIN"),
    allow_credentials=True,
    allow_methods=os.getenv("ALLOW_METHODS"),
    allow_headers=os.getenv("ALLOW_HEADERS")
)

# =================================
# Include Router
# =================================
app.include_router(users.router)

# =================================
# Template Dir & Static Dir
# =================================
BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=BASE_DIR / "templates")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

# =================================
# 404 Route 
# =================================
@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 404:
        return templates.TemplateResponse(
            'notfound.html',
            {'request': request},
            status_code=404
        )
    return JSONResponse(
         status_code=exc.status_code,
        content={"detail": exc.detail},
    )

# =================================
# Route Start ... 
# =================================
@app.get('/', response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )

""")


# ==========================================
# app/database file create
# ==========================================
def database(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

engine = create_engine(
    DATABASE_URL, 
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    connect_args={"check_same_thread": False} # sqlite connect er jonno eita lagbe
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

Base = declarative_base()

# dependency (FastAPI use)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
""")


# ==========================================
# app/models.py file create
# ==========================================
def models(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
from sqlalchemy import Column,  Integer, String, Boolean, DateTime
from datetime import datetime
from .database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

# Add More Table ....

""")


# ==========================================
# static/images/logo.png file create
# ==========================================
def static_logo(file_nm: str):
    logo_path = files("shafikul_cli.asset").joinpath("logo.png")
    shutil.copy(logo_path, file_nm)

# ==========================================
# router/users.py file create
# ==========================================
def users_route(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
from fastapi import APIRouter

router = APIRouter(
    prefix="/api/users",
    tags=["users"]
)

@router.get("/")
def index():
    return {"message": "Router working"}

""")


# ==========================================
# templates/index.html file create
# ==========================================
def index(file_nm: str):
    current_version = get_version()
    with open(file_nm, "w", encoding="utf-8") as f:
            f.write(f"""
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shafikul FastAPI App {current_version} </title>
    <link rel="shortcut icon" href="{{{{ url_for('static', path='images/logo.png') }}}}" type="image/x-icon">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Tailwind config for custom transitions or dark mode
        tailwind.config = {{{{
          darkMode: 'class',
        }}}}
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap');
        body {{{{
          font-family: 'Plus Jakarta Sans', sans-serif; 
        }}}}
    </style>
</head>

<body class="bg-slate-100 dark:bg-slate-950 transition-colors duration-500">

    <div class="fixed inset-0 -z-10 overflow-hidden">
        <div class="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-purple-500/30 rounded-full blur-[120px] animate-pulse"></div>
        <div class="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-blue-500/30 rounded-full blur-[120px]"></div>
    </div>

    <!-- Main Container -->
    <div class="min-h-screen flex flex-col items-center justify-center p-6">
        
        <!-- Dark Mode Toggle -->
        <button onclick="document.documentElement.classList.toggle('dark')" class="absolute top-5 right-5 p-2 bg-white/20 dark:bg-gray-800/30 backdrop-blur-md border border-white/20 dark:border-white/10 rounded-full shadow-lg hover:scale-110 transition-transform">
            <span class="dark:hidden">🌙</span>
            <span class="hidden dark:inline">☀️</span>
        </button>

        <!-- Card -->
        <div class="w-full max-w-md p-8 md:p-10 rounded-3xl
                    bg-white/30 dark:bg-white/5 
                    backdrop-blur-xl backdrop-saturate-150
                    border border-white/40 dark:border-white/10
                    shadow-[0_8px_32px_0_rgba(31,38,135,0.2)]
                    text-center transform transition-all hover:shadow-2xl">
            
            <!-- Icon And Logo -->
            <div class="inline-flex p-3 rounded-2xl bg-indigo-500/20 mb-6">
                <svg class="w-10 h-10 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
            </div>

            <h1 class="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-300 dark:to-purple-300 bg-clip-text text-transparent mb-4">
                Shafikul FastAPI
            </h1>
            
            <p class="text-slate-600 dark:text-slate-300 mb-8 leading-relaxed">
                Build blazing fast APIs with the power of Python and modern UI design. High performance, easy to code, ready for production.
            </p>

            <div class="space-y-4">
                <a href="#" class="block w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-lg shadow-indigo-500/30 transition-all hover:-translate-y-1">
                    Get Started
                </a>
                
                <a href="#" class="block w-full py-3 px-6 bg-white/50 dark:bg-white/10 hover:bg-white/80 dark:hover:bg-white/20 text-slate-800 dark:text-white font-semibold rounded-xl border border-white/20 transition-all">
                    Documentation
                </a>
            </div>

            <!-- Status -->
            <div class="mt-8 flex justify-center gap-4">
                <div class="flex items-center gap-2 px-3 py-1 bg-green-500/20 rounded-full">
                    <span class="w-2 h-2 bg-green-500 rounded-full animate-ping"></span>
                    <span class="text-xs font-medium text-green-700 dark:text-green-400">API Live</span>
                </div>
                <div class="flex items-center gap-2 px-3 py-1 bg-blue-500/20 rounded-full text-blue-700 dark:text-blue-400">
                    <span class="text-xs font-medium italic underline">v1.0.0</span>
                </div>
            </div>
        </div>

        <p class="mt-8 text-slate-500 dark:text-slate-500 text-sm">
            © 2024 Shafikul. Made with ❤️
        </p>
    </div>

</body>
</html>
""")


# ==========================================
# templates/notfound.html file create
# ==========================================
def notfound(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Not Found</title>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Roboto:700');

:root {
  --color-main: #004880;
}

html, body, .wrapper {
  position: relative;
  
  width: 100%;
  height: 100%;
  
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

* {
  box-sizing: border-box;
}

.composition {
  position: relative;
  
  width: 750px;
  height: 400px;
  
  background-color: var(--color-main);
  background-image: linear-gradient(to left, #072e61, #004880);
  
  overflow: hidden;
}

.layer-0 {
  position: absolute;
  z-index: 10;
}
.layer-1 {
  position: absolute;
  z-index: 15;
}
.layer-2 {
  position: absolute;
  z-index: 20;
}

.shelf {
  position: absolute;
  top: 150px;
  left: 250px;
}
.shelf__side_left {
  position: absolute;
  top: 0;
  left: 0;
  
  width: 500px;
  height: 60px;
  
  background-color: #cdfffa;
  
  transform: skewY(-25deg);
}
.shelf__side_front {
  position: absolute;
  top: 137px;
  left: 0;
  
  width: 70px;
  height: 60px;
  
  background-color: #9dfbf3;
  background-image: linear-gradient(160deg, #84fff2, #2f7fb2);
  
  border: 1px solid rgba(47, 127, 178, 0.5);
  
  transform: skewY(30deg);
}
.shelf__side_bottom {
  position: absolute;
  top: 43px;
  left: 36px;
  
  width: 500px;
  height: 73px;
  
  background-color: #7adbd5;
  
  transform: skewY(-25deg) skewX(44deg);
}
.shelf__side_right {
  position: absolute;
  top: 42px;
  left: 70px;
  
  width: 500px;
  height: 60px;
  
  background-color: #0b2f6c;
  background-image: linear-gradient(0deg, #0b2f6c, #16598b);
  
  transform: skewY(-25deg);
}

.shelf__handle_top {
  position: absolute;
  top: 144px;
  left: 17px;
  
  width: 30px;
  height: 7px;
  
  background-color: #5ac8d3;
  
  transform: skewY(30deg) skewX(-50deg)
}
.shelf__handle_front {
  position: absolute;
  top: 149px;
  left: 13px;
  
  width: 30px;
  height: 10px;
  
  background-color: #71e7e4;
  border: 1px solid rgba(47, 127, 178, 0.5);
  
  transform: skewY(30deg);
}
.shelf__handle_right {
  position: absolute;
  top: 155px;
  left: 43px;
  
  width: 6px;
  height: 10px;
  
  background-color: #287caa;
  
  transform: skewY(-30deg);
}

.shadow {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  
  width: 150px;
  height: 100%;
  
  background-image: linear-gradient(to right, rgba(1, 20, 61, 0), rgba(1, 20, 61, 0.8) 65%, rgba(1, 20, 61, 1));
}

.case {
  position: absolute;
  
  transform: translateY(0);
  transition: .3s transform ease-in;
}
.case:hover {
  transform: translateY(-5px);
}
.case_1 {
  top: -85px;
  right: -470px;
}
.case_2 {
  top: -82px;
  right: -463px;
}
.case_3 {
  top: -79px;
  right: -456px;
}
.case_4 {
  top: -76px;
  right: -449px;
}
.case_5 {
  top: -73px;
  right: -442px;
}
.case_6 {
  top: -70px;
  right: -435px;
}
.case_7 {
  top: -67px;
  right: -428px;
}
.case_8 {
  top: -63px;
  right: -421px;
}
.case_9 {
  top: -59px;
  right: -414px;
}
.case_10 {
  top: -56px;
  right: -407px;
}
.case_11 {
  top: -53px;
  right: -400px;
}
.case_12 {
  top: -49px;
  right: -393px;
}
.case_13 {
  top: -46px;
  right: -386px;
}
.case_14 {
  top: -43px;
  right: -379px;
}
.case_15 {
  top: -39px;
  right: -372px;
}
.case_16 {
  top: -36px;
  right: -365px;
}
.case_17 {
  top: -33px;
  right: -358px;
}
.case_18 {
  top: -29px;
  right: -351px;
}
.case_19 {
  top: -26px;
  right: -344px;
}
.case_20 {
  top: -23px;
  right: -337px;
}
.case_21 {
  top: -19px;
  right: -330px;
}
.case_22 {
  top: -16px;
  right: -323px;
}
.case_23 {
  top: -13px;
  right: -316px;
}
.case_24 {
  top: -9px;
  right: -309px;
}
.case_25 {
  top: -6px;
  right: -302px;
}
.case_26 {
  top: -3px;
  right: -295px;
}
.case_27 {
  top: 1px;
  right: -288px;
}
.case_28 {
  top: 4px;
  right: -281px;
}
.case_29 {
  top: 7px;
  right: -274px;
}
.case_30 {
  top: 11px;
  right: -267px;
}
.case_31 {
  top: 14px;
  right: -260px;
}
.case_32 {
  top: 17px;
  right: -253px;
}
.case_33 {
  top: 20px;
  right: -246px;
}
.case_34 {
  top: 24px;
  right: -239px;
}
.case_35 {
  top: 27px;
  right: -232px;
}
.case_36 {
  top: 30px;
  right: -225px;
}
.case_37 {
  top: 33px;
  right: -218px;
}
.case_38 {
  top: 37px;
  right: -211px;
}
.case_39 {
  top: 40px;
  right: -204px;
}
.case_40 {
  top: 43px;
  right: -197px;
}
.case_41 {
  top: 46px;
  right: -190px;
}
.case_42 {
  top: 49px;
  right: -183px;
}
.case_43 {
  top: 53px;
  right: -176px;
}
.case_44 {
  top: 56px;
  right: -169px;
}
.case_45 {
  top: 59px;
  right: -162px;
}
.case_46 {
  top: 62px;
  right: -155px;
}
.case_47 {
  top: 65px;
  right: -148px;
}

.case__front {
  position: absolute;
  top: 3px;
  left: 0;
  
  width: 70px;
  height: 55px;
  
  background-color: #9d7f63;
  
  transform: skewY(25deg);
}
.case__label {
  position: absolute;
  top: -12px;
  left: 5px;
  
  width: 10px;
  height: 7px;
  
  background-color: #9d7f63;
  
  transform: skewY(25deg);
}
.case__label_left {
  top: -12px;
  left: 5px;
}
.case__label_right {
  top: 12px;
  left: 55px;
}
.case__top {
  position: absolute;
  top: 0;
  left: 2px;
  
  width: 70px;
  height: 4px;
  
  background-image: linear-gradient(to top, #e9eceb, #a3bab4 50%, #e9eceb);
  
  transform: skewY(25deg) skewX(-45deg);
}
.case__right {
  position: absolute;
  top: 18px;
  left: 69px;
  
  width: 5px;
  height: 55px;
  
  background-image: linear-gradient(to left, #e9eceb, #a3bab4 50%, #e9eceb);
  
  transform: skewY(-25deg);
}
.case__number {
  position: absolute;
  top: 41px;
  left: 10px;
  
  color: #7c664e;
  font-size: 8px;
  
  transform-origin: top left;
  transform: rotate(-66deg) skewY(-25deg);
}

.glow {
  position: absolute;
}
.glow__bottom {
  position: absolute;
  top: 60px;
  left: 5px;
  
  width: 135px;
  height: 120px;
  
  background-image: linear-gradient(to top, rgba(132, 255, 242, 1), rgba(132, 255, 242, 1) 30%, rgba(132, 255, 242, 0));
  
  transform: perspective(120px) rotateX(-20deg);
}
.glow__top {
  position: absolute;
  top: -25px;
  left: 7px;
  
  width: 130px;
  height: 180px;
  
  background-image: linear-gradient(to top, rgba(132, 255, 242, 1), rgba(132, 255, 242, 1) 20%, rgba(132, 255, 242, 0));
  
  transform: perspective(150px) rotateX(-20deg);
}

.glow__ball {
  position: absolute;
  top: 0;
  left: 0;
  
  width: 10px;
  height: 10px;
  
  border-radius: 10px;
  background-color: #83fff2;
  
  transform: translateY(160px);
}
.glow__ball_1 {  
  animation: 5s fadeUp infinite;
  animation-delay: .5s;
}
.glow__ball_2 {
  left: 10px;
  
  width: 5px;
  height: 5px;
  
  animation: 4s fadeUp infinite;
  animation-delay: .8s;
}
.glow__ball_3 {
  left: 24px;
  
  width: 15px;
  height: 15px;
  
  animation: 9s fadeUp infinite;
  animation-delay: .65s;
}
.glow__ball_4 {
  left: 34px;
  
  width: 8px;
  height: 8px;
  
  animation: 7s fadeUp infinite;
  animation-delay: .5s;
}
.glow__ball_5 {
  left: 57px;
  
  width: 14px;
  height: 14px;
  
  animation: 7s fadeUp infinite;
  animation-delay: .9s;
}
.glow__ball_6 {
  left: 78px;
  
  width: 11px;
  height: 11px;
  
  animation: 3s fadeUp infinite;
  animation-delay: .3s;
}
.glow__ball_7 {
  left: 91px;
  
  width: 13px;
  height: 13px;
  
  animation: 8s fadeUp infinite;
  animation-delay: .77s;
}
.glow__ball_8 {
  left: 105px;
  
  width: 7px;
  height: 7px;
  
  animation: 6s fadeUp infinite;
  animation-delay: .4s;
}
.glow__ball_9 {
  left: 113px;
  
  width: 8px;
  height: 8px;
  
  animation: 4s fadeUp infinite;
  animation-delay: .6s;
}
.glow__ball_10 {
  left: 120px;
  
  width: 4px;
  height: 4px;
  
  animation: 9s fadeUp infinite;
  animation-delay: .92s;
}

.numbers {
  position: absolute;
  top: 0;
  left: 122px;
  
  color: #fff;
  font-family: 'Roboto', sans-serif;
  font-size: 200px;
  
  display: flex;
}
.numbers__item {
  margin: 0 10px;
  
  animation: 5s bounceUpDown infinite;
}
.numbers__item_1 {
  animation-delay: .3s;
}
.numbers__item_2 {
  animation: 5.4s bounceUpDown infinite;
  animation-delay: .5s;
}
.numbers__item_3 {
  animation-delay: .3s;
}

@keyframes fadeUp {
  0% {
    transform: translateY(160px);
    opacity: 1;
  }
  60% {
    opacity: 1;
  }
  100% {
    transform: translateY(-10px);
    opacity: 0;
  }
}
@keyframes bounceUpDown {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(50px);
  }
}


@media screen and (max-width: 800px) {
  .composition {
    transform: scale(0.8);
  }
}

@media screen and (max-width: 700px) {
  .composition {
    transform: scale(0.7);
  }
}

@media screen and (max-width: 600px) {
  .composition {
    transform: scale(0.6);
  }
}

@media screen and (max-width: 500px) {
  .composition {
    transform: scale(0.5);
  }
}

@media screen and (max-width: 400px) {
  .composition {
    transform: scale(0.4);
  }
}

@media screen and (max-width: 300px) {
  .composition {
    transform: scale(0.3);
  }
}
    </style>
</head>
<body>
    <div class="wrapper">
  <div class="composition">
    <div class="layer-0 shelf">
      <div class="shelf__side_left"></div>
      <div class="shelf__side_bottom"></div>
      
      <div class="case case_1">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_2">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_3">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_4">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_5">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_6">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_7">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_8">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_9">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_10">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_11">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_12">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_13">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_14">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_15">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_16">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_17">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_18">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_19">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_20">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_21">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_22">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_23">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_24">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_25">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_26">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_27">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_28">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_29">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_30">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_31">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_32">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_33">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_34">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_35">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_36">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_37">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_38">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_39">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_40">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_41">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_42">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_43">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_44">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_45">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_46">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_right"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      <div class="case case_47">
        <div class="case__front"></div>
        <div class="case__top"></div>
        <div class="case__label case__label_left"></div>
        <div class="case__right"></div>
        <div class="case__number">
          №2428506
        </div>
      </div>
      
      <div class="glow">
        <div class="glow__bottom"></div>
        <div class="glow__top"></div>
        <div class="glow__ball glow__ball_1"></div>
        <div class="glow__ball glow__ball_2"></div>
        <div class="glow__ball glow__ball_3"></div>
        <div class="glow__ball glow__ball_4"></div>
        <div class="glow__ball glow__ball_5"></div>
        <div class="glow__ball glow__ball_6"></div>
        <div class="glow__ball glow__ball_7"></div>
        <div class="glow__ball glow__ball_8"></div>
        <div class="glow__ball glow__ball_9"></div>
        <div class="glow__ball glow__ball_10"></div>
        
      </div>
      
      <div class="shelf__side_front"></div>
      <div class="shelf__side_right"></div>
      
      <div class="shelf__handle_top"></div>
      <div class="shelf__handle_front"></div>
      <div class="shelf__handle_right"></div>
    </div>
    <div class="layer-1 shadow"></div>
    <div class="layer-2 numbers">
      <div class="numbers__item numbers__item_1">4</div>
      <div class="numbers__item numbers__item_2">0</div>
      <div class="numbers__item numbers__item_3">4</div>
    </div>
  </div>
</div>
</body>
</html>
""")


# ==========================================
# utility/helper_function.py file create
# ==========================================
def helper_function(file_nm: str):
    with open(file_nm, "w" ,encoding="utf-8") as f:
            f.write("""
import os
""")


# # ==========================================
# # ___ file create
# # ==========================================
# def name(file_nm: str):
#     with open(file_nm, "w" ,encoding="utf-8") as f:
#             f.write("""

# """)












# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------

# ==========================================
# change migration/env.py file database url
# ==========================================
def edit_migration_env():
    file_path = os.path.join("migrations", "env.py")

    if not os.path.exists(file_path):
        print(f"Error: {file_path} not found.")
        return

    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    new_lines = []
    import_added = False
    load_dotenv_added = False
    db_url_added = False

    for line in lines:
        stripped = line.strip()

        # ১. ইম্পোর্ট অ্যাড করা (একবারই হবে)
        if not import_added and ("from alembic import context" in stripped or stripped.startswith("import")):
            new_lines.append("import os\n")
            new_lines.append("from app.database import Base\n")
            new_lines.append("from app import models\n")
            new_lines.append("from dotenv import load_dotenv\n\n")
            import_added = True

        # ২. config = context.config লাইনের আগে load_dotenv() অ্যাড করা
        if "config = context.config" in stripped and not load_dotenv_added:
            new_lines.append("load_dotenv()\n\n")
            load_dotenv_added = True

        # ৩. target_metadata = None লাইনটি রিপ্লেস করা
        if "target_metadata = None" in stripped:
            new_lines.append("target_metadata = Base.metadata\n")
            continue  # এটা দিলে নিচের new_lines.append(line) রান হবে না, ফলে পুরনো লাইনটি বাদ যাবে

        # মূল লাইনটি অ্যাড করা (যদি উপরের 'continue' হিট না করে)
        new_lines.append(line)

        # ৪. config = context.config লাইনের পরে DATABASE_URL সেট করা
        if "config = context.config" in stripped and not db_url_added:
            new_lines.append('config.set_main_option("sqlalchemy.url", os.getenv("DATABASE_URL"))\n\n')
            db_url_added = True

    with open(file_path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

    console.print("[bold cyan]Created Dynamic env file. [/]")