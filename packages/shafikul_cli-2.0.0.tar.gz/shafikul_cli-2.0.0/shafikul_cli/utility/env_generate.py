import os
from rich.console import Console

console = Console()

# =========================================================
# env generator
# =========================================================
def ensure_env_file():
    env_file = ".env"

    required_vars = {
        "DATABASE_URL": "postgresql://user:password@localhost:5432/dbname",
        "SSL_PATH": "./certs/ca.pem",
    }

    # ❌ File doesn't exist → create full
    if not os.path.exists(env_file):
        with open(env_file, "w") as f:
            f.write("# Database config\n")
            for key, value in required_vars.items():
                f.write(f"{key}={value}\n")
        console.print("[green]Created .env file[/]")
        return

    # ✅ File exists → read current vars
    with open(env_file, "r") as f:
        lines = f.readlines()

    existing_keys = set()
    for line in lines:
        if "=" in line and not line.strip().startswith("#"):
            existing_keys.add(line.split("=")[0].strip())

    # find missing vars
    missing = {
        k: v for k, v in required_vars.items() if k not in existing_keys
    }

    if not missing:
        console.print("[yellow].env already up-to-date[/]")
        return

    # append missing vars
    with open(env_file, "a") as f:
        f.write("\n# Added by Shafikul CLI\n")
        for key, value in missing.items():
            f.write(f"{key}={value}\n")

    console.print("[cyan]Updated .env with missing variables[/]")
