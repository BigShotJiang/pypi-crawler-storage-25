from rich.console import Console
from . import helper_function as Hfn
     
console = Console()

def file_inside_content(file_name: str):
    console.print("[bold magenta]Creating File: [/] " + file_name )
    if file_name == '.env':
        Hfn.env(file_name)

    if file_name == '.gitignore':
        Hfn.gitignore(file_name)
    
    if file_name == 'requirements.txt':
        Hfn.requirements(file_name)
    
    if file_name == 'README.md':
        Hfn.readme(file_name)

    if file_name == 'main.py':
        Hfn.mainfile(file_name)
    
    if file_name == 'app/database.py':
        Hfn.database(file_name)
    
    if file_name == 'app/models.py':
        Hfn.models(file_name)
    
    if file_name == 'router/users.py':
        Hfn.users_route(file_name)
    
    if file_name == 'templates/index.html':
        Hfn.index(file_name)
    
    if file_name == 'templates/notfound.html':
        Hfn.notfound(file_name)
    
    if file_name == 'utility/helper_function.py':
        Hfn.helper_function(file_name)
    
    if file_name == 'static/images/logo.png':
        Hfn.static_logo(file_name)
    
    # if file_name == 'main':
    #     pass
    