import sys
from rich.panel import Panel
import subprocess
from rich.console import Console


console = Console()

# =========================================================
# 🌐 package install for dependicy
# =========================================================
def install_dependencies(packages: list[str]):
    console.print("[cyan]🌐 Installing dependencies...[/]")
    for pkg in packages:
        try:
            subprocess.call([sys.executable, "-m", "pip", "install", pkg])
            console.print(f"[green]Package initialized successfully -> [bold cyan]{pkg}[/] [/]")

        except subprocess.CalledProcessError as e:
            console.print(f"[red]Failed to initialize {pkg}: {e}[/]")

# =========================================================
# sqlalchemy init command run
# =========================================================
def alembic_init():
    console.print(
        Panel(
            "[bold underline cyan]alembic init migrations[/]",
            title="🚀 Alembic Initialize",
            border_style="green"
        )
    )

    try:
        subprocess.run(
            ["alembic", "init", "migrations"],
            check=True
        )
        console.print("[green]Alembic initialized successfully[/]")
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Failed to initialize Alembic: {e}[/]")


# =========================================================
# Create User Table
# =========================================================
def user_table_autogenerate():
    console.print(
        Panel(
            "[bold underline cyan]alembic revision --autogenerate -m 'create users table'[/]",
            title="🚀 Creating User Table ...",
            border_style="green"
        )
    )

    try:
        subprocess.run(
            ["alembic", "revision", "--autogenerate", "-m", "create users table"],
            check=True
        )

        console.print("[green]Migrate Table In DB[/]")
        subprocess.run(
            ["alembic", "upgrade", "head"],
            check=True
        )

        console.print("[green]User Table Create successfully[/]")
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Failed to Create User Table: {e}[/]")
