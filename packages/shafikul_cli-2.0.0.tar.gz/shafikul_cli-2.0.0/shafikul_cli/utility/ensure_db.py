import os
from rich.console import Console

console = Console()


def ensure_db_in_main():
    main_file = "main.py"

    import_block = """from fastapi import Depends
from sqlalchemy.orm import Session
from app import database

"""

    db_block = """def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

db: Session = Depends(get_db)

"""

    # ❌ main.py নেই → create minimal
    if not os.path.exists(main_file):
        with open(main_file, "w") as f:
            f.write(import_block + db_block)
        console.print("[green]Created main.py with DB dependency[/]")
        return

    with open(main_file, "r") as f:
        existing = f.read()

    updated = existing

    # add import if missing
    if "from app import database" not in existing:
        updated = import_block + updated
        console.print("[cyan]Added DB imports to main.py[/]")

    # add get_db if missing
    if "def get_db()" not in existing:
        updated = updated + "\n\n" + db_block
        console.print("[cyan]Added get_db() to main.py[/]")

    # write back only if changed
    if updated != existing:
        with open(main_file, "w") as f:
            f.write(updated)
    else:
        console.print("[yellow]main.py already has DB setup[/]")

