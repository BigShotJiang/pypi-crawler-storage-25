import os
from pathlib import Path
from rich.console import Console

console = Console()

# =========================================================
# 📁 FILE GENERATOR
# =========================================================
def create_file_structure(dir_name: str, file_name: str, content: str = ""):
    os.makedirs(dir_name, exist_ok=True)

    init_path = os.path.join(dir_name, "__init__.py")
    if not os.path.exists(init_path):
        Path(init_path).touch()
        console.print(f"[cyan]Created:[/] {init_path}")

    file_path = os.path.join(dir_name, file_name)
    if not os.path.exists(file_path):
        with open(file_path, "w") as f:
            f.write(content)
        console.print(f"[green]Created:[/] {file_path}")
    else:
        console.print(f"[yellow]Already exists:[/] {file_path}")

