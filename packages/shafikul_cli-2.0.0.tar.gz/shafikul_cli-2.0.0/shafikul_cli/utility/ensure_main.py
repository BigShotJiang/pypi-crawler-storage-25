import os
from rich.console import Console

console = Console()


#=========================================================
# check main.py file a code add 
#=========================================================
def ensure_main_py():
    main_file = "main.py"

    new_code = """from fastapi import FastAPI,Request
from fastapi.responses import HTMLResponse,JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException
from pathlib import Path
from router import users

app = FastAPI()

# =================================
# Add Middleware
# =================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# =================================
# Include Router
# =================================
app.include_router(users.router)

# =================================
# Template Dir & Static Dir
# =================================
BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=BASE_DIR / "templates")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

# =================================
# 404 Route 
# =================================
@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 404:
        return JSONResponse(
            status_code=404,
            content={"error": "Resource Not Found", "details": exc.detail}
        )
        # return template.TemplateResponse(
        #     '404.html',
        #     {'request': request},
        #     status_code=404
        # )
    return JSONResponse(
         status_code=exc.status_code,
        content={"detail": exc.detail},
    )

# =================================
# Route Start ... 
# =================================
@app.get('/', response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )

"""

    # ❌ main.py নেই → create
    if not os.path.exists(main_file):
        with open(main_file, "w") as f:
            f.write(new_code)
        console.print("[green]Created main.py with FastAPI setup[/]")
        return

    # ✅ আছে → read existing content
    with open(main_file, "r") as f:
        existing = f.read()

    # duplicate check
    if "app = FastAPI()" in existing:
        console.print("[yellow]main.py already configured[/]")
        return

    # prepend new code
    with open(main_file, "w") as f:
        f.write(new_code + existing)

    console.print("[cyan]Updated main.py (prepended FastAPI setup)[/]")

