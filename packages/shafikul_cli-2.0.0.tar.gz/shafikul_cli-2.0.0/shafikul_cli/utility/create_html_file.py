
from pathlib import Path
from rich.console import Console
console = Console()

def create_html_file(file_name: str, content: str):
    """
    Create or update an HTML file dynamically.
    
    Args:
        file_name (str): Name of the file to create (e.g., 'index.html')
        content (str): HTML content to write into the file
    """
    # template folder path
    templates_dir = Path("templates")  # root relative path
    target_file = templates_dir / file_name

    # Static Folder Create
    static_dir = Path("static")
    static_dir.mkdir(parents=True, exist_ok=True)

    # ✅ Create templates folder if missing
    if not templates_dir.exists():
        templates_dir.mkdir(parents=True, exist_ok=True)
        console.print(f"[cyan]Created folder:[/] {templates_dir}")
    else:
        console.print(f"[yellow]Folder already exists:[/] {templates_dir}")

    # ✅ Create or update the HTML file
    if not target_file.exists():
        target_file.touch()
        console.print(f"[cyan]Created file:[/] {target_file}")
    else:
        console.print(f"[yellow]File already exists, updating:[/] {target_file}")

    # Write the HTML content
    target_file.write_text(content, encoding="utf-8")
    console.print(f"[green]HTML content written successfully to {target_file}![/]")
