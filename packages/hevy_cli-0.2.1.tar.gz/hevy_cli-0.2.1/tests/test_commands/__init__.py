"""Command tests."""
