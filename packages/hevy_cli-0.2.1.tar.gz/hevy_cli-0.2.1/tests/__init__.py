"""Tests for hevy-cli."""
