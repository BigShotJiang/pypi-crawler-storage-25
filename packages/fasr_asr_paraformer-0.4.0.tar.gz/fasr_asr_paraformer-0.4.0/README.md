# fasr-asr-paraformer

基于 [Paraformer](https://github.com/modelscope/FunASR) 的语音识别模型插件，为 fasr 提供离线 ASR 能力，支持带时间戳输出和热词偏置。

## 安装

```bash
pip install fasr-asr-paraformer
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `paraformer` | `ParaformerForASR` | `iic/speech_paraformer-large-vad-punc_asr_nat-zh-cn-16k-common-vocab8404-pytorch` | 离线 Paraformer，输出带时间戳的 token |
| `seaco_paraformer` | `SeacoParaformerForASR` | `iic/speech_seaco_paraformer_large_asr_nat-zh-cn-16k-common-vocab8404-pytorch` | 支持热词偏置的 Paraformer |

模型权重默认从 ModelScope 自动下载。

## 使用方式

### 在流水线中使用

```python
from fasr import AudioPipeline

# 标准 Paraformer
pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="paraformer")
    .add_pipe("sentencizer", model="ct_transformer")
)

audio = pipeline("example.wav")
print(audio.text)
```

### 热词识别

```python
pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="seaco_paraformer")
    .add_pipe("sentencizer", model="ct_transformer")
)

audio = pipeline("meeting.wav", hotwords=["Paraformer", "语音识别"])
```

### 单独使用模型

```python
from fasr.config import registry

model = registry.asr_models.get("paraformer")()
model.from_checkpoint()

tokens = model.transcribe([waveform_array], sample_rate=16000)
for tok in tokens[0]:
    print(f"{tok.text} [{tok.start_ms}-{tok.end_ms}ms]")
```

## `from_checkpoint` 参数

### ParaformerForASR（`paraformer`）

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | `None`（自动下载） | 模型权重目录 |
| `disable_update` | `bool` | `True` | 禁用 FunASR 自动更新检查 |
| `disable_log` | `bool` | `True` | 禁用 FunASR 日志输出 |
| `disable_pbar` | `bool` | `True` | 禁用进度条 |

### SeacoParaformerForASR（`seaco_paraformer`）

参数与 `ParaformerForASR` 相同。

额外 `**kwargs` 会直接传递给 `funasr.AutoModel()`。

### `transcribe` 额外参数

| 参数 | 说明 |
|---|---|
| `sample_rate` | 输入音频采样率，默认 `16000` |
| `hotwords`（仅 seaco） | 热词列表，如 `["Paraformer", "语音识别"]` |

## 依赖

- `fasr`
- `funasr`、`funasr-onnx`
- `torch`、`torchaudio`
- Python 3.10–3.12
