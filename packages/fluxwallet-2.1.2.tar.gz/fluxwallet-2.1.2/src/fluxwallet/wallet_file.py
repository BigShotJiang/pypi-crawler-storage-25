"""Encrypted wallet file I/O with master key architecture.

The data encryption key (master key) is a random 32-byte value generated once.
It is wrapped (encrypted) by a key derived from the user's password via Argon2id.
This separation means password changes only rewrite the header, and the keychain
stores the master key directly — no ambiguity about what's cached.

File format:
    magic         4 bytes   b"FXWL"
    version       2 bytes   uint16 LE
    kdf_id        1 byte    0x01 = Argon2id
    time_cost     1 byte
    mem_cost      4 bytes   uint32 LE (KB)
    parallelism   1 byte
    salt          16 bytes
    wrapped_key   60 bytes  (AES-GCM: 12 nonce + 32 ciphertext + 16 tag)
    --- (89 byte header) ---
    nonce         12 bytes  (AES-256-GCM)
    ciphertext    variable  (zlib-compressed msgpack + 16-byte auth tag)
"""

from __future__ import annotations

import contextlib
import logging
import os
import secrets
import shutil
import stat
import struct
import tempfile
import zlib
from pathlib import Path

import argon2.low_level
import keyring
import keyring.errors
import msgpack

from fluxwallet.encoding import aes_decrypt, aes_encrypt
from fluxwallet.secure_mem import secure_wipe

_logger = logging.getLogger(__name__)

MAGIC = b"FXWL"
FORMAT_VERSION = 2
KDF_ARGON2ID = 0x01

ARGON2_TIME_COST = 3
ARGON2_MEMORY_COST = 65536  # 64 MB
ARGON2_PARALLELISM = 4
ARGON2_HASH_LEN = 32

_HEADER_FMT = "<4s H B B I B 16s 60s"
_HEADER_SIZE = struct.calcsize(_HEADER_FMT)  # 89 bytes

_KEYRING_SERVICE = "fluxwallet"
_KEYRING_ACCOUNT = "master_key"


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------


def _derive_wrapping_key(password: str | bytearray, salt: bytes) -> bytearray:
    pw_bytes = bytes(password) if isinstance(password, bytearray) else password.encode("utf-8")

    raw = argon2.low_level.hash_secret_raw(
        secret=pw_bytes,
        salt=salt,
        time_cost=ARGON2_TIME_COST,
        memory_cost=ARGON2_MEMORY_COST,
        parallelism=ARGON2_PARALLELISM,
        hash_len=ARGON2_HASH_LEN,
        type=argon2.low_level.Type.ID,
    )
    return bytearray(raw)


def _wrap_master_key(master_key: bytes, wrapping_key: bytes) -> bytes:
    return aes_encrypt(master_key, wrapping_key)


def _unwrap_master_key(wrapped: bytes, wrapping_key: bytes) -> bytes:
    return aes_decrypt(wrapped, wrapping_key)


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------


def _pack_header(salt: bytes, wrapped_key: bytes) -> bytes:
    return struct.pack(
        _HEADER_FMT,
        MAGIC,
        FORMAT_VERSION,
        KDF_ARGON2ID,
        ARGON2_TIME_COST,
        ARGON2_MEMORY_COST,
        ARGON2_PARALLELISM,
        salt,
        wrapped_key,
    )


def _unpack_header(data: bytes) -> tuple[int, int, int, int, int, bytes, bytes]:
    """Returns (version, kdf_id, time_cost, mem_cost, parallelism, salt, wrapped_key)."""
    if len(data) < _HEADER_SIZE:
        raise ValueError(
            "File too small to contain wallet header."
            " Recovery: file may be corrupted; restore from backup"
        )

    magic, version, kdf_id, time_cost, mem_cost, parallelism, salt, wrapped_key = struct.unpack(
        _HEADER_FMT, data[:_HEADER_SIZE]
    )

    if magic != MAGIC:
        raise ValueError(
            "Not a fluxwallet file (bad magic bytes)."
            " Recovery: check the file path or restore from backup"
        )
    if version > FORMAT_VERSION:
        raise ValueError(f"Unsupported wallet file version {version}")
    if kdf_id != KDF_ARGON2ID:
        raise ValueError(f"Unsupported KDF type {kdf_id}")

    return version, kdf_id, time_cost, mem_cost, parallelism, salt, wrapped_key


# ---------------------------------------------------------------------------
# Atomic file write
# ---------------------------------------------------------------------------


def _atomic_write(path: str, blob: bytes) -> None:
    dir_path = str(Path(path).parent)
    fd = None
    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(dir=dir_path, prefix=".fxwl_")
        os.write(fd, blob)
        os.fsync(fd)
        os.close(fd)
        fd = None
        if os.name != "nt":
            os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, path)
        tmp_path = None
        # Fsync the directory so the rename is durable after power loss.
        # Not needed on Windows — NTFS journals metadata automatically.
        if os.name != "nt":
            dir_fd = os.open(dir_path, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
    finally:
        if fd is not None:
            os.close(fd)
        if tmp_path is not None:
            with contextlib.suppress(OSError):
                os.unlink(tmp_path)


# ---------------------------------------------------------------------------
# Save / Load
# ---------------------------------------------------------------------------


def save_wallet(
    path: str,
    data: dict,
    password: str | bytearray | None = None,
    master_key: bytes | None = None,
) -> bytes:
    """Serialize, compress, encrypt, and atomically write wallet data.

    If master_key is provided, uses it directly (preserving existing header salt/wrap). If password is provided,
    generates a new master key and wraps it.

    Returns the master key (for storing in keychain).
    """
    payload = zlib.compress(msgpack.packb(data, use_bin_type=True), level=6)

    if master_key and Path(path).exists():
        # Re-save with existing master key — preserve header
        with open(path, "rb") as f:
            header = f.read(_HEADER_SIZE)
        encrypted = aes_encrypt(payload, master_key)
        _atomic_write(path, header + encrypted)
        return master_key

    if master_key and not Path(path).exists():
        # New file with caller-provided master key (e.g. migration)
        salt = secrets.token_bytes(16)
        if not password:
            raise ValueError("Password required for new wallet file")
        wrapping_key = _derive_wrapping_key(password, salt)
        try:
            wrapped = _wrap_master_key(master_key, bytes(wrapping_key))
        finally:
            secure_wipe(wrapping_key)
        header = _pack_header(salt, wrapped)
        encrypted = aes_encrypt(payload, master_key)
        _atomic_write(path, header + encrypted)
        return master_key

    if password:
        mk = secrets.token_bytes(32)
        salt = secrets.token_bytes(16)
        wrapping_key = _derive_wrapping_key(password, salt)
        try:
            wrapped = _wrap_master_key(mk, bytes(wrapping_key))
        finally:
            secure_wipe(wrapping_key)
        header = _pack_header(salt, wrapped)
        encrypted = aes_encrypt(payload, mk)
        _atomic_write(path, header + encrypted)
        return mk

    raise ValueError("Provide either password or master_key")


def load_wallet(
    path: str,
    password: str | bytearray | None = None,
    master_key: bytes | None = None,
) -> dict:
    """Read, decrypt, and deserialize wallet data.

    Provide either password (unwraps master key via Argon2id) or master_key directly.
    """
    with open(path, "rb") as f:
        raw = f.read()

    version, kdf_id, time_cost, mem_cost, parallelism, salt, wrapped_key = _unpack_header(raw)
    encrypted_payload = raw[_HEADER_SIZE:]

    if master_key:
        mk = master_key
    elif password:
        wrapping_key = _derive_wrapping_key(password, salt)
        try:
            mk = _unwrap_master_key(wrapped_key, bytes(wrapping_key))
        finally:
            secure_wipe(wrapping_key)
    else:
        raise ValueError("Provide either password or master_key")

    plaintext = aes_decrypt(encrypted_payload, mk)
    data = msgpack.unpackb(zlib.decompress(plaintext), raw=False)

    if not isinstance(data, dict):
        raise ValueError("Wallet file corrupted: expected dict, got " + type(data).__name__)
    if "wallets" not in data:
        raise ValueError("Wallet file corrupted: missing 'wallets' key")
    if not isinstance(data["wallets"], list):
        raise ValueError("Wallet file corrupted: 'wallets' is not a list")

    return data


def unwrap_master_key(path: str, password: str | bytearray) -> bytes:
    """Derive the wrapping key and unwrap the master key.

    For storing in keychain.
    """
    with open(path, "rb") as f:
        header_bytes = f.read(_HEADER_SIZE)

    _, _, _, _, _, salt, wrapped_key = _unpack_header(header_bytes)
    wrapping_key = _derive_wrapping_key(password, salt)
    try:
        return _unwrap_master_key(wrapped_key, bytes(wrapping_key))
    finally:
        secure_wipe(wrapping_key)


def change_password(path: str, old_password: str | bytearray, new_password: str | bytearray) -> None:
    """Re-wrap the master key with a new password.

    Creates a .bak backup before rewriting. Only rewrites the header.
    """
    backup_path = path + ".bak"
    shutil.copy2(path, backup_path)

    with open(path, "rb") as f:
        raw = f.read()

    _, _, _, _, _, old_salt, old_wrapped = _unpack_header(raw)

    # Unwrap with old password
    old_wrapping = _derive_wrapping_key(old_password, old_salt)
    try:
        mk = _unwrap_master_key(old_wrapped, bytes(old_wrapping))
    finally:
        secure_wipe(old_wrapping)

    # Re-wrap with new password and new salt
    new_salt = secrets.token_bytes(16)
    new_wrapping = _derive_wrapping_key(new_password, new_salt)
    try:
        new_wrapped = _wrap_master_key(mk, bytes(new_wrapping))
    finally:
        secure_wipe(new_wrapping)

    new_header = _pack_header(new_salt, new_wrapped)
    _atomic_write(path, new_header + raw[_HEADER_SIZE:])
    os.unlink(backup_path)


def is_wallet_file(path: str) -> bool:
    try:
        with open(path, "rb") as f:
            return f.read(4) == MAGIC
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Key storage helpers
# ---------------------------------------------------------------------------


def store_key_in_keyring(key_hex: str) -> bool:
    try:
        keyring.set_password(_KEYRING_SERVICE, _KEYRING_ACCOUNT, key_hex)
        return True
    except (keyring.errors.KeyringError, OSError) as e:
        _logger.warning("Failed to store master key in keyring: %s", e)
        return False


def load_key_from_keyring() -> bytes | None:
    try:
        key_hex = keyring.get_password(_KEYRING_SERVICE, _KEYRING_ACCOUNT)
        if key_hex:
            return bytes.fromhex(key_hex)
    except (keyring.errors.KeyringError, OSError) as e:
        _logger.warning("Failed to load master key from keyring: %s", e)
    except ValueError as e:
        _logger.warning("Keyring contains invalid hex data: %s", e)
    return None


def delete_key_from_keyring() -> bool:
    try:
        keyring.delete_password(_KEYRING_SERVICE, _KEYRING_ACCOUNT)
        return True
    except (keyring.errors.KeyringError, OSError) as e:
        _logger.warning("Failed to delete master key from keyring: %s", e)
        return False


def load_key_from_file(key_file: str) -> bytes | None:
    path = Path(key_file)
    if not path.is_file():
        return None

    if os.name != "nt":
        mode = path.stat().st_mode
        if mode & (stat.S_IRGRP | stat.S_IWGRP | stat.S_IROTH | stat.S_IWOTH):
            return None

    key_hex = path.read_text().strip()
    if not key_hex:
        return None
    return bytes.fromhex(key_hex)


def load_key_from_stdin() -> bytes | None:
    """Read master key hex from stdin if piped (not a TTY).

    Usage: echo '<64-char-hex>' | fluxwallet wallet list
    """
    import sys

    if sys.stdin.isatty():
        return None
    key_hex = sys.stdin.readline().strip()
    if not key_hex:
        return None
    return bytes.fromhex(key_hex)


def try_auto_unlock(wallet_path: str, key_file: str | None = None) -> bytes | None:
    """Try to get the master key from available sources.

    Priority: stdin → key file → keychain → None (most explicit wins).
    """
    mk = load_key_from_stdin()
    if mk:
        return mk

    if key_file:
        mk = load_key_from_file(key_file)
        if mk:
            return mk

    return load_key_from_keyring()
