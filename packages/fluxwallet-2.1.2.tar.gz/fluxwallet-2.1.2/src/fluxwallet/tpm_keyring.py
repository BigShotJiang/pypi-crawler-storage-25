"""TPM 2.0 NV Index keyring backend for headless Linux systems.

Stores secrets in a TPM 2.0 NV index via ctypes calls to libtss2-esys,
accessed directly through the kernel resource manager at /dev/tpmrm0
(no tpm2-abrmd daemon required).  The user running fluxwallet must be
in the ``tss`` group (or whatever group owns /dev/tpmrm0).

Registered as a ``keyring.backends`` entry-point so that the Python
``keyring`` library discovers it automatically.  On systems without a
TPM the ``priority`` property raises, making ``viable`` return False,
and keyring silently skips this backend.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import hashlib
import os
from pathlib import Path

os.environ.setdefault("TSS2_LOG", "all+NONE")

from keyring import credentials, errors
from keyring.backend import KeyringBackend
from keyring.compat import properties

# ---- TPM constants --------------------------------------------------------

_NV_INDEX = 0x01800100
_NV_SIZE = 64  # hex-encoded 32-byte master key
_TPM_DEVICE = "/dev/tpmrm0"

ESYS_TR_NONE = 0xFFF
ESYS_TR_PASSWORD = 0x0FF
ESYS_TR_RH_OWNER = 0x101

TPM2_ALG_SHA256 = 0x000B

TPMA_NV_AUTHWRITE = 0x00000004
TPMA_NV_AUTHREAD = 0x00040000
TPMA_NV_NO_DA = 0x02000000

# TSS2_RC error codes
TPM2_RC_NV_RANGE = 0x0146
TPM2_RC_NV_DEFINED = 0x014C
TPM2_RC_HANDLE = 0x08B
TPM2_RC_NV_DEFINED = 0x014C
TPM2_RC_REFERENCE_H0 = 0x0910

# ---- C struct mirrors (ctypes) -------------------------------------------

_TPMU_HA_SIZE = 64  # sizeof(TPMU_HA) = SHA-512 digest
_MAX_NV_BUFFER_SIZE = 2048


class TPM2B_AUTH(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_uint16),
        ("buffer", ctypes.c_uint8 * _TPMU_HA_SIZE),
    ]


class TPM2B_DIGEST(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_uint16),
        ("buffer", ctypes.c_uint8 * _TPMU_HA_SIZE),
    ]


class TPMS_NV_PUBLIC(ctypes.Structure):
    _fields_ = [
        ("nvIndex", ctypes.c_uint32),
        ("nameAlg", ctypes.c_uint16),
        ("attributes", ctypes.c_uint32),
        ("authPolicy", TPM2B_DIGEST),
        ("dataSize", ctypes.c_uint16),
    ]


class TPM2B_NV_PUBLIC(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_uint16),
        ("nvPublic", TPMS_NV_PUBLIC),
    ]


class TPM2B_MAX_NV_BUFFER(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_uint16),
        ("buffer", ctypes.c_uint8 * _MAX_NV_BUFFER_SIZE),
    ]


# ---- Library loading ------------------------------------------------------


def _load_esys() -> ctypes.CDLL:
    path = ctypes.util.find_library("tss2-esys")
    if not path:
        msg = "libtss2-esys not found"
        raise RuntimeError(msg)
    return ctypes.CDLL(path)


def _load_tctildr() -> ctypes.CDLL:
    path = ctypes.util.find_library("tss2-tctildr")
    if not path:
        msg = "libtss2-tctildr not found"
        raise RuntimeError(msg)
    return ctypes.CDLL(path)


def _check_rc(rc: int, func: str) -> None:
    if rc != 0:
        msg = f"{func} failed: 0x{rc:08X}"
        raise RuntimeError(msg)


def _is_nv_not_found(rc: int) -> bool:
    """RC values that mean the NV index doesn't exist."""
    # Strip format-one indicator (bit 7) and parameter/session bits
    base = rc & 0x0FF
    return base in (
        TPM2_RC_HANDLE,  # 0x08B
        TPM2_RC_NV_RANGE,  # 0x146 → base 0x046
        TPM2_RC_REFERENCE_H0,  # 0x0910 → base 0x010
    ) or (rc & 0xFFF) in (
        TPM2_RC_NV_RANGE,
        TPM2_RC_REFERENCE_H0,
    )


def _is_nv_defined(rc: int) -> bool:
    """RC value meaning the NV index already exists."""
    return (rc & 0xFFF) == TPM2_RC_NV_DEFINED or (rc & 0x0FF) == (TPM2_RC_NV_DEFINED & 0x0FF)


# ---- ESAPI context manager ------------------------------------------------


class _EsapiContext:
    """Thin wrapper: open/close an ESAPI context via the kernel RM."""

    def __init__(self) -> None:
        self._esys = _load_esys()
        self._tctildr = _load_tctildr()
        self._tcti_ctx = ctypes.c_void_p()
        self._esys_ctx = ctypes.c_void_p()

    def __enter__(self) -> _EsapiContext:
        tcti_name = f"device:{_TPM_DEVICE}".encode()
        rc = self._tctildr.Tss2_TctiLdr_Initialize(
            tcti_name,
            ctypes.byref(self._tcti_ctx),
        )
        _check_rc(rc, "Tss2_TctiLdr_Initialize")

        rc = self._esys.Esys_Initialize(
            ctypes.byref(self._esys_ctx),
            self._tcti_ctx,
            None,
        )
        _check_rc(rc, "Esys_Initialize")
        return self

    def __exit__(self, *args: object) -> None:
        if self._esys_ctx:
            self._esys.Esys_Finalize(ctypes.byref(self._esys_ctx))
        if self._tcti_ctx:
            self._tctildr.Tss2_TctiLdr_Finalize(
                ctypes.byref(self._tcti_ctx),
            )

    def tr_from_tpm_public(self, handle: int) -> int:
        obj = ctypes.c_uint32()
        rc = self._esys.Esys_TR_FromTPMPublic(
            self._esys_ctx,
            handle,
            ESYS_TR_NONE,
            ESYS_TR_NONE,
            ESYS_TR_NONE,
            ctypes.byref(obj),
        )
        _check_rc(rc, "Esys_TR_FromTPMPublic")
        return obj.value

    def tr_set_auth(self, handle: int, auth_bytes: bytes) -> None:
        auth = TPM2B_AUTH()
        auth.size = len(auth_bytes)
        for i, b in enumerate(auth_bytes):
            auth.buffer[i] = b
        rc = self._esys.Esys_TR_SetAuth(
            self._esys_ctx,
            handle,
            ctypes.byref(auth),
        )
        _check_rc(rc, "Esys_TR_SetAuth")

    def nv_define_space(
        self,
        auth_bytes: bytes,
        nv_index: int,
        data_size: int,
    ) -> int:
        auth = TPM2B_AUTH()
        auth.size = len(auth_bytes)
        for i, b in enumerate(auth_bytes):
            auth.buffer[i] = b

        nv_pub = TPM2B_NV_PUBLIC()
        nv_pub.nvPublic.nvIndex = nv_index
        nv_pub.nvPublic.nameAlg = TPM2_ALG_SHA256
        nv_pub.nvPublic.attributes = TPMA_NV_AUTHWRITE | TPMA_NV_AUTHREAD | TPMA_NV_NO_DA
        nv_pub.nvPublic.dataSize = data_size
        nv_pub.nvPublic.authPolicy.size = 0
        nv_pub.size = ctypes.sizeof(TPMS_NV_PUBLIC)

        nv_handle = ctypes.c_uint32()
        rc = self._esys.Esys_NV_DefineSpace(
            self._esys_ctx,
            ESYS_TR_RH_OWNER,
            ESYS_TR_PASSWORD,
            ESYS_TR_NONE,
            ESYS_TR_NONE,
            ctypes.byref(auth),
            ctypes.byref(nv_pub),
            ctypes.byref(nv_handle),
        )
        _check_rc(rc, "Esys_NV_DefineSpace")
        return nv_handle.value

    def nv_write(self, nv_handle: int, data: bytes) -> None:
        buf = TPM2B_MAX_NV_BUFFER()
        buf.size = len(data)
        for i, b in enumerate(data):
            buf.buffer[i] = b
        rc = self._esys.Esys_NV_Write(
            self._esys_ctx,
            nv_handle,
            nv_handle,
            ESYS_TR_PASSWORD,
            ESYS_TR_NONE,
            ESYS_TR_NONE,
            ctypes.byref(buf),
            0,
        )
        _check_rc(rc, "Esys_NV_Write")

    def nv_read(self, nv_handle: int, size: int) -> bytes:
        data_ptr = ctypes.POINTER(TPM2B_MAX_NV_BUFFER)()
        rc = self._esys.Esys_NV_Read(
            self._esys_ctx,
            nv_handle,
            nv_handle,
            ESYS_TR_PASSWORD,
            ESYS_TR_NONE,
            ESYS_TR_NONE,
            size,
            0,
            ctypes.byref(data_ptr),
        )
        _check_rc(rc, "Esys_NV_Read")
        result = bytes(data_ptr.contents.buffer[: data_ptr.contents.size])
        self._esys.Esys_Free(data_ptr)
        return result

    def nv_undefine_space(self, nv_handle: int) -> None:
        rc = self._esys.Esys_NV_UndefineSpace(
            self._esys_ctx,
            ESYS_TR_RH_OWNER,
            nv_handle,
            ESYS_TR_PASSWORD,
            ESYS_TR_NONE,
            ESYS_TR_NONE,
        )
        _check_rc(rc, "Esys_NV_UndefineSpace")


# ---- Auth helper ----------------------------------------------------------

_DEFAULT_AUTH_SECRET = Path("~/.fluxwallet/tpm-auth-secret")

_tpm_auth_file: Path | None = None


def configure_tpm_auth(path: str | Path | None) -> None:
    """Set the TPM auth secret file path (CLI or config override)."""
    global _tpm_auth_file
    _tpm_auth_file = Path(path) if path else None


def _resolve_auth_secret() -> Path | None:
    """Return the auth secret file path: CLI/config override > convention default."""
    if _tpm_auth_file is not None:
        return _tpm_auth_file.expanduser()
    default = _DEFAULT_AUTH_SECRET.expanduser()
    return default if default.exists() else None


def _machine_auth() -> bytes:
    """Derive a 32-byte NV index auth value from machine identity + optional secret file."""
    mid = Path("/etc/machine-id")
    seed = mid.read_bytes().strip() if mid.exists() else b"fluxwallet-fallback"

    secret_path = _resolve_auth_secret()
    if secret_path is not None and secret_path.exists():
        seed += secret_path.read_bytes().strip()

    return hashlib.sha256(
        b"fluxwallet-tpm-nv-auth-v1:" + seed,
    ).digest()


# ---- Keyring backend ------------------------------------------------------


class TPMKeyring(KeyringBackend):
    """Store secrets in a TPM 2.0 NV index via libtss2-esys."""

    @properties.classproperty
    def priority(cls) -> float:
        if not Path(_TPM_DEVICE).exists():
            raise RuntimeError("No TPM resource manager device")
        if not ctypes.util.find_library("tss2-esys"):
            raise RuntimeError("libtss2-esys not found")
        return 5

    def get_password(self, service: str, username: str) -> str | None:
        try:
            auth = _machine_auth()
            with _EsapiContext() as ctx:
                nv_handle = ctx.tr_from_tpm_public(_NV_INDEX)
                ctx.tr_set_auth(nv_handle, auth)
                data = ctx.nv_read(nv_handle, _NV_SIZE)
                return data.decode("ascii").strip("\x00")
        except RuntimeError as exc:
            if _is_nv_not_found(_extract_rc(exc)):
                return None
            raise

    def set_password(
        self,
        service: str,
        username: str,
        password: str,
    ) -> None:
        encoded = password.encode("ascii").ljust(_NV_SIZE, b"\x00")
        if len(encoded) > _NV_SIZE:
            msg = f"Password too long for NV index ({len(encoded)} > {_NV_SIZE})"
            raise errors.PasswordSetError(msg)

        auth = _machine_auth()

        with _EsapiContext() as ctx:
            try:
                nv_handle = ctx.nv_define_space(
                    auth,
                    _NV_INDEX,
                    _NV_SIZE,
                )
            except RuntimeError as exc:
                if not _is_nv_defined(_extract_rc(exc)):
                    raise
                nv_handle = ctx.tr_from_tpm_public(_NV_INDEX)
                ctx.nv_undefine_space(nv_handle)
                nv_handle = ctx.nv_define_space(
                    auth,
                    _NV_INDEX,
                    _NV_SIZE,
                )
            ctx.tr_set_auth(nv_handle, auth)
            ctx.nv_write(nv_handle, encoded)

    def delete_password(self, service: str, username: str) -> None:
        try:
            with _EsapiContext() as ctx:
                nv_handle = ctx.tr_from_tpm_public(_NV_INDEX)
                ctx.nv_undefine_space(nv_handle)
        except RuntimeError as exc:
            if not _is_nv_not_found(_extract_rc(exc)):
                raise

    def get_credential(
        self,
        service: str,
        username: str | None = None,
    ) -> credentials.Credential | None:
        return None


def _extract_rc(exc: RuntimeError) -> int:
    """Pull the hex RC from our error messages like 'Foo failed: 0x...'."""
    msg = str(exc)
    if "0x" in msg:
        hex_part = msg.split("0x")[-1].rstrip(")")
        try:
            return int(hex_part, 16)
        except ValueError:
            pass
    return 0
