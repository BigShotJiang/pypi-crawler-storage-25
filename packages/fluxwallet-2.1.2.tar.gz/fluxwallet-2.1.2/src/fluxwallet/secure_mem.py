"""Secure memory management using libsodium with bytearray+mlock fallback.

All private keys, mnemonics, passwords, and seeds should use SecureBuffer or bytearray + secure_wipe() instead of
immutable bytes/str/int.
"""

from __future__ import annotations

import atexit
import contextlib
import ctypes
import ctypes.util
import logging
import platform
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import FrameType

_logger = logging.getLogger(__name__)

_SYSTEM = platform.system()


class _SodiumState:
    def __init__(self) -> None:
        self.lib: ctypes.CDLL | None = None
        self.available: bool = False
        self.initialized: bool = False

    def load(self) -> bool:
        if self.lib is not None:
            return self.available

        lib_names = {
            "Darwin": ["libsodium.dylib"],
            "Linux": ["libsodium.so.26", "libsodium.so.23", "libsodium.so"],
            "Windows": ["libsodium.dll", "sodium.dll"],
        }

        found = ctypes.util.find_library("sodium")
        if found:
            try:
                self.lib = ctypes.CDLL(found)
                self.available = True
                return True
            except OSError:
                pass

        for name in lib_names.get(_SYSTEM, []):
            try:
                self.lib = ctypes.CDLL(name)
                self.available = True
                return True
            except OSError:
                continue

        self.available = False
        return False

    def init(self) -> bool:
        if self.initialized:
            return self.available

        if not self.load():
            _logger.warning(
                "libsodium not found — falling back to bytearray+mlock. "
                "Install libsodium for guard pages and secure memory allocation."
            )
            self.initialized = True
            return False

        lib = self.lib
        if lib is None:
            self.initialized = True
            return False

        ret = lib.sodium_init()
        if ret < 0:
            _logger.error("sodium_init() failed")
            self.initialized = True
            return False

        lib.sodium_malloc.restype = ctypes.c_void_p
        lib.sodium_malloc.argtypes = [ctypes.c_size_t]
        lib.sodium_free.restype = None
        lib.sodium_free.argtypes = [ctypes.c_void_p]
        lib.sodium_mprotect_noaccess.restype = ctypes.c_int
        lib.sodium_mprotect_noaccess.argtypes = [ctypes.c_void_p]
        lib.sodium_mprotect_readonly.restype = ctypes.c_int
        lib.sodium_mprotect_readonly.argtypes = [ctypes.c_void_p]
        lib.sodium_mprotect_readwrite.restype = ctypes.c_int
        lib.sodium_mprotect_readwrite.argtypes = [ctypes.c_void_p]
        lib.sodium_memzero.restype = None
        lib.sodium_memzero.argtypes = [ctypes.c_void_p, ctypes.c_size_t]

        self.initialized = True
        return True


_sodium_state = _SodiumState()


def sodium_init() -> bool:
    """Initialize libsodium.

    Idempotent. Returns True if available.
    """
    return _sodium_state.init()


def disable_core_dumps() -> bool:
    """Prevent core dumps that could expose key material in memory."""
    if _SYSTEM in ("Darwin", "Linux"):
        try:
            import resource  # noqa: PLC0415

            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            return True
        except (ValueError, OSError) as e:
            _logger.warning("Could not disable core dumps: %s", e)
            return False
    elif _SYSTEM == "Windows":
        try:
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            kernel32.SetErrorMode(0x0003)
            return True
        except (OSError, AttributeError) as e:
            _logger.warning("Could not disable core dumps: %s", e)
            return False
    return False


# ---------------------------------------------------------------------------
# Secure allocation via libsodium
# ---------------------------------------------------------------------------


def secure_alloc(size: int) -> ctypes.c_void_p:
    """Allocate mlock'd memory with guard pages via sodium_malloc."""
    lib = _sodium_state.lib
    if not _sodium_state.available or lib is None:
        raise RuntimeError("libsodium not available — cannot use secure_alloc")
    ptr = lib.sodium_malloc(size)
    if not ptr:
        raise MemoryError(f"sodium_malloc({size}) returned NULL")
    return ctypes.c_void_p(ptr)


def secure_free(ptr: ctypes.c_void_p) -> None:
    """Zero, munlock, and free sodium_malloc'd memory."""
    lib = _sodium_state.lib
    if not _sodium_state.available or lib is None or not ptr or not ptr.value:
        return
    lib.sodium_free(ptr)


def secure_mprotect_noaccess(ptr: ctypes.c_void_p) -> bool:
    """Make memory inaccessible — any access will segfault."""
    lib = _sodium_state.lib
    if not _sodium_state.available or lib is None or not ptr or not ptr.value:
        return False
    return lib.sodium_mprotect_noaccess(ptr) == 0


def secure_mprotect_readonly(ptr: ctypes.c_void_p) -> bool:
    lib = _sodium_state.lib
    if not _sodium_state.available or lib is None or not ptr or not ptr.value:
        return False
    return lib.sodium_mprotect_readonly(ptr) == 0


def secure_mprotect_readwrite(ptr: ctypes.c_void_p) -> bool:
    lib = _sodium_state.lib
    if not _sodium_state.available or lib is None or not ptr or not ptr.value:
        return False
    return lib.sodium_mprotect_readwrite(ptr) == 0


def secure_memzero(ptr: ctypes.c_void_p, size: int) -> None:
    """Resistant to compiler dead-store elimination unlike memset."""
    lib = _sodium_state.lib
    if _sodium_state.available and lib is not None and ptr and ptr.value:
        lib.sodium_memzero(ptr, size)


# ---------------------------------------------------------------------------
# Python buffer wiping
# ---------------------------------------------------------------------------


def secure_wipe(buf: bytearray | memoryview) -> None:
    """Zero a mutable Python buffer in-place."""
    if not isinstance(buf, (bytearray, memoryview)):
        raise TypeError(
            f"secure_wipe requires bytearray or memoryview, got {type(buf).__name__}. "
            "Use bytearray instead of bytes/str for sensitive data."
        )

    size = len(buf)
    if size == 0:
        return

    lib = _sodium_state.lib
    if _sodium_state.available and lib is not None:
        c_buf = (ctypes.c_char * size).from_buffer(buf)
        lib.sodium_memzero(ctypes.addressof(c_buf), size)
    else:
        # Python's interpreter doesn't do dead-store elimination
        if isinstance(buf, memoryview):
            buf[:] = b"\x00" * size
        else:
            for i in range(size):
                buf[i] = 0


# ---------------------------------------------------------------------------
# Fallback mlock/munlock for bytearray
# ---------------------------------------------------------------------------


def _mlock_bytearray(buf: bytearray) -> bool:
    size = len(buf)
    if size == 0:
        return False

    try:
        c_buf = (ctypes.c_char * size).from_buffer(buf)
        addr = ctypes.addressof(c_buf)
    except (TypeError, ValueError):
        return False

    if _SYSTEM in ("Darwin", "Linux"):
        try:
            libc = ctypes.CDLL(ctypes.util.find_library("c"))
            return libc.mlock(ctypes.c_void_p(addr), size) == 0
        except (OSError, TypeError):
            return False
    elif _SYSTEM == "Windows":
        try:
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            return bool(kernel32.VirtualLock(ctypes.c_void_p(addr), size))
        except (OSError, AttributeError):
            return False
    return False


def _munlock_bytearray(buf: bytearray) -> bool:
    size = len(buf)
    if size == 0:
        return False

    try:
        c_buf = (ctypes.c_char * size).from_buffer(buf)
        addr = ctypes.addressof(c_buf)
    except (TypeError, ValueError):
        return False

    if _SYSTEM in ("Darwin", "Linux"):
        try:
            libc = ctypes.CDLL(ctypes.util.find_library("c"))
            return libc.munlock(ctypes.c_void_p(addr), size) == 0
        except (OSError, TypeError):
            return False
    elif _SYSTEM == "Windows":
        try:
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            return bool(kernel32.VirtualUnlock(ctypes.c_void_p(addr), size))
        except (OSError, AttributeError):
            return False
    return False


# ---------------------------------------------------------------------------
# SecureBuffer
# ---------------------------------------------------------------------------


class SecureBuffer:
    """Secure memory buffer for cryptographic key material.

    With libsodium: sodium_malloc (mlock'd, guard pages, canary, mprotect).
    Without: bytearray with best-effort mlock and explicit zeroing.
    """

    _live_buffers: list[SecureBuffer] = []

    def __init__(self, size: int) -> None:
        self._size: int = size
        self._closed: bool = False
        self._using_sodium: bool = _sodium_state.available
        self._ptr: ctypes.c_void_p | None = None
        self._bytearray: bytearray | None = None

        if self._using_sodium:
            self._ptr = secure_alloc(size)
        else:
            self._bytearray = bytearray(size)
            _mlock_bytearray(self._bytearray)

        SecureBuffer._live_buffers.append(self)

    @property
    def size(self) -> int:
        return self._size

    @property
    def closed(self) -> bool:
        return self._closed

    def write(self, data: bytes | bytearray, offset: int = 0) -> None:
        if self._closed:
            raise RuntimeError("SecureBuffer is closed")
        if offset + len(data) > self._size:
            raise ValueError(f"Data ({len(data)} bytes at offset {offset}) exceeds buffer size ({self._size} bytes)")
        if self._using_sodium and self._ptr is not None:
            secure_mprotect_readwrite(self._ptr)
            ptr_val = self._ptr.value
            if ptr_val is not None:
                ctypes.memmove(ptr_val + offset, bytes(data), len(data))
        elif self._bytearray is not None:
            self._bytearray[offset : offset + len(data)] = data

    def read(self, offset: int = 0, size: int | None = None) -> bytes:
        """Returns an immutable copy — caller should use bytearray if zeroing needed."""
        if self._closed:
            raise RuntimeError("SecureBuffer is closed")
        if size is None:
            size = self._size - offset
        if offset + size > self._size:
            raise ValueError("Read exceeds buffer size")
        if self._using_sodium and self._ptr is not None:
            secure_mprotect_readonly(self._ptr)
            ptr_val = self._ptr.value
            if ptr_val is not None:
                return ctypes.string_at(ptr_val + offset, size)
            return b"\x00" * size
        if self._bytearray is not None:
            return bytes(self._bytearray[offset : offset + size])
        return b"\x00" * size

    def read_into(self, dest: bytearray, offset: int = 0, size: int | None = None) -> None:
        """Read into a mutable bytearray — avoids immutable bytes intermediate."""
        if self._closed:
            raise RuntimeError("SecureBuffer is closed")
        if size is None:
            size = self._size - offset
        if offset + size > self._size:
            raise ValueError("Read exceeds buffer size")
        if self._using_sodium and self._ptr is not None:
            secure_mprotect_readonly(self._ptr)
            ptr_val = self._ptr.value
            if ptr_val is not None:
                ctypes.memmove(
                    (ctypes.c_char * len(dest)).from_buffer(dest),
                    ptr_val + offset,
                    size,
                )
        elif self._bytearray is not None:
            dest[:size] = self._bytearray[offset : offset + size]

    def lock(self) -> None:
        if self._closed:
            return
        if self._using_sodium and self._ptr is not None:
            secure_mprotect_noaccess(self._ptr)

    def unlock_readonly(self) -> None:
        if self._closed:
            return
        if self._using_sodium and self._ptr is not None:
            secure_mprotect_readonly(self._ptr)

    def unlock_readwrite(self) -> None:
        if self._closed:
            return
        if self._using_sodium and self._ptr is not None:
            secure_mprotect_readwrite(self._ptr)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        if self._using_sodium:
            if self._ptr and self._ptr.value:
                secure_free(self._ptr)
                self._ptr = ctypes.c_void_p(None)
        else:
            if self._bytearray is not None:
                secure_wipe(self._bytearray)
                _munlock_bytearray(self._bytearray)
                self._bytearray = None

        with contextlib.suppress(ValueError):
            SecureBuffer._live_buffers.remove(self)

    def __enter__(self) -> SecureBuffer:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        self.close()

    def __del__(self) -> None:
        self.close()

    def __repr__(self) -> str:
        state = "closed" if self._closed else "open"
        backend = "sodium" if self._using_sodium else "bytearray"
        return f"<SecureBuffer size={self._size} state={state} backend={backend}>"


# ---------------------------------------------------------------------------
# Emergency cleanup
# ---------------------------------------------------------------------------


def wipe_all_buffers() -> None:
    """Zero and free all live SecureBuffer instances."""
    for buf in list(SecureBuffer._live_buffers):
        with contextlib.suppress(Exception):
            buf.close()


def _setup_signal_handlers() -> None:
    import signal  # noqa: PLC0415

    def _cleanup_handler(signum: int, frame: FrameType | None) -> None:
        wipe_all_buffers()
        signal.signal(signum, signal.SIG_DFL)
        sys.exit(128 + signum)

    try:
        signal.signal(signal.SIGTERM, _cleanup_handler)
        signal.signal(signal.SIGINT, _cleanup_handler)
        if _SYSTEM != "Windows":
            signal.signal(signal.SIGHUP, _cleanup_handler)
    except (ValueError, OSError):
        pass


atexit.register(wipe_all_buffers)
_setup_signal_handlers()
