"""LMDB-backed cache store with AES-256-GCM encrypted values.

Replaces the SQLite-based db_cache.py. Values are encrypted so a compromised cache file doesn't leak transaction
history, addresses, or balances. LMDB keys (txids, addresses, block heights) are plaintext for efficient lookup — this
is public blockchain data already visible on-chain.
"""

from __future__ import annotations

import logging
import os
import struct
from datetime import UTC, datetime

import lmdb
import msgpack

from fluxwallet.config import LMDB_DEFAULT_MAP_SIZE
from fluxwallet.encoding import aes_decrypt, aes_encrypt

_logger = logging.getLogger(__name__)
_MAX_DBS = 5


class CacheStore:
    """Encrypted LMDB cache for blockchain data."""

    def __init__(
        self,
        path: str,
        encryption_key: bytes | None = None,
        map_size: int = LMDB_DEFAULT_MAP_SIZE,
    ) -> None:
        os.makedirs(path, mode=0o700, exist_ok=True)
        self._env: lmdb.Environment = lmdb.open(path, map_size=map_size, max_dbs=_MAX_DBS)
        self._key: bytes | None = encryption_key

        self._db_transactions: lmdb._Database = self._env.open_db(b"transactions")
        self._db_tx_nodes: lmdb._Database = self._env.open_db(b"tx_nodes")
        self._db_addresses: lmdb._Database = self._env.open_db(b"addresses")
        self._db_blocks: lmdb._Database = self._env.open_db(b"blocks")
        self._db_vars: lmdb._Database = self._env.open_db(b"vars")

    def _encrypt(self, data: dict) -> bytes:
        blob = msgpack.packb(data, use_bin_type=True)
        if self._key:
            return aes_encrypt(blob, self._key)
        return blob

    def _decrypt(self, raw: bytes) -> dict:
        if self._key:
            raw = aes_decrypt(raw, self._key)
        return msgpack.unpackb(raw, raw=False)

    # -- Transactions --------------------------------------------------------

    def put_transaction(self, txid: bytes, data: dict) -> None:
        with self._env.begin(write=True, db=self._db_transactions) as txn:
            txn.put(txid, self._encrypt(data))

    def get_transaction(self, txid: bytes) -> dict | None:
        with self._env.begin(db=self._db_transactions) as txn:
            raw = txn.get(txid)
        if raw is None:
            return None
        return self._decrypt(raw)

    def delete_transaction(self, txid: bytes) -> bool:
        with self._env.begin(write=True, db=self._db_transactions) as txn:
            return txn.delete(txid)

    # -- Transaction nodes (inputs/outputs) ----------------------------------

    @staticmethod
    def _tx_node_key(txid: bytes, index_n: int, is_input: bool) -> bytes:
        return txid + struct.pack(">HB", index_n, int(is_input))

    def put_tx_node(self, txid: bytes, index_n: int, is_input: bool, data: dict) -> None:
        key = self._tx_node_key(txid, index_n, is_input)
        with self._env.begin(write=True, db=self._db_tx_nodes) as txn:
            txn.put(key, self._encrypt(data))

    def get_tx_node(self, txid: bytes, index_n: int, is_input: bool) -> dict | None:
        key = self._tx_node_key(txid, index_n, is_input)
        with self._env.begin(db=self._db_tx_nodes) as txn:
            raw = txn.get(key)
        if raw is None:
            return None
        return self._decrypt(raw)

    def get_tx_nodes(self, txid: bytes) -> list[dict]:
        """Get all nodes (inputs + outputs) for a transaction."""
        prefix = txid
        results = []
        with self._env.begin(db=self._db_tx_nodes) as txn:
            cursor = txn.cursor()
            if cursor.set_range(prefix):
                for key, value in cursor:
                    if not key.startswith(prefix):
                        break
                    node = self._decrypt(value)
                    # Decode key fields
                    suffix = key[len(prefix) :]
                    index_n, is_input = struct.unpack(">HB", suffix)
                    node["index_n"] = index_n
                    node["is_input"] = bool(is_input)
                    results.append(node)
        return results

    def delete_tx_nodes(self, txid: bytes) -> int:
        """Delete all nodes for a transaction.

        Returns count deleted.
        """
        prefix = txid
        count = 0
        with self._env.begin(write=True, db=self._db_tx_nodes) as txn:
            cursor = txn.cursor()
            if cursor.set_range(prefix):
                while cursor.key().startswith(prefix):
                    cursor.delete()
                    count += 1
        return count

    # -- Addresses -----------------------------------------------------------

    def put_address(self, address: str, data: dict) -> None:
        with self._env.begin(write=True, db=self._db_addresses) as txn:
            txn.put(address.encode("utf-8"), self._encrypt(data))

    def get_address(self, address: str) -> dict | None:
        with self._env.begin(db=self._db_addresses) as txn:
            raw = txn.get(address.encode("utf-8"))
        if raw is None:
            return None
        return self._decrypt(raw)

    def delete_address(self, address: str) -> bool:
        with self._env.begin(write=True, db=self._db_addresses) as txn:
            return txn.delete(address.encode("utf-8"))

    # -- Blocks --------------------------------------------------------------

    def put_block(self, height: int, data: dict) -> None:
        key = struct.pack(">I", height)
        with self._env.begin(write=True, db=self._db_blocks) as txn:
            txn.put(key, self._encrypt(data))

    def get_block(self, height: int) -> dict | None:
        key = struct.pack(">I", height)
        with self._env.begin(db=self._db_blocks) as txn:
            raw = txn.get(key)
        if raw is None:
            return None
        return self._decrypt(raw)

    def delete_block(self, height: int) -> bool:
        key = struct.pack(">I", height)
        with self._env.begin(write=True, db=self._db_blocks) as txn:
            return txn.delete(key)

    # -- Variables (with TTL) ------------------------------------------------

    @staticmethod
    def _var_key(name: str, network: str) -> bytes:
        return f"{network}:{name}".encode()

    def put_var(self, name: str, network: str, value: str, expires: datetime | None = None) -> None:
        data = {"value": value}
        if expires:
            data["expires"] = expires.isoformat()
        with self._env.begin(write=True, db=self._db_vars) as txn:
            txn.put(self._var_key(name, network), self._encrypt(data))

    def get_var(self, name: str, network: str) -> str | None:
        """Get a variable value.

        Returns None if expired or missing.
        """
        with self._env.begin(db=self._db_vars) as txn:
            raw = txn.get(self._var_key(name, network))
        if raw is None:
            return None
        data = self._decrypt(raw)
        if "expires" in data and data["expires"]:
            exp = datetime.fromisoformat(data["expires"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=UTC)
            if exp < datetime.now(UTC):
                return None
        return data.get("value")

    def delete_var(self, name: str, network: str) -> bool:
        with self._env.begin(write=True, db=self._db_vars) as txn:
            return txn.delete(self._var_key(name, network))

    # -- Maintenance ---------------------------------------------------------

    def clear(self) -> None:
        """Wipe all cached data."""
        with self._env.begin(write=True) as txn:
            for db in (
                self._db_transactions,
                self._db_tx_nodes,
                self._db_addresses,
                self._db_blocks,
                self._db_vars,
            ):
                txn.drop(db, delete=False)

    def close(self) -> None:
        self._env.close()

    def set_encryption_key(self, key: bytes | None) -> None:
        self._key = key

    def __enter__(self) -> CacheStore:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        self.close()

    @property
    def stats(self) -> dict[str, int]:
        with self._env.begin() as txn:
            return {
                "transactions": txn.stat(self._db_transactions)["entries"],
                "tx_nodes": txn.stat(self._db_tx_nodes)["entries"],
                "addresses": txn.stat(self._db_addresses)["entries"],
                "blocks": txn.stat(self._db_blocks)["entries"],
                "vars": txn.stat(self._db_vars)["entries"],
            }
