#
#    fluxwallet - Python Cryptocurrency Library
#    Script opcode definitions
#    © 2017 - 2021 February - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#


from __future__ import annotations

_opcodes = [
    ("OP_0", 0),
    ("OP_PUSHDATA1", 76),
    "OP_PUSHDATA2",
    "OP_PUSHDATA4",
    "OP_1NEGATE",
    "OP_RESERVED",
    "OP_1",
    "OP_2",
    "OP_3",
    "OP_4",
    "OP_5",
    "OP_6",
    "OP_7",
    "OP_8",
    "OP_9",
    "OP_10",
    "OP_11",
    "OP_12",
    "OP_13",
    "OP_14",
    "OP_15",
    "OP_16",
    "OP_NOP",
    "OP_VER",
    "OP_IF",
    "OP_NOTIF",
    "OP_VERIF",
    "OP_VERNOTIF",
    "OP_ELSE",
    "OP_ENDIF",
    "OP_VERIFY",
    "OP_RETURN",
    "OP_TOALTSTACK",
    "OP_FROMALTSTACK",
    "OP_2DROP",
    "OP_2DUP",
    "OP_3DUP",
    "OP_2OVER",
    "OP_2ROT",
    "OP_2SWAP",
    "OP_IFDUP",
    "OP_DEPTH",
    "OP_DROP",
    "OP_DUP",
    "OP_NIP",
    "OP_OVER",
    "OP_PICK",
    "OP_ROLL",
    "OP_ROT",
    "OP_SWAP",
    "OP_TUCK",
    "OP_CAT",
    "OP_SUBSTR",
    "OP_LEFT",
    "OP_RIGHT",
    "OP_SIZE",
    "OP_INVERT",
    "OP_AND",
    "OP_OR",
    "OP_XOR",
    "OP_EQUAL",
    "OP_EQUALVERIFY",
    "OP_RESERVED1",
    "OP_RESERVED2",
    "OP_1ADD",
    "OP_1SUB",
    "OP_2MUL",
    "OP_2DIV",
    "OP_NEGATE",
    "OP_ABS",
    "OP_NOT",
    "OP_0NOTEQUAL",
    "OP_ADD",
    "OP_SUB",
    "OP_MUL",
    "OP_DIV",
    "OP_MOD",
    "OP_LSHIFT",
    "OP_RSHIFT",
    "OP_BOOLAND",
    "OP_BOOLOR",
    "OP_NUMEQUAL",
    "OP_NUMEQUALVERIFY",
    "OP_NUMNOTEQUAL",
    "OP_LESSTHAN",
    "OP_GREATERTHAN",
    "OP_LESSTHANOREQUAL",
    "OP_GREATERTHANOREQUAL",
    "OP_MIN",
    "OP_MAX",
    "OP_WITHIN",
    "OP_RIPEMD160",
    "OP_SHA1",
    "OP_SHA256",
    "OP_HASH160",
    "OP_HASH256",
    "OP_CODESEPARATOR",
    "OP_CHECKSIG",
    "OP_CHECKSIGVERIFY",
    "OP_CHECKMULTISIG",
    "OP_CHECKMULTISIGVERIFY",
    "OP_NOP1",
    "OP_CHECKLOCKTIMEVERIFY",
    "OP_CHECKSEQUENCEVERIFY",
    "OP_NOP4",
    "OP_NOP5",
    "OP_NOP6",
    "OP_NOP7",
    "OP_NOP8",
    "OP_NOP9",
    "OP_NOP10",
    ("OP_INVALIDOPCODE", 0xFF),
]


class _OpCodes:
    """Namespace holding opcode integer values as attributes."""

    op_0: int = 0
    op_pushdata1: int = 76
    op_pushdata2: int = 0
    op_pushdata4: int = 0
    op_1negate: int = 0
    op_reserved: int = 0
    op_1: int = 0
    op_2: int = 0
    op_3: int = 0
    op_4: int = 0
    op_5: int = 0
    op_6: int = 0
    op_7: int = 0
    op_8: int = 0
    op_9: int = 0
    op_10: int = 0
    op_11: int = 0
    op_12: int = 0
    op_13: int = 0
    op_14: int = 0
    op_15: int = 0
    op_16: int = 0
    op_nop: int = 0
    op_ver: int = 0
    op_if: int = 0
    op_notif: int = 0
    op_verif: int = 0
    op_vernotif: int = 0
    op_else: int = 0
    op_endif: int = 0
    op_verify: int = 0
    op_return: int = 0
    op_toaltstack: int = 0
    op_fromaltstack: int = 0
    op_2drop: int = 0
    op_2dup: int = 0
    op_3dup: int = 0
    op_2over: int = 0
    op_2rot: int = 0
    op_2swap: int = 0
    op_ifdup: int = 0
    op_depth: int = 0
    op_drop: int = 0
    op_dup: int = 0
    op_nip: int = 0
    op_over: int = 0
    op_pick: int = 0
    op_roll: int = 0
    op_rot: int = 0
    op_swap: int = 0
    op_tuck: int = 0
    op_cat: int = 0
    op_substr: int = 0
    op_left: int = 0
    op_right: int = 0
    op_size: int = 0
    op_invert: int = 0
    op_and: int = 0
    op_or: int = 0
    op_xor: int = 0
    op_equal: int = 0
    op_equalverify: int = 0
    op_reserved1: int = 0
    op_reserved2: int = 0
    op_1add: int = 0
    op_1sub: int = 0
    op_2mul: int = 0
    op_2div: int = 0
    op_negate: int = 0
    op_abs: int = 0
    op_not: int = 0
    op_0notequal: int = 0
    op_add: int = 0
    op_sub: int = 0
    op_mul: int = 0
    op_div: int = 0
    op_mod: int = 0
    op_lshift: int = 0
    op_rshift: int = 0
    op_booland: int = 0
    op_boolor: int = 0
    op_numequal: int = 0
    op_numequalverify: int = 0
    op_numnotequal: int = 0
    op_lessthan: int = 0
    op_greaterthan: int = 0
    op_lessthanorequal: int = 0
    op_greaterthanorequal: int = 0
    op_min: int = 0
    op_max: int = 0
    op_within: int = 0
    op_ripemd160: int = 0
    op_sha1: int = 0
    op_sha256: int = 0
    op_hash160: int = 0
    op_hash256: int = 0
    op_codeseparator: int = 0
    op_checksig: int = 0
    op_checksigverify: int = 0
    op_checkmultisig: int = 0
    op_checkmultisigverify: int = 0
    op_nop1: int = 0
    op_checklocktimeverify: int = 0
    op_checksequenceverify: int = 0
    op_nop4: int = 0
    op_nop5: int = 0
    op_nop6: int = 0
    op_nop7: int = 0
    op_nop8: int = 0
    op_nop9: int = 0
    op_nop10: int = 0
    op_invalidopcode: int = 0xFF


op: _OpCodes = _OpCodes()


def _set_opcodes() -> dict[int, str]:
    idx = 0
    opcodenames: dict[int, str] = {}
    for opcode in _opcodes:
        if isinstance(opcode, tuple):
            var, idx = opcode
        else:
            var = opcode
        opcodenames.update({idx: var})
        setattr(op, var.lower(), idx)
        idx += 1
    return opcodenames


opcodenames = _set_opcodes()

OP_N_CODES = range(op.op_1, op.op_16)
