import fluxwallet.config.config as _config_mod
import fluxwallet.config.opcodes as opcodes  # noqa: F401
import fluxwallet.config.secp256k1 as secp256k1  # noqa: F401
from fluxwallet.config.config import (
    BIP39_PBKDF2_ITERATIONS as BIP39_PBKDF2_ITERATIONS,
)
from fluxwallet.config.config import (
    BIP68_LOCKTIME_GRANULARITY_SECONDS as BIP68_LOCKTIME_GRANULARITY_SECONDS,
)

# Re-export constants directly
from fluxwallet.config.config import (
    FW_INSTALL_DIR as FW_INSTALL_DIR,
)
from fluxwallet.config.config import (
    LMDB_DEFAULT_MAP_SIZE as LMDB_DEFAULT_MAP_SIZE,
)
from fluxwallet.config.config import (
    LOG_FILE_MAX_BYTES as LOG_FILE_MAX_BYTES,
)
from fluxwallet.config.config import (
    NETWORK_DENOMINATORS as NETWORK_DENOMINATORS,
)
from fluxwallet.config.config import (
    RELAY_HTTP_TIMEOUT as RELAY_HTTP_TIMEOUT,
)
from fluxwallet.config.config import (
    RELAY_WAIT_TIMEOUT as RELAY_WAIT_TIMEOUT,
)
from fluxwallet.config.config import (
    SCRIPT_TYPES_LOCKING as SCRIPT_TYPES_LOCKING,
)
from fluxwallet.config.config import (
    SCRIPT_TYPES_UNLOCKING as SCRIPT_TYPES_UNLOCKING,
)
from fluxwallet.config.config import (
    SEQUENCE_ENABLE_LOCKTIME as SEQUENCE_ENABLE_LOCKTIME,
)
from fluxwallet.config.config import (
    SEQUENCE_LOCKTIME_GRANULARITY as SEQUENCE_LOCKTIME_GRANULARITY,
)
from fluxwallet.config.config import (
    SEQUENCE_LOCKTIME_MASK as SEQUENCE_LOCKTIME_MASK,
)
from fluxwallet.config.config import (
    SEQUENCE_LOCKTIME_TYPE_FLAG as SEQUENCE_LOCKTIME_TYPE_FLAG,
)
from fluxwallet.config.config import (
    SEQUENCE_REPLACE_BY_FEE as SEQUENCE_REPLACE_BY_FEE,
)
from fluxwallet.config.config import (
    SIGHASH_ALL as SIGHASH_ALL,
)
from fluxwallet.config.config import (
    SIGHASH_ANYONECANPAY as SIGHASH_ANYONECANPAY,
)
from fluxwallet.config.config import (
    SIGHASH_NONE as SIGHASH_NONE,
)
from fluxwallet.config.config import (
    SIGHASH_SINGLE as SIGHASH_SINGLE,
)
from fluxwallet.config.config import (
    SIGNATURE_VERSION_STANDARD as SIGNATURE_VERSION_STANDARD,
)
from fluxwallet.config.config import (
    SUPPORTED_ADDRESS_ENCODINGS as SUPPORTED_ADDRESS_ENCODINGS,
)
from fluxwallet.config.config import (
    TYPE_INT as TYPE_INT,
)
from fluxwallet.config.config import (
    TYPE_TEXT as TYPE_TEXT,
)
from fluxwallet.config.config import (
    UTXO_BATCH_SIZE as UTXO_BATCH_SIZE,
)
from fluxwallet.config.config import (
    WALLET_KEY_STRUCTURES as WALLET_KEY_STRUCTURES,
)
from fluxwallet.config.config import (
    read_config as read_config,
)


# Dynamic config values — delegate to config module's __getattr__
def __getattr__(name):
    return getattr(_config_mod, name)
