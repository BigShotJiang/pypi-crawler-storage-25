#
#    fluxwallet - Python Cryptocurrency Library
#
#    Multisig 3-of-5 wallet with Mnemonic passphrase keys
#
#    © 2017 November - 1200 Web Development <http://1200wd.com/>
#

from fluxwallet.keys import HDKey
from fluxwallet.mnemonic import Mnemonic
from fluxwallet.secure_mem import secure_wipe

NETWORK = "testnet"
KEY_STRENGHT = 128

words = Mnemonic().generate(KEY_STRENGHT)
print(f"A Mnemonic passphrase has been generated. Please write down and store carefully: \n{words}")
password = input("\nEnter a password if you would like to protect passphrase []: ")

seed = Mnemonic().to_seed(words, password)
try:
    hdkey = HDKey.from_seed(seed, network=NETWORK)
finally:
    secure_wipe(seed)
public_account_wif = hdkey.public_master_multisig()
print(f"\nPrivate key: \n{hdkey.wif_private()}")
# print("Public key: \n%s" % hdkey.wif_public())
print(f"Public account key to share with other cosigners for a multisig BIP45 wallet: \n{public_account_wif.wif()}")
