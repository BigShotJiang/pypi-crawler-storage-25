"""Unified exception hierarchy for fluxwallet.

Every exception raised by fluxwallet inherits from FluxWalletError so callers
can use a single ``except FluxWalletError`` to catch anything the library throws.
"""

from __future__ import annotations

import logging

_logger: logging.Logger = logging.getLogger(__name__)


class FluxWalletError(Exception):
    """Base exception for all fluxwallet errors."""

    def __init__(self, msg: str = "") -> None:
        self.msg = msg
        super().__init__(msg)

    def __str__(self) -> str:
        return self.msg


class ServiceError(FluxWalletError):
    """Service provider error."""

    def __init__(
        self,
        msg: str = "",
        provider_errors: dict[str, str] | None = None,
    ) -> None:
        self.provider_errors: dict[str, str] = provider_errors or {}
        _logger.error(msg)
        super().__init__(msg)

    def __str__(self) -> str:
        return self.msg


class ClientError(ServiceError):
    """HTTP client error from a service provider."""

    def __init__(self, msg: str = "") -> None:
        _logger.warning(msg)
        # Skip ServiceError.__init__ logging (error-level) -- client errors are warnings.
        FluxWalletError.__init__(self, msg)

    def __str__(self) -> str:
        return self.msg


class RelayError(ServiceError):
    """SSP relay communication error."""

    def __init__(self, msg: str = "") -> None:
        _logger.error(msg)
        # Same pattern: skip ServiceError.__init__ to avoid double-logging.
        FluxWalletError.__init__(self, msg)

    def __str__(self) -> str:
        return self.msg
