#
#    fluxwallet - Python Cryptocurrency Library
#    MAIN - Load configs, initialize logging and database
#    © 2017 - 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

import logging

# Do not remove any of the imports below, used by other files
from logging.handlers import RotatingFileHandler

from fluxwallet.config import (
    DEFAULT_WALLET_FILE,
    ENABLE_LOGGING,
    FLUXWALLET_VERSION,
    FW_CONFIG_FILE,
    FW_DATA_DIR,
    FW_LOG_FILE,
    FW_WALLET_DIR,
    LOG_FILE_MAX_BYTES,
    LOGLEVEL,
)

# Initialize logging
logger = logging.getLogger("fluxwallet")
logger.setLevel(LOGLEVEL)

if ENABLE_LOGGING:
    handler = RotatingFileHandler(str(FW_LOG_FILE), maxBytes=LOG_FILE_MAX_BYTES, backupCount=2)
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(funcName)s(%(lineno)d) %(message)s",
        datefmt="%Y/%m/%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    handler.setLevel(LOGLEVEL)
    logger.addHandler(handler)

    _logger = logging.getLogger(__name__)
    logger.info("WELCOME TO fluxwallet - CRYPTOCURRENCY LIBRARY")
    logger.info(f"Version: {FLUXWALLET_VERSION}")
    logger.info(f"Logger name: {logging.__name__}")
    logger.info(f"Read config from: {FW_CONFIG_FILE}")
    logger.debug(f"Wallet directory: {FW_WALLET_DIR}")
    logger.debug(f"Wallet file: {DEFAULT_WALLET_FILE}")
    logger.debug(f"Logging to: {FW_LOG_FILE}")
    logger.info(f"Directory for data files: {FW_DATA_DIR}")


def script_type_default(
    witness_type: str | None = None,
    multisig: bool = False,
    locking_script: bool = False,
) -> str | None:
    """Determine default script type for witness type and key type combination.

    :param witness_type: Witness type, only 'legacy' is supported for Flux
    :type witness_type: str
    :param multisig: Multi-signature key or not, default is False
    :type multisig: bool
    :param locking_script: True for locking scripts, False for unlocking scripts
    :type locking_script: bool
    :return str: Default script type
    """

    if not witness_type:
        return None
    if witness_type == "legacy" and not multisig:
        return "p2pkh" if locking_script else "sig_pubkey"
    if witness_type == "legacy" and multisig:
        return "p2sh" if locking_script else "p2sh_multisig"
    raise ValueError(f"Only legacy witness type is supported. Got: {witness_type}")


def get_encoding_from_witness(witness_type: str | None = None) -> str:
    """Derive address encoding from witness type. Flux only supports base58.

    :param witness_type: Witness type
    :type witness_type: str
    :return str:
    """
    return "base58"
