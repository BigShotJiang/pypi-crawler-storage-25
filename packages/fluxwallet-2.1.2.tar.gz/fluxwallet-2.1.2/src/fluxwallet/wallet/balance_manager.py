"""Balance and UTXO management methods extracted from Wallet.

WalletBalanceManager receives a ``wallet`` reference and delegates shared state
access through ``self._wallet.*``.
"""

from __future__ import annotations

import logging
from datetime import datetime
from itertools import groupby
from operator import itemgetter
from typing import TYPE_CHECKING, Literal, overload

from fluxwallet.config import MAX_TRANSACTIONS
from fluxwallet.main import script_type_default
from fluxwallet.services.core import Service
from fluxwallet.type_guards import is_wallet_key
from fluxwallet.values import Value
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet.models import Utxo
from fluxwallet.wallet.store_access import _get_store, _save_store
from fluxwallet.wallet_store import StoredTransaction, StoredTxOutput

if TYPE_CHECKING:
    from fluxwallet.services.models import ProviderUtxo
    from fluxwallet.wallet.core import Wallet

_logger = logging.getLogger(__name__)


class WalletBalanceManager:
    """Manages balance tracking and UTXO operations for a Wallet."""

    def __init__(self, wallet: Wallet) -> None:
        self._wallet = wallet

    async def balance_update_from_serviceprovider(
        self, account_id: int | None = None, network: str | None = None
    ) -> int:
        """Update balance from service provider."""
        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)
        balance = await Service(
            network=network, providers=self._wallet.providers, cache_uri=self._wallet.db_cache_uri
        ).getbalance(await self._wallet.addresslist(account_id=account_id, network=network))
        if balance:
            new_balance = {
                "account_id": account_id,
                "network": network,
                "balance": balance,
            }
            old_balance_item = [
                bi
                for bi in self._wallet._balances
                if bi["network"] == network and bi["account_id"] == account_id
            ]
            if old_balance_item:
                item_n = self._wallet._balances.index(old_balance_item[0])
                self._wallet._balances[item_n] = new_balance
            else:
                self._wallet._balances.append(new_balance)
        return balance

    @overload
    async def balance(
        self,
        account_id: int | None = None,
        network: str | None = None,
        *,
        as_string: Literal[True],
    ) -> str: ...
    @overload
    async def balance(
        self,
        account_id: int | None = None,
        network: str | None = None,
        as_string: Literal[False] = ...,
    ) -> int: ...
    async def balance(
        self,
        account_id: int | None = None,
        network: str | None = None,
        as_string: bool = False,
    ) -> int | str:
        """Get total of unspent outputs."""
        await self._balance_update(account_id, network)
        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)

        balance = 0
        b_res = [
            b["balance"]
            for b in self._wallet._balances
            if b["account_id"] == account_id and b["network"] == network
        ]
        if len(b_res):
            balance = int(b_res[0])
        if as_string:
            return Value.from_satoshi(balance, network=network).format_unit()
        return balance

    async def _balance_update(
        self,
        account_id: int | None = None,
        network: str | None = None,
        key_id: int | None = None,
        min_confirms: int = 0,
    ) -> list[dict[str, str | int]]:
        """Update balance from UTXO's in store."""
        store = await _get_store()

        # Get all transactions for this wallet
        txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=network,
            min_confirmations=min_confirms if min_confirms else None,
        )

        # Compute per-key balances from unspent outputs
        key_values = []
        for tx in txs:
            if min_confirms and tx.confirmations < min_confirms:
                continue
            for out in tx.outputs:
                if out.spent:
                    continue
                if out.key_id is None:
                    continue
                if key_id is not None and out.key_id != key_id:
                    continue
                k = store.get_key(key_id=out.key_id)
                if k:
                    key_values.append(
                        {
                            "id": out.key_id,
                            "network": tx.network_name,
                            "account_id": tx.account_id,
                            "balance": out.value,
                        }
                    )

        grouper = itemgetter("id", "network", "account_id")
        key_balance_list = []
        for key, grp in groupby(sorted(key_values, key=grouper), grouper):
            nw_acc_dict = dict(zip(["id", "network", "account_id"], key, strict=False))
            nw_acc_dict["balance"] = sum(item["balance"] for item in grp)
            key_balance_list.append(nw_acc_dict)

        grouper = itemgetter("network", "account_id")
        balance_list = []
        for key, grp in groupby(sorted(key_balance_list, key=grouper), grouper):
            nw_acc_dict = dict(zip(["network", "account_id"], key, strict=False))
            nw_acc_dict["balance"] = sum(item["balance"] for item in grp)
            balance_list.append(nw_acc_dict)

        # Add keys with no UTXO's with 0 balance
        utxo_key_ids = {kv["id"] for kv in key_values}
        for skey in await self._wallet.keys(account_id=account_id, network=network, key_id=key_id):
            if skey.id not in utxo_key_ids:
                key_balance_list.append(
                    {
                        "id": skey.id,
                        "network": network,
                        "account_id": skey.account_id,
                        "balance": 0,
                    }
                )

        if not key_id:
            for bl in balance_list:
                bl_item = [
                    b
                    for b in self._wallet._balances
                    if b["network"] == bl["network"] and b["account_id"] == bl["account_id"]
                ]
                if not bl_item:
                    self._wallet._balances.append(bl)
                    continue
                lx = self._wallet._balances.index(bl_item[0])
                self._wallet._balances[lx].update(bl)

        self._wallet._balance = sum(
            [b["balance"] for b in balance_list if b["network"] == self._wallet.network.name]
        )

        # Update key balances in store
        for kb in key_balance_list:
            if kb["id"] in self._wallet._key_objects:
                obj = self._wallet._key_objects[kb["id"]]
                if is_wallet_key(obj):
                    obj._balance = int(kb["balance"])
            sk = store.get_key(key_id=kb["id"])
            if sk:
                sk.balance = kb["balance"]
                store._dirty = True

        await _save_store()

        _logger.info(f"Got balance for {len(key_balance_list)} key(s)")
        return self._wallet._balances

    async def utxos_update(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        networks: list[str] | str | None = None,
        key_id: int | None = None,
        depth: int | None = None,
        change: int | None = None,
        update_balance: bool = True,
        max_utxos: int = MAX_TRANSACTIONS,
    ) -> int:
        """Sync UTXO state from the network.

        The network is the source of truth.
        """
        _, account_id, _ = await self._wallet._get_account_defaults("", account_id, key_id)

        store = await _get_store()
        if key_id:
            single_key = store.get_key(key_id=key_id)
            if not single_key:
                raise WalletError(f"Key with id {key_id} not found")
            networks = [single_key.network_name]
            account_id = single_key.account_id

        if networks is None:
            networks = await self._wallet.network_list()
        elif not isinstance(networks, list):
            networks = [networks]

        count_new = 0
        for network in networks:
            if account_id is None and not self._wallet.multisig:
                accounts = await self._wallet.accounts(network=network)
            else:
                accounts = [account_id]

            for acct_id in accounts:
                d = depth if depth is not None else self._wallet.key_depth
                addresslist = await self._wallet.addresslist(
                    account_id=acct_id,
                    used=used,
                    network=network,
                    key_id=key_id,
                    change=change,
                    depth=d,
                )

                srv = Service(
                    network=network,
                    providers=self._wallet.providers,
                    cache_uri=self._wallet.db_cache_uri,
                )
                network_utxos = await srv.getutxos_multi(
                    addresslist,
                    limit=max_utxos,
                )
                if network_utxos is False:
                    raise WalletError(
                        f"No response from any service provider."
                        " Recovery: check network connectivity."
                        f" Errors: {srv.errors}"
                    )

                self._wallet.last_updated = datetime.now()

                # Build lookup from network response
                network_set: set[tuple[bytes, int]] = set()
                network_lookup: dict[tuple[bytes, int], ProviderUtxo] = {}
                for u in network_utxos:
                    utxo_key = (bytes.fromhex(u.txid), u.output_n)
                    network_set.add(utxo_key)
                    network_lookup[utxo_key] = u

                # Reconcile stored outputs against network
                matched: set[tuple[bytes, int]] = set()
                stored_txs = store.get_transactions(
                    wallet_id=self._wallet.wallet_id,
                    account_id=acct_id,
                    network_name=network,
                )

                for tx in stored_txs:
                    for out in tx.outputs:
                        if out.key_id is None:
                            continue
                        utxo_key = (tx.txid, out.output_n)
                        if utxo_key in network_set:
                            out.spent = False
                            net_u = network_lookup[utxo_key]
                            tx.confirmations = net_u.confirmations
                            tx.status = "confirmed" if tx.confirmations else "unconfirmed"
                            store._dirty = True
                            matched.add(utxo_key)
                        elif not out.spent:
                            out.spent = True
                            store._dirty = True

                # Create stubs for network UTXOs not yet in store
                default_script_type = (
                    script_type_default(
                        self._wallet.witness_type,
                        multisig=self._wallet.multisig,
                        locking_script=True,
                    )
                    or "p2pkh"
                )

                for utxo_key in network_set - matched:
                    u = network_lookup[utxo_key]
                    skey = store.get_key(address=u.address)
                    if not skey or skey.wallet_id != self._wallet.wallet_id:
                        continue

                    skey.used = True
                    status = "confirmed" if u.confirmations else "unconfirmed"

                    tx_record = store.get_transaction(
                        txid=utxo_key[0],
                        wallet_id=self._wallet.wallet_id,
                    )
                    if tx_record is None:
                        tx_record = StoredTransaction(
                            id=0,
                            wallet_id=self._wallet.wallet_id,
                            txid=utxo_key[0],
                            version=4 if network == "flux" else 1,
                            status=status,
                            is_complete=False,
                            block_height=u.block_height,
                            account_id=acct_id,
                            confirmations=u.confirmations,
                            network_name=network,
                        )
                        store.add_transaction(tx_record)

                    tx_record.outputs.append(
                        StoredTxOutput(
                            output_n=u.output_n,
                            value=u.value,
                            key_id=skey.id,
                            address=u.address,
                            script=bytes.fromhex(u.script) if u.script else b"",
                            script_type=default_script_type,
                            spent=False,
                        )
                    )
                    store._dirty = True
                    count_new += 1

                _logger.info(
                    f"UTXO sync: {len(network_set)} from network, {len(matched)} matched, {count_new} new"
                )

                if update_balance:
                    await self._balance_update(
                        account_id=acct_id,
                        network=network,
                        key_id=key_id,
                        min_confirms=0,
                    )

        await _save_store()
        return count_new

    async def utxos(
        self,
        account_id: int | None = None,
        network: str | None = None,
        min_confirms: int = 0,
        key_id: int | list[int] | None = None,
    ) -> list[Utxo]:
        """Get UTXO's from store."""
        first_key_id: int | None = (
            key_id if isinstance(key_id, int) else (key_id[0] if isinstance(key_id, list) and key_id else None)
        )
        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id, first_key_id)

        store = await _get_store()
        txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=network,
            min_confirmations=min_confirms if min_confirms else None,
        )

        res = []
        for tx in txs:
            if min_confirms and tx.confirmations < min_confirms:
                continue
            for out in tx.outputs:
                if out.spent:
                    continue
                if out.key_id is None:
                    continue
                if (
                    isinstance(key_id, int)
                    and out.key_id != key_id
                    or isinstance(key_id, list)
                    and out.key_id not in key_id
                ):
                    continue

                k = store.get_key(key_id=out.key_id)
                if not k:
                    continue

                res.append(
                    Utxo(
                        key_id=out.key_id,
                        output_n=out.output_n,
                        value=out.value,
                        spent=out.spent,
                        script=out.script,
                        script_type=out.script_type,
                        address=k.address,
                        confirmations=int(tx.confirmations),
                        txid=tx.txid.hex(),
                        network_name=tx.network_name,
                        transaction_id=tx.id,
                    )
                )

        res.sort(key=lambda x: x.confirmations, reverse=True)
        return res

    async def utxo_add(
        self,
        address: str,
        value: int,
        txid: str | bytes | int,
        output_n: int,
        confirmations: int = 1,
        script: str = "",
    ) -> None:
        """Add a single UTXO to the wallet store without affecting existing UTXOs."""
        if isinstance(txid, bytes):
            txid_bytes = txid
        elif isinstance(txid, int):
            txid_bytes = bytes.fromhex(format(txid, "064x"))
        else:
            txid_bytes = bytes.fromhex(txid)

        store = await _get_store()
        skey = store.get_key(address=address)
        if not skey or skey.wallet_id != self._wallet.wallet_id:
            raise WalletError(f"Key with address {address} not found in this wallet")

        skey.used = True
        status = "confirmed" if confirmations else "unconfirmed"

        tx_record = store.get_transaction(txid=txid_bytes, wallet_id=self._wallet.wallet_id)
        if tx_record is None:
            tx_record = StoredTransaction(
                id=0,
                wallet_id=self._wallet.wallet_id,
                txid=txid_bytes,
                version=4,
                status=status,
                is_complete=False,
                confirmations=confirmations,
                network_name=self._wallet.network.name,
                account_id=skey.account_id,
            )
            store.add_transaction(tx_record)

        script_type = (
            script_type_default(
                self._wallet.witness_type,
                multisig=self._wallet.multisig,
                locking_script=True,
            )
            or "p2pkh"
        )
        tx_record.outputs.append(
            StoredTxOutput(
                output_n=output_n,
                value=value,
                key_id=skey.id,
                address=address,
                script=bytes.fromhex(script) if script else b"",
                script_type=script_type,
                spent=False,
            )
        )
        store._dirty = True
        await _save_store()

    async def utxo_last(self, address: str) -> str:
        """Get transaction ID for latest utxo for given address."""
        store = await _get_store()
        txs = store.get_transactions(wallet_id=self._wallet.wallet_id)

        best = None
        for tx in txs:
            for out in tx.outputs:
                if out.spent:
                    continue
                k = store.get_key(key_id=out.key_id) if out.key_id else None
                if k and k.address == address and (best is None or tx.confirmations < best[1]):
                    best = (tx.txid.hex(), tx.confirmations)

        return "" if best is None else best[0]
