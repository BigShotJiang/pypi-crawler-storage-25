"""Blockchain scanning and transaction-store methods extracted from Wallet.

WalletScanner receives a ``wallet`` reference and delegates shared state
access through ``self._wallet.*``.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import TYPE_CHECKING, Literal, overload

from fluxwallet.config import MAX_TRANSACTIONS
from fluxwallet.encoding import int_to_varbyteint, to_bytes, to_hexstring, varstr
from fluxwallet.networks import network_defined
from fluxwallet.services.core import Service
from fluxwallet.transactions import FluxTransaction, TransactionMixin
from fluxwallet.type_guards import is_transaction_mixin
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet.key_manager import _coerce_key_type, _KeyType
from fluxwallet.wallet.store_access import _get_store, _save_store
from fluxwallet.wallet.wallet_transaction import WalletTransaction
from fluxwallet.wallet_store import (
    StoredTransaction,
    StoredTxInput,
    StoredTxOutput,
)

if TYPE_CHECKING:
    from fluxwallet.wallet.core import Wallet
    from fluxwallet.wallet.wallet_key import WalletKey

_logger = logging.getLogger(__name__)

# Duplicated here to avoid importing from core at runtime (circular).
AUTH_ONLY_NETWORKS = frozenset({"bitcoin"})


class WalletScanner:
    """Manages blockchain scanning and transaction store operations for a Wallet."""

    def __init__(self, wallet: Wallet) -> None:
        self._wallet = wallet
        self._scanning = False

    # ------------------------------------------------------------------
    # Blockchain scanning
    # ------------------------------------------------------------------

    async def scan_key(
        self,
        key: int | WalletKey,
        update_confirmations: bool = True,
        independent: bool = True,
    ) -> set[str]:
        """Scan for new transactions for specified wallet key."""
        if isinstance(key, int):
            key = await self._wallet.key(key)

        if key.network_name in AUTH_ONLY_NETWORKS or not network_defined(key.network_name):
            return set()

        txs_found = 0
        txids_found = set()

        while True:
            new_txids = await self.transactions_update(key_id=key.key_id, update_confirmations=update_confirmations)
            new_tx_count = len(new_txids)

            _logger.info(f"Scanned key {key.key_id}, {key.address} Found {new_tx_count} new transactions")

            txs_found += new_tx_count
            txids_found.update(new_txids)

            if new_tx_count < MAX_TRANSACTIONS:
                break

        if independent:
            await self.update_input_output_key_ids(tx_ids=list(new_txids))
            await self._wallet._balance_update(key_id=key.key_id)

        return txids_found

    async def scan(
        self,
        scan_gap_limit: int = 5,
        account_id: int | None = None,
        key_type: object = None,
        rescan_used: bool = False,
        network: str | None = None,
        keys_ignore: list[int] | None = None,
        blockcount: int | None = None,
    ) -> set[str]:
        if self._scanning:
            return set()
        self._scanning = True
        try:
            return await self._scan_inner(
                scan_gap_limit, account_id, key_type, rescan_used, network, keys_ignore, blockcount
            )
        finally:
            self._scanning = False

    async def _scan_inner(
        self,
        scan_gap_limit: int,
        account_id: int | None,
        key_type: object,
        rescan_used: bool,
        network: str | None,
        keys_ignore: list[int] | None,
        blockcount: int | None,
    ) -> set[str]:
        kt = _coerce_key_type(key_type) if key_type is not None else _KeyType.ANY

        if not keys_ignore:
            keys_ignore = []

        background_tasks = []

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)

        if network != "flux":
            return set()
        if self._wallet.scheme != "bip32" and self._wallet.scheme != "multisig" and scan_gap_limit < 2:
            raise WalletError(
                "The wallet scan() method is only available for"
                " BIP32 wallets. Recovery: use a BIP32 (HD) wallet"
            )

        srv = Service(
            network=network,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )

        if blockcount:
            await srv.store_blockcount(blockcount)
        else:
            blockcount = await srv.blockcount()

        _logger.info(
            "Current height: %d, last scanned height: %d",
            blockcount,
            self._wallet.last_scanned_height,
        )
        if not rescan_used and not blockcount > self._wallet.last_scanned_height:
            return set()

        self._wallet.last_scanned_height = blockcount

        store = await _get_store()
        txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            network_name=network,
        )
        self._wallet.processed_txids = {t.txid.hex() if isinstance(t.txid, bytes) else str(t.txid) for t in txs}

        unconfirmed_txids = [t.txid for t in txs if t.confirmations == 0]

        if not self._wallet.discovered:
            self._wallet.discovered = True
            sw = store.get_wallet(wallet_id=self._wallet.wallet_id)
            if sw:
                sw.discovered = True
                store._dirty = True
            await _save_store()

        if self._wallet.processed_txids:
            background_tasks.append(asyncio.create_task(self.transactions_update_confirmations()))

        if unconfirmed_txids:
            background_tasks.append(asyncio.create_task(self.transactions_update_by_txids(unconfirmed_txids)))

        key_types = [_KeyType.PAYMENT, _KeyType.CHANGE] if kt == _KeyType.ANY else [kt]

        counter = 0
        new_transactions = set()

        first_loop = True
        while True:
            force = True
            if first_loop:
                first_loop = False
                force = False

            if self._wallet.scheme == "single":
                all_addr_keys = await self._wallet.keys_addresses()
                page = all_addr_keys[counter : counter + scan_gap_limit]
                keys_to_scan = [await self._wallet.key(k.id) for k in page]
                counter += scan_gap_limit
            else:
                keys_to_scan = []
                for k_type in key_types:
                    keys_to_scan.extend(
                        await self._wallet.get_keys(
                            account_id,
                            network,
                            number_of_keys=scan_gap_limit,
                            key_type=k_type,
                            force_create=force,
                        )
                    )

            scan_tasks = []

            for key in keys_to_scan:
                if key.key_id in keys_ignore:
                    continue

                keys_ignore.append(key.key_id)

                scan_tasks.append(
                    asyncio.create_task(self.scan_key(key, update_confirmations=False, independent=False))
                )

            raw_results = await asyncio.gather(*scan_tasks, return_exceptions=True)

            results: list[set[str]] = []
            for r in raw_results:
                if isinstance(r, BaseException):
                    _logger.warning("scan_key failed: %s", r)
                else:
                    results.append(r)

            if not any(results):
                break

            merged = set.union(*results)
            new_transactions.update(merged)

        await self.update_input_output_key_ids(account_id, network)
        await self._wallet._balance_update(account_id, network)
        await asyncio.gather(*background_tasks, return_exceptions=True)

        return new_transactions

    async def scan_existing(
        self,
        scan_gap_limit: int = 5,
        account_id: int | None = None,
        change: bool | None = None,
        rescan_used: bool = False,
        network: str | None = None,
        keys_ignore: list[int] | None = None,
        blockcount: int | None = None,
    ) -> set[str]:
        """Scan existing keys for new transactions."""
        if network != "flux":
            return set()

        if not keys_ignore:
            keys_ignore = []

        background_tasks = []

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)
        if self._wallet.scheme != "bip32" and self._wallet.scheme != "multisig" and scan_gap_limit < 2:
            raise WalletError(
                "The wallet scan() method is only available for"
                " BIP32 wallets. Recovery: use a BIP32 (HD) wallet"
            )

        srv = Service(
            network=network,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )

        if blockcount:
            await srv.store_blockcount(blockcount)
        else:
            blockcount = await srv.blockcount()

        _logger.info(
            "Current height: %d, last scanned height: %d",
            blockcount,
            self._wallet.last_scanned_height,
        )
        if not rescan_used and not blockcount > self._wallet.last_scanned_height:
            return set()

        self._wallet.last_scanned_height = blockcount

        background_tasks.append(asyncio.create_task(self.transactions_update_confirmations()))

        if rescan_used:
            used_keys = await self._wallet.keys_addresses(
                account_id=account_id, change=change, network=network, used=True,
            )
            for key in used_keys:
                _logger.debug("Rescanning used key %s", key)
                background_tasks.append(
                    asyncio.create_task(self.scan_key(key.id, update_confirmations=False))
                )

        store = await _get_store()
        txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            network_name=network,
        )
        unconfirmed_txids = [t.txid for t in txs if t.confirmations == 0]

        if unconfirmed_txids:
            background_tasks.append(asyncio.create_task(self.transactions_update_by_txids(unconfirmed_txids)))

        change_range = [0, 1] if change is None else [change]

        _logger.debug("Change range: %s", change_range)

        counter = 0
        new_transactions = set()

        while True:
            if self._wallet.scheme == "single":
                all_addr_keys2 = await self._wallet.keys_addresses()
                page = all_addr_keys2[counter : counter + scan_gap_limit]
                keys_to_scan = [await self._wallet.key(k.id) for k in page]
                counter += scan_gap_limit
            else:
                keys_to_scan = []
                for change_type in change_range:
                    keys_to_scan.extend(
                        await self._wallet.get_keys(
                            account_id,
                            network,
                            number_of_keys=scan_gap_limit,
                            key_type=_KeyType(change_type) if isinstance(change_type, int) else _KeyType.PAYMENT,
                        )
                    )

            scan_tasks = []

            for key in keys_to_scan:
                if key.key_id in keys_ignore:
                    continue

                keys_ignore.append(key.key_id)

                scan_tasks.append(asyncio.create_task(self.scan_key(key, update_confirmations=False)))

            results: list[set[str]] = await asyncio.gather(*scan_tasks)

            if not any(results):
                break

            merged2 = set.union(*results)
            new_transactions.update(merged2)

        await asyncio.gather(*background_tasks)

        return new_transactions

    # ------------------------------------------------------------------
    # Transaction store updates (used by scanning)
    # ------------------------------------------------------------------

    async def transactions_update(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        key_id: int | None = None,
        depth: int | None = None,
        change: int | None = None,
        limit: int = MAX_TRANSACTIONS,
        update_confirmations: bool = True,
    ) -> set[int]:
        """Update wallet transactions from service providers."""

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id, key_id)

        if depth is None:
            depth = self._wallet.key_depth

        if update_confirmations:
            await self.transactions_update_confirmations()

        srv = Service(
            network=network,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )

        addresslist = await self._wallet.addresslist(
            account_id=account_id,
            used=used,
            network=network,
            key_id=key_id,
            change=change,
            depth=depth,
        )

        self._wallet.last_updated = datetime.now()

        new_txids = set()

        store = await _get_store()

        for address in addresslist:
            tx_count = 0

            last_tx_index = int(await self.transaction_last(address, by_index=True))
            tx_generator = srv.get_transactions_by_address(
                address,
                limit=limit,
                after_tx_index=last_tx_index,
            )

            utxo_set = set()

            async for txs in tx_generator:
                tx_count += len(txs)

                wallet_txs = []
                for tx in txs:
                    if self._wallet.processed_txids is None:
                        self._wallet.processed_txids = set()
                    if tx.txid not in self._wallet.processed_txids:
                        self._wallet.processed_txids.add(tx.txid)

                        if is_transaction_mixin(tx):
                            wallet_txs.append(WalletTransaction(self._wallet, tx, addresslist=addresslist))

                utxos, tx_ids = await self.store_transactions(wallet_txs)
                utxo_set.update(utxos)
                new_txids.update(tx_ids)

            for utxo in utxo_set:
                existing_tx = store.get_transaction(txid=bytes.fromhex(utxo[0]), wallet_id=self._wallet.wallet_id)
                if existing_tx:
                    for out in existing_tx.outputs:
                        if out.output_n == utxo[1] and not out.spent:
                            out.spent = True
                            store._dirty = True

            if tx_count:
                sk = store.get_key(address=address)
                if sk and sk.wallet_id == self._wallet.wallet_id:
                    sk.latest_tx_index = tx_count + last_tx_index
                    store._dirty = True

            await _save_store()

        return new_txids

    async def transactions_update_confirmations(self) -> None:
        """Update number of confirmations and status for transactions in store."""
        network = self._wallet.network.name

        srv = Service(
            network=network,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )
        blockcount = await srv.blockcount()
        store = await _get_store()
        txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            network_name=network,
        )

        for tx in txs:
            if tx.block_height and tx.block_height > 0:
                tx.confirmations = blockcount - tx.block_height
                store._dirty = True

        await _save_store()

    async def transactions_update_by_txids(self, txids: list[bytes] | bytes) -> None:
        """Update transactions with provided transaction IDs."""
        if not isinstance(txids, list):
            txids = [txids]

        srv = Service(
            network=self._wallet.network.name,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )
        txids_hexstrings = [to_hexstring(x) for x in txids]
        txs = await srv.get_transactions(txids_hexstrings)

        utxo_set = set()
        for t in txs:
            wt = await WalletTransaction.create(self._wallet, t)
            await wt.store()

            utxos = [(ti.prev_txid.hex(), ti.output_n_int) for ti in wt.tx.inputs]
            utxo_set.update(utxos)

        store = await _get_store()
        for utxo in list(utxo_set):
            tx = store.get_transaction(txid=bytes.fromhex(utxo[0]))
            if tx:
                for out in tx.outputs:
                    if out.output_n == utxo[1] and not out.spent:
                        out.spent = True
                        store._dirty = True

        await _save_store()

    async def update_input_output_key_ids(
        self,
        account_id: int | None = None,
        network: str | None = None,
        *,
        tx_ids: list[int] | None = None,
    ) -> None:
        store = await _get_store()

        if tx_ids:
            txs = [store.transactions[tid] for tid in tx_ids if tid in store.transactions]
        else:
            txs = store.get_transactions(
                wallet_id=self._wallet.wallet_id,
                account_id=account_id,
                network_name=network,
            )

        for tx in txs:
            for inp in tx.inputs:
                k = store.get_key(address=inp.address)
                if k and k.wallet_id == self._wallet.wallet_id:
                    inp.key_id = k.id
                    k.used = True
                    store._dirty = True

            for out in tx.outputs:
                k = store.get_key(address=out.address)
                if k and k.wallet_id == self._wallet.wallet_id:
                    out.key_id = k.id
                    k.used = True
                    store._dirty = True

        await _save_store()

    async def store_transactions(self, txs: list[WalletTransaction]) -> tuple[set[tuple[str, int]], set[int]]:
        utxo_set = set()
        tx_ids = set()

        store = await _get_store()

        for wt in txs:
            version = 4 if wt.tx.network.name == "flux" else 1

            # Check if already exists
            existing = store.get_transaction(
                txid=bytes.fromhex(wt.tx.txid),
                wallet_id=self._wallet.wallet_id,
            )
            if existing:
                continue

            new_tx = StoredTransaction(
                id=0,
                wallet_id=self._wallet.wallet_id,
                version=version,
                txid=bytes.fromhex(wt.tx.txid),
                block_height=wt.tx.block_height,
                size=wt.tx.size or 0,
                confirmations=wt.tx.confirmations or 0,
                date=wt.tx.date if wt.tx.date else datetime.now(),
                fee=wt.tx.fee or 0,
                status=wt.status,
                input_total=wt.tx.input_total,
                output_total=wt.tx.output_total,
                network_name=wt.tx.network.name,
                raw=wt.tx.rawtx,
                verified=wt.tx.verified,
                account_id=wt.account_id,
                coinbase=wt.tx.coinbase,
                expiry_height=wt.tx.expiry_height,
            )

            for ti in wt.tx.inputs:
                witnesses = int_to_varbyteint(len(ti.witnesses)) + b"".join([bytes(varstr(w)) for w in ti.witnesses])

                new_tx.inputs.append(
                    StoredTxInput(
                        index_n=ti.index_n,
                        output_n=ti.output_n_int,
                        key_id=None,
                        value=ti.value,
                        prev_txid=ti.prev_txid,
                        double_spend=ti.double_spend,
                        script=ti.unlocking_script,
                        script_type=ti.script_type or "",
                        witness_type=ti.witness_type or "",
                        sequence=ti.sequence,
                        address=ti.address,
                        witnesses=witnesses,
                    )
                )

            for to in wt.tx.outputs:
                new_tx.outputs.append(
                    StoredTxOutput(
                        output_n=to.output_n,
                        key_id=None,
                        address=to.address,
                        value=to.value,
                        spent=to.spent,
                        script=to.lock_script,
                        script_type=to.script_type or "",
                    )
                )

            txidn = store.add_transaction(new_tx)
            tx_ids.add(txidn)

            for ti in wt.tx.inputs:
                utxo_set.add((ti.prev_txid.hex(), ti.output_n_int))

        await _save_store()
        return (utxo_set, tx_ids)

    async def create_and_store_wallet_tx(self, tx: TransactionMixin, addresslist: list[str]) -> set[tuple[str, int]]:
        wt = WalletTransaction(self._wallet, tx, addresslist=addresslist)
        await wt.store()

        return {(ti.prev_txid.hex(), ti.output_n_int) for ti in wt.tx.inputs}

    # ------------------------------------------------------------------
    # Transaction query (read-only)
    # ------------------------------------------------------------------

    @overload
    async def transactions(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        *,
        as_dict: Literal[True],
    ) -> list[dict[str, object]]: ...
    @overload
    async def transactions(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        *,
        as_dict: Literal[False] = ...,
    ) -> list[WalletTransaction[FluxTransaction]]: ...
    async def transactions(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        as_dict: bool = False,
    ) -> list[WalletTransaction[FluxTransaction]] | list[dict[str, object]]:
        """Get all known transactions for this wallet."""

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id, key_id)

        store = await _get_store()
        all_txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=network,
        )

        if not include_new:
            all_txs = [t for t in all_txs if t.status in ("confirmed", "unconfirmed")]

        # Build combined list of inputs and outputs that belong to wallet keys
        txs = []
        for tx in all_txs:
            for inp in tx.inputs:
                if inp.key_id is None:
                    continue
                k = store.get_key(key_id=inp.key_id)
                if not k or k.wallet_id != self._wallet.wallet_id:
                    continue
                if key_id is not None and inp.key_id != key_id:
                    continue
                txs.append(("input", inp, tx))

            for out in tx.outputs:
                if out.key_id is None:
                    continue
                k = store.get_key(key_id=out.key_id)
                if not k or k.wallet_id != self._wallet.wallet_id:
                    continue
                if key_id is not None and out.key_id != key_id:
                    continue
                txs.append(("output", out, tx))

        # Sort by confirmations (ascending = most confirmed first when reversed),
        # then by tx.id descending, then by txid
        txs.sort(
            key=lambda k: (k[2].confirmations, pow(10, 20) - k[2].id, k[2].txid),
            reverse=True,
        )

        res = []
        txids = []
        for kind, item, tx in txs:
            txid = tx.txid.hex()
            if as_dict:
                if kind == "input":
                    u = {
                        "index_n": item.index_n,
                        "key_id": item.key_id,
                        "address": item.address,
                        "value": -item.value,
                        "prev_txid": item.prev_txid,
                        "output_n": item.output_n,
                        "script": item.script,
                        "script_type": item.script_type,
                        "is_output": True,
                        "block_height": tx.block_height,
                        "date": tx.date,
                    }
                else:
                    u = {
                        "key_id": item.key_id,
                        "address": item.address,
                        "value": item.value,
                        "output_n": item.output_n,
                        "script": item.script,
                        "script_type": item.script_type,
                        "spent": item.spent,
                        "is_output": False,
                        "block_height": tx.block_height,
                        "date": tx.date,
                    }
                u["confirmations"] = None if tx.confirmations is None else int(tx.confirmations)
                u["txid"] = txid
                u["network_name"] = tx.network_name
                u["status"] = tx.status
                u["transaction_id"] = tx.id
            else:
                if txid in txids:
                    continue
                txids.append(txid)
                u = await self.transaction(txid)
            res.append(u)

        return res

    async def transactions_full(
        self,
        network: str | None = None,
        include_new: bool = False,
        limit: int = 0,
        offset: int = 0,
    ) -> list[WalletTransaction]:
        """Get all transactions of this wallet as WalletTransaction objects."""
        network, _, _ = await self._wallet._get_account_defaults(network)
        addresslist = await self._wallet.addresslist()

        store = await _get_store()
        all_txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            network_name=network,
        )

        if not include_new:
            all_txs = [t for t in all_txs if t.status in ("confirmed", "unconfirmed")]

        # Sort by date descending
        all_txs.sort(key=lambda t: t.date if t.date else datetime.min, reverse=True)

        if offset:
            all_txs = all_txs[offset:]
        if limit:
            all_txs = all_txs[:limit]

        sem = asyncio.Semaphore(5)

        async def _fetch(txid_hex: str) -> WalletTransaction | None:
            async with sem:
                return await self.transaction(txid_hex, addresslist)

        tasks = [_fetch(tx.txid.hex()) for tx in all_txs]
        results = await asyncio.gather(*tasks)
        return [t for t in results if t is not None]

    async def transactions_export(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        skip_change: bool = True,
    ) -> list[tuple[object, ...]]:
        """Export wallet transactions as list of tuples."""
        txs_tuples = []
        cumulative_value = 0
        for t in await self.transactions(account_id, network, include_new, key_id):
            if not isinstance(t, WalletTransaction):
                continue
            te = await t.export(skip_change=skip_change)

            if t.outgoing_tx:
                tx_obj = t.tx
                tx_fee = tx_obj.fee if isinstance(tx_obj, TransactionMixin) else 0
                cumulative_value -= tx_fee or 0

            for tei in te:
                addr_list_in = tei[3] if isinstance(tei[3], list) else [tei[3]]
                addr_list_out = tei[4] if isinstance(tei[4], list) else [tei[4]]
                cumulative_value += tei[5]
                txs_tuples.append(
                    (
                        tei[0],
                        tei[1],
                        tei[2],
                        addr_list_in,
                        addr_list_out,
                        tei[5],
                        cumulative_value,
                        tei[6],
                    )
                )
        return txs_tuples

    async def transaction(self, txid: str, addresslist: list[str] | None = None) -> WalletTransaction | None:
        """Get WalletTransaction object for given transaction ID."""
        return await WalletTransaction.from_txid(self._wallet, txid, addresslist)

    @overload
    async def transaction_last(self, address: str, by_index: Literal[True]) -> int: ...
    @overload
    async def transaction_last(self, address: str, by_index: Literal[False] = ...) -> str: ...
    async def transaction_last(self, address: str, by_index: bool = False) -> str | int:
        """Get transaction ID or index for latest transaction for given address."""
        store = await _get_store()
        sk = store.get_key(address=address)
        if not sk or sk.wallet_id != self._wallet.wallet_id:
            return 0 if by_index else ""

        if by_index:
            return sk.latest_tx_index if sk.latest_tx_index else 0
        return "" if not sk.latest_txid else sk.latest_txid.hex()

    async def transaction_spent(self, txid: str, output_n: int | bytes) -> str | None:
        """Check if transaction output is spent, return spending txid."""
        txid_bytes = to_bytes(txid)

        if isinstance(output_n, bytes):
            output_n = int.from_bytes(output_n, "big")

        store = await _get_store()
        txs = store.get_transactions(wallet_id=self._wallet.wallet_id)
        for tx in txs:
            for inp in tx.inputs:
                if inp.prev_txid == txid_bytes and inp.output_n == output_n:
                    return tx.txid.hex()
        return None
