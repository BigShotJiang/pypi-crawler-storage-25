from __future__ import annotations

import logging
from typing import Literal, overload

from fluxwallet.config import DEFAULT_NETWORK, DEFAULT_WITNESS_TYPE
from fluxwallet.keys import Address, HDKey
from fluxwallet.main import get_encoding_from_witness, script_type_default
from fluxwallet.networks import Network
from fluxwallet.type_guards import is_hdkey, is_network
from fluxwallet.values import Value
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet_store import StoredKey, WalletStore

_logger: logging.Logger = logging.getLogger(__name__)


class WalletKey:
    """Wraps an HDKey with persistent wallet metadata (StoredKey).

    All WalletKeys are stored via WalletStore.
    """

    @staticmethod
    def from_stored_key(stored_key: StoredKey, *, hdkey: HDKey | None = None) -> WalletKey:
        return WalletKey(stored_key, hdkey)

    @staticmethod
    def from_hdkey(
        name: str,
        wallet_id: int,
        store: WalletStore,
        *,
        key: HDKey | Address | str | bytes | None = None,
        account_id: int = 0,
        network: str | None = None,
        change: int = 0,
        purpose: int = 44,
        parent_id: int = 0,
        path: str = "m",
        key_type: str,
        encoding: str | None = None,
        witness_type: str | None = DEFAULT_WITNESS_TYPE,
        multisig: bool = False,
        cosigner_id: int | None = None,
    ) -> WalletKey:
        """Create WalletKey from an HDKey object or raw key material.

        Normally called by the Wallet class, not directly.

        :return WalletKey:
        """
        # Resolve the key to either an HDKey or an Address
        if isinstance(key, HDKey):
            hd_key: HDKey = key
            if network is None:
                network = hd_key.network.name
            elif network != hd_key.network.name:
                raise WalletError("Specified network and key network should be the same")
            return WalletKey._from_hdkey_resolved(
                name,
                wallet_id,
                store,
                hd_key,
                account_id=account_id,
                network=network,
                change=change,
                purpose=purpose,
                parent_id=parent_id,
                path=path,
                key_type=key_type,
                encoding=encoding,
                witness_type=witness_type,
                multisig=multisig,
                cosigner_id=cosigner_id,
            )
        if isinstance(key, Address):
            addr_key: Address = key
            if network is None:
                network = addr_key.network.name if is_network(addr_key.network) else str(addr_key.network)
            elif network != (addr_key.network.name if is_network(addr_key.network) else str(addr_key.network)):
                raise WalletError("Specified network and key network should be the same")
            return WalletKey._from_address_resolved(
                name,
                wallet_id,
                store,
                addr_key,
                account_id=account_id,
                network=network,
                change=change,
                purpose=purpose,
                parent_id=parent_id,
                path=path,
                key_type=key_type,
                encoding=encoding,
                witness_type=witness_type,
                multisig=multisig,
                cosigner_id=cosigner_id,
            )
        if network is None:
            network = DEFAULT_NETWORK
        hd_key = HDKey(import_key=key, network=network)
        return WalletKey._from_hdkey_resolved(
            name,
            wallet_id,
            store,
            hd_key,
            account_id=account_id,
            network=network,
            change=change,
            purpose=purpose,
            parent_id=parent_id,
            path=path,
            key_type=key_type,
            encoding=encoding,
            witness_type=witness_type,
            multisig=multisig,
            cosigner_id=cosigner_id,
        )

    @staticmethod
    def _from_hdkey_resolved(
        name: str,
        wallet_id: int,
        store: WalletStore,
        hd_key: HDKey,
        *,
        account_id: int = 0,
        network: str | None = None,
        change: int = 0,
        purpose: int = 44,
        parent_id: int = 0,
        path: str = "m",
        key_type: str,
        encoding: str | None = None,
        witness_type: str | None = DEFAULT_WITNESS_TYPE,
        multisig: bool = False,
        cosigner_id: int | None = None,
    ) -> WalletKey:
        """Create WalletKey from a resolved HDKey."""
        if not encoding and witness_type:
            encoding = get_encoding_from_witness(witness_type)

        script_type: str = script_type_default(witness_type, multisig) or "p2pkh"

        resolved_network: str = network if network is not None else DEFAULT_NETWORK

        wif_private: str = hd_key.wif(witness_type=witness_type, multisig=multisig, is_private=True)
        existing: StoredKey | None = store.get_key(wif=wif_private)
        if existing and existing.wallet_id == wallet_id:
            _logger.warning(f"Key already exists in this wallet. Key ID: {existing.id}")
            return WalletKey(existing, hd_key)

        if key_type != "single" and hd_key.depth != len(path.split("/")) - 1 and path == "m" and hd_key.depth > 1:
            path = "M"

        address: str = hd_key.address(encoding=encoding, script_type=script_type)

        wif_public: str = hd_key.wif(witness_type=witness_type, multisig=multisig, is_private=False)
        existing_by_addr: StoredKey | None = store.get_key(address=address)
        existing_by_wif: StoredKey | None = store.get_key(wif=wif_public)

        existing_by_pub: StoredKey | None = None
        for k in store.get_keys(wallet_id):
            if k.public and k.public == hd_key.public_byte:
                existing_by_pub = k
                break

        stored_key: StoredKey | None = existing_by_addr or existing_by_wif or existing_by_pub
        if stored_key and stored_key.wallet_id == wallet_id:
            stored_key.wif = wif_private
            stored_key.is_private = True
            stored_key.private = hd_key.private_byte
            stored_key.public = hd_key.public_byte
            stored_key.path = path
            store._dirty = True
            return WalletKey(stored_key, hd_key)

        new_key: StoredKey = StoredKey(
            id=0,  # assigned by store.add_key()
            wallet_id=wallet_id,
            name=name[:80],
            public=hd_key.public_byte,
            private=hd_key.private_byte,
            purpose=purpose,
            account_id=account_id,
            depth=hd_key.depth if hd_key.depth is not None else 0,
            change=change,
            address_index=hd_key.child_index,
            wif=wif_private,
            address=address,
            parent_id=parent_id,
            compressed=hd_key.compressed if hd_key.compressed is not None else True,
            is_private=hd_key.is_private if hd_key.is_private is not None else False,
            path=path,
            key_type=key_type,
            network_name=resolved_network,
            encoding=encoding or "",
            cosigner_id=cosigner_id,
        )

        store.add_key(new_key)
        return WalletKey(new_key, hd_key)

    @staticmethod
    def _from_address_resolved(
        name: str,
        wallet_id: int,
        store: WalletStore,
        addr_key: Address,
        *,
        account_id: int = 0,
        network: str | None = None,
        change: int = 0,
        purpose: int = 44,
        parent_id: int = 0,
        path: str = "m",
        key_type: str,
        encoding: str | None = None,
        witness_type: str | None = DEFAULT_WITNESS_TYPE,
        multisig: bool = False,
        cosigner_id: int | None = None,
    ) -> WalletKey:
        """Create WalletKey from a resolved Address."""
        if not encoding and witness_type:
            encoding = get_encoding_from_witness(witness_type)

        resolved_network: str = network if network is not None else DEFAULT_NETWORK

        existing: StoredKey | None = store.get_key(address=addr_key.address)
        if existing and existing.wallet_id == wallet_id:
            _logger.warning(f"Key with ID {existing.id} already exists")
            return WalletKey(existing)

        new_key: StoredKey = StoredKey(
            id=0,
            wallet_id=wallet_id,
            name=name[:80],
            purpose=purpose,
            account_id=account_id,
            depth=addr_key.depth if addr_key.depth is not None else 0,
            change=change,
            address=addr_key.address,
            parent_id=parent_id,
            compressed=addr_key.compressed if addr_key.compressed is not None else True,
            is_private=False,
            path=path,
            key_type=key_type,
            network_name=resolved_network,
            encoding=encoding or "",
            cosigner_id=cosigner_id,
        )

        store.add_key(new_key)
        return WalletKey(new_key)

    def __init__(self, stored_key: StoredKey, hdkey: HDKey | None = None) -> None:
        self._stored_key: StoredKey = stored_key
        self.hdkey: HDKey | None = hdkey

        if hdkey and is_hdkey(hdkey):
            if self._stored_key.public and self._stored_key.public != hdkey.public_byte:
                raise ValueError("Public key mismatch between store and HDKey")
            if self._stored_key.private and self._stored_key.private != hdkey.private_byte:
                raise ValueError("Private key mismatch between store and HDKey")

        self.key_id: int = self._stored_key.id
        self._name: str = self._stored_key.name
        self.wallet_id: int = self._stored_key.wallet_id
        self.key_public: bytes | None = self._stored_key.public or None
        self.key_private: bytes | None = self._stored_key.private or None
        self.account_id: int = self._stored_key.account_id
        self.change: int = self._stored_key.change
        self.address_index: int = self._stored_key.address_index
        self.wif: str | None = self._stored_key.wif
        self.address: str = self._stored_key.address
        self._balance: int = self._stored_key.balance
        self.purpose: int = self._stored_key.purpose
        self.parent_id: int | None = self._stored_key.parent_id
        self.is_private: bool = self._stored_key.is_private
        self.path: str = self._stored_key.path
        self.network_name: str = self._stored_key.network_name
        self.network: Network | None = Network(self.network_name) if self.network_name else None
        self.depth: int = self._stored_key.depth
        self.key_type: str = self._stored_key.key_type
        self.compressed: bool = self._stored_key.compressed
        self.encoding: str = self._stored_key.encoding
        self.cosigner_id: int | None = self._stored_key.cosigner_id
        self.used: bool = self._stored_key.used

    def __repr__(self) -> str:
        return f"<WalletKey(key_id={self.key_id}, name={self.name}, address={self.address}, path={self.path})>"

    @property
    def name(self) -> str:
        return self._name

    @property
    def stored_key(self) -> StoredKey:
        """Access the underlying StoredKey dataclass."""
        return self._stored_key

    def key(self) -> HDKey | None:
        """Get single HDKey for this wallet key."""
        if self.key_type == "multisig":
            raise WalletError("Use multisig_keys() for multisig wallet keys")
        if self.wif:
            self.hdkey = HDKey.from_wif(self.wif, network=self.network_name, compressed=self.compressed)
            return self.hdkey
        return None

    def multisig_keys(self) -> list[HDKey]:
        """Get child HDKeys for multisig key.

        Returns empty list if none found.
        """
        keys: list[HDKey] = []
        for _child_key_id, _order in self._stored_key.multisig_children:
            pass  # placeholder -- actual resolution needs store
        return keys

    def key_from_store(self, store: WalletStore) -> HDKey | None:
        """Get single HDKey, resolving from store if needed."""
        if self.key_type == "multisig":
            raise WalletError("Use multisig_keys_from_store() for multisig wallet keys")
        if self.wif:
            self.hdkey = HDKey.from_wif(self.wif, network=self.network_name, compressed=self.compressed)
            return self.hdkey
        return None

    def multisig_keys_from_store(self, store: WalletStore) -> list[HDKey]:
        """Get child HDKeys for multisig, resolving from store."""
        keys: list[HDKey] = []
        for child_key_id, _order in self._stored_key.multisig_children:
            child: StoredKey | None = store.get_key(key_id=child_key_id)
            if child and child.wif:
                keys.append(
                    HDKey.from_wif(
                        child.wif,
                        network=child.network_name,
                        compressed=self.compressed,
                    )
                )
        return keys

    @overload
    def balance(self, as_string: Literal[True]) -> str: ...
    @overload
    def balance(self, as_string: Literal[False] = ...) -> int: ...
    def balance(self, as_string: bool = False) -> int | str:
        """Get total value of unspent outputs.

        :param as_string: Return a string in currency format
        :type as_string: bool :return float, str: Key balance
        """
        if as_string:
            return Value.from_satoshi(self._balance, network=self.network or DEFAULT_NETWORK).format_unit()
        return self._balance

    def public(self) -> WalletKey:
        """Return current key as public WalletKey with private info removed."""
        pub_key: WalletKey = self
        pub_key.is_private = False
        pub_key.key_private = None

        k = self.key()
        if is_hdkey(k):
            pub_key.wif = k.wif()
        if is_hdkey(self.hdkey):
            self.hdkey = self.hdkey.public()

        return pub_key

    def as_dict(self, include_private: bool = False) -> dict[str, int | str | bool | None]:
        """Return current key information as dictionary."""
        kdict: dict[str, int | str | bool | None] = {
            "id": self.key_id,
            "key_type": self.key_type,
            "network": self.network.name if self.network else "",
            "is_private": self.is_private,
            "name": self.name,
            "key_public": "" if not self.key_public else self.key_public.hex(),
            "account_id": self.account_id,
            "parent_id": self.parent_id,
            "depth": self.depth,
            "change": self.change,
            "address_index": self.address_index,
            "address": self.address,
            "encoding": self.encoding,
            "path": self.path,
            "balance": self.balance(),
            "balance_str": self.balance(as_string=True),
        }
        if include_private:
            kdict.update(
                {
                    "key_private": self.key_private.hex() if self.key_private else "",
                    "wif": self.wif,
                }
            )
        return kdict
