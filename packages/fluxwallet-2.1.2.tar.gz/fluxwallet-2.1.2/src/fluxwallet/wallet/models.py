"""Shared data models for the wallet package."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Utxo:
    """An unspent transaction output available for spending."""

    key_id: int
    output_n: int
    value: int
    spent: bool
    script: bytes | None
    script_type: str
    address: str
    confirmations: int
    txid: str
    network_name: str
    transaction_id: int
