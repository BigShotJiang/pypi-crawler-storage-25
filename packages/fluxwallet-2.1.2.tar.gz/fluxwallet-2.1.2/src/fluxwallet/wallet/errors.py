from __future__ import annotations

import logging

from fluxwallet.exceptions import FluxWalletError

_logger = logging.getLogger(__name__)


class WalletError(FluxWalletError):
    """Handle Wallet class Exceptions."""

    def __init__(self, msg: str = "") -> None:
        _logger.error(msg)
        super().__init__(msg)
