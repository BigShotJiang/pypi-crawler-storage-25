"""Key management methods extracted from Wallet.

WalletKeyManager receives a ``wallet`` reference and delegates shared state
access through ``self._wallet.*``.
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import TYPE_CHECKING

from fluxwallet.config import (
    DEFAULT_NETWORK,
    WALLET_KEY_STRUCTURES,
)
from fluxwallet.encoding import bech32_encode
from fluxwallet.keys import (
    Address,
    BKeyError,
    HDKey,
    Key,
    check_network_and_key,
    path_expand,
)
from fluxwallet.mnemonic import Mnemonic
from fluxwallet.networks import Network
from fluxwallet.sapling import SHIELDED_AVAILABLE
from fluxwallet.scripts import Script
from fluxwallet.secure_mem import secure_wipe
from fluxwallet.type_guards import is_hdkey, is_network, is_wallet_key
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet.store_access import _get_store, _mgr, _save_store
from fluxwallet.wallet.wallet_key import WalletKey
from fluxwallet.wallet_store import StoredKey

if TYPE_CHECKING:
    from fluxwallet.wallet.core import Wallet


class _KeyType(Enum):
    """Mirror of core.KeyType to avoid circular imports."""

    PAYMENT = 0
    CHANGE = 1
    ANY = None

_logger = logging.getLogger(__name__)

# Duplicated from core.py so the manager can reference it without importing Wallet.
AUTH_ONLY_NETWORKS = frozenset({"bitcoin"})


def _normalize_path(path: str) -> str:
    """Normalize BIP0044 key path for HD keys."""
    levels = path.split("/")
    npath = ""
    for level in levels:
        if not level:
            raise WalletError("Could not parse path. Index is empty.")
        nlevel = level
        if level[-1] in "'HhPp":
            nlevel = level[:-1] + "'"
        npath += nlevel + "/"
    if npath[-1] == "/":
        npath = npath[:-1]
    return npath


def _coerce_key_type(kt: object) -> _KeyType:
    """Accept either _KeyType or core.KeyType and return _KeyType."""
    if isinstance(kt, _KeyType):
        return kt
    # Duck-type: core.KeyType has a .value matching _KeyType members
    return _KeyType(kt.value)  # type: ignore[union-attr]


class WalletKeyManager:
    """Manages key creation, derivation, lookup, and export for a Wallet."""

    def __init__(self, wallet: Wallet) -> None:
        self._wallet = wallet

    # ------------------------------------------------------------------
    # Key creation / derivation
    # ------------------------------------------------------------------

    async def _new_key_multisig(
        self,
        public_keys: list[WalletKey],
        name: str,
        account_id: int,
        change: int,
        cosigner_id: int | None,
        network: str,
        address_index: int,
    ) -> WalletKey:
        if self._wallet.sort_keys:
            public_keys.sort(key=lambda pubk: pubk.key_public)
        public_key_list: list[Key | bytes] = [pubk.key_public for pubk in public_keys if pubk.key_public is not None]
        public_key_ids = [str(x.key_id) for x in public_keys]

        redeemscript = Script(
            script_types=["multisig"],
            keys=public_key_list,
            sigs_required=self._wallet.multisig_n_required,
        ).serialize()
        script_type = "p2sh"
        address = Address(
            redeemscript,
            encoding=self._wallet.encoding,
            script_type=script_type,
            network=network,
        )

        store = await _get_store()
        existing_key = store.get_key(address=address.address)
        if existing_key and existing_key.wallet_id == self._wallet.wallet_id:
            return await self.key(existing_key.id)

        path = ""
        if _mgr.store:
            for pubk in public_keys:
                sw = _mgr.store.get_wallet(wallet_id=pubk.wallet_id)
                if sw and sw.cosigner_id == self._wallet.cosigner_id:
                    path = pubk.path
                    break
        cos_id = self._wallet.cosigner_id if self._wallet.cosigner_id is not None else 0
        cos_main = self._wallet.cosigner[cos_id].main_key
        cos_depth = cos_main.depth if is_wallet_key(cos_main) else 0
        depth = cos_depth + len(path.split("/")) - 1
        if not name:
            name = "Multisig Key " + "/".join(public_key_ids)

        multisig_key = StoredKey(
            id=0,
            wallet_id=self._wallet.wallet_id,
            name=name[:80],
            purpose=self._wallet.purpose,
            account_id=account_id,
            depth=depth,
            change=change,
            address_index=address_index,
            parent_id=0,
            is_private=False,
            path=path,
            public=address.hash_bytes,
            wif=f"multisig-{address}",
            address=address.address,
            cosigner_id=cosigner_id,
            key_type="multisig",
            network_name=network,
            redeem_script=redeemscript,
            multisig_children=[(int(child_id), public_key_ids.index(child_id)) for child_id in public_key_ids],
        )
        store.add_key(multisig_key)

        wallet_key = WalletKey(multisig_key)
        self._wallet._key_objects[multisig_key.id] = wallet_key

        await _save_store()
        return wallet_key

    async def new_key(
        self,
        name: str = "",
        account_id: int | None = None,
        change: int = 0,
        cosigner_id: int | None = None,
        network: str | None = None,
    ) -> WalletKey:
        """Create a new HD Key derived from this wallet's masterkey."""
        if self._wallet.scheme == "single":
            if not is_wallet_key(self._wallet.main_key):
                raise WalletError("Main key not available")
            return self._wallet.main_key

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)
        if network != self._wallet.network.name and "coin_type'" not in self._wallet.key_path:
            raise WalletError("Multiple networks not supported by wallet key structure")
        if self._wallet.multisig:
            if not self._wallet.multisig_n_required:
                raise WalletError("Multisig_n_required not set, cannot create new key")
            if cosigner_id is None:
                if self._wallet.cosigner_id is None:
                    raise WalletError("Missing Cosigner ID value, cannot create new key")
                cosigner_id = self._wallet.cosigner_id

        address_index = 0
        if (
            self._wallet.multisig
            and cosigner_id is not None
            and (
                len(self._wallet.cosigner) > cosigner_id
                and self._wallet.cosigner[cosigner_id].key_path == "m"
                or self._wallet.cosigner[cosigner_id].key_path == ["m"]
            )
        ):
            req_path: list[str | int] = []
        else:
            store = await _get_store()
            matching_keys = store.get_keys(
                wallet_id=self._wallet.wallet_id,
                network_name=network,
                account_id=account_id,
                change=change,
                depth=self._wallet.key_depth,
            )
            matching_keys = [
                k
                for k in matching_keys
                if k.purpose == self._wallet.purpose
                and (k.cosigner_id or 0) == (cosigner_id or 0)
            ]
            matching_keys.sort(key=lambda k: k.address_index, reverse=True)
            prevkey = matching_keys[0] if matching_keys else None

            if prevkey:
                address_index = prevkey.address_index + 1

            req_path_ints: list[str | int] = [change, address_index]
            req_path = req_path_ints

        result = await self.key_for_path(
            req_path,
            name=name,
            account_id=account_id,
            network=network,
            cosigner_id=cosigner_id,
            address_index=address_index,
        )
        if result is None:
            raise WalletError("Failed to create new key")
        return result

    async def new_key_change(
        self, name: str = "", account_id: int | None = None, network: str | None = None
    ) -> WalletKey:
        """Create new change key."""
        return await self.new_key(name=name, account_id=account_id, network=network, change=1)

    async def new_account(
        self, name: str = "", account_id: int | None = None, network: str | None = None
    ) -> WalletKey | None:
        """Create a new account with a child key for payments and 1 for change."""
        if self._wallet.scheme != "bip32":
            raise WalletError("We can only create new accounts for a wallet with a BIP32 key scheme")
        if self._wallet.main_key and (self._wallet.main_key.depth != 0 or self._wallet.main_key.is_private is False):
            raise WalletError(
                "A master private key of depth 0 is needed to create new accounts "
                f"(depth: {self._wallet.main_key.depth})"
            )
        if "account'" not in self._wallet.key_path:
            raise WalletError(
                f"Accounts are not supported for this wallet. Account not found in key path {self._wallet.key_path}"
            )
        if network is None:
            network = self._wallet.network.name
        elif network != self._wallet.network.name and "coin_type'" not in self._wallet.key_path:
            raise WalletError("Multiple networks not supported by wallet key structure")

        duplicate_cointypes = [
            Network(x).name
            for x in await self._wallet.network_list()
            if Network(x).name != network and Network(x).bip44_cointype == Network(network).bip44_cointype
        ]
        if duplicate_cointypes:
            raise WalletError(
                f"Can not create new account for network {network} with same BIP44 cointype: {duplicate_cointypes}"
            )

        if account_id is None:
            account_id = 0
            store = await _get_store()
            matching = store.get_keys(
                wallet_id=self._wallet.wallet_id,
                network_name=network,
            )
            matching = [k for k in matching if k.purpose == self._wallet.purpose]
            matching.sort(key=lambda k: k.account_id, reverse=True)
            if matching:
                account_id = matching[0].account_id + 1

        if await self.keys(account_id=account_id, depth=self._wallet.depth_public_master, network=network):
            raise WalletError(f"Account with ID {account_id} already exists for this wallet")

        acckey = await self.key_for_path(
            [],
            level_offset=self._wallet.depth_public_master - self._wallet.key_depth,
            account_id=account_id,
            name=name,
            network=network,
        )
        await self.key_for_path([0, 0], network=network, account_id=account_id)
        await self.key_for_path([1, 0], network=network, account_id=account_id)
        return acckey

    async def import_key(
        self,
        key: HDKey | Address | str | bytes | int,
        account_id: int = 0,
        name: str = "",
        network: str | None = None,
        purpose: int = 44,
        key_type: str | None = None,
    ) -> WalletKey | None:
        """Add new single key to wallet."""
        if self._wallet.scheme not in ["bip32", "single"]:
            raise WalletError(
                "Keys can only be imported to a BIP32 or single"
                " type wallet. Recovery: create a new wallet instead"
            )
        if isinstance(key, (HDKey, Address)):
            network = key.network.name
            hdkey = key

            if network not in await self._wallet.network_list():
                raise WalletError(f"Network {network} not found in this wallet")
        else:
            if isinstance(key, str) and len(key.split(" ")) > 1:
                if network is None:
                    network = self._wallet.network.name

                seed = Mnemonic().to_seed(key)
                try:
                    hdkey = HDKey.from_seed(seed, network=network)
                finally:
                    secure_wipe(seed)
            else:
                if network is None:
                    network = check_network_and_key(key, default_network=self._wallet.network.name)
                if network not in await self._wallet.network_list():
                    raise WalletError(
                        f"Network {network} not available in this wallet, please create an account for this "
                        "network first."
                    )
                hdkey = HDKey(key, network=network, key_type=key_type or "bip32")

        if not self._wallet.multisig:
            if (
                self._wallet.main_key
                and self._wallet.main_key.depth == self._wallet.depth_public_master
                and not isinstance(hdkey, Address)
                and hdkey.is_private
                and hdkey.depth == 0
                and self._wallet.scheme == "bip32"
            ):
                return await self.import_master_key(hdkey, name)

            if key_type is None:
                if isinstance(hdkey, HDKey):
                    hdkey.key_type = "single"
                key_type = "single"

            store = await _get_store()
            ik_path = "m"
            if key_type == "single":
                # Check if key exists
                existing_keys = store.get_keys(
                    wallet_id=self._wallet.wallet_id,
                    account_id=account_id,
                    network_name=network,
                )
                private_to_check = hdkey.private_byte if isinstance(hdkey, HDKey) else None
                key_exists = any(k.private == private_to_check for k in existing_keys if k.private)

                if key_exists:
                    return None

                # Create path for unrelated import keys
                if isinstance(hdkey, HDKey):
                    hdkey.depth = self._wallet.key_depth
                all_keys = [k for k in store.keys.values() if k.path and k.path.startswith("import_key_")]
                all_keys.sort(key=lambda k: k.path, reverse=True)

                if all_keys:
                    ik_path = "import_key_" + str(int(all_keys[0].path[-5:]) + 1).zfill(5)
                else:
                    ik_path = "import_key_00001"
                if not name:
                    name = ik_path

            mk = WalletKey.from_hdkey(
                name,
                self._wallet.wallet_id,
                store,
                key=hdkey,
                network=network,
                key_type=key_type,
                account_id=account_id,
                purpose=purpose,
                path=ik_path,
                witness_type=self._wallet.witness_type,
            )

            await _save_store()

            self._wallet._key_objects.update({mk.key_id: mk})
            if is_wallet_key(self._wallet.main_key) and mk.key_id == self._wallet.main_key.key_id:
                self._wallet.main_key = mk
            return mk
        if not is_hdkey(hdkey):
            raise WalletError("Cannot import Address as private key in multisig wallet")
        account_key = hdkey.public_master(witness_type=self._wallet.witness_type, multisig=True).wif()
        for w in self._wallet.cosigner:
            mk_r = w.main_key.key() if is_wallet_key(w.main_key) else None
            if mk_r is not None and mk_r.wif_public() == account_key:
                _logger.debug(f"Import new private cosigner key in this multisig wallet: {account_key}")
                return await w.import_master_key(hdkey)
        raise WalletError("Unknown key: Can only import a private key for a known public key in multisig wallets")

    async def import_master_key(self, hdkey: HDKey | str, name: str = "Masterkey (imported)") -> WalletKey:
        """Import (another) masterkey in this wallet."""
        network, account_id, _ = await self._wallet._get_account_defaults()
        if not is_hdkey(hdkey):
            hdkey = HDKey(hdkey)
        if not is_wallet_key(self._wallet.main_key):
            raise WalletError(f"Main wallet key is not an WalletKey instance. Type {type(self._wallet.main_key)}")
        if not hdkey.is_private or hdkey.depth != 0:
            raise WalletError(
                "Please supply a valid private BIP32 master key"
                " with key depth 0."
                " Recovery: export master key from source wallet"
            )
        if self._wallet.main_key.is_private:
            raise WalletError(
                "Main key is already a private key, cannot import."
                " Recovery: wallet already has full signing capability"
            )
        if (
            self._wallet.main_key.depth != 1 and self._wallet.main_key.depth != 3 and self._wallet.main_key.depth != 4
        ) or self._wallet.main_key.key_type != "bip32":
            raise WalletError("Current main key is not a valid BIP32 public master key")
        main_key_nw = (
            self._wallet.main_key.network.name
            if is_network(self._wallet.main_key.network)
            else str(self._wallet.main_key.network)
        )
        if not (self._wallet.network.name == main_key_nw == hdkey.network.name):
            raise WalletError(
                "Network of Wallet class, main account key and the imported private key must use the same network"
            )
        if self._wallet.main_key.wif != hdkey.public_master().wif():
            raise WalletError("This key does not correspond to current public master key")

        hdkey.key_type = "bip32"
        ks = [
            k
            for k in WALLET_KEY_STRUCTURES
            if k["witness_type"] == self._wallet.witness_type
            and k["multisig"] == self._wallet.multisig
            and k["purpose"] is not None
        ]
        if len(ks) > 1:
            raise WalletError(
                "Please check definitions in WALLET_KEY_STRUCTURES. Multiple options found for "
                "witness_type - multisig combination"
            )
        kp = ks[0]["key_path"]
        self._wallet.key_path = kp if isinstance(kp, list) else kp.split("/") if isinstance(kp, str) else []

        store = await _get_store()
        self._wallet.main_key = WalletKey.from_hdkey(
            name,
            self._wallet.wallet_id,
            store,
            key=hdkey,
            network=network,
            account_id=account_id,
            purpose=self._wallet.purpose,
            key_type="bip32",
            witness_type=self._wallet.witness_type,
        )
        self._wallet.main_key_id = self._wallet.main_key.key_id
        self._wallet._key_objects.update({self._wallet.main_key_id: self._wallet.main_key})

        sw = store.get_wallet(wallet_id=self._wallet.wallet_id)
        if sw:
            sw.main_key_id = self._wallet.main_key_id
            store._dirty = True

        for key in await self.keys(is_private=False):
            kp = key.path.split("/")
            if kp and kp[0] == "M":
                kp = self._wallet.key_path[: self._wallet.depth_public_master + 1] + kp[1:]
            kp_expanded: list[str | int] = list(kp)
            await self.key_for_path(kp_expanded, recreate=True)

        await _save_store()
        return self._wallet.main_key

    # ------------------------------------------------------------------
    # Key path internals
    # ------------------------------------------------------------------

    async def path_expand(
        self,
        path: list[str | int] | str,
        level_offset: int | None = None,
        account_id: int | None = None,
        cosigner_id: int = 0,
        address_index: int | None = None,
        change: int = 0,
        network: str = DEFAULT_NETWORK,
    ) -> list[str]:
        """Create key path. Specify part of key path to expand to key path used in this wallet."""
        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)
        return path_expand(
            path,
            self._wallet.key_path,
            level_offset,
            account_id=account_id,
            cosigner_id=cosigner_id,
            address_index=address_index if address_index is not None else 0,
            change=change,
            purpose=self._wallet.purpose,
            witness_type=self._wallet.witness_type,
            network=network,
        )

    async def key_for_path(
        self,
        path: list[str | int] | str,
        level_offset: int | None = None,
        name: str | None = None,
        account_id: int | None = None,
        cosigner_id: int | None = None,
        address_index: int = 0,
        change: int = 0,
        network: str | None = None,
        recreate: bool = False,
    ) -> WalletKey | None:
        """Return key for specified path. Derive all wallet keys in path if they don't already exist."""
        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)
        cosigner_id = cosigner_id if cosigner_id is not None else self._wallet.cosigner_id

        level_offset_key = level_offset
        if level_offset and self._wallet.main_key and level_offset > 0:
            level_offset_key = level_offset - self._wallet.main_key.depth

        key_path = self._wallet.key_path
        if self._wallet.multisig and cosigner_id is not None and len(self._wallet.cosigner) > cosigner_id:
            key_path = self._wallet.cosigner[cosigner_id].key_path

        fullpath = path_expand(
            path,
            key_path,
            level_offset_key,
            account_id=account_id,
            cosigner_id=cosigner_id if cosigner_id is not None else 0,
            purpose=self._wallet.purpose,
            address_index=address_index,
            change=change,
            witness_type=self._wallet.witness_type,
            network=network,
        )

        if self._wallet.multisig and self._wallet.cosigner:
            public_keys = []
            for wlt in self._wallet.cosigner:
                if wlt.scheme == "single":
                    wk = wlt.main_key
                else:
                    wk = await wlt.key_for_path(
                        path,
                        level_offset=level_offset,
                        account_id=account_id,
                        name=name,
                        cosigner_id=cosigner_id,
                        network=network,
                        recreate=recreate,
                    )
                public_keys.append(wk)

            return await self._new_key_multisig(
                public_keys,
                name or "",
                account_id,
                change,
                cosigner_id,
                network,
                address_index,
            )

        # Check for closest ancestor in wallet
        wpath = fullpath
        if self._wallet.main_key and self._wallet.main_key.depth and fullpath and fullpath[0] != "M":
            wpath = ["M"] + fullpath[self._wallet.main_key.depth + 1 :]

        store = await _get_store()
        dbkey = None
        while wpath and not dbkey:
            normalized = _normalize_path("/".join(wpath))
            all_keys = store.get_keys(wallet_id=self._wallet.wallet_id)
            candidates = [k for k in all_keys if k.path == normalized]
            if recreate:
                candidates = [k for k in candidates if k.is_private]
            dbkey = candidates[0] if candidates else None
            wpath = wpath[:-1]

        if not dbkey:
            _logger.warning("No master or public master key found in this wallet")
            return None
        topkey = await self.key(dbkey.id)

        # Key already found, return it
        if dbkey and dbkey.path == _normalize_path("/".join(fullpath)) and not recreate:
            return topkey
        nk = None
        parent_id = topkey.key_id
        ck_result = topkey.key()
        if ck_result is None:
            raise WalletError("Cannot derive child keys from non-HDKey")
        ck: HDKey = ck_result
        newpath = topkey.path
        n_items = len(str(dbkey.path).split("/"))
        for lvl in fullpath[n_items:]:
            ck = ck.subkey_for_path(lvl, network=network)
            newpath += "/" + lvl
            if not account_id:
                account_id = (
                    0
                    if "account'" not in self._wallet.key_path
                    or self._wallet.key_path.index("account'") >= len(fullpath)
                    else int(
                        fullpath[self._wallet.key_path.index("account'")][:-1]
                    )
                )
            change = (
                0
                if "change" not in self._wallet.key_path or self._wallet.key_path.index("change") >= len(fullpath)
                else int(fullpath[self._wallet.key_path.index("change")])
            )
            if name and len(fullpath) == len(newpath.split("/")):
                key_name = name
            else:
                key_name = "{} {}".format(
                    self._wallet.key_path[len(newpath.split("/")) - 1],
                    lvl,
                )
                key_name = key_name.replace("'", "").replace("_", " ")

            nk = WalletKey.from_hdkey(
                key_name,
                self._wallet.wallet_id,
                store,
                key=ck,
                account_id=account_id,
                change=change,
                purpose=self._wallet.purpose,
                key_type=self._wallet.scheme,
                path=newpath,
                parent_id=parent_id,
                encoding=self._wallet.encoding,
                witness_type=self._wallet.witness_type,
                cosigner_id=cosigner_id,
                network=network,
            )
            self._wallet._key_objects.update({nk.key_id: nk})
            parent_id = nk.key_id
        await _save_store()
        return nk

    # ------------------------------------------------------------------
    # Key lookup / enumeration
    # ------------------------------------------------------------------

    async def key(self, term: int | str | StoredKey) -> WalletKey:
        """Return single key with given ID or name as WalletKey object."""
        store = await _get_store()
        sk = None

        if isinstance(term, StoredKey):
            sk = term

        if not sk:
            if isinstance(term, int):
                sk = store.get_key(key_id=term)

            if not sk:
                sk = store.get_key(address=str(term))

            if not sk:
                sk = store.get_key(wif=str(term))

            if not sk:
                # Search by name within this wallet
                all_keys = store.get_keys(wallet_id=self._wallet.wallet_id)
                for k in all_keys:
                    if k.name == str(term):
                        sk = k
                        break

        if sk:
            if sk.id in self._wallet._key_objects:
                cached = self._wallet._key_objects[sk.id]
                if is_wallet_key(cached):
                    return cached
            wallet_key = WalletKey(sk)
            self._wallet._key_objects.update({sk.id: wallet_key})
            return wallet_key
        raise BKeyError(f"Key '{term}' not found")

    async def keys(
        self,
        account_id: int | None = None,
        name: str | None = None,
        key_id: int | None = None,
        change: int | None = None,
        depth: int | None = None,
        used: bool | None = None,
        is_private: bool | None = None,
        has_balance: bool | None = None,
        is_active: bool | None = None,
        network: str | None = None,
        include_private: bool | None = False,
        as_dict: bool = False,
        eager_load_network: bool = False,
    ) -> list[StoredKey]:
        """Search for keys in store."""
        store = await _get_store()

        # Start with all keys for this wallet
        all_keys = store.get_keys(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=network,
            change=change,
            depth=depth,
            used=used,
            is_private=is_private,
        )

        # Apply additional filters
        result = []
        for k in all_keys:
            if name is not None and k.name != name:
                continue
            if key_id is not None and k.id != key_id:
                continue
            if has_balance is True and is_active is True:
                raise WalletError("Cannot use has_balance and is_active parameter together")
            if has_balance is not None:
                if has_balance and k.balance == 0:
                    continue
                if not has_balance and k.balance != 0:
                    continue
            if is_active and k.balance == 0 and k.used:
                continue
            # Filter by depth range for bip32 with account/change filters
            if account_id is not None and self._wallet.scheme == "bip32" and depth is None and k.depth < 3:
                continue
            if (
                change is not None
                and self._wallet.scheme == "bip32"
                and depth is None
                and k.depth <= self._wallet.key_depth - 1
            ):
                continue
            result.append(k)

        # Sort by depth then id
        result.sort(key=lambda k: (k.depth, k.id))

        if as_dict:
            keys2 = []
            private_fields = []
            if not include_private:
                private_fields += ["private", "wif"]
            for key in result:
                kd = {
                    "id": key.id,
                    "wallet_id": key.wallet_id,
                    "parent_id": key.parent_id,
                    "name": key.name,
                    "account_id": key.account_id,
                    "depth": key.depth,
                    "change": key.change,
                    "address_index": key.address_index,
                    "address": key.address,
                    "encoding": key.encoding,
                    "purpose": key.purpose,
                    "is_private": key.is_private,
                    "path": key.path,
                    "key_type": key.key_type,
                    "network_name": key.network_name,
                    "balance": key.balance,
                    "used": key.used,
                    "compressed": key.compressed,
                    "cosigner_id": key.cosigner_id,
                }
                if include_private:
                    kd["private"] = key.private
                    kd["wif"] = key.wif
                if "public" not in private_fields:
                    kd["public"] = key.public
                keys2.append(kd)
            return keys2

        return result

    async def keys_networks(self, used: bool | None = None, as_dict: bool = False) -> list[StoredKey]:
        """Get keys of defined networks for this wallet."""
        if self._wallet.scheme != "bip32":
            raise WalletError("The 'keys_network' method can only be used with BIP32 type wallets")
        try:
            depth = self._wallet.key_path.index("coin_type'")
        except ValueError:
            return []
        if self._wallet.multisig and self._wallet.cosigner:
            _logger.warning("No network keys available for multisig wallet, use networks() method for list of networks")

        return await self.keys(depth=depth, used=used, as_dict=as_dict, eager_load_network=True)

    async def keys_accounts(
        self,
        account_id: int | None = None,
        network: str = DEFAULT_NETWORK,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get account key(s) for current wallet."""
        return await self.keys(account_id, depth=self._wallet.depth_public_master, network=network, as_dict=as_dict)

    async def keys_addresses(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        is_active: bool | None = None,
        change: int | None = None,
        network: str | None = None,
        depth: int | None = None,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get address keys of specified account_id for current wallet."""
        if depth is None:
            depth = self._wallet.key_depth
        return await self.keys(
            account_id,
            depth=depth,
            used=used,
            change=change,
            is_active=is_active,
            network=network,
            as_dict=as_dict,
        )

    async def keys_address_payment(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get payment addresses (change=0)."""
        return await self.keys(
            account_id,
            depth=self._wallet.key_depth,
            change=0,
            used=used,
            network=network,
            as_dict=as_dict,
        )

    async def keys_address_change(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get change addresses (change=1)."""
        return await self.keys(
            account_id,
            depth=self._wallet.key_depth,
            change=1,
            used=used,
            network=network,
            as_dict=as_dict,
        )

    async def addresslist(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        change: int | None = None,
        depth: int | None = None,
        key_id: int | None = None,
    ) -> list[str]:
        """Get list of addresses defined in current wallet."""
        addresslist = []
        if depth is None:
            depth = self._wallet.key_depth
        elif depth == -1:
            depth = None
        for key in await self.keys(
            account_id=account_id,
            depth=depth,
            used=used,
            network=network,
            change=change,
            key_id=key_id,
            is_active=False,
        ):
            if key.network_name in AUTH_ONLY_NETWORKS:
                continue
            if key.key_type in ("sapling", "sapling_address"):
                continue
            addresslist.append(key.address)
        return addresslist

    async def get_key(
        self,
        account_id: int | None = None,
        network: str | None = None,
        cosigner_id: int | None = None,
        key_type: _KeyType | object = None,
    ) -> WalletKey:
        """Get an unused key or create a new one."""
        if key_type is None:
            key_type = _KeyType.PAYMENT
        keys = await self._get_unused_keys(
            account_id, network, cosigner_id, key_type=_coerce_key_type(key_type),
        )
        return keys[0]

    async def get_keys(
        self,
        account_id: int | None = None,
        network: str | None = None,
        cosigner_id: int | None = None,
        number_of_keys: int = 1,
        key_type: _KeyType | object = None,
        force_create: bool = False,
    ) -> list[WalletKey]:
        """Get a list of unused keys or create new ones."""
        if key_type is None:
            key_type = _KeyType.PAYMENT
        if self._wallet.scheme == "single":
            raise WalletError(
                "Single wallet has only one (master)key. "
                "Use get_key() or main_key() method"
            )
        return await self._get_unused_keys(
            account_id,
            network,
            cosigner_id,
            number_of_keys,
            key_type=_coerce_key_type(key_type),
            force_create=force_create,
        )

    async def get_key_change(
        self, account_id: int | None = None, network: str | None = None,
    ) -> WalletKey:
        """Get unused change key."""
        keys = await self._get_unused_keys(
            account_id=account_id, network=network, key_type=_KeyType.CHANGE,
        )
        return keys[0]

    async def get_keys_change(
        self,
        account_id: int | None = None,
        network: str | None = None,
        number_of_keys: int = 1,
    ) -> list[WalletKey]:
        """Get unused change keys."""
        return await self._get_unused_keys(
            account_id=account_id,
            network=network,
            key_type=_KeyType.CHANGE,
            number_of_keys=number_of_keys,
        )

    async def _get_unused_keys(
        self,
        account_id: int | None = None,
        network: str | None = None,
        cosigner_id: int | None = None,
        number_of_keys: int = 1,
        key_type: _KeyType = _KeyType.PAYMENT,
        force_create: bool = False,
    ) -> list[WalletKey]:
        """Get unused wallet keys for account / network."""

        keys = []

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)

        if cosigner_id is None:
            cosigner_id = self._wallet.cosigner_id
        elif cosigner_id > len(self._wallet.cosigner):
            raise WalletError(
                f"Cosigner ID ({cosigner_id}) can not be greater then number of"
                f" cosigners for this wallet ({len(self._wallet.cosigner)})"
            )

        if force_create:
            for _ in range(number_of_keys):
                keys.append(
                    await self.new_key(
                        account_id=account_id,
                        change=key_type.value if key_type.value is not None else 0,
                        cosigner_id=cosigner_id,
                        network=network,
                    )
                )
            return keys

        db_key_type = "multisig" if self._wallet.multisig else "bip32"

        store = await _get_store()
        all_keys = store.get_keys(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=network,
            change=key_type.value,
            depth=self._wallet.key_depth,
        )
        typed_keys = [k for k in all_keys if k.cosigner_id == cosigner_id and k.key_type == db_key_type]

        # Find last used key id
        used_keys = [k for k in typed_keys if k.used]
        used_keys.sort(key=lambda k: k.id, reverse=True)
        last_used_key_id = used_keys[0].id if used_keys else 0

        # Find free keys after the last used one
        free_keys = [k for k in typed_keys if not k.used and k.id > last_used_key_id]
        free_keys.sort(key=lambda k: k.id, reverse=True)

        if self._wallet.scheme == "single" and len(free_keys):
            number_of_keys = len(free_keys) if number_of_keys > len(free_keys) else number_of_keys

        for _ in range(number_of_keys):
            if free_keys:
                dk = free_keys.pop()
                nk = await self.key(dk.id)
            else:
                nk = await self.new_key(
                    account_id=account_id,
                    change=key_type.value if key_type.value is not None else 0,
                    cosigner_id=cosigner_id,
                    network=network,
                )
            keys.append(nk)
        return keys

    async def account(self, account_id: int) -> WalletKey:
        """Returns wallet key of specific BIP44 account."""
        if "account'" not in self._wallet.key_path:
            raise WalletError(
                f"Accounts are not supported for this wallet. Account not found in key path {self._wallet.key_path}"
            )
        store = await _get_store()
        matching = store.get_keys(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=self._wallet.network.name,
            depth=3,
        )
        matching = [k for k in matching if k.purpose == self._wallet.purpose]
        if not matching:
            raise WalletError(f"Account with ID {account_id} not found in this wallet")
        return await self.key(matching[0].id)

    async def accounts(self, network: str = DEFAULT_NETWORK) -> list[int]:
        """Get list of accounts for this wallet."""
        if self._wallet.multisig and self._wallet.cosigner:
            if self._wallet.cosigner_id is None:
                raise WalletError("Missing Cosigner ID value for this wallet, cannot fetch account ID")
            cos = self._wallet.cosigner[self._wallet.cosigner_id]
            accounts = [
                wk.account_id
                for wk in await cos.keys_accounts(network=network)
            ]
        else:
            accounts = [wk.account_id for wk in await self.keys_accounts(network=network)]
        if not accounts:
            accounts = [self._wallet.default_account_id]
        return list(dict.fromkeys(accounts))

    # ------------------------------------------------------------------
    # Key export / info
    # ------------------------------------------------------------------

    def wif(self, is_private: bool = False, account_id: int = 0) -> str | None:
        """Return Wallet Import Format string for master key."""
        if is_private and self._wallet.main_key:
            if is_wallet_key(self._wallet.main_key):
                return self._wallet.main_key.wif
            return None
        # For non-multisig, use main_key directly
        if is_wallet_key(self._wallet.main_key):
            k = self._wallet.main_key.key()
            if k is not None:
                return k.wif(
                    is_private=is_private,
                    witness_type=self._wallet.witness_type,
                    multisig=self._wallet.multisig,
                )
        return None

    def wif_multisig(self, is_private: bool = False) -> list[str]:
        """Return WIF strings for all cosigners of a multisig wallet."""
        wiflist: list[str] = []
        for cs in self._wallet.cosigner:
            w = cs.wif(is_private=is_private)
            if w is not None:
                wiflist.append(w)
        return wiflist

    async def public_master(
        self,
        account_id: int | None = None,
        name: str | None = None,
        as_private: bool = False,
        network: str | None = None,
    ) -> WalletKey | list[WalletKey]:
        """Return public master key(s) for this wallet."""
        if (
            self._wallet.main_key
            and is_wallet_key(self._wallet.main_key)
            and self._wallet.main_key.key_type == "single"
        ):
            return self._wallet.main_key
        if not self._wallet.cosigner:
            depth = -self._wallet.key_depth + self._wallet.depth_public_master
            key = await self.key_for_path(
                [],
                depth,
                name=name,
                account_id=account_id,
                network=network,
                cosigner_id=self._wallet.cosigner_id,
            )
            if key is None:
                raise WalletError("Cannot derive public master key")
            return key
        pm_list = []
        for cs in self._wallet.cosigner:
            pm_list.append(await cs.public_master(account_id, name, as_private, network))
        return pm_list


if SHIELDED_AVAILABLE:
    from fluxwallet.sapling.key_manager import SaplingKeyMixin

    # Inject sapling methods into WalletKeyManager at import time
    for _name in ("new_sapling_key", "new_sapling_key_change", "sapling_spending_key", "z_address"):
        setattr(WalletKeyManager, _name, getattr(SaplingKeyMixin, _name))
