from __future__ import annotations

import json
import logging
from enum import Enum
from typing import TYPE_CHECKING, ClassVar, Literal, overload

from fluxwallet.config import (
    DEFAULT_NETWORK,
    DEFAULT_WITNESS_TYPE,
    MAX_TRANSACTIONS,
    WALLET_KEY_STRUCTURES,
)
from fluxwallet.encoding import (
    bech32_encode,
)
from fluxwallet.keys import (
    Address,
    BKeyError,
    HDKey,
)
from fluxwallet.main import get_encoding_from_witness, script_type_default
from fluxwallet.mnemonic import Mnemonic
from fluxwallet.networks import Network, network_defined
from fluxwallet.sapling import SHIELDED_AVAILABLE
from fluxwallet.secure_mem import secure_wipe
from fluxwallet.type_guards import (
    is_hdkey,
    is_network,
    is_wallet_key,
)
from fluxwallet.values import Value
from fluxwallet.wallet.balance_manager import WalletBalanceManager
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet.key_manager import WalletKeyManager, _coerce_key_type, _KeyType
from fluxwallet.wallet.scanner import WalletScanner
from fluxwallet.wallet.store_access import _get_store, _mgr, _save_store, _StoreManager
from fluxwallet.wallet.transaction_manager import TransactionBuilder, WalletTransactionManager
from fluxwallet.wallet.wallet_key import WalletKey
from fluxwallet.wallet_store import (
    StoredKey,
    StoredWallet,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from fluxwallet.keys import Key
    from fluxwallet.sapling.keys import SaplingSpendingKey
    from fluxwallet.sapling.wallet import ShieldedWallet
    from fluxwallet.transactions import (
        FluxTransaction,
        Input,
        Output,
        TransactionMixin,
    )
    from fluxwallet.wallet.models import Utxo
    from fluxwallet.wallet.wallet_transaction import WalletTransaction
    from fluxwallet.wallet_store import StoredTxOutput


_logger = logging.getLogger(__name__)

# Bitcoin keys are used for FluxOS ZelID authentication (message signing).
# They are not used for transactions and should be excluded from network
# operations like scanning, balance updates, and UTXO queries.
AUTH_ONLY_NETWORKS = frozenset({"bitcoin"})

# _StoreManager, _mgr, _get_store, _save_store live in store_access.py


type GenericKeyType = (
    str | bytes | int | HDKey | WalletKey | list[str] | list[bytes] | list[int] | list[HDKey] | list[WalletKey]
)



def _resolve_single_key(
    key: str | bytes | int | HDKey | WalletKey,
    *,
    password: str = "",
    network: str | None = None,
    encoding: str | None = None,
) -> HDKey | Address:
    """Convert any single key input to HDKey or Address."""
    if isinstance(key, HDKey):
        return key
    if isinstance(key, WalletKey):
        hdk = key.key()
        if hdk is not None:
            return hdk
        if key.wif:
            return HDKey(key.wif, network=network)
        raise WalletError("WalletKey has no key material")
    if isinstance(key, str) and len(key.split()) > 1:
        if not network:
            raise WalletError("Please specify network when using passphrase to create a key")
        seed = Mnemonic().to_seed(key, password)
        try:
            return HDKey.from_seed(seed, network=network)
        finally:
            secure_wipe(seed)
    try:
        return HDKey(key, password=password, network=network)
    except BKeyError:
        try:
            return Address.parse(str(key), encoding=encoding, network=network)
        except (BKeyError, ValueError) as err:
            raise WalletError(
                f"Invalid key or address: {key}."
                " Recovery: provide a valid WIF key, xpub, or address"
            ) from err


def _resolve_key_list(
    keys: list[str] | list[bytes] | list[int] | list[HDKey] | list[WalletKey],
    *,
    password: str = "",
    network: str | None = None,
    encoding: str | None = None,
) -> list[HDKey]:
    """Convert a list of any key inputs to list[HDKey].

    Addresses are not valid for multisig — all keys must be HDKeys.
    """
    result: list[HDKey] = []
    for k in keys:
        resolved = _resolve_single_key(k, password=password, network=network, encoding=encoding)
        if isinstance(resolved, Address):
            raise WalletError("Addresses cannot be used in multisig wallets — provide HDKey or WIF")
        result.append(resolved)
    return result


def _narrow_dict(d: object) -> dict[str, object]:
    """Safely narrow an untyped dict to dict[str, object]."""
    if not isinstance(d, dict):
        return {}
    return {str(k): v for k, v in d.items()}


class KeyType(Enum):
    PAYMENT = 0
    CHANGE = 1
    ANY = None


def normalize_path(path: str) -> str:
    """Normalize BIP0044 key path for HD keys. Using single quotes for hardened keys.

    >>> normalize_path("m/44h/2p/1'/0/100")
    "m/44'/2'/1'/0/100"

    :param path: BIP0044 key path
    :type path: str

    :return str: Normalized BIP0044 key path with single quotes
    """

    levels = path.split("/")
    npath = ""
    for level in levels:
        if not level:
            raise WalletError("Could not parse path. Index is empty.")
        nlevel = level
        if level[-1] in "'HhPp":
            nlevel = level[:-1] + "'"
        npath += nlevel + "/"
    if npath[-1] == "/":
        npath = npath[:-1]
    return npath


class Wallet:
    """Class to create and manage keys Using the BIP0044 Hierarchical Deterministic wallet definitions, so you can use
    one Masterkey to generate as much child keys as you want in a structured manner.

    You can import keys in many format such as WIF or extended WIF, bytes, hexstring, seeds or private key integer. For
    the Bitcoin network, Litecoin or any other network you define in the settings.

    Easily send and receive transactions. Compose transactions automatically or select unspent outputs.

    Each wallet name must be unique and can contain only one cointype and purpose, but practically unlimited accounts
    and addresses.
    """

    _password_prompt: ClassVar[Callable[[], str] | None] = None

    @classmethod
    def set_password_prompt(cls, callback: Callable[[], str] | None) -> None:
        """Register a UI callback for password prompting."""
        cls._password_prompt = callback
        _StoreManager._password_prompt = callback

    @classmethod
    def configure(cls, *, key_file: str | None = None, tpm_auth_file: str | None = None) -> None:
        """Set store unlock credentials before any wallet operations."""
        _mgr.key_file = key_file
        if tpm_auth_file:
            from fluxwallet.tpm_keyring import configure_tpm_auth

            configure_tpm_auth(tpm_auth_file)
        elif _mgr.tpm_auth_file:
            from fluxwallet.tpm_keyring import configure_tpm_auth

            configure_tpm_auth(_mgr.tpm_auth_file)

    @classmethod
    async def ensure_loaded(cls) -> None:
        """Ensure the wallet store is loaded and decrypted."""
        await _get_store()

    @classmethod
    async def exists(cls, ident: str | int) -> bool:
        """Check if a wallet exists by name or ID."""
        store = await _get_store()
        if isinstance(ident, int) or (isinstance(ident, str) and ident.isdigit()):
            return store.get_wallet(wallet_id=int(ident) if isinstance(ident, str) else ident) is not None
        return store.get_wallet(name=str(ident)) is not None

    @classmethod
    async def find_by_address(cls, address: str) -> Wallet | None:
        """Find the wallet that owns an address, or None."""
        store = await _get_store()
        key = store.get_key(address=address)
        if not key:
            return None
        w = store.get_wallet(wallet_id=key.wallet_id)
        if not w:
            return None
        return await cls.open(w.name)

    @classmethod
    async def _create(
        cls,
        name: str,
        key: HDKey | Address | str,
        owner: str,
        network: str | None,
        account_id: int,
        purpose: int,
        scheme: str,
        parent_id: int | None,
        sort_keys: bool,
        witness_type: str,
        encoding: str,
        multisig: bool,
        sigs_required: int | None,
        cosigner_id: int | None,
        key_path: list[str] | str | None,
        db_uri: str | None,
    ) -> Wallet:
        store = await _get_store()

        if store.wallet_exists(name):
            raise WalletError(
                f"Wallet with name '{name}' already exists."
                " Recovery: choose a different name or delete it first"
            )
        _logger.info(f"Create new wallet '{name}'")

        if not name:
            raise WalletError("Please enter wallet name")

        if isinstance(key_path, str):
            key_path = key_path.split("/")

        key_depth = 1 if not key_path else len(key_path) - 1

        base_path = "m"
        if is_hdkey(key) and hasattr(key, "depth"):
            if key.depth is None:
                key.depth = key_depth
            key_depth_val: int = key.depth if key.depth is not None else 0
            if key_depth_val > 0 and key_path is not None:
                hardened_keys = [x for x in key_path if x[-1:] == "'"]
                if hardened_keys:
                    depth_public_master = key_path.index(hardened_keys[-1])
                    if depth_public_master != key_depth_val:
                        raise WalletError(
                            f"Depth of provided public master key {key_depth_val} does not correspond with key path "
                            f"{key_path}. Did you provide correct witness_type and multisig attribute?"
                        )
                if key_path is not None:
                    key_path = ["M"] + key_path[key_depth_val + 1 :]
                base_path = "M"

        if isinstance(key_path, list):
            key_path = "/".join(key_path)

        new_wallet = StoredWallet(
            id=0,
            name=name,
            owner=owner,
            network_name=network or DEFAULT_NETWORK,
            purpose=purpose,
            scheme=scheme,
            sort_keys=sort_keys,
            witness_type=witness_type,
            parent_id=parent_id,
            encoding=encoding,
            multisig=multisig,
            multisig_n_required=sigs_required if sigs_required else 1,
            cosigner_id=cosigner_id if cosigner_id is not None else 0,
            key_path=key_path if isinstance(key_path, str) else "",
        )
        new_wallet_id = store.add_wallet(new_wallet)

        if scheme == "bip32" and multisig and parent_id is None:
            wallet = cls(new_wallet)
            await wallet._sync_from_store()

        elif scheme == "bip32":
            main_key = WalletKey.from_hdkey(
                name,
                new_wallet_id,
                store,
                key=key,
                network=network,
                account_id=account_id,
                purpose=purpose,
                key_type="bip32",
                encoding=encoding,
                witness_type=witness_type,
                multisig=multisig,
                path=base_path,
            )
            new_wallet.main_key_id = main_key.key_id

            wallet = cls(new_wallet)
            await wallet._sync_from_store()

            await wallet.key_for_path([0, 0], account_id=account_id, cosigner_id=cosigner_id)
        else:  # scheme == 'single':
            if not key:
                key = HDKey(network=network, depth=key_depth)
            main_key = WalletKey.from_hdkey(
                name,
                new_wallet_id,
                store,
                key=key,
                network=network,
                account_id=account_id,
                purpose=purpose,
                key_type="single",
                encoding=encoding,
                witness_type=witness_type,
                multisig=multisig,
            )
            new_wallet.main_key_id = main_key.key_id
            wallet = cls(new_wallet)
            await wallet._sync_from_store()

        await _save_store()
        return wallet

    @classmethod
    async def from_mnemonic(
        cls,
        name: str,
        mnemonic: str,
        *,
        password: str = "",
        network: str = DEFAULT_NETWORK,
        account_id: int = 0,
        purpose: int = 0,
        witness_type: str = DEFAULT_WITNESS_TYPE,
        encoding: str | None = None,
        key_path: list[str] | str | None = None,
    ) -> Wallet:
        """Create wallet from a BIP39 mnemonic seed phrase.

        :param name: Unique name of this Wallet
        :type name: str
        :param mnemonic: BIP39 mnemonic seed phrase
        :type mnemonic: str
        :param password: Optional passphrase to protect mnemonic
        :type password: str
        :param network: Network name, default is DEFAULT_NETWORK
        :type network: str
        :param account_id: Account ID, default is 0
        :type account_id: int
        :param purpose: BIP43 purpose field
        :type purpose: int
        :param witness_type: Specify witness type
        :type witness_type: str
        :param encoding: Encoding used for address generation
        :type encoding: str
        :param key_path: Key path for wallet
        :type key_path: list, str
        :return Wallet:
        """
        if not encoding:
            encoding = get_encoding_from_witness(witness_type)
        if not key_path:
            ks = [
                k
                for k in WALLET_KEY_STRUCTURES
                if k["witness_type"] == witness_type and k["multisig"] is False and k["purpose"] is not None
            ]
            if ks:
                if not purpose:
                    ks_purpose = ks[0]["purpose"]
                    purpose = int(ks_purpose) if isinstance(ks_purpose, (int, str)) else 0
                if not encoding:
                    encoding = str(ks[0]["encoding"]) if ks[0]["encoding"] else None
                kp_val = ks[0]["key_path"]
                key_path = kp_val if isinstance(kp_val, (list, str)) else None
        if not encoding:
            encoding = get_encoding_from_witness(witness_type)
        seed = Mnemonic().to_seed(mnemonic, password)
        try:
            key = HDKey.from_seed(seed, network=network)
            wallet = await cls._create(
                name,
                key=key,
                owner="",
                network=network,
                account_id=account_id,
                purpose=purpose,
                scheme="bip32",
                parent_id=None,
                sort_keys=True,
                witness_type=witness_type,
                encoding=encoding,
                multisig=False,
                sigs_required=1,
                cosigner_id=None,
                key_path=key_path,
                db_uri=None,
            )

            # Derive and store the Sapling spending key + initial receive address
            if SHIELDED_AVAILABLE:
                import fluxwallet_sapling  # noqa: PLC0415
                from fluxwallet.sapling.keys import SaplingSpendingKey  # noqa: PLC0415

                sk = SaplingSpendingKey.from_seed(seed)
                fvk_bytes = sk.full_viewing_key().raw_bytes()
                store = await _get_store()

                sapling_master = StoredKey(
                    id=0,
                    wallet_id=wallet.wallet_id,
                    name=f"{name}_sapling",
                    key_type="sapling",
                    private=sk.raw_bytes(),
                    public=fvk_bytes,
                    address="",
                    is_private=True,
                    network_name=network,
                    path="m/32'/19167'/0'",
                    depth=3,
                    purpose=32,
                )
                master_id = store.add_key(sapling_master)

                result = fluxwallet_sapling.sapling_derive_address(fvk_bytes, 0)
                found_div = int.from_bytes(result["diversifier"][:8], "little")
                store.add_key(
                    StoredKey(
                        id=0,
                        wallet_id=wallet.wallet_id,
                        parent_id=master_id,
                        name=f"{name}_z0",
                        key_type="sapling_address",
                        depth=5,
                        change=0,
                        address_index=found_div,
                        address=bech32_encode("za", result["payment_address"]),
                        path=f"m/32'/19167'/0'/0/{found_div}",
                        network_name=network,
                        encoding="bech32",
                        purpose=32,
                    )
                )
                await _save_store()

            return wallet
        finally:
            secure_wipe(seed)

    @classmethod
    async def from_key(
        cls,
        name: str,
        key: HDKey,
        *,
        network: str | None = None,
        account_id: int = 0,
        purpose: int = 0,
        scheme: str = "bip32",
        witness_type: str | None = None,
        encoding: str | None = None,
        key_path: list[str] | str | None = None,
    ) -> Wallet:
        """Create wallet from an existing HDKey.

        :param name: Unique name of this Wallet
        :type name: str
        :param key: HDKey to use for this wallet
        :type key: HDKey
        :param network: Network name, use key's network if not specified
        :type network: str
        :param account_id: Account ID, default is 0
        :type account_id: int
        :param purpose: BIP43 purpose field
        :type purpose: int
        :param scheme: Key structure type, i.e. BIP32 or single
        :type scheme: str
        :param witness_type: Specify witness type
        :type witness_type: str
        :param encoding: Encoding used for address generation
        :type encoding: str
        :param key_path: Key path for wallet
        :type key_path: list, str
        :return Wallet:
        """
        if network is None:
            network = key.network.name if is_network(key.network) else DEFAULT_NETWORK
        if witness_type is None:
            witness_type = key.witness_type or DEFAULT_WITNESS_TYPE
        multisig = False
        if not key_path:
            if scheme == "single":
                key_path = ["m"]
                purpose = 0
            else:
                ks = [
                    k
                    for k in WALLET_KEY_STRUCTURES
                    if k["witness_type"] == witness_type and k["multisig"] == multisig and k["purpose"] is not None
                ]
                if len(ks) > 1:
                    raise WalletError(
                        "Please check definitions in WALLET_KEY_STRUCTURES. Multiple options found for "
                        "witness_type - multisig combination"
                    )
                if ks and not purpose:
                    ks_purpose = ks[0]["purpose"]
                    purpose = int(ks_purpose) if isinstance(ks_purpose, (int, str)) else 0
                if ks and not encoding:
                    encoding = str(ks[0]["encoding"]) if ks[0]["encoding"] else None
                kp_val = ks[0]["key_path"]
                key_path = kp_val if isinstance(kp_val, (list, str)) else None
        else:
            if purpose is None:
                purpose = 0
        if not encoding:
            encoding = get_encoding_from_witness(witness_type)
        return await cls._create(
            name,
            key=key,
            owner="",
            network=network,
            account_id=account_id,
            purpose=purpose,
            scheme=scheme,
            parent_id=None,
            sort_keys=True,
            witness_type=witness_type,
            encoding=encoding,
            multisig=False,
            sigs_required=1,
            cosigner_id=None,
            key_path=key_path,
            db_uri=None,
        )

    @classmethod
    async def from_multisig(
        cls,
        name: str,
        keys: list[HDKey],
        sigs_required: int,
        *,
        owner: str = "",
        network: str | None = None,
        account_id: int = 0,
        purpose: int = 0,
        sort_keys: bool = True,
        witness_type: str = DEFAULT_WITNESS_TYPE,
        encoding: str | None = None,
        cosigner_id: int | None = None,
        key_path: list[str] | str | None = None,
        pending: bool = False,
    ) -> Wallet:
        """Create multisig wallet from a list of HDKeys.

        :param name: Unique name of this Wallet
        :type name: str
        :param keys: List of HDKeys for multisig cosigners
        :type keys: list[HDKey | Address]
        :param sigs_required: Number of signatures required
        :type sigs_required: int
        :param owner: Wallet owner for your own reference
        :type owner: str
        :param network: Network name, use first key's network if not specified
        :type network: str
        :param account_id: Account ID, default is 0
        :type account_id: int
        :param purpose: BIP43 purpose field
        :type purpose: int
        :param sort_keys: Sort keys according to BIP45 standard
        :type sort_keys: bool
        :param witness_type: Specify witness type
        :type witness_type: str
        :param encoding: Encoding used for address generation
        :type encoding: str
        :param cosigner_id: Cosigner ID
        :type cosigner_id: int
        :param key_path: Key path for multisig wallet
        :type key_path: list, str
        :param pending: Allow creation with a single key, second cosigner added later via add_cosigner()
        :type pending: bool
        :return Wallet:
        """
        if not keys:
            raise WalletError("Multisig wallet requires at least 1 key")
        if len(keys) < 2 and not pending:
            raise WalletError("Multisig wallet requires at least 2 keys (use pending=True for single-key creation)")
        if not pending and sigs_required > len(keys):
            raise WalletError("Number of keys required to sign is greater then number of keys provided")
        if len(keys) > 15:
            raise WalletError(
                "Redeemscripts with more then 15 keys are non-standard and could result in locked up funds"
            )

        # Resolve network from keys if not specified
        if network is None:
            for k in keys:
                if is_hdkey(k) or isinstance(k, Address):
                    network = k.network.name if is_network(k.network) else None
                    if network:
                        break
        if network is None:
            network = DEFAULT_NETWORK

        if not key_path:
            ks = [
                k
                for k in WALLET_KEY_STRUCTURES
                if k["witness_type"] == witness_type and k["multisig"] is True and k["purpose"] is not None
            ]
            if len(ks) > 1:
                raise WalletError(
                    "Please check definitions in WALLET_KEY_STRUCTURES. Multiple options found for "
                    "witness_type - multisig combination"
                )
            if ks and not purpose:
                ks_purpose = ks[0]["purpose"]
                purpose = int(ks_purpose) if isinstance(ks_purpose, (int, str)) else 0
            if ks and not encoding:
                encoding = str(ks[0]["encoding"]) if ks[0]["encoding"] else None
            kp_val = ks[0]["key_path"]
            key_path = kp_val if isinstance(kp_val, (list, str)) else None
        else:
            if purpose is None:
                purpose = 0
        if not encoding:
            encoding = get_encoding_from_witness(witness_type)

        hdkey_list = list(keys)
        if sort_keys:
            hdkey_list.sort(key=lambda x: x.public_byte)

        cos_prv_lst = [hdkey_list.index(cw) for cw in hdkey_list if cw.is_private]
        if cosigner_id is None:
            if not cos_prv_lst:
                raise WalletError(
                    "This wallet does not contain any private keys, please specify cosigner_id for this wallet"
                )
            if len(cos_prv_lst) > 1:
                raise WalletError(
                    "This wallet contains more then 1 private key, please specify cosigner_id for this wallet"
                )
            cosigner_id = 0 if not cos_prv_lst else cos_prv_lst[0]

        cos_key = hdkey_list[cosigner_id]
        main_key_path = key_path
        if cos_key.key_type == "single":
            main_key_path = "m"

        # Create the parent multisig wallet (no key material, just the shell)
        hdpm = await cls._create(
            name,
            "",
            owner=owner,
            network=network,
            account_id=account_id,
            purpose=purpose,
            scheme="bip32",
            parent_id=None,
            sort_keys=sort_keys,
            witness_type=witness_type,
            encoding=encoding,
            multisig=True,
            sigs_required=sigs_required,
            cosigner_id=cosigner_id,
            key_path=main_key_path,
            db_uri=None,
        )

        # Create cosigner child wallets
        for wlt_cos_id, cokey in enumerate(hdkey_list):
            if hdpm.network.name != cokey.network.name:
                cokey_label = cokey.wif(is_private=False)
                raise WalletError(
                    f"Network for key {cokey_label} ({cokey.network.name}) is different then network "
                    f"specified: {network}/{hdpm.network.name}"
                )
            co_scheme = "bip32"
            wn = f"{name}-cosigner-{wlt_cos_id}"
            c_key_path = key_path
            if cokey.key_type == "single":
                co_scheme = "single"
                c_key_path = ["m"]
            w = await cls._create(
                name=wn,
                key=cokey,
                owner=owner,
                network=network,
                account_id=account_id,
                purpose=hdpm.purpose,
                scheme=co_scheme,
                parent_id=hdpm.wallet_id,
                sort_keys=sort_keys,
                witness_type=hdpm.witness_type,
                encoding=encoding,
                multisig=True,
                sigs_required=None,
                cosigner_id=wlt_cos_id,
                key_path=c_key_path,
                db_uri=None,
            )
            hdpm.cosigner.append(w)
        return hdpm

    @classmethod
    async def create(
        cls,
        name: str,
        keys: GenericKeyType | None = None,
        owner: str = "",
        network: str | None = None,
        account_id: int = 0,
        purpose: int = 0,
        scheme: str = "bip32",
        sort_keys: bool = True,
        password: str = "",
        witness_type: str | None = None,
        encoding: str | None = None,
        multisig: bool | None = None,
        sigs_required: int | None = None,
        cosigner_id: int | None = None,
        key_path: list[str] | str | None = None,
        db_uri: str | None = None,
    ) -> Wallet:
        """Create wallet. Prefer from_mnemonic/from_key/from_multisig for typed APIs.

        This method accepts the union type ``GenericKeyType`` for backwards
        compatibility and dispatches to the appropriate typed classmethod.

        :param name: Unique name of this Wallet
        :type name: str
        :param keys: Masterkey to or list of keys to use for this wallet
        :type keys: str, bytes, int, HDKey, list
        :param owner: Wallet owner for your own reference
        :type owner: str
        :param network: Network name, use default if not specified
        :type network: str
        :param account_id: Account ID, default is 0
        :type account_id: int
        :param purpose: BIP43 purpose field
        :type purpose: int
        :param scheme: Key structure type, i.e. BIP32 or single
        :type scheme: str
        :param sort_keys: Sort keys according to BIP45 standard
        :type sort_keys: bool
        :param password: Password to protect passphrase
        :type password: str
        :param witness_type: Specify witness type
        :type witness_type: str
        :param encoding: Encoding used for address generation
        :type encoding: str
        :param multisig: Multisig wallet
        :type multisig: bool
        :param sigs_required: Number of signatures required
        :type sigs_required: int
        :param cosigner_id: Cosigner ID
        :type cosigner_id: int
        :param key_path: Key path for multisig wallet
        :type key_path: list, str
        :param db_uri: Unused, kept for API compatibility
        :type db_uri: str

        :return Wallet:
        """

        if multisig is None:
            multisig = bool(keys and isinstance(keys, list) and len(keys) > 1)

        if scheme not in ["bip32", "single"]:
            raise WalletError("Only bip32 or single key scheme's are supported at the moment")
        if witness_type not in [None, "legacy", "p2sh-segwit", "segwit"]:
            raise WalletError(f"Witness type {witness_type} not supported at the moment")
        if name.isdigit():
            raise WalletError(
                f"Wallet name '{name}' invalid."
                " Recovery: use a name with at least one letter"
            )

        # --- Multisig path: resolve keys and delegate to from_multisig ---
        if multisig:
            if password:
                raise WalletError("Password protected multisig wallets not supported")
            if scheme != "bip32":
                raise WalletError(f"Multisig wallets should use bip32 scheme not {scheme}")
            if not isinstance(keys, list):
                raise WalletError("Multisig wallets require a list of keys")
            if sigs_required is None:
                sigs_required = len(keys)

            # Resolve each key individually — the list is already validated above
            hdkey_list: list[HDKey] = []
            for k_item in keys:
                if not isinstance(k_item, (str, bytes, int, HDKey, WalletKey)):
                    raise WalletError(f"Invalid key type in list: {type(k_item)}")
                resolved = _resolve_single_key(k_item, password=password, network=network, encoding=encoding)
                if isinstance(resolved, Address):
                    raise WalletError("Addresses cannot be used in multisig wallets — provide HDKey or WIF")
                hdkey_list.append(resolved)

            # Infer network/witness_type from resolved keys
            for resolved_key in hdkey_list:
                if isinstance(resolved_key, HDKey):
                    if network is None:
                        network = resolved_key.network.name if is_network(resolved_key.network) else DEFAULT_NETWORK
                    if witness_type is None:
                        witness_type = resolved_key.witness_type

            return await cls.from_multisig(
                name,
                hdkey_list,
                sigs_required,
                owner=owner,
                network=network,
                account_id=account_id,
                purpose=purpose,
                sort_keys=sort_keys,
                witness_type=witness_type or DEFAULT_WITNESS_TYPE,
                encoding=encoding,
                cosigner_id=cosigner_id,
                key_path=key_path,
            )

        # --- Single key paths ---

        # No keys provided: generate random key
        if keys is None:
            resolved_network = network or DEFAULT_NETWORK
            resolved_wt = witness_type or DEFAULT_WITNESS_TYPE
            if not encoding:
                encoding = get_encoding_from_witness(resolved_wt)
            if not key_path:
                ks = [
                    k
                    for k in WALLET_KEY_STRUCTURES
                    if k["witness_type"] == resolved_wt and k["multisig"] is False and k["purpose"] is not None
                ]
                if ks and not purpose:
                    ks_purpose = ks[0]["purpose"]
                    purpose = int(ks_purpose) if isinstance(ks_purpose, (int, str)) else 0
                if ks and not encoding:
                    encoding = str(ks[0]["encoding"]) if ks[0]["encoding"] else None
                kp_val = ks[0]["key_path"]
                key_path = kp_val if isinstance(kp_val, (list, str)) else None
            if not encoding:
                encoding = get_encoding_from_witness(resolved_wt)
            return await cls._create(
                name,
                key=HDKey(network=resolved_network),
                owner=owner,
                network=resolved_network,
                account_id=account_id,
                purpose=purpose,
                scheme=scheme,
                parent_id=None,
                sort_keys=sort_keys,
                witness_type=resolved_wt,
                encoding=encoding,
                multisig=False,
                sigs_required=1,
                cosigner_id=None,
                key_path=key_path,
                db_uri=db_uri,
            )

        # Mnemonic string (multiple words)
        if isinstance(keys, str) and len(keys.split(" ")) > 1:
            if not network:
                raise WalletError("Please specify network when using passphrase to create a key")
            return await cls.from_mnemonic(
                name,
                keys,
                password=password,
                network=network,
                account_id=account_id,
                purpose=purpose,
                witness_type=witness_type or DEFAULT_WITNESS_TYPE,
                encoding=encoding,
                key_path=key_path,
            )

        # At this point keys is str | bytes | int | HDKey | WalletKey (lists already handled above)
        single_input: str | bytes | int | HDKey | WalletKey
        if isinstance(keys, (str, bytes, int, HDKey, WalletKey)):
            single_input = keys
        else:
            raise WalletError(f"Unexpected key type: {type(keys)}")
        single_key: HDKey | Address = _resolve_single_key(
            single_input, password=password, network=network, encoding=encoding
        )

        if isinstance(single_key, Address):
            # Address-based single key wallet
            resolved_network = network or (
                single_key.network.name if is_network(single_key.network) else DEFAULT_NETWORK
            )
            resolved_wt = witness_type or DEFAULT_WITNESS_TYPE
            if not encoding:
                encoding = get_encoding_from_witness(resolved_wt)
            return await cls._create(
                name,
                key=single_key,
                owner=owner,
                network=resolved_network,
                account_id=account_id,
                purpose=purpose,
                scheme="single",
                parent_id=None,
                sort_keys=sort_keys,
                witness_type=resolved_wt,
                encoding=encoding,
                multisig=False,
                sigs_required=1,
                cosigner_id=None,
                key_path=key_path or ["m"],
                db_uri=db_uri,
            )

        # single_key is HDKey
        return await cls.from_key(
            name,
            single_key,
            network=network,
            account_id=account_id,
            purpose=purpose,
            scheme=scheme,
            witness_type=witness_type,
            encoding=encoding,
            key_path=key_path,
        )

    @classmethod
    async def open(cls, ident: str | int, db_uri: str | None = None) -> Wallet:
        store = await _get_store()

        sw = store.get_wallet(name=ident) if isinstance(ident, str) else store.get_wallet(wallet_id=ident)

        if not sw:
            raise WalletError(
                f"Unable to find wallet: {ident}."
                " Recovery: use 'fluxwallet wallet list' to see wallets"
            )

        wallet = Wallet(sw)
        await wallet._sync_from_store()

        return wallet

    @classmethod
    async def list_all(cls, include_cosigners: bool = False) -> list[dict[str, str | int | None]]:
        """List all wallets.

        Returns list of dicts with id, name, owner, network, etc.
        """
        store = await _get_store()
        wallets: list[dict[str, str | int | None]] = []
        for w in store.list_wallets():
            if w.parent_id and not include_cosigners:
                continue
            wallets.append(
                {
                    "id": w.id,
                    "name": w.name,
                    "owner": w.owner,
                    "network": w.network_name,
                    "purpose": w.purpose,
                    "scheme": w.scheme,
                    "main_key_id": w.main_key_id,
                    "parent_id": w.parent_id,
                }
            )
        return wallets

    @classmethod
    async def delete(cls, wallet: str | int, *, force: bool = False) -> bool:
        """Delete wallet and associated keys and transactions."""
        store = await _get_store()

        if isinstance(wallet, int) or (isinstance(wallet, str) and wallet.isdigit()):
            w = store.get_wallet(wallet_id=int(wallet) if isinstance(wallet, str) else wallet)
        else:
            w = store.get_wallet(name=str(wallet))

        if not w:
            raise WalletError(
                f"Wallet '{wallet}' not found."
                " Recovery: use 'fluxwallet wallet list' to see wallets"
            )

        wallet_id = w.id

        if not force:
            keys = store.get_keys(wallet_id)
            if any(k.balance and k.is_private for k in keys):
                raise WalletError(
                    "Wallet still has unspent outputs."
                    " Recovery: sweep funds first, or use 'force=True'"
                )

        store.delete_wallet(wallet_id)
        await _save_store()

        _logger.info(f"Wallet '{wallet}' deleted")
        return True

    @classmethod
    async def empty(cls, wallet: str | int) -> bool:
        """Remove all generated keys and transactions from wallet, keeping the masterkey."""
        store = await _get_store()

        if isinstance(wallet, int) or (isinstance(wallet, str) and wallet.isdigit()):
            w = store.get_wallet(wallet_id=int(wallet) if isinstance(wallet, str) else wallet)
        else:
            w = store.get_wallet(name=str(wallet))

        if not w:
            raise WalletError(
                f"Wallet '{wallet}' not found."
                " Recovery: use 'fluxwallet wallet list' to see wallets"
            )

        wallet_id = w.id

        keys_to_remove = [k for k in store.get_keys(wallet_id) if k.parent_id and k.parent_id != 0]
        for k in keys_to_remove:
            store._remove_key(k.id)

        tx_ids = list(store._txs_by_wallet.get(wallet_id, []))
        for tid in tx_ids:
            store._remove_transaction(tid)

        await _save_store()
        _logger.info(f"All keys and transactions from wallet '{wallet}' deleted")
        return True

    def __enter__(self) -> Wallet:
        return self

    def __init__(
        self,
        stored_wallet: StoredWallet,
        *,
        main_key: HDKey | None = None,
    ) -> None:
        """Open a wallet with given StoredWallet object.

        :param stored_wallet: StoredWallet dataclass
        :type stored_wallet: StoredWallet
        :param main_key: Pass main key object to save time
        :type main_key: HDKey
        """

        self.wallet_id: int = stored_wallet.id

        self._name: str = stored_wallet.name
        self._owner: str = stored_wallet.owner

        self.network: Network = Network(stored_wallet.network_name)

        self.purpose: int = stored_wallet.purpose
        self.scheme: str = stored_wallet.scheme

        self._balance: int | None = None
        self._balances: list[dict[str, str | int]] = []

        self.main_key_id: int | None = stored_wallet.main_key_id

        self.main_key: WalletKey | HDKey | None = main_key

        self._default_account_id: int | None = stored_wallet.default_account_id
        self.multisig_n_required: int = stored_wallet.multisig_n_required

        self.sort_keys: bool = stored_wallet.sort_keys

        self.providers: list[str] | None = None
        self.witness_type: str = stored_wallet.witness_type
        self.encoding: str = stored_wallet.encoding
        self.multisig: bool = stored_wallet.multisig
        self.cosigner_id: int | None = stored_wallet.cosigner_id
        self.ssp_peer_pubkey: str | None = stored_wallet.ssp_peer_pubkey

        self.script_type: str = script_type_default(self.witness_type, self.multisig, locking_script=True) or "p2pkh"

        self.key_path: list[str] = [] if not stored_wallet.key_path else stored_wallet.key_path.split("/")
        self.depth_public_master: int = 0
        self.parent_id: int | None = stored_wallet.parent_id

        self.discovered: bool = stored_wallet.discovered

        self.last_scanned_height: int = 0

        self.processed_txids: set[str] | None = None

        self.db_cache_uri: str = ""

        self._key_mgr = WalletKeyManager(self)
        self._balance_mgr = WalletBalanceManager(self)
        self._scanner = WalletScanner(self)
        self._tx_mgr = WalletTransactionManager(self)

    def __repr__(self) -> str:
        return f'<Wallet(name="{self.name}")>'

    def __str__(self) -> str:
        return self.name

    async def _get_account_defaults(
        self,
        network: str | None = None,
        account_id: int | None = None,
        key_id: int | None = None,
    ) -> tuple[str, int, StoredKey | None]:
        """Check parameter values for network and account ID, return defaults if not specified."""
        if key_id:
            key = await self.key(key_id)
            network = key.network_name
            account_id = key.account_id

        if network is None:
            network = self.network.name

        if account_id is None and network == self.network.name:
            account_id = self.default_account_id

        store = await _get_store()
        matching_keys = store.get_keys(
            wallet_id=self.wallet_id,
            depth=self.depth_public_master,
            network_name=network,
        )
        # Filter by purpose
        matching_keys = [k for k in matching_keys if k.purpose == self.purpose]

        if account_id is not None:
            matching_keys = [k for k in matching_keys if k.account_id == account_id]

        count = len(matching_keys)
        first_key = matching_keys[0] if matching_keys else None

        if count > 1 and "account'" in self.key_path:
            _logger.warning(
                f"No account_id specified and more than one account ({count}) found for this network {network}."
            )

        if account_id is None:
            account_id = first_key.account_id if first_key else 0

        return network, account_id, first_key

    @property
    def default_account_id(self) -> int | None:
        return self._default_account_id

    async def set_default_account_id(self, value: int) -> None:
        self._default_account_id = value
        store = await _get_store()
        sw = store.get_wallet(wallet_id=self.wallet_id)
        if sw:
            sw.default_account_id = value
            store._dirty = True
        await _save_store()

    @property
    def owner(self) -> str:
        return self._owner

    async def set_owner(self, value: str) -> None:
        self._owner = value
        store = await _get_store()
        sw = store.get_wallet(wallet_id=self.wallet_id)
        if sw:
            sw.owner = value
            store._dirty = True
        await _save_store()

    async def set_ssp_peer_pubkey(self, value: str) -> None:
        """Store the SSP peer's BTC identity pubkey for relay auth derivation."""
        self.ssp_peer_pubkey = value
        store = await _get_store()
        sw = store.get_wallet(wallet_id=self.wallet_id)
        if sw:
            sw.ssp_peer_pubkey = value
            store._dirty = True
        await _save_store()

    async def add_cosigner(self, key: HDKey) -> None:
        """Add the second cosigner to a pending multisig wallet.

        Called during SSP pairing to add the peer's public key.
        """
        if not self.multisig:
            raise WalletError("Not a multisig wallet")
        if len(self.cosigner) != 1:
            raise WalletError(f"Expected 1 cosigner, found {len(self.cosigner)}")

        wlt_cos_id = 1
        wn = f"{self.name}-cosigner-{wlt_cos_id}"

        existing = self.cosigner[0]

        co_scheme = "bip32"
        c_key_path: list[str] | str | None = existing.key_path
        if key.key_type == "single":
            co_scheme = "single"
            c_key_path = ["m"]

        w = await Wallet._create(
            name=wn,
            key=key,
            owner=existing.owner,
            network=self.network.name,
            account_id=existing.default_account_id or 0,
            purpose=self.purpose,
            scheme=co_scheme,
            parent_id=self.wallet_id,
            sort_keys=self.sort_keys,
            witness_type=self.witness_type,
            encoding=self.encoding,
            multisig=True,
            sigs_required=None,
            cosigner_id=wlt_cos_id,
            key_path=c_key_path,
            db_uri=None,
        )
        self.cosigner.append(w)

    @property
    def name(self) -> str:
        return self._name

    async def set_name(self, value: str) -> None:
        store = await _get_store()
        old_name = self._name
        store.rename_wallet(self.wallet_id, value)
        self._name = value

        for k in store.keys.values():
            if k.wallet_id != self.wallet_id:
                continue
            if k.key_type == "sapling" and k.name == f"{old_name}_sapling":
                k.name = f"{value}_sapling"
                store._dirty = True
            elif k.key_type == "sapling_address" and k.name.startswith(f"{old_name}_z"):
                suffix = k.name[len(old_name) :]
                k.name = f"{value}{suffix}"
                store._dirty = True

        await _save_store()

    async def get_cosigner(self) -> list[Wallet]:
        store = await _get_store()
        child_wallets = [w for w in store.list_wallets() if w.parent_id == self.wallet_id]
        child_wallets.sort(key=lambda w: w.name)

        cosigners = []
        for w in child_wallets:
            cosigner = Wallet(w)
            await cosigner._sync_from_store()
            cosigners.append(cosigner)
        return cosigners

    async def sync(self, session: object = None) -> None:
        """Load wallet state including cosigners."""
        await self._sync_from_store()

    async def _sync_from_store(self) -> None:
        """Load wallet state from the store."""
        store = await _get_store()

        if self.main_key_id:
            sk = store.get_key(key_id=self.main_key_id)
            if sk:
                self.main_key = WalletKey(sk)
            else:
                raise WalletError(f"Key with id {self.main_key_id} not found")

        if self._default_account_id is None:
            self._default_account_id = 0
            if self.main_key and is_wallet_key(self.main_key):
                self._default_account_id = self.main_key.account_id

        _logger.info(f"Opening wallet '{self.name}'")

        self._key_objects: dict[int | None, WalletKey | HDKey | None] = {self.main_key_id: self.main_key}

        if self.main_key and self.main_key.depth > 0:
            self.depth_public_master = self.main_key.depth
            self.key_depth = self.depth_public_master + len(self.key_path) - 1
        else:
            hardened_keys = [x for x in self.key_path if x[-1:] == "'"]
            if hardened_keys:
                self.depth_public_master = self.key_path.index(hardened_keys[-1])
            self.key_depth = len(self.key_path) - 1
        self.last_updated = None

        self.cosigner = await self.get_cosigner()

    async def default_network_set(self, network: str | Network) -> None:
        if not is_network(network):
            network = Network(network)
        self.network = network
        store = await _get_store()
        sw = store.get_wallet(wallet_id=self.wallet_id)
        if sw:
            sw.network_name = network.name
            store._dirty = True
        await _save_store()

    async def import_master_key(self, hdkey: HDKey | str, name: str = "Masterkey (imported)") -> WalletKey:
        """Import (another) masterkey in this wallet.

        :param hdkey: Private key
        :type hdkey: HDKey, str
        :param name: Key name of masterkey
        :type name: str
        :return HDKey: Main key as HDKey object
        """
        return await self._key_mgr.import_master_key(hdkey, name)

    async def import_key(
        self,
        key: HDKey | Address | str | bytes | int,
        account_id: int = 0,
        name: str = "",
        network: str | None = None,
        purpose: int = 44,
        key_type: str | None = None,
    ) -> WalletKey | None:
        """Add new single key to wallet.

        :param key: Key to import
        :type key: str, bytes, int, HDKey, Address
        :param account_id: Account ID
        :type account_id: int
        :param name: Specify name for key
        :type name: str
        :param network: Network name
        :type network: str
        :param purpose: BIP definition used, default is BIP44
        :type purpose: int
        :param key_type: Key type of imported key
        :type key_type: str
        :return WalletKey:
        """
        return await self._key_mgr.import_key(key, account_id, name, network, purpose, key_type)

    async def _new_key_multisig(
        self,
        public_keys: list[WalletKey],
        name: str,
        account_id: int,
        change: int,
        cosigner_id: int | None,
        network: str,
        address_index: int,
    ) -> WalletKey:
        return await self._key_mgr._new_key_multisig(
            public_keys, name, account_id, change, cosigner_id, network, address_index
        )

    async def new_key(
        self,
        name: str = "",
        account_id: int | None = None,
        change: int = 0,
        cosigner_id: int | None = None,
        network: str | None = None,
    ) -> WalletKey:
        """Create a new HD Key derived from this wallet's masterkey.

        :param name: Key name
        :type name: str
        :param account_id: Account ID
        :type account_id: int
        :param change: Change (1) or payments (0). Default is 0
        :type change: int
        :param cosigner_id: Cosigner ID for key path
        :type cosigner_id: int
        :param network: Network name
        :type network: str
        :return WalletKey:
        """
        return await self._key_mgr.new_key(name, account_id, change, cosigner_id, network)

    async def new_key_change(
        self, name: str = "", account_id: int | None = None, network: str | None = None
    ) -> WalletKey:
        """Create new change key.

        Calls :func:`new_key` with change=1.
        """
        return await self._key_mgr.new_key_change(name, account_id, network)

    async def new_sapling_key(self, change: int = 0, name: str = "") -> StoredKey:
        """Create a new diversified Sapling z-address (receive or change)."""
        return await self._key_mgr.new_sapling_key(change, name)

    async def new_sapling_key_change(self, name: str = "") -> StoredKey:
        """Create a new Sapling change z-address."""
        return await self._key_mgr.new_sapling_key_change(name)

    async def scan_key(
        self,
        key: int | WalletKey,
        update_confirmations: bool = True,
        independent: bool = True,
    ) -> set[str]:
        """Scan for new transactions for specified wallet key."""
        return await self._scanner.scan_key(key, update_confirmations, independent)

    async def scan(
        self,
        scan_gap_limit: int = 5,
        account_id: int | None = None,
        key_type: KeyType = KeyType.ANY,
        rescan_used: bool = False,
        network: str | None = None,
        keys_ignore: list[int] | None = None,
        blockcount: int | None = None,
    ) -> set[str]:
        return await self._scanner.scan(
            scan_gap_limit, account_id, key_type, rescan_used, network, keys_ignore, blockcount
        )

    async def scan_existing(
        self,
        scan_gap_limit: int = 5,
        account_id: int | None = None,
        change: bool | None = None,
        rescan_used: bool = False,
        network: str | None = None,
        keys_ignore: list[int] | None = None,
        blockcount: int | None = None,
    ) -> set[str]:
        """Scan existing keys for new transactions."""
        return await self._scanner.scan_existing(
            scan_gap_limit, account_id, change, rescan_used, network, keys_ignore, blockcount
        )

    async def _get_unused_keys(
        self,
        account_id: int | None = None,
        network: str | None = None,
        cosigner_id: int | None = None,
        number_of_keys: int = 1,
        key_type: KeyType = KeyType.PAYMENT,
        force_create: bool = False,
    ) -> list[WalletKey]:
        """Get unused wallet keys for account / network."""
        return await self._key_mgr._get_unused_keys(
            account_id, network, cosigner_id, number_of_keys,
            _coerce_key_type(key_type), force_create,
        )

    async def get_key(
        self,
        account_id: int | None = None,
        network: str | None = None,
        cosigner_id: int | None = None,
        key_type: KeyType | _KeyType = KeyType.PAYMENT,
    ) -> WalletKey:
        """Get an unused key or create a new one."""
        return await self._key_mgr.get_key(account_id, network, cosigner_id, key_type)

    async def get_keys(
        self,
        account_id: int | None = None,
        network: str | None = None,
        cosigner_id: int | None = None,
        number_of_keys: int = 1,
        key_type: KeyType | _KeyType = KeyType.PAYMENT,
        force_create: bool = False,
    ) -> list[WalletKey]:
        """Get a list of unused keys or create new ones."""
        return await self._key_mgr.get_keys(
            account_id, network, cosigner_id, number_of_keys, key_type, force_create
        )

    async def get_key_change(self, account_id: int | None = None, network: str | None = None) -> WalletKey:
        """Get unused change key."""
        return await self._key_mgr.get_key_change(account_id, network)

    async def get_keys_change(
        self,
        account_id: int | None = None,
        network: str | None = None,
        number_of_keys: int = 1,
    ) -> list[WalletKey]:
        """Get unused change keys."""
        return await self._key_mgr.get_keys_change(account_id, network, number_of_keys)

    async def new_account(
        self, name: str = "", account_id: int | None = None, network: str | None = None
    ) -> WalletKey | None:
        """Create a new account with a child key for payments and 1 for change.

        :param name: Account Name
        :type name: str
        :param account_id: Account ID. Default is last accounts ID + 1
        :type account_id: int
        :param network: Network name
        :type network: str
        :return WalletKey:
        """
        return await self._key_mgr.new_account(name, account_id, network)

    async def path_expand(
        self,
        path: list[str | int] | str,
        level_offset: int | None = None,
        account_id: int | None = None,
        cosigner_id: int = 0,
        address_index: int | None = None,
        change: int = 0,
        network: str = DEFAULT_NETWORK,
    ) -> list[str]:
        """Create key path. Specify part of key path to expand to key path used in this wallet.

        :param path: Part of path
        :type path: list, str
        :param level_offset: Just create part of path
        :type level_offset: int
        :param account_id: Account ID
        :type account_id: int
        :param cosigner_id: ID of cosigner
        :type cosigner_id: int
        :param address_index: Index of key
        :type address_index: int
        :param change: Change key = 1 or normal = 0
        :type change: int
        :param network: Network name
        :type network: str
        :return list:
        """
        return await self._key_mgr.path_expand(
            path, level_offset, account_id, cosigner_id, address_index, change, network
        )

    async def key_for_path(
        self,
        path: list[str | int] | str,
        level_offset: int | None = None,
        name: str | None = None,
        account_id: int | None = None,
        cosigner_id: int | None = None,
        address_index: int = 0,
        change: int = 0,
        network: str | None = None,
        recreate: bool = False,
    ) -> WalletKey | None:
        """Return key for specified path. Derive all wallet keys in path if they don't already exist.

        :param path: Part of key path, i.e. [0, 0] for [change=0, address_index=0]
        :type path: list, str
        :param level_offset: Create part of path
        :type level_offset: int
        :param name: Specify key name for latest/highest key in structure
        :type name: str
        :param account_id: Account ID
        :type account_id: int
        :param cosigner_id: ID of cosigner
        :type cosigner_id: int
        :param address_index: Index of key
        :type address_index: int
        :param change: Change key = 1 or normal = 0
        :type change: int
        :param network: Network name
        :type network: str
        :param recreate: Recreate key even if already found
        :type recreate: bool
        :return WalletKey:
        """
        return await self._key_mgr.key_for_path(
            path, level_offset, name, account_id, cosigner_id, address_index, change, network, recreate
        )

    async def keys(
        self,
        account_id: int | None = None,
        name: str | None = None,
        key_id: int | None = None,
        change: int | None = None,
        depth: int | None = None,
        used: bool | None = None,
        is_private: bool | None = None,
        has_balance: bool | None = None,
        is_active: bool | None = None,
        network: str | None = None,
        include_private: bool | None = False,
        as_dict: bool = False,
        eager_load_network: bool = False,
    ) -> list[StoredKey]:
        """Search for keys in store.

        :param account_id: Search for account ID
        :type account_id: int
        :param name: Search for Name
        :type name: str
        :param key_id: Search for Key ID
        :type key_id: int
        :param change: Search for Change
        :type change: int
        :param depth: Only include keys with this depth
        :type depth: int
        :param used: Only return used or unused keys
        :type used: bool
        :param is_private: Only return private keys
        :type is_private: bool
        :param has_balance: Only include keys with/without a balance
        :type has_balance: bool
        :param is_active: Only include active keys (balance or unused)
        :type is_active: bool
        :param network: Network name filter
        :type network: str
        :param include_private: Include private key information in dictionary
        :type include_private: bool
        :param as_dict: Return keys as dictionary objects
        :type as_dict: bool
        :return list of StoredKey:
        """
        return await self._key_mgr.keys(
            account_id, name, key_id, change, depth, used, is_private,
            has_balance, is_active, network, include_private, as_dict, eager_load_network,
        )

    async def keys_networks(self, used: bool | None = None, as_dict: bool = False) -> list[StoredKey]:
        """Get keys of defined networks for this wallet."""
        return await self._key_mgr.keys_networks(used, as_dict)

    async def keys_accounts(
        self,
        account_id: int | None = None,
        network: str = DEFAULT_NETWORK,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get account key(s) for current wallet."""
        return await self._key_mgr.keys_accounts(account_id, network, as_dict)

    async def keys_addresses(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        is_active: bool | None = None,
        change: int | None = None,
        network: str | None = None,
        depth: int | None = None,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get address keys of specified account_id for current wallet."""
        return await self._key_mgr.keys_addresses(account_id, used, is_active, change, network, depth, as_dict)

    async def keys_address_payment(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get payment addresses (change=0)."""
        return await self._key_mgr.keys_address_payment(account_id, used, network, as_dict)

    async def keys_address_change(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        as_dict: bool = False,
    ) -> list[StoredKey]:
        """Get change addresses (change=1)."""
        return await self._key_mgr.keys_address_change(account_id, used, network, as_dict)

    async def addresslist(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        change: int | None = None,
        depth: int | None = None,
        key_id: int | None = None,
    ) -> list[str]:
        """Get list of addresses defined in current wallet."""
        return await self._key_mgr.addresslist(account_id, used, network, change, depth, key_id)

    async def key(self, term: int | str | StoredKey) -> WalletKey:
        """Return single key with given ID or name as WalletKey object.

        :param term: Search term can be key ID, key address, key WIF or key name
        :type term: int, str
        :return WalletKey: Single key as object
        """
        return await self._key_mgr.key(term)

    async def account(self, account_id: int) -> WalletKey:
        """Returns wallet key of specific BIP44 account.

        :param account_id: ID of account
        :type account_id: int
        :return WalletKey:
        """
        return await self._key_mgr.account(account_id)

    async def accounts(self, network: str = DEFAULT_NETWORK) -> list[int]:
        """Get list of accounts for this wallet."""
        return await self._key_mgr.accounts(network)

    @overload
    async def networks(self, as_dict: Literal[True]) -> list[dict[str, object]]: ...
    @overload
    async def networks(self, as_dict: Literal[False] = ...) -> list[Network]: ...
    async def networks(self, as_dict: bool = False) -> list[Network] | list[dict[str, object]]:
        """Get list of networks used by this wallet."""
        nw_list = [self.network]
        if self.multisig and self.cosigner:
            store = await _get_store()
            all_keys = store.get_keys(
                wallet_id=self.wallet_id,
                depth=self.key_depth,
            )
            nw_names = {k.network_name for k in all_keys}
            for nw_name in nw_names:
                if nw_name in AUTH_ONLY_NETWORKS:
                    continue
                if network_defined(nw_name):
                    nw_list.append(Network(nw_name))
        elif self.main_key is not None and hasattr(self.main_key, "key_type") and self.main_key.key_type != "single":
            wks = await self.keys_networks()
            for wk in wks:
                if wk.network_name in AUTH_ONLY_NETWORKS:
                    continue
                if network_defined(wk.network_name):
                    nw_list.append(Network(wk.network_name))

        networks = []
        nw_list = list(dict.fromkeys(nw_list))
        for nw in nw_list:
            if as_dict:
                nw = nw.__dict__
            networks.append(nw)

        return networks

    async def network_list(self, field: str = "name") -> list[str]:
        """Returns flat list of currently used networks."""
        return [getattr(x, field) for x in await self.networks()]

    async def balance_update_from_serviceprovider(
        self, account_id: int | None = None, network: str | None = None
    ) -> int:
        """Update balance from service provider."""
        return await self._balance_mgr.balance_update_from_serviceprovider(account_id, network)

    @overload
    async def balance(
        self,
        account_id: int | None = None,
        network: str | None = None,
        *,
        as_string: Literal[True],
    ) -> str: ...
    @overload
    async def balance(
        self,
        account_id: int | None = None,
        network: str | None = None,
        as_string: Literal[False] = ...,
    ) -> int: ...
    async def balance(
        self,
        account_id: int | None = None,
        network: str | None = None,
        as_string: bool = False,
    ) -> int | str:
        """Get total of unspent outputs."""
        return await self._balance_mgr.balance(account_id, network, as_string=as_string)

    async def _balance_update(
        self,
        account_id: int | None = None,
        network: str | None = None,
        key_id: int | None = None,
        min_confirms: int = 0,
    ) -> list[dict[str, str | int]]:
        """Update balance from UTXO's in store."""
        return await self._balance_mgr._balance_update(account_id, network, key_id, min_confirms)

    async def utxos_update(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        networks: list[str] | str | None = None,
        key_id: int | None = None,
        depth: int | None = None,
        change: int | None = None,
        update_balance: bool = True,
        max_utxos: int = MAX_TRANSACTIONS,
    ) -> int:
        """Sync UTXO state from the network.

        The network is the source of truth.
        """
        return await self._balance_mgr.utxos_update(
            account_id, used, networks, key_id, depth, change, update_balance, max_utxos
        )

    async def utxos(
        self,
        account_id: int | None = None,
        network: str | None = None,
        min_confirms: int = 0,
        key_id: int | list[int] | None = None,
    ) -> list[Utxo]:
        """Get UTXO's from store."""
        return await self._balance_mgr.utxos(account_id, network, min_confirms, key_id)

    async def utxo_add(
        self,
        address: str,
        value: int,
        txid: str | bytes | int,
        output_n: int,
        confirmations: int = 1,
        script: str = "",
    ) -> None:
        """Add a single UTXO to the wallet store without affecting existing UTXOs."""
        return await self._balance_mgr.utxo_add(address, value, txid, output_n, confirmations, script)

    async def utxo_last(self, address: str) -> str:
        """Get transaction ID for latest utxo for given address."""
        return await self._balance_mgr.utxo_last(address)

    async def transactions_update_confirmations(self) -> None:
        """Update number of confirmations and status for transactions in store."""
        return await self._scanner.transactions_update_confirmations()

    async def transactions_update_by_txids(self, txids: list[bytes] | bytes) -> None:
        """Update transactions with provided transaction IDs."""
        return await self._scanner.transactions_update_by_txids(txids)

    async def create_and_store_wallet_tx(self, tx: TransactionMixin, addresslist: list[str]) -> set[tuple[str, int]]:
        return await self._scanner.create_and_store_wallet_tx(tx, addresslist)

    async def update_input_output_key_ids(
        self,
        account_id: int | None = None,
        network: str | None = None,
        *,
        tx_ids: list[int] | None = None,
    ) -> None:
        return await self._scanner.update_input_output_key_ids(account_id, network, tx_ids=tx_ids)

    async def store_transactions(self, txs: list[WalletTransaction]) -> tuple[set[tuple[str, int]], set[int]]:
        return await self._scanner.store_transactions(txs)

    async def transactions_update(
        self,
        account_id: int | None = None,
        used: bool | None = None,
        network: str | None = None,
        key_id: int | None = None,
        depth: int | None = None,
        change: int | None = None,
        limit: int = MAX_TRANSACTIONS,
        update_confirmations: bool = True,
    ) -> set[int]:
        """Update wallet transactions from service providers."""
        return await self._scanner.transactions_update(
            account_id, used, network, key_id, depth, change, limit, update_confirmations
        )

    @overload
    async def transaction_last(self, address: str, by_index: Literal[True]) -> int: ...
    @overload
    async def transaction_last(self, address: str, by_index: Literal[False] = ...) -> str: ...
    async def transaction_last(self, address: str, by_index: bool = False) -> str | int:
        """Get transaction ID or index for latest transaction for given address."""
        return await self._scanner.transaction_last(address, by_index)

    @overload
    async def transactions(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        *,
        as_dict: Literal[True],
    ) -> list[dict[str, object]]: ...
    @overload
    async def transactions(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        *,
        as_dict: Literal[False] = ...,
    ) -> list[WalletTransaction[FluxTransaction]]: ...
    async def transactions(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        as_dict: bool = False,
    ) -> list[WalletTransaction[FluxTransaction]] | list[dict[str, object]]:
        """Get all known transactions for this wallet."""
        return await self._scanner.transactions(account_id, network, include_new, key_id, as_dict=as_dict)

    async def transactions_full(
        self,
        network: str | None = None,
        include_new: bool = False,
        limit: int = 0,
        offset: int = 0,
    ) -> list[WalletTransaction]:
        """Get all transactions of this wallet as WalletTransaction objects."""
        return await self._scanner.transactions_full(network, include_new, limit, offset)

    async def transactions_export(
        self,
        account_id: int | None = None,
        network: str | None = None,
        include_new: bool = False,
        key_id: int | None = None,
        skip_change: bool = True,
    ) -> list[tuple[object, ...]]:
        """Export wallet transactions as list of tuples."""
        return await self._scanner.transactions_export(account_id, network, include_new, key_id, skip_change)

    async def transaction(self, txid: str, addresslist: list[str] | None = None) -> WalletTransaction | None:
        """Get WalletTransaction object for given transaction ID."""
        return await self._scanner.transaction(txid, addresslist)

    async def transaction_spent(self, txid: str, output_n: int | bytes) -> str | None:
        """Check if transaction output is spent, return spending txid."""
        return await self._scanner.transaction_spent(txid, output_n)

    async def _objects_by_key_id(self, key_id: int) -> tuple[list[HDKey | Key | bytes | str], StoredKey]:
        return await self._tx_mgr._objects_by_key_id(key_id)

    async def select_inputs(
        self,
        amount: int,
        variance: int | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        min_confirms: int = 1,
        max_utxos: int | None = None,
        return_input_obj: bool = True,
        skip_dust_amounts: bool = True,
    ) -> list[Input] | list[StoredTxOutput]:
        """Select available UTXO's which can be used as inputs for a transaction."""
        return await self._tx_mgr.select_inputs(
            amount, variance, input_key_id, account_id, network,
            min_confirms, max_utxos, return_input_obj, skip_dust_amounts,
        )

    async def transaction_create(
        self,
        outputs: list[Output] | list[tuple[str, int]] | list[tuple[str | Address | HDKey | WalletKey, int]],
        inputs: list[Input] | list[tuple[str, int, int, int]] | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | str | None = None,
        min_confirms: int = 1,
        max_utxos: int | None = None,
        locktime: int = 0,
        number_of_change_outputs: int = 1,
        random_output_order: bool = True,
        message: str = "",
    ) -> WalletTransaction:
        """Create new transaction with specified outputs."""
        return await self._tx_mgr.transaction_create(
            outputs, inputs, input_key_id, account_id, network, fee,
            min_confirms, max_utxos, locktime, number_of_change_outputs,
            random_output_order, message,
        )

    async def transaction_import(self, t: TransactionMixin | dict[str, object]) -> WalletTransaction:
        """Import a Transaction into this wallet."""
        return await self._tx_mgr.transaction_import(t)

    def build_transaction(self, **kwargs: object) -> TransactionBuilder:
        """Return a fluent TransactionBuilder.

        Usage::

            wt = await wallet.build_transaction().to("t1abc...", 50000).fee(10000).send()
        """
        return self._tx_mgr.build_transaction(**kwargs)

    async def send(
        self,
        outputs: list[tuple[str, int]] | list[tuple[str | Address | HDKey | WalletKey, int]],
        inputs: list[tuple[str, int, int, int]] | list[Input] | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | None = None,
        min_confirms: int = 1,
        priv_keys: HDKey | list[HDKey] | list[HDKey | str] | None = None,
        max_utxos: int | None = None,
        locktime: int = 0,
        offline: bool = True,
        number_of_change_outputs: int = 1,
        message: str = "",
    ) -> WalletTransaction:
        """Create a new transaction with specified outputs and push it to the network."""
        return await self._tx_mgr.send(
            outputs, inputs, input_key_id, account_id, network, fee,
            min_confirms, priv_keys, max_utxos, locktime, offline,
            number_of_change_outputs, message,
        )

    async def send_to(
        self,
        to_address: str | Address | HDKey | WalletKey,
        amount: int,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | None = None,
        min_confirms: int = 1,
        priv_keys: HDKey | list[HDKey] | list[HDKey | str] | None = None,
        locktime: int = 0,
        offline: bool = True,
        number_of_change_outputs: int = 1,
        message: str = "",
    ) -> WalletTransaction:
        """Create transaction and send it.

        Wrapper for wallet :func:`send` method.
        """
        return await self._tx_mgr.send_to(
            to_address, amount, input_key_id, account_id, network, fee,
            min_confirms, priv_keys, locktime, offline, number_of_change_outputs, message,
        )

    async def sweep(
        self,
        to_address: str | list[tuple[str, int]],
        account_id: int | None = None,
        input_key_id: int | list[int] | None = None,
        network: str | None = None,
        max_utxos: int = 999,
        min_confirms: int = 1,
        fee_per_kb: int | None = None,
        fee: int | str | None = None,
        locktime: int = 0,
        offline: bool = True,
    ) -> WalletTransaction:
        """Sweep all unspent transaction outputs and send them to one or more output addresses."""
        return await self._tx_mgr.sweep(
            to_address, account_id, input_key_id, network, max_utxos,
            min_confirms, fee_per_kb, fee, locktime, offline,
        )

    def wif(self, is_private: bool = False, account_id: int = 0) -> str | None:
        """Return Wallet Import Format string for master key.

        For multisig wallets, use :meth:`wif_multisig` instead.
        """
        return self._key_mgr.wif(is_private, account_id)

    def wif_multisig(self, is_private: bool = False) -> list[str]:
        """Return WIF strings for all cosigners of a multisig wallet."""
        return self._key_mgr.wif_multisig(is_private)

    async def public_master(
        self,
        account_id: int | None = None,
        name: str | None = None,
        as_private: bool = False,
        network: str | None = None,
    ) -> WalletKey | list[WalletKey]:
        """Return public master key(s) for this wallet."""
        return await self._key_mgr.public_master(account_id, name, as_private, network)

    async def transaction_load(self, txid: str | None = None, filename: str | None = None) -> WalletTransaction:
        """Load transaction object from file."""
        return await self._tx_mgr.transaction_load(txid, filename)

    async def sapling_spending_key(self) -> SaplingSpendingKey:
        """Load the Sapling spending key for this wallet."""
        return await self._key_mgr.sapling_spending_key()

    async def z_address(self, change: int = 0) -> str:
        """Get the latest Sapling z-address for this wallet."""
        return await self._key_mgr.z_address(change)

    async def open_shielded(self, explorer_url: str | None = None) -> ShieldedWallet:
        """Create a ShieldedWallet backed by this wallet's Sapling key."""
        return await self._tx_mgr.open_shielded(explorer_url)

    async def transparent_inputs_for_shielding(
        self,
        amount: int,
        fee: int,
    ) -> list[dict[str, bytes | int]]:
        """Select UTXOs and return transparent inputs for a shielding transaction."""
        return await self._tx_mgr.transparent_inputs_for_shielding(amount, fee)

    async def info(self, detail: int = 3) -> None:
        """Prints wallet information to standard output."""

        print("=== WALLET ===")
        print(f" ID                             {self.wallet_id}")
        print(f" Name                           {self.name}")
        print(f" Owner                          {self.owner}")
        print(f" Scheme                         {self.scheme}")
        print(f" Multisig                       {self.multisig}")
        if self.multisig:
            print(" Multisig Wallet IDs            {}".format(str([w.wallet_id for w in self.cosigner]).strip("[]")))
            print(f" Cosigner ID                    {self.cosigner_id}")
        print(f" Witness type                   {self.witness_type}")
        print(f" Main network                   {self.network.name}")
        print(f" Latest update                  {self.last_updated}")

        if self.multisig:
            print("\n= Multisig Public Master Keys =")
            for cs in self.cosigner:
                print(
                    f"{cs.cosigner_id:5} "
                    f"{(cs.main_key.key_id if is_wallet_key(cs.main_key) else ''):>3} "
                    f"{cs.wif(is_private=False):<70} {cs.scheme:<6} "
                    f"{'main' if is_wallet_key(cs.main_key) and cs.main_key.is_private else 'cosigner':<8} "
                    f"{'*' if cs.cosigner_id == self.cosigner_id else ''}"
                )

            print(
                "For main keys a private master key is available in this wallet to sign transactions. "
                "* cosigner key for this wallet"
            )

        if detail and self.main_key:
            print("\n= Wallet Master Key =")
            print(f" ID                             {self.main_key_id}")
            print(f" Private                        {self.main_key.is_private}")
            print(f" Depth                          {self.main_key.depth}")

        balances = await self._balance_update()
        if detail > 1:
            for nw in await self.networks():
                if not is_network(nw):
                    continue
                print(f"\n- NETWORK: {nw.name} -")
                print("- - Keys")
                if detail < 4:
                    ds = [self.key_depth]
                elif detail < 5:
                    ds = [0, self.key_depth] if self.purpose == 45 else [0, self.depth_public_master, self.key_depth]
                else:
                    ds = range(8)
                for d in ds:
                    is_active = True
                    if detail > 3:
                        is_active = False
                    for key in await self.keys(depth=d, network=nw.name, is_active=is_active):
                        balance_str = Value.from_satoshi(
                            key.balance, network=nw,
                        ).format_unit(currency_repr="symbol")
                        print(
                            f"{key.id:5} {key.path:<28} {key.address:<45}"
                            f" {key.name:<25} {balance_str:>25}"
                        )

                if detail > 2:
                    include_new = False
                    if detail > 3:
                        include_new = True
                    accounts = await self.accounts(network=nw.name)
                    if not accounts:
                        accounts = [0]
                    for account_id in accounts:
                        txs = await self.transactions(
                            include_new=include_new,
                            account_id=account_id,
                            network=nw.name,
                            as_dict=True,
                        )
                        print(f"\n- - Transactions Account {account_id} ({len(txs)})")
                        for tx in txs:
                            if not isinstance(tx, dict):
                                continue
                            txd: dict[str, object] = tx
                            spent = " "
                            address = txd["address"]
                            if not txd["address"]:
                                address = "nulldata"
                            elif "spent" in txd and txd["spent"] is False:
                                spent = "U"
                            status = ""
                            if txd["status"] not in ["confirmed", "unconfirmed"]:
                                status = txd["status"]
                            tx_value = txd["value"]
                            val_str = Value.from_satoshi(
                                int(tx_value) if isinstance(tx_value, (int, str)) else 0,
                                network=nw,
                            ).format_unit(currency_repr="symbol")
                            print(
                                f"{txd['txid']:64} {address:43}"
                                f" {txd['confirmations']:8d}"
                                f" {val_str:>21} {spent} {status}"
                            )

        print("\n= Balance Totals (includes unconfirmed) =")
        for na_balance in balances:
            acct_label = f"(Account {na_balance['account_id']})"
            bal_str = Value.from_satoshi(
                int(na_balance["balance"]),
                network=str(na_balance["network"]),
            ).format_unit(currency_repr="symbol")
            print(
                f"{na_balance['network']:<20} {acct_label:<20} {bal_str:>20}"
            )
        print("\n")

    async def as_dict(self, include_private: bool = False) -> dict[str, object]:
        """Return wallet information in dictionary format."""
        if include_private:
            _logger.warning("Exporting wallet with private keys — handle output securely")

        keys = []
        transactions = []
        for netw in await self.networks():
            if not is_network(netw):
                continue
            for key in await self.keys(network=netw.name, include_private=include_private, as_dict=True):
                keys.append(key)

            if self.multisig:
                for t in await self.transactions(include_new=True, account_id=0, network=netw.name, as_dict=True):
                    if isinstance(t, dict):
                        transactions.append(t)
            else:
                accounts = await self.accounts(network=netw.name)
                if not accounts:
                    accounts = [0]
                for account_id in accounts:
                    for t in await self.transactions(
                        include_new=True,
                        account_id=account_id,
                        network=netw.name,
                        as_dict=True,
                    ):
                        if isinstance(t, dict):
                            transactions.append(t)

        return {
            "wallet_id": self.wallet_id,
            "name": self.name,
            "owner": self._owner,
            "scheme": self.scheme,
            "witness_type": self.witness_type,
            "main_network": self.network.name,
            "main_balance": await self.balance(),
            "main_balance_str": await self.balance(as_string=True),
            "balances": self._balances,
            "default_account_id": self.default_account_id,
            "multisig_n_required": self.multisig_n_required,
            "cosigner_wallet_ids": [w.wallet_id for w in self.cosigner],
            "cosigner_public_masters": [w.wif(is_private=False) for w in self.cosigner],
            "sort_keys": self.sort_keys,
            "main_key_id": self.main_key_id,
            "encoding": self.encoding,
            "keys": keys,
            "transactions": transactions,
        }

    def as_json(self, include_private: bool = False) -> str:
        """Get current key as json formatted string."""
        adict = self.as_dict(include_private=include_private)
        return json.dumps(adict, indent=4, default=str)
