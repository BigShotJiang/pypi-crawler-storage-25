"""Migrate a legacy SQLite wallet database to the new encrypted flat-file format.

Reads directly from SQLite (no SQLAlchemy dependency) and writes to the wallet_store/wallet_file format.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime

from fluxwallet.wallet_store import (
    StoredKey,
    StoredTransaction,
    StoredTxInput,
    StoredTxOutput,
    StoredWallet,
    WalletStore,
)

_logger = logging.getLogger(__name__)


def migrate_sqlite_to_store(db_path: str) -> WalletStore:
    """Read a legacy SQLite wallet DB and return a populated WalletStore."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    store = WalletStore()

    # Config
    config_rows = conn.execute("SELECT variable, value FROM config").fetchall()
    config = {r["variable"]: r["value"] for r in config_rows}

    if config.get("encrypted", "NO") == "YES":
        conn.close()
        raise RuntimeError("Source database is encrypted. Decrypt it first or use an unencrypted backup.")

    store.config.version = config.get("version", "")
    store.config.installation_date = config.get("installation_date", "")

    # Wallets
    wallet_rows = conn.execute("SELECT * FROM wallets").fetchall()
    for w in wallet_rows:
        wallet = StoredWallet(
            id=w["id"],
            name=w["name"],
            owner=w["owner"] or "",
            network_name=w["network_name"] or "",
            purpose=w["purpose"] or 44,
            scheme=w["scheme"] or "bip32",
            witness_type=w["witness_type"] or "legacy",
            encoding=w["encoding"] or "base58",
            main_key_id=w["main_key_id"],
            multisig_n_required=w["multisig_n_required"] or 1,
            sort_keys=bool(w["sort_keys"]),
            parent_id=w["parent_id"],
            cosigner_id=w["cosigner_id"],
            key_path=w["key_path"] or "",
            default_account_id=w["default_account_id"],
            discovered=bool(w["discovered"]),
            ssp_peer_pubkey=w["ssp_peer_pubkey"] or "",
            multisig=bool(w["multisig"]),
        )
        store.wallets[wallet.id] = wallet

    # Keys
    key_rows = conn.execute("SELECT * FROM keys").fetchall()
    for k in key_rows:
        key = StoredKey(
            id=k["id"],
            wallet_id=k["wallet_id"] or 0,
            parent_id=k["parent_id"],
            name=k["name"] or "",
            account_id=k["account_id"] or 0,
            depth=k["depth"] or 0,
            change=k["change"] or 0,
            address_index=k["address_index"] or 0,
            public=bytes(k["public"]) if k["public"] else None,
            private=bytes(k["private"]) if k["private"] else None,
            wif=k["wif"],
            compressed=bool(k["compressed"]) if k["compressed"] is not None else True,
            key_type=k["key_type"] or "bip32",
            address=k["address"] or "",
            cosigner_id=k["cosigner_id"],
            encoding=k["encoding"] or "base58",
            purpose=k["purpose"] or 44,
            is_private=bool(k["is_private"]) if k["is_private"] is not None else False,
            path=k["path"] or "",
            network_name=k["network_name"] or "",
            balance=k["balance"] or 0,
            used=bool(k["used"]) if k["used"] is not None else False,
            latest_txid=bytes(k["latest_txid"]) if k["latest_txid"] else None,
            latest_tx_index=k["latest_tx_index"],
            redeem_script=bytes(k["redeem_script"]) if k["redeem_script"] else None,
        )
        store.keys[key.id] = key

    # Multisig children relationships
    ms_rows = conn.execute(
        "SELECT parent_id, child_id, key_order FROM key_multisig_children ORDER BY key_order"
    ).fetchall()
    for ms in ms_rows:
        parent = store.keys.get(ms["parent_id"])
        if parent:
            parent.multisig_children.append((ms["child_id"], ms["key_order"]))

    # Transactions with inputs and outputs
    tx_rows = conn.execute("SELECT * FROM transactions").fetchall()
    for t in tx_rows:
        date_val = t["date"]
        if isinstance(date_val, str):
            try:
                date_val = datetime.fromisoformat(date_val)
            except ValueError:
                date_val = datetime.now()
        elif date_val is None:
            date_val = datetime.now()

        tx = StoredTransaction(
            id=t["id"],
            wallet_id=t["wallet_id"] or 0,
            txid=bytes(t["txid"]) if t["txid"] else b"",
            account_id=t["account_id"] or 0,
            witness_type=t["witness_type"] or "legacy",
            version=t["version"] or 1,
            locktime=t["locktime"] or 0,
            date=date_val,
            coinbase=bool(t["coinbase"]) if t["coinbase"] is not None else False,
            expiry_height=t["expiry_height"] or 0,
            confirmations=t["confirmations"] or 0,
            block_height=t["block_height"],
            size=t["size"] or 0,
            fee=t["fee"] or 0,
            status=t["status"] or "new",
            is_complete=bool(t["is_complete"]) if t["is_complete"] is not None else True,
            input_total=t["input_total"] or 0,
            output_total=t["output_total"] or 0,
            network_name=t["network_name"] or "",
            raw=bytes(t["raw"]) if t["raw"] else None,
            verified=bool(t["verified"]) if t["verified"] is not None else False,
        )

        # Inputs for this transaction
        input_rows = conn.execute(
            "SELECT * FROM transaction_inputs WHERE transaction_id = ? ORDER BY index_n",
            (t["id"],),
        ).fetchall()
        for inp in input_rows:
            tx.inputs.append(
                StoredTxInput(
                    index_n=inp["index_n"],
                    key_id=inp["key_id"],
                    address=inp["address"] or "",
                    witnesses=bytes(inp["witnesses"]) if inp["witnesses"] else None,
                    witness_type=inp["witness_type"] or "legacy",
                    prev_txid=bytes(inp["prev_txid"]) if inp["prev_txid"] else None,
                    output_n=inp["output_n"] or 0,
                    script=bytes(inp["script"]) if inp["script"] else None,
                    script_type=inp["script_type"] or "sig_pubkey",
                    sequence=inp["sequence"] or 0,
                    value=inp["value"] or 0,
                    double_spend=bool(inp["double_spend"]) if inp["double_spend"] is not None else False,
                )
            )

        # Outputs for this transaction
        output_rows = conn.execute(
            "SELECT * FROM transaction_outputs WHERE transaction_id = ? ORDER BY output_n",
            (t["id"],),
        ).fetchall()
        for out in output_rows:
            tx.outputs.append(
                StoredTxOutput(
                    output_n=out["output_n"],
                    key_id=out["key_id"],
                    address=out["address"] or "",
                    script=bytes(out["script"]) if out["script"] else None,
                    script_type=out["script_type"] or "p2pkh",
                    value=out["value"] or 0,
                    spent=bool(out["spent"]) if out["spent"] is not None else False,
                    spending_txid=bytes(out["spending_txid"]) if out["spending_txid"] else None,
                    spending_index_n=out["spending_index_n"],
                )
            )

        store.transactions[tx.id] = tx

    conn.close()

    # Set ID counters past existing max IDs
    store._next_wallet_id = max((w.id for w in store.wallets.values()), default=0) + 1
    store._next_key_id = max((k.id for k in store.keys.values()), default=0) + 1
    store._next_tx_id = max((t.id for t in store.transactions.values()), default=0) + 1

    store._rebuild_indexes()

    _logger.info(
        "Migrated: %d wallets, %d keys, %d transactions",
        len(store.wallets),
        len(store.keys),
        len(store.transactions),
    )

    return store
