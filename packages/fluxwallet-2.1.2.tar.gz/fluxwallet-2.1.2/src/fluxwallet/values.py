#
#    fluxwallet - Python Cryptocurrency Library
#    VALUE class - representing cryptocurrency values
#    © 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal
from typing import Literal, Self

from fluxwallet.config import DEFAULT_NETWORK, NETWORK_DENOMINATORS
from fluxwallet.networks import NETWORK_DEFINITIONS, Network
from fluxwallet.type_guards import is_network


def _den_to_sats_multiplier(denominator: float | int, network_denominator: float | int) -> int:
    """Given a denominator (e.g. 0.001 for milli) and a network denominator (e.g. 1e-8), return the integer number of
    satoshis per one unit of that denominator."""
    d = Decimal(str(denominator)) / Decimal(str(network_denominator))
    return int(d)


def value_to_satoshi(value: str | int | float | Value, network: str | Network | None = None) -> int:
    """Convert Value object or value string to the smallest denominator amount as integer.

    :param value: Value object, value string as accepted by Value class or numeric value amount
    :type value: str, int, float, Value
    :param network: Specify network to validate value string
    :type network: str, Network
    :return int:
    """
    if isinstance(value, str):
        value = Value(value)
    if isinstance(value, Value):
        if network and value.network != network:
            raise ValueError(f"Value uses different network ({value.network.name}) then supplied network: {network}")
        return value.value_sat
    return int(value)


class Value:
    """Class to represent and convert cryptocurrency values."""

    @classmethod
    def from_satoshi(
        cls,
        value: int,
        denominator: int | float | str | None = None,
        network: str | Network | None = None,
    ) -> Self:
        """Initialize Value class with the smallest denominator as input. Such as represented in script and transactions
        cryptocurrency values.

        :param value: Amount of Satoshi's / smallest denominator for this network
        :type value: int
        :param denominator: Denominator as integer, float or string. Such as 0.001 or m for milli, 1000 or k for kilo,
            etc. See NETWORK_DENOMINATORS for list of available denominator symbols.
        :type denominator: int, float, str
        :param network: Specify network if not supplied already in the value string
        :type network: str, Network
        :return Value:
        """
        if network is None:
            network = Network(DEFAULT_NETWORK)
        elif not is_network(network):
            network = Network(network)
        if denominator is None:
            denominator = network.denominator
        else:
            if isinstance(denominator, str):
                dens = [den for den, symb in NETWORK_DENOMINATORS.items() if symb == denominator]
                if dens:
                    denominator = dens[0]
        obj = cls.__new__(cls)
        obj.network = network
        obj._sats = int(value)
        obj.denominator = denominator
        return obj

    def __init__(
        self,
        value: int | float | str,
        denominator: int | float | str | None = None,
        network: str | Network = DEFAULT_NETWORK,
    ) -> None:
        """Create a new Value class. Specify value as integer, float or string. If a string is provided the amount,
        denominator and currency will be extracted if provided.

        Examples: Initialize value class
        >>> Value(10)
        Value(value=10.00000000000000, denominator=1.00000000, network='flux')

        >>> Value('15 mBTC')
        Value(value=0.01500000000000, denominator=0.00100000, network='bitcoin')

        >>> Value('10 sat')
        Value(value=0.00000010000000, denominator=0.00000001, network='bitcoin')

        >>> Value('1 doge')
        Value(value=1.00000000000000, denominator=1.00000000, network='dogecoin')

        >>> Value(500, 'm')
        Value(value=0.50000000000000, denominator=0.00100000, network='flux')

        >>> Value(500, 0.001)
        Value(value=0.50000000000000, denominator=0.00100000, network='flux')

        All frequently used arithmetic, comparision and logical operators can be used on the Value object.
        So you can compare Value object, add them together, divide or multiply them, etc.

        Values need to use the same network / currency if you work with multiple Value objects.
        I.e. Value('1 BTC') + Value('1 LTC') raises an error.

        # Examples: Value operators
        >>> Value('50000 sat') == Value('5000 fin')  # 1 Satoshi equals 10 Finney, see https://en.bitcoin.it/wiki/Units
        True

        >>> Value('1 btc') > Value('2 btc')
        False

        >>> Value('1000 LTC') / 5
        Value(value=200.00000000000000, denominator=1.00000000, network='litecoin')

        >>> Value('0.002 BTC') + 0.02
        Value(value=0.02200000000000, denominator=1.00000000, network='bitcoin')

        The Value class can be represented in several formats.

        # Examples: Format Value class
        >>> int(Value("10.1 BTC"))
        10

        >>> round(Value("10.123 BTC"), 2).format_str()
        '10.12000000 BTC'

        >>> hex(Value("10.1 BTC"))
        '0x3c336080'

        :param value: Value as integer, float or string. Numeric values must be supplied in the
            denominator unit. String values must be in the format:
            <value> [<denominator>][<currency_symbol>]
        :type value: int, float, str
        :param denominator: Denominator as integer, float or string. Such as 0.001 or m for milli,
            1000 or k for kilo, etc. See NETWORK_DENOMINATORS for list of available denominator symbols.
        :type denominator: int, float, str
        :param network: Specify network if not supplied already in the value string
        :type network: str, Network
        """
        if is_network(network):
            self.network: Network = network
        else:
            self.network = Network(network)
        den_arg: int | float | None
        if isinstance(denominator, str):
            dens = [den for den, symb in NETWORK_DENOMINATORS.items() if symb == denominator]
            den_arg = dens[0] if dens else None
        elif denominator is None:
            den_arg = None
        else:
            den_arg = denominator

        if isinstance(value, str):
            value_items = value.split()
            valuestr: str = value_items[0]
            cur_code: str = self.network.currency_code
            den_input: int | float = 1
            if len(value_items) > 1:
                cur_code = value_items[1]
            network_names: list[str] = [
                n
                for n in NETWORK_DEFINITIONS
                if str(NETWORK_DEFINITIONS[n]["currency_code"]).upper() == cur_code.upper()
            ]
            if network_names:
                self.network = Network(network_names[0])
                self.currency: str = cur_code
            else:
                for den, symb in NETWORK_DENOMINATORS.items():
                    if len(symb) and cur_code[: len(symb)] == symb:
                        cur_code = cur_code[len(symb) :]
                        network_names = [
                            n
                            for n in NETWORK_DEFINITIONS
                            if str(NETWORK_DEFINITIONS[n]["currency_code"]).upper() == cur_code.upper()
                        ]
                        if network_names:
                            self.network = Network(network_names[0])
                            self.currency = cur_code
                        elif len(cur_code):
                            raise ValueError("Currency symbol not recognised")
                        den_input = den
                        break
            sats_per_den: int = _den_to_sats_multiplier(den_input, self.network.denominator)
            self._sats: int = int(Decimal(valuestr) * sats_per_den)
            self.denominator: int | float = den_input if den_arg is None else den_arg
        else:
            self.denominator = den_arg or 1.0
            sats_per_den = _den_to_sats_multiplier(self.denominator, self.network.denominator)
            self._sats = int(Decimal(str(value)) * sats_per_den)

    @classmethod
    def _from_sats(cls, sats: int, denominator: int | float, network: Network) -> Self:
        """Internal constructor that builds a Value directly from a satoshi count."""
        obj = cls.__new__(cls)
        obj.network = network
        obj._sats = int(sats)
        obj.denominator = denominator
        return obj

    @property
    def value(self) -> Decimal:
        """Value in base currency units (e.g. BTC) as a Decimal.

        Provided for backward compatibility.
        """
        return Decimal(self._sats) * Decimal(str(self.network.denominator))

    def _str__(self) -> str:
        return self.format_str()

    def __repr__(self) -> str:
        v = Decimal(self._sats) * Decimal(str(self.network.denominator))
        return f"Value(value={v:.14f}, denominator={self.denominator:.8f}, network='{self.network.name}')"

    def __int__(self) -> int:
        v = Decimal(self._sats) * Decimal(str(self.network.denominator))
        return int(v)

    def __float__(self) -> float:
        v = Decimal(self._sats) * Decimal(str(self.network.denominator))
        net_den = Decimal(str(self.network.denominator))
        if v > net_den:
            precision = -int(net_den.log10())
            return Decimal(str(round(v, precision))).__float__()
        return v.__float__()

    def __lt__(self, other: Value) -> bool:
        if self.network != other.network:
            raise ValueError("Cannot compare values from different networks")
        return self._sats < other._sats

    def __le__(self, other: Value) -> bool:
        if self.network != other.network:
            raise ValueError("Cannot compare values from different networks")
        return self._sats <= other._sats

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Value):
            if self.network != other.network:
                raise ValueError("Cannot compare values from different networks")
            return self._sats == other._sats
        if isinstance(other, (int, float, str)):
            other_val = Value(other)
            return self._sats == other_val._sats and self.network == other_val.network
        return NotImplemented

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __ge__(self, other: Value) -> bool:
        if self.network != other.network:
            raise ValueError("Cannot compare values from different networks")
        return self._sats >= other._sats

    def __gt__(self, other: Value) -> bool:
        if self.network != other.network:
            raise ValueError("Cannot compare values from different networks")
        return self._sats > other._sats

    def __add__(self, other: Value | int | float) -> Value:
        if isinstance(other, Value):
            if self.network != other.network:
                raise ValueError("Cannot calculate with values from different networks")
            return Value._from_sats(self._sats + other._sats, self.denominator, self.network)
        sats_per_den = _den_to_sats_multiplier(self.denominator, self.network.denominator)
        other_sats = int(Decimal(str(other)) * sats_per_den)
        return Value._from_sats(self._sats + other_sats, self.denominator, self.network)

    def __iadd__(self, other: Value | int | float) -> Value:
        if isinstance(other, Value):
            if self.network != other.network:
                raise ValueError("Cannot calculate with values from different networks")
            return Value._from_sats(self._sats + other._sats, self.denominator, self.network)
        sats_per_den = _den_to_sats_multiplier(self.denominator, self.network.denominator)
        other_sats = int(Decimal(str(other)) * sats_per_den)
        return Value._from_sats(self._sats + other_sats, self.denominator, self.network)

    def __isub__(self, other: Value | int | float) -> Value:
        if isinstance(other, Value):
            if self.network != other.network:
                raise ValueError("Cannot calculate with values from different networks")
            return Value._from_sats(self._sats - other._sats, self.denominator, self.network)
        sats_per_den = _den_to_sats_multiplier(self.denominator, self.network.denominator)
        other_sats = int(Decimal(str(other)) * sats_per_den)
        return Value._from_sats(self._sats - other_sats, self.denominator, self.network)

    def __sub__(self, other: Value | int | float) -> Value:
        if isinstance(other, Value):
            if self.network != other.network:
                raise ValueError("Cannot calculate with values from different networks")
            return Value._from_sats(self._sats - other._sats, self.denominator, self.network)
        sats_per_den = _den_to_sats_multiplier(self.denominator, self.network.denominator)
        other_sats = int(Decimal(str(other)) * sats_per_den)
        return Value._from_sats(self._sats - other_sats, self.denominator, self.network)

    def __mul__(self, other: int | float) -> Value:
        new_sats = int(Decimal(str(self._sats)) * Decimal(str(other)))
        return Value._from_sats(new_sats, self.denominator, self.network)

    def __truediv__(self, other: int | float) -> Value:
        new_sats = int(Decimal(str(self._sats)) / Decimal(str(other)))
        return Value._from_sats(new_sats, self.denominator, self.network)

    def __floordiv__(self, other: int | float) -> Value:
        new_sats = self._sats // int(other)
        return Value._from_sats(new_sats, self.denominator, self.network)

    def __round__(self, n: int = 0) -> Value:
        den = Decimal(str(self.denominator))
        net_den = Decimal(str(self.network.denominator))
        sats_per_den = int(den / net_den)
        if sats_per_den <= 0:
            sats_per_den = 1
        value_in_den = Decimal(self._sats) / Decimal(sats_per_den)
        rounded = round(value_in_den, n)
        new_sats = int(rounded * sats_per_den)
        return Value._from_sats(new_sats, self.denominator, self.network)

    def __index__(self) -> int:
        return self._sats

    def format_str(
        self,
        denominator: int | float | str | None = None,
        decimals: int | None = None,
        currency_repr: str | None = "code",
    ) -> str:
        """Get string representation of Value with requested denominator and number of decimals.

        >>> Value(1200000, 'sat').format_str('m')  # milli Bitcoin
        '12.00000 mBTC'

        >>> Value(12000.3, 'sat').format_str(1)  # Use denominator = 1 for Bitcoin
        '0.00012000 BTC'

        >>> Value(12000, 'sat').format_str('auto')
        '120.00 µBTC'

        >>> Value(0.005).format_str('m')
        '5.00000 mBTC'

        >>> Value(12000, 'sat').format_str('auto', decimals=0)
        '120 µBTC'

        >>> Value('13000000 Doge').format_str('auto')  # Yeah, mega Dogecoins...
        '13.00000000 MDOGE'

        >>> Value('2100000000').format_str('auto')
        '2.10000000 GBTC'

        >>> Value('1.5 BTC').format_str(currency_repr='symbol')
        '1.50000000 ₿'

        >>> Value('1.5 BTC').format_str(currency_repr='name')
        '1.50000000 bitcoins'

        :param denominator: Denominator as integer or string. Such as 0.001 or m for milli, 1000 or k
            for kilo, etc. See NETWORK_DENOMINATORS for list of available denominator symbols. If not
            provided the default self.denominator value is used. Use value 'auto' to automatically
            determine the best denominator for human readability.
        :type denominator: int, float, str
        :param decimals: Number of decimals to use
        :type decimals: float
        :param currency_repr: Representation of currency. I.e. code: BTC, name: bitcoins, symbol: ₿
        :type currency_repr: str

        :return str:
        """
        value_base: Decimal = Decimal(self._sats) * Decimal(str(self.network.denominator))

        if denominator is None:
            denominator = self.denominator
        elif denominator == "auto":
            if Decimal("0.001") <= value_base < Decimal("1000"):
                denominator = 1
            elif 1 <= self._sats < 1000:
                denominator = self.network.denominator
            else:
                for den, symb in NETWORK_DENOMINATORS.items():
                    if symb in ["n", "fin", "da", "c", "d", "h"]:
                        continue
                    den_d = Decimal(str(den))
                    if 1 <= value_base / den_d < 1000:
                        denominator = den
                        break
        elif isinstance(denominator, str):
            dens: list[float] = [
                den for den, symb in NETWORK_DENOMINATORS.items() if symb == denominator[: len(symb)] and len(symb)
            ]
            if len(dens) > 1:
                dens = [den for den, symb in NETWORK_DENOMINATORS.items() if symb == denominator]
            if dens:
                denominator = dens[0]
        if not isinstance(denominator, (int, float)):
            raise ValueError("Denominator not found in NETWORK_DENOMINATORS definition")
        if denominator in NETWORK_DENOMINATORS:
            den_symb: str = NETWORK_DENOMINATORS[denominator]
        else:
            raise ValueError("Denominator not found in NETWORK_DENOMINATORS definition")

        net_den: Decimal = Decimal(str(self.network.denominator))
        den_d = Decimal(str(denominator))

        if decimals is None:
            decimals = -int((net_den / den_d).log10())
            if decimals > 8:
                decimals = 8
        if decimals < 0:
            decimals = 0

        balance: Decimal = value_base / den_d
        balance = balance.quantize(Decimal(10) ** -decimals, rounding=ROUND_HALF_UP)

        cur_code: str = self.network.currency_code
        if currency_repr is None:
            cur_code = ""
        if currency_repr == "symbol":
            cur_code = self.network.currency_symbol
        if currency_repr == "name":
            cur_code = self.network.currency_name_plural
        if "sat" in den_symb and self.network.name == "bitcoin":
            cur_code = ""
        return f"{balance:.{decimals}f} {den_symb}{cur_code}"

    def format_unit(self, decimals: int | None = None, currency_repr: str | None = "code") -> str:
        """String representation of this Value. Wrapper for the :func:`str` method, but always uses 1 as denominator,
        meaning main denominator such as BTC, LTC.

        >>> Value('12000 sat').format_unit()
        '0.00012000 BTC'

        :param decimals: Number of decimals to use
        :type decimals: float
        :param currency_repr: Representation of currency. I.e. code: BTC, name: Bitcoin, symbol: ₿
        :type currency_repr: str
        :return str:
        """
        return self.format_str(1, decimals, currency_repr)

    def format_auto(self, decimals: int | None = None, currency_repr: str | None = "code") -> str:
        """String representation of this Value. Wrapper for the :func:`str` method, but automatically determines the
        denominator depending on the value.

        >>> Value('0.0000012 BTC').format_auto()
        '120 sat'

        >>> Value('0.0005 BTC').format_auto()
        '500.00 µBTC'

        :param decimals: Number of decimals to use
        :type decimals: float
        :param currency_repr: Representation of currency. I.e. code: BTC, name: Bitcoin, symbol: ₿
        :type currency_repr: str
        :return str:
        """

        return self.format_str("auto", decimals, currency_repr)

    @property
    def value_sat(self) -> int:
        """Value in the smallest denominator, i.e. Satoshi for the Bitcoin network.

        :return int:
        """
        return self._sats

    def to_bytes(self, length: int = 8, byteorder: Literal["little", "big"] = "little") -> bytes:
        """Representation of value_sat (value in the smallest denominator: satoshi's) as bytes string. Used for script
        or transaction serialization.

        >>> Value('1 sat').to_bytes()
        b'\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00'

        :param length: Length of bytes string to return, default is 8 bytes
        :type length: int
        :param byteorder: Order of bytes: little or big endian. Default is 'little'
        :type byteorder: str

        :return bytes:
        """
        return self._sats.to_bytes(length, byteorder)

    def to_hex(self, length: int = 16, byteorder: Literal["little", "big"] = "little") -> str:
        """Representation of value_sat (value in the smallest denominator: satoshi's) as hexadecimal string.

        >>> Value('15 sat').to_hex()
        '0f00000000000000'

        :param length: Length of hexadecimal string to return, default is 16 characters
        :type length: int
        :param byteorder: Order of bytes: little or big endian. Default is 'little'
        :type byteorder: str
        :return:
        """
        return self._sats.to_bytes(length // 2, byteorder).hex()
