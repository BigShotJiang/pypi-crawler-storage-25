from __future__ import annotations

import struct
from dataclasses import dataclass
from hashlib import blake2b
from io import BytesIO
from typing import BinaryIO, Protocol

from fluxwallet.encoding import read_varbyteint


class _ShieldedSpend(Protocol):
    cv: bytes
    anchor: bytes
    nullifier: bytes
    rk: bytes
    proof: bytes

    def __bytes__(self) -> bytes: ...


MAX_MONEY: int = 440_000_000 * 100_000_000
TX_EXPIRY_HEIGHT_THRESHOLD: int = 500000000

MAX_TX_SIZE_AFTER_SAPLING: int = 2_000_000
MAX_TX_SIZE_BEFORE_SAPLING: int = 100_000
MAX_BLOCK_SIGOPS: int = 20_000
MAX_STANDARD_TX_SIGOPS: int = 4_000
COINBASE_MATURITY: int = 100
SPROUT_MIN_TX_VERSION: int = 1
OVERWINTER_MIN_TX_VERSION: int = 3
OVERWINTER_MAX_TX_VERSION: int = 3
SAPLING_MIN_TX_VERSION: int = 4
SAPLING_MAX_TX_VERSION: int = 4
TX_EXPIRING_SOON_THRESHOLD: int = 3
DEFAULT_TX_EXPIRY_DELTA: int = 20
MAX_SCRIPT_SIZE: int = 10_000
MAX_SCRIPT_ELEMENT_SIZE: int = 520
MAX_OP_RETURN_DATA: int = 80
NULL_PREVOUT: bytes = b"\x00" * 32

OVERWINTER_VERSION_GROUP_ID = 0x03C48270
OVERWINTER_TX_VERSION = 3

SAPLING_VERSION_GROUP_ID = 0x892F2085
SAPLING_TX_VERSION = 4

OP_DUP = 0x76
OP_HASH160 = 0xA9
OP_EQUAL = 0x87
OP_EQUALVERIFY = 0x88
OP_CHECKSIG = 0xAC
OP_RETURN = 0x6A

MAX_COMPACT_SIZE = 0x2000000

SIGHASH_ALL = 1
SIGHASH_NONE = 2
SIGHASH_SINGLE = 3
SIGHASH_ANYONECANPAY = 0x80


def write_compact_size(n: int, allow_u64: bool = False) -> bytes:
    if not allow_u64 and n > MAX_COMPACT_SIZE:
        raise ValueError("Compact size exceeds maximum")
    if n < 253:
        return struct.pack("B", n)
    if n <= 0xFFFF:
        return struct.pack("B", 253) + struct.pack("<H", n)
    if n <= 0xFFFFFFFF:
        return struct.pack("B", 254) + struct.pack("<I", n)
    return struct.pack("B", 255) + struct.pack("<Q", n)


@dataclass
class Script:
    _script: bytes = b""

    def __bool__(self) -> bool:
        return bool(self._script)

    def __bytes__(self) -> bytes:
        return write_compact_size(len(self._script)) + self._script

    @staticmethod
    def encode(operations: list[int | bytes]) -> bytes:
        encoded = b""
        for op in operations:
            if isinstance(op, int):
                encoded += op.to_bytes(1, "big")
            else:
                encoded += write_compact_size(len(op)) + op
        return encoded

    @classmethod
    def from_bytes(cls, b: bytes) -> Script:
        try:
            bio: BinaryIO = BytesIO(b)
        except TypeError:
            script = cls()
            if isinstance(b, bytes):
                script._script = b
            return script

        op = bio.read(1)
        op = int.from_bytes(op, "little")
        match op:
            case x if x == OP_RETURN:
                size = read_varbyteint(bio)
                data = bio.read(size)
                msg = MessageScript(data)
            case x if x == OP_HASH160:
                # p2sh
                size = read_varbyteint(bio)
                script_hash = bio.read(size)
                op_equal = int.from_bytes(bio.read(1), "little")
                if op_equal != OP_EQUAL:
                    raise ValueError("Expected OP_EQUAL in P2SH script")
                msg = P2SHScript(script_hash)
            case x if x == OP_DUP:
                # p2pkh
                hash160 = int.from_bytes(bio.read(1), "little")
                if hash160 != OP_HASH160:
                    raise ValueError("Expected OP_HASH160 in P2PKH script")
                size = read_varbyteint(bio)
                pubkey_hash = bio.read(size)
                op_equalverify = int.from_bytes(bio.read(1), "little")
                if op_equalverify != OP_EQUALVERIFY:
                    raise ValueError("Expected OP_EQUALVERIFY in P2PKH script")
                op_checksig = int.from_bytes(bio.read(1), "little")
                if op_checksig != OP_CHECKSIG:
                    raise ValueError("Expected OP_CHECKSIG in P2PKH script")
                msg = P2PKHScript(pubkey_hash)
            case _:
                # raise ValueError("Unknown script")
                script = cls()
                script._script = bio.getvalue()
                msg = script

        return msg

    def raw(self) -> bytes:
        return self._script


class P2PKHScript(Script):
    def __init__(self, pubkey_hash: bytes) -> None:
        self._script = self.encode([OP_DUP, OP_HASH160, pubkey_hash, OP_EQUALVERIFY, OP_CHECKSIG])


class P2SHScript(Script):
    def __init__(self, script_hash: bytes) -> None:
        self._script = self.encode([OP_HASH160, script_hash, OP_EQUAL])


class MessageScript(Script):
    def __init__(self, message: str | bytes) -> None:
        data = message if isinstance(message, bytes) else message.encode("utf-8")
        self._script = self.encode([OP_RETURN, data])


@dataclass
class OutPoint:
    txid: bytes
    n: int

    def __bytes__(self) -> bytes:
        return self.txid + struct.pack("<I", self.n)


@dataclass
class TxIn:
    prevout: OutPoint
    scriptSig: Script
    nSequence: int

    def __bytes__(self) -> bytes:
        return bytes(self.prevout) + bytes(self.scriptSig) + struct.pack("<I", self.nSequence)


@dataclass
class TxOut:
    nValue: int
    script: Script

    def __bytes__(self) -> bytes:
        return struct.pack("<Q", self.nValue) + bytes(self.script)


class SaplingTx:
    def __init__(
        self,
        version: int,
        vin: list[TxIn] | None = None,
        vout: list[TxOut] | None = None,
        nLockTime: int = 0,
        nExpiryHeight: int = 0,
        valuebalance: int = 0,
        shielded_spends: list[_ShieldedSpend] | None = None,
        shielded_outputs: list[bytes] | None = None,
    ) -> None:
        if version == OVERWINTER_TX_VERSION:
            self.fOverwintered: bool = True
            self.nVersionGroupId: int = OVERWINTER_VERSION_GROUP_ID
            self.nVersion: int = OVERWINTER_TX_VERSION
        elif version == SAPLING_TX_VERSION:
            self.fOverwintered = True
            self.nVersionGroupId = SAPLING_VERSION_GROUP_ID
            self.nVersion = SAPLING_TX_VERSION
        else:
            raise Exception(f"Version: {version} not supported for SaplingTx")

        if version == OVERWINTER_TX_VERSION and self.nVersionGroupId != OVERWINTER_VERSION_GROUP_ID:
            raise ValueError("Version group ID mismatch for Overwinter")
        if version == SAPLING_TX_VERSION and self.nVersionGroupId != SAPLING_VERSION_GROUP_ID:
            raise ValueError("Version group ID mismatch for Sapling")

        self.vin = list(vin) if vin else []
        self.vout = list(vout) if vout else []

        self.nLockTime = nLockTime
        if not (0 <= nExpiryHeight < TX_EXPIRY_HEIGHT_THRESHOLD):
            raise ValueError(f"nExpiryHeight {nExpiryHeight} out of range [0, {TX_EXPIRY_HEIGHT_THRESHOLD})")
        self.nExpiryHeight = nExpiryHeight
        self.valueBalance = 0
        if self.nVersion >= SAPLING_TX_VERSION:
            if not (-MAX_MONEY <= valuebalance <= MAX_MONEY):
                raise ValueError(f"valueBalance {valuebalance} out of range [-{MAX_MONEY}, {MAX_MONEY}]")
            self.valueBalance = valuebalance

        self.vShieldedSpends: list[_ShieldedSpend] = list(shielded_spends) if shielded_spends else []
        self.vShieldedOutputs = list(shielded_outputs) if shielded_outputs else []

        self.vJoinSplit: list[bytes] = []
        self.joinSplitPubKey: bytes = b""
        self.joinSplitSig: bytes = b""
        self.bindingSig: bytes = b""

        # NOTE: vin/vout emptiness and valueBalance consistency are checked in
        # FluxTransaction.validate(), not here, because inputs/outputs are
        # added after construction via add_input()/add_output().

    def __bytes__(self) -> bytes:
        ret = b""
        ret += struct.pack("<I", self.version_bytes())
        if self.fOverwintered:
            ret += struct.pack("<I", self.nVersionGroupId)

        isOverwinterV3 = (
            self.fOverwintered
            and self.nVersionGroupId == OVERWINTER_VERSION_GROUP_ID
            and self.nVersion == OVERWINTER_TX_VERSION
        )

        isSaplingV4 = (
            self.fOverwintered
            and self.nVersionGroupId == SAPLING_VERSION_GROUP_ID
            and self.nVersion == SAPLING_TX_VERSION
        )

        ret += write_compact_size(len(self.vin))
        for x in self.vin:
            ret += bytes(x)

        ret += write_compact_size(len(self.vout))
        for x in self.vout:
            ret += bytes(x)

        ret += struct.pack("<I", self.nLockTime)
        if isOverwinterV3 or isSaplingV4:
            ret += struct.pack("<I", self.nExpiryHeight)

        if isSaplingV4:
            ret += struct.pack("<Q", self.valueBalance)
            ret += write_compact_size(len(self.vShieldedSpends))
            for desc in self.vShieldedSpends:
                ret += bytes(desc)
            ret += write_compact_size(len(self.vShieldedOutputs))
            for desc in self.vShieldedOutputs:
                ret += bytes(desc)

        if self.nVersion >= 2:
            ret += write_compact_size(len(self.vJoinSplit))
            for jsdesc in self.vJoinSplit:
                ret += bytes(jsdesc)
            if len(self.vJoinSplit) > 0:
                ret += self.joinSplitPubKey
                ret += self.joinSplitSig

        if isSaplingV4 and not (len(self.vShieldedSpends) == 0 and len(self.vShieldedOutputs) == 0):
            ret += self.bindingSig

        return ret

    def __repr__(self) -> str:
        resp: str = ""
        for k, v in self.__dict__.items():
            resp += f"{k}: {v}\n"
        return resp

    def version_bytes(self) -> int:
        return self.nVersion | (1 << 31 if self.fOverwintered else 0)

    def getHashPrevouts(self, person: bytes = b"ZcashPrevoutHash") -> bytes:
        digest = blake2b(digest_size=32, person=person)

        for x in self.vin:
            digest.update(bytes(x.prevout))
        return digest.digest()

    def getHashSequence(self, person: bytes = b"ZcashSequencHash") -> bytes:
        digest = blake2b(digest_size=32, person=person)
        for x in self.vin:
            digest.update(struct.pack("<I", x.nSequence))
        return digest.digest()

    def getHashOutputs(self, person: bytes = b"ZcashOutputsHash") -> bytes:
        digest = blake2b(digest_size=32, person=person)
        for x in self.vout:
            digest.update(bytes(x))
        return digest.digest()

    def getHashJoinSplits(self) -> bytes:
        digest = blake2b(digest_size=32, person=b"ZcashJSplitsHash")
        for jsdesc in self.vJoinSplit:
            digest.update(bytes(jsdesc))
        digest.update(self.joinSplitPubKey)
        return digest.digest()

    def getHashShieldedSpends(self) -> bytes:
        digest = blake2b(digest_size=32, person=b"ZcashSSpendsHash")
        for desc in self.vShieldedSpends:
            digest.update(bytes(desc.cv))
            digest.update(bytes(desc.anchor))
            digest.update(desc.nullifier)
            digest.update(bytes(desc.rk))
            digest.update(bytes(desc.proof))
        return digest.digest()

    def getHashShieldedOutputs(self) -> bytes:
        digest = blake2b(digest_size=32, person=b"ZcashSOutputHash")
        for desc in self.vShieldedOutputs:
            digest.update(bytes(desc))
        return digest.digest()

    def signature_hash(
        self,
        script_code: bytes,
        value: int,
        input_n: int,
        nIn: int,
        hash_type: int = SIGHASH_ALL,
    ) -> bytes:
        consensusBranchId: int = getattr(self, "consensus_branch_id", 0x76B809BB)
        if input_n is None:
            return b""

        # this is zip243
        hashPrevouts = b"\x00" * 32
        hashSequence = b"\x00" * 32
        hashOutputs = b"\x00" * 32
        hashJoinSplits = b"\x00" * 32
        hashShieldedSpends = b"\x00" * 32
        hashShieldedOutputs = b"\x00" * 32

        if not (hash_type & SIGHASH_ANYONECANPAY):
            hashPrevouts = self.getHashPrevouts()

        if (
            (not (hash_type & SIGHASH_ANYONECANPAY))
            and (hash_type & 0x1F) != SIGHASH_SINGLE
            and (hash_type & 0x1F) != SIGHASH_NONE
        ):
            hashSequence = self.getHashSequence()

        if (hash_type & 0x1F) != SIGHASH_SINGLE and (hash_type & 0x1F) != SIGHASH_NONE:
            hashOutputs = self.getHashOutputs()
        elif (hash_type & 0x1F) == SIGHASH_SINGLE and nIn >= 0 and nIn < len(self.vout):
            digest = blake2b(digest_size=32, person=b"ZcashOutputsHash")
            digest.update(bytes(self.vout[nIn]))
            hashOutputs = digest.digest()

        if len(self.vJoinSplit) > 0:
            hashJoinSplits = self.getHashJoinSplits()

        if len(self.vShieldedSpends) > 0:
            hashShieldedSpends = self.getHashShieldedSpends()

        if len(self.vShieldedOutputs) > 0:
            hashShieldedOutputs = self.getHashShieldedOutputs()

        # print("hashPrevouts", binascii.hexlify(hashPrevouts))
        # print("hashSequence", binascii.hexlify(hashSequence))
        # print("hashOutputs", binascii.hexlify(hashOutputs))
        # print("hashJoinSplits", binascii.hexlify(hashJoinSplits))
        # print("hashShieldedSpends", binascii.hexlify(hashShieldedSpends))
        # print("hashShieldedOutputs", binascii.hexlify(hashShieldedOutputs))
        # print("concensusbranch", consensusBranchId)

        digest = blake2b(
            digest_size=32,
            person=b"ZcashSigHash" + struct.pack("<I", consensusBranchId),
        )

        digest.update(struct.pack("<I", self.version_bytes()))
        digest.update(struct.pack("<I", self.nVersionGroupId))
        digest.update(hashPrevouts)
        digest.update(hashSequence)
        digest.update(hashOutputs)
        digest.update(hashJoinSplits)
        digest.update(hashShieldedSpends)
        digest.update(hashShieldedOutputs)
        digest.update(struct.pack("<I", self.nLockTime))
        digest.update(struct.pack("<I", self.nExpiryHeight))
        digest.update(struct.pack("<Q", self.valueBalance))
        digest.update(struct.pack("<I", hash_type))

        digest.update(bytes(self.vin[input_n].prevout))
        digest.update(write_compact_size(len(script_code)) + script_code)
        digest.update(struct.pack("<Q", value))

        digest.update(struct.pack("<I", self.vin[input_n].nSequence))

        return digest.digest()
