#
#    fluxwallet - Python Cryptocurrency Library
#    MNEMONIC class for BIP0039 Mnemonic Key management
#    © 2016 - 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

import hashlib
import secrets
from pathlib import Path

from fluxwallet.config import BIP39_PBKDF2_ITERATIONS, DEFAULT_LANGUAGE, FW_INSTALL_DIR, TYPE_TEXT
from fluxwallet.config.secp256k1 import secp256k1_n
from fluxwallet.encoding import change_base, normalize_string, to_bytes
from fluxwallet.secure_mem import secure_wipe


class Mnemonic:
    """Class to convert, generate and parse Mnemonic sentences.

    Implementation of BIP0039 for Mnemonics passphrases

    Took some parts from Pavol Rusnak Trezors implementation, see
    https://github.com/trezor/python-mnemonic
    """

    def __init__(self, language: str = DEFAULT_LANGUAGE) -> None:
        """Init Mnemonic class and read wordlist of specified language.

        :param language: use specific wordlist, i.e. chinese, dutch (in development), english, french, italian, japanese
            or spanish. Leave empty for default 'english'
        :type language: str
        """
        self._wordlist: list[str] = []
        self.change_language(language)

    @staticmethod
    def checksum(data: bytes | str) -> str:
        """Calculates checksum for given data key.

        :param data: key string
        :type data: bytes, hexstring
        :return str: Checksum of key in bits
        """
        data = to_bytes(data)
        if len(data) % 4 > 0:
            raise ValueError(
                f"Data length in bits should be divisible by 32, but it is not "
                f"({len(data)} bytes = {len(data) * 8} bits)."
            )
        key_hash = hashlib.sha256(data).digest()
        result = change_base(key_hash, 256, 2, 256)
        if not isinstance(result, str):
            result = str(result)
        return result[: len(data) * 8 // 32]

    VALID_LANGUAGES: frozenset[str] = frozenset(
        {
            "english",
            "chinese_simplified",
            "chinese_traditional",
            "dutch",
            "french",
            "italian",
            "japanese",
            "korean",
            "spanish",
        }
    )

    def change_language(self, language: str) -> None:
        if language not in self.VALID_LANGUAGES or "/" in language or "\\" in language:
            raise ValueError(f"Invalid language: {language}")
        wordlist_path = Path(FW_INSTALL_DIR) / f"wordlist/{language}.txt"
        self._ingest_wordlist(wordlist_path)

    def _ingest_wordlist(self, wordlist_path: Path) -> None:
        with open(wordlist_path) as stream:
            self._wordlist = [w.strip() for w in stream.readlines()]

    def to_seed(self, words: str, password: str = "", validate: bool = True) -> bytearray:
        """Use Mnemonic words and optionally a password to create a PBKDF2 seed.

        Returns a wipeable bytearray. Callers must call ``secure_wipe(seed)``
        when finished with the seed material.

        >>> Mnemonic().to_seed('chunk gun celery million wood kite tackle twenty story episode raccoon dutch').hex()
        '6969ed4666db67fc74fae7869e2acf3c766b5ef95f5e31eb2fcebd93d76069c6de971225f700042b0b513f0ad6c8562277fc4b5ee1344b720f1686dc2dccc220'

        :param words: Mnemonic passphrase as string with space separated words
        :type words: str
        :param password: A password to protect key, leave empty to disable
        :type password: str
        :param validate: Validate checksum for given word phrase, default is True
        :type validate: bool

        :return bytearray: PBKDF2 seed (caller must wipe with secure_wipe)
        """
        words = self.sanitize_mnemonic(words)
        if validate:
            self.to_entropy(words)

        mnemonic_buf = bytearray(to_bytes(words))
        password_buf = bytearray(to_bytes(password))
        salt = bytearray(b"mnemonic") + password_buf
        try:
            return bytearray(
                hashlib.pbkdf2_hmac(
                    hash_name="sha512",
                    password=mnemonic_buf,
                    salt=salt,
                    iterations=BIP39_PBKDF2_ITERATIONS,
                )
            )
        finally:
            secure_wipe(mnemonic_buf)
            secure_wipe(password_buf)
            secure_wipe(salt)

    def word(self, index: int) -> str:
        """Get word from wordlist.

        :param index: word index ID
        :type index: int
        :return str: A word from the dictionary
        """
        return self._wordlist[index]

    def wordlist(self) -> list[str]:
        """Get full selected wordlist. A wordlist is selected when initializing Mnemonic class.

        :return list: Full list with 2048 words
        """
        return self._wordlist

    def generate(self, strength: int = 256, add_checksum: bool = True) -> str:
        """Generate a random Mnemonic key.

        Uses cryptographically secure os.urandom() function to generate data. Then creates a Mnemonic sentence with the
        'to_mnemonic' method.

        :param strength: Key strength in number of bits as multiply of 32, default is 128 bits. It advised to specify
            128 bits or more, i.e.: 128, 256, 512 or 1024
        :type strength: int
        :param add_checksum: Included a checksum? Default is True
        :type add_checksum: bool
        :return str: Mnemonic passphrase consisting of a space seperated list of words
        """
        if strength % 32 > 0:
            raise ValueError("Strength should be divisible by 32")
        data = secrets.token_bytes(strength // 8)
        return self.to_mnemonic(data, add_checksum=add_checksum)

    def to_mnemonic(self, data: bytes | str, add_checksum: bool = True, check_on_curve: bool = True) -> str:
        """Convert key data entropy to Mnemonic sentence.

        >>> Mnemonic().to_mnemonic('28acfc94465fd2f6774759d6897ec122')
        'chunk gun celery million wood kite tackle twenty story episode raccoon dutch'

        :param data: Key data entropy
        :type data: bytes, hexstring
        :param add_checksum: Included a checksum? Default is True
        :type add_checksum: bool
        :param check_on_curve: Check if data integer value is on secp256k1 curve. Should be enabled
            when not testing and working with crypto
        :type check_on_curve: bool

        :return str: Mnemonic passphrase consisting of a space seperated list of words
        """
        data = to_bytes(data)
        data_int = int.from_bytes(data, "big")
        if check_on_curve and not 0 < data_int < secp256k1_n:
            raise ValueError("Integer value of data should be in secp256k1 domain between 1 and secp256k1_n-1")
        wi: list[int]
        if add_checksum:
            binresult_raw = change_base(data_int, 10, 2, len(data) * 8)
            binresult = str(binresult_raw) + self.checksum(data)
            wi_raw = change_base(binresult, 2, 2048)
            if isinstance(wi_raw, list):
                wi: list[int] = [int(x) for x in wi_raw]
            elif isinstance(wi_raw, int):
                wi = [wi_raw]
            else:
                wi = [int(x) for x in str(wi_raw)]
        else:
            wi_raw = change_base(data_int, 10, 2048, len(data) // 1.375 + len(data) % 1.375 > 0)
            if isinstance(wi_raw, list):
                wi = [int(x) for x in wi_raw]
            elif isinstance(wi_raw, int):
                wi = [wi_raw]
            else:
                wi = [int(x) for x in str(wi_raw)]
        return normalize_string(" ".join([self._wordlist[i] for i in wi]))

    def to_entropy(self, words: str | list[str], includes_checksum: bool = True) -> bytes:
        """Convert Mnemonic words back to key data entropy.

        >>> Mnemonic().to_entropy('chunk gun celery million wood kite tackle twenty story episode raccoon dutch').hex()
        '28acfc94465fd2f6774759d6897ec122'


        :param words: Mnemonic words as string of list of words
        :type words: str
        :param includes_checksum: Boolean to specify if checksum is used. Default is True
        :type includes_checksum: bool

        :return bytes: Entropy seed
        """
        words = self.sanitize_mnemonic(words)
        if isinstance(words, TYPE_TEXT):
            words = words.split(" ")
        wi: list[int] = []
        for word in words:
            wi.append(self._wordlist.index(word))
        ent_length = int(len(words) * 4 / 3)
        ent_raw = change_base(wi, 2048, 256, ent_length, output_even=False)
        if isinstance(ent_raw, int):
            ent_bytes: bytes = ent_raw.to_bytes(ent_length, "big")
        elif isinstance(ent_raw, str):
            ent_bytes = ent_raw.encode("ISO-8859-1")
        elif isinstance(ent_raw, list):
            ent_bytes = bytes(ent_raw)
        else:
            ent_bytes = ent_raw

        if includes_checksum:
            binresult_raw = change_base(ent_bytes, 256, 2, len(ent_bytes) * 4)
            binresult = str(binresult_raw)
            ent_raw2 = change_base(binresult[: -len(binresult) // 33], 2, 256, ent_length)
            if isinstance(ent_raw2, int):
                ent_bytes = ent_raw2.to_bytes(ent_length, "big")
            elif isinstance(ent_raw2, str):
                ent_bytes = ent_raw2.encode("ISO-8859-1")
            elif isinstance(ent_raw2, list):
                ent_bytes = bytes(ent_raw2)
            else:
                ent_bytes = ent_raw2

            # Check checksum
            checksum = binresult[-len(binresult) // 33 :]
            if checksum != self.checksum(ent_bytes):
                raise ValueError("Invalid mnemonic checksum")

        return ent_bytes

    @classmethod
    def detect_language(cls, words: str | list[str]) -> str:
        """Detect language of given phrase.

        >>> Mnemonic().detect_language('chunk gun celery million wood kite tackle twenty story episode raccoon dutch')
        'english'

        :param words: List of space separated words
        :type words: str

        :return str: Language
        """
        if isinstance(words, list):
            words = " ".join(words)
        words_str: str = normalize_string(words)
        words_list: list[str] = words_str.split(" ")

        wlcount: dict[str, int] = {}
        for language in Mnemonic.VALID_LANGUAGES:
            wl_path = Path(FW_INSTALL_DIR, "wordlist", f"{language}.txt")
            if not wl_path.is_file():
                continue
            with wl_path.open(encoding="utf-8") as f:
                wordlist: list[str] = [w.strip() for w in f.readlines()]
                wlcount[language] = 0
                for word in words_list:
                    if word in wordlist:
                        wlcount[language] += 1
        detlang = max(wlcount.keys(), key=(lambda key: wlcount[key]))
        if not wlcount[detlang]:
            raise ValueError(f"Could not detect language of Mnemonic sentence {words_list}")
        return detlang

    def sanitize_mnemonic(self, words: str | list[str]) -> str:
        """Check and convert list of words to utf-8 encoding.

        Raises an error if unrecognised word is found

        :param words: List of space separated words
        :type words: str
        :return str: Sanitized list of words
        """
        if isinstance(words, list):
            words = " ".join(words)
        words_str: str = normalize_string(words)
        language = self.detect_language(words_str)
        words_list: list[str] = words_str.split(" ")
        with Path(FW_INSTALL_DIR, "wordlist", f"{language}.txt").open() as f:
            wordlist: list[str] = [w.strip() for w in f.readlines()]
            for word in words_list:
                if word not in wordlist:
                    raise ValueError("Unrecognised word {} in mnemonic sentence".format(word.encode("utf8")))
        return " ".join(words_list)
