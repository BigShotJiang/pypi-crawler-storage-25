#
#    fluxwallet - Python Cryptocurrency Library
#    ENCODING - Methods for encoding and conversion
#    © 2016 - 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

import hashlib
import hmac
import logging
import math
import numbers
import secrets as _secrets
import unicodedata
from copy import deepcopy
from typing import TYPE_CHECKING, Literal, overload

from cryptography.hazmat.primitives.ciphers import Cipher as AESCipher
from cryptography.hazmat.primitives.ciphers import algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt as ScryptKDF

from fluxwallet.exceptions import FluxWalletError
from fluxwallet.type_guards import is_bytes, is_str

if TYPE_CHECKING:
    from io import BytesIO

_logger: logging.Logger = logging.getLogger(__name__)


class EncodingError(FluxWalletError):
    """Log and raise encoding errors."""


bytesascii: bytes = b""
for bxn in range(256):
    bytesascii += bytes((bxn,))

code_strings: dict[int | str, bytes] = {
    2: b"01",
    3: b" ,.",
    10: b"0123456789",
    16: b"0123456789abcdef",
    32: b"abcdefghijklmnopqrstuvwxyz234567",
    58: b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz",
    256: b"".join([bytes((csx,)) for csx in range(256)]),
    "bech32": b"qpzry9x8gf2tvdw0s3jn54khce6mua7l",
}


def _get_code_string(base: int | str) -> bytes | list[int]:
    if base in code_strings:
        return code_strings[base]
    if isinstance(base, str):
        raise EncodingError(f"Unknown base '{base}'")
    return list(range(0, base))


def _array_to_codestring(array: list[int], base: int | str) -> str:
    codebase: bytes = code_strings[base]
    codestring: str = ""
    for i in array:
        codestring += chr(codebase[i])
    return codestring


def _codestring_to_array(codestring: str, base: int | str) -> list[int]:
    codestring_bytes: bytes = bytes(codestring, "utf8")
    codebase: bytes = code_strings[base]
    array: list[int] = []
    for s in codestring_bytes:
        try:
            array.append(codebase.index(s))
        except ValueError:
            raise EncodingError(f"Character '{s}' not found in codebase") from None
    return array


def _bech32_polymod(values: list[int]) -> int:
    """Internal function that computes the Bech32 checksum."""
    generator: list[int] = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk: int = 1
    for value in values:
        top: int = chk >> 25
        chk = (chk & 0x1FFFFFF) << 5 ^ value
        for i in range(5):
            chk ^= generator[i] if ((top >> i) & 1) else 0
    return chk


def convertbits(data: list[int] | bytes, frombits: int, tobits: int, pad: bool = True) -> list[int] | None:
    """General power-of-2 base conversion.

    Source: https://github.com/sipa/bech32/tree/master/ref/python
    """
    acc: int = 0
    bits: int = 0
    ret: list[int] = []
    maxv: int = (1 << tobits) - 1
    max_acc: int = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return ret


def pubkeyhash_to_addr_bech32(
    pubkeyhash: str | bytes, prefix: str = "bc", witver: int = 0, separator: str = "1"
) -> str:
    """Encode a public key hash as a bech32 (segwit) address.

    Used for SSP relay identity (P2WSH on Bitcoin network).

    :param pubkeyhash: Public key hash (20 or 32 bytes)
    :type pubkeyhash: str, bytes
    :param prefix: Human-readable part ('bc' for mainnet, 'tb' for testnet)
    :type prefix: str
    :param witver: Witness version (0-16)
    :type witver: int
    :param separator: Separator between hrp and data
    :type separator: str
    :return str: Bech32 encoded address
    """
    pkh_list: list[int] = list(to_bytes(pubkeyhash))

    if len(pkh_list) not in [20, 32, 40]:
        if pkh_list[0] != 0:
            witver = pkh_list[0] - 0x50
        if pkh_list[1] != len(pkh_list[2:]):
            raise EncodingError("Incorrect pubkeyhash length")
        pkh_list = pkh_list[2:]

    if witver > 16:
        raise EncodingError("Witness version must be between 0 and 16")

    checksum_xor: int = 1
    converted = convertbits(pkh_list, 8, 5)
    if converted is None:
        raise EncodingError("Error converting pubkeyhash to 5-bit groups")
    data: list[int] = [witver] + converted

    hrp_expanded: list[int] = [ord(x) >> 5 for x in prefix] + [0] + [ord(x) & 31 for x in prefix]
    polymod: int = _bech32_polymod(hrp_expanded + data + [0, 0, 0, 0, 0, 0]) ^ checksum_xor
    checksum: list[int] = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]

    return prefix + separator + _array_to_codestring(data, "bech32") + _array_to_codestring(checksum, "bech32")


def bech32_encode(hrp: str, data: bytes) -> str:
    """Encode raw bytes as a Bech32 string with the given human-readable prefix.

    Used for Sapling addresses (hrp="za"), viewing keys, etc. Unlike segwit bech32, this does not prepend a witness
    version byte.
    """
    converted = convertbits(list(data), 8, 5)
    if converted is None:
        raise EncodingError("Error converting data to 5-bit groups")

    hrp_expanded: list[int] = [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]
    polymod: int = _bech32_polymod(hrp_expanded + converted + [0, 0, 0, 0, 0, 0]) ^ 1
    checksum: list[int] = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]

    return hrp + "1" + _array_to_codestring(converted, "bech32") + _array_to_codestring(checksum, "bech32")


def bech32_decode(addr: str, prefix: str = "za") -> bytes:
    """Decode a Bech32 string back to raw bytes.

    Validates the checksum and HRP prefix. Returns the payload bytes.
    """
    if not addr.startswith(prefix + "1"):
        raise EncodingError(f"Expected prefix '{prefix}1', got '{addr[: len(prefix) + 1]}'")

    data_str = addr[len(prefix) + 1 :]
    data = _codestring_to_array(data_str, "bech32")

    hrp_expanded: list[int] = [ord(x) >> 5 for x in prefix] + [0] + [ord(x) & 31 for x in prefix]
    if _bech32_polymod(hrp_expanded + data) != 1:
        raise EncodingError("Invalid Bech32 checksum")

    # Strip the 6-byte checksum, convert 5-bit back to 8-bit
    payload_5bit = data[:-6]
    converted = convertbits(payload_5bit, 5, 8, pad=False)
    if converted is None:
        raise EncodingError("Error converting from 5-bit groups")

    return bytes(converted)


def normalize_var(
    var: str | bytes | int | list[int] | list[bytes], base: int = 256
) -> bytes | int | list[int] | list[bytes]:
    """For Python 2 convert variable to string.

    For Python 3 convert to bytes

    Convert decimals to integer type

    :param var: input variable in any format
    :type var: str, byte
    :param base: specify variable format, i.e. 10 for decimal, 16 for hex
    :type base: int
    :return: Normalized var in string for Python 2, bytes for Python 3, decimal for base10
    """
    if isinstance(var, str):
        try:
            var_bytes: bytes = var.encode("ISO-8859-1")
        except ValueError:
            try:
                var_bytes = var.encode("utf-8")
            except ValueError:
                raise EncodingError(f"Unknown character '{var}' in input format") from None
        if base == 10:
            return int(var_bytes)
        return var_bytes

    if base == 10:
        if isinstance(var, (bytes, int)):
            return int(var)
        raise EncodingError("Cannot convert list to int for base 10")
    if isinstance(var, list):
        return deepcopy(var)
    return var


@overload
def change_base(
    chars: str | bytes | int | list[int] | list[bytes],
    base_from: int,
    base_to: Literal[16],
    min_length: int = ...,
    output_even: bool | None = ...,
    output_as_list: bool | None = ...,
) -> str: ...
@overload
def change_base(
    chars: str | bytes | int | list[int] | list[bytes],
    base_from: int,
    base_to: Literal[256],
    min_length: int = ...,
    output_even: bool | None = ...,
    output_as_list: bool | None = ...,
) -> bytes: ...
@overload
def change_base(
    chars: str | bytes | int | list[int] | list[bytes],
    base_from: int,
    base_to: Literal[10],
    min_length: int = ...,
    output_even: bool | None = ...,
    output_as_list: bool | None = ...,
) -> int: ...
@overload
def change_base(
    chars: str | bytes | int | list[int] | list[bytes],
    base_from: int,
    base_to: int,
    min_length: int = ...,
    output_even: bool | None = ...,
    output_as_list: bool | None = ...,
) -> str | bytes | int | list[int] | list[bytes]: ...
def change_base(
    chars: str | bytes | int | list[int] | list[bytes],
    base_from: int,
    base_to: int,
    min_length: int = 0,
    output_even: bool | None = None,
    output_as_list: bool | None = None,
) -> str | bytes | int | list[int] | list[bytes]:
    """Convert input chars from one numeric base to another. For instance from hexadecimal (base-16) to decimal
    (base-10)

    From and to numeric base can be any base. If base is not found in definitions an array of index numbers
    will be returned

    Examples:

    >>> change_base('FF', 16, 10)
    255
    >>> change_base('101', 2, 10)
    5

    Convert base-58 public WIF of a key to hexadecimal format

    >>> change_base(
    ...     'xpub661MyMwAqRbcFnkbk13gaJba22ibnEdJS7KAMY99C4jBBHMxWaCBSTrTinNTc9G5LTFtUqbLpWnzY5yPT'
    ...     'NEF9u8sB1kBSygy4UsvuViAmiR',
    ...     58, 16)
    '0488b21e0000000000000000007d3cc6702f48bf618f3f14cce5ee2cacf3f70933345ee4710af6fa4a330cc7d5'\
    '03c045227451b3454ca8b6022b0f0155271d013b58d57d322fd05b519753a46e876388698a'

    Convert base-58 address to public key hash: '00' + length '21' + 20 byte key

    >>> change_base('142Zp9WZn9Fh4MV8F3H5Dv4Rbg7Ja1sPWZ', 58, 16)
    '0021342f229392d7c9ed82c932916cee6517fbc9a2487cd97a'

    Convert to 2048-base, for example a Mnemonic word list. Will return a list of integers

    >>> change_base(100, 16, 2048)
    [100]

    :param chars: Input string
    :type chars: any
    :param base_from: Base number or name from input. For example 2 for binary, 10 for decimal and 16 for hexadecimal
    :type base_from: int, str
    :param base_to: Base number or name for output. For example 2 for binary, 10 for decimal and 16 for hexadecimal
    :type base_to: int
    :param min_length: Minimal output length. Required for decimal, advised for all output to avoid leading
        zeros conversion problems.
    :type min_length: int
    :param output_even: Specify if output must contain an even number of characters. Sometimes handy for
        hex conversions.
    :type output_even: bool
    :param output_as_list: Always output as list instead of string.
    :type output_as_list: bool

    :return str, list: Base converted input as string or list.
    """
    if base_from == 10 and not min_length:
        raise EncodingError("For a decimal input a minimum output length is required")

    code_str: bytes | list[int] = _get_code_string(base_to)

    if base_to not in code_strings:
        output_as_list = True

    code_str_from: bytes | list[int] = _get_code_string(base_from)
    if not isinstance(code_str_from, (bytes, list)):
        raise EncodingError("Code strings must be a list or defined as bytes")
    output: list[int] = []
    input_dec: int = 0
    addzeros: int = 0
    inp: bytes | int | list[int] | list[bytes] = normalize_var(chars, base_from)

    # Use bytes and int's methods for standard conversions to speedup things
    if not min_length:
        if base_from == 256 and base_to == 16 and isinstance(inp, bytes):
            return inp.hex()
        if base_from == 16 and base_to == 256 and isinstance(chars, str):
            return bytes.fromhex(chars)
    if base_from == 16 and base_to == 10 and isinstance(inp, bytes):
        return int(inp, 16)
    if base_from == 10 and base_to == 16 and isinstance(inp, int):
        hex_outp: str = hex(inp)[2:]
        return hex_outp.zfill(min_length) if min_length else hex_outp
    if base_from == 256 and base_to == 10 and isinstance(inp, bytes):
        return int.from_bytes(inp, "big")
    if base_from == 10 and base_to == 256 and isinstance(inp, int):
        return inp.to_bytes(min_length, byteorder="big")
    if base_from == 256 and base_to == 58 and isinstance(inp, bytes):
        return base58encode(inp)
    if base_from == 16 and base_to == 58 and isinstance(chars, str):
        return base58encode(bytes.fromhex(chars))

    if output_even is None and base_to == 16:
        output_even = True

    if isinstance(inp, int):
        input_dec = inp
    elif isinstance(inp, (list, bytes)):
        factor: int = 1
        while len(inp):
            item: int | bytes
            if isinstance(inp, list):
                item = inp.pop()
            else:
                item = inp[-1:]
                inp = inp[:-1]
            try:
                if isinstance(code_str_from, bytes):
                    pos: int = code_str_from.index(item)
                elif isinstance(item, int):
                    pos = code_str_from.index(item)
                else:
                    pos = 0
            except ValueError:
                try:
                    if isinstance(code_str_from, bytes) and isinstance(item, bytes):
                        pos = code_str_from.index(item.lower())
                    elif isinstance(item, int):
                        pos = code_str_from.index(item)
                    else:
                        pos = 0
                except ValueError:
                    raise EncodingError(f"Unknown character {item} found in input string") from None
            input_dec += pos * factor

            # Add leading zero if there are leading zero's in input
            firstchar: bytes = chr(code_str_from[0]).encode("utf-8")
            if not pos * factor:
                if isinstance(inp, list):
                    if not len([x for x in inp if x != firstchar]):
                        addzeros += 1
                elif not len(inp.strip(firstchar)):
                    addzeros += 1
            factor *= base_from
    else:
        raise EncodingError(f"Unknown input format {inp}")

    # Convert decimal to output base
    while input_dec != 0:
        input_dec, remainder = divmod(input_dec, base_to)
        output = [code_str[remainder]] + output

    if base_to != 10:
        pos_fact: float = math.log(base_to, base_from)
        expected_length: float = len(str(chars)) / pos_fact

        zeros: int = int(addzeros / pos_fact)
        if addzeros == 1:
            zeros = 1
        # Different rules for base58 addresses
        if (base_from == 256 and base_to == 58) or (base_from == 58 and base_to == 256):
            zeros = addzeros
        elif base_from == 16 and base_to == 58:
            zeros = -(-addzeros // 2)
        elif base_from == 58 and base_to == 16:
            zeros = addzeros * 2

        for _ in range(zeros):
            if base_to != 10 and expected_length != len(output):
                output = [code_str[0]] + output

        # Add zero's to make even number of digits on Hex output (or if specified)
        if output_even and len(output) % 2:
            output = [code_str[0]] + output

        # Add leading zero's
        while len(output) < min_length:
            output = [code_str[0]] + output

    if not output_as_list and isinstance(output, list):
        output_str: str = "" if not len(output) else "".join([chr(c) for c in output])
        if base_to == 10:
            return int(output_str) if output_str else 0
        if base_to == 256:
            return output_str.encode("ISO-8859-1")
        return output_str
    if base_to == 10:
        return 0
    return output


def base58encode(inp: bytes) -> str:
    """Convert bytes to base58 encode string.

    :param inp: Input string
    :type inp: bytes
    :return str:
    """
    origlen: int = len(inp)
    inp = inp.lstrip(b"\0")
    padding_zeros: int = origlen - len(inp)
    code_str: str = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    acc: int = int.from_bytes(inp, "big")

    string: str = ""
    while acc:
        acc, idx = divmod(acc, 58)
        string = code_str[idx : idx + 1] + string
    return "1" * padding_zeros + string


def varbyteint_to_int(byteint: bytes | list[int]) -> tuple[int, int]:
    """Convert CompactSize Variable length integer in byte format to integer.

    See https://en.bitcoin.it/wiki/Protocol_documentation#Variable_length_integer for specification

    >>> varbyteint_to_int(bytes.fromhex('fd1027'))
    (10000, 3)

    :param byteint: 1-9 byte representation
    :type byteint: bytes, list

    :return (int, int): tuple wit converted integer and size
    """
    if not isinstance(byteint, (bytes, list)):
        raise EncodingError("Byteint must be a list or defined as bytes")
    if byteint == b"":
        return 0, 0
    ni: int = byteint[0]
    if ni < 253:
        return ni, 1
    if ni == 253:  # integer of 2 bytes
        size: int = 2
    elif ni == 254:  # integer of 4 bytes
        size = 4
    else:  # integer of 8 bytes
        size = 8
    return int.from_bytes(byteint[1 : 1 + size][::-1], "big"), size + 1


def read_varbyteint(s: BytesIO) -> int:
    """Read variable length integer from BytesIO stream. Wrapper for the varbyteint_to_int method.

    :param s: A binary stream
    :type s: BytesIO
    :return int:
    """
    pos: int = s.tell()
    value: int
    size: int
    value, size = varbyteint_to_int(s.read(9))
    s.seek(pos + size)
    return value


def read_varbyteint_return(s: BytesIO) -> tuple[int, bytes]:
    """Read variable length integer from BytesIO stream. Return original converted bytes (to reconstruct transaction or
    script).

    :param s: A binary stream
    :type s: BytesIO  :return (int, bytes):
    """
    pos: int = s.tell()
    byteint: bytes = s.read(9)
    if not byteint:
        return 0, b""

    ni: int = byteint[0]
    if ni < 253:
        s.seek(pos + 1)
        return ni, byteint[0:1]
    if ni == 253:  # integer of 2 bytes
        size: int = 2
    elif ni == 254:  # integer of 4 bytes
        size = 4
    else:  # integer of 8 bytes
        size = 8
    varbytes: bytes = byteint[1 : 1 + size]
    s.seek(pos + size + 1)
    return int.from_bytes(varbytes[::-1], "big"), byteint[0:1] + varbytes


def int_to_varbyteint(inp: int) -> bytes:
    """Convert integer to CompactSize Variable length integer in byte format.

    See https://en.bitcoin.it/wiki/Protocol_documentation#Variable_length_integer for specification

    >>> int_to_varbyteint(10000).hex()
    'fd1027'

    :param inp: Integer to convert
    :type inp: int

    :return: byteint: 1-9 byte representation as integer
    """
    if not isinstance(inp, numbers.Number):
        raise EncodingError("Input must be a number type")
    if inp < 0xFD:
        return inp.to_bytes(1, "little")
    if inp < 0xFFFF:
        return b"\xfd" + inp.to_bytes(2, "little")
    if inp < 0xFFFFFFFF:
        return b"\xfe" + inp.to_bytes(4, "little")
    return b"\xff" + inp.to_bytes(8, "little")


def _der_decode_signature(sig_bytes: bytes) -> tuple[int, int]:
    """Decode a DER-encoded ECDSA signature into (r, s) integers.

    :param sig_bytes: DER-encoded signature
    :type sig_bytes: bytes
    :return tuple: (r, s) as integers
    """
    if sig_bytes[0] != 0x30:
        raise EncodingError("Invalid DER signature: missing SEQUENCE tag")
    total_len: int = sig_bytes[1]
    data: bytes = sig_bytes[2 : 2 + total_len]

    if data[0] != 0x02:
        raise EncodingError("Invalid DER signature: missing INTEGER tag for r")
    r_len: int = data[1]
    r: int = int.from_bytes(data[2 : 2 + r_len], "big")
    data = data[2 + r_len :]

    if data[0] != 0x02:
        raise EncodingError("Invalid DER signature: missing INTEGER tag for s")
    s_len: int = data[1]
    s: int = int.from_bytes(data[2 : 2 + s_len], "big")

    return r, s


def _der_encode_signature(r: int, s: int) -> bytes:
    """DER-encode an ECDSA signature from (r, s) integers.

    :param r: r value of signature
    :type r: int
    :param s: s value of signature
    :type s: int
    :return bytes: DER-encoded signature
    """

    def _encode_int(value: int) -> bytes:
        b: bytes = value.to_bytes((value.bit_length() + 7) // 8, "big")
        # Pad with 0x00 if high bit is set (DER integers are signed)
        if b[0] & 0x80:
            b = b"\x00" + b
        return b"\x02" + bytes([len(b)]) + b

    rb: bytes = _encode_int(r)
    sb: bytes = _encode_int(s)
    content: bytes = rb + sb
    return b"\x30" + bytes([len(content)]) + content


@overload
def convert_der_sig(signature: bytes, as_hex: Literal[True] = ...) -> str: ...
@overload
def convert_der_sig(signature: bytes, as_hex: Literal[False]) -> bytes: ...
def convert_der_sig(signature: bytes, as_hex: bool = True) -> str | bytes:
    """
    Extract content from DER encoded string: Convert DER encoded signature to signature string.

    :param signature: DER signature
    :type signature: bytes
    :param as_hex: Output as hexstring
    :type as_hex: bool

    :return bytes, str: Signature
    """

    if not signature:
        return ""
    r: int
    s: int
    r, s = _der_decode_signature(bytes(signature))
    sig: str = f"{r:064x}{s:064x}"
    if as_hex:
        return sig
    return bytes.fromhex(sig)


def der_encode_sig(r: int, s: int) -> bytes:
    """Create DER encoded signature string with signature r and s value.

    :param r: r value of signature
    :type r: int
    :param s: s value of signature
    :type s: int
    :return bytes:
    """
    return _der_encode_signature(r, s)


@overload
def addr_to_pubkeyhash(address: str, as_hex: Literal[True], encoding: str | None = ...) -> str: ...
@overload
def addr_to_pubkeyhash(address: str, as_hex: Literal[False] = ..., encoding: str | None = ...) -> bytes: ...
def addr_to_pubkeyhash(address: str, as_hex: bool = False, encoding: str | None = None) -> bytes | str:
    """Convert base58 address to public key hash.

    :param address: Crypto currency address in base-58 format
    :type address: str
    :param as_hex: Output as hexstring
    :type as_hex: bool
    :param encoding: Address encoding used. Only base58 is supported.
    :type encoding: str  :return bytes, str: public key hash
    """

    return addr_base58_to_pubkeyhash(address, as_hex)


@overload
def addr_base58_to_pubkeyhash(address: str | bytes, as_hex: Literal[True]) -> str: ...
@overload
def addr_base58_to_pubkeyhash(address: str | bytes, as_hex: Literal[False] = ...) -> bytes: ...
def addr_base58_to_pubkeyhash(address: str | bytes, as_hex: bool = False) -> bytes | str:
    """Convert Base58 encoded address to public key hash.

    >>> addr_base58_to_pubkeyhash('142Zp9WZn9Fh4MV8F3H5Dv4Rbg7Ja1sPWZ', as_hex=True)
    '21342f229392d7c9ed82c932916cee6517fbc9a2'

    :param address: Crypto currency address in base-58 format
    :type address: str, bytes
    :param as_hex: Output as hexstring
    :type as_hex: bool

    :return bytes, str: Public Key Hash
    """

    # Bitcoin addresses are 25 bytes (1-byte prefix), Flux are 26 (2-byte prefix)
    address_raw = None
    for expected_len in (25, 26):
        try:
            raw = change_base(address, 58, 256, expected_len)
            if not isinstance(raw, bytes):
                raw = (
                    str(raw).encode("ISO-8859-1")
                    if isinstance(raw, str)
                    else bytes(raw)
                    if isinstance(raw, list)
                    else raw.to_bytes((raw.bit_length() + 7) // 8, "big")
                )
            address_raw = raw
            break
        except EncodingError:
            continue
    if address_raw is None or len(address_raw) not in (25, 26):
        raise EncodingError(f"Invalid address {address}: could not decode to 25 or 26 bytes")
    check: bytes = address_raw[-4:]
    payload: bytes = address_raw[:-4]  # prefix + hash160 (for checksum)
    dsh = double_sha256(payload)
    checksum: bytes = dsh[:4] if isinstance(dsh, bytes) else dsh.encode()[:4]

    if not hmac.compare_digest(check, checksum):
        raise EncodingError("Invalid address, checksum incorrect")
    # Strip version prefix (1 byte for Bitcoin, 2 for Flux) to get 20-byte hash160
    prefix_len = len(payload) - 20
    hash160: bytes = payload[prefix_len:]
    if as_hex:
        return hash160.hex()
    return hash160


def pubkeyhash_to_addr(
    pubkeyhash: bytes | str,
    prefix: str | bytes | None = None,
    encoding: str = "base58",
    witver: int | None = None,
) -> str:
    """Convert public key hash to base58 encoded address.

    :param pubkeyhash: Public key hash
    :type pubkeyhash: bytes, str
    :param prefix: Prefix version byte of network, default is bitcoin '\x00'
    :type prefix: str, bytes
    :param encoding: Address encoding. Only base58 is supported.
    :type encoding: str
    :return str: Base-58 encoded address
    """
    if encoding != "base58":
        raise EncodingError(f"Encoding {encoding} not supported")
    if prefix is None:
        prefix = b"\x00"
    return pubkeyhash_to_addr_base58(pubkeyhash, prefix)


def pubkeyhash_to_addr_base58(pubkeyhash: bytes | str, prefix: str | bytes = b"\x00") -> str:
    """Convert public key hash to base58 encoded address.

    >>> pubkeyhash_to_addr_base58('21342f229392d7c9ed82c932916cee6517fbc9a2')
    '142Zp9WZn9Fh4MV8F3H5Dv4Rbg7Ja1sPWZ'

    :param pubkeyhash: Public key hash
    :type pubkeyhash: bytes, str
    :param prefix: Prefix version byte of network, default is bitcoin '\x00'
    :type prefix: str, bytes

    :return str: Base-58 encoded address
    """
    key: bytes = to_bytes(prefix) + to_bytes(pubkeyhash)
    dsh = double_sha256(key)
    addr256: bytes = key + (dsh if isinstance(dsh, bytes) else dsh.encode())[:4]
    return base58encode(addr256)


def varstr(string: bytes | str) -> bytes:
    """
    Convert string to variably sized string: Bytestring preceded with length byte

    >>> varstr(to_bytes('5468697320737472696e67206861732061206c656e677468206f66203330')).hex()
    '1e5468697320737472696e67206861732061206c656e677468206f66203330'

    :param string: String input
    :type string: bytes, str

    :return bytes: varstring
    """
    s_raw = normalize_var(string) if isinstance(string, (str, bytes, int)) else bytes(string)
    if isinstance(s_raw, bytes):
        s = s_raw
    elif isinstance(s_raw, int):
        s = s_raw.to_bytes((s_raw.bit_length() + 7) // 8 or 1, "big")
    else:
        s = bytes(int(b) if isinstance(b, bytes) else b for b in s_raw)
    if s == b"\0":
        return s
    return int_to_varbyteint(len(s)) + s


def to_bytes(string: str | bytes, unhexlify: bool = True) -> bytes:
    """Convert string, hexadecimal string to bytes.

    :param string: String to convert
    :type string: str, bytes
    :param unhexlify: Try to unhexlify hexstring
    :type unhexlify: bool
    :return: Bytes var
    """
    if not string:
        return b""
    if unhexlify:
        try:
            if is_bytes(string):
                string = string.decode()
            s: bytes = bytes.fromhex(string)
            return s
        except (TypeError, ValueError):
            pass
    if is_bytes(string):
        return string
    return bytes(string, "utf8")


def to_hexstring(string: str | bytes) -> str:
    """Convert bytes, string to a hexadecimal string. Use instead of built-in hex() method if format of input string is
    not known.

    >>> to_hexstring(b'\\x12\\xaa\\xdd')
    '12aadd'

    :param string: Variable to convert to hex string
    :type string: bytes, str

    :return: hexstring
    """
    if not string:
        return ""
    if is_str(string):
        try:
            bytes.fromhex(string)
            return string
        except (ValueError, TypeError):
            pass
        return bytes(string, "utf8").hex()
    return string.hex()


def normalize_string(string: str | bytes) -> str:
    """
    Normalize a string to the default NFKD unicode format
    See https://en.wikipedia.org/wiki/Unicode_equivalence#Normalization

    :param string: string value
    :type string: bytes, str

    :return: string
    """
    if is_bytes(string):
        utxt: str = string.decode("utf8")
    else:
        utxt = string

    return unicodedata.normalize("NFKD", utxt)


@overload
def double_sha256(string: bytes, as_hex: Literal[True]) -> str: ...
@overload
def double_sha256(string: bytes, as_hex: Literal[False] = ...) -> bytes: ...
def double_sha256(string: bytes, as_hex: bool = False) -> bytes | str:
    """Get double SHA256 hash of string.

    :param string: String to be hashed
    :type string: bytes
    :param as_hex: Return value as hexadecimal string. Default is False
    :type as_hex: bool  :return bytes, str:
    """
    if not as_hex:
        return hashlib.sha256(hashlib.sha256(string).digest()).digest()
    return hashlib.sha256(hashlib.sha256(string).digest()).hexdigest()


def ripemd160(string: bytes) -> bytes:
    return hashlib.new("ripemd160", string).digest()


def hash160(string: bytes) -> bytes:
    """Creates a RIPEMD-160 + SHA256 hash of the input string.

    :param string: Script
    :type string: bytes
    :return bytes: RIPEMD-160 hash of script
    """
    return ripemd160(hashlib.sha256(string).digest())


def aes_encrypt(data: bytes, key: bytes, aad: bytes = b"") -> bytes:
    """Encrypt data using AES-256-GCM with a random 12-byte nonce.

    Returns nonce (12 bytes) + ciphertext + tag (16 bytes). Each encryption produces unique output due to random nonce.

    :param data: Data to encrypt
    :type data: bytes
    :param key: 32-byte AES-256 key
    :type key: bytes
    :param aad: Optional additional authenticated data
    :type aad: bytes
    :return bytes: nonce (12) + ciphertext + tag (16)
    """
    nonce: bytes = _secrets.token_bytes(12)
    aesgcm: AESGCM = AESGCM(key)
    ct: bytes = aesgcm.encrypt(nonce, data, aad if aad else None)
    return nonce + ct


def aes_decrypt(encrypted_data: bytes, key: bytes, aad: bytes = b"") -> bytes:
    """Decrypt AES-256-GCM data. Input: nonce (12) + ciphertext + tag (16).

    :param encrypted_data: nonce (12) + ciphertext + tag (16)
    :type encrypted_data: bytes
    :param key: 32-byte AES-256 key
    :type key: bytes
    :param aad: Optional additional authenticated data
    :type aad: bytes
    :return bytes: Decrypted plaintext
    """
    nonce: bytes = encrypted_data[:12]
    ct: bytes = encrypted_data[12:]
    aesgcm: AESGCM = AESGCM(key)
    return aesgcm.decrypt(nonce, ct, aad if aad else None)


def bip38_decrypt(encrypted_privkey: str, password: str) -> tuple[bytes, bytes, bool]:
    """
    BIP0038 non-ec-multiply decryption. Returns WIF private key.
    Based on code from https://github.com/nomorecoin/python-bip38-testing
    This method is called by Key class init function when importing BIP0038 key.

    :param encrypted_privkey: Encrypted private key using WIF protected key format
    :type encrypted_privkey: str
    :param password: Required password for decryption
    :type password: str

    :return tupple (bytes, bytes): (Private Key bytes, 4 byte address hash for verification)
    """
    d_raw = change_base(encrypted_privkey, 58, 256)
    if not isinstance(d_raw, bytes):
        raise EncodingError("Invalid encrypted private key format")
    d: bytes = d_raw[2:]
    flagbyte: bytes = d[0:1]
    d = d[1:]
    if flagbyte == b"\xc0":
        compressed: bool = False
    elif flagbyte == b"\xe0":
        compressed = True
    else:
        raise EncodingError("Unrecognised password protected key format. Flagbyte incorrect.")
    password = unicodedata.normalize("NFC", password)
    password_bytes: bytes = password.encode("utf-8")
    addresshash: bytes = d[0:4]
    d = d[4:-4]
    kdf: ScryptKDF = ScryptKDF(salt=addresshash, length=64, n=16384, r=8, p=8)
    key: bytes = kdf.derive(password_bytes)
    derivedhalf1: bytes = key[0:32]
    derivedhalf2: bytes = key[32:64]
    encryptedhalf1: bytes = d[0:16]
    encryptedhalf2: bytes = d[16:32]
    cipher: AESCipher = AESCipher(algorithms.AES(derivedhalf2), modes.ECB())
    decryptor = cipher.decryptor()
    decryptedhalf2: bytes = decryptor.update(encryptedhalf2)
    decryptedhalf1: bytes = decryptor.update(encryptedhalf1)
    priv: bytes = decryptedhalf1 + decryptedhalf2
    priv = (int.from_bytes(priv, "big") ^ int.from_bytes(derivedhalf1, "big")).to_bytes(32, "big")
    # Compression flag is returned separately; the caller (Key import) handles WIF encoding
    return priv, addresshash, compressed


def bip38_encrypt(private_hex: str, address: str, password: str, flagbyte: bytes = b"\xe0") -> str:
    """
    BIP0038 non-ec-multiply encryption. Returns BIP0038 encrypted private key
    Based on code from https://github.com/nomorecoin/python-bip38-testing

    :param private_hex: Private key in hex format
    :type private_hex: str
    :param address: Address string
    :type address: str
    :param password: Required password for encryption
    :type password: str
    :param flagbyte: Flagbyte prefix for WIF
    :type flagbyte: bytes

    :return str: BIP38 password encrypted private key
    """
    address_bytes: bytes = address.encode("utf-8")
    password = unicodedata.normalize("NFC", password)
    password_bytes: bytes = password.encode("utf-8")
    dsh = double_sha256(address_bytes)
    addresshash: bytes = dsh[:4] if isinstance(dsh, bytes) else dsh.encode()[:4]
    kdf: ScryptKDF = ScryptKDF(salt=addresshash, length=64, n=16384, r=8, p=8)
    key: bytes = kdf.derive(password_bytes)
    derivedhalf1: bytes = key[0:32]
    derivedhalf2: bytes = key[32:64]
    cipher: AESCipher = AESCipher(algorithms.AES(derivedhalf2), modes.ECB())
    encryptor = cipher.encryptor()
    encryptedhalf1: bytes = encryptor.update(
        (int(private_hex[0:32], 16) ^ int.from_bytes(derivedhalf1[0:16], "big")).to_bytes(16, "big")
    )
    encryptedhalf2: bytes = encryptor.update(
        (int(private_hex[32:64], 16) ^ int.from_bytes(derivedhalf1[16:32], "big")).to_bytes(16, "big")
    )
    encrypted_privkey: bytes = b"\x01\x42" + flagbyte + addresshash + encryptedhalf1 + encryptedhalf2
    dsh2 = double_sha256(encrypted_privkey)
    encrypted_privkey += (dsh2 if isinstance(dsh2, bytes) else dsh2.encode())[:4]
    return base58encode(encrypted_privkey)


class Quantity:
    """Class to convert very large or very small numbers to a readable format.

    Provided value is converted to number between 0 and 1000, and a metric prefix will be added.

    >>> # Example - the Hashrate on 10th July 2020
    >>> str(Quantity(122972532877979100000, 'H/s'))
    '122.973 EH/s'
    """

    def __init__(self, value: int | float, units: str = "", precision: int = 3) -> None:
        """Convert given value to number between 0 and 1000 and determine metric prefix.

        :param value: Value as integer in base 0
        :type value: int, float
        :param units: Base units, so 'g' for grams for instance
        :type units: str
        :param precision: Number of digits after the comma
        :type precision: int
        """
        # Metric prefixes according to BIPM, the International System of Units (SI) in 10**3 steps
        self.prefix_list: list[str] = list("yzafpnμm1kMGTPEZY")
        self.base: int = self.prefix_list.index("1")
        if value < 0:
            raise ValueError("Value must be non-negative")

        self.absolute: int | float = value
        self.units: str = units
        self.precision: int = precision
        while value != 0 and (value < 1 or value > 1000) and 0 < self.base < len(self.prefix_list) - 1:
            if value > 1000:
                self.base += 1
                value /= 1000.0
            elif value < 1000:
                self.base -= 1
                value *= 1000.0
        self.value: int | float = value

    def __str__(self) -> str:
        # > Python 3.6: return f"{self.value:4.{self.precision}f} {self.prefix_list[self.base]}{self.units}"
        prefix: str = self.prefix_list[self.base]
        if prefix == "1":
            prefix = ""
        return f"{self.value:4.{self.precision}f} {prefix}{self.units}".strip()
