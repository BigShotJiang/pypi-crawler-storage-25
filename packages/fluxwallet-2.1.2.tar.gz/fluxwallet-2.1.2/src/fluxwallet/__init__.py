import contextlib

import fluxwallet.encoding as encoding  # noqa: F401
import fluxwallet.keys as keys  # noqa: F401
import fluxwallet.mnemonic as mnemonic  # noqa: F401
import fluxwallet.ssp as ssp  # noqa: F401
import fluxwallet.transactions as transactions  # noqa: F401
import fluxwallet.values as values  # noqa: F401
import fluxwallet.wallet as wallet  # noqa: F401
from fluxwallet.exceptions import (
    ClientError,
    FluxWalletError,
    RelayError,
    ServiceError,
)
from fluxwallet.secure_mem import disable_core_dumps, sodium_init

disable_core_dumps()
sodium_init()

__all__ = [
    "ClientError",
    "FluxWalletError",
    "RelayError",
    "ServiceError",
    "encoding",
    "keys",
    "mnemonic",
    "ssp",
    "transactions",
    "values",
    "wallet",
]

with contextlib.suppress(ImportError):
    import fluxwallet.sapling as sapling  # noqa: F401
