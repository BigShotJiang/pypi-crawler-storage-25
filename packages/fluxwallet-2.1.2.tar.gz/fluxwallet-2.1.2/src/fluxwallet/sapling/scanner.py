from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import httpx

from fluxwallet.config import RELAY_HTTP_TIMEOUT
from fluxwallet.sapling import require_sapling
from fluxwallet.sapling.notes import SaplingNote
from fluxwallet.services.models import (
    SaplingCommitment,
    SaplingNullifier,
    SaplingTreeState,
)

if TYPE_CHECKING:
    from fluxwallet.sapling.keys import SaplingIncomingViewingKey


@dataclass(frozen=True)
class ScanResult:
    """Result of scanning commitments or nullifiers."""

    notes: list[SaplingNote]
    chain_height: int
    commitments: list[SaplingCommitment]


class SaplingScanner:
    """Fetches Sapling data from the explorer and trial-decrypts locally."""

    def __init__(self, explorer_url: str, ivk: SaplingIncomingViewingKey) -> None:
        require_sapling()
        self._explorer_url = explorer_url.rstrip("/")
        self._ivk = ivk

    async def scan_range(
        self,
        from_height: int,
    ) -> ScanResult:
        """Fetch commitments from explorer, trial-decrypt each locally.

        Returns notes that belong to this key and the chain height.
        """
        notes: list[SaplingNote] = []
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self._explorer_url}/api/v1/sapling/commitments",
                params={"from": from_height},
                timeout=60.0,
            )
            response.raise_for_status()
            data = response.json()

        chain_height = data["chain_height"]
        commitments = [SaplingCommitment(**c) for c in data["commitments"]]

        for commitment in commitments:
            cmu = bytes.fromhex(commitment.cmu)
            epk = bytes.fromhex(commitment.ephemeral_key)
            enc_ciphertext = bytes.fromhex(commitment.enc_ciphertext)
            height = commitment.block_height

            result = self._ivk.try_decrypt(cmu, epk, enc_ciphertext, height)
            if result is not None:
                note = SaplingNote(
                    value=result["value"],
                    rcm=result["rcm"],
                    address=result["address"],
                    position=commitment.position,
                    block_height=height,
                    txid=commitment.txid,
                    output_index=commitment.output_index,
                    nullifier=result["nullifier"],
                )
                notes.append(note)

        return ScanResult(
            notes=notes,
            chain_height=chain_height,
            commitments=commitments,
        )

    async def check_spent(
        self,
        notes: list[SaplingNote],
    ) -> list[str]:
        """Fetch nullifiers from explorer, return txids of spent notes.

        Also marks notes as spent in-place.
        """
        if not notes:
            return []

        min_height = min(n.block_height for n in notes)
        nullifier_map = {n.nullifier.hex(): n for n in notes}
        spent_txids: list[str] = []

        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self._explorer_url}/api/v1/sapling/nullifiers",
                params={"from": min_height},
                timeout=60.0,
            )
            response.raise_for_status()
            data = response.json()

        nullifiers = [SaplingNullifier(**nf) for nf in data["nullifiers"]]
        for nf_entry in nullifiers:
            nf_hex = nf_entry.nullifier
            if nf_hex in nullifier_map:
                note = nullifier_map[nf_hex]
                note.spent = True
                note.spending_txid = nf_entry.txid
                spent_txids.append(nf_entry.txid)

        return spent_txids

    async def get_tree_root(self, height: int) -> bytes:
        """Get Sapling tree root at height from explorer."""
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self._explorer_url}/api/v1/sapling/tree-state/{height}",
                timeout=RELAY_HTTP_TIMEOUT,
            )
            response.raise_for_status()
            data = SaplingTreeState(**response.json())

        return bytes.fromhex(data.root)
