from __future__ import annotations

from typing import TYPE_CHECKING

from fluxwallet.sapling import fluxwallet_sapling, require_sapling

if TYPE_CHECKING:
    from fluxwallet.services.models import SaplingCommitment


class SaplingTree:
    """Local Sapling commitment Merkle tree.

    Wraps the Rust tree operations for building witnesses needed to create shielded transactions.
    """

    def __init__(self, tree_bytes: bytes | None = None) -> None:
        require_sapling()
        if tree_bytes:
            self._tree_bytes: bytes = tree_bytes
            # Size isn't stored — we don't need it for witness generation
            # on a restored tree. New commitments will be appended.
            self._size: int = -1
        else:
            self._tree_bytes = fluxwallet_sapling.empty_sapling_tree()
            self._size = 0

    def serialize(self) -> bytes:
        """Return the serialized tree state for persistence."""
        return self._tree_bytes

    def add_commitment(self, cmu: bytes) -> int:
        """Add a commitment to the tree.

        Returns the position (leaf index) of the added commitment.
        """
        self._tree_bytes = fluxwallet_sapling.add_commitment(self._tree_bytes, cmu)
        pos = self._size
        self._size += 1
        return pos

    def root(self) -> bytes:
        """Return the current Merkle root of the tree."""
        require_sapling()
        return fluxwallet_sapling.tree_root(self._tree_bytes)

    def witness(self, position: int) -> bytes:
        """Return the authentication path (witness) for a leaf at position.

        The witness is required to prove membership when spending a note.
        """
        require_sapling()
        if position < 0 or position >= self._size:
            raise ValueError(f"Position {position} out of range [0, {self._size})")
        return fluxwallet_sapling.witness_at_position(self._tree_bytes, position)

    @property
    def size(self) -> int:
        """Number of commitments in the tree."""
        return self._size

    def add_commitments(self, commitments: list[SaplingCommitment]) -> int:
        """Add pre-fetched commitments to the tree.

        Returns the count of commitments added.
        """
        count = 0
        for commitment in commitments:
            cmu = bytes.fromhex(commitment.cmu)
            self.add_commitment(cmu)
            count += 1
        return count
