from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SaplingNote:
    """A decrypted Sapling note."""

    value: int
    rcm: bytes
    address: bytes
    position: int
    block_height: int
    txid: str
    output_index: int
    nullifier: bytes
    spent: bool = False
    spending_txid: str | None = None
