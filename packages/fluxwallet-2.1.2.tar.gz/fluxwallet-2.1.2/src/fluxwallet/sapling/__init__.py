from __future__ import annotations

try:
    import fluxwallet_sapling  # noqa: F401

    SHIELDED_AVAILABLE = True
except ImportError:
    SHIELDED_AVAILABLE = False


def require_sapling() -> None:
    """Raise if the Rust extension is not installed."""
    if not SHIELDED_AVAILABLE:
        raise RuntimeError("fluxwallet-sapling is not installed. Install with: pip install fluxwallet[shielded]")
