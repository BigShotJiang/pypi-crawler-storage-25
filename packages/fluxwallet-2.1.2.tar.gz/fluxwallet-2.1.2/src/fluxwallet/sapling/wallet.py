from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

from fluxwallet.encoding import addr_base58_to_pubkeyhash
from fluxwallet.sapling import fluxwallet_sapling, require_sapling
from fluxwallet.sapling.notes import SaplingNote
from fluxwallet.sapling.scanner import SaplingScanner
from fluxwallet.sapling.tree import SaplingTree
from fluxwallet.wallet_store import StoredSaplingNote, StoredWallet, WalletStore

if TYPE_CHECKING:
    from fluxwallet.sapling.keys import SaplingPaymentAddress, SaplingSpendingKey


def _ensure_params_loaded() -> None:
    """Load Sapling proving parameters if not already loaded."""
    require_sapling()
    if not fluxwallet_sapling.params_loaded():
        fluxwallet_sapling.load_sapling_params()


def _stored_to_note(sn: StoredSaplingNote) -> SaplingNote:
    return SaplingNote(
        value=sn.value,
        rcm=sn.rcm,
        address=sn.address,
        position=sn.position,
        block_height=sn.block_height,
        txid=sn.txid,
        output_index=sn.output_index,
        nullifier=sn.nullifier,
        spent=sn.spent,
        spending_txid=sn.spending_txid or None,
    )


def _note_to_stored(note: SaplingNote, wallet_id: int) -> StoredSaplingNote:
    return StoredSaplingNote(
        id=0,
        wallet_id=wallet_id,
        value=note.value,
        rcm=note.rcm,
        address=note.address,
        position=note.position,
        block_height=note.block_height,
        txid=note.txid,
        output_index=note.output_index,
        nullifier=note.nullifier,
        spent=note.spent,
        spending_txid=note.spending_txid or "",
    )


class ShieldedWallet:
    """Manages shielded wallet state: notes, balances, and transactions.

    Loads persisted state from the WalletStore on creation, and saves
    back after sync/spend operations.
    """

    def __init__(
        self,
        spending_key: SaplingSpendingKey,
        explorer_url: str,
        wallet_id: int,
        store: WalletStore,
        stored_wallet: StoredWallet,
        save_callback: Callable[[], Awaitable[None]],
    ) -> None:
        require_sapling()
        self._save = save_callback
        self._spending_key = spending_key
        self._explorer_url = explorer_url.rstrip("/")
        self._wallet_id = wallet_id
        self._store = store
        self._stored_wallet = stored_wallet

        fvk = spending_key.full_viewing_key()
        ivk = fvk.incoming_viewing_key()
        self._scanner = SaplingScanner(explorer_url, ivk)

        # Restore persisted tree state
        if stored_wallet.sapling_tree:
            self._tree = SaplingTree(stored_wallet.sapling_tree)
        else:
            self._tree = SaplingTree()

        # Restore persisted notes
        stored_notes = store.get_sapling_notes(wallet_id=wallet_id)
        self._notes: list[SaplingNote] = [_stored_to_note(sn) for sn in stored_notes]
        self._last_scanned_height: int = stored_wallet.sapling_last_scanned_height

    async def _save_state(self) -> None:
        """Persist tree, notes, and scan height to the store."""
        # Update wallet-level state
        self._stored_wallet.sapling_last_scanned_height = self._last_scanned_height
        self._stored_wallet.sapling_tree = self._tree.serialize()
        self._store.update_wallet(self._stored_wallet)

        # Sync notes: remove old, add current
        old_notes = self._store.get_sapling_notes(wallet_id=self._wallet_id)
        for old in old_notes:
            del self._store.sapling_notes[old.id]

        for note in self._notes:
            stored = _note_to_stored(note, self._wallet_id)
            self._store.add_sapling_note(stored)

        await self._save()

    async def sync(self, up_to_height: int | None = None) -> int:
        """Scan for new notes from last scanned height.

        If up_to_height is None, syncs to the explorer's chain tip. Returns the count of new notes found.
        """
        scan_result = await self._scanner.scan_range(
            self._last_scanned_height + 1,
        )

        chain_height = up_to_height or scan_result.chain_height
        if chain_height <= self._last_scanned_height:
            return 0

        self._tree.add_commitments(scan_result.commitments)

        if self._notes:
            await self._scanner.check_spent(self._notes)

        if scan_result.notes:
            await self._scanner.check_spent(scan_result.notes)

        self._notes.extend(scan_result.notes)
        self._last_scanned_height = chain_height

        await self._save_state()
        return len(scan_result.notes)

    def balance(self) -> int:
        """Sum of unspent note values in satoshis."""
        return sum(n.value for n in self._notes if not n.spent)

    def unspent_notes(self) -> list[SaplingNote]:
        """All unspent notes."""
        return [n for n in self._notes if not n.spent]

    @property
    def last_scanned_height(self) -> int:
        return self._last_scanned_height

    def _select_notes(self, amount_needed: int) -> list[SaplingNote]:
        """Largest-first coin selection from unspent notes."""
        available = sorted(self.unspent_notes(), key=lambda n: n.value, reverse=True)
        selected: list[SaplingNote] = []
        total = 0
        for note in available:
            selected.append(note)
            total += note.value
            if total >= amount_needed:
                return selected
        raise ValueError(
            f"Insufficient shielded balance: need {amount_needed},"
            f" have {total}. Recovery: shield more funds or send less"
        )

    def _build_spend_dicts(
        self,
        notes: list[SaplingNote],
    ) -> list[dict[str, bytes | int]]:
        """Build the spend input dicts that the Rust builder expects."""
        fvk_bytes = self._spending_key.full_viewing_key().raw_bytes()
        spend_dicts: list[dict[str, bytes | int]] = []
        for note in notes:
            witness_bytes = self._tree.witness(note.position)
            spend_dicts.append(
                {
                    "fvk_bytes": fvk_bytes,
                    "note_value": note.value,
                    "rcm_bytes": note.rcm,
                    "address_bytes": note.address,
                    "witness_bytes": witness_bytes,
                }
            )
        return spend_dicts

    async def shield(
        self,
        transparent_inputs: list[dict[str, bytes | int]],
        value: int,
        target_height: int,
        fee: int = 10000,
        change_address_hash: bytes | None = None,
    ) -> bytes:
        """Create t->z shielding transaction.

        Returns raw tx bytes.
        """
        _ensure_params_loaded()

        default_addr = self._spending_key.default_address()
        outputs: list[dict[str, bytes | int]] = [
            {
                "address_bytes": default_addr.to_bytes(),
                "value": value,
                "memo": b"",
            },
        ]

        total_in = sum(int(inp["value"]) for inp in transparent_inputs)
        change = total_in - value - fee

        transparent_outputs: list[dict[str, bytes | int | str]] | None = None
        if change > 0:
            if change_address_hash is None:
                raw_hash = transparent_inputs[0]["address_hash"]
                if not isinstance(raw_hash, bytes):
                    raise ValueError("address_hash must be bytes")
                change_address_hash = raw_hash
            transparent_outputs = [
                {
                    "address_hash": change_address_hash,
                    "address_type": "p2pkh",
                    "value": change,
                },
            ]

        anchor = self._tree.root()

        result = fluxwallet_sapling.build_shielded_transaction(
            spending_key_bytes=self._spending_key.raw_bytes(),
            spends=[],
            outputs=outputs,
            anchor_bytes=anchor,
            fee=fee,
            transparent_inputs=transparent_inputs,
            transparent_outputs=transparent_outputs,
            target_height=target_height,
        )

        return bytes(result["raw_tx"])

    async def send(
        self,
        to_address: SaplingPaymentAddress,
        value: int,
        target_height: int,
        fee: int = 10000,
        memo: bytes = b"",
    ) -> bytes:
        """Create z->z shielded transaction.

        Returns raw tx bytes.
        """
        _ensure_params_loaded()

        total_needed = value + fee
        selected = self._select_notes(total_needed)

        anchor = self._tree.root()
        spend_dicts = self._build_spend_dicts(selected)

        outputs: list[dict[str, bytes | int]] = [
            {
                "address_bytes": to_address.to_bytes(),
                "value": value,
                "memo": memo,
            },
        ]

        input_total = sum(n.value for n in selected)
        change = input_total - total_needed
        if change > 0:
            outputs.append(
                {
                    "address_bytes": self._spending_key.default_address().to_bytes(),
                    "value": change,
                    "memo": b"",
                }
            )

        result = fluxwallet_sapling.build_shielded_transaction(
            spending_key_bytes=self._spending_key.raw_bytes(),
            spends=spend_dicts,
            outputs=outputs,
            anchor_bytes=anchor,
            fee=fee,
            target_height=target_height,
        )

        return bytes(result["raw_tx"])

    async def deshield(
        self,
        to_address: str,
        value: int,
        target_height: int,
        fee: int = 10000,
    ) -> bytes:
        """Create z->t deshielding transaction.

        Returns raw tx bytes.
        """
        _ensure_params_loaded()

        total_needed = value + fee
        selected = self._select_notes(total_needed)

        anchor = self._tree.root()
        spend_dicts = self._build_spend_dicts(selected)

        pkh = addr_base58_to_pubkeyhash(to_address)
        address_type = "p2sh" if to_address.startswith("t3") else "p2pkh"

        transparent_outputs: list[dict[str, bytes | int | str]] = [
            {
                "address_hash": pkh,
                "address_type": address_type,
                "value": value,
            },
        ]

        sapling_outputs: list[dict[str, bytes | int]] = []
        input_total = sum(n.value for n in selected)
        change = input_total - total_needed
        if change > 0:
            sapling_outputs.append(
                {
                    "address_bytes": self._spending_key.default_address().to_bytes(),
                    "value": change,
                    "memo": b"",
                }
            )

        result = fluxwallet_sapling.build_shielded_transaction(
            spending_key_bytes=self._spending_key.raw_bytes(),
            spends=spend_dicts,
            outputs=sapling_outputs,
            anchor_bytes=anchor,
            fee=fee,
            transparent_outputs=transparent_outputs,
            target_height=target_height,
        )

        return bytes(result["raw_tx"])
