from __future__ import annotations

import fluxwallet_sapling
from fluxwallet.encoding import bech32_encode
from fluxwallet.sapling import require_sapling


class SaplingSpendingKey:
    """Master Sapling key — derives all other keys, can spend notes."""

    @classmethod
    def from_seed(
        cls,
        seed: bytearray,
        coin_type: int = 19167,
        account: int = 0,
    ) -> SaplingSpendingKey:
        """Derive from BIP39 seed bytearray."""
        require_sapling()
        result = fluxwallet_sapling.sapling_key_from_seed(bytes(seed), coin_type, account)
        return cls(
            result["spending_key"],
            result["full_viewing_key"],
        )

    def __init__(
        self,
        sk_bytes: bytes,
        fvk_bytes: bytes,
    ) -> None:
        self._sk = sk_bytes
        self._fvk = fvk_bytes

    def full_viewing_key(self) -> SaplingFullViewingKey:
        """Derive the full viewing key from this spending key."""
        return SaplingFullViewingKey(self._fvk)

    def default_address(self) -> SaplingPaymentAddress:
        """Derive the default (diversifier-index-0) payment address."""
        return self.full_viewing_key().derive_address(0)

    def raw_bytes(self) -> bytes:
        """Return the raw spending key bytes."""
        return self._sk

    def __repr__(self) -> str:
        return f"SaplingSpendingKey({self._sk.hex()[:16]}...)"


class SaplingFullViewingKey:
    """Can view all transactions but cannot spend."""

    def __init__(self, fvk_bytes: bytes) -> None:
        self._fvk = fvk_bytes

    def incoming_viewing_key(self) -> SaplingIncomingViewingKey:
        """Derive the incoming viewing key."""
        require_sapling()
        ivk_bytes = fluxwallet_sapling.sapling_incoming_viewing_key(self._fvk)
        return SaplingIncomingViewingKey(ivk_bytes)

    def derive_address(self, diversifier_index: int = 0) -> SaplingPaymentAddress:
        """Derive a payment address at the given diversifier index."""
        require_sapling()
        result = fluxwallet_sapling.sapling_derive_address(self._fvk, diversifier_index)
        return SaplingPaymentAddress(result["payment_address"])

    def raw_bytes(self) -> bytes:
        """Return the raw full viewing key bytes."""
        return self._fvk

    def __repr__(self) -> str:
        return f"SaplingFullViewingKey({self._fvk.hex()[:16]}...)"


class SaplingIncomingViewingKey:
    """Can detect incoming notes only."""

    def __init__(self, ivk_bytes: bytes) -> None:
        self._ivk = ivk_bytes

    def try_decrypt(
        self,
        cmu: bytes,
        epk: bytes,
        enc_ciphertext: bytes,
        height: int,
    ) -> dict | None:
        """Attempt to decrypt a note output.

        Returns a dict with note fields (value, rcm, address, nullifier) on success, or None if the note is not ours.
        """
        require_sapling()
        return fluxwallet_sapling.try_decrypt_note(self._ivk, cmu, epk, enc_ciphertext, height)

    def raw_bytes(self) -> bytes:
        """Return the raw incoming viewing key bytes."""
        return self._ivk

    def __repr__(self) -> str:
        return f"SaplingIncomingViewingKey({self._ivk.hex()[:16]}...)"


class SaplingPaymentAddress:
    """Diversified payment address — share with senders."""

    def __init__(self, addr_bytes: bytes) -> None:
        self._addr = addr_bytes

    def to_bytes(self) -> bytes:
        """Return the raw address bytes."""
        return self._addr

    def __str__(self) -> str:
        return bech32_encode("za", self._addr)

    def __repr__(self) -> str:
        return f"SaplingPaymentAddress({self._addr.hex()[:16]}...)"
