"""Sapling key management methods — mixed into WalletKeyManager when shielded is available."""

from __future__ import annotations

from typing import TYPE_CHECKING

import fluxwallet_sapling
from fluxwallet.encoding import bech32_encode
from fluxwallet.sapling.keys import SaplingSpendingKey
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet.store_access import _get_store, _save_store

if TYPE_CHECKING:
    from fluxwallet.wallet_store import StoredKey


class SaplingKeyMixin:
    """Sapling key methods, mixed into WalletKeyManager when fluxwallet-sapling is installed."""

    async def new_sapling_key(self, change: int = 0, name: str = "") -> StoredKey:
        """Create a new diversified Sapling z-address (receive or change)."""
        from fluxwallet.wallet_store import StoredKey as _StoredKey

        store = await _get_store()
        masters = store.get_keys(wallet_id=self._wallet.wallet_id, key_type="sapling")
        if not masters:
            raise WalletError(
                "No Sapling master key."
                " Recovery: recreate wallet from mnemonic"
            )
        master = masters[0]
        if master.public is None:
            raise WalletError("Sapling master key has no viewing key")

        existing = store.get_keys(wallet_id=self._wallet.wallet_id, key_type="sapling_address", change=change)
        existing.sort(key=lambda k: k.address_index, reverse=True)
        next_index = (existing[0].address_index + 1) if existing else 0

        result = fluxwallet_sapling.sapling_derive_address(master.public, next_index)
        addr_bytes: bytes = result["payment_address"]
        found_div = int.from_bytes(result["diversifier"][:8], "little")

        all_sapling_addrs = store.get_keys(wallet_id=self._wallet.wallet_id, key_type="sapling_address")

        addr_key = _StoredKey(
            id=0,
            wallet_id=self._wallet.wallet_id,
            parent_id=master.id,
            name=name or f"{self._wallet.name}_z{len(all_sapling_addrs)}",
            key_type="sapling_address",
            depth=5,
            change=change,
            address_index=found_div,
            address=bech32_encode("za", addr_bytes),
            path=f"m/32'/19167'/0'/{change}/{found_div}",
            network_name=self._wallet.network.name,
            encoding="bech32",
            purpose=32,
        )
        store.add_key(addr_key)
        await _save_store()
        return addr_key

    async def new_sapling_key_change(self, name: str = "") -> StoredKey:
        """Create a new Sapling change z-address."""
        return await self.new_sapling_key(change=1, name=name)

    async def sapling_spending_key(self) -> SaplingSpendingKey:
        """Load the Sapling spending key for this wallet."""
        store = await _get_store()
        for k in store.keys.values():
            if k.key_type == "sapling" and k.wallet_id == self._wallet.wallet_id:
                if k.private is None:
                    raise WalletError(f"Sapling key for '{self._wallet.name}' has no private key")
                if not k.public:
                    raise WalletError(f"Sapling key for '{self._wallet.name}' has no viewing key")
                return SaplingSpendingKey(k.private, k.public)
        raise WalletError(
            f"No Sapling key found for wallet '{self._wallet.name}'. "
            "Recreate the wallet from its mnemonic to enable shielded support."
        )

    async def z_address(self, change: int = 0) -> str:
        """Get the latest Sapling z-address for this wallet."""
        store = await _get_store()
        addrs = store.get_keys(
            wallet_id=self._wallet.wallet_id,
            key_type="sapling_address",
            change=change,
        )
        if not addrs:
            raise WalletError(f"No z-address for wallet '{self._wallet.name}'")
        addrs.sort(key=lambda k: k.address_index, reverse=True)
        return addrs[0].address
