from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from fluxwallet.wallet import Wallet

if TYPE_CHECKING:
    from fluxwallet.keys import (
        HDKey,
    )

_logger = logging.getLogger(__name__)


class WalletError(Exception):
    def __init__(self, msg: str = "") -> None:
        self.msg = msg
        _logger.error(msg)

    def __str__(self) -> str:
        return self.msg


async def wallets_list(db_uri: str | None = None, include_cosigners: bool = False) -> list[dict[str, str | int | None]]:
    """List wallets.

    Returns list of dicts with id, name, owner, network, etc.
    """
    return await Wallet.list_all(include_cosigners=include_cosigners)


async def wallet_exists(wallet: str | int, db_uri: str | None = None) -> bool:
    """Check if wallet exists by name or ID."""
    return await Wallet.exists(wallet)


async def wallet_create_or_open(
    name: str,
    keys: str | bytes | int | HDKey | list[str] | list[bytes] | list[int] | list[HDKey] = "",
    owner: str = "",
    network: str | None = None,
    account_id: int = 0,
    purpose: int | None = None,
    scheme: str = "bip32",
    sort_keys: bool = True,
    password: str = "",
    witness_type: str | None = None,
    encoding: str | None = None,
    multisig: bool | None = None,
    sigs_required: int | None = None,
    cosigner_id: int | None = None,
    key_path: list[str] | str | None = None,
    db_uri: str | None = None,
) -> Wallet:
    """Create a wallet if it doesn't exist, otherwise open it."""
    if await Wallet.exists(name):
        if keys or owner or password or witness_type or key_path:
            _logger.warning("Opening existing wallet, extra options are ignored")
        return await Wallet.open(name, db_uri=db_uri)
    return await Wallet.create(
        name,
        keys,
        owner,
        network,
        account_id,
        purpose or 0,
        scheme,
        sort_keys,
        password,
        witness_type,
        encoding,
        multisig,
        sigs_required,
        cosigner_id,
        key_path,
        db_uri=db_uri,
    )


async def wallet_delete(wallet: Wallet | int | str, db_uri: str | None = None, force: bool = False) -> bool:
    """Delete wallet and associated keys and transactions."""
    ident = wallet.wallet_id if isinstance(wallet, Wallet) else wallet
    return await Wallet.delete(ident, force=force)


async def wallet_empty(wallet: Wallet | int | str, db_uri: str | None = None) -> bool:
    """Remove all generated keys and transactions from wallet, keeping the masterkey."""
    ident = wallet.wallet_id if isinstance(wallet, Wallet) else wallet
    return await Wallet.empty(ident)


async def wallet_delete_if_exists(wallet: str | int, db_uri: str | None = None, force: bool = False) -> bool:
    """Delete wallet if it exists, otherwise return False."""
    if await Wallet.exists(wallet):
        return await Wallet.delete(wallet, force=force)
    return False


def normalize_path(path: str) -> str:
    """Normalize BIP0044 key path -- use single quotes for hardened keys."""
    levels: list[str] = path.split("/")
    npath: str = ""
    for level in levels:
        if not level:
            raise WalletError("Could not parse path. Index is empty.")
        nlevel: str = level
        if level[-1] in "'HhPp":
            nlevel = level[:-1] + "'"
        npath += nlevel + "/"
    if npath[-1] == "/":
        npath = npath[:-1]
    return npath
