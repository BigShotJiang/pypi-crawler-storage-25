#
#    fluxwallet - Python Cryptocurrency Library
#    NETWORK class reads network definitions and with helper methods
#    © 2017 - 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

import contextlib
import json
import logging
from pathlib import Path

from fluxwallet.config import DEFAULT_NETWORK, FW_DATA_DIR, FW_INSTALL_DIR
from fluxwallet.encoding import change_base
from fluxwallet.main import script_type_default

_logger: logging.Logger = logging.getLogger(__name__)


class NetworkError(Exception):
    """Network Exception class."""

    def __init__(self, msg: str = "") -> None:
        self.msg: str = msg
        _logger.error(msg)

    def __str__(self) -> str:
        return self.msg


def _read_network_definitions() -> dict[str, dict[str, str | int | float | list[list[str | bool | None]]]]:
    """Returns network definitions from json file in settings dir. Tries user config path first, falls back to bundled
    data.

    :return dict: Network definitions
    """

    for base_dir in (FW_DATA_DIR, Path(FW_INSTALL_DIR, "data")):
        fn: Path = Path(base_dir, "networks.json")
        if fn.exists():
            try:
                with fn.open("rb") as f:
                    return json.loads(f.read())
            except json.decoder.JSONDecodeError as e:
                raise NetworkError(f"Error reading network definitions from {fn}: {e}") from e
    raise NetworkError("networks.json not found in user config or bundled data")


NETWORK_DEFINITIONS: dict[str, dict[str, str | int | float | list[list[str | bool | None]]]] = (
    _read_network_definitions()
)


def _nd_str(nd: dict[str, str | int | float | list[list[str | bool | None]]], key: str) -> str:
    """Extract a string value from a network definition dict."""
    v = nd[key]
    if isinstance(v, str):
        return v
    return str(v)


def _nd_int(
    nd: dict[str, str | int | float | list[list[str | bool | None]]],
    key: str,
    default: int = 0,
) -> int:
    """Extract an int value from a network definition dict."""
    v = nd.get(key)
    if v is None:
        return default
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v)
    if isinstance(v, str):
        try:
            return int(float(v))
        except (ValueError, TypeError):
            return default
    return default


def _nd_float(nd: dict[str, str | int | float | list[list[str | bool | None]]], key: str) -> float:
    """Extract a float value from a network definition dict."""
    v = nd[key]
    if isinstance(v, float):
        return v
    if isinstance(v, int):
        return float(v)
    return float(str(v))


def _format_value(field: str, value: str | int | float | list[list[str | bool | None]]) -> bytes | float | str:
    if field[:6] == "prefix":
        return bytes.fromhex(str(value))
    if field == "denominator":
        return float(str(value))
    return str(value)


def network_values_for(field: str) -> list[bytes | float | str]:
    """Return all prefixes for field, i.e.: prefix_wif, prefix_address_p2sh, etc.

    >>> network_values_for('prefix_wif')
    [b'\\x99', b'\\x80', b'\\xef', b'\\xb0', b'\\xcc', b'\\x9e', b'\\xf1']
    >>> network_values_for('prefix_address_p2sh')
    [b'\\x95', b'\\x05', b'\\xc4', b'2', b':', b'\\x10', b'\\x13', b'\\x16']

    :param field: Prefix name from networks definitions (networks.json)
    :type field: str

    :return str:
    """
    return list(dict.fromkeys([_format_value(field, nv[field]) for nv in NETWORK_DEFINITIONS.values()]))


def prefix_len_by_network(network: str) -> int:
    return len(bytes.fromhex(str(NETWORK_DEFINITIONS[network]["prefix_address"])))


def network_by_value(field: str, value: str) -> list[str]:
    """Return all networks for field and (prefix) value.

    Example, get available networks for WIF or address prefix

    >>> network_by_value('prefix_wif', 'B0')
    ['litecoin', 'litecoin_legacy']
    >>> network_by_value('prefix_address', '6f')
    ['testnet', 'litecoin_testnet']

    This method does not work for HD prefixes, use 'wif_prefix_search' instead

    >>> network_by_value('prefix_address', '043587CF')
    []

    :param field: Prefix name from networks definitions (networks.json)
    :type field: str
    :param value: Value of network prefix
    :type value: str

    :return list: Of network name strings
    """
    nws: list[tuple[str, int]] = [
        (nv, _nd_int(NETWORK_DEFINITIONS[nv], "priority"))
        for nv in NETWORK_DEFINITIONS
        if _nd_str(NETWORK_DEFINITIONS[nv], field) == value[0 : len(_nd_str(NETWORK_DEFINITIONS[nv], field))]
    ]
    if not nws:
        with contextlib.suppress(TypeError):
            value = value.upper()
        nws = [
            (nv, _nd_int(NETWORK_DEFINITIONS[nv], "priority"))
            for nv in NETWORK_DEFINITIONS
            if _nd_str(NETWORK_DEFINITIONS[nv], field) == value[0 : len(_nd_str(NETWORK_DEFINITIONS[nv], field))]
        ]
    return [nw[0] for nw in sorted(nws, key=lambda x: x[1], reverse=True)]


def network_defined(network: str) -> bool:
    """Is network defined?

    Networks of this library are defined in networks.json in the operating systems user path.

    >>> network_defined('bitcoin')
    True
    >>> network_defined('ethereum')
    False

    :param network: Network name
    :type network: str

    :return bool:
    """
    return network in list(NETWORK_DEFINITIONS.keys())


def wif_prefix_search(
    wif: str,
    witness_type: str | None = None,
    multisig: bool | None = None,
    network: str | None = None,
) -> list[dict[str, str | bool | None]]:
    """Extract network, script type and public/private information from HDKey WIF or WIF prefix.

    Example, get bitcoin 'xprv' info:

    >>> wif_prefix_search('0488ADE4', network='bitcoin', multisig=False)
    [{'prefix': '0488ADE4', 'is_private': True, 'prefix_str': 'xprv', 'network': 'bitcoin', \
'witness_type': 'legacy', 'multisig': False, 'script_type': 'p2pkh'}]

    Or retreive info with full WIF string:

    >>> wif_prefix_search(
    ...     'xprv9wTYmMFdV23N21MM6dLNavSQV7Sj7meSPXx6AV5eTdqqGLjycVjb115Ec5LgRAXscPZgy5G4jQ9csyyZLN3'
    ...     'PZLxoM1h3BoPuEJzsgeypdKj',
    ...     network='bitcoin', multisig=False)
    [{'prefix': '0488ADE4', 'is_private': True, 'prefix_str': 'xprv', 'network': 'bitcoin', \
'witness_type': 'legacy', 'multisig': False, 'script_type': 'p2pkh'}]

    Can return multiple items if no network is specified:

    >>> [nw['network'] for nw in wif_prefix_search('0488ADE4', multisig=True)]
    ['bitcoin', 'regtest', 'dash', 'dogecoin']

    :param wif: WIF string or prefix as hexadecimal string
    :type wif: str
    :param witness_type: Limit search to specific witness type
    :type witness_type: str
    :param multisig: Limit search to multisig: false, true or None for both. Default is both
    :type multisig: bool
    :param network: Limit search to specified network
    :type network: str

    :return dict:
    """

    key_hex: str = wif
    if len(wif) > 8:
        with contextlib.suppress(Exception):
            key_hex = str(change_base(wif, 58, 16))
    prefix: str = key_hex[:8].upper()
    matches: list[dict[str, str | bool | None]] = []
    for nw in NETWORK_DEFINITIONS:
        if network is not None and nw != network:
            continue
        data: dict[str, str | int | float | list[list[str | bool | None]]] = NETWORK_DEFINITIONS[nw]
        prefixes_wif_val = data["prefixes_wif"]
        if not isinstance(prefixes_wif_val, list):
            continue
        for pf in prefixes_wif_val:
            if (
                pf[0] == prefix
                and (multisig is None or pf[3] is None or pf[3] == multisig)
                and (witness_type is None or pf[4] is None or pf[4] == witness_type)
            ):
                matches.append(
                    {
                        "prefix": prefix,
                        "is_private": pf[2] == "private",
                        "prefix_str": pf[1],
                        "network": nw,
                        "witness_type": pf[4],
                        "multisig": pf[3],
                        "script_type": pf[5],
                    }
                )
    return matches


class Network:
    """Network class with all network definitions.

    Prefixes for WIF, P2SH keys, HD public and private keys, addresses. A currency symbol and type, the denominator
    (such as satoshi) and a BIP0044 cointype.
    """

    def __init__(self, network_name: str = DEFAULT_NETWORK) -> None:
        if network_name not in NETWORK_DEFINITIONS:
            raise NetworkError(f"Network {network_name} not found in network definitions")
        self.name: str = network_name

        _nd = NETWORK_DEFINITIONS[network_name]
        self.currency_name: str = _nd_str(_nd, "currency_name")
        self.currency_name_plural: str = _nd_str(_nd, "currency_name_plural")
        self.currency_code: str = _nd_str(_nd, "currency_code")
        self.currency_symbol: str = _nd_str(_nd, "currency_symbol")
        self.description: str = _nd_str(_nd, "description")
        self.prefix_address_p2sh: bytes = bytes.fromhex(_nd_str(_nd, "prefix_address_p2sh"))
        self.prefix_address: bytes = bytes.fromhex(_nd_str(_nd, "prefix_address"))
        self.prefix_bech32: str = _nd_str(_nd, "prefix_bech32")
        self.prefix_wif: bytes = bytes.fromhex(_nd_str(_nd, "prefix_wif"))
        self.denominator: float = _nd_float(_nd, "denominator")
        self.bip44_cointype: int = _nd_int(_nd, "bip44_cointype")
        self.dust_amount: int = _nd_int(_nd, "dust_amount")  # Dust amount in satoshi
        self.fee_default: int = _nd_int(_nd, "fee_default")  # Default fee in satoshi per kilobyte
        self.fee_min: int = _nd_int(_nd, "fee_min")  # Minimum transaction fee in satoshi per kilobyte
        self.fee_max: int = _nd_int(_nd, "fee_max")  # Maximum transaction fee in satoshi per kilobyte
        self.priority: int = _nd_int(_nd, "priority")
        _pw = _nd["prefixes_wif"]
        self.prefixes_wif: list[list[str | bool | None]] = _pw if isinstance(_pw, list) else []

        # This could be shorter and more flexible with the code below, but this gives 'Unresolved attributes' warnings
        # for f in list(NETWORK_DEFINITIONS[network_name].keys()):
        #     exec("self.%s = NETWORK_DEFINITIONS[network_name]['%s']" % (f, f))

    def __repr__(self) -> str:
        return f"<Network: {self.name}>"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, str):
            return self.name == other
        if not isinstance(other, Network):
            return NotImplemented
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)

    def wif_prefix(
        self,
        is_private: bool = False,
        witness_type: str = "legacy",
        multisig: bool = False,
    ) -> bytes:
        """Get WIF prefix for this network and specifications in arguments.

        >>> Network('bitcoin').wif_prefix()  # xpub
        b'\\x04\\x88\\xb2\\x1e'
        >>> Network('bitcoin').wif_prefix(is_private=True, witness_type='segwit', multisig=True)  # Zprv
        b'\\x02\\xaaz\\x99'

        :param is_private: Private or public key, default is True
        :type is_private: bool
        :param witness_type: Legacy, segwit or p2sh-segwit
        :type witness_type: str
        :param multisig: Multisignature or single signature wallet. Default is False: no multisig
        :type multisig: bool

        :return bytes:
        """
        script_type: str = script_type_default(witness_type, multisig, locking_script=True) or "p2pkh"
        if script_type == "p2sh" and witness_type in ["p2sh-segwit", "segwit"]:
            script_type = "p2sh_p2wsh" if multisig else "p2sh_p2wpkh"
        if is_private:
            ip: str = "private"
        else:
            ip = "public"
        found_prefixes: list[bytes] = [
            bytes.fromhex(str(pf[0])) for pf in self.prefixes_wif if pf[2] == ip and script_type == pf[5]
        ]
        if found_prefixes:
            return found_prefixes[0]
        raise NetworkError(f"WIF Prefix for script type {script_type} not found")
