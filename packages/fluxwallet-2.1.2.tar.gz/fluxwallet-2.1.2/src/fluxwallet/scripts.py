#
#    fluxwallet - Python Cryptocurrency Library
#    Scripts class - Parse, Serialize and Evaluate scripts
#    © 2022 - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

import hashlib
import logging
from io import BytesIO
from typing import TYPE_CHECKING

from fluxwallet.config import SIGHASH_ALL
from fluxwallet.config.opcodes import op, opcodenames
from fluxwallet.encoding import hash160, ripemd160
from fluxwallet.exceptions import FluxWalletError
from fluxwallet.keys import HDKey, Key, Signature

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence

_logger: logging.Logger = logging.getLogger(__name__)


SCRIPT_TYPES: dict[str, tuple[str, list[int | str], list[int]]] = {
    # <name>: (<type>, <script_commands>, <data-lengths>)
    "p2pkh": (
        "locking",
        [op.op_dup, op.op_hash160, "data", op.op_equalverify, op.op_checksig],
        [20],
    ),
    "p2pkh_drop": (
        "locking",
        [
            "data",
            op.op_drop,
            op.op_dup,
            op.op_hash160,
            "data",
            op.op_equalverify,
            op.op_checksig,
        ],
        [32, 20],
    ),
    "p2sh": ("locking", [op.op_hash160, "data", op.op_equal], [20]),
    "multisig": ("locking", ["op_n", "key", "op_n", op.op_checkmultisig], []),
    "p2pk": ("locking", ["key", op.op_checksig], []),
    "nulldata": ("locking", [op.op_return, "data"], [0]),
    "nulldata_1": ("locking", [op.op_return, op.op_0], []),
    "nulldata_2": ("locking", [op.op_return], []),
    "sig_pubkey": ("unlocking", ["signature", "key"], []),
    # 'p2sh_multisig': ('unlocking', [op.op_0, 'signature', 'op_n', 'key', 'op_n', op.op_checkmultisig], []),
    "p2sh_multisig": ("unlocking", [op.op_0, "signature", "redeemscript"], []),
    "p2sh_multisig_2?": (
        "unlocking",
        [op.op_0, "signature", op.op_verify, "redeemscript"],
        [],
    ),
    "p2sh_multisig_3?": (
        "unlocking",
        [op.op_0, "signature", op.op_1add, "redeemscript"],
        [],
    ),
    "signature": ("unlocking", ["signature"], []),
    "signature_multisig": ("unlocking", [op.op_0, "signature"], []),
    "locktime_cltv": (
        "unlocking",
        ["locktime_cltv", op.op_checklocktimeverify, op.op_drop],
        [],
    ),
}


class ScriptError(FluxWalletError):
    """Handle Script class Exceptions."""

    def __init__(self, msg: str = "") -> None:
        _logger.error(msg)
        super().__init__(msg)


def _get_script_types(blueprint: list[int | str]) -> list[str]:
    # Convert blueprint to more generic format
    bp: list[int | str] = []
    for item in blueprint:
        if isinstance(item, str) and item[:4] == "data":
            bp.append("data")
        elif isinstance(item, int) and op.op_1 <= item <= op.op_16:
            bp.append("op_n")
        elif item == "key" and len(bp) and bp[-1] == "key":
            bp[-1] = "key"
        elif item == "signature" and len(bp) and bp[-1] == "signature":
            bp[-1] = "signature"
        else:
            bp.append(item)

    script_types: list[str] = [key for key, values in SCRIPT_TYPES.items() if values[1] == bp]
    if script_types:
        return script_types

    bp_len: list[int] = [int(c.split("-")[1]) for c in blueprint if isinstance(c, str) and c[:4] == "data"]
    script_types = []
    while len(bp):
        # Find all possible matches with blueprint
        matches: list[tuple[str, int, list[int]]] = [
            (key, len(values[1]), values[2])
            for key, values in SCRIPT_TYPES.items()
            if values[1] == bp[: len(values[1])]
        ]
        if not matches:
            script_types.append("unknown")
            break

        # Select match with correct data length if more than 1 match is found
        match_id: int = 0
        for match in matches:
            data_lens: list[int] = match[2]
            for i, data_len in enumerate(data_lens):
                bl: int = bp_len[i]
                if data_len == bl or data_len == 0:
                    match_id = matches.index(match)
                    break

        # Add script type to list
        script_type: str = matches[match_id][0]
        if script_type == "multisig" and script_types[-1:] == ["signature_multisig"]:
            script_types.pop()
            script_type = "p2sh_multisig"
        script_types.append(script_type)
        bp = bp[matches[match_id][1] :]

    return script_types


def data_pack(data: bytes) -> bytes:
    """Add data length prefix to data string to include data in a script.

    :param data: Data to be packed
    :type data: bytes
    :return bytes:
    """
    if len(data) <= 75:
        return len(data).to_bytes(1, "big") + data
    if 75 < len(data) <= 255:
        return b"L" + len(data).to_bytes(1, "little") + data
    return b"M" + len(data).to_bytes(2, "little") + data


def get_data_type(data: bytes | Key | Signature) -> str:
    """Get type of data in script. Recognises signatures, keys, hashes or sequence data. Return 'other' if data is not
    recognised.

    :param data: Data part of script
    :type data: bytes
    :return str:
    """
    if isinstance(data, Key):
        return "key_object"
    if isinstance(data, Signature):
        return "signature_object"
    if data.startswith(b"\x30") and 69 <= len(data) <= 74:
        return "signature"
    if ((data.startswith(b"\x02") or data.startswith(b"\x03")) and len(data) == 33) or (
        data.startswith(b"\x04") and len(data) == 65
    ):
        return "key"
    if len(data) == 20 or len(data) == 32 or 1 < len(data) <= 4:
        return f"data-{len(data)}"
    return "other"


class Script:
    def __init__(
        self,
        commands: list[int | bytes] | None = None,
        message: bytes | None = None,
        script_types: list[str] | str = "",
        is_locking: bool = True,
        keys: list[Key | HDKey | bytes] | None = None,
        signatures: list[Signature | bytes] | None = None,
        blueprint: list[int | str] | None = None,
        tx_data: dict[str, bytes | int] | None = None,
        public_hash: bytes = b"",
        sigs_required: int | None = None,
        redeemscript: bytes = b"",
        hash_type: int | None = SIGHASH_ALL,
    ) -> None:
        """Create a Script object with specified parameters. Use parse() method to create a Script from raw hex.

        >>> s = Script([op.op_2, op.op_4, op.op_add])
        >>> s
        <Script([op.op_2, op.op_4, op.op_add])>
        >>> s.blueprint
        [82, 84, 147]
        >>> s.evaluate()
        True

        Stack is empty now, because evaluate pops last item from stack and check if is non-zero
        >>> s.stack
        []

        :param commands: List of script language commands
        :type commands: list
        :param message: Signed message to verify, normally a transaction hash. Used to validate script
        :type message: bytes
        :param script_types: List of script_types as defined in SCRIPT_TYPES
        :type script_types: list of str
        :param is_locking: Is this a locking script (Output), otherwise unlocking (Input)
        :type is_locking: bool
        :param keys: Provide list of keys to create script
        :type keys: list of Key
        :param signatures: Provide list of signatures to create script
        :type signatures: list of Signature
        :param blueprint: Simplified version of script, normally generated by Script object
        :type blueprint: list of str
        :param tx_data: Dictionary with extra information needed to verify script. Such as 'redeemscript' for
            multisignature scripts and 'blockcount' for time locked scripts
        :type tx_data: dict
        :param public_hash: Public hash of key or redeemscript used to create scripts
        :type public_hash: bytes
        :param sigs_required: Nubmer of signatures required to create multisig script
        :type sigs_required: int
        :param redeemscript: Provide redeemscript to create a new (multisig) script
        :type redeemscript: bytes
        :param hash_type: Specific script hash type, default is SIGHASH_ALL
        :type hash_type: int
        """
        self.commands: list[int | bytes] = list(commands) if commands else []
        self._raw: bytes = b""
        self.stack: list[bytes] | Stack = []
        self.message: bytes | None = message
        self.script_types: list[str] = (
            script_types if isinstance(script_types, list) else ([script_types] if script_types else [])
        )
        self.is_locking: bool | None = is_locking
        self.keys: list[Key | bytes] = keys if keys else []
        self.signatures: list[Signature | bytes] = signatures if signatures else []
        self._blueprint: list[int | str] = blueprint if blueprint else []
        self.tx_data: dict[str, bytes | int] = tx_data if tx_data else {}
        self.sigs_required: int = sigs_required if sigs_required else len(self.keys) if len(self.keys) else 1
        self.redeemscript: bytes = redeemscript
        self.public_hash: bytes = public_hash
        self.hash_type: int | None = hash_type

        if not self.commands and self.script_types and (self.keys or self.signatures or self.public_hash):
            for st in self.script_types:
                st_values: tuple[str, list[int | str], list[int]] = SCRIPT_TYPES[st]
                script_template: list[int | str] = st_values[1]
                self.is_locking = st_values[0] == "locking"
                sig_n_and_m: list[int] = [len(self.keys), self.sigs_required]
                for tc in script_template:
                    command: list[int | bytes] = [tc] if isinstance(tc, int) else []
                    if tc == "data":
                        command = [self.public_hash] if self.public_hash else []
                    elif tc == "signature":
                        command = [bytes(s) if not isinstance(s, bytes) else s for s in self.signatures]
                    elif tc == "key":
                        # BIP67: sort keys lexicographically for deterministic multisig scripts
                        # BIP67: sort by compressed public key bytes for deterministic multisig
                        sorted_keys = (
                            sorted(
                                self.keys,
                                key=lambda k: k.public_byte if hasattr(k, "public_byte") else k,
                            )
                            if st == "multisig"
                            else self.keys
                        )
                        command = [bytes(k) if not isinstance(k, (int, bytes)) else k for k in sorted_keys]
                    elif tc == "op_n":
                        command = [sig_n_and_m.pop() + 80]
                    elif tc == "redeemscript":
                        command = [self.redeemscript]
                    if not command or command == [b""]:
                        raise ScriptError(
                            "Cannot create script, please supply %s" % (tc if tc != "data" else "public key hash")
                        )
                    self.commands += command
        if not (self.keys and self.signatures and self.blueprint):
            self._blueprint = []
            for c in self.commands:
                if isinstance(c, int):
                    self._blueprint.append(c)
                else:
                    data_type: str = get_data_type(c)
                    if data_type in [
                        "key",
                        "signature",
                        "key_object",
                        "signature_object",
                    ]:
                        if data_type == "key_object":
                            data_type = "key"
                        elif data_type == "signature_object":
                            data_type = "signature"
                        self._blueprint.append(data_type)
                    else:
                        self._blueprint.append(f"data-{len(c)}")

    @classmethod
    def parse(
        cls,
        script: BytesIO | bytes | str,
        message: bytes | None = None,
        tx_data: dict[str, bytes | int] | None = None,
        strict: bool = True,
        _level: int = 0,
    ) -> Script:
        """Parse raw script and return Script object. Extracts script commands, keys, signatures and other data.

        Wrapper for the :func:`parse_bytesio` method. Convert hexadecimal string or bytes script to BytesIO.

        >>> Script.parse('76a914af8e14a2cecd715c363b3a72b55b59a31e2acac988ac')
        <Script([op.op_dup, op.op_hash160, data-20, op.op_equalverify, op.op_checksig])>

        :param script: Raw script to parse in bytes, BytesIO or hexadecimal string format
        :type script: BytesIO, bytes, str
        :param message: Signed message to verify, normally a transaction hash
        :type message: bytes
        :param tx_data: Dictionary with extra information needed to verify script. Such as 'redeemscript' for
            multisignature scripts and 'blockcount' for time locked scripts
        :type tx_data: dict
        :param strict: Raise exception when script is malformed, incomplete or not understood. Default is True
        :type strict: bool
        :param _level: Internal argument used to avoid recursive depth
        :type _level: int

        :return Script:
        """
        if isinstance(script, bytes):
            script = BytesIO(script)
        elif isinstance(script, str):
            script = BytesIO(bytes.fromhex(script))
        return cls.parse_bytesio(script, message, tx_data, strict, _level)

    @classmethod
    def parse_bytesio(
        cls,
        script: BytesIO,
        message: bytes | None = None,
        tx_data: dict[str, bytes | int] | None = None,
        strict: bool = True,
        _level: int = 0,
    ) -> Script:
        """Parse raw script and return Script object. Extracts script commands, keys, signatures and other data.

        :param script: Raw script to parse in bytes, BytesIO or hexadecimal string format
        :type script: BytesIO
        :param message: Signed message to verify, normally a transaction hash
        :type message: bytes
        :param tx_data: Dictionary with extra information needed to verify script. Such as 'redeemscript' for
            multisignature scripts and 'blockcount' for time locked scripts
        :type tx_data: dict
        :param strict: Raise exception when script is malformed, incomplete or not understood. Default is True
        :type strict: bool
        :param _level: Internal argument used to avoid recursive depth
        :type _level: int
        :return Script:
        """
        commands: list[int | bytes] = []
        signatures: list[Signature | bytes] = []
        keys: list[Key | bytes] = []
        blueprint: list[int | str] = []
        redeemscript: bytes = b""
        sigs_required: int | None = None
        # hash_type = SIGHASH_ALL  # todo: check
        hash_type: int | None = None
        if not tx_data:
            tx_data = {}

        while script:
            chb: bytes = script.read(1)
            if not chb:
                break
            ch: int = int.from_bytes(chb, "big")
            data: bytes | None = None
            data_length: int = 0
            if 1 <= ch <= 75:  # Data`
                data_length = ch
            elif ch == op.op_pushdata1:
                data_length = int.from_bytes(script.read(1), "little")
            elif ch == op.op_pushdata2:
                data_length = int.from_bytes(script.read(2), "little")
            if data_length:
                data = script.read(data_length)
                if len(data) != data_length:
                    msg: str = "Malformed script, not enough data found"
                    if strict:
                        raise ScriptError(msg)
                    _logger.warning(msg)

            if data:
                data_type: str = get_data_type(data)
                commands.append(data)
                if data_type == "signature":
                    try:
                        sig: Signature = Signature.parse_bytes(data)
                        signatures.append(sig)
                        hash_type = sig.hash_type
                        blueprint.append("signature")
                    except (ValueError, ScriptError) as e:
                        if strict:
                            raise ScriptError(str(e)) from e
                        _logger.warning(str(e))
                elif data_type == "signature_object" and isinstance(data, Signature):
                    signatures.append(data)
                    hash_type = data.hash_type
                    blueprint.append("signature")
                elif data_type == "key":
                    keys.append(Key(data))
                    blueprint.append("key")
                elif data_type == "key_object":
                    keys.append(data)
                    blueprint.append("key")
                elif (
                    data_type.startswith("data")
                    or (len(commands) >= 2 and commands[-2] == op.op_return)
                    or _level >= 1
                ):
                    blueprint.append(f"data-{len(data)}")
                else:
                    try:
                        s2: Script = Script.parse_bytes(data, _level=_level + 1, strict=strict)
                        commands.pop()
                        commands += s2.commands
                        blueprint += s2.blueprint
                        keys += s2.keys
                        signatures += s2.signatures
                        redeemscript = s2.redeemscript
                        sigs_required = s2.sigs_required
                    except (ScriptError, IndexError):
                        blueprint.append(f"data-{len(data)}")
            else:  # Other opcode
                commands.append(ch)
                blueprint.append(ch)

        s: Script = cls(
            commands,
            message,
            keys=keys,
            signatures=signatures,
            blueprint=blueprint,
            tx_data=tx_data,
            hash_type=hash_type,
        )
        script.seek(0)
        s._raw = script.read()

        s.script_types = _get_script_types(blueprint)
        if "unknown" in s.script_types:
            s.script_types = ["unknown"]

        # Extract extra information from script data
        for st in s.script_types[:1]:
            if st == "multisig":
                s.redeemscript = s.raw
                s.sigs_required = int(s.commands[0]) - 80
                if s.sigs_required > len(keys):
                    raise ScriptError(
                        f"Number of signatures required ({s.sigs_required}) is higher then number of keys ({len(keys)})"
                    )
                if len(keys) > 15:
                    raise ScriptError(f"Number of keys ({len(keys)}) exceeds maximum of 15 for OP_CHECKMULTISIG")
                if len(s.keys) != int(s.commands[-2]) - 80:
                    raise ScriptError(f"{len(s.keys)} keys found but {int(s.commands[-2]) - 80} keys expected")
            elif st in ["p2sh"] and len(s.commands) > 1:
                cmd1 = s.commands[1]
                if isinstance(cmd1, bytes):
                    s.public_hash = cmd1
            elif st == "p2pkh" and len(s.commands) > 2:
                cmd2 = s.commands[2]
                if isinstance(cmd2, bytes):
                    s.public_hash = cmd2
        s.redeemscript = redeemscript if redeemscript else s.redeemscript
        if s.redeemscript and "redeemscript" not in s.tx_data:
            s.tx_data["redeemscript"] = s.redeemscript

        s.sigs_required = sigs_required if sigs_required else s.sigs_required

        return s

    @classmethod
    def parse_hex(
        cls,
        script: str,
        message: bytes | None = None,
        tx_data: dict[str, bytes | int] | None = None,
        strict: bool = True,
        _level: int = 0,
    ) -> Script:
        """Parse raw script and return Script object. Extracts script commands, keys, signatures and other data.

        Wrapper for the :func:`parse_bytesio` method. Convert hexadecimal string script to BytesIO.

        >>> Script.parse_hex('76a914af8e14a2cecd715c363b3a72b55b59a31e2acac988ac')
        <Script([op.op_dup, op.op_hash160, data-20, op.op_equalverify, op.op_checksig])>

        :param script: Raw script to parse in hexadecimal string format
        :type script: str
        :param message: Signed message to verify, normally a transaction hash
        :type message: bytes
        :param tx_data: Dictionary with extra information needed to verify script. Such as 'redeemscript' for
            multisignature scripts and 'blockcount' for time locked scripts
        :type tx_data: dict
        :param strict: Raise exception when script is malformed, incomplete or not understood. Default is True
        :type strict: bool
        :param _level: Internal argument used to avoid recursive depth
        :type _level: int

        :return Script:
        """
        return cls.parse_bytesio(BytesIO(bytes.fromhex(script)), message, tx_data, strict, _level)

    @classmethod
    def parse_bytes(
        cls,
        script: bytes,
        message: bytes | None = None,
        tx_data: dict[str, bytes | int] | None = None,
        strict: bool = True,
        _level: int = 0,
    ) -> Script:
        """Parse raw script and return Script object. Extracts script commands, keys, signatures and other data.

        Wrapper for the :func:`parse_bytesio` method. Convert bytes script to BytesIO.

        :param script: Raw script to parse in bytes format
        :type script: bytes
        :param message: Signed message to verify, normally a transaction hash
        :type message: bytes
        :param tx_data: Dictionary with extra information needed to verify script. Such as 'redeemscript' for
            multisignature scripts and 'blockcount' for time locked scripts
        :type tx_data: dict
        :param strict: Raise exception when script is malformed or incomplete
        :type strict: bool
        :param _level: Internal argument used to avoid recursive depth
        :type _level: int

        :return Script:
        """
        return cls.parse_bytesio(BytesIO(script), message, tx_data, strict, _level)

    def __repr__(self) -> str:
        s_items: list[str] = []
        for command in self.blueprint:
            if isinstance(command, int):
                s_items.append("op." + opcodenames.get(command, f"unknown-op-{command}").lower())
            else:
                s_items.append(command)
        return "<Script([" + ", ".join(s_items) + "])>"

    def __str__(self) -> str:
        s_items: list[str] = []
        for command in self.blueprint:
            if isinstance(command, int):
                s_items.append(opcodenames.get(command, f"unknown-op-{command}"))
            else:
                s_items.append(command)
        return " ".join(s_items)

    def __add__(self, other: Script) -> Script:
        self.commands += other.commands
        self._raw += other.raw
        if other.message and not self.message:
            self.message = other.message
        self.is_locking = None
        self.keys += other.keys
        self.signatures += other.signatures
        self._blueprint += other._blueprint
        self.script_types = _get_script_types(self._blueprint)
        if other.tx_data and not self.tx_data:
            self.tx_data = other.tx_data
        if other.redeemscript and not self.redeemscript:
            self.redeemscript = other.redeemscript
        return self

    def __bool__(self) -> bool:
        return bool(self.commands)

    def __hash__(self) -> int:
        return hash(hash160(self.raw))

    @property
    def blueprint(self) -> list[int | str]:
        return self._blueprint

    @property
    def raw(self) -> bytes:
        if not self._raw:
            self._raw = self.serialize()
        return self._raw

    def serialize(self) -> bytes:
        """Serialize script. Return all commands and data as bytes.

        >>> s = Script.parse_hex('76a914af8e14a2cecd715c363b3a72b55b59a31e2acac988ac')
        >>> s.serialize().hex()
        '76a914af8e14a2cecd715c363b3a72b55b59a31e2acac988ac'

        :return bytes:
        """
        raw: bytes = b""
        for cmd in self.commands:
            if isinstance(cmd, int):
                raw += bytes([cmd])
            else:
                raw += data_pack(cmd)
        self._raw = raw
        return raw

    def serialize_list(self) -> list[bytes]:
        """Serialize script and return commands and data as list.

        >>> s = Script.parse_hex('76a9')
        >>> s.serialize_list()
        [b'v', b'\\xa9']

        :return list of bytes:
        """
        clist: list[bytes] = []
        for cmd in self.commands:
            if isinstance(cmd, int):
                clist.append(bytes([cmd]))
            else:
                clist.append(bytes(cmd))
        return clist

    def evaluate(
        self,
        message: bytes | None = None,
        tx_data: dict[str, bytes | int] | None = None,
    ) -> bool:
        """Evaluate script, run all commands and check if it is valid.

        >>> s = Script([op.op_2, op.op_4, op.op_add])
        >>> s
        <Script([op.op_2, op.op_4, op.op_add])>
        >>> s.blueprint
        [82, 84, 147]
        >>> s.evaluate()
        True

        >>> lock_script = bytes.fromhex('76a914f9cc73824051cc82d64a716c836c54467a21e22c88ac')
        >>> unlock_script = bytes.fromhex(
        ...     '483045022100ba2ec7c40257b3d22864c9558738eea4d8771ab97888368124e176fdd6d7cd86'
        ...     '02200f47c8d0c437df1ea8f9819d344e05b9c93e38e88df1fc46abb6194506c50ce1'
        ...     '012103e481f20561573cfd800e64efda61405917cb29e4bd20bed168c52b674937f535'
        ... )
        >>> s = Script.parse_bytes(unlock_script + lock_script)
        >>> transaction_hash = bytes.fromhex('12824db63e7856d00ee5e109fd1c26ac8a6a015858c26f4b336274f6b52da1c3')
        >>> s.evaluate(message=transaction_hash)
        True

        :param message: Signed message to verify, normally a transaction hash. Leave empty to use
            Script.message. If supplied Script.message will be ignored.
        :type message: bytes
        :param tx_data: Dictionary with extra information needed to verify script. Such as 'redeemscript' for
            multisignature scripts and 'blockcount' for time locked scripts. Leave emtpy to use Script.tx_data.
            If supplied Script.tx_data will be ignored

        :return bool: Valid or not valid
        """
        self.message = self.message if message is None else message
        self.tx_data = self.tx_data if tx_data is None else tx_data
        self.stack = Stack()

        commands: list[int | bytes] = self.commands[:]
        while len(commands):
            command: int | bytes = commands.pop(0)
            if isinstance(command, int):
                if command == op.op_0:  # OP_0
                    self.stack.append(encode_num(0))
                elif command == op.op_1negate:  # OP_1NEGATE
                    self.stack.append(encode_num(-1))
                elif op.op_1 <= command <= op.op_16:  # OP_1 to OP_16
                    self.stack.append(encode_num(command - 80))
                elif command == op.op_if or command == op.op_notif:
                    method_name: str = opcodenames[command].lower()
                    method = getattr(self.stack, method_name)
                    if not method(commands):
                        return False
                else:
                    method_name = opcodenames[command].lower()
                    if method_name not in dir(self.stack):
                        raise ScriptError(f"Method {method_name} not found")
                    try:
                        method = getattr(self.stack, method_name)
                        if method_name == "op_checksig" or method_name == "op_checksigverify":
                            res: bool | None = method(self.message)
                        elif method_name == "op_checkmultisig" or method_name == "op_checkmultisigverify":
                            res = method(self.message, self.tx_data)
                        elif method_name == "op_checklocktimeverify":
                            seq = self.tx_data["sequence"]
                            lt = self.tx_data.get("locktime")
                            res = self.stack.op_checklocktimeverify(int(seq), int(lt) if lt is not None else None)
                        elif method_name == "op_checksequenceverify":
                            seq = self.tx_data["sequence"]
                            ver = self.tx_data["version"]
                            res = self.stack.op_checksequenceverify(int(seq), int(ver))
                        else:
                            res = method()
                        if res is False:
                            return False
                    except (ValueError, IndexError, KeyError, ScriptError) as e:
                        _logger.warning(f"Stack evaluate error: {e}")
                        return False
            else:
                self.stack.append(command)

        if len(self.stack) == 0:
            return False
        return self.stack.pop() != b""


class Stack(list):
    """The Stack object is a child of the Python list object with extra operational (OP) methods. The operations as used
    in the Script language can be used to manipulate the stack / list.

    For documentation of the op-methods you could check
    https://en.bitcoin.it/wiki/Script
    """

    @classmethod
    def from_ints(cls, list_ints: Sequence[int]) -> Stack:
        """Create a Stack item with a list of integers.

        >>> Stack.from_ints([1, 2])
        [b'\\x01', b'\\x02']

        :param list_ints:
        :return:
        """
        return Stack([encode_num(n) for n in list_ints])

    def __add__(self, other: list[bytes]) -> Stack:
        return Stack(list.__add__(self, other))

    def __iadd__(self, other: Iterable[bytes]) -> Stack:
        list.__iadd__(self, other)
        return self

    def as_ints(self) -> Stack:
        """Return the Stack as list of integers, skipping items larger than 4 bytes (hashes, pubkeys).

        Script numbers are limited to 4 bytes per BIP62. Larger items are data pushes
        (hashes, public keys) that cannot be meaningfully decoded as integers.

        >>> st = Stack.from_ints([1, 2])
        >>> st.as_ints()
        [1, 2]

        :return list of int:
        """
        return Stack([decode_num(x) for x in self if len(x) <= 4])

    def pop_as_number(self) -> int:
        """Pop the latest item from the list and decode as number.

        >>> st = Stack.from_ints([1, 2])
        >>> st.pop_as_number()
        2

        :return int:
        """
        return decode_num(self.pop())

    def is_arithmetic(self, items: int = 1) -> bool:
        """Check if top stack item is or last stock are arithmetic and has no more than 4 bytes.

        :return bool:
        """
        if len(self) < items:
            raise IndexError(f"Not enough items in list to run operation. Items {len(self)}, expected {items}")
        return all(len(i) <= 4 for i in self[-items:])

    # def op_ver()  # unused

    def op_if(self, commands: list[int | bytes]) -> bool:
        true_items: list[int | bytes] = []
        false_items: list[int | bytes] = []
        current_array: list[int | bytes] = true_items
        found: bool = False
        num_endifs_needed: int = 1
        while len(commands) > 0:
            item: int | bytes = commands.pop(0)
            if item in (99, 100):
                # nested if, we have to go another endif
                num_endifs_needed += 1
                current_array.append(item)
            elif num_endifs_needed == 1 and item == 103:
                current_array = false_items
            elif item == 104:
                if num_endifs_needed == 1:
                    found = True
                    break
                num_endifs_needed -= 1
                current_array.append(item)
            else:
                current_array.append(item)
        if not found:
            return False
        element: bytes = self.pop()
        if decode_num(element) == 0:
            commands[:0] = false_items
        else:
            commands[:0] = true_items
        return True

    def op_notif(self, commands: list[int | bytes]) -> bool:
        element: bytes = self.pop()
        if decode_num(element) == 0:
            self.append(b"\1")
        else:
            self.append(b"\0")
        return self.op_if(commands)

    def op_nop(self) -> bool:
        return True

    def op_verify(self) -> bool:
        return self.pop() != b""

    @staticmethod
    def op_return() -> bool:
        return False

    def op_2drop(self) -> bool:
        self.pop()
        self.pop()
        return True

    def op_2dup(self) -> bool:
        if len(self) < 2:
            raise ValueError("Stack op_2dup method requires minimum of 2 stack items")
        self.extend(self[-2:])
        return True

    def op_3dup(self) -> bool:
        if len(self) < 3:
            raise ValueError("Stack op_3dup method requires minimum of 3 stack items")
        self.extend(self[-3:])
        return True

    def op_2over(self) -> bool:
        if len(self) < 4:
            raise ValueError("Stack op_2over method requires minimum of 4 stack items")
        self.extend(self[-4:-2])
        return True

    def op_2rot(self) -> bool:
        self.extend([self.pop(-6), self.pop(-5)])
        return True

    def op_2swap(self) -> bool:
        self[-2:-2] = [self.pop(), self.pop()]
        return True

    def op_ifdup(self) -> bool:
        if not len(self):
            raise ValueError("Stack op_ifdup method requires minimum of 1 stack item")
        if self[-1] != b"":
            self.append(self[-1])
        return True

    def op_depth(self) -> bool:
        self.append(encode_num(len(self)))
        return True

    def op_drop(self) -> bool:
        self.pop()
        return True

    def op_dup(self) -> bool:
        if not len(self):
            return False
        self.append(self[-1])
        return True

    def op_nip(self) -> bool:
        self.pop(-2)
        return True

    def op_over(self) -> bool:
        if len(self) < 2:
            raise ValueError("Stack op_over method requires minimum of 2 stack items")
        self.append(self[-2])
        return True

    def op_pick(self) -> bool:
        self.append(self[-self.pop_as_number()])
        return True

    def op_roll(self) -> bool:
        self.append(self.pop(-self.pop_as_number()))
        return True

    def op_rot(self) -> bool:
        self.append(self.pop(-3))
        return True

    def op_swap(self) -> bool:
        self.append(self.pop(-2))
        return True

    def op_tuck(self) -> bool:
        self.append(self[-2])
        return True

    def op_size(self) -> bool:
        self.append(encode_num(len(self[-1])))
        return True

    def op_equal(self) -> bool:
        self.append(b"\x01" if self.pop() == self.pop() else b"")
        return True

    def op_equalverify(self) -> bool:
        self.op_equal()
        return self.op_verify()

    # # 'op_reserved1': unused
    # # 'op_reserved2': unused

    def op_1add(self) -> bool:
        if not self.is_arithmetic():
            return False
        self.append(encode_num(self.pop_as_number() + 1))
        return True

    def op_1sub(self) -> bool:
        if not self.is_arithmetic():
            return False
        self.append(encode_num(self.pop_as_number() - 1))
        return True

    def op_negate(self) -> bool:
        if not self.is_arithmetic():
            return False
        self.append(encode_num(-self.pop_as_number()))
        return True

    def op_abs(self) -> bool:
        if not self.is_arithmetic():
            return False
        self.append(encode_num(abs(self.pop_as_number())))
        return True

    def op_not(self) -> bool:
        if not self.is_arithmetic():
            return False
        self.append(b"\1" if self.pop() == b"" else b"")
        return True

    def op_0notequal(self) -> bool:
        if not self.is_arithmetic():
            return False
        self.append(b"" if self.pop() == b"" else b"\1")
        return True

    def op_add(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        self.append(encode_num(self.pop_as_number() + self.pop_as_number()))
        return True

    def op_sub(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        b: int = self.pop_as_number()
        a: int = self.pop_as_number()
        self.append(encode_num(a - b))
        return True

    def op_booland(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        a: bytes = self.pop()
        b: bytes = self.pop()
        if a != b"" and b != b"":
            self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_boolor(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        a: bytes = self.pop()
        b: bytes = self.pop()
        if a != b"" or b != b"":
            self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_numequal(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        if self.pop() == self.pop():
            self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_numequalverify(self) -> bool:
        self.op_numequal()
        return self.op_verify()

    def op_numnotequal(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        if self.pop() != self.pop():
            self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_numlessthan(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        b: int = self.pop_as_number()
        a: int = self.pop_as_number()
        self.append(b"\1" if a < b else b"")
        return True

    def op_numgreaterthan(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        b: int = self.pop_as_number()
        a: int = self.pop_as_number()
        self.append(b"\1" if a > b else b"")
        return True

    def op_numlessthanorequal(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        b: int = self.pop_as_number()
        a: int = self.pop_as_number()
        self.append(b"\1" if a <= b else b"")
        return True

    def op_numgreaterthanorequal(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        b: int = self.pop_as_number()
        a: int = self.pop_as_number()
        self.append(b"\1" if a >= b else b"")
        return True

    def op_min(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        a: int = self.pop_as_number()
        b: int = self.pop_as_number()
        self.append(encode_num(a) if a < b else encode_num(b))
        return True

    def op_max(self) -> bool:
        if not self.is_arithmetic(2):
            return False
        a: int = self.pop_as_number()
        b: int = self.pop_as_number()
        self.append(encode_num(a) if a > b else encode_num(b))
        return True

    def op_within(self) -> bool:
        if not self.is_arithmetic(3):
            return False
        x: int = self.pop_as_number()
        vmin: int = self.pop_as_number()
        vmax: int = self.pop_as_number()
        if vmin <= x < vmax:
            self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_ripemd160(self) -> bool:
        # self.append(hashlib.new('ripemd160', self.pop()).digest())
        self.append(ripemd160(self.pop()))
        return True

    def op_sha1(self) -> bool:
        self.append(hashlib.sha1(self.pop()).digest())
        return True

    def op_sha256(self) -> bool:
        self.append(hashlib.sha256(self.pop()).digest())
        return True

    def op_hash160(self) -> bool:
        self.append(hash160(self.pop()))
        return True

    def op_hash256(self) -> bool:
        self.op_sha256()
        self.op_sha256()
        return True

    def op_checksig(self, message: bytes | None, _: dict[str, bytes | int] | None = None) -> bool:
        public_key: bytes = self.pop()
        signature: bytes = self.pop()
        signature: Signature = Signature.parse_bytes(signature, public_key=public_key)
        if signature.verify(message, public_key):
            self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_checksigverify(self, message: bytes | None, _: dict[str, bytes | int] | None = None) -> bool:
        return self.op_checksig(message, None) and self.op_verify()

    def op_checkmultisig(self, message: bytes | None, data: dict[str, bytes | int] | None = None) -> bool:
        n: int = decode_num(self.pop())
        pubkeys: list[bytes] = []
        for _ in range(n):
            pubkeys.append(self.pop())
        m: int = decode_num(self.pop())
        signatures: list[bytes] = []
        for _ in range(m):
            signatures.append(self.pop())
        if len(self):
            # OP_CHECKMULTISIG bug
            self.pop()
        sigcount: int = 0
        for pubkey in pubkeys:
            s: Signature = Signature.parse_bytes(signatures[sigcount])
            if s.verify(message, pubkey):
                sigcount += 1
                if sigcount >= len(signatures):
                    break

        if sigcount == len(signatures):
            if data and "redeemscript" in data:
                self.append(data["redeemscript"])
            else:
                self.append(b"\1")
        else:
            self.append(b"")
        return True

    def op_checkmultisigverify(self, message: bytes | None, data: dict[str, bytes | int] | None = None) -> bool:
        return self.op_checkmultisig(message, data) and self.op_verify()

    def op_nop1(self) -> bool:
        return True

    def op_checklocktimeverify(self, sequence: int, tx_locktime: int | None) -> bool:
        """Implements CHECKLOCKTIMEVERIFY opcode (CLTV) as defined in BIP65.

        CLTV is an absolute timelock and is added to an output locking script. It locks an output until a certain time
        or block.

        :param sequence: Sequence value from the transaction. Must be 0xffffffff to be valid
        :type sequence: int
        :param tx_locktime: The nLocktime value from the transaction in blocks or as Median Time Past timestamp
        :type tx_locktime: int
        :return bool:
        """
        if not tx_locktime:
            return False
        if sequence == 0xFFFFFFFF:
            return False
        locktime: int = decode_num(self[-1])
        if locktime < 0:
            return False
        if locktime < 50000000 < tx_locktime or locktime > 50000000 > tx_locktime:
            return False
        return not tx_locktime < locktime

    def op_checksequenceverify(self, sequence: int, version: int) -> bool:
        """OP_CHECKSEQUENCEVERIFY is not supported on the Flux network.

        Flux never activated BIP112 — OP_NOP3 remains a no-op in fluxd.

        :param sequence: Sequence value from the transaction
        :type sequence: int
        :param version: Transaction version
        :type version: int
        :return bool:
        """
        raise ScriptError("OP_CHECKSEQUENCEVERIFY is not supported on the Flux network")

    def op_nop4(self) -> bool:
        return True

    def op_nop5(self) -> bool:
        return True

    def op_nop6(self) -> bool:
        return True

    def op_nop7(self) -> bool:
        return True

    def op_nop8(self) -> bool:
        return True

    def op_nop9(self) -> bool:
        return True

    def op_nop10(self) -> bool:
        return True

    # # 'op_invalidopcode':


def encode_num(num: int) -> bytes:
    """Encode number as byte used in Script language. Bitcoin specific little endian format with sign for negative
    integers.

    >>> encode_num(0)
    b''
    >>> encode_num(1)
    b'\\x01'
    >>> encode_num(1000)
    b'\\xe8\\x03'
    >>> encode_num(1000000)
    b'@B\\x0f'

    :param num: number to represent
    :type num: int

    :return bytes:
    """
    if num == 0:
        return b""
    abs_num: int = abs(num)
    negative: bool = num < 0
    length: int = (num.bit_length() + 7) // 8
    encoded: bytes = abs_num.to_bytes(length, byteorder="little")
    if encoded[-1] & 0x80:
        if negative:
            encoded += b"\x80"
        else:
            encoded += b"\0"
    elif negative:
        encoded = encoded[:-1] + (encoded[-1] + 0x80).to_bytes(1, "big")
    return encoded


def decode_num(encoded: bytes) -> int:
    """Decode byte representation of number used in Script language to integer.

    >>> decode_num(b'')
    0
    >>> decode_num(b'@B\\x0f')
    1000000

    :param encoded: Number to decode
    :type encoded: bytes

    :return int:
    """
    if encoded == b"":
        return 0
    negative: bool = False
    if encoded[-1] & 0x80:
        negative = True
    element: bytes = encoded[:-1] + (encoded[-1] & 0x7F).to_bytes(1, "big")
    num: int = int.from_bytes(element, "little")
    if negative:
        return -num
    return num
