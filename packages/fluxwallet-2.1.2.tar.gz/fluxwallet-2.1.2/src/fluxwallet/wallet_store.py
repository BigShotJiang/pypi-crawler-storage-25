"""In-memory wallet data store with encrypted flat-file persistence.

Replaces SQLAlchemy ORM — all wallet data lives in memory as dataclasses, serialized to an encrypted msgpack file on
disk.
"""

from __future__ import annotations

import re
import secrets
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

from fluxwallet.secure_mem import secure_wipe
from fluxwallet.wallet_file import load_wallet, save_wallet

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class StoredKey:
    id: int
    wallet_id: int
    parent_id: int | None = None
    name: str = ""
    account_id: int = 0
    depth: int = 0
    change: int = 0
    address_index: int = 0
    public: bytes | None = None
    private: bytes | None = None
    wif: str | None = None
    compressed: bool = True
    key_type: str = "bip32"
    address: str = ""
    cosigner_id: int | None = None
    encoding: str = "base58"
    purpose: int = 44
    is_private: bool = False
    path: str = ""
    network_name: str = ""
    balance: int = 0
    used: bool = False
    latest_txid: bytes | None = None
    latest_tx_index: int | None = None
    redeem_script: bytes | None = None
    multisig_children: list[tuple[int, int]] = field(default_factory=list)


@dataclass
class StoredTxInput:
    index_n: int
    key_id: int | None = None
    address: str = ""
    witnesses: bytes | None = None
    witness_type: str = "legacy"
    prev_txid: bytes | None = None
    output_n: int = 0
    script: bytes | None = None
    script_type: str = "sig_pubkey"
    sequence: int = 0
    value: int = 0
    double_spend: bool = False


@dataclass
class StoredTxOutput:
    output_n: int
    key_id: int | None = None
    address: str = ""
    script: bytes | None = None
    script_type: str = "p2pkh"
    value: int = 0
    spent: bool = False
    spending_txid: bytes | None = None
    spending_index_n: int | None = None
    locked_until: datetime | None = None


@dataclass
class StoredTransaction:
    id: int
    wallet_id: int
    txid: bytes = b""
    account_id: int = 0
    witness_type: str = "legacy"
    version: int = 1
    locktime: int = 0
    date: datetime = field(default_factory=lambda: datetime.now(UTC))
    coinbase: bool = False
    expiry_height: int = 0
    confirmations: int = 0
    block_height: int | None = None
    size: int = 0
    fee: int = 0
    status: str = "new"
    is_complete: bool = True
    input_total: int = 0
    output_total: int = 0
    network_name: str = ""
    raw: bytes | None = None
    verified: bool = False
    inputs: list[StoredTxInput] = field(default_factory=list)
    outputs: list[StoredTxOutput] = field(default_factory=list)


@dataclass
class StoredSaplingNote:
    id: int
    wallet_id: int
    value: int = 0
    rcm: bytes = b""
    address: bytes = b""
    position: int = 0
    block_height: int = 0
    txid: str = ""
    output_index: int = 0
    nullifier: bytes = b""
    spent: bool = False
    spending_txid: str = ""


@dataclass
class StoredWallet:
    id: int
    name: str
    owner: str = ""
    network_name: str = ""
    purpose: int = 44
    scheme: str = "bip32"
    witness_type: str = "legacy"
    encoding: str = "base58"
    main_key_id: int | None = None
    multisig_n_required: int = 1
    sort_keys: bool = False
    parent_id: int | None = None
    cosigner_id: int | None = None
    key_path: str = ""
    default_account_id: int | None = None
    discovered: bool = False
    ssp_peer_pubkey: str = ""
    multisig: bool = False
    sapling_last_scanned_height: int = 0
    sapling_tree: bytes = b""


@dataclass
class StoredConfig:
    version: str = ""
    installation_date: str = ""


# Name validation
_NAME_RE: re.Pattern[str] = re.compile(r"^[\w\-. ]{1,80}$")


def _validate_wallet_name(name: str) -> None:
    if not name or not _NAME_RE.match(name):
        raise ValueError(
            f"Invalid wallet name '{name}'. "
            "Must be 1-80 characters: letters, digits, hyphens, underscores, dots, spaces."
        )


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

# Dicts are serialized to/from msgpack. The _to_dict functions produce typed
# dicts; the _from_dict functions accept dict[str, object] since data comes
# from untrusted deserialization and each field is narrowed individually.


def _int_or(val: object, default: int) -> int:
    """Narrow an object to int, with fallback."""
    return val if isinstance(val, int) else default


def _str_or(val: object, default: str) -> str:
    """Narrow an object to str, with fallback."""
    return val if isinstance(val, str) else default


def _bytes_or_none(val: object) -> bytes | None:
    """Narrow an object to bytes or None."""
    return val if isinstance(val, bytes) else None


def _int_or_none(val: object) -> int | None:
    """Narrow an object to int or None."""
    return val if isinstance(val, int) else None


def _key_to_dict(
    k: StoredKey,
) -> dict[str, int | str | bytes | bool | list[tuple[int, int]] | None]:
    return {
        "id": k.id,
        "wallet_id": k.wallet_id,
        "parent_id": k.parent_id,
        "name": k.name,
        "account_id": k.account_id,
        "depth": k.depth,
        "change": k.change,
        "address_index": k.address_index,
        "public": k.public,
        "private": k.private,
        "wif": k.wif,
        "compressed": k.compressed,
        "key_type": k.key_type,
        "address": k.address,
        "cosigner_id": k.cosigner_id,
        "encoding": k.encoding,
        "purpose": k.purpose,
        "is_private": k.is_private,
        "path": k.path,
        "network_name": k.network_name,
        "balance": k.balance,
        "used": k.used,
        "latest_txid": k.latest_txid,
        "latest_tx_index": k.latest_tx_index,
        "redeem_script": k.redeem_script,
        "multisig_children": k.multisig_children,
    }


def _key_from_dict(d: dict[str, object]) -> StoredKey:
    raw_children = d.get("multisig_children")
    children: list[tuple[int, int]] = []
    if isinstance(raw_children, list):
        for pair in raw_children:
            if isinstance(pair, (list, tuple)) and len(pair) == 2:
                children.append((_int_or(pair[0], 0), _int_or(pair[1], 0)))
    return StoredKey(
        id=_int_or(d.get("id"), 0),
        wallet_id=_int_or(d.get("wallet_id"), 0),
        parent_id=_int_or_none(d.get("parent_id")),
        name=_str_or(d.get("name"), ""),
        account_id=_int_or(d.get("account_id"), 0),
        depth=_int_or(d.get("depth"), 0),
        change=_int_or(d.get("change"), 0),
        address_index=_int_or(d.get("address_index"), 0),
        public=_bytes_or_none(d.get("public")),
        private=_bytes_or_none(d.get("private")),
        wif=_str_or(d.get("wif"), "") if isinstance(d.get("wif"), str) else None,
        compressed=bool(d.get("compressed", True)),
        key_type=_str_or(d.get("key_type"), "bip32"),
        address=_str_or(d.get("address"), ""),
        cosigner_id=_int_or_none(d.get("cosigner_id")),
        encoding=_str_or(d.get("encoding"), "base58"),
        purpose=_int_or(d.get("purpose"), 44),
        is_private=bool(d.get("is_private", False)),
        path=_str_or(d.get("path"), ""),
        network_name=_str_or(d.get("network_name"), ""),
        balance=_int_or(d.get("balance"), 0),
        used=bool(d.get("used", False)),
        latest_txid=_bytes_or_none(d.get("latest_txid")),
        latest_tx_index=_int_or_none(d.get("latest_tx_index")),
        redeem_script=_bytes_or_none(d.get("redeem_script")),
        multisig_children=children,
    )


def _tx_input_to_dict(i: StoredTxInput) -> dict[str, int | str | bytes | bool | None]:
    return {
        "index_n": i.index_n,
        "key_id": i.key_id,
        "address": i.address,
        "witnesses": i.witnesses,
        "witness_type": i.witness_type,
        "prev_txid": i.prev_txid,
        "output_n": i.output_n,
        "script": i.script,
        "script_type": i.script_type,
        "sequence": i.sequence,
        "value": i.value,
        "double_spend": i.double_spend,
    }


def _tx_input_from_dict(d: dict[str, object]) -> StoredTxInput:
    return StoredTxInput(
        index_n=_int_or(d.get("index_n"), 0),
        key_id=_int_or_none(d.get("key_id")),
        address=_str_or(d.get("address"), ""),
        witnesses=_bytes_or_none(d.get("witnesses")),
        witness_type=_str_or(d.get("witness_type"), "legacy"),
        prev_txid=_bytes_or_none(d.get("prev_txid")),
        output_n=_int_or(d.get("output_n"), 0),
        script=_bytes_or_none(d.get("script")),
        script_type=_str_or(d.get("script_type"), "sig_pubkey"),
        sequence=_int_or(d.get("sequence"), 0),
        value=_int_or(d.get("value"), 0),
        double_spend=bool(d.get("double_spend", False)),
    )


def _tx_output_to_dict(o: StoredTxOutput) -> dict[str, int | str | bytes | bool | None]:
    d: dict[str, int | str | bytes | bool | None] = {
        "output_n": o.output_n,
        "key_id": o.key_id,
        "address": o.address,
        "script": o.script,
        "script_type": o.script_type,
        "value": o.value,
        "spent": o.spent,
        "spending_txid": o.spending_txid,
        "spending_index_n": o.spending_index_n,
    }
    if o.locked_until:
        d["locked_until"] = o.locked_until.isoformat()
    return d


def _tx_output_from_dict(d: dict[str, object]) -> StoredTxOutput:
    locked_raw = d.get("locked_until")
    locked: datetime | None = None
    if isinstance(locked_raw, str):
        locked = datetime.fromisoformat(locked_raw)
    return StoredTxOutput(
        output_n=_int_or(d.get("output_n"), 0),
        key_id=_int_or_none(d.get("key_id")),
        address=_str_or(d.get("address"), ""),
        script=_bytes_or_none(d.get("script")),
        script_type=_str_or(d.get("script_type"), "p2pkh"),
        value=_int_or(d.get("value"), 0),
        spent=bool(d.get("spent", False)),
        spending_txid=_bytes_or_none(d.get("spending_txid")),
        spending_index_n=_int_or_none(d.get("spending_index_n")),
        locked_until=locked,
    )


def _tx_to_dict(
    t: StoredTransaction,
) -> dict[
    str,
    int | str | bytes | bool | list[dict[str, int | str | bytes | bool | None]] | None,
]:
    return {
        "id": t.id,
        "wallet_id": t.wallet_id,
        "txid": t.txid,
        "account_id": t.account_id,
        "witness_type": t.witness_type,
        "version": t.version,
        "locktime": t.locktime,
        "date": t.date.isoformat() if t.date else None,
        "coinbase": t.coinbase,
        "expiry_height": t.expiry_height,
        "confirmations": t.confirmations,
        "block_height": t.block_height,
        "size": t.size,
        "fee": t.fee,
        "status": t.status,
        "is_complete": t.is_complete,
        "input_total": t.input_total,
        "output_total": t.output_total,
        "network_name": t.network_name,
        "raw": t.raw,
        "verified": t.verified,
        "inputs": [_tx_input_to_dict(i) for i in t.inputs],
        "outputs": [_tx_output_to_dict(o) for o in t.outputs],
    }


def _tx_from_dict(d: dict[str, object]) -> StoredTransaction:
    raw_inputs = d.get("inputs")
    inputs: list[StoredTxInput] = []
    if isinstance(raw_inputs, list):
        for i_raw in raw_inputs:
            if isinstance(i_raw, dict):
                i_dict: dict[str, object] = {str(k): v for k, v in i_raw.items()}
                inputs.append(_tx_input_from_dict(i_dict))
    raw_outputs = d.get("outputs")
    outputs: list[StoredTxOutput] = []
    if isinstance(raw_outputs, list):
        for o_raw in raw_outputs:
            if isinstance(o_raw, dict):
                o_dict: dict[str, object] = {str(k): v for k, v in o_raw.items()}
                outputs.append(_tx_output_from_dict(o_dict))
    date_raw = d.get("date")
    date_val: datetime = datetime.now(UTC)
    if isinstance(date_raw, str):
        date_val = datetime.fromisoformat(date_raw)
    return StoredTransaction(
        id=_int_or(d.get("id"), 0),
        wallet_id=_int_or(d.get("wallet_id"), 0),
        txid=_bytes_or_none(d.get("txid")) or b"",
        account_id=_int_or(d.get("account_id"), 0),
        witness_type=_str_or(d.get("witness_type"), "legacy"),
        version=_int_or(d.get("version"), 1),
        locktime=_int_or(d.get("locktime"), 0),
        date=date_val,
        coinbase=bool(d.get("coinbase", False)),
        expiry_height=_int_or(d.get("expiry_height"), 0),
        confirmations=_int_or(d.get("confirmations"), 0),
        block_height=_int_or_none(d.get("block_height")),
        size=_int_or(d.get("size"), 0),
        fee=_int_or(d.get("fee"), 0),
        status=_str_or(d.get("status"), "new"),
        is_complete=bool(d.get("is_complete", True)),
        input_total=_int_or(d.get("input_total"), 0),
        output_total=_int_or(d.get("output_total"), 0),
        network_name=_str_or(d.get("network_name"), ""),
        raw=_bytes_or_none(d.get("raw")),
        verified=bool(d.get("verified", False)),
        inputs=inputs,
        outputs=outputs,
    )


def _sapling_note_to_dict(
    n: StoredSaplingNote,
) -> dict[str, int | str | bytes | bool]:
    return {
        "id": n.id,
        "wallet_id": n.wallet_id,
        "value": n.value,
        "rcm": n.rcm,
        "address": n.address,
        "position": n.position,
        "block_height": n.block_height,
        "txid": n.txid,
        "output_index": n.output_index,
        "nullifier": n.nullifier,
        "spent": n.spent,
        "spending_txid": n.spending_txid,
    }


def _sapling_note_from_dict(d: dict[str, object]) -> StoredSaplingNote:
    return StoredSaplingNote(
        id=_int_or(d.get("id"), 0),
        wallet_id=_int_or(d.get("wallet_id"), 0),
        value=_int_or(d.get("value"), 0),
        rcm=_bytes_or_none(d.get("rcm")) or b"",
        address=_bytes_or_none(d.get("address")) or b"",
        position=_int_or(d.get("position"), 0),
        block_height=_int_or(d.get("block_height"), 0),
        txid=_str_or(d.get("txid"), ""),
        output_index=_int_or(d.get("output_index"), 0),
        nullifier=_bytes_or_none(d.get("nullifier")) or b"",
        spent=bool(d.get("spent", False)),
        spending_txid=_str_or(d.get("spending_txid"), ""),
    )


def _wallet_to_dict(w: StoredWallet) -> dict[str, int | str | bytes | bool | None]:
    return {
        "id": w.id,
        "name": w.name,
        "owner": w.owner,
        "network_name": w.network_name,
        "purpose": w.purpose,
        "scheme": w.scheme,
        "witness_type": w.witness_type,
        "encoding": w.encoding,
        "main_key_id": w.main_key_id,
        "multisig_n_required": w.multisig_n_required,
        "sort_keys": w.sort_keys,
        "parent_id": w.parent_id,
        "cosigner_id": w.cosigner_id,
        "key_path": w.key_path,
        "default_account_id": w.default_account_id,
        "discovered": w.discovered,
        "ssp_peer_pubkey": w.ssp_peer_pubkey,
        "multisig": w.multisig,
        "sapling_last_scanned_height": w.sapling_last_scanned_height,
        "sapling_tree": w.sapling_tree,
    }


def _wallet_from_dict(d: dict[str, object]) -> StoredWallet:
    return StoredWallet(
        id=_int_or(d.get("id"), 0),
        name=_str_or(d.get("name"), ""),
        owner=_str_or(d.get("owner"), ""),
        network_name=_str_or(d.get("network_name"), ""),
        purpose=_int_or(d.get("purpose"), 44),
        scheme=_str_or(d.get("scheme"), "bip32"),
        witness_type=_str_or(d.get("witness_type"), "legacy"),
        encoding=_str_or(d.get("encoding"), "base58"),
        main_key_id=_int_or_none(d.get("main_key_id")),
        multisig_n_required=_int_or(d.get("multisig_n_required"), 1),
        sort_keys=bool(d.get("sort_keys", False)),
        parent_id=_int_or_none(d.get("parent_id")),
        cosigner_id=_int_or_none(d.get("cosigner_id")),
        key_path=_str_or(d.get("key_path"), ""),
        default_account_id=_int_or_none(d.get("default_account_id")),
        discovered=bool(d.get("discovered", False)),
        ssp_peer_pubkey=_str_or(d.get("ssp_peer_pubkey"), ""),
        multisig=bool(d.get("multisig", False)),
        sapling_last_scanned_height=_int_or(d.get("sapling_last_scanned_height"), 0),
        sapling_tree=_bytes_or_none(d.get("sapling_tree")) or b"",
    )


# ---------------------------------------------------------------------------
# WalletStore
# ---------------------------------------------------------------------------


class WalletStore:
    """In-memory store for all wallet data, backed by an encrypted flat file."""

    def __init__(self) -> None:
        self.wallets: dict[int, StoredWallet] = {}
        self.keys: dict[int, StoredKey] = {}
        self.transactions: dict[int, StoredTransaction] = {}
        self.sapling_notes: dict[int, StoredSaplingNote] = {}
        self.config: StoredConfig = StoredConfig()

        self._next_wallet_id: int = 1
        self._next_key_id: int = 1
        self._next_tx_id: int = 1
        self._next_sapling_note_id: int = 1

        self._wallets_by_name: dict[str, int] = {}
        self._keys_by_address: dict[str, int] = {}
        self._keys_by_wallet: dict[int, list[int]] = {}
        self._keys_by_wif: dict[str, int] = {}
        self._txs_by_wallet: dict[int, list[int]] = {}
        self._txs_by_txid: dict[bytes, list[int]] = {}

        self._dirty: bool = False
        self._file_path: str | None = None

    # -- Persistence ---------------------------------------------------------

    def load(
        self,
        path: str,
        password: str | bytearray | None = None,
        master_key: bytes | None = None,
    ) -> None:
        data: dict[str, object] = load_wallet(path, password=password, master_key=master_key)
        self._file_path = path

        version_raw = data.get("version")
        install_raw = data.get("installation_date")
        self.config = StoredConfig(
            version=str(version_raw) if isinstance(version_raw, str) else "",
            installation_date=str(install_raw) if isinstance(install_raw, str) else "",
        )

        raw_wallets = data.get("wallets")
        if isinstance(raw_wallets, list):
            self.wallets = {}
            for w in raw_wallets:
                if isinstance(w, dict):
                    sw = _wallet_from_dict(w)
                    self.wallets[sw.id] = sw

        raw_keys = data.get("keys")
        if isinstance(raw_keys, list):
            self.keys = {}
            for k in raw_keys:
                if isinstance(k, dict):
                    sk = _key_from_dict(k)
                    self.keys[sk.id] = sk

        raw_txs = data.get("transactions")
        if isinstance(raw_txs, list):
            self.transactions = {}
            for t in raw_txs:
                if isinstance(t, dict):
                    st = _tx_from_dict(t)
                    self.transactions[st.id] = st

        raw_notes = data.get("sapling_notes")
        if isinstance(raw_notes, list):
            self.sapling_notes = {}
            for n in raw_notes:
                if isinstance(n, dict):
                    sn = _sapling_note_from_dict(n)
                    self.sapling_notes[sn.id] = sn

        self._next_wallet_id = max((w.id for w in self.wallets.values()), default=0) + 1
        self._next_key_id = max((k.id for k in self.keys.values()), default=0) + 1
        self._next_tx_id = max((t.id for t in self.transactions.values()), default=0) + 1
        self._next_sapling_note_id = max((n.id for n in self.sapling_notes.values()), default=0) + 1

        self._rebuild_indexes()
        self._dirty = False

    def _to_dict(self) -> dict[str, object]:
        return {
            "version": self.config.version,
            "installation_date": self.config.installation_date,
            "wallets": [_wallet_to_dict(w) for w in self.wallets.values()],
            "keys": [_key_to_dict(k) for k in self.keys.values()],
            "transactions": [_tx_to_dict(t) for t in self.transactions.values()],
            "sapling_notes": [_sapling_note_to_dict(n) for n in self.sapling_notes.values()],
        }

    def save(self, password: str | bytearray, path: str | None = None) -> bytes:
        """Save and return the master key (for keychain storage)."""
        path = path or self._file_path
        if not path:
            raise RuntimeError("No file path set — call load() first or pass path")
        mk: bytes = save_wallet(path, self._to_dict(), password=password)
        self._file_path = path
        self._dirty = False
        return mk

    def save_with_key(self, master_key: bytes, path: str | None = None) -> None:
        path = path or self._file_path
        if not path:
            raise RuntimeError("No file path set — call load() first or pass path")
        save_wallet(path, self._to_dict(), master_key=master_key)
        self._file_path = path
        self._dirty = False

    def _rebuild_indexes(self) -> None:
        self._wallets_by_name.clear()
        self._keys_by_address.clear()
        self._keys_by_wallet.clear()
        self._keys_by_wif.clear()
        self._txs_by_wallet.clear()
        self._txs_by_txid.clear()

        for w in self.wallets.values():
            self._wallets_by_name[w.name] = w.id

        for k in self.keys.values():
            if k.address:
                self._keys_by_address[k.address] = k.id
            self._keys_by_wallet.setdefault(k.wallet_id, []).append(k.id)
            if k.wif:
                self._keys_by_wif[k.wif] = k.id

        for t in self.transactions.values():
            self._txs_by_wallet.setdefault(t.wallet_id, []).append(t.id)
            self._txs_by_txid.setdefault(t.txid, []).append(t.id)

    # -- Wallet CRUD ---------------------------------------------------------

    def add_wallet(self, wallet: StoredWallet) -> int:
        _validate_wallet_name(wallet.name)
        if wallet.name in self._wallets_by_name:
            raise ValueError(f"Wallet '{wallet.name}' already exists")

        wallet.id = self._next_wallet_id
        self._next_wallet_id += 1
        self.wallets[wallet.id] = wallet
        self._wallets_by_name[wallet.name] = wallet.id
        self._dirty = True
        return wallet.id

    def get_wallet(self, name: str | None = None, wallet_id: int | None = None) -> StoredWallet | None:
        if wallet_id is not None:
            return self.wallets.get(wallet_id)
        if name is not None:
            wid: int | None = self._wallets_by_name.get(name)
            return self.wallets.get(wid) if wid is not None else None
        return None

    def wallet_exists(self, name: str) -> bool:
        return name in self._wallets_by_name

    def list_wallets(self) -> list[StoredWallet]:
        return list(self.wallets.values())

    def delete_wallet(self, wallet_id: int) -> None:
        wallet: StoredWallet | None = self.wallets.get(wallet_id)
        if not wallet:
            return

        key_ids: list[int] = list(self._keys_by_wallet.get(wallet_id, []))
        for kid in key_ids:
            self._remove_key(kid)

        tx_ids: list[int] = list(self._txs_by_wallet.get(wallet_id, []))
        for tid in tx_ids:
            self._remove_transaction(tid)

        child_ids: list[int] = [w.id for w in self.wallets.values() if w.parent_id == wallet_id]
        for cid in child_ids:
            self.delete_wallet(cid)

        self._wallets_by_name.pop(wallet.name, None)
        self.wallets.pop(wallet_id, None)
        self._dirty = True

    def rename_wallet(self, wallet_id: int, new_name: str) -> None:
        _validate_wallet_name(new_name)
        wallet: StoredWallet | None = self.wallets.get(wallet_id)
        if not wallet:
            raise ValueError(f"Wallet {wallet_id} not found")
        if new_name in self._wallets_by_name and self._wallets_by_name[new_name] != wallet_id:
            raise ValueError(f"Wallet '{new_name}' already exists")

        self._wallets_by_name.pop(wallet.name, None)
        wallet.name = new_name
        self._wallets_by_name[new_name] = wallet_id
        self._dirty = True

    def update_wallet(self, wallet: StoredWallet) -> None:
        """Replace a wallet in the store and mark dirty."""
        if wallet.id not in self.wallets:
            raise ValueError(f"Wallet {wallet.id} not found")
        self.wallets[wallet.id] = wallet
        self._dirty = True

    # -- Key CRUD ------------------------------------------------------------

    def add_key(self, key: StoredKey) -> int:
        key.id = self._next_key_id
        self._next_key_id += 1
        self.keys[key.id] = key
        if key.address:
            self._keys_by_address[key.address] = key.id
        self._keys_by_wallet.setdefault(key.wallet_id, []).append(key.id)
        if key.wif:
            self._keys_by_wif[key.wif] = key.id
        self._dirty = True
        return key.id

    def update_key(self, key: StoredKey) -> None:
        """Replace a key in the store and rebuild its indexes."""
        if key.id not in self.keys:
            raise ValueError(f"Key {key.id} not found in store")
        old = self.keys[key.id]
        # Remove old index entries
        if old.address and old.address in self._keys_by_address:
            self._keys_by_address.pop(old.address, None)
        if old.wif and old.wif in self._keys_by_wif:
            self._keys_by_wif.pop(old.wif, None)
        # Store updated key
        self.keys[key.id] = key
        # Rebuild index entries
        if key.address:
            self._keys_by_address[key.address] = key.id
        if key.wif:
            self._keys_by_wif[key.wif] = key.id
        self._dirty = True

    def get_key(
        self,
        key_id: int | None = None,
        address: str | None = None,
        wif: str | None = None,
    ) -> StoredKey | None:
        if key_id is not None:
            return self.keys.get(key_id)
        if address is not None:
            kid: int | None = self._keys_by_address.get(address)
            return self.keys.get(kid) if kid is not None else None
        if wif is not None:
            kid = self._keys_by_wif.get(wif)
            return self.keys.get(kid) if kid is not None else None
        return None

    def get_keys(
        self,
        wallet_id: int,
        account_id: int | None = None,
        network_name: str | None = None,
        key_type: str | None = None,
        change: int | None = None,
        depth: int | None = None,
        used: bool | None = None,
        is_private: bool | None = None,
        has_balance: bool = False,
    ) -> list[StoredKey]:
        key_ids: list[int] = self._keys_by_wallet.get(wallet_id, [])
        result: list[StoredKey] = []
        for kid in key_ids:
            k: StoredKey = self.keys[kid]
            if account_id is not None and k.account_id != account_id:
                continue
            if network_name is not None and k.network_name != network_name:
                continue
            if key_type is not None and k.key_type != key_type:
                continue
            if change is not None and k.change != change:
                continue
            if depth is not None and k.depth != depth:
                continue
            if used is not None and k.used != used:
                continue
            if is_private is not None and k.is_private != is_private:
                continue
            if has_balance and k.balance <= 0:
                continue
            result.append(k)
        return result

    def get_unused_keys(
        self,
        wallet_id: int,
        change: int = 0,
        account_id: int = 0,
        depth: int | None = None,
    ) -> list[StoredKey]:
        return [
            k
            for k in self.get_keys(wallet_id, account_id=account_id, change=change, used=False)
            if depth is None or k.depth == depth
        ]

    def _remove_key(self, key_id: int) -> None:
        key: StoredKey | None = self.keys.pop(key_id, None)
        if not key:
            return
        if key.address:
            self._keys_by_address.pop(key.address, None)
        if key.wif:
            self._keys_by_wif.pop(key.wif, None)
        wallet_keys: list[int] = self._keys_by_wallet.get(key.wallet_id, [])
        if key_id in wallet_keys:
            wallet_keys.remove(key_id)
        self._dirty = True

    # -- Transaction CRUD ----------------------------------------------------

    def add_transaction(self, tx: StoredTransaction) -> int:
        tx.id = self._next_tx_id
        self._next_tx_id += 1
        self.transactions[tx.id] = tx
        self._txs_by_wallet.setdefault(tx.wallet_id, []).append(tx.id)
        self._txs_by_txid.setdefault(tx.txid, []).append(tx.id)
        self._dirty = True
        return tx.id

    def get_transaction(
        self,
        tx_id: int | None = None,
        txid: bytes | None = None,
        wallet_id: int | None = None,
    ) -> StoredTransaction | None:
        if tx_id is not None:
            return self.transactions.get(tx_id)
        if txid is not None:
            candidates: list[int] = self._txs_by_txid.get(txid, [])
            for tid in candidates:
                tx: StoredTransaction = self.transactions[tid]
                if wallet_id is None or tx.wallet_id == wallet_id:
                    return tx
        return None

    def get_transactions(
        self,
        wallet_id: int,
        account_id: int | None = None,
        status: str | None = None,
        min_confirmations: int | None = None,
        network_name: str | None = None,
    ) -> list[StoredTransaction]:
        tx_ids: list[int] = self._txs_by_wallet.get(wallet_id, [])
        result: list[StoredTransaction] = []
        for tid in tx_ids:
            t: StoredTransaction = self.transactions[tid]
            if account_id is not None and t.account_id != account_id:
                continue
            if status is not None and t.status != status:
                continue
            if min_confirmations is not None and t.confirmations < min_confirmations:
                continue
            if network_name is not None and t.network_name != network_name:
                continue
            result.append(t)
        return result

    def _remove_transaction(self, tx_id: int) -> None:
        tx: StoredTransaction | None = self.transactions.pop(tx_id, None)
        if not tx:
            return
        wallet_txs: list[int] = self._txs_by_wallet.get(tx.wallet_id, [])
        if tx_id in wallet_txs:
            wallet_txs.remove(tx_id)
        txid_list: list[int] = self._txs_by_txid.get(tx.txid, [])
        if tx_id in txid_list:
            txid_list.remove(tx_id)
        self._dirty = True

    # -- UTXO selection ------------------------------------------------------

    def get_utxos(
        self,
        wallet_id: int,
        min_confirmations: int = 1,
        key_id: int | None = None,
    ) -> list[tuple[StoredTransaction, StoredTxOutput]]:
        """Get all unspent outputs for a wallet."""
        now: datetime = datetime.now(UTC)
        result: list[tuple[StoredTransaction, StoredTxOutput]] = []
        for tx in self.get_transactions(wallet_id, min_confirmations=min_confirmations):
            for out in tx.outputs:
                if out.spent:
                    continue
                if out.key_id is None:
                    continue
                if key_id is not None and out.key_id != key_id:
                    continue
                if out.locked_until and out.locked_until > now:
                    continue
                result.append((tx, out))
        return result

    def select_utxos(
        self,
        wallet_id: int,
        amount: int,
        dust_amount: int = 1000,
        min_confirmations: int = 1,
        max_utxos: int = 50,
        key_id: int | None = None,
    ) -> list[tuple[StoredTransaction, StoredTxOutput]]:
        """Select UTXOs to cover amount.

        Randomized to prevent chain analysis fingerprinting.
        """
        utxos: list[tuple[StoredTransaction, StoredTxOutput]] = self.get_utxos(
            wallet_id, min_confirmations=min_confirmations, key_id=key_id
        )

        utxos = [(tx, out) for tx, out in utxos if out.value > dust_amount]

        rng: secrets.SystemRandom = secrets.SystemRandom()
        rng.shuffle(utxos)

        for tx, out in utxos:
            if amount <= out.value <= amount + dust_amount:
                return [(tx, out)]

        singles: list[tuple[StoredTransaction, StoredTxOutput]] = [
            (tx, out) for tx, out in utxos if out.value >= amount
        ]
        if singles:
            singles.sort(key=lambda x: x[1].value)
            return [singles[0]]

        selected: list[tuple[StoredTransaction, StoredTxOutput]] = []
        total: int = 0
        for tx, out in utxos:
            selected.append((tx, out))
            total += out.value
            if total >= amount:
                break
            if len(selected) >= max_utxos:
                break

        return selected

    def lock_utxos(self, utxos: list[tuple[StoredTransaction, StoredTxOutput]], minutes: int = 5) -> None:
        """Mark UTXOs as locked to prevent double-selection in concurrent sends."""
        lock_until: datetime = datetime.now(UTC) + timedelta(minutes=minutes)
        for _, out in utxos:
            out.locked_until = lock_until
        self._dirty = True

    def mark_output_spent(self, tx_id: int, output_n: int, spending_txid: bytes, spending_index_n: int) -> None:
        tx: StoredTransaction | None = self.transactions.get(tx_id)
        if not tx:
            return
        for out in tx.outputs:
            if out.output_n == output_n:
                out.spent = True
                out.spending_txid = spending_txid
                out.spending_index_n = spending_index_n
                self._dirty = True
                return

    # -- Sapling note CRUD ---------------------------------------------------

    def add_sapling_note(self, note: StoredSaplingNote) -> int:
        note.id = self._next_sapling_note_id
        self._next_sapling_note_id += 1
        self.sapling_notes[note.id] = note
        self._dirty = True
        return note.id

    def get_sapling_notes(
        self,
        wallet_id: int,
        spent: bool | None = None,
    ) -> list[StoredSaplingNote]:
        result: list[StoredSaplingNote] = []
        for n in self.sapling_notes.values():
            if n.wallet_id != wallet_id:
                continue
            if spent is not None and n.spent != spent:
                continue
            result.append(n)
        return result

    def update_sapling_note(self, note: StoredSaplingNote) -> None:
        if note.id not in self.sapling_notes:
            raise ValueError(f"Sapling note {note.id} not found")
        self.sapling_notes[note.id] = note
        self._dirty = True

    # -- Cleanup -------------------------------------------------------------

    def wipe(self) -> None:
        """Zero all sensitive data in memory."""
        for k in self.keys.values():
            if isinstance(k.private, bytearray):
                secure_wipe(k.private)
            k.private = None
            k.wif = None
        self.keys.clear()
        self.wallets.clear()
        self.transactions.clear()
        self.sapling_notes.clear()
        self._rebuild_indexes()

    @property
    def dirty(self) -> bool:
        return self._dirty
