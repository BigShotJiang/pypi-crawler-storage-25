"""Reusable TypeIs guard functions for fluxwallet.

These narrow types in *both* branches of an ``if`` / ``else``, unlike
``TypeGuard`` which only narrows the truthy branch.

Input unions match the actual types callers pass — widened from the
original signatures to include all observed call-site types.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeIs

if TYPE_CHECKING:
    from fluxwallet.keys import Address, HDKey, Key
    from fluxwallet.networks import Network
    from fluxwallet.transactions import TransactionMixin, TransactionProtocol
    from fluxwallet.wallet.wallet_key import WalletKey


def is_network(val: str | Network | dict[str, object] | None) -> TypeIs[Network]:
    from fluxwallet.networks import Network

    return isinstance(val, Network)


def is_hdkey(val: HDKey | Address | Key | str | bytes | None) -> TypeIs[HDKey]:
    from fluxwallet.keys import HDKey

    return isinstance(val, HDKey)


def is_key(val: HDKey | Key | str | bytes | None) -> TypeIs[Key]:
    """Narrow to Key but not HDKey (which is a Key subclass)."""
    from fluxwallet.keys import HDKey, Key

    return isinstance(val, Key) and not isinstance(val, HDKey)


def is_wallet_key(val: WalletKey | HDKey | list[HDKey] | None) -> TypeIs[WalletKey]:
    from fluxwallet.wallet.wallet_key import WalletKey

    return isinstance(val, WalletKey)


def is_bytes(val: str | bytes | None) -> TypeIs[bytes]:
    return isinstance(val, bytes)


def is_str(val: str | bytes | int | None) -> TypeIs[str]:
    return isinstance(val, str)


def is_transaction_mixin(
    val: TransactionProtocol | TransactionMixin,
) -> TypeIs[TransactionMixin]:
    from fluxwallet.transactions import TransactionMixin

    return isinstance(val, TransactionMixin)
