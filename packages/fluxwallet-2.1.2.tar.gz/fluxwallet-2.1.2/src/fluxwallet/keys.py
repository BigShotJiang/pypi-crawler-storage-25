#
#    fluxwallet - Python Cryptocurrency Library
#    Public key cryptography and Hierarchical Deterministic Key Management
#    © 2016 - 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import annotations

import collections
import hashlib
import hmac
import json
import logging
import numbers
import secrets
from copy import deepcopy
from typing import Literal, Self, overload

import coincurve

from fluxwallet.config import (
    DEFAULT_NETWORK,
    DEFAULT_WITNESS_TYPE,
    SIGHASH_ALL,
    TYPE_TEXT,
    WALLET_KEY_STRUCTURES,
)
from fluxwallet.config.secp256k1 import (
    secp256k1_n,
    secp256k1_p,
)
from fluxwallet.encoding import (
    EncodingError,
    addr_to_pubkeyhash,
    base58encode,
    bip38_decrypt,
    bip38_encrypt,
    change_base,
    convert_der_sig,
    der_encode_sig,
    double_sha256,
    hash160,
    int_to_varbyteint,
    pubkeyhash_to_addr,
    pubkeyhash_to_addr_base58,
    to_bytes,
    to_hexstring,
)
from fluxwallet.exceptions import FluxWalletError
from fluxwallet.main import get_encoding_from_witness, script_type_default
from fluxwallet.mnemonic import Mnemonic
from fluxwallet.networks import (
    Network,
    network_by_value,
    prefix_len_by_network,
    wif_prefix_search,
)
from fluxwallet.secure_mem import secure_wipe
from fluxwallet.type_guards import is_network

_logger = logging.getLogger(__name__)

# Backward compatibility: fastecdsa/ecdsa have been replaced by coincurve
USE_FASTECDSA = False


class RFC6979:
    """Pure-Python RFC 6979 deterministic nonce generator.

    Retained for backward compatibility and test vectors. In production signing, coincurve handles RFC 6979 internally.
    """

    def __init__(self, msg: str | bytes, x: int, order: int, hash_func: str) -> None:
        self.x = x
        self.order = order
        self.hash_func = hash_func
        if isinstance(msg, str):
            msg = msg.encode("utf-8")
        self.msg_hash = hashlib.new(hash_func, msg).digest()

    def gen_nonce(self) -> int:
        """Generate a deterministic nonce k per RFC 6979."""
        hash_size = len(self.msg_hash)
        order_size = (self.order.bit_length() + 7) // 8

        # Step b: V = 0x01 * hash_size
        v = b"\x01" * hash_size
        # Step c: K = 0x00 * hash_size
        k = b"\x00" * hash_size
        # Step d: K = HMAC_K(V || 0x00 || int2octets(x) || bits2octets(h1))
        x_bytes = self.x.to_bytes(order_size, "big")
        k = hmac.new(k, v + b"\x00" + x_bytes + self.msg_hash, self.hash_func).digest()
        # Step e: V = HMAC_K(V)
        v = hmac.new(k, v, self.hash_func).digest()
        # Step f: K = HMAC_K(V || 0x01 || int2octets(x) || bits2octets(h1))
        k = hmac.new(k, v + b"\x01" + x_bytes + self.msg_hash, self.hash_func).digest()
        # Step g: V = HMAC_K(V)
        v = hmac.new(k, v, self.hash_func).digest()

        # Step h: generate candidate k
        while True:
            t = b""
            while len(t) < order_size:
                v = hmac.new(k, v, self.hash_func).digest()
                t += v
            nonce = int.from_bytes(t[:order_size], "big")
            if 1 <= nonce < self.order:
                return nonce
            k = hmac.new(k, v + b"\x00", self.hash_func).digest()
            v = hmac.new(k, v, self.hash_func).digest()


class BKeyError(FluxWalletError):
    """Handle Key class Exceptions."""


def check_network_and_key(
    key: str | int | bytes,
    network: str | None = None,
    kf_networks: list[str] | None = None,
    default_network: str = DEFAULT_NETWORK,
) -> str:
    """Check if given key corresponds with given network and return network if it does. If no network is specified this
    method tries to extract the network from the key. If no network can be extracted from the key the default network
    will be returned.

    >>> check_network_and_key('5HueCGU8rMjxEXxiPuD5BDku4MkFqeZyd4dZ1jvhTVqvbTLvyTJ')
    'flux'

    A BKeyError will be raised if key does not correspond with network or if multiple network are found.

    :param key: Key in any format recognized by get_key_format function
    :type key: str, int, bytes
    :param network: Optional network. Method raises BKeyError if keys belongs to another network
    :type network: str, None
    :param kf_networks: Optional list of networks which is returned by get_key_format. If left empty the
        get_key_format function will be called.
    :type kf_networks: list, None
    :param default_network: Specify different default network, leave empty for default
    :type default_network: str, None

    :return str: Network name
    """
    if not kf_networks:
        kf = get_key_format(key)
        kf_networks_raw = kf["networks"]
        if isinstance(kf_networks_raw, list):
            kf_networks = [s for s in kf_networks_raw if isinstance(s, str)]
    if kf_networks:
        if network is not None and network not in kf_networks:
            raise BKeyError(f"Specified key {kf_networks} is from different network then specified: {network}")
        if network is None and len(kf_networks) == 1:
            return kf_networks[0]
        if network is None and len(kf_networks) > 1:
            if default_network in kf_networks:
                return default_network
            if "testnet" in kf_networks:
                return "testnet"
            raise BKeyError(f"Could not determine network of specified key, multiple networks found: {kf_networks}")
    if network is None:
        return default_network
    return network


def get_key_format(
    key: str | int | bytes, is_private: bool | None = None
) -> dict[str, str | list[str] | list[bool] | bool | None]:
    """Determines the type (private or public), format and network key.

    This method does not validate if a key is valid.

    >>> get_key_format('becc7ac3b383cd609bd644aa5f102a811bac49b6a34bbd8afe706e32a9ac5c5e')
    {'format': 'hex', 'networks': None, 'is_private': True, 'script_types': [],
     'witness_types': ['legacy'], 'multisig': [False]}

    :param key: Any private or public key
    :type key: str, int, bytes
    :param is_private: Is key private or not?
    :type is_private: bool

    :return dict: Dictionary with format, network and is_private
    """
    if not key:
        raise BKeyError("Key empty, please specify a valid key")
    key_format = ""
    networks: list[str] | None = None
    script_types: list[str] = []
    witness_types: list[str] = ["legacy"]
    multisig: list[bool] = [False]

    # if isinstance(key, bytes) and len(key) in [128, 130]:
    #     key = to_hexstring(key)
    if not (is_private is None or isinstance(is_private, bool)):
        raise BKeyError("Attribute 'is_private' must be False or True")
    if isinstance(key, numbers.Number):
        key_format = "decimal"
        is_private = True
    elif isinstance(key, bytes) and len(key) in [33, 65] and key[:1] in [b"\2", b"\3"]:
        key_format = "bin_compressed"
        is_private = False
    elif isinstance(key, bytes) and (len(key) in [33, 65] and key[:1] == b"\4"):
        key_format = "bin"
        is_private = False
    elif isinstance(key, bytes) and len(key) == 33 and key[-1:] == b"\1":
        key_format = "bin_compressed"
        is_private = True
    elif isinstance(key, bytes) and len(key) == 32:
        key_format = "bin"
        is_private = True
    elif isinstance(key, str) and len(key) == 130 and key[:2] == "04" and not is_private:
        key_format = "public_uncompressed"
        is_private = False
    elif isinstance(key, str) and len(key) == 128:
        key_format = "hex"
        if is_private is None:
            is_private = True
    elif isinstance(key, str) and len(key) == 66 and key[:2] in ["02", "03"] and not is_private:
        key_format = "public"
        is_private = False
    elif isinstance(key, str) and len(key) == 64:
        key_format = "hex"
        if is_private is None:
            is_private = True
    elif isinstance(key, str) and len(key) == 66 and key[-2:] in ["01"] and is_private is not False:
        key_format = "hex_compressed"
        is_private = True
    elif isinstance(key, str) and len(key) == 58 and key[:2] == "6P":
        key_format = "wif_protected"
        is_private = True
    elif isinstance(key, str) and len(key.split(" ")) > 1:
        key_format = "mnemonic"
        is_private = True
    else:
        try:
            key_hex = change_base(key, 58, 16)
            prefix_data = wif_prefix_search(key_hex[:8]) if isinstance(key_hex, str) else []
            if prefix_data:
                networks = [str(v) for v in dict.fromkeys([n["network"] for n in prefix_data])]
                if is_private is None and len({n["is_private"] for n in prefix_data}) > 1:
                    raise BKeyError("Cannot determine if key is private or public, please specify is_private attribute")
                is_private_raw = prefix_data[0]["is_private"]
                is_private = bool(is_private_raw) if is_private_raw is not None else False
                script_types = list(dict.fromkeys([str(n["script_type"]) for n in prefix_data]))
                witness_types = list(dict.fromkeys([str(n["witness_type"]) for n in prefix_data]))
                multisig = list(dict.fromkeys([bool(n["multisig"]) for n in prefix_data]))
                key_format = "hdkey_public"
                if is_private:
                    key_format = "hdkey_private"
            else:
                networks = network_by_value("prefix_wif", key_hex[:2]) if isinstance(key_hex, str) else None
                if networks:
                    key_format = "wif_compressed" if isinstance(key_hex, str) and key_hex[-10:-8] == "01" else "wif"
                    is_private = True
        except (TypeError, EncodingError):
            pass
    if not key_format:
        try:
            if isinstance(key, str):
                int(key)
                if 70 < len(key) < 78:
                    key_format = "decimal"
                    is_private = True
        except (TypeError, ValueError):
            pass
    if not key_format:
        try:
            if isinstance(key, str):
                da = deserialize_address(key)
                key_format = "address"
                da_network = da["network"]
                da_script_type = da["script_type"]
                if isinstance(da_network, list):
                    networks = [s for s in da_network if isinstance(s, str)]
                elif isinstance(da_network, str):
                    networks = [da_network]
                if isinstance(da_script_type, list):
                    script_types = [s for s in da_script_type if isinstance(s, str)]
                elif isinstance(da_script_type, str):
                    script_types = [da_script_type]
                is_private = False
        except (EncodingError, TypeError):
            pass
    if not key_format:
        raise BKeyError("Unrecognised key format")
    return {
        "format": key_format,
        "networks": networks,
        "is_private": is_private,
        "script_types": script_types,
        "witness_types": witness_types,
        "multisig": multisig,
    }


def deserialize_address(
    address: str, encoding: str | None = None, network: str | None = None
) -> dict[str, str | bytes | list[str] | int | None]:
    """Deserialize address. Calculate public key hash and try to determine script type and network.

    The 'network' dictionary item with contains the network with the highest priority if multiple networks
    are found. Same applies for the script type.

    Specify the network argument if network is known to avoid unexpected results.

    If more networks and or script types are found you can find these in the 'networks' field.

    >>> deserialize_address('t1UYux2gMjCkyENfMgdKoQ7rdDMvMHa3uR8')
    {'address': 't1UYux2gMjCkyENfMgdKoQ7rdDMvMHa3uR8', 'encoding': 'base58',
     'public_key_hash': '...', 'public_key_hash_bytes': b'...',
     'prefix': b'\\x1c\\xb8', 'network': 'flux', 'script_type': 'p2pkh',
     'witness_type': 'legacy', 'networks': ['flux'], 'witver': None}

    :param address: A base58 encoded address
    :type address: str
    :param encoding: Encoding scheme used for address encoding. Default is base58.
    :type encoding: str
    :param network: Specify network filter, i.e.: flux, etc. Will trigger check if address is valid for this network
    :type network: str

    :return dict: with information about this address
    """
    if encoding is None or encoding == "base58":
        try:
            address_bytes = change_base(address, 58, 256, 25)
        except EncodingError:
            pass
        else:
            if not isinstance(address_bytes, bytes):
                raise EncodingError(f"Address {address} could not be deserialized with encoding {encoding}")
            check = address_bytes[-4:]
            key_hash = address_bytes[:-4]
            checksum = double_sha256(key_hash)[0:4]
            if check != checksum and encoding == "base58":
                raise BKeyError(f"Invalid address {address}, checksum incorrect")
            if check == checksum:
                address_prefix = key_hash[0:2]
                networks_p2pkh = network_by_value("prefix_address", address_prefix.hex())
                networks_p2sh = network_by_value("prefix_address_p2sh", address_prefix.hex())

                script_type = ""
                witness_type = ""
                networks: list[str] = []
                if networks_p2pkh and not networks_p2sh:
                    script_type = "p2pkh"
                    witness_type = "legacy"
                    networks = networks_p2pkh
                elif networks_p2sh:
                    script_type = "p2sh"
                    networks = networks_p2sh
                if network:
                    if network not in networks:
                        raise BKeyError(f"Network {network} not found in extracted networks: {networks}")
                elif len(networks) >= 1:
                    network = networks[0]

                prefix_len = prefix_len_by_network(network if network else "")
                address_prefix = key_hash[0:prefix_len]
                public_key_hash = key_hash[prefix_len:]

                return {
                    "address": address,
                    "encoding": "base58",
                    "public_key_hash": "" if not public_key_hash else public_key_hash.hex(),
                    "public_key_hash_bytes": public_key_hash,
                    "prefix": address_prefix,
                    "network": network if network else "",
                    "script_type": script_type,
                    "witness_type": witness_type,
                    "networks": networks,
                    "witver": None,
                }

    raise EncodingError(f"Address {address} could not be deserialized with encoding {encoding}")


def create_multisig_address(pubkeys: list[bytes], n_required: int, network: str = "flux") -> tuple[str, bytes]:
    """Create a P2SH multisig address (t3) from public keys.

    Keys are sorted lexicographically per BIP67 before building the redeemscript.

    :param pubkeys: List of public keys as bytes
    :type pubkeys: list[bytes]
    :param n_required: Number of signatures required (M in M-of-N)
    :type n_required: int
    :param network: Network name, default is 'flux'
    :type network: str
    :return tuple: (address_string, redeem_script_bytes)
    """
    if n_required > len(pubkeys):
        raise BKeyError(f"Number of required signatures ({n_required}) exceeds number of keys ({len(pubkeys)})")
    if len(pubkeys) > 15:
        raise BKeyError(f"Number of keys ({len(pubkeys)}) exceeds maximum of 15 for OP_CHECKMULTISIG")

    # BIP67: sort keys lexicographically
    sorted_keys = sorted(pubkeys)

    # Build redeemScript: OP_n <pubkey1> ... <pubkeyN> OP_n OP_CHECKMULTISIG
    redeem_script = bytes([0x50 + n_required])
    for key in sorted_keys:
        redeem_script += bytes([len(key)]) + key
    redeem_script += bytes([0x50 + len(sorted_keys)])
    redeem_script += bytes([0xAE])  # OP_CHECKMULTISIG

    # Hash160 of redeemScript
    script_hash = hash160(redeem_script)

    # Encode with p2sh prefix
    net = Network(network)
    address = pubkeyhash_to_addr_base58(script_hash, prefix=net.prefix_address_p2sh)

    return address, redeem_script


def addr_convert(
    addr: str,
    prefix: str | bytes,
    encoding: str | None = None,
    to_encoding: str | None = None,
) -> str:
    """Convert address to another address with another prefix.

    :param addr: Base58 address
    :type addr: str
    :param prefix: New address prefix
    :type prefix: str, bytes
    :param encoding: Encoding of original address. Default is base58.
    :type encoding: str
    :param to_encoding: Encoding of converted address. Default is base58.
    :type to_encoding: str
    :return str: New converted address
    """

    if encoding is None:
        encoding = "base58"
    pkh = addr_to_pubkeyhash(addr, encoding=encoding)
    if to_encoding is None:
        to_encoding = "base58"
    if isinstance(prefix, TYPE_TEXT):
        prefix = to_hexstring(prefix)
    return pubkeyhash_to_addr(pkh, prefix=prefix, encoding=to_encoding)


def path_expand(
    path: list[str | int] | str,
    path_template: list[str] | None = None,
    level_offset: int | None = None,
    account_id: int = 0,
    cosigner_id: int = 0,
    purpose: int = 44,
    address_index: int = 0,
    change: int = 0,
    witness_type: str = DEFAULT_WITNESS_TYPE,
    multisig: bool = False,
    network: str = DEFAULT_NETWORK,
) -> list[str]:
    """Create key path. Specify part of key path and path settings.

    >>> path_expand([10, 20], witness_type='legacy')
    ['m', "44'", "0'", "0'", '10', '20']

    :param path: Part of path, for example [0, 2] for change=0 and address_index=2
    :type path: list, str
    :param path_template: Template for path to create, default is BIP 44:
        ["m", "purpose'", "coin_type'", "account'", "change", "address_index"]
    :type path_template: list
    :param level_offset: Just create part of path. For example -2 means create path with the last 2 items
        (change, address_index) or 1 will return the master key 'm'
    :type level_offset: int
    :param account_id: Account ID
    :type account_id: int
    :param cosigner_id: ID of cosigner
    :type cosigner_id: int
    :param purpose: Purpose value
    :type purpose: int
    :param address_index: Index of key, normally provided to 'path' argument
    :type address_index: int
    :param change: Change key = 1 or normal = 0, normally provided to 'path' argument
    :type change: int
    :param witness_type: Witness type, only 'legacy' is supported for Flux
    :type witness_type: str
    :param multisig: Is path for multisig keys?
    :type multisig: bool
    :param network: Network name. Leave empty for default network
    :type network: str

    :return list:
    """
    if isinstance(path, str):
        path_parts: list[str | int] = list(path.split("/"))
        path = path_parts
    if not path_template:
        ks = [
            k
            for k in WALLET_KEY_STRUCTURES
            if k["witness_type"] == witness_type and k["multisig"] == multisig and k["purpose"] is not None
        ]
        if ks:
            ks_purpose = ks[0]["purpose"]
            if isinstance(ks_purpose, int):
                purpose = ks_purpose
            ks_key_path = ks[0]["key_path"]
            if isinstance(ks_key_path, list):
                path_template = [str(s) for s in ks_key_path]
    if not isinstance(path, list):
        raise BKeyError(f"Please provide path as list with at least 1 item. Wallet key path format is {path_template}")
    if path_template is None:
        raise BKeyError("No path template available")
    if len(path) > len(path_template):
        raise BKeyError(
            f"Invalid path provided. Path should be shorter than {len(path_template)} items. "
            f"Wallet key path format is {path_template}"
        )

    # If path doesn't start with m/M complement path
    poppath = deepcopy(path)
    if path == [] or path[0] not in ["m", "M"]:
        wallet_key_path: list[str] = list(path_template)
        if level_offset:
            wallet_key_path = wallet_key_path[:level_offset]
        new_path: list[str | int] = []
        for pi in wallet_key_path[::-1]:
            if not len(poppath):
                new_path.append(pi)
            else:
                new_path.append(poppath.pop())
        new_path = new_path[::-1]
    else:
        new_path = deepcopy(path)

    # Replace variable names in path with corresponding values
    script_type_id = 0
    var_defaults: dict[str, str | int] = {
        "network": network,
        "account": account_id,
        "purpose": purpose,
        "coin_type": Network(network).bip44_cointype,
        "script_type": script_type_id,
        "cosigner_index": cosigner_id,
        "change": change,
        "address_index": address_index,
    }
    npath: list[str | int] = new_path
    for i, pi in enumerate(new_path):
        if not isinstance(pi, str):
            pi = str(pi)
        if pi in "mM":
            continue
        hardened = False
        varname = pi
        if pi[-1:] == "'" or (pi[-1:] in "HhPp" and pi[:-1].isdigit()):
            varname = pi[:-1]
            hardened = True
        if path_template[i][-1:] == "'":
            hardened = True
        new_varname = str(var_defaults[varname]) if varname in var_defaults else varname
        if new_varname == varname and not new_varname.isdigit():
            raise BKeyError(f"Variable {varname} not found in Key structure definitions in main.py")
        if varname == "address_index" and address_index is None:
            raise BKeyError("Please provide value for 'address_index' or 'path'")
        npath[i] = new_varname + ("'" if hardened else "")
    result_path = [str(x) for x in npath]
    if "None'" in result_path or "None" in result_path:
        raise BKeyError(f"Could not parse all variables in path {result_path}")
    return result_path


class Address:
    """Class to store, convert and analyse various address types as representation of public keys or scripts hashes."""

    @classmethod
    def parse(
        cls,
        address: str,
        compressed: bool | None = None,
        encoding: str | None = None,
        depth: int | None = None,
        change: int | None = None,
        address_index: int | None = None,
        network: str | None = None,
        network_overrides: dict[str, str] | None = None,
    ) -> Address:
        """Import an address to the Address class. Specify network if available, otherwise it will be derived from the
        address.

        :param address: Address to import
        :type address: str
        :param compressed: Is key compressed or not, default is None
        :type compressed: bool
        :param encoding: Address encoding. Default is base58 encoding.
        :type encoding: str
        :param depth: Level of depth in BIP32 key path
        :type depth: int
        :param change: Use 0 for normal address/key, and 1 for change address (for returned/change payments)
        :type change: int
        :param address_index: Index of address. Used in BIP32 key paths
        :type address_index: int
        :param network: Specify network filter, i.e.: flux, etc. Will trigger check if address is valid for this network
        :type network: str
        :param network_overrides: Override network settings for specific prefixes, i.e.: {"prefix_address_p2sh": "32"}.
            Used by settings in providers.json
        :type network_overrides: dict
        :return Address:
        """
        if encoding is None:
            encoding = "base58"
        addr_dict = deserialize_address(address, encoding=encoding, network=network)
        public_key_hash_bytes = addr_dict["public_key_hash_bytes"]
        prefix = addr_dict["prefix"]
        if network is None:
            addr_network = addr_dict["network"]
            if isinstance(addr_network, str):
                network = addr_network
        script_type = addr_dict["script_type"]
        hashed_data = public_key_hash_bytes if isinstance(public_key_hash_bytes, (str, bytes)) else b""
        prefix_val = prefix if isinstance(prefix, (str, bytes)) else None
        script_type_val = script_type if isinstance(script_type, str) else None
        encoding_val = addr_dict["encoding"]
        if not isinstance(encoding_val, str):
            encoding_val = "base58"
        return Address(
            hashed_data=hashed_data,
            prefix=prefix_val,
            script_type=script_type_val,
            compressed=compressed,
            encoding=encoding_val,
            depth=depth,
            change=change,
            address_index=address_index,
            network=network if network else DEFAULT_NETWORK,
            network_overrides=network_overrides,
        )

    def __init__(
        self,
        data: str | bytes = "",
        hashed_data: str | bytes = "",
        prefix: str | bytes | None = None,
        script_type: str | None = None,
        compressed: bool | None = None,
        encoding: str | None = None,
        witness_type: str | None = None,
        depth: int | None = None,
        change: int | None = None,
        address_index: int | None = None,
        network: str | Network = DEFAULT_NETWORK,
        network_overrides: dict[str, str] | None = None,
    ) -> None:
        """Initialize an Address object. Specify a public key, redeemscript or a hash.

        :param data: Public key, redeem script or other type of script.
        :type data: str, bytes
        :param hashed_data: Hash of a public key or script. Will be generated if 'data' parameter is provided
        :type hashed_data: str, bytes
        :param prefix: Address prefix. Use default network / script_type prefix if not provided
        :type prefix: str, bytes
        :param script_type: Type of script, i.e. p2sh or p2pkh.
        :type script_type: str
        :param encoding: Address encoding. Default is base58 encoding.
        :type encoding: str
        :param witness_type: Witness type. Only 'legacy' is supported for Flux.
        :type witness_type: str
        :param network: Flux network
        :type network: str, Network
        :param network_overrides: Override network settings for specific prefixes, i.e.: {"prefix_address_p2sh": "32"}.
            Used by settings in providers.json
        :type network_overrides: dict
        """
        self.network: Network = network if is_network(network) else Network(network)
        if not (data or hashed_data):
            raise BKeyError("Please specify data (public key or script) or hashed_data argument")
        self.data_bytes: bytes = to_bytes(data)
        self._data: str | None = None
        self.script_type: str | None = script_type
        self.encoding: str | None = encoding
        self.compressed: bool | None = compressed
        self.witver: int = 0
        if witness_type is None:
            witness_type = "legacy"
        self.witness_type: str = witness_type
        self.depth: int | None = depth
        self.change: int | None = change
        self.address_index: int | None = address_index

        if self.encoding is None:
            self.encoding = "base58"
        self.hash_bytes: bytes = to_bytes(hashed_data)
        self.prefix: bytes | None = None
        self.redeemscript: bytes = b""
        if not self.hash_bytes:
            self.hash_bytes = hash160(self.data_bytes)
        self._hashed_data: str | None = None
        if self.encoding == "base58":
            if self.script_type is None:
                self.script_type = "p2pkh"
            if prefix is None:
                if self.script_type in ["p2sh", "p2sh_multisig"]:
                    self.prefix = self.network.prefix_address_p2sh
                else:
                    self.prefix = self.network.prefix_address
            else:
                self.prefix = to_bytes(prefix) if isinstance(prefix, (str, bytes)) else None
        else:
            raise BKeyError(f"Encoding {self.encoding} not supported")
        self.address: str = pubkeyhash_to_addr(
            self.hash_bytes,
            prefix=self.prefix,
            encoding=self.encoding,
            witver=self.witver,
        )
        self.address_orig: str | None = None
        provider_prefix: str | None = None
        if network_overrides and "prefix_address_p2sh" in network_overrides and self.script_type == "p2sh":
            provider_prefix = network_overrides["prefix_address_p2sh"]
        self.address_orig = self.address
        if provider_prefix:
            self.address = addr_convert(self.address, provider_prefix)

    def __repr__(self) -> str:
        return f"<Address(address={self.address})>"

    @property
    def hashed_data(self) -> str:
        if not self._hashed_data:
            self._hashed_data = self.hash_bytes.hex()
        return self._hashed_data

    @property
    def data(self) -> str:
        if not self._data:
            self._data = self.data_bytes.hex()
        return self._data

    def as_dict(self) -> dict[str, str | bytes | int | bool | None]:
        """Get current Address class as dictionary. Byte values are represented by hexadecimal strings.

        :return dict:
        """
        addr_dict = deepcopy(self.__dict__)
        del addr_dict["data_bytes"]
        del addr_dict["hash_bytes"]
        if isinstance(addr_dict["network"], Network):
            addr_dict["network"] = addr_dict["network"].name
        addr_dict["redeemscript"] = addr_dict["redeemscript"].hex()
        addr_dict["prefix"] = addr_dict["prefix"]
        return addr_dict

    def as_json(self) -> str:
        """Get current key as json formatted string.

        :return str:
        """
        adict = self.as_dict()
        return json.dumps(adict, indent=4)

    def with_prefix(self, prefix: str | bytes) -> str:
        """Convert address using another prefix.

        :param prefix: Address prefix
        :type prefix: str, bytes
        :return str: Converted address
        """
        return addr_convert(self.address, prefix)


class Key:
    """Class to generate, import and convert public cryptographic key pairs.

    If no key is specified when creating class a cryptographically secure Private Key is generated using the
    os.urandom() function.
    """

    @staticmethod
    def from_wif(wif: str, network: str | Network | None = None) -> Key:
        """Import private key in WIF format.

        :param wif: Private key in WIF format
        :type wif: str
        :param network: Network name
        :type network: str, Network
        :return Key:
        """
        key_hex = change_base(wif, 58, 16)
        if not isinstance(key_hex, str):
            raise BKeyError("Could not create key, wif format not recognised")
        networks = network_by_value("prefix_wif", key_hex[:2])
        compressed = False
        if networks:
            if key_hex[-10:-8] == "01":
                compressed = True
            network = network or next(iter(networks), DEFAULT_NETWORK)
        else:
            raise BKeyError("Could not create key, wif format not recognised")
        return Key(wif, network, compressed, is_private=True)

    def __init__(
        self,
        import_key: str | int | bytes | None = None,
        network: str | Network | None = None,
        compressed: bool = True,
        password: str = "",
        is_private: bool | None = None,
        strict: bool = True,
    ) -> None:
        """Initialize a Key object. Import key can be in WIF, bytes, hexstring, etc. If import_key is empty a new
        private key will be generated.

        If a private key is imported a public key will be derived. If a public is imported the private key data will
        be empty.

        Both compressed and uncompressed key version is available, the compressed boolean attribute tells if the
        original imported key was compressed or not.

        >>> k = Key('cNUpWJbC1hVJtyxyV4bVAnb4uJ7FPhr82geo1vnoA29XWkeiiCQn')
        >>> k.secret
        12127227708610754620337553985245292396444216111803695028419544944213442390363

        Can also be used to import BIP-38 password protected keys

        >>> k2 = Key('6PYM8wAnnmAK5mHYoF7zqj88y5HtK7eiPeqPdu4WnYEFkYKEEoMFEVfuDg', password='test', network='testnet')
        >>> k2.secret
        12127227708610754620337553985245292396444216111803695028419544944213442390363

        :param import_key: If specified import given private or public key. If not specified a new private key
            is generated.
        :type import_key: str, int, bytes
        :param network: Network name
        :type network: str, Network
        :param compressed: Is key compressed or not, default is True
        :type compressed: bool
        :param password: Optional password if imported key is password protected
        :type password: str
        :param is_private: Specify if imported key is private or public. Default is None: derive from provided key
        :type is_private: bool
        :param strict: Raise BKeyError if key is invalid. Default is True. Set to False if you're parsing
            blockchain transactions, as some may contain invalid keys, but the transaction is/was still valid.
        :type strict: bool

        :return: Key object
        """
        self.public_hex: str | None = None
        self._public_uncompressed_hex: str | None = None
        self.public_compressed_hex: str | None = None
        self.public_byte: bytes | None = None
        self._public_uncompressed_byte: bytes | None = None
        self.public_compressed_byte: bytes | None = None
        self.private_byte: bytes | None = None
        self.private_hex: str | None = None
        self._x: int | None = None
        self._y: int | None = None
        self.x_hex: str | None = None
        self.y_hex: str | None = None
        self.secret: int | None = None
        self.compressed: bool = compressed
        self._hash160: bytes | None = None
        self.key_format: str | None = None
        self.is_private: bool | None = None
        self._address_obj: Address | None = None
        self._wif: str | None = None
        self._wif_prefix: bytes | None = None

        networks_extracted: list[str] | None = None

        if isinstance(import_key, (int, float)) and import_key == 0:
            raise BKeyError("Private key cannot be zero")
        if not import_key:
            import_key = secrets.randbelow(secp256k1_n - 1) + 1
            self.key_format = "decimal"
            if is_private is not None and is_private is not True:
                raise BKeyError("Key generated randomly must be private")
            self.is_private = True  # Ignore provided attribute
        else:
            try:
                kf = get_key_format(import_key)
            except BKeyError as err:
                if strict:
                    raise BKeyError("Unrecognised key format") from err
                networks_extracted = []
            else:
                if kf["format"] == "address":
                    raise BKeyError("Can not create Key object from address")
                kf_format = kf["format"]
                if isinstance(kf_format, str):
                    self.key_format = kf_format
                kf_networks = kf["networks"]
                if isinstance(kf_networks, list):
                    networks_extracted = [s for s in kf_networks if isinstance(s, str)]
                else:
                    networks_extracted = None
                kf_is_private = kf["is_private"]
                if is_private:
                    self.is_private = is_private
                elif isinstance(kf_is_private, bool):
                    self.is_private = kf_is_private
                else:
                    self.is_private = None
                if self.is_private is None:
                    raise BKeyError("Could not determine if key is private or public")

        if network is not None:
            if is_network(network):
                self.network: Network = network
            else:
                self.network = Network(network)
        elif isinstance(networks_extracted, list) and networks_extracted:
            self.network = Network(check_network_and_key(import_key, None, networks_extracted))
        else:
            self.network = Network(DEFAULT_NETWORK)

        if self.key_format == "wif_protected":
            if isinstance(import_key, str):
                import_key_bytes, self.compressed = self._bip38_decrypt(import_key, password, network)
                import_key = import_key_bytes
            self.key_format = "bin_compressed" if self.compressed else "bin"

        if not self.is_private:
            self.secret = None
            if isinstance(import_key, int):
                pub_key = to_hexstring(str(import_key))
            elif isinstance(import_key, (str, bytes)):
                pub_key = to_hexstring(import_key)
            else:
                pub_key = ""
            if len(pub_key) == 130:
                self._public_uncompressed_hex = pub_key
                self.x_hex = pub_key[2:66]
                self.y_hex = pub_key[66:130]
                self._y = int(self.y_hex, 16)
                self.compressed = False
                prefix = "03" if self._y % 2 else "02"
                self.public_hex = pub_key
                self.public_compressed_hex = prefix + self.x_hex
            else:
                self.public_hex = pub_key
                self.x_hex = pub_key[2:66]
                self.compressed = True
                self._x = int(self.x_hex, 16)
                self.public_compressed_hex = pub_key
            self.public_compressed_byte = bytes.fromhex(self.public_compressed_hex)
            if self._public_uncompressed_hex:
                self._public_uncompressed_byte = bytes.fromhex(self._public_uncompressed_hex)
            if self.compressed:
                self.public_byte = self.public_compressed_byte
            else:
                self.public_byte = self.public_uncompressed_byte
        elif self.is_private and self.key_format == "decimal":
            self.secret = int(import_key)
            if self.secret < 1 or self.secret >= secp256k1_n:
                raise BKeyError("Private key must be in range [1, secp256k1_n)")
            private_hex_raw = change_base(self.secret, 10, 16, 64)
            if isinstance(private_hex_raw, str):
                self.private_hex = private_hex_raw
                self.private_byte = bytes.fromhex(self.private_hex)
        elif self.is_private:
            key_hex: str = ""
            key_byte: bytes = b""
            if self.key_format == "hex":
                if isinstance(import_key, str):
                    key_hex = import_key
                    key_byte = bytes.fromhex(key_hex)
            elif self.key_format == "hex_compressed":
                if isinstance(import_key, str):
                    key_hex = import_key[:-2]
                    key_byte = bytes.fromhex(key_hex)
                self.compressed = True
            elif self.key_format == "bin":
                if isinstance(import_key, bytes):
                    key_byte = import_key
                    key_hex = key_byte.hex()
            elif self.key_format == "bin_compressed":
                if isinstance(import_key, bytes):
                    key_byte = import_key
                    if len(import_key) in [33, 65, 129] and import_key[-1:] == b"\1":
                        key_byte = import_key[:-1]
                    key_hex = key_byte.hex()
                self.compressed = True
            elif self.is_private and self.key_format in ["wif", "wif_compressed"]:
                # Check and remove Checksum, prefix and postfix tags
                key_raw = change_base(import_key, 58, 256)
                if not isinstance(key_raw, bytes):
                    raise BKeyError("Cannot decode WIF key")
                checksum = key_raw[-4:]
                key_raw = key_raw[:-4]
                if checksum != double_sha256(key_raw)[:4]:
                    raise BKeyError("Invalid checksum, not a valid WIF key")
                found_networks = network_by_value("prefix_wif", key_raw[0:1].hex())
                if not len(found_networks):
                    raise BKeyError(f"Unrecognised WIF private key, version byte unknown. Versionbyte: {key_raw[0:1]}")
                if isinstance(import_key, str):
                    self._wif = import_key
                self._wif_prefix = key_raw[0:1]
                if key_raw[-1:] == b"\x01":
                    self.compressed = True
                    key_raw = key_raw[:-1]
                else:
                    self.compressed = False
                key_byte = key_raw[1:]
                key_hex = key_byte.hex()
            else:
                raise BKeyError(f"Unknown key format {self.key_format}")

            if not (key_byte or key_hex):
                raise BKeyError("Cannot format key in hex or byte format")
            self.private_hex = key_hex
            self.private_byte = key_byte
            self.secret = int(key_hex, 16)
            if self.secret < 1 or self.secret >= secp256k1_n:
                raise BKeyError("Private key must be in range [1, secp256k1_n)")
        else:
            raise BKeyError("Cannot import key. Public key format unknown")

        if self.is_private and not (self.public_byte or self.public_hex):
            if not self.is_private:
                raise BKeyError("Private key has no known secret number")
            if self.secret is None:
                raise BKeyError("Private key has no known secret number")
            p = ec_point(self.secret)
            self._x, self._y = _pubkey_point(p)
            x_hex_raw = change_base(self._x, 10, 16, 64)
            y_hex_raw = change_base(self._y, 10, 16, 64)
            if not isinstance(x_hex_raw, str) or not isinstance(y_hex_raw, str):
                raise BKeyError("Cannot convert public key point to hex")
            self.x_hex = x_hex_raw
            self.y_hex = y_hex_raw
            prefix = "03" if self._y % 2 else "02"

            self.public_compressed_hex = prefix + self.x_hex
            self._public_uncompressed_hex = "04" + self.x_hex + self.y_hex
            self.public_hex = self.public_compressed_hex if self.compressed else self.public_uncompressed_hex

            self.public_compressed_byte = bytes.fromhex(self.public_compressed_hex)
            self._public_uncompressed_byte = bytes.fromhex(self._public_uncompressed_hex)
            self.public_byte = self.public_compressed_byte if self.compressed else self.public_uncompressed_byte

    def __repr__(self) -> str:
        return f"<Key(public_hex={self.public_hex}, network={self.network.name})>"

    def __str__(self) -> str:
        return self.public_hex or ""

    def __bytes__(self) -> bytes:
        return self.public_byte or b""

    def __add__(self, other: Key | bytes) -> bytes:
        other_bytes = bytes(other) if isinstance(other, Key) else other
        return (self.public_byte or b"") + other_bytes

    def __radd__(self, other: Key | bytes) -> bytes:
        other_bytes = bytes(other) if isinstance(other, Key) else other
        return other_bytes + (self.public_byte or b"")

    def __len__(self) -> int:
        return len(self.public_byte or b"")

    def __eq__(self, other: object) -> bool:
        if other is None or not isinstance(other, Key):
            return False
        if self.is_private and other.is_private:
            return self.private_hex == other.private_hex
        return self.public_hex == other.public_hex

    def __hash__(self) -> int:
        if self.is_private:
            return hash(self.private_byte)
        return hash(self.public_byte)

    def __int__(self) -> int:
        if self.is_private and self.secret is not None:
            return self.secret
        return 0

    @property
    def x(self) -> int | None:
        if not self._x and self.x_hex:
            self._x = int(self.x_hex, 16)
        return self._x

    @property
    def y(self) -> int | None:
        if not self._y:
            if not self.y_hex:
                self._public_uncompressed_hex = self.public_uncompressed_hex
            if self.y_hex:
                self._y = int(self.y_hex, 16)
        return self._y

    @property
    def public_uncompressed_hex(self) -> str:
        if not self._public_uncompressed_hex:
            # Calculate y from x with y=x^3 + 7 function
            if self.public_hex is None:
                return ""
            sign = self.public_hex[:2] == "03"
            if self._x is None:
                return ""
            ys = (pow(self._x, 3, secp256k1_p) + 7) % secp256k1_p
            self._y = mod_sqrt(ys)
            if self._y & 1 != sign:
                self._y = secp256k1_p - self._y
            y_hex_val = change_base(self._y, 10, 16, 64)
            if isinstance(y_hex_val, str):
                self.y_hex = y_hex_val
            self._public_uncompressed_hex = "04" + (self.x_hex or "") + (self.y_hex or "")
        return self._public_uncompressed_hex

    @property
    def public_uncompressed_byte(self) -> bytes:
        if not self._public_uncompressed_byte:
            self._public_uncompressed_byte = bytes.fromhex(self.public_uncompressed_hex)
        return self._public_uncompressed_byte

    def hex(self) -> str:
        return self.public_hex or ""

    def as_dict(self, include_private: bool = False) -> collections.OrderedDict[str, str | int | bool | None]:
        """Get current Key class as dictionary. Byte values are represented by hexadecimal strings.

        :param include_private: Include private key information in dictionary
        :type include_private: bool
        :return collections.OrderedDict:
        """

        key_dict: collections.OrderedDict[str, str | int | bool | None] = collections.OrderedDict()
        key_dict["network"] = self.network.name
        key_dict["key_format"] = self.key_format
        key_dict["compressed"] = self.compressed
        key_dict["is_private"] = self.is_private
        if include_private:
            key_dict["private_hex"] = self.private_hex
            key_dict["secret"] = self.secret
            key_dict["wif"] = self.wif()
        key_dict["public_hex"] = self.public_hex
        key_dict["public_uncompressed_hex"] = self.public_uncompressed_hex
        key_dict["hash160"] = self.hash160.hex()
        key_dict["address"] = self.address()
        x, y = self.public_point()
        key_dict["point_x"] = x
        key_dict["point_y"] = y
        return key_dict

    def as_json(self, include_private: bool = False) -> str:
        """Get current key as json formatted string.

        :param include_private: Include private key information in dictionary
        :type include_private: bool
        :return str:
        """
        return json.dumps(self.as_dict(include_private=include_private), indent=4)

    @staticmethod
    def _bip38_decrypt(
        encrypted_privkey: str,
        password: str,
        network: str | Network | None = DEFAULT_NETWORK,
    ) -> tuple[bytes, bool]:
        """
        BIP0038 non-ec-multiply decryption. Returns WIF private key.
        Based on code from https://github.com/nomorecoin/python-bip38-testing
        This method is called by Key class init function when importing BIP0038 key.

        :param encrypted_privkey: Encrypted private key using WIF protected key format
        :type encrypted_privkey: str
        :param password: Required password for decryption
        :type password: str

        :return str: Private Key WIF
        """
        priv, addresshash, compressed = bip38_decrypt(encrypted_privkey, password)

        # Verify addresshash
        k = Key(priv, compressed=compressed, network=network)
        addr = k.address()
        addr_bytes = addr.encode("utf-8")
        if double_sha256(addr_bytes)[0:4] != addresshash:
            raise BKeyError(
                f"Addresshash verification failed! Password or specified network {network} might be incorrect"
            )
        return priv, compressed

    def encrypt(self, password: str) -> str:
        """
        BIP0038 non-ec-multiply encryption. Returns BIP0038 encrypted private key
        Based on code from https://github.com/nomorecoin/python-bip38-testing

        >>> k = Key('cNUpWJbC1hVJtyxyV4bVAnb4uJ7FPhr82geo1vnoA29XWkeiiCQn')
        >>> k.encrypt('test')
        '6PYM8wAnnmAK5mHYoF7zqj88y5HtK7eiPeqPdu4WnYEFkYKEEoMFEVfuDg'

        :param password: Required password for encryption
        :type password: str

        :return str: BIP38 password encrypted private key
        """
        flagbyte = b"\xe0" if self.compressed else b"\xc0"
        if self.private_hex is None:
            raise BKeyError("No private key available for encryption")
        return bip38_encrypt(self.private_hex, self.address(), password, flagbyte)

    def wif(
        self,
        is_private: bool | None = None,
        child_index: int | None = None,
        prefix: str | bytes | None = None,
        witness_type: str | None = None,
        multisig: bool | None = None,
    ) -> str:
        """Get private Key in Wallet Import Format, steps: # Convert to Binary and add 0x80 hex # Calculate Double
        SHA256 and add as checksum to end of key.

        :param prefix: Specify versionbyte prefix in hexstring or bytes. Normally doesn't need to be specified, method
            uses default prefix from network settings
        :type prefix: str, bytes
        :return str: Base58Check encoded Private Key WIF
        """
        if not self.secret:
            raise BKeyError("WIF format not supported for public key")
        if prefix is None:
            versionbyte = self.network.prefix_wif
        else:
            versionbyte = bytes.fromhex(prefix) if not isinstance(prefix, bytes) else prefix

        if self._wif and self._wif_prefix == versionbyte:
            return self._wif

        key = versionbyte + self.secret.to_bytes(32, byteorder="big")
        if self.compressed:
            key += b"\1"
        checksum = double_sha256(key)
        if isinstance(checksum, str):
            key += bytes.fromhex(checksum)[:4]
        else:
            key += checksum[:4]
        self._wif = base58encode(key)
        self._wif_prefix = versionbyte
        return self._wif

    def public(self) -> Self:
        """Get public version of current key. Removes all private information from current key.

        :return Key: Public key
        """
        key = deepcopy(self)
        key.is_private = False
        key.private_byte = None
        key.private_hex = None
        key.secret = None
        return key

    def public_point(self) -> tuple[int | None, int | None]:
        """Get public key point on Elliptic curve.

        :return tuple: (x, y) point
        """
        return (self.x, self.y)

    @property
    def hash160(self) -> bytes:
        """Get public key in RIPEMD-160 + SHA256 format.

        :return bytes:
        """
        if not self._hash160:
            key_data = self.public_byte if self.compressed else self.public_uncompressed_byte
            self._hash160 = hash160(key_data if key_data else b"")
        return self._hash160

    @property
    def address_obj(self) -> Address:
        """Get address object property. Create standard address object if not defined already.

        :return Address:
        """
        if not self._address_obj:
            self.address()
        if self._address_obj is None:
            raise BKeyError("Could not create address object")
        return self._address_obj

    def address(
        self,
        compressed: bool | None = None,
        prefix: str | bytes | None = None,
        script_type: str | None = None,
        encoding: str | None = None,
    ) -> str:
        """Get address derived from public key.

        :param compressed: Always return compressed address
        :type compressed: bool
        :param prefix: Specify versionbyte prefix in hexstring or bytes. Normally doesn't need to be specified, method
            uses default prefix from network settings
        :type prefix: str, bytes
        :param script_type: Type of script, i.e. p2sh or p2pkh.
        :type script_type: str
        :param encoding: Address encoding. Default is base58 encoding.
        :type encoding: str
        :return str: Base58 encoded address
        """
        if (self.compressed and compressed is None) or compressed:
            data = self.public_byte
            self.compressed = True
        else:
            data = self.public_uncompressed_byte
            self.compressed = False
        if encoding is None:
            encoding = self._address_obj.encoding if self._address_obj else "base58"
        if self._address_obj and script_type is None:
            script_type = self._address_obj.script_type
        if not (self._address_obj and self._address_obj.prefix == prefix and self._address_obj.encoding == encoding):
            self._address_obj = Address(
                data if data else b"",
                prefix=prefix,
                network=self.network,
                script_type=script_type,
                encoding=encoding,
                compressed=compressed,
            )
        return self._address_obj.address

    def address_uncompressed(
        self,
        prefix: str | bytes | None = None,
        script_type: str | None = None,
        encoding: str | None = None,
    ) -> str:
        """Get uncompressed address from public key.

        :param prefix: Specify versionbyte prefix in hexstring or bytes. Normally doesn't need to be specified, method
            uses default prefix from network settings
        :type prefix: str, bytes
        :param script_type: Type of script, i.e. p2sh or p2pkh.
        :type script_type: str
        :param encoding: Address encoding. Default is base58 encoding.
        :type encoding: str
        :return str: Base58 encoded address
        """
        return self.address(compressed=False, prefix=prefix, script_type=script_type, encoding=encoding)

    def info(self, include_private: bool = False) -> None:
        """Prints key information to standard output.

        :param include_private: Include private key details in output. Default is False (redacted).
        :type include_private: bool
        """

        print("KEY INFO")
        print(f" Network                     {self.network.name}")
        print(f" Compressed                  {self.compressed}")
        if self.secret:
            print("SECRET EXPONENT")
            if include_private:
                print(f" Private Key (hex)              {self.private_hex}")
                print(f" Private Key (long)             {self.secret}")
                if isinstance(self, HDKey):
                    print(f" Private Key (wif)              {self.wif_key()}")
                else:
                    print(f" Private Key (wif)              {self.wif()}")
            else:
                print(" Private Key (hex)              <redacted>")
                print(" Private Key (long)             <redacted>")
                print(" Private Key (wif)              <redacted>")
        else:
            print("PUBLIC KEY ONLY, NO SECRET EXPONENT")
        print("PUBLIC KEY")
        print(f" Public Key (hex)            {self.public_hex}")
        print(f" Public Key uncompr. (hex)   {self.public_uncompressed_hex}")
        print(f" Public Key Hash160          {self.hash160.hex()}")
        print(f" Address (b58)               {self.address()}")
        point_x, point_y = self.public_point()
        print(f" Point x                     {point_x}")
        print(f" Point y                     {point_y}")


class HDKey(Key):
    """Class for Hierarchical Deterministic keys as defined in BIP0032.

    Besides a private or public key a HD Key has a chain code, allowing to create a structure of related keys.

    The structure and key-path are defined in BIP0043 and BIP0044.
    """

    @staticmethod
    def from_seed(
        import_seed: bytearray,
        key_type: str = "bip32",
        network: str | Network = DEFAULT_NETWORK,
        compressed: bool = True,
        encoding: str | None = None,
        witness_type: str = DEFAULT_WITNESS_TYPE,
        multisig: bool = False,
    ) -> HDKey:
        """Used by class init function, import key from seed.

        :param import_seed: Private key seed as wipeable bytearray
        :type import_seed: bytearray
        :param key_type: Specify type of key, default is BIP32
        :type key_type: str
        :param network: Network to use
        :type network: str, Network
        :param compressed: Is key compressed or not, default is True
        :type compressed: bool
        :param encoding: Encoding used for address. Default is base58.
        :type encoding: str
        :param witness_type: Witness type used when creating scripts. Only 'legacy' is supported.
        :type witness_type: str
        :param multisig: Specify if key is part of multisig wallet, used when creating key representations such as WIF
            and addresses
        :type multisig: bool
        :return HDKey:
        """
        i = hmac.new(b"Bitcoin seed", import_seed, hashlib.sha512).digest()
        key = i[:32]
        chain = i[32:]
        key_int = int.from_bytes(key, "big")
        if key_int >= secp256k1_n:
            raise BKeyError("Key int value cannot be greater than secp256k1_n")
        # checking to see if this needs to be run in thread

        return HDKey(
            key=key,
            chain=chain,
            network=network,
            key_type=key_type,
            compressed=compressed,
            encoding=encoding,
            witness_type=witness_type,
            multisig=multisig,
        )

    @staticmethod
    def from_passphrase(
        passphrase: str,
        password: str = "",
        network: str | Network = DEFAULT_NETWORK,
        key_type: str = "bip32",
        compressed: bool = True,
        encoding: str | None = None,
        witness_type: str = DEFAULT_WITNESS_TYPE,
        multisig: bool = False,
    ) -> HDKey:
        """Create key from Mnemonic passphrase.

        :param passphrase: Mnemonic passphrase, list of words as string seperated with a space character
        :type passphrase: str
        :param password: Password to protect passphrase
        :type password: str
        :param network: Network to use
        :type network: str, Network
        :param key_type: HD BIP32 or normal Private Key. Default is 'bip32'
        :type key_type: str
        :param compressed: Is key compressed or not, default is True
        :type compressed: bool
        :param encoding: Encoding used for address. Default is base58.
        :type encoding: str
        :param witness_type: Witness type used when creating scripts. Only 'legacy' is supported.
        :type witness_type: str
        :param multisig: Specify if key is part of multisig wallet, used when creating key representations such as WIF
            and addresses
        :type multisig: bool
        :return HDKey:
        """
        seed = Mnemonic().to_seed(passphrase, password)
        try:
            return HDKey.from_seed(
                seed,
                network=network,
                key_type=key_type,
                compressed=compressed,
                encoding=encoding,
                witness_type=witness_type,
                multisig=multisig,
            )
        finally:
            secure_wipe(seed)

    @staticmethod
    def from_wif(
        wif: str,
        network: str | Network | None = None,
        compressed: bool = True,
        multisig: bool | None = None,
    ) -> HDKey:
        """Create HDKey from BIP32 WIF.

        :param wif: HDKey WIF
        :type wif: str
        :param network: Network to use as string
        :type network: str
        :param compressed: Is key compressed or not, default is True
        :type compressed: bool
        :param multisig: Specify if key is part of multisig wallet, used when creating key representations such as WIF
            and addresses
        :type multisig: bool
        :return HDKey:
        """
        bkey = change_base(wif, 58, 256)
        if not isinstance(bkey, bytes):
            raise BKeyError("Invalid BIP32 HDkey WIF. Cannot decode")
        if len(bkey) != 82:
            raise BKeyError("Invalid BIP32 HDkey WIF. Length must be 82 characters")

        if ord(bkey[45:46]):
            is_private = False
            key = bkey[45:78]
        else:
            is_private = True
            key = bkey[46:78]
        depth = ord(bkey[4:5])
        parent_fingerprint = bkey[5:9]
        child_index = int.from_bytes(bkey[9:13], "big")
        chain = bkey[13:45]

        key_hex = bkey.hex()
        network_str: str | None = network.name if isinstance(network, Network) else network
        prefix_data = wif_prefix_search(key_hex[:8], network=network_str, multisig=multisig)
        if not prefix_data:
            raise BKeyError("Invalid BIP32 HDkey WIF. Cannot find prefix in network definitions")

        networks = list(dict.fromkeys([str(n["network"]) for n in prefix_data]))
        if not network_str and networks:
            network_str = networks[0]
        elif network_str not in networks:
            raise BKeyError(f"Network {network_str} not found in list of derived networks {networks}")

        witness_type_raw = next(iter(list(dict.fromkeys([n["witness_type"] for n in prefix_data]))), None)
        witness_type: str | None = str(witness_type_raw) if witness_type_raw is not None else None
        multisig_raw = next(iter(list(dict.fromkeys([n["multisig"] for n in prefix_data]))), None)
        if multisig is None:
            multisig = bool(multisig_raw) if multisig_raw is not None else None

        return HDKey(
            key=key,
            chain=chain,
            depth=depth,
            parent_fingerprint=parent_fingerprint,
            child_index=child_index,
            is_private=is_private,
            network=network_str,
            witness_type=witness_type,
            multisig=multisig if multisig is not None else False,
            compressed=compressed,
        )

    def __init__(
        self,
        import_key: str | bytes | int | Key | None = None,
        key: bytes | None = None,
        chain: bytes | None = None,
        depth: int = 0,
        parent_fingerprint: bytes = b"\0\0\0\0",
        child_index: int = 0,
        is_private: bool = True,
        network: str | Network | None = None,
        key_type: str = "bip32",
        password: str = "",
        compressed: bool = True,
        encoding: str | None = None,
        witness_type: str | None = None,
        multisig: bool = False,
    ) -> None:
        """Hierarchical Deterministic Key class init function.

        If no import_key is specified a key will be generated with systems cryptographically random function.
        Import key can be any format normal or HD key (extended key) accepted by get_key_format.
        If a normal key with no chain part is provided, a chain with only 32 0-bytes will be used.

        >>> private_hex = '221ff330268a9bb5549a02c801764cffbc79d5c26f4041b26293a425fd5b557c'
        >>> k = HDKey(private_hex)
        >>> k  # doctest: +SKIP
        <HDKey(public_hex=..., wif_public=..., network=bitcoin)>

        :param import_key: HD Key to import in WIF format or as byte with key (32 bytes) and chain (32 bytes)
        :type import_key: str, bytes, int
        :param key: Private or public key (length 32)
        :type key: bytes
        :param chain: A chain code (length 32)
        :type chain: bytes
        :param depth: Level of depth in BIP32 key path
        :type depth: int
        :param parent_fingerprint: 4-byte fingerprint of parent
        :type parent_fingerprint: bytes
        :param child_index: Index number of child as integer
        :type child_index: int
        :param is_private: True for private, False for public key. Default is True
        :type is_private: bool
        :param network: Network name. Derived from import_key if possible
        :type network: str, Network
        :param key_type: HD BIP32 or normal Private Key. Default is 'bip32'
        :type key_type: str
        :param password: Optional password if imported key is password protected
        :type password: str
        :param compressed: Is key compressed or not, default is True
        :type compressed: bool
        :param encoding: Encoding used for address. Default is base58.
        :type encoding: str
        :param witness_type: Witness type used when creating scripts. Only 'legacy' is supported.
        :type witness_type: str
        :param multisig: Specify if key is part of multisig wallet, used when creating key representations
            such as WIF and addresses
        :type multisig: bool

        :return HDKey:
        """

        if not encoding and witness_type:
            encoding = get_encoding_from_witness(witness_type)
        self.script_type: str = script_type_default(witness_type, multisig) or "p2pkh"

        # if (key and not chain) or (not key and chain):
        #     raise BKeyError("Please specify both key and chain, use import_key attribute "
        #                     "or use simple Key class instead")
        if not key:
            if not import_key:
                # Generate new Master Key
                seed = secrets.token_bytes(64)
                key, chain = self._key_derivation(seed)
            # If key is 64 bytes long assume a HD Key with key and chain part
            elif isinstance(import_key, bytes) and len(import_key) == 64:
                key = import_key[:32]
                chain = import_key[32:]
            elif isinstance(import_key, Key):
                if not import_key.compressed:
                    _logger.warning("Uncompressed private keys are not standard for BIP32 keys, use at your own risk!")
                    compressed = False
                chain = chain if chain else b"\0" * 32
                if not import_key.private_byte:
                    raise BKeyError("Cannot import public Key in HDKey")
                key = import_key.private_byte
                key_type = "private"
            else:
                kf = get_key_format(import_key)
                if kf["format"] == "address":
                    raise BKeyError("Can not create HDKey object from address")
                kf_script_types = kf["script_types"]
                if isinstance(kf_script_types, list) and len(kf_script_types) == 1:
                    st = kf_script_types[0]
                    if isinstance(st, str):
                        self.script_type = st
                kf_witness_types = kf["witness_types"]
                if isinstance(kf_witness_types, list) and len(kf_witness_types) == 1 and not witness_type:
                    wt = kf_witness_types[0]
                    if isinstance(wt, str):
                        witness_type = wt
                        encoding = get_encoding_from_witness(witness_type)
                kf_multisig = kf["multisig"]
                if isinstance(kf_multisig, list) and len(kf_multisig) == 1:
                    ms = kf_multisig[0]
                    if isinstance(ms, bool):
                        multisig = ms
                kf_networks = kf["networks"]
                kf_networks_list: list[str] | None = None
                if isinstance(kf_networks, list):
                    kf_networks_list = [s for s in kf_networks if isinstance(s, str)]
                network_name: str | None = None
                if isinstance(network, Network):
                    network_name = network.name
                elif isinstance(network, str):
                    network_name = network
                network = Network(check_network_and_key(import_key, network_name, kf_networks_list))
                if kf["format"] in ["hdkey_private", "hdkey_public"]:
                    bkey = change_base(import_key, 58, 256)
                    if not isinstance(bkey, bytes):
                        raise BKeyError("Cannot decode HDKey WIF")
                    # Derive key, chain, depth, child_index and fingerprint part from extended key WIF
                    if ord(bkey[45:46]):
                        is_private = False
                        key = bkey[45:78]
                    else:
                        key = bkey[46:78]
                    depth = ord(bkey[4:5])
                    parent_fingerprint = bkey[5:9]
                    child_index = int.from_bytes(bkey[9:13], "big")
                    chain = bkey[13:45]
                elif kf["format"] == "mnemonic":
                    raise BKeyError("Use HDKey.from_passphrase() method to parse a passphrase")
                elif kf["format"] == "wif_protected":
                    if isinstance(import_key, str) and isinstance(network, Network):
                        key, compressed = self._bip38_decrypt(
                            import_key,
                            password,
                            network.name,
                            witness_type if witness_type else DEFAULT_WITNESS_TYPE,
                        )
                    chain = chain if chain else b"\0" * 32
                    key_type = "private"
                else:
                    if isinstance(import_key, (str, bytes)):
                        key = import_key if isinstance(import_key, bytes) else import_key.encode()
                    elif isinstance(import_key, int):
                        key = import_key.to_bytes(32, "big")
                    chain = chain if chain else b"\0" * 32
                    kf_is_private = kf["is_private"]
                    if isinstance(kf_is_private, bool):
                        is_private = kf_is_private
                    key_type = "private" if is_private else "public"

        if chain is None:
            chain = b"\0" * 32

        if witness_type is None:
            witness_type = DEFAULT_WITNESS_TYPE

        super().__init__(key, network, compressed, password, is_private)

        self.encoding: str | None = encoding
        self.witness_type: str = witness_type
        self.multisig: bool = multisig

        self.chain: bytes = chain
        self.depth: int = depth
        self.parent_fingerprint: bytes = parent_fingerprint
        self.child_index: int = child_index
        self.key_type: str = key_type

    def __repr__(self) -> str:
        return f"<HDKey(public_hex={self.public_hex}, wif_public={self.wif_public()}, network={self.network.name})>"

    def info(self, include_private: bool = False) -> None:
        """Prints key information to standard output."""
        super().info()

        print("EXTENDED KEY")
        print(f" Key Type                    {self.key_type}")
        print(f" Chain code (hex)            {self.chain.hex()}")
        print(f" Child Index                 {self.child_index}")
        print(f" Parent Fingerprint (hex)    {self.parent_fingerprint.hex()}")
        print(f" Depth                       {self.depth}")
        print(f" Extended Public Key (wif)   {self.wif_public()}")
        print(f" Witness type                {self.witness_type}")
        print(f" Script type                 {self.script_type}")
        print(f" Multisig                    {self.multisig}")
        if self.is_private:
            print(f" Extended Private Key (wif)  {self.wif(is_private=True)}")
        print("\n")

    def as_dict(self, include_private: bool = False) -> collections.OrderedDict[str, str | int | bool | None]:
        """Get current HDKey class as dictionary. Byte values are represented by hexadecimal strings.

        :param include_private: Include private key information in dictionary
        :type include_private: bool
        :return collections.OrderedDict:
        """

        key_dict = super().as_dict()
        if include_private:
            key_dict["fingerprint"] = self.fingerprint.hex()
            key_dict["chain_code"] = self.chain.hex()
            key_dict["fingerprint_parent"] = self.parent_fingerprint.hex()
        key_dict["child_index"] = self.child_index
        key_dict["depth"] = self.depth
        key_dict["extended_wif_public"] = self.wif_public()
        if include_private:
            key_dict["extended_wif_private"] = self.wif(is_private=True)
        return key_dict

    def as_json(self, include_private: bool = False) -> str:
        """Get current key as json formatted string.

        :param include_private: Include private key information in dictionary
        :type include_private: bool
        :return str:
        """
        return json.dumps(self.as_dict(include_private=include_private), indent=4)

    def _key_derivation(self, seed: bytes) -> tuple[bytes, bytes]:
        """Derive extended private key with key and chain part from seed.

        :param seed:
        :type seed: bytes
        :return tuple: key and chain bytes
        """
        chain = hasattr(self, "chain") and self.chain or b"Bitcoin seed"
        i = hmac.new(chain, seed, hashlib.sha512).digest()
        key = i[:32]
        chain = i[32:]
        key_int = int.from_bytes(key, "big")
        if key_int >= secp256k1_n:
            raise BKeyError("Key cannot be greater than secp256k1_n. Try another index number.")
        return key, chain

    @property
    def fingerprint(self) -> bytes:
        """
        Get key fingerprint: the last for bytes of the hash160 of this key.

        :return bytes:
        """

        return self.hash160[:4]

    @staticmethod
    def _bip38_decrypt(
        encrypted_privkey: str,
        password: str,
        network: str | Network | None = DEFAULT_NETWORK,
        witness_type: str = DEFAULT_WITNESS_TYPE,
    ) -> tuple[bytes, bool]:
        """
        BIP0038 non-ec-multiply decryption. Returns WIF private key.
        Based on code from https://github.com/nomorecoin/python-bip38-testing
        This method is called by Key class init function when importing BIP0038 key.

        :param encrypted_privkey: Encrypted private key using WIF protected key format
        :type encrypted_privkey: str
        :param password: Required password for decryption
        :type password: str

        :return str: Private Key WIF
        """
        priv, addresshash, compressed = bip38_decrypt(encrypted_privkey, password)
        # compressed = True if priv[-1:] == b'\1' else False

        # Verify addresshash
        net_str: str = DEFAULT_NETWORK
        if isinstance(network, Network):
            net_str = network.name
        elif isinstance(network, str):
            net_str = network
        k = HDKey(priv, compressed=compressed, network=net_str, witness_type=witness_type)
        addr = k.address()
        addr_bytes = addr.encode("utf-8")
        if double_sha256(addr_bytes)[0:4] != addresshash:
            raise BKeyError(
                f"Addresshash verification failed! Password or specified network {net_str} might be incorrect"
            )
        return priv, compressed

    def wif(
        self,
        is_private: bool | None = None,
        child_index: int | None = None,
        prefix: str | bytes | None = None,
        witness_type: str | None = None,
        multisig: bool | None = None,
    ) -> str:
        """Get Extended WIF of current key.

        >>> private_hex = '221ff330268a9bb5549a02c801764cffbc79d5c26f4041b26293a425fd5b557c'
        >>> k = HDKey(private_hex)
        >>> k.wif()
        'xpub661MyMwAqRbcEYS8w7XLSVeEsBXy79zSzH1J8vCdxAZningWLdN3zgtU6SmypHzZG2cYrwpGkWJqRxS6EAW77gd7CHFoXNpBd3LN8xjAyCW'

        :param is_private: Return public or private key
        :type is_private: bool
        :param child_index: Change child index of output WIF key
        :type child_index: int
        :param prefix: Specify version prefix in hexstring or bytes. Normally doesn't need to be specified,
            method uses default prefix from network settings
        :type prefix: str, bytes
        :param witness_type: Specify witness type, default is legacy.
        :type witness_type: str
        :param multisig: Key is part of a multisignature wallet?
        :type multisig: bool

        :return str: Base58 encoded WIF key
        """

        if not witness_type:
            witness_type = DEFAULT_WITNESS_TYPE if not self.witness_type else self.witness_type
        if not multisig:
            multisig = False if not self.multisig else self.multisig

        rkey: bytes = self.private_byte or self.public_compressed_byte or b""
        prefix_as_bytes: bytes | None = None
        if prefix is not None:
            prefix_as_bytes = prefix if isinstance(prefix, bytes) else bytes.fromhex(prefix)
        prefix_bytes: bytes
        if self.is_private and is_private:
            if prefix_as_bytes is None:
                prefix_bytes = self.network.wif_prefix(is_private=True, witness_type=witness_type, multisig=multisig)
            else:
                prefix_bytes = prefix_as_bytes
            typebyte = b"\x00"
        else:
            if prefix_as_bytes is None:
                prefix_bytes = self.network.wif_prefix(witness_type=witness_type, multisig=multisig)
            else:
                prefix_bytes = prefix_as_bytes
            typebyte = b""
            if not is_private:
                rkey = self.public_byte or b""
        if child_index:
            self.child_index = child_index
        raw = (
            prefix_bytes
            + self.depth.to_bytes(1, "big")
            + self.parent_fingerprint
            + self.child_index.to_bytes(4, "big")
            + self.chain
            + typebyte
            + rkey
        )
        chk_raw = double_sha256(raw)
        chk = bytes.fromhex(chk_raw)[:4] if isinstance(chk_raw, str) else chk_raw[:4]
        ret = raw + chk
        result = change_base(ret, 256, 58, 111)
        if isinstance(result, str):
            return result
        return str(result)

    def wif_key(self, prefix: str | bytes | None = None) -> str:
        """Get WIF of Key object. Call to parent object Key.wif()

        :param prefix: Specify versionbyte prefix in hexstring or bytes. Normally doesn't need to be specified, method
            uses default prefix from network settings
        :type prefix: str, bytes
        :return str: Base58Check encoded Private Key WIF
        """
        return super().wif(prefix=prefix)

    def wif_public(
        self,
        prefix: str | bytes | None = None,
        witness_type: str | None = None,
        multisig: bool | None = None,
    ) -> str:
        """Get Extended WIF public key. Wrapper for the :func:`wif` method.

        :param prefix: Specify version prefix in hexstring or bytes. Normally doesn't need to be specified, method uses
            default prefix from network settings
        :type prefix: str, bytes
        :param witness_type: Specify witness type, default is legacy.
        :type witness_type: str
        :param multisig: Key is part of a multisignature wallet?
        :type multisig: bool
        :return str: Base58 encoded WIF key
        """
        return self.wif(
            is_private=False,
            prefix=prefix,
            witness_type=witness_type,
            multisig=multisig,
        )

    def wif_private(
        self,
        prefix: str | bytes | None = None,
        witness_type: str | None = None,
        multisig: bool | None = None,
    ) -> str:
        """Get Extended WIF private key. Wrapper for the :func:`wif` method.

        :param prefix: Specify version prefix in hexstring or bytes. Normally doesn't need to be specified, method uses
            default prefix from network settings
        :type prefix: str, bytes
        :param witness_type: Specify witness type, default is legacy.
        :type witness_type: str
        :param multisig: Key is part of a multi signature wallet?
        :type multisig: bool
        :return str: Base58 encoded WIF key
        """
        return self.wif(is_private=True, prefix=prefix, witness_type=witness_type, multisig=multisig)

    def address(
        self,
        compressed: bool | None = None,
        prefix: str | bytes | None = None,
        script_type: str | None = None,
        encoding: str | None = None,
    ) -> str:
        """Get address derived from public key.

        >>> wif = ('xpub661MyMwAqRbcFcXi3aM3fVdd42FGDSdufhrr5tdobiPjMrPUykFMTdaFEr7y'
        ...        'oy1xxeifDY8kh2k4h9N77MY6rk18nfgg5rPtbFDF2YHzLfA')
        >>> k = HDKey.from_wif(wif)
        >>> k.address()
        '15CacK61qnzJKpSpx9PFiC8X1ajeQxhq8a'

        :param compressed: Always return compressed address
        :type compressed: bool
        :param prefix: Specify versionbyte prefix in hexstring or bytes. Normally doesn't need to be
            specified, method uses default prefix from network settings
        :type prefix: str, bytes
        :param script_type: Type of script, i.e. p2sh or p2pkh.
        :type script_type: str
        :param encoding: Address encoding. Default is base58 encoding.
        :type encoding: str

        :return str: Base58 or Bech32 encoded address
        """
        if compressed is None:
            compressed = self.compressed
        if script_type is None:
            script_type = self.script_type
        if encoding is None:
            encoding = self.encoding
        return super().address(compressed, prefix, script_type, encoding)

    def subkey_for_path(self, path: str | list[str], network: str | None = None) -> HDKey:
        """
        Determine subkey for HD Key for given path.
        Path format: m / purpose' / coin_type' / account' / change / address_index

        See BIP0044 bitcoin proposal for more explanation.

        >>> wif = ('xprv9s21ZrQH143K4LvcS93AHEZh7gBiYND6zMoRiZQGL5wqbpCU2KJDY87Txuv'
        ...        '9dduk9hAcsL76F8b5JKzDREf8EmXjbUwN1c4nR9GEx56QGg2')
        >>> k = HDKey.from_wif(wif)
        >>> k.subkey_for_path("m/44'/0'/0'/0/2")  # doctest: +SKIP
        <HDKey(public_hex=03004331..., wif_public=xpub6GyQo..., network=bitcoin)>

        :param path: BIP0044 key path
        :type path: str, list
        :param network: Network name.
        :type network: str

        :return HDKey: HD Key class object of subkey
        """

        if isinstance(path, str):
            path = path.split("/")
        if self.key_type == "single":
            raise BKeyError("Key derivation cannot be used for 'single' type keys")
        key = self
        first_public = False
        if path[0] == "m":  # Use Private master key
            path = path[1:]
        elif path[0] == "M":  # Use Public master key
            path = path[1:]
            first_public = True
        if path:
            if len(path) > 1:
                _logger.info("Path length > 1 can be slow for larger paths, use Wallet Class to generate keys paths")
            for item in path:
                if not item:
                    raise BKeyError("Could not parse path. Index is empty.")
                hardened = item[-1] in "'HhPp"
                if hardened:
                    item = item[:-1]
                index = int(item)
                if index < 0:
                    raise BKeyError("Could not parse path. Index must be a positive integer.")
                if first_public or not key.is_private:
                    # Public keys cannot derive hardened children (requires private key)
                    key = key.child_public(index=index, network=network)
                    first_public = False
                else:
                    key = key.child_private(index=index, hardened=hardened, network=network)
        return key

    def public_master(
        self,
        account_id: int = 0,
        purpose: int | None = None,
        multisig: bool | None = None,
        witness_type: str | None = None,
        as_private: bool = False,
    ) -> HDKey:
        """Derives a public master key for current HDKey. A public master key can be shared with other software
        administration tools to create readonly wallets or can be used to create multisignature wallets.

        >>> private_hex = 'b66ed9778029d32ebede042c79f448da8f7ab9efba19c63b7d3cdf6925203b71'
        >>> k = HDKey(private_hex)
        >>> pm = k.public_master()
        >>> pm.wif()
        'xpub6CjFexgdDZEtHdW7V4LT8wS9rtG3m187pM9qhTpoZdViFhSv3tW9sWonQNtFN1TCkRGAQGKj1UC2ViHTqb7vJV3X67xSKuCDzv14tBHR3Y7'

        :param account_id: Account ID. Leave empty for account 0
        :type account_id: int
        :param purpose: BIP standard used, i.e. 44 for default, 45 for multisig. Derived from witness_type
            and multisig arguments if not provided
        :type purpose: int
        :param multisig: Key is part of a multisignature wallet?
        :type multisig: bool
        :param witness_type: Specify witness type, default is legacy.
        :type witness_type: str
        :param as_private: Return private key if available. Default is to return public key

        :return HDKey:
        """
        if multisig:
            self.multisig = multisig
        if witness_type:
            self.witness_type = witness_type
        ks = [
            k
            for k in WALLET_KEY_STRUCTURES
            if k["witness_type"] == self.witness_type and k["multisig"] == self.multisig and k["purpose"] is not None
        ]
        if len(ks) > 1:
            raise BKeyError(
                "Please check definitions in WALLET_KEY_STRUCTURES. Multiple options found for "
                "witness_type - multisig combination"
            )
        if ks and not purpose:
            ks_purpose = ks[0]["purpose"]
            if isinstance(ks_purpose, int):
                purpose = ks_purpose
        ks_key_path = ks[0]["key_path"]
        if isinstance(ks_key_path, list):
            path_template: list[str] = [str(s) for s in ks_key_path]
        else:
            raise BKeyError("Invalid key path template")

        # Use last hardened key as public master root
        pm_depth = path_template.index([x for x in path_template if x[-1:] == "'"][-1]) + 1
        path_input: list[str | int] = list(path_template[:pm_depth])
        path = path_expand(
            path_input,
            path_template,
            account_id=account_id,
            purpose=purpose if purpose is not None else 44,
            witness_type=self.witness_type,
            network=self.network.name,
        )
        if as_private:
            return self.subkey_for_path(path)
        return self.subkey_for_path(path).public()

    def public_master_multisig(
        self,
        account_id: int = 0,
        purpose: int | None = None,
        witness_type: str | None = None,
        as_private: bool = False,
    ) -> HDKey:
        """Derives a public master key for current HDKey for use with multi signature wallets. Wrapper for the
        :func:`public_master` method.

        :param account_id: Account ID. Leave empty for account 0
        :type account_id: int
        :param purpose: BIP standard used, i.e. 44 for default, 45 for multisig.
        :type purpose: int
        :param witness_type: Specify witness type, default is legacy.
        :type witness_type: str
        :param as_private: Return private key if available. Default is to return public key
        :return HDKey:
        """

        return self.public_master(account_id, purpose, True, witness_type, as_private)

    def network_change(self, new_network: str) -> bool:
        """Change network for current key.

        :param new_network: Name of new network
        :type new_network: str
        :return bool: True
        """
        self.network = Network(new_network)
        return True

    def child_private(self, index: int = 0, hardened: bool = False, network: str | None = None) -> HDKey:
        """Use Child Key Derivation (CDK) to derive child private key of current HD Key object.

        Used by :func:`subkey_for_path` to create key paths for instance to use in HD wallets. You can use
        this method to create your own key structures.

        This method create private child keys, use :func:`child_public` to create public child keys.

        >>> private_hex = 'd02220828cad5e0e0f25057071f4dae9bf38720913e46a596fd7eb8f83ad045d'
        >>> k = HDKey(private_hex)
        >>> ck = k.child_private(10)
        >>> ck.address()
        '1FgHK5JUa87ASxz5mz3ypeaUV23z9yW654'
        >>> ck.depth
        1
        >>> ck.child_index
        10

        :param index: Key index number
        :type index: int
        :param hardened: Specify if key must be hardened (True) or normal (False)
        :type hardened: bool
        :param network: Network name.
        :type network: str

        :return HDKey: HD Key class object
        """

        if network is None:
            network = self.network.name
        if not self.is_private:
            raise BKeyError("Need a private key to create child private key")
        if self.private_byte is None:
            raise BKeyError("Private key bytes not available")
        if self.public_byte is None:
            raise BKeyError("Public key bytes not available")
        if self.secret is None:
            raise BKeyError("Secret not available")
        if hardened:
            index |= 0x80000000
            data = b"\0" + self.private_byte + index.to_bytes(4, "big")
        else:
            data = self.public_byte + index.to_bytes(4, "big")
        key, chain = self._key_derivation(data)

        key_int = int.from_bytes(key, "big")
        if key_int >= secp256k1_n:
            raise BKeyError("Key cannot be greater than secp256k1_n. Try another index number.")
        newkey = (key_int + self.secret) % secp256k1_n
        if newkey == 0:
            raise BKeyError("Key cannot be zero. Try another index number.")
        newkey_bytes = int.to_bytes(newkey, 32, "big")

        return HDKey(
            key=newkey_bytes,
            chain=chain,
            depth=self.depth + 1,
            parent_fingerprint=self.fingerprint,
            child_index=index,
            witness_type=self.witness_type,
            multisig=self.multisig,
            encoding=self.encoding,
            network=network,
        )

    def child_public(self, index: int = 0, network: str | None = None) -> HDKey:
        """Use Child Key Derivation to derive child public key of current HD Key object.

        Used by :func:`subkey_for_path` to create key paths for instance to use in HD wallets. You can use
        this method to create your own key structures.

        This method create public child keys, use :func:`child_private` to create private child keys.

        >>> private_hex = 'd02220828cad5e0e0f25057071f4dae9bf38720913e46a596fd7eb8f83ad045d'
        >>> k = HDKey(private_hex)
        >>> ck = k.child_public(15)
        >>> ck.address()
        '1PfLJJgKs8nUbMPpaQUucbGmr8qyNSMGeK'
        >>> ck.depth
        1
        >>> ck.child_index
        15

        :param index: Key index number
        :type index: int
        :param network: Network name.
        :type network: str

        :return HDKey: HD Key class object
        """
        if network is None:
            network = self.network.name
        if index > 0x80000000:
            raise BKeyError("Cannot derive hardened key from public private key. Index must be less than 0x80000000")
        if self.public_byte is None:
            raise BKeyError("Public key bytes not available")
        data = self.public_byte + index.to_bytes(4, "big")
        key, chain = self._key_derivation(data)
        key_int = int.from_bytes(key, "big")
        if key_int >= secp256k1_n:
            raise BKeyError("Key cannot be greater than secp256k1_n. Try another index number.")

        x, y = self.public_point()
        if x is None or y is None:
            raise BKeyError("Cannot derive child public key: public point not available")
        # Add EC points: ec_point(key) + parent_public_key
        child_pk = ec_point(key_int)
        parent_pk = coincurve.PublicKey(_point_to_uncompressed_bytes(x, y))
        ki = coincurve.PublicKey.combine_keys([child_pk, parent_pk])
        ki_x, ki_y = _pubkey_point(ki)

        prefix = "03" if ki_y % 2 else "02"
        xhex = change_base(ki_x, 10, 16, 64)
        if not isinstance(xhex, str):
            raise BKeyError("Cannot convert child public key x coordinate")
        secret = bytes.fromhex(prefix + xhex)
        return HDKey(
            key=secret,
            chain=chain,
            depth=self.depth + 1,
            parent_fingerprint=self.fingerprint,
            child_index=index,
            is_private=False,
            witness_type=self.witness_type,
            multisig=self.multisig,
            encoding=self.encoding,
            network=network,
        )

    def public(self) -> Self:
        """Public version of current private key. Strips all private information from HDKey object, returns deepcopy
        version of current object.

        :return HDKey:
        """

        hdkey = deepcopy(self)
        hdkey.is_private = False
        hdkey.secret = None
        hdkey.private_hex = None
        hdkey.private_byte = None
        return hdkey


class Signature:
    """Signature class for transactions. Used to create signatures to sign transaction and verification.

    Sign a transaction hash with a private key and show DER encoded signature:

    >>> sk = HDKey('f2620684cef2b677dc2f043be8f0873b61e79b274c7e7feeb434477c082e0dc2')
    >>> txid = 'c77545c8084b6178366d4e9a06cf99a28d7b5ff94ba8bd76bbbce66ba8cdef70'
    >>> signature = sign(txid, sk)
    >>> signature.as_der_encoded().hex()
    '3044022015f9d39d8b53c68c7549d5dc4cbdafe1c71bae3656b93a02d2209e413d9bbcd00220615cf626da0a81945a707f42814cc51ecde499442eb31913a870b9401af6a4ba01'
    """

    @classmethod
    def parse(cls, signature: bytes | str, public_key: HDKey | Key | str | bytes | None = None) -> Signature | None:
        if isinstance(signature, bytes):
            return cls.parse_bytes(signature, public_key)
        if isinstance(signature, str):
            return cls.parse_hex(signature, public_key)
        return None

    @classmethod
    def parse_hex(cls, signature: str, public_key: HDKey | Key | str | bytes | None = None) -> Signature:
        return cls.parse_bytes(bytes.fromhex(signature), public_key)

    @staticmethod
    def parse_bytes(signature: bytes, public_key: HDKey | Key | str | bytes | None = None) -> Signature:
        """Create a signature from signature string with r and s part. Signature length must be 64 bytes or 128
        character hexstring.

        :param signature: Signature string
        :type signature: bytes
        :param public_key: Public key as HDKey or Key object or any other string accepted by HDKey object
        :type public_key: HDKey, Key, str, hexstring, bytes
        :return Signature:
        """

        der_signature: str | bytes = ""
        hash_type = SIGHASH_ALL
        sig_data: bytes | str = signature
        if len(signature) > 64 and signature.startswith(b"\x30"):
            der_signature = signature[:-1]
            hash_type = int.from_bytes(signature[-1:], "big")
            sig_data = convert_der_sig(signature[:-1], as_hex=False)
        if not isinstance(sig_data, bytes):
            raise BKeyError("Signature must be bytes after DER conversion")
        signature = sig_data
        if len(signature) != 64:
            raise BKeyError("Signature length must be 64 bytes or 128 character hexstring")
        r = int.from_bytes(signature[:32], "big")
        s = int.from_bytes(signature[32:], "big")
        return Signature(
            r,
            s,
            signature=signature,
            der_signature=der_signature,
            public_key=public_key,
            hash_type=hash_type,
        )

    @staticmethod
    def create(
        txid: bytes | str,
        private: HDKey | Key | int | str | bytes,
        use_rfc6979: bool = True,
    ) -> Signature:
        """Sign a transaction hash and create a signature with provided private key.

        >>> k = 'b2da575054fb5daba0efde613b0b8e37159b8110e4be50f73cbe6479f6038f5b'
        >>> txid = '0d12fdc4aac9eaaab9730999e0ce84c3bd5bb38dfd1f4c90c613ee177987429c'
        >>> sig = Signature.create(txid, k)
        >>> sig.hex()
        '48e994862e2cdb372149bad9d9894cf3a5562b4565035943efe0acc502769d351cb88752b5fe8d70d85f3541046df617f8459e991d06a7c0db13b5d4531cd6d4'
        >>> sig.r
        32979225540043540145671192266052053680452913207619328973512110841045982813493
        >>> sig.s
        12990793585889366641563976043319195006380846016310271470330687369836458989268

        :param txid: Transaction signature or transaction hash. If unhashed transaction or message is
            provided the double_sha256 hash of message will be calculated.
        :type txid: bytes, str
        :param private: Private key as HDKey or Key object, or any other string accepted by HDKey object
        :type private: HDKey, Key, str, hexstring, bytes
        :param use_rfc6979: Use deterministic value for k nonce to derive k from txid/message according to
            RFC6979 standard. Default is True, set to False to use random k
        :type use_rfc6979: bool
        :param k: Provide own k. Only use for testing or if you know what you are doing. Providing wrong
            value for k can result in leaking your private key!
        :type k: int

        :return Signature:
        """
        if isinstance(txid, bytes):
            txid = txid.hex()
        if len(txid) > 64:
            txid = double_sha256(bytes.fromhex(txid), as_hex=True)
        if not isinstance(txid, str):
            raise BKeyError("Cannot convert txid to hex string")
        if not isinstance(private, (Key, HDKey)):
            private = HDKey(private)
        pub_key = private.public()
        secret = private.secret
        if secret is None:
            raise BKeyError("No secret key available for signing")

        txid_bytes = bytes.fromhex(txid)
        sk = coincurve.PrivateKey(secret.to_bytes(32, "big"))
        sig_der = sk.sign(txid_bytes, hasher=None)
        # Extract r, s from DER-encoded signature
        signature_hex = convert_der_sig(sig_der)
        if not isinstance(signature_hex, str):
            raise BKeyError("Cannot convert DER signature to hex")
        r = int(signature_hex[:64], 16)
        s = int(signature_hex[64:], 16)
        # Enforce low-s (BIP62)
        if s > secp256k1_n // 2:
            s = secp256k1_n - s
        return Signature(r, s, txid, public_key=pub_key)

    def __init__(
        self,
        r: int,
        s: int,
        txid: bytes | str | None = None,
        signature: str | bytes | None = None,
        der_signature: str | bytes | None = None,
        public_key: HDKey | Key | str | bytes | None = None,
        hash_type: int = SIGHASH_ALL,
    ) -> None:
        """Initialize Signature object with provided r and r value.

        >>> r = 32979225540043540145671192266052053680452913207619328973512110841045982813493
        >>> s = 12990793585889366641563976043319195006380846016310271470330687369836458989268
        >>> sig = Signature(r, s)
        >>> sig.hex()
        '48e994862e2cdb372149bad9d9894cf3a5562b4565035943efe0acc502769d351cb88752b5fe8d70d85f3541046df617f8459e991d06a7c0db13b5d4531cd6d4'

        :param r: r value of signature
        :type r: int
        :param s: s value of signature
        :type s: int
        :param txid: Transaction hash z to sign if known
        :type txid: bytes, hexstring
        :param secret: Private key secret number
        :type secret: int
        :param signature: r and s value of signature as string
        :type signature: str, bytes
        :param der_signature: DER encoded signature
        :type der_signature: str, bytes
        :param public_key: Provide public key P if known
        :type public_key: HDKey, Key, str, hexstring, bytes
        :param k: k value used for signature
        :type k: int
        """

        self.r: int = int(r)
        self.s: int = int(s)
        self.x: int | None = None
        self.y: int | None = None
        if self.r < 1 or self.r >= secp256k1_n:
            raise BKeyError("Invalid Signature: r is not a positive integer smaller than the curve order")
        if self.s < 1 or self.s >= secp256k1_n:
            raise BKeyError("Invalid Signature: s is not a positive integer smaller than the curve order")
        self._txid: str | None = None
        self.txid = txid
        if isinstance(signature, bytes):
            self._signature: bytes = signature
            signature = signature.hex()
        else:
            self._signature = to_bytes(signature) if isinstance(signature, str) else b""
        if signature and len(signature) != 128:
            raise BKeyError("Invalid Signature: length must be 64 bytes")
        self._public_key: HDKey | Key | None = None
        self.public_key = public_key
        self.hash_type: int = hash_type
        self.hash_type_byte: bytes = self.hash_type.to_bytes(1, "big")
        self.der_signature: str | bytes = der_signature if der_signature else ""
        if not der_signature:
            self.der_signature = der_encode_sig(self.r, self.s)

        if isinstance(der_signature, (str, bytes)):
            self._der_encoded: bytes = to_bytes(der_signature) + self.hash_type_byte
        else:
            self._der_encoded = b""

    def __repr__(self) -> str:
        der_sig = "" if not self._der_encoded else self._der_encoded.hex()
        return f"<Signature(r={self.r}, s={self.s}, signature={self.hex()}, der_signature={der_sig})>"

    def __str__(self) -> str:
        result = self.as_der_encoded(as_hex=True)
        if isinstance(result, str):
            return result
        return result.hex()

    def __bytes__(self) -> bytes:
        result = self.as_der_encoded()
        if isinstance(result, bytes):
            return result
        return bytes.fromhex(result)

    def __add__(self, other: Signature | bytes) -> bytes:
        other_bytes = bytes(other) if isinstance(other, Signature) else other
        return bytes(self) + other_bytes

    def __radd__(self, other: Signature | bytes) -> bytes:
        other_bytes = bytes(other) if isinstance(other, Signature) else other
        return other_bytes + bytes(self)

    def __len__(self) -> int:
        return len(bytes(self))

    @property
    def txid(self) -> str | None:
        return self._txid

    @txid.setter
    def txid(self, value: bytes | str | None) -> None:
        if value is not None:
            if isinstance(value, bytes):
                self._txid = value.hex()
            else:
                self._txid = value

    @property
    def public_key(self) -> HDKey | Key | None:
        """Return public key as HDKey object.

        :return HDKey:
        """
        return self._public_key

    @public_key.setter
    def public_key(self, value: HDKey | Key | str | bytes | None) -> None:
        if value is None:
            return
        if isinstance(value, bytes):
            value = HDKey(value)
        if isinstance(value, str):
            value = HDKey(value)
        if value.is_private:
            value = value.public()
        self.x, self.y = value.public_point()

        if self.x is not None and self.y is not None:
            try:
                coincurve.PublicKey(_point_to_uncompressed_bytes(self.x, self.y))
            except ValueError as err:
                raise BKeyError("Invalid public key, point is not on secp256k1 curve") from err
        self._public_key = value

    def hex(self) -> str:
        """Signature r and s value as single hexadecimal string.

        :return hexstring:
        """
        return self.as_bytes().hex()

    def __index__(self) -> bytes:
        return self.as_bytes()

    def as_bytes(self) -> bytes:
        """Signature r and s value as single bytes string.

        :return bytes:
        """

        if not self._signature:
            self._signature = self.r.to_bytes(32, "big") + self.s.to_bytes(32, "big")
        return self._signature

    @overload
    def as_der_encoded(self, as_hex: Literal[True], include_hash_type: bool = ...) -> str: ...
    @overload
    def as_der_encoded(self, as_hex: Literal[False] = ..., include_hash_type: bool = ...) -> bytes: ...
    def as_der_encoded(self, as_hex: bool = False, include_hash_type: bool = True) -> bytes | str:
        """Get DER encoded signature.

        :param as_hex: Output as hexstring
        :type as_hex: bool
        :param include_hash_type: Include hash_type byte at end of signatures as used in raw scripts. Default is True
        :type include_hash_type: bool
        :return bytes:
        """
        if not self._der_encoded or len(self._der_encoded) < 2:
            self._der_encoded = der_encode_sig(self.r, self.s) + self.hash_type_byte

        if include_hash_type:
            return self._der_encoded.hex() if as_hex else self._der_encoded
        return der_encode_sig(self.r, self.s).hex() if as_hex else der_encode_sig(self.r, self.s)

    def verify(
        self,
        txid: bytes | str | None = None,
        public_key: HDKey | Key | str | bytes | None = None,
    ) -> bool:
        """Verify this signature. Provide txid or public_key if not already known.

        >>> k = 'b2da575054fb5daba0efde613b0b8e37159b8110e4be50f73cbe6479f6038f5b'
        >>> pub_key = HDKey(k).public()
        >>> txid = '0d12fdc4aac9eaaab9730999e0ce84c3bd5bb38dfd1f4c90c613ee177987429c'
        >>> sig = ('48e994862e2cdb372149bad9d9894cf3a5562b4565035943efe0acc502769d35'
        ...        '1cb88752b5fe8d70d85f3541046df617f8459e991d06a7c0db13b5d4531cd6d4')
        >>> sig = Signature.parse_hex(sig)
        >>> sig.verify(txid, pub_key)
        True

        :param txid: Transaction hash
        :type txid: bytes, hexstring
        :param public_key: Public key P
        :type public_key: HDKey, Key, str, hexstring, bytes

        :return bool:
        """
        if txid is not None:
            self.txid = to_hexstring(txid)
        if public_key is not None:
            self.public_key = public_key

        if not self.txid or not self.public_key:
            raise BKeyError("Please provide txid and public_key to verify signature")

        transaction_to_sign = to_bytes(self.txid)
        if len(transaction_to_sign) != 32:
            transaction_to_sign = double_sha256(transaction_to_sign)
        if not isinstance(transaction_to_sign, bytes):
            raise BKeyError("Cannot convert transaction to bytes for verification")

        # Normalize to low-s for verification (BIP62)
        r = self.r
        s = self.s
        if s > secp256k1_n // 2:
            s = secp256k1_n - s

        # Build DER signature from r, s
        sig_der = der_encode_sig(r, s)

        pub_bytes = self.public_key.public_byte
        if pub_bytes is None:
            raise BKeyError("Public key bytes not available for verification")
        try:
            pk = coincurve.PublicKey(pub_bytes)
            return pk.verify(sig_der, transaction_to_sign, hasher=None)
        except ValueError:
            # Any signature/key validation failure means invalid signature
            return False


def sign(
    txid: bytes | str,
    private: HDKey | Key | int | str | bytes,
    use_rfc6979: bool = True,
) -> Signature:
    """Sign transaction hash or message with secret private key. Creates a signature object.

    Sign a transaction hash with a private key and show DER encoded signature

    >>> sk = HDKey('728afb86a98a0b60cc81faadaa2c12bc17d5da61b8deaf1c08fc07caf424d493')
    >>> txid = 'c77545c8084b6178366d4e9a06cf99a28d7b5ff94ba8bd76bbbce66ba8cdef70'
    >>> signature = sign(txid, sk)
    >>> signature.as_der_encoded().hex()
    '30440220792f04c5ba654e27eb636ceb7804c5590051dd77da8b80244f1fa8dfbff369b302204ba03b039c808a0403d067f3d75fbe9c65831444c35d64d4192b408d2a7410a101'

    :param txid: Transaction signature or transaction hash. If unhashed transaction or message is provided
        the double_sha256 hash of message will be calculated.
    :type txid: bytes, str
    :param private: Private key as HDKey or Key object, or any other string accepted by HDKey object
    :type private: HDKey, Key, str, hexstring, bytes
    :param use_rfc6979: Use deterministic value for k nonce to derive k from txid/message according to
        RFC6979 standard. Default is True, set to False to use random k
    :type use_rfc6979: bool
    :param k: Provide own k. Only use for testing or if you know what you are doing. Providing wrong value
        for k can result in leaking your private key!
    :type k: int

    :return Signature:
    """
    return Signature.create(txid, private, use_rfc6979)


def verify(
    txid: bytes | str,
    signature: Signature | str | bytes,
    public_key: HDKey | Key | str | bytes | None = None,
) -> bool:
    """Verify provided signature with txid message. If provided signature is no Signature object a new object will be
    created for verification.

    >>> k = 'b2da575054fb5daba0efde613b0b8e37159b8110e4be50f73cbe6479f6038f5b'
    >>> pub_key = HDKey(k).public()
    >>> txid = '0d12fdc4aac9eaaab9730999e0ce84c3bd5bb38dfd1f4c90c613ee177987429c'
    >>> sig = ('48e994862e2cdb372149bad9d9894cf3a5562b4565035943efe0acc502769d35'
    ...        '1cb88752b5fe8d70d85f3541046df617f8459e991d06a7c0db13b5d4531cd6d4')
    >>> verify(txid, sig, pub_key)
    True

    :param txid: Transaction hash
    :type txid: bytes, hexstring
    :param signature: signature as hexstring or bytes
    :type signature: str, bytes
    :param public_key: Public key P. If not provided it will be derived from provided Signature object or
        raise an error if not available
    :type public_key: HDKey, Key, str, hexstring, bytes

    :return bool:
    """
    if not isinstance(signature, Signature):
        if not public_key:
            raise BKeyError("No public key provided, cannot verify")
        parsed = Signature.parse(signature, public_key=public_key)
        if parsed is None:
            raise BKeyError("Cannot parse signature")
        signature = parsed
    return signature.verify(txid, public_key)


def _pubkey_point(pub: coincurve.PublicKey) -> tuple[int, int]:
    """Extract (x, y) integer coordinates from a coincurve PublicKey.

    :param pub: A coincurve PublicKey object
    :type pub: coincurve.PublicKey
    :return tuple: (x, y) as integers
    """
    uncompressed = pub.format(compressed=False)
    # Uncompressed key: 0x04 + 32-byte x + 32-byte y
    x = int.from_bytes(uncompressed[1:33], "big")
    y = int.from_bytes(uncompressed[33:65], "big")
    return x, y


def _point_to_uncompressed_bytes(x: int, y: int) -> bytes:
    """Convert (x, y) integer coordinates to uncompressed public key bytes (0x04 prefix).

    :param x: X coordinate
    :type x: int
    :param y: Y coordinate
    :type y: int
    :return bytes: 65-byte uncompressed public key
    """
    return b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big")


def ec_point(m: int) -> coincurve.PublicKey:
    """Method for elliptic curve multiplication on the secp256k1 curve. Multiply Generator point G by m.

    :param m: A scalar multiplier
    :type m: int
    :return coincurve.PublicKey: Public key representing Generator point G multiplied by m
    """
    m = int(m)
    # Reduce modulo curve order to handle oversized scalars
    m = m % secp256k1_n
    if m == 0:
        raise BKeyError("Invalid scalar for ec_point: zero after reduction")
    secret_bytes = m.to_bytes(32, "big")
    pk = coincurve.PrivateKey(secret_bytes)
    return pk.public_key


def mod_sqrt(a: int) -> int:
    """Compute the square root of 'a' using the secp256k1 'bitcoin' curve.

    Used to calculate y-coordinate if only x-coordinate from public key point is known.
    Formula: y ** 2 == x ** 3 + 7

    :param a: Number to calculate square root
    :type a: int

    :return int:
    """

    # Square root formula: k = (secp256k1_p - 3) // 4
    k = 28948022309329048855892746252171976963317496166410141009864396001977208667915
    return pow(a, k + 1, secp256k1_p)


# --- Bitcoin Message Signing ---

# Flux uses the Zelcash prefix for message signing (ZelID auth, SSP relay)
FLUX_MESSAGE_PREFIX = b"\x18Zelcash Signed Message:\n"


def sign_message(
    message: str | bytes,
    private_key: bytes | Key | HDKey,
    message_prefix: bytes = FLUX_MESSAGE_PREFIX,
) -> tuple[bytes, bytes]:
    """Sign a message using Bitcoin message signing with a configurable prefix.

    Used for SSP relay authentication and ZelID login.

    :param message: Message to sign (string or bytes)
    :param private_key: Private key as 32 bytes, Key, or HDKey
    :param message_prefix: Message prefix bytes (default: Flux/Zelcash prefix)
    :returns: (signature_65_bytes, compressed_pubkey_33_bytes)
    """
    if isinstance(message, str):
        message = message.encode("utf-8")

    private_key_bytes: bytes
    if isinstance(private_key, (Key, HDKey)):
        if private_key.private_byte is None:
            raise BKeyError("Private key bytes not available")
        private_key_bytes = private_key.private_byte
    else:
        private_key_bytes = private_key

    # Construct prefixed message: prefix + varint(len) + message
    msg_len = int_to_varbyteint(len(message))
    prefixed = message_prefix + msg_len + message

    # Double-SHA256 hash
    msg_hash = double_sha256(prefixed)
    if not isinstance(msg_hash, bytes):
        raise BKeyError("Cannot compute message hash")

    # Sign with recoverable signature (includes recovery ID for pubkey recovery)
    pk = coincurve.PrivateKey(private_key_bytes)
    # Returns 65 bytes: signature(64) + recovery_id(1)
    sig = pk.sign_recoverable(msg_hash, hasher=None)

    recovery_id = sig[64]
    # Bitcoin message format: (27 + 4 + recovery_id) | r(32) | s(32)
    # 27 = base, 4 = compressed key flag
    btc_sig = bytes([27 + 4 + recovery_id]) + sig[:64]

    return btc_sig, pk.public_key.format(compressed=True)


def verify_message(
    message: str | bytes,
    signature: bytes,
    address: str | None = None,
    public_key: bytes | None = None,
    message_prefix: bytes = FLUX_MESSAGE_PREFIX,
) -> bool:
    """Verify a Bitcoin message signature.

    Provide either an address or public key to verify against.

    :param message: Original message
    :param signature: 65-byte Bitcoin message signature
    :param address: Address to verify against (recovers pubkey from signature)
    :param public_key: Public key bytes to verify against
    :param message_prefix: Message prefix bytes
    :returns: True if signature is valid
    """
    if isinstance(message, str):
        message = message.encode("utf-8")

    msg_len = int_to_varbyteint(len(message))
    prefixed = message_prefix + msg_len + message
    msg_hash = double_sha256(prefixed)
    if not isinstance(msg_hash, bytes):
        return False

    # Extract recovery info from Bitcoin message signature
    recovery_flag = signature[0]
    compressed = recovery_flag >= 31
    recovery_id = (recovery_flag - 27) & 3
    raw_sig = signature[1:] + bytes([recovery_id])

    try:
        recovered_pubkey = coincurve.PublicKey.from_signature_and_message(raw_sig, msg_hash, hasher=None)
    except ValueError:
        # Malformed signature or unrecoverable public key
        return False

    if public_key:
        return recovered_pubkey.format(compressed=compressed) == public_key

    if address:
        recovered_hash = hash160(recovered_pubkey.format(compressed=compressed))
        # Decode address to get the hash160, accounting for variable prefix length
        addr_bytes = change_base(address, 58, 256)
        if not isinstance(addr_bytes, bytes):
            return False
        # Strip version prefix (1 or 2 bytes) and 4-byte checksum
        addr_hash = addr_bytes[len(addr_bytes) - 24 : -4]
        return recovered_hash == addr_hash

    return False


def derive_identity_key(
    master_key: HDKey,
    type_index: int = 11,
) -> HDKey:
    """Derive a FluxID identity key from a wallet master key.

    Uses the BTC identity chain (coin_type=0) at BIP48 path
    ``m/48'/0'/0'/0'`` then ``child(type_index)/child(0)``, producing a
    Bitcoin P2PKH address usable as a FluxID for FluxOS authentication.

    :param master_key: HD master key (depth 0, with private key)
    :param type_index: 10 for internal (relay auth), 11 for external (public FluxID)
    :returns: Identity HDKey with Bitcoin-network address
    """
    account_key = master_key.subkey_for_path("m/48'/0'/0'/0'")
    identity_key = account_key.subkey_for_path(f"{type_index}/0")

    return HDKey(
        key=identity_key.private_byte,
        chain=identity_key.chain,
        network="bitcoin",
    )
