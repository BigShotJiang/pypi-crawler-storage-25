#
#    fluxwallet - Python Cryptocurrency Library
#    SERVICES - Main Service connector
#    © 2017-2022 - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
from __future__ import annotations

import asyncio
import json
import logging
import secrets
import time
from pathlib import Path
from typing import TYPE_CHECKING, Protocol, TypeVar, runtime_checkable

import yarl

from fluxwallet import services
from fluxwallet.blocks import Block
from fluxwallet.config import (
    BLOCK_COUNT_CACHE_TIME,
    DEFAULT_NETWORK,
    FW_DATA_DIR,
    FW_INSTALL_DIR,
    MAX_TRANSACTIONS,
    SERVICE_MAX_ERRORS,
    TIMEOUT_REQUESTS,
    TYPE_TEXT,
)
from fluxwallet.exceptions import ServiceError as ServiceError
from fluxwallet.networks import Network
from fluxwallet.services.cache import ServiceCache
from fluxwallet.services.models import BroadcastResult, ProviderUtxo
from fluxwallet.transactions import FluxTransaction, transaction_update_spents

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Callable, Coroutine

_logger = logging.getLogger(__name__)


@runtime_checkable
class ProviderProtocol(Protocol):
    """Structural interface that all blockchain service providers must satisfy."""

    async def blockcount(self) -> int: ...
    async def getbalance(self, addresslist: str | list[str]) -> int: ...
    async def getutxos(self, address: str, after_txid: str = "", limit: int = 0) -> list[ProviderUtxo]: ...
    async def getutxos_multi(self, addresslist: list[str], limit: int = 0) -> list[ProviderUtxo]: ...
    async def gettransaction(self, txid: str) -> FluxTransaction: ...
    async def gettransactions(self, address: str, after_txid: str = "", limit: int = 50) -> list[FluxTransaction]: ...
    async def gettransactions_by_txids(self, txids: list[str]) -> tuple[list[FluxTransaction], list[str]]: ...
    def get_transactions_by_address(
        self, address: str, after_tx_index: int = 0, limit: int = 0
    ) -> AsyncGenerator[list[FluxTransaction]]: ...
    async def getrawtransaction(self, txid: str) -> str: ...
    async def sendrawtransaction(self, rawtx: str) -> BroadcastResult: ...
    async def estimatefee(self, blocks: int = 1) -> int: ...
    async def getblock(
        self,
        blockid: str | int,
        parse_transactions: bool = True,
        page: int = 1,
        limit: int = 0,
    ) -> dict[str, object]: ...
    async def close(self) -> None: ...


R = TypeVar("R")


class SingletonNetwork(type):
    _instances: dict[tuple[str | Network, bool], Service] = {}

    def __call__(
        cls,
        *args: str | int | bool | list[str] | None,
        **kwargs: str | int | bool | list[str] | Network | None,
    ) -> Service:
        raw_network = kwargs["network"]
        if not isinstance(raw_network, (str, Network)):
            raise TypeError("network must be str or Network")
        network: str | Network = raw_network
        raw_strict = kwargs.get("strict", False)
        strict: bool = bool(raw_strict)
        key: tuple[str | Network, bool] = (network, strict)

        if key not in cls._instances:
            cls._instances[key] = super().__call__(*args, **kwargs)

        return cls._instances[key]



def provider_url_for_capability(capability: str, network: str = DEFAULT_NETWORK) -> str:
    """Get the URL of the highest-priority provider with a given capability."""
    providers_defined = None
    for base_dir in (FW_DATA_DIR, Path(FW_INSTALL_DIR, "data")):
        fn = Path(base_dir, "providers.json")
        if fn.exists():
            try:
                with fn.open("r") as f:
                    providers_defined = json.loads(f.read())
            except json.decoder.JSONDecodeError as e:
                raise ServiceError(f"Error reading provider definitions from {fn}: {e}") from e
            break

    if providers_defined is None:
        raise ServiceError("providers.json not found in user config or bundled data")

    matches = [
        pdef
        for pdef in providers_defined.values()
        if (pdef.get("network") == network or pdef.get("network") == "") and capability in pdef.get("capabilities", [])
    ]

    if not matches:
        raise ServiceError(f"No provider with capability '{capability}' found for network {network}")

    matches.sort(key=lambda p: p.get("priority", 999))
    return matches[0]["url"]


class Service(metaclass=SingletonNetwork):
    """Class to connect to various cryptocurrency service providers. Use to receive network and blockchain information,
    get specific transaction information, current network fees or push a raw transaction.

    The Service class connects to 1 or more service providers at random to retrieve or send information. If a service
    providers fails to correctly respond the Service class will try another available provider.
    """

    def __init__(
        self,
        *,
        network: str | Network = DEFAULT_NETWORK,
        min_providers: int = 1,
        max_providers: int = 1,
        providers: list[str] | None = None,
        timeout: int = TIMEOUT_REQUESTS,
        cache_uri: str | None = None,
        ignore_priority: bool = False,
        exclude_providers: list[str] | None = None,
        max_errors: int = SERVICE_MAX_ERRORS,
        strict: bool = True,
    ) -> None:
        """Create a service object for the specified network. By default, the object connect to 1 service provider, but
        you can specify a list of providers or a minimum or maximum number of providers.

        :param network: Specify network used
        :type network: str, Network
        :param min_providers: Minimum number of providers to connect to. Default is 1. Use for instance to receive fee
            information from a number of providers and calculate the average fee.
        :type min_providers: int
        :param max_providers: Maximum number of providers to connect to. Default is 1.
        :type max_providers: int
        :param providers: List of providers to connect to. Default is all providers and select a provider at random.
        :type providers: list of str
        :param timeout: Timeout for web requests. Leave empty to use default from config settings
        :type timeout: int
        :param cache_uri: Database to use for caching
        :type cache_uri: str
        :param ignore_priority: Ignores provider priority if set to True. Could be used for unit testing, so no
            providers are missed when testing. Default is False
        :type ignore_priority: bool
        :param exclude_providers: Exclude providers in this list, can be used when problems with certain providers
            arise.
        :type exclude_providers: list of str
        :param strict: Strict checks of valid signatures, scripts and transactions. Normally use strict=True for
            wallets, transaction validations etcetera. For blockchain parsing strict=False should be used, but be sure
            to check warnings in the log file. Default is True.
        :type strict: bool
        """

        # this is used for blockcount - can only be called once at a time
        self.lock = asyncio.Lock()

        if not isinstance(network, Network):
            self.network = Network(network)
        else:
            self.network = network

        if min_providers > max_providers:
            max_providers = min_providers

        self.providers_defined = None
        for base_dir in (FW_DATA_DIR, Path(FW_INSTALL_DIR, "data")):
            fn = Path(base_dir, "providers.json")
            if fn.exists():
                try:
                    with fn.open("r") as f:
                        self.providers_defined = json.loads(f.read())
                except json.decoder.JSONDecodeError as e:  # pragma: no cover
                    errstr = f"Error reading provider definitions from {fn}: {e}"
                    _logger.warning(errstr)
                    raise ServiceError(errstr) from e
                break
        if self.providers_defined is None:
            raise ServiceError("providers.json not found in user config or bundled data")

        for pname, pdef in list(self.providers_defined.items()):
            url = pdef.get("url", "")
            if url:
                parsed = yarl.URL(url)
                if parsed.scheme and parsed.scheme not in ("http", "https"):
                    _logger.warning("Skipping provider %s: unsupported scheme (%s)", pname, url)
                    del self.providers_defined[pname]

        provider_list = [self.providers_defined[x]["provider"] for x in self.providers_defined]
        if providers is None:
            providers = []
        if exclude_providers is None:
            exclude_providers = []
        if not isinstance(providers, list):
            providers = [providers]
        for p in providers:
            if p not in provider_list:
                raise ServiceError(f"Provider '{p}' not found in provider definitions")

        self.providers = {}
        for p in self.providers_defined:
            if (self.providers_defined[p]["network"] == network or self.providers_defined[p]["network"] == "") and (
                not providers or self.providers_defined[p]["provider"] in providers
            ):
                self.providers.update({p: self.providers_defined[p]})
        for nop in exclude_providers:
            if nop in self.providers:
                del self.providers[nop]

        if not self.providers:
            raise ServiceError(f"No providers found for network {network}")
        self.min_providers = min_providers
        self.max_providers = max_providers
        self.results = {}
        self.errors = {}
        self.resultcount = 0
        self.max_errors = max_errors
        self.complete = None
        self.timeout = timeout
        self._blockcount_update = 0.0
        self._blockcount = 0
        self.cache_uri = cache_uri
        self._cache: ServiceCache = ServiceCache(self.network, db_uri="")

        try:
            self._cache = ServiceCache(self.network, db_uri=cache_uri or "")
        except (OSError, RuntimeError) as e:
            _logger.warning(f"Could not connect to cache database. Error: {e}")

        self.results_cache_n = 0
        self.ignore_priority = ignore_priority
        self.strict = strict

    def _reset_results(self) -> None:
        self.results = {}
        self.errors = {}
        self.complete = None
        self.resultcount = 0

    def _provider_order(self) -> list[str]:
        provider_lst = [
            p[0]
            for p in sorted(
                [(x, self.providers[x]["priority"]) for x in self.providers],
                key=lambda x: (x[1], secrets.SystemRandom().random()),
                reverse=True,
            )
        ]
        if self.ignore_priority:
            secrets.SystemRandom().shuffle(provider_lst)
        return provider_lst

    def _get_provider(self, sp: str) -> ProviderProtocol:
        client_module = getattr(services, self.providers[sp]["provider"])
        client_class = getattr(client_module, self.providers[sp]["client_class"])
        return client_class(
            self.network,
            self.providers[sp]["url"],
            self.providers[sp]["denominator"],
            self.providers[sp]["api_key"],
            self.providers[sp]["provider_coin_id"],
            self.providers[sp]["network_overrides"],
            self.timeout,
            self._blockcount,
            self.strict,
        )

    def _should_skip(self, sp: str) -> bool:
        if (
            sp not in ["bitcoind", "litecoind", "dashd", "dogecoind", "caching"]
            and not self.providers[sp]["url"]
            and self.network.name != "fluxwallet_test"
        ):
            return True
        return self.providers[sp]["api_key"] == "api-key-needed"

    async def _execute(self, caller: Callable[[ProviderProtocol], Coroutine[object, object, R]]) -> R:
        """Execute a typed provider method with failover across providers."""
        self._reset_results()

        for sp in self._provider_order():
            if self.resultcount >= self.max_providers:
                break
            if self._should_skip(sp):
                continue
            provider = self._get_provider(sp)
            try:
                res = await caller(provider)
                if res is False:
                    self.errors[sp] = "Received empty response"
                    continue
                self.results[sp] = res
                self.resultcount += 1
            except Exception as e:  # Catch-all: providers can raise arbitrary errors from HTTP, parsing, etc.
                err = e.msg if isinstance(e, ServiceError) else str(e)
                self.errors[sp] = err
                _logger.warning(f"Error from provider {sp}: {err}")
                if len(self.errors) >= self.max_errors:
                    _logger.warning(f"Aborting, max errors exceeded: {list(self.errors.keys())}")
                    if self.results:
                        return list(self.results.values())[0]
                    raise ServiceError(f"All service providers failed: {list(self.errors.keys())}") from e
            finally:
                await provider.close()

        if not self.resultcount:
            raise ServiceError(
                "No service provider responded successfully."
                " Recovery: check your network connection or try again",
                provider_errors=dict(self.errors),
            )

        return list(self.results.values())[0]

    async def getbalance(self, addresslist: list[str] | str, addresses_per_request: int = 5) -> int:
        """Get total balance for address or list of addresses.

        :param addresslist: Address or list of addresses
        :type addresslist: list, str
        :param addresses_per_request: Maximum number of addresses per request. Default is 5. Use lower setting when you
            experience timeouts or service request errors, or higher when possible.
        :type addresses_per_request: int
        :return dict: Balance per address
        """
        if isinstance(addresslist, str):
            addresslist = [addresslist]

        tot_balance = 0

        while addresslist:
            for address in addresslist:
                db_addr_result: dict[str, str | int | None] | None = await self._cache.getaddress(address)
                if db_addr_result is not None:
                    last_block = db_addr_result.get("last_block")
                    balance_val = db_addr_result.get("balance")
                    if (
                        last_block is not None
                        and isinstance(last_block, int)
                        and last_block >= await self.blockcount()
                        and balance_val is not None
                        and isinstance(balance_val, int)
                    ):
                        tot_balance += balance_val
                        addresslist.remove(address)

            al = addresslist[:addresses_per_request]
            balance = await self._execute(lambda p, _al=al: p.getbalance(_al))
            if balance:
                tot_balance += balance

            if len(addresslist) == 1:
                await self._cache.store_address(addresslist[0], balance=balance)

            addresslist = addresslist[addresses_per_request:]
        return tot_balance

    async def getutxos(self, address: str, after_txid: str = "", limit: int = MAX_TRANSACTIONS) -> list[ProviderUtxo]:
        """Get list of unspent outputs (UTXO's) for specified address.

        Sorted from old to new, so the highest number of confirmations first.

        :param address: Address string
        :type address: str
        :param after_txid: Transaction ID of last known transaction. Only check for utxos after given tx id. Default:
            Leave empty to return all utxos.
        :type after_txid: str
        :param limit: Maximum number of utxo's to return. Sometimes ignored by service providers if more results are
            returned by default.
        :type limit: int
        :return list: UTXO's for address
        """
        if not isinstance(address, TYPE_TEXT):
            raise ServiceError("Address parameter must be of type text")

        self.results_cache_n = 0
        self.complete = True


        utxos_cache: list[ProviderUtxo] = []
        if self.min_providers <= 1:
            raw_cache: list[dict[str, str | int | None]] = (
                await self._cache.getutxos(address, bytes.fromhex(after_txid)) or []
            )
            utxos_cache = [ProviderUtxo.model_validate(d) for d in raw_cache]

        if utxos_cache:
            self.results_cache_n = len(utxos_cache)

            # Last updated block does not always include spent info...
            after_txid = utxos_cache[-1].txid

        utxos = await self._execute(lambda p: p.getutxos(address, after_txid, limit))

        # Update cache_transactions_node
        tasks = []
        for utxo in utxos:
            tasks.append(self._cache.store_utxo(utxo.txid, utxo.output_n))

        await asyncio.gather(*tasks)

        if utxos and len(utxos) >= limit:
            self.complete = False
        elif not after_txid:
            balance = sum(u.value for u in utxos)
            await self._cache.store_address(address, balance=balance, n_utxos=len(utxos))

        return utxos_cache + utxos

    async def getutxos_multi(self, addresslist: list[str], limit: int = 0) -> list[ProviderUtxo]:
        """Get UTXOs for multiple addresses in a single API call.

        :param addresslist: List of address strings
        :param limit: Maximum UTXOs to return (0 = unlimited)
        :returns: List of ProviderUtxo objects
        """
        if not addresslist:
            return []
        return await self._execute(lambda p: p.getutxos_multi(addresslist, limit))

    async def get_transaction(self, txid: str) -> FluxTransaction:
        """Get a transaction by its transaction hash. Convert to fluxwallet Transaction object.

        :param txid: Transaction identification hash
        :type txid: str
        :return Transaction: A single transaction object
        """
        tx: FluxTransaction | None = None
        self.results_cache_n = 0


        if self.min_providers <= 1:
            cache_result = await self._cache.get_transaction(bytes.fromhex(txid))
            if isinstance(cache_result, FluxTransaction):
                tx = cache_result
                self.results_cache_n = 1

        if not tx:
            tx = await self._execute(lambda p: p.gettransaction(txid))

            if tx and tx.txid != txid:
                _logger.warning("Incorrect txid after parsing")
                tx.txid = txid

            if len(self.results) and self.min_providers <= 1:
                await self._cache.store_transaction(tx)

        return tx

    async def get_transactions(self, txids: list[str]) -> list[FluxTransaction]:
        """Get a transaction by its transaction hash. Convert to fluxwallet Transaction object.

        :param txid: Transaction identification hash
        :type txid: str
        :return Transaction: A single transaction object
        """

        # this is just for tests to be able to do assertions
        self.results_cache_n = 0

        cache_txs: list[FluxTransaction] = []
        provider_txs: list[FluxTransaction] = []
        cache_misses: list[str] = []


        if self.min_providers <= 1:
            for txid in txids:
                cache_result = await self._cache.get_transaction(bytes.fromhex(txid))
                if isinstance(cache_result, FluxTransaction):
                    self.results_cache_n += 1
                    cache_txs.append(cache_result)
                else:
                    cache_misses.append(txid)

            txs_result, failed_txids = await self._execute(lambda p: p.gettransactions_by_txids(cache_misses))
            txs: list[FluxTransaction] = list(txs_result)
            if failed_txids:
                _logger.warning(
                    "Failed to fetch %d transactions: %s",
                    len(failed_txids),
                    failed_txids[:5],
                )

            for tx in txs:
                if tx and tx.txid not in cache_misses:
                    _logger.warning("Incorrect txid after parsing")
                    continue
                provider_txs.append(tx)

                # what is this results thing?
                if len(self.results):
                    await self._cache.store_transaction(tx)

        return cache_txs + provider_txs

    async def get_transactions_by_address(
        self, address: str, after_tx_index: int = 0, limit: int = MAX_TRANSACTIONS
    ) -> AsyncGenerator[list[FluxTransaction]]:
        """Get all transactions for specified address.

        Sorted from old to new, so transactions with highest number of confirmations first.

        :param address: Address string
        :type address: str
        :param after_txid: Transaction ID of last known transaction. Only check for transactions after given tx id.
            Default: Leave empty to return all transaction. If used only provide a single address
        :type after_txid: str
        :param limit: Maximum number of transactions to return
        :type limit: int
        :return list: List of Transaction objects
        """
        self._reset_results()
        self.results_cache_n = 0

        if not isinstance(address, TYPE_TEXT):
            raise ServiceError("Address parameter must be of type text")


        db_addr: dict[str, str | int | None] | None = await self._cache.getaddress(address)
        txs_cache: list[FluxTransaction] = []

        # Retrieve transactions from cache
        caching_enabled = True
        if self.min_providers > 1:  # Disable cache if comparing providers
            caching_enabled = False

        if caching_enabled:
            # change this to yield
            cache_txs_result: list[FluxTransaction] = (
                await self._cache.get_transactions(address, after_tx_index, limit) or []
            )
            if cache_txs_result:
                txs_cache = cache_txs_result
                self.results_cache_n = len(txs_cache)

        if txs_cache:
            txs_cache = transaction_update_spents(txs_cache, address)
            yield txs_cache

        tx_generator = None

        cache_up_to_date = False
        if db_addr is not None:
            last_block = db_addr.get("last_block")
            if isinstance(last_block, int) and last_block >= await self.blockcount():
                cache_up_to_date = True

        # if our cache isn't up to date with the latest block, go out to service provider
        provider: ProviderProtocol | None = None
        if not cache_up_to_date or not caching_enabled:
            for sp in self._provider_order():
                if self._should_skip(sp):
                    continue
                try:
                    provider = self._get_provider(sp)
                    tx_generator = provider.get_transactions_by_address(address, after_tx_index, limit)
                    break
                except Exception as e:  # Catch-all: providers can raise arbitrary errors from HTTP, parsing, etc.
                    err = e.msg if isinstance(e, ServiceError) else str(e)
                    self.errors[sp] = err
            else:
                if self.errors:
                    raise ServiceError(
                        "No service provider responded successfully."
                        " Recovery: check your network connection or try again",
                        provider_errors=dict(self.errors),
                    )

        if not tx_generator:
            return

        last_block = await self.blockcount()

        try:
            new_tx_count = 0
            async for txs in tx_generator:
                new_tx_count += len(txs)

                txs = transaction_update_spents(txs, address)

                if caching_enabled:
                    # speed this up
                    for t in txs:
                        await self._cache.store_transaction(t)

                yield txs

            if caching_enabled:
                await self._cache.store_address(
                    address,
                    last_block,
                    last_tx_index=new_tx_count + after_tx_index,
                    txs_complete=True,
                )
        finally:
            if provider is not None:
                await provider.close()

    async def getrawtransaction(self, txid: str) -> str:
        """Get a raw transaction by its transaction hash.

        :param txid: Transaction identification hash
        :type txid: str
        :return str: Raw transaction as hexstring
        """
        self.results_cache_n = 0

        rawtx_result: str | None = await self._cache.getrawtransaction(bytes.fromhex(txid))
        if rawtx_result:
            self.results_cache_n = 1
            return rawtx_result

        return await self._execute(lambda p: p.getrawtransaction(txid))

    async def sendrawtransaction(self, rawtx: str) -> BroadcastResult:
        """Push a raw transaction to the network.

        :param rawtx: Raw transaction as hexstring or bytes
        :type rawtx: str
        :return BroadcastResult: Send transaction result
        """
        return await self._execute(lambda p: p.sendrawtransaction(rawtx))

    async def estimatefee(self, blocks: int = 3, priority: str = "") -> int:
        """Estimate fee per kilobyte for a transaction for this network with expected confirmation within a certain
        amount of blocks.

        :param blocks: Expected confirmation time in blocks. Default is 3.
        :type blocks: int
        :param priority: Priority for transaction: can be 'low', 'medium' or 'high'. Overwrites value supplied in
            'blocks' argument
        :type priority: str
        :return int: Fee in the smallest network denominator (satoshi)
        """
        self.results_cache_n = 0

        if priority:
            if priority == "low":
                blocks = 10
            elif priority == "high":
                blocks = 1


        if self.min_providers <= 1:  # Disable cache if comparing providers
            cached_fee = await self._cache.estimatefee(blocks)
            if isinstance(cached_fee, int) and cached_fee:
                self.results_cache_n = 1
                return cached_fee

        fee = await self._execute(lambda p: p.estimatefee(blocks))
        if not fee:  # pragma: no cover
            if self.network.fee_default:
                fee = self.network.fee_default
            else:
                raise ServiceError(
                    "Could not estimate fees."
                    " Recovery: check connectivity or set default fees"
                )
        if fee < self.network.fee_min:
            fee = self.network.fee_min
        elif fee > self.network.fee_max:
            fee = self.network.fee_max

        await self._cache.store_estimated_fee(blocks, fee)

        return fee

    async def store_blockcount(self, blockcount: int) -> None:
        self._blockcount_update = time.monotonic()
        self._blockcount = blockcount

        await self._cache.store_blockcount(blockcount)

    def wihin_blockcount_cache_time(self) -> bool:
        now = time.monotonic()

        return not self._blockcount_update + BLOCK_COUNT_CACHE_TIME < now

    async def blockcount(self) -> int:
        """
        Get the latest block number: The block number of last block in longest chain on the Blockchain.

        Block count is cashed for BLOCK_COUNT_CACHE_TIME seconds to avoid to many calls to service providers.

        :return int:
        """

        if self.wihin_blockcount_cache_time():
            return self._blockcount
        async with self.lock:
            # first guy does the work, the rest use the cache
            if self.wihin_blockcount_cache_time():
                return self._blockcount

            self._blockcount = await self._execute(lambda p: p.blockcount())
            self._blockcount_update = time.monotonic()


            # Store result in cache
            if len(self.results) and list(self.results.keys())[0] != "caching":
                await self._cache.store_blockcount(self._blockcount)
            return self._blockcount

    async def getblock(
        self,
        blockid: int | str,
        parse_transactions: bool = True,
        page: int = 1,
        limit: int | None = None,
    ) -> Block | None:
        """Get block with specified block height or block hash from service providers.

        If parse_transaction is set to True a list of Transaction object will be returned otherwise a
        list of transaction ID's.

        Some providers require 1 or 2 extra request per transaction, so to avoid timeouts or rate limiting errors
        you can specify a page and limit for the transaction. For instance with page=2, limit=4 only transaction
        5 to 8 are returned to the Blocks's 'transaction' attribute.

        If you only use a local bcoin or bitcoind provider, make sure you set the limit to maximum (i.e. 9999)
        because all transactions are already downloaded when fetching the block.

        >>> from fluxwallet.services.core import Service
        >>> srv = Service()
        >>> b = srv.getblock(0)
        >>> b
        <Block(000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f, 0, transactions: 1)>

        :param blockid: Hash or block height of block
        :type blockid: str, int
        :param parse_transactions: Return Transaction objects or just transaction ID's. Default is return txids.
        :type parse_transactions: bool
        :param page: Page number of transaction paging. Default is start from the beginning: 1
        :type page: int
        :param limit: Maximum amount of transaction to return. Default is 25 if parse transaction is
            enabled, otherwise returns all txid's (9999)
        :type limit: int

        :return Block:
        """
        if limit is None:
            limit = 25 if parse_transactions else 99999


        cache_result = await self._cache.getblock(blockid)
        block: Block | None = None
        if isinstance(cache_result, Block):
            block = cache_result
        is_last_page = False

        if block:
            # Block found get transactions from cache
            cached_txs: list[FluxTransaction | str] = list(
                await self._cache.getblocktransactions(block.height, page, limit) or []
            )
            block.transactions = cached_txs
            if block.transactions:
                self.results_cache_n = 1
            is_last_page = page * limit > block.tx_count
        if (
            not block
            or (not len(block.transactions) and limit != 0)
            or (not is_last_page and len(block.transactions) < limit)
            or (is_last_page and ((page - 1) * limit - block.tx_count + len(block.transactions)) < 0)
        ):
            self.results_cache_n = 0
            bd = await self._execute(lambda p: p.getblock(blockid, parse_transactions, page, limit))
            if not bd:
                return None

            block = Block(
                bd["block_hash"],
                bd["version"],
                bd["prev_block"],
                bd["merkle_root"],
                bd["time"],
                bd["bits"],
                bd["nonce"],
                bd["txs"],
                bd["height"],
                bd["depth"],
                self.network,
            )
            block.tx_count = bd["tx_count"]
            block.limit = limit
            block.page = page

            if parse_transactions and self.min_providers <= 1:
                order_n = (page - 1) * limit
                for tx in block.transactions:
                    await self._cache.store_transaction(tx, order_n)
                    order_n += 1
            self.complete = len(block.transactions) == block.tx_count
            await self._cache.store_block(block)
        return block

    async def getcacheaddressinfo(self, address: str) -> dict[str, str | int | None]:
        """Get address information from cache. I.e. balance, number of transactions, number of utox's, etc.

        Cache will only be filled after all transactions for a specific address are retrieved (with get_transactions ie)

        :param address: address string
        :type address: str
        :return dict:
        """
        addr_dict: dict[str, str | int | None] = {"address": address}

        addr_rec: dict[str, str | int | None] | None = await self._cache.getaddress(address)

        if addr_rec is not None:
            addr_dict["balance"] = addr_rec.get("balance")
            addr_dict["last_block"] = addr_rec.get("last_block")
            addr_dict["n_txs"] = addr_rec.get("n_txs")
            addr_dict["n_utxos"] = addr_rec.get("n_utxos")

        return addr_dict

    async def isspent(self, txid: str, output_n: int) -> bool:
        """Check if the output with provided transaction ID and output number is spent.

        :param txid: Transaction ID hex
        :type txid: str
        :param output_n: Output number
        :type output_n: int
        :return bool:
        """

        cache_result = await self._cache.get_transaction(bytes.fromhex(txid))
        if (
            isinstance(cache_result, FluxTransaction)
            and len(cache_result.outputs) > output_n
            and cache_result.outputs[output_n].spent is not None
        ):
            return cache_result.outputs[output_n].spent
        return False

    async def getinputvalues(self, t: FluxTransaction) -> FluxTransaction:
        """Retrieve values for transaction inputs for given Transaction.

        Raw transactions as stored on the blockchain do not contain the input values but only the previous transaction
        hash and index number. This method retrieves the previous transaction and reads the value.

        :param t: Transaction
        :type t: Transaction
        :return Transaction:
        """
        prev_txs: list[FluxTransaction] = []
        for i in t.inputs:
            if not i.value:
                if i.prev_txid not in [pt.txid for pt in prev_txs]:
                    fetched = await self.get_transactions([i.prev_txid.hex()])
                    prev_txs.extend(fetched)
                    prev_t = fetched[0] if fetched else None
                else:
                    matching = [pt for pt in prev_txs if pt.txid == i.prev_txid.hex()]
                    prev_t = matching[0] if matching else None
                if prev_t is not None:
                    i.value = prev_t.outputs[i.output_n_int].value
        return t
