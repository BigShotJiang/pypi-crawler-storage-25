"""Pydantic models for service provider API responses."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class ProviderUtxo(BaseModel):
    """Unspent transaction output from a service provider."""

    model_config = ConfigDict(frozen=True)

    address: str
    txid: str
    output_n: int
    value: int
    script: str = ""
    confirmations: int = 0
    block_height: int | None = None


class BroadcastResult(BaseModel):
    """Result of broadcasting a raw transaction."""

    model_config = ConfigDict(frozen=True)

    txid: str


class SaplingCommitment(BaseModel):
    """Sapling note commitment from the explorer."""

    model_config = ConfigDict(frozen=True)

    block_height: int
    txid: str
    output_index: int
    cmu: str
    ephemeral_key: str
    enc_ciphertext: str
    position: int = 0
    timestamp: int | None = None


class SaplingNullifier(BaseModel):
    """Sapling spend nullifier from the explorer."""

    model_config = ConfigDict(frozen=True)

    block_height: int
    txid: str
    spend_index: int
    nullifier: str
    anchor: str = ""
    timestamp: int | None = None


class SaplingTreeState(BaseModel):
    """Sapling Merkle tree state at a given height."""

    model_config = ConfigDict(frozen=True)

    height: int
    root: str
