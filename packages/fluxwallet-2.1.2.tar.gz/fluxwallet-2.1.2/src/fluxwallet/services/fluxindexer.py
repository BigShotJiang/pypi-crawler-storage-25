"""Flux service provider using the flux-blockchain-explorer API (ClickHouse-backed).

Primary endpoint: the FluxIndexer REST API (v1).
"""

from __future__ import annotations

import contextlib
import logging
import re
import ssl
from decimal import Decimal
from typing import TYPE_CHECKING, Any, Self

import certifi
import httpx
import yarl

from fluxwallet.config import TIMEOUT_REQUESTS
from fluxwallet.exceptions import ClientError as ClientError
from fluxwallet.networks import Network
from fluxwallet.services.models import (
    BroadcastResult,
    ProviderUtxo,
)
from fluxwallet.services.retry import retry_with_backoff
from fluxwallet.transactions import FluxTransaction, Input, Output

if TYPE_CHECKING:
    import collections.abc

_logger = logging.getLogger(__name__)

PROVIDERNAME = "fluxindexer"

# Maximum batch size for transaction batch endpoint.
_BATCH_SIZE = 100

_BASE58_RE = re.compile(r"^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]{25,35}$")
_TXID_RE = re.compile(r"^[0-9a-fA-F]{64}$")
_MAX_MONEY = 440_000_000 * 100_000_000


def _to_dict(raw: object) -> dict[str, object]:
    """Narrow an unknown dict to dict[str, object] by rebuilding with str keys."""
    if isinstance(raw, dict):
        return {str(k): v for k, v in raw.items()}
    return {}


def _str_val(d: dict[str, object], key: str, default: str = "") -> str:
    """Extract a string value from a dict, coercing if needed."""
    v = d.get(key, default)
    return str(v) if v is not None else default


def _int_val(d: dict[str, object], key: str, default: int = 0) -> int:
    """Extract an int value from a dict, coercing if needed."""
    v = d.get(key, default)
    if isinstance(v, int):
        return v
    if isinstance(v, str):
        try:
            return int(v)
        except (ValueError, TypeError):
            return default
    return default


def _int_or_none(d: dict[str, object], key: str) -> int | None:
    """Extract an int value or None from a dict."""
    v = d.get(key)
    if v is None:
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, str):
        try:
            return int(v)
        except (ValueError, TypeError):
            return None
    return None


def _validate_address(address: str) -> None:
    if not _BASE58_RE.match(address):
        raise ValueError(f"Invalid address format: {address!r}")


def _validate_utxo(u: dict[str, object]) -> bool:
    txid = _str_val(u, "txid")
    if not _TXID_RE.match(txid):
        _logger.warning("Skipping UTXO with invalid txid: %s", txid)
        return False
    vout = u.get("vout")
    if not isinstance(vout, int) or vout < 0:
        _logger.warning("Skipping UTXO with invalid vout: %s", vout)
        return False
    sats = u.get("valueSat")
    if not isinstance(sats, (int, str)):
        _logger.warning("Skipping UTXO with invalid value: %s", sats)
        return False
    sats_int = int(sats)
    if sats_int <= 0 or sats_int > _MAX_MONEY:
        _logger.warning("Skipping UTXO with invalid value: %s", sats_int)
        return False
    return True



class FluxIndexerClient:
    """Async client for the flux-blockchain-explorer API (v1).

    Uses the ClickHouse-backed FluxIndexer REST API. All methods are async.
    """

    def __init__(
        self,
        network: str | Network,
        base_url: str,
        denominator: int = 100_000_000,
        api_key: str = "",
        provider_coin_id: str = "",
        network_overrides: dict[str, str] | None = None,
        timeout: int = TIMEOUT_REQUESTS,
        latest_block: int | None = None,
        strict: bool = True,
    ) -> None:
        if not isinstance(network, Network):
            self.network = Network(network)
        else:
            self.network = network
        self.base_url = base_url.rstrip("/")
        parsed = yarl.URL(self.base_url)
        # Private/dev deployments (e.g. squidward) may use plain HTTP on a LAN.
        if parsed.scheme not in ("http", "https"):
            raise ValueError(f"FluxIndexerClient requires HTTP(S), got: {self.base_url}")
        self.provider = PROVIDERNAME
        self.units = denominator
        self.timeout = timeout
        self.latest_block = latest_block
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        self._client = httpx.AsyncClient(
            verify=ssl_ctx,
            timeout=timeout,
            headers={"Accept": "application/json"},
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        await self.close()

    # --- HTTP helpers ---

    async def _get(self, path: str) -> Any:
        """GET request to the FluxIndexer API.

        :param path: API path (appended to base_url/api/v1)
        :returns: Parsed JSON response
        :raises ClientError: On HTTP errors or connection failures
        """
        url = f"{self.base_url}/api/v1{path}"

        async def _do() -> Any:
            response = await self._client.get(url)
            response.raise_for_status()
            return response.json()

        try:
            return await retry_with_backoff(_do)
        except httpx.HTTPStatusError as e:
            msg = str(e)
            with contextlib.suppress(ValueError, AttributeError):
                msg = e.response.text
            raise ClientError(f"HTTP {e.response.status_code} from {url}: {msg}") from e
        except httpx.RequestError as e:
            raise ClientError(f"Request failed for {url}: {e}") from e

    async def _post(self, path: str, data: dict[str, object]) -> Any:
        """POST request to the FluxIndexer API.

        :param path: API path (appended to base_url/api/v1)
        :param data: JSON body
        :returns: Parsed JSON response
        :raises ClientError: On HTTP errors or connection failures
        """
        url = f"{self.base_url}/api/v1{path}"

        async def _do() -> Any:
            response = await self._client.post(url, json=data)
            response.raise_for_status()
            return response.json()

        try:
            return await retry_with_backoff(_do)
        except httpx.HTTPStatusError as e:
            msg = str(e)
            with contextlib.suppress(ValueError, AttributeError):
                msg = e.response.text
            raise ClientError(f"HTTP {e.response.status_code} from {url}: {msg}") from e
        except httpx.RequestError as e:
            raise ClientError(f"Request failed for {url}: {e}") from e

    # --- Blockchain queries ---

    async def blockcount(self) -> int:
        """Get the current block height.

        Uses /api/v1/status which returns indexer.currentHeight.

        :returns: Current block height
        """
        result = await self._get("/status")
        if not isinstance(result, dict):
            raise ClientError("Unexpected /api/v1/status response type")
        data: dict[str, object] = {str(k): v for k, v in result.items()}
        indexer_raw = data.get("indexer")
        indexer = _to_dict(indexer_raw)
        if not indexer:
            raise ClientError("No indexer data in /api/v1/status response")
        # Use chainHeight (from daemon) not currentHeight (indexer progress)
        height = _int_or_none(indexer, "chainHeight")
        if height is None:
            raise ClientError("No currentHeight in /api/v1/status response")
        return height

    async def getblock(
        self,
        blockid: str | int,
        parse_transactions: bool = True,
        page: int = 1,
        limit: int = 0,
    ) -> dict[str, object]:
        """Get block data by height or hash.

        :param blockid: Block height (int) or hash (str)
        :param parse_transactions: If True, include transaction details
        :param page: Page number (unused, for API compat)
        :param limit: Limit (unused, for API compat)
        :returns: Block data dict
        """
        result = await self._get(f"/blocks/{blockid}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected block response type: {type(result)}")
        data: dict[str, object] = {str(k): v for k, v in result.items()}
        return data

    # --- Address queries ---

    async def getbalance(self, addresslist: str | list[str]) -> int:
        """Get balance for an address in satoshis.

        :param addresslist: Single address string or list of addresses
        :returns: Balance in satoshis
        """
        if isinstance(addresslist, list):
            total = 0
            for addr in addresslist:
                total += await self.getbalance(addr)
            return total
        _validate_address(addresslist)
        result = await self._get(f"/addresses/{addresslist}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected address response type: {type(result)}")
        data: dict[str, object] = {str(k): v for k, v in result.items()}
        return _int_val(data, "balance", 0)

    async def getutxos(
        self,
        address: str,
        after_txid: str = "",
        limit: int = 0,
    ) -> list[ProviderUtxo]:
        """Get unspent transaction outputs for an address.

        :param address: Flux address (t1... or t3...)
        :param after_txid: Only return UTXOs after this txid (unused, for API compat)
        :param limit: Maximum number of UTXOs to return (0 = unlimited)
        :returns: List of ProviderUtxo objects
        """
        _validate_address(address)
        raw = await self._get(f"/addresses/{address}/utxos")
        if not isinstance(raw, dict):
            raise ClientError(f"Unexpected UTXO response type: {type(raw)}")
        data: dict[str, object] = {str(k): v for k, v in raw.items()}
        raw_utxos = data.get("utxos", [])
        if not isinstance(raw_utxos, list):
            raise ClientError(f"Unexpected utxos field type: {type(raw_utxos)}")

        utxos: list[ProviderUtxo] = []
        for u_raw in raw_utxos:
            u = _to_dict(u_raw)
            if not u:
                continue
            if not _validate_utxo(u):
                continue
            sats = _int_val(u, "valueSat", 0)
            block_height = _int_val(u, "blockHeight", 0)
            utxos.append(
                ProviderUtxo(
                    address=address,
                    txid=_str_val(u, "txid"),
                    output_n=_int_val(u, "vout", 0),
                    value=sats,
                    block_height=block_height,
                    confirmations=block_height,
                )
            )
            if limit and len(utxos) >= limit:
                break

        return utxos

    async def getutxos_multi(
        self,
        addresslist: list[str],
        limit: int = 0,
    ) -> list[ProviderUtxo]:
        """Get UTXOs for multiple addresses in a single batch call.

        :param addresslist: List of Flux addresses
        :param limit: Maximum UTXOs to return (0 = unlimited)
        :returns: List of ProviderUtxo objects
        """
        if not addresslist:
            return []

        for addr in addresslist:
            _validate_address(addr)

        _ADDR_BATCH = 100
        _PAGE_SIZE = 1000
        utxos: list[ProviderUtxo] = []

        for i in range(0, len(addresslist), _ADDR_BATCH):
            batch = addresslist[i : i + _ADDR_BATCH]
            offset = 0

            while True:
                raw = await self._post(
                    f"/addresses/utxos?limit={_PAGE_SIZE}&offset={offset}",
                    {"addresses": batch},
                )
                if not isinstance(raw, dict):
                    raise ClientError(f"Unexpected batch UTXO response: {type(raw)}")
                raw_utxos = raw.get("utxos", [])
                if not isinstance(raw_utxos, list):
                    raise ClientError(f"Unexpected utxos field: {type(raw_utxos)}")
                raw_height = raw.get("chain_height", 0)
                chain_height = int(raw_height) if isinstance(raw_height, (int, str)) else 0

                for u_raw in raw_utxos:
                    u = _to_dict(u_raw)
                    if not u:
                        continue
                    if not _validate_utxo(u):
                        continue
                    sats = _int_val(u, "valueSat", 0)
                    block_height = _int_val(u, "blockHeight", 0)
                    confirmations = max(chain_height - block_height, 0) if chain_height and block_height else 0
                    utxos.append(
                        ProviderUtxo(
                            address=_str_val(u, "address"),
                            txid=_str_val(u, "txid"),
                            output_n=_int_val(u, "vout", 0),
                            value=sats,
                            block_height=block_height,
                            confirmations=confirmations,
                        )
                    )
                    if limit and len(utxos) >= limit:
                        return utxos

                if len(raw_utxos) < _PAGE_SIZE:
                    break
                offset += _PAGE_SIZE

        return utxos

    # --- Transaction queries ---

    async def gettransaction(self, txid: str) -> FluxTransaction:
        """Get a transaction by txid.

        The explorer returns full transaction data in JSON with vin/vout. Parses into a FluxTransaction object.

        :param txid: Transaction ID
        :returns: Parsed FluxTransaction
        """
        tx_result = await self._get(f"/transactions/{txid}")
        if not isinstance(tx_result, dict):
            raise ClientError(f"Unexpected tx response type: {type(tx_result)}")
        tx_data: dict[str, object] = {str(k): v for k, v in tx_result.items()}

        # Try to get raw hex for proper parsing
        raw_hex = ""
        if tx_data.get("hex"):
            raw_hex = _str_val(tx_data, "hex")
        else:
            # Request with includeHex=true
            tx_hex_result = await self._get(f"/transactions/{txid}?includeHex=true")
            if isinstance(tx_hex_result, dict):
                tx_hex_data: dict[str, object] = {str(k): v for k, v in tx_hex_result.items()}
                if tx_hex_data.get("hex"):
                    raw_hex = _str_val(tx_hex_data, "hex")
                    # Merge any additional data
                    tx_data = tx_hex_data

        if raw_hex:
            t = FluxTransaction.parse_hex(
                raw_hex,
                network=self.network.name,
            )
        else:
            # Fallback: construct from decoded JSON data
            t = self._build_transaction_from_explorer(tx_data)

        t.txid = _str_val(tx_data, "txid", txid)
        t.date = None
        t.confirmations = _int_val(tx_data, "confirmations", 0)
        t.status = "confirmed" if t.confirmations else "unconfirmed"
        t.block_height = _int_or_none(tx_data, "blockHeight")
        fees_raw = _str_val(tx_data, "fees", "0")
        t.fee = int(Decimal(fees_raw) * self.units)

        return t

    async def gettransactions(
        self,
        address: str,
        after_txid: str = "",
        limit: int = 50,
    ) -> list[FluxTransaction]:
        """Get transactions for an address using cursor-based pagination.

        :param address: Flux address
        :param after_txid: Only return transactions after this txid
        :param limit: Maximum number of transactions
        :returns: List of FluxTransaction objects
        """
        _validate_address(address)
        transactions: list[FluxTransaction] = []
        cursor_height: int | None = None
        cursor_txid: str | None = None
        found_after = not bool(after_txid)

        while True:
            url = f"/addresses/{address}/transactions?limit={min(limit * 2, 100)}"
            if cursor_height is not None and cursor_txid is not None:
                url += f"&cursorHeight={cursor_height}&cursorTxid={cursor_txid}"

            result = await self._get(url)
            if not isinstance(result, dict):
                break
            data: dict[str, object] = {str(k): v for k, v in result.items()}

            txs = data.get("transactions", [])
            if not isinstance(txs, list) or not txs:
                break

            for tx_raw in txs:
                td = _to_dict(tx_raw)
                if not td:
                    continue
                tx_id = _str_val(td, "txid")
                if not found_after:
                    if tx_id == after_txid:
                        found_after = True
                    continue

                transactions.append(self._parse_address_tx(td, address))

                if len(transactions) >= limit:
                    return transactions

            # Check for next cursor
            next_cursor_raw = data.get("nextCursor")
            next_cursor = _to_dict(next_cursor_raw)
            if not next_cursor:
                break
            cursor_height = _int_or_none(next_cursor, "height")
            cursor_txid_val = next_cursor.get("txid")
            cursor_txid = str(cursor_txid_val) if cursor_txid_val is not None else None
            if cursor_height is None or cursor_txid is None:
                break

        return transactions

    async def get_transactions_by_address(
        self,
        address: str,
        after_tx_index: int = 0,
        limit: int = 0,
    ) -> collections.abc.AsyncGenerator[list[FluxTransaction]]:
        """Async generator yielding transaction batches for an address.

        Uses cursor-based pagination from the explorer API.

        :param address: Flux address
        :param after_tx_index: Number of transactions already known (skip)
        :param limit: Maximum new transactions to return (0 = all)
        :yields: List[FluxTransaction] per batch
        """
        _validate_address(address)

        # Get total transaction count to determine how many to skip/fetch.
        addr_result = await self._get(f"/addresses/{address}")
        if not isinstance(addr_result, dict):
            return
        addr_data: dict[str, object] = {str(k): v for k, v in addr_result.items()}
        total_txs = _int_val(addr_data, "txs", 0)

        new_txs = total_txs - after_tx_index
        if new_txs <= 0:
            return

        if limit:
            new_txs = min(new_txs, limit)

        total_yielded = 0
        cursor_height: int | None = None
        cursor_txid: str | None = None
        # Skip the first after_tx_index transactions using offset
        offset = after_tx_index if after_tx_index > 0 else 0
        first_request = True

        while total_yielded < new_txs:
            batch_limit = min(100, new_txs - total_yielded)
            url = f"/addresses/{address}/transactions?limit={batch_limit}"
            if cursor_height is not None and cursor_txid is not None:
                url += f"&cursorHeight={cursor_height}&cursorTxid={cursor_txid}"
            elif first_request and offset > 0:
                url += f"&offset={offset}"
            first_request = False

            try:
                result = await self._get(url)
            except (httpx.HTTPError, ClientError, OSError) as e:
                _logger.warning("Failed to fetch tx page for %s: %s", address, e)
                break

            if not isinstance(result, dict):
                break
            page_data: dict[str, object] = {str(k): v for k, v in result.items()}

            txs = page_data.get("transactions", [])
            if not isinstance(txs, list) or not txs:
                break

            batch: list[FluxTransaction] = []
            for tx_raw in txs:
                td = _to_dict(tx_raw)
                if not td:
                    continue
                batch.append(self._parse_address_tx(td, address))

            total_yielded += len(batch)

            if batch:
                yield batch

            if limit and total_yielded >= limit:
                return

            # Advance cursor
            next_cursor_raw = page_data.get("nextCursor")
            next_cursor = _to_dict(next_cursor_raw)
            if not next_cursor:
                break
            cursor_height = _int_or_none(next_cursor, "height")
            cursor_txid_val = next_cursor.get("txid")
            cursor_txid = str(cursor_txid_val) if cursor_txid_val is not None else None
            if cursor_height is None or cursor_txid is None:
                break

    async def gettransactions_by_txids(self, txids: list[str]) -> tuple[list[FluxTransaction], list[str]]:
        """Fetch multiple transactions using the batch endpoint.

        Returns (successful_transactions, failed_txids) so callers can retry or log failures without losing the
        successful results.
        """
        if not txids:
            return [], []

        succeeded: list[FluxTransaction] = []
        failed: list[str] = []

        # Process in batches of _BATCH_SIZE (API limit is 100)
        for i in range(0, len(txids), _BATCH_SIZE):
            batch_txids = txids[i : i + _BATCH_SIZE]
            try:
                result = await self._post("/transactions/batch", {"txids": batch_txids})
                batch_data: dict[str, object] = result

                batch_txs = batch_data.get("transactions", [])
                if not isinstance(batch_txs, list):
                    failed.extend(batch_txids)
                    continue

                for tx_raw in batch_txs:
                    td = _to_dict(tx_raw)
                    if not td:
                        continue
                    if td.get("error"):
                        failed.append(_str_val(td, "txid"))
                        continue
                    try:
                        t = self._build_transaction_from_explorer(td)
                        t.txid = _str_val(td, "txid")
                        t.confirmations = _int_val(td, "confirmations", 0)
                        t.status = "confirmed" if t.confirmations else "unconfirmed"
                        bh = _int_or_none(td, "blockHeight")
                        if bh is None:
                            bh = _int_or_none(td, "block_height")
                        t.block_height = bh
                        fees_raw = _str_val(td, "fees", "0")
                        t.fee = int(Decimal(fees_raw) * self.units)
                        succeeded.append(t)
                    except (ValueError, KeyError, TypeError) as e:
                        _logger.warning(
                            "Failed to parse tx %s: %s",
                            _str_val(td, "txid"),
                            e,
                        )
                        failed.append(_str_val(td, "txid"))

            except (httpx.HTTPError, ClientError, OSError) as e:
                _logger.warning("Batch tx fetch failed: %s", e)
                failed.extend(batch_txids)

        return succeeded, failed

    async def getrawtransaction(self, txid: str) -> str:
        """Get raw transaction hex by txid.

        Requests the transaction with includeHex=true.

        :param txid: Transaction ID
        :returns: Raw hex string (empty if unavailable)
        """
        try:
            result = await self._get(f"/transactions/{txid}?includeHex=true")
            if isinstance(result, dict):
                data: dict[str, object] = {str(k): v for k, v in result.items()}
                return _str_val(data, "hex")
        except ClientError:
            pass
        return ""

    # --- Transaction parsing ---

    def _parse_address_tx(self, tx_data: dict[str, object], address: str) -> FluxTransaction:
        """Parse a transaction from the address transactions endpoint.

        The address transactions endpoint returns summary data (direction, receivedValue, sentValue) without full
        vin/vout. We construct a minimal FluxTransaction with the metadata available.
        """
        t = FluxTransaction(
            inputs=[],
            outputs=[],
            network=self.network.name,
        )
        t.txid = _str_val(tx_data, "txid")
        t.confirmations = _int_val(tx_data, "confirmations", 0)
        t.status = "confirmed" if t.confirmations else "unconfirmed"
        t.block_height = _int_or_none(tx_data, "blockHeight")
        fees_raw = _str_val(tx_data, "feeValue", "0")
        t.fee = int(Decimal(fees_raw))
        return t

    def _build_transaction_from_explorer(self, tx_data: dict[str, object]) -> FluxTransaction:
        """Build a FluxTransaction from explorer API decoded transaction data.

        :param tx_data: Decoded transaction dict from /api/v1/transactions/:txid
        :returns: FluxTransaction object
        """
        inputs: list[Input] = []
        vin_list = tx_data.get("vin", [])
        if isinstance(vin_list, list):
            for vin_raw in vin_list:
                vin = _to_dict(vin_raw)
                if not vin:
                    continue
                # Skip coinbase inputs
                if vin.get("coinbase"):
                    continue
                addresses_raw = vin.get("addresses", [])
                addr = ""
                if isinstance(addresses_raw, list) and addresses_raw:
                    addr = str(addresses_raw[0])
                elif vin.get("addr"):
                    addr = _str_val(vin, "addr")
                value_raw = _str_val(vin, "value", "0")
                value = int(Decimal(value_raw) * self.units)
                inp = Input(
                    prev_txid=_str_val(vin, "txid"),
                    output_n=_int_val(vin, "vout", 0),
                    value=value,
                    address=addr,
                    witness_type="legacy",
                )
                inputs.append(inp)

        outputs: list[Output] = []
        vout_list = tx_data.get("vout", [])
        if isinstance(vout_list, list):
            for vout_raw in vout_list:
                vout = _to_dict(vout_raw)
                if not vout:
                    continue
                script_pub_key = _to_dict(vout.get("scriptPubKey"))
                addresses_raw = script_pub_key.get("addresses", [])
                addr = str(addresses_raw[0]) if isinstance(addresses_raw, list) and addresses_raw else ""
                value_raw = _str_val(vout, "value", "0")
                value = int(Decimal(value_raw) * self.units)
                if value < 0 or value > _MAX_MONEY:
                    raise ValueError(f"API returned invalid output value: {value}")
                lock_script_hex = _str_val(script_pub_key, "hex")
                out = Output(
                    value=value,
                    address=str(addr),
                    lock_script=bytes.fromhex(lock_script_hex) if lock_script_hex else b"",
                    network=self.network.name,
                    output_n=_int_val(vout, "n", 0),
                )
                outputs.append(out)

        version = _int_val(tx_data, "version", 4)
        locktime_val = _int_or_none(tx_data, "lockTime")
        if locktime_val is None:
            locktime_val = _int_val(tx_data, "locktime", 0)
        locktime = locktime_val

        return FluxTransaction(
            inputs=inputs,
            outputs=outputs,
            network=self.network.name,
            version=version,
            locktime=locktime,
        )

    # --- Broadcasting ---

    async def sendrawtransaction(self, rawtx: str) -> BroadcastResult:
        """Broadcast a raw transaction.

        :param rawtx: Transaction hex string
        :returns: BroadcastResult with txid
        :raises ClientError: If broadcast fails
        """
        result = await self._post("/transactions/broadcast", {"rawtx": rawtx})
        txid = result.get("txid")
        if not txid:
            raise ClientError(f"No txid in broadcast response: {result}")
        return BroadcastResult(txid=str(txid))

    # --- Fee estimation ---

    async def estimatefee(self, blocks: int = 1) -> int:
        """Estimate fee rate for Flux transactions.

        Flux uses a fixed fee rate of 1 sat/byte.

        :param blocks: Target confirmation blocks (unused for Flux)
        :returns: Fee rate in satoshis per KB
        """
        return 1000  # 1 sat/byte = 1000 sat/KB

    # --- Sapling-specific endpoints ---

    async def get_sapling_commitments(
        self, from_height: int, to_height: int, limit: int = 10000
    ) -> list[dict[str, object]]:
        """Get Sapling note commitments for a height range.

        :param from_height: Start block height (inclusive)
        :param to_height: End block height (inclusive)
        :param limit: Maximum commitments to return
        :returns: List of commitment dicts with block_height, txid, output_index, cmu, ephemeral_key, enc_ciphertext,
            timestamp
        """
        result = await self._get(f"/sapling/commitments?from={from_height}&to={to_height}&limit={limit}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected commitments response type: {type(result)}")
        data: dict[str, object] = {str(k): v for k, v in result.items()}
        commitments = data.get("commitments", [])
        if not isinstance(commitments, list):
            raise ClientError(f"Unexpected commitments field type: {type(commitments)}")
        typed: list[dict[str, object]] = []
        for item in commitments:
            typed.append(_to_dict(item))
        return typed

    async def get_sapling_nullifiers(
        self, from_height: int, to_height: int, limit: int = 10000
    ) -> list[dict[str, object]]:
        """Get Sapling nullifiers for a height range.

        :param from_height: Start block height (inclusive)
        :param to_height: End block height (inclusive)
        :param limit: Maximum nullifiers to return
        :returns: List of nullifier dicts with block_height, txid, spend_index, nullifier, anchor, timestamp
        """
        result = await self._get(f"/sapling/nullifiers?from={from_height}&to={to_height}&limit={limit}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected nullifiers response type: {type(result)}")
        data: dict[str, object] = {str(k): v for k, v in result.items()}
        nullifiers = data.get("nullifiers", [])
        if not isinstance(nullifiers, list):
            raise ClientError(f"Unexpected nullifiers field type: {type(nullifiers)}")
        typed: list[dict[str, object]] = []
        for item in nullifiers:
            typed.append(_to_dict(item))
        return typed

    async def get_sapling_tree_state(self, height: int) -> dict[str, object]:
        """Get Sapling tree root at a given block height.

        :param height: Block height
        :returns: Dict with height and sapling_root
        """
        result = await self._get(f"/sapling/tree-state/{height}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected tree-state response type: {type(result)}")
        data: dict[str, object] = {str(k): v for k, v in result.items()}
        return data

    # --- Cleanup ---

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()
