#
#    fluxwallet - Python Cryptocurrency Library
#    SERVICES - Cache layer wrapping CacheStore with domain-specific logic
#    © 2017-2022 - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING

import lmdb

from fluxwallet.blocks import Block
from fluxwallet.cache_store import CacheStore
from fluxwallet.config import (
    FW_DATA_DIR,
    MAX_TRANSACTIONS,
    SERVICE_CACHING_ENABLED,
)
from fluxwallet.encoding import int_to_varbyteint, to_bytes, varstr
from fluxwallet.transactions import FluxTransaction

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

    from fluxwallet.networks import Network

_logger = logging.getLogger(__name__)


def _test_cache[T](
    f: Callable[..., Coroutine[object, object, T | None]],
) -> Callable[..., Coroutine[object, object, T | None]]:
    @wraps(f)
    async def inner(
        ref: ServiceCache,
        *args: str | int | bytes | bool | None,
        **kwargs: str | int | bytes | bool | None,
    ) -> T | None:
        if await ref.cache_enabled():
            return await f(ref, *args, **kwargs)
        return None

    return inner


class ServiceCache:
    """Store transaction, utxo and address information in LMDB cache to increase speed and avoid duplicate calls to
    service providers.

    Once confirmed a transaction is immutable so we have to fetch it from a service provider only once. When checking
    for new transactions or utxo's for a certain address we only have to check the new blocks.

    This class is used by the Service class and normally you won't need to access it directly.
    """

    def __init__(self, network: Network, db_uri: str = "") -> None:
        """Open ServiceCache.

        :param network: Specify network used
        :type network: Network
        :param db_uri: Path for LMDB cache directory
        :type db_uri: str
        """

        self.db_uri: str = db_uri
        self.network: Network = network
        self._store: CacheStore | None = None
        self.cache_started: bool = False

    @property
    def _store_or_raise(self) -> CacheStore:
        """Return the underlying CacheStore, raising if not yet initialized."""
        if self._store is None:
            raise RuntimeError("Cache store not initialized — call cache_enabled() first")
        return self._store

    async def cache_enabled(self) -> bool:
        """Check if caching is enabled. Returns False if SERVICE_CACHING_ENABLED is False or no cache is available.

        :return bool:
        """
        if not self.cache_started and SERVICE_CACHING_ENABLED:
            try:
                path = self.db_uri if self.db_uri else str(Path(FW_DATA_DIR, "cache.lmdb"))
                self._store = CacheStore(path)
                self.cache_started = True
            except (OSError, RuntimeError, lmdb.Error) as e:
                _logger.warning(f"Could not open CacheStore: {e}")
                return False

        return not (not SERVICE_CACHING_ENABLED or not self._store)

    @staticmethod
    def _parse_cached_transaction(
        txid: bytes,
        tx_data: dict[str, str | int | float | bool | None],
        nodes: list[dict[str, str | int | bytes | bool | None]],
    ) -> FluxTransaction:
        """Build a FluxTransaction from cached dicts."""
        raw_locktime = tx_data.get("locktime", 0)
        locktime = raw_locktime if isinstance(raw_locktime, int) else 0
        raw_version = tx_data.get("version", 1)
        version = raw_version if isinstance(raw_version, int) else 1
        raw_network = tx_data.get("network_name", "")
        network_name = raw_network if isinstance(raw_network, str) else ""
        raw_fee = tx_data.get("fee", 0)
        fee = raw_fee if isinstance(raw_fee, int) else 0
        raw_date_val = tx_data.get("date")
        date_val: datetime | None = datetime.fromisoformat(raw_date_val) if isinstance(raw_date_val, str) else None
        raw_confirmations = tx_data.get("confirmations", 0)
        confirmations = raw_confirmations if isinstance(raw_confirmations, int) else 0
        raw_block_height = tx_data.get("block_height")
        block_height = raw_block_height if isinstance(raw_block_height, int) else None
        raw_witness_type = tx_data.get("witness_type", "legacy")
        witness_type = raw_witness_type if isinstance(raw_witness_type, str) else "legacy"

        t = FluxTransaction(
            locktime=locktime,
            version=version,
            network=network_name,
            fee=fee,
            txid=txid.hex(),
            date=date_val,
            confirmations=confirmations,
            block_height=block_height,
            status="confirmed",
            witness_type=witness_type,
        )

        for n in nodes:
            if n.get("is_input"):
                raw_ref_txid: str | int | bytes | bool | None = n.get("ref_txid", b"\x00" * 32)
                ref_txid_bytes: bytes
                if isinstance(raw_ref_txid, str):
                    ref_txid_bytes = bytes.fromhex(raw_ref_txid)
                elif isinstance(raw_ref_txid, bytes):
                    ref_txid_bytes = raw_ref_txid
                else:
                    ref_txid_bytes = b"\x00" * 32
                if ref_txid_bytes == b"\x00" * 32:
                    t.coinbase = True
                raw_ref_index = n.get("ref_index_n", 0)
                ref_index = raw_ref_index if isinstance(raw_ref_index, int) else 0
                raw_script = n.get("script", b"")
                script: bytes | str = raw_script if isinstance(raw_script, (bytes, str)) else b""
                raw_address = n.get("address", "")
                address = raw_address if isinstance(raw_address, str) else ""
                raw_sequence = n.get("sequence", 0xFFFFFFFF)
                sequence = raw_sequence if isinstance(raw_sequence, int) else 0xFFFFFFFF
                raw_value = n.get("value", 0)
                value = raw_value if isinstance(raw_value, int) else 0
                raw_index_n = n.get("index_n", 0)
                index_n = raw_index_n if isinstance(raw_index_n, int) else 0
                raw_witnesses = n.get("witnesses", b"")
                witnesses: bytes = raw_witnesses if isinstance(raw_witnesses, bytes) else b""
                t.add_input(
                    ref_txid_bytes.hex(),
                    ref_index,
                    unlocking_script=script,
                    address=address,
                    sequence=sequence,
                    value=value,
                    index_n=index_n,
                    witnesses=witnesses,
                    strict=False,
                )
            else:
                raw_ref_txid_out: str | int | bytes | bool | None = n.get("ref_txid")
                ref_txid_str: str | None
                if isinstance(raw_ref_txid_out, bytes):
                    ref_txid_str = raw_ref_txid_out.hex()
                elif isinstance(raw_ref_txid_out, str):
                    ref_txid_str = raw_ref_txid_out
                else:
                    ref_txid_str = None
                raw_out_value = n.get("value", 0)
                out_value = raw_out_value if isinstance(raw_out_value, int) else 0
                raw_out_address = n.get("address", "")
                out_address = raw_out_address if isinstance(raw_out_address, str) else ""
                raw_lock_script = n.get("script", b"")
                lock_script: bytes | str = raw_lock_script if isinstance(raw_lock_script, (bytes, str)) else b""
                raw_spent = n.get("spent")
                spent = raw_spent if isinstance(raw_spent, bool) else False
                raw_out_index = n.get("index_n", 0)
                out_index = raw_out_index if isinstance(raw_out_index, int) else 0
                raw_spending_index = n.get("ref_index_n")
                spending_index = raw_spending_index if isinstance(raw_spending_index, int) else None
                t.add_output(
                    out_value,
                    out_address,
                    lock_script=lock_script,
                    spent=spent,
                    output_n=out_index,
                    spending_txid=ref_txid_str,
                    spending_index_n=spending_index,
                    strict=False,
                )

        t.update_totals()
        t.size = len(t.raw())
        t.calc_weight_units()
        _logger.info(f"Retrieved transaction {t.txid} from cache")
        return t

    @_test_cache
    async def get_transaction(self, txid: bytes) -> FluxTransaction | None:
        """Get transaction from cache. Returns None if not available.

        :param txid: Transaction identification hash
        :type txid: bytes
        :return Transaction: A single Transaction object
        """

        tx_data = self._store_or_raise.get_transaction(txid)
        if not tx_data:
            return None

        # Only return if this tx belongs to our network
        if tx_data.get("network_name") and tx_data["network_name"] != self.network.name:
            return None

        nodes = self._store_or_raise.get_tx_nodes(txid)

        t = self._parse_cached_transaction(txid, tx_data, nodes)

        if t.block_height:
            bc_result = await self.blockcount()
            if isinstance(bc_result, int) and bc_result:
                t.confirmations = (bc_result - t.block_height) + 1

        return t

    @_test_cache
    async def getaddress(self, address: str) -> dict[str, str | int | None] | None:
        """Get address information from cache.

        :param address: Address string
        :type address: str
        :return dict: Address cache data or None
        """

        data = self._store_or_raise.get_address(address)
        if not data:
            return None
        if data.get("network_name") and data["network_name"] != self.network.name:
            return None
        return data

    @_test_cache
    async def get_transactions(
        self, address: str, after_tx_index: int = 0, limit: int = MAX_TRANSACTIONS
    ) -> list[FluxTransaction]:
        """Get transactions from cache for an address. Returns empty list if none found.

        :param address: Address string
        :type address: str
        :param after_tx_index: Skip transactions before this index
        :type after_tx_index: int
        :param limit: Maximum number of transactions to return
        :type limit: int
        :return list: List of Transaction objects
        """
        db_addr = await self.getaddress(address)
        if not db_addr:
            return []

        # Scan all cached transactions to find those referencing this address
        # We iterate over all transactions and check their nodes for the address
        txs_for_address = self._find_transactions_for_address(address)

        if after_tx_index:
            # Filter to transactions at or after the given index
            txs_for_address = txs_for_address[after_tx_index:]

        txs: list[FluxTransaction] = []
        for txid, tx_data, nodes in txs_for_address:
            t = self._parse_cached_transaction(txid, tx_data, nodes)
            if t:
                if t.block_height:
                    bc_result = await self.blockcount()
                    if isinstance(bc_result, int) and bc_result:
                        t.confirmations = (bc_result - t.block_height) + 1
                txs.append(t)
                if len(txs) >= limit:
                    break

        return txs

    def _find_transactions_for_address(
        self, address: str
    ) -> list[
        tuple[
            bytes,
            dict[str, str | int | float | bool | None],
            list[dict[str, str | int | bytes | bool | None]],
        ]
    ]:
        """Scan cache for all transactions that have a node referencing the given address.

        Returns list of (txid, tx_data, nodes) sorted by block_height then order_n.
        """
        results = []
        store = self._store_or_raise

        # Iterate over all transactions in the LMDB store
        with store._env.begin(db=store._db_transactions) as txn:
            cursor = txn.cursor()
            for raw_txid, raw_data in cursor:
                tx_data = store._decrypt(raw_data)
                if tx_data.get("network_name") and tx_data["network_name"] != self.network.name:
                    continue
                nodes = store.get_tx_nodes(raw_txid)
                for node in nodes:
                    if node.get("address") == address:
                        results.append((raw_txid, tx_data, nodes))
                        break

        # Sort by block_height, then order_n
        results.sort(key=lambda x: (x[1].get("block_height") or 0, x[1].get("order_n") or 0))
        return results

    @_test_cache
    async def getblocktransactions(self, height: int, page: int, limit: int) -> list[FluxTransaction]:
        """Get range of transactions from a block.

        :param height: Block height
        :type height: int
        :param page: Transaction page
        :type page: int
        :param limit: Number of transactions per page
        :type limit: int
        :return:
        """
        n_from = (page - 1) * limit
        n_to = page * limit

        store = self._store_or_raise

        # Scan transactions for those at the given block height
        matching: list[
            tuple[
                bytes,
                dict[str, str | int | float | bool | None],
                list[dict[str, str | int | bytes | bool | None]],
                int,
            ]
        ] = []
        with store._env.begin(db=store._db_transactions) as txn:
            cursor = txn.cursor()
            for raw_txid, raw_data in cursor:
                tx_data = store._decrypt(raw_data)
                if tx_data.get("block_height") == height:
                    raw_order_n = tx_data.get("order_n", 0)
                    order_n = raw_order_n if isinstance(raw_order_n, int) else 0
                    if n_from <= order_n < n_to:
                        nodes = store.get_tx_nodes(raw_txid)
                        matching.append((raw_txid, tx_data, nodes, order_n))

        matching.sort(key=lambda x: x[3])

        txs: list[FluxTransaction] = []
        for raw_txid, tx_data, nodes, _ in matching:
            t = self._parse_cached_transaction(raw_txid, tx_data, nodes)
            if t:
                txs.append(t)
        return txs

    @_test_cache
    async def getrawtransaction(self, txid: bytes) -> str | None:
        """Get a raw transaction string from cache if available.

        :param txid: Transaction identification hash
        :type txid: bytes
        :return str: Raw transaction as hexstring
        """

        tx_data = self._store_or_raise.get_transaction(txid)
        if not tx_data:
            return None
        if tx_data.get("network_name") and tx_data["network_name"] != self.network.name:
            return None

        nodes = self._store_or_raise.get_tx_nodes(txid)
        t = self._parse_cached_transaction(txid, tx_data, nodes)
        return t.raw_hex()

    @_test_cache
    async def getutxos(self, address: str, after_txid: bytes | None = None) -> list[dict[str, str | int | None]]:
        """Get list of unspent outputs (UTXO's) for specified address from cache.

        Sorted from old to new, so highest number of confirmations first.

        :param address: Address string
        :type address: str
        :param after_txid: Transaction ID of last known transaction. Only check for utxos after given tx id. Default:
            Leave empty to return all utxos.
        :type after_txid: bytes
        :return dict: UTXO's per address
        """
        # Find all transactions with outputs for this address
        txs_for_address = self._find_transactions_for_address(address)

        utxos: list[dict] = []
        for txid_bytes, tx_data, nodes in txs_for_address:
            for node in nodes:
                if node.get("is_input") or node.get("address") != address:
                    continue

                if node.get("spent") is False:
                    utxos.append(
                        {
                            "address": address,
                            "txid": txid_bytes.hex(),
                            "confirmations": tx_data.get("confirmations", 0),
                            "output_n": node.get("index_n", 0),
                            "input_n": 0,
                            "block_height": tx_data.get("block_height"),
                            "fee": tx_data.get("fee", 0),
                            "size": 0,
                            "value": node.get("value", 0),
                            "script": "",
                            "date": tx_data.get("date"),
                        }
                    )
                elif node.get("spent") is None:
                    # Unknown spent status, stop here
                    return utxos

            if txid_bytes == after_txid:
                utxos = []

        return utxos

    @_test_cache
    async def estimatefee(self, blocks: int) -> int | None:
        """Get fee estimation from cache for confirmation within specified amount of blocks.

        :param blocks: Expected confirmation time in blocks.
        :type blocks: int
        :return int: Fee in the smallest network denominator (satoshi)
        """
        if blocks <= 1:
            varname = "fee_high"
        elif blocks <= 5:
            varname = "fee_medium"
        else:
            varname = "fee_low"

        value = self._store_or_raise.get_var(varname, self.network.name)
        if value:
            return int(value)
        return None

    @_test_cache
    async def blockcount(self, never_expires: bool = False) -> int | None:
        """Get number of blocks on the current network from cache if recent data is available.

        :param never_expires: Always return latest blockcount found.
        :type never_expires: bool
        :return int:
        """
        store = self._store_or_raise

        # get_var already handles TTL expiration; for never_expires we need raw access
        if never_expires:
            # Read directly, bypassing TTL check
            with store._env.begin(db=store._db_vars) as txn:
                raw = txn.get(store._var_key("blockcount", self.network.name))
            if raw is None:
                return 0
            data = store._decrypt(raw)
            raw_val = data.get("value", 0)
            return int(raw_val) if raw_val is not None else 0

        value = store.get_var("blockcount", self.network.name)
        if value:
            return int(value)
        return 0

    @_test_cache
    async def getblock(self, blockid: int | str) -> Block | None:
        """Get specific block from cache.

        :param blockid: Block height or block hash
        :type blockid: int, str
        :return Block:
        """
        store = self._store_or_raise

        block_data: dict[str, object] | None = None
        if isinstance(blockid, int):
            block_data = store.get_block(blockid)
            if not block_data:
                return None
            if block_data.get("network_name") and block_data["network_name"] != self.network.name:
                return None
        else:
            # Search by block hash - scan blocks
            target_hash = to_bytes(blockid)
            # Scan is acceptable here; blocks DB is small
            with store._env.begin(db=store._db_blocks) as txn:
                cursor = txn.cursor()
                for _, raw in cursor:
                    data = store._decrypt(raw)
                    if data.get("block_hash") == target_hash:
                        block_data = data
                        break
            if not block_data:
                return None

        raw_block_hash = block_data.get("block_hash", b"")
        block_hash: bytes | str = raw_block_hash if isinstance(raw_block_hash, (bytes, str)) else b""
        raw_network_name = block_data.get("network_name", "")
        blk_network: str = raw_network_name if isinstance(raw_network_name, str) else ""
        raw_merkle = block_data.get("merkle_root", b"")
        merkle_root: bytes | str = raw_merkle if isinstance(raw_merkle, (bytes, str)) else b""
        raw_time = block_data.get("time", 0)
        blk_time: int = raw_time if isinstance(raw_time, int) else 0
        raw_nonce = block_data.get("nonce", 0)
        blk_nonce: int | bytes | str = raw_nonce if isinstance(raw_nonce, (int, bytes, str)) else 0
        raw_version = block_data.get("version", 1)
        blk_version: int | bytes | str = raw_version if isinstance(raw_version, (int, bytes, str)) else 1
        raw_prev = block_data.get("prev_block", b"")
        prev_block: bytes | str = raw_prev if isinstance(raw_prev, (bytes, str)) else b""
        raw_bits = block_data.get("bits", 0)
        blk_bits: int | bytes | str = raw_bits if isinstance(raw_bits, (int, bytes, str)) else 0

        b = Block(
            block_hash=block_hash,
            height=block_data.get("height"),
            network=blk_network,
            merkle_root=merkle_root,
            time=blk_time,
            nonce=blk_nonce,
            version=blk_version,
            prev_block=prev_block,
            bits=blk_bits,
        )
        raw_tx_count = block_data.get("tx_count", 0)
        b.tx_count = raw_tx_count if isinstance(raw_tx_count, int) else 0
        _logger.info(f"Retrieved block with height {b.height} from cache")
        return b

    @_test_cache
    async def store_blockcount(self, blockcount: int | str) -> None:
        """Store network blockcount in cache for 60 seconds.

        :param blockcount: Number of latest block
        :type blockcount: int, str
        :return:
        """

        self._store_or_raise.put_var(
            "blockcount",
            self.network.name,
            str(blockcount),
            expires=datetime.now(UTC) + timedelta(seconds=60),
        )

    @_test_cache
    async def store_transaction(self, t: FluxTransaction, order_n: int | None = None) -> None:
        """Store transaction in cache.

        :param t: Transaction
        :type t: Transaction
        :param order_n: Order in block
        :type order_n: int
        :return:
        """

        # Only store complete and confirmed transactions
        if not t.txid:  # pragma: no cover
            _logger.info("Caching failure tx: Missing transaction hash")
            return
        if not t.date or not t.block_height or not t.network:
            _logger.info("Caching failure tx: Incomplete transaction missing date, block height or network info")
            return
        if not t.coinbase and [i for i in t.inputs if not i.value]:
            _logger.info("Caching failure tx: One the transaction inputs has value 0")
            return

        txid = bytes.fromhex(t.txid)
        store = self._store_or_raise

        # Skip if already cached
        if store.get_transaction(txid):
            return

        tx_data = {
            "date": t.date.isoformat() if isinstance(t.date, datetime) else t.date,
            "confirmations": t.confirmations,
            "block_height": t.block_height,
            "network_name": t.network.name,
            "fee": t.fee,
            "order_n": order_n,
            "version": t.version_int,
            "locktime": t.locktime,
            "witness_type": t.witness_type if isinstance(t.witness_type, str) else t.witness_type.value,
            "expiry_height": t.expiry_height,
        }
        store.put_transaction(txid, tx_data)

        for i in t.inputs:
            if i.value is None or i.address is None or i.output_n is None:  # pragma: no cover
                _logger.info("Caching failure tx: Input value, address or output_n missing")
                return

            witnesses = int_to_varbyteint(len(i.witnesses)) + b"".join([bytes(varstr(w)) for w in i.witnesses])

            node_data = {
                "address": i.address,
                "value": i.value,
                "ref_txid": i.prev_txid if isinstance(i.prev_txid, bytes) else bytes.fromhex(i.prev_txid),
                "ref_index_n": i.output_n_int,
                "script": i.unlocking_script
                if isinstance(i.unlocking_script, bytes)
                else bytes(i.unlocking_script)
                if i.unlocking_script
                else b"",
                "sequence": i.sequence,
                "witnesses": witnesses,
            }
            store.put_tx_node(txid, i.index_n, True, node_data)

        for o in t.outputs:
            if o.value is None or o.address is None or o.output_n is None:  # pragma: no cover
                _logger.info("Caching failure tx: Output value, address or output_n missing")
                return

            node_data = {
                "address": o.address,
                "value": o.value,
                "spent": o.spent,
                "ref_txid": (
                    None
                    if not o.spending_txid
                    else (bytes.fromhex(o.spending_txid) if isinstance(o.spending_txid, str) else o.spending_txid)
                ),
                "ref_index_n": o.spending_index_n,
                "script": o.lock_script
                if isinstance(o.lock_script, bytes)
                else bytes(o.lock_script)
                if o.lock_script
                else b"",
            }
            store.put_tx_node(txid, o.output_n, False, node_data)

        _logger.info(f"Added transaction {t.txid} to cache")

    @_test_cache
    async def store_utxo(self, txid: str, index_n: int) -> None:
        """Mark a transaction output as unspent in cache.

        :param txid: Transaction ID
        :type txid: str
        :param index_n: Index number of output
        :type index_n: int
        :return:
        """
        store = self._store_or_raise

        txid_bytes = bytes.fromhex(txid)
        node = store.get_tx_node(txid_bytes, index_n, False)
        if node:
            node["spent"] = False
            store.put_tx_node(txid_bytes, index_n, False, node)

    @_test_cache
    async def store_address(
        self,
        address: str,
        last_block: int | None = None,
        balance: int = 0,
        n_utxos: int | None = None,
        txs_complete: bool = False,
        last_txid: bytes | None = None,
        last_tx_index: int | None = None,
    ) -> None:
        """Store address information in cache.

        :param address: Address string
        :type address: str
        :param last_block: Number of last block retrieved
        :type last_block: int
        :param balance: Total balance of address in satoshis
        :type balance: int
        :param n_utxos: Total number of UTXO's for this address
        :type n_utxos: int
        :param txs_complete: True if all transactions for this address are cached
        :type txs_complete: bool
        :param last_txid: Transaction ID of last downloaded transaction
        :type last_txid: bytes
        :param last_tx_index: Index of last transaction
        :type last_tx_index: int
        :return:
        """
        n_txs = None

        if txs_complete:
            # Count transactions and utxos for this address by scanning cache
            txs_for_address = self._find_transactions_for_address(address)
            n_txs = len(txs_for_address)

            if n_utxos is None:
                unspent_count = 0
                has_unknown_spent = False
                for _, _, nodes in txs_for_address:
                    for node in nodes:
                        if node.get("is_input") or node.get("address") != address:
                            continue
                        if node.get("spent") is False:
                            unspent_count += 1
                        elif node.get("spent") is None:
                            has_unknown_spent = True
                n_utxos = None if has_unknown_spent else unspent_count

            if not balance:
                # Calculate balance from inputs and outputs
                total_in = 0
                total_out = 0
                for _, _, nodes in txs_for_address:
                    for node in nodes:
                        if node.get("address") != address:
                            continue
                        raw_node_val = node.get("value", 0)
                        node_val = raw_node_val if isinstance(raw_node_val, int) else 0
                        if node.get("is_input"):
                            total_in += node_val
                        else:
                            total_out += node_val
                balance = total_out - total_in

        existing_result = await self.getaddress(address)
        existing: dict[str, str | int | None] | None = existing_result if isinstance(existing_result, dict) else None

        addr_data: dict[str, str | int | None] = {
            "network_name": self.network.name,
            "last_block": last_block if last_block else (existing.get("last_block") if existing else None),
            "balance": balance if balance is not None else (existing.get("balance") if existing else None),
            "n_utxos": n_utxos if n_utxos is not None else (existing.get("n_utxos") if existing else None),
            "n_txs": n_txs if n_txs is not None else (existing.get("n_txs") if existing else None),
            "last_txid": (last_txid.hex() if isinstance(last_txid, bytes) else last_txid)
            if last_txid is not None
            else (existing.get("last_txid") if existing else None),
            "last_tx_index": last_tx_index
            if last_tx_index is not None
            else (existing.get("last_tx_index") if existing else None),
        }
        self._store_or_raise.put_address(address, addr_data)

    @_test_cache
    async def store_estimated_fee(self, blocks: int, fee: int) -> None:
        """Store estimated fee in cache.

        :param blocks: Confirmation within x blocks
        :type blocks: int
        :param fee: Estimated fee in satoshis
        :type fee: int
        :return:
        """
        if blocks <= 1:
            varname = "fee_high"
        elif blocks <= 5:
            varname = "fee_medium"
        else:
            varname = "fee_low"

        self._store_or_raise.put_var(
            varname,
            self.network.name,
            str(fee),
            expires=datetime.now(UTC) + timedelta(seconds=600),
        )

    @_test_cache
    async def store_block(self, block: Block) -> None:
        """Store block in cache.

        :param block: Block
        :type block: Block
        :return:
        """
        # Genesis block exception
        if (
            not (
                block.height
                and block.block_hash
                and block.prev_block
                and block.merkle_root
                and block.bits
                and block.version
            )
            and block.block_hash
            != b"\x00\x00\x00\x00\x00\x19\xd6h\x9c\x08Z\xe1e\x83\x1e\x93O\xf7c\xaeF\xa2\xa6\xc1r\xb3\xf1\xb6\n\x8c\xe2o"
        ):  # Bitcoin genesis block
            _logger.info("Caching failure block: incomplete data")
            return

        block_data = {
            "block_hash": block.block_hash,
            "network_name": self.network.name,
            "version": block.version_int,
            "prev_block": block.prev_block,
            "bits": block.bits_int,
            "merkle_root": block.merkle_root,
            "nonce": block.nonce_int,
            "time": block.time,
            "tx_count": block.tx_count,
            "height": block.height,
        }
        if block.height is not None:
            self._store_or_raise.put_block(block.height, block_data)
        _logger.info(f"Stored block {block.height} in cache")
