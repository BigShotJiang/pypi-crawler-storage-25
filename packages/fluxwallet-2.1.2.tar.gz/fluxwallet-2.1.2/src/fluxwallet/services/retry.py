"""Retry helper with exponential backoff for HTTP service clients."""

from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

_logger = logging.getLogger(__name__)


async def retry_with_backoff[T](
    func: Callable[[], Awaitable[T]],
    max_attempts: int = 3,
    initial_delay: float = 1.0,
    backoff_factor: float = 2.0,
    jitter: bool = True,
) -> T:
    """Call *func* with retries on transient failures.

    Retries on connection errors, server errors (5xx), and timeouts.
    Client errors (4xx) are permanent and re-raised immediately.
    """
    last_exc: Exception | None = None

    for attempt in range(max_attempts):
        try:
            return await func()
        except httpx.HTTPStatusError as e:
            # 4xx errors are permanent — no retry
            if e.response.status_code < 500:
                raise
            last_exc = e
        except (httpx.RequestError, TimeoutError) as e:
            last_exc = e

        if attempt < max_attempts - 1:
            delay = initial_delay * (backoff_factor ** attempt)
            if jitter:
                delay *= random.uniform(0.5, 1.5)  # noqa: S311
            _logger.warning(
                "Retry %d/%d after %.1fs: %s",
                attempt + 1,
                max_attempts,
                delay,
                last_exc,
            )
            await asyncio.sleep(delay)

    raise last_exc  # type: ignore[misc]
