# Changelog

All notable changes to **safecadence-network-risk** are documented here.
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-05-02

Initial public release.

### Added
- **Network discovery engine** (`safecadence discover <cidr>`) — multi-threaded
  TCP sweep over any CIDR, banner-grab on common management ports, OUI-based
  MAC-vendor lookup, and heuristic OS / device-type identification. No raw
  sockets, no root required. Identifies Cisco IOS / IOS-XE / NX-OS / ASA,
  Aruba, Arista, Juniper, Fortinet, Palo Alto, MikroTik, Ubiquiti, Meraki,
  Mist, plus generic Linux / Windows / printers / IoT.
- Vendor adapter framework (`BaseAdapter`, `AdapterRegistry`) with auto-discovery.
- **Five vendor adapters** with pure-stdlib parsers:
  - Cisco IOS / IOS-XE
  - Cisco NX-OS (Nexus)
  - Cisco ASA Firewall
  - Aruba CX (AOS-CX)
  - Arista EOS
- **Config audit engine** that loads YAML rule packs and runs three rule types:
  `match_regex`, `absent_regex`, and sandboxed `custom` Python expressions.
- **77 audit rules** total, shipping out of the box:
  - 34 Cisco IOS rules
  - 11 Cisco NX-OS rules
  - 11 Cisco ASA rules
  - 10 Aruba CX rules
  - 11 Arista EOS rules
- Deterministic **Health (0–100)** and **Risk (0–100)** scoring with bands and
  business-criticality multipliers.
- **Four report formats**:
  - Rich-formatted CLI table (color, summary panel)
  - Portable Markdown (`--output`)
  - Machine-readable JSON (`--json`)
  - Self-contained, brand-able HTML (`--html`)
  - Microsoft Word .docx (`--docx`) — pure stdlib, no external deps
- **Bring-Your-Own-Key AI** module — talks directly to OpenAI or Anthropic
  from the user's machine. Keys never touch SafeCadence servers. Supports
  `--output` to save the briefing as Markdown.
- CLI: `safecadence scan | discover | list-vendors | list-rules | rule-info | ai-explain | history`.
- Optional local SQLite scan history (`--save-history`).
- Sample configs for every vendor in `examples/sample_configs/`.
- 66-test pytest suite covering parsers, registry auto-discovery, rule
  loading, scan-to-score pipeline, every renderer, characteristic-rule
  spot checks for each vendor, and the network discovery engine
  (OUI lookup, banner heuristics, sweep with mock TCP listener).
- Convenience `Makefile` (`make install | scan | ai | report | test | shell`).
- GitHub Actions CI matrix (Python 3.10/3.11/3.12) with smoke tests.

### Privacy promises
- The CLI never makes network calls except to the BYOK AI provider you
  explicitly opt into.
- API keys are read from environment variables or `--api-key` only, with
  whitespace trimmed defensively.
- All findings stay on disk unless you run `--save-history`.
