"""
FastAPI app factory.

Endpoints (all JWT-bearer auth except /api/login + /api/health):

    POST /api/login                  → JWT
    GET  /api/health                 → liveness
    GET  /api/me                     → current user info

    GET  /api/devices                → fleet list (latest scan per host)
    GET  /api/devices/{hostname}     → full latest scan
    GET  /api/scans                  → recent scans (history)
    GET  /api/scans/{id}             → one scan payload

    POST /api/scan                   → upload + scan one config (admin/analyst)
    POST /api/scan/bulk              → upload many configs (admin/analyst)

    GET  /api/cves                   → bundled CVE DB
    GET  /api/eol                    → bundled EOL DB
    GET  /api/vendors                → registered adapters
    GET  /api/rules                  → all audit rules

    GET  /api/dashboard.html         → live single-file dashboard
"""

import json
import os
import secrets as _secrets
from typing import List, Optional

# IMPORTANT: import FastAPI at MODULE level (not inside create_app) so its
# annotation classes resolve cleanly when FastAPI inspects the route handlers.
# Wrapped in try/except so the module imports cleanly without [server] extras —
# create_app() raises a friendly error instead.
try:
    from fastapi import Body, Depends, FastAPI, File, HTTPException, Query, UploadFile
    from fastapi.responses import HTMLResponse, JSONResponse
    from fastapi.security import (
        HTTPAuthorizationCredentials, HTTPBearer, OAuth2PasswordRequestForm,
    )
    _SERVER_AVAILABLE = True
except ImportError:
    _SERVER_AVAILABLE = False

from safecadence.server.auth import (
    CurrentUser, authenticate, decode_jwt, load_users, make_jwt, require_role,
)


def create_app(*, db_url: Optional[str] = None, jwt_secret: Optional[str] = None,
               users_file: Optional[str] = None):
    if not _SERVER_AVAILABLE:
        raise RuntimeError(
            "API server requires the [server] extras: "
            "pip install 'safecadence-network-risk[server]'"
        )
    from safecadence.bulk import bulk_scan, _scan_one
    from safecadence.core.registry import AdapterRegistry
    from safecadence.dashboard import build_dashboard_data, render_dashboard
    from safecadence.engines.config_audit import load_rules
    from safecadence.enrichment import load_cve_db, load_eol_db
    from safecadence.storage import open_store

    secret = jwt_secret or os.environ.get("SC_JWT_SECRET") or _secrets.token_urlsafe(32)
    load_users(users_file)              # bootstrap on first run
    store  = open_store(db_url or os.environ.get("DATABASE_URL"))
    bearer = HTTPBearer(auto_error=False)

    app = FastAPI(
        title="SafeCadence Network Risk API",
        version="2.0",
        description="Open-source enterprise network risk auditing — local-first, BYO-AI.",
    )

    # ---- helpers ------------------------------------------------ #
    def get_current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> CurrentUser:
        if not creds or not creds.credentials:
            raise HTTPException(status_code=401, detail="Bearer token required")
        return decode_jwt(creds.credentials, secret=secret)

    def require_admin(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        return require_role("admin")(user)

    def require_writer(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        return require_role("admin", "analyst")(user)

    def audit(user: CurrentUser, action: str, resource: str = "", detail: str = ""):
        if hasattr(store, "audit"):
            try:
                store.audit(tenant_id=user.tenant, actor=user.username,
                            action=action, resource=resource, detail=detail)
            except Exception:
                pass

    # ---- public --------------------------------------------------- #
    @app.get("/api/health")
    def health():
        return {"status": "ok", "version": "2.0"}

    @app.post("/api/login")
    def login(form: OAuth2PasswordRequestForm = Depends()):
        # Re-read users.yaml on every login so admins can edit it without restart
        users_now = load_users(users_file)
        user = authenticate(users_now, username=form.username, password=form.password)
        if not user:
            raise HTTPException(status_code=401, detail="Bad username or password")
        token = make_jwt(user, secret=secret, ttl_minutes=60)
        return {"access_token": token, "token_type": "bearer",
                "tenant": user.tenant, "roles": user.roles}

    # ---- introspection ------------------------------------------- #
    @app.get("/api/me")
    def me(user: CurrentUser = Depends(get_current_user)):
        return {"username": user.username, "tenant": user.tenant, "roles": user.roles}

    @app.get("/api/vendors")
    def vendors(_user: CurrentUser = Depends(get_current_user)):
        return [a.info() for a in AdapterRegistry.all()]

    @app.get("/api/rules")
    def rules(vendor: Optional[str] = None, _user: CurrentUser = Depends(get_current_user)):
        return [{
            "id": r.id, "title": r.title, "severity": r.severity.value,
            "vendor": r.vendor, "domain": r.domain,
        } for r in load_rules(vendor=vendor)]

    @app.get("/api/cves")
    def cves(_user: CurrentUser = Depends(get_current_user)):
        db = load_cve_db()
        return {v: items for v, items in db.items()}

    @app.get("/api/eol")
    def eol(_user: CurrentUser = Depends(get_current_user)):
        return [r.to_dict() for r in load_eol_db()]

    # ---- fleet --------------------------------------------------- #
    @app.get("/api/devices")
    def devices(user: CurrentUser = Depends(get_current_user)):
        return store.latest_per_host(tenant_id=user.tenant)

    @app.get("/api/devices/{hostname}")
    def device(hostname: str, user: CurrentUser = Depends(get_current_user)):
        rows = store.latest_per_host(tenant_id=user.tenant)
        match = next((r for r in rows if r["hostname"] == hostname), None)
        if not match:
            raise HTTPException(status_code=404, detail="Device not found")
        full = store.get(match["id"], tenant_id=user.tenant)
        return full or match

    @app.get("/api/scans")
    def scans(limit: int = Query(50, le=500),
              user: CurrentUser = Depends(get_current_user)):
        return store.list(limit=limit, tenant_id=user.tenant)

    @app.get("/api/scans/{scan_id}")
    def scan_detail(scan_id: int, user: CurrentUser = Depends(get_current_user)):
        d = store.get(scan_id, tenant_id=user.tenant)
        if d is None:
            raise HTTPException(status_code=404, detail="Scan not found")
        return d

    # ---- mutation ------------------------------------------------ #
    @app.post("/api/scan")
    async def post_scan(file: UploadFile = File(...),
                        vendor: Optional[str] = Query(None),
                        criticality: str = Query("medium"),
                        user: CurrentUser = Depends(require_writer)):
        from pathlib import Path
        import tempfile
        tmp = tempfile.NamedTemporaryFile(suffix=".txt", delete=False)
        try:
            tmp.write(await file.read())
            tmp.close()
            result, summary = _scan_one(Path(tmp.name), vendor_override=vendor,
                                        criticality=criticality)
            if result is None:
                raise HTTPException(status_code=400, detail=summary.error or "scan failed")
            scan_id = store.save(result.to_dict(), tenant_id=user.tenant)
            audit(user, "scan", resource=summary.hostname,
                  detail=f"risk={summary.risk}")
            return {"scan_id": scan_id, "summary": {
                "hostname": summary.hostname, "vendor": summary.vendor,
                "health": summary.health, "risk": summary.risk,
                "findings": summary.findings, "cves": summary.cves,
                "eol_status": summary.eol_status,
            }}
        finally:
            try: os.unlink(tmp.name)
            except OSError: pass

    @app.post("/api/scan/bulk")
    async def post_bulk(files: List[UploadFile] = File(...),
                        criticality: str = Query("medium"),
                        user: CurrentUser = Depends(require_writer)):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            for f in files:
                (td_path / f.filename).write_bytes(await f.read())
            results = bulk_scan(td_path, criticality=criticality)
            saved = []
            for r in results:
                if r.error:
                    continue
                # re-scan to get full ScanResult dict (bulk_scan returns summaries only)
                full, _ = _scan_one(Path(r.source), criticality=criticality)
                if full:
                    sid = store.save(full.to_dict(), tenant_id=user.tenant)
                    saved.append({"scan_id": sid, "hostname": r.hostname,
                                  "vendor": r.vendor, "risk": r.risk})
            audit(user, "scan_bulk", detail=f"{len(saved)} devices")
            return {"saved": saved, "total": len(results)}

    # ---- live dashboard (HTML) ----------------------------------- #
    @app.get("/api/dashboard.html", response_class=HTMLResponse)
    def dashboard_live(user: CurrentUser = Depends(get_current_user)):
        rows = store.latest_per_host(tenant_id=user.tenant)
        scans_full = []
        for r in rows:
            full = store.get(r["id"], tenant_id=user.tenant)
            if full: scans_full.append(full)
        data = build_dashboard_data(scans_full)
        return HTMLResponse(render_dashboard(
            data, title=f"SafeCadence — {user.tenant}"
        ))

    return app
