<div align="center">

# SafeCadence Network Risk

**Free, open-source network infrastructure risk auditing.**
Local-first · Multi-vendor · Bring your own AI key.

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![PyPI](https://img.shields.io/badge/pypi-coming_soon-blue)](https://pypi.org/project/safecadence-network-risk/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

</div>

```bash
pip install safecadence-network-risk
safecadence scan my-cisco-config.txt
```

That's it. Score, prioritized findings, and remediation in your terminal in **under 5 seconds**, with zero data leaving your machine.

### From source (one-shot, no PATH headaches)

If you cloned the repo, the included `Makefile` handles the venv for you:

```bash
git clone https://github.com/safecadence/safecadence-network-risk.git
cd safecadence-network-risk
make install     # creates .venv, installs the package + AI extras + pytest
make scan        # scans the bundled sample config
make ai          # runs the BYOK AI explainer (set OPENAI_API_KEY first)
make test        # runs the test suite
```

`make help` lists every target.

---

## What it does

SafeCadence Network Risk audits enterprise infrastructure configs for security gaps, configuration drift, and end-of-life risk. It does what AlgoSec, Tufin, and FireMon do — minus the six-figure license, the 14-day install, and the "your data goes to our cloud" tradeoff.

- **Multi-vendor parsing** — Cisco IOS / IOS-XE, Cisco NX-OS, Cisco ASA, Aruba CX, Arista EOS today; Juniper, Palo Alto, Fortinet, MikroTik next.
- **64 config audit rules** out of the box, each with a vendor-specific fix snippet you can paste.
- **Health & risk scoring** — separate 0-100 scores, computed deterministically with business-criticality weighting.
- **Five report formats** — terminal table, Markdown, JSON, branded HTML, Word .docx — all from one command.
- **CVE matching** (planned for v0.2 — NVD + KEV feed cached locally).
- **EOL/EOS tracking** (planned for v0.2 — endoflife.date data, no API call).
- **Bring-your-own-AI** — pass your OpenAI/Anthropic key on the command line for an executive remediation plan. We never see it.
- **100% local** — no telemetry, no cloud sync, no account, no signup.

## Why it exists

Every firewall and switch audit finds the same handful of issues: any/any rules, missing logging, default SNMP communities, telnet still enabled, OS versions years past EOL. The expensive enterprise tools that catch these:

- Charge $50k+/year per-license
- Require 1-2 weeks of professional services to deploy
- Force your config data through their cloud
- Lock the rule library so you can't audit or extend it

SafeCadence Network Risk is the **opposite of all of that**: free, open, local, contributable, and capable in 5 minutes.

## Quick start

### Install
```bash
pip install safecadence-network-risk
```

### Scan a config file
```bash
safecadence scan path/to/cisco-running-config.txt
```

You'll get a colored terminal report like this:

```
╭──────────────────────────────────────────────────────────────╮
│           SafeCadence Network Risk Report                    │
│                                                               │
│  Vendor:  Cisco IOS / IOS-XE                                  │
│  Health:  72/100  ⚠  warning                                  │
│  Risk:    81/100  ⛔ critical                                 │
│                                                               │
│  9 findings — 3 critical, 4 high, 2 medium                    │
╰──────────────────────────────────────────────────────────────╯

Top 3 findings:
  ⛔ CRITICAL  Telnet enabled on management VTYs
  ⛔ CRITICAL  SNMP community 'public' configured
  ⛔ CRITICAL  BGP neighbor without MD5 authentication
```

### Save report as JSON / Markdown
```bash
safecadence scan running-config.txt -o report.md
safecadence scan running-config.txt -o report.json --format json
```

### Get an AI remediation plan (BYO-key)
```bash
export OPENAI_API_KEY=sk-...
safecadence ai-explain report.json
```

Your key never leaves your machine. The prompt is sent directly from your computer to OpenAI/Anthropic.

### Browse rules and vendors
```bash
safecadence list-vendors
safecadence list-rules
safecadence rule-info telnet-enabled
```

## How it compares

|                            | SafeCadence   | Tufin SecureTrack | AlgoSec ASMS  | RANCID / Oxidized |
|---------------------------|---------------|-------------------|---------------|--------------------|
| Free / open source        | ✅ MIT        | ❌                | ❌            | ✅                 |
| Install in 5 minutes      | ✅            | ❌ days           | ❌ days       | ⚠ hours            |
| Local-first (no cloud)    | ✅            | ⚠                 | ⚠             | ✅                 |
| Config audit rules        | 30+ (YAML)    | hundreds          | hundreds      | ❌ (backup only)   |
| Multi-vendor              | ✅ (planned)  | ✅                | ✅            | ✅                 |
| AI summaries (BYO-key)    | ✅            | ❌                | ⚠ (their key) | ❌                 |
| Per-finding fix snippets  | ✅            | ⚠                 | ⚠             | ❌                 |
| Contributable rule library| ✅ (YAML PRs) | ❌                | ❌            | ❌                 |
| Annual cost               | $0            | $50k-$300k        | $50k-$500k    | $0                 |

## What's in v0.1 (today)

- ✅ Cisco IOS / IOS-XE parser + scanner
- ✅ 30 config audit rules (data-driven YAML)
- ✅ Health + risk scoring engines (deterministic, no AI)
- ✅ Markdown + JSON report renderers
- ✅ BYO-key AI remediation (`OPENAI_API_KEY` or `ANTHROPIC_API_KEY`)
- ✅ Pretty CLI with `rich`
- ✅ Local SQLite history (opt-in)
- ✅ Sample configs for testing

## What's coming in v0.2

- 🔜 Aruba CX adapter
- 🔜 Arista EOS adapter
- 🔜 HTML + PDF + Word report renderers
- 🔜 EOL data (endoflife.date integration, refreshed nightly, cached locally)
- 🔜 CVE matching (NVD JSON feed + CISA KEV, cached locally)
- 🔜 Topology map output (LLDP/CDP parsing)
- 🔜 Asset inventory CSV import
- 🔜 SSH-based config collection

## What's coming in v1.0

- 🔭 Web UI (`safecadence serve` → local FastAPI dashboard)
- 🔭 Multi-tenant SaaS deployment mode
- 🔭 Compliance mapping (PCI / SOC 2 / HIPAA / NIST)
- 🔭 Juniper, Palo Alto, Fortinet, MikroTik
- 🔭 Cloud audit (AWS / Azure / GCP)

[See the full roadmap →](docs/ROADMAP.md)

## Architecture

Modular, plugin-based, deliberately simple:

```
safecadence/
  core/         common asset schema, base adapter, local store
  adapters/     vendor adapters (cisco_ios, aruba_cx, arista_eos, ...)
  engines/      config_audit, health, risk, topology, eol, cve
  reports/      markdown, json, html, pdf, docx renderers
  ai/           BYO-key OpenAI / Anthropic / local-LLM client
  data/         rules (YAML), EOL / CVE caches
  cli.py        click-based CLI
```

Each vendor adapter is a self-contained Python module. Each audit rule is a YAML file. **You can contribute either without touching framework code.**

[Read the architecture guide →](docs/ARCHITECTURE.md)
[Write a vendor adapter →](docs/ADAPTER_GUIDE.md)
[Write an audit rule →](docs/RULE_GUIDE.md)

## Privacy

- **Configs never leave your machine** unless you explicitly export them
- **No telemetry**, no usage tracking, no phone-home
- **No account** — no signup, no email, no API key (ours)
- **AI calls** are sent directly from your computer to your AI provider with your own key. SafeCadence is not in the loop.
- **Local SQLite history** is opt-in via `--save-history`

## Contributing

We want this to be the project that the network and security community actually uses. The two highest-leverage contributions:

1. **Add a vendor adapter** — see [ADAPTER_GUIDE.md](docs/ADAPTER_GUIDE.md). One Python file + tests.
2. **Add a config audit rule** — see [RULE_GUIDE.md](docs/RULE_GUIDE.md). One YAML file. No code required.

[Contribution guide →](CONTRIBUTING.md)
[Good first issues →](https://github.com/safecadence/network-risk/issues?q=is%3Aopen+is%3Aissue+label%3A%22good+first+issue%22)

## Need expert help?

The tool is free forever. If you want SafeCadence to **execute** the recommendations — full audit, change windows, validation, knowledge transfer — we offer paid engagements.

📧 [hello@safecadence.com](mailto:hello@safecadence.com)
🌐 [safecadence.com/consulting](https://safecadence.com/consulting)

## License

MIT — see [LICENSE](LICENSE). Commercial use, modification, redistribution all permitted. We just ask you keep the copyright notice.

## Acknowledgements

Standing on the shoulders of:

- [endoflife.date](https://endoflife.date/) — open EOL data
- [NVD](https://nvd.nist.gov/) — CVE feed
- [CISA KEV](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) — known-exploited vulns
- [NIST SP 800-41 / SP 800-53](https://csrc.nist.gov/publications) — best-practice baselines
- The [rich](https://github.com/Textualize/rich) and [click](https://github.com/pallets/click) communities
