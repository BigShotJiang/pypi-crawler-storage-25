"""End-to-end build pipeline: derive manifest → validate → package → sign → write.

This module orchestrates every other M4 module. The CLI's
``synax skill build`` command loads the :class:`Skill` and the project's
``entry_point`` (via :mod:`synax_skill_cli.utils.project`) and passes
them in; ``synax_sdk.build`` itself stays independent of the CLI package
to avoid a circular dependency.

The pipeline:

1. Caller has already loaded a :class:`Skill` and read the project's
   ``entry_point`` from ``pyproject.toml [tool.synax]``.
2. Derive an in-memory :class:`Manifest` (M2 logic).
3. Build the deterministic tar.gz artifact (M4 packaging); pin its
   ``sha256`` onto ``implementation.hash`` and set ``entry_point``.
4. Validate the now-populated manifest. Schema-layer and consistency
   errors are blocking; warnings are surfaced but don't fail the build.
5. Sign the canonical form with the chosen key (defaults to the store's
   active key). Append the :class:`Signature` to the manifest.
6. Write the signed bundle to ``<project_root>/build/`` by default.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass
from pathlib import Path

from synax_sdk.errors import BuildError
from synax_sdk.manifest import Manifest, Signature
from synax_sdk.packaging import ArtifactResult, build_implementation_artifact
from synax_sdk.signing import KeyStore
from synax_sdk.skill import Skill
from synax_sdk.validation import ValidationError, validate_manifest

DEFAULT_OUTPUT_SUBDIR = "build"
BUNDLE_SUBDIR = "signed_bundle"


@dataclass(frozen=True)
class BuildResult:
    """Everything a successful build produced."""

    manifest: Manifest
    artifact: ArtifactResult
    signature: Signature
    output_dir: Path
    bundle_dir: Path
    warnings: list[ValidationError]


def build(
    project_root: Path,
    skill: Skill,
    *,
    entry_point: str,
    key_fingerprint: str | None = None,
    output_dir: Path | None = None,
    key_store: KeyStore | None = None,
) -> BuildResult:
    """Run the full build pipeline and return the :class:`BuildResult`.

    Args:
        project_root: the directory whose contents will be packaged.
        skill: the loaded skill object (caller has already imported it).
        entry_point: ``module:variable`` import path (becomes
            ``implementation.entry_point`` in the manifest).
        key_fingerprint: signing key. Defaults to the key store's active
            default (``synax keys set-default``).
        output_dir: where to write build outputs. Defaults to
            ``<project_root>/build``.
        key_store: override the key store location (test seam). Defaults
            to ``~/.synax/keys``.

    Raises:
        BuildError: if validation fails with blocking errors, or no
            signing key is available.
    """
    project_root = project_root.resolve()
    output_dir = (output_dir or project_root / DEFAULT_OUTPUT_SUBDIR).resolve()
    key_store = key_store or KeyStore.default()

    manifest = Manifest.from_skill(skill)
    manifest.implementation.entry_point = entry_point

    artifact = build_implementation_artifact(
        project_root,
        extra_ignore=_build_output_relative_pattern(project_root, output_dir),
    )
    manifest.implementation.hash = artifact.sha256

    errors = validate_manifest(manifest)
    blocking = [e for e in errors if e.kind != "warning"]
    warnings = [e for e in errors if e.kind == "warning"]
    if blocking:
        raise BuildError(
            f"Manifest failed validation ({len(blocking)} error(s)). "
            "Fix the issues below and re-run `synax skill build`.",
            errors=list(blocking),
        )

    fingerprint = key_fingerprint or key_store.default_fingerprint
    if fingerprint is None:
        raise BuildError(
            "No signing key available. Run `synax keys generate` to create one, "
            "or pass --key <fingerprint>."
        )
    keypair = key_store.load(fingerprint)
    canonical = manifest.to_canonical_json()
    signature_b64 = keypair.signer().sign(canonical)
    signature = Signature(
        key_fingerprint=fingerprint,
        signer_type="author",
        signature=signature_b64,
        signed_at=datetime.datetime.now(datetime.UTC).isoformat(),
    )
    manifest.signatures.append(signature)

    bundle_dir = _write_outputs(output_dir, manifest, artifact, canonical)

    return BuildResult(
        manifest=manifest,
        artifact=artifact,
        signature=signature,
        output_dir=output_dir,
        bundle_dir=bundle_dir,
        warnings=warnings,
    )


def _build_output_relative_pattern(project_root: Path, output_dir: Path) -> list[str] | None:
    """Return a ``.synax-skillignore``-compatible pattern excluding ``output_dir``.

    Returns ``None`` when ``output_dir`` is outside the project tree (no
    need to ignore — packaging wouldn't pick it up anyway).
    """
    try:
        rel = output_dir.relative_to(project_root)
    except ValueError:
        return None
    rel_str = rel.as_posix().strip("/")
    return [f"{rel_str}/"] if rel_str else None


def _write_outputs(
    output_dir: Path,
    manifest: Manifest,
    artifact: ArtifactResult,
    canonical: bytes,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    bundle_dir = output_dir / BUNDLE_SUBDIR
    bundle_dir.mkdir(parents=True, exist_ok=True)

    # Bundle: what gets uploaded to the platform.
    (bundle_dir / "manifest.yaml").write_text(manifest.to_yaml(), encoding="utf-8")
    (bundle_dir / "implementation.tar.gz").write_bytes(artifact.tar_gz_bytes)

    # Diagnostic files at the build root.
    (output_dir / "manifest.yaml").write_text(manifest.to_yaml(), encoding="utf-8")
    (output_dir / "manifest.json").write_text(manifest.to_json(), encoding="utf-8")
    (output_dir / "manifest.canonical").write_bytes(canonical)

    return bundle_dir
