"""The :class:`Skill` class — the central object skill authors construct.

A skill author writes a Python module that looks like this:

.. code-block:: python

    from synax_sdk import Skill

    skill = Skill(
        name="github-pr-summary",
        version="1.0.0",
        description="Fetch and summarize GitHub pull requests",
        capabilities=["network:api.github.com", "secrets:GITHUB_TOKEN"],
        secrets=[{"name": "GITHUB_TOKEN", "type": "oauth_token", "description": "..."}],
    )

    @skill.tool(description="Fetch a PR")
    async def summarize_pr(repo: str, pr_number: int) -> dict:
        ...

The constructor validates every field at definition time so authors get
fast, actionable feedback. The ``@skill.tool`` decorator registers tools
on the skill and returns the original function unchanged.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal, TypeVar

from synax_sdk.errors import SkillDefinitionError
from synax_sdk.tool import Tool

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,127}$")
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+(?:-[\w.-]+)?(?:\+[\w.-]+)?$")
CAPABILITY_RE = re.compile(r"^[a-z][a-z_]*:.+$")
SECRET_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")

ExecutionLocation = Literal[
    "daemon_only",
    "cloud_only",
    "prefer_daemon",
    "prefer_cloud",
    "either",
]
VALID_EXECUTION_LOCATIONS: frozenset[str] = frozenset(
    ["daemon_only", "cloud_only", "prefer_daemon", "prefer_cloud", "either"]
)

SecretType = Literal[
    "api_key",
    "oauth_token",
    "database_password",
    "ssh_key",
    "certificate",
    "generic_string",
]
VALID_SECRET_TYPES: frozenset[str] = frozenset(
    [
        "api_key",
        "oauth_token",
        "database_password",
        "ssh_key",
        "certificate",
        "generic_string",
    ]
)


# ---------------------------------------------------------------------------
# Supporting dataclasses
# ---------------------------------------------------------------------------
@dataclass
class Secret:
    """A secret a skill declares it needs.

    The skill author lists these on the :class:`Skill`. The platform shows
    the list at install time so the workspace admin can configure values.

    Attributes:
        name: identifier the skill passes to ``secrets.get(name)``.
            Convention: SCREAMING_SNAKE_CASE.
        type: one of :data:`SecretType` — informs the platform's UI.
        description: human-readable description of the secret.
        scope_required: optional OAuth scope, useful when ``type="oauth_token"``.
    """

    name: str
    type: SecretType
    description: str
    scope_required: str | None = None


@dataclass
class SkillDependency:
    """A semver-constrained dependency on another skill."""

    skill: str
    version: str


@dataclass
class SkillMetadata:
    """Marketplace-visible metadata. Every field is optional."""

    category: str | None = None
    tags: list[str] = field(default_factory=list)
    homepage: str | None = None
    source: str | None = None
    documentation: str | None = None
    license: str | None = None
    long_description: str | None = None
    icon_url: str | None = None


# Type variable for the @tool decorator so the wrapped function's type is preserved.
F = TypeVar("F", bound=Callable[..., Any])


# ---------------------------------------------------------------------------
# Skill
# ---------------------------------------------------------------------------
class Skill:
    """A skill being authored.

    Construct one at module scope, register tools with :meth:`tool`, and the
    SDK derives the manifest from the result.

    All fields are validated in ``__init__``. Errors raise
    :class:`~synax_sdk.errors.SkillDefinitionError` with a message that
    names the specific field and (where useful) a suggestion.
    """

    def __init__(
        self,
        *,
        name: str,
        version: str,
        description: str,
        display_name: str | None = None,
        namespace: str | None = None,
        capabilities: list[str] | None = None,
        execution_location: ExecutionLocation = "either",
        secrets: list[Secret | dict[str, Any]] | None = None,
        dependencies: list[SkillDependency | dict[str, Any]] | None = None,
        metadata: SkillMetadata | dict[str, Any] | None = None,
    ) -> None:
        self.name = _validate_name(name)
        self.version = _validate_version(version)
        self.description = _validate_description(description)
        self.display_name = display_name if display_name is not None else _humanize(name)
        self.namespace = _validate_namespace(namespace) if namespace is not None else None
        self.capabilities = _validate_capabilities(capabilities or [])
        self.execution_location = _validate_execution_location(execution_location)
        self.secrets = _normalize_secrets(secrets or [])
        self.dependencies = _normalize_dependencies(dependencies or [])
        self.metadata = _normalize_metadata(metadata)

        _check_secrets_match_capabilities(self.secrets, self.capabilities)

        self._tools: list[Tool] = []

    # ----- Tool registration -------------------------------------------------
    def tool(self, *, description: str) -> Callable[[F], F]:
        """Decorator that registers a function as a tool on this skill.

        The decorated function is returned unchanged, so authors can still
        invoke it directly during local testing. Registration is a side
        effect of decoration.

        Raises:
            SkillDefinitionError: from :meth:`Tool.from_function` if the
                function isn't shaped like a tool, or if a tool with the
                same name is already registered.
        """

        def decorator(func: F) -> F:
            new_tool = Tool.from_function(func, description=description)
            for existing in self._tools:
                if existing.name == new_tool.name:
                    raise SkillDefinitionError(
                        f"Skill {self.name!r} already has a tool named {new_tool.name!r}. "
                        "Tool names must be unique within a skill."
                    )
            self._tools.append(new_tool)
            return func

        return decorator

    @property
    def tools(self) -> list[Tool]:
        """Tools registered on this skill, in declaration order. Returns a copy."""
        return list(self._tools)

    def __repr__(self) -> str:
        ns = f"{self.namespace}/" if self.namespace else ""
        return f"Skill({ns}{self.name} v{self.version}, {len(self._tools)} tool(s))"


# ---------------------------------------------------------------------------
# Field validators (module-level so they can be reused / tested directly)
# ---------------------------------------------------------------------------
def _validate_name(name: str) -> str:
    if not isinstance(name, str) or not SLUG_RE.match(name):
        suggestion = _slug_suggestion(name) if isinstance(name, str) else None
        msg = (
            f"Invalid skill name {name!r}. "
            "Names must be lowercase slug format: start with a letter or digit, "
            "use only [a-z0-9-], 1-128 characters."
        )
        if suggestion and suggestion != name:
            msg += f" Did you mean {suggestion!r}?"
        raise SkillDefinitionError(msg)
    return name


def _validate_version(version: str) -> str:
    if not isinstance(version, str) or not SEMVER_RE.match(version):
        raise SkillDefinitionError(
            f"Invalid skill version {version!r}. "
            "Versions must be semver (e.g. '1.0.0', '0.1.0-beta.1', '2.3.4+build.5')."
        )
    return version


def _validate_description(description: str) -> str:
    if not isinstance(description, str) or not description.strip():
        raise SkillDefinitionError("Skill description must be a non-empty string.")
    if len(description) > 256:
        raise SkillDefinitionError(
            f"Skill description is too long ({len(description)} chars). "
            "Keep it under 256 characters; use metadata.long_description for more."
        )
    return description


def _validate_namespace(namespace: str) -> str:
    if not isinstance(namespace, str) or not SLUG_RE.match(namespace):
        raise SkillDefinitionError(
            f"Invalid namespace {namespace!r}. "
            "Namespaces use the same slug format as skill names "
            "(lowercase [a-z0-9-], 1-128 chars)."
        )
    return namespace


def _validate_capabilities(capabilities: list[str]) -> list[str]:
    seen: set[str] = set()
    for cap in capabilities:
        if not isinstance(cap, str) or not CAPABILITY_RE.match(cap):
            raise SkillDefinitionError(
                f"Invalid capability {cap!r}. "
                "Capabilities follow '<type>:<specifier>' format, "
                "e.g. 'network:api.github.com', 'secrets:GITHUB_TOKEN', "
                "'filesystem:read:/data'."
            )
        if cap in seen:
            raise SkillDefinitionError(f"Duplicate capability {cap!r}.")
        seen.add(cap)
    return list(capabilities)


def _validate_execution_location(value: str) -> str:
    if value not in VALID_EXECUTION_LOCATIONS:
        raise SkillDefinitionError(
            f"Invalid execution_location {value!r}. "
            f"Must be one of: {sorted(VALID_EXECUTION_LOCATIONS)}."
        )
    return value


def _normalize_secrets(secrets: list[Secret | dict[str, Any]]) -> list[Secret]:
    result: list[Secret] = []
    seen_names: set[str] = set()
    for idx, item in enumerate(secrets):
        if isinstance(item, Secret):
            secret = item
        elif isinstance(item, dict):
            try:
                secret = Secret(**item)
            except TypeError as exc:
                raise SkillDefinitionError(
                    f"secrets[{idx}]: could not construct Secret from {item!r}: {exc}. "
                    "Each secret dict must have name, type, description, "
                    "and optionally scope_required."
                ) from exc
        else:
            raise SkillDefinitionError(
                f"secrets[{idx}] must be a Secret or dict, got {type(item).__name__}."
            )

        if not isinstance(secret.name, str) or not SECRET_NAME_RE.match(secret.name):
            raise SkillDefinitionError(
                f"secrets[{idx}].name {secret.name!r}: invalid format. "
                "Secret names should be SCREAMING_SNAKE_CASE (e.g. GITHUB_TOKEN)."
            )
        if secret.type not in VALID_SECRET_TYPES:
            raise SkillDefinitionError(
                f"secrets[{idx}].type {secret.type!r}: must be one of "
                f"{sorted(VALID_SECRET_TYPES)}."
            )
        if not isinstance(secret.description, str) or not secret.description.strip():
            raise SkillDefinitionError(
                f"secrets[{idx}] ({secret.name!r}): description must be a non-empty string."
            )
        if secret.name in seen_names:
            raise SkillDefinitionError(f"Duplicate secret name {secret.name!r}.")
        seen_names.add(secret.name)
        result.append(secret)
    return result


def _normalize_dependencies(
    deps: list[SkillDependency | dict[str, Any]],
) -> list[SkillDependency]:
    result: list[SkillDependency] = []
    for idx, item in enumerate(deps):
        if isinstance(item, SkillDependency):
            result.append(item)
        elif isinstance(item, dict):
            try:
                result.append(SkillDependency(**item))
            except TypeError as exc:
                raise SkillDefinitionError(
                    f"dependencies[{idx}]: could not construct SkillDependency from "
                    f"{item!r}: {exc}. Each dep needs skill and version."
                ) from exc
        else:
            raise SkillDefinitionError(
                f"dependencies[{idx}] must be a SkillDependency or dict, "
                f"got {type(item).__name__}."
            )
    return result


def _normalize_metadata(metadata: SkillMetadata | dict[str, Any] | None) -> SkillMetadata:
    if metadata is None:
        return SkillMetadata()
    if isinstance(metadata, SkillMetadata):
        return metadata
    if isinstance(metadata, dict):
        try:
            return SkillMetadata(**metadata)
        except TypeError as exc:
            raise SkillDefinitionError(
                f"metadata: could not construct SkillMetadata from {metadata!r}: {exc}."
            ) from exc
    raise SkillDefinitionError(
        f"metadata must be a SkillMetadata, dict, or None — got {type(metadata).__name__}."
    )


def _check_secrets_match_capabilities(secrets: list[Secret], capabilities: list[str]) -> None:
    declared_secret_caps = {
        cap.split(":", 1)[1] for cap in capabilities if cap.startswith("secrets:")
    }
    for secret in secrets:
        if secret.name not in declared_secret_caps:
            raise SkillDefinitionError(
                f"Secret {secret.name!r} is declared but not in capabilities. "
                f"Add 'secrets:{secret.name}' to capabilities so the platform "
                "knows to grant access."
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _humanize(slug: str) -> str:
    """Convert ``github-pr-summary`` → ``Github Pr Summary``.

    Used as the default display_name. Authors can override.
    """
    return " ".join(part.capitalize() for part in slug.split("-") if part)


def _slug_suggestion(name: str) -> str | None:
    """Best-effort lowercase + hyphenate for a name suggestion in error messages."""
    cleaned = re.sub(r"[^a-z0-9-]+", "-", name.lower()).strip("-")
    return cleaned or None
