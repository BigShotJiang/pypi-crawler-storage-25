"""The :data:`metrics` facade — counters, gauges, and histograms.

.. code-block:: python

    from synax_sdk import metrics

    metrics.counter("github_api_calls").inc()
    metrics.counter("github_api_calls", labels={"endpoint": "/pulls"}).inc(5)
    metrics.gauge("queue_depth").set(42)
    metrics.histogram("request_ms").observe(123.4)

Each ``metrics.<kind>(name, labels=...)`` call returns a small object
with a single mutator: ``.inc(by=1)`` for :class:`Counter`, ``.set(value)``
for :class:`Gauge`, ``.observe(value)`` for :class:`Histogram`. The
mutator records the event against the active backend; the backend
forwards to the platform's metrics pipeline (or, in tests, the
in-memory mock).
"""

from __future__ import annotations

from dataclasses import dataclass

from synax_sdk.runtime._backends.base import RuntimeBackend, resolve_backend

# Discriminators recorded on every MetricRecord. Match the build_plan exactly.
COUNTER_KIND = "counter_inc"
GAUGE_KIND = "gauge_set"
HISTOGRAM_KIND = "histogram_observe"


@dataclass(frozen=True)
class Counter:
    """Append-only counter. Call :meth:`inc` once per event."""

    _backend: RuntimeBackend
    name: str
    labels: dict[str, str]

    def inc(self, by: float = 1.0) -> None:
        """Increment the counter by ``by`` (defaults to 1)."""
        self._backend.record_metric(
            name=self.name, kind=COUNTER_KIND, value=float(by), labels=self.labels
        )


@dataclass(frozen=True)
class Gauge:
    """Settable scalar. Call :meth:`set` to update."""

    _backend: RuntimeBackend
    name: str
    labels: dict[str, str]

    def set(self, value: float) -> None:
        """Record ``value`` as the current gauge value."""
        self._backend.record_metric(
            name=self.name, kind=GAUGE_KIND, value=float(value), labels=self.labels
        )


@dataclass(frozen=True)
class Histogram:
    """Distribution. Call :meth:`observe` once per sample."""

    _backend: RuntimeBackend
    name: str
    labels: dict[str, str]

    def observe(self, value: float) -> None:
        """Record a single observation."""
        self._backend.record_metric(
            name=self.name, kind=HISTOGRAM_KIND, value=float(value), labels=self.labels
        )


class _Metrics:
    """Factory for per-call metric objects."""

    def counter(self, name: str, *, labels: dict[str, str] | None = None) -> Counter:
        return Counter(_backend=resolve_backend(), name=name, labels=dict(labels or {}))

    def gauge(self, name: str, *, labels: dict[str, str] | None = None) -> Gauge:
        return Gauge(_backend=resolve_backend(), name=name, labels=dict(labels or {}))

    def histogram(self, name: str, *, labels: dict[str, str] | None = None) -> Histogram:
        return Histogram(_backend=resolve_backend(), name=name, labels=dict(labels or {}))


metrics = _Metrics()
