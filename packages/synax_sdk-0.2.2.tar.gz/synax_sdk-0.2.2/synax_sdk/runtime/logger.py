"""The :data:`logger` facade — structured logging from inside a skill.

.. code-block:: python

    from synax_sdk import logger

    logger.info("Fetched PR", extra={"pr_number": 42, "files_changed": 7})
    logger.warning("Rate limit approaching")
    try:
        ...
    except Exception:
        logger.exception("Unexpected failure while parsing")

Five levels are supported (``debug``, ``info``, ``warning``, ``error``,
``exception``). ``exception`` captures the current traceback into the
``extra`` payload — call it from inside an ``except:`` block.

Logs flow into the platform's observability when running in production
and into the :class:`~synax_sdk.testing.MockPlatform`'s in-memory record
when running under tests.
"""

from __future__ import annotations

import traceback
from typing import Any

from synax_sdk.runtime._backends.base import resolve_backend


class _Logger:
    """Structured logger that delegates to the active backend."""

    def _emit(self, level: str, message: str, extra: dict[str, Any] | None) -> None:
        resolve_backend().log(level=level, message=message, extra=extra)

    def debug(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._emit("debug", message, extra)

    def info(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._emit("info", message, extra)

    def warning(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._emit("warning", message, extra)

    def error(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._emit("error", message, extra)

    def exception(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        """Emit an error-level log with the current traceback in ``extra['traceback']``.

        Intended to be called from inside an ``except:`` block. If no
        exception is currently being handled, ``extra['traceback']`` is
        the literal string ``"NoneType: None"`` (matches ``traceback.format_exc()``
        behaviour outside an except block).
        """
        merged: dict[str, Any] = dict(extra) if extra else {}
        merged["traceback"] = traceback.format_exc()
        self._emit("error", message, merged)


logger = _Logger()
