"""The :data:`ctx` proxy and the :class:`Context` / :class:`Invoker` dataclasses.

A skill reads invocation metadata via ``ctx``:

.. code-block:: python

    from synax_sdk import ctx

    async def my_tool() -> None:
        run = ctx.run_id           # uuid.UUID
        ws = ctx.workspace_id      # uuid.UUID
        who = ctx.invoker          # Invoker(type=..., id=..., name=...)

``ctx`` is a tiny proxy: each attribute access calls
:meth:`RuntimeBackend.get_context` on the active backend and returns the
named field. Tests set the context via ``MockPlatform.context.set(...)``.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Literal

from synax_sdk.runtime._backends.base import resolve_backend

InvokerType = Literal["user", "bot"]


@dataclass(frozen=True)
class Invoker:
    """Who triggered this skill invocation."""

    type: InvokerType
    id: uuid.UUID
    name: str


@dataclass(frozen=True)
class Context:
    """Per-invocation metadata. Read via :data:`ctx`, set via :class:`MockPlatform`."""

    run_id: uuid.UUID
    workspace_id: uuid.UUID
    invoker: Invoker
    channel_id: uuid.UUID
    bot_id: uuid.UUID | None = None
    user_id: uuid.UUID | None = None


class _CurrentContext:
    """Proxy that fetches each field from the active backend's :class:`Context`.

    Using explicit properties (rather than ``__getattr__``) preserves mypy
    type information at every access site.
    """

    @property
    def run_id(self) -> uuid.UUID:
        return resolve_backend().get_context().run_id

    @property
    def workspace_id(self) -> uuid.UUID:
        return resolve_backend().get_context().workspace_id

    @property
    def invoker(self) -> Invoker:
        return resolve_backend().get_context().invoker

    @property
    def channel_id(self) -> uuid.UUID:
        return resolve_backend().get_context().channel_id

    @property
    def bot_id(self) -> uuid.UUID | None:
        return resolve_backend().get_context().bot_id

    @property
    def user_id(self) -> uuid.UUID | None:
        return resolve_backend().get_context().user_id

    def __repr__(self) -> str:
        return "<synax_sdk runtime ctx proxy>"


ctx = _CurrentContext()
