"""The Synax runtime API — what skills call during execution.

When a skill runs inside the Synax platform, calls to ``secrets.get(...)``,
``logger.info(...)``, ``metrics.counter(...).inc()``, and ``ctx.run_id``
delegate to the platform's runtime. When a skill runs locally under a
:class:`~synax_sdk.testing.MockPlatform`, the same calls go through the
mock backend instead. The skill code is identical in both cases.

This module re-exports the facade singletons and submodules authors use:

* :data:`secrets` — ``await secrets.get(name)``
* :data:`logger`  — ``logger.info(message, extra=...)``
* :data:`metrics` — ``metrics.counter(name).inc()``
* :data:`ctx`     — ``ctx.run_id``, ``ctx.workspace_id``, ``ctx.invoker``
* :mod:`network`  — ``await network.http_get(url, ...)`` (capability-gated)
"""

from synax_sdk.runtime import network
from synax_sdk.runtime.context import Context, Invoker, ctx
from synax_sdk.runtime.logger import logger
from synax_sdk.runtime.metrics import metrics
from synax_sdk.runtime.secrets import secrets

__all__ = ["Context", "Invoker", "ctx", "logger", "metrics", "network", "secrets"]
