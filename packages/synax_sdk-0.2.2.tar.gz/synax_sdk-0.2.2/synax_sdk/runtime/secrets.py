"""The :data:`secrets` facade — ``await secrets.get(name)``.

Skills request secrets by name; the backend looks them up and (in
production) audits the access. The skill never sees raw platform credentials
— only secrets the workspace admin configured for that skill.
"""

from __future__ import annotations

from synax_sdk.runtime._backends.base import resolve_backend


class _Secrets:
    """Async accessor for skill secrets."""

    async def get(self, name: str) -> str:
        """Return the value of the named secret.

        Raises:
            SkillRuntimeError: if no backend is active or the secret is
                not configured (in the mock backend's case).
        """
        return await resolve_backend().get_secret(name)


secrets = _Secrets()
