"""The :class:`RuntimeBackend` ABC and the ContextVar that holds the active one.

A backend is the in-process implementation of the runtime API. When a skill
calls ``await secrets.get("X")``, the call resolves the *current* backend
from a ``ContextVar`` and delegates. There can be exactly one active
backend per :class:`contextvars.Context`; the SDK never holds more than
one. The platform's production runtime and the in-memory mock both
implement this ABC.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextvars import ContextVar
from typing import TYPE_CHECKING, Any

import httpx

from synax_sdk.errors import SkillRuntimeError

if TYPE_CHECKING:
    from synax_sdk.runtime.context import Context

# ContextVar default is None — explicitly "no backend bound to this async context".
_backend_var: ContextVar[RuntimeBackend | None] = ContextVar("_synax_runtime_backend", default=None)


class RuntimeBackend(ABC):
    """Abstract runtime backend.

    Subclasses implement how each call is fulfilled (lookup in a real
    secret store, write to a real log pipeline, etc.). The mock backend
    used in tests keeps everything in memory.
    """

    @abstractmethod
    async def get_secret(self, name: str) -> str:
        """Return the value of the named secret, or raise."""

    @abstractmethod
    def log(
        self,
        *,
        level: str,
        message: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Emit a structured log record."""

    @abstractmethod
    def record_metric(
        self,
        *,
        name: str,
        kind: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> None:
        """Record a metric observation.

        ``kind`` is one of ``"counter_inc"``, ``"gauge_set"``,
        ``"histogram_observe"`` — these are the only forms the SDK
        produces today.
        """

    @abstractmethod
    def get_context(self) -> Context:
        """Return the current invocation context (run_id, workspace_id, ...)."""

    @abstractmethod
    async def http_request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str] | None,
        json: Any | None,
        content: str | bytes | None,
        timeout: float,
    ) -> httpx.Response:
        """Perform an outgoing HTTP request.

        Called by :mod:`synax_sdk.runtime.network` after the capability
        check has succeeded. The backend is free to make the request
        directly (current mock impl + future direct-httpx production
        path) or to route it through an out-of-process channel (future
        IPC backend if the platform centralizes egress).

        Implementations must return an :class:`httpx.Response`. The
        public network module passes the response through to the caller
        unmodified, so skills get the standard httpx API surface for
        reading body, headers, and status.
        """

    def get_runtime_capabilities(self) -> frozenset[str] | None:
        """Return the runtime-effective capability set for this invocation.

        Default implementation returns ``None`` — i.e. the backend opts
        *out* of supplying capabilities, and the public
        :mod:`synax_sdk.runtime.network` module falls back to the
        :envvar:`SYNAX_RUNTIME_CAPABILITIES` env-var contract (see
        ``docs/runtime_contract.md``).

        Concrete backends override this when they have their own source of
        truth — even an explicitly empty :class:`frozenset` means "this
        invocation has no capabilities", which is distinct from ``None``
        ("I don't track capabilities; use the env var").
        """
        return None


def resolve_backend() -> RuntimeBackend:
    """Return the active backend or raise :class:`SkillRuntimeError`.

    Used by every facade (``secrets``, ``logger``, ``metrics``, ``ctx``).
    The error message includes both production and test hints so authors
    quickly understand what setup is missing.
    """
    backend = _backend_var.get()
    if backend is None:
        raise SkillRuntimeError(
            "No Synax runtime backend is active. "
            "If you're running tests, wrap the call in MockPlatform().activate(). "
            "If you're running in production, ensure the skill is invoked by the platform "
            "and not imported and called directly."
        )
    return backend


def set_backend(backend: RuntimeBackend | None) -> Any:
    """Set the active backend; returns a token usable with :func:`reset_backend`.

    Internal — :class:`~synax_sdk.testing.MockPlatform.activate` is the
    public entry point.
    """
    return _backend_var.set(backend)


def reset_backend(token: Any) -> None:
    """Reset the active backend to its previous value using a token from
    :func:`set_backend`."""
    _backend_var.reset(token)
