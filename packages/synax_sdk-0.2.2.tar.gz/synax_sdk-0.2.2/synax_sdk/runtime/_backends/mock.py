"""In-memory :class:`RuntimeBackend` implementation used by tests.

The mock is intentionally strict: requesting a secret or context that
wasn't pre-configured raises :class:`SkillRuntimeError`. The build_plan
guidance says "fail loudly" so test setup bugs surface immediately rather
than silently returning a default that masks the issue.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import httpx

from synax_sdk.errors import SkillRuntimeError
from synax_sdk.runtime._backends.base import RuntimeBackend
from synax_sdk.runtime.context import Context


@dataclass(frozen=True)
class LogCall:
    """One captured ``logger.<level>(...)`` invocation."""

    level: str
    message: str
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MetricRecord:
    """One captured metric event.

    ``kind`` is one of ``counter_inc``, ``gauge_set``, ``histogram_observe``.
    """

    name: str
    kind: str
    value: float
    labels: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class HttpRequestRecord:
    """One captured HTTP request made via the mock backend."""

    method: str
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    json: Any | None = None
    content: str | bytes | None = None
    timeout: float = 30.0


@dataclass(frozen=True)
class HttpResponseStub:
    """A registered response for one (method, url) pair on the mock backend.

    Exactly one of ``raises`` or the response fields (``status`` / ``json`` /
    ``text`` / ``headers``) controls the dispatch path. When ``raises`` is
    set, the mock raises that exception instead of returning a response.
    """

    status: int = 200
    json: Any | None = None
    text: str | None = None
    headers: dict[str, str] = field(default_factory=dict)
    raises: BaseException | None = None


class MockBackend(RuntimeBackend):
    """In-memory backend that records every call for later inspection."""

    def __init__(self) -> None:
        self._secrets: dict[str, str] = {}
        self._secret_accesses: list[str] = []
        self._log_calls: list[LogCall] = []
        self._metric_records: list[MetricRecord] = []
        self._context: Context | None = None
        # frozenset() — explicit "no capabilities" (fail-closed).
        # The MockBackend always overrides the env-var path, even when empty.
        self._capabilities: frozenset[str] = frozenset()
        # (method, url) → stub registered via MockPlatform.network.respond_to.
        self._http_responses: dict[tuple[str, str], HttpResponseStub] = {}
        self._http_requests: list[HttpRequestRecord] = []

    # ----- secrets ----------------------------------------------------------
    def set_secret(self, name: str, value: str) -> None:
        self._secrets[name] = value

    @property
    def secret_accesses(self) -> list[str]:
        return list(self._secret_accesses)

    async def get_secret(self, name: str) -> str:
        self._secret_accesses.append(name)
        if name not in self._secrets:
            raise SkillRuntimeError(
                f"Secret {name!r} was requested but not configured on the mock. "
                "Call MockPlatform().secrets.set(name, value) before activating."
            )
        return self._secrets[name]

    # ----- logging ----------------------------------------------------------
    def log(
        self,
        *,
        level: str,
        message: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        self._log_calls.append(
            LogCall(level=level, message=message, extra=dict(extra) if extra else {})
        )

    @property
    def log_calls(self) -> list[LogCall]:
        return list(self._log_calls)

    # ----- metrics ----------------------------------------------------------
    def record_metric(
        self,
        *,
        name: str,
        kind: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> None:
        self._metric_records.append(
            MetricRecord(
                name=name,
                kind=kind,
                value=float(value),
                labels=dict(labels) if labels else {},
            )
        )

    @property
    def metric_records(self) -> list[MetricRecord]:
        return list(self._metric_records)

    # ----- context ----------------------------------------------------------
    def set_context(self, context: Context) -> None:
        self._context = context

    def get_context(self) -> Context:
        if self._context is None:
            raise SkillRuntimeError(
                "No invocation context configured on the mock backend. "
                "Call MockPlatform().context.set(...) before accessing ctx in your skill."
            )
        return self._context

    # ----- capabilities -----------------------------------------------------
    def set_capabilities(self, capabilities: frozenset[str]) -> None:
        """Replace the in-memory capability set (used by MockPlatform)."""
        self._capabilities = frozenset(capabilities)

    def get_runtime_capabilities(self) -> frozenset[str] | None:
        # Always returns a concrete set (never None) so the env-var
        # fallback is bypassed whenever a MockBackend is active.
        return self._capabilities

    # ----- network ----------------------------------------------------------
    def register_http_response(self, *, method: str, url: str, stub: HttpResponseStub) -> None:
        """Register a response stub for one (method, url) pair.

        Internal hook called by the ``MockPlatform.network.respond_to``
        public surface. Re-registering the same (method, url) pair
        overwrites the previous stub.
        """
        self._http_responses[(method.upper(), url)] = stub

    @property
    def http_requests(self) -> list[HttpRequestRecord]:
        """All HTTP requests dispatched through this backend, in call order."""
        return list(self._http_requests)

    async def http_request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str] | None,
        json: Any | None,
        content: str | bytes | None,
        timeout: float,
    ) -> httpx.Response:
        record = HttpRequestRecord(
            method=method.upper(),
            url=url,
            headers=dict(headers) if headers else {},
            json=json,
            content=content,
            timeout=timeout,
        )
        self._http_requests.append(record)

        key = (method.upper(), url)
        stub = self._http_responses.get(key)
        if stub is None:
            raise AssertionError(
                f"Unexpected HTTP request: {method.upper()} {url}. "
                f"Register a response with "
                f"MockPlatform().network.respond_to(url, method=..., ...) "
                f"before invoking the skill."
            )

        if stub.raises is not None:
            raise stub.raises

        return _build_httpx_response(stub, method=method.upper(), url=url)


def _build_httpx_response(stub: HttpResponseStub, *, method: str, url: str) -> httpx.Response:
    """Construct an :class:`httpx.Response` from a registered stub."""
    if stub.json is not None and stub.text is not None:
        raise ValueError("HttpResponseStub cannot specify both json and text — pick one.")

    request = httpx.Request(method=method, url=url)
    headers = dict(stub.headers)

    if stub.json is not None:
        # httpx.Response(json=...) handles encoding + Content-Type when the
        # caller hasn't already set one.
        return httpx.Response(
            status_code=stub.status,
            headers=headers,
            json=stub.json,
            request=request,
        )

    if stub.text is not None:
        return httpx.Response(
            status_code=stub.status,
            headers=headers,
            text=stub.text,
            request=request,
        )

    return httpx.Response(
        status_code=stub.status,
        headers=headers,
        request=request,
    )
