"""Runtime backends. Implementation detail — public API lives in
:mod:`synax_sdk.runtime`."""
