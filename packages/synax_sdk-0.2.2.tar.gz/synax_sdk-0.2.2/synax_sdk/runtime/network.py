"""HTTP wrappers for skills, with capability enforcement and audit logging.

Skills import this module to make outgoing HTTP calls:

.. code-block:: python

    from synax_sdk.runtime import network

    response = await network.http_get(
        "https://api.github.com/repos/anthropics/claude",
        headers={"Accept": "application/vnd.github+json"},
        timeout=30.0,
    )
    response.raise_for_status()
    data = response.json()

The wrappers do four things on top of plain ``httpx``:

1. **Capability enforcement** — every call checks the URL's host (and
   port, if explicit) against the runtime-effective capability set. If
   the capability isn't declared, :class:`~synax_sdk.CapabilityError` is
   raised before any network traffic. The capability source is governed
   by ``docs/runtime_contract.md``.

2. **Audit logging** — every call emits a structured log record with
   ``method``, ``url``, ``status_code`` (when the call returned), and
   ``duration_ms``. In test mode (``MockPlatform`` active) the log goes
   through the bound backend so tests can inspect it via
   ``mock.logger.calls``. Otherwise it goes to the stdlib ``logging``
   module under the ``synax_sdk.runtime.network`` logger name.

3. **Defaults** — 30-second timeout, follow redirects, send a
   ``User-Agent: synax-sdk/<version>`` header (unless the caller
   overrides it).

4. **Dispatch** — when a backend is bound, the request is delegated to
   :meth:`RuntimeBackend.http_request` (so :class:`MockPlatform` returns
   pre-registered stubs and a future platform backend could route
   through IPC). Otherwise the request is made directly with
   :class:`httpx.AsyncClient`.

For v0.2.0 the wrappers cover GET, POST, PUT, DELETE, PATCH — the verbs
the first real consumer (the ``http-fetch`` skill in synax-skills)
needs. The returned object is the raw :class:`httpx.Response` so skills
get the full standard API for reading body, headers, and status.
"""

from __future__ import annotations

import logging
import time
from typing import Any
from urllib.parse import urlparse

import httpx

from synax_sdk.errors import CapabilityError
from synax_sdk.runtime._backends.base import _backend_var
from synax_sdk.runtime._capabilities import get_runtime_capabilities
from synax_sdk.version import __version__

_DEFAULT_TIMEOUT = 30.0
_USER_AGENT = f"synax-sdk/{__version__}"
_stdlib_logger = logging.getLogger("synax_sdk.runtime.network")


async def http_get(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> httpx.Response:
    """Perform an HTTP GET request after a capability check.

    Raises:
        CapabilityError: if the URL's host (and port, if specified) is
            not covered by the runtime-effective capability set.
    """
    return await _request("GET", url, headers=headers, timeout=timeout)


async def http_post(
    url: str,
    *,
    json: Any | None = None,
    content: str | bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> httpx.Response:
    """Perform an HTTP POST request after a capability check.

    Exactly one of ``json`` or ``content`` should be supplied for a request
    with a body — the SDK does not currently combine them.
    """
    return await _request("POST", url, json=json, content=content, headers=headers, timeout=timeout)


async def http_put(
    url: str,
    *,
    json: Any | None = None,
    content: str | bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> httpx.Response:
    """Perform an HTTP PUT request after a capability check."""
    return await _request("PUT", url, json=json, content=content, headers=headers, timeout=timeout)


async def http_delete(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> httpx.Response:
    """Perform an HTTP DELETE request after a capability check."""
    return await _request("DELETE", url, headers=headers, timeout=timeout)


async def http_patch(
    url: str,
    *,
    json: Any | None = None,
    content: str | bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> httpx.Response:
    """Perform an HTTP PATCH request after a capability check."""
    return await _request(
        "PATCH", url, json=json, content=content, headers=headers, timeout=timeout
    )


async def _request(
    method: str,
    url: str,
    *,
    headers: dict[str, str] | None = None,
    json: Any | None = None,
    content: str | bytes | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> httpx.Response:
    """Internal: dispatch the request through the bound backend or httpx."""
    caps = get_runtime_capabilities()
    _check_capability(url, caps)

    merged_headers = _merge_headers(headers)
    start = time.monotonic()
    status: int | None = None
    try:
        backend = _backend_var.get()
        if backend is not None:
            response = await backend.http_request(
                method=method,
                url=url,
                headers=merged_headers,
                json=json,
                content=content,
                timeout=timeout,
            )
        else:
            # TODO(v0.3.0+): consider a shared httpx.AsyncClient for
            # connection pooling once a real consumer demonstrates the
            # need; per-request is fine for http-fetch (one call per
            # invocation).
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=merged_headers,
                    json=json,
                    content=content,
                )
        status = response.status_code
        return response
    finally:
        duration_ms = (time.monotonic() - start) * 1000
        _audit_log(
            method=method,
            url=url,
            status_code=status,
            duration_ms=duration_ms,
        )


def _check_capability(url: str, caps: frozenset[str]) -> None:
    """Verify the URL's host (and port, if explicit) is covered by ``caps``.

    Matching rules:

    * ``network:*`` matches any host on any port.
    * ``network:<host>`` matches any port on that host — host-only
      capabilities are "any port for this host".
    * ``network:<host>:<port>`` matches only that exact port on that host.

    The error message reports the most specific form of the missing
    capability so the suggestion is precise.
    """
    parsed = urlparse(url)
    host = parsed.hostname
    if host is None:
        raise CapabilityError(requested=f"network:<unparseable: {url}>", available=caps)

    if "network:*" in caps:
        return
    if f"network:{host}" in caps:
        return

    port = parsed.port
    if port is not None and f"network:{host}:{port}" in caps:
        return

    requested = f"network:{host}:{port}" if port is not None else f"network:{host}"
    raise CapabilityError(requested=requested, available=caps)


def _merge_headers(user_headers: dict[str, str] | None) -> dict[str, str]:
    """Add a default ``User-Agent`` unless the caller already supplied one."""
    merged: dict[str, str] = {"User-Agent": _USER_AGENT}
    if user_headers:
        # Case-insensitive override: user's User-Agent (any case) wins.
        for k, v in user_headers.items():
            if k.lower() == "user-agent":
                merged.pop("User-Agent", None)
            merged[k] = v
    return merged


def _audit_log(
    *,
    method: str,
    url: str,
    status_code: int | None,
    duration_ms: float,
) -> None:
    """Emit one structured audit record per HTTP call.

    Routes through the bound backend's :meth:`log` when one is active so
    test code can inspect via ``mock.logger.calls``. Otherwise falls back
    to the stdlib ``logging`` module so production-without-a-backend
    invocations aren't silent.
    """
    extra: dict[str, Any] = {
        "method": method,
        "url": url,
        "duration_ms": duration_ms,
    }
    if status_code is not None:
        extra["status_code"] = status_code

    backend = _backend_var.get()
    if backend is not None:
        backend.log(level="info", message="HTTP request", extra=extra)
    else:
        _stdlib_logger.info("HTTP request", extra=extra)
