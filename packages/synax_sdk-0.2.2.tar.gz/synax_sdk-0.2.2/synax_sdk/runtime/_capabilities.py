"""Runtime-effective capability set, from backend or env-var contract.

The public network module calls :func:`get_runtime_capabilities` once per
gated operation. The result is:

* the active backend's :meth:`RuntimeBackend.get_runtime_capabilities`
  return value when the backend chooses to provide one (the in-memory
  mock always does; a future platform backend may), or
* a JSON array parsed from :envvar:`SYNAX_RUNTIME_CAPABILITIES` (cached
  process-wide), or
* the empty set (fail-closed) when the env var is absent, malformed, or
  not a list of strings — a :class:`RuntimeWarning` is emitted in the
  malformed cases so CI surfaces them.

The full contract is in ``docs/runtime_contract.md``.

This module is internal — skill code should never import from it
directly. The capability check is hidden behind the public API of
:mod:`synax_sdk.runtime.network` (and equivalent future modules).
"""

from __future__ import annotations

import json
import os
import warnings

from synax_sdk.runtime._backends.base import _backend_var

ENV_VAR = "SYNAX_RUNTIME_CAPABILITIES"

# Process-wide cache for the env-var path. None means "not yet read this
# process"; a frozenset means "already read, use this".
_cached_env_capabilities: frozenset[str] | None = None


def get_runtime_capabilities() -> frozenset[str]:
    """Return the runtime-effective capability set for the current invocation.

    See module docstring for precedence and fail-closed semantics.
    """
    backend = _backend_var.get()
    if backend is not None:
        backend_caps = backend.get_runtime_capabilities()
        if backend_caps is not None:
            return backend_caps
    return _read_env_capabilities()


def _read_env_capabilities() -> frozenset[str]:
    """Read and cache :envvar:`SYNAX_RUNTIME_CAPABILITIES`, fail-closed."""
    global _cached_env_capabilities
    if _cached_env_capabilities is not None:
        return _cached_env_capabilities

    raw = os.environ.get(ENV_VAR)
    if raw is None:
        _cached_env_capabilities = frozenset()
        return _cached_env_capabilities

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        warnings.warn(
            f"{ENV_VAR} is not valid JSON; treating capability set as empty. "
            f"Expected a JSON array of capability strings, e.g. "
            f'["network:api.example.com"].',
            RuntimeWarning,
            stacklevel=2,
        )
        _cached_env_capabilities = frozenset()
        return _cached_env_capabilities

    if not isinstance(parsed, list):
        warnings.warn(
            f"{ENV_VAR} must be a JSON array; got {type(parsed).__name__}. "
            f"Treating capability set as empty.",
            RuntimeWarning,
            stacklevel=2,
        )
        _cached_env_capabilities = frozenset()
        return _cached_env_capabilities

    if not all(isinstance(item, str) for item in parsed):
        warnings.warn(
            f"{ENV_VAR} array contains non-string elements; treating capability "
            f"set as empty. Every element must be a capability string.",
            RuntimeWarning,
            stacklevel=2,
        )
        _cached_env_capabilities = frozenset()
        return _cached_env_capabilities

    _cached_env_capabilities = frozenset(parsed)
    return _cached_env_capabilities


def _reset_cache_for_testing() -> None:
    """Drop the cached env-var read so the next call re-reads the environment.

    Test-only escape hatch — production code never calls this.
    """
    global _cached_env_capabilities
    _cached_env_capabilities = None
