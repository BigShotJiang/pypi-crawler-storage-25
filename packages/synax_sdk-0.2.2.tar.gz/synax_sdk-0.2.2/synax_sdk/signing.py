"""Ed25519 signing of skill manifests.

A skill author generates a keypair once (``synax keys generate``), keeps
the private key locally under ``~/.synax/keys/<fingerprint>.key`` with
mode ``0o600``, and uses it at build time to sign the canonical form of
each manifest they publish. The platform stores public keys for known
publishers and verifies signatures on every install.

This module wraps :mod:`nacl.signing` (PyNaCl, libsodium bindings) — we
never reach for raw bytes-and-hashes implementations of Ed25519.

Public surface:

* :class:`KeyPair` — an Ed25519 keypair (may be public-only)
* :class:`Signer` — wraps a private key, signs canonical manifest bytes
* :class:`Verifier` — wraps a public key, verifies a signature
* :func:`generate_keypair` — produce a fresh keypair
* :func:`save_keypair_to_file` / :func:`load_keypair_from_file`
* :func:`save_public_key_to_file` / :func:`load_public_key_from_file`
* :func:`fingerprint_for_public_key` — SHA-256 hex over public key bytes
"""

from __future__ import annotations

import base64
import datetime
import hashlib
import json
import os
import platform
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nacl.exceptions import BadSignatureError
from nacl.signing import SigningKey, VerifyKey

from synax_sdk.errors import SynaxSDKError

KEY_FILE_VERSION = 1
ALGORITHM = "Ed25519"


class SigningError(SynaxSDKError):
    """Signing-related failure: bad key file, bad signature, etc."""


# ---------------------------------------------------------------------------
# Fingerprint
# ---------------------------------------------------------------------------
def fingerprint_for_public_key(public_key_bytes: bytes) -> str:
    """Return ``sha256:<64-hex>`` for a public key.

    Used as the stable identifier for a key throughout the SDK and the
    platform. Two keys with the same public bytes have the same
    fingerprint; the private half doesn't influence the fingerprint.
    """
    return "sha256:" + hashlib.sha256(public_key_bytes).hexdigest()


# ---------------------------------------------------------------------------
# KeyPair / Signer / Verifier
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class KeyPair:
    """An Ed25519 keypair.

    Either side may be ``None`` (a public-only KeyPair, suitable for
    verification but not signing).
    """

    public_key: bytes
    private_key: bytes | None = None
    created_at: str | None = None  # ISO 8601 in UTC
    name: str | None = None  # optional human-readable label

    @property
    def fingerprint(self) -> str:
        return fingerprint_for_public_key(self.public_key)

    @property
    def has_private(self) -> bool:
        return self.private_key is not None

    def signer(self) -> Signer:
        """Return a :class:`Signer` bound to this keypair. Requires the private half."""
        if self.private_key is None:
            raise SigningError(
                f"Cannot sign with public-only KeyPair (fingerprint {self.fingerprint}). "
                "Load the private key file or generate a new keypair."
            )
        return Signer(self)

    def verifier(self) -> Verifier:
        """Return a :class:`Verifier` bound to this keypair's public half."""
        return Verifier(self)


@dataclass(frozen=True)
class Signer:
    """Signs canonical manifest bytes with an Ed25519 private key."""

    keypair: KeyPair

    def sign(self, canonical_bytes: bytes) -> str:
        """Return a base64-encoded signature over ``canonical_bytes``."""
        if self.keypair.private_key is None:
            raise SigningError("Signer is missing its private key — cannot produce a signature.")
        signing_key = SigningKey(self.keypair.private_key)
        signed = signing_key.sign(canonical_bytes)
        return base64.b64encode(signed.signature).decode("ascii")


@dataclass(frozen=True)
class Verifier:
    """Verifies a signature against a public key."""

    keypair: KeyPair

    def verify(self, canonical_bytes: bytes, signature_b64: str) -> None:
        """Raise :class:`SigningError` if the signature doesn't verify.

        Returns ``None`` on success — callers should let ``SigningError``
        propagate when verification fails rather than relying on a
        boolean.
        """
        try:
            signature_bytes = base64.b64decode(signature_b64, validate=True)
        except Exception as exc:
            raise SigningError(f"Signature is not valid base64: {exc}") from exc
        verify_key = VerifyKey(self.keypair.public_key)
        try:
            verify_key.verify(canonical_bytes, signature_bytes)
        except BadSignatureError as exc:
            raise SigningError(
                f"Signature does not verify against key {self.keypair.fingerprint}."
            ) from exc


# ---------------------------------------------------------------------------
# Key generation
# ---------------------------------------------------------------------------
def generate_keypair(*, name: str | None = None) -> KeyPair:
    """Generate a fresh Ed25519 keypair.

    ``name`` is an optional human-readable label stored alongside the key
    in the on-disk file. It is not used for fingerprinting and is purely
    informational.
    """
    signing_key = SigningKey.generate()
    return KeyPair(
        public_key=bytes(signing_key.verify_key),
        private_key=bytes(signing_key),
        created_at=datetime.datetime.now(datetime.UTC).isoformat(),
        name=name,
    )


# ---------------------------------------------------------------------------
# File I/O
# ---------------------------------------------------------------------------
def _restrict_permissions(path: Path) -> None:
    """Set the file to mode 0o600 on POSIX. No-op on Windows (different ACL model)."""
    if platform.system() == "Windows":  # pragma: no cover - platform branch
        return
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def _ensure_directory(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if platform.system() != "Windows":  # pragma: no cover - platform branch
        try:
            os.chmod(path.parent, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
        except OSError:
            pass


def save_keypair_to_file(keypair: KeyPair, path: Path) -> None:
    """Write a keypair (or public-only KeyPair) to a JSON file at ``path``.

    Always restricts permissions to ``0o600`` on POSIX. The file format
    is documented at :data:`KEY_FILE_VERSION` and is forward-compatible:
    unknown fields are ignored on load.
    """
    payload: dict[str, Any] = {
        "version": KEY_FILE_VERSION,
        "algorithm": ALGORITHM,
        "fingerprint": keypair.fingerprint,
        "public_key_b64": base64.b64encode(keypair.public_key).decode("ascii"),
    }
    if keypair.private_key is not None:
        payload["private_key_b64"] = base64.b64encode(keypair.private_key).decode("ascii")
    if keypair.created_at is not None:
        payload["created_at"] = keypair.created_at
    if keypair.name is not None:
        payload["name"] = keypair.name

    _ensure_directory(path)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    _restrict_permissions(path)


def save_public_key_to_file(keypair: KeyPair, path: Path) -> None:
    """Write only the public key to ``path``. Used for sharing with the platform."""
    public_only = KeyPair(
        public_key=keypair.public_key,
        created_at=keypair.created_at,
        name=keypair.name,
    )
    payload: dict[str, Any] = {
        "version": KEY_FILE_VERSION,
        "algorithm": ALGORITHM,
        "fingerprint": public_only.fingerprint,
        "public_key_b64": base64.b64encode(public_only.public_key).decode("ascii"),
    }
    if public_only.created_at is not None:
        payload["created_at"] = public_only.created_at
    if public_only.name is not None:
        payload["name"] = public_only.name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def load_keypair_from_file(path: Path) -> KeyPair:
    """Load a keypair from a JSON key file.

    Raises :class:`SigningError` if the file is missing, malformed, or
    contains a key of the wrong algorithm.
    """
    if not path.exists():
        raise SigningError(f"Key file not found: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SigningError(f"Key file {path} is not valid JSON: {exc}") from exc

    algorithm = payload.get("algorithm")
    if algorithm != ALGORITHM:
        raise SigningError(
            f"Key file {path} uses algorithm {algorithm!r}; this SDK only supports {ALGORITHM!r}."
        )

    public_b64 = payload.get("public_key_b64")
    if not isinstance(public_b64, str):
        raise SigningError(f"Key file {path} is missing required field 'public_key_b64'.")
    try:
        public_key = base64.b64decode(public_b64, validate=True)
    except Exception as exc:
        raise SigningError(f"Key file {path}: public_key_b64 is not valid base64: {exc}") from exc

    private_key: bytes | None = None
    private_b64 = payload.get("private_key_b64")
    if private_b64 is not None:
        if not isinstance(private_b64, str):
            raise SigningError(f"Key file {path}: private_key_b64 must be a string.")
        try:
            private_key = base64.b64decode(private_b64, validate=True)
        except Exception as exc:
            raise SigningError(
                f"Key file {path}: private_key_b64 is not valid base64: {exc}"
            ) from exc

    name = payload.get("name")
    if name is not None and not isinstance(name, str):
        raise SigningError(f"Key file {path}: 'name' must be a string when present.")

    return KeyPair(
        public_key=public_key,
        private_key=private_key,
        created_at=payload.get("created_at"),
        name=name,
    )


def load_public_key_from_file(path: Path) -> KeyPair:
    """Convenience wrapper — loads a key file and discards any private half."""
    kp = load_keypair_from_file(path)
    return KeyPair(public_key=kp.public_key, created_at=kp.created_at, name=kp.name)


# ---------------------------------------------------------------------------
# Default-key index
# ---------------------------------------------------------------------------
DEFAULT_KEY_INDEX_FILENAME = "default"


@dataclass
class KeyStore:
    """Filesystem-backed store of keys under a directory (default ``~/.synax/keys/``).

    The store is just a directory; keys are individual JSON files named
    ``<fingerprint>.key`` (with ``sha256:`` prefix on the filename
    URL-encoded as ``sha256_<hex>.key`` to avoid filename headaches), plus
    a small ``default`` file pointing at the active fingerprint.
    """

    root: Path
    _DEFAULT_ROOT: Path | None = field(default=None, init=False, repr=False)

    @classmethod
    def default(cls) -> KeyStore:
        """Return the user-level store at ``~/.synax/keys/``."""
        return cls(root=Path.home() / ".synax" / "keys")

    def _file_for(self, fingerprint: str) -> Path:
        sanitised = fingerprint.replace(":", "_")
        return self.root / f"{sanitised}.key"

    def resolve(self, prefix_or_full: str) -> str:
        """Resolve a fingerprint prefix (or full fingerprint) to the unique full match.

        Accepts either a full ``sha256:<64-hex>`` fingerprint or any
        unambiguous hex prefix (with or without the ``sha256:`` scheme).
        The match is case-insensitive on the hex portion.

        Raises :class:`SigningError` when the prefix matches zero or more
        than one stored key. The single-match case returns the full
        fingerprint in canonical ``sha256:<64-hex>`` form.
        """
        raw = prefix_or_full.strip()
        if not raw:
            raise SigningError("Empty fingerprint or prefix.")
        # Strip optional ``sha256:`` scheme. We only support sha256 today;
        # if/when more algorithms ship, this is where to add a check.
        hex_prefix = raw.removeprefix("sha256:").lower()
        if not hex_prefix:
            raise SigningError(f"Empty fingerprint or prefix in {prefix_or_full!r}.")
        if any(c not in "0123456789abcdef" for c in hex_prefix):
            raise SigningError(f"Fingerprint {prefix_or_full!r} contains non-hex characters.")
        # Fast-path: full-length input that already exists as a file.
        if len(hex_prefix) == 64:
            candidate = f"sha256:{hex_prefix}"
            if self._file_for(candidate).exists():
                return candidate
            raise SigningError(f"No key matching {prefix_or_full!r} in {self.root}.")
        # Prefix-match against the list of known keys.
        matches = [
            fp
            for fp in self.list_fingerprints()
            if fp.removeprefix("sha256:").startswith(hex_prefix)
        ]
        if len(matches) == 1:
            return matches[0]
        if not matches:
            raise SigningError(f"No key matching prefix {prefix_or_full!r} in {self.root}.")
        listed = ", ".join(matches)
        raise SigningError(
            f"Ambiguous prefix {prefix_or_full!r} matches {len(matches)} keys: {listed}. "
            "Use a longer prefix."
        )

    def save(self, keypair: KeyPair, *, set_default_if_none: bool = True) -> Path:
        """Save ``keypair`` to the store and return the path it was written to.

        If no default is currently set and ``set_default_if_none`` is
        ``True``, the newly-saved keypair becomes the default.
        """
        target = self._file_for(keypair.fingerprint)
        save_keypair_to_file(keypair, target)
        if set_default_if_none and self.default_fingerprint is None:
            self.set_default(keypair.fingerprint)
        return target

    def load(self, fingerprint: str) -> KeyPair:
        full = self.resolve(fingerprint)
        return load_keypair_from_file(self._file_for(full))

    def list_fingerprints(self) -> list[str]:
        if not self.root.exists():
            return []
        prints: list[str] = []
        for child in sorted(self.root.iterdir()):
            if child.suffix != ".key":
                continue
            try:
                kp = load_keypair_from_file(child)
            except SigningError:
                continue
            prints.append(kp.fingerprint)
        return prints

    @property
    def _default_pointer(self) -> Path:
        return self.root / DEFAULT_KEY_INDEX_FILENAME

    @property
    def default_fingerprint(self) -> str | None:
        if not self._default_pointer.exists():
            return None
        try:
            payload = json.loads(self._default_pointer.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return None
        fp = payload.get("fingerprint")
        return fp if isinstance(fp, str) else None

    def set_default(self, fingerprint: str) -> None:
        full = self.resolve(fingerprint)
        _ensure_directory(self._default_pointer)
        self._default_pointer.write_text(
            json.dumps({"fingerprint": full}, indent=2),
            encoding="utf-8",
        )

    def delete(self, fingerprint: str, *, force: bool = False) -> str:
        """Delete a key from the store.

        Returns the resolved full fingerprint that was deleted. Refuses
        to delete the active default unless ``force=True``; when the
        default is force-deleted the pointer file is cleared so callers
        observe ``default_fingerprint is None`` afterwards.
        """
        full = self.resolve(fingerprint)
        is_default = self.default_fingerprint == full
        if is_default and not force:
            raise SigningError(
                f"Refusing to delete the default signing key {full}. "
                "Set a new default first, or pass force=True."
            )
        target = self._file_for(full)
        try:
            target.unlink()
        except FileNotFoundError as exc:  # pragma: no cover - race condition
            raise SigningError(f"Key file {target} disappeared during delete.") from exc
        if is_default and self._default_pointer.exists():
            self._default_pointer.unlink()
        return full
