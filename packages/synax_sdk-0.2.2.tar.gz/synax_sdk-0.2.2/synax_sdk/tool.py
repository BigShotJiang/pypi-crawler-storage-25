"""The :class:`Tool` dataclass and the inspection logic that builds tools from functions.

A *tool* is the unit a Synax bot calls. Skill authors decorate a function with
``@skill.tool(description=...)`` and the SDK turns that function into a
:class:`Tool`: the function's parameter signature becomes a JSON Schema, its
docstring contributes per-parameter descriptions, and its return annotation
(if any) becomes the return schema.

This module is intentionally self-contained: it knows nothing about
:class:`~synax_sdk.skill.Skill`. The Skill class composes Tool by calling
:meth:`Tool.from_function`.
"""

from __future__ import annotations

import dataclasses
import inspect
import re
import textwrap
import types as builtin_types
import typing
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

from synax_sdk.errors import SkillDefinitionError

# Tool names mirror Python function names: snake_case, max 64 chars per manifest spec.
TOOL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

_SECTION_HEADERS = {
    "args:",
    "arguments:",
    "parameters:",
    "returns:",
    "return:",
    "yields:",
    "yield:",
    "raises:",
    "raise:",
    "exceptions:",
    "note:",
    "notes:",
    "example:",
    "examples:",
    "attributes:",
    "see also:",
}
_ARGS_HEADERS = {"args:", "arguments:", "parameters:"}


# ---------------------------------------------------------------------------
# Public Tool dataclass
# ---------------------------------------------------------------------------
@dataclass(eq=False)
class Tool:
    """A tool: a callable + the metadata needed for the manifest.

    Attributes:
        name: snake_case identifier, defaults to the function's ``__name__``.
        description: one-or-three-sentence description from the decorator.
        parameters_schema: JSON Schema (``type: object``) for invocation args.
        returns_schema: JSON Schema for the return value, or ``None`` if the
            function lacks a return annotation.
        func: the original callable, returned unchanged from the decorator
            so authors can still invoke it directly during local testing.
    """

    name: str
    description: str
    parameters_schema: dict[str, Any]
    returns_schema: dict[str, Any] | None
    func: Callable[..., Any]
    is_async: bool = field(default=False)

    @classmethod
    def from_function(
        cls,
        func: Callable[..., Any],
        *,
        description: str,
        name: str | None = None,
    ) -> Tool:
        """Build a :class:`Tool` from a decorated function.

        Raises:
            SkillDefinitionError: if the function uses ``*args`` / ``**kwargs``,
                if any parameter lacks a type annotation, if a type isn't
                supported, or if the tool name isn't snake_case.
        """
        tool_name = name or func.__name__
        if not TOOL_NAME_RE.match(tool_name):
            raise SkillDefinitionError(
                f"Invalid tool name {tool_name!r}. "
                "Tool names must be snake_case: start with a lowercase letter, "
                "use only [a-z0-9_], and be 1-64 characters long."
            )

        if not description or not description.strip():
            raise SkillDefinitionError(
                f"Tool {tool_name!r} requires a non-empty description. "
                "Pass description=... to @skill.tool()."
            )

        signature = inspect.signature(func)
        try:
            hints = typing.get_type_hints(func, include_extras=False)
        except Exception as exc:  # forward refs that can't resolve
            raise SkillDefinitionError(
                f"Tool {tool_name!r}: could not resolve type hints on "
                f"{func.__qualname__}: {exc}"
            ) from exc

        docstring_params = _parse_google_docstring(func.__doc__)

        properties: dict[str, dict[str, Any]] = {}
        required: list[str] = []

        for param_name, param in signature.parameters.items():
            if param_name in ("self", "cls"):
                continue
            if param.kind is inspect.Parameter.VAR_POSITIONAL:
                raise SkillDefinitionError(
                    f"Tool {tool_name!r} uses *{param_name}, which is not supported. "
                    "Tools must have explicit named parameters with type annotations."
                )
            if param.kind is inspect.Parameter.VAR_KEYWORD:
                raise SkillDefinitionError(
                    f"Tool {tool_name!r} uses **{param_name}, which is not supported. "
                    "Tools must have explicit named parameters with type annotations."
                )

            if param_name not in hints:
                raise SkillDefinitionError(
                    f"Tool {tool_name!r} parameter {param_name!r} has no type annotation. "
                    "Tool parameters must be annotated so the SDK can derive the JSON Schema."
                )

            param_schema = python_type_to_json_schema(
                hints[param_name],
                where=f"tool {tool_name!r} parameter {param_name!r}",
            )

            if param_name in docstring_params:
                param_schema = {**param_schema, "description": docstring_params[param_name]}

            if param.default is not inspect.Parameter.empty:
                param_schema = {**param_schema, "default": param.default}
            else:
                required.append(param_name)

            properties[param_name] = param_schema

        parameters_schema: dict[str, Any] = {"type": "object", "properties": properties}
        if required:
            parameters_schema["required"] = required

        returns_schema: dict[str, Any] | None = None
        if "return" in hints and hints["return"] is not type(None):
            returns_schema = python_type_to_json_schema(
                hints["return"], where=f"tool {tool_name!r} return type"
            )

        return cls(
            name=tool_name,
            description=description.strip(),
            parameters_schema=parameters_schema,
            returns_schema=returns_schema,
            func=func,
            is_async=inspect.iscoroutinefunction(func),
        )


# ---------------------------------------------------------------------------
# Type → JSON Schema
# ---------------------------------------------------------------------------
def python_type_to_json_schema(annotation: Any, *, where: str = "<unknown>") -> dict[str, Any]:
    """Translate a Python type annotation into a JSON Schema fragment.

    Supported:
        ``str``, ``int``, ``float``, ``bool``, ``None`` / ``type(None)``,
        ``bytes``, ``Any``, ``list[X]``, ``dict[str, X]``, ``tuple[X, ...]``,
        ``set[X]``, ``frozenset[X]``, ``Optional[X]``, ``X | None``,
        ``Union[A, B]`` / ``A | B``, ``Literal[...]``, ``TypedDict``,
        and ``@dataclass`` types. ``Any`` produces an empty schema (``{}``).

    Args:
        annotation: a resolved type annotation (call ``typing.get_type_hints``
            first if the caller used ``from __future__ import annotations``).
        where: human-readable location string used in error messages, e.g.
            ``"tool 'summarize_pr' parameter 'repo'"``.

    Raises:
        SkillDefinitionError: if the annotation is not in the supported set.
    """
    if annotation is None or annotation is type(None):
        return {"type": "null"}
    if annotation is Any:
        return {}
    if annotation is str:
        return {"type": "string"}
    if annotation is int:
        return {"type": "integer"}
    if annotation is float:
        return {"type": "number"}
    if annotation is bool:
        return {"type": "boolean"}
    if annotation is bytes:
        return {"type": "string", "contentEncoding": "base64"}

    # Bare container classes (used without type parameters): list, dict, set, frozenset, tuple.
    # typing.get_origin returns None for these, so they need their own branch.
    if annotation is list or annotation is set or annotation is frozenset or annotation is tuple:
        return {"type": "array"}
    if annotation is dict:
        return {"type": "object"}

    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)

    if origin is Literal:
        return _literal_to_schema(args, where=where)

    if _is_union(origin, annotation):
        return _union_to_schema(args, where=where)

    if origin in (list, set, frozenset):
        if not args:
            return {"type": "array"}
        return {"type": "array", "items": python_type_to_json_schema(args[0], where=where)}

    if origin is tuple:
        if len(args) == 2 and args[1] is Ellipsis:
            return {
                "type": "array",
                "items": python_type_to_json_schema(args[0], where=where),
            }
        raise SkillDefinitionError(
            f"At {where}: fixed-length tuple types (e.g. tuple[int, str]) are not supported. "
            "Use tuple[X, ...] for variable-length, or define a dataclass / TypedDict."
        )

    if origin is dict:
        if not args:
            return {"type": "object"}
        if args[0] is not str:
            raise SkillDefinitionError(
                f"At {where}: dict keys must be str (got {args[0]!r}). "
                "JSON object keys are always strings."
            )
        return {
            "type": "object",
            "additionalProperties": python_type_to_json_schema(args[1], where=where),
        }

    if _is_typed_dict(annotation):
        return _typed_dict_to_schema(annotation, where=where)

    if dataclasses.is_dataclass(annotation) and isinstance(annotation, type):
        return _dataclass_to_schema(annotation, where=where)

    raise SkillDefinitionError(
        f"At {where}: unsupported type annotation {annotation!r}. "
        "Supported: str, int, float, bool, bytes, None, Any, list[X], dict[str, X], "
        "tuple[X, ...], set[X], Optional[X], Union[...], Literal[...], TypedDict, dataclass."
    )


def _is_union(origin: Any, annotation: Any) -> bool:
    """Detect both ``Union[...]`` (origin=typing.Union) and ``X | Y`` (UnionType)."""
    if origin is typing.Union:
        return True
    union_type = getattr(builtin_types, "UnionType", None)
    return union_type is not None and isinstance(annotation, union_type)


def _union_to_schema(args: tuple[Any, ...], *, where: str) -> dict[str, Any]:
    schemas = [python_type_to_json_schema(a, where=where) for a in args]
    # Optional[X] is the common case; collapse to anyOf.
    return {"anyOf": schemas}


def _literal_to_schema(args: tuple[Any, ...], *, where: str) -> dict[str, Any]:
    if not args:
        raise SkillDefinitionError(f"At {where}: Literal[] requires at least one argument.")
    types_seen = {type(v) for v in args}
    schema: dict[str, Any] = {"enum": list(args)}
    if len(types_seen) == 1:
        only = next(iter(types_seen))
        if only is str:
            schema["type"] = "string"
        elif only is bool:
            schema["type"] = "boolean"
        elif only is int:
            schema["type"] = "integer"
        elif only is float:
            schema["type"] = "number"
    return schema


def _is_typed_dict(annotation: Any) -> bool:
    is_td = getattr(typing, "is_typeddict", None)
    if callable(is_td):
        return bool(is_td(annotation))
    return (
        isinstance(annotation, type)
        and issubclass(annotation, dict)
        and hasattr(annotation, "__total__")
        and hasattr(annotation, "__annotations__")
    )


def _typed_dict_to_schema(td: Any, *, where: str) -> dict[str, Any]:
    annotations = typing.get_type_hints(td)
    required_keys = getattr(td, "__required_keys__", None)
    if required_keys is None:
        # Python pre-3.9 fallback: total= determines requiredness
        required_keys = set(annotations.keys()) if getattr(td, "__total__", True) else set()

    properties = {
        name: python_type_to_json_schema(tp, where=f"{where} field {name!r}")
        for name, tp in annotations.items()
    }
    schema: dict[str, Any] = {"type": "object", "properties": properties}
    required = sorted(set(required_keys) & set(annotations.keys()))
    if required:
        schema["required"] = required
    return schema


def _dataclass_to_schema(dc: type, *, where: str) -> dict[str, Any]:
    annotations = typing.get_type_hints(dc)
    properties: dict[str, Any] = {}
    required: list[str] = []
    for f in dataclasses.fields(dc):
        properties[f.name] = python_type_to_json_schema(
            annotations.get(f.name, f.type), where=f"{where} field {f.name!r}"
        )
        if f.default is dataclasses.MISSING and f.default_factory is dataclasses.MISSING:
            required.append(f.name)
    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required
    return schema


# ---------------------------------------------------------------------------
# Google-style docstring parser
# ---------------------------------------------------------------------------
def _parse_google_docstring(doc: str | None) -> dict[str, str]:
    """Return ``{param_name: description}`` from a Google-style docstring.

    Recognises the ``Args:`` / ``Arguments:`` / ``Parameters:`` section
    headings and extracts ``name: description`` entries, joining continuation
    lines into a single space-separated description.

    Anything outside that section is ignored. If the docstring is empty,
    missing, or has no recognised parameter section, returns ``{}``.
    """
    if not doc:
        return {}

    lines = textwrap.dedent(doc).splitlines()
    params: dict[str, str] = {}
    in_args = False
    current_name: str | None = None
    current_body: list[str] = []
    entry_indent: int | None = None

    def flush() -> None:
        nonlocal current_name, current_body
        if current_name is not None:
            params[current_name] = " ".join(s.strip() for s in current_body).strip()
        current_name = None
        current_body = []

    for raw in lines:
        stripped = raw.strip()
        lower = stripped.lower()
        indent = len(raw) - len(raw.lstrip())

        if lower in _SECTION_HEADERS:
            flush()
            entry_indent = None
            in_args = lower in _ARGS_HEADERS
            continue

        if not in_args or not stripped:
            continue

        if ":" in stripped and (entry_indent is None or indent == entry_indent):
            flush()
            entry_indent = indent
            name, _, desc = stripped.partition(":")
            current_name = name.strip()
            current_body = [desc]
        elif current_name is not None:
            current_body.append(stripped)

    flush()
    return params
