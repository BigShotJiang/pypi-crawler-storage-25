"""Deterministic packaging of skill implementation artifacts.

A skill's implementation artifact is a ``.tar.gz`` archive of the project
directory, minus anything matched by ``.synax-skillignore``. The archive
is *deterministic* — same content in, same bytes out, every time — so
that ``sha256(artifact)`` is a stable identifier that gets pinned into
the manifest's ``implementation.hash``.

Determinism is achieved by:

* sorting archive entries lexicographically by archive path,
* zeroing ``mtime`` / ``uid`` / ``gid`` / ``uname`` / ``gname``,
* normalising file modes to ``0o644`` and directory modes to ``0o755``,
* invoking ``gzip.GzipFile`` with ``mtime=0`` (otherwise gzip writes the
  current time into its 10-byte header and the resulting bytes differ
  per call).
"""

from __future__ import annotations

import fnmatch
import gzip
import hashlib
import io
import tarfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

# Defaults match docs/build_plan.md §Milestone 4 Implementation Notes.
DEFAULT_IGNORE_PATTERNS: tuple[str, ...] = (
    "__pycache__/",
    "*.pyc",
    "*.pyo",
    ".pytest_cache/",
    ".mypy_cache/",
    ".ruff_cache/",
    ".git/",
    "build/",
    "dist/",
    "*.egg-info/",
    ".venv/",
    "venv/",
    ".env",
    ".env.*",
    ".synax/",
    ".vscode/",
    ".idea/",
)


@dataclass(frozen=True)
class ArtifactResult:
    """Outcome of :func:`build_implementation_artifact`."""

    tar_gz_bytes: bytes
    sha256: str  # ``"sha256:<64-hex>"`` — already prefixed for manifest use
    included_files: list[str]  # archive paths (POSIX style), in archive order


# ---------------------------------------------------------------------------
# Ignore pattern handling
# ---------------------------------------------------------------------------
def _parse_skillignore(text: str) -> list[str]:
    """Parse ``.synax-skillignore`` text into a list of patterns.

    Blank lines and ``#``-prefixed comments are skipped. Other lines are
    stripped of leading/trailing whitespace and kept verbatim.
    """
    patterns: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        patterns.append(line)
    return patterns


def _matches_any(rel: PurePosixPath, patterns: list[str]) -> bool:
    """Return ``True`` if ``rel`` matches any of ``patterns``.

    Simple fnmatch-style semantics:

    * A pattern ending in ``/`` matches when one of the path's parts
      equals the directory name (so ``__pycache__/`` excludes anything
      inside any ``__pycache__`` directory).
    * Otherwise the pattern is tried against both the file basename
      AND the full relative path (so ``*.pyc`` matches ``a/b.pyc`` and
      ``foo/*.py`` matches ``foo/bar.py``).
    """
    parts = rel.parts
    name = rel.name
    full = str(rel)
    for pat in patterns:
        if pat.endswith("/"):
            dirname = pat.rstrip("/")
            if dirname in parts:
                return True
        else:
            if fnmatch.fnmatch(name, pat):
                return True
            if fnmatch.fnmatch(full, pat):
                return True
    return False


def load_skillignore(project_dir: Path) -> list[str]:
    """Return the active ignore-pattern list for ``project_dir``.

    If ``.synax-skillignore`` exists at the project root, *its* patterns
    replace the defaults (matching gitignore semantics — the file is the
    source of truth, defaults aren't appended). If the file is absent,
    the SDK's :data:`DEFAULT_IGNORE_PATTERNS` are used.
    """
    skillignore = project_dir / ".synax-skillignore"
    if skillignore.exists():
        return _parse_skillignore(skillignore.read_text(encoding="utf-8"))
    return list(DEFAULT_IGNORE_PATTERNS)


# ---------------------------------------------------------------------------
# Deterministic file collection
# ---------------------------------------------------------------------------
def _normalise_tarinfo(info: tarfile.TarInfo) -> tarfile.TarInfo:
    """Strip all variable metadata from a tar entry."""
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    if info.isdir():
        info.mode = 0o755
    elif info.isfile():
        info.mode = 0o644
    return info


def _collect_files(project_dir: Path, patterns: list[str]) -> list[tuple[Path, str]]:
    """Walk ``project_dir`` and return ``[(absolute_path, archive_path)]``.

    Sorted lexicographically by archive path. Files matching ``patterns``
    are excluded. Symlinks are skipped — they aren't portable across
    platforms and the build artifact is supposed to be self-contained.
    """
    collected: list[tuple[Path, str]] = []
    for child in project_dir.rglob("*"):
        if child.is_symlink() or not child.is_file():
            continue
        rel = PurePosixPath(*child.relative_to(project_dir).parts)
        if _matches_any(rel, patterns):
            continue
        collected.append((child, str(rel)))
    collected.sort(key=lambda pair: pair[1])
    return collected


# ---------------------------------------------------------------------------
# Top-level build
# ---------------------------------------------------------------------------
def build_implementation_artifact(
    project_dir: Path,
    *,
    extra_ignore: list[str] | None = None,
) -> ArtifactResult:
    """Produce a deterministic tar.gz of ``project_dir``.

    Args:
        project_dir: directory to package. Must exist and be a directory.
        extra_ignore: additional patterns to merge into the active
            ignore list (useful for build-time exclusions like the
            ``build/`` output directory).

    Returns:
        :class:`ArtifactResult` carrying the bytes, the SHA-256 hash
        (already prefixed with ``"sha256:"``), and the list of archive
        paths for diagnostics.
    """
    if not project_dir.exists() or not project_dir.is_dir():
        raise FileNotFoundError(f"Project directory not found or not a directory: {project_dir}")

    patterns = load_skillignore(project_dir)
    if extra_ignore:
        patterns.extend(extra_ignore)

    files = _collect_files(project_dir, patterns)

    buf = io.BytesIO()
    # mtime=0 in the gzip header is what makes the gzip layer deterministic.
    with gzip.GzipFile(fileobj=buf, mode="wb", mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w") as tar:
            for absolute, archive_name in files:
                info = tar.gettarinfo(name=str(absolute), arcname=archive_name)
                info = _normalise_tarinfo(info)
                with absolute.open("rb") as fh:
                    tar.addfile(info, fileobj=fh)

    tar_gz_bytes = buf.getvalue()
    digest = hashlib.sha256(tar_gz_bytes).hexdigest()
    return ArtifactResult(
        tar_gz_bytes=tar_gz_bytes,
        sha256=f"sha256:{digest}",
        included_files=[name for _, name in files],
    )
