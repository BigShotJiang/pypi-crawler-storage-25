"""Vendored JSON Schema documents for skill manifests.

The schema text matches ``docs/manifest_spec.md`` and is shipped in the wheel
so the platform's published schema isn't a runtime dependency. When the
platform's schema evolves, update the JSON file here and bump
:data:`CURRENT_SCHEMA_VERSION`.
"""

from __future__ import annotations

import json
from functools import cache
from importlib import resources
from typing import Any

CURRENT_SCHEMA_VERSION = "1.0"


@cache
def load_manifest_schema(version: str = CURRENT_SCHEMA_VERSION) -> dict[str, Any]:
    """Return the parsed JSON Schema dict for the given manifest version.

    Raises :class:`FileNotFoundError` if ``version`` isn't bundled with the SDK.
    """
    filename = f"manifest_v{version.replace('.', '_')}.json"
    try:
        text = resources.files(__package__).joinpath(filename).read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise FileNotFoundError(
            f"Schema version {version!r} is not bundled with this SDK. "
            f"Expected file: synax_sdk/schema/{filename}"
        ) from exc
    parsed: dict[str, Any] = json.loads(text)
    return parsed
