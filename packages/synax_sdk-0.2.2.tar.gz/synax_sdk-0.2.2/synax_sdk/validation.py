"""Manifest validation — JSON Schema + logical consistency checks.

Two layers run in sequence:

1. **JSON Schema** validation against the vendored
   ``synax_sdk/schema/manifest_v1_0.json``. Catches structural issues:
   missing required fields, wrong types, names that don't match the
   slug pattern, versions that don't parse as semver, capabilities
   without the ``<type>:<specifier>`` shape, etc.

2. **Logical consistency** checks that JSON Schema can't express:

   * Every declared secret must have a matching ``secrets:<name>``
     capability — the platform enforces secret access via capabilities,
     so a secret without one would never be accessible.
   * The implementation's ``hash`` field, if present, must be in
     canonical ``sha256:<64-hex>`` form (the schema already enforces
     this, but we surface it as a distinct error class).
   * Daemon-only execution_location should usually need filesystem or
     local-network capabilities — emitted as a warning rather than an
     error (the platform might accept it).

Returns a flat ``list[ValidationError]`` so the CLI can format all
issues at once rather than failing on the first one.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

import jsonschema
from jsonschema.exceptions import ValidationError as JsonSchemaError

from synax_sdk.manifest import Manifest
from synax_sdk.schema import CURRENT_SCHEMA_VERSION, load_manifest_schema


@dataclass(frozen=True)
class ValidationError:
    """One validation issue.

    Attributes:
        field: dotted-path location, e.g. ``"tools[0].name"`` or
            ``"implementation.hash"``. ``""`` for whole-document errors.
        message: human-readable explanation.
        kind: short category code. ``"schema"`` for JSON Schema failures,
            ``"consistency"`` for cross-field checks, ``"warning"`` for
            non-blocking advisories.
        suggestion: optional hint for fixing the issue.
    """

    field: str
    message: str
    kind: str = "schema"
    suggestion: str | None = None


# ---------------------------------------------------------------------------
# Top-level entry
# ---------------------------------------------------------------------------
def validate_manifest(
    manifest: Manifest,
    *,
    schema_version: str | None = None,
) -> list[ValidationError]:
    """Validate ``manifest``; return every issue found.

    Args:
        manifest: the manifest to validate.
        schema_version: which schema to validate against. Defaults to
            the SDK's current version.
    """
    errors: list[ValidationError] = []
    errors.extend(_schema_errors(manifest, schema_version or CURRENT_SCHEMA_VERSION))
    errors.extend(_consistency_errors(manifest))
    return errors


# ---------------------------------------------------------------------------
# Layer 1 — JSON Schema
# ---------------------------------------------------------------------------
def _schema_errors(manifest: Manifest, version: str) -> list[ValidationError]:
    schema = load_manifest_schema(version)
    validator = jsonschema.Draft202012Validator(schema)
    payload = manifest.to_dict()
    errors: list[ValidationError] = []
    for err in validator.iter_errors(payload):
        errors.append(_to_validation_error(err))
    return errors


def _to_validation_error(err: JsonSchemaError) -> ValidationError:
    field = _format_path(err.absolute_path)
    return ValidationError(field=field, message=err.message, kind="schema")


def _format_path(path: Iterable[str | int]) -> str:
    """Convert a jsonschema absolute_path (deque of segments) to a dotted-string."""
    pieces: list[str] = []
    for segment in path:
        if isinstance(segment, int):
            if pieces:
                pieces[-1] = f"{pieces[-1]}[{segment}]"
            else:
                pieces.append(f"[{segment}]")
        else:
            pieces.append(str(segment))
    return ".".join(pieces)


# ---------------------------------------------------------------------------
# Layer 2 — logical consistency
# ---------------------------------------------------------------------------
def _consistency_errors(manifest: Manifest) -> list[ValidationError]:
    errors: list[ValidationError] = []
    errors.extend(_secrets_match_capabilities(manifest))
    errors.extend(_daemon_only_uses_local_capability(manifest))
    return errors


def _secrets_match_capabilities(manifest: Manifest) -> list[ValidationError]:
    """Every declared secret must have a matching ``secrets:<name>`` capability."""
    secret_caps = {
        cap.split(":", 1)[1]
        for cap in manifest.capabilities
        if cap.startswith("secrets:") and ":" in cap
    }
    errors: list[ValidationError] = []
    for idx, secret in enumerate(manifest.secrets):
        if secret.name not in secret_caps:
            errors.append(
                ValidationError(
                    field=f"secrets[{idx}].name",
                    message=(
                        f"Secret {secret.name!r} is declared but no matching "
                        f"'secrets:{secret.name}' capability is present."
                    ),
                    kind="consistency",
                    suggestion=f"Add 'secrets:{secret.name}' to capabilities.",
                )
            )
    return errors


def _daemon_only_uses_local_capability(manifest: Manifest) -> list[ValidationError]:
    """``execution_location='daemon_only'`` usually implies local capabilities.

    Emitted as a warning — the platform may accept skills without them.
    """
    if manifest.execution_location != "daemon_only":
        return []
    local_capability_prefixes = ("filesystem:", "subprocess:")
    # Tokens are loopback/wildcard markers we treat as "local"; not a bind address.
    local_tokens = ("localhost", "127.0.0.1", "0.0.0.0")  # noqa: S104 — string match, not a bind
    network_local = any(
        cap.startswith("network:") and any(token in cap for token in local_tokens)
        for cap in manifest.capabilities
    )
    has_local = (
        any(cap.startswith(local_capability_prefixes) for cap in manifest.capabilities)
        or network_local
    )
    if has_local:
        return []
    return [
        ValidationError(
            field="execution_location",
            message=(
                "execution_location='daemon_only' but no filesystem, subprocess, "
                "or local-network capability is declared."
            ),
            kind="warning",
            suggestion=(
                "Either add a local capability (e.g. 'filesystem:read:/data') or "
                "change execution_location to 'either' / 'prefer_daemon'."
            ),
        )
    ]
