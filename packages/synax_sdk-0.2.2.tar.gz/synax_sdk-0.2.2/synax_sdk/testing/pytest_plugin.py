"""Pytest fixtures for skill authors.

This module is registered as a pytest plugin via the
``[project.entry-points.pytest11]`` table in ``pyproject.toml`` — installing
``synax-sdk`` is enough to make these fixtures available; no extra
``conftest.py`` wiring is required.

Available fixtures:

* :func:`synax_mock_platform` — a fresh :class:`MockPlatform` per test.
* :func:`synax_skill_under_test` — loads the :class:`Skill` from the
  current project's ``pyproject.toml [tool.synax]``. Walks up from the
  test file looking for a project root.

Implementation note: every ``synax_sdk`` / ``synax_skill_cli`` import is
intentionally deferred to inside each fixture body. Pytest resolves
``pytest11`` entry-point modules during its plugin-loading phase, which
runs *before* ``pytest-cov`` starts measuring. Importing the rest of the
SDK at module top here would mean those statements get executed outside
coverage's instrumentation and show up as "uncovered" for the rest of
the test run.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from synax_sdk.skill import Skill
    from synax_sdk.testing import MockPlatform


@pytest.fixture
def synax_mock_platform() -> Iterator[MockPlatform]:
    """A fresh :class:`MockPlatform` per test, with ``.activate()`` already entered.

    Yielding the platform inside the activate() block means runtime API
    calls within the test see the mock without any extra ``with`` setup.
    """
    from synax_sdk.testing import MockPlatform

    mock = MockPlatform()
    with mock.activate():
        yield mock


@pytest.fixture
def synax_skill_under_test(pytestconfig: pytest.Config) -> Skill:
    """Locate and import the skill module under test.

    Looks for ``pyproject.toml`` with ``[tool.synax]`` starting from the
    pytest rootdir and walking up. Raises if no project is found — write
    your own fixture if the test layout doesn't match.
    """
    from pathlib import Path

    from synax_skill_cli.utils.project import find_project_root, load_skill_from_project

    start = Path(str(pytestconfig.rootpath))
    return load_skill_from_project(find_project_root(start))
