"""The :class:`MockPlatform` — the in-memory stand-in for the Synax platform.

Used by skill authors and SDK tests alike. Drives the same
:class:`~synax_sdk.runtime._backends.mock.MockBackend` that the runtime
facades resolve to when ``MockPlatform.activate()`` is in scope.
"""

from __future__ import annotations

import uuid
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from synax_sdk.runtime._backends.base import reset_backend, set_backend
from synax_sdk.runtime._backends.mock import (
    HttpRequestRecord,
    HttpResponseStub,
    LogCall,
    MetricRecord,
    MockBackend,
)
from synax_sdk.runtime.context import Context, Invoker, InvokerType
from synax_sdk.runtime.metrics import COUNTER_KIND, GAUGE_KIND, HISTOGRAM_KIND


def _coerce_uuid(value: str | uuid.UUID | None) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    return uuid.UUID(value)


# ---------------------------------------------------------------------------
# Sub-objects exposed on MockPlatform
# ---------------------------------------------------------------------------
class _MockSecrets:
    """The ``mock.secrets`` interface — configure values, inspect accesses."""

    def __init__(self, backend: MockBackend) -> None:
        self._backend = backend

    def set(self, name: str, value: str) -> None:
        """Configure the value the skill will receive from ``secrets.get(name)``."""
        self._backend.set_secret(name, value)

    @property
    def accesses(self) -> list[str]:
        """Names the skill has requested so far, in call order."""
        return self._backend.secret_accesses


class _MockLogger:
    """The ``mock.logger`` interface — inspect captured log calls."""

    def __init__(self, backend: MockBackend) -> None:
        self._backend = backend

    @property
    def calls(self) -> list[LogCall]:
        """All ``logger.<level>(...)`` invocations, in call order."""
        return self._backend.log_calls

    def at_level(self, level: str) -> list[LogCall]:
        """Convenience filter — only calls whose level matches ``level``."""
        return [c for c in self._backend.log_calls if c.level == level]


# ---------------------------------------------------------------------------
# Metric aggregation state types
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CounterState:
    """Aggregated counter for one metric name. Sum of all inc()'s across labels."""

    name: str
    value: float


@dataclass(frozen=True)
class GaugeState:
    """Latest gauge value for one metric name (most recent ``set()``)."""

    name: str
    value: float


@dataclass(frozen=True)
class HistogramState:
    """All observations recorded against a histogram name."""

    name: str
    values: list[float] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.values)

    @property
    def sum(self) -> float:
        return sum(self.values)


class _MockMetrics:
    """The ``mock.metrics`` interface — aggregated views + raw records."""

    def __init__(self, backend: MockBackend) -> None:
        self._backend = backend

    @property
    def records(self) -> list[MetricRecord]:
        """All metric events recorded, in call order. Defensive copy."""
        return self._backend.metric_records

    @property
    def counters(self) -> dict[str, CounterState]:
        """Counters aggregated by name (summed across all labels)."""
        sums: dict[str, float] = {}
        for r in self._backend.metric_records:
            if r.kind == COUNTER_KIND:
                sums[r.name] = sums.get(r.name, 0.0) + r.value
        return {name: CounterState(name=name, value=value) for name, value in sums.items()}

    @property
    def gauges(self) -> dict[str, GaugeState]:
        """Gauges as the last value set per name (across all labels)."""
        latest: dict[str, float] = {}
        for r in self._backend.metric_records:
            if r.kind == GAUGE_KIND:
                latest[r.name] = r.value
        return {name: GaugeState(name=name, value=value) for name, value in latest.items()}

    @property
    def histograms(self) -> dict[str, HistogramState]:
        """Histograms as the list of observations per name."""
        buckets: dict[str, list[float]] = {}
        for r in self._backend.metric_records:
            if r.kind == HISTOGRAM_KIND:
                buckets.setdefault(r.name, []).append(r.value)
        return {name: HistogramState(name=name, values=values) for name, values in buckets.items()}


class _MockNetwork:
    """The ``mock.network`` interface — register responses, inspect requests.

    Test code calls :meth:`respond_to` to pre-program responses for the
    URLs the skill will hit, then reads :attr:`requests` after running the
    skill to verify what actually went out.
    """

    def __init__(self, backend: MockBackend) -> None:
        self._backend = backend

    def respond_to(
        self,
        url: str,
        *,
        method: str = "GET",
        status: int = 200,
        json: Any | None = None,
        text: str | None = None,
        headers: dict[str, str] | None = None,
        raises: BaseException | None = None,
    ) -> None:
        """Register a stub response for one (method, url) pair.

        Args:
            url: The exact URL the skill is expected to request.
            method: The HTTP method (default ``"GET"``).
            status: The HTTP status code to return (ignored if ``raises``).
            json: A JSON-serializable body. Mutually exclusive with ``text``.
            text: A text body. Mutually exclusive with ``json``.
            headers: Response headers. Defaults to ``{}``.
            raises: If set, the mock raises this exception instead of
                returning a response — useful for simulating timeouts and
                network failures.

        Re-registering the same (method, url) pair overwrites the previous
        stub. URL matching is exact (including query string).
        """
        if json is not None and text is not None:
            raise ValueError(
                "respond_to accepts json or text, not both. "
                "Pass exactly one body form, or omit both for an empty body."
            )
        stub = HttpResponseStub(
            status=status,
            json=json,
            text=text,
            headers=dict(headers) if headers else {},
            raises=raises,
        )
        self._backend.register_http_response(method=method, url=url, stub=stub)

    @property
    def requests(self) -> list[HttpRequestRecord]:
        """All HTTP requests the skill made, in call order."""
        return self._backend.http_requests


class _MockCapabilities:
    """The ``mock.capabilities`` interface — configure runtime-effective caps.

    Mirrors the env-var contract documented in ``docs/runtime_contract.md``
    but lets tests set the capability set programmatically. When the
    :class:`MockBackend` is active, this set wins over the env var —
    including when empty (an explicit "this invocation has no
    capabilities" assertion).
    """

    def __init__(self, backend: MockBackend) -> None:
        self._backend = backend

    def set(self, capabilities: Iterable[str]) -> None:
        """Replace the capability set with the given iterable of strings."""
        self._backend.set_capabilities(frozenset(capabilities))

    def add(self, capability: str) -> None:
        """Add a single capability to the existing set."""
        current = self._backend.get_runtime_capabilities() or frozenset()
        self._backend.set_capabilities(current | {capability})

    @property
    def current(self) -> frozenset[str]:
        """The capability set the active invocation will see."""
        return self._backend.get_runtime_capabilities() or frozenset()


class _MockContext:
    """The ``mock.context`` interface — configure the invocation context."""

    def __init__(self, backend: MockBackend) -> None:
        self._backend = backend

    def set(
        self,
        *,
        run_id: str | uuid.UUID | None = None,
        workspace_id: str | uuid.UUID | None = None,
        channel_id: str | uuid.UUID | None = None,
        invoker: Invoker | None = None,
        invoker_type: InvokerType = "user",
        invoker_id: str | uuid.UUID | None = None,
        invoker_name: str = "test-invoker",
        bot_id: str | uuid.UUID | None = None,
        user_id: str | uuid.UUID | None = None,
    ) -> Context:
        """Configure the invocation context.

        Any UUID-typed field omitted defaults to ``uuid.uuid4()``. ``invoker``
        can be supplied directly as an :class:`~synax_sdk.runtime.context.Invoker`
        instance, or built from the ``invoker_type``/``invoker_id``/``invoker_name``
        kwargs (useful when you only care about one or two fields).
        """
        if invoker is None:
            invoker = Invoker(
                type=invoker_type,
                id=_coerce_uuid(invoker_id) or uuid.uuid4(),
                name=invoker_name,
            )
        context = Context(
            run_id=_coerce_uuid(run_id) or uuid.uuid4(),
            workspace_id=_coerce_uuid(workspace_id) or uuid.uuid4(),
            invoker=invoker,
            channel_id=_coerce_uuid(channel_id) or uuid.uuid4(),
            bot_id=_coerce_uuid(bot_id),
            user_id=_coerce_uuid(user_id),
        )
        self._backend.set_context(context)
        return context


# ---------------------------------------------------------------------------
# MockPlatform
# ---------------------------------------------------------------------------
class MockPlatform:
    """In-memory stand-in for the Synax platform.

    Usage:

    .. code-block:: python

        from synax_sdk.testing import MockPlatform

        mock = MockPlatform()
        mock.secrets.set("API_KEY", "test-value")
        mock.context.set(workspace_id="00000000-0000-0000-0000-000000000001")

        with mock.activate():
            result = await my_skill_tool(arg="x")

        assert mock.secrets.accesses == ["API_KEY"]
    """

    def __init__(self) -> None:
        self._backend = MockBackend()
        self.secrets = _MockSecrets(self._backend)
        self.logger = _MockLogger(self._backend)
        self.metrics = _MockMetrics(self._backend)
        self.context = _MockContext(self._backend)
        self.network = _MockNetwork(self._backend)
        self.capabilities = _MockCapabilities(self._backend)

    @contextmanager
    def activate(self) -> Iterator[MockPlatform]:
        """Bind this mock as the active runtime backend for the duration of the block.

        Implemented with :class:`contextvars.ContextVar`, so nested
        ``activate()`` blocks restore the previous backend cleanly and
        async tasks running inside the block see the right backend.
        """
        token: Any = set_backend(self._backend)
        try:
            yield self
        finally:
            reset_backend(token)

    @property
    def backend(self) -> MockBackend:
        """The underlying backend (escape hatch for advanced inspection)."""
        return self._backend
