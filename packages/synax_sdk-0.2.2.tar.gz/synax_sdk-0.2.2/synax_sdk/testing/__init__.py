"""Test utilities for skill authors.

The main export is :class:`MockPlatform`, which substitutes for the real
Synax platform when authors run their skills under pytest. It provides
methods for setting up runtime state (secrets, context) and for inspecting
what the skill did (logs emitted, metrics recorded, secrets accessed).
"""

from synax_sdk.runtime._backends.mock import HttpRequestRecord, HttpResponseStub
from synax_sdk.testing._mock_platform import (
    CounterState,
    GaugeState,
    HistogramState,
    MockPlatform,
)
from synax_sdk.testing.declarative import (
    CaseResult,
    TestCase,
    TestCaseError,
    discover_cases,
    run_all,
    run_case,
)
from synax_sdk.testing.runners import run_tool, run_tool_async

__all__ = [
    "CaseResult",
    "CounterState",
    "GaugeState",
    "HistogramState",
    "HttpRequestRecord",
    "HttpResponseStub",
    "MockPlatform",
    "TestCase",
    "TestCaseError",
    "discover_cases",
    "run_all",
    "run_case",
    "run_tool",
    "run_tool_async",
]
