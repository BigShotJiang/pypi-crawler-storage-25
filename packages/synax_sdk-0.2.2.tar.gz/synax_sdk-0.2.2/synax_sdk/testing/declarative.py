"""Declarative test cases for skills — YAML in, pass/fail out.

A skill project's ``test_inputs/`` directory holds test cases:

.. code-block:: text

    test_inputs/
    ├── secrets.yaml               # shared across all tools (optional)
    ├── summarize_pr/
    │   ├── secrets.yaml           # shared across this tool's cases (optional)
    │   ├── case_basic.yaml
    │   └── case_with_labels.yaml
    └── list_recent_prs/
        └── case_default_limit.yaml

Each case file is a YAML document like:

.. code-block:: yaml

    input:
      repo: "owner/name"
      pr_number: 42
    secrets:
      GITHUB_TOKEN: "test-token"
    context:
      workspace_id: "00000000-0000-0000-0000-000000000001"
    expected_output: {title: "...", summary: "..."}
    # OR
    expected_output_schema:
      type: object
      properties:
        title: {type: string}
    expected_logs:
      - level: info
        message_contains: "Summarized"
    expected_secret_accesses: ["GITHUB_TOKEN"]
    should_raise: "ValueError"

Every ``expected_*`` field is optional; the runner only checks the ones
that are present.
"""

from __future__ import annotations

import asyncio
import time
import traceback
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from synax_sdk.errors import SynaxSDKError
from synax_sdk.skill import Skill
from synax_sdk.testing._mock_platform import MockPlatform
from synax_sdk.tool import Tool

# Sentinel for "field not specified" (so None can be a legitimate expected_output value).
_MISSING = object()


class TestCaseError(SynaxSDKError):
    """Malformed test-case YAML — schema violation, unknown tool, etc."""


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class TestCase:
    """One declarative case ready to run."""

    tool: str
    name: str
    path: Path
    input: dict[str, Any]
    secrets: dict[str, str]
    context_overrides: dict[str, Any]
    expected_output: Any
    expected_output_schema: dict[str, Any] | None
    expected_logs: list[dict[str, Any]]
    expected_secret_accesses: list[str]
    expected_capability_uses: list[str]
    should_raise: str | None
    _has_expected_output: bool = field(default=False)


@dataclass(frozen=True)
class CaseResult:
    """Outcome of running a single test case."""

    tool: str
    case: str
    passed: bool
    duration_seconds: float
    failures: list[str] = field(default_factory=list)
    error: str | None = None  # set only when the run itself blew up unexpectedly

    @property
    def label(self) -> str:
        return f"{self.tool}/{self.case}"


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------
def discover_cases(test_inputs_dir: Path, skill: Skill) -> list[TestCase]:
    """Walk ``test_inputs_dir`` and return every test case found.

    Subdirectories are tool names; ``*.yaml`` files within are cases
    (excluding ``secrets.yaml``, which holds shared secret values for
    the directory it lives in). Files whose names start with ``_`` are
    treated as helpers and skipped.
    """
    if not test_inputs_dir.exists():
        return []
    if not test_inputs_dir.is_dir():
        raise TestCaseError(f"test_inputs path is not a directory: {test_inputs_dir}")

    tool_names = {t.name for t in skill.tools}
    root_secrets = _load_secrets(test_inputs_dir / "secrets.yaml")
    cases: list[TestCase] = []

    for tool_dir in sorted(p for p in test_inputs_dir.iterdir() if p.is_dir()):
        tool_name = tool_dir.name
        if tool_name not in tool_names:
            raise TestCaseError(
                f"test_inputs/{tool_name}/ doesn't match any tool on skill {skill.name!r}. "
                f"Available tools: {sorted(tool_names)}."
            )
        tool_secrets = {**root_secrets, **_load_secrets(tool_dir / "secrets.yaml")}
        for path in sorted(tool_dir.iterdir()):
            if path.suffix != ".yaml" or path.name.startswith("_"):
                continue
            if path.name == "secrets.yaml":
                continue
            cases.append(_load_case(path, tool_name=tool_name, default_secrets=tool_secrets))
    return cases


def _load_secrets(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    data = _yaml_load(path)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise TestCaseError(f"{path}: secrets.yaml must be a mapping of name → value.")
    out: dict[str, str] = {}
    for name, value in data.items():
        if not isinstance(name, str) or not isinstance(value, str):
            raise TestCaseError(
                f"{path}: secret name and value must both be strings (got {name!r}: {value!r})."
            )
        out[name] = value
    return out


def _load_case(path: Path, *, tool_name: str, default_secrets: dict[str, str]) -> TestCase:
    raw = _yaml_load(path)
    if not isinstance(raw, dict):
        raise TestCaseError(f"{path}: top-level YAML must be a mapping, got {type(raw).__name__}.")

    case_name = path.stem
    input_data = raw.get("input", {})
    if not isinstance(input_data, dict):
        raise TestCaseError(f"{path}: 'input' must be a mapping.")
    secrets = dict(default_secrets)
    case_secrets = raw.get("secrets", {})
    if not isinstance(case_secrets, dict):
        raise TestCaseError(f"{path}: 'secrets' must be a mapping.")
    for k, v in case_secrets.items():
        secrets[str(k)] = str(v)
    context_overrides = raw.get("context", {})
    if not isinstance(context_overrides, dict):
        raise TestCaseError(f"{path}: 'context' must be a mapping.")

    has_expected = "expected_output" in raw
    expected_output = raw.get("expected_output", _MISSING)

    expected_schema = raw.get("expected_output_schema")
    if expected_schema is not None and not isinstance(expected_schema, dict):
        raise TestCaseError(f"{path}: 'expected_output_schema' must be a JSON-Schema mapping.")

    expected_logs = raw.get("expected_logs", [])
    if not isinstance(expected_logs, list):
        raise TestCaseError(f"{path}: 'expected_logs' must be a list.")
    for item in expected_logs:
        if not isinstance(item, dict):
            raise TestCaseError(f"{path}: each expected_logs entry must be a mapping.")

    expected_secret_accesses = raw.get("expected_secret_accesses", [])
    if not isinstance(expected_secret_accesses, list) or not all(
        isinstance(x, str) for x in expected_secret_accesses
    ):
        raise TestCaseError(f"{path}: 'expected_secret_accesses' must be a list of strings.")

    expected_capability_uses = raw.get("expected_capability_uses", [])
    if not isinstance(expected_capability_uses, list) or not all(
        isinstance(x, str) for x in expected_capability_uses
    ):
        raise TestCaseError(f"{path}: 'expected_capability_uses' must be a list of strings.")

    should_raise = raw.get("should_raise")
    if should_raise is not None and not isinstance(should_raise, str):
        raise TestCaseError(f"{path}: 'should_raise' must be a string (exception class name).")

    return TestCase(
        tool=tool_name,
        name=case_name,
        path=path,
        input=input_data,
        secrets=secrets,
        context_overrides=context_overrides,
        expected_output=expected_output,
        expected_output_schema=expected_schema,
        expected_logs=expected_logs,
        expected_secret_accesses=list(expected_secret_accesses),
        expected_capability_uses=list(expected_capability_uses),
        should_raise=should_raise,
        _has_expected_output=has_expected,
    )


def _yaml_load(path: Path) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise TestCaseError(f"{path}: invalid YAML: {exc}") from exc


# ---------------------------------------------------------------------------
# Running
# ---------------------------------------------------------------------------
def run_case(case: TestCase, skill: Skill) -> CaseResult:
    """Run one case against ``skill`` and return the structured result."""
    tool = _find_tool(skill, case.tool)
    if tool is None:
        return CaseResult(
            tool=case.tool,
            case=case.name,
            passed=False,
            duration_seconds=0.0,
            error=f"Skill {skill.name!r} has no tool named {case.tool!r}.",
        )

    mock = MockPlatform()
    for name, value in case.secrets.items():
        mock.secrets.set(name, value)
    if case.context_overrides:
        mock.context.set(**case.context_overrides)

    failures: list[str] = []
    raised: BaseException | None = None
    output: Any = None
    started = time.perf_counter()
    try:
        with mock.activate():
            output = _invoke(tool, case.input)
    except BaseException as exc:
        raised = exc
    elapsed = time.perf_counter() - started

    # --- should_raise check
    if case.should_raise:
        if raised is None:
            failures.append(f"expected exception {case.should_raise} but call returned {output!r}")
        elif type(raised).__name__ != case.should_raise:
            failures.append(
                f"expected exception {case.should_raise} but got "
                f"{type(raised).__name__}: {raised}"
            )
    elif raised is not None:
        return CaseResult(
            tool=case.tool,
            case=case.name,
            passed=False,
            duration_seconds=elapsed,
            error=f"{type(raised).__name__}: {raised}\n{traceback.format_exc()}",
        )

    # --- expected_output (exact equality)
    if case._has_expected_output and not failures:
        if output != case.expected_output:
            failures.append(f"expected_output {case.expected_output!r} but got {output!r}")

    # --- expected_output_schema (JSON Schema)
    if case.expected_output_schema and not failures:
        try:
            jsonschema.Draft202012Validator(case.expected_output_schema).validate(output)
        except jsonschema.ValidationError as exc:
            failures.append(f"output failed expected_output_schema: {exc.message}")

    # --- expected_secret_accesses
    if case.expected_secret_accesses:
        actual = list(mock.secrets.accesses)
        for name in case.expected_secret_accesses:
            if name not in actual:
                failures.append(f"expected secret access for {name!r} but skill never requested it")

    # --- expected_logs
    if case.expected_logs:
        actual_logs = list(mock.logger.calls)
        for expected in case.expected_logs:
            mismatch = _find_log_mismatch(expected, actual_logs)
            if mismatch is not None:
                failures.append(mismatch)

    return CaseResult(
        tool=case.tool,
        case=case.name,
        passed=not failures,
        duration_seconds=elapsed,
        failures=failures,
    )


def run_all(
    skill: Skill,
    test_inputs_dir: Path,
    *,
    filter_tool: str | None = None,
    filter_case: str | None = None,
) -> list[CaseResult]:
    """Discover and run every case (optionally filtered) for ``skill``."""
    cases = discover_cases(test_inputs_dir, skill)
    if filter_tool:
        cases = [c for c in cases if c.tool == filter_tool]
    if filter_case:
        cases = [c for c in cases if filter_case in c.name]
    return [run_case(c, skill) for c in cases]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _find_tool(skill: Skill, name: str) -> Tool | None:
    for t in skill.tools:
        if t.name == name:
            return t
    return None


def _invoke(tool: Tool, inputs: dict[str, Any]) -> Any:
    if tool.is_async:
        return asyncio.run(tool.func(**inputs))
    return tool.func(**inputs)


def _find_log_mismatch(expected: dict[str, Any], actual_logs: Iterable[Any]) -> str | None:
    """Return ``None`` if at least one actual log matches ``expected``, else a message."""
    level = expected.get("level")
    contains = expected.get("message_contains")
    equals = expected.get("message_equals")
    extra_contains = expected.get("extra_contains")
    for log in actual_logs:
        if level is not None and log.level != level:
            continue
        if equals is not None and log.message != equals:
            continue
        if contains is not None and contains not in log.message:
            continue
        if extra_contains is not None:
            if not isinstance(extra_contains, dict):
                return f"expected_logs.extra_contains must be a mapping, got {type(extra_contains).__name__}"
            if not all(log.extra.get(k) == v for k, v in extra_contains.items()):
                continue
        return None
    return f"no log matched {expected!r}"
