"""Helpers for invoking tools and asserting their behavior.

These run *outside* the platform but inside an active
:class:`~synax_sdk.testing.MockPlatform`. Use them when you want to test
a tool directly, without going through the declarative test-case YAML.

.. code-block:: python

    from synax_sdk.testing import MockPlatform, run_tool

    mock = MockPlatform()
    mock.secrets.set("GREETING", "Hi")
    with mock.activate():
        result = run_tool(skill.tools[0], name="World")
    assert result == "Hi, World"
"""

from __future__ import annotations

import asyncio
from typing import Any

from synax_sdk.tool import Tool


def run_tool(tool: Tool, /, **inputs: Any) -> Any:
    """Invoke ``tool`` with keyword arguments and return its result.

    Handles both sync and async tools. For async tools, ``asyncio.run`` is
    used to drive the coroutine to completion — call this from synchronous
    code; if you're already inside an async test, await the tool directly.
    """
    if tool.is_async:
        return asyncio.run(tool.func(**inputs))
    return tool.func(**inputs)


async def run_tool_async(tool: Tool, /, **inputs: Any) -> Any:
    """Async variant of :func:`run_tool` — use inside ``async def`` tests."""
    if tool.is_async:
        return await tool.func(**inputs)
    return tool.func(**inputs)
