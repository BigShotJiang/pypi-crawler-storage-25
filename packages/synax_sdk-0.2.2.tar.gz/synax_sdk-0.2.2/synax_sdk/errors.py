"""Exception hierarchy for the Synax SDK.

All SDK-raised exceptions inherit from :class:`SynaxSDKError`, so users can
catch every SDK error with one ``except`` clause if desired. More specific
subclasses are preferred when the error category is known.
"""

from __future__ import annotations


class SynaxSDKError(Exception):
    """Base class for every exception raised by the Synax SDK."""


class SkillDefinitionError(SynaxSDKError):
    """A :class:`~synax_sdk.skill.Skill` or tool is defined improperly.

    Raised at construction time (in ``Skill.__init__`` or in the
    ``@skill.tool`` decorator) when the author's code violates the SDK's
    structural rules — for example an invalid skill name, a tool with an
    untyped parameter, or a secret that lacks a matching capability.

    These errors are fatal at *build* time. They never propagate to a
    running skill, because a skill that fails to define cannot be invoked.
    """


class SkillValidationError(SynaxSDKError):
    """A skill or manifest failed semantic validation.

    Distinct from :class:`SkillDefinitionError`: definition errors are about
    *shape* (caught while the Python is being loaded), validation errors
    are about *consistency* across the whole skill — e.g. a manifest whose
    JSON Schema doesn't match the schema spec.
    """


class ManifestError(SynaxSDKError):
    """A manifest could not be constructed, serialized, or parsed."""


class SkillRuntimeError(SynaxSDKError):
    """A skill attempted to use the runtime API in a way that failed.

    Common cases:

    * No runtime backend is active (skill imported but not running inside
      the platform or a :class:`~synax_sdk.testing.MockPlatform`).
    * The mock backend was active but the requested secret / context
      wasn't configured before the skill was invoked.

    The message names what was attempted and what to do about it.
    """


class CapabilityError(SynaxSDKError):
    """A skill attempted a gated operation without the required capability.

    Raised by the runtime API (e.g. :mod:`synax_sdk.runtime.network`) when
    the skill's runtime-effective capability set — supplied by the platform
    via the runtime contract, or programmatically via
    :class:`~synax_sdk.testing.MockPlatform` in tests — does not include
    the capability needed for the call.

    Attributes:
        requested: The capability string the call required, in its most
            specific form (e.g. ``"network:api.github.com:443"`` for a URL
            with an explicit port).
        available: The capabilities currently allowed for the invocation.
            Capability names are not sensitive and are safe to log.

    The error message names the missing capability and lists what *is*
    allowed, so the skill author can see at a glance what to add.
    """

    def __init__(
        self,
        *,
        requested: str,
        available: frozenset[str],
    ) -> None:
        self.requested = requested
        self.available = frozenset(available)
        listed = ", ".join(sorted(self.available)) if self.available else "(none)"
        super().__init__(
            f"Skill did not declare the required capability {requested!r}. "
            f"Currently allowed: {listed}. "
            f"Add it to the Skill's capabilities list to enable this operation."
        )


class BuildError(SynaxSDKError):
    """A build step (load, validate, package, sign, write) failed.

    Aggregates validation errors when validation is the cause; the CLI
    formats them into a coloured list. Construct via :meth:`with_errors`
    when carrying a structured list.
    """

    def __init__(self, message: str, *, errors: list[object] | None = None) -> None:
        super().__init__(message)
        self.errors = errors or []


class PublishError(SynaxSDKError):
    """Base class for publishing failures.

    Subclasses distinguish between authentication problems, server-side
    rejection of the manifest, version conflicts, and network/transient
    failures so the CLI can render the right message and exit code.
    """


class PublishAuthError(PublishError):
    """The platform rejected the auth token (HTTP 401/403)."""


class PublishValidationError(PublishError):
    """The platform rejected the manifest (HTTP 400). Typically because the
    SDK's vendored schema is ahead of or behind the platform's."""

    def __init__(self, message: str, *, details: object | None = None) -> None:
        super().__init__(message)
        self.details = details


class PublishVersionConflictError(PublishError):
    """Version already published (HTTP 409). The author must bump the version."""

    def __init__(self, message: str, *, existing_version_id: str | None = None) -> None:
        super().__init__(message)
        self.existing_version_id = existing_version_id


# Backwards-compatible alias for the original name (without the Error suffix).
PublishVersionConflict = PublishVersionConflictError


class PublishNetworkError(PublishError):
    """Network failure or persistent 5xx after retries."""
