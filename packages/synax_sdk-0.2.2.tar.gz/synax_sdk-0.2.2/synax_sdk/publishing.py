"""HTTP client for publishing skills to a Synax platform instance.

Wire format documented in ``docs/manifest_spec.md`` § Wire Format for
Publishing:

* ``POST {target_url}/api/v1/skills/publish``
* ``Authorization: Bearer <token>``
* Body (JSON):

  .. code-block:: json

      {
        "manifest_yaml": "...",
        "implementation_artifact_b64": "...",
        "implementation_hash": "sha256:..."
      }

* Success response (HTTP 200):

  .. code-block:: json

      {
        "skill_id": "uuid",
        "skill_version_id": "uuid",
        "status": "registered",
        "marketplace_url": "https://..."
      }

* Errors: ``400 manifest_invalid``, ``401/403 auth``,
  ``409 version_already_published``, plus 5xx transient.

The platform's publish endpoint isn't built yet (per ``build_plan.md``
§M5 notes). We pin the contract here so the SDK can be tested against
the mock today and against the real endpoint as soon as it lands.
"""

from __future__ import annotations

import base64
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import httpx

from synax_sdk.errors import (
    PublishAuthError,
    PublishError,
    PublishNetworkError,
    PublishValidationError,
    PublishVersionConflict,
)

PUBLISH_PATH = "/api/v1/skills/publish"
KEY_REGISTER_PATH = "/api/v1/keys/register"

DEFAULT_TIMEOUT_SECONDS = 60.0
DEFAULT_MAX_RETRIES = 3
RETRY_BACKOFF_BASE_SECONDS = 1.0


ProgressStage = Literal["uploading", "complete"]


@dataclass(frozen=True)
class PublishProgress:
    """A progress notification surfaced to the caller during publish."""

    stage: ProgressStage
    message: str
    bytes_total: int | None = None


@dataclass(frozen=True)
class PublishResult:
    """Outcome of a successful publish."""

    skill_id: str
    skill_version_id: str
    status: str
    marketplace_url: str | None = None


@dataclass(frozen=True)
class KeyRegistrationResult:
    """Outcome of a successful ``keys register`` call."""

    registration_id: str
    status: str


# ---------------------------------------------------------------------------
# PublishClient
# ---------------------------------------------------------------------------
class PublishClient:
    """HTTP client for the publish endpoint.

    Constructed with the platform URL + auth token. A single client may
    be reused across multiple publish calls. Pass a custom ``httpx.Client``
    only for advanced testing — the default sets sensible timeouts.
    """

    def __init__(
        self,
        target_url: str,
        auth_token: str,
        *,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = DEFAULT_MAX_RETRIES,
        client: httpx.Client | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if not target_url:
            raise PublishError("Empty target URL — pass --target https://...")
        if not auth_token:
            raise PublishAuthError(
                "Empty auth token. Pass --token, set SYNAX_PUBLISH_TOKEN, "
                "or configure ~/.synax/config.yaml."
            )
        self.target_url = target_url.rstrip("/")
        self.auth_token = auth_token
        self.max_retries = max_retries
        self._owns_client = client is None
        self._client = client or httpx.Client(timeout=timeout)
        self._sleep = sleep

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> PublishClient:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    # ----- publish ----------------------------------------------------------
    def publish(
        self,
        bundle_dir: Path,
        *,
        on_progress: Callable[[PublishProgress], None] | None = None,
    ) -> PublishResult:
        """Upload the bundle at ``bundle_dir`` and return the platform's result.

        ``bundle_dir`` should be the ``signed_bundle/`` directory produced
        by :func:`synax_sdk.build.build` — it must contain ``manifest.yaml``
        and ``implementation.tar.gz``.
        """
        manifest_path = bundle_dir / "manifest.yaml"
        artifact_path = bundle_dir / "implementation.tar.gz"
        if not manifest_path.exists():
            raise PublishError(f"Manifest not found: {manifest_path}")
        if not artifact_path.exists():
            raise PublishError(f"Artifact not found: {artifact_path}")

        manifest_yaml = manifest_path.read_text(encoding="utf-8")
        artifact_bytes = artifact_path.read_bytes()
        import hashlib

        implementation_hash = "sha256:" + hashlib.sha256(artifact_bytes).hexdigest()

        body: dict[str, Any] = {
            "manifest_yaml": manifest_yaml,
            "implementation_artifact_b64": base64.b64encode(artifact_bytes).decode("ascii"),
            "implementation_hash": implementation_hash,
        }
        if on_progress is not None:
            on_progress(
                PublishProgress(
                    stage="uploading",
                    message=f"Uploading manifest + {len(artifact_bytes)} byte artifact",
                    bytes_total=len(artifact_bytes),
                )
            )

        response = self._request_with_retries("POST", PUBLISH_PATH, body)
        result = _parse_publish_response(response)

        if on_progress is not None:
            on_progress(PublishProgress(stage="complete", message="Published successfully"))
        return result

    # ----- key registration -------------------------------------------------
    def register_key(
        self,
        *,
        public_key_b64: str,
        fingerprint: str,
        namespace: str,
        label: str | None = None,
    ) -> KeyRegistrationResult:
        """Register a public key with the platform for a namespace.

        The platform's admin reviews the request; until approved the
        ``status`` field on the response will be ``"pending_approval"``.

        ``label`` is an optional human-readable string attached to the
        registration request (e.g. ``"synax-skills CI key"``). When
        omitted the field is not sent; older platform versions ignore
        unknown fields, so passing a label is safe against any platform
        deployment.
        """
        body: dict[str, Any] = {
            "public_key_b64": public_key_b64,
            "fingerprint": fingerprint,
            "namespace": namespace,
        }
        if label is not None:
            body["label"] = label
        response = self._request_with_retries("POST", KEY_REGISTER_PATH, body)
        return _parse_key_registration_response(response)

    # ----- internals --------------------------------------------------------
    def _request_with_retries(
        self,
        method: str,
        path: str,
        body: dict[str, Any],
    ) -> httpx.Response:
        url = f"{self.target_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.auth_token}",
            "Content-Type": "application/json",
        }
        last_error: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                response = self._client.request(method, url, json=body, headers=headers)
            except (httpx.ConnectError, httpx.TimeoutException, httpx.ReadError) as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    raise PublishNetworkError(
                        f"Network error contacting {url} after {attempt} attempts: {exc}"
                    ) from exc
                self._sleep(RETRY_BACKOFF_BASE_SECONDS * (2 ** (attempt - 1)))
                continue

            if 500 <= response.status_code < 600:
                last_error = PublishNetworkError(
                    f"Server returned {response.status_code} for {url}"
                )
                if attempt >= self.max_retries:
                    raise last_error
                self._sleep(RETRY_BACKOFF_BASE_SECONDS * (2 ** (attempt - 1)))
                continue
            return response

        # Should be unreachable — loop either returns or raises.
        raise PublishNetworkError(  # pragma: no cover - defensive
            f"Exhausted retries contacting {url}: {last_error}"
        )


# ---------------------------------------------------------------------------
# Top-level convenience
# ---------------------------------------------------------------------------
def publish(
    target_url: str,
    auth_token: str,
    bundle_dir: Path,
    *,
    on_progress: Callable[[PublishProgress], None] | None = None,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> PublishResult:
    """One-shot publish: build a client, send the bundle, return the result."""
    with PublishClient(
        target_url=target_url,
        auth_token=auth_token,
        timeout=timeout,
        max_retries=max_retries,
    ) as client:
        return client.publish(bundle_dir, on_progress=on_progress)


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------
def _parse_publish_response(response: httpx.Response) -> PublishResult:
    if response.status_code == httpx.codes.OK:
        try:
            data = response.json()
        except ValueError as exc:
            raise PublishError(
                f"Platform returned non-JSON body for 200: {response.text!r}"
            ) from exc
        try:
            return PublishResult(
                skill_id=data["skill_id"],
                skill_version_id=data["skill_version_id"],
                status=data["status"],
                marketplace_url=data.get("marketplace_url"),
            )
        except KeyError as exc:
            raise PublishError(
                f"Platform 200 response missing required field: {exc}. Body: {data!r}"
            ) from exc

    if response.status_code in (401, 403):
        message = _extract_error_message(response)
        raise PublishAuthError(
            f"Authentication failed (HTTP {response.status_code}): {message}. "
            "Check SYNAX_PUBLISH_TOKEN or --token."
        )
    if response.status_code == 400:
        data = _safe_json(response)
        raise PublishValidationError(
            f"Platform rejected manifest (HTTP 400): {_extract_error_message(response)}",
            details=data.get("details") if isinstance(data, dict) else None,
        )
    if response.status_code == 409:
        data = _safe_json(response)
        existing = None
        if isinstance(data, dict):
            details = data.get("details")
            if isinstance(details, dict):
                existing = details.get("existing_version_id")
        raise PublishVersionConflict(
            f"Version already published (HTTP 409): {_extract_error_message(response)}. "
            "Bump the version in your skill and re-build.",
            existing_version_id=existing,
        )
    raise PublishError(
        f"Unexpected HTTP {response.status_code} from {response.url}: "
        f"{_extract_error_message(response)}"
    )


def _parse_key_registration_response(response: httpx.Response) -> KeyRegistrationResult:
    if response.status_code == httpx.codes.OK:
        data = _safe_json(response)
        if not isinstance(data, dict):
            raise PublishError(f"Key registration: non-object JSON response: {data!r}")
        try:
            return KeyRegistrationResult(
                registration_id=data["registration_id"],
                status=data["status"],
            )
        except KeyError as exc:
            raise PublishError(
                f"Key registration 200 missing field: {exc}. Body: {data!r}"
            ) from exc

    if response.status_code in (401, 403):
        raise PublishAuthError(
            f"Authentication failed registering key (HTTP {response.status_code}): "
            f"{_extract_error_message(response)}."
        )
    if response.status_code == 409:
        raise PublishError(
            f"Key already registered for this namespace (HTTP 409): "
            f"{_extract_error_message(response)}."
        )
    raise PublishError(
        f"Unexpected HTTP {response.status_code} registering key: "
        f"{_extract_error_message(response)}"
    )


def _safe_json(response: httpx.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return None


def _extract_error_message(response: httpx.Response) -> str:
    """Pull a human-readable message out of an error response body if possible."""
    data = _safe_json(response)
    if isinstance(data, dict):
        for key in ("message", "error", "detail"):
            value = data.get(key)
            if isinstance(value, str) and value:
                return value
    text = response.text
    if text:
        return text[:200]
    return f"HTTP {response.status_code}"
