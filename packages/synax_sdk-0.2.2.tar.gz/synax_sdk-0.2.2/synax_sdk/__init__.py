"""Synax SDK — Python library for building skills on the Synax agentic platform.

Public API surface. Anything exported here is part of the stable (within a
minor version) API; anything not exported is internal and may change.

See ``docs/build_plan.md`` for what's wired up at each milestone.
"""

from synax_sdk.errors import (
    CapabilityError,
    ManifestError,
    SkillDefinitionError,
    SkillRuntimeError,
    SkillValidationError,
    SynaxSDKError,
)
from synax_sdk.manifest import Manifest
from synax_sdk.runtime import Context, Invoker, ctx, logger, metrics, network, secrets
from synax_sdk.skill import Secret, Skill, SkillDependency, SkillMetadata
from synax_sdk.version import __version__

__all__ = [
    "CapabilityError",
    "Context",
    "Invoker",
    "Manifest",
    "ManifestError",
    "Secret",
    "Skill",
    "SkillDefinitionError",
    "SkillDependency",
    "SkillMetadata",
    "SkillRuntimeError",
    "SkillValidationError",
    "SynaxSDKError",
    "__version__",
    "ctx",
    "logger",
    "metrics",
    "network",
    "secrets",
]
