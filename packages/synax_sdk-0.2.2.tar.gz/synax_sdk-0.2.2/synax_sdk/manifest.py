"""Skill manifest dataclasses, the ``from_skill`` factory, and serialization.

A manifest is the YAML/JSON representation of a skill that the platform
consumes. This module is the SDK's source of truth for the manifest shape;
the schema it produces must match ``docs/manifest_spec.md``.

At Milestone 2 the manifest is *in-memory only* — no file I/O, no signing,
no JSON Schema validation. ``Implementation.entry_point`` and
``Implementation.hash`` are placeholders that later milestones (4: packaging
& signing) fill in.
"""

from __future__ import annotations

import dataclasses
import json
from dataclasses import dataclass, field
from typing import Any, Literal

import yaml

from synax_sdk import version as _version_module
from synax_sdk.errors import ManifestError
from synax_sdk.skill import Secret, Skill, SkillDependency, SkillMetadata
from synax_sdk.tool import Tool

SCHEMA_VERSION = "1.0"

SignerType = Literal["author", "platform_verifier", "audit", "customer_internal"]
ImplementationType = Literal["python_code", "manifest_only", "typescript_code"]


# ---------------------------------------------------------------------------
# Sub-dataclasses
# ---------------------------------------------------------------------------
@dataclass
class Implementation:
    """How the skill is implemented.

    Only ``type`` is required at construction time. ``entry_point`` and
    ``hash`` are filled in by the build pipeline (Milestone 4).
    """

    type: ImplementationType = "python_code"
    entry_point: str | None = None
    hash: str | None = None
    runtime_requirements: dict[str, str] | None = None


@dataclass
class ToolManifest:
    """A tool as it appears in the manifest."""

    name: str
    description: str
    parameters: dict[str, Any]
    returns: dict[str, Any] | None = None

    @classmethod
    def from_tool(cls, tool: Tool) -> ToolManifest:
        return cls(
            name=tool.name,
            description=tool.description,
            parameters=dict(tool.parameters_schema),
            returns=dict(tool.returns_schema) if tool.returns_schema is not None else None,
        )


@dataclass
class SecretManifest:
    """A secret as it appears in the manifest."""

    name: str
    type: str
    description: str
    scope_required: str | None = None

    @classmethod
    def from_secret(cls, secret: Secret) -> SecretManifest:
        return cls(
            name=secret.name,
            type=secret.type,
            description=secret.description,
            scope_required=secret.scope_required,
        )


@dataclass
class DependencyManifest:
    skill: str
    version: str

    @classmethod
    def from_dependency(cls, dep: SkillDependency) -> DependencyManifest:
        return cls(skill=dep.skill, version=dep.version)


@dataclass
class ManifestMetadata:
    """Manifest-side metadata. Mirrors :class:`SkillMetadata` and adds
    ``sdk_version`` (populated automatically by ``Manifest.from_skill``)."""

    category: str | None = None
    tags: list[str] = field(default_factory=list)
    homepage: str | None = None
    source: str | None = None
    documentation: str | None = None
    license: str | None = None
    long_description: str | None = None
    icon_url: str | None = None
    sdk_version: str | None = None

    @classmethod
    def from_skill_metadata(
        cls, meta: SkillMetadata, *, sdk_version: str | None = None
    ) -> ManifestMetadata:
        return cls(
            category=meta.category,
            tags=list(meta.tags),
            homepage=meta.homepage,
            source=meta.source,
            documentation=meta.documentation,
            license=meta.license,
            long_description=meta.long_description,
            icon_url=meta.icon_url,
            sdk_version=sdk_version,
        )


@dataclass
class Signature:
    key_fingerprint: str
    signer_type: SignerType
    signature: str
    signed_at: str


# ---------------------------------------------------------------------------
# The top-level Manifest
# ---------------------------------------------------------------------------
@dataclass
class Manifest:
    """The top-level skill manifest.

    Construct via :meth:`Manifest.from_skill` rather than instantiating
    directly. Serialize via :meth:`to_yaml`, :meth:`to_json`, or
    :meth:`to_canonical_json` (the bytes used as input to Ed25519 signing).
    """

    schema_version: str
    name: str
    version: str
    display_name: str
    description: str
    implementation: Implementation
    tools: list[ToolManifest]
    namespace: str | None = None
    capabilities: list[str] = field(default_factory=list)
    execution_location: str = "either"
    secrets: list[SecretManifest] = field(default_factory=list)
    dependencies: list[DependencyManifest] = field(default_factory=list)
    metadata: ManifestMetadata = field(default_factory=ManifestMetadata)
    signatures: list[Signature] = field(default_factory=list)

    # -----------------------------------------------------------------------
    @classmethod
    def from_skill(
        cls,
        skill: Skill,
        *,
        sdk_version: str | None = None,
    ) -> Manifest:
        """Build a Manifest from a :class:`~synax_sdk.skill.Skill`.

        The resulting manifest has ``implementation.entry_point`` and
        ``implementation.hash`` left as ``None``; the build pipeline
        (Milestone 4) fills them in once it knows the packaged artifact's
        module path and hash.

        Args:
            skill: source of truth.
            sdk_version: overrides the auto-detected SDK version stamp in
                ``metadata.sdk_version``. Mostly useful for reproducible
                tests.
        """
        return cls(
            schema_version=SCHEMA_VERSION,
            name=skill.name,
            namespace=skill.namespace,
            version=skill.version,
            display_name=skill.display_name,
            description=skill.description,
            implementation=Implementation(type="python_code"),
            tools=[ToolManifest.from_tool(t) for t in skill.tools],
            capabilities=list(skill.capabilities),
            execution_location=skill.execution_location,
            secrets=[SecretManifest.from_secret(s) for s in skill.secrets],
            dependencies=[DependencyManifest.from_dependency(d) for d in skill.dependencies],
            metadata=ManifestMetadata.from_skill_metadata(
                skill.metadata,
                sdk_version=(
                    sdk_version if sdk_version is not None else _version_module.__version__
                ),
            ),
            signatures=[],
        )

    # -----------------------------------------------------------------------
    # Serialization
    # -----------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a plain ``dict`` matching ``manifest_spec.md`` field order.

        Empty optional collections, ``None`` scalars, and defaulted values
        (``execution_location == "either"``) are omitted so the resulting
        document is concise.
        """
        result: dict[str, Any] = {
            "schema_version": self.schema_version,
            "name": self.name,
        }
        if self.namespace:
            result["namespace"] = self.namespace
        result["version"] = self.version
        result["display_name"] = self.display_name
        result["description"] = self.description
        result["implementation"] = _filter_dataclass(self.implementation)
        result["tools"] = [_filter_dataclass(t) for t in self.tools]
        if self.capabilities:
            result["capabilities"] = list(self.capabilities)
        if self.execution_location != "either":
            result["execution_location"] = self.execution_location
        if self.secrets:
            result["secrets"] = [_filter_dataclass(s) for s in self.secrets]
        if self.dependencies:
            result["dependencies"] = [_filter_dataclass(d) for d in self.dependencies]
        meta = _filter_dataclass(self.metadata)
        if meta:
            result["metadata"] = meta
        if self.signatures:
            result["signatures"] = [_filter_dataclass(s) for s in self.signatures]
        return result

    def to_yaml(self) -> str:
        """Serialize as a YAML document with the spec's field order preserved."""
        try:
            return yaml.safe_dump(
                self.to_dict(),
                sort_keys=False,
                default_flow_style=False,
                allow_unicode=True,
            )
        except yaml.YAMLError as exc:  # pragma: no cover - defensive
            raise ManifestError(f"Failed to serialize manifest to YAML: {exc}") from exc

    def to_json(self, *, indent: int | None = 2) -> str:
        """Serialize as JSON. Default is indented for human review."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def to_canonical_json(self) -> bytes:
        """Return the canonical signing bytes.

        The canonical form (per ``manifest_spec.md`` §Canonical form for
        signing):

        1. JSON object representation
        2. Drop ``signatures`` (signatures sign everything *except* themselves)
        3. Sort keys recursively
        4. No whitespace
        5. UTF-8 encoded
        """
        payload = self.to_dict()
        payload.pop("signatures", None)
        return json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _filter_dataclass(obj: Any) -> Any:
    """Convert a dataclass to dict, omitting None and empty list/dict fields.

    Plain ``dict`` instances inside the dataclass (such as a JSON Schema
    payload) are returned unchanged — we only filter at the dataclass
    boundary, not inside opaque payloads.
    """
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        result: dict[str, Any] = {}
        for f in dataclasses.fields(obj):
            value = getattr(obj, f.name)
            cleaned = _filter_dataclass(value)
            if cleaned is None:
                continue
            if isinstance(cleaned, list | dict) and len(cleaned) == 0:
                continue
            result[f.name] = cleaned
        return result
    if isinstance(obj, list):
        return [_filter_dataclass(item) for item in obj]
    return obj
