"""``synax keys ...`` subcommands — Ed25519 keypair management."""

from __future__ import annotations

import base64
import json
import sys
from pathlib import Path

import typer
from rich.table import Table

from synax_sdk.errors import PublishError, SynaxSDKError
from synax_sdk.publishing import PublishClient
from synax_sdk.signing import (
    KeyPair,
    KeyStore,
    fingerprint_for_public_key,
    generate_keypair,
    load_public_key_from_file,
    save_public_key_to_file,
)
from synax_skill_cli.utils.config import load_config, resolve_auth_token, resolve_target
from synax_skill_cli.utils.output import QuietConsole, is_quiet

app = typer.Typer(
    help="Manage Ed25519 signing keys (~/.synax/keys/).",
    no_args_is_help=True,
)
_console = QuietConsole()


def _store(output_dir: Path | None = None) -> KeyStore:
    if output_dir is not None:
        return KeyStore(root=output_dir)
    return KeyStore.default()


def _stdout_is_tty() -> bool:
    """Return whether the current stdout is an interactive terminal.

    Wrapped in a helper so tests can override it — typer's CliRunner
    replaces ``sys.stdout`` with a non-TTY stream, so the "pipe / redirect"
    branch is what the runner naturally exercises; this seam lets us also
    cover the TTY branch.
    """
    return sys.stdout.isatty()


def _fail(msg: str) -> typer.Exit:
    """Print an error and return a typer.Exit(1) for raising."""
    _console.print(f"[red]✗[/red] {msg}")
    return typer.Exit(code=1)


def _key_record(store: KeyStore, fingerprint: str) -> dict[str, object]:
    """Return the JSON-friendly record for a key in the store."""
    kp = store.load(fingerprint)
    return {
        "fingerprint": kp.fingerprint,
        "name": kp.name,
        "created_at": kp.created_at,
        "default": store.default_fingerprint == kp.fingerprint,
        "path": str(store._file_for(kp.fingerprint)),
        "algorithm": "Ed25519",
    }


@app.command("generate")
def keys_generate(
    name: str | None = typer.Option(
        None,
        "--name",
        help="Optional human-readable label stored inline with the key (e.g. 'ci-bot').",
    ),
    output_dir: Path | None = typer.Option(
        None,
        "--output-dir",
        help="Write into this directory instead of ~/.synax/keys/.",
    ),
    set_default: bool = typer.Option(
        False,
        "--set-default",
        help="Set the new key as the default signing key, overriding any existing default.",
    ),
) -> None:
    """Generate a new Ed25519 keypair and save it to ``~/.synax/keys/``."""
    store = _store(output_dir)
    keypair = generate_keypair(name=name)
    path = store.save(keypair)
    if set_default:
        store.set_default(keypair.fingerprint)

    if is_quiet():
        typer.echo(keypair.fingerprint)
        return

    label = f" ({name})" if name else ""
    _console.print(f"[green]✓[/green] Generated keypair {keypair.fingerprint}{label}")
    _console.print(f"  saved to {path}")
    if store.default_fingerprint == keypair.fingerprint:
        _console.print("  set as default signing key")


@app.command("list")
def keys_list(
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit a JSON array of key records instead of the table.",
    ),
) -> None:
    """List known keys in ``~/.synax/keys/``."""
    store = _store()
    fingerprints = store.list_fingerprints()

    if as_json:
        records = [_key_record(store, fp) for fp in fingerprints]
        typer.echo(json.dumps(records, indent=2))
        return

    if is_quiet():
        for fp in fingerprints:
            typer.echo(fp)
        return

    if not fingerprints:
        _console.print(
            "[yellow]No keys found.[/yellow] Run [bold]synax keys generate[/bold] to create one."
        )
        return

    default = store.default_fingerprint
    table = Table(title=f"Keys at {store.root}")
    table.add_column("Fingerprint")
    table.add_column("Name")
    table.add_column("Created")
    table.add_column("Default", justify="center")
    for fp in fingerprints:
        kp = store.load(fp)
        marker = "[green]*[/green]" if fp == default else ""
        table.add_row(fp, kp.name or "—", kp.created_at or "—", marker)
    _console.print(table)


@app.command("show")
def keys_show(
    fingerprint: str = typer.Argument(..., help="Full fingerprint or any unambiguous hex prefix."),
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit the record as a JSON object instead of human-readable lines.",
    ),
) -> None:
    """Show metadata for a single key."""
    store = _store()
    try:
        record = _key_record(store, fingerprint)
    except SynaxSDKError as exc:
        raise _fail(str(exc)) from exc

    if as_json:
        typer.echo(json.dumps(record, indent=2))
        return

    if is_quiet():
        typer.echo(str(record["fingerprint"]))
        return

    _console.print(f"[bold]{record['fingerprint']}[/bold]")
    _console.print(f"  name:       {record['name'] or '—'}")
    _console.print(f"  created_at: {record['created_at'] or '—'}")
    _console.print(f"  default:    {'yes' if record['default'] else 'no'}")
    _console.print(f"  algorithm:  {record['algorithm']}")
    _console.print(f"  path:       {record['path']}")


@app.command("export")
def keys_export(
    fingerprint: str = typer.Argument(
        ..., help="Key fingerprint to export (full or any unambiguous prefix)."
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Write the public key to this file instead of stdout.",
    ),
) -> None:
    """Export a public key by fingerprint (or write to stdout).

    When stdout is a TTY (interactive shell), prints a human-readable
    summary. When stdout is redirected to a file or pipe, emits the JSON
    pub-file format so that ``synax keys export <fp> > ci.pub`` produces
    a file that ``synax keys register --public-key-file ci.pub`` can
    consume.
    """
    store = _store()
    try:
        keypair = store.load(fingerprint)
    except SynaxSDKError as exc:
        raise _fail(str(exc)) from exc

    if output is not None:
        save_public_key_to_file(keypair, output)
        if not is_quiet():
            _console.print(f"[green]✓[/green] Public key written to {output}")
        return

    # No --output: write to stdout. Pipe-friendly when not a TTY.
    if not _stdout_is_tty() or is_quiet():
        payload = {
            "version": 1,
            "algorithm": "Ed25519",
            "fingerprint": keypair.fingerprint,
            "public_key_b64": base64.b64encode(keypair.public_key).decode("ascii"),
        }
        if keypair.created_at is not None:
            payload["created_at"] = keypair.created_at
        if keypair.name is not None:
            payload["name"] = keypair.name
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
        return

    # TTY: human-friendly KV summary.
    public_b64 = base64.b64encode(keypair.public_key).decode("ascii")
    typer.echo(f"fingerprint: {keypair.fingerprint}")
    typer.echo(f"public_key_b64: {public_b64}")
    if keypair.name is not None:
        typer.echo(f"name: {keypair.name}")
    if keypair.created_at is not None:
        typer.echo(f"created_at: {keypair.created_at}")


@app.command("import")
def keys_import(
    pub_file: Path = typer.Argument(..., help="Path to a public key file."),
) -> None:
    """Import a public key file (for verification only — no private half)."""
    store = _store()
    try:
        keypair = load_public_key_from_file(pub_file)
    except SynaxSDKError as exc:
        raise _fail(str(exc)) from exc
    target = store.save(keypair, set_default_if_none=False)

    if is_quiet():
        typer.echo(keypair.fingerprint)
        return

    _console.print(f"[green]✓[/green] Imported public key {keypair.fingerprint}")
    _console.print(f"  saved to {target}")


@app.command("set-default")
def keys_set_default(
    fingerprint: str = typer.Argument(
        ..., help="Fingerprint of an existing key (full or any unambiguous prefix)."
    ),
) -> None:
    """Set the default signing key."""
    store = _store()
    try:
        store.set_default(fingerprint)
        resolved = store.default_fingerprint
    except SynaxSDKError as exc:
        raise _fail(str(exc)) from exc

    if is_quiet():
        if resolved is not None:
            typer.echo(resolved)
        return

    _console.print(f"[green]✓[/green] Default key set to {resolved}")


@app.command("delete")
def keys_delete(
    fingerprint: str = typer.Argument(
        ..., help="Fingerprint of an existing key (full or any unambiguous prefix)."
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip the confirmation prompt. Required to delete the active default.",
    ),
) -> None:
    """Delete a key from the local store.

    Refuses to delete the active default unless ``--force`` is passed.
    Under ``synax --quiet`` deletion is non-interactive and ``--force``
    becomes required (no prompt can be shown).
    """
    store = _store()
    try:
        full = store.resolve(fingerprint)
    except SynaxSDKError as exc:
        raise _fail(str(exc)) from exc

    is_default = store.default_fingerprint == full

    if not force:
        if is_quiet():
            raise _fail("Refusing to delete without --force in quiet mode (no interactive prompt).")
        prompt = f"Delete key {full}?"
        if is_default:
            prompt = f"{full} is the default signing key. Pass --force to delete it. Aborting."
            raise _fail(prompt)
        confirmed = typer.confirm(prompt, default=False)
        if not confirmed:
            _console.print("Aborted.")
            return

    try:
        store.delete(full, force=True)
    except SynaxSDKError as exc:
        raise _fail(str(exc)) from exc

    if is_quiet():
        typer.echo(full)
        return

    _console.print(f"[green]✓[/green] Deleted key {full}")
    if is_default:
        _console.print("  default pointer cleared")


@app.command("register")
def keys_register(
    namespace: str = typer.Option(..., "--namespace", help="Namespace to claim."),
    target: str | None = typer.Option(
        None,
        "--target",
        help="Platform URL (overrides config.default_target).",
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help="Publish auth token. Falls back to SYNAX_PUBLISH_TOKEN env var, then config.",
    ),
    fingerprint: str | None = typer.Option(
        None,
        "--key",
        "-k",
        help="Key fingerprint to register (full or any unambiguous prefix). "
        "Defaults to the configured default key. Mutually exclusive with --public-key-file.",
    ),
    public_key_file: Path | None = typer.Option(
        None,
        "--public-key-file",
        help="Register a public key from a file produced by `synax keys export` instead of "
        "a key in the local store. Mutually exclusive with --key.",
    ),
    label: str | None = typer.Option(
        None,
        "--label",
        help="Optional human-readable label sent to the platform alongside the registration.",
    ),
) -> None:
    """Register a public key with a platform for trusted-publisher onboarding."""
    if fingerprint is not None and public_key_file is not None:
        raise _fail("--key and --public-key-file are mutually exclusive.")

    config = load_config()
    resolved_target = resolve_target(target, config)
    if not resolved_target:
        raise _fail("No target URL. Pass --target, or set default_target in ~/.synax/config.yaml.")
    resolved_token = resolve_auth_token(token, config)
    if not resolved_token:
        raise _fail(
            "No publish token. Pass --token, set SYNAX_PUBLISH_TOKEN, "
            "or configure default_auth_token_env in ~/.synax/config.yaml."
        )

    keypair: KeyPair
    if public_key_file is not None:
        try:
            keypair = load_public_key_from_file(public_key_file)
        except SynaxSDKError as exc:
            raise _fail(str(exc)) from exc
    else:
        store = _store()
        fp = fingerprint or store.default_fingerprint
        if not fp:
            raise _fail(
                "No key fingerprint. Pass --key, --public-key-file, or set a default "
                "with `synax keys set-default`."
            )
        try:
            keypair = store.load(fp)
        except SynaxSDKError as exc:
            raise _fail(str(exc)) from exc

    public_b64 = base64.b64encode(keypair.public_key).decode("ascii")
    # Recompute the fingerprint locally so a tampered or stale name field
    # in the file can't lie about identity.
    final_fingerprint = fingerprint_for_public_key(keypair.public_key)

    try:
        with PublishClient(target_url=resolved_target, auth_token=resolved_token) as client:
            result = client.register_key(
                public_key_b64=public_b64,
                fingerprint=final_fingerprint,
                namespace=namespace,
                label=label,
            )
    except PublishError as exc:
        raise _fail(str(exc)) from exc

    if is_quiet():
        typer.echo(result.registration_id)
        return

    _console.print(
        f"[green]✓[/green] Registered key {final_fingerprint} "
        f"for namespace [bold]{namespace}[/bold]"
    )
    _console.print(f"  registration_id: {result.registration_id}")
    _console.print(f"  status:          {result.status}")
