"""``synax skill ...`` subcommands — author, validate, build, publish skills."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import typer
import yaml
from rich.console import Console
from rich.table import Table

from synax_sdk import version as _version_module
from synax_sdk.build import BUNDLE_SUBDIR, DEFAULT_OUTPUT_SUBDIR, build
from synax_sdk.errors import BuildError, PublishError, SynaxSDKError
from synax_sdk.manifest import Manifest
from synax_sdk.publishing import PublishClient, PublishProgress
from synax_sdk.signing import Verifier, fingerprint_for_public_key, load_keypair_from_file
from synax_sdk.testing.declarative import CaseResult, TestCaseError, run_all
from synax_sdk.validation import ValidationError, validate_manifest
from synax_skill_cli.utils.config import load_config, resolve_auth_token, resolve_target
from synax_skill_cli.utils.project import (
    find_project_root,
    load_skill_from_project,
    read_synax_config,
)
from synax_skill_cli.utils.templating import TemplateError, render_template_dir

TEST_INPUTS_DIRNAME = "test_inputs"

app = typer.Typer(
    help="Author, validate, build, and publish skills.",
    no_args_is_help=True,
)
_console = Console()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _print_validation_errors(errors: list[ValidationError]) -> None:
    """Render a list of ValidationError instances as a rich table."""
    if not errors:
        return
    table = Table(show_header=True)
    table.add_column("kind", style="bold")
    table.add_column("field")
    table.add_column("message")
    table.add_column("suggestion", style="dim")
    for err in errors:
        colour = {"schema": "red", "consistency": "red", "warning": "yellow"}.get(err.kind, "white")
        table.add_row(
            f"[{colour}]{err.kind}[/{colour}]", err.field, err.message, err.suggestion or ""
        )
    _console.print(table)


def _resolve_project_root() -> Path:
    """Wrap find_project_root with friendly error printing."""
    try:
        return find_project_root()
    except SynaxSDKError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
SKILL_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,127}$")


def _git_user_name() -> str | None:
    """Best-effort lookup of the current git user name (``git config user.name``)."""
    try:
        result = subprocess.run(
            ["git", "config", "--get", "user.name"],  # noqa: S607
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    name = result.stdout.strip()
    return name or None


def _git_init(directory: Path) -> bool:
    """Run ``git init`` in ``directory``. Returns True on success."""
    try:
        result = subprocess.run(
            ["git", "init", "--quiet"],  # noqa: S607
            cwd=directory,
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False
    return result.returncode == 0


@app.command("init")
def skill_init(
    name: str = typer.Argument(..., help="Skill name (slug format)."),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output directory (default: <skill_name>/ under the current directory).",
    ),
    author: str | None = typer.Option(
        None,
        "--author",
        help="Author name. Defaults to `git config user.name`, then 'Skill Author'.",
    ),
    version: str = typer.Option(
        "0.1.0",
        "--version",
        help="Initial version for the scaffolded project.",
    ),
    do_git: bool = typer.Option(
        True,
        "--git/--no-git",
        help="Run `git init` in the new project directory.",
    ),
) -> None:
    """Scaffold a new Synax skill project."""
    if not SKILL_NAME_RE.match(name):
        _console.print(
            f"[red]✗[/red] Invalid skill name {name!r}. "
            "Names must be lowercase slug format (a-z, 0-9, hyphens), 1-128 chars, "
            "starting with a letter or digit."
        )
        raise typer.Exit(code=1)

    target = output if output is not None else Path.cwd() / name
    target = target.resolve()
    if target.exists() and any(target.iterdir()):
        _console.print(f"[red]✗[/red] Output directory {target} already exists and is not empty.")
        raise typer.Exit(code=1)

    resolved_author = author or _git_user_name() or "Skill Author"
    variables = {
        "skill_name": name,
        "skill_name_snake": name.replace("-", "_"),
        "skill_name_human": " ".join(p.capitalize() for p in name.split("-") if p),
        "author_name": resolved_author,
        "version": version,
        "sdk_version": _version_module.__version__,
    }

    try:
        rendered = render_template_dir(output_dir=target, variables=variables)
    except TemplateError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    if do_git:
        if _git_init(target):
            _console.print(f"  initialised git repository in {target}")
        else:
            _console.print(
                "  [yellow]⚠[/yellow] couldn't run `git init` (git not installed?) — "
                "skipping; project files are otherwise complete."
            )

    _console.print(f"[green]✓[/green] Created [bold]{name}[/bold] at {target}")
    _console.print(
        f"  scaffolded {len(rendered)} files, pinned to synax-sdk {_version_module.__version__}"
    )
    _console.print()
    _console.print("To get started:")
    _console.print(f"  cd {target.name if output is None else target}")
    _console.print("  uv sync")
    _console.print("  uv run synax skill test")
    _console.print("  uv run synax skill build")


@app.command("validate")
def skill_validate() -> None:
    """Validate the current project's skill manifest."""
    root = _resolve_project_root()
    try:
        skill = load_skill_from_project(root)
    except SynaxSDKError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    manifest = Manifest.from_skill(skill)
    errors = validate_manifest(manifest)
    blocking = [e for e in errors if e.kind != "warning"]
    warnings = [e for e in errors if e.kind == "warning"]

    if errors:
        _print_validation_errors(errors)

    if blocking:
        _console.print(
            f"[red]✗[/red] Validation failed: {len(blocking)} error(s), {len(warnings)} warning(s)."
        )
        raise typer.Exit(code=1)

    if warnings:
        _console.print(f"[yellow]⚠[/yellow] Validation passed with {len(warnings)} warning(s).")
    else:
        tool_count = len(skill.tools)
        cap_count = len(skill.capabilities)
        sec_count = len(skill.secrets)
        _console.print(
            f"[green]✓[/green] Validation passed ({tool_count} tools, "
            f"{cap_count} capabilities, {sec_count} secrets)."
        )


@app.command("test")
def skill_test(
    tool: str | None = typer.Option(
        None,
        "--tool",
        help="Run only cases whose tool name matches this exactly.",
    ),
    filter_pattern: str | None = typer.Option(
        None,
        "--filter",
        "-f",
        help="Run only cases whose name contains this substring.",
    ),
    inputs_dir: Path | None = typer.Option(
        None,
        "--inputs",
        help=f"Override the test inputs directory (default: <project>/{TEST_INPUTS_DIRNAME}).",
    ),
) -> None:
    """Run the skill's declarative test cases against a mock platform."""
    root = _resolve_project_root()
    try:
        skill = load_skill_from_project(root)
    except SynaxSDKError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    test_inputs = inputs_dir if inputs_dir is not None else root / TEST_INPUTS_DIRNAME
    if not test_inputs.exists():
        _console.print(
            f"[yellow]⚠[/yellow] No test inputs directory at {test_inputs}. "
            f"Create one with `mkdir {TEST_INPUTS_DIRNAME}/<tool>` and add YAML cases."
        )
        raise typer.Exit(code=0)

    try:
        results = run_all(skill, test_inputs, filter_tool=tool, filter_case=filter_pattern)
    except TestCaseError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    if not results:
        _console.print("[yellow]⚠[/yellow] No matching test cases found.")
        raise typer.Exit(code=0)

    _print_test_results(results)

    failed = [r for r in results if not r.passed]
    if failed:
        _console.print(
            f"[red]✗[/red] {len(failed)} test case(s) failed, "
            f"{len(results) - len(failed)} passed."
        )
        raise typer.Exit(code=1)
    _console.print(f"[green]✓[/green] All {len(results)} test case(s) passed.")


def _print_test_results(results: list[CaseResult]) -> None:
    """Render the per-case outcome to the console."""
    for result in results:
        ms = result.duration_seconds * 1000
        if result.passed:
            _console.print(f"  [green]✓[/green] {result.label} — PASS ({ms:.0f}ms)")
        else:
            _console.print(f"  [red]✗[/red] {result.label} — FAIL ({ms:.0f}ms)")
            if result.error is not None:
                # Indent the multi-line error text for readability.
                for line in result.error.splitlines()[:6]:
                    _console.print(f"      {line}")
            else:
                for failure in result.failures:
                    _console.print(f"      {failure}")


@app.command("build")
def skill_build(
    key: str | None = typer.Option(
        None,
        "--key",
        "-k",
        help="Signing key fingerprint. Defaults to the configured default.",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Override the build output directory (default: <project>/build).",
    ),
) -> None:
    """Build a signed implementation artifact for the current project."""
    root = _resolve_project_root()
    try:
        skill = load_skill_from_project(root)
        config = read_synax_config(root)
        entry_point = config.get("entry_point")
        if not isinstance(entry_point, str):
            raise BuildError("Missing entry_point in [tool.synax].")
        _console.print(f"  loading: [bold]{skill.name}[/bold] v{skill.version}")
        result = build(
            root,
            skill,
            entry_point=entry_point,
            key_fingerprint=key,
            output_dir=output,
        )
    except BuildError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        if exc.errors:
            # exc.errors is list[ValidationError]
            _print_validation_errors([e for e in exc.errors if isinstance(e, ValidationError)])
        raise typer.Exit(code=1) from exc
    except SynaxSDKError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    _console.print(
        f"[green]✓[/green] Built [bold]{result.manifest.name}[/bold] v{result.manifest.version}"
    )
    _console.print(f"  manifest:    {result.bundle_dir / 'manifest.yaml'}")
    _console.print(f"  artifact:    {result.bundle_dir / 'implementation.tar.gz'}")
    _console.print(f"  hash:        {result.artifact.sha256}")
    _console.print(f"  signed by:   {result.signature.key_fingerprint}")
    if result.warnings:
        _console.print(f"[yellow]⚠[/yellow] {len(result.warnings)} warning(s):")
        _print_validation_errors(result.warnings)


@app.command("publish")
def skill_publish(
    target: str | None = typer.Option(
        None,
        "--target",
        help="Platform URL (overrides config.default_target).",
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help="Publish auth token. Falls back to SYNAX_PUBLISH_TOKEN env var, then config.",
    ),
    key: str | None = typer.Option(
        None,
        "--key",
        "-k",
        help="Signing key fingerprint (only used when re-building).",
    ),
    do_build: bool = typer.Option(
        True,
        "--build/--no-build",
        help="Rebuild the skill before publishing. --no-build uses an existing build/signed_bundle/.",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Override the build output directory (default: <project>/build).",
    ),
) -> None:
    """Build (optional) and publish the current project's skill to a platform."""
    root = _resolve_project_root()
    config = load_config(project_root=root)

    resolved_target = resolve_target(target, config)
    if not resolved_target:
        _console.print(
            "[red]✗[/red] No target URL. Pass --target, or set default_target in "
            "~/.synax/config.yaml."
        )
        raise typer.Exit(code=1)

    resolved_token = resolve_auth_token(token, config)
    if not resolved_token:
        _console.print(
            "[red]✗[/red] No publish token. Pass --token, set SYNAX_PUBLISH_TOKEN, "
            "or configure default_auth_token_env in ~/.synax/config.yaml."
        )
        raise typer.Exit(code=1)

    # Determine the bundle directory.
    if output is not None:
        bundle_dir = output / BUNDLE_SUBDIR
    else:
        bundle_dir = root / DEFAULT_OUTPUT_SUBDIR / BUNDLE_SUBDIR

    if do_build:
        try:
            skill = load_skill_from_project(root)
            skill_config = read_synax_config(root)
            entry_point = skill_config.get("entry_point")
            if not isinstance(entry_point, str):
                raise BuildError("Missing entry_point in [tool.synax].")
            _console.print(f"  building:  [bold]{skill.name}[/bold] v{skill.version}")
            result = build(
                root,
                skill,
                entry_point=entry_point,
                key_fingerprint=key,
                output_dir=output,
            )
            bundle_dir = result.bundle_dir
        except BuildError as exc:
            _console.print(f"[red]✗[/red] {exc}")
            if exc.errors:
                _print_validation_errors([e for e in exc.errors if isinstance(e, ValidationError)])
            raise typer.Exit(code=1) from exc
        except SynaxSDKError as exc:
            _console.print(f"[red]✗[/red] {exc}")
            raise typer.Exit(code=1) from exc
    elif not bundle_dir.exists():
        _console.print(
            f"[red]✗[/red] No build bundle at {bundle_dir}. "
            "Drop --no-build, or run `synax skill build` first."
        )
        raise typer.Exit(code=1)

    def _progress(p: PublishProgress) -> None:
        _console.print(f"  {p.stage}: {p.message}")

    try:
        with PublishClient(target_url=resolved_target, auth_token=resolved_token) as client:
            result_published = client.publish(bundle_dir, on_progress=_progress)
    except PublishError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    _console.print(
        f"[green]✓[/green] Published [bold]{result_published.skill_id}[/bold] "
        f"(version {result_published.skill_version_id})"
    )
    _console.print(f"  status:    {result_published.status}")
    if result_published.marketplace_url:
        _console.print(f"  url:       {result_published.marketplace_url}")


@app.command("verify")
def skill_verify(
    manifest_path: Path = typer.Argument(..., help="Path to a manifest YAML file."),
    public_key: Path | None = typer.Option(
        None,
        "--public-key",
        help="Public key file. Defaults to looking up the signature's fingerprint in ~/.synax/keys/.",
    ),
) -> None:
    """Verify the signatures on a manifest YAML file."""
    if not manifest_path.exists():
        _console.print(f"[red]✗[/red] Manifest file not found: {manifest_path}")
        raise typer.Exit(code=1)

    parsed = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    signatures = parsed.get("signatures", [])
    if not signatures:
        _console.print(f"[yellow]⚠[/yellow] {manifest_path} has no signatures to verify.")
        raise typer.Exit(code=1)

    # Reconstruct canonical bytes by stripping signatures and re-emitting.
    payload = {k: v for k, v in parsed.items() if k != "signatures"}
    canonical = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")

    from synax_sdk.signing import KeyStore  # local import; avoids loading at module init

    store = KeyStore.default()
    ok = 0
    fail = 0
    for sig in signatures:
        fingerprint = sig["key_fingerprint"]
        try:
            if public_key is not None:
                kp = load_keypair_from_file(public_key)
                if fingerprint_for_public_key(kp.public_key) != fingerprint:
                    _console.print(
                        f"[red]✗[/red] {fingerprint}: explicit --public-key doesn't match this signature's fingerprint."
                    )
                    fail += 1
                    continue
            else:
                kp = store.load(fingerprint)
            Verifier(keypair=kp).verify(canonical, sig["signature"])
            _console.print(f"[green]✓[/green] {fingerprint} ({sig['signer_type']})")
            ok += 1
        except SynaxSDKError as exc:
            _console.print(f"[red]✗[/red] {fingerprint}: {exc}")
            fail += 1

    if fail:
        raise typer.Exit(code=1)
    _console.print(f"[green]✓[/green] {ok} signature(s) verified.")


@app.command("info")
def skill_info() -> None:
    """Show metadata about the current skill."""
    root = _resolve_project_root()
    try:
        skill = load_skill_from_project(root)
    except SynaxSDKError as exc:
        _console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(code=1) from exc

    _console.print(f"[bold]{skill.name}[/bold] v{skill.version}")
    if skill.namespace:
        _console.print(f"  namespace: {skill.namespace}")
    _console.print(f"  display name: {skill.display_name}")
    _console.print(f"  description:  {skill.description}")
    _console.print(f"  execution:    {skill.execution_location}")
    if skill.capabilities:
        _console.print(f"  capabilities ({len(skill.capabilities)}):")
        for cap in skill.capabilities:
            _console.print(f"    • {cap}")
    if skill.secrets:
        _console.print(f"  secrets ({len(skill.secrets)}):")
        for sec in skill.secrets:
            _console.print(f"    • {sec.name} ({sec.type})")
    _console.print(f"  tools ({len(skill.tools)}):")
    for tool in skill.tools:
        _console.print(f"    • {tool.name} — {tool.description}")
