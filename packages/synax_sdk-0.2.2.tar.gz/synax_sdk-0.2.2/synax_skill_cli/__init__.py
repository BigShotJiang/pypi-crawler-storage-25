"""Synax CLI — the `synax` command for building, validating, and publishing skills."""
