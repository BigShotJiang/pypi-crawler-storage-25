"""Enable ``python -m synax_skill_cli``."""

from synax_skill_cli.main import app

if __name__ == "__main__":  # pragma: no cover
    app()
