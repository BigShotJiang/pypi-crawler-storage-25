"""Render a packaged template directory into a new skill project on disk.

Templates live in :mod:`synax_skill_cli.templates` as ``.tmpl`` files. The
renderer iterates a small manifest (source → destination pairs) and
applies :class:`string.Template` substitution to both the file contents
and the destination path so the skill module file can be named after the
``skill_name_snake`` variable.

``string.Template`` uses ``$variable`` / ``${variable}`` syntax. To
emit a literal ``$`` from a template, write ``$$``.
"""

from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from string import Template

DEFAULT_TEMPLATE = "default"

# Source path within ``synax_skill_cli/templates/<template_name>/`` →
# destination path (may itself reference $variables). Order matters only
# for deterministic output; rendering is independent per file.
TEMPLATE_MANIFEST: tuple[tuple[str, str], ...] = (
    ("pyproject.toml.tmpl", "pyproject.toml"),
    ("skill.py.tmpl", "${skill_name_snake}.py"),
    ("README.md.tmpl", "README.md"),
    (".gitignore.tmpl", ".gitignore"),
    (".synax-skillignore.tmpl", ".synax-skillignore"),
    ("tests/test_skill.py.tmpl", "tests/test_skill.py"),
    ("test_inputs/greet/case_basic.yaml.tmpl", "test_inputs/greet/case_basic.yaml"),
)


class TemplateError(Exception):
    """A template couldn't be rendered (missing variable, IO failure, etc.)."""


@dataclass(frozen=True)
class RenderedFile:
    """One file that ``render_template_dir`` wrote."""

    source: str  # relative path inside the template directory
    destination: Path  # absolute path written


def render_template_dir(
    *,
    output_dir: Path,
    variables: dict[str, str],
    template_name: str = DEFAULT_TEMPLATE,
) -> list[RenderedFile]:
    """Render every file from the named template tree into ``output_dir``.

    Args:
        output_dir: target directory. Will be created if missing. Refuses
            to overwrite if it already exists and is non-empty.
        variables: substitution map. Must contain every ``$name`` used by
            any template file or destination path; missing keys raise
            :class:`TemplateError`.
        template_name: subdirectory name under ``synax_skill_cli/templates/``.
            Currently only ``"default"`` ships.

    Returns:
        The list of files written, in manifest order.
    """
    if output_dir.exists() and any(output_dir.iterdir()):
        raise TemplateError(
            f"Output directory {output_dir} already exists and is not empty — refusing to overwrite."
        )

    base = resources.files("synax_skill_cli").joinpath("templates", template_name)
    if not base.is_dir():
        raise TemplateError(f"Template {template_name!r} is not bundled with the SDK.")

    output_dir.mkdir(parents=True, exist_ok=True)
    rendered: list[RenderedFile] = []
    for src, dst_template in TEMPLATE_MANIFEST:
        source = base.joinpath(*src.split("/"))
        try:
            template_text = source.read_text(encoding="utf-8")
        except FileNotFoundError as exc:
            raise TemplateError(
                f"Template file {template_name}/{src} is missing from the SDK package."
            ) from exc
        rendered_text = _substitute(template_text, variables, where=src)
        rel_destination = _substitute(dst_template, variables, where=f"{src} destination")
        target = output_dir / rel_destination
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered_text, encoding="utf-8")
        rendered.append(RenderedFile(source=src, destination=target))
    return rendered


def _substitute(text: str, variables: dict[str, str], *, where: str) -> str:
    try:
        return Template(text).substitute(variables)
    except KeyError as exc:
        raise TemplateError(
            f"Template {where}: missing required variable {exc.args[0]!r}."
        ) from exc
    except ValueError as exc:
        raise TemplateError(f"Template {where}: invalid placeholder ({exc}).") from exc
