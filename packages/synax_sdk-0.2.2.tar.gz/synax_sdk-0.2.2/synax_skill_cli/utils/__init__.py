"""Internal helpers for the synax CLI."""
