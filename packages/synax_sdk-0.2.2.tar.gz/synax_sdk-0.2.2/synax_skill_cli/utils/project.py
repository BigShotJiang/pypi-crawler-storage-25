"""Locate skill projects on disk and load their :class:`Skill` object.

A skill project is recognised by a ``pyproject.toml`` with a
``[tool.synax]`` section. The section's ``entry_point`` field names the
import path of the skill object, e.g.:

.. code-block:: toml

    [tool.synax]
    entry_point = "my_skill:skill"

Where ``my_skill.py`` sits at the project root and declares a module-level
``skill = Skill(...)``.
"""

from __future__ import annotations

import importlib
import sys
import tomllib
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from synax_sdk.errors import BuildError
from synax_sdk.skill import Skill


def find_project_root(start: Path | None = None) -> Path:
    """Walk up from ``start`` (defaults to cwd) until a skill project is found.

    A skill project is a directory containing a ``pyproject.toml`` whose
    parsed contents include a ``[tool.synax]`` table.

    Raises :class:`BuildError` if no such project is found before reaching
    the filesystem root.
    """
    start = (start or Path.cwd()).resolve()
    current = start
    while True:
        candidate = current / "pyproject.toml"
        if candidate.exists() and _has_synax_section(candidate):
            return current
        if current.parent == current:
            raise BuildError(
                f"No skill project found at or above {start}. "
                "A skill project's pyproject.toml must contain a [tool.synax] section. "
                "Run `synax skill init <name>` to scaffold one."
            )
        current = current.parent


def _has_synax_section(pyproject: Path) -> bool:
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return False
    return isinstance(data.get("tool", {}).get("synax"), dict)


def read_synax_config(project_root: Path) -> dict[str, Any]:
    """Return the parsed ``[tool.synax]`` table for ``project_root``.

    Raises :class:`BuildError` if the file is missing or malformed.
    """
    pyproject = project_root / "pyproject.toml"
    if not pyproject.exists():
        raise BuildError(f"pyproject.toml missing at {project_root}.")
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise BuildError(f"pyproject.toml at {project_root} is not valid TOML: {exc}") from exc
    section = data.get("tool", {}).get("synax")
    if not isinstance(section, dict):
        raise BuildError(
            f"pyproject.toml at {project_root} has no [tool.synax] section. "
            "Add one with at least an entry_point = 'module:variable' line."
        )
    return section


def load_skill_from_project(project_root: Path) -> Skill:
    """Import the skill module and return the :class:`Skill` instance.

    The ``entry_point`` is read from ``[tool.synax]`` in pyproject.toml
    and must be in ``module:variable`` form. The project root is added
    to ``sys.path`` for the duration of the import.
    """
    config = read_synax_config(project_root)
    entry_point = config.get("entry_point")
    if not isinstance(entry_point, str) or ":" not in entry_point:
        raise BuildError(
            f"[tool.synax].entry_point is missing or malformed in {project_root}/pyproject.toml. "
            "Expected 'module_name:variable_name' (e.g. 'my_skill:skill')."
        )
    module_name, _, var_name = entry_point.partition(":")
    module_name = module_name.strip()
    var_name = var_name.strip()
    if not module_name or not var_name:
        raise BuildError(
            f"entry_point {entry_point!r} must be 'module:variable', "
            "with non-empty module and variable names."
        )

    with _added_to_sys_path(project_root):
        try:
            module = importlib.import_module(module_name)
        except ModuleNotFoundError as exc:
            raise BuildError(
                f"Could not import {module_name!r} from {project_root}: {exc}. "
                "Check the entry_point in pyproject.toml."
            ) from exc
        # Pop the cached module so subsequent calls re-read the file from disk
        # (skill source may have changed between invocations, especially in
        # tests that rewrite the file).
        sys.modules.pop(module_name, None)

    if not hasattr(module, var_name):
        raise BuildError(
            f"Module {module_name!r} has no attribute {var_name!r}. "
            f"Make sure {module_name}.py defines '{var_name} = Skill(...)'."
        )
    obj = getattr(module, var_name)
    if not isinstance(obj, Skill):
        raise BuildError(
            f"{module_name}:{var_name} is a {type(obj).__name__}, not a synax_sdk.Skill instance."
        )
    return obj


@contextmanager
def _added_to_sys_path(path: Path) -> Any:
    """Prepend ``path`` to ``sys.path`` for the duration of the block."""
    abs_path = str(path.resolve())
    inserted = False
    if abs_path not in sys.path:
        sys.path.insert(0, abs_path)
        inserted = True
    try:
        yield
    finally:
        if inserted:
            try:
                sys.path.remove(abs_path)
            except ValueError:
                pass
