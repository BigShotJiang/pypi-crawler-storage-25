"""User + project CLI configuration.

Two config files are consulted, in order:

1. ``~/.synax/config.yaml`` — user-level defaults (default target URL,
   name of the env var holding the publish token).
2. ``<project_root>/.synax/config.yaml`` — per-project overrides.

The project file's keys override the user file's. Missing files yield
defaults. Tokens are *never* stored in either file — only the *name* of
the env var that holds the token (``default_auth_token_env``).
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import yaml

from synax_sdk.errors import SynaxSDKError

USER_CONFIG_PATH = Path.home() / ".synax" / "config.yaml"
PROJECT_CONFIG_SUBPATH = Path(".synax") / "config.yaml"

# Env var the CLI always checks for a publish token before falling back to config.
PUBLISH_TOKEN_ENV_VAR = "SYNAX_PUBLISH_TOKEN"


class ConfigError(SynaxSDKError):
    """A config file exists but is unreadable / malformed."""


@dataclass(frozen=True)
class CliConfig:
    """Resolved CLI config (after merging user + project files)."""

    default_target: str | None = None
    default_auth_token_env: str | None = None


def load_config(
    project_root: Path | None = None,
    *,
    user_path: Path = USER_CONFIG_PATH,
) -> CliConfig:
    """Load and merge user + project config.

    Args:
        project_root: directory whose ``.synax/config.yaml`` is the
            project override. If ``None``, only the user file is read.
        user_path: override for ``~/.synax/config.yaml`` (test seam).
    """
    user = _load_one(user_path)
    project: dict[str, Any] = {}
    if project_root is not None:
        project = _load_one(project_root / PROJECT_CONFIG_SUBPATH)

    merged = {**user, **project}
    return CliConfig(
        default_target=_str_or_none(merged.get("default_target")),
        default_auth_token_env=_str_or_none(merged.get("default_auth_token_env")),
    )


def save_config(config: CliConfig, path: Path) -> None:
    """Write ``config`` to ``path`` as YAML. Creates parent directories."""
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {k: v for k, v in asdict(config).items() if v is not None}
    path.write_text(yaml.safe_dump(payload, sort_keys=True), encoding="utf-8")


def resolve_auth_token(
    explicit_token: str | None,
    config: CliConfig,
    *,
    env: Mapping[str, str] | None = None,
) -> str | None:
    """Find the publish auth token using the documented priority.

    Order: explicit value (``--token``) → ``SYNAX_PUBLISH_TOKEN`` env var
    → the env var named by ``config.default_auth_token_env``. Returns
    ``None`` if none of the three resolve.
    """
    if explicit_token:
        return explicit_token
    environ: Mapping[str, str] = env if env is not None else os.environ
    direct = environ.get(PUBLISH_TOKEN_ENV_VAR)
    if direct:
        return direct
    if config.default_auth_token_env:
        return environ.get(config.default_auth_token_env) or None
    return None


def resolve_target(
    explicit_target: str | None,
    config: CliConfig,
) -> str | None:
    """``--target`` flag wins; otherwise fall back to ``config.default_target``."""
    if explicit_target:
        return explicit_target
    return config.default_target


def _load_one(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"Could not read config file {path}: {exc}") from exc
    try:
        data = yaml.safe_load(text) if text.strip() else {}
    except yaml.YAMLError as exc:
        raise ConfigError(f"Config file {path} is not valid YAML: {exc}") from exc
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ConfigError(
            f"Config file {path} must contain a YAML object at the top level, "
            f"got {type(data).__name__}."
        )
    return data


def _str_or_none(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None
