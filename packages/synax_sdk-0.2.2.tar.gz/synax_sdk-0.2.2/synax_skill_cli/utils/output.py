"""Shared CLI output helpers — honors a process-wide ``--quiet`` flag.

The root ``synax`` callback flips ``set_quiet(True)`` when ``--quiet/-q``
is on the command line; every subcommand uses :class:`QuietConsole`,
which transparently suppresses Rich banner output in that mode. Plain
``typer.echo(...)`` calls bypass the wrapper entirely, so commands can
still emit load-bearing output (fingerprints, registration IDs, JSON
payloads) under ``--quiet`` — that is the point of the flag.
"""

from __future__ import annotations

from typing import Any

from rich.console import Console

_quiet = False


def set_quiet(value: bool) -> None:
    """Set the process-wide quiet flag. Called once from the root callback."""
    global _quiet
    _quiet = value


def is_quiet() -> bool:
    """Return whether quiet mode is currently active."""
    return _quiet


class QuietConsole:
    """Drop-in replacement for ``rich.console.Console`` that respects quiet mode.

    ``print(...)`` is a no-op when quiet mode is on; every other Console
    attribute proxies through to a real underlying ``Console``. Commands
    use this for banner / status output; load-bearing output goes through
    ``typer.echo``.
    """

    def __init__(self) -> None:
        self._inner = Console()

    def print(self, *args: Any, **kwargs: Any) -> None:
        if _quiet:
            return
        self._inner.print(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        # Fall through to the underlying Console for any non-print attribute
        # (e.g. ``.input``, ``.status``, ``.is_terminal``).
        return getattr(self._inner, name)
