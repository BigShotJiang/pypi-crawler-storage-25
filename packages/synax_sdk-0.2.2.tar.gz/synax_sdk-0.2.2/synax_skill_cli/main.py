"""Entry point for the ``synax`` CLI.

Top-level Typer app + subcommand wiring. Real command implementations live
in :mod:`synax_skill_cli.commands.*`; this module just stitches them
together and provides global flags (``--version``).
"""

from __future__ import annotations

import typer

from synax_sdk.version import __version__
from synax_skill_cli.commands import keys as keys_commands
from synax_skill_cli.commands import skill as skill_commands
from synax_skill_cli.utils.output import set_quiet

app = typer.Typer(
    name="synax",
    help="Synax SDK — build, validate, sign, and publish skills.",
    add_completion=False,
)

app.add_typer(skill_commands.app, name="skill")
app.add_typer(keys_commands.app, name="keys")

# ----- config (placeholder until Milestone 5) ----------------------------------
config_app = typer.Typer(
    help="Read and write CLI configuration.",
    no_args_is_help=True,
)
app.add_typer(config_app, name="config")


@config_app.command("get")
def config_get(key: str = typer.Argument(..., help="Config key.")) -> None:
    """Read a value from ``~/.synax/config.yaml``."""
    typer.echo(
        f"Not yet implemented — coming in Milestone 5 (publishing) for {key!r}. " "[Milestone 5]"
    )


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key."),
    value: str = typer.Argument(..., help="Config value."),
) -> None:
    """Write a value to ``~/.synax/config.yaml``."""
    typer.echo(
        f"Not yet implemented — coming in Milestone 5 (publishing) for {key!r}={value!r}. "
        "[Milestone 5]"
    )


# ----- root callback -----------------------------------------------------------
@app.callback(invoke_without_command=True)
def _root_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show the SDK version and exit.",
        is_eager=True,
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress banner / status output. Load-bearing output (fingerprints, "
        "registration IDs, JSON payloads) still prints — useful in CI.",
    ),
) -> None:
    """Synax SDK CLI."""
    set_quiet(quiet)
    if version:
        typer.echo(f"synax-sdk {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


if __name__ == "__main__":  # pragma: no cover
    app()
