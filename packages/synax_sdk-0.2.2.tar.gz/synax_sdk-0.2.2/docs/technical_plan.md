# Synax Python SDK — Technical Plan

**Version:** 0.1
**Status:** Pre-implementation design
**Audience:** Engineers (human and AI assistants like Claude Code)

---

## How to Use This Document

This document captures the architectural design and engineering conventions for the Synax Python SDK. It complements `build_plan.md` (which says what to build, in what order) by explaining the design decisions and structures.

Read this after `README.md`, `parent_platform_context.md`, and `manifest_spec.md`. Read it before starting Milestone 3 of `build_plan.md` where the design choices start to matter.

---

## Table of Contents

1. [Design Principles](#1-design-principles)
2. [Core Abstractions](#2-core-abstractions)
3. [Package Structure](#3-package-structure)
4. [The Skill Definition API](#4-the-skill-definition-api)
5. [The Runtime API](#5-the-runtime-api)
6. [Manifest Generation](#6-manifest-generation)
7. [Signing and Verification](#7-signing-and-verification)
8. [Local Testing Infrastructure](#8-local-testing-infrastructure)
9. [The CLI](#9-the-cli)
10. [Engineering Conventions](#10-engineering-conventions)
11. [Open Design Questions](#11-open-design-questions)

---

## 1. Design Principles

These principles inform every design decision in the SDK. When tradeoffs arise, refer back here.

### 1.1 Skills should look like normal Python

Skill authors are Python developers. The SDK should feel like writing normal Python code, not like writing into a framework. Decorators where they help, type hints throughout, async/await for I/O. Authors should be able to use any Python tooling they're used to (pytest, mypy, ruff, debugger).

### 1.2 Convention over configuration

A skill following common patterns should require minimal configuration. Default values should make sense for typical cases. Magic that simplifies the common case is acceptable; magic that hides important behavior is not.

### 1.3 Fail fast at build time

Errors in a skill's structure (missing capabilities, invalid signatures, malformed parameters) should be caught at build time, not at runtime in production. The SDK validates aggressively before allowing publish.

### 1.4 The manifest is derived, not authored

Skill authors write Python code. The SDK derives the manifest from that code. Authors don't write YAML by hand. This eliminates a class of "code and manifest drift" bugs.

### 1.5 Local development without a platform

A skill should be testable locally without a running Synax platform. The SDK provides a mock platform (in-memory secrets, in-memory logger, in-memory metrics) for development and testing.

### 1.6 The SDK does not implement the sandbox

Skills run in a sandbox at execution time, but the platform enforces it, not the SDK. The SDK trusts the developer not to write malicious code; the platform protects against actually-malicious or accidentally-overreaching code at runtime.

### 1.7 Signed artifacts are immutable

Once a skill is built and signed, modifying it invalidates the signature. The SDK enforces this — you cannot publish an artifact whose content doesn't match its hash.

### 1.8 Backwards compatibility within major versions

After 1.0, the SDK's public API doesn't break within a major version. Skills built against SDK 1.x continue to work with SDK 1.y for any y > x. Schema version is tracked separately and may evolve faster.

---

## 2. Core Abstractions

### 2.1 The `Skill` class

The central object. Represents a skill being authored. Has metadata, capabilities, tools, and the ability to be built into a manifest.

```python
class Skill:
    name: str
    version: str
    description: str
    display_name: str | None
    namespace: str | None
    capabilities: list[str]
    execution_location: ExecutionLocation
    secrets: list[SecretDeclaration]
    dependencies: list[SkillDependency]
    metadata: SkillMetadata
    tools: list[Tool]  # populated by the @skill.tool decorator
```

A skill author instantiates `Skill(...)` at module scope, decorates functions with `@skill.tool(...)`, and exports the skill. The CLI tools and runtime find the skill via the manifest's `entry_point`.

### 2.2 The `@skill.tool` decorator

Declares a function as a tool exposed by the skill. The decorator inspects the function signature, extracts parameter types via type hints, registers it on the skill.

```python
@skill.tool(description="...")
async def my_tool(repo: str, pr_number: int) -> dict:
    ...
```

The decorator returns the original function unchanged (so the skill author can still call it directly during testing). The registration happens as a side effect.

### 2.3 The runtime context

Skills have access to platform capabilities through a thread-local (or async-local) context:

```python
from synax_sdk import secrets, logger, metrics, ctx

async def my_tool(...):
    token = await secrets.get("GITHUB_TOKEN")
    logger.info("Processing")
    metrics.counter("calls").inc()
    user = ctx.invoker
```

These objects are stubs/mocks in local development and real implementations when the skill executes inside the platform's sandbox.

### 2.4 The manifest

A typed Python representation of the manifest schema. Constructed by the build tool from a `Skill` object. Serialized to YAML or JSON for distribution.

```python
@dataclass
class Manifest:
    schema_version: str
    name: str
    version: str
    display_name: str
    description: str
    implementation: Implementation
    tools: list[ToolManifest]
    capabilities: list[str]
    execution_location: str
    secrets: list[SecretManifest]
    dependencies: list[DependencyManifest]
    metadata: ManifestMetadata
    signatures: list[Signature]
```

---

## 3. Package Structure

```
synax-sdk-python/
├── README.md
├── LICENSE                       # Apache 2.0
├── CLAUDE.md                     # For Claude Code
├── pyproject.toml
├── uv.lock
├── docs/                         # Documentation
│   ├── README.md
│   ├── parent_platform_context.md
│   ├── manifest_spec.md
│   ├── build_plan.md
│   └── technical_plan.md
├── synax_sdk/                    # The main package
│   ├── __init__.py               # Public API exports
│   ├── skill.py                  # Skill class, @tool decorator
│   ├── tool.py                   # Tool class, parameter inspection
│   ├── manifest.py               # Manifest dataclasses, validation, serialization
│   ├── runtime/                  # Runtime API for skills
│   │   ├── __init__.py
│   │   ├── secrets.py            # secrets.get(...)
│   │   ├── logger.py             # logger.info/warning/error
│   │   ├── metrics.py            # metrics.counter, metrics.gauge
│   │   ├── context.py            # ctx (run_id, workspace_id, invoker)
│   │   ├── platform.py           # platform API (memory, transcripts) for advanced use
│   │   └── _backends/            # Different backend implementations
│   │       ├── __init__.py
│   │       ├── mock.py           # In-memory backend for testing
│   │       └── platform.py       # Real backend used when running inside Synax
│   ├── signing.py                # Ed25519 signing and verification
│   ├── packaging.py              # Build the implementation artifact (tar.gz)
│   ├── publishing.py             # HTTP client for the platform's publish API
│   ├── validation.py             # Manifest validation against schema
│   ├── schema/                   # JSON Schema files (vendored)
│   │   ├── manifest_v1_0.json
│   │   └── __init__.py
│   ├── errors.py                 # Custom exception hierarchy
│   └── version.py                # SDK version
├── synax_skill_cli/              # The `synax` CLI
│   ├── __init__.py
│   ├── __main__.py               # python -m synax_skill_cli
│   ├── main.py                   # CLI entry point (typer app)
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── init.py               # synax skill init
│   │   ├── validate.py           # synax skill validate
│   │   ├── test.py               # synax skill test
│   │   ├── build.py              # synax skill build
│   │   ├── publish.py            # synax skill publish
│   │   └── keys.py               # synax keys generate/list/import
│   ├── templates/                # Project templates for skill init
│   │   └── default/
│   │       ├── pyproject.toml.tmpl
│   │       ├── skill.py.tmpl
│   │       ├── README.md.tmpl
│   │       └── tests/
│   │           └── test_skill.py.tmpl
│   └── utils/
│       ├── __init__.py
│       └── project.py            # Finding skill projects, loading them
├── tests/                        # SDK's own tests
│   ├── unit/
│   ├── integration/
│   ├── fixtures/
│   │   └── sample_skills/        # Test skills
│   └── conftest.py
└── .github/
    └── workflows/                # CI
        ├── ci.yml
        └── publish.yml           # PyPI release on tag
```

### 3.1 Two top-level packages

`synax_sdk` is the library that skill authors import. `synax_skill_cli` is the CLI. They're separate because:

- Some users (advanced) will use `synax_sdk` directly for building and publishing skills programmatically (CI pipelines, etc.)
- The CLI depends on heavier dependencies (typer, rich) that library users shouldn't have to install
- It makes the SDK API surface clearer — you import from `synax_sdk`, you invoke `synax` from the shell

Both packages are installed by `pip install synax-sdk`. The `synax` command is registered as a console script via `pyproject.toml`.

### 3.2 Why not a single package?

A single package would conflate "the library users import" with "the CLI tooling." Keeping them separate makes the public API clearer and reduces the dependency footprint for library use cases.

---

## 4. The Skill Definition API

### 4.1 Creating a Skill

```python
from synax_sdk import Skill

skill = Skill(
    name="github-pr-summary",                # required
    version="1.0.0",                         # required
    description="Fetch and summarize PRs",   # required
    display_name="GitHub PR Summary",        # optional, derived from name if absent
    namespace=None,                          # optional
    capabilities=[                           # optional, default []
        "network:api.github.com",
        "secrets:GITHUB_TOKEN",
    ],
    execution_location="either",             # optional, default "either"
    secrets=[                                # optional, default []
        Secret(
            name="GITHUB_TOKEN",
            type="oauth_token",
            description="GitHub OAuth token with repo:read scope",
            scope_required="repo:read",
        ),
    ],
    dependencies=[],                         # optional, default []
    metadata=SkillMetadata(                  # optional, default empty
        category="developer_tools",
        tags=["github"],
        homepage="https://...",
        source="https://github.com/...",
        license="Apache-2.0",
    ),
)
```

The `Skill` constructor validates everything at creation time:

- `name` is slug-formatted
- `version` is valid semver
- Capabilities follow the `<type>:<specifier>` format
- Declared secrets have corresponding `secrets:<name>` in capabilities
- Tags and other metadata are normalized

Errors raise `SkillDefinitionError` with helpful messages.

### 4.2 Defining tools

```python
@skill.tool(description="Fetch a GitHub PR and return a summary")
async def summarize_pr(repo: str, pr_number: int) -> dict:
    """
    Args:
        repo: Repository in format owner/name
        pr_number: Pull request number
    """
    ...
```

The decorator:

1. Inspects the function signature (parameters, types, defaults)
2. Inspects the docstring (for parameter descriptions)
3. Builds a `Tool` object
4. Registers it on the skill
5. Returns the function unchanged (so it can still be called directly)

**Parameter inspection rules:**

- Parameter type annotations are required (mypy strict in the SDK enforces this for the SDK; we should validate it for skill authors too)
- The first positional `self` or `cls` parameter is allowed (for class-based tools, though this is unusual)
- `*args` and `**kwargs` are not allowed (tools have explicit parameters)
- Default values are recorded in the manifest

**Type mappings to JSON Schema:**

```
str          → {type: "string"}
int          → {type: "integer"}
float        → {type: "number"}
bool         → {type: "boolean"}
list[X]      → {type: "array", items: <X schema>}
dict[str, X] → {type: "object", additionalProperties: <X schema>}
Optional[X]  → <X schema with "nullable": True> or anyOf with null
Literal[...] → {type: "string", enum: [...]} (or appropriate type)
@dataclass   → object schema derived from the dataclass fields
pydantic     → pydantic's own schema generation if pydantic available
```

**Docstring parsing:**

The SDK supports Google-style and reStructuredText-style docstrings for extracting parameter descriptions:

```python
@skill.tool(description="Fetch a PR")
async def summarize_pr(repo: str, pr_number: int) -> dict:
    """Fetch and summarize a GitHub PR.

    Args:
        repo: Repository in format owner/name
        pr_number: Pull request number to fetch
    """
```

Parameter descriptions in the docstring are added to the JSON Schema. If both decorator and docstring provide descriptions, the docstring wins (more local, more likely to be kept up to date).

### 4.3 Return types

```python
@skill.tool(description="...")
async def my_tool(...) -> dict:  # any specific dict shape
    ...

# Or with a typed dict:
class PRSummary(TypedDict):
    title: str
    summary: str
    files_changed: int

@skill.tool(description="...")
async def my_tool(...) -> PRSummary:
    ...

# Or with a dataclass:
@dataclass
class PRSummary:
    title: str
    summary: str
    files_changed: int

@skill.tool(description="...")
async def my_tool(...) -> PRSummary:
    ...
```

The SDK derives the return schema from the type. The platform validates returns against the schema (when validation is enabled at install time).

### 4.4 Async vs sync tools

Tools should be `async def` by default. Synchronous tools are allowed but discouraged — most useful work involves I/O and benefits from async.

The SDK detects whether a tool is sync or async and handles both correctly. Internally, sync tools are wrapped to run in a thread pool when invoked.

---

## 5. The Runtime API

The runtime API is what skills use during execution. The same code runs in production (where it calls real platform services) and in local testing (where it calls in-memory mocks).

### 5.1 Secrets

```python
from synax_sdk import secrets

token = await secrets.get("GITHUB_TOKEN")
```

Behavior:

- In local development: looks in `.env` files, environment variables, or a configured local secrets file
- In testing: returns values from the mock platform's secret store
- In production: calls the platform's secret API, which audits the access

**The skill never sees raw API tokens for the platform itself.** Secrets the skill requests are about external services (GitHub, Slack, etc.).

### 5.2 Logger

```python
from synax_sdk import logger

logger.debug("Detailed info")
logger.info("Normal operation")
logger.warning("Something noteworthy")
logger.error("Something went wrong")
logger.exception("Exception caught")  # includes traceback
```

Structured logging:

```python
logger.info("Processed PR", extra={
    "pr_number": 42,
    "files_changed": 15,
})
```

Logs flow into the platform's observability when running in production; flow to stderr in local development.

### 5.3 Metrics

```python
from synax_sdk import metrics

# Counters
metrics.counter("github_api_calls").inc()
metrics.counter("github_api_calls").inc(by=5)

# Counters with labels
metrics.counter("github_api_calls", labels={"endpoint": "/pulls"}).inc()

# Gauges
metrics.gauge("active_workers").set(42)

# Histograms
metrics.histogram("request_duration_ms").observe(123.4)
```

Metrics are recorded against the skill's namespace automatically. Platform-level aggregation happens at execution time.

### 5.4 Context

```python
from synax_sdk import ctx

ctx.run_id          # UUID of the current run
ctx.workspace_id    # UUID of the workspace
ctx.invoker         # InvokerInfo: type ('user'|'bot'), id, name
ctx.bot_id          # UUID of the bot if invoker is a bot, else None
ctx.user_id         # UUID of the user if invoker is a user (directly or via bot owner)
```

This is provided by the platform at execution time. In local testing, the mock platform provides synthetic context.

### 5.5 Platform API (advanced)

For skills that need to read or write platform data (rare but supported):

```python
from synax_sdk.runtime import platform

# Read recent transcript messages from the channel
messages = await platform.transcripts.recent(channel_id=ctx.channel_id, limit=20)

# Read channel memory state
memory = await platform.memory.state(channel_id=ctx.channel_id)

# Write a memory event
await platform.memory.record_event(
    channel_id=ctx.channel_id,
    event_type="note_added",
    payload={"content": "Important context"},
)
```

These require corresponding capabilities (`platform:transcripts_read`, `platform:memory_read`, `platform:memory_write`). The platform enforces capability checks at runtime.

Most skills don't need this. It's available for skills that are deeply integrated with platform behavior (e.g., skills that manage channel state, skills that read prior conversation context).

---

## 6. Manifest Generation

The build process (Milestone 4 in `build_plan.md`) converts a Python skill module into a manifest.

### 6.1 Build flow

```
1. Load the skill module (Python import)
2. Find the Skill object (default: module-level variable named "skill")
3. Collect declared tools, capabilities, secrets, metadata
4. Compute SHA-256 of the implementation artifact
5. Construct the Manifest dataclass
6. Validate against the schema
7. Compute canonical JSON form
8. Sign with the author's Ed25519 key
9. Insert the signature
10. Serialize to YAML for distribution
```

### 6.2 Implementation artifact

The implementation artifact is a tar.gz archive containing:

- `pyproject.toml` — project metadata, dependencies
- The skill's Python module(s)
- README.md (if present)
- Tests (if present, optional)
- A `requirements.txt` with pinned dependencies (generated by the build)

What's excluded:

- The SDK itself (it's installed by the platform at execution time)
- Tests beyond the skill's own
- Development tooling configuration (linters, formatters)
- IDE files (`.vscode/`, etc.)
- VCS files (`.git/`)
- Cache directories (`__pycache__/`, `.pytest_cache/`)

The exclusions follow a `.synax-skillignore` file (analogous to `.gitignore`). Default exclusions are sensible; authors can override.

### 6.3 Computing the hash

The implementation hash is the SHA-256 of the tar.gz archive's bytes. Computing it requires the archive to be deterministic (same content → same hash):

- File order in the archive is sorted lexicographically
- Timestamps are zeroed (or set to a fixed value)
- File permissions are normalized
- Owner/group fields are zeroed

This is the same problem `tarfile` and reproducible builds solve. The SDK uses appropriate tar flags to produce deterministic archives.

### 6.4 Manifest serialization

The YAML serialization is for human reading. The JSON serialization is for signing.

When the SDK saves a manifest to disk, it produces:

```
build/
├── manifest.yaml          # YAML form
├── manifest.json          # JSON form
├── manifest.canonical     # Canonical JSON used for signing
├── implementation.tar.gz  # The artifact
└── signed_bundle/         # What gets uploaded
    ├── manifest.yaml      # Manifest with signatures embedded
    └── implementation.tar.gz
```

The publish step uploads the bundle.

---

## 7. Signing and Verification

### 7.1 Key generation

The first time a developer uses the SDK, they generate a signing key:

```bash
synax keys generate
synax keys generate --name "ci-bot" --set-default
synax keys generate --output-dir /tmp/sandbox-keys
```

This:

1. Generates an Ed25519 keypair using PyNaCl.
2. Computes the fingerprint — `sha256:<64-hex>` over the public-key bytes.
3. Writes a single JSON key file at `~/.synax/keys/sha256_<hex>.key` (mode `0o600`
   on POSIX) containing both halves plus optional metadata (`created_at`, optional
   `name`). The file format is documented at
   `KEY_FILE_VERSION = 1` in `synax_sdk.signing` and is forward-compatible:
   unknown fields are ignored on load, so older SDK versions can still read keys
   written by newer ones.
4. Updates `~/.synax/keys/default` (a small JSON pointer file) if no default
   was previously set, or if `--set-default` was passed.

The developer can have multiple keys (different identities, different namespaces,
key rotation). Keys are addressed throughout the SDK and CLI by their full
fingerprint (`sha256:<64-hex>`); the CLI also accepts any unambiguous hex prefix
(git-short-SHA model).

There is no separate `index.yaml` or `<key_id>.key.pub` file — the per-key JSON
file is the single source of truth. Public-only copies are produced on demand by
`synax keys export <fingerprint> --output <path>` (or by redirecting the
non-TTY stdout of `synax keys export`).

### 7.2 Signing

At build time, the SDK signs the manifest:

```bash
synax skill build --key=<key_fingerprint>
```

If `--key` is omitted, the SDK uses the default key from `~/.synax/keys/default`.

The signature:

1. Constructs the canonical JSON form of the manifest (excluding `signatures` field)
2. Signs those bytes with the private key
3. Encodes the signature as base64
4. Inserts a `Signature` object into the manifest

### 7.3 Verification

At any point, the SDK can verify a manifest's signatures:

```bash
synax skill verify <manifest_file>
```

This:

1. Parses the manifest
2. For each signature in `signatures`:
   - Looks up the public key by fingerprint
   - Reconstructs the canonical JSON form
   - Verifies the signature against the public key
3. Reports success or failure with details

### 7.4 Key management

The SDK provides commands for managing keys:

```bash
synax keys generate                    # generate a new keypair
synax keys generate --name X           # ...with a human-readable label stored in the key file
synax keys generate --set-default      # ...and overwrite the current default
synax keys generate --output-dir DIR   # ...writing into DIR instead of ~/.synax/keys/

synax keys list                        # list known keys (rich table)
synax keys list --json                 # ...as a JSON array for scripting

synax keys show <fp>                   # detailed view of a single key
synax keys show <fp> --json            # ...as JSON

synax keys export <fp>                 # export the public key
                                       #   - TTY stdout:  human-readable summary
                                       #   - non-TTY stdout: pub-file JSON (pipeable)
synax keys export <fp> --output PATH   # ...write pub-file JSON to PATH

synax keys import <pub_file>           # import a public key (for verification only)
synax keys set-default <fp>            # set the default signing key
synax keys delete <fp>                 # delete a key; --force skips confirmation
                                       #   and is required for deleting the default
```

`<fp>` is the full `sha256:<64-hex>` fingerprint, or any unambiguous hex prefix
(matched against all keys in the store; ambiguity is rejected with a clear
"prefix X matches: a, b" message).

Keys are stored at `~/.synax/keys/`. The directory has mode `700` (private)
where the platform supports POSIX permissions. Private keys are mode `600`.

### 7.5 Trusted Publisher key registration

For developers who want to be Trusted Publishers (and have their namespace
recognized by the platform), they need to register their public key with the
platform:

```bash
# Register the default key in the local store under a namespace:
synax keys register \
  --target https://synax.platform.com \
  --namespace mycompany

# Register a specific key by fingerprint (any unambiguous prefix works):
synax keys register \
  --target https://synax.platform.com \
  --namespace mycompany \
  --key sha256:abc1234

# Register a public key that isn't in the local store (e.g. from `keys export`):
synax keys register \
  --target https://synax.platform.com \
  --namespace mycompany \
  --public-key-file /tmp/ci.pub \
  --label "synax-skills CI key"
```

This uploads the public key to the platform as part of becoming a trusted
publisher. The platform admin approves the registration. After approval,
manifests signed with this key are recognized as authoritative for the
`mycompany/` namespace.

Flags:

- `--target` — platform URL (falls back to `default_target` in config).
- `--namespace` — required; the namespace to claim.
- `--key` / `-k` — fingerprint (full or unambiguous prefix) of a key in the
  local store. Mutually exclusive with `--public-key-file`.
- `--public-key-file` — path to a JSON pub-file produced by `synax keys export`.
  Mutually exclusive with `--key`.
- `--label` — optional human-readable label sent to the platform alongside the
  registration. Older platform versions ignore unknown fields.
- `--token` — auth token; falls back to `SYNAX_PUBLISH_TOKEN`, then config.

---

## 8. Local Testing Infrastructure

### 8.1 The mock platform

When skills run locally (during development or testing), they need a stand-in for the platform's runtime API. The SDK provides this.

```python
from synax_sdk.testing import MockPlatform

async def test_my_skill():
    mock = MockPlatform()
    mock.secrets.set("GITHUB_TOKEN", "fake-token-for-testing")
    mock.context.set(run_id="test-run", workspace_id="test-ws", ...)

    with mock.activate():
        # Inside this block, all runtime API calls go to the mock
        result = await summarize_pr(repo="owner/name", pr_number=42)

    # Inspect what the skill did
    assert mock.logger.calls[0].level == "INFO"
    assert mock.metrics.counters["github_api_calls"].value == 1
    assert mock.secrets.accesses == ["GITHUB_TOKEN"]
```

The mock platform is in-memory, fast, fully introspectable. Tests can verify the skill behaved correctly.

### 8.2 The `synax skill test` command

A higher-level testing tool that:

1. Loads the skill from the current project
2. Sets up a mock platform with sample data
3. Runs each declared tool against test inputs
4. Reports successes and failures

```bash
synax skill test
```

Test inputs come from a `test_inputs/` directory:

```
test_inputs/
├── summarize_pr/
│   ├── case_basic.yaml          # Input parameters
│   ├── case_invalid_repo.yaml   # Expected to error
│   └── secrets.yaml             # Mock secret values
```

Each test case YAML:

```yaml
input:
  repo: "owner/name"
  pr_number: 42
expected_output_schema:
  type: object
  properties:
    title: {type: string}
expected_capabilities_used:
  - "secrets:GITHUB_TOKEN"
  - "network:api.github.com"
```

### 8.3 Integration with pytest

Skill authors can also write tests with pytest using the mock platform:

```python
import pytest
from synax_sdk.testing import MockPlatform
from my_skill import summarize_pr

@pytest.fixture
def mock_platform():
    return MockPlatform()

async def test_summarize_pr_happy_path(mock_platform):
    mock_platform.secrets.set("GITHUB_TOKEN", "test-token")

    with mock_platform.activate():
        result = await summarize_pr(repo="owner/name", pr_number=42)

    assert "title" in result
    assert mock_platform.logger.calls
```

The SDK provides pytest fixtures (`synax_mock_platform`, `synax_skill_under_test`) to make this ergonomic.

---

## 9. The CLI

The `synax` command is the primary interface for most developers.

### 9.1 Command structure

```
synax
├── skill
│   ├── init <name>            # Scaffold a new skill
│   ├── validate               # Validate manifest of current project
│   ├── test                   # Run skill tests
│   ├── build                  # Build the signed artifact
│   ├── publish                # Publish to a platform
│   ├── verify <file>          # Verify signatures of a manifest
│   └── info                   # Show info about the current skill
├── keys
│   ├── generate               # Generate a signing keypair
│   ├── list                   # List known keys
│   ├── export <fingerprint>   # Export public key
│   ├── import <file>          # Import a public key
│   ├── set-default <fp>       # Set default signing key
│   └── register               # Register public key with platform
└── config
    ├── set <key> <value>      # Set a config value
    └── get <key>              # Get a config value
```

### 9.2 Implementation with typer

The CLI uses `typer` for clean modern Python CLI:

```python
import typer

app = typer.Typer()
skill_app = typer.Typer()
keys_app = typer.Typer()

app.add_typer(skill_app, name="skill")
app.add_typer(keys_app, name="keys")

@skill_app.command("init")
def skill_init(name: str = typer.Argument(..., help="Skill name")):
    """Scaffold a new Synax skill project."""
    ...

@skill_app.command("validate")
def skill_validate():
    """Validate the current skill project's manifest."""
    ...
```

### 9.3 Output formatting

Use `rich` for terminal output: colored, tables, progress indicators. Skill build and publish should show progress (which can take a few seconds).

For machine consumption (CI pipelines), respect a `--json` flag that emits structured output instead.

### 9.4 Configuration

CLI configuration lives at `~/.synax/config.yaml`:

```yaml
default_key: <fingerprint>
default_target: https://synax.mycompany.com
default_auth_token: <env_var_name>  # Reference to env var, not the value itself
```

Per-project overrides at `.synax/config.yaml` in the project root.

---

## 10. Engineering Conventions

These conventions match the platform's where applicable and are slightly relaxed where the SDK's context differs.

### 10.1 Python conventions

- **Python version:** 3.14 (matching platform)
- **Style:** Black formatting, isort imports, ruff linting
- **Type hints:** Required everywhere. mypy strict.
- **Docstrings:** Google style on public APIs.
- **Async:** Default to async for I/O operations. Sync is acceptable for pure logic.

### 10.2 Package management

- **uv** for managing the development environment
- Dependencies declared in `pyproject.toml`
- Lock file (`uv.lock`) committed to the repo

### 10.3 Public API discipline

Anything in `synax_sdk.__init__.py` is the public API. Anything not exported is internal (subject to change).

```python
# synax_sdk/__init__.py
from synax_sdk.skill import Skill, tool
from synax_sdk.runtime import secrets, logger, metrics, ctx
from synax_sdk.errors import SkillDefinitionError, SkillValidationError

__all__ = [
    "Skill",
    "tool",
    "secrets",
    "logger",
    "metrics",
    "ctx",
    "SkillDefinitionError",
    "SkillValidationError",
]
```

When considering breaking the public API:
- Pre-1.0: allowed within minor versions but documented in changelog
- Post-1.0: only in major version bumps with deprecation warnings during the prior major

### 10.4 Testing

- **pytest** with `pytest-asyncio` for async tests
- Coverage target: 90% (higher than the platform because the SDK is more constrained)
- Unit tests for every module
- Integration tests for the CLI (using `typer.testing.CliRunner`)
- Integration tests for the publish flow (against a mock platform server)

### 10.5 Documentation

- **API documentation:** auto-generated from docstrings using mkdocstrings or pdoc
- **User guides:** written prose in `docs/`
- **README** prominently shows the canonical example

### 10.6 Security

- **Never include the SDK's signing keys in any artifact**
- **Validate all inputs** at API boundaries (deserialization, network responses)
- **Use defusedxml** if any XML parsing is needed (unlikely)
- **Pin all dependencies** in the lock file
- **Audit dependencies** with `pip-audit` in CI

### 10.7 Error messages

Errors should be informative and actionable. Bad:

```
SkillDefinitionError: invalid name
```

Good:

```
SkillDefinitionError: Invalid skill name "GitHub-PR" — names must be lowercase
slug format (a-z, 0-9, hyphens). Did you mean "github-pr"?
```

### 10.8 Logging

The SDK itself uses Python's standard logging. The skill author can configure verbosity:

```bash
SYNAX_SDK_LOG=debug synax skill build
```

### 10.9 What to avoid

- **Don't depend on the platform's database schema** — that's coupling we don't want
- **Don't import from the platform repo** — they're separate codebases
- **Don't make the runtime API mutable** — `secrets.get` not `secrets["X"] = ...`
- **Don't reach into the user's Python environment** — skills run in their own envs
- **Don't add features the user didn't ask for** — keep the public API minimal

---

## 11. Open Design Questions

These are questions to revisit during implementation. They don't block starting but should be resolved before the SDK ships 1.0.

### 11.1 How does a skill express version compatibility with the SDK?

A skill built with SDK 0.1 will work with SDK 0.2 mostly, but eventually compatibility matters. Should manifests declare `sdk_version` they were built with? The platform checks this at install time?

Tentative answer: yes. Add `metadata.sdk_version` to the manifest. Platform reads it. SDK records its version automatically at build time.

### 11.2 Tool versioning within a skill

If a skill v1.0 exposes a tool `foo`, and v2.0 changes `foo`'s signature, that's a breaking change. Should tools have their own versions?

Tentative answer: no. Tools are versioned with their skill. Skills should use semver — breaking changes go in major versions. This is simpler than per-tool versioning.

### 11.3 Streaming tool responses

Some tools might produce streaming output (e.g., a tool that fetches a large file in chunks). Should the SDK support tools that return async generators?

Tentative answer: defer. v1 supports return-once tools. Streaming tools are a v2 feature when there's demand.

### 11.4 Sync skill execution support

Should the SDK support skills that are entirely synchronous (no async)? Some authors prefer sync code.

Tentative answer: yes, but de-emphasized in documentation. Async-first is the SDK's posture; sync works but isn't the recommended path.

### 11.5 Skill composition

Can a skill depend on another skill and invoke it? The schema allows `dependencies`, but the runtime mechanism isn't specified.

Tentative answer: defer to v0.2. v1 supports declared dependencies (the platform enforces them at install time), but runtime composition (skill A invoking skill B) isn't supported yet.

### 11.6 Skill state management

Can skills have state that persists across invocations? E.g., a skill that maintains a connection pool, a cache, etc.

Tentative answer: no per-skill state by default. Each invocation is independent. Skills that need persistent state must use the platform's secrets or external storage. This is a deliberate simplification — adding state later is easier than removing it.

### 11.7 Skill testing against real platform instances

Should `synax skill test` be able to run against a real platform instance (for integration testing)?

Tentative answer: yes, but as a separate flag (`synax skill test --target https://...`). Default is local-only testing.

---

*End of technical plan*
