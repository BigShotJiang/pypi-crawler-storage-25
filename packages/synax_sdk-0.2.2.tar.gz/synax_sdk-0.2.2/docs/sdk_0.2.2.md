# Synax SDK v0.2.2 — Release Retrospective

**Tag:** `v0.2.2`
**Date:** 2026-05-20
**Branch flow:** dev (TestPyPI) → main (PyPI)
**Predecessor:** v0.2.1 (2026-05-18) — pipeline polish, OIDC validated on PyPI
**Successor:** TBD (v0.3.0 context envelope)

---

## TL;DR

v0.2.2 closes a batch of CLI gaps that operators ran into during the
`synergentic/synax-skills` repo's CI signing-key setup. No SDK Python-import
behavior changes from v0.2.1; the surface that grows is the `synax` CLI plus
two additive Python API additions (`KeyPair.name`,
`PublishClient.register_key(label=...)`). 734 tests pass, mypy strict / ruff /
black clean.

The release is bug-fix-flavored — it implements documented behavior that
wasn't actually shipping. Patch-version is appropriate.

---

## How We Got Here

During CI setup in the sister repo, the operator ran:

```bash
synax keys generate --name "synax-skills-ci"
```

…and got `No such option: --name`. The documentation referenced the flag but
the CLI didn't accept it. Rather than work around it one flag at a time, we
ran a comprehensive audit of every `synax` command, compared the actual
flags against what `docs/technical_plan.md` §7 and the operator-facing
materials in the sister repo described, and closed the gaps in a single
release.

This is the same kind of "design intent that never shipped" drift that
`docs/technical_plan.md` §7.1 had with the never-implemented
`~/.synax/keys/index.yaml`. v0.2.2 reconciles both: the docs and the code.

---

## Phase 1 — The Audit (Documented vs Actual)

### `synax keys` subcommands — gaps found

| Command | Documented intent | v0.2.1 actual flags | v0.2.2 closes |
|---|---|---|---|
| `keys generate` | metadata index, named keys, custom output | `--help` only | `--name`, `--output-dir`, `--set-default` |
| `keys list` | rich table, optional JSON | `--help` only | `--json` flag, `Name` column |
| `keys export` | pipeable pub file | `<fp>`, `--output/-o`; stdout was non-loadable KV | TTY-aware stdout; prefix lookup |
| `keys import` | import a pub file | `<PUB_FILE>` | (matches docs — no change) |
| `keys set-default` | set default by fingerprint | exact match only | prefix lookup |
| `keys delete` | _missing entirely_ | absent | new command |
| `keys show` | _missing entirely_ | absent | new command |
| `keys register` | register a pub key with platform | `--namespace`, `--target`, `--token`, `--key` | `--public-key-file`, `--label`, prefix on `--key` |

### `synax skill` subcommands — no gaps

All `skill` commands (init, validate, test, build, publish, verify, info)
matched their documentation. No changes in v0.2.2.

### Cross-cutting gap — `synax --quiet`

Mentioned in `docs/technical_plan.md` §10 as "for machine consumption (CI
pipelines), respect a `--quiet` flag that emits minimal output". Not
implemented. Added in v0.2.2 as a global flag on `synax`.

### Architectural findings during the audit

1. **No key metadata storage shipped.** `technical_plan.md` §7.1 referenced
   `~/.synax/keys/index.yaml` mapping fingerprints to metadata. Never
   implemented. The actual on-disk layout was one `sha256_<hex>.key` JSON
   file per key (with both halves) plus a `default` pointer file. v0.2.2
   adds `name` *inline in the per-key JSON*, not via a separate index file —
   atomic, no sync hazards, matches the existing file format's
   forward-compatibility contract ("unknown fields ignored on load").

2. **`<key_id>.key.pub` never shipped either.** §7.1 step 3 listed a
   separate public-only file at write time. We've never generated one
   automatically. Public-only files are produced *on demand* by
   `synax keys export --output` (or, post-v0.2.2, by redirecting non-TTY
   stdout).

3. **Fingerprint prefix matching was missing.** Full fingerprints are
   `sha256:` + 64 hex chars. Forcing the operator to retype them is
   absurd. v0.2.2 adopts the git-short-SHA model — any unambiguous hex
   prefix resolves; ambiguity is rejected with the candidate set quoted.

4. **`keys export` stdout was the load-bearing bug.** The pre-v0.2.2 stdout
   format was human-readable key=value lines. `keys register
   --public-key-file` (which v0.2.2 introduces) reads back the *JSON*
   pub-file format produced by `--output`. So the natural shell idiom
   `synax keys export <fp> > ci.pub && synax keys register
   --public-key-file ci.pub` was broken end-to-end. v0.2.2 fixes this by
   making `keys export` TTY-aware: human KV at a terminal, JSON pub-file
   when piped or redirected.

---

## Phase 2 — Bucket Categorization

### Bucket A — Operator-blocking (shipped in v0.2.2)

- `keys generate --name`, `--output-dir`, `--set-default`
- `keys list --json`, Name column
- `keys export` TTY-aware stdout; prefix lookup
- `keys set-default` prefix lookup
- `keys register --public-key-file`, `--label`; prefix on `--key`
- `PublishClient.register_key(label=...)` SDK addition
- `keys delete <fp>` new command (with confirm + `--force` + default protection)
- `keys show <fp>` new command (with `--json`)
- `synax --quiet/-q` global flag

### Bucket B — Quality-of-life (deferred)

- More `--quiet`/`--json` coverage on `synax skill *` commands.
- `keys delete` interactive multi-select (delete several at once).
- `keys export --format pem` (we use JSON pub format; PEM compat is its own scope).
- `keys rotate` (rotation policy is a separate design problem).

### Bucket C — Docs-only fixes (shipped in v0.2.2 commit 1)

- `docs/technical_plan.md` §7.1 — removed never-shipped `index.yaml` and
  `<key_id>.key.pub`. Documented the actual on-disk format.
- §7.4 — refreshed the `synax keys` command list with the new flags.
- §7.5 — `keys register` doc expanded with `--public-key-file` and `--label`.

---

## Phase 3 — Per-Command Before / After

### `keys generate`

**Before:**
```
$ synax keys generate
✓ Generated keypair sha256:abc...
  saved to ~/.synax/keys/sha256_abc...key
  set as default signing key
```

**After:**
```
$ synax keys generate --name "ci-bot"
✓ Generated keypair sha256:abc... (ci-bot)
  saved to ~/.synax/keys/sha256_abc...key
  set as default signing key

$ synax keys generate --output-dir /tmp/sandbox-keys
$ synax keys generate --set-default                       # overrides existing default
$ synax --quiet keys generate --name ci
sha256:abc1234...                                          # only the fingerprint
```

### `keys list`

**Before:** Rich table with Fingerprint / Created / Default columns.

**After:**
- Default Rich table now includes a `Name` column.
- `--json` emits an array of records suitable for `jq` / scripting.
- Under `--quiet` emits one fingerprint per line.

```
$ synax keys list --json
[
  {
    "fingerprint": "sha256:abc...",
    "name": "ci-bot",
    "created_at": "2026-05-20T12:34:56Z",
    "default": true,
    "path": "/home/.../sha256_abc....key",
    "algorithm": "Ed25519"
  }
]
```

### `keys show` (new)

```
$ synax keys show abc1234                                  # prefix lookup works
sha256:abc1234567...
  name:       ci-bot
  created_at: 2026-05-20T12:34:56Z
  default:    yes
  algorithm:  Ed25519
  path:       /home/.../sha256_abc...key

$ synax keys show abc1234 --json
{ "fingerprint": "sha256:abc...", "name": "ci-bot", ... }
```

### `keys export`

**Before (broken pipe):**
```
$ synax keys export sha256:abc... > ci.pub
$ cat ci.pub
fingerprint: sha256:abc...
public_key_b64: MCowBQYDK2VwAyEA...

$ synax keys register --public-key-file ci.pub ...        # FAILS — not a pub file
```

**After:**
```
# Interactive — unchanged human-readable summary
$ synax keys export sha256:abc...
fingerprint: sha256:abc...
public_key_b64: MCowBQYDK2VwAyEA...
created_at: ...

# Piped — emits JSON pub-file format
$ synax keys export sha256:abc... > ci.pub
$ cat ci.pub
{
  "version": 1,
  "algorithm": "Ed25519",
  "fingerprint": "sha256:abc...",
  "public_key_b64": "MCowBQYDK2VwAyEA...",
  "created_at": "..."
}
$ synax keys register --public-key-file ci.pub ...        # WORKS

# Prefix lookup
$ synax keys export abc1234 -o ci.pub
```

### `keys set-default`

```
$ synax keys set-default abc1234                          # prefix lookup
✓ Default key set to sha256:abc1234567...
```

### `keys delete` (new)

```
$ synax keys delete abc1234
Delete key sha256:abc1234567...? [y/N]: y
✓ Deleted key sha256:abc1234567...

# Refuses to delete the default unless --force
$ synax keys delete sha256:default-key-fp
✗ sha256:default-key-fp is the default signing key. Pass --force to delete it. Aborting.

$ synax keys delete sha256:default-key-fp --force
✓ Deleted key sha256:default-key-fp
  default pointer cleared

# Under --quiet, --force is required (no interactive prompt available)
$ synax --quiet keys delete abc1234
✗ Refusing to delete without --force in quiet mode (no interactive prompt).
```

### `keys register`

**Before:** Only registered keys already in the local store.

**After:**
```
# Register a key from a file produced by `keys export`
$ synax keys register \
    --target https://platform.example.com \
    --namespace synax \
    --public-key-file /tmp/ci.pub \
    --label "synax-skills CI key"
✓ Registered key sha256:abc... for namespace synax
  registration_id: reg-123
  status:          pending_approval

# Mutual exclusion enforced
$ synax keys register --key abc1234 --public-key-file ci.pub --namespace x
✗ --key and --public-key-file are mutually exclusive.

# --quiet emits just the registration_id
$ synax --quiet keys register --target ... --namespace synax
reg-123
```

### Global `synax --quiet/-q`

```
$ synax --quiet keys generate --name ci
sha256:abc...                                              # script-friendly

$ FP=$(synax --quiet keys generate --name ci)
$ synax --quiet keys export "$FP" > ci.pub
$ synax --quiet keys register --public-key-file ci.pub --namespace x --target ...
reg-abc-123

# All Rich banners suppressed; load-bearing output (fingerprints,
# registration IDs, JSON payloads) still printed.
```

---

## Phase 4 — Implementation Notes

### Key file format — additive `name` field

The pre-v0.2.2 on-disk format (`KEY_FILE_VERSION = 1`):

```json
{
  "version": 1,
  "algorithm": "Ed25519",
  "fingerprint": "sha256:...",
  "public_key_b64": "...",
  "private_key_b64": "...",
  "created_at": "..."
}
```

v0.2.2 adds an optional `name` field. The format version stays at 1 because
the file format's docstring already promised forward compatibility:

> The file format is documented at `KEY_FILE_VERSION = 1` and is
> forward-compatible: unknown fields are ignored on load.

Concretely:

- **Old SDK reads new file:** drops the `name` field, loads everything else.
  No error.
- **New SDK reads old file:** `name` is absent → loaded as `None`. Same
  behavior as before.

`save_keypair_to_file` omits the field when `name is None`, so absent-name
keys round-trip without picking up an extra field.

### Fingerprint prefix resolution

`KeyStore.resolve(prefix_or_full) -> str`:

1. Strips optional `sha256:` scheme.
2. Validates the input is non-empty hex (case-insensitive).
3. Full-length input (64 hex chars) → fast path: check exact file existence,
   return canonical form or raise.
4. Prefix → list all fingerprints, find those whose hex part starts with
   the prefix.
5. Exactly 1 match → return canonical full fingerprint.
6. 0 matches → `SigningError("No key matching prefix 'abc' in /path.")`.
7. >1 match → `SigningError("Ambiguous prefix 'abc' matches N keys: a, b. Use a longer prefix.")`.

`KeyStore.load`, `KeyStore.set_default`, and the new `KeyStore.delete` all
funnel through `resolve`. Full fingerprints continue to work — the
single-match prefix lookup handles them identically.

### `KeyStore.delete(fp, *, force=False)`

- Resolves the fingerprint.
- Refuses to delete the active default unless `force=True` — operator can't
  accidentally leave the store without a default by typing one wrong
  command.
- When the default is force-deleted, clears `~/.synax/keys/default` so
  `default_fingerprint` becomes `None`.
- Returns the canonical full fingerprint that was deleted (useful for
  `--quiet` output).

### `PublishClient.register_key(label=...)`

The wire-format change is minimal — when `label is None`, the body is
unchanged from v0.2.1. When set, the body grows one field:

```json
{
  "public_key_b64": "...",
  "fingerprint": "sha256:...",
  "namespace": "...",
  "label": "synax-skills CI key"
}
```

Platform deployments that don't yet know about the field ignore it (a
well-behaved JSON API ignores unknown fields). No coordinated platform
change is required for v0.2.2 to ship.

### `--quiet` plumbing

A new `synax_skill_cli.utils.output` module exposes:

- `set_quiet(value: bool)` — flips a module-level flag.
- `is_quiet() -> bool` — read the flag.
- `QuietConsole` — drop-in replacement for `rich.console.Console`. Its
  `.print(...)` becomes a no-op when `is_quiet()`. Every other Console
  attribute proxies through to a real underlying `Console`.

The root `synax --quiet` callback calls `set_quiet(True)`. Each subcommand
that previously did `_console = Console()` now does
`_console = QuietConsole()`, and uses `typer.echo(...)` directly for
load-bearing output (fingerprints, registration IDs, JSON payloads) that
must survive `--quiet`.

### TTY-aware `keys export`

The decision branch:

```python
if not _stdout_is_tty() or is_quiet():
    # emit JSON pub-file format
else:
    # emit human-readable KV summary
```

`_stdout_is_tty()` is a tiny wrapper around `sys.stdout.isatty()`. The
indirection exists so tests can patch the helper instead of fighting
typer's `CliRunner` (which replaces `sys.stdout` with a non-TTY stream).

---

## Tests Added

- `tests/unit/test_signing.py` — `TestKeyPairName` (6 cases),
  `TestKeyStoreResolve` (10 cases), `TestKeyStoreDelete` (7 cases).
- `tests/unit/test_publishing.py` — `register_key` label forwarding
  (with and without `label`), backwards-compat body shape.
- `tests/unit/test_cli_keys.py` — `TestKeysGenerateFlags` (3 cases),
  `TestKeysListJson` (3), `TestKeysShow` (4), `TestKeysExportTty` (3),
  `TestKeysDelete` (8), `TestQuietFlag` (4).
- `tests/unit/test_cli_publish.py` — `--label` forwarding, `--public-key-file`
  happy path, `--key` / `--public-key-file` mutex, `--quiet` register output.
- `tests/integration/test_m4_acceptance.py` fixture updated to match the
  new `_store(output_dir=None)` signature.

**Final test count:** 734 passing, 2 skipped, 0 failing.
**Coverage delta:** new code is fully covered; project-wide coverage stays
≥94%.

---

## Backwards Compatibility Audit

| Surface | Pre-v0.2.2 invocation | v0.2.2 behavior |
|---|---|---|
| `synax keys generate` | no flags | unchanged — still creates a default key |
| `synax keys list` | no flags | unchanged — Rich table just gains a `Name` column |
| `synax keys export <fp>` interactive | KV summary | unchanged (TTY branch) |
| `synax keys export <fp> > file` | non-loadable KV | **changed** — now produces JSON pub file. Pre-1.0 break of a broken behavior; called out in CHANGELOG |
| `synax keys set-default <full-fp>` | exact match | unchanged — full fp resolves identically |
| `synax keys register --key <full-fp>` | exact match | unchanged |
| Existing key files on disk | loaded as `KeyPair(name=None)` | unchanged |
| Newly-written key files | gain optional `name` field | older SDK versions silently drop the field per format contract |
| `PublishClient.register_key(...)` without `label` | unchanged body | unchanged |

The CHANGELOG explicitly calls out the one behavior change
(`keys export` pipe output) under a `### Changed` heading. Every other
addition is purely additive.

---

## Operator Workflow — End-to-End Validation

The blocking workflow from the operator setup checklist:

```bash
# 1. Generate a labeled CI signing key
synax keys generate --name "synax-skills-ci"

# 2. List keys, copy the fingerprint
synax keys list

# 3. Export the public key for registration
synax keys export sha256:abc1234 > /tmp/ci.pub
# (or any unambiguous prefix:)
synax keys export abc1234 > /tmp/ci.pub

# 4. Register with the platform
synax keys register \
  --target https://platform.example.com \
  --public-key-file /tmp/ci.pub \
  --namespace synax \
  --label "synax-skills CI key"
```

All four steps work after v0.2.2. Steps 1, 3, and 4 were broken in v0.2.1.

---

## What's NOT in v0.2.2

- **No Python-import API additions beyond `KeyPair.name` and
  `register_key(label=...)`.** The library surface that skill authors
  import is unchanged.
- **No runtime contract changes.** Env vars, capability checks, network
  module — all unchanged from v0.2.0.
- **No new CLI command tree shape.** Only flags added to existing
  commands, plus two new `keys` subcommands (`show`, `delete`).
- **No key rotation, no revocation.** Out of scope; future SDK versions.
- **No multiple key algorithms.** Ed25519-only, same as v0.2.0/0.2.1.

---

## Release Flow (per `docs/publish_now.md`)

This release goes through the same branch-aware OIDC pipeline that shipped
v0.2.1:

```bash
# Already done locally:
#   - 5 commits on dev (9e43428 → 143b806)
#   - Tag v0.2.2 to be created

# Dev → TestPyPI:
git push origin dev
git tag -a v0.2.2 -m "v0.2.2 — close CLI gaps documented since v0.1.0"
git push origin v0.2.2

# After TestPyPI verifies, dev → main → PyPI:
git checkout main
git merge --ff-only dev
git push origin main
# Tag is already on the same commit; workflow re-routes to PyPI
# because the tagged commit is now on main.
```

The workflow at `.github/workflows/publish.yml` inspects the branch
containing the tagged commit — main → PyPI, dev → TestPyPI — and routes
accordingly via OIDC trusted publishing. No tokens are stored in the repo
or in CI logs.

---

## Lessons for Future Releases

1. **Audit documentation against implementation periodically.** v0.2.2
   exists because documentation drifted from code over multiple
   milestones. A simple `--help` vs docs comparison would have caught
   each gap individually; bundling them was efficient but also
   revealing — there were more gaps than any one user had reported.

2. **TTY-aware output is the right default for command-line tools that
   are both interactive and pipeable.** The `keys export` bug existed
   because someone optimized for the interactive case and never tried
   the pipe case. The pattern `if not sys.stdout.isatty(): emit machine
   format` should be the default whenever a command can plausibly be
   piped.

3. **`--quiet` is cheap once you have a console wrapper.** Adding it as
   a no-op `.print` override was ~30 lines of new code. Doing it
   command-by-command would have been ~10× the diff. Worth doing as a
   single global flag from day one of any CLI.

4. **Prefix-matching fingerprints is non-negotiable for any tool whose
   identifiers are hashes.** Git solved this in 2005. Our CLI took
   until v0.2.2.

5. **Forward-compat key file format paid off.** The `unknown fields
   ignored on load` rule documented in v0.1.0's `signing.py` made
   adding `name` a zero-risk extension. Old SDKs reading new files
   silently work. Newer-file detection is automatic via field
   presence, not via version bumps.

---

## References

- Commits: `9e43428` → `143b806` on `dev`
- CHANGELOG entry: `CHANGELOG.md` § [0.2.2] — 2026-05-20
- Doc reconciliation: `docs/technical_plan.md` §7.1 / §7.4 / §7.5
- Release runbook: `docs/publish_sdk.md`, `docs/publish_now.md`
- Runtime contract (unchanged): `docs/runtime_contract.md`
- Predecessor retrospective context: `CHANGELOG.md` § [0.2.1] — 2026-05-18
