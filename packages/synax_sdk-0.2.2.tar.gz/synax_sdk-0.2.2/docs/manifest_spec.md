# Skill Manifest Specification

**Version:** 1.0 (matches platform manifest schema version 1.0)
**Status:** Authoritative for SDK implementation
**Audience:** SDK developers, Claude Code

---

## How to Use This Document

This document specifies the format of skill manifests that this SDK generates and publishes to a Synax platform instance. It's derived from the platform's `data_model.md` §17, which is the upstream source of truth.

When building the SDK:
- The SDK generates manifests that conform to this schema
- The SDK validates manifests against this schema before publishing
- This document is the contract between the SDK and the platform

If the platform's schema evolves (a new version published in the platform repo's `data_model.md`), update this document to match. The SDK should support whatever versions of the schema the platform currently accepts.

---

## Overview

A **skill manifest** is a YAML or JSON document that describes a skill: its identity, what tools it exposes, what capabilities it needs, who signed it, and how to execute it.

Manifests are produced by skill authors (with help from this SDK), distributed to a Synax platform, and used by the platform to install and execute skills.

**Two equivalent serializations:**
- YAML — preferred for human authoring and review
- JSON — required for the canonical form used for signing

The SDK works with both. When signing or validating signatures, it uses the canonical JSON form (sorted keys, no whitespace). When presenting to users, it uses YAML.

---

## Top-Level Schema

A complete manifest has these top-level fields:

```yaml
schema_version: "1.0"        # required, string, currently "1.0"
name: "<skill-name>"          # required, slug format
namespace: "<namespace>"       # optional, for trusted publishers
version: "1.0.0"              # required, semver
display_name: "Display Name"  # required, human-readable
description: "Short desc"     # required, one-line description

implementation:                # required, see "Implementation" section
  type: "python_code"          # required, one of: manifest_only, python_code, typescript_code
  entry_point: "module:function"  # required for code-based
  hash: "sha256:..."           # required, content hash

tools:                         # required, list of tools, at least one
  - name: "tool_name"
    ...

capabilities:                  # optional, list of capability strings
  - "network:api.github.com"
  - "secrets:GITHUB_TOKEN"

execution_location: "either"   # optional, one of: daemon_only, cloud_only, prefer_daemon, prefer_cloud, either; default "either"

secrets:                       # optional, list of secrets the skill uses
  - name: "GITHUB_TOKEN"
    type: "oauth_token"
    description: "..."

dependencies:                  # optional, list of skill dependencies
  - skill: "other-skill"
    version: ">=1.0.0,<2.0.0"

metadata:                      # optional, miscellaneous metadata
  category: "developer_tools"
  tags: ["github", "code-review"]
  homepage: "https://..."
  source: "https://github.com/..."
  documentation: "https://..."
  license: "Apache-2.0"

signatures:                    # required at publish, list of signatures
  - key_fingerprint: "..."
    signer_type: "author"
    signature: "..."
```

---

## Field Specifications

### `schema_version` (required, string)

The version of this schema. Currently `"1.0"`. The SDK generates manifests with this exact value. Future schema versions will be additive where possible.

### `name` (required, string, slug format)

The skill's identifier. Slug format: lowercase alphanumeric with hyphens. Maximum 128 characters.

Examples: `github-pr-summary`, `send-slack-message`, `web-search`.

The combination of `name` + `namespace` must be globally unique on the platform. For unnamespaced (community) skills, just `name` must be unique.

### `namespace` (optional, string, slug format)

The publisher's namespace. Reserved for Trusted Publisher tier skills. If absent, the skill is in the global namespace (community tier).

Examples: `synax`, `anthropic`, `acmecorp`.

A skill `synax/github-fetch` lives at namespace `synax`, name `github-fetch`. Two different namespaces can have skills with the same name.

### `version` (required, string, semver)

The skill version following semantic versioning. Format: `MAJOR.MINOR.PATCH` (e.g., `1.2.3`).

The platform allows multiple versions of the same skill to coexist. Workspaces install a specific version. Skill authors publish new versions to release updates.

Pre-release versions (`1.0.0-beta.1`) are valid. Build metadata (`1.0.0+20260514`) is valid but discouraged.

### `display_name` (required, string)

Human-readable name shown in the marketplace UI. Maximum 255 characters.

Example: `"GitHub PR Summary"` (the display form of `github-pr-summary`).

### `description` (required, string)

One-line description (under 256 characters) that appears in marketplace listings.

For longer descriptions, use the `metadata.long_description` field.

### `implementation` (required, object)

Describes how the skill is implemented. Contains:

- **`type`** (required, enum): One of `"manifest_only"`, `"python_code"`, `"typescript_code"`. This SDK produces `"python_code"` skills.
- **`entry_point`** (required for code-based): Python import path in `module:function` format. The function is the `Skill` object that `synax_skill_cli` invokes. Example: `"github_pr_summary:skill"`.
- **`hash`** (required): SHA-256 hash of the implementation artifact in format `"sha256:<64-hex-chars>"`. This binds the manifest to a specific implementation. The platform verifies this hash before executing.
- **`runtime_requirements`** (optional, object): Constraints on the runtime environment. Examples: `{"python": ">=3.11"}`, `{"node": ">=18"}`.

For manifest-only skills (not produced by this SDK), the `implementation` block contains inline operations instead of an entry point. This SDK doesn't generate that variant.

### `tools` (required, list, minimum 1 item)

The tools this skill exposes. Each tool is a callable function that bots can invoke. Each tool has:

```yaml
- name: "summarize_pr"             # required, identifier (snake_case)
  description: "Fetch a GitHub..."  # required, what the tool does
  parameters:                       # required, JSON Schema
    type: object
    properties:
      repo:
        type: string
        description: "Repository in format owner/name"
      pr_number:
        type: integer
        description: "Pull request number"
    required: ["repo", "pr_number"]
  returns:                          # optional, JSON Schema for return value
    type: object
    properties:
      title:
        type: string
      summary:
        type: string
      files_changed:
        type: integer
```

**Notes on tool fields:**

- **`name`**: snake_case, maximum 64 characters. Must be unique within the skill. This is the name bots see and invoke.
- **`description`**: explains what the tool does in 1-3 sentences. Bots use this to decide when to call the tool, so it should be informative.
- **`parameters`**: A JSON Schema document. Must be `type: object` at the top level. Bots provide arguments matching this schema.
- **`returns`**: Optional. If present, the platform validates the return value matches. If absent, the platform accepts any return value.

### `capabilities` (optional, list of strings)

Capabilities the skill needs to run. The platform enforces these at execution time — a skill that declares `network:api.github.com` can only reach that host.

Capability format: `<type>:<specifier>`. Common types:

- **`network:<hostname>`** — outbound network access to a specific host. Example: `"network:api.github.com"`.
- **`network:<hostname>:<port>`** — host with specific port. Example: `"network:smtp.gmail.com:587"`.
- **`secrets:<name>`** — access to a named secret. Example: `"secrets:GITHUB_TOKEN"`.
- **`filesystem:read:<path>`** — read access to a filesystem path. Example: `"filesystem:read:/data/inputs"`.
- **`filesystem:write:<path>`** — write access. Example: `"filesystem:write:/tmp"`.
- **`subprocess:<command>`** — ability to spawn a specific subprocess. Example: `"subprocess:git"`.
- **`platform:<api>`** — access to a platform API. Example: `"platform:memory_read"` or `"platform:transcripts_read"`.

Capabilities are inspectable by users when installing a skill. Users approve them before installation. A skill that requests capabilities the user doesn't approve will fail to install.

When defining a skill via this SDK, capabilities are declared on the `Skill` object:

```python
skill = Skill(
    name="github-pr-summary",
    capabilities=[
        "network:api.github.com",
        "secrets:GITHUB_TOKEN",
    ],
)
```

### `execution_location` (optional, enum, default `"either"`)

Where this skill is permitted to execute. One of:

- **`daemon_only`** — must execute on a daemon (user's local hardware). For skills that need filesystem or local network access.
- **`cloud_only`** — must execute in the platform's cloud workers. For skills that need cloud-only capabilities.
- **`prefer_daemon`** — prefer daemon, fall back to cloud if no daemon is available.
- **`prefer_cloud`** — prefer cloud, fall back to daemon if customer policy requires daemon.
- **`either`** — execute wherever convenient. Default.

The customer's policy can further restrict this — a customer might say "all skills must run on daemons in our environment." If a skill declares `cloud_only` and the customer requires daemon, the skill fails to install (with a clear error).

### `secrets` (optional, list of objects)

Secrets the skill uses. Each item:

```yaml
- name: "GITHUB_TOKEN"            # required, what the skill calls secrets.get(name)
  type: "oauth_token"              # required, one of the secret types
  description: "GitHub OAuth..."   # required, helps customer understand what to provide
  scope_required: "repo:read"      # optional, helpful for oauth_token type
```

**Secret types** (matching platform's data_model.md):

- `api_key` — generic API key
- `oauth_token` — OAuth token, often with refresh metadata
- `database_password` — password for database connection
- `ssh_key` — SSH key for remote access
- `certificate` — X.509 certificate
- `generic_string` — any other secret

When a workspace installs a skill, the workspace admin sees the list of required secrets. They must configure each secret in the platform's secrets system before the skill can be used.

### `dependencies` (optional, list of objects)

Other skills this skill depends on. Each item:

```yaml
- skill: "other-skill"             # required, the skill name
  version: ">=1.0.0,<2.0.0"        # required, semver constraint
```

The platform resolves dependencies at install time. A skill with unsatisfied dependencies fails to install.

Most skills have no dependencies (skills should be self-contained where possible). This field is for genuine composition scenarios.

### `metadata` (optional, object)

Miscellaneous metadata that doesn't affect execution but is useful for the marketplace and documentation:

```yaml
metadata:
  category: "developer_tools"      # marketplace category
  tags: ["github", "code-review"]  # searchable tags
  homepage: "https://..."          # project homepage
  source: "https://github.com/..." # source code URL
  documentation: "https://..."     # user documentation
  license: "Apache-2.0"            # SPDX license identifier
  long_description: "..."          # longer description (markdown supported)
  icon_url: "https://..."          # icon for marketplace display
```

All metadata fields are optional. The SDK passes them through unchanged.

### `signatures` (required at publish, list of objects)

Cryptographic signatures over the canonical JSON form of the manifest. At least one signature (from the author) is required for publishing.

Each signature:

```yaml
- key_fingerprint: "abc123..."      # SHA-256 of the public key
  signer_type: "author"              # author, platform_verifier, audit, customer_internal
  signature: "base64-encoded-sig"   # Ed25519 signature, base64
  signed_at: "2026-05-14T10:00:00Z" # ISO 8601 timestamp
```

**Signer types:**

- **`author`** — the skill's author. Always required.
- **`platform_verifier`** — Synax platform verifier signature (Verified tier). Added by the platform, not by this SDK.
- **`audit`** — third-party audit signature. Added by external auditors.
- **`customer_internal`** — customer's internal CA signature for org-private skills.

The SDK is responsible for the `author` signature. Other signature types are added at later stages and aren't this SDK's concern.

### Canonical form for signing

The signature is over a specific canonical representation:

1. Take the manifest as a JSON object
2. Remove the `signatures` field (signatures sign everything except themselves)
3. Sort all keys recursively in lexicographic order
4. Serialize with no whitespace and no trailing newline (use `json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)`)
5. Encode as UTF-8 bytes
6. Sign those bytes with the author's Ed25519 private key
7. Add the signature back into the `signatures` list

The platform reverses this process to verify: it takes the manifest, removes signatures, canonicalizes the same way, and verifies against the public key fingerprint.

---

## Complete Example

Here's a realistic complete manifest:

```yaml
schema_version: "1.0"
name: "github-pr-summary"
version: "1.2.3"
display_name: "GitHub PR Summary"
description: "Fetch and summarize GitHub pull requests"

implementation:
  type: "python_code"
  entry_point: "github_pr_summary:skill"
  hash: "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  runtime_requirements:
    python: ">=3.11"

tools:
  - name: "summarize_pr"
    description: "Fetch a GitHub PR and return a structured summary including title, body, files changed, and review status"
    parameters:
      type: object
      properties:
        repo:
          type: string
          description: "Repository in format owner/name"
        pr_number:
          type: integer
          description: "Pull request number"
      required: ["repo", "pr_number"]
    returns:
      type: object
      properties:
        title:
          type: string
        body:
          type: string
        author:
          type: string
        files_changed:
          type: integer
        additions:
          type: integer
        deletions:
          type: integer
        review_status:
          type: string

  - name: "list_recent_prs"
    description: "List recent open pull requests for a repository"
    parameters:
      type: object
      properties:
        repo:
          type: string
          description: "Repository in format owner/name"
        limit:
          type: integer
          description: "Maximum number of PRs to return"
          default: 10
      required: ["repo"]

capabilities:
  - "network:api.github.com"
  - "secrets:GITHUB_TOKEN"

execution_location: "either"

secrets:
  - name: "GITHUB_TOKEN"
    type: "oauth_token"
    description: "GitHub OAuth token with repo:read scope"
    scope_required: "repo:read"

dependencies: []

metadata:
  category: "developer_tools"
  tags: ["github", "code-review", "summarization"]
  homepage: "https://example.com/github-pr-summary"
  source: "https://github.com/example/github-pr-summary"
  documentation: "https://example.com/docs/github-pr-summary"
  license: "Apache-2.0"

signatures:
  - key_fingerprint: "abc123def456..."
    signer_type: "author"
    signature: "MEUCIQDl...="
    signed_at: "2026-05-14T10:00:00Z"
```

---

## Validation Rules

The SDK validates manifests before publishing. Rules:

### Required fields
- `schema_version`, `name`, `version`, `display_name`, `description`, `implementation`, `tools` must be present.
- `signatures` must be present at publish time with at least one `author` signature.

### Format constraints
- `name` matches `^[a-z0-9][a-z0-9-]{0,127}$` (slug format, lowercase)
- `namespace` if present matches the same pattern
- `version` matches semver format
- `schema_version` equals `"1.0"` (for v1)

### Tool constraints
- At least one tool must be defined
- Tool names must be unique within the skill
- Tool `parameters` must be valid JSON Schema with `type: object`
- Tool `returns` if present must be valid JSON Schema

### Capability constraints
- Each capability must match the format `<type>:<specifier>` (one or more `:`)
- Known capability types: `network`, `secrets`, `filesystem`, `subprocess`, `platform`
- Unknown capability types produce a warning but don't fail validation (platform may understand types the SDK doesn't)

### Implementation constraints
- `hash` field must match `sha256:<64-hex-chars>` format
- `hash` value must match the actual SHA-256 of the implementation artifact
- `entry_point` must be valid Python import path for `python_code` skills

### Signature constraints
- All signatures must verify against their declared keys
- The `author` signature must use a key the SDK can locate (typically `~/.synax/keys/`)
- `signed_at` must be in ISO 8601 format

### Logical constraints
- All `secrets` listed must have corresponding `secrets:<name>` in `capabilities`
- All `network:<host>` capabilities should look like real hostnames (validation is loose; platform may reject unusual hosts)
- `execution_location: "daemon_only"` skills should generally need filesystem or local-network capabilities (warn if neither is declared)

---

## Wire Format for Publishing

When publishing a skill to a platform, the SDK uses this REST API:

### Request

```
POST {platform_url}/api/v1/skills/publish
Content-Type: application/json
Authorization: Bearer <publisher_token>

{
  "manifest_yaml": "<the YAML manifest as a string>",
  "implementation_artifact_b64": "<base64-encoded tar.gz of the skill code>",
  "implementation_hash": "sha256:..."
}
```

The publisher token is obtained from the platform — either:
- A workspace admin creates a publisher token for community skills
- A trusted publisher's API key for namespaced skills

### Response (success)

```
HTTP/1.1 200 OK
Content-Type: application/json

{
  "skill_id": "uuid",
  "skill_version_id": "uuid",
  "status": "registered",
  "marketplace_url": "https://platform/marketplace/skills/<id>"
}
```

### Response (validation failure)

```
HTTP/1.1 400 Bad Request
Content-Type: application/json

{
  "error_code": "manifest_invalid",
  "message": "Manifest validation failed",
  "details": {
    "field": "tools[0].parameters",
    "issue": "Required property 'type' is missing"
  }
}
```

### Response (signature failure)

```
HTTP/1.1 401 Unauthorized
Content-Type: application/json

{
  "error_code": "signature_invalid",
  "message": "Author signature does not verify",
  "details": {...}
}
```

### Response (duplicate version)

```
HTTP/1.1 409 Conflict
Content-Type: application/json

{
  "error_code": "version_already_published",
  "message": "Version 1.2.3 of github-pr-summary already exists. Bump the version.",
  "details": {"existing_version_id": "..."}
}
```

---

## Implementation Artifact Format

The implementation artifact is a `.tar.gz` archive containing the skill's code. Structure:

```
<artifact>.tar.gz
├── pyproject.toml         # project metadata
├── README.md              # skill documentation (optional but recommended)
├── <skill_module>.py      # the main module containing the Skill object
├── (optional support files)
└── requirements.txt       # pinned dependencies for the skill (optional)
```

The archive root contains the skill files directly (not nested in a subdirectory). The entry point in the manifest refers to a module within this archive.

The archive is base64-encoded for the wire format.

---

## Differences from Manifest-Only Skills

For reference (and to avoid confusion): manifest-only skills use the same top-level schema but with these differences:

- `implementation.type` is `"manifest_only"`
- `implementation.entry_point` is omitted
- `implementation.operations` is added — inline declarative operations (HTTP requests, transformations, etc.)
- No implementation artifact is uploaded (manifest contains everything)

This SDK does not produce manifest-only skills. They're authored directly as YAML.

---

## Schema Evolution

The schema version is `"1.0"` for v1 of the platform. Future versions:

- **`"1.1"`** — backwards-compatible additions (new optional fields, new capability types)
- **`"2.0"`** — breaking changes (would require platform version compatibility check)

The SDK should:
- Generate `schema_version: "1.0"` for v1
- Read manifests of any `schema_version: "1.x"` it knows about
- Reject (with clear error) manifests of unknown schema versions
- Track the schema version it supports prominently in its own version metadata

---

*End of skill manifest specification*
