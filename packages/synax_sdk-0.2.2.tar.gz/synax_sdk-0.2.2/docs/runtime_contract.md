# SDK ↔ Platform Runtime Contract

**Status:** Active — first formalized in SDK v0.2.0
**Audience:** Platform engineers wiring the Synax sandbox to invoke skills; SDK contributors

---

## What this document is

The Synax SDK runs inside a process that the Synax platform spawns. That parent process is responsible for supplying the SDK with the metadata and policy state it needs to execute a skill safely. This document specifies the wire-level contract between the two — what the platform must provide, in what shape, and how the SDK reacts when it's missing or malformed.

For v0.2.0 the contract is a small set of process **environment variables**. v0.3.0+ may introduce a richer IPC protocol (e.g. a Unix-domain socket or a parent-process FD) for streaming context and capability updates; in that future, the env-var path remains as a documented fallback for backwards compatibility and for local-development invocations that don't sit behind the full platform.

This is the source of truth. If the platform's sandbox code and this document disagree, the platform's code must change.

---

## Conventions

- All variables are prefixed `SYNAX_` to namespace cleanly from anything else in the process environment.
- Where a value is structured, **JSON** is the encoding. Single-string values use bare strings (no quoting).
- Where a value is a UUID, the canonical hyphenated lowercase form is required (`xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`).
- The SDK is **fail-closed**: when a required input is missing or unparseable, the SDK does not silently substitute a permissive default. It either raises an error at the call site that needed the input, or treats the input as empty (for collections) so the next dependent check fails with a clear message.
- The SDK **never logs the values** of `SYNAX_PUBLISH_TOKEN` or any other secret-bearing variable. Capability names are not considered sensitive and may appear in error messages and run-trace logs.

---

## Runtime environment variables

### `SYNAX_RUNTIME_CAPABILITIES`

- **Format:** JSON array of capability strings, e.g. `["network:api.github.com", "network:smtp.gmail.com:587", "secrets:GITHUB_TOKEN"]`.
- **Required:** No.
- **Default when absent:** Empty set.
- **Behavior on malformed input** (invalid JSON, top-level value not an array, array element not a string): empty set, and a `RuntimeWarning` is emitted once via the `warnings` module so it surfaces in test runs and CI without crashing the skill subprocess.
- **Consumed by:** `synax_sdk.runtime.network` (every `http_*` call) and by any future gated operation in the runtime API.
- **Semantics:** This is the **runtime-effective** capability set for the current execution — the intersection of (a) what the skill's manifest declared, (b) what the workspace admin approved at install time, and (c) what active customer policy allows. It is **not** the skill's originally-declared capability list from its manifest. The platform computes this intersection per invocation and serializes the result here.
- **Caching:** The SDK reads this variable once at first use and caches the value for the lifetime of the process. The platform is expected to set the variable before spawning the skill subprocess and to spawn a fresh subprocess per execution; if the variable changes during a process's lifetime, the SDK will not pick up the change. (Tests can call `synax_sdk.runtime._capabilities._reset_cache_for_testing()` to bypass this.)
- **Implemented in:** SDK v0.2.0.

#### Capability string format

A capability string is `<type>:<specifier>`. The `<type>` is a lowercase identifier (e.g. `network`, `secrets`, `filesystem`); the `<specifier>` is type-specific. For `network` capabilities:

- `network:*` — wildcard, matches any host and any port.
- `network:<host>` — matches requests to that host on any port.
- `network:<host>:<port>` — matches requests to that host on exactly that port.

A `network:<host>` capability also matches a request whose URL specifies an explicit port — host-only acts as "any port for this host". Port-qualified capabilities are stricter.

When a network call's destination does not match any of the three forms above in the runtime-effective set, the SDK raises `synax_sdk.CapabilityError` with the requested capability and the set of currently-available capabilities.

### `SYNAX_PUBLISH_TOKEN`

- **Format:** Opaque string (bearer token).
- **Required:** When running `synax skill publish` without `--token`.
- **Default when absent:** No default. The CLI errors out at the publish step with a message naming the variable.
- **Consumed by:** `synax_sdk.publishing.PublishClient` and the `synax skill publish` CLI command.
- **Implemented in:** SDK v0.1.0 (predates this document).
- **Sensitivity:** Token. Never logged.

---

## Reserved for future versions

The following variables are **reserved names** — the SDK does not read them in v0.2.0, but they are claimed by this contract so that platform implementations and future SDK versions can rely on the shape.

If you are wiring the platform's sandbox today, you may set these now in anticipation of v0.3.0+. The SDK will start consuming them when a stub production backend lands (no firm date; tied to the platform's sandbox milestone).

| Variable | Format | Purpose |
| --- | --- | --- |
| `SYNAX_RUN_ID` | UUID | The unique ID of the current skill invocation. Will populate `ctx.run_id`. |
| `SYNAX_WORKSPACE_ID` | UUID | The workspace the invocation belongs to. Will populate `ctx.workspace_id`. |
| `SYNAX_CHANNEL_ID` | UUID | The channel context for the invocation. Will populate `ctx.channel_id`. |
| `SYNAX_BOT_ID` | UUID, optional | The bot that triggered the invocation, if applicable. Will populate `ctx.bot_id`. |
| `SYNAX_USER_ID` | UUID, optional | The user that triggered the invocation, if applicable. Will populate `ctx.user_id`. |
| `SYNAX_INVOKER_TYPE` | `"user"` or `"bot"` | The invoker type. Will populate `ctx.invoker.type`. |
| `SYNAX_INVOKER_ID` | UUID | The invoker's UUID. Will populate `ctx.invoker.id`. |
| `SYNAX_INVOKER_NAME` | String | The invoker's display name. Will populate `ctx.invoker.name`. |

Until v0.3.0+, context is supplied to the SDK via the in-process `RuntimeBackend.get_context()` method (the platform's production backend implementation calls into its own state to construct the `Context`). The reserved env-var names exist to lock down the contract before that subprocess-style invocation path ships.

---

## How the SDK decides what to use

For variables that may also be supplied via a backend object (currently: capabilities), the SDK uses this precedence:

1. **A test-mode backend is bound** (`synax_sdk.testing.MockPlatform.activate()`): the backend's programmatic value is used. Env vars are ignored. This keeps test ergonomics clean — tests never have to manipulate the process environment.
2. **No backend is bound, or the bound backend is a production backend**: the SDK reads the env var (with caching and fail-closed semantics as documented above).

For variables consumed only at the CLI layer (currently: `SYNAX_PUBLISH_TOKEN`), there is no backend involvement — the variable is read directly when the relevant command runs.

---

## Versioning

This document is versioned with the SDK. Breaking changes to the contract require a SDK minor version bump pre-1.0 (and a major version bump post-1.0), an entry in `CHANGELOG.md`, and coordination with the platform team before merge.

Additive changes (new reserved variables, new capability types) do not require a version bump but do require a CHANGELOG entry.
