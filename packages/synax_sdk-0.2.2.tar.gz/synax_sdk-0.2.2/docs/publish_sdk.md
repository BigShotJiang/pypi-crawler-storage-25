# Publishing the Synax SDK to PyPI

End-to-end guide for releasing a new version of `synax-sdk` to PyPI. Written from scratch for the **0.1.0 first release**; the same flow applies to every future version with a different number.

This document is the single source of truth for the release process. If anything below disagrees with `.github/workflows/publish.yml` or `pyproject.toml`, fix the doc OR the file — they should never drift.

---

## TL;DR

For the very first release you need a one-time setup (PyPI accounts + trusted publishers + GitHub Environments — see [§ One-time setup](#one-time-setup)). After that, every release is:

```bash
# 1. Verify everything is green
uv run pytest                       # 622 tests pass
uv run ruff check . && uv run black --check . && uv run isort --check .
uv run mypy synax_sdk synax_skill_cli
uv build                            # produces dist/synax_sdk-X.Y.Z*

# 2. Bump version in synax_sdk/version.py + pyproject.toml + uv.lock,
#    update CHANGELOG.md, commit it.
git commit -am "chore: release X.Y.Z"

# 3. Tag and push
git tag vX.Y.Z
git push origin main --tags

# 4. Watch the publish workflow
gh run watch
```

The tag push triggers `.github/workflows/publish.yml` which builds, uploads to TestPyPI for validation, then promotes to PyPI.

---

## How the release flow is wired

```
git tag vX.Y.Z            <-- you do this
    │
    └── git push --tags
            │
            └── GitHub Actions: .github/workflows/publish.yml
                    │
                    ├── job: build
                    │     - uv sync --frozen --all-extras
                    │     - uv build  →  dist/synax_sdk-X.Y.Z.tar.gz
                    │                     dist/synax_sdk-X.Y.Z-py3-none-any.whl
                    │     - uploads `dist` artifact (7-day retention)
                    │
                    ├── job: publish-testpypi      (needs: build)
                    │     - downloads `dist` artifact
                    │     - pypa/gh-action-pypi-publish → TestPyPI
                    │       (OIDC trusted publishing, environment: testpypi)
                    │
                    └── job: publish-pypi          (needs: publish-testpypi)
                          - downloads `dist` artifact
                          - pypa/gh-action-pypi-publish → PyPI
                            (OIDC trusted publishing, environment: pypi)
```

If `publish-testpypi` fails, `publish-pypi` does not run. This is a deliberate validation gate.

---

## One-time setup

You only need to do this section once per project (not per release).

### 1. Create PyPI + TestPyPI accounts

If you don't already have them:

- PyPI: <https://pypi.org/account/register/>
- TestPyPI: <https://test.pypi.org/account/register/>

Enable 2FA on both. Required for anyone publishing in 2026+.

### 2. Reserve the project name

The first time you publish, PyPI auto-creates the project under your account. For OIDC trusted publishing to work, the project **must exist on PyPI before the first OIDC publish**. The chicken-and-egg solution is one of:

**Option A — Pre-create with a manual API-token upload (recommended for first release)**

1. Create an API token at <https://pypi.org/manage/account/token/> scoped to "Entire account" (you'll narrow it later).
2. Locally:
   ```bash
   uv build
   uv publish --token pypi-XXXX  # uploads dist/* to PyPI
   ```
3. Repeat for TestPyPI:
   ```bash
   uv publish --publish-url https://test.pypi.org/legacy/ --token pypi-XXXX
   ```
4. After the upload, narrow the API token to scope `synax-sdk` only (or delete it once OIDC is set up).

**Option B — Use a "Pending Publisher" via OIDC**

PyPI supports configuring a trusted publisher *before* the project exists; the first OIDC publish then creates the project. See <https://docs.pypi.org/trusted-publishers/creating-a-project-through-oidc/>. This is cleaner but requires more upfront PyPI form-filling.

For 0.1.0 we recommend **Option A** — it's faster and you immediately verify the wheel works on PyPI before switching to OIDC for subsequent releases.

### 3. Configure trusted publishers (OIDC)

Once `synax-sdk` exists on both indexes:

**PyPI** (<https://pypi.org/manage/project/synax-sdk/settings/publishing/>):

- Owner / org: `synergentic`
- Repository name: `synax-sdk`
- Workflow filename: `publish.yml`
- Environment name: `pypi`

**TestPyPI** (<https://test.pypi.org/manage/project/synax-sdk/settings/publishing/>):

- Owner / org: `synergentic`
- Repository name: `synax-sdk`
- Workflow filename: `publish.yml`
- Environment name: `testpypi`

The exact field labels may shift over time; the values above stay the same.

### 4. Create the GitHub Environments

In the repo, go to **Settings → Environments → New environment** and create two:

- `testpypi`
- `pypi`

For each, optionally configure:

- **Required reviewers** — at least one human approval before deployment runs. Recommended for `pypi`; optional for `testpypi`.
- **Deployment branches and tags** — restrict to `refs/tags/v*.*.*`. Prevents accidental publishes from arbitrary branches.

The environments don't need secrets if you're using OIDC. If you fall back to API tokens (see [§ Fallback: API tokens](#fallback-api-tokens)), add them here.

### 5. Verify the setup with a TestPyPI-only dry run

```bash
gh workflow run publish.yml --field test_only=true
gh run watch
```

This invokes `workflow_dispatch` with `test_only=true`, which:

1. Builds the wheel + sdist for whatever commit is on the branch.
2. Publishes to TestPyPI only (skips the PyPI step).

If this works, OIDC is configured correctly. If it fails, see [§ Troubleshooting](#troubleshooting).

---

## Pre-flight checklist (every release)

Run through this before tagging. Catching problems before the tag is much easier than yanking a bad release after.

### Code health

```bash
uv run ruff check .
uv run black --check .
uv run isort --check .
uv run mypy synax_sdk synax_skill_cli
uv run pytest --cov=synax_sdk --cov=synax_skill_cli --cov-fail-under=80
uv run pip-audit
```

All must pass. CI on `main` should also be green.

### Build verification

```bash
rm -rf dist/
uv build
uv run python -m zipfile -l dist/synax_sdk-X.Y.Z-py3-none-any.whl | head -50
```

Confirm:

- Both `.tar.gz` and `.whl` are produced
- No `UserWarning: Duplicate name` messages
- Wheel contains everything under `synax_sdk/` and `synax_skill_cli/`
- All `synax_skill_cli/templates/default/*.tmpl` files are present
- `synax_sdk/schema/manifest_v1_0.json` is present
- `synax_sdk/py.typed` is present

### Version consistency

Three places must agree:

| File | Field |
|---|---|
| `synax_sdk/version.py` | `__version__ = "X.Y.Z"` |
| `pyproject.toml` | `version = "X.Y.Z"` (under `[project]`) |
| `uv.lock` | Auto-regenerated by `uv sync` |

```bash
uv run python -c "from synax_sdk import __version__; print(__version__)"
grep -E '^version' pyproject.toml
grep -A1 'name = "synax-sdk"' uv.lock | grep version
```

All three must print the same X.Y.Z.

### CHANGELOG

`CHANGELOG.md` must have an entry for X.Y.Z dated today (no `[Unreleased]` heading covering the new version).

### Install smoke test (optional but recommended)

In a fresh virtualenv on a clean machine:

```bash
python -m venv /tmp/synax-smoke && source /tmp/synax-smoke/bin/activate
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple \
            synax-sdk==X.Y.Z
synax --version          # → synax-sdk X.Y.Z
synax keys generate
synax skill init smoke-test
cd smoke-test
uv sync
uv run synax skill test
uv run synax skill build
```

The `--extra-index-url https://pypi.org/simple` is required because TestPyPI doesn't host the SDK's dependencies (httpx, PyNaCl, etc.).

This is what the build_plan §Milestone 8 acceptance criteria asks for. If it works, you're cleared to promote to PyPI.

---

## Releasing X.Y.Z

### 1. Bump the version

On `main` (or a release branch you intend to merge):

```bash
# synax_sdk/version.py:  __version__ = "X.Y.Z"
# pyproject.toml:        version = "X.Y.Z"
uv sync                              # regenerates uv.lock

# Update CHANGELOG.md — add an `[X.Y.Z] — YYYY-MM-DD` heading
# under [Unreleased] and move the relevant entries down.

uv run pytest                        # double-check
git add synax_sdk/version.py pyproject.toml uv.lock CHANGELOG.md
git commit -m "chore: release X.Y.Z"
```

### 2. Push the commit, wait for CI

```bash
git push origin main
gh run watch
```

CI must be green before tagging.

### 3. Tag and push

```bash
git tag vX.Y.Z -m "Release vX.Y.Z"
git push origin vX.Y.Z
```

**The tag triggers `.github/workflows/publish.yml`.** Do not push the tag if any pre-flight check failed.

### 4. Watch the publish workflow

```bash
gh run watch
```

Expected timeline:

- `build`: 30–60 seconds
- `publish-testpypi`: 15–30 seconds + however long any environment approvals take
- `publish-pypi`: same

### 5. Post-publish validation

```bash
# Wait ~60 seconds for PyPI's CDN to propagate.
python -m venv /tmp/synax-postrelease && source /tmp/synax-postrelease/bin/activate
pip install synax-sdk==X.Y.Z
python -c "from synax_sdk import __version__; assert __version__ == 'X.Y.Z'"
synax --version
synax skill init verify-release
cd verify-release
uv sync && uv run synax skill build
```

### 6. Create the GitHub Release page

```bash
gh release create vX.Y.Z \
  --title "vX.Y.Z" \
  --notes-from-tag \
  --notes-start-tag vPREV.Y.Z
```

Or do it via the GitHub UI: **Releases → Draft a new release → Choose tag vX.Y.Z**. The release notes can mirror the CHANGELOG entry.

---

## Fallback: API tokens

If you don't want to set up OIDC trusted publishing (or it's temporarily broken), the workflow supports API tokens.

### 1. Create API tokens

- PyPI: <https://pypi.org/manage/account/token/> — scope to `synax-sdk` after the first publish.
- TestPyPI: <https://test.pypi.org/manage/account/token/>

### 2. Add as repo secrets

GitHub repo **Settings → Secrets and variables → Actions → New repository secret**:

- `PYPI_API_TOKEN` — the token starting with `pypi-`
- `TEST_PYPI_API_TOKEN` — the TestPyPI token

### 3. Uncomment the `password:` lines

Edit `.github/workflows/publish.yml`. In both `publish-testpypi` and `publish-pypi` jobs, the publish step has commented-out fallback lines:

```yaml
- name: Publish to TestPyPI
  uses: pypa/gh-action-pypi-publish@release/v1
  with:
    repository-url: https://test.pypi.org/legacy/
    # Trusted publishing — no password needed when OIDC is configured.
    # Fallback for API tokens (uncomment + add secret):
    # password: ${{ secrets.TEST_PYPI_API_TOKEN }}
```

Uncomment the last two lines so they become:

```yaml
    password: ${{ secrets.TEST_PYPI_API_TOKEN }}
```

Same for the PyPI job with `PYPI_API_TOKEN`.

You can also keep both — OIDC takes precedence when the `id-token: write` permission is granted. If OIDC fails for any reason, the action falls back to `password:`.

---

## Troubleshooting

### Workflow shows as "failed" with 0 jobs immediately on push

This is **not** cosmetic — it means GitHub rejected the workflow at the deployment-gate stage, before any runner was allocated. The two real causes:

1. **Referenced environments don't exist.** The workflow has `environment: testpypi` and `environment: pypi` blocks. On private org repos, GitHub won't auto-create them — you must add them in advance under **Settings → Environments → New environment**. Create one named exactly `testpypi` and one named exactly `pypi`. The `gh` equivalent: `gh api -X PUT repos/<owner>/<repo>/environments/testpypi`.

2. **PyPI trusted publisher not configured.** Even with environments present, `pypa/gh-action-pypi-publish` will fail (with a real check-run, not a 0-job failure) unless the trusted publisher relationship is registered on PyPI/TestPyPI for `(owner, repo, workflow=publish.yml, environment=pypi|testpypi)`.

Both must be in place before the first OIDC publish succeeds.

### `pypa/gh-action-pypi-publish` fails with `oidc-error`

Usually one of:

- The `id-token: write` permission is missing from the job. Check that the job has:
  ```yaml
  permissions:
    id-token: write
  ```
- The environment name in the workflow (`pypi` or `testpypi`) doesn't match the trusted-publisher configuration on PyPI. Re-check both.
- The trusted publisher specifies a different workflow filename. Must match `publish.yml` exactly.
- The PyPI account hasn't enabled OIDC for this project. See <https://docs.pypi.org/trusted-publishers/>.

### `HTTPError: 400 Bad Request — File already exists`

PyPI doesn't allow overwriting an existing version. You either:

- Bump to a new version (most common — bump to `X.Y.Z+1` and tag again).
- Yank the existing release if it was a mistake (see [§ Yanking a bad release](#yanking-a-bad-release)).

PyPI never allows you to *re-upload* the same version, even after yanking. Versions are immutable in PyPI's model.

### `uv build` emits `UserWarning: Duplicate name`

Hatchling's `[tool.hatch.build.targets.wheel] packages = [...]` auto-includes everything under the package paths. Adding a `[tool.hatch.build.targets.wheel.force-include]` entry for the same path causes duplicate inclusion. We hit this once during M7-1 development. The fix is to delete the redundant `force-include` block — the `packages =` rule already covers data files.

### TestPyPI install fails with missing dependencies

TestPyPI hosts only `synax-sdk` itself, not its dependencies. When testing an install from TestPyPI, always include the real PyPI as a fallback index:

```bash
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple \
            synax-sdk==X.Y.Z
```

### CI run on the tag push doesn't trigger

Confirm:

- The tag matches `v*.*.*` (e.g. `v0.1.0`, not `0.1.0` or `release-0.1.0`).
- The tag was pushed (`git push origin vX.Y.Z`, not just `git tag`).
- The workflow file `.github/workflows/publish.yml` exists on the commit the tag points at.

### Permission denied uploading to PyPI

The trusted publisher is configured for a different repo / workflow / environment. The error message lists exactly what PyPI saw vs what was configured. Fix the mismatch on either side; the trusted-publisher record is the easier one to update.

---

## Yanking a bad release

If a release goes out and you discover a problem (broken wheel, missing files, security issue), **yank** rather than delete. Yanking marks a version as "do not install by default" without removing it — existing installs keep working, but `pip install synax-sdk` won't pick it up.

### On PyPI

1. Go to <https://pypi.org/manage/project/synax-sdk/releases/>.
2. Find the bad release, click "Yank release".
3. Provide a reason — it shows up next to the version on PyPI.

Users can still explicitly request the yanked version (`pip install synax-sdk==X.Y.Z`) but won't get it implicitly.

### Then ship the fix

1. Bump version to `X.Y.(Z+1)`.
2. Fix the issue, commit, tag, push as normal.
3. The CHANGELOG entry for the new version should call out the yanked one ("Fixes the broken wheel from X.Y.Z which has been yanked").

---

## Versioning policy

Pre-1.0 (current):

- **MAJOR.MINOR.PATCH** with patch bumps for bugfix-only releases, minor bumps for new features, and breaking changes allowed in minor versions per `docs/technical_plan.md` § 1.8.
- The vendored manifest schema version (`docs/manifest_spec.md`) is tracked separately from the SDK version.

Post-1.0:

- Strict semver. Breaking API changes require a major bump.
- Schema versions follow the platform's schema, not the SDK version directly.

---

## Required reading before your first release

- This document
- `CHANGELOG.md` — confirm the entry for X.Y.Z is accurate and complete
- `docs/build_plan.md` § Milestone 8 — what 0.1.0 contains
- `.github/workflows/publish.yml` — what the automation actually does

---

## Quick reference

| Action | Command |
|---|---|
| Trigger the manual TestPyPI-only dry run | `gh workflow run publish.yml --field test_only=true` |
| Trigger a real release | `git tag vX.Y.Z && git push --tags` |
| Watch the publish workflow | `gh run watch` |
| Inspect produced artifacts before tagging | `uv build && ls dist/ && python -m zipfile -l dist/*.whl` |
| Check published version | `pip index versions synax-sdk` |
| Yank a bad release | PyPI web UI → project → Releases → Yank |
| Where the secrets live (if using fallback) | repo Settings → Secrets and variables → Actions |
| Where trusted publishers are configured | PyPI/TestPyPI → project settings → Publishing |

---

*This document supersedes any informal release notes. Update it whenever the workflow file or release process changes.*
