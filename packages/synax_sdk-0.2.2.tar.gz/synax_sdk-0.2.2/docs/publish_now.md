# Publishing — quick reference

Day-to-day release commands. For one-time setup (PyPI accounts, trusted publishers, GitHub environments), see `publish_sdk.md`.

The branch-aware `publish.yml` routes tags based on where the tagged commit lives:

| Tag pushed on… | Goes to… |
|---|---|
| `dev` | TestPyPI |
| `main` | PyPI |
| Neither | Workflow fails fast |

Pre-release validation happens on `dev`. Final releases happen on `main`.

---

## Versioning convention

| Branch | Tag format | Example | Visibility |
|---|---|---|---|
| `dev` | `vX.Y.Z<pre>` | `v0.3.0rc1`, `v0.3.0rc2` | TestPyPI; `pip install` ignores unless `--pre` |
| `main` | `vX.Y.Z` (clean) | `v0.3.0` | PyPI; default `pip install` target |

PEP 440 pre-release suffixes (`rc1`, `rc2`, `a1`, `b1`) let you iterate freely on dev without colliding on TestPyPI (which is immutable like PyPI). The clean `vX.Y.Z` is reserved for the main-branch release.

---

## Dev release → TestPyPI

Run from a clean `dev` working copy with all tests green locally.

```powershell
git checkout dev

# 1. Bump version (synax_sdk/version.py + pyproject.toml) to X.Y.ZrcN
#    Update CHANGELOG.md [Unreleased] entries
git commit -am "chore(release): vX.Y.ZrcN"

# 2. Tag and push (commit + tag in one go)
git tag -a vX.Y.ZrcN -m "vX.Y.ZrcN"
git push origin dev --follow-tags

# 3. Watch the workflow
gh run watch
```

The workflow:
- Detects target = `testpypi` (commit is on `dev`, not on `main`)
- Builds `dist/synax_sdk-X.Y.ZrcN-*`
- Publishes to TestPyPI via OIDC

Validate the install:

```powershell
python -m venv $env:TEMP\synax-rc
& "$env:TEMP\synax-rc\Scripts\Activate.ps1"
pip install --index-url https://test.pypi.org/simple/ `
            --extra-index-url https://pypi.org/simple `
            --pre `
            synax-sdk==X.Y.ZrcN
python -c "from synax_sdk import __version__; print(__version__)"
synax --version
deactivate
```

If anything is wrong, iterate: bump to `rc2`, commit, tag, push. The previous `rcN` stays on TestPyPI as historical record.

---

## Main release → PyPI

Once a dev `rcN` is validated and you're ready to ship for real:

```powershell
# 1. Merge dev into main
git checkout main
git merge --no-ff dev -m "Release vX.Y.Z"

# 2. Bump version to the clean X.Y.Z (strip the rcN suffix)
#    Update CHANGELOG.md — promote [Unreleased] entries under [X.Y.Z] — YYYY-MM-DD
git commit -am "chore(release): vX.Y.Z"

# 3. Tag and push
git tag -a vX.Y.Z -m "vX.Y.Z"
git push origin main --follow-tags

# 4. Watch the workflow
gh run watch
```

The workflow:
- Detects target = `pypi` (commit is on `main`)
- Builds `dist/synax_sdk-X.Y.Z-*`
- Publishes to PyPI via OIDC

Validate the install:

```powershell
# Wait ~60s for PyPI's CDN to propagate
python -m venv $env:TEMP\synax-release
& "$env:TEMP\synax-release\Scripts\Activate.ps1"
pip install synax-sdk==X.Y.Z
python -c "from synax_sdk import __version__; assert __version__ == 'X.Y.Z'"
synax --version
deactivate
```

Then make the GitHub Release page visible:

```powershell
gh release create vX.Y.Z --title "vX.Y.Z" --notes-from-tag
```

---

## After main lands — sync dev back

`main` is now ahead of `dev` (the version bump from `X.Y.ZrcN` → `X.Y.Z` happened on main). Merge it back so dev doesn't drift:

```powershell
git checkout dev
git merge main
git push origin dev
```

Now `dev` and `main` are equal again. Start the next cycle on dev.

---

## Common gotchas

**"File already exists" from TestPyPI on a dev push.** You re-used a version that already shipped. Bump to the next `rcN` and tag again. TestPyPI versions are immutable — same rule as PyPI.

**"Tag commit is on neither main nor dev" workflow error.** You tagged a commit that exists on a feature branch but not `dev` or `main`. Either merge the branch into `dev` first, or use `workflow_dispatch` (`gh workflow run publish.yml --field target=testpypi`) to publish manually.

**The workflow runs but skips both publish jobs.** The `detect-target` job didn't set an output. Check the workflow log — most likely the tagged commit's branch containment check failed because `actions/checkout` ran with shallow history. The workflow needs `fetch-depth: 0` on the detect-target job.

**Dev published `0.3.0rc1` but main wants to publish `0.3.0`.** That's the whole point of the pre-release suffix — TestPyPI keeps the `rcN` builds, PyPI gets the clean version. No collision.

**Forgot to bump version before tagging.** The build will succeed but upload to PyPI/TestPyPI fails with "File already exists" (for a re-used version) or you'll publish under the wrong number. Always check `pyproject.toml` and `synax_sdk/version.py` agree on the new version *before* `git tag`.

---

## Quick reference

| Task | Command |
|---|---|
| Dev pre-release | `git tag -a vX.Y.ZrcN -m vX.Y.ZrcN && git push origin dev --follow-tags` |
| Main release | `git tag -a vX.Y.Z -m vX.Y.Z && git push origin main --follow-tags` |
| Watch a run | `gh run watch` |
| Manual dispatch | `gh workflow run publish.yml --field target=testpypi` (or `=pypi`) |
| Check published versions | `pip index versions synax-sdk` |
| Sync dev after main release | `git checkout dev && git merge main && git push origin dev` |
