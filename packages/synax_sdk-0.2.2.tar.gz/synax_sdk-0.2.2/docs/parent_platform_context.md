# Parent Platform Context — What Synax Is

**Version:** 0.1
**Audience:** New contributors to this SDK who have not seen the Synax platform
**Purpose:** Standalone context about Synax so this SDK can be built without reading the platform repository

---

## Why This Document Exists

This SDK repository is independent of the Synax platform repository. A developer working on this SDK doesn't necessarily have access to the platform repo or the full design documents that govern it. This document captures everything about Synax that the SDK developer needs to know.

If you're working on this SDK and you've already read the platform's documentation, you can skip this. Otherwise, read this carefully before starting work.

---

## What Synax Is

**Synax** is a multi-agent orchestration platform built by **Synergentic Technologies**. It combines two ideas:

1. **Team communication channels** — like Slack or Discord. Users have organizations, workspaces, groups, and channels. People send messages to each other in channels.

2. **Agentic AI capabilities** — like Claude Code, ChatGPT, or AutoGPT. AI agents (called "bots" in Synax) can be invoked, configured, given memory, given tools, and made to perform multi-step tasks.

The combination is what makes Synax distinctive. Users and AI agents are first-class participants in channels together. You can `@mention` a bot in a channel and it responds. You can have multiple bots collaborating in a channel. You can observe everything they're doing in real time. You can give them tools (called "skills") that let them interact with the world.

### The platform supports:

- **Cloud deployment** — Synergentic-operated SaaS at synax cloud
- **Self-hosted deployment** — customers deploy in their own infrastructure
- **User-owned compute** — local hardware can run inference and execute skills via a daemon

### Key differentiators:

- **Accessibility-first** — the platform is built from the ground up to work well with screen readers and assistive technologies
- **Hybrid deployment** — feature parity between cloud and self-hosted
- **Local model inference** — users can route to models running on their own hardware
- **A trained orchestrator** (in development) — a small language model that learns coordination patterns

---

## The Synax Hierarchy

To understand where skills fit, here's the platform's organizational structure:

```
Organization              (the tenant — typically a company)
  └── Workspace           (a project or product area)
      └── Group           (a logical grouping within a workspace)
          └── Channel     (where conversations happen)
```

**Skills are installed at the workspace level.** A skill is installed once into a workspace and is then available to all channels and bots in that workspace.

---

## What a Skill Is

A **skill** is the platform's extension primitive — it's how bots can do things beyond conversation. Think of skills as the platform equivalent of:

- ChatGPT plugins
- Claude's tools
- AutoGPT's tools
- LangChain's tools

A skill exposes one or more **tools** that bots can invoke. Each tool has:

- A name (e.g., `summarize_pull_request`)
- A description (what it does, when a bot should use it)
- Parameters (typed inputs)
- A return value (typed output)
- An implementation (the code that runs)

When a bot decides to use a tool, the platform:

1. Validates the bot has permission to use this skill
2. Validates the parameters match the schema
3. Looks up any secrets the skill needs (e.g., API keys)
4. Executes the skill in a sandboxed environment
5. Returns the result to the bot
6. Records everything in the run trace for observability

---

## Skill Authoring Tiers

Synax supports two authoring approaches:

### Tier 1 — Manifest-only skills

For simple skills that just call HTTP endpoints, transform data, or compose pre-built operations. These are defined entirely in YAML and don't require any custom code. The platform interprets the manifest at execution time.

**This SDK does NOT generate manifest-only skills.** Those are written directly as YAML and don't need a code-based authoring tool.

### Tier 2 — Code-based skills

For sophisticated skills that need custom Python (or eventually TypeScript) code. The skill author writes a Python module using this SDK; the SDK generates the manifest from the decorated code and packages it for distribution.

**This is what this SDK is for.** Everything in this repository is about making Tier 2 skill development excellent.

---

## The Skill Lifecycle

A skill's life from authoring to execution:

1. **Author writes the skill** using this SDK's API (decorators, type hints, business logic)
2. **Author runs `synax skill build`** which generates the manifest and packages the skill with signing
3. **Author runs `synax skill publish --target <platform-url>`** which uploads to the platform's marketplace
4. **A workspace admin installs the skill** through the platform's marketplace UI or API
5. **A bot is configured to have access to the skill** by including it in the bot's allow-list
6. **A bot invokes the skill** by calling one of its tools mid-run
7. **The platform routes the execution** to either the cloud or a daemon (per the skill's manifest and customer policy)
8. **The skill runs in a sandbox** with controlled access to filesystem, network, secrets
9. **The skill returns a result** which becomes part of the bot's context

The SDK is involved in steps 1-3. The platform handles 4-9.

---

## Trust and Tiers

Synax has a tiered trust model for skills:

- **Verified** — reviewed by Synergentic; platform signature on the manifest
- **Trusted Publisher** — published by an identity-verified developer; their signature is recognized
- **Community** — anyone can publish; signed only by the author; clearly marked as use-at-your-own-risk
- **Customer Internal** — published privately into an org's internal namespace

The SDK signs manifests at build time with the developer's Ed25519 key. Customer policy determines which signatures are required for installation. This SDK doesn't need to know about tiers; it just produces a signed manifest and the platform decides whether to accept it.

---

## What the Platform Provides to Skills

When a skill is executing, it has access to a controlled set of platform capabilities:

### Secrets

Skills request secrets by name. The platform looks up the secret in its secure store, validates the skill has permission, audits the access, and returns the value:

```python
github_token = await secrets.get("GITHUB_TOKEN")
```

Skills declare which secrets they need in their manifest. The platform validates this at install time.

### Logger

Skills can emit structured logs that flow into the platform's observability:

```python
logger.info("Fetched PR", extra={"pr_number": 42})
```

### Metrics (optional)

Skills can record custom metrics:

```python
metrics.counter("github_api_calls").inc()
```

### Platform context

Skills receive a context object with information about the current invocation:

```python
ctx.run_id        # UUID of the run that invoked this skill
ctx.workspace_id  # UUID of the workspace
ctx.invoker       # info about the bot or user that called the skill
```

### Network and filesystem

These are restricted by capabilities declared in the manifest. A skill that declares `network:api.github.com` can only reach that host. A skill that declares `filesystem:read:/data` can only read from that path.

---

## What the Platform Does NOT Provide to Skills

To prevent escape from the sandbox:

- No raw subprocess access (unless declared as a capability)
- No raw filesystem access outside declared paths
- No raw network access outside declared destinations
- No access to other workspaces' data
- No access to platform internals (database, Django ORM, etc.)
- No ability to invoke other skills directly (must go through the platform's tool-calling layer)

The sandbox is enforced at the platform side. The SDK doesn't enforce it — but the SDK should make it natural for skills to be written in ways that comply with sandbox expectations.

---

## What the SDK Targets

The SDK is what skill authors interact with. It needs to:

1. **Make defining skills feel like writing Python** — decorators, type hints, normal async/await
2. **Generate manifests automatically** — authors shouldn't have to write YAML by hand
3. **Provide a great developer experience** — clear errors, good CLI, fast iteration
4. **Hide the complexity of signing, packaging, and publishing** — these should be one-line operations
5. **Enable local testing** — authors should be able to test skills without a running platform

The SDK does NOT need to:

1. **Run skills in production** — the platform does that
2. **Communicate with the daemon directly** — the platform abstracts that
3. **Handle platform authentication** — the platform manages auth for skill execution
4. **Implement the sandbox** — the platform implements it

---

## The Manifest

The manifest is the data structure that describes a skill — what it does, what tools it exposes, what capabilities it needs, who signed it. It's a YAML (or JSON) document that follows a specific schema.

The platform's authoritative schema is in `data_model.md` § 17 in the platform repository. This SDK includes a copy of that schema in [`manifest_spec.md`](./manifest_spec.md) for self-contained reference.

The SDK's job at build time is to:

1. Inspect the decorated Python code
2. Derive the manifest structure from the decorators
3. Validate the manifest against the schema
4. Sign it with the developer's key
5. Package it with the implementation code

---

## Example Skill (What the SDK Should Make Possible)

This is the target developer experience. The SDK should make a skill this readable:

```python
from synax_sdk import Skill, secrets, logger

skill = Skill(
    name="github-pr-summary",
    version="1.0.0",
    description="Fetch and summarize a GitHub pull request",
    capabilities=[
        "network:api.github.com",
        "secrets:GITHUB_TOKEN",
    ],
)

@skill.tool(
    description="Fetch a GitHub pull request and return a structured summary",
)
async def summarize_pr(repo: str, pr_number: int) -> dict:
    """
    Args:
        repo: Repository in format owner/name
        pr_number: Pull request number
    """
    token = await secrets.get("GITHUB_TOKEN")
    # ... fetch from GitHub API, summarize, return ...
    logger.info("Summarized PR", extra={"repo": repo, "pr_number": pr_number})
    return {"title": ..., "summary": ..., "files_changed": ...}


if __name__ == "__main__":
    skill.run()
```

From this code, the SDK should:

- Derive a manifest with one tool: `summarize_pr`
- Extract the tool's parameters from the function signature
- Extract the tool's description from the decorator and docstring
- Capture the capabilities declared on the Skill object
- Generate the manifest YAML
- Allow it to be tested locally
- Allow it to be built, signed, and published

---

## The Wire Format for Publishing

When the SDK publishes a skill to a platform instance, it uses the platform's REST API:

```
POST {platform_url}/api/v1/skills/publish
Content-Type: application/json
Authorization: Bearer <skill_developer_token>

{
  "manifest_yaml": "<the YAML manifest as a string>",
  "manifest_signatures": [
    {
      "key_fingerprint": "...",
      "signer_type": "author",
      "signature": "..."
    }
  ],
  "implementation_artifact": "<base64-encoded archive of the skill code>",
  "implementation_hash": "sha256:..."
}
```

The platform responds with:

```json
{
  "skill_id": "uuid",
  "skill_version_id": "uuid",
  "status": "registered"
}
```

Details of the wire format are in `manifest_spec.md`.

---

## What's Next

Now that you have context on Synax and what this SDK is for, read these in order:

1. [`manifest_spec.md`](./manifest_spec.md) — exactly what the SDK generates
2. [`build_plan.md`](./build_plan.md) — what to build, in what order
3. [`technical_plan.md`](./technical_plan.md) — design decisions and internal architecture

Then begin Milestone 1 from `build_plan.md`.

---

*End of parent platform context*
