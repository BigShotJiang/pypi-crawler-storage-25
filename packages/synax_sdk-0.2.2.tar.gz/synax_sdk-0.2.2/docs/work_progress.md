# Work Progress Journal

A running log of what Claude Code did during autonomous work sessions on the Synax SDK. Newer entries on top within each milestone. Each session/milestone gets a heading and entries describe what was implemented, what went wrong, decisions made, and any open questions.

Read this end-to-end if you're picking up where I left off. If anything in here is marked **STUCK** or **QUESTION** at the top, that's where I need a human decision.

---

## Milestone 8 — Release 0.1.0 to PyPI

**Started:** 2026-05-15
**Completed:** 2026-05-15 (release prepared, awaiting tag push by user)
**Commits:** pre-release polish (CHANGELOG + README + classifier), publishing workflow, version bump + final docs
**Result:** 622 tests passing (1 skipped, POSIX-only), 94.04% coverage. `uv build` produces a clean wheel + sdist with all templates bundled.
**Remaining manual step:** `git tag v0.1.0 && git push --tags`. That triggers `.github/workflows/publish.yml` (build → TestPyPI → PyPI via OIDC trusted publishing).
**Required user setup before first publish:**
1. Configure OIDC trusted publisher on PyPI (https://pypi.org/manage/account/publishing/) and TestPyPI (https://test.pypi.org/manage/account/publishing/) — link the GitHub repo `synergentic/synax-sdk` + workflow `publish.yml` + environments `pypi` / `testpypi`.
2. OR add `PYPI_API_TOKEN` + `TEST_PYPI_API_TOKEN` repo secrets and uncomment the `password:` lines in `publish.yml`.
3. Create the GitHub Environments `pypi` and `testpypi` in repo settings (optional but recommended for deployment history + protection rules).
**Open questions or blockers:** None on the SDK side. Post-release, the platform-side `/api/v1/skills/publish` endpoint still needs to be implemented (carries over from M5).

### Plan

3 commits — final polish + workflow + version bump:

1. **Pre-release polish** — CHANGELOG.md (Keep-a-Changelog format), README.md rewrite (PyPI-visible getting-started), bump Development Status classifier from Pre-Alpha to Alpha.
2. **Publishing workflow** — `.github/workflows/publish.yml` triggered on `v*.*.*` tag push. Build artifacts with `uv build`, publish to TestPyPI then PyPI. Use OIDC trusted publishing (recommended), document API-token fallback.
3. **Version bump + final docs** — `synax_sdk/version.py` 0.1.0.dev0 → 0.1.0, update test that asserts the version, verify `uv build` works locally, mark M8 complete.

### Up-front decisions

- **I will NOT push to actual PyPI.** That requires the user's API tokens or OIDC trusted-publisher setup on PyPI, plus authorization to publish under their account. My job is to prepare everything so the final `git tag v0.1.0 && git push --tags` triggers the workflow and the user takes it from there.
- **I will NOT create the `v0.1.0` git tag.** Tagging is the user's call once they've reviewed the bumped version and the workflow. Tags are conventionally hard-to-undo and tied to release ownership.
- **OIDC trusted publishing** is the recommended publish path — no secret tokens in GitHub. The workflow uses `pypa/gh-action-pypi-publish@release/v1` with `id-token: write` permission and no `password:` arg. Users configure the trusted-publisher relationship on their PyPI / TestPyPI project once. Fallback to `secrets.PYPI_API_TOKEN` is documented in a comment so users without OIDC set up can still ship.
- **Publish to TestPyPI first** for every tagged release as a safety gate. If TestPyPI fails, PyPI doesn't run.
- **`workflow_dispatch`** also wired up for manual runs (TestPyPI only). Useful for pre-release validation without creating a real tag.
- **Development Status: 3 - Alpha** for 0.1.0. We have working CLI, tests, and end-to-end flow; "Pre-Alpha" understates the maturity.
- **CHANGELOG.md** uses Keep-a-Changelog format. 0.1.0 entry summarizes the M1-M7 deliverables grouped by category (Added / Tooling / Documentation).

### Entries

#### 2026-05-15 — M8 Commit 3: version bump 0.1.0.dev0 → 0.1.0

**Three small file changes**:

- `synax_sdk/version.py`: `__version__ = "0.1.0.dev0"` → `"0.1.0"`.
- `pyproject.toml`: `version = "0.1.0.dev0"` → `"0.1.0"`.
- `tests/unit/test_placeholder.py`: renamed `test_version_string_is_dev` to `test_version_string_is_pinned` and updated the asserted value.

**`uv build` verification**:

First attempt printed `UserWarning: Duplicate name` for every `.tmpl` file. Cause: `[tool.hatch.build.targets.wheel] packages = ["synax_skill_cli"]` auto-includes everything under the path, AND I had also added an explicit `[tool.hatch.build.targets.wheel.force-include]` block in M7 Commit 1 — duplicate inclusion. Removed the force-include block; the default `packages =` rule picks up data files automatically.

After the fix:

```
Successfully built dist\synax_sdk-0.1.0.tar.gz
Successfully built dist\synax_sdk-0.1.0-py3-none-any.whl
```

Wheel inspection (`python -m zipfile -l dist/synax_sdk-0.1.0-py3-none-any.whl`) confirms:

- All seven `.tmpl` files under `synax_skill_cli/templates/default/` are present.
- The JSON Schema `synax_sdk/schema/manifest_v1_0.json` is present.
- `synax_sdk/py.typed` marker present.
- Every source module ships.

**Docs updates** in this commit:

- `CLAUDE.md` — Current Status: all 8 milestones complete; included the to-release-from-here checklist.
- `docs/build_plan.md` — Current Status + summary table + Milestone 8 heading marked done with implementation notes (including the duplicate-name fix and OIDC trusted-publishing details).
- `docs/work_progress.md` — closed out M8 section with all-commit summary, the manual tag-push steps the user needs to run, and the required PyPI / TestPyPI OIDC setup pointers.

All checks green: ruff, black, isort, mypy strict (35 source files), **622 tests passed (1 skipped), 94.04% coverage**. `uv build` produces a clean wheel + sdist.

---

#### 2026-05-15 — M8 Commit 2: PyPI publishing workflow

`.github/workflows/publish.yml` (~100 lines). Trigger: `v*.*.*` tag push, plus `workflow_dispatch` for manual TestPyPI-only runs.

**Three jobs in sequence**:

1. **`build`** — checkout, install uv, sync deps, `uv build` to produce both wheel and sdist, upload as a GitHub Actions artifact named `dist`.
2. **`publish-testpypi`** — depends on `build`, downloads the artifact, publishes to TestPyPI via `pypa/gh-action-pypi-publish@release/v1`. Uses GitHub Environments (`testpypi`) for the deployment view + auditability.
3. **`publish-pypi`** — depends on `publish-testpypi` (so any TestPyPI failure halts the run). On `workflow_dispatch` with `test_only=true`, this job is skipped via an `if:` condition.

**OIDC trusted publishing** is the primary path — both publish jobs have `permissions: id-token: write` and call the action with no `password:`. The user configures the trusted publisher relationship once on PyPI / TestPyPI by linking the repo + workflow + environment. Fallback for API tokens is left as commented-out lines in the YAML with a pointer to where to add `secrets.PYPI_API_TOKEN` / `secrets.TEST_PYPI_API_TOKEN`.

**Workflow design notes**:

- `workflow_dispatch.inputs.test_only` (boolean, default `true`) lets the user manually validate the publish pipeline against TestPyPI without creating a real tag.
- GitHub Environments (`testpypi`, `pypi`) are set with the package URL so the Actions UI shows the right link on each deployment.
- Inspecting the wheel listing with `python -m zipfile -l` gives a quick sanity check of bundled files in the workflow logs — especially useful for confirming `synax_skill_cli/templates/*.tmpl` are in the wheel.
- `actions/upload-artifact` retention is 7 days; long enough for debugging if PyPI rejects the upload, short enough not to bloat storage.
- `if-no-files-found: error` on upload guards against silent `uv build` failures.

**No code changes outside the workflow file** — all 622 tests still pass; ruff clean.

---

#### 2026-05-15 — M8 Commit 1: pre-release polish

**`CHANGELOG.md`** (~150 lines, Keep-a-Changelog format):

- `[0.1.0]` entry summarizes the M1-M7 deliverables grouped into seven sections: Skill authoring API, Manifest generation, Runtime API, Build pipeline, Publishing, Local testing, CLI. Each section lists what's available with the minimum context a new user needs to understand the scope.
- Section "Tooling" calls out Python version, package management, lint/type/test stack.
- Section "Documentation" lists every doc in the repo with one-line descriptions.
- `[Unreleased]` placeholder at top for future entries.
- Compare-links at bottom (currently point at non-existent tag — the v0.1.0 tag gets created by the user as the final step).

**`README.md`** rewritten as a PyPI-first getting-started doc. The previous version pointed at `docs/`, which PyPI users won't see. The new version:

- Badge row (CI, PyPI version placeholder, Python versions, license).
- One-paragraph "what is this" hook.
- `pip install synax-sdk` quick install.
- Quick-start command sequence (`keys generate` → `skill init` → `uv sync` → `skill test` → `skill build` → `skill publish`).
- A "what a skill looks like" code sample that mirrors the parent_platform_context example.
- Two testing patterns side-by-side (declarative YAML + pytest fixtures).
- CLI command tree summary.
- Status callout flagging "0.1.0 initial release; pre-1.0 minor versions may break API".
- Links back into the in-repo docs.
- Development commands for contributors.

**`pyproject.toml`** classifier bumped from `Development Status :: 2 - Pre-Alpha` to `Development Status :: 3 - Alpha`. We have working CLI, tests, end-to-end flow; "Pre-Alpha" understates the maturity.

**No problems** — all 622 tests still pass, lint/type/format all clean.

---

## Milestone 7 — Project init template

**Started:** 2026-05-15
**Completed:** 2026-05-15
**Commits:** templates + renderer, `skill init` CLI, integration tests + docs
**Result:** 622 tests passing (1 skipped, POSIX-only), 94.04% coverage. templating.py at 91%, skill.py at 83% (gap is build/publish/verify paths exercised by their own test files).
**Open questions or blockers:** None. The end-to-end loop now works: `synax skill init` → `synax skill build` → `synax skill publish`. Ready to move to Milestone 8 (release 0.1.0 to PyPI — version bump, CHANGELOG, publishing workflow on tag push).

### Plan

3 commits:

1. **Templates + renderer** — `synax_skill_cli/templates/default/*.tmpl` (pyproject.toml, skill module, README, .gitignore, .synax-skillignore, sample pytest test, sample declarative test case) + `synax_skill_cli/utils/templating.py` with `render_template_dir()` driven by `string.Template`. Tests for substitution, file creation, escaping `$` literals.
2. **`synax skill init` CLI** — replace M1 stub in `commands/skill.py`. Flags: `--output`, `--author`, `--version`, `--no-git`. Detects `git config user.name` for author defaulting. CLI tests with CliRunner.
3. **Integration test + docs** — generates a project end-to-end, runs `synax skill build` on it to verify it actually works (the acceptance criterion). Mark M7 done.

### Up-front decisions

- **Templating uses `string.Template`** (stdlib, `$variable` syntax) — no new dep on Jinja2. Use case is just a handful of variable substitutions; full templating power isn't needed. `$$` escapes a literal `$`.
- **Variables**:
  - `skill_name` — the slug as the user typed it ("my-new-skill")
  - `skill_name_snake` — Python identifier ("my_new_skill"); used for the module filename and entry_point
  - `skill_name_human` — display form ("My New Skill")
  - `author_name` — defaults to `git config user.name`, then "Skill Author" if git not configured
  - `version` — defaults to "0.1.0"
  - `sdk_version` — auto-stamped from `synax_sdk.__version__` so the generated project pins the SDK it was scaffolded against
- **Skill module is named after `skill_name_snake`** — so `synax skill init github-tools` produces `github_tools.py` with `entry_point = "github_tools:skill"`. Reads better than always-`skill:skill`.
- **`.tmpl` extension on every template file** — keeps ruff/mypy/black from trying to parse them. The renderer strips `.tmpl` when writing the destination.
- **Destination paths in the manifest can themselves contain `$variable`** — that's how we rename the skill module. The renderer substitutes both the file *contents* and the *output path*.
- **Git init**: default is `git init` on the new directory. `--no-git` skips it. Failures to `git init` (e.g. git not installed) are surfaced as warnings, not errors — the rest of the scaffolding works fine without it.
- **Target directory must not exist**: refuse to overwrite. Authors run `synax skill init my-skill --output ./elsewhere` if they need a different target name.

### Entries

#### 2026-05-15 — M7 Commit 2: `synax skill init` CLI command

Replaced the M1 stub with a real implementation.

**Flags**:
- `name` (positional) — slug-format skill name
- `--output` / `-o` — target directory (default: `<name>/` under cwd)
- `--author` — overrides git lookup
- `--version` — initial version (default `0.1.0`)
- `--git` / `--no-git` — controls `git init` in the new directory

**Behaviour**:
- Validates the skill name against `^[a-z0-9][a-z0-9-]{0,127}$`. Bad names get a clear error.
- Target directory must not exist or must be empty (refuses to overwrite).
- Author defaults to `git config user.name`, then `"Skill Author"`.
- `_git_user_name()` and `_git_init()` are thin subprocess wrappers that tolerate missing-git / timeout / OSError gracefully (return `None` / `False`).
- Builds the substitution dict (slug + snake + human + author + version + sdk_version) and renders the default template.
- If `--git` (default), runs `git init` and prints "initialised git repository". If that fails, prints a yellow warning but still exits 0 (the project files are complete; git is a convenience).
- Prints the "To get started: cd … / uv sync / uv run synax skill test / uv run synax skill build" banner.

`test_placeholder.py` STUB_COMMANDS list is now down to just the `config get/set` placeholders.

**Tests (18 in `test_cli_init.py`):**

- Happy: default path, custom `--output`, explicit `--author`, git user name auto-detected, fallback author "Skill Author", explicit `--version`, skill name translated to snake_case (`github-pr-tools` → `github_pr_tools.py` + entry_point), human form in README, `git init` runs when enabled, git init failure warns but exits 0, next-steps banner printed, SDK version pinned in pyproject.
- Errors: invalid slug rejected, uppercase rejected, existing non-empty directory rejected, empty existing directory allowed.
- **End-to-end loadability**: after `init`, runs `find_project_root` + `load_skill_from_project` against the generated tree, confirms the skill loads with the right name and the `greet` tool. Then runs the bundled declarative case via `run_all()` and asserts it passes — strongest proof that the template actually works.
- Git availability: `_git_user_name` / `_git_init` handle `FileNotFoundError` (git missing) cleanly.

**Problems encountered and fixed:**

1. **Ruff `N812`** — `from synax_sdk.version import __version__ as _SDK_VERSION` (lowercase imported as uppercase). Switched to `from synax_sdk import version as _version_module` and referenced `_version_module.__version__` — same pattern used elsewhere in the codebase.
2. **Three ruff `S603`/`RUF100`** — I added `# noqa: S603` annotations to the `subprocess.run` calls preemptively, but `S603` ("untrusted input") isn't actually enabled in our ruff config, so RUF100 flagged them as unused. Removed via `ruff --fix`.
3. **Ruff `F541`** — one f-string had no placeholders (`f"  [yellow]⚠[/yellow] couldn't run \`git init\` (git not installed?) — "`). Auto-fixed to a regular string.
4. **Two black-format passes** auto-applied.

All checks green: ruff, black, isort, mypy strict (35 source files), **617 tests passed (1 skipped), 94.04% coverage**. skill.py at 83% (the gap is build/publish/verify/info paths exercised by their respective test files, not init).

---

#### 2026-05-15 — M7 Commit 1: templates + renderer

**Template tree** at `synax_skill_cli/templates/default/`:

- `pyproject.toml.tmpl` — `[project]` metadata, `synax-sdk` dependency pinned by `>=$sdk_version`, `[tool.synax].entry_point = "${skill_name_snake}:skill"`, `[tool.pytest.ini_options].asyncio_mode = "auto"`, hatchling build backend.
- `skill.py.tmpl` — example skill with one `greet` tool that uses `secrets.get` and `logger.info`. Demonstrates the runtime API end-to-end.
- `README.md.tmpl` — getting-started instructions + project layout.
- `.gitignore.tmpl` — Python defaults + `.synax/`.
- `.synax-skillignore.tmpl` — comprehensive ignore list.
- `tests/test_skill.py.tmpl` — pytest-based example using the auto-loaded `synax_mock_platform` + `synax_skill_under_test` fixtures + `run_tool_async`.
- `test_inputs/greet/case_basic.yaml.tmpl` — declarative test case demonstrating `expected_output` + `expected_secret_accesses` + `expected_logs`.

**`synax_skill_cli/utils/templating.py`** (~90 lines):

- `TEMPLATE_MANIFEST` — explicit tuple of `(source_path, dest_path_template)` pairs. Both source and destination paths can reference `$variable` — that's how the skill module gets renamed to `${skill_name_snake}.py`.
- `RenderedFile(source, destination)` — frozen dataclass returned per file.
- `render_template_dir(output_dir, variables, template_name="default") -> list[RenderedFile]` — top-level entry point. Refuses to overwrite non-empty directories.
- `TemplateError` for missing variables, missing templates, missing template files, non-empty output dirs.

**`pyproject.toml` changes**:

- `[tool.hatch.build.targets.wheel.force-include]` adds `synax_skill_cli/templates` so the `.tmpl` files definitely ship in the wheel.
- ruff `extend-exclude`, mypy `exclude`, black `extend-exclude` all skip `synax_skill_cli/templates/` so the templating tools don't try to parse `.tmpl` files as Python.

**Tests (15 in `test_templating.py`):**

- Creates every expected file in the right relative location.
- Returns RenderedFile instances in manifest order.
- pyproject.toml has all variables substituted (skill_name, version, author, entry_point, sdk_version).
- Skill module file is renamed via `${skill_name_snake}` — `my_skill.py` exists; literal `${skill_name_snake}.py` doesn't.
- Skill module contents substituted, AND the f-string `{greeting}, {name}` passes through unchanged (regression test: easy to accidentally treat `{...}` as a template placeholder).
- Nested directories (`tests/`, `test_inputs/greet/`) created correctly.
- `.synax-skillignore` and `.gitignore` rendered with expected content.
- Missing variable → `TemplateError` with the variable name.
- Non-empty output directory refused.
- Empty (but existing) output directory accepted.
- Unknown template name → error.
- Manifest invariants: every source ends with `.tmpl`, no destination does.

**No problems encountered** beyond one ruff `I001` autofix on the test file's import order. Template render is deterministic and produces a fully-working skill project on first try.

All checks green: ruff, black, isort, mypy strict (35 source files; templates correctly excluded), **600 tests passed (1 skipped), 94.15% coverage**. templating.py at 91% — the missing 9% is the FileNotFoundError + ValueError paths that only fire on package-shipping bugs that can't be triggered from a normal install.

---

## Milestone 6 — Local testing infrastructure

**Started:** 2026-05-15
**Completed:** 2026-05-15
**Commits:** pytest plugin + runners, declarative runner, `skill test` CLI, integration tests + docs
**Result:** 586 tests passing (1 skipped, POSIX-only), 94.20% coverage. declarative.py + runners.py at 100%; pytest_plugin.py at 50% locally (the fixture bodies run inside pytester sub-processes and aren't visible to the outer coverage collector — effectively integration-tested through pytester outcome assertions).
**Open questions or blockers:** None. Ready to move to Milestone 7 (project init template — `synax skill init <name>` scaffolding a working skill project from a template).

### Plan

4 commits:

1. **pytest plugin + runners** — `synax_sdk/testing/runners.py` with `run_tool()` (handles sync + async tools); `synax_sdk/testing/pytest_plugin.py` exposing `synax_mock_platform` and `synax_skill_under_test` fixtures. Wired via `pyproject.toml [project.entry-points.pytest11]` so `pip install synax-sdk` brings the fixtures in.
2. **Declarative test runner** — `synax_sdk/testing/declarative.py` that loads `test_inputs/<tool>/case_*.yaml` files, resolves secrets (per-case + `secrets.yaml` at directory level), invokes each tool against a `MockPlatform`, evaluates expectations (`expected_output` / `expected_output_schema` / `expected_logs` / `expected_secret_accesses` / `expected_capability_uses` / `should_raise`), and returns structured pass/fail results.
3. **`synax skill test` CLI** — replace the M1 stub with a real implementation using the declarative runner. `--tool` and `--filter` flags. Rich output with timings + per-case diagnostics.
4. **Integration test + docs** — `tests/integration/test_m6_acceptance.py` covering both authoring patterns; brief `docs/testing_skills.md` with examples; status updates.

### Up-front decisions (taken without asking the user)

- **`run_tool(tool, **inputs)` always returns an awaitable internally and unwraps with `asyncio.run` when called from sync code**. Sync tools are invoked directly. The runner adapts so callers don't need to know which kind of tool they have.
- **Declarative test case schema** — superset of the build_plan §M6 example:
  - `input` (dict, required) — keyword arguments to the tool
  - `secrets` (dict, optional) — name → value; merged with `secrets.yaml` (per-case wins)
  - `context` (dict, optional) — overrides for `MockPlatform.context.set(...)`
  - `expected_output` (any, optional) — exact-equality check
  - `expected_output_schema` (JSON Schema dict, optional) — validates the return value
  - `expected_logs` (list, optional) — items can have `level`, `message_contains`, `message_equals`, `extra_contains`
  - `expected_secret_accesses` (list of names, optional)
  - `expected_capability_uses` (list of capability strings, optional — *advisory*, not enforced)
  - `should_raise` (exception class name, optional) — for negative-path testing
- **Test discovery layout**: walk `test_inputs/`, subdirectories = tool names, `*.yaml` files = test cases, `secrets.yaml` at each directory level = shared secrets (closest scope wins). YAML files starting with `_` are treated as helpers and skipped.
- **`synax skill test` is standalone** — doesn't shell out to pytest. The pytest plugin (`synax_mock_platform`, `synax_skill_under_test`) is for authors who *want* to write pytest-based tests; the declarative runner is for "just write some YAML and go".
- **Pytest plugin registration** via `[project.entry-points.pytest11]` so it auto-loads on `pip install synax-sdk`. Authors don't need to add anything to `conftest.py`.
- **Capability checks are advisory** — `expected_capability_uses` is recorded for documentation but not actually validated against runtime capability checks (those happen on the real platform, not in the local mock).

### Entries

#### 2026-05-15 — M6 Commit 3: `synax skill test` CLI command

Replaced the M1 stub in `synax_skill_cli/commands/skill.py` with a real implementation using the declarative runner from M6-2.

**Flags**:
- `--tool` — filter to one tool's cases (exact name match)
- `--filter` / `-f` — filter cases by substring in the case name
- `--inputs` — override the default `test_inputs/` directory

**Behaviour**:
- Loads the skill from the current project (`find_project_root` → `load_skill_from_project`).
- No `test_inputs/` directory → warning + exit 0 (nothing to run is success).
- No matching cases after filtering → warning + exit 0.
- Each case prints `✓ tool/case — PASS (Nms)` or `✗ tool/case — FAIL (Nms)` followed by indented failure messages (or the first six lines of an unexpected-exception traceback).
- Exits 1 if any case failed; exits 0 otherwise.

`test_placeholder.py` STUB_COMMANDS list shrank further — only `skill init` and `config get/set` remain stubs.

**Tests (12 in `test_cli_test.py`):**

- Happy paths: no `test_inputs/` (warn + exit 0), one passing case, multiple passing cases, `--tool` filter to non-existent tool, `--filter` narrows to one case, `--inputs` overrides the directory.
- Failure modes: failing case exits 1 with FAIL output, malformed case YAML exits 1 with parse error, no project found exits 1, failure diagnostics printed.

**No problems** beyond a single black-format pass.

All checks green: ruff, black, isort, mypy strict (34 source files), **581 tests passed (1 skipped), 94.20% coverage**.

---

#### 2026-05-15 — M6 Commit 2: declarative test case runner

`synax_sdk/testing/declarative.py` (~290 lines):

- `TestCase` frozen dataclass — one parsed case ready to run.
- `CaseResult` frozen dataclass — pass/fail outcome with failures list, optional error (for unexpected exceptions), duration, and a `.label` property like `"tool/case"`.
- `discover_cases(test_inputs_dir, skill)` — walks the directory, returns the list of cases. Subdirectories are tool names; `*.yaml` files are cases. `secrets.yaml` at root and per-tool level merge; per-case `secrets` overrides everything.
- `run_case(case, skill)` — sets up `MockPlatform`, invokes the tool, evaluates expectations, returns `CaseResult`.
- `run_all(skill, test_inputs_dir, *, filter_tool=None, filter_case=None)` — discover + run + filter.

Supported expectations:

- `expected_output` (exact `==` match; `None` is meaningful)
- `expected_output_schema` (JSON Schema validation via `jsonschema.Draft202012Validator`)
- `expected_logs` (list of matchers, each with optional `level`, `message_contains`, `message_equals`, `extra_contains`)
- `expected_secret_accesses` (list of secret names that must have been requested)
- `expected_capability_uses` (list of capability strings; **advisory only** — not enforced locally)
- `should_raise` (exception class name; matched against `type(exc).__name__`)

Async + sync tools both work — `_invoke()` dispatches with `asyncio.run` for async tools.

`TestCaseError` (extends `SynaxSDKError`) is raised for malformed YAML, unknown tools, bad field types.

**Tests (37 in `test_declarative.py`):**

- Discovery: missing dir → empty; non-directory → error; tool subdirs walked; unknown tool dir → error; `secrets.yaml` at root + tool + case (precedence); `_`-prefixed files skipped; non-YAML files ignored; malformed YAML → error; non-mapping top-level → error; bad field types (secrets/input as non-mapping etc.) → error.
- `run_case`: simple pass, failure mismatch, async tool with secrets + logs + expected accesses, `expected_output: null` is meaningful, no expected_output → no check, runtime exception is reported as `.error` not `.failures`.
- `expected_output_schema`: pass + mismatch.
- `should_raise`: matching exception passes; wrong type fails; returning instead of raising fails.
- `expected_logs`: `message_contains`, `message_equals`, `extra_contains` all work; no match → failure.
- `expected_secret_accesses`: missing access → failure with the secret name in the message.
- `run_all`: returns all discovered cases, `filter_tool` / `filter_case` filters narrow the set.
- `CaseResult.label` formatting.

**Problems encountered and fixed:**

1. **Ruff `RUF100`** on a stale `# noqa: BLE001` directive — the rule isn't enabled in our config, so the noqa is unused. Removed; the `except BaseException` is fine because we re-classify the caught exception into the structured `error` field of `CaseResult`.
2. **One black-format pass** after writing.

All checks green: ruff, black, isort, mypy strict (34 source files), **572 tests passed (1 skipped), 94.39% coverage**. declarative.py covered well by the new test file.

---

#### 2026-05-15 — M6 Commit 1: pytest plugin + runners

`synax_sdk/testing/runners.py` (~40 lines):

- `run_tool(tool, **inputs)` — sync entry point. Async tools are driven with `asyncio.run`; sync tools called directly. Use from sync test code.
- `run_tool_async(tool, **inputs)` — async entry point. Returns awaitable; sync tools called directly (the result isn't awaited since it's already a value). Use from `async def` tests.

`synax_sdk/testing/pytest_plugin.py` (~50 lines):

- `synax_mock_platform` fixture — fresh `MockPlatform` per test, `.activate()` already entered (yields inside the `with` block so runtime API calls just work).
- `synax_skill_under_test` fixture — locates `pyproject.toml [tool.synax]` from `pytestconfig.rootpath`, imports the skill, returns it.

Plugin registered via `pyproject.toml [project.entry-points.pytest11]`. Users get the fixtures automatically on `pip install synax-sdk`.

**Tests:**

- `tests/unit/test_runners.py` (12 tests) — sync + async tools, exception propagation in both directions, kwargs threading, backend-required check.
- `tests/unit/test_pytest_plugin.py` (5 tests) using pytester — each test invokes a fresh pytest in a temp dir to verify the fixtures load, behave correctly per-test, and work together (the project-loaded skill is callable through the activated mock).

**Problems encountered and fixed:**

1. **The pytester sub-test pytest didn't have `asyncio_mode = "auto"`** — async test functions failed with "async def functions are not natively supported". Embedded `[tool.pytest.ini_options] asyncio_mode = "auto"` in the PYPROJECT template used inside pytester so the sub-suite picks it up.
2. **The big one — coverage collapse**. Adding the `pytest11` entry point made pytest auto-load `synax_sdk.testing.pytest_plugin` during its plugin-loading phase. To get there, Python imports `synax_sdk/__init__.py` → `synax_sdk/testing/__init__.py` → etc. — about 80% of the SDK's top-level statements run *before* `pytest-cov` starts measuring. Result: total coverage dropped from 95% to 77%, well below the 80% gate. Two-part fix:
   - **Defer all `synax_sdk` / `synax_skill_cli` imports inside fixture bodies** in `pytest_plugin.py`. The module's top-level imports are now just `pytest` + `TYPE_CHECKING` annotations. Annotations are strings (PEP 563-style via `from __future__ import annotations`), so the SDK isn't imported until a fixture is *used*.
   - **Disable the plugin for our own test suite** via `addopts = ["-p", "no:synax_testing"]` in `pyproject.toml [tool.pytest.ini_options]`. Even with deferred imports, the entry-point still forces `synax_sdk.testing.pytest_plugin` to load (which is fine, it imports nothing now), but more importantly the addopts line guards against future regressions if I ever accidentally hoist an import. End users still get the plugin via their `pip install synax-sdk`; our pytester tests exercise it explicitly in sub-processes.

After the fix: **540 tests passing, 95.27% coverage** — back above the 80% gate.

3. **The `runners.py` async branch test for sync tools** — `await run_tool_async(sync_tool, ...)` is technically `await <plain_value>` which would fail at runtime. The implementation skirts this by checking `tool.is_async` and returning the call result directly without awaiting. The test verifies that this is OK in an async context (no TypeError on awaiting a non-awaitable).

All checks green: ruff, black, isort, mypy strict (32 source files), **540 tests passed, 95.27% coverage**. runners.py at 100% (after deferred-import fix); pytest_plugin.py at 50% locally (the fixture bodies that run inside pytester sub-processes aren't visible to our outer coverage — they're effectively integration-tested through outcome assertions).

---

## Milestone 5 — Publishing to a platform instance

**Started:** 2026-05-15
**Completed:** 2026-05-15
**Commits:** PublishClient + httpx, config support, real publish + register CLI, integration tests + docs
**Result:** 527 tests passing (1 skipped POSIX-only), 95.11% coverage. publishing.py 90%, config.py 97%, CLI command modules 82-98%.
**Open questions or blockers:** None for the SDK side. **Platform side dependency**: `/api/v1/skills/publish` and `/api/v1/keys/register` endpoints don't exist on the Synax platform yet. The SDK has the contract pinned and tested against a mock; when the platform implements the endpoints, this code should work unchanged. Ready to move to Milestone 6 (local testing infrastructure — `synax skill test`, declarative test cases under `test_inputs/`, pytest fixtures).

### Plan

4 commits — smaller than M4:

1. **PublishClient + httpx + errors** — `synax_sdk/publishing.py` with `PublishClient` (httpx-based), `publish()` top-level function, `PublishResult`, progress callbacks, retries on 5xx/network errors. New error types in `errors.py`: `PublishError` base + `PublishAuthError`, `PublishValidationError`, `PublishVersionConflict`, `PublishNetworkError`. Tests use `respx` (already a dev dep) to mock httpx.
2. **Config file support** — `synax_skill_cli/utils/config.py` reading `~/.synax/config.yaml` + project-local `.synax/config.yaml`. Project overrides user. Tests.
3. **Real `skill publish` + `keys register` CLI** — replace the two M1 stubs with real implementations using PublishClient. `SYNAX_PUBLISH_TOKEN` env var fallback. CLI tests with CliRunner + respx.
4. **Integration test + docs** — full build-and-publish acceptance flow against a mock platform server; mark M5 done in CLAUDE.md / build_plan.md.

### Up-front decisions

- **Wire format follows `docs/manifest_spec.md` §Wire Format for Publishing exactly.** Endpoint: `POST {target_url}/api/v1/skills/publish`, body `{"manifest_yaml": str, "implementation_artifact_b64": str, "implementation_hash": str}`, header `Authorization: Bearer <token>`.
- **The platform's publish endpoint doesn't exist yet** (per `build_plan.md` §M5 implementation notes). We document the contract, ship the client, and test against a mock. When the platform side lands, this code should work unchanged.
- **Auth token comes from**: explicit `--token` flag, then `SYNAX_PUBLISH_TOKEN` env var, then `~/.synax/config.yaml :: default_auth_token_env` (an env-var *name* — never store the token value in a config file). Error message points at all three options if none found.
- **Retries**: 3 attempts with exponential backoff (1s, 2s, 4s) on transient failures — network errors and HTTP 5xx. 4xx errors are not retried (they're caller bugs, not transient).
- **`keys register`**: invents an endpoint shape `POST {target_url}/api/v1/keys/register` with `{"public_key_b64", "fingerprint", "namespace"}` and an expected response of `{"registration_id", "status"}`. The platform side will define the real shape later; this is the SDK's tentative contract and is fully replaceable.
- **Progress reporting**: synchronous callback `Callable[[PublishProgress], None]` invoked at stage boundaries. Stages are `"build_in_progress" | "uploading" | "complete"`. Keeping it simple — no per-byte streaming for M5 because the bundle is small (~hundreds of KB) and the artifact is base64-encoded in the request body anyway.
- **`skill publish` default behaviour**: if a `build/signed_bundle/` exists, use it; otherwise build first (via `synax_sdk.build`). `--no-build` errors out if the bundle is missing. `--build` forces a fresh build even if one exists.

### Entries

#### 2026-05-15 — M5 Commit 3: real `skill publish` + `keys register` CLI

Replaced two M1 stub commands with real implementations.

**`synax skill publish`** (`commands/skill.py`):

- `--target` / `--token` / `--key` / `--build` / `--no-build` / `--output` flags.
- Token + target resolution via `resolve_auth_token` / `resolve_target` (M5 config layer) — clear error messages when missing.
- Default behaviour rebuilds the skill before publishing (mirrors `synax skill build`'s output). `--no-build` skips the build but errors out if no existing bundle is present.
- Progress callback prints `uploading: ...` then `complete: ...` from `PublishProgress`.
- On platform errors, formats `PublishError`/`PublishAuthError`/`PublishValidationError`/`PublishVersionConflict`/`PublishNetworkError` from M5 Commit 1.
- Success output: skill_id, skill_version_id, status, marketplace_url (if returned).

**`synax keys register`** (`commands/keys.py`):

- `--namespace` (required), `--target`, `--token`, `--key` flags.
- Defaults to the keystore's active default key if no `--key` given.
- Loads the keypair, base64-encodes the public half, POSTs `/api/v1/keys/register`.
- Prints registration_id and status (typically `pending_approval`).

The `test_placeholder.py` STUB_COMMANDS list shrank further — only `skill init`, `skill test`, and `config get/set` remain stubs.

**Tests (16 in `test_cli_publish.py`) using respx to mock the platform:**

- skill publish happy paths: build-then-publish, --no-build with existing bundle, explicit --token wins over env.
- skill publish failure modes: missing target, missing token, --no-build with no bundle, platform 401 auth failure, platform 409 version conflict.
- keys register happy path; request body shape (namespace, valid base64 public key, sha256 fingerprint).
- keys register failure modes: missing target, missing token, no key + no default, unknown fingerprint, platform auth failure.

Each test uses three fixtures: `project_dir` (cwd-locked, builds the skill in-place), `store` (tmp keystore with one key, patched at both seams), and `isolated_config` (redirects USER_CONFIG_PATH to a non-existent file so real config doesn't bleed in). The `env_token` fixture sets SYNAX_PUBLISH_TOKEN; tests that need to test "no token" omit it.

**No problems** beyond a single black-format pass over the new test files.

All checks green: ruff, black, isort, mypy strict (30 source files), **521 tests passed (1 skipped), 95.07% coverage**. CLI commands: `keys.py` 98%, `skill.py` 82% (the 18% gap is the `init` / `test` / `config` stubs still in place).

---

#### 2026-05-15 — M5 Commit 2: CLI config file support

`synax_skill_cli/utils/config.py` (~120 lines):

- `CliConfig(default_target, default_auth_token_env)` — frozen dataclass; both fields optional strings.
- `load_config(project_root=None, *, user_path=USER_CONFIG_PATH)` — reads `~/.synax/config.yaml` then optional `<project_root>/.synax/config.yaml`; the project file overrides the user file. Missing → defaults.
- `save_config(config, path)` — writes YAML; creates parent directories; omits `None` fields.
- `resolve_auth_token(explicit, config, env=None)` — three-step lookup: explicit value → `SYNAX_PUBLISH_TOKEN` env var → env var named by `config.default_auth_token_env`. Returns `None` if nothing matches.
- `resolve_target(explicit, config)` — `--target` flag wins; falls back to `config.default_target`.
- `ConfigError` (extends `SynaxSDKError`) for malformed config files.
- Constants: `USER_CONFIG_PATH`, `PROJECT_CONFIG_SUBPATH`, `PUBLISH_TOKEN_ENV_VAR`.

**Token security stance**: only the *name* of the env var holding the token is stored on disk; never the token itself. `resolve_auth_token` reads `os.environ` at call time via the injected `env=` parameter (test seam).

**Tests (26 in `test_config.py`):**

- `load_config`: defaults when no files; user-only load; project overrides user; user value kept when project silent on a field; empty YAML / `null` root → defaults; malformed YAML raises `ConfigError`; non-object root raises; `project_root=None` only reads user; unknown keys silently ignored (forward-compat); non-string values for known keys treated as `None`.
- `save_config`: round-trips; creates parent directories; `None` fields omitted; empty config → empty file.
- `resolve_auth_token`: explicit wins; SYNAX_PUBLISH_TOKEN env wins over config-named var; config-named var used when env-direct missing; both missing → `None`; config names an unset var → `None` (no KeyError); empty string explicit value falls through to env (since `""` isn't a real token).
- `resolve_target`: explicit wins; fallback to config; both missing → `None`; empty explicit falls through.

**Problems encountered and fixed:**

1. **Ruff S105/S106 firing everywhere on `*token*` substrings** — the env var name constant `PUBLISH_TOKEN_ENV_VAR = "SYNAX_PUBLISH_TOKEN"`, the test value `default_auth_token_env="MY_TOKEN_VAR"` (which is the *name* of an env var, not a credential), and dozens of `token = ...` assignments in tests where `token` is a returned value from the function under test. The fix has two parts:
   - Added `S105`, `S106` to `[tool.ruff.lint.per-file-ignores] tests/**/*.py` — tests use plenty of dummy-token literals and these are never real credentials.
   - Added `S105` to a per-file ignore for `synax_skill_cli/utils/config.py` so the env-var-name constant doesn't trip the rule.
   - Removed the now-unused `# noqa: S105` annotations from earlier files (`test_m3_acceptance.py`, `test_publishing.py`) — ruff's `RUF100` rule caught them after the per-file ignore made them redundant.

2. **No other problems** — single black-format pass, then green.

All checks green: ruff, black, isort, mypy strict (30 source files), **508 tests passed (1 skipped), 95.55% coverage**. config.py at 97%.

---

#### 2026-05-15 — M5 Commit 1: PublishClient + httpx + error types

`synax_sdk/publishing.py` (~370 lines):

- `PublishClient(target_url, auth_token, *, timeout, max_retries, client=None, sleep=time.sleep)` — httpx-backed; supports custom HTTP client and sleep injection for tests.
- `PublishClient.publish(bundle_dir, on_progress=None) -> PublishResult` — reads `manifest.yaml` + `implementation.tar.gz` from the bundle, computes SHA-256, base64-encodes the artifact, POSTs to `/api/v1/skills/publish`.
- `PublishClient.register_key(public_key_b64, fingerprint, namespace) -> KeyRegistrationResult` — POSTs to `/api/v1/keys/register` for trusted-publisher onboarding.
- Top-level `publish()` convenience function for one-shot use.
- Retries with exponential backoff (1s → 2s → 4s) on `httpx.ConnectError` / `TimeoutException` / `ReadError` and HTTP 5xx. 4xx not retried.
- Result parsing distinguishes 200, 400, 401/403, 409, 5xx, unexpected.

New error types in `synax_sdk/errors.py`:

- `PublishError` (base)
- `PublishAuthError` (401/403)
- `PublishValidationError` (400) — carries `details` field
- `PublishVersionConflictError` (409) — carries `existing_version_id`; alias `PublishVersionConflict` for the original name
- `PublishNetworkError` (5xx after retries / persistent connect errors)

Tests (30 in `test_publishing.py`) using respx:

- Construction: empty target/token rejected; trailing slash normalised; context manager closes the client.
- Happy path: response parsed correctly, Authorization header sent, body shape correct (manifest YAML + base64 artifact + computed hash), progress callback invoked with `uploading` then `complete`, `marketplace_url` optional.
- Error responses: 401/403 → PublishAuthError; 400 → PublishValidationError with details; 409 → PublishVersionConflict with existing_version_id; 418 → PublishError "Unexpected"; 200 with non-JSON body / missing required field → PublishError.
- Retries: 5xx-then-200 succeeds after 3 attempts (`route.call_count == 3`); 5xx persistent raises after retries exhausted; 4xx not retried (call_count == 1); `ConnectError`-then-200 retries; persistent network error raises PublishNetworkError; backoff sequence is `[1.0, 2.0]` for two retries (exponential).
- Missing bundle files: missing manifest.yaml → PublishError; missing implementation.tar.gz → PublishError.
- Top-level `publish()` one-shot wraps PublishClient correctly.
- `register_key` happy path, body shape, 401 → PublishAuthError, 409 → PublishError "already registered", 5xx → PublishNetworkError after retries.

**Problems encountered and fixed:**

1. **Ruff N818**: exception name `PublishVersionConflict` lacks the conventional `Error` suffix. Renamed to `PublishVersionConflictError` and kept the original as a module-level alias for backward compatibility with the API I'd already started building toward. Both names work and the tests use whichever is more readable per assertion.
2. **Black reformatted a couple of long lines** in the test file once — harmless.

Coverage: publishing.py at 90% (the missing 10% is mostly the safe-JSON fallbacks for non-JSON error bodies, plus the `pragma: no cover` defensive branch at the bottom of `_request_with_retries`).

All checks green: ruff, black, isort, mypy strict (30 source files), **482 tests passed (1 skipped), 95.48% coverage**.

---

## Milestone 4 — Build, sign, validate, CLI

**Started:** 2026-05-15
**Completed:** 2026-05-15
**Commits:** signing, packaging, schema+validation, build+project-utils, CLI commands, integration tests + docs
**Result:** 452 tests passing (1 skipped, POSIX-only), 96.05% coverage. All M4 SDK modules at ≥95%; CLI command modules at 83-100% (the gap is stub bodies for register/publish/init/test which will be replaced in M5–M7).
**Open questions or blockers:** None. Ready to move to Milestone 5 (publishing — httpx-based PublishClient, `synax skill publish --target <url>`, mock platform server for tests, auth-token handling).

### Plan

6 commits — the biggest milestone yet:

1. **Signing module** — PyNaCl `KeyPair`/`Signer`/`Verifier`, key file format with metadata, `~/.synax/keys/` layout, fingerprint = SHA-256 of public key.
2. **Packaging module** — `build_implementation_artifact(project_dir) -> bytes`, deterministic tar.gz with normalised timestamps/permissions/ownership, `.synax-skillignore` parsing.
3. **Schema + validation** — vendored `synax_sdk/schema/manifest_v1_0.json`, `validation.py` with `validate_manifest()` returning `list[ValidationError]`, plus logical consistency checks.
4. **Build orchestrator** — `build.py` running the full pipeline (load → derive → validate → package → sign → write `build/`), plus `synax_skill_cli/utils/project.py` for `find_project_root` / `load_skill_from_project`.
5. **CLI commands** — replace the placeholder stubs in `synax_skill_cli/main.py` with real implementations via `synax_skill_cli/commands/*.py`. Includes CLI tests with `typer.testing.CliRunner`.
6. **Integration test + docs** — `tests/integration/test_m4_acceptance.py` exercising the full M4 acceptance flow (generate keys, build a skill, validate); mark M4 done in CLAUDE.md and build_plan.md.

### Up-front decisions (taken without asking the user, since they're stepping away)

- **Key file format:** JSON, single file per keypair under `~/.synax/keys/<fingerprint>.key`, mode `0o600`. Fields: `fingerprint`, `created_at`, `algorithm="Ed25519"`, `private_key_b64`, `public_key_b64`. Public-key-only files use the same JSON but omit `private_key_b64`.
- **Default key tracking:** `~/.synax/keys/default` is a small JSON pointing at the active fingerprint (`{"fingerprint": "..."}`). `synax keys generate` writes this file if no default exists yet; `synax keys set-default <fp>` overwrites it.
- **Windows POSIX permissions:** I'll call `os.chmod(path, 0o600)` regardless of platform. On Linux/macOS it enforces; on Windows the call succeeds but ACL behaviour is different. The mock backend doesn't care, and the platform-side trust model is signature-based not file-permission-based, so this is acceptable. Will document the caveat.
- **`.synax-skillignore` defaults** (from technical_plan §6.2): `__pycache__/`, `*.pyc`, `.pytest_cache/`, `.mypy_cache/`, `.ruff_cache/`, `.git/`, `build/`, `dist/`, `*.egg-info/`, `.venv/`, `venv/`, `.env`, `.env.*`, `.synax/`, `tests/`, `.vscode/`, `.idea/`. Pattern syntax is fnmatch-style, one pattern per line, `#`-prefixed comments allowed. Skill authors can add their own.
- **Deterministic tar.gz:** sort entries lexicographically by archive path, zero out mtime (`0`), set uid/gid to `0`, set uname/gname to empty strings, and set file permissions to `0o644` for files and `0o755` for directories. Use `gzip.GzipFile` with `mtime=0` so the gzip header itself is also deterministic.
- **Validation errors are structured dataclasses**, not strings — fields `field`, `message`, optionally `suggestion`. Easy for the CLI to format with rich.
- **Vendored JSON Schema is hand-written** rather than generated from the manifest dataclass — the schema needs to express constraints (semver pattern, slug pattern, etc.) that aren't visible in the dataclass annotations.

### Entries

#### 2026-05-15 — M4 Commit 5: CLI commands (real implementations)

Replaced the placeholder typer commands from M1 with real implementations.

**New module structure:**

- `synax_skill_cli/commands/keys.py` — `keys generate / list / export / import / set-default` real; `keys register` still stub (Milestone 5).
- `synax_skill_cli/commands/skill.py` — `skill validate / build / info / verify` real; `skill init` stub (M7), `skill test` stub (M6), `skill publish` stub (M5).
- `synax_skill_cli/commands/config.py` would have lived here, but it's tiny so I kept `config get/set` stubs inline in `main.py`.
- `synax_skill_cli/main.py` reduced to wiring: top-level app + subcommand groups + global `--version` callback.

**Behavior highlights:**

- `keys generate` saves under `~/.synax/keys/`, prints fingerprint + path, marks "set as default" when no default existed.
- `keys list` shows a rich table with a `*` marker for the default key.
- `keys export` writes to a file (`--output`) or prints fingerprint + base64-encoded public key.
- `skill validate` prints a rich error table colourised by `ValidationError.kind` (red for schema/consistency, yellow for warnings); exit 1 on any blocking issue.
- `skill build` orchestrates the M4 pipeline end-to-end with one-line progress messages and a final summary (manifest path, artifact path, hash, signing fingerprint).
- `skill verify` parses the manifest YAML, reconstructs the canonical bytes (drop `signatures`, sort recursively, no whitespace, UTF-8) and verifies every signature against the keystore.
- `skill info` summarises the loaded skill — name, version, namespace, capabilities, secrets, tools — without doing any I/O.

**Tests (~30 new, in `test_cli_keys.py` and `test_cli_skill.py`):**

Use `typer.testing.CliRunner`. Tests patch the `KeyStore` two ways: `monkeypatch.setattr(keys_module, "_store", lambda: s)` for code paths that use `keys._store()`, and `monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: s))` for code paths that call `KeyStore.default()` directly (the build/verify flow). Each test gets a fresh `tmp_path`-rooted store so they never touch `~/.synax/`.

Coverage covers:

- keys: generate (with and without existing default), list (empty + populated), export to stdout, export to file, export unknown fingerprint, import valid + invalid, set-default known + unknown.
- skill: validate happy path, no project, invalid skill; build happy path, --key, --output, no key available; info happy path, no project; verify happy path, missing file, manifest without signatures, tampered manifest (catches the actual cryptographic verification working end-to-end).
- CLI structure: top-level --help lists groups; each subcommand --help lists its real commands.

The old `test_placeholder.py` was updated — its `STUB_COMMANDS` list now contains only commands that still genuinely print "Not yet implemented" (M5/6/7 deferrals plus the config stubs).

**Problems encountered and fixed:**

1. **Ruff `B008`** fired on `output: Path | None = typer.Option(...)` and similar — "do not perform function call in argument defaults". This is the canonical typer pattern; the rule has a `extend-immutable-calls` allowlist for exactly this case. Added `typer.Argument` and `typer.Option` to that list in `pyproject.toml [tool.ruff.lint.flake8-bugbear]`. M1's `main.py` happened not to trigger B008 because all of its annotations were `str = typer.Option(...)` not `Path | None = typer.Option(...)` — there's some subtlety in how ruff visits the AST.
2. **Two unused imports** in test files — autofixed.
3. **Test isolation across keystores**: the build/verify flow uses `KeyStore.default()` (a classmethod) directly, while keys commands use the module-level `_store()` helper. To redirect both in tests I had to patch both seams. Documented this in the `store` fixture's docstring.
4. **Rich text wrap broke a substring assertion**: `assert "Generated keypair sha256:" in result.stdout` failed because rich wrapped the long fingerprint onto a new line, splitting the phrase. Loosened to check `"Generated keypair"` and `"sha256:"` separately. Won't break if rich's wrap behaviour changes again.

All checks green: ruff, black, isort, mypy strict (29 source files), **446 tests passed (1 skipped), 96.05% coverage**. CLI modules: `main.py` 100%, `keys.py` 98%, `skill.py` 83% (the 17% is the `register`/`publish`/`init`/`test` stubs whose bodies will be replaced in M5/6/7).

---

#### 2026-05-15 — M4 Commit 4: build orchestrator + project utils

Two pieces:

**`synax_skill_cli/utils/project.py`** (~150 lines):

- `find_project_root(start=None)` — walks up from `start` (default cwd) looking for a `pyproject.toml` with a `[tool.synax]` section.
- `read_synax_config(project_root)` — parses `[tool.synax]` (uses Python's stdlib `tomllib`).
- `load_skill_from_project(project_root)` — reads `entry_point = "module:variable"`, adds project root to `sys.path` via a contextmanager, imports the module, returns the `Skill` instance. Pops the imported module from `sys.modules` after access so subsequent calls re-read the file from disk.

**`synax_sdk/build.py`** (~150 lines):

- `BuildResult(manifest, artifact, signature, output_dir, bundle_dir, warnings)` — frozen dataclass.
- `build(project_root, skill, *, entry_point, key_fingerprint=None, output_dir=None, key_store=None) -> BuildResult`. The pipeline:
  1. `Manifest.from_skill(skill)`
  2. `build_implementation_artifact(project_root)` (excluding `output_dir` if it lives inside the project)
  3. Pin `implementation.hash` to the artifact's sha256 and set `implementation.entry_point`
  4. `validate_manifest()` — blocking errors raise `BuildError(errors=[...])`, warnings flow through
  5. Sign canonical bytes with the chosen / default key; append `Signature` with `signer_type="author"` and an ISO 8601 `signed_at`
  6. Write the signed bundle to `<output_dir>/signed_bundle/` (manifest.yaml + implementation.tar.gz) plus diagnostic files (manifest.yaml/.json/.canonical) at `<output_dir>/`.

`BuildError` extends `SynaxSDKError` and carries an `errors` attribute for the CLI to format.

**Tests (29 + 17 = 46 across two files):**

For project utils: every path of `find_project_root`, both layers of `read_synax_config`, every error path of `load_skill_from_project` (missing entry_point, malformed, no colon, empty halves, module not found, attribute missing, attribute wrong type).

For build orchestrator: happy path (returns BuildResult), hash pinned, entry_point set, bundle files written, diagnostic files written, signature verifies against the written canonical form, signature appears in manifest, YAML and JSON round-trip; custom output_dir, explicit key fingerprint, output_dir-inside-project exclusion; failures: no signing key, validation failure carries errors, warnings don't block; determinism — same project produces the same artifact hash across runs with different signing keys.

**Problems encountered and fixed:**

1. **Circular dependency**: my first draft had `synax_sdk/build.py` importing from `synax_skill_cli/utils/project.py`, while project.py imported from `synax_sdk.skill`. Refactored `build()` to take `skill` and `entry_point` as explicit parameters; the CLI command loads them and passes them in. `synax_sdk` no longer depends on `synax_skill_cli`.
2. **Ruff `RUF043`**: three `pytest.raises(match="...")` patterns used unescaped metacharacters like `.` and `[`. Switched to raw strings with `\.` and `\[` so the regex intent is explicit.
3. **isort `I001`** on one test file — autofixed.
4. **Test isolation bug**: `test_attribute_is_not_skill` rewrites `my_skill.py` to contain `skill = 42`, then expects `load_skill_from_project` to fail with "not a Skill". It passed in isolation but failed when run after another test that already cached `my_skill` in `sys.modules` with a real Skill instance. Fixed by popping the imported module from `sys.modules` immediately after the import inside the context manager — this also makes the helper correct for real usage where the skill source may change between invocations.

All checks green: ruff, black, isort, mypy strict (26 source files), **428 tests passed (1 skipped), 97.26% coverage**.

---

#### 2026-05-15 — M4 Commit 3: vendored JSON Schema + validation module

`synax_sdk/schema/manifest_v1_0.json` — the authoritative JSON Schema for skill manifests, mirroring `docs/manifest_spec.md`. ~220 lines covering every required and optional field with precise patterns (`name`/`namespace` slug, `version` semver, `implementation.hash` `sha256:` form, capabilities `<type>:<spec>` shape, `signatures.key_fingerprint`, secret names SCREAMING_SNAKE_CASE, secret types enum, etc.). The schema sets `additionalProperties: false` at every layer to prevent silent drift.

`synax_sdk/schema/__init__.py` — `load_manifest_schema(version="1.0")` with `@cache` to load once per process.

`synax_sdk/validation.py` (~180 lines):

- `ValidationError` — frozen dataclass with `field`, `message`, `kind` (`"schema"` / `"consistency"` / `"warning"`), optional `suggestion`.
- `validate_manifest(manifest, *, schema_version=None) -> list[ValidationError]` — runs both layers, returns every issue (not just the first).
- Layer 1: jsonschema `Draft202012Validator.iter_errors` → `ValidationError(kind="schema")`. JSON-pointer-ish field paths like `tools[0].name`.
- Layer 2: logical consistency:
  - Every declared secret must have a matching `secrets:<name>` capability.
  - `execution_location='daemon_only'` should have a filesystem/subprocess/local-network capability — emitted as `kind="warning"` (non-blocking advisory).

**Tests (35):**

- Schema loader: default version, explicit "1.0", unknown version raises FileNotFoundError.
- Happy paths: simple skill validates clean, skill without secrets validates clean.
- Schema layer: zero tools rejected (spec requires ≥1); bad hash format rejected; valid hash accepted; description too long; signature with bad fingerprint; bad secret type; duplicate capabilities.
- Consistency layer: secret without capability flagged with suggestion; daemon_only without local caps emits warning; daemon_only with filesystem OR localhost network silences warning; non-daemon location skips warning.
- ValidationError shape: default kind, explicit kind, optional suggestion, frozen.
- Realistic manifests: full manifest_spec.md "Complete Example" validates clean; broken manifest yields multiple errors at once (not fail-fast).

**Problems encountered and fixed:**

1. **Ruff `UP033`**: `@lru_cache(maxsize=None)` → use `@cache` (the unbounded alias added in 3.9). Trivial.
2. **Ruff `S104`**: `("localhost", "127.0.0.1", "0.0.0.0")` flagged as "Possible binding to all interfaces". These are *string match tokens*, not bind addresses. Lifted them to a named local with `# noqa: S104 — string match, not a bind` and a comment explaining the intent.
3. **mypy `no-any-return`** on `return json.loads(text)`: assigned to an explicitly-typed local first.
4. **mypy `unused-ignore` + `attr-defined`** on `for segment in path` where I had typed `path: object`. Switched the parameter type to `Iterable[str | int]` (matches what jsonschema actually produces — a deque of segments).
5. **Ruff `F401`** unused import `DependencyManifest` in the test file — dropped from the import list.
6. Black reformatted one line in validation.py once after editing.

All checks green: ruff, black, isort, mypy strict (23 source files), **395 tests passed (1 skipped), 97.51% coverage**. schema/__init__.py at 100%, validation.py at 97%.

---

#### 2026-05-15 — M4 Commit 2: packaging module + .synax-skillignore

`synax_sdk/packaging.py` (~200 lines). Public surface:

- `build_implementation_artifact(project_dir, *, extra_ignore=None) -> ArtifactResult` — top-level entry point.
- `ArtifactResult(tar_gz_bytes, sha256, included_files)` — frozen dataclass; `sha256` already prefixed with `"sha256:"` so it slots straight into `implementation.hash`.
- `load_skillignore(project_dir) -> list[str]` — loads `.synax-skillignore` if present, else returns the default list.
- `DEFAULT_IGNORE_PATTERNS` — the SDK's built-in defaults (`__pycache__/`, `*.pyc`, `.venv/`, etc.).

**Determinism strategy:**

1. Files collected via `rglob`, then sorted lexicographically by archive path.
2. Each TarInfo gets `mtime=0`, `uid=0`, `gid=0`, `uname=""`, `gname=""`, mode normalised to `0o644` (files) / `0o755` (dirs).
3. The gzip wrapper uses `mtime=0` — without this the gzip 10-byte header includes the current time, defeating bytewise determinism.
4. Symlinks are skipped (not portable across platforms and unreliable in tar archives).

**Ignore pattern semantics:**

Simple fnmatch-style — a pattern ending in `/` matches when any path component equals the directory name (so `__pycache__/` excludes the dir and its contents anywhere in the tree); otherwise the pattern is tested against both the basename and the full POSIX-style relative path. Documented in the module docstring; not full gitignore but sufficient for the M4 patterns.

The `.synax-skillignore` file **replaces** the defaults rather than extending them — matches gitignore convention.

**Tests (29):**

- `load_skillignore` defaults vs. file present, comment + blank-line stripping, whitespace trim.
- Missing / non-directory project_dir → `FileNotFoundError`.
- Empty directory → empty archive with valid hash.
- Archive contents in sorted POSIX order.
- File bytes preserved (verified via on-disk size, not Python string length — see problem below).
- **Determinism: same project → byte-identical output across multiple invocations.**
- Content change changes hash.
- Creation order doesn't change archive order (alphabetical regardless).
- mtime/uid/gid/uname/gname all zeroed in archive entries.
- File modes normalised to 644.
- Default patterns exclude `__pycache__/`, `*.pyc`, `.synax/`, `.venv/`, `.env*`.
- Custom skillignore replaces (doesn't extend) defaults.
- `extra_ignore` kwarg appends to active patterns.
- Directory pattern matches subdirectory occurrences anywhere in the tree.
- Symlinks skipped (graceful skip if symlink creation isn't supported in the test environment).
- SHA-256 format and consistency with the actual bytes.

**Problems encountered and fixed:**

1. **mypy `unused-ignore` warning**: I had `# type: ignore[arg-type]` on `tarfile.open(fileobj=gz, mode="w")` but `gz` is `gzip.GzipFile` which is a valid `BinaryIO`-compatible type. Removed the unnecessary suppression.
2. **Windows line-ending translation broke `test_archive_contains_file_bytes`**: writing `"print('hi')\n"` via `path.write_text` translates `\n` → `\r\n` on Windows, so the file on disk is 13 bytes but the Python string is 12. The test then compared the archive entry's size against the Python string length. Switched to `write_bytes` so the on-disk size matches the input bytes regardless of platform.

All checks green: ruff, black, isort, mypy strict (21 source files), **371 tests passed (1 skipped), 97.49% coverage**. packaging.py at 96% (the missing 4% is the symlink-skip branch in `_collect_files` plus a defensive branch — both exercised only on platforms that allow symlinks).

---

#### 2026-05-15 — M4 Commit 1: signing module + key storage

`synax_sdk/signing.py` (~310 lines). Public surface:

- `KeyPair` — frozen dataclass holding `public_key` + optional `private_key` + optional `created_at`. `.fingerprint` is `sha256:<hex>` over the public key. `.has_private`, `.signer()`, `.verifier()` methods.
- `Signer` (wraps KeyPair with the private half) → `.sign(canonical_bytes) -> str` (base64 signature).
- `Verifier` (wraps KeyPair) → `.verify(canonical_bytes, signature_b64) -> None`; raises `SigningError` on failure.
- `generate_keypair()` — fresh Ed25519 keypair with current UTC timestamp.
- File I/O: `save_keypair_to_file`, `load_keypair_from_file`, `save_public_key_to_file`, `load_public_key_from_file`. Format is versioned JSON, mode `0o600` on POSIX.
- `KeyStore` — a directory under `~/.synax/keys/` with one file per keypair plus a `default` JSON pointing at the active fingerprint. Methods: `save`, `load`, `list_fingerprints`, `set_default`, `.default_fingerprint`.
- `SigningError` exception class.

Wraps PyNaCl's `nacl.signing.SigningKey` / `VerifyKey` — never reaches for hand-rolled crypto (per CLAUDE.md never-do).

**Tests (42 + 1 POSIX-only skipped on Windows):**

- Fingerprint format, determinism, distinctness.
- `generate_keypair()` produces a 32+32 byte keypair with a matching fingerprint, distinct on each call.
- Sign/verify round-trip; tamper-detection on payload; wrong-key rejection; malformed-signature rejection.
- Public-only KeyPair: `.signer()` raises with a useful message; `.verifier()` works.
- Save/load round-trip preserves all fields.
- Save public-only file strips private; `load_public_key_from_file` drops private even when present in the source file.
- POSIX file permissions test (0o600) skipped on Windows.
- Error cases on load: missing file, bad JSON, wrong algorithm, missing public key, bad base64 in either half.
- `KeyStore`: save creates file, first save sets default, second save doesn't clobber default, `set_default` to known/unknown fingerprint, list with/without keys, list skips malformed files, default pointer none cases.
- Cross-implementation sanity: signatures from our `Signer` verify via raw `nacl.signing.VerifyKey`.

**No problems encountered.** One black-format pass after writing. signing.py at 95% coverage (remaining 5% is defensive `OSError` swallows in `_ensure_directory` plus a couple of less-traveled `KeyStore` paths).

All checks green: ruff, black, isort, mypy strict (20 source files), **342 tests passed (1 skipped), 97.67% coverage**.

---

## Milestone 3 — Runtime API with mock backend

**Started:** 2026-05-15
**Completed:** 2026-05-15
**Commits:** foundation+secrets+ctx, logger, metrics, public API + integration, plus final docs commit
**Result:** 301 tests passing, 98.10% coverage. Every M3 module at 100% (`runtime/_backends/base.py`, `runtime/_backends/mock.py`, `runtime/context.py`, `runtime/logger.py`, `runtime/metrics.py`, `runtime/secrets.py`, `testing/_mock_platform.py`).
**Open questions or blockers:** None. Ready to move to Milestone 4 (build artifact, Ed25519 signing, manifest validation, CLI commands).

### Plan

5 commits:

1. **Foundation + secrets + ctx** — RuntimeBackend ABC, `ContextVar` machinery, `Context`/`Invoker` dataclasses, `ctx` proxy, `secrets` facade, MockBackend skeleton, MockPlatform skeleton with `.secrets` and `.context` sub-objects, `SkillRuntimeError` exception.
2. **Logger** — `logger.debug/info/warning/error/exception` facade, `MockBackend.log`, `LogCall` dataclass, `MockPlatform.logger`.
3. **Metrics** — `metrics.counter/gauge/histogram` factories, `Counter/Gauge/Histogram` classes with `inc/set/observe`, `MetricRecord` type, `MockBackend.record_metric`, `MockPlatform.metrics` with aggregated `.counters`/`.gauges`/`.histograms` plus raw `.records`.
4. **Public API + integration test** — wire `secrets`/`logger`/`metrics`/`ctx`/`Context`/`Invoker` into `synax_sdk/__init__.py`; integration test mirroring the build_plan §M3 acceptance example verbatim.
5. **Docs** — mark M3 complete in CLAUDE.md and build_plan.md; finalize this section.

### Up-front decisions (taken without asking the user, since they're stepping away)

- **`ctx` is a read-only proxy** with explicit `@property` accessors for each Context field (`run_id`, `workspace_id`, `invoker`, `channel_id`, `bot_id`, `user_id`). Each property dereferences the active backend's `get_context()`. Verbose but mypy-friendly — `__getattr__` would lose type information.
- **One `ContextVar[RuntimeBackend | None]` holds the active backend**. The runtime context (run_id, workspace_id, etc.) is fetched *through* the backend via `get_context()`, not stored separately. This matches the build_plan's `RuntimeBackend` ABC method list (`get_secret`, `log`, `record_metric`, `get_context`).
- **`secrets` is an object** (instance of an internal `_Secrets` class), not a module. Same for `logger`, `metrics`, `ctx`. The build_plan's `from synax_sdk.runtime.secrets import secrets` syntax implies an importable symbol — a module-level singleton.
- **The mock backend fails loudly** when a skill requests a secret/context that wasn't configured. `SkillRuntimeError` with a message that points at the test setup. Matches build_plan implementation note ("helps catch test setup bugs").
- **No "real" backend implementation in this SDK at M3.** The platform's runtime infrastructure provides that. We only ship the ABC + mock.
- **`MockPlatform.metrics.counters` is keyed by name only**, aggregating across labels. For label-aware assertions, callers iterate `MockPlatform.metrics.records` (raw `MetricRecord` list). Simpler default; full fidelity when needed.

### Entries

#### 2026-05-15 — M3 Commit 4: public API + integration tests

`synax_sdk/__init__.py` now exports the runtime surface: `secrets`, `logger`, `metrics`, `ctx`, `Context`, `Invoker`, and `SkillRuntimeError`. Total `__all__` is now 17 names (M2's 10 + 7 new for M3).

`tests/integration/test_m3_acceptance.py` — 6 end-to-end tests:

1. **The exact build_plan §M3 acceptance example** verbatim — skill uses `secrets.get` and `logger.info` inside a tool body, test injects via `MockPlatform`, asserts result + log message + secret access.
2. **Every facade reachable from the top-level package** — exercises all of `secrets`, `logger`, `metrics.counter/gauge/histogram`, `ctx.run_id/workspace_id/invoker` in one block, asserts everything captured correctly.
3. **`__all__` matches an explicit expected set** of 17 names — guards against accidental adds/removes without doc updates.
4. **Realistic skill** with multiple runtime calls (secret + log + counter + histogram), invoked twice; asserts ordering, aggregation, and extra payloads.
5. **All four facades raise `SkillRuntimeError` outside `activate()`** — uniform contract.
6. **`Context` and `Invoker` dataclasses constructable** by skill authors directly (useful for richer test setups).

**Problems encountered and fixed:**

1. **Ruff S105 ("Possible hardcoded password")** flagged `"ghp_xxx"` in the realistic-skill test. Initially tried `# noqa: S105` inline but my first attempt used `replace_all` which jammed the comment inside the function call's argument list (`mock.secrets.set("GITHUB_TOKEN", "FAKE_TEST_TOKEN"  # noqa: ...)`) — syntactically invalid. Restructured to assign the fake value to a named variable first (`fake_token = "FAKE_TEST_TOKEN"  # noqa: S105`) so the noqa sits on a top-level assignment where it doesn't interfere with call syntax. Then reused `fake_token` in the call.
2. **The M2 acceptance test's `test_public_api_exports` broke** because it asserted exact set equality with the M2-era `__all__`. The new M3 names made this fail. Changed `==` to `<=` (subset) so the test pins M2's *floor* — every M2 name must remain exported, but subsequent milestones can add. The new M3 acceptance test does the exact-equality check for the current `__all__`.

All checks green: ruff, black, isort, mypy strict (19 source files), **301 tests passed, 98.10% coverage**.

---

#### 2026-05-15 — M3 Commit 3: metrics

`synax_sdk/runtime/metrics.py` with `_Metrics` factory and three immutable record-types: `Counter` (`.inc(by=1)`), `Gauge` (`.set(value)`), `Histogram` (`.observe(value)`). All three are `@dataclass(frozen=True)` carrying a reference to the active backend; the mutator methods record one `MetricRecord` per call via `backend.record_metric(kind=..., ...)`.

`MockPlatform.metrics` adds aggregation views:

- `.counters` → `dict[name, CounterState(name, value)]` — sums `counter_inc` records across all labels per name.
- `.gauges` → `dict[name, GaugeState(name, value)]` — most recent `gauge_set` value per name.
- `.histograms` → `dict[name, HistogramState(name, values)]` — list of observations; `HistogramState` has `.count` and `.sum` properties.
- `.records` → raw `list[MetricRecord]` for label-aware assertions.

`CounterState`, `GaugeState`, `HistogramState` exported from `synax_sdk.testing` so test code can construct them directly if needed.

**Tests (29 new):**

- All three factory methods raise without active backend.
- `Counter.inc()` defaults to 1, `inc(by=N)` works, accumulates correctly.
- Counters with different labels aggregate by name in `.counters` view; raw `.records` preserves labels.
- `Gauge.set()` is "latest wins".
- `Histogram.observe()` accumulates values, `.count` and `.sum` derived correctly.
- Same metric name across different kinds (counter, gauge, histogram) don't interfere with each other's aggregations.
- `.records` returns in call order and is a defensive copy.
- Empty platform yields empty aggregations (no KeyError, no spurious entries).

**No problems on this commit** — clean first-try run.

All checks green: ruff, black, isort, mypy strict (19 source files), **295 tests passed, 98.09% coverage**. Every M3 module at 100% (`runtime/`, `testing/`).

---

#### 2026-05-15 — M3 Commit 2: logger

`synax_sdk/runtime/logger.py` with `_Logger` providing `.debug`/`.info`/`.warning`/`.error`/`.exception`. Each delegates to `resolve_backend().log(level=..., message=..., extra=...)`. `logger.exception()` captures `traceback.format_exc()` into the merged extra dict — call it from inside an `except:` block to get a real stack trace, or call it from outside and you get the `"NoneType: None"` string that `format_exc()` returns (Python convention).

Added `MockPlatform.logger` sub-object with `.calls` (raw list of `LogCall`) and `.at_level(level)` (filtered list). `MockBackend.log()` defensively copies the `extra` dict so callers mutating the dict after-the-fact don't corrupt the captured record.

**Tests (16 new):**

- Every level (debug/info/warning/error) reaches the mock with correct level + message.
- `extra` is preserved + defensively copied.
- `logger.exception()` works inside AND outside `except:` blocks.
- `logger.exception()` merges with caller-provided `extra`.
- `mock.logger.calls` returns in call order.
- `mock.logger.at_level()` filter is correct including the empty case.
- `mock.logger.calls` returns a defensive copy.

**No problems.** Clean run on first try — ruff, black, isort, mypy strict (18 source files), **273 tests passed, 97.69% coverage**. logger.py at 100%.

---

#### 2026-05-15 — M3 Commit 1: foundation + secrets + ctx

`synax_sdk/runtime/` package with the foundation: `RuntimeBackend` ABC (`_backends/base.py`), `MockBackend` (`_backends/mock.py`), `Context`/`Invoker` dataclasses + `ctx` proxy (`context.py`), and the `secrets` facade (`secrets.py`). Plus `synax_sdk/testing/_mock_platform.py` with `MockPlatform` exposing `.secrets`, `.context`, and `.activate()`. Added `SkillRuntimeError` to the exception hierarchy.

**Tests (49 new):**

- `test_runtime_foundation.py` — ABC can't be instantiated, partial subclass rejected, `resolve_backend` raises with helpful message when no backend, `set_backend`/`reset_backend` round-trip, nested set/reset restores outer, `SkillRuntimeError` is a `SynaxSDKError`, `Context`/`Invoker` dataclass shapes and frozenness.
- `test_runtime_secrets.py` — `secrets.get()` raises without backend, returns configured values, raises with specific "not configured" error inside `activate()`, records accesses (including failed ones), nested `MockPlatform.activate()` blocks restore correctly.
- `test_runtime_context.py` — `ctx.<field>` raises both when no backend AND when no context configured; every field readable; string UUIDs accepted; bad UUIDs rejected; default invoker; explicit invoker wins over per-component kwargs; `set()` overwrite.

**No problems on this commit.** Single black-format pass on `base.py` after writing it. ruff clean on first try after fixing two pre-flight test issues (one `B017` and one stale `noqa`).

Coverage of mock.py is 93% — the four missing lines are the `log()`/`record_metric()` paths that get tested in commits 2 and 3. Everything else at 100%.

All checks green: ruff, black, isort, mypy strict (17 source files), **257 tests passed, 97.40% coverage**.

---

## Milestone 2 — Skill class and tool decorator

**Started:** 2026-05-15
**Completed:** 2026-05-15
**Commits:** `c5d492c` (errors), `6a80276` (tool), `69cb511` (skill), `a5c58b7` (manifest), `dca9f05` (public API + integration), plus final docs commit
**Result:** 216 tests passing, 97.29% coverage. manifest.py and skill.py at 100%; tool.py at 94% (defensive error branches uncovered).
**Open questions or blockers:** None. Ready to move to Milestone 3.

### Plan

6 commits, each self-contained and CI-green:

1. **errors.py + tests** — exception hierarchy (foundation for everything else)
2. **tool.py + tests** — `Tool` dataclass, signature inspection, type → JSON Schema, Google docstring parser
3. **skill.py + tests** — `Skill` class with constructor validation + `@tool` decorator
4. **manifest.py + tests** — `Manifest` and supporting dataclasses, `from_skill`, YAML/JSON/canonical serialization
5. **public API + integration test** — wire up `synax_sdk/__init__.py`, end-to-end test from build_plan §Milestone 2 acceptance criteria
6. **docs + status updates** — mark M2 done, finalize this journal

### Up-front decisions (taken without asking the user, since they stepped away)

These are documented here so they're reviewable on return. None of them seem load-bearing or hard to reverse.

- **`Optional[X]` and `X | None` → `{"anyOf": [<X schema>, {"type": "null"}]}`.** This is the JSON Schema standard. The OpenAPI 3.0 `nullable: true` extension is *not* valid JSON Schema and would fail validation against the platform's schema validator (`jsonschema` library). The platform spec (`docs/manifest_spec.md`) doesn't show an explicit example for nullable params, so I'm going with the JSON Schema standard form.
- **`Manifest.from_skill()` does not compute the implementation hash or sign anything.** Per `build_plan.md` §Milestone 2 the build/sign pipeline is Milestone 4. `Implementation.hash` is left as `None` at construction time; later milestones will fill it in. `signatures` defaults to an empty list.
- **Empty optional fields are dropped from YAML/JSON serialization.** A skill with no `dependencies` shouldn't emit `dependencies: []` in its manifest YAML — it should omit the key. Same for empty `tags`, missing `metadata` fields, etc. The platform's schema treats these as optional and absent.
- **`metadata.sdk_version`** is populated automatically from `synax_sdk.version.__version__`. `technical_plan.md` §11.1 tentatively suggests this and it's free to add now.
- **`Tool` dataclass uses `eq=False`** because comparing tools by equality is meaningless when one of the fields is a Python callable. Identity comparison is what callers will actually want.
- **Skill names and namespaces use `^[a-z0-9][a-z0-9-]{0,127}$`** per `manifest_spec.md` §Validation Rules. Tool names use snake_case per the spec example: `^[a-z][a-z0-9_]{0,63}$`.
- **Semver validation uses a loose regex** (`^\d+\.\d+\.\d+(?:-[\w.-]+)?(?:\+[\w.-]+)?$`) rather than the full SemVer 2.0.0 grammar. The platform side will do the strict check; this is a fast sanity gate.

### Entries

#### 2026-05-15 — Commit 5: public API exports + integration test

Wired up `synax_sdk/__init__.py` to export the M2 public surface (10 names total): `Skill`, `Secret`, `SkillDependency`, `SkillMetadata`, `Manifest`, the 4 exception classes, and `__version__`. Anything not in `__all__` stays internal.

Added `tests/integration/test_m2_acceptance.py` with 4 end-to-end tests:

1. **build_plan §M2 acceptance example, verbatim** — constructs the Skill, decorates a tool, calls it directly via `asyncio.run`, derives the manifest, serializes to YAML, and asserts every field of the spec is correct.
2. **Public API surface check** — asserts every name in `__all__` is importable AND that the set equals the documented expectation. Catches accidental adds/removes.
3. **Exception hierarchy check via public imports** — same hierarchy assertions as the unit tests, but importing from `synax_sdk` rather than `synax_sdk.errors`.
4. **Complex skill round-trip** — namespace, execution_location, multiple tools, TypedDict return type, dependencies, full metadata. Verifies that `to_dict()`, `to_yaml()`, `to_canonical_json()` all agree and that all the M2 features compose correctly.

**Problems encountered and fixed:**

1. **I wrote garbled syntax in one assertion**: `parsed_yaml == parsed | {"sdk_version_marker": parsed_yaml.get("sdk_version_marker")} - {"sdk_version_marker"} or parsed_yaml == parsed` — a confused half-formed thought during writing. Replaced with a clean `parsed_yaml == parsed`; YAML and canonical JSON serialize to the same dict structure since both skip empty/None values.
2. **isort I001 on the new test file** — auto-fixed.

The integration tests are decorated with `pytestmark = pytest.mark.integration` so they can be deselected with `-m "not integration"` in CI shortcuts. They still run as part of the default `pytest` invocation.

All checks green: ruff, black, isort, mypy strict (9 source files), **216 tests passed, 97.29% coverage**. manifest.py now at 100% (integration test covered the previously-uncovered defensive branch).

---

#### 2026-05-15 — Commit 4: `Manifest` dataclasses + serialization

`synax_sdk/manifest.py` and `tests/unit/test_manifest.py`. ~300 lines, 42 tests, 99% coverage on manifest.py.

**Dataclasses (mirror `docs/manifest_spec.md` exactly):**

- `Implementation` — type, entry_point, hash, runtime_requirements. `entry_point` and `hash` default to `None` so M2 can produce manifests; M4 packaging fills them in.
- `ToolManifest`, `SecretManifest`, `DependencyManifest` — each with a `.from_<source_type>` factory.
- `ManifestMetadata` — superset of `SkillMetadata`, adds `sdk_version`.
- `Signature` — key_fingerprint, signer_type (Literal of 4), signature, signed_at.
- `Manifest` — the top-level dataclass with the `from_skill` factory plus three serializers.

**Serialization:**

- `to_dict()` — produces a plain dict in spec field order (NOT declaration order). Filters None scalars, empty list/dict fields, and the default `execution_location="either"`.
- `to_yaml()` — `yaml.safe_dump` with `sort_keys=False` to preserve spec order. No `!!python/` tags (test asserts this).
- `to_json(indent=2)` — human-readable.
- `to_canonical_json() -> bytes` — the bytes Ed25519 will sign. Excludes `signatures`, sorts keys recursively, no whitespace, UTF-8 encoded. Deterministic — verified by a same-skill-twice test.

**Problems encountered and fixed:**

1. **`N812: Lowercase __version__ imported as non-lowercase _SDK_VERSION`** — ruff rejects renaming a lowercase name to uppercase on import. Switched to `from synax_sdk import version as _version_module` then referenced `_version_module.__version__` directly. (Same fix on the test side: import as `_sdk_version` lowercase, then assign to a module-level `SDK_VERSION` for test readability.)
2. **`UP012: Unnecessary UTF-8 encoding argument`** — `"café".encode("utf-8")` → `"café".encode()` (utf-8 is the default).
3. **Test assumption wrong about canonical-form first key.** I assumed the first key alphabetically would be `"description"`, but with `capabilities` populated, `"capabilities"` sorts first. Rewrote the test to assert (a) the first key matches what's actually there given the input, and (b) every level's keys are in sorted order when parsed back. The second check is the more durable one.

**Open notes:**

- `to_yaml` is wrapped in a `try/except yaml.YAMLError` that's marked `pragma: no cover` — it's defensive against a yaml library bug and can't be triggered by normal input. This is the only uncovered line in manifest.py.
- `runtime_requirements` is left untouched at M2; M4 will populate it from the project's pyproject.toml.

All checks green: ruff, black, isort, mypy strict (9 source files), 212 tests, 97.01% coverage.

---

#### 2026-05-15 — Commit 3: `Skill` class + `@tool` decorator

`synax_sdk/skill.py` and `tests/unit/test_skill.py`. ~340 lines of implementation, 84 tests, 100% coverage of skill.py.

**Supporting dataclasses:**

- `Secret` — name (SCREAMING_SNAKE_CASE), type (Literal of 6 valid types), description, optional scope_required
- `SkillDependency` — skill name + version constraint
- `SkillMetadata` — every field optional (category, tags, homepage, source, documentation, license, long_description, icon_url)

**Skill class:**

- Constructor takes keyword-only arguments to make calls self-documenting at the call site (`Skill(name="...", version="...")` reads better than positional).
- Accepts `secrets` and `dependencies` as either dataclass instances OR plain dicts. Dicts are converted internally. This makes the acceptance-test syntax (`secrets=[{...}]`) work without forcing users to import `Secret`.
- `metadata` accepts a `SkillMetadata`, dict, or `None`.
- `display_name` derived from `name` via `_humanize` (`"hello-world"` → `"Hello World"`) if not given.
- `__repr__` shows `name`, `version`, `tool count`, plus `namespace/` prefix if set.

**Validation rules (each with actionable error messages):**

- Name: `^[a-z0-9][a-z0-9-]{0,127}$`. Bad names get a `"Did you mean 'github-pr'?"` suggestion via `_slug_suggestion`.
- Version: loose semver regex (platform side does the strict check).
- Description: non-empty, ≤256 chars (longer descriptions belong in `metadata.long_description`).
- Capabilities: `^[a-z][a-z_]*:.+$`; duplicates rejected.
- Execution location: enum of 5 values.
- Secrets: SCREAMING_SNAKE_CASE names, valid type, non-empty description, no duplicate names, **and every secret must have a matching `secrets:<name>` in capabilities** (technical_plan §4.1).
- Dependencies: shape-check only; semver constraint validation deferred to the platform.

**The `@skill.tool(description=...)` decorator:**

- Returns the original function unchanged so authors can still call it directly during local testing.
- Detects duplicate tool names within a skill and rejects with a helpful error.
- `tools` property returns a copy of the registered list so callers can't mutate internal state.

**No problems hit on this commit.** Clean run on first try — ruff, black, isort, mypy strict, all 170 tests passed, 96.56% total coverage. skill.py at 100%.

---

#### 2026-05-15 — Commit 2: `Tool` class + type-hint → JSON Schema + docstring parser

`synax_sdk/tool.py` and `tests/unit/test_tool.py`. About 400 lines of implementation, 55 tests covering:

- Every primitive type mapping
- Containers: `list[X]`, `dict[str, X]`, `set[X]`, `tuple[X, ...]`, plus bare versions
- Union: both `Optional[X]` and `X | None`, both `Union[A, B, C]` and `A | B | C`
- `Literal[...]` with inferred type for homogeneous values, no type for mixed
- `TypedDict` with `total=True` and `total=False`
- `@dataclass` with required and defaulted fields
- Error: unsupported types, non-str dict keys, fixed-length tuples, missing annotations, `*args` / `**kwargs`, bad tool names, empty descriptions
- Docstring parser: empty, missing section, multi-line continuations, alternative section headers, sections after Args
- Tool.from_function: sync/async detection, return-type handling, explicit-name override, method binding with `self`

**Problems encountered and fixed:**

1. **Bare container classes failed**. `list`, `dict`, `set`, etc. (without `[X]`) caused `unsupported type annotation`. `typing.get_origin(list)` returns `None`, not `list` — only subscripted forms have a meaningful origin. Added a dedicated branch before the `typing.get_origin` dispatch that matches the bare classes by identity.
2. **`from __future__ import annotations` in the test file broke local-class tests**. With deferred annotations, function annotations become strings; `typing.get_type_hints` then resolves them against the function's `__globals__`. Classes defined *inside* test methods aren't in those globals, so resolution failed inside `Tool.from_function`. Removed the future import from `test_tool.py` (we're on Python 3.14 — modern syntax like `str | None` and `list[X]` works without it). Documented the reason in the file's module docstring.
3. **Ruff `UP007` / `UP045` warnings on `Optional[X]` and `Union[A, B]`**. These forms appear *intentionally* in the tests — we want to verify the SDK handles both legacy and modern syntax. Resolved with targeted `# noqa: UP045` / `# noqa: UP007` directives on the lines that use them.
4. **Black moved the `# noqa` to a different line from the `Union[...]` expression** after reformatting. Restructured by assigning `Union[str, int, bool]` to an intermediate variable on a single line so the noqa stays adjacent.
5. **Case mismatch in my own test regex**. The error message starts with capital "At" but I wrote `match="at tool..."`. Lowercased the match pattern (regex matches case-sensitively by default).

**Open design notes:**

- `Tool` uses `@dataclass(eq=False)` because two tools whose `.func` is a different lambda but otherwise identical are still meaningfully "different tools" — identity comparison is more useful.
- Docstring parser is a hand-rolled line-by-line state machine; ~25 lines. Avoided depending on `docstring_parser` per `build_plan.md` Milestone 2 implementation note.
- `self` and `cls` parameters are silently dropped (a method bound on a class can still be registered as a tool). Technical_plan §4.2 says this is "unusual but allowed".
- `Annotated[X, ...]` is not supported yet (`include_extras=False`). If skill authors want to use it for parameter metadata, we can add support in a follow-up.

All checks green: ruff, black, isort, mypy strict, 86 tests passed, 94.62% coverage (tool.py at 94%, the remaining gaps are defensive error branches that are hard to trigger via real code paths).

---

#### 2026-05-15 — Commit 1: exception hierarchy

`synax_sdk/errors.py` and `tests/unit/test_errors.py`. Four classes:

- `SynaxSDKError` (base) — catches everything from the SDK in one `except`
- `SkillDefinitionError` — fatal at *definition* time (bad name, bad type, etc.)
- `SkillValidationError` — fatal at *validation* time (semantic mismatch)
- `ManifestError` — manifest construction/serialization failures

The distinction between Definition and Validation is intentional and documented in the docstrings: definition errors fire as Python parses the skill module; validation errors fire later when the SDK reconciles tools, capabilities, and schema. They could be collapsed but having them separate gives more precise `except` clauses.

12 tests cover: subclass-of-base, distinctness, catchable-as-base for every subclass, message round-trip, args tuple.

No problems. All checks green: ruff, black, isort, mypy strict, 98.73% coverage (31 tests).
