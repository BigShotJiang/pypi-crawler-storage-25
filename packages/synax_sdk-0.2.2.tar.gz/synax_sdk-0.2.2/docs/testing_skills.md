# Testing Skills

The Synax SDK supports two ways to test a skill locally without ever talking to a real Synax platform:

1. **Declarative YAML cases** under `test_inputs/`, run via `synax skill test`.
2. **pytest-based tests** using the SDK's `MockPlatform` and provided fixtures.

Both run the same skill code against the same in-memory mock backend. Pick whichever fits the test you're writing — most projects end up using both.

---

## Declarative test cases — `synax skill test`

Lay your project out like this:

```text
my-skill/
├── pyproject.toml          # [tool.synax] entry_point = "my_skill:skill"
├── my_skill.py             # contains `skill = Skill(...)` + @skill.tool decorators
└── test_inputs/
    ├── secrets.yaml        # secrets shared across all tools (optional)
    ├── summarize_pr/
    │   ├── secrets.yaml    # secrets shared across summarize_pr cases (optional)
    │   ├── case_basic.yaml
    │   └── case_with_labels.yaml
    └── list_recent_prs/
        └── case_default_limit.yaml
```

Subdirectories of `test_inputs/` are tool names; each `*.yaml` file inside is one test case. Cases starting with `_` are skipped.

Each case looks like:

```yaml
input:
  repo: "owner/name"
  pr_number: 42
secrets:
  GITHUB_TOKEN: "test-token"
context:
  workspace_id: "00000000-0000-0000-0000-000000000001"
expected_output: {title: "...", files_changed: 7}
# OR
expected_output_schema:
  type: object
  properties:
    title: {type: string}
expected_logs:
  - level: info
    message_contains: "Fetched PR"
expected_secret_accesses: ["GITHUB_TOKEN"]
should_raise: "ValueError"   # for negative-path cases
```

Every `expected_*` field is optional — the runner only checks the ones present. Per-case `secrets` override tool-level `secrets.yaml`, which override the root `test_inputs/secrets.yaml`.

Run with:

```bash
synax skill test                          # all cases
synax skill test --tool summarize_pr      # filter to one tool
synax skill test --filter case_basic      # filter by case name substring
synax skill test --inputs custom_inputs   # override test_inputs/ location
```

Exit code is `1` if any case failed, `0` otherwise.

### Expected log matchers

Each entry under `expected_logs:` can use any of:

- `level: info | debug | warning | error`
- `message_contains: "substring"`
- `message_equals: "exact full message"`
- `extra_contains: {key: value, ...}` — every key/value must match

A case fails if the skill never emitted a matching log.

### Capability uses

`expected_capability_uses` is **advisory only** — it's recorded in the test case for documentation but the local mock doesn't enforce capability scopes. The platform enforces them at runtime when the skill ships.

---

## pytest-based tests

`pip install synax-sdk` auto-registers a pytest plugin that exposes two fixtures:

- `synax_mock_platform` — a fresh `MockPlatform` per test, already inside its `.activate()` block.
- `synax_skill_under_test` — the `Skill` instance loaded from the current project's `[tool.synax].entry_point`.

Example test file:

```python
# tests/test_greet.py
from synax_sdk.testing import run_tool_async

async def test_greet_returns_configured_greeting(
    synax_mock_platform, synax_skill_under_test
):
    synax_mock_platform.secrets.set("GREETING", "Hi")
    greet = next(t for t in synax_skill_under_test.tools if t.name == "greet")
    result = await run_tool_async(greet, name="World")
    assert result == "Hi, World"
```

You can also use `MockPlatform` directly without the fixture:

```python
from synax_sdk.testing import MockPlatform
import asyncio

def test_greet_directly():
    from my_skill import greet
    mock = MockPlatform()
    mock.secrets.set("GREETING", "Hi")
    with mock.activate():
        result = asyncio.run(greet(name="World"))
    assert result == "Hi, World"
```

### Inspecting what the skill did

Inside an `activate()` block (or after it exits, if you keep the `mock` reference), every interaction is recorded:

```python
assert mock.secrets.accesses == ["GREETING"]
assert mock.logger.calls[0].message == "Greeting World"
assert mock.metrics.counters["github_api_calls"].value == 1
```

See `MockPlatform`'s docstring for the full inspection surface.

### Async setup

The SDK's tests use `asyncio_mode = "auto"` so `async def` test functions Just Work. If your project's `pyproject.toml` doesn't have that, add:

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
```

---

## Choosing between the two

| Use the declarative runner when… | Use pytest tests when… |
|---|---|
| The expected output is a value or schema | You need to assert on intermediate side effects |
| The case is a "given these inputs, expect this output" contract | The test needs custom Python control flow |
| You want non-developers to write/read tests | You want IDE refactor support |
| You want `synax skill test` to gate publish | You want full pytest assertion introspection |

Both can coexist in the same project — they run independently.
