# Synax Python SDK — Project Overview

**Version:** 0.1 (pre-implementation)
**Status:** Repository provisioned; implementation not yet started
**Audience:** Anyone new to this codebase; first reading

---

## What This Repository Is

This repository contains the **Python SDK for building Synax skills**. It's a separate package from the Synax platform itself — skill developers install this SDK via pip, build their skills, and publish them to a Synax platform instance.

This document is the entry point. Read it first, then dive into the companion documents:

- **[technical_plan.md](./technical_plan.md)** — SDK architecture, design decisions, internal structure
- **[build_plan.md](./build_plan.md)** — implementation phases with concrete deliverables (start here when you're ready to write code)
- **[manifest_spec.md](./manifest_spec.md)** — the skill manifest format the SDK generates (authoritative for SDK; the platform's `data_model.md` §17 is the upstream source)
- **[parent_platform_context.md](./parent_platform_context.md)** — context about Synax (the platform this SDK targets), for readers who haven't seen the parent project

**Recommended reading order:** README → parent_platform_context → manifest_spec → build_plan → technical_plan (for depth).

---

## What Synax Is (Brief)

Synax is a multi-agent orchestration platform built by Synergentic Technologies. It combines collaborative team communication (channels, like Slack) with agentic AI capabilities (bots, model invocations, skill execution, like Claude Code). Users and AI agents coexist as first-class participants in channels.

A **skill** is the platform's extension primitive — the tool layer that bots call. Want a bot to be able to fetch GitHub pull requests? You build a `github-pr-fetch` skill. Want it to send Slack messages? You build a `send-slack-message` skill. Skills are how bots interact with the world beyond conversation.

This SDK is what skill developers use to build skills.

For full context on Synax, see [parent_platform_context.md](./parent_platform_context.md).

---

## What This SDK Does

A skill developer's workflow with the SDK:

```bash
# Install the SDK
pip install synax-sdk

# Scaffold a new skill
synax skill init my-github-skill

# Edit the skill code
cd my-github-skill
# ... write your skill ...

# Validate the manifest
synax skill validate

# Test the skill locally
synax skill test

# Build a signed artifact
synax skill build

# Publish to a Synax platform instance
synax skill publish --target https://synax.mycompany.com
```

The SDK provides:

1. **A Python API** for defining skills (`Skill`, `@skill.tool`, runtime helpers)
2. **A CLI** (`synax skill ...`) for scaffolding, validating, testing, building, and publishing
3. **Manifest generation** — derives the skill manifest from decorated Python code
4. **Signing** — Ed25519 signatures on built artifacts
5. **Local testing tools** — mock platform runtime so skills can be tested without a deployment
6. **Publishing** — uploads signed artifacts to a Synax platform's marketplace API

---

## What This SDK Does NOT Do

To prevent scope creep:

- It does NOT run skills in production (the platform's skill execution runtime does that)
- It does NOT define the platform's REST API (that lives in the platform repo)
- It does NOT include the platform's data models (skills don't access the database directly)
- It does NOT include UI components (skills are headless)
- It does NOT include the TypeScript SDK (that's a separate repo, post-launch)

---

## Repository Relationship to the Platform

```
synergentic/synax-platform/          ← the Django platform that runs Synax
    └── docs/design/data_model.md    ← authoritative skill manifest schema
    └── docs/phase_plan.md           ← Phase 2.1 lists this SDK as a deliverable

synergentic/synax-sdk-python/        ← THIS REPOSITORY
    └── docs/manifest_spec.md        ← derives from platform's data_model.md §17
    └── docs/build_plan.md           ← what to build, in order
    └── synax_sdk/                   ← the actual Python package
    └── synax_skill_cli/             ← the `synax` CLI

synergentic/synax-skills/            ← starter skills built using this SDK (Phase 2.3)

synergentic/synax-daemon/            ← Rust daemon (Phase 3)

synergentic/synax-sdk-typescript/    ← TypeScript SDK (post-launch)
```

The platform repository is the source of truth for the skill manifest schema, the platform REST API, and the wire protocols. This SDK targets that platform.

---

## Technology Stack

- **Language:** Python 3.14
- **Package management:** uv
- **Type checking:** mypy strict
- **Linting:** ruff, black, isort
- **Testing:** pytest with pytest-asyncio
- **HTTP client:** httpx (for publishing to platform)
- **Cryptography:** PyNaCl (Ed25519 signing)
- **CLI framework:** typer (clean modern CLI with type hints)
- **YAML parsing:** PyYAML (for manifest serialization)
- **Schema validation:** jsonschema

---

## Current Status

**Active phase:** Phase 2.1 — Python SDK (per platform's `phase_plan.md`)
**Implementation status:** Not yet started
**First milestone:** Set up the project skeleton (see `build_plan.md` Milestone 1)

---

## Licensing

This SDK is licensed under **Apache License 2.0**.

This is intentionally more permissive than the Synax platform itself (which uses BSL or Elastic License v2). The reasoning: the SDK is what developers use to build skills, and developers expect permissive licensing for SDKs they integrate with their own projects. Apache 2.0 is the standard for SDKs in source-available platforms (similar to Sentry's SDKs, MongoDB's drivers, Elastic's clients).

This means:
- Anyone can use the SDK in their own projects, commercial or otherwise
- Anyone can fork and modify the SDK
- Contributions back to this repository are welcome (CLA may apply once the project is more mature)

The skills built with this SDK are owned by their authors, who can license them however they choose.

---

## Versioning

The SDK follows semantic versioning (SemVer):

- **MAJOR** — breaking changes to the skill API or manifest format
- **MINOR** — new features that are backwards-compatible
- **PATCH** — bug fixes and internal improvements

Pre-1.0 releases (0.x.y) may break compatibility between minor versions while the API stabilizes. Once 1.0 ships, compatibility is preserved within major versions.

Initial release will be `0.1.0` to PyPI when Milestone 4 of `build_plan.md` completes.

---

## Getting Started With Implementation

When you're ready to start building:

1. Read this document (you're doing it)
2. Read `parent_platform_context.md` to understand Synax
3. Read `manifest_spec.md` to understand what the SDK generates
4. Read `build_plan.md` for the implementation sequence
5. Read `technical_plan.md` for design depth
6. Begin Milestone 1 from `build_plan.md`

For working with Claude Code:

- The `CLAUDE.md` at the repository root is loaded automatically
- It points Claude Code at these documents
- Follow conventions in `technical_plan.md` § Engineering Conventions
- Update `build_plan.md` as milestones land

---

*End of project overview*
