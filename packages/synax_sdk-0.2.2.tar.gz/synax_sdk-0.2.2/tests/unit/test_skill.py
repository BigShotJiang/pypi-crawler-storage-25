"""Tests for ``synax_sdk.skill`` — the ``Skill`` class and the @tool decorator."""

from dataclasses import dataclass
from typing import Any

import pytest

from synax_sdk.errors import SkillDefinitionError
from synax_sdk.skill import (
    Secret,
    Skill,
    SkillDependency,
    SkillMetadata,
    _humanize,
    _slug_suggestion,
)


# ---------------------------------------------------------------------------
# Minimal valid skill (used as the baseline for many tests)
# ---------------------------------------------------------------------------
def make_skill(**overrides: Any) -> Skill:
    """Construct a Skill with sensible defaults, overridable per test."""
    kwargs: dict[str, Any] = {
        "name": "hello-world",
        "version": "1.0.0",
        "description": "A trivial test skill",
    }
    kwargs.update(overrides)
    return Skill(**kwargs)


# ---------------------------------------------------------------------------
# Constructor: happy paths
# ---------------------------------------------------------------------------
class TestConstructorHappy:
    def test_minimal_construction(self) -> None:
        skill = make_skill()
        assert skill.name == "hello-world"
        assert skill.version == "1.0.0"
        assert skill.description == "A trivial test skill"
        assert skill.display_name == "Hello World"
        assert skill.namespace is None
        assert skill.capabilities == []
        assert skill.execution_location == "either"
        assert skill.secrets == []
        assert skill.dependencies == []
        assert skill.tools == []

    def test_explicit_display_name_overrides(self) -> None:
        skill = make_skill(display_name="HelloWorld")
        assert skill.display_name == "HelloWorld"

    def test_namespace(self) -> None:
        skill = make_skill(namespace="acme")
        assert skill.namespace == "acme"

    def test_with_capabilities(self) -> None:
        skill = make_skill(
            capabilities=["network:api.github.com", "filesystem:read:/data"],
        )
        assert skill.capabilities == ["network:api.github.com", "filesystem:read:/data"]

    def test_secrets_as_dicts(self) -> None:
        skill = make_skill(
            capabilities=["secrets:TOKEN"],
            secrets=[{"name": "TOKEN", "type": "api_key", "description": "API token"}],
        )
        assert len(skill.secrets) == 1
        assert skill.secrets[0].name == "TOKEN"
        assert skill.secrets[0].type == "api_key"

    def test_secrets_as_objects(self) -> None:
        secret = Secret(name="TOKEN", type="oauth_token", description="OAuth token")
        skill = make_skill(capabilities=["secrets:TOKEN"], secrets=[secret])
        assert skill.secrets == [secret]

    def test_secret_with_scope_required(self) -> None:
        skill = make_skill(
            capabilities=["secrets:GITHUB_TOKEN"],
            secrets=[
                {
                    "name": "GITHUB_TOKEN",
                    "type": "oauth_token",
                    "description": "...",
                    "scope_required": "repo:read",
                }
            ],
        )
        assert skill.secrets[0].scope_required == "repo:read"

    def test_dependencies_as_dicts(self) -> None:
        skill = make_skill(dependencies=[{"skill": "other-skill", "version": ">=1.0.0"}])
        assert skill.dependencies == [SkillDependency(skill="other-skill", version=">=1.0.0")]

    def test_dependencies_as_objects(self) -> None:
        dep = SkillDependency(skill="other", version=">=1.0.0")
        skill = make_skill(dependencies=[dep])
        assert skill.dependencies == [dep]

    def test_metadata_as_dict(self) -> None:
        skill = make_skill(metadata={"category": "developer_tools", "tags": ["github"]})
        assert skill.metadata.category == "developer_tools"
        assert skill.metadata.tags == ["github"]

    def test_metadata_as_object(self) -> None:
        meta = SkillMetadata(category="dev", license="Apache-2.0")
        skill = make_skill(metadata=meta)
        assert skill.metadata is meta

    def test_metadata_defaults_to_empty(self) -> None:
        skill = make_skill()
        assert skill.metadata == SkillMetadata()

    def test_repr(self) -> None:
        skill = make_skill()
        assert "hello-world" in repr(skill)
        assert "v1.0.0" in repr(skill)

    def test_repr_with_namespace(self) -> None:
        skill = make_skill(namespace="acme")
        assert "acme/hello-world" in repr(skill)

    def test_execution_locations(self) -> None:
        for loc in ["daemon_only", "cloud_only", "prefer_daemon", "prefer_cloud", "either"]:
            skill = make_skill(execution_location=loc)  # type: ignore[arg-type]
            assert skill.execution_location == loc


# ---------------------------------------------------------------------------
# Constructor: name validation
# ---------------------------------------------------------------------------
class TestNameValidation:
    @pytest.mark.parametrize(
        "bad_name",
        ["Hello-World", "hello world", "_hello", "-hello", "", "x" * 129, "HELLO"],
    )
    def test_invalid_names_rejected(self, bad_name: str) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid skill name"):
            make_skill(name=bad_name)

    def test_suggestion_in_error(self) -> None:
        with pytest.raises(SkillDefinitionError, match=r"Did you mean 'github-pr'"):
            make_skill(name="GitHub-PR")

    @pytest.mark.parametrize(
        "good_name",
        ["a", "hello", "hello-world", "github-pr-summary", "x9", "0abc", "a" + "-b" * 50],
    )
    def test_valid_names_accepted(self, good_name: str) -> None:
        make_skill(name=good_name)

    def test_non_string_name_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid skill name"):
            make_skill(name=123)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Constructor: version validation
# ---------------------------------------------------------------------------
class TestVersionValidation:
    @pytest.mark.parametrize(
        "good", ["1.0.0", "0.0.1", "10.20.30", "1.0.0-beta.1", "1.0.0+build.5"]
    )
    def test_valid_versions(self, good: str) -> None:
        make_skill(version=good)

    @pytest.mark.parametrize("bad", ["1.0", "1", "v1.0.0", "1.0.0.0", "abc", ""])
    def test_invalid_versions(self, bad: str) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid skill version"):
            make_skill(version=bad)


# ---------------------------------------------------------------------------
# Constructor: description validation
# ---------------------------------------------------------------------------
class TestDescriptionValidation:
    def test_empty_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="non-empty string"):
            make_skill(description="")

    def test_whitespace_only_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="non-empty string"):
            make_skill(description="   ")

    def test_too_long_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="too long"):
            make_skill(description="x" * 257)

    def test_at_limit_accepted(self) -> None:
        make_skill(description="x" * 256)


# ---------------------------------------------------------------------------
# Constructor: namespace validation
# ---------------------------------------------------------------------------
class TestNamespaceValidation:
    def test_valid(self) -> None:
        make_skill(namespace="acme")

    def test_invalid_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid namespace"):
            make_skill(namespace="ACME")


# ---------------------------------------------------------------------------
# Constructor: capability validation
# ---------------------------------------------------------------------------
class TestCapabilityValidation:
    @pytest.mark.parametrize(
        "good",
        [
            "network:api.github.com",
            "network:smtp.gmail.com:587",
            "secrets:GITHUB_TOKEN",
            "filesystem:read:/data",
            "filesystem:write:/tmp",
            "subprocess:git",
            "platform:memory_read",
        ],
    )
    def test_valid_capabilities(self, good: str) -> None:
        make_skill(capabilities=[good])

    @pytest.mark.parametrize(
        "bad",
        ["nocolon", ":empty-type", "Network:foo", "1network:foo", ""],
    )
    def test_invalid_capabilities(self, bad: str) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid capability"):
            make_skill(capabilities=[bad])

    def test_duplicate_capabilities(self) -> None:
        with pytest.raises(SkillDefinitionError, match="Duplicate capability"):
            make_skill(capabilities=["network:x.com", "network:x.com"])

    def test_non_string_capability_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid capability"):
            make_skill(capabilities=[42])  # type: ignore[list-item]


# ---------------------------------------------------------------------------
# Constructor: execution location
# ---------------------------------------------------------------------------
class TestExecutionLocation:
    def test_invalid_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="Invalid execution_location"):
            make_skill(execution_location="anywhere")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Constructor: secrets validation
# ---------------------------------------------------------------------------
class TestSecretsValidation:
    def test_bad_secret_name(self) -> None:
        with pytest.raises(SkillDefinitionError, match="SCREAMING_SNAKE_CASE"):
            make_skill(
                capabilities=["secrets:lowercase"],
                secrets=[{"name": "lowercase", "type": "api_key", "description": "x"}],
            )

    def test_bad_secret_type(self) -> None:
        with pytest.raises(SkillDefinitionError, match="must be one of"):
            make_skill(
                capabilities=["secrets:TOKEN"],
                secrets=[{"name": "TOKEN", "type": "weird", "description": "x"}],
            )

    def test_empty_secret_description(self) -> None:
        with pytest.raises(SkillDefinitionError, match="description must be a non-empty"):
            make_skill(
                capabilities=["secrets:TOKEN"],
                secrets=[{"name": "TOKEN", "type": "api_key", "description": ""}],
            )

    def test_duplicate_secret_names(self) -> None:
        with pytest.raises(SkillDefinitionError, match="Duplicate secret name"):
            make_skill(
                capabilities=["secrets:TOKEN"],
                secrets=[
                    {"name": "TOKEN", "type": "api_key", "description": "x"},
                    {"name": "TOKEN", "type": "api_key", "description": "y"},
                ],
            )

    def test_secret_dict_missing_field(self) -> None:
        with pytest.raises(SkillDefinitionError, match="could not construct Secret"):
            make_skill(
                capabilities=["secrets:TOKEN"],
                secrets=[{"name": "TOKEN"}],  # type: ignore[list-item]
            )

    def test_secret_with_wrong_type_in_list(self) -> None:
        with pytest.raises(SkillDefinitionError, match="must be a Secret or dict"):
            make_skill(
                capabilities=["secrets:TOKEN"],
                secrets=["TOKEN"],  # type: ignore[list-item]
            )

    def test_secret_without_capability(self) -> None:
        with pytest.raises(SkillDefinitionError, match="not in capabilities"):
            make_skill(
                secrets=[{"name": "TOKEN", "type": "api_key", "description": "x"}],
            )


# ---------------------------------------------------------------------------
# Constructor: dependencies validation
# ---------------------------------------------------------------------------
class TestDependenciesValidation:
    def test_dict_missing_field(self) -> None:
        with pytest.raises(SkillDefinitionError, match="could not construct SkillDependency"):
            make_skill(dependencies=[{"skill": "x"}])  # type: ignore[list-item]

    def test_wrong_type(self) -> None:
        with pytest.raises(SkillDefinitionError, match="must be a SkillDependency or dict"):
            make_skill(dependencies=["bad"])  # type: ignore[list-item]


# ---------------------------------------------------------------------------
# Constructor: metadata validation
# ---------------------------------------------------------------------------
class TestMetadataValidation:
    def test_dict_with_bad_field(self) -> None:
        with pytest.raises(SkillDefinitionError, match="could not construct SkillMetadata"):
            make_skill(metadata={"unknown_field": 1})

    def test_wrong_type(self) -> None:
        with pytest.raises(SkillDefinitionError, match="must be a SkillMetadata"):
            make_skill(metadata=42)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# @tool decorator
# ---------------------------------------------------------------------------
class TestToolDecorator:
    def test_registers_simple_tool(self) -> None:
        skill = make_skill()

        @skill.tool(description="Greet")
        def greet(name: str) -> str:
            """Greet.

            Args:
                name: who.
            """
            return f"hi {name}"

        assert len(skill.tools) == 1
        assert skill.tools[0].name == "greet"
        assert skill.tools[0].description == "Greet"

    def test_returns_function_unchanged(self) -> None:
        """Calling the decorated function directly must still work."""
        skill = make_skill()

        @skill.tool(description="Greet")
        def greet(name: str) -> str:
            return f"hi {name}"

        assert greet("World") == "hi World"

    def test_multiple_tools(self) -> None:
        skill = make_skill()

        @skill.tool(description="First")
        def first(x: int) -> int:
            return x

        @skill.tool(description="Second")
        def second(y: str) -> str:
            return y

        assert [t.name for t in skill.tools] == ["first", "second"]

    def test_duplicate_tool_name_rejected(self) -> None:
        skill = make_skill()

        @skill.tool(description="Greet")
        def greet(name: str) -> str:
            return name

        with pytest.raises(SkillDefinitionError, match="already has a tool named"):

            @skill.tool(description="Re-greet")
            def greet(name: str) -> str:
                return name

    def test_tools_property_returns_copy(self) -> None:
        """Mutating the returned list shouldn't affect the skill."""
        skill = make_skill()

        @skill.tool(description="Greet")
        def greet(name: str) -> str:
            return name

        snapshot = skill.tools
        snapshot.clear()
        assert len(skill.tools) == 1


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
class TestHelpers:
    def test_humanize(self) -> None:
        assert _humanize("hello-world") == "Hello World"
        assert _humanize("a") == "A"
        assert _humanize("x-y-z") == "X Y Z"

    def test_slug_suggestion(self) -> None:
        assert _slug_suggestion("GitHub-PR") == "github-pr"
        assert _slug_suggestion("Hello World!") == "hello-world"
        assert _slug_suggestion("___") is None


# ---------------------------------------------------------------------------
# Acceptance criteria from build_plan.md §Milestone 2
# ---------------------------------------------------------------------------
class TestBuildPlanAcceptance:
    """Mirrors the exact example in docs/build_plan.md §Milestone 2 acceptance."""

    def test_acceptance_example_constructs(self) -> None:
        skill = Skill(
            name="hello-world",
            version="1.0.0",
            description="A trivial test skill",
            capabilities=["secrets:GREETING"],
            secrets=[{"name": "GREETING", "type": "generic_string", "description": "..."}],
        )

        @skill.tool(description="Say hello")
        async def greet(name: str) -> str:
            """Greet someone.

            Args:
                name: Who to greet
            """
            return f"Hello, {name}"

        assert skill.name == "hello-world"
        assert len(skill.tools) == 1
        assert skill.tools[0].name == "greet"
        assert skill.tools[0].is_async is True
        assert skill.tools[0].parameters_schema["required"] == ["name"]
        assert skill.tools[0].parameters_schema["properties"]["name"] == {
            "type": "string",
            "description": "Who to greet",
        }


# ---------------------------------------------------------------------------
# Secret dataclass independent behavior
# ---------------------------------------------------------------------------
class TestSecretDataclass:
    def test_default_scope_required(self) -> None:
        secret = Secret(name="X", type="api_key", description="d")
        assert secret.scope_required is None

    def test_explicit_scope_required(self) -> None:
        secret = Secret(name="X", type="oauth_token", description="d", scope_required="repo:read")
        assert secret.scope_required == "repo:read"


@dataclass
class UnrelatedDC:
    x: int
