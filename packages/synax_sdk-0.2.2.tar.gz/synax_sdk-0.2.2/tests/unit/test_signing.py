"""Tests for ``synax_sdk.signing``."""

from __future__ import annotations

import base64
import json
import sys
from pathlib import Path

import pytest
from nacl.signing import SigningKey

from synax_sdk.signing import (
    ALGORITHM,
    KEY_FILE_VERSION,
    KeyPair,
    KeyStore,
    Signer,
    SigningError,
    Verifier,
    fingerprint_for_public_key,
    generate_keypair,
    load_keypair_from_file,
    load_public_key_from_file,
    save_keypair_to_file,
    save_public_key_to_file,
)


# ---------------------------------------------------------------------------
# fingerprint_for_public_key
# ---------------------------------------------------------------------------
class TestFingerprint:
    def test_format(self) -> None:
        fp = fingerprint_for_public_key(b"\x00" * 32)
        assert fp.startswith("sha256:")
        assert len(fp) == len("sha256:") + 64
        assert all(c in "0123456789abcdef" for c in fp[len("sha256:") :])

    def test_deterministic(self) -> None:
        fp1 = fingerprint_for_public_key(b"hello")
        fp2 = fingerprint_for_public_key(b"hello")
        assert fp1 == fp2

    def test_different_keys_different_fingerprints(self) -> None:
        assert fingerprint_for_public_key(b"a") != fingerprint_for_public_key(b"b")


# ---------------------------------------------------------------------------
# generate_keypair
# ---------------------------------------------------------------------------
class TestGenerateKeypair:
    def test_produces_full_keypair(self) -> None:
        kp = generate_keypair()
        assert kp.has_private
        assert kp.public_key is not None
        assert kp.private_key is not None
        assert kp.created_at is not None

    def test_keys_are_32_bytes(self) -> None:
        kp = generate_keypair()
        assert len(kp.public_key) == 32
        assert kp.private_key is not None
        assert len(kp.private_key) == 32

    def test_fingerprint_matches_public_key(self) -> None:
        kp = generate_keypair()
        assert kp.fingerprint == fingerprint_for_public_key(kp.public_key)

    def test_each_call_produces_distinct_keypair(self) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        assert kp1.fingerprint != kp2.fingerprint


# ---------------------------------------------------------------------------
# Sign / Verify round-trip
# ---------------------------------------------------------------------------
class TestSignAndVerify:
    def test_round_trip(self) -> None:
        kp = generate_keypair()
        payload = b"some canonical manifest bytes"
        sig = kp.signer().sign(payload)
        kp.verifier().verify(payload, sig)  # no raise

    def test_verify_returns_none_on_success(self) -> None:
        kp = generate_keypair()
        sig = kp.signer().sign(b"hi")
        assert kp.verifier().verify(b"hi", sig) is None

    def test_signature_is_base64(self) -> None:
        kp = generate_keypair()
        sig = kp.signer().sign(b"hi")
        # base64 round-trips cleanly
        decoded = base64.b64decode(sig, validate=True)
        assert len(decoded) == 64  # Ed25519 signature is 64 bytes

    def test_tamper_with_payload_fails_verification(self) -> None:
        kp = generate_keypair()
        sig = kp.signer().sign(b"original")
        with pytest.raises(SigningError, match="does not verify"):
            kp.verifier().verify(b"tampered", sig)

    def test_wrong_key_fails_verification(self) -> None:
        signer_kp = generate_keypair()
        other_kp = generate_keypair()
        sig = signer_kp.signer().sign(b"hi")
        with pytest.raises(SigningError, match="does not verify"):
            other_kp.verifier().verify(b"hi", sig)

    def test_malformed_signature_rejected(self) -> None:
        kp = generate_keypair()
        with pytest.raises(SigningError, match="not valid base64"):
            kp.verifier().verify(b"hi", "@@@not-base64@@@")


# ---------------------------------------------------------------------------
# Public-only KeyPair
# ---------------------------------------------------------------------------
class TestPublicOnlyKeypair:
    def test_signer_rejected(self) -> None:
        kp = generate_keypair()
        public_only = KeyPair(public_key=kp.public_key)
        assert not public_only.has_private
        with pytest.raises(SigningError, match="Cannot sign with public-only"):
            public_only.signer()

    def test_verifier_works(self) -> None:
        kp = generate_keypair()
        public_only = KeyPair(public_key=kp.public_key)
        sig = kp.signer().sign(b"hi")
        public_only.verifier().verify(b"hi", sig)


# ---------------------------------------------------------------------------
# save / load round-trip
# ---------------------------------------------------------------------------
class TestKeyFileIO:
    def test_save_then_load_full_keypair(self, tmp_path: Path) -> None:
        kp = generate_keypair()
        target = tmp_path / "x.key"
        save_keypair_to_file(kp, target)
        loaded = load_keypair_from_file(target)
        assert loaded.public_key == kp.public_key
        assert loaded.private_key == kp.private_key
        assert loaded.fingerprint == kp.fingerprint
        assert loaded.created_at == kp.created_at

    def test_file_format_is_versioned_json(self, tmp_path: Path) -> None:
        kp = generate_keypair()
        target = tmp_path / "x.key"
        save_keypair_to_file(kp, target)
        payload = json.loads(target.read_text(encoding="utf-8"))
        assert payload["version"] == KEY_FILE_VERSION
        assert payload["algorithm"] == ALGORITHM
        assert payload["fingerprint"] == kp.fingerprint
        assert "public_key_b64" in payload
        assert "private_key_b64" in payload

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX-only file mode")
    def test_save_sets_posix_600(self, tmp_path: Path) -> None:
        import stat as stat_mod

        kp = generate_keypair()
        target = tmp_path / "x.key"
        save_keypair_to_file(kp, target)
        mode = target.stat().st_mode & 0o777
        assert mode == (stat_mod.S_IRUSR | stat_mod.S_IWUSR)

    def test_save_public_key_only_strips_private(self, tmp_path: Path) -> None:
        kp = generate_keypair()
        target = tmp_path / "x.pub"
        save_public_key_to_file(kp, target)
        payload = json.loads(target.read_text(encoding="utf-8"))
        assert "private_key_b64" not in payload
        assert payload["fingerprint"] == kp.fingerprint

    def test_load_public_key_only(self, tmp_path: Path) -> None:
        kp = generate_keypair()
        target = tmp_path / "x.pub"
        save_public_key_to_file(kp, target)
        loaded = load_public_key_from_file(target)
        assert loaded.public_key == kp.public_key
        assert loaded.private_key is None

    def test_load_full_then_strip(self, tmp_path: Path) -> None:
        kp = generate_keypair()
        target = tmp_path / "x.key"
        save_keypair_to_file(kp, target)
        loaded = load_public_key_from_file(target)
        # load_public_key_from_file should drop private even if it was in the file
        assert loaded.private_key is None


# ---------------------------------------------------------------------------
# Error cases on load
# ---------------------------------------------------------------------------
class TestKeyFileErrors:
    def test_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(SigningError, match="not found"):
            load_keypair_from_file(tmp_path / "nope.key")

    def test_invalid_json(self, tmp_path: Path) -> None:
        target = tmp_path / "x.key"
        target.write_text("{not json", encoding="utf-8")
        with pytest.raises(SigningError, match="not valid JSON"):
            load_keypair_from_file(target)

    def test_wrong_algorithm(self, tmp_path: Path) -> None:
        target = tmp_path / "x.key"
        target.write_text(
            json.dumps({"algorithm": "RSA", "public_key_b64": "AAA="}),
            encoding="utf-8",
        )
        with pytest.raises(SigningError, match="algorithm"):
            load_keypair_from_file(target)

    def test_missing_public_key(self, tmp_path: Path) -> None:
        target = tmp_path / "x.key"
        target.write_text(json.dumps({"algorithm": ALGORITHM}), encoding="utf-8")
        with pytest.raises(SigningError, match="public_key_b64"):
            load_keypair_from_file(target)

    def test_bad_base64_public(self, tmp_path: Path) -> None:
        target = tmp_path / "x.key"
        target.write_text(
            json.dumps({"algorithm": ALGORITHM, "public_key_b64": "@@@"}),
            encoding="utf-8",
        )
        with pytest.raises(SigningError, match="not valid base64"):
            load_keypair_from_file(target)

    def test_bad_base64_private(self, tmp_path: Path) -> None:
        target = tmp_path / "x.key"
        target.write_text(
            json.dumps(
                {
                    "algorithm": ALGORITHM,
                    "public_key_b64": base64.b64encode(b"\x00" * 32).decode(),
                    "private_key_b64": "@@@",
                }
            ),
            encoding="utf-8",
        )
        with pytest.raises(SigningError, match="private_key_b64"):
            load_keypair_from_file(target)


# ---------------------------------------------------------------------------
# KeyStore
# ---------------------------------------------------------------------------
class TestKeyStore:
    def test_save_creates_file(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        path = store.save(kp)
        assert path.exists()
        assert path.parent == tmp_path

    def test_save_sets_default_when_empty(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        assert store.default_fingerprint == kp.fingerprint

    def test_second_save_doesnt_overwrite_default(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        assert store.default_fingerprint == kp1.fingerprint

    def test_set_default_to_known_key(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        store.set_default(kp2.fingerprint)
        assert store.default_fingerprint == kp2.fingerprint

    def test_set_default_to_unknown_key_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        with pytest.raises(SigningError, match="No key matching"):
            store.set_default("sha256:" + "a" * 64)

    def test_list_fingerprints(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        prints = store.list_fingerprints()
        assert kp1.fingerprint in prints
        assert kp2.fingerprint in prints
        assert len(prints) == 2

    def test_list_fingerprints_empty(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        assert store.list_fingerprints() == []

    def test_load_by_fingerprint(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        loaded = store.load(kp.fingerprint)
        assert loaded.public_key == kp.public_key

    def test_list_skips_malformed_files(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        (tmp_path / "garbage.key").write_text("{not json}", encoding="utf-8")
        prints = store.list_fingerprints()
        assert prints == [kp.fingerprint]

    def test_default_fingerprint_none_when_no_pointer(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        assert store.default_fingerprint is None

    def test_default_fingerprint_none_on_malformed_pointer(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        store.root.mkdir(exist_ok=True)
        (store.root / "default").write_text("{garbage", encoding="utf-8")
        assert store.default_fingerprint is None


# ---------------------------------------------------------------------------
# KeyPair.name + on-disk round-trip
# ---------------------------------------------------------------------------
class TestKeyPairName:
    def test_default_name_is_none(self) -> None:
        kp = generate_keypair()
        assert kp.name is None

    def test_generate_keypair_with_name(self) -> None:
        kp = generate_keypair(name="ci-bot")
        assert kp.name == "ci-bot"

    def test_save_load_round_trip_preserves_name(self, tmp_path: Path) -> None:
        kp = generate_keypair(name="ci-bot")
        path = tmp_path / "kp.key"
        save_keypair_to_file(kp, path)
        loaded = load_keypair_from_file(path)
        assert loaded.name == "ci-bot"

    def test_save_load_round_trip_omits_name_when_none(self, tmp_path: Path) -> None:
        kp = generate_keypair()
        path = tmp_path / "kp.key"
        save_keypair_to_file(kp, path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        assert "name" not in payload
        loaded = load_keypair_from_file(path)
        assert loaded.name is None

    def test_load_rejects_non_string_name(self, tmp_path: Path) -> None:
        path = tmp_path / "kp.key"
        path.write_text(
            json.dumps(
                {
                    "version": KEY_FILE_VERSION,
                    "algorithm": ALGORITHM,
                    "public_key_b64": base64.b64encode(b"\x00" * 32).decode("ascii"),
                    "name": 42,
                }
            ),
            encoding="utf-8",
        )
        with pytest.raises(SigningError, match="'name' must be a string"):
            load_keypair_from_file(path)

    def test_public_only_save_preserves_name(self, tmp_path: Path) -> None:
        kp = generate_keypair(name="ci-bot")
        path = tmp_path / "kp.pub"
        save_public_key_to_file(kp, path)
        loaded = load_public_key_from_file(path)
        assert loaded.name == "ci-bot"


# ---------------------------------------------------------------------------
# KeyStore.resolve — prefix lookup
# ---------------------------------------------------------------------------
class TestKeyStoreResolve:
    def test_full_fingerprint_resolves_to_itself(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        assert store.resolve(kp.fingerprint) == kp.fingerprint

    def test_short_prefix_resolves_when_unambiguous(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        assert store.resolve(hex_part[:8]) == kp.fingerprint

    def test_prefix_with_scheme_works(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        assert store.resolve(f"sha256:{hex_part[:10]}") == kp.fingerprint

    def test_uppercase_prefix_works(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        assert store.resolve(hex_part[:6].upper()) == kp.fingerprint

    def test_empty_prefix_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        with pytest.raises(SigningError, match="Empty fingerprint"):
            store.resolve("")
        with pytest.raises(SigningError, match="Empty fingerprint"):
            store.resolve("sha256:")
        with pytest.raises(SigningError, match="Empty fingerprint"):
            store.resolve("   ")

    def test_non_hex_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        with pytest.raises(SigningError, match="non-hex"):
            store.resolve("xyz!")

    def test_no_match_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        with pytest.raises(SigningError, match="No key matching"):
            store.resolve("abc123")

    def test_full_fingerprint_no_match_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        with pytest.raises(SigningError, match="No key matching"):
            store.resolve("sha256:" + "a" * 64)

    def test_ambiguous_prefix_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        # Forge two keys with the same hex prefix by writing the files directly
        # — generate_keypair() can't guarantee a collision. We write minimal
        # valid key files whose filenames + fingerprints share a prefix.
        pub_a = bytes.fromhex("ab" + "00" * 31)
        pub_b = bytes.fromhex("ac" + "00" * 31)
        fp_a = "sha256:" + __import__("hashlib").sha256(pub_a).hexdigest()
        fp_b = "sha256:" + __import__("hashlib").sha256(pub_b).hexdigest()
        # Find a hex prefix shared by both fingerprints' hex portions.
        ha = fp_a.removeprefix("sha256:")
        hb = fp_b.removeprefix("sha256:")
        shared = ""
        for ca, cb in zip(ha, hb, strict=False):
            if ca == cb:
                shared += ca
            else:
                break
        if not shared:
            pytest.skip("randomly generated test fingerprints do not share a prefix")
        # Save both via the normal KeyPair → save path.
        store.save(KeyPair(public_key=pub_a))
        store.save(KeyPair(public_key=pub_b))
        with pytest.raises(SigningError, match="Ambiguous prefix"):
            store.resolve(shared)

    def test_load_accepts_prefix(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        loaded = store.load(hex_part[:8])
        assert loaded.public_key == kp.public_key

    def test_set_default_accepts_prefix(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        hex2 = kp2.fingerprint.removeprefix("sha256:")
        store.set_default(hex2[:8])
        # The pointer stores the canonical full fingerprint, not the prefix.
        assert store.default_fingerprint == kp2.fingerprint


# ---------------------------------------------------------------------------
# KeyStore.delete
# ---------------------------------------------------------------------------
class TestKeyStoreDelete:
    def test_delete_removes_the_file(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        path = store._file_for(kp2.fingerprint)
        store.delete(kp2.fingerprint)
        assert not path.exists()
        assert kp2.fingerprint not in store.list_fingerprints()

    def test_delete_returns_resolved_fingerprint(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        kp_other = generate_keypair()
        store.save(kp)
        store.save(kp_other)
        store.set_default(kp.fingerprint)  # so kp_other isn't default
        hex_part = kp_other.fingerprint.removeprefix("sha256:")
        returned = store.delete(hex_part[:8])
        assert returned == kp_other.fingerprint

    def test_delete_refuses_default_without_force(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)  # becomes default automatically
        with pytest.raises(SigningError, match="default signing key"):
            store.delete(kp.fingerprint)
        assert store._file_for(kp.fingerprint).exists()

    def test_delete_default_with_force_clears_pointer(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        kp = generate_keypair()
        store.save(kp)
        assert store.default_fingerprint == kp.fingerprint
        store.delete(kp.fingerprint, force=True)
        assert store.default_fingerprint is None
        assert not store._file_for(kp.fingerprint).exists()

    def test_delete_unknown_raises(self, tmp_path: Path) -> None:
        store = KeyStore(root=tmp_path)
        with pytest.raises(SigningError, match="No key matching"):
            store.delete("sha256:" + "a" * 64)


# ---------------------------------------------------------------------------
# Cross-implementation check — our signatures verify against raw PyNaCl
# ---------------------------------------------------------------------------
class TestCryptoSanity:
    def test_signature_verifies_via_pynacl_directly(self) -> None:
        """Sign with our Signer, verify with raw nacl.signing.VerifyKey."""
        kp = generate_keypair()
        payload = b"sanity"
        sig_b64 = kp.signer().sign(payload)
        sig_bytes = base64.b64decode(sig_b64)
        # Use raw PyNaCl to verify — independently confirms our signature is valid.
        verify_key = SigningKey(kp.private_key).verify_key  # type: ignore[arg-type]
        verify_key.verify(payload, sig_bytes)  # raises if bad


# ---------------------------------------------------------------------------
# Signer / Verifier dataclasses
# ---------------------------------------------------------------------------
class TestSignerVerifierShape:
    def test_signer_holds_keypair(self) -> None:
        kp = generate_keypair()
        s = Signer(keypair=kp)
        assert s.keypair is kp

    def test_verifier_holds_keypair(self) -> None:
        kp = generate_keypair()
        v = Verifier(keypair=kp)
        assert v.keypair is kp

    def test_signer_without_private_raises(self) -> None:
        kp = KeyPair(public_key=b"\x00" * 32)
        s = Signer(keypair=kp)
        with pytest.raises(SigningError, match="missing its private key"):
            s.sign(b"x")
