"""Tests for ``synax_skill_cli.utils.project``."""

from __future__ import annotations

from pathlib import Path

import pytest

from synax_sdk.errors import BuildError
from synax_sdk.skill import Skill
from synax_skill_cli.utils.project import (
    find_project_root,
    load_skill_from_project,
    read_synax_config,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
PYPROJECT_TEMPLATE = """\
[project]
name = "test-skill"
version = "0.1.0"

[tool.synax]
entry_point = "my_skill:skill"
"""

SKILL_SOURCE = """\
from synax_sdk import Skill

skill = Skill(
    name="my-skill",
    version="0.1.0",
    description="A test skill",
)

@skill.tool(description="Echo the input")
def echo(text: str) -> str:
    \"\"\"Echo.

    Args:
        text: input.
    \"\"\"
    return text
"""


def _make_project(
    root: Path, *, pyproject: str = PYPROJECT_TEMPLATE, skill_src: str = SKILL_SOURCE
) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    (root / "pyproject.toml").write_text(pyproject, encoding="utf-8")
    (root / "my_skill.py").write_text(skill_src, encoding="utf-8")
    return root


# ---------------------------------------------------------------------------
# find_project_root
# ---------------------------------------------------------------------------
class TestFindProjectRoot:
    def test_finds_root_when_started_at_root(self, tmp_path: Path) -> None:
        _make_project(tmp_path)
        assert find_project_root(tmp_path) == tmp_path.resolve()

    def test_walks_up_from_subdirectory(self, tmp_path: Path) -> None:
        _make_project(tmp_path)
        subdir = tmp_path / "a" / "b" / "c"
        subdir.mkdir(parents=True)
        assert find_project_root(subdir) == tmp_path.resolve()

    def test_skips_pyproject_without_synax_section(self, tmp_path: Path) -> None:
        outer = tmp_path / "outer"
        outer.mkdir()
        (outer / "pyproject.toml").write_text(
            "[project]\nname = 'unrelated'\nversion = '1.0'\n",
            encoding="utf-8",
        )
        inner = outer / "inner"
        _make_project(inner)
        # Starting from inner should find inner — outer doesn't have [tool.synax]
        assert find_project_root(inner) == inner.resolve()

    def test_raises_when_no_project_found(self, tmp_path: Path) -> None:
        with pytest.raises(BuildError, match="No skill project found"):
            find_project_root(tmp_path)

    def test_defaults_to_cwd(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        _make_project(tmp_path)
        monkeypatch.chdir(tmp_path)
        assert find_project_root() == tmp_path.resolve()


# ---------------------------------------------------------------------------
# read_synax_config
# ---------------------------------------------------------------------------
class TestReadSynaxConfig:
    def test_returns_section(self, tmp_path: Path) -> None:
        _make_project(tmp_path)
        config = read_synax_config(tmp_path)
        assert config["entry_point"] == "my_skill:skill"

    def test_missing_pyproject_raises(self, tmp_path: Path) -> None:
        with pytest.raises(BuildError, match=r"pyproject\.toml missing"):
            read_synax_config(tmp_path)

    def test_malformed_toml_raises(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[not toml", encoding="utf-8")
        with pytest.raises(BuildError, match="not valid TOML"):
            read_synax_config(tmp_path)

    def test_missing_synax_section_raises(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\nversion = '0.1.0'\n",
            encoding="utf-8",
        )
        with pytest.raises(BuildError, match=r"no \[tool\.synax\]"):
            read_synax_config(tmp_path)


# ---------------------------------------------------------------------------
# load_skill_from_project
# ---------------------------------------------------------------------------
class TestLoadSkillFromProject:
    def test_loads_skill(self, tmp_path: Path) -> None:
        _make_project(tmp_path)
        skill = load_skill_from_project(tmp_path)
        assert isinstance(skill, Skill)
        assert skill.name == "my-skill"
        assert len(skill.tools) == 1
        assert skill.tools[0].name == "echo"

    def test_missing_entry_point_raises(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[tool.synax]\n",
            encoding="utf-8",
        )
        (tmp_path / "x.py").write_text("", encoding="utf-8")
        with pytest.raises(BuildError, match="entry_point is missing or malformed"):
            load_skill_from_project(tmp_path)

    def test_malformed_entry_point_no_colon(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[tool.synax]\nentry_point = "no_colon"\n',
            encoding="utf-8",
        )
        with pytest.raises(BuildError, match="entry_point is missing or malformed"):
            load_skill_from_project(tmp_path)

    def test_empty_module_or_variable(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[tool.synax]\nentry_point = ":skill"\n',
            encoding="utf-8",
        )
        with pytest.raises(BuildError, match="non-empty module and variable"):
            load_skill_from_project(tmp_path)

    def test_module_not_found(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[tool.synax]\nentry_point = "nonexistent:skill"\n',
            encoding="utf-8",
        )
        with pytest.raises(BuildError, match="Could not import 'nonexistent'"):
            load_skill_from_project(tmp_path)

    def test_attribute_missing_on_module(self, tmp_path: Path) -> None:
        _make_project(
            tmp_path,
            pyproject='[tool.synax]\nentry_point = "my_skill:wrong_name"\n',
        )
        with pytest.raises(BuildError, match="no attribute 'wrong_name'"):
            load_skill_from_project(tmp_path)

    def test_attribute_is_not_skill(self, tmp_path: Path) -> None:
        _make_project(
            tmp_path,
            skill_src="skill = 42\n",
            pyproject='[tool.synax]\nentry_point = "my_skill:skill"\n',
        )
        with pytest.raises(BuildError, match=r"not a synax_sdk\.Skill"):
            load_skill_from_project(tmp_path)
