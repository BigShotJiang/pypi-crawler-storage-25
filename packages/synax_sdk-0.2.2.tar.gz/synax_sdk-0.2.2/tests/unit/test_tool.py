"""Tests for ``synax_sdk.tool``.

Covers three concerns: type-hint → JSON Schema translation, Google-style
docstring parsing, and the ``Tool.from_function`` factory's end-to-end
behaviour including its error messages.

NOTE: This file deliberately does NOT use ``from __future__ import
annotations``. Several tests define classes inside test methods and then
pass functions whose annotations reference those local classes to
``Tool.from_function``. With future annotations, annotations become
strings that ``typing.get_type_hints`` resolves against the function's
``__globals__`` — local classes aren't visible there, so resolution fails.
We keep real-class annotations to mirror what skill authors actually write.
"""

from dataclasses import dataclass
from typing import Any, Literal, Optional, TypedDict, Union

import pytest

from synax_sdk.errors import SkillDefinitionError
from synax_sdk.tool import Tool, _parse_google_docstring, python_type_to_json_schema


# ---------------------------------------------------------------------------
# python_type_to_json_schema — primitives
# ---------------------------------------------------------------------------
class TestPrimitives:
    @pytest.mark.parametrize(
        ("tp", "expected"),
        [
            (str, {"type": "string"}),
            (int, {"type": "integer"}),
            (float, {"type": "number"}),
            (bool, {"type": "boolean"}),
            (bytes, {"type": "string", "contentEncoding": "base64"}),
            (type(None), {"type": "null"}),
            (None, {"type": "null"}),
            (Any, {}),
        ],
    )
    def test_primitive(self, tp: Any, expected: dict[str, Any]) -> None:
        assert python_type_to_json_schema(tp) == expected


# ---------------------------------------------------------------------------
# python_type_to_json_schema — containers
# ---------------------------------------------------------------------------
class TestContainers:
    def test_list_of_str(self) -> None:
        assert python_type_to_json_schema(list[str]) == {
            "type": "array",
            "items": {"type": "string"},
        }

    def test_list_of_int(self) -> None:
        assert python_type_to_json_schema(list[int]) == {
            "type": "array",
            "items": {"type": "integer"},
        }

    def test_nested_list(self) -> None:
        assert python_type_to_json_schema(list[list[int]]) == {
            "type": "array",
            "items": {"type": "array", "items": {"type": "integer"}},
        }

    def test_bare_list_has_no_items(self) -> None:
        assert python_type_to_json_schema(list) == {"type": "array"}

    def test_dict_str_to_int(self) -> None:
        assert python_type_to_json_schema(dict[str, int]) == {
            "type": "object",
            "additionalProperties": {"type": "integer"},
        }

    def test_dict_with_non_str_key_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="dict keys must be str"):
            python_type_to_json_schema(dict[int, str])

    def test_bare_dict(self) -> None:
        assert python_type_to_json_schema(dict) == {"type": "object"}

    def test_set_of_str(self) -> None:
        assert python_type_to_json_schema(set[str]) == {
            "type": "array",
            "items": {"type": "string"},
        }

    def test_tuple_variadic(self) -> None:
        assert python_type_to_json_schema(tuple[int, ...]) == {
            "type": "array",
            "items": {"type": "integer"},
        }

    def test_tuple_fixed_length_rejected(self) -> None:
        with pytest.raises(SkillDefinitionError, match="fixed-length tuple"):
            python_type_to_json_schema(tuple[int, str])


# ---------------------------------------------------------------------------
# python_type_to_json_schema — Union / Optional
# ---------------------------------------------------------------------------
class TestUnion:
    def test_optional_str_typing(self) -> None:
        result = python_type_to_json_schema(Optional[str])  # noqa: UP045 — intentional legacy form
        assert result == {"anyOf": [{"type": "string"}, {"type": "null"}]}

    def test_optional_str_pipe_syntax(self) -> None:
        result = python_type_to_json_schema(str | None)
        assert result == {"anyOf": [{"type": "string"}, {"type": "null"}]}

    def test_union_three_types(self) -> None:
        legacy_union = Union[str, int, bool]  # noqa: UP007 — intentional legacy form
        result = python_type_to_json_schema(legacy_union)
        assert result == {"anyOf": [{"type": "string"}, {"type": "integer"}, {"type": "boolean"}]}

    def test_union_pipe_three_types(self) -> None:
        result = python_type_to_json_schema(str | int | bool)
        assert result == {"anyOf": [{"type": "string"}, {"type": "integer"}, {"type": "boolean"}]}


# ---------------------------------------------------------------------------
# python_type_to_json_schema — Literal
# ---------------------------------------------------------------------------
class TestLiteral:
    def test_literal_strings_get_string_type(self) -> None:
        result = python_type_to_json_schema(Literal["red", "green", "blue"])
        assert result == {"type": "string", "enum": ["red", "green", "blue"]}

    def test_literal_ints_get_integer_type(self) -> None:
        result = python_type_to_json_schema(Literal[1, 2, 3])
        assert result == {"type": "integer", "enum": [1, 2, 3]}

    def test_literal_bools_get_boolean_type(self) -> None:
        result = python_type_to_json_schema(Literal[True, False])
        assert result == {"type": "boolean", "enum": [True, False]}

    def test_literal_mixed_types_omits_type(self) -> None:
        result = python_type_to_json_schema(Literal["one", 1])
        assert "type" not in result
        assert result["enum"] == ["one", 1]


# ---------------------------------------------------------------------------
# python_type_to_json_schema — TypedDict
# ---------------------------------------------------------------------------
class PRSummary(TypedDict):
    title: str
    summary: str
    files_changed: int


class PartialPRSummary(TypedDict, total=False):
    title: str
    summary: str


class TestTypedDict:
    def test_required_keys(self) -> None:
        result = python_type_to_json_schema(PRSummary)
        assert result["type"] == "object"
        assert result["properties"] == {
            "title": {"type": "string"},
            "summary": {"type": "string"},
            "files_changed": {"type": "integer"},
        }
        assert sorted(result["required"]) == ["files_changed", "summary", "title"]

    def test_total_false_has_no_required(self) -> None:
        result = python_type_to_json_schema(PartialPRSummary)
        assert "required" not in result
        assert result["properties"] == {
            "title": {"type": "string"},
            "summary": {"type": "string"},
        }


# ---------------------------------------------------------------------------
# python_type_to_json_schema — dataclass
# ---------------------------------------------------------------------------
@dataclass
class Point:
    x: int
    y: int


@dataclass
class PointWithDefault:
    x: int
    y: int = 0


class TestDataclass:
    def test_required_fields(self) -> None:
        result = python_type_to_json_schema(Point)
        assert result == {
            "type": "object",
            "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}},
            "required": ["x", "y"],
        }

    def test_field_with_default_is_not_required(self) -> None:
        result = python_type_to_json_schema(PointWithDefault)
        assert result["required"] == ["x"]


# ---------------------------------------------------------------------------
# python_type_to_json_schema — error cases
# ---------------------------------------------------------------------------
class TestUnsupportedTypes:
    def test_unknown_class_rejected(self) -> None:
        class Unrelated:
            pass

        with pytest.raises(SkillDefinitionError, match="unsupported type annotation"):
            python_type_to_json_schema(Unrelated)

    def test_error_includes_where_context(self) -> None:
        with pytest.raises(SkillDefinitionError, match="tool 'foo' parameter 'bar'"):
            python_type_to_json_schema(object, where="tool 'foo' parameter 'bar'")


# ---------------------------------------------------------------------------
# _parse_google_docstring
# ---------------------------------------------------------------------------
class TestDocstringParser:
    def test_empty_returns_empty(self) -> None:
        assert _parse_google_docstring(None) == {}
        assert _parse_google_docstring("") == {}

    def test_no_args_section_returns_empty(self) -> None:
        doc = "Just a description with no Args section."
        assert _parse_google_docstring(doc) == {}

    def test_basic_args_section(self) -> None:
        doc = """Summary line.

        Args:
            repo: Repository in format owner/name
            pr_number: Pull request number
        """
        assert _parse_google_docstring(doc) == {
            "repo": "Repository in format owner/name",
            "pr_number": "Pull request number",
        }

    def test_continuation_lines(self) -> None:
        doc = """Summary.

        Args:
            repo: Repository in format owner/name.
                Can include the prefix github.com/ but doesn't need to.
            limit: Max items to return
        """
        result = _parse_google_docstring(doc)
        assert "Can include the prefix" in result["repo"]
        assert result["limit"] == "Max items to return"

    def test_alternative_section_names(self) -> None:
        for header in ("Arguments:", "Parameters:"):
            doc = f"Summary.\n\n        {header}\n            name: A name\n        "
            assert _parse_google_docstring(doc) == {"name": "A name"}

    def test_other_sections_ignored(self) -> None:
        doc = """Summary.

        Args:
            x: First arg

        Returns:
            Some value.

        Raises:
            ValueError: when broken
        """
        assert _parse_google_docstring(doc) == {"x": "First arg"}

    def test_args_section_terminated_by_returns(self) -> None:
        """Lines after Returns: must not be treated as new params."""
        doc = """Summary.

        Args:
            x: First

        Returns:
            something: not an arg
        """
        assert _parse_google_docstring(doc) == {"x": "First"}


# ---------------------------------------------------------------------------
# Tool.from_function — happy paths
# ---------------------------------------------------------------------------
class TestFromFunction:
    def test_simple_sync_function(self) -> None:
        def greet(name: str) -> str:
            """Greet someone.

            Args:
                name: Who to greet.
            """
            return f"hi {name}"

        tool = Tool.from_function(greet, description="Greet someone")

        assert tool.name == "greet"
        assert tool.description == "Greet someone"
        assert tool.is_async is False
        assert tool.parameters_schema == {
            "type": "object",
            "properties": {"name": {"type": "string", "description": "Who to greet."}},
            "required": ["name"],
        }
        assert tool.returns_schema == {"type": "string"}
        assert tool.func is greet

    def test_async_function_is_async(self) -> None:
        async def fetch(url: str) -> dict:
            return {}

        tool = Tool.from_function(fetch, description="Fetch URL")
        assert tool.is_async is True

    def test_parameter_with_default_is_not_required(self) -> None:
        def list_prs(repo: str, limit: int = 10) -> list[dict]:
            """List PRs.

            Args:
                repo: Repository.
                limit: Max PRs.
            """
            return []

        tool = Tool.from_function(list_prs, description="List PRs")
        props = tool.parameters_schema["properties"]
        assert props["limit"]["default"] == 10
        assert tool.parameters_schema["required"] == ["repo"]

    def test_function_with_no_return_annotation(self) -> None:
        def noop():  # type: ignore[no-untyped-def]
            return None

        tool = Tool.from_function(noop, description="Noop")
        assert tool.returns_schema is None
        assert tool.parameters_schema == {"type": "object", "properties": {}}

    def test_return_type_none_is_none(self) -> None:
        def noop() -> None:
            return None

        tool = Tool.from_function(noop, description="Noop")
        assert tool.returns_schema is None

    def test_explicit_name_override(self) -> None:
        def my_func() -> None:
            pass

        tool = Tool.from_function(my_func, description="X", name="renamed_tool")
        assert tool.name == "renamed_tool"

    def test_complex_signature(self) -> None:
        def summarize_pr(repo: str, pr_number: int) -> PRSummary:
            """Fetch and summarize.

            Args:
                repo: Repository in format owner/name.
                pr_number: Pull request number.
            """
            return PRSummary(title="", summary="", files_changed=0)

        tool = Tool.from_function(summarize_pr, description="Summarize a PR")
        assert tool.parameters_schema == {
            "type": "object",
            "properties": {
                "repo": {
                    "type": "string",
                    "description": "Repository in format owner/name.",
                },
                "pr_number": {
                    "type": "integer",
                    "description": "Pull request number.",
                },
            },
            "required": ["repo", "pr_number"],
        }
        assert tool.returns_schema is not None
        assert tool.returns_schema["type"] == "object"
        assert "title" in tool.returns_schema["properties"]


# ---------------------------------------------------------------------------
# Tool.from_function — error cases
# ---------------------------------------------------------------------------
class TestFromFunctionErrors:
    def test_missing_description(self) -> None:
        def f(x: int) -> int:
            return x

        with pytest.raises(SkillDefinitionError, match="non-empty description"):
            Tool.from_function(f, description="")

    def test_whitespace_only_description(self) -> None:
        def f(x: int) -> int:
            return x

        with pytest.raises(SkillDefinitionError, match="non-empty description"):
            Tool.from_function(f, description="   ")

    def test_bad_tool_name(self) -> None:
        def f() -> None:
            pass

        with pytest.raises(SkillDefinitionError, match="snake_case"):
            Tool.from_function(f, description="x", name="Bad-Name")

    def test_uppercase_function_name_rejected(self) -> None:
        def BadName() -> None:  # noqa: N802 — intentional bad name
            pass

        with pytest.raises(SkillDefinitionError, match="snake_case"):
            Tool.from_function(BadName, description="x")

    def test_missing_annotation(self) -> None:
        def f(x) -> int:  # type: ignore[no-untyped-def]
            return 0

        with pytest.raises(SkillDefinitionError, match="no type annotation"):
            Tool.from_function(f, description="x")

    def test_var_positional_rejected(self) -> None:
        def f(*args: int) -> int:
            return 0

        with pytest.raises(SkillDefinitionError, match=r"\*args"):
            Tool.from_function(f, description="x")

    def test_var_keyword_rejected(self) -> None:
        def f(**kwargs: int) -> int:
            return 0

        with pytest.raises(SkillDefinitionError, match=r"\*\*kwargs"):
            Tool.from_function(f, description="x")

    def test_self_and_cls_skipped(self) -> None:
        """``self`` and ``cls`` are tolerated (unusual but technical_plan allows them)."""

        class Container:
            def method(self, x: int) -> int:
                return x

        tool = Tool.from_function(Container.method, description="x", name="method")
        assert "self" not in tool.parameters_schema["properties"]
        assert "x" in tool.parameters_schema["properties"]

    def test_unsupported_param_type_includes_param_name_in_error(self) -> None:
        class Unrelated:
            pass

        def f(weird: Unrelated) -> None:  # type: ignore[type-arg]
            pass

        with pytest.raises(SkillDefinitionError, match="parameter 'weird'"):
            Tool.from_function(f, description="x")
