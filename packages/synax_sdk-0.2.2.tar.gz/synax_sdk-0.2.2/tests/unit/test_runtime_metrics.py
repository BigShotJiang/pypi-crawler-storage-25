"""Tests for the ``metrics`` facade and ``MockPlatform.metrics``."""

import pytest

from synax_sdk.errors import SkillRuntimeError
from synax_sdk.runtime.metrics import (
    COUNTER_KIND,
    GAUGE_KIND,
    HISTOGRAM_KIND,
    Counter,
    Gauge,
    Histogram,
    metrics,
)
from synax_sdk.testing import CounterState, GaugeState, HistogramState, MockPlatform


# ---------------------------------------------------------------------------
# No active backend
# ---------------------------------------------------------------------------
class TestMetricsNoBackend:
    def test_counter_factory_raises(self) -> None:
        with pytest.raises(SkillRuntimeError):
            metrics.counter("x")

    def test_gauge_factory_raises(self) -> None:
        with pytest.raises(SkillRuntimeError):
            metrics.gauge("x")

    def test_histogram_factory_raises(self) -> None:
        with pytest.raises(SkillRuntimeError):
            metrics.histogram("x")


# ---------------------------------------------------------------------------
# Counter
# ---------------------------------------------------------------------------
class TestCounter:
    def test_factory_returns_counter(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            c = metrics.counter("requests")
        assert isinstance(c, Counter)
        assert c.name == "requests"
        assert c.labels == {}

    def test_inc_default_is_one(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("requests").inc()
        assert mock.metrics.counters["requests"].value == 1.0

    def test_inc_with_by(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("requests").inc(by=5)
        assert mock.metrics.counters["requests"].value == 5.0

    def test_inc_accumulates(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("requests").inc()
            metrics.counter("requests").inc(by=3)
            metrics.counter("requests").inc()
        assert mock.metrics.counters["requests"].value == 5.0

    def test_inc_across_labels_aggregates_in_default_view(self) -> None:
        """`.counters` is aggregated by name only; label-aware checks use `.records`."""
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("requests", labels={"endpoint": "/a"}).inc()
            metrics.counter("requests", labels={"endpoint": "/b"}).inc(2)
        assert mock.metrics.counters["requests"].value == 3.0

    def test_records_preserve_labels(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("requests", labels={"endpoint": "/a"}).inc()
            metrics.counter("requests", labels={"endpoint": "/b"}).inc()
        records = [r for r in mock.metrics.records if r.kind == COUNTER_KIND]
        assert {tuple(sorted(r.labels.items())) for r in records} == {
            (("endpoint", "/a"),),
            (("endpoint", "/b"),),
        }

    def test_counter_state_dataclass(self) -> None:
        s = CounterState(name="x", value=2.5)
        assert s.name == "x"
        assert s.value == 2.5


# ---------------------------------------------------------------------------
# Gauge
# ---------------------------------------------------------------------------
class TestGauge:
    def test_factory_returns_gauge(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            g = metrics.gauge("workers")
        assert isinstance(g, Gauge)

    def test_set_records_value(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.gauge("workers").set(42)
        assert mock.metrics.gauges["workers"].value == 42.0

    def test_set_takes_latest_value(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.gauge("workers").set(1)
            metrics.gauge("workers").set(2)
            metrics.gauge("workers").set(3)
        assert mock.metrics.gauges["workers"].value == 3.0

    def test_gauge_state_dataclass(self) -> None:
        s = GaugeState(name="x", value=1.0)
        assert s.value == 1.0


# ---------------------------------------------------------------------------
# Histogram
# ---------------------------------------------------------------------------
class TestHistogram:
    def test_factory_returns_histogram(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            h = metrics.histogram("latency_ms")
        assert isinstance(h, Histogram)

    def test_observe_records_value(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.histogram("latency_ms").observe(123.4)
        state = mock.metrics.histograms["latency_ms"]
        assert state.values == [123.4]
        assert state.count == 1
        assert state.sum == 123.4

    def test_multiple_observations_accumulate(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.histogram("latency_ms").observe(10)
            metrics.histogram("latency_ms").observe(20)
            metrics.histogram("latency_ms").observe(30)
        state = mock.metrics.histograms["latency_ms"]
        assert state.values == [10.0, 20.0, 30.0]
        assert state.count == 3
        assert state.sum == 60.0

    def test_histogram_state_empty(self) -> None:
        s = HistogramState(name="x")
        assert s.count == 0
        assert s.sum == 0


# ---------------------------------------------------------------------------
# Cross-cutting
# ---------------------------------------------------------------------------
class TestMixedMetricTypes:
    def test_different_kinds_don_t_interfere(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("name_x").inc()
            metrics.gauge("name_x").set(99)
            metrics.histogram("name_x").observe(50)
        # Same name, different kinds — each lands in its own aggregation bucket.
        assert mock.metrics.counters["name_x"].value == 1.0
        assert mock.metrics.gauges["name_x"].value == 99.0
        assert mock.metrics.histograms["name_x"].values == [50.0]

    def test_records_in_call_order(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("a").inc()
            metrics.gauge("b").set(1)
            metrics.histogram("c").observe(10)
        kinds = [r.kind for r in mock.metrics.records]
        assert kinds == [COUNTER_KIND, GAUGE_KIND, HISTOGRAM_KIND]

    def test_records_is_defensive_copy(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            metrics.counter("a").inc()
        snapshot = mock.metrics.records
        snapshot.clear()
        assert len(mock.metrics.records) == 1

    def test_empty_aggregations(self) -> None:
        mock = MockPlatform()
        assert mock.metrics.counters == {}
        assert mock.metrics.gauges == {}
        assert mock.metrics.histograms == {}
        assert mock.metrics.records == []
