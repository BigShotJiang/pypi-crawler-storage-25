"""Tests for the SDK exception hierarchy.

These verify the inheritance relationships and that every SDK-raised error
can be caught with a single ``except SynaxSDKError`` clause.
"""

from __future__ import annotations

import pytest

from synax_sdk.errors import (
    CapabilityError,
    ManifestError,
    SkillDefinitionError,
    SkillValidationError,
    SynaxSDKError,
)


class TestHierarchy:
    """Every SDK error must inherit from SynaxSDKError, and SynaxSDKError from Exception."""

    def test_base_inherits_from_exception(self) -> None:
        assert issubclass(SynaxSDKError, Exception)

    @pytest.mark.parametrize(
        "subclass",
        [SkillDefinitionError, SkillValidationError, ManifestError, CapabilityError],
    )
    def test_subclasses_inherit_from_base(self, subclass: type[SynaxSDKError]) -> None:
        assert issubclass(subclass, SynaxSDKError)

    def test_definition_and_validation_are_distinct(self) -> None:
        """SkillDefinitionError and SkillValidationError should not be each other's subclass."""
        assert not issubclass(SkillDefinitionError, SkillValidationError)
        assert not issubclass(SkillValidationError, SkillDefinitionError)

    def test_manifest_error_is_distinct(self) -> None:
        assert not issubclass(ManifestError, SkillDefinitionError)
        assert not issubclass(ManifestError, SkillValidationError)


class TestCatchableAsBase:
    """A single ``except SynaxSDKError`` must catch every SDK-raised exception."""

    @pytest.mark.parametrize(
        "exc_cls",
        [SkillDefinitionError, SkillValidationError, ManifestError, SynaxSDKError],
    )
    def test_caught_by_base(self, exc_cls: type[SynaxSDKError]) -> None:
        with pytest.raises(SynaxSDKError):
            raise exc_cls("boom")


class TestMessageRoundTrip:
    """Exception arguments behave like a normal Exception."""

    def test_message_preserved(self) -> None:
        err = SkillDefinitionError("invalid name 'GitHub-PR'")
        assert str(err) == "invalid name 'GitHub-PR'"

    def test_args_tuple(self) -> None:
        err = ManifestError("bad", "schema")
        assert err.args == ("bad", "schema")


class TestCapabilityError:
    """CapabilityError carries the requested + available capabilities."""

    def test_attributes_preserved(self) -> None:
        err = CapabilityError(
            requested="network:api.example.com",
            available=frozenset({"network:api.github.com"}),
        )
        assert err.requested == "network:api.example.com"
        assert err.available == frozenset({"network:api.github.com"})

    def test_message_lists_requested_and_available(self) -> None:
        err = CapabilityError(
            requested="network:api.example.com",
            available=frozenset({"network:api.github.com", "network:api.slack.com"}),
        )
        message = str(err)
        assert "'network:api.example.com'" in message
        # Available list is sorted for deterministic messages.
        assert "network:api.github.com, network:api.slack.com" in message

    def test_message_when_no_capabilities_available(self) -> None:
        err = CapabilityError(requested="network:api.example.com", available=frozenset())
        assert "(none)" in str(err)

    def test_available_coerced_to_frozenset(self) -> None:
        """Accepts any iterable but stores as frozenset for safety."""
        err = CapabilityError(
            requested="network:x",
            available=frozenset({"network:y"}),
        )
        assert isinstance(err.available, frozenset)

    def test_catchable_as_base(self) -> None:
        with pytest.raises(SynaxSDKError):
            raise CapabilityError(requested="x", available=frozenset())
