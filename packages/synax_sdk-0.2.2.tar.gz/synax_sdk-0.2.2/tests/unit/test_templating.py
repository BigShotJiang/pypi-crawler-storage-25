"""Tests for ``synax_skill_cli.utils.templating``."""

from __future__ import annotations

from pathlib import Path

import pytest

from synax_skill_cli.utils.templating import (
    TEMPLATE_MANIFEST,
    RenderedFile,
    TemplateError,
    render_template_dir,
)

_DEFAULT_VARS = {
    "skill_name": "my-skill",
    "skill_name_snake": "my_skill",
    "skill_name_human": "My Skill",
    "author_name": "Test Author",
    "version": "0.1.0",
    "sdk_version": "9.9.9-test",
}


class TestRenderTemplateDir:
    def test_creates_every_expected_file(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        results = render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        # One RenderedFile per template manifest entry.
        assert len(results) == len(TEMPLATE_MANIFEST)
        assert all(isinstance(r, RenderedFile) for r in results)
        for r in results:
            assert r.destination.exists(), f"missing: {r.destination}"

    def test_returns_files_in_manifest_order(self, tmp_path: Path) -> None:
        results = render_template_dir(output_dir=tmp_path / "proj", variables=_DEFAULT_VARS)
        sources = [r.source for r in results]
        assert sources == [src for src, _ in TEMPLATE_MANIFEST]

    def test_pyproject_substitutes_skill_name(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        text = (out / "pyproject.toml").read_text(encoding="utf-8")
        assert 'name = "my-skill"' in text
        assert 'version = "0.1.0"' in text
        assert 'authors = [{ name = "Test Author" }]' in text
        assert 'entry_point = "my_skill:skill"' in text
        assert "synax-sdk>=9.9.9-test" in text

    def test_skill_module_renamed_by_variable(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        # The destination uses ${skill_name_snake} → my_skill.py
        assert (out / "my_skill.py").exists()
        assert not (out / "skill.py").exists()
        assert not (out / "${skill_name_snake}.py").exists()

    def test_skill_module_contents_substituted(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        text = (out / "my_skill.py").read_text(encoding="utf-8")
        assert 'name="my-skill"' in text
        assert 'version="0.1.0"' in text
        # The f-string body `{greeting}, {name}` should pass through unchanged.
        assert 'return f"{greeting}, {name}"' in text

    def test_nested_directories_created(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        assert (out / "tests" / "test_skill.py").exists()
        assert (out / "test_inputs" / "greet" / "case_basic.yaml").exists()

    def test_synax_skillignore_present(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        text = (out / ".synax-skillignore").read_text(encoding="utf-8")
        assert "__pycache__/" in text
        assert ".synax/" in text

    def test_gitignore_present(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        text = (out / ".gitignore").read_text(encoding="utf-8")
        assert ".venv/" in text
        assert ".synax/" in text


class TestRenderErrors:
    def test_missing_variable_raises(self, tmp_path: Path) -> None:
        partial = dict(_DEFAULT_VARS)
        del partial["author_name"]
        with pytest.raises(TemplateError, match="missing required variable 'author_name'"):
            render_template_dir(output_dir=tmp_path / "proj", variables=partial)

    def test_non_empty_output_dir_refused(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        out.mkdir()
        (out / "existing.txt").write_text("hi", encoding="utf-8")
        with pytest.raises(TemplateError, match="already exists and is not empty"):
            render_template_dir(output_dir=out, variables=_DEFAULT_VARS)

    def test_empty_output_dir_is_fine(self, tmp_path: Path) -> None:
        out = tmp_path / "proj"
        out.mkdir()  # exists but empty
        render_template_dir(output_dir=out, variables=_DEFAULT_VARS)
        assert (out / "pyproject.toml").exists()

    def test_unknown_template_raises(self, tmp_path: Path) -> None:
        with pytest.raises(TemplateError, match="not bundled"):
            render_template_dir(
                output_dir=tmp_path / "proj",
                variables=_DEFAULT_VARS,
                template_name="nonexistent",
            )


class TestTemplateManifest:
    def test_manifest_entries_have_tmpl_extension(self) -> None:
        """All source paths in the manifest end with .tmpl."""
        for src, _ in TEMPLATE_MANIFEST:
            assert src.endswith(".tmpl"), f"missing .tmpl: {src}"

    def test_destinations_have_no_tmpl_extension(self) -> None:
        """Destinations strip the .tmpl extension."""
        for _, dst in TEMPLATE_MANIFEST:
            assert not dst.endswith(".tmpl"), f"unexpected .tmpl: {dst}"
