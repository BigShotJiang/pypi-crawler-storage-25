"""Tests for the ``secrets`` facade and the mock backend's secret handling."""

import pytest

from synax_sdk.errors import SkillRuntimeError
from synax_sdk.runtime.secrets import secrets
from synax_sdk.testing import MockPlatform


class TestSecretsFacade:
    async def test_raises_without_backend(self) -> None:
        with pytest.raises(SkillRuntimeError, match="No Synax runtime backend is active"):
            await secrets.get("ANY")

    async def test_returns_configured_value(self) -> None:
        mock = MockPlatform()
        mock.secrets.set("GREETING", "Hello")
        with mock.activate():
            value = await secrets.get("GREETING")
        assert value == "Hello"

    async def test_raises_on_unknown_secret_inside_activate(self) -> None:
        mock = MockPlatform()
        with mock.activate(), pytest.raises(SkillRuntimeError, match="not configured on the mock"):
            await secrets.get("UNKNOWN")

    async def test_records_access(self) -> None:
        mock = MockPlatform()
        mock.secrets.set("A", "1")
        mock.secrets.set("B", "2")
        with mock.activate():
            await secrets.get("A")
            await secrets.get("B")
            await secrets.get("A")
        assert mock.secrets.accesses == ["A", "B", "A"]

    async def test_failed_access_still_recorded(self) -> None:
        """A failed access still appears in .accesses — useful for diagnosing test setup."""
        mock = MockPlatform()
        with mock.activate(), pytest.raises(SkillRuntimeError):
            await secrets.get("MISSING")
        assert mock.secrets.accesses == ["MISSING"]


class TestMockPlatformActivation:
    async def test_activate_makes_backend_visible_to_facade(self) -> None:
        mock = MockPlatform()
        mock.secrets.set("X", "x")
        with mock.activate():
            assert await secrets.get("X") == "x"

    async def test_after_activate_block_facade_raises_again(self) -> None:
        mock = MockPlatform()
        mock.secrets.set("X", "x")
        with mock.activate():
            await secrets.get("X")
        with pytest.raises(SkillRuntimeError):
            await secrets.get("X")

    async def test_nested_activates_restore_outer(self) -> None:
        outer = MockPlatform()
        outer.secrets.set("WHO", "outer")
        inner = MockPlatform()
        inner.secrets.set("WHO", "inner")

        with outer.activate():
            assert await secrets.get("WHO") == "outer"
            with inner.activate():
                assert await secrets.get("WHO") == "inner"
            # back to outer
            assert await secrets.get("WHO") == "outer"

    def test_backend_escape_hatch(self) -> None:
        """MockPlatform.backend exposes the raw backend for advanced inspection."""
        mock = MockPlatform()
        assert mock.backend is mock._backend
