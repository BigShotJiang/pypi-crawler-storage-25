"""Tests for the ``ctx`` proxy and ``MockPlatform.context.set()``."""

import uuid

import pytest

from synax_sdk.errors import SkillRuntimeError
from synax_sdk.runtime.context import Context, Invoker, ctx
from synax_sdk.testing import MockPlatform


class TestCtxProxy:
    def test_raises_without_backend(self) -> None:
        with pytest.raises(SkillRuntimeError, match="No Synax runtime backend is active"):
            _ = ctx.run_id

    def test_raises_when_context_not_configured(self) -> None:
        mock = MockPlatform()
        with mock.activate(), pytest.raises(SkillRuntimeError, match="No invocation context"):
            _ = ctx.run_id

    def test_reads_run_id(self) -> None:
        mock = MockPlatform()
        target = uuid.UUID(int=42)
        mock.context.set(run_id=target)
        with mock.activate():
            assert ctx.run_id == target

    def test_reads_workspace_id(self) -> None:
        mock = MockPlatform()
        target = uuid.UUID(int=43)
        mock.context.set(workspace_id=target)
        with mock.activate():
            assert ctx.workspace_id == target

    def test_reads_channel_id(self) -> None:
        mock = MockPlatform()
        target = uuid.UUID(int=44)
        mock.context.set(channel_id=target)
        with mock.activate():
            assert ctx.channel_id == target

    def test_reads_invoker(self) -> None:
        mock = MockPlatform()
        invoker = Invoker(type="bot", id=uuid.UUID(int=1), name="my-bot")
        mock.context.set(invoker=invoker)
        with mock.activate():
            assert ctx.invoker == invoker
            assert ctx.invoker.type == "bot"
            assert ctx.invoker.name == "my-bot"

    def test_optional_bot_user_ids_default_none(self) -> None:
        mock = MockPlatform()
        mock.context.set()
        with mock.activate():
            assert ctx.bot_id is None
            assert ctx.user_id is None

    def test_optional_bot_user_ids_settable(self) -> None:
        mock = MockPlatform()
        bot = uuid.UUID(int=10)
        user = uuid.UUID(int=11)
        mock.context.set(bot_id=bot, user_id=user)
        with mock.activate():
            assert ctx.bot_id == bot
            assert ctx.user_id == user

    def test_repr(self) -> None:
        assert "ctx proxy" in repr(ctx)


class TestMockContextSet:
    def test_returns_constructed_context(self) -> None:
        mock = MockPlatform()
        result = mock.context.set(run_id=uuid.UUID(int=1))
        assert isinstance(result, Context)
        assert result.run_id == uuid.UUID(int=1)

    def test_accepts_string_uuids(self) -> None:
        mock = MockPlatform()
        result = mock.context.set(run_id="00000000-0000-0000-0000-000000000001")
        assert result.run_id == uuid.UUID(int=1)

    def test_invalid_string_uuid_rejected(self) -> None:
        mock = MockPlatform()
        with pytest.raises(ValueError):
            mock.context.set(run_id="not-a-uuid")

    def test_defaults_are_random_uuids(self) -> None:
        mock = MockPlatform()
        result = mock.context.set()
        assert isinstance(result.run_id, uuid.UUID)
        assert isinstance(result.workspace_id, uuid.UUID)
        assert isinstance(result.channel_id, uuid.UUID)

    def test_default_invoker_is_test_user(self) -> None:
        mock = MockPlatform()
        result = mock.context.set()
        assert result.invoker.type == "user"
        assert result.invoker.name == "test-invoker"

    def test_invoker_constructed_from_components(self) -> None:
        mock = MockPlatform()
        result = mock.context.set(
            invoker_type="bot",
            invoker_id=uuid.UUID(int=5),
            invoker_name="my-bot",
        )
        assert result.invoker.type == "bot"
        assert result.invoker.id == uuid.UUID(int=5)
        assert result.invoker.name == "my-bot"

    def test_explicit_invoker_wins_over_components(self) -> None:
        mock = MockPlatform()
        explicit = Invoker(type="user", id=uuid.UUID(int=99), name="explicit")
        result = mock.context.set(invoker=explicit, invoker_name="ignored")
        assert result.invoker is explicit

    def test_overwrite(self) -> None:
        """Calling set() twice replaces the context."""
        mock = MockPlatform()
        first = mock.context.set(run_id=uuid.UUID(int=1))
        second = mock.context.set(run_id=uuid.UUID(int=2))
        with mock.activate():
            assert ctx.run_id == second.run_id
            assert ctx.run_id != first.run_id
