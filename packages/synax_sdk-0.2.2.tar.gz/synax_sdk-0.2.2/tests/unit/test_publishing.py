"""Tests for ``synax_sdk.publishing`` — PublishClient and ``publish()``."""

from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

import httpx
import pytest
import respx

from synax_sdk.errors import (
    PublishAuthError,
    PublishError,
    PublishNetworkError,
    PublishValidationError,
    PublishVersionConflict,
)
from synax_sdk.publishing import (
    KEY_REGISTER_PATH,
    PUBLISH_PATH,
    PublishClient,
    PublishProgress,
    PublishResult,
    publish,
)

TARGET = "https://synax.example.com"
TOKEN = "spt_test_token"
PUBLISH_URL = TARGET + PUBLISH_PATH
KEYS_URL = TARGET + KEY_REGISTER_PATH


# ---------------------------------------------------------------------------
# Bundle fixture: a minimal manifest.yaml + implementation.tar.gz on disk.
# ---------------------------------------------------------------------------
@pytest.fixture
def bundle(tmp_path: Path) -> Path:
    bundle_dir = tmp_path / "signed_bundle"
    bundle_dir.mkdir()
    (bundle_dir / "manifest.yaml").write_text("name: demo\nversion: 1.0.0\n", encoding="utf-8")
    (bundle_dir / "implementation.tar.gz").write_bytes(b"fake-tar-bytes")
    return bundle_dir


def _expected_hash(bundle_dir: Path) -> str:
    return (
        "sha256:" + hashlib.sha256((bundle_dir / "implementation.tar.gz").read_bytes()).hexdigest()
    )


def _success_body(**overrides: object) -> dict[str, object]:
    body: dict[str, object] = {
        "skill_id": "11111111-2222-3333-4444-555555555555",
        "skill_version_id": "66666666-7777-8888-9999-000000000000",
        "status": "registered",
        "marketplace_url": "https://synax.example.com/marketplace/skills/demo",
    }
    body.update(overrides)
    return body


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------
class TestConstruction:
    def test_empty_target_rejected(self) -> None:
        with pytest.raises(PublishError, match="Empty target URL"):
            PublishClient(target_url="", auth_token=TOKEN)

    def test_empty_token_rejected(self) -> None:
        with pytest.raises(PublishAuthError, match="Empty auth token"):
            PublishClient(target_url=TARGET, auth_token="")

    def test_trailing_slash_normalised(self) -> None:
        client = PublishClient(target_url=TARGET + "/", auth_token=TOKEN)
        assert client.target_url == TARGET
        client.close()

    def test_context_manager_closes(self) -> None:
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as c:
            assert c.target_url == TARGET


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------
class TestPublishHappy:
    @respx.mock
    def test_returns_publish_result(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            result = client.publish(bundle)
        assert isinstance(result, PublishResult)
        assert result.status == "registered"
        assert result.skill_id == "11111111-2222-3333-4444-555555555555"
        assert result.marketplace_url == "https://synax.example.com/marketplace/skills/demo"

    @respx.mock
    def test_sends_bearer_token(self, bundle: Path) -> None:
        route = respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            client.publish(bundle)
        request = route.calls.last.request
        assert request.headers["Authorization"] == f"Bearer {TOKEN}"

    @respx.mock
    def test_sends_correct_body(self, bundle: Path) -> None:
        route = respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            client.publish(bundle)
        body = json.loads(route.calls.last.request.content)
        assert body["manifest_yaml"] == "name: demo\nversion: 1.0.0\n"
        assert body["implementation_hash"] == _expected_hash(bundle)
        assert base64.b64decode(body["implementation_artifact_b64"]) == b"fake-tar-bytes"

    @respx.mock
    def test_progress_callback_invoked(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        progress: list[PublishProgress] = []
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            client.publish(bundle, on_progress=progress.append)
        stages = [p.stage for p in progress]
        assert stages == ["uploading", "complete"]

    @respx.mock
    def test_marketplace_url_optional(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(
                200, json={"skill_id": "a", "skill_version_id": "b", "status": "registered"}
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            result = client.publish(bundle)
        assert result.marketplace_url is None


# ---------------------------------------------------------------------------
# Error responses
# ---------------------------------------------------------------------------
class TestPublishErrors:
    @respx.mock
    def test_401_raises_auth_error(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(401, json={"message": "bad token"})
        )
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishAuthError, match="Authentication failed"),
        ):
            client.publish(bundle)

    @respx.mock
    def test_403_also_raises_auth_error(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(403, json={"message": "forbidden"})
        )
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishAuthError),
        ):
            client.publish(bundle)

    @respx.mock
    def test_400_raises_validation_error(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(
                400,
                json={
                    "error_code": "manifest_invalid",
                    "message": "Manifest validation failed",
                    "details": {"field": "tools[0].parameters", "issue": "missing 'type'"},
                },
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            with pytest.raises(PublishValidationError) as exc_info:
                client.publish(bundle)
        assert exc_info.value.details == {
            "field": "tools[0].parameters",
            "issue": "missing 'type'",
        }

    @respx.mock
    def test_409_raises_version_conflict(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(
                409,
                json={
                    "error_code": "version_already_published",
                    "message": "Version 1.2.3 already exists",
                    "details": {"existing_version_id": "abc-123"},
                },
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            with pytest.raises(PublishVersionConflict) as exc_info:
                client.publish(bundle)
        assert exc_info.value.existing_version_id == "abc-123"

    @respx.mock
    def test_unexpected_status_raises_publish_error(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(418, json={"message": "teapot"}))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishError, match="Unexpected HTTP 418"),
        ):
            client.publish(bundle)

    @respx.mock
    def test_200_with_non_json_body(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, text="not json"))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishError, match="non-JSON body"),
        ):
            client.publish(bundle)

    @respx.mock
    def test_200_missing_required_field(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json={"skill_id": "x"}))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishError, match="missing required field"),
        ):
            client.publish(bundle)


# ---------------------------------------------------------------------------
# Retries
# ---------------------------------------------------------------------------
class TestRetries:
    @respx.mock
    def test_5xx_retries_then_succeeds(self, bundle: Path) -> None:
        route = respx.post(PUBLISH_URL).mock(
            side_effect=[
                httpx.Response(500, json={"message": "boom"}),
                httpx.Response(503, json={"message": "still boom"}),
                httpx.Response(200, json=_success_body()),
            ]
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=lambda _: None) as client:
            result = client.publish(bundle)
        assert result.status == "registered"
        assert route.call_count == 3

    @respx.mock
    def test_5xx_exhausts_retries_then_raises(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(502, text="bad gateway"))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=lambda _: None) as client,
            pytest.raises(PublishNetworkError, match="Server returned 502"),
        ):
            client.publish(bundle)

    @respx.mock
    def test_4xx_not_retried(self, bundle: Path) -> None:
        route = respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(400, json={"message": "bad"})
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=lambda _: None) as client:
            with pytest.raises(PublishValidationError):
                client.publish(bundle)
        assert route.call_count == 1

    @respx.mock
    def test_connect_error_retries(self, bundle: Path) -> None:
        # First two attempts raise ConnectError, third succeeds.
        route = respx.post(PUBLISH_URL).mock(
            side_effect=[
                httpx.ConnectError("net down"),
                httpx.ConnectError("net still down"),
                httpx.Response(200, json=_success_body()),
            ]
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=lambda _: None) as client:
            result = client.publish(bundle)
        assert result.status == "registered"
        assert route.call_count == 3

    @respx.mock
    def test_persistent_network_failure_raises(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(side_effect=httpx.ConnectError("nope"))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=lambda _: None) as client,
            pytest.raises(PublishNetworkError, match="Network error"),
        ):
            client.publish(bundle)

    @respx.mock
    def test_retry_backoff_increases(self, bundle: Path) -> None:
        sleeps: list[float] = []
        respx.post(PUBLISH_URL).mock(
            side_effect=[
                httpx.Response(500),
                httpx.Response(500),
                httpx.Response(200, json=_success_body()),
            ]
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=sleeps.append) as client:
            client.publish(bundle)
        # Two retries triggered two sleeps with exponential backoff (1s, 2s).
        assert sleeps == [1.0, 2.0]


# ---------------------------------------------------------------------------
# Missing files
# ---------------------------------------------------------------------------
class TestPublishBundleMissing:
    def test_missing_manifest(self, tmp_path: Path) -> None:
        bundle_dir = tmp_path / "signed_bundle"
        bundle_dir.mkdir()
        (bundle_dir / "implementation.tar.gz").write_bytes(b"x")
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishError, match="Manifest not found"),
        ):
            client.publish(bundle_dir)

    def test_missing_artifact(self, tmp_path: Path) -> None:
        bundle_dir = tmp_path / "signed_bundle"
        bundle_dir.mkdir()
        (bundle_dir / "manifest.yaml").write_text("name: x", encoding="utf-8")
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishError, match="Artifact not found"),
        ):
            client.publish(bundle_dir)


# ---------------------------------------------------------------------------
# Top-level publish() convenience
# ---------------------------------------------------------------------------
class TestTopLevelPublish:
    @respx.mock
    def test_one_shot(self, bundle: Path) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        result = publish(TARGET, TOKEN, bundle)
        assert result.status == "registered"


# ---------------------------------------------------------------------------
# register_key
# ---------------------------------------------------------------------------
class TestRegisterKey:
    @respx.mock
    def test_happy_path(self) -> None:
        respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200,
                json={"registration_id": "reg-123", "status": "pending_approval"},
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            result = client.register_key(
                public_key_b64="AAAA", fingerprint="sha256:abc", namespace="acme"
            )
        assert result.registration_id == "reg-123"
        assert result.status == "pending_approval"

    @respx.mock
    def test_sends_expected_body(self) -> None:
        route = respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "r", "status": "pending_approval"}
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            client.register_key(public_key_b64="PUBKEY", fingerprint="sha256:xyz", namespace="acme")
        body = json.loads(route.calls.last.request.content)
        assert body == {
            "public_key_b64": "PUBKEY",
            "fingerprint": "sha256:xyz",
            "namespace": "acme",
        }

    @respx.mock
    def test_sends_label_when_provided(self) -> None:
        route = respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "r", "status": "pending_approval"}
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            client.register_key(
                public_key_b64="PUBKEY",
                fingerprint="sha256:xyz",
                namespace="acme",
                label="synax-skills CI key",
            )
        body = json.loads(route.calls.last.request.content)
        assert body == {
            "public_key_b64": "PUBKEY",
            "fingerprint": "sha256:xyz",
            "namespace": "acme",
            "label": "synax-skills CI key",
        }

    @respx.mock
    def test_omits_label_when_none(self) -> None:
        route = respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "r", "status": "pending_approval"}
            )
        )
        with PublishClient(target_url=TARGET, auth_token=TOKEN) as client:
            client.register_key(
                public_key_b64="PUBKEY",
                fingerprint="sha256:xyz",
                namespace="acme",
                label=None,
            )
        body = json.loads(route.calls.last.request.content)
        assert "label" not in body

    @respx.mock
    def test_auth_failure_raises(self) -> None:
        respx.post(KEYS_URL).mock(return_value=httpx.Response(401, json={"message": "nope"}))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishAuthError),
        ):
            client.register_key(public_key_b64="x", fingerprint="sha256:x", namespace="a")

    @respx.mock
    def test_409_raises_publish_error(self) -> None:
        respx.post(KEYS_URL).mock(return_value=httpx.Response(409, json={"message": "exists"}))
        with (
            PublishClient(target_url=TARGET, auth_token=TOKEN) as client,
            pytest.raises(PublishError, match="already registered"),
        ):
            client.register_key(public_key_b64="x", fingerprint="sha256:x", namespace="a")

    @respx.mock
    def test_unexpected_status(self) -> None:
        respx.post(KEYS_URL).mock(return_value=httpx.Response(500, text="boom"))
        with PublishClient(target_url=TARGET, auth_token=TOKEN, sleep=lambda _: None) as client:
            with pytest.raises(PublishNetworkError):
                client.register_key(public_key_b64="x", fingerprint="sha256:x", namespace="a")
