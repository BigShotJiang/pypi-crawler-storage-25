"""Smoke tests proving the package imports and the CLI is wired correctly."""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

import synax_sdk
from synax_skill_cli.main import app

runner = CliRunner()


def test_version_string_is_pinned() -> None:
    assert synax_sdk.__version__ == "0.2.2"


def test_cli_help_runs() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Synax SDK" in result.stdout
    assert "skill" in result.stdout
    assert "keys" in result.stdout
    assert "config" in result.stdout


def test_cli_version_flag() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "0.2.2" in result.stdout


def test_cli_no_args_shows_help() -> None:
    result = runner.invoke(app, [])
    assert result.exit_code == 0
    assert "skill" in result.stdout


# Commands that are still placeholders (their milestone hasn't shipped yet)
# should run, print a "not yet implemented" message, and exit 0. Commands
# that have shipped real implementations are covered in tests/unit/test_cli_*.py.
STUB_COMMANDS: list[list[str]] = [
    ["config", "get", "default_key"],  # config commands deferred indefinitely
    ["config", "set", "default_key", "abc123"],
]


@pytest.mark.parametrize("cmd", STUB_COMMANDS, ids=lambda c: " ".join(c))
def test_stub_commands_report_not_implemented(cmd: list[str]) -> None:
    result = runner.invoke(app, cmd)
    assert result.exit_code == 0, result.stdout
    assert "Not yet implemented" in result.stdout
