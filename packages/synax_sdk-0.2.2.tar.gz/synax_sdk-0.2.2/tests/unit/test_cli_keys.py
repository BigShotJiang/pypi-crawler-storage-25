"""CLI tests for the ``synax keys`` subcommands."""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from synax_sdk.signing import KeyStore, generate_keypair, save_public_key_to_file
from synax_skill_cli.commands import keys as keys_module
from synax_skill_cli.main import app

runner = CliRunner()


def _flat(text: str) -> str:
    """Collapse whitespace so rich's wrap behaviour doesn't break substring matches."""
    return " ".join(text.split())


@pytest.fixture
def store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> KeyStore:
    """A tmp-rooted KeyStore that replaces the default in all CLI commands."""
    s = KeyStore(root=tmp_path / "keys")
    monkeypatch.setattr(keys_module, "_store", lambda output_dir=None: s)
    return s


class TestKeysGenerate:
    def test_creates_keypair_and_sets_default(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "generate"])
        assert result.exit_code == 0, result.stdout
        # rich may wrap the fingerprint line, so check the components separately.
        assert "Generated keypair" in _flat(result.stdout)
        assert "sha256:" in result.stdout
        assert "set as default" in _flat(result.stdout)
        assert store.default_fingerprint is not None
        assert len(store.list_fingerprints()) == 1

    def test_second_generate_does_not_clobber_default(self, store: KeyStore) -> None:
        runner.invoke(app, ["keys", "generate"])
        first_default = store.default_fingerprint
        result = runner.invoke(app, ["keys", "generate"])
        assert result.exit_code == 0
        # The default is the first key, not the new one.
        assert store.default_fingerprint == first_default
        assert "set as default" not in _flat(result.stdout)
        assert len(store.list_fingerprints()) == 2


class TestKeysList:
    def test_empty_store_friendly_message(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "list"])
        assert result.exit_code == 0
        assert "No keys found" in _flat(result.stdout)

    def test_lists_with_default_marker(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)
        result = runner.invoke(app, ["keys", "list"])
        assert result.exit_code == 0
        assert kp.fingerprint[:12] in result.stdout  # rich may truncate; fingerprint prefix present


class TestKeysExport:
    def test_export_to_stdout(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)
        result = runner.invoke(app, ["keys", "export", kp.fingerprint])
        assert result.exit_code == 0
        assert "public_key_b64" in result.stdout
        assert kp.fingerprint in result.stdout

    def test_export_to_file(self, store: KeyStore, tmp_path: Path) -> None:
        kp = generate_keypair()
        store.save(kp)
        target = tmp_path / "out.pub"
        result = runner.invoke(app, ["keys", "export", kp.fingerprint, "--output", str(target)])
        assert result.exit_code == 0
        assert target.exists()
        assert "written to" in _flat(result.stdout)

    def test_export_unknown_fingerprint_fails(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "export", "sha256:" + "0" * 64])
        assert result.exit_code == 1
        assert "No key matching" in _flat(result.stdout)


class TestKeysImport:
    def test_imports_public_key(self, store: KeyStore, tmp_path: Path) -> None:
        kp = generate_keypair()
        pub_file = tmp_path / "external.pub"
        save_public_key_to_file(kp, pub_file)
        result = runner.invoke(app, ["keys", "import", str(pub_file)])
        assert result.exit_code == 0
        assert kp.fingerprint in result.stdout
        # Imported but doesn't become default (store was empty before).
        assert store.default_fingerprint is None
        # Loading it back yields a public-only KeyPair.
        loaded = store.load(kp.fingerprint)
        assert loaded.private_key is None

    def test_import_bad_file_fails(self, store: KeyStore, tmp_path: Path) -> None:
        bad = tmp_path / "garbage.pub"
        bad.write_text("{not json}", encoding="utf-8")
        result = runner.invoke(app, ["keys", "import", str(bad)])
        assert result.exit_code == 1


class TestKeysSetDefault:
    def test_sets_default(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        # Default is kp1 (first saved). Switch to kp2.
        result = runner.invoke(app, ["keys", "set-default", kp2.fingerprint])
        assert result.exit_code == 0
        assert store.default_fingerprint == kp2.fingerprint

    def test_sets_default_by_prefix(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        result = runner.invoke(app, ["keys", "set-default", hex_part[:8]])
        assert result.exit_code == 0
        assert store.default_fingerprint == kp.fingerprint

    def test_unknown_fingerprint_fails(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "set-default", "sha256:" + "0" * 64])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# v0.2.2 additions
# ---------------------------------------------------------------------------
class TestKeysGenerateFlags:
    def test_name_flag_stores_name(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "generate", "--name", "ci-bot"])
        assert result.exit_code == 0, result.stdout
        fps = store.list_fingerprints()
        assert len(fps) == 1
        kp = store.load(fps[0])
        assert kp.name == "ci-bot"
        assert "ci-bot" in _flat(result.stdout)

    def test_output_dir_writes_into_alt_directory(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Drop the store fixture's monkeypatching; --output-dir should build
        # its own KeyStore. But the fixture has already monkey-patched _store
        # to return the same tmp_path store for every call. To exercise the
        # output_dir branch independently, we invoke without the fixture by
        # using a fresh runner under a fresh tmp_path and not requesting the
        # store fixture.
        from synax_skill_cli.commands import keys as keys_module

        alt_root = tmp_path / "alt"
        # Replace _store so we honor --output-dir as the real code does.
        monkeypatch.setattr(
            keys_module,
            "_store",
            lambda output_dir=None: KeyStore(root=output_dir) if output_dir else KeyStore.default(),
        )
        result = runner.invoke(app, ["keys", "generate", "--output-dir", str(alt_root)])
        assert result.exit_code == 0, result.stdout
        assert (alt_root).exists()
        # At least one .key file present in alt_root.
        keys_in_alt = [p for p in alt_root.iterdir() if p.suffix == ".key"]
        assert len(keys_in_alt) == 1

    def test_set_default_overrides_existing_default(self, store: KeyStore) -> None:
        # Generate one (becomes default), then generate again with --set-default.
        runner.invoke(app, ["keys", "generate"])
        first_default = store.default_fingerprint
        result = runner.invoke(app, ["keys", "generate", "--set-default"])
        assert result.exit_code == 0
        # The new key should be the default now.
        assert store.default_fingerprint != first_default
        assert store.default_fingerprint in store.list_fingerprints()


class TestKeysListJson:
    def test_json_output_is_an_array(self, store: KeyStore) -> None:
        kp = generate_keypair(name="ci")
        store.save(kp)
        result = runner.invoke(app, ["keys", "list", "--json"])
        assert result.exit_code == 0
        import json

        records = json.loads(result.stdout)
        assert isinstance(records, list)
        assert len(records) == 1
        assert records[0]["fingerprint"] == kp.fingerprint
        assert records[0]["name"] == "ci"
        assert records[0]["default"] is True

    def test_json_output_empty_array_when_no_keys(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "list", "--json"])
        assert result.exit_code == 0
        import json

        assert json.loads(result.stdout) == []

    def test_default_table_has_name_column(self, store: KeyStore) -> None:
        kp = generate_keypair(name="ci-bot")
        store.save(kp)
        result = runner.invoke(app, ["keys", "list"])
        assert result.exit_code == 0
        assert "ci-bot" in _flat(result.stdout)
        assert "Name" in _flat(result.stdout)


class TestKeysShow:
    def test_show_default_lines(self, store: KeyStore) -> None:
        kp = generate_keypair(name="ci-bot")
        store.save(kp)
        result = runner.invoke(app, ["keys", "show", kp.fingerprint])
        assert result.exit_code == 0
        flat = _flat(result.stdout)
        assert kp.fingerprint in flat
        assert "ci-bot" in flat
        assert "Ed25519" in flat

    def test_show_by_prefix(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        result = runner.invoke(app, ["keys", "show", hex_part[:8]])
        assert result.exit_code == 0
        assert kp.fingerprint in _flat(result.stdout)

    def test_show_json(self, store: KeyStore) -> None:
        kp = generate_keypair(name="ci-bot")
        store.save(kp)
        result = runner.invoke(app, ["keys", "show", kp.fingerprint, "--json"])
        assert result.exit_code == 0
        import json

        record = json.loads(result.stdout)
        assert record["fingerprint"] == kp.fingerprint
        assert record["name"] == "ci-bot"
        assert record["default"] is True

    def test_show_unknown_fails(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "show", "sha256:" + "0" * 64])
        assert result.exit_code == 1
        assert "No key matching" in _flat(result.stdout)


class TestKeysExportTty:
    def test_export_non_tty_emits_json_pubfile(self, store: KeyStore) -> None:
        # CliRunner captures stdout as non-tty by default, so this is the
        # pipe / redirect case.
        kp = generate_keypair(name="ci-bot")
        store.save(kp)
        result = runner.invoke(app, ["keys", "export", kp.fingerprint])
        assert result.exit_code == 0
        import json

        payload = json.loads(result.stdout)
        assert payload["fingerprint"] == kp.fingerprint
        assert payload["name"] == "ci-bot"
        assert payload["algorithm"] == "Ed25519"
        assert "public_key_b64" in payload

    def test_export_tty_emits_human_kv(
        self, store: KeyStore, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        kp = generate_keypair()
        store.save(kp)
        monkeypatch.setattr(keys_module, "_stdout_is_tty", lambda: True)
        result = runner.invoke(app, ["keys", "export", kp.fingerprint])
        assert result.exit_code == 0
        assert "fingerprint:" in result.stdout
        assert "public_key_b64:" in result.stdout

    def test_export_by_prefix(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)
        hex_part = kp.fingerprint.removeprefix("sha256:")
        result = runner.invoke(app, ["keys", "export", hex_part[:8]])
        assert result.exit_code == 0
        import json

        payload = json.loads(result.stdout)
        assert payload["fingerprint"] == kp.fingerprint


class TestKeysDelete:
    def test_delete_with_force(self, store: KeyStore) -> None:
        # Two keys so the one we delete isn't the default.
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["keys", "delete", kp2.fingerprint, "--force"])
        assert result.exit_code == 0
        assert kp2.fingerprint not in store.list_fingerprints()
        assert kp1.fingerprint in store.list_fingerprints()

    def test_delete_with_confirm_y(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["keys", "delete", kp2.fingerprint], input="y\n")
        assert result.exit_code == 0
        assert kp2.fingerprint not in store.list_fingerprints()

    def test_delete_aborts_on_n(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["keys", "delete", kp2.fingerprint], input="n\n")
        assert result.exit_code == 0
        assert kp2.fingerprint in store.list_fingerprints()
        assert "Aborted" in _flat(result.stdout)

    def test_delete_refuses_default_without_force(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)  # becomes default
        result = runner.invoke(app, ["keys", "delete", kp.fingerprint])
        assert result.exit_code == 1
        assert kp.fingerprint in store.list_fingerprints()
        assert "default signing key" in _flat(result.stdout)

    def test_delete_default_with_force(self, store: KeyStore) -> None:
        kp = generate_keypair()
        store.save(kp)  # becomes default
        result = runner.invoke(app, ["keys", "delete", kp.fingerprint, "--force"])
        assert result.exit_code == 0
        assert kp.fingerprint not in store.list_fingerprints()
        assert store.default_fingerprint is None

    def test_delete_by_prefix(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        hex2 = kp2.fingerprint.removeprefix("sha256:")
        result = runner.invoke(app, ["keys", "delete", hex2[:8], "--force"])
        assert result.exit_code == 0
        assert kp2.fingerprint not in store.list_fingerprints()

    def test_delete_unknown_fails(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["keys", "delete", "sha256:" + "0" * 64, "--force"])
        assert result.exit_code == 1

    def test_delete_under_quiet_requires_force(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["--quiet", "keys", "delete", kp2.fingerprint])
        assert result.exit_code == 1
        assert kp2.fingerprint in store.list_fingerprints()


class TestQuietFlag:
    def test_generate_quiet_prints_only_fingerprint(self, store: KeyStore) -> None:
        result = runner.invoke(app, ["--quiet", "keys", "generate"])
        assert result.exit_code == 0
        stripped = result.stdout.strip()
        assert stripped.startswith("sha256:")
        assert len(stripped.splitlines()) == 1

    def test_list_quiet_prints_one_per_line(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["--quiet", "keys", "list"])
        assert result.exit_code == 0
        lines = [ln for ln in result.stdout.splitlines() if ln.strip()]
        assert set(lines) == {kp1.fingerprint, kp2.fingerprint}

    def test_set_default_quiet_prints_fingerprint(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["--quiet", "keys", "set-default", kp2.fingerprint])
        assert result.exit_code == 0
        assert result.stdout.strip() == kp2.fingerprint

    def test_delete_quiet_with_force_prints_fingerprint(self, store: KeyStore) -> None:
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        store.save(kp1)
        store.save(kp2)
        result = runner.invoke(app, ["--quiet", "keys", "delete", kp2.fingerprint, "--force"])
        assert result.exit_code == 0
        assert result.stdout.strip() == kp2.fingerprint
