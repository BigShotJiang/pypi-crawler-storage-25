"""CLI tests for ``synax skill test``."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from synax_skill_cli.main import app

runner = CliRunner()


def _flat(text: str) -> str:
    return " ".join(text.split())


PYPROJECT = """\
[project]
name = "demo"
version = "0.0.0"

[tool.synax]
entry_point = "demo_skill:skill"
"""

SKILL_SRC = """\
from synax_sdk import Skill, secrets, logger

skill = Skill(
    name="demo",
    version="0.1.0",
    description="demo skill",
    capabilities=["secrets:GREETING"],
    secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
)

@skill.tool(description="Greet")
async def greet(name: str) -> str:
    \"\"\"Greet.

    Args:
        name: who.
    \"\"\"
    g = await secrets.get("GREETING")
    logger.info(f"greeted {name}")
    return f"{g}, {name}"
"""


@pytest.fixture
def project_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "demo_skill.py").write_text(SKILL_SRC, encoding="utf-8")
    monkeypatch.chdir(root)
    return root


def _write_case(path: Path, content: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(content), encoding="utf-8")


# ---------------------------------------------------------------------------
# Happy paths
# ---------------------------------------------------------------------------
class TestSkillTestHappy:
    def test_no_test_inputs_directory(self, project_dir: Path) -> None:
        """Skip silently and exit 0 — no tests means nothing to fail."""
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 0
        assert "No test inputs directory" in _flat(result.stdout)

    def test_runs_passing_case(self, project_dir: Path) -> None:
        _write_case(
            project_dir / "test_inputs" / "greet" / "case_basic.yaml",
            {
                "input": {"name": "World"},
                "secrets": {"GREETING": "Hello"},
                "expected_output": "Hello, World",
            },
        )
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 0, result.stdout
        flat = _flat(result.stdout)
        assert "PASS" in flat
        assert "All 1 test" in flat

    def test_runs_multiple_cases(self, project_dir: Path) -> None:
        _write_case(
            project_dir / "test_inputs" / "greet" / "a.yaml",
            {
                "input": {"name": "A"},
                "secrets": {"GREETING": "Hi"},
                "expected_output": "Hi, A",
            },
        )
        _write_case(
            project_dir / "test_inputs" / "greet" / "b.yaml",
            {
                "input": {"name": "B"},
                "secrets": {"GREETING": "Hi"},
                "expected_output": "Hi, B",
            },
        )
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 0, result.stdout
        assert _flat(result.stdout).count("PASS") == 2

    def test_filter_by_tool(self, project_dir: Path) -> None:
        _write_case(
            project_dir / "test_inputs" / "greet" / "case.yaml",
            {
                "input": {"name": "X"},
                "secrets": {"GREETING": "Y"},
                "expected_output": "Y, X",
            },
        )
        # Filter to a non-existent tool name — should still exit 0 with no results.
        result = runner.invoke(app, ["skill", "test", "--tool", "no-such-tool"])
        assert result.exit_code == 0
        assert "No matching test cases found" in _flat(result.stdout)

    def test_filter_by_case_substring(self, project_dir: Path) -> None:
        _write_case(
            project_dir / "test_inputs" / "greet" / "case_alpha.yaml",
            {
                "input": {"name": "A"},
                "secrets": {"GREETING": "X"},
                "expected_output": "X, A",
            },
        )
        _write_case(
            project_dir / "test_inputs" / "greet" / "case_beta.yaml",
            {
                "input": {"name": "B"},
                "secrets": {"GREETING": "X"},
                "expected_output": "X, B",
            },
        )
        result = runner.invoke(app, ["skill", "test", "--filter", "alpha"])
        assert result.exit_code == 0
        # Only one case ran
        assert _flat(result.stdout).count("PASS") == 1
        assert "case_alpha" in _flat(result.stdout)

    def test_custom_inputs_directory(self, project_dir: Path, tmp_path: Path) -> None:
        inputs = tmp_path / "custom"
        _write_case(
            inputs / "greet" / "case.yaml",
            {
                "input": {"name": "X"},
                "secrets": {"GREETING": "Y"},
                "expected_output": "Y, X",
            },
        )
        result = runner.invoke(app, ["skill", "test", "--inputs", str(inputs)])
        assert result.exit_code == 0
        assert "PASS" in _flat(result.stdout)


# ---------------------------------------------------------------------------
# Failure modes
# ---------------------------------------------------------------------------
class TestSkillTestFailures:
    def test_failing_case_exits_1(self, project_dir: Path) -> None:
        _write_case(
            project_dir / "test_inputs" / "greet" / "case.yaml",
            {
                "input": {"name": "World"},
                "secrets": {"GREETING": "Hello"},
                "expected_output": "WRONG",
            },
        )
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 1
        flat = _flat(result.stdout)
        assert "FAIL" in flat
        assert "1 test case(s) failed" in flat

    def test_malformed_yaml_exits_1(self, project_dir: Path) -> None:
        (project_dir / "test_inputs" / "greet").mkdir(parents=True)
        (project_dir / "test_inputs" / "greet" / "case.yaml").write_text(
            "not: valid: :::",
            encoding="utf-8",
        )
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 1
        assert "invalid YAML" in _flat(result.stdout)

    def test_no_project_exits_1(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 1
        assert "No skill project found" in _flat(result.stdout)

    def test_failure_diagnostics_printed(self, project_dir: Path) -> None:
        _write_case(
            project_dir / "test_inputs" / "greet" / "case.yaml",
            {
                "input": {"name": "World"},
                "secrets": {"GREETING": "Hi"},
                "expected_output": "WRONG",
            },
        )
        result = runner.invoke(app, ["skill", "test"])
        assert result.exit_code == 1
        # The actual mismatch message should appear after the FAIL line.
        assert "expected_output" in _flat(result.stdout)
