"""Tests for the ``logger`` facade and ``MockPlatform.logger``."""

import pytest

from synax_sdk.errors import SkillRuntimeError
from synax_sdk.runtime.logger import logger
from synax_sdk.testing import MockPlatform


class TestLoggerNoBackend:
    def test_raises_without_backend(self) -> None:
        with pytest.raises(SkillRuntimeError, match="No Synax runtime backend is active"):
            logger.info("hello")


class TestLoggerLevels:
    def test_debug(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.debug("d")
        assert mock.logger.calls[0].level == "debug"
        assert mock.logger.calls[0].message == "d"

    def test_info(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("i")
        assert mock.logger.calls[0].level == "info"

    def test_warning(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.warning("w")
        assert mock.logger.calls[0].level == "warning"

    def test_error(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.error("e")
        assert mock.logger.calls[0].level == "error"

    def test_message_preserved(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("a specific message")
        assert mock.logger.calls[0].message == "a specific message"


class TestLoggerExtra:
    def test_no_extra_yields_empty_dict(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("hello")
        assert mock.logger.calls[0].extra == {}

    def test_extra_passed_through(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("fetched PR", extra={"pr_number": 42, "files_changed": 7})
        assert mock.logger.calls[0].extra == {"pr_number": 42, "files_changed": 7}

    def test_extra_is_defensively_copied(self) -> None:
        """The mock should snapshot extra; later mutation by caller mustn't change captures."""
        mock = MockPlatform()
        payload = {"x": 1}
        with mock.activate():
            logger.info("hello", extra=payload)
        payload["x"] = 999
        assert mock.logger.calls[0].extra == {"x": 1}


class TestLoggerException:
    def test_exception_outside_except_block(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.exception("something")
        call = mock.logger.calls[0]
        assert call.level == "error"
        assert "traceback" in call.extra

    def test_exception_inside_except_captures_traceback(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            try:
                raise ValueError("boom")
            except ValueError:
                logger.exception("caught")
        tb = mock.logger.calls[0].extra["traceback"]
        assert "ValueError: boom" in tb
        assert "Traceback" in tb

    def test_exception_merges_with_extra(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            try:
                raise RuntimeError("x")
            except RuntimeError:
                logger.exception("ctx", extra={"caller": "test"})
        extra = mock.logger.calls[0].extra
        assert extra["caller"] == "test"
        assert "traceback" in extra


class TestMockLoggerInspection:
    def test_calls_property_returns_in_order(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("one")
            logger.warning("two")
            logger.error("three")
        assert [c.message for c in mock.logger.calls] == ["one", "two", "three"]

    def test_at_level_filters(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("i1")
            logger.warning("w")
            logger.info("i2")
        infos = mock.logger.at_level("info")
        assert [c.message for c in infos] == ["i1", "i2"]

    def test_at_level_returns_empty_for_unused_level(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("x")
        assert mock.logger.at_level("debug") == []

    def test_calls_is_defensive_copy(self) -> None:
        mock = MockPlatform()
        with mock.activate():
            logger.info("x")
        snapshot = mock.logger.calls
        snapshot.clear()
        assert len(mock.logger.calls) == 1
