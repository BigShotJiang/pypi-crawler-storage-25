"""Tests for ``synax_sdk.testing.runners``."""

from __future__ import annotations

import pytest

from synax_sdk.errors import SkillRuntimeError
from synax_sdk.runtime.secrets import secrets
from synax_sdk.skill import Skill
from synax_sdk.testing import MockPlatform, run_tool, run_tool_async


def _make_sync_skill() -> Skill:
    s = Skill(name="x", version="1.0.0", description="x")

    @s.tool(description="Echo")
    def echo(text: str) -> str:
        """Echo.

        Args:
            text: in.
        """
        return text

    return s


def _make_async_skill() -> Skill:
    s = Skill(
        name="x",
        version="1.0.0",
        description="x",
        capabilities=["secrets:KEY"],
        secrets=[{"name": "KEY", "type": "api_key", "description": "."}],
    )

    @s.tool(description="Lookup")
    async def lookup(name: str) -> str:
        """Lookup.

        Args:
            name: who.
        """
        v = await secrets.get("KEY")
        return f"{v}:{name}"

    return s


# ---------------------------------------------------------------------------
# run_tool (sync entry point)
# ---------------------------------------------------------------------------
class TestRunTool:
    def test_invokes_sync_tool(self) -> None:
        skill = _make_sync_skill()
        result = run_tool(skill.tools[0], text="hello")
        assert result == "hello"

    def test_invokes_async_tool_via_asyncio_run(self) -> None:
        skill = _make_async_skill()
        mock = MockPlatform()
        mock.secrets.set("KEY", "TOK")
        with mock.activate():
            result = run_tool(skill.tools[0], name="alice")
        assert result == "TOK:alice"

    def test_propagates_exceptions_from_sync_tool(self) -> None:
        s = Skill(name="x", version="1.0.0", description="x")

        @s.tool(description="Boom")
        def boom(x: int) -> int:
            """Boom.

            Args:
                x: trigger.
            """
            raise ValueError(f"x={x}")

        with pytest.raises(ValueError, match="x=42"):
            run_tool(s.tools[0], x=42)

    def test_propagates_exceptions_from_async_tool(self) -> None:
        s = Skill(name="x", version="1.0.0", description="x")

        @s.tool(description="Boom")
        async def boom(x: int) -> int:
            """Boom.

            Args:
                x: trigger.
            """
            raise RuntimeError(f"x={x}")

        with pytest.raises(RuntimeError, match="x=7"):
            run_tool(s.tools[0], x=7)

    def test_passes_kwargs_through(self) -> None:
        s = Skill(name="x", version="1.0.0", description="x")

        @s.tool(description="Add")
        def add(a: int, b: int) -> int:
            """Add.

            Args:
                a: first.
                b: second.
            """
            return a + b

        assert run_tool(s.tools[0], a=1, b=2) == 3


# ---------------------------------------------------------------------------
# run_tool_async (async entry point)
# ---------------------------------------------------------------------------
class TestRunToolAsync:
    async def test_async_function_awaited(self) -> None:
        skill = _make_async_skill()
        mock = MockPlatform()
        mock.secrets.set("KEY", "X")
        with mock.activate():
            result = await run_tool_async(skill.tools[0], name="bob")
        assert result == "X:bob"

    async def test_sync_function_works_in_async_context(self) -> None:
        skill = _make_sync_skill()
        result = await run_tool_async(skill.tools[0], text="hi")
        assert result == "hi"


# ---------------------------------------------------------------------------
# Cross-cutting: backend must be active for tools that use the runtime API
# ---------------------------------------------------------------------------
class TestBackendRequirement:
    def test_runtime_call_outside_activate_raises(self) -> None:
        skill = _make_async_skill()
        with pytest.raises(SkillRuntimeError):
            run_tool(skill.tools[0], name="alice")
