"""Tests for the runtime backend ABC, ContextVar wiring, and SkillRuntimeError."""

import uuid
from typing import Any

import httpx
import pytest

from synax_sdk.errors import SkillRuntimeError, SynaxSDKError
from synax_sdk.runtime._backends.base import (
    RuntimeBackend,
    reset_backend,
    resolve_backend,
    set_backend,
)
from synax_sdk.runtime.context import Context, Invoker


class _Stub(RuntimeBackend):
    """Minimal concrete RuntimeBackend so the ABC can be instantiated for tests."""

    async def get_secret(self, name: str) -> str:
        return f"value-of-{name}"

    def log(
        self,
        *,
        level: str,
        message: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        return None

    def record_metric(
        self,
        *,
        name: str,
        kind: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> None:
        return None

    def get_context(self) -> Context:
        return Context(
            run_id=uuid.UUID(int=1),
            workspace_id=uuid.UUID(int=2),
            invoker=Invoker(type="user", id=uuid.UUID(int=3), name="t"),
            channel_id=uuid.UUID(int=4),
        )

    async def http_request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str] | None,
        json: Any | None,
        content: str | bytes | None,
        timeout: float,
    ) -> httpx.Response:
        return httpx.Response(200, text="ok")


class TestRuntimeBackendABC:
    def test_cannot_instantiate_abstract(self) -> None:
        with pytest.raises(TypeError):
            RuntimeBackend()  # type: ignore[abstract]

    def test_concrete_subclass_works(self) -> None:
        backend = _Stub()
        assert isinstance(backend, RuntimeBackend)

    def test_partial_subclass_fails(self) -> None:
        class Half(RuntimeBackend):
            async def get_secret(self, name: str) -> str:
                return ""

            # missing log / record_metric / get_context / http_request

        with pytest.raises(TypeError):
            Half()  # type: ignore[abstract]

    def test_http_request_is_abstract(self) -> None:
        """A subclass missing only http_request still cannot be instantiated."""

        class NoHttp(RuntimeBackend):
            async def get_secret(self, name: str) -> str:
                return ""

            def log(self, *, level, message, extra=None):  # type: ignore[no-untyped-def]
                pass

            def record_metric(self, *, name, kind, value, labels=None):  # type: ignore[no-untyped-def]
                pass

            def get_context(self) -> Context:
                raise NotImplementedError

            # No http_request.

        with pytest.raises(TypeError):
            NoHttp()  # type: ignore[abstract]


class TestResolveBackend:
    def test_raises_when_no_backend_active(self) -> None:
        with pytest.raises(SkillRuntimeError, match="No Synax runtime backend is active"):
            resolve_backend()

    def test_returns_active_backend(self) -> None:
        backend = _Stub()
        token = set_backend(backend)
        try:
            assert resolve_backend() is backend
        finally:
            reset_backend(token)

    def test_error_mentions_test_setup(self) -> None:
        with pytest.raises(SkillRuntimeError) as excinfo:
            resolve_backend()
        msg = str(excinfo.value)
        assert "MockPlatform" in msg
        assert "activate" in msg


class TestSetAndResetBackend:
    def test_set_then_reset(self) -> None:
        backend = _Stub()
        token = set_backend(backend)
        assert resolve_backend() is backend
        reset_backend(token)
        with pytest.raises(SkillRuntimeError):
            resolve_backend()

    def test_nested_set(self) -> None:
        """Inner set/reset restores the outer backend."""
        outer = _Stub()
        inner = _Stub()
        assert outer is not inner

        outer_token = set_backend(outer)
        try:
            inner_token = set_backend(inner)
            try:
                assert resolve_backend() is inner
            finally:
                reset_backend(inner_token)
            assert resolve_backend() is outer
        finally:
            reset_backend(outer_token)


class TestSkillRuntimeError:
    def test_is_synax_sdk_error(self) -> None:
        assert issubclass(SkillRuntimeError, SynaxSDKError)

    def test_raises_with_message(self) -> None:
        err = SkillRuntimeError("test")
        assert str(err) == "test"


# ---------------------------------------------------------------------------
# Context dataclass
# ---------------------------------------------------------------------------
class TestContextDataclass:
    def test_construct(self) -> None:
        c = Context(
            run_id=uuid.UUID(int=1),
            workspace_id=uuid.UUID(int=2),
            invoker=Invoker(type="user", id=uuid.UUID(int=3), name="alice"),
            channel_id=uuid.UUID(int=4),
        )
        assert c.run_id == uuid.UUID(int=1)
        assert c.bot_id is None
        assert c.user_id is None

    def test_optional_fields(self) -> None:
        c = Context(
            run_id=uuid.UUID(int=1),
            workspace_id=uuid.UUID(int=2),
            invoker=Invoker(type="bot", id=uuid.UUID(int=3), name="bot-1"),
            channel_id=uuid.UUID(int=4),
            bot_id=uuid.UUID(int=5),
            user_id=uuid.UUID(int=6),
        )
        assert c.bot_id == uuid.UUID(int=5)
        assert c.user_id == uuid.UUID(int=6)

    def test_frozen(self) -> None:
        import dataclasses

        c = Context(
            run_id=uuid.UUID(int=1),
            workspace_id=uuid.UUID(int=2),
            invoker=Invoker(type="user", id=uuid.UUID(int=3), name="x"),
            channel_id=uuid.UUID(int=4),
        )
        with pytest.raises(dataclasses.FrozenInstanceError):
            c.run_id = uuid.UUID(int=99)  # type: ignore[misc]


class TestInvokerDataclass:
    def test_construct_user(self) -> None:
        i = Invoker(type="user", id=uuid.UUID(int=1), name="alice")
        assert i.type == "user"
        assert i.name == "alice"

    def test_construct_bot(self) -> None:
        i = Invoker(type="bot", id=uuid.UUID(int=1), name="helper")
        assert i.type == "bot"
