"""Tests for ``synax_sdk.testing.declarative``."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from synax_sdk.runtime.logger import logger
from synax_sdk.runtime.secrets import secrets
from synax_sdk.skill import Skill
from synax_sdk.testing import (
    CaseResult,
    TestCase,
    TestCaseError,
    discover_cases,
    run_all,
    run_case,
)


# ---------------------------------------------------------------------------
# Skill fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def echo_skill() -> Skill:
    s = Skill(name="echo-skill", version="1.0.0", description="echo")

    @s.tool(description="Echo")
    def echo(text: str) -> str:
        """Echo.

        Args:
            text: input.
        """
        return text

    return s


@pytest.fixture
def runtime_skill() -> Skill:
    s = Skill(
        name="runtime-skill",
        version="1.0.0",
        description="uses runtime",
        capabilities=["secrets:KEY"],
        secrets=[{"name": "KEY", "type": "api_key", "description": "."}],
    )

    @s.tool(description="Greet")
    async def greet(name: str) -> str:
        """Greet.

        Args:
            name: who.
        """
        token = await secrets.get("KEY")
        logger.info(f"greeted {name}", extra={"who": name})
        return f"{token}:{name}"

    return s


@pytest.fixture
def boom_skill() -> Skill:
    s = Skill(name="boom-skill", version="1.0.0", description="boom")

    @s.tool(description="Raise")
    def explode(reason: str) -> None:
        """Raise.

        Args:
            reason: msg.
        """
        raise ValueError(reason)

    return s


def _write_case(path: Path, content: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(content), encoding="utf-8")


# ---------------------------------------------------------------------------
# discover_cases
# ---------------------------------------------------------------------------
class TestDiscovery:
    def test_missing_dir_returns_empty(self, tmp_path: Path, echo_skill: Skill) -> None:
        assert discover_cases(tmp_path / "nope", echo_skill) == []

    def test_non_directory_raises(self, tmp_path: Path, echo_skill: Skill) -> None:
        target = tmp_path / "x.txt"
        target.write_text("not a dir")
        with pytest.raises(TestCaseError, match="not a directory"):
            discover_cases(target, echo_skill)

    def test_walks_tool_subdirs(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(
            tmp_path / "echo" / "case_basic.yaml",
            {"input": {"text": "hi"}, "expected_output": "hi"},
        )
        cases = discover_cases(tmp_path, echo_skill)
        assert len(cases) == 1
        assert isinstance(cases[0], TestCase)
        assert cases[0].tool == "echo"
        assert cases[0].name == "case_basic"

    def test_unknown_tool_dir_raises(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(tmp_path / "wrong" / "case.yaml", {"input": {}})
        with pytest.raises(TestCaseError, match="doesn't match any tool"):
            discover_cases(tmp_path, echo_skill)

    def test_secrets_yaml_at_root_loaded(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(tmp_path / "secrets.yaml", {"KEY": "from-root"})
        _write_case(tmp_path / "greet" / "case.yaml", {"input": {"name": "A"}})
        cases = discover_cases(tmp_path, runtime_skill)
        assert cases[0].secrets == {"KEY": "from-root"}

    def test_secrets_yaml_at_tool_level_overrides_root(
        self, tmp_path: Path, runtime_skill: Skill
    ) -> None:
        _write_case(tmp_path / "secrets.yaml", {"KEY": "from-root"})
        _write_case(tmp_path / "greet" / "secrets.yaml", {"KEY": "from-tool"})
        _write_case(tmp_path / "greet" / "case.yaml", {"input": {"name": "A"}})
        cases = discover_cases(tmp_path, runtime_skill)
        assert cases[0].secrets == {"KEY": "from-tool"}

    def test_per_case_secrets_override_directory_secrets(
        self, tmp_path: Path, runtime_skill: Skill
    ) -> None:
        _write_case(tmp_path / "greet" / "secrets.yaml", {"KEY": "from-tool"})
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {"input": {"name": "A"}, "secrets": {"KEY": "from-case"}},
        )
        cases = discover_cases(tmp_path, runtime_skill)
        assert cases[0].secrets == {"KEY": "from-case"}

    def test_underscore_prefixed_files_ignored(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(tmp_path / "echo" / "_helper.yaml", {"input": {"text": "hi"}})
        _write_case(tmp_path / "echo" / "case.yaml", {"input": {"text": "hi"}})
        cases = discover_cases(tmp_path, echo_skill)
        assert len(cases) == 1
        assert cases[0].name == "case"

    def test_non_yaml_files_ignored(self, tmp_path: Path, echo_skill: Skill) -> None:
        (tmp_path / "echo").mkdir(parents=True)
        (tmp_path / "echo" / "README.md").write_text("docs")
        _write_case(tmp_path / "echo" / "case.yaml", {"input": {"text": "hi"}})
        cases = discover_cases(tmp_path, echo_skill)
        assert len(cases) == 1

    def test_invalid_yaml_top_level_raises(self, tmp_path: Path, echo_skill: Skill) -> None:
        (tmp_path / "echo").mkdir(parents=True)
        (tmp_path / "echo" / "bad.yaml").write_text("- a\n- b\n")
        with pytest.raises(TestCaseError, match="top-level YAML must be a mapping"):
            discover_cases(tmp_path, echo_skill)

    def test_malformed_yaml_raises(self, tmp_path: Path, echo_skill: Skill) -> None:
        (tmp_path / "echo").mkdir(parents=True)
        (tmp_path / "echo" / "bad.yaml").write_text("not: valid: yaml: :::")
        with pytest.raises(TestCaseError, match="invalid YAML"):
            discover_cases(tmp_path, echo_skill)

    def test_bad_secrets_field_type_raises(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {"input": {"name": "A"}, "secrets": "not-a-dict"},
        )
        with pytest.raises(TestCaseError, match="'secrets' must be a mapping"):
            discover_cases(tmp_path, runtime_skill)


# ---------------------------------------------------------------------------
# run_case — happy paths
# ---------------------------------------------------------------------------
class TestRunCase:
    def test_simple_pass(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(
            tmp_path / "echo" / "case.yaml",
            {"input": {"text": "hi"}, "expected_output": "hi"},
        )
        (case,) = discover_cases(tmp_path, echo_skill)
        result = run_case(case, echo_skill)
        assert result.passed
        assert result.failures == []
        assert result.duration_seconds >= 0.0

    def test_failure_mismatch(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(
            tmp_path / "echo" / "case.yaml",
            {"input": {"text": "hi"}, "expected_output": "BYE"},
        )
        (case,) = discover_cases(tmp_path, echo_skill)
        result = run_case(case, echo_skill)
        assert not result.passed
        assert any("expected_output" in f for f in result.failures)

    def test_async_tool_with_secrets(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {
                "input": {"name": "World"},
                "secrets": {"KEY": "abc"},
                "expected_output": "abc:World",
                "expected_secret_accesses": ["KEY"],
                "expected_logs": [
                    {"level": "info", "message_contains": "greeted World"},
                ],
            },
        )
        (case,) = discover_cases(tmp_path, runtime_skill)
        result = run_case(case, runtime_skill)
        assert result.passed, result.failures

    def test_expected_output_none(self, tmp_path: Path) -> None:
        """expected_output: null is treated as 'expect None', not 'no expectation'."""
        s = Skill(name="x", version="1.0.0", description="x")

        @s.tool(description="None")
        def returns_none() -> None:
            """Returns None."""

        _write_case(
            tmp_path / "returns_none" / "case.yaml",
            {"input": {}, "expected_output": None},
        )
        (case,) = discover_cases(tmp_path, s)
        result = run_case(case, s)
        assert result.passed

    def test_no_expected_output_field_passes_without_check(
        self, tmp_path: Path, echo_skill: Skill
    ) -> None:
        """If the case has no expected_output and no other checks, it passes."""
        _write_case(tmp_path / "echo" / "case.yaml", {"input": {"text": "hi"}})
        (case,) = discover_cases(tmp_path, echo_skill)
        result = run_case(case, echo_skill)
        assert result.passed

    def test_runtime_exception_is_error_not_failure(
        self, tmp_path: Path, boom_skill: Skill
    ) -> None:
        _write_case(
            tmp_path / "explode" / "case.yaml",
            {"input": {"reason": "no thanks"}, "expected_output": "x"},
        )
        (case,) = discover_cases(tmp_path, boom_skill)
        result = run_case(case, boom_skill)
        assert not result.passed
        assert result.error is not None
        assert "ValueError" in result.error
        assert "no thanks" in result.error


# ---------------------------------------------------------------------------
# Expected_output_schema
# ---------------------------------------------------------------------------
class TestExpectedSchema:
    def test_passes_when_output_matches(self, tmp_path: Path) -> None:
        s = Skill(name="x", version="1.0.0", description="x")

        @s.tool(description="Dict")
        def make_dict() -> dict:
            """Returns dict."""
            return {"a": 1, "b": "two"}

        _write_case(
            tmp_path / "make_dict" / "case.yaml",
            {
                "input": {},
                "expected_output_schema": {
                    "type": "object",
                    "properties": {"a": {"type": "integer"}, "b": {"type": "string"}},
                    "required": ["a", "b"],
                },
            },
        )
        (case,) = discover_cases(tmp_path, s)
        assert run_case(case, s).passed

    def test_fails_with_schema_mismatch(self, tmp_path: Path) -> None:
        s = Skill(name="x", version="1.0.0", description="x")

        @s.tool(description="Dict")
        def make_dict() -> dict:
            """Returns dict."""
            return {"a": "wrong-type"}

        _write_case(
            tmp_path / "make_dict" / "case.yaml",
            {
                "input": {},
                "expected_output_schema": {
                    "type": "object",
                    "properties": {"a": {"type": "integer"}},
                },
            },
        )
        (case,) = discover_cases(tmp_path, s)
        result = run_case(case, s)
        assert not result.passed
        assert any("expected_output_schema" in f for f in result.failures)


# ---------------------------------------------------------------------------
# should_raise
# ---------------------------------------------------------------------------
class TestShouldRaise:
    def test_raises_expected(self, tmp_path: Path, boom_skill: Skill) -> None:
        _write_case(
            tmp_path / "explode" / "case.yaml",
            {"input": {"reason": "ok"}, "should_raise": "ValueError"},
        )
        (case,) = discover_cases(tmp_path, boom_skill)
        result = run_case(case, boom_skill)
        assert result.passed

    def test_raises_wrong_type_fails(self, tmp_path: Path, boom_skill: Skill) -> None:
        _write_case(
            tmp_path / "explode" / "case.yaml",
            {"input": {"reason": "ok"}, "should_raise": "RuntimeError"},
        )
        (case,) = discover_cases(tmp_path, boom_skill)
        result = run_case(case, boom_skill)
        assert not result.passed
        assert any("RuntimeError" in f for f in result.failures)

    def test_does_not_raise_when_expected_fails(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(
            tmp_path / "echo" / "case.yaml",
            {"input": {"text": "hi"}, "should_raise": "ValueError"},
        )
        (case,) = discover_cases(tmp_path, echo_skill)
        result = run_case(case, echo_skill)
        assert not result.passed
        assert any("expected exception" in f for f in result.failures)


# ---------------------------------------------------------------------------
# expected_logs
# ---------------------------------------------------------------------------
class TestExpectedLogs:
    def test_message_contains_match(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {
                "input": {"name": "Bob"},
                "secrets": {"KEY": "x"},
                "expected_logs": [{"level": "info", "message_contains": "greeted Bob"}],
            },
        )
        (case,) = discover_cases(tmp_path, runtime_skill)
        assert run_case(case, runtime_skill).passed

    def test_message_equals_match(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {
                "input": {"name": "Bob"},
                "secrets": {"KEY": "x"},
                "expected_logs": [{"message_equals": "greeted Bob"}],
            },
        )
        (case,) = discover_cases(tmp_path, runtime_skill)
        assert run_case(case, runtime_skill).passed

    def test_extra_contains_match(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {
                "input": {"name": "Bob"},
                "secrets": {"KEY": "x"},
                "expected_logs": [{"extra_contains": {"who": "Bob"}}],
            },
        )
        (case,) = discover_cases(tmp_path, runtime_skill)
        assert run_case(case, runtime_skill).passed

    def test_no_log_match_fails(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {
                "input": {"name": "Bob"},
                "secrets": {"KEY": "x"},
                "expected_logs": [{"level": "error", "message_contains": "Bob"}],
            },
        )
        (case,) = discover_cases(tmp_path, runtime_skill)
        result = run_case(case, runtime_skill)
        assert not result.passed
        assert any("no log matched" in f for f in result.failures)


# ---------------------------------------------------------------------------
# expected_secret_accesses
# ---------------------------------------------------------------------------
class TestExpectedSecretAccesses:
    def test_missing_access_fails(self, tmp_path: Path, runtime_skill: Skill) -> None:
        _write_case(
            tmp_path / "greet" / "case.yaml",
            {
                "input": {"name": "x"},
                "secrets": {"KEY": "v"},
                "expected_secret_accesses": ["KEY", "OTHER"],
            },
        )
        (case,) = discover_cases(tmp_path, runtime_skill)
        result = run_case(case, runtime_skill)
        assert not result.passed
        assert any("OTHER" in f for f in result.failures)


# ---------------------------------------------------------------------------
# run_all
# ---------------------------------------------------------------------------
class TestRunAll:
    def test_runs_every_discovered_case(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(
            tmp_path / "echo" / "a.yaml",
            {"input": {"text": "a"}, "expected_output": "a"},
        )
        _write_case(
            tmp_path / "echo" / "b.yaml",
            {"input": {"text": "b"}, "expected_output": "b"},
        )
        results = run_all(echo_skill, tmp_path)
        assert len(results) == 2
        assert all(r.passed for r in results)

    def test_filter_by_tool(self, tmp_path: Path) -> None:
        s = Skill(name="m", version="1.0.0", description="m")

        @s.tool(description="A")
        def alpha(x: str) -> str:
            """Alpha.

            Args:
                x: in.
            """
            return x

        @s.tool(description="B")
        def beta(x: str) -> str:
            """Beta.

            Args:
                x: in.
            """
            return x

        _write_case(tmp_path / "alpha" / "case.yaml", {"input": {"x": "a"}})
        _write_case(tmp_path / "beta" / "case.yaml", {"input": {"x": "b"}})
        results = run_all(s, tmp_path, filter_tool="alpha")
        assert [r.tool for r in results] == ["alpha"]

    def test_filter_by_case_substring(self, tmp_path: Path, echo_skill: Skill) -> None:
        _write_case(tmp_path / "echo" / "case_alpha.yaml", {"input": {"text": "x"}})
        _write_case(tmp_path / "echo" / "case_beta.yaml", {"input": {"text": "x"}})
        results = run_all(echo_skill, tmp_path, filter_case="alpha")
        assert [r.case for r in results] == ["case_alpha"]


# ---------------------------------------------------------------------------
# CaseResult shape
# ---------------------------------------------------------------------------
class TestCaseResult:
    def test_label(self) -> None:
        result = CaseResult(tool="t", case="c", passed=True, duration_seconds=0.01)
        assert result.label == "t/c"
