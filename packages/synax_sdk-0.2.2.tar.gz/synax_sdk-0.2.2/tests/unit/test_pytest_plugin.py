"""Tests for the pytest plugin exposed by ``synax_sdk.testing.pytest_plugin``.

Uses pytest's built-in ``pytester`` fixture (auto-loaded via ``pytest.Pytester``)
to invoke a fresh pytest in a temp directory and verify our plugin's
fixtures show up + work.
"""

from __future__ import annotations

import pytest

pytest_plugins = ["pytester"]


PYPROJECT = """\
[project]
name = "demo"
version = "0.0.0"

[tool.synax]
entry_point = "demo_skill:skill"

[tool.pytest.ini_options]
asyncio_mode = "auto"
"""

SKILL_SRC = """\
from synax_sdk import Skill

skill = Skill(
    name="demo",
    version="0.1.0",
    description="demo",
    capabilities=["secrets:GREETING"],
    secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
)

@skill.tool(description="Greet")
async def greet(name: str) -> str:
    \"\"\"Greet.

    Args:
        name: who.
    \"\"\"
    from synax_sdk import secrets as s
    g = await s.get("GREETING")
    return f"{g}, {name}"
"""


def _make_project(pytester: pytest.Pytester) -> None:
    pytester.makefile(".toml", pyproject=PYPROJECT)
    pytester.makepyfile(demo_skill=SKILL_SRC)


class TestMockPlatformFixture:
    def test_fixture_yields_active_mock(self, pytester: pytest.Pytester) -> None:
        _make_project(pytester)
        pytester.makepyfile(test_x="""
            import pytest
            from synax_sdk import secrets

            async def test_secrets_available(synax_mock_platform):
                synax_mock_platform.secrets.set("K", "V")
                assert await secrets.get("K") == "V"
            """)
        result = pytester.runpytest("-q")
        result.assert_outcomes(passed=1)

    def test_each_test_gets_fresh_mock(self, pytester: pytest.Pytester) -> None:
        _make_project(pytester)
        pytester.makepyfile(test_x="""
            async def test_first(synax_mock_platform):
                synax_mock_platform.secrets.set("K", "A")
                assert "K" not in synax_mock_platform.secrets.accesses

            async def test_second(synax_mock_platform):
                # Should NOT see the secret from test_first.
                assert synax_mock_platform.secrets.accesses == []
            """)
        result = pytester.runpytest("-q")
        result.assert_outcomes(passed=2)


class TestSkillUnderTestFixture:
    def test_loads_project_skill(self, pytester: pytest.Pytester) -> None:
        _make_project(pytester)
        pytester.makepyfile(test_x="""
            from synax_sdk import Skill

            def test_skill_loaded(synax_skill_under_test):
                assert isinstance(synax_skill_under_test, Skill)
                assert synax_skill_under_test.name == "demo"
                assert synax_skill_under_test.tools[0].name == "greet"
            """)
        result = pytester.runpytest("-q")
        result.assert_outcomes(passed=1)

    def test_tools_runnable_through_mock(self, pytester: pytest.Pytester) -> None:
        _make_project(pytester)
        pytester.makepyfile(test_x="""
            from synax_sdk.testing import run_tool_async

            async def test_invoke_tool(synax_mock_platform, synax_skill_under_test):
                synax_mock_platform.secrets.set("GREETING", "Hi")
                tool = next(t for t in synax_skill_under_test.tools if t.name == "greet")
                result = await run_tool_async(tool, name="World")
                assert result == "Hi, World"
            """)
        result = pytester.runpytest("-q")
        result.assert_outcomes(passed=1)


class TestPluginAutoloaded:
    def test_no_conftest_required(self, pytester: pytest.Pytester) -> None:
        """The plugin loads via entry-points; pytester sees it without a conftest."""
        _make_project(pytester)
        pytester.makepyfile(test_x="""
            def test_fixtures_visible(synax_mock_platform, synax_skill_under_test):
                # Just touching the fixtures is enough to prove they're loaded.
                assert synax_mock_platform is not None
                assert synax_skill_under_test is not None
            """)
        result = pytester.runpytest("-q")
        result.assert_outcomes(passed=1)
