"""Tests for ``synax_sdk.packaging`` — deterministic tar.gz of a project directory."""

from __future__ import annotations

import gzip
import io
import tarfile
from pathlib import Path

import pytest

from synax_sdk.packaging import (
    DEFAULT_IGNORE_PATTERNS,
    ArtifactResult,
    build_implementation_artifact,
    load_skillignore,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _write(path: Path, content: str = "x") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _tar_entries(blob: bytes) -> list[tarfile.TarInfo]:
    """Return TarInfo entries from a tar.gz blob."""
    with gzip.GzipFile(fileobj=io.BytesIO(blob), mode="rb") as gz:
        with tarfile.open(fileobj=gz, mode="r") as tar:  # type: ignore[arg-type]
            return list(tar.getmembers())


# ---------------------------------------------------------------------------
# load_skillignore
# ---------------------------------------------------------------------------
class TestLoadSkillignore:
    def test_defaults_when_no_file(self, tmp_path: Path) -> None:
        patterns = load_skillignore(tmp_path)
        assert patterns == list(DEFAULT_IGNORE_PATTERNS)

    def test_file_replaces_defaults(self, tmp_path: Path) -> None:
        (tmp_path / ".synax-skillignore").write_text("*.tmp\nbuild/\n", encoding="utf-8")
        patterns = load_skillignore(tmp_path)
        assert patterns == ["*.tmp", "build/"]
        # __pycache__/ from defaults is NOT included
        assert "__pycache__/" not in patterns

    def test_comments_and_blank_lines_stripped(self, tmp_path: Path) -> None:
        (tmp_path / ".synax-skillignore").write_text(
            "# a comment\n\n*.tmp\n   \n# another\nbuild/\n",
            encoding="utf-8",
        )
        patterns = load_skillignore(tmp_path)
        assert patterns == ["*.tmp", "build/"]

    def test_whitespace_stripped(self, tmp_path: Path) -> None:
        (tmp_path / ".synax-skillignore").write_text("  *.tmp  \n", encoding="utf-8")
        patterns = load_skillignore(tmp_path)
        assert patterns == ["*.tmp"]


# ---------------------------------------------------------------------------
# build_implementation_artifact — basic shape
# ---------------------------------------------------------------------------
class TestBasicBuild:
    def test_missing_directory_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            build_implementation_artifact(tmp_path / "nope")

    def test_file_passed_as_dir_raises(self, tmp_path: Path) -> None:
        f = tmp_path / "a.txt"
        f.write_text("x", encoding="utf-8")
        with pytest.raises(FileNotFoundError):
            build_implementation_artifact(f)

    def test_empty_directory(self, tmp_path: Path) -> None:
        result = build_implementation_artifact(tmp_path)
        assert result.included_files == []
        assert result.sha256.startswith("sha256:")
        assert len(result.sha256) == len("sha256:") + 64

    def test_returns_artifact_result(self, tmp_path: Path) -> None:
        _write(tmp_path / "a.py", "print()")
        result = build_implementation_artifact(tmp_path)
        assert isinstance(result, ArtifactResult)
        assert isinstance(result.tar_gz_bytes, bytes)


# ---------------------------------------------------------------------------
# Contents and ordering
# ---------------------------------------------------------------------------
class TestArtifactContents:
    def test_includes_files(self, tmp_path: Path) -> None:
        _write(tmp_path / "skill.py", "import x")
        _write(tmp_path / "pyproject.toml", "[project]")
        result = build_implementation_artifact(tmp_path)
        assert "skill.py" in result.included_files
        assert "pyproject.toml" in result.included_files

    def test_archive_paths_use_posix_slashes(self, tmp_path: Path) -> None:
        _write(tmp_path / "sub" / "nested.py", "x")
        result = build_implementation_artifact(tmp_path)
        assert "sub/nested.py" in result.included_files

    def test_files_sorted_alphabetically(self, tmp_path: Path) -> None:
        _write(tmp_path / "z.py", "")
        _write(tmp_path / "a.py", "")
        _write(tmp_path / "m.py", "")
        result = build_implementation_artifact(tmp_path)
        assert result.included_files == ["a.py", "m.py", "z.py"]

    def test_archive_contains_file_bytes(self, tmp_path: Path) -> None:
        # Use binary write so OS-level newline translation can't affect the size.
        target = tmp_path / "skill.py"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"print('hi')\n")
        result = build_implementation_artifact(tmp_path)
        entries = _tar_entries(result.tar_gz_bytes)
        names = {m.name: m for m in entries}
        assert "skill.py" in names
        assert names["skill.py"].size == len(b"print('hi')\n")


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------
class TestDeterminism:
    def test_same_project_same_bytes(self, tmp_path: Path) -> None:
        _write(tmp_path / "a.py", "x")
        _write(tmp_path / "b.py", "y")
        r1 = build_implementation_artifact(tmp_path)
        r2 = build_implementation_artifact(tmp_path)
        assert r1.tar_gz_bytes == r2.tar_gz_bytes
        assert r1.sha256 == r2.sha256

    def test_content_change_changes_hash(self, tmp_path: Path) -> None:
        target = tmp_path / "a.py"
        _write(target, "v1")
        r1 = build_implementation_artifact(tmp_path)
        _write(target, "v2")
        r2 = build_implementation_artifact(tmp_path)
        assert r1.sha256 != r2.sha256

    def test_creation_order_doesnt_matter(self, tmp_path: Path) -> None:
        """Files added in different orders produce the same archive."""
        # Order 1: a, b, c
        d1 = tmp_path / "d1"
        d1.mkdir()
        _write(d1 / "a.py", "x")
        _write(d1 / "b.py", "y")
        _write(d1 / "c.py", "z")

        # Order 2: c, a, b
        d2 = tmp_path / "d2"
        d2.mkdir()
        _write(d2 / "c.py", "z")
        _write(d2 / "a.py", "x")
        _write(d2 / "b.py", "y")

        r1 = build_implementation_artifact(d1)
        r2 = build_implementation_artifact(d2)
        # tar archives may differ due to other metadata, but the included
        # file order MUST be alphabetical regardless.
        assert r1.included_files == r2.included_files == ["a.py", "b.py", "c.py"]

    def test_no_current_time_in_archive(self, tmp_path: Path) -> None:
        """mtime fields zeroed → no time leakage."""
        _write(tmp_path / "a.py", "x")
        result = build_implementation_artifact(tmp_path)
        entries = _tar_entries(result.tar_gz_bytes)
        for entry in entries:
            assert entry.mtime == 0, f"{entry.name} has mtime {entry.mtime}"

    def test_no_current_user_in_archive(self, tmp_path: Path) -> None:
        """uid/gid/uname/gname all zeroed/empty."""
        _write(tmp_path / "a.py", "x")
        result = build_implementation_artifact(tmp_path)
        entries = _tar_entries(result.tar_gz_bytes)
        for entry in entries:
            assert entry.uid == 0
            assert entry.gid == 0
            assert entry.uname == ""
            assert entry.gname == ""

    def test_file_modes_normalised(self, tmp_path: Path) -> None:
        _write(tmp_path / "a.py", "x")
        result = build_implementation_artifact(tmp_path)
        entries = _tar_entries(result.tar_gz_bytes)
        for entry in entries:
            if entry.isfile():
                assert entry.mode == 0o644


# ---------------------------------------------------------------------------
# Ignore patterns
# ---------------------------------------------------------------------------
class TestIgnore:
    def test_default_excludes_pycache(self, tmp_path: Path) -> None:
        _write(tmp_path / "skill.py", "x")
        _write(tmp_path / "__pycache__" / "skill.cpython-314.pyc", "")
        result = build_implementation_artifact(tmp_path)
        assert "skill.py" in result.included_files
        assert all("__pycache__" not in p for p in result.included_files)

    def test_default_excludes_pyc(self, tmp_path: Path) -> None:
        _write(tmp_path / "a.py", "")
        _write(tmp_path / "a.pyc", "")
        result = build_implementation_artifact(tmp_path)
        assert "a.py" in result.included_files
        assert "a.pyc" not in result.included_files

    def test_default_excludes_dot_synax(self, tmp_path: Path) -> None:
        _write(tmp_path / ".synax" / "keys" / "abc.key", "")
        _write(tmp_path / "skill.py", "x")
        result = build_implementation_artifact(tmp_path)
        assert result.included_files == ["skill.py"]

    def test_default_excludes_venv(self, tmp_path: Path) -> None:
        _write(tmp_path / ".venv" / "bin" / "python", "")
        _write(tmp_path / "skill.py", "x")
        result = build_implementation_artifact(tmp_path)
        assert result.included_files == ["skill.py"]

    def test_default_excludes_env_files(self, tmp_path: Path) -> None:
        _write(tmp_path / ".env", "")
        _write(tmp_path / ".env.local", "")
        _write(tmp_path / "skill.py", "x")
        result = build_implementation_artifact(tmp_path)
        assert ".env" not in result.included_files
        assert ".env.local" not in result.included_files

    def test_custom_skillignore_used(self, tmp_path: Path) -> None:
        _write(tmp_path / ".synax-skillignore", "*.draft\n")
        _write(tmp_path / "skill.py", "x")
        _write(tmp_path / "notes.draft", "x")
        # The default pyc filter does NOT apply because skillignore replaces defaults.
        _write(tmp_path / "a.pyc", "x")
        result = build_implementation_artifact(tmp_path)
        # .pyc not in our custom list → INCLUDED. .draft excluded.
        assert "notes.draft" not in result.included_files
        # .synax-skillignore itself is not in the custom ignore list, so it should appear.
        assert ".synax-skillignore" in result.included_files

    def test_extra_ignore_appended(self, tmp_path: Path) -> None:
        _write(tmp_path / "secret.txt", "x")
        _write(tmp_path / "skill.py", "x")
        result = build_implementation_artifact(tmp_path, extra_ignore=["secret.txt"])
        assert "skill.py" in result.included_files
        assert "secret.txt" not in result.included_files

    def test_directory_pattern_matches_subdirectory(self, tmp_path: Path) -> None:
        _write(tmp_path / "a" / "b" / "__pycache__" / "x.pyc", "")
        _write(tmp_path / "skill.py", "x")
        result = build_implementation_artifact(tmp_path)
        assert "skill.py" in result.included_files
        assert all("__pycache__" not in p for p in result.included_files)


# ---------------------------------------------------------------------------
# Symlinks (POSIX only — Windows tests skip silently because the
# symlink creation requires elevated privileges)
# ---------------------------------------------------------------------------
class TestSymlinks:
    def test_symlinks_skipped(self, tmp_path: Path) -> None:
        target = tmp_path / "real.py"
        _write(target, "x")
        link = tmp_path / "link.py"
        try:
            link.symlink_to(target)
        except (OSError, NotImplementedError):
            pytest.skip("symlink creation not supported in this environment")

        result = build_implementation_artifact(tmp_path)
        assert "real.py" in result.included_files
        # symlinks are skipped
        assert "link.py" not in result.included_files


# ---------------------------------------------------------------------------
# Hash format
# ---------------------------------------------------------------------------
class TestHash:
    def test_sha256_format(self, tmp_path: Path) -> None:
        _write(tmp_path / "a.py", "x")
        result = build_implementation_artifact(tmp_path)
        assert result.sha256.startswith("sha256:")
        hex_part = result.sha256[len("sha256:") :]
        assert len(hex_part) == 64
        assert all(c in "0123456789abcdef" for c in hex_part)

    def test_hash_matches_actual_bytes(self, tmp_path: Path) -> None:
        import hashlib

        _write(tmp_path / "a.py", "x")
        result = build_implementation_artifact(tmp_path)
        expected = "sha256:" + hashlib.sha256(result.tar_gz_bytes).hexdigest()
        assert result.sha256 == expected
