"""Tests for ``synax_sdk.build`` — the end-to-end pipeline orchestrator."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from synax_sdk.build import build
from synax_sdk.errors import BuildError
from synax_sdk.signing import KeyStore, generate_keypair
from synax_sdk.skill import Skill


# ---------------------------------------------------------------------------
# Fixtures: a minimal valid project on disk
# ---------------------------------------------------------------------------
@pytest.fixture
def skill() -> Skill:
    s = Skill(
        name="hello-skill",
        version="0.1.0",
        description="A trivial skill",
        capabilities=["secrets:GREETING"],
        secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
    )

    @s.tool(description="Greet")
    async def greet(name: str) -> str:
        """Greet.

        Args:
            name: who.
        """
        return f"hello, {name}"

    return s


@pytest.fixture
def project_root(tmp_path: Path) -> Path:
    (tmp_path / "skill_module.py").write_text("", encoding="utf-8")
    return tmp_path


@pytest.fixture
def key_store(tmp_path: Path) -> KeyStore:
    store = KeyStore(root=tmp_path / "keys")
    store.save(generate_keypair())
    return store


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------
class TestSuccessfulBuild:
    def test_returns_build_result(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(
            project_root,
            skill,
            entry_point="skill_module:skill",
            key_store=key_store,
        )
        assert result.manifest.name == "hello-skill"
        assert result.signature.signer_type == "author"
        assert result.signature.key_fingerprint == key_store.default_fingerprint
        assert result.warnings == []

    def test_manifest_has_hash_pinned(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        assert result.manifest.implementation.hash is not None
        assert result.manifest.implementation.hash.startswith("sha256:")
        assert result.manifest.implementation.hash == result.artifact.sha256

    def test_manifest_has_entry_point(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        assert result.manifest.implementation.entry_point == "m:s"

    def test_writes_bundle_files(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        assert (result.bundle_dir / "manifest.yaml").exists()
        assert (result.bundle_dir / "implementation.tar.gz").exists()

    def test_writes_diagnostic_files_at_build_root(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        assert (result.output_dir / "manifest.yaml").exists()
        assert (result.output_dir / "manifest.json").exists()
        assert (result.output_dir / "manifest.canonical").exists()

    def test_signature_verifies_against_canonical(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        # Re-derive canonical form from the file and verify
        canonical = (result.output_dir / "manifest.canonical").read_bytes()
        kp = key_store.load(result.signature.key_fingerprint)
        kp.verifier().verify(canonical, result.signature.signature)

    def test_signature_appears_in_manifest(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        assert len(result.manifest.signatures) == 1
        assert result.manifest.signatures[0] is result.signature

    def test_yaml_bundle_round_trips(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        text = (result.bundle_dir / "manifest.yaml").read_text(encoding="utf-8")
        parsed = yaml.safe_load(text)
        assert parsed["name"] == "hello-skill"
        assert parsed["implementation"]["entry_point"] == "m:s"
        assert parsed["signatures"][0]["signer_type"] == "author"

    def test_json_round_trips(self, project_root: Path, skill: Skill, key_store: KeyStore) -> None:
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        parsed = json.loads((result.output_dir / "manifest.json").read_text(encoding="utf-8"))
        assert parsed["name"] == "hello-skill"


# ---------------------------------------------------------------------------
# Custom output_dir + key_fingerprint
# ---------------------------------------------------------------------------
class TestBuildOptions:
    def test_custom_output_dir(
        self, project_root: Path, tmp_path: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        target = tmp_path / "other_build"
        result = build(
            project_root,
            skill,
            entry_point="m:s",
            output_dir=target,
            key_store=key_store,
        )
        assert result.output_dir == target.resolve()
        assert (target / "signed_bundle" / "manifest.yaml").exists()

    def test_explicit_key_fingerprint(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        kp = generate_keypair()
        key_store.save(kp)
        result = build(
            project_root,
            skill,
            entry_point="m:s",
            key_fingerprint=kp.fingerprint,
            key_store=key_store,
        )
        assert result.signature.key_fingerprint == kp.fingerprint

    def test_excludes_output_dir_when_inside_project(
        self, project_root: Path, skill: Skill, key_store: KeyStore
    ) -> None:
        # The default output_dir is project_root/build/ — it shouldn't end up
        # included in its own artifact.
        result = build(project_root, skill, entry_point="m:s", key_store=key_store)
        assert "build/" not in " ".join(result.artifact.included_files)


# ---------------------------------------------------------------------------
# Failure modes
# ---------------------------------------------------------------------------
class TestBuildErrors:
    def test_no_signing_key_available(
        self, project_root: Path, skill: Skill, tmp_path: Path
    ) -> None:
        empty_store = KeyStore(root=tmp_path / "empty_keys")
        with pytest.raises(BuildError, match="No signing key available"):
            build(project_root, skill, entry_point="m:s", key_store=empty_store)

    def test_validation_failure_blocks_build(self, project_root: Path, key_store: KeyStore) -> None:
        # Construct a skill with NO tools — fails JSON Schema's minItems=1
        bad = Skill(name="empty", version="1.0.0", description="empty")
        with pytest.raises(BuildError, match="Manifest failed validation"):
            build(project_root, bad, entry_point="m:s", key_store=key_store)

    def test_validation_error_carries_errors(self, project_root: Path, key_store: KeyStore) -> None:
        bad = Skill(name="empty", version="1.0.0", description="empty")
        try:
            build(project_root, bad, entry_point="m:s", key_store=key_store)
        except BuildError as exc:
            assert exc.errors
            assert any("tools" in str(e.field) for e in exc.errors)
        else:
            pytest.fail("expected BuildError")

    def test_warnings_dont_block_but_are_returned(
        self, project_root: Path, key_store: KeyStore
    ) -> None:
        # daemon_only without local capability emits a warning
        s = Skill(
            name="w",
            version="1.0.0",
            description="w",
            capabilities=["network:api.example.com"],
            execution_location="daemon_only",
        )

        @s.tool(description="t")
        def t() -> None:
            """T."""

        result = build(project_root, s, entry_point="m:s", key_store=key_store)
        assert any(w.kind == "warning" for w in result.warnings)


# ---------------------------------------------------------------------------
# Determinism (artifact hash is stable across runs)
# ---------------------------------------------------------------------------
class TestDeterminism:
    def test_same_project_same_artifact_hash(
        self, project_root: Path, skill: Skill, tmp_path: Path
    ) -> None:
        store1 = KeyStore(root=tmp_path / "k1")
        store1.save(generate_keypair())
        store2 = KeyStore(root=tmp_path / "k2")
        store2.save(generate_keypair())

        r1 = build(project_root, skill, entry_point="m:s", key_store=store1)
        r2 = build(project_root, skill, entry_point="m:s", key_store=store2)
        # Different keys → different signatures, but identical artifact.
        assert r1.artifact.sha256 == r2.artifact.sha256
        assert r1.signature.signature != r2.signature.signature
