"""Tests for ``synax_sdk.runtime._capabilities``.

Covers backend-vs-env precedence, env-var format handling (valid /
missing / empty / malformed JSON / non-array / non-string elements),
warning emission for malformed inputs, and cache behavior.
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from synax_sdk.runtime import _capabilities
from synax_sdk.runtime._backends.base import RuntimeBackend, reset_backend, set_backend
from synax_sdk.runtime._backends.mock import MockBackend


class _MinimalBackend(RuntimeBackend):
    """Concrete backend that inherits every default — including the None
    return from ``get_runtime_capabilities``. Used to exercise the
    opt-out branch where the env var path takes over."""

    async def get_secret(self, name: str) -> str:  # pragma: no cover
        return ""

    def log(
        self,
        *,
        level: str,
        message: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        return None

    def record_metric(
        self,
        *,
        name: str,
        kind: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> None:
        return None

    def get_context(self):  # type: ignore[no-untyped-def]
        raise NotImplementedError

    async def http_request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str] | None,
        json: Any | None,
        content: str | bytes | None,
        timeout: float,
    ) -> httpx.Response:  # pragma: no cover
        return httpx.Response(200)


@pytest.fixture(autouse=True)
def reset_cap_cache() -> None:
    """Ensure every test starts with a cold env-var cache."""
    _capabilities._reset_cache_for_testing()


class TestEnvVarPath:
    """When no backend is bound, the env var is the source of truth."""

    def test_missing_env_var_yields_empty_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv(_capabilities.ENV_VAR, raising=False)
        assert _capabilities.get_runtime_capabilities() == frozenset()

    def test_empty_array_yields_empty_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, "[]")
        assert _capabilities.get_runtime_capabilities() == frozenset()

    def test_valid_array(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(
            _capabilities.ENV_VAR,
            '["network:api.example.com", "secrets:FOO"]',
        )
        assert _capabilities.get_runtime_capabilities() == frozenset(
            {"network:api.example.com", "secrets:FOO"}
        )

    def test_malformed_json_warns_and_returns_empty(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, "not valid json")
        with pytest.warns(RuntimeWarning, match="not valid JSON"):
            assert _capabilities.get_runtime_capabilities() == frozenset()

    def test_non_array_json_warns_and_returns_empty(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, '{"k": "v"}')
        with pytest.warns(RuntimeWarning, match="must be a JSON array"):
            assert _capabilities.get_runtime_capabilities() == frozenset()

    def test_non_string_elements_warns_and_returns_empty(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, "[1, 2, 3]")
        with pytest.warns(RuntimeWarning, match="non-string elements"):
            assert _capabilities.get_runtime_capabilities() == frozenset()


class TestCaching:
    """The env-var path is cached process-wide; tests can reset it."""

    def test_value_is_cached_across_calls(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:x"]')
        first = _capabilities.get_runtime_capabilities()
        # Change the env without resetting cache — should still see old value.
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:y"]')
        second = _capabilities.get_runtime_capabilities()
        assert first == second == frozenset({"network:x"})

    def test_reset_cache_picks_up_new_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:x"]')
        assert _capabilities.get_runtime_capabilities() == frozenset({"network:x"})
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:y"]')
        _capabilities._reset_cache_for_testing()
        assert _capabilities.get_runtime_capabilities() == frozenset({"network:y"})


class TestBackendPrecedence:
    """When a backend supplies capabilities, the env var is bypassed."""

    def test_mock_backend_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:from-env"]')
        backend = MockBackend()
        backend.set_capabilities(frozenset({"network:from-backend"}))
        token = set_backend(backend)
        try:
            assert _capabilities.get_runtime_capabilities() == frozenset({"network:from-backend"})
        finally:
            reset_backend(token)

    def test_explicitly_empty_mock_does_not_fall_through(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Empty backend set must still suppress the env-var path.

        ``frozenset()`` from a backend means "this invocation has no
        capabilities", not "I have nothing to say — ask the env".
        """
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:from-env"]')
        backend = MockBackend()  # defaults to frozenset()
        token = set_backend(backend)
        try:
            assert _capabilities.get_runtime_capabilities() == frozenset()
        finally:
            reset_backend(token)


class TestAbcDefault:
    """RuntimeBackend.get_runtime_capabilities default returns None — opt-out."""

    def test_default_returns_none(self) -> None:
        backend = _MinimalBackend()
        assert backend.get_runtime_capabilities() is None

    def test_opt_out_backend_falls_through_to_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:from-env"]')
        token = set_backend(_MinimalBackend())
        try:
            assert _capabilities.get_runtime_capabilities() == frozenset({"network:from-env"})
        finally:
            reset_backend(token)
