"""Tests for ``synax_sdk.runtime.network``.

Covers: capability matching (host, host:port, wildcard, missing),
verb wrappers, default headers / timeout, audit logging through both
backend and stdlib paths, and the no-backend production fallback that
uses httpx directly.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx
import pytest

from synax_sdk import CapabilityError, __version__
from synax_sdk.runtime import _capabilities, network
from synax_sdk.testing import MockPlatform


@pytest.fixture(autouse=True)
def reset_cap_cache() -> None:
    """Cold env-var cache for every test."""
    _capabilities._reset_cache_for_testing()


class TestCapabilityMatching:
    """``_check_capability`` honors wildcard, host-only, and host:port forms."""

    @pytest.mark.parametrize(
        "url, caps",
        [
            ("https://api.example.com/x", frozenset({"network:api.example.com"})),
            ("https://api.example.com:8443/x", frozenset({"network:api.example.com"})),
            (
                "https://api.example.com:8443/x",
                frozenset({"network:api.example.com:8443"}),
            ),
            ("https://anything.example.com/", frozenset({"network:*"})),
            ("https://host:1234/", frozenset({"network:*"})),
        ],
    )
    def test_allowed(self, url: str, caps: frozenset[str]) -> None:
        network._check_capability(url, caps)  # does not raise

    def test_denied_with_no_caps(self) -> None:
        with pytest.raises(CapabilityError) as excinfo:
            network._check_capability("https://api.example.com/", frozenset())
        assert excinfo.value.requested == "network:api.example.com"
        assert excinfo.value.available == frozenset()

    def test_denied_reports_port_form_when_url_has_port(self) -> None:
        with pytest.raises(CapabilityError) as excinfo:
            network._check_capability(
                "https://smtp.example.com:587/x",
                frozenset({"network:other.example.com"}),
            )
        assert excinfo.value.requested == "network:smtp.example.com:587"

    def test_port_qualified_cap_does_not_match_different_port(self) -> None:
        with pytest.raises(CapabilityError):
            network._check_capability(
                "https://example.com:443/",
                frozenset({"network:example.com:8443"}),
            )

    def test_unparseable_url_raises(self) -> None:
        with pytest.raises(CapabilityError) as excinfo:
            network._check_capability("not a url", frozenset({"network:*"}))
        assert "unparseable" in excinfo.value.requested


class TestVerbWrappers:
    """All five verbs route through the bound backend with the right method."""

    @pytest.mark.parametrize(
        "verb, method, has_body",
        [
            (network.http_get, "GET", False),
            (network.http_post, "POST", True),
            (network.http_put, "PUT", True),
            (network.http_delete, "DELETE", False),
            (network.http_patch, "PATCH", True),
        ],
    )
    @pytest.mark.asyncio
    async def test_verb_dispatches_correctly(
        self,
        verb: Any,
        method: str,
        has_body: bool,
    ) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to(
            "https://example.com/x",
            method=method,
            status=200,
            text="ok",
        )
        with mock.activate():
            if has_body:
                response = await verb("https://example.com/x", json={"a": 1})
            else:
                response = await verb("https://example.com/x")
        assert response.status_code == 200
        assert mock.network.requests[0].method == method


class TestCapabilityEnforcement:
    """Calls without a matching capability fail before any HTTP traffic."""

    @pytest.mark.asyncio
    async def test_missing_capability_raises_before_dispatch(self) -> None:
        mock = MockPlatform()
        # No respond_to — if the call reaches the backend we'd hit
        # AssertionError; we expect CapabilityError instead.
        with mock.activate():
            with pytest.raises(CapabilityError, match=r"api\.example\.com"):
                await network.http_get("https://api.example.com/x")
        assert mock.network.requests == []

    @pytest.mark.asyncio
    async def test_host_only_cap_allows_explicit_port(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com:8443/x", method="GET", status=200, text="ok")
        with mock.activate():
            r = await network.http_get("https://example.com:8443/x")
        assert r.status_code == 200


class TestDefaultsAndHeaders:
    """User-Agent + 30s default timeout are wired correctly."""

    @pytest.mark.asyncio
    async def test_default_user_agent_added(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com/x", text="ok")
        with mock.activate():
            await network.http_get("https://example.com/x")
        ua = mock.network.requests[0].headers["User-Agent"]
        assert ua == f"synax-sdk/{__version__}"

    @pytest.mark.asyncio
    async def test_user_supplied_user_agent_wins(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com/x", text="ok")
        with mock.activate():
            await network.http_get("https://example.com/x", headers={"user-agent": "skill/1.0"})
        # Case-insensitive — only the user's header should remain.
        headers = mock.network.requests[0].headers
        assert headers.get("user-agent") == "skill/1.0"
        assert "User-Agent" not in headers  # default removed

    @pytest.mark.asyncio
    async def test_default_timeout_is_30_seconds(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com/x", text="ok")
        with mock.activate():
            await network.http_get("https://example.com/x")
        assert mock.network.requests[0].timeout == 30.0

    @pytest.mark.asyncio
    async def test_timeout_override(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com/x", text="ok")
        with mock.activate():
            await network.http_get("https://example.com/x", timeout=5.5)
        assert mock.network.requests[0].timeout == 5.5


class TestAuditLog:
    """Each call emits one structured log record."""

    @pytest.mark.asyncio
    async def test_log_through_backend_when_bound(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com/x", status=200, text="ok")
        with mock.activate():
            await network.http_get("https://example.com/x")
        info_calls = mock.logger.at_level("info")
        assert len(info_calls) == 1
        call = info_calls[0]
        assert call.message == "HTTP request"
        assert call.extra["method"] == "GET"
        assert call.extra["url"] == "https://example.com/x"
        assert call.extra["status_code"] == 200
        assert call.extra["duration_ms"] >= 0

    @pytest.mark.asyncio
    async def test_log_emitted_even_when_backend_raises(self) -> None:
        """A failed call still produces an audit record (without status)."""
        mock = MockPlatform()
        mock.capabilities.set(["network:example.com"])
        mock.network.respond_to("https://example.com/x", raises=httpx.ConnectError("nope"))
        with mock.activate():
            with pytest.raises(httpx.ConnectError):
                await network.http_get("https://example.com/x")
        info_calls = mock.logger.at_level("info")
        assert len(info_calls) == 1
        assert "status_code" not in info_calls[0].extra

    @pytest.mark.asyncio
    async def test_log_falls_back_to_stdlib_when_no_backend(
        self,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        """No-backend path uses the stdlib logger so audit isn't silent."""
        monkeypatch.setenv(_capabilities.ENV_VAR, '["network:example.com"]')
        # Stub out the actual HTTP call so we don't hit the network.
        captured: dict[str, Any] = {}

        async def fake_request(self, **kwargs: Any) -> httpx.Response:  # type: ignore[no-untyped-def]
            captured.update(kwargs)
            return httpx.Response(204, request=httpx.Request("GET", kwargs["url"]))

        monkeypatch.setattr(httpx.AsyncClient, "request", fake_request)

        with caplog.at_level(logging.INFO, logger="synax_sdk.runtime.network"):
            response = await network.http_get("https://example.com/x")

        assert response.status_code == 204
        # The stub got called — meaning we used the direct-httpx path.
        assert captured["method"] == "GET"
        # The audit log fired through stdlib.
        records = [r for r in caplog.records if r.name == "synax_sdk.runtime.network"]
        assert len(records) == 1
        assert records[0].message == "HTTP request"
