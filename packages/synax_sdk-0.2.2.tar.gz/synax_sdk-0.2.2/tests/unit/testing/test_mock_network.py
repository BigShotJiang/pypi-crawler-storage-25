"""Tests for ``MockPlatform.network`` and ``MockBackend.http_request``."""

from __future__ import annotations

import asyncio

import httpx
import pytest

from synax_sdk.testing import MockPlatform


class TestRespondTo:
    """Stub registration covers the body-shape, headers, and status variants."""

    def test_json_response(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to(
            "https://api.example.com/v1/items",
            method="GET",
            status=200,
            json={"items": ["a", "b"]},
        )

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://api.example.com/v1/items",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        response = asyncio.run(go())
        assert response.status_code == 200
        assert response.json() == {"items": ["a", "b"]}

    def test_text_response(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://example.com/", status=200, text="hello world")

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://example.com/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        response = asyncio.run(go())
        assert response.text == "hello world"

    def test_status_only(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://example.com/missing", status=404)

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://example.com/missing",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        response = asyncio.run(go())
        assert response.status_code == 404
        assert response.text == ""

    def test_headers_returned(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to(
            "https://example.com/",
            text="ok",
            headers={"X-Custom": "yes"},
        )

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://example.com/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        response = asyncio.run(go())
        assert response.headers["x-custom"] == "yes"

    def test_re_registration_overwrites(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://x/", status=200, text="first")
        mock.network.respond_to("https://x/", status=500, text="second")

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://x/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        response = asyncio.run(go())
        assert response.status_code == 500
        assert response.text == "second"

    def test_json_and_text_together_rejected(self) -> None:
        mock = MockPlatform()
        with pytest.raises(ValueError, match="json or text, not both"):
            mock.network.respond_to("https://example.com/", json={"a": 1}, text="oops")

    def test_method_is_part_of_key(self) -> None:
        """GET and POST stubs for the same URL are independent."""
        mock = MockPlatform()
        mock.network.respond_to("https://x/", method="GET", text="get")
        mock.network.respond_to("https://x/", method="POST", text="post")

        async def get_one(method: str) -> str:
            r = await mock.backend.http_request(
                method=method,
                url="https://x/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )
            return r.text

        assert asyncio.run(get_one("GET")) == "get"
        assert asyncio.run(get_one("POST")) == "post"


class TestRaisesPath:
    """A registered exception is raised in place of returning a response."""

    def test_timeout_simulation(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to(
            "https://slow.example.com/",
            raises=httpx.TimeoutException("Request timed out"),
        )

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://slow.example.com/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        with pytest.raises(httpx.TimeoutException, match="timed out"):
            asyncio.run(go())

    def test_connect_error_simulation(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://unreachable/", raises=httpx.ConnectError("nope"))

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://unreachable/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        with pytest.raises(httpx.ConnectError):
            asyncio.run(go())


class TestUnexpectedRequest:
    """An unregistered (method, url) raises AssertionError with a hint."""

    def test_unregistered_url(self) -> None:
        mock = MockPlatform()

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="GET",
                url="https://example.com/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        with pytest.raises(AssertionError, match="Unexpected HTTP request"):
            asyncio.run(go())

    def test_mismatched_method(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://x/", method="GET", text="ok")

        async def go() -> httpx.Response:
            return await mock.backend.http_request(
                method="POST",
                url="https://x/",
                headers=None,
                json=None,
                content=None,
                timeout=30.0,
            )

        with pytest.raises(AssertionError, match="POST https://x/"):
            asyncio.run(go())


class TestRequestCapture:
    """mock.network.requests is the audit log of what the skill sent out."""

    def test_records_method_url_and_payload(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://api.example.com/", method="POST", json={})

        async def go() -> None:
            await mock.backend.http_request(
                method="POST",
                url="https://api.example.com/",
                headers={"X-Auth": "tok"},
                json={"a": 1},
                content=None,
                timeout=10.0,
            )

        asyncio.run(go())
        records = mock.network.requests
        assert len(records) == 1
        assert records[0].method == "POST"
        assert records[0].url == "https://api.example.com/"
        assert records[0].headers == {"X-Auth": "tok"}
        assert records[0].json == {"a": 1}
        assert records[0].timeout == 10.0

    def test_multiple_requests_preserved_in_order(self) -> None:
        mock = MockPlatform()
        mock.network.respond_to("https://a/", text="A")
        mock.network.respond_to("https://b/", text="B")

        async def go() -> None:
            await mock.backend.http_request(
                method="GET",
                url="https://a/",
                headers=None,
                json=None,
                content=None,
                timeout=5.0,
            )
            await mock.backend.http_request(
                method="GET",
                url="https://b/",
                headers=None,
                json=None,
                content=None,
                timeout=5.0,
            )

        asyncio.run(go())
        urls = [r.url for r in mock.network.requests]
        assert urls == ["https://a/", "https://b/"]


class TestMockCapabilities:
    """``mock.capabilities`` set / add / current behave as documented."""

    def test_set_replaces(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:x"])
        mock.capabilities.set(["network:y", "network:z"])
        assert mock.capabilities.current == frozenset({"network:y", "network:z"})

    def test_add_extends(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set(["network:a"])
        mock.capabilities.add("network:b")
        assert mock.capabilities.current == frozenset({"network:a", "network:b"})

    def test_current_defaults_to_empty(self) -> None:
        mock = MockPlatform()
        assert mock.capabilities.current == frozenset()

    def test_accepts_iterables_other_than_list(self) -> None:
        mock = MockPlatform()
        mock.capabilities.set({"network:x", "network:y"})  # set, not list
        assert mock.capabilities.current == frozenset({"network:x", "network:y"})
