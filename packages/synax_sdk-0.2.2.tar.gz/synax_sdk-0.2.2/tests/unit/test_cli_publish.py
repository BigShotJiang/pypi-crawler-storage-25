"""CLI tests for ``synax skill publish`` and ``synax keys register``."""

from __future__ import annotations

import base64
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from synax_sdk.publishing import KEY_REGISTER_PATH, PUBLISH_PATH
from synax_sdk.signing import KeyStore, generate_keypair
from synax_skill_cli.commands import keys as keys_module
from synax_skill_cli.main import app

runner = CliRunner()


def _flat(text: str) -> str:
    return " ".join(text.split())


TARGET = "https://synax.example.com"
PUBLISH_URL = TARGET + PUBLISH_PATH
KEYS_URL = TARGET + KEY_REGISTER_PATH
PUBLISH_TOKEN = "spt_test_token"

PYPROJECT = """\
[project]
name = "demo"
version = "0.0.0"

[tool.synax]
entry_point = "demo_skill:skill"
"""

SKILL_SRC = """\
from synax_sdk import Skill

skill = Skill(
    name="publish-demo",
    version="0.1.0",
    description="demo for publish tests",
)

@skill.tool(description="Echo")
def echo(text: str) -> str:
    \"\"\"Echo.

    Args:
        text: in.
    \"\"\"
    return text
"""


@pytest.fixture
def project_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "demo_skill.py").write_text(SKILL_SRC, encoding="utf-8")
    monkeypatch.chdir(root)
    return root


@pytest.fixture
def store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> KeyStore:
    s = KeyStore(root=tmp_path / "keys")
    s.save(generate_keypair())
    monkeypatch.setattr(keys_module, "_store", lambda: s)
    monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: s))
    return s


@pytest.fixture
def env_token(monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("SYNAX_PUBLISH_TOKEN", PUBLISH_TOKEN)
    return PUBLISH_TOKEN


@pytest.fixture
def isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Point user config at an empty file so real config doesn't leak in."""
    monkeypatch.setattr(
        "synax_skill_cli.utils.config.USER_CONFIG_PATH",
        tmp_path / "nope.yaml",
    )


def _success_body(**overrides: object) -> dict[str, object]:
    body: dict[str, object] = {
        "skill_id": "11111111-2222-3333-4444-555555555555",
        "skill_version_id": "66666666-7777-8888-9999-000000000000",
        "status": "registered",
        "marketplace_url": "https://synax.example.com/marketplace/skills/demo",
    }
    body.update(overrides)
    return body


# ---------------------------------------------------------------------------
# skill publish — happy paths
# ---------------------------------------------------------------------------
class TestSkillPublishHappy:
    @respx.mock
    def test_build_then_publish(
        self, project_dir: Path, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
        assert result.exit_code == 0, result.stdout
        flat = _flat(result.stdout)
        assert "building:" in flat
        assert "Published" in flat
        assert "registered" in flat
        assert "marketplace" in flat or "https://" in flat

    @respx.mock
    def test_no_build_uses_existing_bundle(
        self, project_dir: Path, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        # First do a build so a bundle exists, then re-publish with --no-build.
        runner.invoke(app, ["skill", "build"])
        result = runner.invoke(app, ["skill", "publish", "--target", TARGET, "--no-build"])
        assert result.exit_code == 0, result.stdout
        # building: should NOT appear because we passed --no-build
        assert "building:" not in _flat(result.stdout)

    @respx.mock
    def test_explicit_token_used(
        self, project_dir: Path, store: KeyStore, isolated_config: None
    ) -> None:
        route = respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=_success_body()))
        result = runner.invoke(
            app,
            ["skill", "publish", "--target", TARGET, "--token", "explicit-tok"],
        )
        assert result.exit_code == 0, result.stdout
        assert route.calls.last.request.headers["Authorization"] == "Bearer explicit-tok"


# ---------------------------------------------------------------------------
# skill publish — failure modes
# ---------------------------------------------------------------------------
class TestSkillPublishErrors:
    def test_missing_target(
        self,
        project_dir: Path,
        store: KeyStore,
        env_token: str,
        isolated_config: None,
    ) -> None:
        result = runner.invoke(app, ["skill", "publish"])
        assert result.exit_code == 1
        assert "No target URL" in _flat(result.stdout)

    def test_missing_token(self, project_dir: Path, store: KeyStore, isolated_config: None) -> None:
        # No env token, no config — just target.
        result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
        assert result.exit_code == 1
        assert "No publish token" in _flat(result.stdout)

    def test_no_build_with_missing_bundle(
        self, project_dir: Path, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        result = runner.invoke(app, ["skill", "publish", "--target", TARGET, "--no-build"])
        assert result.exit_code == 1
        assert "No build bundle" in _flat(result.stdout)

    @respx.mock
    def test_platform_auth_failure(
        self, project_dir: Path, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(401, json={"message": "bad token"})
        )
        result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
        assert result.exit_code == 1
        assert "Authentication failed" in _flat(result.stdout)

    @respx.mock
    def test_platform_version_conflict(
        self, project_dir: Path, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        respx.post(PUBLISH_URL).mock(
            return_value=httpx.Response(
                409,
                json={"message": "already published", "details": {"existing_version_id": "x"}},
            )
        )
        result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
        assert result.exit_code == 1
        assert "already published" in _flat(result.stdout)


# ---------------------------------------------------------------------------
# keys register
# ---------------------------------------------------------------------------
class TestKeysRegister:
    @respx.mock
    def test_happy_path(self, store: KeyStore, env_token: str, isolated_config: None) -> None:
        respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "reg-42", "status": "pending_approval"}
            )
        )
        result = runner.invoke(
            app,
            ["keys", "register", "--target", TARGET, "--namespace", "acme"],
        )
        assert result.exit_code == 0, result.stdout
        flat = _flat(result.stdout)
        assert "Registered key" in flat
        assert "reg-42" in flat
        assert "pending_approval" in flat

    @respx.mock
    def test_sends_expected_body(
        self, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        route = respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "x", "status": "pending_approval"}
            )
        )
        runner.invoke(
            app,
            ["keys", "register", "--target", TARGET, "--namespace", "acme"],
        )
        import json as _json

        body = _json.loads(route.calls.last.request.content)
        assert body["namespace"] == "acme"
        # public_key_b64 is base64; just check decodability
        base64.b64decode(body["public_key_b64"], validate=True)
        assert body["fingerprint"].startswith("sha256:")

    def test_missing_target(self, store: KeyStore, env_token: str, isolated_config: None) -> None:
        result = runner.invoke(app, ["keys", "register", "--namespace", "acme"])
        assert result.exit_code == 1
        assert "No target URL" in _flat(result.stdout)

    def test_missing_token(self, store: KeyStore, isolated_config: None) -> None:
        result = runner.invoke(app, ["keys", "register", "--target", TARGET, "--namespace", "acme"])
        assert result.exit_code == 1
        assert "No publish token" in _flat(result.stdout)

    def test_no_key_no_default(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        env_token: str,
        isolated_config: None,
    ) -> None:
        empty_store = KeyStore(root=tmp_path / "empty")
        monkeypatch.setattr(keys_module, "_store", lambda: empty_store)
        result = runner.invoke(app, ["keys", "register", "--target", TARGET, "--namespace", "acme"])
        assert result.exit_code == 1
        assert "No key fingerprint" in _flat(result.stdout)

    @respx.mock
    def test_unknown_key_fingerprint(
        self, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        result = runner.invoke(
            app,
            [
                "keys",
                "register",
                "--target",
                TARGET,
                "--namespace",
                "acme",
                "--key",
                "sha256:" + "0" * 64,
            ],
        )
        assert result.exit_code == 1
        assert "No key matching" in _flat(result.stdout)

    @respx.mock
    def test_platform_returns_error(
        self, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        respx.post(KEYS_URL).mock(return_value=httpx.Response(401, json={"message": "bad token"}))
        result = runner.invoke(app, ["keys", "register", "--target", TARGET, "--namespace", "acme"])
        assert result.exit_code == 1
        assert "Authentication failed" in _flat(result.stdout)

    @respx.mock
    def test_register_with_label_forwards_to_platform(
        self, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        route = respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "reg-l", "status": "pending_approval"}
            )
        )
        result = runner.invoke(
            app,
            [
                "keys",
                "register",
                "--target",
                TARGET,
                "--namespace",
                "acme",
                "--label",
                "CI key",
            ],
        )
        assert result.exit_code == 0, result.stdout
        import json as _json

        body = _json.loads(route.calls.last.request.content)
        assert body["label"] == "CI key"
        assert body["namespace"] == "acme"

    @respx.mock
    def test_register_with_public_key_file(
        self,
        store: KeyStore,
        env_token: str,
        isolated_config: None,
        tmp_path: Path,
    ) -> None:
        """A key not in the local store can still be registered via --public-key-file."""
        from synax_sdk.signing import generate_keypair, save_public_key_to_file

        external_kp = generate_keypair()
        pub_path = tmp_path / "external.pub"
        save_public_key_to_file(external_kp, pub_path)

        route = respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "reg-f", "status": "pending_approval"}
            )
        )
        result = runner.invoke(
            app,
            [
                "keys",
                "register",
                "--target",
                TARGET,
                "--namespace",
                "acme",
                "--public-key-file",
                str(pub_path),
            ],
        )
        assert result.exit_code == 0, result.stdout
        import json as _json

        body = _json.loads(route.calls.last.request.content)
        # The registered fingerprint is the one from the file, not the local store's default.
        assert body["fingerprint"] == external_kp.fingerprint
        # The external key is NOT in the local store.
        assert external_kp.fingerprint not in store.list_fingerprints()

    def test_register_key_and_public_key_file_are_mutually_exclusive(
        self,
        store: KeyStore,
        env_token: str,
        isolated_config: None,
        tmp_path: Path,
    ) -> None:
        from synax_sdk.signing import generate_keypair, save_public_key_to_file

        kp = generate_keypair()
        pub_path = tmp_path / "k.pub"
        save_public_key_to_file(kp, pub_path)
        result = runner.invoke(
            app,
            [
                "keys",
                "register",
                "--target",
                TARGET,
                "--namespace",
                "acme",
                "--key",
                kp.fingerprint,
                "--public-key-file",
                str(pub_path),
            ],
        )
        assert result.exit_code == 1
        assert "mutually exclusive" in _flat(result.stdout)

    @respx.mock
    def test_quiet_prints_only_registration_id(
        self, store: KeyStore, env_token: str, isolated_config: None
    ) -> None:
        respx.post(KEYS_URL).mock(
            return_value=httpx.Response(
                200, json={"registration_id": "reg-q", "status": "pending_approval"}
            )
        )
        result = runner.invoke(
            app,
            ["--quiet", "keys", "register", "--target", TARGET, "--namespace", "acme"],
        )
        assert result.exit_code == 0, result.stdout
        assert result.stdout.strip() == "reg-q"
