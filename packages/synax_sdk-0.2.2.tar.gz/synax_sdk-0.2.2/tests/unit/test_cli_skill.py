"""CLI tests for the ``synax skill`` subcommands (validate, build, info, verify)."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from synax_sdk.signing import KeyStore, generate_keypair
from synax_skill_cli.commands import keys as keys_module
from synax_skill_cli.main import app

runner = CliRunner()


def _flat(text: str) -> str:
    """Collapse all whitespace runs to single spaces.

    Rich wraps output to the host terminal width; on Linux runners the tmp
    paths are long and wrapping splits short phrases like "no signatures"
    across newlines. Substring-matching against the flattened output is
    independent of wrap behaviour.
    """
    return " ".join(text.split())


PYPROJECT = """\
[project]
name = "demo"
version = "0.0.0"

[tool.synax]
entry_point = "demo_skill:skill"
"""

SKILL_SRC = """\
from synax_sdk import Skill

skill = Skill(
    name="demo-skill",
    version="0.1.0",
    description="A demo",
    capabilities=["secrets:GREETING"],
    secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
)

@skill.tool(description="Greet someone")
def greet(name: str) -> str:
    \"\"\"Greet.

    Args:
        name: who.
    \"\"\"
    return f"hello, {name}"
"""


@pytest.fixture
def project_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """A skill project on disk + cwd pointed at it so find_project_root() works."""
    root = tmp_path / "proj"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "demo_skill.py").write_text(SKILL_SRC, encoding="utf-8")
    monkeypatch.chdir(root)
    return root


@pytest.fixture
def store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> KeyStore:
    """Test keystore + patch the default in every CLI module that consults it."""
    s = KeyStore(root=tmp_path / "keys")
    s.save(generate_keypair())
    monkeypatch.setattr(keys_module, "_store", lambda: s)
    monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: s))
    return s


# ---------------------------------------------------------------------------
# skill validate
# ---------------------------------------------------------------------------
class TestSkillValidate:
    def test_valid_skill_passes(self, project_dir: Path) -> None:
        result = runner.invoke(app, ["skill", "validate"])
        assert result.exit_code == 0
        assert "Validation passed" in _flat(result.stdout)

    def test_no_project_fails(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["skill", "validate"])
        assert result.exit_code == 1
        assert "No skill project found" in _flat(result.stdout)

    def test_invalid_skill_reports_errors(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        bad_root = tmp_path / "bad"
        bad_root.mkdir()
        (bad_root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
        # A skill with no tools fails the schema's minItems=1 requirement.
        (bad_root / "demo_skill.py").write_text(
            "from synax_sdk import Skill\n"
            "skill = Skill(name='x', version='1.0.0', description='x')\n",
            encoding="utf-8",
        )
        monkeypatch.chdir(bad_root)
        result = runner.invoke(app, ["skill", "validate"])
        assert result.exit_code == 1
        assert "Validation failed" in _flat(result.stdout)


# ---------------------------------------------------------------------------
# skill build
# ---------------------------------------------------------------------------
class TestSkillBuild:
    def test_happy_build(self, project_dir: Path, store: KeyStore) -> None:
        result = runner.invoke(app, ["skill", "build"])
        assert result.exit_code == 0, result.stdout
        assert "Built" in result.stdout
        bundle = project_dir / "build" / "signed_bundle"
        assert (bundle / "manifest.yaml").exists()
        assert (bundle / "implementation.tar.gz").exists()

    def test_build_with_explicit_key(self, project_dir: Path, store: KeyStore) -> None:
        fp = store.default_fingerprint
        assert fp is not None
        result = runner.invoke(app, ["skill", "build", "--key", fp])
        assert result.exit_code == 0
        assert fp in result.stdout

    def test_build_writes_to_custom_output(
        self, project_dir: Path, store: KeyStore, tmp_path: Path
    ) -> None:
        out = tmp_path / "elsewhere"
        result = runner.invoke(app, ["skill", "build", "--output", str(out)])
        assert result.exit_code == 0
        assert (out / "signed_bundle" / "manifest.yaml").exists()

    def test_build_without_key_fails(
        self, project_dir: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        empty = KeyStore(root=tmp_path / "empty_keys")
        monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: empty))
        result = runner.invoke(app, ["skill", "build"])
        assert result.exit_code == 1
        assert "No signing key" in _flat(result.stdout)


# ---------------------------------------------------------------------------
# skill info
# ---------------------------------------------------------------------------
class TestSkillInfo:
    def test_shows_fields(self, project_dir: Path) -> None:
        result = runner.invoke(app, ["skill", "info"])
        assert result.exit_code == 0
        assert "demo-skill" in result.stdout
        assert "v0.1.0" in result.stdout
        # Tool name should be present (rich may wrap; check prefix)
        assert "greet" in result.stdout
        assert "secrets:GREETING" in result.stdout

    def test_info_without_project_fails(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["skill", "info"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# skill verify
# ---------------------------------------------------------------------------
class TestSkillVerify:
    def test_verifies_built_manifest(self, project_dir: Path, store: KeyStore) -> None:
        # Build first to produce a signed manifest.
        runner.invoke(app, ["skill", "build"])
        manifest_path = project_dir / "build" / "signed_bundle" / "manifest.yaml"
        result = runner.invoke(app, ["skill", "verify", str(manifest_path)])
        assert result.exit_code == 0, result.stdout
        assert "verified" in result.stdout

    def test_missing_file_fails(self, project_dir: Path) -> None:
        result = runner.invoke(app, ["skill", "verify", "nonexistent.yaml"])
        assert result.exit_code == 1
        assert "not found" in result.stdout

    def test_manifest_without_signatures_fails(self, project_dir: Path, tmp_path: Path) -> None:
        manifest = tmp_path / "m.yaml"
        manifest.write_text(yaml.safe_dump({"name": "x", "signatures": []}), encoding="utf-8")
        result = runner.invoke(app, ["skill", "verify", str(manifest)])
        assert result.exit_code == 1
        # rich may wrap the message across newlines depending on the tmp_path
        # length on the host — collapse whitespace before substring-checking.
        assert "no signatures" in _flat(result.stdout)

    def test_tampered_manifest_fails(self, project_dir: Path, store: KeyStore) -> None:
        runner.invoke(app, ["skill", "build"])
        manifest_path = project_dir / "build" / "signed_bundle" / "manifest.yaml"
        data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
        # Modify a field that's part of the canonical form
        data["description"] = "TAMPERED"
        manifest_path.write_text(yaml.safe_dump(data), encoding="utf-8")
        result = runner.invoke(app, ["skill", "verify", str(manifest_path)])
        assert result.exit_code == 1
        assert "does not verify" in _flat(result.stdout)


# ---------------------------------------------------------------------------
# Top-level CLI still works
# ---------------------------------------------------------------------------
class TestCliRoot:
    def test_help_lists_real_subcommand_groups(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        # Sanity: all three groups present
        assert "skill" in result.stdout
        assert "keys" in result.stdout

    def test_skill_help_lists_real_commands(self) -> None:
        result = runner.invoke(app, ["skill", "--help"])
        assert result.exit_code == 0
        for name in ("validate", "build", "info", "verify"):
            assert name in result.stdout

    def test_keys_help_lists_real_commands(self) -> None:
        result = runner.invoke(app, ["keys", "--help"])
        assert result.exit_code == 0
        for name in ("generate", "list", "export", "import", "set-default"):
            assert name in result.stdout
