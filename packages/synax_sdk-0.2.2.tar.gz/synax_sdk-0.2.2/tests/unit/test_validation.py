"""Tests for ``synax_sdk.validation`` and the vendored JSON Schema."""

from __future__ import annotations

import pytest

from synax_sdk.manifest import (
    Implementation,
    Manifest,
    ManifestMetadata,
    SecretManifest,
    Signature,
    ToolManifest,
)
from synax_sdk.schema import CURRENT_SCHEMA_VERSION, load_manifest_schema
from synax_sdk.skill import Skill
from synax_sdk.validation import ValidationError, validate_manifest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _valid_skill() -> Skill:
    """A skill that passes validation cleanly."""
    skill = Skill(
        name="hello-world",
        version="1.0.0",
        description="A trivial skill",
        capabilities=["secrets:GREETING"],
        secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
    )

    @skill.tool(description="Say hello")
    async def greet(name: str) -> str:
        """Greet.

        Args:
            name: who.
        """
        return f"Hello, {name}"

    return skill


def _has_error_for(field: str, errors: list[ValidationError]) -> bool:
    return any(field in e.field for e in errors)


# ---------------------------------------------------------------------------
# Schema loader
# ---------------------------------------------------------------------------
class TestSchemaLoader:
    def test_loads_default_version(self) -> None:
        schema = load_manifest_schema()
        assert schema["$id"].endswith("v1_0")
        assert "schema_version" in schema["required"]

    def test_explicit_version(self) -> None:
        schema = load_manifest_schema("1.0")
        assert schema["title"].startswith("Synax Skill Manifest")

    def test_unknown_version_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            load_manifest_schema("99.0")

    def test_current_version_constant(self) -> None:
        assert CURRENT_SCHEMA_VERSION == "1.0"


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------
class TestValidPathway:
    def test_simple_skill_validates_clean(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        errors = validate_manifest(manifest)
        # No errors. (Warnings would have kind="warning", but this skill triggers none.)
        assert errors == [], errors

    def test_skill_without_secrets_is_fine(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x")

        @skill.tool(description="t")
        def t() -> None:
            """T."""

        errors = validate_manifest(Manifest.from_skill(skill))
        assert errors == []


# ---------------------------------------------------------------------------
# JSON Schema layer
# ---------------------------------------------------------------------------
class TestSchemaLayer:
    def test_no_tools_rejected(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x")
        manifest = Manifest.from_skill(skill)
        errors = validate_manifest(manifest)
        assert _has_error_for("tools", errors)

    def test_bad_hash_format_rejected(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        manifest.implementation.hash = "not-a-real-hash"
        errors = validate_manifest(manifest)
        assert any("hash" in e.field for e in errors)

    def test_valid_hash_format_accepted(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        manifest.implementation.hash = "sha256:" + "a" * 64
        errors = validate_manifest(manifest)
        assert errors == []

    def test_too_long_description_rejected(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        # bypass dataclass validation by mutating directly
        manifest.description = "x" * 300
        errors = validate_manifest(manifest)
        assert any("description" in e.field for e in errors)

    def test_signature_with_bad_fingerprint(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        manifest.signatures.append(
            Signature(
                key_fingerprint="not-sha256",
                signer_type="author",
                signature="abc",
                signed_at="2026-05-15T00:00:00Z",
            )
        )
        errors = validate_manifest(manifest)
        assert any("signatures" in e.field and "fingerprint" in e.field for e in errors)

    def test_bad_secret_type_rejected_by_schema(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        # Mutate secret type directly (bypass Skill validation)
        bad = SecretManifest(name="GREETING", type="weird_type", description="d")
        manifest.secrets = [bad]
        errors = validate_manifest(manifest)
        assert any("secrets" in e.field for e in errors)

    def test_capabilities_uniqueness_enforced(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        manifest.capabilities = ["secrets:A", "secrets:A"]
        # update secrets to match capability A
        manifest.secrets = [SecretManifest(name="A", type="api_key", description="x")]
        errors = validate_manifest(manifest)
        assert any("capabilities" in e.field for e in errors)


# ---------------------------------------------------------------------------
# Consistency layer
# ---------------------------------------------------------------------------
class TestConsistencyLayer:
    def test_secret_without_capability_flagged(self) -> None:
        skill = _valid_skill()
        manifest = Manifest.from_skill(skill)
        # Drop the matching capability while keeping the secret
        manifest.capabilities = []
        errors = validate_manifest(manifest)
        consistency_errors = [e for e in errors if e.kind == "consistency"]
        assert any("GREETING" in e.message for e in consistency_errors)
        assert any(e.suggestion and "secrets:GREETING" in e.suggestion for e in consistency_errors)

    def test_daemon_only_without_local_caps_emits_warning(self) -> None:
        skill = Skill(
            name="d",
            version="1.0.0",
            description="d",
            capabilities=["network:api.example.com"],
            execution_location="daemon_only",
        )

        @skill.tool(description="t")
        def t() -> None:
            """T."""

        errors = validate_manifest(Manifest.from_skill(skill))
        warnings = [e for e in errors if e.kind == "warning"]
        assert any(w.field == "execution_location" for w in warnings)

    def test_daemon_only_with_filesystem_no_warning(self) -> None:
        skill = Skill(
            name="d",
            version="1.0.0",
            description="d",
            capabilities=["filesystem:read:/data"],
            execution_location="daemon_only",
        )

        @skill.tool(description="t")
        def t() -> None:
            """T."""

        errors = validate_manifest(Manifest.from_skill(skill))
        warnings = [e for e in errors if e.kind == "warning"]
        assert all(w.field != "execution_location" for w in warnings)

    def test_daemon_only_with_localhost_network_no_warning(self) -> None:
        skill = Skill(
            name="d",
            version="1.0.0",
            description="d",
            capabilities=["network:localhost"],
            execution_location="daemon_only",
        )

        @skill.tool(description="t")
        def t() -> None:
            """T."""

        errors = validate_manifest(Manifest.from_skill(skill))
        warnings = [e for e in errors if e.kind == "warning"]
        assert all(w.field != "execution_location" for w in warnings)

    def test_non_daemon_location_no_local_warning(self) -> None:
        """A skill with execution_location='either' shouldn't get the local-cap warning."""
        skill = _valid_skill()
        errors = validate_manifest(Manifest.from_skill(skill))
        warnings = [e for e in errors if e.kind == "warning"]
        assert warnings == []


# ---------------------------------------------------------------------------
# ValidationError shape
# ---------------------------------------------------------------------------
class TestValidationErrorShape:
    def test_default_kind_is_schema(self) -> None:
        err = ValidationError(field="x", message="y")
        assert err.kind == "schema"

    def test_explicit_kind(self) -> None:
        err = ValidationError(field="x", message="y", kind="warning")
        assert err.kind == "warning"

    def test_suggestion_optional(self) -> None:
        err = ValidationError(field="x", message="y", suggestion="z")
        assert err.suggestion == "z"

    def test_frozen(self) -> None:
        import dataclasses

        err = ValidationError(field="x", message="y")
        with pytest.raises(dataclasses.FrozenInstanceError):
            err.field = "new"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Full-manifest examples (build_plan-style fixtures)
# ---------------------------------------------------------------------------
class TestRealisticManifests:
    def test_complete_signed_manifest_validates(self) -> None:
        """A full manifest matching the manifest_spec.md Complete Example."""
        manifest = Manifest(
            schema_version="1.0",
            name="github-pr-summary",
            version="1.2.3",
            display_name="GitHub PR Summary",
            description="Fetch and summarize GitHub pull requests",
            implementation=Implementation(
                type="python_code",
                entry_point="github_pr_summary:skill",
                hash="sha256:" + "e" * 64,
                runtime_requirements={"python": ">=3.11"},
            ),
            tools=[
                ToolManifest(
                    name="summarize_pr",
                    description="Fetch a GitHub PR.",
                    parameters={
                        "type": "object",
                        "properties": {
                            "repo": {"type": "string"},
                            "pr_number": {"type": "integer"},
                        },
                        "required": ["repo", "pr_number"],
                    },
                )
            ],
            capabilities=["network:api.github.com", "secrets:GITHUB_TOKEN"],
            secrets=[
                SecretManifest(
                    name="GITHUB_TOKEN",
                    type="oauth_token",
                    description="GitHub OAuth.",
                    scope_required="repo:read",
                )
            ],
            dependencies=[],
            metadata=ManifestMetadata(category="developer_tools", license="Apache-2.0"),
            signatures=[
                Signature(
                    key_fingerprint="sha256:" + "1" * 64,
                    signer_type="author",
                    signature="abcdef==",
                    signed_at="2026-05-14T10:00:00Z",
                )
            ],
        )
        errors = validate_manifest(manifest)
        assert errors == [], errors

    def test_returns_multiple_errors_at_once(self) -> None:
        """The validator yields every error, not just the first."""
        # Construct a manifest with multiple issues bypassing Skill validation
        manifest = Manifest(
            schema_version="1.0",
            name="x",
            version="not-semver",
            display_name="X",
            description="x",
            implementation=Implementation(type="python_code"),
            tools=[],  # 0 tools — schema requires ≥1
        )
        errors = validate_manifest(manifest)
        # Expect at least: version pattern + empty tools array
        fields_seen = {e.field for e in errors}
        assert "version" in fields_seen
        assert any("tools" in f for f in fields_seen)
