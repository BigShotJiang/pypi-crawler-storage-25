"""Tests for ``synax_sdk.manifest`` — dataclasses, from_skill, and serialization."""

import json

import pytest
import yaml

from synax_sdk.manifest import (
    SCHEMA_VERSION,
    DependencyManifest,
    Implementation,
    Manifest,
    ManifestMetadata,
    SecretManifest,
    Signature,
    ToolManifest,
    _filter_dataclass,
)
from synax_sdk.skill import Secret, Skill, SkillDependency, SkillMetadata
from synax_sdk.version import __version__ as _sdk_version

SDK_VERSION = _sdk_version


# ---------------------------------------------------------------------------
# Shared skill fixture
# ---------------------------------------------------------------------------
@pytest.fixture
def hello_skill() -> Skill:
    """A representative skill used across serialization tests."""
    skill = Skill(
        name="hello-world",
        version="1.0.0",
        description="A trivial greeting skill",
        capabilities=["secrets:GREETING"],
        secrets=[
            {
                "name": "GREETING",
                "type": "generic_string",
                "description": "The greeting word.",
            }
        ],
        metadata={"category": "demo", "tags": ["test"], "license": "Apache-2.0"},
    )

    @skill.tool(description="Say hello")
    async def greet(name: str) -> str:
        """Greet someone.

        Args:
            name: Who to greet.
        """
        return f"hello, {name}"

    return skill


# ---------------------------------------------------------------------------
# Manifest.from_skill
# ---------------------------------------------------------------------------
class TestFromSkill:
    def test_basic_fields(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill)
        assert manifest.schema_version == SCHEMA_VERSION == "1.0"
        assert manifest.name == "hello-world"
        assert manifest.version == "1.0.0"
        assert manifest.display_name == "Hello World"
        assert manifest.description == "A trivial greeting skill"
        assert manifest.namespace is None

    def test_implementation_placeholder(self, hello_skill: Skill) -> None:
        """At Milestone 2 from_skill leaves entry_point + hash unset."""
        manifest = Manifest.from_skill(hello_skill)
        assert manifest.implementation.type == "python_code"
        assert manifest.implementation.entry_point is None
        assert manifest.implementation.hash is None

    def test_tools_translated(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill)
        assert len(manifest.tools) == 1
        assert manifest.tools[0].name == "greet"
        assert manifest.tools[0].description == "Say hello"
        assert manifest.tools[0].parameters["type"] == "object"
        assert manifest.tools[0].parameters["required"] == ["name"]
        assert manifest.tools[0].returns == {"type": "string"}

    def test_secrets_translated(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill)
        assert len(manifest.secrets) == 1
        assert manifest.secrets[0].name == "GREETING"
        assert manifest.secrets[0].type == "generic_string"

    def test_capabilities_copied(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill)
        assert manifest.capabilities == ["secrets:GREETING"]

    def test_sdk_version_auto_populated(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill)
        assert manifest.metadata.sdk_version == SDK_VERSION

    def test_explicit_sdk_version_override(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill, sdk_version="9.9.9")
        assert manifest.metadata.sdk_version == "9.9.9"

    def test_metadata_translated(self, hello_skill: Skill) -> None:
        manifest = Manifest.from_skill(hello_skill)
        assert manifest.metadata.category == "demo"
        assert manifest.metadata.tags == ["test"]
        assert manifest.metadata.license == "Apache-2.0"

    def test_namespace_carried(self) -> None:
        skill = Skill(
            name="x",
            version="1.0.0",
            description="x",
            namespace="acme",
        )
        manifest = Manifest.from_skill(skill)
        assert manifest.namespace == "acme"

    def test_empty_collections_initially_empty(self) -> None:
        """A skill with no capabilities / secrets / deps gets empty lists, not None."""
        skill = Skill(name="x", version="1.0.0", description="x")
        manifest = Manifest.from_skill(skill)
        assert manifest.capabilities == []
        assert manifest.secrets == []
        assert manifest.dependencies == []

    def test_dependencies_translated(self) -> None:
        skill = Skill(
            name="x",
            version="1.0.0",
            description="x",
            dependencies=[SkillDependency(skill="other", version=">=1.0.0")],
        )
        manifest = Manifest.from_skill(skill)
        assert manifest.dependencies == [DependencyManifest(skill="other", version=">=1.0.0")]


# ---------------------------------------------------------------------------
# to_dict — field omission rules
# ---------------------------------------------------------------------------
class TestToDict:
    def test_required_fields_always_present(self, hello_skill: Skill) -> None:
        d = Manifest.from_skill(hello_skill).to_dict()
        for required in (
            "schema_version",
            "name",
            "version",
            "display_name",
            "description",
            "implementation",
            "tools",
        ):
            assert required in d

    def test_namespace_omitted_when_none(self, hello_skill: Skill) -> None:
        assert "namespace" not in Manifest.from_skill(hello_skill).to_dict()

    def test_namespace_present_when_set(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x", namespace="acme")
        assert Manifest.from_skill(skill).to_dict()["namespace"] == "acme"

    def test_empty_capabilities_omitted(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x")
        assert "capabilities" not in Manifest.from_skill(skill).to_dict()

    def test_default_execution_location_omitted(self, hello_skill: Skill) -> None:
        assert "execution_location" not in Manifest.from_skill(hello_skill).to_dict()

    def test_non_default_execution_location_present(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x", execution_location="daemon_only")
        assert Manifest.from_skill(skill).to_dict()["execution_location"] == "daemon_only"

    def test_empty_signatures_omitted(self, hello_skill: Skill) -> None:
        assert "signatures" not in Manifest.from_skill(hello_skill).to_dict()

    def test_empty_metadata_omitted(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x")
        # sdk_version is auto-populated → metadata still has one field
        d = Manifest.from_skill(skill).to_dict()
        assert "metadata" in d
        assert d["metadata"] == {"sdk_version": SDK_VERSION}

    def test_metadata_omitted_when_truly_empty(self) -> None:
        """If sdk_version is also blanked, metadata block is omitted."""
        skill = Skill(name="x", version="1.0.0", description="x")
        manifest = Manifest.from_skill(skill, sdk_version="")
        manifest.metadata.sdk_version = None
        assert "metadata" not in manifest.to_dict()

    def test_field_order_matches_spec(self, hello_skill: Skill) -> None:
        """Spec ordering: schema_version, name, [namespace,] version, display_name, ..."""
        keys = list(Manifest.from_skill(hello_skill).to_dict().keys())
        # required prefix order:
        assert keys[:5] == ["schema_version", "name", "version", "display_name", "description"]
        assert keys.index("implementation") < keys.index("tools")
        assert keys.index("tools") < keys.index("capabilities")


# ---------------------------------------------------------------------------
# to_yaml
# ---------------------------------------------------------------------------
class TestToYaml:
    def test_round_trips_through_yaml(self, hello_skill: Skill) -> None:
        text = Manifest.from_skill(hello_skill).to_yaml()
        loaded = yaml.safe_load(text)
        assert loaded["name"] == "hello-world"
        assert loaded["version"] == "1.0.0"
        assert loaded["tools"][0]["name"] == "greet"

    def test_yaml_preserves_spec_order(self, hello_skill: Skill) -> None:
        """Top-level keys in the YAML should follow spec order, not alphabetical."""
        text = Manifest.from_skill(hello_skill).to_yaml()
        # Find first occurrence of each key as line-leading.
        positions = {
            key: text.find(f"\n{key}:" if i else f"{key}:")
            for i, key in enumerate(
                ["schema_version", "name", "version", "display_name", "description"]
            )
        }
        # All present
        assert all(v != -1 for v in positions.values())
        # In order
        ordered = sorted(positions, key=lambda k: positions[k])
        assert ordered == ["schema_version", "name", "version", "display_name", "description"]

    def test_yaml_no_python_object_tags(self, hello_skill: Skill) -> None:
        """safe_dump shouldn't emit python/object tags for our pure-data structure."""
        text = Manifest.from_skill(hello_skill).to_yaml()
        assert "!!python/" not in text


# ---------------------------------------------------------------------------
# to_json
# ---------------------------------------------------------------------------
class TestToJson:
    def test_valid_json(self, hello_skill: Skill) -> None:
        text = Manifest.from_skill(hello_skill).to_json()
        parsed = json.loads(text)
        assert parsed["name"] == "hello-world"

    def test_indent_none_compact(self, hello_skill: Skill) -> None:
        text = Manifest.from_skill(hello_skill).to_json(indent=None)
        assert "\n" not in text  # single line


# ---------------------------------------------------------------------------
# to_canonical_json — the bytes Ed25519 will sign
# ---------------------------------------------------------------------------
class TestCanonicalJson:
    def test_returns_bytes(self, hello_skill: Skill) -> None:
        canonical = Manifest.from_skill(hello_skill).to_canonical_json()
        assert isinstance(canonical, bytes)

    def test_signatures_excluded(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x")
        manifest = Manifest.from_skill(skill)
        manifest.signatures.append(
            Signature(
                key_fingerprint="abc",
                signer_type="author",
                signature="sig",
                signed_at="2026-05-15T00:00:00Z",
            )
        )
        canonical = manifest.to_canonical_json()
        assert b"signatures" not in canonical
        assert b"signature" not in canonical
        assert b"key_fingerprint" not in canonical

    def test_sorted_keys(self, hello_skill: Skill) -> None:
        canonical = Manifest.from_skill(hello_skill).to_canonical_json()
        text = canonical.decode("utf-8")
        # First top-level key is whichever sorts alphabetically first among
        # the present keys. With capabilities + description + display_name +
        # implementation + ..., "capabilities" wins.
        assert text.startswith('{"capabilities":')
        # Verify every level is sorted by parsing back and checking key order.
        parsed = json.loads(text)
        top_keys = list(parsed.keys())
        assert top_keys == sorted(top_keys)
        # Nested: implementation, tools[0], metadata
        assert list(parsed["implementation"].keys()) == sorted(parsed["implementation"].keys())
        assert list(parsed["tools"][0].keys()) == sorted(parsed["tools"][0].keys())
        assert list(parsed["metadata"].keys()) == sorted(parsed["metadata"].keys())

    def test_no_whitespace(self, hello_skill: Skill) -> None:
        canonical = Manifest.from_skill(hello_skill).to_canonical_json()
        text = canonical.decode("utf-8")
        # No multi-byte separator spaces from json.dumps default formatting.
        assert ": " not in text
        assert ", " not in text

    def test_deterministic(self, hello_skill: Skill) -> None:
        """Same skill, multiple calls → identical bytes."""
        m1 = Manifest.from_skill(hello_skill).to_canonical_json()
        m2 = Manifest.from_skill(hello_skill).to_canonical_json()
        assert m1 == m2

    def test_parses_as_valid_json(self, hello_skill: Skill) -> None:
        canonical = Manifest.from_skill(hello_skill).to_canonical_json()
        parsed = json.loads(canonical.decode("utf-8"))
        assert parsed["name"] == "hello-world"

    def test_unicode_preserved(self) -> None:
        skill = Skill(
            name="unicode-skill",
            version="1.0.0",
            description="contains unicode: café 中文 — ✓",
        )
        canonical = Manifest.from_skill(skill).to_canonical_json()
        # ensure_ascii=False means the bytes contain UTF-8 directly.
        assert "café".encode() in canonical


# ---------------------------------------------------------------------------
# ToolManifest / SecretManifest / DependencyManifest factories
# ---------------------------------------------------------------------------
class TestSubManifestFactories:
    def test_tool_manifest_from_tool(self) -> None:
        skill = Skill(name="x", version="1.0.0", description="x")

        @skill.tool(description="Add")
        def add(a: int, b: int) -> int:
            """Add two ints.

            Args:
                a: first.
                b: second.
            """
            return a + b

        tm = ToolManifest.from_tool(skill.tools[0])
        assert tm.name == "add"
        assert tm.description == "Add"
        assert tm.parameters["required"] == ["a", "b"]
        assert tm.returns == {"type": "integer"}

    def test_secret_manifest_from_secret(self) -> None:
        s = Secret(name="TOKEN", type="api_key", description="x", scope_required="r")
        sm = SecretManifest.from_secret(s)
        assert sm.name == "TOKEN"
        assert sm.scope_required == "r"

    def test_dependency_manifest_from_dep(self) -> None:
        dep = SkillDependency(skill="other", version="1.0.0")
        dm = DependencyManifest.from_dependency(dep)
        assert dm.skill == "other"
        assert dm.version == "1.0.0"

    def test_metadata_from_skill_metadata(self) -> None:
        sm = SkillMetadata(category="dev", tags=["a"], license="MIT")
        mm = ManifestMetadata.from_skill_metadata(sm, sdk_version="x")
        assert mm.category == "dev"
        assert mm.tags == ["a"]
        assert mm.license == "MIT"
        assert mm.sdk_version == "x"


# ---------------------------------------------------------------------------
# _filter_dataclass helper
# ---------------------------------------------------------------------------
class TestFilterDataclass:
    def test_filters_none_fields(self) -> None:
        impl = Implementation(type="python_code", entry_point=None, hash=None)
        assert _filter_dataclass(impl) == {"type": "python_code"}

    def test_keeps_set_fields(self) -> None:
        impl = Implementation(type="python_code", entry_point="x:y", hash="sha256:0" * 64)
        result = _filter_dataclass(impl)
        assert result["entry_point"] == "x:y"
        assert "hash" in result

    def test_filters_empty_list(self) -> None:
        meta = ManifestMetadata(category="x", tags=[])
        result = _filter_dataclass(meta)
        assert "tags" not in result
        assert result == {"category": "x"}

    def test_passes_through_opaque_dict(self) -> None:
        """JSON Schema payloads contain dicts; we don't filter inside them."""
        tm = ToolManifest(
            name="t", description="d", parameters={"type": "object", "properties": {}}
        )
        result = _filter_dataclass(tm)
        assert result["parameters"] == {"type": "object", "properties": {}}

    def test_recurses_into_lists(self) -> None:
        manifest = Manifest(
            schema_version="1.0",
            name="x",
            version="1.0.0",
            display_name="X",
            description="x",
            implementation=Implementation(),
            tools=[ToolManifest(name="t", description="d", parameters={})],
        )
        result = _filter_dataclass(manifest)
        assert isinstance(result, dict)
        assert result["tools"][0]["name"] == "t"
