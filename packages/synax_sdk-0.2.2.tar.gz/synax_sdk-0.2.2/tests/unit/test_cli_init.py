"""CLI tests for ``synax skill init``."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest
from typer.testing import CliRunner

from synax_skill_cli.main import app

runner = CliRunner()


def _flat(text: str) -> str:
    return " ".join(text.split())


@pytest.fixture
def isolated_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Move cwd to a tmp directory so default-target paths are predictable."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def no_git(monkeypatch: pytest.MonkeyPatch) -> None:
    """Force git lookups to fail so tests don't depend on git config."""
    monkeypatch.setattr(
        "synax_skill_cli.commands.skill._git_user_name",
        lambda: None,
    )
    monkeypatch.setattr(
        "synax_skill_cli.commands.skill._git_init",
        lambda directory: False,
    )


# ---------------------------------------------------------------------------
# Happy paths
# ---------------------------------------------------------------------------
class TestInitHappy:
    def test_creates_project_at_default_path(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        assert result.exit_code == 0, result.stdout
        assert "Created" in _flat(result.stdout)
        target = isolated_cwd / "my-skill"
        assert (target / "pyproject.toml").exists()
        assert (target / "my_skill.py").exists()
        assert (target / "README.md").exists()
        assert (target / ".gitignore").exists()
        assert (target / ".synax-skillignore").exists()
        assert (target / "tests" / "test_skill.py").exists()
        assert (target / "test_inputs" / "greet" / "case_basic.yaml").exists()

    def test_custom_output_directory(self, isolated_cwd: Path, no_git: None) -> None:
        target = isolated_cwd / "elsewhere"
        result = runner.invoke(
            app, ["skill", "init", "my-skill", "--output", str(target), "--no-git"]
        )
        assert result.exit_code == 0
        assert (target / "pyproject.toml").exists()
        assert (target / "my_skill.py").exists()

    def test_explicit_author(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(
            app,
            ["skill", "init", "my-skill", "--author", "Jane Doe", "--no-git"],
        )
        assert result.exit_code == 0
        text = (isolated_cwd / "my-skill" / "pyproject.toml").read_text(encoding="utf-8")
        assert 'authors = [{ name = "Jane Doe" }]' in text

    def test_git_user_name_used_as_author_default(
        self, isolated_cwd: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(
            "synax_skill_cli.commands.skill._git_user_name", lambda: "Detected Author"
        )
        monkeypatch.setattr("synax_skill_cli.commands.skill._git_init", lambda directory: False)
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        assert result.exit_code == 0
        text = (isolated_cwd / "my-skill" / "pyproject.toml").read_text(encoding="utf-8")
        assert "Detected Author" in text

    def test_fallback_author_when_no_git(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        assert result.exit_code == 0
        text = (isolated_cwd / "my-skill" / "pyproject.toml").read_text(encoding="utf-8")
        assert "Skill Author" in text

    def test_explicit_version(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(
            app,
            ["skill", "init", "my-skill", "--version", "9.9.9", "--no-git"],
        )
        assert result.exit_code == 0
        text = (isolated_cwd / "my-skill" / "pyproject.toml").read_text(encoding="utf-8")
        assert 'version = "9.9.9"' in text

    def test_skill_name_translated_to_snake_case(self, isolated_cwd: Path, no_git: None) -> None:
        runner.invoke(app, ["skill", "init", "github-pr-tools", "--no-git"])
        target = isolated_cwd / "github-pr-tools"
        assert (target / "github_pr_tools.py").exists()
        pyproject = (target / "pyproject.toml").read_text(encoding="utf-8")
        assert 'entry_point = "github_pr_tools:skill"' in pyproject

    def test_skill_name_human_form(self, isolated_cwd: Path, no_git: None) -> None:
        runner.invoke(app, ["skill", "init", "github-pr-tools", "--no-git"])
        readme = (isolated_cwd / "github-pr-tools" / "README.md").read_text(encoding="utf-8")
        assert "# Github Pr Tools" in readme

    def test_git_init_runs_when_enabled(
        self, isolated_cwd: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        called: list[Path] = []

        def fake_git_init(directory: Path) -> bool:
            called.append(directory)
            return True

        monkeypatch.setattr("synax_skill_cli.commands.skill._git_user_name", lambda: None)
        monkeypatch.setattr("synax_skill_cli.commands.skill._git_init", fake_git_init)
        result = runner.invoke(app, ["skill", "init", "my-skill"])
        assert result.exit_code == 0
        assert len(called) == 1
        assert "initialised git" in _flat(result.stdout)

    def test_git_init_failure_warns_not_errors(
        self, isolated_cwd: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr("synax_skill_cli.commands.skill._git_user_name", lambda: None)
        monkeypatch.setattr("synax_skill_cli.commands.skill._git_init", lambda directory: False)
        result = runner.invoke(app, ["skill", "init", "my-skill"])
        assert result.exit_code == 0
        assert "couldn't run" in _flat(result.stdout)
        # The project files were still created.
        assert (isolated_cwd / "my-skill" / "pyproject.toml").exists()

    def test_next_steps_banner_printed(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        flat = _flat(result.stdout)
        assert "To get started" in flat
        assert "uv sync" in flat
        assert "synax skill test" in flat
        assert "synax skill build" in flat

    def test_sdk_version_pinned(self, isolated_cwd: Path, no_git: None) -> None:
        from synax_sdk.version import __version__

        runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        pyproject = (isolated_cwd / "my-skill" / "pyproject.toml").read_text(encoding="utf-8")
        assert f"synax-sdk>={__version__}" in pyproject
        assert f'sdk_version = "{__version__}"' in pyproject


# ---------------------------------------------------------------------------
# Failure modes
# ---------------------------------------------------------------------------
class TestInitErrors:
    def test_invalid_skill_name_rejected(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(app, ["skill", "init", "Invalid-Name", "--no-git"])
        assert result.exit_code == 1
        assert "Invalid skill name" in _flat(result.stdout)

    def test_uppercase_name_rejected(self, isolated_cwd: Path, no_git: None) -> None:
        result = runner.invoke(app, ["skill", "init", "MY-SKILL", "--no-git"])
        assert result.exit_code == 1

    def test_existing_non_empty_directory_rejected(self, isolated_cwd: Path, no_git: None) -> None:
        target = isolated_cwd / "my-skill"
        target.mkdir()
        (target / "existing.txt").write_text("hi", encoding="utf-8")
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        assert result.exit_code == 1
        assert "already exists" in _flat(result.stdout)

    def test_empty_existing_directory_allowed(self, isolated_cwd: Path, no_git: None) -> None:
        target = isolated_cwd / "my-skill"
        target.mkdir()  # empty
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        assert result.exit_code == 0
        assert (target / "pyproject.toml").exists()


# ---------------------------------------------------------------------------
# Project loadability: the generated project must satisfy `load_skill_from_project`
# ---------------------------------------------------------------------------
class TestGeneratedProjectIsLoadable:
    def test_load_skill_from_generated_project(
        self,
        isolated_cwd: Path,
        no_git: None,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """After init, the project should be loadable by `find_project_root` +
        `load_skill_from_project` (the same code paths used by every other CLI
        command). That's the strongest proof the template renders to a
        working layout."""
        result = runner.invoke(app, ["skill", "init", "my-skill", "--no-git"])
        assert result.exit_code == 0

        from synax_skill_cli.utils.project import (
            find_project_root,
            load_skill_from_project,
        )

        target = isolated_cwd / "my-skill"
        assert find_project_root(target) == target.resolve()
        skill = load_skill_from_project(target)
        assert skill.name == "my-skill"
        assert any(tool.name == "greet" for tool in skill.tools)

        # The pre-bundled test_inputs/greet/case_basic.yaml should pass:
        from synax_sdk.testing.declarative import run_all

        # Move cwd into the generated project so MockPlatform secrets work
        # without any extra setup, and to mirror what `synax skill test` does.
        monkeypatch.chdir(target)
        results = run_all(skill, target / "test_inputs")
        assert len(results) == 1, results
        assert results[0].passed, results[0].failures


# ---------------------------------------------------------------------------
# Pytest-shaped smoke: shutil.which("git") availability not required
# ---------------------------------------------------------------------------
class TestGitAvailability:
    def test_git_helpers_handle_missing_binary(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Make sure _git_user_name and _git_init don't blow up if git is missing."""
        from synax_skill_cli.commands.skill import _git_init, _git_user_name

        # Force FileNotFoundError by pointing PATH at a non-existent location.
        monkeypatch.setenv("PATH", "/nonexistent-path")
        if shutil.which("git") is not None:
            # On systems where git was resolved before PATH was changed (e.g.
            # because the test runner inherited an absolute git location),
            # mocking subprocess.run directly is more reliable.
            import subprocess

            def boom(*args, **kwargs):
                raise FileNotFoundError("git not found")

            monkeypatch.setattr(subprocess, "run", boom)
        assert _git_user_name() is None
        assert _git_init(Path(".")) is False
