"""Tests for ``synax_skill_cli.utils.config``."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from synax_skill_cli.utils.config import (
    PROJECT_CONFIG_SUBPATH,
    PUBLISH_TOKEN_ENV_VAR,
    CliConfig,
    ConfigError,
    load_config,
    resolve_auth_token,
    resolve_target,
    save_config,
)


# ---------------------------------------------------------------------------
# load_config
# ---------------------------------------------------------------------------
class TestLoadConfig:
    def test_returns_defaults_when_no_files(self, tmp_path: Path) -> None:
        config = load_config(project_root=tmp_path, user_path=tmp_path / "nope.yaml")
        assert config == CliConfig()

    def test_loads_user_config(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text(
            yaml.safe_dump(
                {
                    "default_target": "https://synax.example.com",
                    "default_auth_token_env": "MY_TOKEN_VAR",
                }
            ),
            encoding="utf-8",
        )
        config = load_config(project_root=tmp_path, user_path=user)
        assert config.default_target == "https://synax.example.com"
        assert config.default_auth_token_env == "MY_TOKEN_VAR"

    def test_project_overrides_user(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text(yaml.safe_dump({"default_target": "user-target"}), encoding="utf-8")
        project_root = tmp_path / "proj"
        (project_root / ".synax").mkdir(parents=True)
        (project_root / PROJECT_CONFIG_SUBPATH).write_text(
            yaml.safe_dump({"default_target": "project-target"}),
            encoding="utf-8",
        )
        config = load_config(project_root=project_root, user_path=user)
        assert config.default_target == "project-target"

    def test_user_value_kept_when_project_silent(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text(yaml.safe_dump({"default_auth_token_env": "USER_VAR"}), encoding="utf-8")
        project_root = tmp_path / "proj"
        (project_root / ".synax").mkdir(parents=True)
        (project_root / PROJECT_CONFIG_SUBPATH).write_text(
            yaml.safe_dump({"default_target": "p"}),
            encoding="utf-8",
        )
        config = load_config(project_root=project_root, user_path=user)
        assert config.default_target == "p"
        assert config.default_auth_token_env == "USER_VAR"

    def test_empty_yaml_file_is_default(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text("", encoding="utf-8")
        assert load_config(user_path=user) == CliConfig()

    def test_yaml_explicit_null_is_default(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text("~\n", encoding="utf-8")
        assert load_config(user_path=user) == CliConfig()

    def test_malformed_yaml_raises(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text("not: valid: yaml: :::", encoding="utf-8")
        with pytest.raises(ConfigError, match="not valid YAML"):
            load_config(user_path=user)

    def test_non_object_root_raises(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text("- a\n- b\n", encoding="utf-8")
        with pytest.raises(ConfigError, match="YAML object at the top level"):
            load_config(user_path=user)

    def test_no_project_root_only_uses_user(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text(yaml.safe_dump({"default_target": "u"}), encoding="utf-8")
        config = load_config(project_root=None, user_path=user)
        assert config.default_target == "u"

    def test_unknown_keys_ignored(self, tmp_path: Path) -> None:
        """Forward-compatibility: unknown YAML keys don't crash."""
        user = tmp_path / "user.yaml"
        user.write_text(
            yaml.safe_dump({"default_target": "u", "future_field": "ignored", "another": 42}),
            encoding="utf-8",
        )
        config = load_config(user_path=user)
        assert config.default_target == "u"

    def test_non_string_values_treated_as_none(self, tmp_path: Path) -> None:
        user = tmp_path / "user.yaml"
        user.write_text(
            yaml.safe_dump({"default_target": 123, "default_auth_token_env": True}),
            encoding="utf-8",
        )
        config = load_config(user_path=user)
        assert config.default_target is None
        assert config.default_auth_token_env is None


# ---------------------------------------------------------------------------
# save_config
# ---------------------------------------------------------------------------
class TestSaveConfig:
    def test_round_trips(self, tmp_path: Path) -> None:
        original = CliConfig(default_target="https://x", default_auth_token_env="VAR")
        path = tmp_path / "config.yaml"
        save_config(original, path)
        assert path.exists()
        loaded = load_config(user_path=path)
        assert loaded == original

    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        save_config(CliConfig(default_target="x"), tmp_path / "nested" / "deep" / "c.yaml")
        assert (tmp_path / "nested" / "deep" / "c.yaml").exists()

    def test_none_fields_omitted(self, tmp_path: Path) -> None:
        path = tmp_path / "c.yaml"
        save_config(CliConfig(default_target="x"), path)
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert "default_target" in data
        assert "default_auth_token_env" not in data

    def test_empty_config_writes_empty_file(self, tmp_path: Path) -> None:
        path = tmp_path / "c.yaml"
        save_config(CliConfig(), path)
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        assert data == {}


# ---------------------------------------------------------------------------
# resolve_auth_token
# ---------------------------------------------------------------------------
class TestResolveAuthToken:
    def test_explicit_wins(self) -> None:
        token = resolve_auth_token(
            "explicit", CliConfig(default_auth_token_env="OTHER"), env={"OTHER": "from-env"}
        )
        assert token == "explicit"

    def test_falls_back_to_default_env_var(self) -> None:
        token = resolve_auth_token(None, CliConfig(), env={PUBLISH_TOKEN_ENV_VAR: "default-env"})
        assert token == "default-env"

    def test_default_env_takes_precedence_over_config_var(self) -> None:
        token = resolve_auth_token(
            None,
            CliConfig(default_auth_token_env="OTHER"),
            env={PUBLISH_TOKEN_ENV_VAR: "primary", "OTHER": "secondary"},
        )
        assert token == "primary"

    def test_falls_back_to_config_named_env(self) -> None:
        token = resolve_auth_token(
            None, CliConfig(default_auth_token_env="OTHER"), env={"OTHER": "from-other"}
        )
        assert token == "from-other"

    def test_returns_none_when_nothing_matches(self) -> None:
        token = resolve_auth_token(None, CliConfig(), env={})
        assert token is None

    def test_config_var_unset_returns_none(self) -> None:
        """When config names an env var that's not set, we get None (not a KeyError)."""
        token = resolve_auth_token(None, CliConfig(default_auth_token_env="MISSING"), env={})
        assert token is None

    def test_empty_string_explicit_does_not_count(self) -> None:
        token = resolve_auth_token("", CliConfig(), env={PUBLISH_TOKEN_ENV_VAR: "from-env"})
        assert token == "from-env"


# ---------------------------------------------------------------------------
# resolve_target
# ---------------------------------------------------------------------------
class TestResolveTarget:
    def test_explicit_wins(self) -> None:
        assert resolve_target("flag", CliConfig(default_target="config")) == "flag"

    def test_falls_back_to_config(self) -> None:
        assert resolve_target(None, CliConfig(default_target="config")) == "config"

    def test_neither_set_returns_none(self) -> None:
        assert resolve_target(None, CliConfig()) is None

    def test_empty_explicit_falls_back(self) -> None:
        assert resolve_target("", CliConfig(default_target="config")) == "config"
