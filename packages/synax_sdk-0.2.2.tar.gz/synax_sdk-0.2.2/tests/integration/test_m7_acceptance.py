"""End-to-end test of the Milestone 7 acceptance scenario.

The build_plan §Milestone 7 acceptance is the strongest test we have for
the SDK as a whole:

  synax skill init my-new-skill
  cd my-new-skill
  synax skill build       # ← must succeed on the generated project

Builds against the *generated* skill — if any of M2-M7's contracts are
broken, this test catches it.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from synax_sdk.signing import KeyStore, generate_keypair
from synax_skill_cli.commands import keys as keys_module
from synax_skill_cli.main import app

pytestmark = pytest.mark.integration
runner = CliRunner()


def _flat(text: str) -> str:
    return " ".join(text.split())


@pytest.fixture
def isolated_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def isolated_keystore(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> KeyStore:
    store = KeyStore(root=tmp_path / "keys")
    store.save(generate_keypair())
    monkeypatch.setattr(keys_module, "_store", lambda: store)
    monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: store))
    return store


@pytest.fixture
def no_git(monkeypatch: pytest.MonkeyPatch) -> None:
    """Avoid running real git during init — we want a deterministic test."""
    monkeypatch.setattr("synax_skill_cli.commands.skill._git_user_name", lambda: None)
    monkeypatch.setattr("synax_skill_cli.commands.skill._git_init", lambda directory: False)


# ---------------------------------------------------------------------------
# The acceptance flow
# ---------------------------------------------------------------------------
def test_build_plan_m7_acceptance_flow(
    isolated_cwd: Path,
    isolated_keystore: KeyStore,
    no_git: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`synax skill init my-new-skill && cd my-new-skill && synax skill build`."""

    # 1) scaffold
    init_result = runner.invoke(app, ["skill", "init", "my-new-skill", "--no-git"])
    assert init_result.exit_code == 0, init_result.stdout
    assert "Created" in _flat(init_result.stdout)
    assert "To get started" in _flat(init_result.stdout)

    project_dir = isolated_cwd / "my-new-skill"
    monkeypatch.chdir(project_dir)

    # 2) build
    build_result = runner.invoke(app, ["skill", "build"])
    assert build_result.exit_code == 0, build_result.stdout
    flat = _flat(build_result.stdout)
    assert "Built" in flat
    assert "my-new-skill" in flat

    # 3) verify the produced bundle
    bundle_dir = project_dir / "build" / "signed_bundle"
    assert (bundle_dir / "manifest.yaml").exists()
    assert (bundle_dir / "implementation.tar.gz").exists()


def test_generated_project_passes_validate(
    isolated_cwd: Path,
    no_git: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The scaffolded skill should validate cleanly with no warnings either."""
    runner.invoke(app, ["skill", "init", "demo-skill", "--no-git"])
    monkeypatch.chdir(isolated_cwd / "demo-skill")
    result = runner.invoke(app, ["skill", "validate"])
    assert result.exit_code == 0, result.stdout
    assert "Validation passed" in _flat(result.stdout)


def test_generated_project_passes_skill_test(
    isolated_cwd: Path,
    no_git: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The bundled test_inputs/greet/case_basic.yaml should pass."""
    runner.invoke(app, ["skill", "init", "demo-skill", "--no-git"])
    monkeypatch.chdir(isolated_cwd / "demo-skill")
    result = runner.invoke(app, ["skill", "test"])
    assert result.exit_code == 0, result.stdout
    flat = _flat(result.stdout)
    assert "PASS" in flat
    assert "case_basic" in flat
    assert "All 1 test case(s) passed" in flat


def test_generated_project_info_summary(
    isolated_cwd: Path,
    no_git: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`synax skill info` should reflect the template values."""
    runner.invoke(app, ["skill", "init", "demo-skill", "--no-git"])
    monkeypatch.chdir(isolated_cwd / "demo-skill")
    result = runner.invoke(app, ["skill", "info"])
    assert result.exit_code == 0, result.stdout
    flat = _flat(result.stdout)
    assert "demo-skill" in flat
    assert "v0.1.0" in flat
    assert "greet" in flat
    assert "secrets:GREETING" in flat


def test_init_with_custom_options_produces_buildable_project(
    isolated_cwd: Path,
    isolated_keystore: KeyStore,
    no_git: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-default flags (--author, --version) still produce a buildable project."""
    result = runner.invoke(
        app,
        [
            "skill",
            "init",
            "github-pr-tools",
            "--author",
            "Acme Inc.",
            "--version",
            "2.3.4",
            "--no-git",
        ],
    )
    assert result.exit_code == 0, result.stdout

    project_dir = isolated_cwd / "github-pr-tools"
    monkeypatch.chdir(project_dir)
    build_result = runner.invoke(app, ["skill", "build"])
    assert build_result.exit_code == 0, build_result.stdout
    # The hash inside the manifest is bound to a *github-pr-tools* skill at
    # version 2.3.4 — confirm by reading the produced bundle.
    import yaml as _yaml

    manifest = _yaml.safe_load(
        (project_dir / "build" / "signed_bundle" / "manifest.yaml").read_text(encoding="utf-8")
    )
    assert manifest["name"] == "github-pr-tools"
    assert manifest["version"] == "2.3.4"
    assert manifest["implementation"]["entry_point"] == "github_pr_tools:skill"
