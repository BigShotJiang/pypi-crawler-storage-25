"""End-to-end test mirroring the build_plan.md §Milestone 2 acceptance example.

If the public API surface changes such that the example in the build plan
stops working, this test will catch it. The example is the contract this
milestone delivers.
"""

import asyncio
import json
from typing import Any

import pytest
import yaml

# These imports prove the public API is wired correctly.
from synax_sdk import (
    Manifest,
    ManifestError,
    Secret,
    Skill,
    SkillDefinitionError,
    SkillDependency,
    SkillMetadata,
    SkillValidationError,
    SynaxSDKError,
    __version__,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# The build_plan acceptance example, verbatim
# ---------------------------------------------------------------------------
def test_build_plan_acceptance_example_runs() -> None:
    """The exact example from build_plan.md §Milestone 2 acceptance section."""
    skill = Skill(
        name="hello-world",
        version="1.0.0",
        description="A trivial test skill",
        capabilities=["secrets:GREETING"],
        secrets=[{"name": "GREETING", "type": "generic_string", "description": "..."}],
    )

    @skill.tool(description="Say hello")
    async def greet(name: str) -> str:
        """Greet someone.

        Args:
            name: Who to greet
        """
        return f"Hello, {name}"

    # The decorator returns the original function — direct invocation must work.
    result = asyncio.run(greet(name="World"))
    assert result == "Hello, World"

    # Manifest derivation
    manifest = Manifest.from_skill(skill)
    assert manifest.name == "hello-world"
    assert manifest.version == "1.0.0"
    assert len(manifest.tools) == 1
    assert manifest.tools[0].name == "greet"
    assert manifest.tools[0].description == "Say hello"

    # YAML serialization is valid YAML matching the schema shape
    yaml_text = manifest.to_yaml()
    parsed = yaml.safe_load(yaml_text)
    assert parsed["schema_version"] == "1.0"
    assert parsed["name"] == "hello-world"
    assert parsed["tools"][0]["parameters"]["required"] == ["name"]
    assert parsed["tools"][0]["parameters"]["properties"]["name"] == {
        "type": "string",
        "description": "Who to greet",
    }
    assert parsed["tools"][0]["returns"] == {"type": "string"}


# ---------------------------------------------------------------------------
# Public API surface
# ---------------------------------------------------------------------------
def test_public_api_exports() -> None:
    """Every M2 name is still in synax_sdk.__all__.

    Subsequent milestones may add more names; this test pins the M2 *floor*
    so adding never accidentally removes. The current __all__ check lives in
    the latest milestone's acceptance test.
    """
    import synax_sdk

    m2_names = {
        "Manifest",
        "ManifestError",
        "Secret",
        "Skill",
        "SkillDefinitionError",
        "SkillDependency",
        "SkillMetadata",
        "SkillValidationError",
        "SynaxSDKError",
        "__version__",
    }
    assert m2_names <= set(synax_sdk.__all__)
    for name in m2_names:
        assert hasattr(synax_sdk, name), f"synax_sdk.{name} missing"


def test_exception_hierarchy_via_public_api() -> None:
    """The hierarchy is the same regardless of import path."""
    assert issubclass(SkillDefinitionError, SynaxSDKError)
    assert issubclass(SkillValidationError, SynaxSDKError)
    assert issubclass(ManifestError, SynaxSDKError)
    assert issubclass(SynaxSDKError, Exception)


# ---------------------------------------------------------------------------
# A more complex skill — multiple tools, complex types, dependencies, metadata
# ---------------------------------------------------------------------------
def test_complex_skill_round_trip() -> None:
    from typing import TypedDict

    class PRSummary(TypedDict):
        title: str
        files_changed: int
        author: str

    skill = Skill(
        name="github-pr-tools",
        namespace="acme",
        version="2.3.1",
        description="GitHub PR helpers",
        display_name="GitHub PR Tools",
        capabilities=[
            "network:api.github.com",
            "secrets:GITHUB_TOKEN",
        ],
        execution_location="prefer_cloud",
        secrets=[
            Secret(
                name="GITHUB_TOKEN",
                type="oauth_token",
                description="GitHub OAuth token with repo:read scope.",
                scope_required="repo:read",
            ),
        ],
        dependencies=[SkillDependency(skill="http-utils", version=">=1.0.0,<2.0.0")],
        metadata=SkillMetadata(
            category="developer_tools",
            tags=["github", "code-review"],
            license="Apache-2.0",
            homepage="https://example.com",
        ),
    )

    @skill.tool(description="Fetch and summarize a GitHub pull request")
    async def summarize_pr(repo: str, pr_number: int) -> PRSummary:
        """Fetch a PR.

        Args:
            repo: Repository in owner/name format.
            pr_number: Pull request number.
        """
        return PRSummary(title="x", files_changed=1, author="y")

    @skill.tool(description="List recent open PRs for a repository")
    async def list_recent_prs(repo: str, limit: int = 10) -> list[dict[str, Any]]:
        """List recent open PRs.

        Args:
            repo: Repository in owner/name format.
            limit: Maximum number of PRs to return.
        """
        return []

    # Two tools, in declaration order
    assert [t.name for t in skill.tools] == ["summarize_pr", "list_recent_prs"]

    manifest = Manifest.from_skill(skill)
    data = manifest.to_dict()

    assert data["namespace"] == "acme"
    assert data["execution_location"] == "prefer_cloud"
    assert data["dependencies"] == [{"skill": "http-utils", "version": ">=1.0.0,<2.0.0"}]
    assert data["metadata"]["category"] == "developer_tools"
    assert data["metadata"]["tags"] == ["github", "code-review"]
    assert data["metadata"]["sdk_version"] == __version__
    assert data["tools"][0]["parameters"]["properties"]["repo"]["description"] == (
        "Repository in owner/name format."
    )
    assert data["tools"][1]["parameters"]["properties"]["limit"]["default"] == 10

    # The summarize_pr return schema reflects the TypedDict
    pr_returns = data["tools"][0]["returns"]
    assert pr_returns["type"] == "object"
    assert set(pr_returns["properties"].keys()) == {"title", "files_changed", "author"}

    # Canonical JSON for signing is deterministic and excludes signatures
    canonical = manifest.to_canonical_json()
    parsed = json.loads(canonical.decode("utf-8"))
    assert "signatures" not in parsed
    assert parsed["name"] == "github-pr-tools"

    # YAML output is round-trippable. parsed_yaml has "signatures" omitted
    # because the manifest has no signatures yet, just like the canonical JSON.
    yaml_text = manifest.to_yaml()
    parsed_yaml = yaml.safe_load(yaml_text)
    assert parsed_yaml == parsed
