"""End-to-end test of the Milestone 3 acceptance scenario.

The build_plan §Milestone 3 acceptance criteria says: skills can use the
runtime API (secrets, logger, metrics, ctx) and tests can verify behaviour
with ``MockPlatform``. This file pins that contract end-to-end.
"""

import uuid

import pytest

# Everything imported from the public top-level namespace — proves
# `from synax_sdk import ...` works for every name we want skill authors
# to reach for.
from synax_sdk import (
    Context,
    Invoker,
    Skill,
    SkillRuntimeError,
    ctx,
    logger,
    metrics,
    secrets,
)
from synax_sdk.testing import MockPlatform

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# The build_plan acceptance example
# ---------------------------------------------------------------------------
def _build_skill_with_runtime_calls() -> Skill:
    """Construct the build_plan §M3 acceptance skill and return it."""
    skill = Skill(
        name="greet-skill",
        version="1.0.0",
        description="Demonstrates the runtime API",
        capabilities=["secrets:GREETING"],
        secrets=[
            {
                "name": "GREETING",
                "type": "generic_string",
                "description": "Greeting word.",
            }
        ],
    )

    @skill.tool(description="Greet someone")
    async def my_tool(name: str) -> str:
        """Greet someone using a configured greeting.

        Args:
            name: Who to greet.
        """
        greeting = await secrets.get("GREETING")
        logger.info(f"Greeting {name}")
        return f"{greeting}, {name}"

    return skill


async def test_build_plan_m3_acceptance_example() -> None:
    """Mirrors docs/build_plan.md §Milestone 3 Acceptance verbatim."""
    skill = _build_skill_with_runtime_calls()
    my_tool = skill.tools[0].func  # the original async function

    mock = MockPlatform()
    mock.secrets.set("GREETING", "Hello")

    with mock.activate():
        result = await my_tool(name="World")

    assert result == "Hello, World"
    assert mock.logger.calls[0].message == "Greeting World"
    assert mock.secrets.accesses == ["GREETING"]


# ---------------------------------------------------------------------------
# Full runtime surface — every facade reachable from the top-level package
# ---------------------------------------------------------------------------
async def test_every_runtime_facade_via_top_level_imports() -> None:
    """secrets, logger, metrics, ctx all imported from `synax_sdk` and exercised."""
    mock = MockPlatform()
    mock.secrets.set("KEY", "value")
    mock.context.set(
        run_id=uuid.UUID(int=1),
        workspace_id=uuid.UUID(int=2),
        invoker=Invoker(type="user", id=uuid.UUID(int=3), name="alice"),
    )

    with mock.activate():
        v = await secrets.get("KEY")
        logger.info("did a thing", extra={"v": v})
        metrics.counter("calls").inc()
        metrics.gauge("queue").set(7)
        metrics.histogram("ms").observe(42)
        run = ctx.run_id
        ws = ctx.workspace_id
        who = ctx.invoker

    assert v == "value"
    assert mock.logger.calls[0].message == "did a thing"
    assert mock.metrics.counters["calls"].value == 1.0
    assert mock.metrics.gauges["queue"].value == 7.0
    assert mock.metrics.histograms["ms"].values == [42.0]
    assert run == uuid.UUID(int=1)
    assert ws == uuid.UUID(int=2)
    assert who.name == "alice"


# ---------------------------------------------------------------------------
# Public API: __all__ matches an explicit expectation
# ---------------------------------------------------------------------------
def test_public_api_exports() -> None:
    import synax_sdk

    expected = {
        "CapabilityError",
        "Context",
        "Invoker",
        "Manifest",
        "ManifestError",
        "Secret",
        "Skill",
        "SkillDefinitionError",
        "SkillDependency",
        "SkillMetadata",
        "SkillRuntimeError",
        "SkillValidationError",
        "SynaxSDKError",
        "__version__",
        "ctx",
        "logger",
        "metrics",
        "network",
        "secrets",
    }
    assert set(synax_sdk.__all__) == expected
    for name in expected:
        assert hasattr(synax_sdk, name), f"synax_sdk.{name} missing"


# ---------------------------------------------------------------------------
# Realistic skill — multiple runtime calls, error propagation, mock inspection
# ---------------------------------------------------------------------------
async def test_realistic_skill_with_runtime_and_inspection() -> None:
    skill = Skill(
        name="github-search",
        version="1.0.0",
        description="Search GitHub",
        capabilities=["network:api.github.com", "secrets:GITHUB_TOKEN"],
        secrets=[
            {
                "name": "GITHUB_TOKEN",
                "type": "oauth_token",
                "description": "GH token",
            }
        ],
    )

    @skill.tool(description="Search GitHub repos")
    async def search(query: str, limit: int = 10) -> dict:
        """Search.

        Args:
            query: Search query.
            limit: Max results.
        """
        token = await secrets.get("GITHUB_TOKEN")
        logger.info("searching", extra={"query": query, "limit": limit})
        metrics.counter("github_api_calls").inc()
        metrics.histogram("search_latency_ms").observe(123.4)
        return {"token_used": token, "results": []}

    fake_token = "FAKE_TEST_TOKEN"
    mock = MockPlatform()
    mock.secrets.set("GITHUB_TOKEN", fake_token)
    mock.context.set()

    func = skill.tools[0].func
    with mock.activate():
        result1 = await func(query="rust", limit=5)
        result2 = await func(query="python")

    assert result1["token_used"] == fake_token
    assert mock.secrets.accesses == ["GITHUB_TOKEN", "GITHUB_TOKEN"]
    assert len(mock.logger.calls) == 2
    assert mock.logger.calls[0].extra == {"query": "rust", "limit": 5}
    assert mock.logger.calls[1].extra == {"query": "python", "limit": 10}
    assert mock.metrics.counters["github_api_calls"].value == 2.0
    assert mock.metrics.histograms["search_latency_ms"].count == 2
    # Result of the second call too
    assert result2["token_used"] == fake_token


# ---------------------------------------------------------------------------
# Sanity: runtime calls outside activate() raise the same way regardless of import path
# ---------------------------------------------------------------------------
async def test_runtime_calls_outside_activate_raise() -> None:
    """All four runtime facades raise SkillRuntimeError when no backend is active."""
    with pytest.raises(SkillRuntimeError):
        await secrets.get("X")
    with pytest.raises(SkillRuntimeError):
        logger.info("x")
    with pytest.raises(SkillRuntimeError):
        metrics.counter("x")
    with pytest.raises(SkillRuntimeError):
        _ = ctx.run_id


# ---------------------------------------------------------------------------
# Context types are also importable
# ---------------------------------------------------------------------------
def test_context_and_invoker_dataclasses_importable() -> None:
    """Authors can construct Context / Invoker directly (e.g. for richer test setups)."""
    invoker = Invoker(type="bot", id=uuid.UUID(int=1), name="b")
    context = Context(
        run_id=uuid.UUID(int=2),
        workspace_id=uuid.UUID(int=3),
        invoker=invoker,
        channel_id=uuid.UUID(int=4),
    )
    assert context.invoker is invoker
