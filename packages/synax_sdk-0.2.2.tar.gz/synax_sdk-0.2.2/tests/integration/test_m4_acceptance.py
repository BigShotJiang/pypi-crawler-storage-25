"""End-to-end test of the Milestone 4 acceptance scenario.

The build_plan §Milestone 4 acceptance section says a developer can:

* generate a keypair with ``synax keys generate``
* build the current project with ``synax skill build``
* validate it with ``synax skill validate``

This test wires that whole flow together via :class:`typer.testing.CliRunner`
and asserts every observable side-effect (key on disk, bundle on disk,
signature verifies cryptographically against the canonical bytes).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from synax_sdk.signing import KeyStore, Verifier
from synax_skill_cli.commands import keys as keys_module
from synax_skill_cli.main import app

pytestmark = pytest.mark.integration
runner = CliRunner()


PYPROJECT = """\
[project]
name = "hello-skill"
version = "0.1.0"

[tool.synax]
entry_point = "hello_skill:skill"
"""

SKILL_SRC = """\
from synax_sdk import Skill

skill = Skill(
    name="hello-skill",
    version="0.1.0",
    description="A trivial skill",
    capabilities=["secrets:GREETING"],
    secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
)

@skill.tool(description="Greet someone")
def greet(name: str) -> str:
    \"\"\"Greet.

    Args:
        name: who.
    \"\"\"
    return f"hello, {name}"
"""


@pytest.fixture
def project_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "hello_skill.py").write_text(SKILL_SRC, encoding="utf-8")
    monkeypatch.chdir(root)
    return root


@pytest.fixture
def isolated_keystore(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> KeyStore:
    """An empty tmp_path keystore that every CLI command sees."""
    s = KeyStore(root=tmp_path / "keys")
    monkeypatch.setattr(keys_module, "_store", lambda output_dir=None: s)
    monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: s))
    return s


# ---------------------------------------------------------------------------
# The full acceptance flow
# ---------------------------------------------------------------------------
def test_build_plan_m4_acceptance_flow(
    project_dir: Path,
    isolated_keystore: KeyStore,
) -> None:
    """Verbatim flow from build_plan.md §Milestone 4 Acceptance Criteria."""
    # 1) generate a key
    r1 = runner.invoke(app, ["keys", "generate"])
    assert r1.exit_code == 0, r1.stdout
    assert isolated_keystore.default_fingerprint is not None

    # 2) validate the current project
    r2 = runner.invoke(app, ["skill", "validate"])
    assert r2.exit_code == 0, r2.stdout
    assert "Validation passed" in r2.stdout

    # 3) build the current project
    r3 = runner.invoke(app, ["skill", "build"])
    assert r3.exit_code == 0, r3.stdout
    assert "Built" in r3.stdout

    bundle_dir = project_dir / "build" / "signed_bundle"
    manifest_path = bundle_dir / "manifest.yaml"
    artifact_path = bundle_dir / "implementation.tar.gz"
    assert manifest_path.exists()
    assert artifact_path.exists()

    # 4) the produced manifest verifies via the CLI
    r4 = runner.invoke(app, ["skill", "verify", str(manifest_path)])
    assert r4.exit_code == 0, r4.stdout
    assert "verified" in r4.stdout


def test_build_artifact_hash_matches_manifest_hash(
    project_dir: Path,
    isolated_keystore: KeyStore,
) -> None:
    """The hash pinned into the manifest must be the SHA-256 of the actual
    .tar.gz file written next to it. If they ever diverge, the platform
    refuses the upload."""
    import hashlib

    runner.invoke(app, ["keys", "generate"])
    runner.invoke(app, ["skill", "build"])

    bundle_dir = project_dir / "build" / "signed_bundle"
    manifest = yaml.safe_load((bundle_dir / "manifest.yaml").read_text(encoding="utf-8"))
    actual_hash = (
        "sha256:" + hashlib.sha256((bundle_dir / "implementation.tar.gz").read_bytes()).hexdigest()
    )
    assert manifest["implementation"]["hash"] == actual_hash


def test_signature_verifies_against_independent_canonical_form(
    project_dir: Path,
    isolated_keystore: KeyStore,
) -> None:
    """Re-derive canonical bytes from the produced manifest and verify
    using only the public key — this is the same path the platform takes."""
    runner.invoke(app, ["keys", "generate"])
    runner.invoke(app, ["skill", "build"])

    bundle_dir = project_dir / "build" / "signed_bundle"
    manifest = yaml.safe_load((bundle_dir / "manifest.yaml").read_text(encoding="utf-8"))
    payload = {k: v for k, v in manifest.items() if k != "signatures"}
    canonical = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")

    sig = manifest["signatures"][0]
    keypair = isolated_keystore.load(sig["key_fingerprint"])
    # Public-only verification (matches platform behaviour)
    public_only = type(keypair)(public_key=keypair.public_key)
    Verifier(keypair=public_only).verify(canonical, sig["signature"])


def test_validate_command_catches_real_problems(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Build a project with a skill that has no tools — validation must reject it."""
    root = tmp_path / "bad"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "hello_skill.py").write_text(
        "from synax_sdk import Skill\n"
        "skill = Skill(name='x', version='1.0.0', description='x')\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(root)
    result = runner.invoke(app, ["skill", "validate"])
    assert result.exit_code == 1
    assert "Validation failed" in result.stdout


def test_build_is_deterministic_across_runs(
    project_dir: Path,
    isolated_keystore: KeyStore,
) -> None:
    """Two builds with the same key produce the same artifact and canonical bytes."""
    runner.invoke(app, ["keys", "generate"])
    runner.invoke(app, ["skill", "build"])
    bundle = project_dir / "build" / "signed_bundle"
    first_artifact = (bundle / "implementation.tar.gz").read_bytes()
    first_canonical = (project_dir / "build" / "manifest.canonical").read_bytes()

    # Build a second time
    runner.invoke(app, ["skill", "build"])
    second_artifact = (bundle / "implementation.tar.gz").read_bytes()
    second_canonical = (project_dir / "build" / "manifest.canonical").read_bytes()

    assert first_artifact == second_artifact
    assert first_canonical == second_canonical


def test_round_trip_via_verify_after_tampering(
    project_dir: Path,
    isolated_keystore: KeyStore,
) -> None:
    """Tamper with the manifest, run verify, get a clear failure."""
    runner.invoke(app, ["keys", "generate"])
    runner.invoke(app, ["skill", "build"])

    manifest_path = project_dir / "build" / "signed_bundle" / "manifest.yaml"
    data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    data["description"] = "MALICIOUS"
    manifest_path.write_text(yaml.safe_dump(data), encoding="utf-8")

    result = runner.invoke(app, ["skill", "verify", str(manifest_path)])
    assert result.exit_code == 1
    assert "does not verify" in result.stdout
