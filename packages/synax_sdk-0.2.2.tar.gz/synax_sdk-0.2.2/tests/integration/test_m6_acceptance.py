"""End-to-end test of the Milestone 6 acceptance scenario.

The build_plan §Milestone 6 acceptance shows BOTH:

  - Declarative ``synax skill test`` running cases from
    ``test_inputs/<tool>/case_*.yaml``.
  - pytest-based testing using ``MockPlatform`` directly.

This file exercises the verbatim flow + a couple of variants.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from synax_sdk.skill import Skill
from synax_sdk.testing import MockPlatform, run_tool_async
from synax_skill_cli.main import app

pytestmark = pytest.mark.integration
runner = CliRunner()


def _flat(text: str) -> str:
    return " ".join(text.split())


PYPROJECT = """\
[project]
name = "greet-skill"
version = "0.1.0"

[tool.synax]
entry_point = "greet_skill:skill"
"""

SKILL_SRC = """\
from synax_sdk import Skill, secrets, logger

skill = Skill(
    name="greet-skill",
    version="0.1.0",
    description="Greeting demo",
    capabilities=["secrets:GREETING"],
    secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
)

@skill.tool(description="Greet someone")
async def greet(name: str) -> str:
    \"\"\"Greet.

    Args:
        name: who.
    \"\"\"
    word = await secrets.get("GREETING")
    logger.info(f"greeted {name}", extra={"who": name})
    return f"{word}, {name}"
"""


@pytest.fixture
def project_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "greet_skill.py").write_text(SKILL_SRC, encoding="utf-8")
    monkeypatch.chdir(root)
    return root


def _write_case(path: Path, content: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(content), encoding="utf-8")


# ---------------------------------------------------------------------------
# Declarative flow — build_plan acceptance example
# ---------------------------------------------------------------------------
def test_declarative_acceptance_flow(project_dir: Path) -> None:
    """Verbatim build_plan.md §M6 declarative acceptance example."""
    _write_case(
        project_dir / "test_inputs" / "greet" / "case_basic.yaml",
        {
            "input": {"name": "World"},
            "secrets": {"GREETING": "Hello"},
            "expected_output": "Hello, World",
        },
    )
    result = runner.invoke(app, ["skill", "test"])
    assert result.exit_code == 0, result.stdout
    flat = _flat(result.stdout)
    assert "PASS" in flat
    assert "case_basic" in flat
    assert "All 1 test case(s) passed" in flat


def test_declarative_with_full_assertions(project_dir: Path) -> None:
    """Exercise every expected_* field — output, schema, logs, secret accesses."""
    _write_case(
        project_dir / "test_inputs" / "greet" / "case_full.yaml",
        {
            "input": {"name": "Alice"},
            "secrets": {"GREETING": "Hi"},
            "expected_output": "Hi, Alice",
            "expected_output_schema": {"type": "string"},
            "expected_logs": [
                {"level": "info", "message_contains": "greeted Alice"},
            ],
            "expected_secret_accesses": ["GREETING"],
        },
    )
    result = runner.invoke(app, ["skill", "test"])
    assert result.exit_code == 0, result.stdout
    assert "PASS" in _flat(result.stdout)


def test_declarative_failure_surfaces_diagnostics(project_dir: Path) -> None:
    _write_case(
        project_dir / "test_inputs" / "greet" / "case_bad.yaml",
        {
            "input": {"name": "X"},
            "secrets": {"GREETING": "Hi"},
            "expected_output": "WRONG",
        },
    )
    result = runner.invoke(app, ["skill", "test"])
    assert result.exit_code == 1
    flat = _flat(result.stdout)
    assert "FAIL" in flat
    assert "case_bad" in flat
    assert "expected_output" in flat


# ---------------------------------------------------------------------------
# pytest-based flow — build_plan acceptance example
# ---------------------------------------------------------------------------
def test_pytest_based_pattern_works(project_dir: Path) -> None:
    """The build_plan §M6 acceptance shows a pytest-style test using MockPlatform.

    Here we run that pattern inline (same module) rather than via pytester
    to keep this test focused on the contract rather than fixture loading.
    """
    skill = Skill(
        name="hello",
        version="1.0.0",
        description=".",
        capabilities=["secrets:GREETING"],
        secrets=[{"name": "GREETING", "type": "generic_string", "description": "."}],
    )

    from synax_sdk import secrets

    @skill.tool(description="Greet")
    async def greet(name: str) -> str:
        """Greet.

        Args:
            name: who.
        """
        g = await secrets.get("GREETING")
        return f"{g}, {name}"

    mock = MockPlatform()
    mock.secrets.set("GREETING", "Hi")
    with mock.activate():
        import asyncio

        result = asyncio.run(greet(name="World"))
    assert result == "Hi, World"


async def test_pytest_async_pattern_with_runner(project_dir: Path) -> None:
    """The recommended async pattern: MockPlatform + run_tool_async."""
    skill = Skill(
        name="hello",
        version="1.0.0",
        description=".",
        capabilities=["secrets:KEY"],
        secrets=[{"name": "KEY", "type": "api_key", "description": "."}],
    )

    from synax_sdk import secrets

    @skill.tool(description="Lookup")
    async def lookup(key: str) -> str:
        """Lookup.

        Args:
            key: in.
        """
        v = await secrets.get("KEY")
        return f"{v}/{key}"

    mock = MockPlatform()
    mock.secrets.set("KEY", "value")
    with mock.activate():
        result = await run_tool_async(skill.tools[0], key="abc")
    assert result == "value/abc"
