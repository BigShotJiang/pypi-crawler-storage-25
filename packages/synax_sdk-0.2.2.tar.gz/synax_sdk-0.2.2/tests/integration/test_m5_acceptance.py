"""End-to-end test of the Milestone 5 acceptance scenario.

The build_plan §Milestone 5 acceptance says a developer can:

  export SYNAX_PUBLISH_TOKEN=spt_abc123...
  synax skill publish --target https://synax.mycompany.com

This file wires the whole flow together: build, publish, parse the
result. It also covers the failure messages the build_plan calls out
(auth failure, validation failure, version conflict).
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from synax_sdk.publishing import KEY_REGISTER_PATH, PUBLISH_PATH
from synax_sdk.signing import KeyStore, generate_keypair
from synax_skill_cli.commands import keys as keys_module
from synax_skill_cli.main import app

pytestmark = pytest.mark.integration
runner = CliRunner()


def _flat(text: str) -> str:
    return " ".join(text.split())


TARGET = "https://synax.mycompany.com"
PUBLISH_URL = TARGET + PUBLISH_PATH
KEYS_URL = TARGET + KEY_REGISTER_PATH

PYPROJECT = """\
[project]
name = "hello-skill"
version = "0.1.0"

[tool.synax]
entry_point = "hello_skill:skill"
"""

SKILL_SRC = """\
from synax_sdk import Skill

skill = Skill(
    name="hello-skill",
    version="0.1.0",
    description="A trivial skill",
)

@skill.tool(description="Greet")
def greet(name: str) -> str:
    \"\"\"Greet.

    Args:
        name: who.
    \"\"\"
    return f"hello, {name}"
"""


@pytest.fixture
def project_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "pyproject.toml").write_text(PYPROJECT, encoding="utf-8")
    (root / "hello_skill.py").write_text(SKILL_SRC, encoding="utf-8")
    monkeypatch.chdir(root)
    return root


@pytest.fixture
def isolated_setup(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> dict[str, object]:
    """Set up a tmp keystore + token env var + isolated user config path."""
    store = KeyStore(root=tmp_path / "keys")
    store.save(generate_keypair())
    monkeypatch.setattr(keys_module, "_store", lambda: store)
    monkeypatch.setattr("synax_sdk.signing.KeyStore.default", classmethod(lambda cls: store))
    monkeypatch.setenv("SYNAX_PUBLISH_TOKEN", "spt_test_token")
    monkeypatch.setattr(
        "synax_skill_cli.utils.config.USER_CONFIG_PATH",
        tmp_path / "nope.yaml",
    )
    return {"store": store}


# ---------------------------------------------------------------------------
# The full acceptance flow
# ---------------------------------------------------------------------------
@respx.mock
def test_build_plan_m5_acceptance_flow(
    project_dir: Path,
    isolated_setup: dict[str, object],
) -> None:
    """Verbatim from build_plan.md §Milestone 5 Acceptance.

    `synax skill publish --target https://...` succeeds, surfaces
    progress, prints the marketplace URL.
    """
    success = {
        "skill_id": "11111111-2222-3333-4444-555555555555",
        "skill_version_id": "66666666-7777-8888-9999-000000000000",
        "status": "registered",
        "marketplace_url": "https://synax.mycompany.com/marketplace/skills/hello",
    }
    route = respx.post(PUBLISH_URL).mock(return_value=httpx.Response(200, json=success))

    result = runner.invoke(app, ["skill", "publish", "--target", TARGET])

    assert result.exit_code == 0, result.stdout
    flat = _flat(result.stdout)
    assert "Published" in flat
    assert "registered" in flat
    assert "marketplace" in flat or "https://synax.mycompany.com/marketplace" in flat
    # The platform got exactly one request, with the expected shape.
    assert route.call_count == 1
    body = json.loads(route.calls.last.request.content)
    assert "manifest_yaml" in body
    assert "implementation_artifact_b64" in body
    assert body["implementation_hash"].startswith("sha256:")
    auth = route.calls.last.request.headers["Authorization"]
    assert auth == "Bearer spt_test_token"


# ---------------------------------------------------------------------------
# Each documented failure mode (build_plan calls these out explicitly)
# ---------------------------------------------------------------------------
@respx.mock
def test_auth_failure_message(
    project_dir: Path,
    isolated_setup: dict[str, object],
) -> None:
    respx.post(PUBLISH_URL).mock(
        return_value=httpx.Response(401, json={"message": "Invalid token"})
    )
    result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
    assert result.exit_code == 1
    flat = _flat(result.stdout)
    assert "Authentication failed" in flat
    assert "Invalid token" in flat


@respx.mock
def test_manifest_validation_failure(
    project_dir: Path,
    isolated_setup: dict[str, object],
) -> None:
    respx.post(PUBLISH_URL).mock(
        return_value=httpx.Response(
            400,
            json={
                "error_code": "manifest_invalid",
                "message": "Manifest validation failed",
                "details": {"field": "tools[0].parameters", "issue": "missing type"},
            },
        )
    )
    result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
    assert result.exit_code == 1
    assert "rejected manifest" in _flat(result.stdout)


@respx.mock
def test_version_conflict_message(
    project_dir: Path,
    isolated_setup: dict[str, object],
) -> None:
    respx.post(PUBLISH_URL).mock(
        return_value=httpx.Response(
            409,
            json={
                "error_code": "version_already_published",
                "message": "Version 0.1.0 of hello-skill already exists. Bump the version.",
                "details": {"existing_version_id": "abc-123"},
            },
        )
    )
    result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
    assert result.exit_code == 1
    flat = _flat(result.stdout)
    assert "already published" in flat
    assert "Bump the version" in flat


@respx.mock
def test_transient_5xx_then_success(
    project_dir: Path,
    isolated_setup: dict[str, object],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """5xx response retries up to max_retries; eventually succeeds."""
    # Patch sleep so retry backoff is instant in the test.
    monkeypatch.setattr("synax_sdk.publishing.time.sleep", lambda _: None)
    success = {
        "skill_id": "x",
        "skill_version_id": "y",
        "status": "registered",
    }
    route = respx.post(PUBLISH_URL).mock(
        side_effect=[
            httpx.Response(500, json={"message": "boom"}),
            httpx.Response(503, json={"message": "still boom"}),
            httpx.Response(200, json=success),
        ]
    )
    result = runner.invoke(app, ["skill", "publish", "--target", TARGET])
    assert result.exit_code == 0, result.stdout
    assert route.call_count == 3


# ---------------------------------------------------------------------------
# keys register full flow
# ---------------------------------------------------------------------------
@respx.mock
def test_keys_register_acceptance_flow(isolated_setup: dict[str, object]) -> None:
    route = respx.post(KEYS_URL).mock(
        return_value=httpx.Response(
            200, json={"registration_id": "reg-001", "status": "pending_approval"}
        )
    )
    result = runner.invoke(
        app,
        ["keys", "register", "--target", TARGET, "--namespace", "mycompany"],
    )
    assert result.exit_code == 0, result.stdout
    flat = _flat(result.stdout)
    assert "Registered key" in flat
    assert "reg-001" in flat
    assert "pending_approval" in flat
    body = json.loads(route.calls.last.request.content)
    assert body["namespace"] == "mycompany"
    assert body["fingerprint"].startswith("sha256:")
