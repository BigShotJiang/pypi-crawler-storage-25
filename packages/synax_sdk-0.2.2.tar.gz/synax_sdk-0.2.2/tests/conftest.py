"""Shared pytest configuration. pytest-asyncio mode is configured in pyproject.toml."""
