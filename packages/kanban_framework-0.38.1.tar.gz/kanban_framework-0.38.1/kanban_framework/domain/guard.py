from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

from kanban_framework.types import Task, Phase
from kanban_framework.infra.filesystem import Filesystem
from kanban_framework.infra.config import Config
from kanban_framework.infra.scheduler import Scheduler


@dataclass
class CheckResult:
    passed: bool
    failures: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @staticmethod
    def combine(results: list[CheckResult]) -> CheckResult:
        all_failures: list[str] = []
        all_warnings: list[str] = []
        for r in results:
            all_failures.extend(r.failures)
            all_warnings.extend(r.warnings)
        return CheckResult(
            passed=len(all_failures) == 0,
            failures=all_failures,
            warnings=all_warnings,
        )


def _auto_collect_scores(fs: Filesystem, task_id: str, iteration: int) -> dict | None:
    """Auto-extract evaluation scores from review reports when score_history is empty."""
    import json
    report_dir = fs.report_dir(task_id, iteration)
    if not report_dir.is_dir():
        return None

    scores = {}
    reviews_dir = report_dir / "reviews"
    scan_dir = reviews_dir if reviews_dir.is_dir() else report_dir
    for f in scan_dir.iterdir():
        if not f.is_file() or f.suffix != ".json":
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            total = data.get("total") or data.get("score") or data.get("overall")
            role = data.get("role") or f.stem
            if total is not None:
                scores[role] = total
        except (json.JSONDecodeError, OSError):
            continue

    if not scores:
        return None

    avg = sum(scores.values()) / len(scores)
    return {"average": round(avg, 2), "scores": scores}


class Guard:
    def __init__(self, fs: Filesystem, config: Config):
        self._fs = fs
        self._cfg = config

    # Hardcoded fallback when workflow.json lacks required_artifacts
    _DEFAULT_ARTIFACTS: dict[str, list[str]] = {
        "plan": ["spec.md", "task_breakdown.json", "plan/index.md"],
        "plan_review": ["plan_review_report.json"],
        "qa_spec": ["test_spec.md"],
        "spec_review": ["spec_review_report.json"],
        "execute": ["execution_summary.md", "execution_pitfalls.md", "execution_decisions.md"],
        "retrospective": ["retrospective.md", "acceptance.md"],
    }

    def _get_required_artifacts(self, phase: Phase, lightweight: bool = False) -> list[str]:
        """Read required_artifacts from workflow.json; fall back to hardcoded defaults."""
        workflow = self._cfg.workflow
        for p in workflow.get("phases", []):
            if p.get("id") == phase.value:
                artifacts = p.get("required_artifacts")
                if artifacts:
                    return artifacts
        if lightweight and phase == Phase.EXECUTE:
            return ["execution_summary.md"]
        return self._DEFAULT_ARTIFACTS.get(phase.value, [])

    def check_artifacts(self, task: Task, phase: Phase, lightweight: bool = False) -> CheckResult:
        if task.status.value == "draft":
            return CheckResult(passed=True)
        # Evaluate phase: only check evaluation reports (acceptance.md checked in retrospective)
        if phase == Phase.EVALUATE:
            return self.check_evaluation(task, task.iteration, lightweight=lightweight)

        required = self._get_required_artifacts(phase, lightweight=lightweight)
        if not required:
            return CheckResult(passed=True)

        results = [self._check_file(task, filename) for filename in required]
        if phase == Phase.EXECUTE:
            results.append(self._check_test_files(task))
            results.append(self._check_tdd_evidence(task))
            results.append(self._check_knowledge_artifact(task, "execution_pitfalls.md",
                "Execute phase should produce at least one pitfall note. "
                "Write execution_pitfalls.md or use kanban knowledge add."))
        if phase == Phase.RETROSPECTIVE:
            results.append(self._check_knowledge_artifact(task, "knowledge_extracted.json",
                "Retrospective phase should produce knowledge_extracted.json. "
                "Run kanban knowledge extract."))
        combined = CheckResult.combine(results)

        if phase == Phase.EXECUTE and task.worktree_path is None:
            # Check if project is a git repo at all (#210)
            is_git_repo = (self._fs._root / ".git").is_dir()
            if not is_git_repo:
                combined.warnings.append("worktree not set (non-git repo, skipped)")
            elif task.lightweight:
                combined.warnings.append("worktree not set (lightweight mode)")
            else:
                combined.failures.append(
                    "worktree not set — Execute phase requires git worktree isolation. "
                    "Use --lightweight flag only if the task qualifies for lightweight mode."
                )

        return combined

    def check_evaluation(self, task: Task, iteration: int, lightweight: bool = False) -> CheckResult:
        missing = []
        report_dir = self._fs.report_dir(task.id, iteration)
        for role_def in Scheduler.eval_roles(lightweight=lightweight):
            role = role_def["name"]
            # Check reviews/ subdirectory first (#142 restructure), then flat
            report_file = report_dir / "reviews" / f"{role}_report.json"
            if not self._fs.file_exists(report_file):
                report_file = report_dir / f"{role}_report.json"
            if not self._fs.file_exists(report_file):
                missing.append(role)

        return CheckResult(
            passed=len(missing) == 0,
            failures=[f"missing {r} report" for r in missing],
        )

    def check_plan_quality(self, task: Task, report_dir: Path) -> CheckResult:
        import json as _json
        td = self._fs.task_dir(task.id)
        spec_file = td / "spec.md"
        breakdown_file = td / "task_breakdown.json"
        index_file = td / "plan" / "index.md"

        failures: list[str] = []

        # File existence
        if not self._fs.file_exists(spec_file):
            failures.append("spec.md missing")
        if not self._fs.file_exists(breakdown_file):
            failures.append("task_breakdown.json missing")
        if not self._fs.file_exists(index_file):
            failures.append("plan/index.md missing")

        if failures:
            return CheckResult(passed=False, failures=failures)

        # Parse task_breakdown.json
        try:
            breakdown_data = _json.loads(breakdown_file.read_text(encoding="utf-8"))
        except (ValueError, OSError) as e:
            return CheckResult(passed=False, failures=[f"task_breakdown.json invalid: {e}"])

        subtasks = breakdown_data.get("subtasks", [])
        if not subtasks:
            failures.append("task_breakdown.json has no subtasks")

        # Verify each subtask has a plan file
        plan_dir = td / "plan"
        subtask_ids = []
        for st in subtasks:
            st_id = st.get("id", "")
            if not st_id:
                failures.append("subtask missing 'id' field")
                continue
            subtask_ids.append(st_id)
            # Check plan file exists (ST-NNN_*.md pattern)
            plan_files = list(plan_dir.glob(f"{st_id}_*.md"))
            if not plan_files:
                failures.append(f"plan/{st_id}_*.md missing for subtask {st_id}")

        # Verify index.md references subtasks
        try:
            index_content = index_file.read_text(encoding="utf-8")
        except OSError:
            index_content = ""
        if subtask_ids and index_content:
            for st_id in subtask_ids:
                if st_id not in index_content:
                    failures.append(f"index.md missing reference to {st_id}")
                    break

        # Check for circular dependencies
        if subtask_ids:
            dep_graph = {st_id: [] for st_id in subtask_ids}
            for st in subtasks:
                st_id = st.get("id", "")
                for dep in st.get("dependencies", []):
                    if dep in dep_graph:
                        dep_graph[st_id].append(dep)
            if self._has_cycle(dep_graph):
                failures.append("circular dependency detected in task_breakdown.json")

        return CheckResult(passed=len(failures) == 0, failures=failures)

    @staticmethod
    def _has_cycle(graph: dict[str, list[str]]) -> bool:
        visited: set[str] = set()
        stack: set[str] = set()

        def dfs(node: str) -> bool:
            if node in stack:
                return True
            if node in visited:
                return False
            visited.add(node)
            stack.add(node)
            for dep in graph.get(node, []):
                if dfs(dep):
                    return True
            stack.remove(node)
            return False

        return any(dfs(n) for n in graph)

    def check_spec(self, task: Task, report_dir: Path) -> CheckResult:
        spec_file = self._fs.task_dir(task.id) / "test_spec.md"
        if not self._fs.file_exists(spec_file):
            return CheckResult(passed=False, failures=["test_spec.md missing"])
        if spec_file.stat().st_size == 0:
            return CheckResult(passed=False, failures=["test_spec.md is empty"])
        # IR-119: verify acceptance criteria have test case coverage
        task_spec_file = self._fs.task_dir(task.id) / "spec.md"
        if self._fs.file_exists(task_spec_file):
            spec_content = spec_file.read_text(encoding="utf-8")
            req_content = task_spec_file.read_text(encoding="utf-8")
            warnings: list[str] = []
            import re
            ac_section = re.search(r'## 验收标准\n\n(.*?)(?:\n##|\Z)', req_content, re.DOTALL)
            if ac_section:
                for line in ac_section.group(1).split('\n'):
                    line = line.strip()
                    if line.startswith('- AC-'):
                        ac_id = line.split(':', 1)[0].lstrip('- ').strip()
                        ac_text = line.split(':', 1)[1].strip()[:60] if ':' in line else line
                        if ac_text.lower() not in spec_content.lower():
                            warnings.append(f"{ac_id} not covered by test spec")
            if warnings:
                return CheckResult(passed=True, warnings=warnings)
        return CheckResult(passed=True)

    def check_parallel_conflicts(self, task: Task) -> CheckResult:
        breakdown_file = self._fs.task_dir(task.id) / "task_breakdown.json"
        if not self._fs.file_exists(breakdown_file):
            return CheckResult(passed=False, failures=["task_breakdown.json missing"])

        import json
        data = json.loads(breakdown_file.read_text(encoding="utf-8"))
        subtasks = data.get("subtasks", [])

        parallelizable = [
            s for s in subtasks
            if s.get("parallelizable") and not s.get("dependencies")
        ]
        conflicts = []
        for i in range(len(parallelizable)):
            for j in range(i + 1, len(parallelizable)):
                a_files = set(parallelizable[i].get("file_ownership", []))
                b_files = set(parallelizable[j].get("file_ownership", []))
                overlap = a_files & b_files
                if overlap:
                    conflicts.append(
                        f"{parallelizable[i]['id']} <-> {parallelizable[j]['id']}: "
                        f"{', '.join(sorted(overlap))}"
                    )

        if conflicts:
            return CheckResult(
                passed=False,
                failures=[f"parallel conflict: {c}" for c in conflicts],
            )
        return CheckResult(passed=True)

    def check_cross_task_conflicts(self) -> CheckResult:
        """Check file ownership conflicts across all active (non-archived) tasks."""
        import json
        conflicts = []
        task_files = {}

        # Scan all task.json files in tasks/ directory
        tasks_dir = self._fs.kanban_dir / "tasks"
        if not tasks_dir.exists():
            return CheckResult(passed=True, warnings=["no tasks directory"])

        for tf in tasks_dir.glob("TASK-*.json"):
            data = json.loads(tf.read_text(encoding="utf-8"))
            tid = data.get("id", tf.stem)
            status = data.get("status", "")
            if status in ("archived", "cancelled"):
                continue

            bf = self._fs.task_dir(tid) / "task_breakdown.json"
            if not self._fs.file_exists(bf):
                continue
            breakdown = json.loads(bf.read_text(encoding="utf-8"))
            all_files = set()
            for st in breakdown.get("subtasks", []):
                for f in st.get("file_ownership", []):
                    all_files.add(f)
            if all_files:
                task_files[tid] = all_files

        tids = sorted(task_files.keys())
        for i in range(len(tids)):
            for j in range(i + 1, len(tids)):
                overlap = task_files[tids[i]] & task_files[tids[j]]
                if overlap:
                    conflicts.append(
                        f"{tids[i]} <-> {tids[j]}: {', '.join(sorted(overlap))}"
                    )

        if conflicts:
            return CheckResult(
                passed=False,
                failures=[f"cross-task conflict: {c}" for c in conflicts],
            )
        return CheckResult(passed=True)

    def check_phase_completeness(self, task: Task, lightweight: bool = False) -> CheckResult:
        """Verify no phases were skipped in the task's history.

        Compares the task's history against PHASE_ORDER —
        every phase before the current one must appear in history.
        """
        from kanban_framework.infra.scheduler import Scheduler
        order = Scheduler.LIGHTWEIGHT_PHASE_ORDER if lightweight else Scheduler.PHASE_ORDER
        completed_phases = {
            h["phase"] for h in task.history
            if h.get("status") == "completed"
        }
        missing = []
        for p in order:
            if p == task.phase:
                break
            if p.value not in completed_phases:
                missing.append(p.value)

        if missing:
            return CheckResult(
                passed=False,
                failures=[f"skipped phases: {', '.join(missing)}"],
            )
        return CheckResult(passed=True)

    def check_brainstorming(self, task: Task) -> CheckResult:
        """IR-16: Verify brainstorming was completed — spec.md must exist and be non-empty."""
        spec_file = self._fs.task_dir(task.id) / "spec.md"
        if not self._fs.file_exists(spec_file):
            return CheckResult(
                passed=False,
                failures=["spec.md missing — Plan Step A (superpowers:brainstorming) must be completed before plan_review"],
            )
        if spec_file.stat().st_size == 0:
            return CheckResult(
                passed=False,
                failures=["spec.md is empty — brainstorming must produce a non-empty spec document"],
            )
        return CheckResult(passed=True)

    def check_retrospective(self, task: Task) -> CheckResult:
        retro_file = self._fs.task_dir(task.id) / "retrospective.md"
        accept_file = self._fs.task_dir(task.id) / "acceptance.md"

        failures = []
        if not self._fs.file_exists(retro_file):
            failures.append("retrospective.md missing")
        elif retro_file.stat().st_size == 0:
            failures.append("retrospective.md is empty")

        if not self._fs.file_exists(accept_file):
            failures.append("acceptance.md missing")
        elif accept_file.stat().st_size == 0:
            failures.append("acceptance.md is empty")

        return CheckResult(passed=len(failures) == 0, failures=failures)

    def check_evaluation_score(self, task: Task) -> CheckResult:
        """Check if evaluation score meets pass_threshold.

        Uses IterationDecider to determine action:
        - PASS → passed=True
        - MAX_ITER → passed=True (forced user_decision per IR-17)
        - HOT/FULL → passed=False with iteration suggestion
        """
        from kanban_framework.domain.self_improve import IterationDecider

        if not task.score_history:
            # Auto-collect scores from review reports (fix #210)
            entry = _auto_collect_scores(self._fs, task.id, task.iteration)
            if entry:
                task.score_history.append(entry)
            else:
                return CheckResult(passed=False, failures=["no score_history recorded"])

        entry = task.score_history[-1]
        # Support multiple key names (#181): average, overall, score
        avg_score = entry.get("average") or entry.get("overall") or entry.get("score")
        if avg_score is None:
            return CheckResult(passed=False, failures=[
                f"score_history entry missing score key (tried 'average'/'overall'/'score'), "
                f"got keys: {sorted(entry.keys())}"
            ])
        pass_threshold = self._cfg.pass_threshold
        max_iterations = self._cfg.max_iterations

        action = IterationDecider.decide(
            avg_score, task.iteration, max_iterations, pass_threshold
        )

        if action.value in ("user_decision", "max_iterations"):
            warnings = []
            if action.value == "max_iterations":
                warnings.append(
                    f"max iterations ({max_iterations}) reached, forcing user_decision"
                )
            return CheckResult(passed=True, warnings=warnings)

        return CheckResult(
            passed=False,
            failures=[
                f"score {avg_score} < threshold {pass_threshold}, "
                f"auto-iteration required: {action.value}"
            ],
        )

    def batch_check(
        self, task: Task, report_dir: Path
    ) -> dict[str, CheckResult]:
        """Run multiple independent guard checks and return results by name.

        Each check runs independently -- one failure does not block others.
        """
        return {
            "check_artifacts": self.check_artifacts(task, task.phase, lightweight=task.lightweight),
            "check_plan_quality": self.check_plan_quality(task, report_dir),
            "check_parallel_conflicts": self.check_parallel_conflicts(task),
            "check_phase_completeness": self.check_phase_completeness(task, lightweight=task.lightweight),
            "check_brainstorming": self.check_brainstorming(task),
        }

    def batch_check_combined(
        self, task: Task, report_dir: Path
    ) -> CheckResult:
        """Run batch_check and combine all results into single CheckResult."""
        results = self.batch_check(task, report_dir)
        return CheckResult.combine(list(results.values()))

    def _check_knowledge_artifact(self, task: Task, filename: str, hint: str) -> CheckResult:
        """Check a knowledge artifact exists — non-blocking warning by default. (#236)"""
        td = self._fs.task_dir(task.id)
        f = td / filename
        if self._fs.file_exists(f) and f.stat().st_size > 0:
            return CheckResult(passed=True)
        return CheckResult(passed=True, warnings=[f"{filename} missing — {hint}"])

    def _check_file(self, task: Task, filename: str) -> CheckResult:
        task_dir = self._fs.task_dir(task.id)
        candidates = [
            task_dir / filename,
        ]
        iteration_dir = self._fs.iteration_dir(task.id, task.iteration)
        candidates.append(iteration_dir / filename)
        # New subdirectory structure: reviews/ execute/ evaluate/
        candidates.append(iteration_dir / "reviews" / filename)
        candidates.append(iteration_dir / "execute" / filename)
        candidates.append(iteration_dir / "evaluate" / filename)
        # Old report dir (backward compat)
        candidates.append(iteration_dir / "reports" / filename)

        # Also check round-suffixed versions (_r1, _r2, ...) in reviews/
        # for multi-round review phases (#157)
        if filename.endswith("_report.json"):
            base = filename.replace(".json", "")
            reviews_dir = iteration_dir / "reviews"
            if reviews_dir.is_dir():
                for f in sorted(reviews_dir.glob(f"{base}_r*.json")):
                    candidates.append(f)

        for filepath in candidates:
            if self._fs.file_exists(filepath):
                if filepath.stat().st_size == 0:
                    return CheckResult(passed=False, failures=[f"{filename} is empty"])
                return CheckResult(passed=True)

        return CheckResult(passed=False, failures=[f"{filename} missing"])

    def _check_test_files(self, task: Task) -> CheckResult:
        """IR-10: Verify test files exist alongside implementation files."""
        if not task.worktree_path:
            return CheckResult(passed=True)
        wt = Path(task.worktree_path)
        cfg = self._cfg
        output_dir = cfg.raw.get("output_dir", "src")
        code_dir = wt / output_dir
        if not code_dir.exists():
            return CheckResult(passed=True)
        test_patterns = ["test_*.py", "*_test.py", "*.test.js", "*.spec.ts"]
        source_patterns = ["*.py", "*.js", "*.ts"]
        source_files: list[Path] = []
        for pat in source_patterns:
            source_files.extend(code_dir.rglob(pat))
        test_files: list[Path] = []
        for pat in test_patterns:
            test_files.extend(code_dir.rglob(pat))
        if source_files and not test_files:
            return CheckResult(
                passed=False,
                failures=["no test files found — IR-10 requires tests for all code changes"],
            )
        return CheckResult(passed=True)

    def _check_tdd_evidence(self, task: Task) -> CheckResult:
        """Verify TDD evidence table in execution_summary.md.

        Checks that the TDD evidence table exists and each row shows
        RED=FAIL (not PASS), proving tests were written before code.
        """
        iter_dir = self._fs.iteration_dir(task.id, task.iteration)
        summary_file = iter_dir / "execution_summary.md"
        if not self._fs.file_exists(summary_file):
            # Also check execute/ subdirectory (#142 restructure)
            summary_file = iter_dir / "execute" / "execution_summary.md"
        if not self._fs.file_exists(summary_file):
            return CheckResult(
                passed=False,
                failures=["execution_summary.md missing — cannot verify TDD evidence"],
            )
        content = summary_file.read_text(encoding="utf-8")

        # Look for the TDD evidence table header
        if "## TDD 执行证据" not in content:
            return CheckResult(
                passed=False,
                failures=[
                    "TDD evidence table missing in execution_summary.md — "
                    "must contain '## TDD 执行证据' section. Expected format:\n"
                    "## TDD 执行证据\n"
                    "| 功能点 | 测试文件 | RED (Fail) | GREEN (Pass) | 备注 |\n"
                    "|--------|----------|------------|--------------|------|\n"
                    "| feature | test_X.py | FAIL: reason | PASS | note |"
                ],
            )

        # Extract table rows (lines starting with | after the header)
        tdd_section = content.split("## TDD 执行证据")[1]
        if "## " in tdd_section:
            tdd_section = tdd_section.split("## ")[0]

        rows = [line.strip() for line in tdd_section.split("\n")
                if line.strip().startswith("|") and "RED" not in line
                and "---" not in line and "功能点" not in line]

        if not rows:
            return CheckResult(
                passed=False,
                failures=["TDD evidence table has no data rows — each feature point needs a RED→GREEN evidence row"],
            )

        # Check each row for RED=FAIL evidence
        failures = []
        for row in rows:
            cells = [c.strip() for c in row.split("|")[1:-1]]
            if len(cells) < 5:
                continue
            feature = cells[0]
            red_result = cells[2]
            # Regression/coverage tests: RED=PASS is expected (testing existing features)
            is_regression = any(kw in feature.lower() for kw in
                ("regression", "coverage", "验证", "回归", "覆盖率"))
            if is_regression:
                continue  # regression tests may have RED=PASS
            if "PASS" in red_result.upper() and "FAIL" not in red_result.upper():
                failures.append(
                    f"{feature}: RED phase was PASS — test did not fail before implementation, "
                    "TDD not correctly executed (test didn't catch missing feature)"
                )
            elif "FAIL" not in red_result.upper():
                failures.append(
                    f"{feature}: RED phase result unclear — must show FAIL with reason, got '{red_result}'"
                )

        if failures:
            return CheckResult(passed=False, failures=failures)
        return CheckResult(passed=True)
