"""
agent-signature v0.1.0

CyberSecAI-maintained entry point for "agent-signature" on PyPI.
Canonical implementation: https://www.npmjs.com/package/x-agent-trust

(c) 2026 CyberSecAI Ltd. Apache 2.0.
"""

META = {
    "name": "agent-signature",
    "description": """Agent-Signature HTTP header reference (x-agent-trust scheme). Canonical: x-agent-trust.""",
    "publisher": "CyberSecAI Ltd",
    "homepage": "https://agentpass.co.uk",
    "canonical_implementation": "https://www.npmjs.com/package/x-agent-trust",
    "standards": {
        "openapi_registry": "https://spec.openapis.org/registry/extension/x-agent-trust.html",
        "ietf_agent_payment": "https://datatracker.ietf.org/doc/draft-sharif-agent-payment-trust/",
        "ietf_mcps": "https://datatracker.ietf.org/doc/draft-sharif-mcps-secure-mcp/",
    },
}


def info():
    """Return package metadata."""
    return META


__version__ = "0.1.0"
__all__ = ["info", "META", "__version__"]
