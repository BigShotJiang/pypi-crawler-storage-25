from buf.validate import validate_pb2 as _validate_pb2
from common.v1 import property_pb2 as _property_pb2
from geometry.v1 import anchor_pb2 as _anchor_pb2
from validation.v1 import predefined_string_rules_pb2 as _predefined_string_rules_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FeedbackType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FEEDBACK_TYPE_UNSPECIFIED: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_TASK_HIGHLIGHT: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_TASK_PART_HIGHLIGHT: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_TASK_TOOL_HIGHLIGHT: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_TASK_OVERVIEW: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_TASK_INSTRUCTION: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_TASK_CHECKLIST: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ROBOT_PATH: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ROBOT_SILHOUETTE: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ROBOT_WAYPOINTS: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ROBOT_STATUS: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ROBOT_LIGHT: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_MESSAGE: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ICON: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_ZONE: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_PLAY_SOUND: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_RULER: _ClassVar[FeedbackType]
    FEEDBACK_TYPE_HIGHLIGHT: _ClassVar[FeedbackType]

class VisibilityScope(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    VISIBILITY_SCOPE_UNSPECIFIED: _ClassVar[VisibilityScope]
    VISIBILITY_SCOPE_ALWAYS: _ClassVar[VisibilityScope]
    VISIBILITY_SCOPE_LOW_GUIDANCE: _ClassVar[VisibilityScope]
    VISIBILITY_SCOPE_MEDIUM_GUIDANCE: _ClassVar[VisibilityScope]
    VISIBILITY_SCOPE_FULL_GUIDANCE: _ClassVar[VisibilityScope]
FEEDBACK_TYPE_UNSPECIFIED: FeedbackType
FEEDBACK_TYPE_TASK_HIGHLIGHT: FeedbackType
FEEDBACK_TYPE_TASK_PART_HIGHLIGHT: FeedbackType
FEEDBACK_TYPE_TASK_TOOL_HIGHLIGHT: FeedbackType
FEEDBACK_TYPE_TASK_OVERVIEW: FeedbackType
FEEDBACK_TYPE_TASK_INSTRUCTION: FeedbackType
FEEDBACK_TYPE_TASK_CHECKLIST: FeedbackType
FEEDBACK_TYPE_ROBOT_PATH: FeedbackType
FEEDBACK_TYPE_ROBOT_SILHOUETTE: FeedbackType
FEEDBACK_TYPE_ROBOT_WAYPOINTS: FeedbackType
FEEDBACK_TYPE_ROBOT_STATUS: FeedbackType
FEEDBACK_TYPE_ROBOT_LIGHT: FeedbackType
FEEDBACK_TYPE_MESSAGE: FeedbackType
FEEDBACK_TYPE_ICON: FeedbackType
FEEDBACK_TYPE_ZONE: FeedbackType
FEEDBACK_TYPE_PLAY_SOUND: FeedbackType
FEEDBACK_TYPE_RULER: FeedbackType
FEEDBACK_TYPE_HIGHLIGHT: FeedbackType
VISIBILITY_SCOPE_UNSPECIFIED: VisibilityScope
VISIBILITY_SCOPE_ALWAYS: VisibilityScope
VISIBILITY_SCOPE_LOW_GUIDANCE: VisibilityScope
VISIBILITY_SCOPE_MEDIUM_GUIDANCE: VisibilityScope
VISIBILITY_SCOPE_FULL_GUIDANCE: VisibilityScope

class FeedbackMessage(_message.Message):
    __slots__ = ("id", "name", "icon", "description", "type", "visibility_scope", "properties", "config_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_SCOPE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    icon: str
    description: str
    type: FeedbackType
    visibility_scope: VisibilityScope
    properties: _containers.RepeatedCompositeFieldContainer[_property_pb2.Property]
    config_id: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., type: _Optional[_Union[FeedbackType, str]] = ..., visibility_scope: _Optional[_Union[VisibilityScope, str]] = ..., properties: _Optional[_Iterable[_Union[_property_pb2.Property, _Mapping]]] = ..., config_id: _Optional[str] = ...) -> None: ...

class FeedbackMessages(_message.Message):
    __slots__ = ("feedbacks",)
    FEEDBACKS_FIELD_NUMBER: _ClassVar[int]
    feedbacks: _containers.RepeatedCompositeFieldContainer[FeedbackMessage]
    def __init__(self, feedbacks: _Optional[_Iterable[_Union[FeedbackMessage, _Mapping]]] = ...) -> None: ...

class FeedbackAddMessage(_message.Message):
    __slots__ = ("config_id", "name", "icon", "description", "type", "visibility_scope", "robot_id", "anchor")
    CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_SCOPE_FIELD_NUMBER: _ClassVar[int]
    ROBOT_ID_FIELD_NUMBER: _ClassVar[int]
    ANCHOR_FIELD_NUMBER: _ClassVar[int]
    config_id: str
    name: str
    icon: str
    description: str
    type: FeedbackType
    visibility_scope: VisibilityScope
    robot_id: str
    anchor: _anchor_pb2.Anchor
    def __init__(self, config_id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., type: _Optional[_Union[FeedbackType, str]] = ..., visibility_scope: _Optional[_Union[VisibilityScope, str]] = ..., robot_id: _Optional[str] = ..., anchor: _Optional[_Union[_anchor_pb2.Anchor, _Mapping]] = ...) -> None: ...

class FeedbackUpdateMessage(_message.Message):
    __slots__ = ("id", "name", "icon", "description", "visibility_scope")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_SCOPE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    icon: str
    description: str
    visibility_scope: VisibilityScope
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., visibility_scope: _Optional[_Union[VisibilityScope, str]] = ...) -> None: ...

class FeedbackCloneMessage(_message.Message):
    __slots__ = ("original_id", "name", "icon", "description", "visibility_scope")
    ORIGINAL_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_SCOPE_FIELD_NUMBER: _ClassVar[int]
    original_id: str
    name: str
    icon: str
    description: str
    visibility_scope: VisibilityScope
    def __init__(self, original_id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., visibility_scope: _Optional[_Union[VisibilityScope, str]] = ...) -> None: ...
