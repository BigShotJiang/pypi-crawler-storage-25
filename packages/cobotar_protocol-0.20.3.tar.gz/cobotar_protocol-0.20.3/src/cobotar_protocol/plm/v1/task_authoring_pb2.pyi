from geometry.v1 import pose_pb2 as _pose_pb2
from geometry.v1 import vector3_pb2 as _vector3_pb2
from plm.v1 import task_pb2 as _task_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StoredTaskMessage(_message.Message):
    __slots__ = ("id", "name", "icon", "description", "instruction_text", "sequence_number", "part_id", "model_id", "task_type", "target", "approach", "assignment_preference")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_TEXT_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    MODEL_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_TYPE_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    APPROACH_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENT_PREFERENCE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    icon: str
    description: str
    instruction_text: str
    sequence_number: int
    part_id: str
    model_id: str
    task_type: _task_pb2.TaskType
    target: _pose_pb2.Pose
    approach: _vector3_pb2.Vector3
    assignment_preference: _task_pb2.TaskAssignmentPreference
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., instruction_text: _Optional[str] = ..., sequence_number: _Optional[int] = ..., part_id: _Optional[str] = ..., model_id: _Optional[str] = ..., task_type: _Optional[_Union[_task_pb2.TaskType, str]] = ..., target: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., approach: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ..., assignment_preference: _Optional[_Union[_task_pb2.TaskAssignmentPreference, str]] = ...) -> None: ...

class StoredTaskMessages(_message.Message):
    __slots__ = ("tasks",)
    TASKS_FIELD_NUMBER: _ClassVar[int]
    tasks: _containers.RepeatedCompositeFieldContainer[StoredTaskMessage]
    def __init__(self, tasks: _Optional[_Iterable[_Union[StoredTaskMessage, _Mapping]]] = ...) -> None: ...

class NewTaskMessage(_message.Message):
    __slots__ = ("parent_id", "name", "icon", "description", "sequence_number")
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    parent_id: str
    name: str
    icon: str
    description: str
    sequence_number: int
    def __init__(self, parent_id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., sequence_number: _Optional[int] = ...) -> None: ...

class UpdateTaskMessage(_message.Message):
    __slots__ = ("id", "name", "icon", "description", "instruction_text", "sequence_number", "part_id", "model_id", "task_type", "target", "approach", "assignment_preference")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_TEXT_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    MODEL_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_TYPE_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    APPROACH_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENT_PREFERENCE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    icon: str
    description: str
    instruction_text: str
    sequence_number: int
    part_id: str
    model_id: str
    task_type: _task_pb2.TaskType
    target: _pose_pb2.Pose
    approach: _vector3_pb2.Vector3
    assignment_preference: _task_pb2.TaskAssignmentPreference
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., instruction_text: _Optional[str] = ..., sequence_number: _Optional[int] = ..., part_id: _Optional[str] = ..., model_id: _Optional[str] = ..., task_type: _Optional[_Union[_task_pb2.TaskType, str]] = ..., target: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., approach: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ..., assignment_preference: _Optional[_Union[_task_pb2.TaskAssignmentPreference, str]] = ...) -> None: ...
