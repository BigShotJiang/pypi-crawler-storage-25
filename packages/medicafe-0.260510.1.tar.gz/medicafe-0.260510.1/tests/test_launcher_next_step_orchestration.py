#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import time
import unittest
from io import StringIO

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class LauncherNextStepOrchestrationTests(unittest.TestCase):

    def _make_orchestrator(self, non_interactive=False):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        session.non_interactive = non_interactive
        orch = MediCafeOrchestrator(session)
        empty_support_send_manager = MagicMock()
        empty_support_send_manager.list_jobs = MagicMock(return_value=[])
        empty_support_send_manager.preflight_reap_stale_running_jobs = MagicMock(return_value=[])
        empty_support_send_manager._ensure_worker_locked = MagicMock()
        orch._support_send_job_manager = MagicMock(return_value=empty_support_send_manager)
        orch._next_step_assistant_enabled = True
        return orch

    def _attach_temp_cloud_lab(self, orch, temp_root):
        lab_root = os.path.join(temp_root, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir)
        cr = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=lab_root)
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        cr.write_operator_deferred_support_send = MagicMock(return_value=True)
        cr.write_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=True)
        orch._cloud_readiness_service = MagicMock(return_value=cr)
        return lab_root, cr

    def _post_update_state_path(self, lab_root):
        return os.path.join(lab_root, 'reports', 'post_update_cloud_autofollow_state.json')

    def _write_post_update_state(self, lab_root, payload):
        path = self._post_update_state_path(lab_root)
        with open(path, 'w') as handle:
            json.dump(payload, handle)
        return path

    def _read_post_update_state(self, lab_root):
        with open(self._post_update_state_path(lab_root), 'r') as handle:
            return json.load(handle)

    def test_startup_preflight_json_io_failure_routes_to_banner_notice(self):
        orch = self._make_orchestrator(non_interactive=False)
        report = {
            'counts': {'pass': 4, 'warn': 0, 'fail': 1},
            'elapsed_ms': 12,
            'results': [
                {
                    'id': 'json_io',
                    'status': 'FAIL',
                    'message': 'JSON IO probe failed (1 issue(s))',
                    'hint': 'See JSON_IO_DIAGNOSTIC',
                    'details': 'config_dir directory probe failed',
                },
            ],
        }
        captured = StringIO()
        with patch('MediCafe.MediLink_ConfigLoader.log'):
            with patch('sys.stdout', captured):
                orch._handle_startup_preflight_report(report)

        self.assertEqual(captured.getvalue(), '')

        self.assertFalse(orch._json_io_preflight_ok)
        self.assertTrue(any(
            level == 'WARNING' and 'Config/preflight IO diagnostics need attention' in message
            for level, message in orch.startup_notices
        ))

    def test_assistant_disallowed_for_non_interactive(self):
        orch = self._make_orchestrator(non_interactive=True)
        self.assertFalse(orch._assistant_interaction_allowed())

    def test_signal_provider_submission_attempts_counts_retry_candidates(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': temp_root}}, handle)
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = temp_root
            attempts_path = os.path.join(temp_root, 'submission_attempts.jsonl')
            rows = [
                {'claim_key': 'a', 'status': 'submitted', 'custody': 'out_of_custody', 'attempt_at': 1},
                {'claim_key': 'b', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 2},
                {'claim_key': 'c', 'status': 'rejected_277', 'custody': 'returned_to_custody', 'attempt_at': 3},
            ]
            with open(attempts_path, 'w') as handle:
                for row in rows:
                    handle.write(json.dumps(row) + '\n')
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_signal_provider_submission_attempts_uses_latest_claim_attempt(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': temp_root}}, handle)
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = temp_root
            attempts_path = os.path.join(temp_root, 'submission_attempts.jsonl')
            rows = [
                {'claim_key': 'x', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 1},
                {'claim_key': 'x', 'status': 'submitted', 'custody': 'out_of_custody', 'attempt_at': 2},
                {'claim_key': 'y', 'status': 'rejected_277', 'custody': 'returned_to_custody', 'attempt_at': 3},
            ]
            with open(attempts_path, 'w') as handle:
                for row in rows:
                    handle.write(json.dumps(row) + '\n')
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_submission_attempts_respects_local_claims_path(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            claims_root = os.path.join(temp_root, 'claims')
            storage_root = os.path.join(temp_root, 'storage')
            os.makedirs(claims_root)
            os.makedirs(storage_root)
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': claims_root}}, handle)

            attempts_path = os.path.join(claims_root, 'submission_attempts.jsonl')
            with open(attempts_path, 'w') as handle:
                handle.write(json.dumps({'claim_key': 'z', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 1}) + '\n')

            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage_root
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_signal_provider_remittance_ledger_requires_recent_entries(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            ledger_path = os.path.join(temp_root, 'remittance_file_ledger.jsonl')
            old_ts = 1000000000
            with open(ledger_path, 'w') as handle:
                handle.write(json.dumps({'mtime': old_ts}) + '\n')
            payload = orch._signal_provider_remittance_ledger()
            self.assertFalse(payload.get('zdat_pending', False))

            recent_ts = 2000000000
            with patch('MediCafe.launcher.time.time', return_value=recent_ts + 5):
                with open(ledger_path, 'a') as handle:
                    handle.write(json.dumps({'mtime': recent_ts, 'new_records': 1}) + '\n')
                payload2 = orch._signal_provider_remittance_ledger()
            self.assertTrue(payload2.get('zdat_pending'))
            self.assertGreaterEqual(payload2.get('intake_artifacts_new_count', 0), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_remittance_ledger_prefers_explicit_pending_flags(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            ledger_path = os.path.join(temp_root, 'remittance_file_ledger.jsonl')
            now_ts = 2200000000
            with patch('MediCafe.launcher.time.time', return_value=now_ts):
                # Row is recent but does not explicitly indicate pending work.
                with open(ledger_path, 'w') as handle:
                    handle.write(json.dumps({'mtime': now_ts - (3 * 3600)}) + '\n')
                payload = orch._signal_provider_remittance_ledger()
                self.assertFalse(payload.get('zdat_pending', False))

                with open(ledger_path, 'a') as handle:
                    handle.write(json.dumps({'mtime': now_ts - 60, 'new_records': 2}) + '\n')
                payload2 = orch._signal_provider_remittance_ledger()
                self.assertTrue(payload2.get('zdat_pending'))
                self.assertEqual(payload2.get('intake_artifacts_new_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_remittance_ledger_accepts_records_count_rows(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            ledger_path = os.path.join(temp_root, 'remittance_file_ledger.jsonl')
            now_ts = 2300000000
            with patch('MediCafe.launcher.time.time', return_value=now_ts):
                with open(ledger_path, 'w') as handle:
                    handle.write(json.dumps({'mtime': now_ts - 30, 'records_count': 2}) + '\n')
                payload = orch._signal_provider_remittance_ledger()
                self.assertTrue(payload.get('zdat_pending'))
                self.assertEqual(payload.get('intake_artifacts_new_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_collect_startup_signals_uses_canonical_providers(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_assistant_signal_providers') as provider_builder:
            provider_builder.return_value = [
                lambda: {'zdat_pending': True},
                lambda: {'retry_queue_pending_count': 3},
            ]
            signals = orch._collect_startup_assistant_signals()
            self.assertTrue(signals.get('zdat_pending'))
            self.assertEqual(signals.get('retry_queue_pending_count'), 3)

    def test_maybe_offer_next_step_skips_when_non_interactive(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=True)
        with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
            orch._maybe_offer_next_step_assistant('medibot', 0)
            prompt_mock.assert_not_called()

    def test_run_update_flow_launches_updater_window_without_maximize_flag(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.environment['upgrade_medicafe'] = os.path.join(
            tempfile.gettempdir(), 'update_medicafe.py'
        )
        with open(orch.environment['upgrade_medicafe'], 'w') as handle:
            handle.write('print("noop")\n')

        with patch.object(orch, '_build_update_runner', return_value=r'C:\Temp\runner.cmd'):
            with patch('MediCafe.launcher.subprocess.Popen') as popen_mock:
                with patch.object(orch, '_exit_after_payer_list_join') as exit_mock:
                    orch.run_update_flow()

        popen_mock.assert_called_once()
        cmd_args = popen_mock.call_args[0][0]
        self.assertEqual(cmd_args[:6], ['cmd', '/c', 'start', 'MediCafe Updater', 'cmd', '/c'])
        self.assertEqual(cmd_args[-1], r'C:\Temp\runner.cmd')
        self.assertNotIn('/MAX', cmd_args)
        self.assertFalse(popen_mock.call_args[1].get('shell', False))
        exit_mock.assert_called_once()

    def test_build_update_runner_relaunches_medibot_maximized(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_update_runner_')
        script_path = os.path.join(temp_root, 'update_medicafe.py')
        try:
            with open(script_path, 'w') as handle:
                handle.write('print("noop")\n')
            with patch.dict(os.environ, {'TEMP': temp_root}, clear=False):
                runner_path = orch._build_update_runner(script_path)
            self.assertTrue(runner_path and os.path.exists(runner_path))
            with open(runner_path, 'r') as handle:
                runner_text = handle.read()
            self.assertIn('start "MediBot" /MAX !MEDIBOT_PATH!', runner_text)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_handle_fatal_error_can_offer_update_recovery(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_collect_error_bundle', return_value=None):
            with patch.object(orch, '_prompt', return_value='2'):
                with patch.object(orch, '_launch_update_runner_and_exit', return_value=True) as launch_mock:
                    orch.handle_fatal_error(RuntimeError('boom'))
        launch_mock.assert_called_once()


    def test_maybe_offer_next_step_skips_when_child_marked_user_exit(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
            with patch.object(orch, '_execute_assistant_action') as exec_mock:
                orch._maybe_offer_next_step_assistant(
                    'medilink',
                    0,
                    extra_signals={'user_exit_requested': True},
                )
        prompt_mock.assert_not_called()
        exec_mock.assert_not_called()

    def test_run_medicafe_command_records_child_user_exit_signal(self):
        from MediCafe.action_intent import ACTION_EXIT_SENTINEL_ENV
        orch = self._make_orchestrator(non_interactive=False)

        def _fake_call(_args, cwd=None, env=None):
            if env is None:
                raise AssertionError('expected subprocess env')
            sentinel = env.get(ACTION_EXIT_SENTINEL_ENV, '')
            self.assertTrue(sentinel)
            with open(sentinel, 'w') as handle:
                handle.write('reason=user_exit\n')
            return 0

        with patch.object(orch, '_run_preflight_if_needed', return_value=True):
            with patch('MediCafe.launcher.subprocess.call', side_effect=_fake_call):
                rc = orch.run_medicafe_command('medilink')

        self.assertEqual(rc, 0)
        self.assertEqual(
            orch._consume_last_command_assistant_signals('medilink'),
            {'child_exit_reason': 'user_exit', 'user_exit_requested': True},
        )
        self.assertEqual(orch._consume_last_command_assistant_signals('medilink'), {})

    def test_startup_assistant_skips_without_actionable_signals(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        orch._startup_assistant_presented = False
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_collect_startup_assistant_signals', return_value={}):
                with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
                    result = orch._maybe_offer_startup_assistant()
                    self.assertFalse(result)
                    prompt_mock.assert_not_called()




    def test_assistant_mode_env_auto_contextual_enables_without_legacy_flag(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        with patch.dict(os.environ, {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'auto_contextual'}, clear=False):
            orch = MediCafeOrchestrator(session)
        self.assertEqual(orch._assistant_mode_or_default(), 'auto_contextual')
        self.assertTrue(orch._next_step_assistant_enabled)

    def test_auto_contextual_skips_prompt_for_safe_high_confidence_recommendation(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        orch._assistant_mode = 'auto_contextual'
        orch._next_step_assistant_enabled = True
        captured = StringIO()
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_refresh_transition_assistant_signals', return_value={'retry_queue_pending_count': 1}):
                with patch.object(orch, '_execute_assistant_action', return_value=0) as exec_mock:
                    with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
                        with patch('sys.stdout', captured):
                            orch._maybe_offer_next_step_assistant('claims_status', 0)
        prompt_mock.assert_not_called()
        exec_mock.assert_called()
        self.assertIn('Why:', captured.getvalue())
        self.assertIn('retry queue has pending work', captured.getvalue())

    def test_transition_path_refreshes_signals_each_time(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_refresh_transition_assistant_signals', return_value={}) as refresh_mock:
                with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation', return_value={'action_id': 'main_menu'}):
                    orch._maybe_offer_next_step_assistant('medibot', 0)
        refresh_mock.assert_called_once()

    def test_main_menu_loop_startup_assistant_checked_when_header_skipped(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_print_welcome_block'):
            with patch.object(orch, '_print_main_menu_options'):
                with patch.object(orch, '_maybe_offer_startup_assistant', side_effect=[False, False]) as startup_mock:
                    with patch.object(orch, '_get_menu_choice', return_value='exit'):
                        with patch.object(orch, '_mark_clean_exit'):
                            with patch.object(orch, '_join_payer_list_thread'):
                                orch.main_menu_loop(show_header_on_first=False)
        startup_mock.assert_called()

    def test_post_update_autofollow_baselines_first_observed_version(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_baseline_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            with patch.object(orch, '_run_post_update_cloud_autofollow') as run_mock:
                started = orch._start_post_update_cloud_autofollow_thread('2.0.0')
            self.assertFalse(started)
            run_mock.assert_not_called()
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('installed_version'), '2.0.0')
            self.assertEqual(state.get('status'), 'idle')
            self.assertEqual(state.get('stage'), 'baseline_recorded')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_installed_version_change_starts_post_update_autofollow_thread(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_changed_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.0.0',
                'previous_installed_version': '',
                'status': 'succeeded',
                'stage': 'previous_complete',
                'started_at_utc': '',
                'updated_at_utc': '2026-04-15T00:00:00Z',
                'finished_at_utc': '2026-04-15T00:00:01Z',
                'last_reason': 'test',
            })
            with patch.object(orch, '_run_post_update_cloud_autofollow', return_value=True) as run_mock:
                started = orch._start_post_update_cloud_autofollow_thread('1.1.0')
                orch._post_update_autofollow_thread.join(2.0)
            self.assertTrue(started)
            run_mock.assert_called_once_with('1.1.0', '1.0.0')
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('installed_version'), '1.1.0')
            self.assertEqual(state.get('previous_installed_version'), '1.0.0')
            self.assertEqual(state.get('status'), 'evaluating_recommendation')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_same_installed_version_dedupes_post_update_autofollow(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_dedupe_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'succeeded',
                'stage': 'complete',
                'updated_at_utc': '2026-04-15T00:00:00Z',
            })
            with patch.object(orch, '_run_post_update_cloud_autofollow') as run_mock:
                started = orch._start_post_update_cloud_autofollow_thread('1.1.0')
            self.assertFalse(started)
            run_mock.assert_not_called()
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_same_installed_version_recovers_running_post_update_job(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_recover_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_send',
                'stage': 'sending email to support',
                'job_id': 'ssj-abandoned',
                'started_at_utc': '2026-04-14T00:00:00Z',
                'updated_at_utc': '2026-04-14T00:00:00Z',
            })
            manager = MagicMock()
            manager.list_jobs = MagicMock(return_value=[{
                'job_id': 'ssj-abandoned',
                'status': 'running',
                'source': 'post_update_cloud_autofollow',
                'installed_version': '1.1.0',
                'progress_stage': 'sending email to support',
            }])
            manager.recover_jobs_after_launcher_restart = MagicMock(return_value={
                'recovered_job_ids': ['ssj-abandoned'],
                'queued_job_ids': ['ssj-abandoned'],
            })
            orch._support_send_job_manager = MagicMock(return_value=manager)
            with patch.object(orch, '_run_post_update_cloud_autofollow') as run_mock:
                started = orch._start_post_update_cloud_autofollow_thread('1.1.0')
            self.assertFalse(started)
            run_mock.assert_not_called()
            manager.recover_jobs_after_launcher_restart.assert_called_once_with(
                source='post_update_cloud_autofollow',
                installed_version='1.1.0')
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('status'), 'queued_send')
            self.assertEqual(state.get('stage'), 'recovered_after_launcher_restart')
            self.assertEqual(state.get('last_reason'), 'support_send_recovered_after_launcher_restart')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)
    def test_same_installed_version_with_queued_bundle_retries_autofollow(self):
        import zipfile
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_bundle_retry_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            storage = os.path.join(temp_root, 'storage')
            queue_dir = os.path.join(storage, 'reports_queue')
            os.makedirs(queue_dir)
            orch.environment['local_storage_path'] = storage
            bundle_path = os.path.join(queue_dir, 'medicafe_bundle_run_evidence_bundle_20260414_120000.zip')
            with zipfile.ZipFile(bundle_path, 'w') as zf:
                zf.writestr('meta.json', json.dumps({
                    'app_version': '1.1.0',
                    'bundle_kind': 'run_evidence_bundle',
                    'extra_context': {
                        'operator_execution_mode': 'post_update_autofollow',
                        'support_send_job_context': {
                            'source': 'post_update_cloud_autofollow',
                            'installed_version': '1.1.0',
                        },
                    },
                }))
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'failed',
                'stage': 'sending email to support',
                'started_at_utc': '2026-04-14T00:00:00Z',
                'updated_at_utc': '2026-04-14T00:00:00Z',
                'last_reason': 'launcher_closed_before_send_finished',
            })
            with patch.object(orch, '_run_post_update_cloud_autofollow', return_value=True) as run_mock:
                started = orch._start_post_update_cloud_autofollow_thread('1.1.0')
                orch._post_update_autofollow_thread.join(2.0)
            self.assertTrue(started)
            run_mock.assert_called_once_with('1.1.0', '1.0.0')
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('last_reason'), 'retry_incomplete_same_version')
            self.assertEqual(state.get('recovery_bundle_path'), bundle_path)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)
    def test_same_installed_version_with_unsent_queued_bundle_overrides_handled_state(self):
        import zipfile
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_bundle_retry_succeeded_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            storage = os.path.join(temp_root, 'storage')
            queue_dir = os.path.join(storage, 'reports_queue')
            os.makedirs(queue_dir)
            orch.environment['local_storage_path'] = storage
            bundle_path = os.path.join(queue_dir, 'medicafe_bundle_system_health_pack_20260414_120000.zip')
            with zipfile.ZipFile(bundle_path, 'w') as zf:
                zf.writestr('meta.json', json.dumps({
                    'app_version': '1.1.0',
                    'bundle_kind': 'system_health_pack',
                    'extra_context': {
                        'operator_execution_mode': 'post_update_autofollow',
                        'support_send_job_context': {
                            'source': 'post_update_cloud_autofollow',
                            'installed_version': '1.1.0',
                        },
                    },
                }))
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'succeeded',
                'stage': 'started_without_background_tracking',
                'started_at_utc': '2026-04-14T00:00:00Z',
                'updated_at_utc': '2026-04-14T00:00:00Z',
                'finished_at_utc': '2026-04-14T00:00:01Z',
                'last_reason': 'started_without_background_tracking',
            })
            with patch.object(orch, '_run_post_update_cloud_autofollow', return_value=True) as run_mock:
                started = orch._start_post_update_cloud_autofollow_thread('1.1.0')
                orch._post_update_autofollow_thread.join(2.0)
            self.assertTrue(started)
            run_mock.assert_called_once_with('1.1.0', '1.0.0')
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('last_reason'), 'retry_incomplete_same_version')
            self.assertEqual(state.get('recovery_bundle_path'), bundle_path)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)
    def test_update_available_notification_does_not_run_cloud_followthrough(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.update_available_version = '9.9.9'
        with patch.object(orch, '_print_welcome_block'):
            with patch.object(orch, '_print_main_menu_options'):
                with patch.object(orch, '_print_background_support_send_status_banner', return_value=False):
                    with patch.object(orch, '_maybe_offer_startup_assistant', return_value=False):
                        with patch.object(orch, '_start_cloud_recommendation_followthrough') as auto_mock:
                            with patch.object(orch, '_get_menu_choice', return_value='exit'):
                                with patch.object(orch, '_confirm_exit_with_active_support_send_jobs', return_value=True):
                                    with patch.object(orch, '_mark_clean_exit'):
                                        with patch.object(orch, '_join_payer_list_thread'):
                                            orch.main_menu_loop(show_header_on_first=False)
        auto_mock.assert_not_called()

    def test_dispatch_update_blocked_while_post_update_autofollow_active(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_block_update_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_send',
                'stage': 'sending',
                'job_id': '',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            orch._prompt = MagicMock(return_value='')
            with patch.object(orch, 'run_update_flow') as update_mock:
                with patch('sys.stdout', new=StringIO()) as out:
                    result = orch._dispatch_launcher_action('update')
            self.assertEqual(result, 'handled')
            self.assertIn('Post-update developer evidence is still being generated', out.getvalue())
            update_mock.assert_not_called()
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_rollback_blocked_while_post_update_autofollow_active(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_block_rollback_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_diagnostic_action',
                'stage': 'phase_d_dat_smoke',
                'diagnostic_action_id': 'phase_d_dat_smoke',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            orch._prompt = MagicMock(return_value='')
            with patch('MediCafe.launcher.subprocess.call') as call_mock:
                allowed = orch.forced_version_rollback()
            self.assertFalse(allowed)
            call_mock.assert_not_called()
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_medilink_and_medibot_allowed_while_post_update_autofollow_active(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_allows_work_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'queued_send',
                'stage': 'queued',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            with patch.object(orch, 'run_medicafe_command', return_value=0) as run_mock:
                with patch.object(orch, '_maybe_offer_next_step_assistant') as assistant_mock:
                    self.assertEqual(orch._dispatch_launcher_action('medilink'), 'handled')
                    self.assertEqual(orch._dispatch_launcher_action('medibot'), 'handled')
            self.assertEqual(run_mock.call_args_list[0][0][0], 'medilink')
            self.assertEqual(run_mock.call_args_list[1][0][0], 'medibot')
            self.assertEqual(assistant_mock.call_count, 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)
    def test_auto_followthrough_uses_non_blocking_send_enqueue_path(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch._operator_support_send_rec = MagicMock(return_value={
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_action_kind': 'send_bundle',
            'pipeline_running': True,
            'preferred_when_stable': 'system_health',
            'best_now_send': 'system_health',
            'recommended_report_kind': 'system_health_pack',
            'summary_line': 'Recommended: send system health pack.',
        })
        orch._cloud_readiness_service = MagicMock(return_value=MagicMock())
        with patch.object(orch, '_send_bundle_for_operator_type', return_value=True) as send_mock:
            started = orch._start_cloud_recommendation_followthrough(trigger='test-trigger')
        self.assertTrue(started)
        self.assertEqual(send_mock.call_args[1].get('pause_for_ack'), False)

    def test_auto_followthrough_dat_qa_full_block_disables_send_pause(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch._operator_support_send_rec = MagicMock(return_value={
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_action_kind': 'review_dat_qa_full_block',
            'pipeline_running': False,
            'preferred_when_stable': 'run_evidence',
        })
        orch._cloud_readiness_service = MagicMock(return_value=MagicMock())
        with patch.object(orch, '_review_dat_qa_full_block_action', return_value=True) as qa_mock:
            started = orch._start_cloud_recommendation_followthrough(trigger='test-trigger')
        self.assertTrue(started)
        self.assertEqual(qa_mock.call_args[1].get('pause_for_ack'), False)

    def test_auto_followthrough_historical_reprocess_skips_confirmation_prompt(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch._operator_support_send_rec = MagicMock(return_value={
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'pipeline_running': False,
            'preferred_when_stable': 'run_evidence',
        })
        orch._cloud_readiness_service = MagicMock(return_value=MagicMock())
        with patch.object(orch, '_run_historical_phase_d_reprocess_action', return_value=True) as hist_mock:
            started = orch._start_cloud_recommendation_followthrough(trigger='test-trigger')
        self.assertTrue(started)
        self.assertEqual(hist_mock.call_args[1].get('confirm_prompt'), False)

    def test_post_update_historical_reprocess_failure_includes_helper_diagnostics_patch(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_hist_nf_')
        try:
            lab_root, cr = self._attach_temp_cloud_lab(orch, temp_root)
            orch.repo_root = temp_root
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            cr.get_last_historical_phase_d_reprocess_helper_diagnostics = MagicMock(return_value={
                'hist_helper_load_ok': False,
                'hist_helper_stage': 'script_missing',
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
            })
            patch_state = MagicMock()
            with patch.object(orch, '_run_historical_phase_d_reprocess_action', return_value=False):
                with patch.object(orch, '_patch_post_update_autofollow_state', patch_state):
                    with patch('sys.stdout', StringIO()):
                        orch._start_cloud_recommendation_followthrough(
                            trigger='post_update_installed:1.1.0',
                            source='post_update_cloud_autofollow',
                            operator_execution_mode='post_update_autofollow',
                            installed_version='1.1.0',
                            post_update=True,
                        )
            fail_payloads = [
                ca[0][0] for ca in patch_state.call_args_list
                if ca[0]
                and isinstance(ca[0][0], dict)
                and ca[0][0].get('last_reason') == 'diagnostic_action_not_started'
            ]
            self.assertTrue(fail_payloads)
            diag = fail_payloads[-1].get('historical_helper_diagnostics')
            self.assertIsInstance(diag, dict)
            self.assertFalse(diag.get('hist_helper_load_ok'))
            self.assertEqual(diag.get('hist_helper_stage'), 'script_missing')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_dat_smoke_failure_includes_dat_smoke_diagnostics_patch(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_smoke_nf_')
        try:
            lab_root, cr = self._attach_temp_cloud_lab(orch, temp_root)
            orch.repo_root = temp_root
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            cr.read_phase_d_dat_smoke_state = MagicMock(return_value={
                'last_requested_anchor_run_id': 'a1',
                'last_requested_context_run_id': '',
                'last_remediation_issue_code': '',
                'last_started_at_utc': '',
                'last_finished_at_utc': '',
                'last_status': 'failed',
                'last_report_path': '',
                'last_assessment': 'timeout',
                'cooldown_until_utc': '',
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
                'recommended_action_kind': 'phase_d_dat_smoke',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
            })
            patch_state = MagicMock()
            with patch.object(orch, '_run_phase_d_dat_smoke_action', return_value=False):
                with patch.object(orch, '_patch_post_update_autofollow_state', patch_state):
                    with patch('sys.stdout', StringIO()):
                        orch._start_cloud_recommendation_followthrough(
                            trigger='post_update_installed:1.1.0',
                            source='post_update_cloud_autofollow',
                            operator_execution_mode='post_update_autofollow',
                            installed_version='1.1.0',
                            post_update=True,
                        )
            fail_payloads = [
                ca[0][0] for ca in patch_state.call_args_list
                if ca[0]
                and isinstance(ca[0][0], dict)
                and ca[0][0].get('last_reason') == 'diagnostic_action_not_started'
            ]
            self.assertTrue(fail_payloads)
            diag = fail_payloads[-1].get('dat_smoke_diagnostics')
            self.assertIsInstance(diag, dict)
            self.assertEqual(diag.get('last_status'), 'failed')
            self.assertEqual(diag.get('last_assessment'), 'timeout')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_post_update_send_bundle_recommendation_queues_tagged_job(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_send_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            manager = MagicMock()
            manager.enqueue = MagicMock(return_value={
                'accepted': True,
                'job_id': 'ssj-post-update',
                'status': 'queued',
                'policy_decision': 'queued',
                'policy_reason': 'accepted',
            })
            orch._support_send_job_manager = MagicMock(return_value=manager)
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'send_bundle',
                'recommended_action_kind': 'send_bundle',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_source_scope': 'scope-a',
                'recommendation_anchor_run_id': 'run-a',
                'recommendation_live_run_id': 'run-a',
                'why_summary': 'latest run evidence is ready to send',
            })
            captured = StringIO()
            with patch('sys.stdout', captured):
                started = orch._start_cloud_recommendation_followthrough(
                    trigger='post_update_installed:1.1.0',
                    source='post_update_cloud_autofollow',
                    operator_execution_mode='post_update_autofollow',
                    installed_version='1.1.0',
                    post_update=True,
                )
            self.assertTrue(started)
            self.assertIn('Why:', captured.getvalue())
            self.assertIn('latest run evidence is ready to send', captured.getvalue())
            req = manager.enqueue.call_args[0][0]
            self.assertEqual(req.get('source'), 'post_update_cloud_autofollow')
            self.assertEqual(req.get('send_type'), 'run_evidence')
            self.assertEqual(req.get('installed_version'), '1.1.0')
            self.assertEqual(req.get('recommendation_action_kind'), 'send_bundle')
            self.assertIn('version=1.1.0|action=send_bundle', req.get('source_scope_hash'))
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('status'), 'queued_send')
            self.assertEqual(state.get('job_id'), 'ssj-post-update')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_phase_c_probe_starts_for_stale_context_once(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_phase_c_probe_')
        try:
            lab_root, cr = self._attach_temp_cloud_lab(orch, temp_root)
            cr.run_shadow_pipeline = MagicMock(return_value=(True, 'started', {'job_id': 'pipe-1'}))
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as handle:
                json.dump({
                    'last_manifest_sha256': 'sha-b',
                    'phase_c_circuit_open': True,
                }, handle)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as handle:
                json.dump({}, handle)

            started = orch._maybe_start_post_update_phase_c_probe('1.2.3')
            self.assertTrue(started)
            cr.run_shadow_pipeline.assert_called_once_with(orch.repo_root, orch.python_exe, orch.environment)
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('phase_c_probe_status'), 'started')
            self.assertEqual(state.get('phase_c_probe_started_for_version'), '1.2.3')

            started_again = orch._maybe_start_post_update_phase_c_probe('1.2.3')
            self.assertFalse(started_again)
            cr.run_shadow_pipeline.assert_called_once()
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_watchdog_wakes_queued_support_send_worker(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_watchdog_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.2.4',
                'status': 'queued_send',
                'stage': 'queued',
                'job_id': 'ssj-watchdog',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'updated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            manager = MagicMock()
            manager.ensure_pending_worker_liveness = MagicMock(return_value=True)
            manager.list_jobs = MagicMock(return_value=[{
                'job_id': 'ssj-watchdog',
                'status': 'queued',
                'progress_stage': 'queued',
            }])
            manager.preflight_reap_stale_running_jobs = MagicMock(return_value=[])
            manager._ensure_worker_locked = MagicMock()
            orch._support_send_job_manager = MagicMock(return_value=manager)
            started = orch._start_post_update_autofollow_watchdog('1.2.4')
            self.assertTrue(started)
            time.sleep(0.2)
            manager.ensure_pending_worker_liveness.assert_any_call(
                reason='post_update_autofollow_watchdog')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_watchdog_skips_second_thread_while_first_alive(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_watchdog_dedupe_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.0.0',
                'status': 'queued_send',
                'stage': 'queued',
                'job_id': 'ssj-dedupe',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            manager = MagicMock()
            manager.ensure_pending_worker_liveness = MagicMock(return_value=False)
            manager.list_jobs = MagicMock(return_value=[{
                'job_id': 'ssj-dedupe',
                'status': 'queued',
            }])
            orch._support_send_job_manager = MagicMock(return_value=manager)
            with patch.object(orch, '_post_update_autofollow_watchdog_poll_sec', return_value=0.2):
                self.assertTrue(orch._start_post_update_autofollow_watchdog('1.0.0'))
                first = orch._post_update_autofollow_watchdog_thread
                self.assertFalse(orch._start_post_update_autofollow_watchdog('1.0.0'))
                self.assertIs(orch._post_update_autofollow_watchdog_thread, first)
                self.assertTrue(orch._start_post_update_autofollow_watchdog('1.0.1'))
                self.assertIsNot(orch._post_update_autofollow_watchdog_thread, first)
                self.assertEqual(orch._post_update_autofollow_watchdog_version, '1.0.1')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_watchdog_exits_when_status_terminal(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_watchdog_term_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            seq = [
                {
                    'installed_version': '1.0.0',
                    'status': 'queued_send',
                    'job_id': 'j1',
                    'stage': 'queued',
                },
                {
                    'installed_version': '1.0.0',
                    'status': 'succeeded',
                    'job_id': 'j1',
                    'stage': 'done',
                },
            ]

            def _refresh():
                return seq.pop(0) if seq else {}

            manager = MagicMock()
            manager.ensure_pending_worker_liveness = MagicMock(return_value=False)
            orch._support_send_job_manager = MagicMock(return_value=manager)
            with patch.object(orch, '_refresh_post_update_autofollow_state', side_effect=_refresh):
                with patch.object(orch, '_post_update_autofollow_watchdog_poll_sec', return_value=0.02):
                    self.assertTrue(orch._start_post_update_autofollow_watchdog('1.0.0'))
                    orch._post_update_autofollow_watchdog_thread.join(timeout=2.0)
                    self.assertFalse(orch._post_update_autofollow_watchdog_thread.is_alive())
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_watchdog_timeout_patches_diagnostics(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_watchdog_to_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            active = {
                'installed_version': '1.0.0',
                'status': 'queued_send',
                'job_id': 'ssj-to',
                'stage': 'queued',
            }
            manager = MagicMock()
            manager.ensure_pending_worker_liveness = MagicMock(return_value=False)
            orch._support_send_job_manager = MagicMock(return_value=manager)
            patch_calls = []

            def _capture_patch(updates):
                patch_calls.append(dict(updates or {}))
                return dict(active)

            with patch.object(orch, '_refresh_post_update_autofollow_state', return_value=dict(active)):
                with patch.object(orch, '_patch_post_update_autofollow_state', side_effect=_capture_patch):
                    with patch.object(orch, '_post_update_autofollow_watchdog_max_sec', return_value=1):
                        with patch.object(orch, '_post_update_autofollow_watchdog_poll_sec', return_value=0.01):
                            with patch(
                                    'MediCafe.launcher_cloud_readiness_mixin.time.sleep',
                                    lambda _s: None):
                                with patch(
                                        'MediCafe.launcher_cloud_readiness_mixin.time.time',
                                        side_effect=[1000.0, 1000.5, 1002.0]):
                                    self.assertTrue(orch._start_post_update_autofollow_watchdog('1.0.0'))
                                    orch._post_update_autofollow_watchdog_thread.join(timeout=2.0)
            diag_payloads = [
                c.get('watchdog_diagnostics') for c in patch_calls
                if isinstance(c.get('watchdog_diagnostics'), dict)
            ]
            self.assertTrue(diag_payloads)
            self.assertEqual(diag_payloads[-1].get('event'), 'watchdog_timeout')
            self.assertEqual(diag_payloads[-1].get('reason'), 'watchdog_timeout')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_dat_qa_full_block_queues_anchored_run_evidence(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_datqa_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            manager = MagicMock()
            manager.enqueue = MagicMock(return_value={
                'accepted': True,
                'job_id': 'ssj-datqa',
                'status': 'queued',
                'policy_decision': 'queued',
                'policy_reason': 'accepted',
            })
            orch._support_send_job_manager = MagicMock(return_value=manager)
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
                'recommended_action_kind': 'review_dat_qa_full_block',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_source_scope': 'scope-datqa',
                'action_preview': {'anchor_run_id': 'run-datqa', 'phase_d_context_run_id': 'ctx-datqa'},
            })
            started = orch._start_cloud_recommendation_followthrough(
                trigger='post_update_installed:1.1.0',
                source='post_update_cloud_autofollow',
                operator_execution_mode='post_update_autofollow',
                installed_version='1.1.0',
                post_update=True,
            )
            self.assertTrue(started)
            req = manager.enqueue.call_args[0][0]
            self.assertEqual(req.get('send_type'), 'run_evidence')
            self.assertEqual(req.get('anchor_run_id'), 'run-datqa')
            self.assertEqual(req.get('context_run_id'), 'ctx-datqa')
            self.assertEqual(req.get('recommendation_action_kind'), 'review_dat_qa_full_block')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_dat_smoke_recommendation_records_diagnostic_state(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_datsmoke_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
                'recommended_action_kind': 'phase_d_dat_smoke',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
                'why_summary': 'DAT smoke will verify the selected Phase D block',
            })
            with patch.object(orch, '_run_phase_d_dat_smoke_action', return_value=True) as smoke_mock:
                captured = StringIO()
                with patch('sys.stdout', captured):
                    started = orch._start_cloud_recommendation_followthrough(
                        trigger='post_update_installed:1.1.0',
                        source='post_update_cloud_autofollow',
                        operator_execution_mode='post_update_autofollow',
                        installed_version='1.1.0',
                        post_update=True,
                    )
            self.assertTrue(started)
            self.assertIn('Why:', captured.getvalue())
            self.assertIn('DAT smoke will verify the selected Phase D block', captured.getvalue())
            smoke_mock.assert_called_once()
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('status'), 'running_diagnostic_action')
            self.assertEqual(state.get('diagnostic_action_id'), 'phase_d_dat_smoke')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_dat_smoke_autorun_prints_reason_before_launch(self):
        orch = self._make_orchestrator(non_interactive=False)
        cr = MagicMock()
        cr.read_phase_d_dat_smoke_state = MagicMock(return_value={})
        cr.read_operator_deferred_phase_d_dat_smoke = MagicMock(return_value={})
        cr.clear_operator_deferred_phase_d_dat_smoke = MagicMock()
        orch._cloud_readiness_service = MagicMock(return_value=cr)
        rec = {
            'recommended_action_kind': 'phase_d_dat_smoke',
            'pipeline_running': False,
            'why_summary': 'DAT smoke is needed for the selected QA block',
            'action_preview': {
                'anchor_run_id': 'run-anchor',
                'phase_d_context_run_id': 'run-context',
            },
        }
        captured = StringIO()
        with patch.object(orch, '_run_phase_d_dat_smoke', return_value=True):
            with patch('sys.stdout', captured):
                orch._maybe_autorun_phase_d_dat_smoke(rec)
        self.assertIn('Why:', captured.getvalue())
        self.assertIn('DAT smoke is needed for the selected QA block', captured.getvalue())

    def test_post_update_historical_reprocess_recommendation_records_diagnostic_state(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_hist_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
            })
            with patch.object(orch, '_run_historical_phase_d_reprocess_action', return_value=True) as hist_mock:
                started = orch._start_cloud_recommendation_followthrough(
                    trigger='post_update_installed:1.1.0',
                    source='post_update_cloud_autofollow',
                    operator_execution_mode='post_update_autofollow',
                    installed_version='1.1.0',
                    post_update=True,
                )
            self.assertTrue(started)
            hist_mock.assert_called_once()
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('status'), 'running_diagnostic_action')
            self.assertEqual(state.get('diagnostic_action_id'), 'historical_phase_d_reprocess')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_diagnostic_handoff_follows_changed_recommendation(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_diag_handoff_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_diagnostic_action',
                'stage': 'phase_d_dat_verification_rerun',
                'diagnostic_action_id': 'phase_d_dat_verification_rerun',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
                'recommended_action_kind': 'review_dat_qa_full_block',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
                'action_preview': {'anchor_run_id': 'run-1'},
            })
            orch._last_support_send_enqueue_result = {
                'job_id': 'job-1',
                'status': 'queued',
                'policy_decision': 'accepted',
            }
            with patch.object(orch, '_review_dat_qa_full_block_action', return_value=True) as review_mock:
                state = orch._refresh_post_update_autofollow_state()
            review_mock.assert_called_once()
            self.assertEqual(state.get('status'), 'queued_send')
            self.assertEqual(state.get('job_id'), 'job-1')
            self.assertEqual(state.get('previous_diagnostic_action_id'), 'phase_d_dat_verification_rerun')
            self.assertEqual(state.get('last_reason'), 'recommended_send_queued')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_diagnostic_handoff_waits_while_pipeline_running(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_diag_wait_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_diagnostic_action',
                'stage': 'phase_d_dat_verification_rerun',
                'diagnostic_action_id': 'phase_d_dat_verification_rerun',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'phase_d_dat_verification_rerun',
                'recommended_action_kind': 'phase_d_dat_verification_rerun',
                'pipeline_running': True,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'system_health',
            })
            with patch.object(orch, '_send_bundle_for_operator_type') as send_mock:
                state = orch._refresh_post_update_autofollow_state()
            send_mock.assert_not_called()
            self.assertEqual(state.get('status'), 'running_diagnostic_action')
            self.assertEqual(state.get('diagnostic_action_id'), 'phase_d_dat_verification_rerun')
            self.assertEqual(state.get('last_reason'), 'diagnostic_action_waiting_for_pipeline_idle')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_diagnostic_wait_does_not_poll_stale_support_send_job_id(self):
        """Merged autofollow state can retain job_id from an earlier send; do not treat it as active while a diagnostic runs."""
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_diag_stale_job_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_diagnostic_action',
                'stage': 'phase_d_dat_verification_rerun',
                'diagnostic_action_id': 'phase_d_dat_verification_rerun',
                'job_id': 'stale-pre-diagnostic-job',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'last_reason': 'diagnostic_action_waiting_for_pipeline_idle',
            })
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'phase_d_dat_verification_rerun',
                'recommended_action_kind': 'phase_d_dat_verification_rerun',
                'pipeline_running': True,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'system_health',
            })

            def _no_poll_stale_job(_jid):
                raise AssertionError('stale job_id must not be polled during diagnostic_action wait')

            with patch.object(orch, '_find_background_support_send_job', side_effect=_no_poll_stale_job):
                state = orch._refresh_post_update_autofollow_state()
            self.assertEqual(state.get('status'), 'running_diagnostic_action')
            self.assertEqual(state.get('diagnostic_action_id'), 'phase_d_dat_verification_rerun')
            self.assertEqual(state.get('job_id'), 'stale-pre-diagnostic-job')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_diagnostic_handoff_sends_evidence_when_same_action_persists(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_diag_same_')
        try:
            lab_root, _cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'running_diagnostic_action',
                'stage': 'phase_d_dat_verification_rerun',
                'diagnostic_action_id': 'phase_d_dat_verification_rerun',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            rec = {
                'preferred_when_stable_action_kind': 'phase_d_dat_verification_rerun',
                'recommended_action_kind': 'phase_d_dat_verification_rerun',
                'pipeline_running': False,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
            }
            orch._operator_support_send_rec = MagicMock(return_value=rec)

            def _send_bundle(*args, **kwargs):
                orch._last_support_send_enqueue_result = {
                    'job_id': 'job-same',
                    'status': 'queued',
                    'policy_decision': 'accepted',
                }
                return True

            with patch.object(orch, '_send_bundle_for_operator_type', side_effect=_send_bundle) as send_mock:
                with patch.object(orch, '_run_phase_d_dat_verification_rerun_action') as rerun_mock:
                    state = orch._refresh_post_update_autofollow_state()
            rerun_mock.assert_not_called()
            send_mock.assert_called_once()
            self.assertEqual(state.get('status'), 'queued_send')
            self.assertEqual(state.get('job_id'), 'job-same')
            self.assertEqual(state.get('last_reason'), 'diagnostic_action_unresolved_send_queued')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_post_update_active_pipeline_queues_best_now_and_defers_preferred(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_post_update_bestnow_')
        try:
            lab_root, cr = self._attach_temp_cloud_lab(orch, temp_root)
            self._write_post_update_state(lab_root, {
                'installed_version': '1.1.0',
                'previous_installed_version': '1.0.0',
                'status': 'evaluating_recommendation',
                'stage': 'test',
                'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            })
            manager = MagicMock()
            manager.enqueue = MagicMock(return_value={
                'accepted': True,
                'job_id': 'ssj-best-now',
                'status': 'queued',
                'policy_decision': 'queued',
                'policy_reason': 'accepted',
            })
            orch._support_send_job_manager = MagicMock(return_value=manager)
            orch._operator_support_send_rec = MagicMock(return_value={
                'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
                'recommended_action_kind': 'phase_d_dat_smoke',
                'pipeline_running': True,
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'system_health',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_source_scope': 'scope-active',
                'action_preview': {'anchor_run_id': 'run-active'},
            })
            started = orch._start_cloud_recommendation_followthrough(
                trigger='post_update_installed:1.1.0',
                source='post_update_cloud_autofollow',
                operator_execution_mode='post_update_autofollow',
                installed_version='1.1.0',
                post_update=True,
            )
            self.assertTrue(started)
            cr.write_operator_deferred_phase_d_dat_smoke.assert_called_once()
            req = manager.enqueue.call_args[0][0]
            self.assertEqual(req.get('send_type'), 'system_health')
            self.assertEqual(req.get('recommendation_action_kind'), 'phase_d_dat_smoke')
            state = self._read_post_update_state(lab_root)
            self.assertEqual(state.get('status'), 'queued_send')
            self.assertEqual(state.get('last_reason'), 'best_now_send_queued_preferred_deferred')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)
    def test_run_startup_tasks_skips_passive_gmail_queue_resolution(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_run_download_migration'):
            with patch.object(orch, '_launch_startup_csv'):
                with patch('MediCafe.launcher.cloud_readiness', None):
                    with patch.object(error_reporter, 'maybe_auto_resolve_queued_bundles_passive') as auto_mock:
                        orch._run_startup_tasks()
        auto_mock.assert_not_called()

    def test_download_emails_runs_legacy_queue_followup_before_csv(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, 'run_medicafe_command', return_value=0):
            with patch.object(orch, '_maybe_resolve_queued_reports_after_legacy_gmail_download') as follow_mock:
                with patch.object(orch, 'process_csvs', return_value=0):
                    rc = orch.download_emails()
        self.assertEqual(rc, 0)
        follow_mock.assert_called_once_with(0)

    def test_legacy_queue_followup_records_notice_when_attempted(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(
            error_reporter,
            'maybe_resolve_queued_bundles_opportunistically',
            return_value={'attempted': True, 'sent': 2, 'failed': 1},
        ) as auto_mock:
            orch._maybe_resolve_queued_reports_after_legacy_gmail_download(0)
        auto_mock.assert_called_once_with(source='legacy_gmail_download')
        self.assertTrue(any('after legacy Gmail download' in message for _level, message in orch.startup_notices))

    def test_legacy_queue_followup_skips_failed_download(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(error_reporter, 'maybe_resolve_queued_bundles_opportunistically') as auto_mock:
            orch._maybe_resolve_queued_reports_after_legacy_gmail_download(1)
        auto_mock.assert_not_called()

    def test_default_assistant_mode_auto_contextual_without_env_or_prefs(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        import MediCafe.launcher as launcher_mod
        if launcher_mod.next_step_assistant is None:
            self.skipTest('launcher_next_step_assistant not available')
        tmp = tempfile.mkdtemp(prefix='mc_asst_')
        try:
            cfg = os.path.join(tmp, 'config.json')
            with open(cfg, 'w') as handle:
                handle.write('{}')
            args = MagicMock()
            args.skip_csv = False
            args.direct_action = None
            args.debug_mode = False
            args.auto_choice = None
            session = SessionConfig(args)
            with patch.dict(os.environ, {}, clear=False):
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', None)
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT', None)
                orch = MediCafeOrchestrator(session)
                orch.environment['config_file'] = cfg
                orch._assistant_mode = orch._resolve_assistant_mode()
                orch._next_step_assistant_enabled = (
                    bool(launcher_mod.next_step_assistant) and orch._assistant_mode != 'off'
                )
            self.assertEqual(orch._assistant_mode_or_default(), 'auto_contextual')
            self.assertTrue(orch._next_step_assistant_enabled)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_assistant_preference_file_off(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig, _LAUNCHER_PREFERENCES_FILENAME
        import MediCafe.launcher as launcher_mod
        if launcher_mod.next_step_assistant is None:
            self.skipTest('launcher_next_step_assistant not available')
        tmp = tempfile.mkdtemp(prefix='mc_asst_')
        try:
            cfg = os.path.join(tmp, 'config.json')
            with open(cfg, 'w') as handle:
                handle.write('{}')
            pref_path = os.path.join(tmp, _LAUNCHER_PREFERENCES_FILENAME)
            with open(pref_path, 'w') as handle:
                json.dump({'next_step_assistant_mode': 'off'}, handle)
            args = MagicMock()
            args.skip_csv = False
            args.direct_action = None
            args.debug_mode = False
            args.auto_choice = None
            session = SessionConfig(args)
            with patch.dict(os.environ, {}, clear=False):
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', None)
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT', None)
                orch = MediCafeOrchestrator(session)
                orch.environment['config_file'] = cfg
                orch._assistant_mode = orch._resolve_assistant_mode()
                orch._next_step_assistant_enabled = (
                    bool(launcher_mod.next_step_assistant) and orch._assistant_mode != 'off'
                )
            self.assertEqual(orch._assistant_mode_or_default(), 'off')
            self.assertFalse(orch._next_step_assistant_enabled)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_assistant_env_overrides_preference_file(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig, _LAUNCHER_PREFERENCES_FILENAME
        import MediCafe.launcher as launcher_mod
        if launcher_mod.next_step_assistant is None:
            self.skipTest('launcher_next_step_assistant not available')
        tmp = tempfile.mkdtemp(prefix='mc_asst_')
        try:
            cfg = os.path.join(tmp, 'config.json')
            with open(cfg, 'w') as handle:
                handle.write('{}')
            pref_path = os.path.join(tmp, _LAUNCHER_PREFERENCES_FILENAME)
            with open(pref_path, 'w') as handle:
                json.dump({'next_step_assistant_mode': 'auto_contextual'}, handle)
            args = MagicMock()
            args.skip_csv = False
            args.direct_action = None
            args.debug_mode = False
            args.auto_choice = None
            session = SessionConfig(args)
            with patch.dict(os.environ, {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'off'}, clear=False):
                orch = MediCafeOrchestrator(session)
                orch.environment['config_file'] = cfg
                orch._assistant_mode = orch._resolve_assistant_mode()
                orch._next_step_assistant_enabled = (
                    bool(launcher_mod.next_step_assistant) and orch._assistant_mode != 'off'
                )
            self.assertEqual(orch._assistant_mode_or_default(), 'off')
            self.assertFalse(orch._next_step_assistant_enabled)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


    def test_visible_fallback_menu_order_matches_v1(self):
        orch = self._make_orchestrator(non_interactive=False)
        buffer = StringIO()
        with patch('sys.stdout', buffer):
            orch._print_main_menu_options()
        lines = [line.strip() for line in buffer.getvalue().splitlines() if line.strip()]
        self.assertEqual(lines, [
            'Please select an option:',
            '1. Update MediCafe',
            '2. Download Email de Carol',
            '3. MediLink Claims',
            '4. Run MediBot',
            '5. Troubleshooting',
            '0. Exit',
        ])

    def test_interactive_menu_numbers_use_new_visible_order(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_prompt', return_value='4'):
            self.assertEqual(orch._get_menu_choice(), 'medibot')
        with patch.object(orch, '_prompt', return_value='5'):
            self.assertEqual(orch._get_menu_choice(), 'troubleshooting')

    def test_auto_choice_legacy_numeric_values_still_resolve_hidden_actions(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.session.auto_menu_choice = '4'
        orch.session.auto_menu_source = 'CLI'
        captured = StringIO()
        with patch('sys.stdout', captured):
            self.assertEqual(orch._get_menu_choice(), 'claims_status')
        self.assertIn('Why:', captured.getvalue())
        self.assertIn('CLI auto choice requested this launcher action', captured.getvalue())

        orch.session.auto_menu_choice = '5'
        orch.session.auto_menu_source = 'ENV'
        self.assertEqual(orch._get_menu_choice(), 'deductible')

    def test_auto_choice_accepts_stable_action_ids(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.session.auto_menu_choice = 'medilink'
        orch.session.auto_menu_source = 'CLI'
        self.assertEqual(orch._get_menu_choice(), 'medilink')

    def test_startup_assistant_runs_before_menu_render(self):
        orch = self._make_orchestrator(non_interactive=False)
        call_order = []
        with patch.object(orch, '_clear_console', side_effect=lambda: call_order.append('clear')):
            with patch.object(orch, '_print_version_details', side_effect=lambda: call_order.append('version')):
                with patch.object(orch, '_print_welcome_block', side_effect=lambda: call_order.append('welcome')):
                    with patch.object(orch, '_maybe_offer_startup_assistant', side_effect=lambda: call_order.append('assistant') or False):
                        with patch.object(orch, '_print_main_menu_options', side_effect=lambda: call_order.append('menu')):
                            with patch.object(orch, '_get_menu_choice', return_value='exit'):
                                with patch.object(orch, '_dispatch_launcher_action', return_value='exit'):
                                    with patch.object(orch, '_mark_clean_exit'):
                                        with patch.object(orch, '_join_payer_list_thread'):
                                            orch.main_menu_loop(show_header_on_first=True)
        self.assertLess(call_order.index('assistant'), call_order.index('menu'))

    def test_signal_provider_queued_error_reports_counts_zip_files(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_queue_')
        repo_root = tempfile.mkdtemp(prefix='mc_repo_')
        try:
            queue_dir = os.path.join(temp_root, 'reports_queue')
            os.makedirs(queue_dir)
            with open(os.path.join(queue_dir, 'a.zip'), 'w') as handle:
                handle.write('x')
            with open(os.path.join(queue_dir, 'b.zip'), 'w') as handle:
                handle.write('x')
            with open(os.path.join(queue_dir, 'ignore.txt'), 'w') as handle:
                handle.write('x')
            orch.environment['local_storage_path'] = temp_root
            orch.repo_root = repo_root
            payload = orch._signal_provider_queued_error_reports()
            self.assertEqual(payload.get('queued_error_reports_pending_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)
            shutil.rmtree(repo_root, ignore_errors=True)

    def test_signal_provider_docx_index_attention_when_index_missing(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_docx_')
        try:
            with open(os.path.join(temp_root, 'schedule.docx'), 'w') as handle:
                handle.write('placeholder')
            orch.environment['local_storage_path'] = temp_root
            payload = orch._signal_provider_docx_index_attention()
            self.assertTrue(payload.get('docx_index_attention_needed'))
            self.assertEqual(payload.get('docx_index_reason'), 'missing')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_monthly_export_due_near_boundary_without_recent_export(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_export_')
        try:
            export_root = os.path.join(temp_root, 'claims')
            os.makedirs(export_root)
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': export_root}}, handle)
            orch.environment['config_file'] = config_path
            with patch('MediCafe.launcher.time.localtime', return_value=time.struct_time((2026, 4, 1, 12, 0, 0, 2, 92, -1))):
                with patch('MediCafe.launcher.time.time', return_value=1775044800):
                    payload = orch._signal_provider_monthly_humana_aetna_export_due()
            self.assertTrue(payload.get('monthly_humana_aetna_export_due'))
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_run_direct_troubleshooting_bypasses_prepare(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.session.direct_action = 'troubleshooting'
        with patch.object(orch, '_clear_console'):
            with patch.object(orch, '_print_legacy_banner'):
                with patch.object(orch, 'prepare') as prepare_mock:
                    with patch.object(orch, 'troubleshooting_menu') as troubleshooting_mock:
                        rc = orch.run()
        self.assertEqual(rc, 0)
        prepare_mock.assert_not_called()
        troubleshooting_mock.assert_called_once()

    def test_validate_config_can_open_recovery_tools_before_fatal_error(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_cfg_missing_')
        try:
            orch.environment['config_file'] = os.path.join(temp_root, 'config.json')
            with patch.object(orch, '_prompt', return_value='2'):
                with patch.object(orch, '_config_failure_recovery_menu', return_value=True) as recovery_mock:
                    self.assertTrue(orch._validate_config())
            recovery_mock.assert_called_once()
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_validate_config_reprompts_on_invalid_choice(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_cfg_badchoice_')
        try:
            orch.environment['config_file'] = os.path.join(temp_root, 'config.json')
            with patch.object(orch, '_prompt', side_effect=['x', '2']):
                with patch.object(orch, '_config_failure_recovery_menu', return_value=True) as recovery_mock:
                    self.assertTrue(orch._validate_config())
            self.assertEqual(recovery_mock.call_count, 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_validate_config_only_zero_escalates_fatal(self):
        from MediCafe.launcher import LauncherConfigError
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_cfg_fatal_')
        try:
            missing = os.path.join(temp_root, 'config.json')
            orch.environment['config_file'] = missing
            with patch.object(orch, '_prompt', return_value='0'):
                with self.assertRaises(LauncherConfigError):
                    orch._validate_config()
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_config_failure_recovery_menu_can_run_config_diagnostics(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_prompt', side_effect=['2', '0']):
            with patch.object(orch, '_run_config_diagnostics') as diagnostics_mock:
                resolved = orch._config_failure_recovery_menu()
        self.assertFalse(resolved)
        diagnostics_mock.assert_called_once()

    def test_troubleshooting_menu_can_run_config_diagnostics(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_clear_console'):
            with patch.object(orch, '_print_legacy_banner'):
                with patch.object(orch, '_print_troubleshooting_group'):
                    with patch.object(orch, '_prompt', side_effect=['d', '0']):
                        with patch.object(orch, '_run_config_diagnostics') as diagnostics_mock:
                            orch.troubleshooting_menu()
        diagnostics_mock.assert_called_once()

    def test_handle_fatal_error_config_error_can_offer_recovery_tools(self):
        from MediCafe.launcher import LauncherConfigError
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_collect_error_bundle', return_value=None):
            with patch.object(orch, '_prompt', return_value='2'):
                with patch.object(orch, '_config_failure_recovery_menu', return_value=False) as recovery_mock:
                    orch.handle_fatal_error(LauncherConfigError('missing config'))
        recovery_mock.assert_called_once()

if __name__ == '__main__':
    unittest.main()
