from setuptools import setup, find_packages
from pathlib import Path
import runpy

# Determine long_description from available README files (prefer Markdown)
this_directory = Path(__file__).parent
long_description_text = None
for candidate_name in [
    "README.md",
    "DOCUMENTATION_CONSOLIDATION_SUMMARY.md",
    "MARKDOWN_CONSOLIDATION_PLAN.md",
]:
    candidate_path = this_directory / candidate_name
    if candidate_path.exists():
        long_description_text = candidate_path.read_text(encoding="utf-8")
        break

if long_description_text is None:
    long_description_text = """
    # Project Overview: MediCafe

    ## Project Description
    MediCafe is a comprehensive suite designed to automate and streamline several aspects of medical administrative tasks within Medisoft, a popular medical practice management software. The system consists of two main components: MediBot and MediLink, each serving distinct functions but integrated to enhance the workflow of medical practices.

    ## MediBot Module
    MediBot is primarily focused on automating data entry processes in Medisoft. It utilizes AutoHotkey scripting to control and automate the GUI interactions required for inputting patient data into Medisoft. Key features and functionalities include:

    - **Error Handling and Logging:** MediBot aims to implement a robust error handling mechanism that can log issues and provide feedback for troubleshooting.
    - **Insurance Mode Adjustments:** The system can adjust data inputs based on specific requirements from various insurance providers, including Medicare.
    - **Diagnosis Entry Automation:** MediBot automates the extraction and entry of diagnosis codes from surgical schedules into Medisoft.
    - **Script Efficiency:** The module enhances the efficiency of scripts handling Medisoft's quirks, such as fields that are skipped or require special navigation.
    - **User Interface (UI) Enhancements:** Plans to develop a graphical user interface to help non-technical users manage and execute scripts more easily.
    - **Documentation and Support:** Comprehensive documentation and support channels are being established to assist users in setup, configuration, and troubleshooting.

    ## MediLink Module
    MediLink focuses on the backend processes related to medical claims submission, particularly handling communications with multiple endpoints like Availity, Optum, and PNT Data. Its main features include:

    - **Dynamic Configurations:** Supports multiple endpoints with environmental settings to ensure flexibility in claims submission.
    - **File Detection and Integrity Checks:** Enhances the detection of new claim files with detailed logging and integrity checks for preprocessing validation.
    - **Automated Response Handling:** Automates the process of receiving and integrating response files from endpoints into Medisoft, alerting users to exceptions.
    - **Endpoint Management:** Allows dynamic updating of endpoints based on insurance provider changes, ensuring accurate and efficient claims processing.
    - **User Interface (UI) Interactions:** Provides a user interface for managing claims submission, including confirming or adjusting suggested endpoints.

    ## Integration and Workflow
    The two modules work in tandem to provide a seamless experience. MediBot handles the initial data entry into Medisoft, preparing the system with up-to-date patient and treatment information. This data is then utilized by MediLink for preparing and submitting medical claims to various insurance providers. Errors and feedback from MediLink can prompt adjustments in MediBot's data entry processes, creating a feedback loop that enhances accuracy and efficiency.

    The integration aims to reduce the administrative burden on medical practices, decrease the incidence of data entry errors, and ensure timely submission of medical claims, thereby improving the revenue cycle management of healthcare providers.

    ## Target Users
    The system is intended for use by administrative staff in medical practices who are responsible for patient data management and claims processing. By automating these tasks, the system not only saves time but also reduces the potential for human error, leading to more accurate billing and improved operational efficiency.

    ## Future Directions
    Future enhancements may include the development of additional modules for other aspects of medical practice management, further integrations with healthcare systems, and continuous improvements in user interface design to accommodate an even broader range of users.
    """


def _collect_data_files(
    relative_root,
    allowed_suffixes=None,
    include_names=None,
    exclude_dir_names=None,
    exclude_name_prefixes=None,
):
    """
    Collect non-package runtime files so wheel/sdist both carry cloud assets.
    Returns setuptools-compatible [(destination_dir, [file1, file2, ...]), ...].
    """
    root = this_directory / relative_root
    if not root.exists() or not root.is_dir():
        return []

    allowed_suffixes = set(allowed_suffixes or [])
    include_names = set(include_names or [])
    exclude_dir_names = set(exclude_dir_names or [])
    exclude_name_prefixes = tuple(exclude_name_prefixes or ())
    grouped = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue

        rel_from_root_parts = path.relative_to(root).parts
        if any(part in exclude_dir_names for part in rel_from_root_parts[:-1]):
            continue
        if "__pycache__" in rel_from_root_parts:
            continue
        if any(path.name.startswith(prefix) for prefix in exclude_name_prefixes):
            continue
        if path.name in include_names or path.suffix.lower() in allowed_suffixes:
            rel_parent = path.parent.relative_to(this_directory).as_posix()
            rel_file = path.relative_to(this_directory).as_posix()
            grouped.setdefault(rel_parent, []).append(rel_file)

    return sorted(grouped.items())


runtime_data_files = []
runtime_data_files.extend(_collect_data_files("scripts/unified_model", allowed_suffixes={".py"}))
runtime_data_files.extend(_collect_data_files("sql", allowed_suffixes={".sql"}))
runtime_data_files.extend(_collect_data_files("MediLink/gcp_baseline", allowed_suffixes={".md", ".sh"}))
runtime_data_files.extend(
    _collect_data_files(
        "cloud/orchestrator",
        allowed_suffixes={".py", ".md", ".sh", ".txt", ".yaml", ".yml", ".json"},
        include_names={"Dockerfile"},
        exclude_dir_names={"tests", "json", "__pycache__"},
        exclude_name_prefixes=("temp_",),
    )
)
runtime_data_files.extend(_collect_data_files("tools", allowed_suffixes={".py", ".ps1", ".md"}))

_REQUIRED_XP_UNIFIED_MODEL_SCRIPTS = (
    "dat_payer_resolution.py",
    "ingest_from_manifest.py",
    "package_shadow_run_report.py",
    "patient_field_mapper.py",
    "run_qa_canonical.py",
)


def _validate_required_unified_model_scripts():
    """
    Fail packaging early when critical XP runtime scripts are missing or empty.
    """
    um_dir = this_directory / "scripts" / "unified_model"
    problems = []
    for name in _REQUIRED_XP_UNIFIED_MODEL_SCRIPTS:
        path = um_dir / name
        if not path.is_file():
            problems.append("{0} (missing)".format(path.as_posix()))
            continue
        try:
            if path.stat().st_size <= 0:
                problems.append("{0} (zero_bytes)".format(path.as_posix()))
        except OSError as exc:
            problems.append("{0} (stat_error={1})".format(path.as_posix(), exc))
    if problems:
        raise RuntimeError(
            "XP package layout validation failed for required unified_model scripts: {0}".format(
                "; ".join(problems)
            )
        )


_validate_required_unified_model_scripts()


def _write_xp_packaged_file_manifest(version):
    """
    Generate the expected XP data-file hash manifest immediately before build.

    The XP launcher executes scripts/unified_model files from setup.py data_files,
    so package version alone is not enough to prove the runtime scripts are fresh.
    """
    helper_path = this_directory / "MediCafe" / "xp_package_integrity.py"
    helper_globals = runpy.run_path(str(helper_path))
    writer = helper_globals.get("write_expected_manifest")
    if not writer:
        raise RuntimeError("xp_package_integrity.write_expected_manifest unavailable")
    writer(str(this_directory), version=version)


def _read_setup_literal_version():
    text = (this_directory / "setup.py").read_text(encoding="utf-8")
    import re
    match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', text)
    if not match:
        raise RuntimeError("Unable to read setup.py package version for XP manifest")
    return match.group(1)

for top_level_file in ("collect_validation_reports.bat", "update_endpoint_config.py"):
    path = this_directory / top_level_file
    if path.exists():
        runtime_data_files.append(("", [path.relative_to(this_directory).as_posix()]))

_write_xp_packaged_file_manifest(_read_setup_literal_version())

setup(
    name='medicafe',
    version="0.260510.1",
    description='MediCafe',
    long_description=long_description_text,
    long_description_content_type='text/markdown',
    keywords='medicafe medibot medilink medisoft automation healthcare claims',
    url='https://github.com/katanada2/MediCafe',
    project_urls={
        'Source': 'https://github.com/katanada2/MediCafe',
        'Bug Tracker': 'https://github.com/katanada2/MediCafe/issues',
    },
    author='Daniel Vidaud',
    author_email='daniel@personalizedtransformation.com',
    license='MIT',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.4',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    packages=find_packages(include=['MediCafe', 'MediCafe.*', 'MediBot', 'MediBot.*', 'MediLink', 'MediLink.*', 'xp_client', 'xp_client.*']),
    include_package_data=True,
    package_data={
        'MediCafe': ['xp_packaged_file_manifest.json'],
        'MediBot': ['*.bat'],
        'MediLink': ['openssl.cnf', '*.html'],
        'xp_client': ['*.ini', '*.md'],
    },
    data_files=runtime_data_files,
    python_requires='>=3.4, <3.5',
    install_requires=[
        'requests==2.21.0',
        'openpyxl==2.4.11',
        'argparse==1.4.0',
        'numpy==1.11.3; platform_python_implementation != "CPython" or sys_platform != "win32" or python_version > "3.5"',
        'pandas==0.20.0; platform_python_implementation != "CPython" or sys_platform != "win32" or python_version > "3.5"',
        'tqdm==4.14.0',
        'lxml==4.2.0; platform_python_implementation != "CPython" or sys_platform != "win32" or python_version > "3.5"',
        'python-docx==0.8.11',
        'PyYAML==5.2',
        'chardet==3.0.4',
        'cffi==1.8.2', # msal needs this and then pip install will fail because 1.15.X won't work on XP.
        'msal==1.26.0'
    ],
    extras_require={
        'test': [
            'pytest==4.6.11',
            'pytest-timeout==1.4.2',
        ],
        'binary': [
            'numpy==1.11.3; platform_python_implementation == "CPython" and sys_platform == "win32" and python_version <= "3.5"',
            'pandas==0.20.0; platform_python_implementation == "CPython" and sys_platform == "win32" and python_version <= "3.5"',
            'lxml==4.2.0; platform_python_implementation == "CPython" and sys_platform == "win32" and python_version <= "3.5"',
        ]
    },
    entry_points={
        'console_scripts': [
            'medicafe=MediCafe.__main__:main',
        ],
    },
    zip_safe=False
)
