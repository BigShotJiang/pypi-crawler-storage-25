import json
import shutil
from datetime import datetime, timedelta

from playwright.async_api import async_playwright

from gemiterm.config import (
    ensure_config_dir,
    get_default_profile_name,
    get_profile_path,
    list_profiles,
    set_default_profile_name,
)
from gemiterm.exceptions import AuthenticationError, CookieExpiredError

REQUIRED_COOKIES = {"__Secure-1PSID", "__Secure-1PSIDTS"}
COOKIE_EXPIRY_THRESHOLD_DAYS = 7


def _find_chromium_executable() -> str | None:
    """Find chromium executable in standard playwright cache locations."""
    import os
    from pathlib import Path

    playwright_cache_locations = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "ms-playwright",
        Path.home() / ".cache" / "ms-playwright",
    ]

    for cache_dir in playwright_cache_locations:
        if not cache_dir.exists():
            continue
        for chromium_dir in cache_dir.iterdir():
            if not chromium_dir.name.startswith("chromium-"):
                continue
            chrome_exe = chromium_dir / "chrome-win" / "chrome.exe"
            if chrome_exe.exists():
                return str(chrome_exe)

    return None


def validate_cookies(cookies: dict) -> bool:
    if not cookies or "cookies" not in cookies:
        return False
    cookie_list = cookies.get("cookies", [])
    cookie_names = {c.get("name") for c in cookie_list if isinstance(c, dict)}
    return REQUIRED_COOKIES.issubset(cookie_names)


def check_cookie_freshness(cookies: dict) -> bool:
    if not cookies or "cookies" not in cookies:
        return False
    cookie_list = cookies.get("cookies", [])
    for cookie in cookie_list:
        if isinstance(cookie, dict) and cookie.get("name") == "__Secure-1PSIDTS":
            expires = cookie.get("expires", -1)
            if expires > 0:
                expiry_date = datetime.fromtimestamp(expires)
                threshold = datetime.now() + timedelta(days=COOKIE_EXPIRY_THRESHOLD_DAYS)
                if expiry_date < threshold:
                    return False
    return True


async def login(profile_name: str | None = None) -> list[dict]:
    if profile_name is None:
        profile_name = get_default_profile_name()
    ensure_config_dir()
    profile_path = get_profile_path(profile_name)
    profile_path.parent.mkdir(parents=True, exist_ok=True)

    chromium_executable = _find_chromium_executable()
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False, executable_path=chromium_executable if chromium_executable else None
        )
        context = await browser.new_context()
        page = await context.new_page()

        await page.goto("https://gemini.google.com")

        await page.wait_for_load_state("networkidle")

        while True:
            current_cookies = await context.cookies()
            cookie_names = {c["name"] for c in current_cookies}
            if "__Secure-1PSID" in cookie_names and "__Secure-1PSIDTS" in cookie_names:
                break
            await page.wait_for_timeout(500)

        cookies = await context.cookies()
        await context.storage_state(path=profile_path)
        await browser.close()

    if not list_profiles():
        set_default_profile_name(profile_name)
    return [dict(c) for c in cookies]


def load_cookies(profile_name: str | None = None) -> tuple[str, str | None]:
    if profile_name is None:
        profile_name = get_default_profile_name()
    storage_path = get_profile_path(profile_name)
    if not storage_path.exists():
        raise AuthenticationError(
            f"Authentication required. Run 'gemiterm auth' to authenticate. "
            f"Storage file not found at {storage_path}"
        )
    with open(storage_path) as f:
        cookies = json.load(f)
    if not check_cookie_freshness(cookies):
        raise CookieExpiredError(
            "Session appears to be expired. Please run 'gemiterm auth' to re-authenticate."
        )
    cookie_dict = {c["name"]: c["value"] for c in cookies.get("cookies", [])}
    secure_1psid = cookie_dict.get("__Secure-1PSID")
    secure_1psidts = cookie_dict.get("__Secure-1PSIDTS")
    if not secure_1psid:
        raise AuthenticationError("Missing required cookie __Secure-1PSID")
    return (secure_1psid, secure_1psidts)


def get_profile_status(profile_name: str) -> dict:
    profile_path = get_profile_path(profile_name)
    if not profile_path.exists():
        return {
            "exists": False,
            "is_active": False,
            "expires_at": None,
            "needs_refresh": True,
        }
    try:
        with open(profile_path) as f:
            cookies = json.load(f)
        is_active = check_cookie_freshness(cookies)
        expires_at = None
        for cookie in cookies.get("cookies", []):
            if isinstance(cookie, dict) and cookie.get("name") == "__Secure-1PSIDTS":
                expires = cookie.get("expires", -1)
                if expires > 0:
                    dt = datetime.fromtimestamp(expires)
                    hour = str(int(dt.strftime("%I")))
                    expires_at = (
                        f"{dt.month}/{dt.day}/{dt.year} {hour}:{dt.strftime('%M%p')}"
                        f" ({dt.strftime('%A')})"
                    )
                    break
        return {
            "exists": True,
            "is_active": is_active,
            "expires_at": expires_at,
            "needs_refresh": not is_active,
        }
    except (json.JSONDecodeError, OSError):
        return {
            "exists": True,
            "is_active": False,
            "expires_at": None,
            "needs_refresh": True,
        }


def delete_profile(name: str) -> None:
    profile_dir = get_profile_path(name).parent
    if profile_dir.exists():
        shutil.rmtree(profile_dir)
    if get_default_profile_name() == name:
        remaining = list_profiles()
        if remaining:
            set_default_profile_name(remaining[0])


def rename_profile(old_name: str, new_name: str) -> None:
    old_dir = get_profile_path(old_name).parent
    new_dir = get_profile_path(new_name).parent
    if old_dir.exists():
        old_dir.rename(new_dir)
    if get_default_profile_name() == old_name:
        set_default_profile_name(new_name)


def list_profile_statuses() -> list[dict]:
    default_name = get_default_profile_name()
    profiles = list_profiles()
    statuses = []
    for name in profiles:
        status = get_profile_status(name)
        status["name"] = name
        status["is_default"] = name == default_name
        statuses.append(status)
    return statuses
