"""
bench — SDK for defining AI components as classes.

Public API:
    bench.Tool(name, description, input_schema, fn, output_schema)
    bench.CodeEval(name, description, fn)
    bench.Skill(name, description, instructions, ...)
    bench.Runner(client=...)
    bench.Agent(name, description, instructions, model, runner, ...)
    bench.LLMProcessor(name, description, instructions, model, runner, ...)
    bench.LLMEval(name, description, instructions, model, runner, ...)
    bench.Orchestration(name, description, steps)
    bench.Step(component, name, next)
    bench.Conditional(condition, if_true, if_false)
    bench.Checklist(name, description, evals, weights)
    bench.EvalTree(name, description, root)
    bench.Branch(eval, threshold, if_pass, if_fail)
    bench.Edge(weight, node)
    bench.Leaf(eval)

    bench.wrap(client)  — observe an LLM client (Anthropic / OpenAI / Gemini)
"""

from zhanla.types import (
    ComponentType,
    ComponentValue,
    CodeEvalKwargs,
    Runner,
    LLMResponse,
    ToolCall,
    Tool,
    CodeEval,
    Skill,
    Agent,
    LLMProcessor,
    LLMEval,
    Orchestration,
    OrchestrationStep as Step,
    Conditional,
    Checklist,
    EvalTree,
    Branch,
    Edge,
    Leaf,
    EvalTrace,
    ZhanlaComponent,
)
from zhanla.store import get_all, clear
from zhanla.registry import registry
from zhanla.wrap import wrap
from zhanla.json_utils import parse_json_response
from zhanla.trace_store import (
    LLMCall,
    TraceContext,
    set_trace_context,
    get_trace_context,
    reset_trace_context,
)

__all__ = [
    "ComponentType",
    "ComponentValue",
    "CodeEvalKwargs",
    "Runner",
    "LLMResponse",
    "ToolCall",
    "Tool",
    "CodeEval",
    "Skill",
    "Agent",
    "LLMProcessor",
    "LLMEval",
    "Orchestration",
    "Step",
    "Conditional",
    "Checklist",
    "EvalTree",
    "Branch",
    "Edge",
    "Leaf",
    "EvalTrace",
    "ZhanlaComponent",
    "get_all",
    "clear",
    "registry",
    "wrap",
    "parse_json_response",
    "LLMCall",
    "TraceContext",
    "set_trace_context",
    "get_trace_context",
    "reset_trace_context",
]
