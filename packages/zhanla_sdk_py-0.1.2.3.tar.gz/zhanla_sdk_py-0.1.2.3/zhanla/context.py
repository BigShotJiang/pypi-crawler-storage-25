"""Context variable for tracking the active parent trace during nested execution."""
from __future__ import annotations

from contextvars import ContextVar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from zhanla.types import EvalTrace

_active_parent: ContextVar["EvalTrace | None"] = ContextVar(
    "_active_parent", default=None
)


def get_parent() -> "EvalTrace | None":
    """Return the currently active parent trace, or None if not nested."""
    return _active_parent.get()


def set_parent(trace: "EvalTrace | None") -> object:
    """Set the active parent trace. Returns a Token for resetting via reset()."""
    return _active_parent.set(trace)
