"""Execution-local in-memory trace store."""
from __future__ import annotations

from contextvars import ContextVar

from zhanla.types import EvalTrace

_traces_var: ContextVar[list[EvalTrace] | None] = ContextVar("_traces_var", default=None)


def _current_traces() -> list[EvalTrace]:
    traces = _traces_var.get()
    if traces is None:
        traces = []
        _traces_var.set(traces)
    return traces


def append(trace: EvalTrace) -> None:
    """Append a completed trace to the current execution scope."""
    _current_traces().append(trace)


def get_all() -> list[EvalTrace]:
    """Return a snapshot of traces for the current execution scope."""
    return list(_current_traces())


def clear() -> None:
    """Reset traces for the current execution scope."""
    _traces_var.set([])
