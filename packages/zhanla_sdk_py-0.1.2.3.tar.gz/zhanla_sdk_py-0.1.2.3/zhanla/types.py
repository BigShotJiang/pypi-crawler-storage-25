"""Core types for the bench SDK — class-based component model."""
from __future__ import annotations

import inspect
import json
import re
import textwrap
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

try:
    from typing import TypedDict
except ImportError:  # pragma: no cover - Python < 3.8
    from typing_extensions import TypedDict


# ---------------------------------------------------------------------------
# ComponentValue — allowed value types for CodeEval fn arguments
# ---------------------------------------------------------------------------

ComponentValue = Union[str, int, float, Dict[str, Any], List[Any]]


class _RequiredCodeEvalKwargs(TypedDict):
    model_response: str


class CodeEvalKwargs(_RequiredCodeEvalKwargs, total=False):
    expected_output: str
    model_input: str

# ---------------------------------------------------------------------------
# Key validation
# ---------------------------------------------------------------------------

_KEY_PATTERN = re.compile(r"^[a-z0-9-]+$")
_KEY_MAX_LEN = 64


def _slugify(name: str) -> str:
    """Convert a component name to a key-safe slug (lowercase, hyphens only)."""
    slug = name.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug[:_KEY_MAX_LEN]


def _validate_key(key: str, component_name: str) -> None:
    """Raise ValueError if key does not meet format requirements."""
    if not key:
        raise ValueError(f"Component '{component_name}': key must not be empty")
    if not _KEY_PATTERN.match(key):
        raise ValueError(
            f"Component '{component_name}': key '{key}' must contain only "
            f"lowercase letters, digits, and hyphens ([a-z0-9-])"
        )
    if len(key) > _KEY_MAX_LEN:
        raise ValueError(
            f"Component '{component_name}': key '{key}' is too long "
            f"(max {_KEY_MAX_LEN} chars, got {len(key)})"
        )


class ComponentType(str, Enum):
    AGENT = "agent"
    SKILL = "skill"
    TOOL = "tool"
    ORCHESTRATION = "orchestration"
    LLM_PROCESSOR = "llm_processor"
    CODE_EVAL = "code_eval"
    LLM_EVAL = "llm_eval"
    CHECKLIST = "checklist"
    EVAL_TREE = "eval_tree"


# Execution mode derived from component_type at serialization time
EXECUTION_MODES: dict[ComponentType, str] = {
    ComponentType.TOOL: "code",
    ComponentType.CODE_EVAL: "code",
    ComponentType.SKILL: "prompt",
    ComponentType.AGENT: "prompt",
    ComponentType.LLM_PROCESSOR: "prompt",
    ComponentType.LLM_EVAL: "prompt",
    ComponentType.ORCHESTRATION: "dag",
    ComponentType.CHECKLIST: "composite",
    ComponentType.EVAL_TREE: "composite",
}


def _get_fn_source(fn: Callable | None) -> str:
    """Extract source code of a callable for hashing."""
    if fn is None:
        return ""
    try:
        return textwrap.dedent(inspect.getsource(fn))
    except (OSError, TypeError):
        return ""



def _preview_text(text: str, limit: int = 160) -> str:
    normalized = " ".join(text.split()).strip()
    if len(normalized) <= limit:
        return normalized
    return f"{normalized[:limit]}..."


def _schema_summary(schema: dict[str, Any]) -> str:
    properties = schema.get("properties", {})
    if not isinstance(properties, dict) or not properties:
        return "Expected a JSON object."
    fields: list[str] = []
    for key, value in properties.items():
        field_type = value.get("type", "unknown") if isinstance(value, dict) else "unknown"
        fields.append(f"{key}: {field_type}")
    return "Expected JSON object fields: " + ", ".join(fields)


def _validate_tool_json_schema(schema: Any) -> dict[str, Any]:
    if not isinstance(schema, dict):
        raise ValueError("Tool input_schema must be a JSON Schema object.")
    if schema.get("type") != "object":
        raise ValueError("Tool input_schema must be a JSON Schema object with type 'object'.")
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        raise ValueError("Tool input_schema must define a properties object.")
    return schema



# ---------------------------------------------------------------------------
# Trace types (kept for runtime execution recording)
# ---------------------------------------------------------------------------

@dataclass
class Step:
    """A single named step recorded within a parent trace."""
    name: str
    data: Any
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class EvalTrace:
    """Full execution record for a single component invocation."""
    name: str
    component_type: ComponentType
    input: dict
    output: dict | None
    error: str | None
    latency_ms: float
    steps: list[Step]
    status: str  # 'pending' | 'running' | 'completed' | 'failed'
    trigger_run_id: str | None = None
    path_taken: dict | None = None


@dataclass
class ToolCall:
    """Normalized tool call emitted by a runner."""

    name: str
    input: dict
    id: str
    _parseError: str | None = None


@dataclass
class LLMResponse:
    """Normalized runner response used by the executor."""

    text: str
    tool_calls: list[ToolCall]
    stop_reason: str | None


class Runner:
    """Base LLM runner with built-in provider adapters and automatic tracing."""

    def __init__(self, *, client: Any) -> None:
        from zhanla.wrap import wrap

        self.client = wrap(client)

    def build_messages(self, component: ZhanlaComponent, row: dict) -> list[dict]:
        return [
            {"role": "system", "content": getattr(component, "instructions", "")},
            {"role": "user", "content": json.dumps(row)},
        ]

    def _tool_to_json_schema(self, schema: Any) -> dict[str, Any]:
        if isinstance(schema, type) and hasattr(schema, "model_json_schema"):
            return _validate_tool_json_schema(schema.model_json_schema())
        if isinstance(schema, dict):
            if "type" in schema:
                return _validate_tool_json_schema(dict(schema))
            properties: dict[str, Any] = {}
            for key, value in schema.items():
                if isinstance(value, dict) and "type" in value:
                    properties[key] = value
                elif value is str:
                    properties[key] = {"type": "string"}
                elif value in (int, float):
                    properties[key] = {"type": "number"}
                elif value is bool:
                    properties[key] = {"type": "boolean"}
                elif value is type(None):
                    properties[key] = {"type": "null"}
                elif value is list:
                    properties[key] = {"type": "array", "items": {}}
                elif isinstance(value, type) and hasattr(value, "model_json_schema"):
                    properties[key] = value.model_json_schema()
                else:
                    properties[key] = {"type": "string"}
            return _validate_tool_json_schema({"type": "object", "properties": properties})
        raise ValueError("Tool input_schema is required and must be convertible to a JSON Schema object.")

    def _gemini_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        converted: dict[str, Any] = {}
        for key, value in schema.items():
            if key in {"required", "additionalProperties", "$schema"}:
                continue
            if key == "type" and isinstance(value, str):
                converted[key] = value.upper()
                continue
            if key == "properties" and isinstance(value, dict):
                converted[key] = {
                    prop_name: self._gemini_schema(prop_schema)
                    if isinstance(prop_schema, dict)
                    else prop_schema
                    for prop_name, prop_schema in value.items()
                }
                continue
            if key == "items" and isinstance(value, dict):
                converted[key] = self._gemini_schema(value)
                continue
            converted[key] = value
        return converted

    def _normalize_tools(self, tools: list | None, provider: str) -> list[dict[str, Any]] | None:
        if not tools:
            return None

        normalized: list[dict[str, Any]] = []
        for tool in tools:
            if isinstance(tool, dict):
                normalized.append(tool)
                continue

            schema = self._tool_to_json_schema(getattr(tool, "input_schema", None))
            name = str(getattr(tool, "name", ""))
            description = str(getattr(tool, "description", ""))

            if provider == "anthropic":
                normalized.append({
                    "name": name,
                    "description": description,
                    "input_schema": {**schema, "additionalProperties": False},
                })
            elif provider == "openai":
                normalized.append({
                    "type": "function",
                    "function": {
                        "name": name,
                        "description": description,
                        "parameters": {**schema, "additionalProperties": False},
                    },
                })
            elif provider == "gemini":
                normalized.append({
                    "function_declarations": [{
                        "name": name,
                        "description": description,
                        "parameters": self._gemini_schema(schema),
                    }]
                })
            else:
                normalized.append({
                    "name": name,
                    "description": description,
                    "input_schema": schema,
                })

        return normalized

    def _provider_name(self) -> str:
        client = self.client
        if hasattr(client, "messages") and hasattr(client.messages, "create"):
            return "anthropic"
        if (
            hasattr(client, "chat")
            and hasattr(client.chat, "completions")
            and hasattr(client.chat.completions, "create")
        ):
            return "openai"
        if hasattr(client, "models") and hasattr(client.models, "generate_content"):
            return "gemini"
        return type(client).__name__

    def _build_json_repair_messages(
        self,
        text: str,
        output_schema: dict[str, Any],
    ) -> list[dict[str, str]]:
        return [
            {
                "role": "system",
                "content": "\n".join([
                    "Repair malformed JSON.",
                    "Return only valid JSON that conforms to the requested schema.",
                    _schema_summary(output_schema),
                ]),
            },
            {
                "role": "user",
                "content": f"Malformed JSON:\n{text}",
            },
        ]

    async def _request_json_repair(
        self,
        model: str,
        output_schema: dict[str, Any],
        text: str,
    ) -> str:
        response = await self.call_llm(
            messages=self._build_json_repair_messages(text, output_schema),
            model=model,
            tools=[],
            output_schema=None,
            json_repair=False,
        )
        return response.text

    async def _maybe_repair_json(
        self,
        *,
        model: str,
        output_schema: Any,
        json_repair: bool,
        text: str,
    ) -> str:
        if not json_repair or output_schema is None or not text.strip():
            return text

        schema = self._tool_to_json_schema(output_schema)
        try:
            json.loads(text)
            return text
        except Exception:
            repaired_text = await self._request_json_repair(model, schema, text)
            try:
                json.loads(repaired_text)
                return repaired_text
            except Exception as exc:
                raise ValueError(
                    "JSON repair failed for "
                    f"provider={self._provider_name()} "
                    f"model={model} "
                    f'original_response_preview="{_preview_text(text)}" '
                    f'repair_attempt_preview="{_preview_text(repaired_text)}"'
                ) from exc

    def _parse_openai_tool_call(
        self,
        name: str,
        arguments: Any,
        tool_id: str,
    ) -> ToolCall:
        parsed_input: dict[str, Any] = {}
        parse_error: str | None = None

        if isinstance(arguments, str):
            try:
                parsed = json.loads(arguments or "{}")
            except Exception:
                parse_error = arguments
            else:
                if isinstance(parsed, dict):
                    parsed_input = parsed
        elif isinstance(arguments, dict):
            parsed_input = arguments

        return ToolCall(name=name, input=parsed_input, id=tool_id, _parseError=parse_error)

    def _extract_gemini_function_calls(self, raw: Any) -> list[ToolCall]:
        candidates = getattr(raw, "candidates", []) or []
        if not candidates:
            return []

        first = candidates[0]
        content = getattr(first, "content", None)
        parts = getattr(content, "parts", None) or []
        tool_calls: list[ToolCall] = []

        for index, part in enumerate(parts):
            function_call = getattr(part, "function_call", None) or getattr(part, "functionCall", None)
            if function_call is None and isinstance(part, dict):
                function_call = part.get("function_call") or part.get("functionCall")
            if function_call is None:
                continue

            args = getattr(function_call, "args", None)
            if args is None and isinstance(function_call, dict):
                args = function_call.get("args")
            if args is None:
                args = getattr(function_call, "arguments", None)
            if args is None and isinstance(function_call, dict):
                args = function_call.get("arguments")

            parsed_input: dict[str, Any] = {}
            parse_error: str | None = None
            if isinstance(args, dict):
                parsed_input = args
            elif hasattr(args, "model_dump"):
                dumped = args.model_dump()
                if isinstance(dumped, dict):
                    parsed_input = dumped
            elif isinstance(args, str):
                try:
                    parsed = json.loads(args or "{}")
                except Exception:
                    parse_error = args
                else:
                    if isinstance(parsed, dict):
                        parsed_input = parsed

            call_id = getattr(function_call, "id", None)
            if call_id is None and isinstance(function_call, dict):
                call_id = function_call.get("id")

            name = getattr(function_call, "name", None)
            if name is None and isinstance(function_call, dict):
                name = function_call.get("name")

            tool_calls.append(ToolCall(
                name=str(name or ""),
                input=parsed_input,
                id=str(call_id or f"tool_{index}"),
                _parseError=parse_error,
            ))

        return tool_calls

    def _warn_model_provider_mismatch(self, model: str) -> None:
        import warnings

        provider = self._provider_name()
        expected: str | None = None
        if model.startswith("claude-"):
            expected = "anthropic"
        elif model.startswith("gemini-"):
            expected = "gemini"
        elif model.startswith(("gpt-", "o1-", "o3-", "o4-")):
            expected = "openai"
        if expected is not None and provider != expected:
            warnings.warn(
                f"Model '{model}' looks like an {expected} model but the runner client is {provider}. "
                "Check that your client matches your model.",
                UserWarning,
                stacklevel=4,
            )

    async def call_llm(
        self,
        messages: list[dict],
        model: str,
        tools: list | None,
        output_schema: Any,
        json_repair: bool = False,
        temperature: float | None = None,
        top_k: int | None = None,
    ) -> LLMResponse:
        self._warn_model_provider_mismatch(model)
        client = self.client

        if hasattr(client, "messages") and hasattr(client.messages, "create"):
            return await self._call_anthropic(messages, model, tools, output_schema, json_repair, temperature, top_k)
        if (
            hasattr(client, "chat")
            and hasattr(client.chat, "completions")
            and hasattr(client.chat.completions, "create")
        ):
            return await self._call_openai(messages, model, tools, output_schema, json_repair, temperature)
        if hasattr(client, "models") and hasattr(client.models, "generate_content"):
            return await self._call_gemini(messages, model, tools, output_schema, json_repair, temperature, top_k)

        raise TypeError(
            f"Runner does not support client type {type(client).__name__}. "
            "Use bench.Runner with an Anthropic, OpenAI, or Gemini client, "
            "or subclass Runner and override call_llm()."
        )

    async def _call_anthropic(
        self,
        messages: list[dict],
        model: str,
        tools: list | None,
        output_schema: Any,
        json_repair: bool,
        temperature: float | None = None,
        top_k: int | None = None,
    ) -> LLMResponse:
        create_kwargs: dict[str, Any] = {
            "model": model,
            "messages": [m for m in messages if m.get("role") != "system"],
            "max_tokens": 1024,
        }
        system_messages = [m["content"] for m in messages if m.get("role") == "system"]
        if system_messages:
            create_kwargs["system"] = "\n\n".join(str(m) for m in system_messages)
        if temperature is not None:
            create_kwargs["temperature"] = temperature
        if top_k is not None:
            create_kwargs["top_k"] = top_k
        if tools:
            create_kwargs["tools"] = self._normalize_tools(tools, "anthropic")

        raw = self.client.messages.create(**create_kwargs)
        if inspect.isawaitable(raw):
            raw = await raw

        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        for block in getattr(raw, "content", []) or []:
            if getattr(block, "type", None) == "text":
                text_parts.append(getattr(block, "text", "") or "")
            elif getattr(block, "type", None) == "tool_use":
                tool_calls.append(
                    ToolCall(
                        name=str(getattr(block, "name", "")),
                        input=getattr(block, "input", {}) or {},
                        id=str(getattr(block, "id", "")),
                    )
                )

        return LLMResponse(
            text=await self._maybe_repair_json(
                model=model,
                output_schema=output_schema,
                json_repair=json_repair,
                text="".join(text_parts).strip(),
            ),
            tool_calls=tool_calls,
            stop_reason=getattr(raw, "stop_reason", None),
        )

    async def _call_openai(
        self,
        messages: list[dict],
        model: str,
        tools: list | None,
        output_schema: Any,
        json_repair: bool,
        temperature: float | None = None,
    ) -> LLMResponse:
        create_kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }
        if temperature is not None:
            create_kwargs["temperature"] = temperature
        if tools:
            create_kwargs["tools"] = self._normalize_tools(tools, "openai")

        raw = self.client.chat.completions.create(**create_kwargs)
        if inspect.isawaitable(raw):
            raw = await raw

        choices = getattr(raw, "choices", []) or []
        first_choice = choices[0] if choices else None
        message = getattr(first_choice, "message", None) if first_choice else None
        raw_tool_calls = getattr(message, "tool_calls", None) or []

        return LLMResponse(
            text=await self._maybe_repair_json(
                model=model,
                output_schema=output_schema,
                json_repair=json_repair,
                text=getattr(message, "content", "") or "",
            ),
            tool_calls=[
                self._parse_openai_tool_call(
                    name=str(getattr(getattr(tc, "function", None), "name", "")),
                    arguments=getattr(getattr(tc, "function", None), "arguments", "{}"),
                    tool_id=str(getattr(tc, "id", "")),
                )
                for tc in raw_tool_calls
            ],
            stop_reason=getattr(first_choice, "finish_reason", None),
        )

    async def _call_gemini(
        self,
        messages: list[dict],
        model: str,
        tools: list | None,
        output_schema: Any,
        json_repair: bool,
        temperature: float | None = None,
        top_k: int | None = None,
    ) -> LLMResponse:
        system_messages = [m["content"] for m in messages if m.get("role") == "system"]
        user_messages = [m["content"] for m in messages if m.get("role") != "system"]
        config: dict[str, Any] = {}
        if system_messages:
            config["system_instruction"] = "\n\n".join(str(m) for m in system_messages)
        if temperature is not None:
            config["temperature"] = temperature
        if top_k is not None:
            config["top_k"] = top_k
        if tools:
            config["tools"] = self._normalize_tools(tools, "gemini")

        raw = self.client.models.generate_content(
            model=model,
            contents="\n\n".join(str(m) for m in user_messages),
            config=config or None,
        )
        if inspect.isawaitable(raw):
            raw = await raw

        stop_reason = None
        candidates = getattr(raw, "candidates", []) or []
        if candidates:
            stop_reason = str(getattr(candidates[0], "finish_reason", None))

        return LLMResponse(
            text=await self._maybe_repair_json(
                model=model,
                output_schema=output_schema,
                json_repair=json_repair,
                text=getattr(raw, "text", "") or "",
            ),
            tool_calls=self._extract_gemini_function_calls(raw),
            stop_reason=stop_reason,
        )


# ---------------------------------------------------------------------------
# Component classes
# ---------------------------------------------------------------------------

class ZhanlaComponent:
    """Shared base for all bench component classes."""

    component_type: ComponentType
    name: str
    description: str

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

    @property
    def is_runnable(self) -> bool:
        """Whether this component can be a top-level bench run target."""
        return self.component_type in (
            ComponentType.TOOL,
            ComponentType.AGENT,
            ComponentType.LLM_PROCESSOR,
            ComponentType.ORCHESTRATION,
        )

    @property
    def is_eval(self) -> bool:
        return self.component_type in (
            ComponentType.CODE_EVAL,
            ComponentType.LLM_EVAL,
            ComponentType.CHECKLIST,
            ComponentType.EVAL_TREE,
        )


class Tool(ZhanlaComponent):
    component_type = ComponentType.TOOL

    def __init__(
        self,
        *,
        name: str,
        description: str,
        fn: Callable,
        input_schema: Any,
        output_schema: Any,
        key: str,
    ) -> None:
        self.name = name
        self.description = description
        self.fn = fn
        self.input_schema = Runner.__new__(Runner)._tool_to_json_schema(input_schema)
        self.output_schema = output_schema
        self.is_async = inspect.iscoroutinefunction(fn)
        self.source_code = _get_fn_source(fn) or None
        self.source_language = "python"
        self.source_format = "function"
        _validate_key(key, name)
        self.key = key


class CodeEval(ZhanlaComponent):
    component_type = ComponentType.CODE_EVAL

    def __init__(
        self,
        *,
        name: str,
        description: str,
        fn: Callable[..., Any],
        model_response_format: str = "JSON",
        key: str,
    ) -> None:
        self.name = name
        self.description = description
        self.fn = fn
        self.is_async = inspect.iscoroutinefunction(fn)
        self.model_response_format = model_response_format
        self.source_code = _get_fn_source(fn) or None
        self.source_language = "python"
        self.source_format = "function"
        _validate_key(key, name)
        self.key = key


class Skill(ZhanlaComponent):
    component_type = ComponentType.SKILL

    def __init__(
        self,
        *,
        name: str,
        description: str,
        instructions: str,
        tools: list[Tool] | None = None,
        output_schema: Any = None,
        key: str,
    ) -> None:
        self.name = name
        self.description = description
        self.instructions = instructions
        self.tools = tools or []
        self.output_schema = output_schema
        _validate_key(key, name)
        self.key = key


class Agent(ZhanlaComponent):
    component_type = ComponentType.AGENT

    def __init__(
        self,
        *,
        name: str,
        description: str,
        instructions: str,
        model: str,
        client: Any = None,
        runner: Runner | None = None,
        tools: list[Tool] | None = None,
        skills: list[Skill] | None = None,
        agents: list[Agent] | None = None,
        output_schema: Any = None,
        json_repair: bool = False,
        temperature: float | None = None,
        top_k: int | None = None,
        key: str,
    ) -> None:
        if client is not None and runner is not None:
            raise ValueError("Specify client or runner, not both.")
        if client is not None:
            runner = Runner(client=client)
        self.name = name
        self.description = description
        self.instructions = instructions
        self.model = model
        self.runner = runner
        self.tools = tools or []
        self.skills = skills or []
        self.agents = agents or []
        self.output_schema = output_schema
        self.json_repair = json_repair
        self.temperature = temperature
        self.top_k = top_k
        _validate_key(key, name)
        self.key = key


class LLMProcessor(ZhanlaComponent):
    component_type = ComponentType.LLM_PROCESSOR

    def __init__(
        self,
        *,
        name: str,
        description: str,
        instructions: str,
        model: str,
        client: Any = None,
        runner: Runner | None = None,
        output_schema: Any = None,
        json_repair: bool = False,
        temperature: float | None = None,
        top_k: int | None = None,
        key: str,
    ) -> None:
        if client is not None and runner is not None:
            raise ValueError("Specify client or runner, not both.")
        if client is not None:
            runner = Runner(client=client)
        self.name = name
        self.description = description
        self.instructions = instructions
        self.model = model
        self.runner = runner
        self.output_schema = output_schema
        self.json_repair = json_repair
        self.temperature = temperature
        self.top_k = top_k
        _validate_key(key, name)
        self.key = key


class LLMEval(ZhanlaComponent):
    component_type = ComponentType.LLM_EVAL

    def __init__(
        self,
        *,
        name: str,
        description: str,
        instructions: str,
        model: str,
        client: Any = None,
        runner: Runner | None = None,
        output_schema: Any = None,
        json_repair: bool = False,
        temperature: float | None = None,
        top_k: int | None = None,
        key: str,
    ) -> None:
        if client is not None and runner is not None:
            raise ValueError("Specify client or runner, not both.")
        if client is not None:
            runner = Runner(client=client)
        self.name = name
        self.description = description
        self.instructions = instructions
        self.model = model
        self.runner = runner
        self.output_schema = output_schema
        self.json_repair = json_repair
        self.temperature = temperature
        self.top_k = top_k
        _validate_key(key, name)
        self.key = key


class Conditional:
    """Routing primitive for orchestration steps."""

    def __init__(
        self,
        *,
        condition: Callable,
        if_true: str,
        if_false: str,
    ) -> None:
        self.condition = condition
        self.if_true = if_true
        self.if_false = if_false


class OrchestrationStep:
    """A single step in an orchestration DAG."""

    def __init__(
        self,
        *,
        component: ZhanlaComponent | Conditional,
        name: str,
        next: list[str] | None = None,
    ) -> None:
        self.component = component
        self.name = name
        self.next = next or []


class Orchestration(ZhanlaComponent):
    component_type = ComponentType.ORCHESTRATION

    def __init__(
        self,
        *,
        name: str,
        description: str,
        steps: list[OrchestrationStep],
        key: str,
    ) -> None:
        self.name = name
        self.description = description
        self.steps = steps
        _validate_key(key, name)
        self.key = key


# ---------------------------------------------------------------------------
# Eval composition
# ---------------------------------------------------------------------------

class Leaf:
    """Terminal scoring node in an EvalTree."""

    def __init__(self, *, eval: ZhanlaComponent) -> None:
        self.eval = eval


class Edge:
    """Weighted edge in an EvalTree."""

    def __init__(self, *, weight: float, node: Leaf | Branch) -> None:
        self.weight = weight
        self.node = node


class Branch:
    """Routing node in an EvalTree."""

    def __init__(
        self,
        *,
        eval: ZhanlaComponent,
        threshold: float,
        if_pass: list[Edge],
        if_fail: list[Edge],
    ) -> None:
        self.eval = eval
        self.threshold = threshold
        self.if_pass = if_pass
        self.if_fail = if_fail


class Checklist(ZhanlaComponent):
    component_type = ComponentType.CHECKLIST

    def __init__(
        self,
        *,
        name: str,
        description: str,
        evals: list[ZhanlaComponent],
        weights: list[float] | None = None,
        key: str,
    ) -> None:
        self.name = name
        self.description = description
        self.evals = evals
        self.weights = weights
        _validate_key(key, name)
        self.key = key


class EvalTree(ZhanlaComponent):
    component_type = ComponentType.EVAL_TREE

    def __init__(
        self,
        *,
        name: str,
        description: str,
        root: Branch,
        key: str,
    ) -> None:
        self.name = name
        self.description = description
        self.root = root
        _validate_key(key, name)
        self.key = key
