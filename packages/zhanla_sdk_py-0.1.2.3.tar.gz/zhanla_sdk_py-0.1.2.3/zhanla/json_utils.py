"""Helpers for extracting JSON payloads from model text responses."""
from __future__ import annotations

import json
import re
from typing import Any


def _preview_text(text: str, limit: int = 200) -> str:
    normalized = " ".join(text.split()).strip()
    if len(normalized) <= limit:
        return normalized
    return f"{normalized[:limit]}..."


def _extract_malformed_component_error(normalized: str) -> Any:
    start_match = re.match(r'^\{\s*"_component_error"\s*:\s*"', normalized)
    end_match = re.search(r'"\s*\}$', normalized)
    if start_match is None or end_match is None or end_match.start() < start_match.end():
        return None
    return {"_component_error": normalized[start_match.end():end_match.start()]}


def parse_json_response(text: str) -> Any:
    """Parse a JSON payload from raw or fenced model output."""
    normalized = text.strip()
    if normalized.startswith("```"):
        lines = normalized.splitlines()
        if len(lines) >= 3 and lines[0].startswith("```") and lines[-1].strip() == "```":
            normalized = "\n".join(lines[1:-1]).strip()
            if normalized.lower().startswith("json"):
                normalized = normalized[4:].lstrip()
    try:
        return json.loads(normalized)
    except json.JSONDecodeError as exc:
        recovered = _extract_malformed_component_error(normalized)
        if recovered is not None:
            return recovered
        raise json.JSONDecodeError(
            f"Failed to parse JSON response: {exc.msg}. Response preview: {_preview_text(normalized)}",
            exc.doc,
            exc.pos,
        ) from exc
