"""Discover a component closure from a Python file.

Usage: python -m zhanla.discover path/to/file.py:ComponentName

Outputs a JSON array of ComponentManifest dicts to stdout (leaf-first order).
Exits non-zero on error.
"""
from __future__ import annotations

import dataclasses
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


def _import_module(filepath: str) -> object:
    path = Path(filepath).resolve()
    if not path.exists():
        raise ValueError(f"File not found: {filepath}")
    module_name = f"_bench_discover_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load file: {filepath}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    module_dir = str(path.parent)
    inserted = False
    if module_dir not in sys.path:
        sys.path.insert(0, module_dir)
        inserted = True
    try:
        spec.loader.exec_module(module)  # type: ignore[union-attr]
    finally:
        if inserted:
            try:
                sys.path.remove(module_dir)
            except ValueError:
                pass
    return module


def _get_children(comp: Any) -> list[Any]:
    """Return direct live-object children of a component."""
    from zhanla.types import Conditional, Orchestration, EvalTree

    children: list[Any] = []
    for attr in ("tools", "skills", "agents", "evals"):
        children.extend(getattr(comp, attr, []) or [])
    if isinstance(comp, Orchestration):
        for step in comp.steps:
            if not isinstance(step.component, Conditional):
                children.append(step.component)
    if isinstance(comp, EvalTree):
        children.extend(_walk_branch_children(comp.root))
    return children


def _walk_branch_children(node: Any) -> list[Any]:
    from zhanla.types import Branch, Leaf, Edge

    if node is None:
        return []
    children: list[Any] = []
    if isinstance(node, Branch):
        children.append(node.eval)
        for edge in list(getattr(node, "if_pass", []) or []) + list(getattr(node, "if_fail", []) or []):
            children.extend(_walk_branch_children(edge.node))
    elif isinstance(node, Leaf):
        children.append(node.eval)
    return children


def _walk_closure(root: Any) -> list[Any]:
    """BFS over the live object graph. Returns leaf-first ordered components."""
    from zhanla.manifest import to_manifest, compute_behavior_hash

    seen: dict[tuple[str, str], Any] = {}
    order: list[Any] = []

    def visit(comp: Any) -> None:
        ck = (comp.component_type.value, comp.key)
        if ck in seen:
            if seen[ck] is not comp:
                existing_hash = compute_behavior_hash(to_manifest(seen[ck]))
                new_hash = compute_behavior_hash(to_manifest(comp))
                if existing_hash != new_hash:
                    raise ValueError(
                        f"Conflict: two different {comp.component_type.value} objects "
                        f"claim key '{comp.key}' but have different behavior."
                    )
            return
        seen[ck] = comp
        for child in _get_children(comp):
            visit(child)
        order.append(comp)

    visit(root)
    return order


def _manifest_to_dict(manifest: Any) -> dict:
    """Serialize a ComponentManifest to a JSON-serializable dict."""
    from zhanla.manifest import ComponentRef, _ref_to_dict

    result: dict = {}
    for f in dataclasses.fields(manifest):
        value = getattr(manifest, f.name)
        if value is None:
            continue
        if isinstance(value, list) and value and isinstance(value[0], ComponentRef):
            result[f.name] = [_ref_to_dict(r) for r in value]
        else:
            result[f.name] = value
    return result


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m zhanla.discover file.py:ComponentName", file=sys.stderr)
        sys.exit(1)

    spec = sys.argv[1]

    if ":" in spec:
        filepath, symbol_name = spec.rsplit(":", 1)
        if not symbol_name:
            print(f"Empty component name in spec: {spec!r}", file=sys.stderr)
            sys.exit(1)
    else:
        filepath = spec
        symbol_name = None

    try:
        module = _import_module(filepath)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    from zhanla.types import ZhanlaComponent
    from zhanla.manifest import to_manifest

    # Collect all component instances from the module
    components: list[Any] = []
    seen_ids: set[int] = set()
    for attr_name in dir(module):
        obj = getattr(module, attr_name, None)
        if isinstance(obj, ZhanlaComponent) and id(obj) not in seen_ids:
            seen_ids.add(id(obj))
            components.append((attr_name, obj))

    if not components:
        print(f"No bench components found in {filepath}", file=sys.stderr)
        sys.exit(1)

    if symbol_name is not None:
        matches = [(name, c) for name, c in components if name == symbol_name or c.name == symbol_name]
        if not matches:
            available = ", ".join(name for name, _ in components)
            print(f"Component '{symbol_name}' not found in {filepath}. Available: {available}", file=sys.stderr)
            sys.exit(1)
        root = matches[0][1]
    else:
        # Use the first runnable component as root
        runnables = [(name, c) for name, c in components if c.is_runnable]
        if not runnables:
            print(f"No runnable components found in {filepath}", file=sys.stderr)
            sys.exit(1)
        root = runnables[0][1]

    abs_path = str(Path(filepath).resolve())

    try:
        closure = _walk_closure(root)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    manifests = []
    for comp in closure:
        m = to_manifest(comp, file_path=abs_path)
        manifests.append(_manifest_to_dict(m))

    sys.stdout.write(json.dumps(manifests) + "\n")


if __name__ == "__main__":
    main()
