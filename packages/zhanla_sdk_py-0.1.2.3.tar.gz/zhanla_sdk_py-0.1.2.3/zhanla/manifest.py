"""ComponentManifest — language-neutral discovery and sync contract.

The SDK emits raw manifest data only. Hashes are computed by the CLI.
This module is shared between the Python SDK, TypeScript adapter, and CLI.
"""
from __future__ import annotations

import hashlib
import json
import textwrap
import inspect
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# ComponentRef — typed reference to a nested component
# ---------------------------------------------------------------------------

@dataclass
class ComponentRef:
    """Typed reference to a nested bench component, emitted during manifest traversal."""
    key: str
    component_type: str
    name: str
    language: str
    execution_mode: str


# ---------------------------------------------------------------------------
# Output schema normalization
# ---------------------------------------------------------------------------

_PY_TYPE_TO_JSON: dict[type, str] = {
    str: "string",
    int: "number",
    float: "number",
    bool: "boolean",
    type(None): "null",
}


def normalize_output_schema(schema: Any) -> dict | None:
    """Normalize a Python-native output_schema to canonical JSON Schema form.

    Accepts:
    - None → None
    - A dict that already looks like JSON Schema (has a "type" key) → returned as-is
    - A plain dict mapping field names to Python types → converted to object schema
    - A Pydantic BaseModel subclass → via model_json_schema()
    """
    if schema is None:
        return None

    # Already canonical JSON Schema
    if isinstance(schema, dict) and "type" in schema:
        return schema

    # Pydantic BaseModel
    if isinstance(schema, type) and hasattr(schema, "model_json_schema"):
        raw = schema.model_json_schema()
        return _normalize_pydantic_schema(raw)

    # Plain dict: {"key": type} or {"key": str, ...}
    if isinstance(schema, dict):
        return _dict_schema_to_json_schema(schema)

    return None


def _dict_schema_to_json_schema(schema: dict) -> dict:
    """Convert {"key": PythonType} to JSON Schema object."""
    properties: dict[str, dict] = {}
    for key, value_type in schema.items():
        if value_type is list:
            properties[key] = {"type": "array", "items": {}}
        elif value_type in _PY_TYPE_TO_JSON:
            properties[key] = {"type": _PY_TYPE_TO_JSON[value_type]}
        else:
            properties[key] = {"type": "string"}
    return {"type": "object", "properties": properties}


def _normalize_pydantic_schema(raw: dict) -> dict:
    """Normalize a Pydantic model_json_schema() output to canonical form."""
    result: dict = {"type": "object", "properties": {}}
    pydantic_to_json = {
        "string": "string",
        "integer": "number",
        "number": "number",
        "boolean": "boolean",
    }
    for name, prop in raw.get("properties", {}).items():
        raw_type = prop.get("type", "string")
        json_type = pydantic_to_json.get(raw_type, raw_type)
        result["properties"][name] = {"type": json_type}
    if "required" in raw:
        result["required"] = raw["required"]
    return result


# ---------------------------------------------------------------------------
# ComponentManifest
# ---------------------------------------------------------------------------

@dataclass
class ComponentManifest:
    """Language-neutral representation of a discovered bench component.

    The SDK fills all fields except hashes. The CLI computes behavior_hash
    and snapshot_hash from the canonical manifest before syncing.

    Fields present in every manifest:
    - name, description, component_type, key
    - key_source: key provenance, typically "explicit" for current SDK-authored components
    - language ("python" or "typescript")
    - is_runnable, is_eval
    - execution_mode

    Optional fields depend on component type:
    - instructions, model: for Agent, Skill, LLMProcessor, LLMEval
    - fn_present, is_async: for Tool, CodeEval
    - output_schema: canonical JSON Schema dict
    - tool_refs, skill_refs, agent_refs: typed ComponentRef lists
    - steps: for Orchestration (each step has a component_ref)
    - eval_refs, weights: for Checklist
    - root: for EvalTree (each branch/leaf has an eval_ref)

    Entrypoint metadata (for local execution):
    - file_path, symbol_name

    Source metadata (for upload):
    - source_code, source_language, source_format
    """

    name: str
    description: str
    component_type: str
    key: str                      # stable identity key for the component family
    key_source: str               # usually "explicit"; "implicit" may appear in legacy manifests
    language: str                 # "python" | "typescript"
    is_runnable: bool
    is_eval: bool
    execution_mode: str

    # Component-specific optional fields
    instructions: str | None = None
    model: str | None = None
    temperature: float | None = None
    fn_present: bool | None = None
    is_async: bool | None = None
    output_schema: dict | None = None

    # Nested component references — typed refs with key, component_type, name, language, execution_mode
    tool_refs: list[ComponentRef] | None = None
    skill_refs: list[ComponentRef] | None = None
    agent_refs: list[ComponentRef] | None = None
    steps: list[dict] | None = None      # Orchestration steps (component_ref field = typed ref dict)
    eval_refs: list[ComponentRef] | None = None   # Checklist eval refs
    weights: list[float] | None = None   # Checklist weights
    root: dict | None = None             # EvalTree root (eval_ref field = typed ref dict)

    # Entrypoint metadata
    file_path: str | None = None
    symbol_name: str | None = None

    # Source metadata
    source_code: str | None = None
    source_language: str | None = None
    source_format: str | None = None

    # Eval input format (code_eval only)
    model_response_format: str | None = None


# ---------------------------------------------------------------------------
# to_manifest — serialize a Python ZhanlaComponent to a ComponentManifest
# ---------------------------------------------------------------------------

def to_manifest(
    comp: Any,
    *,
    file_path: str | None = None,
    symbol_name: str | None = None,
) -> ComponentManifest:
    """Serialize a Python SDK component instance into a ComponentManifest."""
    from zhanla.types import (
        ZhanlaComponent,
        ComponentType,
        Tool,
        CodeEval,
        Skill,
        Agent,
        LLMProcessor,
        LLMEval,
        Orchestration,
        Checklist,
        EvalTree,
        Conditional,
        EXECUTION_MODES,
        _get_fn_source,
    )

    if not isinstance(comp, ZhanlaComponent):
        raise TypeError(f"Expected a ZhanlaComponent instance, got {type(comp)}")

    ct = comp.component_type
    execution_mode = EXECUTION_MODES.get(ct, "unknown")

    key = comp.key
    key_source = "explicit"

    base = ComponentManifest(
        name=comp.name,
        description=getattr(comp, "description", ""),
        component_type=ct.value,
        key=key,
        key_source=key_source,
        language="python",
        is_runnable=comp.is_runnable,
        is_eval=comp.is_eval,
        execution_mode=execution_mode,
        file_path=file_path,
        symbol_name=symbol_name,
    )

    def _component_ref(c: Any) -> ComponentRef:
        c_type = c.component_type
        return ComponentRef(
            key=c.key,
            component_type=c_type.value,
            name=c.name,
            language="python",
            execution_mode=EXECUTION_MODES.get(c_type, "unknown"),
        )

    if ct == ComponentType.TOOL:
        fn = getattr(comp, "fn", None)
        src = _get_fn_source(fn)
        base.fn_present = fn is not None and callable(fn)
        base.is_async = getattr(comp, "is_async", False)
        base.output_schema = normalize_output_schema(getattr(comp, "output_schema", None))
        base.source_code = src or None
        base.source_language = "python"
        base.source_format = "function"

    elif ct == ComponentType.CODE_EVAL:
        fn = getattr(comp, "fn", None)
        src = _get_fn_source(fn)
        base.fn_present = fn is not None and callable(fn)
        base.is_async = getattr(comp, "is_async", False)
        base.source_code = src or None
        base.source_language = "python"
        base.source_format = "function"
        base.model_response_format = getattr(comp, "model_response_format", "JSON")

    elif ct == ComponentType.SKILL:
        base.instructions = getattr(comp, "instructions", None)
        base.tool_refs = [_component_ref(t) for t in getattr(comp, "tools", [])] or None
        base.output_schema = normalize_output_schema(getattr(comp, "output_schema", None))

    elif ct == ComponentType.AGENT:
        base.instructions = getattr(comp, "instructions", None)
        base.model = getattr(comp, "model", None)
        base.temperature = getattr(comp, "temperature", None)
        base.tool_refs = [_component_ref(t) for t in getattr(comp, "tools", [])] or None
        base.skill_refs = [_component_ref(s) for s in getattr(comp, "skills", [])] or None
        base.agent_refs = [_component_ref(a) for a in getattr(comp, "agents", [])] or None
        base.output_schema = normalize_output_schema(getattr(comp, "output_schema", None))

    elif ct in (ComponentType.LLM_PROCESSOR, ComponentType.LLM_EVAL):
        base.instructions = getattr(comp, "instructions", None)
        base.model = getattr(comp, "model", None)
        base.temperature = getattr(comp, "temperature", None)
        base.output_schema = normalize_output_schema(getattr(comp, "output_schema", None))

    elif ct == ComponentType.ORCHESTRATION:
        base.steps = _serialize_orchestration_steps(comp, _component_ref)

    elif ct == ComponentType.CHECKLIST:
        base.eval_refs = [_component_ref(e) for e in getattr(comp, "evals", [])] or None
        base.weights = getattr(comp, "weights", None)

    elif ct == ComponentType.EVAL_TREE:
        root = getattr(comp, "root", None)
        if root is not None:
            base.root = _serialize_branch(root, _component_ref)

    return base


def _ref_to_dict(ref: Any) -> dict:
    """Convert a ComponentRef (dataclass) or plain dict to a serializable dict."""
    if isinstance(ref, dict):
        return ref
    return {
        "key": ref.key,
        "component_type": ref.component_type,
        "name": ref.name,
        "language": ref.language,
        "execution_mode": ref.execution_mode,
    }


def _project_ref_for_hash(ref: Any) -> dict:
    """Project a ref to the 2-field form used for behavior hashing.

    Strips display-only fields (name, language, execution_mode) so renaming
    a nested component does not change the parent's behavior_hash.
    """
    if isinstance(ref, dict):
        return {"key": ref["key"], "component_type": ref["component_type"]}
    return {"key": ref.key, "component_type": ref.component_type}


def _normalize_step_for_hash(step: dict) -> dict:
    """Strip non-behavioral fields from an orchestration step for hashing."""
    if step.get("is_conditional"):
        return step
    result = dict(step)
    if "component_ref" in result:
        result["component_ref"] = _project_ref_for_hash(result["component_ref"])
    return result


def _normalize_eval_node_for_hash(node: dict) -> dict:
    """Recursively strip non-behavioral fields from an eval-tree node for hashing."""
    if not isinstance(node, dict):
        return node
    result = dict(node)
    if "eval_ref" in result:
        result["eval_ref"] = _project_ref_for_hash(result["eval_ref"])
    for branch_key in ("if_pass", "if_fail"):
        if branch_key in result and isinstance(result[branch_key], list):
            result[branch_key] = [
                {**e, "node": _normalize_eval_node_for_hash(e["node"])}
                if isinstance(e, dict) and "node" in e else e
                for e in result[branch_key]
            ]
    return result


def _get_ref_key(ref: Any) -> str:
    """Extract the key from a ComponentRef or plain dict."""
    if isinstance(ref, dict):
        return ref["key"]
    return ref.key


def _serialize_orchestration_steps(orch: Any, ref_fn: Any) -> list[dict]:
    from zhanla.types import Conditional

    steps = []
    for s in getattr(orch, "steps", []):
        comp = s.component
        if isinstance(comp, Conditional):
            steps.append({
                "name": s.name,
                "is_conditional": True,
                "if_true": comp.if_true,
                "if_false": comp.if_false,
                "next": s.next,
            })
        else:
            steps.append({
                "name": s.name,
                "component_ref": _ref_to_dict(ref_fn(comp)),
                "next": s.next,
            })
    return steps


def _serialize_edge(edge: Any, ref_fn: Any) -> dict:
    from zhanla.types import Leaf, Branch

    node = edge.node
    if isinstance(node, Leaf):
        return {"weight": edge.weight, "node": {"type": "leaf", "eval_ref": _ref_to_dict(ref_fn(node.eval))}}
    if isinstance(node, Branch):
        return {"weight": edge.weight, "node": _serialize_branch(node, ref_fn)}
    return {"weight": edge.weight, "node": {}}


def _serialize_branch(branch: Any, ref_fn: Any) -> dict:
    return {
        "type": "branch",
        "eval_ref": _ref_to_dict(ref_fn(branch.eval)),
        "threshold": branch.threshold,
        "if_pass": [_serialize_edge(e, ref_fn) for e in getattr(branch, "if_pass", [])],
        "if_fail": [_serialize_edge(e, ref_fn) for e in getattr(branch, "if_fail", [])],
    }


# ---------------------------------------------------------------------------
# validate_manifest — shared validation rules for both Python and TS manifests
# ---------------------------------------------------------------------------

def validate_manifest(manifest: ComponentManifest) -> list[str]:
    """Validate a ComponentManifest. Returns a list of error strings."""
    errors: list[str] = []
    ct = manifest.component_type

    if not manifest.name:
        errors.append("Component is missing a name")
        return errors  # Stop here — name is required for all further messages

    if not manifest.description:
        errors.append(f"'{manifest.name}' is missing a description")

    # fn required for Tool, CodeEval
    if ct in ("tool", "code_eval"):
        if not manifest.fn_present:
            errors.append(f"'{manifest.name}' must provide a callable fn")

    # output_schema required for Tool
    if ct == "tool":
        if manifest.output_schema is None:
            errors.append(f"'{manifest.name}' must declare an output_schema")

    # instructions required for Skill, Agent, LLMProcessor, LLMEval
    if ct in ("skill", "agent", "llm_processor", "llm_eval"):
        if not manifest.instructions:
            errors.append(f"'{manifest.name}' is missing instructions")

    # model required for Agent, LLMProcessor, LLMEval
    if ct in ("agent", "llm_processor", "llm_eval"):
        if not manifest.model:
            errors.append(f"'{manifest.name}' must specify a model")

    return errors


def validate_manifests(manifests: list[ComponentManifest]) -> list[str]:
    """Validate all manifests. Returns list of issue strings prefixed with ERROR:."""
    issues: list[str] = []
    for m in manifests:
        for err in validate_manifest(m):
            issues.append(f"ERROR: {err}")
    return issues


# ---------------------------------------------------------------------------
# Hash computation — CLI calls these after receiving manifest data
# ---------------------------------------------------------------------------

def _stable_json(value: Any) -> str:
    """Deterministic JSON serialization with sorted keys."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _compute_sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _behavior_fields(manifest: ComponentManifest) -> dict:
    """Extract the runtime-affecting fields used for behavior_hash.

    Excludes name, description, and key. Name and description are cosmetic.
    Key is an identity label, not a behavioral field. Excluding it keeps
    behavior_hash focused on what the component does, not what it's called.

    Includes all fields that affect runtime behavior: instructions, model, refs,
    schemas, source code, orchestration structure, checklist structure, eval tree.
    """
    fields: dict = {
        "component_type": manifest.component_type,
        "execution_mode": manifest.execution_mode,
    }
    if manifest.instructions is not None:
        fields["instructions"] = manifest.instructions
    if manifest.model is not None:
        fields["model"] = manifest.model
    if manifest.temperature is not None:
        fields["temperature"] = manifest.temperature
    if manifest.output_schema is not None:
        fields["output_schema"] = manifest.output_schema
    if manifest.tool_refs is not None:
        fields["tool_refs"] = sorted(
            [_project_ref_for_hash(r) for r in manifest.tool_refs], key=lambda r: r["key"]
        )
    if manifest.skill_refs is not None:
        fields["skill_refs"] = sorted(
            [_project_ref_for_hash(r) for r in manifest.skill_refs], key=lambda r: r["key"]
        )
    if manifest.agent_refs is not None:
        fields["agent_refs"] = sorted(
            [_project_ref_for_hash(r) for r in manifest.agent_refs], key=lambda r: r["key"]
        )
    if manifest.steps is not None:
        fields["steps"] = [_normalize_step_for_hash(s) for s in manifest.steps]
    if manifest.eval_refs is not None:
        fields["eval_refs"] = sorted(
            [_project_ref_for_hash(r) for r in manifest.eval_refs], key=lambda r: r["key"]
        )
    if manifest.weights is not None:
        fields["weights"] = manifest.weights
    if manifest.root is not None:
        fields["root"] = _normalize_eval_node_for_hash(manifest.root)
    if manifest.source_code is not None:
        fields["source_code"] = manifest.source_code
    if manifest.model_response_format is not None:
        fields["model_response_format"] = manifest.model_response_format
    if manifest.fn_present is not None:
        fields["fn_present"] = manifest.fn_present
    if manifest.is_async is not None:
        fields["is_async"] = manifest.is_async
    return fields


def _snapshot_fields(manifest: ComponentManifest) -> dict:
    """Extract all fields for snapshot_hash.

    Includes name, description, and key (stable identity) on top of all
    behavior fields — so any cosmetic or structural change produces a new hash.
    """
    fields = _behavior_fields(manifest)
    fields["name"] = manifest.name
    fields["description"] = manifest.description or ""
    fields["key"] = manifest.key
    return fields


def compute_behavior_hash(manifest: ComponentManifest) -> str:
    """Compute hash of runtime-affecting fields (excludes name and description)."""
    return _compute_sha256(_stable_json(_behavior_fields(manifest)))


def compute_snapshot_hash(manifest: ComponentManifest) -> str:
    """Compute hash of the full canonical snapshot (includes name and description)."""
    return _compute_sha256(_stable_json(_snapshot_fields(manifest)))
