"""Type-scoped component registry for class-based bench components."""
from __future__ import annotations

from zhanla.types import ZhanlaComponent, ComponentType


class ComponentRegistry:
    """Registry for all bench component instances, keyed by (component_type, name)."""

    def __init__(self) -> None:
        self._components: dict[tuple[ComponentType, str], ZhanlaComponent] = {}

    def register(self, component: ZhanlaComponent) -> None:
        """Register a component. Raises on duplicate (type, name) pair."""
        key = (component.component_type, component.name)
        if key in self._components:
            raise ValueError(
                f"Duplicate {component.component_type.value} named '{component.name}'. "
                f"Each component must have a unique name within its type."
            )
        self._components[key] = component

    def get(self, component_type: ComponentType, name: str) -> ZhanlaComponent | None:
        """Look up a component by type and name."""
        return self._components.get((component_type, name))

    def get_by_name(self, name: str) -> list[ZhanlaComponent]:
        """Find all components with a given name across all types."""
        return [c for (ct, n), c in self._components.items() if n == name]

    def discover(self) -> list[ZhanlaComponent]:
        """Return all registered components."""
        return list(self._components.values())

    def clear(self) -> None:
        """Remove all registered components."""
        self._components.clear()


# Module-level singleton
registry = ComponentRegistry()
