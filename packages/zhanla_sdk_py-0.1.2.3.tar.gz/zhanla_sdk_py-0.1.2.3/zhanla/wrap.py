"""bench.wrap() — observe LLM clients without executing them.

Wraps an existing LLM client so every call is recorded in the active
TraceContext. The underlying client is unchanged; bench only observes.

Supported clients:
  - anthropic.Anthropic (sync)
  - anthropic.AsyncAnthropic (async)
  - openai.OpenAI (sync)
  - openai.AsyncOpenAI (async)
  - google.genai.Client (sync + async via .aio)
"""
from __future__ import annotations

import functools
import time
from typing import Any

from zhanla.trace_store import LLMCall, get_trace_context


def _serialize(obj: Any) -> Any:
    """Convert a provider response object to a JSON-serializable structure."""
    if obj is None:
        return None
    if hasattr(obj, "model_dump"):
        try:
            return obj.model_dump()
        except Exception:
            pass
    if isinstance(obj, (list, tuple)):
        return [_serialize(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _serialize(v) for k, v in obj.items()}
    if hasattr(obj, "__dict__"):
        return {k: _serialize(v) for k, v in obj.__dict__.items() if not k.startswith("_")}
    return obj


def _get_gemini_function_call_part(part: Any) -> Any:
    if isinstance(part, dict):
        return part.get("function_call") or part.get("functionCall")
    return getattr(part, "function_call", None) or getattr(part, "functionCall", None)


def _extract_gemini_tool_call_parts(response: Any) -> list[Any]:
    candidates = getattr(response, "candidates", []) or []
    if not candidates:
        return []

    first = candidates[0]
    content = getattr(first, "content", None)
    parts = getattr(content, "parts", None) or []
    tool_parts: list[Any] = []
    for part in parts:
        if _get_gemini_function_call_part(part) is not None:
            tool_parts.append(part)
    return tool_parts


# ---------------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------------

def _record_anthropic_call(
    ctx: Any,
    kwargs: dict,
    response: Any,
    latency_ms: int,
) -> None:
    content = getattr(response, "content", []) or []
    tool_calls = [b for b in content if getattr(b, "type", None) == "tool_use"]
    usage = getattr(response, "usage", None)

    ctx.record(LLMCall(
        trace_id=ctx.trace_id,
        parent_id=None,
        sequence_order=ctx.next_sequence(),
        autorater_run_id=ctx.autorater_run_id,
        dataset_item_id=ctx.dataset_item_id,
        provider="anthropic",
        model=getattr(response, "model", kwargs.get("model", "")),
        input_messages=_serialize(kwargs.get("messages", [])),
        output=_serialize(content),
        tool_calls=_serialize(tool_calls) if tool_calls else None,
        raw_response=_serialize(response),
        input_tokens=getattr(usage, "input_tokens", None) if usage else None,
        output_tokens=getattr(usage, "output_tokens", None) if usage else None,
        latency_ms=latency_ms,
        stop_reason=getattr(response, "stop_reason", None),
    ))


def _wrap_anthropic_sync(client: Any) -> Any:
    original_create = client.messages.create

    @functools.wraps(original_create)
    def traced_create(*args: Any, **kwargs: Any) -> Any:
        ctx = get_trace_context()
        start = time.perf_counter()
        response = original_create(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        if ctx is not None:
            _record_anthropic_call(ctx, kwargs, response, latency_ms)
        return response

    client.messages.create = traced_create
    return client


def _wrap_anthropic_async(client: Any) -> Any:
    original_create = client.messages.create

    @functools.wraps(original_create)
    async def traced_create(*args: Any, **kwargs: Any) -> Any:
        ctx = get_trace_context()
        start = time.perf_counter()
        response = await original_create(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        if ctx is not None:
            _record_anthropic_call(ctx, kwargs, response, latency_ms)
        return response

    client.messages.create = traced_create
    return client


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------

def _record_openai_call(
    ctx: Any,
    kwargs: dict,
    response: Any,
    latency_ms: int,
) -> None:
    choices = getattr(response, "choices", []) or []
    first_choice = choices[0] if choices else None
    message = getattr(first_choice, "message", None) if first_choice else None
    tool_calls = getattr(message, "tool_calls", None) if message else None
    usage = getattr(response, "usage", None)
    finish_reason = getattr(first_choice, "finish_reason", None) if first_choice else None

    ctx.record(LLMCall(
        trace_id=ctx.trace_id,
        parent_id=None,
        sequence_order=ctx.next_sequence(),
        autorater_run_id=ctx.autorater_run_id,
        dataset_item_id=ctx.dataset_item_id,
        provider="openai",
        model=getattr(response, "model", kwargs.get("model", "")),
        input_messages=_serialize(kwargs.get("messages", [])),
        output=_serialize(message),
        tool_calls=_serialize(tool_calls) if tool_calls else None,
        raw_response=_serialize(response),
        input_tokens=getattr(usage, "prompt_tokens", None) if usage else None,
        output_tokens=getattr(usage, "completion_tokens", None) if usage else None,
        latency_ms=latency_ms,
        stop_reason=finish_reason,
    ))


def _wrap_openai_sync(client: Any) -> Any:
    original_create = client.chat.completions.create

    @functools.wraps(original_create)
    def traced_create(*args: Any, **kwargs: Any) -> Any:
        ctx = get_trace_context()
        start = time.perf_counter()
        response = original_create(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        if ctx is not None:
            _record_openai_call(ctx, kwargs, response, latency_ms)
        return response

    client.chat.completions.create = traced_create
    return client


def _wrap_openai_async(client: Any) -> Any:
    original_create = client.chat.completions.create

    @functools.wraps(original_create)
    async def traced_create(*args: Any, **kwargs: Any) -> Any:
        ctx = get_trace_context()
        start = time.perf_counter()
        response = await original_create(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        if ctx is not None:
            _record_openai_call(ctx, kwargs, response, latency_ms)
        return response

    client.chat.completions.create = traced_create
    return client


# ---------------------------------------------------------------------------
# Gemini (google.genai.Client)
# ---------------------------------------------------------------------------

def _record_gemini_call(
    ctx: Any,
    args: tuple,
    kwargs: dict,
    response: Any,
    latency_ms: int,
) -> None:
    candidates = getattr(response, "candidates", []) or []
    first = candidates[0] if candidates else None
    content = _serialize(getattr(first, "content", None)) if first else None
    tool_calls = _extract_gemini_tool_call_parts(response)
    finish_reason = str(getattr(first, "finish_reason", None)) if first else None
    usage = getattr(response, "usage_metadata", None)
    model = kwargs.get("model") or (args[0] if args else "")

    ctx.record(LLMCall(
        trace_id=ctx.trace_id,
        parent_id=None,
        sequence_order=ctx.next_sequence(),
        autorater_run_id=ctx.autorater_run_id,
        dataset_item_id=ctx.dataset_item_id,
        provider="gemini",
        model=str(model),
        input_messages=_serialize(kwargs.get("contents", [])),
        output=content,
        tool_calls=_serialize(tool_calls) if tool_calls else None,
        raw_response=_serialize(response),
        input_tokens=getattr(usage, "prompt_token_count", None) if usage else None,
        output_tokens=getattr(usage, "candidates_token_count", None) if usage else None,
        latency_ms=latency_ms,
        stop_reason=finish_reason,
    ))


def _wrap_gemini(client: Any) -> Any:
    # Wrap sync models.generate_content
    original_sync = client.models.generate_content

    @functools.wraps(original_sync)
    def traced_sync(*args: Any, **kwargs: Any) -> Any:
        ctx = get_trace_context()
        start = time.perf_counter()
        response = original_sync(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        if ctx is not None:
            _record_gemini_call(ctx, args, kwargs, response, latency_ms)
        return response

    client.models.generate_content = traced_sync

    # Wrap async aio.models.generate_content if present
    if hasattr(client, "aio") and hasattr(getattr(client, "aio", None), "models"):
        original_async = client.aio.models.generate_content

        @functools.wraps(original_async)
        async def traced_async(*args: Any, **kwargs: Any) -> Any:
            ctx = get_trace_context()
            start = time.perf_counter()
            response = await original_async(*args, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            if ctx is not None:
                _record_gemini_call(ctx, args, kwargs, response, latency_ms)
            return response

        client.aio.models.generate_content = traced_async

    return client


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def wrap(client: Any) -> Any:
    """Wrap an LLM client to record every call in the active TraceContext.

    Supported clients:
      - anthropic.Anthropic / anthropic.AsyncAnthropic
      - openai.OpenAI / openai.AsyncOpenAI
      - google.genai.Client

    Returns the same client object (modified in place).
    Raises TypeError for unsupported client types.
    """
    try:
        import anthropic  # type: ignore[import-untyped]
        if isinstance(client, anthropic.Anthropic):
            return _wrap_anthropic_sync(client)
        if isinstance(client, anthropic.AsyncAnthropic):
            return _wrap_anthropic_async(client)
    except ImportError:
        pass

    try:
        import openai  # type: ignore[import-untyped]
        if isinstance(client, openai.OpenAI):
            return _wrap_openai_sync(client)
        if isinstance(client, openai.AsyncOpenAI):
            return _wrap_openai_async(client)
    except ImportError:
        pass

    try:
        import google.genai  # type: ignore[import-untyped]
        if isinstance(client, google.genai.Client):
            return _wrap_gemini(client)
    except ImportError:
        pass

    raise TypeError(
        f"bench.wrap() does not support {type(client).__name__}. "
        "Supported clients: anthropic.Anthropic, anthropic.AsyncAnthropic, "
        "openai.OpenAI, openai.AsyncOpenAI, google.genai.Client."
    )
