"""In-memory LLM call trace store backed by a ContextVar.

The CLI sets a TraceContext before executing a runner-backed component.
The bench.wrap() interceptors read the active context and record each LLM call.
After execution the CLI flushes the calls and writes them to Supabase.
"""
from __future__ import annotations

from contextvars import ContextVar, Token
from dataclasses import dataclass, field
from typing import Any


@dataclass
class LLMCall:
    trace_id: str
    parent_id: str | None
    sequence_order: int
    autorater_run_id: str | None
    dataset_item_id: str | None
    provider: str           # "anthropic" | "openai" | "gemini"
    model: str
    input_messages: list
    output: Any             # serialized model output (content blocks, message, etc.)
    tool_calls: list | None
    raw_response: Any       # full serialized provider response
    input_tokens: int | None
    output_tokens: int | None
    latency_ms: int
    stop_reason: str | None
    metadata: dict | None = None


@dataclass
class TraceContext:
    trace_id: str
    autorater_run_id: str | None = None
    dataset_item_id: str | None = None
    _calls: list[LLMCall] = field(default_factory=list, init=False, repr=False)
    _sequence: int = field(default=0, init=False, repr=False)

    def next_sequence(self) -> int:
        n = self._sequence
        self._sequence += 1
        return n

    def record(self, call: LLMCall) -> None:
        self._calls.append(call)

    def flush(self) -> list[LLMCall]:
        calls = list(self._calls)
        self._calls.clear()
        return calls


_active_context: ContextVar[TraceContext | None] = ContextVar("bench_trace", default=None)


def set_trace_context(ctx: TraceContext) -> Token:
    return _active_context.set(ctx)


def get_trace_context() -> TraceContext | None:
    return _active_context.get()


def reset_trace_context(token: Token) -> None:
    _active_context.reset(token)
