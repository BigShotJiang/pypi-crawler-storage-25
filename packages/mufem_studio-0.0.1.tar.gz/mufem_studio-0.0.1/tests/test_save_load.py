import json
import zipfile
from io import BytesIO
from pathlib import Path

from playwright.sync_api import Page

FIXTURE = Path(__file__).parent / "sim-state.zip"

IGNORED_ERRORS = [
    "Font_FontMgr, error: unable to find any font!",
]

def filter_errors(errors, msg):
    if msg.type == "error" and not any(msg.text.startswith(i) for i in IGNORED_ERRORS):
        errors.append(msg.text)

def read_zip_contents(data: bytes) -> dict:
    result = {}
    with zipfile.ZipFile(BytesIO(data)) as z:
        for name in z.namelist():
            raw = z.read(name)
            try:
                result[name] = json.loads(raw)
            except Exception:
                result[name] = raw  # binary (brep, etc.)
    return result

def test_save_load_roundtrip(page: Page):
    errors = []
    page.on("console", lambda msg: filter_errors(errors, msg))
    page.on("pageerror", lambda err: errors.append(str(err)))

    page.goto("http://localhost:8089/geometry-studio.html")
    page.wait_for_selector(".panel-title", timeout=15_000)

    # Wait for WASM/SimCore to be ready (Run button becomes enabled or UI stabilizes)
    page.wait_for_function("() => document.querySelector('.btn-blue') !== null", timeout=15_000)
    page.wait_for_timeout(1_000)  # small settling delay after WASM ready

    page.locator("input[type=file][accept='.zip']").set_input_files(str(FIXTURE))

    # Wait for materials to appear in the UI instead of a fixed timeout
    page.wait_for_selector(".mat-row", timeout=10_000)
    page.wait_for_timeout(500)

    # assert errors == [], "Errors after load:\n" + "\n".join(errors)

    with page.expect_download() as dl_info:
        page.locator("button.btn", has_text="Save").click()
    saved = Path(dl_info.value.path()).read_bytes()

    orig_setup  = json.loads(zipfile.ZipFile(BytesIO(FIXTURE.read_bytes())).read("setup.json"))
    saved_setup = json.loads(zipfile.ZipFile(BytesIO(saved)).read("setup.json"))

    assert orig_setup == saved_setup, \
        f"setup.json mismatch:\n  orig={json.dumps(orig_setup, indent=2)}\n  saved={json.dumps(saved_setup, indent=2)}"