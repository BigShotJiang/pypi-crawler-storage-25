# Changelog

All notable changes to this project are documented in this file. The format is
based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this
project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.7.2

### Fixed
- `nodejs` variant build no longer collides with the pnpm/yarn corepack
  shims that ship in `node:22-slim` (`npm install -g` now passes `--force`).

## 0.7.1

### Fixed
- `trusted-agent --help` / `-h` now prints local usage and exits instead of
  building the image and forwarding the flag to `claude` inside the sandbox.

## 0.7.0

### Added
- Image variants. The single Dockerfile is split into `default` (lean base
  with Python), `nodejs` (adds pnpm + yarn), `rust`, and `android`. Pick one
  with `--variant NAME`. Users can drop their own variant at
  `~/.config/trusted-agent/variants/<name>/Dockerfile`; user variants take
  precedence over bundled ones.

### Changed
- Image is now tagged `trusted-agent-<variant>:latest` instead of
  `trusted-agent:latest`. The old image is no longer built and can be removed
  with `podman image rm trusted-agent:latest`.
- `default` variant no longer bundles the Rust toolchain or the Android SDK;
  use `--variant rust` / `--variant android` to get them.

## 0.6.2

### Added
- Render the changelog on the PyPI project page alongside the README, via the
  `hatch-fancy-pypi-readme` build hook.

## 0.6.1

### Added
- Mirror the host's `~/.claude/plugins/` into the sandbox at container start so
  installed plugins are available without manual reinstall. Carries over
  `enabledPlugins` and `extraKnownMarketplaces` from the host's
  `~/.claude/settings.json` into the projected user settings.

## 0.5.0

### Added
- Bind-mount the git common dir for linked worktrees so git commands resolve
  inside the sandbox.
- Rust toolchain (stable, with clippy and rustfmt) and the Android SDK
  (cmdline-tools, platform-tools, API 34, build-tools 34.0.0) in the image.

## 0.3.0

### Added
- Install `uv` / `uvx` in the sandbox image.
- README with basic usage.

## 0.2.0

### Added
- First working version: run Claude Code inside a podman + gVisor sandbox with
  a projected `~/.claude.json`, projected credentials, and a `/workspace`
  bind-mount.
