"""Run Claude Code inside a podman + gVisor sandbox."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

DEFAULT_VARIANT = "default"
VARIANTS_BUILTIN_DIR = Path(__file__).resolve().parent / "variants"
VARIANTS_USER_DIR = Path.home() / ".config" / "trusted-agent" / "variants"

# Keys in ~/.claude.json that leak host state into the sandbox. Everything else
# (oauthAccount, feature flags, onboarding state) is kept so Claude Code
# behaves normally.
SENSITIVE_KEYS = ("projects", "githubRepoPaths")

# Folders we refuse to mount as the workspace — bind-mounting any of these
# under /workspace is almost certainly a mistake and would expose core host
# state to the sandbox.
FORBIDDEN_FOLDERS = frozenset(
    Path(p)
    for p in (
        "/",
        "/bin",
        "/boot",
        "/dev",
        "/etc",
        "/lib",
        "/lib64",
        "/opt",
        "/proc",
        "/root",
        "/run",
        "/sbin",
        "/srv",
        "/sys",
        "/usr",
        "/var",
        "/home",
    )
)


def _resolve_tool(name: str) -> str:
    """Resolve a host binary to an absolute path via $PATH, exit if missing."""
    path = shutil.which(name)
    if path is None:
        sys.exit(f"[trusted-agent] {name!r} not found on PATH")
    return path


def _image_name(variant: str) -> str:
    return f"trusted-agent-{variant}:latest"


def _resolve_variant(name: str) -> Path:
    """Find the variant's Dockerfile dir. User dir wins over bundled so users
    can override a built-in variant by name."""
    for root in (VARIANTS_USER_DIR, VARIANTS_BUILTIN_DIR):
        candidate = root / name
        if (candidate / "Dockerfile").is_file():
            return candidate
    sys.exit(f"[trusted-agent] unknown variant: {name!r}")


def _image_exists(podman: str, image: str) -> bool:
    return (
        subprocess.run(
            [podman, "image", "exists", image],
            check=False,
        ).returncode
        == 0
    )


def _dockerfile_base(dockerfile: Path) -> str | None:
    """Return the image referenced by the first ``FROM`` line, if any."""
    for raw in dockerfile.read_text().splitlines():
        line = raw.strip()
        if line.upper().startswith("FROM "):
            return line.split(None, 1)[1].split()[0]
    return None


def _ensure_image(podman: str, variant: str) -> None:
    """Build the variant image if missing. If its Dockerfile FROMs another
    known trusted-agent variant, build that base first."""
    image = _image_name(variant)
    if _image_exists(podman, image):
        return
    context = _resolve_variant(variant)
    base = _dockerfile_base(context / "Dockerfile") or ""
    prefix, suffix = "trusted-agent-", ":latest"
    if base.startswith(prefix) and base.endswith(suffix):
        dep = base[len(prefix) : -len(suffix)]
        if (VARIANTS_USER_DIR / dep / "Dockerfile").is_file() or (
            VARIANTS_BUILTIN_DIR / dep / "Dockerfile"
        ).is_file():
            _ensure_image(podman, dep)
    print(f"[trusted-agent] building {image}...", file=sys.stderr)
    subprocess.run([podman, "build", "-t", image, str(context)], check=True)


USAGE = """\
Usage: trusted-agent [--folder|-C PATH] [--variant NAME] [CMD ...]

Run a command (default: claude) inside a podman + gVisor sandbox.

Options:
  --folder, -C PATH   Mount PATH at /workspace (default: current directory).
  --variant NAME      Image variant (default: default). Built-in variants:
                      default, nodejs, rust, android. User variants live at
                      ~/.config/trusted-agent/variants/<name>/Dockerfile.
  -h, --help          Show this message and exit.
"""


def _parse_args(argv: list[str]) -> tuple[Path, str, list[str]]:
    folder = Path.cwd()
    variant = DEFAULT_VARIANT
    while argv:
        flag = argv[0]
        if flag in ("-h", "--help"):
            print(USAGE, end="")
            sys.exit(0)
        if flag not in ("--folder", "-C", "--variant"):
            break
        if len(argv) < 2:
            sys.exit(f"{flag} requires a value")
        if flag in ("--folder", "-C"):
            folder = Path(argv[1]).resolve()
        else:
            variant = argv[1]
        argv = argv[2:]
    return folder, variant, argv


def _validate_folder(folder: Path) -> None:
    if not folder.is_dir():
        sys.exit(f"folder not found: {folder}")
    # Shell-special chars would let a crafted path inject extra fields into
    # podman's --mount spec (which is comma-separated key=value pairs).
    if any(c in str(folder) for c in (",", ":", "\n")):
        sys.exit(f"folder path contains illegal characters: {folder}")
    if folder in FORBIDDEN_FOLDERS or folder == Path.home():
        sys.exit(f"refusing to sandbox sensitive host path: {folder}")


def _write_temp(contents: bytes, suffix: str) -> Path:
    fd, tmp = tempfile.mkstemp(prefix="trusted-agent-", suffix=suffix)
    try:
        os.write(fd, contents)
    finally:
        os.close(fd)
    os.chmod(tmp, 0o600)
    return Path(tmp)


def _git_common_dir(folder: Path) -> Path | None:
    """Absolute path of the git common dir, if ``folder`` is a linked worktree
    whose .git data lives outside the folder; ``None`` otherwise.

    A linked worktree's ``.git`` is a *file* whose ``gitdir:`` line points at
    an absolute host path inside the original repo's ``.git/worktrees/<name>``.
    Without bind-mounting that target, every git command in the sandbox fails.
    """
    git = shutil.which("git")
    if git is None:
        return None
    result = subprocess.run(
        [git, "-C", str(folder), "rev-parse", "--git-common-dir"],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    common = (folder / result.stdout.strip()).resolve()
    if not common.is_dir():
        return None
    # If the common dir is already inside the workspace, the /workspace mount
    # covers it — nothing extra to do.
    try:
        common.relative_to(folder)
    except ValueError:
        return common
    return None


def _projected_claude_json() -> Path | None:
    """Stripped copy of ~/.claude.json: account metadata + trust flags only."""
    src = Path.home() / ".claude.json"
    if not src.exists():
        return None
    try:
        data = json.loads(src.read_text())
    except json.JSONDecodeError:
        return None
    for key in SENSITIVE_KEYS:
        data.pop(key, None)
    # Pre-accept the folder-trust prompt for /workspace. The sandbox is the
    # trust boundary here — re-asking every start is noise, and only this
    # one synthetic path ends up in the projected config.
    data["projects"] = {
        "/workspace": {
            "hasTrustDialogAccepted": True,
            "hasCompletedProjectOnboarding": True,
            "projectOnboardingSeenCount": 1,
        }
    }
    return _write_temp(json.dumps(data).encode(), suffix="-claude.json")


def _projected_user_settings() -> Path:
    """Minimal ~/.claude/settings.json that silences the bypass-permissions
    dialog. The dialog's gate reads `skipDangerousModePermissionPrompt` from
    userSettings; pre-populating it is cleaner than the old top-level
    bypassPermissionsModeAccepted flag, which only triggered a migration.

    Carries over `enabledPlugins` / `extraKnownMarketplaces` from the host so
    the plugins copied by `_projected_plugins()` are actually activated.
    """
    settings: dict[str, object] = {"skipDangerousModePermissionPrompt": True}
    src = Path.home() / ".claude" / "settings.json"
    if src.exists():
        try:
            host = json.loads(src.read_text())
        except json.JSONDecodeError:
            host = {}
        for key in ("enabledPlugins", "extraKnownMarketplaces"):
            if key in host:
                settings[key] = host[key]
    return _write_temp(json.dumps(settings).encode(), suffix="-settings.json")


def _projected_plugins() -> Path | None:
    """Throwaway copy of ~/.claude/plugins/ so the sandbox sees the same set
    of installed plugins as the host. Returns None if the host has no plugins
    dir. Copying (not bind-mounting the original) keeps any in-sandbox writes
    contained, matching the projection model used for the other claude state.
    """
    src = Path.home() / ".claude" / "plugins"
    if not src.is_dir():
        return None
    dst = Path(tempfile.mkdtemp(prefix="trusted-agent-", suffix="-plugins"))
    shutil.copytree(src, dst, dirs_exist_ok=True, symlinks=True)
    return dst


def _projected_credentials() -> Path | None:
    """Throwaway copy of ~/.claude/.credentials.json (the OAuth tokens).

    The real tokens live here, not in ~/.claude.json. Copying to a temp file
    means in-session token refreshes are discarded on exit and the host file
    stays untouched, same pattern as the .claude.json projection.
    """
    src = Path.home() / ".claude" / ".credentials.json"
    if not src.exists():
        return None
    return _write_temp(src.read_bytes(), suffix="-credentials.json")


def main() -> None:
    folder, variant, passthrough = _parse_args(sys.argv[1:])
    _validate_folder(folder)

    podman = _resolve_tool("podman")
    _resolve_tool(
        "runsc"
    )  # presence check; podman looks runtimes up via its own config

    _ensure_image(podman, variant)

    claude_json = _projected_claude_json()
    credentials = _projected_credentials()
    user_settings = _projected_user_settings()
    plugins = _projected_plugins()
    cmd: list[str] = [
        podman,
        # runsc doesn't play well with rootless podman's default systemd cgroup
        # manager, swap to cgroupfs so container creation doesn't hit polkit.
        "--cgroup-manager=cgroupfs",
        "run",
        "--rm",
        "-it",
        "--runtime=runsc",
        # Rootless runsc can't write to the unified cgroup hierarchy; tell
        # runsc itself to skip cgroup setup. (`--cgroups=disabled` is gated to
        # crun/runc in podman, so we go through --runtime-flag instead.)
        "--runtime-flag=ignore-cgroups",
        "--userns=keep-id",
        # Defense-in-depth: drop all Linux capabilities, forbid privilege
        # escalation via setuid binaries, cap the pid count so a runaway
        # process (or fork bomb) can't take down the host.
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        "--pids-limit=1024",
        # --mount is used instead of -v so a path with embedded colons can't
        # smuggle extra fields; the flag is also rejected for any path with
        # "," or "\n" by _validate_folder.
        "--mount",
        f"type=bind,source={folder},destination=/workspace",
        "-w",
        "/workspace",
        "-e",
        "TERM",
    ]
    # Both mounts are writable on purpose: they point at temp copies that
    # are deleted after the container exits. Claude Code runs startup
    # migrations that need to write back, and token refreshes touch
    # .credentials.json — read-only would abort startup. Any in-sandbox
    # tamper disappears with the temp file; the host's real files are
    # never touched.
    if claude_json is not None:
        cmd += [
            "--mount",
            f"type=bind,source={claude_json},destination=/home/node/.claude.json",
        ]
    if credentials is not None:
        cmd += [
            "--mount",
            f"type=bind,source={credentials},destination=/home/node/.claude/.credentials.json",
        ]
    cmd += [
        "--mount",
        f"type=bind,source={user_settings},destination=/home/node/.claude/settings.json",
    ]
    if plugins is not None:
        cmd += [
            "--mount",
            f"type=bind,source={plugins},destination=/home/node/.claude/plugins",
        ]

    # Linked git worktrees keep refs/objects in the original repo's .git dir
    # and reach it via an absolute path. Mount that dir at the same path
    # inside the container so the worktree's `gitdir:` pointer still resolves.
    git_common = _git_common_dir(folder)
    if git_common is not None:
        if any(c in str(git_common) for c in (",", ":", "\n")):
            sys.exit(f"git common dir contains illegal characters: {git_common}")
        cmd += [
            "--mount",
            f"type=bind,source={git_common},destination={git_common}",
        ]

    cmd.append(_image_name(variant))
    cmd += passthrough or ["claude"]

    try:
        returncode = subprocess.run(cmd).returncode
    finally:
        for tmp in (claude_json, credentials, user_settings):
            if tmp is not None:
                tmp.unlink(missing_ok=True)
        if plugins is not None:
            shutil.rmtree(plugins, ignore_errors=True)
    sys.exit(returncode)


if __name__ == "__main__":
    main()
