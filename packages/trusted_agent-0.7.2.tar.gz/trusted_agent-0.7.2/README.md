Run claude code in a [gVisor](https://gvisor.dev/) sandbox, inside a container.

You need to have podman installed and ready, and be signed-in in claude-code on the host.

```bash
uvx trusted-agent claude --dangerously-skip-permissions "Do something"
```

## Variants

Pick a pre-built image variant with `--variant NAME` (defaults to `default`):

- `default` — node + python + common dev tools.
- `nodejs` — adds `pnpm` and `yarn`.
- `rust` — adds the Rust stable toolchain (with clippy and rustfmt).
- `android` — adds JDK 17 and the Android SDK.

```bash
uvx trusted-agent --variant rust claude
```

Drop your own `Dockerfile` at `~/.config/trusted-agent/variants/<name>/Dockerfile` to add a variant. User variants take precedence over bundled ones with the same name. To extend the lean base, start your file with `FROM trusted-agent-default:latest`.
