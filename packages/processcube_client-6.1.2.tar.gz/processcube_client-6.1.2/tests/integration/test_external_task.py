import os
import pytest

from processcube_client.core.api.client import Client
from processcube_client.core.api.helpers.process_models import ProcessStartRequest, StartCallbackType
from processcube_client.core.api.helpers.external_tasks import (
    FetchAndLockRequestPayload,
    FinishExternalTaskRequestPayload,
    ServiceErrorRequest,
    ServiceError,
)

from .conftest import skip_if_no_engine


PROCESSES_DIR = os.path.join(os.path.dirname(__file__), "processes")


def _start_process(client, process_model_id="ExternalTaskTest_Process"):
    request = ProcessStartRequest(
        process_model_id=process_model_id,
        start_event_id="StartEvent_1",
        initial_token={"test": "value"},
        return_on=StartCallbackType.CallbackOnProcessInstanceCreated,
    )
    return client.process_model_start(process_model_id, request)


def _fetch_task(client, topic="test-task", worker_id="test-worker"):
    payload = FetchAndLockRequestPayload(
        worker_id=worker_id,
        topic_name=topic,
        max_tasks=1,
        long_polling_timeout=5000,
        lock_duration=30000,
    )
    return client.external_task_fetch_and_lock(payload)


@skip_if_no_engine
class TestExternalTaskFetchAndLock:

    def test_fetch_returns_task_with_payload(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)
        _start_process(client)

        tasks = _fetch_task(client)
        assert len(tasks) >= 1

        task = tasks[0]
        assert task.topic == "test-task"
        assert task.payload is not None

    def test_task_has_metadata(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)
        _start_process(client)

        tasks = _fetch_task(client, worker_id="metadata-worker")
        assert len(tasks) >= 1

        task = tasks[0]
        assert task.id is not None
        assert task.worker_id is not None
        assert task.process_instance_id is not None
        assert task.correlation_id is not None
        assert task.flow_node_instance_id is not None


@skip_if_no_engine
class TestExternalTaskFinish:

    def test_finish_task_successfully(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)
        _start_process(client)

        tasks = _fetch_task(client, worker_id="finish-worker")
        assert len(tasks) >= 1

        finish_payload = FinishExternalTaskRequestPayload(
            worker_id="finish-worker",
            result={"answer": 42},
        )
        success = client.external_task_finish(tasks[0].id, finish_payload)
        assert success is True


@skip_if_no_engine
class TestExternalTaskError:

    def test_report_error(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)
        _start_process(client)

        tasks = _fetch_task(client, worker_id="error-worker")
        assert len(tasks) >= 1

        error_request = ServiceErrorRequest(
            worker_id="error-worker",
            error=ServiceError(
                error_code="TEST_ERROR",
                error_message="This is a test error",
            ),
        )
        success = client.external_task_handle_service_error(tasks[0].id, error_request)
        assert success is True


@skip_if_no_engine
class TestExternalTaskExtendLock:

    def test_extend_lock(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)
        _start_process(client)

        tasks = _fetch_task(client, worker_id="lock-worker")
        assert len(tasks) >= 1

        from processcube_client.core.api.helpers.external_tasks import ExtendLockRequest
        extend_request = ExtendLockRequest(
            worker_id="lock-worker",
            additional_duration=30000,
        )
        success = client.external_task_extend_lock(tasks[0].id, extend_request)
        assert success is True
