"""
Tests für den async ExternalTaskClient.

Nutzt das gleiche Muster wie die controlling_platform:
Ein eigener asyncio-Loop wird erstellt, der ExternalTaskClient registriert
sich darauf, und der Loop wird manuell gesteuert.
"""

import asyncio
import os
import time
import threading
import pytest

from processcube_client import ExternalTaskClient
from processcube_client.external_task import FunctionalError
from processcube_client.core.api.client import Client
from processcube_client.core.api.helpers.process_models import ProcessStartRequest, StartCallbackType

from .conftest import skip_if_no_engine


PROCESSES_DIR = os.path.join(os.path.dirname(__file__), "processes")


def _start_process(engine_url):
    client = Client(engine_url)
    client.deploy_bpmn_from_path(PROCESSES_DIR)
    request = ProcessStartRequest(
        process_model_id="ExternalTaskTest_Process",
        start_event_id="StartEvent_1",
        initial_token={"test": "async_value"},
        return_on=StartCallbackType.CallbackOnProcessInstanceCreated,
    )
    return client.process_model_start("ExternalTaskTest_Process", request)


def _run_async_worker(engine_url, topic, handler, timeout_seconds=15):
    """
    Startet den ExternalTaskClient mit eigenem Loop in einem eigenen Thread.
    Der Loop wird im Thread gestartet — wie FastAPI den Loop bereitstellt.
    """
    loop = asyncio.new_event_loop()

    et_client = ExternalTaskClient(
        engine_url,
        loop=loop,
        install_signals=False,
    )
    et_client.subscribe_to_external_task_topic(
        topic,
        handler,
        max_tasks=1,
        long_polling_timeout_in_ms=timeout_seconds * 1000,
        lock_duration_in_ms=30000,
    )

    def run():
        asyncio.set_event_loop(loop)
        # start() mit run_forever=True startet loop.run_forever()
        et_client.start(run_forever=True)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()

    return thread, et_client, loop


def _wait_for_result(result_store, key, et_client, thread, timeout=20):
    """Wartet bis der Handler das Ergebnis geschrieben hat, dann stoppt den Worker."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if key in result_store:
            et_client.stop()
            thread.join(timeout=5)
            return
        time.sleep(0.2)
    # Timeout — trotzdem stoppen
    et_client.stop()
    thread.join(timeout=5)


@skip_if_no_engine
class TestAsyncExternalTaskSimpleHandler:

    def test_simple_handler_receives_payload(self, engine_url):
        result_store = {}

        def handler(payload):
            result_store["received"] = True
            result_store["payload"] = payload
            return {"answer": 42}

        _start_process(engine_url)
        time.sleep(0.5)

        thread, et_client, loop = _run_async_worker(engine_url, "test-task", handler)

        _wait_for_result(result_store, "received", et_client, thread)

        assert result_store.get("received") is True


@skip_if_no_engine
class TestAsyncExternalTaskExtendedHandler:

    def test_extended_handler_receives_external_task(self, engine_url):
        result_store = {}

        def handler(payload, external_task):
            result_store["task_id"] = external_task.get("id")
            result_store["worker_id"] = external_task.get("workerId")
            result_store["process_instance_id"] = external_task.get("processInstanceId")
            return {"status": "ok"}

        # Prozess zuerst starten, damit Task bereit ist
        _start_process(engine_url)
        time.sleep(0.5)

        thread, et_client, loop = _run_async_worker(engine_url, "test-task", handler)

        _wait_for_result(result_store, "task_id", et_client, thread)

        assert result_store.get("task_id") is not None
        assert result_store.get("process_instance_id") is not None


@skip_if_no_engine
class TestAsyncExternalTaskFunctionalError:

    def test_functional_error_is_reported(self, engine_url):
        error_store = {}

        def handler(payload):
            error_store["raised"] = True
            raise FunctionalError(
                code="TEST_ERROR",
                message="Test error from async handler",
            )

        _start_process(engine_url)
        time.sleep(0.5)

        thread, et_client, loop = _run_async_worker(engine_url, "test-task", handler)

        _wait_for_result(error_store, "raised", et_client, thread)

        assert error_store.get("raised") is True


@skip_if_no_engine
class TestAsyncExternalTaskAsyncHandler:

    def test_async_handler_works(self, engine_url):
        result_store = {}

        async def handler(payload):
            result_store["async"] = True
            return {"async_result": "ok"}

        _start_process(engine_url)
        time.sleep(0.5)

        thread, et_client, loop = _run_async_worker(engine_url, "test-task", handler)

        _wait_for_result(result_store, "async", et_client, thread)

        assert result_store.get("async") is True
