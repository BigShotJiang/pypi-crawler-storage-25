import os
import pytest

from processcube_client.core.api.client import Client
from processcube_client.core.api.helpers.process_models import ProcessStartRequest, StartCallbackType
from processcube_client.core.api.helpers.external_tasks import FetchAndLockRequestPayload

from .conftest import skip_if_no_engine


PROCESSES_DIR = os.path.join(os.path.dirname(__file__), "processes")


@skip_if_no_engine
class TestSyncClient:

    def test_info(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        info = client.info()
        assert info is not None

    def test_deploy_and_start_process(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)

        request = ProcessStartRequest(process_model_id="ExternalTaskTest_Process", start_event_id="StartEvent_1", return_on=StartCallbackType.CallbackOnProcessInstanceCreated)
        result = client.process_model_start("ExternalTaskTest_Process", request)
        assert result is not None

    def test_fetch_and_lock_external_task(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)

        # Prozess starten, damit ein ExternalTask entsteht
        request = ProcessStartRequest(process_model_id="ExternalTaskTest_Process", start_event_id="StartEvent_1", return_on=StartCallbackType.CallbackOnProcessInstanceCreated)
        client.process_model_start("ExternalTaskTest_Process", request)

        # ExternalTask abholen
        payload = FetchAndLockRequestPayload(
            worker_id="test-worker",
            topic_name="test-task",
            max_tasks=1,
            long_polling_timeout=5000,
            lock_duration=30000,
        )
        tasks = client.external_task_fetch_and_lock(payload)
        assert len(tasks) >= 1
        assert tasks[0].topic == "test-task"

    def test_fetch_lock_and_finish_external_task(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)

        request = ProcessStartRequest(process_model_id="ExternalTaskTest_Process", start_event_id="StartEvent_1", return_on=StartCallbackType.CallbackOnProcessInstanceCreated)
        client.process_model_start("ExternalTaskTest_Process", request)

        payload = FetchAndLockRequestPayload(
            worker_id="test-worker-finish",
            topic_name="test-task",
            max_tasks=1,
            long_polling_timeout=5000,
            lock_duration=30000,
        )
        tasks = client.external_task_fetch_and_lock(payload)
        assert len(tasks) >= 1

        from processcube_client.core.api.helpers.external_tasks import FinishExternalTaskRequestPayload
        finish_payload = FinishExternalTaskRequestPayload(
            worker_id="test-worker-finish",
            result={"status": "completed"},
        )
        success = client.external_task_finish(tasks[0].id, finish_payload)
        assert success is True
