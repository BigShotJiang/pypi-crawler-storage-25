import pytest
from processcube_client.app_info import AppInfoClient
from processcube_client.core.api.client import Client

from .conftest import skip_if_no_engine


@skip_if_no_engine
class TestAppInfo:

    def test_get_info(self, engine_url, identity_dict):
        client = AppInfoClient(engine_url, identity=identity_dict)
        info = client.get_info()
        assert info is not None

    def test_get_authority(self, engine_url, identity_dict):
        client = AppInfoClient(engine_url, identity=identity_dict)
        authority = client.get_authority()
        assert authority is not None


@skip_if_no_engine
class TestAppInfoSyncClient:

    def test_info(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        info = client.info()
        assert info is not None
