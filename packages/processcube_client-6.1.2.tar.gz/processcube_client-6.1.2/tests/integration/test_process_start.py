import os
import pytest

from processcube_client.core.api.client import Client
from processcube_client.core.api.helpers.process_models import ProcessStartRequest, StartCallbackType

from .conftest import skip_if_no_engine


PROCESSES_DIR = os.path.join(os.path.dirname(__file__), "processes")


@skip_if_no_engine
class TestProcessStart:

    def test_start_process_returns_instance_id(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        client.deploy_bpmn_from_path(PROCESSES_DIR)

        request = ProcessStartRequest(
            process_model_id="ExternalTaskTest_Process",
            start_event_id="StartEvent_1",
            initial_token={"key": "value"},
            return_on=StartCallbackType.CallbackOnProcessInstanceCreated,
        )
        result = client.process_model_start("ExternalTaskTest_Process", request)
        assert result is not None
        assert result.process_instance_id is not None
        assert result.correlation_id is not None
