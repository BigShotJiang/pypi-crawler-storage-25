import pytest
import requests


ENGINE_URL = "http://localhost:8000"


def engine_is_reachable():
    try:
        resp = requests.get(
            f"{ENGINE_URL}/atlas_engine/api/v1/info",
            timeout=3,
        )
        return resp.status_code == 200
    except requests.ConnectionError:
        return False


pytestmark = pytest.mark.integration

skip_if_no_engine = pytest.mark.skipif(
    not engine_is_reachable(),
    reason="ProcessCube Engine nicht erreichbar auf " + ENGINE_URL,
)


@pytest.fixture(scope="session")
def engine_url():
    return ENGINE_URL


@pytest.fixture(scope="session")
def identity():
    """Callable identity für Client-Klasse (Sync)."""
    return None


@pytest.fixture(scope="session")
def identity_dict():
    """Dict identity für async Clients."""
    return None
