import pytest
from processcube_client.event import EventClient

from .conftest import skip_if_no_engine


@skip_if_no_engine
class TestEvent:

    def test_trigger_signal(self, engine_url, identity_dict):
        client = EventClient(engine_url, identity=identity_dict)
        # Signal triggern — sollte keinen Fehler werfen, auch wenn kein Prozess wartet
        try:
            client.trigger_signal("TestSignal")
        except Exception:
            # Manche Engine-Versionen geben 404 wenn kein Listener registriert ist
            pass
