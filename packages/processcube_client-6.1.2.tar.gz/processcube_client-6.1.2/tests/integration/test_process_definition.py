import os
import pytest
from processcube_client.core.api.client import Client

from .conftest import skip_if_no_engine


PROCESSES_DIR = os.path.join(os.path.dirname(__file__), "processes")


@skip_if_no_engine
class TestProcessDefinition:

    def test_deploy_bpmn_from_path(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        result = client.deploy_bpmn_from_path(PROCESSES_DIR)
        assert len(result.deployed_files) > 0
        for deployed in result.deployed_files:
            assert deployed.deployed is True

    def test_deploy_single_bpmn(self, engine_url, identity):
        client = Client(engine_url, identity=identity)
        bpmn_file = os.path.join(PROCESSES_DIR, "ExternalTaskTest.bpmn")
        result = client.deploy_bpmn_from_path(bpmn_file)
        assert len(result.deployed_files) == 1
        assert result.deployed_files[0].deployed is True
