from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.ability.atom.webdriver.interaction.javascript.JSBase import JSBase
from blues_lib.tools.ability.atom.webdriver.interaction.javascript.JSCss import JSCss
from blues_lib.tools.ability.atom.webdriver.interaction.javascript.JSScroll import JSScroll
from blues_lib.tools.TaskContext import TaskContext


class JSDocument(JSBase):
  
  def __init__(self,context:TaskContext):
    super().__init__(context)
    self.js_css = JSCss(context)
    self.js_scroll = JSScroll(context)

  def prevent_dynamic_file_event(self,options:dict|None=None)->bool: 
    '''
    Avoid the dynamic file change open the file dialog
    '''
    trigger_type:str = (options or {}).get('trigger_type') or 'file' # text or file
    script:str = f"""
      window.tempFileInput = null;
      // rewrite create element method
      const originalCreate = document.createElement;
      document.createElement = function(tag) {{
        const elem = originalCreate.call(document, tag);
        if (tag === "input" && elem.type === "{trigger_type}") {{
          window.tempFileInput = elem;
          // prevent click event
          elem.click = () => {{}}; 
        }}
        return elem;
      }};
      return true;
    """
    return self.execute_script({"value":script})

  def set_inner_html(self,options:dict)->bool: 
    '''
    Insert html to element
    Args:
      options (dict): javascript options
        - value (str): html string
    Returns:
      bool : 
    '''
    html:str = options.get('value')
    script:str = '{return arguments[0].innerHTML=`%s`;}' % (html)
    options['value'] = script
    return self._set_document(options)
  
  def set_outer_html(self,options:dict)->bool:
    '''
    Set outer html of element
    Args:
      options (dict): javascript options
        - value (str): html string
    Returns:
      bool : 
    '''
    html:str = options.get('value')
    script:str = '{return arguments[0].outerHTML=`%s`;}' % (html)
    options['value'] = script
    return self._set_document(options)
  
  def set_inner_text(self,options:dict)->bool:
    '''
    Get or set text of element
    Args:
      options (dict): javascript options
        - value (str): text string
    Returns:
      str|None: text of element
    '''
    text:str = options.get('value')
    script:str = '{return arguments[0].innerText=`%s`;}' % (text)
    options['value'] = script
    return self._set_document(options)

  def append_inner_html(self,options:dict)->bool:
    '''
    Append html to inner html of element
    Args:
      options (dict): javascript options
        - value (str): html string
    Returns:
      bool : 
    '''
    html:str = options.get('value')
    script:str = '{const html = arguments[0].innerHTML; return arguments[0].innerHTML=html+`%s`;}' % (html)
    options['value'] = script
    return self._set_document(options)

  def append_inner_text(self,options:dict)->bool:
    '''
    Append text to inner text of element
    Args:
      options (dict): javascript options
        - value (str): text string
    Returns:
      bool : 
    '''
    text:str = options.get('value')
    script:str = '{const text = arguments[0].innerText; return arguments[0].innerText=text+`%s`;}' % (text)
    options['value'] = script
    return self._set_document(options)

  def remove_html(self,options:dict)->bool:
    '''
    Remove inner html of element
    Args:
      options (dict): javascript options
        - value (str): html string
    Returns:
      bool : 
    '''
    script:str = 'return arguments[0].outerHTML=``;'
    options['value'] = script
    return self._set_document(options)

  def remove_text(self,options:dict)->bool:
    '''
    Remove inner text of element
    Args:
      options (dict): javascript options
    Returns:
      bool : 
    '''
    script:str = 'return arguments[0].innerText=``;'
    options['value'] = script
    return self._set_document(options)

  def set_value(self,options:dict)->bool:
    options['value'] = {
      'value':options.get('value') or ''
    }
    return self.set_attribute(options)

  def set_attribute(self,options:dict)->bool:
    '''
    Set attribute of element
    Args:
      options (dict): javascript options
        - value (dict): attribute dict
    Returns:
      bool :
    '''
    attr_set = []
    attrs:dict[str,str] = options.get('value')
    if not attrs:
      return False
    
    self.js_css.display(options)
    self.js_scroll.scroll_into_view(options)

    for attr_key, attr_value in attrs.items():
      attr_set.append(f"targetElem.setAttribute(`{attr_key}`, `{attr_value}`);")
    script:str = f"const targetElem = arguments[0]; {''.join(attr_set)}"

    opts:dict = {**options,'value':script}
    return self._set_document(opts)
   
  def remove_attribute(self,options:dict)->bool:
    '''
    Remove the attribute of the element
    Args:
      options (dict): the javascript options
        - value (list): the attribute list
    Returns:
      bool :
    '''
    attrs:list[str] = options.get('value')
    if not attrs:
      return False

    attr_set = []
    for attr_key in attrs:
      attr_set.append(f"targetElem.removeAttribute(`{attr_key}`);")
    script:str = f"const targetElem = arguments[0]; {''.join(attr_set)}"
    options['value'] = script
    return self._set_document(options)
