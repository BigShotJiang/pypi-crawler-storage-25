from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.file.File import File
from blues_lib.utils.file.FileWriter import FileWriter
from blues_lib.utils.datetime.DateTimeManager import DateTimeManager
from blues_lib.utils.message.EmailSender import EmailSender  
from blues_lib.types import EmailOpts, EmailPara, EmailTpl
from blues_lib.utils.message.PublishHelper import PublishHelper

class Sharing(BaseAbility): 

  def share_to_email(self,opts:dict)->bool: 
    data:Any = opts.get('value')
    if not data:
      return False

    template:EmailTpl = opts.get('template') or 'default'
    mailer = EmailSender.get_instance()

    e_opts:EmailOpts = {}
    if template == 'publish':
      e_opts = PublishHelper.get_opts(opts)
    else:
      paras:list[EmailPara] = [] 
      if EmailSender.is_paras(data):
        paras = data
      else:
        paras = [{
          'type':'text',
          'value':str(data),
        }]
      default_subject:str = f'sharing_email_{DateTimeManager.get_now()}'
      e_opts = {
        'subject': opts.get('subject','') or default_subject,
        'addressee': opts.get('addressee',''),
        'addressee_name': opts.get('addressee_name','') or 'BluesLiu',
        'paras': paras,
      }

    if not e_opts.get('addressee'):
      self._logger.warning(f'share_to_email error : addressee is None')
      return False

    stdout = mailer.send(e_opts)
    if stdout.code != 200:
      self._logger.warning(f'share_to_email error : {stdout.message}')
      return False
    return True

  def share_to_file(self,opts:dict)->str: 
    data:Any = opts.get('value')
    if not data:
      return

    dirs:str|list[str] = opts.get('dirs') or []
    dirs = [dirs] if isinstance(dirs,str) else dirs
    dirs = ['file'] + dirs

    default_name:str = f'sharing_file_{DateTimeManager.get_now()}'
    parts:str = opts.get('filename','').split('.')
    filename:str = parts[0] or default_name
    extension:str = opts.get('extension') or (parts[1] if len(parts) > 1 else '') or 'txt'

    mode:str = opts.get('mode') or 'w' # w or a
    file_path:str = File.get_blues_file_path(dirs,filename,extension)
    if extension == 'txt':
      FileWriter.write_text(file_path,str(data),mode)
    elif extension == 'json':
      FileWriter.write_json(file_path,data)
    elif extension == 'csv':
      FileWriter.write_csv(file_path,data)
    return file_path

  def share_to_xcom(self,opts:dict)->list[str]: 
    ti = opts.get('ti')
    if not ti:
      raise ValueError('share_to_xcom error, ti is None')

    data:Any = opts.get('value')
    if not data:
      return []
    
    if not isinstance(data,dict):
      data = {"data":data}

    for key,value in data.items(): 
      ti.xcom_push(key,value)
      
    return data.keys()
     