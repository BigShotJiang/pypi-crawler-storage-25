from datetime import datetime
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.file.FileWriter import FileWriter
from blues_lib.utils.file.File import File

class Writer(BaseAbility):
  
  def append_log(self,options:dict)->str:
    file_opts:dict = {
      'subdir': 'stat',
      'filename': f'stat_{datetime.now().strftime("%Y%m%d")}',
      'extension': 'log',
    }
    file_path:str = File.get_abs_file(file_opts)
    message:str = options.get("message")
    mode:str = 'a'
    return FileWriter.write_text(file_path,message,mode)

  def write_text(self,options:dict)->str:
    options['extension'] = 'txt'
    file_path:str = File.get_abs_file(options)
    value:str = str(options.get("value"))
    mode:str = 'w'
    return FileWriter.write_text(file_path,value,mode)

  def append_text(self,options:dict)->str:
    options['extension'] = 'txt'
    file_path:str = File.get_abs_file(options)
    separator:str = str(options.get("separator") or ' ')
    value:str = str(options.get("value"))+separator
    mode:str = 'a'
    return FileWriter.write_text(file_path,value,mode)
  
  def write_json(self,options:dict)->str:
    options['extension'] = 'json'
    file_path:str = File.get_abs_file(options)
    value:dict = options.get("value")
    return FileWriter.write_json(file_path,value)

  def write_csv(self,options:dict)->str:
    options['extension'] = 'csv'
    file_path:str = File.get_abs_file(options)
    value:list = options.get("value")
    return FileWriter.write_csv(file_path,value)
