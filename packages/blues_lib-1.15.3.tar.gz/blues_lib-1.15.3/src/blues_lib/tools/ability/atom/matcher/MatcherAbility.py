from blues_lib.tools.ability.atom.webdriver.DriverAbilityFacade import DriverAbilityFacade
from blues_lib.tools.TaskContext import TaskContext
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

class MatcherAbility(BaseAbility):

  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._facade = DriverAbilityFacade(context)
