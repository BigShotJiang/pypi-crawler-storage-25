from blues_lib.tools.ability.atom.hook.Sharing import Sharing
from blues_lib.tools.ability.atom.hook.Mapping import Mapping
from blues_lib.tools.TaskContext import TaskContext

class HookAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      Sharing.__name__:Sharing(context),
      Mapping.__name__:Mapping(context),
    }