from blues_lib.tools.ability.atom.dpp.DppEntity import DppEntity
from blues_lib.tools.TaskContext import TaskContext

class DppAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      DppEntity.__name__:DppEntity(context),
    }