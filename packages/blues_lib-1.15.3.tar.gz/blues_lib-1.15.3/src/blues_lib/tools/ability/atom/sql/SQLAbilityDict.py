from blues_lib.tools.ability.atom.sql import DBQuerier, DBInserter, DBUpdater, DBDeleter, DBWaiter
from blues_lib.tools.TaskContext import TaskContext

class SQLAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      DBQuerier.__name__:DBQuerier(context),
      DBInserter.__name__:DBInserter(context),
      DBUpdater.__name__:DBUpdater(context),
      DBDeleter.__name__:DBDeleter(context),
      DBWaiter.__name__:DBWaiter(context),
    }