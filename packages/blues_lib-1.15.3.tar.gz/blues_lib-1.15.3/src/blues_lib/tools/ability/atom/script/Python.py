from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.script.PythonExecutor import PythonExecutor
from blues_lib.types import ToolDef

class Python(BaseAbility): 

  # syntax sugar
  def json_loads(self,options:dict[str,any])->any:
    # 处理被 markdown 的 ```json xxx ``` 包裹的字符串
    value = options['value'].strip()
    if value.startswith('```json') and value.endswith('```'):
      # 移除 markdown 包裹
      value = value[7:-3].strip()
      options['value'] = value
    options['script'] = "lambda value: json.loads(value)"
    return self.python_lambda(options)
  
  def json_dumps(self,options:dict[str,any])->any:
    options['script'] = "lambda value: json.dumps(value,indent=2,ensure_ascii=False)"
    return self.python_lambda(options)
  
  def to_string(self,options:dict[str,any])->any:
    options['script'] = "lambda value: str(value)"
    return self.python_lambda(options)

  # basic method
  def python_lambda(self,options:dict[str,any])->any:
    ability_def:ToolDef = {
      'name':'lambda',
      'options':options
    }
    result = PythonExecutor.execute(ability_def)
    return result

  def python_func(self,options:dict[str,any])->any:
    return self.python_function(options)

  def python_function(self,options:dict[str,any])->any:
    ability_def:ToolDef = {
      'name':'function',
      'options':options
    }
    return PythonExecutor.execute(ability_def)

  def python_file(self,options:dict[str,any])->any:
    ability_def:ToolDef = {
      'name':'file',
      'options':options
    }
    return PythonExecutor.execute(ability_def)
