from blues_lib.tools.ability.atom.tool.Dummy import Dummy
from blues_lib.tools.ability.atom.tool.Util import Util
from blues_lib.tools.ability.atom.tool.Clipboard import Clipboard
from blues_lib.tools.ability.atom.tool.Calculator import Calculator
from blues_lib.tools.TaskContext import TaskContext

class ToolAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      Dummy.__name__:Dummy(context),
      Util.__name__:Util(context),
      Clipboard.__name__:Clipboard(context),
      Calculator.__name__:Calculator(context),
    }