from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.datetime.DateTimeManager import DateTimeManager
from blues_lib.services.sql.DBQuerier import DBQuerier
from blues_lib.supports.dp.output.STDOut import STDOut

class DBWaiter(BaseAbility):

  def wait_sms_code(self,options:dict)->str:
    code:str = self._get(options)
    if not code:
      self._logger.error(f'[{self.__class__.__name__}] Failed to fetch the auth code')
      return ''
    return code

  def _get(self,options:dict)->str:
    step = 10
    timeout = options.get('timeout',300)
    domain = options.get('domain')
    ts = options.get('timestamp')
    steps =  list(range(0,timeout,step))
    i = 0
    for s in steps:
      i+=1

      if code := self._get_code(domain,ts):
        return str(code)

      DateTimeManager.count_down({
        'duration':step,
        'title':f'[{self.__class__.__name__}] Wait for the auth code {i*step}/{timeout} - {domain} {ts}'
      })
    return ''

  def _get_code(self,domain,ts)->str:
    conditions = [
      {'field':'login_ts','comparator':'=','value':ts},
      {'field':'login_site','comparator':'=','value':domain},
    ]
    querier = DBQuerier('naps_loginer')
    stdout:STDOut = querier.get('*',conditions)
    data = stdout.data
    return data[0]['login_sms_code'] if data else ''
