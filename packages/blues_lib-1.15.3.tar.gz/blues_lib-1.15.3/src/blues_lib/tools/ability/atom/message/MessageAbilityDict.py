from blues_lib.tools.ability.atom.message.Email import Email
from blues_lib.tools.ability.atom.message.DingDing import DingDing
from blues_lib.tools.TaskContext import TaskContext

class MessageAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      Email.__name__:Email(context),
      DingDing.__name__:DingDing(context),
    }