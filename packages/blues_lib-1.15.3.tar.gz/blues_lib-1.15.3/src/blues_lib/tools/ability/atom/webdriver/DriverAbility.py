from selenium.common.exceptions import NoSuchShadowRootException
from selenium.webdriver.remote.webelement import WebElement

from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.TaskContext import TaskContext

class DriverAbility(BaseAbility):

  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._driver = context.driver
    self._default_options:dict = {
      # locator
      'target':'',
      'root':self._driver,
      'timeout':5,
    }

  def _is_shadow_host(self,element:WebElement)->bool:
    '''
    Check if the element is a shadow host.
      - every WebElement has a shadow_root attribute
      - if it's unavailable, access the attribute will raise NoSuchShadowRootException
    Args:
      element (WebElement): the element to check
    Returns:
      bool: True if the element has a shadow root, False otherwise
    '''
    try:
      shadow_root = element.shadow_root
      return shadow_root is not None
    except NoSuchShadowRootException:
      return False
    except AttributeError:
      return False

  def _get_ability_options(self,options:dict|None)->dict:
    if not options:
      return self._default_options
    return {**self._default_options,**options}
