from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.wait.EC import EC

from blues_lib.tools.ability.atom.webdriver.DriverSearcher import DriverSearcher
from blues_lib.tools.TaskContext import TaskContext

class Querier(DriverSearcher):
  
  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._ec = EC(context)

  def query_element(self,options:dict)->WebElement|None:
    return self._search_element(options)

  def query_elements(self,options:dict)->list[WebElement]|None:
    return self._search_elements(options)

  def query_element_length(self,options:dict)->int:
    elems:list[WebElement]|None = self._search_elements(options)
    return len(elems) if elems else 0

  def _get_element(self,options:dict)->WebElement|None:
    '''
    Wait and Get the target WebElement
    Args:
      options (dict): the options for querying the element
    Returns:
      WebElement|None: the first matching element or None if not found
    '''
    return self._ec.presence_of_element_located(options)

  def _get_elements(self,options:dict)->list[WebElement]|None:
    '''
    Wait and Get the target WebElements
    Args:
      options (dict): the options for querying the elements
    Returns:
      list[WebElement]|None: the list of matching elements or None if not found
    '''
    return self._ec.presence_of_all_elements_located(options)