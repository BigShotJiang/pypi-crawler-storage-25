from blues_lib.tools.ability.BaseFacade import BaseFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.atom.AtomAbilityDict import AtomAbilityDict

class AtomFacade(BaseFacade):
  
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    return AtomAbilityDict.get(self._context)
  