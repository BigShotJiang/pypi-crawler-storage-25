from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.supports.dp.exception import  AbilityExecError,SkipLoopWarning,SkipLoopError, SkipSeqError,BlockSeqError


class Dummy(BaseAbility):
  
  def print_data(self,options:dict)->any:
    value:any = options.get("value")
    self._logger.info(f'{self.__class__.__name__}: {value}')
    return value

  def pass_data(self,options:dict)->any:
    return options.get('value')

  def raise_error(self,options:dict)->None:
    message:str = options.get("value") or 'dummy error message'
    name:str = options.get("name")
    if name == AbilityExecError.__name__:
      raise AbilityExecError(message)
    elif name == SkipLoopWarning.__name__:
      raise SkipLoopWarning(message)
    elif name == SkipLoopError.__name__:
      raise SkipLoopError(message)
    elif name == SkipSeqError.__name__:
      raise SkipSeqError(message)
    elif name == BlockSeqError.__name__:
      raise BlockSeqError(message)
    else:
      raise Exception(message)
        
