from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.services.cleaner.DirCleaner import DirCleaner
from blues_lib.services.cleaner.DBCleaner import DBCleaner
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.types import CleanOpts

class Cleaner(BaseAbility):

  def clean(self,options:dict)->STDOut:
    value:CleanOpts = options.get('value',{})
    db_count = DBCleaner(value).clean()
    dir_count = DirCleaner(value).clean()
    return STDOut(200,'ok',{'db':db_count,'dir':dir_count})

