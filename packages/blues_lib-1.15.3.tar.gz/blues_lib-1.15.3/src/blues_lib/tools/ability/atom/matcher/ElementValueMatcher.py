from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility

import re

class ElementValueMatcher(MatcherAbility):

  def element_value_to_equal(self,options:dict)->bool:
    value:str = self._get_element_value(options)
    expected:str = str(options.get('expected')).strip()
    return value==expected

  def element_value_to_match(self,options:dict)->bool:
    value:str = self._get_element_value(options)
    expected:str = str(options.get('expected')).strip()
    return bool(re.search(expected,value))

  def _get_element_value(self,options:dict)->str:
    elem:WebElement|None = self._facade.execute('query_element',options)
    return elem.get_attribute('value').strip() if elem else ''