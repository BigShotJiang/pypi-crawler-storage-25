import pyperclip
import os
import time
from selenium.webdriver.remote.webelement import WebElement

from blues_lib.tools.ability.atom.webdriver.element.interaction.InterBase import InterBase
from blues_lib.utils.file.FileWriter import FileWriter
from blues_lib.utils.file.File import File
from blues_lib.utils.file.FileRemover import FileRemover

class InterClick(InterBase):

  def click_seq(self,options:dict)->bool:
    targets:list[str|WebElement]|str|None = options.get('target','')
    interval:int|float = options.get('interval') or 0.5 
    if not targets:
      return False

    if isinstance(targets,str):
      targets = [targets]

    for target in targets:
      sub_opts = {**options,'target':target}
      self.click(sub_opts)
      time.sleep(interval)
    return True

  def click(self,options:dict)->bool:
    '''
    Click and release
    Args:
      options (dict, optional): The options for clicking element. Defaults to None.
    Returns:
      bool
    '''
    elem:WebElement|None = self._querier.query_element(options)     
    if not elem:
      return False
    
    # can't deal with elemen's parent's invisible
    self._javascript.display_and_scroll_into_view({**options,'target':elem})
    elem.click()
    return True
  
  def click_and_copy(self,options:dict)->str:
    '''
    Click a button and copy text to clipboard
    Args:
      options (dict): javascript options
    Returns:
      str : copied content
    '''
    text:str = self.__copy_text(options)
    if not text:
      return ''

    if max_length:= int(options.get('max_length') or -1):
      text_len:int = len(text)
      if max_length>0 and text_len > max_length:
        text = text[:max_length]+'...'

    return FileWriter.write_or_return(options,text)
    
  def click_and_download(self,options:dict)->str:
    home:str = File.get_blues_download_home()
    filename:str = options.get('filename','')
    item_path:str = os.path.join(home,filename)
    if filename:
      FileRemover.remove_file(item_path)

    success:bool = self.click(options)
    if not success or not filename:
      return ''

    timeout:int|float = options.get('timeout') or 60
    interval:int|float = options.get('interval') or 2
    status:bool = File.wait(item_path,timeout,interval)
    return item_path if status else ''

  def __copy_text(self,options:dict)->str:
    success:bool = self.click(options)
    if not success:
      return ''

    time.sleep(0.2)
    # get the text from the clipboard
    return pyperclip.paste()
