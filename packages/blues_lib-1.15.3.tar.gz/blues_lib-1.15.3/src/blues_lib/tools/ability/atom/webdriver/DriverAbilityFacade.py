from blues_lib.tools.ability.BaseFacade import BaseFacade
from blues_lib.tools.ability.atom.webdriver.DriverAbilityDict import DriverAbilityDict
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

class DriverAbilityFacade(BaseFacade):
    
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    return DriverAbilityDict.get(self._context)
