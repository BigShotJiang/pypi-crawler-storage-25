from selenium.webdriver import ActionChains
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility
from blues_lib.tools.TaskContext import TaskContext

class MouseBase(QuerierAbility):
  """
  Working with mouse actions
  Reference : https://www.selenium.dev/documentation/webdriver/actions_api/mouse/
  """
  
  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._chains = ActionChains(self._driver)
    self._builder = ActionBuilder(self._driver)
