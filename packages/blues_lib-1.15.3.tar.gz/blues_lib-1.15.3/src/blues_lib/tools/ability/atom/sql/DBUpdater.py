from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts,SQLCondition
from blues_lib.services.sql.DBMutator import DBMutator
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper
from blues_lib.supports.dp.output.STDOut import STDOut

class DBUpdater(BaseAbility):

  def sql_update(self,options:SQLOpts)->STDOut:
    table:str = options.get('table')
    entity = SQLHelper.get_entity(options)
    conditions:list[SQLCondition] = SQLHelper.get_conditions(options,entity)

    mutator = DBMutator(table)
    return mutator.update(entity,conditions)
