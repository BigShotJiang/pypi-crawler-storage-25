from blues_lib.utils.file.File import File
from blues_lib.utils.file.FileDownloader import FileDownloader    

from blues_lib.tools.ability.atom.webdriver.element.file.FileBase import FileBase

class FileImage(FileBase):

  def download_images(self,options:dict)->list[str]|None:
    '''
    Download image from image element
    Args:
      options (dict) : the element query options
        - value (list[str]) : the download dirs list
    Returns:
      str : the downloaded file path
    '''
    urls:list[str]|None = self._info.get_srcs(options)
    if not urls:
      return None

    default_dir = File.get_blues_dir_path(['download','img']) 
    file_dir = options.get('value') or default_dir

    result:dict = FileDownloader.download(urls,file_dir)
    if result['code'] !=200:
      return None
    return result['files']
  