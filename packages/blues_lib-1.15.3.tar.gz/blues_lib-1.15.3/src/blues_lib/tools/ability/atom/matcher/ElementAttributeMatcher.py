from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility

import re

class ElementAttributeMatcher(MatcherAbility):

  def element_attribute_to_equal(self,options:dict)->bool:
    value:str = self._get_element_attribute(options)
    expected:str = str(options.get('expected')).strip()
    return value==expected

  def element_attribute_to_match(self,options:dict)->bool:
    value:str = self._get_element_attribute(options)
    expected:str = str(options.get('expected')).strip()
    return bool(re.match(expected,value))

  def _get_element_attribute(self,options:dict)->str:
    elem:WebElement|None = self._facade.execute('query_element',options)
    return elem.get_attribute(options.get('value')).strip() if elem else ''