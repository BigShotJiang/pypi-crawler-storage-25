from blues_lib.tools.ability.BaseFacade import BaseFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.sequence.SeqAbilityDict import SeqAbilityDict

class SeqFacade(BaseFacade):
    
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    return SeqAbilityDict.get(self._context)