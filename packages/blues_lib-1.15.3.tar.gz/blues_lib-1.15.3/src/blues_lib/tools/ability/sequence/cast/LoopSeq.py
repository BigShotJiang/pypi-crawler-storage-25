from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer
from blues_lib.types import SeqOpts,ToolDef,AttemptBy
from blues_lib.supports.dp.exception import SkipLoopWarning,SkipLoopError,AbilityExecError, SkipSeqError, BlockSeqError
from blues_lib.tools.ability.sequence.cast.BaseSeq import BaseSeq

class LoopSeq(BaseSeq):

  _SUMMARY_KEY:str = 'loop'

  # Public API
  def cast_loop(self,options:SeqOpts)->list[dict[str,any]]:
    self._prepare(options)
    return self._process()

  def _process(self)->list[dict[str,any]]:
    attempts:int = int(self._tool_summary.get('attempts') or -1)
    attempt_by:AttemptBy = self._tool_summary.get('attempt_by') or 1
    # like page item
    attempt_item:dict = self._tool_summary.get('attempt_item') or {}

    items:list[dict[str,any]] = self._iter_helper.get_loop_items(attempt_by)
    results:list[dict[str,any]] = []
    for idx,item in enumerate(items):
      # use the real result to check if skip or not
      item = {**attempt_item,**item}
      result_len:int = len(results)
      if attempts>0 and result_len>=attempts:
        break

      try:
        result:dict = self._cast_single(item,idx)
        results.append(result)
      except (SkipSeqError,BlockSeqError) as e:
        raise e
      except (SkipLoopWarning) as e:
        self._logger.warning(e)
        continue
      except (SkipLoopError,AbilityExecError,Exception) as e:
        self._logger.warning(e)
        self._cast_by_error(item,idx)
        continue

      self._iter_helper.delay(self._tool_summary)

    self._logger.info(f'cast loop by {len(items)} items (attempts={attempts}) and  get {len(results)} results')
    return results
  
  def _cast_single(self,item:dict[str,any],idx:int)->dict:
    # support typed item,nest cast's bizdata is it's options
    self._set_type_tools(item)
    tool_defs:list[ToolDef] = self._seq_opts.get('tools')
    return self._cast_by_item(tool_defs,item,idx)
  
  def _cast_by_error(self,item:dict,idx:int)->None:
    tool_defs:list[ToolDef] = self._tool_summary.get('skip_loop_tools')
    if tool_defs:
      self._cast_by_item(tool_defs,item,idx)
  
  def _cast_by_item(self,tool_defs:list[ToolDef],item:dict[str,any],idx:int)->dict:
    loop_biz:dict[str,any] = {
      **(item or {}),
      '_item':item, # the whole item data
      '_index':idx,
      '_no':idx+1
    }
    tool_defs = Jinja2Renderer.render_loop(tool_defs,loop_biz)
    return self._cast(tool_defs)

  def _set_type_tools(self,item:dict[str,any])->None:
    type_tools:dict = self._seq_opts.get('type_tools') or {}
    if not type_tools:
      return

    item_type:str = item.get('type') or ''
    if not item_type:
      raise ValueError(f'has type_tools but item type is empty')

    # such as: {"text":{"tools":[]}}
    sub_seq_opts:dict = type_tools.get(item_type) or {}
    if not sub_seq_opts:
      raise ValueError(f'has type_tools but no tools for item type {item_type}')

    # add tools to seq_opts
    self._seq_opts.update(sub_seq_opts)
