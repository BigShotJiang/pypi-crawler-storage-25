from abc import ABC,abstractmethod
from blues_lib.types import ToolDef,ToolSummary
from blues_lib.tools.TaskContext import TaskContext

class HookHandler(ABC):
  def __init__(self,tool_summary:ToolSummary,context:TaskContext) -> None:
    self._tool_summary = tool_summary
    self._context = context
    
    self._prev_tools:list[ToolDef] = self._tool_summary.get('prev_tools')
    self._post_tools:list[ToolDef] = self._tool_summary.get('post_tools')
    self._skip_loop_tools:list[ToolDef] = self._tool_summary.get('skip_loop_tools')
    self._skip_seq_tools:list[ToolDef] = self._tool_summary.get('skip_seq_tools')
    self._block_seq_tools:list[ToolDef] = self._tool_summary.get('block_seq_tools')
    
    self._prev_tool_names:list[str] = [tool.get('name') for tool in self._prev_tools]
    self._post_tool_names:list[str] = [tool.get('name') for tool in self._post_tools]
    self._skip_loop_tool_names:list[str] = [tool.get('name') for tool in self._skip_loop_tools]
    self._skip_seq_tool_names:list[str] = [tool.get('name') for tool in self._skip_seq_tools]
    self._block_seq_tool_names:list[str] = [tool.get('name') for tool in self._block_seq_tools]

  @abstractmethod
  def handle(self)->None:
    pass
