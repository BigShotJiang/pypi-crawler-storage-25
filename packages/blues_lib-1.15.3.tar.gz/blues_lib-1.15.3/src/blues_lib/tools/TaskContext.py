import logging
import uuid
from datetime import datetime
from typing import Callable
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.types import DriverMode,DriverStartupOpts,DriverLocOpts,DriverDef,ToolDef
from blues_lib.tools.ability.atom.webdriver.driver.DriverFactory import DriverFactory   

class TaskContext:
  _DEFAULT_CONTEXT:DriverDef = {
    "notify":{
      "mode":"ding",
    },
    "driver":{
      "mode":"cft",
      "startup":{
        "features" : ["imageless"],
      },
    },
  }

  def __init__(self,config:dict|None = None):
    self._logger = logging.getLogger('airflow.task')
    self.id:str = str(uuid.uuid4())
    self._config:dict = config or self._DEFAULT_CONTEXT
    self.driver:WebDriver|None = None
    self._total_result_list:list[any] = []
    self._total_result_dict:dict[str,any] = {}
    self._total_stats:list[dict] = []
    self._setup()
    
  def add_result(self,id:str,result:any)->None:
    self._total_result_list.append(result)
    self._total_result_dict[id] = result

  @property
  def last_result(self)->any:
    return self._total_result_list[-1] if self._total_result_list else None

  @property
  def result(self)->dict[str,any]:
    return self._total_result_dict
      
  @property
  def result_list(self)->list[any]:
    return list(self.result.values())

  def _setup(self)->None:
    self._set_driver()
    
  def _set_driver(self)->None:
    driver:WebDriver|dict|bool = self._config.get('driver')
    if isinstance(driver,WebDriver):
      self.driver = driver
      return

    # don't need driver
    if driver is False:
      self.driver = False
      return 

    self.clear_driver()

    mode:DriverMode = driver.get('mode') or 'cft'
    startup_opts:DriverStartupOpts = driver.get('startup') or {}
    location_opts:DriverLocOpts = driver.get('location') or {}

    factory =  DriverFactory(**startup_opts)
    method:Callable = getattr(factory,mode)
    self.driver = method(**location_opts)
  
  def clear_driver(self)->None:
    if self.driver:
      self.driver.quit()
      self.driver = None
      
  def teardown(self)->None:
    self.log()
    self.clear_driver()

  def get_id(self,id:str,name:str='')->str:
    return id or self.get_auto_id(name)
  
  def get_meta_id(self,meta:dict)->str:
    name:str = meta.get('name')
    id:str = meta.get('options', {}).get('id')
    return self.get_id(id,name)
  
  def get_auto_id(self,name:str,prefix:str='__')->str:
    '''
    基于name生成在 _total_result_dict 中的唯一id，生成规则:
    - 在name前加_作为内置id标识前缀
    - 在name后加_n作为id后缀，同时避免重复
    - 如果name不存在则_n为_0，后续重复则_n+1
    '''
    n = 0
    while True:
      auto_id = f"{prefix}{name}_{n}"
      if auto_id not in self._total_result_dict:
        return auto_id
      n += 1

  def add_stat(self,stat:bool,name:str,description:str,error:str='')->None:
    self._total_stats.append({'stat':stat,'name':name,'description':description,'error':error})

  def log(self)->None:
    log_text:str = self._get_log_text()
    if not log_text:
      return

    from blues_lib.tools.ability.AbilityExecutor import AbilityExecutor
    tools:list[ToolDef] = self._get_log_tools(log_text)
    self._logger.info(log_text)
    AbilityExecutor(self).execute(tools)

  def _get_log_text(self):
    if not self._total_stats:
      return ''
    
    last_stat:dict = self._total_stats[-1]
    stat:bool = last_stat.get('stat')
    name:str = last_stat.get('name')
    description:str = last_stat.get('description')
    error:str = last_stat.get('error')
    stat:str = "PASS" if stat else "FAIL"
    dtime:str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    title:str = f'{name} task'
    if description:
      title += f' [{description}]'
    
    text:str = f'{title} {stat} on {dtime}'
    if error:
      text += f'\nerror:{error}'
    return text

  def _get_log_tools(self,log_text:str)->list[ToolDef]:
    screenshot_tool:ToolDef = {
      "name":"save_screenshot",
      "options":{
        "id":"screenshot",
      },
    }
    ding_tool:ToolDef = {
      "name":"ding_group",
      "options":{
        "msgtype":"markdown",
        "title":"Ablity Stat",
        "text":"### "+log_text+"\n Screenshot: [[screenshot]]",
      }
    }
    tools:list[ToolDef] = [
      {
        "name":"append_log",
        "options":{
          "id":"logfile",
          "message":f"\n\n"+log_text+"\n Screenshot: [[screenshot]]",
        }
      },
    ]
    if self.driver:
      tools.insert(0,screenshot_tool)

    if self._config.get('notify',{}).get('mode') == 'ding':
      tools.append(ding_tool)
    return tools