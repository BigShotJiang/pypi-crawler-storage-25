from blues_lib.types import ToolDef

from blues_lib.tools.airflow.PythonOperator import PythonOperator
from blues_lib.tools.airflow.OperatorCreater import OperatorCreater

class DAG:
  @classmethod
  def execute(cls,ctx_meta:dict,meta:ToolDef)->None:
    creater = OperatorCreater(ctx_meta,meta,PythonOperator)
    operators = creater.get_operators()
    for operator in operators:
      operator.execute()

  @classmethod
  def repeat(cls,metas_seq:list[tuple[dict|None,dict]])->None:
    for ctx,meta in metas_seq:
      cls.execute(ctx,meta)