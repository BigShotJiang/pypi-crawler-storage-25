from typing import Any
from copy import deepcopy
from blues_lib.resources.ResourceManager import ResourceManager
from blues_lib.utils.hocon.render.ResourceRenderer import ResourceRenderer
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer
from blues_lib.resources.definition.ToolDefConverter import ToolDefConverter
from blues_lib.utils.url.URIManager import URIManager

class ResourceLoader:
  
  _TOOL_KEYS = ['tools','prev_tools','post_tools','skip_loop_tools','skip_seq_tools','block_seq_tools']
  _TASK_TOOL_KEY = 'tools'
  
  @classmethod
  def read(cls,uri:str)->Any:
    return ResourceManager.read(uri)

  @classmethod
  def load(cls,resource:dict|str)->dict:
    '''
    Read hocon resources and include it's child hocon resources.
    Args:
      resource (dict|str): The resource, support three types:
        - dict: The resource is already loaded.
        - str of uri: The resource is a uri.
        - str of file path: The resource is a file path. support slash path or dot path.
    Returns:
      dict: The loaded resource.
    '''
    if not resource or not isinstance(resource,str):
      return resource

    if not URIManager.is_uri(resource):
      resource = cls.register(resource)

    if ResourceManager.is_property_uri(resource):
      return cls.read(resource)

    return ResourceRenderer(resource).render()

  @classmethod
  def load_repeat_metas(cls,resource:dict|str,repeat_by:int|list=0)->list[tuple[dict|None,dict]]:
    orig_meta:dict = cls.load(resource)
    repeat_items:list[tuple[dict,dict]] = cls.__get_repeat_items(orig_meta,repeat_by)
    repeat_metas:list[tuple[dict|None,dict]] = []
    for items in repeat_items:
      meta_copy:dict = deepcopy(orig_meta) # keep all replaceholders
      metas:tuple[dict|None,dict] = cls.load_metas(meta_copy,*items)
      repeat_metas.append(metas)
    return repeat_metas

  @classmethod
  def load_metas(cls,resource:dict|str,globals:dict|None=None,context:dict|None=None)->tuple[dict|None,dict]:
    meta:dict = cls.load_meta(resource,globals)
    ctx:dict = cls.__merge_context(meta,context)
    return ctx,meta

  @classmethod
  def load_meta(cls,resource:dict|str,globals:dict|None=None)->dict:
    '''
    Load and interpolate by iteself.
    Args:
      resource (dict|str): The resource, support three types:
        - dict: The resource is already loaded.
        - str of uri: The resource is a uri.
        - str of file path: The resource is a file path. support slash path or dot path.
      globals (dict|None, optional): The globals to interpolate the resource with.
        Defaults to None.
    Returns:
      dict: The interpolated resource.
    '''
    meta:dict = cls.__load_and_convert(resource)
    merged_globals:dict = cls.__merge_globals(meta,globals)
    if not merged_globals:
      return meta
    return Jinja2Renderer.render(meta,merged_globals)

  @classmethod
  def __get_repeat_items(cls,meta:dict,repeat_by:int|list)->list[tuple[dict,dict]]:
    items:list[tuple[dict,dict]] = []
    inner_repeat_by:int|list = meta.pop('repeat_by', 1)
    if not repeat_by:
      repeat_by = inner_repeat_by
    if isinstance(repeat_by,int):
      for i in range(repeat_by):
        globals:dict = {}
        context:dict = {}
        items.append((globals,context))
    else:
      for item in repeat_by:
        if not item:
          continue
        if isinstance(item,dict):
          globals:dict = item
          context:dict = {}
          items.append((globals,context))
        elif isinstance(item,list) or isinstance(item,tuple):
          globals:dict = item[0]
          context:dict = item[1] if len(item) > 1 else {}
          items.append((globals,context))
    return items

  @classmethod
  def __merge_context(cls,meta:dict,context:dict|None=None)->dict:
    inner_ctx:dict = meta.pop('context', {})
    outer_ctx:dict = context or {}
    merged_ctx:dict = {**inner_ctx,**outer_ctx}
    return merged_ctx

  @classmethod
  def __merge_globals(cls,meta:dict,globals:dict|None=None)->dict:
    inner_globals:dict = meta.pop('globals', {})
    outer_globals:dict = globals or {}
    merged_globals:dict = {**inner_globals,**outer_globals}
    # render globals by itself
    if not merged_globals:
      return {}
    return Jinja2Renderer.render(merged_globals,merged_globals)

  @classmethod
  def __load_and_convert(cls,resource:dict|str)->dict:
    meta:dict = cls.load(resource)
    cls.convert_standard_tools(meta)
    return meta

  @classmethod
  def register(cls,dot_or_path:str)->str:
    '''
    使用本地dot或文件path地址
    '''
    temp_uri = f'template://{dot_or_path}'
    ResourceManager.register(temp_uri,dot_or_path)
    return temp_uri
  
  @classmethod
  def convert_standard_tools(cls,task_biz:dict,excludes:list[str]=[])->None:
    '''
    将简写的工具定义转换为标准的工具定义元数据，使用 ToolDefConverter.convert(value) 实现转换，并直接修改数据节点的值。
    该方法不返回任何值，仅在原数据节点上进行修改。
    
    转换规则：
    1. 递归task_biz的所有dict和list节点。
    2. 如果属性名是 _TOOL_KEYS 中的任意一个，递归调用 ToolDefConverter.convert(value) 替换此节点的值。
    3. 注意替换值后，要继续递归处理子节点。
    Args:
      task_biz (dict): 任务业务数据元数据字典
    Returns:
      None
    '''
    if not isinstance(task_biz, dict):
      return

    for key, value in task_biz.items():
      if key in cls._TOOL_KEYS and value is not None and key not in excludes:
        task_biz[key] = ToolDefConverter.convert(value)
        cls._process_value(task_biz[key])
      else:
        cls._process_value(value)

  @classmethod
  def _process_value(cls, value: Any) -> None:
    if isinstance(value, dict):
      cls.convert_standard_tools(value)
    elif isinstance(value, list):
      for item in value:
        cls._process_value(item)
      