from typing import Any
from blues_lib.resources.property.DateTime import DateTime

class PropertyReader():

  NAMESPACES = {
    'datetime': DateTime,
  }

  @classmethod
  def get(cls, path:str)->Any:
    segments:list[str] = path.split('/')
    if len(segments) < 2:
      raise ValueError(f"property path {path} is invalid")

    namespace:str = segments[0]
    property_class = cls.NAMESPACES.get(namespace)
    if not property_class:
      raise ValueError(f"property namespace {namespace} not found")
    
    property_name:str = segments[1]
    return property_class.get(property_name)