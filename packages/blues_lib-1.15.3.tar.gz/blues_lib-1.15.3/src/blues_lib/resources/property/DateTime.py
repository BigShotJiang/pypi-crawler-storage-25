from typing import Any
from blues_lib.utils.datetime.DateTimeManager import DateTimeManager

class DateTime():

  PROPERTIES = {
    "timestamp": lambda: DateTimeManager.get_timestamp(),
    "now": lambda: DateTimeManager.get_now(),
  }

  @classmethod
  def get(cls, name:str)->Any:
    if name not in cls.PROPERTIES:
      raise ValueError(f"property {name} not found")
    return cls.PROPERTIES[name]()
