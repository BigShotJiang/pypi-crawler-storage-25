import re,os
from typing import Any
from blues_lib.utils.resource.ResourceReader import ResourceReader
from blues_lib.utils.url.URIManager import URIManager
from blues_lib.utils.file.DotFileReader import DotFileReader
from blues_lib.utils.file.FileReader import FileReader
from blues_lib.resources.property.PropertyReader import PropertyReader

class ResourceManager:
  
  _SCHEME_NAMESPACES = {
    'example': 'blues_lib.resources.example',
    'definition': 'blues_lib.resources.definition',
    'template': 'blues_lib.resources.template',
    'bizdata': 'blues_lib.resources.bizdata',
    'schema': 'blues_lib.resources.schema',
  }
  _TEMP_RESOURCES = {}
  _PROJECT_DIR = os.getenv('PROJECT_DIR','blues-lib-py')
  _PROJECT_HOME = os.getenv('PROJECT_HOME','')

  @classmethod
  def read(cls, uri:str) -> Any:
    '''
    Read resource from URI
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
    Returns:
      Any: Resource content
    '''
    if uri in cls._TEMP_RESOURCES:
      return cls._TEMP_RESOURCES[uri]
    
    segments:dict[str,str] = URIManager.parse(uri)
    scheme:str = segments.get('scheme')
    netloc:str = segments.get('netloc','')
    path:str = segments.get('path','')

    if scheme == 'property':
      return cls.read_property(netloc+path)

    package:str = cls._SCHEME_NAMESPACES.get(scheme,'')
    if not package:
      raise ValueError(f'{uri} is a unknow resource')

    conf_file:str = netloc+path
    if not conf_file.endswith('.conf'):
      conf_file += '.conf'

    return ResourceReader.read_hocon(package, conf_file)
  
  @classmethod
  def is_property_uri(cls,uri:str)->bool:
    segments:dict[str,str] = URIManager.parse(uri)
    scheme:str = segments.get('scheme')
    return scheme == 'property'

  @classmethod
  def read_temp(cls, uri:str) -> Any|None:
    '''
    Read temporary resource from URI
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
    Returns:
      Any: Resource content
    '''
    return cls._TEMP_RESOURCES.get(uri)

  @classmethod
  def read_property(cls, property_path:str) -> Any|None:
    '''
    Read property resource from URI
    Args:
      property_path {str} : Property path, such as 'datetime/now'
    Returns:
      Any: Property content
    '''
    return PropertyReader.get(property_path)

  @classmethod
  def register(cls, uri:str, resource:Any) -> str:
    '''
    Register temporary resource to URI
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
      resource {Any} : Resource content
    Returns:
      Any: Resource content
    '''
    if isinstance(resource, str) and cls.is_dot_path(resource):
      return cls.register_by_dot_path(uri, resource)

    if isinstance(resource, str) and cls.is_file_path(resource):
      return cls.register_by_file_path(uri, resource)

    cls._TEMP_RESOURCES[uri] = resource
    return uri

  @classmethod
  def is_dot_path(cls, dot_path:str) -> bool:
    '''
    Check if dot path is valid
    Args:
      dot_path {str} : Dot path, such as 'tests.task.browser.login.def'
    Returns:
      bool: True if dot path is valid
    '''
    pattern = r'^[^/\\.]+(?:\.[^/\\.]+)+$'
    return bool(re.match(pattern, dot_path))

  @classmethod
  def is_file_path(cls, file_path:str) -> bool:
    '''
    Check if file path is valid, support Win and Linux and Mac
    Args:
      file_path {str} : absolute file path, such as '/Users/bluesliu/Documents/Projects/python/blues-lib-py/tests/task/browser/login.def'
    Returns:
      bool: True if file path is valid
    '''
    # 合法路径（相对+绝对），排除系统非法字符
    pattern = r'^[^<>:"|?*]+[/\\][^<>:"|?*]*$'
    return bool(re.match(pattern, file_path))

  @classmethod
  def register_by_dot_path(cls, uri:str, dot_path:str) -> str:
    '''
    Register temporary resource to URI by file path
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
      dot_path {str} : Dot path, such as 'tests.task.browser.login.def'
    Returns:
      Any: Resource content
    ''' 
    resource:Any = DotFileReader.read_hocon(cls._PROJECT_DIR,dot_path)
    cls._TEMP_RESOURCES[uri] = resource
    return uri
  
  @classmethod
  def register_by_file_path(cls, uri:str, file_path:str) -> str:
    '''
    Register temporary resource to URI by file path
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
      file_path {str} : absolute file path, such as '/Users/bluesliu/Documents/Projects/python/blues-lib-py/tests/task/browser/login.def'
    Returns:
      Any: Resource content
    '''
    if not os.path.isabs(file_path):
      file_path = os.path.normpath(os.path.join(cls._PROJECT_HOME, file_path))
    if not file_path.endswith('.conf'):
      file_path += '.conf'
    resource:Any = FileReader.read_hocon(file_path)
    cls._TEMP_RESOURCES[uri] = resource
    return uri
