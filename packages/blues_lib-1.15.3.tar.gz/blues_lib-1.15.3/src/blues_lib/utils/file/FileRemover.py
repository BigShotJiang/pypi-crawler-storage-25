import os
import logging
from datetime import datetime,timedelta
from blues_lib.utils.file.File import File

class FileRemover: 
  _logger = logging.getLogger('airflow.task')

  @classmethod
  def remove_dirs(cls,directory:str,retention_days=0)->int:
    '''
    @description Remove all child dir and files
    @param {string} directory 
    '''
    threshold = datetime.now() - timedelta(days=retention_days)
    removed_count = 0
    if not File.exists(directory):
      return removed_count

    for root, dirs, files in os.walk(directory):
      for file in files:
        file_path = os.path.join(root, file)
        if cls.__remove_once(file_path,retention_days):
          removed_count +=1
      for dire in dirs:
        dir_path = os.path.join(root, dire)
        file_modified_time = datetime.fromtimestamp(os.path.getmtime(dir_path))
        if file_modified_time < threshold:
          # recursion to remove the dir
          removed_count += cls.remove_dirs(dir_path,retention_days)
    # remove the base dir
    if File.is_dir_empty(directory):
      os.rmdir(directory)
      removed_count +=1
    return removed_count

  @classmethod
  def remove_files(cls,dir_path:str,retention_days=0)->int:
    '''
    @description : clear files before n days
    @param {str} directory
    @param {int} retention_days : default 7
    @returns {int} deleted files count
    '''
    removed_count = 0
    for item in os.scandir(dir_path):
      if cls.__remove_once(item.path,retention_days):
        removed_count +=1
    return removed_count

  @classmethod
  def remove_file(cls,file_path:str,retention_days=0)->bool:
    '''
    @description : clear file before n days
    @param {str} file_path
    @param {int} retention_days : default 7
    @returns {bool} deleted file count
    '''
    if not File.exists(file_path):
      return True
    return cls.__remove_once(file_path,retention_days)

  @classmethod
  def __remove_once(cls,item_path:str,retention_days)->bool:
    '''
    @description : clear file before n days
    @param {str} item_path
    @param {int} retention_days : default 7
    @returns {bool} deleted file count
    '''
    if not os.path.isfile(item_path):
      return True

    threshold = datetime.now() - timedelta(days=retention_days)
    # 获取文件的最后修改时间
    file_modified_time = datetime.fromtimestamp(os.path.getmtime(item_path))
    # 如果文件的最后修改时间早于阈值，则删除文件
    if file_modified_time < threshold:
      try:
        os.remove(item_path)
        return True
      except OSError as e:
        cls._logger.warning(f"remove file {item_path} failed, {e}")
        return False
    return True