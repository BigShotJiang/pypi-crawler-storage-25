import os,time
import uuid
from datetime import datetime,timedelta
from pathlib import Path
from blues_lib.utils.datetime.DateTimeManager import DateTimeManager

class File():

  @classmethod
  def get_project_home(cls)->str:
    return os.environ.get('PROJECT_HOME') or ''

  @classmethod
  def get_project_package(cls)->str:
    return os.environ.get('PROJECT_PACKAGE') or ''

  @classmethod
  def get_project_test(cls)->str:
    return os.environ.get('PROJECT_TEST') or ''

  @classmethod
  def get_home(cls)->str:
    return str(Path.home())
 
  @classmethod
  def get_blues_home(cls)->str:
    home:str = cls.get_home()
    dir_path:str = os.path.join(home,'.blues')
    return cls.makedirs(dir_path)
 
  @classmethod
  def get_blues_cft_home(cls)->str:
    # 此目录 存放chrome cft资源
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'cft')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_log_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'log')
    return cls.makedirs(dir_path)
 
  @classmethod
  def get_today_log_home(cls,subdir:str|list[str]=''):
    '''
    Get the today log home
    Parameter:
      subdir {None|str|list} : the sub dirs
        None: return the root dir
        str: return the subdir
        list: return the multi subdir
    '''
    today = datetime.now().strftime("%Y-%m-%d")
    root = cls.get_blues_log_home()
    subdir = subdir if type(subdir)==list else [subdir]
    dir_path = os.path.join(root,today,*subdir)
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_download_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'browser_download')
    return cls.makedirs(dir_path)

  @classmethod
  def get_today_download_home(cls,subdir:str|list[str]=''):
    '''
    Get the today download home
    Parameter:
      subdir {None|str|list} : the sub dirs
        None: return the root dir
        str: return the subdir
        list: return the multi subdir
    '''
    today = datetime.now().strftime("%Y-%m-%d")
    root = cls.get_blues_download_home()
    subdir = subdir if type(subdir)==list else [subdir]
    dir_path = os.path.join(root,today,*subdir)
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_cache_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'cache')
    return cls.makedirs(dir_path)
 
  @classmethod
  def get_blues_temp_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'temp')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_file_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'file')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_dir_path(cls,subdir:str|list[str]=''):
    '''
    Get the blues lib's standard dir path
    Parameter:
      subdir {None|str|list} : the sub dirs
        None: return the root dir
        str: return the subdir
        list: return the multi subdir
    '''
    blues_home:str = cls.get_blues_home()
    if not subdir:
      dirs = []

    dirs = subdir if type(subdir)==list else [subdir]
    # support multi level dirs
    dir_path = os.path.join(blues_home,*dirs)

    # create dir
    cls.makedirs(dir_path)
    return dir_path 

  @classmethod
  def get_blues_file_path(cls,subdir:str|list[str],filename:str,extension='txt'):
    '''
    Get the file absolute path base the blues lib root dir
    Support add subdirs
    Parameter:
      subdir {str,list} : one or multi level dirs
      filename {str} : the filename
    '''
    dir_path = cls.get_blues_dir_path(subdir)
    filename = '%s.%s' % (filename,extension) if extension else filename
    return os.path.join(dir_path,filename)

  @classmethod
  def get_file_name(cls,prefix='',name='',suffix='',extension=''):
    file_name = name if name else int(time.time()*1000)
    if prefix:
      file_name='%s-%s' % (prefix,file_name)
    if suffix:
      file_name='%s-%s' % (file_name,suffix)
    if extension:
      file_name='%s.%s' % (file_name,extension)
    return file_name 

  @classmethod
  def get_abs_path(cls,root_dir:str,path:str)->str:
    cur_path = os.path.realpath(__file__)
    root_path = os.path.join(cur_path.split(root_dir)[0],root_dir)
    return os.path.join(root_path,path)

  @classmethod
  def get_abs_file(cls,options:dict|str|bool)->str:
    if options is True:
      options = {
        'filename':str(uuid.uuid4())+'.txt',
      }

    if isinstance(options,str):
      options = {
        'absfile':options,
      }

    absfile:str = options.get("absfile") or ''
    if absfile:
      return absfile

    absdir:str|list[str] = options.get("absdir") or ''
    extension:str = options.get("extension") or 'txt'
    default_name:str = str(uuid.uuid4())
    filename:str = options.get("filename", default_name)
    name, ext = os.path.splitext(filename)
    ext = ext.lstrip('.') if ext else extension

    if absdir:
      absdir = absdir if isinstance(absdir,list) else [absdir]
      return os.path.join(*absdir,f'{name}.{ext}')

    options.setdefault('subdir','temp')
    subdir:str|list[str] = options.get("subdir")
    return File.get_blues_file_path(subdir,name,ext)

  @classmethod
  def exists(cls,path)->bool:
    '''
    @description : Does a dir or file exist
    @param {str} path
    @returns {bool} 
    '''
    return os.path.exists(path)

  @classmethod
  def is_dir_empty(cls,dir_path)->bool:
    return not bool(os.listdir(dir_path))

  @classmethod
  def filter_exists(cls,files)->list[str]:
    exists_files = []
    for file in files:
      if not cls.exists(file):
        continue
      exists_files.append(file)
    return exists_files

  @classmethod
  def makedirs(cls,dir_path)->str:
    '''
    @description : Create dirs (support multilevel directory) if they don't exist
    @param {str} dir_path : multilevel dir
    @returns {None}
    '''
    if not cls.exists(dir_path):
      os.makedirs(dir_path)
    return dir_path

  @classmethod
  def readfiles(cls,dir_path:str)->list[str]:
    '''
    Read the file list in a dir, don't support the next dirs
    @param {string} directory 
    '''
    file_list = []
    for root, dirs, files in os.walk(dir_path):
      for file in files:
        file_list.append(os.path.join(root, file))
    return file_list

  @classmethod
  def wait(cls,item_path:str,timeout:int|float=1,interval:int|float=1)->bool:
    '''
    Wait for a file or dir to exist
    @param {str} item_path : file or dir path
    @param {int|float} timeout : default 1s
    @param {int|float} interval : default 0.5s
    @returns {bool} 
   '''
    start_time = time.time()
    while not cls.exists(item_path) and time.time() - start_time < timeout:
      DateTimeManager.count_down({
        'duration':interval,
        'title':f'Waiting for {item_path} to exist'
      })
    return cls.exists(item_path)

  @classmethod
  def get_extension(cls,file_path: str, keep_dot: bool = False) -> str:
    """
    从文件路径获取扩展名
    :param file_path: 文件完整路径/文件名
    :param keep_dot: 是否保留前面的点，默认 False 不带点
    :return: 扩展名，无后缀返回空字符串
    """
    suffix = Path(file_path).suffix
    if keep_dot:
      return suffix
    return suffix.lstrip(".")

  @classmethod
  def get_full_suffixes(cls,file_path: str) -> list[str]:
    """获取全部多级后缀，例如 xxx.tar.gz → ['.tar', '.gz']"""
    return Path(file_path).suffixes