from blues_lib.types import EmailOpts

class PublishHelper():

  @staticmethod
  def get_opts(opts:dict)->EmailOpts:
    value:dict = opts.get('value',{})
    entities:list[dict] = value.get('entities',[])
    subject = PublishHelper._get_subject(entities)
    paras = PublishHelper._get_paras(entities)
    return {
      'subject':subject,
      'paras':paras,
      'addressee':value.get('addressee',''),
      'addressee_name':value.get('addressee_name'),
    }
    
  @staticmethod
  def _get_subject(entities:list[dict])->str:
    success_count = 0
    failure_count = 0
    first_title:str = ''
    for entity in entities:
      mat_title:str = entity.get('mat_title','')
      pub_stat:str = entity.get('pub_stat','')
      if not first_title:
        first_title = mat_title
      
      if pub_stat == 'success':
        success_count += 1
      else:
        failure_count += 1
    return f'Published {success_count} succeeded, {failure_count} failed : {first_title}'
    
  @staticmethod
  def _get_paras(entities:list[dict])->list[dict]:
    paras = []
    for entity in entities:
      title:str = entity.get('mat_title','')
      pub_stat:str = entity.get('pub_stat','')
      pub_shot:str = entity.get('pub_shot','')
      paras.append({
        'type':'text',
        'value':f'{title} - {pub_stat}',
      })
      if pub_shot:
        paras.append({
          'type':'image',
          'value':pub_shot,
        })
    return paras
