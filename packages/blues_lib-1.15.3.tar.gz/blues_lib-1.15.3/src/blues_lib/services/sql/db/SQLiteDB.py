import os
import sqlite3

from blues_lib.services.sql.db.BaseDB import BaseDB
from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut


class SQLiteDB(BaseDB):

  sqlite = None

  @property
  def db_type(self) -> str:
    return 'sqlite'

  def _get_connector(self):
    db_path: str = self._account.get('db_path') or os.environ.get('SQLITE_DB_PATH') or 'dpp_data.db'

    db_dir = os.path.dirname(db_path)
    if db_dir and not os.path.exists(db_dir):
      os.makedirs(db_dir, exist_ok=True)

    return sqlite3.connect(
      db_path,
      check_same_thread=False,
      timeout=30
    )

  def _execute(self, sql: str, values=None) -> SQLSTDOut:
    if self.is_conn_lost():
      self._set_cursor()

    try:
      invoker = self._get_invoker_name()

      if values and self._is_series(values[0]):
        count = self.cursor.executemany(sql, values)
      else:
        count = self.cursor.execute(sql, values) if values else self.cursor.execute(sql)

      self.connector.commit()

      return self._build_result(
        invoker=invoker,
        code=200,
        count=count.rowcount if hasattr(count, 'rowcount') else 0,
        lastid=self.cursor.lastrowid if invoker == 'post' else None,
        sql=sql
      )

    except Exception as e:
      invoker = self._get_invoker_name()
      return self._build_result(
        invoker=invoker,
        code=500,
        message=str(e),
        sql=sql
      )

  def _rows_to_dict(self, rows) -> list:
    if not rows:
      return []

    column_names = [desc[0] for desc in self.cursor.description] if self.cursor.description else []
    dict_rows = []
    for row in rows:
      dict_row = {}
      for i, col_name in enumerate(column_names):
        dict_row[col_name] = row[i]
      dict_rows.append(dict_row)
    return dict_rows
