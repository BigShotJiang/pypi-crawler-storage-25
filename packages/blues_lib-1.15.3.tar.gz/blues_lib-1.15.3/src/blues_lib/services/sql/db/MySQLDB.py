import os
import pymysql
from pymysql.converters import escape_string

from blues_lib.services.sql.db.BaseDB import BaseDB
from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut


class MySQLDB(BaseDB):

  mysql = None

  @property
  def db_type(self) -> str:
    return 'mysql'

  def _get_connector(self):
    host: str = self._account.get('host') or os.environ.get('MYSQL_HOST')
    user: str = self._account.get('user') or os.environ.get('MYSQL_USER')
    password: str = self._account.get('password') or os.environ.get('MYSQL_PASSWORD')
    database: str = self._account.get('database') or os.environ.get('MYSQL_DATABASE')

    return pymysql.connect(
      host=host,
      user=user,
      password=password,
      database=database,
      cursorclass=pymysql.cursors.DictCursor,
      connect_timeout=90,
      read_timeout=90,
      write_timeout=160
    )

  def _execute(self, sql: str, values=None) -> SQLSTDOut:
    if self.is_conn_lost():
      self._set_cursor()

    try:
      invoker = self._get_invoker_name()

      if values and self._is_series(values[0]):
        count = self.cursor.executemany(sql, self._get_escape_rows(values))
      else:
        count = self.cursor.execute(sql, self._get_escape_row(values))

      self.connector.commit()

      return self._build_result(
        invoker=invoker,
        code=200,
        count=count,
        lastid=self.cursor.lastrowid if invoker == 'post' else None,
        sql=sql
      )

    except Exception as e:
      invoker = self._get_invoker_name()
      return self._build_result(
        invoker=invoker,
        code=500,
        message=str(e),
        sql=sql
      )

  def _get_escape_row(self, row):
    if not row:
      return row
    escape_row = []
    for value in row:
      if type(value) == str:
        escape_row.append(escape_string(value))
    return escape_row

  def _get_escape_rows(self, rows):
    if not rows:
      return rows
    escape_rows = []
    for row in rows:
      escape_rows.append(self._get_escape_row(row))
    return escape_rows

  def _rows_to_dict(self, rows) -> list:
    return rows if rows else []
