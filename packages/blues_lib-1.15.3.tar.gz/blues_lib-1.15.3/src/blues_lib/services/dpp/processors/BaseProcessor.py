from abc import abstractmethod
from blues_lib.supports.dp.chain.LastMatchHandler import LastMatchHandler
from blues_lib.services.dpp.db.FlushHelper import FlushHelper
from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut


class BaseProcessor(LastMatchHandler):
  """
  所有数据处理器的统一基类。
  核心原则：
    - 每个handler只处理 request['entities']
    - 遇到invalid数据立即写入数据库（stat='invalid'）并从entities移除
    - 只有valid数据继续流转到下一个handler
  """

  _RULE_KEY: str = ''

  def resolve(self) -> bool:
    entities, config = self._prepare()
    if not entities:
      return False
    if not config:
      return True

    input_count = len(entities)
    valid_entities, invalid_entities = self._process(entities, config)
    result = self._post_process(valid_entities, invalid_entities, config)
    self._logger.info(f'input {input_count} -> output {len(valid_entities)}')
    return result

  def _prepare(self) -> tuple[list, dict]:
    entities = self._request.get('entities', [])
    config = self._get_config()
    return entities, config

  def _post_process(self, valid_entities: list, invalid_entities: list, config: dict) -> bool:
    persist_config = self._request.get('rule', {}).get('persist', {})
    result:SQLSTDOut = FlushHelper.flush(invalid_entities, 'invalid', persist_config)
    if result.code != 200:
      self._logger.warning(f'flush invalid entities to db failed: {result.message}')

    self._request['entities'] = valid_entities
    return True

  def _get_config(self) -> dict:
    return self._request.get('rule', {}).get(self._RULE_KEY, {})

  @abstractmethod
  def _process(self, entities: list, config: dict) -> tuple[list, list]:
    """处理数据，返回 (valid_entities, invalid_entities)"""
    ...
