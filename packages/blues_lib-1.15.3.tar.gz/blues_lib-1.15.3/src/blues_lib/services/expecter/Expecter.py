import re
from blues_lib.services.sql.DBQuerier import DBQuerier
from blues_lib.types import ToolExpect
from blues_lib.types import SQLCondition

class Expecter:

  @classmethod
  def to_be(cls, expect: ToolExpect) -> bool:
    return cls.to_equal(expect)

  @classmethod
  def not_to_be(cls, expect: ToolExpect) -> bool:
    return cls.not_to_equal(expect)

  @classmethod
  def to_equal(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = expect.get("value")
    return result == value

  @classmethod
  def not_to_equal(cls, expect: ToolExpect) -> bool:
    return not cls.to_equal(expect)

  @classmethod
  def to_be_null(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    return result is None

  @classmethod
  def not_to_be_null(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_null(expect)

  @classmethod
  def to_be_truthy(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    return bool(result) is True

  @classmethod
  def not_to_be_truthy(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_truthy(expect)

  @classmethod
  def to_be_falsy(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    return bool(result) is False

  @classmethod
  def not_to_be_falsy(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_falsy(expect)

  @classmethod
  def to_be_greater_than(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = expect.get("value")
    return float(result) > float(value)

  @classmethod
  def not_to_be_greater_than(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_greater_than(expect)

  @classmethod
  def to_be_less_than(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = expect.get("value")
    return float(result) < float(value)

  @classmethod
  def not_to_be_less_than(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_less_than(expect)

  @classmethod
  def to_be_greater_than_or_equal(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = expect.get("value")
    return float(result) >= float(value)

  @classmethod
  def not_to_be_greater_than_or_equal(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_greater_than_or_equal(expect)

  @classmethod
  def to_be_less_than_or_equal(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = expect.get("value")
    return float(result) <= float(value)

  @classmethod
  def not_to_be_less_than_or_equal(cls, expect: ToolExpect) -> bool:
    return not cls.to_be_less_than_or_equal(expect)

  @classmethod
  def to_contain(cls, expect: ToolExpect) -> bool:
    result = str(expect.get("result") or "")
    value = str(expect.get("value") or "")
    return value in result

  @classmethod
  def not_to_contain(cls, expect: ToolExpect) -> bool:
    return not cls.to_contain(expect)

  @classmethod
  def to_search(cls, expect: ToolExpect) -> bool:
    """使用 re.search 搜索匹配（在整个字符串中查找）"""
    result = str(expect.get("result") or "")
    value = str(expect.get("value") or "")
    try:
      return bool(re.search(value, result))
    except re.error:
      return False

  @classmethod
  def not_to_search(cls, expect: ToolExpect) -> bool:
    return not cls.to_search(expect)

  @classmethod
  def to_match(cls, expect: ToolExpect) -> bool:
    """使用 re.match 匹配（仅匹配字符串开头，等同于正则的 ^）"""
    result = str(expect.get("result") or "")
    value = str(expect.get("value") or "")
    try:
      return bool(re.match(value, result))
    except re.error:
      return False

  @classmethod
  def not_to_match(cls, expect: ToolExpect) -> bool:
    return not cls.to_match(expect)

  @classmethod
  def to_have_length(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = int(expect.get("value"))
    return len(result) == value

  @classmethod
  def not_to_have_length(cls, expect: ToolExpect) -> bool:
    return not cls.to_have_length(expect)

  @classmethod
  def to_have_length_greater_than(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = int(expect.get("value"))
    return len(result) > value

  @classmethod
  def not_to_have_length_greater_than(cls, expect: ToolExpect) -> bool:
    return not cls.to_have_length_greater_than(expect)

  @classmethod
  def to_have_property(cls, expect: ToolExpect) -> bool:
    result = expect.get("result")
    value = expect.get("value")
    return value in result

  @classmethod
  def not_to_have_property(cls, expect: ToolExpect) -> bool:
    return not cls.to_have_property(expect)

  @classmethod
  def to_have_url(cls, expect:ToolExpect)->bool:
    querier = DBQuerier('ap_mat')
    value:str = expect.get('value') or ''
    return querier.has('url',value)

  @classmethod
  def not_to_have_url(cls, expect:ToolExpect)->bool:
    return not cls.to_have_url(expect)

  @classmethod
  def to_search_entity(cls, expect:ToolExpect)->bool:
    querier = DBQuerier('ap_mat')
    condition:SQLCondition = expect.get('value') or {}
    return querier.search(condition)

  @classmethod
  def not_to_search_entity(cls, expect:ToolExpect)->bool:
    return not cls.to_search_entity(expect)
