class SkipLoopError(Exception):
  def __init__(self, message="Skip the loop"):
    super().__init__(message)
