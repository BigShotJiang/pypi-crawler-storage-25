class SkipSeqError(Exception):
  def __init__(self, message="Skip the sequence"):
    super().__init__(message)
