class BlockSeqError(Exception):
  def __init__(self, message="Block seq error"):
    super().__init__(message)
