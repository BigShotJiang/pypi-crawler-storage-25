from blues_lib.utils.email.EmailSender import EmailSender
from blues_lib.supports.logger.FileLogger import FileLogger

class MailLogger(FileLogger):

  def info(self,message:str,payload:dict):
    '''
    @description write log
    @param {MailPayload}
    '''
    super().info(message)
    EmailSender.send(payload)

  def warning(self,message:str,payload:dict):
    '''
    @description write log
    @param {MailPayload}
    '''
    super().warning(message)
    EmailSender.send(payload)
  
  def error(self,message:str,payload:dict):
    '''
    @description write log
    @param {MailPayload}
    '''
    super().error(message)
    EmailSender.send(payload)

  def debug(self,message:str,payload:dict):
    super().debug(message)
    EmailSender.send(payload)
    