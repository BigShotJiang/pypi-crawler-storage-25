"""
amazon_sagemaker_jupyter_scheduler setup
"""
import os
import json
from pathlib import Path

import setuptools

HERE = Path(__file__).parent.resolve()

# The name of the project
name = "amazon_sagemaker_jupyter_scheduler"

lab_path = (HERE / name / "labextension")
labext_name = "@amzn/sagemaker-jupyter-scheduler"

long_description = (HERE / "README.md").read_text()

# Get the package info from package.json
pkg_json = json.loads((HERE / "package.json").read_bytes())

SETUP_PY_DIR = os.path.dirname(os.path.realpath(__file__))

with open(os.path.join(SETUP_PY_DIR, "requirements.txt")) as fid:
    install_requires = fid.readlines()


def _get_data_files():
    """Expand data_files_spec into setuptools data_files format."""
    data_files_spec = [
        ("share/jupyter/labextensions/%s" % labext_name, str(lab_path), "**"),
        (
            "etc/jupyter/jupyter_server_config.d",
            "jupyter-config/jupyter_server_config.d",
            "amazon_sagemaker_jupyter_scheduler.json",
        ),
        (
            "etc/jupyter/",
            "jupyter-config",
            "jupyter_server_config.py",
        ),
    ]
    data_files = []
    for (install_path, source_dir, pattern) in data_files_spec:
        source_dir = str(source_dir)
        # Walk the source directory and collect matching files
        for root, dirs, files in os.walk(source_dir):
            # Skip node_modules
            if 'node_modules' in dirs:
                dirs.remove('node_modules')
            matched = []
            for f in files:
                full = os.path.join(root, f)
                # Simple glob matching: ** matches everything,
                # otherwise match the filename
                if pattern == "**" or Path(full).match(pattern):
                    matched.append(os.path.relpath(full))
            if matched:
                rel_root = os.path.relpath(root, source_dir)
                if rel_root == '.':
                    dest = install_path
                else:
                    dest = os.path.join(install_path, rel_root)
                data_files.append((dest, matched))
    return data_files


setup_args = dict(
    name=name,
    version=pkg_json["version"],
    url=pkg_json["homepage"],
    author=pkg_json["author"],
    description=pkg_json["description"],
    license=pkg_json["license"],
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    install_requires=install_requires,
    zip_safe=False,
    include_package_data=True,
    data_files=_get_data_files(),
    python_requires=">=3.7",
    platforms="Linux, Mac OS X, Windows",
    keywords=["Jupyter", "JupyterLab", "JupyterLab3",
              "Scheduling Notebooks", "Notebooks", "Amazon Sagemaker"],
    classifiers=[
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Framework :: Jupyter",
    ],
    extras_require={
        "dev": [
            "asynctest",
            "black",
            "pytest",
            "pytest-asyncio",
            "pytest-cov",
        ]
    },
    license_files=['LICENSE', 'NOTICE']
)


if __name__ == "__main__":
    setuptools.setup(**setup_args)
