<a href="https://www.buymeacoffee.com/khalel" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

# Sewar

[![Downloads](https://static.pepy.tech/badge/sewar)](https://pepy.tech/project/sewar)
[![Build Status](https://github.com/andrewekhalel/sewar/actions/workflows/workflow.yaml/badge.svg
)](https://github.com/andrewekhalel/sewar/actions/workflows/workflow.yaml)
[![codecov](https://codecov.io/gh/andrewekhalel/sewar/graph/badge.svg?token=D4SH5yVpYZ)](https://codecov.io/gh/andrewekhalel/sewar)
[![PyPI version](https://badge.fury.io/py/sewar.svg)](https://badge.fury.io/py/sewar)

Sewar is a python package for image quality assessment using different metrics. You can check documentation [here](http://sewar.readthedocs.io/).


## Implemented metrics
- [x] Mean Squared Error (MSE) 
- [x] Root Mean Squared Error (RMSE)
- [x] Peak Signal-to-Noise Ratio (PSNR) [[1]](https://ieeexplore.ieee.org/abstract/document/1284395/)
- [x] Structural Similarity Index (SSIM) [[1]](https://ieeexplore.ieee.org/abstract/document/1284395/)
- [x] Universal Quality Image Index (UQI) [[2]](https://ieeexplore.ieee.org/document/995823/)
- [x] Multi-scale Structural Similarity Index (MS-SSIM) [[3]](https://ieeexplore.ieee.org/abstract/document/1292216/)
- [x] Erreur Relative Globale Adimensionnelle de Synthèse (ERGAS) [[4]](https://hal.archives-ouvertes.fr/hal-00395027/)
- [x] Spatial Correlation Coefficient (SCC) [[5]](https://www.tandfonline.com/doi/abs/10.1080/014311698215973)
- [x] Relative Average Spectral Error (RASE) [[6]](https://ieeexplore.ieee.org/document/1304896/)
- [x] Spectral Angle Mapper (SAM) [[7]](https://ntrs.nasa.gov/search.jsp?R=19940012238)
- [x] Spectral Distortion Index (D_lambda) [[8]](https://www.ingentaconnect.com/content/asprs/pers/2008/00000074/00000002/art00003)
- [x] Spatial Distortion Index (D_S) [[8]](https://www.ingentaconnect.com/content/asprs/pers/2008/00000074/00000002/art00003)
- [x] Quality with No Reference (QNR) [[8]](https://www.ingentaconnect.com/content/asprs/pers/2008/00000074/00000002/art00003)
- [x] Visual Information Fidelity (VIF) [[9]](https://ieeexplore.ieee.org/abstract/document/1576816/)
- [x] Block Sensitive - Peak Signal-to-Noise Ratio (PSNR-B) [[10]](https://ieeexplore.ieee.org/abstract/document/5535179/)
- [x] Hypercomplex Image Quality Index (Q2n) [[11]](https://ieeexplore.ieee.org/document/5204070/)

## Todo
- [ ] Add command-line support for No-reference metrics

## Installation
Just as simple as
```
pip install sewar
```

## Running tests
```
pip install pytest pytest-cov
pytest --cov=sewar
```
## Example usage
A simple example to use UQI. All metric functions expect **numpy arrays** in `H x W x C` format (height x width x channels):
```python
>>> import numpy as np
>>> from PIL import Image
>>> from sewar.full_ref import uqi
>>> img1 = np.asarray(Image.open("image1.tif"))
>>> img2 = np.asarray(Image.open("image2.tif"))
>>> uqi(img1, img2)
0.8847521481522062
```

## Example usage for command line interface
```
sewar [metric] [GT path] [P path] (any extra parameters)
```
An example to use SSIM
```shell
foo@bar:~$ sewar ssim images/ground_truth.tif images/deformed.tif -ws 13
ssim : 0.8947009811410856
```
Available metrics list
```
mse, rmse, psnr, rmse_sw, uqi, ssim, ergas, scc, rase, sam, msssim, vifp, psnrb, q2n
```

## Contributors
Special thanks to @sachinpuranik99 and @sunwj.

## References
[1] "Image quality assessment: from error visibility to structural similarity." 2004)<br/>
[2] "A universal image quality index." (2002)<br/>
[3] "Multiscale structural similarity for image quality assessment." (2003)<br/>
[4] "Quality of high resolution synthesised images: Is there a simple criterion?." (2000)<br/>
[5] "A wavelet transform method to merge Landsat TM and SPOT panchromatic data." (1998)<br/>
[6] "Fusion of multispectral and panchromatic images using improved IHS and PCA mergers based on wavelet decomposition." (2004)<br/>
[7] "Discrimination among semi-arid landscape endmembers using the spectral angle mapper (SAM) algorithm." (1992)<br/>
[8] "Multispectral and panchromatic data fusion assessment without reference." (2008)<br/>
[9] "Image information and visual quality." (2006)<br/>
[10] "Quality Assessment of Deblocked Images" (2011)<br/>
[11] "Hypercomplex quality assessment of multi/hyperspectral images." (2009)<br/>
