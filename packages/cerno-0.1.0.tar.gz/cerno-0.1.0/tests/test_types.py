"""Tests for Cerno SDK Pydantic response models."""

from cerno.types import (
    AuditExportResult,
    SarDraft,
    SarListItem,
    TransactionAnalysis,
    VerifyResponse,
)


def test_verify_response_parses():
    data = {
        "decision": "dismiss",
        "confidence": 0.85,
        "risk_score": 15,
        "reasoning": ["Low risk profile"],
        "evidence": {"jurisdiction": "CA"},
        "session_id": "abc-123",
    }
    result = VerifyResponse.model_validate(data)
    assert result.decision == "dismiss"
    assert result.risk_score == 15
    assert result.session_id == "abc-123"


def test_sar_draft_parses():
    data = {
        "request": {"id": "req-1", "session_id": "s-1"},
        "draft": {"narrative": "test"},
        "session": {"id": "s-1"},
        "checks": [],
        "transactions": [],
        "submission": None,
    }
    result = SarDraft.model_validate(data)
    assert result.request["id"] == "req-1"
    assert result.draft is not None


def test_sar_list_item_parses():
    data = {
        "id": "req-1",
        "session_id": "s-1",
        "status": "draft",
        "created_at": "2026-04-10T00:00:00Z",
        "customer_name": "Jane Doe",
        "reference_id": "ref-001",
        "risk_score": 72,
    }
    result = SarListItem.model_validate(data)
    assert result.customer_name == "Jane Doe"


def test_transaction_analysis_parses():
    data = {
        "decision": "approve",
        "risk_score": 20,
        "reasoning": ["Normal activity"],
        "should_file_sar": False,
        "estimated_sar_filing_deadline": None,
        "analysis_id": "a-1",
    }
    result = TransactionAnalysis.model_validate(data)
    assert result.decision == "approve"
    assert not result.should_file_sar


def test_transaction_analysis_with_deadline():
    data = {
        "decision": "escalate",
        "risk_score": 85,
        "reasoning": ["Suspicious pattern"],
        "should_file_sar": True,
        "estimated_sar_filing_deadline": "2026-05-10",
        "analysis_id": "a-2",
    }
    result = TransactionAnalysis.model_validate(data)
    assert result.estimated_sar_filing_deadline is not None


def test_audit_export_result_parses():
    data = {
        "download_url": "https://s3.example.com/export.zip",
        "filename": "export.zip",
        "export_id": "exp-1",
    }
    result = AuditExportResult.model_validate(data)
    assert result.download_url is not None


def test_audit_export_result_empty():
    result = AuditExportResult()
    assert result.download_url is None
