"""Tests for the Cerno SDK client (mock httpx responses)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from cerno import CernoClient
from cerno.exceptions import (
    AuthenticationError,
    RateLimitError,
    ServerError,
    ValidationError,
)


def _mock_response(
    status_code: int = 200,
    json_data: dict | list | None = None,
    headers: dict[str, str] | None = None,
) -> httpx.Response:
    """Build a mock httpx.Response."""
    resp = httpx.Response(
        status_code=status_code,
        json=json_data,
        headers=headers or {},
        request=httpx.Request("POST", "https://api.cerno.ai/test"),
    )
    return resp


class TestVerify:
    def test_verify_success(self):
        response_data = {
            "decision": "dismiss",
            "confidence": 0.85,
            "risk_score": 15,
            "reasoning": ["Low risk"],
            "evidence": {},
            "session_id": "s-1",
        }
        with patch.object(
            httpx.Client, "request", return_value=_mock_response(json_data=response_data)
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            result = client.verify({"reference_id": "test"})
            assert result.decision == "dismiss"
            assert result.session_id == "s-1"

    def test_verify_401_raises_auth_error(self):
        with patch.object(
            httpx.Client,
            "request",
            return_value=_mock_response(
                status_code=401, json_data={"detail": "Invalid API key"}
            ),
        ):
            client = CernoClient(api_key="sk_live_bad_key_00000000")
            with pytest.raises(AuthenticationError):
                client.verify({"reference_id": "test"})

    def test_verify_422_raises_validation_error(self):
        with patch.object(
            httpx.Client,
            "request",
            return_value=_mock_response(
                status_code=422, json_data={"detail": "Missing field"}
            ),
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            with pytest.raises(ValidationError):
                client.verify({})

    def test_verify_429_raises_rate_limit(self):
        with patch.object(
            httpx.Client,
            "request",
            return_value=_mock_response(
                status_code=429,
                json_data={"detail": "Limit exceeded"},
                headers={"Retry-After": "3600"},
            ),
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            with pytest.raises(RateLimitError) as exc_info:
                client.verify({"reference_id": "test"})
            assert exc_info.value.retry_after == 3600

    def test_verify_500_raises_server_error(self):
        with patch.object(
            httpx.Client,
            "request",
            return_value=_mock_response(
                status_code=500, json_data={"detail": "Internal error"}
            ),
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            with pytest.raises(ServerError):
                client.verify({"reference_id": "test"})


class TestSar:
    def test_create_sar_draft(self):
        response_data = {
            "request": {"id": "r-1", "session_id": "s-1"},
            "draft": {"narrative": "SAR narrative"},
            "session": {"id": "s-1"},
            "checks": [],
            "transactions": [],
            "submission": None,
        }
        with patch.object(
            httpx.Client, "request", return_value=_mock_response(json_data=response_data)
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            result = client.create_sar_draft("s-1", ["tx-1", "tx-2"])
            assert result.request["id"] == "r-1"

    def test_list_sars(self):
        response_data = [
            {
                "id": "r-1",
                "session_id": "s-1",
                "status": "draft",
                "created_at": "2026-04-10T00:00:00Z",
                "customer_name": "Jane Doe",
                "reference_id": "ref-1",
            }
        ]
        with patch.object(
            httpx.Client, "request", return_value=_mock_response(json_data=response_data)
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            result = client.list_sars()
            assert len(result) == 1
            assert result[0].customer_name == "Jane Doe"


class TestTransactions:
    def test_analyze_transaction(self):
        response_data = {
            "decision": "approve",
            "risk_score": 20,
            "reasoning": ["Normal"],
            "should_file_sar": False,
            "estimated_sar_filing_deadline": None,
            "analysis_id": "a-1",
        }
        with patch.object(
            httpx.Client, "request", return_value=_mock_response(json_data=response_data)
        ):
            client = CernoClient(api_key="sk_live_test1234567890ab")
            result = client.analyze_transaction(
                transaction_id="tx-1",
                customer_session_id="s-1",
                amount=1500.00,
                currency="CAD",
                destination="CA",
            )
            assert result.decision == "approve"
            assert result.analysis_id == "a-1"


class TestContextManager:
    def test_client_as_context_manager(self):
        with patch.object(httpx.Client, "close"):
            with CernoClient(api_key="sk_live_test1234567890ab") as client:
                assert client is not None
