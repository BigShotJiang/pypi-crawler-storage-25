# Cerno Python SDK

Python client for the Cerno compliance API.

```python
from cerno import CernoClient

client = CernoClient(api_key="sk_live_...")
result = client.verify({"reference_id": "test", ...})
```
