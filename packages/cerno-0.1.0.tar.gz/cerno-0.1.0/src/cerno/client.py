"""Cerno Python SDK — sync client for the Cerno compliance API."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from cerno._http import HttpClient
from cerno.types import (
    AuditExportResult,
    SarDraft,
    SarListItem,
    TransactionAnalysis,
    VerifyResponse,
)

DEFAULT_BASE_URL = "https://api.cerno.ai"


class CernoClient:
    """Sync client for the Cerno compliance API.

    Usage::

        from cerno import CernoClient

        client = CernoClient(api_key="sk_live_...")
        result = client.verify(...)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._http = HttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> CernoClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Verify
    # ------------------------------------------------------------------

    def verify(self, payload: dict[str, Any]) -> VerifyResponse:
        """Run multi-jurisdiction identity verification.

        Args:
            payload: Full verify request body (see API docs).

        Returns:
            Structured verification result with decision, risk score,
            reasoning trace, and evidence.
        """
        data = self._http.request("POST", "/api/v1/verify", json=payload)
        return VerifyResponse.model_validate(data)

    # ------------------------------------------------------------------
    # SAR
    # ------------------------------------------------------------------

    def create_sar_draft(
        self,
        session_id: str,
        transaction_ids: list[str] | None = None,
    ) -> SarDraft:
        """Generate a SAR draft from a session and optional transactions."""
        body: dict[str, Any] = {"session_id": session_id}
        if transaction_ids is not None:
            body["transaction_ids"] = transaction_ids
        data = self._http.request("POST", "/api/v1/sar/draft", json=body)
        return SarDraft.model_validate(data)

    def list_sars(self) -> list[SarListItem]:
        """List SAR requests for the organization."""
        data = self._http.request("GET", "/api/v1/sar/list")
        return [SarListItem.model_validate(item) for item in data]

    def get_sar(self, request_id: str) -> SarDraft:
        """Get details for a specific SAR request."""
        data = self._http.request("GET", f"/api/v1/sar/{request_id}")
        return SarDraft.model_validate(data)

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    def analyze_transaction(
        self,
        *,
        transaction_id: str,
        customer_session_id: str,
        amount: float,
        currency: str,
        destination: str,
        transaction_type: str = "wire",
        timestamp: datetime | str | None = None,
    ) -> TransactionAnalysis:
        """Analyze a transaction for risk scoring and decisioning."""
        ts = timestamp
        if ts is None:
            ts = datetime.utcnow().isoformat()
        elif isinstance(ts, datetime):
            ts = ts.isoformat()

        body = {
            "transaction_id": transaction_id,
            "customer_session_id": customer_session_id,
            "amount": amount,
            "currency": currency,
            "destination": destination,
            "transaction_type": transaction_type,
            "timestamp": ts,
        }
        data = self._http.request(
            "POST", "/api/v1/transactions/analyze", json=body
        )
        return TransactionAnalysis.model_validate(data)

    # ------------------------------------------------------------------
    # Audit
    # ------------------------------------------------------------------

    def audit_export(
        self,
        start_date: date | str,
        end_date: date | str,
        *,
        delivery: str = "auto",
        include_pii: bool = True,
        include_pdf: bool = True,
        include_csv: bool = True,
        include_json: bool = True,
    ) -> AuditExportResult:
        """Generate an audit export package."""
        body = {
            "start_date": str(start_date),
            "end_date": str(end_date),
            "delivery": delivery,
            "include_pii": include_pii,
            "include_pdf": include_pdf,
            "include_csv": include_csv,
            "include_json": include_json,
        }
        data = self._http.request("POST", "/api/v1/audit/export", json=body)
        if isinstance(data, dict):
            return AuditExportResult.model_validate(data)
        return AuditExportResult()
