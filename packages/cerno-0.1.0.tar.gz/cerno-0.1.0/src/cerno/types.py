"""Pydantic response models for the Cerno SDK (standalone, no server imports)."""

from __future__ import annotations

from datetime import date

from pydantic import BaseModel


class VerifyResponse(BaseModel):
    decision: str
    confidence: float
    risk_score: int
    reasoning: list[str]
    evidence: dict
    session_id: str


class SarDraft(BaseModel):
    request: dict
    draft: dict | None = None
    session: dict
    checks: list[dict]
    transactions: list[dict]
    submission: dict | None = None


class SarListItem(BaseModel):
    id: str
    session_id: str
    status: str
    created_at: str
    customer_name: str
    reference_id: str
    risk_score: int | None = None
    risk_level: str | None = None
    template_used: str | None = None
    confidence: float | None = None
    narrative_excerpt: str = ""


class TransactionAnalysis(BaseModel):
    decision: str
    risk_score: int
    reasoning: list[str]
    should_file_sar: bool
    estimated_sar_filing_deadline: date | None = None
    analysis_id: str


class AuditExportResult(BaseModel):
    download_url: str | None = None
    filename: str | None = None
    export_id: str | None = None
