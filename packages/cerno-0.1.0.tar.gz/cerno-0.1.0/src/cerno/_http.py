"""Low-level httpx wrapper with error mapping."""

from __future__ import annotations

from typing import Any

import httpx

from cerno.exceptions import (
    AuthenticationError,
    CernoError,
    RateLimitError,
    ServerError,
    ValidationError,
)


def _raise_for_status(response: httpx.Response) -> None:
    """Map HTTP status codes to Cerno SDK exceptions."""
    if response.is_success:
        return

    status = response.status_code
    try:
        detail = response.json().get("detail", response.text)
    except Exception:
        detail = response.text

    if status == 401:
        raise AuthenticationError(str(detail), status_code=401)
    if status == 422:
        raise ValidationError(str(detail), status_code=422)
    if status == 429:
        retry_after = int(response.headers.get("Retry-After", "86400"))
        raise RateLimitError(str(detail), retry_after=retry_after)
    if status >= 500:
        raise ServerError(str(detail), status_code=status)

    raise CernoError(str(detail), status_code=status)


class HttpClient:
    """Thin wrapper around httpx.Client with auth and error mapping."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        timeout: float,
    ) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        response = self._client.request(
            method,
            path,
            json=json,
            params=params,
        )
        _raise_for_status(response)
        if response.headers.get("content-type", "").startswith("application/json"):
            return response.json()
        return response.content

    def close(self) -> None:
        self._client.close()
