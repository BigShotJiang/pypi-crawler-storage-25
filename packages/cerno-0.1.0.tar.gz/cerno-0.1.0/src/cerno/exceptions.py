"""Cerno SDK exceptions."""


class CernoError(Exception):
    """Base exception for all Cerno SDK errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(CernoError):
    """Raised when the API key is invalid or missing."""


class RateLimitError(CernoError):
    """Raised when the daily usage limit is exceeded."""

    def __init__(
        self,
        message: str = "Daily API usage limit exceeded",
        retry_after: int = 86400,
    ) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class ValidationError(CernoError):
    """Raised when the request payload fails server-side validation."""


class ServerError(CernoError):
    """Raised on 5xx responses from the Cerno API."""
