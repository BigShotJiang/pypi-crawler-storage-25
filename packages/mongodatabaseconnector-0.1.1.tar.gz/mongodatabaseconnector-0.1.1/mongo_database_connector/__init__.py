"""MongoDB Connector library with singleton client and multi-database support."""

from .connector import MongoDBConnector, get_client, get_connector, get_database

__all__ = [
    'MongoDBConnector',
    'get_connector',
    'get_client',
    'get_database',
]
