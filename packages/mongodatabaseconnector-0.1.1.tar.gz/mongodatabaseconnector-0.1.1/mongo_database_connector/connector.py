import os
import threading
import time
from typing import Dict, Optional, Tuple

import pytz # type: ignore
from bson.codec_options import CodecOptions
from pymongo import MongoClient
from pymongo.database import Database

_ENV_URI = "MONGO_DB_URI"
_ENV_DB_NAME = "MONGO_DB_NAME"
_ENV_TIMEZONE = "MONGO_DB_TZ"
_ENV_DEBUG = "MONGO_DB_DEBUG"
_ENV_DEBUG_URI = "MONGO_DB_DEBUG_URI"


def _env_bool(name, default=False):
    return os.getenv(name, 'true' if default else 'false').strip().lower() in ('1', 'true', 'yes')


def _normalize_timezone(timezone_name: Optional[str]) -> str:
    if timezone_name and timezone_name in pytz.all_timezones:
        return timezone_name
    return 'Asia/Kolkata'


class MongoDBConnector:
    """Singleton MongoDB connector that supports multiple databases and URIs."""

    _instance = None
    _global_lock = threading.Lock()
    _debug = _env_bool(_ENV_DEBUG, False)
    _print_db_uri = _env_bool(_ENV_DEBUG_URI, False)

    def __init__(self, default_uri=None, default_db=None, default_tz=None):
        self._default_uri = default_uri or os.getenv(_ENV_URI, 'mongodb://localhost:27017')
        self._default_db = default_db or os.getenv(_ENV_DB_NAME, 'test')
        self._default_tz = _normalize_timezone(default_tz or os.getenv(_ENV_TIMEZONE, 'Asia/Kolkata'))
        self._clients: Dict[str, MongoClient] = {}
        self._databases: Dict[Tuple[str, str], Database] = {}

        if self._print_db_uri:
            print('MongoDBConnector default URI:', self._default_uri)
            print('MongoDBConnector default database:', self._default_db)

    @classmethod
    def get_instance(cls, default_uri=None, default_db=None, default_tz=None):
        if cls._instance is None:
            with cls._global_lock:
                if cls._instance is None:
                    if cls._debug:
                        print('Creating MongoDBConnector singleton instance...')
                    cls._instance = cls(default_uri=default_uri, default_db=default_db, default_tz=default_tz)
        return cls._instance

    def _create_codec_options(self, timezone_name: str) -> CodecOptions:
        timezone_name = _normalize_timezone(timezone_name)
        return CodecOptions(tz_aware=True, tzinfo=pytz.timezone(timezone_name))

    def _get_client(self, uri: str) -> MongoClient:
        if uri not in self._clients:
            if self._debug:
                print('Opening MongoClient for URI:', uri)
            self._clients[uri] = MongoClient(uri)
        return self._clients[uri]

    def get_database(self, db_name=None, uri=None, tz=None):
        uri = uri or self._default_uri
        db_name = db_name or self._default_db
        timezone_name = _normalize_timezone(tz or self._default_tz)

        client = self._get_client(uri)
        key = (uri, db_name)

        if key not in self._databases:
            if self._debug:
                print('Caching database:', db_name, 'for URI:', uri)
            self._databases[key] = client[db_name]

        codec_options = self._create_codec_options(timezone_name)
        return self._databases[key].with_options(codec_options=codec_options)

    def get_client(self, uri=None):
        uri = uri or self._default_uri
        return self._get_client(uri)

    def list_cached_databases(self):
        return list(self._databases.keys())


def get_connector(default_uri=None, default_db=None, default_tz=None) -> MongoDBConnector:
    return MongoDBConnector.get_instance(default_uri=default_uri, default_db=default_db, default_tz=default_tz)


def get_database(uri=None, db_name=None, tz=None):
    return get_connector().get_database(db_name=db_name, uri=uri, tz=tz)


def get_client(uri=None):
    return get_connector().get_client(uri=uri)
