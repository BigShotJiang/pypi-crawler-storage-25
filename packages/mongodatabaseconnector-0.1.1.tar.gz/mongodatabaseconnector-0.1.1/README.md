# MongoDBConnector

A singleton MongoDB connector library with support for multiple databases and multiple connection URIs.

## Installation

```bash
pip install pymongo pytz MongoDatabaseConnector
```

## Usage

```python
from mongo_database_connector import get_database

# Connect using environment defaults or fallback values.
default_db = get_database()

# Connect to a named database on the default URI.
users_db = get_database(db_name='users')

# Connect to a different URI and database.
analytics_db = get_database(uri='mongodb://localhost:27018', db_name='analytics')
```

## Environment Variables

- `MONGO_DB_URI` — default MongoDB URI (fallback: `mongodb://localhost:27017`)
- `MONGO_DB_NAME` — default database name (fallback: `test`)
- `MONGO_DB_TZ` — default timezone (fallback: `Asia/Kolkata`)
- `MONGO_DB_DEBUG` — enable debug logging
- `MONGO_DB_DEBUG_URI` — print default URI and database name during initialization


## pip install build twine
## python -m build
## twine --verbose upload dist/*
