from yta_constants.file import FileParsingMethod, AudioFileExtension, VideoFileExtension, ImageFileExtension, TextFileExtension, SubtitleFileExtension, FileExtension
from yta_programming.decorators.requires_dependency import requires_dependency
from typing import Any
from pathlib import Path

import io


def _parse_unparseable(
    file: 'FileResource'
):
    """
    *For internal use only*
    """
    raise Exception(
        'The content is unparseable.'
    )


def _parse_text(
    file: 'FileResource',
    encoding: str = 'utf-8'
) -> str:
    """
    *For internal use only*

    Parse the `file` provided as text.
    """
    if file.has_content:
        return (
            io.BytesIO(
                file.read_bytes()
            )
            .getvalue()
            .decode(encoding)
        )

    return Path(file.filename).read_text(
        encoding = encoding
    )


@requires_dependency('yta_temp', 'yta_general', 'yta_temp')
@requires_dependency('yta_file', 'yta_general', 'yta_file')
@requires_dependency('moviepy', 'yta_general', 'moviepy')
def _parse_moviepy_video(
    file: 'FileResource'
):
    """
    *For internal use only*

    Parse the `file` provided as a video from the
    `moviepy` library.

    This method needs the next dependencies:
    - `moviepy`
    - `yta_file`
    - `yta_temp`
    """
    from yta_temp import Temp
    from yta_file.handler import FileHandler
    from moviepy import VideoFileClip

    if file.has_content:
        temp_filename = (
            Temp.get_filename('video.mp4')
        )

        FileHandler.write_binary(
            temp_filename,
            file.read_bytes()
        )

        return VideoFileClip(
            temp_filename
        )

    return VideoFileClip(
        file.filename
    )


@requires_dependency('yta_temp', 'yta_general', 'yta_temp')
@requires_dependency('yta_file', 'yta_general', 'yta_file')
@requires_dependency('moviepy', 'yta_general', 'moviepy')
def _parse_moviepy_audio(
    file: 'FileResource'
):
    """
    *For internal use only*

    Parse the `file` provided as an audio from the
    `moviepy` library.

    This method needs the next dependencies:
    - `moviepy`
    - `yta_file`
    - `yta_temp`
    """
    from yta_temp import Temp
    from yta_file.handler import FileHandler
    from moviepy import AudioFileClip

    if file.has_content:
        temp_filename = (
            Temp.get_filename('audio.mp3')
        )

        FileHandler.write_binary(
            temp_filename,
            file.read_bytes()
        )

        return AudioFileClip(
            temp_filename
        )

    return AudioFileClip(
        file.filename
    )


@requires_dependency('PIL', 'yta_general', 'pillow')
def _parse_pillow_image(
    file: 'FileResource'
):
    """
    *For internal use only*

    Parse the `file` provided as an image from the
    `pillow` library.

    This method needs the next dependencies:
    - `pillow`
    """
    from PIL import Image

    if file.has_content:
        return Image.open(
            io.BytesIO(
                file.read_bytes()
            )
        )

    return Image.open(
        file.filename
    )


@requires_dependency('cv2', 'yta_general', 'opencv-python')
@requires_dependency('numpy', 'yta_general', 'numpy')
def _parse_opencv_image(
    file: 'FileResource'
):
    """
    *For internal use only*

    Parse the `file` provided as an image from the
    `opencv` library.

    This method needs the next dependencies:
    - `cv2`
    - `numpy`
    """
    import numpy as np
    import cv2

    if file.has_content:
        return cv2.imdecode(
            np.frombuffer(
                file.read_bytes(),
                np.uint8
            ),
            cv2.IMREAD_COLOR
        )

    return cv2.imread(
        file.filename
    )


@requires_dependency('pydub', 'yta_general', 'pydub')
def _parse_pydub_audio(
    file: 'FileResource'
):
    """
    *For internal use only*

    Parse the `file` provided as an audio from the
    `pydub` library.

    This method needs the next dependencies:
    - `pydub`
    """
    from pydub import AudioSegment

    if file.has_content:
        return AudioSegment.from_file(
            io.BytesIO(
                file.read_bytes()
            )
        )

    return AudioSegment.from_file(
        file.filename
    )


FILE_PARSERS = {
    FileParsingMethod.UNPARSEABLE: _parse_unparseable,
    FileParsingMethod.IO_TEXT: _parse_text,
    FileParsingMethod.IO_SUBTITLES: _parse_text,
    FileParsingMethod.MOVIEPY_VIDEO: _parse_moviepy_video,
    FileParsingMethod.MOVIEPY_AUDIO: _parse_moviepy_audio,
    FileParsingMethod.PILLOW_IMAGE: _parse_pillow_image,
    FileParsingMethod.OPENCV_IMAGE: _parse_opencv_image,
    FileParsingMethod.PYDUB_AUDIO: _parse_pydub_audio
}
"""
Dict to map the different file parsing methods
to their corresponding parsing functions.
"""

FILE_EXTENSION_CLASS_TO_FILE_PARSING_METHOD = {
    AudioFileExtension: FileParsingMethod.PYDUB_AUDIO,
    VideoFileExtension: FileParsingMethod.MOVIEPY_VIDEO,
    ImageFileExtension: FileParsingMethod.PILLOW_IMAGE,
    TextFileExtension: FileParsingMethod.IO_TEXT,
    SubtitleFileExtension: FileParsingMethod.IO_SUBTITLES,
    # We don't have it as a registered specific extension
    FileExtension: FileParsingMethod.UNPARSEABLE
}
"""
Dict to map the different file extension classes
to their corresponding file parsing methods.
"""


class FileParser:
    """
    Class to parse files according to their
    `parsing_method`.
    """

    @staticmethod
    def parse(
        file: 'FileResource',
        *,
        do_force: bool = False
    ) -> Any:
        """
        Parse the `file` provided if it is not already
        parsed.

        This method could need one of the next dependencies:
        - `pydub`
        - `moviepy`
        - `numpy`
        - `cv2`
        - `pil`
        - `yta_temp`
        - `yta_file`
        """
        if (
            file.is_parsed and
            not do_force
        ):
            return file.parsed_content

        parser = FILE_PARSERS.get(
            file.parsing_method
        )

        if parser is None:
            raise Exception(
                f'Unsupported parsing method: '
                f'{file.parsing_method}'
            )

        parsed = parser(file)

        file.parsed_content = parsed

        return parsed
    