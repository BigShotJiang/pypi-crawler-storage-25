from yta_general.file.parser import FILE_EXTENSION_CLASS_TO_FILE_PARSING_METHOD
from yta_constants.file import FileParsingMethod, FileExtension, get_extension
from dataclasses import dataclass, field
from typing import Union, Any
from pathlib import Path

import io


@dataclass(slots = True)
class FileResource_old:
    """
    *Dataclass*

    Neutral representation of a file that may exist:
    - in memory
    - on disk
    - downloaded remotely
    - parsed
    - unparsed

    The `file_extension` will be autodetected, if not
    set, from the `filename` or `output_filename`, if
    existing.

    The `parsing_method` will be autodetected, if not
    set, from the `file_extension`, if existing.
    """

    raw_content: Union[bytes, bytearray, io.BytesIO, None] = None
    """
    The raw content of the file.
    """
    filename: Union[str, None] = None
    """
    The name of the file.
    """
    output_filename: Union[str, None] = None
    """
    The destination filename.
    """
    # TODO: This should include the other types
    file_extension: Union[FileExtension, None] = None
    """
    The type of the file, useful to parse it, that
    could be a specific and single extension or the
    Enum class (that includes any extension of that
    type). Can be `None` if the file includes just
    content, no filename, and it was not defined.

    Examples:
    - `file_extension = VideoFileExtension`
    - `file_extension = VideoFileExtension.MOV`
    """
    parsing_method: Union[FileParsingMethod, None] = None
    """
    The parsing method expected to be used to parse
    the file.
    """
    parsed_content: Union[Any, None] = None
    """
    The content of the file once it's been parsed
    according to the `parsing_method` defined.
    """
    # TODO: What is this (?)
    extra_args: dict[str, Any] = field(default_factory = dict)
    """
    TODO: Explain it better
    """
    source_url: Union[str, None] = None
    """
    The url from which we obtained this file.
    """
    metadata: dict[str, Any] = field(default_factory = dict)
    """
    Metadata of the file.
    """

    @property
    def has_content(
        self
    ) -> bool:
        return self.raw_content is not None

    @property
    def has_filename(
        self
    ) -> bool:
        return self.filename is not None

    @property
    def is_parsed(
        self
    ) -> bool:
        return self.parsed_content is not None

    # @property
    # def path(
    #     self
    # ) -> Path | None:
    #     return (
    #         Path(self.filename)
    #         if self.filename else
    #         None
    #     )

    def __post_init__(
        self
    ):
        """
        Validate and autodetect information.
        """
        if not self.has_content and not self.has_filename:
            raise ValueError(
                'A file must contain either "raw_content" or "filename".'
            )

        # Autodetect file extension if missing
        if self.file_extension is None:
            detected_filename = (
                self.filename or
                self.output_filename
            )

            if detected_filename:
                self.file_extension = get_extension(str(Path(detected_filename).suffix))

                # Auto-detect parsing method (?)
                if not self.parsing_method:
                    self.parsing_method = FILE_EXTENSION_CLASS_TO_FILE_PARSING_METHOD.get(self.file_extension.__class__, None)

    def read_bytes(
        self
    ) -> bytes:
        """
        Obtain raw bytes regardless of source.
        """
        if self.raw_content is not None:
            if isinstance(self.raw_content, io.BytesIO):
                return self.raw_content.getvalue()
            return bytes(self.raw_content)

        if self.filename is not None:
            return Path(self.filename).read_bytes()

        raise ValueError(
            'No content or filename available.'
        )
    
    def parse(
        self,
        *,
        do_force: bool = False
    ) -> Any:
        """
        Parse the file content using the configured
        parsing method.
        """
        from yta_general.file.parser import FileParser

        if (
            self.is_parsed and
            not do_force
        ):
            return self.parsed_content

        return FileParser.parse(
            self,
            do_force = do_force
        )
    
    
    def write(
        self,
        filename: str
    ) -> str:
        """
        Persist file to disk.
        """
        destination = Path(filename)

        # This is in 'yta-file-downloader.utils'    
        destination.parent.mkdir(
            parents = True,
            exist_ok = True
        )

        if self.has_content:
            destination.write_bytes(
                self.read_bytes()
            )
        elif self.has_filename:
            destination.write_bytes(
                Path(self.filename).read_bytes()
            )
        else:
            raise ValueError(
                'Nothing to write.'
            )

        return str(destination).replace('\\\\', '\\').replace('\\', '/')

    def clear_parsed_cache(
        self
    ):
        """
        Remove parsed cached object.
        """
        self.parsed_content = None


# TODO: Remove this above when below is working
    
"""
Module to include the new way to handle the
`FileResource` that includes a better way to
handle the file format, extensions, etc.
"""
from yta_constants.file import FileParsingMethod
from pystandards.http.mime_type import HttpMimeType
from pystandards.file import FileExtension
from urllib.parse import unquote
from dataclasses import dataclass, field
from pathlib import Path
from typing import Union, Any

import mimetypes
import re


@dataclass(slots = True)
class FileFormat:
    """
    The format o file, including its MIME type and
    the extension (both values can be None) if this
    information is not available.
    """

    mime_type: Union[HttpMimeType, None] = None
    extension: Union[FileExtension, None] = None

    def __post_init__(
        self
    ):
        self.mime_type = HttpMimeType.to_enum(self.mime_type)
        self.extension = FileExtension.to_enum(self.extension)


@dataclass(slots = True)
class RemoteFileInfo:
    """
    Original information of the file obtained from
    the source.
    """

    filename: Union[str, None] = None
    format: Union[FileFormat, None] = None

    @property
    def stem(
        self
    ) -> Union[str, None]:
        """
        The filename including not the suffix (extension).
        """
        if not self.filename:
            return None

        return Path(self.filename).stem

    @property
    def extension(
        self
    ) -> Union[str, None]:
        """
        The extension of the file, if existing, in
        lowercase and without the dot.
        """
        if not self.filename:
            return None

        suffix = Path(self.filename).suffix

        if not suffix:
            return None

        return suffix.lower().lstrip('.')


@dataclass(slots = True)
class UserFileRequest:
    """
    The filename requested by the user.
    """

    output_filename: Union[str, None] = None

    @property
    def stem(
        self
    ) -> Union[str, None]:
        """
        The filename including not the suffix (extension).
        """
        if not self.output_filename:
            return None

        return Path(self.output_filename).stem

    @property
    def extension(
        self
    ) -> Union[str, None]:
        """
        The extension of the file, if existing, in
        lowercase and without the dot.
        """
        if not self.output_filename:
            return None

        suffix = Path(self.output_filename).suffix

        if not suffix:
            return None

        return suffix.lower().lstrip('.')


@dataclass(slots = True)
class ResolvedFileInfo:
    """
    The final result of the file after validating,
    extending or fixing the names.
    """

    filename: str
    is_corrected: bool = False

    @property
    def path(
        self
    ) -> Path:
        """
        The filename as a `Path` instance.
        """
        return Path(self.filename)

    @property
    def stem(
        self
    ) -> str:
        """
        The filename including not the suffix (extension).
        """
        return self.path.stem

    @property
    def extension(
        self
    ) -> Union[str, None]:
        """
        The extension of the file, if existing, in
        lowercase and without the dot.
        """
        suffix = self.path.suffix

        if not suffix:
            return None

        return suffix.lower().lstrip('.')


@dataclass(slots = True)
class FileResource:
    """
    *Dataclass*

    A dataclass to include information about a
    file that has been obtained from a source
    and asked to be named in a specific way.
    """

    raw_content: Union[bytes, bytearray, str, 'io.BytesIO', None] = None
    """
    The raw content of the file.
    """
    remote: RemoteFileInfo = field(default_factory = RemoteFileInfo)
    """
    A `RemoteFileInfo` instance including the
    information of the remote file.
    """
    request: UserFileRequest = field(default_factory = UserFileRequest)
    """
    A `UserFileRequest` instance including the
    parameters requested by the user.
    """
    source_format: Union[FileFormat, None] = None
    """
    The `FileFormat` instance that has the
    information about the format of the file on
    the source, including MIME type and extension.
    """
    final_format: Union[FileFormat, None] = None
    """
    The `FileFormat` instance that has the final
    MIEM type and extension of the file that is
    returned, that has been processed according
    to the remote source and the processing
    method, which is currently accepting the
    remote configuration.
    """
    resolved: Union[ResolvedFileInfo, None] = None
    """
    The file information once its been resolved
    by using the source and the parameters 
    requested by the user.
    """
    parsing_method: Union[FileParsingMethod, None] = None
    """
    The parsing method expected to be used to parse
    the file.
    """
    parsed_content: Union[Any, None] = None
    """
    The content of the file once it's been parsed
    according to the `parsing_method` defined.
    """
    parsing_extra_args: dict[str, Any] = field(default_factory = dict)
    """
    Extra arguments to use when parsing the content
    with the `parsing_method` provided.
    """
    source_url: Union[str, None] = None
    """
    The url from which we obtained this file if it
    was obtained from a remote url.
    """
    source_path: Union[str, None] = None
    """
    The path (as str) of the file if it was obtained
    directly from a local storage and not from a
    remote url.
    """


    @property
    def filename(
        self
    ) -> Union[str, None]:
        """
        The filename once its been resolved.
        """
        return (
            self.resolved.filename
            if self.resolved else
            None
        )


    @property
    def extension(
        self
    ) -> Union[str, None]:
        """
        The extension of the file, if existing, in
        lowercase and without the dot.
        """
        return (
            None
            if not self.resolved else
            self.resolved.extension
        )


    @property
    def mime_type(
        self
    ) -> Union[str, None]:
        """
        The final mime type.
        """
        return (
            None
            if not self.final_format else
            self.final_format.mime_type
        )


    @classmethod
    def create(
        cls,
        *,
        raw_content: Union[bytes, str, None] = None,
        remote_filename: Union[str, None] = None,
        requested_filename: Union[str, None] = None,
        source_mime_type: Union[str, None] = None,
        source_extension: Union[str, None] = None,
        final_mime_type: Union[str, None] = None,
        final_extension: Union[str, None] = None,
        default_filename: str = 'download',
        parsing_method: Union[FileParsingMethod, None] = None,
        parsing_extra_args: dict[str, Any] = {},
        source_url: Union[str, None] = None,
        source_path: Union[str, None] = None
    ) -> 'FileResource':
        """
        Creaete a `FileResource` instance by using the
        provided parameters.

        The `remote_filename` will be used if the
        `requested_filename` is not provided.

        The `source_mime_type` and `source_extension`
        will be used to set the correct type and
        extension as they come directly from the source.

        The `default_filename` will be used in case that
        there is no `remote_filename` nor any
        `requested_filename`.

        If `final_mime_type` and/or `final_extension`
        are provided, they will be used. 
        """
        source_format = FileFormat(
            mime_type = source_mime_type,
            extension = source_extension,
        )

        final_format = FileFormat(
            mime_type = (
                final_mime_type or
                source_mime_type
            ),
            extension = (
                final_extension or
                source_extension
            ),
        )

        resolved = cls._resolve_filename(
            remote_filename = remote_filename,
            requested_filename = requested_filename,
            final_extension = final_format.extension.value,
            default_filename = default_filename
        )

        return cls(
            raw_content = raw_content,
            remote = RemoteFileInfo(
                filename = remote_filename,
                format = source_format,
            ),
            request = UserFileRequest(
                output_filename = requested_filename,
            ),
            source_format = source_format,
            final_format = final_format,
            resolved = resolved,
            parsing_method = parsing_method,
            parsing_extra_args = parsing_extra_args,
            source_url = source_url,
            source_path = source_path
        )


    @staticmethod
    def _resolve_filename(
        *,
        remote_filename: Union[str, None],
        requested_filename: Union[str, None],
        final_extension: Union[str, None],
        default_filename: str,
    ) -> ResolvedFileInfo:
        """
        Get the `ResolvedFileInfo` according to
        the parameters provided, using the next
        order of priority:
        - 1. User requested
        - 2. Remote
        - 3. Default

        A `is_corrected` flag will be set as `True`
        if the extension of the filename requested
        by the user had to be replaced because it
        was not the correct one.
        """
        is_corrected = False

        base_path = (
            Path(requested_filename)
            if requested_filename else
            Path(remote_filename)
            if remote_filename else
            Path(default_filename)
        )

        stem = (
            base_path.stem or
            default_filename
        )

        current_extension = (
            base_path.suffix.lower().lstrip('.')
            if base_path.suffix
            else None
        )

        if final_extension:
            if current_extension != final_extension:
                is_corrected = current_extension is not None
            filename = f'{stem}.{final_extension}'
        else:
            filename = stem

        return ResolvedFileInfo(
            filename = filename,
            is_corrected = is_corrected,
        )
    

class FileResourceFactory:
    """
    Factory to be able to create `FileResource`
    instances.
    """

    @classmethod
    def from_httpx_response(
        cls,
        response: 'httpx.Response',
        *,
        output_filename: Union[str, None] = None,
        parsing_method: Union[FileParsingMethod, None] = None,
        parsing_extra_args: dict[str, Any] = {}
    ) -> FileResource:
        """
        Get a `FileResource` instance that is resolved
        based on the http `response` given and the
        `output_filename` provided.
        """
        remote_filename = cls._extract_remote_filename(
            response
        )

        source_format = _mime_type_to_file_format(response.headers.get('content-type'))
        
        # source_format = cls._detect_source_format_from_httpx_response(
        #     response
        # )

        return FileResource.create(
            raw_content = None,
            remote_filename = remote_filename,
            requested_filename = output_filename,
            source_mime_type = source_format.mime_type,
            source_extension = source_format.extension,
            final_mime_type = None,
            final_extension = None,
            default_filename = 'download',
            parsing_method = parsing_method,
            parsing_extra_args = parsing_extra_args,
            source_url = str(response.url),
            source_path = None
        )
    
    @classmethod
    def from_path(
        cls,
        path: Path,
        *,
        output_filename: Union[str, None] = None,
        parsing_method: Union[FileParsingMethod, None] = None,
        parsing_extra_args: dict[str, Any] = {}
    ) -> FileResource:
        """
        Get a `FileResource` instance resolved
        from a local file path.
        """
        source_format = _mime_type_to_file_format(mimetypes.guess_type(str(path))[0])

        # source_format = cls._detect_source_format_from_path(
        #     path = path
        # )

        return FileResource.create(
            raw_content = None,
            remote_filename = None,
            requested_filename = output_filename,
            source_mime_type = source_format.mime_type,
            source_extension = source_format.extension,
            final_mime_type = None,
            final_extension = None,
            default_filename = path.stem,
            parsing_method = parsing_method,
            parsing_extra_args = parsing_extra_args,
            source_url = None,
            source_path = path
        )


    @staticmethod
    def _extract_remote_filename(
        response: 'httpx.Response',
    ) -> Union[str, None]:
        """
        Get the `filename` of the remote file that
        is included in the httpx `response` provided.
        """
        content_disposition = response.headers.get(
            'content-disposition'
        )

        if content_disposition:
            match = re.search(
                r'filename="?([^"]+)"?',
                content_disposition,
            )

            if match:
                return match.group(1)

        # fallback: final URL

        path = Path(unquote(response.url.path))

        if path.name:
            # TODO: Maybe replace '\' (?)
            return path.name

        return None
    

    # @staticmethod
    # def _detect_source_format_from_httpx_response(
    #     response: 'httpx.Response'
    # ) -> FileFormat:
    #     """
    #     Get the `FileFormat` of the remote file that
    #     is included in the httpx `response` provided.
    #     """
    #     mime_type = response.headers.get('content-type')

    #     return _mime_type_to_file_format(mime_type)
    

    # @staticmethod
    # def _detect_source_format_from_path(
    #     path: Path
    # ) -> FileFormat:
    #     """
    #     Detect the source format from a local file path.
    #     """
    #     mime_type, _ = mimetypes.guess_type(
    #         str(path)
    #     )

    #     return _mime_type_to_file_format(mime_type)
    
def _mime_type_to_file_format(
    mime_type: Union[tuple, None]
) -> FileFormat:
    """
    *For internal use only*

    Transform the `mime_type` provided into
    a `FileFormat` instance.
    """
    file_extension = None

    if mime_type:
        """
        We will try to parse with our own method and
        use the 'mimetypes' library as fallback if
        needed.
        """
        try:
            file_extension = FileExtension.from_http_mime_type(mime_type)
        except:
            file_extension = FileExtension.to_enum(
                value = mimetypes.guess_extension(
                    mime_type.split(';')[0].strip()
                )
            )

        mime_type = HttpMimeType.to_enum(mime_type)

    return FileFormat(
        mime_type = mime_type,
        extension = file_extension,
    )