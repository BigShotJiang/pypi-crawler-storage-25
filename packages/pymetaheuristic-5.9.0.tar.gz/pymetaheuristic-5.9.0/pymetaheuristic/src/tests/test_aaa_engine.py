from __future__ import annotations

from pathlib import Path
import math
import sys

_ROOT = Path(__file__).resolve().parents[3]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pymetaheuristic  # noqa: E402


def sphere(x):
    return sum(v * v for v in x)


def test_aaa_is_discoverable_and_has_metadata():
    assert "aaa" in pymetaheuristic.list_algorithms()
    info = pymetaheuristic.get_algorithm_info("aaa")
    assert info["algorithm_id"] == "aaa"
    assert info["algorithm_name"] == "Artificial Algae Algorithm"
    assert info["doi"] == "10.1016/j.asoc.2015.03.003"
    assert info["capabilities"].has_population is True
    assert info["capabilities"].supports_candidate_injection is False


def test_aaa_runs_and_respects_bounds():
    result = pymetaheuristic.optimize(
        algorithm="aaa",
        target_function=sphere,
        min_values=[-5.0, -5.0, -5.0],
        max_values=[5.0, 5.0, 5.0],
        population_size=8,
        max_steps=5,
        seed=7,
        store_history=False,
    )
    assert math.isfinite(result.best_fitness)
    assert len(result.best_position) == 3
    assert all(-5.0 <= v <= 5.0 for v in result.best_position)


def test_aaa_seed_reproducibility():
    kwargs = dict(
        algorithm="aaa",
        target_function=sphere,
        min_values=[-5.0, -5.0],
        max_values=[5.0, 5.0],
        population_size=6,
        max_steps=4,
        seed=11,
        store_history=False,
    )
    first = pymetaheuristic.optimize(**kwargs)
    second = pymetaheuristic.optimize(**kwargs)
    assert first.best_fitness == second.best_fitness
    assert first.best_position == second.best_position
