"""Tests for the Knowledge-Base config keys: kb_artifacts, auto_summarize_on_end, kb_max_results."""

from __future__ import annotations

from meeting_helper.config import Config


def test_kb_artifacts_default_empty(tmp_path):
    cfg = Config(tmp_path / "config.json")
    assert cfg.kb_artifacts == []


def test_kb_artifacts_add_remove_idempotent(tmp_path):
    cfg = Config(tmp_path / "config.json")
    cfg.add_kb("2026-05-08_193029.summary.txt")
    cfg.add_kb("2026-05-08_193029.summary.txt")  # duplicate is no-op
    assert cfg.kb_artifacts == ["2026-05-08_193029.summary.txt"]
    assert cfg.is_kb("2026-05-08_193029.summary.txt") is True
    cfg.remove_kb("2026-05-08_193029.summary.txt")
    assert cfg.kb_artifacts == []
    assert cfg.is_kb("2026-05-08_193029.summary.txt") is False


def test_kb_artifacts_round_trip(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg = Config(cfg_path)
    cfg.add_kb("a.summary.txt")
    cfg.add_kb("b.note.md")
    reloaded = Config(cfg_path)
    assert sorted(reloaded.kb_artifacts) == ["a.summary.txt", "b.note.md"]


def test_auto_summarize_on_end_default_false(tmp_path):
    cfg = Config(tmp_path / "config.json")
    assert cfg.auto_summarize_on_end is False


def test_auto_summarize_on_end_round_trip(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg = Config(cfg_path)
    cfg.auto_summarize_on_end = True
    cfg.save()
    assert Config(cfg_path).auto_summarize_on_end is True


def test_kb_max_results_default_three(tmp_path):
    cfg = Config(tmp_path / "config.json")
    assert cfg.kb_max_results == 3


def test_kb_independent_from_favorites(tmp_path):
    cfg = Config(tmp_path / "config.json")
    cfg.add_favorite("a.summary.txt")
    assert cfg.is_kb("a.summary.txt") is False
    cfg.add_kb("a.summary.txt")
    assert cfg.is_favorite("a.summary.txt") is True
    assert cfg.is_kb("a.summary.txt") is True


def test_to_app_config_pipes_kb_fields(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg = Config(cfg_path)
    cfg.add_kb("note-one.note.md")
    cfg.add_kb("2026-05-01_120000.summary.txt")
    cfg.auto_summarize_on_end = True
    cfg.save()

    app_cfg = cfg.to_app_config()
    assert sorted(app_cfg.kb_artifacts) == [
        "2026-05-01_120000.summary.txt",
        "note-one.note.md",
    ]
    assert app_cfg.kb_max_results == 3
    assert app_cfg.auto_summarize_on_end is True
