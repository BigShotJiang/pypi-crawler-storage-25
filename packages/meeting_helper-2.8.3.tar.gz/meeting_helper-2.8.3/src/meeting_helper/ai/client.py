"""AI client: real-time queries (Claude or Ollama), post-meeting transcription & summarization."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.state import AppState

logger = logging.getLogger(__name__)


_SPRINT_REFRESH_INTERVAL_SEC = 5 * 60.0  # refresh sprint cache every 5 minutes


async def refresh_sprint_tickets(state: "AppState", force: bool = False) -> None:
    """Refresh `state.sprint_tickets` from local-todo's active sprint.

    No-op if local-todo isn't connected. Only re-fetches when the cache is
    older than ``_SPRINT_REFRESH_INTERVAL_SEC`` (or ``force=True``).
    """
    if state.local_todo is None:
        return
    if (
        not force
        and state.sprint_tickets
        and (time.time() - state.sprint_tickets_loaded_at) < _SPRINT_REFRESH_INTERVAL_SEC
    ):
        return
    try:
        tasks = await state.local_todo.my_active_tasks(limit=100)
    except Exception as exc:
        logger.warning("sprint cache refresh failed: %s", exc)
        return
    state.sprint_tickets = tasks or []
    state.sprint_tickets_loaded_at = time.time()
    logger.info("Sprint cache refreshed (%d tickets)", len(state.sprint_tickets))


async def _hydrate_ticket(state: "AppState", picked: dict) -> dict:
    """Fetch the full ticket record (body, comments, history) via local-todo
    `get_task`. The picker's input came from `search_tasks` which only
    returns id/title/status — too thin for the reply AI to ground on.

    Returns the hydrated dict (or the original `picked` on failure).
    """
    if state.local_todo is None:
        return picked
    ticket_id = picked.get("id")
    board_id = picked.get("board_id")
    if not ticket_id or board_id is None:
        return picked
    try:
        full = await state.local_todo.get("task", str(ticket_id), int(board_id))
    except Exception as exc:
        logger.warning("ticket hydration failed for %s: %s", ticket_id, exc)
        return picked
    if not full:
        return picked
    # Preserve any picker-side annotations (_llm_topic, board_name, etc.)
    merged = dict(picked)
    merged.update(full)
    return merged


async def pick_topic_ticket(
    state: "AppState",
    config: "AppConfig",
    question: str = "",
) -> dict | None:
    """Ask the LLM to pick which sprint ticket the meeting is currently
    about, from `state.sprint_tickets` + the recent transcript. Returns the
    picked ticket HYDRATED with body + comments via local-todo `get_task`.

    Why LLM-pick from a finite list instead of free-form extraction or
    keyword search: the constrained list eliminates hallucination, and the
    LLM understands semantic equivalence ("tribute remapper" / "the
    remapper" → ENGT-4147 about remapper) which keyword search misses.
    """
    from meeting_helper.ai.prompts import (
        TICKET_PICKER_SYSTEM_PROMPT,
        build_ticket_picker_user_message,
    )

    if not state.sprint_tickets:
        return None

    # Build the labeled transcript window — a bit larger than usual so the
    # picker has context but not so large the LLM drifts.
    timestamped = _collect_timestamped_sentences(state, n_per_buffer=8)
    labeled: list[tuple[str, str]] = [(role, txt) for _ts, role, txt in timestamped]
    if question:
        # The typed/extracted question is the freshest signal — append as a
        # `[me]` line so the prompt's "recency wins" rule favors it.
        labeled.append(("self", question))
    if not labeled:
        return None

    user_msg = build_ticket_picker_user_message(
        sprint_tickets=state.sprint_tickets,
        labeled_sentences=labeled,
    )

    try:
        raw = await _call_ai_for_tasks(
            config, TICKET_PICKER_SYSTEM_PROMPT, user_msg, kind="topic-pick"
        )
    except Exception as exc:
        logger.warning("ticket picker LLM call failed: %s", exc)
        return None

    # Parse JSON (may be wrapped in markdown fences from a chatty model)
    try:
        match = re.search(r"\{.*?\}", raw, re.DOTALL)
        data = json.loads(match.group(0)) if match else json.loads(raw)
    except Exception as exc:
        logger.warning("ticket picker returned non-JSON: %s — %r", exc, raw[:200])
        return None

    picked_id = data.get("ticket_id")
    if not picked_id:
        return None
    # Find the matching record in our sprint cache (gives us board_id for the
    # hydration call).
    for t in state.sprint_tickets:
        if str(t.get("id")) == str(picked_id):
            out = dict(t)
            out["_llm_topic"] = data.get("topic", "") or ""
            # Hydrate with body + comments + history so the reply AI has the
            # rich ticket context, not just the title.
            return await _hydrate_ticket(state, out)
    return None


async def _pre_flight_topic_refresh(
    state: "AppState",
    config: "AppConfig",
    question: str,
) -> None:
    """Pre-flight topic identification via the ticket-picker LLM.

    Runs on every query (typed or hotkey) before the AI prompt is built,
    so the reply is grounded in the right ticket from the first token.

    Skips silently if local-todo isn't connected, the picker can't match,
    OR the user has manually pinned a topic that's still inside its
    pin window (set by POST /topic/set). The manual pin already populated
    state.current_topic_cards with a hydrated card, so we skip the
    LLM round-trip entirely — saves cost AND respects the user's choice.
    """
    if state.local_todo is None:
        return
    # Honor manual topic pin — without this gate, every /query rewinds the
    # user's pinned selection to whatever the LLM picks from recent
    # transcript. MANUAL mode is sticky: the user toggles it off via the
    # AUTO/MANUAL pill in the GUI.
    if getattr(state, "topic_manual_mode", False):
        logger.debug("pre_flight: manual topic pin active — skipping LLM pick")
        return
    await refresh_sprint_tickets(state)
    picked = await pick_topic_ticket(state, config, question=question)
    if picked is None:
        return

    # The picked ticket becomes the warm cache. The banner shows its title.
    cards = [picked]
    ticket_ids = [picked.get("id")] if picked.get("id") else []
    topic_str = picked.get("title") or picked.get("_llm_topic") or ""
    if not topic_str and not ticket_ids:
        return

    prev = state.current_topic or {}
    state.current_topic = {
        "topic": topic_str,
        "ticket_ids": ticket_ids,
        "search_query": picked.get("_llm_topic") or topic_str,
        "last_user_statement": prev.get("last_user_statement", ""),
    }
    state.current_topic_cards = cards

    # Broadcast so the GUI banner snaps before the AI starts streaming.
    try:
        from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast
        await broadcast({
            "type": "topic",
            "topic": topic_str,
            "ticket_ids": ticket_ids,
            "last_user_statement": prev.get("last_user_statement", ""),
            "cards": [slim_card_for_broadcast(c) for c in cards],
            "hot_moment": {
                "active": state.is_hot_moment(),
                "until_wallclock": state.hot_moment_until_wallclock(),
            },
        })
    except Exception as exc:
        logger.warning("pre-flight topic broadcast failed: %s", exc)


_CARD_BODY_CHAR_LIMIT = 1200
_CARD_COMMENT_CHAR_LIMIT = 600
_CARD_COMMENTS_KEPT = 5


def _summary_output_path(input_path: Path) -> Path:
    """Compute the .summary.txt path for a transcript input.

    Strips compound suffixes (.live.txt, .transcript.txt) before appending
    .summary.txt. Falls back to Path.with_suffix for anything else.
    """
    name = input_path.name
    for suffix in (".live.txt", ".transcript.txt"):
        if name.endswith(suffix):
            return input_path.with_name(name[: -len(suffix)] + ".summary.txt")
    return input_path.with_suffix(".summary.txt")


def _truncate(text: str, limit: int) -> str:
    """Trim ``text`` to ``limit`` chars, appending ``…`` when cut."""
    text = (text or "").strip()
    if not text:
        return ""
    return text if len(text) <= limit else text[:limit].rstrip() + "…"


def _format_cards_markdown(cards: list[dict]) -> str:
    """Render local-todo records as a Markdown block for the system prompt.

    Includes title, status/sprint/due meta, body (up to ~1200 chars), and
    the last few comments (up to ~600 chars each). Hydrated cards from
    ``get_task`` have all of this; thin cards from ``search_tasks`` only get
    the title + meta line. Empty input returns an empty string.
    """
    if not cards:
        return ""
    lines: list[str] = []
    for c in cards:
        cid = c.get("id", "?")
        title = c.get("title", "(untitled)")
        meta_parts: list[str] = []
        if c.get("status"):
            meta_parts.append(c["status"])
        if c.get("priority"):
            meta_parts.append(f"P:{c['priority']}")
        if c.get("sprint_name") or c.get("sprint"):
            meta_parts.append(f"Sprint {c.get('sprint_name') or c['sprint']}")
        if c.get("due"):
            meta_parts.append(f"Due {c['due']}")
        if c.get("updated_at"):
            meta_parts.append(f"Updated {c['updated_at']}")
        meta = " · ".join(meta_parts) if meta_parts else ""
        head = f"- [{cid}] {title}"
        if meta:
            head += f" — {meta}"
        lines.append(head)

        # Body — try body_md first (hydrated), then body / description (thin).
        body = c.get("body_md") or c.get("body") or c.get("description")
        body_snippet = _truncate(body or "", _CARD_BODY_CHAR_LIMIT)
        if body_snippet:
            # Keep newlines so markdown structure inside the body survives —
            # indented two spaces so it's clear it belongs to the card.
            lines.append("  Body:")
            for body_line in body_snippet.split("\n"):
                lines.append(f"  {body_line}")

        # Comments — most recent first. Hydrated cards have a list; thin
        # cards don't have the field.
        comments = c.get("comments") or []
        if comments:
            # Sort by created_at descending if present, else preserve order.
            try:
                sorted_comments = sorted(
                    comments,
                    key=lambda x: x.get("created_at") or "",
                    reverse=True,
                )
            except Exception:
                sorted_comments = list(comments)
            kept = sorted_comments[:_CARD_COMMENTS_KEPT]
            lines.append(f"  Recent comments (showing {len(kept)} of {len(comments)}):")
            for cm in kept:
                cm_body = cm.get("body_md") or cm.get("body") or ""
                cm_snippet = _truncate(cm_body, _CARD_COMMENT_CHAR_LIMIT)
                if not cm_snippet:
                    continue
                cm_when = cm.get("created_at") or ""
                cm_who = cm.get("author_user_id") or cm.get("author") or ""
                header_bits = [b for b in (cm_when, cm_who) if b]
                header = f"  - " + (" · ".join(header_bits) if header_bits else "(unknown)")
                lines.append(header)
                for cm_line in cm_snippet.split("\n"):
                    lines.append(f"    {cm_line}")

        # Linked docs — name only, hint that more context exists.
        linked_docs = c.get("linked_docs") or []
        if linked_docs:
            doc_titles = [d.get("title") or d.get("id", "?") for d in linked_docs[:5]]
            lines.append("  Linked docs: " + ", ".join(doc_titles))
    return "\n".join(lines)


def _format_kb_cards_markdown(cards: "list") -> str:
    """Render KB cards (past meeting summaries + notes) as a Markdown block.

    Visually distinct from _format_cards_markdown (local-todo cards) so the
    agent and the user can both tell prior-meeting context apart from
    ticket context.
    """
    if not cards:
        return ""
    lines: list[str] = ["", "### Past meetings and notes (knowledge base)"]
    for c in cards:
        kind_label = "Meeting" if c.kind == "meeting" else "Note"
        head_bits = [kind_label]
        if c.date:
            head_bits.append(c.date)
        head_bits.append(c.title)
        lines.append(f"- **{' · '.join(head_bits)}**")
        # Body is summary text or note text — keep it whole; summaries are
        # already designed to be exhaustive but compact.
        body_lines = (c.body or "").strip().split("\n")
        for body_line in body_lines:
            lines.append(f"  {body_line}")
    return "\n".join(lines)


def slim_kb_card_for_broadcast(card) -> dict:
    """Slim a KbCard down to the wire-shape used by the overlay/dashboard."""
    return {
        "id": card.id,
        "kind": card.kind,
        "title": card.title,
        "date": card.date,
        "score": card.score,
    }


async def _retrieve_and_broadcast_kb_cards(state, config, *, query_text: str) -> str:
    """Retrieve KB cards for the current query, broadcast them, and render markdown.

    Fail-isolation lives inside `retrieve_kb_cards` itself — it always returns a list
    (empty on error) and never raises. Returns the markdown block (empty string when
    no cards were retrieved).
    """
    from meeting_helper.library_retrieval import retrieve_kb_cards
    from meeting_helper.server.websocket import broadcast

    self_text = (
        "\n".join(state.self_buffer.get_last_n(config.sentence_window * 5))
        if state.self_buffer
        else ""
    )
    other_text = (
        "\n".join(state.other_buffer.get_last_n(config.sentence_window * 5))
        if state.other_buffer
        else ""
    )
    kb_cards = await retrieve_kb_cards(
        query_text=query_text,
        self_buffer_text=self_text,
        other_buffer_text=other_text,
        config=config,
    )
    if kb_cards:
        await broadcast(
            {"type": "kb_cards", "items": [slim_kb_card_for_broadcast(c) for c in kb_cards]}
        )
    return _format_kb_cards_markdown(kb_cards)


# ---------------------------------------------------------------------------
# Message assembly
# ---------------------------------------------------------------------------

def _extract_likely_question(
    timestamped_sentences: list[tuple[float, str, str]],
    cutoff_ts: float = 0.0,
) -> str:
    """Find the most recent unanswered question in the merged transcript.

    ``timestamped_sentences`` is a list of ``(ts, role, text)`` tuples sorted
    chronologically (oldest first). Only sentences with ``ts > cutoff_ts``
    are considered — this prevents us from re-extracting a question that
    already produced an AI answer (the previous query stamps the cutoff).

    Returns the most recent ``?``-terminated sentence after the cutoff.
    Returns ``""`` if no fresh question exists. The empty case is handled
    gracefully by ``_assemble_messages``, which substitutes a "answer about
    the topic" prompt fragment.
    """
    fresh = [(ts, txt) for ts, _role, txt in timestamped_sentences if ts > cutoff_ts]
    for _ts, txt in reversed(fresh):
        if txt.rstrip().endswith("?"):
            return txt.strip()
    return ""


def _collect_timestamped_sentences(
    state: "AppState",
    n_per_buffer: int,
) -> list[tuple[float, str, str]]:
    """Read the most recent ``n_per_buffer`` entries from each buffer and
    return a chronological merge as ``[(ts, role, text), ...]``.

    Reads the raw buffers (with timestamps) under their existing locks.
    """
    self_entries: list[tuple[float, str, str]] = []
    other_entries: list[tuple[float, str, str]] = []
    if state.self_buffer is not None:
        with state.self_buffer._lock:  # noqa: SLF001 — no public ts accessor today
            self_entries = [
                (e.timestamp, "self", e.text)
                for e in list(state.self_buffer._sentences)[-n_per_buffer:]
            ]
    if state.other_buffer is not None:
        with state.other_buffer._lock:  # noqa: SLF001
            other_entries = [
                (e.timestamp, "other", e.text)
                for e in list(state.other_buffer._sentences)[-n_per_buffer:]
            ]
    return sorted(self_entries + other_entries, key=lambda t: t[0])


def _assemble_messages(state: "AppState", config: "AppConfig") -> list:
    """Build the messages list with explicit, role-tagged context sections.

    Sections (in order):
      ## Topic just discussed         — from state.current_topic (TopicWorker)
      ## What I just said             — from state.self_buffer
      ## What others just said        — from state.other_buffer
      ## What was just asked          — explicit question (last '?' in either buffer)

    The AI prompt's "answer using these sections" rule pins the model to this
    structure, eliminating "I don't have enough context" responses.
    """
    self_sentences: list[str] = []
    other_sentences: list[str] = []
    if state.self_buffer is not None:
        self_sentences = state.self_buffer.get_last_n(config.sentence_window * 5)
    if state.other_buffer is not None:
        other_sentences = state.other_buffer.get_last_n(config.sentence_window * 5)

    if not self_sentences and not other_sentences:
        content = "No transcript captured yet. The meeting may have just started."
    else:
        # Find the most recent NEW question across BOTH buffers, merged
        # chronologically. ``last_query_at`` filters out stale questions that
        # already produced an answer.
        timestamped = _collect_timestamped_sentences(state, n_per_buffer=8)
        question = _extract_likely_question(timestamped, cutoff_ts=state.last_query_at)
        # Stamp the cursor — anything earlier than now is "already considered"
        # for question extraction. Updated even when no `?` was found, so the
        # next call doesn't keep searching the same window.
        state.last_query_at = time.time()

        topic = state.current_topic or {}
        topic_lines: list[str] = []
        if topic.get("topic"):
            topic_lines.append(f"- Topic: {topic['topic']}")
        if topic.get("ticket_ids"):
            topic_lines.append(f"- Tickets: {', '.join(topic['ticket_ids'])}")
        if topic.get("last_user_statement"):
            topic_lines.append(f'- Last thing I said: "{topic["last_user_statement"]}"')
        topic_block = "\n".join(topic_lines) if topic_lines else "(no topic identified yet)"

        self_block = "\n".join(self_sentences) if self_sentences else "(silent)"
        other_block = "\n".join(other_sentences) if other_sentences else "(silent)"

        content = (
            "## Topic just discussed\n"
            f"{topic_block}\n\n"
            "## What I just said (first person, my own voice)\n"
            f"{self_block}\n\n"
            "## What others just said\n"
            f"{other_block}\n\n"
            "## What was just asked\n"
            f"{question or '(no explicit question — answer about the topic above)'}\n\n"
            "Answer the question above. LEAD with the answer itself, not a status preamble like 'so I'm working on…'. If the answer has several parts (multiple causes, components, items), give a one-sentence lead-in then break the parts out as `-` bullets with **bold** labels; if it's a single point, one short sentence is enough. If it's about the work in the sections above or the loaded tickets, ground it there and resolve any pronouns/fragments from that context; if it's a general or conceptual question, just answer it directly from what you know — no forced ticket connection, no ticket header. Either way, commit; never ask for clarification."
        )

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    return messages


# ---------------------------------------------------------------------------
# Streaming helpers
# ---------------------------------------------------------------------------

async def _broadcast_first_token_latency(t0: float) -> None:
    """Broadcast time-to-first-token (ms) once, right after the first text token.

    `t0` is a `time.monotonic()` reading taken just before the streaming call
    started, so this measures the chosen model's real first-token latency
    (including any provider-side "thinking"), independent of context assembly.
    """
    from meeting_helper.server.websocket import broadcast
    ms = max(0, round((time.monotonic() - t0) * 1000))
    await broadcast({"type": "ai_latency", "first_token_ms": ms})


# ---------------------------------------------------------------------------
# Claude (Anthropic) streaming
# ---------------------------------------------------------------------------

async def _stream_claude_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields Claude text deltas. Raises on hard error.

    On a context-too-long BadRequestError it trims `state.conversation_history`
    in place and retries once (yielding the retry's deltas).
    No broadcast() calls — callers handle broadcasting.
    """
    import anthropic
    import httpx

    if not config.anthropic_api_key:
        raise RuntimeError("No Anthropic API key configured")

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )

    async def _once(msgs):
        async with client.messages.stream(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=system_prompt,
            messages=msgs,
        ) as stream:
            async for text_delta in stream.text_stream:
                if text_delta:
                    yield text_delta

    try:
        async for d in _once(messages):
            yield d
    except anthropic.AuthenticationError as exc:
        raise RuntimeError("Invalid Anthropic API key") from exc
    except anthropic.BadRequestError as exc:
        if "token" not in str(exc).lower():
            raise RuntimeError(f"Claude bad request: {exc}") from exc
        # Context too long — trim history and retry once.
        half = max(2, len(state.conversation_history) // 2)
        logger.warning("Claude context too long — trimming history %d→%d, retrying",
                       len(state.conversation_history), half)
        state.conversation_history = state.conversation_history[half:]
        msgs_retry = list(state.conversation_history) + [messages[-1]]
        async for d in _once(msgs_retry):
            yield d


# ---------------------------------------------------------------------------
# Gemini (Google) streaming
# ---------------------------------------------------------------------------

def _messages_to_gemini_contents(messages: list) -> list:
    """Convert internal message format to Gemini contents list."""
    from google.genai import types

    contents = []
    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        text = msg.get("content", "")
        if isinstance(text, str) and text:
            contents.append(types.Content(
                role=role,
                parts=[types.Part.from_text(text=text)],
            ))
        elif isinstance(text, list):
            parts = [types.Part.from_text(text=b["text"]) for b in text if b.get("type") == "text"]
            if parts:
                contents.append(types.Content(role=role, parts=parts))
    return contents


async def _stream_gemini_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields Gemini text deltas. Raises on hard error.
    No broadcast() calls — callers handle broadcasting.
    """
    if not config.google_api_key:
        raise RuntimeError("No Google API key configured")

    from google import genai
    from google.genai import types

    model = config.gemini_model
    client = genai.Client(api_key=config.google_api_key)
    contents = _messages_to_gemini_contents(messages)

    gen_kwargs: dict = dict(system_instruction=system_prompt, max_output_tokens=config.max_tokens)
    # Gemini 3 models "think" before answering, which adds noticeable
    # latency. For a real-time copilot we want the fastest response, so keep
    # the thinking effort minimal.
    if "gemini-3" in model:
        gen_kwargs["thinking_config"] = types.ThinkingConfig(thinking_level="low")

    q: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_event_loop()
    _sentinel = object()

    def _produce():
        try:
            for chunk in client.models.generate_content_stream(
                model=model,
                contents=contents,
                config=types.GenerateContentConfig(**gen_kwargs),
            ):
                text = getattr(chunk, "text", None)
                if text:
                    loop.call_soon_threadsafe(q.put_nowait, text)
        except Exception as exc:  # surface the error to the consumer
            loop.call_soon_threadsafe(q.put_nowait, exc)
        finally:
            loop.call_soon_threadsafe(q.put_nowait, _sentinel)

    task = loop.run_in_executor(None, _produce)
    try:
        while True:
            item = await q.get()
            if item is _sentinel:
                break
            if isinstance(item, Exception):
                raise RuntimeError(f"Gemini error: {item}") from item
            yield item
    finally:
        await task


# ---------------------------------------------------------------------------
# Ollama (local) streaming
# ---------------------------------------------------------------------------

def _ensure_ollama(model: str, host: str = "http://localhost:11434") -> bool:
    """Ensure Ollama is running and the model is available. Returns True if ready."""
    from meeting_helper.ai.ollama_utils import (
        is_ollama_installed, start_ollama, get_installed_models, keep_alive, _is_remote,
    )

    remote = _is_remote(host)

    if not remote and not is_ollama_installed():
        logger.error("Ollama not installed")
        return False

    if not start_ollama(host):
        logger.error("Ollama server failed to start (host=%s)", host)
        return False

    if not remote:
        keep_alive()

    installed = get_installed_models(start_server=True, host=host)
    if model not in installed:
        logger.error("Model %s not available on %s. Download it from Settings.", model, host)
        return False

    return True


def _trim_system_prompt_for_local(system_prompt: str, max_chars: int = 4000) -> str:
    """Trim the system prompt for local models that have smaller context windows.

    Keeps the core instructions and truncates the workspace context block.
    """
    if len(system_prompt) <= max_chars:
        return system_prompt

    # Find the context block separator
    sep = "\n\n---\nThe user's workspace context is below."
    idx = system_prompt.find(sep)
    if idx == -1:
        # No context block — just truncate
        return system_prompt[:max_chars]

    # Keep core prompt + truncated context
    core = system_prompt[:idx]
    context = system_prompt[idx:]
    remaining = max_chars - len(core) - 100  # leave room for truncation notice
    if remaining > 200:
        trimmed_context = context[:remaining] + "\n\n[... context truncated for local model ...]"
        return core + trimmed_context
    else:
        return core


async def _stream_ollama_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields Ollama text deltas. Raises on hard error.
    No broadcast() calls — callers handle broadcasting.
    """
    model = config.local_model
    host = config.ollama_host
    loop = asyncio.get_event_loop()
    ready = await loop.run_in_executor(None, _ensure_ollama, model, host)
    if not ready:
        raise RuntimeError(f"Ollama not reachable at {host}")
    system_prompt = _trim_system_prompt_for_local(system_prompt)

    ollama_messages = [{"role": "system", "content": system_prompt}]
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, list):
            content = "\n\n".join(b["text"] for b in content if b.get("type") == "text")
        if content:
            ollama_messages.append({"role": msg["role"], "content": content})

    q: asyncio.Queue = asyncio.Queue()
    _sentinel = object()

    def _produce():
        try:
            body = json.dumps(
                {"model": model, "messages": ollama_messages, "stream": True}
            ).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=45) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    text = chunk.get("message", {}).get("content", "")
                    if text:
                        loop.call_soon_threadsafe(q.put_nowait, text)
        except Exception as exc:
            loop.call_soon_threadsafe(q.put_nowait, exc)
        finally:
            loop.call_soon_threadsafe(q.put_nowait, _sentinel)

    task = loop.run_in_executor(None, _produce)
    try:
        while True:
            item = await q.get()
            if item is _sentinel:
                break
            if isinstance(item, Exception):
                raise RuntimeError(f"Local AI error: {item}") from item
            yield item
    finally:
        await task


# ---------------------------------------------------------------------------
# Provider cascade orchestrator
# ---------------------------------------------------------------------------

# Provider key -> (display label, async-generator factory).
# A generator factory has signature:
#   async def f(state, config, messages, system_prompt) -> AsyncIterator[str]
_PROVIDER_GENERATORS = {
    "anthropic": ("Claude", _stream_claude_gen),
    "google": ("Gemini", _stream_gemini_gen),
    "local": ("Local", _stream_ollama_gen),
}

_ANSWER_IDS = "ABCDEFGH"          # up to 8 concurrent answers — plenty
_HARD_CEILING_SEC = 20.0          # no first token from anyone within this → give up


def _key_available(config: "AppConfig", key: str) -> bool:
    if key == "anthropic":
        return bool(config.anthropic_api_key)
    if key == "google":
        return bool(config.google_api_key)
    if key == "local":
        return True
    return False


def _provider_model(config: "AppConfig", key: str) -> str:
    if key == "anthropic":
        return (getattr(config, "claude_model_alias", "")
                or getattr(config, "claude_model", "") or "claude")
    if key == "google":
        return (getattr(config, "gemini_model_alias", "")
                or getattr(config, "gemini_model", "") or "gemini")
    if key == "local":
        return getattr(config, "local_model", "") or "local"
    return key


async def _drain_answer(state, config, messages, system_prompt, *,
                        answer_id: str, provider_key: str, label: str,
                        first_token_event: "asyncio.Event", results: dict) -> None:
    """Run one provider generator to completion, broadcasting answer_open / chunk /
    done. Records full text + first_token_ms (or error) into `results[answer_id]`.
    Never raises — failures are captured in `results`."""
    from meeting_helper.server.websocket import broadcast
    model = _provider_model(config, provider_key)
    factory = _PROVIDER_GENERATORS[provider_key][1]
    results[answer_id] = {"provider": label.lower(), "model": model, "text": "",
                          "first_token_ms": None, "error": None}
    t0 = time.monotonic()
    opened = False
    try:
        async for delta in factory(state, config, messages, system_prompt):
            if not delta:
                continue
            if not opened:
                opened = True
                await broadcast({"type": "answer_open", "answer_id": answer_id,
                                 "provider": label.lower(), "model": model})
                ms = max(0, round((time.monotonic() - t0) * 1000))
                results[answer_id]["first_token_ms"] = ms
                first_token_event.set()
            results[answer_id]["text"] += delta
            await broadcast({"type": "chunk", "answer_id": answer_id, "text": delta})
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        results[answer_id]["error"] = str(exc)
        logger.warning("answer %s (%s) failed: %s", answer_id, label, exc)
        return
    if opened:
        await broadcast({"type": "done", "answer_id": answer_id,
                         "full_text": results[answer_id]["text"],
                         "first_token_ms": results[answer_id]["first_token_ms"]})


async def _stream_ai(state: "AppState", config: "AppConfig", messages: list,
                     system_prompt: str, *, kind: str = "stream") -> str:
    """Run the configured provider cascade. Returns the canonical (primary) answer
    text — or, if the primary produced nothing, the first answer that did, else ""."""
    from meeting_helper.server.websocket import broadcast
    state.record_ai_call(kind)

    # Resolve participating providers: ai_provider_order filtered by available keys.
    order = [k for k in (getattr(config, "ai_provider_order", None) or ["anthropic", "google"])
             if _key_available(config, k)]
    if not order:
        await broadcast({"type": "error", "message": "No AI provider configured."})
        return ""

    delay_ms = max(0, int(getattr(config, "ai_failover_delay_ms", 2000)))
    first_token_event = asyncio.Event()
    results: dict[str, dict] = {}
    tasks: dict[str, asyncio.Task] = {}
    launched = 0

    def _launch_next() -> bool:
        nonlocal launched
        if launched >= len(order):
            return False
        key = order[launched]
        aid = _ANSWER_IDS[launched]
        label = _PROVIDER_GENERATORS[key][0]
        tasks[aid] = asyncio.create_task(_drain_answer(
            state, config, messages, system_prompt,
            answer_id=aid, provider_key=key, label=label,
            first_token_event=first_token_event, results=results))
        launched += 1
        return True

    try:
        _launch_next()  # primary

        # Cascade: keep launching the next provider every `delay_ms` until SOMEONE
        # emits a first token (or every task currently launched has finished, or
        # we hit the hard ceiling). delay_ms == 0 → launch everyone immediately.
        ceiling = time.monotonic() + _HARD_CEILING_SEC
        ev_waiter: asyncio.Task | None = None
        while launched < len(order):
            if delay_ms == 0:
                _launch_next()
                continue
            # Wake as soon as either someone emits a first token OR every
            # currently-launched answer has finished (e.g. the primary errored
            # instantly) — whichever comes first, capped at `delay_ms`.
            if ev_waiter is None or ev_waiter.done():
                ev_waiter = asyncio.create_task(first_token_event.wait())
            pending_answers = [t for t in tasks.values() if not t.done()]
            await asyncio.wait({ev_waiter, *pending_answers},
                               timeout=delay_ms / 1000.0,
                               return_when=asyncio.FIRST_COMPLETED)
            if first_token_event.is_set():
                break  # someone produced a first token — stop cascading
            # If every launched task is already done and none produced a token,
            # launch the next one immediately rather than waiting another window.
            if all(t.done() for t in tasks.values()):
                if not _launch_next():
                    break
                continue
            if time.monotonic() >= ceiling:
                break
            _launch_next()
        if ev_waiter is not None and not ev_waiter.done():
            ev_waiter.cancel()

        # Wait for all launched answers to finish.
        if tasks:
            done, pending = await asyncio.wait(tasks.values(), timeout=_HARD_CEILING_SEC)
            for t in pending:
                t.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
    except asyncio.CancelledError:
        if ev_waiter is not None and not ev_waiter.done():
            ev_waiter.cancel()
        for t in tasks.values():
            t.cancel()
        await asyncio.gather(*tasks.values(), return_exceptions=True)
        raise

    # Canonical answer = primary if it produced text, else first (by launch order)
    # that did.
    primary_aid = _ANSWER_IDS[0]
    ordered_aids = [_ANSWER_IDS[i] for i in range(launched)]
    canonical = ""
    for aid in ordered_aids:
        r = results.get(aid)
        if r and r["text"]:
            canonical = r["text"]
            break

    if not canonical:
        await broadcast({"type": "error", "message": "All AI providers failed or timed out."})
        return ""

    await broadcast({"type": "all_done"})
    return canonical


# ---------------------------------------------------------------------------
# Real-time query (during meeting, hotkey-triggered)
# ---------------------------------------------------------------------------

async def handle_query(state: "AppState", config: "AppConfig") -> None:
    """Assemble context from buffers + warm topic, stream AI response.

    NO per-query LLM extraction or cards search — TopicWorker keeps
    state.current_topic and state.current_topic_cards updated every ~5s.
    """
    from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast

    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()
    state.active_query_started_at = time.time()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    # Pre-flight topic refresh: per-query LLM extraction over the recent
    # buffers, then load the actual ticket from local-todo. Grounds the
    # AI's reply in fresh, ticket-loaded context every single time. Latency
    # cost: one Haiku-style call (~200 ms) + one local-todo search.
    try:
        _failover_ms = int(getattr(config, "ai_failover_delay_ms", 2000))
    except (TypeError, ValueError):
        _failover_ms = 2000
    _preflight_timeout = max(4.0, 2 * _failover_ms / 1000.0)
    try:
        await asyncio.wait_for(
            _pre_flight_topic_refresh(state, config, question=""),
            timeout=_preflight_timeout,
        )
    except asyncio.TimeoutError:
        logger.warning("pre-flight topic refresh timed out after %.1fs — answering with warm cache",
                       _preflight_timeout)
    except Exception as exc:
        logger.warning("pre-flight topic refresh failed: %s — answering with warm cache", exc)

    # Warm reads now reflect the pre-flight refresh.
    cards = list(state.current_topic_cards or [])
    cards_markdown = _format_cards_markdown(cards)
    state.last_cards = cards
    if cards:
        await broadcast({"type": "cards", "items": [slim_card_for_broadcast(c) for c in cards]})

    # KB retrieval (past meetings + notes flagged 📚). Fail-isolation lives
    # inside retrieve_kb_cards — it always returns a list, never raises.
    cards_markdown = cards_markdown + await _retrieve_and_broadcast_kb_cards(
        state, config, query_text=""
    )

    messages = _assemble_messages(state, config)
    current_user_turn = messages[-1]
    from meeting_helper.ai.prompts import build_system_prompt
    system_prompt = build_system_prompt(
        context_block="",
        cards_markdown=cards_markdown,
    )

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt, kind="query")

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            logger.info("Query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Query cancelled")
        return

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Manual query (user-typed text during meeting)
# ---------------------------------------------------------------------------

async def handle_manual_query(state: "AppState", config: "AppConfig", user_text: str) -> None:
    """Send a user-typed question to AI, with both transcripts + warm topic."""
    from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast

    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()
    state.active_query_started_at = time.time()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    # Pre-flight topic refresh: LLM extraction over the typed question +
    # recent buffers, then load the actual ticket from local-todo. The AI's
    # prompt that follows is grounded in the loaded ticket, not just whatever
    # TopicWorker last cached.
    try:
        _failover_ms = int(getattr(config, "ai_failover_delay_ms", 2000))
    except (TypeError, ValueError):
        _failover_ms = 2000
    _preflight_timeout = max(4.0, 2 * _failover_ms / 1000.0)
    try:
        await asyncio.wait_for(
            _pre_flight_topic_refresh(state, config, question=user_text),
            timeout=_preflight_timeout,
        )
    except asyncio.TimeoutError:
        logger.warning("pre-flight topic refresh timed out after %.1fs — answering with warm cache",
                       _preflight_timeout)
    except Exception as exc:
        logger.warning("pre-flight topic refresh failed: %s — answering with warm cache", exc)

    # Warm cache (now refreshed by pre-flight)
    cards = list(state.current_topic_cards or [])
    cards_markdown = _format_cards_markdown(cards)
    state.last_cards = cards
    if cards:
        await broadcast({"type": "cards", "items": [slim_card_for_broadcast(c) for c in cards]})

    # KB retrieval (past meetings + notes flagged 📚). Fail-isolation lives
    # inside retrieve_kb_cards — it always returns a list, never raises.
    cards_markdown = cards_markdown + await _retrieve_and_broadcast_kb_cards(
        state, config, query_text=user_text
    )

    # Build full prompt content with explicit user-typed question
    self_sentences: list[str] = []
    other_sentences: list[str] = []
    if state.self_buffer is not None:
        self_sentences = state.self_buffer.get_last_n(config.sentence_window * 5)
    if state.other_buffer is not None:
        other_sentences = state.other_buffer.get_last_n(config.sentence_window * 5)

    topic = state.current_topic or {}
    topic_lines: list[str] = []
    if topic.get("topic"):
        topic_lines.append(f"- Topic: {topic['topic']}")
    if topic.get("ticket_ids"):
        topic_lines.append(f"- Tickets: {', '.join(topic['ticket_ids'])}")
    if topic.get("last_user_statement"):
        topic_lines.append(f'- Last thing I said: "{topic["last_user_statement"]}"')
    topic_block = "\n".join(topic_lines) if topic_lines else "(no topic identified yet)"

    self_block = "\n".join(self_sentences) if self_sentences else "(silent)"
    other_block = "\n".join(other_sentences) if other_sentences else "(silent)"

    # Stamp the question cursor so the next hotkey press won't re-extract any
    # `?` from the buffer that's older than this typed query.
    state.last_query_at = time.time()

    content = (
        "## Topic just discussed\n"
        f"{topic_block}\n\n"
        "## What I just said (first person)\n"
        f"{self_block}\n\n"
        "## What others just said\n"
        f"{other_block}\n\n"
        "## What was just asked (typed by me)\n"
        f"{user_text}\n\n"
        "Answer the typed question. LEAD with the answer itself, not a status preamble like 'so I'm working on…'. If the answer has several parts (multiple causes, components, items), give a one-sentence lead-in then break the parts out as `-` bullets with **bold** labels; if it's a single point, one short sentence is enough. If it's about the work in the sections above or the loaded tickets, ground it there and resolve any pronouns or vague references from that context; if it's a general or conceptual question, just answer it directly from what you know — no forced ticket connection, no ticket header."
    )

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    from meeting_helper.ai.prompts import build_system_prompt
    system_prompt = build_system_prompt(
        context_block="",
        cards_markdown=cards_markdown,
    )

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt, kind="query-manual")

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            logger.info("Manual query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Manual query cancelled")
        return

    except Exception as exc:
        logger.error("Manual query error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Proactive query (auto-triggered when a question is detected in transcript)
# ---------------------------------------------------------------------------

async def handle_proactive_query(state: "AppState", config: "AppConfig", question: str) -> None:
    """Auto-triggered query when a question is detected. Same as manual but labeled auto."""
    # NOTE: KB retrieval (past meetings/notes) is intentionally skipped in the
    # proactive path. This handler does not go through build_system_prompt and
    # uses the cached state.system_prompt / config.system_prompt directly to
    # keep auto-detected replies snappy. If KB injection is wanted here too in
    # the future, refactor this handler to use _retrieve_and_broadcast_kb_cards
    # and build_system_prompt like handle_query / handle_manual_query.
    from meeting_helper.server.websocket import broadcast

    # Cancel any in-progress streaming task
    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one (proactive)")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()
    state.active_query_started_at = time.time()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start", "proactive": True, "question": question})

    transcript = ""
    if state.sentence_buffer is not None:
        transcript = state.sentence_buffer.get_last_n_as_text(config.sentence_window * 2)

    if transcript:
        content = f"{question}\n\n---\n## Recent meeting transcript:\n{transcript}"
    else:
        content = question

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    system_prompt = state.system_prompt or config.system_prompt

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt, kind="query-proactive")

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            logger.info("Proactive query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Proactive query cancelled")
        return

    except Exception as exc:
        logger.error("Proactive query error: %s", exc)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Post-meeting: transcribe MP3 with faster-whisper
# ---------------------------------------------------------------------------

def transcribe_audio_file(mp3_path: str, config: "AppConfig") -> str:
    """Transcribe an MP3 file using faster-whisper. Returns full transcript text.

    Runs synchronously — caller should wrap in asyncio.to_thread().
    """
    from faster_whisper import WhisperModel

    path = Path(mp3_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {mp3_path}")

    logger.info("Transcribing %s with faster-whisper...", path.name)
    t0 = time.monotonic()

    from meeting_helper.ssl_fix import patch_ssl
    patch_ssl()

    model = WhisperModel("medium", compute_type="int8")
    segments, info = model.transcribe(
        str(path),
        language=config.transcription_language if config.transcription_language != "auto" else None,
        beam_size=5,
        vad_filter=True,
        condition_on_previous_text=True,
    )

    lines: list[str] = []
    for segment in segments:
        start_m, start_s = divmod(int(segment.start), 60)
        end_m, end_s = divmod(int(segment.end), 60)
        timestamp = f"[{start_m:02d}:{start_s:02d} - {end_m:02d}:{end_s:02d}]"
        lines.append(f"{timestamp} {segment.text.strip()}")

    transcript = "\n".join(lines)
    elapsed = time.monotonic() - t0
    logger.info("Transcription complete: %d segments, %.1fs", len(lines), elapsed)

    # Save alongside the MP3
    out_path = path.with_suffix(".transcript.txt")
    out_path.write_text(transcript)
    logger.info("Transcript saved: %s", out_path.name)

    return transcript


# ---------------------------------------------------------------------------
# Post-meeting: summarize transcript
# ---------------------------------------------------------------------------

async def summarize_transcript(transcript_path: str, config: "AppConfig") -> str:
    """Send a full transcript to the configured AI provider for structured summary."""
    from meeting_helper.ai.prompts import SUMMARIZE_SYSTEM_PROMPT

    path = Path(transcript_path)
    if not path.exists():
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")

    transcript = path.read_text()
    if not transcript.strip():
        raise ValueError("Transcript file is empty")

    logger.info("Summarizing transcript (%d chars)...", len(transcript))
    t0 = time.monotonic()

    user_msg = f"Please summarize this meeting transcript:\n\n{transcript}"

    if config.preferred_provider == "local":
        # Use Ollama
        model = config.local_model
        host = config.ollama_host
        ready = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_ollama, model, host,
        )
        if not ready:
            raise ValueError(f"Ollama not reachable at {host}")

        def _summarize_sync():
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": SUMMARIZE_SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read()).get("message", {}).get("content", "")

        summary = await asyncio.get_event_loop().run_in_executor(None, _summarize_sync)

    elif config.preferred_provider == "gemini" and config.google_api_key:
        # Use Gemini
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=config.google_api_key)

        def _summarize_gemini():
            resp = client.models.generate_content(
                model=config.gemini_model,
                contents=user_msg,
                config=types.GenerateContentConfig(
                    system_instruction=SUMMARIZE_SYSTEM_PROMPT,
                    max_output_tokens=config.max_tokens,
                ),
            )
            return resp.text or ""

        summary = await asyncio.get_event_loop().run_in_executor(None, _summarize_gemini)

    else:
        # Use Claude
        import anthropic
        import httpx

        if not config.anthropic_api_key:
            raise ValueError("No Anthropic API key configured")

        client = anthropic.AsyncAnthropic(
            api_key=config.anthropic_api_key,
            http_client=httpx.AsyncClient(verify=False),
        )
        message = await client.messages.create(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=SUMMARIZE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        summary = message.content[0].text

    elapsed = time.monotonic() - t0
    logger.info("Summarization complete: %d chars, %.1fs", len(summary), elapsed)

    # Save alongside the transcript — handle both .live.txt and .transcript.txt
    out_path = _summary_output_path(path)
    out_path.write_text(summary)
    logger.info("Summary saved: %s", out_path.name)

    return summary


async def _call_ai_for_tasks(
    config: "AppConfig", system_prompt: str, user_msg: str, *, kind: str = "tasks"
) -> str:
    """Send a single non-streaming request to the configured provider, return raw text."""
    from meeting_helper.state import state as _state
    _state.record_ai_call(kind)
    if config.preferred_provider == "local":
        model = config.local_model
        host = config.ollama_host
        ready = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_ollama, model, host,
        )
        if not ready:
            raise RuntimeError(f"Ollama not reachable at {host}")

        def _sync():
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_msg},
                ],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read()).get("message", {}).get("content", "")
        return await asyncio.get_event_loop().run_in_executor(None, _sync)

    if config.preferred_provider == "gemini" and config.google_api_key:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=config.google_api_key)

        def _sync():
            resp = client.models.generate_content(
                model=config.gemini_model,
                contents=user_msg,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    max_output_tokens=config.max_tokens,
                ),
            )
            return resp.text or ""
        return await asyncio.get_event_loop().run_in_executor(None, _sync)

    import anthropic
    import httpx

    if not config.anthropic_api_key:
        raise RuntimeError("No Anthropic API key configured")

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )
    message = await client.messages.create(
        model=config.claude_model,
        max_tokens=config.max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    )
    return message.content[0].text


async def extract_tasks(state: "AppState", config: "AppConfig") -> list[dict]:
    """Extract new action items from the live transcript.

    Reads state.sentence_buffer + state.session_tasks. Appends newly extracted
    tasks to state.session_tasks. Returns the list of newly added tasks
    (empty on any failure or empty transcript).
    """
    from meeting_helper.ai.prompts import (
        EXTRACT_TASKS_SYSTEM_PROMPT,
        build_extract_tasks_user_message,
    )
    from meeting_helper import tasks as tasks_mod

    if state.sentence_buffer is None:
        return []
    transcript = state.sentence_buffer.get_full_transcript().strip()
    if not transcript:
        return []

    existing_titles = [t.get("title") or t.get("text", "") for t in state.session_tasks]
    user_msg = build_extract_tasks_user_message(transcript, existing_titles)

    logger.info("extract_tasks: transcript=%d chars, existing=%d",
                len(transcript), len(existing_titles))

    try:
        raw = await _call_ai_for_tasks(
            config, EXTRACT_TASKS_SYSTEM_PROMPT, user_msg, kind="extract-tasks"
        )
    except Exception as exc:
        logger.warning("extract_tasks: AI call failed: %s", exc)
        return []

    parsed = tasks_mod.parse_ai_response(raw)
    if not parsed:
        return []

    new_tasks = tasks_mod.finalize_tasks(parsed)
    state.session_tasks.extend(new_tasks)
    logger.info("extract_tasks: added %d tasks (total=%d)",
                len(new_tasks), len(state.session_tasks))
    return new_tasks
