# Changelog

## 0.16.0 (2026-04-06)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/surgeapi/python-sdk/compare/v0.15.0...v0.16.0)

### Features

* **api:** create an audience ([9727f07](https://github.com/surgeapi/python-sdk/commit/9727f073425376bed9b81696a33bc6e0b14dd0e4))
* **api:** require terms_and_conditions_url for campaigns ([de1f3ea](https://github.com/surgeapi/python-sdk/commit/de1f3ea22f7353a14d3324ec847f8652c4c8a0da))
* **api:** update a campaign ([148f377](https://github.com/surgeapi/python-sdk/commit/148f37712485144a8879c0e7276bc2b165d201c5))

## 0.15.0 (2026-04-01)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/surgeapi/python-sdk/compare/v0.14.0...v0.15.0)

### Features

* **api:** add a contact to an audience ([165faea](https://github.com/surgeapi/python-sdk/commit/165faeaab6ba9647ad09224f0a1cb92538cb8cd5))
* **api:** allow canadian organizations ([6fdc307](https://github.com/surgeapi/python-sdk/commit/6fdc3072d36fcc529dd99627dd76a6dc17857466))
* **api:** list contacts in audiences ([8d250d8](https://github.com/surgeapi/python-sdk/commit/8d250d81acb5c3d87ad9d8052ef9b6b8e0282e85))
* **internal:** implement indices array format for query and form serialization ([1a15830](https://github.com/surgeapi/python-sdk/commit/1a1583061167ba5a0e774fae1d4e552ffacbb33c))


### Chores

* **ci:** skip lint on metadata-only changes ([b0c7411](https://github.com/surgeapi/python-sdk/commit/b0c7411ccc4aad8278beb8d5ede4360231423b1f))


### Documentation

* **api:** allow Canadian mobile number ([b06654f](https://github.com/surgeapi/python-sdk/commit/b06654fb187f23449817d3b5c69214d73fa17917))

## 0.14.0 (2026-03-24)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/surgeapi/python-sdk/compare/v0.13.0...v0.14.0)

### Features

* **api:** get and list recordings endpoints ([6c6708c](https://github.com/surgeapi/python-sdk/commit/6c6708c638e2be30037da2924687396d35ea8a2d))
* **api:** list users endpoint ([68363dc](https://github.com/surgeapi/python-sdk/commit/68363dc5c1e16a6c6f3f4338e2bf58d72d4c745e))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([aa8ba6f](https://github.com/surgeapi/python-sdk/commit/aa8ba6fb822f18b12967a0afa6fe15372b11b267))
* **pydantic:** do not pass `by_alias` unless set ([f5efffe](https://github.com/surgeapi/python-sdk/commit/f5efffe7c979ff1bcaf759c0109e81c97692dca5))
* sanitize endpoint path params ([859f37d](https://github.com/surgeapi/python-sdk/commit/859f37d4330b55c6bb48223fc903d14d1a1094a2))


### Chores

* **internal:** tweak CI branches ([d74dbf6](https://github.com/surgeapi/python-sdk/commit/d74dbf61b220b77ee3dc5bbf6da150f836520202))
* **internal:** update gitignore ([c8df3a3](https://github.com/surgeapi/python-sdk/commit/c8df3a3cc07ca0a1a2ee549f5c9eb3527cb61239))

## 0.13.0 (2026-03-11)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/surgeapi/python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** add campaign ID to phone numbers ([0e51d36](https://github.com/surgeapi/python-sdk/commit/0e51d369c478446fbe88315e1e2b26d5b43f702f))
* **api:** add phoneNumberAttachedToCampaign webhook ([ae2844f](https://github.com/surgeapi/python-sdk/commit/ae2844fb07dac358e9ef1428382e403f0f482abb))
* **api:** remove 'pending' campaign status ([3088b15](https://github.com/surgeapi/python-sdk/commit/3088b15d753ee0dadbcc1936097aae419bdabc1a))
* **api:** rename segments to audiences ([798e60c](https://github.com/surgeapi/python-sdk/commit/798e60cad12e5c92fe83b6bfea2d4b73952407ca))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([d8bb15a](https://github.com/surgeapi/python-sdk/commit/d8bb15aecfe2f4a0f20ea60b1a610709897fbb06))
* **dependencies:** require standardwebhooks 1.0.1 ([5e4fb88](https://github.com/surgeapi/python-sdk/commit/5e4fb8836d01faf0d1cbd1c72f1fbcf9fbfdf9bd))
* **internal:** add request options to SSE classes ([e84cf02](https://github.com/surgeapi/python-sdk/commit/e84cf02ed7c59d8f31889b26224b07360bef9ee7))
* **internal:** make `test_proxy_environment_variables` more resilient ([9aae19d](https://github.com/surgeapi/python-sdk/commit/9aae19dbc2bb8207ad07a1226d8cf7905e25845a))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([b3ed71d](https://github.com/surgeapi/python-sdk/commit/b3ed71dc48b367967f505da7ea05878eae5977de))
* **tests:** update webhook tests ([0bff74e](https://github.com/surgeapi/python-sdk/commit/0bff74ede7d437a6dfc742c0fbe0062e6c8e356d))

## 0.12.0 (2026-02-22)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/surgeapi/python-sdk/compare/v0.11.0...v0.12.0)

### Features

* **api:** add list campaigns endpoint ([7c546c3](https://github.com/surgeapi/python-sdk/commit/7c546c3a7271db8d0f45c581cff8bdfe83df6cd5))
* **api:** add metadata to message webhooks ([b6e794a](https://github.com/surgeapi/python-sdk/commit/b6e794a304eb02168442d9a9ddf43357b5bac293))
* **api:** delete recording endpoint ([f0c9d1d](https://github.com/surgeapi/python-sdk/commit/f0c9d1d3f98ba0948a8059f7bdb5c69bb6a64e6a))
* **api:** make attachment type an enum ([a5556bc](https://github.com/surgeapi/python-sdk/commit/a5556bc9c6e2dde38589bea08775653f5c7f0e07))


### Chores

* format all `api.md` files ([f862135](https://github.com/surgeapi/python-sdk/commit/f8621354800c8323130a4395169907b97b0ebd98))
* **internal:** fix lint error on Python 3.14 ([e0d7a11](https://github.com/surgeapi/python-sdk/commit/e0d7a1156a8704f50f384051ec655c27f383f46d))
* **internal:** remove mock server code ([00ad53a](https://github.com/surgeapi/python-sdk/commit/00ad53a11f706bbdab70148e2212598a4fe62805))
* **test:** update skip reason message ([82a587f](https://github.com/surgeapi/python-sdk/commit/82a587f96b1c6418e1245d2d3eeadbcf48a6966e))
* update mock server docs ([5e2e5af](https://github.com/surgeapi/python-sdk/commit/5e2e5af6e2968abcbea53d71a74cff647bfdd969))

## 0.11.0 (2026-02-12)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/surgeapi/python-sdk/compare/v0.10.0...v0.11.0)

### Features

* **api:** add campaign.status field ([6609a8e](https://github.com/surgeapi/python-sdk/commit/6609a8e9331eefb146feca8b7299abebad3f76e9))
* **api:** add get campaign endpoint ([3de865c](https://github.com/surgeapi/python-sdk/commit/3de865c2443720646edf06fbbd8184225aecd727))
* **api:** add recording.completed webhook ([fbf48ec](https://github.com/surgeapi/python-sdk/commit/fbf48ec7def9ede6ceed1ef25f9c80fb262c1f4d))
* **api:** add voicemail.received webhook ([08343a3](https://github.com/surgeapi/python-sdk/commit/08343a33073fa5c5b30036c8eae2b1704146ba5e))
* **api:** get recording file ([6f11bec](https://github.com/surgeapi/python-sdk/commit/6f11bece32534c3a59e85637809991e3eeb36064))


### Chores

* **internal:** bump dependencies ([2f2bce2](https://github.com/surgeapi/python-sdk/commit/2f2bce223c262d71580cd6aa4cba54c2f2a971c3))

## 0.10.0 (2026-02-04)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/surgeapi/python-sdk/compare/v0.9.0...v0.10.0)

### Features

* **api:** add list contacts endpoint ([366eada](https://github.com/surgeapi/python-sdk/commit/366eada13d0406378a14cb0dfd3806962e5ead4b))
* **api:** add list messages endpoint ([e98690f](https://github.com/surgeapi/python-sdk/commit/e98690fb2c7affd8fb9c79fd88d2c865dfb54d18))
* **api:** add list phone numbers endpoint ([bd92d8c](https://github.com/surgeapi/python-sdk/commit/bd92d8c3178afe49b6669d0843f4a3c937c901bc))
* **client:** add custom JSON encoder for extended type support ([7026006](https://github.com/surgeapi/python-sdk/commit/7026006a71d7be946ed0e8b2ae00ff3491fd3087))
* **sdks:** set up pagination ([ffea470](https://github.com/surgeapi/python-sdk/commit/ffea470f67051a338cbb366bb4b4da3c9da0c6f9))


### Bug Fixes

* **api:** make message body nullable ([6b675c3](https://github.com/surgeapi/python-sdk/commit/6b675c3b167b4668ac7f552caa5e7210bb206834))

## 0.9.0 (2026-01-26)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/surgeapi/python-sdk/compare/v0.8.0...v0.9.0)

### Features

* **api:** api update ([00a8111](https://github.com/surgeapi/python-sdk/commit/00a81116e3cb1e873eadd63118fab12c04ac3322))
* **api:** api update ([3fc4111](https://github.com/surgeapi/python-sdk/commit/3fc4111ba7585d625fa5c6983676bb48bff13db7))
* **api:** api update ([9c9a5c0](https://github.com/surgeapi/python-sdk/commit/9c9a5c05d32908d4555c114e5aff957992cd57a1))


### Chores

* **ci:** upgrade `actions/github-script` ([0cc4a16](https://github.com/surgeapi/python-sdk/commit/0cc4a16fbb1283014c5014b474e8de1e92a72dcc))

## 0.8.0 (2026-01-18)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/surgeapi/python-sdk/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([4a9859b](https://github.com/surgeapi/python-sdk/commit/4a9859b54793ebd612cd6a21b56c97b6ed409a06))

## 0.7.0 (2026-01-18)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/surgeapi/python-sdk/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([5ddec3e](https://github.com/surgeapi/python-sdk/commit/5ddec3e114ce0b8d027cbfd694bdf98b3e8594ad))


### Chores

* **internal:** update `actions/checkout` version ([962b119](https://github.com/surgeapi/python-sdk/commit/962b11979229dc82946389f638fd242495794391))

## 0.6.0 (2026-01-15)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/surgeapi/python-sdk/compare/v0.5.0...v0.6.0)

### Features

* **api:** add delete user endpoint ([621a07f](https://github.com/surgeapi/python-sdk/commit/621a07f73f9a342b51c9cdd37e5263b86514749e))
* **client:** add support for binary request streaming ([f0b5766](https://github.com/surgeapi/python-sdk/commit/f0b5766fbf7f2b695b62e7f74472a93895a14223))

## 0.5.0 (2026-01-09)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/surgeapi/python-sdk/compare/v0.4.0...v0.5.0)

### Features

* **api:** add archive account endpoint ([ac52910](https://github.com/surgeapi/python-sdk/commit/ac52910b127e1691a752d8a8b8555d0cc8b7d6c6))


### Bug Fixes

* use async_to_httpx_files in patch method ([ba4b8d7](https://github.com/surgeapi/python-sdk/commit/ba4b8d75e30520955e90b68bd1476e62f57e0aac))


### Chores

* **internal:** add `--fix` argument to lint script ([c47bbfb](https://github.com/surgeapi/python-sdk/commit/c47bbfb4de382eae8fef2424d737798671939f27))
* **internal:** codegen related update ([c5e779b](https://github.com/surgeapi/python-sdk/commit/c5e779bde9a46405b994dab6b201feb03aa4956b))

## 0.4.0 (2025-12-17)

Full Changelog: [v0.3.1...v0.4.0](https://github.com/surgeapi/python-sdk/compare/v0.3.1...v0.4.0)

### Features

* **api:** add retrieve message endpoint ([954d2d3](https://github.com/surgeapi/python-sdk/commit/954d2d3de777c40a5808d0f7876ec6e11b601b10))


### Bug Fixes

* compat with Python 3.14 ([340f1da](https://github.com/surgeapi/python-sdk/commit/340f1daa0b1024c2f45b71e66841302bd2cc9190))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([f657dfd](https://github.com/surgeapi/python-sdk/commit/f657dfda7eb8097cafea011a7f612122d0bd28b7))
* ensure streams are always closed ([a3d05db](https://github.com/surgeapi/python-sdk/commit/a3d05dbf55c77424e8b88803c4390c72d70a2894))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([7724409](https://github.com/surgeapi/python-sdk/commit/7724409c6eb510edf6da6ad5867a18ec32316bc4))


### Chores

* add missing docstrings ([15bbcc4](https://github.com/surgeapi/python-sdk/commit/15bbcc4e1152d504c1a900cf49295d2091eb4a24))
* add Python 3.14 classifier and testing ([1cfb2c6](https://github.com/surgeapi/python-sdk/commit/1cfb2c6ff172ebe9a1b8bc5f25da787d42174e15))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([7e24ec8](https://github.com/surgeapi/python-sdk/commit/7e24ec81a02c78d3c07ea2f39fc8b2f83cbb32bc))
* **docs:** use environment variables for authentication in code snippets ([ce7f16c](https://github.com/surgeapi/python-sdk/commit/ce7f16ce441087610dd314ee17c709fb9e86a19d))
* **internal:** add missing files argument to base client ([b42fa76](https://github.com/surgeapi/python-sdk/commit/b42fa7670217848526df4a3d69033f93fc295c04))
* **internal:** codegen related update ([7ae81f1](https://github.com/surgeapi/python-sdk/commit/7ae81f18f92f5088717d109461d1fa12207670cb))
* **internal:** codegen related update ([fd67466](https://github.com/surgeapi/python-sdk/commit/fd67466a3d1e41835071287fcd6448fa09549eb1))
* **internal:** codegen related update ([1049106](https://github.com/surgeapi/python-sdk/commit/10491067966bd0e3a02f3b678bea16d0871d1914))
* **internal:** codegen related update ([7d90209](https://github.com/surgeapi/python-sdk/commit/7d90209510715401244d34253ffd6892f944376f))
* **internal:** fix test definition ([66e3f20](https://github.com/surgeapi/python-sdk/commit/66e3f200599963abe5fe5cd8a89edfa52c8fd4ac))
* **internal:** grammar fix (it's -&gt; its) ([1693443](https://github.com/surgeapi/python-sdk/commit/16934439864c8eb0cb167d9daf5c7b01c26e9702))
* **package:** drop Python 3.8 support ([1548699](https://github.com/surgeapi/python-sdk/commit/1548699689894152c1b0fdb4435c608f96872dff))
* speedup initial import ([86798d7](https://github.com/surgeapi/python-sdk/commit/86798d76d735e1dde3c7977af63838013b6c3617))
* update lockfile ([39ab4f5](https://github.com/surgeapi/python-sdk/commit/39ab4f55d1a419924e252cdff2008c8b3f973a5d))

## 0.3.1 (2025-10-31)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/surgeapi/python-sdk/compare/v0.3.0...v0.3.1)

### Features

* **api:** create externally registered campaigns ([2aaae37](https://github.com/surgeapi/python-sdk/commit/2aaae3778862c64d85485e2eb9b9c6508a87606c))


### Bug Fixes

* **client:** close streams without requiring full consumption ([46da11c](https://github.com/surgeapi/python-sdk/commit/46da11c9f87b0bf9b20f93fa97ea1abca8389a5c))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([50983ab](https://github.com/surgeapi/python-sdk/commit/50983ab68d34871cea4ac5db3fc94a7da9373c6e))
* **internal/tests:** avoid race condition with implicit client cleanup ([1785037](https://github.com/surgeapi/python-sdk/commit/17850379f87317638de53bd04492db2e7f3d2532))
* **internal:** codegen related update ([e7eb248](https://github.com/surgeapi/python-sdk/commit/e7eb2485f250c6fe2108385a50c62cb56f547f73))
* **internal:** detect missing future annotations with ruff ([3e0ad24](https://github.com/surgeapi/python-sdk/commit/3e0ad247d55004c3dc572f7b1bc611d24d362431))


### Documentation

* **api:** add context around organization contacts ([fb0897c](https://github.com/surgeapi/python-sdk/commit/fb0897ce5361bc708db7d1bb9e96eba573bb3d97))

## 0.3.0 (2025-10-09)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/surgeapi/python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([6963cf8](https://github.com/surgeapi/python-sdk/commit/6963cf83818a22e4421272433ade940bb32959d8))
* **api:** api update ([2f3657d](https://github.com/surgeapi/python-sdk/commit/2f3657d8448c0f926b55aa646d060730500ad0e4))
* **api:** manual updates ([4f90c78](https://github.com/surgeapi/python-sdk/commit/4f90c78360f4622622a9f977a501f97db399453f))
* **api:** manual updates ([90f8f61](https://github.com/surgeapi/python-sdk/commit/90f8f61fe28690cdb2544d0885a21e9bf4df9e85))
* **types:** remove explicit params types ([49b0c02](https://github.com/surgeapi/python-sdk/commit/49b0c0262095a8df8ea9f0cf903edf52de816299))
* **types:** try removing account_update_params type ([837fd43](https://github.com/surgeapi/python-sdk/commit/837fd43cf29f97ab61d6a4e5becd30e1832c20a9))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([c7560f0](https://github.com/surgeapi/python-sdk/commit/c7560f05fe673690f1e6edd51c06427bd466a8cb))
* improve example values ([24fc93e](https://github.com/surgeapi/python-sdk/commit/24fc93ecf04cd848227327d876690c1ba1055828))
* **internal:** codegen related update ([803cc55](https://github.com/surgeapi/python-sdk/commit/803cc55c7e58649c00eef4abf416750cdb4d48af))
* **internal:** update pydantic dependency ([fc71fe4](https://github.com/surgeapi/python-sdk/commit/fc71fe4f7e7e807b6fd765bf8ec6f5bd133c73e8))
* **types:** change optional parameter type from NotGiven to Omit ([2d99575](https://github.com/surgeapi/python-sdk/commit/2d995752dc2f803d65cd82576caff490910e025b))

## 0.2.0 (2025-09-16)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/surgeapi/python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** add ruby and change python package name ([7c927af](https://github.com/surgeapi/python-sdk/commit/7c927af371870b176fe51805df1be9ac64544f8b))

## 0.1.0 (2025-09-12)

Full Changelog: [v0.0.1-alpha.0...v0.1.0](https://github.com/surgeapi/python-sdk/compare/v0.0.1-alpha.0...v0.1.0)

### Chores

* sync repo ([c5ee59c](https://github.com/surgeapi/python-sdk/commit/c5ee59c5bccf5590db15b9594fa4f2fd1f096cc8))
* update SDK settings ([096a068](https://github.com/surgeapi/python-sdk/commit/096a0685eed28af9d1ccb7251746cc0e0ae04630))
* update SDK settings ([2dbeb2c](https://github.com/surgeapi/python-sdk/commit/2dbeb2c2dcfdfaa5b909faf0701d0e664cf6b182))
