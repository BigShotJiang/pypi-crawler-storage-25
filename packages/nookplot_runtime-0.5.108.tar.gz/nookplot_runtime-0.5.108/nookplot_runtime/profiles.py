"""
Profile-aware credential loading for nookplot-runtime.

The SDK normally takes ``api_key`` and ``gateway_url`` at instantiation.
This helper is for developers who want the Python SDK to read from
``~/.nookplot/`` — the same directory @nookplot/cli and @nookplot/mcp
write to — so a user running multiple forged agents can point the SDK
at whichever scope is active in their shell.

Resolution order (mirrors the TypeScript helper):

1. Explicit ``name`` argument to :func:`load_profile`
2. ``NOOKPLOT_PROFILE`` env var
3. Sticky default from ``~/.nookplot/active-profile``
4. ``None`` (load default creds only, no scope)

Example — pick up whatever profile is active:

    from nookplot_runtime.profiles import load_profile
    from nookplot_runtime import NookplotRuntime

    creds = load_profile()
    if not creds:
        raise RuntimeError("No credentials — run `nookplot register` first")

    runtime = NookplotRuntime(
        api_key=creds["api_key"],
        gateway_url=creds["gateway_url"],
    )
    # If creds.scoped_agent_address is set, the developer forwards it
    # on per-call headers where the gateway honors it.

Example — multi-agent (two SDK instances in parallel):

    researcher = load_profile("jeffs-researcher")
    writer = load_profile("jeffs-writer")
    # Both share the creator's api_key; differ in scoped_agent_address.

Backward compat: developers who don't call this helper see zero impact.
The SDK's core API is unchanged.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional, TypedDict


class LoadedProfile(TypedDict, total=False):
    """Resolved credential bundle, with optional scope metadata."""

    api_key: str
    address: str
    private_key: str
    gateway_url: str
    scoped_agent_address: Optional[str]
    profile_name: Optional[str]
    display_name: Optional[str]


def _nookplot_dir() -> Path:
    # Resolved lazily (not cached at import) so tests can patch HOME
    # between calls without reload gymnastics.
    return Path.home() / ".nookplot"


def _credentials_path() -> Path:
    return _nookplot_dir() / "credentials.json"


def _profile_path(name: str) -> Path:
    return _nookplot_dir() / "profiles" / name / "profile.json"


def _active_profile_path() -> Path:
    return _nookplot_dir() / "active-profile"


def resolve_active_profile_name(explicit_name: Optional[str] = None) -> Optional[str]:
    """
    Return the profile name that WOULD be used by :func:`load_profile`
    given the current env + filesystem state.

    Exported for developers who want to inspect the resolution without
    loading credentials.
    """
    if explicit_name:
        return explicit_name
    env = os.environ.get("NOOKPLOT_PROFILE")
    if env:
        return env
    try:
        path = _active_profile_path()
        if path.exists():
            content = path.read_text(encoding="utf-8").strip()
            if content:
                return content
    except OSError:
        # Permissions error or similar — fall through.
        pass
    return None


def load_profile(name: Optional[str] = None) -> Optional[LoadedProfile]:
    """
    Load credentials + optional profile scope from ``~/.nookplot/``.

    Returns ``None`` when no ``credentials.json`` exists — surface a
    clear "run `nookplot register` first" message in that case.

    On invalid / missing profile data, falls back to creator-direct
    credentials without raising. This matches the fail-open pattern
    used by @nookplot/mcp so a stale NOOKPLOT_PROFILE env var in the
    shell doesn't break unrelated scripts.
    """
    # 1. Base creds — the creator's shared API key.
    creds_path = _credentials_path()
    if not creds_path.exists():
        return None
    try:
        raw = json.loads(creds_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    required = ("apiKey", "address", "privateKey", "gatewayUrl")
    if not all(isinstance(raw.get(k), str) and raw[k] for k in required):
        return None

    # 2. Gateway URL override via env (same convention as MCP + CLI).
    gateway_url = os.environ.get("NOOKPLOT_GATEWAY_URL") or raw["gatewayUrl"]

    base: LoadedProfile = {
        "api_key": raw["apiKey"],
        "address": raw["address"],
        "private_key": raw["privateKey"],
        "gateway_url": gateway_url,
        "display_name": raw.get("displayName"),
    }

    # 3. Resolve + merge profile scope.
    profile_name = resolve_active_profile_name(name)
    if not profile_name:
        return base

    prof_path = _profile_path(profile_name)
    if not prof_path.exists():
        # Stale profile reference — fall back to creator-direct.
        return base

    try:
        prof = json.loads(prof_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return base

    scope = prof.get("scopedAgentAddress")
    if not isinstance(scope, str) or not scope:
        # Malformed profile — fall back.
        return base

    return {
        **base,
        "scoped_agent_address": scope,
        "profile_name": profile_name,
    }


def list_profiles() -> list[dict[str, Any]]:
    """
    List all profiles registered on the local machine.

    Returns an empty list if ``~/.nookplot/profiles`` doesn't exist.
    Never raises — invalid profiles are silently skipped.
    """
    profiles_dir = _nookplot_dir() / "profiles"
    if not profiles_dir.exists():
        return []
    out: list[dict[str, Any]] = []
    try:
        for child in sorted(profiles_dir.iterdir()):
            if not child.is_dir():
                continue
            p_file = child / "profile.json"
            if not p_file.exists():
                continue
            try:
                data = json.loads(p_file.read_text(encoding="utf-8"))
                scope = data.get("scopedAgentAddress")
                if not isinstance(scope, str):
                    continue
                out.append({
                    "name": child.name,
                    "scoped_agent_address": scope,
                    "display_name": data.get("displayName"),
                    "hermes_profile": data.get("hermesProfile"),
                })
            except (json.JSONDecodeError, OSError):
                continue
    except OSError:
        return []
    return out
