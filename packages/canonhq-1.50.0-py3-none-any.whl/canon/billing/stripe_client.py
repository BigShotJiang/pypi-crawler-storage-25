"""Stripe API client wrapper."""

from __future__ import annotations

import logging

import stripe

from ..settings import Settings

logger = logging.getLogger(__name__)


class StripeClient:
    """Thin wrapper around the Stripe SDK."""

    def __init__(self, settings: Settings) -> None:
        if not settings.stripe_secret_key:
            raise ValueError("stripe_secret_key is required to initialize StripeClient")
        self._settings = settings
        # TODO: stripe.api_key is module-level global state. Fine for single-account
        # deployments, but must be refactored if multiple Stripe accounts are needed.
        stripe.api_key = settings.stripe_secret_key

    def create_checkout_session(
        self,
        *,
        customer_email: str | None = None,
        customer_id: str | None = None,
        price_id: str,
        quantity: int = 1,
        success_url: str,
        cancel_url: str,
        metadata: dict | None = None,
        trial_period_days: int | None = None,
    ) -> stripe.checkout.Session:
        params: dict = {
            "mode": "subscription",
            "line_items": [{"price": price_id, "quantity": quantity}],
            "success_url": success_url,
            "cancel_url": cancel_url,
            "automatic_tax": {"enabled": True},
            "tax_id_collection": {"enabled": True},
            "billing_address_collection": "required",
        }
        if customer_id:
            params["customer"] = customer_id
        elif customer_email:
            params["customer_email"] = customer_email
        sub_data: dict = {}
        if metadata:
            params["metadata"] = metadata
            sub_data["metadata"] = metadata
        if trial_period_days is not None:
            sub_data["trial_period_days"] = trial_period_days
            params["payment_method_collection"] = "if_required"
        if sub_data:
            params["subscription_data"] = sub_data

        return stripe.checkout.Session.create(**params)

    def create_portal_session(
        self,
        *,
        customer_id: str,
        return_url: str,
    ) -> stripe.billing_portal.Session:
        return stripe.billing_portal.Session.create(
            customer=customer_id,
            return_url=return_url,
        )

    def construct_webhook_event(
        self,
        payload: bytes,
        sig_header: str,
    ) -> stripe.Event:
        return stripe.Webhook.construct_event(
            payload,
            sig_header,
            self._settings.stripe_webhook_secret,
        )

    def get_price_id(self, plan: str, cycle: str) -> str:
        """Resolve Stripe Price ID from plan + billing cycle."""
        mapping = {
            ("starter", "monthly"): self._settings.stripe_starter_monthly_price_id,
            ("starter", "annual"): self._settings.stripe_starter_annual_price_id,
            ("pro", "monthly"): self._settings.stripe_pro_monthly_price_id,
            ("pro", "annual"): self._settings.stripe_pro_annual_price_id,
        }
        price_id = mapping.get((plan, cycle))
        if not price_id:
            raise ValueError(f"No Stripe Price configured for {plan}/{cycle}")
        return price_id

    def plan_for_price_id(self, price_id: str) -> tuple[str, str] | None:
        """Map a Stripe Price ID to (plan, billing_cycle), or None if unknown."""
        s = self._settings
        mapping = {
            s.stripe_starter_monthly_price_id: ("starter", "monthly"),
            s.stripe_starter_annual_price_id: ("starter", "annual"),
            s.stripe_pro_monthly_price_id: ("pro", "monthly"),
            s.stripe_pro_annual_price_id: ("pro", "annual"),
        }
        # Filter out empty-string keys from unconfigured price IDs
        return mapping.get(price_id) if price_id else None
