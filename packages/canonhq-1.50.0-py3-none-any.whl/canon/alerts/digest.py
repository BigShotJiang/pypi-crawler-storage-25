"""Weekly SRE digest data model and formatting."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class WeeklyDigest:
    total_errors_this_week: int
    total_errors_last_week: int
    top_errors: list[dict] = field(default_factory=list)
    new_errors_count: int = 0
    cron_success_rate: float = 100.0
    webhook_p95_ms: float = 0.0
    open_triage_issues: int = 0


def format_digest_message(digest: WeeklyDigest) -> str:
    """Format the weekly digest as a Slack-friendly markdown message."""
    lines = [
        "*Weekly SRE Digest*",
        "",
    ]

    # Error trend
    if digest.total_errors_last_week > 0:
        change_pct = (
            (digest.total_errors_this_week - digest.total_errors_last_week)
            / digest.total_errors_last_week
            * 100
        )
        trend = f"+{change_pct:.1f}%" if change_pct >= 0 else f"{change_pct:.1f}%"
        emoji = "\U0001f4c8" if change_pct > 0 else "\U0001f4c9"
        lines.append(f"{emoji} *Errors:* {digest.total_errors_this_week} ({trend} vs last week)")
    else:
        lines.append(f"*Errors:* {digest.total_errors_this_week} (trend: N/A)")

    lines.append(f"*New error patterns:* {digest.new_errors_count}")
    lines.append("")

    # Top errors
    if digest.top_errors:
        lines.append("*Top Errors:*")
        for i, err in enumerate(digest.top_errors[:5], 1):
            lines.append(f"  {i}. `{err['type']}: {err['message']}` ({err['count']}x)")
        lines.append("")

    # Cron health
    lines.append(f"*Cron success rate:* {digest.cron_success_rate:.1f}%")

    # Webhook latency
    if digest.webhook_p95_ms > 0:
        lines.append(f"*Webhook p95 latency:* {digest.webhook_p95_ms:.0f}ms")

    # Open triage issues
    if digest.open_triage_issues > 0:
        lines.append(f"*Open auto-triaged issues:* {digest.open_triage_issues}")

    return "\n".join(lines)
