"""Data models for SRE alert messages."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class AlertSeverity(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @property
    def emoji(self) -> str:
        return {
            AlertSeverity.LOW: "\U0001f535",
            AlertSeverity.MEDIUM: "\U0001f7e1",
            AlertSeverity.HIGH: "\U0001f7e0",
            AlertSeverity.CRITICAL: "\U0001f534",
        }[self]

    @property
    def color(self) -> str:
        return {
            AlertSeverity.LOW: "#3498db",
            AlertSeverity.MEDIUM: "#f1c40f",
            AlertSeverity.HIGH: "#e67e22",
            AlertSeverity.CRITICAL: "#e74c3c",
        }[self]


@dataclass
class AlertMessage:
    severity: AlertSeverity
    title: str
    summary: str
    endpoint: str | None = None
    time_window: str | None = None
    posthog_url: str | None = None
    spec_link: str | None = None

    def to_slack_blocks(self) -> list[dict]:
        blocks: list[dict] = []
        blocks.append(
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"{self.severity.emoji} *{self.title}*"},
            }
        )
        detail_parts = [self.summary]
        if self.endpoint:
            detail_parts.append(f"*Endpoint:* `{self.endpoint}`")
        if self.time_window:
            detail_parts.append(f"*Window:* {self.time_window}")
        blocks.append(
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": "\n".join(detail_parts)},
            }
        )
        links: list[str] = []
        if self.posthog_url:
            links.append(f"<{self.posthog_url}|View in PostHog>")
        if self.spec_link:
            links.append(f"<{self.spec_link}|Related Spec>")
        if links:
            blocks.append(
                {
                    "type": "context",
                    "elements": [{"type": "mrkdwn", "text": " | ".join(links)}],
                }
            )
        return blocks
