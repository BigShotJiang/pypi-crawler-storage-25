"""Slack incoming webhook delivery for SRE alerts."""

from __future__ import annotations

import logging

import httpx

from .models import AlertMessage

logger = logging.getLogger(__name__)


class SlackAlerter:
    """Posts alert messages to a Slack incoming webhook.

    Reuses a single httpx.AsyncClient for the lifetime of the alerter,
    following the same pattern as GitHubClient.
    """

    def __init__(self, webhook_url: str) -> None:
        self._webhook_url = webhook_url
        self._http: httpx.AsyncClient | None = (
            httpx.AsyncClient(timeout=10.0) if webhook_url else None
        )

    @property
    def enabled(self) -> bool:
        return bool(self._webhook_url)

    async def send(self, alert: AlertMessage) -> None:
        """Post a structured alert to Slack. No-op when disabled.

        Swallows delivery errors so real-time alerting never crashes
        the request handler.
        """
        if not self.enabled:
            return
        payload = {"blocks": alert.to_slack_blocks()}
        try:
            await self._post(payload)
        except Exception:
            logger.error("Failed to deliver Slack alert", exc_info=True)
            return
        # analytics tracking is internally guarded
        from canon import analytics

        analytics.track(
            "sre_alert_fired",
            properties={
                "alert_type": alert.title,
                "severity": str(alert.severity),
            },
        )

    async def send_text(self, text: str) -> None:
        """Post a plain text message to Slack. No-op when disabled.

        Raises on delivery failure so callers (e.g. cron jobs) can
        detect and report unsuccessful sends.
        """
        if not self.enabled:
            return
        await self._post({"text": text})

    async def _post(self, payload: dict) -> None:
        """Low-level POST to webhook. Raises on HTTP errors."""
        if self._http is None:
            return
        resp = await self._http.post(self._webhook_url, json=payload)
        resp.raise_for_status()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._http is not None:
            await self._http.aclose()
            self._http = None
