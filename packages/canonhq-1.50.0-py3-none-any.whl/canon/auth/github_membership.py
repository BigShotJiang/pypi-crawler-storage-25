"""GitHub org membership lookup for login-time org resolution.

When a user authenticates via Auth0 with a GitHub social connection, their
Auth0 ID token includes a custom claim with their GitHub access token.  This
module uses that token to query the GitHub API for the user's org memberships
and cross-references them against Canon's installation registry to determine
which installed org(s) the user belongs to.

This is best-effort: all errors are caught and result in an empty list,
never blocking login.
"""

from __future__ import annotations

import logging

import httpx

logger = logging.getLogger(__name__)

_GITHUB_API = "https://api.github.com"


async def fetch_github_user_orgs(github_token: str) -> list[str]:
    """Fetch the authenticated user's GitHub org memberships.

    Returns a list of org login names (lowercase).  Returns ``[]`` on any
    error (network, auth, rate-limit) so callers never need to handle
    exceptions.
    """
    if not github_token:
        return []

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(
                f"{_GITHUB_API}/user/orgs",
                headers={
                    "Authorization": f"Bearer {github_token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                params={"per_page": 100},
            )
            if resp.status_code != 200:
                logger.warning(
                    "GitHub /user/orgs returned %d — skipping membership check",
                    resp.status_code,
                )
                return []

            orgs = resp.json()
            return [
                org["login"].lower() for org in orgs if isinstance(org, dict) and org.get("login")
            ]
    except Exception:
        logger.warning("GitHub org membership lookup failed", exc_info=True)
        return []


async def resolve_org_from_github(github_token: str, registry) -> list[str]:
    """Cross-reference the user's GitHub orgs with installed Canon orgs.

    Returns a list of org logins that are both:
    1. GitHub orgs the user is a member of
    2. Orgs with an active Canon installation in the registry

    Returns ``[]`` if no matches or on any error.
    """
    if not github_token or registry is None:
        return []

    github_orgs = await fetch_github_user_orgs(github_token)
    if not github_orgs:
        return []

    try:
        installed_orgs = await registry.list_orgs()
    except Exception:
        logger.warning("Failed to list installed orgs from registry", exc_info=True)
        return []

    if not installed_orgs:
        return []

    installed_lower = {org.lower(): org for org in installed_orgs}
    return [installed_lower[gh_org] for gh_org in github_orgs if gh_org in installed_lower]
