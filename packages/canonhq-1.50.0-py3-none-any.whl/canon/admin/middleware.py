"""Admin middleware — FastAPI dependency that gates super-admin routes."""

from __future__ import annotations

from fastapi import Depends, HTTPException

from canon.auth.deps import get_current_user
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission


async def require_super_admin(
    user: CurrentUser = Depends(get_current_user),
) -> CurrentUser:
    """FastAPI dependency that enforces PLATFORM_MANAGE permission.

    Chains on :func:`~canon.auth.deps.get_current_user` to resolve the
    caller's identity from session, API key, or JWT, then checks for the
    ``PLATFORM_MANAGE`` permission.

    - **404** if the user is anonymous — avoids revealing that admin
      routes exist at all.
    - **403** if the user is authenticated but lacks ``PLATFORM_MANAGE``.
    """
    if user.is_anonymous:
        raise HTTPException(status_code=404)
    if not user.has_permission(Permission.PLATFORM_MANAGE):
        raise HTTPException(status_code=403, detail="Insufficient permissions")
    return user
