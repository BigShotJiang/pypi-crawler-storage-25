"""AdminConfig — deployment-mode-aware feature gating for super-admin UI."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from canon.settings import Settings

DeploymentMode = Literal["cloud", "self_hosted", "development"]


class AdminFeatures(BaseModel):
    billing: bool
    cross_org: bool
    impersonation: bool


class AdminConfig(BaseModel):
    mode: DeploymentMode
    features: AdminFeatures


def get_admin_config(settings: Settings) -> AdminConfig:
    """Build an AdminConfig from the current Settings.

    Cloud mode enables billing, cross-org queries, and impersonation.
    Self-hosted and development modes disable all cloud-only features.
    """
    is_cloud = settings.deployment_mode == "cloud"
    return AdminConfig(
        mode=settings.deployment_mode,
        features=AdminFeatures(
            billing=is_cloud,
            cross_org=is_cloud,
            impersonation=is_cloud,
        ),
    )
