"""Canon platform admin module."""
