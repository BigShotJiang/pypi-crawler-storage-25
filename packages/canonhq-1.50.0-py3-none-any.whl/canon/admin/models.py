"""Pydantic response models for the super-admin API."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, model_validator


class AuditEventResponse(BaseModel):
    id: str = ""
    event_type: str = ""
    resource_type: str = ""
    resource_id: str = ""
    actor_id: int | None = None
    org: str | None = None
    detail: dict[str, Any] | None = None
    ip_address: str | None = None
    created_at: datetime | None = None


class KPIStats(BaseModel):
    org_count: int = 0
    user_count: int = 0
    spec_count: int = 0
    avg_coverage_pct: float = 0.0


class OrgSummary(BaseModel):
    login: str = ""
    installation_id: str | None = None
    user_count: int = 0
    created_at: datetime | None = None
    status: str = "active"
    display_name: str = ""  # from Auth0
    member_count: int | None = None  # from Auth0
    primary_contact_email: str | None = None  # from organizations_meta
    primary_contact_name: str | None = None  # from organizations_meta
    support_notes: str | None = None  # from organizations_meta
    oidc_org_id: str | None = None  # from gh_installations


class OrgMetadataUpdate(BaseModel):
    """Fields accepted by PATCH /api/admin/orgs/{org}.

    All fields are optional; omitted fields are left unchanged. An empty
    string clears the field (except display_name, which routes to Auth0).
    """

    display_name: str | None = None
    primary_contact_email: str | None = None
    primary_contact_name: str | None = None
    support_notes: str | None = None


class UserSummary(BaseModel):
    id: int = 0
    login: str = ""
    email: str = ""
    role: str = ""
    status: str = "active"
    org_login: str = ""
    created_at: datetime | None = None
    last_login: str | None = None  # from Auth0
    login_count: int | None = None  # from Auth0
    email_verified: bool | None = None  # from Auth0
    picture: str | None = None  # from Auth0
    identities: list[dict] | None = None  # from Auth0


class HealthSubsystem(BaseModel):
    name: str
    healthy: bool
    detail: str = ""


class DashboardResponse(BaseModel):
    kpis: KPIStats = KPIStats()
    health: list[HealthSubsystem] = []
    recent_events: list[AuditEventResponse] = []


class RoleUpdate(BaseModel):
    role: Literal["viewer", "editor", "admin", "super_admin"]


class UserDeleteConfirm(BaseModel):
    """Body for DELETE /api/admin/users/{id} — typed confirmation gating."""

    confirm: str


class UserOrgMembershipAdd(BaseModel):
    """Body for POST /api/admin/users/{id}/orgs — add user to an org.

    Accepts either ``org_login`` (Canon side, looked up via gh_installations)
    or ``oidc_org_id`` (Auth0 side) directly. At least one must be set.
    """

    org_login: str | None = None
    oidc_org_id: str | None = None

    @model_validator(mode="after")
    def _require_at_least_one(self) -> UserOrgMembershipAdd:
        if not self.org_login and not self.oidc_org_id:
            raise ValueError("At least one of org_login or oidc_org_id must be provided")
        return self


class UserOrgMembership(BaseModel):
    """A single row in the user's Auth0 org membership list."""

    oidc_org_id: str
    name: str
    display_name: str = ""
    org_login: str | None = None  # mapped back to Canon if a match exists


class SubscriptionSummary(BaseModel):
    org_login: str = ""
    plan: str = ""
    status: str = ""
    seat_count: int = 0
    billing_cycle: str = ""
    stripe_customer_id: str | None = None
    current_period_start: datetime | None = None
    current_period_end: datetime | None = None


class IntegrationSummary(BaseModel):
    org_login: str = ""
    provider: str = ""
    display_name: str = ""
    status: str = ""
    connected_by: str | None = None
    connected_at: datetime | None = None
