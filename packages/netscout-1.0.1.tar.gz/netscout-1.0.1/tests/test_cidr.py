"""Tests for cidr — CIDR parsing, expansion, dedup."""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import ipaddress
import pytest

from cidr import (
    check_host_count,
    deduplicate_and_merge,
    expand_hosts,
    parse_targets,
)


class TestParseTargets:
    def test_single_cidr(self):
        specs, errors = parse_targets(["10.10.10.0/24"])
        assert not errors
        assert len(specs) == 1
        assert specs[0].networks[0] == ipaddress.IPv4Network("10.10.10.0/24")

    def test_single_ip(self):
        specs, errors = parse_targets(["192.168.1.5"])
        assert not errors
        assert specs[0].individual_ips == [ipaddress.IPv4Address("192.168.1.5")]

    def test_short_range(self):
        specs, errors = parse_targets(["10.10.10.1-5"])
        assert not errors
        ips = specs[0].individual_ips
        assert len(ips) == 5
        assert ips[0] == ipaddress.IPv4Address("10.10.10.1")
        assert ips[-1] == ipaddress.IPv4Address("10.10.10.5")

    def test_full_range(self):
        specs, errors = parse_targets(["10.10.10.1-10.10.10.3"])
        assert not errors
        assert len(specs[0].individual_ips) == 3

    def test_comma_separated(self):
        specs, errors = parse_targets(["10.10.10.0/24, 172.20.0.0/16"])
        assert not errors
        assert len(specs) == 2

    def test_invalid_input(self):
        specs, errors = parse_targets(["not-a-valid-thing-at-all-xyz123"])
        assert len(errors) == 1

    def test_multiple_inputs(self):
        specs, errors = parse_targets(["10.10.10.0/24", "192.168.1.5"])
        assert not errors
        assert len(specs) == 2


class TestDeduplicateAndMerge:
    def test_overlapping_cidrs(self):
        specs, _ = parse_targets(["10.10.10.0/24", "10.10.10.0/25"])
        networks, total = deduplicate_and_merge(specs)
        assert len(networks) == 1
        assert networks[0] == ipaddress.IPv4Network("10.10.10.0/24")

    def test_adjacent_singles(self):
        specs, _ = parse_targets(["10.10.10.1", "10.10.10.2"])
        networks, total = deduplicate_and_merge(specs)
        assert total == 2

    def test_total_count(self):
        specs, _ = parse_targets(["10.10.10.0/24"])
        _, total = deduplicate_and_merge(specs)
        assert total == 256


class TestExpandHosts:
    def test_expand_slash24(self):
        nets = [ipaddress.IPv4Network("10.10.10.0/24")]
        hosts = expand_hosts(nets)
        assert len(hosts) == 254

    def test_expand_slash32(self):
        nets = [ipaddress.IPv4Network("10.10.10.5/32")]
        hosts = expand_hosts(nets)
        assert len(hosts) == 1
        assert hosts[0] == ipaddress.IPv4Address("10.10.10.5")


class TestCheckHostCount:
    def test_under_limit(self):
        assert check_host_count(1000, force=False) is True

    def test_over_limit_no_force(self):
        with pytest.raises(SystemExit):
            check_host_count(100_000, force=False)

    def test_over_limit_with_force(self):
        assert check_host_count(100_000, force=True) is True
