"""Tests for exporter — multi-format export."""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import json
from pathlib import Path

import pytest

from exporter import detect_format, export_results, export_to_string
from scanner import HostResult, PortInfo


def _sample_hosts() -> dict[str, HostResult]:
    hr1 = HostResult(
        ip="10.10.10.5", alive=True, method="nmap-sn",
        hostname="target.local", os_guess="Linux/Unix", rtt_ms=1.5,
        open_ports=[22, 80],
        port_details={
            22: PortInfo(port=22, state="open", service="ssh", banner="SSH-2.0-OpenSSH"),
            80: PortInfo(port=80, state="open", service="http", banner=""),
        },
    )
    hr2 = HostResult(ip="10.10.10.6", alive=False, method="nmap-sn")
    return {"10.10.10.5": hr1, "10.10.10.6": hr2}


class TestDetectFormat:
    def test_json(self): assert detect_format("output.json") == ".json"
    def test_csv(self): assert detect_format("output.csv") == ".csv"
    def test_txt(self): assert detect_format("output.txt") == ".txt"
    def test_gnmap(self): assert detect_format("output.gnmap") == ".gnmap"
    def test_unsupported(self):
        with pytest.raises(ValueError): detect_format("output.xml")


class TestExportToString:
    def test_json_output(self):
        data = json.loads(export_to_string(_sample_hosts(), ".json"))
        assert data["alive_hosts"] == 1
        assert data["results"][0]["ip"] == "10.10.10.5"

    def test_csv_output(self):
        lines = export_to_string(_sample_hosts(), ".csv").strip().split("\n")
        assert len(lines) == 2
        assert "10.10.10.5" in lines[1]

    def test_txt_output(self):
        result = export_to_string(_sample_hosts(), ".txt")
        assert "10.10.10.5" in result and "target.local" in result

    def test_gnmap_output(self):
        result = export_to_string(_sample_hosts(), ".gnmap")
        assert "10.10.10.5" in result and "22/open/tcp" in result


class TestExportResults:
    def test_file_creation(self, tmp_path):
        out = str(tmp_path / "results.json")
        export_results(_sample_hosts(), out)
        assert Path(out).exists()
        data = json.loads(Path(out).read_text())
        assert data["alive_hosts"] == 1
