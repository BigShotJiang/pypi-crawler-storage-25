"""
Export scan results to multiple formats: txt, json, csv, gnmap.

Format is auto-detected from the output file extension.
"""

from __future__ import annotations

import csv
import json
import io
from pathlib import Path
from typing import TextIO

from scanner import HostResult

SUPPORTED_FORMATS = {".txt", ".json", ".csv", ".gnmap"}


def detect_format(filepath: str) -> str:
    ext = Path(filepath).suffix.lower()
    if ext not in SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported output format '{ext}'. Supported: {', '.join(sorted(SUPPORTED_FORMATS))}")
    return ext


def _export_txt(hosts: dict[str, HostResult], fp: TextIO) -> None:
    fp.write("=" * 72 + "\n  NetScout Scan Results\n" + "=" * 72 + "\n\n")
    alive = sorted((hr for hr in hosts.values() if hr.alive), key=lambda h: tuple(int(o) for o in h.ip.split(".")))
    fp.write(f"  Live hosts: {len(alive)} / {len(hosts)}\n\n")
    for hr in alive:
        fp.write(f"  Host: {hr.ip}\n")
        if hr.hostname: fp.write(f"    Hostname:  {hr.hostname}\n")
        if hr.os_guess: fp.write(f"    OS Guess:  {hr.os_guess}\n")
        if hr.mac:
            fp.write(f"    MAC:       {hr.mac}")
            if hr.vendor: fp.write(f" ({hr.vendor})")
            fp.write("\n")
        if hr.rtt_ms: fp.write(f"    RTT:       {hr.rtt_ms:.1f} ms\n")
        if hr.open_ports:
            fp.write("    Ports:\n")
            for port in hr.open_ports:
                pi = hr.port_details.get(port)
                if pi:
                    line = f"      {port:<6} {pi.state:<10} {pi.service:<16}"
                    if pi.banner: line += f" {pi.banner}"
                    fp.write(line.rstrip() + "\n")
                else:
                    fp.write(f"      {port:<6} open\n")
        fp.write("\n")
    fp.write("=" * 72 + "\n")


def _export_json(hosts: dict[str, HostResult], fp: TextIO) -> None:
    data = {"total_hosts": len(hosts), "alive_hosts": sum(1 for hr in hosts.values() if hr.alive), "results": []}
    alive = sorted((hr for hr in hosts.values() if hr.alive), key=lambda h: tuple(int(o) for o in h.ip.split(".")))
    for hr in alive:
        entry: dict = {"ip": hr.ip, "alive": hr.alive, "method": hr.method, "hostname": hr.hostname,
                       "os_guess": hr.os_guess, "mac": hr.mac, "vendor": hr.vendor, "rtt_ms": hr.rtt_ms,
                       "open_ports": hr.open_ports, "ports": {}}
        for port, pi in hr.port_details.items():
            entry["ports"][str(port)] = {"state": pi.state, "service": pi.service, "banner": pi.banner}
        data["results"].append(entry)
    json.dump(data, fp, indent=2)
    fp.write("\n")


def _export_csv(hosts: dict[str, HostResult], fp: TextIO) -> None:
    writer = csv.writer(fp)
    writer.writerow(["IP", "Alive", "Hostname", "OS Guess", "MAC", "Vendor", "RTT (ms)", "Open Ports", "Services", "Banners"])
    alive = sorted((hr for hr in hosts.values() if hr.alive), key=lambda h: tuple(int(o) for o in h.ip.split(".")))
    for hr in alive:
        ports_str = " ".join(str(p) for p in hr.open_ports)
        services, banners = [], []
        for port in hr.open_ports:
            pi = hr.port_details.get(port)
            if pi:
                services.append(f"{port}/{pi.service}" if pi.service else str(port))
                if pi.banner: banners.append(f"{port}:{pi.banner}")
        writer.writerow([hr.ip, hr.alive, hr.hostname, hr.os_guess, hr.mac, hr.vendor,
                         f"{hr.rtt_ms:.1f}", ports_str, " | ".join(services), " | ".join(banners)])


def _export_gnmap(hosts: dict[str, HostResult], fp: TextIO) -> None:
    fp.write("# NetScout greppable output\n")
    alive = sorted((hr for hr in hosts.values() if hr.alive), key=lambda h: tuple(int(o) for o in h.ip.split(".")))
    for hr in alive:
        parts = [f"Host: {hr.ip}"]
        if hr.hostname: parts.append(f"({hr.hostname})")
        parts.append("Status: Up")
        if hr.open_ports:
            port_strs = []
            for port in hr.open_ports:
                pi = hr.port_details.get(port)
                svc = pi.service if pi else ""
                port_strs.append(f"{port}/open/tcp//{svc}//")
            parts.append("Ports: " + ", ".join(port_strs))
        if hr.os_guess: parts.append(f"OS: {hr.os_guess}")
        fp.write("\t".join(parts) + "\n")


def export_results(hosts: dict[str, HostResult], filepath: str) -> None:
    fmt = detect_format(filepath)
    exporters = {".txt": _export_txt, ".json": _export_json, ".csv": _export_csv, ".gnmap": _export_gnmap}
    with open(filepath, "w", newline="", encoding="utf-8") as fp:
        exporters[fmt](hosts, fp)


def export_to_string(hosts: dict[str, HostResult], fmt: str) -> str:
    buf = io.StringIO()
    exporters = {".txt": _export_txt, ".json": _export_json, ".csv": _export_csv, ".gnmap": _export_gnmap}
    if fmt not in exporters: raise ValueError(f"Unsupported format: {fmt}")
    exporters[fmt](hosts, buf)
    return buf.getvalue()
