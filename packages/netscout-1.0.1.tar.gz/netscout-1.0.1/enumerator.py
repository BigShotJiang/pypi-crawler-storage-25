"""
Enumeration module — port checking, OS fingerprinting, service detection,
banner grabbing, and nmap script scanning.

All nmap calls:
  - Use -oX - (XML to stdout)
  - Batch ALL live hosts in ONE call
  - Run via asyncio.create_subprocess_exec
  - Parse with xml.etree.ElementTree
  - Degrade gracefully if nmap is absent
"""

from __future__ import annotations

import asyncio
import xml.etree.ElementTree as ET
from typing import Callable

from scanner import (
    HostResult,
    PortInfo,
    WELL_KNOWN_SERVICES,
    guess_os_from_ttl,
    nmap_available,
)
import resolver

# ---------------------------------------------------------------------------
# Port scanning (async TCP connect — zero nmap dependency)
# ---------------------------------------------------------------------------


async def check_ports(
    hosts: dict[str, HostResult],
    ports: list[int],
    *,
    timeout: float = 0.5,
    threads: int = 150,
    grab_banner: bool = True,
    callback: Callable[[str, int, str], None] | None = None,
) -> None:
    """
    For each live host, async-connect to each port and update HostResult in place.

    One connection attempt per port per host — no retries.
    """
    sem = asyncio.Semaphore(threads)
    live = {ip: hr for ip, hr in hosts.items() if hr.alive}

    async def _probe(ip: str, port: int) -> tuple[str, PortInfo]:
        pi = PortInfo(
            port=port,
            service=WELL_KNOWN_SERVICES.get(port, ""),
        )
        async with sem:
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(ip, port),
                    timeout=timeout,
                )
                pi.state = "open"

                # Banner grab — read first 256 bytes
                if grab_banner:
                    try:
                        data = await asyncio.wait_for(
                            reader.read(256), timeout=0.5
                        )
                        pi.banner = data.decode(errors="replace").strip().split("\n")[0][:256]
                    except (asyncio.TimeoutError, OSError):
                        pass

                writer.close()
                await writer.wait_closed()

            except (asyncio.TimeoutError, OSError):
                pi.state = "filtered"
            except ConnectionRefusedError:
                pi.state = "closed"

        if callback and pi.state == "open":
            callback(ip, port, pi.service)
        return ip, pi

    tasks = [_probe(ip, port) for ip in live for port in ports]
    results = await asyncio.gather(*tasks)

    for ip, pi in results:
        hosts[ip].port_details[pi.port] = pi
        if pi.state == "open" and pi.port not in hosts[ip].open_ports:
            hosts[ip].open_ports.append(pi.port)

    # Sort open_ports
    for hr in hosts.values():
        hr.open_ports.sort()


# ---------------------------------------------------------------------------
# Reverse DNS for live hosts
# ---------------------------------------------------------------------------


async def resolve_hostnames(
    hosts: dict[str, HostResult],
    concurrency: int = 150,
) -> None:
    """Batch reverse-DNS for live hosts that don't already have a hostname."""
    ips_to_resolve = [
        ip for ip, hr in hosts.items() if hr.alive and not hr.hostname
    ]
    if not ips_to_resolve:
        return
    mapping = await resolver.batch_reverse(ips_to_resolve, concurrency=concurrency)
    for ip, hostname in mapping.items():
        if hostname:
            hosts[ip].hostname = hostname


# ---------------------------------------------------------------------------
# nmap XML helpers
# ---------------------------------------------------------------------------


def _parse_nmap_xml(xml_bytes: bytes) -> dict[str, dict]:
    """
    Generic nmap XML parser → dict[ip, {...parsed data...}].

    Extracts ports, OS matches, service info, and script output.
    """
    results: dict[str, dict] = {}
    try:
        root = ET.fromstring(xml_bytes.decode(errors="replace"))
    except ET.ParseError:
        return results

    for host_el in root.findall("host"):
        addr_el = host_el.find("address[@addrtype='ipv4']")
        if addr_el is None:
            continue
        ip = addr_el.get("addr", "")
        data: dict = {"ports": {}, "os": "", "scripts": {}}

        # Ports
        ports_el = host_el.find("ports")
        if ports_el is not None:
            for port_el in ports_el.findall("port"):
                portid = int(port_el.get("portid", "0"))
                state_el = port_el.find("state")
                service_el = port_el.find("service")
                sinfo: dict = {
                    "state": state_el.get("state", "closed") if state_el is not None else "closed",
                    "service": "",
                    "version": "",
                    "banner": "",
                }
                if service_el is not None:
                    sinfo["service"] = service_el.get("name", "")
                    product = service_el.get("product", "")
                    version = service_el.get("version", "")
                    sinfo["version"] = f"{product} {version}".strip()
                # Script output on port
                for script_el in port_el.findall("script"):
                    sid = script_el.get("id", "")
                    soutput = script_el.get("output", "")
                    sinfo.setdefault("scripts", {})[sid] = soutput
                data["ports"][portid] = sinfo

        # OS
        os_el = host_el.find("os")
        if os_el is not None:
            osmatch = os_el.find("osmatch")
            if osmatch is not None:
                data["os"] = osmatch.get("name", "")

        # Host scripts
        hostscript_el = host_el.find("hostscript")
        if hostscript_el is not None:
            for script_el in hostscript_el.findall("script"):
                sid = script_el.get("id", "")
                soutput = script_el.get("output", "")
                data["scripts"][sid] = soutput

        results[ip] = data
    return results


async def _run_nmap(args: list[str]) -> bytes:
    """Execute nmap with given args, return stdout bytes."""
    cmd = ["nmap", "-oX", "-", *args]
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return stdout


# ---------------------------------------------------------------------------
# OS fingerprinting: --os
# ---------------------------------------------------------------------------


async def os_fingerprint(
    hosts: dict[str, HostResult],
    deep: bool = False,
    fast: bool = False,
) -> None:
    """
    OS guessing.

    Default: TTL-based (zero extra packets).
    With --deep: nmap -O on all live hosts in one call.
    """
    live_ips = [ip for ip, hr in hosts.items() if hr.alive]

    # Phase 1: TTL heuristic (always, zero cost)
    for ip in live_ips:
        hr = hosts[ip]
        if hr.ttl and not hr.os_guess:
            hr.os_guess = guess_os_from_ttl(hr.ttl)

    # Phase 2: Deep nmap -O (only with --deep)
    if deep and nmap_available() and live_ips:
        timing = "-T5" if fast else "-T4"
        args = ["-O", "--osscan-guess", "--max-os-tries", "1", timing, *live_ips]
        xml = await _run_nmap(args)
        parsed = _parse_nmap_xml(xml)
        for ip, data in parsed.items():
            if ip in hosts and data.get("os"):
                hosts[ip].os_guess = data["os"]


# ---------------------------------------------------------------------------
# Service version detection: --services
# ---------------------------------------------------------------------------


async def service_version(
    hosts: dict[str, HostResult],
    ports: list[int] | None = None,
    fast: bool = False,
) -> None:
    """
    nmap -sV --version-intensity 0 on live hosts for specified ports.
    Updates HostResult.port_details with service + version info.
    """
    if not nmap_available():
        return

    live_ips = [ip for ip, hr in hosts.items() if hr.alive]
    if not live_ips:
        return

    # Build port string
    if ports:
        port_str = ",".join(str(p) for p in ports)
    else:
        # Use all discovered open ports
        all_ports: set[int] = set()
        for ip in live_ips:
            all_ports.update(hosts[ip].open_ports)
        if not all_ports:
            return
        port_str = ",".join(str(p) for p in sorted(all_ports))

    timing = "-T5" if fast else "-T4"
    args = ["-sV", "--version-intensity", "0", timing, "-p", port_str, *live_ips]
    xml = await _run_nmap(args)
    parsed = _parse_nmap_xml(xml)

    for ip, data in parsed.items():
        if ip not in hosts:
            continue
        for portid, pinfo in data.get("ports", {}).items():
            if portid in hosts[ip].port_details:
                hosts[ip].port_details[portid].service = pinfo.get("service", "")
                version = pinfo.get("version", "")
                if version:
                    hosts[ip].port_details[portid].banner = version
            else:
                pi = PortInfo(
                    port=portid,
                    state=pinfo.get("state", "closed"),
                    service=pinfo.get("service", ""),
                    banner=pinfo.get("version", ""),
                )
                hosts[ip].port_details[portid] = pi
                if pi.state == "open" and portid not in hosts[ip].open_ports:
                    hosts[ip].open_ports.append(portid)
        hosts[ip].open_ports.sort()


# ---------------------------------------------------------------------------
# Script scan: --scripts
# ---------------------------------------------------------------------------


async def script_scan(
    hosts: dict[str, HostResult],
    ports: list[int] | None = None,
    fast: bool = False,
) -> dict[str, dict[str, str]]:
    """
    nmap --script=default on live hosts.

    Returns dict[ip, dict[script_id, output]].
    """
    if not nmap_available():
        return {}

    live_ips = [ip for ip, hr in hosts.items() if hr.alive]
    if not live_ips:
        return {}

    timing = "-T5" if fast else "-T4"
    args = ["--script=default", timing]
    if ports:
        args += ["-p", ",".join(str(p) for p in ports)]
    args += live_ips

    xml = await _run_nmap(args)
    parsed = _parse_nmap_xml(xml)

    all_scripts: dict[str, dict[str, str]] = {}
    for ip, data in parsed.items():
        scripts = data.get("scripts", {})
        # Also grab per-port scripts
        for portid, pinfo in data.get("ports", {}).items():
            for sid, sout in pinfo.get("scripts", {}).items():
                scripts[f"{sid}:{portid}"] = sout
        if scripts:
            all_scripts[ip] = scripts
    return all_scripts


# ---------------------------------------------------------------------------
# Deep scan: --deep  (nmap -O -sV on live hosts)
# ---------------------------------------------------------------------------


async def deep_scan(
    hosts: dict[str, HostResult],
    ports: list[int] | None = None,
    fast: bool = False,
) -> None:
    """Full nmap -O -sV on live hosts in a single call."""
    if not nmap_available():
        return

    live_ips = [ip for ip, hr in hosts.items() if hr.alive]
    if not live_ips:
        return

    timing = "-T5" if fast else "-T4"
    args = ["-O", "-sV", "--osscan-guess", "--max-os-tries", "1",
            "--version-intensity", "2", timing]
    if ports:
        args += ["-p", ",".join(str(p) for p in ports)]
    args += live_ips

    xml = await _run_nmap(args)
    parsed = _parse_nmap_xml(xml)

    for ip, data in parsed.items():
        if ip not in hosts:
            continue
        if data.get("os"):
            hosts[ip].os_guess = data["os"]
        for portid, pinfo in data.get("ports", {}).items():
            pi = PortInfo(
                port=portid,
                state=pinfo.get("state", "closed"),
                service=pinfo.get("service", ""),
                banner=pinfo.get("version", ""),
            )
            hosts[ip].port_details[portid] = pi
            if pi.state == "open" and portid not in hosts[ip].open_ports:
                hosts[ip].open_ports.append(portid)
        hosts[ip].open_ports.sort()


# ---------------------------------------------------------------------------
# Quick enum combo: --enum (TTL OS + banner + DNS, zero extra roundtrips)
# ---------------------------------------------------------------------------


async def quick_enum(
    hosts: dict[str, HostResult],
    ports: list[int] | None = None,
    threads: int = 150,
) -> None:
    """
    Fast enumeration: TTL-based OS guess + banner grab + reverse DNS.
    Zero extra network round trips beyond the port checks themselves.
    """
    # OS from TTL (free)
    for hr in hosts.values():
        if hr.alive and hr.ttl and not hr.os_guess:
            hr.os_guess = guess_os_from_ttl(hr.ttl)

    # Banner grab on discovered open ports (if not already done by check_ports)
    # This is a no-op if banners were already grabbed

    # Reverse DNS
    await resolve_hostnames(hosts, concurrency=threads)
