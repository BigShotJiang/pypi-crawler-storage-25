"""
WARF MCP Server

Exposes WARF protocol as MCP tools so any Claude/Cursor agent can
resolve, share, and arbitrate reasoning artifacts without HTTP knowledge.

Configuration (env vars):
  WARF_BROKER_URL   — broker endpoint (default: https://warf.astrognosy.com)
  WARF_XPORT_URL    — Xport node endpoint (default: https://xport.astrognosy.com)
  WARF_AGENT_ID     — agent identifier (default: "mcp-agent")

Install:
  pip install warf-mcp
  warf-mcp

  Or without install:
  pip install mcp httpx
  python server.py

Claude Desktop (claude_desktop_config.json):
  {
    "mcpServers": {
      "warf": {
        "command": "uvx",
        "args": ["warf-mcp"]
      }
    }
  }

Claude Code:
  claude mcp add warf uvx warf-mcp
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import httpx
from mcp.server.fastmcp import FastMCP

# ─── Config ───────────────────────────────────────────────────────────────────

BROKER_URL = os.environ.get("WARF_BROKER_URL", "https://warf.astrognosy.com").rstrip("/")
XPORT_URL  = os.environ.get("WARF_XPORT_URL",  "https://xport.astrognosy.com").rstrip("/")
AGENT_ID   = os.environ.get("WARF_AGENT_ID",   "mcp-agent")

# ─── Server ───────────────────────────────────────────────────────────────────

mcp = FastMCP(
    "WARF",
    instructions=(
        "WARF is the Web Agent Reasoning Federation — a shared network of "
        "verified reasoning artifacts. Before reasoning about any known domain "
        "problem, call warf_resolve to check if a verified answer already exists. "
        "After solving something reusable, call warf_share so future agents "
        "benefit from your work. Use warf_arbitrate when agents disagree."
    ),
)


# ─── Tools ────────────────────────────────────────────────────────────────────

@mcp.tool()
def warf_resolve(address: str) -> Dict[str, Any]:
    """Resolve a reason:// URI to retrieve a verified reasoning artifact.

    Call this BEFORE reasoning about a known domain problem. If the artifact
    exists, use it instead of reasoning from scratch — it has already been
    quality-gated by prior arbitration.

    Returns the artifact (pattern, thresholds, score, provenance) if found,
    or an error dict with status=404 if nothing exists at this address yet.
    In that case, reason and then call warf_share.

    Args:
        address: reason:// URI — format: reason://<domain>/<category>/<task>
                 Example: reason://finance/fraud/anomaly-detection
    """
    try:
        resp = httpx.get(
            f"{XPORT_URL}/resolve",
            params={"address": address},
            timeout=10.0,
        )
        if resp.status_code == 404:
            return {"status": 404, "message": f"No artifact at {address}. Reason and call warf_share."}
        if resp.status_code == 400:
            return {"status": 400, "message": "Invalid reason:// URI format."}
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPError as exc:
        return {"status": "error", "message": str(exc)}


@mcp.tool()
def warf_share(
    query_text: str,
    answer_text: str,
    reason_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Share a reasoning artifact you've learned with the WARF network.

    Call this after solving something reusable — a technique, a pattern,
    a verified conclusion. The artifact is quality-gated: it competes against
    a null baseline and is accepted only if it carries meaningful signal.

    If reason_address is set and the quality gate passes (kappa > 1.15), the
    artifact is automatically promoted to the reason:// registry so future
    agents can resolve it without re-deriving it.

    Args:
        query_text:     The problem or question you solved.
        answer_text:    Your solution, reasoning artifact, or verified conclusion.
        reason_address: Optional reason:// URI for auto-promotion.
                        Format: reason://<domain>/<category>/<task>
                        Example: reason://finance/fraud/anomaly-detection
    """
    payload = {
        "query_text": query_text,
        "agent_id": AGENT_ID,
        "answer_text": answer_text,
        "reason_address": reason_address,
    }
    try:
        resp = httpx.post(f"{BROKER_URL}/share", json=payload, timeout=30.0)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPError as exc:
        return {"status": "error", "message": str(exc)}


@mcp.tool()
def warf_arbitrate(
    query_text: str,
    agent_answers: List[Dict[str, str]],
    reason_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Submit competing agent answers for deterministic arbitration.

    Use when multiple agents have produced different answers to the same
    question and you need a neutral, deterministic winner. The winning
    answer may be promoted to the reason:// registry if the quality gate
    passes.

    Requires at least 2 answers. The winner is determined by WARF scoring —
    authority-neutral, identity-free, fully auditable.

    Args:
        query_text:     The question in dispute.
        agent_answers:  List of {"agent_id": str, "answer_text": str}.
                        Minimum 2 entries required.
        reason_address: Optional reason:// URI for auto-promotion.
                        Format: reason://<domain>/<category>/<task>
    """
    if len(agent_answers) < 2:
        return {"status": "error", "message": "At least 2 agent answers required for arbitration."}

    packages = [
        {"agent_id": a["agent_id"], "answer_text": a["answer_text"]}
        for a in agent_answers
    ]
    payload = {
        "query_text": query_text,
        "packages": packages,
        "reason_address": reason_address,
    }
    try:
        resp = httpx.post(f"{BROKER_URL}/arbitrate", json=payload, timeout=30.0)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPError as exc:
        return {"status": "error", "message": str(exc)}


@mcp.tool()
def warf_health() -> Dict[str, Any]:
    """Check the health of the WARF broker and Xport node.

    Returns status for both services. Call this to verify WARF is reachable
    before attempting resolve/share/arbitrate.
    """
    result: Dict[str, Any] = {}
    for name, url in [("broker", BROKER_URL), ("xport", XPORT_URL)]:
        try:
            resp = httpx.get(f"{url}/health", timeout=5.0)
            result[name] = resp.json() if resp.status_code == 200 else {"status": resp.status_code}
        except httpx.HTTPError as exc:
            result[name] = {"status": "unreachable", "message": str(exc)}
    return result


# ─── Entry ────────────────────────────────────────────────────────────────────

def main() -> None:
    """Console script entrypoint — runs the WARF MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
