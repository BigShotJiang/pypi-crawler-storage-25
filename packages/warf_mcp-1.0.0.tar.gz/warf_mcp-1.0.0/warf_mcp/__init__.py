"""warf-mcp — WARF protocol as MCP tools for Claude/Cursor agents."""

from warf_mcp.server import mcp, main

__version__ = "1.0.0"
__all__ = ["mcp", "main"]
