"""Validate bridge exports for a tenant against their LDD schemas."""
from __future__ import annotations

import csv
from pathlib import Path


def _latest(glob: str, root: Path) -> Path | None:
    files = sorted(root.glob(glob))
    return files[-1] if files else None


def validate_cmdb(tenant: str, tenants_root: Path) -> list[str]:
    """Return list of error strings (empty = pass)."""
    errors: list[str] = []
    tenant_dir = tenants_root / tenant
    latest = _latest("cmdb-*.csv", tenant_dir / "bridge")
    if not latest:
        errors.append(f"[CMDB] no cmdb-*.csv found in {tenant_dir / 'bridge'}; run task bridge:export-cmdb first")
        return errors

    seen_ids: set[str] = set()
    row_count = 0
    required = ["ci_type", "cmdb_id", "name", "owned_by", "support_group",
                "aws_account_id", "last_discovered", "discovery_confidence_pct"]

    with open(latest, "r", encoding="utf-8") as f:
        first = f.readline()
        if not first.startswith("#"):
            f.seek(0)
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            errors.append(f"[CMDB] {latest.name}: empty file or no header")
            return errors
        missing = [c for c in required if c not in reader.fieldnames]
        if missing:
            errors.append(f"[CMDB] {latest.name}: missing required columns: {missing}")
            return errors

        for row in reader:
            row_count += 1
            cid = row.get("cmdb_id", "")
            if cid in seen_ids:
                errors.append(f"[CMDB] {latest.name}: duplicate cmdb_id={cid!r}")
            seen_ids.add(cid)
            try:
                conf = int(row.get("discovery_confidence_pct", "0"))
                if not 0 <= conf <= 100:
                    errors.append(f"[CMDB] {cid}: discovery_confidence_pct out of range: {conf}")
            except ValueError:
                errors.append(f"[CMDB] {cid}: discovery_confidence_pct not an integer: {row.get('discovery_confidence_pct')!r}")
            acct = row.get("aws_account_id", "")
            if not acct.isdigit() or len(acct) != 12:
                errors.append(f"[CMDB] {cid}: aws_account_id must be 12 digits, got {acct!r}")

    if row_count == 0:
        errors.append(f"[CMDB] {latest.name}: zero data rows")
    return errors


def validate_jsm(tenant: str, tenants_root: Path) -> list[str]:
    """Return list of error strings (empty = pass)."""
    errors: list[str] = []
    tenant_dir = tenants_root / tenant
    latest = _latest("jsm-*.csv", tenant_dir / "bridge")
    if not latest:
        errors.append(f"[JSM] no jsm-*.csv found in {tenant_dir / 'bridge'}; run task bridge:export-jsm first")
        return errors

    seen_keys: set[str] = set()
    row_count = 0
    required = ["object_type", "object_key", "name", "attributes_json", "owner", "last_updated"]

    with open(latest, "r", encoding="utf-8") as f:
        first = f.readline()
        if not first.startswith("#"):
            f.seek(0)
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            errors.append(f"[JSM] {latest.name}: empty file or no header")
            return errors
        missing = [c for c in required if c not in reader.fieldnames]
        if missing:
            errors.append(f"[JSM] {latest.name}: missing required columns: {missing}")
            return errors

        for row in reader:
            row_count += 1
            k = row.get("object_key", "")
            if k in seen_keys:
                errors.append(f"[JSM] {latest.name}: duplicate object_key={k!r}")
            seen_keys.add(k)

    if row_count == 0:
        errors.append(f"[JSM] {latest.name}: zero data rows")
    return errors
