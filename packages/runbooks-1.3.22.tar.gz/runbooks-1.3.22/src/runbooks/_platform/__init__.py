"""
Enterprise FinOps Platform Integration Layer

This module provides the integration layer between the runbooks package
and the FinOps notebook interfaces, enabling business-friendly access
to technical cost optimization capabilities.
"""

from runbooks import __version__

from .components.validators import ProfileValidator
from .core.runbooks_wrapper import RunbooksWrapper
from .finops.unit_economics import UnitEconomicsCalculator

__all__ = ["RunbooksWrapper", "UnitEconomicsCalculator", "ProfileValidator"]
