"""
Remediation Commands Module - Security Remediation & Multi-Account Operations

KISS Principle: Focused on security remediation and compliance automation
DRY Principle: Centralized multi-account remediation patterns

Exposes enterprise remediation functionality from src/runbooks/remediation/
with 45 Python files covering Security Hub, GuardDuty, S3, IAM, EC2, and more.
"""

import click

from runbooks.common.rich_utils import console


def create_remediation_group():
    """
    Create the remediation command group with all subcommands.

    Returns:
        Click Group object with all remediation commands

    Performance: Lazy creation only when needed by DRYCommandRegistry
    Context Reduction: Exposes hidden 45-file remediation module
    """

    from runbooks.common.rich_utils import create_rich_group_class

    _categories = {
        "🛡️ S3 Security Operations": [
            ("s3-security", "S3 security remediation (block public access, enforce SSL, enable encryption)")
        ],
        "📋 Account Management": [("list-accounts", "List available accounts for remediation operations")],
        "⚙️ Configuration": [
            ("config-info", "Display current remediation configuration and environment setup"),
            ("generate-config", "Generate universal configuration templates for remediation operations"),
        ],
    }

    RichRemediationCls = create_rich_group_class(
        categories=_categories,
        title_prefix="Remediation Commands",
        footer_lines=[
            "\n[bold]Usage Patterns:[/bold]",
            "  [dim]# List available accounts for remediation[/dim]",
            "  [cyan]runbooks remediation list-accounts[/cyan]",
            "",
            "  [dim]# Execute S3 security remediation (dry-run by default)[/dim]",
            "  [cyan]runbooks remediation s3-security --operations block_public_access --dry-run[/cyan]",
            "",
            "  [dim]# Generate configuration templates[/dim]",
            "  [cyan]runbooks remediation generate-config --output-dir ./config[/cyan]",
        ],
    )

    from runbooks.remediation.remediation_cli import remediation

    rich_remediation = RichRemediationCls(name="remediation", help=remediation.help)

    # Copy all commands from the imported group to the new group
    for name, command in remediation.commands.items():
        rich_remediation.add_command(command, name=name)

    return rich_remediation


# Export for registry
__all__ = ["create_remediation_group"]
