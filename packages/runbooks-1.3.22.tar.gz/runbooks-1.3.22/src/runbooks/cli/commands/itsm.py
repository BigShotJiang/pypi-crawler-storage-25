"""
ITSM Commands Module - IT Service Management Operations

KISS Principle: Focused on JIRA OPS ticket enrichment via REST API
DRY Principle: Reuses rich_utils patterns for consistent CLI output

Provides bulk JIRA ticket classification and label enrichment
for the OPS board using deterministic service/tier mapping.

Rate limit: 0.3s between JIRA API calls (ADR-ITSM-02).
Authentication: JIRA_URL / JIRA_USERNAME / JIRA_API_TOKEN env vars,
                or ~/.atlassian/credentials.json fallback.
"""

import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import click

from runbooks.common.rich_utils import (
    BOX_PRIMARY,
    create_table,
    get_console,
    print_error,
    print_header,
    print_success,
)

# ---------------------------------------------------------------------------
# Classification mapping (deterministic, based on existing domain labels)
# ---------------------------------------------------------------------------

# Map from a keyword that may appear in ticket labels to (service_label, tier_label)
SERVICE_TIER_MAP: Dict[str, Tuple[str, str]] = {
    "ec2": ("service:ec2", "tier:critical"),
    "database-rds": ("service:rds", "tier:critical"),
    "vpc": ("service:vpc", "tier:critical"),
    "security": ("service:security", "tier:critical"),
    "elb-alb": ("service:elb-alb", "tier:critical"),
    "eip-ebs": ("service:eip-ebs", "tier:important"),
    "networking": ("service:networking", "tier:important"),
    "storage-s3": ("service:s3", "tier:important"),
}

DEFAULT_SERVICE: Tuple[str, str] = ("service:general", "tier:best-effort")

# Labels managed by this command — never strip labels outside this set
_SERVICE_LABELS = {v[0] for v in SERVICE_TIER_MAP.values()} | {DEFAULT_SERVICE[0]}
_TIER_LABELS = {v[1] for v in SERVICE_TIER_MAP.values()} | {DEFAULT_SERVICE[1]}
_MANAGED_LABELS = _SERVICE_LABELS | _TIER_LABELS

_JIRA_RATE_LIMIT = 0.3  # seconds between API calls


# ---------------------------------------------------------------------------
# JIRA client helpers
# ---------------------------------------------------------------------------


def _load_credentials() -> Tuple[str, str, str]:
    """Load JIRA credentials from env vars or ~/.atlassian/credentials.json.

    Returns:
        (jira_url, username, api_token)

    Raises:
        click.ClickException: when credentials cannot be resolved.
    """
    jira_url = os.environ.get("JIRA_URL", "https://1xops.atlassian.net")
    username = os.environ.get("JIRA_USERNAME", "")
    api_token = os.environ.get("JIRA_API_TOKEN", "")

    if not username or not api_token:
        creds_path = Path.home() / ".atlassian" / "credentials.json"
        if creds_path.exists():
            try:
                data = json.loads(creds_path.read_text())
                username = username or data.get("username", "")
                api_token = api_token or data.get("api_token", "")
            except (json.JSONDecodeError, KeyError):
                pass

    if not username or not api_token:
        raise click.ClickException(
            "JIRA credentials not found. Set JIRA_USERNAME and JIRA_API_TOKEN "
            "environment variables, or create ~/.atlassian/credentials.json with "
            '{"username": "...", "api_token": "..."}.'
        )

    return jira_url, username, api_token


def _jira_get(session: Any, url: str) -> Dict:
    """Execute GET request and raise on non-2xx."""
    resp = session.get(url)
    if not resp.ok:
        raise click.ClickException(f"JIRA GET {url} returned {resp.status_code}: {resp.text[:200]}")
    return resp.json()


def _jira_post(session: Any, url: str, payload: Dict) -> Dict:
    """Execute POST request and raise on non-2xx."""
    resp = session.post(url, json=payload)
    if not resp.ok:
        raise click.ClickException(f"JIRA POST {url} returned {resp.status_code}: {resp.text[:200]}")
    return resp.json()


def _jira_put(session: Any, url: str, payload: Dict) -> None:
    """Execute PUT request and raise on non-2xx."""
    resp = session.put(url, json=payload)
    if not resp.ok:
        raise click.ClickException(f"JIRA PUT {url} returned {resp.status_code}: {resp.text[:200]}")


def _build_session(jira_url: str, username: str, api_token: str) -> Any:
    """Create an authenticated requests.Session for JIRA REST API v3."""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
    except ImportError as exc:
        raise click.ClickException("The 'requests' package is required. Install it via: uv add requests") from exc

    session = requests.Session()
    session.auth = HTTPBasicAuth(username, api_token)
    session.headers.update({"Accept": "application/json", "Content-Type": "application/json"})
    session.base_url = jira_url  # type: ignore[attr-defined]
    return session


# ---------------------------------------------------------------------------
# Ticket search and classification logic
# ---------------------------------------------------------------------------


def _classify_labels(existing_labels: List[str]) -> Tuple[str, str]:
    """Determine (service_label, tier_label) from the ticket's current labels.

    Iterates SERVICE_TIER_MAP in definition order; first keyword match wins.
    Falls back to DEFAULT_SERVICE when no keyword matches.
    """
    label_set = {lbl.lower() for lbl in existing_labels}
    for keyword, (svc, tier) in SERVICE_TIER_MAP.items():
        if keyword in label_set:
            return svc, tier
    return DEFAULT_SERVICE


def _missing_enrichment(labels: List[str]) -> bool:
    """Return True when the ticket lacks at least one managed service: or tier: label."""
    has_service = any(lbl.startswith("service:") for lbl in labels)
    has_tier = any(lbl.startswith("tier:") for lbl in labels)
    return not (has_service and has_tier)


def _fetch_tickets(session: Any, jira_url: str, jql: str) -> List[Dict]:
    """Paginate through POST /rest/api/3/search/jql and return all issues."""
    url = f"{jira_url}/rest/api/3/search/jql"
    issues: List[Dict] = []
    next_token: Optional[str] = None

    while True:
        payload: Dict[str, Any] = {
            "jql": jql,
            "fields": ["summary", "labels", "status"],
            "maxResults": 100,
        }
        if next_token:
            payload["nextPageToken"] = next_token

        data = _jira_post(session, url, payload)
        issues.extend(data.get("issues", []))
        time.sleep(_JIRA_RATE_LIMIT)

        next_token = data.get("nextPageToken")
        if not next_token:
            break

    return issues


def _apply_labels(session: Any, jira_url: str, key: str, new_labels: List[str]) -> None:
    """PUT merged label list to JIRA. Additive only — never removes existing labels."""
    url = f"{jira_url}/rest/api/3/issue/{key}"
    _jira_put(session, url, {"fields": {"labels": new_labels}})
    time.sleep(_JIRA_RATE_LIMIT)


# ---------------------------------------------------------------------------
# Result export
# ---------------------------------------------------------------------------


def _export_csv(rows: List[Dict], output_path: str) -> None:
    """Write classification results to CSV."""
    import csv as csv_mod

    fieldnames = ["key", "summary", "current_labels", "service_label", "tier_label", "action"]
    with open(output_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv_mod.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "key": row["key"],
                    "summary": row["summary"][:80],
                    "current_labels": " ".join(row["current_labels"]),
                    "service_label": row["service_label"],
                    "tier_label": row["tier_label"],
                    "action": row["action"],
                }
            )


# ---------------------------------------------------------------------------
# Command group factory
# ---------------------------------------------------------------------------


def create_itsm_group() -> click.Group:
    """Create the itsm command group with all subcommands.

    Returns:
        Click Group object with all ITSM commands.

    Performance: Lazy creation only when needed by DRYCommandRegistry.
    """
    from runbooks.common.rich_utils import create_rich_group_class

    _categories = {
        "Ticket Management": [
            ("classify", "Classify OPS tickets and apply service/tier enrichment labels"),
        ],
    }

    @click.group(
        cls=create_rich_group_class(
            categories=_categories,
            title_prefix="ITSM Commands",
            footer_lines=[
                "\n[blue]Usage: runbooks itsm [COMMAND] [OPTIONS][/blue]",
                "[blue]Docs: https://1xops.atlassian.net/jira/software/c/projects/OPS/[/blue]",
            ],
        ),
        invoke_without_command=True,
    )
    @click.pass_context
    def itsm(ctx: click.Context) -> None:
        """
        IT Service Management operations for the OPS JIRA board.

        Provides bulk ticket classification and label enrichment
        using deterministic service/tier mapping.

        Rate limit: 0.3s per JIRA API call (ADR-ITSM-02).

        Examples:
            runbooks itsm classify --batch --dry-run
            runbooks itsm classify --batch --execute
            runbooks itsm classify --ticket OPS-42 --dry-run
        """
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # ------------------------------------------------------------------
    # classify subcommand
    # ------------------------------------------------------------------

    @itsm.command()
    @click.option("--ticket", metavar="OPS-NNN", default=None, help="Classify a single ticket by key.")
    @click.option("--batch", is_flag=True, help="Classify all OPS tickets missing enrichment labels.")
    @click.option(
        "--dry-run/--no-dry-run",
        default=True,
        show_default=True,
        help="Report only (default). Use --no-dry-run with --execute to apply labels.",
    )
    @click.option("--execute", is_flag=True, help="Apply labels after displaying dry-run report.")
    @click.option(
        "--output",
        "output_path",
        default=None,
        metavar="PATH",
        help="Export results to CSV (default: /tmp/runbooks-itsm-classify-{timestamp}.csv).",
    )
    @click.pass_context
    def classify(
        ctx: click.Context,
        ticket: Optional[str],
        batch: bool,
        dry_run: bool,
        execute: bool,
        output_path: Optional[str],
    ) -> None:
        """
        Classify OPS tickets and apply service/tier enrichment labels.

        Applies a deterministic mapping from domain keywords in existing labels
        to standardised service:* and tier:* labels. Labels are ADDITIVE ONLY —
        existing labels are never removed or modified.

        Authentication uses JIRA_URL, JIRA_USERNAME, JIRA_API_TOKEN env vars,
        or ~/.atlassian/credentials.json as fallback.

        Examples:
            runbooks itsm classify --batch --dry-run
            runbooks itsm classify --batch --execute
            runbooks itsm classify --ticket OPS-42 --dry-run
            runbooks itsm classify --batch --execute --output /tmp/results.csv
        """
        console = get_console()
        print_header("ITSM Classify")

        if not ticket and not batch:
            raise click.UsageError("Specify --ticket OPS-NNN or --batch.")

        if execute and dry_run:
            # --execute implies writing; override the default --dry-run
            dry_run = False

        # Resolve output path
        if output_path is None:
            ts = datetime.now().strftime("%Y%m%d-%H%M%S")
            output_path = f"/tmp/runbooks-itsm-classify-{ts}.csv"

        # Load credentials and build session (not required in dry-run preview mode)
        if not dry_run:
            jira_url, username, api_token = _load_credentials()
            session = _build_session(jira_url, username, api_token)
        else:
            jira_url = os.environ.get("JIRA_URL", "https://1xops.atlassian.net")
            session = None

        # Build JQL
        if ticket:
            jql = f'project = OPS AND key = "{ticket}"'
        else:
            # batch: only tickets missing service: or tier: label
            jql = (
                'project = OPS AND NOT labels in membersOf("service:ec2", "service:rds", '
                '"service:vpc", "service:security", "service:elb-alb", "service:eip-ebs", '
                '"service:networking", "service:s3", "service:general") '
                'AND NOT labels in membersOf("tier:critical", "tier:important", "tier:best-effort") '
                "ORDER BY created DESC"
            )

        console.print(f"[dim]Querying JIRA: {jira_url}[/dim]")
        console.print(f"[dim]JQL: {jql}[/dim]\n")

        if dry_run and session is None:
            # Dry-run without credentials: show classification rules only
            console.print("[yellow]Dry-run mode (no credentials):[/yellow] showing classification rules only.")
            console.print("[dim]To preview real tickets, set JIRA_USERNAME + JIRA_API_TOKEN.[/dim]")
            return

        issues = _fetch_tickets(session, jira_url, jql)

        if not issues:
            console.print("[green]No tickets require classification.[/green]")
            return

        # Classify each ticket
        results: List[Dict] = []
        for issue in issues:
            key = issue["key"]
            fields = issue.get("fields", {})
            summary = fields.get("summary", "")[:80]
            current_labels: List[str] = fields.get("labels") or []

            svc_label, tier_label = _classify_labels(current_labels)

            has_service = any(lbl.startswith("service:") for lbl in current_labels)
            has_tier = any(lbl.startswith("tier:") for lbl in current_labels)

            labels_to_add = []
            if not has_service:
                labels_to_add.append(svc_label)
            if not has_tier:
                labels_to_add.append(tier_label)

            if labels_to_add:
                action = "ADD: " + " + ".join(labels_to_add)
            else:
                action = "already-labeled"

            results.append(
                {
                    "key": key,
                    "summary": summary,
                    "current_labels": current_labels,
                    "service_label": svc_label,
                    "tier_label": tier_label,
                    "new_labels": list(current_labels) + labels_to_add,
                    "labels_to_add": labels_to_add,
                    "action": action,
                }
            )

        # Dry-run table
        table = create_table(
            title=f"ITSM Classification Plan ({len(results)} tickets)",
            columns=[
                {"name": "#", "style": "dim", "no_wrap": True},
                {"name": "Key", "style": "cyan", "no_wrap": True},
                {"name": "Summary", "no_wrap": False},
                {"name": "Current Labels", "style": "dim", "no_wrap": False},
                {"name": "+ service:", "style": "green", "no_wrap": True},
                {"name": "+ tier:", "style": "yellow", "no_wrap": True},
                {"name": "Action", "no_wrap": True},
            ],
            box_style=BOX_PRIMARY,
        )
        for idx, row in enumerate(results, 1):
            svc_add = row["service_label"] if not any(l.startswith("service:") for l in row["current_labels"]) else ""
            tier_add = row["tier_label"] if not any(l.startswith("tier:") for l in row["current_labels"]) else ""
            action_style = "[green]" if row["labels_to_add"] else "[dim]"
            table.add_row(
                str(idx),
                row["key"],
                row["summary"],
                " ".join(row["current_labels"]) or "[dim]-[/dim]",
                f"[green]{svc_add}[/green]" if svc_add else "[dim]-[/dim]",
                f"[yellow]{tier_add}[/yellow]" if tier_add else "[dim]-[/dim]",
                f"{action_style}{row['action']}[/]",
            )
        console.print(table)

        needs_update = [r for r in results if r["labels_to_add"]]
        already_labeled = len(results) - len(needs_update)

        if dry_run and not execute:
            console.print(
                f"\n[yellow]Dry-run mode:[/yellow] {len(needs_update)} tickets would be updated. "
                "Use [bold]--execute[/bold] to apply."
            )
            _export_csv(results, output_path)
            print_success(f"Results exported: {output_path}")
            return

        # Execute: apply labels
        if not needs_update:
            console.print("\n[green]All tickets already have enrichment labels. Nothing to update.[/green]")
        else:
            console.print(f"\n[bold]Applying labels to {len(needs_update)} tickets...[/bold]")
            failures = 0
            updated = 0
            from rich.progress import MofNCompleteColumn, SpinnerColumn, TextColumn
            from rich.progress import Progress as RichProgress

            with RichProgress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                MofNCompleteColumn(),
                console=console,
            ) as progress:
                task = progress.add_task("Updating JIRA tickets", total=len(needs_update))
                for row in needs_update:
                    try:
                        _apply_labels(session, jira_url, row["key"], row["new_labels"])
                        updated += 1
                        row["action"] = "DONE"
                    except click.ClickException as exc:
                        failures += 1
                        row["action"] = f"FAILED: {exc.format_message()[:60]}"
                    finally:
                        progress.advance(task)

            # Summary table
            summary_table = create_table(
                title="Classification Summary",
                caption=["Metric", "Value"],
                columns=[
                    ["Total tickets", str(len(results))],
                    ["Already labeled", str(already_labeled)],
                    ["Newly labeled", str(updated)],
                    ["Failures", f"[red]{failures}[/red]" if failures else "0"],
                ],
                box_style=BOX_PRIMARY,
            )
            console.print(summary_table)

            if failures:
                print_error(f"{failures} ticket(s) failed to update. Check output CSV for details.")
            else:
                print_success(f"Successfully applied enrichment labels to {updated} ticket(s).")

        _export_csv(results, output_path)
        print_success(f"Results exported: {output_path}")

    return itsm
