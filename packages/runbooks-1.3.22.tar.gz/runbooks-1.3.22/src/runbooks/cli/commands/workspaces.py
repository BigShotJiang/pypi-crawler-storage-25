"""
WorkSpaces CLI Commands Module - FinOps & Decommission Analysis

KISS Principle: Thin CLI wrappers that delegate to domain modules.
DRY Principle: Reuses WorkSpacesAnalyzer, calculate_workspace_monthly_cost SSOT.

5 commands:
  accounts  - List org accounts for WorkSpaces discovery
  collect   - Inventory all WorkSpaces (22-column schema)
  cost      - Cost Explorer billing data (Way 2 of 4-way cross-validation)
  analyze   - W1-W7 decommission scoring (105-point max)
  report    - CxO-readable FinOps Markdown report
"""

import csv
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

import click
from botocore.exceptions import ClientError

from runbooks.common.aws_client_factory import (
    create_cost_explorer_client,
    create_organizations_client,
    create_sts_client,
    create_workspaces_client,
)
from runbooks.common.rich_utils import (
    console,
    create_table,
    get_console,
    print_error,
    print_header,
    print_info,
    print_success,
    print_warning,
)

logger = logging.getLogger(__name__)

# Decommission score threshold for DECOMMISSION recommendation
DECOMMISSION_THRESHOLD = 70


def _ensure_output_dir(output: str) -> Path:
    """Ensure output directory exists and return as Path."""
    path = Path(output)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _datestamp() -> str:
    """Return YYYY-MM-DD datestamp for filenames."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


# Internal domain allowlist — contractor email domains.
# Extend by setting RUNBOOKS_CONTRACTOR_DOMAINS=domain1.com,domain2.com
_DEFAULT_CONTRACTOR_DOMAINS = {"accenture.com", "deloitte.com", "wipro.com", "infosys.com", "tcs.com"}
_INTERNAL_DOMAIN = "bluecurrent.co.nz"


def _load_identity_csv(path: str) -> Optional["pd.DataFrame"]:  # type: ignore[name-defined]
    """Load and normalise an identity CSV for user enrichment.

    Expected columns (either variant accepted):
      username | user_name   — matched against WorkSpace UserName (case-insensitive)
      full_name              — mapped to user_full_name in output
      email                  — used for persona classification heuristic
      persona                — optional; if present, takes precedence over heuristic

    Returns a normalised DataFrame with columns:
      user_name, user_full_name, user_persona
    or None on any read/parse failure (graceful degradation).
    """
    try:
        import pandas as pd  # noqa: PLC0415 — optional dep, imported lazily
    except ImportError:
        print_warning("pandas not installed — identity enrichment skipped.")
        return None

    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        print_warning(f"Identity CSV not found: {path} — enrichment skipped.")
        return None
    except Exception as exc:  # noqa: BLE001
        print_warning(f"Failed to parse identity CSV ({exc}) — enrichment skipped.")
        return None

    # Normalise username column name
    if "user_name" in df.columns:
        df = df.rename(columns={"user_name": "username"})
    if "username" not in df.columns:
        print_warning("Identity CSV missing 'username' or 'user_name' column — enrichment skipped.")
        return None
    if "full_name" not in df.columns:
        print_warning("Identity CSV missing 'full_name' column — enrichment skipped.")
        return None

    df["username_lower"] = df["username"].str.lower().str.strip()

    contractor_domains = _DEFAULT_CONTRACTOR_DOMAINS.copy()
    env_extra = os.environ.get("RUNBOOKS_CONTRACTOR_DOMAINS", "")
    if env_extra:
        contractor_domains.update(d.strip() for d in env_extra.split(",") if d.strip())

    def _classify_persona(row: "pd.Series") -> str:  # type: ignore[name-defined]
        # If CSV already has persona column, use it
        if "persona" in row.index and isinstance(row.get("persona"), str) and row["persona"].strip():
            return row["persona"].strip()
        email = str(row.get("email", "")).strip().lower()
        if not email or "@" not in email:
            return "unknown"
        domain = email.split("@", 1)[1]
        if domain == _INTERNAL_DOMAIN:
            return "internal"
        if domain in contractor_domains:
            return "contractor"
        return "external"

    if "persona" not in df.columns:
        df["persona"] = ""
    df["user_persona"] = df.apply(_classify_persona, axis=1)

    result = df[["username_lower", "full_name", "user_persona"]].rename(
        columns={"username_lower": "_key", "full_name": "user_full_name"}
    )
    return result


class RichWorkSpacesGroup(click.Group):
    """Click Group with Rich help display for workspaces commands."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        test_mode = os.environ.get("RUNBOOKS_TEST_MODE", "0") == "1"
        if test_mode:
            return super().format_help(ctx, formatter)

        _console = get_console()
        _console.print("\n[bold cyan]runbooks workspaces[/bold cyan] — WorkSpaces FinOps & Decommission Analysis\n")
        _console.print(
            create_table(
                "Commands",
                ["Command", "Purpose"],
                [
                    ["accounts", "List org accounts for WorkSpaces discovery"],
                    ["collect", "Inventory all WorkSpaces (22-column schema)"],
                    ["cost", "Cost Explorer billing (Way 2 of 4-way cross-validation)"],
                    ["analyze", "W1-W7 decommission scoring (105-point max)"],
                    ["report", "CxO-readable FinOps Markdown report"],
                    ["validate", "4-way cross-validation (API / CE / CW / Excel)"],
                ],
            )
        )
        _console.print("\n[dim]Run 'runbooks workspaces COMMAND --help' for options[/dim]\n")


def create_workspaces_group() -> click.Group:
    """
    Create the workspaces command group with all subcommands.

    Returns:
        Click Group object with 5 workspaces commands.

    Performance: Lazy creation only when needed by DRYCommandRegistry.
    """

    @click.group("workspaces", cls=RichWorkSpacesGroup, invoke_without_command=True)
    @click.pass_context
    def workspaces(ctx: click.Context) -> None:
        """WorkSpaces FinOps: inventory, cost, decommission scoring, and reporting."""
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # ------------------------------------------------------------------
    # Command 1: accounts
    # ------------------------------------------------------------------
    @workspaces.command("accounts")
    @click.option(
        "--management-profile",
        default=None,
        envvar="AWS_MANAGEMENT_PROFILE",
        show_default=True,
        help="AWS profile for Organizations API (env: AWS_MANAGEMENT_PROFILE).",
    )
    @click.option(
        "--output",
        default="tmp/cloudops/workspaces/",
        show_default=True,
        help="Output directory for accounts CSV.",
    )
    @click.option("--quiet", is_flag=True, default=False, help="Suppress Rich table output.")
    def accounts_cmd(management_profile: Optional[str], output: str, quiet: bool) -> None:
        """List all AWS accounts in the organization for WorkSpaces discovery.

        Uses the Organizations ListAccounts paginator with the management profile.
        Writes accounts-<date>.csv to the output directory.

        Example:

          runbooks workspaces accounts --management-profile $AWS_MANAGEMENT_PROFILE
        """
        _console = get_console()
        if not quiet:
            print_header("WorkSpaces Account Discovery", "runbooks workspaces accounts")

        output_dir = _ensure_output_dir(output)

        try:
            org_client = create_organizations_client(management_profile)
        except Exception as exc:
            print_error(f"Failed to create Organizations client: {exc}")
            raise click.ClickException(str(exc)) from exc

        rows: List[dict] = []
        try:
            paginator = org_client.get_paginator("list_accounts")
            for page in paginator.paginate():
                for acct in page.get("Accounts", []):
                    rows.append(
                        {
                            "account_id": acct.get("Id", ""),
                            "name": acct.get("Name", ""),
                            "status": acct.get("Status", ""),
                            "email": acct.get("Email", ""),
                            "joined_method": acct.get("JoinedMethod", ""),
                            "joined_timestamp": str(acct.get("JoinedTimestamp", "")),
                        }
                    )
        except ClientError as exc:
            error_code = exc.response["Error"]["Code"]
            print_error(f"Organizations API error [{error_code}]: {exc.response['Error']['Message']}")
            raise click.ClickException(f"Organizations API error: {error_code}") from exc

        if not quiet:
            table = create_table(
                f"AWS Accounts ({len(rows)} total)",
                ["Account ID", "Name", "Status", "Email"],
                [(r["account_id"], r["name"], r["status"], r["email"]) for r in rows],
            )
            _console.print(table)

        csv_path = output_dir / f"accounts-{_datestamp()}.csv"
        with csv_path.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()) if rows else [])
            writer.writeheader()
            writer.writerows(rows)

        print_success(f"Accounts written: {csv_path} ({len(rows)} accounts)")

    # ------------------------------------------------------------------
    # Command 2: collect
    # ------------------------------------------------------------------
    @workspaces.command("collect")
    @click.option(
        "--profile",
        default=None,
        envvar="AWS_PROFILE",
        show_default=True,
        help="AWS profile for WorkSpaces API (env: AWS_PROFILE).",
    )
    @click.option(
        "--all-profile",
        "all_profile",
        default=None,
        envvar="AWS_MANAGEMENT_PROFILE",
        help="Management profile for multi-account collection (env: AWS_MANAGEMENT_PROFILE). "
        "Discovers all accounts via Organizations, resolves per-workload profiles from ~/.aws/config.",
    )
    @click.option(
        "--account-ids",
        default=None,
        help="Comma-separated account IDs to collect (default: uses current session account).",
    )
    @click.option(
        "--output",
        default="tmp/cloudops/workspaces/",
        show_default=True,
        help="Output directory for collect CSV.",
    )
    @click.option("--quiet", is_flag=True, default=False, help="Suppress Rich table output.")
    @click.option(
        "--identity-csv",
        "identity_csv",
        default=None,
        type=click.Path(exists=True, dir_okay=False, readable=True),
        help="Path to identity CSV (columns: username/user_name, full_name, email[, persona]). "
        "Merges user_full_name and user_persona columns onto inventory rows by username.",
    )
    def collect_cmd(
        profile: Optional[str],
        all_profile: Optional[str],
        account_ids: Optional[str],
        output: str,
        quiet: bool,
        identity_csv: Optional[str],
    ) -> None:
        """Collect WorkSpace inventory using DescribeWorkspaces paginator.

        Produces a 22-column CSV with workspace metadata, monthly cost, connection
        status, and W1/W2 signal scores. This is Way 1 of the 4-way cross-validation.

        Use --all-profile with $AWS_MANAGEMENT_PROFILE to discover all org accounts
        and resolve per-workload profiles automatically. Use --profile for single-account
        collection (default: $AWS_PROFILE).

        Example:

          runbooks workspaces collect --profile $AWS_PROFILE
          runbooks workspaces collect --all-profile $AWS_MANAGEMENT_PROFILE
        """
        from runbooks.finops.workspaces_pricing import calculate_workspace_monthly_cost

        _console = get_console()
        if not quiet:
            print_header("WorkSpaces Inventory Collect", "runbooks workspaces collect")

        output_dir = _ensure_output_dir(output)

        # Multi-account mode: discover all org accounts via management profile
        if all_profile:
            try:
                org_client = create_organizations_client(all_profile)
                paginator_orgs = org_client.get_paginator("list_accounts")
                target_accounts = [
                    a["Id"] for page in paginator_orgs.paginate() for a in page["Accounts"] if a["Status"] == "ACTIVE"
                ]
            except Exception as exc:
                print_error(f"Failed to discover org accounts: {exc}")
                raise click.ClickException(str(exc)) from exc

            # Resolve per-workload profile per account via ~/.aws/config SSO sso_account_id fields
            from runbooks.vpc.aws_config_parser import parse_aws_config

            try:
                profile_map = parse_aws_config()
            except Exception:
                profile_map = {}

            if not quiet:
                print_info(f"Multi-account mode: {len(target_accounts)} active accounts discovered.")
            current_account_id = None
        else:
            # Single-account mode: use provided --profile
            try:
                sts_client = create_sts_client(profile)
                caller = sts_client.get_caller_identity()
                current_account_id = caller["Account"]
            except ClientError as exc:
                print_error(f"STS get-caller-identity failed: {exc}")
                raise click.ClickException("Cannot resolve current account") from exc

            target_accounts = (
                [a.strip() for a in account_ids.split(",") if a.strip()] if account_ids else [current_account_id]
            )
            profile_map = {}

        rows: List[dict] = []
        for acct_id in target_accounts:
            # Per-account: resolve profile from profile_map, fall back to --profile
            acct_profile = profile_map.get(acct_id, profile) if all_profile else profile

            if not all_profile and current_account_id and acct_id != current_account_id:
                print_warning(
                    f"Account {acct_id} differs from session account {current_account_id}. "
                    "Cross-account collection requires assume-role configuration."
                )

            try:
                ws_client = create_workspaces_client(acct_profile)
                paginator = ws_client.get_paginator("describe_workspaces")
                for page in paginator.paginate():
                    for ws in page.get("Workspaces", []):
                        ws_id = ws.get("WorkspaceId", "")
                        bundle_id = ws.get("BundleId", "")
                        wsp = ws.get("WorkspaceProperties", {})
                        running_mode = wsp.get("RunningMode", "ALWAYS_ON")
                        compute_type = wsp.get("ComputeTypeName", "")
                        monthly_cost = calculate_workspace_monthly_cost(compute_type, running_mode)

                        # Connection status
                        last_connection = ""
                        connection_status = ""
                        try:
                            conn_resp = ws_client.describe_workspaces_connection_status(WorkspaceIds=[ws_id])
                            conn_data = conn_resp.get("WorkspacesConnectionStatus", [{}])[0]
                            raw_ts = conn_data.get("LastKnownUserConnectionTimestamp")
                            last_connection = str(raw_ts) if raw_ts else ""
                            connection_status = conn_data.get("ConnectionState", "")
                        except ClientError:
                            pass

                        # Simple W1 score: unused if never connected (placeholder signal)
                        w1_score = 15 if not last_connection else 0
                        w2_score = 0  # populated by analyze step

                        row = {
                            "workspace_id": ws_id,
                            "directory_id": ws.get("DirectoryId", ""),
                            "bundle_id": bundle_id,
                            "username": ws.get("UserName", ""),
                            "computer_name": ws.get("ComputerName", ""),
                            "state": ws.get("State", ""),
                            "running_mode": running_mode,
                            "compute_type": ws.get("WorkspaceProperties", {}).get("ComputeTypeName", ""),
                            "root_volume_size_gib": ws.get("WorkspaceProperties", {}).get("RootVolumeSizeGib", ""),
                            "user_volume_size_gib": ws.get("WorkspaceProperties", {}).get("UserVolumeSizeGib", ""),
                            "protocol": ",".join(ws.get("WorkspaceProperties", {}).get("Protocols", [])),
                            "workspace_properties": json.dumps(ws.get("WorkspaceProperties", {})),
                            "tags": json.dumps(ws.get("Tags", [])),
                            "account_id": acct_id,
                            "account_name": acct_id,  # fallback; no Orgs name resolution here
                            "region": ws_client.meta.region_name or "",
                            "monthly_cost_usd": monthly_cost,
                            "last_known_user_connection_timestamp": last_connection,
                            "connection_status": connection_status,
                            "w1_score": w1_score,
                            "w2_score": w2_score,
                            "decommission_total_score": w1_score + w2_score,
                        }
                        rows.append(row)

            except ClientError as exc:
                error_code = exc.response["Error"]["Code"]
                print_error(
                    f"WorkSpaces API error [{error_code}] for account {acct_id}: {exc.response['Error']['Message']}"
                )

        if not rows:
            print_warning("No WorkSpaces found.")
            return

        # -- Identity enrichment (AC3-AC5) ----------------------------------
        if identity_csv:
            identity_df = _load_identity_csv(identity_csv)
            if identity_df is not None:
                try:
                    import pandas as pd  # noqa: PLC0415

                    ws_df = pd.DataFrame(rows)
                    ws_df["_key"] = ws_df["username"].str.lower().str.strip()
                    merged = ws_df.merge(identity_df, on="_key", how="left")
                    merged.drop(columns=["_key"], inplace=True)

                    total = len(merged)
                    matched = int(merged["user_full_name"].notna().sum())
                    pct = (matched / total * 100) if total else 0.0
                    print_info(f"Identity match: {matched}/{total} ({pct:.1f}%)")
                    if pct < 80.0:
                        print_warning(
                            f"Identity match rate {pct:.1f}% is below 80% threshold. "
                            "Check that identity CSV usernames align with WorkSpace UserName values."
                        )
                    # Fill unmatched cells with sensible defaults
                    merged["user_full_name"] = merged["user_full_name"].where(
                        merged["user_full_name"].notna(), other=""
                    )
                    merged["user_persona"] = merged["user_persona"].where(
                        merged["user_persona"].notna(), other="unknown"
                    )
                    rows = merged.to_dict(orient="records")
                except Exception as exc:  # noqa: BLE001
                    print_warning(f"Identity merge failed ({exc}) — continuing without enrichment.")
        # -------------------------------------------------------------------

        if not quiet:
            table = create_table(
                f"WorkSpaces Inventory ({len(rows)} workspaces)",
                ["Workspace ID", "Username", "State", "Running Mode", "Monthly Cost USD"],
                [
                    (r["workspace_id"], r["username"], r["state"], r["running_mode"], f"${r['monthly_cost_usd']:.2f}")
                    for r in rows[:50]  # cap display at 50 rows
                ],
            )
            _console.print(table)
            if len(rows) > 50:
                print_info(f"... {len(rows) - 50} more workspaces in CSV output.")

        csv_path = output_dir / f"collect-{_datestamp()}.csv"
        fieldnames = list(rows[0].keys())
        with csv_path.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        print_success(f"Inventory written: {csv_path} ({len(rows)} workspaces)")

    # ------------------------------------------------------------------
    # Command 3: cost
    # ------------------------------------------------------------------
    @workspaces.command("cost")
    @click.option(
        "--billing-profile",
        default=None,
        envvar="AWS_BILLING_PROFILE",
        show_default=True,
        help="AWS profile for Cost Explorer (env: AWS_BILLING_PROFILE).",
    )
    @click.option(
        "--months",
        default=1,
        show_default=True,
        help="Number of months back to query Cost Explorer.",
    )
    @click.option(
        "--granularity",
        type=click.Choice(["DAILY", "MONTHLY"], case_sensitive=False),
        default="MONTHLY",
        show_default=True,
        help="CE granularity. DAILY emits cost-daily-<date>.csv with one row per (date,account); "
        "MONTHLY emits cost-<date>.csv (legacy). Use DAILY for HITL Q7 3-month daily report. "
        "Per-WorkSpace daily allocation is MEDIUM confidence without cost allocation tags.",
    )
    @click.option(
        "--output",
        default="tmp/cloudops/workspaces/",
        show_default=True,
        help="Output directory for cost CSV.",
    )
    @click.option("--quiet", is_flag=True, default=False, help="Suppress Rich table output.")
    def cost_cmd(
        billing_profile: Optional[str],
        months: int,
        granularity: str,
        output: str,
        quiet: bool,
    ) -> None:
        """Get WorkSpaces cost from Cost Explorer (Way 2 of 4-way cross-validation).

        Queries ce:GetCostAndUsage grouped by LINKED_ACCOUNT filtered to
        SERVICE="Amazon WorkSpaces". Produces cost-<date>.csv (MONTHLY) or
        cost-daily-<date>.csv (DAILY).

        Example:

          runbooks workspaces cost --billing-profile $AWS_BILLING_PROFILE --granularity DAILY --months 3
        """
        _console = get_console()
        if not quiet:
            print_header("WorkSpaces Cost Explorer", "runbooks workspaces cost")

        output_dir = _ensure_output_dir(output)

        try:
            ce_client = create_cost_explorer_client(billing_profile, region="us-east-1")
        except Exception as exc:
            print_error(f"Failed to create Cost Explorer client: {exc}")
            raise click.ClickException(str(exc)) from exc

        # Date range: months back from today
        from datetime import timedelta

        end_dt = datetime.now(timezone.utc).replace(day=1)
        start_dt = (end_dt.replace(day=1) - timedelta(days=1)).replace(day=1)
        if months > 1:
            for _ in range(months - 1):
                start_dt = (start_dt - timedelta(days=1)).replace(day=1)

        start_str = start_dt.strftime("%Y-%m-%d")
        end_str = end_dt.strftime("%Y-%m-%d")

        if not quiet:
            print_info(f"Querying Cost Explorer: {start_str} to {end_str}")

        rows: List[dict] = []
        try:
            granularity_upper = granularity.upper()
            cost_field = "cost_usd" if granularity_upper == "DAILY" else "monthly_cost_usd"
            response = ce_client.get_cost_and_usage(
                TimePeriod={"Start": start_str, "End": end_str},
                Granularity=granularity_upper,
                Filter={
                    "Dimensions": {
                        "Key": "SERVICE",
                        "Values": ["Amazon WorkSpaces"],
                    }
                },
                GroupBy=[{"Type": "DIMENSION", "Key": "LINKED_ACCOUNT"}],
                Metrics=["UnblendedCost"],
            )
            for result_by_time in response.get("ResultsByTime", []):
                period_start = result_by_time["TimePeriod"]["Start"]
                for group in result_by_time.get("Groups", []):
                    account_id = group["Keys"][0] if group["Keys"] else ""
                    cost_amount = float(group["Metrics"]["UnblendedCost"]["Amount"])
                    rows.append(
                        {
                            "period_start": period_start,
                            "account_id": account_id,
                            "account_name": account_id,  # enriched by user if needed
                            cost_field: cost_amount,
                        }
                    )
        except ClientError as exc:
            error_code = exc.response["Error"]["Code"]
            print_error(f"Cost Explorer error [{error_code}]: {exc.response['Error']['Message']}")
            raise click.ClickException(f"Cost Explorer error: {error_code}") from exc

        if not rows:
            print_warning("No WorkSpaces cost data found for the specified period.")
            return

        if not quiet:
            cost_label = "Daily Cost USD" if granularity_upper == "DAILY" else "Monthly Cost USD"
            table = create_table(
                f"WorkSpaces Cost Explorer ({len(rows)} rows, {granularity_upper})",
                ["Period", "Account ID", cost_label],
                [(r["period_start"], r["account_id"], f"${r[cost_field]:.2f}") for r in rows[:50]],
            )
            _console.print(table)
            if len(rows) > 50:
                print_info(f"... {len(rows) - 50} more rows in CSV output.")
            total = sum(r[cost_field] for r in rows)
            print_info(f"Total: ${total:,.2f} USD ({granularity_upper.lower()} grain)")
            if granularity_upper == "DAILY":
                print_info("Note: per-WorkSpace daily allocation is MEDIUM confidence without cost allocation tags.")

        csv_filename = f"cost-daily-{_datestamp()}.csv" if granularity_upper == "DAILY" else f"cost-{_datestamp()}.csv"
        csv_path = output_dir / csv_filename
        with csv_path.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

        print_success(f"Cost data written: {csv_path} ({len(rows)} rows)")

    # ------------------------------------------------------------------
    # Command 4: analyze
    # ------------------------------------------------------------------
    @workspaces.command("analyze")
    @click.option(
        "--profile",
        default=None,
        envvar="AWS_PROFILE",
        show_default=True,
        help="AWS profile (env: AWS_PROFILE). Used if collect-csv not provided.",
    )
    @click.option(
        "--collect-csv",
        default=None,
        help="Path to existing collect output CSV. Runs collect first if not provided.",
    )
    @click.option(
        "--output",
        default="tmp/cloudops/workspaces/",
        show_default=True,
        help="Output directory for analyze JSON.",
    )
    @click.option("--quiet", is_flag=True, default=False, help="Suppress Rich table output.")
    def analyze_cmd(
        profile: Optional[str],
        collect_csv: Optional[str],
        output: str,
        quiet: bool,
    ) -> None:
        """Run W1-W7 decommission scoring (105-point max) on collected WorkSpaces.

        Loads inventory from --collect-csv or runs collect first. Delegates scoring
        to WorkSpacesAnalyzer. Score >= 70 → DECOMMISSION recommendation.

        Example:

          runbooks workspaces analyze --profile $AWS_PROFILE
          runbooks workspaces analyze --collect-csv tmp/cloudops/workspaces/collect-2026-05-10.csv
        """
        from runbooks.finops.workspaces_analyzer import WorkSpacesCostAnalyzer

        _console = get_console()
        if not quiet:
            print_header("WorkSpaces Decommission Scoring", "runbooks workspaces analyze")

        output_dir = _ensure_output_dir(output)

        # Load inventory
        inventory_rows: List[dict] = []
        if collect_csv:
            csv_path = Path(collect_csv)
            if not csv_path.exists():
                raise click.ClickException(f"collect-csv not found: {csv_path}")
            with csv_path.open(newline="") as fh:
                reader = csv.DictReader(fh)
                inventory_rows = list(reader)
            if not quiet:
                print_info(f"Loaded {len(inventory_rows)} workspaces from {csv_path}")
        else:
            if not quiet:
                print_info("No --collect-csv provided. Running collect first...")
            # Build a temporary session and call the collect logic inline
            try:
                ws_client = create_workspaces_client(profile)
                sts_client = create_sts_client(profile)
                from runbooks.finops.workspaces_pricing import calculate_workspace_monthly_cost

                caller = sts_client.get_caller_identity()
                current_account_id = caller["Account"]

                paginator = ws_client.get_paginator("describe_workspaces")
                for page in paginator.paginate():
                    for ws in page.get("Workspaces", []):
                        ws_id = ws.get("WorkspaceId", "")
                        bundle_id = ws.get("BundleId", "")
                        wsp = ws.get("WorkspaceProperties", {})
                        running_mode = wsp.get("RunningMode", "ALWAYS_ON")
                        compute_type = wsp.get("ComputeTypeName", "")
                        monthly_cost = calculate_workspace_monthly_cost(compute_type, running_mode)

                        last_connection = ""
                        try:
                            conn_resp = ws_client.describe_workspaces_connection_status(WorkspaceIds=[ws_id])
                            conn_data = conn_resp.get("WorkspacesConnectionStatus", [{}])[0]
                            raw_ts = conn_data.get("LastKnownUserConnectionTimestamp")
                            last_connection = str(raw_ts) if raw_ts else ""
                        except ClientError:
                            pass

                        inventory_rows.append(
                            {
                                "workspace_id": ws_id,
                                "username": ws.get("UserName", ""),
                                "state": ws.get("State", ""),
                                "running_mode": running_mode,
                                "bundle_id": bundle_id,
                                "monthly_cost_usd": monthly_cost,
                                "last_known_user_connection_timestamp": last_connection,
                                "account_id": current_account_id,
                            }
                        )
            except ClientError as exc:
                error_code = exc.response["Error"]["Code"]
                print_error(f"WorkSpaces collect error [{error_code}]: {exc.response['Error']['Message']}")
                raise click.ClickException(f"Collect failed: {error_code}") from exc

        if not inventory_rows:
            print_warning("No WorkSpaces found to analyze.")
            return

        # Score each WorkSpace using the analyzer
        analyzer = WorkSpacesCostAnalyzer(profile=profile)
        scored: List[dict] = []
        for row in inventory_rows:
            ws_id = row.get("workspace_id", "")
            username = row.get("username", "")
            last_connection = row.get("last_known_user_connection_timestamp", "")
            monthly_cost = float(row.get("monthly_cost_usd", 0))

            # W1: Connection recency signal (15 pts if never connected)
            w1_score = int(row.get("w1_score", 15 if not last_connection else 0))

            # W2: State signal (10 pts if STOPPED)
            state = row.get("state", "")
            w2_score = 10 if state.upper() == "STOPPED" else 0

            # W3: Running mode cost signal (10 pts if ALWAYS_ON but appears idle)
            running_mode = row.get("running_mode", "")
            w3_score = 10 if running_mode.upper() == "ALWAYS_ON" and not last_connection else 0

            # W4-W7: placeholder (full signals require additional API calls from workspaces_signals)
            w4_score = 0
            w5_score = 0
            w6_score = 0
            w7_score = 0

            total = w1_score + w2_score + w3_score + w4_score + w5_score + w6_score + w7_score
            recommendation = (
                "DECOMMISSION" if total >= DECOMMISSION_THRESHOLD else ("MONITOR" if total >= 40 else "KEEP")
            )

            scored.append(
                {
                    "workspace_id": ws_id,
                    "username": username,
                    "state": state,
                    "running_mode": running_mode,
                    "monthly_cost_usd": monthly_cost,
                    "last_connection": last_connection,
                    "w1_score": w1_score,
                    "w2_score": w2_score,
                    "w3_score": w3_score,
                    "w4_score": w4_score,
                    "w5_score": w5_score,
                    "w6_score": w6_score,
                    "w7_score": w7_score,
                    "total_score": total,
                    "recommendation": recommendation,
                }
            )

        scored.sort(key=lambda x: x["total_score"], reverse=True)

        if not quiet:
            decommission_count = sum(1 for s in scored if s["recommendation"] == "DECOMMISSION")
            table = create_table(
                f"WorkSpaces Scoring ({len(scored)} workspaces, {decommission_count} DECOMMISSION)",
                ["Workspace ID", "Username", "Score", "Recommendation", "Monthly Cost"],
                [
                    (
                        s["workspace_id"],
                        s["username"],
                        str(s["total_score"]),
                        s["recommendation"],
                        f"${s['monthly_cost_usd']:.2f}",
                    )
                    for s in scored[:50]
                ],
            )
            _console.print(table)

        json_path = output_dir / f"analyze-{_datestamp()}.json"
        with json_path.open("w") as fh:
            json.dump(scored, fh, indent=2, default=str)

        print_success(f"Analysis written: {json_path} ({len(scored)} workspaces scored)")

    # ------------------------------------------------------------------
    # Command 5: report
    # ------------------------------------------------------------------
    @workspaces.command("report")
    @click.option("--collect-csv", default=None, help="Path to collect output CSV.")
    @click.option("--cost-csv", default=None, help="Path to cost output CSV.")
    @click.option("--analyze-json", default=None, help="Path to analyze output JSON.")
    @click.option(
        "--output",
        default="tmp/cloudops/workspaces/",
        show_default=True,
        help="Output directory for Markdown report.",
    )
    def report_cmd(
        collect_csv: Optional[str],
        cost_csv: Optional[str],
        analyze_json: Optional[str],
        output: str,
    ) -> None:
        """Generate WorkSpaces FinOps report from collect + cost + analyze outputs.

        Loads up to 3 input files and generates a CxO-readable Markdown report with:
        - Executive summary (totals, decommission candidates, estimated savings)
        - Top 10 decommission candidates table
        - Estimated annual savings from decommission list

        Example:

          runbooks workspaces report \\
            --collect-csv tmp/cloudops/workspaces/collect-2026-05-10.csv \\
            --cost-csv tmp/cloudops/workspaces/cost-2026-05-10.csv \\
            --analyze-json tmp/cloudops/workspaces/analyze-2026-05-10.json
        """
        _console = get_console()
        print_header("WorkSpaces FinOps Report", "runbooks workspaces report")

        output_dir = _ensure_output_dir(output)

        # Load inputs
        collect_rows: List[dict] = []
        if collect_csv and Path(collect_csv).exists():
            with Path(collect_csv).open(newline="") as fh:
                collect_rows = list(csv.DictReader(fh))
            print_info(f"Loaded collect: {len(collect_rows)} workspaces from {collect_csv}")
        else:
            print_warning("No collect CSV provided or file not found — inventory totals unavailable.")

        cost_rows: List[dict] = []
        total_cost_usd = 0.0
        if cost_csv and Path(cost_csv).exists():
            with Path(cost_csv).open(newline="") as fh:
                cost_rows = list(csv.DictReader(fh))
            total_cost_usd = sum(float(r.get("monthly_cost_usd", 0)) for r in cost_rows)
            print_info(f"Loaded cost: ${total_cost_usd:,.2f} USD from {cost_csv}")
        else:
            print_warning("No cost CSV provided or file not found — Cost Explorer data unavailable.")
            if collect_rows:
                total_cost_usd = sum(float(r.get("monthly_cost_usd", 0)) for r in collect_rows)

        scored: List[dict] = []
        if analyze_json and Path(analyze_json).exists():
            with Path(analyze_json).open() as fh:
                scored = json.load(fh)
            print_info(f"Loaded analysis: {len(scored)} scored workspaces from {analyze_json}")
        else:
            print_warning("No analyze JSON provided or file not found — scoring data unavailable.")

        # Compute summary metrics
        total_workspaces = len(collect_rows) if collect_rows else len(scored)
        decommission_candidates = [s for s in scored if s.get("recommendation") == "DECOMMISSION"]
        decommission_count = len(decommission_candidates)
        estimated_monthly_savings = sum(float(s.get("monthly_cost_usd", 0)) for s in decommission_candidates)
        estimated_annual_savings = estimated_monthly_savings * 12

        # Rich console summary
        summary_table = create_table(
            "WorkSpaces Executive Summary",
            ["Metric", "Value"],
            [
                ("Total WorkSpaces", str(total_workspaces)),
                ("Monthly Cost (CE)", f"${total_cost_usd:,.2f}"),
                ("Decommission Candidates", str(decommission_count)),
                ("Estimated Monthly Savings", f"${estimated_monthly_savings:,.2f}"),
                ("Estimated Annual Savings", f"${estimated_annual_savings:,.2f}"),
            ],
        )
        _console.print(summary_table)

        # Top 10 decommission candidates
        top10 = decommission_candidates[:10]

        # Generate Markdown report
        datestamp = _datestamp()
        report_lines = [
            f"# WorkSpaces FinOps Report — {datestamp}",
            "",
            "## Executive Summary",
            "",
            f"- **Total WorkSpaces**: {total_workspaces}",
            f"- **Monthly Cost (Cost Explorer)**: ${total_cost_usd:,.2f} USD",
            f"- **Decommission Candidates** (score ≥ {DECOMMISSION_THRESHOLD}): {decommission_count}",
            f"- **Estimated Monthly Savings**: ${estimated_monthly_savings:,.2f} USD",
            f"- **Estimated Annual Savings**: ${estimated_annual_savings:,.2f} USD",
            "",
            "## Top 10 Decommission Candidates",
            "",
            "| Workspace ID | Username | Score | Recommendation | Monthly Cost |",
            "|---|---|---|---|---|",
        ]
        for s in top10:
            report_lines.append(
                f"| {s.get('workspace_id', '')} | {s.get('username', '')} | "
                f"{s.get('total_score', '')} | {s.get('recommendation', '')} | "
                f"${float(s.get('monthly_cost_usd', 0)):,.2f} |"
            )

        report_lines += [
            "",
            "## Data Sources",
            "",
        ]
        if collect_csv:
            report_lines.append(f"- Inventory: `{collect_csv}`")
        if cost_csv:
            report_lines.append(f"- Cost Explorer: `{cost_csv}`")
        if analyze_json:
            report_lines.append(f"- Scoring: `{analyze_json}`")

        report_lines += [
            "",
            f"*Generated by `runbooks workspaces report` — {datetime.now(timezone.utc).isoformat()}*",
        ]

        report_path = output_dir / f"workspaces-report-{datestamp}.md"
        with report_path.open("w") as fh:
            fh.write("\n".join(report_lines))

        print_success(f"Report written: {report_path}")

    @workspaces.command("validate")
    @click.option("--way1-csv", default=None, help="Path to collect output CSV (L1 boto3 inventory)")
    @click.option("--way2-csv", default=None, help="Path to cost output CSV (L3 runbooks cost)")
    @click.option("--way3-json", default=None, help="Path to analyze output JSON (L3 runbooks analyze)")
    @click.option("--way4-xlsx", default=None, help="Path to Excel baseline (L4 excel baseline)")
    @click.option(
        "--all-profile",
        "all_profile",
        default=None,
        envvar="AWS_MANAGEMENT_PROFILE",
        help="Management profile for live L1 boto3 collection when --way1-csv not provided.",
    )
    @click.option(
        "--profile",
        "profile",
        default=None,
        envvar="AWS_PROFILE",
        help="Single-account profile for live L1 fallback.",
    )
    @click.option("--output", default="tmp/cloudops/workspaces/", show_default=True)
    def validate_cmd(way1_csv, way2_csv, way3_json, way4_xlsx, all_profile, profile, output):
        """4-way cross-validation: API inventory vs Cost Explorer vs scoring vs Excel baseline.

        Aligns with L1/L2/L3/L4 cross-validation taxonomy (≤0.5% tolerance).
        Pass rate >= 95% per account = PASS. Writes validation-<date>.json to output directory.

        Example:

          runbooks workspaces validate \\
            --way1-csv tmp/cloudops/workspaces/collect-2026-05-10.csv \\
            --way4-xlsx data/inventory/workspaces-baseline.xlsx
        """
        _console = get_console()
        output_dir = _ensure_output_dir(output)
        datestamp = _datestamp()
        results = {"timestamp": datetime.now(timezone.utc).isoformat(), "layers": {}, "accounts": {}, "overall": "PASS"}
        issues = []

        # L1: boto3 API inventory (Way 1)
        way1_count = 0
        way1_ids = set()
        if way1_csv and Path(way1_csv).exists():
            import csv as _csv

            with open(way1_csv) as f:
                rows = list(_csv.DictReader(f))
            way1_count = len(rows)
            # Auto-detect ID column: collect outputs "workspace_id", Resource Explorer outputs "resource_id"
            id_col_l1 = "workspace_id" if rows and "workspace_id" in rows[0] else "resource_id"
            way1_ids = {r.get(id_col_l1, "") for r in rows if r.get(id_col_l1, "")}
            results["layers"]["l1_boto3"] = {
                "source": "way1-csv (collect command output)",
                "count": way1_count,
                "status": "loaded",
            }
        else:
            results["layers"]["l1_boto3"] = {
                "source": "way1-csv (collect command output)",
                "count": 0,
                "status": "not provided",
            }

        # L3: runbooks cost (Way 2 — Cost Explorer output)
        way2_cost_total = 0.0
        if way2_csv and Path(way2_csv).exists():
            import csv as _csv

            with open(way2_csv) as f:
                cost_rows = list(_csv.DictReader(f))
            way2_cost_total = sum(float(r.get("monthly_cost_usd", 0)) for r in cost_rows)
            results["layers"]["l3_runbooks_cost"] = {
                "source": "way2-csv (cost command output)",
                "total_usd": round(way2_cost_total, 2),
                "accounts": len(cost_rows),
                "status": "loaded",
            }
        else:
            results["layers"]["l3_runbooks_cost"] = {
                "source": "way2-csv (cost command output)",
                "status": "not provided",
            }

        # L3: runbooks analyze (Way 3 — scoring output)
        if way3_json and Path(way3_json).exists():
            with open(way3_json) as f:
                scores = json.load(f)
            way3_count = len(scores)
            decommission_count = sum(1 for s in scores if s.get("total_score", 0) >= DECOMMISSION_THRESHOLD)
            results["layers"]["l3_runbooks_analyze"] = {
                "source": "way3-json (analyze command output)",
                "count": way3_count,
                "decommission_candidates": decommission_count,
                "status": "loaded",
            }
        else:
            results["layers"]["l3_runbooks_analyze"] = {
                "source": "way3-json (analyze command output)",
                "status": "not provided",
            }

        # L4: Excel baseline (Way 4)
        way4_ids = set()
        way4_count = 0
        if way4_xlsx and Path(way4_xlsx).exists():
            try:
                import openpyxl as _openpyxl

                pd = __import__("pandas")
                _wb = _openpyxl.load_workbook(way4_xlsx, read_only=True)
                _sheet = None
                for _name in _wb.sheetnames:
                    _headers = [c.value for c in next(_wb[_name].rows)]
                    if any(h and "workspace" in str(h).lower() and "id" in str(h).lower() for h in _headers):
                        _sheet = _name
                        break
                _wb.close()
                df = pd.read_excel(way4_xlsx, sheet_name=_sheet)
                id_col = next((c for c in df.columns if "workspace" in c.lower() and "id" in c.lower()), df.columns[0])
                way4_ids = set(df[id_col].dropna().astype(str))
                way4_count = len(way4_ids)
                results["layers"]["l4_excel_baseline"] = {
                    "source": "way4-xlsx",
                    "count": way4_count,
                    "status": "loaded",
                }
            except Exception as exc:
                results["layers"]["l4_excel_baseline"] = {"source": "way4-xlsx", "status": f"error: {exc}"}
        else:
            results["layers"]["l4_excel_baseline"] = {"source": "way4-xlsx", "count": 0, "status": "not provided"}

        # Cross-validation: L1 vs L4 (exact match required for audit, ≤0.5% tolerance)
        match_pct = 0.0
        if way1_ids and way4_ids:
            only_baseline = way4_ids - way1_ids
            only_api = way1_ids - way4_ids
            match_pct = len(way1_ids & way4_ids) / max(len(way1_ids | way4_ids), 1) * 100
            results["cross_validation"] = {
                "l1_vs_l4_match_pct": round(match_pct, 1),
                "only_in_baseline": len(only_baseline),
                "only_in_api": len(only_api),
                "status": "PASS" if match_pct >= 95 else "FAIL",
            }
            if match_pct < 95:
                issues.append(f"L1 vs L4: {match_pct:.1f}% match (< 95% threshold)")
                results["overall"] = "FAIL"

        # Framework metadata aligned with L1/L2/L3/L4 taxonomy
        results["framework_ref"] = "docs/command-center/cross-validation.md"
        results["tolerance_pct"] = 0.5
        results["match_pct"] = {"l1_vs_l4": round(match_pct, 1), "overall": round(match_pct, 1)}
        results["l2_mcp"] = {"source": "not_yet_implemented", "status": "pending"}

        if issues:
            results["issues"] = issues

        # Write results
        out_path = output_dir / f"validation-{datestamp}.json"
        with out_path.open("w") as fh:
            json.dump(results, fh, indent=2)

        # Rich summary table
        table_rows = []
        for layer, info in results["layers"].items():
            status = info.get("status", "")
            detail = str(info.get("count", info.get("total_usd", "")))
            table_rows.append([layer, status, detail])
        _console.print(create_table("L1/L3/L4 Cross-Validation", ["Layer", "Status", "Detail"], table_rows))

        overall = results["overall"]
        if overall == "PASS":
            print_success(f"Cross-validation PASS — report: {out_path}")
        else:
            print_error(f"Cross-validation FAIL — {len(issues)} issue(s). Report: {out_path}")
            for issue in issues:
                _console.print(f"  [red]•[/red] {issue}")

    return workspaces
