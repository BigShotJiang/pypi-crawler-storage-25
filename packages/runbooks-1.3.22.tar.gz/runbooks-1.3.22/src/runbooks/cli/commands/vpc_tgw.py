"""
TGW CLI Subgroup — `runbooks vpc tgw`

Implements the 5 TGW subcommands per RQ2-S1 P0 (ADLC sprint 2026-04-28):
  discover    — multi-account TGW discovery (Phase 1)
  hub-binding — hub identification with hub_score formula (Phase 3)
  routes      — route table analysis
  hybrid      — hybrid connectivity (DX + VPN + peerings)
  diagram     — render PNG diagrams from evidence

STD-S3 compliance (cli-claude-command-parity.md):
  Verb names use kebab-case to match future L2 wrapper names:
    discover     → /vpc:tgw-discover
    hub-binding  → /vpc:tgw-hub-binding
    routes       → /vpc:tgw-routes
    hybrid       → /vpc:tgw-hybrid
    diagram      → /vpc:tgw-diagram

READONLY autonomous (operational-efficiency.md Rule 8):
  All subcommands use describe/list/get only. No mutations.

Profile semantics (aws-profile-semantics.md):
  discover uses --management-profile ($AWS_MANAGEMENT_PROFILE)
  routes/hybrid use --hub-profile (per-workload)
"""

import json
import os
import sys
from pathlib import Path
from typing import Optional

import click

from runbooks.common.error_handling import handle_aws_errors
from runbooks.common.rich_utils import (
    BOX_PRIMARY,
    console,
    create_table,
    get_console,
    print_error,
    print_header,
    print_info,
    print_success,
    print_warning,
)

_DEFAULT_EVIDENCE_DIR = "tmp/cloud-infrastructure/tgw-investigation"
_DEFAULT_OUTPUT_DIR = "cloudops/docs/static/diagrams"


def create_tgw_group():
    """
    Create the tgw command group — registered as a subgroup of vpc.

    Lazy creation pattern matching registry.py convention.
    Returns Click Group object with 5 subcommands.
    """
    from runbooks.common.rich_utils import create_rich_group_class

    _categories = {
        "Discovery": [
            ("discover", "Multi-account TGW discovery (Phase 1)"),
            ("hub-binding", "Identify hub TGW via hub_score formula (Phase 3)"),
        ],
        "Analysis": [
            ("routes", "Route table analysis and blackhole detection"),
            ("hybrid", "Hybrid connectivity — DX + VPN + peerings"),
        ],
        "Visualization": [
            ("diagram", "Render PNG diagrams from evidence (types: topology|hybrid|route-flow|all)"),
        ],
    }

    @click.group(
        cls=create_rich_group_class(
            categories=_categories,
            title_prefix="TGW Commands",
            footer_lines=[
                "\n[blue]Usage: runbooks vpc tgw [COMMAND] [OPTIONS][/blue]",
                "[blue]Example: runbooks vpc tgw discover --management-profile $AWS_MANAGEMENT_PROFILE[/blue]",
                "[dim]READONLY — no mutations. All commands require READONLY profile.[/dim]",
            ],
        ),
        invoke_without_command=True,
        name="tgw",
    )
    @click.pass_context
    def tgw_group(ctx):
        """
        Transit Gateway multi-account discovery and analysis.

        \b
        TGW Workflow (sequential phases):
        ├── Phase 1: discover    — org-wide TGW inventory
        ├── Phase 3: hub-binding — identify network hub TGW
        ├── Phase 4: routes      — route table analysis
        ├── Phase 5: hybrid      — DX / VPN connectivity
        └── Visual:  diagram     — PNG architecture diagrams

        \b
        Examples:
            runbooks vpc tgw discover --management-profile $AWS_MANAGEMENT_PROFILE
            runbooks vpc tgw hub-binding --evidence tmp/cloud-infrastructure/tgw-investigation/phase1-org-aggregate.json
            runbooks vpc tgw routes --hub-profile $AWS_OPERATIONS_PROFILE --tgw-id tgw-abc123
            runbooks vpc tgw hybrid --hub-profile $AWS_OPERATIONS_PROFILE
            runbooks vpc tgw diagram --type all --evidence-dir tmp/cloud-infrastructure/tgw-investigation/
        """
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # ── discover ────────────────────────────────────────────────────────────

    @tgw_group.command("discover")
    @click.option(
        "--management-profile",
        envvar="AWS_MANAGEMENT_PROFILE",
        required=True,
        help="AWS profile for Organizations list-accounts (env: $AWS_MANAGEMENT_PROFILE)",
    )
    @click.option(
        "--region",
        envvar="AWS_REGION",
        default="ap-southeast-2",
        show_default=True,
        help="AWS region (env: $AWS_REGION)",
    )
    @click.option(
        "--output",
        "output_path",
        type=click.Path(),
        default=f"{_DEFAULT_EVIDENCE_DIR}/phase1-org-aggregate.json",
        show_default=True,
        help="Output JSON evidence file",
    )
    @handle_aws_errors(module_name="vpc-tgw-discover")
    def discover(management_profile: str, region: str, output_path: str):
        """
        Multi-account TGW discovery (Phase 1).

        \b
        Workflow:
          1. list-accounts via Organizations ($AWS_MANAGEMENT_PROFILE)
          2. Resolve per-account profiles from ~/.aws/config
          3. STS verify each account (prevents CROSS_ACCOUNT_SILENT_ZERO)
          4. describe-transit-gateways + describe-transit-gateway-attachments
          5. Aggregate JSON + Rich table

        \b
        Profile Semantics (aws-profile-semantics.md):
          --management-profile → Organizations only (NOT for EC2/TGW queries)
          Per-workload profiles resolved from ~/.aws/config for item 4

        \b
        READONLY — no mutations.

        \b
        Examples:
            runbooks vpc tgw discover --management-profile $AWS_MANAGEMENT_PROFILE
            runbooks vpc tgw discover --management-profile my-mgmt-profile --region ap-southeast-2
        """
        try:
            from runbooks.vpc.tgw_orchestrator import discover_tgws
            from runbooks.vpc.tgw_validator import validate_tgw_profiles
        except ImportError as exc:
            print_error(f"TGW orchestrator module not available: {exc}")
            sys.exit(1)

        # Profile validation (WARN on mismatch, hard fail on ProfileNotFound)
        validate_tgw_profiles(management_profile=management_profile, region=region)

        result = discover_tgws(
            management_profile=management_profile,
            region=region,
            output_path=output_path,
        )
        return result

    # ── hub-binding ─────────────────────────────────────────────────────────

    @tgw_group.command("hub-binding")
    @click.option(
        "--evidence",
        "evidence_path",
        type=click.Path(exists=False),
        default=f"{_DEFAULT_EVIDENCE_DIR}/phase1-org-aggregate.json",
        show_default=True,
        help="Phase 1 discover JSON evidence file",
    )
    @click.option(
        "--output",
        "output_path",
        type=click.Path(),
        default=f"{_DEFAULT_EVIDENCE_DIR}/phase3-hub-binding.json",
        show_default=True,
        help="Output JSON evidence file",
    )
    @click.option(
        "--network-ou-id",
        default=None,
        help="Optional AWS Organizations Network OU ID for NetworkOU signal",
    )
    @click.option(
        "--terraform-state",
        "terraform_state_path",
        type=click.Path(),
        default=None,
        help="Optional path to terraform.tfstate for IaC managed signal",
    )
    @handle_aws_errors(module_name="vpc-tgw-hub-binding")
    def hub_binding(
        evidence_path: str,
        output_path: str,
        network_ou_id: Optional[str],
        terraform_state_path: Optional[str],
    ):
        """
        Identify hub TGW via hub_score formula (Phase 3).

        \b
        Hub Score Formula (transit-gateway-operations v3.0.0):
          hub_score = 0.40·attachment_count_norm
                    + 0.30·NetworkOU
                    + 0.20·RAM_owner_SELF
                    + 0.10·tf_managed

        Verdict: HUB if score >= 0.80 AND delta >= 0.15 vs next TGW.
        Otherwise: AMBIGUOUS_HUB.

        \b
        Examples:
            runbooks vpc tgw hub-binding
            runbooks vpc tgw hub-binding --evidence phase1-org-aggregate.json --network-ou-id ou-abc123
            runbooks vpc tgw hub-binding --terraform-state terraform/network/terraform.tfstate
        """
        try:
            from runbooks.vpc.tgw_orchestrator import bind_hub
        except ImportError as exc:
            print_error(f"TGW orchestrator module not available: {exc}")
            sys.exit(1)

        result = bind_hub(
            evidence_path=evidence_path,
            output_path=output_path,
            network_ou_id=network_ou_id,
            terraform_state_path=terraform_state_path,
        )
        return result

    # ── routes ──────────────────────────────────────────────────────────────

    @tgw_group.command("routes")
    @click.option(
        "--hub-profile",
        envvar="AWS_OPERATIONS_PROFILE",
        required=True,
        help="AWS profile for hub account TGW route queries (env: $AWS_OPERATIONS_PROFILE)",
    )
    @click.option(
        "--tgw-id",
        required=True,
        help="Transit Gateway ID to analyze (e.g. tgw-abc123)",
    )
    @click.option(
        "--region",
        envvar="AWS_REGION",
        default="ap-southeast-2",
        show_default=True,
        help="AWS region",
    )
    @click.option(
        "--output",
        "output_path",
        type=click.Path(),
        default=f"{_DEFAULT_EVIDENCE_DIR}/phase4-routes.json",
        show_default=True,
        help="Output JSON evidence file",
    )
    @handle_aws_errors(module_name="vpc-tgw-routes")
    def routes(hub_profile: str, tgw_id: str, region: str, output_path: str):
        """
        Analyze TGW route tables and detect blackhole routes.

        \b
        Queries:
          - describe-transit-gateway-route-tables
          - search-transit-gateway-routes (blackhole detection)

        \b
        READONLY — no mutations.

        \b
        Examples:
            runbooks vpc tgw routes --hub-profile $AWS_OPERATIONS_PROFILE --tgw-id tgw-089aa9c2212845b28
        """
        try:
            from runbooks.vpc.transit_gateway_manager import TransitGatewayManager
        except ImportError as exc:
            print_error(f"TransitGatewayManager not available: {exc}")
            sys.exit(1)

        print_header("TGW Route Table Analysis", version="1.0.0")
        print_info(f"Hub profile: {hub_profile}")
        print_info(f"TGW ID: {tgw_id}")
        print_info(f"Region: {region}")

        manager = TransitGatewayManager(region=region, profile=hub_profile, console=get_console())

        # Reuse existing topology analysis for route tables
        topology = manager.analyze_topology()

        # Filter to the requested TGW
        target_tgw = next(
            (t for t in topology.get("transit_gateways", []) if t["transit_gateway_id"] == tgw_id),
            None,
        )

        if target_tgw is None:
            print_warning(f"TGW {tgw_id} not found in account {hub_profile}. Check profile/region.")
            return {}

        # Get route tables and search for blackholes
        try:
            session = __import__("boto3").Session(profile_name=hub_profile)
            ec2 = session.client("ec2", region_name=region)
            from botocore.config import Config as _Config

            ec2 = session.client(
                "ec2", region_name=region, config=_Config(retries={"max_attempts": 3, "mode": "adaptive"})
            )

            rt_paginator = ec2.get_paginator("describe_transit_gateway_route_tables")
            route_tables = []
            for page in rt_paginator.paginate(Filters=[{"Name": "transit-gateway-id", "Values": [tgw_id]}]):
                route_tables.extend(page.get("TransitGatewayRouteTables", []))

            blackholes = []
            for rt in route_tables:
                rt_id = rt["TransitGatewayRouteTableId"]
                bh_response = ec2.search_transit_gateway_routes(
                    TransitGatewayRouteTableId=rt_id,
                    Filters=[{"Name": "state", "Values": ["blackhole"]}],
                )
                bh_routes = bh_response.get("Routes", [])
                if bh_routes:
                    blackholes.extend([{"route_table_id": rt_id, **r} for r in bh_routes])

        except Exception as exc:
            print_error(f"Route table query failed: {exc}")
            return {}

        result = {
            "tgw_id": tgw_id,
            "hub_profile": hub_profile,
            "region": region,
            "route_tables": [
                {
                    "route_table_id": rt["TransitGatewayRouteTableId"],
                    "state": rt["State"],
                    "default_association": rt.get("DefaultAssociationRouteTable", False),
                    "default_propagation": rt.get("DefaultPropagationRouteTable", False),
                    "routes": [],  # routes queried separately via search-transit-gateway-routes
                }
                for rt in route_tables
            ],
            "blackhole_count": len(blackholes),
            "blackholes": blackholes,
        }

        # Display
        table = create_table(
            title=f"Route Tables — {tgw_id}",
            columns=[
                {"name": "RT ID", "justify": "left"},
                {"name": "State", "justify": "center"},
                {"name": "Default Assoc", "justify": "center"},
                {"name": "Default Prop", "justify": "center"},
            ],
        )
        for rt in result["route_tables"]:
            state_color = "green" if rt["state"] == "available" else "yellow"
            table.add_row(
                rt["route_table_id"],
                f"[{state_color}]{rt['state']}[/{state_color}]",
                "[green]Yes[/green]" if rt["default_association"] else "No",
                "[green]Yes[/green]" if rt["default_propagation"] else "No",
            )
        console.print(table)

        if blackholes:
            print_warning(f"[yellow]Found {len(blackholes)} blackhole route(s) — review required![/yellow]")
            bh_table = create_table(
                title="Blackhole Routes",
                columns=[
                    {"name": "Route Table", "justify": "left"},
                    {"name": "Destination CIDR", "justify": "left"},
                    {"name": "State", "justify": "center"},
                ],
            )
            for bh in blackholes[:20]:
                bh_table.add_row(
                    bh.get("route_table_id", ""),
                    bh.get("DestinationCidrBlock", ""),
                    "[red]blackhole[/red]",
                )
            console.print(bh_table)
        else:
            print_success("No blackhole routes found.")

        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w") as f:
            json.dump(result, f, indent=2, default=str)
        print_success(f"Route evidence: {output_path}")

        return result

    # ── hybrid ──────────────────────────────────────────────────────────────

    @tgw_group.command("hybrid")
    @click.option(
        "--hub-profile",
        envvar="AWS_OPERATIONS_PROFILE",
        required=True,
        help="AWS profile for hub account queries (env: $AWS_OPERATIONS_PROFILE)",
    )
    @click.option(
        "--management-profile",
        envvar="AWS_MANAGEMENT_PROFILE",
        default=None,
        help="AWS profile for Organizations queries (env: $AWS_MANAGEMENT_PROFILE)",
    )
    @click.option(
        "--region",
        envvar="AWS_REGION",
        default="ap-southeast-2",
        show_default=True,
        help="AWS region",
    )
    @click.option(
        "--output",
        "output_path",
        type=click.Path(),
        default=f"{_DEFAULT_EVIDENCE_DIR}/phase5-hybrid.json",
        show_default=True,
        help="Output JSON evidence file",
    )
    @handle_aws_errors(module_name="vpc-tgw-hybrid")
    def hybrid(
        hub_profile: str,
        management_profile: Optional[str],
        region: str,
        output_path: str,
    ):
        """
        Hybrid connectivity analysis — DX, VPN, TGW peerings.

        \b
        Queries:
          - describe-direct-connect-gateways
          - describe-vpn-connections
          - describe-transit-gateway-peering-attachments

        \b
        READONLY — no mutations.

        \b
        Examples:
            runbooks vpc tgw hybrid --hub-profile $AWS_OPERATIONS_PROFILE
            runbooks vpc tgw hybrid --hub-profile ops-profile --management-profile mgmt-profile
        """
        print_header("TGW Hybrid Connectivity Analysis", version="1.0.0")
        print_info(f"Hub profile: {hub_profile}")
        print_info(f"Region: {region}")

        import boto3 as _boto3
        from botocore.config import Config as _Config

        _retry_cfg = _Config(retries={"max_attempts": 3, "mode": "adaptive"})

        try:
            session = _boto3.Session(profile_name=hub_profile)

            # DX gateways
            dx_client = session.client("directconnect", region_name=region, config=_retry_cfg)
            dx_response = dx_client.describe_direct_connect_gateways()
            dx_gateways = dx_response.get("directConnectGateways", [])

            # VPN connections (EC2 API)
            ec2 = session.client("ec2", region_name=region, config=_retry_cfg)
            vpn_paginator = ec2.get_paginator("describe_vpn_connections")
            vpn_connections = []
            for page in vpn_paginator.paginate():
                vpn_connections.extend(page.get("VpnConnections", []))

            # TGW peering attachments
            peering_paginator = ec2.get_paginator("describe_transit_gateway_peering_attachments")
            peering_attachments = []
            for page in peering_paginator.paginate():
                peering_attachments.extend(page.get("TransitGatewayPeeringAttachments", []))

        except Exception as exc:
            print_error(f"Hybrid connectivity query failed: {exc}")
            sys.exit(1)

        result = {
            "hub_profile": hub_profile,
            "region": region,
            "direct_connect_gateways": [
                {
                    "dx_gateway_id": dx.get("directConnectGatewayId"),
                    "name": dx.get("directConnectGatewayName"),
                    "state": dx.get("directConnectGatewayState"),
                    "amazon_side_asn": dx.get("amazonSideAsn"),
                    "owner_account": dx.get("ownerAccount"),
                }
                for dx in dx_gateways
            ],
            "vpn_connections": [
                {
                    "vpn_id": vpn.get("VpnConnectionId"),
                    "state": vpn.get("State"),
                    "type": vpn.get("Type"),
                    "customer_gateway_id": vpn.get("CustomerGatewayId"),
                }
                for vpn in vpn_connections
            ],
            "tgw_peerings": [
                {
                    "attachment_id": p.get("TransitGatewayAttachmentId"),
                    "requester_tgw": p.get("RequesterTgwInfo", {}).get("TransitGatewayId"),
                    "requester_account": p.get("RequesterTgwInfo", {}).get("OwnerId"),
                    "accepter_tgw": p.get("AccepterTgwInfo", {}).get("TransitGatewayId"),
                    "accepter_account": p.get("AccepterTgwInfo", {}).get("OwnerId"),
                    "state": p.get("State"),
                }
                for p in peering_attachments
            ],
        }

        # Display summary table
        table = create_table(
            title="Hybrid Connectivity Summary",
            columns=[
                {"name": "Component", "justify": "left"},
                {"name": "Count", "justify": "right"},
                {"name": "Details", "justify": "left"},
            ],
        )
        table.add_row("Direct Connect Gateways", str(len(dx_gateways)), f"Region: {region}")
        table.add_row("VPN Connections", str(len(vpn_connections)), f"Region: {region}")
        table.add_row("TGW Peerings", str(len(peering_attachments)), f"Region: {region}")
        console.print(table)

        # DX detail
        if dx_gateways:
            dx_table = create_table(
                title="Direct Connect Gateways",
                columns=[
                    {"name": "DX Gateway ID", "justify": "left"},
                    {"name": "Name", "justify": "left"},
                    {"name": "State", "justify": "center"},
                    {"name": "Owner", "justify": "left"},
                ],
            )
            for dx in result["direct_connect_gateways"]:
                state_color = "green" if dx["state"] == "available" else "yellow"
                dx_table.add_row(
                    dx["dx_gateway_id"] or "—",
                    dx["name"] or "—",
                    f"[{state_color}]{dx['state']}[/{state_color}]",
                    dx["owner_account"] or "—",
                )
            console.print(dx_table)

        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w") as f:
            json.dump(result, f, indent=2, default=str)
        print_success(f"Hybrid connectivity evidence: {output_path}")

        return result

    # ── diagram ─────────────────────────────────────────────────────────────

    @tgw_group.command("diagram")
    @click.option(
        "--type",
        "diagram_type",
        type=click.Choice(["topology", "hybrid", "route-flow", "all"], case_sensitive=False),
        default="all",
        show_default=True,
        help="Diagram type(s) to render",
    )
    @click.option(
        "--evidence-dir",
        type=click.Path(),
        default=_DEFAULT_EVIDENCE_DIR,
        show_default=True,
        help="Evidence directory (from discover/hub-binding outputs)",
    )
    @click.option(
        "--output-dir",
        type=click.Path(),
        default=_DEFAULT_OUTPUT_DIR,
        show_default=True,
        help="Output directory for PNG files",
    )
    @handle_aws_errors(module_name="vpc-tgw-diagram")
    def diagram(diagram_type: str, evidence_dir: str, output_dir: str):
        """
        Render TGW PNG diagrams from evidence (no AWS API calls).

        \b
        Types:
          topology   — hub-spoke topology with account groups
          hybrid     — hybrid connectivity (DX + peerings + on-prem)
          route-flow — route table architecture (Main-RT vs Spokes-RT)
          all        — all three diagrams

        \b
        PNG quality gate: >= 100 KB (diagram-standards.md).
        Requires diagrams library: uv add 'diagrams[all]'

        \b
        Examples:
            runbooks vpc tgw diagram --type all
            runbooks vpc tgw diagram --type topology --output-dir docs/static/diagrams/tgw
            runbooks vpc tgw diagram --type hybrid --evidence-dir tmp/cloud-infrastructure/tgw-investigation/
        """
        print_header("TGW Diagram Generation", version="1.0.0")
        print_info(f"Type: {diagram_type}")
        print_info(f"Evidence dir: {evidence_dir}")
        print_info(f"Output dir: {output_dir}")

        try:
            from runbooks.vpc.diagrams.discovery_loaders import validate_png_size
            from runbooks.vpc.diagrams.tgw_hub_spoke_topology import (
                generate_diagram as gen_topology,
            )
            from runbooks.vpc.diagrams.tgw_hub_spoke_topology import (
                load_discovery_data,
            )
            from runbooks.vpc.diagrams.tgw_hybrid_connectivity import (
                generate_diagram as gen_hybrid,
            )
            from runbooks.vpc.diagrams.tgw_hybrid_connectivity import (
                load_data as load_hybrid,
            )
            from runbooks.vpc.diagrams.tgw_route_table_flow import (
                generate_diagram as gen_route,
            )
            from runbooks.vpc.diagrams.tgw_route_table_flow import (
                load_data as load_route,
            )
        except ImportError as exc:
            print_error(f"Diagram modules not available: {exc}")
            sys.exit(1)

        Path(output_dir).mkdir(parents=True, exist_ok=True)

        generated = []
        errors = []

        def _render(name: str, loader, generator, ev_dir: str, out_dir: str):
            try:
                data = loader(ev_dir)
                png = generator(data, out_dir)
                size = validate_png_size(png)
                print_success(f"{name}: {png} ({size:,} bytes)")
                generated.append(png)
            except FileNotFoundError as exc:
                errors.append(f"{name}: evidence missing — {exc}")
                print_error(f"{name}: {exc}")
            except RuntimeError as exc:
                errors.append(f"{name}: {exc}")
                print_error(f"{name}: {exc}")
            except ValueError as exc:
                errors.append(f"{name}: PNG quality gate failed — {exc}")
                print_error(f"{name}: {exc}")

        types_to_render = ["topology", "hybrid", "route-flow"] if diagram_type == "all" else [diagram_type]

        for t in types_to_render:
            if t == "topology":
                _render("hub-spoke topology", load_discovery_data, gen_topology, evidence_dir, output_dir)
            elif t == "hybrid":
                _render("hybrid connectivity", load_hybrid, gen_hybrid, evidence_dir, output_dir)
            elif t == "route-flow":
                _render("route table flow", load_route, gen_route, evidence_dir, output_dir)

        # Summary
        table = create_table(
            title="Diagram Generation Summary",
            columns=[
                {"name": "Result", "justify": "center"},
                {"name": "Path", "justify": "left"},
            ],
        )
        for png in generated:
            table.add_row("[green]PASS[/green]", png)
        for err in errors:
            table.add_row("[red]FAIL[/red]", err)
        console.print(table)

        if errors and not generated:
            sys.exit(1)

        return {"generated": generated, "errors": errors}

    return tgw_group


# Expose for direct import in tests and vpc.py registration
tgw_group = create_tgw_group()
