"""
Common CLI Decorators for Modular Commands — DEPRECATED MODULE

All functions in this module have been consolidated into
``runbooks.common.cli_decorators``. This file is retained purely for
backward-compatibility and will emit a ``DeprecationWarning`` on every
import.

Migration: replace any import of the form::

    from runbooks.common.decorators import <name>

with::

    from runbooks.common.cli_decorators import <name>
"""

import warnings as _warnings

# Re-export everything from the canonical module so existing callers still work.
from runbooks.common.cli_decorators import (  # noqa: F401
    common_aws_options,
    common_filter_options,
    common_output_options,
    enterprise_audit_trail,
    error_handler,
    performance_timing,
    require_aws_profile,
    rich_progress,
)


def _warn(name: str) -> None:
    _warnings.warn(
        f"'{name}' imported from runbooks.common.decorators is deprecated. Use runbooks.common.cli_decorators instead.",
        DeprecationWarning,
        stacklevel=3,
    )


# Emit the warning at import time so any surviving consumer is notified
# without requiring them to call the decorated function first.
_warn("runbooks.common.decorators (module)")
