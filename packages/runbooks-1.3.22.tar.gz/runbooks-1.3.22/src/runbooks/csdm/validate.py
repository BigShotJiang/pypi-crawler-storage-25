"""Validate CSDM/JSM bridge exports for a tenant against required schema constraints."""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table

console = Console()


def validate_cmdb(tenant: str, tenants_root: Path) -> list[str]:
    """Return list of error strings (empty list = pass).

    Args:
        tenant: tenant directory name (e.g. 'b2b-energy')
        tenants_root: absolute path to the tenants/ directory
    """
    errors: list[str] = []
    tenant_dir = tenants_root / tenant
    latest = tenant_dir / "cmdb-integration" / "cmdb.csv"
    if not latest.exists():
        errors.append(f"[CMDB] no cmdb.csv found in {tenant_dir / 'cmdb-integration'}; run task csdm:export-snow first")
        return errors

    seen_ids: set[str] = set()
    row_count = 0
    required = ["ci_type", "cmdb_id", "name", "owned_by", "support_group",
                "aws_account_id", "last_discovered", "discovery_confidence_pct"]

    with open(latest, "r", encoding="utf-8") as f:
        first = f.readline()
        if not first.startswith("#"):
            f.seek(0)
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            errors.append(f"[CMDB] {latest.name}: empty file or no header")
            return errors
        missing = [c for c in required if c not in reader.fieldnames]
        if missing:
            errors.append(f"[CMDB] {latest.name}: missing required columns: {missing}")
            return errors

        for row in reader:
            row_count += 1
            cid = row.get("cmdb_id", "")
            if cid in seen_ids:
                errors.append(f"[CMDB] {latest.name}: duplicate cmdb_id={cid!r}")
            seen_ids.add(cid)
            try:
                conf = int(row.get("discovery_confidence_pct", "0"))
                if not 0 <= conf <= 100:
                    errors.append(f"[CMDB] {cid}: discovery_confidence_pct out of range: {conf}")
            except ValueError:
                errors.append(f"[CMDB] {cid}: discovery_confidence_pct not an integer: {row.get('discovery_confidence_pct')!r}")
            acct = row.get("aws_account_id", "")
            if not acct.isdigit() or len(acct) != 12:
                errors.append(f"[CMDB] {cid}: aws_account_id must be 12 digits, got {acct!r}")

    if row_count == 0:
        errors.append(f"[CMDB] {latest.name}: zero data rows")
    return errors


def validate_jsm(tenant: str, tenants_root: Path) -> list[str]:
    """Return list of error strings (empty list = pass).

    Args:
        tenant: tenant directory name (e.g. 'b2b-energy')
        tenants_root: absolute path to the tenants/ directory
    """
    errors: list[str] = []
    tenant_dir = tenants_root / tenant
    latest = tenant_dir / "cmdb-integration" / "jsm.csv"
    if not latest.exists():
        errors.append(f"[JSM] no jsm.csv found in {tenant_dir / 'cmdb-integration'}; run task csdm:export-jsm first")
        return errors

    seen_keys: set[str] = set()
    row_count = 0
    required = ["object_type", "object_key", "name", "attributes_json", "owner", "last_updated"]

    with open(latest, "r", encoding="utf-8") as f:
        first = f.readline()
        if not first.startswith("#"):
            f.seek(0)
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            errors.append(f"[JSM] {latest.name}: empty file or no header")
            return errors
        missing = [c for c in required if c not in reader.fieldnames]
        if missing:
            errors.append(f"[JSM] {latest.name}: missing required columns: {missing}")
            return errors

        for row in reader:
            row_count += 1
            k = row.get("object_key", "")
            if k in seen_keys:
                errors.append(f"[JSM] {latest.name}: duplicate object_key={k!r}")
            seen_keys.add(k)

    if row_count == 0:
        errors.append(f"[JSM] {latest.name}: zero data rows")
    return errors


def main() -> None:
    """CLI entry point: validate bridge exports for a tenant."""
    ap = argparse.ArgumentParser(description="Validate CSDM/JSM bridge exports for a tenant")
    ap.add_argument("--tenant", required=True, help="tenant directory name, e.g. b2b-energy")
    ap.add_argument("--tenants-root", default="tenants", help="path to tenants/ directory (default: tenants)")
    args = ap.parse_args()

    tenants_root = Path(args.tenants_root)
    cmdb_errors = validate_cmdb(args.tenant, tenants_root)
    jsm_errors = validate_jsm(args.tenant, tenants_root)
    all_errors = cmdb_errors + jsm_errors

    table = Table(title=f"Validation — tenant={args.tenant}", show_header=True, header_style="bold")
    table.add_column("Check", style="cyan")
    table.add_column("Status")

    if cmdb_errors:
        for e in cmdb_errors:
            table.add_row(e, "[bold red]✗ FAIL[/]")
    else:
        table.add_row("CMDB export", "[bold green]✓ PASS[/]")

    if jsm_errors:
        for e in jsm_errors:
            table.add_row(e, "[bold red]✗ FAIL[/]")
    else:
        table.add_row("JSM export", "[bold green]✓ PASS[/]")

    console.print(table)

    if all_errors:
        sys.exit(2)


if __name__ == "__main__":
    main()
