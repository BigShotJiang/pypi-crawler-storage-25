"""CMDB Health Scoring Module — Jaccard similarity algorithm (CC-004).

Computes data completeness health scores for CSDMRow CI records.
APRA CPS 234 §36: all outputs are stamped with audit trail metadata.

Jaccard formula:  score = |observed_fields| / |all_fields|
Threshold:        score >= 0.80 → HEALTHY; score < 0.80 → DEGRADED

"Observed" (populated) means the field value is truthy:
  - Non-empty strings
  - Non-zero integers (discovery_confidence_pct=0 = "not yet discovered" = not counted)
  - Enum/datetime values are always truthy when present

All 15 CSDMRow fields are in the expected set.
"""

from __future__ import annotations

import subprocess
from datetime import UTC, datetime
from typing import Any

from runbooks.csdm.schemas import CSDMRow

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_HEALTH_THRESHOLD = 0.80
_HEALTHY = "HEALTHY"
_DEGRADED = "DEGRADED"

# All 15 CSDMRow field names — the expected attribute set for Jaccard denominator.
_EXPECTED_FIELDS: tuple[str, ...] = (
    "ci_type",
    "cmdb_id",
    "name",
    "short_description",
    "owned_by",
    "support_group",
    "supports_service",
    "business_capability",
    "application_service",
    "discovery_source",
    "last_discovered",
    "discovery_confidence_pct",
    "aws_account_id",
    "aws_region",
    "terraform_workspace",
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _jaccard_score(ci: CSDMRow) -> float:
    """Compute Jaccard completeness score for a single CI.

    Observed set = fields with truthy values (non-empty, non-zero).
    Expected set = all 15 CSDMRow fields.
    Jaccard = |observed| / |expected| (observed ⊆ expected so union = expected).
    """
    observed = sum(1 for field in _EXPECTED_FIELDS if bool(getattr(ci, field, None)))
    return observed / len(_EXPECTED_FIELDS)


def _get_git_commit() -> str:
    """Return the current git HEAD short hash, or 'unknown' if unavailable."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return "unknown"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def calculate_health_score(cis: list[CSDMRow]) -> dict[str, Any]:
    """Compute CMDB health scores for a list of CSDMRow CIs using Jaccard similarity.

    Args:
        cis: List of CSDMRow instances to score.

    Returns:
        Dict with keys:
          - total_cis (int): total records scored
          - healthy_pct (float): percentage with Jaccard >= 0.80
          - degraded_pct (float): percentage with Jaccard < 0.80
          - jaccard_scores (list): per-CI [{cmdb_id, jaccard, health}]
          - audit_timestamp (str): ISO-8601 UTC timestamp
          - git_commit (str): git HEAD short hash
          - generator (str): module identifier
          - hitl_review_required (bool): always True (APRA CPS 234 §36)
    """
    per_ci: list[dict[str, Any]] = []
    healthy_count = 0

    for ci in cis:
        score = _jaccard_score(ci)
        health = _HEALTHY if score >= _HEALTH_THRESHOLD else _DEGRADED
        if health == _HEALTHY:
            healthy_count += 1
        per_ci.append({"cmdb_id": ci.cmdb_id, "jaccard": round(score, 4), "health": health})

    total = len(cis)
    if total == 0:
        healthy_pct = 0.0
        degraded_pct = 0.0
    else:
        healthy_pct = round(healthy_count / total * 100.0, 2)
        degraded_pct = round((total - healthy_count) / total * 100.0, 2)

    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    return {
        "total_cis": total,
        "healthy_pct": healthy_pct,
        "degraded_pct": degraded_pct,
        "jaccard_scores": per_ci,
        "audit_timestamp": now_iso,
        "git_commit": _get_git_commit(),
        "generator": "runbooks.csdm.health_score",
        "hitl_review_required": True,
    }
