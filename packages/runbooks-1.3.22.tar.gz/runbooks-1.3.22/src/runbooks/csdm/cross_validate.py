"""4-way cross-validation pipeline for CSDM CI records.

Sources:
    V1 — CSV from tenants/<tenant>/ci-schema/cmdb/inputs/<resource_type>.csv
    V2 — runbooks.csdm renderer pipeline (in-process, produces merged CSV)
    V3 — MCP/LLM agent source (skipped when ANTHROPIC_API_KEY is unset)
    V4 — AWS describe-* API calls via boto3 (READONLY, $AWS_OPERATIONS_PROFILE)

Gate 1: V1 ∩ V2 ∩ V4 (+ V3 if available) by {resource_id} ≥95% match
  - ≥95%: write merged CSV to tenants/<tenant>/inputs/<resource_type>.csv
  - <95%: exit 2, write drift report to tmp/command-center/cross-validation/

Usage:
    python -m runbooks.csdm.cross_validate \\
        --tenant b2b-energy \\
        --tenants-root tenants \\
        --resource-type ec2
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import sys
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table

console = Console()

GATE1_THRESHOLD = 95.0  # match percentage required to write merged CSV


# ---------------------------------------------------------------------------
# Source collectors
# ---------------------------------------------------------------------------


def _collect_v1(tenant: str, tenants_root: Path, resource_type: str) -> tuple[list[dict[str, str]], str]:
    """V1: Read CI records from tenant ci-schema/cmdb/inputs/<resource_type>.csv."""
    csv_path = tenants_root / tenant / "ci-schema" / "cmdb" / "inputs" / f"{resource_type}.csv"
    if not csv_path.exists():
        return [], f"V1 CSV not found: {csv_path}"
    rows: list[dict[str, str]] = []
    try:
        with open(csv_path, encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(dict(row))
    except Exception as exc:
        return [], f"V1 read error: {exc}"
    return rows, ""


def _collect_v2(tenant: str, tenants_root: Path, resource_type: str) -> tuple[list[dict[str, str]], str]:
    """V2: Run runbooks.csdm renderer pipeline in-process; read its CSV output."""
    import tempfile
    import shutil

    try:
        from runbooks.csdm.cmdb_export import export_cmdb
    except ImportError as exc:
        return [], f"V2 import error: {exc}"

    # Export into a temp dir so we do not pollute the real cmdb-integration/
    tmp_tenants = Path(tempfile.mkdtemp())
    try:
        # Mirror only ci-schema/ into the temp tenants root (export_cmdb reads it)
        src_ci = tenants_root / tenant / "ci-schema"
        if not src_ci.exists():
            return [], f"V2 ci-schema not found for tenant {tenant!r}"
        dst_tenant = tmp_tenants / tenant
        dst_tenant.mkdir(parents=True)
        shutil.copytree(str(src_ci), str(dst_tenant / "ci-schema"))

        out_csv = export_cmdb(tenant, tmp_tenants)
        rows: list[dict[str, str]] = []
        with open(out_csv, encoding="utf-8") as f:
            first = f.readline()
            if not first.startswith("#"):
                f.seek(0)
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(dict(row))
        # Filter rows matching the resource_type by cmdb_id prefix or ci_type heuristic
        # ec2 → ci-ec2-* or cmdb_id containing resource_type
        filtered = _filter_by_resource_type(rows, resource_type)
        return filtered, ""
    except Exception as exc:
        return [], f"V2 export error: {exc}"
    finally:
        shutil.rmtree(str(tmp_tenants), ignore_errors=True)


def _filter_by_resource_type(rows: list[dict[str, str]], resource_type: str) -> list[dict[str, str]]:
    """Filter rendered rows to those matching resource_type by cmdb_id prefix heuristic."""
    resource_type_lower = resource_type.lower()
    matched = [r for r in rows if resource_type_lower in r.get("cmdb_id", "").lower()]
    # If heuristic yields nothing, return all rows (renderer does not tag by resource type)
    return matched if matched else rows


def _collect_v3_skipped(reason: str) -> tuple[list[dict[str, str]], str, bool]:
    """Return empty V3 result with skip marker."""
    return [], reason, True


def _collect_v4(resource_type: str, profile: str) -> tuple[list[dict[str, str]], str]:
    """V4: Call AWS describe-* API via boto3 (READONLY, $AWS_OPERATIONS_PROFILE).

    Performs sts.get_caller_identity() pre-check before describe calls.
    Supports resource_type: ec2 (extendable).
    """
    try:
        import botocore.config
        import boto3
    except ImportError:
        return [], "V4 boto3 not installed"

    retry_config = botocore.config.Config(retries={"max_attempts": 3, "mode": "adaptive"})
    session = boto3.Session(profile_name=profile)

    # STS pre-check (CA specification: hard-exit on profile mismatch)
    try:
        sts = session.client("sts", config=retry_config)
        identity = sts.get_caller_identity()
        account_id = identity.get("Account", "unknown")
    except Exception as exc:
        return [], f"V4 STS pre-check failed (profile={profile!r}): {exc}"

    rows: list[dict[str, str]] = []
    if resource_type == "ec2":
        try:
            ec2 = session.client("ec2", config=retry_config)
            paginator = ec2.get_paginator("describe_instances")
            for page in paginator.paginate():
                for reservation in page.get("Reservations", []):
                    for inst in reservation.get("Instances", []):
                        name_tag = next(
                            (t["Value"] for t in inst.get("Tags", []) if t["Key"] == "Name"),
                            inst["InstanceId"],
                        )
                        rows.append(
                            {
                                "resource_id": inst["InstanceId"],
                                "name": name_tag,
                                "aws_account_id": account_id,
                                "resource_type": "ec2",
                            }
                        )
        except Exception as exc:
            return [], f"V4 EC2 describe error (account={account_id}): {exc}"
    else:
        return [], f"V4 resource_type {resource_type!r} not yet supported (only 'ec2' implemented)"

    return rows, ""


# ---------------------------------------------------------------------------
# Comparison logic
# ---------------------------------------------------------------------------


def _extract_resource_ids(rows: list[dict[str, str]], resource_type: str) -> set[str]:
    """Extract a set of resource identifiers from a source's rows.

    Uses 'resource_id' if present (V4), else 'cmdb_id' (V1/V2), else 'name'.
    """
    ids: set[str] = set()
    for row in rows:
        rid = row.get("resource_id") or row.get("cmdb_id") or row.get("name", "")
        if rid:
            ids.add(rid.strip())
    return ids


def _compute_match_pct(id_sets: list[set[str]]) -> float:
    """Compute intersection size / union size * 100 across all active sources."""
    if not id_sets:
        return 0.0
    union: set[str] = set()
    for s in id_sets:
        union |= s
    if not union:
        return 100.0  # all sources empty — trivially consistent
    intersection = union.copy()
    for s in id_sets:
        intersection &= s
    return round(len(intersection) / len(union) * 100, 2)


def _build_merged_rows(
    v1_rows: list[dict[str, str]],
    v2_rows: list[dict[str, str]],
    resource_type: str,
) -> list[dict[str, str]]:
    """Merge V1 and V2 rows; V1 is authoritative, V2 fills any gaps."""
    seen: set[str] = set()
    merged: list[dict[str, str]] = []
    for row in v1_rows + v2_rows:
        rid = row.get("resource_id") or row.get("cmdb_id") or row.get("name", "")
        if rid and rid not in seen:
            seen.add(rid)
            merged.append(row)
    return merged


# ---------------------------------------------------------------------------
# Gate 1 result writer
# ---------------------------------------------------------------------------


def _write_gate1_json(
    out_dir: Path,
    tenant: str,
    resource_type: str,
    sources_active: list[str],
    v3_skipped: bool,
    v3_skip_reason: str,
    match_pct: float,
    decision: str,
    source_errors: dict[str, str],
    date_str: str,
) -> Path:
    """Write Gate 1 result JSON and return its path."""
    out_dir.mkdir(parents=True, exist_ok=True)
    gate1_path = out_dir / f"gate1-{date_str}.json"
    payload: dict[str, Any] = {
        "schema_version": "1.0",
        "story_id": "CC-041",
        "tenant": tenant,
        "resource_type": resource_type,
        "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
        "sources_active": sources_active,
        "v3_skipped": v3_skipped,
        "v3_skip_reason": v3_skip_reason,
        "match_pct": match_pct,
        "gate1_threshold_pct": GATE1_THRESHOLD,
        "decision": decision,
        "source_errors": source_errors,
    }
    with open(gate1_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return gate1_path


def _write_merged_csv(
    tenant: str,
    tenants_root: Path,
    resource_type: str,
    merged_rows: list[dict[str, str]],
) -> Path:
    """Write merged CSV to tenants/<tenant>/inputs/<resource_type>.csv."""
    inputs_dir = tenants_root / tenant / "inputs"
    inputs_dir.mkdir(parents=True, exist_ok=True)
    out_path = inputs_dir / f"{resource_type}.csv"
    if not merged_rows:
        # Write header-only file; Gate 1 only reaches here on ≥95% with ≥1 source
        out_path.write_text("resource_id,name,aws_account_id,resource_type\n", encoding="utf-8")
        return out_path
    fieldnames = list(merged_rows[0].keys())
    with open(out_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(merged_rows)
    return out_path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def run_cross_validate(
    tenant: str,
    tenants_root: Path,
    resource_type: str,
    cv_out_dir: Path,
    aws_profile: str | None = None,
) -> dict[str, Any]:
    """Run 4-way cross-validation for one resource type.

    Args:
        tenant: tenant directory name (e.g. 'b2b-energy')
        tenants_root: absolute path to tenants/ directory
        resource_type: 'ec2', 's3', 'rds', etc.
        cv_out_dir: output directory for gate1 JSON
        aws_profile: AWS profile name for V4 (None = skip V4)

    Returns:
        dict with keys: decision, match_pct, gate1_path, merged_csv_path, sources_active,
                        v3_skipped, v3_skip_reason, source_errors
    """
    date_str = dt.date.today().isoformat()
    source_errors: dict[str, str] = {}
    sources_active: list[str] = []
    id_sets: list[set[str]] = []

    # V1: tenant CSV
    v1_rows, v1_err = _collect_v1(tenant, tenants_root, resource_type)
    if v1_err:
        source_errors["V1"] = v1_err
        console.print(f"[yellow]  V1 error: {v1_err}[/]")
    else:
        v1_ids = _extract_resource_ids(v1_rows, resource_type)
        if v1_ids:
            sources_active.append("V1")
            id_sets.append(v1_ids)
            console.print(f"[dim]  V1: {len(v1_ids)} resources from tenant CSV[/]")

    # V2: renderer pipeline
    v2_rows, v2_err = _collect_v2(tenant, tenants_root, resource_type)
    if v2_err:
        source_errors["V2"] = v2_err
        console.print(f"[yellow]  V2 error: {v2_err}[/]")
    else:
        v2_ids = _extract_resource_ids(v2_rows, resource_type)
        if v2_ids:
            sources_active.append("V2")
            id_sets.append(v2_ids)
            console.print(f"[dim]  V2: {len(v2_ids)} resources from renderer[/]")

    # V3: MCP/LLM — skip when ANTHROPIC_API_KEY unset
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    v3_skipped = not bool(anthropic_key)
    v3_skip_reason = "" if not v3_skipped else "ANTHROPIC_API_KEY not set in environment"
    if v3_skipped:
        console.print(f"[dim]  V3: skipped ({v3_skip_reason})[/]")
    else:
        # V3 is a future MCP integration; for now mark as not-yet-implemented
        v3_skip_reason = "V3 MCP integration not yet implemented (CC-S2)"
        v3_skipped = True
        console.print(f"[dim]  V3: skipped ({v3_skip_reason})[/]")

    # V4: AWS describe-* via boto3
    if aws_profile:
        v4_rows, v4_err = _collect_v4(resource_type, aws_profile)
        if v4_err:
            source_errors["V4"] = v4_err
            console.print(f"[yellow]  V4 error: {v4_err}[/]")
        else:
            v4_ids = _extract_resource_ids(v4_rows, resource_type)
            if v4_ids:
                sources_active.append("V4")
                id_sets.append(v4_ids)
                console.print(f"[dim]  V4: {len(v4_ids)} resources from AWS API[/]")
    else:
        source_errors["V4"] = "AWS_OPERATIONS_PROFILE not set — V4 skipped"
        console.print(f"[dim]  V4: skipped (AWS_OPERATIONS_PROFILE not set)[/]")

    # Compute match percentage
    if len(id_sets) < 2:
        # Only one (or zero) active sources — cannot compute a meaningful match
        match_pct = 100.0 if len(id_sets) == 1 else 0.0
        if len(id_sets) < 2:
            console.print(
                f"[yellow]  Warning: fewer than 2 active sources ({sources_active}); "
                f"match_pct set to {match_pct}[/]"
            )
    else:
        match_pct = _compute_match_pct(id_sets)

    decision = "write" if match_pct >= GATE1_THRESHOLD else "halt"

    # Write Gate 1 JSON
    gate1_path = _write_gate1_json(
        out_dir=cv_out_dir,
        tenant=tenant,
        resource_type=resource_type,
        sources_active=sources_active,
        v3_skipped=v3_skipped,
        v3_skip_reason=v3_skip_reason,
        match_pct=match_pct,
        decision=decision,
        source_errors=source_errors,
        date_str=date_str,
    )
    console.print(f"[dim]  Gate 1 JSON: {gate1_path}[/]")

    merged_csv_path: Path | None = None
    if decision == "write":
        # Merge V1+V2 rows and write to inputs/
        merged_rows = _build_merged_rows(v1_rows, v2_rows, resource_type)
        merged_csv_path = _write_merged_csv(tenant, tenants_root, resource_type, merged_rows)
        console.print(f"[bold green]  Gate 1 PASS ({match_pct}%) — merged CSV: {merged_csv_path}[/]")
    else:
        console.print(f"[bold red]  Gate 1 FAIL ({match_pct}% < {GATE1_THRESHOLD}%) — HALT[/]")
        console.print(f"  Drift report: {gate1_path}")

    return {
        "decision": decision,
        "match_pct": match_pct,
        "gate1_path": str(gate1_path),
        "merged_csv_path": str(merged_csv_path) if merged_csv_path else None,
        "sources_active": sources_active,
        "v3_skipped": v3_skipped,
        "v3_skip_reason": v3_skip_reason,
        "source_errors": source_errors,
    }


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point: 4-way cross-validation for a tenant + resource type."""
    ap = argparse.ArgumentParser(
        description="4-way cross-validation pipeline for CSDM CI records",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--tenant", required=True, help="tenant directory name, e.g. b2b-energy")
    ap.add_argument("--tenants-root", default="tenants", help="path to tenants/ directory (default: tenants)")
    ap.add_argument(
        "--resource-type",
        default="ec2",
        help="resource type to validate: ec2, s3, rds, ... (default: ec2)",
    )
    ap.add_argument(
        "--cv-out-dir",
        default="tmp/command-center/cross-validation",
        help="directory for gate1 JSON (default: tmp/command-center/cross-validation)",
    )
    args = ap.parse_args()

    tenants_root = Path(args.tenants_root)
    cv_out_dir = Path(args.cv_out_dir)
    aws_profile = os.environ.get("AWS_OPERATIONS_PROFILE") or None

    console.print(f"[bold]Cross-validation[/] tenant=[cyan]{args.tenant}[/] resource=[cyan]{args.resource_type}[/]")
    if aws_profile:
        console.print(f"[dim]  V4 profile: {aws_profile}[/]")

    result = run_cross_validate(
        tenant=args.tenant,
        tenants_root=tenants_root,
        resource_type=args.resource_type,
        cv_out_dir=cv_out_dir,
        aws_profile=aws_profile,
    )

    # Summary table
    table = Table(title="Gate 1 Result", show_header=True, header_style="bold")
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    table.add_row("decision", result["decision"])
    table.add_row("match_pct", str(result["match_pct"]))
    table.add_row("sources_active", ", ".join(result["sources_active"]) or "none")
    table.add_row("v3_skipped", str(result["v3_skipped"]))
    table.add_row("gate1_path", result["gate1_path"])
    if result.get("merged_csv_path"):
        table.add_row("merged_csv", result["merged_csv_path"])
    for src, err in result["source_errors"].items():
        table.add_row(f"error.{src}", err)
    console.print(table)

    if result["decision"] == "halt":
        sys.exit(2)


if __name__ == "__main__":
    main()
