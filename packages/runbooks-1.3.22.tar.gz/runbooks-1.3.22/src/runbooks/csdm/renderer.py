"""Jinja2 CSDM bridge renderer: per-CI-class inputs/ + templates/ -> unified bridge CSV."""
from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path

import yaml
from jinja2 import ChoiceLoader, Environment, FileSystemLoader, TemplateNotFound

from runbooks.common.rich_utils import console


_CMDB_HEADER = [
    "ci_type", "cmdb_id", "name", "short_description", "owned_by",
    "support_group", "supports_service", "business_capability",
    "application_service", "discovery_source", "last_discovered",
    "discovery_confidence_pct", "aws_account_id", "aws_region",
    "terraform_workspace",
]

_JSM_HEADER = [
    "object_type", "object_key", "name", "description",
    "attributes_json", "references", "owner", "last_updated",
]


def _base_templates_dir(surface_dir: Path) -> Path | None:
    """Return the _base transforms dir for surface_dir, or None if absent.

    Mapping:
        tenants/<tenant>/ci-schema/cmdb/ -> tenants/_base/transforms/snow/
        tenants/<tenant>/ci-schema/jsm/  -> tenants/_base/transforms/jsm/
    """
    parts = surface_dir.parts
    try:
        idx = list(parts).index("tenants")
    except ValueError:
        return None
    if len(parts) <= idx + 2:
        return None
    # Determine surface sub-name from the last path component
    surface_name = parts[-1]
    _surface_map = {"cmdb": "snow", "jsm": "jsm"}
    transforms_sub = _surface_map.get(surface_name)
    if transforms_sub is None:
        # Legacy fallback removed (CC-ADR-015). Unknown surface_name is an error.
        raise ValueError(f"Unknown surface_name: {surface_name!r}. Update _surface_map in renderer.py.")
    tenants_root = Path(*parts[: idx + 1])
    base_dir = tenants_root / "_base" / "transforms" / transforms_sub
    return base_dir if base_dir.exists() else None


def _apply_spec(row: dict, spec: dict) -> dict:
    """Apply a template spec to one input row — pass-through columns + override values."""
    out: dict = {}
    pass_through: list[str] = spec.get("pass_through", list(row.keys()))
    for col in pass_through:
        out[col] = row.get(col, "")
    # Apply overrides: any key in spec that is not a structural key
    skip = {"pass_through", "ci_class", "object_type_value"}
    for key, val in spec.items():
        if key in skip:
            continue
        out[key] = val
    return out


def render_surface(
    surface_dir: Path,
    tenant: str,
    out_path: Path,
    header: list[str],
) -> int:
    """Render all inputs/*.csv through templates/*.j2 into a unified CSV.

    Iterates inputs/ in sorted (alphabetical) order for deterministic output.
    If no matching template exists for an input CSV, rows pass through verbatim.

    Args:
        surface_dir: path to the surface directory (e.g. ci-schema/cmdb/)
        tenant: tenant name string (available to Jinja2 templates as {{ tenant }})
        out_path: destination CSV path (written with one header row)
        header: ordered list of column names for the output CSV

    Returns:
        Number of data rows written (excluding header).

    Raises:
        FileNotFoundError: if inputs/ subdirectory does not exist under surface_dir.
    """
    inputs_dir = surface_dir / "inputs"
    templates_dir = surface_dir / "templates"

    if not inputs_dir.exists():
        raise FileNotFoundError(f"inputs/ missing: {inputs_dir}")

    loaders = []
    if templates_dir.exists():
        loaders.append(FileSystemLoader(str(templates_dir)))
    base_tmpl_dir = _base_templates_dir(surface_dir)
    if base_tmpl_dir:
        loaders.append(FileSystemLoader(str(base_tmpl_dir)))

    env: Environment = Environment(
        loader=ChoiceLoader(loaders) if loaders else FileSystemLoader("/dev/null"),
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    export_date = dt.date.today().isoformat()
    row_count = 0

    with open(out_path, "w", encoding="utf-8", newline="") as out_fh:
        writer = csv.DictWriter(out_fh, fieldnames=header, extrasaction="ignore")
        writer.writeheader()

        for input_csv in sorted(inputs_dir.glob("*.csv")):
            ci_class = input_csv.stem
            with open(input_csv, encoding="utf-8", newline="") as fh:
                rows = list(csv.DictReader(fh))

            try:
                tmpl = env.get_template(f"{ci_class}.j2")
                rendered_yaml = tmpl.render(tenant=tenant, export_date=export_date)
                spec: dict = yaml.safe_load(rendered_yaml) or {}
                tmpl_source = "tenant" if templates_dir.exists() and (templates_dir / f"{ci_class}.j2").exists() else "base"
                console.print(f"[dim]  -> {ci_class}: {len(rows)} rows via {tmpl_source} template[/]")
            except TemplateNotFound:
                spec = {}
                console.print(f"[yellow]  warning: {ci_class}: no template — pass-through[/]")

            for row in rows:
                out_row = _apply_spec(row, spec) if spec else row
                writer.writerow(out_row)
                row_count += 1

    return row_count


def render_cmdb(surface_dir: Path, tenant: str, out_path: Path) -> int:
    """Render CMDB surface (ServiceNow CSDM columns) to out_path.

    Args:
        surface_dir: path to ci-schema/cmdb/ directory
        tenant: tenant name (passed to Jinja2 context)
        out_path: destination CSV path

    Returns:
        Number of data rows written.
    """
    return render_surface(surface_dir, tenant, out_path, _CMDB_HEADER)


def render_jsm(surface_dir: Path, tenant: str, out_path: Path) -> int:
    """Render JSM Assets surface (Atlassian columns) to out_path.

    Args:
        surface_dir: path to ci-schema/jsm/ directory
        tenant: tenant name (passed to Jinja2 context)
        out_path: destination CSV path

    Returns:
        Number of data rows written.
    """
    return render_surface(surface_dir, tenant, out_path, _JSM_HEADER)
