"""Shared Pydantic schemas for ServiceNow CSDM 5 + Atlassian JSM Assets exports."""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class CIType(str, Enum):
    """ServiceNow CSDM 5 class hierarchy."""
    BUSINESS_CAPABILITY = "Business Capability"
    APPLICATION = "Application"
    APPLICATION_SERVICE = "Application Service"
    TECHNICAL_SERVICE = "Technical Service"
    CONFIGURATION_ITEM = "Configuration Item"


class DiscoverySource(str, Enum):
    AWS_CONFIG = "aws-config"
    AWS_RESOURCE_EXPLORER = "aws-resource-explorer"
    TERRAFORM_STATE = "terraform-state"
    CONFLUENCE_MINE = "confluence-mine"
    MANUAL = "manual"


class CSDMRow(BaseModel):
    """One row of the ServiceNow CSDM bridge export."""
    ci_type: CIType
    cmdb_id: str = Field(..., max_length=64)
    name: str = Field(..., max_length=255)
    short_description: str = Field(default="", max_length=510)
    owned_by: str  # email format
    support_group: str = Field(..., max_length=64)
    supports_service: str = Field(..., max_length=255)
    business_capability: str = Field(..., max_length=255)
    application_service: str = Field(..., max_length=255)
    discovery_source: DiscoverySource
    last_discovered: datetime
    discovery_confidence_pct: int = Field(..., ge=0, le=100)
    aws_account_id: str = Field(..., pattern=r"^\d{12}$")
    aws_region: str = Field(default="", max_length=16)
    terraform_workspace: str = Field(default="", max_length=64)

    @field_validator("owned_by")
    @classmethod
    def email_format(cls, v: str) -> str:
        if "@" not in v:
            raise ValueError(f"owned_by must be an email, got: {v!r}")
        return v


class JSMRow(BaseModel):
    """One row of the Atlassian JSM Assets bridge export."""
    object_type: str
    object_key: str = Field(..., max_length=64)
    name: str = Field(..., max_length=255)
    description: str = Field(default="", max_length=1000)
    attributes_json: str  # serialised JSON
    references: List[str] = Field(default_factory=list)
    owner: str = Field(..., max_length=64)
    last_updated: datetime
