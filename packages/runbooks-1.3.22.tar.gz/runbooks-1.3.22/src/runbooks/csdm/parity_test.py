"""Parity tests: Python render path vs Jinja2 direct render, byte-for-byte comparison."""
from __future__ import annotations

import csv
import json
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from jinja2 import ChoiceLoader, Environment, FileSystemLoader, TemplateNotFound

from runbooks.common.rich_utils import console


def normalize_whitespace(text: str) -> str:
    """Normalize whitespace (3-step: strip, collapse, no value transformation).

    Step 1: Strip leading/trailing whitespace from each line.
    Step 2: Collapse consecutive internal spaces to single space.
    Step 3: Strip outer text (leading/trailing around entire text).

    This normalizer intentionally avoids transforming cell values — only whitespace variance.
    """
    lines = text.split("\n")
    # Step 1 + 2: strip each line, collapse internal spaces
    normalized_lines = [" ".join(line.strip().split()) for line in lines]
    # Step 3: rejoin and strip the result
    return "\n".join(normalized_lines).strip()


def _render_via_python(
    surface_dir: Path,
    tenant: str,
    ci_type: str,
) -> str:
    """Render a single CI type CSV using the Python renderer (renderer.py).

    This uses the same logic as renderer.render_surface() but for a single CI type.
    """
    import csv
    import datetime as dt
    import yaml
    from jinja2 import TemplateNotFound

    from runbooks.csdm.renderer import _base_templates_dir, _CMDB_HEADER, _apply_spec, Environment, ChoiceLoader, FileSystemLoader

    inputs_dir = surface_dir / "inputs"
    templates_dir = surface_dir / "templates"
    input_csv = inputs_dir / f"{ci_type}.csv"

    if not input_csv.exists():
        raise FileNotFoundError(f"Input CSV not found: {input_csv}")

    # Load Jinja2 environment (same as render_surface)
    loaders = []
    if templates_dir.exists():
        loaders.append(FileSystemLoader(str(templates_dir)))
    base_tmpl_dir = _base_templates_dir(surface_dir)
    if base_tmpl_dir:
        loaders.append(FileSystemLoader(str(base_tmpl_dir)))

    env = Environment(
        loader=ChoiceLoader(loaders) if loaders else FileSystemLoader("/dev/null"),
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    export_date = dt.date.today().isoformat()

    # Load input CSV
    with open(input_csv, encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))

    # Render: output CSV header + rows
    output_lines = []
    output_lines.append(",".join(_CMDB_HEADER))

    try:
        tmpl = env.get_template(f"{ci_type}.j2")
        rendered_yaml = tmpl.render(tenant=tenant, export_date=export_date)
        spec = yaml.safe_load(rendered_yaml) or {}
    except TemplateNotFound:
        spec = {}

    for row in rows:
        out_row = _apply_spec(row, spec) if spec else row
        csv_row = [str(out_row.get(col, "")) for col in _CMDB_HEADER]
        output_lines.append(",".join(csv_row))

    return "\n".join(output_lines)


def _render_via_jinja2_direct(
    surface_dir: Path,
    tenant: str,
    ci_type: str,
) -> str:
    """Render a single CI type CSV using Jinja2 direct template load (base path)."""
    import csv
    import datetime as dt
    import yaml

    from runbooks.csdm.renderer import _base_templates_dir, _CMDB_HEADER, _apply_spec

    inputs_dir = surface_dir / "inputs"
    templates_dir = surface_dir / "templates"
    input_csv = inputs_dir / f"{ci_type}.csv"

    if not input_csv.exists():
        raise FileNotFoundError(f"Input CSV not found: {input_csv}")

    # Load Jinja2 environment (same as renderer.py)
    loaders = []
    if templates_dir.exists():
        loaders.append(FileSystemLoader(str(templates_dir)))
    base_tmpl_dir = _base_templates_dir(surface_dir)
    if base_tmpl_dir:
        loaders.append(FileSystemLoader(str(base_tmpl_dir)))

    env: Environment = Environment(
        loader=ChoiceLoader(loaders) if loaders else FileSystemLoader("/dev/null"),
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    export_date = dt.date.today().isoformat()

    # Load input CSV
    with open(input_csv, encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))

    # Render template
    output_lines = []
    output_lines.append(",".join(_CMDB_HEADER))

    try:
        tmpl = env.get_template(f"{ci_type}.j2")
        rendered_yaml = tmpl.render(tenant=tenant, export_date=export_date)
        spec: dict = yaml.safe_load(rendered_yaml) or {}
    except TemplateNotFound:
        spec = {}

    # Apply spec to each row and write CSV
    for row in rows:
        out_row = _apply_spec(row, spec) if spec else row
        csv_row = [str(out_row.get(col, "")) for col in _CMDB_HEADER]
        output_lines.append(",".join(csv_row))

    return "\n".join(output_lines)


def compare_renders(
    tenant: str,
    ci_type: str,
    tenants_root: Path,
) -> tuple[bool, str]:
    """Compare Python render vs Jinja2 direct render for a single CI type.

    Args:
        tenant: tenant name (e.g. 'b2b-energy')
        ci_type: CI type name (e.g. 'ec2', 'iam_role', 'lambda', 'rds', 's3', 'vpc')
        tenants_root: root tenants directory

    Returns:
        (match: bool, diff_detail: str)
        - match=True if renders are byte-identical after normalization
        - diff_detail: side-by-side diff or error message if mismatch
    """
    surface_dir = tenants_root / tenant / "ci-schema" / "cmdb"

    if not surface_dir.exists():
        return False, f"Surface directory not found: {surface_dir}"

    try:
        # Render both ways
        python_render = _render_via_python(surface_dir, tenant, ci_type)
        jinja2_render = _render_via_jinja2_direct(surface_dir, tenant, ci_type)

        # Normalize whitespace
        python_norm = normalize_whitespace(python_render)
        jinja2_norm = normalize_whitespace(jinja2_render)

        # Compare
        if python_norm == jinja2_norm:
            return True, ""

        # Mismatch: show diff
        python_lines = python_norm.split("\n")
        jinja2_lines = jinja2_norm.split("\n")
        diff_lines = []
        for i, (p_line, j_line) in enumerate(zip(python_lines, jinja2_lines)):
            if p_line != j_line:
                diff_lines.append(f"  Line {i+1}:")
                diff_lines.append(f"    Python:  {p_line[:80]}")
                diff_lines.append(f"    Jinja2:  {j_line[:80]}")
        if len(python_lines) != len(jinja2_lines):
            diff_lines.append(
                f"  Line count: Python {len(python_lines)} vs Jinja2 {len(jinja2_lines)}"
            )
        return False, "\n".join(diff_lines)

    except Exception as e:
        return False, f"Error comparing renders: {e}"


def run_parity_tests(
    tenant: str,
    tenants_root: Path = None,
) -> dict:
    """Run parity tests for all CI types in a tenant.

    Args:
        tenant: tenant name
        tenants_root: root tenants directory (default: infer from cwd)

    Returns:
        results dict with per-CI-type results and overall verdict
    """
    if tenants_root is None:
        tenants_root = Path.cwd() / "tenants"

    results = {
        "scope_id": "CC-ADR-014-pipeline",
        "story_id": "CC-042",
        "agent": "qa-automation-engineer",
        "timestamp": datetime.now(UTC).isoformat(),
        "tenant": tenant,
        "ci_types_tested": [],
        "overall_verdict": "PASS",
    }

    # CI types to test (6 main types for CMDB)
    ci_types = ["ec2", "iam_role", "lambda", "rds", "s3", "vpc"]

    for ci_type in ci_types:
        match, detail = compare_renders(tenant, ci_type, tenants_root)
        result = {
            "ci_type": ci_type,
            "pass": match,
            "detail": detail if not match else "",
        }
        results["ci_types_tested"].append(result)
        if not match:
            results["overall_verdict"] = "FAIL"
            console.print(
                f"[red]FAIL[/] {ci_type}: {detail.split(chr(10))[0]}"
            )
        else:
            console.print(f"[green]PASS[/] {ci_type}: renders byte-identical")

    return results


if __name__ == "__main__":
    import sys

    tenant = sys.argv[1] if len(sys.argv) > 1 else "b2b-energy"
    results = run_parity_tests(tenant)
    sys.exit(0 if results["overall_verdict"] == "PASS" else 2)
