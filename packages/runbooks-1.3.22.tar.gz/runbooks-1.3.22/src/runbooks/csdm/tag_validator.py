"""AWS resource tag validator against a YAML tag schema.

Validates resource tags for mandatory presence, enum values, and format patterns.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import yaml

# Anchor for schema resolution when lz_topology is used.
# Points to tenants/_base/ci-schema/ relative to this file's package root.
_SCHEMA_DIR = Path(__file__).parent.parent.parent.parent / "tenants" / "_base" / "ci-schema"

_LZ_SCHEMA_FILES: dict[str, str] = {
    "multi-account": "aws-tagging-standard-multi-account-lz.yaml",
    "single-account": "aws-tagging-standard-single-account-lz.yaml",
}


@dataclass
class ValidationResult:
    """Result of a tag validation run."""

    valid: bool
    missing_required: list[str] = field(default_factory=list)
    invalid_values: dict[str, str] = field(default_factory=dict)


def validate_tags(
    resource_tags: dict,
    schema_path: Path | None = None,
    lz_topology: Literal["multi-account", "single-account"] | None = None,
) -> ValidationResult:
    """Validate resource_tags against a YAML tag schema.

    Exactly one of schema_path or lz_topology must be provided.

    Args:
        resource_tags: dict of tag key -> tag value from an AWS resource.
        schema_path: explicit path to a tagging schema YAML file.
            Mutually exclusive with lz_topology.
        lz_topology: landing zone topology selector.
            "multi-account" resolves aws-tagging-standard-multi-account-lz.yaml.
            "single-account" resolves aws-tagging-standard-single-account-lz.yaml.
            Mutually exclusive with schema_path.

    Returns:
        ValidationResult with valid flag, missing_required list, and invalid_values dict.

    Raises:
        ValueError: if both schema_path and lz_topology are provided, or if neither is provided.

    Examples:
        # Using an explicit schema path (existing call signature — unchanged):
        result = validate_tags(tags, schema_path=Path("/path/to/schema.yaml"))

        # Using lz_topology routing (new):
        result = validate_tags(tags, lz_topology="multi-account")
        result = validate_tags(tags, lz_topology="single-account")
    """
    if schema_path is not None and lz_topology is not None:
        raise ValueError(
            "Provide schema_path OR lz_topology, not both."
        )
    if schema_path is None and lz_topology is None:
        raise ValueError(
            "One of schema_path or lz_topology must be provided."
        )
    if lz_topology is not None:
        filename = _LZ_SCHEMA_FILES[lz_topology]
        schema_path = _SCHEMA_DIR / filename

    schema = yaml.safe_load(schema_path.read_text(encoding="utf-8"))  # type: ignore[union-attr]
    tag_defs: dict = schema.get("tags", {})

    missing_required: list[str] = []
    invalid_values: dict[str, str] = {}

    for tag_key, tag_def in tag_defs.items():
        value = resource_tags.get(tag_key)

        if tag_def.get("required", False) and value is None:
            missing_required.append(tag_key)
            continue

        if value is None:
            continue

        tag_type = tag_def.get("type", "string")
        allowed_values = tag_def.get("allowed_values")
        pattern = tag_def.get("pattern")

        if allowed_values and value not in allowed_values:
            invalid_values[tag_key] = (
                f"'{value}' not in allowed values: {allowed_values}"
            )
        elif pattern and not re.match(pattern, value):
            invalid_values[tag_key] = (
                f"'{value}' does not match pattern {pattern}"
            )

    valid = not missing_required and not invalid_values
    return ValidationResult(
        valid=valid,
        missing_required=missing_required,
        invalid_values=invalid_values,
    )
