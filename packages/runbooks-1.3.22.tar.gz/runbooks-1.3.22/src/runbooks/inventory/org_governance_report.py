"""AWS Organizations Governance Report — builds an HTML dashboard from AWS Organizations APIs.

Fetches accounts, enabled service integrations, SCPs, and delegated admins using direct
boto3 pagination (sync, no async).  Converts raw API items to a Plotly/pandas HTML report.
No SAMPLE fallback — credentials missing = sys.exit(1).

READONLY only — list_accounts, list_aws_service_access_for_organization,
list_policies, list_delegated_administrators.
"""

from __future__ import annotations

import json
import logging
import re
import sys
from datetime import datetime, timezone
from typing import Any

import boto3
import botocore.config
import botocore.exceptions

logger = logging.getLogger(__name__)

_RETRY_CONFIG = botocore.config.Config(retries={"max_attempts": 3, "mode": "adaptive"})
_ORG_REGION = "us-east-1"

# ── Colour palette (dark GitHub theme) ───────────────────────────────────────
C_GREEN  = '#3FB950'
C_RED    = '#F85149'
C_GREY   = '#8B949E'
C_BLUE   = '#58A6FF'
C_ORANGE = '#FF9900'
C_AMBER  = '#E3B341'


def _org_client(profile: str | None) -> Any:
    """Return an Organizations boto3 client (us-east-1 global endpoint)."""
    session = boto3.Session(profile_name=profile)
    return session.client("organizations", region_name=_ORG_REGION, config=_RETRY_CONFIG)


def _pages(client: Any, method: str, key: str, **kw: Any) -> list[dict]:
    """Helper paginator: collect all pages from an AWS paginator into a single list.

    Args:
        client: boto3 Organizations client
        method: pagination method name (e.g. 'list_roots', 'list_accounts_for_parent')
        key: response key to extract from each page (e.g. 'Roots', 'Accounts')
        **kw: kwargs passed to paginator.paginate()

    Returns:
        List of all items from all pages
    """
    out: list[dict] = []
    for p in client.get_paginator(method).paginate(**kw):
        out.extend(p.get(key, []))
    return out


def build_ou_tree(client: Any, accts_by_id: dict) -> tuple[list[dict], int]:
    """Traverse AWS Organizations tree via BFS, building a flat list of all nodes.

    Args:
        client: boto3 Organizations client
        accts_by_id: dict mapping account ID -> account details (from list_accounts)

    Returns:
        Tuple: (tree_list, max_depth) where tree_list is a list of dicts with keys:
               id, name, parent_id, type (ROOT|OU|ACCOUNT), account_status (ACTIVE|SUSPENDED|None)
    """
    roots = _pages(client, 'list_roots', 'Roots')
    tree: list[dict] = []
    max_d = 0
    queue: list[tuple[str, str, str, int]] = [
        (roots[0]['Id'], roots[0].get('Name', 'Root'), '', 0)
    ]
    while queue:
        pid, pname, gid, depth = queue.pop(0)
        tree.append({
            'id': pid,
            'name': pname,
            'parent_id': gid,
            'type': 'ROOT' if gid == '' else 'OU',
            'account_status': None,
        })
        if depth > max_d:
            max_d = depth
        for ou in _pages(client, 'list_organizational_units_for_parent', 'OrganizationalUnits', ParentId=pid):
            queue.append((ou['Id'], ou['Name'], pid, depth + 1))
        for acct in _pages(client, 'list_accounts_for_parent', 'Accounts', ParentId=pid):
            st = accts_by_id.get(acct['Id'], {}).get('Status', 'n/a')
            tree.append({
                'id': acct['Id'],
                'name': acct['Name'],
                'parent_id': pid,
                'type': 'ACCOUNT',
                'account_status': st,
            })
    return tree, max_d


def get_accounts(profile: str | None) -> list[dict]:
    """Return all accounts via NextToken pagination. Exits 1 on credential error."""
    try:
        client = _org_client(profile)
        items: list[dict] = []
        kwargs: dict = {}
        while True:
            resp = client.list_accounts(**kwargs)
            items.extend(resp.get("Accounts", []))
            token = resp.get("NextToken")
            if not token:
                break
            kwargs["NextToken"] = token
        logger.info("get_accounts: %d", len(items))
        return items
    except botocore.exceptions.NoCredentialsError:
        from runbooks.common.rich_utils import print_error
        print_error("No AWS credentials found. Set $AWS_MANAGEMENT_PROFILE or configure ~/.aws/config.")
        sys.exit(1)
    except botocore.exceptions.ClientError as exc:
        from runbooks.common.rich_utils import print_error
        print_error(f"AWS error fetching accounts: {exc}")
        sys.exit(1)


def get_org_services(client: Any) -> list[dict]:
    """Return all enabled AWS service integrations via NextToken pagination."""
    items: list[dict] = []
    kwargs: dict = {}
    while True:
        resp = client.list_aws_service_access_for_organization(**kwargs)
        items.extend(resp.get("EnabledServicePrincipals", []))
        token = resp.get("NextToken")
        if not token:
            break
        kwargs["NextToken"] = token
    return items


def get_org_policies(client: Any, filter_type: str = "SERVICE_CONTROL_POLICY") -> list[dict]:
    """Return all organization policies of the given type via NextToken pagination."""
    items: list[dict] = []
    kwargs: dict = {"Filter": filter_type}
    while True:
        resp = client.list_policies(**kwargs)
        items.extend(resp.get("Policies", []))
        token = resp.get("NextToken")
        if not token:
            break
        kwargs["NextToken"] = token
    return items


def get_delegated_admins(client: Any) -> list[dict]:
    """Return all delegated administrator accounts via NextToken pagination."""
    items: list[dict] = []
    kwargs: dict = {}
    while True:
        resp = client.list_delegated_administrators(**kwargs)
        items.extend(resp.get("DelegatedAdministrators", []))
        token = resp.get("NextToken")
        if not token:
            break
        kwargs["NextToken"] = token
    return items


def traffic_light(pct: float) -> tuple[str, str]:
    """Return (hex_colour, label) for a coverage percentage."""
    if pct >= 95:
        return ("#2ecc71", "GREEN")
    elif pct >= 80:
        return ("#f39c12", "AMBER")
    return ("#e74c3c", "RED")


# ── Five traffic-light helpers (data-driven thresholds) ──────────────────────

def _tl_accounts(n: int) -> str:
    """Return colour for total account count (green if >=1)."""
    return C_GREEN if n >= 1 else C_RED


def _tl_active_ratio(active: int, total: int) -> str:
    """Return colour for active/total ratio (green >=95%, amber >=80%, red otherwise)."""
    if total == 0:
        return C_RED
    r = active / total
    return C_GREEN if r >= 0.95 else (C_AMBER if r >= 0.80 else C_RED)


def _tl_services(n: int) -> str:
    """Return colour for enabled service count (green 5-30, amber <5, red >30)."""
    if 5 <= n <= 30:
        return C_GREEN
    if n < 5:
        return C_AMBER
    return C_RED  # >30 = over-privileged risk


def _tl_scps(n: int) -> str:
    """Return colour for SCP count (green >=3, amber >=1, red 0)."""
    if n >= 3:
        return C_GREEN
    if n >= 1:
        return C_AMBER
    return C_RED  # 0 = no guardrails


def _tl_delegated(n: int) -> str:
    """Return colour for delegated admin count (green >=3, amber >=1, red 0)."""
    if n >= 3:
        return C_GREEN
    if n >= 1:
        return C_AMBER
    return C_RED  # 0 = single point of control


def compute_kpis(
    accounts: list[dict],
    services: list[dict],
    policies: list[dict],
    delegated: list[dict],
) -> dict:
    """Compute KPI dict from raw boto3 response items (no DataFrames).

    Returns keys: total_accounts, active_accounts, suspended_accounts,
    service_count, scp_count, delegated_count, coverage_pct.
    """
    total = len(accounts)
    active = sum(1 for a in accounts if a.get("Status", "").upper() == "ACTIVE")
    suspended = total - active
    coverage_pct = round(active / total * 100, 1) if total else 0.0
    return {
        "total_accounts": total,
        "active_accounts": active,
        "suspended_accounts": suspended,
        "service_count": len(services),
        "scp_count": len(policies),
        "delegated_count": len(delegated),
        "coverage_pct": coverage_pct,
    }


def write_evidence_json(
    output_dir: str | None,
    accounts: list[dict],
    services: list[dict],
    policies: list[dict],
    delegated: list[dict],
) -> str | None:
    """Write org-governance-YYYY-MM-DD.json evidence file to output_dir.

    Args:
        output_dir: Directory to write JSON file; if None, returns None without writing.
        accounts: Raw boto3 Accounts list.
        services: Raw boto3 EnabledServicePrincipals list.
        policies: Raw boto3 Policies list.
        delegated: Raw boto3 DelegatedAdministrators list.

    Returns:
        Absolute path of written JSON file, or None if output_dir is None.
    """
    if output_dir is None:
        return None

    import os
    kpis = compute_kpis(accounts, services, policies, delegated)
    total = kpis["total_accounts"]
    active = kpis["active_accounts"]

    evidence = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "apra_anchors": ["CPS 234 §36", "CPS 230 §6.2.1"],
        "data": {
            "total_accounts": total,
            "active_accounts": active,
            "suspended_accounts": kpis["suspended_accounts"],
            "services_enabled": kpis["service_count"],
            "total_scps": kpis["scp_count"],
            "aws_managed_scps": sum(
                1 for p in policies
                if p.get("AwsManaged") in (True, "True", "true")
            ),
            "custom_scps": sum(
                1 for p in policies
                if p.get("AwsManaged") not in (True, "True", "true")
            ),
            "delegated_admins": kpis["delegated_count"],
        },
        "traffic_lights": {
            "accounts":  "green" if _tl_accounts(total)            == C_GREEN else ("amber" if _tl_accounts(total)            == C_AMBER else "red"),
            "active":    "green" if _tl_active_ratio(active, total) == C_GREEN else ("amber" if _tl_active_ratio(active, total) == C_AMBER else "red"),
            "services":  "green" if _tl_services(kpis["service_count"]) == C_GREEN else ("amber" if _tl_services(kpis["service_count"]) == C_AMBER else "red"),
            "scps":      "green" if _tl_scps(kpis["scp_count"])     == C_GREEN else ("amber" if _tl_scps(kpis["scp_count"])     == C_AMBER else "red"),
            "delegated": "green" if _tl_delegated(kpis["delegated_count"]) == C_GREEN else ("amber" if _tl_delegated(kpis["delegated_count"]) == C_AMBER else "red"),
        },
        "coverage_pct": kpis["coverage_pct"],
    }

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    filename = f"org-governance-{today}.json"
    os.makedirs(output_dir, exist_ok=True)
    out_path = os.path.join(output_dir, filename)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(evidence, fh, indent=2)
    logger.info("write_evidence_json: %s", out_path)
    return out_path


def build_html_dashboard(
    accounts: list[dict],
    services: list[dict],
    policies: list[dict],
    delegated: list[dict],
    tenant_name: str = "Organization",
    ou_tree: list[dict] | None = None,
) -> str:
    """Build a self-contained 5-panel dark-theme HTML dashboard.

    Args:
        accounts: Raw boto3 Accounts list (keys: Id, Name, Status, Email, ...).
        services: Raw boto3 EnabledServicePrincipals list (key: ServicePrincipal).
        policies: Raw boto3 Policies list.
        delegated: Raw boto3 DelegatedAdministrators list.
        tenant_name: Display name shown in the dashboard title.
        ou_tree: Optional output from build_ou_tree(); used for the Sunburst panel.
                 If None, falls back to a flat account-list sunburst.

    Returns:
        Self-contained HTML string (plotly CDN, full_html=True compatible).

    Raises:
        ImportError: If plotly is not installed (install with: uv sync --extra analytics).
    """
    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
    except ImportError as exc:
        raise ImportError(
            f"Missing dependency: {exc}. Install with: uv sync --extra analytics"
        ) from exc

    kpis = compute_kpis(accounts, services, policies, delegated)
    total_accounts     = kpis["total_accounts"]
    active_accounts    = kpis["active_accounts"]
    suspended_accounts = kpis["suspended_accounts"]
    scp_count          = kpis["scp_count"]
    delegated_count    = kpis["delegated_count"]

    service_principals = [s.get("ServicePrincipal", "") for s in services]
    service_names      = sorted(service_principals)

    aws_managed_scps = sum(
        1 for p in policies if p.get("AwsManaged") in (True, "True", "true")
    )
    custom_scps = scp_count - aws_managed_scps

    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # ── Traffic lights ────────────────────────────────────────────────────────
    tl_accounts  = _tl_accounts(total_accounts)
    tl_active    = _tl_active_ratio(active_accounts, total_accounts)
    tl_services  = _tl_services(len(service_names))
    tl_scps      = _tl_scps(scp_count)
    tl_delegated = _tl_delegated(delegated_count)

    # ── Colour palette ────────────────────────────────────────────────────────
    bg     = '#0D1117'
    panel  = '#161B22'
    border = '#30363D'
    text   = '#E6EDF3'
    subtext = '#8B949E'
    purple = '#BC8CFF'

    # ── Sunburst data (from ou_tree if provided, else flat fallback) ──────────
    sb_ids: list[str] = []
    sb_labels: list[str] = []
    sb_parents: list[str] = []
    sb_colors: list[str] = []
    sb_hover: list[str] = []

    if ou_tree:
        accts_by_id = {a.get("Id", ""): a for a in accounts}
        for node in ou_tree:
            nid    = node["id"]
            nlabel = node["name"]
            npar   = node["parent_id"]
            ntype  = node["type"]
            nst    = node.get("account_status")
            if ntype == "ROOT":
                color = C_ORANGE
                hover = "Organization Root"
            elif ntype == "OU":
                color = C_BLUE
                hover = f"OU: {nlabel}"
            else:  # ACCOUNT
                if nst and nst.upper() == "ACTIVE":
                    color = C_GREEN
                elif nst and nst.upper() == "SUSPENDED":
                    color = C_RED
                else:
                    color = C_GREY
                acct = accts_by_id.get(nid, {})
                hover = f"{nlabel} | {nid} | {acct.get('Email', '')} | {nst or ''}"
            sb_ids.append(nid)
            sb_labels.append(nlabel)
            sb_parents.append(npar)
            sb_colors.append(color)
            sb_hover.append(hover)

    if not sb_ids:
        # Flat fallback — all accounts under a synthetic ROOT node
        sb_ids    = ["ROOT"] + [a.get("Id", str(i)) for i, a in enumerate(accounts)]
        sb_labels = ["All Accounts"] + [a.get("Name", a.get("Id", str(i))) for i, a in enumerate(accounts)]
        sb_parents = [""] + ["ROOT"] * len(accounts)
        sb_hover  = ["Organization root"] + [
            a.get("Name", a.get("Id", "")) for a in accounts
        ]
        sb_colors = [C_ORANGE] + [
            C_GREEN if a.get("Status", "").upper() == "ACTIVE"
            else (C_RED if a.get("Status", "").upper() == "SUSPENDED" else C_GREY)
            for a in accounts
        ]

    # ── KPI banner HTML ───────────────────────────────────────────────────────
    kpi_html = (
        f'<div style="background:{panel};border:1px solid {border};border-radius:8px;'
        f'padding:20px 28px;margin-bottom:16px;font-family:Inter,Segoe UI,sans-serif;">'
        f'<div style="color:{subtext};font-size:11px;letter-spacing:2px;text-transform:uppercase;'
        f'margin-bottom:16px;">AWS Organizations &middot; {tenant_name} &middot; '
        f'{generated_at} &middot; <span style="color:{subtext};font-size:10px;">'
        f'APRA CPS 234 §36 · CPS 230 §6.2.1</span></div>'
        f'<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;">'
        f'<div style="text-align:center"><div style="color:{tl_accounts};font-size:36px;font-weight:700">{total_accounts}</div>'
        f'<div style="color:{subtext};font-size:12px">Total Accounts</div></div>'
        f'<div style="text-align:center"><div style="color:{tl_active};font-size:36px;font-weight:700">{active_accounts}</div>'
        f'<div style="color:{subtext};font-size:12px">Active Accounts</div></div>'
        f'<div style="text-align:center"><div style="color:{tl_services};font-size:36px;font-weight:700">{len(service_names)}</div>'
        f'<div style="color:{subtext};font-size:12px">Org Services Enabled</div></div>'
        f'<div style="text-align:center"><div style="color:{tl_scps};font-size:36px;font-weight:700">{scp_count}</div>'
        f'<div style="color:{subtext};font-size:12px">SCPs Active</div></div>'
        f'<div style="text-align:center"><div style="color:{tl_delegated};font-size:36px;font-weight:700">{delegated_count}</div>'
        f'<div style="color:{subtext};font-size:12px">Delegated Admins</div></div>'
        f'</div></div>'
    )

    # ── 5-panel Plotly layout ─────────────────────────────────────────────────
    # Row 1: full-width Sunburst (org structure)
    # Row 2: donut (account status) | bar (services enabled)
    # Row 3: donut (SCP breakdown)  | bar (delegated admins)
    fig = make_subplots(
        rows=3, cols=2,
        subplot_titles=[
            'How is the organization structured by OU and account?',
            '',
            'How many accounts are active vs. suspended?',
            'Which AWS services are organization-wide?',
            'How many governance guardrails are active?',
            'Who owns each service domain?',
        ],
        specs=[
            [{'type': 'sunburst', 'colspan': 2}, None],
            [{'type': 'domain'},                 {'type': 'xy'}],
            [{'type': 'domain'},                 {'type': 'xy'}],
        ],
        row_heights=[0.40, 0.30, 0.30],
        horizontal_spacing=0.08,
        vertical_spacing=0.12,
    )

    # Panel 1 — Org Structure (Sunburst)
    fig.add_trace(
        go.Sunburst(
            ids=sb_ids,
            labels=sb_labels,
            parents=sb_parents,
            marker=dict(colors=sb_colors, line=dict(color=bg, width=1)),
            customdata=sb_hover,
            hovertemplate='<b>%{label}</b><br>%{customdata}<extra></extra>',
            branchvalues='total',
            maxdepth=4,
            textfont=dict(size=11),
        ),
        row=1, col=1,
    )

    # Panel 2 — Account Status (donut)
    other_accounts = total_accounts - active_accounts - suspended_accounts
    acct_counts = {k: v for k, v in {
        'ACTIVE':    active_accounts,
        'SUSPENDED': suspended_accounts,
        'OTHER':     other_accounts,
    }.items() if v > 0}
    fig.add_trace(
        go.Pie(
            labels=list(acct_counts.keys()),
            values=list(acct_counts.values()),
            hole=0.55,
            marker=dict(
                colors=[C_GREEN, C_RED, subtext],
                line=dict(color=bg, width=2),
            ),
            textinfo='label+percent',
            textfont=dict(color=text, size=11),
        ),
        row=2, col=1,
    )

    # Panel 3 — Services Enabled (horizontal bar, top 20)
    svc20 = service_names[:20]
    svc_labels = [re.sub(r'\.amazonaws\.com$', '', s) for s in svc20]
    if svc_labels:
        fig.add_trace(
            go.Bar(
                y=svc_labels,
                x=[1] * len(svc_labels),
                orientation='h',
                marker=dict(color=C_BLUE, opacity=0.85),
                showlegend=False,
                text=svc_labels,
                textposition='inside',
                textfont=dict(size=9, color=text),
            ),
            row=2, col=2,
        )
    else:
        fig.add_trace(
            go.Scatter(
                x=[0], y=[0], mode='text',
                text=['No org-wide services enabled'],
                textfont=dict(color=C_AMBER, size=12),
            ),
            row=2, col=2,
        )

    # Panel 4 — Governance Guardrails (donut)
    scp_counts = {k: v for k, v in {
        'Custom SCPs':      custom_scps,
        'AWS-Managed SCPs': aws_managed_scps,
    }.items() if v > 0}
    if scp_counts:
        fig.add_trace(
            go.Pie(
                labels=list(scp_counts.keys()),
                values=list(scp_counts.values()),
                hole=0.55,
                marker=dict(
                    colors=[purple, border],
                    line=dict(color=bg, width=2),
                ),
                textinfo='label+value',
                textfont=dict(color=text, size=11),
            ),
            row=3, col=1,
        )
    else:
        fig.add_trace(
            go.Scatter(
                x=[0], y=[0], mode='text',
                text=['No SCPs — audit risk'],
                textfont=dict(color=C_RED, size=13),
            ),
            row=3, col=1,
        )

    # Panel 5 — Delegated Admins (horizontal bar)
    if delegated:
        da_rows: list[str] = []
        for admin in delegated[:15]:
            name = admin.get('Name', admin.get('Id', '?'))
            sps  = admin.get('ServicePrincipals', [])
            if sps:
                for sp in sps:
                    da_rows.append(f"{name} — {re.sub(r'\\.amazonaws\\.com$', '', sp)}")
            else:
                da_rows.append(name)
        da_rows = da_rows[:15]
        fig.add_trace(
            go.Bar(
                y=da_rows,
                x=[1] * len(da_rows),
                orientation='h',
                marker=dict(color=C_AMBER, opacity=0.85),
                showlegend=False,
                text=da_rows,
                textposition='inside',
                textfont=dict(size=9, color=text),
            ),
            row=3, col=2,
        )
    else:
        fig.add_trace(
            go.Scatter(
                x=[0], y=[0], mode='text',
                text=['No delegated administrators — single-point-of-control risk'],
                textfont=dict(color=C_RED, size=11),
            ),
            row=3, col=2,
        )

    # ── Global layout ─────────────────────────────────────────────────────────
    fig.update_layout(
        height=900,
        paper_bgcolor=bg,
        plot_bgcolor=panel,
        font=dict(family='Inter, Segoe UI, sans-serif', color=text, size=12),
        margin=dict(t=70, b=40, l=20, r=20),
        showlegend=False,
    )

    for ann in fig.layout.annotations:
        ann.font.color = subtext
        ann.font.size  = 12

    # Hide axes on bar charts (values are decorative — presence = count)
    fig.update_layout(
        xaxis2=dict(visible=False),
        xaxis3=dict(visible=False),
        yaxis2=dict(showgrid=False, zeroline=False, color=subtext, tickfont=dict(size=9)),
        yaxis3=dict(showgrid=False, zeroline=False, color=subtext, tickfont=dict(size=9)),
    )

    # ── Panel 5 title (Plotly drops the 6th subplot_title with colspan+None spec) ──
    # Manually pin it above row3-col2 (x-domain [0.54, 1.0], y-domain top ~0.228).
    panel5_title = dict(
        text='Who owns each service domain?',
        xref='paper', yref='paper',
        x=0.77, y=0.268,
        xanchor='center', yanchor='bottom',
        showarrow=False,
        font=dict(size=12, color=subtext),
    )

    # ── Regulatory footer annotations ─────────────────────────────────────────
    REG_FONT = dict(size=9, color=subtext)
    _reg_annotations = [
        panel5_title,
        dict(text='APRA CPS 230 §6.2.1 — Service mapping &amp; hierarchical accountability',
             xref='paper', yref='paper', x=0.5, y=0.98, xanchor='center', yanchor='top',
             showarrow=False, font=REG_FONT),
        dict(text='APRA CPS 234 §36 — Information asset inventory',
             xref='paper', yref='paper', x=0.0, y=0.56, xanchor='left', yanchor='top',
             showarrow=False, font=REG_FONT),
        dict(text='APRA CPS 230 §6.2.1 — Service mapping completeness',
             xref='paper', yref='paper', x=1.0, y=0.56, xanchor='right', yanchor='top',
             showarrow=False, font=REG_FONT),
        dict(text='APRA CPS 234 §36 — Access controls &amp; governance guardrails',
             xref='paper', yref='paper', x=0.0, y=0.18, xanchor='left', yanchor='top',
             showarrow=False, font=REG_FONT),
        dict(text='APRA CPS 230 §6.2.1 — Accountability &amp; ownership',
             xref='paper', yref='paper', x=1.0, y=0.18, xanchor='right', yanchor='top',
             showarrow=False, font=REG_FONT),
    ]
    existing_anns = list(fig.layout.annotations)
    fig.update_layout(annotations=existing_anns + _reg_annotations)

    # ── Assemble full HTML ────────────────────────────────────────────────────
    plotly_div = fig.to_html(full_html=False, include_plotlyjs='cdn')

    html = (
        '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
        f'<title>AWS Organizations — CxO Dashboard — {tenant_name}</title>'
        '<style>'
        f'body{{margin:0;padding:24px 32px;background:{bg};font-family:Inter,Segoe UI,sans-serif;color:{text}}}'
        'h1{font-size:20px;font-weight:600;margin:0 0 4px}'
        f'.sub{{color:{subtext};font-size:13px;margin-bottom:20px}}'
        f'.reg{{color:{subtext};font-size:11px;border-top:1px solid {border};padding-top:12px;margin-top:16px}}'
        '</style></head>'
        '<body>'
        f'<h1>{tenant_name} — AWS Organizations Governance Report</h1>'
        f'<div class="sub">Generated: {generated_at}</div>'
        + kpi_html
        + plotly_div
        + '<div class="reg">'
        'Regulatory anchors: APRA CPS 234 §36 (information asset inventory, access controls) '
        '&middot; APRA CPS 230 §6.2.1 (service mapping, hierarchical accountability, ownership)'
        '</div>'
        '</body></html>'
    )

    return html
