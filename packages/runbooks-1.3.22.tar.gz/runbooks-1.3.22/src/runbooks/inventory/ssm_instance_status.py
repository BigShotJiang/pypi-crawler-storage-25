#!/usr/bin/env python3
"""
SSM Instance Status - Agent Info, Patch Compliance, and Command History

Queries AWS Systems Manager for a specific EC2 instance to surface:
- Agent version, platform, ping status, last ping time, IP address
- Patch compliance state (installed, missing, failed counts)
- Last 10 command invocations (document name, status, execution time)

READONLY: Uses ssm:DescribeInstanceInformation, ssm:DescribeInstancePatchStates,
          ssm:ListCommandInvocations — no mutations.

Usage:
    runbooks inventory ssm-status --instance-id i-0abc123 --profile ops-profile
    runbooks inventory ssm-status --instance-id i-0abc123 --profile ops-profile --output json
"""

import json
from datetime import datetime
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_table,
    print_error,
    print_info,
    print_warning,
)

# Retry config per Rule 6 (AWS API Consumer Audit)
_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})


def _get_ssm_client(profile: Optional[str], region: str):
    """Create SSM client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("ssm", config=_RETRY_CONFIG)


def fetch_agent_info(ssm_client, instance_id: str) -> Optional[dict[str, Any]]:
    """
    Fetch SSM agent information for a single instance.

    Args:
        ssm_client: Boto3 SSM client
        instance_id: EC2 instance ID (e.g. i-0abc123)

    Returns:
        Dict with agent fields, or None if instance not registered with SSM
    """
    try:
        paginator = ssm_client.get_paginator("describe_instance_information")
        for page in paginator.paginate(
            Filters=[{"Key": "InstanceIds", "Values": [instance_id]}],
            PaginationConfig={"MaxItems": 10, "PageSize": 10},
        ):
            items = page.get("InstanceInformationList", [])
            if items:
                return items[0]
        return None
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied"):
            raise
        if error_code == "InvalidInstanceId":
            return None
        raise


def fetch_patch_state(ssm_client, instance_id: str) -> Optional[dict[str, Any]]:
    """
    Fetch patch compliance state for a single instance.

    Args:
        ssm_client: Boto3 SSM client
        instance_id: EC2 instance ID

    Returns:
        Dict with patch counts, or None if patch baseline not configured
    """
    try:
        response = ssm_client.describe_instance_patch_states(InstanceIds=[instance_id])
        items = response.get("InstancePatchStates", [])
        return items[0] if items else None
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied"):
            raise
        return None


def fetch_recent_commands(ssm_client, instance_id: str, limit: int = 10) -> list[dict[str, Any]]:
    """
    Fetch the last N command invocations for a single instance.

    Args:
        ssm_client: Boto3 SSM client
        instance_id: EC2 instance ID
        limit: Maximum invocations to return (default 10)

    Returns:
        List of command invocation dicts, newest first
    """
    results: list[dict[str, Any]] = []
    try:
        paginator = ssm_client.get_paginator("list_command_invocations")
        for page in paginator.paginate(
            InstanceId=instance_id,
            Details=False,
            PaginationConfig={"MaxItems": limit, "PageSize": limit},
        ):
            results.extend(page.get("CommandInvocations", []))
            if len(results) >= limit:
                break
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied"):
            raise
        # InvalidInstanceId or no history — return empty list
    return results[:limit]


def _fmt_dt(dt_val) -> str:
    """Format datetime or ISO string to human-readable local representation."""
    if dt_val is None:
        return "N/A"
    if isinstance(dt_val, datetime):
        return dt_val.strftime("%Y-%m-%d %H:%M UTC")
    return str(dt_val)


def render_ssm_status(
    instance_id: str,
    agent_info: Optional[dict[str, Any]],
    patch_state: Optional[dict[str, Any]],
    recent_commands: list[dict[str, Any]],
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Render SSM instance status to console or return structured data.

    Args:
        instance_id: EC2 instance ID
        agent_info: SSM agent info dict (or None if not registered)
        patch_state: Patch compliance dict (or None)
        recent_commands: List of command invocations
        output_format: "table" or "json"

    Returns:
        Structured dict of all SSM status data
    """
    structured: dict[str, Any] = {
        "instance_id": instance_id,
        "agent_info": {},
        "patch_compliance": {},
        "recent_commands": [],
    }

    # --- Section 1: Agent Info ---
    if agent_info:
        structured["agent_info"] = {
            "agent_version": agent_info.get("AgentVersion", "N/A"),
            "ping_status": agent_info.get("PingStatus", "N/A"),
            "last_ping_date": _fmt_dt(agent_info.get("LastPingDateTime")),
            "platform_type": agent_info.get("PlatformType", "N/A"),
            "platform_name": agent_info.get("PlatformName", "N/A"),
            "platform_version": agent_info.get("PlatformVersion", "N/A"),
            "ip_address": agent_info.get("IPAddress", "N/A"),
            "computer_name": agent_info.get("ComputerName", "N/A"),
        }
    else:
        structured["agent_info"] = {"ping_status": "NOT_REGISTERED"}

    # --- Section 2: Patch Compliance ---
    if patch_state:
        structured["patch_compliance"] = {
            "patch_group": patch_state.get("PatchGroup", "N/A"),
            "baseline_id": patch_state.get("BaselineId", "N/A"),
            "installed_count": patch_state.get("InstalledCount", 0),
            "installed_other_count": patch_state.get("InstalledOtherCount", 0),
            "installed_rejected_count": patch_state.get("InstalledRejectedCount", 0),
            "missing_count": patch_state.get("MissingCount", 0),
            "failed_count": patch_state.get("FailedCount", 0),
            "not_applicable_count": patch_state.get("NotApplicableCount", 0),
            "operation_type": patch_state.get("Operation", "N/A"),
            "operation_end_time": _fmt_dt(patch_state.get("OperationEndTime")),
            "compliance_status": patch_state.get("OverallSeverity", "N/A"),
        }
    else:
        structured["patch_compliance"] = {"status": "NO_PATCH_DATA"}

    # --- Section 3: Recent Commands ---
    for inv in recent_commands:
        structured["recent_commands"].append(
            {
                "command_id": inv.get("CommandId", "N/A"),
                "document_name": inv.get("DocumentName", "N/A"),
                "status": inv.get("StatusDetails", inv.get("Status", "N/A")),
                "requested_date": _fmt_dt(inv.get("RequestedDateTime")),
            }
        )

    if output_format == "json":
        console.print_json(json.dumps(structured, default=str, indent=2))
        return structured

    # --- Rich table rendering ---
    console.print(f"\n[bold cyan]SSM Instance Status: {instance_id}[/bold cyan]\n")

    # Agent info table
    agent_table = create_table(
        title="Agent Information",
        columns=[
            {"header": "Property", "style": "cyan", "no_wrap": True},
            {"header": "Value", "style": "white"},
        ],
    )
    ai = structured["agent_info"]
    if ai.get("ping_status") == "NOT_REGISTERED":
        agent_table.add_row("Status", "[yellow]SSM agent not installed or not reporting[/yellow]")
    else:
        for key, val in [
            ("Agent Version", ai.get("agent_version", "N/A")),
            ("Ping Status", ai.get("ping_status", "N/A")),
            ("Last Ping", ai.get("last_ping_date", "N/A")),
            ("Platform", f"{ai.get('platform_name', 'N/A')} {ai.get('platform_version', '')}".strip()),
            ("Platform Type", ai.get("platform_type", "N/A")),
            ("IP Address", ai.get("ip_address", "N/A")),
            ("Computer Name", ai.get("computer_name", "N/A")),
        ]:
            ping = ai.get("ping_status", "")
            val_fmt = f"[green]{val}[/green]" if key == "Ping Status" and ping == "Online" else str(val)
            agent_table.add_row(key, val_fmt)
    console.print(agent_table)

    # Patch compliance table
    console.print()
    patch_table = create_table(
        title="Patch Compliance",
        columns=[
            {"header": "Metric", "style": "cyan", "no_wrap": True},
            {"header": "Count", "style": "white", "justify": "right"},
        ],
    )
    pc = structured["patch_compliance"]
    if pc.get("status") == "NO_PATCH_DATA":
        patch_table.add_row("Status", "[yellow]No patch data — patch baseline may not be configured[/yellow]")
    else:
        for key, val in [
            ("Installed", str(pc.get("installed_count", 0))),
            ("Installed (Other)", str(pc.get("installed_other_count", 0))),
            ("Installed (Rejected)", str(pc.get("installed_rejected_count", 0))),
            ("Missing", str(pc.get("missing_count", 0))),
            ("Failed", str(pc.get("failed_count", 0))),
            ("Not Applicable", str(pc.get("not_applicable_count", 0))),
            ("Operation", str(pc.get("operation_type", "N/A"))),
            ("Last Operation", str(pc.get("operation_end_time", "N/A"))),
            ("Compliance Severity", str(pc.get("compliance_status", "N/A"))),
        ]:
            failed = pc.get("failed_count", 0)
            missing = pc.get("missing_count", 0)
            if key == "Missing" and missing > 0:
                val = f"[yellow]{val}[/yellow]"
            elif key == "Failed" and failed > 0:
                val = f"[red]{val}[/red]"
            patch_table.add_row(key, val)
    console.print(patch_table)

    # Recent commands table
    console.print()
    if recent_commands:
        cmd_table = create_table(
            title="Recent Command Invocations (last 10)",
            columns=[
                {"header": "Document Name", "style": "cyan"},
                {"header": "Status", "style": "white", "no_wrap": True},
                {"header": "Requested", "style": "dim"},
                {"header": "Command ID", "style": "dim"},
            ],
        )
        for cmd in structured["recent_commands"]:
            status = cmd["status"]
            status_fmt = (
                f"[green]{status}[/green]"
                if status in ("Success", "Delivered")
                else f"[red]{status}[/red]"
                if status in ("Failed", "TimedOut", "Cancelled")
                else status
            )
            cmd_table.add_row(
                cmd["document_name"],
                status_fmt,
                cmd["requested_date"],
                cmd["command_id"][:20] + "...",
            )
        console.print(cmd_table)
    else:
        console.print("[dim]No recent command invocations found.[/dim]")

    console.print()
    return structured


def run_ssm_instance_status(
    instance_id: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Fetch and render SSM instance status for a given EC2 instance.

    Args:
        instance_id: EC2 instance ID (e.g. i-0abc123)
        profile: AWS profile name (None uses default/env)
        region: AWS region (default: ap-southeast-2)
        output_format: "table" or "json"

    Returns:
        Structured dict with agent_info, patch_compliance, recent_commands

    Raises:
        SystemExit on access denied or unexpected API errors
    """
    print_info(f"Fetching SSM status for {instance_id} in {region}...")

    try:
        ssm_client = _get_ssm_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create SSM client: {e}")
        raise SystemExit(1)

    # Fetch agent info
    agent_info: Optional[dict[str, Any]] = None
    try:
        agent_info = fetch_agent_info(ssm_client, instance_id)
        if agent_info is None:
            print_warning(
                f"SSM agent not installed or not reporting for instance {instance_id}. "
                "Ensure the SSM agent is running and the instance has the required IAM role."
            )
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied"):
            print_error(
                f"Access denied querying SSM DescribeInstanceInformation with profile '{profile}'. "
                "Ensure ssm:DescribeInstanceInformation is allowed."
            )
            raise SystemExit(1)
        print_error(f"SSM agent info error ({error_code}): {e}")
        raise SystemExit(1)

    # Fetch patch state (graceful degradation — show agent info even if patch fails)
    patch_state: Optional[dict[str, Any]] = None
    try:
        patch_state = fetch_patch_state(ssm_client, instance_id)
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied"):
            print_warning(f"Access denied querying patch state — ssm:DescribeInstancePatchStates required.")
        else:
            print_warning(f"Could not fetch patch state ({error_code}) — showing N/A.")

    # Fetch recent commands (graceful degradation)
    recent_commands: list[dict[str, Any]] = []
    try:
        recent_commands = fetch_recent_commands(ssm_client, instance_id)
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied"):
            print_warning(f"Access denied querying command history — ssm:ListCommandInvocations required.")
        else:
            print_warning(f"Could not fetch command history ({error_code}) — showing empty.")

    return render_ssm_status(
        instance_id=instance_id,
        agent_info=agent_info,
        patch_state=patch_state,
        recent_commands=recent_commands,
        output_format=output_format,
    )
