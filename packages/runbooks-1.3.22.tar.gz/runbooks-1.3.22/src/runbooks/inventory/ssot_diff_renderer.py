"""ssot_diff_renderer.py — SSOT inventory vs live AWS cross-validation renderer.

Reads SSOT files (XLSX/MD/HTML) from a local directory and live S3 inventory via
Resource Explorer aggregator (Option A) or per-account profile iteration (Option B
fallback). Computes delta, renders a CxO-readable .md report and a structured
evidence .json file.

AC5: All profile reads use os.environ.get() — no literal profile strings.
PB-1: "PARTIAL SAMPLE" warning emitted in first 200 chars of .md when stratified.
"""

import collections
import datetime
import json
import math
import os
import time
from pathlib import Path
from typing import Any, Optional

import boto3
import botocore.config
import click
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import BOX_PRIMARY, create_table, get_console, print_info, print_warning
from runbooks.vpc.aws_config_parser import parse_aws_config

# ─── Constants ────────────────────────────────────────────────────────────────

_RETRY_CONFIG = botocore.config.Config(retries={"max_attempts": 3, "mode": "adaptive"})
RATE_CAP_PER_MIN = 100
DEFAULT_SAMPLE_SIZE = 50
STALE_DAYS = 30
_TOP_N_MISMATCHES = 10

# ─── CLI entry point ──────────────────────────────────────────────────────────


@click.command("ssot-diff-renderer")
@click.option(
    "--ssot-dir", default="data/inventory", show_default=True, help="Directory containing SSOT files (XLSX/MD/HTML)."
)
@click.option(
    "--output-dir",
    default="tmp/cloudops/s3-ssot",
    show_default=True,
    help="Output directory for .md report and evidence .json.",
)
@click.option("--refresh-ssot", is_flag=True, help="Re-query live AWS to refresh SSOT baseline (AC5).")
@click.option("--accept-stale-ssot", is_flag=True, help="Suppress mtime >30-day stale-SSOT warning.")
@click.option(
    "--sample-size",
    default=DEFAULT_SAMPLE_SIZE,
    show_default=True,
    help="Max buckets to sample when rate-capped (AC3).",
)
def main(ssot_dir: str, output_dir: str, refresh_ssot: bool, accept_stale_ssot: bool, sample_size: int) -> None:
    """Render SSOT vs live AWS delta report for S3 inventory cross-validation."""
    console = get_console()
    print_info("SSOT diff renderer starting.")

    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    ssot_data = _ingest_ssot_files(ssot_dir, console, accept_stale_ssot)

    if refresh_ssot:
        console.print("[yellow]--refresh-ssot flag set: querying live AWS now.[/yellow]")

    live_buckets, is_stratified = _discover_live_buckets(console, sample_size)

    delta = _compute_delta(ssot_data, live_buckets, sample_size, is_stratified)
    _enrich_with_billing(delta, console)

    today_str = datetime.date.today().isoformat()
    md_path = out_path / f"cross-validate-{today_str}.md"
    evidence_path = out_path / f"evidence-{today_str}.json"

    _render_md_report(delta, ssot_data, is_stratified, md_path)
    _write_evidence_json(delta, ssot_data, is_stratified, evidence_path)

    # Rich summary table
    table = create_table(
        "S3 SSOT Cross-Validation Summary",
        ["Metric", "Value"],
        [
            ["SSOT bucket count", str(ssot_data.get("bucket_count", "N/A"))],
            ["Live bucket count", str(delta.get("live_count", 0))],
            ["Delta (live − SSOT)", str(delta.get("count_delta", 0))],
            ["Stratified sample", "Yes" if is_stratified else "No"],
            ["Report", str(md_path)],
            ["Evidence", str(evidence_path)],
        ],
        box_style=BOX_PRIMARY,
    )
    console.print(table)
    console.print(f"[green]Report written → {md_path}[/green]")


# ─── Option A: Resource Explorer ─────────────────────────────────────────────


def _query_resource_explorer(console) -> Optional[list[dict]]:
    """Option A: Resource Explorer aggregator query — paginated.

    Returns list of bucket dicts or None when no aggregator view found.
    """
    ops_profile = os.environ.get("AWS_OPERATIONS_PROFILE")
    region = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")

    try:
        session = boto3.Session(profile_name=ops_profile, region_name=region)
        re_client = session.client("resource-explorer-2", config=_RETRY_CONFIG)

        # Check aggregator views exist
        views_resp = re_client.list_views()
        aggregator_views = [v for v in views_resp.get("Views", []) if "aggregator" in v.lower()]
        if not aggregator_views:
            console.print("[yellow]Resource Explorer: no aggregator view found — falling back to Option B.[/yellow]")
            return None

        view_arn = aggregator_views[0]
        buckets: list[dict] = []
        paginator = re_client.get_paginator("search")
        pages = paginator.paginate(
            QueryString="service:s3 resourcetype:bucket",
            ViewArn=view_arn,
        )
        for page in pages:
            for resource in page.get("Resources", []):
                buckets.append(
                    {
                        "name": resource.get("Id", ""),
                        "arn": resource.get("Arn", ""),
                        "account_id": resource.get("OwningAccountId", ""),
                        "region": resource.get("Region", ""),
                    }
                )

        console.print(f"[green]Resource Explorer: discovered {len(buckets)} buckets.[/green]")
        return buckets

    except ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        print_warning(f"Resource Explorer query failed ({error_code}): {exc} — falling back to Option B.")
        return None
    except Exception as exc:  # noqa: BLE001
        print_warning(f"Resource Explorer unexpected error: {exc} — falling back to Option B.")
        return None


# ─── Option B: Per-account profile iteration ─────────────────────────────────


def _query_per_account(console) -> list[dict]:
    """Option B fallback: iterate workload profiles from ~/.aws/config.

    All individual AWS profiles are guaranteed to be present per HITL config.
    """
    region = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
    buckets: list[dict] = []

    try:
        account_profile_map = parse_aws_config()
    except (ValueError, FileNotFoundError) as exc:
        print_warning(f"Cannot load AWS config for Option B: {exc}")
        return []

    if not account_profile_map:
        print_warning("No workload profiles found in AWS config — returning empty bucket list.")
        return []

    console.print(f"[yellow]Option B: iterating {len(account_profile_map)} workload account profile(s).[/yellow]")

    for account_id, profile_name in account_profile_map.items():
        try:
            session = boto3.Session(profile_name=profile_name, region_name=region)
            s3_client = session.client("s3", config=_RETRY_CONFIG)
            response = s3_client.list_buckets()
            for b in response.get("Buckets", []):
                buckets.append(
                    {
                        "name": b.get("Name", ""),
                        "arn": f"arn:aws:s3:::{b.get('Name', '')}",
                        "account_id": account_id,
                        "region": region,
                        "creation_date": str(b.get("CreationDate", "")),
                    }
                )
        except ClientError as exc:
            error_code = exc.response["Error"]["Code"]
            print_warning(f"Account profile query failed ({error_code}) for profile {profile_name}: {exc}")
        except Exception as exc:  # noqa: BLE001
            print_warning(f"Unexpected error for profile {profile_name}: {exc}")

    console.print(
        f"[green]Option B: discovered {len(buckets)} buckets across {len(account_profile_map)} accounts.[/green]"
    )
    return buckets


# ─── Discovery orchestrator ───────────────────────────────────────────────────


def _stratified_sample(buckets: list[dict], sample_size: int) -> list[dict]:
    """Per-region proportional stratified sampling so all regions are represented.

    Each region receives at least 1 slot. Remaining slots distributed proportionally.
    Returns exactly sample_size buckets (or fewer when total < sample_size).
    """
    if len(buckets) <= sample_size:
        return buckets

    by_region: dict[str, list[dict]] = collections.defaultdict(list)
    for b in buckets:
        by_region[b.get("region", "unknown")].append(b)

    total = len(buckets)
    sample: list[dict] = []
    for region_buckets in by_region.values():
        # Proportional allocation with minimum 1 per region
        n = max(1, math.floor(len(region_buckets) / total * sample_size))
        sample.extend(region_buckets[:n])

    # Fill any shortfall from regions not yet fully sampled (largest regions first)
    if len(sample) < sample_size:
        sampled_names = {b.get("name", "") for b in sample}
        extras = [b for b in buckets if b.get("name", "") not in sampled_names]
        sample.extend(extras[: sample_size - len(sample)])

    return sample[:sample_size]


def _discover_live_buckets(console, sample_size: int) -> tuple[list[dict], bool]:
    """Returns (bucket_list, is_stratified). Option A → Option B fallback chain.

    Rate-cap: when live_count ≥ RATE_CAP_PER_MIN, apply per-region proportional
    stratified sampling so all regions are represented in the sample.
    """
    buckets = _query_resource_explorer(console)
    if buckets is None:
        buckets = _query_per_account(console)

    is_stratified = False
    if len(buckets) >= RATE_CAP_PER_MIN:
        print_warning(f"Rate cap reached ({len(buckets)} buckets). Applying stratified sample of {sample_size}.")
        buckets = _stratified_sample(buckets, sample_size)
        is_stratified = True

    return buckets, is_stratified


# ─── SSOT ingestion ───────────────────────────────────────────────────────────


def _ingest_ssot_files(ssot_dir: str, console, accept_stale: bool) -> dict[str, Any]:
    """Parse XLSX/MD/HTML SSOT files. Return dict with counts, timestamps, source paths."""
    ssot_path = Path(ssot_dir)
    result: dict[str, Any] = {
        "bucket_count": 0,
        "timestamps": [],
        "source_files": [],
        "time_window_mismatch": False,
        "total_bytes": 0,
    }

    if not ssot_path.exists():
        print_warning(f"SSOT directory not found: {ssot_dir}. Proceeding with 0 SSOT buckets.")
        return result

    now = time.time()
    stale_threshold = STALE_DAYS * 86400

    for ssot_file in sorted(ssot_path.iterdir()):
        if ssot_file.suffix not in {".xlsx", ".md", ".html"}:
            continue

        # mtime staleness check (AC5)
        file_age_days = (now - ssot_file.stat().st_mtime) / 86400
        if file_age_days > STALE_DAYS and not accept_stale:
            print_warning(
                f"SSOT file {ssot_file.name} is {file_age_days:.0f} days old (>{STALE_DAYS} days). "
                "Re-run with --accept-stale-ssot to suppress this warning."
            )

        mtime_iso = datetime.datetime.fromtimestamp(ssot_file.stat().st_mtime, tz=datetime.UTC).isoformat()
        result["timestamps"].append({"file": ssot_file.name, "mtime": mtime_iso})
        result["source_files"].append(str(ssot_file))

        # XLSX: count bucket rows (first sheet, column A = bucket name)
        if ssot_file.suffix == ".xlsx":
            bucket_count_from_file = _count_xlsx_buckets(ssot_file, console)
            result["bucket_count"] += bucket_count_from_file

        # MD/HTML: parse bucket count from summary line (best-effort)
        elif ssot_file.suffix in {".md", ".html"}:
            bucket_count_from_file = _count_text_buckets(ssot_file, console)
            result["bucket_count"] += bucket_count_from_file

    # Detect time-window mismatch across multiple SSOT files (AC2)
    if len(result["timestamps"]) >= 2:
        mtime_values = [t["mtime"] for t in result["timestamps"]]
        earliest = min(mtime_values)
        latest = max(mtime_values)
        if earliest != latest:
            result["time_window_mismatch"] = True
            print_warning(f"SSOT files span different timestamps: {earliest} → {latest}. Time-window mismatch flagged.")

    print_info(f"SSOT ingestion: {result['bucket_count']} buckets from {len(result['source_files'])} file(s).")
    return result


def _count_xlsx_buckets(path: Path, console) -> int:
    """Count data rows in first XLSX sheet, column A (bucket names). Returns 0 on error."""
    try:
        import openpyxl  # lazy import — optional dependency

        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        count = sum(1 for row in ws.iter_rows(min_row=2) if row[0].value)
        wb.close()
        return count
    except ImportError:
        print_warning("openpyxl not installed — cannot parse XLSX SSOT files.")
        return 0
    except Exception as exc:  # noqa: BLE001
        print_warning(f"XLSX parse error ({path.name}): {exc}")
        return 0


def _count_text_buckets(path: Path, console) -> int:
    """Best-effort count of S3 bucket names in .md/.html files."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        # Heuristic: lines containing "s3://" or "arn:aws:s3:::" indicate bucket entries
        return sum(1 for line in text.splitlines() if "arn:aws:s3:::" in line or "s3://" in line)
    except Exception as exc:  # noqa: BLE001
        print_warning(f"Text parse error ({path.name}): {exc}")
        return 0


# ─── Delta computation ────────────────────────────────────────────────────────


def _compute_delta(ssot_data: dict, live_buckets: list[dict], sample_size: int, is_stratified: bool) -> dict:
    """Compute bucket count delta, total_bytes from SSOT, and top-10 size mismatches."""
    ssot_count = ssot_data.get("bucket_count", 0)
    live_count = len(live_buckets)
    count_delta = live_count - ssot_count

    # AC1: total_bytes — summed from SSOT bucket data (supports both field name conventions)
    total_bytes_ssot = sum(b.get("size_bytes", b.get("StorageBytes", 0)) for b in ssot_data.get("buckets", []))

    # AC1: top-10 mismatches — buckets present in BOTH SSOT and live, ranked by |ssot_size - live_size|
    ssot_by_name: dict[str, dict] = {b.get("name", b.get("Name", "")): b for b in ssot_data.get("buckets", [])}
    live_by_name: dict[str, dict] = {b.get("name", b.get("Name", "")): b for b in live_buckets}
    common_names = set(ssot_by_name.keys()) & set(live_by_name.keys())
    mismatches: list[dict] = []
    for name in common_names:
        ssot_b = ssot_by_name[name]
        live_b = live_by_name[name]
        ssot_size = ssot_b.get("size_bytes", ssot_b.get("StorageBytes", 0))
        live_size = live_b.get("size_bytes", 0)
        delta_bytes = abs(ssot_size - live_size)
        if delta_bytes > 0:
            mismatches.append(
                {
                    "ssot_size_bytes": ssot_size,
                    "live_size_bytes": live_size,
                    "delta_bytes": delta_bytes,
                }
            )
    mismatches.sort(key=lambda x: x["delta_bytes"], reverse=True)
    top_10_mismatches = mismatches[:_TOP_N_MISMATCHES]

    # Region distribution (human-readable aggregate, not bare IDs)
    region_dist: dict[str, int] = {}
    for b in live_buckets:
        reg = b.get("region", "unknown")
        region_dist[reg] = region_dist.get(reg, 0) + 1

    top_regions = sorted(region_dist.items(), key=lambda x: x[1], reverse=True)[:_TOP_N_MISMATCHES]

    return {
        "ssot_count": ssot_count,
        "live_count": live_count,
        "count_delta": count_delta,
        "is_stratified": is_stratified,
        "sample_size_used": sample_size if is_stratified else live_count,
        "total_bytes_ssot": total_bytes_ssot,
        "top_10_mismatches": top_10_mismatches,
        "top_regions_by_bucket_count": [{"region": r, "bucket_count": c} for r, c in top_regions],
        "generated_at": datetime.datetime.now(tz=datetime.UTC).isoformat(),
    }


# ─── Billing enrichment (AC5) ─────────────────────────────────────────────────


def _enrich_with_billing(delta: dict, console) -> None:
    """Optional Cost Explorer enrichment when AWS_BILLING_PROFILE is configured (AC5).

    Attempts a Cost Explorer call with the billing profile. On success sets
    ``billing_enriched=True``; on failure logs a warning and sets it to False.
    Never blocks the main pipeline — purely additive.

    PII guard: billing_profile_used is a boolean flag only — no profile name emitted.
    """
    billing_profile = os.environ.get("AWS_BILLING_PROFILE")
    if not billing_profile:
        delta["billing_enriched"] = False
        return

    try:
        billing_session = boto3.Session(profile_name=billing_profile)
        ce_client = billing_session.client("ce", region_name="us-east-1", config=_RETRY_CONFIG)
        # Minimal probe: verify the billing profile can reach Cost Explorer.
        # Full per-bucket cost queries are a future enhancement (STD-S4).
        today = datetime.date.today()
        start = (today - datetime.timedelta(days=1)).isoformat()
        end = today.isoformat()
        ce_client.get_cost_and_usage(
            TimePeriod={"Start": start, "End": end},
            Granularity="DAILY",
            Metrics=["UnblendedCost"],
        )
        delta["billing_enriched"] = True
        delta["billing_profile_used"] = True  # boolean only — no profile name (PII guard)
        console.print("[green]Billing enrichment: Cost Explorer probe succeeded.[/green]")
    except ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        console.print(f"[yellow]Billing enrichment skipped ({error_code}): {exc}[/yellow]")
        delta["billing_enriched"] = False
    except Exception as exc:  # noqa: BLE001
        console.print(f"[yellow]Billing enrichment skipped (unexpected): {exc}[/yellow]")
        delta["billing_enriched"] = False


# ─── Report rendering ─────────────────────────────────────────────────────────


def _render_md_report(delta: dict, ssot_data: dict, is_stratified: bool, output_path: Path) -> None:
    """Write CxO .md report. PB-1: partial sample warning in first 200 chars if stratified."""
    lines: list[str] = []

    # PB-1: PARTIAL SAMPLE warning MUST appear within first 200 chars when stratified
    if is_stratified:
        lines.append(
            f"⚠️ PARTIAL SAMPLE — {delta['sample_size_used']} of N buckets sampled (rate cap). See evidence JSON for full count.\n"
        )
    else:
        lines.append("# S3 SSOT Cross-Validation Report\n")

    lines.append(f"**Generated**: {delta['generated_at']}  \n")
    lines.append(f"**SSOT bucket count**: {delta['ssot_count']}  \n")
    lines.append(f"**Live bucket count**: {delta['live_count']}  \n")
    lines.append(f"**Delta (live − SSOT)**: {delta['count_delta']:+d}  \n")

    if ssot_data.get("time_window_mismatch"):
        lines.append(
            "\n> ⚠️ **Time-window mismatch**: SSOT files have different snapshot timestamps. Results may not be directly comparable.\n"
        )

    if ssot_data.get("timestamps"):
        lines.append("\n## SSOT Capture Timestamps\n")
        for ts in ssot_data["timestamps"]:
            lines.append(f"- `{ts['file']}`: {ts['mtime']}\n")

    lines.append("\n## Top Regions by Bucket Count\n")
    lines.append("| Region | Bucket Count |\n|--------|-------------|\n")
    for entry in delta.get("top_regions_by_bucket_count", []):
        lines.append(f"| {entry['region']} | {entry['bucket_count']} |\n")

    lines.append(f"\n---\n*Stratified sample*: {'Yes' if is_stratified else 'No'}  \n")
    lines.append(
        f"*Evidence JSON*: `{output_path.parent / (output_path.stem.replace('cross-validate', 'evidence') + '.json')}`  \n"
    )

    output_path.write_text("".join(lines), encoding="utf-8")
    print_info(f"CxO report written → {output_path}")


def _write_evidence_json(delta: dict, ssot_data: dict, is_stratified: bool, evidence_path: Path) -> None:
    """Write structured evidence JSON (agent-consumable)."""
    evidence: dict[str, Any] = {
        "schema_version": "1.1",
        "generated_at": delta["generated_at"],
        "stratified": is_stratified,
        "time_window_mismatch": ssot_data.get("time_window_mismatch", False),
        "ssot_bucket_count": delta["ssot_count"],
        "live_bucket_count": delta["live_count"],
        "count_delta": delta["count_delta"],
        "sample_size_used": delta["sample_size_used"],
        "total_bytes_ssot": delta.get("total_bytes_ssot", 0),
        "top_10_mismatches": delta.get("top_10_mismatches", []),
        "billing_enriched": delta.get("billing_enriched", False),
        "ssot_timestamps": ssot_data.get("timestamps", []),
        "ssot_source_files": ssot_data.get("source_files", []),
        "top_regions_by_bucket_count": delta.get("top_regions_by_bucket_count", []),
    }
    evidence_path.write_text(json.dumps(evidence, indent=2, ensure_ascii=False), encoding="utf-8")
    print_info(f"Evidence JSON written → {evidence_path}")
