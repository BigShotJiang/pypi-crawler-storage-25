"""
AWS resource collectors organized by service category.

This module provides specialized collectors for different AWS service categories,
each implementing a common interface for resource discovery and inventory.

Categories:
    - aws_compute: EC2, Lambda, ECS, Batch, Fargate
    - aws_storage: S3, EBS, EFS, FSx
    - aws_database: RDS, DynamoDB, ElastiCache, Redshift
    - aws_network: VPC, ELB, CloudFront, Route53, API Gateway
    - aws_security: IAM, GuardDuty, Config, Security Hub, WAF
    - aws_management: CloudFormation, Organizations, Control Tower, SSM
    - aws_certificates: ACM, IAM server certificates, Azure Key Vault
"""

from runbooks.inventory.collectors.aws_certificates import CertificateCollector
from runbooks.inventory.collectors.aws_compute import ComputeResourceCollector
from runbooks.inventory.collectors.aws_management import ManagementResourceCollector, OrganizationsManager
from runbooks.inventory.collectors.aws_networking import SubnetCollector, VPCCollector
from runbooks.inventory.collectors.base import BaseResourceCollector
from runbooks.inventory.collectors.resource_explorer import ResourceExplorerCollector

__all__ = [
    "BaseResourceCollector",
    "CertificateCollector",
    "ComputeResourceCollector",
    "VPCCollector",
    "SubnetCollector",
    "ManagementResourceCollector",
    "OrganizationsManager",
    "ResourceExplorerCollector",
]
