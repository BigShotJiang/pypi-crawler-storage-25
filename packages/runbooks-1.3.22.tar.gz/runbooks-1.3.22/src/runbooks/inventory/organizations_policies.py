"""
AWS Organizations policy discovery wrapper.

Wraps organizations.list_policies for 4 policy types:
  - SERVICE_CONTROL_POLICY
  - TAG_POLICY
  - BACKUP_POLICY
  - AISERVICES_OPT_OUT_POLICY

Pagination: organizations.list_policies uses NextToken (NOT Marker).
Note: IAM list_policies uses Marker — different service, different API shape.
The Marker pattern in inventory_modules.py:2677 is IAM-only.

READONLY only — no create/delete/update operations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import botocore.config
import boto3

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# All 4 Organizations policy types supported by list_policies Filter.
# AISERVICES_OPT_OUT_POLICY is exposed as "chatbot-policies" in CLI output
# to match HITL nomenclature (AC-A.3, plan annotation in CA log).
ALL_POLICY_TYPES = [
    "SERVICE_CONTROL_POLICY",
    "TAG_POLICY",
    "BACKUP_POLICY",
    "AISERVICES_OPT_OUT_POLICY",
]

_RETRY_CONFIG = botocore.config.Config(retries={"max_attempts": 3, "mode": "adaptive"})


def list_organization_policies_for_type(client: "boto3.client", policy_type: str) -> list[dict]:
    """Return all policies of the given type via NextToken pagination.

    Paginates organizations.list_policies until no NextToken remains.
    Empty list is a valid result (org may have no policies of this type).

    Args:
        client: A boto3 organizations client (must already carry retry config).
        policy_type: One of ALL_POLICY_TYPES.

    Returns:
        List of policy dicts as returned by the AWS API.
    """
    policies: list[dict] = []
    kwargs: dict = {"Filter": policy_type}

    while True:
        response = client.list_policies(**kwargs)
        policies.extend(response.get("Policies", []))

        next_token = response.get("NextToken")
        if not next_token:
            break
        kwargs["NextToken"] = next_token

    logger.info("list_organization_policies_for_type: %s → %d policies", policy_type, len(policies))
    return policies


def list_organization_policies(session: boto3.Session, policy_type: str = "ALL") -> dict[str, list[dict]]:
    """Return a dict keyed by policy type, each value a list of policy dicts.

    When policy_type == 'ALL', iterates all 4 supported types.
    When policy_type is a specific type, returns a single-entry dict.

    Args:
        session: A boto3.Session (caller provides profile + region).
        policy_type: 'ALL' or one of ALL_POLICY_TYPES.

    Returns:
        Dict mapping policy_type string to list of policy dicts.

    Raises:
        botocore.exceptions.ClientError: Propagated on auth/permission failure.
    """
    client = session.client("organizations", config=_RETRY_CONFIG)

    types_to_fetch = ALL_POLICY_TYPES if policy_type == "ALL" else [policy_type]
    result: dict[str, list[dict]] = {}

    for pt in types_to_fetch:
        result[pt] = list_organization_policies_for_type(client, pt)

    return result
