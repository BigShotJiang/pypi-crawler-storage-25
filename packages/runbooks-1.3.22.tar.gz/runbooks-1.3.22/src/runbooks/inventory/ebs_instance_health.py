#!/usr/bin/env python3
"""
EBS Instance Health - Volume Inventory, Metrics, and Encryption Audit

Queries EC2 and CloudWatch for EBS volumes attached to a specific EC2 instance:
- Volume ID, device, size, type, IOPS (provisioned), throughput, encrypted, KMS key
- CloudWatch VolumeReadOps, VolumeWriteOps, BurstBalance (30-day average)
- Encryption audit: flags unencrypted volumes as HIGH risk
- Summary panel: total storage, encrypted %, gp2 vs gp3 migration candidates

READONLY: Uses ec2:DescribeVolumes and cloudwatch:GetMetricStatistics — no mutations.

Usage:
    runbooks inventory ebs-health --instance-id i-0abc123 --profile ops-profile
    runbooks inventory ebs-health --instance-id i-0abc123 --profile ops-profile --output json
"""

import json
from datetime import datetime, timedelta, UTC
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    create_table,
    print_error,
    print_info,
)

# Retry config per Rule 6 (AWS API Consumer Audit)
_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})


def _get_ec2_client(profile: Optional[str], region: str):
    """Create EC2 client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("ec2", config=_RETRY_CONFIG)


def _get_cloudwatch_client(profile: Optional[str], region: str):
    """Create CloudWatch client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("cloudwatch", config=_RETRY_CONFIG)


def fetch_volumes(ec2_client, instance_id: str) -> list[dict[str, Any]]:
    """
    Fetch EBS volumes attached to a specific instance.

    Args:
        ec2_client: Boto3 EC2 client
        instance_id: EC2 instance ID

    Returns:
        List of volume dicts from DescribeVolumes response
    """
    paginator = ec2_client.get_paginator("describe_volumes")
    volumes: list[dict[str, Any]] = []
    for page in paginator.paginate(
        Filters=[{"Name": "attachment.instance-id", "Values": [instance_id]}],
        PaginationConfig={"MaxItems": 200, "PageSize": 100},
    ):
        volumes.extend(page.get("Volumes", []))
    return volumes


def fetch_metric_avg(
    cw_client,
    volume_id: str,
    metric_name: str,
    days: int = 30,
) -> Optional[float]:
    """
    Fetch 30-day average for a single CloudWatch EBS metric.

    Args:
        cw_client: Boto3 CloudWatch client
        volume_id: EBS volume ID
        metric_name: CloudWatch metric name (e.g. VolumeReadOps)
        days: Lookback window in days (default 30)

    Returns:
        Average value as float, or None if no data
    """
    end_time = datetime.now(UTC)
    start_time = end_time - timedelta(days=days)

    try:
        response = cw_client.get_metric_statistics(
            Namespace="AWS/EBS",
            MetricName=metric_name,
            Dimensions=[{"Name": "VolumeId", "Value": volume_id}],
            StartTime=start_time,
            EndTime=end_time,
            Period=86400,  # Daily aggregation
            Statistics=["Average"],
        )
        datapoints = response.get("Datapoints", [])
        if not datapoints:
            return None
        return sum(dp["Average"] for dp in datapoints) / len(datapoints)
    except ClientError:
        return None


def _extract_volume_info(volume: dict[str, Any]) -> dict[str, Any]:
    """Extract normalised volume fields from DescribeVolumes response."""
    attachments = volume.get("Attachments", [])
    device = attachments[0].get("Device", "N/A") if attachments else "N/A"
    kms_key = volume.get("KmsKeyId", "")
    if kms_key:
        # Shorten ARN for display
        kms_key = kms_key.split("/")[-1] if "/" in kms_key else kms_key
    return {
        "volume_id": volume.get("VolumeId", "N/A"),
        "device": device,
        "size_gb": volume.get("Size", 0),
        "volume_type": volume.get("VolumeType", "N/A"),
        "iops_provisioned": volume.get("Iops", "N/A"),
        "throughput_mbps": volume.get("Throughput", "N/A"),
        "encrypted": volume.get("Encrypted", False),
        "kms_key": kms_key or ("AWS Managed" if volume.get("Encrypted") else "NONE"),
        "state": volume.get("State", "N/A"),
        "create_time": volume.get("CreateTime"),
    }


def run_ebs_instance_health(
    instance_id: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Fetch and render EBS health for volumes attached to an EC2 instance.

    Args:
        instance_id: EC2 instance ID (e.g. i-0abc123)
        profile: AWS profile name (None uses default/env)
        region: AWS region (default: ap-southeast-2)
        output_format: "table" or "json"

    Returns:
        Structured dict with volumes list and summary

    Raises:
        SystemExit on access denied or unexpected API errors
    """
    print_info(f"Fetching EBS health for {instance_id} in {region}...")

    try:
        ec2_client = _get_ec2_client(profile, region)
        cw_client = _get_cloudwatch_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create AWS clients: {e}")
        raise SystemExit(1)

    # Fetch volumes
    try:
        raw_volumes = fetch_volumes(ec2_client, instance_id)
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("AccessDeniedException", "AccessDenied", "UnauthorizedOperation"):
            print_error(
                f"Access denied querying EBS volumes with profile '{profile}'. Ensure ec2:DescribeVolumes is allowed."
            )
            raise SystemExit(1)
        print_error(f"EC2 API error ({error_code}): {e}")
        raise SystemExit(1)

    if not raw_volumes:
        console.print(f"[yellow]No EBS volumes attached to instance {instance_id}.[/yellow]")
        return {"instance_id": instance_id, "volumes": [], "summary": {}}

    # Build volume records with CW metrics
    volumes_data: list[dict[str, Any]] = []
    print_info(f"Fetching CloudWatch metrics for {len(raw_volumes)} volume(s)...")

    for vol in raw_volumes:
        info = _extract_volume_info(vol)
        vol_id = info["volume_id"]

        # Fetch 30-day average IOPS and BurstBalance
        read_ops_avg = fetch_metric_avg(cw_client, vol_id, "VolumeReadOps")
        write_ops_avg = fetch_metric_avg(cw_client, vol_id, "VolumeWriteOps")
        burst_balance_avg = fetch_metric_avg(cw_client, vol_id, "BurstBalance")

        # Actual IOPS = daily average of (ReadOps + WriteOps) / 86400 seconds
        actual_iops: Optional[float] = None
        if read_ops_avg is not None and write_ops_avg is not None:
            actual_iops = (read_ops_avg + write_ops_avg) / 86400.0

        info["actual_iops_30d"] = round(actual_iops, 1) if actual_iops is not None else None
        info["burst_balance_30d"] = round(burst_balance_avg, 1) if burst_balance_avg is not None else None
        info["encryption_risk"] = "HIGH" if not info["encrypted"] else "OK"

        # gp2 migration candidate: unencrypted OR gp2 type
        info["gp2_migration_candidate"] = info["volume_type"] == "gp2"

        volumes_data.append(info)

    # Build summary
    total_gb = sum(v["size_gb"] for v in volumes_data)
    encrypted_count = sum(1 for v in volumes_data if v["encrypted"])
    gp2_count = sum(1 for v in volumes_data if v["gp2_migration_candidate"])
    unencrypted_count = len(volumes_data) - encrypted_count

    summary = {
        "total_volumes": len(volumes_data),
        "total_storage_gb": total_gb,
        "encrypted_count": encrypted_count,
        "unencrypted_count": unencrypted_count,
        "encrypted_pct": round(encrypted_count / len(volumes_data) * 100, 1) if volumes_data else 0,
        "gp2_migration_candidates": gp2_count,
    }

    structured = {
        "instance_id": instance_id,
        "volumes": volumes_data,
        "summary": summary,
    }

    if output_format == "json":
        console.print_json(json.dumps(structured, default=str, indent=2))
        return structured

    # --- Rich table rendering ---
    console.print(f"\n[bold cyan]EBS Instance Health: {instance_id}[/bold cyan]\n")

    vol_table = create_table(
        title="EBS Volumes",
        columns=[
            {"header": "Volume ID", "style": "cyan", "no_wrap": True},
            {"header": "Device", "style": "white", "no_wrap": True},
            {"header": "Size (GiB)", "style": "white", "justify": "right"},
            {"header": "Type", "style": "white", "no_wrap": True},
            {"header": "IOPS (prov.)", "style": "white", "justify": "right"},
            {"header": "IOPS (30d avg)", "style": "white", "justify": "right"},
            {"header": "Burst% (30d)", "style": "white", "justify": "right"},
            {"header": "Encrypted", "style": "white", "no_wrap": True},
            {"header": "KMS Key", "style": "dim"},
        ],
    )

    for v in volumes_data:
        encrypted_str = "[green]Yes[/green]" if v["encrypted"] else "[red bold]No (HIGH)[/red bold]"
        iops_actual = str(v["actual_iops_30d"]) if v["actual_iops_30d"] is not None else "[dim]N/A[/dim]"
        burst_str = str(v["burst_balance_30d"]) if v["burst_balance_30d"] is not None else "[dim]N/A[/dim]"
        vol_table.add_row(
            v["volume_id"],
            v["device"],
            str(v["size_gb"]),
            v["volume_type"],
            str(v["iops_provisioned"]),
            iops_actual,
            burst_str,
            encrypted_str,
            v["kms_key"],
        )

    console.print(vol_table)

    # Summary panel
    enc_color = "green" if summary["encrypted_pct"] == 100.0 else "yellow" if summary["encrypted_pct"] > 0 else "red"
    summary_lines = [
        f"[bold]Total Volumes:[/bold] {summary['total_volumes']}",
        f"[bold]Total Storage:[/bold] {summary['total_storage_gb']} GiB",
        f"[bold]Encrypted:[/bold] [{enc_color}]{summary['encrypted_count']}/{summary['total_volumes']} "
        f"({summary['encrypted_pct']}%)[/{enc_color}]",
    ]
    if summary["unencrypted_count"] > 0:
        summary_lines.append(f"[bold red]Unencrypted (HIGH risk):[/bold red] {summary['unencrypted_count']} volume(s)")
    if summary["gp2_migration_candidates"] > 0:
        summary_lines.append(
            f"[bold yellow]gp2 Migration Candidates:[/bold yellow] {summary['gp2_migration_candidates']} "
            f"volume(s) — consider upgrading to gp3 for cost savings"
        )

    console.print(
        create_panel(
            "\n".join(summary_lines),
            title="EBS Summary",
            border_style="cyan",
        )
    )
    console.print()

    return structured
