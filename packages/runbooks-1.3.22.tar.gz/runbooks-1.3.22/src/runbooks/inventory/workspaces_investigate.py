#!/usr/bin/env python3
"""
WorkSpaces Investigation Orchestrator - 6-Phase Comprehensive Analysis

Chains 6 investigation phases into a single command for deep-dive WorkSpaces analysis:

Phase 1 (Discovery):   workspaces:DescribeWorkspaces filtered by workspace-id
Phase 2 (Metadata):    Bundle type, compute type, running mode, directory, user
Phase 3 (Security):    Volume encryption, IP access control, root/user volume encryption
Phase 4 (Network):     Directory VPC/subnet, security groups, connection state
Phase 5 (Compliance):  Auto-stop timeout, maintenance mode, protocol (WSP vs PCoIP)
Phase 6 (Summary):     Cost optimisation (from usage state), recommendations

Design: Composition over inheritance. Each phase is self-contained with graceful
        degradation -- a phase failure does not abort subsequent phases.

READONLY: workspaces:DescribeWorkspaces*, workspaces:DescribeWorkspaceDirectories,
          workspaces:DescribeWorkspaceBundles, workspaces:DescribeConnectionAliases,
          workspaces:DescribeWorkspaceConnectionStatus -- no mutations.

Usage:
    runbooks inventory workspaces-investigate --workspace-id wsb-abc123 --profile ops
    runbooks inventory workspaces-investigate --workspace-id wsb-abc123 --profile ops --output json
"""

import json
from datetime import datetime, UTC
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    print_error,
    print_info,
)
from runbooks.finops.workspaces_pricing import calculate_workspace_monthly_cost

_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})

_RISK_HIGH = 60
_RISK_CRITICAL = 80

# WorkSpaces billing hours per month assumption
_MONTHLY_HOURS = 730


def _get_ws_client(profile: Optional[str], region: str):
    """Create WorkSpaces client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("workspaces", config=_RETRY_CONFIG)


def _get_ds_client(profile: Optional[str], region: str):
    """Create Directory Service client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("ds", config=_RETRY_CONFIG)


# ─── Phase 1: Discovery ───────────────────────────────────────────────────────


def phase1_discovery(ws_client, workspace_id: str) -> dict[str, Any]:
    """
    Fetch WorkSpace metadata via DescribeWorkspaces filtered by workspace-id.

    Returns dict with user, state, running_mode, directory_id.
    """
    try:
        response = ws_client.describe_workspaces(WorkspaceIds=[workspace_id])
        workspaces = response.get("Workspaces", [])
        if not workspaces:
            return {"error": f"WorkSpace {workspace_id} not found"}

        ws = workspaces[0]
        wsp_props = ws.get("WorkspaceProperties", {})

        return {
            "workspace_id": ws.get("WorkspaceId", workspace_id),
            "user_name": ws.get("UserName", "N/A"),
            "directory_id": ws.get("DirectoryId", "N/A"),
            "bundle_id": ws.get("BundleId", "N/A"),
            "state": ws.get("State", "N/A"),
            "subnet_id": ws.get("SubnetId", "N/A"),
            "error_code": ws.get("ErrorCode"),
            "error_message": ws.get("ErrorMessage"),
            "computer_name": ws.get("ComputerName", "N/A"),
            "ip_address": ws.get("IpAddress", "N/A"),
            "root_volume_size_gb": wsp_props.get("RootVolumeSizeGib", "N/A"),
            "user_volume_size_gb": wsp_props.get("UserVolumeSizeGib", "N/A"),
            "compute_type": wsp_props.get("ComputeTypeName", "N/A"),
            "running_mode": wsp_props.get("RunningMode", "N/A"),
            "auto_stop_timeout_hours": wsp_props.get("RunningModeAutoStopTimeoutInMinutes", 60) // 60,
            "protocols": wsp_props.get("Protocols", ["PCoIP"]),
            "root_volume_encrypted": ws.get("RootVolumeEncryptionEnabled", False),
            "user_volume_encrypted": ws.get("UserVolumeEncryptionEnabled", False),
            "volume_encryption_key": ws.get("VolumeEncryptionKey"),
            "estimated_monthly_cost_usd": calculate_workspace_monthly_cost(
                wsp_props.get("ComputeTypeName", ""),
                wsp_props.get("RunningMode", "AUTO_STOP"),
            ),
            "error": None,
        }
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        return {"error": f"WorkSpaces API error ({error_code}): {e}"}


# ─── Phase 2: Metadata ────────────────────────────────────────────────────────


def phase2_metadata(ws_client, workspace_id: str, bundle_id: str, directory_id: str) -> dict[str, Any]:
    """
    Fetch bundle details and directory information.

    Returns dict with bundle_name, os_type, directory_alias.
    """
    result: dict[str, Any] = {
        "bundle_name": "N/A",
        "bundle_description": "N/A",
        "os_type": "N/A",
        "directory_alias": "N/A",
        "directory_type": "N/A",
        "dns_servers": [],
        "error": None,
    }

    # Bundle details
    try:
        bundle_response = ws_client.describe_workspace_bundles(BundleIds=[bundle_id])
        bundles = bundle_response.get("Bundles", [])
        if bundles:
            bundle = bundles[0]
            result["bundle_name"] = bundle.get("Name", "N/A")
            result["bundle_description"] = bundle.get("Description", "N/A")
            result["os_type"] = bundle.get("BundleType", "N/A")
            compute_type = bundle.get("ComputeType", {}).get("Name", "N/A")
            result["compute_type_from_bundle"] = compute_type
    except ClientError as e:
        result["bundle_error"] = f"Bundle fetch failed: {e.response['Error']['Code']}"

    # Directory details
    try:
        dir_response = ws_client.describe_workspace_directories(DirectoryIds=[directory_id])
        directories = dir_response.get("Directories", [])
        if directories:
            d = directories[0]
            result["directory_alias"] = d.get("Alias", "N/A")
            result["directory_type"] = d.get("DirectoryType", "N/A")
            result["dns_servers"] = d.get("DnsIpAddresses", [])
            result["workspace_security_group_id"] = d.get("WorkspaceSecurityGroupId", "N/A")
    except ClientError as e:
        result["dir_error"] = f"Directory fetch failed: {e.response['Error']['Code']}"

    return result


# ─── Phase 3: Security ────────────────────────────────────────────────────────


def phase3_security(ws_client, workspace_id: str, discovery: dict[str, Any]) -> dict[str, Any]:
    """
    Assess WorkSpaces security: volume encryption, IP access control.

    Returns dict with encryption status and IP access control state.
    """
    result: dict[str, Any] = {
        "root_volume_encrypted": discovery.get("root_volume_encrypted", False),
        "user_volume_encrypted": discovery.get("user_volume_encrypted", False),
        "both_volumes_encrypted": (
            discovery.get("root_volume_encrypted", False) and discovery.get("user_volume_encrypted", False)
        ),
        "ip_access_control_groups": [],
        "error": None,
    }

    # Get connection status (last known connection)
    try:
        conn_response = ws_client.describe_workspaces_connection_status(WorkspaceIds=[workspace_id])
        statuses = conn_response.get("WorkspacesConnectionStatus", [])
        if statuses:
            status = statuses[0]
            last_conn = status.get("LastKnownUserConnectionTimestamp")
            result["last_connection"] = str(last_conn) if last_conn else "Never"
            result["connection_state"] = status.get("ConnectionState", "N/A")
        else:
            result["last_connection"] = "N/A"
            result["connection_state"] = "N/A"
    except ClientError as e:
        result["conn_error"] = f"Connection status fetch failed: {e.response['Error']['Code']}"

    return result


# ─── Phase 4: Network ─────────────────────────────────────────────────────────


def phase4_network(ws_client, workspace_id: str, directory_id: str) -> dict[str, Any]:
    """
    Assess WorkSpaces network: directory VPC/subnet, security groups.

    VPC ID is sourced from VpcSettings.VpcId on the WorkSpaces directory record.
    WorkspaceCreationProperties.CustomSecurityGroupId is a security group ID, not a
    VPC ID -- using it for vpc_id was ISS-009.

    Returns dict with vpc_id, subnet_ids, security_group_id.
    """
    result: dict[str, Any] = {
        "vpc_id": "N/A",
        "subnet_ids": [],
        "workspace_security_group_id": "N/A",
        "error": None,
    }

    try:
        dir_response = ws_client.describe_workspace_directories(DirectoryIds=[directory_id])
        directories = dir_response.get("Directories", [])
        if directories:
            d = directories[0]
            # VpcSettings.VpcId is the authoritative source for the VPC ID that hosts
            # this WorkSpaces directory.  CustomSecurityGroupId is a SG ID.
            result["vpc_id"] = d.get("VpcSettings", {}).get("VpcId", "N/A")
            # SubnetIds from the directory registration
            result["subnet_ids"] = d.get("SubnetIds", [])
            result["workspace_security_group_id"] = d.get("WorkspaceSecurityGroupId", "N/A")
            result["workspace_access_properties"] = d.get("WorkspaceAccessProperties", {})
    except ClientError as e:
        result["error"] = f"Network assessment failed: {e.response['Error']['Code']}"

    return result


# ─── Phase 5: Compliance ──────────────────────────────────────────────────────


def phase5_compliance(discovery: dict[str, Any]) -> dict[str, Any]:
    """
    Assess WorkSpaces compliance: protocol, running mode, auto-stop.

    Returns dict with compliance flags.
    """
    protocols = discovery.get("protocols", ["PCoIP"])
    running_mode = discovery.get("running_mode", "N/A")
    auto_stop_hours = discovery.get("auto_stop_timeout_hours", 1)
    state = discovery.get("state", "N/A")

    return {
        "protocol": protocols[0] if protocols else "PCoIP",
        "wsp_enabled": "WSP" in (protocols if isinstance(protocols, list) else []),
        "running_mode": running_mode,
        "is_always_on": running_mode == "ALWAYS_ON",
        "auto_stop_timeout_hours": auto_stop_hours,
        "auto_stop_too_long": auto_stop_hours > 2,
        "state": state,
        "is_stopped": state in ("STOPPED", "STOP_PENDING"),
        "is_suspended": state in ("SUSPENDED",),
        "is_error": state in ("ERROR", "UNHEALTHY"),
        "error": None,
    }


# ─── Phase 6: Risk Scoring ────────────────────────────────────────────────────


def phase6_summary(
    workspace_id: str,
    p1: dict[str, Any],
    p2: dict[str, Any],
    p3: dict[str, Any],
    p4: dict[str, Any],
    p5: dict[str, Any],
) -> dict[str, Any]:
    """
    Aggregate phase results into risk score and cost optimisation recommendations.

    Risk scoring (100-point scale):
    - Volumes not encrypted:        15 pts each (root/user), max 30
    - AlwaysOn unused (stopped):    20 pts
    - Auto-stop timeout > 2h:       10 pts
    - Error state:                  25 pts
    - Legacy protocol (PCoIP only): 5 pts
    """
    risk_score = 0
    recommendations: list[dict[str, str]] = []

    # Volume encryption
    if not p3.get("root_volume_encrypted"):
        risk_score += 15
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable root volume encryption (requires new WorkSpace deployment)",
            }
        )
    if not p3.get("user_volume_encrypted"):
        risk_score += 15
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable user volume encryption (requires new WorkSpace deployment)",
            }
        )

    # AlwaysOn while stopped/unused
    if p5.get("is_always_on") and p5.get("is_stopped"):
        risk_score += 20
        monthly_cost = p1.get("estimated_monthly_cost_usd")
        cost_str = f" (~USD {monthly_cost:.0f}/month)" if monthly_cost else ""
        recommendations.append(
            {
                "priority": "P0",
                "action": f"WorkSpace is ALWAYS_ON but stopped{cost_str} -- switch to AUTO_STOP or terminate",
            }
        )

    # Auto-stop timeout
    if p5.get("auto_stop_too_long"):
        risk_score += 10
        recommendations.append(
            {
                "priority": "P2",
                "action": f"Reduce auto-stop timeout from {p5.get('auto_stop_timeout_hours', '?')}h to 1-2h to reduce cost",
            }
        )

    # Error state
    if p5.get("is_error"):
        risk_score += 25
        recommendations.append(
            {
                "priority": "P0",
                "action": f"WorkSpace is in error state: {p1.get('state', 'UNKNOWN')} -- investigate and remediate",
            }
        )

    # Protocol recommendation
    if not p5.get("wsp_enabled"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P3",
                "action": "Consider enabling WSP (WorkSpaces Streaming Protocol) for better performance",
            }
        )

    # Cost insight
    monthly_cost = p1.get("estimated_monthly_cost_usd")
    if monthly_cost and p5.get("is_stopped"):
        recommendations.append(
            {
                "priority": "P1",
                "action": f"WorkSpace is stopped but may still incur ~USD {monthly_cost:.0f}/month -- review usage",
            }
        )

    risk_score = min(risk_score, 100)

    if risk_score >= _RISK_CRITICAL:
        risk_level, risk_color = "CRITICAL", "red bold"
    elif risk_score >= _RISK_HIGH:
        risk_level, risk_color = "HIGH", "red"
    elif risk_score >= 30:
        risk_level, risk_color = "MEDIUM", "yellow"
    else:
        risk_level, risk_color = "LOW", "green"

    return {
        "workspace_id": workspace_id,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "recommendations": recommendations,
        "estimated_monthly_cost_usd": p1.get("estimated_monthly_cost_usd"),
    }


# ─── Rendering ────────────────────────────────────────────────────────────────


def _phase_status(phase_data: dict[str, Any]) -> str:
    """Return coloured status indicator for a phase result."""
    if phase_data.get("error"):
        return "[yellow]SKIP[/yellow]"
    return "[green]OK[/green]"


def render_investigation(
    workspace_id: str,
    phases: dict[str, dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    """Render WorkSpaces investigation results as a Rich panel."""
    p1 = phases["discovery"]
    p2 = phases["metadata"]
    p3 = phases["security"]
    p4 = phases["network"]
    p5 = phases["compliance"]

    risk_color = summary.get("risk_color", "white")
    risk_level = summary.get("risk_level", "UNKNOWN")
    risk_score = summary.get("risk_score", 0)

    lines: list[str] = []

    if not p1.get("error"):
        cost = summary.get("estimated_monthly_cost_usd")
        cost_str = f" ~USD {cost:.0f}/mo" if cost else ""
        lines.append(
            f"  Phase 1: Discovery   {_phase_status(p1)}  "
            f"(user: {p1.get('user_name', 'N/A')}, "
            f"state: {p1.get('state', 'N/A')}, "
            f"{p1.get('compute_type', 'N/A')}{cost_str})"
        )
        lines.append(
            f"           Running mode: {p1.get('running_mode', 'N/A')}  "
            f"Protocol: {', '.join(p1.get('protocols', ['PCoIP']))}"
        )
    else:
        lines.append(f"  Phase 1: Discovery   [yellow]SKIP[/yellow]  {p1['error']}")

    if not p2.get("error"):
        lines.append(
            f"  Phase 2: Metadata    {_phase_status(p2)}  "
            f"(bundle: {p2.get('bundle_name', 'N/A')}, "
            f"dir: {p2.get('directory_alias', 'N/A')}, "
            f"type: {p2.get('directory_type', 'N/A')})"
        )
    else:
        lines.append(f"  Phase 2: Metadata    [yellow]SKIP[/yellow]  {p2.get('error', 'No data')}")

    root_enc = "[green]Yes[/green]" if p3.get("root_volume_encrypted") else "[red]No[/red]"
    user_enc = "[green]Yes[/green]" if p3.get("user_volume_encrypted") else "[red]No[/red]"
    last_conn = p3.get("last_connection", "N/A")
    lines.append(
        f"  Phase 3: Security    {_phase_status(p3)}  "
        f"(root encrypted: {root_enc}, user encrypted: {user_enc}, "
        f"last connection: {last_conn})"
    )

    if not p4.get("error"):
        lines.append(
            f"  Phase 4: Network     {_phase_status(p4)}  "
            f"(SG: {p4.get('workspace_security_group_id', 'N/A')}, "
            f"subnets: {len(p4.get('subnet_ids', []))})"
        )
    else:
        lines.append(f"  Phase 4: Network     [yellow]SKIP[/yellow]  {p4.get('error', 'No data')}")

    if not p5.get("error"):
        wsp_str = "[green]Yes[/green]" if p5.get("wsp_enabled") else "[dim]No[/dim]"
        auto_timeout = p5.get("auto_stop_timeout_hours", "N/A")
        timeout_color = "red" if p5.get("auto_stop_too_long") else "green"
        lines.append(
            f"  Phase 5: Compliance  {_phase_status(p5)}  "
            f"(WSP: {wsp_str}, "
            f"auto-stop: [{timeout_color}]{auto_timeout}h[/{timeout_color}], "
            f"mode: {p5.get('running_mode', 'N/A')})"
        )
    else:
        lines.append(f"  Phase 5: Compliance  [yellow]SKIP[/yellow]  {p5.get('error', 'No data')}")

    lines.append(
        f"\n  Phase 6: Summary     [green]OK[/green]  "
        f"Risk Score: [{risk_color}]{risk_score}/100 ({risk_level})[/{risk_color}]"
    )

    recs = summary.get("recommendations", [])
    if recs:
        lines.append("\n  [bold]Recommendations:[/bold]")
        for i, rec in enumerate(recs, 1):
            priority = rec["priority"]
            p_color = {"P0": "red bold", "P1": "red", "P2": "yellow", "P3": "cyan"}.get(priority, "white")
            lines.append(f"  {i}. [[{p_color}]{priority}[/{p_color}]] {rec['action']}")

    console.print(
        create_panel(
            "\n".join(lines),
            title=f"WorkSpaces Investigation: {workspace_id}",
            border_style=risk_color.split()[0],
        )
    )


# ─── Top-level runner ─────────────────────────────────────────────────────────


def run_workspaces_investigate(
    workspace_id: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Run a 6-phase WorkSpaces investigation and render results.

    Args:
        workspace_id: WorkSpace ID (e.g. ws-abc123def)
        profile: AWS profile name (None uses default/env)
        region: AWS region (default: ap-southeast-2)
        output_format: "table" or "json"

    Returns:
        Structured dict with all phase results and risk summary

    Raises:
        SystemExit on unrecoverable initial errors
    """
    print_info(f"Starting WorkSpaces investigation for {workspace_id} in {region}...")

    try:
        ws_client = _get_ws_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create WorkSpaces client: {e}")
        raise SystemExit(1)

    phases: dict[str, dict[str, Any]] = {}

    console.print("[dim]Phase 1/6: Discovery...[/dim]")
    phases["discovery"] = phase1_discovery(ws_client, workspace_id)
    if phases["discovery"].get("error") and "not found" in str(phases["discovery"]["error"]).lower():
        print_error(f"WorkSpace {workspace_id} not found. Aborting investigation.")
        raise SystemExit(1)

    discovery = phases["discovery"]
    bundle_id = discovery.get("bundle_id", "N/A")
    directory_id = discovery.get("directory_id", "N/A")

    console.print("[dim]Phase 2/6: Metadata...[/dim]")
    phases["metadata"] = phase2_metadata(ws_client, workspace_id, bundle_id, directory_id)

    console.print("[dim]Phase 3/6: Security...[/dim]")
    phases["security"] = phase3_security(ws_client, workspace_id, discovery)

    console.print("[dim]Phase 4/6: Network...[/dim]")
    phases["network"] = phase4_network(ws_client, workspace_id, directory_id)

    console.print("[dim]Phase 5/6: Compliance...[/dim]")
    phases["compliance"] = phase5_compliance(discovery)

    console.print("[dim]Phase 6/6: Risk scoring...[/dim]")
    summary = phase6_summary(
        workspace_id,
        phases["discovery"],
        phases["metadata"],
        phases["security"],
        phases["network"],
        phases["compliance"],
    )

    result: dict[str, Any] = {
        "workspace_id": workspace_id,
        "region": region,
        "phases": phases,
        "summary": summary,
        "timestamp": datetime.now(UTC).isoformat(),
    }

    if output_format == "json":
        console.print_json(json.dumps(result, default=str, indent=2))
        return result

    render_investigation(workspace_id, phases, summary)
    return result
