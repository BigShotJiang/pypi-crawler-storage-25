"""
AWS AppRegistry (Service Catalog AppRegistry) discovery wrapper.

Wraps servicecatalog-appregistry.list_applications.

AppRegistry is account-scoped (not org-scoped) — caller uses $AWS_OPERATIONS_PROFILE.
Pagination: NextToken on list_applications.

READONLY only — no create/delete/update operations.
"""

from __future__ import annotations

import logging

import botocore.config
import boto3

logger = logging.getLogger(__name__)

_RETRY_CONFIG = botocore.config.Config(retries={"max_attempts": 3, "mode": "adaptive"})


def list_appregistry_applications_all(client: "boto3.client") -> list[dict]:
    """Return all AppRegistry applications in the account via NextToken pagination.

    Args:
        client: A boto3 servicecatalog-appregistry client (must carry retry config).

    Returns:
        List of Application dicts as returned by the AWS API.
        Empty list is valid — account may have no AppRegistry applications.
    """
    apps: list[dict] = []
    kwargs: dict = {}

    while True:
        response = client.list_applications(**kwargs)
        apps.extend(response.get("applications", []))

        next_token = response.get("nextToken")
        if not next_token:
            break
        kwargs["nextToken"] = next_token

    logger.info("list_appregistry_applications_all: → %d apps", len(apps))
    return apps


def build_appregistry_session_client(session: boto3.Session, region: str) -> "boto3.client":
    """Create a servicecatalog-appregistry client with retry config from a session.

    Args:
        session: A boto3.Session (caller provides profile).
        region: AWS region for AppRegistry (service is account-scoped, region-endpoint).

    Returns:
        boto3 client for servicecatalog-appregistry with adaptive retry.
    """
    return session.client("servicecatalog-appregistry", region_name=region, config=_RETRY_CONFIG)
