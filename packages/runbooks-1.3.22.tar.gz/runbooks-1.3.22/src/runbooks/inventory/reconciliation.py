"""Cross-source AWS inventory reconciliation.

Given an SSOT (CMDB export, FinOps snapshot, security audit, M&A asset list)
in xlsx/csv/json format, this module collects live AWS inventory via the AWS
Resource Groups Tagging API, supplements with CodePipeline webhooks (which
Resource Explorer 2 does not index), and computes Jaccard precision/recall/F1
between the SSOT and live AWS state.

Generic — customer-agnostic, profile-agnostic, filter-agnostic.  The single
public function ``reconcile()`` accepts an SSOT path, an AWS profile, and a
filter regex, returning a 12-key scorecard dict.

The CodePipeline ListWebhooks supplement is reused from
``runbooks.inventory.collectors.resource_explorer._supplement_codepipeline_webhooks``
to close the known Resource Explorer 2 indexing gap for webhook resources.

Default ``expected_recall=0.995`` is appropriate for compliance-grade inventory
reconciliation (APRA CPS 234, SOC2 CC6.1, NIST CSF ID.AM-1).  Lower for
exploratory queries.

Example::

    from runbooks.inventory.reconciliation import reconcile

    scorecard = reconcile(
        ssot_path="cmdb-export.xlsx",
        aws_profile="my-profile",
        filter_regex="prod-app",
        region="ap-southeast-2",
    )
    print(scorecard["recall"], scorecard["verdict"])
"""

from __future__ import annotations

import csv
import json
import os
import re
from datetime import datetime, UTC
from pathlib import Path
from typing import Any

import boto3
import botocore.config
import openpyxl

# ---------------------------------------------------------------------------
# Retry configuration — reused by all boto3 clients in this module
# ---------------------------------------------------------------------------

_RETRY_CONFIG = botocore.config.Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def reconcile(
    ssot_path: str,
    aws_profile: str,
    filter_regex: str,
    region: str | None = None,
    expected_recall: float = 0.995,
    ssot_format: str = "auto",
    tag_filter_values: list[str] | None = None,
    expected_account: str | None = None,
    output_dir: str | Path | None = None,
) -> dict:
    """Reconcile an SSOT against live AWS inventory.

    Collects AWS resources matching ``filter_regex`` via the Resource Groups
    Tagging API (two passes: tag-filter pass A + ARN-regex pass B) and
    optionally via CodePipeline ListWebhooks.  Parses the SSOT file and
    computes Jaccard-family metrics between the two sets.

    Args:
        ssot_path:         Path to the SSOT file (xlsx, csv, or json).
        aws_profile:       AWS profile name.  Falls back to ``$AWS_PROFILE``
                           when an empty string is passed.
        filter_regex:      Regular expression applied to ARNs in Pass B and
                           to SSOT identifiers.  Also controls whether the
                           CodePipeline webhook supplement fires (activated
                           when the pattern contains ``codepipeline``).
        region:            AWS region.  Falls back to ``$AWS_REGION`` then
                           ``$AWS_DEFAULT_REGION`` when ``None`` is passed.
        expected_recall:   Recall threshold for the PASS/FAIL gate.
                           Default 0.995 (99.5%) for compliance-grade use.
        ssot_format:       One of ``"auto"`` (detect by extension),
                           ``"xlsx"``, ``"csv"``, or ``"json"``.
        tag_filter_values: Optional list of tag values for Pass A
                           ``application-name`` tag filter.  When ``None``,
                           Pass A is skipped and only Pass B (ARN regex) runs.
        expected_account:  Optional account ID to validate against; triggers
                           a warning when resources from other accounts appear.
        output_dir:        Optional directory to write the scorecard JSON.
                           When ``None``, no file is written.

    Returns:
        dict with 12 keys:
            ``ssot_count``         — number of ARNs in the SSOT
            ``aws_count``          — number of ARNs collected from AWS
            ``union_count``        — |ssot ∪ aws|
            ``precision``          — tp / (tp + fp)
            ``recall``             — tp / (tp + fn)
            ``f1``                 — harmonic mean of precision and recall
            ``jaccard``            — tp / (tp + fp + fn)
            ``verdict``            — ``"PASS"`` or ``"FAIL"`` vs expected_recall
            ``missing_from_aws``   — sorted list of SSOT ARNs absent from AWS
            ``extra_in_aws``       — sorted list of AWS ARNs absent from SSOT
            ``per_type_breakdown`` — dict of service::type → {truth, aws} counts
            ``evidence_path``      — path to written JSON or ``None``

    Raises:
        FileNotFoundError: When ``ssot_path`` does not exist.
        ValueError:        When ``ssot_format`` is unsupported (e.g. ``.tsv``).
        re.error:          When ``filter_regex`` is not a valid regex.
        RuntimeError:      When the AWS client cannot be created or RGTA fails.
    """
    resolved_region: str = region or os.environ.get("AWS_REGION", "") or os.environ.get("AWS_DEFAULT_REGION", "")
    if not resolved_region:
        raise ValueError("region must be provided or $AWS_REGION / $AWS_DEFAULT_REGION env var set.")

    # Validate regex eagerly — raises re.error for callers before any I/O
    compiled_filter = re.compile(filter_regex, re.IGNORECASE)

    ssot: set[str] = _parse_ssot(ssot_path, ssot_format, compiled_filter)
    aws: set[str] = _collect_aws_inventory(
        aws_profile,
        resolved_region,
        compiled_filter,
        tag_filter_values=tag_filter_values,
        expected_account=expected_account,
    )

    scorecard: dict = _score_jaccard(ssot, aws)
    scorecard["verdict"] = _pdca_gate(scorecard, expected_recall)
    scorecard["ssot_count"] = len(ssot)
    scorecard["aws_count"] = len(aws)
    scorecard["union_count"] = len(ssot | aws)
    scorecard["per_type_breakdown"] = _per_type_breakdown(ssot, aws)

    evidence_path: str | None = None
    if output_dir is not None:
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        out_file = out_dir / f"reconciliation-scorecard-{ts}.json"
        out_file.write_text(json.dumps(scorecard, indent=2, default=str))
        evidence_path = str(out_file)

    scorecard["evidence_path"] = evidence_path
    return scorecard


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _parse_ssot(path: str, ssot_format: str, pattern: re.Pattern) -> set[str]:
    """Parse SSOT file and return a set of normalised ARNs matching ``pattern``.

    Auto-detects format from file extension when ``ssot_format="auto"``.
    Raises:
        FileNotFoundError: Path does not exist.
        ValueError:        Unsupported extension when format is ``"auto"``.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"SSOT file not found: {path}")

    fmt = ssot_format
    if fmt == "auto":
        ext = p.suffix.lower()
        if ext == ".xlsx":
            fmt = "xlsx"
        elif ext == ".csv":
            fmt = "csv"
        elif ext == ".json":
            fmt = "json"
        else:
            raise ValueError(f"Unsupported SSOT format: {ext!r}. Use --ssot-format {{{{xlsx|csv|json}}}} to override.")

    arns: set[str] = set()

    if fmt == "xlsx":
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows_iter = ws.iter_rows(values_only=True)
            raw_headers = next(rows_iter, None)
            if raw_headers is None:
                continue
            headers = [str(h).strip() if h is not None else "" for h in raw_headers]
            # Find columns that might contain ARNs or identifiers
            arn_cols = [i for i, h in enumerate(headers) if h.upper() in ("ARN", "IDENTIFIER")]
            name_cols = [i for i, h in enumerate(headers) if "NAME" in h.upper()]
            search_cols = arn_cols or name_cols or list(range(min(5, len(headers))))
            for row in rows_iter:
                if all(v is None for v in row):
                    continue
                for col_idx in search_cols:
                    if col_idx >= len(row):
                        continue
                    val = row[col_idx]
                    if val is None:
                        continue
                    s = str(val).strip()
                    if s and pattern.search(s):
                        arns.add(_normalise_arn(s))
                        break
        wb.close()

    elif fmt == "csv":
        with open(path, newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                for val in row.values():
                    if val and pattern.search(val):
                        arns.add(_normalise_arn(val.strip()))
                        break

    elif fmt == "json":
        data = json.loads(p.read_text(encoding="utf-8"))
        # Support list-of-strings, list-of-dicts with "arn"/"identifier" key,
        # or dict with "resources" / "arns" list
        items: list[Any] = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            items = data.get("resources") or data.get("arns") or data.get("arns_via_re") or []
        for item in items:
            if isinstance(item, str):
                candidate = item
            elif isinstance(item, dict):
                candidate = item.get("arn") or item.get("identifier") or ""
            else:
                continue
            candidate = candidate.strip()
            if candidate and pattern.search(candidate):
                arns.add(_normalise_arn(candidate))

    return arns


def _collect_aws_inventory(
    profile: str,
    region: str,
    pattern: re.Pattern,
    tag_filter_values: list[str] | None = None,
    expected_account: str | None = None,
) -> set[str]:
    """Collect AWS resource ARNs via RGTA (two passes) + optional webhook supplement.

    Pass A (tag filter) runs only when ``tag_filter_values`` is provided.
    Pass B (ARN regex) always runs.
    CodePipeline webhook supplement runs when pattern matches ``codepipeline``.

    Returns:
        set of normalised ARNs matching ``pattern``.
    Raises:
        RuntimeError: When AWS client creation fails.
    """
    resolved_profile = profile or os.environ.get("AWS_PROFILE", "")

    try:
        if resolved_profile:
            session = boto3.Session(profile_name=resolved_profile, region_name=region)
        else:
            session = boto3.Session(region_name=region)
        client = session.client("resourcegroupstaggingapi", config=_RETRY_CONFIG)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to create RGTA client (profile={resolved_profile!r}, region={region!r}): {exc}"
        ) from exc

    results: dict[str, dict] = {}

    # Pass A — tag filter (optional)
    if tag_filter_values:
        paginator = client.get_paginator("get_resources")
        pages = paginator.paginate(
            TagFilters=[{"Key": "application-name", "Values": tag_filter_values}],
            ResourcesPerPage=100,
        )
        for page in pages:
            for resource in page.get("ResourceTagMappingList", []):
                arn = resource["ResourceARN"]
                parsed = _parse_arn(arn)
                results[_normalise_arn(arn)] = {
                    "arn": arn,
                    "service": parsed["service"],
                    "region": parsed["region"] or region,
                    "account": parsed["account"],
                    "detected_via": "tag_filter",
                }

    # Pass B — full scan + ARN regex post-filter
    paginator = client.get_paginator("get_resources")
    pages = paginator.paginate(ResourcesPerPage=100)
    for page in pages:
        for resource in page.get("ResourceTagMappingList", []):
            arn = resource["ResourceARN"]
            if not pattern.search(arn):
                continue
            norm = _normalise_arn(arn)
            if norm not in results:
                parsed = _parse_arn(arn)
                results[norm] = {
                    "arn": arn,
                    "service": parsed["service"],
                    "region": parsed["region"] or region,
                    "account": parsed["account"],
                    "detected_via": "arn_regex",
                }
            else:
                results[norm]["detected_via"] = "both"

    # CodePipeline webhook supplement — RGTA does not index codepipeline:webhook
    if re.search(r"codepipeline", pattern.pattern, re.IGNORECASE):
        from runbooks.inventory.collectors.resource_explorer import (
            _supplement_codepipeline_webhooks,
        )

        try:
            webhooks = _supplement_codepipeline_webhooks(
                profile=resolved_profile,
                region=region,
                filter_predicate=lambda w: bool(pattern.search(w.get("arn", ""))),
            )
            for w in webhooks:
                norm = _normalise_arn(w["arn"])
                if norm not in results:
                    results[norm] = {
                        "arn": w["arn"],
                        "service": "codepipeline",
                        "region": region,
                        "account": w.get("account", ""),
                        "detected_via": "webhook_supplement",
                    }
        except Exception:
            # Supplement is best-effort; RGTA results are still valid without it
            pass

    # Optional account validation warning
    if expected_account:
        unexpected = {
            rec["account"] for rec in results.values() if rec["account"] and rec["account"] != expected_account
        }
        if unexpected:
            import warnings

            warnings.warn(
                f"Unexpected account IDs in AWS inventory: {unexpected}",
                stacklevel=3,
            )

    return set(results.keys())


def _score_jaccard(truth: set[str], candidate: set[str]) -> dict:
    """Compute precision, recall, F1, and Jaccard between two ARN sets.

    Returns:
        dict with keys: precision, recall, f1, jaccard,
                        missing_from_aws (fn_set sorted), extra_in_aws (fp_set sorted).
    """
    tp_set = truth & candidate
    fp_set = candidate - truth
    fn_set = truth - candidate

    tp = len(tp_set)
    fp = len(fp_set)
    fn = len(fn_set)

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
    jaccard = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else 0.0

    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "jaccard": round(jaccard, 4),
        "missing_from_aws": sorted(fn_set),
        "extra_in_aws": sorted(fp_set),
    }


def _pdca_gate(scorecard: dict, expected_recall: float) -> str:
    """Return ``"PASS"`` when recall meets threshold, else ``"FAIL"``."""
    return "PASS" if scorecard.get("recall", 0.0) >= expected_recall else "FAIL"


def _normalise_arn(arn: str) -> str:
    """Lowercase for case-insensitive ARN comparison; preserve version qualifiers."""
    return arn.strip().lower()


def _arn_type(arn: str) -> str:
    """Extract ``service::resource-type`` from an ARN for per-type breakdown."""
    parts = arn.lower().split(":")
    if len(parts) < 6:
        return "unknown"
    service = parts[2]
    resource_part = ":".join(parts[5:])
    resource_type = re.split(r"[/:]", resource_part)[0]
    return f"{service}::{resource_type}"


def _parse_arn(arn: str) -> dict[str, str]:
    """Parse an ARN into component fields."""
    parts = arn.split(":", 5)
    if len(parts) < 6:
        return {"service": "unknown", "region": "unknown", "account": "unknown", "resource_name": arn}
    service = parts[2]
    region = parts[3]
    account = parts[4]
    resource_part = parts[5]
    if "/" in resource_part:
        resource_name = resource_part.rsplit("/", 1)[-1]
    elif ":" in resource_part:
        resource_name = resource_part.rsplit(":", 1)[-1]
    else:
        resource_name = resource_part
    return {"service": service, "region": region, "account": account, "resource_name": resource_name}


def _per_type_breakdown(truth: set[str], aws: set[str]) -> dict:
    """Return per-service::resource-type count dict with truth and aws tallies."""
    types: dict[str, dict] = {}
    for arn in truth:
        t = _arn_type(arn)
        types.setdefault(t, {"truth": 0, "aws": 0})
        types[t]["truth"] += 1
    for arn in aws:
        t = _arn_type(arn)
        types.setdefault(t, {"truth": 0, "aws": 0})
        types[t]["aws"] += 1
    return dict(sorted(types.items()))
