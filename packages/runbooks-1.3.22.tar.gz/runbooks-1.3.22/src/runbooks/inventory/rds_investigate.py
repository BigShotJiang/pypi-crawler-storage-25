#!/usr/bin/env python3
"""
RDS Instance Investigation Orchestrator - 6-Phase Comprehensive Analysis

Chains 6 investigation phases into a single command for deep-dive RDS analysis:

Phase 1 (Discovery):   rds:DescribeDBInstances -- engine, class, storage, Multi-AZ
Phase 2 (Metadata):    Parameter/option groups, maintenance window, backup retention
Phase 3 (Security):    Snapshot exposure, SecurityHub findings, encryption/SSL
Phase 4 (Network):     VPC SGs, subnet group, public accessibility
Phase 5 (Compliance):  Auto-upgrade, deletion protection, Performance Insights, PITR
Phase 6 (Summary):     Risk score + executive Rich panel

Design: Composition over inheritance. Each phase is self-contained with graceful
        degradation -- a phase failure does not abort subsequent phases.

READONLY: rds:DescribeDB*, rds:ListTagsForResource, securityhub:GetFindings,
          ec2:DescribeSecurityGroups -- no mutations.

Usage:
    runbooks inventory rds-investigate --db-instance-id mydb --profile ops
    runbooks inventory rds-investigate --db-instance-id mydb --profile ops --output json
"""

import json
from datetime import datetime, UTC
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    print_error,
    print_info,
)

_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})

_RISK_HIGH = 60
_RISK_CRITICAL = 80


def _get_rds_client(profile: Optional[str], region: str):
    """Create RDS client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("rds", config=_RETRY_CONFIG)


def _get_ec2_client(profile: Optional[str], region: str):
    """Create EC2 client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("ec2", config=_RETRY_CONFIG)


def _get_sh_client(profile: Optional[str], region: str):
    """Create SecurityHub client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("securityhub", config=_RETRY_CONFIG)


def _age_days(dt_val) -> Optional[int]:
    """Return days since a datetime, or None."""
    if dt_val is None:
        return None
    now = datetime.now(UTC)
    if hasattr(dt_val, "tzinfo") and dt_val.tzinfo is None:
        dt_val = dt_val.replace(tzinfo=UTC)
    return (now - dt_val).days


# ─── Phase 1: Discovery ───────────────────────────────────────────────────────


def phase1_discovery(rds_client, db_instance_id: str) -> dict[str, Any]:
    """
    Fetch core RDS instance metadata via DescribeDBInstances.

    The raw boto3 DBInstance dict is stored under the ``_raw_db`` key so that
    subsequent phases (2, 4, 5) can reuse it without re-calling the API (ISS-010).

    Returns dict with engine, class, storage, Multi-AZ, VPC, status.
    """
    try:
        response = rds_client.describe_db_instances(DBInstanceIdentifier=db_instance_id)
        instances = response.get("DBInstances", [])
        if not instances:
            return {"error": f"DB instance {db_instance_id} not found"}

        db = instances[0]
        create_time = db.get("InstanceCreateTime")
        age = _age_days(create_time)

        return {
            # Carry the raw boto3 dict so downstream phases avoid redundant API calls.
            "_raw_db": db,
            "db_instance_id": db.get("DBInstanceIdentifier", db_instance_id),
            "db_instance_arn": db.get("DBInstanceArn", "N/A"),
            "status": db.get("DBInstanceStatus", "N/A"),
            "engine": db.get("Engine", "N/A"),
            "engine_version": db.get("EngineVersion", "N/A"),
            "db_instance_class": db.get("DBInstanceClass", "N/A"),
            "allocated_storage_gb": db.get("AllocatedStorage", 0),
            "storage_type": db.get("StorageType", "N/A"),
            "iops": db.get("Iops"),
            "multi_az": db.get("MultiAZ", False),
            "publicly_accessible": db.get("PubliclyAccessible", False),
            "vpc_id": db.get("DBSubnetGroup", {}).get("VpcId", "N/A"),
            "subnet_group": db.get("DBSubnetGroup", {}).get("DBSubnetGroupName", "N/A"),
            "availability_zone": db.get("AvailabilityZone", "N/A"),
            "secondary_az": db.get("SecondaryAvailabilityZone"),
            "storage_encrypted": db.get("StorageEncrypted", False),
            "kms_key_id": db.get("KmsKeyId"),
            "create_time": str(create_time) if create_time else "N/A",
            "age_days": age,
            "endpoint": db.get("Endpoint", {}).get("Address", "N/A"),
            "port": db.get("Endpoint", {}).get("Port"),
            "ca_certificate": db.get("CACertificateIdentifier", "N/A"),
            "db_name": db.get("DBName", "N/A"),
            "master_username": db.get("MasterUsername", "N/A"),
            "error": None,
        }
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("DBInstanceNotFound",):
            return {"error": f"DB instance {db_instance_id} not found"}
        return {"error": f"RDS API error ({error_code}): {e}"}


# ─── Phase 2: Metadata ────────────────────────────────────────────────────────


def phase2_metadata(db: dict[str, Any]) -> dict[str, Any]:
    """
    Extract RDS metadata from the raw DBInstance dict fetched in phase 1.

    Accepts the pre-fetched boto3 DBInstance dict (ISS-010: no redundant API call).

    Returns dict with maintenance window, backup retention, parameter groups.
    """
    param_groups = [
        {"name": pg["DBParameterGroupName"], "status": pg["ParameterApplyStatus"]}
        for pg in db.get("DBParameterGroups", [])
    ]
    option_groups = [
        {"name": og["OptionGroupName"], "status": og["Status"]} for og in db.get("OptionGroupMemberships", [])
    ]

    return {
        "maintenance_window": db.get("PreferredMaintenanceWindow", "N/A"),
        "backup_window": db.get("PreferredBackupWindow", "N/A"),
        "backup_retention_days": db.get("BackupRetentionPeriod", 0),
        "auto_minor_version_upgrade": db.get("AutoMinorVersionUpgrade", False),
        "deletion_protection": db.get("DeletionProtection", False),
        "performance_insights_enabled": db.get("PerformanceInsightsEnabled", False),
        "monitoring_interval": db.get("MonitoringInterval", 0),
        "enhanced_monitoring_arn": db.get("EnhancedMonitoringResourceArn"),
        "param_groups": param_groups,
        "option_groups": option_groups,
        "db_cluster_id": db.get("DBClusterIdentifier"),
        "read_replica_source": db.get("ReadReplicaSourceDBInstanceIdentifier"),
        "read_replicas": db.get("ReadReplicaDBInstanceIdentifiers", []),
        "license_model": db.get("LicenseModel", "N/A"),
        "error": None,
    }


# ─── Phase 3: Security ────────────────────────────────────────────────────────


def phase3_security(
    rds_client,
    sh_client,
    db_instance_id: str,
    db_arn: str,
    region: str,
) -> dict[str, Any]:
    """
    Assess RDS security: public snapshots, SecurityHub findings, SSL, encryption.

    Returns dict with findings, public_snapshot_count, ssl_enforced flag.
    """
    result: dict[str, Any] = {
        "securityhub_findings": [],
        "severity_counts": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
        "public_snapshot_count": 0,
        "ssl_enforced": None,
        "error": None,
    }

    # Check for public snapshots
    try:
        paginator = rds_client.get_paginator("describe_db_snapshots")
        for page in paginator.paginate(
            DBInstanceIdentifier=db_instance_id,
            SnapshotType="public",
            PaginationConfig={"MaxItems": 50, "PageSize": 50},
        ):
            result["public_snapshot_count"] += len(page.get("DBSnapshots", []))
    except ClientError as e:
        result["snapshot_error"] = f"Snapshot check failed: {e.response['Error']['Code']}"

    # SecurityHub findings for RDS ARN
    try:
        paginator = sh_client.get_paginator("get_findings")
        for page in paginator.paginate(
            Filters={
                "ResourceId": [{"Value": db_arn, "Comparison": "EQUALS"}],
                "RecordState": [{"Value": "ACTIVE", "Comparison": "EQUALS"}],
            },
            PaginationConfig={"MaxItems": 200, "PageSize": 100},
        ):
            for f in page.get("Findings", []):
                sev_label = f.get("Severity", {}).get("Label", "UNKNOWN").upper()
                title = f.get("Title", "N/A")[:80]
                result["securityhub_findings"].append({"title": title, "severity": sev_label})
                if sev_label in result["severity_counts"]:
                    result["severity_counts"][sev_label] += 1
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code not in ("AccessDeniedException", "InvalidAccessException"):
            result["sh_error"] = f"SecurityHub query failed: {error_code}"
        else:
            result["sh_error"] = "SecurityHub not enabled or access denied"

    return result


# ─── Phase 4: Network ─────────────────────────────────────────────────────────


def phase4_network(
    ec2_client,
    db: dict[str, Any],
) -> dict[str, Any]:
    """
    Assess RDS network configuration: SG rules, subnet group, public access.

    Accepts the pre-fetched boto3 DBInstance dict (ISS-010: no redundant API call).

    Returns dict with security_group_ids, subnet_ids, publicly_accessible.
    """
    sg_ids = [sg["VpcSecurityGroupId"] for sg in db.get("VpcSecurityGroups", [])]
    subnet_ids = [s["SubnetIdentifier"] for s in db.get("DBSubnetGroup", {}).get("Subnets", [])]

    # Check SG rules for wide-open ingress
    open_sg_warnings: list[str] = []
    try:
        if sg_ids:
            sg_response = ec2_client.describe_security_groups(GroupIds=sg_ids)
            for sg in sg_response.get("SecurityGroups", []):
                for rule in sg.get("IpPermissions", []):
                    for ip_range in rule.get("IpRanges", []):
                        if ip_range.get("CidrIp") == "0.0.0.0/0":
                            open_sg_warnings.append(
                                f"SG {sg['GroupId']} allows 0.0.0.0/0 on port {rule.get('FromPort', 'all')}"
                            )
    except ClientError:
        pass

    return {
        "security_group_ids": sg_ids,
        "subnet_ids": subnet_ids,
        "subnet_group_name": db.get("DBSubnetGroup", {}).get("DBSubnetGroupName", "N/A"),
        "publicly_accessible": db.get("PubliclyAccessible", False),
        "open_sg_warnings": open_sg_warnings,
        "error": None,
    }


# ─── Phase 5: Compliance ──────────────────────────────────────────────────────


def phase5_compliance(db: dict[str, Any]) -> dict[str, Any]:
    """
    Assess RDS compliance posture: upgrade policy, deletion protection, PITR.

    Accepts the pre-fetched boto3 DBInstance dict (ISS-010: no redundant API call).

    Returns dict with compliance flags and their boolean values.
    """
    backup_retention = db.get("BackupRetentionPeriod", 0)

    return {
        "auto_minor_version_upgrade": db.get("AutoMinorVersionUpgrade", False),
        "deletion_protection": db.get("DeletionProtection", False),
        "performance_insights_enabled": db.get("PerformanceInsightsEnabled", False),
        "backup_retention_days": backup_retention,
        "pitr_enabled": backup_retention > 0,
        "storage_encrypted": db.get("StorageEncrypted", False),
        "iam_database_authentication": db.get("IAMDatabaseAuthenticationEnabled", False),
        "copy_tags_to_snapshot": db.get("CopyTagsToSnapshot", False),
        "monitoring_interval_sec": db.get("MonitoringInterval", 0),
        "enhanced_monitoring": db.get("MonitoringInterval", 0) > 0,
        "error": None,
    }


# ─── Phase 6: Risk Scoring ────────────────────────────────────────────────────


def phase6_summary(
    db_instance_id: str,
    p1: dict[str, Any],
    p2: dict[str, Any],
    p3: dict[str, Any],
    p4: dict[str, Any],
    p5: dict[str, Any],
) -> dict[str, Any]:
    """
    Aggregate phase results into risk score and executive recommendations.

    Risk scoring (100-point scale):
    - Publicly accessible:      25 pts (CRITICAL if True)
    - Public snapshots:         15 pts per snapshot (max 30)
    - SecurityHub CRITICAL:     20 pts each (max 40)
    - SecurityHub HIGH:         10 pts each (max 20)
    - Storage not encrypted:    15 pts
    - No deletion protection:   10 pts
    - No PITR:                  10 pts
    - No auto minor upgrade:    5 pts
    - Not Multi-AZ:             5 pts
    """
    risk_score = 0
    recommendations: list[dict[str, str]] = []

    # Publicly accessible
    if p1.get("publicly_accessible") or p4.get("publicly_accessible"):
        risk_score += 25
        recommendations.append(
            {
                "priority": "P0",
                "action": "Disable PubliclyAccessible -- RDS instance is exposed to the internet",
            }
        )

    # Public snapshots
    public_snaps = p3.get("public_snapshot_count", 0)
    if public_snaps > 0:
        snap_score = min(public_snaps * 15, 30)
        risk_score += snap_score
        recommendations.append(
            {
                "priority": "P0",
                "action": f"Remove {public_snaps} public snapshot(s) -- data exposure risk",
            }
        )

    # SecurityHub findings
    sev = p3.get("severity_counts", {})
    critical_sh = sev.get("CRITICAL", 0)
    high_sh = sev.get("HIGH", 0)
    sh_score = min(critical_sh * 20 + high_sh * 10, 40)
    risk_score += sh_score
    if critical_sh > 0:
        recommendations.append(
            {
                "priority": "P0",
                "action": f"Remediate {critical_sh} CRITICAL SecurityHub finding(s)",
            }
        )
    if high_sh > 0:
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Address {high_sh} HIGH SecurityHub finding(s)",
            }
        )

    # Storage encryption
    if not p1.get("storage_encrypted") and not p5.get("storage_encrypted"):
        risk_score += 15
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable storage encryption (requires snapshot restore)",
            }
        )

    # Deletion protection
    if not p2.get("deletion_protection") and not p5.get("deletion_protection"):
        risk_score += 10
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable deletion protection to prevent accidental removal",
            }
        )

    # PITR
    if not p5.get("pitr_enabled"):
        risk_score += 10
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable automated backups (BackupRetentionPeriod > 0) for PITR",
            }
        )

    # Auto minor version upgrade
    if not p2.get("auto_minor_version_upgrade") and not p5.get("auto_minor_version_upgrade"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Enable AutoMinorVersionUpgrade for security patches",
            }
        )

    # Multi-AZ
    if not p1.get("multi_az"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Consider Multi-AZ deployment for production databases",
            }
        )

    # Open SG warnings
    for warning in p4.get("open_sg_warnings", []):
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Restrict SG: {warning}",
            }
        )

    risk_score = min(risk_score, 100)

    if risk_score >= _RISK_CRITICAL:
        risk_level, risk_color = "CRITICAL", "red bold"
    elif risk_score >= _RISK_HIGH:
        risk_level, risk_color = "HIGH", "red"
    elif risk_score >= 30:
        risk_level, risk_color = "MEDIUM", "yellow"
    else:
        risk_level, risk_color = "LOW", "green"

    return {
        "db_instance_id": db_instance_id,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "recommendations": recommendations,
        "severity_counts": sev,
        "public_snapshot_count": public_snaps,
    }


# ─── Rendering ────────────────────────────────────────────────────────────────


def _phase_status(phase_data: dict[str, Any]) -> str:
    """Return coloured status indicator for a phase result."""
    if phase_data.get("error"):
        return "[yellow]SKIP[/yellow]"
    return "[green]OK[/green]"


def render_investigation(
    db_instance_id: str,
    phases: dict[str, dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    """Render RDS investigation results as a Rich panel."""
    p1 = phases["discovery"]
    p2 = phases["metadata"]
    p3 = phases["security"]
    p4 = phases["network"]
    p5 = phases["compliance"]

    risk_color = summary.get("risk_color", "white")
    risk_level = summary.get("risk_level", "UNKNOWN")
    risk_score = summary.get("risk_score", 0)

    lines: list[str] = []

    if not p1.get("error"):
        age_str = f"{p1.get('age_days', '?')} days" if p1.get("age_days") is not None else "N/A"
        public_str = "[red]YES[/red]" if p1.get("publicly_accessible") else "[green]No[/green]"
        enc_str = "[green]Yes[/green]" if p1.get("storage_encrypted") else "[red]No[/red]"
        lines.append(
            f"  Phase 1: Discovery   {_phase_status(p1)}  "
            f"({p1.get('engine', 'N/A')} {p1.get('engine_version', '')}, "
            f"{p1.get('db_instance_class', 'N/A')}, "
            f"age: {age_str})"
        )
        lines.append(f"           Multi-AZ: {p1.get('multi_az', False)}  Encrypted: {enc_str}  Public: {public_str}")
    else:
        lines.append(f"  Phase 1: Discovery   [yellow]SKIP[/yellow]  {p1['error']}")

    if not p2.get("error"):
        lines.append(
            f"  Phase 2: Metadata    {_phase_status(p2)}  "
            f"(backup: {p2.get('backup_retention_days', 0)}d, "
            f"deletion protection: {p2.get('deletion_protection', False)})"
        )
    else:
        lines.append(f"  Phase 2: Metadata    [yellow]SKIP[/yellow]  {p2.get('error', 'No data')}")

    sev = summary.get("severity_counts", {})
    snap_count = summary.get("public_snapshot_count", 0)
    lines.append(
        f"  Phase 3: Security    {_phase_status(p3)}  "
        f"([red]{sev.get('CRITICAL', 0)} CRITICAL[/red], "
        f"[red]{sev.get('HIGH', 0)} HIGH[/red], "
        f"public snapshots: {snap_count})"
    )

    if not p4.get("error"):
        sg_count = len(p4.get("security_group_ids", []))
        open_warns = len(p4.get("open_sg_warnings", []))
        warn_str = f"[red]{open_warns} open SG warning(s)[/red]" if open_warns else "[green]SGs OK[/green]"
        lines.append(f"  Phase 4: Network     {_phase_status(p4)}  ({sg_count} SGs, {warn_str})")
    else:
        lines.append(f"  Phase 4: Network     [yellow]SKIP[/yellow]  {p4.get('error', 'No data')}")

    if not p5.get("error"):
        pitr_str = "[green]Yes[/green]" if p5.get("pitr_enabled") else "[red]No[/red]"
        lines.append(
            f"  Phase 5: Compliance  {_phase_status(p5)}  "
            f"(PITR: {pitr_str}, "
            f"auto-upgrade: {p5.get('auto_minor_version_upgrade', False)}, "
            f"PI: {p5.get('performance_insights_enabled', False)})"
        )
    else:
        lines.append(f"  Phase 5: Compliance  [yellow]SKIP[/yellow]  {p5.get('error', 'No data')}")

    lines.append(
        f"\n  Phase 6: Summary     [green]OK[/green]  "
        f"Risk Score: [{risk_color}]{risk_score}/100 ({risk_level})[/{risk_color}]"
    )

    recs = summary.get("recommendations", [])
    if recs:
        lines.append("\n  [bold]Recommendations:[/bold]")
        for i, rec in enumerate(recs, 1):
            priority = rec["priority"]
            p_color = {"P0": "red bold", "P1": "red", "P2": "yellow", "P3": "cyan"}.get(priority, "white")
            lines.append(f"  {i}. [[{p_color}]{priority}[/{p_color}]] {rec['action']}")

    console.print(
        create_panel(
            "\n".join(lines),
            title=f"RDS Instance Investigation: {db_instance_id}",
            border_style=risk_color.split()[0],
        )
    )


# ─── Top-level runner ─────────────────────────────────────────────────────────


def run_rds_investigate(
    db_instance_id: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Run a 6-phase RDS instance investigation and render results.

    Args:
        db_instance_id: RDS DB instance identifier
        profile: AWS profile name (None uses default/env)
        region: AWS region (default: ap-southeast-2)
        output_format: "table" or "json"

    Returns:
        Structured dict with all phase results and risk summary

    Raises:
        SystemExit on unrecoverable initial errors
    """
    print_info(f"Starting RDS investigation for {db_instance_id} in {region}...")

    try:
        rds_client = _get_rds_client(profile, region)
        ec2_client = _get_ec2_client(profile, region)
        sh_client = _get_sh_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create AWS clients: {e}")
        raise SystemExit(1)

    phases: dict[str, dict[str, Any]] = {}

    console.print("[dim]Phase 1/6: Discovery...[/dim]")
    phases["discovery"] = phase1_discovery(rds_client, db_instance_id)
    if phases["discovery"].get("error") and "not found" in str(phases["discovery"]["error"]).lower():
        print_error(f"DB instance {db_instance_id} not found. Aborting investigation.")
        raise SystemExit(1)

    db_arn = phases["discovery"].get("db_instance_arn", "N/A")
    # Raw boto3 DBInstance dict -- reused by phases 2, 4, 5 to avoid redundant API calls.
    raw_db: dict[str, Any] = phases["discovery"].get("_raw_db", {})

    console.print("[dim]Phase 2/6: Metadata...[/dim]")
    phases["metadata"] = phase2_metadata(raw_db)

    console.print("[dim]Phase 3/6: Security...[/dim]")
    phases["security"] = phase3_security(rds_client, sh_client, db_instance_id, db_arn, region)

    console.print("[dim]Phase 4/6: Network...[/dim]")
    phases["network"] = phase4_network(ec2_client, raw_db)

    console.print("[dim]Phase 5/6: Compliance...[/dim]")
    phases["compliance"] = phase5_compliance(raw_db)

    console.print("[dim]Phase 6/6: Risk scoring...[/dim]")
    summary = phase6_summary(
        db_instance_id,
        phases["discovery"],
        phases["metadata"],
        phases["security"],
        phases["network"],
        phases["compliance"],
    )

    result: dict[str, Any] = {
        "db_instance_id": db_instance_id,
        "region": region,
        "phases": phases,
        "summary": summary,
        "timestamp": datetime.now(UTC).isoformat(),
    }

    if output_format == "json":
        console.print_json(json.dumps(result, default=str, indent=2))
        return result

    render_investigation(db_instance_id, phases, summary)
    return result
