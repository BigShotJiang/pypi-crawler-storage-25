"""
AWS Resource Groups discovery wrapper.

Wraps resource-groups.list_groups + resource-groups.list_group_resources.

Resource Groups is region-scoped (not org-scoped) — caller MUST pass region.
Empty Groups list is a legitimate result (region may have no groups).
Pagination: NextToken on both list_groups and list_group_resources.

READONLY only — no create/delete/update operations.
"""

from __future__ import annotations

import logging

import botocore.config
import boto3

logger = logging.getLogger(__name__)

_RETRY_CONFIG = botocore.config.Config(retries={"max_attempts": 3, "mode": "adaptive"})


def list_resource_groups_all(client: "boto3.client", region: str) -> list[dict]:
    """Return all resource groups in the given region via NextToken pagination.

    Args:
        client: A boto3 resource-groups client (must carry retry config).
        region: AWS region string — passed through for logging context only
                (the client is already region-bound on creation).

    Returns:
        List of Group dicts as returned by the AWS API.
        Empty list is valid — region may have no resource groups.
    """
    groups: list[dict] = []
    kwargs: dict = {}

    while True:
        response = client.list_groups(**kwargs)
        groups.extend(response.get("Groups", []))

        next_token = response.get("NextToken")
        if not next_token:
            break
        kwargs["NextToken"] = next_token

    logger.info("list_resource_groups_all: region=%s → %d groups", region, len(groups))
    return groups


def list_group_resources(client: "boto3.client", group_name: str, region: str) -> list[dict]:
    """Return all resources in the named resource group via NextToken pagination.

    Args:
        client: A boto3 resource-groups client (must carry retry config).
        group_name: Resource group name.
        region: AWS region string — for logging context.

    Returns:
        List of resource items as returned by the AWS API.
        Each item contains 'Identifier' (ResourceArn + ResourceType) and 'Status'.
    """
    resources: list[dict] = []
    kwargs: dict = {"Group": group_name}

    while True:
        response = client.list_group_resources(**kwargs)
        resources.extend(response.get("Resources", []))

        next_token = response.get("NextToken")
        if not next_token:
            break
        kwargs["NextToken"] = next_token

    logger.info("list_group_resources: group=%s region=%s → %d resources", group_name, region, len(resources))
    return resources


def build_resource_groups_session_client(session: boto3.Session, region: str) -> "boto3.client":
    """Create a resource-groups client with retry config from a session.

    Args:
        session: A boto3.Session (caller provides profile).
        region: AWS region for resource-groups (service is region-scoped).

    Returns:
        boto3 client for resource-groups with adaptive retry.
    """
    return session.client("resource-groups", region_name=region, config=_RETRY_CONFIG)
