#!/usr/bin/env python3
"""
S3 Bucket Investigation Orchestrator - 6-Phase Comprehensive Analysis

Chains 6 investigation phases into a single command for deep-dive S3 analysis:

Phase 1 (Discovery):   s3:GetBucketLocation, s3:GetBucketTagging
Phase 2 (Metadata):    Versioning, lifecycle rules, storage class distribution
Phase 3 (Security):    Public access block, bucket policy, ACL, SecurityHub findings
Phase 4 (Network):     Access logging, VPC endpoints, bucket policy IP restrictions
Phase 5 (Compliance):  Encryption, Object Lock, MFA Delete, access logging enabled
Phase 6 (Summary):     Risk score (PUBLIC=CRITICAL) + executive Rich panel

Design: Composition over inheritance. Each phase is self-contained with graceful
        degradation -- a phase failure does not abort subsequent phases.

READONLY: s3:GetBucket*, s3:GetPublicAccessBlock, securityhub:GetFindings -- no mutations.

Usage:
    runbooks inventory s3-investigate --bucket-name my-bucket --profile ops
    runbooks inventory s3-investigate --bucket-name my-bucket --profile ops --output json
"""

import json
from datetime import datetime, UTC
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    print_error,
    print_info,
)

_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})

_RISK_HIGH = 60
_RISK_CRITICAL = 80


def _get_s3_client(profile: Optional[str], region: str):
    """Create S3 client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("s3", config=_RETRY_CONFIG)


def _get_sh_client(profile: Optional[str], region: str):
    """Create SecurityHub client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("securityhub", config=_RETRY_CONFIG)


def _safe_s3_get(s3_client, method_name: str, **kwargs) -> Optional[dict[str, Any]]:
    """
    Call an s3_client method and return response, None on NoSuchBucketConfiguration.

    Returns None for expected "not configured" errors, raises others.
    """
    try:
        method = getattr(s3_client, method_name)
        return method(**kwargs)
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in (
            "NoSuchBucketPolicy",
            "NoSuchLifecycleConfiguration",
            "NoSuchBucketConfiguration",
            "ObjectLockConfigurationNotFoundError",
            "ServerSideEncryptionConfigurationNotFoundError",
            "NoSuchCORSConfiguration",
        ):
            return None
        raise


# ─── Phase 1: Discovery ───────────────────────────────────────────────────────


def phase1_discovery(s3_client, bucket_name: str, region: str) -> dict[str, Any]:
    """
    Fetch S3 bucket location, tags, and basic existence check.

    Returns dict with region, creation_date, tags.
    """
    try:
        loc_response = s3_client.get_bucket_location(Bucket=bucket_name)
        bucket_region = loc_response.get("LocationConstraint") or "us-east-1"

        tags: dict[str, str] = {}
        try:
            tag_response = s3_client.get_bucket_tagging(Bucket=bucket_name)
            tags = {t["Key"]: t["Value"] for t in tag_response.get("TagSet", [])}
        except ClientError as e:
            if e.response["Error"]["Code"] not in ("NoSuchTagSet",):
                raise

        return {
            "bucket_name": bucket_name,
            "region": bucket_region,
            "tags": tags,
            "environment": tags.get("Environment", tags.get("env", "unknown")),
            "error": None,
        }
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("NoSuchBucket",):
            return {"error": f"Bucket {bucket_name} does not exist"}
        return {"error": f"S3 API error ({error_code}): {e}"}


# ─── Phase 2: Metadata ────────────────────────────────────────────────────────


def phase2_metadata(s3_client, bucket_name: str) -> dict[str, Any]:
    """
    Fetch S3 bucket metadata: versioning, lifecycle rules, replication config.

    Returns dict with versioning_status, lifecycle_rules_count, replication.
    """
    result: dict[str, Any] = {
        "versioning_status": "Disabled",
        "mfa_delete": "Disabled",
        "lifecycle_rules_count": 0,
        "replication_enabled": False,
        "cors_enabled": False,
        "error": None,
    }

    try:
        # Versioning
        ver_response = s3_client.get_bucket_versioning(Bucket=bucket_name)
        result["versioning_status"] = ver_response.get("Status", "Disabled") or "Disabled"
        result["mfa_delete"] = ver_response.get("MFADelete", "Disabled") or "Disabled"

        # Lifecycle
        lc_response = _safe_s3_get(s3_client, "get_bucket_lifecycle_configuration", Bucket=bucket_name)
        if lc_response:
            result["lifecycle_rules_count"] = len(lc_response.get("Rules", []))

        # Replication
        rep_response = _safe_s3_get(s3_client, "get_bucket_replication", Bucket=bucket_name)
        result["replication_enabled"] = rep_response is not None

        # CORS
        cors_response = _safe_s3_get(s3_client, "get_bucket_cors", Bucket=bucket_name)
        result["cors_enabled"] = cors_response is not None

    except ClientError as e:
        result["error"] = f"Metadata fetch failed: {e.response['Error']['Code']}"

    return result


# ─── Phase 3: Security ────────────────────────────────────────────────────────


def phase3_security(
    s3_client,
    sh_client,
    bucket_name: str,
    bucket_arn: str,
) -> dict[str, Any]:
    """
    Assess S3 security: public access block, bucket ACL, policy, SecurityHub findings.

    Returns dict with public_access_block settings, is_public flag, findings.
    """
    result: dict[str, Any] = {
        "block_public_acls": False,
        "ignore_public_acls": False,
        "block_public_policy": False,
        "restrict_public_buckets": False,
        "is_public": False,
        "acl_grants": [],
        "has_bucket_policy": False,
        "securityhub_findings": [],
        "severity_counts": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
        "error": None,
    }

    # Public access block
    try:
        pab = s3_client.get_public_access_block(Bucket=bucket_name)
        config = pab.get("PublicAccessBlockConfiguration", {})
        result["block_public_acls"] = config.get("BlockPublicAcls", False)
        result["ignore_public_acls"] = config.get("IgnorePublicAcls", False)
        result["block_public_policy"] = config.get("BlockPublicPolicy", False)
        result["restrict_public_buckets"] = config.get("RestrictPublicBuckets", False)
        # Bucket is public if any block is False
        result["is_public"] = not all(
            [
                config.get("BlockPublicAcls", False),
                config.get("IgnorePublicAcls", False),
                config.get("BlockPublicPolicy", False),
                config.get("RestrictPublicBuckets", False),
            ]
        )
    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchPublicAccessBlockConfiguration":
            result["is_public"] = True  # No block = potentially public
        else:
            result["pab_error"] = f"Public access block check failed: {e.response['Error']['Code']}"

    # ACL
    try:
        acl_response = s3_client.get_bucket_acl(Bucket=bucket_name)
        grants = acl_response.get("Grants", [])
        for grant in grants:
            grantee = grant.get("Grantee", {})
            uri = grantee.get("URI", "")
            if "AllUsers" in uri or "AuthenticatedUsers" in uri:
                result["acl_grants"].append(
                    {
                        "permission": grant.get("Permission", "N/A"),
                        "grantee": uri,
                    }
                )
    except ClientError:
        pass

    # Bucket policy existence
    policy_response = _safe_s3_get(s3_client, "get_bucket_policy", Bucket=bucket_name)
    result["has_bucket_policy"] = policy_response is not None

    # SecurityHub findings
    try:
        paginator = sh_client.get_paginator("get_findings")
        for page in paginator.paginate(
            Filters={
                "ResourceId": [{"Value": bucket_arn, "Comparison": "EQUALS"}],
                "RecordState": [{"Value": "ACTIVE", "Comparison": "EQUALS"}],
            },
            PaginationConfig={"MaxItems": 200, "PageSize": 100},
        ):
            for f in page.get("Findings", []):
                sev_label = f.get("Severity", {}).get("Label", "UNKNOWN").upper()
                title = f.get("Title", "N/A")[:80]
                result["securityhub_findings"].append({"title": title, "severity": sev_label})
                if sev_label in result["severity_counts"]:
                    result["severity_counts"][sev_label] += 1
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code not in ("AccessDeniedException", "InvalidAccessException"):
            result["sh_error"] = f"SecurityHub query failed: {error_code}"

    return result


# ─── Phase 4: Network ─────────────────────────────────────────────────────────


def phase4_network(s3_client, bucket_name: str) -> dict[str, Any]:
    """
    Assess S3 access logging and bucket policy IP restrictions.

    Returns dict with logging_enabled, target_bucket, policy_has_ip_restriction.
    """
    result: dict[str, Any] = {
        "logging_enabled": False,
        "logging_target_bucket": None,
        "has_ip_restriction": False,
        "error": None,
    }

    try:
        log_response = s3_client.get_bucket_logging(Bucket=bucket_name)
        logging_config = log_response.get("LoggingEnabled", {})
        if logging_config:
            result["logging_enabled"] = True
            result["logging_target_bucket"] = logging_config.get("TargetBucket")
    except ClientError as e:
        result["error"] = f"Logging check failed: {e.response['Error']['Code']}"
        return result

    # Check if bucket policy includes IP-based restrictions
    try:
        policy_response = _safe_s3_get(s3_client, "get_bucket_policy", Bucket=bucket_name)
        if policy_response:
            policy_str = policy_response.get("Policy", "")
            result["has_ip_restriction"] = "aws:SourceIp" in policy_str or "NotIpAddress" in policy_str
    except ClientError:
        pass

    return result


# ─── Phase 5: Compliance ──────────────────────────────────────────────────────


def phase5_compliance(s3_client, bucket_name: str) -> dict[str, Any]:
    """
    Assess S3 compliance: encryption, Object Lock, MFA Delete, versioning.

    Returns dict with encryption_type, object_lock_enabled, mfa_delete.
    """
    result: dict[str, Any] = {
        "encryption_enabled": False,
        "encryption_algorithm": None,
        "kms_key_id": None,
        "object_lock_enabled": False,
        "object_lock_mode": None,
        "versioning_enabled": False,
        "mfa_delete": "Disabled",
        "error": None,
    }

    # Encryption
    enc_response = _safe_s3_get(s3_client, "get_bucket_encryption", Bucket=bucket_name)
    if enc_response:
        rules = enc_response.get("ServerSideEncryptionConfiguration", {}).get("Rules", [])
        if rules:
            sse = rules[0].get("ApplyServerSideEncryptionByDefault", {})
            result["encryption_enabled"] = True
            result["encryption_algorithm"] = sse.get("SSEAlgorithm", "N/A")
            result["kms_key_id"] = sse.get("KMSMasterKeyID")

    # Object Lock
    ol_response = _safe_s3_get(s3_client, "get_object_lock_configuration", Bucket=bucket_name)
    if ol_response:
        ol_config = ol_response.get("ObjectLockConfiguration", {})
        if ol_config.get("ObjectLockEnabled") == "Enabled":
            result["object_lock_enabled"] = True
            result["object_lock_mode"] = ol_config.get("Rule", {}).get("DefaultRetention", {}).get("Mode")

    # Versioning & MFA Delete
    try:
        ver_response = s3_client.get_bucket_versioning(Bucket=bucket_name)
        result["versioning_enabled"] = ver_response.get("Status") == "Enabled"
        result["mfa_delete"] = ver_response.get("MFADelete", "Disabled") or "Disabled"
    except ClientError:
        pass

    return result


# ─── Phase 6: Risk Scoring ────────────────────────────────────────────────────


def phase6_summary(
    bucket_name: str,
    p1: dict[str, Any],
    p2: dict[str, Any],
    p3: dict[str, Any],
    p4: dict[str, Any],
    p5: dict[str, Any],
) -> dict[str, Any]:
    """
    Aggregate phase results into risk score and executive recommendations.

    Risk scoring (100-point scale):
    - Publicly accessible (is_public=True): 35 pts (CRITICAL threshold alone)
    - Public ACL grants:                    10 pts each (max 20)
    - No encryption:                        20 pts
    - SecurityHub CRITICAL:                 20 pts each (max 40)
    - SecurityHub HIGH:                     10 pts each (max 20)
    - No access logging:                    5 pts
    - No versioning:                        5 pts
    - No lifecycle rules:                   5 pts
    """
    risk_score = 0
    recommendations: list[dict[str, str]] = []

    # Public access
    if p3.get("is_public"):
        risk_score += 35
        recommendations.append(
            {
                "priority": "P0",
                "action": "Enable S3 Block Public Access on all 4 settings -- bucket is PUBLICLY ACCESSIBLE",
            }
        )

    # Public ACL grants
    acl_grants = p3.get("acl_grants", [])
    if acl_grants:
        acl_score = min(len(acl_grants) * 10, 20)
        risk_score += acl_score
        for grant in acl_grants:
            recommendations.append(
                {
                    "priority": "P0",
                    "action": f"Remove ACL grant: {grant['permission']} to {grant['grantee']}",
                }
            )

    # Encryption
    if not p5.get("encryption_enabled"):
        risk_score += 20
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable server-side encryption (SSE-S3 or SSE-KMS)",
            }
        )

    # SecurityHub findings
    sev = p3.get("severity_counts", {})
    critical_sh = sev.get("CRITICAL", 0)
    high_sh = sev.get("HIGH", 0)
    sh_score = min(critical_sh * 20 + high_sh * 10, 40)
    risk_score += sh_score
    if critical_sh > 0:
        recommendations.append(
            {
                "priority": "P0",
                "action": f"Remediate {critical_sh} CRITICAL SecurityHub finding(s)",
            }
        )
    if high_sh > 0:
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Address {high_sh} HIGH SecurityHub finding(s)",
            }
        )

    # Access logging
    if not p4.get("logging_enabled"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Enable S3 server access logging for audit trail",
            }
        )

    # Versioning
    if not p5.get("versioning_enabled"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Enable S3 versioning to protect against accidental deletion",
            }
        )

    # Lifecycle rules
    if p2.get("lifecycle_rules_count", 0) == 0:
        risk_score += 5
        recommendations.append(
            {
                "priority": "P3",
                "action": "Add lifecycle rules for cost optimisation (transition to cheaper storage classes)",
            }
        )

    risk_score = min(risk_score, 100)

    if risk_score >= _RISK_CRITICAL:
        risk_level, risk_color = "CRITICAL", "red bold"
    elif risk_score >= _RISK_HIGH:
        risk_level, risk_color = "HIGH", "red"
    elif risk_score >= 30:
        risk_level, risk_color = "MEDIUM", "yellow"
    else:
        risk_level, risk_color = "LOW", "green"

    return {
        "bucket_name": bucket_name,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "recommendations": recommendations,
        "severity_counts": sev,
        "is_public": p3.get("is_public", False),
    }


# ─── Rendering ────────────────────────────────────────────────────────────────


def _phase_status(phase_data: dict[str, Any]) -> str:
    """Return coloured status indicator for a phase result."""
    if phase_data.get("error"):
        return "[yellow]SKIP[/yellow]"
    return "[green]OK[/green]"


def render_investigation(
    bucket_name: str,
    phases: dict[str, dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    """Render S3 investigation results as a Rich panel."""
    p1 = phases["discovery"]
    p2 = phases["metadata"]
    p3 = phases["security"]
    p4 = phases["network"]
    p5 = phases["compliance"]

    risk_color = summary.get("risk_color", "white")
    risk_level = summary.get("risk_level", "UNKNOWN")
    risk_score = summary.get("risk_score", 0)

    lines: list[str] = []

    if not p1.get("error"):
        lines.append(
            f"  Phase 1: Discovery   {_phase_status(p1)}  "
            f"(region: {p1.get('region', 'N/A')}, tags: {len(p1.get('tags', {}))})"
        )
    else:
        lines.append(f"  Phase 1: Discovery   [yellow]SKIP[/yellow]  {p1['error']}")

    if not p2.get("error"):
        lc_count = p2.get("lifecycle_rules_count", 0)
        ver_str = p2.get("versioning_status", "Disabled")
        lines.append(
            f"  Phase 2: Metadata    {_phase_status(p2)}  "
            f"(versioning: {ver_str}, lifecycle rules: {lc_count}, "
            f"replication: {p2.get('replication_enabled', False)})"
        )
    else:
        lines.append(f"  Phase 2: Metadata    [yellow]SKIP[/yellow]  {p2.get('error', 'No data')}")

    sev = summary.get("severity_counts", {})
    is_public = summary.get("is_public", False)
    public_str = "[red bold]YES (CRITICAL)[/red bold]" if is_public else "[green]No[/green]"
    lines.append(
        f"  Phase 3: Security    {_phase_status(p3)}  "
        f"(public: {public_str}, "
        f"[red]{sev.get('CRITICAL', 0)} CRITICAL[/red], "
        f"[red]{sev.get('HIGH', 0)} HIGH[/red])"
    )

    if not p4.get("error"):
        log_str = "[green]Yes[/green]" if p4.get("logging_enabled") else "[yellow]No[/yellow]"
        lines.append(
            f"  Phase 4: Network     {_phase_status(p4)}  "
            f"(access logging: {log_str}, "
            f"IP restriction: {p4.get('has_ip_restriction', False)})"
        )
    else:
        lines.append(f"  Phase 4: Network     [yellow]SKIP[/yellow]  {p4.get('error', 'No data')}")

    if not p5.get("error"):
        enc_str = "[green]Yes[/green]" if p5.get("encryption_enabled") else "[red]No[/red]"
        enc_algo = p5.get("encryption_algorithm", "None")
        lines.append(
            f"  Phase 5: Compliance  {_phase_status(p5)}  "
            f"(encryption: {enc_str} [{enc_algo}], "
            f"object lock: {p5.get('object_lock_enabled', False)}, "
            f"versioning: {p5.get('versioning_enabled', False)})"
        )
    else:
        lines.append(f"  Phase 5: Compliance  [yellow]SKIP[/yellow]  {p5.get('error', 'No data')}")

    lines.append(
        f"\n  Phase 6: Summary     [green]OK[/green]  "
        f"Risk Score: [{risk_color}]{risk_score}/100 ({risk_level})[/{risk_color}]"
    )

    recs = summary.get("recommendations", [])
    if recs:
        lines.append("\n  [bold]Recommendations:[/bold]")
        for i, rec in enumerate(recs, 1):
            priority = rec["priority"]
            p_color = {"P0": "red bold", "P1": "red", "P2": "yellow", "P3": "cyan"}.get(priority, "white")
            lines.append(f"  {i}. [[{p_color}]{priority}[/{p_color}]] {rec['action']}")

    console.print(
        create_panel(
            "\n".join(lines),
            title=f"S3 Bucket Investigation: {bucket_name}",
            border_style=risk_color.split()[0],
        )
    )


# ─── Top-level runner ─────────────────────────────────────────────────────────


def run_s3_investigate(
    bucket_name: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Run a 6-phase S3 bucket investigation and render results.

    Args:
        bucket_name: S3 bucket name
        profile: AWS profile name (None uses default/env)
        region: AWS region for client creation (default: ap-southeast-2)
        output_format: "table" or "json"

    Returns:
        Structured dict with all phase results and risk summary

    Raises:
        SystemExit on unrecoverable initial errors
    """
    print_info(f"Starting S3 investigation for s3://{bucket_name}...")

    try:
        s3_client = _get_s3_client(profile, region)
        sh_client = _get_sh_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create AWS clients: {e}")
        raise SystemExit(1)

    phases: dict[str, dict[str, Any]] = {}

    console.print("[dim]Phase 1/6: Discovery...[/dim]")
    phases["discovery"] = phase1_discovery(s3_client, bucket_name, region)
    if phases["discovery"].get("error") and "does not exist" in str(phases["discovery"]["error"]).lower():
        print_error(f"Bucket {bucket_name} does not exist. Aborting investigation.")
        raise SystemExit(1)

    bucket_region = phases["discovery"].get("region", region)
    bucket_arn = f"arn:aws:s3:::{bucket_name}"

    # Re-create S3 client in bucket's actual region for accurate API calls
    try:
        s3_client = _get_s3_client(profile, bucket_region)
    except Exception:
        pass  # Fall back to original client

    console.print("[dim]Phase 2/6: Metadata...[/dim]")
    phases["metadata"] = phase2_metadata(s3_client, bucket_name)

    console.print("[dim]Phase 3/6: Security...[/dim]")
    phases["security"] = phase3_security(s3_client, sh_client, bucket_name, bucket_arn)

    console.print("[dim]Phase 4/6: Network...[/dim]")
    phases["network"] = phase4_network(s3_client, bucket_name)

    console.print("[dim]Phase 5/6: Compliance...[/dim]")
    phases["compliance"] = phase5_compliance(s3_client, bucket_name)

    console.print("[dim]Phase 6/6: Risk scoring...[/dim]")
    summary = phase6_summary(
        bucket_name,
        phases["discovery"],
        phases["metadata"],
        phases["security"],
        phases["network"],
        phases["compliance"],
    )

    result: dict[str, Any] = {
        "bucket_name": bucket_name,
        "region": bucket_region,
        "phases": phases,
        "summary": summary,
        "timestamp": datetime.now(UTC).isoformat(),
    }

    if output_format == "json":
        console.print_json(json.dumps(result, default=str, indent=2))
        return result

    render_investigation(bucket_name, phases, summary)
    return result
