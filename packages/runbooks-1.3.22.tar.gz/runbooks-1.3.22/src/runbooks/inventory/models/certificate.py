"""Certificate inventory models for multi-cloud certificate discovery."""

from datetime import datetime, UTC
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field, computed_field


class CertificateStatus(str, Enum):
    """Certificate lifecycle status."""

    ISSUED = "ISSUED"
    PENDING_VALIDATION = "PENDING_VALIDATION"
    INACTIVE = "INACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"
    FAILED = "FAILED"
    VALIDATION_TIMED_OUT = "VALIDATION_TIMED_OUT"


class CertificateSource(str, Enum):
    """Where the certificate originates."""

    ACM = "ACM"
    IAM_SERVER_CERT = "IAM_SERVER_CERT"
    AZURE_KEY_VAULT = "AZURE_KEY_VAULT"
    THIRD_PARTY = "THIRD_PARTY"


class ExpiryBucket(str, Enum):
    """Risk-level classification based on days until expiry."""

    EXPIRED = "EXPIRED"
    CRITICAL_7D = "CRITICAL_7D"
    WARNING_30D = "WARNING_30D"
    ATTENTION_90D = "ATTENTION_90D"
    VALID = "VALID"


class ManagedBy(str, Enum):
    """Who manages certificate lifecycle."""

    DATACOM = "DATACOM"
    VENDOR = "VENDOR"
    AWS_AUTO_RENEW = "AWS_AUTO_RENEW"
    LETS_ENCRYPT = "LETS_ENCRYPT"
    UNKNOWN = "UNKNOWN"


class ProvisioningMethod(str, Enum):
    """How the certificate was originally provisioned."""

    MANUAL = "MANUAL"
    CLOUDFORMATION = "CLOUDFORMATION"
    TERRAFORM = "TERRAFORM"
    ADO = "ADO"
    CDK = "CDK"
    UNKNOWN = "UNKNOWN"


class CertificateUsage(BaseModel):
    """A resource that uses this certificate."""

    resource_type: str = Field(..., description="ALB, NLB, Classic ELB, CloudFront, API Gateway")
    resource_arn: str = Field(default="")
    resource_name: str = Field(default="")
    listener_arn: Optional[str] = None


class CertificateRecord(BaseModel):
    """Core certificate record for the central registry."""

    certificate_arn: str
    domain_name: str
    subject_alternative_names: list[str] = Field(default_factory=list)
    account_id: str = ""
    account_name: str = ""
    region: str = "ap-southeast-2"
    source: CertificateSource = CertificateSource.ACM
    status: CertificateStatus = CertificateStatus.ISSUED
    issuer: str = ""
    key_algorithm: str = ""
    certificate_type: str = ""  # AMAZON_ISSUED, IMPORTED, PRIVATE
    not_before: Optional[datetime] = None
    not_after: Optional[datetime] = None
    in_use: bool = False
    usage: list[CertificateUsage] = Field(default_factory=list)
    auto_renewal_eligible: bool = False
    renewal_status: str = ""  # ACM RenewalSummary.RenewalStatus: SUCCESS, PENDING_AUTO_RENEWAL, FAILED, N/A
    owner_team: str = "UNKNOWN"
    managed_by: ManagedBy = ManagedBy.UNKNOWN
    provisioning_method: ProvisioningMethod = ProvisioningMethod.UNKNOWN
    tags: dict[str, str] = Field(default_factory=dict)
    discovered_at: datetime = Field(default_factory=datetime.utcnow)

    @computed_field
    @property
    def days_until_expiry(self) -> Optional[int]:
        """Calculate days remaining until certificate expiry."""
        if self.not_after is None:
            return None
        now = datetime.now(UTC)
        # Strip tzinfo from not_after if needed for comparison
        not_after = self.not_after.replace(tzinfo=None) if self.not_after.tzinfo else self.not_after
        now_naive = now.replace(tzinfo=None)
        delta = not_after - now_naive
        return delta.days

    @computed_field
    @property
    def deletion_guidance(self) -> str:
        """HITL guidance: how to delete this certificate based on provisioning method."""
        if self.provisioning_method == ProvisioningMethod.CLOUDFORMATION:
            return "Delete via CloudFormation stack update"
        if self.provisioning_method == ProvisioningMethod.CDK:
            return "Delete via CDK deploy (remove construct)"
        if self.provisioning_method in (ProvisioningMethod.TERRAFORM, ProvisioningMethod.ADO):
            return "Refer to provisioning team (Terraform/ADO managed)"
        if self.provisioning_method == ProvisioningMethod.MANUAL:
            return "Delete manually via AWS Console"
        return "Determine creation method before deleting"

    @computed_field
    @property
    def safe_to_delete(self) -> bool:
        """Whether this certificate can be safely deleted (expired AND not in use)."""
        return self.expiry_bucket == ExpiryBucket.EXPIRED and not self.in_use

    @computed_field
    @property
    def expiry_bucket(self) -> ExpiryBucket:
        """Classify certificate into a risk bucket based on days until expiry."""
        days = self.days_until_expiry
        if days is None:
            return ExpiryBucket.VALID
        if days < 0:
            return ExpiryBucket.EXPIRED
        if days <= 7:
            return ExpiryBucket.CRITICAL_7D
        if days <= 30:
            return ExpiryBucket.WARNING_30D
        if days <= 90:
            return ExpiryBucket.ATTENTION_90D
        return ExpiryBucket.VALID


class CertificateInventorySummary(BaseModel):
    """Aggregated counts for reporting."""

    total_certificates: int = 0
    by_status: dict[str, int] = Field(default_factory=dict)
    by_expiry_bucket: dict[str, int] = Field(default_factory=dict)
    by_source: dict[str, int] = Field(default_factory=dict)
    by_managed_by: dict[str, int] = Field(default_factory=dict)
    by_provisioning_method: dict[str, int] = Field(default_factory=dict)
    in_use_count: int = 0
    unused_count: int = 0
    auto_renewal_eligible_count: int = 0
    safe_to_delete_count: int = 0
    accounts_scanned: int = 0
    accounts_failed: int = 0


class CertificateInventoryResult(BaseModel):
    """Complete inventory scan result."""

    certificates: list[CertificateRecord] = Field(default_factory=list)
    summary: CertificateInventorySummary = Field(default_factory=CertificateInventorySummary)
    scan_metadata: dict[str, Any] = Field(default_factory=dict)

    def build_summary(self) -> CertificateInventorySummary:
        """Build summary from certificate list."""
        summary = CertificateInventorySummary()
        summary.total_certificates = len(self.certificates)
        for cert in self.certificates:
            # By status
            status_key = cert.status.value
            summary.by_status[status_key] = summary.by_status.get(status_key, 0) + 1
            # By expiry bucket
            bucket_key = cert.expiry_bucket.value
            summary.by_expiry_bucket[bucket_key] = summary.by_expiry_bucket.get(bucket_key, 0) + 1
            # By source
            source_key = cert.source.value
            summary.by_source[source_key] = summary.by_source.get(source_key, 0) + 1
            # By managed_by
            mgr_key = cert.managed_by.value
            summary.by_managed_by[mgr_key] = summary.by_managed_by.get(mgr_key, 0) + 1
            # By provisioning_method
            prov_key = cert.provisioning_method.value
            summary.by_provisioning_method[prov_key] = summary.by_provisioning_method.get(prov_key, 0) + 1
            # Safe-to-delete count
            if cert.safe_to_delete:
                summary.safe_to_delete_count += 1
            # Usage counts
            if cert.in_use:
                summary.in_use_count += 1
            else:
                summary.unused_count += 1
            if cert.auto_renewal_eligible:
                summary.auto_renewal_eligible_count += 1
        summary.accounts_scanned = len(set(c.account_id for c in self.certificates if c.account_id))
        self.summary = summary
        return summary
