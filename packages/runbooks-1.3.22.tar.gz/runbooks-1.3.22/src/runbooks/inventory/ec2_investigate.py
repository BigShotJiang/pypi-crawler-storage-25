#!/usr/bin/env python3
"""
EC2 Host Investigation Orchestrator - 6-Phase Comprehensive Analysis

Chains 6 investigation phases into a single command for deep-dive EC2 analysis:

Phase 1 (Discovery):   ec2:DescribeInstances -- instance metadata, VPC, tags
Phase 2 (Metadata):    EBS layout via ebs_instance_health module
Phase 3 (Security):    SecurityHub+GuardDuty+Inspector via host_findings module
Phase 4 (Network):     VPC flow log traffic via flow_log_query module
Phase 5 (Compliance):  SSM patch state via ssm_instance_status module
Phase 6 (Summary):     Risk score aggregation + executive Rich panel

Design: Composition over inheritance. Each phase calls an existing module.
        Phase failures degrade gracefully -- investigation continues.

READONLY: ec2:DescribeInstances, ssm:*, securityhub:*, guardduty:*,
          inspector2:*, logs:*, ec2:DescribeFlowLogs -- no mutations.

Usage:
    runbooks inventory ec2-investigate --instance-id i-0abc123 --profile ops
    runbooks inventory ec2-investigate --instance-id i-0abc123 --profile ops --output json
"""

import json
from datetime import datetime, UTC
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    print_error,
    print_info,
)

# Retry config per Rule 6 (AWS API Consumer Audit)
_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})

# Risk scoring thresholds
_RISK_HIGH = 60
_RISK_CRITICAL = 80


def _get_ec2_client(profile: Optional[str], region: str):
    """Create EC2 client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("ec2", config=_RETRY_CONFIG)


# ─── Phase 1: Discovery ───────────────────────────────────────────────────────


def phase1_discovery(
    ec2_client,
    instance_id: str,
) -> dict[str, Any]:
    """
    Fetch core EC2 instance metadata via DescribeInstances.

    Returns dict with state, type, AMI, VPC, subnet, tags, launch time, private IP.
    """
    try:
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        reservations = response.get("Reservations", [])
        if not reservations:
            return {"error": f"Instance {instance_id} not found"}

        inst = reservations[0]["Instances"][0]

        # Calculate age in days
        launch_time = inst.get("LaunchTime")
        age_days: Optional[int] = None
        if launch_time:
            now = datetime.now(UTC)
            if launch_time.tzinfo is None:
                launch_time = launch_time.replace(tzinfo=UTC)
            age_days = (now - launch_time).days

        # Extract name tag
        tags = inst.get("Tags", [])
        name = next((t["Value"] for t in tags if t["Key"] == "Name"), instance_id)

        return {
            "instance_id": inst.get("InstanceId", instance_id),
            "name": name,
            "state": inst.get("State", {}).get("Name", "unknown"),
            "instance_type": inst.get("InstanceType", "N/A"),
            "ami_id": inst.get("ImageId", "N/A"),
            "vpc_id": inst.get("VpcId", "N/A"),
            "subnet_id": inst.get("SubnetId", "N/A"),
            "availability_zone": inst.get("Placement", {}).get("AvailabilityZone", "N/A"),
            "private_ip": inst.get("PrivateIpAddress", "N/A"),
            "public_ip": inst.get("PublicIpAddress"),
            "platform": inst.get("Platform", "linux"),
            "architecture": inst.get("Architecture", "N/A"),
            "launch_time": str(launch_time) if launch_time else "N/A",
            "age_days": age_days,
            "iam_profile": inst.get("IamInstanceProfile", {}).get("Arn", "None"),
            "monitoring": inst.get("Monitoring", {}).get("State", "disabled"),
            "imdsv2": inst.get("MetadataOptions", {}).get("HttpTokens", "optional"),
            "tags": {t["Key"]: t["Value"] for t in tags},
            "security_groups": [sg["GroupId"] for sg in inst.get("SecurityGroups", [])],
            "error": None,
        }
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("InvalidInstanceID.NotFound",):
            return {"error": f"Instance {instance_id} not found"}
        return {"error": f"EC2 API error ({error_code}): {e}"}


# ─── Phase 2: EBS Metadata ────────────────────────────────────────────────────


def phase2_ebs_metadata(
    instance_id: str,
    profile: Optional[str],
    region: str,
) -> dict[str, Any]:
    """
    Fetch EBS volume layout and encryption status via ebs_instance_health module.

    Returns structured dict with volumes summary.
    """
    try:
        from runbooks.inventory.ebs_instance_health import run_ebs_instance_health

        result = run_ebs_instance_health(
            instance_id=instance_id,
            profile=profile,
            region=region,
            output_format="json",
        )
        return result or {"error": "No EBS data returned"}
    except SystemExit:
        return {"error": "EBS health query failed (access denied or API error)"}
    except Exception as e:
        return {"error": f"EBS health query failed: {e}"}


# ─── Phase 3: Security Findings ───────────────────────────────────────────────


def phase3_security(
    instance_id: str,
    profile: Optional[str],
    region: str,
) -> dict[str, Any]:
    """
    Aggregate SecurityHub, GuardDuty, Inspector2 findings via host_findings module.

    Returns structured dict with severity counts and findings list.
    """
    try:
        from runbooks.security.host_findings import run_host_findings

        result = run_host_findings(
            resource_id=instance_id,
            profile=profile,
            region=region,
            output_format="json",
        )
        return result or {"error": "No security data returned"}
    except SystemExit:
        return {"error": "Security findings query failed (access denied or API error)"}
    except Exception as e:
        return {"error": f"Security findings query failed: {e}"}


# ─── Phase 4: Network / Flow Logs ─────────────────────────────────────────────


def phase4_network(
    instance_id: str,
    private_ip: str,
    vpc_id: str,
    profile: Optional[str],
    region: str,
    days: int = 7,
) -> dict[str, Any]:
    """
    Query VPC flow logs for the instance's private IP via flow_log_query module.

    Returns structured dict with flow summary and traffic classification.
    """
    if vpc_id == "N/A" or not private_ip or private_ip == "N/A":
        return {"error": "VPC ID or private IP not available -- skipping flow log query"}

    try:
        from runbooks.vpc.flow_log_query import run_flow_log_query

        result = run_flow_log_query(
            instance_ip=private_ip,
            vpc_id=vpc_id,
            profile=profile,
            region=region,
            days=days,
            output_format="json",
        )
        return result or {"error": "No flow log data returned"}
    except SystemExit:
        return {"error": "Flow log query failed (access denied or flow logs not enabled)"}
    except Exception as e:
        return {"error": f"Flow log query failed: {e}"}


# ─── Phase 5: SSM Compliance ──────────────────────────────────────────────────


def phase5_compliance(
    instance_id: str,
    profile: Optional[str],
    region: str,
) -> dict[str, Any]:
    """
    Fetch SSM agent info and patch compliance via ssm_instance_status module.

    Returns structured dict with patch counts and agent ping status.
    """
    try:
        from runbooks.inventory.ssm_instance_status import run_ssm_instance_status

        result = run_ssm_instance_status(
            instance_id=instance_id,
            profile=profile,
            region=region,
            output_format="json",
        )
        return result or {"error": "No SSM data returned"}
    except SystemExit:
        return {"error": "SSM status query failed (access denied or API error)"}
    except Exception as e:
        return {"error": f"SSM status query failed: {e}"}


# ─── Phase 6: Risk Scoring & Summary ─────────────────────────────────────────


def phase6_summary(
    instance_id: str,
    p1: dict[str, Any],
    p2: dict[str, Any],
    p3: dict[str, Any],
    p4: dict[str, Any],
    p5: dict[str, Any],
) -> dict[str, Any]:
    """
    Aggregate phase results into a risk score and executive recommendations.

    Risk scoring (100-point scale):
    - Security findings:  CRITICAL=20pts, HIGH=10pts, MEDIUM=5pts each (max 40)
    - Unencrypted EBS:    10 pts per unencrypted volume (max 20)
    - Missing patches:    5 pts per missing patch (max 15)
    - IMDSv2 not enforced: 10 pts
    - SSM offline:        5 pts
    - Old instance (>2yr): 5 pts
    - No monitoring:      5 pts

    Returns dict with risk_score, risk_level, and recommendations list.
    """
    risk_score = 0
    recommendations: list[dict[str, str]] = []

    # Security findings contribution
    severity_counts = p3.get("severity_counts", {})
    critical_count = severity_counts.get("CRITICAL", 0)
    high_count = severity_counts.get("HIGH", 0)
    medium_count = severity_counts.get("MEDIUM", 0)

    finding_score = min(critical_count * 20 + high_count * 10 + medium_count * 5, 40)
    risk_score += finding_score

    if critical_count > 0:
        recommendations.append(
            {
                "priority": "P0",
                "action": f"Remediate {critical_count} CRITICAL security finding(s) immediately",
            }
        )
    if high_count > 0:
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Address {high_count} HIGH severity finding(s)",
            }
        )

    # EBS encryption
    ebs_summary = p2.get("summary", {})
    unencrypted = ebs_summary.get("unencrypted_count", 0)
    if unencrypted > 0:
        enc_score = min(unencrypted * 10, 20)
        risk_score += enc_score
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Encrypt {unencrypted} unencrypted EBS volume(s)",
            }
        )

    # Patch compliance
    patch_data = p5.get("patch_compliance", {})
    missing_patches = patch_data.get("missing_count", 0)
    if missing_patches > 0:
        patch_score = min(missing_patches * 5, 15)
        risk_score += patch_score
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Apply {missing_patches} missing patch(es)",
            }
        )

    # IMDSv2 enforcement
    imdsv2 = p1.get("imdsv2", "optional")
    if imdsv2 != "required":
        risk_score += 10
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enforce IMDSv2 (HttpTokens=required) to prevent SSRF",
            }
        )

    # SSM agent status
    agent_info = p5.get("agent_info", {})
    ping_status = agent_info.get("ping_status", "NOT_REGISTERED")
    if ping_status not in ("Online",):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": f"SSM agent status is '{ping_status}' -- ensure agent is running",
            }
        )

    # Instance age (>2 years)
    age_days = p1.get("age_days")
    if age_days and age_days > 730:
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": f"Instance is {age_days} days old -- review for modernisation",
            }
        )

    # Monitoring state
    monitoring = p1.get("monitoring", "disabled")
    if monitoring == "disabled":
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Enable detailed CloudWatch monitoring",
            }
        )

    # Cap at 100
    risk_score = min(risk_score, 100)

    # Risk level classification
    if risk_score >= _RISK_CRITICAL:
        risk_level = "CRITICAL"
        risk_color = "red bold"
    elif risk_score >= _RISK_HIGH:
        risk_level = "HIGH"
        risk_color = "red"
    elif risk_score >= 30:
        risk_level = "MEDIUM"
        risk_color = "yellow"
    else:
        risk_level = "LOW"
        risk_color = "green"

    return {
        "instance_id": instance_id,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "recommendations": recommendations,
        "severity_counts": severity_counts,
        "finding_score": finding_score,
        "unencrypted_volumes": unencrypted,
        "missing_patches": missing_patches,
        "imdsv2_enforced": imdsv2 == "required",
        "ssm_ping_status": ping_status,
    }


# ─── Rendering ────────────────────────────────────────────────────────────────


def _phase_status(phase_data: dict[str, Any]) -> str:
    """Return coloured status indicator for a phase result."""
    if phase_data.get("error"):
        return "[yellow]SKIP[/yellow]"
    return "[green]OK[/green]"


def render_investigation(
    instance_id: str,
    phases: dict[str, dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    """Render full investigation results as a Rich panel to console."""
    p1 = phases["discovery"]
    p2 = phases["ebs_metadata"]
    p3 = phases["security"]
    p4 = phases["network"]
    p5 = phases["compliance"]

    risk_color = summary.get("risk_color", "white")
    risk_level = summary.get("risk_level", "UNKNOWN")
    risk_score = summary.get("risk_score", 0)

    # Build panel lines
    lines: list[str] = []

    # Phase 1
    if not p1.get("error"):
        age_str = f"{p1.get('age_days', '?')} days" if p1.get("age_days") is not None else "N/A"
        lines.append(
            f"  Phase 1: Discovery   {_phase_status(p1)}  "
            f"({p1.get('instance_type', 'N/A')}, {p1.get('state', 'N/A')}, "
            f"age: {age_str})"
        )
        lines.append(
            f"           VPC: {p1.get('vpc_id', 'N/A')}  "
            f"IP: {p1.get('private_ip', 'N/A')}  "
            f"IMDSv2: {p1.get('imdsv2', 'optional')}"
        )
    else:
        lines.append(f"  Phase 1: Discovery   [yellow]SKIP[/yellow]  {p1['error']}")

    # Phase 2
    ebs_summary = p2.get("summary", {})
    if not p2.get("error") and ebs_summary:
        lines.append(
            f"  Phase 2: EBS         {_phase_status(p2)}  "
            f"({ebs_summary.get('total_volumes', 0)} vols, "
            f"{ebs_summary.get('total_storage_gb', 0)} GiB, "
            f"{ebs_summary.get('unencrypted_count', 0)} unencrypted)"
        )
    else:
        lines.append(f"  Phase 2: EBS         [yellow]SKIP[/yellow]  {p2.get('error', 'No data')}")

    # Phase 3
    sev = summary.get("severity_counts", {})
    if not p3.get("error"):
        lines.append(
            f"  Phase 3: Security    {_phase_status(p3)}  "
            f"([red]{sev.get('CRITICAL', 0)} CRITICAL[/red], "
            f"[red]{sev.get('HIGH', 0)} HIGH[/red], "
            f"[yellow]{sev.get('MEDIUM', 0)} MEDIUM[/yellow])"
        )
    else:
        lines.append(f"  Phase 3: Security    [yellow]SKIP[/yellow]  {p3.get('error', 'No data')}")

    # Phase 4
    flow_summary = p4.get("summary", {})
    if not p4.get("error") and flow_summary:
        classification = flow_summary.get("classification", "UNKNOWN")
        total_flows = flow_summary.get("total_flows", 0)
        lines.append(f"  Phase 4: Network     {_phase_status(p4)}  ({classification}, {total_flows:,} flows)")
    else:
        lines.append(f"  Phase 4: Network     [yellow]SKIP[/yellow]  {p4.get('error', 'No data')}")

    # Phase 5
    agent_info = p5.get("agent_info", {})
    patch_data = p5.get("patch_compliance", {})
    if not p5.get("error"):
        missing = patch_data.get("missing_count", 0)
        ping = agent_info.get("ping_status", "N/A")
        lines.append(f"  Phase 5: Compliance  {_phase_status(p5)}  (SSM: {ping}, {missing} missing patches)")
    else:
        lines.append(f"  Phase 5: Compliance  [yellow]SKIP[/yellow]  {p5.get('error', 'No data')}")

    # Phase 6 summary
    lines.append(
        f"\n  Phase 6: Summary     [green]OK[/green]  "
        f"Risk Score: [{risk_color}]{risk_score}/100 ({risk_level})[/{risk_color}]"
    )

    # Recommendations
    recs = summary.get("recommendations", [])
    if recs:
        lines.append("\n  [bold]Recommendations:[/bold]")
        for i, rec in enumerate(recs, 1):
            priority = rec["priority"]
            p_color = {"P0": "red bold", "P1": "red", "P2": "yellow", "P3": "cyan"}.get(priority, "white")
            lines.append(f"  {i}. [[{p_color}]{priority}[/{p_color}]] {rec['action']}")

    panel_content = "\n".join(lines)
    name = phases["discovery"].get("name", instance_id) if not phases["discovery"].get("error") else instance_id

    console.print(
        create_panel(
            panel_content,
            title=f"EC2 Host Investigation: {instance_id} ({name})",
            border_style=risk_color.split()[0],  # strip 'bold' for border
        )
    )


# ─── Top-level runner ─────────────────────────────────────────────────────────


def run_ec2_investigate(
    instance_id: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    days: int = 7,
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Run a 6-phase EC2 host investigation and render results.

    Args:
        instance_id: EC2 instance ID (e.g. i-0abc123)
        profile: AWS profile name (None uses default/env)
        region: AWS region (default: ap-southeast-2)
        days: Flow log lookback window in days (default 7)
        output_format: "table" or "json"

    Returns:
        Structured dict with all phase results and risk summary

    Raises:
        SystemExit on unrecoverable initial errors (client creation failure)
    """
    print_info(f"Starting EC2 investigation for {instance_id} in {region}...")

    try:
        ec2_client = _get_ec2_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create EC2 client: {e}")
        raise SystemExit(1)

    phases: dict[str, dict[str, Any]] = {}

    # Phase 1: Discovery
    console.print("[dim]Phase 1/6: Discovery...[/dim]")
    phases["discovery"] = phase1_discovery(ec2_client, instance_id)
    if phases["discovery"].get("error") and "not found" in str(phases["discovery"]["error"]).lower():
        print_error(f"Instance {instance_id} not found. Aborting investigation.")
        raise SystemExit(1)

    # Extract context for downstream phases
    discovery = phases["discovery"]
    private_ip = discovery.get("private_ip", "N/A")
    vpc_id = discovery.get("vpc_id", "N/A")

    # Phase 2: EBS Metadata
    console.print("[dim]Phase 2/6: EBS metadata...[/dim]")
    phases["ebs_metadata"] = phase2_ebs_metadata(instance_id, profile, region)

    # Phase 3: Security Findings
    console.print("[dim]Phase 3/6: Security findings...[/dim]")
    phases["security"] = phase3_security(instance_id, profile, region)

    # Phase 4: Network / Flow Logs
    console.print("[dim]Phase 4/6: Network flow logs...[/dim]")
    phases["network"] = phase4_network(instance_id, private_ip, vpc_id, profile, region, days)

    # Phase 5: SSM Compliance
    console.print("[dim]Phase 5/6: SSM compliance...[/dim]")
    phases["compliance"] = phase5_compliance(instance_id, profile, region)

    # Phase 6: Risk Scoring
    console.print("[dim]Phase 6/6: Risk scoring...[/dim]")
    summary = phase6_summary(
        instance_id,
        phases["discovery"],
        phases["ebs_metadata"],
        phases["security"],
        phases["network"],
        phases["compliance"],
    )

    result: dict[str, Any] = {
        "instance_id": instance_id,
        "region": region,
        "phases": phases,
        "summary": summary,
        "timestamp": datetime.now(UTC).isoformat(),
    }

    if output_format == "json":
        console.print_json(json.dumps(result, default=str, indent=2))
        return result

    render_investigation(instance_id, phases, summary)
    return result
