#!/usr/bin/env python3
"""
VPC/TGW Investigation Orchestrator - 6-Phase Comprehensive Analysis

Chains 6 investigation phases into a single command for deep-dive VPC analysis:

Phase 1 (Discovery):   ec2:DescribeVpcs -- CIDR, tags, DHCP options, tenancy
Phase 2 (Metadata):    Subnets (public/private count), route tables, IGW, NAT GW
Phase 3 (Security):    NACLs, default SG rules, flow log status, SecurityHub findings
Phase 4 (Network):     Peering, TGW attachments, VPN connections, VPC endpoints
Phase 5 (Compliance):  Flow logs enabled, DNS resolution, DNS hostnames, IPAM
Phase 6 (Summary):     Resource count, estimated NAT GW cost, topology summary

Design: Composition over inheritance. Each phase is self-contained with graceful
        degradation -- a phase failure does not abort subsequent phases.

READONLY: ec2:Describe*, securityhub:GetFindings -- no mutations.

Usage:
    runbooks inventory vpc-investigate --vpc-id vpc-0abc123 --profile ops
    runbooks inventory vpc-investigate --vpc-id vpc-0abc123 --profile ops --output json
"""

import json
from datetime import datetime, UTC
from typing import Any, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    print_error,
    print_info,
)

_RETRY_CONFIG = Config(retries={"max_attempts": 3, "mode": "adaptive"})

_RISK_HIGH = 60
_RISK_CRITICAL = 80

# Approximate NAT Gateway cost (USD/month, ap-southeast-2)
_NAT_GW_MONTHLY_USD = 45.0


def _get_ec2_client(profile: Optional[str], region: str):
    """Create EC2 client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("ec2", config=_RETRY_CONFIG)


def _get_sh_client(profile: Optional[str], region: str):
    """Create SecurityHub client with retry config."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("securityhub", config=_RETRY_CONFIG)


def _tag_name(tags: list[dict[str, str]], default: str = "N/A") -> str:
    """Extract the Name tag value from a tags list."""
    if not tags:
        return default
    return next((t["Value"] for t in tags if t["Key"] == "Name"), default)


# ─── Phase 1: Discovery ───────────────────────────────────────────────────────


def phase1_discovery(ec2_client, vpc_id: str) -> dict[str, Any]:
    """
    Fetch core VPC metadata via DescribeVpcs.

    Returns dict with CIDR, tenancy, DHCP options, is_default, tags.
    """
    try:
        response = ec2_client.describe_vpcs(VpcIds=[vpc_id])
        vpcs = response.get("Vpcs", [])
        if not vpcs:
            return {"error": f"VPC {vpc_id} not found"}

        vpc = vpcs[0]
        tags = vpc.get("Tags", [])
        cidr_blocks = [assoc.get("CidrBlock", "N/A") for assoc in vpc.get("CidrBlockAssociationSet", [])]
        if not cidr_blocks:
            cidr_blocks = [vpc.get("CidrBlock", "N/A")]

        return {
            "vpc_id": vpc.get("VpcId", vpc_id),
            "name": _tag_name(tags, vpc_id),
            "state": vpc.get("State", "N/A"),
            "is_default": vpc.get("IsDefault", False),
            "cidr_block": vpc.get("CidrBlock", "N/A"),
            "cidr_blocks": cidr_blocks,
            "dhcp_options_id": vpc.get("DhcpOptionsId", "N/A"),
            "instance_tenancy": vpc.get("InstanceTenancy", "default"),
            "owner_id": vpc.get("OwnerId", "N/A"),
            "tags": {t["Key"]: t["Value"] for t in tags},
            "error": None,
        }
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("InvalidVpcID.NotFound",):
            return {"error": f"VPC {vpc_id} not found"}
        return {"error": f"EC2 API error ({error_code}): {e}"}


# ─── Phase 2: Metadata ────────────────────────────────────────────────────────


def phase2_metadata(ec2_client, vpc_id: str) -> dict[str, Any]:
    """
    Fetch VPC topology metadata: subnets, route tables, IGW, NAT gateways.

    Returns dict with counts and identifiers for key network components.
    """
    result: dict[str, Any] = {
        "total_subnets": 0,
        "public_subnets": 0,
        "private_subnets": 0,
        "subnet_ids": [],
        "internet_gateway_ids": [],
        "nat_gateway_ids": [],
        "nat_gateway_states": {},
        "route_table_ids": [],
        "main_route_table_id": None,
        "error": None,
    }

    # Subnets
    try:
        paginator = ec2_client.get_paginator("describe_subnets")
        subnets: list[dict[str, Any]] = []
        for page in paginator.paginate(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}],
            PaginationConfig={"MaxItems": 500, "PageSize": 100},
        ):
            subnets.extend(page.get("Subnets", []))

        result["total_subnets"] = len(subnets)
        result["subnet_ids"] = [s["SubnetId"] for s in subnets]

        # Classify subnets: public = MapPublicIpOnLaunch=True
        public_count = sum(1 for s in subnets if s.get("MapPublicIpOnLaunch", False))
        result["public_subnets"] = public_count
        result["private_subnets"] = len(subnets) - public_count
    except ClientError as e:
        result["subnet_error"] = f"Subnet fetch failed: {e.response['Error']['Code']}"

    # Internet Gateways
    try:
        igw_response = ec2_client.describe_internet_gateways(
            Filters=[{"Name": "attachment.vpc-id", "Values": [vpc_id]}]
        )
        result["internet_gateway_ids"] = [igw["InternetGatewayId"] for igw in igw_response.get("InternetGateways", [])]
    except ClientError as e:
        result["igw_error"] = f"IGW fetch failed: {e.response['Error']['Code']}"

    # NAT Gateways
    try:
        paginator = ec2_client.get_paginator("describe_nat_gateways")
        nat_gws: list[dict[str, Any]] = []
        for page in paginator.paginate(
            Filters=[
                {"Name": "vpc-id", "Values": [vpc_id]},
                {"Name": "state", "Values": ["available", "pending", "deleting"]},
            ],
            PaginationConfig={"MaxItems": 200, "PageSize": 100},
        ):
            nat_gws.extend(page.get("NatGateways", []))

        result["nat_gateway_ids"] = [n["NatGatewayId"] for n in nat_gws]
        result["nat_gateway_states"] = {n["NatGatewayId"]: n["State"] for n in nat_gws}
    except ClientError as e:
        result["nat_error"] = f"NAT GW fetch failed: {e.response['Error']['Code']}"

    # Route Tables
    try:
        paginator = ec2_client.get_paginator("describe_route_tables")
        route_tables: list[dict[str, Any]] = []
        for page in paginator.paginate(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}],
            PaginationConfig={"MaxItems": 200, "PageSize": 100},
        ):
            route_tables.extend(page.get("RouteTables", []))

        result["route_table_ids"] = [rt["RouteTableId"] for rt in route_tables]

        # Identify main route table
        for rt in route_tables:
            for assoc in rt.get("Associations", []):
                if assoc.get("Main"):
                    result["main_route_table_id"] = rt["RouteTableId"]
                    break
    except ClientError as e:
        result["rt_error"] = f"Route table fetch failed: {e.response['Error']['Code']}"

    return result


# ─── Phase 3: Security ────────────────────────────────────────────────────────


def phase3_security(
    ec2_client,
    sh_client,
    vpc_id: str,
) -> dict[str, Any]:
    """
    Assess VPC security: default SG rules, NACLs, SecurityHub findings.

    Returns dict with default_sg_warnings, nacl_count, securityhub findings.
    """
    result: dict[str, Any] = {
        "default_sg_id": None,
        "default_sg_has_open_rules": False,
        "default_sg_warnings": [],
        "nacl_count": 0,
        "nacl_ids": [],
        "securityhub_findings": [],
        "severity_counts": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
        "error": None,
    }

    # Default Security Group check
    try:
        sg_response = ec2_client.describe_security_groups(
            Filters=[
                {"Name": "vpc-id", "Values": [vpc_id]},
                {"Name": "group-name", "Values": ["default"]},
            ]
        )
        sgs = sg_response.get("SecurityGroups", [])
        if sgs:
            default_sg = sgs[0]
            result["default_sg_id"] = default_sg["GroupId"]

            # Check inbound rules
            for rule in default_sg.get("IpPermissions", []):
                for ip_range in rule.get("IpRanges", []):
                    if ip_range.get("CidrIp") == "0.0.0.0/0":
                        result["default_sg_has_open_rules"] = True
                        result["default_sg_warnings"].append(
                            f"Default SG allows 0.0.0.0/0 inbound on port {rule.get('FromPort', 'all')}"
                        )
                for ip_range in rule.get("Ipv6Ranges", []):
                    if ip_range.get("CidrIpv6") == "::/0":
                        result["default_sg_has_open_rules"] = True
                        result["default_sg_warnings"].append(
                            f"Default SG allows ::/0 inbound on port {rule.get('FromPort', 'all')}"
                        )
    except ClientError as e:
        result["sg_error"] = f"Security group check failed: {e.response['Error']['Code']}"

    # NACLs
    try:
        nacl_response = ec2_client.describe_network_acls(Filters=[{"Name": "vpc-id", "Values": [vpc_id]}])
        nacls = nacl_response.get("NetworkAcls", [])
        result["nacl_count"] = len(nacls)
        result["nacl_ids"] = [n["NetworkAclId"] for n in nacls]
    except ClientError as e:
        result["nacl_error"] = f"NACL fetch failed: {e.response['Error']['Code']}"

    # SecurityHub findings for VPC
    try:
        paginator = sh_client.get_paginator("get_findings")
        for page in paginator.paginate(
            Filters={
                "ResourceId": [{"Value": vpc_id, "Comparison": "CONTAINS"}],
                "RecordState": [{"Value": "ACTIVE", "Comparison": "EQUALS"}],
            },
            PaginationConfig={"MaxItems": 200, "PageSize": 100},
        ):
            for f in page.get("Findings", []):
                sev_label = f.get("Severity", {}).get("Label", "UNKNOWN").upper()
                title = f.get("Title", "N/A")[:80]
                result["securityhub_findings"].append({"title": title, "severity": sev_label})
                if sev_label in result["severity_counts"]:
                    result["severity_counts"][sev_label] += 1
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code not in ("AccessDeniedException", "InvalidAccessException"):
            result["sh_error"] = f"SecurityHub query failed: {error_code}"

    return result


# ─── Phase 4: Network ─────────────────────────────────────────────────────────


def phase4_network(ec2_client, vpc_id: str) -> dict[str, Any]:
    """
    Assess VPC connectivity: peering, TGW attachments, VPN, VPC endpoints.

    Returns dict with peering_connections, tgw_attachment_ids, vpn_connections, endpoint_ids.
    """
    result: dict[str, Any] = {
        "peering_connections": [],
        "tgw_attachment_ids": [],
        "tgw_ids": [],
        "vpn_connections": [],
        "vpc_endpoint_ids": [],
        "vpc_endpoint_count": 0,
        "error": None,
    }

    # VPC Peering
    try:
        paginator = ec2_client.get_paginator("describe_vpc_peering_connections")
        for page in paginator.paginate(
            Filters=[
                {"Name": "status-code", "Values": ["active", "pending-acceptance"]},
            ],
            PaginationConfig={"MaxItems": 100, "PageSize": 50},
        ):
            for peering in page.get("VpcPeeringConnections", []):
                accepter = peering.get("AccepterVpcInfo", {})
                requester = peering.get("RequesterVpcInfo", {})
                if accepter.get("VpcId") == vpc_id or requester.get("VpcId") == vpc_id:
                    peer_vpc = accepter.get("VpcId") if requester.get("VpcId") == vpc_id else requester.get("VpcId")
                    result["peering_connections"].append(
                        {
                            "peering_id": peering["VpcPeeringConnectionId"],
                            "peer_vpc_id": peer_vpc,
                            "peer_account": accepter.get("OwnerId")
                            if requester.get("VpcId") == vpc_id
                            else requester.get("OwnerId"),
                            "status": peering.get("Status", {}).get("Code", "N/A"),
                        }
                    )
    except ClientError as e:
        result["peering_error"] = f"Peering fetch failed: {e.response['Error']['Code']}"

    # TGW Attachments
    try:
        paginator = ec2_client.get_paginator("describe_transit_gateway_attachments")
        for page in paginator.paginate(
            Filters=[
                {"Name": "resource-id", "Values": [vpc_id]},
                {"Name": "resource-type", "Values": ["vpc"]},
            ],
            PaginationConfig={"MaxItems": 100, "PageSize": 50},
        ):
            for att in page.get("TransitGatewayAttachments", []):
                result["tgw_attachment_ids"].append(att["TransitGatewayAttachmentId"])
                tgw_id = att.get("TransitGatewayId")
                if tgw_id and tgw_id not in result["tgw_ids"]:
                    result["tgw_ids"].append(tgw_id)
    except ClientError as e:
        result["tgw_error"] = f"TGW attachment fetch failed: {e.response['Error']['Code']}"

    # VPN Connections -- scoped to this VPC via its Virtual Private Gateway (ISS-011).
    # Step 1: find the VGW(s) attached to the VPC.
    # Step 2: filter describe_vpn_connections by those VGW IDs so we do not return all
    #         VPN connections in the region (the old code had no vpc-id filter).
    try:
        vgw_response = ec2_client.describe_vpn_gateways(Filters=[{"Name": "attachment.vpc-id", "Values": [vpc_id]}])
        vgw_ids = [vgw["VpnGatewayId"] for vgw in vgw_response.get("VpnGateways", [])]

        if vgw_ids:
            vpn_response = ec2_client.describe_vpn_connections(
                Filters=[
                    {"Name": "vpn-gateway-id", "Values": vgw_ids},
                    {"Name": "state", "Values": ["available", "pending"]},
                ]
            )
            for vpn in vpn_response.get("VpnConnections", []):
                result["vpn_connections"].append(
                    {
                        "vpn_id": vpn["VpnConnectionId"],
                        "type": vpn.get("Type", "N/A"),
                        "state": vpn.get("State", "N/A"),
                    }
                )
    except ClientError as e:
        result["vpn_error"] = f"VPN fetch failed: {e.response['Error']['Code']}"

    # VPC Endpoints
    try:
        paginator = ec2_client.get_paginator("describe_vpc_endpoints")
        for page in paginator.paginate(
            Filters=[
                {"Name": "vpc-id", "Values": [vpc_id]},
                {"Name": "vpc-endpoint-state", "Values": ["available", "pending"]},
            ],
            PaginationConfig={"MaxItems": 200, "PageSize": 100},
        ):
            for ep in page.get("VpcEndpoints", []):
                result["vpc_endpoint_ids"].append(ep["VpcEndpointId"])
        result["vpc_endpoint_count"] = len(result["vpc_endpoint_ids"])
    except ClientError as e:
        result["endpoint_error"] = f"VPC endpoint fetch failed: {e.response['Error']['Code']}"

    return result


# ─── Phase 5: Compliance ──────────────────────────────────────────────────────


def phase5_compliance(ec2_client, vpc_id: str) -> dict[str, Any]:
    """
    Assess VPC compliance: flow logs, DNS resolution/hostnames.

    Returns dict with flow_logs_enabled, dns_resolution, dns_hostnames.
    """
    result: dict[str, Any] = {
        "flow_logs_enabled": False,
        "flow_log_destinations": [],
        "dns_resolution": False,
        "dns_hostnames": False,
        "is_default_vpc": False,
        "error": None,
    }

    # Flow logs
    try:
        paginator = ec2_client.get_paginator("describe_flow_logs")
        for page in paginator.paginate(
            Filters=[{"Name": "resource-id", "Values": [vpc_id]}],
            PaginationConfig={"MaxItems": 50, "PageSize": 50},
        ):
            for fl in page.get("FlowLogs", []):
                if fl.get("FlowLogStatus") == "ACTIVE":
                    result["flow_logs_enabled"] = True
                    result["flow_log_destinations"].append(fl.get("LogDestination") or fl.get("LogGroupName", "N/A"))
    except ClientError as e:
        result["flow_log_error"] = f"Flow log check failed: {e.response['Error']['Code']}"

    # DNS attributes
    try:
        dns_res_response = ec2_client.describe_vpc_attribute(VpcId=vpc_id, Attribute="enableDnsSupport")
        result["dns_resolution"] = dns_res_response.get("EnableDnsSupport", {}).get("Value", False)

        dns_host_response = ec2_client.describe_vpc_attribute(VpcId=vpc_id, Attribute="enableDnsHostnames")
        result["dns_hostnames"] = dns_host_response.get("EnableDnsHostnames", {}).get("Value", False)
    except ClientError as e:
        result["dns_error"] = f"DNS attribute check failed: {e.response['Error']['Code']}"

    # Default VPC status
    try:
        vpc_response = ec2_client.describe_vpcs(VpcIds=[vpc_id])
        vpcs = vpc_response.get("Vpcs", [])
        if vpcs:
            result["is_default_vpc"] = vpcs[0].get("IsDefault", False)
    except ClientError:
        pass

    return result


# ─── Phase 6: Risk Scoring ────────────────────────────────────────────────────


def phase6_summary(
    vpc_id: str,
    p1: dict[str, Any],
    p2: dict[str, Any],
    p3: dict[str, Any],
    p4: dict[str, Any],
    p5: dict[str, Any],
) -> dict[str, Any]:
    """
    Aggregate phase results into risk score and topology recommendations.

    Risk scoring (100-point scale):
    - Default VPC in use:            20 pts
    - Default SG has open rules:     25 pts
    - Flow logs not enabled:         20 pts
    - SecurityHub CRITICAL:          20 pts each (max 40)
    - SecurityHub HIGH:              10 pts each (max 20)
    - DNS resolution disabled:       5 pts
    - DNS hostnames disabled:        5 pts
    """
    risk_score = 0
    recommendations: list[dict[str, str]] = []

    # Default VPC
    if p1.get("is_default") or p5.get("is_default_vpc"):
        risk_score += 20
        recommendations.append(
            {
                "priority": "P1",
                "action": "Migrate workloads away from default VPC and delete it (CIS Benchmark 3.x)",
            }
        )

    # Default SG open rules
    if p3.get("default_sg_has_open_rules"):
        risk_score += 25
        for warning in p3.get("default_sg_warnings", []):
            recommendations.append(
                {
                    "priority": "P0",
                    "action": f"Remove default SG open rule: {warning}",
                }
            )

    # Flow logs
    if not p5.get("flow_logs_enabled"):
        risk_score += 20
        recommendations.append(
            {
                "priority": "P1",
                "action": "Enable VPC flow logs for network traffic audit and security monitoring",
            }
        )

    # SecurityHub findings
    sev = p3.get("severity_counts", {})
    critical_sh = sev.get("CRITICAL", 0)
    high_sh = sev.get("HIGH", 0)
    sh_score = min(critical_sh * 20 + high_sh * 10, 40)
    risk_score += sh_score
    if critical_sh > 0:
        recommendations.append(
            {
                "priority": "P0",
                "action": f"Remediate {critical_sh} CRITICAL SecurityHub finding(s)",
            }
        )
    if high_sh > 0:
        recommendations.append(
            {
                "priority": "P1",
                "action": f"Address {high_sh} HIGH SecurityHub finding(s)",
            }
        )

    # DNS attributes
    if not p5.get("dns_resolution"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Enable DNS resolution (enableDnsSupport=true) for internal DNS",
            }
        )
    if not p5.get("dns_hostnames"):
        risk_score += 5
        recommendations.append(
            {
                "priority": "P2",
                "action": "Consider enabling DNS hostnames (enableDnsHostnames=true)",
            }
        )

    # Cost insight (NAT gateways)
    nat_count = len(p2.get("nat_gateway_ids", []))
    estimated_nat_cost = nat_count * _NAT_GW_MONTHLY_USD
    if nat_count > 0:
        recommendations.append(
            {
                "priority": "P3",
                "action": (
                    f"{nat_count} NAT Gateway(s) detected (~USD {estimated_nat_cost:.0f}/month base) "
                    "-- review if VPC endpoints can replace internet-bound traffic"
                ),
            }
        )

    risk_score = min(risk_score, 100)

    if risk_score >= _RISK_CRITICAL:
        risk_level, risk_color = "CRITICAL", "red bold"
    elif risk_score >= _RISK_HIGH:
        risk_level, risk_color = "HIGH", "red"
    elif risk_score >= 30:
        risk_level, risk_color = "MEDIUM", "yellow"
    else:
        risk_level, risk_color = "LOW", "green"

    return {
        "vpc_id": vpc_id,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "recommendations": recommendations,
        "severity_counts": sev,
        "nat_gateway_count": nat_count,
        "estimated_nat_monthly_usd": estimated_nat_cost,
        "peering_count": len(p4.get("peering_connections", [])),
        "tgw_count": len(p4.get("tgw_ids", [])),
        "endpoint_count": p4.get("vpc_endpoint_count", 0),
    }


# ─── Rendering ────────────────────────────────────────────────────────────────


def _phase_status(phase_data: dict[str, Any]) -> str:
    """Return coloured status indicator for a phase result."""
    if phase_data.get("error"):
        return "[yellow]SKIP[/yellow]"
    return "[green]OK[/green]"


def render_investigation(
    vpc_id: str,
    phases: dict[str, dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    """Render VPC investigation results as a Rich panel."""
    p1 = phases["discovery"]
    p2 = phases["metadata"]
    p3 = phases["security"]
    p4 = phases["network"]
    p5 = phases["compliance"]

    risk_color = summary.get("risk_color", "white")
    risk_level = summary.get("risk_level", "UNKNOWN")
    risk_score = summary.get("risk_score", 0)

    lines: list[str] = []

    if not p1.get("error"):
        default_str = "[yellow]YES (default)[/yellow]" if p1.get("is_default") else "[green]No[/green]"
        lines.append(
            f"  Phase 1: Discovery   {_phase_status(p1)}  "
            f"({p1.get('cidr_block', 'N/A')}, state: {p1.get('state', 'N/A')}, "
            f"default: {default_str})"
        )
        lines.append(f"           Name: {p1.get('name', vpc_id)}")
    else:
        lines.append(f"  Phase 1: Discovery   [yellow]SKIP[/yellow]  {p1['error']}")

    if not p2.get("error"):
        nat_count = len(p2.get("nat_gateway_ids", []))
        nat_cost = summary.get("estimated_nat_monthly_usd", 0.0)
        nat_str = f"{nat_count} NAT GW (~USD {nat_cost:.0f}/mo)" if nat_count else "0 NAT GW"
        lines.append(
            f"  Phase 2: Metadata    {_phase_status(p2)}  "
            f"({p2.get('total_subnets', 0)} subnets "
            f"[{p2.get('public_subnets', 0)} pub / {p2.get('private_subnets', 0)} priv], "
            f"{nat_str})"
        )
    else:
        lines.append(f"  Phase 2: Metadata    [yellow]SKIP[/yellow]  {p2.get('error', 'No data')}")

    sev = summary.get("severity_counts", {})
    default_sg_warn = p3.get("default_sg_has_open_rules", False)
    sg_str = "[red]OPEN RULES[/red]" if default_sg_warn else "[green]OK[/green]"
    lines.append(
        f"  Phase 3: Security    {_phase_status(p3)}  "
        f"(default SG: {sg_str}, "
        f"[red]{sev.get('CRITICAL', 0)} CRITICAL[/red], "
        f"[red]{sev.get('HIGH', 0)} HIGH[/red], "
        f"{p3.get('nacl_count', 0)} NACLs)"
    )

    peering_count = summary.get("peering_count", 0)
    tgw_count = summary.get("tgw_count", 0)
    ep_count = summary.get("endpoint_count", 0)
    lines.append(
        f"  Phase 4: Network     {_phase_status(p4)}  "
        f"(peering: {peering_count}, TGW: {tgw_count}, "
        f"endpoints: {ep_count}, VPN: {len(p4.get('vpn_connections', []))})"
    )

    if not p5.get("error"):
        fl_str = "[green]Yes[/green]" if p5.get("flow_logs_enabled") else "[red]No[/red]"
        dns_str = "[green]Yes[/green]" if p5.get("dns_resolution") else "[yellow]No[/yellow]"
        lines.append(
            f"  Phase 5: Compliance  {_phase_status(p5)}  "
            f"(flow logs: {fl_str}, DNS resolution: {dns_str}, "
            f"DNS hostnames: {p5.get('dns_hostnames', False)})"
        )
    else:
        lines.append(f"  Phase 5: Compliance  [yellow]SKIP[/yellow]  {p5.get('error', 'No data')}")

    lines.append(
        f"\n  Phase 6: Summary     [green]OK[/green]  "
        f"Risk Score: [{risk_color}]{risk_score}/100 ({risk_level})[/{risk_color}]"
    )

    # Topology summary
    lines.append(
        f"\n  [bold]Topology:[/bold] "
        f"{p2.get('total_subnets', 0)} subnets | "
        f"{len(p2.get('nat_gateway_ids', []))} NAT GW | "
        f"{len(p2.get('internet_gateway_ids', []))} IGW | "
        f"{len(p2.get('route_table_ids', []))} route tables | "
        f"{peering_count} peering | {tgw_count} TGW | {ep_count} endpoints"
    )

    recs = summary.get("recommendations", [])
    if recs:
        lines.append("\n  [bold]Recommendations:[/bold]")
        for i, rec in enumerate(recs, 1):
            priority = rec["priority"]
            p_color = {"P0": "red bold", "P1": "red", "P2": "yellow", "P3": "cyan"}.get(priority, "white")
            lines.append(f"  {i}. [[{p_color}]{priority}[/{p_color}]] {rec['action']}")

    vpc_name = p1.get("name", vpc_id) if not p1.get("error") else vpc_id
    console.print(
        create_panel(
            "\n".join(lines),
            title=f"VPC Investigation: {vpc_id} ({vpc_name})",
            border_style=risk_color.split()[0],
        )
    )


# ─── Top-level runner ─────────────────────────────────────────────────────────


def run_vpc_investigate(
    vpc_id: str,
    profile: Optional[str],
    region: str = "ap-southeast-2",
    output_format: str = "table",
) -> dict[str, Any]:
    """
    Run a 6-phase VPC/TGW investigation and render results.

    Args:
        vpc_id: VPC ID (e.g. vpc-0abc123def)
        profile: AWS profile name (None uses default/env)
        region: AWS region (default: ap-southeast-2)
        output_format: "table" or "json"

    Returns:
        Structured dict with all phase results and risk summary

    Raises:
        SystemExit on unrecoverable initial errors
    """
    print_info(f"Starting VPC investigation for {vpc_id} in {region}...")

    try:
        ec2_client = _get_ec2_client(profile, region)
        sh_client = _get_sh_client(profile, region)
    except Exception as e:
        print_error(f"Failed to create AWS clients: {e}")
        raise SystemExit(1)

    phases: dict[str, dict[str, Any]] = {}

    console.print("[dim]Phase 1/6: Discovery...[/dim]")
    phases["discovery"] = phase1_discovery(ec2_client, vpc_id)
    if phases["discovery"].get("error") and "not found" in str(phases["discovery"]["error"]).lower():
        print_error(f"VPC {vpc_id} not found. Aborting investigation.")
        raise SystemExit(1)

    console.print("[dim]Phase 2/6: Metadata...[/dim]")
    phases["metadata"] = phase2_metadata(ec2_client, vpc_id)

    console.print("[dim]Phase 3/6: Security...[/dim]")
    phases["security"] = phase3_security(ec2_client, sh_client, vpc_id)

    console.print("[dim]Phase 4/6: Network...[/dim]")
    phases["network"] = phase4_network(ec2_client, vpc_id)

    console.print("[dim]Phase 5/6: Compliance...[/dim]")
    phases["compliance"] = phase5_compliance(ec2_client, vpc_id)

    console.print("[dim]Phase 6/6: Risk scoring...[/dim]")
    summary = phase6_summary(
        vpc_id,
        phases["discovery"],
        phases["metadata"],
        phases["security"],
        phases["network"],
        phases["compliance"],
    )

    result: dict[str, Any] = {
        "vpc_id": vpc_id,
        "region": region,
        "phases": phases,
        "summary": summary,
        "timestamp": datetime.now(UTC).isoformat(),
    }

    if output_format == "json":
        console.print_json(json.dumps(result, default=str, indent=2))
        return result

    render_investigation(vpc_id, phases, summary)
    return result
