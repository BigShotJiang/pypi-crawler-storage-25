#!/usr/bin/env python3
"""
KMS Activity Enricher - Key Management Service Activity Signals
===============================================================

Business Value: Identify KMS keys with rotation disabled, grant accumulation, or pending deletion.
Strategic Impact: Reduce compliance risk and per-key charges ($1/month each CUSTOMER key).
Integration: Feeds data to FinOps activity health tree (F8 enricher, Order 2).

Activity Signals (K1-K7):
- K1: Rotation disabled — CUSTOMER symmetric key with no automatic rotation (SHOULD)
- K2: Key unused >180 days — no rotation history or grants/aliases (MUST)
- K3: Alias orphan — alias pointing to non-existent or deleted key (KEEP)
- K4: Grant accumulation — >50 grants per key (suggests build-up) (SHOULD)
- K5: Imported key expiring — EXTERNAL origin with ValidTo within 30 days (MUST)
- K6: Multi-region replica gap — multi-region primary with no replica keys (KEEP)
- K7: Pending deletion — key scheduled for deletion (informational) (KEEP)

Usage:
    from runbooks.finops.kms_activity_enricher import KMSActivityEnricher

    enricher = KMSActivityEnricher(
        operational_profile="my-profile",
        region="ap-southeast-2",
    )
    df = enricher.discover()
    df = enricher.enrich_signals(df)

Author: Runbooks Team
Version: 1.0.0
Epic: FinOps Activity Health Tree (10-enricher sprint, Order 2)
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone, UTC
from enum import Enum
from typing import Any

import pandas as pd
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.profile_utils import create_operational_session
from runbooks.common.rich_utils import BOX_PRIMARY, console, create_table, format_cost
from runbooks.finops.base_enrichers import ActivityEnricherMixin, ActivityTreeBranch  # noqa: F401

logger = logging.getLogger(__name__)

# KMS per-customer key monthly charge
_KMS_KEY_MONTHLY_COST: float = 1.00

# ═════════════════════════════════════════════════════════════════════════════
# ENUMERATION TYPES
# ═════════════════════════════════════════════════════════════════════════════

class KMSIdleSignal(str, Enum):
    """KMS idle/risk/waste decommission signals (K1-K7)."""

    K1 = "K1: Rotation disabled (CUSTOMER symmetric key)"
    K2 = "K2: Key unused >180 days"
    K3 = "K3: Alias orphan (alias without active key)"
    K4 = "K4: Grant accumulation (>50 grants)"
    K5 = "K5: Imported key expiring within 30 days"
    K6 = "K6: Multi-region replica gap"
    K7 = "K7: Key pending deletion (informational)"

# ═════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class KMSKeyMetrics:
    """Configuration and usage metrics for a single KMS key."""

    key_id: str
    key_arn: str
    key_state: str = "Enabled"  # Enabled | Disabled | PendingDeletion | PendingImport | Unavailable
    key_manager: str = "CUSTOMER"  # AWS | CUSTOMER
    key_spec: str = "SYMMETRIC_DEFAULT"  # SYMMETRIC_DEFAULT | RSA_2048 | etc.
    origin: str = "AWS_KMS"  # AWS_KMS | EXTERNAL | AWS_CLOUDHSM
    rotation_enabled: bool = True
    creation_date: datetime | None = None
    valid_to: datetime | None = None  # For EXTERNAL keys only
    multi_region: bool = False
    replica_keys: list[str] = field(default_factory=list)
    alias_names: list[str] = field(default_factory=list)
    grant_count: int = 0
    days_since_creation: int = 0

@dataclass
class KMSActivityAnalysis:
    """Analysis result for a single KMS key."""

    key_id: str
    key_arn: str
    region: str
    account_id: str
    metrics: KMSKeyMetrics
    signals_triggered: list[str] = field(default_factory=list)
    tier: str = "KEEP"
    annual_cost_estimate: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

# ═════════════════════════════════════════════════════════════════════════════
# CORE ENRICHER
# ═════════════════════════════════════════════════════════════════════════════

class KMSActivityEnricher(ActivityEnricherMixin):
    """
    KMS activity enricher for the FinOps activity health tree.

    Implements ActivityTreeBranch Protocol (discover / enrich_signals / render /
    handle_permission_denied) plus ActivityEnricherMixin boilerplate.

    AWS API Audit (Rule 6):
    [x] Pagination: get_paginator("list_keys"), get_paginator("list_aliases"),
        get_paginator("list_grants") — all used
    [x] Retry: Config(retries={"max_attempts": 3, "mode": "adaptive"}) on all clients
    [x] Error visibility: ClientError caught + console.print warning; no silent return None
    [x] Timeout: with_timeout() wraps _discover_inner in render()
    [x] Account name: account_id passed as-is; caller resolves via Organizations

    Only CUSTOMER-managed keys are evaluated for most signals (AWS-managed keys
    are free and cannot be deleted by customers). K3 (alias orphan) covers all aliases.

    Signals:
        K1 SHOULD — rotation disabled on CUSTOMER symmetric key
        K2 MUST   — key unused >180 days (no grants, aliases, recent rotation)
        K3 KEEP   — alias orphan (alias without active key)
        K4 SHOULD — grant accumulation (>50 grants per key)
        K5 MUST   — imported key expiring within 30 days
        K6 KEEP   — multi-region primary with no replica keys
        K7 KEEP   — key pending deletion (informational)
    """

    # ActivityTreeBranch Protocol constants
    service_id: str = "kms"
    service_emoji: str = "🔑"
    service_display_name: str = "KMS"
    priority: int = 70

    # Threshold for grant accumulation signal
    _GRANT_ACCUMULATION_THRESHOLD: int = 50

    # Days without modification to flag as unused
    _UNUSED_THRESHOLD_DAYS: int = 180

    # Days until expiry to trigger K5
    _EXPIRY_WARNING_DAYS: int = 30

    def __init__(
        self,
        operational_profile: str,
        region: str | None = None,
        lookback_days: int = 90,
        cache_ttl: int = 300,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            operational_profile=operational_profile,
            region=region,
            lookback_days=lookback_days,
            cache_ttl=cache_ttl,
            **kwargs,
        )
        self._cfg = Config(retries={"max_attempts": 3, "mode": "adaptive"})
        self._session = create_operational_session(operational_profile)
        self._client = self._session.client("kms", region_name=self.region, config=self._cfg)
        logger.debug(
            "KMSActivityEnricher init: profile=%s region=%s lookback=%dd",
            operational_profile,
            self.region,
            self.lookback_days,
        )

    # ── Discovery ─────────────────────────────────────────────────────────────

    def discover(self) -> pd.DataFrame:
        """
        Paginate kms:ListKeys and collect per-key metadata.

        Returns one row per KMS key with columns:
        resource_id, key_id, key_arn, region, account_id,
        key_state, key_manager, key_spec, origin, rotation_enabled,
        creation_date_iso, valid_to_iso, multi_region, replica_count,
        alias_names, grant_count, days_since_creation.
        """
        rows: list[dict[str, Any]] = []
        now = datetime.now(UTC)

        # Build alias map: key_id -> list[alias_name]
        alias_map = self._build_alias_map()

        try:
            paginator = self._client.get_paginator("list_keys")
            for page in paginator.paginate():
                for key_entry in page.get("Keys", []):
                    key_id = key_entry["KeyId"]
                    key_arn = key_entry["KeyArn"]

                    try:
                        meta = self._client.describe_key(KeyId=key_id)["KeyMetadata"]
                    except ClientError as e:
                        console.print(f"[yellow]Warning: kms DescribeKey {key_id} failed: {e}[/yellow]")
                        continue

                    key_manager = meta.get("KeyManager", "CUSTOMER")
                    key_state = meta.get("KeyState", "Enabled")
                    key_spec = meta.get("KeySpec", "SYMMETRIC_DEFAULT")
                    origin = meta.get("Origin", "AWS_KMS")
                    multi_region = meta.get("MultiRegion", False)
                    creation_date = meta.get("CreationDate")
                    valid_to = meta.get("ValidTo")

                    # Rotation status (only meaningful for CUSTOMER SYMMETRIC keys)
                    rotation_enabled = False
                    if key_manager == "CUSTOMER" and key_spec == "SYMMETRIC_DEFAULT":
                        try:
                            rot_resp = self._client.get_key_rotation_status(KeyId=key_id)
                            rotation_enabled = rot_resp.get("KeyRotationEnabled", False)
                        except ClientError as e:
                            console.print(f"[yellow]Warning: kms GetKeyRotationStatus {key_id} failed: {e}[/yellow]")

                    # Replica count
                    replica_count = 0
                    if multi_region:
                        mr_config = meta.get("MultiRegionConfiguration", {})
                        replica_count = len(mr_config.get("ReplicaKeys", []))

                    # Grant count
                    grant_count = self._count_grants(key_id)

                    # Days since creation
                    days_since_creation = 0
                    creation_date_iso = ""
                    if creation_date:
                        creation_date_iso = creation_date.isoformat()
                        if creation_date.tzinfo is None:
                            creation_date = creation_date.replace(tzinfo=UTC)
                        days_since_creation = (now - creation_date).days

                    valid_to_iso = valid_to.isoformat() if valid_to else ""

                    rows.append(
                        {
                            "resource_id": key_arn,
                            "key_id": key_id,
                            "key_arn": key_arn,
                            "region": self.region,
                            "account_id": key_arn.split(":")[4] if ":" in key_arn else "",
                            "key_state": key_state,
                            "key_manager": key_manager,
                            "key_spec": key_spec,
                            "origin": origin,
                            "rotation_enabled": rotation_enabled,
                            "creation_date_iso": creation_date_iso,
                            "valid_to_iso": valid_to_iso,
                            "multi_region": multi_region,
                            "replica_count": replica_count,
                            "alias_names": alias_map.get(key_id, []),
                            "grant_count": grant_count,
                            "days_since_creation": days_since_creation,
                        }
                    )
        except ClientError as e:
            console.print(f"[yellow]Warning: kms ListKeys failed: {e}[/yellow]")
            return pd.DataFrame()

        if not rows:
            return pd.DataFrame(
                columns=[
                    "resource_id",
                    "key_id",
                    "key_arn",
                    "region",
                    "account_id",
                    "key_state",
                    "key_manager",
                    "key_spec",
                    "origin",
                    "rotation_enabled",
                    "creation_date_iso",
                    "valid_to_iso",
                    "multi_region",
                    "replica_count",
                    "alias_names",
                    "grant_count",
                    "days_since_creation",
                ]
            )
        return pd.DataFrame(rows)

    # ── Signal enrichment ─────────────────────────────────────────────────────

    def enrich_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply K1-K7 signal logic to the discovery DataFrame.

        Adds columns: signals_triggered (list[str]), tier (MUST/SHOULD/KEEP),
        annual_cost_estimate (float).
        """
        if df.empty:
            df["signals_triggered"] = pd.Series(dtype=object)
            df["tier"] = pd.Series(dtype=str)
            df["annual_cost_estimate"] = pd.Series(dtype=float)
            return df

        now = datetime.now(UTC)

        # Build orphan alias set: aliases that point to no active key in df
        active_key_ids = set(df["key_id"].tolist())
        orphan_aliases = self._find_orphan_aliases(active_key_ids)

        signals_list: list[list[str]] = []
        tiers: list[str] = []
        annual_costs: list[float] = []

        for _, row in df.iterrows():
            key_manager: str = str(row.get("key_manager", "CUSTOMER"))
            key_spec: str = str(row.get("key_spec", "SYMMETRIC_DEFAULT"))
            key_state: str = str(row.get("key_state", "Enabled"))
            origin: str = str(row.get("origin", "AWS_KMS"))
            rotation_enabled: bool = bool(row.get("rotation_enabled", True))
            grant_count: int = int(row.get("grant_count", 0))
            multi_region: bool = bool(row.get("multi_region", False))
            replica_count: int = int(row.get("replica_count", 0))
            days_since_creation: int = int(row.get("days_since_creation", 0))
            valid_to_iso: str = str(row.get("valid_to_iso", ""))
            alias_names: list[str] = list(row.get("alias_names", []))

            signals: list[str] = []

            # K1: Rotation disabled on CUSTOMER symmetric key
            if (
                key_manager == "CUSTOMER"
                and key_spec == "SYMMETRIC_DEFAULT"
                and not rotation_enabled
                and key_state == "Enabled"
            ):
                signals.append("K1")

            # K2: Key unused >180 days
            # v1 simplification per plan: flag if creation >180d ago
            # AND no grants AND no aliases (absence of integration markers)
            if (
                days_since_creation > self._UNUSED_THRESHOLD_DAYS
                and grant_count == 0
                and not alias_names
                and key_manager == "CUSTOMER"
            ):
                signals.append("K2")

            # K3: Alias orphan — covered at DataFrame level
            # If any alias belonging to this key_id is in orphan_aliases, flag it
            key_id: str = str(row.get("key_id", ""))
            if any(a in orphan_aliases for a in alias_names):
                signals.append("K3")

            # K4: Grant accumulation
            if grant_count > self._GRANT_ACCUMULATION_THRESHOLD:
                signals.append("K4")

            # K5: Imported key expiring within 30 days
            if origin == "EXTERNAL" and valid_to_iso:
                try:
                    valid_to_dt = datetime.fromisoformat(valid_to_iso.replace("Z", "+00:00"))
                    if valid_to_dt.tzinfo is None:
                        valid_to_dt = valid_to_dt.replace(tzinfo=UTC)
                    days_until_expiry = (valid_to_dt - now).days
                    if days_until_expiry <= self._EXPIRY_WARNING_DAYS:
                        signals.append("K5")
                except (ValueError, TypeError):
                    pass

            # K6: Multi-region primary with no replica keys
            if multi_region and replica_count == 0:
                signals.append("K6")

            # K7: Pending deletion (informational)
            if key_state == "PendingDeletion":
                signals.append("K7")

            # Cost: $1/month per CUSTOMER key
            annual_cost = _KMS_KEY_MONTHLY_COST * 12 if key_manager == "CUSTOMER" else 0.0

            tier = self._classify_tier(signals)
            signals_list.append(signals)
            tiers.append(tier)
            annual_costs.append(annual_cost)

        df = df.copy()
        df["signals_triggered"] = signals_list
        df["tier"] = tiers
        df["annual_cost_estimate"] = annual_costs
        return df

    # ── Render ────────────────────────────────────────────────────────────────

    def render(self, tree: "Any", timeout: int = 15) -> None:
        """Render KMS branch into the supplied Rich Tree node."""
        from rich.text import Text

        try:
            df = self.with_timeout(self._discover_inner, seconds=timeout)
        except TimeoutError:
            label = Text()
            label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
            label.append(f"(timed out after {timeout}s)", style="dim italic yellow")
            tree.add(label)
            return
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code in ("AccessDenied", "UnauthorizedOperation"):
                self.handle_permission_denied(tree, e)
                return
            raise

        if df is None or df.empty:
            header = Text()
            header.append(f"{self.service_emoji} {self.service_display_name}", style="dim")
            header.append(" — no keys found", style="dim italic")
            tree.add(header)
            return

        must = df[df["tier"] == "MUST"]
        should = df[df["tier"] == "SHOULD"]
        keep = df[df["tier"] == "KEEP"]

        header_text = Text()
        header_text.append(f"{self.service_emoji} {self.service_display_name}", style="bold cyan")
        header_text.append(f"  {len(df)} key(s)", style="dim")
        if not must.empty:
            header_text.append(f"  {len(must)} MUST", style="bold red")
        if not should.empty:
            header_text.append(f"  {len(should)} SHOULD", style="bold yellow")
        branch = tree.add(header_text)

        if not must.empty:
            must_node = branch.add(Text("● MUST action (expiring/unused)", style="bold bright_red"))
            for _, row in must.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                aliases = ", ".join(row["alias_names"]) if row["alias_names"] else "—"
                label = Text()
                label.append(row["key_id"], style="red")
                label.append(f"  [{sigs}]", style="dim red")
                label.append(f"  aliases: {aliases}", style="dim")
                must_node.add(label)

        if not should.empty:
            should_node = branch.add(Text("◎ SHOULD review", style="bold yellow"))
            for _, row in should.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                annual = f"${row['annual_cost_estimate']:,.0f}/yr"
                label = Text()
                label.append(row["key_id"], style="yellow")
                label.append(f"  [{sigs}]", style="dim yellow")
                label.append(f"  {annual}", style="dim")
                should_node.add(label)

        if not keep.empty:
            keep_label = Text()
            keep_label.append(f"✓ {len(keep)} key(s) healthy/informational", style="dim green")
            branch.add(keep_label)

        legend = Text()
        legend.append(
            "K1:rotation-disabled K2:unused>180d K3:alias-orphan "
            "K4:grant-accumulation K5:import-expiring K6:replica-gap K7:pending-deletion",
            style="dim italic",
        )
        branch.add(legend)

    def handle_permission_denied(self, tree: "Any", exc: Exception) -> None:
        """Render permission-denied stub when IAM blocks KMS API calls."""
        from rich.text import Text

        label = Text()
        label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
        label.append("(permission denied — check IAM)", style="dim italic yellow")
        tree.add(label)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _discover_inner(self) -> pd.DataFrame:
        """Wrapper for with_timeout: discover + enrich_signals."""
        df = self.discover()
        return self.enrich_signals(df)

    def _classify_tier(self, signals: list[str]) -> str:
        """Return highest-priority tier given triggered signal keys."""
        if any(s in ("K2", "K5") for s in signals):
            return "MUST"
        if any(s in ("K1", "K4") for s in signals):
            return "SHOULD"
        if signals:  # K3, K6, K7
            return "KEEP"
        return "KEEP"

    def _build_alias_map(self) -> dict[str, list[str]]:
        """
        Build a mapping of key_id -> [alias_names] from ListAliases paginator.

        Aliases that have no TargetKeyId (orphans) are tracked separately.
        """
        alias_map: dict[str, list[str]] = {}
        try:
            paginator = self._client.get_paginator("list_aliases")
            for page in paginator.paginate():
                for alias in page.get("Aliases", []):
                    alias_name = alias.get("AliasName", "")
                    target_key_id = alias.get("TargetKeyId")
                    if target_key_id:
                        alias_map.setdefault(target_key_id, []).append(alias_name)
        except ClientError as e:
            console.print(f"[yellow]Warning: kms ListAliases failed: {e}[/yellow]")
        return alias_map

    def _find_orphan_aliases(self, active_key_ids: set[str]) -> set[str]:
        """
        Return set of alias names whose TargetKeyId is absent from active_key_ids.

        An alias is orphaned when it points to a deleted or non-existent key.
        """
        orphans: set[str] = set()
        try:
            paginator = self._client.get_paginator("list_aliases")
            for page in paginator.paginate():
                for alias in page.get("Aliases", []):
                    alias_name = alias.get("AliasName", "")
                    target_key_id = alias.get("TargetKeyId")
                    if target_key_id and target_key_id not in active_key_ids:
                        orphans.add(alias_name)
                    elif not target_key_id:
                        # Alias with no target is definitionally orphaned
                        orphans.add(alias_name)
        except ClientError as e:
            console.print(f"[yellow]Warning: kms ListAliases (orphan scan) failed: {e}[/yellow]")
        return orphans

    def _count_grants(self, key_id: str) -> int:
        """Count active grants for a key using ListGrants paginator."""
        count = 0
        try:
            paginator = self._client.get_paginator("list_grants")
            for page in paginator.paginate(KeyId=key_id):
                count += len(page.get("Grants", []))
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code not in ("NotFoundException", "KMSInvalidStateException"):
                console.print(f"[yellow]Warning: kms ListGrants {key_id} failed: {e}[/yellow]")
        return count

    # ── Legacy display helper ─────────────────────────────────────────────────

    def display_analysis(self, analyses: list[KMSActivityAnalysis]) -> None:
        """Display KMS analysis results as a Rich table."""
        if not analyses:
            console.print("[yellow]No KMS analyses to display[/yellow]")
            return

        table = create_table(
            columns=[
                {"name": "Key ID", "style": "cyan"},
                {"name": "State", "style": "white"},
                {"name": "Origin", "style": "white"},
                {"name": "Signals", "style": "bright_magenta"},
                {"name": "Tier", "style": "bold"},
                {"name": "Annual Est.", "style": "white"},
            ],
            box_style=BOX_PRIMARY,
        )

        for a in analyses:
            sigs = ", ".join(a.signals_triggered) if a.signals_triggered else "—"
            tier_map = {
                "MUST": "[bright_red]MUST[/bright_red]",
                "SHOULD": "[bright_yellow]SHOULD[/bright_yellow]",
                "KEEP": "[bright_green]KEEP[/bright_green]",
            }
            tier_str = tier_map.get(a.tier, a.tier)
            table.add_row(
                a.key_id,
                a.metrics.key_state,
                a.metrics.origin,
                sigs,
                tier_str,
                f"${a.annual_cost_estimate:,.2f}",
            )

        console.print()
        console.print(table)
        console.print()
