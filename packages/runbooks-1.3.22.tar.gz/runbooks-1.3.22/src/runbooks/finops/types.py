"""Type definitions for CloudOps & FinOps Runbooks Module."""

from typing import TypedDict

class BudgetInfo(TypedDict):
    """Type for a budget entry."""

    name: str
    limit: float
    actual: float
    forecast: float | None

class CostData(TypedDict):
    """Type for cost data returned from AWS Cost Explorer."""

    account_id: str | None
    current_month: float
    last_month: float
    current_month_cost_by_service: list[dict]
    costs_by_service: dict[str, float]  # Service name to cost mapping for table display
    budgets: list[BudgetInfo]
    current_period_name: str
    previous_period_name: str
    time_range: int | None
    current_period_start: str
    current_period_end: str
    previous_period_start: str
    previous_period_end: str
    monthly_costs: list[tuple[str, float]] | None

class DualMetricResult(TypedDict):
    """Type for dual-metric cost analysis results."""

    unblended_costs: dict[str, float]  # UnblendedCost data (technical perspective)
    amortized_costs: dict[str, float]  # AmortizedCost data (financial perspective)
    technical_total: float  # Total UnblendedCost
    financial_total: float  # Total AmortizedCost
    variance: float  # Absolute difference between metrics
    variance_percentage: float  # Percentage variance
    period_start: str
    period_end: str
    service_breakdown_unblended: list[tuple[str, float]]  # Technical service costs
    service_breakdown_amortized: list[tuple[str, float]]  # Financial service costs

class ProfileData(TypedDict):
    """Type for processed profile data with dual-metric support."""

    profile_name: str  # Updated field name for consistency
    account_id: str
    current_month: float  # Primary metric: UnblendedCost (technical accuracy)
    previous_month: float  # Updated field name for consistency
    current_month_formatted: str  # Formatted display for primary metric
    previous_month_formatted: str  # Formatted display for primary metric
    # Dual-metric architecture foundation
    current_month_amortized: float | None  # Secondary metric: AmortizedCost (financial accuracy)
    previous_month_amortized: float | None  # Secondary metric: AmortizedCost (financial accuracy)
    current_month_amortized_formatted: str | None  # Formatted display for secondary metric
    previous_month_amortized_formatted: str | None  # Formatted display for secondary metric
    metric_context: str | None  # "technical" or "financial" or "dual" context indicator
    service_costs: list[tuple[str, float]]
    service_costs_amortized: list[tuple[str, float]] | None  # AmortizedCost service breakdown
    service_costs_formatted: list[str]
    budget_info: list[str]
    ec2_summary: dict[str, int]
    ec2_summary_formatted: list[str]
    success: bool
    error: str | None
    current_period_name: str
    previous_period_name: str
    percent_change_in_total_cost: float | None

class CLIArgs(TypedDict, total=False):
    """Type for CLI arguments."""

    profiles: list[str] | None
    regions: list[str] | None
    all: bool
    combine: bool
    report_name: str | None
    report_type: list[str] | None
    dir: str | None
    time_range: int | None

RegionName = str
EC2Summary = dict[str, int]
