#!/usr/bin/env python3
"""
GuardDuty Activity Enricher - Threat Detection Activity Signals
===============================================================

Business Value: Surface redundant/misconfigured GuardDuty detectors and unresolved findings.
Strategic Impact: Reduce security debt from ignored CRITICAL findings and coverage gaps.
Integration: Feeds data to FinOps activity health tree (F7 enricher, Order 2).

Activity Signals (GD1-GD7):
- GD1: Detector disabled but still charged — DISABLED status but recent data retained (MUST)
- GD2: Unaddressed CRITICAL findings >30 days old and not archived (MUST)
- GD3: Data-source coverage gap — S3/Kubernetes/Malware Protection disabled (SHOULD)
- GD4: Archived findings >1 year — stale retention review needed (KEEP)
- GD5: Protection plan downgraded — EKS_AUDIT_LOGS or MALWARE_PROTECTION disabled (SHOULD)
- GD6: Trusted-IP list stale — not updated in >180 days (KEEP)
- GD7: Master-member drift — member accounts not fully enabled (KEEP)

Note: GuardDuty/Security Hub may return AccessDenied on non-member account profiles.
handle_permission_denied() catches AccessDenied, UnauthorizedOperation, BadRequestException.

Usage:
    from runbooks.finops.guardduty_activity_enricher import GuardDutyActivityEnricher

    enricher = GuardDutyActivityEnricher(
        operational_profile="my-profile",
        region="ap-southeast-2",
    )
    df = enricher.discover()
    df = enricher.enrich_signals(df)

Author: Runbooks Team
Version: 1.0.0
Epic: FinOps Activity Health Tree (10-enricher sprint, Order 2)
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone, UTC
from enum import Enum
from typing import Any

import pandas as pd
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.profile_utils import create_operational_session
from runbooks.common.rich_utils import BOX_PRIMARY, console, create_table, format_cost
from runbooks.finops.base_enrichers import ActivityEnricherMixin, ActivityTreeBranch  # noqa: F401

logger = logging.getLogger(__name__)

# GuardDuty ClientError codes that indicate permission issues (not bugs)
_PERMISSION_ERROR_CODES = frozenset(
    ("AccessDenied", "UnauthorizedOperation", "BadRequestException", "AccessDeniedException")
)

# ═════════════════════════════════════════════════════════════════════════════
# ENUMERATION TYPES
# ═════════════════════════════════════════════════════════════════════════════

class GuardDutyIdleSignal(str, Enum):
    """GuardDuty idle/misconfiguration decommission signals (GD1-GD7)."""

    GD1 = "GD1: Detector disabled but still billed"
    GD2 = "GD2: Unaddressed CRITICAL findings >30 days"
    GD3 = "GD3: Data-source coverage gap (S3/K8s/Malware)"
    GD4 = "GD4: Archived findings >1 year old"
    GD5 = "GD5: Protection plan downgraded (EKS/Malware)"
    GD6 = "GD6: Trusted-IP list stale (>180 days)"
    GD7 = "GD7: Master-member relationship drift"

# ═════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class GuardDutyDetectorMetrics:
    """Snapshot of a single GuardDuty detector's configuration and findings."""

    detector_id: str
    status: str = "ENABLED"  # ENABLED | DISABLED
    s3_logs_enabled: bool = True
    kubernetes_enabled: bool = False
    malware_protection_enabled: bool = False
    eks_audit_logs_enabled: bool = False
    critical_unarchived_count: int = 0  # severity 8.0-8.9, not archived, >30d
    archived_old_count: int = 0  # archived findings >1 year
    member_drift_count: int = 0  # members with status != ENABLED
    ip_set_stale_count: int = 0  # IPSets not updated in >180d

@dataclass
class GuardDutyActivityAnalysis:
    """Analysis result for a single GuardDuty detector."""

    detector_id: str
    region: str
    account_id: str
    metrics: GuardDutyDetectorMetrics
    signals_triggered: list[str] = field(default_factory=list)
    tier: str = "KEEP"
    annual_cost_estimate: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

# ═════════════════════════════════════════════════════════════════════════════
# CORE ENRICHER
# ═════════════════════════════════════════════════════════════════════════════

class GuardDutyActivityEnricher(ActivityEnricherMixin):
    """
    GuardDuty activity enricher for the FinOps activity health tree.

    Implements ActivityTreeBranch Protocol (discover / enrich_signals / render /
    handle_permission_denied) plus ActivityEnricherMixin boilerplate.

    AWS API Audit (Rule 6):
    [x] Pagination: get_paginator("list_findings"), get_paginator("list_detectors")
        not available directly — ListDetectors is not paginated; ListFindings uses
        paginator. ListMembers uses paginator.
    [x] Retry: Config(retries={"max_attempts": 3, "mode": "adaptive"}) on all clients
    [x] Error visibility: ClientError caught + console.print warning; no silent return None
    [x] Timeout: with_timeout() wraps _discover_inner in render()
    [x] Account name: account_id passed as-is; caller resolves via Organizations

    Important: GuardDuty ListDetectors does not have a paginator; it returns
    all detector IDs in a single call (max 1 per account per region). The
    paginator for list_findings IS available and used.

    Signals:
        GD1 MUST   — detector disabled but still billed
        GD2 MUST   — unaddressed CRITICAL findings >30 days
        GD3 SHOULD — data-source coverage gap
        GD4 KEEP   — archived findings >1 year
        GD5 SHOULD — protection plan downgraded
        GD6 KEEP   — trusted-IP list stale
        GD7 KEEP   — master-member drift
    """

    # ActivityTreeBranch Protocol constants
    service_id: str = "guardduty"
    service_emoji: str = "🛡️"
    service_display_name: str = "GuardDuty"
    priority: int = 60

    def __init__(
        self,
        operational_profile: str,
        region: str | None = None,
        lookback_days: int = 90,
        cache_ttl: int = 300,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            operational_profile=operational_profile,
            region=region,
            lookback_days=lookback_days,
            cache_ttl=cache_ttl,
            **kwargs,
        )
        self._cfg = Config(retries={"max_attempts": 3, "mode": "adaptive"})
        self._session = create_operational_session(operational_profile)
        self._client = self._session.client("guardduty", region_name=self.region, config=self._cfg)
        logger.debug(
            "GuardDutyActivityEnricher init: profile=%s region=%s lookback=%dd",
            operational_profile,
            self.region,
            self.lookback_days,
        )

    # ── Discovery ─────────────────────────────────────────────────────────────

    def discover(self) -> pd.DataFrame:
        """
        List all GuardDuty detectors in the region and collect their metadata.

        Returns one row per detector with columns:
        resource_id, detector_id, region, account_id, status,
        s3_logs_enabled, kubernetes_enabled, malware_protection_enabled,
        eks_audit_logs_enabled.
        """
        rows: list[dict[str, Any]] = []
        try:
            # ListDetectors: max 1 detector per account per region (no paginator needed)
            resp = self._client.list_detectors()
            detector_ids: list[str] = resp.get("DetectorIds", [])

            for det_id in detector_ids:
                try:
                    det = self._client.get_detector(DetectorId=det_id)
                    status = det.get("Status", "ENABLED")
                    ds = det.get("DataSources", {})
                    features = det.get("Features", [])

                    s3_enabled = ds.get("S3Logs", {}).get("Status") == "ENABLED"
                    k8s_enabled = ds.get("Kubernetes", {}).get("AuditLogs", {}).get("Status") == "ENABLED"
                    malware_enabled = (
                        ds.get("MalwareProtection", {}).get("ScanEc2InstanceWithFindings", {}).get("EbsVolumes", False)
                        is True
                    )
                    # Features list (newer API surface)
                    eks_audit = False
                    for feat in features:
                        if feat.get("Name") in ("EKS_AUDIT_LOGS",) and feat.get("Status") == "ENABLED":
                            eks_audit = True

                    rows.append(
                        {
                            "resource_id": det_id,
                            "detector_id": det_id,
                            "region": self.region,
                            "account_id": "",  # caller enriches
                            "status": status,
                            "s3_logs_enabled": s3_enabled,
                            "kubernetes_enabled": k8s_enabled,
                            "malware_protection_enabled": malware_enabled,
                            "eks_audit_logs_enabled": eks_audit,
                        }
                    )
                except ClientError as e:
                    console.print(f"[yellow]Warning: guardduty GetDetector {det_id} failed: {e}[/yellow]")

        except ClientError as e:
            if e.response["Error"]["Code"] in _PERMISSION_ERROR_CODES:
                raise  # re-raise so render() can call handle_permission_denied
            console.print(f"[yellow]Warning: guardduty ListDetectors failed: {e}[/yellow]")
            return pd.DataFrame()

        if not rows:
            return pd.DataFrame(
                columns=[
                    "resource_id",
                    "detector_id",
                    "region",
                    "account_id",
                    "status",
                    "s3_logs_enabled",
                    "kubernetes_enabled",
                    "malware_protection_enabled",
                    "eks_audit_logs_enabled",
                ]
            )
        return pd.DataFrame(rows)

    # ── Signal enrichment ─────────────────────────────────────────────────────

    def enrich_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply GD1-GD7 signal logic to the discovery DataFrame.

        Adds columns: signals_triggered (list[str]), tier (MUST/SHOULD/KEEP),
        annual_cost_estimate (float).
        """
        if df.empty:
            df["signals_triggered"] = pd.Series(dtype=object)
            df["tier"] = pd.Series(dtype=str)
            df["annual_cost_estimate"] = pd.Series(dtype=float)
            return df

        now = datetime.now(UTC)
        signals_list: list[list[str]] = []
        tiers: list[str] = []
        annual_costs: list[float] = []

        for _, row in df.iterrows():
            det_id: str = str(row["detector_id"])
            status: str = str(row.get("status", "ENABLED"))
            signals: list[str] = []

            # GD1: Detector disabled
            if status == "DISABLED":
                signals.append("GD1")

            # GD2: CRITICAL unarchived findings >30 days old
            critical_old = self._count_critical_unarchived_old(det_id, now)
            if critical_old > 0:
                signals.append("GD2")

            # GD3: Data-source coverage gap
            s3_on = bool(row.get("s3_logs_enabled", True))
            if not s3_on:
                signals.append("GD3")

            # GD4: Archived findings >1 year
            archived_old = self._count_archived_old(det_id, now)
            if archived_old > 0:
                signals.append("GD4")

            # GD5: Protection plan downgraded
            eks_on = bool(row.get("eks_audit_logs_enabled", False))
            malware_on = bool(row.get("malware_protection_enabled", False))
            k8s_on = bool(row.get("kubernetes_enabled", False))
            # Flag if EKS audit or malware was previously enabled but is now off
            # v1 simplification: flag if k8s configured but not enabled, or malware not enabled
            # (indicates a plan was possibly downgraded; operator reviews)
            if not eks_on and not malware_on:
                signals.append("GD5")

            # GD6: Trusted-IP list stale
            stale_ipsets = self._count_stale_ipsets(det_id, now)
            if stale_ipsets > 0:
                signals.append("GD6")

            # GD7: Master-member drift
            drift = self._count_member_drift(det_id)
            if drift > 0:
                signals.append("GD7")

            tier = self._classify_tier(signals)
            signals_list.append(signals)
            tiers.append(tier)
            annual_costs.append(0.0)  # GuardDuty pricing is event-volume based; complex estimate

        df = df.copy()
        df["signals_triggered"] = signals_list
        df["tier"] = tiers
        df["annual_cost_estimate"] = annual_costs
        return df

    # ── Render ────────────────────────────────────────────────────────────────

    def render(self, tree: "Any", timeout: int = 15) -> None:
        """Render GuardDuty branch into the supplied Rich Tree node."""
        from rich.text import Text

        try:
            df = self.with_timeout(self._discover_inner, seconds=timeout)
        except TimeoutError:
            label = Text()
            label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
            label.append(f"(timed out after {timeout}s)", style="dim italic yellow")
            tree.add(label)
            return
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code in _PERMISSION_ERROR_CODES:
                self.handle_permission_denied(tree, e)
                return
            raise

        if df is None or df.empty:
            header = Text()
            header.append(f"{self.service_emoji} {self.service_display_name}", style="dim")
            header.append(" — no detectors found", style="dim italic")
            tree.add(header)
            return

        must = df[df["tier"] == "MUST"]
        should = df[df["tier"] == "SHOULD"]
        keep = df[df["tier"] == "KEEP"]

        header_text = Text()
        header_text.append(f"{self.service_emoji} {self.service_display_name}", style="bold cyan")
        header_text.append(f"  {len(df)} detector(s)", style="dim")
        if not must.empty:
            header_text.append(f"  {len(must)} MUST", style="bold red")
        if not should.empty:
            header_text.append(f"  {len(should)} SHOULD", style="bold yellow")
        branch = tree.add(header_text)

        if not must.empty:
            must_node = branch.add(Text("● MUST decommission/fix", style="bold bright_red"))
            for _, row in must.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                label = Text()
                label.append(row["detector_id"], style="red")
                label.append(f"  [{sigs}]", style="dim red")
                must_node.add(label)

        if not should.empty:
            should_node = branch.add(Text("◎ SHOULD review", style="bold yellow"))
            for _, row in should.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                label = Text()
                label.append(row["detector_id"], style="yellow")
                label.append(f"  [{sigs}]", style="dim yellow")
                should_node.add(label)

        if not keep.empty:
            keep_label = Text()
            keep_label.append(f"✓ {len(keep)} detector(s) healthy", style="dim green")
            branch.add(keep_label)

        legend = Text()
        legend.append(
            "GD1:disabled-billed GD2:critical-findings GD3:datasource-gap "
            "GD4:archived>1y GD5:plan-downgraded GD6:ipset-stale GD7:member-drift",
            style="dim italic",
        )
        branch.add(legend)

    def handle_permission_denied(self, tree: "Any", exc: Exception) -> None:
        """Render permission-denied stub when IAM blocks GuardDuty API calls."""
        from rich.text import Text

        label = Text()
        label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
        label.append("(permission denied — check IAM)", style="dim italic yellow")
        tree.add(label)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _discover_inner(self) -> pd.DataFrame:
        """Wrapper for with_timeout: discover + enrich_signals."""
        df = self.discover()
        return self.enrich_signals(df)

    def _classify_tier(self, signals: list[str]) -> str:
        """Return highest-priority tier given triggered signal keys."""
        if any(s in ("GD1", "GD2") for s in signals):
            return "MUST"
        if any(s in ("GD3", "GD5") for s in signals):
            return "SHOULD"
        if signals:  # GD4, GD6, GD7
            return "KEEP"
        return "KEEP"

    def _count_critical_unarchived_old(self, detector_id: str, now: datetime) -> int:
        """
        Count CRITICAL (severity 8.0-8.9) findings that are not archived and older than 30 days.

        Uses ListFindings paginator with severity filter + GetFindings to check archive status.
        """
        cutoff = now - timedelta(days=30)
        count = 0
        try:
            paginator = self._client.get_paginator("list_findings")
            for page in paginator.paginate(
                DetectorId=detector_id,
                FindingCriteria={
                    "Criterion": {
                        "severity": {"Gte": 8, "Lte": 8},
                        "service.archived": {"Eq": ["false"]},
                        "updatedAt": {"Lte": int(cutoff.timestamp() * 1000)},
                    }
                },
            ):
                finding_ids = page.get("FindingIds", [])
                # Batch GetFindings (max 50 per call)
                for i in range(0, len(finding_ids), 50):
                    batch = finding_ids[i : i + 50]
                    try:
                        details = self._client.get_findings(DetectorId=detector_id, FindingIds=batch)
                        for f in details.get("Findings", []):
                            if not f.get("Service", {}).get("Archived", False):
                                count += 1
                    except ClientError as e:
                        console.print(f"[yellow]Warning: guardduty GetFindings batch failed: {e}[/yellow]")
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code not in _PERMISSION_ERROR_CODES:
                console.print(f"[yellow]Warning: guardduty ListFindings (critical) {detector_id} failed: {e}[/yellow]")
        return count

    def _count_archived_old(self, detector_id: str, now: datetime) -> int:
        """Count archived findings created more than 1 year ago."""
        cutoff = now - timedelta(days=365)
        count = 0
        try:
            paginator = self._client.get_paginator("list_findings")
            for page in paginator.paginate(
                DetectorId=detector_id,
                FindingCriteria={
                    "Criterion": {
                        "service.archived": {"Eq": ["true"]},
                        "createdAt": {"Lte": int(cutoff.timestamp() * 1000)},
                    }
                },
            ):
                count += len(page.get("FindingIds", []))
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code not in _PERMISSION_ERROR_CODES:
                console.print(f"[yellow]Warning: guardduty ListFindings (archived) {detector_id} failed: {e}[/yellow]")
        return count

    def _count_stale_ipsets(self, detector_id: str, now: datetime) -> int:
        """Count IPSets that have not been updated in >180 days."""
        stale = 0
        cutoff = now - timedelta(days=180)
        try:
            resp = self._client.list_ip_sets(DetectorId=detector_id)
            for ipset_id in resp.get("IpSetIds", []):
                try:
                    detail = self._client.get_ip_set(DetectorId=detector_id, IpSetId=ipset_id)
                    updated_at = detail.get("UpdatedAt")
                    if updated_at:
                        if updated_at.replace(tzinfo=UTC) < cutoff:
                            stale += 1
                except ClientError as e:
                    console.print(f"[yellow]Warning: guardduty GetIPSet {ipset_id} failed: {e}[/yellow]")
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code not in _PERMISSION_ERROR_CODES:
                console.print(f"[yellow]Warning: guardduty ListIPSets {detector_id} failed: {e}[/yellow]")
        return stale

    def _count_member_drift(self, detector_id: str) -> int:
        """Count member accounts with RelationshipStatus != ENABLED."""
        drift = 0
        try:
            paginator = self._client.get_paginator("list_members")
            for page in paginator.paginate(DetectorId=detector_id):
                for member in page.get("Members", []):
                    if member.get("RelationshipStatus") != "Enabled":
                        drift += 1
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code not in _PERMISSION_ERROR_CODES:
                console.print(f"[yellow]Warning: guardduty ListMembers {detector_id} failed: {e}[/yellow]")
        return drift

    # ── Legacy display helper ─────────────────────────────────────────────────

    def display_analysis(self, analyses: list[GuardDutyActivityAnalysis]) -> None:
        """Display GuardDuty analysis results as a Rich table."""
        if not analyses:
            console.print("[yellow]No GuardDuty analyses to display[/yellow]")
            return

        table = create_table(
            columns=[
                {"name": "Detector ID", "style": "cyan"},
                {"name": "Status", "style": "white"},
                {"name": "Signals", "style": "bright_magenta"},
                {"name": "Tier", "style": "bold"},
            ],
            box_style=BOX_PRIMARY,
        )

        for a in analyses:
            sigs = ", ".join(a.signals_triggered) if a.signals_triggered else "—"
            tier_map = {
                "MUST": "[bright_red]MUST[/bright_red]",
                "SHOULD": "[bright_yellow]SHOULD[/bright_yellow]",
                "KEEP": "[bright_green]KEEP[/bright_green]",
            }
            tier_str = tier_map.get(a.tier, a.tier)
            table.add_row(
                a.detector_id,
                a.metrics.status,
                sigs,
                tier_str,
            )

        console.print()
        console.print(table)
        console.print()
