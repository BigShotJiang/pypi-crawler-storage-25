"""
Vizro FinOps Dashboard — CFO-ready interactive cost visualization.

COS1-01: Multi-channel delivery (CLI + Notebook + Dashboard).
Reads from existing CLI JSON exports or runs CLI subprocess.

Usage:
    runbooks finops vizro --data-file artifacts/finops-exports/org-dashboard-*.json
    runbooks finops vizro --profile $AWS_BILLING_PROFILE

Port: 8050 (distinct from JupyterLab 8888, Docusaurus 3000)
Dependency: vizro>=0.1.46 (analytics extras group in pyproject.toml)
"""

import json
import logging
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# Category keyword map — mirrors scripts/generate_vizro_dashboard.py taxonomy
_CATEGORIES: dict[str, list[str]] = {
    "Compute": ["EC2", "Lambda", "ECS", "EKS", "Fargate", "Lightsail"],
    "Storage": ["S3", "EBS", "EFS", "Glacier", "Backup"],
    "Database": ["RDS", "DynamoDB", "ElastiCache", "Redshift", "Aurora"],
    "Network": ["CloudFront", "VPC", "Route 53", "Direct Connect", "Transit Gateway", "NAT Gateway"],
    "Security": ["WAF", "Shield", "GuardDuty", "Security Hub", "KMS", "Secrets Manager"],
    "Operations": ["CloudWatch", "CloudTrail", "Config", "Systems Manager"],
}

def load_data(data_file: str | None = None, profile: str | None = None) -> dict:
    """Load cost data from JSON file or run CLI subprocess.

    Priority: data_file > profile > latest file in artifacts/finops-exports/

    Args:
        data_file: Path to a pre-exported org-dashboard-*.json file.
        profile: AWS billing profile name for live CLI subprocess.

    Returns:
        Parsed JSON dict matching the org_cost_dashboard export schema.

    Raises:
        FileNotFoundError: When no data source is available.
    """
    if data_file:
        logger.info("Loading data from %s", data_file)
        with open(data_file) as f:
            return json.load(f)

    if profile:
        import tempfile

        output = Path(tempfile.mkdtemp()) / "vizro-data.json"
        result = subprocess.run(
            [
                "runbooks",
                "finops",
                "dashboard",
                "--profile",
                profile,
                "--export",
                "json",
                "--output-file",
                str(output),
                "--timeframe",
                "monthly",
            ],
            capture_output=True,
            text=True,
            timeout=180,
        )
        if result.returncode == 0 and output.exists():
            logger.info("CLI export succeeded: %s", output)
            with open(output) as f:
                return json.load(f)
        logger.error("CLI subprocess failed (rc=%d): %s", result.returncode, result.stderr[:200])

    # Fallback: latest file in artifacts/finops-exports/
    artifacts_dir = Path("artifacts/finops-exports")
    if artifacts_dir.exists():
        candidates = sorted(
            artifacts_dir.glob("org-dashboard-*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if candidates:
            logger.info("Fallback: using %s", candidates[0])
            with open(candidates[0]) as f:
                return json.load(f)

    raise FileNotFoundError(
        "No data source available. Provide --data-file or --profile, "
        "or ensure artifacts/finops-exports/org-dashboard-*.json exists."
    )

def _categorize_service(service_name: str) -> str:
    """Map AWS service name to a FinOps category."""
    lower = service_name.lower()
    for category, keywords in _CATEGORIES.items():
        if any(kw.lower() in lower for kw in keywords):
            return category
    if "tax" in lower:
        return "Tax"
    return "Other"

def _build_dataframes(data: dict) -> tuple:
    """Convert raw JSON export to pandas DataFrames for Vizro.

    Args:
        data: Parsed org_cost_dashboard JSON export.

    Returns:
        Tuple of (df_accounts, df_services, data) where data is passed through
        for access to summary scalars (organization_total, account_count, etc.).
    """
    import pandas as pd

    # Accounts — supports both list-of-dicts and per_account_costs dict shapes
    accounts_raw = data.get("accounts", [])
    per_account = data.get("per_account_costs", {})

    if accounts_raw:
        df_accounts = pd.DataFrame(accounts_raw)
        if "name" not in df_accounts.columns and "id" in df_accounts.columns:
            df_accounts["name"] = df_accounts["id"]
    elif per_account:
        df_accounts = pd.DataFrame([{"name": k, "cost": v} for k, v in per_account.items()])
    else:
        df_accounts = pd.DataFrame(columns=["name", "cost"])

    if not df_accounts.empty and "cost" in df_accounts.columns:
        df_accounts = df_accounts.sort_values("cost", ascending=False)

    # Services
    service_costs = data.get("service_costs", {})
    if isinstance(service_costs, dict) and service_costs:
        df_services = pd.DataFrame([{"service": k, "cost": float(v)} for k, v in service_costs.items()]).sort_values(
            "cost", ascending=False
        )
    else:
        df_services = pd.DataFrame(columns=["service", "cost"])

    if not df_services.empty:
        df_services["category"] = df_services["service"].apply(_categorize_service)

    return df_accounts, df_services, data

_AZURE_CATEGORY_COLORS: dict[str, str] = {
    "Compute": "#00B4FF",
    "Storage": "#FF9222",
    "Security": "#FF5267",
    "Analytics": "#9C27B0",
    "Networking": "#08BDBA",
    "Other": "#FDC935",
}

_AZURE_SERVICE_CATEGORIES: dict[str, list[str]] = {
    "Compute": ["Virtual Machines", "App Service", "Functions", "Container", "AKS", "Batch"],
    "Storage": ["Storage", "Blob", "Disk", "Files", "Archive", "Backup"],
    "Security": ["Sentinel", "Defender", "Security", "Key Vault"],
    "Analytics": ["Log Analytics", "Monitor", "Synapse", "Data Factory", "Stream Analytics"],
    "Networking": ["Virtual Network", "VPN", "Load Balancer", "DNS", "CDN", "Front Door"],
}

def _categorize_azure_service(service_name: str) -> str:
    """Map Azure service name to a FinOps category."""
    lower = service_name.lower()
    for category, keywords in _AZURE_SERVICE_CATEGORIES.items():
        if any(kw.lower() in lower for kw in keywords):
            return category
    return "Other"

def build_page_azure(azure_data: dict) -> "vm.Page":
    """Build a Vizro Page for Azure cost overview.

    Args:
        azure_data: Dict from AzureCostReport.to_vizro_dict() or equivalent shape:
            {subscriptions, services, total_cost_nzd, billing_period, ...}

    Returns:
        vm.Page with KPI cards and horizontal bar charts for subscriptions/services.

    Raises:
        ImportError: If vizro or pandas are not installed.
    """
    try:
        import pandas as pd
        import vizro.models as vm
        import vizro.plotly.express as vpx
    except ImportError:
        raise ImportError("vizro and pandas required: uv sync --group analytics")

    if not azure_data:
        return vm.Page(
            title="Azure Cost Overview",
            components=[vm.Card(text="No Azure data available")],
        )

    total_nzd = azure_data.get("total_cost_nzd", 0.0)
    billing_period = azure_data.get("billing_period", "Unknown")
    total_subs = azure_data.get("total_subscriptions", 0)
    total_svcs = azure_data.get("total_services", 0)

    components = [
        vm.Card(text=f"**Total Spend (NZD)**\n\nNZ${total_nzd:,.0f}"),
        vm.Card(text=f"**Period**\n\n{billing_period}"),
        vm.Card(text=f"**Subscriptions**\n\n{total_subs}"),
        vm.Card(text=f"**Services**\n\n{total_svcs}"),
    ]

    # Subscription bar chart (top 10, ascending for readability)
    subs = azure_data.get("subscriptions", [])
    if subs:
        df_subs = pd.DataFrame(subs[:10]).sort_values("cost_nzd", ascending=True)
        components.append(
            vm.Graph(
                figure=vpx.bar(
                    df_subs,
                    x="cost_nzd",
                    y="subscription_name",
                    orientation="h",
                    title=f"Top Subscriptions — NZ${total_nzd:,.0f} Total",
                    labels={"cost_nzd": "Cost (NZD)", "subscription_name": "Subscription"},
                )
            )
        )

    # Service bar chart (top 10) with category colours
    svcs = azure_data.get("services", [])
    if svcs:
        df_svcs = pd.DataFrame(svcs[:10]).sort_values("cost_nzd", ascending=True)
        df_svcs["category"] = df_svcs["service_name"].apply(_categorize_azure_service)
        components.append(
            vm.Graph(
                figure=vpx.bar(
                    df_svcs,
                    x="cost_nzd",
                    y="service_name",
                    orientation="h",
                    color="category",
                    color_discrete_map=_AZURE_CATEGORY_COLORS,
                    title="Top Services by Category",
                    labels={"cost_nzd": "Cost (NZD)", "service_name": "Service"},
                )
            )
        )

    return vm.Page(title="Azure Cost Overview", components=components)

def launch_dashboard(
    profile: str | None = None,
    data_file: str | None = None,
    port: int = 8050,
    mode: str = "executive",
    azure_data: dict | None = None,
) -> None:
    """Launch the Vizro FinOps dashboard.

    Builds a 3-page interactive dashboard:
    - Page 1: Executive Overview (treemap + KPI cards)
    - Page 2: Account Analysis (horizontal bar, top 20)
    - Page 3: Service Categories (sunburst)

    Args:
        profile: AWS billing profile for live data via CLI subprocess.
        data_file: Path to pre-exported JSON (faster, no AWS call).
        port: HTTP port for the Dash server. Default 8050.
        mode: Persona hint (executive / architect / sre). Reserved for future tab filtering.

    Raises:
        SystemExit: When vizro is not installed or data load fails.
    """
    try:
        import plotly.express as px
        import vizro.models as vm
        import vizro.plotly.express as vpx
        from vizro import Vizro
        from vizro.managers import data_manager
    except ImportError:
        logger.error("vizro not installed")
        sys.exit("vizro not installed. Run: uv sync --group analytics")

    from runbooks.common.rich_utils import console

    try:
        data = load_data(data_file=data_file, profile=profile)
    except FileNotFoundError as exc:
        sys.exit(str(exc))

    df_accounts, df_services, raw = _build_dataframes(data)

    org_total: float = float(raw.get("organization_total", 0))
    if not org_total and not df_services.empty:
        org_total = float(df_services["cost"].sum())

    prev_total: float = float(raw.get("previous_total", 0))
    account_count: int = int(raw.get("account_count", len(df_accounts)))

    # Register DataFrames with Vizro data manager
    data_manager["accounts"] = df_accounts
    data_manager["services"] = df_services

    # --- Page 1: Executive Overview ---
    # Note: Vizro requires wrapped graph functions, but this causes Pydantic validation errors.
    # Simplified to KPI cards only until Vizro integration is fully debugged.
    page_executive = vm.Page(
        title="Executive Overview",
        components=[
            vm.Card(text=f"**Total Spend**\n\n${org_total:,.0f}"),
            vm.Card(text=f"**Previous Month**\n\n${prev_total:,.0f}"),
            vm.Card(text=f"**Accounts**\n\n{account_count}"),
        ],
    )

    # --- Page 2: Account Analysis ---
    page_accounts = vm.Page(
        title="Account Analysis",
        components=[
            vm.Graph(
                figure=vpx.bar(
                    df_accounts.head(20).sort_values("cost", ascending=True) if not df_accounts.empty else df_accounts,
                    x="cost",
                    y="name",
                    orientation="h",
                    title=f"Top 20 Accounts — ${org_total:,.0f} Total",
                )
            )
        ]
        if not df_accounts.empty
        else [vm.Card(text="No account data")],
    )

    # --- Page 3: Service Categories ---
    page_categories = vm.Page(
        title="Service Categories",
        components=[
            vm.Graph(
                figure=vpx.bar(
                    df_services[df_services["cost"] > 0] if not df_services.empty else df_services,
                    x="service",
                    y="cost",
                    color="category",
                    title="Cost by Category and Service",
                )
            )
        ]
        if not df_services.empty
        else [vm.Card(text="No service data")],
    )

    pages = [page_executive, page_accounts, page_categories]
    if azure_data:
        pages.append(build_page_azure(azure_data))

    dashboard = vm.Dashboard(
        title=f"FinOps Cost Dashboard — ${org_total:,.0f}",
        pages=pages,
    )

    console.print(f"[green]Starting Vizro dashboard on http://localhost:{port}[/green]")
    console.print(
        f"[dim]Data: {data_file or 'CLI subprocess'} | Accounts: {account_count} | Total: ${org_total:,.0f}[/dim]"
    )

    Vizro().build(dashboard).run(port=port)
