#!/usr/bin/env python3
"""
Lambda Activity Enricher - Serverless Function Activity Signals
===============================================================

Business Value: Idle Lambda function detection enabling cost optimization.
Strategic Impact: Identify unused serverless functions with provisioned concurrency waste.
Integration: Feeds data to FinOps activity health tree (F3 enricher, Order 2).

Activity Signals (L1-L7):
- L1: Idle >30 days — no invocations in 30-day window (MUST decommission)
- L2: 100% failure rate — all invocations failed with >=10 invocations (MUST)
- L3: Provisioned concurrency idle — utilisation <10% over 7 days (SHOULD)
- L4: Memory over-provisioned — max memory used / configured < 30% (SHOULD)
- L5: Disabled + reserved concurrency — function inactive yet reserves quota (SHOULD)
- L6: DLQ orphan — dead-letter queue set but messages accumulating (KEEP)
- L7: Stale code — last modified >180 days ago (KEEP)

Usage:
    from runbooks.finops.lambda_activity_enricher import LambdaActivityEnricher

    enricher = LambdaActivityEnricher(
        operational_profile="my-profile",
        region="ap-southeast-2",
    )
    df = enricher.discover()
    df = enricher.enrich_signals(df)
    # Then: enricher.render(tree)

Author: Runbooks Team
Version: 1.0.0
Epic: FinOps Activity Health Tree (10-enricher sprint, Order 2)
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone, UTC
from enum import Enum
from typing import Any

import pandas as pd
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.profile_utils import create_operational_session
from runbooks.common.rich_utils import BOX_PRIMARY, console, create_table, format_cost
from runbooks.finops.base_enrichers import ActivityEnricherMixin, ActivityTreeBranch  # noqa: F401

logger = logging.getLogger(__name__)

# ═════════════════════════════════════════════════════════════════════════════
# ENUMERATION TYPES
# ═════════════════════════════════════════════════════════════════════════════

class LambdaIdleSignal(str, Enum):
    """Lambda idle/underutilization decommission signals (L1-L7)."""

    L1 = "L1: No invocations in 30 days"
    L2 = "L2: 100% failure rate (>=10 invocations)"
    L3 = "L3: Provisioned concurrency idle (<10% util, 7d)"
    L4 = "L4: Memory over-provisioned (<30% max-used/configured)"
    L5 = "L5: Disabled function with reserved concurrency"
    L6 = "L6: DLQ orphan (messages accumulating)"
    L7 = "L7: Stale code (last modified >180 days)"

# ═════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class LambdaActivityMetrics:
    """CloudWatch and Lambda API metrics for a single function."""

    invocations_30d: float = 0.0  # Sum of invocations last 30 days
    errors_30d: float = 0.0  # Sum of errors last 30 days
    error_rate: float = 0.0  # errors / invocations (0-1.0)
    prov_concurrency_util_7d: float = 0.0  # avg ProvisionedConcurrencyUtilization last 7d
    max_memory_used_mb: float = 0.0  # peak MaxMemoryUsed metric last 30d
    memory_configured_mb: int = 128  # function MemorySize from config
    memory_utilisation: float = 0.0  # max_memory_used / configured (0-1.0)
    reserved_concurrency: int | None = None
    function_state: str = "Active"  # Active | Inactive | Failed | Pending
    dlq_arn: str | None = None
    dlq_messages: int = 0  # ApproximateNumberOfMessages on DLQ SQS queue
    last_modified_days_ago: int = 0  # days since code was last updated
    has_provisioned_concurrency: bool = False

@dataclass
class LambdaActivityAnalysis:
    """Analysis result for a single Lambda function."""

    function_name: str
    function_arn: str
    runtime: str
    region: str
    account_id: str
    metrics: LambdaActivityMetrics
    signals_triggered: list[str] = field(default_factory=list)
    tier: str = "KEEP"  # MUST / SHOULD / KEEP
    annual_cost_estimate: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

# ═════════════════════════════════════════════════════════════════════════════
# CORE ENRICHER
# ═════════════════════════════════════════════════════════════════════════════

class LambdaActivityEnricher(ActivityEnricherMixin):
    """
    Lambda activity enricher for the FinOps activity health tree.

    Implements ActivityTreeBranch Protocol (discover / enrich_signals / render /
    handle_permission_denied) plus ActivityEnricherMixin boilerplate
    (region, lookback_days, cache_ttl, with_timeout).

    AWS API Audit (Rule 6):
    [x] Pagination: get_paginator("list_functions"), get_paginator("list_event_source_mappings")
    [x] Retry: Config(retries={"max_attempts": 3, "mode": "adaptive"}) on all clients
    [x] Error visibility: ClientError caught + console.print warning; no silent return None
    [x] Timeout: with_timeout() wraps _discover_inner in render()
    [x] Account name: account_id passed as-is; caller resolves via Organizations

    Signals:
        L1 MUST  — no invocations in 30 days
        L2 MUST  — 100% error rate
        L3 SHOULD — provisioned concurrency idle (<10% util, 7d)
        L4 SHOULD — memory over-provisioned (<30% max used / configured)
        L5 SHOULD — inactive function with reserved concurrency slot
        L6 KEEP  — DLQ orphan (messages accumulating)
        L7 KEEP  — stale code (>180d since last modification)
    """

    # ActivityTreeBranch Protocol constants
    service_id: str = "lambda"
    service_emoji: str = "λ"
    service_display_name: str = "AWS Lambda"
    priority: int = 20

    # Signal tier mapping (MUST / SHOULD / KEEP)
    _SIGNAL_TIERS: dict[str, str] = {
        "L1": "MUST",
        "L2": "MUST",
        "L3": "SHOULD",
        "L4": "SHOULD",
        "L5": "SHOULD",
        "L6": "KEEP",
        "L7": "KEEP",
    }

    def __init__(
        self,
        operational_profile: str,
        region: str | None = None,
        lookback_days: int = 90,
        cache_ttl: int = 300,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            operational_profile=operational_profile,
            region=region,
            lookback_days=lookback_days,
            cache_ttl=cache_ttl,
            **kwargs,
        )
        self._cfg = Config(retries={"max_attempts": 3, "mode": "adaptive"})
        self._session = create_operational_session(operational_profile)
        self._client = self._session.client("lambda", region_name=self.region, config=self._cfg)
        self._cw = self._session.client("cloudwatch", region_name=self.region, config=self._cfg)
        self._sqs = self._session.client("sqs", region_name=self.region, config=self._cfg)
        logger.debug(
            "LambdaActivityEnricher init: profile=%s region=%s lookback=%dd",
            operational_profile,
            self.region,
            self.lookback_days,
        )

    # ── Discovery ─────────────────────────────────────────────────────────────

    def discover(self) -> pd.DataFrame:
        """
        Paginate lambda:ListFunctions and return a flat DataFrame.

        Columns: resource_id, function_name, function_arn, runtime,
                 region, account_id, memory_mb, function_state,
                 last_modified_iso, dlq_arn, reserved_concurrency.
        """
        functions: list[dict[str, Any]] = []
        try:
            paginator = self._client.get_paginator("list_functions")
            for page in paginator.paginate():
                for fn in page.get("Functions", []):
                    # Enrich with GetFunctionConcurrency (may 404 if not set)
                    reserved = None
                    try:
                        conc = self._client.get_function_concurrency(FunctionName=fn["FunctionArn"])
                        reserved = conc.get("ReservedConcurrentExecutions")
                    except ClientError as e:
                        code = e.response["Error"]["Code"]
                        if code not in ("ResourceNotFoundException", "TooManyRequestsException"):
                            console.print(
                                f"[yellow]Warning: lambda GetFunctionConcurrency "
                                f"{fn['FunctionName']} failed: {e}[/yellow]"
                            )

                    dlq_arn: str | None = None
                    fn_state = "Active"
                    try:
                        detail = self._client.get_function(FunctionName=fn["FunctionArn"])
                        config = detail.get("Configuration", {})
                        fn_state = config.get("State", "Active")
                        dlq_arn = config.get("DeadLetterConfig", {}).get("TargetArn")
                    except ClientError as e:
                        console.print(f"[yellow]Warning: lambda GetFunction {fn['FunctionName']} failed: {e}[/yellow]")

                    functions.append(
                        {
                            "resource_id": fn["FunctionArn"],
                            "function_name": fn["FunctionName"],
                            "function_arn": fn["FunctionArn"],
                            "runtime": fn.get("Runtime", "unknown"),
                            "region": self.region,
                            "account_id": fn["FunctionArn"].split(":")[4],
                            "memory_mb": fn.get("MemorySize", 128),
                            "function_state": fn_state,
                            "last_modified_iso": fn.get("LastModified", ""),
                            "dlq_arn": dlq_arn,
                            "reserved_concurrency": reserved,
                        }
                    )
        except ClientError as e:
            console.print(f"[yellow]Warning: lambda ListFunctions failed: {e}[/yellow]")
            return pd.DataFrame()

        if not functions:
            return pd.DataFrame(
                columns=[
                    "resource_id",
                    "function_name",
                    "function_arn",
                    "runtime",
                    "region",
                    "account_id",
                    "memory_mb",
                    "function_state",
                    "last_modified_iso",
                    "dlq_arn",
                    "reserved_concurrency",
                ]
            )
        return pd.DataFrame(functions)

    # ── Signal enrichment ─────────────────────────────────────────────────────

    def enrich_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply L1-L7 signal logic to the discovery DataFrame.

        Adds columns: signals_triggered (list[str]), tier (MUST/SHOULD/KEEP),
        annual_cost_estimate (float).
        """
        if df.empty:
            df["signals_triggered"] = pd.Series(dtype=object)
            df["tier"] = pd.Series(dtype=str)
            df["annual_cost_estimate"] = pd.Series(dtype=float)
            return df

        now = datetime.now(UTC)
        signals_list: list[list[str]] = []
        tiers: list[str] = []
        annual_costs: list[float] = []

        for _, row in df.iterrows():
            fn_arn: str = row["function_arn"]
            fn_name: str = row["function_name"]
            memory_mb: int = int(row.get("memory_mb", 128))
            fn_state: str = str(row.get("function_state", "Active"))
            dlq_arn: str | None = row.get("dlq_arn")
            reserved: int | None = row.get("reserved_concurrency")
            last_mod_iso: str = str(row.get("last_modified_iso", ""))

            signals: list[str] = []

            # ── L1: No invocations in 30 days ────────────────────────────────
            invocations_30d = self._get_cw_sum(fn_name, "Invocations", days=30, namespace="AWS/Lambda")
            errors_30d = self._get_cw_sum(fn_name, "Errors", days=30, namespace="AWS/Lambda")
            if invocations_30d == 0.0:
                signals.append("L1")

            # ── L2: 100% failure rate with >=10 invocations ──────────────────
            if invocations_30d >= 10:
                error_rate = errors_30d / invocations_30d if invocations_30d > 0 else 0.0
                if error_rate >= 1.0:
                    signals.append("L2")

            # ── L3: Provisioned concurrency idle (<10% util, 7d) ─────────────
            pcu_util = self._get_cw_avg(fn_name, "ProvisionedConcurrencyUtilization", days=7, namespace="AWS/Lambda")
            if pcu_util is not None and pcu_util < 0.10:
                signals.append("L3")

            # ── L4: Memory over-provisioned (<30% max used / configured) ─────
            max_mem = self._get_cw_max(fn_name, "MaxMemoryUsed", days=30, namespace="AWS/Lambda")
            if max_mem is not None and memory_mb > 0:
                mem_util = max_mem / memory_mb
                if mem_util < 0.30:
                    signals.append("L4")

            # ── L5: Disabled function with reserved concurrency ───────────────
            if fn_state in ("Inactive", "Failed") and reserved is not None and reserved > 0:
                signals.append("L5")

            # ── L6: DLQ orphan (messages accumulating) ────────────────────────
            if dlq_arn and ":sqs:" in dlq_arn:
                msgs = self._get_sqs_message_count(dlq_arn)
                if msgs > 0:
                    signals.append("L6")

            # ── L7: Stale code (>180 days since last modification) ────────────
            if last_mod_iso:
                try:
                    last_mod_dt = datetime.fromisoformat(last_mod_iso.replace("Z", "+00:00").split(".")[0] + "+00:00")
                    days_ago = (now - last_mod_dt).days
                    if days_ago > 180:
                        signals.append("L7")
                except (ValueError, TypeError):
                    pass

            # ── Tier classification ───────────────────────────────────────────
            tier = self._classify_tier(signals)

            # ── Rough cost estimate (requests + GB-s) ─────────────────────────
            # Lambda pricing: $0.20 per 1M requests + $0.0000166667 per GB-s
            # Estimate using invocations and avg duration proxy (256ms default)
            monthly_requests = invocations_30d
            gb_seconds_monthly = (memory_mb / 1024) * 0.256 * monthly_requests
            monthly_cost = (monthly_requests / 1_000_000) * 0.20 + gb_seconds_monthly * 0.0000166667
            annual_cost = monthly_cost * 12

            signals_list.append(signals)
            tiers.append(tier)
            annual_costs.append(annual_cost)

        df = df.copy()
        df["signals_triggered"] = signals_list
        df["tier"] = tiers
        df["annual_cost_estimate"] = annual_costs
        return df

    # ── Render ────────────────────────────────────────────────────────────────

    def render(self, tree: "Any", timeout: int = 15) -> None:  # "Any" avoids circular at runtime
        """
        Render this enricher's branch into the supplied Rich Tree node.

        Groups functions by tier: MUST (red), SHOULD (yellow), KEEP (green dim).
        Uses with_timeout() so a slow account does not stall the full tree.
        """
        from rich.text import Text

        try:
            df = self.with_timeout(self._discover_inner, seconds=timeout)
        except TimeoutError:
            label = Text()
            label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
            label.append(f"(timed out after {timeout}s)", style="dim italic yellow")
            tree.add(label)
            return
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code in ("AccessDenied", "UnauthorizedOperation"):
                self.handle_permission_denied(tree, e)
                return
            raise

        if df is None or df.empty:
            header = Text()
            header.append(f"{self.service_emoji} {self.service_display_name}", style="dim")
            header.append(" — no functions found", style="dim italic")
            tree.add(header)
            return

        # Header node
        must = df[df["tier"] == "MUST"]
        should = df[df["tier"] == "SHOULD"]
        keep = df[df["tier"] == "KEEP"]

        header_text = Text()
        header_text.append(f"{self.service_emoji} {self.service_display_name}", style="bold cyan")
        header_text.append(f"  {len(df)} functions", style="dim")
        if not must.empty:
            header_text.append(f"  {len(must)} MUST", style="bold red")
        if not should.empty:
            header_text.append(f"  {len(should)} SHOULD", style="bold yellow")
        branch = tree.add(header_text)

        # MUST tier group
        if not must.empty:
            must_node = branch.add(Text("● MUST decommission", style="bold bright_red"))
            for _, row in must.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                cost_str = f"${row['annual_cost_estimate']:,.0f}/yr" if row["annual_cost_estimate"] > 0 else ""
                label = Text()
                label.append(row["function_name"], style="red")
                label.append(f"  [{sigs}]", style="dim red")
                if cost_str:
                    label.append(f"  {cost_str}", style="dim")
                must_node.add(label)

        # SHOULD tier group
        if not should.empty:
            should_node = branch.add(Text("◎ SHOULD review", style="bold yellow"))
            for _, row in should.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                label = Text()
                label.append(row["function_name"], style="yellow")
                label.append(f"  [{sigs}]", style="dim yellow")
                should_node.add(label)

        # KEEP tier (summary only)
        if not keep.empty:
            keep_label = Text()
            keep_label.append(f"✓ {len(keep)} functions healthy", style="dim green")
            branch.add(keep_label)

        # Signal legend as leaf
        legend = Text()
        legend.append(
            "L1:idle>30d L2:100%fail L3:prov-concurrency L4:mem-overprovisioned "
            "L5:inactive+reserved L6:DLQ-orphan L7:stale-code",
            style="dim italic",
        )
        branch.add(legend)

    def handle_permission_denied(self, tree: "Any", exc: Exception) -> None:
        """Render permission-denied stub when IAM blocks Lambda API calls."""
        from rich.text import Text

        label = Text()
        label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
        label.append("(permission denied — check IAM)", style="dim italic yellow")
        tree.add(label)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _discover_inner(self) -> pd.DataFrame:
        """Wrapper for with_timeout: discover + enrich_signals."""
        df = self.discover()
        return self.enrich_signals(df)

    def _classify_tier(self, signals: list[str]) -> str:
        """Return highest-priority tier given triggered signal keys."""
        if any(s in ("L1", "L2") for s in signals):
            return "MUST"
        if any(s in ("L3", "L4", "L5") for s in signals):
            return "SHOULD"
        if signals:  # L6, L7
            return "KEEP"
        return "KEEP"

    def _get_cw_sum(
        self,
        function_name: str,
        metric: str,
        days: int,
        namespace: str = "AWS/Lambda",
    ) -> float:
        """Return sum of a CloudWatch metric over [now-days, now]."""
        now = datetime.now(UTC)
        start = now - timedelta(days=days)
        try:
            resp = self._cw.get_metric_statistics(
                Namespace=namespace,
                MetricName=metric,
                Dimensions=[{"Name": "FunctionName", "Value": function_name}],
                StartTime=start,
                EndTime=now,
                Period=days * 86400,
                Statistics=["Sum"],
            )
            datapoints = resp.get("Datapoints", [])
            return sum(dp["Sum"] for dp in datapoints)
        except ClientError as e:
            console.print(
                f"[yellow]Warning: cloudwatch GetMetricStatistics {metric}/{function_name} failed: {e}[/yellow]"
            )
            return 0.0

    def _get_cw_avg(
        self,
        function_name: str,
        metric: str,
        days: int,
        namespace: str = "AWS/Lambda",
    ) -> float | None:
        """Return average of a CloudWatch metric; None if no datapoints."""
        now = datetime.now(UTC)
        start = now - timedelta(days=days)
        try:
            resp = self._cw.get_metric_statistics(
                Namespace=namespace,
                MetricName=metric,
                Dimensions=[{"Name": "FunctionName", "Value": function_name}],
                StartTime=start,
                EndTime=now,
                Period=days * 86400,
                Statistics=["Average"],
            )
            datapoints = resp.get("Datapoints", [])
            if not datapoints:
                return None
            return sum(dp["Average"] for dp in datapoints) / len(datapoints)
        except ClientError as e:
            console.print(
                f"[yellow]Warning: cloudwatch GetMetricStatistics {metric}/{function_name} failed: {e}[/yellow]"
            )
            return None

    def _get_cw_max(
        self,
        function_name: str,
        metric: str,
        days: int,
        namespace: str = "AWS/Lambda",
    ) -> float | None:
        """Return maximum of a CloudWatch metric; None if no datapoints."""
        now = datetime.now(UTC)
        start = now - timedelta(days=days)
        try:
            resp = self._cw.get_metric_statistics(
                Namespace=namespace,
                MetricName=metric,
                Dimensions=[{"Name": "FunctionName", "Value": function_name}],
                StartTime=start,
                EndTime=now,
                Period=days * 86400,
                Statistics=["Maximum"],
            )
            datapoints = resp.get("Datapoints", [])
            if not datapoints:
                return None
            return max(dp["Maximum"] for dp in datapoints)
        except ClientError as e:
            console.print(
                f"[yellow]Warning: cloudwatch GetMetricStatistics {metric}/{function_name} failed: {e}[/yellow]"
            )
            return None

    def _get_sqs_message_count(self, queue_arn: str) -> int:
        """
        Return ApproximateNumberOfMessages for an SQS queue given its ARN.

        ARN format: arn:aws:sqs:{region}:{account}:{queue-name}
        """
        parts = queue_arn.split(":")
        if len(parts) < 6:
            return 0
        queue_name = parts[-1]
        try:
            url_resp = self._sqs.get_queue_url(QueueName=queue_name)
            queue_url = url_resp["QueueUrl"]
            attr_resp = self._sqs.get_queue_attributes(
                QueueUrl=queue_url,
                AttributeNames=["ApproximateNumberOfMessages"],
            )
            return int(attr_resp.get("Attributes", {}).get("ApproximateNumberOfMessages", 0))
        except ClientError as e:
            console.print(f"[yellow]Warning: sqs GetQueueAttributes {queue_name} failed: {e}[/yellow]")
            return 0

    # ── Legacy display helper (matches DynamoDB pattern) ──────────────────────

    def display_analysis(self, analyses: list[LambdaActivityAnalysis]) -> None:
        """
        Display a list of LambdaActivityAnalysis objects as a Rich table.

        Matches display_analysis() pattern from DynamoDBActivityEnricher for API parity.
        """
        if not analyses:
            console.print("[yellow]No Lambda analyses to display[/yellow]")
            return

        table = create_table(
            columns=[
                {"name": "Function", "style": "cyan"},
                {"name": "Runtime", "style": "white"},
                {"name": "Memory MB", "style": "bright_yellow"},
                {"name": "State", "style": "white"},
                {"name": "Signals", "style": "bright_magenta"},
                {"name": "Tier", "style": "bold"},
                {"name": "Annual Est.", "style": "white"},
            ],
            box_style=BOX_PRIMARY,
        )

        for a in analyses:
            sigs = ", ".join(a.signals_triggered) if a.signals_triggered else "—"
            tier_map = {
                "MUST": "[bright_red]MUST[/bright_red]",
                "SHOULD": "[bright_yellow]SHOULD[/bright_yellow]",
                "KEEP": "[bright_green]KEEP[/bright_green]",
            }
            tier_str = tier_map.get(a.tier, a.tier)
            table.add_row(
                a.function_name,
                a.runtime,
                str(a.metrics.memory_configured_mb),
                a.metrics.function_state,
                sigs,
                tier_str,
                f"${a.annual_cost_estimate:,.2f}",
            )

        console.print()
        console.print(table)
        console.print()
