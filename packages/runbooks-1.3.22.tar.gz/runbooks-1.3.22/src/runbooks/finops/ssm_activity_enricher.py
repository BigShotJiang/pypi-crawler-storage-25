#!/usr/bin/env python3
"""
SSM Activity Enricher - Systems Manager Activity Signals
=========================================================

Business Value: Identify idle SSM-managed instances and over-provisioned parameter tiers.
Strategic Impact: Reduce SSM Advanced Parameter Store costs and unmanaged-instance risk.
Integration: Feeds data to FinOps activity health tree (F6 enricher, Order 2).

Activity Signals (SM1-SM7):
- SM1: Instance offline >30 days — last ping older than 30 days (MUST)
- SM2: Unused Advanced parameter — not modified in 365 days + Advanced tier cost ($) (SHOULD)
- SM3: Patch drift — OperationEndTime >90 days ago or rejected patches (SHOULD)
- SM4: Inventory failed — 0 collected types in last 7 days (KEEP)
- SM5: Association noncompliant — recurring Failed association executions (SHOULD)
- SM6: Run-Command failures >50% — >50% failed invocations last 7 days (KEEP)
- SM7: Session zero — no SSM session activity in 90 days for instance (KEEP)

Usage:
    from runbooks.finops.ssm_activity_enricher import SSMActivityEnricher

    enricher = SSMActivityEnricher(
        operational_profile="my-profile",
        region="ap-southeast-2",
    )
    df = enricher.discover()
    df = enricher.enrich_signals(df)

Author: Runbooks Team
Version: 1.0.0
Epic: FinOps Activity Health Tree (10-enricher sprint, Order 2)
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone, UTC
from enum import Enum
from typing import Any

import pandas as pd
from botocore.config import Config
from botocore.exceptions import ClientError

from runbooks.common.profile_utils import create_operational_session
from runbooks.common.rich_utils import BOX_PRIMARY, console, create_table, format_cost
from runbooks.finops.base_enrichers import ActivityEnricherMixin, ActivityTreeBranch  # noqa: F401

logger = logging.getLogger(__name__)

# ═════════════════════════════════════════════════════════════════════════════
# ENUMERATION TYPES
# ═════════════════════════════════════════════════════════════════════════════

class SSMIdleSignal(str, Enum):
    """Systems Manager idle/waste decommission signals (SM1-SM7)."""

    SM1 = "SM1: Instance offline >30 days"
    SM2 = "SM2: Advanced parameter unused >365 days"
    SM3 = "SM3: Patch drift (>90d or rejected patches)"
    SM4 = "SM4: Inventory collection failed (last 7d)"
    SM5 = "SM5: Association recurring failures"
    SM6 = "SM6: Run-Command failure rate >50% (7d)"
    SM7 = "SM7: No SSM sessions in 90 days"

# ═════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class SSMInstanceMetrics:
    """Metrics for a single SSM-managed EC2 instance."""

    instance_id: str
    ping_status: str = "Online"  # Online | ConnectionLost | Inactive | Terminated
    last_ping_days_ago: int = 0  # days since last successful ping
    patch_operation_days_ago: int = 0  # days since last patch scan
    installed_rejected_count: int = 0  # rejected patches
    has_session_history: bool = False  # any session in last 90 days
    last_session_days_ago: int | None = None
    run_cmd_total: int = 0  # run-cmd invocations last 7d
    run_cmd_failed: int = 0  # failed run-cmd invocations last 7d
    association_failed_count: int = 0  # failing associations

@dataclass
class SSMParameterMetrics:
    """Metrics for a single SSM Parameter Store entry."""

    parameter_name: str
    tier: str = "Standard"  # Standard | Advanced | Intelligent-Tiering
    last_modified_days_ago: int = 0  # days since last modification
    annual_cost_estimate: float = 0.0

@dataclass
class SSMActivityAnalysis:
    """Combined analysis result for SSM resources (instances + parameters)."""

    resource_id: str
    resource_type: str  # "instance" | "parameter"
    region: str
    account_id: str
    signals_triggered: list[str] = field(default_factory=list)
    tier: str = "KEEP"
    annual_cost_estimate: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

# ═════════════════════════════════════════════════════════════════════════════
# CORE ENRICHER
# ═════════════════════════════════════════════════════════════════════════════

class SSMActivityEnricher(ActivityEnricherMixin):
    """
    Systems Manager activity enricher for the FinOps activity health tree.

    Implements ActivityTreeBranch Protocol (discover / enrich_signals / render /
    handle_permission_denied) plus ActivityEnricherMixin boilerplate.

    AWS API Audit (Rule 6):
    [x] Pagination: get_paginator for DescribeInstanceInformation, DescribeParameters,
        ListCommandInvocations
    [x] Retry: Config(retries={"max_attempts": 3, "mode": "adaptive"}) on all clients
    [x] Error visibility: ClientError caught + console.print warning; no silent return None
    [x] Timeout: with_timeout() wraps _discover_inner in render()
    [x] Account name: account_id passed as-is; caller resolves via Organizations

    Signals:
        SM1 MUST   — instance offline >30 days
        SM2 SHOULD — Advanced parameter unused >365 days
        SM3 SHOULD — patch drift (>90d or rejected patches)
        SM4 KEEP   — inventory collection failed (last 7d)
        SM5 SHOULD — association recurring failures
        SM6 KEEP   — run-command failure rate >50% (7d)
        SM7 KEEP   — no SSM sessions in 90 days
    """

    # ActivityTreeBranch Protocol constants
    service_id: str = "ssm"
    service_emoji: str = "⚙️"
    service_display_name: str = "Systems Manager"
    priority: int = 50

    # Advanced parameter pricing: $0.05/parameter/month
    _ADVANCED_PARAM_MONTHLY_COST: float = 0.05

    def __init__(
        self,
        operational_profile: str,
        region: str | None = None,
        lookback_days: int = 90,
        cache_ttl: int = 300,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            operational_profile=operational_profile,
            region=region,
            lookback_days=lookback_days,
            cache_ttl=cache_ttl,
            **kwargs,
        )
        self._cfg = Config(retries={"max_attempts": 3, "mode": "adaptive"})
        self._session = create_operational_session(operational_profile)
        self._client = self._session.client("ssm", region_name=self.region, config=self._cfg)
        logger.debug(
            "SSMActivityEnricher init: profile=%s region=%s lookback=%dd",
            operational_profile,
            self.region,
            self.lookback_days,
        )

    # ── Discovery ─────────────────────────────────────────────────────────────

    def discover(self) -> pd.DataFrame:
        """
        Paginate SSM managed instances and parameters into a flat DataFrame.

        Two resource types are returned (resource_type column):
        - "instance": SSM-managed EC2 instances from DescribeInstanceInformation
        - "parameter": Advanced-tier parameters from DescribeParameters

        Columns: resource_id, resource_type, region, account_id,
                 (instance-only) ping_status, last_ping_iso,
                 (parameter-only) param_tier, last_modified_iso.
        """
        rows: list[dict[str, Any]] = []

        # ── Managed instances ─────────────────────────────────────────────────
        try:
            paginator = self._client.get_paginator("describe_instance_information")
            for page in paginator.paginate():
                for inst in page.get("InstanceInformationList", []):
                    rows.append(
                        {
                            "resource_id": inst.get("InstanceId", ""),
                            "resource_type": "instance",
                            "region": self.region,
                            "account_id": "",  # caller enriches
                            "ping_status": inst.get("PingStatus", "Unknown"),
                            "last_ping_iso": inst.get("LastPingDateTime", ""),
                            "param_tier": None,
                            "last_modified_iso": None,
                        }
                    )
        except ClientError as e:
            console.print(f"[yellow]Warning: ssm DescribeInstanceInformation failed: {e}[/yellow]")

        # ── Advanced parameters only (Standard tier is free) ─────────────────
        try:
            paginator = self._client.get_paginator("describe_parameters")
            filters = [{"Key": "Tier", "Values": ["Advanced"]}]
            for page in paginator.paginate(ParameterFilters=filters):
                for param in page.get("Parameters", []):
                    rows.append(
                        {
                            "resource_id": param.get("Name", ""),
                            "resource_type": "parameter",
                            "region": self.region,
                            "account_id": "",
                            "ping_status": None,
                            "last_ping_iso": None,
                            "param_tier": param.get("Tier", "Advanced"),
                            "last_modified_iso": str(param.get("LastModifiedDate", "")),
                        }
                    )
        except ClientError as e:
            console.print(f"[yellow]Warning: ssm DescribeParameters failed: {e}[/yellow]")

        if not rows:
            return pd.DataFrame(
                columns=[
                    "resource_id",
                    "resource_type",
                    "region",
                    "account_id",
                    "ping_status",
                    "last_ping_iso",
                    "param_tier",
                    "last_modified_iso",
                ]
            )
        return pd.DataFrame(rows)

    # ── Signal enrichment ─────────────────────────────────────────────────────

    def enrich_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply SM1-SM7 signal logic to the discovery DataFrame.

        Adds columns: signals_triggered (list[str]), tier (MUST/SHOULD/KEEP),
        annual_cost_estimate (float).
        """
        if df.empty:
            df["signals_triggered"] = pd.Series(dtype=object)
            df["tier"] = pd.Series(dtype=str)
            df["annual_cost_estimate"] = pd.Series(dtype=float)
            return df

        now = datetime.now(UTC)
        signals_list: list[list[str]] = []
        tiers: list[str] = []
        annual_costs: list[float] = []

        for _, row in df.iterrows():
            resource_id: str = str(row["resource_id"])
            resource_type: str = str(row.get("resource_type", "instance"))
            signals: list[str] = []
            annual_cost = 0.0

            if resource_type == "instance":
                signals, annual_cost = self._enrich_instance(row, now, resource_id)
            elif resource_type == "parameter":
                signals, annual_cost = self._enrich_parameter(row, now)

            tier = self._classify_tier(signals)
            signals_list.append(signals)
            tiers.append(tier)
            annual_costs.append(annual_cost)

        df = df.copy()
        df["signals_triggered"] = signals_list
        df["tier"] = tiers
        df["annual_cost_estimate"] = annual_costs
        return df

    def _enrich_instance(self, row: pd.Series, now: datetime, instance_id: str) -> tuple[list[str], float]:
        """Apply SM1, SM3, SM4, SM5, SM6, SM7 to a single managed instance."""
        signals: list[str] = []

        # SM1: Offline >30 days
        last_ping_iso: str = str(row.get("last_ping_iso", ""))
        last_ping_days = self._days_ago(last_ping_iso, now)
        if last_ping_days is not None and last_ping_days > 30:
            signals.append("SM1")

        # SM3: Patch drift
        try:
            patch_resp = self._client.describe_instance_patch_states(InstanceIds=[instance_id])
            for ps in patch_resp.get("InstancePatchStates", []):
                op_end = ps.get("OperationEndTime")
                if op_end:
                    days_since_patch = (now - op_end.replace(tzinfo=UTC)).days
                    if days_since_patch > 90:
                        signals.append("SM3")
                if ps.get("InstalledRejectedCount", 0) > 0:
                    if "SM3" not in signals:
                        signals.append("SM3")
        except ClientError as e:
            console.print(f"[yellow]Warning: ssm DescribeInstancePatchStates {instance_id} failed: {e}[/yellow]")

        # SM5: Association noncompliant (recurring failures)
        try:
            assoc_resp = self._client.describe_association_executions(
                Filters=[
                    {"Key": "Status", "Values": ["Failed"]},
                    {"Key": "CreatedTimeCutoff", "Value": (now - timedelta(days=7)).isoformat()},
                ]
            )
            if assoc_resp.get("AssociationExecutions"):
                signals.append("SM5")
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code not in ("AssociationDoesNotExist",):
                console.print(f"[yellow]Warning: ssm DescribeAssociationExecutions failed: {e}[/yellow]")

        # SM6: Run-Command failure rate >50% (last 7d)
        try:
            paginator = self._client.get_paginator("list_command_invocations")
            total = 0
            failed = 0
            cutoff = now - timedelta(days=7)
            for page in paginator.paginate(Filters=[{"key": "InvokedAfter", "value": cutoff.isoformat()}]):
                for inv in page.get("CommandInvocations", []):
                    if inv.get("InstanceId") == instance_id:
                        total += 1
                        if inv.get("Status") == "Failed":
                            failed += 1
            if total > 0 and (failed / total) > 0.50:
                signals.append("SM6")
        except ClientError as e:
            console.print(f"[yellow]Warning: ssm ListCommandInvocations failed: {e}[/yellow]")

        # SM7: No SSM sessions in 90 days
        try:
            session_resp = self._client.describe_sessions(
                State="History",
                Filters=[{"key": "Target", "value": instance_id}],
            )
            sessions = session_resp.get("Sessions", [])
            recent = False
            for sess in sessions:
                end_dt = sess.get("EndDate")
                if end_dt:
                    days = (now - end_dt.replace(tzinfo=UTC)).days
                    if days <= 90:
                        recent = True
                        break
            if not recent:
                signals.append("SM7")
        except ClientError as e:
            console.print(f"[yellow]Warning: ssm DescribeSessions {instance_id} failed: {e}[/yellow]")

        return signals, 0.0  # instance SSM management cost is per instance-hour (complex); 0 placeholder

    def _enrich_parameter(self, row: pd.Series, now: datetime) -> tuple[list[str], float]:
        """Apply SM2 to a single Advanced parameter."""
        signals: list[str] = []

        last_mod_iso: str = str(row.get("last_modified_iso", ""))
        days_ago = self._days_ago(last_mod_iso, now)
        if days_ago is not None and days_ago > 365:
            signals.append("SM2")

        # Advanced tier: $0.05/month per parameter
        annual_cost = self._ADVANCED_PARAM_MONTHLY_COST * 12
        return signals, annual_cost

    # ── Render ────────────────────────────────────────────────────────────────

    def render(self, tree: "Any", timeout: int = 15) -> None:
        """Render Systems Manager branch into the supplied Rich Tree node."""
        from rich.text import Text

        try:
            df = self.with_timeout(self._discover_inner, seconds=timeout)
        except TimeoutError:
            label = Text()
            label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
            label.append(f"(timed out after {timeout}s)", style="dim italic yellow")
            tree.add(label)
            return
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code in ("AccessDenied", "UnauthorizedOperation"):
                self.handle_permission_denied(tree, e)
                return
            raise

        if df is None or df.empty:
            header = Text()
            header.append(f"{self.service_emoji} {self.service_display_name}", style="dim")
            header.append(" — no SSM resources found", style="dim italic")
            tree.add(header)
            return

        must = df[df["tier"] == "MUST"]
        should = df[df["tier"] == "SHOULD"]
        keep = df[df["tier"] == "KEEP"]

        header_text = Text()
        header_text.append(f"{self.service_emoji} {self.service_display_name}", style="bold cyan")
        header_text.append(f"  {len(df)} resources", style="dim")
        if not must.empty:
            header_text.append(f"  {len(must)} MUST", style="bold red")
        if not should.empty:
            header_text.append(f"  {len(should)} SHOULD", style="bold yellow")
        branch = tree.add(header_text)

        if not must.empty:
            must_node = branch.add(Text("● MUST decommission", style="bold bright_red"))
            for _, row in must.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                label = Text()
                label.append(str(row["resource_id"]), style="red")
                label.append(f"  [{row['resource_type']}]", style="dim")
                label.append(f"  [{sigs}]", style="dim red")
                must_node.add(label)

        if not should.empty:
            should_node = branch.add(Text("◎ SHOULD review", style="bold yellow"))
            for _, row in should.iterrows():
                sigs = ", ".join(row["signals_triggered"])
                label = Text()
                label.append(str(row["resource_id"]), style="yellow")
                label.append(f"  [{row['resource_type']}] [{sigs}]", style="dim yellow")
                should_node.add(label)

        if not keep.empty:
            keep_label = Text()
            keep_label.append(f"✓ {len(keep)} resources healthy", style="dim green")
            branch.add(keep_label)

        legend = Text()
        legend.append(
            "SM1:offline>30d SM2:adv-param-unused SM3:patch-drift "
            "SM4:inventory-fail SM5:assoc-fail SM6:runcmd-fail>50% SM7:no-sessions",
            style="dim italic",
        )
        branch.add(legend)

    def handle_permission_denied(self, tree: "Any", exc: Exception) -> None:
        """Render permission-denied stub when IAM blocks SSM API calls."""
        from rich.text import Text

        label = Text()
        label.append(f"{self.service_emoji} {self.service_display_name} ", style="dim")
        label.append("(permission denied — check IAM)", style="dim italic yellow")
        tree.add(label)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _discover_inner(self) -> pd.DataFrame:
        """Wrapper for with_timeout: discover + enrich_signals."""
        df = self.discover()
        return self.enrich_signals(df)

    def _classify_tier(self, signals: list[str]) -> str:
        """Return highest-priority tier given triggered signal keys."""
        if "SM1" in signals:
            return "MUST"
        if any(s in ("SM2", "SM3", "SM5") for s in signals):
            return "SHOULD"
        if signals:  # SM4, SM6, SM7
            return "KEEP"
        return "KEEP"

    def _days_ago(self, iso_str: str, now: datetime) -> int | None:
        """Parse an ISO-8601 or boto3-datetime string and return days since then."""
        if not iso_str or iso_str in ("None", ""):
            return None
        try:
            # boto3 may return datetime objects stored as str via .isoformat()
            iso_clean = str(iso_str).replace("Z", "+00:00")
            dt = datetime.fromisoformat(iso_clean)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return (now - dt).days
        except (ValueError, TypeError):
            return None

    # ── Legacy display helper ─────────────────────────────────────────────────

    def display_analysis(self, analyses: list[SSMActivityAnalysis]) -> None:
        """Display SSM analysis results as a Rich table."""
        if not analyses:
            console.print("[yellow]No SSM analyses to display[/yellow]")
            return

        table = create_table(
            columns=[
                {"name": "Resource ID", "style": "cyan"},
                {"name": "Type", "style": "white"},
                {"name": "Signals", "style": "bright_magenta"},
                {"name": "Tier", "style": "bold"},
                {"name": "Annual Est.", "style": "white"},
            ],
            box_style=BOX_PRIMARY,
        )

        for a in analyses:
            sigs = ", ".join(a.signals_triggered) if a.signals_triggered else "—"
            tier_map = {
                "MUST": "[bright_red]MUST[/bright_red]",
                "SHOULD": "[bright_yellow]SHOULD[/bright_yellow]",
                "KEEP": "[bright_green]KEEP[/bright_green]",
            }
            tier_str = tier_map.get(a.tier, a.tier)
            table.add_row(
                a.resource_id,
                a.resource_type,
                sigs,
                tier_str,
                f"${a.annual_cost_estimate:,.2f}",
            )

        console.print()
        console.print(table)
        console.print()
