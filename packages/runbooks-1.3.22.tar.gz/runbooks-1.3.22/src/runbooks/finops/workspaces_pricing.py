"""WorkSpaces bundle pricing — strict YAML loader.

Pricing data lives in data/workspaces_pricing.yaml. This module raises RuntimeError
at import if the YAML is missing or malformed — loud failure is intentional (opposite
of G5 regression that silenced FileNotFoundError and returned $35 for every bundle).

Public API:
    calculate_workspace_monthly_cost(bundle_type: str, running_mode: str) -> float
"""

import logging
import pathlib

import yaml

logger = logging.getLogger(__name__)

_PRICING_YAML = pathlib.Path(__file__).parent / "data" / "workspaces_pricing.yaml"
# Used ONLY for unknown bundle TYPE at call-time. NEVER for missing YAML.
_FALLBACK_MONTHLY_USD = 45.0  # Standard bundle price — used when ComputeTypeName is unrecognised

def _load_pricing() -> dict[str, dict]:
    """Strict YAML load. Raises RuntimeError if missing or malformed."""
    if not _PRICING_YAML.exists():
        raise RuntimeError(
            f"WorkSpaces pricing SSOT missing: {_PRICING_YAML}. "
            "This is a configuration error — pricing data must not be hardcoded. "
            "Restore data/workspaces_pricing.yaml to fix."
        )
    try:
        with open(_PRICING_YAML, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        bundles = data.get("bundles", {}) if isinstance(data, dict) else {}
        if not bundles or not isinstance(bundles, dict):
            raise RuntimeError(f"YAML at {_PRICING_YAML} has empty or invalid 'bundles' section")
        return bundles
    except yaml.YAMLError as exc:
        raise RuntimeError(f"Failed to parse {_PRICING_YAML}: {exc}") from exc

_BUNDLE_PRICES: dict[str, dict] = _load_pricing()

def calculate_workspace_monthly_cost(bundle_type: str, running_mode: str) -> float:
    """Return monthly cost (USD) for an AWS WorkSpace bundle type.

    Args:
        bundle_type: AWS Compute enum (uppercase) from boto3 WorkspaceProperties.ComputeTypeName.
                     Examples: VALUE, STANDARD, PERFORMANCE, POWER, POWERPRO, GRAPHICS_G4DN.
        running_mode: ALWAYS_ON or AUTO_STOP (informational; monthly_cost_usd is the floor
                      for both modes; AUTO_STOP adds per-hour usage charges on top).

    Returns:
        Monthly cost USD. Returns STANDARD bundle price ($45) with a warning for unknown
        bundle_type values. Raises RuntimeError at module import if YAML is missing.
    """
    from runbooks.common.rich_utils import print_warning

    if not bundle_type:
        return _FALLBACK_MONTHLY_USD

    key = bundle_type.upper().strip()
    info = _BUNDLE_PRICES.get(key)

    if info is None:
        print_warning(
            f"Unknown WorkSpaces ComputeTypeName '{bundle_type}'; "
            f"using Standard fallback ${_FALLBACK_MONTHLY_USD:.1f}/month. "
            f"Add this bundle type to {_PRICING_YAML.name} to suppress this warning."
        )
        return _FALLBACK_MONTHLY_USD

    monthly = float(info.get("monthly_cost_usd", _FALLBACK_MONTHLY_USD))
    if monthly == 0.0:
        # GRAPHICS (deprecated/unavailable) has monthly_cost_usd: 0.0 intentionally
        print_warning(
            f"WorkSpaces bundle '{bundle_type}' has $0 pricing in YAML "
            f"(deprecated or unavailable in this region). "
            f"Using Standard fallback ${_FALLBACK_MONTHLY_USD:.1f}/month."
        )
        return _FALLBACK_MONTHLY_USD

    return monthly
