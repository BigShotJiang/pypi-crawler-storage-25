"""
Azure FinOps HTML Dashboard — CDN Plotly, dark GitHub theme.

Pure function: no file I/O, no network, no Azure SDK calls.
The CLI wrapper (finops_azure.py) handles file output.

FOCUS 1.3 aligned | Portal CSV SSOT pattern
"""

from __future__ import annotations

import json
from collections import defaultdict

# Vizro-aligned cost tier colors (WCAG AAA)
_TIER_COLORS = {"HIGH": "#7B0000", "MEDIUM": "#E85A00", "LOW": "#D4C4A8"}

# Vizro service category colors
_CAT_COLORS = {
    "Compute": "#00B4FF",
    "Storage": "#FF9222",
    "Security": "#FF5267",
    "Analytics": "#9C27B0",
    "Networking": "#08BDBA",
    "Other": "#FDC935",
}

def generate_dashboard_html(
    subscriptions: list[dict],
    services: list[dict],
    total_nzd: float,
    budget_nzd: float,
    billing_period: str,
    daily_rate: float = 0.0,
    advisor_actions: list[dict] | None = None,
    prior_month_daily_rate: float = 0.0,
    days_in_month: int = 30,
    billing_period_start: str = "",
    billing_period_end: str = "",
) -> str:
    """
    Generate an Azure FinOps HTML dashboard as a self-contained string.

    Args:
        subscriptions: List of dicts with keys: name (str), cost (float), tier (str).
                       tier must be one of: HIGH, MEDIUM, LOW.
        services:      List of dicts with keys: name (str), cost (float), cat (str).
                       cat must be one of: Compute, Storage, Security, Analytics, Networking, Other.
        total_nzd:     Total spend in NZD for the billing period.
        budget_nzd:    Monthly budget in NZD.
        billing_period: Human-readable label, e.g. "February 2026" or "2026-03".
        daily_rate:    Average daily spend. Computed from total/days_in_month if 0.
        advisor_actions: Optional list of Azure Advisor recommendations.
                         Each dict: action, yearly_nzd, impact, subscription, source, verify, caveat.
        prior_month_daily_rate: Prior month average daily spend in NZD. Used for MoM KPI.
                                Defaults to 0.0 (falls back to budget variance display).
        days_in_month: Actual number of days in the billing month. Used for daily rate
                       calculation. Defaults to 30.
        billing_period_start: ISO date string for period start, e.g. "2026-03-01".
                              When provided (with billing_period_end), a CxO verification
                              section is rendered with reproduce commands. Defaults to "".
        billing_period_end:   ISO date string for period end, e.g. "2026-03-31".
                              Must be provided together with billing_period_start.
                              Defaults to "".

    Returns:
        HTML string. No file I/O performed.
    """
    if advisor_actions is None:
        advisor_actions = []

    # Auto-detect actual days from billing_period when caller uses default
    if days_in_month == 30 and billing_period:
        from runbooks.finops.azure.types import parse_billing_period_to_days

        days_in_month = parse_billing_period_to_days(billing_period)

    if daily_rate == 0.0 and total_nzd > 0:
        daily_rate = total_nzd / days_in_month

    budget_under = budget_nzd - total_nzd
    budget_pct = (budget_under / budget_nzd * 100) if budget_nzd > 0 else 0.0
    budget_status = "WITHIN BUDGET" if budget_under >= 0 else "OVER BUDGET"
    budget_badge_class = "badge-ok" if budget_under >= 0 else "badge-risk"

    positive_subs = sorted([s for s in subscriptions if s["cost"] > 0], key=lambda s: s["cost"], reverse=True)
    top3_cost = sum(s["cost"] for s in positive_subs[:3])
    top3_pct = (top3_cost / total_nzd * 100) if total_nzd > 0 else 0.0
    active_subs = len(positive_subs)
    active_svcs = len([s for s in services if s["cost"] > 0])

    # Category aggregation for donut chart
    cats: dict[str, float] = defaultdict(float)
    for s in services:
        cats[s["cat"]] += s["cost"]
    cat_names = list(cats.keys())
    cat_costs = list(cats.values())
    cat_colors_list = [_CAT_COLORS.get(c, "#FDC935") for c in cat_names]

    sub_names = [s["name"].split("(")[0].strip() for s in positive_subs]
    sub_costs = [s["cost"] for s in positive_subs]
    sub_colors = [_TIER_COLORS.get(s["tier"], "#D4C4A8") for s in positive_subs]

    svc_top10 = sorted([s for s in services if s["cost"] > 0], key=lambda s: s["cost"], reverse=True)[:10]
    svc_names = [s["name"] for s in svc_top10]
    svc_costs = [s["cost"] for s in svc_top10]
    svc_colors = [_CAT_COLORS.get(s["cat"], "#FDC935") for s in svc_top10]

    advisor_rows = "".join(
        f"<tr><td>{i + 1}</td><td>{a['action']}</td>"
        f"<td>{'High' if a.get('impact') == 'High' else 'Low'}</td>"
        f"<td>NZ${a.get('yearly_nzd', 0):,}/yr</td>"
        f"<td>{a.get('subscription', '')}</td>"
        f'<td style="font-size:11px;color:#8b949e">{a.get("source", "")}</td>'
        f'<td style="font-size:11px;color:#58a6ff">{a.get("verify", "")}</td>'
        f'<td style="font-size:11px;color:#d29922">{a.get("caveat", "")}</td></tr>'
        for i, a in enumerate(advisor_actions)
    )

    reproduce_section = ""
    if billing_period_start and billing_period_end:
        reproduce_section = f"""
    <div class="charts">
        <div class="chart-card full-width">
            <h3>How to Reproduce (CxO Verification)</h3>
            <p style="font-size:13px; line-height:1.8">
            <strong>1. Azure Portal (manual):</strong> Cost Management &gt; Cost Analysis &gt; Date: {billing_period_start} to {billing_period_end} &gt; Group by: Subscription / Service Name<br>
            <strong>2. runbooks CLI (automated):</strong> <code>uv run runbooks finops azure monthly --start-date {billing_period_start} --end-date {billing_period_end} --all-subscriptions --mode cfo --budget {budget_nzd:.0f}</code><br>
            <strong>3. Claude command (orchestrated):</strong> <code>/finops:azure-monthly {billing_period}</code><br>
            <strong>4. Dashboard:</strong> <code>uv run runbooks finops azure dashboard --month {billing_period} --budget {budget_nzd:.0f} --subscriptions-csv &lt;portal-csv-subs&gt; --services-csv &lt;portal-csv-svcs&gt;</code>
            </p>
        </div>
    </div>"""

    advisor_section = ""
    if advisor_actions:
        advisor_section = f"""
    <div class="charts">
        <div class="chart-card full-width">
            <h3>Azure Advisor Recommendations (SSOT — not estimates)</h3>
            <table class="advisor-table">
                <thead><tr><th>#</th><th>Recommendation</th><th>Impact</th><th>Yearly Saving</th><th>Subscription</th><th>Source</th><th>Verify</th><th>Caveat</th></tr></thead>
                <tbody>{advisor_rows}</tbody>
            </table>
        </div>
    </div>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Azure FinOps Dashboard \u2014 {billing_period}</title>
    <script src="https://cdn.plot.ly/plotly-2.32.0.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0d1117; color: #c9d1d9; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 24px 32px; border-bottom: 2px solid #0078d4; }}
        .header h1 {{ font-size: 24px; color: #fff; }}
        .header .subtitle {{ color: #8b949e; margin-top: 4px; font-size: 14px; }}
        .kpi-row {{ display: grid; grid-template-columns: repeat(6, 1fr); gap: 16px; padding: 20px 32px; }}
        .kpi {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; text-align: center; }}
        .kpi .value {{ font-size: 28px; font-weight: 700; color: #58a6ff; }}
        .kpi .label {{ font-size: 12px; color: #8b949e; margin-top: 4px; text-transform: uppercase; }}
        .kpi.green .value {{ color: #3fb950; }}
        .kpi.red .value {{ color: #f85149; }}
        .kpi.amber .value {{ color: #d29922; }}
        .charts {{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 0 32px 20px; }}
        .chart-card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; }}
        .chart-card h3 {{ font-size: 16px; color: #c9d1d9; margin-bottom: 12px; }}
        .full-width {{ grid-column: 1 / -1; }}
        .badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }}
        .badge-ok {{ background: #238636; color: #fff; }}
        .badge-risk {{ background: #da3633; color: #fff; }}
        .footer {{ text-align: center; padding: 16px; color: #484f58; font-size: 12px; }}
        .advisor-table {{ width: 100%; border-collapse: collapse; margin-top: 12px; }}
        .advisor-table th, .advisor-table td {{ padding: 8px 10px; text-align: left; border-bottom: 1px solid #30363d; font-size: 12px; }}
        .advisor-table th {{ color: #8b949e; font-weight: 600; font-size: 11px; }}
        .risk-banner {{ background: #3d1f1f; border: 1px solid #f85149; border-radius: 8px; padding: 16px; margin: 0 32px 20px; }}
        .risk-banner h3 {{ color: #f85149; margin-bottom: 8px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Azure FinOps Dashboard \u2014 {billing_period}</h1>
        <div class="subtitle">
            SSOT: Azure Portal CSV + Azure Advisor | Total: NZ${total_nzd:,.2f}
            <span class="badge {budget_badge_class}">{budget_status}</span>
            &nbsp;|&nbsp; FOCUS 1.3 &nbsp;|&nbsp; {active_subs} subscription(s)
        </div>
    </div>

    <div class="kpi-row">
        <div class="kpi"><div class="value">NZ${total_nzd:,.0f}</div><div class="label">Total Spend</div></div>
        {
        (
            f'<div class="kpi {"green" if (daily_rate - prior_month_daily_rate) / prior_month_daily_rate * 100 <= 0 else "red"}">'
            f'<div class="value">{((daily_rate - prior_month_daily_rate) / prior_month_daily_rate * 100):+.1f}%</div>'
            f'<div class="label">Daily MoM</div></div>'
        )
        if prior_month_daily_rate > 0
        else (
            f'<div class="kpi {"green" if budget_under >= 0 else "red"}">'
            f'<div class="value">NZ${abs(budget_under):,.0f}</div>'
            f'<div class="label">{"Under" if budget_under >= 0 else "Over"} Budget ({abs(budget_pct):.1f}%)</div></div>'
        )
    }
        <div class="kpi"><div class="value">NZ${daily_rate:,.0f}</div><div class="label">Daily Rate</div></div>
        <div class="kpi {"red" if top3_pct > 80 else "amber"}">
            <div class="value">{top3_pct:.0f}%</div>
            <div class="label">Top 3 Concentration</div>
        </div>
        <div class="kpi"><div class="value">{active_subs}</div><div class="label">Active Subscriptions</div></div>
        <div class="kpi"><div class="value">{active_svcs}</div><div class="label">Services</div></div>
    </div>

    {
        (
            lambda conc: (
                f'''<div class="risk-banner">
        <h3>Cost Concentration ({len(conc)} subscription{"s" if len(conc) != 1 else ""} above 30%)</h3>
        <ul style="margin:8px 0 0 20px;font-size:13px;line-height:1.8">
        {"".join(f"<li><strong>{s['name'].split('(')[0].strip()}</strong> — NZ${s['cost']:,.0f}/mo ({s['cost'] / total_nzd * 100:.1f}% of total)</li>" for s in conc)}
        </ul>
        <p style="font-size:13px;margin-top:8px">Review cost optimization and workload distribution for subscriptions exceeding 30% of total spend.</p>
    </div>'''
                if conc
                else ""
            )
        )([s for s in positive_subs if total_nzd > 0 and s["cost"] / total_nzd > 0.30])
    }

    <div class="charts">
        <div class="chart-card">
            <h3>Cost by Subscription (Portal CSV)</h3>
            <div id="sub-chart"></div>
        </div>
        <div class="chart-card">
            <h3>Top 10 Services (Portal CSV)</h3>
            <div id="svc-chart"></div>
        </div>
        <div class="chart-card">
            <h3>Cost by Service Category</h3>
            <div id="cat-chart"></div>
        </div>
        <div class="chart-card">
            <h3>Budget Gauge \u2014 NZ${budget_nzd:,.0f}</h3>
            <div id="gauge-chart"></div>
        </div>
    </div>
    {reproduce_section}
    {advisor_section}
    <div class="footer">
        Portal CSV SSOT + Azure Advisor | FOCUS 1.3 | {billing_period} |
        Budget: NZ${budget_nzd:,.0f} | Generated by runbooks finops azure dashboard
    </div>

    <script>
        const darkLayout = {{
            paper_bgcolor: '#161b22', plot_bgcolor: '#161b22',
            font: {{ color: '#c9d1d9', family: '-apple-system, sans-serif' }},
            margin: {{ t: 10, b: 40, l: 200, r: 20 }}
        }};

        Plotly.newPlot('sub-chart', [{{
            type: 'bar', orientation: 'h',
            y: {json.dumps(sub_names[::-1])},
            x: {json.dumps(sub_costs[::-1])},
            marker: {{ color: {json.dumps(sub_colors[::-1])} }},
            text: {json.dumps([f"NZ${c:,.0f}" for c in sub_costs[::-1]])},
            textposition: 'outside',
            hovertemplate: '%{{y}}: NZ$%{{x:,.2f}}<extra></extra>'
        }}], {{...darkLayout, height: 340, xaxis: {{ title: 'Cost (NZD)', gridcolor: '#21262d' }}}});

        Plotly.newPlot('svc-chart', [{{
            type: 'bar', orientation: 'h',
            y: {json.dumps(svc_names[::-1])},
            x: {json.dumps(svc_costs[::-1])},
            marker: {{ color: {json.dumps(svc_colors[::-1])} }},
            text: {json.dumps([f"NZ${c:,.0f}" for c in svc_costs[::-1]])},
            textposition: 'outside',
            hovertemplate: '%{{y}}: NZ$%{{x:,.2f}}<extra></extra>'
        }}], {{...darkLayout, height: 340, xaxis: {{ title: 'Cost (NZD)', gridcolor: '#21262d' }}}});

        Plotly.newPlot('cat-chart', [{{
            type: 'pie',
            labels: {json.dumps(cat_names)},
            values: {json.dumps([round(c, 2) for c in cat_costs])},
            marker: {{ colors: {json.dumps(cat_colors_list)} }},
            textinfo: 'label+percent', textfont: {{ color: '#fff' }}, hole: 0.4,
            hovertemplate: '%{{label}}: NZ$%{{value:,.2f}} (%{{percent}})<extra></extra>'
        }}], {{...darkLayout, height: 280, margin: {{ t: 10, b: 10, l: 10, r: 10 }}}});

        Plotly.newPlot('gauge-chart', [{{
            type: 'indicator', mode: 'gauge+number+delta',
            value: {total_nzd},
            number: {{ prefix: 'NZ$', valueformat: ',.0f' }},
            delta: {{ reference: {
        budget_nzd
    }, valueformat: ',.0f', prefix: 'NZ$', decreasing: {{ color: '#3fb950' }} }},
            gauge: {{
                axis: {{ range: [0, {budget_nzd * 1.25:.0f}], tickprefix: 'NZ$', tickformat: ',.0f' }},
                bar: {{ color: '#3fb950' }},
                bgcolor: '#21262d',
                steps: [
                    {{ range: [0, {budget_nzd * 0.9:.0f}], color: '#238636' }},
                    {{ range: [{budget_nzd * 0.9:.0f}, {budget_nzd * 1.1:.0f}], color: '#9e6a03' }},
                    {{ range: [{budget_nzd * 1.1:.0f}, {budget_nzd * 1.25:.0f}], color: '#da3633' }}
                ],
                threshold: {{ line: {{ color: '#58a6ff', width: 3 }}, value: {budget_nzd} }}
            }}
        }}], {{...darkLayout, height: 280, margin: {{ t: 30, b: 10, l: 40, r: 50 }}}});
    </script>
</body>
</html>"""
    return html
