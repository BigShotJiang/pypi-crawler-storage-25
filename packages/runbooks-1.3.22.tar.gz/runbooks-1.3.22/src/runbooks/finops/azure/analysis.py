"""
Azure FinOps Analysis Module - Cross-Validation, Accuracy, Trends, Anomalies

Consolidates analysis logic from azure-monthly.md command into testable functions.
Follows ADLC v3.0.0 thin wrapper architecture pattern.

v1.0.0 (2026-01-20):
- cross_validate_sources() - 3-way validation (REST/CLI/MCP)
- calculate_accuracy() - 4-component accuracy formula
- analyze_trends() - MoM/YoY trend analysis
- detect_anomalies() - Cost spike/drop detection

Architecture:
- API is ALWAYS authoritative (v2.3.0 lesson)
- ground_truth_override = False (ALWAYS)
- Portal CSV is validation cross-check ONLY

Framework: ADLC v3.0.0 | Version: 1.0.0
"""

import json
import logging
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from runbooks.finops.azure.types import parse_billing_period_to_days

try:
    from dateutil.relativedelta import relativedelta
except ImportError:
    # Fallback for environments without dateutil
    relativedelta = None

# =============================================================================
# Cross-Validation Functions
# =============================================================================

def calculate_variance(ground_truth: float, comparison: float) -> dict[str, Any]:
    """
    Calculate variance between ground truth and comparison values.

    Args:
        ground_truth: The authoritative value (REST API)
        comparison: The value to compare against

    Returns:
        Dictionary with amount, percentage, and status (PASS/WARN/FAIL)
    """
    if ground_truth == 0:
        return {
            "amount": abs(comparison),
            "percentage": 100.0 if comparison != 0 else 0.0,
            "status": "FAIL" if comparison != 0 else "PASS",
        }

    var_amt = abs(ground_truth - comparison)
    var_pct = (var_amt / ground_truth) * 100
    status = "PASS" if var_pct <= 1.0 else "WARN" if var_pct <= 5.0 else "FAIL"

    return {
        "amount": round(var_amt, 2),
        "percentage": round(var_pct, 4),
        "status": status,
    }

def cross_validate_sources(
    rest_total: float,
    cli_total: float = 0.0,
    mcp_total: float = 0.0,
    cli_status: str = "available",
    mcp_status: str = "pending",
    billing_period: str = "",
) -> dict[str, Any]:
    """
    Perform 3-way cross-validation between REST API, CLI, and MCP sources.

    Args:
        rest_total: Total from REST API (ground truth)
        cli_total: Total from CLI
        mcp_total: Total from MCP server
        cli_status: Status of CLI query
        mcp_status: Status of MCP query
        billing_period: The billing period being validated

    Returns:
        Validation report with sources, variances, and overall status
    """
    rest_vs_cli = calculate_variance(rest_total, cli_total)
    rest_vs_mcp = (
        calculate_variance(rest_total, mcp_total)
        if mcp_status == "available"
        else {"amount": 0, "percentage": 0, "status": "N/A"}
    )

    # Determine overall status
    overall_status = "PASS"
    if rest_vs_cli["status"] == "FAIL" or rest_vs_mcp["status"] == "FAIL":
        overall_status = "FAIL"
    elif rest_vs_cli["status"] == "WARN" or rest_vs_mcp["status"] == "WARN":
        overall_status = "WARN"

    return {
        "generated_at": datetime.now().isoformat(),
        "billing_period": billing_period,
        "version": "3.1.0",
        "validation_sources": {
            "primary": {
                "name": "Azure REST API",
                "total_nzd": rest_total,
                "status": "available",
                "note": "Ground truth source",
            },
            "secondary": {
                "name": "runbooks CLI",
                "total_nzd": cli_total,
                "status": cli_status,
                "note": "Known subscription context bug - only returns first context",
            },
            "tertiary": {
                "name": "MCP Server",
                "total_nzd": mcp_total,
                "status": mcp_status,
                "note": "Query request pending execution" if mcp_status == "pending" else "",
            },
        },
        "variances": {
            "rest_vs_cli": rest_vs_cli,
            "rest_vs_mcp": rest_vs_mcp,
        },
        "overall_status": overall_status,
        "recommendation": "Use REST API as authoritative source",
        "threshold": "≤1% variance for PASS",
    }

# =============================================================================
# Accuracy Calculation
# =============================================================================

def calculate_accuracy(
    rest_total: float,
    rest_subs: int,
    subscriptions: list[dict[str, Any]],
    cli_total: float = 0.0,
    cli_subs: int = 0,
    billing_period: str = "",
) -> dict[str, Any]:
    """
    Calculate 4-component accuracy score.

    Components:
    - Cost Value Match (40%): REST API vs expected
    - Subscription Coverage (30%): Subscriptions with data
    - Service Name Match (20%): Services discovered
    - FOCUS Compliance (10%): FOCUS 1.3 columns implemented

    Args:
        rest_total: Total cost from REST API
        rest_subs: Number of subscriptions with cost
        subscriptions: List of subscription data
        cli_total: Total from CLI (for variance calculation)
        cli_subs: Number of subscriptions from CLI
        billing_period: The billing period

    Returns:
        Accuracy report with component scores and overall accuracy
    """
    # 4-Component Accuracy Formula
    cost_match = 1.0  # REST API is ground truth
    sub_match = rest_subs / len(subscriptions) if subscriptions else 0.0
    service_count = sum(len(s.get("top_services", [])) for s in subscriptions)
    service_match = 1.0 if service_count > 0 else 0.0
    focus_match = min(37 / 28, 1.0)  # 37 columns implemented / 28 required

    overall = 0.40 * cost_match + 0.30 * sub_match + 0.20 * service_match + 0.10 * focus_match
    status = "PASS" if overall >= 0.995 else "FAIL"

    return {
        "generated_at": datetime.now().isoformat(),
        "billing_period": billing_period,
        "ground_truth": {
            "source": "Azure REST API",
            "total_cost_nzd": rest_total,
            "subscriptions_with_cost": rest_subs,
            "subscriptions_accessible": len(subscriptions),
        },
        "cli_result": {
            "source": "runbooks CLI",
            "total_cost_nzd": cli_total,
            "subscriptions_with_cost": cli_subs,
            "note": "KNOWN BUG: Only returns first subscription context",
        },
        "variance": {
            "cli_amount_nzd": abs(rest_total - cli_total),
            "cli_percentage": round(abs(rest_total - cli_total) / rest_total * 100, 2) if rest_total > 0 else 0,
        },
        "accuracy_components": {
            "cost_value_match": {"weight": "40%", "score": f"{cost_match * 100:.2f}%"},
            "subscription_coverage": {"weight": "30%", "score": f"{sub_match * 100:.2f}%"},
            "service_name_match": {"weight": "20%", "score": f"{service_match * 100:.2f}%"},
            "focus_compliance": {"weight": "10%", "score": f"{focus_match * 100:.2f}%"},
        },
        "overall_accuracy": f"{overall * 100:.2f}%",
        "target": "99.5%",
        "status": status,
    }

# =============================================================================
# Trend Analysis
# =============================================================================

def load_historical_cost(data_base: Path, period: str) -> float | None:
    """
    Load cost from historical archive.

    Args:
        data_base: Base path for data files (e.g., data/finops/azure)
        period: The period to load (e.g., "2025-11")

    Returns:
        Cost value if found, None otherwise
    """
    cost_file = data_base / period / "cost-summary.json"
    if cost_file.exists():
        try:
            data = json.load(open(cost_file))
            return data.get("total_nzd", data.get("total", 0))
        except (json.JSONDecodeError, KeyError):
            pass
    return None

def analyze_trends(
    current_total: float,
    billing_period: str,
    data_base: Path,
) -> dict[str, Any]:
    """
    Analyze MoM and YoY trends.

    Args:
        current_total: Current period's total cost
        billing_period: Current billing period (e.g., "2025-12")
        data_base: Base path for historical data

    Returns:
        Trend analysis with MoM, YoY, and 12-month history
    """
    if relativedelta is None:
        return {
            "error": "dateutil not installed",
            "mom_change_pct": None,
            "yoy_change_pct": None,
            "twelve_month_history": [],
        }

    # Parse current period
    current_date = datetime.strptime(billing_period, "%Y-%m")
    prev_month = (current_date - relativedelta(months=1)).strftime("%Y-%m")
    same_month_last_year = (current_date - relativedelta(years=1)).strftime("%Y-%m")

    # Load historical data
    prev_cost = load_historical_cost(data_base, prev_month)
    yoy_cost = load_historical_cost(data_base, same_month_last_year)

    # Calculate MoM change
    mom_change_pct = None
    mom_change_abs = None
    if prev_cost is not None and prev_cost > 0:
        mom_change_abs = current_total - prev_cost
        mom_change_pct = round((mom_change_abs / prev_cost) * 100, 2)

    # Daily-normalized MoM — corrects for month-length differences (Feb=28, Mar=31)
    days_current = parse_billing_period_to_days(billing_period)
    days_prev = parse_billing_period_to_days(prev_month)
    daily_current = current_total / days_current if days_current > 0 else 0.0
    daily_prev = (prev_cost / days_prev) if (prev_cost is not None and days_prev > 0) else None
    daily_normalized_mom_pct = round(((daily_current - daily_prev) / daily_prev) * 100, 2) if daily_prev else None

    # Calculate YoY change
    yoy_change_pct = None
    yoy_change_abs = None
    if yoy_cost is not None and yoy_cost > 0:
        yoy_change_abs = current_total - yoy_cost
        yoy_change_pct = round((yoy_change_abs / yoy_cost) * 100, 2)

    # Load 12-month history
    twelve_months = []
    for i in range(12):
        period = (current_date - relativedelta(months=i)).strftime("%Y-%m")
        cost = load_historical_cost(data_base, period)
        if cost is not None:
            twelve_months.append({"period": period, "cost": cost})

    return {
        "mom_change_pct": mom_change_pct,
        "mom_change_abs": mom_change_abs,
        "previous_period": prev_month,
        "previous_total": prev_cost,
        "daily_normalized_mom_pct": daily_normalized_mom_pct,
        "days_in_current_month": days_current,
        "days_in_previous_month": days_prev,
        "daily_cost_current": daily_current,
        "daily_cost_previous": daily_prev,
        "yoy_change_pct": yoy_change_pct,
        "yoy_change_abs": yoy_change_abs,
        "same_month_last_year": same_month_last_year,
        "yoy_total": yoy_cost,
        "twelve_month_history": twelve_months,
    }

# =============================================================================
# Anomaly Detection
# =============================================================================

# Default thresholds for anomaly detection
DEFAULT_THRESHOLDS = {
    "mom_alert": 20.0,  # >20% MoM increase = Alert
    "mom_warning": 10.0,  # >10% MoM increase = Warning
    "yoy_alert": 50.0,  # >50% YoY increase = Alert
    "yoy_warning": 25.0,  # >25% YoY increase = Warning
    "subscription_spike": 30.0,  # >30% subscription concentration = Alert
}

def detect_anomalies(
    current_total: float,
    trends: dict[str, Any],
    subscriptions: list[dict[str, Any]],
    billing_period: str,
    thresholds: dict[str, float] | None = None,
) -> dict[str, Any]:
    """
    Detect cost anomalies based on trends and thresholds.

    Args:
        current_total: Current period's total cost
        trends: Trend analysis from analyze_trends()
        subscriptions: List of subscription data
        billing_period: Current billing period
        thresholds: Custom thresholds (uses defaults if not provided)

    Returns:
        Anomaly report with detected anomalies and severity
    """
    thresholds = thresholds or DEFAULT_THRESHOLDS
    anomalies = []

    # Check MoM anomaly
    mom_pct = trends.get("mom_change_pct")
    if mom_pct is not None:
        if mom_pct > thresholds["mom_alert"]:
            anomalies.append(
                {
                    "type": "MoM Spike",
                    "severity": "ALERT",
                    "metric": f"+{mom_pct:.1f}%",
                    "threshold": f">{thresholds['mom_alert']}%",
                    "description": f"Month-over-month cost increased by {mom_pct:.1f}%",
                }
            )
        elif mom_pct > thresholds["mom_warning"]:
            anomalies.append(
                {
                    "type": "MoM Increase",
                    "severity": "WARNING",
                    "metric": f"+{mom_pct:.1f}%",
                    "threshold": f">{thresholds['mom_warning']}%",
                    "description": f"Month-over-month cost increased by {mom_pct:.1f}%",
                }
            )
        elif mom_pct < -thresholds["mom_warning"]:
            anomalies.append(
                {
                    "type": "MoM Drop",
                    "severity": "INFO",
                    "metric": f"{mom_pct:.1f}%",
                    "threshold": f"<-{thresholds['mom_warning']}%",
                    "description": f"Month-over-month cost decreased by {abs(mom_pct):.1f}%",
                }
            )

    # Check YoY anomaly
    yoy_pct = trends.get("yoy_change_pct")
    if yoy_pct is not None:
        if yoy_pct > thresholds["yoy_alert"]:
            anomalies.append(
                {
                    "type": "YoY Spike",
                    "severity": "ALERT",
                    "metric": f"+{yoy_pct:.1f}%",
                    "threshold": f">{thresholds['yoy_alert']}%",
                    "description": f"Year-over-year cost increased by {yoy_pct:.1f}%",
                }
            )
        elif yoy_pct > thresholds["yoy_warning"]:
            anomalies.append(
                {
                    "type": "YoY Increase",
                    "severity": "WARNING",
                    "metric": f"+{yoy_pct:.1f}%",
                    "threshold": f">{thresholds['yoy_warning']}%",
                    "description": f"Year-over-year cost increased by {yoy_pct:.1f}%",
                }
            )

    # Check subscription-level anomalies
    for sub in subscriptions:
        sub_pct = sub.get("percentage", 0)
        if sub_pct > thresholds["subscription_spike"]:
            anomalies.append(
                {
                    "type": "Subscription Concentration",
                    "severity": "WARNING",
                    "subscription": sub.get("name", "Unknown"),
                    "metric": f"{sub_pct:.1f}% of total",
                    "threshold": f">{thresholds['subscription_spike']}%",
                    "description": f"{sub.get('name', 'Unknown')} represents {sub_pct:.1f}% of total spend",
                }
            )

    # Determine overall status
    if any(a["severity"] == "ALERT" for a in anomalies):
        overall_status = "ALERT"
    elif any(a["severity"] == "WARNING" for a in anomalies):
        overall_status = "WARNING"
    else:
        overall_status = "OK"

    return {
        "generated_at": datetime.now().isoformat(),
        "billing_period": billing_period,
        "version": "3.1.0",
        "total_cost_nzd": current_total,
        "thresholds": thresholds,
        "anomalies_detected": len(anomalies),
        "anomalies": anomalies,
        "status": overall_status,
    }

# =============================================================================
# 4-Way Cross-Validation Orchestrator
# =============================================================================

_SUBPROCESS_TIMEOUT = 30  # seconds for CLI source

def _query_rest_api_source(
    billing_period: str,
    subscription_id: str | None,
) -> dict[str, Any]:
    """Query REST API source via AzureCostClient.get_cost_summary()."""
    try:
        # Parse YYYY-MM into start/end dates for LastMonth or custom
        from datetime import date as _date

        from runbooks.finops.azure.client import AzureCostClient

        year, month = int(billing_period[:4]), int(billing_period[5:7])
        import calendar

        last_day = calendar.monthrange(year, month)[1]
        start = _date(year, month, 1)
        end = _date(year, month, last_day)

        client = AzureCostClient(subscription_id=subscription_id)
        cost_data = client.get_cost_summary(
            timeframe="Custom",
            include_subscriptions=True,
            start_date=start,
            end_date=end,
        )
        total_nzd = float(cost_data.get("total_cost_nzd", 0.0))
        return {"total_nzd": total_nzd, "status": "success", "error": None}
    except Exception as exc:  # noqa: BLE001
        logger.debug("REST API source failed: %s", exc)
        return {"total_nzd": 0.0, "status": "failed", "error": str(exc)}

def _query_cli_source(billing_period: str, subscription_id: str | None) -> dict[str, Any]:
    """Query Azure CLI cost management independently via subprocess."""
    try:
        import calendar

        year, month = int(billing_period[:4]), int(billing_period[5:7])
        last_day = calendar.monthrange(year, month)[1]
        start_str = f"{billing_period}-01"
        end_str = f"{billing_period}-{last_day:02d}"

        scope = f"/subscriptions/{subscription_id}" if subscription_id else None

        # Build query body JSON inline
        query_body = json.dumps(
            {
                "type": "ActualCost",
                "timeframe": "Custom",
                "timePeriod": {
                    "from": f"{start_str}T00:00:00Z",
                    "to": f"{end_str}T23:59:59Z",
                },
                "dataset": {
                    "granularity": "None",
                    "aggregation": {"totalCost": {"name": "Cost", "function": "Sum"}},
                },
            }
        )

        cmd = [
            "az",
            "costmanagement",
            "query",
            "--type",
            "ActualCost",
            "--dataset-aggregation",
            "totalCost={name:Cost,function:Sum}",
            "--timeframe",
            "Custom",
            "--time-period",
            f"from={start_str}T00:00:00Z to={end_str}T23:59:59Z",
        ]
        if scope:
            cmd += ["--scope", scope]

        # Simpler: use `az rest` with POST to Cost Management Query API
        if scope:
            uri = f"https://management.azure.com{scope}/providers/Microsoft.CostManagement/query?api-version=2023-11-01"
        else:
            # Fall back to account-level scope resolution
            acct_result = subprocess.run(
                ["az", "account", "show", "--query", "id", "-o", "tsv"],
                capture_output=True,
                text=True,
                timeout=_SUBPROCESS_TIMEOUT,
            )
            if acct_result.returncode != 0 or not acct_result.stdout.strip():
                return {
                    "total_nzd": 0.0,
                    "status": "failed",
                    "error": "Could not resolve default subscription ID",
                }
            resolved_id = acct_result.stdout.strip()
            uri = f"https://management.azure.com/subscriptions/{resolved_id}/providers/Microsoft.CostManagement/query?api-version=2023-11-01"

        result = subprocess.run(
            ["az", "rest", "--method", "POST", "--uri", uri, "--body", query_body],
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT,
        )

        if result.returncode != 0:
            return {
                "total_nzd": 0.0,
                "status": "failed",
                "error": result.stderr.strip() or "az rest returned non-zero",
            }

        data = json.loads(result.stdout)
        # Cost Management Query API returns rows: [[cost, currency, ...], ...]
        rows = data.get("properties", {}).get("rows", [])
        total = float(rows[0][0]) if rows else 0.0
        return {"total_nzd": total, "status": "success", "error": None}

    except subprocess.TimeoutExpired:
        return {"total_nzd": 0.0, "status": "failed", "error": f"CLI timed out after {_SUBPROCESS_TIMEOUT}s"}
    except (json.JSONDecodeError, KeyError, IndexError, ValueError) as exc:
        logger.debug("CLI source parse error: %s", exc)
        return {"total_nzd": 0.0, "status": "failed", "error": f"Parse error: {exc}"}
    except Exception as exc:  # noqa: BLE001
        logger.debug("CLI source failed: %s", exc)
        return {"total_nzd": 0.0, "status": "failed", "error": str(exc)}

def _query_csv_source(portal_csv_path: Path | None) -> dict[str, Any]:
    """Load portal CSV source via load_azure_subscriptions_csv()."""
    if portal_csv_path is None:
        return {"total_nzd": 0.0, "status": "skipped", "error": "No portal_csv_path provided"}
    try:
        from runbooks.finops.azure.cost_processor import load_azure_subscriptions_csv

        _rows, total_nzd, _total_usd = load_azure_subscriptions_csv(portal_csv_path)
        return {"total_nzd": float(total_nzd), "status": "success", "error": None}
    except FileNotFoundError:
        return {"total_nzd": 0.0, "status": "failed", "error": f"File not found: {portal_csv_path}"}
    except Exception as exc:  # noqa: BLE001
        logger.debug("CSV source failed: %s", exc)
        return {"total_nzd": 0.0, "status": "failed", "error": str(exc)}

def _compute_variance_matrix(sources: dict[str, dict[str, Any]]) -> dict[str, float]:
    """
    Compute pairwise variance percentage for successful source pairs.

    Variance = abs(a - b) / max(a, b) * 100.
    Returns empty dict entry (None) when either source is not successful.
    """
    pairs = [
        ("rest_vs_cli", "rest_api", "cli"),
        ("rest_vs_csv", "rest_api", "portal_csv"),
        ("cli_vs_csv", "cli", "portal_csv"),
    ]
    matrix: dict[str, float] = {}
    for key, src_a, src_b in pairs:
        a_info = sources[src_a]
        b_info = sources[src_b]
        if a_info["status"] == "success" and b_info["status"] == "success":
            a, b = a_info["total_nzd"], b_info["total_nzd"]
            denom = max(abs(a), abs(b))
            pct = round(abs(a - b) / denom * 100, 4) if denom > 0 else 0.0
            matrix[key] = pct
        else:
            matrix[key] = None  # type: ignore[assignment]
    return matrix

def execute_cross_validation(
    billing_period: str,
    subscription_id: str | None = None,
    portal_csv_path: Path | None = None,
    config: Any | None = None,  # AzureReportConfig — forward ref kept as Any
) -> dict[str, Any]:
    """
    Execute 4-way cross-validation by querying 4 independent sources.

    Sources:
    1. REST API — via AzureCostClient.get_cost_summary()
    2. CLI — via subprocess `az rest` POST to Cost Management Query API
    3. Portal CSV — via load_azure_subscriptions_csv() (skipped if path not provided)
    4. MCP — placeholder (always skipped; future integration)

    Args:
        billing_period: Billing month in YYYY-MM format (e.g., "2026-03")
        subscription_id: Optional Azure subscription ID to scope queries
        portal_csv_path: Optional path to Portal CSV export for V3 source
        config: Optional AzureReportConfig (reserved for future use)

    Returns:
        Dict with billing_period, timestamp, per-source results, variance matrix,
        sources_available count, max_variance_pct, overall_status, and accuracy_pct.

    Overall status thresholds:
        PASS  — max variance < 5 %
        WARN  — max variance < 10 % (or only 1 source available)
        FAIL  — max variance >= 10 %
    """
    timestamp = datetime.now().isoformat()

    # --- Query each source independently ---
    rest_result = _query_rest_api_source(billing_period, subscription_id)
    cli_result = _query_cli_source(billing_period, subscription_id)
    csv_result = _query_csv_source(portal_csv_path)
    mcp_result: dict[str, Any] = {
        "total_nzd": 0.0,
        "status": "skipped",
        "error": "MCP server not available in CLI context",
    }

    sources = {
        "rest_api": rest_result,
        "cli": cli_result,
        "portal_csv": csv_result,
        "mcp": mcp_result,
    }

    # --- Variance matrix ---
    variance_matrix = _compute_variance_matrix(sources)

    # --- Aggregate metrics ---
    sources_available = sum(1 for s in sources.values() if s["status"] == "success")
    computed_variances = [v for v in variance_matrix.values() if v is not None]
    max_variance_pct = max(computed_variances) if computed_variances else 0.0

    # --- Overall status ---
    if sources_available <= 1:
        overall_status = "WARN"
    elif max_variance_pct >= 10.0:
        overall_status = "FAIL"
    elif max_variance_pct >= 5.0:
        overall_status = "WARN"
    else:
        overall_status = "PASS"

    # --- Accuracy: average of (100 - variance) across computed pairs ---
    if computed_variances:
        accuracy_pct = round(sum(100.0 - v for v in computed_variances) / len(computed_variances), 4)
    else:
        accuracy_pct = 100.0 if sources_available == 1 else 0.0

    # --- Per-subscription reconciliation (AC-1 to AC-3) ---
    # Only computed when portal_csv_path is provided and CSV source succeeded.
    subscription_reconciliation: list[dict[str, Any]] = []
    if portal_csv_path is not None and csv_result["status"] == "success":
        try:
            import calendar as _calendar

            from runbooks.finops.azure.cost_processor import load_azure_subscriptions_csv

            # --- V1: Aggregate CSV rows by subscription name ---
            csv_rows, _csv_total, _csv_usd = load_azure_subscriptions_csv(portal_csv_path)
            csv_by_name: dict[str, float] = {}
            for row in csv_rows:
                name = row["subscription_name"]
                csv_by_name[name] = csv_by_name.get(name, 0.0) + row["cost_nzd"]

            # --- V2: Fetch per-subscription costs from REST API ---
            api_by_name: dict[str, float] = {}
            try:
                from runbooks.finops.azure.client import AzureCostClient

                _year, _month = int(billing_period[:4]), int(billing_period[5:7])
                _last_day = _calendar.monthrange(_year, _month)[1]
                from datetime import date as _date

                _start = _date(_year, _month, 1)
                _end = _date(_year, _month, _last_day)
                _client = AzureCostClient(subscription_id=subscription_id)
                _sub_costs = _client.query_by_subscription(timeframe="Custom", start_date=_start, end_date=_end)
                api_by_name = {s["subscription_name"]: s["cost_nzd"] for s in _sub_costs}
            except Exception as _api_exc:  # noqa: BLE001
                logger.debug("Per-subscription REST API query failed: %s", _api_exc)

            # --- Build reconciliation entries ---
            _mismatch_threshold = 5.0  # >5% variance = MISMATCH (consistent with overall PASS/WARN threshold)
            for sub_name, csv_cost in sorted(csv_by_name.items()):
                api_cost = api_by_name.get(sub_name)
                if api_cost is None:
                    # Subscription present in CSV but not returned by API — RBAC gap
                    subscription_reconciliation.append(
                        {
                            "name": sub_name,
                            "csv_cost": round(csv_cost, 4),
                            "api_cost": None,
                            "variance_pct": None,
                            "status": "RBAC_INVISIBLE",
                            "rbac_invisible": True,
                        }
                    )
                else:
                    denom = max(abs(csv_cost), abs(api_cost))
                    variance_pct = round(abs(csv_cost - api_cost) / denom * 100, 4) if denom > 0 else 0.0
                    status = "MATCH" if variance_pct <= _mismatch_threshold else "MISMATCH"
                    subscription_reconciliation.append(
                        {
                            "name": sub_name,
                            "csv_cost": round(csv_cost, 4),
                            "api_cost": round(api_cost, 4),
                            "variance_pct": variance_pct,
                            "status": status,
                            "rbac_invisible": False,
                        }
                    )

            # API subscriptions not seen in CSV are not flagged (API may have RBAC-visible subs with zero portal export)

        except Exception as _recon_exc:  # noqa: BLE001
            logger.debug("Per-subscription reconciliation failed: %s", _recon_exc)

    # Coverage analysis: compare API-visible subs vs Portal CSV subs
    api_sub_count = len([r for r in subscription_reconciliation if r.get("api_cost_nzd") is not None])
    csv_sub_count = len([r for r in subscription_reconciliation if r.get("csv_cost_nzd", 0) > 0])
    coverage_pct = round((api_sub_count / csv_sub_count * 100) if csv_sub_count > 0 else 100.0, 1)
    coverage_status = "PASS" if coverage_pct >= 95.0 else "WARN_RBAC_SCOPED"

    return {
        "billing_period": billing_period,
        "timestamp": timestamp,
        "sources": sources,
        "variance_matrix": variance_matrix,
        "sources_available": sources_available,
        "sources_total": 4,
        "max_variance_pct": round(max_variance_pct, 4),
        "overall_status": overall_status,
        "accuracy_pct": accuracy_pct,
        "subscription_reconciliation": subscription_reconciliation,
        "coverage": {
            "api_subscriptions": api_sub_count,
            "csv_subscriptions": csv_sub_count,
            "coverage_pct": coverage_pct,
            "status": coverage_status,
            "note": "Portal CSV is SSOT (EA billing). API is RBAC-scoped." if coverage_pct < 95 else "",
        },
    }

# =============================================================================
# Cost Summary Generator
# =============================================================================

def get_exchange_rate() -> tuple[float, str]:
    """
    Fetch current NZD to USD exchange rate with fallback.

    Returns:
        Tuple of (rate, source) where source is "live" or "cached fallback"
    """
    import urllib.error
    import urllib.request

    try:
        # Primary: exchangerate.host API (free, no key required)
        url = "https://api.exchangerate.host/latest?base=NZD&symbols=USD"
        with urllib.request.urlopen(url, timeout=5) as response:  # nosec B310
            data = json.load(response)
            rate = data.get("rates", {}).get("USD")
            if rate:
                return round(rate, 4), "live"
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
        pass
    except Exception:
        pass

    # Fallback: Use cached rate
    return 0.58, "cached fallback"

def generate_cost_summary(
    ground_truth: dict[str, Any],
    billing_period: str,
    trends: dict[str, Any],
    ground_truth_override: bool = False,
    ground_truth_source: str = "REST API",
) -> dict[str, Any]:
    """
    Generate cost summary for archival.

    Args:
        ground_truth: Ground truth data from REST API
        billing_period: The billing period
        trends: Trend analysis data
        ground_truth_override: Whether Portal CSV override is active
        ground_truth_source: Source of ground truth data

    Returns:
        Cost summary for JSON archival
    """
    exchange_rate, rate_source = get_exchange_rate()
    current_total = ground_truth.get("total_cost_nzd", 0)

    # Aggregate top services across subscriptions
    service_totals: dict[str, float] = {}
    for sub in ground_truth.get("subscriptions", []):
        for svc in sub.get("top_services", []):
            name = svc.get("service", "Unknown")
            cost = svc.get("cost", 0)
            service_totals[name] = service_totals.get(name, 0) + cost

    top_services = sorted(
        [{"service": k, "cost_nzd": v} for k, v in service_totals.items()],
        key=lambda x: -x["cost_nzd"],
    )[:10]

    return {
        "period": billing_period,
        "generated_at": datetime.now().isoformat(),
        "version": "4.1.0",
        "currency": "NZD",
        "exchange_rate_usd": exchange_rate,
        "exchange_rate_source": rate_source,
        "total_nzd": current_total,
        "ground_truth_source": ground_truth_source,
        "ground_truth_override": ground_truth_override,
        "rest_api_total_nzd": ground_truth.get("total_cost_nzd", 0),
        "subscriptions": [
            {
                "name": s["name"],
                "id": s["subscription_id"],
                "cost_nzd": s["cost_nzd"],
                "percentage": s["percentage"],
                "status": s["status"],
            }
            for s in ground_truth.get("subscriptions", [])
        ],
        "top_services": top_services,
        "trends": trends,
        # Legacy fields for backwards compatibility
        "mom_change_pct": trends.get("mom_change_pct"),
        "yoy_change_pct": trends.get("yoy_change_pct"),
    }
