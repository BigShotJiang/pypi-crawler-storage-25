"""CostOptimizer Protocol for MCP tool discovery.

Enables runtime type checking and MCP schema generation without importing
concrete optimizer classes.
"""

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from .base import OptimizerResult

@runtime_checkable
class CostOptimizerProtocol(Protocol):
    """Typed interface for cost optimization analyzers."""

    def analyze(self) -> "OptimizerResult":
        """Analyze and return cost optimization recommendations."""
        ...

    def get_name(self) -> str:
        """Return a human-readable name for this optimizer."""
        ...

    def get_service(self) -> str:
        """Return the AWS service this optimizer targets (e.g., 'EC2', 'RDS')."""
        ...
