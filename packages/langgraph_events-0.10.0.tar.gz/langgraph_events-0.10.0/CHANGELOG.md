# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.10.0] - 2026-05-23

### Added
- **Required `ScalarReducer` values via handler type annotations** — when a handler declares a reducer parameter whose type annotation rejects `None` (e.g. `strategy: str`), the framework raises `ReducerNotSetError` at injection time if the channel value is `None`. Use `str | None` / `Optional[str]` / `Any` / `object` (or omit the annotation) to opt out and keep the legacy permissive behavior. `ReducerNotSetError` is a `ValueError` subclass exported from `langgraph_events`; the precondition raise sits outside the `raises=` catch boundary, so a broad `raises=ValueError` declaration cannot silently swallow it. Note: handlers previously receiving `None` through a non-`None`-typed parameter and handling it internally will now raise at injection — widen the annotation to opt out.
- **`NamespaceModel.Edge.causation`** — a causal-role axis alongside `kind`: `intent` (a command emits its own outcome), `react` (a reactor emits a fact), `orchestrate` (a reactor emits a command — a saga move), `chain` (a command emits another command), or `None` (`raises`/`framework`/boundary-crossing edges). Surfaces in `text()`, `to_dict()`/`json()` (additive — no schema bump), and `mermaid()` (`orchestrate` bold, `chain` dashed-warning; `intent`/`react` unchanged, so no diagram churn). The `supervisor`, `error_recovery`, and `expense_approval` example diagrams now mark their orchestration edges.
- **`CommandChainWarning`** — emitted at `namespaces()` time for every `chain`-causation edge (an inline `Command.handle()` returning another `Command`). Filter via `warnings.filterwarnings("ignore", category=CommandChainWarning)`.
- **Event migration story for `NamespaceAwareSerde`**: the `@migrate_from(*old_qualnames)` decorator lets consumers rename or relocate event classes without invalidating existing checkpoints. `EventGraph.from_namespaces(Persona, checkpointer=MemorySaver())` auto-wires a `NamespaceAwareSerde` scoped to exactly those namespaces — no manual serde construction and no namespace-tuple double-threading. A user-supplied `NamespaceAwareSerde` (custom `migrations=`/`legacy_write=`) passed via `MemorySaver(serde=...)` always wins (the opt-out). Old `(module, qualname)` is rewritten to the current identity in memory on read; the wire format is unchanged so rolling deploys with prior library versions keep working. `AddField(module=..., qualname=..., field=..., default=...)` covers new required fields on existing events; `Migration.rename(...)` / `Migration.add_field(...)` are single-op sugar over the raw `Migration(operations=(...))` form, with `name` optional everywhere. Hand-authored `Migration` lists for cross-module renames or composite operations flow through the serde's `migrations=` kwarg and compose with the decorator-driven collection. A `legacy_write=True` flag makes new code emit payloads under the oldest historic qualname for the rollout window — scope-symmetric with the read path, so out-of-scope decorated classes are NOT relabelled. `detect_changes(graph, baseline_path)` + `write_baseline(graph, path)` (under `langgraph_events.serde.migrations.detect`) provide a suggestion engine for pre-commit hooks; the baseline file is versioned and a mismatch raises at read time. Reducer projections are intentionally not migrated — events are the truth and projections re-derive. See [Event migrations](docs/event-migrations.md). (closes #70)
- **Pre-deploy migration confidence surface** — close the loop *before* a deploy instead of discovering a missing migration on the first production read. `synthesize_legacy_payload(module, qualname, kwargs)` (exported from `langgraph_events.serde` / `langgraph_events.serde.migrations`) builds the exact `(format, bytes)` a prior release would have written, so a CI test can assert it still revives under the current migration table without importing private wire-format symbols. `NamespaceAwareSerde.assert_covers(baseline_path)` raises `MigrationCoverageError` (exported from `langgraph_events.serde.migrations.detect`, `.uncovered` lists the offending identities) if any identity in the baseline is neither still live nor covered by a rename migration. `NamespaceAwareSerde.revivable_identities()` exposes the read-only union of live + migration-source identities for custom coverage rules. See [Event migrations](docs/event-migrations.md). (closes #70)
- **`assert_all_baselined_revive(serde, baseline_path)`** (exported from `langgraph_events.serde` / `langgraph_events.serde.migrations`) — pushes a synthesized legacy payload for every baselined identity through the real ext-hook and asserts it revives to an `Event`, filling required fields of the resolved live class with placeholders. Zero per-event maintenance: a new `@migrate_from` plus a regenerated baseline is covered with no new test code. `python -m langgraph_events.serde.migrations <module:factory> <baseline>` exits non-zero when topology diverges, making a forgotten migration a build failure rather than a production read error.
- **`@backfill(field, *, default=… | default_factory=…)`** (exported from `langgraph_events.serde` / `langgraph_events.serde.migrations`) — the class-scoped, auto-collected sibling of `@migrate_from` for the "added a now-required field" case. The back-fill value lives on the class, not in a remote `migrations=` list, and is picked up by the same namespace walk — so `EventGraph.from_namespaces(NS, checkpointer=MemorySaver())` covers it with zero manual serde wiring. Composes with `@migrate_from` on the same class (rename first, then back-fill on the resulting identity); stacked decorators accumulate; reuses the `AddField` mutable-default guard (not a forked rule). For cross-module relocations or composite operations, the hand-authored `Migration` / raw `AddField` escape hatch remains in `serde.migrations`. See [Event migrations](docs/event-migrations.md#adding-a-required-field).
- **`Migration.rename(to=<class>)` / `Migration.add_field(target=<class>)`** — the live (post-rename / AddField target) identity may now be passed as the class object; module/qualname are derived from it, so an IDE rename moves with the code instead of silently breaking a string. The string forms remain for the cross-module case; fully backward compatible.
- **`replay_reducer(reducer, events)`** (exported from `langgraph_events.serde`) — names the recovery pattern for cases where a reducer's projection function or output shape changed and the cached channel value is stale. Reads the migrated event log, re-runs the reducer's projection via `BaseReducer.seed`, and returns the rebuilt value for the caller to write back through the checkpointer. Pairs with the empirically-mapped reducer-state matrix in `docs/event-migrations.md`.

### Changed
- **`IntegrationEvent` placement is now enforced (breaking)**. An `IntegrationEvent` nested inside a `Namespace` or `Command` raises `TypeError` at class creation — it crosses a context boundary by definition. Symmetric with the existing `Command` / `DomainEvent` nesting rules; `SystemEvent` is unaffected (`Halted` subclasses may still nest for locality). **Migration**: move any nested `IntegrationEvent` to module level.
- **`write_baseline` refuses silent regression (breaking)**: `write_baseline(graph, path)` now raises `BaselineRegressionError` (exported from `langgraph_events.serde.migrations.detect`; `.removed` lists the dropped `(module, qualname)` identities) when *path* already exists and the new snapshot would drop identities the old baseline recorded — overwriting them away would make `detect_changes` / `assert_covers` permanently blind to a forgotten migration. The previously prose-only rule ("commit the baseline alongside the migration, never after") is now enforced. Pass `write_baseline(graph, path, allow_removed=True)` for intentional deletes. The check compares baseline ↔ topology only; it never inspects the serde — coverage stays with `assert_covers` / `assert_all_baselined_revive`. **Migration**: if a regenerate legitimately drops identities, pass `allow_removed=True`; otherwise author the `@migrate_from` / `@backfill` / `Migration` first, then regenerate.
- **Top-level `langgraph_events.serde` surface narrowed (breaking)**: raw `RenameEvent` and `AddField` are no longer re-exported from `langgraph_events.serde`. The common path is decorator-first (`@migrate_from`) plus `Migration.rename` / `Migration.add_field` sugar. The raw operation constructors remain importable from `langgraph_events.serde.migrations` for the rare composite multi-op `Migration`. **Migration**: change `from langgraph_events.serde import RenameEvent, AddField` to `from langgraph_events.serde.migrations import RenameEvent, AddField`.
- **`NamespaceAwareSerde.dumps_typed` no longer falls through to `JsonPlusSerializer.dumps_typed` on `MsgpackEncodeError`**. The fallback was a no-op in the default config (upstream re-raised the same error) and, with the parent's binary-fallback kwarg enabled, would silently emit unsafe-binary bytes that bypass the migration table. The encode error now propagates at the source. `ormsgpack.MsgpackEncodeError` is a `TypeError` subclass, so existing `except TypeError:` handlers continue to catch it; the only user-visible diff is that the `UserWarning` no longer fires before the raise.
- **Scatter must enumerate concrete event types**. Return annotations of the form `-> Scatter`, `-> Scatter[Any]`, `-> Scatter[Event]`, `-> Scatter[DomainEvent]`, `-> Scatter[IntegrationEvent]`, `-> Scatter[SystemEvent]`, and `-> Scatter[T]` (TypeVar) are now rejected at `EventGraph` construction with a `TypeError`. These shapes contributed no usable types to the privacy graph, so the v0.9.0 `enforce_command_privacy()` check passed silently and the leak was only caught at runtime — turning the previous build-time `CommandPrivacyError` into something developers could paper over by widening the annotation. **Migration**: replace `-> Scatter` with `-> Scatter[Event1 | Event2 | ...]` enumerating the concrete events you scatter. The error message points at the right form (and steers away from demoting the offending `Command` to `DomainEvent`/`IntegrationEvent`, which would silently lose privacy guarantees).
- **NamespaceModel JSON schema bumped to v2**. `CommandHandler.has_untyped_scatter` and `Policy.has_untyped_scatter` are removed (the represented condition is now impossible at build time). The "Scatter handlers: …" footer in mermaid output and the bare `Scatter` token in text output are both gone for the same reason. Consumers reading `to_dict()` must update.

### Fixed
- **Scatter return-type parser**: `Scatter[A | B]` now extracts both `A` and `B` as scatter targets, matching the behavior of the equivalent `Scatter[A] | Scatter[B]` form. Previously the Union argument was rejected by an `isinstance(..., type)` check and silently dropped, so `info.scatter_types` came back empty — orphan-warning detection and choreography diagrams missed those targets entirely. (closes #66)

## [0.9.0] - 2026-05-07

### Added
- **CommandPrivacyError**: new exported exception class (subclass of `TypeError`). Raised at `EventGraph` construction when a handler emits a `DomainEvent` it isn't allowed to emit. Two symmetric rules enforce that *outcomes nested inside a `Command` are private to that Command's inline `handle()`*:
  1. An inline `Command.handle()` may only return events nested under that same Command (or a parent Command, via inheritance) — not sibling/namespace-level events, not another Command's private outcomes.
  2. Any non-inline handler (`@on(...)` reactor) is forbidden from emitting a Command-private event. The owning Command's `handle()` is the single canonical producer; recovery and observer reactors emit namespace-level sibling events instead.
- **Class-level `invariants` and `raises` on `Command`**: declare invariants and catchable exceptions for an inline `handle()` directly on the Command class (e.g. `invariants: ClassVar = {Inv: predicate}`, `raises: ClassVar = (RateLimitError,)`). The framework forwards them to the synthesized `@on(Cmd)` wrapper, honoring inheritance via `getattr` so a child Command picks up a parent's declarations. Closes a gap where modifiers were only available on the external `@on(Cmd, ...)` form — prerequisite for the privacy migration above, since recovery patterns that previously rode on external `@on(Cmd, ...)` declarations now live on the Command class itself.
- **Domain-named inline handlers**: a Command's inline handler can now be named after its verb (`place`, `ship`, `submit`, …) instead of the generic `handle`. The framework picks up the sole public method in the class body. To preserve the "one intent, one handler" semantic, declaring more than one public method on a Command raises `TypeError` at class creation; underscore-prefix helpers to opt them out of the count.

### Changed
- `@on(Cmd) -> Cmd.Outcome` patterns are no longer allowed. A Command's nested outcomes must be produced by `Cmd.handle()` only. Tests, examples, and docs that previously relied on the external `@on(Cmd) -> Cmd.Outcome` form now use inline `handle()` (with class-level `invariants` / `raises` where needed). Recovery patterns that produced nested outcomes from outside (`@on(InvariantViolated) -> Cmd.Rejected`, `@on(HandlerRaised) -> Cmd.Rejected`) emit namespace-level events instead — for example, `Order.Place.Rejected` becomes `Order.Rejected` in the canonical `examples/order.py`.

### Fixed
- **Inline-handle outcome-coverage messages**: single-outcome Commands no longer report duplicate outcome names (`Done, Done`) in the missing-outcomes error — the synthesized `Outcomes` alias is excluded from the walk over nested DomainEvents. Bare `-> Scatter` on a Command's inline handler is now rejected up front with a message pointing at `Scatter[…]` or dropping the annotation, instead of falling through to a confusing `(no types)` coverage error. (closes #73)

## [0.8.0] - 2026-05-05

### Fixed
- **serde**: `NamespaceAwareSerde` no longer silently degrades non-event payloads (Pydantic models, plain dataclasses, project types) to `dict` on `langgraph-checkpoint>=4.0.3`. The fallback for ext codes the namespace-aware serde doesn't own previously dispatched through the *module-level* `_msgpack_ext_hook` from `langgraph.checkpoint.serde.jsonplus`, which 4.0.3 rebound to a strict hook (`_create_msgpack_ext_hook(allowed_modules=None)`). That bypassed both `LANGGRAPH_STRICT_MSGPACK` and the `JsonPlusSerializer` constructor's `allowed_msgpack_modules` argument, so every checkpointed non-event value came back as a `dict` (with a logged `Blocked deserialization of <module>.<name>` warning) and downstream code blew up with `AttributeError` when it called methods on the supposed instance. The fallback now routes through the parent's *per-instance* `_unpack_ext_hook`, so the constructor-level allowlist and `LANGGRAPH_STRICT_MSGPACK` work as documented for non-event payloads passing through `NamespaceAwareSerde`. (#68)

### Added
- **agui**: `agui_messages_to_langchain(messages, *, drop_invalid_tool_calls=False) -> list[BaseMessage]` — public helper at `langgraph_events.agui` for converting AG-UI protocol messages to LangChain `BaseMessage` instances. Mirrors the existing internal LangChain→AG-UI direction. Handles `UserMessage` (string and multimodal content with the `url > data > id` priority cascade), `AssistantMessage` (with optional `tool_calls`, parsing `function.arguments` JSON), `SystemMessage`, and `ToolMessage`. `ReasoningMessage` and `DeveloperMessage` are skipped with a DEBUG log; `ActivityMessage` and unknown roles raise `ValueError`. With `drop_invalid_tool_calls=True`, tool calls whose `function.arguments` fail to JSON-parse are dropped (WARNING-logged); if all of an `AssistantMessage`'s tool calls are dropped, the message itself is dropped. Removes the need to depend on `ag-ui-langgraph` for this utility.
- **agui**: `merge_frontend_messages(input_data, checkpoint_state, *, reducer_name="messages", drop_invalid_tool_calls=True) -> tuple[BaseMessage, ...]` — high-level helper for `ResumeFactory` implementations. Reads existing messages from `checkpoint_state["reducers"][reducer_name]`, converts `input_data.messages` via `agui_messages_to_langchain`, and merges via langgraph's `add_messages` (id-based dedup). Defensive default for malformed tool-call JSON; pass `drop_invalid_tool_calls=False` for strict parity with upstream.
- **agui**: `extract_resume_input(input_data) -> Any` — pulls resume input from `RunAgentInput.forwarded_props["command"]["resume"]`. If the value is a string, attempts `json.loads` (returns the decoded JSON value — dict, list, scalar — on success; the raw string on `JSONDecodeError`). Dicts/lists/numbers pass through unchanged. Returns `None` if absent or falsy.

## [0.7.0] - 2026-05-05

### Added
- **DomainPatternWarning**: new exported warning class. Emitted at `EventGraph.namespaces()` time when 2+ events in the same namespace fan out (via 2+ distinct reactor handlers) to identical target sets — typically a sign that a shared abstraction was missed (a common base event or a single reactor on a common subscription would collapse them). Detection is exact-set-equality only; subset/superset overlaps don't qualify. Silence via the standard warnings filter: `warnings.filterwarnings("ignore", category=DomainPatternWarning)`. The warning fires once per pattern at construction time; renderers (`mermaid()`, `text()`, etc.) do not re-emit.
- **NamespaceModel.mermaid(namespace_order=…)**: new keyword controlling how namespace subgraph clusters are sequenced. Pass `"alphabetical"` to preserve the legacy alphabetical order (useful for snapshot-pinned consumers). Defaults to `"affinity"` — see Changed.
- **NamespaceModel.mermaid(reactor_hub_min=…)**: new opt-in keyword (default `None`) for hub-style fanout rendering. When set to an integer `N`, any `(source, handler)` pair producing `≥ N` solid-or-scatter targets is rewritten as `Source --> Hub --> {targets}` — the handler name moves from being repeated on every fanout edge to a single label on the hub node (small circle, `:::hub` styling), placed inside the source's subgraph. Useful for tracing in large graphs where the same handler-name label clutters the area around high-fanout sources. Invariant-gated reactors are not hubbed (the invariant chain already concentrates dispatch); `raises` edges are not hubbed (single error path). Per-target arrow style (solid vs scatter) is preserved on the `Hub --> Target` edges. No default behavior change — leave unset for the existing flat fanout output.

### Changed
- **mermaid**: subgraph clusters now sort by inter-namespace edge affinity by default (greedy nearest-neighbor) instead of alphabetically. Heavily-connected namespaces land adjacent in the rendered diagram, substantially shortening the long crossing arrows that dominate multi-namespace graphs (Definition→Persona/Story/Scenario in real usage). Affinity counts solid + scatter + framework reaction edges plus invariant chain edges; ownership-fill `-.- ` arrows and `raises` edges don't contribute. Ties break alphabetically. **Default rendered output changes for any consumer with multi-namespace graphs** — pass `mermaid(namespace_order="alphabetical")` to opt out for snapshot stability.

## [0.6.2] - 2026-05-04

### Fixed
- **mermaid**: `render_mermaid_choreography` no longer collapses cross-namespace events that share a leaf class name. Previously, a project with sibling namespaces (e.g. `Persona.Approve.Approved`, `Story.Approve.Approved`, `Scenario.Approve.Approved`) emitted a single mermaid node for all three, merging their incoming/outgoing edges. The renderer now detects leaf-name collisions across the model and escalates only the colliding classes to qualname-based node IDs (`Persona_Approve_Approved`, …); display labels stay terse since the surrounding subgraph cluster already conveys namespace context. Non-colliding diagrams render byte-identically. (#62)

## [0.6.1] - 2026-05-04

### Fixed
- **serde**: `NamespaceAwareSerde` now preserves namespace identity for `Event` instances nested inside `langgraph.types.Interrupt` (the dataclass LangGraph wraps every interrupted value in before checkpointing). Previously, every namespaced `Interrupted`/`InterruptedWithPayload` subclass round-tripped through a checkpointer would silently decode back as `Interrupt(value=None, id=...)` because LangGraph's generic dataclass branch (`EXT_CONSTRUCTOR_KW_ARGS`) recurses into a hardcoded `_msgpack_default` and bypassed our namespace-aware `default=`. `Interrupt` is now intercepted directly under a dedicated ext code so the wrapped value re-enters our encoder. Note: this fix applies to checkpoints written *after* the upgrade — checkpoints already persisted under v0.6.0 still decode their nested events as `None` (same risk profile as before). (#60)

## [0.6.0] - 2026-05-04

### Added
- **EventGraph**: `services=` kwarg for dependency injection in two forms. (1) `services=[chat_model, session_factory]` — type-keyed; handler params resolve by their type annotation via an MRO walk (a base-class annotation matches a registered subclass instance), with exact-type match preferred over subclass match. (2) `services={"primary_chat": a, "backup_chat": b}` — name-keyed; handler params resolve by name. The mapping form allows multiple instances of the same type. Inline `Command.handle(self, chat_model: BaseChatModel)` and external `@on(...)` handlers share the same mechanism. Resolution order: reducer name → framework type (`EventLog` / `RunnableConfig` / `BaseStore`) → service. Eliminates the closure-factory pattern downstream projects use today to shuttle services into handlers.
- **serde**: new opt-in `langgraph_events.serde.NamespaceAwareSerde` — a `JsonPlusSerializer` subclass that keys `Event` identity by `(__module__, __qualname__)` instead of `(__module__, __name__)`. Drop-in for any LangGraph checkpointer that accepts `serde=` (e.g. `MemorySaver(serde=NamespaceAwareSerde())`). Two namespaces with sibling-named events (`Persona.Approve.Approved`, `Story.Approve.Approved`) now round-trip distinctly; non-event payloads encode exactly as the default serde.
- **InterruptedWithPayload[PayloadT]** (in `langgraph_events.agui`): new generic base for HITL with a discriminated frontend payload. Subclasses implement `interrupt_payload(self) -> PayloadT` and inherit from `Interrupted`. The AG-UI `InterruptedMapper` recognises it directly — no `agui_dict()` override needed. Eliminates the project-local "shim base" pattern downstream HITL projects use today to break import cycles between sibling namespace modules.
- **on_namespace_finalize(cls, callback)**: public hook that schedules a callback to fire once the enclosing Namespace's `__init_subclass__` finishes (after `_stamp_nested_namespace` and `_attach_command_outcomes`). Useful for class decorators that need to call `typing.get_type_hints()` against forward references to siblings inside the same in-progress Namespace body — those references can't resolve while the class body is evaluating, but resolve cleanly at finalize time. The callback receives `(cls, namespace_cls)` so decorators can resolve siblings via `vars(namespace_cls)` without touching private state. Re-exported at `langgraph_events.on_namespace_finalize`.

### Changed
- **EventGraph**: handler params with no injection source now raise `TypeError` at graph construction (previously crashed at first dispatch with a missing-keyword error). Two services of the same exact type are rejected at construction. A handler param annotated as a class that matches multiple registered services is rejected at construction with both candidate type names in the message. Resolution prefers an exact-type service match over subclass matches, so `services=[BaseChatModel(), Anthropic()]` cleanly resolves a `param: BaseChatModel` to the base instance. Annotations equal to `object` are skipped — they would otherwise silently match every registered service.
- **agui**: `FrontendToolCallRequested` (previously top-level `langgraph_events.FrontendToolCallRequested`) now lives in `langgraph_events.agui` alongside `FrontendStateMutated`. Update imports to `from langgraph_events.agui import FrontendToolCallRequested`. **The top-level alias still resolves**, but emits a `DeprecationWarning` per access pointing at the new path; it will be removed in a future release. The class itself is unchanged.

### Fixed
- **on_namespace_finalize**: callbacks registered after the enclosing Namespace has already finalized now fire immediately rather than dangling in the registry forever. Previously a decorator applied post-hoc to an already-bound class was a silent no-op.
- **EventGraph**: variadic handler params (`*args` / `**kwargs`) are no longer flagged as unclaimed at graph construction.
- **serde**: `NamespaceAwareSerde.dumps_typed` now warns when an unencodable payload forces fallback to the upstream serializer (which uses leaf-name identity, collision-prone for nested events). `loads_typed` now raises a clear `ValueError` naming the missing class when a checkpoint references an Event class that has been renamed or removed, rather than the opaque `ValueError("ext_hook failed")` from upstream. Imports of LangGraph private helpers are now guarded with a clear `ImportError` if upstream renames them.

## [0.5.2] - 2026-04-30

### Added
- **agui**: `AGUIAdapter(include_reducers=...)` validation — malformed values (anything other than `bool | list[str]`) now raise `TypeError` at construction instead of silently producing empty snapshots at runtime.

### Fixed
- **agui**: `AGUIAdapter.connect()` and the streaming `StateSnapshotEvent` path no longer leak the EventGraph-internal `events` audit log to clients. The audit log is graph-internal and was causing O(history) wire bloat on every client `Send` via `RunAgentInput.state` round-trip. The strip set is now derived from `_internal._BASE_FIELDS` (single source of truth across all four projection sites) rather than hardcoded; future internal channels propagate automatically. `_extract_frontend_state` also strips internal keys as defense-in-depth against stale-client echo.
- **agui**: Resume-time frontend state now flows through `FrontendStateMutated` instead of bypassing dispatch via `apre_seed(raw_state)`. The adapter computes per-reducer contributions from the FSM event (preserving `fn` semantics — transformations, `SKIP`) and writes them to channels via `apre_seed` *before* the resume's domain dispatch, then injects FSM as a seed to `astream_resume` so it appears in the output stream and the persisted audit log. Reducers that subscribe to `FrontendStateMutated` see the same contract on resume as on the non-resume path; reducers that subscribe to backend domain events are no longer clobbered by stale frontend snapshot keys. `@on(FrontendStateMutated)` *handlers* still do not fire on resume — `Command(resume=...)` carries one value and seeds dispatch out-of-graph; use `@on(Resumed)` for resume-time side effects.

### Changed
- **agui**: `AGUIAdapter.__init__` validates the `messages` reducer eagerly (raises `ValueError` immediately, before any other setup).
- **EventGraph**: `stream_resume` and `astream_resume` now accept a `seeds: list[Event] | None = None` kwarg. Seeds are dispatched alongside the resume in the same step — used by `AGUIAdapter` to route `FrontendStateMutated` through reducers on resume. Power users can plumb their own resume-time companion events through this hook.

## [0.5.1] - 2026-04-24

### Added
- `AGUIAdapter` now emits a new built-in `FrontendStateMutated` event (an `IntegrationEvent`, exported from `langgraph_events.agui`) as the first event of each run when `RunAgentInput.state` carries non-empty client-owned state. The dedicated `messages` key is filtered out (driven by `MessagesSnapshotEvent` / `TextMessageEvent`). Reducers mirroring client-driven channels subscribe to it like any other event — e.g. `ScalarReducer(event_type=FrontendStateMutated, fn=lambda e: e.state.get("focus", SKIP))` — and handlers can optionally `@on(FrontendStateMutated)` to react. On resume, the adapter writes the filtered state directly to reducer channels via `graph.apre_seed` before calling `astream_resume` (LangGraph's `ainvoke` on a pending-interrupt thread would consume the interrupt); in the idiomatic state-key-equals-channel-name pattern the values flow through identically to the non-resume path. `FrontendStateMutated` is not echoed back to the client — its downstream reducer changes surface via the usual `StateSnapshotEvent` path. Works with or without a checkpointer on the non-resume path.

## [0.5.0] - 2026-04-22

### Added
- Event taxonomy: `Namespace`, `Command`, `DomainEvent`, `IntegrationEvent`, `SystemEvent`. `Namespace` subclasses act as namespaces for nested commands and outcomes, encoding the `Domain.Command.Outcomes` pattern (`Order.Place.Placed`) directly in Python's class structure. Class-creation enforcement: `Command` subclasses must be nested in a `Namespace`, `DomainEvent` subclasses must be nested in a `Namespace` or `Command`. Existing framework events (`Halted`, `Interrupted`, `Resumed`, `HandlerRaised`, `Cancelled`, `MaxRoundsExceeded`) gain `SystemEvent` as a parent — backwards-compatible since they still inherit `Event` transitively. See `examples/order.py`.
- `Command.Outcomes` — auto-generated union of a command's nested `DomainEvent` classes. Used for `isinstance` checks, introspection (`typing.get_args(Command.Outcomes)`), and as the fallback runtime contract for handlers subscribed to a command. Users may declare `Outcomes` explicitly for `mypy` visibility; the framework validates drift against the nested events at class creation.
- Inline command handlers — a `handle` method defined directly on a `Command` class auto-registers as that command's handler when the class is passed to `EventGraph` or via `EventGraph.from_namespaces(*domains, handlers=...)`. `self` is the command event. Existing `@on(...)` handlers still work and compose in the same graph.
- Strict return-type enforcement — at dispatch, the framework validates handler returns against (a) the declared return annotation, or (b) the subscribed command's `Outcomes` when no annotation is present. Violations raise `TypeError` at the handler's dispatch. Unannotated non-`Command`-subscribing handlers keep the legacy shape-only check.
- Declarative domain reducers — `Reducer` / `ScalarReducer` instances declared as class attributes inside a `Namespace` are auto-named (from the attribute), auto-scoped (only that domain's events contribute), and auto-discovered by `EventGraph` via any handler subscribed to the domain's events. Explicit `reducers=[...]` kwarg still works for graph-wide reducers. Child domains inherit parent reducers via MRO.
- `Invariant` marker base class — subclass to declare a typed invariant (e.g. `class CustomerNotBanned(Invariant)`). The subclass identity drives matching; zero-arg instantiable.
- `invariants=` parameter on `@on()` — dict mapping typed `Invariant` subclasses to sync predicates (`invariants={CustomerNotBanned: lambda log: not log.has(CustomerBanned)}`). Evaluated in two phases per matching event: **pre-check** (before the handler runs, against the current log) and **post-check** (after the handler returns, against `log + emitted events`). Pre-check failure skips the handler; post-check failure drops the handler's emitted events and commits `InvariantViolated` in their place with `would_emit: tuple[Event, ...]` carrying the rolled-back events. Pin a reaction with `@on(InvariantViolated, invariant=CustomerNotBanned)` — pinned reactors fire for both phases without distinguishing. Multiple invariants short-circuit on first failure; async predicates are rejected at decoration; predicate exceptions propagate. Compile-time drift check raises `TypeError` when a pinned `invariant=` matcher references a class no handler declares ("would never fire"). Predicates must be pure functions of `log` — the same predicate runs in both phases. See `examples/order.py`.
- `EventGraph.namespaces()` — returns a `NamespaceModel`: a code-derived snapshot of the graph's structure with two lenses (`view="structure"` — domains → commands → outcomes taxonomy; `view="choreography"` — full event flow with handlers, policies, edges, seeds). Renderers: `text()`, `mermaid()`, `json()` / `to_dict()`. Nested frozen dataclasses (`NamespaceModel.Namespace`, `Command`, `CommandHandler`, `Policy`, `Edge`, `Invariant`) replace the prior `Catalog` / `AggregateEntry` / `CommandEntry` TypedDicts.
- `NamespaceModel.invariants` — first-class node for every declared invariant, with `cls`, `commands` (owning commands), `declared_by` (handler names), and `reactors` (pinned `@on(InvariantViolated, invariant=…)` handler names). Surfaced in `graph.namespaces().text()` as an `Invariants:` section and in `graph.namespaces().mermaid()` as a diamond gate node styled `:::inv` inside the owning domain's subgraph. When an invariant has a pinned reactor, the reactor's output edge leaves the Invariant diamond directly — one clean chain `Command -.->|invariant| Invariant -.->|reactor| Outcome` instead of a disconnected gate and a separate `InvariantViolated` stadium node. The `InvariantViolated` node drops from the diagram entirely when every reactor is pinned (no catch-all `@on(InvariantViolated)`). Ownership-gap arrows are suppressed for outcomes already reached via an invariant chain.
- `EventGraph.from_namespaces(*domains, handlers=None, **kwargs)` — classmethod factory that walks domains' namespaces, auto-registers every command with an inline `handle`, and appends any extra external handlers.
- `@on()` field matchers now accept `str` values for equality match alongside `type` values for `isinstance` match.
- `@on` is now polymorphic: `@on` (bare) and `@on(kwargs=...)` infer the event type from the handler's first parameter annotation, removing the common duplication between decorator argument and annotation. `@on(Type, ...)` remains the explicit form for multi-event subscription or any case where you prefer not to rely on inference. Errors at decoration if the annotation is missing or not a single `Event` subclass, and the error points to the explicit form.
- New examples: `expense_approval.py` (human-in-the-loop approval with Interrupted/resume), `conversation.py` (tool-calling agent with content moderation and AG-UI frontend tools end-to-end). `examples/order.py` grows a `ScalarReducer` attribute + pinned `@on(InvariantViolated, invariant=…)` reaction to illustrate those idioms in the canonical example.

### Changed
- `Reducer` and `ScalarReducer` fields beyond `name` are now keyword-only. Positional calls `Reducer(name, event_type, fn)` break; switch to `Reducer(name="x", event_type=..., fn=...)`. Calls already using kwargs are unaffected. See `docs/migrating.md`.
- Bare `Event` subclassing now raises `TypeError` — use `DomainEvent`, `IntegrationEvent`, `Command`, or `SystemEvent`. See `docs/migrating.md`.
- Handler return types are enforced at dispatch — mismatches raise `TypeError`. Unannotated non-`Command` handlers keep the legacy shape-only check. See `docs/migrating.md`.
- `Auditable` and `MessageEvent` are plain mixins — compose with an event branch (e.g. `IntegrationEvent, Auditable`). See `docs/migrating.md`.
- `SystemPromptSet` is now an `IntegrationEvent` (was `SystemEvent`). `SystemEvent` is reserved for framework-emitted facts; system prompts are user-seeded input. `@on(SystemEvent)` catch-alls and `isinstance(evt, SystemEvent)` branches that treated system prompts as framework signals need updating. See `docs/migrating.md`.

### Removed
- `EventGraph.catalog()` / `EventGraph.describe()` and the `Catalog` / `AggregateEntry` / `CommandEntry` TypedDicts — superseded by `EventGraph.namespaces()` + `NamespaceModel`. See `docs/migrating.md`.
- `examples/react_agent.py` — redundant with `examples/conversation.py` (same send/classify/LLM+tools shape, now reshaped as a `Conversation` namespace).
- `examples/reflection_loop.py` — multi-subscription loop pattern covered by `examples/conversation.py`.
- `examples/human_in_the_loop.py` — HITL pattern subsumed by `examples/expense_approval.py`.
- `examples/agui_frontend_tools.py` — LLM-initiated AG-UI frontend-tool flow folded into `examples/conversation.py`.
- `examples/agui_confirm_dialog.py` — handler-initiated `FrontendToolCallRequested` snippet moved to `docs/agui.md`.

## [0.4.0] - 2026-04-20

### Added
- `raises=` parameter on `@on()` — declare exceptions the framework should catch from a handler. Caught exceptions are surfaced as the new built-in `HandlerRaised` event carrying the raising handler's name (`handler`), the event being processed (`source_event`), and the raw exception (`exception`). Subscribe with `@on(HandlerRaised, exception=MyError)` to react (retry, back off, halt) without try/except boilerplate. Compile-time validation fails if a declared exception has no matching catcher; catchers that add a non-`exception` field matcher (e.g. `source_event=SomeType`) are conservatively not counted toward coverage and must be paired with a broader catcher. Framework-level errors (e.g. calling `invoke()` on an async handler from within a running event loop) are raised outside the `raises=` catch boundary and cannot be swallowed by a broad `raises=Exception`. `exception=` field matchers reject non-`Exception` `BaseException` subclasses (symmetric with `raises=`). See `examples/error_recovery.py`.
- AG-UI frontend tools — `useFrontendTool` (CopilotKit v2) is now idiomatic against an `EventGraph`. The adapter streams `AIMessageChunk.tool_call_chunks` as `ToolCallStart`/`ToolCallArgs`/`ToolCallEnd` (new `LLMToolCallChunk` frame + adapter wiring), and a new built-in `FrontendToolCallRequested(Interrupted)` event maps to the same triple for handler-initiated flows — tool calls become "HITL with typed fields," mirroring `ApprovalRequested(Interrupted)`. Two new helpers in `langgraph_events.agui`: `build_langchain_tools(input_data.tools)` converts AG-UI tool defs to OpenAI-format bindings for `llm.bind_tools(...)`; `detect_new_tool_results(input_data, checkpoint_state)` returns inbound tool messages not yet in the checkpoint so `resume_factory` can return a `MessageEvent` and continue the graph. See `examples/agui_frontend_tools.py` (LLM-initiated) and `examples/agui_confirm_dialog.py` (handler-initiated).

### Changed
- AG-UI frontend-tool plumbing now raises `ValueError` on contract violations instead of silently coercing missing fields. Triggers: `FrontendToolCallRequested(name="")` (or whitespace), an LLM `tool_call_chunk` lacking `index`, the first chunk of a streaming call lacking `id` or `name`, and an inbound `role: "tool"` message lacking `tool_call_id`. The streaming-path errors propagate through the existing `AGUIAdapter.stream()` top-level handler and surface as a `RUN_ERROR` event with the diagnostic message; conformant CopilotKit clients and LangChain chat models are unaffected.

## [0.3.0] - 2026-04-13

### Added
- `EventGraph.apre_seed()` — async counterpart to `pre_seed()`

## [0.2.1] - 2026-04-12

### Fixed
- Init reducer state from checkpoint in `_astream_v2` and `make_seed_node`

## [0.2.0] - 2026-04-06

### Added
- Field-level dispatch for `@on` decorator
- AG-UI protocol adapter with `langgraph-events[agui]` optional dependency
- Custom event emit helpers (`emit_custom`, `aemit_custom`, `emit_state_snapshot`, `aemit_state_snapshot`)
- First-class `StateSnapshotFrame` for state snapshot streaming
- `SKIP` sentinel for scalar reducer no-op returns
- Graceful `Halted` subtypes (`MaxRoundsExceeded`, `Cancelled`) and `OrphanedEventWarning`
- LLM token streaming (`LLMToken`, `LLMStreamEnd` frames)
- MkDocs documentation site on GitHub Pages

### Changed
- Restructured docs for better DX (split concepts, grouped API reference)
- `Interrupted` is now a bare marker class — subclass with typed fields

### Fixed
- AG-UI adapter message deduplication and ID reconciliation
- `connect()` yielding no events for new threads
- Resume interrupt detection for interrupts created during resume

## [0.1.0] - 2026-02-20

### Added
- Core `Event`, `EventGraph`, and `@on` decorator
- `Reducer` and `ScalarReducer` for custom state channels
- `EventLog` with query methods (`first`, `count`, `after`, `before`, `select`)
- Multi-subscription `@on(A, B)` and `Scatter` for fan-out
- `Auditable` and `MessageEvent` base events
- `SystemPromptSet` event for system prompts
- Config and store injection for handlers
- `Interrupted` / `Resumed` events for human-in-the-loop
- Mermaid diagram generation
- BDD-style test suite with pytest-describe
- CI workflow (lint, typecheck, test)

[Unreleased]: https://github.com/cadance-io/langgraph-events/compare/v0.10.0...HEAD
[0.10.0]: https://github.com/cadance-io/langgraph-events/compare/v0.9.0...v0.10.0
[0.9.0]: https://github.com/cadance-io/langgraph-events/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/cadance-io/langgraph-events/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/cadance-io/langgraph-events/compare/v0.6.2...v0.7.0
[0.6.2]: https://github.com/cadance-io/langgraph-events/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/cadance-io/langgraph-events/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/cadance-io/langgraph-events/compare/v0.5.2...v0.6.0
[0.5.2]: https://github.com/cadance-io/langgraph-events/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/cadance-io/langgraph-events/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/cadance-io/langgraph-events/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/cadance-io/langgraph-events/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/cadance-io/langgraph-events/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/cadance-io/langgraph-events/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/cadance-io/langgraph-events/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/cadance-io/langgraph-events/releases/tag/v0.1.0
