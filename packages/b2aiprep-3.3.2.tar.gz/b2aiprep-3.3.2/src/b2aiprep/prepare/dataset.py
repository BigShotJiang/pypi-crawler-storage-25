"""
Utilities for extracting subsets of data from a BIDS-like formatted dataset.

The BIDS-like format assumed is in the following structure. Let's assume we have
a participant (p1) and they have multiple sessios (s1, s2, s3). Then the BIDS-like
structure is:

sub-p1/
    ses-s1/
        beh/
            sub-p1_ses-s1_session-questionnaire-a.json
            sub-p1_ses-s1_session-questionnaire-b.json
        sub-p1_ses-s1_sessionschema.json
    sub-p1_subject-questionnaire-a.json
    sub-p1_subject-questionnaire-b.json
    ...
"""

from copy import copy, deepcopy
from functools import partial
import logging
import os
import re
import shutil
import typing as t
from collections import OrderedDict, defaultdict
from pathlib import Path
from importlib.resources import files
from importlib import resources
import json
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd
import torch
from fhir.resources.questionnaireresponse import QuestionnaireResponse
from senselab.audio.data_structures.audio import Audio
from senselab.audio.tasks.preprocessing import downmix_audios_to_mono, resample_audios
from soundfile import LibsndfileError
from tqdm import tqdm

from b2aiprep.prepare.constants import RepeatInstrument, Instrument
from b2aiprep.prepare.update import build_activity_payload
from b2aiprep.prepare.utils import (
    copy_package_resource,
    get_commit_sha,
    normalize_task_label,
    sanitize_task_entity_in_bids_stem,
)
from b2aiprep.prepare.fhir_utils import convert_response_to_bids_metadata
from b2aiprep.prepare.prepare import (
    get_value_from_metadata,
    remap_id, 
    update_metadata_record_and_session_id,
    reduce_id_length
)
from b2aiprep.prepare.bids import get_paths
from pydantic import BaseModel
from b2aiprep.prepare.redcap import RedCapDataset

_LOGGER = logging.getLogger(__name__)

DEFAULT_RESAMPLE_RATE = 16000
DEFAULT_BIT_DEPTH = 16

# Sensitive audio feature content that must not be present for sensitive tasks.
#
# This is a grouped spec because the per-record feature `.pt` files are nested dicts
# (e.g., `features["torchaudio"]["mfcc"]`), while some sensitive artifacts live at
# the top-level (e.g., `features["transcription"]`).
_SENSITIVE_FEATURES_REMOVED_FROM_BUNDLE: t.Mapping[str, t.FrozenSet[str]] = {
    "torchaudio": frozenset({"mel_filter_bank", "mfcc", "mel_spectrogram", "spectrogram"}),
    "": frozenset({"ppgs", "transcription"}),
    "sparc": frozenset({"ema"}),
}


def _remove_sensitive_features_from_feature_payload(
    features: t.MutableMapping[str, t.Any],
    spec: t.Mapping[str, t.AbstractSet[str]] = _SENSITIVE_FEATURES_REMOVED_FROM_BUNDLE,
) -> None:
    """Remove sensitive feature content from an in-memory feature payload in-place."""

    for group, keys_to_remove in spec.items():
        if group == "":
            for key in keys_to_remove:
                features.pop(key, None)
            continue

        grouped_payload = features.get(group)
        if isinstance(grouped_payload, dict):
            for key in keys_to_remove:
                grouped_payload.pop(key, None)

def _copy_audio_files_parallel(copy_tasks: t.List[t.Tuple[Path, Path]], max_workers: int = 16, sanitize_audio_format: bool = False):
    """Copy audio files in parallel using ThreadPoolExecutor.
    
    Args:
        copy_tasks: List of (source_path, dest_path) tuples
        max_workers: Number of parallel worker threads
    """
    
    def copy_one_file(src: Path, dst: Path) -> t.Optional[str]:
        """Copy a single file, return error message if failed."""
        try:
            if sanitize_audio_format:
                src_audio = Audio(filepath=src)
                downmixed_audio = downmix_audios_to_mono([src_audio])[0]
                audio_16k = resample_audios([downmixed_audio], DEFAULT_RESAMPLE_RATE)[0]
                audio_16k.save_to_file(dst,bits_per_sample=DEFAULT_BIT_DEPTH)
            else:
                shutil.copyfile(src, dst)
            return None
        except Exception as e:
            return f"Failed to copy {src} -> {dst}: {e}"
    
    if not copy_tasks:
        return
    
    errors = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(copy_one_file, src, dst): (src, dst) for src, dst in copy_tasks}
        
        for future in as_completed(futures):
            error = future.result()
            if error:
                errors.append(error)
                _LOGGER.error(error)
    
    if errors:        
        failed_files = [err.split("->")[0].replace("Failed to copy", "").strip() for err in errors]  
        total_files = len(copy_tasks)  
        unique_error_types = set()  
        for err in errors:  
            # Try to extract the exception type from the error message  
            if ":" in err:  
                unique_error_types.add(err.split(":")[-1].strip())  
        summary = (  
            f"Encountered {len(errors)} errors out of {total_files} files during parallel audio copying.\n"  
            f"Failed files (up to 5 shown): {failed_files[:5]}\n"  
            f"Unique error types (up to 3 shown): {list(unique_error_types)[:3]}"  
        )  
        _LOGGER.warning(summary)  


class BIDSDataset:
    def __init__(self, data_path: t.Union[Path, str, os.PathLike]):
        self.data_path = Path(data_path).resolve()
    
    @classmethod
    def from_redcap(
        cls,
        redcap_dataset: RedCapDataset,
        outdir: t.Union[str, Path],
        audiodir: t.Optional[t.Union[str, Path]] = None,
        max_audio_workers: int = 16,
        sanitize_audio_format: bool = False,
    ) -> 'BIDSDataset':
        """
        Create a BIDSDataset by converting a RedCapDataset to BIDS format.
        
        Args:
            redcap_dataset: The RedCapDataset to convert
            outdir: Output directory for BIDS structure
            audiodir: Optional directory containing audio files
            max_audio_workers: Number of parallel threads for audio copying (default: 16)
            sanitize_audio_format: Whether to standardize the audio to 16KHz and mono-channel
            
        Returns:
            BIDSDataset instance pointing to the created BIDS directory
        """
        outdir = Path(outdir).as_posix()
        BIDSDataset._initialize_data_directory(outdir)

        _LOGGER.info("Converting RedCap dataset to BIDS phenotype files.")
        # Subselect the RedCap dataframe and output components to individual files in the phenotype directory
        BIDSDataset._construct_phenotype_from_reproschema(
            df=redcap_dataset.df,
            output_dir=os.path.join(outdir, "phenotype"),
        )

        if audiodir is None:
            # Return a new BIDSDataset instance pointing to the created directory
            return cls(outdir)

        _LOGGER.info("Processing audio files into BIDS format.")
        # We have two remaining tasks: (1) copy the audio files, and (2) create sidecar .json files.
        # First we prepare the metadata necessary for the .json files.
        participants_df = redcap_dataset.get_df_of_repeat_instrument(RepeatInstrument.PARTICIPANT.value)
        _LOGGER.info(f"Number of {RepeatInstrument.PARTICIPANT.name} entries: {len(participants_df)}")
        sessions_df = redcap_dataset.get_df_of_repeat_instrument(RepeatInstrument.SESSION.value)
        _LOGGER.info(f"Number of {RepeatInstrument.SESSION.name} entries: {len(sessions_df)}")
        acoustic_tasks_df = redcap_dataset.get_df_of_repeat_instrument(RepeatInstrument.ACOUSTIC_TASK.value)
        _LOGGER.info(f"Number of {RepeatInstrument.ACOUSTIC_TASK.name} entries: {len(acoustic_tasks_df)}")
        recordings_df = redcap_dataset.get_df_of_repeat_instrument(RepeatInstrument.RECORDING.value)
        _LOGGER.info(f"Number of {RepeatInstrument.RECORDING.name} entries: {len(recordings_df)}")

        sessions_by_participant = defaultdict(list)
        for session in sessions_df.to_dict("records"):
            sessions_by_participant[session["record_id"]].append(session)

        tasks_by_session = defaultdict(list)
        for task in acoustic_tasks_df.to_dict("records"):
            tasks_by_session[task["acoustic_task_session_id"]].append(task)

        recordings_by_task = defaultdict(list)
        for recording in recordings_df.to_dict("records"):
            recordings_by_task[recording["recording_acoustic_task_id"]].append(recording)

        participants = []
        for participant in participants_df.to_dict("records"):
            participants.append(participant)
            participant["sessions"] = sessions_by_participant.get(participant["record_id"], [])

            for session in participant["sessions"]:
                session_id = session["session_id"]
                session["acoustic_tasks"] = tasks_by_session.get(session_id, [])
                
                for task in session["acoustic_tasks"]:
                    task["recordings"] = recordings_by_task.get(task["acoustic_task_id"], [])

        # Output participant data to FHIR format
        audio_files: t.List[Path] = []
        if audiodir is not None and Path(audiodir).exists():
            audio_files = list(Path(audiodir).rglob("*.wav"))
        
        audio_mappings_path = files("b2aiprep.prepare.resources").joinpath("audio_task_descriptions.json")
        with open(audio_mappings_path, 'r') as file_object:
            audio_descriptor_dict = json.load(file_object, object_pairs_hook=OrderedDict)
        # create an index of recording_id: audio_file for later use
        # ASSUMES that audio files are named with the recording_id in the filename
        # we use a defensive regex to grab uuid-like IDs from the stem just in case
        p_uuid = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')
        audio_files_by_recording: t.Dict[str, Path] = {}
        for audio_file in audio_files:
            match = p_uuid.search(audio_file.stem)
            if not match:
                continue
            uuid = match.group(0)
            if uuid in audio_files_by_recording:
                _LOGGER.warning(
                    f"Multiple audio files found for recording UUID {uuid}: "
                    f"{audio_files_by_recording[uuid]} and {audio_file}. "
                    "Only the last one will be retained."
                )
            audio_files_by_recording[uuid] = audio_file

        for participant in tqdm(participants, desc="Writing participant data to file"):
            cls._output_participant_data_to_metadata_file(
                participant,
                Path(outdir),
                audio_files_by_recording=audio_files_by_recording,
                max_audio_workers=max_audio_workers,
                sanitize_audio_format=sanitize_audio_format,
                audio_descriptor_dict=audio_descriptor_dict
            )
        
        # Return a new BIDSDataset instance pointing to the created directory
        return cls(outdir)

    @staticmethod
    def _initialize_data_directory(bids_dir_path: str) -> None:
        """Initializes the data directory using the template.

        Args:
            bids_dir_path (str): The path to the BIDS directory where the data should be initialized.

        Returns:
            None
        """
        if not os.path.exists(bids_dir_path):
            os.makedirs(bids_dir_path)
            _LOGGER.info(f"Created directory: {bids_dir_path}")

        template_package = "b2aiprep.template"
        copy_package_resource(template_package, "CHANGELOG.md", bids_dir_path)
        copy_package_resource(template_package, "README.md", bids_dir_path)
        copy_package_resource(template_package, "dataset_description.json", bids_dir_path)
        copy_package_resource(template_package, "phenotype", bids_dir_path)

    def find_questionnaires(self, questionnaire_name: str) -> t.List[Path]:
        """
        Find all the questionnaires with a given suffix.

        Parameters
        ----------
        questionnaire_name : str
            The name of the questionnaire.

        Returns
        -------
        List[Path]
            A list of questionnaires which have the given questionnaire suffix.
        """
        questionnaires = []
        
        # Handle special cases for the new data structure
        if questionnaire_name == "recordingschema":
            # Find all audio metadata JSON files which contain recordingschema data
            for audio_json in self.data_path.rglob("*/audio/*.json"):
                questionnaires.append(audio_json)
        else:
            # Try the original approach first for backward compatibility
            for questionnaire in self.data_path.rglob(f"sub-*_{questionnaire_name}.json"):
                questionnaires.append(questionnaire)
        
        return questionnaires

    def find_subject_questionnaires(self, subject_id: str) -> t.List[Path]:
        """
        Find all the questionnaires for a given subject.

        Parameters
        ----------
        subject_id : str
            The subject identifier.

        Returns
        -------
        List[Path]
            A list of questionnaires for the specific subject.
        """
        subject_path = self.data_path / f"sub-{subject_id}"
        questionnaires = []
        for questionnaire in subject_path.glob("sub-*.json"):
            questionnaires.append(questionnaire)
        return questionnaires

    def find_session_questionnaires(self, subject_id: str, session_id: str) -> t.List[Path]:
        """
        Find all the questionnaires for a given subject and session.

        Parameters
        ----------
        subject_id : str
            The subject identifier.
        session_id : str
            The session identifier.

        Returns
        -------
        List[Path]
            A list of questionnaires for the specific subject and session.
        """
        session_path = self.data_path / f"sub-{subject_id}" / f"ses-{session_id}"
        questionnaires = []
        for questionnaire in session_path.glob("sub-*.json"):
            questionnaires.append(questionnaire)
        return questionnaires

    def find_subjects(self) -> t.List[Path]:
        """
        Find all the subjects in the dataset.

        Returns
        -------
        List[Path]
            A list of subject paths.
        """
        subjects = []
        for subject in self.data_path.glob("sub-*"):
            subjects.append(subject)
        return subjects

    def find_sessions(self, subject_id: str) -> t.List[Path]:
        """
        Find all the sessions for a given subject.

        Parameters
        ----------
        subject_id : str
            The subject identifier.

        Returns
        -------
        List[Path]
            A list of session paths.
        """
        subject_path = self.data_path / f"sub-{subject_id}"
        sessions = []
        for session in subject_path.glob("ses-*"):
            sessions.append(session)
        return sessions

    def find_tasks(self, subject_id: str, session_id: str) -> t.Dict[str, Path]:
        """
        Find all the tasks for a given subject and session.

        Parameters
        ----------
        subject_id : str
            The subject identifier.
        session_id : str
            The session identifier.

        Returns
        -------
        Dict[str, Path]
            A dictionary of tasks for the subject and session.
        """
        session_path = self.data_path / f"sub-{subject_id}" / f"ses-{session_id}"
        tasks = {}
        prefix_length = len(f"sub-{subject_id}_ses-{session_id}_task-")
        for task in session_path.glob(f"sub-{subject_id}_ses-{session_id}_task-*"):
            task_id = task.stem[prefix_length:-4]
            tasks[task_id] = task.stem
        return tasks

    def list_questionnaire_types(self, subject_only: bool = False) -> t.List[str]:
        """
        List all the questionnaire types in the dataset.

        Returns
        -------
        List[str]
            A list of questionnaire types.
        """
        questionnaire_types = set()
        for subject_path in self.data_path.glob("sub-*"):
            # subject-wide resources
            for questionnaire in subject_path.glob("sub-*.json"):
                questionnaire_types.add(questionnaire.stem.split("_")[-1])
            if subject_only:
                continue
            # session-wide resources
            for session_path in subject_path.glob("ses-*"):
                beh_path = session_path.joinpath("beh")
                if beh_path.exists():
                    for questionnaire in beh_path.glob("sub-*.json"):
                        questionnaire_types.add(questionnaire.stem.split("_")[-1])
        return sorted(list(questionnaire_types))

    def load_questionnaire(self, questionnaire_path: Path) -> QuestionnaireResponse:
        """
        Load a questionnaire from a given path.

        Parameters
        ----------
        questionnaire_path : Path
            The path to the questionnaire.

        Returns
        -------
        pd.DataFrame
            The questionnaire data.
        """
        return QuestionnaireResponse.parse_raw(questionnaire_path.read_text())

    def load_subject_questionnaires(self, subject_id: str) -> t.List[QuestionnaireResponse]:
        """
        Load all the questionnaires for a given subject.

        Parameters
        ----------
        subject_id : str
            The subject identifier.

        Returns
        -------
        List[QuestionnaireResponse]
            A list of questionnaires for the specific subject. Each element is a FHIR
            QuestionnaireResponse object, which inherits from Pydantic.
        """
        questionnaires = self.find_subject_questionnaires(subject_id)
        return [self.load_questionnaire(path) for path in questionnaires]

    def load_questionnaires(self, questionnaire_name: str) -> t.List[QuestionnaireResponse]:
        """
        Load all the questionnaires with a given name.

        Parameters
        ----------
        questionnaire_name : str
            The name of the questionnaire.

        Returns
        -------
        List[QuestionnaireResponse]
            A list of questionnaires for the specific subject. Each element is a FHIR
            QuestionnaireResponse object, which inherits from Pydantic.
        """
        questionnaires = self.find_questionnaires(questionnaire_name)
        return [self.load_questionnaire(path) for path in questionnaires]

    def questionnaire_to_dataframe(self, questionnaire: QuestionnaireResponse) -> pd.DataFrame:
        """
        Convert a questionnaire to a pandas DataFrame.

        Parameters
        ----------
        questionnaire : pd.DataFrame
            The questionnaire data.

        Returns
        -------
        pd.DataFrame
            The questionnaire data as a DataFrame. The dataframe is in a "long" format
            with a column for "linkId" and multiple value columns (e.g. "valueString")
        """
        questionnaire_dict = questionnaire.dict()
        items = questionnaire_dict["item"]
        has_multiple_answers = False
        for item in items:
            if ("answer" in item) and (len(item["answer"]) > 1):
                has_multiple_answers = True
                break
        if has_multiple_answers:
            raise NotImplementedError("Questionnaire has multiple answers per question.")

        items = []
        for item in questionnaire_dict["item"]:
            # Rename record_id to participant_id
            link_id = item["linkId"]
            if link_id == "record_id":
                link_id = "participant_id"
            if "answer" in item:
                items.append(
                    OrderedDict(
                        linkId=link_id,
                        **item["answer"][0],
                    )
                )
            else:
                items.append(
                    OrderedDict(
                        linkId=link_id,
                        valueString=None,
                    )
                )
        # unroll based on the possible value options
        return pd.DataFrame(items)

    def find_audio(self, subject_id: str, session_id: str) -> t.List[Path]:
        """
        Find all the audio recordings for a given subject and session.

        Parameters
        ----------
        subject_id : str
            The subject identifier.
        session_id : str
            The session identifier.

        Returns
        -------
        List[Path]
            A list of audio recordings.
        """
        session_path = self.data_path / f"sub-{subject_id}" / f"ses-{session_id}" / "audio"
        audio = []
        for audio_file in session_path.glob("*.wav"):
            audio.append(audio_file)
        return audio

    def find_audio_features(self, subject_id: str, session_id: str) -> t.List[Path]:
        """
        Find all the audio features for a given subject and session.

        Parameters
        ----------
        subject_id : str
            The subject identifier.
        session_id : str
            The session identifier.

        Returns
        -------
        List[Path]
            A list of audio features.
        """
        session_path = self.data_path / f"sub-{subject_id}" / f"ses-{session_id}" / "audio"
        features = []
        for feature_file in session_path.glob("*.pt"):
            features.append(feature_file)
        return features

    def find_audio_transcripts(self, subject_id: str, session_id: str) -> t.List[Path]:
        """
        Find all the audio transcripts for a given subject and session.

        Parameters
        ----------
        subject_id : str
            The subject identifier.
        session_id : str
            The session identifier.

        Returns
        -------
        List[Path]
            A list of audio transcripts.
        """
        session_path = (
            self.data_path / f"sub-{subject_id}" / f"ses-{session_id}" / "audio_transcripts"
        )
        transcripts = []
        for transcript_file in session_path.glob("*.json"):
            transcripts.append(transcript_file)
        return transcripts

    @staticmethod
    def _df_to_dict(df: pd.DataFrame, index_col: str) -> t.Dict[str, t.Any]:
        """Convert a DataFrame to a dictionary of dictionaries, with the given column as the index.

        Retains the index column within the dictionary.

        Args:
            df: DataFrame to convert.
            index_col: Column to use as the index.

        Returns:
            Dictionary of dictionaries.

        Raises:
            ValueError: If index column not found in DataFrame or non-unique values found.
        """
        if index_col not in df.columns:
            raise ValueError(f"Index column {index_col} not found in DataFrame.")
        if df[index_col].isnull().any():
            _LOGGER.warning(
                f"Found {df[index_col].isnull().sum()} null value(s) for {index_col}. Removing."
            )
            df = df.dropna(subset=[index_col])

        non_unique = df[df[index_col].duplicated(keep=False)]
        if df[index_col].nunique() < df.shape[0]:
            raise ValueError(f"Non-unique {index_col} values found. {non_unique}")
        

        # *copy* the given column into the index, preserving the original column
        # so that it is output in the later call to to_dict()
        df.index = df[index_col]

        return df.to_dict("index")

    @staticmethod
    def _dataframe_to_tsv(df: pd.DataFrame, tsv_path: str) -> None:
        """Construct a TSV file from a DataFrame.

        Args:
            df: DataFrame containing the data.
            tsv_path: Path to the output TSV file.
        """
        # Save the combined DataFrame to a TSV file
        df.to_csv(tsv_path, sep="\t", index=False)
        _LOGGER.info(f"TSV file with {df.shape[0]} rows created and saved to: {tsv_path}")

    @staticmethod
    def _load_reproschema(
        reproschema_file: Path,
        reproschema_folder: Path,
    ) -> t.Dict[str, t.Dict[str, t.Any]]:
        with reproschema_file.open("r", encoding="utf-8") as fp:
            schema_json = json.load(fp)

        protocol_order = schema_json.get("ui", {}).get("order")

        commit_sha = get_commit_sha(reproschema_folder)

        activities = {}
        for rel_path in protocol_order:
            # activities are relative to the reproschema schema file itself
            activity_path = reproschema_file.parent.joinpath(rel_path).resolve()
            if not activity_path.exists():
                _LOGGER.warning("Skipping missing activity %s", rel_path)
                continue

            activity_json = json.loads(activity_path.read_text())
            activity_id = activity_json.get("id")

            payload = build_activity_payload(
                activity_json=activity_json,
                activity_path=activity_path,
                reproschema_folder=reproschema_folder,
                commit_sha=commit_sha,
            )

            activities[activity_id] = payload

        return activities

    @staticmethod
    def _load_reorganization_file(drop_deleted_columns: bool = True) -> pd.DataFrame:
        """Load the reproschema reorganization CSV file.

        Returns:
            DataFrame containing the reorganization data.
        """
        reorganization_file = files("b2aiprep.prepare.resources").joinpath("bids_field_organization.csv")
        df = pd.read_csv(reorganization_file, sep=',', header=0)
        if drop_deleted_columns:
            df = df.loc[df['delete'].str.upper() != 'YES']
        return df

    @staticmethod
    def _find_redcap_checkbox_columns(
        df: pd.DataFrame,
    ) -> t.Dict[str, t.List[str]]:
        """Find RedCap checkbox columns in the DataFrame.

        Args:
            df: DataFrame containing the data.

        Returns:
            List of base column names for checkbox fields.
        """
        checkbox_columns = defaultdict(list)
        pattern = re.compile(r'^(?P<base>.+?)___(?P<suffix>.+)$')
        for col in df.columns:
            match = pattern.match(col)
            if match:
                base_col = match.group('base')
                checkbox_columns[base_col].append(col)
        return checkbox_columns

    @staticmethod
    def _fix_disjoint_demographic_rows(
        df: pd.DataFrame,
        id_col: str,
        demographic_col: str,
        schema_name: str = 'demographics'
    ) -> None:
        """Fix disjoint demographic rows by propagating known values.

        Args:
            df: DataFrame containing the data.
            id_col: Column name for participant ID.
            demographic_col: Column name for the demographic variable to fix.
        """
        # carry-forward age column values within each participant
        # use groupby-apply-transform to ensure we do not mix values across participants
        df[demographic_col] = df.groupby(id_col)[demographic_col].transform(
            lambda x: x.ffill().bfill()
        )

        # drop rows where the *only* non-null value is id_col + age
        # this avoids dropping rows where other data is present
        def is_only_id_and_demo(row: pd.Series) -> bool:
            non_null_cols = row.dropna().index.tolist()
            if len(non_null_cols) == 2 and id_col in non_null_cols and demographic_col in non_null_cols:
                return True
            return False
        mask_only_id_and_demo = df.apply(is_only_id_and_demo, axis=1)
        num_dropped = mask_only_id_and_demo.sum()
        if num_dropped > 0:
            _LOGGER.info((f"Fixing {schema_name} by dropping {num_dropped}/{df.shape[0]} rows with only "
                         f"{id_col} and {demographic_col} present."))
            df.drop(index=df[mask_only_id_and_demo].index, inplace=True)
        
    @staticmethod
    def _construct_phenotype_from_reproschema(
        df: pd.DataFrame,
        output_dir: str,
        clean_phenotype_data: bool = True
    ) -> None:
        """Construct TSV/JSON files from a source ReproSchema folder.

        Args:
            df: DataFrame containing the data.
            output_dir: Directory where the TSV files will be saved.
            clean_phenotype_data: Whether to clean the phenotype data (default: True).
        """

        # We will ignore data dictionary columns when there are corresponding columns
        # in the dataframe with the suffix "___[text]". These are multi-checkbox columns.
        # Only the option responses are kept, the main column does not exist in the data,
        # only in the data dictionary.
        checkbox_columns = BIDSDataset._find_redcap_checkbox_columns(df)

        # Rename repeat instruments to their standard names
        instrument_name_to_schema_name = {
            repeat_instrument.value.schema_name_pretty: repeat_instrument.value.schema_name
            for repeat_instrument in RepeatInstrument.__iter__()
        }
        df['schema_name_source'] = df['redcap_repeat_instrument'].map(instrument_name_to_schema_name)
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Load reproschema file

        source_path = files("b2aiprep.redcap2rs")
        if source_path.joinpath('b2ai-redcap2rs_schema').is_file():
            resolved_schema_file = source_path.joinpath('b2ai-redcap2rs_schema')
            reproschema_folder = Path(resolved_schema_file).parent.resolve()
        elif (source_path / 'b2ai-redcap2rs' / 'b2ai-redcap2rs_schema').is_file():
            resolved_schema_file = source_path / 'b2ai-redcap2rs' / 'b2ai-redcap2rs_schema'
            reproschema_folder = Path(resolved_schema_file).parent.parent.resolve()
        else:
            raise FileNotFoundError(
                f"Could not find 'b2ai-redcap2rs_schema' in source directory: {source_path}"
            )

        schemas = BIDSDataset._load_reproschema(resolved_schema_file, reproschema_folder)

        # create an index for data_element -> schema
        element_to_schema = {}
        for schema_name, data in schemas.items():
            for element_name in data['data_elements'].keys():
                element_to_schema[element_name] = schema_name

                # add in the checkbox columns which are not natively listed as individual
                # questions in the reproschema activities
                if element_name in checkbox_columns:
                    for checkbox_column in checkbox_columns[element_name]:
                        element_to_schema[checkbox_column] = schema_name

        # with all the reproschema activities defined, we now parse our manual reorganization
        # this is a CSV with:
        #   schema_name_source, column_name_source
        # ... used to identify the source reproschema element, and:
        #   schema_name, column_name, group, description
        # ... used to arrange & describe the output in the phenotype/ folder.
        # the overall goal is to remap from schema_name_source -> schema_name
        #   (the schema_name becomes the filename)
        # and to map from column_name_source -> column_name
        #   (the column_name becomes the column in the TSV file)
        df_reorg = BIDSDataset._load_reorganization_file(drop_deleted_columns=False)

        # Track inclusion/exclusion for a final report.
        # Note: columns are tracked using their *source* names (i.e., RedCap/df column names).
        df_deleted = df_reorg.loc[df_reorg['delete'].str.upper() == 'YES']
        df_reorg_active = df_reorg.loc[df_reorg['delete'].str.upper() != 'YES']

        _norm = lambda c: str(c)
        df_cols = {_norm(c) for c in df.columns}

        reorg_all_cols = {_norm(c) for c in df_reorg['column_name_source'].dropna().tolist()}
        cols_for_deletion = {_norm(c) for c in df_deleted['column_name_source'].dropna().tolist()}
        cols_for_adding = {_norm(c) for c in df_reorg_active['column_name_source'].dropna().tolist()}

        # the rest we will track as we go
        included_cols: t.Set[str] = set()
        missing_in_df_cols: t.Set[str] = set()
        redcap_group_cols: t.Set[str] = set()

        df_reorg = df_reorg_active

        element_used = {} # keep track of whether we have used an element, for logging later.
        payload = {
            "description": "",
            "data_elements": {},
            # this variable will track the name of the original columns in RedCap
            "columns_for_indexing": [],
            # this variable will track the name of the *new* columns in the output df
            "columns_for_output": [],
            # group is popped before saving
            "group": "",
            # source schema name is used to filter rows
            "schema_name_source": [],
        }
        updated_schemas = defaultdict(lambda: deepcopy(payload))
        for updated_schema_name, group in df_reorg.groupby('schema_name'):
            column_mapping = group.set_index('column_name_source').to_dict(orient='index')
            for column, updated_data in column_mapping.items():
                col_norm = _norm(column)
                if col_norm not in df_cols:
                    if col_norm in checkbox_columns:
                        # skip the main checkbox column if we have the ___ option columns
                        _LOGGER.debug(
                            f'Skipping RedCap checkbox main column "{column}" as option columns found.'
                        )
                        redcap_group_cols.add(col_norm)
                        continue
                    _LOGGER.warning(f'Requested output for "{column}", but this column was not found in the source df.')
                    missing_in_df_cols.add(col_norm)
                    continue
                included_cols.add(col_norm)
                
                # the source schema is defined based on the element itself;
                # we do not need the schema_name_source column, but it is kept for ease of reading the CSV.
                schema_to_use = element_to_schema[column]
                
                if '___' in column:
                    column_base, column_choice = column.rsplit('___', maxsplit=1)
                else:
                    column_base = column
                    column_choice = None
                if column_base in checkbox_columns:
                    data_element = copy(schemas[schema_to_use]["data_elements"][column_base])
                    # reduce the choices to just the choice for this checkbox
                    data_element['choices'] = [
                        choice for choice in data_element.get('choices', [])
                        if str(choice.get('value')) == str(column_choice)
                    ]
                    if clean_phenotype_data:
                        # for checkbox columns, we convert to integer 0/1
                        data_element['valueType'] = ['xsd:integer']
                else:
                    # populate the detailed metadata for this column
                    data_element = copy(schemas[schema_to_use]["data_elements"][column])
                if "description" in updated_data and (updated_data["description"] != ""):
                    description = updated_data["description"]
                elif "description" in data_element and (data_element["description"] != ""):
                    description = data_element["description"]
                else:
                    description = data_element.get("question", "").get("en", "")
                data_element["description"] = description
                new_element_name = updated_data["column_name"]

                updated_schema_name = updated_data["schema_name"]
                updated_schemas[updated_schema_name]['columns_for_indexing'].append(column)
                updated_schemas[updated_schema_name]['columns_for_output'].append(new_element_name)
                updated_schemas[updated_schema_name]['schema_name_source'].append(updated_data["schema_name_source"])

                # update the payload so we have a reproschema json for this df
                updated_schemas[updated_schema_name]["data_elements"][new_element_name] = data_element
                updated_schemas[updated_schema_name]["group"] = updated_data["group"]
                element_used[column] = True

        # with our full updated_schemas dict prepared, we can iterate through the *new* schema names
        # and output a single folder for each
        for schema_name, payload in updated_schemas.items():
            columns_for_indexing = payload.pop("columns_for_indexing")
            columns_for_output = payload.pop("columns_for_output")
            schema_name_sources = set(payload.pop("schema_name_source"))
            group = payload.pop("group")
            if "record_id" not in columns_for_indexing:
                columns_for_indexing = ["record_id"] + columns_for_indexing
                columns_for_output = ["participant_id"] + columns_for_output

                # record_id is implicitly included in outputs when missing from the reorg mapping.
                if "record_id" in df_cols:
                    included_cols.add("record_id")

                # add record_id to the data elements if missing, add it at the beginning
                payload["data_elements"] = {
                    "participant_id": {
                        "description": "A unique identifier for the participant.",
                        "valueType": [
                            "xsd:string"
                        ]
                    },
                    **payload["data_elements"],
                }
            # we now extract the sub-dataframe from our source redcap data and output it to tsv
            # filter df to only rows with the relevant repeat_instruments
            selected_df = df.loc[:, columns_for_indexing]
            # next up, we subselect the rows used for this set of columns ("repeat instrument").
            # but first, verify that we have all of the source schema names in our df
            # this is defensive in case we are missing an entire repeat_instrument from the source df.
            # in that case we will use all rows and drop those with all NaN later.
            if schema_name_sources:
                have_all_schema_names = all(
                    source_name in df['schema_name_source'].unique()
                    for source_name in schema_name_sources
                )
                if have_all_schema_names:
                    selected_df = selected_df.loc[
                        df['schema_name_source'].isin(schema_name_sources)
                    ]

            # Rename columns based on the reorganization mapping.
            if len(columns_for_indexing) != len(columns_for_output):
                raise ValueError(
                    f"Schema {schema_name}: columns_for_indexing ({len(columns_for_indexing)}) and "
                    f"columns_for_output ({len(columns_for_output)}) length mismatch."
                )

            rename_map = dict(zip(columns_for_indexing, columns_for_output))
            if rename_map.get("record_id") not in (None, "participant_id"):
                _LOGGER.warning(
                    f"Schema {schema_name}: overriding record_id rename target "
                    f"{rename_map.get('record_id')!r} -> 'participant_id'."
                )
                rename_map["record_id"] = "participant_id"

            # Protect against accidentally collapsing columns.
            output_cols = list(rename_map.values())
            dupes = sorted({c for c in output_cols if output_cols.count(c) > 1})
            if dupes:
                raise ValueError(
                    f"Schema {schema_name}: duplicate output column names after mapping: {dupes}. "
                    "Check bids_field_organization.csv for collisions."
                )

            selected_df = selected_df.rename(columns=rename_map)
            # Keep output column order stable and aligned to metadata.
            selected_df = selected_df[output_cols]
            id_col = "participant_id"

            updated_schema = {schema_name: payload}
            if clean_phenotype_data:
                selected_df, updated_schema = BIDSDataset._clean_phenotype_data(selected_df, updated_schema)

            # Remove rows where the only non-null value is record_id/participant_id
            selected_df = selected_df.dropna(how="all", subset=[col for col in selected_df.columns if col != id_col])
            if selected_df.empty:
                _LOGGER.warning(f"No data remaining after dropping empty rows for {schema_name}")
                continue

            if 'age' in selected_df.columns:
                BIDSDataset._fix_disjoint_demographic_rows(selected_df, id_col, 'age', schema_name=schema_name)
                selected_df = selected_df.dropna(how="all", subset=[col for col in selected_df.columns if col != id_col])
                if selected_df.empty:
                    _LOGGER.warning(f"No data remaining after dropping empty rows for {schema_name}")
                    continue

            # Output to a TSV/JSON file.
            filename = f'{schema_name}.json'
            if group != "":
                output_dir_grouped = os.path.join(output_dir, group)
                os.makedirs(output_dir_grouped, exist_ok=True)
            else:
                output_dir_grouped = output_dir
            BIDSDataset._dataframe_to_tsv(
                selected_df,
                os.path.join(output_dir_grouped, filename.replace(".json", ".tsv"))
            )
            with open(os.path.join(output_dir_grouped, filename), "w") as f:
                json.dump(updated_schema, f, indent=2)

        # Final report: included/excluded columns (by source column name).
        # our later loops only go through reorg columns, so calculate what we're missing now
        excluded_in_df_not_in_reorg = df_cols - reorg_all_cols

        _LOGGER.info(
            "RedCap Dataframe column report: total=%d, included=%d, deleted_intentionally=%d, only_in_df=%d",
            len(df_cols),
            len(included_cols.intersection(df_cols)),
            len(cols_for_deletion.intersection(df_cols)),
            len(excluded_in_df_not_in_reorg),
        )
        _LOGGER.info(
            "RedCap ReproSchema expected column report: total=%d, included=%d, redcap_group_general_q=%d, deleted_intentionally=%d, missing_in_df=%d",
            df_reorg_active.shape[0] + df_deleted.shape[0],
            len(included_cols),
            len(redcap_group_cols),
            len(cols_for_deletion),
            len(missing_in_df_cols),
        )
        _LOGGER.debug(f"Included columns: {sorted(included_cols)}")
        _LOGGER.debug(f"Excluded (missing in df) columns: {sorted(missing_in_df_cols)}")
        _LOGGER.debug(f"Excluded (redcap group) columns: {sorted(redcap_group_cols)}")
        _LOGGER.debug(f"Excluded (deleted) columns: {sorted(cols_for_deletion)}")
        _LOGGER.debug(f"Excluded (in df but not in reorg) columns: {sorted(excluded_in_df_not_in_reorg)}")

    @staticmethod
    def _get_instrument_for_name(name: str) -> Instrument:
        """Get instrument for a given name.

        Args:
            name: The instrument name.

        Returns:
            The instrument object.

        Raises:
            ValueError: If no instrument found for the given name.
        """
        for repeat_instrument in RepeatInstrument:
            instrument = repeat_instrument.value
            if instrument.name == name:
                return instrument
        raise ValueError(f"No instrument found for value {name}")

    @staticmethod
    def _write_pydantic_model_to_bids_file(
        output_path: Path,
        data: dict,
        schema_name: str,
        subject_id: str,
        session_id: t.Optional[str] = None,
        task_name: t.Optional[str] = None,
        recording_name: t.Optional[str] = None,
    ):
        """Write a Pydantic model (presumably a FHIR resource) to a JSON file.

        Follows the BIDS file name conventions.

        Args:
            output_path: The path to write the file to.
            data: The data to write.
            schema_name: The name of the schema.
            subject_id: The subject ID.
            session_id: The session ID.
            task_name: The task name.
            recording_name: The recording name.
        """
        # sub-<participant_id>_ses-<session_id>_task-<task_name>_run-_metadata.json
        filename = f"sub-{subject_id}"
        if pd.notna(session_id):
            session_id = str(session_id).replace(" ", "-").replace("_", "-")
            filename += f"_ses-{session_id}"
        if pd.notna(task_name):
            task_name = str(task_name).replace(" ", "-").replace("_", "-")
            if pd.notna(recording_name):
                task_name = str(recording_name).replace(" ", "-").replace("_", "-")
            filename += f"_task-{task_name}"

        schema_name = schema_name.replace(" ", "-").replace("schema", "").replace("_", "-")
        schema_name = schema_name + "-metadata"
        filename += f"_{schema_name}.json"

        if not output_path.exists():
            output_path.mkdir(parents=True, exist_ok=False)
        with open(output_path / filename, "w") as f:
            f.write(json.dumps(data, indent=2))

    @staticmethod
    def _output_participant_data_to_metadata_file(
        participant: dict, outdir: Path, audio_files_by_recording: t.Optional[t.Dict[str, Path]] = None,
        max_audio_workers: int = 16, sanitize_audio_format: bool = False, audio_descriptor_dict:OrderedDict = {}
    ):
        """Output participant data to FHIR format.

        Args:
            participant: The participant data dictionary.
            outdir: The output directory path.
            audio_files_by_recording: Dictionary mapping recording IDs to audio file paths (optional).
            max_audio_workers: Number of parallel threads for audio copying (default: 16).
            sanitize_audio_format: Standardize to 16KHz mono-audio
        """
        participant_id = participant["record_id"]
        subject_path = outdir / f"sub-{participant_id}"

        # TODO: prepare a Patient resource to use as the reference for each questionnaire
        # patient = create_fhir_patient(participant)

        session_instrument = BIDSDataset._get_instrument_for_name("sessions")
        task_instrument = BIDSDataset._get_instrument_for_name("acoustic_tasks")
        recording_instrument = BIDSDataset._get_instrument_for_name("recordings")

        # Collect all audio copy tasks for parallel execution
        audio_copy_tasks = []

        # validated questionnaires are asked per session
        sessions_rows = []
        
        for session in participant["sessions"]:
            sessions_row = {key: session[key] for key in session_instrument.columns}
            sessions_rows.append(sessions_row)
            session_id = session["session_id"]
            # TODO: prepare a session resource to use as the encounter reference for
            # each session questionnaire
            session_path = subject_path / f"ses-{session_id}"
            audio_output_path = session_path / "audio"
            if not audio_output_path.exists():
                audio_output_path.mkdir(parents=True, exist_ok=True)
    
            # multiple acoustic tasks are asked per session
            for task in session["acoustic_tasks"]:
                if task is None:
                    continue
                
                # Handle NaN/None values in acoustic_task_name
                acoustic_task_name = task.get("acoustic_task_name")
                if pd.isna(acoustic_task_name):
                    _LOGGER.warning(f"Skipping task with missing acoustic_task_name for participant {participant_id}, session {session_id}")
                    continue
                
                acoustic_task_name = acoustic_task_name.replace(" ", "-").replace("_", "-")
                meta_data = convert_response_to_bids_metadata(
                    task,
                    questionnaire_name=task_instrument.name,
                    mapping_name=task_instrument.schema_name_clobbered,
                    columns=task_instrument.columns,
                    audio_task_descriptions=audio_descriptor_dict,
                )
                BIDSDataset._write_pydantic_model_to_bids_file(
                    audio_output_path,
                    meta_data,
                    schema_name=task_instrument.schema_name_clobbered,
                    subject_id=participant_id,
                    session_id=session_id,
                    task_name=acoustic_task_name,
                )

                # prefix is used to name audio files, if they are copied over
                prefix = f"sub-{participant_id}_ses-{session_id}"
                # there may be more than one recording per acoustic task
                for recording in task["recordings"]:
                    meta_data = convert_response_to_bids_metadata(
                        recording,
                        questionnaire_name=recording_instrument.name,
                        mapping_name=recording_instrument.schema_name_clobbered,
                        columns=recording_instrument.columns,
                        audio_task_descriptions=audio_descriptor_dict
                    )
                    BIDSDataset._write_pydantic_model_to_bids_file(
                        audio_output_path,
                        meta_data,
                        schema_name=recording_instrument.schema_name_clobbered,
                        subject_id=participant_id,
                        session_id=session_id,
                        task_name=acoustic_task_name,
                        recording_name=recording["recording_name"],
                    )
                    if audio_files_by_recording is None:
                        continue
                    audio_file = audio_files_by_recording.get(recording["recording_id"], None)

                    if not audio_file:
                        continue

                    # Schedule audio copy (to be executed in parallel later)
                    ext = audio_file.suffix
                    recording_name = recording["recording_name"].replace(" ", "-").replace("_", "-")
                    audio_file_destination = (
                        audio_output_path / f"{prefix}_task-{recording_name}{ext}"
                    )
                    
                    if not audio_file_destination.exists():
                        audio_copy_tasks.append((audio_file, audio_file_destination))

        # Execute all audio copies in parallel
        if audio_copy_tasks:
            _copy_audio_files_parallel(audio_copy_tasks, max_workers=max_audio_workers, sanitize_audio_format=sanitize_audio_format)

        # Save sessions.tsv
        sessions_df = pd.DataFrame(sessions_rows)
        if not os.path.exists(subject_path):
            os.mkdir(subject_path)
        sessions_tsv_path = subject_path / "sessions.tsv"
        sessions_df.to_csv(sessions_tsv_path, sep="\t", index=False)

    @staticmethod
    def load_phenotype_data(phenotype_filepath: Path) -> t.Tuple[pd.DataFrame, t.Dict[str, t.Any]]:
        """
        Load phenotype data from TSV and JSON files.
        
        Args:
            phenotype_filepath: Path to the phenotype file (without extension)
            
        Returns:
            Tuple of (DataFrame, phenotype_metadata_dict)
        """
        phenotype_name = phenotype_filepath.stem
        # Load TSV and JSON files
        df = pd.read_csv(phenotype_filepath.with_suffix('.tsv'), sep="\t")
        with open(phenotype_filepath.with_suffix('.json'), "r") as f:
            phenotype = json.load(f)
            data_elements = {}
            for schema in phenotype:
                data_elements.update(phenotype[schema].get("data_elements", {}))
            phenotype = data_elements

        # Handle nested phenotype structure which occurs in ReproSchema activities
        if len(phenotype) == 1:
            only_key = next(iter(phenotype))
            if 'data_elements' in phenotype[only_key]:
                phenotype = phenotype[only_key]['data_elements']

        # Add record_id to phenotype if missing
        if df.shape[1] > 0:
            phenotype_has_id = 'record_id' in list(phenotype.keys()) or 'participant_id' in list(phenotype.keys())
            df_has_id = 'record_id' in df.columns or 'participant_id' in df.columns
            if not phenotype_has_id and not df_has_id:
                phenotype = BIDSDataset._add_record_id_to_phenotype(phenotype)

        # Validate column count
        if len(phenotype) != df.shape[1]:
            _LOGGER.warning(
                f"Phenotype {phenotype_name} has {len(phenotype)} columns, but the data has {df.shape[1]} columns."
            )

        return df, phenotype

    @staticmethod
    def _map_series(series: pd.Series, mapping: dict) -> pd.Series:
        """
        Map values in a pandas Series using a provided mapping dictionary. Log any issues arising.
        
        Args:
            series: The pandas Series to map.
            mapping: The mapping dictionary.
        Returns:
            The mapped pandas Series.
        """
        ids_before = series.copy()
        series = series.map(mapping).fillna(series)
        idxUnchanged = ids_before == series
        n_unchanged = idxUnchanged.sum()
        proportion = ((len(ids_before) - n_unchanged) / len(ids_before)) if len(ids_before) > 0 else 0
        _LOGGER.debug(f"Remapped {proportion:3.1%} ({len(ids_before) - n_unchanged}/{len(ids_before)}) of IDs for '{series.name}'")
        if n_unchanged > 0:
            _LOGGER.warning((
                f"A subset of IDs ({1-proportion:3.1%}, {n_unchanged}) are missing "
                f"remapping for '{series.name}': {set(ids_before[idxUnchanged])}"
            ))
        return series

    @staticmethod
    def _deidentify_phenotype(df: pd.DataFrame, phenotype: dict, participant_ids_to_remove: t.List[str] = [], participant_ids_to_remap: dict = {}, participant_session_id_to_remap: dict = {}) -> t.Tuple[pd.DataFrame, dict]:
        """
        Apply deidentification operations to phenotype data.
        
        Args:
            df: DataFrame containing the phenotype data
            phenotype: Dictionary containing the phenotype metadata
            
        Returns:
            Tuple of (deidentified_df, deidentified_phenotype_dict)
        """
        # Rename record_id to participant_id
        if "record_id" in df.columns:
            df, phenotype = BIDSDataset._rename_record_id_to_participant_id(df, phenotype)

        # Remove participants
        idx = df["participant_id"].isin(participant_ids_to_remove)
        if idx.any():
            _LOGGER.info(f"Removing {idx.sum()} participants from phenotype data.")
            df = df.loc[~idx]

        # Remap IDs
        if participant_ids_to_remap and "participant_id" in df.columns:
            remap_partial = partial(remap_id, id_mapping=participant_ids_to_remap)
            df.loc[:, "participant_id"] = BIDSDataset._map_series(df["participant_id"], remap_partial)

        if participant_session_id_to_remap:
            remap_partial = partial(remap_id, id_mapping=participant_session_id_to_remap, id_type="session")
            for col in df.columns:
                if "session_id" in col:
                    df.loc[:, col] = BIDSDataset._map_series(df[col], remap_partial)

        # Remove sensitive columns
        df, phenotype = BIDSDataset._remove_sensitive_columns(df, phenotype)

        # Sanitize task labels in task phenotype tables (e.g., phenotype/task/acoustic_task.tsv)
        if "acoustic_task_name" in df.columns:
            df.loc[:, "acoustic_task_name"] = df["acoustic_task_name"].apply(
                lambda v: normalize_task_label(v) if pd.notna(v) else v
            )

        return df, phenotype

    @staticmethod
    def _is_redcap_group(column: str) -> bool:
        """Check if a column is a RedCap group column."""
        pattern = re.compile(r'^(?P<base>.+?)___(?P<suffix>.+)$')
        match = pattern.match(column)
        return match is not None

    @staticmethod
    def _clean_phenotype_data(df: pd.DataFrame, phenotype: dict) -> t.Tuple[pd.DataFrame, dict]:
        """
        Apply data cleaning operations to phenotype data.
        
        Args:
            df: DataFrame containing the phenotype data
            phenotype: Dictionary containing the phenotype metadata
            
        Returns:
            Tuple of (cleaned_df, cleaned_phenotype_dict)
        """
        # Fix alcohol column date values
        df = BIDSDataset._fix_alcohol_column(df)

        for c in df.columns:
            if BIDSDataset._is_redcap_group(c):
                # convert from whatever the text is to 1
                if df[c].dropna().nunique() > 1:
                    _LOGGER.warning(
                        f"RedCap checkbox column {c} has unexpected non-binary values: "
                        f"{df[c].dropna().unique().tolist()}. Converting to binary."
                    )
                df[c] = df[c].apply(lambda x: 1 if pd.notna(x) and str(x).strip() != "" else np.nan).astype(pd.Int8Dtype())
                # TODO: phenotype changes for checkbox columns?
        # Warn about empty columns - but keep them as some are expected
        BIDSDataset._warn_about_empty_columns(df, phenotype)
        
        # Add derived columns
        if ("gender_identity" in df.columns) and ("specify_gender_identity" in df.columns):
            df, phenotype = BIDSDataset._add_sex_at_birth_column(df, phenotype)

        return df, phenotype

    @staticmethod
    def _fix_alcohol_column(df: pd.DataFrame) -> pd.DataFrame:
        """Fix known date values in the alcohol_amt column."""
        if "alcohol_amt" in df:
            date_fix_map = {
                "4-Mar": "3 - 4",
                "6-May": "5 - 6",
                "9-Jul": "7 - 9",
            }
            df["alcohol_amt"] = df["alcohol_amt"].apply(
                lambda x: date_fix_map[x] if x in date_fix_map else x
            )
        return df

    @staticmethod
    def _warn_about_empty_columns(df: pd.DataFrame, phenotype: dict) -> None:
        """Warn about columns that are empty."""
        empty_columns = []
        for column in df.columns:
            if df[column].isnull().all() and BIDSDataset._is_redcap_group(column) is False:
                empty_columns.append(column)
        
        if empty_columns:
            _LOGGER.warning(f"Found {len(empty_columns)} empty columns: {empty_columns}")

    @staticmethod
    def _remove_sensitive_columns(df: pd.DataFrame, phenotype: dict) -> t.Tuple[pd.DataFrame, dict]:
        """Remove columns with sensitive data (free-text, geo-location, etc)."""

        # TODO: Revisit this list. The deidentification is now implicitly applied by the
        # use of bids_field_reorganization.csv to select only desired columns.
        # This is kept here for now as an extra layer of safety, particularly for pediatrics
        # which has not had the RedCap dataset imported/tested yet. In the future, this code may
        # remove useful non-PHI columns, so care should be taken.
        columns_to_drop = [
            "state_province",
            "zipcode",
            "other_edu_level",
            "others_household_specify",
            "diagnosis_alz_dementia_mci_ca_rudas_score",
            "diagnosis_alz_dementia_mci_ca_mmse_score",
            "diagnosis_alz_dementia_mci_ca_moca_score",
            "diagnosis_alz_dementia_mci_ca_adas_cog_score",
            "diagnosis_alz_dementia_mci_ca_other",
            "diagnosis_alz_dementia_mci_ca_other_score",
            "diagnosis_parkinsons_ma_updrs_part_i_score",
            "diagnosis_parkinsons_ma_updrs_part_ii_score",
            "diagnosis_parkinsons_ma_updrs_part_iii_score",
            "diagnosis_parkinsons_ma_updrs_part_iv_score",
            "diagnosis_parkinsons_non_motor_symptoms_yes",
            "traumatic_event",
            # pediatric columns
            "city",
            "state_province",
            "peds_zipcode",
            "peds_other_race_specify",
            "peds_other_primary_language",
            "peds_mc_conditions_other_specified",
            "peds_mc_chronic_medical_condition_specified",
            "peds_mc_genetic_syndromes_specified",
            "peds_mc_hospitalized_specified",
            "peds_mc_allergies_specified",
            "peds_mc_dif_swallowing_specified",
            "peds_mc_ear_inf_ant_py_specified",
            "peds_mc_etp_procedure",
            "peds_mc_eval_voice_swal_c_specified",
            "peds_mc_ft_specified",
            "peds_mc_reflux_specified",
            "peds_mc_hl_specified",
            "peds_mc_hw_voice_2_w_specified",
            "peds_mc_no_surgeries_procedure",
            "peds_mc_stridor_specified",
            "peds_mc_ox_sup_specified",
            "peds_mc_meds_specified",
            "peds_mc_v_dis_specified",
            "peds_mc_a_therapy_specified",
            "peds_mc_surgery_t_vc_a_specified",
            "peds_mc_fr_inf_tons_specified",
            "peds_mc_fr_v_f_specified",
            # below could be considered for inclusion in the future
            "peds_mc_tonsillectomy_date",
            "peds_mc_adenoidectomy_date",
            "peds_mc_neck_mass_branchial_cleft_cyst_surgery_date",
            "peds_mc_etp_procedure_date",
            "peds_mc_neck_mass_dermoid_cyst_surgery_date",
            "peds_mc_neck_mass_enlarged_lymph_node_surgery_date",
            "peds_mc_lingual_tonsillectomy_date",
            "peds_mc_no_surgeries_procedure_date",
            "peds_mc_neck_mass_thyroglossal_duct_cyst_surgery_date",
            "peds_mc_neck_mass_hyroid_nodule_or_cancer_surgery_date",
            "peds_mc_v_dis_specified"
        ]
        df, phenotype = BIDSDataset._drop_columns_from_df_and_data_dict(
            df, phenotype, columns_to_drop, "Removing PHI containing columns"
        )

        if 'gender_identity' in df.columns:
            _LOGGER.info(f"sex_at_birth value_counts: {df['sex_at_birth'].value_counts(dropna=False).to_dict()}")
            _LOGGER.info(f"gender_identity value_counts: {df['gender_identity'].value_counts(dropna=False).to_dict()}")
            df, phenotype = BIDSDataset._drop_columns_from_df_and_data_dict(
                df, phenotype, ["gender_identity"], "Remove sensitive demographic columns"
            )
        
        return df, phenotype

    @staticmethod
    def _drop_columns_from_df_and_data_dict(
        df: pd.DataFrame, phenotype: dict, columns_to_drop: t.List[str], message: str
    ) -> t.Tuple[pd.DataFrame, dict]:
        """Drop columns from the DataFrame and phenotype dictionary."""
        columns_to_drop_in_df = [col for col in columns_to_drop if col in df.columns]
        
        if columns_to_drop_in_df:
            _LOGGER.info(f"{message}: {columns_to_drop_in_df}")
            df = df.drop(columns=columns_to_drop_in_df)
            phenotype = {k: v for k, v in phenotype.items() if k not in columns_to_drop_in_df}
        
        return df, phenotype

    @staticmethod
    def _add_record_id_to_phenotype(phenotype: dict) -> dict:
        """Add record_id to phenotype metadata if missing."""
        if 'record_id' in phenotype:
            return phenotype

        phenotype_updated = {
            'record_id': {
                "description": "Unique identifier for each participant."
            }
        }
        phenotype_updated.update(phenotype)
        return phenotype_updated

    @staticmethod
    def _rename_record_id_to_participant_id(df: pd.DataFrame, phenotype: dict) -> t.Tuple[pd.DataFrame, dict]:
        """Rename record_id column to participant_id."""
        phenotype_updated = {}
        for name, value in phenotype.items():
            if name == 'record_id':
                phenotype_updated['participant_id'] = value
                continue
            phenotype_updated[name] = value

        # Only rename if record_id exists and participant_id doesn't exist
        if 'record_id' in df.columns and 'participant_id' not in df.columns:
            df = df.rename(columns={"record_id": "participant_id"})
        elif 'record_id' in df.columns and 'participant_id' in df.columns:
            # If both exist, drop record_id since participant_id takes precedence
            df = df.drop(columns=['record_id'])
            # Remove record_id from phenotype_updated if it exists
            phenotype_updated = {k: v for k, v in phenotype_updated.items() if k != 'record_id'}
        
        return df, phenotype_updated

    @staticmethod
    def _add_sex_at_birth_column(df: pd.DataFrame, phenotype: dict) -> t.Tuple[pd.DataFrame, dict]:
        """Add sex_at_birth column derived from gender_identity and specify_gender_identity."""
        df["sex_at_birth"] = None
        for sex_at_birth in ["Male", "Female"]:
            idx = (
                df["gender_identity"].str.contains(sex_at_birth)
                & df["specify_gender_identity"].notnull()
            )
            df.loc[idx, "sex_at_birth"] = sex_at_birth

        # Re-order columns to place sex_at_birth after gender_identity
        phenotype_reordered = deepcopy(phenotype)
        first_key = next(iter(phenotype))
        # reset data elements for reordering
        phenotype_reordered[first_key]["data_elements"] = {}
        data_elements_updated = phenotype_reordered[first_key]["data_elements"]
        columns = []
        for c in df.columns:
            if c == "specify_gender_identity":
                # this continue implicitly removes this column from the output
                continue
            elif c == "gender_identity":
                columns.append(c)
                columns.append("sex_at_birth")
                data_elements_updated[c] = phenotype[first_key]["data_elements"][c]
                data_elements_updated["sex_at_birth"] = {
                    "description": "The sex at birth for the individual."
                }
            elif c == "sex_at_birth":
                continue
            else:
                columns.append(c)
                if c in phenotype[first_key]["data_elements"]:
                    data_elements_updated[c] = phenotype[first_key]["data_elements"][c]

        df = df[columns]
        return df, phenotype_reordered

    @staticmethod
    def _reduce_id_length(df: pd.DataFrame, id_name: str) -> pd.DataFrame:
        """Reduce the length of ID columns to 8 characters."""
        if id_name in df.columns:
            df = df.copy()  # Avoid SettingWithCopyWarning
            df[id_name] = df[id_name].apply(reduce_id_length)
        return df

    @staticmethod
    def load_remap_id_list(publish_config_dir: Path) -> t.Dict[str, str]:
        audio_to_remap_path = publish_config_dir / "id_remapping.json"
        if not audio_to_remap_path.exists():
            raise FileNotFoundError(f"ID remapping file {audio_to_remap_path} does not exist.")

        with open(audio_to_remap_path, 'r') as f:
            data = json.load(f)

        if not isinstance(data, dict):
            raise ValueError(f"ID remapping file {audio_to_remap_path} should contain a dict of participant_id:new_id.")

        return data
    
    @staticmethod
    def load_remap_session_id_list(publish_config_dir: Path) -> t.Dict[str, str]:
        session_id_to_remap_path = publish_config_dir / "session_id_remapping.json"
        if not session_id_to_remap_path.exists():
            raise FileNotFoundError(f"ID remapping file {session_id_to_remap_path} does not exist.")

        with open(session_id_to_remap_path, 'r') as f:
            data = json.load(f)

        if not isinstance(data, dict):
            raise ValueError(f"ID remapping file {session_id_to_remap_path} should contain a dict of session_id:new_id.")

        return data

    @staticmethod
    def map_sequential_session_ids(folder_path: Path, sequential: bool = False) ->  t.Dict[str, str]:
        """
            Function retrieves all session ids for all participants from the sessions.tsv files and maps them to an integer.
            If there are mutliple session exists for a participant, the seqiential will increase sequentially.
        """
        folder = Path(folder_path)
        session_files = list(folder.rglob("sessions.tsv"))
        
        # add in the session.tsv file from the phenotype folder
        # this *should* have all possible session ids, so the scan of sessions.tsv
        # is redundant / for safety only

        phenotype_session_files = list(folder.joinpath("phenotype").rglob("session.tsv"))
        session_files = session_files + phenotype_session_files

        if not session_files:
            _LOGGER.warning((
                f"No 'sessions.tsv' files found under {folder_path}"
                f" - cannot map session IDs."
            ))
            return {}

        df_list = []
        for session_file in session_files:
            try:
                df_session = pd.read_csv(session_file, sep="\t", dtype=str)
                if 'record_id' in df_session.columns and 'session_id' in df_session.columns:
                    df_list.append(df_session[['record_id', 'session_id']])
                elif 'participant_id' in df_session.columns and 'session_id' in df_session.columns:
                    df_session = df_session.rename(columns={"participant_id": "record_id"})
                    df_list.append(df_session[['record_id', 'session_id']])
                else:
                    _LOGGER.warning(f"'sessions.tsv' file {session_file} is missing required columns.")
            except Exception as e:
                _LOGGER.error(f"Error reading 'sessions.tsv' file {session_file}: {e}")
        
        if not df_list:
            _LOGGER.warning((
                f"No valid 'sessions.tsv' files with required columns found under {folder_path}"
                f" - cannot map session IDs."
            ))
            return {}
        combined = pd.concat(df_list).drop_duplicates().reset_index(drop=True)
        # Sort so all rows of a record_id appear together
        combined.sort_values(by=['record_id', 'session_id'], inplace=True)
        
        if sequential:
            # we create a sequential integer using the original session_id to sort
            combined['mapped_id'] = combined.groupby('record_id').cumcount() + 1
        else:
            # we assume the original session_id is a uuid, and we trim it to 8 characters
            # we do this in a way that ensures uniqueness within each participant
            combined['mapped_id'] = combined['session_id'].map(reduce_id_length)
            
            # check for duplicates *across* participants - this is not an issue, but may confuse
            # users, so we log a warning and restore the original session IDs up to 16 char
            # probability of collision for 8 char, 10,000 IDs is ~0.0116
            # probability of collision for 16 char, 1,000,000 IDs is ~2.7105e-8
            duplicates = combined.duplicated(subset=['mapped_id'], keep=False)
            if duplicates.any():
                # use 16 character session IDs for participants with duplicates
                duplicate_mapped_id = combined.loc[duplicates, 'mapped_id'].unique()
                for mapped_id in duplicate_mapped_id:
                    idx = combined['mapped_id'] == mapped_id
                    combined.loc[idx, 'mapped_id'] = combined.loc[idx, 'session_id'].map(
                        lambda x: reduce_id_length(x, length=16)
                    )
                
                n_dupe = duplicate_mapped_id.shape[0]
                _LOGGER.warning((
                    f"Session ID remapping resulted in duplicate session_id for {n_dupe} sessions. "
                    f"Using original session IDs for these cases."
                ))
        
        # enforce lower case as it is convention in BIDS
        combined['mapped_id'] = combined['mapped_id'].astype(str).str.lower()
        session_id_dict = combined.set_index('session_id')['mapped_id'].to_dict()
        _LOGGER.info(f"Created a session_id mapping of {len(session_id_dict):,} IDs.")
        return session_id_dict

    @staticmethod
    def load_participant_ids_to_remove(publish_config_dir: Path) -> t.List[str]:
        """Load list of participant IDs to remove from JSON file."""
        participant_to_remove_path = publish_config_dir / "participants_to_remove.json"
        if not participant_to_remove_path.exists():
            # If file doesn't exist, raise an error
            raise FileNotFoundError(f"Participant IDs to remove file {participant_to_remove_path} does not exist.")

        with open(participant_to_remove_path, 'r') as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError(f"Participant IDs to remove file {participant_to_remove_path} should contain a list of participant IDs.")
        
        _LOGGER.info(f"Loaded {len(data)} participant IDs to remove: {data}.")
        return data
    
    @staticmethod
    def load_audio_filestems_to_remove(publish_config_dir: Path) -> t.List[str]:
        """Load list of audio file stems to remove from JSON file."""
        audio_to_remove_path = publish_config_dir / "audio_filestems_to_remove.json"
        if not audio_to_remove_path.exists():
            # If file doesn't exist, raise an error
            raise FileNotFoundError(f"Audio filestems to remove file {audio_to_remove_path} does not exist.")

        with open(audio_to_remove_path, 'r') as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError(f"Audio filestems to remove file {audio_to_remove_path} should contain a list of audio file stems.")
        
        return data

    @staticmethod
    def load_audio_tasks_to_include(deidentify_config_dir: Path) -> t.List[str]:
        """Load list of audio tasks that are to be included."""
        audio_tasks_to_include_path = deidentify_config_dir / "audio_tasks_to_include.json"
        if not audio_tasks_to_include_path.exists():
            # If file doesn't exist, raise an error
            raise FileNotFoundError(f"Inclusion audio tasks file {audio_tasks_to_include_path} does not exist.")

        with open(audio_tasks_to_include_path, 'r') as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError(f"Inclusion audio tasks file {audio_tasks_to_include_path} should contain a list of audio task names.")
        
        return data

    def deidentify(self, outdir: t.Union[str, Path], deidentify_config_dir: Path, skip_audio: bool = False, skip_audio_features: bool = False, max_workers: int = 16) -> 'BIDSDataset':
        """
        Create a deidentified version of the BIDS dataset.
        
        This method performs the following deidentification steps:
        1. Load phenotype data
        2. Apply deidentification (remove participants, remap IDs, rename columns)
        3. Apply data cleaning (fix values, remove unwanted columns)
        4. Process audio files (if not skipped)
        5. Copy template files
        
        Args:
            outdir: Output directory for the deidentified dataset
            deidentify_config_dir: Config directory for doing deidentification
            skip_audio: If True, skip copying/processing audio files
            
        Returns:
            New BIDSDataset instance pointing to the deidentified directory
        """
        outdir = Path(outdir)
        outdir.mkdir(parents=True, exist_ok=False)  # Don't overwrite existing directories
        
        participant_ids_to_remap = BIDSDataset.load_remap_id_list(deidentify_config_dir)
        participant_ids_to_remove = BIDSDataset.load_participant_ids_to_remove(deidentify_config_dir)
        audio_filestems_to_remove = BIDSDataset.load_audio_filestems_to_remove(deidentify_config_dir)
        audio_tasks_to_include = BIDSDataset.load_audio_tasks_to_include(deidentify_config_dir)
        participant_session_id_to_remap = BIDSDataset.map_sequential_session_ids(self.data_path)

        # Allow users to specify filestems either in the original ID space (pre-deidentify)
        # or in the deidentified ID space (post-remap). We expand the configured list so
        # matching works regardless of which convention is used.
        audio_filestems_to_remove = BIDSDataset._expand_filestems_for_deidentification(
            audio_filestems_to_remove,
            participant_ids_to_remap=participant_ids_to_remap,
            participant_session_id_to_remap=participant_session_id_to_remap,
        )
        
        # Process phenotype directory if it exists
        phenotype_base_path = self.data_path.joinpath("phenotype")
        if phenotype_base_path.exists():
            _LOGGER.info("Processing phenotype data for deidentification.")
            phenotype_output_path = outdir.joinpath("phenotype")
            phenotype_output_path.mkdir(parents=True, exist_ok=True)
            
            for phenotype_filepath in phenotype_base_path.rglob("*.tsv"):
                _LOGGER.info(f"Processing {phenotype_filepath.stem}.")
                df_pheno, phenotype_dict = BIDSDataset.load_phenotype_data(phenotype_filepath)
                df_pheno, phenotype_dict = BIDSDataset._deidentify_phenotype(df_pheno, phenotype_dict, participant_ids_to_remove, participant_ids_to_remap, participant_session_id_to_remap)
                
                # Write out phenotype data and data dictionary
                phenotype_subdir = phenotype_output_path.joinpath(phenotype_filepath.parent.relative_to(phenotype_base_path))
                phenotype_subdir.mkdir(parents=True, exist_ok=True)
                df_pheno.to_csv(
                    phenotype_subdir.joinpath(f"{phenotype_filepath.stem}.tsv"), 
                    sep="\t", index=False
                )
                with open(phenotype_subdir.joinpath(f"{phenotype_filepath.stem}.json"), "w") as f:
                    json.dump(phenotype_dict, f, indent=2)
            _LOGGER.info("Finished processing phenotype data.")
        
        if not skip_audio:
            # Process audio files
            _LOGGER.info("Processing audio files for deidentification.")
            BIDSDataset._deidentify_audio_files(
                self.data_path, 
                outdir, 
                participant_ids_to_remove, 
                audio_filestems_to_remove,
                audio_tasks_to_include, 
                participant_ids_to_remap, 
                participant_session_id_to_remap,
                max_workers=max_workers,
            )
            _LOGGER.info("Finished processing audio files.")

        if not skip_audio_features:
            # Process audio files
            _LOGGER.info("Processing audio features for deidentification.")
            BIDSDataset._deidentify_feature_files(
                self.data_path,
                outdir,
                participant_ids_to_remove,
                audio_filestems_to_remove,
                audio_tasks_to_include,
                participant_ids_to_remap,
                participant_session_id_to_remap,
                max_workers=max_workers,
            )
            _LOGGER.info("Finished processing features.")

        # Process quality metrics file if it exists
        _LOGGER.info("Processing quality metrics for deidentification.")
        BIDSDataset._deidentify_quality_metrics(
            self.data_path,
            outdir,
            participant_ids_to_remove,
            audio_filestems_to_remove,
            audio_tasks_to_include,
            participant_ids_to_remap,
            participant_session_id_to_remap,
        )
        _LOGGER.info("Finished processing quality metrics.")

        # Copy over the standard BIDS template files if they exist
        for template_file in ["README.md", "CHANGES.md", "dataset_description.json"]:
            template_path = self.data_path.joinpath(template_file)
            if template_path.exists():
                shutil.copy(template_path, outdir)
        
        _LOGGER.info("Deidentification completed.")
        return BIDSDataset(outdir)

    @staticmethod
    def _collect_paths(
        data_path: Path,
        file_extension: str
    ) -> t.List[Path]:
        """Collect all file paths with the given extension from the dataset."""
        paths = get_paths(data_path, file_extension=file_extension)
        paths = [x["path"] for x in paths]
        
        # Sort audio paths for consistent processing
        paths = sorted(
            paths,
            # sort first by subject, then by task
            key=lambda x: (x.stem.split("_")[0], x.stem.split("_")[2]),
        )
        return paths

    @staticmethod
    def _apply_exclusion_list_to_filepaths(
        paths: t.List[Path],
        exclusion_list: t.List[str],
        exclusion_type: str = 'participant'
    ) -> t.List[Path]:
        """Remove filepaths based on overlap with a specified exclusion list."""
        n = len(paths)
        exclusion = set(exclusion_list)
        if len(exclusion) == 0:
            return paths
        def _canonical_recording_stem(stem: str) -> str:
            """Canonicalize a BIDS-like recording stem for matching.

            Many artifacts share a common "recording" identity, but append additional
            entities (e.g. "_features", "_run-1", "_rec-foo"). For exclusion matching,
            we treat the canonical identifier as everything up through the `task-...`
            entity, inclusive.
            """

            parts = stem.split("_")
            try:
                task_idx = next(i for i, part in enumerate(parts) if part.startswith("task-"))
            except StopIteration:
                return stem

            # Join up to and including the task entity (e.g. sub-..._ses-..._task-...)
            return "_".join(parts[: task_idx + 1])

        if exclusion_type == 'participant':
            paths = [
                x for x in paths
                if all(f"sub-{pid}" not in str(x) for pid in exclusion)
            ]
        elif exclusion_type == 'filename':
            # Normalize exclusions to recording filestems (strip extensions and known suffixes).
            canonical_exclusion = {
                _canonical_recording_stem(Path(excl).stem) for excl in exclusion
            }
            paths = [
                a for a in paths
                if _canonical_recording_stem(a.stem) not in canonical_exclusion
            ]
        elif exclusion_type == 'filestem_contains':
            paths = [
                a for a in paths
                if all(
                    normalize_task_label(excl) not in normalize_task_label(a.stem)
                    for excl in exclusion
                )
            ]
            # for better logging, add the list of exclusions to the exclusion type
            exclusion_type += f" ({', '.join(exclusion)})"
        else:
            raise ValueError(f"Unknown exclusion_type: {exclusion_type}")
        if len(paths) < n:
            _LOGGER.info(
                f"Removed {n - len(paths)} records due to exclusion: {exclusion_type}."
            )
        return paths

    @staticmethod
    def _grab_filepaths_list_to_include(
        paths: t.List[Path],
        inclusion_list: t.List[str],
    ) -> t.List[Path]:
        """Grabs filepaths based on overlap with a specified inclusion list."""
        n = len(paths)
        inclusion = set(inclusion_list)
        if len(inclusion) == 0:
            return []

        new_paths = []
        for file in paths:
            for incl in inclusion_list:
                if normalize_task_label(incl) in normalize_task_label(file.stem):
                    new_paths.append(file)
                    break

        if len(new_paths) < n:
            _LOGGER.info(
                f"Removed {n - len(new_paths)} records due to not being part of inclusion list: {inclusion_list}."
            )
        return new_paths

    @staticmethod
    def _expand_filestems_for_deidentification(
        filestems: t.Iterable[str],
        *,
        participant_ids_to_remap: t.Mapping[str, str],
        participant_session_id_to_remap: t.Mapping[str, str],
    ) -> t.List[str]:
        """Expand configured recording filestems to match both original and remapped IDs.

        Users may provide filestems referencing either:
        - the source dataset naming (e.g. sub-001js_ses-<uuid>_task-foo)
        - the deidentified naming (e.g. sub-512342_ses-<mapped>_task-foo)

        This returns a de-duplicated list containing both forms.
        """

        # Build reverse maps so we can support both directions when possible.
        reverse_participant_map = {v: k for k, v in participant_ids_to_remap.items()}
        reverse_session_map = {v: k for k, v in participant_session_id_to_remap.items()}

        expanded: t.Set[str] = set()
        pattern = re.compile(r"^sub-(?P<sub>[^_]+)(?:_ses-(?P<ses>[^_]+))?(?P<rest>.*)$")

        for raw in filestems:
            stem = Path(raw).stem  # tolerate accidental extensions
            expanded.add(stem)

            m = pattern.match(stem)
            if not m:
                continue

            sub = m.group("sub")
            ses = m.group("ses")
            rest = m.group("rest")

            # Forward-map into deidentified space
            sub_fwd = participant_ids_to_remap.get(sub, sub)
            ses_fwd = participant_session_id_to_remap.get(ses, ses) if ses is not None else None
            if ses_fwd is None:
                expanded.add(f"sub-{sub_fwd}{rest}")
            else:
                expanded.add(f"sub-{sub_fwd}_ses-{ses_fwd}{rest}")

            # Reverse-map back into original space (best-effort)
            sub_rev = reverse_participant_map.get(sub, sub)
            ses_rev = reverse_session_map.get(ses, ses) if ses is not None else None
            if ses_rev is None:
                expanded.add(f"sub-{sub_rev}{rest}")
            else:
                expanded.add(f"sub-{sub_rev}_ses-{ses_rev}{rest}")

        return sorted(expanded)

    @staticmethod
    def _extract_participant_id_from_path(path: t.Union[str, Path]) -> str:
        """Extract participant ID from the path, preferring directory parts.
        Falls back to regex on filestem if needed."""
        # Prefer directory parts
        path = Path(path)
        for part in Path(path).parts:
            if part.startswith("sub-"):
                return part[4:]

        # Fallback to filestem regex
        m = re.search(r"sub-([A-Za-z0-9\-]+)", path.stem)
        if m:
            return m.group(1)

        raise ValueError(f"Could not extract participant ID from path: {path}")

    @staticmethod
    def _extract_session_id_from_path(path: t.Union[str, Path]) -> str:
        """Extract session ID from the path, preferring directory parts.
        Falls back to regex on filestem using ses-(.+?)_ if needed."""
        # Prefer directory parts
        path = Path(path)
        for part in path.parts:
            if part.startswith("ses-"):
                return part[4:]

        # Fallback to filestem regex: ses-(.+?)_
        m = re.search(r"ses-(.+?)_", path.stem)
        if m:
            return m.group(1)

        raise ValueError(f"Could not extract session ID from path: {path}")

    @staticmethod
    def _extract_task_name_from_path(path: t.Union[str, Path]) -> str:
        """Extract the task name from the stem of the path.
        
        Tasks are optional components of filenames. They must follow the `task-<label>` pattern."""
        path = Path(path)
        m = re.search(r"task-(.+?)(_|$)", path.stem)
        if m:
            return m.group(1)

        raise ValueError(f"Could not extract task name from path: {path}")

    @staticmethod
    def _deidentify_audio_files(
        data_path: Path,
        outdir: Path,
        exclude_participant_ids: t.List[str] = [],
        exclude_audio_filestems: t.List[str] = [],
        audio_tasks_to_include_list: t.List[str] = [],
        participant_ids_to_remap: t.Dict[str, str] = {},
        participant_session_id_to_remap: t.Dict[str, str] = {},
        max_workers: int = 16,
    ):
        """
        Copy and deidentify audio files to the output directory.
        
        This method:
        1. Gets all audio paths from the dataset
        2. Removes participants from hard-coded exclusion list
        3. Filters out sensitive audio files
        4. Updates metadata with deidentified IDs
        5. Copies audio files and metadata to new location
        
        Args:
            data_path: Directory of the input BIDS dataset
            outdir: Output directory for deidentified audio files
            exclude_participant_ids: list of participant IDs to exclude
            exclude_audio_filestems: list of audio filenames to exclude
            audio_task_to_include_list: list of sensitive audio tasks
            participant_ids_to_remap: map between old and new participant IDs
            participant_session_id_to_remap: map between old and new session IDs
        """
        # Get all audio paths
        audio_paths = BIDSDataset._collect_paths(data_path, file_extension=".wav")
        if len(audio_paths) == 0:
            _LOGGER.warning(f"No audio files (.wav) found in {data_path}.")
            return
        
        # Remove known individuals (hard-coded participant removal)
        audio_paths = BIDSDataset._apply_exclusion_list_to_filepaths(
            audio_paths, exclusion_list=exclude_participant_ids, exclusion_type='participant'
        )

        # Remove known files (hard-coded file-based removal)
        audio_paths = BIDSDataset._apply_exclusion_list_to_filepaths(
            audio_paths, exclusion_list=exclude_audio_filestems, exclusion_type='filename'
        )

        # Remove specific tasks
        audio_paths = BIDSDataset._apply_exclusion_list_to_filepaths(
            audio_paths, exclusion_list=['audio-check'], exclusion_type='filestem_contains'
        )

        audio_tasks_to_include_list = [f"task-{normalize_task_label(task)}" for task in audio_tasks_to_include_list]
        audio_paths = BIDSDataset._grab_filepaths_list_to_include(
            audio_paths, inclusion_list=audio_tasks_to_include_list
        )
        
        # if audio_paths:
        #     _LOGGER.warning(f"No audio paths are present in {audio_paths}")
        #     return

        _LOGGER.info(f"Copying {len(audio_paths)} recordings.")

        def process_audio_file(audio_path):
            json_path = audio_path.parent.joinpath(f'{audio_path.stem}_recording-metadata.json')
            
            if not json_path.exists():
                _LOGGER.warning(f"Metadata file {json_path} not found. Skipping {audio_path}.")
                return

            metadata = json.loads(json_path.read_text())
            
            # Update metadata with deidentified IDs
            update_metadata_record_and_session_id(metadata, participant_ids_to_remap, participant_session_id_to_remap)
            participant_id = get_value_from_metadata(metadata, linkid="participant_id", endswith=False)
            session_id = get_value_from_metadata(metadata, linkid="session_id", endswith=True)
            
            # Create output path with deidentified structure
            sanitized_stem = sanitize_task_entity_in_bids_stem(audio_path.stem)
            audio_path_stem_ending = '-'.join(sanitized_stem.split("_")[2:])
            output_path = outdir.joinpath(
                f"sub-{participant_id}/ses-{session_id}/audio/sub-{participant_id}_ses-{session_id}_{audio_path_stem_ending}.wav"
            )
            output_path.parent.mkdir(parents=True, exist_ok=True)
        
            # Copy over the associated .json file and audio data
            with open(output_path.with_suffix(".json"), "w") as fp:
                json.dump(metadata, fp, indent=2)
            shutil.copy(audio_path, output_path)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            list(tqdm(executor.map(process_audio_file, audio_paths), total=len(audio_paths), desc="Copying audio and metadata files"))


    @staticmethod
    def _deidentify_feature_files(
        data_path: Path,
        outdir: Path,
        exclude_participant_ids: t.List[str] = [],
        exclude_audio_filestems: t.List[str] = [],
        audio_tasks_to_include_list: t.List[str] = [],
        participant_ids_to_remap: t.Dict[str, str] = {},
        participant_session_id_to_remap: t.Dict[str, str] = {},
        max_workers: int = 16,
    ):
        """
        Copy and deidentify audio feature files to the output directory.
        
        This method:
        1. Gets all audio feature paths from the dataset
        2. Removes participants from hard-coded exclusion list
        3. Filters out sensitive files
        4. Removes subfields from sensitive files
        5. Copies feature files to the new location
        
        Args:
            data_path: Directory of the input BIDS dataset
            outdir: Output directory for deidentified audio files
            exclude_participant_ids: list of participant IDs to exclude
            exclude_audio_filestems: list of audio filenames to exclude
            audio_task_to_include_list: list of sensitive audio tasks
            participant_ids_to_remap: map between old and new participant IDs
            participant_session_id_to_remap: map between old and new session IDs
        """
        # Get all audio paths
        paths = BIDSDataset._collect_paths(data_path, file_extension=".pt")
        if len(paths) == 0:
            _LOGGER.warning(f"No feature files (.pt) found in {data_path}.")
            return
        
        # Remove known individuals (hard-coded participant removal)
        paths = BIDSDataset._apply_exclusion_list_to_filepaths(
            paths, exclusion_list=exclude_participant_ids, exclusion_type='participant'
        )

        # Remove known files (hard-coded file-based removal)
        paths = BIDSDataset._apply_exclusion_list_to_filepaths(
            paths, exclusion_list=exclude_audio_filestems, exclusion_type='filename'
        )

        # Remove specific tasks
        paths = BIDSDataset._apply_exclusion_list_to_filepaths(
            paths, exclusion_list=['audio-check'], exclusion_type='filestem_contains'
        )

        audio_task_labels = {normalize_task_label(t) for t in audio_tasks_to_include_list}
        
        _LOGGER.info(f"Copying {len(paths)} feature files.")

        def process_feature_file(features_path):
            participant_id = BIDSDataset._extract_participant_id_from_path(features_path)
            participant_id = remap_id(
                participant_id, participant_ids_to_remap
            )
            session_id = BIDSDataset._extract_session_id_from_path(features_path)
            session_id = remap_id(
                session_id, participant_session_id_to_remap, id_type="session"
            )

            # Create output path with deidentified structure
            features_ending = '_features'
            audio_path_stem = sanitize_task_entity_in_bids_stem(
                features_path.stem.replace(features_ending, '')
            )
            path_stem_ending = '-'.join(audio_path_stem.split("_")[2:]) + features_ending
            output_path = outdir.joinpath(
                f"sub-{participant_id}/ses-{session_id}/audio/sub-{participant_id}_ses-{session_id}_{path_stem_ending}{features_path.suffix}"
            )
            output_path.parent.mkdir(parents=True, exist_ok=True)

            # if it is a audio task we wish to include, move all features over
            task_name = BIDSDataset._extract_task_name_from_path(features_path)
            if normalize_task_label(task_name) in audio_task_labels:
                shutil.copy(features_path, output_path)
            else:
                features = torch.load(features_path, weights_only=False, map_location=torch.device('cpu'))
                _remove_sensitive_features_from_feature_payload(features)
                torch.save(features, output_path)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            list(tqdm(executor.map(process_feature_file, paths), total=len(paths), desc="Copying and de-identifying feature files"))

    @staticmethod
    def _deidentify_quality_metrics(
        data_path: Path,
        outdir: Path,
        exclude_participant_ids: t.List[str] = [],
        exclude_audio_filestems: t.List[str] = [],
        audio_tasks_to_include_list: t.List[str] = [],
        participant_ids_to_remap: t.Dict[str, str] = {},
        participant_session_id_to_remap: t.Dict[str, str] = {},
    ) -> None:
        """
        Deidentify and copy audio quality metrics to the output directory.

        If no quality metrics file exists this method is a no-op, since the file
        is optional.  When present, the same participant exclusion, task filtering,
        and ID remapping that is applied to audio files is applied here so the
        released metrics are consistent with the rest of the deidentified dataset.

        Args:
            data_path: Path to the source BIDS dataset
            outdir: Output directory for the deidentified dataset
            exclude_participant_ids: list of participant IDs to exclude
            exclude_audio_filestems: list of audio file stems to exclude
            audio_tasks_to_include_list: list of audio tasks to include
            participant_ids_to_remap: mapping from old to new participant IDs
            participant_session_id_to_remap: mapping from old to new session IDs
        """
        quality_metrics_path = data_path / "audio_quality_metrics.tsv"
        if not quality_metrics_path.exists():
            _LOGGER.info("No audio_quality_metrics.tsv found; skipping quality metrics deidentification.")
            return

        df = pd.read_csv(quality_metrics_path, sep="\t", dtype=str)

        # Remove excluded participants
        if exclude_participant_ids and "participant_id" in df.columns:
            idx = df["participant_id"].isin(exclude_participant_ids)
            if idx.any():
                _LOGGER.info(f"Removing {idx.sum()} quality metric rows for excluded participants.")
                df = df.loc[~idx]

        # Remove audio-check task rows (mirrors the exclusion in _deidentify_audio_files)
        if "task_name" in df.columns:
            df = df.loc[
                df["task_name"].apply(
                    lambda task: normalize_task_label("audio-check") not in normalize_task_label(task)
                )
            ]

        # Doesn't filter to only included audio tasks as these are similar to non-identifiable features
        # # Filter to only included audio tasks
        # if audio_tasks_to_include_list and "task_name" in df.columns:
        #     normalized_tasks = {normalize_task_label(task) for task in audio_tasks_to_include_list}
        #     df = df.loc[df["task_name"].apply(lambda task: normalize_task_label(task) in normalized_tasks)]

        # Remove rows for excluded audio file stems
        if exclude_audio_filestems and {"participant_id", "session_id", "task_name"}.issubset(df.columns):
            def row_is_excluded(row):
                stem = f"sub-{row['participant_id']}_ses-{row['session_id']}_task-{row['task_name']}"
                return any(normalize_task_label(excl) in normalize_task_label(stem) for excl in exclude_audio_filestems)
            df = df.loc[~df.apply(row_is_excluded, axis=1)]

        # Remap participant IDs
        if participant_ids_to_remap and "participant_id" in df.columns:
            remap_partial = partial(remap_id, id_mapping=participant_ids_to_remap)
            df["participant_id"] = BIDSDataset._map_series(df["participant_id"], remap_partial)

        # Remap session IDs
        if participant_session_id_to_remap and "session_id" in df.columns:
            remap_partial = partial(remap_id, id_mapping=participant_session_id_to_remap, id_type="session")
            df["session_id"] = BIDSDataset._map_series(df["session_id"], remap_partial)

        df.to_csv(outdir / "audio_quality_metrics.tsv", sep="\t", index=False)

        quality_json_path = data_path / "audio_quality_metrics.json"
        if quality_json_path.exists():
            shutil.copy(quality_json_path, outdir)
        else:
            _LOGGER.warning(
                "audio_quality_metrics.json not found in BIDS dataset; "
                "copying schema from package resources."
            )
            qc_json_resource = resources.files("b2aiprep").joinpath(
                "prepare", "resources", "audio_quality_metrics.json"
            )
            with qc_json_resource.open() as src, open(outdir / "audio_quality_metrics.json", "w") as dst:
                dst.write(src.read())


class VBAIDataset(BIDSDataset):
    """Extension of BIDS format dataset implementing helper functions for data specific
    to the Bridge2AI Voice as a Biomarker of Health project.
    """

    def __init__(self, data_path: t.Union[Path, str, os.PathLike]):
        super().__init__(data_path)

    def _merge_columns_with_underscores(self, df: pd.DataFrame) -> pd.DataFrame:
        """Merges columns which are exported by RedCap in a one-hot encoding manner, i.e.
        they correspond to a single category but are split into multiple yes/no columns.

        Modifies the dataframe in place.

        Parameters
        ----------
        df : pd.DataFrame
            The dataframe to modify.

        Returns
        -------
        pd.DataFrame
            The modified dataframe.
        """

        # identify all the columns which end with __1, __2, etc.
        # extract the prefix for these columns only
        columns_with_underscores = sorted(
            list(
                set(
                    [
                        col[: col.rindex("__") - 1]
                        for col in df.columns
                        if re.search("__[0-9]+$", col) is not None
                    ]
                )
            )
        )

        # iterate through each prefix and merge together data into this prefix
        for col in columns_with_underscores:
            columns_to_merge = df.filter(like=f"{col}__").columns
            df[col] = df[columns_to_merge].apply(
                lambda x: next((i for i in x if i is not None), None), axis=1
            )
            df.drop(columns=columns_to_merge, inplace=True)
        return df

    def load_and_pivot_questionnaire(self, questionnaire_name: str) -> pd.DataFrame:
        """
        Loads all data for a questionnaire and pivots on the appropriate identifier column.

        Parameters
        ----------
        questionnaire_name : str
            The name of the questionnaire to load.

        Returns
        -------
        pd.DataFrame
            A "wide" format dataframe with questionnaire data. Returns empty DataFrame 
            if columns are not found in participants.tsv.
        """
        participants_file = self.data_path / "participants.tsv"
        if not participants_file.exists():
            _LOGGER.warning(f"participants.tsv file not found at {participants_file}")
            return pd.DataFrame()

        participants_df = pd.read_csv(participants_file, sep="\t")
        # Load questionnaire columns from instrument_columns resources
        instrument_columns_path = files("b2aiprep").joinpath("prepare").joinpath("resources").joinpath("instrument_columns")
        questionnaire_file = instrument_columns_path.joinpath(f"{questionnaire_name}.json")
        
        if not questionnaire_file.exists():
            _LOGGER.warning(f"Questionnaire JSON file not found: {questionnaire_name}.json")
            return pd.DataFrame()
            
        questionnaire_columns = json.loads(questionnaire_file.read_text())

        # Filter to only include columns that exist in participants.tsv
        available_columns = [col for col in questionnaire_columns if col in participants_df.columns]
        
        if not available_columns:
            _LOGGER.warning(f"No columns from '{questionnaire_name}' questionnaire found in participants.tsv")
            return pd.DataFrame()

        # Select the available columns
        questionnaire_df = participants_df[available_columns].copy()
        
        return questionnaire_df

    def load_participants(self) -> pd.DataFrame:
        """
        Loads the participants.tsv file and returns a dataframe with participant data.

        Returns
        -------
        pd.DataFrame
            A dataframe with participant data.
        """
        participants_file = self.data_path / "participants.tsv"
        if not participants_file.exists():
            _LOGGER.warning("participants.tsv file not found")
            return pd.DataFrame()

        try:
            df = pd.read_csv(participants_file, sep='\t')
            # Rename record_id to participant_id for consistency
            if 'record_id' in df.columns:
                df.rename(columns={'record_id': 'participant_id'}, inplace=True)
            return df
        except Exception as e:
            _LOGGER.error(f"Error loading participants data: {e}")
            return pd.DataFrame()

    def _load_session_schema_from_participants_tsv(self) -> pd.DataFrame:
        """
        Load session schema data from the participants.tsv file.
        
        Returns
        -------
        pd.DataFrame
            Session schema data with participant_id and session information.
        """
        participants_file = self.data_path / "participants.tsv"
        if not participants_file.exists():
            _LOGGER.warning("participants.tsv file not found")
            return pd.DataFrame()
        
        try:
            # Read the participants file
            df = pd.read_csv(participants_file, sep='\t')
            
            # Select session-related columns
            session_columns = [
                'participant_id', 'session_id', 'session_status', 
                'session_is_control_participant', 'session_duration'
            ]
            
            # Only include columns that exist in the file
            available_columns = [col for col in session_columns if col in df.columns]
            
            if not available_columns:
                _LOGGER.warning("No session-related columns found in participants.tsv")
                return pd.DataFrame()
            
            # Filter to rows that have session data (session_id is not null)
            session_df = df[available_columns].copy()
            if 'session_id' in session_df.columns:
                session_df = session_df.dropna(subset=['session_id'])
            
            return session_df
            
        except Exception as e:
            _LOGGER.error(f"Error loading session data from participants.tsv: {e}")
            return pd.DataFrame()

    def _load_recording_and_acoustic_task_df(self) -> pd.DataFrame:
        """Loads recording schema dataframe with the acoustic task name.

        Returns
        -------
        pd.DataFrame
            The recordings dataframe with the additional "acoustic_task_name" column.
        """
        recording_df = self.load_and_pivot_questionnaire("recordingschema")
        task_df = self.load_and_pivot_questionnaire("acoustictaskschema")

        recording_df = recording_df.merge(
            task_df[["acoustic_task_id", "acoustic_task_name"]],
            how="inner",
            left_on="recording_acoustic_task_id",
            right_on="acoustic_task_id",
        )
        return recording_df

    def load_recording(self, recording_id: str) -> Audio:
        """Checks for and loads in the given recording_id.

        Parameters
        ----------
        recording_id : str
            The recording identifier.

        Returns
        -------
        Audio
            The loaded audio.
        """
        # verify the recording_id is in the recording_df
        recording_df = self._load_recording_and_acoustic_task_df()
        idx = recording_df["recording_id"] == recording_id
        if not idx.any():
            raise ValueError(
                f"Recording ID '{recording_id}' not found in \
                             recordings dataframe."
            )

        row = recording_df.loc[idx].iloc[0]

        # Use participant_id or fall back to record_id for backward compatibility
        subject_id = row.get("participant_id", row.get("record_id"))
        session_id = row["recording_session_id"]
        task = row["acoustic_task_name"].replace(" ", "-")
        name = row["recording_name"].replace(" ", "-")

        audio_file = self.data_path.joinpath(
            f"sub-{subject_id}",
            f"ses-{session_id}",
            "audio",
            f"sub-{subject_id}_ses-{session_id}_{task}_rec-{name}.wav",
        )
        return Audio(filepath=str(audio_file))

    def load_recordings(self) -> t.List[Audio]:
        """Loads all audio recordings in the dataset.

        Returns
        -------
        List[Audio]
            The loaded audio recordings.
        """
        recording_df = self._load_recording_and_acoustic_task_df()
        audio_data = []
        missed_files = []
        for _, row in tqdm(
            recording_df.iterrows(), total=recording_df.shape[0], desc="Loading audio"
        ):
            # Use participant_id or fall back to record_id for backward compatibility
            subject_id = row.get("participant_id", row.get("record_id"))
            session_id = row["recording_session_id"]
            task = row["acoustic_task_name"].replace(" ", "-")
            name = row["recording_name"].replace(" ", "-")
            audio_file = self.data_path.joinpath(
                f"sub-{subject_id}",
                f"ses-{session_id}",
                "audio",
                f"sub-{subject_id}_ses-{session_id}_{task}_rec-{name}.wav",
            )
            try:
                audio_data.append(Audio(filepath=str(audio_file)))
            except (LibsndfileError, FileNotFoundError):
                # assuming lbsnd file error is a file not found, usually it is
                missed_files.append(audio_file)
                continue

        if len(missed_files) > 0:
            _LOGGER.warning(
                f"Could not find {len(missed_files)} / {recording_df.shape[0]} audio files."
            )

        return audio_data

    def load_spectrograms(self) -> t.List[np.array]:
        """Loads all audio recordings in the dataset."""
        recording_df = self._load_recording_and_acoustic_task_df()
        audio_data = []
        missed_files = []
        for _, row in tqdm(
            recording_df.iterrows(), total=recording_df.shape[0], desc="Loading audio"
        ):
            # Use participant_id or fall back to record_id for backward compatibility
            subject_id = row.get("participant_id", row.get("record_id"))
            session_id = row["recording_session_id"]
            task = row["acoustic_task_name"].replace(" ", "-")
            name = row["recording_name"].replace(" ", "-")
            audio_file = self.data_path.joinpath(
                f"sub-{subject_id}",
                f"ses-{session_id}",
                "audio",
                f"sub-{subject_id}_ses-{session_id}_{task}_rec-{name}.pt",
            )
            try:
                device = 'cpu' # not checking for cuda because optimization would be minimal if any
                features = torch.load(str(audio_file), weights_only=False, map_location=torch.device(device))
                audio_data.append(features["specgram"])
            except FileNotFoundError:
                # assuming lbsnd file error is a file not found, usually it is
                missed_files.append(audio_file)
                continue

        if len(missed_files) > 0:
            _LOGGER.warning(
                f"Could not find {len(missed_files)} / {recording_df.shape[0]} feature files."
            )

        return audio_data

    def validate_audio_files_exist(self) -> bool:
        """
        Validates that the audio recordings for all sessions are present.

        Parameters
        ----------
        subject_id : str
            The subject identifier.
        session_id : str
            The session identifier.

        Returns
        -------
        bool
            Whether the audio files are present.
        """
        missing_audio_files = []
        # iterate over all of the audio tasks in beh subfolder
        subjects = self.find_subjects()
        for subject in subjects:
            sessions = self.find_sessions(subject)
            for session in sessions:
                tasks = self.find_tasks(subject, session)
                for task_name, task_filename in tasks.items():
                    # check if the audio file is present
                    if "_rec-" not in task_name:
                        continue
                    if not task_name.endswith("_recordingschema.json"):
                        continue

                    suffix_len = len("_recordingschema")
                    audio_filename = (
                        Path(task_filename.parent).joinpath("..", "audio"),
                        f"{task_filename.stem[:suffix_len]}",
                    )
                    if not audio_filename.exists():
                        missing_audio_files.append(audio_filename)

        _LOGGER.debug(f"Missing audio files: {missing_audio_files}")
        return len(missing_audio_files) == 0
