import glob
from importlib.resources import files, as_file
import json
import logging
import os
from pathlib import Path
import shutil
import subprocess
import time
import wave
from typing import Any, Dict, List
import re
import hmac
import hashlib
import secrets
import pandas as pd

_LOGGER = logging.getLogger(__name__)


_TASK_LABEL_NORMALIZATION_RE = re.compile(r"[^a-z0-9]+")


def normalize_task_label(task_label: Any) -> str:
    """Normalize task labels for robust comparisons.

    Task labels may differ by capitalization, punctuation, or separators.
    This normalizer lower-cases and replaces non-alphanumerics with `-`.
    """
    value = str(task_label).strip().lower()
    value = _TASK_LABEL_NORMALIZATION_RE.sub("-", value)
    return value.strip("-")


_TASK_ENTITY_RE = re.compile(r"(task-)([^_]+)")


def sanitize_task_entity_in_bids_stem(stem: str) -> str:
    """Sanitize the value of the `task-<label>` entity inside a BIDS-like filename stem.

    This only touches the task entity value (up to the next underscore). It preserves
    all other entities.
    """

    def _repl(match: re.Match) -> str:
        prefix, raw_label = match.group(1), match.group(2)
        return f"{prefix}{normalize_task_label(raw_label)}"

    return _TASK_ENTITY_RE.sub(_repl, stem)


def get_commit_sha(submodule_root: Path) -> str:
    sha_file = submodule_root.joinpath("commit_sha.txt")
    if sha_file.is_file():
        return sha_file.read_text().strip()
    try:
        result = subprocess.run(
            ["git", "-C", str(submodule_root), "rev-parse", "HEAD"],
            capture_output=True,
            check=True,
            text=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        _LOGGER.warning(
            "Could not determine reproschema commit SHA from %s; termURLs will be unversioned.",
            submodule_root,
        )
        return ""


def reformat_resources(input_dir: str, output_dir: str) -> None:
    """
    Converts lists from all JSON files in the input directory to dictionaries
    where each list item becomes a key in the dictionary with a value of
    {"description": ""}, and saves them to the output directory with the same filename.

    Args:
        input_dir (str): The directory path containing input JSON files with lists.
        output_dir (str): The directory path to save the output JSON dictionary files.

    Raises:
        ValueError: If input_dir and output_dir are the same.
        FileNotFoundError: If input_dir does not exist.
        Exception: If any unexpected error occurs during file processing.

    Returns:
        None
    """
    # Check if input and output directories are the same
    if os.path.abspath(input_dir) == os.path.abspath(output_dir):
        raise ValueError("Input and output directories must be different.")

    # Check if input directory exists
    if not os.path.exists(input_dir):
        raise FileNotFoundError(f"Input directory '{input_dir}' does not exist.")

    # Create output directory if it does not exist
    os.makedirs(output_dir, exist_ok=True)

    # Iterate through all files in the input directory
    for filename in os.listdir(input_dir):
        if filename.endswith(".json"):
            input_json_path = os.path.join(input_dir, filename)
            output_json_path = os.path.join(output_dir, filename)
            print(output_json_path)

            try:
                # Load the list from the input JSON file
                with open(input_json_path, "r") as input_file:
                    keys_list: List[str] = json.load(input_file)
                result_dict: Dict[str, Dict[str, str]] = {
                    key: {"description": ""} for key in keys_list
                }

                # Save the resulting dictionary to the output JSON file
                with open(output_json_path, "w") as output_file:
                    json.dump(result_dict, output_file, indent=4)

            except Exception as e:
                print(f"Error processing file '{filename}': {e}")


def make_tsv_files(directory: str) -> None:
    """
    Creates .tsv files for each .json file present in the specified directory.
    The .tsv files will have columns corresponding to the keys of the JSON files,
    maintaining the order of the keys.

    Args:
        directory (str): The path to the directory containing .json files for which
                         .tsv files need to be created.

    Returns:
        None

    Raises:
        FileNotFoundError: If the specified directory does not exist.
        Exception: If any unexpected error occurs during file creation.
    """
    if not os.path.exists(directory):
        raise FileNotFoundError(f"The directory '{directory}' does not exist.")

    # Iterate over all files in the specified directory
    for filename in os.listdir(directory):
        if filename.endswith(".json"):
            base_name = os.path.splitext(filename)[0]
            tsv_filename = f"{base_name}.tsv"
            json_filepath = os.path.join(directory, filename)
            tsv_filepath = os.path.join(directory, tsv_filename)

            try:
                with open(json_filepath, "r") as json_file:
                    data = json.load(json_file)

                # Extract top-level keys from the JSON file to be the columns
                keys = list(data.keys())
                df = pd.DataFrame([{key: "" for key in keys}])

                # Write the DataFrame to a .tsv file
                df.to_csv(tsv_filepath, sep="\t", index=False)

            except Exception as e:
                print(f"Error processing file '{filename}': {e}")


def copy_package_resource(
    package: str, resource: str, destination_dir: str, destination_name: str = None
) -> None:
    """
    Copy a file or directory from within a package to a specified directory,
    overwriting if it already exists.

    Args:
        package (str): The package name where the file or directory is located.
        resource (str): The resource name (file or directory path within the package).
        destination_dir (str): The directory where the file or directory should be copied.
        destination_name (str, optional): The new name for the copied file or directory.
        If not provided, the original name is used.

    Returns:
        None
    """
    if destination_name is None:
        destination_name = os.path.basename(resource)
    destination_path = os.path.join(destination_dir, destination_name)

    # Check if the destination path already exists and remove it if so
    if os.path.exists(destination_path):
        if os.path.isdir(destination_path):
            shutil.rmtree(destination_path)
        else:
            os.remove(destination_path)

    with as_file(files(package).joinpath(resource)) as src_path:
        src_path = str(src_path)  # Ensure a string path
        if os.path.isdir(src_path):  # Resource is a directory
            shutil.copytree(src_path, destination_path)
        else:  # Resource is a file
            shutil.copy(src_path, destination_path)


def remove_files_by_pattern(directory: str, pattern: str) -> None:
    """
    Remove all files in a given directory that match a specific pattern.

    Args:
        directory (str): The path to the directory.
        pattern (str): The pattern to match files (e.g., "*.txt" for all text files).

    Returns:
        None
    """
    # Construct the full path pattern
    path_pattern = os.path.join(directory, pattern)

    # Use glob to find all files that match the pattern
    files_to_remove = glob.glob(path_pattern)

    for file_path in files_to_remove:
        try:
            os.remove(file_path)
            print(f"Removed file: {file_path}")
        except OSError as e:
            print(f"Error removing file {file_path}: {e}")

def open_json_as_dict(file_path):
    with open(file_path, "r") as file:
        return json.load(file)


# Updated function to take file paths as input and perform the comparison
def compare_json_keys_only_differences_from_files(file1_path, file2_path):
    # Load JSON files as dictionaries
    json1 = open_json_as_dict(file1_path)
    json2 = open_json_as_dict(file2_path)

    # Get keys from both JSON objects
    keys1 = set(json1.keys())
    keys2 = set(json2.keys())

    # Find differences
    only_in_file1 = keys1 - keys2
    only_in_file2 = keys2 - keys1

    result = {"only_in_file1": list(only_in_file1), "only_in_file2": list(only_in_file2)}

    return result


def sort_json_by_another_and_save(
    json_to_sort: Dict[str, any], reference_json: Dict[str, any], output_file_path: str
) -> None:
    # Create an ordered list of keys from the reference JSON
    reference_keys = list(reference_json.keys())

    # Sort the json_to_sort according to the reference keys order
    sorted_json = {key: json_to_sort[key] for key in reference_keys if key in json_to_sort}

    # Save the sorted JSON to the output file
    with open(output_file_path, "w") as output_file:
        json.dump(sorted_json, output_file, indent=4)

    print(f"Sorted JSON saved to {output_file_path}")


def save_json(data: Dict[str, any], file_path: str) -> None:
    """Helper function to save a dictionary as a JSON file with correct character rendering."""
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def update_jsons_in_directory(directory: str, reference_file: str) -> None:
    """Function to load all JSON files in a directory, replace their values
    with values from a reference JSON file based on matching keys, and remove
    those entries from the reference JSON at the end, excluding <measurement_tool_name>.json."""

    # Load reference JSON
    reference_json = open_json_as_dict(reference_file)

    # Track the keys that have been updated
    updated_keys: List[str] = []

    # Iterate over all files in the directory
    for file_name in os.listdir(directory):
        # Exclude <measurement_tool_name>.json
        if file_name.endswith(".json") and file_name != "<measurement_tool_name>.json":
            file_path = os.path.join(directory, file_name)

            # Load the current JSON file as a dict
            json_data = open_json_as_dict(file_path)

            # Replace values in the json_data with the ones from reference_json for matching keys
            updated_json = {}
            for key in json_data.keys():
                if key in reference_json:
                    updated_json[key] = reference_json[key]  # Use the value from reference JSON
                    updated_keys.append(key)  # Track the key to be removed later
                else:
                    raise KeyError(f"Key '{key}' in {file_name} not found in reference JSON.")

            # Save the updated JSON file
            save_json(updated_json, file_path)
            print(f"Updated: {file_name}")

    # Remove all updated keys from the reference JSON
    for key in updated_keys:
        reference_json.pop(key, None)

    # Save the modified reference JSON back to its original file
    save_json(reference_json, reference_file)
    print(f"Updated reference JSON saved back to {reference_file}")


def retry(func, max_retries=3, delay=0.5, exceptions=(Exception,)):
    """
    Retry a function n times with a specified delay.

    Args:
        func: The function to be called.
        max_retries: The maximum number of retries (default: 3).
        delay: The delay between retries in seconds (default: 1).
        exceptions: A tuple of exceptions to retry on (default: all exceptions).
    """

    def wrapper(*args, **kwargs):
        attempts = 0
        while attempts < max_retries:
            try:
                return func(*args, **kwargs)
            except exceptions as e:
                attempts += 1
                if attempts < max_retries:
                    print(
                        f"Retry attempt {attempts} failed due to {e}. Retrying in {delay} seconds..."
                    )
                    time.sleep(delay)
                else:
                    raise

    return wrapper


def get_wav_duration(file_path):
    """
    Function to retrieve duration of .wav audio file
    Args:
        file_path: The url to the given audio files.
    """
    with wave.open(file_path, "rb") as audio_file:
        # Get the total number of frames
        frames = audio_file.getnframes()
        # Get the frame rate (samples per second)
        rate = audio_file.getframerate()
        # Calculate duration in seconds
        duration = frames / float(rate)
    return duration


def generate_seed(seed_size=32):
    """Generate a cryptographic seed"""
    seed = secrets.token_bytes(seed_size)
    return seed


def generate_pseudonym(id_str, secret_key, length, salt=""):
    """Generates a fixed-length pseudonym."""
    message = str(id_str) + salt
    digest = hmac.new(secret_key, message.encode(), hashlib.sha256).hexdigest()
    number = int(digest[:12], 16) % 10**length
    return str(number).zfill(length)


def load_lookup_table(lookup_path):
    lookup_path = Path(lookup_path)

    if not lookup_path.exists():
        raise FileNotFoundError(f"Lookup table not found at: {lookup_path}")

    with open(lookup_path, "r") as f:
        lookup_table = json.load(f)
        existing_ids = len(lookup_table)
        _LOGGER.info(f"Pre-existing table contains {existing_ids} ids")
    remapped_ids = set(lookup_table.values())

    return lookup_table, remapped_ids


def build_lookup_table(original_ids, secret_key, load_lookup=None):
    """
    Generates the look up table using the secret and original ids.
    """
    id_length = 6
    if load_lookup is None:
        lookup_table = {}
        used_values = set()
    else:
        lookup_table, used_values = load_lookup_table(load_lookup)
    for oid in original_ids:
        if oid in lookup_table:
            continue
        salt_counter = 0
        while True:
            salt = str(salt_counter) if salt_counter > 0 else ""
            pseudo_id = generate_pseudonym(oid, secret_key, id_length, salt)
            if pseudo_id not in used_values:
                lookup_table[oid] = pseudo_id
                used_values.add(pseudo_id)
                break
            salt_counter += 1  # for collisions

    return lookup_table