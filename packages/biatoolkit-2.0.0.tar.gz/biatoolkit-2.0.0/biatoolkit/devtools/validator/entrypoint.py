"""
Funções utilitárias para resolução e validação do entrypoint do bundle AgentCore.

Este módulo resolve o entrypoint (arquivo ou módulo) com base em:
- argumentos explícitos (--entry-file / --entry-module), OU
- inferência a partir do Dockerfile (CMD/ENTRYPOINT).

Além de resolver, também valida:
- nome de módulo Python válido para `python -m`
- existência do arquivo/módulo dentro do bundle
- compilação do Python (syntax/bytecode)
- scaffold MCP (estrutura mínima esperada)
- coerência com o Dockerfile quando argumentos explícitos são usados

⚠️ Ponto importante (o que você pediu):
Mesmo quando o entrypoint é inferido APENAS pelo Dockerfile,
a validação precisa falhar de forma clara caso o módulo/arquivo indicado
não exista dentro do bundle.

Exemplo:
Dockerfile:
    CMD ["opentelemetry-instrument", "python", "-m", "sales_agent_murilo"]

Se NÃO existir `sales_agent_murilo.py` (ou pacote `sales_agent_murilo/`),
a validação estática deve retornar ERROR explícito (não só warning).
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Tuple
import re

from .models import ValidationIssue
from .dockerfile_val import infer_entrypoint_from_dockerfile_path, Entrypoint, _extract_cmd_tokens_from_dockerfile_text
from .requirements import looks_like_external_dependency
from .python_checks import check_python_compiles, check_mcp_scaffold


_PY_MODULE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$")


def is_valid_python_module_name(name: str) -> bool:
    """
    Verifica se o nome informado é um nome de módulo Python válido (regex),
    adequado para `python -m <module>`.

    Exemplos válidos:
      - my_module
      - my_package.submodule
    """
    return bool(_PY_MODULE_RE.match(name))


def module_exists_in_bundle(root: Path, module_name: str) -> bool:
    """
    Verifica se o módulo existe no bundle como:
      - arquivo .py: <module>.py
      - pacote: <module>/__init__.py
      - pacote executável: <module>/__main__.py

    Isso cobre os casos comuns de `python -m module`.
    """
    parts = module_name.split(".")
    rel = Path(*parts)
    cand_file = root / rel.with_suffix(".py")          # mymod.py
    cand_pkg_init = root / rel / "__init__.py"         # mymod/__init__.py
    cand_pkg_main = root / rel / "__main__.py"         # mymod/__main__.py
    return cand_file.exists() or cand_pkg_init.exists() or cand_pkg_main.exists()


def resolve_entrypoint(
    root: Path,
    dockerfile_path: Path,
    entry_file: Optional[str],
    entry_module: Optional[str],
    issues: List[ValidationIssue],
) -> Optional[Entrypoint]:
    """
    Resolve o entrypoint do bundle, considerando argumentos explícitos e o Dockerfile.

    Regras:
    - Se ambos entry_file e entry_module são passados, gera erro de ambiguidade.
    - Se entry_file é passado:
        - valida existência do arquivo dentro do bundle
        - valida consistência com o Dockerfile (se inferível)
        - valida compilação + scaffold MCP
    - Se entry_module é passado:
        - valida consistência com o Dockerfile (se inferível)
        - valida existência/validade do módulo (local ou dep externa)
        - valida compilação + scaffold MCP (se local)
    - Se nenhum é passado:
        - tenta inferir pelo Dockerfile
        - **E valida de forma obrigatória** (o ponto do seu pedido):
            - se o Dockerfile apontar pra módulo/arquivo inexistente, retorna ERROR claro.

    Retorna:
      Entrypoint no formato:
        ("file", "app.py")  ou  ("module", "sales_agent_murilo")
      ou None em caso de erro fatal.
    """
    if entry_file and entry_module:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="ENTRY_AMBIGUOUS",
                message="Passe apenas um: --entry-file OU --entry-module (não ambos).",
                hint="Ex.: --entry-module sales_agent_murilo",
            )
        )
        return None

    inferred = infer_entrypoint_from_dockerfile_path(dockerfile_path)

    # UX: erro específico quando CMD usa OTel wrapper mas falta o módulo após -m
    try:
        docker_text = dockerfile_path.read_text(encoding="utf-8", errors="ignore")
        tokens = _extract_cmd_tokens_from_dockerfile_text(docker_text) or []
    except Exception:
        tokens = []

    if not inferred and tokens[:3] == ["opentelemetry-instrument", "python", "-m"]:
        issues.append(ValidationIssue(
            severity="ERROR",
            code="ENTRY_MODULE_MISSING_AFTER_M",
            message='CMD incompleto no Dockerfile: faltou o módulo após "-m".',
            file=str(dockerfile_path),
            hint=f'Use: CMD ["opentelemetry-instrument","python","-m","name_main_module"] | tokens={tokens}'
        ))
        return None

    def _has_error(local_issues: List[ValidationIssue]) -> bool:
        return any(i.severity == "ERROR" for i in local_issues)

    def _validate_final(ep: Entrypoint, *, source: str) -> Optional[Entrypoint]:
        """
        Valida o entrypoint resolvido (seja por args, seja por Dockerfile).

        source:
          "Dockerfile" | "--entry-file" | "--entry-module" (apenas para mensagens melhores)
        """
        kind, value = ep

        if kind == "file":
            p = root / value
            if not p.exists():
                issues.append(
                    ValidationIssue(
                        severity="ERROR",
                        code="ENTRY_FILE_NOT_FOUND",
                        message=f"Entrypoint ({source}) aponta para arquivo inexistente: {value}",
                        file=str(p),
                        hint="Garanta que o arquivo exista dentro do bundle, ou ajuste o CMD do Dockerfile / argumento --entry-file.",
                    )
                )
                return None

            # valida compilação e scaffold MCP
            file_issues = check_file_entrypoint(root, value)
            issues.extend(file_issues)
            if _has_error(file_issues):
                return None
            return ep

        if kind == "module":
            # Valida nome, existência no bundle ou se é dependência externa.
            module_issues = check_module_entrypoint(root, value, allow_hyphen_module=False)

            # ✅ Caso crítico pedido: se veio do Dockerfile e o módulo não existe no bundle,
            # queremos um erro MUITO explícito apontando para o CMD do Dockerfile.
            if source == "Dockerfile" and any(i.code == "MODULE_NOT_FOUND_IN_BUNDLE" for i in module_issues):
                issues.append(
                    ValidationIssue(
                        severity="ERROR",
                        code="ENTRYPOINT_MODULE_NOT_FOUND",
                        message=(
                            f"Dockerfile CMD aponta para `python -m {value}`, "
                            f"mas esse módulo não existe no bundle."
                        ),
                        file=str(dockerfile_path),
                        hint=(
                            f"Confirme que existe `{value}.py` na raiz do bundle "
                            f"ou um pacote `{value}/__init__.py` (ou `{value}/__main__.py`)."
                        ),
                    )
                )
                return None

            issues.extend(module_issues)
            if _has_error(module_issues):
                return None
            return ep

        # fallback defensivo (não deveria ocorrer)
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="ENTRYPOINT_KIND_UNKNOWN",
                message=f"Entrypoint resolvido com tipo desconhecido: {kind}",
                hint="Reporte este caso. Esperado: ('file', ...) ou ('module', ...).",
            )
        )
        return None

    # --- 1) entry_file explícito ---
    if entry_file:
        p = root / entry_file
        if not p.exists():
            issues.append(
                ValidationIssue(
                    severity="ERROR",
                    code="ENTRY_FILE_NOT_FOUND",
                    message=f"Entry file informado não existe: {entry_file}",
                    file=str(p),
                    hint="Aponte para um arquivo .py existente dentro do bundle.",
                )
            )
            return None

        if inferred and inferred != ("file", entry_file):
            issues.append(
                ValidationIssue(
                    severity="ERROR",
                    code="ENTRY_MISMATCH",
                    message=f"Entry file ({entry_file}) não bate com o Dockerfile (inferred={inferred}).",
                    file=str(dockerfile_path),
                    hint="Ajuste o Dockerfile CMD ou use --entry-module/--entry-file correto.",
                )
            )
            return None

        return _validate_final(("file", entry_file), source="--entry-file")

    # --- 2) entry_module explícito ---
    if entry_module:
        if inferred and inferred != ("module", entry_module):
            issues.append(
                ValidationIssue(
                    severity="ERROR",
                    code="ENTRY_MISMATCH",
                    message=f"Entry module ({entry_module}) não bate com o Dockerfile (inferred={inferred}).",
                    file=str(dockerfile_path),
                    hint="Ajuste o Dockerfile CMD ou use --entry-module correto.",
                )
            )
            return None

        return _validate_final(("module", entry_module), source="--entry-module")

    # --- 3) Nenhum argumento: inferir pelo Dockerfile ---
    if not inferred:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="ENTRY_NOT_INFERRED",
                message="Não foi possível inferir entrypoint pelo Dockerfile.",
                file=str(dockerfile_path),
                hint="Passe --entry-file app.py ou --entry-module meu_modulo.",
            )
        )
        return None

    # ✅ Aqui é onde estava faltando clareza: inferiu do Dockerfile mas não validava existência.
    return _validate_final(inferred, source="Dockerfile")


def check_module_entrypoint(root: Path, module_name: str, *, allow_hyphen_module: bool) -> List[ValidationIssue]:
    """
    Valida se o módulo informado existe, é válido e compila.

    Regras:
    - Gera erro se o nome não é válido para python -m (regex), a menos que allow_hyphen_module=True
      (nesse caso vira WARN, mas ainda assim pode falhar na fase runtime).
    - Se existir no bundle, checa compilação e scaffold MCP.
    - Se não existir no bundle, verifica se parece dependência externa (requirements.txt).
    - Se não encontrado nem como local nem como dependência, retorna ERROR.

    Observação:
    - Para o seu caso (Dockerfile com python -m sales_agent_murilo), o comportamento esperado é:
      - Se `sales_agent_murilo.py` existir => OK (e checa compile + scaffold)
      - Se não existir e não estiver em requirements => ERROR MODULE_NOT_FOUND_IN_BUNDLE
    """
    issues: List[ValidationIssue] = []

    if not is_valid_python_module_name(module_name):
        sev = "WARN" if allow_hyphen_module else "ERROR"
        issues.append(
            ValidationIssue(
                severity=sev,
                code="ENTRY_MODULE_INVALID_PYNAME",
                message=f"O entry_module '{module_name}' não é um nome de módulo Python válido para `python -m`.",
                hint=(
                    "Você habilitou allow_hyphen_module=True (escape hatch). Confirme na Fase 2 (docker build/run)."
                    if allow_hyphen_module
                    else "Python não resolve hífen em nomes de módulo. Use módulo importável (underscore) no CMD."
                ),
            )
        )
        return issues

    if module_exists_in_bundle(root, module_name):
        parts = module_name.split(".")
        package_main = root.joinpath(*parts) / "__main__.py"
        module_py = root.joinpath(*parts).with_suffix(".py")
        target = package_main if package_main.exists() else module_py
        issues.extend(check_python_compiles(target))
        issues.extend(check_mcp_scaffold(target))
        return issues

    if looks_like_external_dependency(root, module_name):
        issues.append(
            ValidationIssue(
                severity="WARN",
                code="ENTRY_MODULE_EXTERNAL",
                message=f"Não encontrei '{module_name}' no bundle, mas parece ser dependência externa (requirements.txt).",
                hint="Pode estar OK se o Dockerfile instala requirements.txt. Valide na Fase 2 (smoke test).",
            )
        )
        return issues

    issues.append(
        ValidationIssue(
            severity="ERROR",
            code="MODULE_NOT_FOUND_IN_BUNDLE",
            message=f"Não encontrei '{module_name}' no bundle e não detectei dependência correspondente em requirements.txt.",
            hint="Se for código local, adicione ao bundle. Se for pip, inclua no requirements.txt.",
        )
    )
    return issues


def check_file_entrypoint(root: Path, file_name: str) -> List[ValidationIssue]:
    """
    Valida se o arquivo informado existe, compila e contém scaffold MCP.

    Observação:
    - A existência do arquivo normalmente é checada antes de chamar esta função,
      mas mantemos o check de compilação e scaffold aqui.
    """
    entry_path = root / file_name
    issues: List[ValidationIssue] = []
    issues.extend(check_python_compiles(entry_path))
    issues.extend(check_mcp_scaffold(entry_path))
    return issues
