"""
Funções utilitárias para parse e validação do requirements.txt do bundle AgentCore.
Inclui:
 - Normalização de nomes de pacotes para comparação robusta
 - Parse seguro do arquivo requirements.txt
 - Heurística para identificar se um módulo é dependência externa
"""
from __future__ import annotations
from pathlib import Path
from typing import List
import re

def normalize_dist_name(s: str) -> str:
    """
    Normaliza o nome de um pacote para facilitar comparações:
    - Remove espaços
    - Converte para minúsculas
    - Troca '_' e '.' por '-'
    Exemplo: 'My_Package.Name' -> 'my-package-name'
    """
    s = s.strip().lower()  # Remove espaços e deixa minúsculo
    s = re.sub(r"\s+", "", s)  # Remove espaços internos
    return s.replace("_", "-").replace(".", "-")  # Uniformiza separadores

def parse_requirements(requirements_path: Path) -> List[str]:
    """
    Faz o parse do requirements.txt e retorna uma lista de nomes de pacotes.
    - Ignora comentários e linhas vazias
    - Ignora opções de pip (linhas começando com '-' ou '--')
    - Remove comentários inline (após ' #')
    - Extrai apenas o nome do pacote, ignorando versões e extras
    """
    if not requirements_path.exists():
        return []  # Arquivo não existe
    out: List[str] = []
    for raw in requirements_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue  # Ignora linhas vazias e comentários
        if " #" in line:
            line = line.split(" #", 1)[0].strip()  # Remove comentário inline
        if line.startswith(("-", "--")):
            continue  # Ignora opções de pip
        # Extrai o nome do pacote antes de qualquer operador de versão, extra, etc.
        name = re.split(r"\s|==|>=|<=|~=|!=|@|\[|;", line, maxsplit=1)[0].strip()
        if name:
            out.append(name)
    return out

def looks_like_external_dependency(root: Path, module_name: str) -> bool:
    """
    Heurística para identificar se um módulo parece ser uma dependência externa:
    - Compara o nome do módulo (primeira parte) com os nomes dos pacotes do requirements.txt
    - Usa normalização para tolerar variações de '_' e '-'
    - Retorna True se encontrar correspondência provável
    """
    reqs = parse_requirements(root / "requirements.txt")
    if not reqs:
        return False  # Não há requirements.txt ou está vazio

    root_mod = module_name.split(".", 1)[0]  # Pega o nome base do módulo
    root_mod_n = normalize_dist_name(root_mod)
    reqs_n = {normalize_dist_name(r) for r in reqs}  # Normaliza todos os nomes do requirements

    # Considera variações comuns de nome (hífen vs underscore)
    candidates = {
        root_mod_n,
        root_mod_n.replace("-", "_"),
        root_mod_n.replace("_", "-"),
    }
    # Retorna True se qualquer variação estiver presente nas dependências
    return any(c in reqs_n for c in candidates)
