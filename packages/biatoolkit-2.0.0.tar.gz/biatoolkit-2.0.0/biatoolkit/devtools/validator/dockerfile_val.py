"""
Módulo de validação do Dockerfile do bundle AgentCore.

Inclui funções para:
- Inferir o entrypoint real (module/file) a partir do Dockerfile
- Checar instruções mínimas obrigatórias (FROM, COPY, CMD)

Contrato (modo simples e determinístico):
Esperamos que o bundle use o wrapper de OTel e execute o módulo via python -m:

  CMD ["opentelemetry-instrument", "python", "-m", "<SEU_MODULO>"]

Ou seja:
  tokens[0] == "opentelemetry-instrument"
  tokens[1] começa com "python" (python, python3, python3.10...)
  tokens[2] == "-m"
  tokens[3] == nome do módulo

Se o contrato bater, o entrypoint é sempre:
  ("module", tokens[3])

Isso evita inferências erradas (ex.: tratar wrapper como módulo).
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple, List
import ast
import re

from .models import ValidationIssue

Entrypoint = Tuple[str, str]  # ("file","app.py") | ("module","module.name")

_CMD_RE = re.compile(r"(?im)^\s*(CMD|ENTRYPOINT)\s+(.*)$")


def _strip_comments(line: str) -> str:
    """Remove comentários simples do Dockerfile (heurística)."""
    return line.split("#", 1)[0].strip()


def _parse_exec_form_array(rest: str) -> Optional[List[str]]:
    """
    Parse do formato exec (JSON array) do Dockerfile:
      CMD ["python", "-m", "foo"]
    """
    rest = rest.strip()
    if not rest.startswith("["):
        return None
    try:
        arr = ast.literal_eval(rest)
        if isinstance(arr, list) and all(isinstance(x, str) for x in arr):
            return arr
    except Exception:
        return None
    return None


def _parse_shell_form(rest: str) -> Optional[List[str]]:
    """
    Parse do formato shell:
      CMD python -m foo
    Split simples (não cobre quoting complexo).
    """
    rest = rest.strip()
    if not rest or rest.startswith("["):
        return None
    parts = [p for p in rest.split() if p.strip()]
    return parts if parts else None


def _extract_cmd_tokens_from_dockerfile_text(dockerfile_text: str) -> Optional[List[str]]:
    """
    Extrai tokens do ÚLTIMO CMD do Dockerfile (comportamento padrão do Docker).
    Se não houver CMD, tenta ENTRYPOINT.
    """
    lines = [_strip_comments(l) for l in dockerfile_text.splitlines()]
    lines = [l for l in lines if l]

    last_cmd: Optional[str] = None
    last_entrypoint: Optional[str] = None

    for line in lines:
        m = _CMD_RE.match(line)
        if not m:
            continue
        instr = m.group(1).upper()
        rest = m.group(2).strip()
        if instr == "CMD":
            last_cmd = rest
        elif instr == "ENTRYPOINT":
            last_entrypoint = rest

    target = last_cmd or last_entrypoint
    if not target:
        return None

    arr = _parse_exec_form_array(target)
    if arr is not None:
        return arr

    return _parse_shell_form(target)


def _looks_like_python_token(t: str) -> bool:
    """python, python3, python3.10 etc."""
    return t == "python" or t.startswith("python")


def _infer_by_contract(tokens: List[str]) -> Optional[Entrypoint]:
    """
    Inferência determinística baseada no contrato:

      ["opentelemetry-instrument", "python", "-m", "<module>"]

    Retorna ("module", "<module>") se bater; caso contrário, None.
    """
    if len(tokens) < 4:
        return None
    if tokens[0] != "opentelemetry-instrument":
        return None
    if not _looks_like_python_token(tokens[1]):
        return None
    if tokens[2] != "-m":
        return None
    mod = tokens[3].strip()
    if not mod:
        return None
    return ("module", mod)


def _infer_fallback(tokens: List[str]) -> Optional[Entrypoint]:
    """
    Fallback genérico (caso você reutilize o toolkit para outros bundles):

    - procura a ÚLTIMA ocorrência do padrão: python* -m <module>
    - se não tiver -m, procura o ÚLTIMO *.py após um python*
    """
    # 1) Último "python*"
    py_positions = [i for i, t in enumerate(tokens) if _looks_like_python_token(t)]
    if not py_positions:
        return None

    # 2) Tenta achar o ÚLTIMO padrão python* -m <module> no array inteiro
    last_mod = None
    for i in range(len(tokens) - 2):
        if _looks_like_python_token(tokens[i]) and tokens[i + 1] == "-m":
            cand = tokens[i + 2].strip()
            if cand:
                last_mod = cand
    if last_mod:
        return ("module", last_mod)

    # 3) Fallback para arquivo .py depois do último python
    last_py = None
    last_py_i = py_positions[-1]
    for t in tokens[last_py_i + 1 :]:
        if t.strip().endswith(".py"):
            last_py = t.strip()
    if last_py:
        return ("file", last_py)

    return None


def infer_entrypoint_from_dockerfile_text(dockerfile_text: str) -> Optional[Entrypoint]:
    """
    Infere entrypoint pelo Dockerfile.

    Estratégia:
    1) Extrai tokens do CMD/ENTRYPOINT.
    2) Aplica inferência por contrato (opentelemetry-instrument + python -m).
    3) Se não bater, aplica fallback genérico.
    """
    tokens = _extract_cmd_tokens_from_dockerfile_text(dockerfile_text)
    if not tokens:
        return None

    ep = _infer_by_contract(tokens)
    if ep:
        return ep

    return _infer_fallback(tokens)


def infer_entrypoint_from_dockerfile_path(dockerfile_path: Path) -> Optional[Entrypoint]:
    """Lê Dockerfile e infere entrypoint."""
    if not dockerfile_path.exists():
        return None
    text = dockerfile_path.read_text(encoding="utf-8", errors="ignore")
    return infer_entrypoint_from_dockerfile_text(text)


def check_dockerfile_minimum(dockerfile: Path) -> List[ValidationIssue]:
    """
    Checa se o Dockerfile contém instruções mínimas: FROM, COPY e CMD.
    Também valida o contrato do CMD se existir.
    """
    issues: List[ValidationIssue] = []
    if not dockerfile.exists():
        return issues

    text = dockerfile.read_text(encoding="utf-8", errors="ignore")

    if not re.search(r"(?im)^\s*FROM\s+\S+", text):
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="DOCKERFILE_MISSING_FROM",
                message="Dockerfile não contém FROM.",
                file=str(dockerfile),
                hint="Inclua uma imagem base: FROM public.ecr.aws/docker/library/python:3.11-slim (exemplo).",
            )
        )

    if not re.search(r"(?im)^\s*COPY\s+.+", text):
        issues.append(
            ValidationIssue(
                severity="WARN",
                code="DOCKERFILE_MISSING_COPY",
                message="Dockerfile não contém COPY (heurística).",
                file=str(dockerfile),
                hint="Normalmente você precisa copiar o código e requirements para dentro da imagem.",
            )
        )

    if not re.search(r"(?im)^\s*CMD\s+", text):
        issues.append(
            ValidationIssue(
                severity="WARN",
                code="DOCKERFILE_MISSING_CMD",
                message="Dockerfile não contém CMD (heurística).",
                file=str(dockerfile),
                hint='Ex.: CMD ["opentelemetry-instrument","python","-m","sales_agent_murilo"]',
            )
        )
        return issues

    # ✅ valida contrato do CMD (para deixar explícito)
    tokens = _extract_cmd_tokens_from_dockerfile_text(text)

    if tokens:
        # Se começa com opentelemetry-instrument, exigimos o contrato completo.
        if tokens and tokens[0] == "opentelemetry-instrument":
            if _infer_by_contract(tokens) is None:
                issues.append(
                    ValidationIssue(
                        severity="ERROR",
                        code="DOCKERFILE_CMD_CONTRACT_INVALID",
                        message=(
                            "CMD inválido para o contrato esperado. "
                            "Esperado: CMD [\"opentelemetry-instrument\",\"python\",\"-m\",\"<module>\"]"
                        ),
                        file=str(dockerfile),
                        hint=f"Tokens detectados: {tokens}",
                    )
                )

    return issues
