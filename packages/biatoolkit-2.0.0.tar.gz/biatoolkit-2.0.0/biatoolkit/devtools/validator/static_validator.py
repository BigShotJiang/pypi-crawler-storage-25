"""
Validação estática do bundle AgentCore.
Inclui funções para checagem de arquivos obrigatórios, entrypoint e dependências.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Optional


# Importa modelos e funções auxiliares para validação do bundle AgentCore
from .models import ValidationIssue, ValidationResult
from .requirements import parse_requirements
from .dockerfile_val import check_dockerfile_minimum
from .entrypoint import resolve_entrypoint, check_module_entrypoint, check_file_entrypoint

def check_required_files(root: Path) -> List[ValidationIssue]:
    """
    Verifica se os arquivos obrigatórios (requirements.txt e Dockerfile) existem no diretório raiz do projeto.
    Retorna uma lista de ValidationIssue para cada arquivo ausente.
    """
    issues: List[ValidationIssue] = []
    for name in ["requirements.txt", "Dockerfile"]:
        p = root / name
        if not p.exists():
            # Adiciona um erro caso o arquivo obrigatório não seja encontrado
            issues.append(ValidationIssue(
                severity="ERROR",
                code="MISSING_FILE",
                message=f"Arquivo obrigatório não encontrado: {name}",
                file=str(p),
                hint=f"Crie o arquivo {name} no bundle antes de subir para o AgentCore.",
            ))
    return issues

def check_requirements_parse(reqs: Path) -> List[ValidationIssue]:
    """
    Tenta fazer o parse do requirements.txt e retorna um aviso caso haja erro de sintaxe ou formatação.
    """
    issues: List[ValidationIssue] = []
    if not reqs.exists():
        return issues
    try:
        _ = parse_requirements(reqs)
    except Exception as e:
        # Adiciona um aviso se não conseguir interpretar o requirements.txt
        issues.append(ValidationIssue(
            severity="WARN",
            code="REQUIREMENTS_PARSE_WARN",
            message=f"Não consegui interpretar requirements.txt completamente: {e}",
            file=str(reqs),
            hint="Garanta que requirements.txt tenha uma lista simples de dependências (um por linha).",
        ))
    return issues


def validate_agentcore_bundle(
    project_path: str | Path,
    entry_file: Optional[str] = None,
    entry_module: Optional[str] = None,
    *,
    allow_hyphen_module: bool = False,
) -> ValidationResult:
    """
    Valida um bundle de projeto para o AgentCore.
    - Verifica arquivos obrigatórios
    - Resolve e valida o entrypoint (arquivo ou módulo)
    - Valida o requirements.txt e Dockerfile
    Retorna um ValidationResult com todos os problemas encontrados.
    Parâmetros:
        project_path: caminho do projeto a ser validado
        entry_file: nome do arquivo de entrada (opcional)
        entry_module: nome do módulo de entrada (opcional)
        allow_hyphen_module: permite hífen no nome do módulo (padrão: False)
    """
    root = Path(project_path).resolve()
    issues: List[ValidationIssue] = []

    dockerfile = root / "Dockerfile"
    reqs = root / "requirements.txt"

    # 1. Verifica arquivos obrigatórios
    issues.extend(check_required_files(root))
    if any(i.severity == "ERROR" and i.code == "MISSING_FILE" for i in issues):
        # Se faltar arquivo obrigatório, retorna imediatamente
        return ValidationResult(ok=False, issues=issues)

    # 2. Resolve o entrypoint (arquivo ou módulo)
    resolved = resolve_entrypoint(
        root=root,
        dockerfile_path=dockerfile,
        entry_file=entry_file,
        entry_module=entry_module,
        issues=issues,
    )
    if resolved is None:
        # Se não conseguir resolver o entrypoint, retorna
        return ValidationResult(ok=False, issues=issues)

    kind, value = resolved
    if kind == "file":
        # Valida entrypoint do tipo arquivo
        issues.extend(check_file_entrypoint(root, value))
    else:
        # Valida entrypoint do tipo módulo
        issues.extend(check_module_entrypoint(root, value, allow_hyphen_module=allow_hyphen_module))

    # 3. Valida requirements.txt e Dockerfile
    issues.extend(check_requirements_parse(reqs))
    issues.extend(check_dockerfile_minimum(dockerfile))

    # 4. Retorna resultado final
    ok = not any(i.severity == "ERROR" for i in issues)
    return ValidationResult(ok=ok, issues=issues)
