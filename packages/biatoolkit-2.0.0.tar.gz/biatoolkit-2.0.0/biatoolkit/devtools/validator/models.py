"""
Modelos de dados para issues e resultados de validação do AgentCore.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class ValidationIssue:
    """
    Representa um problema encontrado durante a validação do bundle.
    Campos:
        severity: nível do problema (ERROR, WARN, INFO)
        code: código identificador
        message: mensagem descritiva
        file: arquivo relacionado (opcional)
        hint: dica de correção (opcional)
    """
    severity: str   # "ERROR" | "WARN" | "INFO"
    code: str
    message: str
    file: Optional[str] = None
    hint: Optional[str] = None

@dataclass
class ValidationResult:
    """
    Resultado da validação do bundle.
    Campos:
        ok: True se não há erros bloqueantes
        issues: lista de ValidationIssue encontrados
    """
    ok: bool
    issues: List[ValidationIssue]
