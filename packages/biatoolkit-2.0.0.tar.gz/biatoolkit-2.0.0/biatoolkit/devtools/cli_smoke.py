from __future__ import annotations

import argparse
from typing import Dict, Optional

from biatoolkit.devtools.validator.runtime_validator import smoke_validate_bundle


def _parse_env(env_list) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for item in env_list or []:
        if "=" not in item:
            continue
        k, v = item.split("=", 1)
        out[k.strip()] = v
    return out


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Smoke test (runtime) de bundle MCP para AgentCore (docker build/run)."
    )

    parser.add_argument("--path", required=True, help="Pasta do bundle (Dockerfile/requirements/etc).")
    parser.add_argument("--tag", help="Tag da imagem docker a ser criada (default auto).")
    parser.add_argument("--run-seconds", type=int, default=8, help="Quantos segundos o container deve ficar vivo (default: 8).")
    parser.add_argument("--build-timeout-sec", type=int, default=600, help="Timeout do docker build em segundos (default: 600).")
    parser.add_argument("--start-timeout-sec", type=int, default=60, help="Timeout para iniciar o container (default: 60).")

    parser.add_argument("--skip-static", action="store_true", help="Pula validação estática e roda apenas o smoke (não recomendado).")
    parser.add_argument("--keep-image", action="store_true", help="Não remove a imagem docker após o teste.")
    parser.add_argument("--keep-container", action="store_true", help="Não remove o container após o teste (útil para debug).")

    parser.add_argument("--env", action="append", default=[], help="Variável de ambiente KEY=VALUE (pode repetir).")

    # Porta para expor o servidor (necessário para MCP/health)
    parser.add_argument("--port", type=int, default=8000, help="Porta a mapear (host:port). Default: 8000")
    parser.add_argument("--health-path", help="Path do health check (ex: /health).")

    # MCP ListTools (Item 3)
    parser.add_argument("--mcp-url", help="URL completa do endpoint MCP (ex: http://127.0.0.1:8000/mcp). Se não informado, monta com --port + --mcp-path.")
    parser.add_argument("--mcp-path", default="/mcp", help="Path do endpoint MCP (default: /mcp). Usado se --mcp-url não for informado.")
    parser.add_argument("--skip-mcp-list-tools", action="store_true", help="Pula o ListTools MCP (não recomendado; usado só para debug).")

    parser.add_argument("--verbose", action="store_true", help="Exibe logs de progresso.")
    parser.add_argument("--show-logs", action="store_true", help="Mostra logs do container (tail 80) no sucesso.")

    args = parser.parse_args()

    env = _parse_env(args.env)

    if args.health_path and not args.port:
        parser.error("--health-path requer --port.")

    # Se não for passar mcp-url, vamos montar URL com base no host local
    mcp_url: Optional[str] = args.mcp_url
    if not mcp_url:
        # host é sempre localhost (onde o docker fez -p)
        mcp_url = f"http://127.0.0.1:{args.port}{args.mcp_path}"

    result = smoke_validate_bundle(
        project_path=args.path,
        tag=args.tag,
        run_seconds=args.run_seconds,
        build_timeout_sec=args.build_timeout_sec,
        start_timeout_sec=args.start_timeout_sec,
        keep_image=args.keep_image,
        keep_container=args.keep_container,
        skip_static=args.skip_static,
        env=env or None,
        port=args.port,  # necessário pro -p no docker run
        health_path=args.health_path,
        verbose=args.verbose,
        show_logs=args.show_logs,
        mcp_url=mcp_url,
        skip_mcp_list_tools=args.skip_mcp_list_tools,
    )

    if args.verbose:
        print("\n=== BIATOOLKIT SMOKE (Runtime) - verbose ===")
        print(f"Path: {args.path}")

    print("\n=== BIATOOLKIT SMOKE (Runtime) ===")
    print(f"Path: {args.path}")
    print(f"OK: {result.ok}")

    if not result.issues:
        print("\nNenhum issue encontrado.")
    else:
        for issue in result.issues:
            print(f"\n[{issue.severity}] {issue.code}: {issue.message}")
            if issue.hint:
                print(f"  -> {issue.hint}")

    raise SystemExit(0 if result.ok else 1)


if __name__ == "__main__":
    main()
