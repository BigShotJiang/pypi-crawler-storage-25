"""
CLI para validação estática (fase 1) de bundles MCP para AgentCore.
Permite especificar entrypoint, modo estrito e mostra detalhes dos problemas encontrados.
"""
import argparse
from biatoolkit.devtools.agentcore_validator import validate_agentcore_bundle


def main():
    """
    Função principal do CLI: faz o parse dos argumentos, chama o validador estático e imprime o resultado.
    """
    parser = argparse.ArgumentParser(
        description="Valida bundle MCP para AgentCore (fase 1)."
    )

    # Argumentos principais
    parser.add_argument(
        "--path",
        required=True,
        help="Pasta do bundle (Dockerfile/requirements/etc).",
    )
    parser.add_argument(
        "--entry-file",
        help="Arquivo Python que inicia o MCP server (ex: app.py).",
    )
    parser.add_argument(
        "--entry-module",
        help="Módulo Python executado via python -m (ex: sales_agent_murilo).",
    )
    parser.add_argument(
        "--allow-hyphen-module",
        action="store_true",
        help="Escape hatch: rebaixa nome inválido em python -m (ex: com hífen) de ERROR para WARN.",
    )
    parser.add_argument(
        "--require-entry",
        action="store_true",
        help="Exige que você passe --entry-file OU --entry-module explicitamente.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Mostra logs detalhados do processo de smoke."
    )
    parser.add_argument(
        "--print-inferred-entry",
        action="store_true",
        help="Mostra o entrypoint inferido a partir do Dockerfile.",
    )

    args = parser.parse_args()

    # Validação de argumentos obrigatórios
    if args.require_entry and not (args.entry_file or args.entry_module):
        parser.error("Com --require-entry, você precisa passar --entry-file OU --entry-module.")

    # Executa a validação estática principal
    result = validate_agentcore_bundle(
        project_path=args.path,
        entry_file=args.entry_file,
        entry_module=args.entry_module,
        allow_hyphen_module=args.allow_hyphen_module,
    )

    # Exibe o resultado da validação
    print("\n=== BIATOOLKIT VALIDATE (Fase 1) ===")
    print(f"Path: {args.path}")
    print(f"OK: {result.ok}")

    if not result.issues:
        print("\nNenhum issue encontrado.")
    else:
        for issue in result.issues:
            print(f"\n[{issue.severity}] {issue.code}: {issue.message}")
            if issue.hint:
                print(f"  -> {issue.hint}")

    if not result.ok:
        exit(1)


if __name__ == "__main__":
    main()
