import pytest
from biatoolkit.core.basic_client import BiaClient

def test_biaclient_url_suffix_added():
    """Verifica que o cliente adiciona /mcp quando o caller passa só a base."""
    c = BiaClient("http://localhost:8000")
    assert c.url.endswith("/mcp")

def test_biaclient_url_suffix_not_duplicated():
    """Garante que uma URL já finalizada com /mcp não seja duplicada."""
    c = BiaClient("http://localhost:8000/mcp")
    assert c.url == "http://localhost:8000/mcp"

def test_biaclient_headers_are_stored():
    """Confirma que os headers informados no construtor são preservados."""
    headers = {"X-Test": "1"}
    c = BiaClient("http://localhost:8000", headers=headers)
    assert c.headers == headers
