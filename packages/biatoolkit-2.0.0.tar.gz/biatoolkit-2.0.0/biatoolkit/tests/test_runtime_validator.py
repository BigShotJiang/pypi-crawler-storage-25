from pathlib import Path
from types import SimpleNamespace

from biatoolkit.devtools.validator.models import ValidationResult
from biatoolkit.devtools.validator.runtime_validator import _run_static_validate, smoke_validate_bundle


def _cmd_result(cmd, returncode=0, stdout="", stderr="", timed_out=False):
    return SimpleNamespace(
        cmd=cmd,
        returncode=returncode,
        stdout=stdout,
        stderr=stderr,
        timed_out=timed_out,
    )


def test_run_static_validate_uses_static_validator(monkeypatch, tmp_path):
    """Verifica que a fase estática delega para o validador de bundle correto."""
    expected = ValidationResult(ok=True, issues=[])

    def _fake_validate_agentcore_bundle(root):
        assert root == tmp_path.resolve()
        return expected

    monkeypatch.setattr(
        "biatoolkit.devtools.validator.static_validator.validate_agentcore_bundle",
        _fake_validate_agentcore_bundle,
    )

    assert _run_static_validate(tmp_path) is expected


def test_smoke_validate_bundle_respects_skip_mcp_list_tools(monkeypatch, tmp_path):
    """Confirma que o smoke pula ListTools quando a flag skip_mcp_list_tools está ativa."""
    monkeypatch.setattr(
        "biatoolkit.devtools.validator.runtime_validator.docker_available",
        lambda: _cmd_result(["docker", "version"], returncode=0),
    )
    monkeypatch.setattr(
        "biatoolkit.devtools.validator.runtime_validator._run_static_validate",
        lambda root: ValidationResult(ok=True, issues=[]),
    )

    def _fake_run_cmd(cmd, cwd=None, timeout_sec=None):
        if cmd[:3] == ["docker", "build", "-t"]:
            return _cmd_result(cmd, returncode=0)
        if cmd[:4] == ["docker", "run", "-d", "--name"]:
            return _cmd_result(cmd, returncode=0, stdout="container-123")
        if cmd[:3] == ["docker", "rm", "-f"]:
            return _cmd_result(cmd, returncode=0)
        if cmd[:3] == ["docker", "rmi", "-f"]:
            return _cmd_result(cmd, returncode=0)
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr("biatoolkit.devtools.validator.runtime_validator.run_cmd", _fake_run_cmd)
    monkeypatch.setattr(
        "biatoolkit.devtools.validator.runtime_validator._inspect_container",
        lambda name: (True, 0),
    )
    monkeypatch.setattr("biatoolkit.devtools.validator.runtime_validator.time.sleep", lambda _: None)

    def _unexpected_mcp_call(*args, **kwargs):
        raise AssertionError("MCP ListTools should not run when skip_mcp_list_tools=True")

    monkeypatch.setattr(
        "biatoolkit.devtools.validator.runtime_validator._mcp_list_tools_via_biatoolkit",
        _unexpected_mcp_call,
    )

    result = smoke_validate_bundle(
        project_path=tmp_path,
        run_seconds=1,
        skip_static=True,
        mcp_url="http://127.0.0.1:8000/mcp",
        skip_mcp_list_tools=True,
    )

    assert result.ok is True
    assert result.issues == []