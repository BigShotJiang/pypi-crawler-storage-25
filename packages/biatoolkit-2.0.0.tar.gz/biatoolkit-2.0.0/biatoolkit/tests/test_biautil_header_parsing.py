from types import SimpleNamespace

from biatoolkit.core.util import BiaUtil


class _FakeMCP:
    def __init__(self, headers: dict):
        self._headers = headers

    def get_context(self):
        # estrutura esperada: ctx.request_context.request.headers
        return SimpleNamespace(
            request_context=SimpleNamespace(
                request=SimpleNamespace(headers=self._headers)
            )
        )


def test_get_header_reads_strings_and_ints():
    """Verifica parsing de headers string e coerção dos campos inteiros do runtime."""
    prefix = "x-amzn-bedrock-agentcore-runtime-custom"
    headers = {
        f"{prefix}-current-host": "host",
        f"{prefix}-user-email": "user@x.com",
        f"{prefix}-jwt-token": "jwt",
        f"{prefix}-jsessionid": "js",
        f"{prefix}-organization-id": "10",
        f"{prefix}-codparc": "20",
        f"{prefix}-iam-user-id": "30",
        f"{prefix}-gateway-token": "gw",
    }

    util = BiaUtil(_FakeMCP(headers))
    h = util.get_header()

    assert h.current_host == "host"
    assert h.user_email == "user@x.com"
    assert h.jwt_token == "jwt"
    assert h.jsessionid == "js"
    assert h.organization_id == 10
    assert h.codparc == 20
    assert h.iam_user_id == 30
    assert h.gateway_token == "gw"


def test_get_header_defaults_when_missing():
    """Garante defaults seguros quando nenhum header esperado está presente."""
    util = BiaUtil(_FakeMCP({}))
    h = util.get_header()

    assert h.current_host is None
    assert h.user_email is None
    assert h.jwt_token is None
    assert h.jsessionid is None
    assert h.organization_id == 0
    assert h.codparc == 0
    assert h.iam_user_id == 0
    assert h.gateway_token is None

def test_get_header_ints_are_robust():
    """Confirma fallback para zero quando campos inteiros vêm vazios ou inválidos."""
    prefix = "x-amzn-bedrock-agentcore-runtime-custom"
    headers = {
        f"{prefix}-organization-id": "",
        f"{prefix}-codparc": "abc",
        f"{prefix}-iam-user-id": None,
    }
    util = BiaUtil(_FakeMCP(headers))
    h = util.get_header()

    assert h.organization_id == 0
    assert h.codparc == 0
    assert h.iam_user_id == 0
