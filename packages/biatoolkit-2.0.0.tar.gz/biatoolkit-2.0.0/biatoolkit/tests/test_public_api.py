import inspect
import importlib
import logging

def test_import_biautil():
    """Valida import direto do utilitário público BiaUtil."""
    from biatoolkit.core.util import BiaUtil
    assert BiaUtil is not None

def test_import_biaclient():
    """Valida import direto do cliente público BiaClient."""
    from biatoolkit.core.basic_client import BiaClient
    assert BiaClient is not None

def test_biautil_has_expected_methods():
    """Confirma que BiaUtil expõe os métodos públicos esperados."""
    from biatoolkit.core.util import BiaUtil
    assert hasattr(BiaUtil, "get_header")
    assert hasattr(BiaUtil, "get_parameter")

def test_biaclient_has_expected_methods():
    """Confirma que BiaClient mantém as operações públicas principais."""
    from biatoolkit.core.basic_client import BiaClient
    assert hasattr(BiaClient, "list_tools")
    assert hasattr(BiaClient, "call_tool")

def test_biaclient_call_tool_signature_is_stable():
    """Protege a assinatura pública de call_tool para evitar quebras de contrato."""
    from biatoolkit.core.basic_client import BiaClient
    sig = inspect.signature(BiaClient.call_tool)
    assert "tool_name" in sig.parameters
    assert "params" in sig.parameters
    assert sig.parameters["params"].default is None


def test_root_package_import_is_lazy_and_side_effect_free():
    """Garante que importar o pacote raiz não inicializa logging nem efeitos colaterais."""
    root_logger = logging.getLogger()
    original_handlers = list(root_logger.handlers)

    try:
        package = importlib.import_module("biatoolkit")
        package = importlib.reload(package)

        assert not any(
            getattr(handler, "_biatoolkit_bootstrap_handler", False)
            for handler in root_logger.handlers
        )
        assert package.BiaClient.__name__ == "BiaClient"
        assert package.BiaUtil.__name__ == "BiaUtil"
    finally:
        root_logger.handlers[:] = original_handlers
