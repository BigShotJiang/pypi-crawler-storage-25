from biatoolkit.core.settings import BiaToolkitSettings


def test_settings_defaults():
    """Valida os defaults básicos de configuração expostos pelo toolkit."""
    s = BiaToolkitSettings()
    assert s.aws_region == "sa-east-1"
    assert s.client_timeout_seconds == 120
    assert "bedrock" in s.header_prefix

def test_settings_from_env(monkeypatch):
    """Garante que variáveis de ambiente sobrescrevem os defaults de settings."""
    monkeypatch.setenv("BIATOOLKIT_AWS_REGION", "us-east-1")
    monkeypatch.setenv("BIATOOLKIT_CLIENT_TIMEOUT_SECONDS", "77")
    s = BiaToolkitSettings.from_env()
    assert s.aws_region == "us-east-1"
    assert s.client_timeout_seconds == 77
