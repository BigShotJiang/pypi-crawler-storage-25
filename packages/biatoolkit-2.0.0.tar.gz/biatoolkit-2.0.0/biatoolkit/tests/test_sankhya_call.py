import pytest
from biatoolkit.sankhya.erp import Sankhya, SankhyaHTTPError
from unittest.mock import patch, MagicMock



from biatoolkit.sankhya.erp import SankhyaSettings

def test_sankhya_settings_from_env(monkeypatch):
    """Valida leitura de timeouts, retries e SSL da configuração Sankhya via env."""
    monkeypatch.setenv("SANKHYA_TIMEOUT_CONNECT", "5.5")
    monkeypatch.setenv("SANKHYA_TIMEOUT_READ", "15")
    monkeypatch.setenv("SANKHYA_RETRIES_TOTAL", "7")
    monkeypatch.setenv("SANKHYA_RETRY_BACKOFF", "1.2")
    monkeypatch.setenv("SANKHYA_VERIFY_SSL", "0")
    settings = SankhyaSettings.from_env()
    assert settings.timeout_connect == 5.5
    assert settings.timeout_read == 15.0
    assert settings.retries_total == 7
    assert settings.retry_backoff == 1.2
    assert settings.verify_ssl is False


from biatoolkit.sankhya.helpers._support import build_url, SERVICE_PATH
def test_build_url_priority():
    """Verifica precedência entre URL explícita, base_url e query na montagem final."""
    # url explícita
    assert build_url(url="https://x.com/abc", base_url="https://api.sankhya.com") == "https://x.com/abc"
    # base_url + SERVICE_PATH
    assert build_url(base_url="https://api.sankhya.com") == f"https://api.sankhya.com{SERVICE_PATH}"
    # query
    assert build_url(base_url="https://api.sankhya.com", query="a=1&b=2") == f"https://api.sankhya.com{SERVICE_PATH}?a=1&b=2"
    assert build_url(url="https://x.com/abc", base_url="https://api.sankhya.com", query="a=1") == "https://x.com/abc?a=1"

def test_resolve_jsessionid_explicit():
    """Confirma que um JSESSIONID explícito é usado sem consultar runtime."""
    s = Sankhya()
    assert s._resolve_jsessionid("abc123") == "abc123"

@patch("biatoolkit.sankhya.helpers._runtime.BiaUtil")
def test_resolve_jsessionid_from_mcp(mock_biautil):
    """Garante fallback para o header do runtime quando jsessionid não é informado."""
    mock_mcp = MagicMock()
    mock_header = MagicMock(jsessionid="jsid456")
    mock_biautil.return_value.get_header.return_value = mock_header
    s = Sankhya(mcp=mock_mcp)
    assert s._resolve_jsessionid(None) == "jsid456"


@patch("biatoolkit.sankhya.helpers._runtime.BiaUtil")
def test_load_view_uses_current_host_from_mcp(mock_biautil):
    """Valida que load_view resolve base_url a partir de current_host no runtime."""
    from biatoolkit.core.response import ToolkitResponse
    mock_mcp = MagicMock()
    mock_header = MagicMock(current_host="https://runtime.sankhya.com", jsessionid="jsid456")
    mock_biautil.return_value.get_header.return_value = mock_header

    with patch.object(Sankhya, "call_json", return_value=ToolkitResponse.ok({"ok": True})) as mock_call_json:
        out = Sankhya(mcp=mock_mcp).load_view("VW_TEST", "1=1")

    assert out.data == {"ok": True}
    assert mock_call_json.call_args.kwargs["base_url"] == "https://runtime.sankhya.com"
    assert mock_call_json.call_args.kwargs["raise_for_http_error"] is True


@patch("biatoolkit.sankhya.helpers._runtime.BiaUtil")
def test_load_view_allows_disabling_raise_for_http_error(mock_biautil):
    """Valida que load_view propaga raise_for_http_error=False para a chamada subjacente."""
    from biatoolkit.core.response import ToolkitResponse
    mock_mcp = MagicMock()
    mock_header = MagicMock(current_host="https://runtime.sankhya.com", jsessionid="jsid456")
    mock_biautil.return_value.get_header.return_value = mock_header

    with patch.object(Sankhya, "call_json", return_value=ToolkitResponse.http_error(status_code=200, error="test error")) as mock_call_json:
        out = Sankhya(mcp=mock_mcp).load_view(
            "VW_TEST",
            "1=1",
            raise_for_http_error=False,
        )

    assert out.success is False
    assert mock_call_json.call_args.kwargs["raise_for_http_error"] is False


def test_load_view_requires_base_url_when_runtime_header_missing():
    """Confirma erro claro quando nem parâmetro nem header fornecem base_url."""
    mock_mcp = MagicMock()
    with patch("biatoolkit.sankhya.helpers._runtime.BiaUtil") as mock_biautil:
        mock_biautil.return_value.get_header.return_value = MagicMock(current_host=None)
        with pytest.raises(ValueError, match="base_url não definida"):
            Sankhya(mcp=mock_mcp).load_view("VW_TEST", "1=1", jsessionid="tok")

@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_success(mock_session):
    """Verifica retorno JSON em uma chamada HTTP bem-sucedida ao Sankhya."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"ok": True}
    mock_session.return_value.post.return_value = mock_resp
    s = Sankhya()
    out = s.call_json(payload={"x": 1}, jsessionid="tok", method="POST", base_url="https://fake.sankhya.com")
    assert out.success is True
    assert out.data == {"ok": True}

@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_http_error(mock_session):
    """Assegura que falhas HTTP levantam SankhyaHTTPError por padrão."""
    mock_resp = MagicMock()
    mock_resp.status_code = 500
    mock_resp.text = "fail"
    mock_session.return_value.post.return_value = mock_resp
    s = Sankhya()
    with pytest.raises(SankhyaHTTPError):
        s.call_json(payload={}, jsessionid="tok", method="POST", base_url="https://fake.sankhya.com")

@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_non_json_response(mock_session):
    """Garante fallback para raw_text quando a resposta HTTP não é JSON válido."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.side_effect = Exception("not json")
    mock_resp.text = "plain text"
    mock_session.return_value.post.return_value = mock_resp
    s = Sankhya()
    out = s.call_json(payload={}, jsessionid="tok", method="POST", base_url="https://fake.sankhya.com")
    assert out.success is True
    assert out.data == {"raw_text": "plain text"}


@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_raises_for_sankhya_business_error_even_with_http_200(mock_session):
    """Valida que erro de negócio Sankhya em HTTP 200 vira exceção no fluxo padrão."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "serviceName": "APIRestSP.handleRequestNoneTx",
        "status": "3",
        "statusMessage": "Não autorizado.",
    }
    mock_resp.text = '{"status":"3","statusMessage":"Não autorizado."}'
    mock_session.return_value.get.return_value = mock_resp

    s = Sankhya()
    with pytest.raises(SankhyaHTTPError) as exc:
        s.call_json(
            payload=None,
            jsessionid="abc.123",
            url="https://runtime.sankhya.com/v1/financeiros/receitas",
            method="GET",
        )

    assert exc.value.status_code == 200
    assert "Não autorizado" in str(exc.value)


@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_returns_error_payload_for_sankhya_business_error_when_not_raising(mock_session):
    """Confirma retorno estruturado de erro quando raise_for_http_error está desabilitado."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "serviceName": "APIRestSP.handleRequestNoneTx",
        "status": "3",
        "statusMessage": "Não autorizado.",
    }
    mock_resp.text = '{"status":"3","statusMessage":"Não autorizado."}'
    mock_session.return_value.get.return_value = mock_resp

    s = Sankhya()
    out = s.call_json(
        payload=None,
        jsessionid="abc.123",
        url="https://runtime.sankhya.com/v1/financeiros/receitas",
        method="GET",
        raise_for_http_error=False,
    )

    assert out.success is False
    assert out.status_code == 200
    assert "Não autorizado" in out.error

def test_static_call_delegates():
    """Garante que o atalho estático Sankhya.Call delega para call_json."""
    from biatoolkit.core.response import ToolkitResponse
    with patch.object(Sankhya, "call_json", return_value=ToolkitResponse.ok({"ok": 1})) as mock_call_json:
        out = Sankhya.Call(jsessionID="tok", payload={"a": 1}, base_url="https://fake.sankhya.com")
        assert out.data == {"ok": 1}
        assert mock_call_json.called


@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_with_service_path_resolves_base_url_and_includes_v1_params(mock_session):
    """Valida resolução de path REST v1 com base_url interna e parâmetros padrão."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"ok": True}
    mock_session.return_value.get.return_value = mock_resp

    s = Sankhya()
    with patch.object(s._runtime, "resolve_base_url", return_value="https://runtime.sankhya.com"):
        out = s.call_json(
            payload=None,
            jsessionid="abc.123",
            service_path="/v1/financeiros/receitas",
            query="pagina=1",
            method="GET",
        )

    assert out.success is True
    assert out.data == {"ok": True}
    called_url = mock_session.return_value.get.call_args.args[0]
    called_headers = mock_session.return_value.get.call_args.kwargs["headers"]
    assert called_url == (
        "https://runtime.sankhya.com/v1/financeiros/receitas"
        "?pagina=1&outputType=json&mgeSession=abc"
    )
    assert called_headers["Cookie"] == "JSESSIONID=abc.123"


@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_default_session_always_sends_cookie(mock_session):
    """Confirma que o fluxo padrão envia mgeSession truncado e Cookie completo."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"ok": True}
    mock_session.return_value.get.return_value = mock_resp

    s = Sankhya()
    with patch.object(s._runtime, "resolve_base_url", return_value="https://runtime.sankhya.com"):
        s.call_json(
            payload=None,
            jsessionid="abc.123",
            service_path="/v1/financeiros/receitas",
            query="pagina=1",
            method="GET",
        )

    called_url = mock_session.return_value.get.call_args.args[0]
    called_headers = mock_session.return_value.get.call_args.kwargs["headers"]
    assert "mgeSession=abc" in called_url
    assert called_headers["Cookie"] == "JSESSIONID=abc.123"


@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_returns_error_payload_for_http_404_when_not_raising(mock_session):
    """Garante payload de erro em 404 quando o caller opta por não lançar exceção."""
    mock_resp = MagicMock()
    mock_resp.status_code = 404
    mock_resp.text = "not found"
    mock_session.return_value.get.return_value = mock_resp

    s = Sankhya()
    out = s.call_json(
        payload=None,
        jsessionid="abc.123",
        url="https://runtime.sankhya.com/v1/financeiros/receitas",
        method="GET",
        raise_for_http_error=False,
    )

    assert out.success is False
    assert out.status_code == 404


@patch("biatoolkit.sankhya.helpers._http.requests.Session")
def test_call_json_raises_for_http_401(mock_session):
    """Assegura que resposta 401 continue sendo tratada como erro HTTP."""
    mock_resp = MagicMock()
    mock_resp.status_code = 401
    mock_resp.text = "unauthorized"
    mock_session.return_value.get.return_value = mock_resp

    s = Sankhya()
    with pytest.raises(SankhyaHTTPError) as exc:
        s.call_json(
            payload=None,
            jsessionid="abc.123",
            url="https://runtime.sankhya.com/v1/financeiros/receitas",
            method="GET",
        )
    assert exc.value.status_code == 401
