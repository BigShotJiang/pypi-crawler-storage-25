import os
from types import SimpleNamespace

from biatoolkit.core.util import BiaUtil


class _FakeMCP:
    def __init__(self, headers: dict):
        self._headers = headers

    def get_context(self):
        return SimpleNamespace(
            request_context=SimpleNamespace(
                request=SimpleNamespace(headers=self._headers)
            )
        )


def test_get_parameter_prefers_env(monkeypatch):
    """Valida que get_parameter prioriza variáveis de ambiente antes do SSM."""
    util = BiaUtil(_FakeMCP({}))
    monkeypatch.setenv("MEU_PARAM", "valor_env")
    assert util.get_parameter("MEU_PARAM") == "valor_env"


def test_get_parameter_falls_back_to_ssm(monkeypatch):
    """Garante fallback para SSM quando o parâmetro não existe no ambiente."""
    util = BiaUtil(_FakeMCP({}))
    monkeypatch.delenv("MEU_PARAM", raising=False)

    # Stub: força fallback "SSM" sem bater na AWS
    monkeypatch.setattr(util, "_BiaUtil__get_from_ssm", lambda name: "valor_ssm")

    assert util.get_parameter("MEU_PARAM") == "valor_ssm"


def test_get_parameter_returns_none_when_missing(monkeypatch):
    """Confirma retorno None quando a chave não existe nem em env nem no SSM."""
    util = BiaUtil(_FakeMCP({}))
    monkeypatch.delenv("MEU_PARAM", raising=False)
    monkeypatch.setattr(util, "_BiaUtil__get_from_ssm", lambda name: None)

    assert util.get_parameter("MEU_PARAM") is None

def test_get_parameter_does_not_call_ssm_when_env_exists(monkeypatch):
    """Assegura que o fallback externo não é consultado quando env já resolve a chave."""
    util = BiaUtil(_FakeMCP({}))
    monkeypatch.setenv("MEU_PARAM", "valor_env")

    # se chamar SSM, explode o teste
    monkeypatch.setattr(util, "_BiaUtil__get_from_ssm", lambda name: (_ for _ in ()).throw(RuntimeError("SSM called")))

    assert util.get_parameter("MEU_PARAM") == "valor_env"
