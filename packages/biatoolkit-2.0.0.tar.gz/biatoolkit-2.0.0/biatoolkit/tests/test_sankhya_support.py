import pytest

from biatoolkit.sankhya.helpers._support import (
    build_debug_payload,
    build_response_debug_payload,
    build_url,
    get_sankhya_business_error,
    inject_request_id,
    is_absolute_url,
    mask_secrets,
    parse_json_response,
    prepare_request,
    should_include_output_type_json,
)


def test_inject_request_id_preserves_existing_header():
    """Verifica que inject_request_id respeita um request id já fornecido."""
    headers = inject_request_id({"x-request-id": "req-123"})
    assert headers["x-request-id"] == "req-123"


def test_build_url_with_relative_path_and_query():
    """Valida montagem de URL relativa com base_url e querystring adicional."""
    out = build_url(url="service", base_url="https://fake.sankhya.com/root", query="a=1")
    assert out == "https://fake.sankhya.com/root/service?a=1"


def test_prepare_request_masks_secret_in_log_info_and_sets_cookie():
    """Confirma que prepare_request monta cookie e mascara segredos no log."""
    prepared = prepare_request(
        payload={"requestBody": {"query": {"viewName": "VW_TEST"}}},
        jsessionid="tok.secret",
        url=None,
        base_url="https://fake.sankhya.com",
        query="serviceName=x",
        method="POST",
        default_headers={"X-App": "bia"},
        extra_headers={"Authorization": "Bearer abc"},
        include_output_type_json=False,
        timeout=None,
        timeout_defaults=(1.0, 2.0),
    )

    assert prepared.headers["Cookie"] == "JSESSIONID=tok.secret"
    assert prepared.timeout == (1.0, 2.0)
    assert prepared.log_info["view_name"] == "VW_TEST"
    assert "mgeSession=%2A%2A%2A" in prepared.log_info["url"]


def test_prepare_request_v1_includes_output_type_and_truncated_mge_session():
    """Garante inclusão de outputType=json e mgeSession truncado para REST v1."""
    prepared = prepare_request(
        payload=None,
        jsessionid="tok.secret",
        url="/v1/financeiros/receitas",
        base_url="https://fake.sankhya.com",
        query="pagina=1",
        method="GET",
        default_headers={"X-App": "bia"},
        extra_headers=None,
        include_output_type_json=True,
        timeout=None,
        timeout_defaults=(1.0, 2.0),
    )

    assert prepared.url == (
        "https://fake.sankhya.com/v1/financeiros/receitas"
        "?pagina=1&outputType=json&mgeSession=tok"
    )
    assert prepared.headers["Cookie"] == "JSESSIONID=tok.secret"
    assert "mgeSession=tok" in prepared.url


def test_mask_secrets_masks_nested_structures():
    """Verifica mascaramento recursivo de segredos em estruturas aninhadas."""
    out = mask_secrets(
        {
            "Authorization": "Bearer abc",
            "nested": ["https://x.com?a=1&token=abc", {"cookie": "JSESSIONID=abc"}],
        }
    )

    assert out["Authorization"] == "***"
    assert "token=%2A%2A%2A" in out["nested"][0]
    assert out["nested"][1]["cookie"] == "***"


def test_build_debug_payload_masks_headers_and_payload():
    """Assegura que o payload de debug nunca exponha tokens ou authorization."""
    out = build_debug_payload(
        payload={"token": "abc"},
        headers={"Authorization": "Bearer abc"},
        log_info={"request_id": "req-1"},
    )

    assert out["headers"]["Authorization"] == "***"
    assert '"token": "***"' in out["payload"]


def test_build_response_debug_payload_masks_response_text():
    """Garante mascaramento de segredos também no texto de resposta logado."""
    out = build_response_debug_payload({"request_id": "req-1"}, "authorization: bearer abc")
    assert out["response"] == "authorization: bearer ***"


def test_parse_json_response_falls_back_to_raw_text():
    """Valida fallback para raw_text quando response.json() falha."""
    class _Response:
        text = "plain text"

        def json(self):
            raise ValueError("not json")

    assert parse_json_response(_Response()) == {"raw_text": "plain text"}


def test_get_sankhya_business_error_extracts_status_message_from_error_payload():
    """Extrai a mensagem de erro funcional quando o payload Sankhya indica falha."""
    out = get_sankhya_business_error(
        {
            "serviceName": "APIRestSP.handleRequestNoneTx",
            "status": "3",
            "statusMessage": "Não autorizado.",
        }
    )

    assert out == "Não autorizado."


def test_should_include_output_type_json_for_v1_path_only_when_missing():
    """Confirma inclusão automática de outputType=json em paths REST v1."""
    assert should_include_output_type_json("/v1/financeiros/receitas", "pagina=1") is True


def test_should_not_include_output_type_json_when_already_provided():
    """Evita duplicação de outputType quando a query já o informa explicitamente."""
    assert should_include_output_type_json("/v1/financeiros/receitas", "outputType=json") is False


def test_is_absolute_url_detection():
    """Valida a distinção entre URL absoluta e path relativo."""
    assert is_absolute_url("https://example.com/v1/recurso") is True
    assert is_absolute_url("/v1/recurso") is False