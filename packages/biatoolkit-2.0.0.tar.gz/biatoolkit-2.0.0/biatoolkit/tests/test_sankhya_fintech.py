from unittest.mock import MagicMock, patch, call

import pytest

import biatoolkit.sankhya.fintech as _fintech_mod
from biatoolkit.sankhya.fintech import (
    SankhyaFintech,
    SankhyaFintechSettings,
)
from biatoolkit.sankhya.helpers._fintech_support import (
    FintechHTTPError,
    build_fintech_url,
)


def _mock_response(status_code=200, json_body=None, text=""):
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = text or ""
    if isinstance(json_body, Exception):
        resp.json.side_effect = json_body
    else:
        resp.json.return_value = json_body if json_body is not None else {}
    return resp


# -------------------- Settings --------------------
def test_fintech_settings_from_env(monkeypatch):
    """Valida leitura de base_url, timeouts, retries e SSL do Fintech via variáveis de ambiente."""
    monkeypatch.setenv("SANKHYA_FINTECH_BASE_URL", "http://fake.fintech")
    monkeypatch.setenv("SANKHYA_FINTECH_TIMEOUT_CONNECT", "4.2")
    monkeypatch.setenv("SANKHYA_FINTECH_TIMEOUT_READ", "17")
    monkeypatch.setenv("SANKHYA_FINTECH_RETRIES_TOTAL", "5")
    monkeypatch.setenv("SANKHYA_FINTECH_RETRY_BACKOFF", "0.9")
    monkeypatch.setenv("SANKHYA_FINTECH_VERIFY_SSL", "0")
    s = SankhyaFintechSettings.from_env()
    assert s.base_url == "http://fake.fintech"
    assert s.timeout_connect == 4.2
    assert s.timeout_read == 17.0
    assert s.retries_total == 5
    assert s.retry_backoff == 0.9
    assert s.verify_ssl is False


# -------------------- Helpers --------------------
def test_build_fintech_url_basic():
    """Verifica a concatenação simples de base_url com service_path."""
    assert (
        build_fintech_url(base_url="http://api.fintech", service_path="/x/y")
        == "http://api.fintech/x/y"
    )


def test_build_fintech_url_trailing_slash_and_missing_lead():
    """Normaliza barra final da base e barra inicial ausente no service_path."""
    assert (
        build_fintech_url(base_url="http://api.fintech/", service_path="x/y")
        == "http://api.fintech/x/y"
    )


def test_build_fintech_url_with_query():
    """Confirma que a querystring é anexada corretamente à URL final."""
    assert (
        build_fintech_url(base_url="http://api.fintech", service_path="/x", query="a=1&b=2")
        == "http://api.fintech/x?a=1&b=2"
    )


def test_build_fintech_url_requires_base_and_path():
    """Garante erro quando base_url ou service_path estão vazios."""
    with pytest.raises(ValueError):
        build_fintech_url(base_url="", service_path="/x")
    with pytest.raises(ValueError):
        build_fintech_url(base_url="http://x", service_path="")


# -------------------- Resolvers --------------------
def test_resolve_integrator_token_explicit():
    """Confirma que um integrator_token explícito é usado sem consultar defaults."""
    f = SankhyaFintech()
    assert f._resolve_integrator_token("explicit-xyz") == "explicit-xyz"


def test_resolve_integrator_token_no_value_raises(monkeypatch):
    """Garante ValueError quando nenhuma fonte tem o token (sem env, sem cache, sem SSM prefix)."""
    monkeypatch.delenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", raising=False)
    monkeypatch.delenv("BIATOOLKIT_SSM_PREFIX", raising=False)
    _fintech_mod._cached_integrator_token = None
    _fintech_mod._cached_integrator_token_at = 0.0
    f = SankhyaFintech()
    with pytest.raises(ValueError, match="SANKHYA_FINTECH_INTEGRATOR_TOKEN"):
        f._resolve_integrator_token(None)
    with pytest.raises(ValueError):
        f._resolve_integrator_token("   ")


def test_resolve_integrator_token_from_env(monkeypatch):
    """Env var presente retorna o token sem consultar o SSM."""
    monkeypatch.setenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", "env-token-xyz")
    _fintech_mod._cached_integrator_token = None
    _fintech_mod._cached_integrator_token_at = 0.0
    f = SankhyaFintech()
    with patch("boto3.client") as mock_boto3:
        result = f._resolve_integrator_token(None)
    assert result == "env-token-xyz"
    mock_boto3.assert_not_called()


def test_resolve_integrator_token_from_ssm_direct(monkeypatch):
    """Com mcp=None e BIATOOLKIT_SSM_PREFIX definido, boto3 é chamado e retorna o token."""
    monkeypatch.delenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", raising=False)
    monkeypatch.setenv("BIATOOLKIT_SSM_PREFIX", "/biatoolkit")
    _fintech_mod._cached_integrator_token = None
    _fintech_mod._cached_integrator_token_at = 0.0
    f = SankhyaFintech()
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": "ssm-token-abc"}}
    mock_ssm.exceptions.ParameterNotFound = type("ParameterNotFound", (Exception,), {})
    with patch("boto3.client", return_value=mock_ssm):
        result = f._resolve_integrator_token(None)
    assert result == "ssm-token-abc"
    mock_ssm.get_parameter.assert_called_once_with(
        Name="/biatoolkit/SANKHYA_FINTECH_INTEGRATOR_TOKEN",
        WithDecryption=True,
    )


def test_resolve_integrator_token_uses_cache(monkeypatch):
    """Segunda chamada usa o cache e não chama boto3 novamente."""
    monkeypatch.delenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", raising=False)
    monkeypatch.setenv("BIATOOLKIT_SSM_PREFIX", "/biatoolkit")
    _fintech_mod._cached_integrator_token = None
    _fintech_mod._cached_integrator_token_at = 0.0
    f = SankhyaFintech()
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": "cached-token"}}
    mock_ssm.exceptions.ParameterNotFound = type("ParameterNotFound", (Exception,), {})
    with patch("boto3.client", return_value=mock_ssm):
        r1 = f._resolve_integrator_token(None)
        r2 = f._resolve_integrator_token(None)
    assert r1 == r2 == "cached-token"
    assert mock_ssm.get_parameter.call_count == 1


def test_resolve_integrator_token_cache_expired(monkeypatch):
    """Cache com TTL expirado força nova chamada ao SSM."""
    import time as _time
    monkeypatch.delenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", raising=False)
    monkeypatch.setenv("BIATOOLKIT_SSM_PREFIX", "/biatoolkit")
    _fintech_mod._cached_integrator_token = "old-token"
    _fintech_mod._cached_integrator_token_at = _time.monotonic() - (_fintech_mod._TOKEN_CACHE_TTL + 1)
    f = SankhyaFintech()
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": "fresh-token"}}
    mock_ssm.exceptions.ParameterNotFound = type("ParameterNotFound", (Exception,), {})
    with patch("boto3.client", return_value=mock_ssm):
        result = f._resolve_integrator_token(None)
    assert result == "fresh-token"
    mock_ssm.get_parameter.assert_called_once()


def test_resolve_codparc_explicit():
    """Verifica que um codparc explícito é preservado sem consultar o runtime."""
    f = SankhyaFintech()
    assert f._resolve_codparc(42) == 42


@patch("biatoolkit.sankhya.helpers._runtime.BiaUtil")
def test_resolve_codparc_from_header(mock_biautil):
    """Valida fallback para codparc do header do runtime quando não é informado."""
    mock_mcp = MagicMock()
    mock_biautil.return_value.get_header.return_value = MagicMock(codparc=123)
    f = SankhyaFintech(mcp=mock_mcp)
    assert f._resolve_codparc(None) == 123


def test_resolve_codparc_missing_raises():
    """Assegura erro explícito quando codparc não pode ser resolvido em lugar nenhum."""
    f = SankhyaFintech()
    with pytest.raises(ValueError, match="codparc ausente"):
        f._resolve_codparc(None)


# -------------------- Handshake --------------------
def _fintech_with_mocked_session():
    f = SankhyaFintech(
        fintech_settings=SankhyaFintechSettings(
            base_url="http://fake.fintech",
            timeout_connect=1.0,
            timeout_read=2.0,
            retries_total=0,
            retry_backoff=0.0,
            verify_ssl=False,
        )
    )
    f._session = MagicMock()
    return f


def test_auth_handshake_success_hits_three_steps_with_correct_headers_and_bodies():
    """Valida o handshake completo de 3 passos (integrator → efetivar → customer-token) com URLs, headers e bodies corretos."""
    f = _fintech_with_mocked_session()
    f._session.get.return_value = _mock_response(
        200, {"token": "int-ephemeral"}, text='{"token":"int-ephemeral"}'
    )
    f._session.post.side_effect = [
        _mock_response(
            200,
            {"cliente": {"id": "cli-999"}},
            text='{"cliente":{"id":"cli-999"}}',
        ),
        _mock_response(200, {"token": "customer-zzz"}, text='{"token":"customer-zzz"}'),
    ]

    token = f._auth_handshake(
        codparc=77,
        nome="ACME LTDA",
        integrator_token="INT-KEY",
        extra_headers=None,
        timeout=(1.0, 2.0),
    )

    assert token == "customer-zzz"

    get_args = f._session.get.call_args
    assert get_args.args[0] == "http://fake.fintech/api/v1/public/auth/integrator-token"
    assert get_args.kwargs["headers"]["X-Integrator-Token"] == "INT-KEY"

    post_calls = f._session.post.call_args_list
    assert post_calls[0].args[0] == (
        "http://fake.fintech/api/v1/admin/credenciamento/pre-contratacao/efetivar"
    )
    assert post_calls[0].kwargs["headers"]["Authorization"] == "Bearer int-ephemeral"
    assert post_calls[0].kwargs["json"] == {"cliente": {"idExterno": "77", "nome": "ACME LTDA"}}

    assert post_calls[1].args[0] == "http://fake.fintech/api/v1/public/auth/customer-token"
    assert post_calls[1].kwargs["headers"]["X-Integrator-Token"] == "INT-KEY"
    assert post_calls[1].kwargs["json"] == {"customer_id": "cli-999"}


def test_auth_handshake_step1_failure_raises_with_step_label():
    """Garante que falha no passo 1 (integrator-token) sobe erro marcado com step='integrator'."""
    f = _fintech_with_mocked_session()
    f._session.get.return_value = _mock_response(500, {}, text="boom")
    with pytest.raises(FintechHTTPError) as exc:
        f._auth_handshake(
            codparc=1,
            nome="X",
            integrator_token="k",
            extra_headers=None,
            timeout=(1.0, 2.0),
        )
    assert exc.value.step == "integrator"
    assert exc.value.status_code == 500


def test_auth_handshake_step2_failure_raises_with_step_label():
    """Garante que falha no passo 2 (pre-contratacao/efetivar) sobe erro marcado com step='efetivar'."""
    f = _fintech_with_mocked_session()
    f._session.get.return_value = _mock_response(200, {"token": "t1"}, text='{"token":"t1"}')
    f._session.post.return_value = _mock_response(400, {}, text="bad")
    with pytest.raises(FintechHTTPError) as exc:
        f._auth_handshake(
            codparc=1,
            nome="X",
            integrator_token="k",
            extra_headers=None,
            timeout=(1.0, 2.0),
        )
    assert exc.value.step == "efetivar"
    assert exc.value.status_code == 400


def test_auth_handshake_step3_failure_raises_with_step_label():
    """Garante que falha no passo 3 (customer-token) sobe erro marcado com step='customer'."""
    f = _fintech_with_mocked_session()
    f._session.get.return_value = _mock_response(200, {"token": "t1"}, text='{"token":"t1"}')
    f._session.post.side_effect = [
        _mock_response(200, {"cliente": {"id": "c1"}}, text='{"cliente":{"id":"c1"}}'),
        _mock_response(401, {}, text="unauthorized"),
    ]
    with pytest.raises(FintechHTTPError) as exc:
        f._auth_handshake(
            codparc=1,
            nome="X",
            integrator_token="k",
            extra_headers=None,
            timeout=(1.0, 2.0),
        )
    assert exc.value.step == "customer"
    assert exc.value.status_code == 401


def test_auth_handshake_missing_cliente_id_raises():
    """Assegura erro no passo 'efetivar' quando a resposta não retorna cliente.id."""
    f = _fintech_with_mocked_session()
    f._session.get.return_value = _mock_response(200, {"token": "t1"}, text='{"token":"t1"}')
    f._session.post.return_value = _mock_response(200, {"cliente": {}}, text='{"cliente":{}}')
    with pytest.raises(FintechHTTPError) as exc:
        f._auth_handshake(
            codparc=1,
            nome="X",
            integrator_token="k",
            extra_headers=None,
            timeout=(1.0, 2.0),
        )
    assert exc.value.step == "efetivar"


# -------------------- call_json --------------------
def _fintech_with_handshake(customer_token="CUST-TKN"):
    f = _fintech_with_mocked_session()
    f._auth_handshake = MagicMock(return_value=customer_token)
    return f


def test_call_sends_bearer_and_returns_parsed_body():
    """Valida que call() dispara o handshake, envia Bearer do customer-token e retorna o JSON."""
    f = _fintech_with_handshake("CUST-TKN")
    f._session.post.return_value = _mock_response(
        200, {"ok": True, "id": 1}, text='{"ok":true}'
    )

    out = f.call(
        service_path="/api/v1/pix/cobrancas",
        nome="ACME LTDA",
        codparc=77,
        payload={"valor": 50.0},
    )

    assert out.success is True
    assert out.data == {"ok": True, "id": 1}
    f._auth_handshake.assert_called_once()
    call = f._session.post.call_args
    assert call.args[0] == "http://fake.fintech/api/v1/pix/cobrancas"
    assert call.kwargs["headers"]["Authorization"] == "Bearer CUST-TKN"
    assert call.kwargs["json"] == {"valor": 50.0}


def test_call_missing_nome_raises():
    """Garante erro de validação quando o nome do cliente não é informado em call()."""
    f = _fintech_with_handshake()
    with pytest.raises(ValueError, match="nome"):
        f.call(service_path="/x", nome="", codparc=1)


def test_call_raises_on_http_error_by_default():
    """Confirma que erros HTTP da chamada final sobem como FintechHTTPError com step='call'."""
    f = _fintech_with_handshake()
    f._session.post.return_value = _mock_response(500, {}, text="fail")
    with pytest.raises(FintechHTTPError) as exc:
        f.call(
            service_path="/x",
            nome="ACME",
            codparc=1,
            payload={},
        )
    assert exc.value.step == "call"
    assert exc.value.status_code == 500


def test_call_returns_error_payload_when_not_raising():
    """Valida que call() devolve ToolkitResponse de erro quando raise_for_http_error=False."""
    f = _fintech_with_handshake()
    f._session.post.return_value = _mock_response(404, {}, text="nope")
    out = f.call(
        service_path="/x",
        nome="ACME",
        codparc=1,
        payload={},
        raise_for_http_error=False,
    )
    assert out.success is False
    assert out.status_code == 404
    assert "404" in out.error


def test_call_supports_get_without_payload():
    """Confirma suporte a GET sem payload, preservando querystring na URL final."""
    f = _fintech_with_handshake()
    f._session.get.return_value = _mock_response(200, {"items": []}, text='{"items":[]}')
    out = f.call(
        service_path="/api/v1/pix/cobrancas",
        nome="ACME",
        codparc=1,
        method="GET",
        query="pagina=1",
    )
    assert out.success is True
    assert out.data == {"items": []}
    called_url = f._session.get.call_args.args[0]
    assert called_url == "http://fake.fintech/api/v1/pix/cobrancas?pagina=1"


# -------------------- Static shortcut --------------------
def test_static_call_delegates_to_instance():
    """Garante que o atalho estático SankhyaFintech.Call delega para o método de instância call()."""
    from biatoolkit.core.response import ToolkitResponse
    with patch.object(SankhyaFintech, "call", return_value=ToolkitResponse.ok({"ok": 1})) as m:
        out = SankhyaFintech.Call(
            service_path="/x",
            nome="ACME",
            codparc=1,
            payload={"a": 1},
        )
        assert out.data == {"ok": 1}
        assert m.called


