"""
biatoolkit.sankhya.fintech

Integração com o gateway financeiro da Sankhya (fintechapi).

Este módulo é responsável por toda a camada de comunicação com o gateway —
desde a autenticação (handshake de 3 passos) até a execução de operações
financeiras (Pix, Pagamentos, Boleto). O dev do MCP Tool não precisa conhecer
os detalhes do protocolo de autenticação; basta chamar `call_json` ou `Call`.

──────────────────────────────────────────────────────────────
FLUXO DE AUTENTICAÇÃO (executado automaticamente a cada call_json)
──────────────────────────────────────────────────────────────

  1. GET  /api/v1/public/auth/integrator-token
       Header: X-Integrator-Token: <chave do integrador>
       → retorna um Bearer token de curta duração (integrator_bearer)

  2. POST /api/v1/admin/credenciamento/pre-contratacao/efetivar
       Header: Authorization: Bearer <integrator_bearer>
       Body:   { "cliente": { "idExterno": "<CODPARC>", "nome": "<NOMEPARC>" } }
       → retorna o cliente.id cadastrado no gateway

  3. POST /api/v1/public/auth/customer-token
       Header: X-Integrator-Token: <chave do integrador>
       Body:   { "customer_id": "<cliente.id>" }
       → retorna o customer_token (Bearer) usado nas operações financeiras

  4. Chamada real (Pix, Pagamentos, etc.)
       Header: Authorization: Bearer <customer_token>

──────────────────────────────────────────────────────────────
CONFIG VIA ENV (todas opcionais)
──────────────────────────────────────────────────────────────
  SANKHYA_FINTECH_BASE_URL          default http://fintechapi-dev.sankhya.com.br
  SANKHYA_FINTECH_TIMEOUT_CONNECT   default 3.05
  SANKHYA_FINTECH_TIMEOUT_READ      default 12
  SANKHYA_FINTECH_RETRIES_TOTAL     default 3
  SANKHYA_FINTECH_RETRY_BACKOFF     default 0.5
  SANKHYA_FINTECH_VERIFY_SSL        default "1"
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
import logging
import os
import time

from ..core.response import ToolkitResponse
from ..core.settings import BiaToolkitSettings
from .helpers._fintech_support import FintechHTTPError, build_fintech_url
from .helpers._http import HTTPClientSettings, build_retry_session, execute_request
from .helpers._runtime import SankhyaRuntimeResolver
from .helpers._support import inject_request_id, mask_secrets


logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# CACHE DO INTEGRATOR TOKEN
# ──────────────────────────────────────────────────────────────

_cached_integrator_token: Optional[str] = None
_cached_integrator_token_at: float = 0.0
_TOKEN_CACHE_TTL = 300.0  # segundos — evita bater no SSM em cada handshake


# ──────────────────────────────────────────────────────────────
# CONSTANTES DO GATEWAY
# ──────────────────────────────────────────────────────────────

_DEFAULT_BASE_URL = "http://fintechapi-dev.sankhya.com.br"

# Endpoints do handshake de autenticação
_PATH_INTEGRATOR_TOKEN = "/api/v1/public/auth/integrator-token"
_PATH_EFETIVAR = "/api/v1/admin/credenciamento/pre-contratacao/efetivar"
_PATH_CUSTOMER_TOKEN = "/api/v1/public/auth/customer-token"




# ──────────────────────────────────────────────────────────────
# SETTINGS
# ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class SankhyaFintechSettings(HTTPClientSettings):
    """
    Configurações de conexão com o gateway fintech.
    Herda os 5 campos comuns de HTTPClientSettings e adiciona `base_url`
    (o gateway tem URL fixa, diferente do ERP que vem do header do runtime).
    """

    base_url: str = _DEFAULT_BASE_URL

    @staticmethod
    def from_env() -> "SankhyaFintechSettings":
        """Cria a instância lendo variáveis de ambiente; usa defaults se ausentes."""

        def _f(name: str, default: float) -> float:
            try:
                return float(os.getenv(name, str(default)))
            except Exception:
                return default

        def _i(name: str, default: int) -> int:
            try:
                return int(os.getenv(name, str(default)))
            except Exception:
                return default

        def _b(name: str, default: bool) -> bool:
            raw = os.getenv(name, "1" if default else "0").strip().lower()
            return raw in ("1", "true", "yes", "y", "on")

        return SankhyaFintechSettings(
            base_url=os.getenv("SANKHYA_FINTECH_BASE_URL", _DEFAULT_BASE_URL).strip(),
            timeout_connect=_f("SANKHYA_FINTECH_TIMEOUT_CONNECT", 3.05),
            timeout_read=_f("SANKHYA_FINTECH_TIMEOUT_READ", 12.0),
            retries_total=_i("SANKHYA_FINTECH_RETRIES_TOTAL", 3),
            retry_backoff=_f("SANKHYA_FINTECH_RETRY_BACKOFF", 0.5),
            verify_ssl=_b("SANKHYA_FINTECH_VERIFY_SSL", True),
        )


# ──────────────────────────────────────────────────────────────
# CLASSE PRINCIPAL
# ──────────────────────────────────────────────────────────────

class SankhyaFintech:
    """
    Cliente do gateway financeiro Sankhya (fintechapi).

    Encapsula o handshake de autenticação e expõe uma interface simples
    para que os MCP Tools façam operações financeiras sem conhecer os
    detalhes do protocolo de auth.

    Uso em MCP server:
        fintech = SankhyaFintech(mcp)
        resp = fintech.call(
            service_path="/api/v1/pix/cobrancas",
            nome="ACME COMERCIO LTDA",
            payload={"valor": 100.0},
        )

    Atalho estático (sem instanciar):
        SankhyaFintech.Call(mcp=mcp, service_path="...", nome="...")
    """

    def __init__(
        self,
        mcp: Optional[Any] = None,
        *,
        toolkit_settings: Optional[BiaToolkitSettings] = None,
        fintech_settings: Optional[SankhyaFintechSettings] = None,
        default_headers: Optional[Dict[str, str]] = None,
    ):
        self.mcp = mcp
        self.toolkit_settings = toolkit_settings or BiaToolkitSettings.from_env()
        self.fintech_settings = fintech_settings or SankhyaFintechSettings.from_env()
        self.default_headers = default_headers or {}

        # SankhyaRuntimeResolver extrai codparc e outros dados do header do AgentCore
        self._runtime = SankhyaRuntimeResolver(self.mcp, self.toolkit_settings)
        # Sessão HTTP compartilhada com retries em 429/5xx (helpers._http)
        self._session = build_retry_session(
            retries_total=self.fintech_settings.retries_total,
            retry_backoff=self.fintech_settings.retry_backoff,
        )

    # ──────────────────────────────────────────────────────────
    # CAMADA HTTP — wrapper fino sobre execute_request
    # ──────────────────────────────────────────────────────────

    def _request(
        self,
        *,
        method: str,
        url: str,
        headers: Dict[str, str],
        payload: Optional[Dict[str, Any]],
        timeout: Tuple[float, float],
        step: str,
        raise_for_http_error: bool,
    ) -> Tuple[int, Dict[str, Any], str]:
        """
        Wrapper fino sobre `execute_request` que preenche o contexto de log
        específico do Fintech (component name, step, label). A lógica HTTP
        completa (logs, retry, exception) está em helpers._http.
        """
        log_info = {
            "component": "biatoolkit.sankhya_fintech",
            "request_id": headers.get("x-request-id"),
            "step": step,
            "method": method,
            "url": mask_secrets(url),
        }
        return execute_request(
            self._session,
            method=method,
            url=url,
            headers=headers,
            payload=payload,
            timeout=timeout,
            verify_ssl=self.fintech_settings.verify_ssl,
            log_info=log_info,
            component_label=f"SankhyaFintech {step}",
            error_cls=FintechHTTPError,
            step=step,
            raise_for_http_error=raise_for_http_error,
        )

    # ──────────────────────────────────────────────────────────
    # RESOLVERS — obtêm credenciais do contexto ou do caller
    # ──────────────────────────────────────────────────────────

    def _resolve_integrator_token(self, explicit: Optional[str]) -> str:
        """Resolve o integrator token: arg explícito → env var → cache → SSM → ValueError."""
        global _cached_integrator_token, _cached_integrator_token_at

        if explicit and str(explicit).strip():
            return str(explicit).strip()

        from_env = os.getenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", "").strip()
        if from_env:
            return from_env

        now = time.monotonic()
        if _cached_integrator_token and (now - _cached_integrator_token_at) < _TOKEN_CACHE_TTL:
            return _cached_integrator_token

        token: Optional[str] = None

        if self.mcp is not None:
            from ..core.util import BiaUtil
            raw = BiaUtil(self.mcp, self.toolkit_settings).get_parameter("SANKHYA_FINTECH_INTEGRATOR_TOKEN")
            if raw and str(raw).strip():
                token = str(raw).strip()

        if not token:
            prefix = os.getenv("BIATOOLKIT_SSM_PREFIX", "").strip()
            if prefix:
                import boto3
                client = boto3.client("ssm", region_name=self.toolkit_settings.aws_region)
                try:
                    resp = client.get_parameter(
                        Name=f"{prefix}/SANKHYA_FINTECH_INTEGRATOR_TOKEN",
                        WithDecryption=True,
                    )
                    raw = resp.get("Parameter", {}).get("Value", "")
                    token = raw.strip() or None
                except client.exceptions.ParameterNotFound:
                    pass

        if token:
            _cached_integrator_token = token
            _cached_integrator_token_at = now
            return token

        raise ValueError(
            "SANKHYA_FINTECH_INTEGRATOR_TOKEN não encontrado. "
            "Defina a variável de ambiente ou armazene no SSM com BIATOOLKIT_SSM_PREFIX=/biatoolkit."
        )

    def _resolve_codparc(self, explicit: Optional[int]) -> int:
        """Usa o codparc explícito se informado; caso contrário lê do header do runtime."""
        return self._runtime.resolve_codparc(explicit)

    def _timeout(self, override: Optional[Tuple[float, float]]) -> Tuple[float, float]:
        """Retorna o timeout informado ou o default das settings."""
        return override or (self.fintech_settings.timeout_connect, self.fintech_settings.timeout_read)

    def _base_headers(self, extra: Optional[Dict[str, str]]) -> Dict[str, str]:
        """Monta os headers base que serão reutilizados em todos os passos do handshake."""
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        headers.update(self.default_headers)
        if extra:
            headers.update(extra)
        return inject_request_id(headers)  # garante x-request-id único por request chain

    # ──────────────────────────────────────────────────────────
    # HANDSHAKE — 3 passos de autenticação no gateway
    # ──────────────────────────────────────────────────────────

    def _step1_get_integrator_bearer(
        self,
        integrator_token: str,
        base_headers: Dict[str, str],
        timeout: Tuple[float, float],
    ) -> str:
        """
        Passo 1: obtém um Bearer token de curta duração usando a chave do integrador.

        GET /api/v1/public/auth/integrator-token
        Header: X-Integrator-Token: <integrator_token>
        → retorna access_token para usar como Bearer no passo 2.
        """
        url = build_fintech_url(base_url=self.fintech_settings.base_url, service_path=_PATH_INTEGRATOR_TOKEN)
        # A chave do integrador vai no header X-Integrator-Token (não como Bearer)
        headers = {**base_headers, "X-Integrator-Token": integrator_token}
        _, body, raw = self._request(method="GET", url=url, headers=headers, payload=None, timeout=timeout, step="integrator", raise_for_http_error=True)
        return self._extract_token(body, step="integrator", raw_text=raw)

    def _step2_get_cliente_id(
        self,
        integrator_bearer: str,
        codparc: int,
        nome: str,
        base_headers: Dict[str, str],
        timeout: Tuple[float, float],
    ) -> str:
        """
        Passo 2: credencia ou recupera o cliente no gateway pelo CODPARC do Sankhya ERP.

        POST /api/v1/admin/credenciamento/pre-contratacao/efetivar
        Header: Authorization: Bearer <integrator_bearer>
        Body:   { "cliente": { "idExterno": "<CODPARC>", "nome": "<NOMEPARC>" } }
        → retorna cliente.id (ID interno do gateway, diferente do CODPARC).
        """
        url = build_fintech_url(base_url=self.fintech_settings.base_url, service_path=_PATH_EFETIVAR)
        # O bearer do passo 1 autoriza esta operação administrativa de credenciamento
        headers = {**base_headers, "Authorization": f"Bearer {integrator_bearer}"}
        # idExterno é o CODPARC do Sankhya; o gateway usa isso como chave de ligação
        payload = {"cliente": {"idExterno": str(codparc), "nome": nome}}
        _, body, raw = self._request(method="POST", url=url, headers=headers, payload=payload, timeout=timeout, step="efetivar", raise_for_http_error=True)
        return self._extract_cliente_id(body, raw_text=raw)

    def _step3_get_customer_token(
        self,
        cliente_id: str,
        integrator_token: str,
        base_headers: Dict[str, str],
        timeout: Tuple[float, float],
    ) -> str:
        """
        Passo 3: obtém o token do cliente para autorizar operações financeiras.

        POST /api/v1/public/auth/customer-token
        Header: X-Integrator-Token: <integrator_token>
        Body:   { "customer_id": "<cliente.id>" }
        → retorna o customer Bearer token. Com ele é possível fazer Pix, Pagamentos etc.
        """
        url = build_fintech_url(base_url=self.fintech_settings.base_url, service_path=_PATH_CUSTOMER_TOKEN)
        # Volta a usar X-Integrator-Token (não o Bearer do passo 1)
        headers = {**base_headers, "X-Integrator-Token": integrator_token}
        payload = {"customer_id": cliente_id}
        _, body, raw = self._request(method="POST", url=url, headers=headers, payload=payload, timeout=timeout, step="customer", raise_for_http_error=True)
        return self._extract_token(body, step="customer", raw_text=raw)

    def _auth_handshake(
        self,
        *,
        codparc: int,
        nome: str,
        integrator_token: str,
        extra_headers: Optional[Dict[str, str]],
        timeout: Tuple[float, float],
    ) -> str:
        """
        Orquestra os 3 passos de autenticação e ret/orna o customer_token pronto para uso.

        Esse token é o único que deve ser passado como Authorization: Bearer
        nas chamadas às APIs financeiras (Pix, Pagamentos, Boleto).
        """
        base = self._base_headers(extra_headers)

        integrator_bearer = self._step1_get_integrator_bearer(integrator_token, base, timeout)
        cliente_id = self._step2_get_cliente_id(integrator_bearer, codparc, nome, base, timeout)
        customer_token = self._step3_get_customer_token(cliente_id, integrator_token, base, timeout)

        return customer_token

    # ──────────────────────────────────────────────────────────
    # EXTRATORES — parse das respostas do gateway
    # ──────────────────────────────────────────────────────────

    @staticmethod
    def _extract_token(body: Any, *, step: str, raw_text: str) -> str:
        """Extrai o token de acesso da resposta do gateway (suporta múltiplos nomes de campo)."""
        if isinstance(body, dict):
            for key in ("token", "access_token", "accessToken"):
                value = body.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
        raise FintechHTTPError(
            f"Resposta do passo '{step}' sem token reconhecível. Keys recebidas: {list(body.keys()) if isinstance(body, dict) else type(body).__name__}",
            status_code=200,
            response_text=raw_text,
            step=step,
        )

    @staticmethod
    def _extract_cliente_id(body: Any, *, raw_text: str) -> str:
        """Extrai o cliente.id da resposta do passo efetivar."""
        if isinstance(body, dict):
            cliente = body.get("cliente")
            if isinstance(cliente, dict):
                cid = cliente.get("id")
                if cid is not None and str(cid).strip():
                    return str(cid).strip()
        raise FintechHTTPError(
            "Resposta do passo 'efetivar' sem cliente.id.",
            status_code=200,
            response_text=raw_text,
            step="efetivar",
        )

    # ──────────────────────────────────────────────────────────
    # API PÚBLICA — interface para os MCP Tools
    # ──────────────────────────────────────────────────────────

    def call(
        self,
        *,
        service_path: str,
        nome: str,
        method: str = "POST",
        payload: Optional[Dict[str, Any]] = None,
        query: Optional[str] = None,
        codparc: Optional[int] = None,
        integrator_token: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        timeout: Optional[Tuple[float, float]] = None,
        raise_for_http_error: bool = True,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """
        Realiza uma chamada autenticada ao gateway financeiro da Sankhya.

        O handshake de 3 passos é executado automaticamente antes de cada chamada.
        O MCP Tool não precisa gerenciar tokens — só informa o endpoint e o payload.

        Args:
            service_path:      Path da API fintech, ex: "/api/v1/pix/cobrancas".
            nome:              NOMEPARC do parceiro (obrigatório para o credenciamento).
            method:            Método HTTP: GET, POST, PUT, PATCH, DELETE.
            payload:           Body JSON (para métodos com body).
            query:             Querystring adicional, ex: "pagina=1&tamanho=20".
            codparc:           CODPARC do Sankhya. Se None, lê do header do runtime.
            integrator_token:  Chave do integrador. Se None, usa o token de DEV.
            extra_headers:     Headers adicionais aplicados em todas as requisições.
            timeout:           (connect_secs, read_secs). Se None, usa as settings.
            raise_for_http_error: Se True (padrão), lança FintechHTTPError em 4xx/5xx.

        Returns:
            ToolkitResponse[Dict]: Resposta estruturada com success, data, error, status_code.
        """
        return self._call_json(
            service_path=service_path,
            nome=nome,
            method=method,
            payload=payload,
            query=query,
            codparc=codparc,
            integrator_token=integrator_token,
            extra_headers=extra_headers,
            timeout=timeout,
            raise_for_http_error=raise_for_http_error,
        )

    def _call_json(
        self,
        *,
        service_path: str,
        nome: str,
        method: str = "POST",
        payload: Optional[Dict[str, Any]] = None,
        query: Optional[str] = None,
        codparc: Optional[int] = None,
        integrator_token: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        timeout: Optional[Tuple[float, float]] = None,
        raise_for_http_error: bool = True,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """Implementação interna de call. Use call() ao invés."""
        if not nome or not str(nome).strip():
            raise ValueError("nome (NOMEPARC) é obrigatório para o handshake do fintech.")

        resolved_codparc = self._resolve_codparc(codparc)
        resolved_integrator = self._resolve_integrator_token(integrator_token)
        tmo = self._timeout(timeout)

        # Executa o handshake e obtém o customer_token com permissão para operações financeiras
        customer_token = self._auth_handshake(
            codparc=resolved_codparc,
            nome=str(nome).strip(),
            integrator_token=resolved_integrator,
            extra_headers=extra_headers,
            timeout=tmo,
        )

        # Monta a URL e os headers da chamada final com o token do cliente
        final_url = build_fintech_url(base_url=self.fintech_settings.base_url, service_path=service_path, query=query)
        headers = self._base_headers(extra_headers)
        headers["Authorization"] = f"Bearer {customer_token}"

        status, parsed, raw_text = self._request(
            method=method,
            url=final_url,
            headers=headers,
            payload=payload,
            timeout=tmo,
            step="call",
            raise_for_http_error=raise_for_http_error,
        )

        request_id = headers.get("x-request-id")

        if not (200 <= status < 300):
            logger.warning(
                "[BIATOOLKIT] SankhyaFintech HTTP ERROR call",
                extra={"custom": {
                    "component": "biatoolkit.sankhya_fintech",
                    "request_id": request_id,
                    "method": method,
                    "url": mask_secrets(final_url),
                    "service_path": service_path,
                    "http_status": status,
                }},
            )
            return ToolkitResponse.http_error(
                status_code=status,
                error=f"Falha HTTP {status} ao chamar o gateway fintech.",
                request_id=request_id,
            )

        return ToolkitResponse.ok(
            data=parsed,
            status_code=status,
            request_id=request_id,
        )

    @staticmethod
    def Call(
        *,
        service_path: str,
        nome: str,
        mcp: Optional[Any] = None,
        method: str = "POST",
        payload: Optional[Dict[str, Any]] = None,
        query: Optional[str] = None,
        codparc: Optional[int] = None,
        integrator_token: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        raise_for_http_error: bool = True,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """
        Atalho estático — equivalente a instanciar SankhyaFintech e chamar call.
        Útil para chamadas avulsas sem precisar guardar a instância.

        Returns:
            ToolkitResponse[Dict]: Resposta estruturada.
        """
        fintech = SankhyaFintech(mcp=mcp)
        return fintech.call(
            service_path=service_path,
            nome=nome,
            method=method,
            payload=payload,
            query=query,
            codparc=codparc,
            integrator_token=integrator_token,
            extra_headers=extra_headers,
            raise_for_http_error=raise_for_http_error,
        )


__all__ = ["SankhyaFintech", "SankhyaFintechSettings", "FintechHTTPError"]
