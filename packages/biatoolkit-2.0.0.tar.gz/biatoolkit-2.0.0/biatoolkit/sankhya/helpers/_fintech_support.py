"""
Helpers específicos da integração com o gateway fintech da Sankhya.

Distinções em relação ao helper do ERP (_sankhya_support):
- Não monta /mge/service.sbr nem parâmetro mgeSession.
- Não injeta Cookie JSESSIONID.
- Usa Bearer tokens (integrator e customer) nos headers.
"""

from __future__ import annotations

from typing import Optional

from ._http import BiaHTTPError


class FintechHTTPError(BiaHTTPError):
    """
    Erro HTTP/negócio em chamadas ao gateway fintech.

    Herda de BiaHTTPError. O campo `step` indica qual fase falhou:
    "integrator" | "efetivar" | "customer" | "call".
    """
    pass


def build_fintech_url(
    *,
    base_url: str,
    service_path: str,
    query: Optional[str] = None,
) -> str:
    if not base_url or not base_url.strip():
        raise ValueError("base_url do fintech é obrigatório.")
    if not service_path or not service_path.strip():
        raise ValueError("service_path do fintech é obrigatório.")

    path = service_path.strip()
    if not path.startswith("/"):
        path = "/" + path

    final_url = base_url.strip().rstrip("/") + path

    if not query:
        return final_url
    separator = "&" if "?" in final_url else "?"
    return f"{final_url}{separator}{query.lstrip('?')}"


__all__ = ["FintechHTTPError", "build_fintech_url"]
