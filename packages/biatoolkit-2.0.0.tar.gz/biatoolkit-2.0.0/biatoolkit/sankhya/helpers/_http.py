"""
biatoolkit.sankhya.helpers._http

Camada HTTP genérica compartilhada entre a integração com o ERP Sankhya e o
gateway Fintech. Isola a lógica duplicada de sessão com retries, execução de
request com logs padronizados e tratamento de erros HTTP.

Responsabilidades:
  - `BiaHTTPError`: exceção base do toolkit (subclassificada por domínio).
  - `HTTPClientSettings`: dataclass base com os 5 campos comuns de settings HTTP.
  - `build_retry_session`: cria `requests.Session` com política de retries padrão.
  - `execute_request`: executa GET/POST com logs BEGIN/END/DEBUG/EXCEPTION.

Cada domínio (ERP, Fintech) mantém sua lógica específica (auth, URL building,
business errors) e delega apenas a parte HTTP pura para este módulo.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple, Type
import json
import logging

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ._support import mask_secrets, now_ms, parse_json_response, truncate_text


logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# EXCEÇÃO BASE
# ──────────────────────────────────────────────────────────────

class BiaHTTPError(RuntimeError):
    """
    Exceção HTTP base do biatoolkit.

    Campos:
      - status_code: status HTTP (quando aplicável).
      - response_text: corpo bruto da resposta.
      - step: rótulo opcional do passo (usado pelo handshake do Fintech:
              "integrator" | "efetivar" | "customer" | "call"). None no ERP.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        response_text: str = "",
        step: Optional[str] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_text = response_text
        self.step = step


# ──────────────────────────────────────────────────────────────
# SETTINGS BASE
# ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class HTTPClientSettings:
    """Campos comuns de settings HTTP — herdado por SankhyaSettings e SankhyaFintechSettings."""

    timeout_connect: float
    timeout_read: float
    retries_total: int
    retry_backoff: float
    verify_ssl: bool


# ──────────────────────────────────────────────────────────────
# SESSÃO HTTP COM RETRIES
# ──────────────────────────────────────────────────────────────

def build_retry_session(*, retries_total: int, retry_backoff: float) -> requests.Session:
    """
    Cria uma `requests.Session` com política de retries padrão do toolkit.

    Retenta automaticamente em falhas transitórias (429 rate-limit e 5xx),
    com backoff exponencial configurável. Não retenta em 4xx (exceto 429).
    """
    s = requests.Session()
    retries = Retry(
        total=max(0, int(retries_total)),
        connect=max(0, int(retries_total)),
        read=max(0, int(retries_total)),
        backoff_factor=float(retry_backoff),
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=("POST", "GET"),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retries)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s


# ──────────────────────────────────────────────────────────────
# EXECUÇÃO DE REQUEST COM LOGS PADRONIZADOS
# ──────────────────────────────────────────────────────────────

def execute_request(
    session: requests.Session,
    *,
    method: str,
    url: str,
    headers: Dict[str, str],
    payload: Optional[Dict[str, Any]],
    timeout: Tuple[float, float],
    verify_ssl: bool,
    log_info: Dict[str, Any],
    component_label: str,
    error_cls: Type[BiaHTTPError],
    step: Optional[str] = None,
    raise_for_http_error: bool = True,
) -> Tuple[int, Dict[str, Any], str]:
    """
    Executa uma requisição HTTP com logs padronizados do toolkit.

    Args:
      session: sessão HTTP pré-configurada (usar `build_retry_session`).
      method: "GET" | "POST" | etc.
      url: URL completa.
      headers: headers (incluindo Authorization, Content-Type, x-request-id).
      payload: corpo JSON (apenas para métodos com body).
      timeout: (connect_secs, read_secs).
      verify_ssl: verificar certificado SSL.
      log_info: dict com contexto de log (component, request_id, step, method, url...).
      component_label: rótulo usado nos logs BEGIN/END/DEBUG (ex: "Sankhya call_json").
      error_cls: classe de exceção a lançar em HTTP error (subclasse de BiaHTTPError).
      step: rótulo opcional do passo (passado para a exceção).
      raise_for_http_error: se True, lança `error_cls` em 4xx/5xx.

    Returns:
      Tupla (status_code, parsed_body, raw_text).
      Caller decide o que fazer com o resultado (ex: checar business error no ERP).
    """
    start = now_ms()

    logger.info(f"[BIATOOLKIT] BEGIN {component_label}: " + json.dumps(log_info, default=str))
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug(
            f"[BIATOOLKIT] {component_label} DEBUG",
            extra={
                "custom": {
                    **log_info,
                    "headers": mask_secrets(headers),
                    "payload": truncate_text(
                        json.dumps(mask_secrets(payload), ensure_ascii=False), 2000
                    ) if payload else None,
                }
            },
        )

    try:
        if method.upper() == "GET":
            resp = session.get(url, headers=headers, timeout=timeout, verify=verify_ssl)
        else:
            resp = session.post(url, headers=headers, json=payload, timeout=timeout, verify=verify_ssl)
    except Exception:
        logger.exception(f"[BIATOOLKIT] EXCEPTION {component_label}", extra={"custom": log_info})
        raise

    duration = now_ms() - start
    status = resp.status_code
    ok = 200 <= status < 300
    end_info = {
        **log_info,
        "duration_ms": int(duration),
        "http_status": status,
        "ok": ok,
        "request_payload": mask_secrets(payload) if payload is not None else None,
    }
    logger.info(f"[BIATOOLKIT] END {component_label}: " + json.dumps(end_info, default=str))

    parsed = parse_json_response(resp)

    if not ok and raise_for_http_error:
        step_desc = f" no passo '{step}'" if step else ""
        raise error_cls(
            f"Falha HTTP {status}{step_desc}.",
            status_code=status,
            response_text=resp.text or "",
            step=step,
        )

    return status, parsed, resp.text or ""


__all__ = [
    "BiaHTTPError",
    "HTTPClientSettings",
    "build_retry_session",
    "execute_request",
]
