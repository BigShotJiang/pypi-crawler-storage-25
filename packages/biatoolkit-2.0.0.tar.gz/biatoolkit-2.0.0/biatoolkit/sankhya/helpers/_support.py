from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
import json
import os
import re
import time
import uuid
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse


SERVICE_PATH = "/mge/service.sbr"

_SECRET_PATTERNS = re.compile(
    r"(authorization|cookie|jsessionid|mgesession|token|password|secret|api_key|apikey|x_api_key|x-api-key)",
    re.I,
)


@dataclass(frozen=True)
class PreparedRequest:
    url: str
    query: str
    headers: Dict[str, str]
    timeout: Tuple[float, float]
    log_info: Dict[str, Any]


def get_request_id(headers: Optional[dict] = None) -> str:
    if headers and "x-request-id" in headers:
        request_id = headers["x-request-id"]
        if request_id:
            return str(request_id)
    for env_name in ("BIA_REQUEST_ID", "REQUEST_ID"):
        request_id = os.getenv(env_name)
        if request_id:
            return str(request_id)
    return str(uuid.uuid4())


def inject_request_id(headers: Optional[Dict[str, str]]) -> Dict[str, str]:
    result = dict(headers or {})
    if "x-request-id" not in result:
        result["x-request-id"] = get_request_id(result)
    return result


def now_ms() -> float:
    return time.perf_counter() * 1000


def truncate_text(value: Any, max_len: int) -> str:
    text = value if isinstance(value, str) else str(value)
    if len(text) > max_len:
        return text[:max_len] + "...[truncated]"
    return text


def mask_secrets_in_url(url: str, mask: str = "***") -> str:
    try:
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc or not parsed.query:
            return url

        masked_query = []
        for key, value in parse_qsl(parsed.query, keep_blank_values=True):
            masked_query.append((key, mask if _SECRET_PATTERNS.search(key) else value))

        return urlunparse(
            (
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                parsed.params,
                urlencode(masked_query, doseq=True),
                parsed.fragment,
            )
        )
    except Exception:
        return url


def mask_secrets_in_text(text: str, mask: str = "***") -> str:
    try:
        text = re.sub(
            r"(?i)\b(jsessionid|mgesession|token|api[_-]?key|x-api-key)\s*=\s*([^;,\s]+)",
            lambda match: f"{match.group(1)}={mask}",
            text,
        )
        text = re.sub(
            r"(?i)\b(authorization)\s*:\s*(bearer)\s+([^\s]+)",
            lambda match: f"{match.group(1)}: {match.group(2)} {mask}",
            text,
        )
        return text
    except Exception:
        return text


def mask_secrets(value: Any, mask: str = "***") -> Any:
    if isinstance(value, dict):
        return {
            key: (mask if _SECRET_PATTERNS.search(key) else mask_secrets(item, mask))
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [mask_secrets(item, mask) for item in value]
    if isinstance(value, str):
        masked_url = mask_secrets_in_url(value, mask=mask)
        if masked_url != value:
            return masked_url
        return mask_secrets_in_text(value, mask=mask)
    return value


def build_url(
    *,
    url: Optional[str] = None,
    base_url: Optional[str] = None,
    query: Optional[str] = None,
) -> str:
    if url and url.strip():
        final_url = url.strip()
        if not final_url.startswith(("http://", "https://")):
            if not base_url:
                raise ValueError("base_url deve ser informado para url relativo.")
            normalized_base = base_url.strip().rstrip("/")
            if not final_url.startswith("/"):
                final_url = "/" + final_url
            final_url = normalized_base + final_url
    else:
        if not base_url:
            raise ValueError("base_url deve ser informado para montar a URL Sankhya.")
        final_url = f"{base_url.strip().rstrip('/')}{SERVICE_PATH}"

    if not query:
        return final_url
    separator = "&" if "?" in final_url else "?"
    return f"{final_url}{separator}{query.lstrip('?')}"


def is_absolute_url(value: Optional[str]) -> bool:
    if not value or not value.strip():
        return False
    return value.strip().startswith(("http://", "https://"))


def should_include_output_type_json(url: Optional[str], query: Optional[str]) -> bool:
    if query and re.search(r"(^|[?&])outputtype=", query, re.I):
        return False
    if not url:
        return False
    normalized = url.strip().lower()
    return normalized.startswith("/v1/") or "/v1/" in normalized


def _append_query_param(parts: list[str], key: str, value: str) -> None:
    parts.append(f"{key}={value}")


def _session_query_value(jsessionid: str) -> Optional[str]:
    return jsessionid.split(".", 1)[0] if "." in jsessionid else jsessionid


def extract_view_name_from_payload(payload: Optional[Dict[str, Any]]) -> Optional[str]:
    if not isinstance(payload, dict):
        return None
    try:
        request_body = payload.get("requestBody") or {}
        query = request_body.get("query") or {}
        view_name = query.get("viewName")
        if isinstance(view_name, str) and view_name.strip():
            return view_name.strip()
    except Exception:
        return None
    return None


def prepare_request(
    *,
    payload: Optional[Dict[str, Any]],
    jsessionid: str,
    url: Optional[str],
    base_url: Optional[str],
    query: Optional[str],
    method: str,
    default_headers: Optional[Dict[str, str]],
    extra_headers: Optional[Dict[str, str]],
    include_output_type_json: bool,
    timeout: Optional[Tuple[float, float]],
    timeout_defaults: Tuple[float, float],
) -> PreparedRequest:
    
    query_parts = []
    if query:
        query_parts.append(query.lstrip("?"))
    if include_output_type_json:
        _append_query_param(query_parts, "outputType", "json")

    sid_query = _session_query_value(jsessionid)
    if sid_query:
        _append_query_param(query_parts, "mgeSession", sid_query)

    final_query = "&".join(query_parts)
    final_url = build_url(url=url, query=final_query, base_url=base_url)

    headers = {"Content-Type": "application/json", **(default_headers or {})}
    if extra_headers:
        headers.update(extra_headers)
    headers = inject_request_id(headers)
    
    headers["Cookie"] = f"JSESSIONID={jsessionid}"
    
    log_info = {
        "component": "biatoolkit.sankhya",
        "request_id": headers.get("x-request-id"),
        "operation": "call_json",
        "url": mask_secrets(final_url),
        "query": mask_secrets(final_query),
        "method": method,
        "include_output_type_json": include_output_type_json,
        "view_name": extract_view_name_from_payload(payload),
    }
    return PreparedRequest(
        url=final_url,
        query=final_query,
        headers=headers,
        timeout=timeout or timeout_defaults,
        log_info=log_info,
    )


def build_debug_payload(
    *,
    payload: Optional[Dict[str, Any]],
    headers: Dict[str, str],
    log_info: Dict[str, Any],
) -> Dict[str, Any]:
    return {
        **log_info,
        "headers": mask_secrets(headers),
        "payload": truncate_text(json.dumps(mask_secrets(payload), ensure_ascii=False), 2000)
        if payload
        else None,
    }


def build_response_debug_payload(log_info: Dict[str, Any], response_text: str) -> Dict[str, Any]:
    return {
        **log_info,
        "response": truncate_text(mask_secrets(response_text), 2000),
    }


def parse_json_response(response: Any) -> Dict[str, Any]:
    try:
        return response.json()
    except Exception:
        return {"raw_text": response.text}


def get_sankhya_business_error(payload: Any) -> Optional[str]:
    if not isinstance(payload, dict):
        return None

    status = payload.get("status")
    status_message = payload.get("statusMessage")
    if status is None or not status_message:
        return None

    normalized_status = str(status).strip().lower()
    if normalized_status in ("1", "true", "200", "success", "ok"):
        return None

    return str(status_message)