from __future__ import annotations

from typing import Any, Optional
import logging

from ...core.settings import BiaToolkitSettings
from ...core.util import BiaUtil


logger = logging.getLogger(__name__)


class SankhyaRuntimeResolver:
    def __init__(self, mcp: Optional[Any], toolkit_settings: BiaToolkitSettings):
        self.mcp = mcp
        self.toolkit_settings = toolkit_settings

    def _get_header(self) -> Any:
        if self.mcp is None:
            return None
        try:
            util = BiaUtil(self.mcp, self.toolkit_settings)
            return util.get_header()
        except Exception as exc:
            logger.debug("[BIATOOLKIT] Falha ao ler header do runtime via BiaUtil: %s", exc)
            return None

    def resolve_jsessionid(self, explicit_jsessionid: Optional[str]) -> str:
        if explicit_jsessionid and str(explicit_jsessionid).strip():
            return str(explicit_jsessionid).strip()

        header = self._get_header()
        if header and getattr(header, "jsessionid", None):
            return str(header.jsessionid).strip()

        raise ValueError(
            "JSESSIONID ausente. Passe jsessionid explicitamente ou forneça 'mcp' para ler do header."
        )

    def resolve_base_url(self, explicit_base_url: Optional[str]) -> str:
        if explicit_base_url and str(explicit_base_url).strip():
            return str(explicit_base_url).strip()

        header = self._get_header()
        if header and getattr(header, "current_host", None):
            return str(header.current_host).strip()

        raise ValueError(
            "base_url não definida. Informe base_url explicitamente ou execute via MCP para obter do header."
        )

    def resolve_codparc(self, explicit_codparc: Optional[int]) -> int:
        if explicit_codparc is not None:
            try:
                return int(explicit_codparc)
            except (TypeError, ValueError):
                raise ValueError(f"codparc inválido: {explicit_codparc!r}")

        header = self._get_header()
        codparc = getattr(header, "codparc", None) if header else None
        if codparc:
            return int(codparc)

        raise ValueError(
            "codparc ausente. Passe codparc explicitamente ou forneça 'mcp' para ler do header."
        )