"""
biatoolkit.sankhya_call

Classe utilitária para chamadas HTTP a serviços Sankhya (ou gateway),
autenticando via JSESSIONID (cookie), preferencialmente obtido do header
do runtime (AgentCore) via BiaUtil.

Objetivo:
- O dev do MCP Tool não precisa recriar autenticação, headers e session.
- Basta chamar Sankhya(...).call_json(...) ou Sankhya.Call(...) (compat).

Requisitos:
- requests
- urllib3 (vem com requests)
- boto3 (já usado no biatoolkit.util)
- mcp.server.fastmcp.FastMCP (se usar no server; opcional para modo local)

Config via env (todas opcionais):
- SANKHYA_TIMEOUT_CONNECT: default 3.05
- SANKHYA_TIMEOUT_READ: default 12
- SANKHYA_RETRIES_TOTAL: default 3
- SANKHYA_RETRY_BACKOFF: default 0.5
- SANKHYA_VERIFY_SSL: default "1"
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
import os
import logging

try:
    # FastMCP só existe no runtime/servidor MCP. Em testes locais, pode faltar.
    from mcp.server.fastmcp import FastMCP
except Exception:  # pragma: no cover
    FastMCP = Any  # type: ignore

from ..core.response import ToolkitResponse
from ..core.settings import BiaToolkitSettings
from .helpers._http import (
    BiaHTTPError,
    HTTPClientSettings,
    build_retry_session,
    execute_request,
)
from .helpers._runtime import SankhyaRuntimeResolver
from .helpers._support import (
    SERVICE_PATH,
    build_url,
    get_sankhya_business_error,
    inject_request_id,
    is_absolute_url,
    prepare_request,
    should_include_output_type_json,
)


logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class SankhyaSettings(HTTPClientSettings):
    """
    Configurações específicas da integração Sankhya ERP (timeouts, retries, SSL).
    Não armazena base_url nem service_path — resolvidos do header do runtime.
    Herda os 5 campos comuns de HTTPClientSettings.
    """

    @staticmethod
    def from_env() -> "SankhyaSettings":
        def _f(name: str, default: float) -> float:
            try:
                return float(os.getenv(name, str(default)))
            except Exception:
                return default

        def _i(name: str, default: int) -> int:
            try:
                return int(os.getenv(name, str(default)))
            except Exception:
                return default

        def _b(name: str, default: bool) -> bool:
            raw = os.getenv(name, "1" if default else "0").strip().lower()
            return raw in ("1", "true", "yes", "y", "on")

        return SankhyaSettings(
            timeout_connect=_f("SANKHYA_TIMEOUT_CONNECT", 3.05),
            timeout_read=_f("SANKHYA_TIMEOUT_READ", 12.0),
            retries_total=_i("SANKHYA_RETRIES_TOTAL", 3),
            retry_backoff=_f("SANKHYA_RETRY_BACKOFF", 0.5),
            verify_ssl=_b("SANKHYA_VERIFY_SSL", True),
        )

class SankhyaHTTPError(BiaHTTPError):
    """Erro HTTP em chamadas ao Sankhya ERP. Herda de BiaHTTPError."""
    pass


class Sankhya:
    """
    Classe responsável por integrar e chamar serviços da plataforma Sankhya.

    Uso recomendado (em MCP server):
        sk = Sankhya(mcp)
        out = sk.call_json(payload=..., jsessionid="...", service_path="/v1/...")
        out = sk.load_view("BIA_VW_MB_RULES", "CODPROD_A = 123", fields="*")

    Uso compatível com o scaffold (estático):
        out = Sankhya.Call(jsessionID="...", payload={...})
        # ou sem jsessionID se você passar mcp:
        out = Sankhya.Call(jsessionID=None, mcp=mcp, payload={...})
    """

    def __init__(
        self,
        mcp: Optional[Any] = None,  # FastMCP pode não estar disponível em tempo de análise
        *,
        toolkit_settings: Optional[BiaToolkitSettings] = None,
        sankhya_settings: Optional[SankhyaSettings] = None,
        default_headers: Optional[Dict[str, str]] = None,
    ):
        """
        Inicializa a instância Sankhya.

        Args:
            mcp: Instância opcional do FastMCP para contexto do runtime.
            toolkit_settings: Configurações globais do toolkit (opcional).
            sankhya_settings: Configurações específicas da integração Sankhya (opcional).
            default_headers: Headers HTTP padrão para todas as requisições (opcional).
        """
        self.mcp = mcp
        self.toolkit_settings = toolkit_settings or BiaToolkitSettings.from_env()
        self.sankhya_settings = sankhya_settings or SankhyaSettings.from_env()
        self.default_headers = default_headers or {}
        self._runtime = SankhyaRuntimeResolver(self.mcp, self.toolkit_settings)

        # Sessão HTTP compartilhada com retries em 429/5xx (helpers._http)
        self._session = build_retry_session(
            retries_total=self.sankhya_settings.retries_total,
            retry_backoff=self.sankhya_settings.retry_backoff,
        )

    # -------------------------
    # JSESSIONID resolve
    # -------------------------
    def _resolve_jsessionid(self, jsessionid: Optional[str] = None) -> str:
        """
        Resolve o JSESSIONID a ser usado na autenticação.
        Prioriza o valor explícito, depois tenta extrair do header do runtime via BiaUtil.

        Args:
            jsessionid: Token de sessão explícito (opcional).

        Returns:
            str: JSESSIONID válido.

        Raises:
            ValueError: Se não for possível obter o JSESSIONID.
        """
        return self._runtime.resolve_jsessionid(jsessionid)


    # -------------------------
    # Métodos públicos
    # -------------------------
    def call_json(
        self,
        *,
        payload: Optional[Dict[str, Any]] = None,
        jsessionid: Optional[str] = None,
        url: Optional[str] = None,
        service_path: Optional[str] = None,
        base_url: Optional[str] = None,
        query: Optional[str] = None,
        method: str = "POST",
        extra_headers: Optional[Dict[str, str]] = None,
        include_output_type_json: Optional[bool] = None,
        timeout: Optional[Tuple[float, float]] = None,
        raise_for_http_error: bool = True,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """
        Faz uma chamada HTTP ao serviço Sankhya e retorna resposta estruturada.

        Args:
            payload: Corpo JSON (para POST). Pode ser None.
            jsessionid: Se None, tenta resolver do header (mcp) automaticamente.
            url: URL completa ou relativa.
            service_path: Path do serviço (ex: "/v1/financeiros/receitas").
            base_url: Base URL alternativa (opcional).
            query: Querystring adicional (ex: "serviceName=...&outputType=json")
            method: "POST" ou "GET"
            extra_headers: Headers adicionais.
            include_output_type_json: Força outputType=json na query.
            timeout: (connect, read) override
            raise_for_http_error: Se True, lança SankhyaHTTPError em status != 200

        Returns:
            ToolkitResponse[Dict]: Resposta estruturada com success, data, error, status_code.
        """

        # --- Observabilidade: BEGIN log ---
        sid = self._resolve_jsessionid(jsessionid)
        if url and service_path:
            raise ValueError("Informe apenas um entre 'url' e 'service_path'.")

        target_url = service_path if service_path is not None else url
        resolved_base_url = base_url
        if not is_absolute_url(target_url):
            resolved_base_url = self._runtime.resolve_base_url(base_url)

        include_output_type = (
            should_include_output_type_json(target_url, query)
            if include_output_type_json is None
            else bool(include_output_type_json)
        )

        # Monta URL final, headers (JSESSIONID cookie, mgeSession na query) e timeout
        prepared = prepare_request(
            payload=payload,
            jsessionid=sid,
            url=target_url,
            base_url=resolved_base_url,
            query=query,
            method=method,
            default_headers=self.default_headers,
            extra_headers=extra_headers,
            include_output_type_json=include_output_type,
            timeout=timeout,
            timeout_defaults=(
                self.sankhya_settings.timeout_connect,
                self.sankhya_settings.timeout_read,
            ),
        )

        # Delega request + logs para a camada HTTP comum
        status, parsed_response, raw_text = execute_request(
            self._session,
            method=method,
            url=prepared.url,
            headers=prepared.headers,
            payload=payload,
            timeout=prepared.timeout,
            verify_ssl=self.sankhya_settings.verify_ssl,
            log_info=prepared.log_info,
            component_label="Sankhya call_json",
            error_cls=SankhyaHTTPError,
            step=None,
            raise_for_http_error=raise_for_http_error,
        )

        request_id = prepared.log_info.get("request_id") if prepared.log_info else None

        # Se chegou aqui com status != 200 é porque raise_for_http_error=False
        if status != 200:
            return ToolkitResponse.http_error(
                status_code=status,
                error=f"Falha HTTP {status} ao chamar Sankhya/gateway.",
                request_id=request_id,
            )

        # Sankhya pode retornar HTTP 200 com statusMessage de erro de negócio — tratar aqui
        business_error = get_sankhya_business_error(parsed_response)
        if business_error:
            logger.warning(
                "[BIATOOLKIT] SankhyaERP BUSINESS ERROR call_json",
                extra={"custom": {**prepared.log_info, "business_error": business_error}},
            )
            if raise_for_http_error:
                raise SankhyaHTTPError(
                    f"Falha de negócio Sankhya: {business_error}",
                    status_code=status,
                    response_text="[truncated]",
                )
            return ToolkitResponse.make_business_error(
                error=f"Falha de negócio Sankhya: {business_error}",
                business_error=business_error,
                status_code=status,
                request_id=request_id,
            )

        return ToolkitResponse.ok(
            data=parsed_response,
            status_code=status,
            request_id=request_id,
        )

    def load_view(
        self,
        view_name: str,
        where_sql: str,
        *,
        fields: str = "*",
        jsessionid: Optional[str] = None,
        url: Optional[str] = None,
        base_url: Optional[str] = None,
        output_type: str = "json",
        extra_headers: Optional[Dict[str, str]] = None,
        raise_for_http_error: bool = True,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """
        Helper para o CRUDServiceProvider.loadView (mge/service.sbr).
        Monta o payload e a querystring automaticamente para facilitar consultas a views Sankhya.

        Args:
            view_name: Nome da view no Sankhya.
            where_sql: Cláusula WHERE (string).
            fields: Campos a retornar (string).
            jsessionid: Se None, pega do header (mcp).
            url: URL completa opcional (override).
            base_url: Base URL alternativa (opcional).
            output_type: "json" (default).
            extra_headers: Headers adicionais.
            raise_for_http_error: Se True, lança SankhyaHTTPError em erro HTTP/negócio.

        Returns:
            ToolkitResponse[Dict]: Resposta da consulta à view.
        """
        # Monta a querystring para o serviço
        query = f"serviceName=CRUDServiceProvider.loadView&outputType={output_type}"

        # Monta o corpo do payload conforme esperado pelo serviço
        body = {
            "serviceName": "CRUDServiceProvider.loadView",
            "requestBody": {
                "query": {
                    "viewName": view_name,
                    "where": {"$": where_sql},
                    "fields": {"field": {"$": fields}},
                }
            },
        }

        # Se base_url não foi fornecido, tenta obter do MCP (se existir)
        base_url = self._runtime.resolve_base_url(base_url)


        # Propaga view_name para call_json (para log)
        # Adiciona x-request-id se possível
        headers = extra_headers.copy() if extra_headers else {}
        headers = inject_request_id(headers)
        return self.call_json(
            payload=body,
            jsessionid=jsessionid,
            url=url,
            base_url=base_url,
            query=query,
            method="POST",
            extra_headers=headers,
            include_output_type_json=False,
            raise_for_http_error=raise_for_http_error,
        )

    # -------------------------
    # Compat com scaffold
    # -------------------------
    @staticmethod
    def Call(
        jsessionID: Optional[str] = None,
        *,
        payload: Optional[Dict[str, Any]] = None,
        mcp: Optional[Any] = None,  # FastMCP pode não estar disponível em tempo de análise
        url: Optional[str] = None,
        service_path: Optional[str] = None,
        base_url: Optional[str] = None,
        query: Optional[str] = None,
        method: str = "POST",
        extra_headers: Optional[Dict[str, str]] = None,
        include_output_type_json: Optional[bool] = None,
        raise_for_http_error: bool = True,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """
        Método estático compatível com o scaffold original.
        Permite chamada rápida ao serviço Sankhya sem instanciar manualmente a classe.

        Exemplos de uso:
            Sankhya.Call(jsessionID="...", payload={...}, query="serviceName=...&outputType=json")
            Sankhya.Call(jsessionID=None, mcp=mcp, payload={...}, query="...")

        Args:
            jsessionID: Token de sessão JSESSIONID (opcional).
            payload: Corpo da requisição (dict).
            mcp: Instância opcional do FastMCP para contexto do runtime.
            url: URL completa (opcional).
            service_path: Path do serviço (opcional).
            base_url: Base URL alternativa (opcional).
            query: Querystring adicional (opcional).
            method: "POST" ou "GET".
            extra_headers: Headers adicionais.
            include_output_type_json: Força outputType=json na query.
            raise_for_http_error: Se True, lança SankhyaHTTPError em erro HTTP/negócio.

        Returns:
            ToolkitResponse[Dict]: Resposta estruturada do serviço.
        """
        sk = Sankhya(mcp=mcp)
        headers = extra_headers.copy() if extra_headers else {}
        headers = inject_request_id(headers)
        return sk.call_json(
            payload=payload,
            jsessionid=jsessionID,
            url=url,
            service_path=service_path,
            base_url=base_url,
            query=query,
            method=method,
            extra_headers=headers,
            include_output_type_json=include_output_type_json,
            raise_for_http_error=raise_for_http_error,
        )


__all__ = ["Sankhya", "SankhyaSettings", "SankhyaHTTPError"]
