from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .core.logging_setup import bootstrap_logging

if TYPE_CHECKING:
	from .core.basic_client import BiaClient
	from .core.response import ToolkitResponse
	from .core.util import BiaUtil
	from .sankhya.erp import Sankhya
	from .sankhya.fintech import SankhyaFintech

__all__ = ["BiaUtil", "BiaClient", "Sankhya", "SankhyaFintech", "ToolkitResponse", "bootstrap_logging"]


def __getattr__(name: str) -> Any:
	if name == "BiaClient":
		from .core.basic_client import BiaClient as _BiaClient

		return _BiaClient
	if name == "BiaUtil":
		from .core.util import BiaUtil as _BiaUtil

		return _BiaUtil
	if name == "Sankhya":
		from .sankhya.erp import Sankhya as _Sankhya

		return _Sankhya
	if name == "SankhyaFintech":
		from .sankhya.fintech import SankhyaFintech as _SankhyaFintech

		return _SankhyaFintech
	if name == "ToolkitResponse":
		from .core.response import ToolkitResponse as _ToolkitResponse

		return _ToolkitResponse
	raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
	return sorted(set(globals()) | set(__all__))
