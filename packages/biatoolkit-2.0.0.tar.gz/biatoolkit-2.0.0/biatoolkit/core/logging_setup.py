# biatoolkit/logging_setup.py
from __future__ import annotations

import json
import logging
import os
import sys
from typing import Optional


_ENV_LEVEL_KEYS = ("BIATOOLKIT_LOG_LEVEL", "LOG_LEVEL")
_DEFAULT_LEVEL = "INFO"
_HANDLER_TAG_ATTR = "_biatoolkit_bootstrap_handler"


def _env_log_level() -> int:
    raw = None
    for k in _ENV_LEVEL_KEYS:
        v = os.getenv(k)
        if v:
            raw = v.strip().upper()
            break
    if not raw:
        raw = _DEFAULT_LEVEL

    # aceita "10", "20" etc também
    if raw.isdigit():
        return int(raw)

    return getattr(logging, raw, logging.INFO)


class BiaToolkitFormatter(logging.Formatter):
    """
    Formatter seguro para libraries:
    - mantém formato humano legível
    - se houver `record.custom` (dict), adiciona JSON ao final
    """

    def format(self, record: logging.LogRecord) -> str:
        base = super().format(record)

        custom = getattr(record, "custom", None)
        if custom is None:
            return base

        try:
            extra_json = json.dumps(custom, ensure_ascii=False, separators=(",", ":"))
        except Exception:
            extra_json = str(custom)

        return f"{base} | {extra_json}"


class _OnlyBiaToolkitFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return record.name == "biatoolkit" or record.name.startswith("biatoolkit.")


def _root_has_real_handlers() -> bool:
    """
    Detecta se o app já configurou logging.
    - root.handlers não vazio geralmente significa configuração explícita
    - mas alguns runtimes instalam handlers default; ainda assim, tratamos como "já configurado"
    """
    root = logging.getLogger()
    return bool(root.handlers)


def _already_bootstrapped(root: logging.Logger) -> bool:
    for h in root.handlers:
        if getattr(h, _HANDLER_TAG_ATTR, False):
            return True
    return False


def bootstrap_logging(force: bool = False) -> None:
    """
    Bootstrap seguro:
    - Se já houver handlers no root: não mexe (respeita app)
    - Se não houver: instala handler mínimo no root, filtrando só `biatoolkit.*`
    - Não chama basicConfig()
    - Idempotente
    - Nível controlado por ENV (BIATOOLKIT_LOG_LEVEL / LOG_LEVEL)
    """
    root = logging.getLogger()

    if _already_bootstrapped(root):
        return

    if not force and _root_has_real_handlers():
        return

    level = _env_log_level()

    handler = logging.StreamHandler(sys.stdout)
    setattr(handler, _HANDLER_TAG_ATTR, True)

    # filtra para não “poluir” logs de outras libs quando root estava vazio
    handler.addFilter(_OnlyBiaToolkitFilter())

    handler.setLevel(level)
    handler.setFormatter(
        BiaToolkitFormatter(
            fmt="%(asctime)s %(levelname)s %(name)s - %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S%z",
        )
    )

    root.addHandler(handler)

    # garante que o logger base da lib emita no nível desejado
    logging.getLogger("biatoolkit").setLevel(level)
