"""
biatoolkit.core.response

Tipos estruturados para respostas do toolkit (Sankhya ERP, Fintech, etc).
Garante que todos os módulos retornem um formato consistente e type-safe.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Generic, Optional, TypeVar


T = TypeVar("T")


@dataclass(frozen=True)
class ToolkitResponse(Generic[T]):
    """
    Resposta estruturada de operações do toolkit (Sankhya ERP, Fintech, etc).

    Attributes:
        success: True se a operação foi bem-sucedida (HTTP 200-299, sem erros de negócio).
        data: Dados retornados em caso de sucesso. None em caso de erro.
        error: Mensagem de erro em caso de falha. None em caso de sucesso.
        status_code: Código HTTP da resposta (ex: 200, 404, 500).
        request_id: ID de requisição para correlação de logs (ex: x-request-id header).
        business_error: Erro de negócio específico do Sankhya ERP (ex: statusMessage).
                         Preenchido quando HTTP 200 mas a operação falhou no servidor.
    """

    success: bool
    data: Optional[T] = None
    error: Optional[str] = None
    status_code: Optional[int] = None
    request_id: Optional[str] = None
    business_error: Optional[str] = None

    @staticmethod
    def ok(data: T, status_code: int = 200, request_id: Optional[str] = None) -> ToolkitResponse[T]:
        """Factory para resposta bem-sucedida."""
        return ToolkitResponse(
            success=True,
            data=data,
            status_code=status_code,
            request_id=request_id,
        )

    @staticmethod
    def http_error(
        status_code: int,
        error: str,
        request_id: Optional[str] = None,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """Factory para erro HTTP (4xx, 5xx)."""
        return ToolkitResponse(
            success=False,
            error=error,
            status_code=status_code,
            request_id=request_id,
        )

    @staticmethod
    def make_business_error(
        error: str,
        business_error: Optional[str] = None,
        status_code: int = 200,
        request_id: Optional[str] = None,
    ) -> ToolkitResponse[Dict[str, Any]]:
        """Factory para erro de negócio (HTTP 200 mas falha semântica)."""
        return ToolkitResponse(
            success=False,
            error=error,
            business_error=business_error,
            status_code=status_code,
            request_id=request_id,
        )

    @staticmethod
    def validation_error(error: str) -> ToolkitResponse[Dict[str, Any]]:
        """Factory para erro de validação (entrada inválida)."""
        return ToolkitResponse(
            success=False,
            error=error,
            status_code=None,
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Serializa para dict (compatibilidade com código que espera dict solto).
        Útil para transições graduais.
        """
        result: Dict[str, Any] = {"success": self.success}
        if self.data is not None:
            result["data"] = self.data
        if self.error is not None:
            result["error"] = self.error
        if self.status_code is not None:
            result["status_code"] = self.status_code
        if self.request_id is not None:
            result["request_id"] = self.request_id
        if self.business_error is not None:
            result["business_error"] = self.business_error
        return result


__all__ = ["ToolkitResponse"]
