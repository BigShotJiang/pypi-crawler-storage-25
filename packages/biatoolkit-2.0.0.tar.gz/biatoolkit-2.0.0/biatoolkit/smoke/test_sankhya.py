"""
test_sankhya.py - Exemplos de uso genérico de Sankhya.Call() para diferentes endpoints

Este script demonstra como os desenvolvedores podem chamar qualquer API REST da 
Sankhya usando o Sankhya.Call(). Suporta GET, POST, PUT, DELETE, PATCH com 
queries e payloads customizados.

Variáveis de ambiente:
  SANKHYA_JSESSIONID       - Token de autenticação (opcional; se vazio, tenta extrair do header do runtime)
  SANKHYA_BASE_URL         - Base URL (default: https://ecossistema2.sankhyacloud.com.br)
  SANKHYA_TEST_MODE        - Modo de teste: "api" ou "load_view" (default: load_view)
  
  Para modo API:
    SANKHYA_API_ENDPOINT     - Endpoint REST (ex: /api/v1/financeiros/despesas)
    SANKHYA_API_QUERY        - Query string (ex: pagina=1&tamanho=20)
    SANKHYA_API_METHOD       - HTTP method: GET, POST, PUT, DELETE, PATCH (default: GET)
    SANKHYA_API_PAYLOAD_FILE - Arquivo JSON com payload (opcional, para POST/PUT)
    
Exemplos de uso:
  # GET com query e jsessionID
  export SANKHYA_JSESSIONID=seu_token
  export SANKHYA_TEST_MODE=api
  export SANKHYA_API_ENDPOINT=/api/v1/financeiros/despesas
  export SANKHYA_API_QUERY=pagina=1&tamanho=20
  export SANKHYA_API_METHOD=GET
  python test_sankhya.py

  # POST com payload
  export SANKHYA_API_METHOD=POST
  export SANKHYA_API_PAYLOAD_FILE=payload.json
  python test_sankhya.py
  
  # Sem jsessionID (tenta extrair do header/runtime)
  python test_sankhya.py
"""

import logging
import os
import json
from typing import Optional, Dict, Any

from biatoolkit.sankhya.erp import Sankhya, SankhyaHTTPError

# Logs do toolkit no console para depuração
_handler = logging.StreamHandler()
_handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))
logging.getLogger("biatoolkit").addHandler(_handler)
logging.getLogger("biatoolkit").setLevel(
    logging.DEBUG if os.getenv("BIA_DEBUG", "").lower() in ("1", "true") else logging.INFO
)


# ============ Configurações =============
os.environ.setdefault("SANKHYA_SERVICE_PATH", "/mge/service.sbr")

JSESSIONID = os.getenv("SANKHYA_JSESSIONID", "").strip()
BASE_URL = os.getenv("SANKHYA_BASE_URL", "https://ecossistema2.sankhyacloud.com.br")
TEST_MODE = os.getenv("SANKHYA_TEST_MODE", "load_view").strip().lower()

# Para modo API (genérico)
API_ENDPOINT = os.getenv("SANKHYA_API_ENDPOINT", "/v1/financeiros/receitas")
API_QUERY = os.getenv("SANKHYA_API_QUERY", "").strip()
API_METHOD = os.getenv("SANKHYA_API_METHOD", "GET").strip().upper()
API_PAYLOAD_FILE = os.getenv("SANKHYA_API_PAYLOAD_FILE", "").strip()
RAISE_FOR_HTTP_ERROR = os.getenv("SANKHYA_RAISE_FOR_HTTP_ERROR", "1").strip().lower() in ("1", "true", "yes", "on")


# ============ Funções auxiliares =============
def _normalize_service_path(endpoint: str) -> str:
    """Normaliza path do serviço garantindo barra inicial."""
    endpoint = (endpoint or "").strip()
    if not endpoint:
        return "/v1/financeiros/receitas"
    return endpoint if endpoint.startswith("/") else f"/{endpoint}"


def _load_payload_from_file(filepath: str) -> Optional[Dict[str, Any]]:
    """Carrega payload JSON de um arquivo."""
    if not filepath or not os.path.exists(filepath):
        return None
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Erro ao carregar payload de {filepath}: {e}")
        return None


def run_load_view_test(sk: Sankhya, jsessionid: Optional[str]) -> dict:
    """Executa teste de load_view (serviço legado mge/service.sbr)."""
    return sk.load_view(
        "BIA_VW_MB_RULES",
        "1=1",
        fields="*",
        jsessionid=jsessionid or None,  # Se vazio, tenta extrair do header
        base_url=BASE_URL,
        raise_for_http_error=RAISE_FOR_HTTP_ERROR,
    )


def run_api_test(jsessionid: Optional[str]) -> dict:
    """
    Executa teste genérico de API REST da Sankhya.
    Suporta GET, POST, PUT, DELETE, PATCH com queries e payloads customizados.
    
    Se jsessionid for None, o sistema tenta extrair do header do runtime.
    """
    service_path = _normalize_service_path(API_ENDPOINT)
    
    # Carrega payload se necessário
    payload = None
    if API_METHOD in ("POST", "PUT", "PATCH") and API_PAYLOAD_FILE:
        payload = _load_payload_from_file(API_PAYLOAD_FILE)
        print(f"📦 Payload carregado de {API_PAYLOAD_FILE}")
    
    print(f"🌐 {API_METHOD} {service_path}")
    print(f"   Base URL: {BASE_URL}")
    if API_QUERY:
        print(f"   Query: {API_QUERY}")
    if payload:
        print(f"   Body: {json.dumps(payload, ensure_ascii=False)[:100]}...")
    sid_display = (jsessionid or "<do header runtime>")
    print(f"   JSESSIONID: {sid_display[:20]}...{sid_display[-20:]}" if len(sid_display) > 40 else f"   JSESSIONID: {sid_display}")
    print()

    return Sankhya.Call(
        jsessionID=jsessionid or None,  # Se vazio, tenta extrair do header
        service_path=service_path,
        base_url=BASE_URL,
        query=API_QUERY or None,
        method=API_METHOD,
        payload=payload,
        raise_for_http_error=RAISE_FOR_HTTP_ERROR,
    )


def main() -> None:
    """Main entry point."""
    sk = Sankhya()

    try:
        if TEST_MODE == "api":
            print("=" * 70)
            print("🔧 Modo de teste: API REST (genérico)")
            print("=" * 70)
            print(f"BASE_URL:    {BASE_URL}")
            print(f"ENDPOINT:    {API_ENDPOINT}")
            print(f"METHOD:      {API_METHOD}")
            if API_QUERY:
                print(f"QUERY:       {API_QUERY}")
            print(f"FAIL_FAST:   {RAISE_FOR_HTTP_ERROR}")
            print()
            out = run_api_test(JSESSIONID)
        else:
            print("=" * 70)
            print("🔍 Modo de teste: load_view (serviço legado mge/service.sbr)")
            print("=" * 70)
            print(f"VIEW:  BIA_VW_MB_RULES")
            print(f"FAIL_FAST:   {RAISE_FOR_HTTP_ERROR}")
            print()
            out = run_load_view_test(sk, JSESSIONID)

        print()
        print("✅ OK! Resposta recebida")
        print(f"Top-level keys: {list(out.keys())}")
        print()
        print("JSON formatado:")
        print(json.dumps(out, indent=2, ensure_ascii=False))

    except SankhyaHTTPError as e:
        print()
        print(f"❌ HTTP ERROR: {e.status_code}")
        print(f"Body (primeiros 500 chars):")
        print((e.response_text or "")[:500])
        print("\nDica: defina SANKHYA_RAISE_FOR_HTTP_ERROR=0 para tratar erro sem exception.")


if __name__ == "__main__":
    main()
