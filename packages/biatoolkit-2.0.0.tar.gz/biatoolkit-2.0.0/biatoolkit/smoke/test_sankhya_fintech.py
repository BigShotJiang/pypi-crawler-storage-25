"""
test_sankhya_fintech.py - Smoke script para debugar o SankhyaFintech ponta a ponta.

Executa o handshake de 3 passos (integrator → efetivar → customer) contra o
gateway fintech da Sankhya e, se tudo der certo, dispara uma chamada real
contra o service_path informado.

Variáveis de ambiente — Gerais:
  SANKHYA_FINTECH_BASE_URL         - default http://fintechapi-dev.sankhya.com.br
  SANKHYA_FINTECH_CODPARC          - CODPARC real do cliente no Sankhya DEV (obrigatório)
  SANKHYA_FINTECH_NOME             - NOMEPARC (razão social) correspondente (obrigatório)
  SANKHYA_FINTECH_ENDPOINT         - service_path a chamar após o handshake
  SANKHYA_FINTECH_METHOD           - GET | POST (default GET)
  SANKHYA_FINTECH_QUERY            - querystring adicional (opcional)
  SANKHYA_FINTECH_PAYLOAD_FILE     - arquivo JSON com payload (opcional, p/ POST)
  SANKHYA_FINTECH_INTEGRATOR_TOKEN - chave do integrador (obrigatório localmente; em runtime é lido do SSM)
  SANKHYA_FINTECH_SKIP_FINAL_CALL  - "1" para só rodar o handshake sem a call final
  BIA_DEBUG                        - "1" para ligar logs DEBUG

Variáveis de ambiente — Pagamentos (POST /api/v1/payments):
  PAYMENT_ACCOUNT_ID          - ID da conta no gateway (obrigatório para --mode payment)
  PAYMENT_VALUE               - Valor do pagamento, ex: "10.50" (obrigatório)
  PAYMENT_DATE                - Data no formato YYYY-MM-DD, ex: "2026-05-10" (obrigatório)
  PAYMENT_CODE                - Código de barras do boleto (obrigatório)
  PAYMENT_EXTERNAL_ID         - ID externo do pagamento no seu sistema (obrigatório)
  PAYMENT_BENEFICIARY_NAME    - Nome do beneficiário (obrigatório)
  PAYMENT_BENEFICIARY_DOC     - CPF/CNPJ do beneficiário (obrigatório)
  PAYMENT_DESCRIPTION         - Descrição opcional do pagamento
  PAYMENT_IDEMPOTENCY_KEY     - Chave de idempotência (auto-gerado se ausente)

Exemplo de uso — só handshake:
  SANKHYA_FINTECH_CODPARC=123 SANKHYA_FINTECH_NOME="ACME" SANKHYA_FINTECH_SKIP_FINAL_CALL=1 python -m biatoolkit.smoke.test_sankhya_fintech

Exemplo de uso — pagamento:
  SANKHYA_FINTECH_CODPARC=123 SANKHYA_FINTECH_NOME="ACME" \\
  PAYMENT_ACCOUNT_ID="acc-001" PAYMENT_VALUE="10.50" PAYMENT_DATE="2026-05-10" \\
  PAYMENT_CODE="34191790010104351004791020150008682430000010000" \\
  PAYMENT_EXTERNAL_ID="PAG-001" PAYMENT_BENEFICIARY_NAME="John Doe" \\
  PAYMENT_BENEFICIARY_DOC="00000000000" \\
  python -m biatoolkit.smoke.test_sankhya_fintech --mode payment
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import uuid
from typing import Any, Dict, Optional

from biatoolkit.sankhya.fintech import SankhyaFintech
from biatoolkit.sankhya.helpers._fintech_support import FintechHTTPError


def _out(msg: str = "") -> None:
    """Escreve em stderr com flush — mesmo canal dos logs, sem problema de ordem."""
    print(msg, file=sys.stderr, flush=True)


def _print_curl(method: str, url: str, headers: dict, payload: Any) -> None:
    lines = [f"curl -X {method} '{url}' \\"]
    for k, v in headers.items():
        if k.lower() in ("x-request-id",):
            continue
        lines.append(f"  -H '{k}: {v}' \\")
    if payload is not None:
        lines.append(f"  -d '{json.dumps(payload, ensure_ascii=False)}'")
    else:
        lines[-1] = lines[-1].rstrip(" \\")
    _out("\n".join(lines))



# Logs do toolkit no console para depuração
_handler = logging.StreamHandler()
_handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))
logging.getLogger("biatoolkit").addHandler(_handler)
logging.getLogger("biatoolkit").setLevel(
    logging.DEBUG if os.getenv("BIA_DEBUG", "").lower() in ("1", "true") else logging.INFO
)


CODPARC_RAW = os.getenv("SANKHYA_FINTECH_CODPARC", "").strip()
NOME = os.getenv("SANKHYA_FINTECH_NOME", "").strip()
ENDPOINT = os.getenv("SANKHYA_FINTECH_ENDPOINT", "").strip()
METHOD = os.getenv("SANKHYA_FINTECH_METHOD", "GET").strip().upper()
QUERY = os.getenv("SANKHYA_FINTECH_QUERY", "").strip() or None
PAYLOAD_FILE = os.getenv("SANKHYA_FINTECH_PAYLOAD_FILE", "").strip()
INTEGRATOR_OVERRIDE = os.getenv("SANKHYA_FINTECH_INTEGRATOR_TOKEN", "").strip() or None
SKIP_FINAL = os.getenv("SANKHYA_FINTECH_SKIP_FINAL_CALL", "").strip().lower() in (
    "1", "true", "yes", "on",
)

# Variáveis para o modo de pagamento (POST /api/v1/payments)
PAYMENT_ACCOUNT_ID = os.getenv("PAYMENT_ACCOUNT_ID", "").strip()
PAYMENT_VALUE_RAW = os.getenv("PAYMENT_VALUE", "").strip()
PAYMENT_DATE = os.getenv("PAYMENT_DATE", "").strip()
PAYMENT_CODE = os.getenv("PAYMENT_CODE", "").strip()
PAYMENT_EXTERNAL_ID = os.getenv("PAYMENT_EXTERNAL_ID", "").strip()
PAYMENT_BENEFICIARY_NAME = os.getenv("PAYMENT_BENEFICIARY_NAME", "").strip()
PAYMENT_BENEFICIARY_DOC = os.getenv("PAYMENT_BENEFICIARY_DOC", "").strip()
PAYMENT_DESCRIPTION = os.getenv("PAYMENT_DESCRIPTION", "").strip() or None
PAYMENT_IDEMPOTENCY_KEY = os.getenv("PAYMENT_IDEMPOTENCY_KEY", "").strip() or None
# Dados do usuário externo que autoriza o pagamento
PAYMENT_EXTERNAL_USER_ID = os.getenv("PAYMENT_EXTERNAL_USER_ID", "").strip()
PAYMENT_EXTERNAL_USER_NAME = os.getenv("PAYMENT_EXTERNAL_USER_NAME", "").strip()
PAYMENT_EXTERNAL_USER_EMAIL = os.getenv("PAYMENT_EXTERNAL_USER_EMAIL", "").strip()


def _load_payload(path: str) -> Optional[Dict[str, Any]]:
    if not path or not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _validate_required() -> int:
    missing = []
    if not CODPARC_RAW:
        missing.append("SANKHYA_FINTECH_CODPARC")
    if not NOME:
        missing.append("SANKHYA_FINTECH_NOME")
    if missing:
        _out("❌ Variáveis obrigatórias ausentes: " + ", ".join(missing))
        return 0
    try:
        return int(CODPARC_RAW)
    except ValueError:
        _out(f"❌ SANKHYA_FINTECH_CODPARC inválido (deve ser inteiro): {CODPARC_RAW!r}")
        return 0


def run_handshake_only(fintech: SankhyaFintech, codparc: int) -> None:
    integrator = fintech._resolve_integrator_token(INTEGRATOR_OVERRIDE)
    _out(f"🔑 Integrator token (primeiros 8): {integrator[:8]}...")
    _out(f"👤 CODPARC: {codparc}  |  NOME: {NOME}")
    _out()

    customer_token = fintech._auth_handshake(
        codparc=codparc,
        nome=NOME,
        integrator_token=integrator,
        extra_headers=None,
        timeout=(
            fintech.fintech_settings.timeout_connect,
            fintech.fintech_settings.timeout_read,
        ),
    )
    _out()
    _out("✅ Handshake OK")
    _out(f"customer_token (primeiros 20): {customer_token[:20]}...")


def run_full_call(fintech: SankhyaFintech, codparc: int) -> None:
    payload = _load_payload(PAYLOAD_FILE) if PAYLOAD_FILE else None

    _out(f"🌐 {METHOD} {ENDPOINT}")
    _out(f"   base_url: {fintech.fintech_settings.base_url}")
    _out(f"   CODPARC:  {codparc}")
    _out(f"   NOME:     {NOME}")
    if QUERY:
        _out(f"   query:    {QUERY}")
    if payload:
        _out(f"   payload:  {json.dumps(payload, ensure_ascii=False)[:120]}...")
    _out()

    resp = fintech.call(
        service_path=ENDPOINT,
        nome=NOME,
        method=METHOD,
        payload=payload,
        query=QUERY,
        codparc=codparc,
        integrator_token=INTEGRATOR_OVERRIDE,
    )

    _out()
    _out("✅ Resposta final recebida")
    _out(json.dumps(resp.to_dict(), indent=2, ensure_ascii=False))


def _validate_payment_vars() -> bool:
    missing = []
    if not PAYMENT_ACCOUNT_ID:
        missing.append("PAYMENT_ACCOUNT_ID")
    if not PAYMENT_VALUE_RAW:
        missing.append("PAYMENT_VALUE")
    if not PAYMENT_DATE:
        missing.append("PAYMENT_DATE")
    if not PAYMENT_CODE:
        missing.append("PAYMENT_CODE")
    if not PAYMENT_EXTERNAL_ID:
        missing.append("PAYMENT_EXTERNAL_ID")
    if not PAYMENT_BENEFICIARY_NAME:
        missing.append("PAYMENT_BENEFICIARY_NAME")
    if not PAYMENT_BENEFICIARY_DOC:
        missing.append("PAYMENT_BENEFICIARY_DOC")
    if missing:
        _out("❌ Variáveis obrigatórias para pagamento ausentes: " + ", ".join(missing))
        return False
    try:
        float(PAYMENT_VALUE_RAW)
    except ValueError:
        _out(f"❌ PAYMENT_VALUE inválido (deve ser número): {PAYMENT_VALUE_RAW!r}")
        return False
    return True


def run_payment_call(fintech: SankhyaFintech, codparc: int) -> None:
    idempotency_key = PAYMENT_IDEMPOTENCY_KEY or str(uuid.uuid4())
    external_user_id = PAYMENT_EXTERNAL_USER_ID or str(codparc)
    external_user_name = PAYMENT_EXTERNAL_USER_NAME or NOME
    external_user_email = PAYMENT_EXTERNAL_USER_EMAIL or ""

    payment_item: Dict[str, Any] = {
        "accountId": PAYMENT_ACCOUNT_ID,
        "value": float(PAYMENT_VALUE_RAW),
        "paymentDate": PAYMENT_DATE,
        "paymentCode": PAYMENT_CODE,
        "type": "BOLETO",
        "externalId": PAYMENT_EXTERNAL_ID,
        "beneficiaryName": PAYMENT_BENEFICIARY_NAME,
        "beneficiaryDocument": PAYMENT_BENEFICIARY_DOC,
    }
    if PAYMENT_DESCRIPTION:
        payment_item["description"] = PAYMENT_DESCRIPTION

    payload: Dict[str, Any] = {"items": [payment_item]}

    _out(f"💳 POST /api/v1/payments")
    _out(f"   base_url:          {fintech.fintech_settings.base_url}")
    _out(f"   CODPARC:           {codparc}")
    _out(f"   NOME:              {NOME}")
    _out(f"   accountId:         {PAYMENT_ACCOUNT_ID}")
    _out(f"   value:             {PAYMENT_VALUE_RAW}")
    _out(f"   paymentDate:       {PAYMENT_DATE}")
    _out(f"   externalId:        {PAYMENT_EXTERNAL_ID}")
    _out(f"   beneficiaryName:   {PAYMENT_BENEFICIARY_NAME}")
    _out(f"   beneficiaryDoc:    {PAYMENT_BENEFICIARY_DOC}")
    _out(f"   Idempotency-Key:      {idempotency_key}")
    _out(f"   X-External-User-Id:   {external_user_id}")
    _out(f"   X-External-User-Name: {external_user_name}")
    _out(f"   X-External-User-Email:{external_user_email or '(vazio)'}")
    _out()

    resp = fintech.call(
        service_path="/api/v1/payments",
        nome=NOME,
        method="POST",
        payload=payload,
        codparc=codparc,
        integrator_token=INTEGRATOR_OVERRIDE,
        extra_headers={
            "Idempotency-Key": idempotency_key,
            "X-External-User-Id": external_user_id,
            "X-External-User-Name": external_user_name,
            **({"X-External-User-Email": external_user_email} if external_user_email else {}),
        },
        raise_for_http_error=False,
    )

    _out()
    _out("Resposta do pagamento recebida")
    _out(json.dumps(resp.to_dict(), indent=2, ensure_ascii=False, default=str))


def main() -> int:
    parser = argparse.ArgumentParser(description="SankhyaFintech smoke test")
    parser.add_argument(
        "--mode",
        choices=["default", "payment"],
        default="default",
        help="Modo de execução: 'default' (handshake + endpoint genérico) ou 'payment' (POST /api/v1/payments)",
    )
    args = parser.parse_args()

    codparc = _validate_required()
    if not codparc:
        return 2

    if args.mode == "payment" and not _validate_payment_vars():
        return 2

    fintech = SankhyaFintech()

    _out("=" * 72)
    _out("🔧 SankhyaFintech smoke debug")
    _out("=" * 72)
    _out(f"BASE_URL:     {fintech.fintech_settings.base_url}")
    _out(f"MODE:         {args.mode}")
    if args.mode == "default":
        _out(f"SKIP_FINAL:   {SKIP_FINAL}")
    _out()

    try:
        if args.mode == "payment":
            run_payment_call(fintech, codparc)
        elif SKIP_FINAL or not ENDPOINT:
            run_handshake_only(fintech, codparc)
        else:
            run_full_call(fintech, codparc)
        return 0
    except FintechHTTPError as exc:
        _out()
        _out(f"❌ FintechHTTPError [step={exc.step}] status={exc.status_code}")
        _out("Body:")
        _out((exc.response_text or "")[:500])
        return 1
    except ValueError as exc:
        _out()
        _out(f"❌ Configuração inválida: {exc}")
        return 2
    except Exception as exc:
        _out()
        _out(f"❌ Exceção inesperada: {type(exc).__name__}: {exc}")
        raise


if __name__ == "__main__":
    sys.exit(main())
