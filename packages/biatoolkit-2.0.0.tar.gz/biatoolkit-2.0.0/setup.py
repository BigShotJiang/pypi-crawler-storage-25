from pathlib import Path

from setuptools import find_packages, setup


ROOT = Path(__file__).parent

setup(
    name='biatoolkit',
    version='2.0.0',
    packages=find_packages(),
    install_requires=['mcp', 'boto3', 'requests'],
    author='Bia Platform Team',  
    author_email='data.platform@sankhya.com.br',
    description='Biblioteca para desenvolvedores que utilizam o BiaAgentBuilder',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.10',
    long_description=(ROOT / 'README_PUBLIC.md').read_text(encoding='utf-8'),
    long_description_content_type='text/markdown',

)