"""Service layer for GPStitch."""
