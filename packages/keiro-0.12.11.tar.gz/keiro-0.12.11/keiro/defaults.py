"""Keiro infrastructure defaults — single source of truth.

Values are read from ``defaults.yaml`` (bundled inside the wheel).
Override at runtime via ``~/.keiro/credentials``, environment variables,
or explicit function arguments.

Missing keys cause immediate ``KeyError`` with a clear traceback —
no silent fallbacks.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Dict

import yaml

_DEFAULTS_PATH = Path(__file__).parent / "defaults.yaml"
_DEFAULTS = yaml.safe_load(_DEFAULTS_PATH.read_text())

_LOG = logging.getLogger(__name__)

DEFAULT_GATEWAY_URL: str = _DEFAULTS["gateway"]["url"]
DEFAULT_MODEL: str = _DEFAULTS["gateway"]["model"]
DEFAULT_API_KEY: str = _DEFAULTS["gateway"]["api_key"]

# Derived constants parsed from DEFAULT_GATEWAY_URL.
_parsed_url = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(DEFAULT_GATEWAY_URL)
DEFAULT_GATEWAY_HOST: str = _parsed_url.hostname or "localhost"
DEFAULT_GATEWAY_PORT: int = _parsed_url.port or 8080
del _parsed_url

# --- Timeout defaults (seconds) ---
_TIMEOUTS: Dict[str, object] = _DEFAULTS["timeouts"]

CONNECT_TIMEOUT: float = float(_TIMEOUTS["connect"])
READ_TIMEOUT_STANDARD: float = float(_TIMEOUTS["read_standard"])
READ_TIMEOUT_REASONING: float = float(_TIMEOUTS["read_reasoning"])

EB1_PER_STAGE_TIMEOUT: Dict[str, float] = {
    k: float(v)
    for k, v in _TIMEOUTS["eb1_per_stage"].items()  # type: ignore[union-attr]
}
EB1_VARIANT_STAGES: Dict[str, int] = {
    k: int(v)
    for k, v in _TIMEOUTS["eb1_stages"].items()  # type: ignore[union-attr]
}


# Models requiring GNN server routing (not local ensemble).
# Generated from catalog at import time — no manual maintenance.
def _build_gnn_routed_prefixes() -> frozenset[str]:
    try:
        from keiro.ensemble.catalog import all_variants

        return frozenset(v.key for v in all_variants() if v.route_kind == "gnn")
    except (ImportError, ModuleNotFoundError):
        # Fallback for minimal installs without the catalog.
        return frozenset(
            (
                "eb1-preview",
                "eb1-fast-preview",
                "eb1-frontier-preview",
                "eb1-delta-preview",
            )
        )


EB1_GNN_ROUTED_PREFIXES: frozenset[str] = _build_gnn_routed_prefixes()


# --- Predictive context-budget warn fractions ---
#
# Informational thresholds for per-turn context-budget telemetry.  When the
# conservative prompt-token estimate crosses these fractions of a model's
# context window, the ensemble emits a warning event and the gateway sets
# the ``X-Ember-Context-Warning`` response header.  These values NEVER gate
# candidate dispatch — the ensemble always runs the planned candidates and
# judge.  See the ``_filter_by_context`` reversion (git 269f2e3).
_CONTEXT_BUDGET: Dict[str, object] = _DEFAULTS["context_budget"]
CONTEXT_CANDIDATE_WARN_FRACTION: float = float(_CONTEXT_BUDGET["candidate_warn_fraction"])
CONTEXT_JUDGE_WARN_FRACTION: float = float(_CONTEXT_BUDGET["judge_warn_fraction"])


# ---------------------------------------------------------------------------
# Feature flags
# ---------------------------------------------------------------------------

_FEATURE_FLAGS: Dict[str, bool] = {
    str(k): bool(v) for k, v in (_DEFAULTS.get("feature_flags") or {}).items()
}

_TRUTHY: frozenset[str] = frozenset({"1", "true", "yes", "on"})

_LEGACY_FEATURE_FLAG_ENV: Dict[str, str] = {
    "context_aware_routing": "EB1_CONTEXT_AWARE_ROUTING",
    "gnn_fail_loud": "EB1_GNN_FAIL_LOUD",
    "anthropic_fast_mode": "EB1_FAST_MODE",
    "judge_overflow_recovery": "EB1_JUDGE_OVERFLOW_RECOVERY",
    "parallel_candidates": "EB1_PARALLEL_CANDIDATES",
}

_LEGACY_WARNED: set[str] = set()


def get_feature_flag(name: str) -> bool:
    """Return the current value of a feature flag.

    Canonical source: ``defaults.yaml:feature_flags.<name>``.  Env
    override ``EB1_FF_<NAME>`` wins for dev / rollout testing; the
    legacy per-flag env var (e.g. ``EB1_CONTEXT_AWARE_ROUTING``) is
    still honored as a second-chance override but emits a one-shot
    deprecation warning so ops can migrate.

    Per AGENTS.md §54: feature flags must live in versioned config,
    not sprinkled as ad-hoc env vars per service.
    """
    if name not in _FEATURE_FLAGS:
        raise KeyError(f"Unknown feature flag {name!r}; add it to defaults.yaml:feature_flags")
    override = os.environ.get(f"EB1_FF_{name.upper()}")
    if override is None:
        legacy = _LEGACY_FEATURE_FLAG_ENV.get(name)
        if legacy is not None:
            override = os.environ.get(legacy)
            if override is not None and legacy not in _LEGACY_WARNED:
                _LEGACY_WARNED.add(legacy)
                _LOG.warning(
                    "feature flag %r: env var %s is deprecated; "
                    "use EB1_FF_%s or set feature_flags.%s in defaults.yaml",
                    name,
                    legacy,
                    name.upper(),
                    name,
                )
    if override is not None:
        return override.strip().lower() in _TRUTHY
    return _FEATURE_FLAGS[name]


# ---------------------------------------------------------------------------
# Gateway URL resolution helpers
# ---------------------------------------------------------------------------


def get_gateway_url() -> str:
    """Return the default gateway URL, respecting env var override.

    Resolution order:
        1. EB1_GATEWAY_URL environment variable (full URL).
        2. EB1_GATEWAY_HOST environment variable (composed with default port).
        3. defaults.yaml gateway.url.
    """

    env_url = os.environ.get("EB1_GATEWAY_URL")
    if env_url:
        return env_url.rstrip("/")
    env_host = os.environ.get("EB1_GATEWAY_HOST")
    if env_host:
        return f"http://{env_host}:{DEFAULT_GATEWAY_PORT}"
    return DEFAULT_GATEWAY_URL


def get_gateway_host() -> str:
    """Return just the hostname/IP from the gateway URL."""

    env_host = os.environ.get("EB1_GATEWAY_HOST")
    if env_host:
        return env_host
    from urllib.parse import urlparse

    return urlparse(DEFAULT_GATEWAY_URL).hostname or "localhost"


def get_gateway_port() -> int:
    """Return the port number from the default gateway URL."""
    from urllib.parse import urlparse

    return urlparse(DEFAULT_GATEWAY_URL).port or 8080
