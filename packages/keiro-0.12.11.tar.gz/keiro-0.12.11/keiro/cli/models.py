"""``keiro models`` — list available models and rate limits.

Two modes:
    - **Online (default):** fetches from the gateway via ``Client.get_models()``,
      including ``rate_limits`` when upstream quotas are configured.
    - **Offline (``--local``):** lists from the local variant registry with no
      network calls; rate limits are not shown.

Examples::

    keiro models                       # online, table format
    keiro models --local               # offline, table format
    keiro models --format json         # online, JSON output
    keiro models --local --format json # offline, JSON output
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any

from keiro.ensemble.catalog import all_variants
from keiro.ensemble.variants import Eb1Variant

_CATALOG_VARIANTS = all_variants()

# Customer-safe descriptions are declared on each variant in the catalog SSOT
# (`keiro.ensemble.catalog`). This dict is derived so the CLI never drifts
# from the catalog. Never expose internal details like GNN, candidates,
# judge, fan-out, or provider names in those descriptions.
_MODEL_DESCRIPTIONS: dict[str, str] = {
    v.key: v.description for v in _CATALOG_VARIANTS if v.description
}


@dataclass(frozen=True)
class ModelDisplayRow:
    """Customer-facing model metadata for CLI display."""

    model: str
    description: str
    default: bool = False


def _normalize_public_model_id(model: str) -> str:
    """Normalize a model id for local catalog display checks."""
    normalized = model.strip().lower()
    if "/" in normalized:
        normalized = normalized.split("/", 1)[1]
    return normalized


def resolve_catalog_variant(model: str) -> Eb1Variant | None:
    """Resolve a public model id to a registered EB1 variant, if any."""
    if not model or not model.strip():
        return None
    normalized = _normalize_public_model_id(model)
    for variant in _CATALOG_VARIANTS:
        if variant.matches(normalized):
            return variant
    return None


def is_catalog_eb1_model(model: str) -> bool:
    """Return True when ``model`` resolves to a registered EB1 variant."""
    return resolve_catalog_variant(model) is not None


def get_model_description(model: str) -> str:
    """Return the customer-safe description for a model, or empty string."""
    variant = resolve_catalog_variant(model)
    return variant.description if variant and variant.description else ""


def list_model_descriptions() -> Mapping[str, str]:
    """Return all customer-safe model descriptions keyed by model id."""
    return _MODEL_DESCRIPTIONS


def catalog_model_display_rows(
    *,
    default_model: str | None = None,
    order: Sequence[str] | None = None,
    default_first: bool = False,
) -> tuple[ModelDisplayRow, ...]:
    """Return model display rows for help, local listing, and picker UI."""
    models = (
        list(order)
        if order is not None
        else [variant.key for variant in _CATALOG_VARIANTS]
    )
    seen: set[str] = set()
    rows: list[ModelDisplayRow] = []

    for model in models:
        variant = resolve_catalog_variant(model)
        if variant is None or model in seen:
            continue
        seen.add(model)
        rows.append(
            ModelDisplayRow(
                model=model,
                description=variant.description or "",
                default=bool(
                    default_model
                    and variant.matches(_normalize_public_model_id(default_model))
                ),
            )
        )

    if default_first:
        rows.sort(key=lambda row: (not row.default, models.index(row.model)))
    return tuple(rows)


def build_parser() -> argparse.ArgumentParser:
    """Build argument parser for ``keiro models``."""
    parser = argparse.ArgumentParser(
        prog="keiro models",
        description="List available EB1 models and rate limits.",
    )
    parser.add_argument(
        "--local",
        action="store_true",
        help="List from local variant registry (no network call).",
    )
    parser.add_argument(
        "--format",
        choices=("table", "json"),
        default="table",
        dest="output_format",
        help="Output format (default: table).",
    )
    parser.add_argument(
        "--gateway-url",
        default=None,
        help="Override gateway URL for online mode.",
    )
    return parser


def run(args: argparse.Namespace) -> int:
    """Execute ``keiro models``."""
    if args.local:
        return _run_local(args.output_format)
    return _run_remote(args.output_format, gateway_url=args.gateway_url)


# ---------------------------------------------------------------------------
# Local mode
# ---------------------------------------------------------------------------


def _run_local(output_format: str) -> int:
    """List models from the local variant registry."""
    from keiro.defaults import DEFAULT_MODEL

    display_rows = catalog_model_display_rows(
        default_model=DEFAULT_MODEL,
        default_first=True,
    )
    rows = [asdict(row) for row in display_rows]

    if output_format == "json":
        json.dump(rows, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 0

    _print_table(rows, has_limits=False)
    return 0


# ---------------------------------------------------------------------------
# Remote mode
# ---------------------------------------------------------------------------


def _run_remote(output_format: str, *, gateway_url: str | None) -> int:
    """Fetch models from the gateway and display them."""
    from keiro.client import Client, KeirError

    try:
        kwargs: dict[str, Any] = {}
        if gateway_url:
            kwargs["base_url"] = gateway_url
        client = Client(**kwargs)
        data = client.get_models()
    except KeirError as exc:
        print(
            f"Could not reach gateway: {exc.user_message}\n"
            "Hint: use --local to list models without a "
            "gateway connection.",
            file=sys.stderr,
        )
        return 1
    except Exception:
        print(
            "Could not reach gateway. Check your network "
            "connection.\n"
            "Hint: use --local to list models without a "
            "gateway connection.",
            file=sys.stderr,
        )
        return 1

    entries = data.get("data", []) if isinstance(data, dict) else []

    rows: list[dict[str, Any]] = []
    has_limits = False
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        model_id = entry.get("id", "")
        # Skip provider-namespaced duplicates like "takumi/eb1-preview".
        if (
            not isinstance(model_id, str)
            or "/" in model_id
            or not _is_remote_eb1_entry(entry)
        ):
            continue
        row: dict[str, Any] = {
            "model": model_id,
            "description": (entry.get("description") or get_model_description(model_id)),
        }
        rate_limits = entry.get("rate_limits")
        if isinstance(rate_limits, dict):
            row["rpm"] = rate_limits.get("rpm")
            row["tpm"] = rate_limits.get("tpm")
            has_limits = True
        rows.append(row)

    if output_format == "json":
        json.dump(rows, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 0

    if not rows:
        print("No EB1 models found on the gateway.", file=sys.stderr)
        return 1

    _print_table(rows, has_limits=has_limits)
    return 0


def _is_remote_eb1_entry(entry: Mapping[str, Any]) -> bool:
    """Return True for gateway-owned EB1 entries.

    Local catalog matches are accepted, but remote mode also trusts
    gateway-owned metadata so older clients do not hide newly deployed
    Keiro models.
    """
    model_id = entry.get("id", "")
    if not isinstance(model_id, str) or not model_id:
        return False
    if is_catalog_eb1_model(model_id):
        return True
    owned_by = entry.get("owned_by")
    provider = entry.get("provider")
    return model_id.lower().startswith("eb1") and (
        owned_by == "keiro" or provider in {"keiro", "takumi"}
    )


# ---------------------------------------------------------------------------
# Table rendering
# ---------------------------------------------------------------------------


def _print_table(
    rows: list[dict[str, Any]],
    *,
    has_limits: bool,
) -> None:
    """Print a formatted table of models to stdout."""
    if not rows:
        return

    headers = ["Model", "Description"]
    if has_limits:
        headers.extend(["RPM", "TPM"])

    # Compute column widths.
    widths = [len(h) for h in headers]
    formatted_rows: list[list[str]] = []
    for row in rows:
        description = str(row.get("description", ""))
        if row.get("default"):
            description = f"{description} (default)" if description else "(default)"
        cells = [
            str(row.get("model", "")),
            description,
        ]
        if has_limits:
            rpm = row.get("rpm")
            tpm = row.get("tpm")
            cells.append(f"{rpm:,}" if rpm is not None else "-")
            cells.append(f"{tpm:,}" if tpm is not None else "-")
        formatted_rows.append(cells)
        for i, cell in enumerate(cells):
            widths[i] = max(widths[i], len(cell))

    # Print header.
    header_line = "  ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    separator = "  ".join("-" * widths[i] for i in range(len(headers)))
    print(header_line)
    print(separator)

    # Print rows.
    for cells in formatted_rows:
        line = "  ".join(
            cells[i].rjust(widths[i]) if i >= 2 else cells[i].ljust(widths[i])
            for i in range(len(cells))
        )
        print(line)
