from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from ._datetime import FlexibleDatetime

class CustomFields(BaseModel):
    model_config = ConfigDict(populate_by_name=True)


class AdditionalContacts(CustomFields):
    pass


class AdditionalNote(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    note_id: Annotated[int | None, Field(alias='noteId', description='The ID of the note to modify (required for updates).')] = None
    date: date_aliased | None = None
    note: Annotated[str | None, Field(description='The note text (max 4095 characters).')] = None


class AdditionalNotes(CustomFields):
    pass


class Address(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    line4: str | None = None
    line5: str | None = None
    city: Annotated[str | None, Field(description='City name.')] = None
    state: Annotated[str | None, Field(description='State or province code (e.g., "CA", "NY").')] = None
    postal_code: Annotated[str | None, Field(alias='postalCode', description='ZIP or postal code.')] = None
    country: Annotated[str | None, Field(description='Country name.')] = None
    note: Annotated[str | None, Field(description='Optional note about this address.')] = None


class AddressBlock(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    line4: str | None = None
    line5: str | None = None


class AddressRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    line4: str | None = None
    line5: str | None = None
    city: Annotated[str | None, Field(description='(Optional) City.', max_length=31)] = None
    state: Annotated[str | None, Field(description='(Optional) State.', max_length=21)] = None
    postal_code: Annotated[str | None, Field(alias='postalCode', description='(Optional) Postal code.', max_length=13)] = None
    country: Annotated[str | None, Field(description='(Optional) Country.', max_length=31)] = None
    note: Annotated[str | None, Field(description='(Optional) A note associated with the address.', max_length=4095)] = None


class AlternateShippingAddresses(CustomFields):
    pass


class AppliedCredits(CustomFields):
    pass


class SetCredits(CustomFields):
    pass


class AppliedToTransactionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    payment_amount: Annotated[float | None, Field(alias='paymentAmount', description="Monetary amount of the payment in the transaction's currency.\n\nUses decimal for financial precision. Null indicates the amount is unspecified.")] = None
    set_credits: Annotated[SetCredits | None, Field(alias='setCredits', description='Collection of requests to set credits.\n\nMay be null. Initialized at object creation (init-only). Serialized as\n"setCredits".')] = None
    discount_amount: Annotated[float | None, Field(alias='discountAmount', description='Monetary amount of any discount applied to the item or transaction.\n\nNull when no discount is applied. Use the same currency and scale as other monetary values in\nthe model.')] = None
    discount_account_id: Annotated[str | None, Field(alias='discountAccountId', description='Identifier of the account used for discounts.\n\nNullable; null indicates no discount account is assigned. When present, it should correspond\nto an account identifier in the accounting system.')] = None
    discount_class_id: Annotated[str | None, Field(alias='discountClassId', description='Identifier of the discount class.\n\nCorresponds to the JSON property "discountClassId". May be null when no discount class is\nassigned.')] = None


class AppliedToTransactions(CustomFields):
    pass


class LinkedTransactions(CustomFields):
    pass


class QbdRef(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str | None = None
    full_name: Annotated[str | None, Field(alias='fullName', description='The fully-qualified name of the referenced object (e.g., "Acme Corp" or "Travel:Airfare").')] = None


class AppliedToTxn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    type: str | None = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='The primary reference number for the transaction this one is applied to.')] = None
    balance_remaining: Annotated[float | None, Field(alias='balanceRemaining', description='The balance remaining on the applied-to transaction.')] = None
    payment_amount: Annotated[float | None, Field(alias='paymentAmount', description='The amount of the parent transaction applied to this one.')] = None
    discount_amount: Annotated[float | None, Field(alias='discountAmount', description='The discount amount given on the applied-to transaction.')] = None
    discount_account: Annotated[QbdRef | None, Field(alias='discountAccount', description='Reference to the discount account used.')] = None
    discount_class: Annotated[QbdRef | None, Field(alias='discountClass', description='Reference to the class used for the discount.')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    applied_credits: Annotated[AppliedCredits | None, Field(alias='appliedCredits', description='Credits applied to this transaction.')] = None


class AppliedToTxns(CustomFields):
    pass


class ApplyCredits(CustomFields):
    pass


class ApplyToTransactions(CustomFields):
    pass


class BarCodeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    value: str | None = None
    assign_even_if_used: Annotated[bool | None, Field(alias='assignEvenIfUsed', description='(Optional) If true, allows the value to be assigned even if already in use.', examples=['true'])] = None
    allow_override: Annotated[bool | None, Field(alias='allowOverride', description='(Optional) If true, allows the bar code value to be overridden in transactions.', examples=['true'])] = None


class BillingRateItems(CustomFields):
    pass


class BillingRatePerItems(CustomFields):
    pass


class Code(Enum):
    API_KEY_REQUIRED = 'API_KEY_REQUIRED'
    API_KEY_INVALID = 'API_KEY_INVALID'
    API_KEY_EXPIRED = 'API_KEY_EXPIRED'
    API_KEY_REVOKED = 'API_KEY_REVOKED'
    KEY_MODE_MISMATCH = 'KEY_MODE_MISMATCH'
    AUTHENTICATION_ERROR = 'AUTHENTICATION_ERROR'
    AUTHORIZATION_ERROR = 'AUTHORIZATION_ERROR'
    VALIDATION_ERROR = 'VALIDATION_ERROR'
    QBD_OBJECT_NOT_FOUND = 'QBD_OBJECT_NOT_FOUND'
    ACCOUNT_RESTRICTED = 'ACCOUNT_RESTRICTED'
    CONNECTION_RESTRICTED = 'CONNECTION_RESTRICTED'
    CONNECTION_ARCHIVED = 'CONNECTION_ARCHIVED'
    DEVELOPMENT_ACCESS_RESTRICTED = 'DEVELOPMENT_ACCESS_RESTRICTED'
    QBD_CONNECTION_ERROR = 'QBD_CONNECTION_ERROR'
    QBD_SESSION_ERROR = 'QBD_SESSION_ERROR'
    QBD_XML_RESPONSE_ERROR = 'QBD_XML_RESPONSE_ERROR'
    QBD_STALE_EDIT_SEQUENCE = 'QBD_STALE_EDIT_SEQUENCE'
    INVALID_OPERATION = 'INVALID_OPERATION'
    NOT_IMPLEMENTED = 'NOT_IMPLEMENTED'
    METHOD_NOT_ALLOWED = 'METHOD_NOT_ALLOWED'
    GET_PAGINATED_NOT_SUPPORTED = 'GET_PAGINATED_NOT_SUPPORTED'
    GET_BY_ID_NOT_SUPPORTED = 'GET_BY_ID_NOT_SUPPORTED'
    CREATE_NOT_SUPPORTED = 'CREATE_NOT_SUPPORTED'
    UPDATE_NOT_SUPPORTED = 'UPDATE_NOT_SUPPORTED'
    DELETE_NOT_SUPPORTED = 'DELETE_NOT_SUPPORTED'
    UNEXPECTED_SERVICE_RESPONSE = 'UNEXPECTED_SERVICE_RESPONSE'
    SUBSCRIPTION_REQUIRED = 'SUBSCRIPTION_REQUIRED'
    RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED'
    TIMEOUT_ERROR = 'TIMEOUT_ERROR'
    REQUEST_TIMEOUT = 'REQUEST_TIMEOUT'
    UNEXPECTED_ERROR = 'UNEXPECTED_ERROR'
    INTERNAL_ERROR = 'INTERNAL_ERROR'


class ColumnTitles(CustomFields):
    pass


class Columns(CustomFields):
    pass


class CustomContactFields(CustomFields):
    pass


class Contact(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description="Submitter's full name (max 100 chars).")] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    contact_name: Annotated[str | None, Field(alias='contactName')] = None
    salutation: str | None = None
    first_name: Annotated[str, Field(alias='firstName')]
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    custom_contact_fields: Annotated[CustomContactFields | None, Field(alias='customContactFields', description='Custom contact fields (name/value pairs) for this contact.\nMaps to AdditionalContactRef in QbXML (0-5 allowed per contact).')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class Contacts(CustomFields):
    pass


class NullableCreditCardTransactionType(Enum):
    AUTHORIZATION = 'Authorization'
    CAPTURE = 'Capture'
    CHARGE = 'Charge'
    REFUND = 'Refund'
    VOICE_AUTHORIZATION = 'VoiceAuthorization'
    NONE_TYPE_NONE = None


class NullableTransactionMode(Enum):
    CARD_NOT_PRESENT = 'CardNotPresent'
    CARD_PRESENT = 'CardPresent'
    NONE_TYPE_NONE = None


class CreateCreditCardTransactionInputInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    credit_card_number: Annotated[str, Field(alias='creditCardNumber')]
    expiration_month: Annotated[int, Field(alias='expirationMonth')]
    expiration_year: Annotated[int, Field(alias='expirationYear')]
    name_on_card: Annotated[str, Field(alias='nameOnCard')]
    credit_card_address: Annotated[str | None, Field(alias='creditCardAddress', max_length=41)] = None
    credit_card_postal_code: Annotated[str | None, Field(alias='creditCardPostalCode', max_length=13)] = None
    commercial_card_code: Annotated[str | None, Field(alias='commercialCardCode', max_length=4)] = None
    transaction_mode: Annotated[NullableTransactionMode | None, Field(alias='transactionMode')] = None
    credit_card_txn_type: Annotated[NullableCreditCardTransactionType | None, Field(alias='creditCardTxnType')] = None


class NullableAvsStreet(Enum):
    PASS = 'Pass'
    FAIL = 'Fail'
    NOT_AVAILABLE = 'NotAvailable'
    NONE_TYPE_NONE = None


class PaymentStatus(Enum):
    UNKNOWN = 'Unknown'
    COMPLETED = 'Completed'


class UpdateCreditCardTransactionResultInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    result_code: Annotated[int, Field(alias='resultCode')]
    result_message: Annotated[str, Field(alias='resultMessage')]
    credit_card_trans_id: Annotated[str, Field(alias='creditCardTransId')]
    merchant_account_number: Annotated[str, Field(alias='merchantAccountNumber')]
    payment_status: Annotated[PaymentStatus, Field(alias='paymentStatus')]
    txn_authorization_time: Annotated[FlexibleDatetime, Field(alias='txnAuthorizationTime')]
    authorization_code: Annotated[str | None, Field(alias='authorizationCode', max_length=25)] = None
    avs_street: Annotated[NullableAvsStreet | None, Field(alias='avsStreet')] = None
    avs_zip: Annotated[NullableAvsStreet | None, Field(alias='avsZip')] = None
    card_security_code_match: Annotated[NullableAvsStreet | None, Field(alias='cardSecurityCodeMatch')] = None
    recon_batch_id: Annotated[str | None, Field(alias='reconBatchId', max_length=30)] = None
    payment_grouping_code: Annotated[int | None, Field(alias='paymentGroupingCode')] = None
    txn_authorization_stamp: Annotated[int | None, Field(alias='txnAuthorizationStamp')] = None
    client_trans_id: Annotated[str | None, Field(alias='clientTransId')] = None


class CreateCreditCardTransactionResultInfoRequest(UpdateCreditCardTransactionResultInfoRequest):
    pass


class CreateCreditCardTransactionInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    input_info: Annotated[CreateCreditCardTransactionInputInfoRequest, Field(alias='inputInfo', description='(Required) Input details for the credit card transaction.')]
    result_info: Annotated[CreateCreditCardTransactionResultInfoRequest, Field(alias='resultInfo', description='(Required) Result details from the credit card processor.')]


class CreateExpenseLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str | None, Field(alias='accountId', description='(Optional) The ListID or FullName of the expense account.')] = None
    amount: Annotated[float | None, Field(description='(Optional) The amount of the expense line.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo specific to this line item.')] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'])] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) Billable status (Billable, NotBillable, HasBeenBilled).')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreateItemGroupLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_group_id: Annotated[str, Field(alias='itemGroupId', description='(Required) The ListID or FullName of the item group.')]
    quantity: Annotated[float | None, Field(description="(Optional) Quantity of the group. QuickBooks will multiply this by the group's internal quantities.")] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class LinkToTransactionLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_id: Annotated[str, Field(alias='transactionId', description='(Required) The TxnID and TxnLineId of the transaction to link to.')]
    transaction_line_id: Annotated[str, Field(alias='transactionLineId')]


class CreateItemLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    cost: Annotated[float | None, Field(description='(Optional) Cost per item (used in purchases).')] = None
    rate: Annotated[float | None, Field(description='(Optional) Price per item (used in sales).')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) Billable status (Billable, NotBillable, HasBeenBilled).')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item.')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber', description='(Optional) Expiration date for serial/lot number (v16.0).')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId', description='(Optional) Overrides the default income/expense account associated with the item.')] = None
    link_to_transaction: Annotated[LinkToTransactionLineRequest | None, Field(alias='linkToTransaction')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreateSetCreditRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    credit_transaction_id: Annotated[str, Field(alias='creditTransactionId')]
    applied_amount: Annotated[float, Field(alias='appliedAmount', description='The amount of the credit to apply.\n(Required)')]
    override: Annotated[bool | None, Field(description='If true, overrides default logic for applying credits.\n(Optional)')] = None


class CreditCardTransactionInputInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    number: str
    expiration_month: Annotated[int, Field(alias='expirationMonth', description="(Optional) The credit card's new expiration month (1-12).")]
    expiration_year: Annotated[int, Field(alias='expirationYear', description="(Optional) The credit card's new expiration year (e.g., 2025).")]
    name: str
    sddress: str | None = None
    postal_code: Annotated[str | None, Field(alias='postalCode')] = None
    commercial_card_code: Annotated[str | None, Field(alias='commercialCardCode', description='(Optional) New commercial card code. (Max 4 characters)')] = None
    transaction_mode: Annotated[NullableTransactionMode | None, Field(alias='transactionMode', description='(Optional) New transaction mode (0 for CardNotPresent [DEFAULT], 1 for CardPresent).')] = None
    transaction_type: Annotated[NullableCreditCardTransactionType | None, Field(alias='transactionType')] = None


class CreditCardTransactionResultInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    result_code: Annotated[int, Field(alias='resultCode')]
    result_message: Annotated[str, Field(alias='resultMessage')]
    credit_card_trans_id: Annotated[str, Field(alias='creditCardTransID')]
    merchant_account_number: Annotated[str, Field(alias='merchantAccountNumber')]
    authorization_code: Annotated[str | None, Field(alias='authorizationCode')] = None
    avs_street: Annotated[NullableAvsStreet | None, Field(alias='avsStreet')] = None
    avs_zip: Annotated[NullableAvsStreet | None, Field(alias='avsZip')] = None
    card_security_code_match: Annotated[NullableAvsStreet | None, Field(alias='cardSecurityCodeMatch')] = None
    recon_batch_id: Annotated[str | None, Field(alias='reconBatchID')] = None
    payment_grouping_code: Annotated[int | None, Field(alias='paymentGroupingCode')] = None
    payment_status: Annotated[PaymentStatus, Field(alias='paymentStatus')]
    transaction_authorization_time: Annotated[FlexibleDatetime, Field(alias='transactionAuthorizationTime')]
    transaction_authorization_stamp: Annotated[int | None, Field(alias='transactionAuthorizationStamp')] = None
    client_transaction_id: Annotated[str | None, Field(alias='clientTransactionId')] = None


class CreditCardTransactionInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request: CreditCardTransactionInputInfo
    response: CreditCardTransactionResultInfo


class CreditLines(CustomFields):
    pass


class CustomContactField(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    value: str


class DataExt(CustomFields):
    pass


class DataExtRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    owner_id: Annotated[str | None, Field(alias='ownerId', description='Gets or inits the Owner ID (a GUID) for the data extension.\nUse "0" for Custom Fields (user-defined). Use specific GUID for Private Data.')] = None
    name: str
    value: str


class DebitLines(CustomFields):
    pass


class DefaultExpenseAccounts(CustomFields):
    pass


class DefaultUnits(CustomFields):
    pass


class DeleteResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    deleted: bool | None = None
    id: str
    object_type: Annotated[str, Field(alias='objectType')]
    ref_number: Annotated[str | None, Field(alias='refNumber')] = None
    status: str
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    error_message: Annotated[str | None, Field(alias='errorMessage')] = None
    error_code: Annotated[str | None, Field(alias='errorCode')] = None
    suggested_action: Annotated[str | None, Field(alias='suggestedAction')] = None
    timestamp: FlexibleDatetime | None = None


class DepositLines(CustomFields):
    pass


class Type(Enum):
    VALIDATION_ERROR_TYPE = 'VALIDATION_ERROR_TYPE'
    AUTHENTICATION_ERROR_TYPE = 'AUTHENTICATION_ERROR_TYPE'
    NOT_FOUND_ERROR_TYPE = 'NOT_FOUND_ERROR_TYPE'
    RESTRICTION_ERROR_TYPE = 'RESTRICTION_ERROR_TYPE'
    INTEGRATION_CONNECTION_ERROR_TYPE = 'INTEGRATION_CONNECTION_ERROR_TYPE'
    INTEGRATION_RESPONSE_ERROR_TYPE = 'INTEGRATION_RESPONSE_ERROR_TYPE'
    BILLING_ERROR_TYPE = 'BILLING_ERROR_TYPE'
    APPLICATION_ERROR_TYPE = 'APPLICATION_ERROR_TYPE'
    TIMEOUT_ERROR_TYPE = 'TIMEOUT_ERROR_TYPE'
    RATE_LIMIT_ERROR_TYPE = 'RATE_LIMIT_ERROR_TYPE'
    UNEXPECTED_ERROR_TYPE = 'UNEXPECTED_ERROR_TYPE'


class ErrorDetail(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    message: Annotated[str, Field(description='Developer-facing error message including the QBD-provided error code and message. Example: "QBD Connection Error (0x80040420): The QuickBooks user has denied access."')]
    user_facing_message: Annotated[str, Field(alias='userFacingMessage', description='User-facing error message with instructions for the end-user to resolve the issue.')]
    type: Annotated[Type, Field(description='Error type/category. Identifies the broad class of error.')]
    code: Annotated[Code, Field(description='Error code identifying the specific error. Use this for programmatic error handling.')]
    http_status_code: Annotated[int, Field(alias='httpStatusCode', description='HTTP status code for the response (e.g. 400, 404, 502, 500).')]
    integration_code: Annotated[str | None, Field(alias='integrationCode', description='QuickBooks Desktop integration-specific error code. Can be a COM HRESULT (e.g. "0x80040420") or QB XML status code (e.g. "3120"). Null for non-QBD errors.')] = None
    request_id: Annotated[str, Field(alias='requestId', description='Request ID for tracking and diagnostics (e.g. "req_abc123").')]


class NullableBillableStatus(Enum):
    NOT_BILLABLE = 'NotBillable'
    BILLABLE = 'Billable'
    HAS_BEEN_BILLED = 'HasBeenBilled'
    NONE_TYPE_NONE = None


class ExpenseLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    account: Annotated[QbdRef | None, Field(description='Expense account (e.g., "Office Supplies")')] = None
    amount: Annotated[float | None, Field(description='(Optional) The amount of the expense line.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo specific to this line item.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    customer: QbdRef | None = None
    sales_representative: Annotated[QbdRef | None, Field(alias='salesRepresentative')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    tax_amount: Annotated[float | None, Field(alias='taxAmount')] = None
    vendor: QbdRef | None = None
    billable_status: Annotated[NullableBillableStatus | None, Field(alias='billableStatus', description='(Optional) Billable status (Billable, NotBillable, HasBeenBilled).')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class ExpenseLines(CustomFields):
    pass


class FixedAssetSalesInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    sales_desc: Annotated[str | None, Field(alias='salesDesc', description="A description of the sales transaction or the reason for the asset's disposal.", examples=['Sold to secondary logistics firm'])] = None
    sales_date: Annotated[date_aliased | None, Field(alias='salesDate', description='The date on which the asset was sold or disposed of.', examples=['2024-01-15T00:00:00'])] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice', description='The final price for which the asset was sold.', examples=['14000.00'])] = None
    sales_expense: Annotated[float | None, Field(alias='salesExpense', description='Any expenses directly incurred in order to sell the asset (e.g., broker fees, delivery costs).', examples=['500.00'])] = None


class GroupLines(CustomFields):
    pass


class InventoryAdjustmentLines(CustomFields):
    pass


class Lines(CustomFields):
    pass


class ItemGroupLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_group: Annotated[QbdRef | None, Field(alias='itemGroup')] = None
    description: str | None = None
    quantity: Annotated[float | None, Field(description="(Optional) Quantity of the group. QuickBooks will multiply this by the group's internal quantities.", ge=0.01)] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    is_print_items_in_group: Annotated[bool | None, Field(alias='isPrintItemsInGroup')] = None
    lines: Lines | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class ItemGroupLineDetail(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item: QbdRef | None = None
    quantity: float | None = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None


class ItemGroupLines(CustomFields):
    pass


class ItemInventoryAssemblyLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    inventory_item: Annotated[QbdRef | None, Field(alias='inventoryItem')] = None
    quantity: float | None = None


class ItemLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    item: QbdRef | None = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    cost: Annotated[float | None, Field(description='(Optional) Cost per item (used in purchases).')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    customer: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    override_item_account: Annotated[QbdRef | None, Field(alias='overrideItemAccount')] = None
    billable_status: Annotated[NullableBillableStatus | None, Field(alias='billableStatus', description='(Optional) Billable status (Billable, NotBillable, HasBeenBilled).')] = None
    item_group: Annotated[QbdRef | None, Field(alias='itemGroup')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    rate: Annotated[float | None, Field(description='(Optional) Price per item (used in sales).')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item.')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class ItemLines(CustomFields):
    pass


class ItemSalesTax1(CustomFields):
    pass


class LineGroups(CustomFields):
    pass


class LineItemGroups(CustomFields):
    pass


class LineItems(CustomFields):
    pass


class LinkedTransaction(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    transaction_id: Annotated[str, Field(alias='transactionId')]
    transaction_type: Annotated[str, Field(alias='transactionType')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Optional reference number of the linked transaction')] = None
    link_type: Annotated[str | None, Field(alias='linkType', description='The type of link - indicates whether the link represents an amount or quantity')] = None
    amount: Annotated[float | None, Field(description='The amount associated with this link')] = None


class PerItemPriceLevels(CustomFields):
    pass


class PriceLevelPerItemModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item: Annotated[QbdRef | None, Field(description='The item this pricing rule applies to.')] = None
    custom_price: Annotated[float | None, Field(alias='customPrice', description='The custom price for this item (mutually exclusive with CustomPricePercent).')] = None
    custom_price_percent: Annotated[float | None, Field(alias='customPricePercent', description='The custom price as a percentage (mutually exclusive with CustomPrice).')] = None


class QbdDataExt(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    owner_id: Annotated[str | None, Field(alias='OwnerId')] = None
    name: str | None = None
    type: str | None = None
    value: str | None = None


class RateEntries(CustomFields):
    pass


class RateHistory1(CustomFields):
    pass


class RefundAppliedToTransactions(CustomFields):
    pass


class RefundAppliedToTxns(CustomFields):
    pass


class RelatedUnits(CustomFields):
    pass


class Rows(CustomFields):
    pass


class SetCredit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    amount: float
    override: Annotated[bool | None, Field(description='If true, overrides default logic for applying credits.\n(Optional)')] = None


class SetCreditRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    credit_transaction_id: Annotated[str, Field(alias='creditTransactionId')]
    id: str | None = None
    applied_amount: Annotated[float, Field(alias='appliedAmount', description='Amount applied to an account, invoice, or payment (Optional).\n\nRepresents a monetary value; currency and precision are determined by the surrounding\ncontext.')]
    override: Annotated[bool | None, Field(description='Indicates whether to override the default credit application behavior.')] = None


class ShipToAddresses(CustomFields):
    pass


class ShippingAddresses(CustomFields):
    pass


class StandardErrorResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    error: Annotated[ErrorDetail, Field(description='The error details object.')]


class SubTitles(CustomFields):
    pass


class UpdateExpenseLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    account_id: Annotated[str | None, Field(alias='accountId', description='(Optional) The ListID or FullName of the expense account.')] = None
    amount: Annotated[float | None, Field(description='(Optional) The amount of the expense line.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo specific to this line item.')] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'])] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) Billable status (Billable, NotBillable, HasBeenBilled).')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None


class UpdateItemGroupLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_group_id: Annotated[str | None, Field(alias='itemGroupId', description='(Optional) The ListID or FullName of the item group.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    lines: Lines | None = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None


class UpdateItemLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    cost: Annotated[float | None, Field(description='(Optional) Cost per item (used in purchases).')] = None
    rate: Annotated[float | None, Field(description='(Optional) Price per item (used in sales).')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) Billable status (Billable, NotBillable, HasBeenBilled).')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item.')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber', description='(Optional) Expiration date for serial/lot number (v16.0).')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None


class Values(CustomFields):
    pass
