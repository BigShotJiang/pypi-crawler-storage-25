from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, QbdRef

class SalesTaxCode(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the sales tax code. (Max 3 characters)')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    is_taxable: Annotated[bool | None, Field(alias='isTaxable', description='(Required) Indicates whether the sales tax code represents a taxable (true) or non-taxable (false) item.')] = None
    desc: str | None = None
    item_purchase_tax: Annotated[QbdRef | None, Field(alias='itemPurchaseTax')] = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Sales Tax Code is inactive. Default is true.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseSalesTaxCode(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[SalesTaxCode] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateSalesTaxCodeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the sales tax code. (Max 3 characters)')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Sales Tax Code is inactive. Default is true.')] = None
    is_taxable: Annotated[bool, Field(alias='isTaxable', description='(Required) Indicates whether the sales tax code represents a taxable (true) or non-taxable (false) item.')]
    description: Annotated[str | None, Field(description='(Optional) A description for the sales tax code. (Max 50 characters)')] = None
    item_purchase_tax_id: Annotated[str | None, Field(alias='itemPurchaseTaxId', description='(Optional) The ListID or FullName of the ItemSalesTax item used for tax calculation on purchases.\nFollows the Flattened-ID Pattern for ItemPurchaseTaxRef.')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the ItemSalesTax item used for tax calculation on sales.\nFollows the Flattened-ID Pattern for ItemSalesTaxRef.')] = None


class UpdateSalesTaxCodeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) The new name of the sales tax code. (Max 31 characters)')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Sales Tax Code will be made inactive.')] = None
    is_taxable: Annotated[bool | None, Field(alias='isTaxable', description='(Optional) Indicates whether the sales tax code represents a taxable (true) or non-taxable (false) item.\nNOTE: You cannot change this after the code has been used in a transaction.')] = None
    description: Annotated[str | None, Field(description='(Optional) The new description for the sales tax code. (Max 50 characters)')] = None
    item_purchase_tax_id: Annotated[str | None, Field(alias='itemPurchaseTaxId', description='(Optional) The ListID or FullName of the ItemSalesTax item used for tax calculation on purchases.\nFollows the Flattened-ID Pattern for ItemPurchaseTaxRef.')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the ItemSalesTax item used for tax calculation on sales.\nFollows the Flattened-ID Pattern for ItemSalesTaxRef.')] = None
