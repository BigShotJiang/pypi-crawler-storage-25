from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, DefaultUnits, RelatedUnits

class BaseUnit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='The case-insensitive unique name of this base unit, unique across all base units. **NOTE**: Base units do not have a `fullName` field because they are not hierarchical objects, which is why `name` is unique for them but not for objects that have parents. Maximum length: 31 characters.')]
    abbreviation: Annotated[str, Field(description="The base unit's short identifier shown in the QuickBooks U/M field on transaction line items. Maximum length: 31 characters.")]


class UnitOfMeasureSet(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the unit of measure set. Max length: 31.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    unit_of_measure_type: Annotated[str | None, Field(alias='unitOfMeasureType', description='The type of measurement: "Area", "Count", "Length", "Other", "Time", "Volume", "Weight".')] = None
    base_unit: Annotated[BaseUnit | None, Field(alias='baseUnit', description='The base unit definition for this set.')] = None
    related_units: Annotated[RelatedUnits | None, Field(alias='relatedUnits', description='List of related units with conversion ratios.')] = None
    default_units: Annotated[DefaultUnits | None, Field(alias='defaultUnits', description='List of default units for specific purposes (Purchase, Sales, Shipping).')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the UOM set is active. Defaults to true.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseUnitOfMeasureSet(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[UnitOfMeasureSet] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class BaseUnitRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the base unit (e.g., "Barrel"). Max length: 31.')]
    abbreviation: Annotated[str, Field(description='(Required) The abbreviation of the base unit (e.g., "bbl"). Max length: 31.')]


class CreateUnitOfMeasureSetRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the unit of measure set. Max length: 31.')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the UOM set is active. Defaults to true.')] = None
    unit_of_measure_type: Annotated[str, Field(alias='unitOfMeasureType', description='(Required) The type of measurement this set is for.\nValid values: "Area", "Count", "Length", "Other", "Time", "Volume", "Weight"')]
    base_unit: Annotated[BaseUnitRequest, Field(alias='baseUnit', description='(Required) The base unit definition for the set.')]
    related_units: Annotated[RelatedUnits | None, Field(alias='relatedUnits', description='(Optional) A list of related units and their conversion ratios to the base unit.')] = None
    default_units: Annotated[DefaultUnits | None, Field(alias='defaultUnits', description='(Optional) A list of default units to use for specific purposes (Purchase, Sales, Shipping).')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class DefaultUnit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    unit_used_for: Annotated[str, Field(alias='unitUsedFor', description='Where this default unit is used as the default: purchase line items, sales line items, or shipping lines.')]
    unit: Annotated[str, Field(description='The unit name for this default unit, as displayed in the U/M field. If the company file is enabled for multiple units per item, this appears as an available unit for the item. Must correspond to the base unit or a related unit defined in this set. Maximum length: 31 characters.')]


class DefaultUnitRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    unit_used_for: Annotated[str, Field(alias='unitUsedFor', description='(Required) The purpose the unit is used for.\nValid values: "Purchase", "Sales", "Shipping"')]
    unit: Annotated[str, Field(description='(Required) The name of the unit to be used as default for the specified purpose.\nMax length: 31.')]


class RelatedUnit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='The case-insensitive unique name of this related unit, unique across all related units. **NOTE**: Related units do not have a `fullName` field because they are not hierarchical objects, which is why `name` is unique for them but not for objects that have parents. Maximum length: 31 characters.')]
    abbreviation: Annotated[str, Field(description="The related unit's short identifier shown in the QuickBooks U/M field on transaction line items. Maximum length: 31 characters.")]
    conversion_ratio: Annotated[float | None, Field(alias='conversionRatio', description='The number of base units in this related unit, represented as a decimal string. For example, if the base unit is "box" and this related unit is "case" with `conversionRatio` = "10", that means there are 10 boxes in one case.')] = None


class RelatedUnitRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the related unit (e.g., "Gallon"). Max length: 31.')]
    abbreviation: Annotated[str, Field(description='(Required) The abbreviation of the related unit (e.g., "gal"). Max length: 31.')]
    conversion_ratio: Annotated[float, Field(alias='conversionRatio', description='(Required) The conversion ratio to the BaseUnit (e.g., 42 for Barrel to Gallons).\nValid range: 0.001 to 5000.')]
