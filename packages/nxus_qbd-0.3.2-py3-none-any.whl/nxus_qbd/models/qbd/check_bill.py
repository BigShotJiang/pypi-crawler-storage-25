from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, AppliedToTransactions, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class CheckBill(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The currency exchange rate.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., Check #).\nMax length: 11 characters.\nNote: Cannot be specified with IsToBePrinted=true.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the check.\nMax length: 4095 characters.')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    payables_account: Annotated[QbdRef | None, Field(alias='payablesAccount')] = None
    address: Annotated[Address | None, Field(description="The payee's full address.")] = None
    address_block: Annotated[AddressBlock | None, Field(alias='addressBlock', description='The address block formatted for printing on the check.')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    applied_to_transactions: Annotated[AppliedToTransactions | None, Field(alias='appliedToTransactions', description='(Required) List of transactions (bills) to apply this check to.\nQBD requiring at least one AppliedToTransactionAddRequest for BillPaymentCheckAdd.')] = None
    amount: Annotated[float | None, Field(description='(Optional) The total amount of the check.')] = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency', description='(Optional) The amount in the home currency.')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseCheckBill(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[CheckBill] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCheckBillRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    payee_id: Annotated[str, Field(alias='payeeId')]
    bank_account_id: Annotated[str, Field(alias='bankAccountId', description='(Required) The ListID of the bank account from which the check is drawn.\nMax length: 159 characters.')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., Check #).\nMax length: 11 characters.\nNote: Cannot be specified with IsToBePrinted=true.')] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId', description='(Optional) The ListID of the Accounts Payable account.\nMax length: 159 characters.')] = None
    amount: Annotated[float | None, Field(description='(Optional) The total amount of the check.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='(Optional) The ListID of the currency.\nMax length: 64 characters.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The currency exchange rate.')] = None
    amount_in_home_currency: Annotated[float | None, Field(alias='amountInHomeCurrency', description='(Optional) The amount in the home currency.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the check.\nMax length: 4095 characters.')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    applied_to_transactions: Annotated[AppliedToTransactions | None, Field(alias='appliedToTransactions', description='(Required) List of transactions (bills) to apply this check to.\nQBD requiring at least one AppliedToTransactionAddRequest for BillPaymentCheckAdd.')] = None


class UpdateCheckBillRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    payee_id: Annotated[str | None, Field(alias='payeeId')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the check.\nMax length: 4095 characters.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., Check #).\nMax length: 11 characters.')] = None
    bank_account_id: Annotated[str | None, Field(alias='bankAccountId', description='(Optional) The ListID of the bank account.\nMax length: 159 characters.')] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId', description='(Optional) The ListID of the Accounts Payable account.\nMax length: 159 characters.')] = None
    amount: Annotated[float | None, Field(description='(Optional) The total amount of the check.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='(Optional) The ListID of the currency.\nMax length: 64 characters.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The currency exchange rate.')] = None
    amount_in_home_currency: Annotated[float | None, Field(alias='amountInHomeCurrency', description='(Optional) The amount in the home currency.')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    applied_to_transactions: Annotated[AppliedToTransactions | None, Field(alias='appliedToTransactions', description='(Optional) List of transactions to apply updates to.')] = None
