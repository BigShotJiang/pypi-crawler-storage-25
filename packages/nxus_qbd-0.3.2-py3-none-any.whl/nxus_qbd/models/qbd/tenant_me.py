from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime

class RotatePublishableKeyResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    publishable_key: Annotated[str | None, Field(alias='publishableKey', description='The new publishable key — update all auth flow URLs with this.')] = None
    message: str | None = None
    rotated_at: Annotated[FlexibleDatetime | None, Field(alias='rotatedAt')] = None


class TenantMeResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: UUID
    name: str | None = None
    slug: str | None = None
    status: str | None = None
    publishable_key: Annotated[str | None, Field(alias='publishableKey', description='The tenant-level publishable key (pk_nxus_live_... or pk_nxus_test_...).\nUse as the ?pk= query parameter in your hosted QWC setup page URLs.\nSafe to share with clients and embed in frontend code.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime | None, Field(alias='updatedAt')] = None
