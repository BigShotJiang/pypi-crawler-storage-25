from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressRequest, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class Bill(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    vendor: Annotated[QbdRef | None, Field(description='The vendor who issued the bill. When linking to a Purchase Order, this vendor\nmust match the vendor on the Purchase Order.', examples=[{'id': '80000001-1234567890', 'fullName': 'Daigle Lighting'}])] = None
    vendor_address: Annotated[Address | None, Field(alias='vendorAddress', description='The billing address of the vendor.', examples=[{'line1': 'Daigle Lighting', 'line2': '123 Industrial Way', 'city': 'Middlefield', 'state': 'CA', 'postalCode': '94471'}])] = None
    payables_account: Annotated[QbdRef | None, Field(alias='payablesAccount')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='The date by which the bill must be paid.', examples=['"2024-11-28"'])] = None
    amount_due: Annotated[float | None, Field(alias='amountDue', description='The total monetary amount of the bill.')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (v8.0).')] = None
    amount_due_in_home_currency: Annotated[str | None, Field(alias='amountDueInHomeCurrency', description="The total amount due expressed in the company's home currency.\nThis is calculated and returned by QuickBooks when the multicurrency feature is enabled.", examples=['"1500.00"'])] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the bill.')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='Indicates whether the bill is currently marked as pending.', examples=['false'])] = None
    terms: Annotated[QbdRef | None, Field(description='The payment terms associated with the bill (e.g., Net 30), which calculate the DueDate.', examples=[{'id': '80000002-1234567890', 'fullName': 'Net 30'}])] = None
    class_: Annotated[QbdRef | None, Field(alias='class', description='The class associated with the bill, used for categorizing expenses and reporting\n(requires class tracking to be enabled in QuickBooks).', examples=[{'id': '80000005-1234567890', 'fullName': 'Overhead'}])] = None
    memo: Annotated[str | None, Field(description='Memo/description for the bill.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode', description='The sales tax code indicating the general taxability of the bill (e.g., Tax, Non).', examples=[{'id': '80000008-1234567890', 'fullName': 'Non'}])] = None
    is_paid: Annotated[bool | None, Field(alias='isPaid', description='Indicates whether the bill has been paid in full and closed.', examples=['false'])] = None
    amount: float | None = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates whether the amounts in the bill already include sales tax.', examples=['false'])] = None
    account: QbdRef | None = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items for the bill.\nAt least one expense line or item line is required.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the bill (for inventory items).')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    open_amount: Annotated[float | None, Field(alias='openAmount')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseBill(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Bill] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateBillRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    vendor_id: Annotated[str, Field(alias='vendorId', description='Filter by Vendor ID.')]
    vendor_address: Annotated[AddressRequest | None, Field(alias='vendorAddress', description='Optional vendor address override.')] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    transaction_date: Annotated[date_aliased, Field(alias='transactionDate')]
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='Due date for the bill.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the bill.', max_length=20)] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='Terms reference (e.g., "Net 30", "Due on receipt").')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='Reference to the QuickBooks Class for this transaction (PRIVATE, v13.0).')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the bill.', max_length=4095)] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Whether tax is included in item amounts (not in QBD, v6.0).')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='Sales tax code reference (not in QBD, v6.0).')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (v8.0).')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    link_to_transaction_ids: Annotated[list[str] | None, Field(alias='linkToTransactionIds')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items for the bill.\nAt least one expense line or item line is required.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the bill (for inventory items).')] = None


class UpdateBillRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'])] = None
    vendor_address: Annotated[AddressRequest | None, Field(alias='vendorAddress')] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', max_length=20)] = None
    terms_id: Annotated[str | None, Field(alias='termsId')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='Reference to the QuickBooks Class for this transaction (PRIVATE, v13.0).')] = None
    memo: Annotated[str | None, Field(max_length=4095)] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Whether tax is included in item amounts (not in QBD).')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='Sales tax code reference (not in QBD).')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions.')] = None
    clear_expense_lines: Annotated[bool | None, Field(alias='clearExpenseLines')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    clear_item_lines: Annotated[bool | None, Field(alias='clearItemLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
