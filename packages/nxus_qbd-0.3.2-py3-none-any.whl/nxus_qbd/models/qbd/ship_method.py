from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields

class ShipMethod(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the shipping method. (Max 15 characters)')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Shipping Method is inactive. Default is true.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseShipMethod(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ShipMethod] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateShipMethodRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the shipping method. (Max 15 characters)', max_length=15)]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Shipping Method is inactive. Default is true.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateShipMethodRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) The new name of the shipping method. (Max 15 characters)', max_length=15)] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Shipping Method is inactive.')] = None
