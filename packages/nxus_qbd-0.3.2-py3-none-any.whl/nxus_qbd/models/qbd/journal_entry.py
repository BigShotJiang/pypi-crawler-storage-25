from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CreditLines, CustomFields, DebitLines, ExpenseLines, GroupLines, ItemGroupLines, ItemLines, Lines, LinkedTransactions, QbdRef

class JournalEntry(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the journal entry. (Max 20 characters)')] = None
    memo: str | None = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    is_adjustment: Annotated[bool | None, Field(alias='isAdjustment', description='Memo/description for the journal entry. (Max 4095 characters)')] = None
    is_home_currency_adjustment: Annotated[bool | None, Field(alias='isHomeCurrencyAdjustment', description='Indicates if this is a home currency adjustment.')] = None
    is_amounts_entered_in_home_currency: Annotated[bool | None, Field(alias='isAmountsEnteredInHomeCurrency', description='Indicates if amounts are entered in home currency.')] = None
    debit_lines: Annotated[DebitLines | None, Field(alias='debitLines')] = None
    credit_lines: Annotated[CreditLines | None, Field(alias='creditLines')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseJournalEntry(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[JournalEntry] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateJournalEntryRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the journal entry. (Max 20 characters)')] = None
    is_adjustment: Annotated[bool | None, Field(alias='isAdjustment', description='Memo/description for the journal entry. (Max 4095 characters)')] = None
    is_home_currency_adjustment: Annotated[bool | None, Field(alias='isHomeCurrencyAdjustment', description='Indicates if this is a home currency adjustment.')] = None
    is_amounts_entered_in_home_currency: Annotated[bool | None, Field(alias='isAmountsEnteredInHomeCurrency', description='Indicates if amounts are entered in home currency.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='(Optional) The ListID or FullName of the currency.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    debit_lines: Annotated[DebitLines | None, Field(alias='debitLines')] = None
    credit_lines: Annotated[CreditLines | None, Field(alias='creditLines')] = None


class CreateJournalLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str, Field(alias='accountId', description='(Required) The ListID or FullName of the account.')]
    amount: Annotated[float, Field(description='(Required) Amount for the line.')]
    memo: Annotated[str | None, Field(description='Memo for the line. (Max 4095 characters)')] = None
    entity_id: Annotated[str | None, Field(alias='entityId', description='(Optional) The ListID or FullName of the entity (customer, vendor, or other name).')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the item sales tax.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='Billable status of the line (Billable, NotBillable, HasBeenBilled).')] = None


class JournalLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    id: str
    account: QbdRef | None = None
    amount: Annotated[float | None, Field(description='(Required) Amount for the line.')] = None
    memo: Annotated[str | None, Field(description='Memo for the line. (Max 4095 characters)')] = None
    entity: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='Billable status of the line (Billable, NotBillable, HasBeenBilled).')] = None


class UpdateJournalEntryRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the journal entry. (Max 20 characters)')] = None
    is_adjustment: Annotated[bool | None, Field(alias='isAdjustment', description='Indicates if this is an adjustment entry.')] = None
    is_home_currency_adjustment: Annotated[bool | None, Field(alias='isHomeCurrencyAdjustment', description='Indicates if this is a home currency adjustment.')] = None
    is_amounts_entered_in_home_currency: Annotated[bool | None, Field(alias='isAmountsEnteredInHomeCurrency', description='Indicates if amounts are entered in home currency.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='(Optional) The ListID or FullName of the currency.')] = None
    lines: Lines | None = None
    group_lines: Annotated[GroupLines | None, Field(alias='groupLines')] = None


class UpdateJournalLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str | None, Field(alias='accountId', description='(Optional) The ListID or FullName of the account.')] = None
    amount: Annotated[float | None, Field(description='(Optional) Amount for the line.')] = None
    memo: Annotated[str | None, Field(description='(Optional) Memo for the line. (Max 4095 characters)')] = None
    entity_id: Annotated[str | None, Field(alias='entityId', description='(Optional) The ListID or FullName of the entity (customer, vendor, or other name).')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the item sales tax.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='Billable status of the line (Billable, NotBillable, HasBeenBilled).')] = None
