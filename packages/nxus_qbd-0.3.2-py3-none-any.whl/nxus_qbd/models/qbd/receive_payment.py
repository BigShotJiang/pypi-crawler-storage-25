from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import AppliedToTransactions, AppliedToTxns, CreditCardTransactionInfo, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class ReceivePayment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (v8.0+).')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the payment (max 20 chars).')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the payment (max 4095 chars).')] = None
    txn_number: Annotated[int | None, Field(alias='txnNumber')] = None
    customer: QbdRef | None = None
    receivables_account: Annotated[QbdRef | None, Field(alias='receivablesAccount')] = None
    payment_method: Annotated[QbdRef | None, Field(alias='paymentMethod')] = None
    deposit_to_account: Annotated[QbdRef | None, Field(alias='depositToAccount')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    unused_payment: Annotated[float | None, Field(alias='unusedPayment')] = None
    unused_credits: Annotated[float | None, Field(alias='unusedCredits')] = None
    applied_to_txns: Annotated[AppliedToTxns | None, Field(alias='appliedToTxns', description='List of invoices/transactions to apply this payment to.\nMutually exclusive with IsAutoApply.')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseReceivePayment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ReceivePayment] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreditCardTxnInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    credit_card_number: Annotated[str | None, Field(alias='creditCardNumber')] = None
    expiration_month: Annotated[int | None, Field(alias='expirationMonth')] = None
    expiration_year: Annotated[int | None, Field(alias='expirationYear')] = None
    name_on_card: Annotated[str | None, Field(alias='nameOnCard')] = None
    credit_card_address: Annotated[str | None, Field(alias='creditCardAddress')] = None
    credit_card_postal_code: Annotated[str | None, Field(alias='creditCardPostalCode')] = None
    commercial_card_code: Annotated[str | None, Field(alias='commercialCardCode')] = None
    transaction_mode: Annotated[str | None, Field(alias='transactionMode')] = None
    cvc_number: Annotated[str | None, Field(alias='cvcNumber')] = None


class CreateReceivePaymentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    customer_id: Annotated[str, Field(alias='customerId', description='The customer making the payment (required).')]
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the payment (max 20 chars).')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount', description='Total amount of the payment.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (v8.0+).')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='Payment method reference (e.g., "Cash", "Check", "Credit Card").')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the payment (max 4095 chars).')] = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId', description='Account to deposit the payment into.')] = None
    credit_card_transaction_info: Annotated[CreditCardTxnInfoRequest | None, Field(alias='creditCardTransactionInfo')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_auto_apply: Annotated[bool | None, Field(alias='isAutoApply', description='If true, QuickBooks will automatically apply the payment to outstanding invoices.\nMutually exclusive with AppliedToTxns.')] = None
    applied_to_transactions: Annotated[AppliedToTransactions | None, Field(alias='appliedToTransactions')] = None


class UpdateReceivePaymentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='Customer making the payment.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the payment (max 20 chars).')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount', description='Total amount of the payment.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (v8.0+).')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='Payment method reference.')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the payment (max 4095 chars).')] = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId', description='Account to deposit the payment into.')] = None
    credit_card_txn_info: Annotated[CreditCardTxnInfoRequest | None, Field(alias='creditCardTxnInfo', description='Credit card transaction information (v7.0+ for mod).')] = None
    applied_to_transactions: Annotated[AppliedToTransactions | None, Field(alias='appliedToTransactions')] = None
