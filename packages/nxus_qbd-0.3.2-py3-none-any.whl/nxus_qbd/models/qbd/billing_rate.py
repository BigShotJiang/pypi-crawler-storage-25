from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BillingRateItems, BillingRatePerItems, CustomFields, QbdRef

class BillingRate(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the billing rate.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    billing_rate_type: Annotated[str | None, Field(alias='billingRateType', description='Indicates whether the billing rate applies a fixed rate to all service items or custom rates per individual service item [2-4].', examples=['FixedBilling | PerItem'])] = None
    fixed_billing_rate: Annotated[float | None, Field(alias='fixedBillingRate', description='A simple fixed rate that will override all the standard rates for service items performed by the entity assigned this billing rate [2, 3].', examples=['100.00'])] = None
    billing_rate_per_items: Annotated[BillingRatePerItems | None, Field(alias='billingRatePerItems', description='A list of specific service items that are being overridden by a fixed custom rate or percentage [2, 4].', examples=[[{'Item': {'ListId': '80000015-1234567890', 'FullName': 'Pump Repair'}, 'CustomRate': 50.0, 'CustomRatePercent': -50.0}]])] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseBillingRate(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[BillingRate] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class BillingRateItemRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str, Field(alias='itemId', description='(Required) The ListID or FullName of the service item to override.')]
    custom_rate: Annotated[float | None, Field(alias='customRate', description='(Optional) A specific fixed rate for this item.')] = None
    custom_rate_percent: Annotated[float | None, Field(alias='customRatePercent', description='(Optional) A specific percentage rate for this item.')] = None
    adjust_percentage: Annotated[float | None, Field(alias='adjustPercentage', description='(Optional) The percentage to adjust the billing rate by.\nRequired if AdjustBillingRateRelativeTo is set.')] = None
    adjust_billing_rate_relative_to: Annotated[str | None, Field(alias='adjustBillingRateRelativeTo', description='(Optional) What the adjustment is relative to (StandardRate, CurrentCustomRate).\nRequired if AdjustPercentage is set.')] = None


class BillingRatePerItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item: Annotated[QbdRef | None, Field(description='A reference to the specific service item this custom rate applies to [4, 5].', examples=[{'ListId': '80000015-1234567890', 'FullName': 'Pump Repair'}])] = None
    custom_rate: Annotated[float | None, Field(alias='customRate', description="A fixed hourly rate for this specific service item that overrides the item's standard rate [6].", examples=['50.00'])] = None
    custom_rate_percent: Annotated[float | None, Field(alias='customRatePercent', description="A percentage adjustment higher or lower than the item's standard rate [6, 7].\nA positive value indicates a higher rate, and a negative value indicates a lower rate discount (e.g., -50.0 means 50% lower than the standard rate) [7, 8].", examples=['-50.0'])] = None


class CreateBillingRateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the billing rate.')]
    fixed_billing_rate: Annotated[float | None, Field(alias='fixedBillingRate', description='(Optional) Specifies a fixed billing rate that applies to all service items.\nMutually exclusive with BillingRateItems.')] = None
    billing_rate_items: Annotated[BillingRateItems | None, Field(alias='billingRateItems', description='(Optional) Specific billing rates per service item.\nIf you want to specify more than one service item, use this list.\nMutually exclusive with FixedBillingRate.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
