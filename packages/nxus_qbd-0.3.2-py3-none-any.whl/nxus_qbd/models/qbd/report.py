from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import ColumnTitles, Columns, CustomFields, Rows, SubTitles, Values

class ReportData(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    rows: Annotated[Rows | None, Field(description='The rows in the report.')] = None


class Report(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: Annotated[str | None, Field(description='The unique nexus identifier for the report object in the REST API.')] = None
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    title: str | None = None
    subtitle: str | None = None
    basis: str | None = None
    period: str | None = None
    row_count: Annotated[int | None, Field(alias='rowCount')] = None
    column_count: Annotated[int | None, Field(alias='columnCount')] = None
    header_row_count: Annotated[int | None, Field(alias='headerRowCount')] = None
    columns: Columns | None = None
    data: ReportData | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class ApiResponseReport(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    success: bool | None = None
    message: str | None = None
    data: Report | None = None
    timestamp: FlexibleDatetime | None = None
    request_id: Annotated[str | None, Field(alias='requestId')] = None


class DictionaryStringString(RootModel[dict[str, str]]):
    root: dict[str, str]


class ReportColData(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    column_id: Annotated[str | None, Field(alias='columnId')] = None
    value: Annotated[str | None, Field(description='The value of the column.')] = None
    data_type: Annotated[str | None, Field(alias='dataType', description='The data type of the column.')] = None
    attributes: Annotated[DictionaryStringString | None, Field(description='The attributes of the column.')] = None


class ReportColumnDescription(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    data_type: Annotated[str | None, Field(alias='dataType', description='The data type of the column.')] = None
    type: str | None = None
    column_titles: Annotated[ColumnTitles | None, Field(alias='columnTitles', description='The column titles for the report.')] = None


class ReportColumnTitle(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    title_row: Annotated[int | None, Field(alias='titleRow', description='The title row of the column.')] = None
    value: Annotated[str | None, Field(description='The value of the column title.')] = None
    sub_titles: Annotated[SubTitles | None, Field(alias='subTitles', description='The sub-titles for the column.')] = None


class ReportRowData(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    type: str | None = None
    value: Annotated[str | None, Field(description='The value of the row.')] = None
    row_number: Annotated[int | None, Field(alias='rowNumber', description='The row number of the row.')] = None


class ReportRow(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    type: Annotated[str | None, Field(description='The type of the row.')] = None
    row_number: Annotated[int | None, Field(alias='rowNumber', description='The row number of the row.')] = None
    value: Annotated[str | None, Field(description='The value of the row.')] = None
    info: ReportRowData | None = None
    values: Values | None = None
    rows: Rows | None = None
