from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import AppliedCredits, AppliedToTransactions, ApplyToTransactions, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class ApplyToTransactionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    payment_amount: Annotated[float | None, Field(alias='paymentAmount', description='The amount of the payment to apply to this transaction.\n(Optional in schema, but typically used)')] = None
    applied_credits: Annotated[AppliedCredits | None, Field(alias='appliedCredits', description='List of credits to set/apply to this transaction.\n(Optional, may repeat)')] = None
    discount_amount: Annotated[float | None, Field(alias='discountAmount', description='The amount of discount to apply.\n(Optional)')] = None
    discount_account_id: Annotated[str | None, Field(alias='discountAccountId', description='The account to track the discount.\n(Optional)')] = None
    discount_class_id: Annotated[str | None, Field(alias='discountClassId', description='The class to track the discount.\n(Optional)')] = None
    is_valid: Annotated[bool | None, Field(alias='isValid', description='Validation: Must specify either PaymentAmount, AppliedCredits, DiscountAmount, or any combination.')] = None


class CreditCardBill(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate (required if currency is specified)')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the payment')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the payment')] = None
    credit_card_account: Annotated[QbdRef | None, Field(alias='creditCardAccount', description='Credit card account being charged (required)\nThe credit card account to which this bill credit card payment is being charged.\nThis bill credit card payment will decrease the balance of this account.')] = None
    payables_account: Annotated[QbdRef | None, Field(alias='payablesAccount')] = None
    applied_to_transactions: Annotated[AppliedToTransactions | None, Field(alias='appliedToTransactions')] = None
    amount: Annotated[float | None, Field(description='Total amount of the payment')] = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseCreditCardBill(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[CreditCardBill] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCreditCardBillRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Transaction reference number (optional) autogenerates if not specified\nused for pagination and idempotency')] = None
    payee_id: Annotated[str, Field(alias='payeeId', description='Vendor/payee being paid (required)')]
    payables_account_id: Annotated[str, Field(alias='payablesAccountId')]
    credit_card_account_id: Annotated[str, Field(alias='creditCardAccountId', description='Credit card account being charged (required)')]
    amount: Annotated[float, Field(description='Total amount of the payment (required)\nMust match sum of applied bill amounts', ge=0.01, le=999999999999.99)]
    memo: Annotated[str | None, Field(description='Memo/description for the payment', max_length=4095)] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='Currency reference (optional - for multi-currency environments)')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate (required if currency is specified)')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    apply_to_transactions: Annotated[list[ApplyToTransactionRequest], Field(alias='applyToTransactions')]
    is_valid_total_amount: Annotated[bool | None, Field(alias='isValidTotalAmount', description='Validation: Ensure total matches applied amounts')] = None


class UpdateCreditCardBillRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the payment', max_length=20)] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    payee_id: Annotated[str | None, Field(alias='payeeId', description='Vendor/payee being paid')] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    credit_card_account_id: Annotated[str | None, Field(alias='creditCardAccountId', description='Credit card account being charged')] = None
    amount: Annotated[float | None, Field(description='Total amount of the payment', ge=0.01, le=999999999999.99)] = None
    memo: Annotated[str | None, Field(description='Memo/description for the payment', max_length=4095)] = None
    apply_to_transactions: Annotated[ApplyToTransactions | None, Field(alias='applyToTransactions')] = None
