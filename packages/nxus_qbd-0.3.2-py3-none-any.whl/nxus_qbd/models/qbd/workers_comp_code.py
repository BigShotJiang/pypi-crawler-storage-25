from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, RateEntries, RateHistory1

class WorkersCompCode(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the Workers Comp Code. Max length: 13.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    desc: Annotated[str | None, Field(description="Description of the Workers' Compensation Code.")] = None
    current_rate: Annotated[float | None, Field(alias='currentRate', description='The current rate being used.')] = None
    current_effective_date: Annotated[date_aliased | None, Field(alias='currentEffectiveDate', description='The effective date of the current rate.')] = None
    next_rate: Annotated[float | None, Field(alias='nextRate', description='The next scheduled rate (if any).')] = None
    next_effective_date: Annotated[date_aliased | None, Field(alias='nextEffectiveDate', description='The effective date of the next rate.')] = None
    rate_history: Annotated[RateHistory1 | None, Field(alias='rateHistory', description='History of all rate entries for this code.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates if the code is active. Defaults to true.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseWorkersCompCode(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[WorkersCompCode] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateWorkersCompCodeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the Workers Comp Code. Max length: 13.')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates if the code is active. Defaults to true.')] = None
    desc: Annotated[str | None, Field(description='(Optional) Description of the code. Max length: 31.')] = None
    rate_entries: Annotated[RateEntries, Field(alias='rateEntries', description='(Required) List of rate entries associated with this code.\nMust have at least one entry.')]
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class RateEntryRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    rate: Annotated[float, Field(description='(Required) The rate for this entry.')]
    effective_date: Annotated[date_aliased, Field(alias='effectiveDate', description='(Required) The effective date of this rate.')]


class RateHistory(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    rate: Annotated[float | None, Field(description='The rate value.')] = None
    effective_date: Annotated[date_aliased | None, Field(alias='effectiveDate', description='The effective date of this rate.')] = None


class UpdateWorkersCompCodeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) New name for the code. Max length: 13.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Update the active status.')] = None
    desc: Annotated[str | None, Field(description='(Optional) Update the description. Max length: 31.')] = None
    rate_entries: Annotated[RateEntries | None, Field(alias='rateEntries', description='(Optional) Add or update rate entries.')] = None
