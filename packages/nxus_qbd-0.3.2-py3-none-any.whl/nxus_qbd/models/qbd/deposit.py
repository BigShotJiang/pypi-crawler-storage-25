from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, DepositLines, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class CashBackInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_line_id: Annotated[str | None, Field(alias='transactionLineId')] = None
    account: QbdRef | None = None
    memo: Annotated[str | None, Field(description='(Optional) Memo about the cash back line. (Max 4095 characters)')] = None
    amount: Annotated[float | None, Field(description='(Optional) The amount of cash back requested.')] = None


class Deposit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate if this is a foreign currency Deposit.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber')] = None
    memo: Annotated[str | None, Field(description='(Optional) General memo about the Deposit. (Max 4095 characters)')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    deposit_to_account: Annotated[QbdRef | None, Field(alias='depositToAccount')] = None
    deposit_total: Annotated[float | None, Field(alias='depositTotal')] = None
    deposit_total_in_home_currency: Annotated[float | None, Field(alias='depositTotalInHomeCurrency')] = None
    cash_back_info: Annotated[CashBackInfo | None, Field(alias='cashBackInfo', description='(Optional) Information about cash back requested from the deposit total.')] = None
    deposit_lines: Annotated[DepositLines | None, Field(alias='depositLines', description='(Optional) A list of payment and manual lines making up the total deposit amount.')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseDeposit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Deposit] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CashBackInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str | None, Field(alias='accountId', description='(Required for Add, Optional for Mod) The ListID or FullName of the account to which the cash back amount will be posted (e.g., Expense Account).\nFollows the Flattened-ID Pattern for AccountRef.')] = None
    memo: Annotated[str | None, Field(description='(Optional) Memo about the cash back line. (Max 4095 characters)', max_length=4095)] = None
    amount: Annotated[float | None, Field(description='(Optional) The amount of cash back requested.')] = None


class DepositManualLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    entity_id: Annotated[str | None, Field(alias='entityId', description='(Optional) The ListID or FullName of the entity (Customer, Vendor, OtherName) associated with this deposit line.\nFollows the Flattened-ID Pattern for EntityRef.')] = None
    account_id: Annotated[str, Field(alias='accountId', description='(Required for Add, Optional for Mod) The ListID or FullName of the income or other source account for this line item.\nFollows the Flattened-ID Pattern for AccountRef.')]
    memo: Annotated[str | None, Field(description='(Optional) Memo for this line item. (Max 4095 characters)', max_length=4095)] = None
    check_number: Annotated[str | None, Field(alias='checkNumber', description='(Optional) Check Number for this deposit line. (Max 20 characters)', max_length=20)] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='(Optional) The ListID or FullName of the payment method.\nFollows the Flattened-ID Pattern for PaymentMethodRef.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.\nFollows the Flattened-ID Pattern for ClassRef.')] = None
    amount: Annotated[float | None, Field(description='(Optional) Amount of the deposit line.')] = None


class DepositPaymentLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    payment_txn_line_id: Annotated[str | None, Field(alias='paymentTxnLineId', description='(Optional) The TxnLineID of the specific line within the payment transaction (if applicable, typically for Undeposited Funds line).')] = None
    override_memo: Annotated[str | None, Field(alias='overrideMemo', description='(Optional) Memo override for this line item. (Max 4095 characters)', max_length=4095)] = None
    override_check_number: Annotated[str | None, Field(alias='overrideCheckNumber', description='(Optional) Check Number override for this line item. (Max 20 characters)', max_length=20)] = None
    override_class_id: Annotated[str | None, Field(alias='overrideClassId', description='(Optional) The ListID or FullName of the class override for this line item.')] = None


class CreateDepositLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    payment_line: Annotated[DepositPaymentLineRequest | None, Field(alias='paymentLine', description='(Optional) Details for depositing a previously recorded payment (ReceivePayment, SalesReceipt).\nMutually exclusive with ManualLine.')] = None
    manual_line: Annotated[DepositManualLineRequest | None, Field(alias='manualLine', description='(Optional) Details for manually depositing a fund from another source.\nMutually exclusive with PaymentLine.')] = None


class CreateDepositRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    deposit_to_account_id: Annotated[str, Field(alias='depositToAccountId', description='(Required) The ListID of the bank account where the funds are deposited.\nFollows the Flattened-ID Pattern for DepositToAccountRef.', max_length=50)]
    memo: Annotated[str | None, Field(description='(Optional) General memo about the Deposit. (Max 4095 characters)', max_length=4095)] = None
    cash_back_info: Annotated[CashBackInfoRequest | None, Field(alias='cashBackInfo', description='(Optional) Information about cash back requested from the deposit total.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='(Optional) The ListID or FullName of the currency for the transaction.\nFollows the Flattened-ID Pattern for CurrencyRef.', max_length=50)] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate if this is a foreign currency Deposit.')] = None
    deposit_lines: Annotated[DepositLines | None, Field(alias='depositLines', description='(Optional) A list of payment and manual lines making up the total deposit amount.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class DepositLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_type: Annotated[str | None, Field(alias='transactionType')] = None
    transaction_id: Annotated[str | None, Field(alias='transactionId')] = None
    transaction_line_id: Annotated[str | None, Field(alias='transactionLineId')] = None
    payment_transaction_line_id: Annotated[str | None, Field(alias='paymentTransactionLineId')] = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    memo: str | None = None
    check_number: Annotated[str | None, Field(alias='checkNumber')] = None
    payment_method: Annotated[QbdRef | None, Field(alias='paymentMethod')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    amount: float | None = None


class UpdateDepositLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_line_id: Annotated[str, Field(alias='transactionLineId')]
    payment_line_mod: Annotated[DepositPaymentLineRequest | None, Field(alias='paymentLineMod', description='(Optional) Modification details for a payment line (PaymentTxnID, OverrideMemo, etc.).\nMutually exclusive with ManualLineMod.')] = None
    manual_line_mod: Annotated[DepositManualLineRequest | None, Field(alias='manualLineMod', description='(Optional) Modification details for a manual line (EntityId, AccountId, Amount, etc.).\nMutually exclusive with PaymentLineMod.')] = None


class UpdateDepositRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId', description='(Optional) The ListID or FullName of the bank account where the funds are deposited.\nFollows the Flattened-ID Pattern for DepositToAccountRef.')] = None
    memo: Annotated[str | None, Field(description='(Optional) New general memo about the Deposit. (Max 4095 characters)', max_length=4095)] = None
    cash_back_info: Annotated[CashBackInfoRequest | None, Field(alias='cashBackInfo')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='(Optional) The ListID or FullName of the currency for the transaction.\nFollows the Flattened-ID Pattern for CurrencyRef.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) New exchange rate if this is a foreign currency Deposit.')] = None
    deposit_lines: Annotated[DepositLines | None, Field(alias='depositLines')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
