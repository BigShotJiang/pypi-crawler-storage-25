from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class TimeTracking(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber')] = None
    memo: str | None = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    customer: QbdRef | None = None
    item_service: Annotated[QbdRef | None, Field(alias='itemService')] = None
    duration: Annotated[str | None, Field(description='(Required) The duration of the work performed, formatted as an XML TimeIntervalType string (e.g., "PT8H0M0S" for 8 hours).')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    payroll_item_wage: Annotated[QbdRef | None, Field(alias='payrollItemWage')] = None
    notes: Annotated[str | None, Field(description='(Optional) General notes about the time entry. Max 4095 chars.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) Status indicating if the time is billable (Billable, NotBillable, HasBeenBilled).')] = None
    is_billable: Annotated[bool | None, Field(alias='isBillable', description='(Optional) Legacy flag to set time as billable. Use BillableStatus instead if possible.')] = None
    is_billed: Annotated[bool | None, Field(alias='isBilled')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseTimeTracking(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[TimeTracking] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateTimeTrackingRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    entity_id: Annotated[str, Field(alias='entityId', description='(Required) The ListID or FullName of the Entity (Employee, Vendor, or OtherName) that performed the work.')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job this time is for. Required if IsBillable is true.')] = None
    item_service_id: Annotated[str | None, Field(alias='itemServiceId', description='(Optional) The ListID or FullName of the Service Item used to charge for the work.')] = None
    duration: Annotated[str, Field(description='(Required) The duration of the work performed, formatted as an XML TimeIntervalType string (e.g., "PT8H0M0S" for 8 hours).')]
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with this time entry.')] = None
    payroll_item_wage_id: Annotated[str | None, Field(alias='payrollItemWageId', description='(Optional) The ListID or FullName of the Payroll Item Wage used to process payroll for this time.')] = None
    notes: Annotated[str | None, Field(description='(Optional) General notes about the time entry. Max 4095 chars.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) Status indicating if the time is billable (Billable, NotBillable, HasBeenBilled).')] = None
    is_billable: Annotated[bool | None, Field(alias='isBillable', description='(Optional) Legacy flag to set time as billable. Use BillableStatus instead if possible.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateTimeTrackingRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    entity_id: Annotated[str, Field(alias='entityId', description="(Required) The ListID or FullName of the Entity (Employee, Vendor, or OtherName) that performed the work.\nNote: This field is required even if you don't need to modify it, due to a quirk in the QBD SDK.\nYou must include the existing EntityId value if you don't want to change it.")]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job this time is for.')] = None
    item_service_id: Annotated[str | None, Field(alias='itemServiceId', description='(Optional) The ListID or FullName of the Service Item used to charge for the work.')] = None
    duration: Annotated[str, Field(description='(Required) The new duration of the work performed, formatted as an XML TimeIntervalType string (e.g., "PT8H0M0S" for 8 hours).')]
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with this time entry.')] = None
    payroll_item_wage_id: Annotated[str | None, Field(alias='payrollItemWageId', description='(Optional) The ListID or FullName of the Payroll Item Wage used to process payroll for this time.')] = None
    notes: Annotated[str | None, Field(description='(Optional) New general notes about the time entry. Max 4095 chars.')] = None
    billable_status: Annotated[str | None, Field(alias='billableStatus', description='(Optional) New status indicating if the time is billable (Billable, NotBillable, HasBeenBilled).')] = None
    is_billable: Annotated[bool | None, Field(alias='isBillable', description='(Optional) Legacy flag to set time as billable. Use BillableStatus instead if possible.')] = None
