from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, FixedAssetSalesInfo, QbdRef

class ItemFixedAsset(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    acquired_as: Annotated[str | None, Field(alias='acquiredAs', description='Indicates the condition of the asset at the time of acquisition (e.g., "New" or "Used").', examples=['New'])] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc', description='A description of the asset specifically related to its purchase.', examples=['Purchased from local dealership for logistics team'])] = None
    purchase_date: Annotated[date_aliased | None, Field(alias='purchaseDate', description='The date on which the business purchased or acquired the asset.', examples=['2018-05-12T00:00:00'])] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost', description='The date on which the business purchased or acquired the asset.', examples=['2018-05-12T00:00:00'])] = None
    vendor_or_payee_name: Annotated[str | None, Field(alias='vendorOrPayeeName', description='The original purchase price or cost of acquiring the asset.', examples=['35000.00'])] = None
    asset_account: Annotated[QbdRef | None, Field(alias='assetAccount', description="A reference to the specific Fixed Asset account in the Chart of Accounts used to track this asset's financial value.", examples=[{'ListId': '8000001A-1234567890', 'FullName': 'Fixed Assets: Vehicles'}])] = None
    sales_info: Annotated[FixedAssetSalesInfo | None, Field(alias='salesInfo')] = None
    asset_desc: Annotated[str | None, Field(alias='assetDesc', description='A general description of the fixed asset.', examples=['Company Delivery Van - North Region'])] = None
    location: Annotated[str | None, Field(description='The physical location or department where the asset is currently kept.', examples=['Warehouse A'])] = None
    po_number: Annotated[str | None, Field(alias='poNumber', description='The Purchase Order number associated with the acquisition of the asset.', examples=['PO-2018-405'])] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='The serial number or vehicle identification number (VIN) of the asset.', examples=['1FTNE04C49HA12345'])] = None
    warranty_exp_date: Annotated[date_aliased | None, Field(alias='warrantyExpDate', description="The date on which the manufacturer's or vendor's warranty for the asset expires.", examples=['2023-05-12T00:00:00'])] = None
    notes: Annotated[str | None, Field(description='Additional free-form notes or comments regarding the asset.', examples=['Minor scratch on passenger side door from 2020.'])] = None
    asset_number: Annotated[str | None, Field(alias='assetNumber', description='A unique, company-assigned tracking number or barcode number for the asset.', examples=['FA-1004'])] = None
    cost_basis: Annotated[float | None, Field(alias='costBasis', description='The cost basis of the asset used for calculating tax and depreciation (often includes purchase price plus freight, installation, etc.).', examples=['36500.00'])] = None
    year_end_accumulated_depreciation: Annotated[float | None, Field(alias='yearEndAccumulatedDepreciation', description='The total amount of depreciation accumulated for this asset up to the end of the most recent fiscal year.', examples=['18000.00'])] = None
    year_end_book_value: Annotated[float | None, Field(alias='yearEndBookValue', description='The net book value of the asset at the end of the fiscal year (typically Cost Basis minus Accumulated Depreciation).', examples=['18500.00'])] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseItemFixedAsset(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemFixedAsset] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemFixedAssetRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    acquired_as: Annotated[str | None, Field(alias='acquiredAs')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_date: Annotated[date_aliased | None, Field(alias='purchaseDate')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    vendor_or_payee_name: Annotated[str | None, Field(alias='vendorOrPayeeName')] = None
    asset_account_id: Annotated[str, Field(alias='assetAccountId')]
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    asset_description: Annotated[str | None, Field(alias='assetDescription')] = None
    location: str | None = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    warranty_expiration_date: Annotated[date_aliased | None, Field(alias='warrantyExpirationDate')] = None
    notes: str | None = None
    asset_number: Annotated[str | None, Field(alias='assetNumber')] = None
    cost_basis: Annotated[float | None, Field(alias='costBasis')] = None
    year_end_accumulated_depreciation: Annotated[float | None, Field(alias='yearEndAccumulatedDepreciation')] = None
    year_end_book_value: Annotated[float | None, Field(alias='yearEndBookValue')] = None
    externalid: str | None = None


class UpdateItemFixedAssetRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    acquired_as: Annotated[str | None, Field(alias='acquiredAs')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_date: Annotated[date_aliased | None, Field(alias='purchaseDate')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    vendor_or_payee_name: Annotated[str | None, Field(alias='vendorOrPayeeName')] = None
    asset_account_id: Annotated[str | None, Field(alias='assetAccountId')] = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    asset_description: Annotated[str | None, Field(alias='assetDescription')] = None
    location: str | None = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    warranty_expiration_date: Annotated[date_aliased | None, Field(alias='warrantyExpirationDate')] = None
    notes: str | None = None
    asset_number: Annotated[str | None, Field(alias='assetNumber')] = None
    cost_basis: Annotated[float | None, Field(alias='costBasis')] = None
    year_end_accumulated_depreciation: Annotated[float | None, Field(alias='yearEndAccumulatedDepreciation')] = None
    year_end_book_value: Annotated[float | None, Field(alias='yearEndBookValue')] = None
