from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, AddressRequest, CustomFields, QbdRef

class InventorySite(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    parent_site: Annotated[QbdRef | None, Field(alias='parentSite')] = None
    is_default_site: Annotated[bool | None, Field(alias='isDefaultSite')] = None
    site_desc: Annotated[str | None, Field(alias='siteDesc')] = None
    contact: str | None = None
    phone: str | None = None
    fax: str | None = None
    email: str | None = None
    site_address: Annotated[Address | None, Field(alias='siteAddress')] = None
    site_address_block: Annotated[AddressBlock | None, Field(alias='siteAddressBlock')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseInventorySite(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[InventorySite] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateInventorySiteRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    description: str | None = None
    contact: str | None = None
    phone: str | None = None
    fax: str | None = None
    email: str | None = None
    address: AddressRequest | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateInventorySiteRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    description: str | None = None
    contact: str | None = None
    phone: str | None = None
    fax: str | None = None
    email: str | None = None
    address: AddressRequest | None = None
