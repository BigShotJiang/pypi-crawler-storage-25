from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, ExpenseLines, ItemGroupLines, ItemLines, Lines, LinkedTransactions, QbdRef

class BuildAssembly(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the build.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    txn_number: Annotated[int | None, Field(alias='txnNumber', description='The internal transaction number.')] = None
    item_inventory_assembly: Annotated[QbdRef | None, Field(alias='itemInventoryAssembly', description='Reference to the Inventory Assembly Item being built.')] = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the built assembly.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the built assembly.')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber', description='(Optional) Expiration date for the serial/lot number.')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='Indicates if the build is pending.')] = None
    quantity_to_build: Annotated[float | None, Field(alias='quantityToBuild', description='(Required) The quantity of the assembly to build.')] = None
    quantity_can_build: Annotated[float | None, Field(alias='quantityCanBuild')] = None
    quantity_on_hand: Annotated[float | None, Field(alias='quantityOnHand')] = None
    quantity_on_sales_order: Annotated[float | None, Field(alias='quantityOnSalesOrder')] = None
    lines: Lines | None = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseBuildAssembly(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[BuildAssembly] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class ComponentItemLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item: Annotated[QbdRef | None, Field(description='The Inventory Assembly item being created.')] = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber')] = None
    description: str | None = None
    quantity_on_hand: Annotated[float | None, Field(alias='quantityOnHand')] = None
    quantity_needed: Annotated[float | None, Field(alias='quantityNeeded')] = None


class CreateBuildAssemblyRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    inventory_assembly_item_id: Annotated[str, Field(alias='inventoryAssemblyItemId')]
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site where the build takes place.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the specific location within the inventory site.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the built assembly.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the built assembly.')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the build.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    quantity_to_build: Annotated[float, Field(alias='quantityToBuild', description='(Required) The quantity of the assembly to build.')]
    mark_pending_if_required: Annotated[bool | None, Field(alias='markPendingIfRequired', description='(Optional) If true, marks the build as pending if there are insufficient component quantities.\nIf false (default), the request will fail if components are missing.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateBuildAssemblyRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the built assembly.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the built assembly.')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the build.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    quantity_to_build: Annotated[float | None, Field(alias='quantityToBuild', description='(Optional) The quantity of the assembly to build.')] = None
    mark_pending_if_required: Annotated[bool | None, Field(alias='markPendingIfRequired', description='(Optional) If true, marks the build as pending if there are insufficient component quantities.')] = None
    remove_pending: Annotated[bool | None, Field(alias='removePending', description='(Optional) If true, attempts to finalize a pending build.')] = None
