from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class CreditCardCredit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (Optional).')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description="Reference number for the transaction (Optional).\nMaxLength of 11 characters is based on QuickBooks Desktop's limit for RefNumber fields.")] = None
    memo: Annotated[str | None, Field(description='Memo for the transaction (Optional).')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates if tax is included in the line items.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode', description='Reference to the sales tax code.')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items for the credit card credit.\nAt least one expense line or item line is required.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the credit card credit (for inventory items).\nAt least one expense line or item line is required.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items for the credit card credit.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseCreditCardCredit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[CreditCardCredit] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCreditCardCreditRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str, Field(alias='accountId', description='Credit Card Account ListID (Required).')]
    payee_id: Annotated[str | None, Field(alias='payeeId', description='Payee Entity ListID (Vendor, Customer, etc.) (Required).')] = None
    def_macro: Annotated[str | None, Field(alias='defMacro', description='Macro name (Optional). Need to look into this before implementing.\nthis helps to SetCredit, can create an object, that is needed in order to\ncreate the initially reequested object')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description="Reference number for the transaction (Optional).\nMaxLength of 11 characters is based on QuickBooks Desktop's limit for RefNumber fields.")] = None
    memo: Annotated[str | None, Field(description='Memo for the transaction (Optional).')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates if tax is included in line items (Optional).\nOnly Qbd versions for UK and CA support this.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='Sales Tax Code ListID (Optional).')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (Optional).')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items for the credit card credit.\nAt least one expense line or item line is required.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the credit card credit (for inventory items).\nAt least one expense line or item line is required.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items for the credit card credit.')] = None


class UpdateCreditCardCreditRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    account_id: Annotated[str | None, Field(alias='accountId', description='Credit Card Account ListID (Optional for updates).')] = None
    payee_id: Annotated[str | None, Field(alias='payeeId', description='Payee Entity ListID (Optional for updates).')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the transaction (Optional).', max_length=11)] = None
    memo: Annotated[str | None, Field(description='Memo for the transaction (Optional).')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates if tax is included in line items (Optional).\nOnly Qbd versions for UK and CA support this.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='Sales Tax Code ListID (Optional).')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (Optional).')] = None
    clear_expense_lines: Annotated[bool | None, Field(alias='clearExpenseLines', description='Clear existing expense lines (Optional).')] = None
    clear_item_lines: Annotated[bool | None, Field(alias='clearItemLines', description='Clear existing item lines (Optional).')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items to update/replace (Optional for updates).')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items to update/replace (Optional for updates).')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items to update/replace (Optional for updates).')] = None
