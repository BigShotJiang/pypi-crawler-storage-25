from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, ApplyToTransactions, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class ApplyCheckToTransactionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    amount: Annotated[float | None, Field(description='The amount of the check to apply to this transaction.\n(Optional - if not specified, QuickBooks will apply the full check amount)')] = None


class Check(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate (for multi-currency)')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Check number (optional - QB can auto-generate)')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the check')] = None
    address: Annotated[Address | None, Field(description='Payee address (optional)')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='If true, the amount includes sales tax.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    is_void: Annotated[bool | None, Field(alias='isVoid')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense lines for the check (at least one line item required)')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item lines for the check')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group lines for the check')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseCheck(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Check] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCheckRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Check number (optional - QB can auto-generate)', max_length=11)] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    account_id: Annotated[str, Field(alias='accountId', description='Bank account to write check from (required)')]
    payee_id: Annotated[str, Field(alias='payeeId', description='Vendor/payee receiving the check (required)')]
    memo: Annotated[str | None, Field(description='Memo/description for the check', max_length=4095)] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='If true, the amount includes sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='The ListID or FullName of the sales tax code.')] = None
    address: Annotated[Address | None, Field(description='Payee address (optional)')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate (for multi-currency)')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense lines for the check (at least one line item required)')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item lines for the check')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group lines for the check')] = None
    apply_to_transactions: Annotated[ApplyToTransactions | None, Field(alias='applyToTransactions', description='Transactions to which this check is applied\nThe ARAccountRef will be obtained from the ExpenseLineAdd\nThe sum of the ApplyCheckToTxn amounts MUST equal the amount of the ExpenseLine\nAny transactions linked from a check in the ApplyToTxnAdd aggregate MUST use the same AR account specified in the ExpenseLineAdd AccountRef, which MUST be an ARAccount\nAny transactions linked from a check in the ApplyToTxnAdd aggregate must apply to the same entity referred to in the check PayeeEntityRef.')] = None


class UpdateCheckRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Check number', max_length=20)] = None
    traansaction_date: Annotated[date_aliased | None, Field(alias='traansactionDate')] = None
    account_id: Annotated[str | None, Field(alias='accountId', description='Bank account')] = None
    payee_id: Annotated[str | None, Field(alias='payeeId', description='Vendor/payee')] = None
    memo: Annotated[str | None, Field(description='Memo/description', max_length=4095)] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    address: Annotated[Address | None, Field(description='Payee address')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='If true, the amount includes sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='The ListID or FullName of the sales tax code.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate')] = None
    apply_to_transactions: Annotated[ApplyToTransactions | None, Field(alias='applyToTransactions', description='Transactions to which this check is applied (modifies existing links)')] = None
    clear_expense_lines: Annotated[bool | None, Field(alias='clearExpenseLines', description='Clear existing expense lines')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense lines (if provided, replaces existing lines)')] = None
    clear_item_lines: Annotated[bool | None, Field(alias='clearItemLines', description='Clear existing item lines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item lines (if provided, replaces existing lines)')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group lines (if provided, replaces existing lines)')] = None
