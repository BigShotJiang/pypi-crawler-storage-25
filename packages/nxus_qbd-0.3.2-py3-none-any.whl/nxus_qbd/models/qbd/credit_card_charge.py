from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class CreditCardCharge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber')] = None
    memo: str | None = None
    transaction_number: Annotated[str | None, Field(alias='transactionNumber')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseCreditCardCharge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[CreditCardCharge] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCreditCardRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str, Field(alias='accountId', description='(Required) The ListID or FullName of the Credit Card account.')]
    payee_id: Annotated[str | None, Field(alias='payeeId', description='(Optional) The ListID or FullName of the Payee (Vendor, Customer, Employee).')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the transaction.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction.')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the amount includes sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate, used for multi-currency.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='(Optional) A list of expense lines. You must provide ExpenseLines OR ItemLines/ItemGroupLines.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='(Optional) A list of item lines. You must provide ExpenseLines OR ItemLines/ItemGroupLines.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='(Optional) A list of item group lines. You must provide ExpenseLines OR ItemLines/ItemGroupLines.')] = None


class UpdateCreditCardRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    account_id: Annotated[str | None, Field(alias='accountId', description='(Optional) Change the Credit Card account used for the charge.')] = None
    payee_id: Annotated[str | None, Field(alias='payeeId', description='(Optional) Change the Payee (Vendor, Customer, Employee). Cannot be cleared.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) Modify or clear the reference number.')] = None
    memo: Annotated[str | None, Field(description='(Optional) Modify or clear the memo.')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the amount includes sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate, used for multi-currency.')] = None
    clear_expense_lines: Annotated[bool | None, Field(alias='clearExpenseLines', description='(Optional) Set to true to remove all existing expense lines.\nCannot be true if ClearItemLines is also true.')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='(Optional) A list of expense lines to modify.\nNote: To add new lines, use a line id of "-1". To modify existing lines, provide the current line id from QuickBooks.')] = None
    clear_item_lines: Annotated[bool | None, Field(alias='clearItemLines', description='(Optional) Set to true to remove all existing item lines.\nCannot be true if ClearExpenseLines is also true.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='(Optional) A list of item lines to modify.\nNote: To add new lines, use a line id of "-1". To modify existing lines, provide the current line id from QuickBooks.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='(Optional) A list of item group lines to modify.\nNote: To add new lines, use a line id of "-1". To modify existing lines, provide the current line id from QuickBooks.')] = None
