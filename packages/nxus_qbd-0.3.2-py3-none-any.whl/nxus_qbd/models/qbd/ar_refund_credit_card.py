from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, AddressRequest, CreditCardTransactionInfo, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef, RefundAppliedToTransactions, RefundAppliedToTxns

class ArRefundCreditCard(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for the transaction.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the refund.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    receivables_account: Annotated[QbdRef | None, Field(alias='receivablesAccount')] = None
    address: Annotated[Address | None, Field(description='(Optional) Address details for the refund.')] = None
    address_block: Annotated[AddressBlock | None, Field(alias='addressBlock')] = None
    payment_method: Annotated[QbdRef | None, Field(alias='paymentMethod')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    refund_applied_to_txns: Annotated[RefundAppliedToTxns | None, Field(alias='refundAppliedToTxns', description='(Required) List of credit transactions (e.g., Credit Memos) to apply this refund to.')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseArRefundCreditCard(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ArRefundCreditCard] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class RefundAppliedToTransactionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    refund_amount: Annotated[float, Field(alias='refundAmount', description='(Required) The amount of the refund applied to this specific transaction.')]


class CreateArRefundCreditCardRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    customer_id: Annotated[str, Field(alias='customerId', description='(Required) The ListID or FullName of the customer receiving the refund.')]
    refund_from_account_id: Annotated[str | None, Field(alias='refundFromAccountId', description='(Optional) The ListID or FullName of the account the refund is coming from.\nIn an ARRefundCreditCardAdd, the account which is the source of funds for the credit\ncard refund. Normally this is Undeposited Funds. However, you can specify another account\nif you wish. If you specify nothing here, Undeposited Funds is used by default.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the refund.')] = None
    address: Annotated[AddressRequest | None, Field(description='(Optional) Address details for the refund.')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='(Optional) The ListID or FullName of the payment method.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for the transaction.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    refund_applied_to_transactions: Annotated[list[RefundAppliedToTransactionRequest], Field(alias='refundAppliedToTransactions')]


class RefundAppliedToTransaction(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    transaction_type: Annotated[str | None, Field(alias='transactionType')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber')] = None
    credit_remaining: Annotated[float | None, Field(alias='creditRemaining')] = None
    refund_amount: Annotated[float | None, Field(alias='refundAmount', description='(Required) The amount of the refund applied to this specific transaction.')] = None
    credit_remaining_in_home_currency: Annotated[float | None, Field(alias='creditRemainingInHomeCurrency')] = None
    refund_amount_in_home_currency: Annotated[float | None, Field(alias='refundAmountInHomeCurrency')] = None


class UpdateArRefundCreditCardRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer receiving the refund.')] = None
    refund_from_account_id: Annotated[str | None, Field(alias='refundFromAccountId', description='(Optional) The ListID or FullName of the account the refund is coming from.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number for the refund.')] = None
    address: Annotated[AddressRequest | None, Field(description='(Optional) Address details for the refund.')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='(Optional) The ListID or FullName of the payment method.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for the transaction.')] = None
    refund_applied_to_transactions: Annotated[RefundAppliedToTransactions | None, Field(alias='refundAppliedToTransactions')] = None
