from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, QbdRef

class NullableAccountType(Enum):
    ACCOUNTS_PAYABLE = 'AccountsPayable'
    ACCOUNTS_RECEIVABLE = 'AccountsReceivable'
    BANK = 'Bank'
    COST_OF_GOODS_SOLD = 'CostOfGoodsSold'
    CREDIT_CARD = 'CreditCard'
    EQUITY = 'Equity'
    EXPENSE = 'Expense'
    FIXED_ASSET = 'FixedAsset'
    INCOME = 'Income'
    LONG_TERM_LIABILITY = 'LongTermLiability'
    NON_POSTING = 'NonPosting'
    OTHER_ASSET = 'OtherAsset'
    OTHER_CURRENT_ASSET = 'OtherCurrentAsset'
    OTHER_CURRENT_LIABILITY = 'OtherCurrentLiability'
    OTHER_EXPENSE = 'OtherExpense'
    OTHER_INCOME = 'OtherIncome'
    NONE_TYPE_NONE = None


class NullableCashFlowClassification(Enum):
    NONE = 'None'
    OPERATING = 'Operating'
    INVESTING = 'Investing'
    FINANCING = 'Financing'
    NOT_APPLICABLE = 'NotApplicable'
    NONE_TYPE_NONE = None


class NullableSpecialAccountType(Enum):
    ACCOUNTS_PAYABLE = 'AccountsPayable'
    ACCOUNTS_RECEIVABLE = 'AccountsReceivable'
    CONDENSE_ITEM_ADJUSTMENT_EXPENSES = 'CondenseItemAdjustmentExpenses'
    COST_OF_GOODS_SOLD = 'CostOfGoodsSold'
    DIRECT_DEPOSIT_LIABILITIES = 'DirectDepositLiabilities'
    ESTIMATES = 'Estimates'
    EXCHANGE_GAIN_LOSS = 'ExchangeGainLoss'
    INVENTORY_ASSETS = 'InventoryAssets'
    ITEM_RECEIPT_ACCOUNT = 'ItemReceiptAccount'
    OPENING_BALANCE_EQUITY = 'OpeningBalanceEquity'
    PAYROLL_EXPENSES = 'PayrollExpenses'
    PAYROLL_LIABILITIES = 'PayrollLiabilities'
    PETTY_CASH = 'PettyCash'
    PURCHASE_ORDERS = 'PurchaseOrders'
    RECONCILIATION_DIFFERENCES = 'ReconciliationDifferences'
    RETAINED_EARNINGS = 'RetainedEarnings'
    SALES_ORDERS = 'SalesOrders'
    SALES_TAX_PAYABLE = 'SalesTaxPayable'
    UNCATEGORIZED_EXPENSES = 'UncategorizedExpenses'
    UNCATEGORIZED_INCOME = 'UncategorizedIncome'
    UNDEPOSITED_FUNDS = 'UndepositedFunds'
    NONE_TYPE_NONE = None


class TaxLineInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    tax_line_id: Annotated[int, Field(alias='taxLineId')]
    tax_line_name: Annotated[str | None, Field(alias='taxLineName')] = None


class Account(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='Account name (required)')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    full_name: Annotated[str | None, Field(alias='fullName', description='The fully-qualified unique name for this object, formed by combining the names of its parent objects with its own `name`, separated by colons. Not case-sensitive. Parent:Child:SubChild', examples=['Bank:'])] = None
    parent: Annotated[QbdRef | None, Field(description='The short name of the account as it appears in the QuickBooks UI.', examples=['Checking'])] = None
    sublevel: Annotated[int | None, Field(description='Depth level of the account in the hierarchy (0 for top level).')] = None
    account_type: Annotated[NullableAccountType | None, Field(alias='accountType', description='The specific type of the account.')] = None
    special_account_type: Annotated[NullableSpecialAccountType | None, Field(alias='specialAccountType', description='Special sub-classification for the account.')] = None
    is_tax_account: Annotated[bool | None, Field(alias='isTaxAccount', description='Whether the account is a tax account (optional, default: false)\nOnly set to true for accounts that track tax liabilities/expenses')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber', description='Account number (optional)')] = None
    bank_number: Annotated[str | None, Field(alias='bankNumber', description='Bank account number (for bank accounts only)')] = None
    description: Annotated[str | None, Field(description="Description of the account. Maps to 'Desc' in XML.")] = None
    balance: float | None = None
    total_balance: Annotated[float | None, Field(alias='totalBalance')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode', description='Reference to the associated Sales Tax Code.\nDerived from SalesTaxCodeRef.')] = None
    tax_line_details: Annotated[TaxLineInfo | None, Field(alias='taxLineDetails')] = None
    cash_flow_classification: Annotated[NullableCashFlowClassification | None, Field(alias='cashFlowClassification', description='Cash flow classification for the account.')] = None
    currency: Annotated[QbdRef | None, Field(description='Reference to the currency associated with the account.\nDerived from CurrencyRef.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='Whether the account is active (default: true)')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class AccountType(Enum):
    ACCOUNTS_PAYABLE = 'AccountsPayable'
    ACCOUNTS_RECEIVABLE = 'AccountsReceivable'
    BANK = 'Bank'
    COST_OF_GOODS_SOLD = 'CostOfGoodsSold'
    CREDIT_CARD = 'CreditCard'
    EQUITY = 'Equity'
    EXPENSE = 'Expense'
    FIXED_ASSET = 'FixedAsset'
    INCOME = 'Income'
    LONG_TERM_LIABILITY = 'LongTermLiability'
    NON_POSTING = 'NonPosting'
    OTHER_ASSET = 'OtherAsset'
    OTHER_CURRENT_ASSET = 'OtherCurrentAsset'
    OTHER_CURRENT_LIABILITY = 'OtherCurrentLiability'
    OTHER_EXPENSE = 'OtherExpense'
    OTHER_INCOME = 'OtherIncome'


class BasePageResponseAccount(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Account] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateAccountRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='Account name (required)')]
    account_type: Annotated[AccountType, Field(alias='accountType', description='Account type (required)\nNOTE: Cannot create non_posting accounts via API - QuickBooks creates these internally')]
    account_number: Annotated[str | None, Field(alias='accountNumber', description='Account number (optional)')] = None
    description: Annotated[str | None, Field(description='Account description (optional)')] = None
    parent_id: Annotated[str | None, Field(alias='parentId', description='Parent account reference (for sub-accounts)')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='The default sales-tax code for transactions with this account, determining whether\nthe transactions are taxable or non-taxable. This can be overridden at the transaction or transaction-line level.\nDefault codes include "Non" (non-taxable) and "Tax" (taxable), but custom codes can also be created in QuickBooks.\nIf QuickBooks is not set up to charge sales tax(via the "Do You Charge Sales Tax?" preference), it will assign the\ndefault non-taxable code to all sales.')] = None
    tax_line_id: Annotated[str | None, Field(alias='taxLineId', description='The identifier of the tax line associated with this account. You can see a list of all available values for this\nfield by calling the endpoint for account tax lines.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description="The account's currency. For built-in currencies, the name and code are standard international values. For user-defined\ncurrencies, all values are editable.")] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='Whether the account is active (default: true)')] = None
    is_tax_account: Annotated[bool | None, Field(alias='isTaxAccount', description='Whether the account is a tax account (optional, default: false)\nOnly set to true for accounts that track tax liabilities/expenses')] = None
    open_balance: Annotated[float | None, Field(alias='openBalance', description='Opening balance for the account (optional)')] = None
    open_balance_date: Annotated[date_aliased | None, Field(alias='openBalanceDate', description='Opening balance date (optional, defaults to today)')] = None
    bank_number: Annotated[str | None, Field(alias='bankNumber', description='Bank account number (for bank accounts only)')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateAccountRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='Account name')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='Whether the account is active')] = None
    account_type: Annotated[NullableAccountType | None, Field(alias='accountType', description='Account type (optional)\nNOTE: Cannot create non_posting accounts via API - QuickBooks creates these internally')] = None
    is_tax_account: Annotated[bool | None, Field(alias='isTaxAccount', description='Whether the account is a tax account (optional)')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber', description='Account number (optional)')] = None
    description: Annotated[str | None, Field(description='Account description (optional)')] = None
    parent_id: Annotated[str | None, Field(alias='parentId', description='Parent account reference (optional, for sub-accounts)')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='The default sales-tax code for transactions with this account, determining whether\nthe transactions are taxable or non-taxable. This can be overridden at the transaction or transaction-line level.\nDefault codes include "Non" (non-taxable) and "Tax" (taxable), but custom codes can also be created in QuickBooks.\nIf QuickBooks is not set up to charge sales tax(via the "Do You Charge Sales Tax?" preference), it will assign the\ndefault non-taxable code to all sales. (Optional)')] = None
    open_balance: Annotated[float | None, Field(alias='openBalance', description='Opening balance for the account (optional)')] = None
    open_balance_date: Annotated[date_aliased | None, Field(alias='openBalanceDate', description='Opening balance date (optional, defaults to today)')] = None
    tax_line_id: Annotated[str | None, Field(alias='taxLineId', description='The identifier of the tax line associated with this account. You can see a list of all available values for this\nfield by calling the endpoint for account tax lines.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description="The account's currency. For built-in currencies, the name and code are standard international values. For user-defined\ncurrencies, all values are editable. (Optional)")] = None
    bank_number: Annotated[str | None, Field(alias='bankNumber', description='Bank account number (Optional, for bank accounts only)\n\n\n<i>**NOTE:** QuickBooks Desktop does not support cursor-based pagination for this resource.</i>')] = None
