from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LinkedTransactions, QbdRef

class VendorCredit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate', description='(Optional) The date of the transaction. Defaults to the current date.', examples=['2025-01-01'])] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate, if using multi-currency.', examples=['1.25'])] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., credit memo number from vendor). Max 20 chars.', examples=['REF12345'])] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction. Max 4095 chars.', examples=['Memo for the vendor credit'])] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    entity: Annotated[QbdRef | None, Field(description='Refers to the Vendor. Note: The base Entity is for PayeeEntityRef.')] = None
    vendor: Annotated[QbdRef | None, Field(description='Refers to the Vendor.')] = None
    account: Annotated[QbdRef | None, Field(description='Refers to the Payables Account. Note: The base Account is for PayeeAccountRef.')] = None
    payables_account: Annotated[QbdRef | None, Field(alias='payablesAccount')] = None
    credit_amount: Annotated[float | None, Field(alias='creditAmount', description='The total amount of the credit.')] = None
    credit_amount_in_home_currency: Annotated[float | None, Field(alias='creditAmountInHomeCurrency', description='Note: The base AmountInHomeCurrency is a string. This is a decimal.')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the amount includes sales tax.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    open_amount: Annotated[float | None, Field(alias='openAmount', description='The amount of this credit that has not yet been applied.')] = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='(Optional) A list of expense lines to add to the vendor credit.', examples=[[{'accountId': '10000001-1039043346', 'amount': 100.0, 'memo': 'Expense line memo'}]])] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='(Optional) A list of item lines to add to the vendor credit.\nNote: You can have either ItemLines or ItemGroupLines, but not both.', examples=[[{'itemId': '10000001-1039043346', 'quantity': 2, 'rate': 50.0, 'memo': 'Item line memo'}]])] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='(Optional) A list of item group lines to add to the vendor credit.\nNote: You can have either ItemLines or ItemGroupLines, but not both.', examples=[[{'itemGroupId': '10000001-1039043346', 'quantity': 1, 'rate': 200.0, 'memo': 'Item group line memo'}]])] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseVendorCredit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[VendorCredit] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateVendorCreditRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'])] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    transaction_date: Annotated[FlexibleDatetime | None, Field(alias='transactionDate', description='(Optional) The date of the transaction. Defaults to the current date.', examples=['2025-01-01'])] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., credit memo number from vendor). Max 20 chars.', examples=['REF12345'])] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction. Max 4095 chars.', examples=['Memo for the vendor credit'])] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the amount includes sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code for the transaction.', examples=['10000001-1039043346'])] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate, if using multi-currency.', examples=['1.25'])] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='(Optional) A list of expense lines to add to the vendor credit.', examples=[[{'accountId': '10000001-1039043346', 'amount': 100.0, 'memo': 'Expense line memo'}]])] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='(Optional) A list of item lines to add to the vendor credit.\nNote: You can have either ItemLines or ItemGroupLines, but not both.', examples=[[{'itemId': '10000001-1039043346', 'quantity': 2, 'rate': 50.0, 'memo': 'Item line memo'}]])] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='(Optional) A list of item group lines to add to the vendor credit.\nNote: You can have either ItemLines or ItemGroupLines, but not both.', examples=[[{'itemGroupId': '10000001-1039043346', 'quantity': 1, 'rate': 200.0, 'memo': 'Item group line memo'}]])] = None


class UpdateVendorCreditRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'])] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    transaction_date: Annotated[FlexibleDatetime | None, Field(alias='transactionDate', description='(Optional) The date of the transaction.', examples=['2026-01-01'])] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., credit memo number from vendor). Max 20 chars.', examples=['REF12345'])] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction. Max 4095 chars.', examples=['Payment for items.'])] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the amount includes sales tax.', examples=['true'])] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code for the transaction.', examples=['10000001-1039043346'])] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate, if using multi-currency.', examples=['1.25'])] = None
    clear_expense_lines: Annotated[bool | None, Field(alias='clearExpenseLines', description='(Optional) Set to true to remove all existing expense lines.', examples=['false'])] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='(Optional) A list of modifications for expense lines.', examples=[[{'lineId': '20000001-1234567890', 'accountId': '10000001-1039043346', 'amount': 100.0, 'memo': 'Updated expense line memo'}]])] = None
    clear_item_lines: Annotated[bool | None, Field(alias='clearItemLines', description='(Optional) Set to true to remove all existing item lines (items and item groups).', examples=['false'])] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='(Optional) A list of modifications for item lines.\nNote: You can have either ItemLines or ItemGroupLines, but not both.', examples=[[{'lineId': '30000001-1234567890', 'itemId': '10000001-1039043346', 'quantity': 2, 'rate': 50.0, 'memo': 'Updated item line memo'}]])] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='(Optional) A list of modifications for item group lines.\nNote: You can have either ItemLines or ItemGroupLines, but not both.', examples=[[{'lineId': '40000001-1234567890', 'itemGroupId': '10000001-1039043346', 'quantity': 1, 'rate': 200.0, 'memo': 'Updated item group line memo'}]])] = None
