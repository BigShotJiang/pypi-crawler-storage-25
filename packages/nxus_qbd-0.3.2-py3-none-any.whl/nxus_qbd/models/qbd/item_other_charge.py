from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, CustomFields, QbdRef
from .item_non_inventory import ItemNonInventorySalesAndPurchaseDetailsRequest, ItemNonInventorySalesOrPurchaseDetailsRequest

class ItemOtherCharge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType', description='Special item type designation.\nPossible values: FinanceCharge, ReimbursableExpenseGroup, ReimbursableExpenseSubtotal')] = None
    item_other_charge_description: Annotated[str | None, Field(alias='itemOtherChargeDescription')] = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account: QbdRef | None = None
    sales_desc: Annotated[str | None, Field(alias='salesDesc')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseItemOtherCharge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemOtherCharge] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class ItemOtherChargeSalesAndPurchaseDetailsRequest(ItemNonInventorySalesAndPurchaseDetailsRequest):
    pass


class ItemOtherChargeSalesOrPurchaseDetailsRequest(ItemNonInventorySalesOrPurchaseDetailsRequest):
    pass


class CreateItemOtherChargeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    barcode: BarCodeRequest | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    class_name: Annotated[str | None, Field(alias='className')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    parent_name: Annotated[str | None, Field(alias='parentName')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_or_purchase_details: Annotated[ItemOtherChargeSalesOrPurchaseDetailsRequest | None, Field(alias='salesOrPurchaseDetails')] = None
    sales_and_purchase_details: Annotated[ItemOtherChargeSalesAndPurchaseDetailsRequest | None, Field(alias='salesAndPurchaseDetails')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateItemOtherChargeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    barcode: BarCodeRequest | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_or_purchase_details: Annotated[ItemOtherChargeSalesOrPurchaseDetailsRequest | None, Field(alias='salesOrPurchaseDetails')] = None
    sales_and_purchase_details: Annotated[ItemOtherChargeSalesAndPurchaseDetailsRequest | None, Field(alias='salesAndPurchaseDetails')] = None
