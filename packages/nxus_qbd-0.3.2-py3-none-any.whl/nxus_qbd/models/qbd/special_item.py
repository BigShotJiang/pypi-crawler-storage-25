from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, CustomFields

class CreateSpecialItemRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    special_item_type: Annotated[str, Field(alias='specialItemType', description='(Required) The type of special item to create.\nValid values: "FinanceCharge", "ReimbursableExpenseGroup", "ReimbursableExpenseSubtotal"')]
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode', description='(Optional) Bar Code details for the special item.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class SpecialItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    special_item_type: Annotated[str | None, Field(alias='specialItemType', description='The type of special item: "FinanceCharge", "ReimbursableExpenseGroup", or "ReimbursableExpenseSubtotal".')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None
