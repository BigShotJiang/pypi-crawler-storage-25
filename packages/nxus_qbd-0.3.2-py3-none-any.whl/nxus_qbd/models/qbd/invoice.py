from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressRequest, ApplyCredits, CustomFields, ExpenseLines, ItemGroupLines, ItemLines, LineGroups, Lines, LinkedTransactions, QbdRef

class Invoice(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the invoice.')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the invoice.')] = None
    customer: Annotated[QbdRef | None, Field(description='The customer to whom the invoice is addressed.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class', description='Class Reference.')] = None
    receivables_account: Annotated[QbdRef | None, Field(alias='receivablesAccount')] = None
    template: Annotated[QbdRef | None, Field(description='Reference to the visual template (e.g., "Custom Invoice") used in QuickBooks.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='The date the invoice is due.')] = None
    billing_address: Annotated[Address | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[Address | None, Field(alias='shippingAddress')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending')] = None
    is_finance_charge: Annotated[bool | None, Field(alias='isFinanceCharge')] = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber')] = None
    terms: Annotated[QbdRef | None, Field(description='Reference to the payment terms (e.g., "Net 30") applied to this invoice.')] = None
    sales_representative: Annotated[QbdRef | None, Field(alias='salesRepresentative')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    shipping_date: Annotated[date_aliased | None, Field(alias='shippingDate')] = None
    shipping_method: Annotated[QbdRef | None, Field(alias='shippingMethod')] = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax')] = None
    customer_msg: Annotated[QbdRef | None, Field(alias='customerMsg')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    customer_sales_tax_code: Annotated[QbdRef | None, Field(alias='customerSalesTaxCode')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    subtotal: Annotated[float | None, Field(description="The total of all line items, before sales tax.\nThe 'Amount' property (from BaseTransactionDto) represents the grand total.")] = None
    sales_tax_total: Annotated[float | None, Field(alias='salesTaxTotal', description='The total amount of sales tax calculated for the invoice.')] = None
    balance_remaining: Annotated[float | None, Field(alias='balanceRemaining', description='The remaining balance to be paid.')] = None
    is_paid: Annotated[bool | None, Field(alias='isPaid', description='Indicates if the invoice has been paid in full.')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: Annotated[QbdRef | None, Field(description='The Accounts Receivable (A/R) account associated with this invoice.')] = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the invoice.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items for the invoice.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseInvoice(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Invoice] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateInvoiceRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    customer_id: Annotated[str, Field(alias='customerId', description='Customer ListID (required).')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='Class ListID.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='Template ListID.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the invoice.', max_length=11)] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending')] = None
    is_finance_charge: Annotated[bool | None, Field(alias='isFinanceCharge')] = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='Terms ListID.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='Due date for the invoice.')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    shipping_date: Annotated[date_aliased | None, Field(alias='shippingDate')] = None
    shipping_method_id: Annotated[str | None, Field(alias='shippingMethodId')] = None
    sales_tax_item_id: Annotated[str | None, Field(alias='salesTaxItemId')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the invoice.')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='Customer Sales Tax Code ListID.')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    link_to_transaction_ids: Annotated[list[str] | None, Field(alias='linkToTransactionIds')] = None
    apply_credits: Annotated[ApplyCredits | None, Field(alias='applyCredits')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None


class NullablePaidStatus(RootModel[int]):
    root: int


class UpdateInvoiceRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='Customer ListID (optional for updates).')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='Class ListID.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='Template ListID.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the invoice.', max_length=11)] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending')] = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='Terms ListID.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='Due date for the invoice.')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    shipping_date: Annotated[date_aliased | None, Field(alias='shippingDate')] = None
    shipping_method_id: Annotated[str | None, Field(alias='shippingMethodId')] = None
    sales_tax_item_id: Annotated[str | None, Field(alias='salesTaxItemId')] = None
    memo: Annotated[str | None, Field(description='Memo/description for the invoice.')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    apply_credits: Annotated[ApplyCredits | None, Field(alias='applyCredits')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
