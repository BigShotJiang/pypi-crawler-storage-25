from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields

class PaymentMethod(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the payment method.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    payment_method_type: Annotated[str | None, Field(alias='paymentMethodType', description='The type of payment method (e.g., "Cash", "Visa", "ECheck").')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the payment method is active.\nDefaults to true if not specified.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponsePaymentMethod(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[PaymentMethod] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreatePaymentMethodRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the payment method.', max_length=31)]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the payment method is active.\nDefaults to true if not specified.')] = None
    payment_method_type: Annotated[str | None, Field(alias='paymentMethodType', description='(Optional) The type of payment method.\nValid values: american_express, cash, check, debit_card, discover, e_check, gift_card, master_card, other, other_credit_card, visa.')] = None


class UpdatePaymentMethodRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    payment_method_type: Annotated[str | None, Field(alias='paymentMethodType', description='(Optional) The type of payment method.\nValid values: american_express, cash, check, debit_card, discover, e_check, gift_card, master_card, other, other_credit_card, visa.')] = None
    revision_number: Annotated[str, Field(alias='revisionNumber')]
