from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields

class CurrencyFormat(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    thousand_separator: Annotated[str | None, Field(alias='thousandSeparator', description='Controls the thousands separator when displaying currency values (for example, "1,000,000"). Defaults to comma.')] = None
    thousand_separator_grouping: Annotated[str | None, Field(alias='thousandSeparatorGrouping', description='Controls how digits are grouped for thousands when displaying currency values (for example, "10,000,000").')] = None
    decimal_places: Annotated[str | None, Field(alias='decimalPlaces', description='Controls the number of decimal places displayed for currency values. Use `0` to hide decimals or `2` to display cents.')] = None
    decimal_separator: Annotated[str | None, Field(alias='decimalSeparator', description='Controls the decimal separator when displaying currency values (for example, "1.00" vs "1,00"). Defaults to period.')] = None


class Currency(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the currency, displayed to the user. (Max 64 characters)')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    currency_code: Annotated[str | None, Field(alias='currencyCode', description='(Required) The three-letter currency code (e.g., USD, EUR). Values are normalized to trimmed uppercase. (Max 3 characters)')] = None
    currency_format: Annotated[CurrencyFormat | None, Field(alias='currencyFormat', description='(Optional) Specifies the formatting rules for the currency.')] = None
    is_user_defined_currency: Annotated[bool | None, Field(alias='isUserDefinedCurrency')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    as_of_date: Annotated[date_aliased | None, Field(alias='asOfDate')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Currency is inactive. Default is true.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseCurrency(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Currency] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CurrencyFormatRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    thousand_separator: Annotated[int | None, Field(alias='thousandSeparator', description='(Optional) Defines the separator for thousands place.\nValues: 0 for Comma [DEFAULT], 1 for Period, 2 for Space, 3 for Apostrophe.')] = None
    thousand_separator_grouping: Annotated[int | None, Field(alias='thousandSeparatorGrouping', description='(Optional) Defines the grouping pattern for thousands separator.\nValues: 0 for XX_XXX_XXX [DEFAULT], 1 for X_XX_XX_XXX.')] = None
    decimal_places: Annotated[int | None, Field(alias='decimalPlaces', description='(Optional) Defines the number of decimal places.\nValues: 0 for 0 decimal places, 2 for 2 decimal places [DEFAULT].')] = None
    decimal_separator: Annotated[int | None, Field(alias='decimalSeparator', description='(Optional) Defines the separator for the decimal place.\nValues: 0 for Period [DEFAULT], 1 for Comma.')] = None


class CreateCurrencyRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the currency, displayed to the user. (Max 64 characters)')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Currency is inactive. Default is true.')] = None
    currency_code: Annotated[str, Field(alias='currencyCode', description='(Required) The three-letter currency code (e.g., USD, EUR). Values are normalized to trimmed uppercase. (Max 3 characters)')]
    currency_format: Annotated[CurrencyFormatRequest | None, Field(alias='currencyFormat', description='(Optional) Specifies the formatting rules for the currency.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateCurrencyRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) The new name of the currency. Cannot be changed for built-in QuickBooks currencies. (Max 64 characters)')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Currency will be made inactive.')] = None
    currency_code: Annotated[str | None, Field(alias='currencyCode', description='(Optional) The three-letter currency code (e.g., USD, EUR). Values are normalized to trimmed uppercase. Cannot be changed for built-in QuickBooks currencies. (Max 3 characters)')] = None
    currency_format: Annotated[CurrencyFormatRequest | None, Field(alias='currencyFormat', description='(Optional) Specifies the formatting rules for the currency.')] = None
