from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields

class DateDrivenTerm(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    due_day_of_month: Annotated[int | None, Field(alias='dueDayOfMonth')] = None
    grace_period: Annotated[int | None, Field(alias='gracePeriod')] = None
    discount_day_of_month: Annotated[int | None, Field(alias='discountDayOfMonth', description='The day of the month within which payment must be received to qualify for the discount specified by `discountPercentage`.')] = None
    discount_percntage: Annotated[float | None, Field(alias='discountPercntage')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class BasePageResponseDateDrivenTerm(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[DateDrivenTerm] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateDateDrivenTermRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    due_day_of_month: Annotated[str | None, Field(alias='dueDayOfMonth')] = None
    grace_period: Annotated[str | None, Field(alias='gracePeriod')] = None
    discount_day_of_month: Annotated[str | None, Field(alias='discountDayOfMonth')] = None
    discount_percentage: Annotated[str | None, Field(alias='discountPercentage')] = None


class UpdateDateDrivenTermRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
