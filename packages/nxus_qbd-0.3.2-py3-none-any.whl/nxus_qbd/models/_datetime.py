"""Auto-generated support helpers. Do not edit by hand."""

from __future__ import annotations

from datetime import date, datetime, time
from typing import Annotated

from pydantic import BeforeValidator


def _coerce_flexible_datetime(value):
    if value is None or isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime.combine(value, time.min)
    if isinstance(value, str):
        normalized = value.replace('Z', '+00:00')
        return datetime.fromisoformat(normalized)
    return value


FlexibleDatetime = Annotated[datetime, BeforeValidator(_coerce_flexible_datetime)]

__all__ = ['FlexibleDatetime']
