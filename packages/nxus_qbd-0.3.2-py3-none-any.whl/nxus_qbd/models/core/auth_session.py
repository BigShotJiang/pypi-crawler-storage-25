from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime

class AuthSessionResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: Annotated[str, Field(description='Unique auth session identifier (e.g. `auth_sess_xR4kLm9p2vQ`)')]
    object_type: Annotated[str | None, Field(alias='objectType', description='Always `"auth_session"`')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt', description='UTC timestamp when this session was created')]
    connection_id: Annotated[str | None, Field(alias='connectionId', description='The connection ID this session was created for')] = None
    client_secret: Annotated[str | None, Field(alias='clientSecret', description='Opaque secret for server-side session identification.\nDo not share this with your users.')] = None
    auth_flow_url: Annotated[str | None, Field(alias='authFlowUrl', description='The URL to send your user to for QWC setup.\nEmbed this in an email, button, or redirect — the user clicks it,\nwalks through the setup wizard, and the connection activates.')] = None
    expires_at: Annotated[FlexibleDatetime | None, Field(alias='expiresAt', description='UTC timestamp when this session expires.\nDefaults to 30 minutes from creation. Extend with `linkExpiryMins`.')] = None
    redirect_url: Annotated[str | None, Field(alias='redirectUrl', description='The redirect URL included in the request, if any')] = None
    status: Annotated[str | None, Field(description='Session status: "pending", "in_progress", or "completed"')] = None


class CreateAuthSessionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    connection_id: Annotated[str | None, Field(alias='connectionId', description='The ID of the connection to initiate the auth setup for.')] = None
    redirect_url: Annotated[str | None, Field(alias='redirectUrl', description='Optional URL to redirect the user to after they complete the QWC setup page.', examples=['https://myapp.com/onboarding/complete'])] = None
    link_expiry_mins: Annotated[int | None, Field(alias='linkExpiryMins', description='How long the auth setup URL remains valid, in minutes.\nDefaults to 30 minutes if omitted. Maximum is 10,080 minutes (7 days).', examples=['60'])] = None
