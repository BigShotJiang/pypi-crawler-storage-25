from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime

class ConnectionStatus(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    connection_id: Annotated[UUID | None, Field(alias='connectionId')] = None
    is_connected: Annotated[bool | None, Field(alias='isConnected')] = None
    last_sync_at: Annotated[FlexibleDatetime | None, Field(alias='lastSyncAt')] = None
    company_name: Annotated[str | None, Field(alias='companyName')] = None
