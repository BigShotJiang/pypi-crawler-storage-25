from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime

class ConnectionModeRequest(RootModel[int]):
    root: Annotated[int, Field(description='The mode for a new connection. Determines billing tier and SOAP enforcement behaviour.')]


class ConnectionResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: Annotated[str, Field(description='Developer-facing connection ID in prefixed form, e.g. `conn_01965a3f2e7b7000b4c1d2e3f4a5b6c7`.')]
    object_type: Annotated[str | None, Field(alias='objectType', description='Constant resource discriminator.')] = None
    external_id: Annotated[str | None, Field(alias='externalId', description='Your own external identifier for the connection, if supplied.')] = None
    description: Annotated[str | None, Field(description='Human-friendly label for the connection.')] = None
    mode: Annotated[str | None, Field(description='Connection mode, either `development` or `production`.')] = None
    lifecycle_state: Annotated[str | None, Field(alias='lifecycleState', description='Lifecycle state, e.g. `active` or `archived`.')] = None
    restriction_reason: Annotated[str | None, Field(alias='restrictionReason', description='Restriction reason when access is limited by policy.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='True when the tenant may currently access the connection.')] = None
    is_archived: Annotated[bool | None, Field(alias='isArchived', description='True when the connection has been archived.')] = None
    is_operational: Annotated[bool | None, Field(alias='isOperational', description='True when the connection is usable for sync and API operations.')] = None
    requires_payment: Annotated[bool | None, Field(alias='requiresPayment', description='True when the connection requires billing completion before it can operate.')] = None
    billing_status: Annotated[str | None, Field(alias='billingStatus', description='Billing status for production connections.')] = None
    billing_url: Annotated[str | None, Field(alias='billingUrl', description='Hosted billing URL when payment is required.')] = None
    billing_checkout_endpoint: Annotated[str | None, Field(alias='billingCheckoutEndpoint', description='Relative API endpoint the client can call to start checkout.')] = None
    company_name: Annotated[str | None, Field(alias='companyName', description='Company name reported by QuickBooks.')] = None
    company_file: Annotated[str | None, Field(alias='companyFile', description='Company file path reported by QuickBooks.')] = None
    edition: Annotated[str | None, Field(description='QuickBooks edition, e.g. Pro or Enterprise.')] = None
    last_connected_at: Annotated[FlexibleDatetime | None, Field(alias='lastConnectedAt', description='Last observed QuickBooks connection timestamp.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt', description='When the connection record was created.')]
    updated_at: Annotated[FlexibleDatetime | None, Field(alias='updatedAt', description='When the connection record was last updated.')] = None


class CreateConnectionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    description: Annotated[str | None, Field(description='Optional display label for this connection, e.g. "Production - Acme Corp".\nDefaults to "QuickBooks Connection" if omitted.')] = None
    external_id: Annotated[str | None, Field(alias='externalId', description='Your own unique identifier for this connection — e.g. your customer ID, user ID,\nor any string meaningful in your system. Must be unique within your account.\nOnce set, you can use this value anywhere a connectionId is accepted.\nMax 255 characters.')] = None
    mode: Annotated[ConnectionModeRequest | None, Field(description='The operating mode for this connection.\n<list type="bullet"><item>**Development** (default) — free tier, requires QuickBooks Sample Company file.</item><item>**Production** — paid tier. The connection is created immediately, but it remains\nnon-operational until Stripe billing is completed. The response includes billing details.</item></list>')] = None


class UpdateConnectionRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    description: Annotated[str | None, Field(description='Update the display label')] = None
    external_id: Annotated[str | None, Field(alias='externalId', description='Update or set the external ID. Pass an empty string to clear it.\nMust be unique within your account.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='Enable or disable the connection')] = None
