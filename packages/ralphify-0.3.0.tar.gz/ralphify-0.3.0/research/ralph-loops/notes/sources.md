# Sources

## High Relevance

- https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents — Anthropic — Definitive guide to initializer/worker agent pattern with progress files and feature lists — **high**
- https://engineering.atspotify.com/2025/12/feedback-loops-background-coding-agents-part-3 — Spotify Engineering — Honk system: auto-activating verifiers, LLM-as-judge (25% veto rate), sandboxed containers — **high**
- https://github.com/karpathy/autoresearch — Andrej Karpathy — 630-line autonomous ML optimization loop, 3 primitives (editable asset, scalar metric, time-boxed cycle) — **high**
- https://engineering.fb.com/2026/03/17/developer-tools/ranking-engineer-agent-rea-autonomous-ai-system-accelerating-meta-ads-ranking-innovation/ — Meta Engineering — REA: hibernate-and-wake pattern for multi-week autonomous ML workflows, 5x productivity — **high**
- https://developers.openai.com/cookbook/examples/codex/long_horizon_tasks/ — OpenAI — Codex 25-hour sessions with 4-file durable memory system, 30K+ lines generated — **high**
- https://daviddaniel.tech/research/articles/autonomous-agents-loop/ — David Daniel — Research showing autonomous loops outperform interactive assistance; the $50K contract for $297 story — **high**
- https://github.com/strongdm/attractor/blob/main/coding-agent-loop-spec.md — StrongDM — Formal spec for coding agent loop: session management, event system, loop detection, steering injection — **high**
- https://beyond.addy.ie/2026-trends/ — Addy Osmani — 2026 trends: agent skills as packages, multi-agent fleet tools (Conductor, Gas Town, Vibe Kanban), Beads memory — **high**
- https://addyosmani.com/blog/self-improving-agents/ — Addy Osmani — Self-improving agents via AGENTS.md knowledge base, compound learning, planner-worker model — **high**
- https://news.ycombinator.com/item?id=46081704 — HN Discussion — Practitioner skepticism on multi-agent judges, "understanding can't be outsourced" insight — **high**
- https://www.humanlayer.dev/blog/skill-issue-harness-engineering-for-coding-agents — HumanLayer/Kyle — "The model is probably fine. It's just a skill issue." Context flooding, tool overload, auto-CLAUDE.md hurting performance 20%+ — **high**
- https://www.humanlayer.dev/blog/writing-a-good-claude-md — HumanLayer/Kyle — 150-200 instruction ceiling, <300 lines target, never auto-generate, progressive disclosure — **high**
- https://addyo.substack.com/p/the-80-problem-in-agentic-coding — Addy Osmani — Comprehension debt: "you understand less of your own codebase over time"; only 48% consistently review AI code — **high**
- https://simonwillison.net/guides/agentic-engineering-patterns/anti-patterns/ — Simon Willison — Cognitive debt vs technical debt, unreviewed PRs as #1 anti-pattern — **high**
- https://github.blog/ai-and-ml/github-copilot/how-to-write-a-great-agents-md-lessons-from-over-2500-repositories/ — GitHub Blog — Analysis of 2,500+ AGENTS.md files: six core areas, code examples > prose, three-tier boundaries — **high**
- https://news.ycombinator.com/item?id=43536868 — HN — Context window poisoning: once a mistake enters context, agents compound rather than self-correct — **high**
- https://news.ycombinator.com/item?id=47257212 — HN — Agentic engineering anti-patterns: treat agent output as first draft, equal review time — **high**
- https://codemanship.wordpress.com/2026/03/11/the-ai-ready-software-developer-21-stuck-in-a-doom-loop-drop-a-gear/ — Jason Gorman — Doom loops happen when tasks are out-of-distribution; fix by decomposing into simpler steps — **high**
- https://testdouble.com/insights/youre-holding-it-wrong-the-double-loop-model-for-agentic-coding — Test Double — Double loop model: Loop 1 (vibing/exploring) then Loop 2 (review/polish). Overly prescriptive prompts are counterproductive — **high**
- https://arxiv.org/abs/2603.05344 — Nghi D. Q. Bui — OPENDEV paper: doom-loop detection, adaptive context compaction, event-driven reminders against instruction fade — **high**
- https://github.com/uditgoenka/autoresearch — Udit Goenka — Autoresearch as Claude Code skill: 8 rules, verify/guard separation, crash recovery table — **high**
- https://github.com/davebcn87/pi-autoresearch — davebcn87 — MCP extension with statistical confidence scoring (MAD), checks vs metrics separation — **high**
- https://github.com/snarktank/ralph — snarktank — PRD-driven ralph: prd.json with acceptance criteria, progress.txt learning log, auto-archive — **high**
- https://block.github.io/goose/docs/tutorials/ralph-loop/ — Goose/Block — Worker/reviewer separation with file-based handoff (task.md, review-feedback.txt, review-result.txt) — **high**
- https://www.humanlayer.dev/blog/brief-history-of-ralph — HumanLayer — Origin of ralph loops (Geoff Huntley, July 2025), cascading specifications, "overbaking" emergent behavior — **high**

- https://ghuntley.com/ralph/ — Geoff Huntley — Agent-in-a-while-loop with specs, one-item-per-loop, subagent delegation, "sign erection" pattern — **high**
- https://github.com/humanlayer/advanced-context-engineering-for-coding-agents/blob/main/ace-fca.md — Dex Horthy / HumanLayer — Frequent intentional compaction via research/plan/implement workflow (517 HN pts) — **high**
- https://martinfowler.com/articles/exploring-gen-ai/context-engineering-coding-agents.html — Birgitta Bockeler / Thoughtworks — Taxonomy of context types and loading strategies for coding agents — **high**
- https://martinfowler.com/articles/exploring-gen-ai/humans-and-agents.html — Kief Morris / Thoughtworks — "On the loop" human position and the agentic flywheel pattern — **high**
- https://aicoding.leaflet.pub/3mbrvhyye4k2e — Chad Fowler — "Relocating Rigor": probabilistic inside, deterministic at edges — **high**
- https://mitchellh.com/writing/my-ai-adoption-journey — Mitchell Hashimoto — Six-step progression from chatbot to always-running harness-engineered agents — **high**
- https://openai.com/index/harness-engineering/ — OpenAI — Context engineering + architectural constraints + garbage collection agents — **high**
- https://testdouble.com/insights/pragmatic-approaches-to-agentic-coding-for-engineering-leaders — Test Double team — 17-author extension codifying the double loop for leadership adoption — **high**
- https://github.com/humanlayer/humanlayer/tree/main/.claude/commands/ — HumanLayer team — Real production research/plan/implement claude command files — **high**
- https://russpoldrack.substack.com/p/workflows-for-agentic-coding-and — Russ Poldrack — Specification-driven five-file workflow with custom Claude commands for phase transitions — **high**

## Medium Relevance

- https://muraco.ai/en/articles/harness-engineering-claude-code-codex/ — Muraco.ai — Harness engineering 101: 4 essential documents (design.md, task_checklist.md, session_handoff.md, AGENTS.md) — **medium**
- https://fortune.com/2026/03/17/andrej-karpathy-loop-autonomous-ai-agents-future/ — Fortune — Karpathy's vision: "emulate a research community" of collaborative agents — **medium**
- https://kingy.ai/ai/autoresearch-karpathys-minimal-agent-loop-for-autonomous-llm-experimentation/ — Kingy AI — Detailed autoresearch architecture: git-based state, results.tsv tracking — **medium**
- https://blogs.oracle.com/developers/what-is-the-ai-agent-loop-the-core-architecture-behind-autonomous-ai-systems — Oracle Developers — Overview of agent loop architecture: plan-execute-observe pattern — **medium**
- https://www.leanware.co/insights/ralph-wiggum-ai-coding — Leanware — Ralph Wiggum pattern history and implementation guide — **medium**
- https://linearb.io/blog/dex-horthy-humanlayer-rpi-methodology-ralph-loop — LinearB — RPI methodology, context isolation through dumb/smart model separation — **medium**
- https://github.com/Chachamaru127/claude-code-harness — GitHub — Plan→Work→Review autonomous cycle harness for Claude Code — **medium**
- https://venturebeat.com/technology/andrej-karpathys-new-open-source-autoresearch-lets-you-run-hundreds-of-ai — VentureBeat — Autoresearch release coverage with community results — **medium**
- https://news.ycombinator.com/item?id=42336553 — HN — The 70% problem: AI gets you 70% there, last 30% still requires real engineering — **medium**
- https://news.ycombinator.com/item?id=46312159 — HN — AI helps ship faster but produces 1.7x more bugs — **medium**
- https://news.ycombinator.com/item?id=44574465 — HN — METR study: AI tools made experienced devs 19% slower but they perceived themselves as faster — **medium**
- https://news.ycombinator.com/item?id=44632575 — HN — Replit agent deleted production database, fabricated data to cover it up — **medium**
- https://news.ycombinator.com/item?id=45005434 — HN — Agent in a while loop deployed multi-cloud Kubernetes nobody asked for — **medium**
- https://news.ycombinator.com/item?id=47006615 — HN — Breaking the spell of vibe coding: hallucinated bugs, dead-end architectures, code ownership loss — **medium**
- https://rocketedge.com/2026/03/15/your-ai-agent-bill-is-30x-higher-than-it-needs-to-be-the-6-tier-fix/ — RocketEdge — $47K LangChain incident, $47K data enrichment incident from unbounded agent autonomy — **medium**
- https://medium.com/@danielmanzke/burning-tokens-with-ai-coding-agents-3621f67c9776 — Daniel Manzke — 80% of tokens burned on last 20% of work — **medium**
- https://sankalp.bearblog.dev/my-experience-with-claude-code-20-and-how-to-get-better-at-using-coding-agents/ — Sankalp — Start compaction at 60% context, lossy sub-agent summaries, prompt erosion after 50+ tool calls — **medium**
- https://www.augmentcode.com/blog/how-to-build-your-agent-11-prompting-techniques-for-better-ai-agents — Augment Code — Models overfit to examples, frequent tool calling violations, context-first matters more than prompt tricks — **medium**
- https://news.ycombinator.com/item?id=44193056 — HN — "What do you put in claude.md?" — directory/index pattern, supporting docs, local overrides — **medium**
- https://news.ycombinator.com/item?id=46098838 — HN — Verification canaries, subdirectory CLAUDE.md files, bootstrap commands — **medium**
- https://github.com/Mizoreww/awesome-claude-code-config — Mizoreww — Self-improvement loop via lessons.md, adversarial cross-model review, 16-step statusline — **medium**
- https://freek.dev/3026-my-claude-code-setup — Freek Van der Herten — Anti-sycophancy instruction, skill delegation, whitelist permissions — **medium**
- https://www.morphllm.com/claude-md-examples — morphllm.com — Six domain-specific CLAUDE.md templates (minimal, monorepo, Next.js, ML, DevOps, hooks) — **medium**
- https://github.com/hesreallyhim/awesome-claude-code — hesreallyhim — 29.8k star curated list: skills, workflows, hooks, statuslines, alternative clients — **medium**
- https://composio.dev/blog/why-ai-agent-pilots-fail-2026-integration-roadmap — Composio — 85% per-action accuracy = 20% success for 10-step workflows — **medium**
- https://stackoverflow.blog/2025/12/29/developers-remain-willing-but-reluctant-to-use-ai-the-2025-developer-survey-results-are-here/ — Stack Overflow — 66% frustrated with "almost right" AI solutions, 45% say debugging AI code takes longer — **medium**

- https://itrevolution.com/articles/the-three-developer-loops-a-new-framework-for-ai-assisted-coding/ — Leah Brown / IT Revolution — Inner/middle/outer loop framework from Kim & Yegge's Vibe Coding book — **medium**
- https://www.bassimeledath.com/blog/levels-of-agentic-engineering — Bassim Eledath — 8 levels of agentic engineering; Level 5 = harness engineering — **medium**
- https://ranthebuilder.cloud/blog/agentic-ai-prompting-best-practices-for-smarter-vibe-coding — Ran Isenberg — Six-step prompting framework with plan-first exploration gate — **medium**
- https://agenticoding.ai/docs/methodology/lesson-3-high-level-methodology — agenticoding.ai — Research/Plan/Execute/Validate methodology with exploration vs. exact planning modes — **medium**
- https://www.youtube.com/watch?v=8rABwKRsec4 — Sean Grove (via Horthy) — "Specs are the new code" talk; committing prompts not just generated output — **medium**

- https://github.com/frankbria/ralph-claude-code — frankbria — 8,065-star ralph loop with intelligent exit detection, circuit breakers, rate limiting, 566 tests — **high**
- https://github.com/snwfdhmp/awesome-ralph — snwfdhmp — 806-star curated directory of 30+ ralph loop implementations, tutorials, podcasts — **high**
- https://github.com/VoltAgent/awesome-agent-skills — VoltAgent — 12,238-star collection of 500+ agent skills, cross-platform SKILL.md format — **high**
- https://www.infoq.com/news/2026/01/claude-code-creator-workflow/ — InfoQ — Boris Cherny runs 5+ parallel Claudes, plan-first, CLAUDE.md as living documentation — **high**
- https://earezki.com/ai-news/2026-03-02-i-built-an-mcp-server-so-my-ai-agent-can-track-its-own-spending/ — earezki — Agent Budget Guard MCP server: agents self-track spending, runtime circuit breaker — **high**
- https://github.com/auraguardhq/aura-guard — auraguardhq — Deterministic middleware for agent tool calls: ALLOW/CACHE/BLOCK/REWRITE/ESCALATE/FINALIZE, no LLM — **high**
- https://www.vibesparking.com/en/blog/ai/2026-02-14-bmad-ralph-execution-loop-claude-code/ — Vibe Sparking AI — BMAD+Ralph: structured planning phases + autonomous execution loop — **high**
- https://github.com/pentoai/ml-ralph — pentoai — Autonomous ML experiment loop agent, reached top-30 Kaggle Higgs Boson — **high**
- https://rocketedge.com/2026/03/15/your-ai-agent-bill-is-30x-higher-than-it-needs-to-be-the-6-tier-fix/ — RocketEdge — Six-tier cost control: per-request, per-task, per-day caps, alerts, routing, caching — **high**
- https://adamtuttle.codes/blog/2026/my-ralph-workflow-for-claude-code/ — Adam Tuttle — RALPH workflow: plan/ralph/ralph-install scripts, runs while AFK, progress.md log — **high**
- https://mariogiancini.com/ralph-loop-plugin-pattern-for-multiple-projects — Mario Giancini — Project-specific ralph configs for monorepos, per-project verification commands — **high**
- https://agent-wars.com/news/2026-03-16-how-one-developer-uses-multi-agent-llm-workflows-architect-developer-reviewers — Agent Wars — Stavros Korokithakis: multi-model diversity (Opus architect, Sonnet dev, Codex+Gemini reviewers) — **high**
- https://blog.lpains.net/posts/2026-01-31-real-world-example-ralph/ — LPains — Real-world production feature built with Ralph Wiggum Loop using GitHub Copilot CLI — **high**

- https://www.anthropic.com/research/measuring-agent-autonomy — Anthropic — Empirical study of trust accumulation: 20%→40% auto-approve over 750 sessions, turn duration doubling, experienced users interrupt more — **high**
- https://martinfowler.com/articles/pushing-ai-autonomy.html — Birgitta Bockeler / Thoughtworks — Autonomy complexity thresholds: 3-5 entity CRUD works, 10+ entities needs intervention, production not recommended. Overeagerness/brute-force have no known mitigation — **high**
- https://www.llmwatch.com/p/guided-autonomy-progressive-trust — Pascal Biese / LLM Watch — Trust Equation: Trust = (Competence × Consistency × Recoverability) / Consequence. 4-level trust ladder with graduation criteria — **high**
- https://about.gitlab.com/blog/building-trust-in-agentic-tools-what-we-learned-from-our-users/ — Erika Feldman, Will Leidheiser / GitLab — Trust as "micro-inflection points" — compound growth, single failure erases weeks. 13 participants across company sizes — **medium**
- https://www.swarmia.com/blog/five-levels-ai-agent-autonomy/ — Swarmia — 5 autonomy levels for coding agents. Higher is not always better — appropriate level depends on task — **medium**
- https://engineering.block.xyz/blog/testing-pyramid-for-ai-agents — Angie Jones / Block — 4-layer agent testing pyramid: deterministic → reproducible (record/playback) → probabilistic → vibes. Live LLM tests never in CI — **high**
- https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents — Anthropic — Three grader types (code/model/human), pass@k and pass^k metrics, rubric calibration against human judgment — **high**
- https://www.datadoghq.com/blog/ai/harness-first-agents/ — Datadog — Harness-first engineering with 5-layer verification pyramid (TLA+ to production telemetry). 87% memory reduction on redis-rust — **high**
- https://eugeneyan.com/writing/llm-evaluators/ — Eugene Yan — LLM-as-judge survey: GPT-4 85% agreement with humans, verbosity bias >90%, position bias up to 70%, PoLL outperforms single judge — **high**
- https://blog.langchain.com/the-anatomy-of-an-agent-harness/ — LangChain — Composable middleware architecture: Agent = Model + Harness. "Build your harness to be rippable" — **high**
- https://blog.langchain.com/improving-deep-agents-with-harness-engineering/ — LangChain — 52.8%→66.5% on Terminal Bench via harness changes alone. LoopDetectionMiddleware, ReasoningSandwich, PreCompletionChecklist — **high**
- https://redreamality.com/blog/ralph-wiggum-loop-vs-open-spec/ — Redreamality — Ralph vs Open Spec convergence into integrated ASDLC workflow. Specs define what; ralph provides execution — **high**
- https://asdlc.io/patterns/ralph-loop/ — ASDLC.io — Formalized Agentic SDLC with ralph loop as a pattern — **medium**
- https://github.com/tzachbon/smart-ralph — tzachbon — Spec-driven development with smart compaction for Claude Code — **medium**
- https://github.com/merllinsbeard/speckit-ralph — merllinsbeard — Execution engine for Spec Kit workflows with ralph loop — **medium**
- https://cloudsecurityalliance.org/blog/2026/02/02/the-agentic-trust-framework-zero-trust-governance-for-ai-agents — CSA — Agentic Trust Framework: 4 maturity levels with 5 promotion gates — **medium**

- https://evaldriven.org/ — Grey Newell — 10-principle EDD manifesto: "evaluation is the product," evals in CI on every change — **high**
- https://www.braintrust.dev/articles/eval-driven-development — Braintrust — Three-phase EDD methodology: define evals as specs, optimize against evals, refine from production traces — **high**
- https://vercel.com/blog/eval-driven-development-build-better-ai-faster — Malte Ubl, Alice Moore, Ido Pesok / Vercel — Vercel iterates on v0 prompts "almost daily" using Braintrust. All PRs impacting output include eval results — **high**
- https://fireworks.ai/blog/eval-driven-development-with-claude-code — Fireworks AI — Concrete EDD workflow: 4→32 test cases, 0.6 threshold, MCP server integration — **high**
- https://arize.com/blog/claude-md-best-practices-learned-from-optimizing-claude-code-with-prompt-learning/ — Priyan Jindal / Arize AI — RL-inspired prompt learning optimized CLAUDE.md for +5.19% cross-repo, +10.87% single-repo on SWE-bench. Pure system prompt optimization — **high**
- https://blog.mgechev.com/2026/02/26/skill-eval/ — Minko Gechev — TypeScript framework for unit-testing agent skills: Docker containers, deterministic+LLM graders, pass@k vs pass^k metrics — **high**
- https://langwatch.ai/scenario/best-practices/the-vibe-eval-loop/ — @_rchaves_ — Merges "vibe checking" with systematic evals: explore→write scenario test→confirm fail→fix→verify pass — **high**
- https://news.ycombinator.com/item?id=47319587 — HN — "How are people doing AI evals these days?" — highly heterogeneous, no gold standard, tools: Langfuse/Braintrust/Promptfoo/DeepEval — **high**
- https://news.ycombinator.com/item?id=47145438 — HN — "Your lack of Evals is the problem" — ad-hoc iteration on AGENTS.md, tools: Tessl.io, ai-evals.io — **medium**
- https://news.ycombinator.com/item?id=46809708 — HN — AGENTS.md outperforms skills in Vercel evals (always-in-prompt vs invoked-on-demand), sample size concerns — **medium**

- https://www.philschmid.de/agent-harness-2026 — Phil Schmid / Hugging Face — "Build to Delete" framework for rippable harnesses, the Bitter Lesson applied to agent harness design — **high**
- https://ghuntley.com/loop/ — Geoffrey Huntley — "Everything is a Ralph Loop": forward/reverse/loop modes, Loom (Level 9 evolutionary software), push-to-master with no branches — **high**
- https://www.nxcode.io/resources/news/harness-engineering-complete-guide-ai-agent-codex-2026 — NxCode — Comprehensive harness engineering guide: entropy management, agent-specific code review, multi-provider harness design — **high**
- https://www.alibabacloud.com/blog/from-react-to-ralph-loop-a-continuous-iteration-paradigm-for-ai-agents_602799 — Alibaba Cloud — ReAct vs Ralph Loop architectural comparison: external verification beats self-assessment, completion promises, stop hooks — **high**
- https://www.verdent.ai/guides/ralph-tui-ai-agent-dashboard — Verdent — Ralph TUI: first dedicated agent loop dashboard, tracks completion rate/stuck detection/cost per feature, session state persistence — **high**
- https://paddo.dev/blog/ralph-wiggum-autonomous-loops/ — Paddo.dev — Practical ralph loop guide: high-success use cases (migrations, test coverage, scaffolding), anti-patterns (ambiguous requirements, security code), 3-month compiler story — **high**
- https://linearb.io/dev-interrupted/podcast/inventing-the-ralph-wiggum-loop — Dev Interrupted / LinearB — Geoffrey Huntley podcast: Loom/Gas Town, Level 9 evolutionary software, agents push to master with 30-second deploys — **high**
- https://www.infoq.com/news/2026/02/openai-harness-engineering-codex/ — InfoQ — OpenAI harness engineering: 1M+ lines with zero hand-written code, three pillars (context engineering, architectural constraints, entropy management), Friday cleanup → automated GC agents — **high**

- https://www.anthropic.com/engineering/advanced-tool-use — Anthropic — Tool Search + Programmatic Tool Calling: 85% token reduction, 13-point accuracy improvement, dynamic tool loading GA Feb 2026 — **high**
- https://hackteam.io/blog/tool-calling-is-broken-without-mcp-server-composition/ — Roy Derks / Hackteam — 4 MCP composition patterns: client-side, virtual server, dynamic selection, programmatic execution — **high**
- https://a16z.com/a-deep-dive-into-mcp-and-the-future-of-ai-tooling/ — a16z — MCP architecture deep dive: agent-centric execution model vs LSP reactive model, 97M monthly downloads — **high**
- https://www.speakeasy.com/mcp/tool-design/dynamic-tool-discovery — Speakeasy — Search-Describe-Execute pattern: 160x token reduction, 100% success rate across 40-400 tools — **high**
- https://www.docker.com/blog/dynamic-mcps-stop-hardcoding-your-agents-world/ — Docker — Dynamic MCPs: agents discover, configure, and compose tools at runtime in sandbox — **high**
- https://github.com/snagasuri/deebo-prototype — Sriram Nagasuri — Deebo: autonomous debugging MCP server, parallel git branches for hypothesis testing — **high**
- https://codspeed.io/changelog/2026-03-16-mcp-server — CodSpeed — Performance engineering MCP: flamegraphs, benchmark comparison, optimize-measure-repeat loops — **high**
- https://github.com/upstash/context7 — Upstash — Context7 MCP: live docs for 9K+ libraries, eliminates hallucinated APIs — **high**
- https://news.ycombinator.com/item?id=47207442 — HN — Hive Memory: cross-project persistent memory for coding agents, ~/.cortex/ storage — **medium**
- https://news.ycombinator.com/item?id=46692102 — HN — Mother MCP: auto-detect tech stack, install modular ~500-token skills, 25+ skill registries — **medium**
- https://www.bannerbear.com/blog/8-best-mcp-servers-for-claude-code-developers-in-2026/ — Bannerbear — Curated MCP server list for Claude Code developers — **medium**
- https://github.com/alfredolopez80/multi-agent-ralph-loop — alfredolopez80 — Multi-agent ralph loop with 13 MCP servers, specialized sub-agents (coder/reviewer/tester/researcher) — **high**
- https://news.ycombinator.com/item?id=44678426 — HN — "What is so good about MCP servers?" — practitioner debate: productivity gains vs reliability concerns, cargo-culting criticism — **medium**
- https://blog.modelcontextprotocol.io/posts/2026-mcp-roadmap/ — MCP team — 2026 roadmap: transport scalability, Tasks primitive, governance, enterprise readiness — **medium**
- https://www.truefoundry.com/blog/best-mcp-gateways — TrueFoundry — MCP gateway comparison: Composio, TrueFoundry, Portkey — **medium**

- https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents — Anthropic — Context as finite resource, just-in-time retrieval, sub-agent architectures, tool design for minimal context — **high**
- https://www.philschmid.de/context-engineering-part-2 — Phil Schmid — Context compaction vs summarization hierarchy, hierarchical action spaces, agent-as-tool MapReduce, Manus 5x rewrites — **high**
- https://www.epsilla.com/blogs/2026-03-12-harness-engineering — Epsilla — "LLM is CPU, harness is OS", functional correctness gap (intent-failure detection), greater autonomy demands tighter constraints, 30-60-90 roadmap — **high**
- https://earezki.com/ai-news/2026-03-15-harness-engineering-why-the-model-is-a-commodity-and-the-infrastructure-is-your-moat/ — earezki — Evolve control plane (5-layer harness), closed knowledge loop from JSONL logs, infrastructure as competitive moat — **high**
- https://www.infoq.com/news/2026/03/opus-4-6-context-compaction/ — InfoQ — Opus 4.6 context compaction: 76% vs 18.5% on MRCR v2 at 1M tokens, adaptive thinking effort controls — **high**
- https://jvaneyck.wordpress.com/2026/02/22/guardrails-for-agentic-coding-how-to-move-up-the-ladder-without-lowering-your-bar/ — Van Eyck — 6 guardrails (CI, domain types, deterministic tools, arch tests, scenario tests, scanners), hooks as superpower, XP rediscovered — **high**
- https://getbeam.dev/blog/anthropic-agentic-coding-trends-2026.html — Beam/Anthropic — 78% multi-file edits, 23-min sessions, 47 tool calls/session, 40% fewer errors with arch docs, 8 trends — **high**
- https://dev.to/alexandergekov/2026-the-year-of-the-ralph-loop-agent-1gkj — Alexander Gekov — Ralph loop overview: token management signals, guardrails/signs pattern, concrete use cases, Fruit Ninja example — **high**
- https://antran.app/blogs/2026/ralph_wiggum/ — An Tran — Ralph loop implementations (bash, stop-hook, orchestrator, ralphy), prompt structure patterns, when loops fail — **high**
- https://github.com/vercel-labs/ralph-loop-agent — Vercel Labs — Two-tier loop (inner tool calls, outer verification), composable stop conditions, feedback injection from verify — **high**
- https://github.com/iannuttall/ralph — iannuttall — Minimal file-based agent loop, PRD JSON state, STALE_SECONDS auto-reopen, multi-agent support — **medium**
- https://www.mindstudio.ai/blog/context-rot-ai-coding-agents-explained — MindStudio — Context rot symptoms (repeated suggestions, hallucinated APIs, scope drift), degradation after 20-30 exchanges — **high**
- https://news.ycombinator.com/item?id=47000034 — HN — Quadratic cost curve: cached input tokens dominate by 50K tokens, tool call chains multiply costs unpredictably — **high**
- https://news.ycombinator.com/item?id=47378792 — HN — Autonomous coding agents astroturfing: skepticism on claims, disconnect between hype and usage, financial incentives — **medium**
- https://news.ycombinator.com/item?id=46737630 — HN — Codex agent loop internals: encrypted compaction, reasoning token lifecycle, skills as JIT context — **high**
- https://openai.com/index/unrolling-the-codex-agent-loop/ — OpenAI — Codex loop internals: call-tool-append-repeat, /responses/compact endpoint, encrypted latent-space compaction — **high**

- https://cursor.com/blog/scaling-agents — Cursor — Planner-worker-judge architecture, 1M+ lines, hundreds of concurrent agents, role-based pipeline evolution — **high**
- https://mikemason.ca/writing/ai-coding-agents-jan-2026/ — Mike Mason — 8-13% real productivity gains (Thoughtworks), GitClear code quality data, Cursor Browser scrutiny, production anti-patterns — **high**
- https://www.augmentcode.com/guides/how-to-run-a-multi-agent-coding-workspace — Augment Code — 6 coordination patterns, worktree isolation, failure taxonomy, sequential merge — **high**
- https://dev.to/meridian-ai/the-loop-as-laboratory-what-3190-cycles-of-autonomous-ai-operation-reveal-23je — Meridian AI — 3,190 cycles over 30 days, 9 sub-agents, identity persistence, 110+ hour session — **high**
- https://matrixtrak.com/blog/agents-loop-forever-how-to-stop — MatrixTrak — Loop fingerprint detection, error classification matrix, stopping conditions, logging schema — **high**
- https://writing.alteredcraft.com/p/the-ralph-wiggum-agent-loop-is-really — Sam Keen — Ralph loop as engineering discipline, spec-driven development, validation gates — **high**
- https://earezki.com/ai-news/2026-03-19-the-inception-loop-a-month-in-the-life-of-a-self-improving-ai-sidekick/ — earezki — Inception loop: self-improving AI agent, autonomous PR submission, 12-hour maintenance cycles — **medium**
- https://www.braintrust.dev/articles/best-ai-agent-observability-tools-2026 — Braintrust — Top 5 agent observability platforms: Braintrust, Helicone, Galileo, Fiddler, Vellum — **medium**
- https://news.ycombinator.com/item?id=46651646 — HN — Controller-enforced alternative to agent-driven ralph loops, tests as sole acceptance gate — **medium**
- https://ralphable.com/blog/ralph-loop-methodology — Ralphable — 75+ ralph loop examples across coding, writing, analysis — **medium**
- https://docs.bswen.com/blog/2026-03-21-git-worktrees-parallel-claude-code/ — BSWEN — Git worktrees for parallel Claude Code agents, practical setup guide — **medium**

- https://codescene.com/blog/agentic-ai-coding-best-practice-patterns-for-speed-with-quality — CodeScene — Code Health 9.5+ threshold for optimal AI agent performance, 2-3x speedup, multi-level safeguarding, "speed amplifies both good and bad decisions" — **high**
- https://missing.csail.mit.edu/2026/agentic-coding/ — MIT Missing Semester — Academic curriculum on agentic coding: "intern not subordinate" mental model, /llms.txt standard, subagent delegation, 200-line agent architecture — **medium**
- https://github.com/swarm-cli — swarm-cli — DAG pipeline orchestration for ralph loops: planner→implementer→reviewer as continuous pipeline, Docker-like CLI — **medium**

- https://dev.to/boucle2026/how-to-tell-if-your-ai-agent-is-stuck-with-real-data-from-220-loops-4d4h — Boucle — Empirical analysis of 220 agent loops: 55% productive/45% problematic, 6 signal types, 13.3x feedback amplification, 50% remediation effectiveness — **high**
- https://dev.to/singhdevhub/how-we-prevent-ai-agents-drift-code-slop-generation-2eb7 — SinghDevHub (CRED) — 8 interconnected safeguards from production: dual-threshold circuit breakers, structured output contracts, explicit termination tools, AI-reviewing-AI — **high**
- https://understandingdata.com/posts/checkpoint-commit-patterns/ — James Phoenix — 4 git checkpoint patterns for AI-assisted development: Validation Gate, Incremental Checkpoint, Safety Bracket, End-of-Session Commit — **high**
- https://www.microsoft.com/en-us/research/blog/systematic-debugging-for-ai-agents-introducing-the-agentrx-framework/ — Microsoft Research (Barke et al.) — AgentRx: 4-stage debugging pipeline, 9-category failure taxonomy, +23.6% failure localization, 115 annotated trajectories — **high**
- https://www.nickwinder.com/blog/trace-driven-development-langsmith-claude-code — Nick Winder — Trace-driven development: LangSmith MCP + Claude Code for autonomous fix proposals, "days to minutes" fix time — **high**
- https://dev.to/tumf/ralph-claude-code-the-technology-to-stop-ai-agents-how-the-circuit-breaker-pattern-prevents-3di4 — tumf — Circuit breaker implementation: 3 states, concrete thresholds (3/5/70%), two-stage error filtering, $10.50/hour per agent — **high**
- https://earezki.com/ai-news/2026-02-23-does-ai-have-a-hero-gene/ — Evangelos Letsos (Andromeda) — Emergent cross-agent recovery: backend agent autonomously diagnosed and fixed frontend agent's config error, peer review by third agent — **high**
- https://promptengineering.org/agents-at-work-the-2026-playbook-for-building-reliable-agentic-workflows/ — Sunil Ramlochan — 5-stage production agent loop, structured outputs for 100% schema compliance, immutable audit logs, least-privilege design — **high**
- https://markaicode.com/fix-ai-agent-looping-autonomous-coding/ — Mark (Markaicode) — 5 anti-looping techniques with code: action history tracking, result-based detection, reflection prompts, circuit breakers, escalation protocol — **medium**
- https://tech.eu/2026/03/17/agent-debugging-startup-laminar-raises-3m-seed-to-tackle-the-observability-gap-in-ai-agents/ — Laminar — Agent Debugger: replay from any step, AI-powered failure pattern detection, browser session recording synced with traces — **medium**
- https://opentelemetry.io/blog/2025/ai-agent-observability/ — OpenTelemetry (IBM/Google) — Standardized semantic conventions for AI agent observability across CrewAI, AutoGen, LangGraph — **medium**
- https://www.gocodeo.com/post/error-recovery-and-fallback-strategies-in-ai-agent-development — GoCodeo — Progressive failure response: self-correct → fallback → graceful degradation → human escalation, error type classification — **medium**

- https://adamtuttle.codes/blog/2026/my-ralph-workflow-for-claude-code/ — Adam Tuttle — PRD-driven loop with permission gating, $100/hr cost data, completion promises, progress tracking — **high**
- https://deepwiki.com/FlorianBruniaux/claude-code-ultimate-guide/7.3-fresh-context-pattern-(ralph-loop) — Florian Bruniaux — TDD loop pattern, PostToolUse hooks, OpusPlan hybrid cost optimization, iteration limits — **high**
- https://github.com/github/awesome-copilot/blob/main/cookbook/copilot-sdk/nodejs/ralph-loop.md — GitHub — Two-phase plan-then-build, IMPLEMENTATION_PLAN.md as coordination artifact, 60-line AGENTS.md guidance — **high**
- https://grahammann.net/blog/how-im-vibe-coding-2026 — Graham Mann — Multi-model orchestration (Opus builder, others as reviewers), parallel conversation threads, minimal prompting — **medium**
- https://asdlc.io/patterns/ralph-loop/ — ASDLC.io — Completion promise formalization, convergence formula P(C) = 1-(1-p)^n, anti-pattern warnings for vague prompts — **medium**
- https://popularaitools.ai/claude-code-loops-skills-guide/ — Popular AI Tools — Claude Code /loop command (time-based), max 50 concurrent tasks, complementary to iteration-based loops — **low**

- https://developers.openai.com/cookbook/examples/partners/self_evolving_agents/autonomous_agent_retraining — OpenAI + Weco — Canonical meta-loop: execute → evaluate → metaprompt → redeploy, 75% pass threshold for promotion — **high**
- https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents — Anthropic — Swiss Cheese Model for layered evals, 8-step roadmap, eval saturation detection — **high**
- https://www.philschmid.de/agents-pass-at-k-pass-power-k — Phil Schmid — Definitive pass@k vs pass^k analysis: 70% success = 97% pass@3 but 34% pass^3 — **high**
- https://simmering.dev/blog/agent-benchmarks/ — Paul Simmering — The Reliability Gap: 3-tier enterprise readiness model based on pass^k degradation, "meltdown" spiraling — **high**
- https://www.weco.ai/ — Weco AI — Tree-search engine for autonomous prompt/code optimization given an eval script — **high**
- https://arize.com/blog/optimizing-coding-agent-rules-claude-md-agents-md-clinerules-cursor-rules-for-improved-accuracy/ — Arize AI — PromptLearning for CLAUDE.md: +6% SWE-bench accuracy, 20-50 rule rulesets — **high**
- https://arxiv.org/abs/2504.04365 — IBM Research — AutoPDL: AutoML over prompting patterns, up to 67.5pp accuracy gains — **high**
- https://www.evidentlyai.com/blog/automated-prompt-optimization — Evidently AI — Mistake-driven prompt optimization with train/val/test splits and early stopping — **medium**
- https://github.blog/ai-and-ml/automate-repository-tasks-with-github-agentic-workflows/ — GitHub — Agentic Workflows: Markdown+YAML frontmatter compiled to Actions, "Continuous AI" — **high**
- https://code.claude.com/docs/en/github-actions — Anthropic — Claude Code GitHub Action: cron schedules, @claude mentions, issue assignments — **high**
- https://developers.openai.com/codex/github-action — OpenAI — Codex GitHub Action: scheduled execution, future "automation cloud" — **high**
- https://devops.com/cursor-cloud-agents-get-their-own-computers-and-35-of-internal-prs-to-prove-it/ — DevOps.com — 35% of Cursor internal PRs by cloud agents, each gets own VM, 99.9% reliability — **high**
- https://openai.com/index/introducing-codex/ — OpenAI — Codex cloud sandbox: two-phase runtime (network setup → offline agent), secrets removed before agent — **high**
- https://earezki.com/ai-news/2026-03-12-how-to-schedule-ai-agent-tasks-with-cron-the-missing-guide/ — earezki — Production cron: 23 concurrent jobs, SQLite+WAL, daily schedule pattern — **high**
- https://blog.geta.team/how-we-built-a-cron-scheduler-for-ai-agents-at-scale/ — Geta Team — Centralized scheduler for 100+ agents, ~200 lines JS, hot config reload — **high**
- https://code.claude.com/docs/en/agent-teams — Anthropic — Agent Teams: 3-5 teammates, independent context windows, direct communication — **high**
- https://benjamincrozat.com/agents-md — Benjamin Crozat — AGENTS.md as cross-tool standard, works across Claude/Cursor/Codex — **medium**
- https://www.promptfoo.dev/docs/guides/evaluate-coding-agents/ — Promptfoo/OpenAI — Agent eval: trajectory tracing, cost assertions, Claude/Codex SDK support — **high**
- https://docs.langchain.com/langsmith/cicd-pipeline-example — LangChain — Full CI/CD pipeline with quality-gated production releases — **high**
- https://www.braintrust.dev/articles/eval-driven-development — Braintrust — EDD methodology: define → optimize → refine, regression gates, CI/CD integration — **high**
- https://foundercollective.com/blog/eval-driven-development/ — Founder Collective — Evals as "top-level abstraction in the AI stack", Weco exemplar — **medium**
- https://www.braintrust.dev/articles/best-ai-observability-tools-2026 — Braintrust — 2026 AI observability buyer's guide: Braintrust, Langfuse, Helicone, Galileo, Datadog — **medium**
- https://galileo.ai/blog/best-agent-monitoring-tools-production — Galileo — Agent monitoring: graph tracing, per-step eval, tool usage, latency/cost tracking — **medium**
- https://news.ycombinator.com/item?id=44623207 — HN — "What actually works in production": 99%^20=82%, $25/1-2hrs on large codebases, zero companies without HITL — **high**
- https://resources.anthropic.com/hubfs/2026%20Agentic%20Coding%20Trends%20Report.pdf — Anthropic — 95% weekly AI use, Rakuten 99.9% on 12.5M lines, TELUS 500K+ hours saved, 0-20% fully delegatable — **high**
- https://www.builder.io/blog/best-ai-background-agents-for-developers-2026 — Builder.io — Background agents comparison: Cursor, Copilot, Builder, Devin, Claude Code — **medium**
- https://coder.com/blog/launch-dec-2025-coder-tasks — Coder — Cloud dev environments for Claude Code, GitHub issue to PR — **medium**
- https://www.nxcode.io/resources/news/cursor-cloud-agents-virtual-machines-autonomous-coding-guide-2026 — NxCode — Cursor cloud agents: clone repo, branch, test, video demo, merge-ready PR — **medium**
- https://deepeval.com/docs/prompt-optimization-introduction — Confident AI — GEPA (Pareto) and MIPROv2 (surrogate-based) prompt optimization — **medium**

## Lower Relevance

- https://www.permit.io/blog/human-in-the-loop-for-ai-agents-best-practices-frameworks-use-cases-and-demo — Permit.io — Human-in-the-loop patterns for AI agents — **low**
- https://hatchworks.com/blog/ai-agents/ai-agent-design-best-practices/ — HatchWorks — General agent design best practices — **low**
- https://agentsarcade.com/blog/error-handling-agentic-systems-retries-rollbacks-graceful-failure — Agents Arcade — Error handling patterns: retries, rollbacks, graceful failure — **low**
- https://news.ycombinator.com/item?id=44294633 — HN — Agent produces invalid code repeating same logical errors despite explicit correction — **low**
- https://news.ycombinator.com/item?id=47096937 — HN — Context limits fill up unpredictably, breaking flow — **low**
- https://news.ycombinator.com/item?id=46876455 — HN — AI-generated "slop" flooding open source projects — **low**
- https://news.ycombinator.com/item?id=47246979 — HN — Agent-generated complexity removes natural friction on code size — **low**
- https://news.ycombinator.com/item?id=34137990 — HN — AI assistance lowers programmers' guards against buggy code — **low**

## New Sources — Iteration 18

- https://martinfowler.com/articles/exploring-gen-ai/humans-and-agents.html — Kief Morris / Martin Fowler — "In/on/out of the loop" framework: humans design the loop (specs, tests, feedback) rather than reviewing every output — **high**
- https://arxiv.org/abs/2603.05344 — Nghi D. Q. Bui — OpenDev: first academic systematization of terminal-native coding agents; 6-phase ReAct loop (pre-check, thinking, self-critique, action, tool execution, post-processing) with 7 supporting subsystems — **high**
- https://earezki.com/ai-news/2026-03-20-i-built-a-35-agent-ai-coding-swarm-that-runs-overnight/ — earezki/Mathew Dostal — 35 concurrent agents, 6,500+ runs, 124 duplicate PRs, $65/day cost spikes, 5-layer memory (CLAUDE.md + local files + Qdrant vector DB), zombie process detection — **high**
- https://manus.im/blog/Context-Engineering-for-AI-Agents-Lessons-from-Building-Manus — Peak Ji / Manus — KV-cache hit rate as #1 production metric; 100:1 input-to-output ratio; prompt prefix stability for 10x cost reduction; rebuilt framework 4x ("Stochastic Graduate Descent") — **high**
- https://addyosmani.com/blog/self-improving-agents/ — Addy Osmani — Detailed technical breakdown of continuous coding loops: atomic task design, validation gates, context management, scaling patterns — **medium**

## New Sources — Iteration 19

- https://fortune.com/2026/03/18/ai-coding-risks-amazon-agents-enterprise/ — Fortune — Production database destruction by Claude Code, Amazon outages from AI-assisted changes, only 48% of devs review AI code — **high**
- https://www.infoq.com/news/2026/03/stripe-autonomous-coding-agents/ — InfoQ — Stripe Minions: 1,300+ PRs/week, $1T+ payment volume, "Blueprints" mixing deterministic code and agent loops — **high**
- https://www.theregister.com/2026/03/18/ai_for_software_developers_qcon/ — The Register — QCon London: Bockeler warns AI tools erode expertise needed to supervise them, "lethal trifecta" — **high**
- https://www.infoq.com/news/2026/03/agents-context-file-value-review/ — InfoQ/ETH Zurich — LLM-generated context files REDUCED success rates by ~3%, human-written only +4%, both increased costs 19-20% — **high**
- https://qconlondon.com/presentation/mar2026/context-engineering-building-knowledge-engine-ai-agents-need — QCon London — "Context Engineering: Building the Knowledge Engine", context should undergo version control and CI/CD — **high**
- https://jxnl.co/writing/2025/08/30/context-engineering-compaction/ — Jason Liu — Compaction as "momentum in gradient descent", doesn't always pass clear instructions to next agent — **high**
- https://www.indium.tech/blog/agent-memory-compression-failure-modes/ — Indium Tech — 5 memory compression failure modes: catastrophic forgetting, hallucination amplification, context drift, over-compression bottlenecks, bias creep — **high**
- https://dev.to/ai_agent_digest/your-ai-agents-memory-is-broken-here-are-4-architectures-racing-to-fix-it-55j1 — DEV Community — 4 memory architectures: Observational (94.87%), Graph (Zep), Self-Editing (MemGPT), RAG+Hybrid — **high**
- https://github.com/GoogleCloudPlatform/generative-ai/tree/main/gemini/agents/always-on-memory-agent — Google — Always On Memory Agent: no vector DB, SQLite, 30-min consolidation loop, open-sourced March 2026 — **high**
- https://arxiv.org/abs/2502.12110 — NeurIPS 2025 — A-MEM: Zettelkasten method for interconnected agent knowledge networks — **medium**
- https://arxiv.org/abs/2504.19413 — Mem0 — 91% lower p95 latency, 90%+ token cost savings vs full-context — **medium**
- https://arxiv.org/abs/2501.13956 — Zep/Graphiti — Temporal knowledge graph for agent memory, 18.5% accuracy improvement — **medium**
- https://news.ycombinator.com/item?id=46988596 — HN — Improving 15 LLMs via harness changes: 5-14% improvement, ~20% token reduction — **high**
- https://georgetaskos.medium.com/the-real-ai-failure-mode-flawless-execution-of-wrong-specs-9c20b8416bda — George Taskos — "The real AI failure mode: flawless execution of wrong specs" — **high**
- https://www.langchain.com/state-of-agent-engineering — LangChain — State of Agent Engineering survey: 89% observability, 52.4% offline evals, 57% agents in prod — **high**
- https://guardrails.md/ — GUARDRAILS.md community standard — Four universal patterns, anti-patterns, context rotation at 80% capacity — **medium**
- https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/ — METR — RCT: experienced devs 19% slower with AI, believe they're 20% faster, N=246 — **high**
- https://www.coderabbit.ai/blog/2025-was-the-year-of-ai-speed-2026-will-be-the-year-of-ai-quality — CodeRabbit — 1.7x defect rate in AI-generated code vs human — **medium**
- https://harness-engineering.ai/blog/daily-ai-agent-news-roundup-march-20-2026-3/ — harness-engineering.ai — GPT-5.4 with 1M context + Pro Mode, Skylos security tool, framework comparison — **medium**

## Iteration 20 — Intent Failure & Human-Agent Collaboration
- https://arxiv.org/html/2603.17150 — Microsoft Research — Intent Formalization: specification spectrum from tests to DSLs, TiCoder doubled accuracy 40%→84% — **critical**
- https://doodledapp.com/feed/ai-made-every-test-pass-the-code-was-still-wrong — Doodledapp — AI tests what code does, not what it should do; independent ground truth is the fix — **critical**
- https://dev.to/stephenc222/ai-agents-can-pass-tests-they-still-cant-maintain-systems-2004 — Stephen C. — SWE-CI: agents break existing behavior in ~50% of maintenance iterations — **critical**
- https://metr.org/blog/2025-06-05-recent-reward-hacking/ — METR — o3 reward-hacked 30.4% of RE-Bench runs, admits misalignment 10/10 times when asked — **critical**
- https://dev.to/slimd/i-stopped-my-ai-coding-agent-from-rewriting-tests-heres-the-prompt-architecture-that-worked-1io8 — slimd — Authority hierarchy (specs>tests>code) via PactKit; pre-existing tests read-only — **high**
- https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html — Boeckeler/Martin Fowler — Compares Kiro, spec-kit, Tessl; three SDD approaches — **high**
- https://bryanfinster.substack.com/p/ai-broke-your-code-review-heres-how — Bryan Finster — Nyquist principle: defect detection must exceed production rate; 400-line threshold — **high**
- https://addyosmani.com/blog/code-review-ai/ — Addy Osmani — PR Contract framework: intent + proof + risk + review focus; logic errors 75% more common in AI code — **high**
- https://www.seangoedecke.com/agents-and-fallbacks/ — Sean Goedecke — Agents silently add fallback code paths; can't evaluate prototypes with hidden backups — **high**
- https://www.augmentcode.com/product/intent — Augment Code — Living specs with Coordinator + Verifier agents; bidirectional spec-code sync — **high**
- https://www.getautonoma.com/blog/amazon-vibe-coding-lessons — Autonoma AI — 4 Sev-1 incidents in 90 days, 6.3M lost orders; verification layer didn't scale — **critical**
- https://www.designative.info/2026/03/08/preventing-agent-drift-designing-ai-systems-that-stay-aligned-with-human-intent/ — Designative — 4-stage intention lifecycle: Capture→Persist→Maintain→Validate — **medium**
- https://addyosmani.com/blog/future-agentic-coding/ — Addy Osmani — Conductor (synchronous, tight) vs Orchestrator (async, parallel); role evolution timeline — **high**
- https://thenewstack.io/anthropic-launches-a-multi-agent-code-review-tool-for-claude-code/ — Anthropic — 5 independent reviewer agents; 84% finding rate on large PRs averaging 7.5 issues — **high**
- https://www.qodo.ai/blog/5-ai-code-review-pattern-predictions-in-2026/ — Qodo — Context-First Review: understand why the diff exists, not just what changed — **medium**
- https://lucumr.pocoo.org/2025/12/22/a-year-of-vibes/ — Armin Ronacher — PRs lack prompt/failure transparency; value in failures discarded by VCS — **medium**
- https://github.blog/ai-and-ml/generative-ai/spec-driven-development-with-ai-get-started-with-a-new-open-source-toolkit/ — GitHub — Spec Kit: specify→plan→tasks→implement; "intent is the source of truth" — **high**
- https://addyosmani.com/blog/good-spec/ — Addy Osmani — Three-tier boundaries (always/ask/never); kick off with concise spec, let AI expand — **high**
- https://intent-driven.dev/knowledge/best-practices/ — Intent-Driven.dev — "Are the artifacts human reviewable?" test for feature sizing — **medium**
- https://www.nxcode.io/resources/news/agentic-engineering-complete-guide-vibe-coding-ai-agents-2026 — NxCode — Role shift: code writing→intent specification + constraint design + output validation — **medium**
- https://www.augmentcode.com/guides/vibe-coding-vs-spec-driven-development — Augment Code — When to use vibe (prototypes) vs spec-driven (production) — **medium**
- https://arxiv.org/abs/2602.00180 — ICSE 2026 — Three rigor levels: spec-first, spec-anchored, spec-as-source; 50% error reduction — **critical**
- https://www.mindstudio.ai/blog/stripe-minions-blueprint-architecture-deterministic-agentic-nodes — MindStudio — Stripe Blueprints: deterministic+agentic nodes, dependency update example — **high**
- https://www.thoughtworks.com/en-us/insights/blog/agile-engineering-practices/spec-driven-development-unpacking-2025-new-engineering-practices — Thoughtworks — SDD as 2025's most important new practice — **high**
- https://openspec.pro/ — OpenSpec — Brownfield-first SDD, 27K+ stars, YC-backed, 4-phase state machine — **high**
- https://chiefloop.com/concepts/prd-format.html — Chief — Autonomous PRD agent; structured user stories with acceptance criteria checkboxes — **medium**

## New Sources — Iteration 21

- https://blog.langchain.com/improving-deep-agents-with-harness-engineering/ — LangChain — Top 30→Top 5 on Terminal Bench via harness-only changes; 4 middleware layers; reasoning sandwich (xhigh-high-xhigh = 66.5%); trace analyzer skill — **critical**
- https://blog.langchain.com/open-swe-an-open-source-framework-for-internal-coding-agents/ — LangChain — Open SWE captures Stripe/Coinbase/Ramp internal patterns; middleware safety nets (open_pr_if_needed, message queue injection); March 17, 2026 — **critical**
- https://techcommunity.microsoft.com/blog/appsonazureblog/the-agent-that-investigates-itself/4500073 — Microsoft — Azure SRE Agent self-improvement loop: searches 24h errors, traces to root cause, submits PR; 80% error reduction in 2 weeks — **critical**
- https://techcommunity.microsoft.com/blog/appsonazureblog/context-engineering-lessons-from-building-azure-sre-agent/4481200/ — Microsoft — Filesystem-as-world replaces RAG: Intent Met 45%→75%; 4-phase architecture evolution (100+ tools → ~5); code interpreter pattern; concurrent memory staleness unsolved — **critical**
- https://zencoder.ai/blog/20k-bug-that-changed-evals — Zencoder — $20K eval bug: spec quality masks model differences (6pt spread → 26pt); multi-model complementarity data (68% cross-vendor overlap); 730-task analysis — **critical**
- https://iximiuz.com/en/posts/grounded-take-on-agentic-coding/ — Ivan Velichko / iximiuz — 50K lines/month on 100K LOC codebase; dangerous failure modes (removing features, XSS); domain knowledge irreplaceable; 90% usefulness drop without dev environment — **critical**
- https://github.com/strongdm/attractor/blob/main/coding-agent-loop-spec.md — StrongDM — Attractor: fully programmable agentic loop; host steers mid-task; read-before-write enforcement via middleware; config changes between turns — **high**
- https://github.com/axon-core/axon — Axon — Kubernetes-native agent framework: Task CRD → isolated Pod → autonomous work → branch/PR/cost output; any agent (Claude, Codex, Gemini) — **high**
- https://devops.com/open-swe-captures-the-architecture-that-stripe-coinbase-and-ramp-built-independently-for-internal-coding-agents/ — DevOps.com — Open SWE captures independently-evolved enterprise patterns; deterministic middleware for critical operations — **high**
- https://www.mager.co/blog/2026-03-17-open-swe-coding-agents/ — Mager — Build internal coding agent in 10 minutes with Open SWE; middleware handles "what if the LLM forgets" — **medium**

## New Sources — Iteration 22

- https://northflank.com/blog/how-to-sandbox-ai-agents — Northflank — 3-tier isolation (microVM/gVisor/container), adaptive selection pattern, 10-30% gVisor overhead, 125ms Firecracker boot, defense-in-depth stack — **critical**
- https://developer.nvidia.com/blog/practical-security-guidance-for-sandboxing-agentic-workflows-and-managing-execution-risk/ — NVIDIA AI Red Team — Tiered permission model, approval caching risk, ephemeral sandbox lifecycle, OS-level controls (Landlock/Seatbelt), config file protection — **critical**
- https://developer.nvidia.com/blog/run-autonomous-self-evolving-agents-more-safely-with-nvidia-openshell/ — NVIDIA — OpenShell: out-of-process policy enforcement, browser tab isolation, privacy router, deny-by-default, zero code changes for Claude Code/Codex — **critical**
- https://news.ycombinator.com/item?id=46930565 — HN — "Beyond Agentic Coding": plan-mode-first consensus, 2-3 agent cognitive limit, agents lack decision breadcrumbs, trust per-cycle not cumulative, speed doesn't solve sync — **high**
- https://cycode.com/blog/agent-infrastructure-as-code/ — Cycode / Dor Atias — Agent Infrastructure as Code: repository-level security controls for AI agents — **medium**
- https://code.claude.com/docs/en/sandboxing — Anthropic — Claude Code built-in sandbox: file access and command restrictions per project — **medium**

## Iteration 23 — Protocol Stack & Credential Security

- https://blog.gitguardian.com/the-state-of-secrets-sprawl-2026/ — GitGuardian — 29M hardcoded secrets on GitHub, AI commits 2x leak rate, Claude Code 3.2% vs 1.5% baseline, 81% AI-service secret surge — **critical**
- https://vercel.com/blog/security-boundaries-in-agentic-architectures — Vercel — Credential injection proxy architecture, application sandbox + secret injection as strongest combined posture — **critical**
- https://www.globenewswire.com/news-release/2026/03/19/3259248/0/en/Keycard-Releases-Runtime-Governance-for-Autonomous-Coding-Agents.html — Keycard — Runtime governance: identity-bound, task-scoped, ephemeral credentials, point-of-execution policy enforcement, cross-environment portability (March 19, 2026) — **critical**
- https://www.linuxfoundation.org/press/linux-foundation-announces-the-formation-of-the-agentic-ai-foundation — Linux Foundation — AAIF formation: MCP + goose + AGENTS.md donated, AWS/Anthropic/Google/Microsoft/OpenAI platinum members (Dec 9, 2025) — **critical**
- https://dev.to/pockit_tools/mcp-vs-a2a-the-complete-guide-to-ai-agent-protocols-in-2026-30li — DEV Community — MCP (97M monthly SDK downloads) vs A2A (150+ orgs), complementary roles, protocol stack overview — **high**
- https://astrix.security/learn/blog/state-of-mcp-server-security-2025/ — Astrix Security — 88% of MCP servers need auth, 53% use static secrets, 8.5% use OAuth, 24K secrets in MCP configs on GitHub — **critical**
- https://docs.ag-ui.com/introduction — CopilotKit — AG-UI protocol: 16 event types, typed handoffs, mid-flow pause/approve/retry, agent→frontend standardization — **high**
- https://github.com/a2aproject/A2A — Google/AAIF — A2A protocol repo: Agent Cards, task-based interaction, v0.3 with gRPC + signed security cards — **high**
- https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/ — Google — A2A announcement: agent-to-agent coordination, 50+ launch partners, complementary to MCP — **high**
- https://cloud.google.com/blog/products/ai-machine-learning/agent2agent-protocol-is-getting-an-upgrade — Google Cloud — A2A v0.3: gRPC support, signed security cards, extended Python SDK — **high**
- https://www.knostic.ai/blog/claude-loads-secrets-without-permission — Knostic / Dor Munis — Claude Code silently reads .env files without notification; proxy billing spike was the tell — **high**
- https://thehackernews.com/2026/02/claude-code-flaws-allow-remote-code.html — The Hacker News / Check Point — CVE-2026-21852: malicious repo exfiltrates API keys via settings.json hooks before trust dialog — **high**
- https://github.blog/ai-and-ml/generative-ai/under-the-hood-security-architecture-of-github-agentic-workflows/ — GitHub — Zero-secret agent architecture: separate containers for LLM keys, MCP credentials, GitHub tokens, chroot-jailed filesystem — **high**
- https://infisical.com/blog/secure-secrets-management-for-cursor-cloud-agents — Infisical — Secrets management for Cursor Cloud Agents: store only machine identity, fetch secrets at runtime — **high**
- https://aembit.io/blog/securing-ai-agents-without-secrets/ — Aembit — Workload identity + ephemeral credentials, eliminate static secrets from agents entirely — **high**
- https://1password.com/solutions/agentic-ai — 1Password — Agentic AI SDK for secure agent credential management, vault-backed injection, MCP integration — **medium**
- https://www.d4b.dev/blog/2026-03-20-agentic-ui-comparing-ag-ui-mcp-ui-and-a2a-protocols — d4b — Comparison of AG-UI, MCP-UI/Apps, and A2A protocols for different use cases — **medium**
- https://atamel.dev/posts/2026/03-17_agent_protocols_mcp_a2a_a2ui_agui/ — Mete Atamel — Developer's overview of MCP, A2A, A2UI, AG-UI protocol stack — **medium**
- https://www.doppler.com/blog/mcp-server-credential-security-best-practices — Doppler — MCP credential security best practices: avoid hardcoding, use secret managers, rotate tokens — **medium**
- https://composio.dev/blog/secure-ai-agent-infrastructure-guide — Composio — Complete guide to secure AI agent infrastructure: auth, secrets, sandboxing — **medium**
- https://www.mintmcp.com/blog/ai-agent-security — MintMCP — AI agent security enterprise guide 2026: governance-containment gap as defining challenge — **medium**
- https://news.ycombinator.com/item?id=47438930 — HN / Altimate Code — Show HN: Open-source agentic data engineering harness, domain-specific harness for SQL (March 20, 2026) — **medium**

## Iteration 25 — Domain-Specific Loops & Observability

- https://mykalseceng.github.io/posts/ralph-pentest-loop/ — Dark Knight Blog — Ralph Pentest Loop: two-stage pipeline (code review → exploitation), 5-iteration retry, Burp Suite MCP — **high**
- https://github.com/agairola/securing-ralph-loop — agairola — Security-enforced development loop: /self-check → /security-scan, 3-failure escalation — **high**
- https://blog.ogunlana.net/2026/01/22/agentic-frameworks-in-cloud-infrastructure-an-exhaustive-analysis-of-ralph-and-get-shit-done-for-devops-engineering/ — Bola Ogunlana — Ralph loops for DevOps: Day 2 operations, terraform validate as circuit breaker, never direct deployment permissions — **high**
- https://www.databricks.com/company/newsroom/press-releases/databricks-launches-genie-code-bringing-agentic-engineering-data — Databricks — Genie Code: 32.1%→77.1% success rate, autonomous pipeline building, 80%+ new databases launched by agents — **critical**
- https://gradientflow.substack.com/p/data-engineering-for-machine-users — Ben Lorica / Gradient Flow — Write-Audit-Publish pattern for data pipeline agents, brownfield modernization as highest-ROI — **high**
- https://www.pagerduty.com/newsroom/pagerduty-operations-cloud-spring-2026-release/ — PagerDuty — SRE Agent evolves to virtual responder, agent-to-agent MCP, Q2 2026 early access — **high**
- https://www.mindstudio.ai/blog/what-is-autoresearch-loop-karpathy-business-optimization — MindStudio — AutoResearch for 6 business domains: email marketing, SEO, sales outreach, pricing, support routing, ad optimization — **high**
- https://www.gravitee.io/blog/state-of-ai-agent-security-2026-report-when-adoption-outpaces-control — Gravitee — State of AI Agent Security 2026: 47.1% monitored, 88% experienced incidents, 45.6% shared API keys — **critical**
- https://aiagentindex.mit.edu/ — MIT AI Agent Index — 25/30 agents disclose no safety results, 87% lack safety cards, only 4/13 frontier agents disclose agentic evals — **critical**
- https://oneuptime.com/blog/post/2026-03-09-ai-agents-observability-crisis/view — OneUptime — Fintech case: agent scaled down production DB during month-end processing → 11-hour outage — **critical**
- https://www.microsoft.com/en-us/security/blog/2026/03/18/observability-ai-systems-strengthening-visibility-proactive-risk-detection/ — Microsoft — Observability as release requirement for AI agents, behavioral baselines, tool call frequency monitoring — **critical**
- https://www.microsoft.com/en-us/security/blog/2026/03/20/secure-agentic-ai-end-to-end/ — Microsoft — End-to-end agentic AI security guidance, multi-layered controls — **high**
- https://www.splunk.com/en_us/blog/observability/splunk-observability-ai-agent-monitoring-innovations.html — Splunk — AI Agent Monitoring GA Q1 2026: hallucination/bias/drift detection, Cisco AI Defense integration — **high**
- https://github.com/iris-eval/mcp-server — Iris — First MCP-native eval & observability server, 12 built-in rules, zero-SDK integration (March 14, 2026) — **high**
- https://os-for-agent.github.io/ — AgenticOS Workshop (ASPLOS 2026) — First academic workshop on OS design for AI agents, new process models, security isolation (March 23, 2026) — **high**
- https://noimosai.com/en/blog/the-ultimate-guide-to-ai-agents-for-content-creation-scale-your-marketing-autonomously-in-2026 — Noimosa — AI agents for content creation: $10.9B market, 80% marketing overhead reduction, 10x content production — **medium**
- https://www.braintrust.dev/blog/ralph-wiggum-debugging — Braintrust — Debugging Ralph Wiggum loops with Braintrust traces: 274 LLM calls, 95K tokens, $1.38 per 2 user stories — **high**
- https://o-mega.ai/articles/top-5-ai-agent-observability-platforms-the-ultimate-2026-guide — O-Mega — Top 5 observability platforms: LangSmith, Langfuse, Braintrust, Arize, Maxim AI — **medium**
- https://klizos.com/ai-agents-are-becoming-operating-systems-in-2026/ — Klizos — AI agents as operating systems: coordination layer with specialized agents — **medium**
- https://ai-security-blog.com/blog/Ralph-Loop — AI Security Blog — Ralph loops used in malware development: PROMPTFLUX, VoidLink, offensive applications — **medium**
- https://calv.info/agents-feb-2026 — Calvin — Practitioner workflow: time-based model selection (Opus daytime, Codex overnight), skills as token-efficient automation (~50-100 tokens), 3-4 overnight tasks standard. Skills beat marketplace. — **high**
- https://blog.lpains.net/posts/2026-01-31-real-world-example-ralph/ — LPains — Real-world ralph loop: 60% time savings (6h vs 15-20h), 5 iterations, 100 premium requests. Spec quality is the critical success factor. — **high**
- https://stacktoheap.com/blog/2026/02/23/how-i-code-from-the-gym-part-4/ — StackToHeap — SDK migration via ralph: 9 stories, 81 minutes, 60 files changed. Abstract stories fail; concrete code-boundary stories succeed. 80/20 mechanical/manual split. — **high**
- https://www.thoughtworks.com/insights/blog/generative-ai/beyond-vibe-coding-the-five-building-blocks-of-aI-native-engineering — Thoughtworks (Sunit Parekh) — Five building blocks of AI-native engineering: Agent, Model, Methodology, Spec, Context. Formalization of the discipline. — **medium**
- https://agenticengineer.com/tactical-agentic-coding — Agentic Engineer — PITER framework, 12 leverage points, 7-level prompt hierarchy, "Agent Experts" pattern (Act, Learn, Reuse). — **medium**
- https://www.hugo.im/posts/agent-harness-infrastructure — Hugo Nogueira — "Intelligence without infrastructure is just a demo." The 100th tool call problem. Three essential infrastructure components: durable execution, structured memory, goal management. — **medium**
- https://blog.skypilot.co/scaling-autoresearch/ — Alex Kim, Romil Bhardwaj (SkyPilot) — Scaled Karpathy's autoresearch to 16 GPUs: 910 experiments in 8 hours, $9 API + $300 GPU. Agent spontaneously developed two-tier GPU screening strategy. — **high**
- https://fortune.com/2026/03/17/andrej-karpathy-loop-autonomous-ai-agents-future/ — Jeremy Kahn (Fortune) — Karpathy 700 experiments, 20 optimizations, 11% speedup. Shopify CEO 19% gain from 37 overnight experiments. "Emulate a research community, not a PhD student." — **high**
- https://sierra.ai/blog/model-failover — Sierra AI — Multi-Model Router with AIMD congestion control for production model failover. Refuses mid-stream fallback. Best-in-class provider resilience. — **high**
- https://planoai.dev/blog/the-two-agentic-loops-how-to-design-and-scale-agentic-apps — Salman Paracha (Plano AI) — Inner loop (agent reasoning) vs outer loop (governance/orchestration). YAML config for model downgrade on budget threshold. — **high**
- https://how2.sh/posts/how-to-build-agent-tool-timeout-envelopes-for-safer-rollouts-for-mission-critical-automations/ — how2.sh — Three-tier graceful degradation: CRITICAL (abort), IMPORTANT (warn), OPTIONAL (skip). Structured degradation signals to agent. — **high**
- https://www.inngest.com/blog/durable-execution-key-to-harnessing-ai-agents — Inngest — Step-level checkpointing, exactly-once semantics, suspend/resume for human-in-the-loop. 5 steps at 99% = 95% without durability. — **high**
- https://dev.to/klement_gunndu/4-fault-tolerance-patterns-every-ai-agent-needs-in-production-jih — klement_gunndu (DEV) — 4-layer fault tolerance stack: retry, model fallback, error classification, checkpoint recovery. Unrecoverable failures 23%→2%. — **high**
- https://www.harperfoley.com/blog/ai-agents-destroyed-production-zero-postmortems — Harper Foley — 10 production incidents across 6 AI tools in 16 months: deleted home dirs, fabricated DB records, erased 1.94M rows. Zero vendor postmortems. — **high**
- https://www.damiangalarza.com/posts/2026-02-13-linear-agent-loop/ — Damian Galarza — Linear-driven agent loop: bash + fresh Claude Code + Linear MCP. PR staleness cascade as novel failure mode. — **high**
- https://blog.langchain.com/the-anatomy-of-an-agent-harness/ — Vivek Trivedy (LangChain) — "Agent = Model + Harness." Opus 4.6 ranks #33 in Claude Code but #5 in other harnesses. Harness choice matters more than model choice. — **high**
- https://www.morphllm.com/ai-coding-agent — Morph Engineering — 15 AI coding agents tested: same model, 17-problem spread across harnesses. Cursor $7K annual depleted in 1 day. — **medium**
- https://moltbook-ai.com/posts/ai-agent-cost-optimization-2026 — Moltbook-AI — 10 cost optimization strategies: model routing (40-70% savings), context management (30-50%), caching (20-40%). Unoptimized = 10-50x excess tokens. — **high**
- https://logiciel.io/blog/incident-response-patterns-autonomous-agents-prod — Logiciel — 4 incident response patterns: human-in-the-loop, scoped autonomy, supervisor agent, shadow mode. MTTR improves 30-50%. — **medium**
- https://earezki.com/ai-news/2026-03-07-5-ai-agent-failures-that-will-kill-your-production-deployment-and-how-i-fixed-them/ — earezki — 5 production agent failures: hallucination-by-omission, context drift, cron race conditions, prompt injection, uncontrolled costs. — **high**
- https://arxiv.org/abs/2603.05344 — Nghi D. Q. Bui — OPENDEV: Rust-based CLI agent with lazy tool discovery, adaptive context compaction, cross-session memory, event-driven system reminders. — **medium**

## Memory Engineering & Event-Driven Loops (Iteration 29)

- https://ngrok.com/blog/bmo-self-improving-coding-agent — ngrok — BMO self-improving agent: 4-loop system, knowing-doing gap, OPPORTUNITIES.md paradox, 2/60 tool usage, structured triggers work — **high**
- https://factory.ai/news/compressing-context — Factory.ai — Two-threshold compression (T_max/T_retained), restorable compression via breadcrumbs, "minimize tokens per task not request" — **high**
- https://code.claude.com/docs/en/channels — Anthropic — Claude Code Channels: event-driven push into running sessions via MCP, Telegram/Discord plugins, webhook receivers — **high**
- https://dev.to/suede/the-architecture-of-persistent-memory-for-claude-code-17d — suede (DEV) — Claude Code two-tier memory: CLAUDE.md auto-briefing + .memory/state.json, hooks, Jaccard dedup, confidence decay, budget system — **high**
- https://elephaant.com/blog/google-always-on-memory-agent-vector-db-alternative-2026 — Elephaant — Google Always On Memory Agent analysis: 3 sub-agents, SQLite, drift risk, "real cost is drift not tokens" — **high**
- https://dev.to/ai_agent_digest/your-ai-agents-memory-is-broken-here-are-4-architectures-racing-to-fix-it-55j1 — AI Agent Digest (DEV) — Comparative analysis: RAG, observational, self-editing, graph memory. Observational best for long-running agents — **high**
- https://news.ycombinator.com/item?id=46097759 — HN — Three-layer memory consensus: semantic + task tracking + versioning. "Separating understanding from tracking reduces cognitive load." — **medium**
- https://news.ycombinator.com/item?id=47465415 — HN (March 22, 2026) — Practitioners share CLAUDE.md patterns: Table Flip Rule, persona-based instruction, ASCII diagrams, ADHD accommodations — **medium**
- https://news.ycombinator.com/item?id=47466679 — HN (March 22, 2026) — Von Hammerstein's classification applied to AI agents: industrious+stupid = dangerous. Verification overhead exceeds speed gains. — **medium**
- https://arxiv.org/abs/2603.07670 — March 2026 survey — Memory for autonomous LLM agents: 5 mechanism families, shift from static recall to multi-session agentic evaluation — **medium**
- https://arxiv.org/html/2603.04257 — Memex(RL) — Pointer-heavy index maps for long-horizon agents: separate compact summary from full-fidelity artifacts, selective retrieval — **medium**
- https://arxiv.org/abs/2502.12110 — A-MEM — Zettelkasten-inspired agentic memory with dynamic indexing, NeurIPS 2025 — **medium**
- https://arxiv.org/abs/2601.02553 — SimpleMem — Three-stage compression: 30x token reduction, 43.24 F1 on LoCoMo vs Mem0's 34.20 — **medium**
- https://hackernoon.com/the-complete-guide-to-ai-agent-memory-files-claudemd-agentsmd-and-beyond — HackerNoon — Taxonomy of CLAUDE.md, AGENTS.md, and agent memory file patterns — **medium**

## Iteration 30 — Workflow Composition, CI/CD Integration & Agent Fleets

- https://www.elastic.co/search-labs/blog/ci-pipelines-claude-ai-agent — Elastic — Claude Code in Buildkite CI: 24 PRs fixed, 22 commits, 20 days saved. CLAUDE.md as team guidelines. Auto-merge disabled. — **high**
- https://developers.redhat.com/articles/2026/03/12/how-develop-agentic-workflows-ci-pipeline-cicaddy — Red Hat — Cicaddy: pipeline-native agent framework, MCP as tool interface, one-shot execution with multi-turn reasoning, 3 agent types — **high**
- https://github.blog/ai-and-ml/generative-ai/multi-agent-workflows-often-fail-heres-how-to-engineer-ones-that-dont/ — GitHub Blog — Typed schemas at handoff points, action schemas, MCP — #1 failure cause is context loss — **high**
- https://developers.googleblog.com/developers-guide-to-multi-agent-patterns-in-adk/ — Google — 8 core multi-agent patterns in ADK: Sequential, Coordinator, Parallel, Hierarchical, Generator/Critic, Iterative, HitL, Composite — **high**
- https://www.deloitte.com/us/en/insights/industry/technology/technology-media-and-telecom-predictions/2026/ai-agent-orchestration.html — Deloitte — $8.5B agent market, 40% of projects may be cancelled by 2027 due to complexity — **high**
- https://intelligenttools.co/blog/claude-code-unsupervised-8-hours-ralph-loop — IntelligentTools — 47 commits overnight, 8 files refactored, test coverage 62%→87%, $23.14 cost, 80% success rate — **high**
- https://news.ycombinator.com/item?id=46988596 — HN/blog.can.ac — Hash-based line identification: +5-14pp on coding benchmarks, ~20% token reduction. "Harness reveals optimization potential." — **high**
- https://fortune.com/2026/03/17/andrej-karpathy-loop-autonomous-ai-agents-future/ — Fortune — Karpathy: 700 experiments, 2 days. Shopify CEO: 37 experiments overnight, 19% gain. "The final boss battle." — **high**
- https://blog.langchain.com/choosing-the-right-multi-agent-architecture/ — LangChain — Subagents vs Skills vs Handoffs vs Router decision matrix. Skills save 40% tokens via statefulness. — **high**
- https://techcrunch.com/2026/03/05/cursor-is-rolling-out-a-new-system-for-agentic-coding/ — TechCrunch — Cursor Automations: event-triggered agents (Slack, Linear, GitHub, PagerDuty), isolated Ubuntu VMs — **high**
- https://shipyard.build/blog/claude-code-multi-agent/ — Shipyard — Agent Teams, Gas Town, Multiclaude. "Multi-agent doesn't make sense for 95% of tasks." — **medium**
- https://www.alibabacloud.com/blog/from-react-to-ralph-loop-a-continuous-iteration-paradigm-for-ai-agents_602799 — Alibaba Cloud — ReAct vs Ralph comparison: context rot vs forced iteration. Token costs $50-150 large tasks. 5-50 iteration limits. — **medium**
- https://docs.bswen.com/blog/2026-03-21-agent-task-handoff-coordination/ — BSWEN — HANDOFF.md files as state transfer between agents. Context loss is #1 multi-agent failure. — **medium**
- https://news.ycombinator.com/item?id=47162581 — HN/__parallaxis — Context Harness: Rust/SQLite/FTS5 hybrid search, MCP-compatible, WAL mode for concurrent read/write — **medium**
- https://news.ycombinator.com/item?id=47141035 — HN/Charlie Guo (OpenAI) — Emerging harness engineering playbook from OpenAI, Stripe, OpenClaw — **medium**
- https://www.salesforce.com/news/stories/connectivity-report-announcement-2026/ — Salesforce — Multi-agent adoption to surge 67% by 2027. 86% of IT leaders cite complexity concern. — **medium**
- https://www.datacamp.com/tutorial/crewai-vs-langgraph-vs-autogen — DataCamp — Framework comparison: LangGraph 2.2x faster than CrewAI, 8-9x token efficiency differences — **medium**
- https://pasqualepillitteri.it/en/news/381/claude-code-march-2026-updates — Pasquale Pillitteri — Claude Code /loop (v2.1.71), 1M context (v2.1.75), /effort command (v2.1.76), MCP Elicitation — **medium**
