import os
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import click
import requests

from . import auth, local_instance
from .local_server import serve_local_app


LOCAL_START_TIMEOUT_S = 10.0
LOCAL_STOP_TIMEOUT_S = 5.0


def _bundled_frontend_dir():
    return Path(__file__).resolve().parent / "bundled_frontend"


def _package_root():
    return Path(__file__).resolve().parent.parent


def build_local_instance(pid, app_port, api_port, data_dir, token, instance_id):
    return local_instance.LocalInstance(
        instance_id=instance_id,
        pid=pid,
        app_port=app_port,
        api_port=api_port,
        web_base_url=f"http://127.0.0.1:{app_port}",
        api_base_url=f"http://127.0.0.1:{api_port}",
        data_dir=str(Path(data_dir)),
        token=token,
        started_at=datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
    )


def start_local(app_port=None, api_port=None, data_dir=None):
    existing_instance = local_instance.load_local_instance()
    if existing_instance and local_instance.probe_local_instance(existing_instance):
        return {"already_running": True, "instance": existing_instance}

    app_dir = _bundled_frontend_dir()
    if not app_dir.exists():
        raise click.ClickException(f"Missing bundled frontend assets: {app_dir}")

    resolved_data_dir = Path(data_dir).expanduser() if data_dir else auth.get_local_data_dir()
    resolved_data_dir.mkdir(parents=True, exist_ok=True)

    try:
        resolved_app_port, resolved_api_port = local_instance.resolve_port_pair(app_port=app_port, api_port=api_port)
    except PermissionError as error:
        raise click.ClickException(str(error)) from error
    except (OSError, ValueError) as error:
        raise click.ClickException(str(error)) from error

    token = local_instance.DEFAULT_LOCAL_TOKEN
    instance_id = str(uuid4())
    log_path = local_instance.get_local_log_path()
    log_path.parent.mkdir(parents=True, exist_ok=True)

    command = [
        sys.executable,
        "-m",
        "gradexp.cli",
        "_serve-local-instance",
        "--app-port",
        str(resolved_app_port),
        "--api-port",
        str(resolved_api_port),
        "--data-dir",
        str(resolved_data_dir),
        "--instance-id",
        instance_id,
        "--token",
        token,
    ]

    with open(log_path, "ab") as log_file:
        process = subprocess.Popen(
            command,
            cwd=str(_package_root()),
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,
            close_fds=True,
        )

    instance = build_local_instance(
        pid=process.pid,
        app_port=resolved_app_port,
        api_port=resolved_api_port,
        data_dir=resolved_data_dir,
        token=token,
        instance_id=instance_id,
    )

    try:
        _wait_for_startup(instance, timeout=LOCAL_START_TIMEOUT_S)
    except Exception as error:
        _terminate_process(instance.pid)
        local_instance.clear_local_instance(expected_instance_id=instance.instance_id)
        raise click.ClickException(str(error)) from error

    local_instance.save_local_instance(instance)
    return {
        "already_running": False,
        "instance": instance,
        "log_path": log_path,
    }


def get_local_status():
    instance = local_instance.load_local_instance()
    if not instance:
        return {"running": False}

    version = local_instance.probe_local_instance(instance)
    if not version:
        return {
            "running": False,
            "stale": True,
            "instance": instance,
        }

    return {
        "running": True,
        "instance": instance,
        "version": version,
        "log_path": local_instance.get_local_log_path(),
    }


def stop_local():
    instance = local_instance.load_local_instance()
    if not instance:
        return {"stopped": False, "reason": "not-running"}

    _request_shutdown(instance)
    if not _wait_for_shutdown(instance, timeout=LOCAL_STOP_TIMEOUT_S):
        _terminate_process(instance.pid)
        if not _wait_for_shutdown(instance, timeout=LOCAL_STOP_TIMEOUT_S):
            raise click.ClickException(
                f"Failed to stop local Gradient Explorer instance (PID {instance.pid})."
            )

    local_instance.clear_local_instance(expected_instance_id=instance.instance_id)
    return {"stopped": True, "instance": instance}


def run_local_service(app_port, api_port, data_dir, instance_id, token):
    app_dir = _bundled_frontend_dir()
    if not app_dir.exists():
        raise click.ClickException(f"Missing bundled frontend assets: {app_dir}")

    stop_event = threading.Event()
    _install_signal_handlers(stop_event)
    serve_local_app(
        app_dir=app_dir,
        data_dir=Path(data_dir).expanduser(),
        app_port=app_port,
        api_port=api_port,
        instance_id=instance_id,
        access_token=token,
        stop_event=stop_event,
    )

def _install_signal_handlers(stop_event):
    def _stop_handler(signum, frame):
        stop_event.set()

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, _stop_handler)


def _wait_for_startup(instance, timeout):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not local_instance.is_process_running(instance.pid):
            break

        version = local_instance.probe_local_instance(instance, timeout=0.3)
        if version:
            try:
                response = requests.get(instance.web_base_url, timeout=0.3)
                if response.ok:
                    return version
            except requests.exceptions.RequestException:
                pass

        time.sleep(0.1)

    raise RuntimeError(_startup_error_message(instance))


def _startup_error_message(instance):
    log_tail = _read_log_tail(local_instance.get_local_log_path())
    base_message = (
        "Local Gradient Explorer failed to start. "
        f"See {local_instance.get_local_log_path()} for details."
    )
    if not log_tail:
        return base_message
    return f"{base_message}\n\nRecent log output:\n{log_tail}"


def _read_log_tail(path, max_lines=20):
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    lines = content.strip().splitlines()
    return "\n".join(lines[-max_lines:])


def _request_shutdown(instance):
    try:
        response = requests.post(
            f"{instance.api_base_url}/local/shutdown",
            headers={"Authorization": f"Bearer {instance.token}"},
            timeout=0.5,
        )
    except requests.exceptions.RequestException:
        return False

    return response.status_code == 202


def _wait_for_shutdown(instance, timeout):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not local_instance.is_process_running(instance.pid):
            return True
        if _local_services_stopped(instance):
            return True
        time.sleep(0.1)
    return False


def _terminate_process(pid):
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return


def _local_services_stopped(instance):
    if local_instance.probe_local_instance(instance, timeout=0.2) is not None:
        return False

    for url in (instance.web_base_url, f"{instance.api_base_url}/version"):
        try:
            response = requests.get(url, timeout=0.2)
            if response.ok:
                return False
        except requests.exceptions.RequestException:
            continue

    return True
