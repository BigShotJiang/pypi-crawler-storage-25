// Allow clipboard shortcuts (Ctrl/Cmd+C/X/V/A) in the React UI.
// Emscripten's keyboard handler calls preventDefault() on all key events
// outside <input>/<textarea>, which blocks native copy/paste on regular text.
// This capture-phase listener fires before Emscripten's and stops it from
// consuming clipboard shortcuts when the target is outside the canvas.
window.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && 'cxva'.indexOf(e.key.toLowerCase()) !== -1) {
        var canvas = document.getElementById('canvas');
        if (e.target !== canvas && !(canvas && canvas.contains(e.target))) {
            e.stopImmediatePropagation();
        }
    }
}, true);

window.Module = Object.assign(window.Module || {}, {
    preRun: window.Module?.preRun || [],
    postRun: window.Module?.postRun || [],
    print: function () {
      console.log(Array.prototype.slice.call(arguments).join(" "));
    },
    printErr: function () {
      console.error(Array.prototype.slice.call(arguments).join(" "));
    },
    canvas: document.getElementById("canvas"),
    setStatus: function () {},
    monitorRunDependencies: function () {},
    runtimeReady: false,
    locateFile: function (path, prefix) {
        const base = (prefix || "") + path;
        const version = window.__SOKOL_ASSET_VERSION__;
        if (!version) {
            return base;
        }
        const separator = base.indexOf("?") === -1 ? "?" : "&";
        return base + separator + "v=" + encodeURIComponent(version);
    },
    onRuntimeInitialized: function() {
        Module.runtimeReady = true;
        setupIdleMode();
    },
});
var Module = window.Module;
window.onerror = function (event) {
    console.log("onerror: " + event.message);
};

// Idle mode management - pauses main loop when idle to save GPU
function setupIdleMode() {
    let isPaused = false;
    let consecutiveIdleChecks = 0;
    const IDLE_CHECKS_BEFORE_PAUSE = 30; // ~500ms at 60fps check rate

    const canvas = document.getElementById("canvas");
    if (!canvas) return;

    // Resume from pause on any input
    const resumeIfPaused = () => {
        if (isPaused) {
            isPaused = false;
            consecutiveIdleChecks = 0;
            Module._emscripten_resume_main_loop();
            console.log("Resuming main loop (user input)");
        }
    };

    // Listen for input events that should wake from idle
    canvas.addEventListener("mousedown", resumeIfPaused);
    canvas.addEventListener("mousemove", resumeIfPaused);
    canvas.addEventListener("wheel", resumeIfPaused);
    canvas.addEventListener("touchstart", resumeIfPaused);
    canvas.addEventListener("touchmove", resumeIfPaused);
    canvas.addEventListener("keydown", resumeIfPaused);
    window.addEventListener("resize", resumeIfPaused);

    // Periodically check if we should pause
    setInterval(() => {
        if (isPaused) return;

        try {
            const isIdle = Module._get_is_idle();
            if (isIdle) {
                consecutiveIdleChecks++;
                if (consecutiveIdleChecks >= IDLE_CHECKS_BEFORE_PAUSE) {
                    isPaused = true;
                    Module._emscripten_pause_main_loop();
                    console.log("Pausing main loop (idle mode)");
                }
            } else {
                consecutiveIdleChecks = 0;
            }
        } catch {
            // _get_is_idle may not exist in older builds
        }
    }, 16); // Check every ~16ms (roughly once per frame)
}
