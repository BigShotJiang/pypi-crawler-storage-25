// For running in console to test print_array export

var arr = new Int32Array([1, 2, 3, 4, 5]);

var nDataBytes = arr.length * arr.BYTES_PER_ELEMENT;
var dataPtr = Module._malloc(nDataBytes);
Module.HEAP32.set(arr, dataPtr / arr.BYTES_PER_ELEMENT);

Module.ccall(
    'print_array',
    null,
    ['number', 'number'], // Change 'array' to 'number' to pass a pointer
    [dataPtr, arr.length]
);

Module._free(dataPtr);