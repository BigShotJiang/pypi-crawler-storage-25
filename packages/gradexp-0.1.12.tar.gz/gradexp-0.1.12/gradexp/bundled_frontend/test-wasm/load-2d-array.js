const rows = 3;
// const cols = 4;
const initialValues = [
  [1.1, 2.2, 3.3, 4.4],
  [5.5, 6.6, 7.7, 8.8],
  [9.9, 10.1, 11.11, 12.12]
];

const arr2d = Array.from({ length: rows }, (_, i) => 
  new Float64Array(initialValues[i])
);

console.log(arr2d);