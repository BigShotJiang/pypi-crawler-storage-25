import json
import os
import socket
from dataclasses import dataclass
from pathlib import Path

import requests


DEFAULT_LOCAL_DIRNAME = ".gradexp-data"
DEFAULT_LOCAL_TOKEN = "gradexp-local-token"
DEFAULT_APP_PORT = 3000
DEFAULT_API_PORT = 3001
DEFAULT_PORT_SEARCH_WINDOW = 400
LOCAL_INSTANCE_FILENAME = "local-instance.json"
LOCAL_LOG_FILENAME = "local-server.log"
LOCALHOST_HOSTNAMES = {"127.0.0.1", "localhost", "::1"}


@dataclass
class LocalInstance:
    instance_id: str
    pid: int
    app_port: int
    api_port: int
    web_base_url: str
    api_base_url: str
    data_dir: str
    token: str
    started_at: str

    def to_dict(self):
        return {
            "instance_id": self.instance_id,
            "pid": self.pid,
            "app_port": self.app_port,
            "api_port": self.api_port,
            "web_base_url": self.web_base_url,
            "api_base_url": self.api_base_url,
            "data_dir": self.data_dir,
            "token": self.token,
            "started_at": self.started_at,
        }


def get_local_control_dir():
    return Path.home() / DEFAULT_LOCAL_DIRNAME


def get_default_local_data_dir():
    return get_local_control_dir()


def get_local_instance_path():
    return get_local_control_dir() / LOCAL_INSTANCE_FILENAME


def get_local_log_path():
    return get_local_control_dir() / LOCAL_LOG_FILENAME


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(payload, indent=2))
    tmp_path.replace(path)


def save_local_instance(instance):
    _write_json(get_local_instance_path(), instance.to_dict())


def clear_local_instance(expected_instance_id=None):
    path = get_local_instance_path()
    if not path.exists():
        return

    if expected_instance_id:
        current = _read_local_instance_file()
        if not current or current.get("instance_id") != expected_instance_id:
            return

    path.unlink()


def _read_local_instance_file():
    path = get_local_instance_path()
    if not path.exists():
        return None

    try:
        payload = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None

    required_keys = {
        "instance_id",
        "pid",
        "app_port",
        "api_port",
        "web_base_url",
        "api_base_url",
        "data_dir",
        "token",
        "started_at",
    }
    if not required_keys.issubset(payload):
        return None
    return payload


def load_local_instance():
    payload = _read_local_instance_file()
    if not payload:
        return None

    instance = LocalInstance(
        instance_id=str(payload["instance_id"]),
        pid=int(payload["pid"]),
        app_port=int(payload["app_port"]),
        api_port=int(payload["api_port"]),
        web_base_url=str(payload["web_base_url"]).rstrip("/"),
        api_base_url=str(payload["api_base_url"]).rstrip("/"),
        data_dir=str(payload["data_dir"]),
        token=str(payload["token"]),
        started_at=str(payload["started_at"]),
    )

    if not is_process_running(instance.pid):
        clear_local_instance(expected_instance_id=instance.instance_id)
        return None

    return instance


def is_process_running(pid):
    if pid <= 0:
        return False

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def probe_local_instance(instance, timeout=0.5):
    try:
        response = requests.get(f"{instance.api_base_url}/version", timeout=timeout)
        response.raise_for_status()
        payload = response.json()
    except (ValueError, requests.exceptions.RequestException):
        return None

    if payload.get("mode") != "local":
        return None
    if payload.get("instance_id") != instance.instance_id:
        return None
    return payload


def find_available_port_pair(preferred_port=None, search_window=DEFAULT_PORT_SEARCH_WINDOW):
    if preferred_port is not None:
        candidate_starts = range(preferred_port, preferred_port + search_window)
    else:
        random_start = _probe_available_port(0)
        candidate_starts = list(range(DEFAULT_APP_PORT, DEFAULT_APP_PORT + search_window))
        candidate_starts.extend(range(random_start, min(random_start + search_window, 65534)))

    last_error = None
    attempted_ports = set()
    for start_port in candidate_starts:
        if start_port in attempted_ports:
            continue
        attempted_ports.add(start_port)
        if start_port < 1 or start_port >= 65535:
            continue
        try:
            with _bound_socket(start_port), _bound_socket(start_port + 1):
                return start_port, start_port + 1
        except OSError as error:
            last_error = error

    if isinstance(last_error, PermissionError):
        raise PermissionError(
            "Could not allocate local ports because binding loopback sockets is not permitted in this environment."
        ) from last_error
    raise OSError("Could not find an unused adjacent port pair for the local Gradient Explorer instance.")


def resolve_port_pair(app_port=None, api_port=None):
    if app_port is not None and api_port is not None:
        if api_port == app_port:
            raise ValueError("App and API ports must be different.")
        return _resolve_adjacent_pair_from_anchor(app_port, api_port)

    if app_port is not None:
        return _resolve_adjacent_pair_from_anchor(app_port, app_port + 1)

    if api_port is not None:
        return _resolve_adjacent_pair_from_anchor(api_port - 1, api_port)

    return find_available_port_pair()


def _resolve_adjacent_pair_from_anchor(app_port, api_port):
    if app_port < 1 or api_port < 1:
        raise ValueError("Ports must be positive integers.")

    with _bound_socket(app_port), _bound_socket(api_port):
        return app_port, api_port


def _probe_available_port(port):
    with _bound_socket(port) as sock:
        return sock.getsockname()[1]


def _bound_socket(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", port))
    return sock


def is_loopback_url(url):
    from urllib.parse import urlparse

    parsed = urlparse(url)
    return (parsed.hostname or "").lower() in LOCALHOST_HOSTNAMES
