FLOAT32_DTYPE = "float32"
FLOAT16_DTYPE = "float16"
BFLOAT16_DTYPE = "bfloat16"
DEFAULT_PRECISION = FLOAT32_DTYPE

SUPPORTED_STORAGE_DTYPES = (
    FLOAT32_DTYPE,
    FLOAT16_DTYPE,
    BFLOAT16_DTYPE,
)

_DTYPE_ALIASES = {
    "fp32": FLOAT32_DTYPE,
    "float32": FLOAT32_DTYPE,
    "fp16": FLOAT16_DTYPE,
    "float16": FLOAT16_DTYPE,
    "half": FLOAT16_DTYPE,
    "bf16": BFLOAT16_DTYPE,
    "bfloat16": BFLOAT16_DTYPE,
}

_BYTES_PER_VALUE = {
    FLOAT32_DTYPE: 4,
    FLOAT16_DTYPE: 2,
    BFLOAT16_DTYPE: 2,
}


def canonicalize_precision(precision, default=DEFAULT_PRECISION):
    if precision is None:
        return default

    normalized = str(precision).strip().lower()
    if not normalized:
        return default

    if normalized not in _DTYPE_ALIASES:
        supported = ", ".join(sorted(_DTYPE_ALIASES.keys()))
        raise ValueError(f"Unsupported precision '{precision}'. Expected one of: {supported}.")

    return _DTYPE_ALIASES[normalized]


def bytes_per_value(dtype):
    return _BYTES_PER_VALUE[canonicalize_precision(dtype)]


def flattened_element_count(shape):
    total = 1
    for dim in shape:
        total *= int(dim)
    return total


def expected_byte_length(dtype, shape):
    return flattened_element_count(shape) * bytes_per_value(dtype)
