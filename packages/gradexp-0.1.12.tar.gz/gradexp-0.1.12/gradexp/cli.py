import click

from . import auth, local_instance
from .local_sync import DEFAULT_SYNC_INTERVAL_S, get_local_sync_status, run_local_sync
from .local_start import get_local_status, run_local_service, start_local, stop_local


_ACCENT_COLOR = "cyan"
_SUCCESS_COLOR = "green"
_WARNING_COLOR = "yellow"
_DANGER_COLOR = "red"
_MUTED_COLOR = "bright_black"


def _accent(text, bold=False, underline=False):
    return click.style(str(text), fg=_ACCENT_COLOR, bold=bold, underline=underline)


def _success(text, bold=False):
    return click.style(str(text), fg=_SUCCESS_COLOR, bold=bold)


def _warning(text, bold=False):
    return click.style(str(text), fg=_WARNING_COLOR, bold=bold)


def _danger(text, bold=False):
    return click.style(str(text), fg=_DANGER_COLOR, bold=bold)


def _muted(text, bold=False):
    return click.style(str(text), fg=_MUTED_COLOR, bold=bold)


def _link(url):
    return _accent(url, underline=True)


def _human_bytes(n):
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return f"{n:.1f} TB"


def _pluralize(count, singular):
    suffix = "" if count == 1 else "s"
    return f"{count} {singular}{suffix}"


def _info_box(title, rows):
    """Print a bordered box with a title and key-value rows."""
    normalized_rows = [(str(label), str(value)) for label, value in rows]
    label_width = max(len(label) for label, _ in normalized_rows)
    content_lines = [
        f"  {label:<{label_width}}  {click.unstyle(value)}"
        for label, value in normalized_rows
    ]
    inner_width = max(len(title) + 2, *(len(line) for line in content_lines)) + 2

    click.echo(_accent(f"\u250c {title} {'─' * (inner_width - len(title) - 2)}\u2510", bold=True))
    for (label, value), plain_line in zip(normalized_rows, content_lines):
        padded_label = f"{label:<{label_width}}"
        padding = inner_width - len(plain_line)
        styled_line = f"  {_accent(padded_label, bold=True)}  {value}"
        click.echo(f"{_accent('\u2502')}{styled_line}{' ' * padding}{_accent('\u2502')}")
    click.echo(_accent(f"\u2514{'─' * inner_width}\u2518", bold=True))


def _local_instance_rows(instance, include_started=False):
    rows = [
        ("Frontend", _link(instance.web_base_url)),
        ("API", _link(instance.api_base_url)),
        ("Data dir", _accent(instance.data_dir)),
        ("PID", click.style(str(instance.pid), bold=True)),
    ]
    if include_started:
        rows.append(("Started", _muted(instance.started_at, bold=True)))
    return rows


def _local_sync_rows(summary):
    if summary.error:
        return [
            ("Status", _danger("Summary unavailable", bold=True)),
            ("Saved locally", _accent(_human_bytes(summary.local_bytes), bold=True)),
            ("Reason", _danger(summary.error)),
        ]

    if not summary.store_available:
        return [
            ("Status", _muted("No local tensor data", bold=True)),
            ("Pending sync", _success("0 runs · 0 tensors · 0 steps · 0 B")),
            ("Saved locally", _accent(_human_bytes(summary.local_bytes), bold=True)),
        ]

    pending_parts = []
    if summary.unsynced_runs:
        pending_parts.append(_pluralize(summary.unsynced_runs, "run"))
    pending_parts.append(_pluralize(summary.unsynced_tensors, "tensor"))
    pending_parts.append(_pluralize(summary.unsynced_steps, "step"))
    pending_parts.append(_human_bytes(summary.unsynced_bytes))
    pending_value = (
        _success("0 runs · 0 tensors · 0 steps · 0 B")
        if summary.unsynced_runs == 0 and summary.unsynced_tensors == 0
        else _warning(
            " · ".join(pending_parts),
            bold=True,
        )
    )
    status_value = (
        _success("Fully synced", bold=True)
        if summary.is_fully_synced()
        else _warning("Pending upload", bold=True)
    )

    return [
        ("Status", status_value),
        ("Pending sync", pending_value),
        ("Saved locally", _accent(_human_bytes(summary.local_bytes), bold=True)),
        (
            "Tracked",
            _accent(
                f"{_pluralize(summary.total_runs, 'run')} · "
                f"{_pluralize(summary.total_tensors, 'tensor')} · "
                f"{_pluralize(summary.total_steps, 'step')}"
            ),
        ),
    ]


def _show_local_sync_summary(data_dir):
    _info_box("Local Sync Summary", _local_sync_rows(get_local_sync_status(data_dir)))


def _follow_log():
    """Tail the local server log file, blocking until interrupted."""
    import time

    log_path = local_instance.get_local_log_path()
    click.echo(_muted(f"\n--- Following {log_path} (Ctrl-C to stop) ---\n", bold=True))
    try:
        with open(log_path, "r") as f:
            f.seek(0, 2)  # seek to end
            while True:
                line = f.readline()
                if line:
                    click.echo(line, nl=False)
                else:
                    time.sleep(0.2)
    except KeyboardInterrupt:
        click.echo(_muted("\n--- Stopped following logs ---", bold=True))


def _get_or_start_local_instance(app_port=None, api_port=None, data_dir=None):
    """Return a running local instance, starting one if needed."""
    status = get_local_status()
    if status["running"]:
        return status["instance"], False

    result = start_local(app_port=app_port, api_port=api_port, data_dir=data_dir)
    return result["instance"], not result["already_running"]


@click.group()
@click.version_option()
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
def main(ctx, debug):
    """Gradient Explorer CLI"""
    ctx.ensure_object(dict)
    ctx.obj["DEBUG"] = debug


@main.command()
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
def login(ctx, debug):
    """Log in to Gradient Explorer."""
    auth.login_flow(debug=debug or ctx.obj.get("DEBUG", False))


@main.group()
def local():
    """Manage a local Gradient Explorer instance."""


@local.command("start")
@click.option("--app-port", type=int, default=None, help="Frontend port")
@click.option("--api-port", type=int, default=None, help="API port")
@click.option(
    "--data-dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    default=None,
    help="Directory for local API state",
)
@click.option("-f", "--follow", is_flag=True, help="Follow server logs after starting")
def local_start_command(app_port, api_port, data_dir, follow):
    """Start the bundled local frontend and API in the background."""
    instance, started = _get_or_start_local_instance(
        app_port=app_port,
        api_port=api_port,
        data_dir=data_dir,
    )

    if started:
        click.echo(_success("Started local Gradient Explorer.", bold=True))
    else:
        click.echo(_warning("Local Gradient Explorer is already running.", bold=True))

    _info_box("Local Gradient Explorer", _local_instance_rows(instance))

    if follow:
        _follow_log()


@local.command("status")
@click.option("-f", "--follow", is_flag=True, help="Follow server logs")
def local_status_command(follow):
    """Show the status of the local Gradient Explorer instance."""
    status = get_local_status()
    if not status["running"]:
        if status.get("stale"):
            instance = status["instance"]
            click.echo(_warning("Local Gradient Explorer process exists, but the server is not responding.", bold=True))
            _info_box("Stale Instance", _local_instance_rows(instance))
            _show_local_sync_summary(instance.data_dir)
            return
        click.echo(_warning("No local Gradient Explorer instance is running.", bold=True))
        _show_local_sync_summary(auth.get_local_data_dir())
        return

    instance = status["instance"]
    click.echo(_success("Local Gradient Explorer is running.", bold=True))
    _info_box("Local Gradient Explorer", _local_instance_rows(instance, include_started=True))
    _show_local_sync_summary(instance.data_dir)

    if follow:
        _follow_log()


@local.command("open")
def local_open_command():
    """Open the local Gradient Explorer frontend in a browser."""
    import webbrowser

    instance, started = _get_or_start_local_instance()
    if started:
        click.echo(_success("Started local Gradient Explorer.", bold=True))
        click.echo(f"{_accent('Backend API:', bold=True)} {_link(instance.api_base_url)}")

    opened = False
    try:
        opened = webbrowser.open(instance.web_base_url)
    except Exception:
        pass

    if opened:
        click.echo(f"{_success('Opened', bold=True)} {_link(instance.web_base_url)}")
        return

    click.echo(_warning("Could not open browser automatically.", bold=True))
    click.echo(f"{_accent('Frontend URL:', bold=True)} {_link(instance.web_base_url)}")


@local.command("stop")
def local_stop_command():
    """Stop the local Gradient Explorer instance."""
    result = stop_local()
    if not result["stopped"]:
        click.echo(_warning("No local Gradient Explorer instance is running.", bold=True))
        return

    click.echo(_success("Stopped local Gradient Explorer.", bold=True))


@local.command("sync")
@click.option(
    "--data-dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    default=None,
    help="Directory containing the local store to sync",
)
@click.option("--once", is_flag=True, help="Run one sync pass and exit")
@click.option("--interval", type=float, default=DEFAULT_SYNC_INTERVAL_S, show_default=True, help="Watch poll interval in seconds")
def local_sync_command(data_dir, once, interval):
    """Sync local runs and tensors to the hosted Gradient Explorer account."""
    if interval <= 0:
        raise click.ClickException("--interval must be greater than zero.")
    run_local_sync(data_dir=data_dir, once=once, interval=interval)


@main.command(name="_serve-local-instance", hidden=True)
@click.option("--app-port", type=int, required=True)
@click.option("--api-port", type=int, required=True)
@click.option(
    "--data-dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    required=True,
)
@click.option("--instance-id", type=str, required=True)
@click.option("--token", type=str, required=True)
def serve_local_instance_command(app_port, api_port, data_dir, instance_id, token):
    run_local_service(
        app_port=app_port,
        api_port=api_port,
        data_dir=data_dir,
        instance_id=instance_id,
        token=token,
    )


if __name__ == "__main__":
    main()
