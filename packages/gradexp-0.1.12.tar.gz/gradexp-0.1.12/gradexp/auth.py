import json
import os
import webbrowser
from pathlib import Path

import appdirs
import click
import requests

from . import local_instance


APP_NAME = "gradexp"
APP_AUTHOR = "GradientExplorer"
BASE_URL = "gradient-explorer.xyz"
_INTERNAL_USER_PREFIXES = ("user_", "user-user_", "user_user_")
_VISIBLE_KEY_BULLETS = 8


def get_base_url():
    return os.getenv("GRADEXP_BASE_URL", BASE_URL).rstrip("/")


def _get_explicit_service_base_url(env_key):
    explicit_base_url = os.getenv(env_key)
    if explicit_base_url:
        return explicit_base_url.rstrip("/")
    return None


def _env_prefers_local():
    value = os.getenv("GRADEXP_PREFER_LOCAL")
    if value is None or value == "":
        return True
    return value.strip().lower() not in {"0", "false", "no", "n", "off"}


def _get_active_local_instance(prefer_local=True, explicit_base_url=None):
    if not prefer_local or not _env_prefers_local():
        return None
    return local_instance.load_local_instance()


def _get_hosted_service_base_url(subdomain=""):
    base_url = get_base_url()
    if base_url.startswith("http://") or base_url.startswith("https://"):
        return base_url
    return f"https://{subdomain}{base_url}"


def get_api_base_url(prefer_local=True):
    explicit_base_url = _get_explicit_service_base_url("GRADEXP_API_BASE_URL")

    active_local_instance = _get_active_local_instance(
        prefer_local=prefer_local,
        explicit_base_url=explicit_base_url,
    )
    if active_local_instance:
        return active_local_instance.api_base_url

    if explicit_base_url:
        return explicit_base_url

    return _get_hosted_service_base_url("api.")


def get_web_base_url(prefer_local=True):
    explicit_base_url = _get_explicit_service_base_url("GRADEXP_WEB_BASE_URL")

    active_local_instance = _get_active_local_instance(
        prefer_local=prefer_local,
        explicit_base_url=explicit_base_url,
    )
    if active_local_instance:
        return active_local_instance.web_base_url

    if explicit_base_url:
        return explicit_base_url

    return _get_hosted_service_base_url()


def build_api_url(path, prefer_local=True):
    normalized_path = path if path.startswith("/") else f"/{path}"
    return f"{get_api_base_url(prefer_local=prefer_local)}{normalized_path}"


def get_local_data_dir():
    configured_path = os.getenv("GRADEXP_LOCAL_DATA_DIR")
    if configured_path:
        return Path(configured_path).expanduser()
    return local_instance.get_default_local_data_dir()


def is_loopback_url(url):
    return local_instance.is_loopback_url(url)


def get_config_dir():
    return appdirs.user_config_dir(APP_NAME, APP_AUTHOR)


def get_token_path():
    config_dir = get_config_dir()
    return os.path.join(config_dir, "secrets.json")


def save_token(token):
    config_dir = get_config_dir()
    os.makedirs(config_dir, exist_ok=True)

    token_path = get_token_path()
    with open(token_path, "w") as file:
        json.dump({"api_key": token}, file)

    os.chmod(token_path, 0o600)


def load_saved_token():
    token_path = get_token_path()
    if not os.path.exists(token_path):
        return None

    try:
        with open(token_path, "r") as file:
            data = json.load(file)
    except (json.JSONDecodeError, IOError):
        return None

    return data.get("api_key")


def load_token(prefer_local=True):
    active_local_instance = _get_active_local_instance(
        prefer_local=prefer_local,
        explicit_base_url=_get_explicit_service_base_url("GRADEXP_API_BASE_URL"),
    )
    if active_local_instance:
        return active_local_instance.token

    env_token = os.getenv("GRADEXP_API_KEY")
    if env_token:
        return env_token

    return load_saved_token()


def validate_api_key(api_key, debug=False):
    try:
        url = build_api_url("/api/v1/me", prefer_local=False)
        headers = {"Authorization": f"Bearer {api_key}"}

        if debug:
            click.echo(f"DEBUG: Request URL: {url}")
            click.echo(f"DEBUG: Request Headers: Authorization: Bearer {api_key[:4]}...{api_key[-4:]}")

        response = requests.get(url, headers=headers)

        if debug:
            click.echo(f"DEBUG: Response Status: {response.status_code}")
            click.echo(f"DEBUG: Response Body: {response.text}")

        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as error:
        if debug:
            click.echo(f"DEBUG: Request failed: {error}")
        return None


def _clean_text(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _looks_like_internal_user_value(value):
    text = _clean_text(value)
    if not text:
        return False
    lowered = text.lower()
    return any(lowered.startswith(prefix) for prefix in _INTERNAL_USER_PREFIXES)


def _extract_email_address(value):
    if isinstance(value, str):
        return _clean_text(value)
    if not isinstance(value, dict):
        return None
    for key in ("email_address", "emailAddress", "email"):
        email = _clean_text(value.get(key))
        if email:
            return email
    return None


def _get_primary_email(user_info):
    if not isinstance(user_info, dict):
        return None

    for key in ("primary_email_address", "primaryEmailAddress", "email_address", "emailAddress", "email"):
        email = _extract_email_address(user_info.get(key))
        if email:
            return email

    primary_id = _clean_text(
        user_info.get("primary_email_address_id") or user_info.get("primaryEmailAddressId")
    )
    entries = user_info.get("email_addresses") or user_info.get("emailAddresses")
    if not isinstance(entries, list):
        return None

    fallback_email = None
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        email = _extract_email_address(entry)
        if not email:
            continue
        if fallback_email is None:
            fallback_email = email
        entry_id = _clean_text(entry.get("id"))
        if primary_id and entry_id == primary_id:
            return email
    return fallback_email


def _get_user_display_name(user_info):
    if not isinstance(user_info, dict):
        return ""

    for key in ("full_name", "fullName", "name"):
        value = _clean_text(user_info.get(key))
        if value and not _looks_like_internal_user_value(value):
            return value

    first_name = _clean_text(user_info.get("first_name") or user_info.get("firstName"))
    last_name = _clean_text(user_info.get("last_name") or user_info.get("lastName"))
    joined_name = " ".join(part for part in (first_name, last_name) if part)
    if joined_name:
        return joined_name

    username = _clean_text(user_info.get("username"))
    if username and not _looks_like_internal_user_value(username):
        return username

    email = _get_primary_email(user_info)
    if email:
        return email

    for key in ("id", "userId"):
        value = _clean_text(user_info.get(key))
        if value and not _looks_like_internal_user_value(value):
            return value

    return ""


def _format_api_key_progress(length):
    if length <= 0:
        return ""
    masked = "*" * min(length, _VISIBLE_KEY_BULLETS)
    if length <= _VISIBLE_KEY_BULLETS:
        return masked
    return f"{masked} ({length} chars)"


def _render_api_key_prompt(length):
    progress = _format_api_key_progress(length)
    suffix = f" {progress}" if progress else ""
    click.echo(f"\rPaste your API key and press Enter:{suffix}", nl=False)


def _prompt_api_key():
    buffer = []
    _render_api_key_prompt(0)
    while True:
        char = click.getchar(echo=False)
        if char in ("\r", "\n"):
            break
        if char in ("\b", "\x7f"):
            if buffer:
                buffer.pop()
        elif char.isprintable():
            buffer.append(char)
        _render_api_key_prompt(len(buffer))

    click.echo()
    api_key = "".join(buffer).strip()
    return api_key or None


def login_flow(debug=False):
    auth_url = f"{get_web_base_url(prefer_local=False)}/authorize"

    opened = False
    try:
        opened = webbrowser.open(auth_url)
    except Exception:
        pass

    if opened:
        click.echo(f"Opening {auth_url} in your default browser...")
    else:
        click.echo("Could not open browser automatically.")
        click.echo(f"Visit this URL to get your API key:\n\n    {auth_url}\n")

    api_key = _prompt_api_key()
    if not api_key:
        click.echo("No API key provided. Login failed.")
        return

    user_info = validate_api_key(api_key, debug=debug)
    if user_info:
        save_token(api_key)
        display_name = _get_user_display_name(user_info)
        label = f" as {display_name}" if display_name else ""
        click.secho(f"Logged in{label}. API key saved.", fg="green")
        return

    click.secho("Error: Invalid API Key", fg="red")


def check_login():
    token = load_token()
    if token:
        click.echo(f"Logged in with token: {token[:4]}..." + "*" * 10)
        return True

    click.echo("Not logged in. Please run `gradexp login`.")
    return False
