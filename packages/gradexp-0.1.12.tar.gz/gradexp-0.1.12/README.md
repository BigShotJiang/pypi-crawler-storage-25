# gradexp

Like wandb, but for tensors.

`gradexp` logs tensors from Python and lets you inspect them in Gradient Explorer, either in the hosted app or a local viewer.

## Quickstart

```bash
pip install gradexp
gradexp login
# For local mode:
gradexp local open
```

Example:

```python
import gradexp
import numpy as np

gradexp.init(project_name="examples", run_name="hello-gradexp")

for step in range(10):
    tensor = np.random.randn(224, 224, 3).astype(np.float32)
    gradexp.log(tensor, name="tensor")
```

When `gradexp.init()` succeeds, it prints a run URL. If a local instance is running, data is routed there automatically.

## Common CLI Commands

```bash
gradexp login
gradexp local open
gradexp local start
gradexp local status
gradexp local stop
gradexp local sync
```