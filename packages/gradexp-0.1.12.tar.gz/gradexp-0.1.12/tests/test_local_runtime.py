import os
import tempfile
import unittest
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

from gradexp import auth
from gradexp.client import Client


@dataclass
class FakeLocalInstance:
    api_base_url: str = "http://127.0.0.1:43001"
    web_base_url: str = "http://127.0.0.1:43000"
    token: str = "gradexp-local-token"


class TestLocalRuntimeHelpers(unittest.TestCase):
    def test_get_local_data_dir_defaults_to_home_dot_gradexp_data(self):
        with patch.dict(os.environ, {"HOME": "/Users/tester"}, clear=False):
            os.environ.pop("GRADEXP_LOCAL_DATA_DIR", None)
            data_dir = auth.get_local_data_dir()

        self.assertEqual(data_dir, Path("/Users/tester/.gradexp-data"))

    def test_get_local_data_dir_honors_env_override(self):
        with patch.dict(
            os.environ,
            {"HOME": "/Users/tester", "GRADEXP_LOCAL_DATA_DIR": "~/custom-gradexp-data"},
            clear=False,
        ):
            data_dir = auth.get_local_data_dir()

        self.assertEqual(data_dir, Path("/Users/tester/custom-gradexp-data"))

    def test_is_loopback_url(self):
        self.assertTrue(auth.is_loopback_url("http://127.0.0.1:3002"))
        self.assertTrue(auth.is_loopback_url("http://localhost:3002"))
        self.assertFalse(auth.is_loopback_url("https://api.gradient-explorer.xyz"))

    def test_prefers_active_local_instance_urls_when_no_explicit_env_is_set(self):
        with patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()):
            self.assertEqual(auth.get_api_base_url(), "http://127.0.0.1:43001")
            self.assertEqual(auth.get_web_base_url(), "http://127.0.0.1:43000")

    def test_active_local_instance_overrides_explicit_env_by_default(self):
        env = {
            "GRADEXP_API_BASE_URL": "https://api.example.com",
            "GRADEXP_WEB_BASE_URL": "https://app.example.com",
        }
        with patch.dict(os.environ, env, clear=False), \
             patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()):
            self.assertEqual(auth.get_api_base_url(), "http://127.0.0.1:43001")
            self.assertEqual(auth.get_web_base_url(), "http://127.0.0.1:43000")

    def test_can_force_remote_urls_even_with_active_local_instance(self):
        env = {
            "GRADEXP_API_BASE_URL": "https://api.example.com",
            "GRADEXP_WEB_BASE_URL": "https://app.example.com",
            "GRADEXP_PREFER_LOCAL": "0",
        }
        with patch.dict(os.environ, env, clear=False), \
             patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()):
            self.assertEqual(auth.get_api_base_url(), "https://api.example.com")
            self.assertEqual(auth.get_web_base_url(), "https://app.example.com")

    def test_load_token_uses_active_local_instance_before_saved_token(self):
        with patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()), \
             patch("gradexp.auth.get_token_path", return_value="/nonexistent-token-path"):
            self.assertEqual(auth.load_token(), "gradexp-local-token")

    def test_load_token_uses_active_local_instance_before_env_token_when_auto_discovered(self):
        with patch.dict(os.environ, {"GRADEXP_API_KEY": "hosted-token"}, clear=True), \
             patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()):
            self.assertEqual(auth.load_token(), "gradexp-local-token")

    def test_load_token_prefers_active_local_instance_even_when_remote_env_is_set(self):
        env = {
            "GRADEXP_API_BASE_URL": "https://api.example.com",
            "GRADEXP_API_KEY": "hosted-token",
        }
        with patch.dict(os.environ, env, clear=True), \
             patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()):
            self.assertEqual(auth.load_token(), "gradexp-local-token")

    def test_load_token_can_force_remote_with_prefer_local_env_disabled(self):
        env = {
            "GRADEXP_API_BASE_URL": "https://api.example.com",
            "GRADEXP_API_KEY": "hosted-token",
            "GRADEXP_PREFER_LOCAL": "off",
        }
        with patch.dict(os.environ, env, clear=True), \
             patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()):
            self.assertEqual(auth.load_token(), "hosted-token")

    def test_load_token_can_ignore_active_local_instance(self):
        with tempfile.NamedTemporaryFile("w+", delete=False) as token_file:
            token_file.write('{"api_key": "hosted-token"}')
            token_file.flush()
            token_path = token_file.name

        try:
            with patch("gradexp.local_instance.load_local_instance", return_value=FakeLocalInstance()), \
                 patch("gradexp.auth.get_token_path", return_value=token_path):
                self.assertEqual(auth.load_token(prefer_local=False), "hosted-token")
        finally:
            os.unlink(token_path)


class TestClientLocalRuntimeStatus(unittest.TestCase):
    def test_logs_local_backend_status_once(self):
        client = Client()
        response = MagicMock()
        response.raise_for_status.return_value = None
        response.json.return_value = {
            "version": "local-dev",
            "mode": "local",
            "data_dir": "/tmp/gradexp-data",
        }

        with patch("gradexp.auth.get_api_base_url", return_value="http://127.0.0.1:3002"), \
             patch("gradexp.auth.get_web_base_url", return_value="http://127.0.0.1:3001"), \
             patch.object(client._session, "get", return_value=response) as mock_get, \
             patch("gradexp.client._term_log") as mock_log:
            client._maybe_log_local_backend_status()
            client._maybe_log_local_backend_status()

        mock_get.assert_called_once_with("http://127.0.0.1:3002/version", timeout=1.0)
        mock_log.assert_called_once()
        self.assertIn("/tmp/gradexp-data", mock_log.call_args[0][0])

    def test_skips_local_probe_for_remote_backend(self):
        client = Client()

        with patch("gradexp.auth.get_api_base_url", return_value="https://api.gradient-explorer.xyz"), \
             patch("gradexp.auth.get_web_base_url", return_value="https://gradient-explorer.xyz"), \
             patch.object(client._session, "get") as mock_get, \
             patch("gradexp.client._term_log") as mock_log:
            client._maybe_log_local_backend_status()

        mock_get.assert_not_called()
        mock_log.assert_not_called()


if __name__ == "__main__":
    unittest.main()
