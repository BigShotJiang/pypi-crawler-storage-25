import unittest
from unittest.mock import patch, MagicMock
import json
import base64
import numpy as np
import requests
import sys
import os

# Ensure we can import gradexp from current directory
sys.path.append(os.getcwd())

import gradexp
import gradexp.client as client


class FakeScalar:
    def __init__(self, value):
        self.value = value

    def item(self):
        return self.value


class FakeGrad:
    def __init__(self, value):
        self.value = value

    def norm(self, _order):
        return FakeScalar(self.value)


class FakeParam:
    def __init__(self, grad_value):
        self.grad = FakeGrad(grad_value)


class FakeModel:
    def __init__(self, named_params):
        self._named_params = named_params

    def named_parameters(self):
        return list(self._named_params)

class FakeLoggedTensor:
    def __init__(self, shape):
        self.shape = shape

class FakeLoggedParam(FakeLoggedTensor):
    def __init__(self, shape, grad=None):
        super().__init__(shape)
        self.grad = grad

class TestGradExp(unittest.TestCase):
    @patch('gradexp.auth.load_token')
    @patch('requests.Session.patch')
    @patch('requests.Session.post')
    def test_full_flow(self, mock_post, mock_patch, mock_load_token):
        client._client = client.Client()

        # Setup mocks
        mock_load_token.return_value = "test_api_key"
        patch_response = MagicMock()
        patch_response.status_code = 200
        patch_response.json.return_value = {"status": "updated"}
        mock_patch.return_value = patch_response
        
        # Mock Init Response (201 Created)
        init_response = MagicMock()
        init_response.status_code = 201
        init_response.json.return_value = {
            "run_id": "run_uuid_123",
            "project_id": "project_uuid_456",
            "name": "test-run",
            "status": "active"
        }
        
        # Mock Upload Response (200 OK)
        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.json.return_value = {"status": "success"}
        
        # Configure side_effect to return different responses based on call order or inspection
        # But simpler: just cycle them if we know the order, or make the mock return init first then upload
        # Since we use the same session object, requests.Session.post is called
        mock_post.side_effect = [init_response, upload_response]

        # 1. run gradexp.init()
        gradexp.init(project_name="test-project", run_name="test-run")
        
        # Verify init call
        self.assertEqual(mock_post.call_count, 1)
        init_call_args = mock_post.call_args_list[0]
        self.assertIn('/api/v1/runs', init_call_args[0][0])
        self.assertEqual(init_call_args[1]['headers']['Authorization'], 'Bearer test_api_key')
        
        payload = init_call_args[1]['json']
        self.assertEqual(payload['project_name'], 'test-project')
        self.assertEqual(payload['run_name'], 'test-run')
        
        # Mock Tensor Creation Response (200 OK)
        tensor_response = MagicMock()
        tensor_response.status_code = 200
        tensor_response.json.return_value = {"tensor_id": "tensor_uuid_123"}
        
        # Update side_effect for subsequent calls
        # 2nd call: _ensure_tensor (POST /runs/.../tensors)
        # 3rd call: batch upload (POST /tensors/.../steps)
        mock_post.side_effect = [tensor_response, upload_response]

        # 2. run gradexp.log()
        data = np.random.rand(3, 224, 224).astype(np.float32)
        gradexp.log(data)
        gradexp.finish()

        # Verify calls
        self.assertEqual(mock_post.call_count, 3) 
        
        # Verify tensor creation call
        tensor_call_args = mock_post.call_args_list[1]
        self.assertIn('/api/v1/runs/run_uuid_123/tensors', tensor_call_args[0][0])
        
        # Verify log call
        log_call_args = mock_post.call_args_list[2]
        self.assertIn('/api/v1/tensors/tensor_uuid_123/steps', log_call_args[0][0])
        self.assertIn('data', log_call_args[1])
        self.assertEqual(log_call_args[1]['headers']['Authorization'], 'Bearer test_api_key')
        payload = json.loads(log_call_args[1]['data'].decode('utf-8'))
        self.assertEqual(payload["steps"][0]["step"], 0)

        print("\nTest passed successfully!")

    @patch('gradexp.auth.load_token')
    @patch('requests.Session.patch')
    @patch('requests.Session.post')
    def test_log_gradient_stats_explicit_step_reaches_backend(self, mock_post, mock_patch, mock_load_token):
        client._client = client.Client()

        mock_load_token.return_value = "test_api_key"
        patch_response = MagicMock()
        patch_response.status_code = 200
        patch_response.json.return_value = {"status": "updated"}
        mock_patch.return_value = patch_response

        init_response = MagicMock()
        init_response.status_code = 201
        init_response.json.return_value = {
            "run_id": "run_uuid_123",
            "project_id": "project_uuid_456",
            "name": "test-run",
            "status": "active"
        }

        tensor_response = MagicMock()
        tensor_response.status_code = 200
        tensor_response.json.return_value = {"tensor_id": "tensor_uuid_123"}

        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.json.return_value = {"status": "success"}

        mock_post.side_effect = [init_response, tensor_response, upload_response]

        gradexp.init(project_name="test-project", run_name="test-run")

        model = FakeModel([
            ("layers.0.weight", FakeParam(3.5)),
        ])
        gradexp.log_gradient_stats(model, step=7, stats=["grad_l2"])
        gradexp.finish()

        self.assertEqual(mock_post.call_count, 3)

        log_call_args = mock_post.call_args_list[2]
        self.assertIn('/api/v1/tensors/tensor_uuid_123/steps', log_call_args[0][0])
        payload = json.loads(log_call_args[1]['data'].decode('utf-8'))
        self.assertEqual(payload["steps"][0]["step"], 7)

        logged_values = np.frombuffer(
            base64.b64decode(payload["steps"][0]["value"]),
            dtype=np.float32,
        )
        np.testing.assert_allclose(logged_values, np.array([3.5], dtype=np.float32))

    @patch('gradexp.auth.load_token')
    @patch('gradexp.auth.get_web_base_url', return_value='http://127.0.0.1:3000')
    @patch('gradexp.auth.get_api_base_url', return_value='http://127.0.0.1:3001')
    @patch('requests.Session.get')
    @patch('requests.Session.patch')
    @patch('requests.Session.post')
    def test_log_gradient_stats_includes_local_step_metadata_for_local_backend(
        self,
        mock_post,
        mock_patch,
        mock_get,
        _mock_get_api_base_url,
        _mock_get_web_base_url,
        mock_load_token,
    ):
        client._client = client.Client()

        mock_load_token.return_value = "gradexp-local-token"
        version_response = MagicMock()
        version_response.status_code = 200
        version_response.raise_for_status.return_value = None
        version_response.json.return_value = {
            "version": "local-dev",
            "mode": "local",
            "data_dir": "/tmp/gradexp-data",
        }
        mock_get.return_value = version_response

        patch_response = MagicMock()
        patch_response.status_code = 200
        patch_response.json.return_value = {"status": "updated"}
        mock_patch.return_value = patch_response

        init_response = MagicMock()
        init_response.status_code = 201
        init_response.json.return_value = {
            "run_id": "run_uuid_123",
            "project_id": "project_uuid_456",
            "name": "test-run",
            "status": "active"
        }

        tensor_response = MagicMock()
        tensor_response.status_code = 200
        tensor_response.json.return_value = {"tensor_id": "tensor_uuid_123"}

        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.json.return_value = {"status": "success"}

        mock_post.side_effect = [init_response, tensor_response, upload_response]

        gradexp.init(project_name="test-project", run_name="test-run")
        model = FakeModel([
            ("layers.0.weight", FakeParam(3.5)),
        ])
        gradexp.log_gradient_stats(model, step=7, stats=["grad_l2"])
        gradexp.finish()

        log_call_args = mock_post.call_args_list[2]
        payload = json.loads(log_call_args[1]['data'].decode('utf-8'))
        self.assertEqual(payload["steps"][0]["step"], 7)
        self.assertIn("local_step_metadata", payload["steps"][0])
        self.assertEqual(payload["steps"][0]["local_step_metadata"]["kind"], "gradient_stats")
        self.assertEqual(payload["steps"][0]["local_step_metadata"]["step"], 7)

    @patch('gradexp.auth.load_token')
    @patch('requests.Session.patch')
    @patch('requests.Session.post')
    def test_init_precision_fp16_uploads_two_bytes_per_value(self, mock_post, mock_patch, mock_load_token):
        client._client = client.Client()

        mock_load_token.return_value = "test_api_key"
        patch_response = MagicMock()
        patch_response.status_code = 200
        patch_response.json.return_value = {"status": "updated"}
        mock_patch.return_value = patch_response

        init_response = MagicMock()
        init_response.status_code = 201
        init_response.json.return_value = {
            "run_id": "run_uuid_123",
            "project_id": "project_uuid_456",
        }

        tensor_response = MagicMock()
        tensor_response.status_code = 200
        tensor_response.json.return_value = {"tensor_id": "tensor_uuid_123"}

        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.json.return_value = {"status": "success"}

        mock_post.side_effect = [init_response, tensor_response, upload_response]

        gradexp.init(project_name="test-project", run_name="test-run", precision="fp16")
        gradexp.log(np.array([1.5, -2.0, 3.25], dtype=np.float32), name="weights")
        gradexp.finish()

        tensor_call_args = mock_post.call_args_list[1]
        self.assertEqual(tensor_call_args[1]["json"]["dtype"], "float16")

        upload_call_args = mock_post.call_args_list[2]
        payload = json.loads(upload_call_args[1]["data"].decode("utf-8"))
        raw_bytes = base64.b64decode(payload["steps"][0]["value"])
        self.assertEqual(len(raw_bytes), 3 * 2)
        np.testing.assert_allclose(
            np.frombuffer(raw_bytes, dtype=np.float16).astype(np.float32),
            np.array([1.5, -2.0, 3.25], dtype=np.float32),
        )

    @patch('gradexp.auth.load_token')
    @patch('requests.Session.patch')
    @patch('requests.Session.post')
    def test_init_precision_bf16_uploads_two_bytes_per_value(self, mock_post, mock_patch, mock_load_token):
        client._client = client.Client()

        mock_load_token.return_value = "test_api_key"
        patch_response = MagicMock()
        patch_response.status_code = 200
        patch_response.json.return_value = {"status": "updated"}
        mock_patch.return_value = patch_response

        init_response = MagicMock()
        init_response.status_code = 201
        init_response.json.return_value = {
            "run_id": "run_uuid_123",
            "project_id": "project_uuid_456",
        }

        tensor_response = MagicMock()
        tensor_response.status_code = 200
        tensor_response.json.return_value = {"tensor_id": "tensor_uuid_123"}

        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.json.return_value = {"status": "success"}

        mock_post.side_effect = [init_response, tensor_response, upload_response]

        values = np.array([1.1, -3.5, 256.25], dtype=np.float32)
        gradexp.init(project_name="test-project", run_name="test-run", precision="bf16")
        gradexp.log(values, name="weights")
        gradexp.finish()

        tensor_call_args = mock_post.call_args_list[1]
        self.assertEqual(tensor_call_args[1]["json"]["dtype"], "bfloat16")

        upload_call_args = mock_post.call_args_list[2]
        payload = json.loads(upload_call_args[1]["data"].decode("utf-8"))
        raw_bytes = base64.b64decode(payload["steps"][0]["value"])
        self.assertEqual(len(raw_bytes), values.size * 2)
        np.testing.assert_array_equal(
            np.frombuffer(raw_bytes, dtype=np.uint16),
            client._float32_to_bfloat16_uint16(values),
        )

    @patch('gradexp.client._client.log')
    def test_log_model_tensors_logs_weights_and_updates_with_explicit_step(self, mock_log):
        model = FakeModel([
            (
                "layers.0.weight",
                FakeLoggedParam(shape=(2, 3), grad=FakeLoggedTensor(shape=(2, 3))),
            ),
            (
                "layers.0.bias",
                FakeLoggedParam(shape=(3,), grad=FakeLoggedTensor(shape=(3,))),
            ),
        ])

        gradexp.log_model_tensors(model, step=11)

        self.assertEqual(mock_log.call_count, 4)
        logged_names = [call.kwargs["name"] for call in mock_log.call_args_list]
        self.assertEqual(
            logged_names,
            [
                "weights/layers.0.weight",
                "updates/layers.0.weight",
                "weights/layers.0.bias",
                "updates/layers.0.bias",
            ],
        )
        for call in mock_log.call_args_list:
            self.assertEqual(call.kwargs["step"], 11)

    @patch('gradexp.client._term_log')
    @patch('gradexp.client._client.log')
    def test_log_model_tensors_rejects_oversize_tensors(self, mock_log, mock_term_log):
        model = FakeModel([
            (
                "layers.0.weight",
                FakeLoggedParam(shape=(client._MAX_TENSOR_ELEMENTS + 1,), grad=FakeLoggedTensor(shape=(1,))),
            ),
        ])

        gradexp.log_model_tensors(model, step=3)

        mock_log.assert_not_called()
        self.assertIn("only for tiny models", mock_term_log.call_args[0][0])
        self.assertIn(client._MAX_TENSOR_ELEMENTS_LABEL, mock_term_log.call_args[0][0])

    @patch('gradexp.client._term_log')
    def test_log_rejects_oversize_tensors(self, mock_term_log):
        oversize_tensor = np.broadcast_to(
            np.array(1, dtype=np.float32),
            (client._MAX_TENSOR_ELEMENTS + 1,),
        )
        log_client = client.Client()
        log_client.active = True

        log_client.log(oversize_tensor, name="too-big")

        self.assertTrue(log_client._upload_queue.empty())
        self.assertIn("too large to log", mock_term_log.call_args[0][0])
        self.assertIn(client._MAX_TENSOR_ELEMENTS_LABEL, mock_term_log.call_args[0][0])

    @patch('requests.Session.post')
    def test_upload_batch_falls_back_to_raw_single_step_after_413(self, mock_post):
        log_client = client.Client()
        log_client.api_key = "test_api_key"
        log_client.active = True

        batch_response = MagicMock()
        batch_response.status_code = 413
        batch_error = requests.exceptions.HTTPError("payload too large")
        batch_error.response = batch_response
        batch_response.raise_for_status.side_effect = batch_error

        raw_response = MagicMock()
        raw_response.status_code = 200
        raw_response.raise_for_status.return_value = None

        mock_post.side_effect = [batch_response, raw_response]

        log_client._upload_batch(
            "tensor_uuid_123",
            [{"step": 5, "content": b"\x00\x01\x02"}],
        )

        self.assertEqual(mock_post.call_count, 2)
        self.assertIn('/api/v1/tensors/tensor_uuid_123/steps', mock_post.call_args_list[0][0][0])
        self.assertIn('/api/v1/tensors/tensor_uuid_123/step?step=5', mock_post.call_args_list[1][0][0])
        self.assertEqual(
            mock_post.call_args_list[1][1]['headers']['Content-Type'],
            'application/octet-stream',
        )
        self.assertEqual(mock_post.call_args_list[1][1]['data'], b"\x00\x01\x02")
        self.assertEqual(log_client._bytes_uploaded, 3)
        self.assertEqual(log_client._tensors_uploaded, 1)

if __name__ == '__main__':
    unittest.main()
