r"""
 __  __                           _
|  \/  | ___ _ __ ___   ___  _ __(_)
| |\/| |/ _ \ '_ ` _ \ / _ \| '__| |
| |  | |  __/ | | | | | (_) | |  | |
|_|  |_|\___|_| |_| |_|\___/|_|  |_|
                  perfectam memoriam
                       memorilabs.ai
"""

from uuid import uuid4

from memori._utils import generate_uniq
from memori.storage._base import (
    BaseConversation,
    BaseConversationMessage,
    BaseConversationMessages,
    BaseEntity,
    BaseEntityFact,
    BaseKnowledgeGraph,
    BaseProcess,
    BaseProcessAttribute,
    BaseSchema,
    BaseSchemaVersion,
    BaseSession,
    BaseStorageAdapter,
)
from memori.storage._registry import Registry
from memori.storage.migrations._mysql import migrations


class Conversation(BaseConversation):
    def __init__(self, conn: BaseStorageAdapter):
        super().__init__(conn)
        self.message = ConversationMessage(conn)
        self.messages = ConversationMessages(conn)

    def create(self, session_id, timeout_minutes: int):
        existing = (
            self.conn.execute(
                """
                SELECT c.id,
                       COALESCE(MAX(m.date_created), c.date_created) as last_activity
                  FROM memori_conversation c
                  LEFT JOIN memori_conversation_message m ON m.conversation_id = c.id
                 WHERE c.session_id = %s
                 GROUP BY c.id, c.date_created
                """,
                (session_id,),
            )
            .mappings()
            .fetchone()
        )

        if existing:
            result = self.conn.execute(
                """
                SELECT TIMESTAMPDIFF(MINUTE, %s, CURRENT_TIMESTAMP) as minutes_since_activity
                """,
                (existing["last_activity"],),
            ).fetchone()

            if result[0] <= timeout_minutes:
                return existing["id"]

        uuid = uuid4()
        self.conn.execute(
            """
            INSERT IGNORE INTO memori_conversation(
                uuid,
                session_id
            ) VALUES (
                %s,
                %s
            )
            """,
            (uuid, session_id),
        )
        self.conn.commit()

        return (
            self.conn.execute(
                """
                SELECT id
                  FROM memori_conversation
                 WHERE session_id = %s
                """,
                (session_id,),
            )
            .mappings()
            .fetchone()
            .get("id", None)
        )

    def update(self, id: int, summary: str):
        if summary is None:
            return self

        self.conn.execute(
            """
            UPDATE memori_conversation
               SET summary = %s
             WHERE id = %s
            """,
            (
                summary,
                id,
            ),
        )
        self.conn.commit()

        return self

    def read(self, id: int) -> dict | None:
        result = (
            self.conn.execute(
                """
                SELECT id, uuid, session_id, summary, date_created, date_updated
                  FROM memori_conversation
                 WHERE id = %s
                """,
                (id,),
            )
            .mappings()
            .fetchone()
        )

        if result is None:
            return None

        return dict(result)

    def read_id_by_session_id(self, session_id) -> int | None:
        result = (
            self.conn.execute(
                """
                SELECT id
                  FROM memori_conversation
                 WHERE session_id = %s
                """,
                (session_id,),
            )
            .mappings()
            .fetchone()
        )
        if result is None:
            return None
        return result.get("id", None)


class ConversationMessage(BaseConversationMessage):
    def create(self, conversation_id: int, role: str, type: str, content: str):
        self.conn.execute(
            """
            INSERT INTO memori_conversation_message(
                uuid,
                conversation_id,
                role,
                type,
                content
            ) VALUES (
                %s,
                %s,
                %s,
                %s,
                %s
            )
            """,
            (
                uuid4(),
                conversation_id,
                role,
                type,
                content,
            ),
        )


class ConversationMessages(BaseConversationMessages):
    def read(self, conversation_id: int):
        results = (
            self.conn.execute(
                """
                SELECT role,
                       content
                  FROM memori_conversation_message
                 WHERE conversation_id = %s
                """,
                (conversation_id,),
            )
            .mappings()
            .fetchall()
        )

        messages = []
        for result in results:
            messages.append({"content": result["content"], "role": result["role"]})

        return messages


class KnowledgeGraph(BaseKnowledgeGraph):
    def create(self, entity_id: int, semantic_triples: list):
        if semantic_triples is None or len(semantic_triples) == 0:
            return self

        for semantic_triple in semantic_triples:
            uniq = generate_uniq(
                [semantic_triple.subject_name, semantic_triple.subject_type]
            )

            self.conn.execute(
                """
                INSERT IGNORE INTO memori_subject(
                    uuid,
                    name,
                    type,
                    uniq
                ) VALUES (
                    %s,
                    %s,
                    %s,
                    %s
                )
                """,
                (
                    uuid4(),
                    semantic_triple.subject_name,
                    semantic_triple.subject_type,
                    uniq,
                ),
            )
            self.conn.commit()

            subject_id = (
                self.conn.execute(
                    """
                    SELECT id
                      FROM memori_subject
                     WHERE uniq = %s
                    """,
                    (uniq,),
                )
                .mappings()
                .fetchone()
                .get("id", None)
            )

            uniq = generate_uniq([semantic_triple.predicate])

            self.conn.execute(
                """
                INSERT IGNORE INTO memori_predicate(
                    uuid,
                    content,
                    uniq
                ) VALUES (
                    %s,
                    %s,
                    %s
                )
                """,
                (
                    uuid4(),
                    semantic_triple.predicate,
                    uniq,
                ),
            )
            self.conn.commit()

            predicate_id = (
                self.conn.execute(
                    """
                    SELECT id
                      FROM memori_predicate
                     WHERE uniq = %s
                    """,
                    (uniq,),
                )
                .mappings()
                .fetchone()
                .get("id", None)
            )

            uniq = generate_uniq(
                [semantic_triple.object_name, semantic_triple.object_type]
            )

            self.conn.execute(
                """
                INSERT IGNORE INTO memori_object(
                    uuid,
                    name,
                    type,
                    uniq
                ) VALUES (
                    %s,
                    %s,
                    %s,
                    %s
                )
                """,
                (
                    uuid4(),
                    semantic_triple.object_name,
                    semantic_triple.object_type,
                    uniq,
                ),
            )
            self.conn.commit()

            object_id = (
                self.conn.execute(
                    """
                    SELECT id
                      FROM memori_object
                     WHERE uniq = %s
                    """,
                    (uniq,),
                )
                .mappings()
                .fetchone()
                .get("id", None)
            )

            if (
                entity_id is not None
                and subject_id is not None
                and predicate_id is not None
                and object_id is not None
            ):
                self.conn.execute(
                    """
                    INSERT INTO memori_knowledge_graph(
                        uuid,
                        entity_id,
                        subject_id,
                        predicate_id,
                        object_id,
                        num_times,
                        date_last_time
                    ) VALUES (
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        1,
                        current_timestamp()
                    )
                    ON DUPLICATE KEY UPDATE
                        num_times = num_times + 1,
                        date_last_time = current_timestamp()
                    """,
                    (uuid4(), entity_id, subject_id, predicate_id, object_id),
                )
                self.conn.commit()

        return self

    def delete_by_entity(self, entity_id: int):
        self.conn.execute(
            """
            DELETE
              FROM memori_knowledge_graph
             WHERE entity_id = %s
            """,
            (entity_id,),
        )
        self.conn.execute(
            """
            DELETE
              FROM memori_subject
             WHERE NOT EXISTS (
                   SELECT 1
                     FROM memori_knowledge_graph
                    WHERE memori_knowledge_graph.subject_id = memori_subject.id
             )
            """
        )
        self.conn.execute(
            """
            DELETE
              FROM memori_predicate
             WHERE NOT EXISTS (
                   SELECT 1
                     FROM memori_knowledge_graph
                    WHERE memori_knowledge_graph.predicate_id = memori_predicate.id
             )
            """
        )
        self.conn.execute(
            """
            DELETE
              FROM memori_object
             WHERE NOT EXISTS (
                   SELECT 1
                     FROM memori_knowledge_graph
                    WHERE memori_knowledge_graph.object_id = memori_object.id
             )
            """
        )
        self.conn.commit()
        return self


class Entity(BaseEntity):
    def create(self, external_id: str):
        self.conn.execute(
            """
            INSERT IGNORE INTO memori_entity(
                uuid,
                external_id
            ) VALUES (
                %s,
                %s
            )
            """,
            (uuid4(), external_id),
        )
        self.conn.commit()

        return (
            self.conn.execute(
                """
                SELECT id
                  FROM memori_entity
                 WHERE external_id = %s
                """,
                (external_id,),
            )
            .mappings()
            .fetchone()
            .get("id", None)
        )


class EntityFact(BaseEntityFact):
    def create(
        self,
        entity_id: int,
        facts: list,
        fact_embeddings: list | None = None,
        conversation_id: int | None = None,
    ):
        if facts is None or len(facts) == 0:
            return self

        from memori.embeddings import format_embedding_for_db

        for i, fact in enumerate(facts):
            embedding = (
                fact_embeddings[i]
                if fact_embeddings and i < len(fact_embeddings)
                else []
            )
            embedding_formatted = format_embedding_for_db(embedding, "mysql")
            uniq = generate_uniq(fact)

            self.conn.execute(
                """
                INSERT INTO memori_entity_fact(
                    uuid,
                    entity_id,
                    content,
                    content_embedding,
                    num_times,
                    date_last_time,
                    uniq
                ) VALUES (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    current_timestamp(),
                    %s
                )
                ON DUPLICATE KEY UPDATE
                    num_times = num_times + 1,
                    date_last_time = current_timestamp()
                """,
                (
                    uuid4(),
                    entity_id,
                    fact,
                    embedding_formatted,
                    1,
                    uniq,
                ),
            )

            if conversation_id is not None:
                fact_row = (
                    self.conn.execute(
                        """
                        SELECT id
                          FROM memori_entity_fact
                         WHERE entity_id = %s
                           AND uniq = %s
                        """,
                        (entity_id, uniq),
                    )
                    .mappings()
                    .fetchone()
                )
                fact_id = fact_row.get("id") if fact_row else None
                if fact_id is not None:
                    self.conn.execute(
                        """
                        INSERT IGNORE INTO memori_entity_fact_mention(
                            uuid,
                            entity_id,
                            fact_id,
                            conversation_id
                        ) VALUES (
                            %s,
                            %s,
                            %s,
                            %s
                        )
                        """,
                        (uuid4(), entity_id, fact_id, conversation_id),
                    )

        self.conn.commit()

        return self

    def get_embeddings(self, entity_id: int, limit: int = 1000):
        return (
            self.conn.execute(
                """
                SELECT id,
                       content_embedding
                  FROM memori_entity_fact
                 WHERE entity_id = %s
                 ORDER BY date_last_time DESC,
                          num_times DESC,
                          id DESC
                 LIMIT %s
                """,
                (entity_id, limit),
            )
            .mappings()
            .fetchall()
        )

    def get_facts_by_ids(self, fact_ids: list[int]):
        if not fact_ids:
            return []
        placeholders = ",".join(["%s"] * len(fact_ids))

        fact_query = f"""
                SELECT id,
                       content,
                       date_created
                  FROM memori_entity_fact
                 WHERE id IN ({placeholders})
                """  # nosec B608: Safe - only interpolating placeholder count, actual values parameterized
        fact_rows = self.conn.execute(fact_query, tuple(fact_ids)).mappings().fetchall()
        if not fact_rows:
            return []

        facts_by_id = {
            row["id"]: {
                "id": row["id"],
                "content": row["content"],
                "date_created": row.get("date_created"),
                "summaries": [],
            }
            for row in fact_rows
        }

        summary_query = f"""
                SELECT m.fact_id,
                       c.summary AS content,
                       COALESCE(c.date_updated, c.date_created) AS date_created
                  FROM memori_entity_fact_mention m
                  JOIN memori_conversation c
                    ON c.id = m.conversation_id
                 WHERE m.fact_id IN ({placeholders})
                   AND c.summary IS NOT NULL
                   AND c.summary != ''
                """  # nosec B608: Safe - only interpolating placeholder count, actual values parameterized
        summary_rows = (
            self.conn.execute(summary_query, tuple(fact_ids)).mappings().fetchall()
        )

        for row in summary_rows:
            fact_id = row.get("fact_id")
            fact = facts_by_id.get(fact_id)
            content = row.get("content")
            if fact is None or not isinstance(content, str) or not content:
                continue
            fact["summaries"].append(
                {"content": content, "date_created": row.get("date_created")}
            )

        return [facts_by_id[fact_id] for fact_id in fact_ids if fact_id in facts_by_id]

    def delete_by_entity(self, entity_id: int):
        self.conn.execute(
            """
            DELETE
              FROM memori_entity_fact
             WHERE entity_id = %s
            """,
            (entity_id,),
        )
        self.conn.commit()
        return self


class Process(BaseProcess):
    def create(self, external_id: str):
        self.conn.execute(
            """
            INSERT IGNORE INTO memori_process(
                uuid,
                external_id
            ) VALUES (
                %s,
                %s
            )
            """,
            (
                uuid4(),
                external_id,
            ),
        )
        self.conn.commit()

        return (
            self.conn.execute(
                """
                SELECT id
                  FROM memori_process
                 WHERE external_id = %s
                """,
                (external_id,),
            )
            .mappings()
            .fetchone()
            .get("id", None)
        )


class ProcessAttribute(BaseProcessAttribute):
    def create(self, process_id: int, attributes: list):
        if attributes is None or len(attributes) == 0:
            return self

        for attribute in attributes:
            self.conn.execute(
                """
                INSERT INTO memori_process_attribute(
                    uuid,
                    process_id,
                    content,
                    num_times,
                    date_last_time,
                    uniq
                ) VALUES (
                    %s,
                    %s,
                    %s,
                    %s,
                    current_timestamp(),
                    %s
                )
                ON DUPLICATE KEY UPDATE
                    num_times = num_times + 1,
                    date_last_time = current_timestamp()
                """,
                (
                    uuid4(),
                    process_id,
                    attribute,
                    1,
                    generate_uniq(attribute),
                ),
            )

        self.conn.commit()

        return self


class Session(BaseSession):
    def create(self, uuid: str, entity_id: int, process_id: int):
        self.conn.execute(
            """
            INSERT IGNORE INTO memori_session(
                uuid,
                entity_id,
                process_id
            ) VALUES (
                %s,
                %s,
                %s
            )
            """,
            (
                uuid,
                entity_id,
                process_id,
            ),
        )
        self.conn.commit()

        return (
            self.conn.execute(
                """
                SELECT id
                  FROM memori_session
                 WHERE uuid = %s
                """,
                (uuid,),
            )
            .mappings()
            .fetchone()
            .get("id", None)
        )

    def read(self, uuid: str) -> int | None:
        result = (
            self.conn.execute(
                """
                SELECT id
                  FROM memori_session
                 WHERE uuid = %s
                """,
                (str(uuid),),
            )
            .mappings()
            .fetchone()
        )
        if result is None:
            return None
        return result.get("id", None)


class Schema(BaseSchema):
    def __init__(self, conn: BaseStorageAdapter):
        super().__init__(conn)
        self.version = SchemaVersion(conn)


class SchemaVersion(BaseSchemaVersion):
    def create(self, num: int):
        self.conn.execute(
            """
            INSERT INTO memori_schema_version(
                num
            ) VALUES (
                %s
            )
            """,
            (num,),
        )

    def delete(self):
        self.conn.execute(
            """
            DELETE FROM memori_schema_version
            """
        )

    def read(self):
        return (
            self.conn.execute(
                """
                SELECT num
                  FROM memori_schema_version
                """
            )
            .mappings()
            .fetchone()
            .get("num", None)
        )


@Registry.register_driver("mysql")
@Registry.register_driver("mariadb")
class Driver:
    """MySQL storage driver (also supports MariaDB).

    Attributes:
        migrations: Database schema migrations for MySQL.
        requires_rollback_on_error: MySQL does not abort transactions on query
            errors, so no rollback is needed to continue executing queries.
    """

    migrations = migrations
    requires_rollback_on_error = False

    def __init__(self, conn: BaseStorageAdapter):
        self.conversation = Conversation(conn)
        self.entity = Entity(conn)
        self.entity_fact = EntityFact(conn)
        self.knowledge_graph = KnowledgeGraph(conn)
        self.process = Process(conn)
        self.process_attribute = ProcessAttribute(conn)
        self.schema = Schema(conn)
        self.session = Session(conn)
