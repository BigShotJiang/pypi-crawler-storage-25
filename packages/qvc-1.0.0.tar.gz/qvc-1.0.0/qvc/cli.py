def main():
    import sys
    import glob
    from qvc import init, add, commit, diff_text, diff_param, diff_state, remove, status, restore

    if len(sys.argv) < 2:
        print("Usage: qvc <command>")
        exit()

    cmd = sys.argv[1]

    if cmd == "help":
        print("""
QVC - Quantum Version Control CLI
---------------------------------

Usage:
  qvc <command> [options]

Commands:

  init
      Initialize a new QVC project in the current directory.

  add <file | .>
      Add circuit data to the staging area.
      Use '.' to add the default circuit file.

  commit <message>
      Commit the staged circuit data to the database.

  status <stage|commit> <summary|detailed>
      Show the current status of circuits.

      stage summary      Show summary of staged circuits
      stage detailed     Show detailed staged circuits

      commit summary     Show summary of committed circuits
      commit detailed    Show detailed committed circuits

  diff <text|param|state> <summary|detailed>
      Compare staged circuits with committed circuits.

      text summary       Show text-level differences
      text detailed      Show detailed text differences

      param summary      Show parameter differences
      param detailed     Show detailed parameter differences

      state summary      Show quantum state differences
      state detailed     Show detailed state differences

  remove <limit>
      Remove entries from the database up to the given limit.

  restore
      Restore circuits from the last committed state.
""")

    elif cmd == "init":
        init.initialize()

    elif cmd == "add":
        if len(sys.argv) < 3:
            print("Usage: qvc add <file|.>")
            sys.exit(1)

        target = sys.argv[2]

        if target == ".":
            py_files = glob.glob("*.py")

            if not py_files:
                print("No Python files found.")
                sys.exit(1)

            added_count = 0

            for file in py_files:
                print(f"Checking {file}...")

                if not add.is_quantum_circuit_file(file):
                    print(f"Skipping {file} (No quantum circuit found)")
                    continue

                try:
                    qc = add.load_circuit_from_file(file)
                    added_file = add.generate(qc)
                    add.stage(added_file)

                    print(f"Added {file}")
                    added_count += 1

                except Exception:
                    print(f"Skipping {file} (Processing failed)")

            print(f"\n{added_count} circuit file(s) added.")

        else:
            if not add.is_quantum_circuit_file(target):
                print("No quantum circuit found in file.")
                sys.exit(1)

            qc = add.load_circuit_from_file(target)
            added_file = add.generate(qc)
            add.stage(added_file)
    
    elif cmd == "remove":
        if len(sys.argv) < 3:
            print("Usage: qvc remove <limit>")
        else:
            limit = int(sys.argv[2])
            remove.remove_entry(limit)
    
    elif cmd == "status":
        if len(sys.argv) < 4:
            print("Usage: qvc status <stage|commit> <summary|detailed>")
        else:
            status_type = sys.argv[2]
            mode = sys.argv[3]

            if status_type == "stage":
                if mode == "summary" or mode == ".":
                    status.stage_summary_status()
                elif mode == "detailed":
                    status.stage_detailed_status()
                else:
                    print("Unknown status mode")
            elif status_type == "commit":
                if mode == "summary" or mode == ".":
                    status.commit_summary_status()
                elif mode == "detailed":
                    status.commit_detailed_status()
                else:
                    print("Unknown status mode")
            else:
                print("Unknown status type")

    elif cmd == "commit":
        if len(sys.argv) < 3:
            print("Commit message missing")
        else:
            message = sys.argv[2]
            commit.commits(message)
    
    elif cmd == "restore":
        if len(sys.argv) < 2:
            print("Usage: qvc restore")
        else:
            restore.restore_entry()
    
    elif cmd == "diff":
        if len(sys.argv) < 4:
            print("Usage: qvc diff <text|param|state> <summary|detailed>")
        else:
            diff_type = sys.argv[2]
            mode = sys.argv[3]

            if diff_type == "text":
                if mode == "summary" or mode == ".":
                    print(diff_text.summary_diff())
                elif mode == "detailed":
                    print(diff_text.detailed_diff())
                else:
                    print("Unknown diff mode")

            elif diff_type == "param":
                if mode == "summary" or mode == ".":
                    print(diff_param.summary_param_diff())
                elif mode == "detailed":
                    print(diff_param.detailed_param_diff())
                else:
                    print("Unknown diff mode")

            elif diff_type == "state":
                if mode == "summary" or mode == ".":
                    print(diff_state.summary_state_diff())
                elif mode == "detailed":
                    print(diff_state.detailed_state_diff())
                else:
                    print("Unknown diff mode")

            else:
                print("Unknown diff type")

    else:
        print("Unknown command")