<div align="center">
    
# QVC – Quantum Version Control
***A command-line version control system for quantum circuits.***
</div>

QVC is a **Python-based CLI tool** that enables developers and researchers to track, manage, and compare versions of **quantum circuits** built using **Qiskit**. Inspired by traditional version control systems, QVC introduces staging, committing, and diffing capabilities specifically tailored for quantum computing workflows.

It allows users to **stage circuits, commit versions, analyze circuit differences, and restore previous circuit states**, making it useful for **students, researchers, and quantum developers**.

<div align="center">

[![GitHub Release](https://img.shields.io/github/v/release/Pratham-Vishwakarma/QVC?style=flat)](https://github.com/Pratham-Vishwakarma/QVC/releases/latest)
[![Stars](https://img.shields.io/github/stars/Pratham-Vishwakarma/QVC)](https://github.com/Pratham-Vishwakarma/QVC/stargazers)
[![Forks](https://img.shields.io/github/forks/Pratham-Vishwakarma/QVC)](https://github.com/Pratham-Vishwakarma/QVC/network/members)
[![License](https://img.shields.io/badge/License-MIT-green)](https://github.com/Pratham-Vishwakarma/QVC/blob/main/LICENSE)
[![Download](https://img.shields.io/badge/Download-Setup-blue)](https://github.com/Pratham-Vishwakarma/QVC/releases/latest)
[![Report Issue](https://img.shields.io/badge/Report%20Issue-red)](https://github.com/Pratham-Vishwakarma/QVC/issues)
[![View Code](https://img.shields.io/badge/View%20Code-gray)](https://github.com/Pratham-Vishwakarma/QVC)

![Python](https://img.shields.io/badge/Python-blue?style=flat)
![Qiskit](https://img.shields.io/badge/Qiskit-purple?style=flat)
![NumPy](https://img.shields.io/badge/NumPy-orange?style=flat)
![CLI](https://img.shields.io/badge/CLI-Tool-green?style=flat)

</div>

## Table of Contents

- [Table of Contents](#table-of-contents)
- [Features](#features)
- [Installation / Setup](#installation--setup)
- [Usage](#usage)
  - [General User](#general-user)
  - [Developer](#developer)
- [Screenshots / Demo](#screenshots--demo)
- [Project Structure](#project-structure)
- [Configuration](#configuration)
- [Contributing Guidelines](#contributing-guidelines)
- [Roadmap](#roadmap)
- [Built With / Tech Stack](#built-with--tech-stack)
- [Authors / Acknowledgements](#authors--acknowledgements)
- [License](#license)
- [Support / Contact](#support--contact)

# Features

* ⚛ <u>**Quantum Circuit Versioning**</u> – Track and manage different versions of quantum circuits.  
* 📦 <u>**Staging System**</u> – Add circuits to a staging area before committing.  
* 📝 <u>**Commit History**</u> – Save circuit versions with commit messages.  
* 🔍 <u>**Circuit Difference Analysis**</u> – Compare circuits using text, parameter, and state differences.  
* 📊 <u>**Status Monitoring**</u> – View staged and committed circuits in summary or detailed form.  
* ♻ <u>**Restore Functionality**</u> – Restore circuits to previously committed versions.  
* 🖥 <u>**Command Line Interface**</u> – Lightweight CLI workflow similar to traditional version control tools.  

# Installation / Setup

### Prerequisites

* Python **3.9+**
* **pip** package manager

### Steps for Installation

```bash
# Clone repository
git clone https://github.com/Pratham-Vishwakarma/QVC.git
cd QVC
````

Install the CLI tool:

```bash
pip install .
```

After installation, you can run:

```bash
qvc help
```

# Usage

## General User

Initialize a QVC project:

```bash
qvc init
```

Add a circuit file:

```bash
qvc add circuit.py
```

Add all circuit files in the directory:

```bash
qvc add .
```

Commit staged circuits:

```bash
qvc commit "Initial circuit commit"
```

Check status:

```bash
qvc status stage summary
```

View circuit differences:

```bash
qvc diff text detailed
```

Restore previous version:

```bash
qvc restore
```

## Developer

Install in editable mode:

```bash
pip install -e .
```

Run CLI directly for testing:

```bash
python -m qvc.cli
```

Modify modules inside the `qvc` directory to extend functionality.

Example workflow:

```bash
qvc init
qvc add bell.py
qvc commit "Initial circuit"
qvc diff text summary
```

# Project Structure

```
qvc/
│
├── qvc/
│   ├── cli.py
│   ├── add.py
│   ├── commit.py
│   ├── diff_text.py
│   ├── diff_param.py
│   ├── diff_state.py
│   ├── status.py
│   └── restore.py
│
├── pyproject.toml
├── README.md
└── LICENSE
```

# Configuration

No additional configuration required.

Initialize QVC in your project directory:

```bash
qvc init
```

# Contributing Guidelines

1. Fork the repository.
2. Create a feature branch.

```bash
git checkout -b feature-name
```

3. Commit changes.

```bash
git commit -m "Add feature"
```

4. Push to branch.

```bash
git push origin feature-name
```

5. Open a Pull Request.

# Roadmap

* [ ] Add commit history viewer
* [ ] Add circuit visualization
* [ ] Add remote repository support
* [ ] Improve circuit parsing using AST
* [ ] Add merge functionality for circuits

# Built With / Tech Stack

| Component    | Purpose                   |
| ------------ | ------------------------- |
| Python       | Core CLI implementation   |
| Qiskit       | Quantum circuit framework |
| NumPy        | Numerical operations      |
| AST (Python) | Static code analysis      |
| pip          | Package management        |

# Authors / Acknowledgements

* **Pratham Vishwakarma** – Developer
* **Raj Parmar** – Developer

Inspired by modern version control workflows and quantum development tools.

Special thanks to the **Qiskit community** for advancing quantum computing.

# License

QVC is licensed under the **MIT License**.

# Support / Contact

* **Email:** [pratham.vishwakarma125940@gmail.com](mailto:pratham.vishwakarma125940@gmail.com)
* **GitHub:** [https://github.com/Pratham-Vishwakarma](https://github.com/Pratham-Vishwakarma)
* **LinkedIn:** [https://www.linkedin.com/in/pratham-vishwakarma/](https://www.linkedin.com/in/pratham-vishwakarma/)
* **X:** [https://www.x.com/pratham1826/](https://www.x.com/pratham1826/)