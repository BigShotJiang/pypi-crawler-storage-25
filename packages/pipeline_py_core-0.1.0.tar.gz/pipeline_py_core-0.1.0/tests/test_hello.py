from pipeline_py import hello


def test_hello():
    assert hello() == "Hello, World!"
