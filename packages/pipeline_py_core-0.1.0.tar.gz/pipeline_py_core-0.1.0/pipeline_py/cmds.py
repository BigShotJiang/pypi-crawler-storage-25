cmds = [
    ("fmt", ["black", "."], "auto-format code"),
    ("isort", ["isort", "."], "sort imports"),
    ("lint", ["flake8", "."], "lint check"),
    ("tests", ["pytest", "-q"], "unit tests"),
    ("coverage", ["pytest", "--cov=."], "coverage check"),
    ("build", ["python", "-m", "build"], "build package"),
]
