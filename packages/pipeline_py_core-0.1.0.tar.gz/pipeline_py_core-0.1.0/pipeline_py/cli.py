import typer

from .pipeline import run_pipeline

app = typer.Typer()


@app.command()
def run():
    typer.echo("🚀 Running pipeline...\n")

    ok = run_pipeline()

    if not ok:
        raise typer.Exit(1)


def main():
    app()
