import subprocess as sp

from .cmds import cmds


def run_pipeline():
    for name, command, desc in cmds:
        print(f"\n🚀 Running: {name} -> {desc}")

        result = sp.run(command, shell=False)

        if result.returncode != 0:
            print(f"\n❌ Stage failed: {name}")
            return result.returncode

        print(f"✅ Stage passed: {name}")

    print("\n🎉 Pipeline completed successfully!")
    return 0
