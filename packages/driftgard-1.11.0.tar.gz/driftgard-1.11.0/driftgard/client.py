import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import requests

from .errors import DriftgardError, AuthError, RateLimitError, FeatureNotAvailableError, ChainDepthExceededError

DEFAULT_BASE_URL = "https://api.driftgard.com"
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 2
RETRY_DELAY = 0.5
DEFAULT_CB_THRESHOLD = 5
DEFAULT_CB_RESET_SECONDS = 30


class Driftgard:
    """Driftgard Python SDK — evaluate LLM interactions against your compliance policy."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        failure_mode: str = "open",
        circuit_breaker_threshold: int = DEFAULT_CB_THRESHOLD,
        circuit_breaker_reset_seconds: int = DEFAULT_CB_RESET_SECONDS,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._failure_mode = failure_mode  # "open" or "closed"
        self._cb_threshold = circuit_breaker_threshold
        self._cb_reset_seconds = circuit_breaker_reset_seconds
        self._cb_state = "closed"  # closed | open | half-open
        self._cb_failures = 0
        self._cb_opened_at = 0.0

    def evaluate(
        self,
        project_id: str,
        prompt: str = "",
        response: str = "",
        model_id: str = "",
        timestamp: Optional[str] = None,
        experiment_id: Optional[str] = None,
        session_id: Optional[str] = None,
        parent_evaluation_id: Optional[str] = None,
        control_pack_id: Optional[str] = None,
        control_pack_version: Optional[int] = None,
        dry_run: bool = False,
        idempotency_key: Optional[str] = None,
        eval_mode: Optional[str] = None,
        tool_call: Optional[Dict[str, Any]] = None,
        sequence_no: Optional[int] = None,
        agent_id: Optional[str] = None,
        agent_role: Optional[str] = None,
        on_behalf_of: Optional[str] = None,
        parent_agent_id: Optional[str] = None,
        usage: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Evaluate a prompt/response pair against your active control pack."""
        idem_key = idempotency_key or f"idem_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"

        # Circuit breaker: if open, check reset timeout
        if self._cb_state == "open":
            if time.time() - self._cb_opened_at >= self._cb_reset_seconds:
                self._cb_state = "half-open"
            else:
                return self._synthetic_response(project_id, "circuit_open")

        body: Dict[str, Any] = {
            "project_id": project_id,
            "prompt": prompt,
            "response": response,
            "model_id": model_id,
            "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
        }
        if experiment_id:
            body["experiment_id"] = experiment_id
        if session_id:
            body["session_id"] = session_id
        if parent_evaluation_id:
            body["parent_evaluation_id"] = parent_evaluation_id
        if control_pack_id:
            body["control_pack_id"] = control_pack_id
        if control_pack_version is not None:
            body["control_pack_version"] = control_pack_version
        if dry_run:
            body["dry_run"] = True
        if eval_mode:
            body["eval_mode"] = eval_mode
        if tool_call:
            body["tool_call"] = tool_call
        if sequence_no is not None:
            body["sequence_no"] = sequence_no
        if agent_id:
            body["agent_id"] = agent_id
        if agent_role:
            body["agent_role"] = agent_role
        if on_behalf_of:
            body["on_behalf_of"] = on_behalf_of
        if parent_agent_id:
            body["parent_agent_id"] = parent_agent_id
        if usage:
            body["usage"] = usage

        try:
            result = self._post("/audit/evaluate", body, idem_key)
            # Success — reset circuit breaker
            self._cb_failures = 0
            self._cb_state = "closed"
            return result
        except (AuthError, RateLimitError, ChainDepthExceededError, FeatureNotAvailableError):
            raise  # Real errors — don't trigger circuit breaker
        except DriftgardError:
            self._cb_failures += 1
            if self._cb_failures >= self._cb_threshold:
                self._cb_state = "open"
                self._cb_opened_at = time.time()
            return self._synthetic_response(project_id, "failure_mode")

    def _synthetic_response(self, project_id: str, source: str) -> Dict[str, Any]:
        """Generate a synthetic response based on failure mode."""
        allowed = self._failure_mode == "open"
        resp: Dict[str, Any] = {
            "ok": True,
            "project_id": project_id,
            "evaluation_id": f"local_{int(time.time() * 1000)}_{uuid.uuid4().hex[:6]}",
            "active_control_pack_id": "",
            "active_control_pack_version": 0,
            "data_mode": "unknown",
            "telemetry_mode": "unknown",
            "execution_mode": "sync",
            "decision_action": "log_only" if allowed else "enforce",
            "decision_source": source,
            "evaluation": {
                "allowed": allowed,
                "risk_score": 0 if allowed else 10,
                "violations": [] if allowed else [{
                    "clause_id": "DRIFTGARD_UNAVAILABLE",
                    "severity": "critical",
                    "category": "system",
                    "reason": f"Driftgard API unavailable — fail-{'open' if allowed else 'closed'} policy applied ({source})",
                }],
            },
        }
        if not allowed:
            resp["fallback"] = {
                "message": "Service temporarily unavailable. Request blocked by fail-closed policy.",
                "code": "DRIFTGARD_UNAVAILABLE",
                "action": "show_message",
                "source": source,
                "escalated": False,
                "retry_after_ms": int(self._cb_reset_seconds * 1000) if self._cb_state == "open" else None,
            }
        return resp

    @property
    def circuit_breaker_state(self) -> Dict[str, Any]:
        """Get current circuit breaker state (for observability)."""
        return {"state": self._cb_state, "failures": self._cb_failures, "opened_at": self._cb_opened_at}

    def evaluate_tool_call(
        self,
        project_id: str,
        model_id: str,
        tool_name: str,
        parameters: Optional[Dict[str, Any]] = None,
        session_id: Optional[str] = None,
        parent_evaluation_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        sequence_no: Optional[int] = None,
        agent_id: Optional[str] = None,
        agent_role: Optional[str] = None,
        on_behalf_of: Optional[str] = None,
        parent_agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Evaluate a tool/function call against your control pack's tool_rules."""
        return self.evaluate(
            project_id=project_id,
            model_id=model_id,
            eval_mode="tool_call",
            tool_call={"tool_name": tool_name, "parameters": parameters or {}},
            session_id=session_id,
            parent_evaluation_id=parent_evaluation_id,
            idempotency_key=idempotency_key,
            sequence_no=sequence_no,
            agent_id=agent_id,
            agent_role=agent_role,
            on_behalf_of=on_behalf_of,
            parent_agent_id=parent_agent_id,
        )

    def report_outcome(
        self,
        evaluation_id: str,
        project_id: str,
        execution_status: str = "unknown",
        duration_ms: Optional[int] = None,
        error_code: Optional[str] = None,
        error_message: Optional[str] = None,
        affected_resources: Optional[list] = None,
        external_ref: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Report the outcome of a tool execution after it was allowed."""
        body: Dict[str, Any] = {
            "project_id": project_id,
            "execution_status": execution_status,
        }
        if duration_ms is not None:
            body["duration_ms"] = duration_ms
        if error_code:
            body["error_code"] = error_code
        if error_message:
            body["error_message"] = error_message
        if affected_resources:
            body["affected_resources"] = affected_resources
        if external_ref:
            body["external_ref"] = external_ref
        return self._post(f"/audit/evaluations/{evaluation_id}/outcome", body)

    def guard(self, tool_fn, tool_name: str, project_id: str, model_id: str = "agent", session_id: Optional[str] = None):
        """Wrap a tool function with Driftgard policy check."""
        dg = self
        def guarded(**kwargs):
            result = dg.evaluate_tool_call(
                project_id=project_id,
                model_id=model_id,
                tool_name=tool_name,
                parameters=kwargs,
                session_id=session_id,
            )
            if not result.get("evaluation", {}).get("allowed", False):
                fallback_msg = result.get("fallback", {}).get("message", f'Tool "{tool_name}" blocked by policy')
                raise DriftgardError(fallback_msg, status=403, code="tool_blocked")
            return tool_fn(**kwargs)
        guarded.__name__ = f"guarded_{tool_fn.__name__}" if hasattr(tool_fn, "__name__") else f"guarded_{tool_name}"
        return guarded

    def _post(self, path: str, body: Dict[str, Any], idempotency_key: Optional[str] = None, attempt: int = 0) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "x-api-key": self._api_key,
        }
        if idempotency_key:
            headers["x-idempotency-key"] = idempotency_key

        try:
            res = requests.post(url, json=body, headers=headers, timeout=self._timeout)
        except requests.exceptions.RequestException as e:
            if attempt < self._max_retries:
                time.sleep(RETRY_DELAY * (2 ** attempt))
                return self._post(path, body, idempotency_key, attempt + 1)
            raise DriftgardError(str(e), status=0, code="network_error")

        if res.status_code == 401:
            raise AuthError()
        if res.status_code == 429:
            payload = res.json() if res.headers.get("content-type", "").startswith("application/json") else {}
            if payload.get("error") == "chain_depth_exceeded":
                raise ChainDepthExceededError(
                    payload.get("message", ""),
                    depth=payload.get("depth", 0),
                    max_depth=payload.get("max", 0),
                )
            raise RateLimitError()

        if res.status_code == 403:
            payload = res.json() if res.headers.get("content-type", "").startswith("application/json") else {}
            if payload.get("error") == "feature_not_available":
                raise FeatureNotAvailableError(payload.get("message", ""), payload.get("tier", "unknown"))
            raise DriftgardError(payload.get("message", "Forbidden"), status=403, code="forbidden")

        if res.status_code >= 500 and attempt < self._max_retries:
            time.sleep(RETRY_DELAY * (2 ** attempt))
            return self._post(path, body, idempotency_key, attempt + 1)

        payload = res.json() if res.headers.get("content-type", "").startswith("application/json") else {}

        if not res.ok:
            raise DriftgardError(
                payload.get("message") or payload.get("error") or "Request failed",
                status=res.status_code,
                code=payload.get("error", "unknown"),
            )

        return payload
