"""Utilidades compartidas de pkgxray."""
