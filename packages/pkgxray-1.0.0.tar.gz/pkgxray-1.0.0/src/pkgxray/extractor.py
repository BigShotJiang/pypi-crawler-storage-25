"""Extrae archivos Python de los archivos comprimidos de paquetes descargados."""

import io
import tarfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import List, Tuple

from pkgxray.analyzers.base import ExtractedFile


def _is_safe_archive_path(name: str) -> bool:
    """Returns True if the archive member path is safe (no path traversal).

    Works regardless of host OS by normalising both / and \\ separators,
    then checking with PurePosixPath so that Windows-style paths inside
    archives are caught even when running on Linux.
    """
    normalised = name.replace("\\", "/")
    try:
        p = PurePosixPath(normalised)
    except Exception:
        return False
    return ".." not in p.parts and not p.is_absolute()

MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB


def extract_python_files(archive_path: Path) -> Tuple[List[ExtractedFile], int]:
    """Extrae los archivos fuente Python de un archivo de paquete.

    Soporta archivos .tar.gz, .tgz, .whl y .zip.

    Args:
        archive_path: Ruta al archivo comprimido descargado.

    Returns:
        Tupla (lista de ExtractedFile, número de archivos binarios encontrados).
        Los binarios (.so/.pyd/.dll/.dylib) se cuentan pero no se extraen.

    Raises:
        ValueError: Si el formato del archivo no es soportado.
    """
    name = archive_path.name.lower()
    if name.endswith(".tar.gz") or name.endswith(".tgz"):
        return _extract_from_tarball(archive_path)
    elif name.endswith(".whl") or name.endswith(".zip"):
        return _extract_from_zip(archive_path)
    else:
        raise ValueError(f"Formato de archivo no soportado: {archive_path.name}")


def _extract_from_tarball(archive_path: Path) -> Tuple[List[ExtractedFile], int]:
    """Extrae archivos Python de un archivo .tar.gz y cuenta binarios."""
    extracted = []
    binary_count = 0
    try:
        with tarfile.open(archive_path, "r:gz") as tf:
            for member in tf.getmembers():
                if not member.isfile():
                    continue
                if not _is_safe_archive_path(member.name):
                    continue
                if member.size > MAX_FILE_SIZE:
                    continue
                if _is_binary_file(member.name):
                    binary_count += 1
                    continue
                if not _is_python_file(member.name):
                    continue

                try:
                    f = tf.extractfile(member)
                    if f is None:
                        continue
                    content = f.read().decode("utf-8", errors="ignore")
                    extracted.append(
                        ExtractedFile(
                            filename=member.name,
                            content=content,
                            is_setup=_is_setup_file(member.name),
                            is_config=_is_config_file(member.name),
                        )
                    )
                except Exception:
                    continue
    except tarfile.TarError:
        pass
    return extracted, binary_count


def _extract_from_zip(archive_path: Path) -> Tuple[List[ExtractedFile], int]:
    """Extrae archivos Python de un archivo .whl o .zip y cuenta binarios."""
    extracted = []
    binary_count = 0
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                if not _is_safe_archive_path(info.filename):
                    continue
                if info.file_size > MAX_FILE_SIZE:
                    continue
                if _is_binary_file(info.filename):
                    binary_count += 1
                    continue
                if not _is_python_file(info.filename):
                    continue

                try:
                    content = zf.read(info.filename).decode("utf-8", errors="ignore")
                    extracted.append(
                        ExtractedFile(
                            filename=info.filename,
                            content=content,
                            is_setup=_is_setup_file(info.filename),
                            is_config=_is_config_file(info.filename),
                        )
                    )
                except Exception:
                    continue
    except zipfile.BadZipFile:
        pass
    return extracted, binary_count


def _is_python_file(filename: str) -> bool:
    """Retorna True si el archivo debe ser extraído para análisis.

    Incluye código Python (.py) y archivos de configuración del paquete que
    tienen su propio analizador dedicado (ConfigFileAnalyzer).  Estos últimos
    NO son pasados a ast.parse() — el analizador los interpreta directamente
    como TOML o INI según su extensión.
    """
    lower = filename.lower()
    return (
        lower.endswith(".py")
        or lower.endswith("setup.cfg")
        or lower.endswith("pyproject.toml")
    )


_BINARY_EXTENSIONS = {".so", ".pyd", ".dll", ".dylib"}


def _is_binary_file(filename: str) -> bool:
    """Returns True if the file is a compiled extension that cannot be AST-analysed."""
    return Path(filename).suffix.lower() in _BINARY_EXTENSIONS


def _is_setup_file(filename: str) -> bool:
    """Retorna True si el archivo es setup.py (activa SetupScriptAnalyzer)."""
    return Path(filename).name.lower() == "setup.py"


def _is_config_file(filename: str) -> bool:
    """Retorna True si el archivo es un config de paquete (activa ConfigFileAnalyzer)."""
    basename = Path(filename).name.lower()
    return basename in {"pyproject.toml", "setup.cfg"}
