"""TokenBreak Model File Scanner.

Audit NLP model artifacts for TokenBreak vulnerabilities by inspecting
tokenizer configurations and model architectures.
"""

__version__ = "0.1.0"
