"""
Tests covering all 5 fixes applied to the cifer package:
  1. Relative imports in connection_handler.py
  2. Bare except replaced in connection_handler_wss.py
  3. Pickle → JSON key/dataset serialization in securetrain.py
  4. RestrictedUnpickler in server.py
  5. RotatingFileHandler in client.py
"""

import io
import json
import os
import pickle
import sys
import tempfile
import textwrap

import numpy as np
import pandas as pd
import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Fix 1 — Relative imports in connection_handler.py
# ─────────────────────────────────────────────────────────────────────────────
def test_connection_handler_uses_relative_imports():
    src_path = os.path.join(os.path.dirname(__file__), "..", "cifer", "connection_handler.py")
    with open(src_path) as f:
        lines = f.readlines()

    # Bare top-level import looks like "^import federated_pb2$" (no leading "from")
    bare_imports = [
        line.rstrip()
        for line in lines
        if line.strip() in ("import federated_pb2", "import federated_pb2_grpc")
    ]
    assert bare_imports == [], (
        f"Bare module-level imports found (should be relative): {bare_imports}"
    )

    source = "".join(lines)
    assert "from . import federated_pb2" in source
    assert "from . import federated_pb2_grpc" in source


# ─────────────────────────────────────────────────────────────────────────────
# Fix 2 — No bare except in connection_handler_wss.py
# ─────────────────────────────────────────────────────────────────────────────
def test_no_bare_except_in_connection_handler_wss():
    src_path = os.path.join(os.path.dirname(__file__), "..", "cifer", "connection_handler_wss.py")
    with open(src_path) as f:
        lines = f.readlines()

    bare_excepts = [
        (i + 1, line.rstrip())
        for i, line in enumerate(lines)
        if line.strip() == "except:"
    ]
    assert bare_excepts == [], (
        f"Bare 'except:' found at lines: {bare_excepts}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Fix 3 — securetrain.py: JSON key & dataset serialization
# ─────────────────────────────────────────────────────────────────────────────
phe = pytest.importorskip("phe", reason="phe not installed — skipping securetrain tests")


def test_generate_named_keys_writes_json(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    from cifer.securetrain import generate_named_keys, get_key_paths
    pubkey, privkey = generate_named_keys("testkey")

    pub_path, priv_path = get_key_paths("testkey")
    assert os.path.exists(pub_path), "Public key file missing"
    assert os.path.exists(priv_path), "Private key file missing"

    # Files must be valid JSON (not pickle)
    with open(pub_path) as f:
        pub_data = json.load(f)
    with open(priv_path) as f:
        priv_data = json.load(f)

    assert "n" in pub_data, "Public key JSON must contain 'n'"
    assert "p" in priv_data and "q" in priv_data, "Private key JSON must contain 'p' and 'q'"
    assert pub_data["n"] == pubkey.n


def test_load_public_key(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from cifer.securetrain import generate_named_keys, load_public_key
    pubkey, _ = generate_named_keys("loadtest")
    loaded = load_public_key("loadtest")
    assert loaded.n == pubkey.n


def test_load_private_key(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from cifer.securetrain import generate_named_keys, load_private_key
    _, privkey = generate_named_keys("privtest")
    loaded = load_private_key("privtest")
    assert loaded.p == privkey.p
    assert loaded.q == privkey.q


def test_encrypt_and_decrypt_dataset_roundtrip(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from cifer.securetrain import encrypt_dataset, decrypt_dataset

    # Create a small CSV
    csv_path = str(tmp_path / "input.csv")
    pd.DataFrame({"a": [1.0, 2.0, 3.0], "b": [4.0, 5.0, 6.0]}).to_csv(csv_path, index=False)

    enc_path = str(tmp_path / "enc.json")
    dec_path = str(tmp_path / "dec.csv")

    encrypt_dataset(csv_path, enc_path, "roundtrip")
    decrypt_dataset(enc_path, dec_path, "roundtrip")

    result = pd.read_csv(dec_path)
    expected = pd.read_csv(csv_path)
    pd.testing.assert_frame_equal(result.reset_index(drop=True), expected.reset_index(drop=True))


def test_encrypted_dataset_is_not_pickle(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from cifer.securetrain import encrypt_dataset

    csv_path = str(tmp_path / "check.csv")
    pd.DataFrame({"x": [1.0, 2.0]}).to_csv(csv_path, index=False)

    enc_path = str(tmp_path / "enc_check.json")
    encrypt_dataset(csv_path, enc_path, "checkkey")

    # File must be valid JSON (not pickle bytes)
    with open(enc_path) as f:
        data = json.load(f)
    assert "n" in data and "columns" in data and "data" in data


def test_key_files_are_not_pickle(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from cifer.securetrain import generate_named_keys, get_key_paths

    generate_named_keys("picklecheck")
    pub_path, priv_path = get_key_paths("picklecheck")

    for path in (pub_path, priv_path):
        with open(path, "rb") as f:
            header = f.read(2)
        # Pickle files start with \x80\x04 or similar magic bytes
        assert header[:1] != b"\x80", f"{path} looks like a pickle file"


# ─────────────────────────────────────────────────────────────────────────────
# Fix 4 — server.py: RestrictedUnpickler blocks malicious payloads
# ─────────────────────────────────────────────────────────────────────────────
def test_safe_loads_blocks_os_system():
    """A pickle that calls os.system must be blocked."""
    from cifer.server import _safe_loads

    # Build a valid pickle payload that would invoke os.system("id")
    class _Exploit:
        def __reduce__(self):
            import os
            return (os.system, ("id",))

    malicious = pickle.dumps(_Exploit())
    with pytest.raises(pickle.UnpicklingError, match="Blocked unsafe class"):
        _safe_loads(malicious)


def test_safe_loads_blocks_subprocess():
    """Pickle that calls subprocess.check_output must be blocked."""
    import subprocess

    from cifer.server import _safe_loads

    payload = pickle.dumps(subprocess.check_output)  # serialises the callable
    with pytest.raises(pickle.UnpicklingError, match="Blocked unsafe class"):
        _safe_loads(payload)


def test_safe_loads_allows_plain_list():
    from cifer.server import _safe_loads

    data = [1, 2, 3]
    assert _safe_loads(pickle.dumps(data)) == data


def test_safe_loads_allows_numpy_array():
    from cifer.server import _safe_loads

    arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
    result = _safe_loads(pickle.dumps(arr))
    np.testing.assert_array_equal(result, arr)


# ─────────────────────────────────────────────────────────────────────────────
# Fix 5 — client.py: RotatingFileHandler
# ─────────────────────────────────────────────────────────────────────────────
def test_client_logger_uses_rotating_file_handler(tmp_path, monkeypatch):
    """client.py must configure a RotatingFileHandler, not a plain FileHandler."""
    from logging.handlers import RotatingFileHandler

    monkeypatch.chdir(tmp_path)

    # Re-import in isolation so the module-level logger setup re-runs
    if "cifer.client" in sys.modules:
        del sys.modules["cifer.client"]

    # Patch heavy optional deps so the import doesn't fail in a CI environment
    sys.modules.setdefault("tensorflow", _FakeTF())
    sys.modules.setdefault("tensorflow.keras", _FakeTF())
    sys.modules.setdefault("tensorflow.keras.models", _FakeTF())

    import importlib
    try:
        import cifer.client  # noqa: F401 – side effect: configures logger
    except Exception:
        pass  # TF / other heavy deps may fail; we only care about logger config

    import logging
    client_logger = logging.getLogger("cifer_client")

    rotating_handlers = [h for h in client_logger.handlers if isinstance(h, RotatingFileHandler)]
    assert rotating_handlers, (
        "cifer_client logger has no RotatingFileHandler — log rotation is not configured"
    )
    handler = rotating_handlers[0]
    assert handler.maxBytes == 5 * 1024 * 1024, "maxBytes should be 5 MB"
    assert handler.backupCount == 3


# ─────────────────────────────────────────────────────────────────────────────
# Helper stub
# ─────────────────────────────────────────────────────────────────────────────
class _FakeTF:
    """Minimal stub so cifer.client can be imported without TensorFlow installed."""
    def __getattr__(self, name):
        return _FakeTF()

    def __call__(self, *args, **kwargs):
        return _FakeTF()
