import os
import sys
import subprocess
import requests
import typer
import yaml
from rich import print

app = typer.Typer(help="🚀 Cifer CLI", rich_markup_mode="rich")

securetrain_app = typer.Typer(help="🔐 Secure training commands")
dataset_app = typer.Typer(help="📦 Dataset commands")

app.add_typer(securetrain_app, name="securetrain")
app.add_typer(dataset_app, name="dataset")


# ================= CONFIG =================
def load_config():
    config_path = os.path.expanduser("~/.cifer/config.yaml")

    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                return yaml.safe_load(f) or {}
        except Exception:
            print("[red]❌ Failed to read config[/red]")
            return {}

    return {}


# ================= VERSION =================
@app.command()
def version():
    """Show Cifer version"""
    try:
        from importlib.metadata import version
        print(f"[green]Cifer version:[/green] {version('cifer')}")
    except Exception:
        print("[yellow]⚠️ Cifer not installed via pip[/yellow]")


# ================= PROJECT INIT =================
@app.command("init")
def init_project(name: str):
    """Create new Cifer project"""

    try:
        os.makedirs(name, exist_ok=True)
        os.makedirs(f"{name}/dataset", exist_ok=True)
        os.makedirs(f"{name}/models", exist_ok=True)

        config = {
            "project": name,
            "server": "ws://localhost:8080"
        }

        os.makedirs(os.path.expanduser("~/.cifer"), exist_ok=True)

        with open(f"{name}/config.yaml", "w") as f:
            yaml.dump(config, f)

        print(f"[green]✅ Project '{name}' created[/green]")

    except Exception as e:
        print(f"[red]❌ Error creating project: {e}[/red]")


# ================= SERVER =================
@app.command("server")
def run_server(
    project_id: str = typer.Option(..., help="Encoded project ID"),
    company_id: str = typer.Option(..., help="Encoded company ID"),
    client_id: str = typer.Option(..., help="Encoded client ID"),
    base_api: str = typer.Option("https://workspace.cifer.ai/FederatedApi", help="Base API URL"),
    dry_run: bool = typer.Option(False, help="Skip upload (test mode)"),
):
    """Run Cifer Federated Server"""

    print(f"[cyan]Starting Cifer Federated Server...[/cyan]")

    try:
        from cifer.server import CiferServer

        server = CiferServer(
            encoded_project_id=project_id,
            encoded_company_id=company_id,
            encoded_client_id=client_id,
            base_api=base_api,
            dry_run=dry_run,
        )
        server.run()

    except Exception as e:
        print(f"[red]Server error: {e}[/red]")


# ================= CLIENT =================
@app.command("client")
def run_client(
    dataset: str = typer.Option(..., help="Path to dataset (.npz or .pt)"),
    project_id: str = typer.Option(..., help="Encoded project ID"),
    company_id: str = typer.Option(..., help="Encoded company ID"),
    client_id: str = typer.Option(..., help="Encoded client ID"),
    model_path: str = typer.Option(..., help="Path to model file (.h5)"),
    base_api: str = typer.Option("https://workspace.cifer.ai/FederatedApi", help="Base API URL"),
    epochs: int = typer.Option(1, help="Number of training epochs"),
    encrypt: bool = typer.Option(False, help="Enable homomorphic encryption"),
):
    """Run federated client"""

    if not os.path.exists(dataset):
        print("[red]Dataset not found[/red]")
        raise typer.Exit()

    print(f"[cyan]Starting Cifer Federated Client...[/cyan]")

    try:
        from cifer.client import CiferClient

        client = CiferClient(
            encoded_project_id=project_id,
            encoded_company_id=company_id,
            encoded_client_id=client_id,
            base_api=base_api,
            dataset_path=dataset,
            model_path=model_path,
            use_encryption=encrypt,
            epochs=epochs,
        )
        client.run()

    except Exception as e:
        print(f"[red]Client error: {e}[/red]")


# ================= DATASET =================
@dataset_app.command("download")
def download_dataset(name: str):
    """Download dataset from HuggingFace"""

    print(f"[cyan]📦 Downloading dataset: {name}[/cyan]")

    try:
        from datasets import load_dataset

        dataset = load_dataset(name)

        output_dir = f"./dataset/{name}"
        os.makedirs("./dataset", exist_ok=True)

        dataset.save_to_disk(output_dir)

        print(f"[green]✅ Saved to {output_dir}[/green]")

    except Exception as e:
        print(f"[red]❌ Download failed: {e}[/red]")


# ================= STATUS =================
@app.command("status")
def status(server: str = typer.Option("http://localhost:8080")):
    """Check server status"""

    try:
        r = requests.get(f"{server}/metrics", timeout=3)

        if r.status_code == 200:
            print("[green]✅ Server OK[/green]")
            print(r.json())
        else:
            print(f"[yellow]⚠️ Status code: {r.status_code}[/yellow]")

    except Exception:
        print("[red]❌ Server not reachable[/red]")


# ================= Securetrain =================
@securetrain_app.command("encrypt-dataset")
def securetrain_encrypt(
    dataset: str = typer.Option(..., help="Path to CSV dataset"),
    output: str = typer.Option(..., help="Output path for encrypted dataset"),
    key: str = typer.Option(..., help="Key name for encryption"),
):
    """Encrypt dataset"""

    if not os.path.exists(dataset):
        print("[red]Dataset not found[/red]")
        raise typer.Exit()

    try:
        from cifer.securetrain import encrypt_dataset
        encrypt_dataset(dataset, output, key)
        print("[green]Dataset encrypted[/green]")

    except Exception as e:
        print(f"[red]Error: {e}[/red]")


@securetrain_app.command("train")
def securetrain_train(
    encrypted_data: str = typer.Option(..., help="Path to encrypted dataset"),
    output_model: str = typer.Option(..., help="Output path for trained model"),
    key: str = typer.Option(..., help="Key name for decryption"),
    features: str = typer.Option(..., help="Comma-separated feature column names"),
    label: str = typer.Option(..., help="Label column name"),
):
    """Train model on encrypted data"""

    try:
        from cifer.securetrain import train_model
        feature_cols = [f.strip() for f in features.split(",")]
        train_model(encrypted_data, output_model, key, feature_cols, label)
        print("[green]Model trained[/green]")

    except Exception as e:
        print(f"[red]Error: {e}[/red]")


@securetrain_app.command("decrypt-model")
def securetrain_decrypt(
    input_model: str = typer.Option(..., help="Path to model file"),
    output_model: str = typer.Option(..., help="Output path for decrypted model"),
    key: str = typer.Option(..., help="Key name for decryption"),
):
    """Decrypt trained model"""

    try:
        from cifer.securetrain import decrypt_model
        decrypt_model(input_model, output_model, key)
        print("[green]Model decrypted[/green]")

    except Exception as e:
        print(f"[red]Error: {e}[/red]")


# ================= JUPYTER =================
@app.command("register-kernel")
def register_kernel():
    """Register Jupyter Kernel"""

    print("[cyan]📓 Registering kernel...[/cyan]")

    try:
        subprocess.run(
            [
                sys.executable,
                "-m",
                "ipykernel",
                "install",
                "--user",
                "--name",
                "cifer-kernel",
                "--display-name",
                "Cifer Kernel",
            ],
            check=True,
        )

        print("[green]✅ Kernel registered[/green]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= AGENT =================
@app.command("agent-ace")
def agent_ace(port: int = typer.Option(9999)):
    """Launch ACE agent"""

    print(f"[cyan]🤖 Starting ACE agent on {port}[/cyan]")

    try:
        from cifer.agent_ace import run_agent_ace
        run_agent_ace(port=port)

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= NOTEBOOK =================
@app.command("download-notebook")
def download_notebook(url: str):
    """Download notebook"""

    filename = url.split("/")[-1]

    print(f"[cyan]⬇️ Downloading {filename}[/cyan]")

    try:
        response = requests.get(url, stream=True, timeout=10)

        if response.status_code == 200:
            with open(filename, "wb") as f:
                for chunk in response.iter_content(8192):
                    f.write(chunk)

            print(f"[green]✅ Downloaded {filename}[/green]")
        else:
            print("[red]❌ Download failed[/red]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= SIM =================
@app.command("train")
def simulate_training(
    epochs: int = typer.Option(5),
    lr: float = typer.Option(0.001),
):
    """Simulate training"""

    print(f"[cyan]⚙️ Training {epochs} epochs | lr={lr}[/cyan]")

    for i in range(1, epochs + 1):
        print(f"[yellow]Epoch {i}/{epochs}[/yellow]")

    print("[green]✅ Done[/green]")


# ================= ENTRY =================
def main():
    app()


if __name__ == "__main__":
    main()