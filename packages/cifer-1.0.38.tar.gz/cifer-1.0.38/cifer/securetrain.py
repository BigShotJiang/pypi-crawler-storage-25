import argparse
import io
import json
import os
import pickle
import requests
import pandas as pd
import numpy as np
from io import BytesIO
from phe import paillier


# ─────────────────────────────────────────────────────────
# Restricted Unpickler — allow only sklearn model classes
# ─────────────────────────────────────────────────────────
_SKLEARN_SAFE = {
    ("sklearn.linear_model._logistic", "LogisticRegression"),
    ("sklearn.linear_model.logistic", "LogisticRegression"),
    ("sklearn.utils._bunch", "Bunch"),
    ("numpy", "ndarray"),
    ("numpy.core.multiarray", "_reconstruct"),
    ("numpy", "dtype"),
    ("builtins", "list"),
    ("builtins", "dict"),
    ("builtins", "float"),
    ("builtins", "int"),
    ("builtins", "str"),
    ("builtins", "bool"),
    ("builtins", "bytes"),
}


class _SafeUnpickler(pickle.Unpickler):
    """Only allows known-safe sklearn / numpy classes to be unpickled."""
    def find_class(self, module, name):
        if (module, name) in _SKLEARN_SAFE:
            return super().find_class(module, name)
        raise pickle.UnpicklingError(f"Blocked unsafe class: {module}.{name}")


def _safe_loads(data: bytes):
    return _SafeUnpickler(io.BytesIO(data)).load()


def _safe_load(file_obj):
    return _SafeUnpickler(file_obj).load()


# ─────────────────────────────────────────────────────────
# Key Paths
# ─────────────────────────────────────────────────────────
def get_key_paths(key_name):
    pub_path = f"keys/{key_name}/public.key.json"
    priv_path = f"keys/{key_name}/private.key.json"
    return pub_path, priv_path


# ─────────────────────────────────────────────────────────
# Key Generation & Serialization (JSON — no pickle)
# ─────────────────────────────────────────────────────────
def generate_named_keys(key_name):
    print(f"🔐 Generating public/private key pair for: {key_name}")
    pubkey, privkey = paillier.generate_paillier_keypair()
    dir_path = f"keys/{key_name}"
    os.makedirs(dir_path, exist_ok=True)

    pub_path, priv_path = get_key_paths(key_name)

    # Public key — only n is needed
    with open(pub_path, "w") as f:
        json.dump({"n": pubkey.n}, f)

    # Private key — store p and q (secret primes)
    with open(priv_path, "w") as f:
        json.dump({"p": privkey.p, "q": privkey.q}, f)

    print(f"✅ Keys saved to: {pub_path}, {priv_path}")
    return pubkey, privkey


def load_public_key(key_name):
    path = get_key_paths(key_name)[0]
    print(f"📂 Loading public key from: {path}")
    with open(path, "r") as f:
        data = json.load(f)
    return paillier.PaillierPublicKey(n=data["n"])


def load_private_key(key_name):
    path = get_key_paths(key_name)[1]
    print(f"📂 Loading private key from: {path}")
    with open(path, "r") as f:
        data = json.load(f)
    n = data["p"] * data["q"]
    pubkey = paillier.PaillierPublicKey(n=n)
    return paillier.PaillierPrivateKey(pubkey, data["p"], data["q"])


# ─────────────────────────────────────────────────────────
# Encrypted Dataset Serialization (JSON — no pickle)
# ─────────────────────────────────────────────────────────
def _save_encrypted_df(enc_df: pd.DataFrame, pubkey, output_path: str):
    """Serialize an encrypted DataFrame to JSON (no pickle)."""
    serialized = {}
    for col in enc_df.columns:
        serialized[col] = [
            {"c": str(enc_val.ciphertext()), "e": enc_val.exponent}
            for enc_val in enc_df[col]
        ]
    payload = {"n": pubkey.n, "columns": list(enc_df.columns), "data": serialized}
    with open(output_path, "w") as f:
        json.dump(payload, f)


def _load_encrypted_df(input_path: str) -> pd.DataFrame:
    """Deserialize an encrypted DataFrame from JSON."""
    with open(input_path, "r") as f:
        payload = json.load(f)
    pubkey = paillier.PaillierPublicKey(n=payload["n"])
    records = {}
    for col in payload["columns"]:
        records[col] = [
            paillier.EncryptedNumber(pubkey, int(item["c"]), item["e"])
            for item in payload["data"][col]
        ]
    return pd.DataFrame(records)


# ─────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────
def encrypt_dataset(dataset_path_or_url, output_path, key_name):
    print("🔄 Loading dataset...")
    if dataset_path_or_url.startswith("http"):
        response = requests.get(dataset_path_or_url, timeout=30)
        response.raise_for_status()
        df = pd.read_csv(BytesIO(response.content))
        print("✅ Dataset loaded from URL.")
    else:
        df = pd.read_csv(dataset_path_or_url)
        print("✅ Dataset loaded from local path.")

    df = df.select_dtypes(include="number")
    print(f"🧮 Detected numeric columns: {list(df.columns)}")

    pubkey, _ = generate_named_keys(key_name)

    print("🔐 Encrypting dataset...")
    enc_df = df.copy()
    for col in enc_df.columns:
        enc_df[col] = enc_df[col].apply(lambda x: pubkey.encrypt(float(x)))

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    print(f"💾 Saving encrypted dataset to: {output_path}")
    _save_encrypted_df(enc_df, pubkey, output_path)
    print("✅ Dataset encrypted and saved successfully.")


def train_model(encrypted_path, output_model_path, key_name, feature_cols, label_col):
    print(f"📂 Loading encrypted dataset: {encrypted_path}")
    enc_df = _load_encrypted_df(encrypted_path)

    print("🔄 Extracting features and labels...")
    try:
        X_enc = enc_df[feature_cols].values.tolist()
        y_enc = enc_df[label_col].values.tolist()
    except KeyError as e:
        print(f"❌ Column error: {e}")
        return

    print(f"📂 Loading private key to decrypt data for training: {key_name}")
    privkey = load_private_key(key_name)

    print("🔓 Decrypting dataset before training...")
    try:
        X_plain = np.array([[privkey.decrypt(val) for val in row] for row in X_enc])
        y_plain = np.array([privkey.decrypt(val) for val in y_enc])
    except Exception as e:
        print(f"❌ Failed to decrypt: {e}")
        return

    print("✅ Label distribution:", np.unique(y_plain, return_counts=True))
    if len(np.unique(y_plain)) < 2:
        print("❌ Need at least 2 classes in the dataset for training.")
        return

    print("🧠 Training model using decrypted values...")
    from sklearn.linear_model import LogisticRegression  # lazy — avoid top-level scipy dep
    clf = LogisticRegression()
    clf.fit(X_plain, y_plain)

    os.makedirs(os.path.dirname(output_model_path) or ".", exist_ok=True)
    print(f"💾 Saving trained model to: {output_model_path}")
    # sklearn models have no safe alternative serialization — file is stored locally
    with open(output_model_path, "wb") as f:
        pickle.dump(clf, f)
    print("✅ Model trained and saved successfully.")


def decrypt_model(model_path, output_path, key_name):
    print(f"📂 Loading encrypted model: {model_path}")
    with open(model_path, "rb") as f:
        model = _safe_load(f)

    privkey = load_private_key(key_name)

    print("🔓 Decrypting model coefficients...")
    decrypted_coef = []
    for coef in model.coef_[0]:
        try:
            val = privkey.decrypt(coef)
        except Exception:
            val = coef
        decrypted_coef.append(val)

    model.coef_ = [decrypted_coef]
    print(f"💾 Saving decrypted model to: {output_path}")
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "wb") as f:
        pickle.dump(model, f)
    print("✅ Decrypted model saved successfully.")


def decrypt_dataset(encrypted_input_path, output_path, key_name):
    print(f"📂 Loading encrypted dataset from: {encrypted_input_path}")
    enc_df = _load_encrypted_df(encrypted_input_path)

    privkey = load_private_key(key_name)

    print("🔓 Decrypting dataset...")
    _cell_map = enc_df.map if hasattr(enc_df, "map") else enc_df.applymap
    dec_df = _cell_map(lambda x: privkey.decrypt(x))

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    print(f"💾 Saving decrypted dataset to: {output_path}")
    dec_df.to_csv(output_path, index=False)
    print("✅ Dataset decrypted and saved successfully.")


# ─────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Cifer Secure Training (named key version)")
    subparsers = parser.add_subparsers(dest="command")

    enc = subparsers.add_parser("encrypt-dataset", help="Encrypt a CSV dataset")
    enc.add_argument("--dataset", required=True)
    enc.add_argument("--output", required=True)
    enc.add_argument("--key", required=True)

    decdata = subparsers.add_parser("decrypt-dataset", help="Decrypt encrypted dataset")
    decdata.add_argument("--input", required=True)
    decdata.add_argument("--output", required=True)
    decdata.add_argument("--key", required=True)

    train = subparsers.add_parser("train", help="Train model on encrypted data")
    train.add_argument("--encrypted-data", required=True)
    train.add_argument("--output-model", required=True)
    train.add_argument("--key", required=True)
    train.add_argument("--features", nargs="+", help="Feature column names", required=True)
    train.add_argument("--label", help="Label column name", required=True)

    dec = subparsers.add_parser("decrypt-model", help="Decrypt model")
    dec.add_argument("--input-model", required=True)
    dec.add_argument("--output-model", required=True)
    dec.add_argument("--key", required=True)

    args = parser.parse_args()
    if args.command == "encrypt-dataset":
        encrypt_dataset(args.dataset, args.output, args.key)
    elif args.command == "decrypt-dataset":
        decrypt_dataset(args.input, args.output, args.key)
    elif args.command == "train":
        train_model(
            args.encrypted_data,
            args.output_model,
            args.key,
            args.features,
            args.label,
        )
    elif args.command == "decrypt-model":
        decrypt_model(args.input_model, args.output_model, args.key)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
