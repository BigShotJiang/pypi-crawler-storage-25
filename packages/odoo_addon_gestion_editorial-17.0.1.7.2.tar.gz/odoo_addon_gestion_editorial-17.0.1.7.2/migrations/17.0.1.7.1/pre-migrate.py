import logging
from odoo import api, SUPERUSER_ID
from odoo.tools import sql
from openupgradelib import openupgrade

_logger = logging.getLogger(__name__)

def migrate(cr, version):
    if openupgrade.column_exists(cr, "purchase_order_line", "contact_type"):
        _logger.info("Column [contact_type] exists")
        openupgrade.rename_columns(cr, {"purchase_order_line": [("contact_type", "contact_type_old")]})
        _logger.info("Column [contact_type] renamed to [contact_type_old]")