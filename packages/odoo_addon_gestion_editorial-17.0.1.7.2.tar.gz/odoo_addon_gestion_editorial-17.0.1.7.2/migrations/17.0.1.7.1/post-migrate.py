import logging
from odoo import api, SUPERUSER_ID
from odoo.tools import sql
from openupgradelib import openupgrade

_logger = logging.getLogger(__name__)

def migrate(cr, version):
    env = api.Environment(cr, SUPERUSER_ID, {})
    env.registry.clear_cache()
    env.invalidate_all()
    _logger.info("=== INICIANDO POST-MIGRATE SCRIPT ===")

    try:
        ddaa_orders = env['purchase.order'].search([
            ('is_ddaa_order', '=', True),
        ])

        updated_ddaa_orders = 0
        for order in ddaa_orders:
            author_id = order.partner_id
            _logger.info(f"Actualizando albarán de autoría para {author_id.name}")
            for line in order.order_line:
                product_category = line.product_id.categ_id.id
                _logger.info(f"product_category: {product_category}")
                if product_category and product_category == env.company.product_category_ddaa_id.id:
                        # `producto_referencia` is a One2many on templates, so we must
                        # handle the case where it returns 0..N records.
                        producto_referencia = line.product_id.producto_referencia
                        if not producto_referencia:
                            _logger.warning(
                                "No producto_referencia found for purchase.order.line %s (product %s)",
                                line.id,
                                line.product_id.id,
                            )
                            continue
                        product = producto_referencia[0]

                        cr.execute(
                            f"SELECT contact_type_old FROM purchase_order_line WHERE id = {line.id}"
                        )
                        contact_type = cr.fetchone()[0]

                        _logger.info(f"product_id: {product.id}")
                        _logger.info(f"author_id: {author_id.id}")
                        _logger.info(f"contact_type: {contact_type}")

                        authorship = env['authorship.product'].search([
                            ('product_id', '=', product.id),
                            ('author_id', '=', author_id.id),
                            ('contact_type', '=', contact_type)
                        ], limit=1)

                        _logger.info(f"Authorship found: {authorship.id if authorship else 'None'}")

                        if authorship:
                            line.authorship = authorship.id
            updated_ddaa_orders+=1

        _logger.info(f"### TOTAL UPDATED DDAA ORDERS: {updated_ddaa_orders} ")
        openupgrade.drop_columns(cr, [("purchase_order_line", "contact_type_old")])


    except Exception as e:
        _logger.error(f"Error en post-migrate: {str(e)}")
        raise
    
    _logger.info("=== POST-MIGRATE COMPLETADO ===")