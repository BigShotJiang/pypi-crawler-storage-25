from . import authorships_confirm
