from odoo import models, fields, api

class AuthorshipConfirmWizard(models.TransientModel):
    _name = 'wizard.authorship.confirm'
    _description = 'Confirm Authorship Creation'

    import_result_info = fields.Text(readonly=True)
    line_ids = fields.One2many(
        'wizard.authorship.confirm.line',
        'wizard_id',
        string='Autorías pendientes'
    )

    def action_confirm(self):
        for line in self.line_ids:
            if not line.create_author:
                continue

            if line.author_id:
                author_contact = line.author_id
            else:
                author_contact = self.env['res.partner'].create({
                    'name': line.author_name_suggestion,
                    'is_author': True,
                })

            author_type_id = self.env.ref('gestion_editorial.contact_type_author').id  
            self.env['authorship.product'].create({
                'author_id': author_contact.id,
                'product_id': line.book_id.id,
                'contact_type': author_type_id,
                'sales_price': 0,
            })
        return {'type': 'ir.actions.act_window_close'}


class AuthorshipConfirmWizardLine(models.TransientModel):
    _name = 'wizard.authorship.confirm.line'
    _description = 'Línea de autoría pendiente'

    wizard_id = fields.Many2one('wizard.authorship.confirm', ondelete='cascade')
    author_id = fields.Many2one(
        'res.partner',
        string='Contacto',
        domain=[('is_author', '=', True)],
    )
    author_name_suggestion = fields.Char(
        string='Nombre del autor',
        readonly=True
    )
    book_id = fields.Many2one('product.template', string='Libro', required=True)
    book_name = fields.Char(string='Libro', related='book_id.name', readonly=True)
    create_author = fields.Boolean(string='Crear / Asignar autor', default=True)
