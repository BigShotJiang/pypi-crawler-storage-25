# Changelog

All notable changes to this Odoo module will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [17.0.1.7.2] - 2026-04-29

### Added

- Modules screenshots for Odoo Store

### Changed

- Module metadata for Odoo Store. Notably, we had OPL-1 license while we always choose AGPL. Also set price and descriptions in English.

### Fixed

- In liquidations, the delivered quantity was not automatically set for confirmed negative lines.

## [17.0.1.7.1] - 2026-03-27

### Added

- New report view specific for DDAA orders.
- New wizard for manage new authorships after book creation

### Changed

- Replace 'contact_type' field with 'authorship' field in 'purchase_order_line' model.
- 'contact_type' field in 'purchase_order_line' model is now a related field from the authorship field.
- Update invoice, sale order, and purcharse order reports xml views.

## [17.0.1.7.0] - 2026-03-17

### Fixed

- Solved minor warnings about Odoo code.
- Fix some fields values for the purchase deposit picking type created in data (only relevant for new installations).
- Fix the helper widget in liquidations and deposit return for both sales and purchases (the deposit for the contact of the document).
- Fix bug when closing a negative ddaa order creates new ddaa orders for the other authorships of the product.
- When updating prices for books delivered to authors, only update ddaa_orders for authorships that generates DDAA.
- Fix bug when a liquidation order has lines with negative quantities (liquidation returns). Now, two pickings are created: one for the positive quantities (LIQ) and another for the negative quantities (RLIQ).

### Added

- Added new translated terms
- Add audiobook category :warning: User action needed: If needed, add audiobook category to the categories that generate DDAA in 'gestion_editorial' settings.
- Add filters for product view: "all_books", "physical_books", "ebooks", and "audiobooks"
- Set the default filter as "all_books"

## [17.0.1.6.2] - 2026-02-13

### Fixed

- Fix bug with getting correct ddaa_qty when selecting a pricelist that gets the ddaa amount from the sale's price.
- Fix bug when opening deposit search

## [17.0.1.6.1] - 2026-02-11

### Changed

- Hide pricelist in sales deposit return view

### Fixed

- Get the deposit sales partner from `picking_id` and not from `move_id`

## [17.0.1.6.0] - 2026-01-21

### Changed

- Hide create invoice button in sales deposit return view

## [17.0.1.5.0] - 2026-01-21

### Fixed

- Fix bug with liquidations and ddaa creation

### Changed

- Remove consignment configuration (by default is False)
- Hide create invoice buttons in deposit return views
- Block creation of invoices from deposit returns views
- Translate some liquidation messages :warning: User action needed: reload spanish and catalan translations.

## [17.0.1.4.0] - 2026-01-16

### Added

- Add setting to install subscriptions module.

### Changed

- Fix bug with getting pricelist in liquidations by linking stock.picking with sale.order and sale.order.line with stock.move when creating a liquidation.
- Change some texts in purchase liq views :warning: User action needed: reload spanish and catalan translations.

### Fixed

- Fix purchase liq status "To invoice" when invoice already exists

## [17.0.1.3.0] - 2026-01-08

### Changed

- Add catalan translation for "Orders" menu title. :warning: User action needed: reload catalan translations.
- Change purchase order translation "Confirmar pedido" to "Confirmar :warning: User action needed: reload spanish translations.
- Set "no" invoice status after confirm to return of sales deposit
- Change message after make a purchase deposit return in related purchase orders
- Change visible columns in liquidation wizard

## [17.0.1.2.4] - 2025-12-17

### Added

- New filters to stock picking view
- New wizard for managing negative ddaa_orders. When closing a negative ddaa_order you can now decide to open a new ddaa_order and distribute the amounts in the new order lines.

### Changed

- Display barcode column only if any row as a barcode (in report views)
- Refactor of editorial liquidations

### Fixed

- Fix error creating product with contact

## [17.0.1.2.3] - 2025-12-04

The last undocumented release. We will document the following versions.
