"""FastAPI production template package."""
