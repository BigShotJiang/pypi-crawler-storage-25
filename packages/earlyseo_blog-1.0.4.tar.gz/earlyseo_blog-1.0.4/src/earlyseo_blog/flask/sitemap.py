"""
Flask sitemap helpers for EarlySEO blog articles.

Usage::

    from flask import Flask
    from earlyseo_blog.flask.sitemap import create_blog_sitemap_entries, register_blog_sitemap

    app = Flask(__name__)
    app.config["EARLYSEO_SITE_ID"] = "your-site-id"
    app.config["SERVER_NAME"] = "example.com"

    # Option 1: Register a /blog/sitemap.xml route automatically
    register_blog_sitemap(app, url_prefix="/blog")

    # Option 2: Get entries and build your own sitemap
    with app.app_context():
        entries = create_blog_sitemap_entries()
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from flask import Blueprint, Response, current_app
from markupsafe import escape

from earlyseo_blog.client import EarlySeoClient


def _get_client() -> EarlySeoClient:
    site_id = current_app.config.get("EARLYSEO_SITE_ID", "")
    if not site_id:
        raise ValueError("EARLYSEO_SITE_ID must be set in Flask app config")
    cdn = current_app.config.get("EARLYSEO_CDN_BASE_URL")
    kwargs: dict = {"site_id": site_id}
    if cdn:
        kwargs["cdn_base_url"] = cdn
    return EarlySeoClient(**kwargs)


def _parse_iso(date_str: str) -> Optional[str]:
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00")).replace(
            tzinfo=timezone.utc
        )
        return dt.strftime("%Y-%m-%dT%H:%M:%S+00:00")
    except (ValueError, AttributeError):
        return None


def create_blog_sitemap_entries(
    *,
    base_url: Optional[str] = None,
    blog_path: str = "/blog",
    changefreq: str = "weekly",
    priority: str = "0.7",
) -> List[dict]:
    """
    Fetch all published articles and return a list of sitemap entry dicts.

    Each dict has keys: ``url``, ``lastmod`` (optional), ``changefreq``, ``priority``.
    """
    client = _get_client()
    manifest = client.get_manifest()
    if not manifest:
        return []

    if base_url is None:
        base_url = current_app.config.get("EARLYSEO_BASE_URL", "")

    normalised_base = base_url.rstrip("/")
    normalised_path = blog_path.rstrip("/")

    entries: List[dict] = []

    # Blog list page
    entries.append(
        {
            "url": f"{normalised_base}{normalised_path}",
            "lastmod": _parse_iso(manifest.updated_at),
            "changefreq": changefreq,
            "priority": str(round(float(priority) - 0.1, 1)),
        }
    )

    for page in range(1, manifest.total_pages + 1):
        list_page = client.get_list_page(page)
        if not list_page:
            continue
        for article in list_page.articles:
            entries.append(
                {
                    "url": f"{normalised_base}{normalised_path}/{article.slug}",
                    "lastmod": _parse_iso(article.created_at),
                    "changefreq": changefreq,
                    "priority": priority,
                }
            )

    return entries


def _render_sitemap_xml(entries: List[dict]) -> str:
    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    lines.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
    for entry in entries:
        lines.append("  <url>")
        lines.append(f"    <loc>{escape(entry['url'])}</loc>")
        if entry.get("lastmod"):
            lines.append(f"    <lastmod>{escape(entry['lastmod'])}</lastmod>")
        if entry.get("changefreq"):
            lines.append(f"    <changefreq>{escape(entry['changefreq'])}</changefreq>")
        if entry.get("priority"):
            lines.append(f"    <priority>{escape(entry['priority'])}</priority>")
        lines.append("  </url>")
    lines.append("</urlset>")
    return "\n".join(lines)


def register_blog_sitemap(
    app,
    *,
    url_prefix: str = "/blog",
    base_url: Optional[str] = None,
) -> None:
    """
    Register a ``/blog/sitemap.xml`` route on the Flask app that serves
    a sitemap of all published EarlySEO blog articles.
    """
    bp = Blueprint("earlyseo_sitemap", __name__)

    @bp.route("/sitemap.xml")
    def blog_sitemap():
        entries = create_blog_sitemap_entries(
            base_url=base_url, blog_path=url_prefix
        )
        xml = _render_sitemap_xml(entries)
        return Response(xml, content_type="application/xml; charset=utf-8")

    app.register_blueprint(bp, url_prefix=url_prefix)
