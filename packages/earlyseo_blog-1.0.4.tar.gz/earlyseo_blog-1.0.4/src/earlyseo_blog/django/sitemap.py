"""
Django sitemap class for EarlySEO blog articles.

Usage in ``urls.py``::

    from django.contrib.sitemaps.views import sitemap
    from earlyseo_blog.django.sitemap import EarlySeoBlogSitemap

    sitemaps = {
        "blog": EarlySeoBlogSitemap,
    }

    urlpatterns = [
        path("sitemap.xml", sitemap, {"sitemaps": sitemaps}, name="sitemap"),
        path("blog/", include("earlyseo_blog.django.urls")),
    ]
"""

from __future__ import annotations

from django.conf import settings
from django.contrib.sitemaps import Sitemap

from earlyseo_blog.client import EarlySeoClient


class EarlySeoBlogSitemap(Sitemap):
    """Sitemap for all published EarlySEO blog articles."""

    changefreq = "weekly"
    priority = 0.7

    def _get_client(self) -> EarlySeoClient:
        site_id = getattr(settings, "EARLYSEO_SITE_ID", "")
        if not site_id:
            raise ValueError("EARLYSEO_SITE_ID must be set in Django settings")
        cdn = getattr(settings, "EARLYSEO_CDN_BASE_URL", None)
        kwargs: dict = {"site_id": site_id}
        if cdn:
            kwargs["cdn_base_url"] = cdn
        return EarlySeoClient(**kwargs)

    def items(self):
        """Return a list of dicts with slug and created_at for every article."""
        client = self._get_client()
        manifest = client.get_manifest()
        if not manifest:
            return []

        articles = []
        for page in range(1, manifest.total_pages + 1):
            list_page = client.get_list_page(page)
            if not list_page:
                continue
            for article in list_page.articles:
                articles.append(
                    {"slug": article.slug, "created_at": article.created_at}
                )
        return articles

    def location(self, item: dict) -> str:
        blog_path = getattr(settings, "EARLYSEO_BLOG_PATH", "/blog")
        return f"{blog_path.rstrip('/')}/{item['slug']}/"

    def lastmod(self, item: dict):
        from datetime import datetime, timezone

        try:
            return datetime.fromisoformat(
                item["created_at"].replace("Z", "+00:00")
            ).replace(tzinfo=timezone.utc)
        except (ValueError, KeyError):
            return None
