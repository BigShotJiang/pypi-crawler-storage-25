#!/bin/bash
# Display the last line of the runner.log files for all countries in a given
# scenario combination.
#
# Usage:
#
#
#     ./monitor_log_files.sh /home/paul/rp/eu_cbm/eu_cbm_data/output/reference

SCENARIO_DIR=${1:?Usage: $0 <scenario_output_dir>}

for d in "$SCENARIO_DIR"/*/0/; do
  country=$(basename "$(dirname "$d")")
  last=$(tail -1 "$SCENARIO_DIR/$country/0/logs/runner.log" 2>/dev/null)
  echo "$country: $last"
done


