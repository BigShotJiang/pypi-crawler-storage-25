
This document explains how the Net Annual Increment (NAI) and Gross Annual Increment (GAI) are
computed in `eu_cbm_hat`, walks through each step of the computation from raw CBM output tables
to final per-hectare values, and discusses the particular treatment of afforestation and
deforestation. A final section proposes how NAI could be computed *within* the simulation time
step rather than as a post-processing step.


# Background: what NAI and GAI measure

In forestry, the **Gross Annual Increment (GAI)** is the total volume of new wood produced by a
forest stand in one year, regardless of losses. The **Net Annual Increment (NAI)** is the gross
increment minus natural mortality (turnover). Both are typically expressed in cubic metres of
wood per year, either as a total or per hectare (m³/ha/yr).

In CBM, all carbon fluxes are tracked explicitly. NAI and GAI can therefore be reconstructed
from the simulated carbon pools and fluxes by:

1. Computing the year-over-year change in standing biomass stock (the net stock change).
2. Adding back the carbon that left the standing biomass pool through harvesting or disturbances
   — since that carbon was *produced* by the forest even if it is no longer standing.
3. For GAI, also adding back natural turnover (mortality), which NAI excludes by definition.

All pool and flux values in CBM are in **tonnes of carbon (tC)**. They are converted to
**cubic metres over bark (m³ ob)** before computing NAI. The conversion formula is explained
in the section below.



# Step 1 — Merging and aggregating pools and fluxes (`pools_fluxes_morf`)

The raw CBM output consists of two tables: `pools` (the carbon content of each pool at each
time step, for each stand) and `flux` (the carbon transferred between pools during each time
step). Both tables are at the stand level — one row per stand identifier per time step.

The post-processor first aggregates these tables by year, disturbance type, and classifiers
(status, forest type, and so on). The grouping index is:

```
["year", "disturbance_type"] + classifier columns
```

**Pool aggregation (`pools_morf`)**

Softwood and hardwood pools are summed into four composite variables:

| Composite variable | CBM source pools                                                          |
|--||
| `merch`            | `softwood_merch` + `hardwood_merch`                                       |
| `other`            | `softwood_other` + `hardwood_other`   (other woody components, OWC)      |
| `roots`            | `softwood_fine_roots` + `hardwood_fine_roots` + coarse equivalents        |
| `foliage`          | `softwood_foliage` + `hardwood_foliage`                                   |

The `merch` pool holds stemwood (the commercially valuable component). The `other` (OWC) pool
holds branches, bark and other above-ground woody components.

**Flux aggregation (`fluxes_morf`)**

Six flux categories are retained for NAI computation (all in tC/yr):

| Variable                         | Description                                                          |
|-|-|
| `merch_prod`                     | Stemwood transferred to wood products by harvesting                  |
| `oth_prod`                       | OWC transferred to wood products by harvesting                       |
| `turnover_merch_litter_input`    | Stemwood transferred to dead organic matter by natural mortality      |
| `turnover_oth_litter_input`      | OWC transferred to dead organic matter by natural mortality           |
| `disturbance_merch_litter_input` | Stemwood transferred to dead organic matter by disturbances           |
| `disturbance_oth_litter_input`   | OWC transferred to dead organic matter by disturbances                |
| `disturbance_merch_to_air`       | Stemwood directly emitted to the atmosphere (e.g. combustion)         |
| `disturbance_oth_to_air`         | OWC directly emitted to the atmosphere (e.g. combustion)              |

The merged table `pools_fluxes_morf` is a join of `pools_morf` and `fluxes_morf` on the
grouping index.

**Code location**: `PostProcessor.pools_morf`, `PostProcessor.fluxes_morf`,
`PostProcessor.pools_fluxes_morf` in `eu_cbm_hat/post_processor/__init__.py`.



# Step 2 — Carbon to volume conversion (`pools_fluxes_vol`)

All CBM pools and fluxes are in **tonnes of carbon**. To produce NAI in the standard forestry
unit (m³/yr), they are converted to **cubic metres over bark (m³ ob)**.

The conversion relies on two species-specific parameters, looked up by `forest_type`:

- **`wood_density`**: dry biomass per unit volume (t/m³ ob).
- **`bark_frac`**: the fraction of total wood volume that is bark.

The general relationship between carbon mass and biomass volume is:

> carbon mass (tC) = biomass volume (m³ ob) × wood density (t/m³ ob) × carbon fraction

The **carbon fraction of biomass** is the proportion of dry biomass that is carbon. CBM uses
the IPCC default value:

```
CARBON_FRACTION_OF_BIOMASS = 0.49
```

Rearranging to get volume from carbon mass:

```
m³ ob = tC / (0.49 × wood_density)
```

This is the `ton_carbon_to_m3_ob()` function in `eu_cbm_hat/post_processor/convert.py`. Note
that the "over bark" formula does **not** subtract `bark_frac`, because over-bark volume already
includes bark — the wood density parameter is calibrated to account for it.

The following volume variables are derived in `NAI.pools_fluxes_vol`:

| Volume variable           | Source carbon variable               |
||--|
| `merch_stock_vol`         | `merch`                              |
| `agb_stock_vol`           | `merch + other` (above-ground total) |
| `merch_prod_vol`          | `merch_prod`                         |
| `other_prod_vol`          | `oth_prod`                           |
| `turnover_merch_loss_vol` | `turnover_merch_litter_input`        |
| `turnover_oth_loss_vol`   | `turnover_oth_litter_input`          |
| `dist_merch_loss_vol`     | `disturbance_merch_litter_input`     |
| `dist_oth_loss_vol`       | `disturbance_oth_litter_input`       |
| `merch_air_vol`           | `disturbance_merch_to_air`           |
| `oth_air_vol`             | `disturbance_oth_to_air`             |

**Code location**: `NAI.pools_fluxes_vol` in `eu_cbm_hat/post_processor/nai.py`.



# Step 3 — Aggregation by grouping variables (`df_agg`)

The caller specifies one or more grouping variables (typically `["status"]`). The table is
aggregated by `["year"] + groupby` — summing area, all pool volumes and all flux volumes across
all classifiers within each group and year.

The available `df_agg` methods are:

| Method                      | Grouping                              |
|--||
| `df_agg(["status"])`        | By land-use status only               |
| `df_agg_con_broad([...])`   | By status and coniferous/broadleaf    |
| `df_agg_con_broad_climate`  | By status, con/broad, and climate zone|

## Treatment of NF fluxes

The `status` classifier marks each stand as one of:

- **`ForAWS`** — Forest Available for Wood Supply (managed forest).
- **`AR`** — land undergoing Afforestation/Reforestation.
- **`NF`** — Non-Forest (land that has been deforested and lost its forest classification).

After aggregation, the code detects all rows with `status == "NF"` and adds their flux values
(products, litter inputs, etc.) into the corresponding `ForAWS` row for the same year. The
`NF` rows are then excluded from the final output.

```python
# Simplified logic in df_agg():
selector = df_agg["status"] == "NF"
df_agg_nf = df_agg.loc[selector, ["year", "status"] + FLUXES_COLS].copy()
df_agg_nf["status"] = "ForAWS"  # re-label as ForAWS before merging
df_agg = df_agg.merge(df_agg_nf, on=["year"] + groupby, how="left")
# add NF fluxes into ForAWS fluxes, then drop NF rows
```

The reason for this treatment is explained in the afforestation/deforestation section below.

**Code location**: `NAI.df_agg` in `eu_cbm_hat/post_processor/nai.py`.



# Step 4 — Computing NAI and GAI (`compute_nai_gai`)

Once the table has one row per group per year, the function `compute_nai_gai()` computes the
year-over-year stock change and derives NAI and GAI.

## Net stock change

The year-over-year change in standing stock volume is computed using a grouped difference:

```python
df["net_merch"] = df.groupby(groupby)["merch_stock_vol"].diff()
df["net_agb"]   = df.groupby(groupby)["agb_stock_vol"].diff()
```

This yields the change in standing wood volume within each group from one year to the next. A
positive value means the stock grew; a negative value means more was lost than grew.

## NAI and GAI equations

Using the notation:

| Symbol                | Variable in code             | Description                                          |
|--|||
| ΔS_merch              | `net_merch`                  | Year-over-year change in merchantable stock (m³)     |
| ΔS_agb                | `net_agb`                    | Year-over-year change in above-ground biomass (m³)   |
| H_merch               | `merch_prod_vol`             | Stemwood harvested to products (m³)                  |
| H_other               | `other_prod_vol`             | OWC harvested to products (m³)                       |
| D_merch               | `dist_merch_loss_vol`        | Stemwood transferred to litter by disturbances (m³)  |
| D_other               | `dist_oth_loss_vol`          | OWC transferred to litter by disturbances (m³)       |
| T_merch               | `turnover_merch_loss_vol`    | Stemwood lost to litter by natural mortality (m³)    |
| T_other               | `turnover_oth_loss_vol`      | OWC lost to litter by natural mortality (m³)         |
| E_merch               | `merch_air_vol`              | Stemwood emitted directly to air (combustion) (m³)   |
| E_other               | `oth_air_vol`                | OWC emitted directly to air (combustion) (m³)        |

**Merchantable pool (stemwood only)**:

```
NAI_merch = ΔS_merch + H_merch + D_merch
GAI_merch = NAI_merch + T_merch + E_merch
          = ΔS_merch + H_merch + D_merch + T_merch + E_merch
```

**Above-ground biomass (stemwood + OWC)**:

```
NAI_agb = ΔS_agb + H_merch + H_other + D_merch + D_other
GAI_agb = NAI_agb + T_merch + T_other + E_merch + E_other
        = ΔS_agb + H_merch + H_other + D_merch + D_other
                 + T_merch + T_other + E_merch + E_other
```

## Conceptual interpretation

The carbon balance for the merchantable pool within one year is:

```
ΔS_merch = Growth_merch - T_merch - H_merch - D_merch - E_merch
```

Rearranging:

```
Growth_merch = ΔS_merch + T_merch + H_merch + D_merch + E_merch  →  GAI_merch
```

GAI is therefore the total biological production of new wood. NAI removes natural mortality
(`T_merch`) and direct combustion (`E_merch`), retaining only losses that represent physically
harvested or displaced wood:

```
NAI_merch = GAI_merch - T_merch - E_merch
          = ΔS_merch  + H_merch + D_merch
```

Intuitively: NAI is the increment that *could have been* standing wood if not for harvests and
disturbance-driven transfers to dead organic matter. Mortality (turnover) and combustion are
excluded because they represent wood that was produced but lost to biological senescence or fire,
not captured by the forest sector.

> **Note**: foliage is currently absent from these equations. Including foliage would be
> appropriate for ecosystem-level NAI indicators. See the note at the end of the `NAI` class
> docstring.

## Per-hectare values

After computing totals, per-hectare equivalents are derived by dividing by the aggregated area:

```
NAI_merch_ha = NAI_merch / area
GAI_merch_ha = GAI_merch / area
NAI_agb_ha   = NAI_agb   / area
GAI_agb_ha   = GAI_agb   / area
```

**Code location**: `compute_nai_gai()` in `eu_cbm_hat/post_processor/nai.py`.



# Special cases: afforestation and deforestation

## Afforestation (status `AR`)

Land in the `AR` category (Afforestation/Reforestation) is land that was previously non-forest
and is being planted or naturally regenerating into forest. It carries its own `status` rows
through the simulation.

In the current implementation:

- `AR` rows appear in the aggregated table alongside `ForAWS` rows.
- The NAI computation (`compute_nai_gai`) applies equally to `AR` rows: it computes the stock
  difference for `AR` land over time.
- In `df_agg_con_broad_climate`, `AR` rows are explicitly excluded from the final output
  (`df_out_con_broad[(df_out_con_broad["status"] != "NF") & (df_out_con_broad["status"] != "AR")]`).
- The `df_agg` method does not exclude `AR` rows, so they appear in the output where they can
  be analysed separately (e.g. to track how quickly newly afforested stands accumulate biomass).

The first NAI value for `AR` land is always zero (the `diff()` on the first year returns NaN,
which is treated as zero by the `sum()` call), as there is no preceding year stock to compare to.

## Deforestation (status `NF`)

When a forest stand is deforested (disturbance type 7), it transitions to the `NF`
(Non-Forest) status. The deforested stand may still generate carbon fluxes in the same year
(products removed during the harvest, litter inputs to the soil, etc.). These fluxes appear in
the CBM output under `status == "NF"`.

In the `df_agg` method, the `NF` flux values are merged back into the `ForAWS` rows for the
same year. This ensures that the products and litter inputs from the deforestation event are
attributed to the forest sector's NAI rather than disappearing when `NF` rows are dropped.

The mechanism is:

1. Extract all flux columns for rows where `status == "NF"`.
2. Re-label their `status` as `"ForAWS"`.
3. Merge back into the main table on `["year"] + groupby`.
4. Add the re-labelled NF flux values to the ForAWS flux values.
5. Drop the original `NF` rows from the output.

> **Note to document author**: the full rationale for this treatment (in particular why it is
> correct to attribute NF fluxes to ForAWS rather than to a separate deforestation category)
> should be clarified with the team and added here.



# Why NAI is only available as a post-processing step

The `NAI` class is part of the `PostProcessor` hierarchy and can only be called **after the
full model run has completed and the output tables have been written to disk**.

There are two reasons for this:

**1. The output tables must exist.**

`NAI.pools_fluxes_vol` reads from `runner.output["pools"]` and `runner.output["flux"]`, which
are the full time-series output tables produced by the simulation. These are only available once
the run has finished.

**2. NAI requires a multi-year stock difference.**

The core NAI computation uses:

```python
df["net_merch"] = df.groupby(groupby)["merch_stock_vol"].diff()
```

This pandas `diff()` operation computes the change between consecutive years **across the entire
time series at once**. It requires all years to be present in memory simultaneously. This is
fundamentally incompatible with computing NAI time-step-by-time-step during the simulation,
where only the current year's state is available.

In other words: to know the stock change in year *t*, you need the stock level at year *t−1*.
During the simulation, the previous year's pool table is not available inside the time-step
loop — it has already been processed and is not retained in memory.

This is why NAI can only be computed after the run, when the full output table spans all years
and the `diff()` can be applied globally.



# Draft: NAI computation within the time step

> **Status**: this section is a design draft. It describes a technically feasible approach
> but has not yet been implemented.

## Motivation

There are situations where it would be useful to have an estimate of NAI *during* the
simulation — for example, to monitor whether the simulated forest is growing at expected rates,
or potentially to inform harvest allocation decisions. The post-processing approach requires
waiting until the run is complete, which makes it unsuitable for these purposes.

## What is available inside `dynamics_func`

The `DynamicSimulation.dynamics_func` method in `eu_cbm_hat/cbm/dynamic.py` is called by
libcbm at every simulation time step. It receives `cbm_vars`, the full state of all stands at
the **beginning** of the current time step (pools, fluxes, classifiers, state variables, etc.).

Crucially, the method already performs a *virtual* CBM step:

```python
end_vars = copy.deepcopy(cbm_vars)
end_vars = self.cbm.step(end_vars)
```

This call applies the full CBM annual process to a copy of `cbm_vars`, producing `end_vars`
which contains:

- **Pools after the full annual process**: growth, natural turnover (mortality), litter and soil
  carbon decay, and any disturbances that were **predetermined** in the input (e.g. natural
  disturbances already encoded in the events table before the run started).
- **Fluxes for the same year**: the carbon transferred during this virtual step — products from
  predetermined harvests, turnover litter inputs, disturbance litter inputs, emissions to air.

What `end_vars` does **not yet contain** is the effect of the **HAT-allocated harvest
disturbances** — these are the harvesting events that `dynamics_func` is in the process of
determining. HAT reads `end_vars` to decide how much wood is available, then injects harvest
disturbance events back into `cbm_vars`, which libcbm will apply when it runs its own
`cbm.step()` at the end of the time step.

This is the key distinction: `end_vars` represents the state of the forest *as if only growth,
natural mortality, and pre-specified disturbances had occurred* — not the final state after
HAT-driven harvesting.

## Computing NAI from `cbm_vars` and `end_vars`

Given `cbm_vars` (start of step) and `end_vars` (end of step, before HAT harvest), a within-
timestep NAI for the merchantable pool can be written as:

```
NAI_merch(t) = [end_pools_merch(t) - start_pools_merch(t)] × area
             + end_flux_merch_to_product(t) × area
             + end_flux_dist_merch_litter(t) × area
```

where `start_pools_merch` comes from `cbm_vars.pools` and all `end_` quantities come from
`end_vars.pools` and `end_vars.flux`.

In practice, the `stands` dataframe that `dynamics_func` already builds (after area scaling)
contains the necessary columns:

```python
# stands already has area-scaled pools and fluxes from end_vars
# Pool change (net stock change) requires also the start-of-step pools:
start_merch = (cbm_vars_to_df(cbm_vars, "pools")[["SoftwoodMerch", "HardwoodMerch"]]
               .sum(axis=1)
               .multiply(cbm_vars_to_df(cbm_vars, "inventory")["area"]))
end_merch   = stands["SoftwoodMerch"] + stands["HardwoodMerch"]  # already area-scaled

net_merch   = end_merch - start_merch
merch_prod  = stands["softwood_merch_to_product"] + stands["hardwood_merch_to_product"]
dist_litter = stands["disturbance_merch_litter_input"]

nai_merch_total = (net_merch + merch_prod + dist_litter).sum()
```

To convert to m³ ob, the same formula applies:

```
m³ ob = tC / (0.49 × wood_density)
```

Wood density is available from `self.runner.silv.coefs.df` (already loaded in `dynamics_func`
for the harvest volume calculation), so the conversion can be applied per forest type.

## Caveats and limitations

1. **HAT harvest is excluded.** The NAI computed this way reflects growth and predetermined
   disturbances only. The harvest disturbances that HAT is about to inject will further reduce
   the standing stock, but those fluxes are not yet in `end_vars.flux`. The final NAI (including
   HAT harvest) can only be known after libcbm has run its own step on the modified `cbm_vars`.

2. **NF and AR stands require special treatment.** Deforested stands (NF) and afforesting
   stands (AR) need the same handling as in the post-processing computation (attributing NF
   fluxes to ForAWS). The classifier columns needed to identify these stands are available in
   the `stands` dataframe.

3. **First time step.** The stock difference in the very first time step compares against the
   initial inventory pools. This is consistent with the post-processing computation (which also
   returns NaN/zero for the first year), but should be handled explicitly.

4. **This is a pre-HAT-harvest NAI estimate.** If the goal is to inform HAT harvest decisions
   with NAI, this estimate (representing biological production before harvesting) is actually
   well-suited: it quantifies how much the forest grew before the model applies any new
   silvicultural disturbances.
