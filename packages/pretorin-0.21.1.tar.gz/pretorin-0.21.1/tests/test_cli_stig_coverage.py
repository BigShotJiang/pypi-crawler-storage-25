"""Coverage tests for src/pretorin/cli/stig.py.

Targets all five STIG commands: list, show, rules, applicable, infer — in both
normal and JSON modes plus error handling and empty-result branches.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest
from typer.testing import CliRunner

from pretorin.cli.main import app
from pretorin.cli.output import set_json_mode
from pretorin.client.api import PretorianClientError

runner = CliRunner()


@pytest.fixture(autouse=True)
def _reset_json_mode():
    set_json_mode(False)
    yield
    set_json_mode(False)


def _run_with_mock_client(args: list[str], client: AsyncMock) -> object:
    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=client)
    ctx.__aexit__ = AsyncMock(return_value=None)
    with patch("pretorin.client.api.PretorianClient", return_value=ctx):
        return runner.invoke(app, args)


def _base_client() -> AsyncMock:
    client = AsyncMock()
    client.is_configured = True
    return client


# =============================================================================
# stig list
# =============================================================================


def test_stig_list_normal_with_items() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(
        return_value={
            "total": 1,
            "items": [
                {
                    "stig_id": "RHEL_9_STIG",
                    "title": "Red Hat Enterprise Linux 9 Security Technical Implementation Guide",
                    "technology_area": "OS",
                    "rule_count": 250,
                    "severity_counts": {"cat_i": 10, "cat_ii": 200, "cat_iii": 40},
                },
            ],
        }
    )

    result = _run_with_mock_client(["stig", "list", "--technology-area", "OS"], client)

    assert result.exit_code == 0, result.output
    assert "RHEL_9_STIG" in result.output
    client.list_stigs.assert_awaited_once()
    kwargs = client.list_stigs.await_args.kwargs
    assert kwargs.get("technology_area") == "OS"


def test_stig_list_empty() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(return_value={"total": 0, "items": []})

    result = _run_with_mock_client(["stig", "list"], client)

    assert result.exit_code == 0
    assert "No STIG benchmarks" in result.output


def test_stig_list_json_mode() -> None:
    client = _base_client()
    data = {
        "total": 1,
        "items": [
            {
                "stig_id": "RHEL_9_STIG",
                "title": "RHEL 9",
                "technology_area": "OS",
                "rule_count": 1,
                "severity_counts": {"cat_i": 0, "cat_ii": 1, "cat_iii": 0},
            },
        ],
    }
    client.list_stigs = AsyncMock(return_value=data)

    result = _run_with_mock_client(["--json", "stig", "list"], client)

    assert result.exit_code == 0, result.output
    assert json.loads(result.stdout) == data


def test_stig_list_error() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(side_effect=PretorianClientError("Not authorized"))

    result = _run_with_mock_client(["stig", "list"], client)

    assert result.exit_code == 1
    assert "Not authorized" in result.output


# =============================================================================
# stig show
# =============================================================================


def test_stig_show_normal_mode() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(
        return_value={
            "items": [
                {
                    "stig_id": "RHEL_9_STIG",
                    "title": "Red Hat Enterprise Linux 9 STIG",
                    "version": "V1R1",
                    "technology_area": "OS",
                    "product": "RHEL 9",
                    "vendor": "Red Hat",
                    "rule_count": 250,
                    "severity_counts": {"cat_i": 10, "cat_ii": 200, "cat_iii": 40},
                },
            ],
        }
    )

    result = _run_with_mock_client(["stig", "show", "RHEL_9_STIG"], client)

    assert result.exit_code == 0, result.output
    assert "RHEL_9_STIG" in result.output
    assert "V1R1" in result.output
    assert "Red Hat" in result.output


def test_stig_show_not_found() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(return_value={"items": []})

    result = _run_with_mock_client(["stig", "show", "NOPE"], client)

    assert result.exit_code == 1
    assert "not found" in result.output.lower()


def test_stig_show_json_mode_match() -> None:
    client = _base_client()
    item = {
        "stig_id": "RHEL_9_STIG",
        "title": "RHEL 9 STIG",
        "version": "V1R1",
        "technology_area": "OS",
        "product": "RHEL 9",
        "vendor": "Red Hat",
        "rule_count": 1,
        "severity_counts": {"cat_i": 0, "cat_ii": 1, "cat_iii": 0},
    }
    client.list_stigs = AsyncMock(return_value={"items": [item]})

    result = _run_with_mock_client(["--json", "stig", "show", "RHEL_9_STIG"], client)

    assert result.exit_code == 0, result.output
    assert json.loads(result.stdout) == item


def test_stig_show_json_mode_not_found() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(return_value={"items": []})

    result = _run_with_mock_client(["--json", "stig", "show", "NOPE"], client)

    # In JSON mode the command emits an error payload but does not exit non-zero
    assert result.exit_code == 0
    assert json.loads(result.stdout) == {"error": "not found"}


def test_stig_show_error() -> None:
    client = _base_client()
    client.list_stigs = AsyncMock(side_effect=PretorianClientError("Server error"))

    result = _run_with_mock_client(["stig", "show", "RHEL_9_STIG"], client)

    assert result.exit_code == 1
    assert "Server error" in result.output


# =============================================================================
# stig rules
# =============================================================================


def test_stig_rules_normal_with_items() -> None:
    client = _base_client()
    client.list_stig_rules = AsyncMock(
        return_value={
            "total": 1,
            "items": [
                {
                    "stig_ref": "SV-230221r858671_rule",
                    "rule_id": "SV-230221r858671_rule",
                    "group_id": "V-230221",
                    "severity": "cat_ii",
                    "title": "RHEL 8 must employ strong authenticators.",
                    "cci_ids": ["CCI-000015"],
                },
            ],
        }
    )

    result = _run_with_mock_client(
        ["stig", "rules", "RHEL_9_STIG", "--severity", "cat_ii", "--cci", "CCI-000015"],
        client,
    )

    assert result.exit_code == 0, result.output
    assert "V-230221" in result.output
    client.list_stig_rules.assert_awaited_once()
    args = client.list_stig_rules.await_args
    assert args.args[0] == "RHEL_9_STIG"
    assert args.kwargs.get("severity") == "cat_ii"
    assert args.kwargs.get("cci_id") == "CCI-000015"


def test_stig_rules_empty() -> None:
    client = _base_client()
    client.list_stig_rules = AsyncMock(return_value={"total": 0, "items": []})

    result = _run_with_mock_client(["stig", "rules", "RHEL_9_STIG"], client)

    assert result.exit_code == 0
    assert "No rules found" in result.output


def test_stig_rules_json_mode() -> None:
    client = _base_client()
    data = {
        "total": 1,
        "items": [
            {
                "stig_ref": "SV-1",
                "rule_id": "SV-1",
                "group_id": "V-1",
                "severity": "cat_i",
                "title": "Test rule",
                "cci_ids": ["CCI-000001"],
            },
        ],
    }
    client.list_stig_rules = AsyncMock(return_value=data)

    result = _run_with_mock_client(["--json", "stig", "rules", "RHEL_9_STIG"], client)

    assert result.exit_code == 0, result.output
    assert json.loads(result.stdout) == data


def test_stig_rules_handles_missing_severity_and_title() -> None:
    """Branch where item.get('severity') is empty and title is None — the
    formatter has special-cased these to avoid rich tag mismatches."""
    client = _base_client()
    client.list_stig_rules = AsyncMock(
        return_value={
            "items": [
                {
                    "stig_ref": "SV-1",
                    "group_id": "V-1",
                    "severity": "",
                    "title": None,
                    "cci_ids": [],
                },
            ],
        }
    )

    result = _run_with_mock_client(["stig", "rules", "RHEL_9_STIG"], client)

    assert result.exit_code == 0, result.output
    assert "SV-1" in result.output


def test_stig_rules_error() -> None:
    client = _base_client()
    client.list_stig_rules = AsyncMock(side_effect=PretorianClientError("Server error"))

    result = _run_with_mock_client(["stig", "rules", "RHEL_9_STIG"], client)

    assert result.exit_code == 1
    assert "Server error" in result.output


# =============================================================================
# stig applicable
# =============================================================================


def test_stig_applicable_normal_mode() -> None:
    client = _base_client()
    client.get_stig_applicability = AsyncMock(
        return_value={
            "applicability": [
                {
                    "stig_id": "RHEL_9_STIG",
                    "stig_name": "RHEL 9 STIG",
                    "source": "inferred",
                    "confidence": 0.85,
                    "is_confirmed": True,
                    "is_excluded": False,
                },
                {
                    "stig_id": "WIN_2022_STIG",
                    "stig_name": "Windows 2022 STIG",
                    "source": "manual",
                    "confidence": None,
                    "is_confirmed": False,
                    "is_excluded": True,
                },
                {
                    "stig_id": "DOCKER_STIG",
                    "stig_name": "Docker STIG",
                    "source": "inferred",
                    "confidence": 0.5,
                    "is_confirmed": False,
                    "is_excluded": False,
                },
            ],
        }
    )

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["stig", "applicable", "--system", "Primary"], client)

    assert result.exit_code == 0, result.output
    assert "RHEL_9_STIG" in result.output
    assert "Confirmed" in result.output
    assert "Excluded" in result.output
    assert "Pending" in result.output


def test_stig_applicable_empty() -> None:
    client = _base_client()
    client.get_stig_applicability = AsyncMock(return_value={"applicability": []})

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["stig", "applicable"], client)

    assert result.exit_code == 0
    assert "No STIG applicability data" in result.output


def test_stig_applicable_json_mode() -> None:
    client = _base_client()
    data = {
        "applicability": [
            {
                "stig_id": "RHEL_9_STIG",
                "stig_name": "RHEL 9",
                "source": "inferred",
                "confidence": 0.9,
                "is_confirmed": True,
                "is_excluded": False,
            },
        ],
    }
    client.get_stig_applicability = AsyncMock(return_value=data)

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["--json", "stig", "applicable"], client)

    assert result.exit_code == 0, result.output
    assert json.loads(result.stdout) == data


def test_stig_applicable_error() -> None:
    client = _base_client()
    client.get_stig_applicability = AsyncMock(side_effect=PretorianClientError("Server error"))

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["stig", "applicable"], client)

    assert result.exit_code == 1
    assert "Server error" in result.output


# =============================================================================
# stig infer
# =============================================================================


def test_stig_infer_normal_mode_with_results() -> None:
    client = _base_client()
    client.infer_stigs = AsyncMock(
        return_value={
            "system_name": "Primary",
            "system_id": "sys-1",
            "inferred": [
                {
                    "stig_id": "RHEL_9_STIG",
                    "stig_name": "RHEL 9 STIG",
                    "technology_area": "OS",
                    "confidence": 0.9,
                    "rationale": "RHEL 9 detected in tech stack",
                },
                {
                    "stig_id": "DOCKER_STIG",
                    "stig_name": "Docker STIG",
                    "technology_area": "Container",
                    "confidence": 0.55,
                    "rationale": "Docker mentioned",
                },
                {
                    "stig_id": "FALLBACK_STIG",
                    "stig_name": "Fallback STIG",
                    "technology_area": "Other",
                    "confidence": 0.2,
                    "rationale": "Low confidence",
                },
            ],
        }
    )

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["stig", "infer", "--system", "Primary"], client)

    assert result.exit_code == 0, result.output
    assert "RHEL_9_STIG" in result.output
    assert "Inferred: 3 applicable STIGs" in result.output


def test_stig_infer_empty() -> None:
    client = _base_client()
    client.infer_stigs = AsyncMock(return_value={"inferred": []})

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["stig", "infer"], client)

    assert result.exit_code == 0
    assert "No applicable STIGs inferred" in result.output


def test_stig_infer_json_mode() -> None:
    client = _base_client()
    data = {
        "system_name": "Primary",
        "system_id": "sys-1",
        "inferred": [
            {
                "stig_id": "RHEL_9_STIG",
                "stig_name": "RHEL 9",
                "technology_area": "OS",
                "confidence": 0.9,
                "rationale": "match",
            },
        ],
    }
    client.infer_stigs = AsyncMock(return_value=data)

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["--json", "stig", "infer"], client)

    assert result.exit_code == 0, result.output
    assert json.loads(result.stdout) == data


def test_stig_infer_error() -> None:
    client = _base_client()
    client.infer_stigs = AsyncMock(side_effect=PretorianClientError("Server error"))

    with patch(
        "pretorin.cli.context.resolve_execution_context",
        new=AsyncMock(return_value=("sys-1", "fedramp-moderate")),
    ):
        result = _run_with_mock_client(["stig", "infer"], client)

    assert result.exit_code == 1
    assert "Server error" in result.output
