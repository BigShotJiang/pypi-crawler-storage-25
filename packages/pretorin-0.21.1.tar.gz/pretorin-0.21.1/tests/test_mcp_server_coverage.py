"""Coverage tests for src/pretorin/mcp/server.py.

Covers lines 75-76 (AuthenticationError handler), 78-79 (NotFoundError handler),
83-85 (generic Exception handler), 90-91 (_run_server), 100-101 (run_server),
105 (__name__ == "__main__" guard).
"""

from __future__ import annotations

from io import StringIO
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pretorin.client.api import (
    AuthenticationError,
    NotFoundError,
    PretorianClientError,
    WorkflowRoutingError,
)


class TestCallToolErrorHandlers:
    """Tests for error handlers in call_tool."""

    @pytest.mark.asyncio
    async def test_authentication_error_handler(self):
        """Lines 75-76: AuthenticationError is caught and formatted."""
        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"test_tool": AsyncMock(side_effect=AuthenticationError("Token expired", status_code=401))},
            ),
        ):
            result = await call_tool("test_tool", {})

        assert result.isError is True
        assert "Authentication failed" in result.content[0].text

    @pytest.mark.asyncio
    async def test_not_found_error_handler(self):
        """Lines 78-79: NotFoundError is caught and formatted."""
        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"test_tool": AsyncMock(side_effect=NotFoundError("Resource not found", status_code=404))},
            ),
        ):
            result = await call_tool("test_tool", {})

        assert result.isError is True
        assert "Not found" in result.content[0].text

    @pytest.mark.asyncio
    async def test_generic_pretorianclient_error_handler(self):
        """Lines 80-82: PretorianClientError is caught and formatted."""
        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"test_tool": AsyncMock(side_effect=PretorianClientError("Server error", status_code=500))},
            ),
        ):
            result = await call_tool("test_tool", {})

        assert result.isError is True
        assert "Server error" in result.content[0].text

    @pytest.mark.asyncio
    async def test_workflow_routing_required_returns_structured_payload(self):
        """WorkflowRoutingError is converted to a structured JSON payload
        with error_code, message, and routing_hint — including the mapped
        suggested_intent_verb for tools registered in _TOOL_TO_INTENT_VERB."""
        import json as _json

        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        side_effect = WorkflowRoutingError(
            "No active system/framework context.",
            error_code="workflow_required",
            routing_hint={
                "reason": "no_active_context",
                "next_action": "call_start_task",
                "missing": ["system_id", "framework_id"],
            },
        )

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"create_evidence": AsyncMock(side_effect=side_effect)},
            ),
        ):
            result = await call_tool("create_evidence", {})

        assert result.isError is True
        payload = _json.loads(result.content[0].text)
        assert payload["error"] == "workflow_required"
        assert "No active system/framework context" in payload["message"]
        assert payload["routing_hint"]["reason"] == "no_active_context"
        assert payload["routing_hint"]["next_action"] == "call_start_task"
        assert payload["routing_hint"]["suggested_intent_verb"] == "collect_evidence"

    @pytest.mark.asyncio
    async def test_workflow_routing_required_without_intent_mapping(self):
        """Tools not in _TOOL_TO_INTENT_VERB still get the structured payload
        but without suggested_intent_verb."""
        import json as _json

        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        side_effect = WorkflowRoutingError(
            "Routing required",
            routing_hint={"reason": "no_active_context"},
        )

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"some_other_write_tool": AsyncMock(side_effect=side_effect)},
            ),
        ):
            result = await call_tool("some_other_write_tool", {})

        payload = _json.loads(result.content[0].text)
        assert payload["error"] == "workflow_required"
        assert "suggested_intent_verb" not in payload["routing_hint"]

    @pytest.mark.asyncio
    async def test_workflow_routing_required_emits_telemetry(self, capsys):
        """The structured error path also emits a PRETORIN_TELEMETRY_EVENT
        line to stderr so MCP hosts can scrape bypass rates."""
        import json as _json

        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        side_effect = WorkflowRoutingError(
            "Routing required",
            routing_hint={"reason": "no_active_context", "missing": ["system_id"]},
        )

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"create_evidence": AsyncMock(side_effect=side_effect)},
            ),
            patch.dict("os.environ", {}, clear=False),
        ):
            # Make sure telemetry isn't disabled in the test env.
            import os as _os

            _os.environ.pop("PRETORIN_MCP_TELEMETRY_DISABLED", None)
            await call_tool("create_evidence", {})

        captured = capsys.readouterr()
        telemetry_lines = [line for line in captured.err.splitlines() if line.startswith("PRETORIN_TELEMETRY_EVENT")]
        assert len(telemetry_lines) == 1
        event = _json.loads(telemetry_lines[0].removeprefix("PRETORIN_TELEMETRY_EVENT").strip())
        assert event["event_type"] == "workflow_routing_required"
        assert event["tool"] == "create_evidence"
        assert event["reason"] == "no_active_context"
        assert event["suggested_intent_verb"] == "collect_evidence"

    @pytest.mark.asyncio
    async def test_start_task_success_emits_telemetry(self, capsys):
        """Successful start_task calls emit a canonical-path event so the
        ratio of bypass events to start_task events can be computed."""
        import json as _json

        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"start_task": AsyncMock(return_value=[])},
            ),
        ):
            import os as _os

            _os.environ.pop("PRETORIN_MCP_TELEMETRY_DISABLED", None)
            await call_tool("start_task", {"entities": {}})

        captured = capsys.readouterr()
        telemetry_lines = [line for line in captured.err.splitlines() if line.startswith("PRETORIN_TELEMETRY_EVENT")]
        assert len(telemetry_lines) == 1
        event = _json.loads(telemetry_lines[0].removeprefix("PRETORIN_TELEMETRY_EVENT").strip())
        assert event["event_type"] == "start_task_succeeded"
        assert event["tool"] == "start_task"

    @pytest.mark.asyncio
    async def test_telemetry_disabled_env_suppresses_emission(self, capsys):
        """PRETORIN_MCP_TELEMETRY_DISABLED=1 suppresses telemetry output."""
        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        side_effect = WorkflowRoutingError("Routing required")

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"create_evidence": AsyncMock(side_effect=side_effect)},
            ),
            patch.dict("os.environ", {"PRETORIN_MCP_TELEMETRY_DISABLED": "1"}),
        ):
            await call_tool("create_evidence", {})

        captured = capsys.readouterr()
        telemetry_lines = [line for line in captured.err.splitlines() if line.startswith("PRETORIN_TELEMETRY_EVENT")]
        assert telemetry_lines == []

    @pytest.mark.asyncio
    async def test_generic_exception_handler(self):
        """Lines 83-85: Generic Exception is caught and formatted."""
        from pretorin.mcp.server import call_tool

        mock_client = AsyncMock()
        mock_client.is_configured = True
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        with (
            patch("pretorin.mcp.server.PretorianClient", return_value=mock_client),
            patch(
                "pretorin.mcp.server.TOOL_HANDLERS",
                {"test_tool": AsyncMock(side_effect=RuntimeError("Unexpected failure"))},
            ),
        ):
            result = await call_tool("test_tool", {})

        assert result.isError is True
        assert "Unexpected failure" in result.content[0].text


class TestRunServer:
    """Tests for _run_server and run_server."""

    @pytest.mark.asyncio
    async def test_run_server_async(self):
        """Lines 90-91: _run_server calls stdio_server and server.run."""
        from pretorin.mcp.server import _run_server

        mock_read = AsyncMock()
        mock_write = AsyncMock()

        with (
            patch("pretorin.mcp.server.stdio_server") as mock_stdio,
            patch("pretorin.mcp.server.server") as mock_server,
        ):
            # stdio_server is an async context manager
            mock_cm = AsyncMock()
            mock_cm.__aenter__ = AsyncMock(return_value=(mock_read, mock_write))
            mock_cm.__aexit__ = AsyncMock(return_value=None)
            mock_stdio.return_value = mock_cm

            mock_server.run = AsyncMock()
            mock_server.create_initialization_options = MagicMock(return_value={})

            await _run_server()

            mock_server.run.assert_awaited_once_with(mock_read, mock_write, {})

    def test_run_server_sync(self):
        """Lines 100-101: run_server calls asyncio.run(_run_server)."""
        from pretorin.mcp.server import run_server

        with patch("pretorin.mcp.server.asyncio.run") as mock_run:
            run_server()
            mock_run.assert_called_once()
            coroutine = mock_run.call_args.args[0]
            coroutine.close()

    def test_run_server_prints_update_notice_to_stderr(self):
        """Startup update notices should go to stderr, not stdout."""
        from pretorin.mcp.server import run_server

        stderr = StringIO()
        with (
            patch("pretorin.mcp.server.asyncio.run") as mock_run,
            patch(
                "pretorin.mcp.server.get_update_status",
                return_value={"prompt": "A newer version is available."},
            ),
            patch("sys.stderr", stderr),
        ):
            run_server()

        assert "NOTICE: A newer version is available." in stderr.getvalue()
        coroutine = mock_run.call_args.args[0]
        coroutine.close()


class TestMainGuard:
    """Test for __name__ == '__main__' guard."""

    def test_main_guard(self):
        """Line 105: __name__ == '__main__' calls run_server."""
        import pretorin.mcp.server as mod

        source_path = mod.__file__

        with open(source_path) as f:
            code = f.read()

        # Verify the guard exists and calls run_server
        assert 'if __name__ == "__main__"' in code
        assert "run_server()" in code
