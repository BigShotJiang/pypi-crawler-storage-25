"""Tests for the check_context MCP handler.

check_context is the session-start probe: cheap, unauthenticated, reads
local CLI config only. These tests exercise each `suggested_next` branch.
"""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from pretorin.mcp.handlers.engagement import handle_check_context


def _payload(response):
    if isinstance(response, list):
        return json.loads(response[0].text)
    return json.loads(response.content[0].text)


@pytest.mark.asyncio
async def test_not_connected_prompts_login() -> None:
    with patch("pretorin.client.config.Config") as mock_cls:
        cfg = mock_cls.return_value
        cfg.is_configured = False
        cfg.active_system_id = None
        cfg.active_system_name = None
        cfg.active_framework_id = None

        payload = _payload(await handle_check_context(None, {}))

    assert payload["connected"] is False
    assert payload["active_system"] is None
    assert payload["active_framework_id"] is None
    assert "pretorin login" in payload["suggested_next"]
    assert payload["pending_attention"] == {}


@pytest.mark.asyncio
async def test_connected_but_no_system_points_to_list_systems() -> None:
    with patch("pretorin.client.config.Config") as mock_cls:
        cfg = mock_cls.return_value
        cfg.is_configured = True
        cfg.active_system_id = None
        cfg.active_system_name = None
        cfg.active_framework_id = None

        payload = _payload(await handle_check_context(None, {}))

    assert payload["connected"] is True
    assert payload["active_system"] is None
    assert "list_systems" in payload["suggested_next"]
    assert "early-access" in payload["suggested_next"]


@pytest.mark.asyncio
async def test_system_without_framework_points_to_context_set() -> None:
    with patch("pretorin.client.config.Config") as mock_cls:
        cfg = mock_cls.return_value
        cfg.is_configured = True
        cfg.active_system_id = "sys-1"
        cfg.active_system_name = "Primary"
        cfg.active_framework_id = None

        payload = _payload(await handle_check_context(None, {}))

    assert payload["active_system"] == {"id": "sys-1", "name": "Primary"}
    assert payload["active_framework_id"] is None
    assert "framework" in payload["suggested_next"].lower()


@pytest.mark.asyncio
async def test_fully_grounded_points_to_start_task() -> None:
    with patch("pretorin.client.config.Config") as mock_cls:
        cfg = mock_cls.return_value
        cfg.is_configured = True
        cfg.active_system_id = "sys-1"
        cfg.active_system_name = "Primary"
        cfg.active_framework_id = "nist-800-53-r5"

        payload = _payload(await handle_check_context(None, {}))

    assert payload["connected"] is True
    assert payload["active_system"] == {"id": "sys-1", "name": "Primary"}
    assert payload["active_framework_id"] == "nist-800-53-r5"
    assert "start_task" in payload["suggested_next"]
    assert "intent_verb" in payload["suggested_next"]


@pytest.mark.asyncio
async def test_active_system_name_falls_back_to_id() -> None:
    with patch("pretorin.client.config.Config") as mock_cls:
        cfg = mock_cls.return_value
        cfg.is_configured = True
        cfg.active_system_id = "sys-1"
        cfg.active_system_name = None
        cfg.active_framework_id = "nist-800-53-r5"

        payload = _payload(await handle_check_context(None, {}))

    assert payload["active_system"] == {"id": "sys-1", "name": "sys-1"}


@pytest.mark.asyncio
async def test_handler_accepts_none_client() -> None:
    """check_context must work without an authenticated client."""
    with patch("pretorin.client.config.Config") as mock_cls:
        cfg = mock_cls.return_value
        cfg.is_configured = False
        cfg.active_system_id = None
        cfg.active_system_name = None
        cfg.active_framework_id = None

        response = await handle_check_context(None, {})

    assert response  # no exception means the public-tool path works
