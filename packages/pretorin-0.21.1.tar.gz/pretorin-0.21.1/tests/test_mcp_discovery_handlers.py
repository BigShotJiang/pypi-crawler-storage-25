"""Tests for the discovery-layer MCP handlers.

Covers list_tools and get_instructions — both
unauthenticated, both safe to call before any platform interaction. These
are the cross-harness discovery surface introduced in RFC #113.
"""

from __future__ import annotations

import json

import pytest

from pretorin.mcp.handlers.engagement import (
    _one_line_purpose,
    handle_get_instructions,
    handle_list_tools,
)


def _payload(response):
    if isinstance(response, list):
        return json.loads(response[0].text)
    return json.loads(response.content[0].text)


# =============================================================================
# _one_line_purpose helper
# =============================================================================


def test_one_line_purpose_extracts_first_sentence() -> None:
    desc = "Route a user prompt to the right workflow. Call this FIRST whenever..."
    assert _one_line_purpose(desc) == "Route a user prompt to the right workflow"


def test_one_line_purpose_collapses_whitespace() -> None:
    desc = "Cheap, unauthenticated  probe\n\nof session\tgrounding"
    assert _one_line_purpose(desc) == "Cheap, unauthenticated probe of session grounding"


def test_one_line_purpose_truncates_long_text() -> None:
    desc = "A" * 200
    result = _one_line_purpose(desc, max_chars=50)
    assert len(result) == 50
    assert result.endswith("…")


def test_one_line_purpose_handles_empty_string() -> None:
    assert _one_line_purpose("") == ""


# =============================================================================
# handle_list_tools
# =============================================================================


@pytest.mark.asyncio
async def test_list_tools_returns_compact_catalog() -> None:
    payload = _payload(await handle_list_tools(None, {}))

    assert payload["total"] > 0
    assert isinstance(payload["tools"], list)
    assert all({"name", "purpose", "tier", "requires_workflow"} <= e.keys() for e in payload["tools"])


@pytest.mark.asyncio
async def test_list_tools_classifies_default_tier() -> None:
    payload = _payload(await handle_list_tools(None, {}))
    by_name = {e["name"]: e for e in payload["tools"]}

    for name in (
        "check_context",
        "start_task",
        "list_tools",
        "get_instructions",
        "list_systems",
        "list_frameworks",
        "get_workflow",
    ):
        assert by_name[name]["tier"] == "default", f"{name} should be tier=default"
        assert by_name[name]["requires_workflow"] is False


@pytest.mark.asyncio
async def test_list_tools_classifies_workflow_tier() -> None:
    payload = _payload(await handle_list_tools(None, {}))
    by_name = {e["name"]: e for e in payload["tools"]}

    for name in (
        "create_evidence",
        "upload_evidence",
        "update_narrative",
        "update_control_status",
    ):
        assert by_name[name]["tier"] == "workflow", f"{name} should be tier=workflow"
        assert by_name[name]["requires_workflow"] is True


@pytest.mark.asyncio
async def test_list_tools_classifies_reference_tier() -> None:
    payload = _payload(await handle_list_tools(None, {}))
    by_name = {e["name"]: e for e in payload["tools"]}

    for name in (
        "get_control",
        "get_framework",
        "list_controls",
    ):
        assert by_name[name]["tier"] == "reference", f"{name} should be tier=reference"
        assert by_name[name]["requires_workflow"] is False


@pytest.mark.asyncio
async def test_list_tools_includes_tier_counts() -> None:
    payload = _payload(await handle_list_tools(None, {}))
    counts = payload["tier_counts"]
    assert counts["default"] >= 7
    assert counts["workflow"] >= 10
    assert counts["reference"] > 0
    assert sum(counts.values()) == payload["total"]


@pytest.mark.asyncio
async def test_list_tools_purposes_are_one_line() -> None:
    payload = _payload(await handle_list_tools(None, {}))
    for entry in payload["tools"]:
        assert "\n" not in entry["purpose"]
        assert len(entry["purpose"]) <= 100


# =============================================================================
# handle_get_instructions
# =============================================================================


@pytest.mark.asyncio
async def test_get_instructions_returns_server_block() -> None:
    payload = _payload(await handle_get_instructions(None, {}))

    assert "instructions" in payload
    assert payload["version"] == 1
    assert "FIRST CALL" in payload["instructions"]
    assert "check_context" in payload["instructions"]
    assert "start_task" in payload["instructions"]


@pytest.mark.asyncio
async def test_get_instructions_accepts_no_args() -> None:
    response = await handle_get_instructions(None, {})
    assert response  # no exception


# =============================================================================
# Intent-verb map stays in sync with WORKFLOW_TIER
# =============================================================================


def test_every_workflow_tier_tool_has_intent_verb_mapping() -> None:
    """Each tool in WORKFLOW_TIER must have a row in _TOOL_TO_INTENT_VERB so
    the structured WorkflowRoutingError payload always carries a
    suggested_intent_verb. If this breaks, either add an intent verb for
    the new tool or remove it from WORKFLOW_TIER."""
    from pretorin.mcp.server import _TOOL_TO_INTENT_VERB
    from pretorin.mcp.tool_metadata import WORKFLOW_TIER

    missing = WORKFLOW_TIER - _TOOL_TO_INTENT_VERB.keys()
    assert not missing, f"WORKFLOW_TIER tools missing intent_verb mapping: {sorted(missing)}"


def test_intent_verbs_use_valid_engagement_values() -> None:
    """Intent verbs map to EngagementEntities.intent_verb enum values."""
    from pretorin.mcp.server import _TOOL_TO_INTENT_VERB

    valid = {"work_on", "collect_evidence", "draft_narrative", "answer", "campaign", "inspect_status"}
    invalid = {(tool, verb) for tool, verb in _TOOL_TO_INTENT_VERB.items() if verb not in valid}
    assert not invalid, f"Tools mapped to invalid intent verbs: {sorted(invalid)}"
