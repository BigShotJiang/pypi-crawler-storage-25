"""Tests for evidence create markdown validation."""

from __future__ import annotations

from unittest.mock import patch

from typer.testing import CliRunner

from pretorin.cli.evidence import app

runner = CliRunner()


class TestEvidenceCreateValidation:
    def test_requires_artifact_content(self):
        """Evidence create requires a standalone Markdown artifact body."""
        result = runner.invoke(
            app,
            [
                "create",
                "ac-02",
                "fedramp-moderate",
                "-d",
                "plain text with no markdown",
                "-t",
                "policy_document",
            ],
        )
        assert result.exit_code != 0
        assert "artifact" in result.output.lower()

    def test_accepts_list_item(self, tmp_path):
        """Evidence create should accept description with a list item."""
        with patch("pretorin.evidence.writer.EvidenceWriter.write", return_value=tmp_path / "test.md"):
            result = runner.invoke(
                app,
                [
                    "create",
                    "ac-02",
                    "fedramp-moderate",
                    "-d",
                    "RBAC configuration verified",
                    "--artifact",
                    "- RBAC configuration verified",
                    "-t",
                    "configuration",
                ],
            )
            assert result.exit_code == 0

    def test_accepts_headings_in_artifact(self, tmp_path):
        """Evidence artifact bodies may use headings now; description is only the summary."""
        with patch("pretorin.evidence.writer.EvidenceWriter.write", return_value=tmp_path / "test.md"):
            result = runner.invoke(
                app,
                [
                    "create",
                    "ac-02",
                    "fedramp-moderate",
                    "-d",
                    "Policy evidence summary",
                    "--artifact",
                    "# Heading\n- list item",
                    "-t",
                    "policy_document",
                ],
            )
            assert result.exit_code == 0

    def test_accepts_code_block(self, tmp_path):
        """Evidence create should accept description with a code block."""
        with patch("pretorin.evidence.writer.EvidenceWriter.write", return_value=tmp_path / "test.md"):
            result = runner.invoke(
                app,
                [
                    "create",
                    "ac-02",
                    "fedramp-moderate",
                    "-d",
                    "YAML configuration summary",
                    "--artifact",
                    "```yaml\nkey: value\n```",
                    "-t",
                    "configuration",
                ],
            )
            assert result.exit_code == 0
