"""Tests for custom_to_unified converters.

Covers format detection and all 12 converters. Custom frameworks are a
flagship feature; every converter is exercised end-to-end and validated
against the unified JSON Schema.
"""

import pytest

from pretorin.frameworks import custom_to_unified
from pretorin.frameworks.validate import validate_unified


def test_detect_oscal_format_returns_none():
    oscal_like = {"uuid": "x", "groups": []}
    assert custom_to_unified.is_oscal_format(oscal_like) is True
    assert custom_to_unified.detect_custom_format(oscal_like) is None


def test_detect_control_families():
    data = {"control_families": [], "controls": []}
    assert custom_to_unified.detect_custom_format(data) == "control_families"


def test_detect_cis_safeguards():
    data = {"metadata": {}, "controls": [{"safeguards": []}]}
    assert custom_to_unified.detect_custom_format(data) == "cis_safeguards"


def test_detect_unknown_shape():
    assert custom_to_unified.detect_custom_format({"foo": "bar"}) is None


def test_convert_raises_on_oscal_input():
    with pytest.raises(custom_to_unified.UnknownCustomFormatError, match="OSCAL"):
        custom_to_unified.convert({"uuid": "x", "groups": []}, "x")


def test_convert_raises_on_unknown_shape():
    with pytest.raises(custom_to_unified.UnknownCustomFormatError, match="Unrecognized"):
        custom_to_unified.convert({"foo": "bar"}, "x")


def test_convert_control_families_shape():
    """GDPR/HIPAA/SOC2-style control_families + controls."""
    data = {
        "catalog_name": "Example Privacy Framework",
        "version": "1.0",
        "regulatory_authority": "Authority X",
        "description": "Privacy controls.",
        "control_families": [
            {
                "family_id": "DSP",
                "family_name": "Data Subject Protection",
                "description": "Rights and remedies.",
            }
        ],
        "controls": [
            {
                "control_id": "DSP-1",
                "control_name": "Right to Access",
                "family_id": "DSP",
                "control_intent": "Subjects can access their data.",
                "guidance": "Provide a request portal.",
                "citation": "Article 15",
                "obligation_type": "mandatory",
            }
        ],
    }

    unified = custom_to_unified.convert(data, "example-privacy")

    assert unified["framework_id"] == "example-privacy"
    assert unified["custom_format_type"] == "control_families"
    assert unified["metadata"]["title"] == "Example Privacy Framework"
    assert unified["metadata"]["publisher"] == "Authority X"

    family = unified["families"][0]
    assert family["id"] == "DSP"
    assert len(family["controls"]) == 1

    ctrl = family["controls"][0]
    assert ctrl["id"] == "DSP-1"
    assert ctrl["statement"] == "Subjects can access their data."
    assert ctrl["guidance"] == "Provide a request portal."
    assert ctrl["references"] == [{"title": "Article 15"}]
    assert ctrl["_custom"]["obligation_type"] == "mandatory"


def test_convert_control_families_passes_schema():
    data = {
        "control_families": [{"family_id": "ac", "family_name": "Access Control"}],
        "controls": [
            {
                "control_id": "ac-1",
                "control_name": "Policy",
                "family_id": "ac",
                "control_intent": "Develop policy.",
            }
        ],
    }
    unified = custom_to_unified.convert(data, "test")
    result = validate_unified(unified)
    assert result.valid, [str(e) for e in result.errors]


def test_convert_cis_safeguards_shape():
    """CIS pattern: each control becomes a family; nested safeguards become controls."""
    data = {
        "metadata": {"framework_name": "CIS Critical Security Controls", "version": "8.0"},
        "controls": [
            {
                "control_id": 1,
                "control_name": "Inventory of Enterprise Assets",
                "description": "Actively manage assets.",
                "safeguards": [
                    {
                        "safeguard_id": "1.1",
                        "safeguard_name": "Establish and Maintain Detailed Inventory",
                        "description": "Maintain accurate inventory.",
                        "implementation_groups": ["IG1", "IG2", "IG3"],
                        "asset_type": "Devices",
                    },
                    {
                        "safeguard_id": "1.2",
                        "safeguard_name": "Address Unauthorized Assets",
                        "description": "Quarantine unauthorized assets.",
                        "implementation_groups": ["IG2", "IG3"],
                    },
                ],
            }
        ],
    }

    unified = custom_to_unified.convert(data, "cis-v8")

    assert unified["custom_format_type"] == "cis_safeguards"
    assert unified["metadata"]["publisher"] == "Center for Internet Security"

    family = unified["families"][0]
    assert family["id"] == "control-1"
    assert family["title"] == "Inventory of Enterprise Assets"
    assert len(family["controls"]) == 2

    sg11 = family["controls"][0]
    assert sg11["id"] == "1.1"
    assert sg11["implementation_level"] == "system"
    assert sg11["_custom"]["implementation_groups"] == ["IG1", "IG2", "IG3"]


def test_convert_cis_safeguards_passes_schema():
    data = {
        "metadata": {"framework_name": "CIS"},
        "controls": [
            {
                "control_id": 1,
                "control_name": "Inventory",
                "safeguards": [
                    {"safeguard_id": "1.1", "safeguard_name": "Maintain inventory", "description": "Do it."}
                ],
            }
        ],
    }
    unified = custom_to_unified.convert(data, "cis")
    result = validate_unified(unified)
    assert result.valid, [str(e) for e in result.errors]


def test_safeguard_type_mapping():
    assert custom_to_unified.map_safeguard_type_to_impl_level(None) is None
    assert custom_to_unified.map_safeguard_type_to_impl_level("administrative") == "organization"
    assert custom_to_unified.map_safeguard_type_to_impl_level("Technical") == "system"
    assert custom_to_unified.map_safeguard_type_to_impl_level("physical") == "hybrid"
    assert custom_to_unified.map_safeguard_type_to_impl_level("unknown-type") is None


def test_is_oscal_format_wrapped_catalog():
    """OSCAL catalogs may be wrapped under a top-level `catalog` key."""
    assert custom_to_unified.is_oscal_format({"catalog": {"uuid": "x", "groups": []}}) is True
    assert custom_to_unified.is_oscal_format({"catalog": "not-a-dict"}) is False
    assert custom_to_unified.is_oscal_format({"catalog": {"groups": []}}) is False


def test_detect_all_format_shapes():
    """Every detector branch must be reachable from a representative payload."""
    assert custom_to_unified.detect_custom_format({"process_requirement_catalog": {}}) == "process_requirement"
    assert (
        custom_to_unified.detect_custom_format({"governance_requirement_catalog": {}}) == "governance_requirement"
    )
    assert custom_to_unified.detect_custom_format({"framework_catalog": {}}) == "framework_catalog"
    assert (
        custom_to_unified.detect_custom_format({"cryptographic_module_validation_catalog": {}}) == "crypto_validation"
    )
    assert custom_to_unified.detect_custom_format({"framework": {"metadata": {}}}) == "framework_wrapper"
    assert custom_to_unified.detect_custom_format({"catalog_metadata": {}, "domains": []}) == "domains"
    assert custom_to_unified.detect_custom_format({"standards": []}) == "standards_specs"
    assert (
        custom_to_unified.detect_custom_format({"metadata": {}, "controls": [{"description": "x"}]})
        == "metadata_controls"
    )
    assert (
        custom_to_unified.detect_custom_format({"control_themes": [], "controls": []}) == "control_themes"
    )
    assert (
        custom_to_unified.detect_custom_format({"control_objectives": [], "requirements": []}) == "pci_dss"
    )


def test_convert_control_families_unknown_family_id_is_synthesized():
    """A control referencing a missing family_id gets a synthesized family entry."""
    data = {
        "control_families": [],
        "controls": [{"control_id": "x-1", "control_name": "Orphan", "family_id": "missing"}],
    }
    unified = custom_to_unified.convert(data, "x")
    assert unified["families"][0]["id"] == "missing"
    assert unified["families"][0]["title"] == "missing"


def test_convert_control_families_article_reference_fallback():
    """`article_reference` is used when `citation` is absent."""
    data = {
        "control_families": [{"family_id": "F", "family_name": "F"}],
        "controls": [
            {
                "control_id": "F-1",
                "control_name": "A",
                "family_id": "F",
                "article_reference": "Art. 5",
            }
        ],
    }
    unified = custom_to_unified.convert(data, "x")
    assert unified["families"][0]["controls"][0]["references"] == [{"title": "Art. 5"}]


def test_convert_domains_shape():
    """CSA-CCM domain catalog."""
    data = {
        "catalog_metadata": {"framework_name": "CCM v4", "version": "4.0"},
        "domains": [
            {"domain_id": "AIS", "domain_name": "Application & Interface Security"},
        ],
        "controls": [
            {
                "control_id": "AIS-01",
                "control_name": "Application Security",
                "domain": "AIS",
                "description": "Secure the app.",
                "cloud_applicability": ["IaaS", "PaaS"],
                "shared_responsibility": "provider",
            },
            {
                "control_id": "ORPH-01",
                "control_name": "Orphan",
                "domain": "ORPH",
                "description": "No matching domain.",
            },
        ],
    }
    unified = custom_to_unified.convert(data, "ccm")
    assert unified["custom_format_type"] == "domains"
    assert unified["metadata"]["publisher"] == "Cloud Security Alliance"

    families_by_id = {f["id"]: f for f in unified["families"]}
    ais = families_by_id["AIS"]
    assert ais["title"] == "Application & Interface Security"
    assert ais["controls"][0]["_custom"]["cloud_applicability"] == ["IaaS", "PaaS"]
    assert ais["controls"][0]["_custom"]["shared_responsibility"] == "provider"

    orph = families_by_id["ORPH"]
    assert orph["title"] == "ORPH"
    assert orph["controls"][0]["id"] == "ORPH-01"

    assert validate_unified(unified).valid


def test_convert_control_themes_shape():
    """ISO-27001 control_themes."""
    data = {
        "catalog_name": "ISO 27001:2022",
        "version": "2022",
        "control_themes": [
            {"theme_id": "people", "theme_name": "People", "identifier_prefix": "6"},
        ],
        "controls": [
            {
                "control_id": "6.1",
                "control_name": "Screening",
                "control_theme": "People",
                "control_intent": "Verify personnel.",
                "applicability_guidance": "Apply at hiring.",
                "is_new_2022": True,
            },
            {
                "control_id": "9.1",
                "control_name": "Unmapped",
                "control_theme": "Technological",
                "control_intent": "x",
            },
        ],
    }
    unified = custom_to_unified.convert(data, "iso-27001")
    assert unified["custom_format_type"] == "control_themes"
    assert unified["metadata"]["publisher"] == "ISO/IEC"

    families_by_id = {f["id"]: f for f in unified["families"]}
    people = families_by_id["people"]
    assert people["controls"][0]["id"] == "6.1"
    assert people["controls"][0]["_custom"]["applicability_guidance"] == "Apply at hiring."
    assert people["controls"][0]["_custom"]["is_new_2022"] is True

    # Unmapped theme is synthesized (theme_name lowercased)
    tech = families_by_id["technological"]
    assert tech["title"] == "Technological"
    assert tech["controls"][0]["id"] == "9.1"

    assert validate_unified(unified).valid


def test_convert_pci_dss_shape():
    """PCI-DSS control_objectives + requirements + controls."""
    data = {
        "catalog_name": "PCI DSS v4",
        "version": "4.0",
        "description": "Payment card security.",
        "control_objectives": [{"id": "obj-1"}],
        "requirements": [
            {"requirement_number": 1, "requirement_title": "Install and Maintain Network Controls"},
        ],
        "controls": [
            {
                "control_id": "1.1.1",
                "control_name": "Network security policy",
                "control_intent": "Define network policy.",
                "testing_guidance": "Review docs.",
                "applicability": "all merchants",
                "defined_approach_requirements": "explicit",
                "customized_approach_objective": "outcome",
            },
            {
                "control_id": "99.1",
                "control_name": "Orphan",
                "testing_requirement": "Test the orphan.",
            },
        ],
    }
    unified = custom_to_unified.convert(data, "pci-dss")
    assert unified["custom_format_type"] == "pci_dss"
    assert unified["metadata"]["publisher"] == "PCI Security Standards Council"

    families_by_id = {f["id"]: f for f in unified["families"]}
    req1 = families_by_id["req-1"]
    assert req1["title"] == "Install and Maintain Network Controls"
    ctrl = req1["controls"][0]
    assert ctrl["id"] == "1.1.1"
    assert ctrl["statement"] == "Define network policy."
    assert ctrl["_custom"]["applicability"] == "all merchants"

    req99 = families_by_id["req-99"]
    assert req99["title"] == "Requirement 99"
    # testing_requirement fallback used when control_intent is missing
    assert req99["controls"][0]["statement"] == "Test the orphan."

    assert validate_unified(unified).valid


def test_convert_process_requirement_shape():
    """DoDI/FISMA-style process_requirement_catalog."""
    data = {
        "process_requirement_catalog": {
            "metadata": {
                "title": "FISMA + RMF",
                "description": "Federal risk management.",
                "governs_control_catalog": "NIST",
                "version": "Rev 5",
            },
            "requirements": [
                {
                    "requirement_id": "RMF-PREP-1",
                    "title": "Identify Roles",
                    "requirement_text": "Identify key roles.",
                    "rmf_step": "Prepare",
                    "requirement_type": "process",
                    "normative_keyword": "shall",
                    "dod_specific": True,
                    "source_reference": "OMB A-130",
                    "related_roles": ["AO", "ISSO"],
                },
                {
                    "requirement_id": "RMF-GEN-1",
                    "title": "Generic",
                    "requirement_text": "Default step.",
                    # rmf_step omitted → falls back to "General"
                },
            ],
        }
    }
    unified = custom_to_unified.convert(data, "fisma-rmf")
    assert unified["custom_format_type"] == "process_requirement"
    assert unified["metadata"]["publisher"] == "NIST"

    families_by_id = {f["id"]: f for f in unified["families"]}
    prepare = families_by_id["prepare"]
    assert prepare["title"] == "Prepare"
    ctrl = prepare["controls"][0]
    assert ctrl["implementation_level"] == "organization"
    assert ctrl["_custom"]["dod_specific"] is True
    assert ctrl["_custom"]["source_reference"] == "OMB A-130"
    assert ctrl["_custom"]["related_roles"] == ["AO", "ISSO"]

    assert families_by_id["general"]["title"] == "General"
    assert validate_unified(unified).valid


def test_convert_governance_requirement_shape():
    """NIST AI RMF governance_requirement_catalog with subcategories."""
    data = {
        "governance_requirement_catalog": {
            "metadata": {"title": "AI RMF", "description": "AI risk.", "version": "1.0"},
            "ai_rmf_functions": [
                {"function_id": "GOVERN", "function_name": "Govern", "function_description": "Governance."},
            ],
            "subcategories": [
                {
                    "subcategory_id": "GV-1.1",
                    "subcategory_name": "Policies",
                    "description": "Establish policies.",
                    "trustworthiness_characteristics": ["Accountable"],
                    "gai_actions": ["Document"],
                    "suggested_actions": ["Adopt charter"],
                },
                {
                    "subcategory_id": "MP-2.1",
                    "subcategory_name": "Mapping",
                    "description": "Map context.",
                },
            ],
        }
    }
    unified = custom_to_unified.convert(data, "ai-rmf")
    assert unified["custom_format_type"] == "governance_requirement"
    assert unified["metadata"]["publisher"] == "NIST"

    families_by_id = {f["id"]: f for f in unified["families"]}
    govern = families_by_id["govern"]
    assert govern["title"] == "Govern"
    ctrl = govern["controls"][0]
    assert ctrl["id"] == "GV-1.1"
    assert ctrl["_custom"]["trustworthiness_characteristics"] == ["Accountable"]

    # MP- prefix maps to MAP function (synthesized — not in ai_rmf_functions)
    mp = families_by_id["map"]
    assert mp["title"] == "MAP"
    assert mp["controls"][0]["id"] == "MP-2.1"

    assert validate_unified(unified).valid


def test_convert_framework_catalog_shape():
    """MITRE ATLAS threat catalog with separate file refs."""
    data = {
        "framework_catalog": {
            "metadata": {"title": "MITRE ATLAS", "version": "v1"},
            "catalog_type_justification": {"statement": "Adversarial ML threat catalog."},
            "normalized_files": {"files": ["tactics.json", "techniques.json"]},
        }
    }
    unified = custom_to_unified.convert(data, "atlas")
    assert unified["custom_format_type"] == "framework_catalog"
    assert unified["metadata"]["publisher"] == "MITRE"
    assert unified["metadata"]["description"] == "Adversarial ML threat catalog."
    assert unified["families"] == []
    assert unified["_normalized_files"] == ["tactics.json", "techniques.json"]
    assert validate_unified(unified).valid


def test_convert_framework_catalog_without_normalized_files():
    data = {"framework_catalog": {"metadata": {"title": "X", "version": "1"}}}
    unified = custom_to_unified.convert(data, "x")
    assert "_normalized_files" not in unified


def test_convert_crypto_validation_shape():
    """FIPS 140-3 cryptographic module validation catalog."""
    data = {
        "cryptographic_module_validation_catalog": {
            "metadata": {
                "framework_name": "FIPS 140-3",
                "fips_publication": "140-3",
                "scope": {"description": "Cryptographic module security."},
            },
            "security_areas": [
                {
                    "area_id": "AREA1",
                    "area_name": "Cryptographic Module Specification",
                    "description": "Module spec requirements.",
                    "requirements": [
                        {
                            "requirement_id": "REQ-1.1",
                            "title": "Module boundaries",
                            "description": "Define boundaries.",
                        }
                    ],
                }
            ],
        }
    }
    unified = custom_to_unified.convert(data, "fips-140-3")
    assert unified["custom_format_type"] == "crypto_validation"
    assert unified["metadata"]["publisher"] == "NIST"
    assert unified["metadata"]["version"] == "140-3"

    family = unified["families"][0]
    assert family["id"] == "area1"
    assert family["title"] == "Cryptographic Module Specification"
    assert family["controls"][0]["id"] == "REQ-1.1"
    assert family["controls"][0]["implementation_level"] == "system"

    assert validate_unified(unified).valid


def test_convert_framework_wrapper_shape():
    """DISA STIG framework wrapper."""
    data = {
        "framework": {
            "metadata": {
                "framework_name": "DISA STIG Catalog",
                "version": "2024",
                "scope": {"description": "Technical hardening guides."},
                "authority": {"name": "DISA"},
            }
        },
        "checklist_concepts": {"severity_levels": ["CAT I", "CAT II", "CAT III"]},
    }
    unified = custom_to_unified.convert(data, "disa-stigs")
    assert unified["custom_format_type"] == "framework_wrapper"
    assert unified["metadata"]["publisher"] == "DISA"
    assert unified["metadata"]["description"] == "Technical hardening guides."
    assert unified["families"] == []
    assert unified["_checklist_concepts"]["severity_levels"] == ["CAT I", "CAT II", "CAT III"]
    assert validate_unified(unified).valid


def test_convert_framework_wrapper_without_checklist_concepts():
    data = {"framework": {"metadata": {"framework_name": "X", "version": "1"}}}
    unified = custom_to_unified.convert(data, "x")
    assert "_checklist_concepts" not in unified


def test_convert_standards_specs_shape():
    """HIPAA-NIST-800-66 standards + implementation_specifications."""
    data = {
        "catalog_name": "HIPAA Security Rule Implementation",
        "description": "HHS HIPAA guidance.",
        "regulatory_authority": "HHS",
        "version": "Rev 2",
        "standards": [
            {
                "standard_id": "164.308(a)(1)",
                "standard_name": "Security Management Process",
                "safeguard_category": "Administrative",
                "description": "Establish security management.",
                "implementation_specifications": [
                    {
                        "spec_id": "164.308(a)(1)(ii)(A)",
                        "name": "Risk Analysis",
                        "description": "Conduct an accurate analysis.",
                        "cfr_reference": "45 CFR 164.308",
                        "requirement_type": "Required",
                        "nist_800_53_refs": ["RA-3"],
                        "nist_csf_refs": ["ID.RA-1"],
                    }
                ],
            },
            {
                "standard_id": "164.310(a)(1)",
                "standard_name": "Facility Access Controls",
                "safeguard_category": "Physical",
                "description": "Limit physical access.",
                "cfr_reference": "45 CFR 164.310",
                "requirement_type": "Standard",
                "nist_800_53_refs": ["PE-2"],
            },
        ],
    }
    unified = custom_to_unified.convert(data, "hipaa-800-66")
    assert unified["custom_format_type"] == "standards_specs"
    assert unified["metadata"]["publisher"] == "HHS"

    families_by_id = {f["id"]: f for f in unified["families"]}
    admin = families_by_id["administrative"]
    assert admin["title"] == "Administrative Safeguards"
    spec_ctrl = admin["controls"][0]
    assert spec_ctrl["id"] == "164.308(a)(1)(ii)(A)"
    assert spec_ctrl["implementation_level"] == "organization"
    assert spec_ctrl["related_controls"] == [{"id": "RA-3", "framework": "nist-800-53"}]
    assert spec_ctrl["_custom"]["nist_csf_refs"] == ["ID.RA-1"]
    assert spec_ctrl["_custom"]["parent_standard"] == "164.308(a)(1)"

    physical = families_by_id["physical"]
    assert physical["title"] == "Physical Safeguards"
    std_ctrl = physical["controls"][0]
    # Standard-level fallback when implementation_specifications is empty
    assert std_ctrl["id"] == "164.310(a)(1)"
    assert std_ctrl["implementation_level"] == "hybrid"
    assert std_ctrl["related_controls"] == [{"id": "PE-2", "framework": "nist-800-53"}]

    assert validate_unified(unified).valid


def test_convert_metadata_controls_shape():
    """Generic metadata_controls (no nested safeguards)."""
    data = {
        "metadata": {"framework_name": "Generic Framework", "version": "0.1"},
        "control_families": [
            {"id": "ops", "name": "Operations", "description": "Ops controls."},
        ],
        "controls": [
            {
                "control_id": "ops-1",
                "control_name": "Change Management",
                "family_id": "ops",
                "description": "Manage changes.",
            },
            {
                "control_id": "misc-1",
                "control_name": "Catch-all",
                "control_intent": "Default family.",
                # family_id and control_family both omitted → goes to "general"
            },
            {
                "control_id": "new-1",
                "control_name": "New Family",
                "control_family": "synthetic",
                "description": "Family invented from control_family.",
            },
        ],
    }
    unified = custom_to_unified.convert(data, "generic")
    assert unified["custom_format_type"] == "metadata_controls"
    assert unified["metadata"]["title"] == "Generic Framework"

    families_by_id = {f["id"]: f for f in unified["families"]}
    assert families_by_id["ops"]["controls"][0]["id"] == "ops-1"
    assert families_by_id["general"]["controls"][0]["id"] == "misc-1"
    # control_intent fallback when description is missing
    assert families_by_id["general"]["controls"][0]["statement"] == "Default family."
    assert families_by_id["synthetic"]["controls"][0]["id"] == "new-1"

    assert validate_unified(unified).valid


def test_convert_metadata_controls_synthesizes_general_family():
    """When there are no families and no controls reference a family, a 'general' family is created."""
    data = {
        "metadata": {"framework_name": "X"},
        "controls": [{"control_id": "x-1", "control_name": "X", "description": "X."}],
    }
    unified = custom_to_unified.convert(data, "x")
    families_by_id = {f["id"]: f for f in unified["families"]}
    assert "general" in families_by_id
    assert families_by_id["general"]["controls"][0]["id"] == "x-1"


def test_convert_dispatch_table_covers_every_detected_format():
    """Every key returned by detect_custom_format must have a converter."""
    detected_keys = {
        "process_requirement",
        "governance_requirement",
        "framework_catalog",
        "crypto_validation",
        "framework_wrapper",
        "domains",
        "standards_specs",
        "cis_safeguards",
        "metadata_controls",
        "control_themes",
        "pci_dss",
        "control_families",
    }
    assert detected_keys == set(custom_to_unified.CONVERTERS.keys())
