"""Tests for MCP recipe-lifecycle handlers + write-tool stamping integration.

Covers WS2 Phase B's MCP surface:

- ``start_recipe`` happy path: validates inputs, opens a context,
  returns context_id + body.
- Error cases: missing fields, unknown recipe id, version mismatch, nesting.
- ``end_recipe`` happy path returns the RecipeResult; status
  validation; expired-context error.
- Write-tool stamping integration: ``handle_create_evidence`` /
  ``handle_create_evidence_batch`` accept ``recipe_context_id`` and stamp
  ``producer_kind="recipe"`` automatically.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from pretorin.client.api import NotFoundError
from pretorin.client.models import ConnectedSource, ControlContext
from pretorin.mcp.handlers.compliance import handle_update_narrative
from pretorin.mcp.handlers.evidence import (
    handle_create_evidence,
    handle_create_evidence_batch,
)
from pretorin.mcp.handlers.recipe import (
    handle_check_sources,
    handle_end_recipe,
    handle_get_recipe,
    handle_list_recipes,
    handle_run_recipe_script,
    handle_start_recipe,
)
from pretorin.recipes import loader as loader_module
from pretorin.recipes.context import get_default_store, reset_default_store
from pretorin.recipes.loader import clear_cache
from pretorin.recipes.registry import script_tool_name

_FIXTURES = Path(__file__).parent / "recipes" / "fixtures" / "valid"


@pytest.fixture(autouse=True)
def _isolate_state() -> None:
    clear_cache()
    reset_default_store()
    yield
    clear_cache()
    reset_default_store()


@pytest.fixture
def fake_dirs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> dict[str, Path]:
    builtin = tmp_path / "builtin"
    builtin.mkdir()
    monkeypatch.setattr(loader_module, "_builtin_recipes_root", lambda: builtin)
    monkeypatch.setattr(loader_module, "_user_recipes_root", lambda: tmp_path / "no-user-dir")
    return {"builtin": builtin}


def _drop(source_dir: Path, fixture_name: str) -> None:
    shutil.copytree(_FIXTURES / fixture_name, source_dir / fixture_name)


def _write_recipe(source_dir: Path, recipe_id: str, *, requires_source: str | None = None) -> None:
    recipe_dir = source_dir / recipe_id
    recipe_dir.mkdir()
    requires = (
        f"""
requires:
  sources:
    - kind: {requires_source}
      binding_role: primary
      probe: "test probe"
      source_version_kind: test_anchor
"""
        if requires_source
        else ""
    )
    recipe_dir.joinpath("recipe.md").write_text(
        f"""---
id: {recipe_id}
version: 0.1.0
name: "{recipe_id}"
description: "A valid recipe fixture with enough descriptive text for source filtering tests."
use_when: "When a test needs a recipe with or without connected source requirements."
produces: evidence
author: "Pretorin Test Fixtures"
{requires}---

# {recipe_id}
"""
    )


def _extract_payload(response: Any) -> dict[str, Any]:
    """Pull the JSON dict from an MCP handler response.

    Successful handlers return ``list[TextContent]``; error handlers
    (``format_error``) return ``CallToolResult(content=[TextContent], isError=True)``
    per MCP convention. Handle both shapes so test assertions can be uniform.
    """
    if isinstance(response, list):
        text = response[0].text
    else:
        # CallToolResult — content is a list of TextContent.
        text = response.content[0].text
    # Errors come back as plain "Error: ..." strings; wrap them in a dict so
    # the rest of the test code can introspect uniformly.
    if not text.strip().startswith("{") and not text.strip().startswith("["):
        return {"error": text}
    return json.loads(text)


# =============================================================================
# start_recipe — happy path
# =============================================================================


@pytest.mark.asyncio
async def test_start_recipe_happy_path(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    payload = _extract_payload(response)
    assert "context_id" in payload
    assert payload["recipe_id"] == "example-recipe"
    assert payload["recipe_version"] == "0.1.0"
    assert payload["tier"] == "official"
    # Body is the recipe.md body the calling agent reads.
    assert "Example Recipe Body" in payload["body"]


@pytest.mark.asyncio
async def test_start_recipe_stores_params_and_selection(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={
            "recipe_id": "example-recipe",
            "recipe_version": "0.1.0",
            "params": {"target": "rhel-9"},
            "selection": {"selected_recipe": "example-recipe", "confidence": "high"},
        },
    )
    payload = _extract_payload(response)
    ctx = get_default_store().get(payload["context_id"])
    assert ctx.params == {"target": "rhel-9"}
    assert ctx.selection == {"selected_recipe": "example-recipe", "confidence": "high"}


@pytest.mark.asyncio
async def test_start_recipe_stores_evidence_ids(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "another-recipe")
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={
            "recipe_id": "another-recipe",
            "recipe_version": "1.2.3",
            "evidence_ids": ["ev-1", "ev-2"],
        },
    )
    payload = _extract_payload(response)
    ctx = get_default_store().get(payload["context_id"])
    assert ctx.evidence_ids == ["ev-1", "ev-2"]
    assert payload["evidence_ids"] == ["ev-1", "ev-2"]


# =============================================================================
# start_recipe — error cases
# =============================================================================


@pytest.mark.asyncio
async def test_start_recipe_missing_fields() -> None:
    response = await handle_start_recipe(client=MagicMock(), arguments={"recipe_id": "x"})
    payload = _extract_payload(response)
    assert "error" in payload or "Missing" in str(payload)


@pytest.mark.asyncio
async def test_start_recipe_unknown_id(fake_dirs: dict[str, Path]) -> None:
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "no-such-recipe", "recipe_version": "0.1.0"},
    )
    payload = _extract_payload(response)
    assert "no-such-recipe" in str(payload).lower() or "no recipe found" in str(payload).lower()


@pytest.mark.asyncio
async def test_start_recipe_version_mismatch(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "9.9.9"},
    )
    payload = _extract_payload(response)
    assert "version" in str(payload).lower()


@pytest.mark.asyncio
async def test_start_recipe_nesting_forbidden(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    _drop(fake_dirs["builtin"], "another-recipe")

    await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    # Second start without ending the first → error.
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "another-recipe", "recipe_version": "1.2.3"},
    )
    payload = _extract_payload(response)
    assert "still active" in str(payload).lower() or "already" in str(payload).lower()


@pytest.mark.asyncio
async def test_start_recipe_invalid_params_type(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    response = await handle_start_recipe(
        client=MagicMock(),
        arguments={
            "recipe_id": "example-recipe",
            "recipe_version": "0.1.0",
            "params": "not-a-dict",
        },
    )
    payload = _extract_payload(response)
    assert "params" in str(payload).lower()


# =============================================================================
# end_recipe
# =============================================================================


@pytest.mark.asyncio
async def test_end_recipe_happy_path(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    context_id = _extract_payload(start)["context_id"]
    end = await handle_end_recipe(client=MagicMock(), arguments={"context_id": context_id})
    payload = _extract_payload(end)
    assert payload["status"] == "pass"
    assert payload["recipe_id"] == "example-recipe"
    assert payload["evidence_count"] == 0
    assert payload["narrative_count"] == 0
    assert payload["errors"] == []


@pytest.mark.asyncio
async def test_end_recipe_with_status(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    context_id = _extract_payload(start)["context_id"]
    end = await handle_end_recipe(
        client=MagicMock(),
        arguments={"context_id": context_id, "status": "fail"},
    )
    assert _extract_payload(end)["status"] == "fail"


@pytest.mark.asyncio
async def test_end_recipe_invalid_status() -> None:
    response = await handle_end_recipe(
        client=MagicMock(),
        arguments={"context_id": "x", "status": "bogus"},
    )
    payload = _extract_payload(response)
    assert "status" in str(payload).lower()


@pytest.mark.asyncio
async def test_end_recipe_unknown_context_id() -> None:
    response = await handle_end_recipe(
        client=MagicMock(),
        arguments={"context_id": "not-a-real-id"},
    )
    payload = _extract_payload(response)
    assert "expired" in str(payload).lower() or "unknown" in str(payload).lower()


# =============================================================================
# Write-tool stamping integration
# =============================================================================


@pytest.fixture
def mock_client() -> AsyncMock:
    """A mock PretorianClient that returns reasonable defaults for write paths."""
    client = AsyncMock()
    client.list_evidence = AsyncMock(return_value=[])
    client.create_evidence = AsyncMock(return_value={"id": "ev-123"})
    client.create_evidence_batch = AsyncMock(
        return_value=MagicMock(model_dump=lambda: {"results": [{"index": 0, "status": "ok"}]})
    )
    client.link_evidence_to_control = AsyncMock(return_value={"linked": True})
    client.get_control = AsyncMock(return_value=MagicMock())
    return client


@pytest.fixture
def mock_resolve_scope(monkeypatch: pytest.MonkeyPatch) -> None:
    """Bypass the real scope resolver in MCP write handlers."""

    async def _fake_scope(
        client: Any, arguments: Any, *, control_required: bool = False, enforce_active_context: bool = False
    ) -> tuple[str, str, str | None]:
        return ("system-1", "framework-1", "AC-2")

    monkeypatch.setattr("pretorin.mcp.handlers.evidence.resolve_execution_scope", _fake_scope)


@pytest.mark.asyncio
async def test_create_evidence_with_recipe_context_stamps_recipe(
    fake_dirs: dict[str, Path], mock_client: AsyncMock, mock_resolve_scope: None
) -> None:
    """Active recipe context → producer_kind='recipe' on the EvidenceCreate payload."""
    _drop(fake_dirs["builtin"], "example-recipe")
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    context_id = _extract_payload(start)["context_id"]

    await handle_create_evidence(
        client=mock_client,
        arguments={
            "name": "test ev",
            "description": "This is a test evidence record.",
            "artifact_content": "This is a test evidence record.\n\n- Item one\n- Item two\n",
            "evidence_type": "code_snippet",
            "recipe_context_id": context_id,
        },
    )

    # Inspect the payload that was passed to the kernel via upsert_evidence.
    # The mock client's create_evidence was called with (system_id, EvidenceCreate(...)).
    # upsert_evidence calls client.create_evidence after constructing the payload.
    assert mock_client.create_evidence.await_count == 1
    _system_id, payload = mock_client.create_evidence.await_args.args
    assert payload.audit_metadata is not None
    assert payload.audit_metadata.producer_kind == "recipe"
    assert payload.audit_metadata.producer_id == "example-recipe"
    assert payload.audit_metadata.producer_version == "0.1.0"


@pytest.mark.asyncio
async def test_create_evidence_without_context_requires_recipe(
    fake_dirs: dict[str, Path], mock_client: AsyncMock, mock_resolve_scope: None
) -> None:
    """No recipe_context_id → structured recipe_required error."""
    response = await handle_create_evidence(
        client=mock_client,
        arguments={
            "name": "test ev",
            "description": "This is a test evidence record.",
            "artifact_content": "This is a test evidence record.\n\n- Item one\n- Item two\n",
            "evidence_type": "code_snippet",
        },
    )
    payload = _extract_payload(response)
    assert payload["error"] == "recipe_required"
    assert payload["recipe_gap"]["tool"] == "create_evidence"
    assert mock_client.create_evidence.await_count == 0


@pytest.mark.asyncio
async def test_create_evidence_invalid_recipe_context_returns_error(
    mock_client: AsyncMock, mock_resolve_scope: None
) -> None:
    """A bogus recipe_context_id surfaces a clear error rather than silently freelancing."""
    response = await handle_create_evidence(
        client=mock_client,
        arguments={
            "name": "test ev",
            "description": "This is a test evidence record.",
            "artifact_content": "This is a test evidence record.\n\n- Item one\n- Item two\n",
            "evidence_type": "code_snippet",
            "recipe_context_id": "not-a-real-id",
        },
    )
    payload = _extract_payload(response)
    assert "expired" in str(payload).lower() or "unknown" in str(payload).lower()
    # And the write was NOT attempted.
    assert mock_client.create_evidence.await_count == 0


@pytest.mark.asyncio
async def test_create_evidence_with_context_bumps_evidence_count(
    fake_dirs: dict[str, Path], mock_client: AsyncMock, mock_resolve_scope: None
) -> None:
    """The context tally updates so end_recipe reports it correctly."""
    _drop(fake_dirs["builtin"], "example-recipe")
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    context_id = _extract_payload(start)["context_id"]

    for _ in range(3):
        await handle_create_evidence(
            client=mock_client,
            arguments={
                "name": "test ev",
                "description": "x",
                "artifact_content": "x",
                "evidence_type": "code_snippet",
                "recipe_context_id": context_id,
            },
        )

    end = await handle_end_recipe(client=MagicMock(), arguments={"context_id": context_id})
    payload = _extract_payload(end)
    assert payload["evidence_count"] == 3


@pytest.mark.asyncio
async def test_create_evidence_batch_with_recipe_context(
    fake_dirs: dict[str, Path], mock_client: AsyncMock, mock_resolve_scope: None
) -> None:
    """Each batch item inherits the recipe context's stamping."""
    _drop(fake_dirs["builtin"], "example-recipe")
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    context_id = _extract_payload(start)["context_id"]

    await handle_create_evidence_batch(
        client=mock_client,
        arguments={
            "items": [
                {
                    "name": "a",
                    "description": "Batch item A.",
                    "artifact_content": "Batch item A.\n\n- one\n- two",
                    "control_id": "AC-2",
                    "evidence_type": "code_snippet",
                },
                {
                    "name": "b",
                    "description": "Batch item B.",
                    "artifact_content": "Batch item B.\n\n- one\n- two",
                    "control_id": "AC-2",
                    "evidence_type": "code_snippet",
                },
            ],
            "recipe_context_id": context_id,
        },
    )

    assert mock_client.create_evidence_batch.await_count == 1
    _system_id, _framework_id, items = mock_client.create_evidence_batch.await_args.args
    for item in items:
        assert item.audit_metadata is not None
        assert item.audit_metadata.producer_kind == "recipe"
        assert item.audit_metadata.producer_id == "example-recipe"


@pytest.mark.asyncio
async def test_create_evidence_batch_without_context_requires_recipe(
    mock_client: AsyncMock, mock_resolve_scope: None
) -> None:
    response = await handle_create_evidence_batch(
        client=mock_client,
        arguments={
            "items": [
                {
                    "name": "a",
                    "description": "Batch item A.",
                    "artifact_content": "Batch item A.\n\n- one\n- two",
                    "control_id": "AC-2",
                    "evidence_type": "code_snippet",
                }
            ],
        },
    )
    payload = _extract_payload(response)
    assert payload["error"] == "recipe_required"
    assert mock_client.create_evidence_batch.await_count == 0


@pytest.mark.asyncio
async def test_update_narrative_requires_recipe_context(mock_client: AsyncMock) -> None:
    response = await handle_update_narrative(
        client=mock_client,
        arguments={"control_id": "AC-2", "narrative": "Updated narrative"},
    )
    payload = _extract_payload(response)
    assert payload["error"] == "recipe_required"


@pytest.mark.asyncio
async def test_update_narrative_with_narrative_recipe_context(
    fake_dirs: dict[str, Path], mock_client: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    _drop(fake_dirs["builtin"], "another-recipe")
    mock_client.update_narrative = AsyncMock(return_value={"ok": True})

    async def _fake_scope(*args: Any, **kwargs: Any) -> tuple[str, str, str | None]:
        return ("sys-1", "fw-1", "ac-2")

    monkeypatch.setattr("pretorin.mcp.handlers.compliance.resolve_execution_scope", _fake_scope)
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={
            "recipe_id": "another-recipe",
            "recipe_version": "1.2.3",
            "evidence_ids": ["ev-1"],
        },
    )
    context_id = _extract_payload(start)["context_id"]
    response = await handle_update_narrative(
        client=mock_client,
        arguments={
            "control_id": "AC-2",
            "narrative": "Access reviews are performed (evidence: ev-1).",
            "recipe_context_id": context_id,
        },
    )
    payload = _extract_payload(response)
    assert payload["ok"] is True
    call_kwargs = mock_client.update_narrative.await_args.kwargs
    assert call_kwargs["recipe_context_id"] == context_id
    assert call_kwargs["evidence_ids"] == ["ev-1"]


# =============================================================================
# Phase C: list_recipes / get_recipe
# =============================================================================


@pytest.mark.asyncio
async def test_list_recipes_empty(fake_dirs: dict[str, Path]) -> None:
    response = await handle_list_recipes(client=MagicMock(), arguments={})
    payload = _extract_payload(response)
    assert payload["total"] == 0
    assert payload["recipes"] == []


@pytest.mark.asyncio
async def test_list_recipes_returns_summary(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    _drop(fake_dirs["builtin"], "another-recipe")
    response = await handle_list_recipes(client=MagicMock(), arguments={})
    payload = _extract_payload(response)
    assert payload["total"] == 2
    ids = {r["id"] for r in payload["recipes"]}
    assert ids == {"example-recipe", "another-recipe"}
    # Body intentionally NOT included in list — that's get_recipe's job.
    for recipe in payload["recipes"]:
        assert "body" not in recipe
        # Summary fields are present.
        for field_name in ["id", "name", "tier", "description", "use_when", "produces"]:
            assert field_name in recipe


@pytest.mark.asyncio
async def test_list_recipes_filter_by_tier(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")  # → official
    response = await handle_list_recipes(
        client=MagicMock(),
        arguments={"tier": "community"},
    )
    payload = _extract_payload(response)
    assert payload["total"] == 0  # builtin → official, filtered out


@pytest.mark.asyncio
async def test_list_recipes_filter_by_produces(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")  # produces evidence
    _drop(fake_dirs["builtin"], "another-recipe")  # produces narrative
    response = await handle_list_recipes(
        client=MagicMock(),
        arguments={"produces": "narrative"},
    )
    payload = _extract_payload(response)
    assert payload["total"] == 1
    assert payload["recipes"][0]["id"] == "another-recipe"


@pytest.mark.asyncio
async def test_list_recipes_filters_missing_connected_sources(fake_dirs: dict[str, Path]) -> None:
    _write_recipe(fake_dirs["builtin"], "source-free")
    _write_recipe(fake_dirs["builtin"], "github-capture", requires_source="github_org")
    client = AsyncMock()
    client.list_connected_sources = AsyncMock(return_value=[ConnectedSource(kind="workspace_repo", identifier="repo")])

    response = await handle_list_recipes(client=client, arguments={"system_id": "sys-1"})
    payload = _extract_payload(response)

    assert {recipe["id"] for recipe in payload["recipes"]} == {"source-free"}
    assert payload["source_filter"]["availability"] == "available"


@pytest.mark.asyncio
async def test_list_recipes_can_include_unavailable_sources(fake_dirs: dict[str, Path]) -> None:
    _write_recipe(fake_dirs["builtin"], "github-capture", requires_source="github_org")
    client = AsyncMock()
    client.list_connected_sources = AsyncMock(return_value=[ConnectedSource(kind="workspace_repo", identifier="repo")])

    response = await handle_list_recipes(
        client=client,
        arguments={"system_id": "sys-1", "include_unavailable": True},
    )
    payload = _extract_payload(response)

    assert payload["recipes"][0]["id"] == "github-capture"
    assert payload["recipes"][0]["source_availability"]["status"] == "unavailable"
    assert payload["recipes"][0]["source_availability"]["missing_sources"] == ["github_org"]


@pytest.mark.asyncio
async def test_list_recipes_fails_open_when_source_api_unknown(fake_dirs: dict[str, Path]) -> None:
    _write_recipe(fake_dirs["builtin"], "github-capture", requires_source="github_org")
    client = AsyncMock()
    client.list_connected_sources = AsyncMock(side_effect=NotFoundError("not found", status_code=404))

    response = await handle_list_recipes(client=client, arguments={"system_id": "sys-1"})
    payload = _extract_payload(response)

    assert payload["total"] == 1
    assert payload["source_filter"]["availability"] == "unknown"
    assert payload["recipes"][0]["source_availability"]["status"] == "unknown"


@pytest.mark.asyncio
async def test_check_sources_returns_capture_plan(fake_dirs: dict[str, Path], monkeypatch: pytest.MonkeyPatch) -> None:
    _write_recipe(fake_dirs["builtin"], "workspace-test", requires_source="workspace_repo")
    client = AsyncMock()
    client.list_connected_sources = AsyncMock(return_value=[ConnectedSource(kind="workspace_repo", identifier="repo")])
    client.get_control_context = AsyncMock(
        return_value=ControlContext(
            control_id="ac-2",
            evidence_expectations=[{"description": "Capture workspace config file"}],
        )
    )

    async def _fake_scope(*args: Any, **kwargs: Any) -> tuple[str, str, str | None]:
        return ("sys-1", "fw-1", "ac-2")

    monkeypatch.setattr("pretorin.mcp.handlers.recipe.resolve_execution_scope", _fake_scope)
    response = await handle_check_sources(
        client=client,
        arguments={"workflow_id": "single-control", "control_id": "ac-2"},
    )
    payload = _extract_payload(response)

    assert payload["items"][0]["status"] == "ready"
    assert payload["items"][0]["selected_recipe_id"] == "workspace-test"


@pytest.mark.asyncio
async def test_get_recipe_unknown_id(fake_dirs: dict[str, Path]) -> None:
    response = await handle_get_recipe(client=MagicMock(), arguments={"recipe_id": "no-such-recipe"})
    payload = _extract_payload(response)
    assert "no recipe found" in str(payload).lower()


@pytest.mark.asyncio
async def test_get_recipe_returns_full_body_and_manifest(fake_dirs: dict[str, Path]) -> None:
    _drop(fake_dirs["builtin"], "example-recipe")
    response = await handle_get_recipe(client=MagicMock(), arguments={"recipe_id": "example-recipe"})
    payload = _extract_payload(response)
    assert payload["id"] == "example-recipe"
    assert "body" in payload
    assert "Example Recipe Body" in payload["body"]
    assert payload["manifest"]["name"] == "Example Recipe"
    assert payload["source"] == "builtin"


# =============================================================================
# Phase C: handle_run_recipe_script (per-recipe-script dispatcher)
# =============================================================================


@pytest.mark.asyncio
async def test_run_recipe_script_requires_active_context(fake_dirs: dict[str, Path]) -> None:
    """Script-tool calls outside an active recipe context are rejected."""
    _drop(fake_dirs["builtin"], "example-recipe")
    # Drop a real script file so the manifest's reference resolves.
    script_file = fake_dirs["builtin"] / "example-recipe" / "scripts" / "example.py"
    script_file.parent.mkdir(exist_ok=True)
    script_file.write_text('"""."""\nasync def run(ctx, **params):\n    return {"ok": True}\n')

    tool_name = script_tool_name("example-recipe", "example_tool")
    response = await handle_run_recipe_script(
        client=MagicMock(),
        arguments={},
        tool_name=tool_name,
    )
    payload = _extract_payload(response)
    assert "active recipe execution context" in str(payload).lower()


@pytest.mark.asyncio
async def test_run_recipe_script_unknown_tool_name(fake_dirs: dict[str, Path]) -> None:
    response = await handle_run_recipe_script(
        client=MagicMock(),
        arguments={},
        tool_name="recipe_unknown__nope",
    )
    payload = _extract_payload(response)
    assert "no recipe script tool" in str(payload).lower()


@pytest.mark.asyncio
async def test_run_recipe_script_wrong_recipe_context(fake_dirs: dict[str, Path]) -> None:
    """Active context for recipe A; calling recipe B's script is rejected."""
    _drop(fake_dirs["builtin"], "example-recipe")
    _drop(fake_dirs["builtin"], "another-recipe")
    script_file = fake_dirs["builtin"] / "example-recipe" / "scripts" / "example.py"
    script_file.parent.mkdir(exist_ok=True)
    script_file.write_text('"""."""\nasync def run(ctx, **params):\n    return {}\n')

    # Start the another-recipe context (no scripts).
    await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "another-recipe", "recipe_version": "1.2.3"},
    )
    # Now try to call example-recipe's script.
    tool_name = script_tool_name("example-recipe", "example_tool")
    response = await handle_run_recipe_script(
        client=MagicMock(),
        arguments={},
        tool_name=tool_name,
    )
    payload = _extract_payload(response)
    assert "active recipe context is for" in str(payload).lower()


@pytest.mark.asyncio
async def test_run_recipe_script_happy_path(fake_dirs: dict[str, Path]) -> None:
    """With an active matching context, the script's run() executes and returns its dict."""
    _drop(fake_dirs["builtin"], "example-recipe")
    script_file = fake_dirs["builtin"] / "example-recipe" / "scripts" / "example.py"
    script_file.parent.mkdir(exist_ok=True)
    script_file.write_text(
        '"""."""\n'
        "async def run(ctx, **params):\n"
        '    return {"ok": True, "input": params.get("input"), "ctx_recipe": ctx.recipe_id}\n'
    )

    await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    tool_name = script_tool_name("example-recipe", "example_tool")
    response = await handle_run_recipe_script(
        client=MagicMock(),
        arguments={"input": "hello"},
        tool_name=tool_name,
    )
    payload = _extract_payload(response)
    assert payload["ok"] is True
    assert payload["input"] == "hello"
    assert payload["ctx_recipe"] == "example-recipe"


@pytest.mark.asyncio
async def test_run_recipe_script_propagates_active_context(
    fake_dirs: dict[str, Path], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Regression for #104: `ctx.system_id` / `ctx.framework_id` MUST come from
    the active CLI context (Config), not from `getattr(client, ...)`.

    Pre-fix the dispatcher read `getattr(client, "active_system_id", None)` and
    `getattr(client, "active_framework_id", None)`. Those attributes don't
    exist on PretorianClient — they live on Config — so every scanner recipe
    saw `ctx.system_id is None` and the platform returned `System not found`.

    This test mocks an active CLI context with known ids, dispatches a script
    that captures them, and asserts they reach the script unchanged.
    """
    _drop(fake_dirs["builtin"], "example-recipe")
    script_file = fake_dirs["builtin"] / "example-recipe" / "scripts" / "example.py"
    script_file.parent.mkdir(exist_ok=True)
    script_file.write_text(
        '"""."""\n'
        "async def run(ctx, **params):\n"
        '    return {"system_id": ctx.system_id, "framework_id": ctx.framework_id}\n'
    )

    class _StubConfig:
        active_system_id = "sys-fixture"
        active_framework_id = "fw-fixture"

    monkeypatch.setattr("pretorin.mcp.handlers.recipe.Config", _StubConfig)

    await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": "example-recipe", "recipe_version": "0.1.0"},
    )
    tool_name = script_tool_name("example-recipe", "example_tool")
    response = await handle_run_recipe_script(
        client=MagicMock(),
        arguments={},
        tool_name=tool_name,
    )
    payload = _extract_payload(response)
    assert payload["system_id"] == "sys-fixture"
    assert payload["framework_id"] == "fw-fixture"


# =============================================================================
# Phase C: list_tools includes per-recipe-script tools dynamically
# =============================================================================


@pytest.mark.asyncio
async def test_list_tools_includes_dynamic_script_tools(fake_dirs: dict[str, Path]) -> None:
    """Loaded recipes' scripts show up in the MCP tool list."""
    from pretorin.mcp.tools import list_tools

    _drop(fake_dirs["builtin"], "example-recipe")
    tools = await list_tools()
    tool_names = {t.name for t in tools}
    expected = script_tool_name("example-recipe", "example_tool")
    assert expected in tool_names

    # Schema is built from ScriptDecl.params — should include "input".
    matching = next(t for t in tools if t.name == expected)
    assert "input" in matching.inputSchema["properties"]
