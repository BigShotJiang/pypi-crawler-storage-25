"""Smoke test for the smoke test.

Runs ``pretorin mcp-smoke-test``'s in-process flow end-to-end and asserts
exit code 0. Catches regressions where the smoke harness itself drifts
from the handlers it exercises.
"""

from __future__ import annotations

import io

import pytest

from pretorin.mcp.smoke import run_smoke_test


def test_smoke_test_exits_zero(capsys: pytest.CaptureFixture[str]) -> None:
    exit_code = run_smoke_test()
    captured = capsys.readouterr()
    assert exit_code == 0, f"smoke test failed:\n{captured.out}\n{captured.err}"
    assert "PASSED" in captured.out


def test_smoke_test_runs_all_sections(capsys: pytest.CaptureFixture[str]) -> None:
    run_smoke_test()
    out = capsys.readouterr().out
    for section in (
        "check_context",
        "list_tools",
        "get_instructions",
        "get_workflow",
        "WorkflowRoutingError",
    ):
        assert section in out, f"smoke test missing section: {section}"


def test_payload_helper_handles_list_and_callresult() -> None:
    """The smoke harness needs to parse both shapes of CallToolResult."""
    from mcp.types import CallToolResult, TextContent

    from pretorin.mcp.smoke import _payload

    list_response = [TextContent(type="text", text='{"a": 1}')]
    assert _payload(list_response) == {"a": 1}

    call_response = CallToolResult(
        content=[TextContent(type="text", text='{"b": 2}')],
        isError=False,
    )
    assert _payload(call_response) == {"b": 2}


def test_captured_stderr_isolates_writes() -> None:
    """The stderr capture context restores the original stream."""
    import sys

    from pretorin.mcp.smoke import _captured_stderr

    original = sys.stderr
    with _captured_stderr() as buf:
        print("captured", file=sys.stderr)
        assert isinstance(sys.stderr, io.StringIO)
    assert sys.stderr is original
    assert "captured" in buf.getvalue()
