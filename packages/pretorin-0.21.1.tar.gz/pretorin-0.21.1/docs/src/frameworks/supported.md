# Supported Frameworks

Pretorin provides access to 26 compliance frameworks and profiles spanning federal, contractor, defense industrial base, intelligence community, regulatory, and industry-specific compliance requirements.

## Representative Frameworks

The table below highlights a representative subset of commonly used frameworks in Pretorin. Always call `pretorin frameworks list` to get the current catalog from the API for your environment. Control counts reflect the full catalog (base controls plus enhancements) as exposed by the platform.

| ID | Title | Version | Tier | Families | Controls |
|----|-------|---------|------|----------|----------|
| `nist-800-53-r5` | NIST SP 800-53 Rev 5 | 5.2.0 | tier1_essential | 20 | 1150 |
| `nist-800-171-r3` | NIST SP 800-171 Revision 3 | 1.0.0 | tier1_essential | 17 | 97 |
| `fedramp-low` | FedRAMP Rev 5 Low Baseline | fedramp2.1.0-oscal1.0.4 | tier1_essential | 18 | 156 |
| `fedramp-moderate` | FedRAMP Rev 5 Moderate Baseline | fedramp2.1.0-oscal1.0.4 | tier1_essential | 18 | 323 |
| `fedramp-high` | FedRAMP Rev 5 High Baseline | fedramp2.1.0-oscal1.0.4 | tier1_essential | 18 | 410 |
| `cmmc-l1` | CMMC 2.0 Level 1 (Foundational) | 2.0 | tier1_essential | 6 | 17 |
| `cmmc-l2` | CMMC 2.0 Level 2 (Advanced) | 2.0 | tier1_essential | 14 | 110 |
| `cmmc-l3` | CMMC 2.0 Level 3 (Expert) | 2.0 | tier1_essential | 10 | 24 |

### Framework Tiers

Each framework has a **tier** classification displayed in the `pretorin frameworks list` output:

| Tier | Description |
|------|-------------|
| **tier1_essential** | Core frameworks most teams encounter first: NIST 800-53, NIST 800-171, the FedRAMP baselines, and all three CMMC levels. |
| **tier2_important** | Sector-specific and adjacent baselines: DoD Cloud SRG / On-Prem, FIPS 140-3, GDPR, HIPAA, ICD-503, IoT Federal, ISO 27001, ISO 42001, MITRE ATLAS, NIST 800-218, NSS-IC, OT/ICS, PCI-DSS 4.0, and SOC 2. |

## Framework Relationships

Understanding how frameworks relate helps with cross-compliance:

```
NIST 800-53 Rev 5 (full catalog including enhancements, ~1150 controls)
├── FedRAMP Low/Moderate/High (800-53 subset + cloud requirements)
├── DoD Cloud IL2/IL4/IL5 + DoD On-Prem (FedRAMP + DoD additions)
├── NIST 800-171 Rev 3 (800-53 subset for CUI in non-federal systems)
│   └── CMMC Level 2 (maps to 800-171 requirements)
└── CMMC Level 3 (advanced controls beyond 800-171)
```

If an organization is already compliant with a parent framework, many child framework controls are already satisfied.

## NIST SP 800-53 Rev 5

The foundational catalog for federal information systems. Includes 20 control families covering all aspects of information security. All other US government frameworks derive from it. The platform exposes the full catalog (base controls plus enhancements), which `pretorin frameworks list` reports as ~1150 controls.

**Target audience:** Federal agencies

## NIST SP 800-171 Rev 3

Protects Controlled Unclassified Information (CUI) in non-federal systems. A focused subset of 800-53 with 97 requirements in the platform's catalog.

**Target audience:** Federal contractors, universities, and other non-federal entities handling CUI under DFARS 252.204-7012 or similar requirements.

## FedRAMP

Based on NIST 800-53 with additional cloud-specific requirements. Required for cloud services used by federal agencies.

**Impact levels:**

| Level | ID | Controls | Use When |
|-------|-----|----------|----------|
| Low | `fedramp-low` | 156 | Public, non-sensitive data. Limited adverse effect from loss. |
| Moderate | `fedramp-moderate` | 323 | CUI, PII, sensitive data. Serious adverse effect from loss. Most common level. |
| High | `fedramp-high` | 410 | Life-safety, financial, law enforcement data. Severe/catastrophic effect from loss. |

**Target audience:** Cloud service providers to government

## CMMC 2.0

Cybersecurity Maturity Model Certification for defense contractors. Required by DoD contracts.

| Level | ID | Controls | Use When |
|-------|-----|----------|----------|
| Level 1 | `cmmc-l1` | 17 | Handles only Federal Contract Information (FCI). Basic cyber hygiene. |
| Level 2 | `cmmc-l2` | 110 | Handles CUI. Aligns with NIST 800-171. Most defense contractors need this. |
| Level 3 | `cmmc-l3` | 24 | Highest sensitivity CUI. Advanced practices **on top of** Level 2. |

**Target audience:** Defense industrial base organizations

> **Note:** CMMC Level 3 controls are in addition to Level 2. An organization at Level 3 must also satisfy all Level 2 controls.

## Custom and Forked Frameworks

If your organization needs to track a framework that isn't in the built-in catalog (e.g., an internal control set, a tailored ISO/SOC 2 mapping, an industry-specific regulation), you can author one yourself or fork an existing Pretorin-managed framework. The `pretorin frameworks` group exposes the full revision lifecycle:

- **Author from scratch** — `init-custom`, `validate-custom`, `upload-custom`
- **Convert from OSCAL or 12 known custom catalog shapes** — `build-custom`
- **Fork an existing framework** — `fork-framework`, `rebase-fork`
- **Inspect drafts** — `revisions`
- **Round-trip back to OSCAL** — `export-oscal`

See the [Custom Frameworks](./custom.md) guide for the end-to-end workflow.

See [Framework Selection Guide](./selection.md) for help choosing the right framework.
