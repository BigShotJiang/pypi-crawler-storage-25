# Framework Selection Guide

Use this decision tree to identify the right compliance framework for your situation.

## Decision Tree

### 1. Federal Agency (US Government)

**Use: NIST 800-53 Rev 5** (`nist-800-53-r5`)

The foundational catalog for federal information systems. All other US government frameworks derive from it. Spans 20 control families covering all aspects of information security; the platform exposes the full catalog (base controls plus enhancements), which `pretorin frameworks list` reports as ~1150 controls. Use this when the organization IS a federal agency and needs the full control catalog.

### 2. Federal Contractor Handling CUI

**Use: NIST 800-171 Rev 3** (`nist-800-171-r3`)

Protects Controlled Unclassified Information (CUI) in non-federal systems. A focused subset of 800-53 with 97 requirements in the platform's catalog. Use this when the organization is a contractor, university, or other non-federal entity that handles CUI under DFARS 252.204-7012 or similar requirements.

### 3. Cloud Service Provider to Government

**Use: FedRAMP** (`fedramp-low`, `fedramp-moderate`, `fedramp-high`)

Based on NIST 800-53 with additional cloud-specific requirements. Required for cloud services used by federal agencies.

| Level | ID | Controls | Use When |
|-------|-----|----------|----------|
| **Low** | `fedramp-low` | 156 | Public, non-sensitive data. Loss would have limited adverse effect. |
| **Moderate** | `fedramp-moderate` | 323 | CUI, PII, sensitive but not critical data. Loss would have serious adverse effect. Most common level. |
| **High** | `fedramp-high` | 410 | Life-safety, financial, law enforcement, or emergency services data. Loss would have severe or catastrophic effect. |

When unsure, **FedRAMP Moderate** is the most common starting point for cloud services handling government data.

### 4. Defense Industrial Base (DIB)

**Use: CMMC** (`cmmc-l1`, `cmmc-l2`, `cmmc-l3`)

Cybersecurity Maturity Model Certification for defense contractors. Required by DoD contracts.

| Level | ID | Controls | Use When |
|-------|-----|----------|----------|
| **Level 1** | `cmmc-l1` | 17 | Handles only Federal Contract Information (FCI). Basic cyber hygiene. |
| **Level 2** | `cmmc-l2` | 110 | Handles CUI. Aligns with NIST 800-171. Most defense contractors need this. |
| **Level 3** | `cmmc-l3` | 24 | Highest sensitivity CUI. Advanced/progressive practices on top of Level 2. |

Note: CMMC Level 3 controls are **in addition to** Level 2.

### 5. None of the above fits — bring your own framework

If the built-in catalog doesn't cover your obligation (e.g., an internal control set, a tailored mapping, an industry-specific regulation), you can author a custom framework or fork an existing one. See the [Custom Frameworks](./custom.md) guide for the `pretorin frameworks init-custom` / `build-custom` / `upload-custom` / `fork-framework` workflow.

## Quick Reference

| Situation | Framework | ID |
|-----------|-----------|-----|
| We're a federal agency | NIST 800-53 | `nist-800-53-r5` |
| We handle CUI as a contractor | NIST 800-171 | `nist-800-171-r3` |
| We're a cloud service for government | FedRAMP | `fedramp-moderate` |
| We have a DoD contract | CMMC | `cmmc-l2` |
| We need to handle both CUI and cloud | FedRAMP + 800-171 | Start with `fedramp-moderate` |
| We're not sure yet | Start with NIST 800-53 | `nist-800-53-r5` |
| Our framework isn't in the catalog | Author or fork your own | See [Custom Frameworks](./custom.md) |

## Using AI Context for Selection

Call `get_framework` (MCP) or `pretorin frameworks get <id>` (CLI) to get AI context including purpose, target audience, regulatory context, scope, and key concepts. This helps confirm whether a framework is the right fit.
