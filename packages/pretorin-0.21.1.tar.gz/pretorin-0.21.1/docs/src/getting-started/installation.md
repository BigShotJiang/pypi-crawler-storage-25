# Installation

Pretorin CLI requires Python 3.10 or later.

## Recommended: uv

[uv](https://docs.astral.sh/uv/) installs the CLI as an isolated tool with its own dependencies:

```bash
uv tool install pretorin
```

## pip

```bash
pip install pretorin
```

## pipx

[pipx](https://pipx.pypa.io/) provides isolated installation similar to uv:

```bash
pipx install pretorin
```

## Docker

A multi-stage Dockerfile is included in the repository. The `production` target builds an image that runs the `pretorin` CLI as its entrypoint:

```bash
git clone https://github.com/pretorin-ai/pretorin-cli.git
cd pretorin-cli
docker build --target production -t pretorin .
docker run --rm pretorin --help
```

Mount your config directory to persist credentials between runs:

```bash
docker run --rm -v "$HOME/.pretorin:/home/pretorin/.pretorin" pretorin frameworks list
```

The included `docker-compose.yml` defines `test`, `test-coverage`, `lint`, `typecheck`, and `integration` services for contributors. Each is invoked with `docker compose run --rm <service>`, not `docker compose up`. See [Contributing](../reference/contributing.md) for development workflows.

## Verify Installation

```bash
pretorin version
```

Expected output:

```
pretorin version 0.21.1
```

## Updating

Check for and install the latest version:

```bash
pretorin update
```

The CLI also checks for updates automatically on startup and notifies you when a new version is available. To disable passive update notifications:

```bash
export PRETORIN_DISABLE_UPDATE_CHECK=1
# or
pretorin config set disable_update_check true
```

## Development Installation

For contributing to Pretorin CLI:

```bash
git clone https://github.com/pretorin-ai/pretorin-cli.git
cd pretorin-cli
uv pip install -e ".[dev]"
```

This installs the package in editable mode with development dependencies (pytest, ruff, mypy, etc.).
