# Agent Skills

Skills are predefined task templates that guide the agent through specific compliance workflows.

## Available Skills

| Skill | Description | Max Turns |
|-------|-------------|-----------|
| `gap-analysis` | Analyze system compliance gaps across frameworks | 20 |
| `narrative-generation` | Generate implementation narratives for controls | 15 |
| `evidence-collection` | Collect and map evidence from codebase to controls | 20 |
| `security-review` | Review codebase for security controls and compliance posture | 25 |
| `stig-scan` | Run STIG compliance scans against a system | 15 |
| `cci-assessment` | Assess CCI compliance for a specific control | 15 |

`max_turns` is enforced only in `--legacy` mode. The Codex runtime governs turn count via its own session loop.

## Using Skills

```bash
# Gap analysis
pretorin agent run --skill gap-analysis "Analyze my system compliance gaps"

# Narrative generation
pretorin agent run --skill narrative-generation "Generate narratives for all AC controls"

# Evidence collection
pretorin agent run --skill evidence-collection "Collect evidence for AC-02 in this repo"

# Security review
pretorin agent run --skill security-review "Review this codebase for AC-02 coverage"

# STIG scan
pretorin agent run --skill stig-scan "Check STIG applicability for my system"

# CCI assessment
pretorin agent run --skill cci-assessment "Assess CCI compliance for AC-02"
```

## List Skills

```bash
pretorin agent skills
```

## Skill Details

### Gap Analysis

Read-only platform analysis that identifies controls without complete implementation. The agent:

1. Lists systems and their associated frameworks
2. Checks the compliance status for each system
3. Identifies controls that are not yet implemented or only partially implemented
4. Prioritizes gaps by risk level (controls in higher-impact families first)
5. Provides actionable recommendations for closing each gap

This skill does not write to the platform — it produces a structured report with sections for each framework. To capture findings as evidence or update narratives, follow up with `evidence-collection` or `narrative-generation`.

See [Gap Analysis Workflow](../workflows/gap-analysis.md) for the broader methodology that combines this skill with codebase search.

### Narrative Generation

Generates control implementation narratives that meet auditor-readiness requirements:

- No markdown headings
- At least two rich markdown elements (code blocks, tables, lists, links)
- At least one structural element (code block, table, or list)
- TODO placeholders for missing information
- Only documents observable facts (no hallucination)

### Evidence Collection

Searches the codebase for evidence that maps to specific controls:

- Identifies relevant files and code patterns
- Creates evidence items with auditor-ready descriptions
- Links evidence to controls via the platform
- Flags gaps where evidence is missing

### Security Review

Reviews the codebase against specific controls and records findings on the platform:

- Analyzes code for control coverage
- Identifies implementation strengths and weaknesses
- Documents findings with file paths and line numbers
- Pushes monitoring events for critical or high-severity findings
- Reopens control authoring with `in_progress` and drafts narratives based on findings
- Adds notes for findings that require manual remediation
- Produces remediation recommendations

This is the broadest write-side skill — it can call `push_monitoring_event`, `update_control_status` (only `in_progress`), `update_narrative`, `create_evidence`, `link_evidence`, and `add_control_note`/`resolve_control_note` in addition to the read-side platform tools.

### STIG Scan

Runs STIG compliance scans against a system:

- Checks which STIGs apply to the system (applicability)
- Gets the test manifest (rules to evaluate)
- Reports available scanners and rule coverage
- Summarizes the scan plan and gaps in automated coverage

### CCI Assessment

Assesses CCI-level compliance for a specific control:

- Gets control context and implementation status
- Lists CCIs for the target control
- Checks CCI-level test results (pass/fail/not tested)
- Identifies CCIs with no test coverage
- Presents results as a traceability chain: Control -> CCIs -> SRGs -> STIG rules
