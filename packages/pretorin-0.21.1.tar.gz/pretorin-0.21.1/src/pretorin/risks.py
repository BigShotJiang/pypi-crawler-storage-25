"""Shared validation constants for the system-scoped risk register.

These were previously duplicated in `pretorin/cli/risk.py` and
`pretorin/mcp/handlers/risks.py`; centralizing them here keeps the CLI
and MCP surfaces from drifting if the platform adds a new treatment or
link type.
"""

from __future__ import annotations

from typing import Final

VALID_TREATMENTS: Final[frozenset[str]] = frozenset({"mitigate", "accept", "transfer", "avoid"})

VALID_LINK_TYPES: Final[frozenset[str]] = frozenset({"contributes_to_risk", "mitigates_risk", "evidence_of_risk"})
