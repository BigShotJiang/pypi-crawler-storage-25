"""Tier classification for MCP tools.

Per RFC #113, the MCP tool surface is being reshaped into a funnel: a small
default tier advertised at session start, with the wider surface unlocked
once a workflow has been routed via ``start_task``.

Phase 0-2 introduces the metadata so ``list_tools`` can return
``{name, one_line_purpose, tier, requires_workflow}`` for every tool. The
**advertisement** behavior (actually culling the default surface) is phase
4 and gated on bypass-log data — the metadata here is informational for now.

Tier semantics:

- ``default`` — always advertised. The minimum surface an agent needs to
  ground itself and reach a workflow. Includes the funnel-entry tools.
- ``reference`` — read-only browsing of frameworks, controls, systems,
  recipes, etc. Safe to call without prior routing; no writes happen.
- ``workflow`` — requires prior ``start_task`` context. Calling these without
  active system/framework raises ``WorkflowRoutingError`` and returns a
  structured ``workflow_required`` payload. Evidence/narrative producer tools
  also require ``recipe_context_id`` and may return ``recipe_required`` before
  scope resolution.
- ``recipe`` — dynamic per-recipe-script tools. Tier is computed by name
  prefix at runtime (any tool starting with ``recipe_``).
"""

from __future__ import annotations

# The minimum surface a calling agent needs to ground itself, learn what's
# available, and route a task. This is the surface that survives the phase-4
# cull (RFC #113).
DEFAULT_TIER: frozenset[str] = frozenset(
    {
        "check_context",
        "start_task",
        "get_workflow",
        "list_systems",
        "list_frameworks",
        "list_tools",
        "get_instructions",
        "get_cli_status",
    }
)

# Tools that mutate platform state and require an active routing context.
# Evidence/narrative producer tools layer a recipe-context guard on top of this
# workflow tier. Keep in sync when adding new write tools.
WORKFLOW_TIER: frozenset[str] = frozenset(
    {
        "create_evidence",
        "create_evidence_batch",
        "upload_evidence",
        "link_evidence",
        "delete_evidence",
        "update_narrative",
        "update_control_status",
        "add_control_note",
        "resolve_control_note",
        "push_monitoring_event",
        "get_control_implementation",
        "get_narrative",
    }
)


def tier_for(tool_name: str) -> str:
    """Return the tier classification for a tool name.

    Per-recipe-script tools (``recipe_<id>__<script>``) are
    classified as ``recipe``. Anything not explicitly in DEFAULT_TIER or
    WORKFLOW_TIER falls back to ``reference``.
    """
    if tool_name in DEFAULT_TIER:
        return "default"
    if tool_name in WORKFLOW_TIER:
        return "workflow"
    if tool_name.startswith("recipe_"):
        return "recipe"
    return "reference"


def requires_workflow(tool_name: str) -> bool:
    """Return True if the tool requires prior ``start_task`` context."""
    return tool_name in WORKFLOW_TIER


__all__ = ["DEFAULT_TIER", "WORKFLOW_TIER", "tier_for", "requires_workflow"]
