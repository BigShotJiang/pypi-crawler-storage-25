"""MCP handlers for engagement-layer tools.

This module hosts the session-grounding and discovery tools the calling
agent uses before making writes:

- ``check_context`` — cheap, unauthenticated probe. Returns local
  connection state + active system/framework, with a plain-English
  ``suggested_next`` hint. Always safe to call at session start.
- ``list_tools`` — compact catalog. Returns ``{name, purpose,
  tier, requires_workflow}`` for every tool. Cross-harness alternative to
  fetching every tool's full schema just to browse.
- ``get_instructions`` — callable mirror of the server
  ``instructions`` block, for harnesses (Cursor, Codex, vanilla SDK) that
  don't render server instructions to the agent.
- ``start_task`` — routes a user prompt to a workflow using
  deterministic entity rules. Three response shapes: MCP error (hard
  cross-check failure), routed selection, or ambiguous selection (the
  calling agent surfaces the ambiguity to the user before retrying).

Neither handler runs an LLM in pretorin; entity extraction and reasoning
are the calling agent's job.
"""

from __future__ import annotations

import logging
from typing import Any

from mcp.types import CallToolResult, TextContent
from pydantic import ValidationError

from pretorin.capture_plan import build_capture_plan
from pretorin.client import PretorianClient
from pretorin.engagement.cross_check import cross_check_entities
from pretorin.engagement.entities import EngagementEntities
from pretorin.engagement.inspect import gather_inspect_summary
from pretorin.engagement.rules import select_workflow
from pretorin.engagement.selection import EngagementSelection
from pretorin.mcp.helpers import format_error, format_json, safe_args

logger = logging.getLogger(__name__)


async def handle_start_task(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Route a user prompt to a workflow.

    Inputs (all under ``entities``):
    - ``intent_verb`` (required): one of work_on / collect_evidence /
      draft_narrative / answer / campaign / inspect_status.
    - ``raw_prompt`` (required): the user's verbatim prompt for audit.
    - ``system_id`` / ``framework_id`` / ``control_ids`` /
      ``scope_question_ids`` / ``policy_question_ids`` (all optional).

    Optional top-level args:
    - ``active_system_id`` — caller's CLI context system. When set and
      different from the resolved system, the response is ambiguous so
      the calling agent surfaces cross-system intent.
    - ``skip_inspect`` (default false) — skip the server-side platform
      reads. Use when the calling agent already has fresh state.

    Returns a JSON ``EngagementSelection``. Hard cross-check failures
    surface as MCP errors so the calling agent sees the failure mode.
    """
    logger.debug("handle_start_task called with %s", safe_args(arguments))

    entities_input = arguments.get("entities")
    if not isinstance(entities_input, dict):
        return format_error(
            "Argument 'entities' is required and must be an object with at least intent_verb and raw_prompt."
        )

    try:
        entities = EngagementEntities.model_validate(entities_input)
    except ValidationError as exc:
        return format_error(f"entities failed schema validation: {exc}")

    active_system_id = arguments.get("active_system_id")
    if active_system_id is not None and not isinstance(active_system_id, str):
        return format_error("active_system_id must be a string when provided")

    skip_inspect = bool(arguments.get("skip_inspect", False))

    # Cross-check the entities against platform state before routing.
    cross_check = await cross_check_entities(client, entities, active_system_id=active_system_id)

    if cross_check.has_hard_error:
        return format_error("; ".join(cross_check.hard_errors))

    # Inspect the system/framework state — best-effort, never fails the
    # call. Skipped only when the caller explicitly opts out.
    if skip_inspect:
        inspect_summary: dict[str, Any] = {"skipped": True}
    else:
        inspect_summary = await gather_inspect_summary(
            client,
            system_id=cross_check.resolved_system_id or entities.system_id,
            framework_id=cross_check.resolved_framework_id or entities.framework_id,
        )

    # Apply the routing rules.
    selection = select_workflow(entities, inspect_summary)

    # If the cross-check found ambiguities (cross-system, wrong-framework,
    # control-in-wrong-framework), override the rule-matched outcome with
    # an ambiguous response so the calling agent asks the user to confirm
    # before any writes happen.
    if cross_check.has_ambiguity:
        selection = EngagementSelection(
            entities=entities,
            inspect_summary=inspect_summary,
            selected_workflow=None,
            workflow_params={},
            rule_matched="",
            ambiguous=True,
            ambiguity_reason=" | ".join(cross_check.ambiguities),
        )

    if not selection.ambiguous and selection.selected_workflow in {"single-control", "campaign"}:
        control_ids: list[str] = []
        if isinstance(selection.workflow_params.get("control_id"), str):
            control_ids = [str(selection.workflow_params["control_id"])]
        elif isinstance(selection.workflow_params.get("control_filter"), list):
            control_ids = [str(item) for item in selection.workflow_params["control_filter"] if item]
        if control_ids:
            try:
                capture_plan = await build_capture_plan(
                    client,
                    workflow_id=selection.selected_workflow,
                    system_id=cross_check.resolved_system_id or entities.system_id,
                    framework_id=cross_check.resolved_framework_id or entities.framework_id,
                    control_ids=control_ids,
                )
                selection.suggested_capture_plan = capture_plan.model_dump(exclude_none=True)
            except Exception as exc:  # noqa: BLE001 - start_task should stay best-effort
                logger.debug("capture-plan generation failed", exc_info=True)
                selection.suggested_capture_plan = {
                    "workflow_id": selection.selected_workflow,
                    "source_availability": "unknown",
                    "items": [],
                    "recipe_gaps": [],
                    "source_message": f"capture-plan generation failed: {exc}",
                }

    return format_json(selection.model_dump())


def _one_line_purpose(description: str, max_chars: int = 100) -> str:
    """Extract a one-line purpose summary from a tool's description.

    Picks the first sentence (split on ``.``) and truncates to ``max_chars``.
    Multi-paragraph descriptions become a single line for compact display.
    """
    flat = " ".join(description.split())
    first = flat.split(".", 1)[0].strip()
    if len(first) > max_chars:
        return first[: max_chars - 1].rstrip() + "…"
    return first


async def handle_list_tools(
    _client: PretorianClient | None,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Return a compact catalog of available MCP tools.

    Designed to answer "what's available?" without forcing the agent to
    fetch every tool's full inputSchema. Each entry is::

        {
          "name": "start_task",
          "purpose": "Route a user prompt to the right workflow...",
          "tier": "default",          # default | reference | workflow | recipe
          "requires_workflow": false
        }

    Unauthenticated — listing is a discovery surface, not a privileged read.
    """
    logger.debug("handle_list_tools called with %s", safe_args(arguments))

    from pretorin.mcp.tool_metadata import requires_workflow, tier_for
    from pretorin.mcp.tools import list_tools as _build_tool_list

    tools = await _build_tool_list()
    entries: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    for tool in tools:
        tier = tier_for(tool.name)
        entries.append(
            {
                "name": tool.name,
                "purpose": _one_line_purpose(tool.description or ""),
                "tier": tier,
                "requires_workflow": requires_workflow(tool.name),
            }
        )
        counts[tier] = counts.get(tier, 0) + 1

    return format_json(
        {
            "total": len(entries),
            "tier_counts": counts,
            "tools": entries,
            "note": (
                "Call `get_instructions` for the routing protocol, or "
                "`start_task` to route a user prompt to a workflow. "
                "Tools with requires_workflow=true need prior start_task context."
            ),
        }
    )


async def handle_get_instructions(
    _client: PretorianClient | None,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Return the server's instructions block as structured data.

    The MCP protocol exposes ``instructions`` in the ``initialize``
    handshake, but not every harness (Cursor, Codex, vanilla Agents SDK)
    renders that text to the agent. This tool mirrors it as a regular tool
    response so any agent can fetch the routing rules on demand.
    """
    logger.debug("handle_get_instructions called with %s", safe_args(arguments))

    from pretorin.mcp.server import server as _server

    instructions = _server.instructions or ""
    return format_json(
        {
            "instructions": instructions,
            "version": 1,
            "note": (
                "These are the same instructions the MCP server advertises in "
                "the `initialize` handshake. Harnesses that don't render the "
                "instructions block can call this tool to fetch them on demand."
            ),
        }
    )


async def handle_check_context(
    _client: PretorianClient | None,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Return a cheap snapshot of session grounding.

    No platform calls — reads local CLI config only. Always callable, even
    when the client isn't authenticated. The ``suggested_next`` field is a
    deterministic next-step hint based on what's missing.

    Response shape::

        {
          "connected": bool,            # api_key present in local config
          "active_system": null | {"id": str, "name": str},
          "active_framework_id": null | str,
          "suggested_next": str,        # plain-English next step
          "pending_attention": {}        # reserved for future signals
        }
    """
    logger.debug("handle_check_context called with %s", safe_args(arguments))

    from pretorin.client.config import Config

    config = Config()
    connected = config.is_configured

    active_system_id = config.active_system_id
    active_system: dict[str, str] | None = None
    if active_system_id:
        active_system = {
            "id": active_system_id,
            "name": config.active_system_name or active_system_id,
        }

    active_framework_id = config.active_framework_id

    if not connected:
        suggested_next = (
            "Not authenticated. Run `pretorin login` in the terminal to authenticate, or set PRETORIN_API_KEY."
        )
    elif active_system is None:
        suggested_next = (
            "Authenticated, but no active system. Call "
            "`list_systems` to see available systems. If empty, "
            "the user needs a beta code — sign up at "
            "https://pretorin.com/early-access/."
        )
    elif not active_framework_id:
        suggested_next = (
            "Active system set, but no active framework. Run "
            "`pretorin context set --framework <id>` in the terminal, or "
            "pass `framework_id` explicitly on each call."
        )
    else:
        suggested_next = (
            "Ready. Call `start_task` with an `intent_verb` "
            "(work_on, collect_evidence, draft_narrative, answer, "
            "campaign, inspect_status) to route the user's request to a "
            "workflow."
        )

    payload: dict[str, Any] = {
        "connected": connected,
        "active_system": active_system,
        "active_framework_id": active_framework_id,
        "suggested_next": suggested_next,
        "pending_attention": {},
    }
    return format_json(payload)


__all__ = [
    "handle_check_context",
    "handle_get_instructions",
    "handle_list_tools",
    "handle_start_task",
]
