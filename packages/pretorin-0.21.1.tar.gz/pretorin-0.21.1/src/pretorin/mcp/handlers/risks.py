"""Handlers for risk-management tools (system-scoped risk register)."""

from __future__ import annotations

from typing import Any

from mcp.types import CallToolResult, TextContent

from pretorin.client import PretorianClient
from pretorin.client.api import PretorianClientError
from pretorin.mcp.helpers import format_error, format_json, require, resolve_system_id
from pretorin.risks import VALID_LINK_TYPES, VALID_TREATMENTS
from pretorin.utils import normalize_control_id


async def _require_system_id(client: PretorianClient, arguments: dict[str, Any]) -> str:
    """Resolve system_id and narrow Optional[str] -> str for downstream type checks."""
    system_id = await resolve_system_id(client, arguments)
    if system_id is None:
        raise PretorianClientError("system_id is required")
    return system_id


async def handle_list_risks(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """List risks for a system, optionally filtered."""
    err = require(arguments, "system_id")
    if err:
        return format_error(err)
    system_id = await _require_system_id(client, arguments)
    risks = await client.list_risks(
        system_id,
        category=arguments.get("category"),
        risk_level=arguments.get("risk_level"),
        status=arguments.get("status"),
    )
    return format_json({"total": len(risks), "risks": risks})


async def handle_get_risk(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Get a single risk with eager-loaded artifact links."""
    err = require(arguments, "system_id", "risk_id")
    if err:
        return format_error(err)
    system_id = await _require_system_id(client, arguments)
    result = await client.get_risk(system_id, arguments["risk_id"])
    return format_json(result)


async def handle_create_risk(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Create a custom risk; auto-links controls if framework_id + suggested_control_families."""
    err = require(arguments, "system_id", "title", "category")
    if err:
        return format_error(err)
    treatment = arguments.get("treatment")
    if treatment is not None and treatment not in VALID_TREATMENTS:
        return format_error(f"Invalid treatment {treatment!r}. Must be one of: {', '.join(sorted(VALID_TREATMENTS))}")
    system_id = await _require_system_id(client, arguments)
    result = await client.create_risk(
        system_id,
        title=arguments["title"],
        category=arguments["category"],
        description=arguments.get("description"),
        cia_category=arguments.get("cia_category"),
        likelihood=arguments.get("likelihood"),
        impact=arguments.get("impact"),
        owner_id=arguments.get("owner_id"),
        treatment=treatment,
        treatment_plan=arguments.get("treatment_plan"),
        treatment_due_date=arguments.get("treatment_due_date"),
        review_frequency_days=arguments.get("review_frequency_days"),
        suggested_control_families=arguments.get("suggested_control_families"),
        framework_id=arguments.get("framework_id"),
    )
    return format_json(result)


async def handle_seed_risks(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Bulk-seed risks from the org library."""
    err = require(arguments, "system_id", "template_ids", "framework_id")
    if err:
        return format_error(err)
    template_ids = arguments["template_ids"]
    if not isinstance(template_ids, list) or not template_ids:
        return format_error("template_ids must be a non-empty list of template IDs")
    system_id = await _require_system_id(client, arguments)
    seeded = await client.seed_risks(
        system_id,
        list(template_ids),
        arguments["framework_id"],
    )
    return format_json({"total": len(seeded), "risks": seeded})


async def handle_update_risk(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Update a risk. The mitigation surface — pass treatment / treatment_plan / treatment_due_date here."""
    err = require(arguments, "system_id", "risk_id")
    if err:
        return format_error(err)
    treatment = arguments.get("treatment")
    if treatment is not None and treatment not in VALID_TREATMENTS:
        return format_error(f"Invalid treatment {treatment!r}. Must be one of: {', '.join(sorted(VALID_TREATMENTS))}")
    fields: dict[str, Any] = {}
    for key in (
        "title",
        "description",
        "category",
        "cia_category",
        "likelihood",
        "impact",
        "owner_id",
        "status",
        "treatment",
        "treatment_plan",
        "treatment_due_date",
        "review_frequency_days",
    ):
        if key in arguments:
            fields[key] = arguments[key]
    if not fields:
        return format_error("No fields to update — pass at least one updatable field.")
    system_id = await _require_system_id(client, arguments)
    result = await client.update_risk(
        system_id,
        arguments["risk_id"],
        **fields,
    )
    return format_json(result)


async def handle_link_risk_artifact(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Attach an artifact link (control / evidence / finding / vendor / monitoring_event) to a risk."""
    err = require(arguments, "system_id", "risk_id", "link_type")
    if err:
        return format_error(err)
    link_type = arguments["link_type"]
    if link_type not in VALID_LINK_TYPES:
        return format_error(f"Invalid link_type {link_type!r}. Must be one of: {', '.join(sorted(VALID_LINK_TYPES))}")
    artifact_keys = (
        "control_id",
        "evidence_id",
        "finding_id",
        "monitoring_event_id",
        "vendor_id",
    )
    # `is not None` (not truthy) so empty strings are caught explicitly below
    selected = [k for k in artifact_keys if arguments.get(k) is not None]
    if len(selected) != 1:
        return format_error(f"Pass exactly one artifact id: one of {', '.join(artifact_keys)}")
    artifact_key = selected[0]
    artifact_value = arguments[artifact_key]
    if not isinstance(artifact_value, str) or not artifact_value.strip():
        return format_error(f"{artifact_key} must be a non-empty string")
    control_id = arguments.get("control_id")
    framework_id = arguments.get("framework_id")
    if control_id is not None and not framework_id:
        return format_error("framework_id is required when linking a control")
    if control_id is not None:
        control_id = normalize_control_id(control_id)
    system_id = await _require_system_id(client, arguments)
    result = await client.add_risk_link(
        system_id,
        arguments["risk_id"],
        link_type=link_type,
        control_id=control_id,
        evidence_id=arguments.get("evidence_id"),
        finding_id=arguments.get("finding_id"),
        monitoring_event_id=arguments.get("monitoring_event_id"),
        vendor_id=arguments.get("vendor_id"),
        framework_id=framework_id,
    )
    return format_json(result)


async def handle_unlink_risk_artifact(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Remove an artifact link from a risk."""
    err = require(arguments, "system_id", "risk_id", "link_id")
    if err:
        return format_error(err)
    system_id = await _require_system_id(client, arguments)
    await client.remove_risk_link(
        system_id,
        arguments["risk_id"],
        arguments["link_id"],
    )
    return format_json(
        {
            "status": "removed",
            "system_id": system_id,
            "risk_id": arguments["risk_id"],
            "link_id": arguments["link_id"],
        }
    )


async def handle_refresh_risk_summary(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """Re-score and best-effort regenerate the AI summary for a risk."""
    err = require(arguments, "system_id", "risk_id")
    if err:
        return format_error(err)
    system_id = await _require_system_id(client, arguments)
    result = await client.refresh_risk_summary(
        system_id,
        arguments["risk_id"],
    )
    return format_json(result)


async def handle_list_risk_library(
    client: PretorianClient,
    arguments: dict[str, Any],
) -> list[TextContent] | CallToolResult:
    """List org-level risk library templates."""
    templates = await client.list_risk_library(category=arguments.get("category"))
    return format_json({"total": len(templates), "templates": templates})
