"""Capture-plan generation for source-aware recipe workflows."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from pretorin.client import PretorianClient
from pretorin.client.api import PretorianClientError
from pretorin.recipes.registry import RecipeRegistry
from pretorin.sources import (
    ConnectedSourcesResult,
    fetch_connected_sources,
    normalize_source_kind,
    recipe_source_availability,
)

CapturePlanStatus = Literal[
    "ready",
    "source_unknown",
    "source_unavailable",
    "recipe_gap",
    "no_expectations",
    "context_unavailable",
]


class RecipeGap(BaseModel):
    """Structured gap surfaced when no runnable recipe can produce an artifact."""

    control_id: str
    source_kind: str | None = None
    evidence_expectation_index: int | None = None
    reason: str
    missing_sources: list[str] = Field(default_factory=list)
    suggested_recipe_id: str | None = None


class CapturePlanItem(BaseModel):
    """One planned evidence/narrative production step."""

    control_id: str
    expectation_index: int
    expectation: dict[str, Any] = Field(default_factory=dict)
    source_kind: str | None = None
    connected: bool | None = None
    recipes_available: list[str] = Field(default_factory=list)
    selected_recipe_id: str | None = None
    status: CapturePlanStatus
    reason: str | None = None
    recipe_gap: RecipeGap | None = None


class CapturePlan(BaseModel):
    """Suggested plan returned by start_task/check_sources."""

    workflow_id: str
    system_id: str | None = None
    framework_id: str | None = None
    source_availability: str
    source_message: str | None = None
    items: list[CapturePlanItem] = Field(default_factory=list)
    recipe_gaps: list[RecipeGap] = Field(default_factory=list)


def _expectation_text(expectation: dict[str, Any]) -> str:
    return " ".join(str(value).lower() for value in expectation.values() if value is not None)


def infer_source_kind(expectation: dict[str, Any]) -> str:
    """Map a platform evidence expectation to a candidate source kind."""
    for key in ("source_kind", "required_source_kind", "kind", "source_type"):
        value = expectation.get(key)
        if isinstance(value, str) and value.strip():
            return normalize_source_kind(value)

    text = _expectation_text(expectation)
    if any(token in text for token in ("github", "pull request", "branch protection", "release marker")):
        return "github_org"
    if "aws" in text:
        return "aws_account"
    if any(token in text for token in ("azure", "entra")):
        return "azure_tenant"
    if any(token in text for token in ("kubernetes", "k8s", "cluster")):
        return "k8s_cluster"
    if "slack" in text:
        return "slack_workspace"
    if "emass" in text or "e mass" in text:
        return "emass"
    if any(token in text for token in ("manual", "attestation", "interview")):
        return "manual_attestation"
    if any(token in text for token in ("code", "config", "file", "workspace", "repo", "runbook", "script")):
        return "workspace_repo"
    return "manual_attestation"


def _extract_expectations(context_payload: dict[str, Any]) -> list[dict[str, Any]]:
    direct = context_payload.get("evidence_expectations")
    if isinstance(direct, list):
        return [item for item in direct if isinstance(item, dict)]
    ai_guidance = context_payload.get("ai_guidance")
    if isinstance(ai_guidance, dict):
        nested = ai_guidance.get("evidence_expectations") or ai_guidance.get("evidence_recommendations")
        if isinstance(nested, list):
            return [item for item in nested if isinstance(item, dict)]
    return []


def _recipe_source_kinds(manifest: Any) -> set[str]:
    return {normalize_source_kind(req.kind) for req in manifest.requires.sources}


def _candidate_recipe_ids(source_kind: str, connected: ConnectedSourcesResult) -> list[str]:
    registry = RecipeRegistry()
    candidates: list[str] = []
    for entry in registry.entries():
        manifest = entry.active.manifest
        recipe_id = manifest.id
        recipe_kinds = _recipe_source_kinds(manifest)
        if source_kind == "manual_attestation":
            matches = recipe_id == "manual-attestation"
        elif source_kind == "workspace_repo":
            matches = source_kind in recipe_kinds or recipe_id in {"code-evidence-capture", "workspace-capture"}
        else:
            matches = source_kind in recipe_kinds
        if not matches:
            continue
        availability = recipe_source_availability(manifest, connected)
        if availability.status != "unavailable":
            candidates.append(recipe_id)
    return _rank_candidates(source_kind, candidates)


def _rank_candidates(source_kind: str, candidates: list[str]) -> list[str]:
    priority = {
        "workspace_repo": ["workspace-capture", "code-evidence-capture"],
        "aws_account": ["cloud-aws-baseline"],
        "azure_tenant": ["cloud-azure-baseline"],
        "manual_attestation": ["manual-attestation"],
    }.get(source_kind, [])
    return sorted(candidates, key=lambda rid: (priority.index(rid) if rid in priority else len(priority), rid))


def _is_connected(source_kind: str, connected: ConnectedSourcesResult) -> bool | None:
    if source_kind == "manual_attestation":
        return True
    if connected.availability == "unknown":
        return None
    return source_kind in connected.connected_kinds


def _item_for_expectation(
    *,
    control_id: str,
    index: int,
    expectation: dict[str, Any],
    connected: ConnectedSourcesResult,
) -> CapturePlanItem:
    source_kind = infer_source_kind(expectation)
    is_connected = _is_connected(source_kind, connected)
    candidates = _candidate_recipe_ids(source_kind, connected)

    if is_connected is False:
        gap = RecipeGap(
            control_id=control_id,
            source_kind=source_kind,
            evidence_expectation_index=index,
            reason=f"Required source kind {source_kind!r} is not connected to the system.",
            missing_sources=[source_kind],
            suggested_recipe_id=candidates[0] if candidates else None,
        )
        return CapturePlanItem(
            control_id=control_id,
            expectation_index=index,
            expectation=expectation,
            source_kind=source_kind,
            connected=False,
            recipes_available=candidates,
            status="source_unavailable",
            reason=gap.reason,
            recipe_gap=gap,
        )

    if not candidates:
        gap = RecipeGap(
            control_id=control_id,
            source_kind=source_kind,
            evidence_expectation_index=index,
            reason=f"No installed recipe can produce evidence from source kind {source_kind!r}.",
        )
        return CapturePlanItem(
            control_id=control_id,
            expectation_index=index,
            expectation=expectation,
            source_kind=source_kind,
            connected=is_connected,
            status="recipe_gap",
            reason=gap.reason,
            recipe_gap=gap,
        )

    status: CapturePlanStatus = "source_unknown" if is_connected is None else "ready"
    return CapturePlanItem(
        control_id=control_id,
        expectation_index=index,
        expectation=expectation,
        source_kind=source_kind,
        connected=is_connected,
        recipes_available=candidates,
        selected_recipe_id=candidates[0],
        status=status,
        reason="source availability unknown; verify before capture" if status == "source_unknown" else None,
    )


async def build_capture_plan(
    client: PretorianClient,
    *,
    workflow_id: str,
    system_id: str | None,
    framework_id: str | None,
    control_ids: list[str],
) -> CapturePlan:
    """Build a best-effort capture plan for workflow entry."""
    connected = (
        await fetch_connected_sources(client, system_id)
        if system_id
        else ConnectedSourcesResult(system_id="", availability="unknown", message="system_id is required")
    )
    plan = CapturePlan(
        workflow_id=workflow_id,
        system_id=system_id,
        framework_id=framework_id,
        source_availability=connected.availability,
        source_message=connected.message,
    )
    if not system_id or not framework_id:
        return plan

    for control_id in control_ids:
        try:
            context = await client.get_control_context(system_id, control_id, framework_id)
        except PretorianClientError as exc:
            gap = RecipeGap(control_id=control_id, reason=f"Could not read control context: {exc.message}")
            plan.items.append(
                CapturePlanItem(
                    control_id=control_id,
                    expectation_index=-1,
                    status="context_unavailable",
                    reason=gap.reason,
                    recipe_gap=gap,
                )
            )
            plan.recipe_gaps.append(gap)
            continue
        payload = context.model_dump(mode="json") if hasattr(context, "model_dump") else {}
        expectations = _extract_expectations(payload)
        if not expectations:
            plan.items.append(
                CapturePlanItem(
                    control_id=control_id,
                    expectation_index=-1,
                    status="no_expectations",
                    reason="No evidence expectations were returned for this control.",
                )
            )
            continue
        for index, expectation in enumerate(expectations):
            item = _item_for_expectation(
                control_id=control_id,
                index=index,
                expectation=expectation,
                connected=connected,
            )
            plan.items.append(item)
            if item.recipe_gap is not None:
                plan.recipe_gaps.append(item.recipe_gap)
    return plan


__all__ = [
    "CapturePlan",
    "CapturePlanItem",
    "RecipeGap",
    "build_capture_plan",
    "infer_source_kind",
]
