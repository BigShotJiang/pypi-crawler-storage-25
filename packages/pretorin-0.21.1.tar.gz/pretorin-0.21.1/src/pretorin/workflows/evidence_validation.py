"""Validate code references in evidence before sending to platform.

Shared by campaign apply and recipe execution to ensure agent-reported
file paths and line numbers are real. The actual file content at the
reported lines becomes the canonical code_snippet.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pretorin.client.api import PretorianClient
from pretorin.client.models import EvidenceArtifactUpdate, EvidenceCodeContext
from pretorin.evidence.audit_metadata import build_cli_metadata, compute_content_hash, source_lines_from_locator

logger = logging.getLogger(__name__)

# Snippets larger than this are truncated with a suffix.
MAX_SNIPPET_BYTES = 50 * 1024  # 50 KB

DEFAULT_DRIFT_NOTE = (
    "Validation detected source drift. Review the updated artifact before marking this control current."
)


def validate_code_reference(
    code_file_path: str | None,
    code_line_numbers: str | None,
    working_dir: Path,
) -> EvidenceCodeContext | None:
    """Validate and enrich a code reference from an AI-reported evidence item.

    - Checks that the file exists at ``working_dir / code_file_path``.
    - Parses ``code_line_numbers`` as "N-M" and checks the range is valid.
    - Reads the actual file content at those lines as the canonical snippet.
    - Returns None if the reference is invalid (file missing, bad line range).
    - Truncates the snippet if it exceeds MAX_SNIPPET_BYTES.
    """
    if not code_file_path:
        return None

    resolved = working_dir / code_file_path
    if not resolved.is_file():
        logger.warning(
            "Evidence code_file_path does not exist: %s (resolved: %s)",
            code_file_path,
            resolved,
        )
        return None

    # Resolve to prevent traversal outside working_dir
    try:
        resolved = resolved.resolve()
        if not resolved.is_relative_to(working_dir.resolve()):
            logger.warning("Path traversal detected: %s", code_file_path)
            return None
    except (OSError, ValueError):
        return None

    context: EvidenceCodeContext = {"code_file_path": code_file_path}

    if code_line_numbers:
        start, end = _parse_line_range(code_line_numbers)
        if start is not None and end is not None:
            try:
                lines = resolved.read_text(errors="replace").splitlines()
            except OSError:
                logger.warning("Could not read file: %s", resolved)
                return context

            if end > len(lines):
                logger.warning(
                    "Line range %s exceeds file length (%d lines): %s",
                    code_line_numbers,
                    len(lines),
                    code_file_path,
                )
                # Drop the line reference but keep the file path
                return context

            # Extract actual content (1-indexed)
            snippet_lines = lines[start - 1 : end]
            snippet = "\n".join(snippet_lines)

            if len(snippet.encode("utf-8")) > MAX_SNIPPET_BYTES:
                truncated = snippet.encode("utf-8")[:MAX_SNIPPET_BYTES].decode("utf-8", errors="ignore")
                snippet = truncated + f"\n[TRUNCATED — full file: {code_file_path}]"

            context["code_line_numbers"] = code_line_numbers
            context["code_snippet"] = snippet
        else:
            logger.warning("Invalid line range format: %s", code_line_numbers)

    return context


async def validate_evidence_source(
    client: PretorianClient,
    *,
    system_id: str,
    evidence_id: str,
    source_root: Path | None = None,
    artifact_content: str | None = None,
    description: str | None = None,
    drift_note: str = DEFAULT_DRIFT_NOTE,
) -> dict[str, Any]:
    """Validate existing evidence against its recorded source-material hash.

    This is intentionally conservative: unsupported source URI schemes fail
    with an actionable error instead of silently marking evidence current. For
    file-backed evidence, the recorded ``source_lines`` or line-style
    ``source_locator`` selects the source slice; otherwise the whole file is
    hashed.
    """
    existing = await client.get_evidence(evidence_id)
    metadata = existing.audit_metadata or {}
    previous_hash = metadata.get("content_hash")
    source_uri = metadata.get("source_uri")
    if not previous_hash:
        raise ValueError("Existing evidence is missing audit_metadata.content_hash; cannot validate drift")
    if not source_uri:
        raise ValueError("Existing evidence is missing audit_metadata.source_uri; cannot re-read source")

    source_lines = _metadata_source_lines(metadata)
    source_path = _source_uri_to_path(str(source_uri), source_root or Path.cwd())
    source_excerpt = _read_source_excerpt(source_path, source_lines)
    fresh_hash = compute_content_hash(source_excerpt)

    if fresh_hash == previous_hash:
        response = await client.mark_evidence_current(system_id, evidence_id)
        return {
            "action": "marked_current",
            "evidence_id": evidence_id,
            "content_hash": fresh_hash,
            "response": response,
        }

    source_locator = metadata.get("source_locator")
    if not source_locator and source_lines:
        source_locator = _format_source_lines(source_lines)

    fresh_metadata = build_cli_metadata(
        body=source_excerpt,
        source_uri=str(source_uri),
        source_type=str(metadata.get("source_type") or "repo_file"),
        source_label=metadata.get("source_label") or str(source_uri),
        source_locator=source_locator,
        source_lines=source_lines,
        source_version=metadata.get("source_version"),
        source_excerpt=source_excerpt,
        capture_method="repository_file_read",
    )
    update = EvidenceArtifactUpdate(
        description=description or existing.description or "Updated evidence artifact after source validation",
        artifact_content=(
            artifact_content or _render_validation_artifact(source_excerpt, str(source_uri), source_locator)
        ),
        audit_metadata=fresh_metadata,
        drift_note=drift_note,
    )
    response = await client.update_evidence_artifact(system_id, evidence_id, update)
    return {
        "action": "artifact_updated",
        "evidence_id": evidence_id,
        "previous_content_hash": previous_hash,
        "content_hash": fresh_hash,
        "response": response,
    }


def enrich_evidence_recommendations(
    recommendations: list[dict[str, Any]],
    working_dir: Path,
) -> list[dict[str, Any]]:
    """Validate and enrich code references in a list of evidence recommendations.

    For each recommendation with code_file_path, validates the reference and
    replaces the agent's snippet with the actual file content. Returns the
    modified list (mutates in place for efficiency).
    """
    for rec in recommendations:
        file_path = rec.get("code_file_path")
        if not file_path:
            continue

        validated = validate_code_reference(
            code_file_path=file_path,
            code_line_numbers=rec.get("code_line_numbers"),
            working_dir=working_dir,
        )

        if validated is None:
            # Invalid reference — drop all code fields
            rec.pop("code_file_path", None)
            rec.pop("code_line_numbers", None)
            rec.pop("code_snippet", None)
        else:
            # Replace agent-reported values with validated ones
            rec["code_file_path"] = validated.get("code_file_path")
            if "code_line_numbers" in validated:
                rec["code_line_numbers"] = validated["code_line_numbers"]
            else:
                rec.pop("code_line_numbers", None)
            if "code_snippet" in validated:
                rec["code_snippet"] = validated["code_snippet"]
            else:
                rec.pop("code_snippet", None)

    return recommendations


def _metadata_source_lines(metadata: dict[str, Any]) -> list[int] | None:
    raw = metadata.get("source_lines")
    if isinstance(raw, list) and all(isinstance(item, int) for item in raw):
        return raw
    locator = metadata.get("source_locator")
    return source_lines_from_locator(str(locator)) if locator else None


def _source_uri_to_path(source_uri: str, source_root: Path) -> Path:
    if source_uri.startswith("file://"):
        raw_path = source_uri.removeprefix("file://")
    elif "://" in source_uri:
        raise ValueError(
            f"Cannot re-read source_uri {source_uri!r}; provide a file-backed validation recipe for this source type"
        )
    else:
        raw_path = source_uri

    path = Path(raw_path)
    if not path.is_absolute():
        path = source_root / path
    if not path.is_file():
        raise ValueError(f"Recorded source file does not exist: {path}")
    return path


def _read_source_excerpt(path: Path, source_lines: list[int] | None) -> str:
    text = path.read_text(errors="replace")
    if not source_lines:
        return text
    lines = text.splitlines()
    missing = [line for line in source_lines if line > len(lines)]
    if missing:
        raise ValueError(f"Recorded source lines exceed file length for {path}: {missing[:5]}")
    return "\n".join(lines[line - 1] for line in source_lines)


def _format_source_lines(source_lines: list[int]) -> str:
    if not source_lines:
        return ""
    ordered = sorted(set(source_lines))
    ranges: list[str] = []
    start = prev = ordered[0]
    for line in ordered[1:]:
        if line == prev + 1:
            prev = line
            continue
        ranges.append(str(start) if start == prev else f"{start}-{prev}")
        start = prev = line
    ranges.append(str(start) if start == prev else f"{start}-{prev}")
    return "lines " + ",".join(ranges)


def _render_validation_artifact(source_excerpt: str, source_uri: str, source_locator: str | None) -> str:
    locator = f" ({source_locator})" if source_locator else ""
    return (
        "## Evidence\n\n"
        f"Source validation observed updated source material from `{source_uri}`{locator}.\n\n"
        "```text\n"
        f"{source_excerpt.rstrip()}\n"
        "```\n"
    )


def _parse_line_range(spec: str) -> tuple[int | None, int | None]:
    """Parse a line range like '42-67' into (start, end). Both 1-indexed."""
    spec = spec.strip()
    if "-" in spec:
        parts = spec.split("-", 1)
        try:
            start = int(parts[0].strip())
            end = int(parts[1].strip())
            if start < 1 or end < start:
                return None, None
            return start, end
        except ValueError:
            return None, None
    else:
        try:
            line = int(spec)
            return line, line
        except ValueError:
            return None, None
