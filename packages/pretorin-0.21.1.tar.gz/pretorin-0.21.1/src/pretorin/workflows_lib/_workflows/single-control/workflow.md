---
id: single-control
version: 0.1.0
name: "Single Control Update"
description: "Update one control's narrative, evidence, and notes for one system. Pick this when the user is working on a specific control by id (e.g., 'review AC-2 for system X') and the work fits in one focused pass without iterating across a family or the whole framework."
use_when: "The user names exactly one control id (or a single control is the obvious target). Not for cross-framework work, family rollups, or campaign-style bulk updates."
produces: mixed
iterates_over: single_control
recipes_commonly_used:
  - code-evidence-capture
  - inspec-baseline
  - openscap-baseline
  - cloud-aws-baseline
  - cloud-azure-baseline
  - workspace-capture
  - evidence-narrative-compose
  - manual-attestation
---

# Single Control Update

Update one control's narrative + evidence + notes in one focused pass. The
workflow does not iterate across a family or framework — that's what
`campaign` is for. If the user has a list of controls, route to `campaign`
with a control filter instead.

## Iteration shape

The "iteration" here is degenerate: one item. Do the work below once.

## Step-by-step

0. **Preflight the capture plan.** Before reading files or writing anything,
   inspect the source/recipe plan that `start_task.suggested_capture_plan`
   seeded. If you need fresh detail, call:

   ```
   check_sources(workflow_id="single-control", system_id, framework_id, control_id)
   list_recipes(system_id=system_id)
   ```

   Present the plan to the user: which source kinds are connected, which
   recipes will run, and any `recipe_gap` entries. Proceed only after the
   user confirms the capture plan.

1. **Resolve scope.** Confirm `system_id`, `control_id`, and `framework_id`
   are all set. Any one missing — ask the user. Do not guess.

2. **Read current state before writing.** The platform may already carry a
   narrative / evidence / notes for this control. Don't blindly overwrite.

   ```
   get_control_context(system_id, control_id, framework_id)
   get_narrative(system_id, control_id, framework_id)
   get_control_implementation(system_id, control_id, framework_id)
   search_evidence(system_id, control_id=control_id)
   get_control_notes(system_id, control_id)
   ```

3. **Inspect the workspace.** Look at code, configs, and connected MCP
   sources for observable facts about how this control is implemented.
   Existing platform records are a *starting point*, not proof a gap
   exists. If the workspace shows stronger implementation than the
   platform record, plan to update the narrative to match observed
   reality.

4. **Pick source-eligible recipes for each evidence/narrative artifact.**
   Call `list_recipes(system_id=system_id)` to see only recipes whose
   required sources are connected (or whose source state is unknown on
   older platform deployments). Match each piece of work to a recipe
   whose `use_when` fits:
   - Capturing a config snippet from a source file → `code-evidence-capture`.
   - Capturing a workspace document, runbook, export, or script →
     `workspace-capture`.
   - Running a STIG scan → one of the `*-baseline` recipes.
   - Recording human attestation when no automated check exists →
     `manual-attestation`.
   - No recipe fits → surface the structured `recipe_gap` to the user.
     Do not fall through to direct platform writes.

   **STIG/CCI traceability:** when the control has STIG-testable
   requirements, use `get_cci_chain(nist_control_id, system_id)`
   for the full Control → CCIs → SRGs → STIG rules picture. The catalog
   defines the STIG-to-CCI mapping — there is no per-system assignment
   step. Use `get_cci_implementation` to inspect a single
   impl row, and `link_evidence_to_cci_implementation` /
   `link_evidence_to_stig_rule_workflow` to attach
   remediation/waiver evidence to specific impls or rules.

5. **Run each picked recipe** through the standard lifecycle:
   ```
   start_recipe(recipe_id, recipe_version, params)  → context_id
   recipe_<safe_id>__<script>(...)                  # one or more
   create_evidence(..., recipe_context_id=context_id)
   end_recipe(context_id, status)
   ```

6. **Update the narrative through a narrative-producing recipe.** The
   narrative write must cite evidence ids in scope:

   ```
   start_recipe(recipe_id=<narrative recipe>, evidence_ids=[...]) → context_id
   update_narrative(..., recipe_context_id=context_id, evidence_ids=[...])
   end_recipe(context_id, status)
   ```

7. **Record gaps as control notes.** Anything the workspace + connected
   sources couldn't verify becomes a `add_control_note` entry
   in the standard Gap/Observed/Missing/Why missing/Manual next step
   format.

8. **Resolve superseded notes deliberately.** If an existing open note is
   now addressed by the observed implementation, evidence, or updated
   narrative, call `resolve_control_note` with a concise `resolution_note`
   explaining why it can close. Do not use `content` as the closure
   justification.

## What to avoid

- Don't open a recipe context unless you'll use it. Empty contexts
  create audit-trail noise.
- Don't nest contexts. Close one before opening another (the runtime
  enforces this).
- Don't write evidence or narratives without a `recipe_context_id`. MCP
  agent writes are recipe-context writes.
- Don't fabricate evidence to fill an empty `evidence_recommendations`
  list. An empty list is a valid result *after* you confirmed the
  workspace has nothing.
