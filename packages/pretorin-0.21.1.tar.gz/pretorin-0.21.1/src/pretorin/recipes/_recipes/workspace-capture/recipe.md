---
id: workspace-capture
version: 0.1.0
name: "Workspace Artifact Capture"
description: "Capture any readable workspace file or excerpt as compliance evidence with redaction and provenance, including docs, runbooks, scripts, configs, or generated reports."
use_when: "The auditor needs evidence from a readable file in the active workspace and the artifact is broader than a source-code snippet, such as a runbook, policy draft, exported report, or operational configuration."
produces: evidence
author: "Pretorin Core Team"
license: Apache-2.0
requires:
  sources:
    - kind: workspace_repo
      binding_role: primary
      probe: "git rev-parse --show-toplevel"
      source_version_kind: workspace_revision
params:
  source_path:
    type: string
    description: "Workspace-relative path to the source artifact"
    required: true
  source_locator:
    type: string
    description: "Optional section, selector, page, or line locator inside the artifact"
  source_version:
    type: string
    description: "Optional source version anchor such as a git commit, report id, or generated timestamp"
scripts:
  redact_secrets:
    path: scripts/redact_secrets.py
    description: "Run pretorin's secret redactor over the supplied workspace artifact text."
    params:
      text:
        type: string
        description: "Raw artifact text to scan and redact"
        required: true
  compose_artifact:
    path: scripts/compose_artifact.py
    description: "Compose an auditor-facing Markdown evidence body with provenance for any workspace artifact."
    params:
      content:
        type: string
        description: "Redacted artifact content to embed"
        required: true
      source_path:
        type: string
        description: "Workspace-relative path to the captured artifact"
        required: true
      source_label:
        type: string
        description: "Human-readable artifact label"
      source_locator:
        type: string
        description: "Optional section, selector, page, or line locator"
      source_version:
        type: string
        description: "Optional source version anchor"
      user_prose:
        type: string
        description: "Short explanation of what the artifact demonstrates"
      secrets_redacted:
        type: integer
        description: "Number of secret-shaped values redacted before composition"
        default: 0
---

# Workspace Artifact Capture

Use this recipe when the evidence source is a readable workspace artifact that
is not naturally a source-code excerpt. Examples include Markdown runbooks,
policy drafts, exported reports, shell scripts, YAML configs, or operational
notes checked into the active workspace.

## Procedure

1. Read the source artifact from the workspace.
2. Call `recipe_workspace_capture__redact_secrets(text=<artifact text>)`.
3. Call `recipe_workspace_capture__compose_artifact(...)` with the redacted
   content and provenance fields.
4. Push evidence with `create_evidence(..., recipe_context_id=<context_id>)`.

Use `source_uri` / `source_label` / `source_locator` / `source_excerpt` on the
write call to preserve the same structured provenance carried in the composed
body. Use the most meaningful `source_version` available: git commit for repo
files, report id for generated exports, or capture timestamp when nothing
stronger exists.
