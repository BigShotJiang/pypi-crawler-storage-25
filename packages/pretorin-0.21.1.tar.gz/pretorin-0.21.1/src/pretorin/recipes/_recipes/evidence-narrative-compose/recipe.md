---
id: evidence-narrative-compose
version: 0.1.0
name: "Evidence Narrative Compose"
description: "Compose a control implementation narrative from a supplied set of evidence ids, requiring every material claim to cite at least one linked evidence item."
use_when: "The agent has collected or selected evidence for a control and needs to update the control narrative with explicit evidence citations instead of free-text claims."
produces: narrative
author: "Pretorin Core Team"
license: Apache-2.0
params:
  evidence_ids:
    type: array
    items: { type: string }
    description: "Evidence ids the narrative must cite"
    required: true
---

# Evidence Narrative Compose

Use this recipe after evidence has been collected or selected for a control.
Open the recipe context with the evidence ids in scope:

```
start_recipe(recipe_id="evidence-narrative-compose",
             recipe_version="0.1.0",
             evidence_ids=[...])
```

Compose a concise implementation narrative from only the supplied evidence.
Every material claim must cite at least one evidence id in plain text, for
example: `Access reviews are performed quarterly (evidence: ev-123).`

Submit the narrative through:

```
update_narrative(...,
                 recipe_context_id=<context_id>,
                 evidence_ids=[...])
```

Close the recipe context after the write. If the evidence does not support a
claim, record a control note instead of adding unsupported narrative text.
