"""Source availability helpers for recipe-aware MCP workflows."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from pretorin.client import PretorianClient
from pretorin.client.api import NotFoundError, PretorianClientError
from pretorin.client.models import ConnectedSource
from pretorin.recipes.manifest import RecipeManifest

SourceAvailabilityState = Literal["available", "unknown"]
RecipeAvailabilityState = Literal["available", "unavailable", "unknown"]

_SOURCE_KIND_ALIASES: dict[str, str] = {
    "git_repo": "workspace_repo",
    "github_repo": "workspace_repo",
    "repo": "workspace_repo",
    "repository": "workspace_repo",
    "local_repo": "workspace_repo",
    "aws_identity": "aws_account",
    "azure_identity": "azure_tenant",
    "entra_tenant": "azure_tenant",
    "kubernetes_cluster": "k8s_cluster",
    "kubernetes": "k8s_cluster",
    "k8s_context": "k8s_cluster",
}


def normalize_source_kind(kind: str) -> str:
    """Normalize platform/local aliases to recipe manifest source kinds."""
    value = kind.strip().lower().replace("-", "_")
    return _SOURCE_KIND_ALIASES.get(value, value)


class SourceStatus(BaseModel):
    """MCP-facing source availability row."""

    kind: str
    connected: bool = True
    identifier: str | None = None
    binding_role: str = "primary"
    bound_at: str | None = None
    last_checked: str | None = None
    probe_status: str | None = None
    display_name: str | None = None

    @classmethod
    def from_connected_source(cls, source: ConnectedSource) -> SourceStatus:
        return cls(
            kind=normalize_source_kind(source.kind),
            connected=source.connected,
            identifier=source.identifier,
            binding_role=source.binding_role,
            bound_at=source.bound_at,
            last_checked=source.last_checked,
            probe_status=source.probe_status,
            display_name=source.display_name,
        )


class ConnectedSourcesResult(BaseModel):
    """Result of source discovery with explicit unknown fallback."""

    system_id: str
    availability: SourceAvailabilityState
    sources: list[SourceStatus] = Field(default_factory=list)
    message: str | None = None

    @property
    def connected_kinds(self) -> set[str]:
        return {source.kind for source in self.sources if source.connected}


class RecipeSourceAvailability(BaseModel):
    """Availability summary for one recipe under a source set."""

    status: RecipeAvailabilityState
    required_sources: list[dict[str, Any]] = Field(default_factory=list)
    missing_sources: list[str] = Field(default_factory=list)
    reason: str | None = None


async def fetch_connected_sources(client: PretorianClient, system_id: str) -> ConnectedSourcesResult:
    """Fetch connected sources, returning ``unknown`` for older platform APIs."""
    try:
        sources = await client.list_connected_sources(system_id)
    except NotFoundError as exc:
        return ConnectedSourcesResult(
            system_id=system_id,
            availability="unknown",
            message=f"Connected-source endpoint is not available on this platform deployment: {exc.message}",
        )
    except PretorianClientError as exc:
        if exc.status_code in {404, 501}:
            return ConnectedSourcesResult(
                system_id=system_id,
                availability="unknown",
                message=f"Connected-source endpoint is not available on this platform deployment: {exc.message}",
            )
        raise
    return ConnectedSourcesResult(
        system_id=system_id,
        availability="available",
        sources=[SourceStatus.from_connected_source(source) for source in sources],
    )


def recipe_source_availability(
    manifest: RecipeManifest,
    connected: ConnectedSourcesResult,
) -> RecipeSourceAvailability:
    """Evaluate whether a recipe's source requirements are satisfied."""
    required_sources = [
        {
            "kind": normalize_source_kind(req.kind),
            "binding_role": req.binding_role,
            "probe": req.probe,
            "source_version_kind": req.source_version_kind,
        }
        for req in manifest.requires.sources
    ]
    if not required_sources:
        return RecipeSourceAvailability(status="available", required_sources=[])
    if connected.availability == "unknown":
        return RecipeSourceAvailability(
            status="unknown",
            required_sources=required_sources,
            reason=connected.message or "source availability is unknown",
        )
    missing: list[str] = []
    for req in required_sources:
        kind = req.get("kind")
        if isinstance(kind, str) and kind not in connected.connected_kinds:
            missing.append(kind)
    if missing:
        return RecipeSourceAvailability(
            status="unavailable",
            required_sources=required_sources,
            missing_sources=missing,
            reason=f"missing connected source(s): {', '.join(missing)}",
        )
    return RecipeSourceAvailability(status="available", required_sources=required_sources)


def should_include_recipe(
    availability: RecipeSourceAvailability,
    *,
    include_unavailable: bool,
) -> bool:
    """Return whether a source-filtered list should include this recipe."""
    if availability.status in {"available", "unknown"}:
        return True
    return include_unavailable


__all__ = [
    "ConnectedSourcesResult",
    "RecipeSourceAvailability",
    "SourceStatus",
    "fetch_connected_sources",
    "normalize_source_kind",
    "recipe_source_availability",
    "should_include_recipe",
]
