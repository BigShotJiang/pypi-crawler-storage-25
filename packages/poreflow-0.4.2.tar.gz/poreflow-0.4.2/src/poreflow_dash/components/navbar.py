# notes
"""
This file is for creating a navigation bar that will sit at the top of your application.
Taken from: https://github.com/bradley-erickson/dash-app-structure/blob/main/src/components/navbar.py
Much of this page is pulled directly from the Dash Bootstrap Components documentation linked below:
https://dash-bootstrap-components.opensource.faculty.ai/docs/components/navbar/
"""

# package imports
from dash import html, callback, Output, Input, State
import dash_bootstrap_components as dbc


# component


def navbar(navlinks: list[dbc.NavLink]):
    return dbc.Navbar(
        dbc.Container(
            [
                html.A(
                    dbc.Row(
                        [
                            html.I(
                                className="bi bi-hexagon",
                                style={
                                    "font-size": "2rem",
                                    "color": "black",
                                    "margin": "5px",
                                },
                            ),
                        ],
                        align="center",
                        className="g-0",
                    ),
                    href="https://twhoekstra.github.io/poreFlow-docs/",
                    style={"textDecoration": "none"},
                    className="navbar-brand",
                ),
                dbc.NavbarToggler(
                    id="navbar-toggler", n_clicks=0, className="navbar-toggler"
                ),
                dbc.Collapse(
                    dbc.Nav(navlinks),
                    id="navbar-collapse",
                    className="collapse navbar-collapse",
                ),
            ]
        ),
        className="navbar navbar-expand-lg navbar-light bg-light",
        style={"data-bs-theme": "light"},
        dark=False,
    )


# add callback for toggling the collapse on small screens
@callback(
    Output("navbar-collapse", "is_open"),
    Input("navbar-toggler", "n_clicks"),
    State("navbar-collapse", "is_open"),
)
def toggle_navbar_collapse(n, is_open):
    if n:
        return not is_open
    return is_open
