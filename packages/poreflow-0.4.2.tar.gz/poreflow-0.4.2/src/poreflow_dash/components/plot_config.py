from dash import html
import dash_bootstrap_components as dbc


def create_modal(id, title, children=None, body_id=None):
    """Create a generalized modal."""
    body_content = children if children else html.Div(id=body_id)
    return dbc.Modal(
        [
            dbc.ModalHeader(dbc.ModalTitle(title)),
            dbc.ModalBody(body_content),
            dbc.ModalFooter(
                dbc.Button(
                    "Close", id=f"{id}-close", className="ms-auto", n_clicks=0
                )
            ),
        ],
        id=id,
        is_open=False,
    )
