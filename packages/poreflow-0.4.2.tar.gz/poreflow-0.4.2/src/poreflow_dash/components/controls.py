from dash import (
    dcc,
    html,
    callback,
    Output,
    Input,
    State,
    ctx,
    clientside_callback,
)
import dash_bootstrap_components as dbc

from dash.exceptions import PreventUpdate

import poreflow_dash as pfd


CONTROL_INPUT_STYLE = {"width": "100px"}
DOWNSAMPLE_INPUT_STYLE = {"width": "260px"}
QUALITY_BAR_STYLE = {"width": "200px", "height": "20px"}

# Standard downsample frequency options
STANDARD_DOWNSAMPLE_FREQS = [100, 500, 1000]


def create_navigation_panel(
    prefix,
    show_save=False,
    show_config=False,
    show_info=False,
    show_save_png=False,
):
    """Create a generalized navigation panel."""
    buttons = []
    if show_save:
        buttons += pfd.IconButton(
            "lucide-save",
            "Save Changes",
            id=f"{prefix}-save-btn",
            color="primary",
        )
    if show_config:
        buttons += pfd.IconButton(
            "lucide-settings",
            "Settings",
            id=f"{prefix}-config-btn",
            color="secondary",
        )
    if show_info:
        buttons += pfd.IconButton(
            "lucide-info",
            "Channel info",
            id=f"{prefix}-info-btn",
            color="secondary",
        )
    if show_save_png:
        buttons += pfd.IconButton(
            "lucide-image-down",
            id=f"{prefix}-save-png-btn",
            tooltip_text="Export PNG",
            color="secondary",
        )

    status_span = html.Span(id=f"{prefix}-status", className="secondary")

    return dbc.Row(
        [
            dbc.Col(
                buttons + [status_span],
                width=3,
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    dbc.Row(
                        [
                            dbc.Col(
                                pfd.IconButton(
                                    "lucide-chevron-left",
                                    id=f"{prefix}-prev-btn",
                                    color="secondary",
                                ),
                                width="auto",
                            ),
                            dbc.Col(
                                dcc.Input(
                                    id=f"{prefix}-idx-input",
                                    type="number",
                                    value=0,
                                    min=0,
                                    step=1,
                                    style={"width": "100px"},
                                ),
                                width="auto",
                            ),
                            dbc.Col(
                                pfd.IconButton(
                                    "lucide-chevron-right",
                                    id=f"{prefix}-next-btn",
                                    color="secondary",
                                ),
                                width="auto",
                            ),
                        ],
                        justify="center",
                        className="align-items-center",
                    ),
                ],
                width=6,
            ),
            dbc.Col(width=3),
            dcc.Store(id=f"{prefix}-idx-store", data=0, storage_type="session"),
            dcc.Store(id=f"{prefix}-idx-external", data=None),
        ],
        className="mt-3 align-items-center",
    )


def get_keyboard_store():
    clientside_callback(
        """
        function(id) {
            if (!window.keyListenerAttached) {
                document.addEventListener('keydown', function(e) {
                    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
                    const keys = ['ArrowRight', 'ArrowLeft', ' ', '1', '2', '3', '4', '5', '6', '7'];
                    if (keys.includes(e.key)) {
                        e.preventDefault();
                        dash_clientside.set_props(id, {data: {key: e.key, ts: Date.now()}});
                    }
                });
                window.keyListenerAttached = true;
            }
            return window.dash_clientside.no_update;
        }
        """,
        Output("keyboard-store", "id"),
        Input("keyboard-store", "id"),
    )

    return dcc.Store(id="keyboard-store")


def register_callbacks(prefix):

    @callback(
        Output(f"{prefix}-idx-input", "value"),
        Input(f"{prefix}-idx-input", "value"),
        Input(f"{prefix}-prev-btn", "n_clicks"),
        Input(f"{prefix}-next-btn", "n_clicks"),
        Input("keyboard-store", "data"),
        Input(f"{prefix}-idx-external", "data"),
        State(f"{prefix}-idx-store", "data"),
    )
    def process_navigation(current, prev, next_btn, key_data, external, store):

        if ctx.triggered_id == f"{prefix}-prev-btn":
            new_idx = max(0, current - 1)

        elif ctx.triggered_id == f"{prefix}-next-btn":
            new_idx = current + 1

        elif ctx.triggered_id == "keyboard-store" and key_data:
            key = key_data.get("key")
            if key in ["ArrowRight", " "]:
                new_idx = current + 1
            elif key == "ArrowLeft":
                new_idx = max(0, current - 1)
            else:
                raise PreventUpdate

        elif ctx.triggered_id == f"{prefix}-idx-input":
            raise PreventUpdate  # Already changed

        elif ctx.triggered_id == f"{prefix}-idx-external":
            # On init the idx-external context is called for some reason
            # Defer to store, allows for persistence when switching windows
            if external is None:
                new_idx = store
            else:
                new_idx = external

        else:  # Initial callback call, just load store
            new_idx = store

        return new_idx

    @callback(
        Output(f"{prefix}-idx-store", "data"),
        Input(f"{prefix}-idx-input", "value"),
    )
    def update_store(inp):
        return inp
