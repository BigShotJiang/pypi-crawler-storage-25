from dash import Patch
from plotly_resampler import FigureResampler


def set_plot_limits(
    fig: FigureResampler, config: dict, section: str, row=None, axes="xy"
) -> None:

    for ax, func in zip(["x", "y"], [fig.update_xaxes, fig.update_yaxes]):
        if f"{ax}lim" not in config[section]:
            continue

        autoscale = config[section].get(f"autoscale_{ax}", "fixed")
        if autoscale == "fixed":
            func(range=config[section][f"{ax}lim"], row=row)


def patch_plot_limits(
    patch: Patch, config: dict, config_update: str, suffix="", section_sele=None
) -> Patch:

    section, field = config_update.split(".")

    if section and section != section_sele:
        return patch

    for ax in ["x", "y"]:
        if field not in [f"autoscale_{ax}", f"{ax}lim"]:
            continue

        autoscale = config[section].get(f"autoscale_{ax}", "fixed")

        lim = {
            "range": tuple(config[section][f"{ax}lim"]),
            "autorange": False,
        }

        if autoscale == "auto":
            lim["autorange"] = True
        elif autoscale != "fixed":
            raise ValueError(f"Unknown autoscale_{ax} setting '{autoscale}'")

        patch["layout"][f"{ax}axis{suffix}"] = lim

    return patch
