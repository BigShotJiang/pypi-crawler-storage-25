import dash_bootstrap_components as dbc
from dash import Output, Input, State, MATCH, dcc
from dash_iconify import DashIconify


def IconButton(
    icon,
    tooltip_text: str = False,
    id="button",
    color="link",
    tooltip_placement="top",
    width=25,
    className=None,
    border=False,
    **kwargs,
):
    """
    Creates a clean, icon-only button with an associated tooltip.
    """
    if id == "button":
        raise ValueError("Please specify an id")

    return [
        dbc.Button(
            DashIconify(icon=icon, width=width),
            id=id,
            color=color,
            className=get_btn_class_name(border, className),
            **kwargs,
        ),
        dbc.Tooltip(
            tooltip_text,
            target=id,
            placement=tooltip_placement,
            className=className,
        )
        if tooltip_text
        else None,
    ]


def get_btn_class_name(border: bool, className) -> str:
    btn_class_name = f"icon-btn p-1{'' if border else ' border-0'} shadow-none"

    if className is not None:
        btn_class_name = f"{btn_class_name} {className}"
    return btn_class_name


def ToggleIconButton(
    id,
    icon_off,
    icon_on,
    tooltip_off,
    tooltip_on,
    color="link",
    tooltip_placement="top",
    width=25,
    className=None,
    border=False,
    **kwargs,
):
    """
    Returns a button and tooltip. The callback will handle swapping
    the icon_off/icon_on and tooltip_off/tooltip_on.
    """
    return [
        dbc.Button(
            DashIconify(
                icon=icon_off, width=width, id={"type": "btn-icon", "index": id}
            ),
            id={"type": "btn-trigger", "index": id},
            color=color,
            className=get_btn_class_name(border, className),
            n_clicks=0,
            **kwargs,
        ),
        dbc.Tooltip(
            tooltip_off,
            id={"type": "btn-tooltip", "index": id},
            target={"type": "btn-trigger", "index": id},
            placement=tooltip_placement,
            className=className,
        ),
        dcc.Store(
            id={"type": "btn-state", "index": id},
            data=False,
        ),
        dcc.Store(
            id={"type": "btn-data", "index": id},
            data={
                "off_icon": icon_off,
                "on_icon": icon_on or icon_off,
                "off_text": tooltip_off,
                "on_text": tooltip_on or tooltip_off,
            },
        ),
    ]


def register_icon_button_callbacks(app):

    @app.callback(
        Output({"type": "btn-icon", "index": MATCH}, "icon"),
        Output({"type": "btn-tooltip", "index": MATCH}, "children"),
        Output({"type": "btn-state", "index": MATCH}, "data"),
        Input({"type": "btn-trigger", "index": MATCH}, "n_clicks"),
        State({"type": "btn-data", "index": MATCH}, "data"),
        prevent_initial_call=True,
    )
    def handle_icon_click(n_clicks, data):

        is_on = n_clicks & 1

        # Extract values from the 'data' dictionary we attached in __init__
        icon = data["on_icon"] if is_on else data["off_icon"]
        text = data["on_text"] if is_on else data["off_text"]

        return icon, text, is_on
