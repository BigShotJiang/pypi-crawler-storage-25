# notes
"""
This file is for creating a simple footer element.
This component will sit at the bottom of each page of the application.
Taken from: https://github.com/bradley-erickson/dash-app-structure/blob/main/src/components/footer.py
"""

from dash import html
import dash_bootstrap_components as dbc

footer = html.Footer(
    dbc.Container(
        [
            html.Hr(),
            "poreFlow Dashboard",
        ]
    ),
    id="footer",
    style=dict(
        position="fixed",
        left=0,
        bottom=0,
        width="100%",
    ),
)
