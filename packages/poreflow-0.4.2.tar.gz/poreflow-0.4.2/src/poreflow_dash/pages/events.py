"""Labeler page for Poreflow dashboard."""

import json

import dash
from dash import (
    dcc,
    html,
    Input,
    Output,
    State,
    callback,
    ctx,
    Patch,
)
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash.exceptions import PreventUpdate

import poreflow as pf
import poreflow_dash as pfd
from poreflow_dash.components.figure import patch_plot_limits, set_plot_limits
from poreflow_dash.components.plot_config import create_modal
from poreflow_dash.components import controls
from poreflow_dash.schema import create_form

dash.register_page(__name__, path=pfd.EVENTS_PAGE_NAME, title="Events")

# --- Constants & Data Structures ---

DEFAULT_CURRENT_RANGE = [0, 300]  # pA

# --- Layout Components ---

BASE_LABEL_BTN_STYLE = {
    "margin": "5px",
    "transition": "all 0.2s ease-in-out",
}

STEPS_KWARGS = dict(
    mode="lines",
    line=dict(color="black", width=2, shape="hv"),
    name="Steps",
    showlegend=False,
)


def create_top_controls():
    """Create the top row of controls: Steps toggle, Downsampling, and Quality."""
    return dbc.Row(
        [
            dbc.Col(
                [
                    html.Label("Filter cutoff (Hz)", className="me-2 mb-0"),
                    dcc.Dropdown(
                        id="events-filter-hz",
                        options=[],
                        clearable=True,
                        placeholder="None",
                        style={"width": "140px"},
                    ),
                    dbc.Tooltip(
                        pfd.ConfigSchema.get_field_description(
                            "input", "filter_freq"
                        ),
                        target="events-filter-hz",
                        placement="right",
                    ),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    html.Div(style={"width": "50px"}),  # Add spacing
                    html.Div(
                        [
                            html.Div(
                                [
                                    # *pfd.IconButton(
                                    #     "lucide-search",
                                    #     id="events-find-steps",
                                    #     tooltip_text="Find steps",
                                    #     color="secondary",
                                    # ),
                                    # *pfd.IconButton(
                                    #     "lucide-rotate-ccw",
                                    #     id="events-reset-steps",
                                    #     tooltip_text="Reset steps",
                                    #     color="secondary",
                                    # ),
                                    *pfd.ToggleIconButton(
                                        id="events-show-steps",
                                        icon_off="lucide-eye",
                                        icon_on="lucide-eye-closed",
                                        tooltip_off="Show steps",
                                        tooltip_on="Hide steps",
                                        color="secondary",
                                    ),
                                ],
                                className="d-flex align-items-center pb-1 border-bottom border-2",
                            ),
                            html.P("Steps", className="text-muted mt-1 mb-0"),
                        ],
                        className="d-flex flex-column align-items-start",
                    ),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    html.Label("Quality", className="me-2"),
                    dbc.Progress(
                        id="quality-bar",
                        value=0,
                        style=controls.QUALITY_BAR_STYLE,
                    ),
                    html.Small(id="quality-text", className="ms-2"),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
        ],
        className="mb-3 align-items-start justify-content-between",
    )


def _range_row(label, id_prefix, defaults, step="any"):
    """Create a row with [min, max] inputs and an Auto checkbox."""
    return dbc.Row(
        [
            dbc.Label(label, width=4),
            dbc.Col(
                dbc.InputGroup(
                    [
                        dbc.Input(
                            id=f"{id_prefix}-min",
                            type="number",
                            value=defaults[0],
                            step=step,
                            size="sm",
                        ),
                        dbc.Input(
                            id=f"{id_prefix}-max",
                            type="number",
                            value=defaults[1],
                            step=step,
                            size="sm",
                        ),
                        dbc.InputGroupText(
                            dbc.Checkbox(
                                id=f"{id_prefix}-auto",
                                label="Auto",
                                value=False,
                            ),
                        ),
                    ],
                    size="sm",
                ),
                width=8,
            ),
        ],
        className="mb-2 align-items-center",
    )


def create_events_config(config):
    """Create the events plot settings form content."""
    include = [
        "events_page.*",
    ]

    if pfd.is_no_file(config):
        return html.Div()
    else:
        # Create the form with only the plot fields we want to show, using list layout
        return create_form(
            pfd.ConfigSchema,
            config,
            include=include,
            layout="list",
        )


def create_labeling_buttons():
    """Create the row of labeling buttons."""
    return html.Div(
        [
            dbc.Button(
                f"{j} ({label.name})",
                id={"type": "label-btn", "index": j},
                style={**BASE_LABEL_BTN_STYLE, "background-color": label.color},
            )
            for j, label in enumerate(pfd.DEFAULT_LABELS)
        ],
        id="label-buttons-container",
        className="mt-4 d-flex justify-content-center flex-wrap",
    )


layout = html.Div(
    [
        dbc.Row(
            dbc.Col(
                [
                    html.H5(
                        "Loading...",
                        id="events-filename",
                        className="text-center mb-3",
                    ),
                    create_top_controls(),
                    dcc.Graph(
                        id="events-graph", config={"displayModeBar": True}
                    ),
                    controls.create_navigation_panel(
                        prefix="events",
                        show_save=True,
                        show_config=True,
                        show_info=True,
                    ),
                    create_labeling_buttons(),
                    html.P(
                        "Shortcuts: Left/Right Arrow for navigation, 1-7 for labels, Space for Next.",
                        className="text-muted text-center mt-3",
                    ),
                ],
                width=12,
            )
        ),
        # Stores
        dcc.Store(id="events-label-store"),
        dcc.Store(id="events-next-event-label"),
        dcc.Store(id="events-new-label-assignment"),
        dcc.Store(
            id="events-pending-changes-store", data={}, storage_type="session"
        ),
        dcc.Store(
            id="events-properties-store", data={}, storage_type="session"
        ),
        dcc.Interval(
            id="events-status-clear-interval", interval=3000, disabled=True
        ),
        # Plot config modal - structure is pre-created, content is updated dynamically
        dbc.Modal(
            [
                dbc.ModalHeader(dbc.ModalTitle("Event Plot Configuration")),
                dbc.ModalBody(html.Div(id="events-plot-config-content")),
                dbc.ModalFooter(
                    dbc.Button(
                        "Close",
                        id="events-config-modal-close",
                        className="ms-auto",
                        n_clicks=0,
                    )
                ),
            ],
            id="events-config-modal",
            is_open=False,
        ),
        create_modal(
            id="events-info-modal",
            title="Event Info",
            body_id="event-info-modal-body",
        ),
    ]
)

controls.register_callbacks("events")


def get_title(idx: int, label: int, pending: bool = False):
    return f"Event {idx} (Label: {label}{'*' if pending else ''})"


# --- Plotting Logic ---


def draw_figure(
    event,
    idx,
    label,
    has_steps,
    show_steps,
    pending_changes,
    f=None,
    absolute=True,
):
    """Generate the Plotly figure for a specific event."""
    t = event.get_t(absolute=absolute)
    i = event[pf.CURRENT_COL].values
    color = pfd.DEFAULT_LABELS[min(label, len(pfd.DEFAULT_LABELS) - 1)].color

    fig = go.Figure()

    # Raw Data Trace
    opacity = 0.3 if show_steps else 1.0
    fig.add_trace(
        go.Scatter(
            x=t,
            y=i,
            line=dict(color=color, width=1),
            opacity=opacity,
            mode="lines",
            showlegend=False,
            name="Raw Data",
        )
    )

    # Steps Trace
    if show_steps and has_steps and f is not None:
        try:
            steps = f.get_steps(event=idx)
            if not steps.empty:
                if not steps.has_times:
                    steps.calculate_times()
                fig.add_trace(
                    go.Scatter(
                        x=steps[pf.START_TIME_COL] + event.start_time,
                        y=steps[pf.MEAN_COL],
                        **STEPS_KWARGS,
                    )
                )
        except Exception:
            pass

    fig.add_hline(
        y=event.ios,
        line_dash="dash",
        line_color="gray",
        annotation_text="IOS",
        annotation_position="top right",
    )

    # Layout
    title = get_title(idx, label, pending=str(idx) in pending_changes)
    fig.update_layout(
        title=title,
        xaxis_title="Time (s)",
        yaxis_title="I (pA)",
        template="plotly_white",
        margin=dict(l=40, r=40, t=60, b=40),
        hovermode="closest",
    )

    return fig


# --- Callbacks ---


@callback(
    Output("events-graph", "figure", allow_duplicate=True),
    Output("events-properties-store", "data"),
    Output("events-filename", "children"),
    Input("events-idx-store", "data"),
    Input("events-filter-hz", "value"),
    State({"type": "btn-state", "index": "events-show-steps"}, "data"),
    State("config-store", "data"),
    State("events-pending-changes-store", "data"),
    prevent_initial_call=True,
)
def create_plot(idx, filter, show_steps, config, pending_changes):
    if pfd.is_no_file(config):
        return text_in_figure(""), {}, "No file loaded"

    f = pfd.get_handle(config)

    if not f.has_events:
        return text_in_figure(""), {}, "File has no events"

    num_events = len(f.get_events())
    if idx >= num_events:
        return text_in_figure("File has no more events"), {}, ""

    downsample = config["input"]["resample_to_freq"]
    event = f.get_event(idx).downsample(downsample).apply_filter(filter)

    label = pending_changes.get(str(idx), event.label)

    absolute = config["events_page"]["x_start"] == "abs"

    fig = draw_figure(
        event,
        idx,
        label,
        f.has_steps,
        show_steps,
        pending_changes,
        f=f,
        absolute=absolute,
    )

    set_plot_limits(fig, config, "events_page")

    quality = getattr(event, "quality", 0)

    # Prepare properties
    ios = getattr(event, "ios", "N/A")

    properties = {
        "quality": quality,
        "label": label,
        "has_steps": f.has_steps,
        "channel": getattr(event, "channel", "N/A"),
        "ios": ios,
        "n_samples": len(event),
        "duration": getattr(event, "duration", len(event) / event.sfreq),
        "start_time": event.start_idx / event.sfreq,
    }

    return fig, properties, config["input"]["name"]


def text_in_figure(s: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=s,
        x=0.5,
        y=0.5,
        showarrow=False,
        font=dict(size=16),
    )
    fig.update_layout(
        template="plotly_white"
    )
    return fig


@callback(
    Output("quality-bar", "value"),
    Output("quality-text", "children"),
    Output("events-next-event-label", "data"),
    Output("event-info-modal-body", "children"),
    Input("events-properties-store", "data"),
)
def update_event_info(props):
    """Update UI components when properties store changes."""
    if not props:
        return 0, "No data", None, "No data available."

    quality = props.get("quality", 0)
    label = props.get("label", None)
    has_steps = props.get("has_steps", False)

    # Info panel content
    info_items = [
        ("Channel", props.get("channel")),
        (
            "Open State Current (pA)",
            f"{props.get('ios'):.1f}"
            if isinstance(props.get("ios"), (int, float))
            else props.get("ios"),
        ),
        ("Samples", props.get("n_samples")),
        (
            "Duration (s)",
            f"{props.get('duration'):.2f}"
            if isinstance(props.get("duration"), float)
            else props.get("duration"),
        ),
        (
            "Start Time (s)",
            f"{props.get('start_time'):.2f}"
            if isinstance(props.get("start_time"), float)
            else props.get("start_time"),
        ),
    ]

    info_body = html.Table(
        [
            html.Tr(
                [html.Th(k, style={"padding-right": "20px"}), html.Td(str(v))]
            )
            for k, v in info_items
        ],
        className="table table-sm table-borderless",
    )

    return quality * 100, f"{quality:.2f}", label, info_body


@callback(
    Output("events-graph", "figure", allow_duplicate=True),
    Input({"type": "btn-state", "index": "events-show-steps"}, "data"),
    State("events-idx-store", "data"),
    State("config-store", "data"),
    State("events-properties-store", "data"),
    prevent_initial_call=True,
)
def update_plot_step_visibility(show_steps, event_idx, config, properties):
    """Toggle steps visibility using Patch to preserve zoom/pan state."""

    if pfd.is_no_file(config):
        raise PreventUpdate

    f = pfd.get_handle(config)

    if not f.has_events:
        raise PreventUpdate

    patch = Patch()

    steps = f.get_steps(event=event_idx)
    has_steps = not steps.empty

    start_time = properties.get("start_time", 0) if properties else 0

    if show_steps:
        if has_steps:
            steps.ensure_times()

            patch["data"][1] = {
                "x": steps[pf.START_TIME_COL] + start_time,
                "y": steps[pf.MEAN_COL],
                **STEPS_KWARGS,
            }

        patch["data"][0]["opacity"] = 0.3

    else:
        if has_steps:
            patch["data"][1].clear()
        patch["data"][0]["opacity"] = 1.0

    return patch


@callback(
    Output("events-label-store", "data"),
    Output("events-pending-changes-store", "data"),
    Input("events-next-event-label", "data"),
    Input("events-new-label-assignment", "data"),
    State("events-idx-store", "data"),
    State("events-pending-changes-store", "data"),
)
def update_labels_on_new_event_or_assignment(
    label_from_event, label_from_button, current_idx, pending_changes
):
    if ctx.triggered_id == "events-next-event-label":
        return label_from_event, pending_changes
    if (
        ctx.triggered_id == "events-new-label-assignment"
        and label_from_button is not None
    ):
        new_pending = pending_changes.copy()
        new_pending[str(current_idx)] = label_from_button
        return label_from_button, new_pending
    raise PreventUpdate


@callback(
    Output("events-status", "children"),
    Output("events-pending-changes-store", "data", allow_duplicate=True),
    Output("events-status-clear-interval", "disabled"),
    Input("event-save-btn", "n_clicks"),
    State("config-store", "data"),
    State("events-pending-changes-store", "data"),
    prevent_initial_call=True,
)
def save_labels(n_clicks, config, pending_changes):
    if not n_clicks or not pending_changes:
        return dash.no_update, dash.no_update, True
    try:
        f = pfd.get_handle(config)
        events = f.get_events()
        for idx_str, label in pending_changes.items():
            events.loc[int(idx_str), pf.LABEL_COL] = label
        f.set_events(events)
        return "Saved!", {}, False
    except Exception as e:
        return f"Error: {str(e)}", pending_changes, False


@callback(
    Output("events-new-label-assignment", "data"),
    Input({"type": "label-btn", "index": dash.ALL}, "n_clicks"),
    Input("keyboard-store", "data"),
)
def get_new_label_from_keypress(btn_clicks, key_data):
    if not ctx.triggered:
        raise PreventUpdate
    trigger_id_str = ctx.triggered[0]["prop_id"].split(".")[0]
    if trigger_id_str.startswith("{"):
        return json.loads(trigger_id_str)["index"]
    if trigger_id_str == "keyboard-store" and key_data:
        key = key_data.get("key")
        if key.isdigit():
            return int(key)
    raise PreventUpdate


# --- Simple Utilities & Styling ---


@callback(
    Output({"type": "label-btn", "index": dash.ALL}, "style"),
    Input("events-label-store", "data"),
)
def update_button_on_new_label(selected_label):
    styles = []
    for j, label in enumerate(pfd.DEFAULT_LABELS):
        style = {**BASE_LABEL_BTN_STYLE, "background-color": label.color}
        if j == selected_label:
            style["transform"] = "scale(1.15)"
            style["z-index"] = "10"
        else:
            style["opacity"] = "0.7"
        styles.append(style)
    return styles


FILTER_HZ_OPTIONS = [50, 100, 200, 500, 1000, 2000, 5000, 10000]


@callback(
    Output("events-filter-hz", "options"),
    Output("events-filter-hz", "value"),
    Input("config-store", "data"),
)
def update_filter_options(config):
    if pfd.is_no_file(config):
        return [], None

    f = pfd.get_handle(config)
    nyquist = f.sfreq / 2
    options = [
        {"label": f"{hz} Hz", "value": hz}
        for hz in FILTER_HZ_OPTIONS
        if hz < nyquist
    ]
    default = config["plot"].get("events_filter_freq", 1000.0)
    value = default if any(o["value"] == default for o in options) else None
    return options, value


@callback(
    Output("events-config-modal", "is_open"),
    Output("events-plot-config-content", "children"),
    Input("events-config-btn", "n_clicks"),
    Input("events-config-modal-close", "n_clicks"),
    State("events-config-modal", "is_open"),
    State("config-store", "data"),
)
def toggle_settings_modal(n1, n2, is_open, config):
    if n1 or n2:
        # When opening the modal, create the config content
        if not is_open:
            config_content = create_events_config(config)
            return True, config_content
        else:
            # When closing, just toggle the modal state
            return False, dash.no_update
    return is_open, dash.no_update


@callback(
    Output("events-info-modal", "is_open"),
    Input("events-info-btn", "n_clicks"),
    Input("events-info-modal-close", "n_clicks"),
    State("events-info-modal", "is_open"),
)
def toggle_info_modal(n1, n2, is_open):
    return not is_open if n1 or n2 else is_open


@callback(
    Output("events-status", "children", allow_duplicate=True),
    Output("events-status-clear-interval", "disabled", allow_duplicate=True),
    Input("events-status-clear-interval", "n_intervals"),
    prevent_initial_call=True,
)
def clear_status(_):
    return "", True


@callback(
    Output("events-graph", "figure", allow_duplicate=True),
    Input("events-new-label-assignment", "data"),
    State("events-idx-store", "data"),
    prevent_initial_call=True,
)
def update_plot_color(label_idx, event_idx):
    if label_idx is None:
        raise PreventUpdate
    patch = Patch()
    patch["data"][0]["line"]["color"] = pfd.DEFAULT_LABELS[label_idx].color
    patch["layout"]["title"]["text"] = get_title(
        event_idx, label_idx, pending=True
    )

    return patch


@callback(
    Output("events-graph", "figure", allow_duplicate=True),
    Input("events-status", "children"),
    State("events-label-store", "data"),
    State("events-idx-store", "data"),
    prevent_initial_call=True,
)
def remove_asterisk(status, label_idx, event_idx):
    if "Error" in status:
        raise PreventUpdate
    patch = Patch()
    patch["layout"]["title"]["text"] = get_title(
        event_idx, label_idx, pending=False
    )
    return patch


@callback(
    Output("events-graph", "figure", allow_duplicate=True),
    Input("config-update", "data"),
    State("config-store", "data"),
    State("events-graph", "figure"),
    prevent_initial_call=True,
)
def update_plot_limits(config_update, config, figure):
    """Update the event plot y-axis range using Patch to preserve zoom/pan state."""
    if figure is None:
        raise PreventUpdate

    patch = Patch()

    patch_plot_limits(patch, config, config_update)

    return patch


@callback(
    Output("events-idx-external", "data"),
    Input("url", "search"),
    prevent_initial_call="initial_duplicate",
)
def set_event_from_url(search):
    """Set event index from URL query parameters."""
    # Parse query parameters from search string (format: "?event_idx=123")
    params = {}

    if search.startswith("?"):
        search = search[1:]  # Remove leading ?
        for param in search.split("&"):
            if "=" in param:
                key, value = param.split("=", 1)
                params[key] = value

    event_idx = params.get("event_idx")

    if event_idx and event_idx.isdigit():
        return int(event_idx)
    else:
        raise PreventUpdate
