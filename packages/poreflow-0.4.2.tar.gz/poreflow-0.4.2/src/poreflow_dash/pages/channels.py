"""Channels page for Poreflow dashboard."""

import pandas as pd
import numpy as np
import dash
from dash.exceptions import PreventUpdate
from dash import (
    dcc,
    html,
    Input,
    Output,
    State,
    callback,
    ctx,
    Patch,
    clientside_callback,
)
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from plotly_resampler import FigureResampler
from plotly_resampler.aggregation import MinMaxLTTB

import poreflow as pf

import poreflow_dash as pfd
from poreflow_dash.components import controls
from poreflow_dash.components.figure import set_plot_limits, patch_plot_limits
from poreflow_dash.components.plot_config import create_modal
from poreflow_dash.schema import create_form

VERTICAL_SPACING = 0.05

HEIGHTS = [0.3, 0.7]
HEIGHTS_NO_VOLTAGE = [0.0, 1.0]



NA = "N/a"
DEFAULT_FILTER_CUTOFF_HZ = 1000

dash.register_page(__name__, path="/channels", title="Channels")


def create_top_controls():
    """Create the top row of controls: Show Events, Raw Downsample, and Event Downsample."""
    return dbc.Row(
        [
            dbc.Col(
                [
                    html.Label(
                        ["Filter cutoff (Hz)"],
                        className="me-2 mb-0",
                    ),
                    dcc.Dropdown(
                        id="channels-filter-cutoff-hz",
                        options=[
                            {"label": "None", "value": 0},
                            {"label": "50 Hz", "value": 50},
                            {"label": "100 Hz", "value": 100},
                            {"label": "200 Hz", "value": 200},
                            {"label": "500 Hz", "value": 500},
                            {"label": "1000 Hz", "value": 1000},
                            {"label": "2000 Hz", "value": 2000},
                            {"label": "5000 Hz", "value": 5000},
                            {"label": "10000 Hz", "value": 10000},
                        ],
                        value=DEFAULT_FILTER_CUTOFF_HZ,
                        clearable=False,
                        style={"width": "120px"},
                    ),
                    dbc.Tooltip(
                        "Bessel lowpass filter cutoff frequency in Hz. Applied to the raw signal before display. Does not affect the underlying data.",
                        target="channels-filter-cutoff-hz",
                        placement="right",
                    ),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    html.Div(style={"width": "50px"}),  # Add spacing
                    html.Div(
                        [
                            html.Div(
                                [
                                    *pfd.ToggleIconButton(
                                        id="channels-show-events",
                                        icon_off="lucide-eye",
                                        icon_on="lucide-eye-closed",
                                        tooltip_off="Show events",
                                        tooltip_on="Hide events",
                                        color="secondary",
                                    ),
                                    html.Div(style={"width": "10px"}),
                                    *pfd.IconButton(
                                        "lucide-search",
                                        id="channels-find-events",
                                        tooltip_text="Find events",
                                        color="secondary",
                                    ),
                                    # *pfd.IconButton(
                                    #     "lucide-filter",
                                    #     id="channels-filter-events",
                                    #     tooltip_text="Filter events",
                                    #     color="secondary",
                                    # ),
                                    html.Div(style={"width": "10px"}),
                                    *pfd.IconButton(
                                        "lucide-scissors",
                                        id="channels-reset-events",
                                        tooltip_text="Remove events in this channel",
                                        color="secondary",
                                    ),
                                    *pfd.IconButton(
                                        "lucide-trash",
                                        id="channels-reset-events-all",
                                        tooltip_text="Remove events in all channels",
                                        color="secondary",
                                    ),
                                    html.Div(style={"width": "10px"}),
                                    html.Label(
                                        "Filter freq. (Hz)",
                                        className="me-2 mb-0 ms-3",
                                    ),
                                    dbc.Input(
                                        id="channels-event-filter-hz",
                                        type="number",
                                        value=1000,
                                        min=1,
                                        step="any",
                                        list="channels-event-downsample-list",
                                        disabled=True,  # Initially disabled
                                        style={"width": "120px"},
                                    ),
                                    html.Datalist(
                                        id="channels-event-downsample-list"
                                    ),
                                    dbc.Tooltip(
                                        pfd.ConfigSchema.get_field_description(
                                            "input", "filter_freq"
                                        ),
                                        target="channels-event-filter-hz",
                                        placement="right",
                                    ),
                                ],
                                className="d-flex align-items-center pb-1 border-bottom border-2",
                            ),
                            html.P("Events", className="text-muted mt-1 mb-0"),
                        ],
                        className="d-flex flex-column align-items-start",
                    ),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
        ],
        className="mb-3 align-items-start",
    )


def create_plot_config(config):
    """Create the channel plot settings form content."""

    # Define which fields to show in the plot config modal
    include = [
        "channels_voltage_page.*",
        "channels_page.*",
    ]

    if pfd.is_no_file(config):
        return html.Div()
    else:
        # Create the form with only the plot fields we want to show, using list layout
        return create_form(
            pfd.ConfigSchema,
            config,
            include=include,
            layout="list",
        )


layout = html.Div(
    [
        dbc.Row(
            dbc.Col(
                [
                    create_top_controls(),
                    dcc.Loading(
                        dcc.Graph(
                            id="channels-graph",
                            config={
                                "displayModeBar": True,
                                "modeBarButtonsToRemove": ["toImage"],
                            },
                        ),
                        overlay_style={
                            "visibility": "visible",
                            "opacity": 0.4,
                        },
                        custom_spinner=dbc.Spinner(
                            color="dark",
                            spinnerClassName="spinner",
                        ),
                    ),
                    html.Small(
                        "",
                        id="channels-display-rate",
                        className="text-muted d-block text-end mb-1",
                    ),
                    controls.create_navigation_panel(
                        prefix="channels",
                        show_config=True,
                        show_info=True,
                        show_save_png=True,
                    ),
                ],
                width=12,
            )
        ),
        # Stores
        dcc.Store(id="channels-find-events-trigger"),
        # Downsample datalists
        html.Datalist(id="channels-event-downsample-list"),
        # Plot config modal - structure is pre-created, content is updated dynamically
        dbc.Modal(
            [
                dbc.ModalHeader(dbc.ModalTitle("Channel Plot Configuration")),
                dbc.ModalBody(html.Div(id="channels-plot-config-content")),
                dbc.ModalFooter(
                    dbc.Button(
                        "Close",
                        id="channels-config-modal-close",
                        className="ms-auto",
                        n_clicks=0,
                    )
                ),
            ],
            id="channels-config-modal",
            is_open=False,
        ),
        create_modal(
            id="channels-info-modal",
            title="Channel Info",
            body_id="channels-info-modal-body",
        ),
        dbc.Modal(
            [
                dbc.ModalHeader(dbc.ModalTitle("Find Events")),
                dbc.ModalBody(
                    dcc.Loading(
                        html.Div(id="channels-find-events-modal-body"),
                        overlay_style={"visibility": "visible", "opacity": 0.6},
                        custom_spinner=html.Span(
                            "Finding events...",
                            className="text-muted fst-italic",
                        ),
                    )
                ),
                dbc.ModalFooter(
                    dbc.Button(
                        "Close",
                        id="channels-find-events-modal-close",
                        className="ms-auto",
                        n_clicks=0,
                    )
                ),
            ],
            id="channels-find-events-modal",
            is_open=False,
        ),
        dbc.Modal(
            [
                dbc.ModalHeader(dbc.ModalTitle("Export PNG")),
                dbc.ModalBody(
                    [
                        dbc.Row(
                            [
                                dbc.Label("Filename", width=3),
                                dbc.Col(
                                    dbc.InputGroup(
                                        [
                                            dbc.Input(
                                                id="channels-save-png-filename",
                                                type="text",
                                                placeholder="channel_plot",
                                                debounce=False,
                                            ),
                                            dbc.InputGroupText(".png"),
                                        ]
                                    ),
                                    width=9,
                                ),
                            ],
                            className="mb-3 align-items-center",
                        ),
                        dbc.Row(
                            [
                                dbc.Label("Metadata", width=3),
                                dbc.Col(
                                    dbc.Textarea(
                                        id="channels-save-png-metadata",
                                        placeholder="Optional notes embedded in the image as an annotation (e.g. sample ID, conditions, date)…",
                                        rows=3,
                                        style={
                                            "resize": "vertical",
                                            "fontSize": "0.85rem",
                                        },
                                    ),
                                    width=9,
                                ),
                            ],
                            className="mb-1 align-items-start",
                        ),
                    ]
                ),
                dbc.ModalFooter(
                    dbc.Row(
                        [
                            dbc.Col(
                                dbc.Button(
                                    "Cancel",
                                    id="channels-save-png-modal-close",
                                    color="secondary",
                                    className="w-100",
                                    n_clicks=0,
                                ),
                                width=6,
                            ),
                            dbc.Col(
                                dbc.Button(
                                    "Download PNG",
                                    id="channels-save-png-download-btn",
                                    color="primary",
                                    className="w-100",
                                    n_clicks=0,
                                ),
                                width=6,
                            ),
                        ],
                        className="g-2 w-100",
                    )
                ),
            ],
            id="channels-save-png-modal",
            is_open=False,
            size="md",
        ),
        dcc.Store(id="channels-save-png-dummy"),
        dbc.Modal(
            [
                dbc.ModalHeader(dbc.ModalTitle("Warning")),
                dbc.ModalBody(
                    html.Div(
                        [
                            html.P(
                                "Are you sure you want to clear ALL events?",
                                className="text-danger fw-bold",
                            ),
                            html.P(
                                "This action cannot be undone.",
                                className="text-muted",
                            ),
                        ],
                        id="channels-reset-all-confirm-modal-body",
                    )
                ),
                dbc.ModalFooter(
                    dbc.Row(
                        [
                            dbc.Col(
                                dbc.Button(
                                    "Cancel",
                                    id="channels-reset-all-cancel",
                                    className="w-100",
                                    color="secondary",
                                ),
                                width=6,
                            ),
                            dbc.Col(
                                dbc.Button(
                                    "Delete",
                                    id="channels-reset-all-confirm",
                                    className="w-100",
                                    color="danger",
                                ),
                                width=6,
                            ),
                        ],
                        className="g-2",
                    )
                ),
            ],
            id="channels-reset-all-confirm-modal",
            is_open=False,
        ),
    ]
)

controls.register_callbacks("channels")

# Server-side store for the FigureResampler object.
# Safe for single-user local apps (poreflow runs on localhost).
_current_fig_resampler: FigureResampler | None = None
_current_sfreq: float = 0  # Original sampling frequency of the displayed trace
_current_n_samples: int = 0  # Total number of samples in the displayed trace
N_SHOWN_SAMPLES = 10000  # Number of samples plotly-resampler displays per view


def is_show_voltage(config: dict) -> bool:
    return config["channels_voltage_page"]["show_voltage"]


def _format_display_rate(x_min: float, x_max: float) -> str:
    """Format the display rate string based on the current view range."""
    duration = x_max - x_min
    if duration <= 0:
        return ""
    n_original = int(duration * _current_sfreq)
    if n_original <= N_SHOWN_SAMPLES:
        return [
            "Displaying all ",
            f"{n_original:,} pts",
            html.Br(),
            f"raw ({_current_sfreq:,.0f} Hz)",
        ]
    effective_rate = N_SHOWN_SAMPLES / duration
    return [
        f"Displaying {N_SHOWN_SAMPLES:,} of {n_original:,} pts",
        html.Br(),
        f"effective ({effective_rate:,.1f} Hz with main features)",
    ]


def draw_figure(
    f: pf.File,
    channel_num,
    filter_cutoff,
    events_downsample,
    show_events,
    show_voltage,
):
    """Create a new channel figure with the given settings.

    Used when going to the next channel.
    Uses plotly-resampler for efficient rendering of large traces.
    The filter_cutoff (Hz) applies a Bessel lowpass filter before display,
    letting the user inspect features at a chosen frequency scale.
    """
    global _current_fig_resampler, _current_sfreq, _current_n_samples

    raw = f.get_raw(channel=channel_num)

    # Apply lowpass filter if requested (without decimation)
    if filter_cutoff and filter_cutoff < raw.get_nyquist():
        raw = raw.apply_filter(filter_cutoff)

    _current_sfreq = raw.sfreq
    _current_n_samples = len(raw)

    # Always create 2-row subplot layout
    # Adjust row heights based on show_voltage setting
    if show_voltage:
        row_heights = HEIGHTS
    else:
        row_heights = HEIGHTS_NO_VOLTAGE  # Hide voltage plot, make current plot full height

    base_fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        row_heights=row_heights,
        vertical_spacing=VERTICAL_SPACING,
    )

    fig = FigureResampler(
        base_fig,
        default_n_shown_samples=N_SHOWN_SAMPLES,
        default_downsampler=MinMaxLTTB(parallel=True),
    )

    # Use lighter color when events are shown
    line_color = pfd.PRIMARY_COLOR_LIGHTER if show_events else pfd.PRIMARY_COLOR

    # Add voltage trace (will be hidden when show_voltage=False)
    fig.add_trace(
        go.Scattergl(
            mode="lines",
            line=dict(color="steelblue", width=1),
            name="Voltage",
            showlegend=False,
            visible=show_voltage,
        ),
        hf_x=raw.t,
        hf_y=raw[pf.VOLTAGE_COL].to_numpy(),
        row=1,
        col=1,
    )

    # Add current trace
    fig.add_trace(
        go.Scattergl(
            mode="lines",
            line=dict(color=line_color, width=2),
            name="Current",
            showlegend=False,
        ),
        hf_x=raw.t,
        hf_y=raw.i.to_numpy(),
        row=2,
        col=1,
    )

    # Always use row=2, col=1 for current panel traces
    row_kwarg = dict(row=2, col=1)

    if show_events and f.has_events:
        events = f.get_events(channel=channel_num)

        if raw.ios is not None:
            x = raw.get_t(n=50)
            y = raw.ios(x)
            fig.add_trace(
                go.Scattergl(**get_ios_plot_data(raw.ios, x, y)), **row_kwarg
            )
            fig.add_annotation(**get_ios_annotation_plot_data(raw.ios, x, y))

        for j, (idx, row) in enumerate(events.iterrows()):
            event_df = f.get_event(idx).downsample(events_downsample)

            label_idx = int(row.get(pf.LABEL_COL, 0))
            color = pfd.DEFAULT_LABELS[
                min(label_idx, len(pfd.DEFAULT_LABELS) - 1)
            ].color

            fig.add_trace(
                go.Scattergl(
                    x=event_df.get_t(absolute=True),
                    y=event_df.i,
                    mode="lines",
                    line=dict(color=color, width=2),
                    name=f"Event {idx}",
                    showlegend=False,
                ),
                **row_kwarg,
            )

    # Always use 2-row layout
    fig.update_layout(
        title=f"Channel {channel_num}",
        template="plotly_white",
        margin=dict(l=40, r=40, t=60, b=40),
        legend=dict(
            orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1
        ),
    )

    # Configure axes based on show_voltage setting
    if show_voltage:
        fig.update_yaxes(
            title_text="V (mV)", showline=True, mirror=True, row=1, col=1
        )
    else:
        # Hide voltage axes when not showing voltage
        fig.update_yaxes(
            showticklabels=False, showline=False, zeroline=False, row=1, col=1
        )

    fig.update_yaxes(
        title_text="I (pA)", showline=True, mirror=True, row=2, col=1
    )
    fig.update_xaxes(
        title_text="Time (s)", showline=True, mirror=True, row=2, col=1
    )
    fig.update_xaxes(showline=True, mirror=True, row=2, col=1)

    _current_fig_resampler = fig
    return fig


def get_ios_annotation_plot_data(
    ios: np.polynomial.Polynomial, x: np.ndarray, y: np.ndarray
) -> dict:
    return dict(
        x=x[-1],
        y=y[-1],
        text=f"IOS: {pf.utils.poly_text(ios, 4, 'unicode')}",
        showarrow=False,
        yshift=10,
        xanchor="right",
    )


def get_ios_plot_data(ios, x: np.ndarray, y: np.ndarray) -> dict:
    return dict(
        x=x,
        y=y,
        mode="lines",
        line=dict(color="gray", dash="dash", width=2),
        showlegend=False,
        name=f"Open state current fit: {pf.utils.poly_text(ios, 4, 'unicode')}",
    )


def store_events_to_file(
    f: pf.File,
    channel_num: int,
    events: pf.EventsDataFrame,
    ios: np.polynomial.Polynomial,
):
    """Store events to file, handling existing events properly."""

    # Clear existing events for this channel
    f.remove_events(channel_num)

    # Load remaining events (other channels) if any
    existing_events = None
    if f.has_events:
        existing_events = f.get_events()

    if existing_events is not None and len(existing_events) > 0:
        # Combine existing events (other channels) with new events
        combined_events = pd.concat([existing_events, events])
        # Sort by channel and event number
        combined_events = combined_events.sort_values(
            [pf.CHANNEL_COL, pf.START_IDX_COL]
        )
        combined_events = combined_events.reset_index(drop=True)
        events = combined_events

    f.set_events(events)
    f.set_ios(ios, channel=channel_num, force=True)


def get_clear_plot_patch(channel_idx: int, config: dict) -> Patch:

    f = pfd.get_handle(config)

    patch = Patch()

    # Current trace is always at index 1
    patch["data"][1]["line"]["color"] = pfd.PRIMARY_COLOR

    n_events = len(f.get_events(channel=channel_idx))
    has_ios = f.get_ios(channel_idx) is not None

    # Start after voltage (index 0) and current (index 1) traces; clear IOS + event traces
    for j in range(2, n_events + 2 + has_ios):
        patch["data"][j].clear()
        patch["layout"]["annotations"][0].clear()

    return patch


@callback(
    Output("channels-info-modal-body", "children"),
    Input("channels-idx-store", "data"),
    Input("config-store", "data"),
)
def update_channel_info_body(
    channel_idx, config: dict
) -> html.Table | html.Small:
    """Create the channel info modal body."""

    if pfd.is_no_file(config):
        return html.Small(
            "No channel data loaded", className="text-muted d-block mb-2"
        )

    if channel_idx is None:
        raise PreventUpdate

    f = pfd.get_handle(config)
    n_events = f.n_events
    ios = f.get_ios(channel_idx)

    info_items = [
        ("Channel", channel_idx),
        ("Total Samples", len(f)),
        ("Duration (s)", f"{f.duration:.2f}"),
        ("Events", n_events),
        ("Open state fit", NA if ios is None else ios),
    ]

    info_body = html.Table(
        [
            html.Tr(
                [html.Th(k, style={"padding-right": "20px"}), html.Td(str(v))]
            )
            for k, v in info_items
        ],
        className="table table-sm table-borderless",
    )

    return info_body


@callback(
    Output("channels-graph", "figure", allow_duplicate=True),
    Output("channels-display-rate", "children"),
    Input("channels-idx-store", "data"),
    State({"type": "btn-state", "index": "channels-show-events"}, "data"),
    State("config-store", "data"),
    State("channels-filter-cutoff-hz", "value"),
    State("channels-event-filter-hz", "value"),
    prevent_initial_call="initial_duplicate",
)
def create_plot(
    channel_idx,
    show_events: bool,
    config,
    filter_cutoff,
    events_downsample,
):

    if pfd.is_no_file(config):
        return go.Figure(), ""

    f = pfd.get_handle(config)

    # Get available channels
    channels = f.get_channels()
    if not channels:
        return go.Figure(), ""

    # channel_idx is 0-based index into the channels list
    if channel_idx >= len(channels):
        channel_idx = 0

    channel_num = channels[channel_idx]

    fig = draw_figure(
        f,
        channel_num,
        filter_cutoff,
        events_downsample,
        show_events,
        is_show_voltage(config),
    )

    fig.update_layout(
        title=dict(
            text=f"{config['input']['name']} — Channel {channel_num}",
            x=0.5,
            xanchor="center",
        )
    )

    set_plot_limits(fig, config, "channels_page", row=2)
    set_plot_limits(fig, config, "channels_voltage_page", row=1)

    total_duration = (
        _current_n_samples / _current_sfreq if _current_sfreq else 0
    )
    display_rate = _format_display_rate(0, total_duration)

    return fig, display_rate


@callback(
    Output("channels-graph", "figure", allow_duplicate=True),
    Output("channels-display-rate", "children", allow_duplicate=True),
    Input("channels-graph", "relayoutData"),
    prevent_initial_call=True,
)
def resample_on_zoom(relayoutdata):
    """Dynamically resample channel data when the user zooms or pans."""
    if _current_fig_resampler is None or relayoutdata is None:
        raise PreventUpdate
    patch = _current_fig_resampler.construct_update_data_patch(relayoutdata)

    # Compute display rate from the visible x-range
    x_min = relayoutdata.get("xaxis.range[0]")
    x_max = relayoutdata.get("xaxis.range[1]")
    if x_min is not None and x_max is not None:
        display_rate = _format_display_rate(float(x_min), float(x_max))
    elif "xaxis.autorange" in relayoutdata:
        # Reset zoom (double-click) — show full range
        total_duration = (
            _current_n_samples / _current_sfreq if _current_sfreq else 0
        )
        display_rate = _format_display_rate(0, total_duration)
    else:
        display_rate = dash.no_update

    return patch, display_rate


@callback(
    Output("channels-event-filter-hz", "disabled"),
    Input({"type": "btn-state", "index": "channels-show-events"}, "data"),
)
def toggle_event_downsample_input(show_events):
    """Enable event downsample input only when show events is checked."""
    return not show_events


@callback(
    Output("channels-config-modal", "is_open"),
    Output("channels-plot-config-content", "children"),
    Input("channels-config-btn", "n_clicks"),
    Input("channels-config-modal-close", "n_clicks"),
    State("channels-config-modal", "is_open"),
    State("config-store", "data"),
)
def toggle_channel_settings_modal(n1, n2, is_open, config):
    if n1 or n2:
        # When opening the modal, create the config content
        if not is_open:
            config_content = create_plot_config(config)
            return True, config_content
        else:
            # When closing, just toggle the modal state
            return False, dash.no_update
    return is_open, dash.no_update


@callback(
    Output("channels-info-modal", "is_open"),
    Input("channels-info-btn", "n_clicks"),
    Input("channels-info-modal-close", "n_clicks"),
    State("channels-info-modal", "is_open"),
)
def toggle_channel_info_modal(n1, n2, is_open):
    return not is_open if n1 or n2 else is_open


@callback(
    Output("channels-graph", "figure", allow_duplicate=True),
    Output("channels-display-rate", "children", allow_duplicate=True),
    Input({"type": "btn-state", "index": "channels-show-events"}, "data"),
    Input("channels-filter-cutoff-hz", "value"),
    Input("channels-event-filter-hz", "value"),
    Input("config-update", "data"),
    State("channels-idx-store", "data"),
    State("config-store", "data"),
    State("channels-graph", "figure"),
    prevent_initial_call=True,
)
def update_plot(
    show_events,
    filter_cutoff,
    downsample_events,
    config_update,
    channel_idx,
    config,
    figure,
):
    """Update the channel plot using Patch to preserve zoom/pan state."""

    if figure is None:  # Do not update a plot if it doesn't exist yet
        raise PreventUpdate

    f = pfd.get_handle(config)

    # Create a patch to update the figure
    patch = Patch()

    # Check what triggered this callback
    triggered_id = ctx.triggered_id

    # Handle show_voltage config changes
    if triggered_id == "config-update" and config_update:
        patch_plot_limits(
            patch, config, config_update, section_sele="channels_voltage_page"
        )
        patch_plot_limits(
            patch,
            config,
            config_update,
            suffix="2",
            section_sele="channels_page",
        )

        # if config_update != "channels_voltage_page.show_voltage":
        #     return patch, dash.no_update

        show_voltage = is_show_voltage(config)

        # Update voltage trace visibility
        patch["data"][0]["visible"] = show_voltage
        patch_axis_visibiliy(patch, show_voltage)

        # Update row heights and axis visibility
        if show_voltage:
            # Show voltage plot (30% height)
            patch["layout"]["yaxis2"]["domain"] = [
                0.0,
                HEIGHTS[1] - VERTICAL_SPACING / 2,
            ]  # Voltage plot takes 30%
            patch["layout"]["yaxis"]["domain"] = [HEIGHTS[1] + VERTICAL_SPACING / 2, 1.0]
            patch["layout"]["yaxis"]["title"]["text"] = "V (mV)"

        else:
            # Hide voltage plot (0% height)
            patch["layout"]["yaxis2"]["domain"] = [
                0.0,
                1.0,
            ]  # Voltage plot takes 0%
            patch["layout"]["yaxis"]["domain"] = [
                0.0,
                1.0,
            ]

        return patch, dash.no_update

    # Voltage trace is always at index 0, current trace at index 1
    # Offset for event traces (after voltage and current traces)
    _events_offset = 2

    # Toggle events button id is dict. Might need to change this later if we add extra buttons
    if (
        isinstance(triggered_id, dict)
        and triggered_id.get("type") == "btn-state"
    ):
        if show_events:
            patch["data"][1]["line"]["color"] = pfd.PRIMARY_COLOR_LIGHTER

            if not f.has_events:
                return patch, dash.no_update  # Early exit if no events

            events = f.get_events(channel=channel_idx)

            ios = f.get_ios(channel_idx)
            add_ios = ios is not None

            if add_ios:
                x = f.get_t(n=50)
                y = ios(x)

                ios_data = get_ios_plot_data(ios, x, y)
                ios_data["yaxis"] = "y2"  # Always use y2 for bottom panel
                patch["data"][_events_offset] = ios_data
                patch["layout"]["annotations"][0] = (
                    get_ios_annotation_plot_data(ios, x, y)
                )

            for j, (idx, row) in enumerate(events.iterrows()):
                event_df = f.get_event(idx).downsample(downsample_events)

                label_idx = int(row.get(pf.LABEL_COL, 0))
                color = pfd.DEFAULT_LABELS[
                    min(label_idx, len(pfd.DEFAULT_LABELS) - 1)
                ].color

                # Add or update event trace
                event_trace = {
                    "x": event_df.get_t(absolute=True),
                    "y": event_df.i.to_numpy(),
                    "mode": "lines",
                    "line": {"color": color, "width": 2},
                    "name": f"Event {idx}",
                    "showlegend": False,
                    "type": "scattergl",
                    "yaxis": "y2",  # Always use y2 for bottom panel
                }
                patch["data"][j + _events_offset + add_ios] = event_trace
            return patch, dash.no_update
        else:
            return get_clear_plot_patch(channel_idx, config), dash.no_update

    elif triggered_id == "channels-filter-cutoff-hz":
        # Filter cutoff changed — rebuild the resampler with newly filtered
        # full-resolution data, then resample for the current zoom window
        # so the view stays in place.
        x_range = figure.get("layout", {}).get("xaxis", {}).get("range")

        channels = f.get_channels()
        channel_num = channels[channel_idx]
        # Rebuild resampler on the full raw→filtered trace
        draw_figure(
            f,
            channel_num,
            filter_cutoff,
            downsample_events,
            show_events,
            is_show_voltage(config),
        )

        if x_range is not None:
            # Ask the resampler to produce data for the current zoom window
            # Note: xaxis is always the bottom axis (row 2) in our fixed layout
            relayout = {
                "xaxis.range[0]": x_range[0],
                "xaxis.range[1]": x_range[1],
            }
            return _current_fig_resampler.construct_update_data_patch(
                relayout
            ), dash.no_update

        # No zoom active — return the full new figure
        return _current_fig_resampler, dash.no_update

    elif triggered_id == "channels-event-filter-hz":
        events = f.get_events(channel=channel_idx)

        for j, (idx, row) in enumerate(events.iterrows()):
            event_df = f.get_event(idx).downsample(downsample_events)

            patch["data"][j + _events_offset]["x"] = event_df.get_t(
                absolute=True
            )
            patch["data"][j + _events_offset]["y"] = event_df.i

        return patch, dash.no_update

    # If we get here, no recognized trigger
    raise PreventUpdate


def patch_axis_visibiliy(patch: Patch, visible: bool):
    patch["layout"]["yaxis"]["showticklabels"] = visible
    patch["layout"]["yaxis"]["showline"] = visible
    patch["layout"]["yaxis"]["zeroline"] = visible

    patch["layout"]["xaxis"]["showticklabels"] = False
    patch["layout"]["xaxis"]["showline"] = False
    patch["layout"]["xaxis"]["zeroline"] = False

    patch["layout"]["xaxis2"]["anchor"] = "y2"



@callback(
    Output("channels-filter-cutoff-hz", "value"),
    Output("channels-event-filter-hz", "value"),
    Input("config-store", "data"),
    State("channels-filter-cutoff-hz", "value"),
    State("channels-event-filter-hz", "value"),
)
def initialize_events_config_from_config(
    config, current_filter_cutoff, current_events_downsample
):

    if pfd.is_no_file(config):
        return 0, 0

    filter_cutoff = config["plot"].get(
        "channels_filter_cutoff_freq", DEFAULT_FILTER_CUTOFF_HZ
    )

    # Only update if the values have actually changed
    if (
        filter_cutoff == current_filter_cutoff
    ):
        raise PreventUpdate

    return filter_cutoff, filter_cutoff


@callback(
    Output("url", "pathname"),
    Output("url", "search"),
    Input("channels-graph", "clickData"),
    State("channels-idx-store", "data"),
    State("config-store", "data"),
    State({"type": "btn-trigger", "index": "channels-show-events"}, "n_clicks"),
    prevent_initial_call=True,
)
def open_event_on_click(click_data, channel_idx, config, n_clicks):
    """Navigate to labeler page when an event is clicked."""

    if not n_clicks & 1 or pfd.is_no_file(
        config
    ):  # If events not being viewed, don't bother
        raise PreventUpdate

    f = pfd.get_handle(config)

    if click_data is None or not f.has_events:
        raise PreventUpdate

    has_ios = f.get_ios(channel_idx) is not None
    # Voltage trace is always at index 0, current trace at index 1
    # Events start at index 2 (after voltage and current)
    _events_start_idx = 2

    trace_index = click_data.get("points", [{}])[0].get("curveNumber")
    event_map = f.get_events(channel_idx).index

    if trace_index < (_events_start_idx + has_ios):  # Before event traces
        raise PreventUpdate

    event_idx = event_map[trace_index - _events_start_idx - has_ios]

    # Navigate to labeler page with event index as query parameter
    return pfd.EVENTS_PAGE_NAME, f"?event_idx={event_idx}"


@callback(
    Output("channels-find-events-modal", "is_open", allow_duplicate=True),
    Input("channels-find-events-modal-close", "n_clicks"),
    prevent_initial_call=True,
)
def close_events_modal(close_clicks):
    """Close the events modal."""
    if ctx.triggered_id == "channels-find-events-modal-close":
        return False
    raise PreventUpdate


@callback(
    Output("channels-find-events-modal", "is_open", allow_duplicate=True),
    Output("channels-find-events-trigger", "data"),
    Input("channels-find-events", "n_clicks"),
    State("channels-idx-store", "data"),
    State("config-store", "data"),
    prevent_initial_call=True,
)
def open_find_events_modal(_find_clicks, channel_idx, config):
    """Open the Find Events modal immediately; computation is triggered via store."""
    return True, {"channel_idx": channel_idx, "config": config}


@callback(
    Output("channels-find-events-modal-body", "children"),
    Output(
        {"type": "btn-trigger", "index": "channels-show-events"}, "n_clicks"
    ),
    Input("channels-find-events-trigger", "data"),
    State({"type": "btn-trigger", "index": "channels-show-events"}, "n_clicks"),
    prevent_initial_call=True,
)
def find_events_for_channel(trigger_data, n_clicks):
    """Find events for the current channel and display results in modal."""

    if trigger_data is None:
        raise PreventUpdate

    channel_idx = trigger_data["channel_idx"]
    config = trigger_data["config"]

    f = pfd.get_handle(config)

    if f is None:
        raise PreventUpdate

    try:
        raw = f.get_raw(channel=channel_idx)

        events_config = config["event_finding"]
        min_duration = events_config.pop("min_duration")

        events = raw.find_events(**events_config)
        events = events.filter_by_duration(min_duration)

        if events is None or len(events) == 0:
            return html.Div(
                [
                    html.P(
                        f"No events found in channel {channel_idx}.",
                        className="text-warning",
                    ),
                ]
            ), dash.no_update

        n_events = len(events)
        avg_duration = events[pf.DURATION_COL].mean()
        total_duration = events[pf.DURATION_COL].sum()

        store_events_to_file(f, channel_idx, events, raw.ios)

        results = html.Div(
            [
                html.P(
                    f"Found {n_events} events in channel {channel_idx}.",
                    className="text-success",
                ),
                html.Hr(),
                html.Table(
                    [
                        html.Tr([html.Th("Statistic"), html.Th("Value")]),
                        html.Tr(
                            [
                                html.Td("Number of events"),
                                html.Td(str(n_events)),
                            ]
                        ),
                        html.Tr(
                            [
                                html.Td("Average duration (s)"),
                                html.Td(f"{avg_duration:.4f}"),
                            ]
                        ),
                        html.Tr(
                            [
                                html.Td("Total duration (s)"),
                                html.Td(f"{total_duration:.4f}"),
                            ]
                        ),
                        html.Tr(
                            [
                                html.Td("Coverage (%)"),
                                html.Td(
                                    f"{(total_duration / raw.duration * 100):.2f}"
                                ),
                            ]
                        ),
                    ],
                    className="table table-sm table-borderless",
                ),
            ]
        )

        return results, n_clicks + 1

    except Exception as e:
        import traceback

        error_details = (
            f"Error finding events: {str(e)}\n\n{traceback.format_exc()}"
        )
        return html.Div(
            [
                html.P(
                    f"Error finding events: {str(e)}", className="text-danger"
                ),
                html.Details(
                    [
                        html.Summary("Show traceback"),
                        html.Pre(
                            error_details,
                            className="text-muted small mt-2",
                            style={"white-space": "pre-wrap"},
                        ),
                    ]
                ),
            ]
        ), dash.no_update


@callback(
    Output(
        {"type": "btn-trigger", "index": "channels-show-events"},
        "n_clicks",
        allow_duplicate=True,
    ),
    Output("channels-idx-external", "data", allow_duplicate=True),
    Input("channels-reset-events", "n_clicks"),
    State("channels-idx-store", "data"),
    State("config-store", "data"),
    prevent_initial_call=True,
)
def reset_current_channel_events(reset_clicks, channel_idx, config):
    """Reset events for the current channel."""

    if ctx.triggered_id != "channels-reset-events" or reset_clicks is None:
        raise PreventUpdate

    f = pfd.get_handle(config)

    if f is None:
        raise PreventUpdate

    f.remove_events(channel_idx)

    return 0, channel_idx  # Same idx forces plot reset


@callback(
    Output(
        {"type": "btn-trigger", "index": "channels-show-events"},
        "n_clicks",
        allow_duplicate=True,
    ),
    Output("channels-reset-all-confirm-modal", "is_open"),
    Output("channels-idx-external", "data", allow_duplicate=True),
    Input("channels-reset-events-all", "n_clicks"),
    Input("channels-reset-all-cancel", "n_clicks"),
    Input("channels-reset-all-confirm", "n_clicks"),
    State("channels-idx-store", "data"),
    State("config-store", "data"),
    prevent_initial_call=True,
)
def handle_reset_all_events(
    reset_all_clicks, cancel_clicks, confirm_clicks, channel_idx, config
):
    """Handle complete reset all events flow with confirmation."""

    triggered_id = ctx.triggered_id

    if (
        triggered_id == "channels-reset-events-all"
        and reset_all_clicks is not None
    ):
        return dash.no_update, True, dash.no_update

    elif triggered_id == "channels-reset-all-cancel":
        return dash.no_update, False, dash.no_update

    elif triggered_id == "channels-reset-all-confirm":
        f = pfd.get_handle(config)

        if f is None:
            raise PreventUpdate

        f.remove_events()

        return 0, False, channel_idx  # Forces plot refresh

    raise PreventUpdate


# ── Save PNG modal ──────────────────────────────────────────────────────────


@callback(
    Output("channels-save-png-modal", "is_open"),
    Output("channels-save-png-filename", "value"),
    Output("channels-save-png-metadata", "value"),
    Input("channels-save-png-btn", "n_clicks"),
    Input("channels-save-png-modal-close", "n_clicks"),
    Input("channels-save-png-download-btn", "n_clicks"),
    State("channels-save-png-modal", "is_open"),
    State("config-store", "data"),
    State("channels-graph", "figure"),
    State("channels-display-rate", "children"),
    State("channels-filter-cutoff-hz", "value"),
    prevent_initial_call=True,
)
def toggle_save_png_modal(
    open_clicks,
    close_clicks,
    download_clicks,
    is_open,
    config,
    figure,
    display_rate_children,
    filter_cutoff,
):
    """Open the modal (pre-filling filename and metadata from current display rate), or close it."""
    if ctx.triggered_id == "channels-save-png-btn":
        name = (
            config["input"]["name"]
            if config and not pfd.is_no_file(config)
            else ""
        )
        stem = (
            name.rsplit(".", 1)[0]
            if name and "." in name
            else (name or "channel_plot")
        )
        x_range = (figure or {}).get("layout", {}).get("xaxis", {}).get("range")
        x1 = round(float(x_range[0])) if x_range else 0
        # Convert children list (may contain strings and html.Br dicts) to plain text
        parts = (
            display_rate_children
            if isinstance(display_rate_children, list)
            else ([display_rate_children] if display_rate_children else [])
        )
        display_rate_text = "\n".join(p for p in parts if isinstance(p, str))
        filter_line = (
            f"Filter cutoff (Hz): {filter_cutoff}"
            if filter_cutoff is not None
            else "Filter cutoff (Hz): None"
        )
        metadata = f"{filter_line}\n{display_rate_text}"
        return True, f"{stem}-{x1}s", metadata
    return False, dash.no_update, dash.no_update


clientside_callback(
    """
    function(n_clicks, filename, metadata) {
        if (!n_clicks) return window.dash_clientside.no_update;

        var graphDiv = document.querySelector('#channels-graph .js-plotly-plot');
        if (!graphDiv) return window.dash_clientside.no_update;

        var fname = (filename || 'channel_plot').trim() || 'channel_plot';
        var sc = 4;

        // Save existing annotations so we can restore them after download
        var existingAnnotations = (graphDiv.layout && graphDiv.layout.annotations)
            ? JSON.parse(JSON.stringify(graphDiv.layout.annotations))
            : [];

        var doDownload = function() {
            Plotly.downloadImage(graphDiv, {format: 'png', filename: fname, scale: sc});
        };

        if (metadata && metadata.trim()) {
            // Save original bottom margin so we can restore it after download
            var origMarginB = (graphDiv.layout && graphDiv.layout.margin && graphDiv.layout.margin.b != null)
                ? graphDiv.layout.margin.b : 40;

            var metaAnnot = {
                text: metadata.replace(/\\n/g, '<br>'),
                showarrow: false,
                xref: 'paper',
                yref: 'paper',
                x: 1.0,
                y: -0.12,
                xanchor: 'right',
                yanchor: 'top',
                align: 'right',
                font: {size: 9, color: '#555555'}
            };
            // Expand bottom margin to prevent the annotation from being clipped
            Plotly.relayout(graphDiv, {
                annotations: existingAnnotations.concat([metaAnnot]),
                'margin.b': 80
            }).then(function() {
                return Plotly.downloadImage(graphDiv, {
                    format: 'png',
                    filename: fname,
                    scale: sc
                });
            }).then(function() {
                Plotly.relayout(graphDiv, {annotations: existingAnnotations, 'margin.b': origMarginB});
            });
        } else {
            doDownload();
        }

        return window.dash_clientside.no_update;
    }
    """,
    Output("channels-save-png-dummy", "data"),
    Input("channels-save-png-download-btn", "n_clicks"),
    State("channels-save-png-filename", "value"),
    State("channels-save-png-metadata", "value"),
    prevent_initial_call=True,
)
