"""File management page for Poreflow dashboard."""

import os
import pathlib
import tomllib
import traceback
from pathlib import Path

import dash
import tomli_w
import dash_bootstrap_components as dbc
from dash import html, Input, Output, State, callback, ctx, dcc
from dash.exceptions import PreventUpdate
from pydantic import ValidationError

import poreflow_dash as pfd
from poreflow_dash.schema import create_form

dash.register_page(__name__, path="/", title="Files")

layout = html.Div(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                    [
                                        html.H4(
                                            "Load Data File",
                                            className="mt-3 mb-3",
                                        ),
                                        html.Div(id="files-load-status"),
                                    ],
                                    className="d-flex align-items-center",
                                )
                            ],
                            className="mt-3 mb-4",
                        ),
                        dbc.InputGroup(
                            [
                                dbc.Input(
                                    id="files-path-input",
                                    placeholder="e.g., /Users/name/data/experiment_01",
                                    type="text",
                                    persistence=True,
                                    persistence_type="session",
                                ),
                                *pfd.IconButton(
                                    "lucide-upload",
                                    "Open Fast5 file",
                                    id="files-load-btn",
                                    color="primary",
                                ),
                                *pfd.IconButton(
                                    "lucide-x",
                                    "Close file. Allows for usage elsewhere.",
                                    id="files-close-btn",
                                    color="secondary",
                                    border=True,
                                ),
                            ],
                            className="mb-3",
                        ),
                        html.P(
                            "Enter the local file system path to your dataset.",
                            className="text-muted",
                        ),
                        html.Br(),
                        dbc.Card(
                            [
                                dbc.CardHeader(html.H4("File Information")),
                                dbc.CardBody(
                                    html.Div(
                                        id="files-info-content",
                                        children="No path loaded.",
                                    ),
                                ),
                            ],
                            className="mb-3",
                        ),
                        html.Br(),
                        html.Div(
                            id="files-config-content"
                        ),  # Settings section will be added here dynamically
                        html.Br(),
                    ],
                    width=12,
                )
            ]
        )
    ]
)


def create_config_ui(config: dict, default: bool, error: str = None):
    """Create the config section for the files page."""

    if default:
        badge = dbc.Badge("Default", color="light", className="ms-2")
    else:
        badge = dbc.Badge(
            "Configuration from folder", color="success", className="ms-2"
        )

    if error is not None:
        error = dbc.Alert(
            error, color="warning", className="ms-2", dismissable=True
        )

    return html.Div(
        [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.H4("Configuration", className="mt-3 mb-3"),
                            badge,
                        ],
                        className="d-flex align-items-center",
                    ),
                    error,
                ],
                className="mt-3 mb-4",
            ),
            html.P(
                "If a configuration TOML file if found in the same folder as your file, it will be used. Otherwise, default settings are loaded",
                className="text-muted",
            ),
            create_form(pfd.ConfigSchema, config, include=None),
            dcc.Download(id="files-config-download"),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            *pfd.IconButton(
                                "lucide-save",
                                id="files-config-save-btn",
                                color="primary",
                                tooltip_text="Save configuration",
                                className="me-2",
                            ),
                            *pfd.IconButton(
                                "lucide-rotate-ccw",
                                id="files-config-reset-btn",
                                color="secondary",
                                tooltip_text="Reset to defaults",
                                className="me-2",
                            ),
                            *pfd.IconButton(
                                "lucide-download",
                                id="files-config-download-btn",
                                color="secondary",
                                tooltip_text="Download configuration",
                                className="me-2",
                            ),
                            html.Span(
                                id="files-config-status", className="ms-3"
                            ),
                        ],
                        className="d-flex align-items-center",
                    )
                ],
                className="mt-3 mb-4",
            ),
        ]
    )


def load_config(
    search_path: str | Path | None = None,
) -> tuple[dict, str | None, str | None]:
    """Load TOML configuration, checking search_path first, then falling back to assets.

    Will validate a loaded config against chema

    Args:
        search_path: Optional path to search for poreflow.toml (defaults to current directory)

    Returns:
        tuple: (config_dict, file_path, error)
        - config_dict: The loaded configuration
        - file_path: Path to the loaded file or None if default
        - error:
        - error: Error message or None
    """
    # Determine search path (default to current directory)
    search_toml_path = get_expected_toml_path(search_path)

    if search_toml_path.exists():
        try:
            with open(search_toml_path, "rb") as f:
                config = tomllib.load(f)
        except tomllib.TOMLDecodeError as e:
            return (
                pfd.ConfigSchema().model_dump(),
                None,
                f"Error parsing TOML, using Default. Info: {e}",
            )

        try:
            schema = pfd.ConfigSchema(**config).model_dump()
        except ValidationError as e:
            return (
                pfd.ConfigSchema().model_dump(),
                None,
                f"Error validating, using Default. Info: {e}",
            )

        return schema, str(search_toml_path), None
    else:
        return pfd.ConfigSchema().model_dump(), None, None


def get_expected_toml_path(search_path: str | Path | None) -> Path:
    if search_path is None:
        search_path = Path.cwd()
    else:
        search_path = Path(search_path)

    return search_path / "poreflow.toml"


def is_default(file_path: str | Path) -> bool:
    """Check if a file path is the default TOML file.

    The reader will have returned a file path None.

    """
    return file_path is None


def requested_file_load_error(new_path: Path, config: dict, error) -> dict:
    new_state = {
        "file_path": new_path.as_posix(),
        "folder_path": new_path.parent.as_posix(),
        "file_name": new_path.name,
        "color": "danger",
        "message": "Error",
        "status": "error",
        "traceback": traceback.format_exc(),
    }
    config[pfd.STATE_KEY] = new_state

    return config


def requested_file_loaded(new_path: Path, config: dict) -> dict:
    new_state = {
        "file_path": new_path.as_posix(),
        "folder_path": new_path.parent.as_posix(),
        "file_name": new_path.name,
        "color": "success",
        "message": "Verified",
        "status": "loaded",
        "traceback": None,
    }
    config[pfd.STATE_KEY] = new_state

    return config


def preload_config(config: dict):
    """Load a config with a default filename, along with the path and filename.

    The default config has a non-specific name, path, and filename. This can
    be added using this function. Path info is extracted from the state
    data in the config.

    Args:
        config: Dictionary containing the (default) config.
    """

    path = Path(config[pfd.STATE_KEY]["file_path"])

    config["input"]["name"] = path.stem
    config["input"]["folder_path"] = path.parent.as_posix()
    config["input"]["file_name"] = path.name


def requested_nonexistent_file(path: Path, config):
    new_state = {
        "file_path": path.as_posix(),
        "folder_path": path.parent.as_posix(),
        "file_name": path.name,
        "color": "warning",
        "message": "File does not exist",
        "status": "no-exist",
        "traceback": None,
    }
    config[pfd.STATE_KEY] = new_state


def requested_none_file(config):
    config[pfd.STATE_KEY] = pfd.NO_FILE_STATE
    return config


def close_unopened_file_error(config):
    state = config[pfd.STATE_KEY]
    new_state = state.copy()
    new_state["color"] = "danger"
    new_state["message"] = "Error closing"
    new_state["status"] = "no-file"

    config[pfd.STATE_KEY] = new_state

    return config


def close_file(config: dict) -> dict:
    state = config[pfd.STATE_KEY]
    pfd.close_handle(config)

    new_state = state.copy()
    new_state["file_path"] = None
    new_state["folder_path"] = None
    new_state["color"] = "dark"
    new_state["message"] = "Closed"
    new_state["status"] = "no-file"

    config[pfd.STATE_KEY] = new_state

    return config


def create_ui(config, error: str = None) -> tuple:
    """Update dataset information component based on new config

    Note that these config also carry the state of the file loading

    Args:
        config:
        error:
        edited (bool): Denote that a default configuration is edited
    """
    state = config.get(pfd.STATE_KEY, pfd.NO_FILE_STATE)

    file_path = state.get("file_path", "")
    status = state["status"]
    message = state["message"]
    color = state["color"]
    error_tb = state["traceback"]

    badge = dbc.Badge(message, color=color, className="ms-2")

    if status in ["no-file", "no-exist"]:
        return "No path loaded.", badge, html.Div()
    elif status == "loaded":
        f = pfd.get_handle(config)
        file_path = pathlib.Path(f.filename)

        info_content = html.Div(
            [
                html.P([html.Strong("Sample rate: "), f"{f.sfreq:.0f} Hz"]),
                html.P([html.Strong("Number of Events: "), str(f.n_events)]),
                html.P([html.Strong("Number of Steps: "), str(f.n_steps)]),
                html.P(
                    [html.Strong("Directory: "), file_path.parent.as_posix()]
                ),
                html.P([html.Strong("Filename: "), file_path.name]),
                html.P([html.Strong("Type: "), f.device]),
                html.P(
                    [
                        html.Strong("Annotator: "),
                        shorten_similar_name(
                            f.annotator.filename, file_path, 8
                        ),
                    ]
                ),
            ]
        )

        default = config[pfd.STATE_KEY]["configuration_path"] is None

        config_section = create_config_ui(config, default, error)

        return info_content, badge, config_section

    elif status == "error":
        info_content = "Error loading file."

        status_msg = html.Div(
            [
                badge,
                dbc.Accordion(
                    [
                        dbc.AccordionItem(
                            html.Pre(error_tb), title="Error Details"
                        )
                    ],
                    start_collapsed=True,
                ),
            ]
        )
        return info_content, status_msg, html.Div()

    raise ValueError(f"Invalid status {status}")


def shorten_similar_name(
    name_to_shorten: str | os.PathLike,
    similar_to: str | os.PathLike,
    end_size: int = 10,
) -> str:

    name_to_shorten = pathlib.Path(name_to_shorten)
    name_to_shorten = name_to_shorten.name  # Do not change extension

    similar_to = pathlib.Path(similar_to)

    replace = similar_to.stem[end_size:-end_size]
    if replace:
        name_to_shorten = name_to_shorten.replace(replace, "..........")
    return name_to_shorten


@callback(
    Output("config-store", "data", allow_duplicate=True),
    Output("files-info-content", "children"),
    Output("files-load-status", "children"),
    Output("files-config-content", "children", allow_duplicate=True),
    Input("files-load-btn", "n_clicks"),
    Input("files-close-btn", "n_clicks"),
    State("files-path-input", "value"),
    State("config-store", "data"),
    prevent_initial_call="initial_duplicate",
)
def new_file_entered(n_load_clicks, n_close_clicks, new_path, config):
    """Update the file configuration in the unified config store."""

    state = config[pfd.STATE_KEY]
    prev_status = state.get("status")  # Store status in config

    if not ctx.triggered:
        return PreventUpdate

    if ctx.triggered_id == "files-close-btn" and prev_status == "loaded":
        return close_file(config), *create_ui(config)

    elif ctx.triggered_id == "files-close-btn":
        return close_unopened_file_error(config), *create_ui(config)

    elif new_path is None or new_path == "":
        return requested_none_file(config), *create_ui(config)

    elif n_load_clicks is None and len(config) > 1:
        # Already loaded a configuration. Only need to check if a new configuration has become available on disk
        return config, *create_ui(config)

    # Proceed to process file
    new_path = new_path.lstrip('"').rstrip('"')  # Remove "" added by windows
    new_path = pathlib.Path(new_path)

    if not new_path.exists():
        requested_nonexistent_file(new_path, config)
        return config, *create_ui(config)

    try:
        pfd.get_handle_from_path(new_path.as_posix())
        config = requested_file_loaded(new_path, config)

    except (FileNotFoundError, IOError) as e:
        config = requested_file_load_error(new_path, config, e)
        return config, *create_ui(config)

    new_config, file_path, config_error = load_config(new_path.parent)

    copy_over_state(config, new_config)
    add_configuration_path_to_state(new_config, file_path)

    if is_default(file_path):
        preload_config(new_config)

    return new_config, *create_ui(new_config, config_error)


def add_configuration_path_to_state(
    config: dict, file_path: str | pathlib.Path | None
):

    if isinstance(file_path, pathlib.Path):
        file_path = file_path.as_posix()
    config[pfd.STATE_KEY]["configuration_path"] = file_path


def copy_over_state(config: dict, new_config: dict):
    new_config[pfd.STATE_KEY] = config[
        pfd.STATE_KEY
    ]  # Add good file loading state


# Callback to reset config to defaults
@callback(
    Output("config-store", "data", allow_duplicate=True),
    Output("files-config-content", "children", allow_duplicate=True),
    Input("files-config-reset-btn", "n_clicks"),
    State("config-store", "data"),
    prevent_initial_call="initial_duplicate",
)
def reset_config_to_defaults(n_clicks, config):
    """Reset all config to default values."""
    if not n_clicks:
        raise PreventUpdate

    state = config[pfd.STATE_KEY]  # Keep old state

    config = pfd.ConfigSchema().model_dump()

    config[pfd.STATE_KEY] = state  # Copy over in old state
    config[pfd.STATE_KEY]["configuration_path"] = None

    preload_config(config)

    return config, create_config_ui(config, True)


# Callback to save config to file
@callback(
    Output("config-store", "data", allow_duplicate=True),
    Output("files-config-status", "children", allow_duplicate=True),
    Input("files-config-save-btn", "n_clicks"),
    State("config-store", "data"),
    prevent_initial_call=True,
)
def save_config_to_file(n_clicks, config):
    """Save config to TOML file."""

    if not n_clicks:
        raise PreventUpdate

    config_to_store = config.copy()
    state = config_to_store.pop(pfd.STATE_KEY)

    config_to_store = pfd.ConfigSchema(**config_to_store).model_dump(
        exclude=True
    )
    export_path = state["configuration_path"]

    if is_default(export_path):
        export_path = get_expected_toml_path(state["folder_path"])

    try:
        with open(export_path, "w") as f:
            f.write(tomli_w.dumps(config_to_store).replace('"', "'"))
    except Exception as e:
        return config, dbc.Alert(
            f"Save failed: {str(e)}", color="danger", className="ms-2"
        )

    add_configuration_path_to_state(config, export_path)

    return config, dbc.Badge(
        "Settings saved successfully!",
        color="success",
        className="ms-2",
    )


@callback(
    Output("files-config-download", "data"),
    Input("files-config-download-btn", "n_clicks"),
    State("config-store", "data"),
    prevent_initial_call=True,
)
def download_config(n_clicks, config):

    config_to_store = config.copy()
    config_to_store.pop(pfd.STATE_KEY)

    config_to_store = pfd.ConfigSchema(**config_to_store).model_dump(
        exclude=True
    )

    return dict(
        content=tomli_w.dumps(config_to_store).replace('"', "'"),
        filename="poreflow.toml",
    )
