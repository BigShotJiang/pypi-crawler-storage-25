from typing import (
    ClassVar,
    List,
    Literal,
    Type,
    get_origin,
    get_args,
    Any,
    Generator,
)

import dash
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined
from pydantic import Field, ConfigDict, BaseModel, ValidationError

from dash import Input, Output, State, ctx, ALL, html
from dash.exceptions import PreventUpdate

import dash_bootstrap_components as dbc

import poreflow_dash as pfd

HIDDEN = {"hidden": True}

DISABLED_FLAG = "DISABLED_FLAG"


class InputConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Input"
    name: str = Field(
        default="My File",
        title="Name",
        description="Display name of file",
    )
    folder_path: str = Field(
        default=DISABLED_FLAG, title="Folder", description="Folder of file"
    )
    file_name: str = Field(
        default=DISABLED_FLAG,
        title="File Name",
        description="Name of file on disk",
    )
    resample_to_freq: int = Field(
        default=5000,
        title="Target rate for Downsampling",
        description="Downsample the signal to a new sample rate in Hz before doing any processing",
    )
    filter_freq: int = Field(
        default=1000,
        title="Filter Cut-off Frequency",
        description="Default filter cut-off frequency in Hz. A 4th-order Bessel filter is used.",
    )


class OutputConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Output"
    path: str = Field(
        default="./",
        title="Folder Path",
        description="Path to output results to",
    )


class EnvironmentConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Environment"
    processes: int = Field(
        default=2,
        title="Number of Processes",
        description="Default number of processes to use when doing parallelization",
    )
    verbose: int = Field(
        default=0, title="Verbosity", description="Verbosity level"
    )


class PlotConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Plot"
    out: str = Field(
        default="./Figures",
        title="Folder Path",
        description="Path to output figures to",
    )
    events_current_range: List[int] = Field(
        default=[0, 150],
        title="Events Current Range",
        description="Default current range for plotting events in pA",
        json_schema_extra=HIDDEN,
    )


class EventFindingConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Event Finding"
    open_state_range: List[int] = Field(
        default=[200, 300],
        title="Open State Range",
        description="Default open state range for plotting in pA",
    )
    voltage_range: List[int] = Field(
        default=[175, 185],
        title="Voltage Range",
        description="Acceptable voltage range for events in mV",
    )
    closing_iterations: int = Field(
        default=10,
        title="Closing Iterations",
        description="Number of morphological closing operations to perform on the event mask. More means more contiguous events",
    )
    boundary_trim: List[int] = Field(
        default=[1, 1],
        title="Boundary Trim",
        description=" Time in ms to trim off the start and end of the events in m",
    )
    n_components: int = Field(
        default=3,
        title="Number of Components",
        description="Number of components to use in the GMM for the open state fit.",
    )
    degree: int = Field(
        default=2,
        title="Degree",
        description="Degree of polynomial fit of the found open state.",
    )
    min_frac_os: float = Field(
        default=0.01,
        title="Minimum Fraction Open State",
        description="Reject all events found in a channel if less that this fraction of the current in the measurement is marked as at open state",
    )
    min_duration: float = Field(
        default=1,
        title="Minimum Duration After Event Detection",
        description="Minimum duration an event in seconds. Postprocessing right after event finder, to remove very short events.",
    )


class StepFindingConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Step Finding"
    sensitivity: float = Field(
        default=3.0,
        title="Sensitivity",
        description="Sensitivity level of the step finder. Higher means finding fewer steps.",
    )
    min_level_length: int = Field(
        default=10,
        title="Minimum Step size",
        description="Minimum level length of a sep in samples.",
    )


class EventFilteringConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Event Filtering"
    min_duration: float = Field(
        default=1,
        title="Minimum Duration",
        description="Minimum duration an event in seconds",
    )
    min_n_steps: int = Field(
        default=45,
        title="Minimum Steps",
        description="Minimum number of steps in an event",
    )
    max_n_steps: int = Field(
        default=800,
        title="Maximum Steps",
        description="Maximum number of steps in an event",
    )
    min_binned_entropy_of_means: float = Field(
        default=2.5,
        title="Minimum Binned Entropy of Means. 2.5 typical of M2 MspA DNA sequencing",
    )
    min_step_rate: float = Field(
        default=12.0,
        title="Minimum Step Rate",
        description="Minimum step rate in Hz. 12 Hz typical of Hel308 at 37C, 1 mM ATP",
    )
    min_ios: float = Field(
        default=0,
        title="Minimum Open State",
        description="Minimum local open state range in pA acceptable for an event",
    )
    max_ios: float = Field(
        default=0,
        title="Maximum Open State",
        description="Maximum local open state range in pA acceptable for an event",
    )


class BoundaryConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Boundary"
    template_DNA_5_3: str = Field(
        default="TCCTTTTATCGTCATCATCTTTGTAATCGCCGCT",
        title="Template DNA Sequence",
        description="Template DNA 5' to 3' sequence for boundaries",
    )
    trim_right: int = Field(
        default=8,
        title="Trim Right",
        description="Trim the right end of the events in bases",
    )
    ref_length: int = Field(
        default=54,
        title="Reference Length",
        description="Reference length in bases",
    )
    segment_step_to_end: int = Field(default=4, title="Segment Step to End")
    window_length: int = Field(
        default=40, title="Window Length", description="Window length in bases"
    )


class ChannelsPageVoltageConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Voltage"
    show_voltage: bool = Field(
        default=True,
        title="Show Voltage",
    )
    ylim: List[int] = Field(
        default=[-200, 200],
        title="Voltage Y-axis Range",
        description="Voltage display range in mV",
    )
    autoscale_y: Literal["auto", "fixed"] = Field(
        default="fixed",
        title="Voltage Y-axis Autoscale",
        description="Y-axis autoscale: 'auto' or 'fixed'",
    )

class ChannelsPageConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Current"
    ylim: List[int] = Field(
        default=[0, 300],
        title="Y-axis Range",
        description="Current range in pA",
    )
    autoscale_y: Literal["auto", "fixed"] = Field(
        default="fixed",
        title="Y-axis",
        description="Y-axis autoscale: 'auto' or 'fixed'",
    )
    xlim: List[int] = Field(
        default=[0, 1000],
        title="X-axis Range",
        description="Time axis range in seconds",
    )
    autoscale_x: Literal["auto", "fixed"] = Field(
        default="auto",
        title="X-axis",
        description="X-axis autoscale: 'auto' or 'fixed'",
    )

class EventsPageConfig(BaseModel):
    UI_CATEGORY: ClassVar[str] = "Events Page Configuration"
    ylim: List[int] = Field(
        default=[0, 300],
        title="Y-axis Range",
        description="Current range in pA",
    )
    autoscale_y: Literal["auto", "fixed"] = Field(
        default="fixed",
        title="Y-axis",
        description="Y-axis autoscale: 'auto' or 'fixed'",
    )
    xlim: List[int] = Field(
        default=[0, 1000],
        title="X-axis Range",
        description="Time axis range in seconds",
    )
    autoscale_x: Literal["auto", "fixed"] = Field(
        default="auto",
        title="X-axis",
        description="X-axis autoscale: 'auto' or 'fixed'",
    )
    x_start: Literal["abs", "rel"] = Field(
        default="abs",
        title="X-axis start time",
        description="X-axis start point mode for plots: 'abs' for time axis in measurement or 'rel' for event starting from t=0.",
    )


class ConfigSchema(BaseModel):
    """Pydantic schema combining all configuration sections with UI metadata."""

    model_config = ConfigDict(extra="forbid")

    input: InputConfig = Field(default_factory=InputConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)
    env: EnvironmentConfig = Field(default_factory=EnvironmentConfig)
    plot: PlotConfig = Field(default_factory=PlotConfig)
    event_finding: EventFindingConfig = Field(
        default_factory=EventFindingConfig
    )
    step_finding: StepFindingConfig = Field(default_factory=StepFindingConfig)
    event_filtering: EventFilteringConfig = Field(
        default_factory=EventFilteringConfig
    )
    boundary: BoundaryConfig = Field(default_factory=BoundaryConfig)
    channels_page: ChannelsPageConfig = Field(
        default_factory=ChannelsPageConfig, json_schema_extra=HIDDEN
    )
    channels_voltage_page: ChannelsPageVoltageConfig = Field(
        default_factory=ChannelsPageVoltageConfig, json_schema_extra=HIDDEN
    )
    events_page: EventsPageConfig = Field(
        default_factory=EventsPageConfig, json_schema_extra=HIDDEN
    )

    @classmethod
    def get_field_description(cls, section: str, field: str) -> str | None:
        """Get the description of a specific field in the schema.

        Args:
            section: The configuration section name (e.g., "input", "plot")
            field: The field name within that section (e.g., "name", "channels_current_range")

        Returns:
            The field description if found, None otherwise
        """
        return cls.get_field(section, field).description

    @classmethod
    def get_field(cls, section: str, field: str) -> FieldInfo | None:
        # Get the section model
        if section not in cls.model_fields:
            raise KeyError(f"Section '{section}' not found")

        section_field = cls.model_fields[section]
        section_model = section_field.annotation

        # Get the field from the section model
        if field not in section_model.model_fields:
            raise KeyError(f"Field '{field}' not found in section '{section}'")

        field_info = section_model.model_fields[field]

        return field_info

    @classmethod
    def get_field_default(cls, section: str, field: str):
        """Get the default value of a specific field in the schema.

        Args:
            section: The configuration section name (e.g., "input", "plot")
            field: The field name within that section (e.g., "name", "channels_current_range")

        Returns:
            The field default value if found, None otherwise
        """
        return cls.get_field(section, field).default

    @classmethod
    def get_field_type(cls, section: str, field: str):
        """Get the type annotation of a specific field in the schema.

        Args:
            section: The configuration section name (e.g., "input", "plot")
            field: The field name within that section (e.g., "name", "channels_current_range")

        Returns:
            The field type annotation if found, None otherwise
        """
        return cls.get_field(section, field).annotation

    @classmethod
    def is_hidden(cls, field: FieldInfo) -> bool:
        """Whether a specific field in the schema is hidden."""

        if not hasattr(field, "json_schema_extra"):
            return False

        extra = field.json_schema_extra

        if not extra:
            return False
        else:
            return extra.get("hidden", False)

    @classmethod
    def excluded(cls) -> dict:
        """Return structured dict of fields marked with json_schema_extra={"hidden": True}.

        For nested models like ConfigSchema, returns a dict with section keys
        containing sets of field names that should be excluded.

        Returns:
            Dictionary with structure matching the model's nested structure,
            containing sets of field names to exclude
        """

        exclude = {}
        for (
            section_description,
            section_name,
            section_info,
            section_model,
        ) in cls.iter_sections():
            if cls.is_hidden(section_info):
                exclude[section_name] = True

            section_excluded_fields = set()

            for field_name, field_info in cls.iter_fields(section_name):
                if cls.is_hidden(field_info):
                    section_excluded_fields.add(field_name)

            if len(section_excluded_fields) > 0:
                exclude[section_name] = section_excluded_fields

        return exclude

    def model_dump(self, exclude: bool = False, **kwargs):
        """Override model_dump to automatically exclude fields marked as hidden.

        Args:
            exclude (bool): Whether to exclude fields marked as hidden
            **kwargs: Additional arguments to pass to parent model_dump

        Returns:
            Dictionary representation of the model with hidden fields excluded
        """
        if exclude:
            exclude_set = self.excluded()
            kwargs["exclude"] = exclude_set

        return super().model_dump(**kwargs)

    @classmethod
    def iter_sections(
        cls,
    ) -> Generator[tuple[str, str, FieldInfo, Any], Any, None]:
        for section_name, section_field in cls.model_fields.items():
            section_model = section_field.annotation
            section_description = getattr(section_model, "UI_CATEGORY")

            yield (
                section_description,
                section_name,
                section_field,
                section_model,
            )

    @classmethod
    def iter_fields(
        cls, section: str
    ) -> Generator[tuple[str, FieldInfo], Any, None]:

        section_field = cls.model_fields[section]
        section_model = section_field.annotation

        for field_name, field_info in section_model.model_fields.items():
            yield field_name, field_info


def is_no_file(config: dict | None) -> bool:
    if config is None:
        return True
    return config[pfd.STATE_KEY] == pfd.NO_FILE_STATE


def create_field_layout(
    field_name,
    field_info,
    comp_id,
    main_label,
    sub_text,
    current_value,
    config,
    section_name,
):
    """Create a field layout component based on the field type.

    Args:
        field_name: Name of the field
        field_info: Pydantic field info
        comp_id: Component ID dictionary
        main_label: Main label for the field
        sub_text: Subtext/description for the field
        current_value: Current value of the field
        config: Full configuration dictionary
        section_name: Configuration section key

    Returns:
        html.Div containing the field layout
    """

    field_type = field_info.annotation

    # Handle boolean fields with switch input
    if field_type is bool:
        return html.Div(
            [
                dbc.Label(main_label, className="fw-bold"),
                dbc.Switch(
                    id=comp_id,
                    value=current_value,
                    className="ms-2",
                ),
                dbc.FormFeedback(
                    id={
                        "type": "field-feedback",
                        "name": f"{section_name}.{field_name}",
                    }
                ),
                dbc.FormText(sub_text) if sub_text else None,
            ],
            className="mb-3",
        )

    # Check if the field type is a Literal (for enum-like fields)
    if get_origin(field_type) is Literal:
        # Get the literal values
        literal_values = get_args(field_type)

        # Create radio items for Literal types
        options = [
            {"label": str(value), "value": value} for value in literal_values
        ]

        return html.Div(
            [
                dbc.Label(main_label, className="fw-bold"),
                dbc.RadioItems(
                    id=comp_id,
                    options=options,
                    value=current_value,
                ),
                dbc.FormFeedback(
                    id={
                        "type": "field-feedback",
                        "name": f"{section_name}.{field_name}",
                    }
                ),
                dbc.FormText(sub_text) if sub_text else None,
            ],
            className="mb-3",
        )

    # Default handling for other types
    input_type = "text"
    if field_type in (int, float):
        input_type = "number"

    return html.Div(
        [
            dbc.Label(main_label, className="fw-bold"),
            dbc.Input(
                id=comp_id,
                type=input_type,
                value=current_value,
                valid=False,
                invalid=False,
                disabled=field_info.default == DISABLED_FLAG,
            ),
            dbc.FormFeedback(
                id={
                    "type": "field-feedback",
                    "name": f"{section_name}.{field_name}",
                }
            ),
            dbc.FormText(sub_text) if sub_text else None,
        ],
        className="mb-3",
    )


def create_form(
    schema: Type[ConfigSchema],
    config: dict,
    include: list[str] = None,
    excluded: bool = None,
    layout: str = "tabs",
):
    """Create a form for editing configuration fields.

    Args:

        schema: The Pydantic schema class
        config: Current configuration dictionary
        include: Optional list of field names to show (format: "section.field").
                       If None, shows all fields.
        excluded (bool): Follow excluded flags in schema. See ConfigSchema. Defaults to None, in which case exclusion is on.
            If `excluded` is not specified and `include` is given, exclusion is turned off by default.
        layout: Layout style for the form. Options: "tabs" (default) or "list"

    Returns:
        dbc.Tabs or list containing the form fields
    """

    tabs = []

    if (include is not None) and excluded is None:
        excluded = False  # Auto turn off excluded if fields to show are given
    elif excluded is None:
        excluded = True

    for (
        category_name,
        section_name,
        section_info,
        section_model,
    ) in schema.iter_sections():
        if excluded and schema.is_hidden(section_info):
            continue

        tab_content = []

        section_include = (
            f"{section_name}.*" in include if include else False
        )  # Include entire section with start pattern

        for field_name, field_info in schema.iter_fields(section_name):
            full_name = f"{section_name}.{field_name}"



            # Skip fields not in fields_to_show if the parameter is provided
            if (
                not section_include
                and include is not None
                and full_name not in include
            ):
                continue

            if excluded and schema.is_hidden(field_info):
                continue

            comp_id = {"type": "config-field", "name": full_name}

            main_label = (
                field_info.title or field_info.description or field_name
            )
            sub_text = field_info.description if field_info.title else None

            current_value = field_info.default

            try:
                current_value = config[section_name][field_name]
            except KeyError:
                pass

            if current_value is PydanticUndefined:
                # For lists, we represent them as empty strings in the UI
                current_value = (
                    "" if "List" in str(field_info.annotation) else None
                )

            field_layout = create_field_layout(
                field_name=field_name,
                field_info=field_info,
                comp_id=comp_id,
                main_label=main_label,
                sub_text=sub_text,
                current_value=current_value,
                config=config,
                section_name=section_name,
            )

            tab_content.append(field_layout)

        if tab_content:  # Only add tab if it has content
            tabs.append(
                dbc.Tab(
                    tab_content,
                    label=category_name,
                    tab_id=f"tab-{section_name}",
                    className="p-4",
                )
            )

    if not tabs:
        return html.Div("No fields to display", className="text-muted")

    # Handle different layout options
    if layout == "list":
        # Return all tab contents wrapped in a container with section headings
        all_children = []
        for tab in tabs:
            # Add section heading if there are multiple sections
            if len(tabs) > 1:
                all_children.append(
                    html.H5(
                        tab.label,
                        className="mt-4 mb-3 border-bottom border-light pb-2",
                    )
                )

            # tab.children should be a list of components
            if hasattr(tab, "children") and tab.children:
                if isinstance(tab.children, list):
                    all_children.extend(tab.children)
                else:
                    all_children.append(tab.children)

        return html.Div(all_children, className="form-container")
    else:  # Default to tabs layout
        return dbc.Tabs(
            tabs,
            id="config-tabs",
            active_tab=f"tab-{list(schema.model_fields.keys())[0]}",
        )


def register_callbacks(app):
    """Register form update callbacks for the application."""

    # Combined callback for updating config store and validation feedback
    @app.callback(
        Output("config-store", "data", allow_duplicate=True),
        Output("config-update", "data"),
        Output({"type": "config-field", "name": ALL}, "invalid"),
        Output({"type": "field-feedback", "name": ALL}, "children"),
        Input({"type": "config-field", "name": ALL}, "value"),
        State({"type": "config-field", "name": ALL}, "id"),
        State("config-store", "data"),
        prevent_initial_call=True,
    )
    def process_form_change(values, ids, config):
        """Process changes to configuration form fields."""

        if ctx.triggered_id is None or not values or not ids:
            raise PreventUpdate

        # Find the index of the triggered input
        try:
            triggered_index = next(
                i
                for i, id_dict in enumerate(ids)
                if id_dict["name"] == ctx.triggered_id["name"]
            )
            value = values[triggered_index]
        except StopIteration:
            raise PreventUpdate

        if value is None:
            raise PreventUpdate

        try:
            section, field = ctx.triggered_id["name"].split(".")
        except (AttributeError, ValueError):
            raise PreventUpdate

        value = str_to_list(value, section, field)

        data = {section: {field: value}}

        # Initialize output arrays
        invalid_states = [False] * len(ids)
        error_messages = [""] * len(ids)

        try:
            # Validate the data
            pfd.ConfigSchema(**data)
            # Update config if validation passes
            if section not in config:
                config[section] = {}
            config[section][field] = value

            # Update config-update store with the changed field
            config_update = f"{section}.{field}"

            return config, config_update, invalid_states, error_messages

        except ValidationError as e:
            # Set error state for the triggered field
            for i, id_dict in enumerate(ids):
                if id_dict["name"] == ctx.triggered_id["name"]:
                    invalid_states[i] = True
                    error_messages[i] = (
                        str(e.errors()[0]["msg"])
                        if e.errors()
                        else "Invalid value"
                    )
                    break

        except Exception as e:
            # Handle any other errors gracefully
            for i, id_dict in enumerate(ids):
                if id_dict["name"] == ctx.triggered_id["name"]:
                    invalid_states[i] = True
                    error_messages[i] = f"Error: {str(e)}"
                    break

        return config, dash.no_update, invalid_states, error_messages

    def str_to_list(value, section: str = None, field: str = None) -> list[str]:

        field_type = ConfigSchema.get_field_type(section, field)

        if get_origin(field_type) is list and isinstance(value, str):
            value = [v.strip() for v in value.split(",")]

            list_type = get_args(field_type)[0] if get_args(field_type) else str

            try:
                value = [list_type(item) for item in value]
            except ValueError:
                pass

        return value

        return value
