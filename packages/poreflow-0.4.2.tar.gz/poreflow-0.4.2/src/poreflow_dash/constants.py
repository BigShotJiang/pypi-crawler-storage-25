from dataclasses import dataclass

__all__ = [
    "Label",
    "DEFAULT_LABELS",
    "PRIMARY_COLOR",
    "PRIMARY_COLOR_LIGHTER",
    "CHANNELS_PAGE_NAME",
    "EVENTS_PAGE_NAME",
    "NO_FILE_STATE",
    "STATE_KEY",
]


@dataclass
class Label:
    name: str
    color: str


DEFAULT_LABELS = [
    Label("none", "#808080"),
    Label("clogged", "#EC6842"),
    Label("dna", "#FFB81C"),
    Label("poc", "#0076C2"),
    Label("poc_reread", "#6CC24A"),
    Label("peptide_reread", "#EF60A3"),
    Label("other", "#bd47c9"),
]


PRIMARY_COLOR = "#543391"
PRIMARY_COLOR_LIGHTER = "#dccafc"

CHANNELS_PAGE_NAME = "/channels"
EVENTS_PAGE_NAME = "/events"

NO_FILE_STATE = {
    "file_path": None,
    "folder_path": None,
    "file_name": None,
    "color": None,
    "message": None,
    "status": "no-file",
    "traceback": None,
    "configuration_path": None,
}
STATE_KEY = "dashboard-state"
