"""Main Dash App for Poreflow."""

import dash
import dash_bootstrap_components as dbc
from dash import dcc, html

import poreflow_dash as pfd
from poreflow_dash.components import controls
from poreflow_dash.components.navbar import navbar
from poreflow_dash.schema import register_callbacks

app = dash.Dash(
    __name__,
    suppress_callback_exceptions=True,
    use_pages=True,
    pages_folder="pages",
    serve_locally=True,
)

register_callbacks(app)  # Form callbacks
pfd.register_icon_button_callbacks(app)

app.title = "poreFlow Dashboard"


navlinks = [
    dbc.NavLink(
        page["name"],
        href=page["relative_path"],
        active="exact",
        className="nav-item",
    )
    for page in dash.page_registry.values()
]


def serve_layout():
    """Define the layout of the application"""
    return html.Div(
        [
            navbar(navlinks),
            dcc.Location(id="url", refresh="callback-nav"),
            dbc.Container(dash.page_container, class_name="my-2"),
            # footer,
            dcc.Store(
                id="config-store",
                data={pfd.STATE_KEY: pfd.NO_FILE_STATE},
                storage_type="session",
            ),
            dcc.Store(
                id="config-update",
                data={"section": None, "field": None},
                storage_type="session",
            ),
            controls.get_keyboard_store(),
        ]
    )


app.layout = serve_layout


if __name__ == "__main__":
    app.run(port=8050, debug=True)
