"""Utility functions for Poreflow dashboards."""

import functools
import poreflow as pf
from dash import html

import poreflow_dash as pfd


@functools.lru_cache(maxsize=1)
def get_handle_from_path(path: str) -> pf.File:
    """
    Get a cached poreflow.io.File handle for the given path.

    Args:
        path (str): Path to the file.
        mode (str): Mode to open the file in.

    Returns:
        poreflow.io.File: The open file handle.
    """
    return pf.File(path)


def get_handle(config: dict) -> pf.File | None:
    path = config[pfd.STATE_KEY]["file_path"]

    if path is None:
        return None

    return get_handle_from_path(path)


def close_handle(config) -> None:
    f = pfd.get_handle(config)
    f.close()
    get_handle_from_path.cache_clear()


def create_downsample_options(sfreq):
    """Create downsample frequency options based on file sampling frequency.

    Args:
        sfreq (float): Sampling frequency of the file in Hz

    Returns:
        list: List of html.Option components for downsample frequencies
    """
    if not sfreq or sfreq <= 0:
        return []

    # Standard downsample frequency options
    target_freqs = [100, 500, 1000]

    options = []
    for freq in target_freqs:
        if freq < sfreq:
            options.append(html.Option(value=str(freq), label=f"{freq} Hz"))

    # Add original frequency option
    options.append(
        html.Option(value=str(int(sfreq)), label=f"Original ({int(sfreq)} Hz)")
    )

    return options


def frequency_to_downsample_factor(sfreq, target_freq):
    """Convert target frequency to downsample factor.

    Args:
        sfreq (float): Original sampling frequency in Hz
        target_freq (float): Target frequency in Hz

    Returns:
        float: Downsample factor (sfreq / target_freq)
    """
    if target_freq >= sfreq:
        return 1.0  # No downsampling needed
    return sfreq / target_freq
