# notes
"""
This file is used for handling anything image related.
I suggest handling the local file encoding/decoding here as well as fetching any external images.
Taken from
"""

# package imports
import base64
from importlib import resources as impresources

from poreflow_dash.assets import logos


logo_path = impresources.files(logos) / "logo.png"

logo_tunel = base64.b64encode(open(str(logo_path), "rb").read())
logo_encoded = "data:image/png;base64,{}".format(logo_tunel.decode())
