import importlib as _importlib

from poreflow_dash import constants
from poreflow_dash.constants import (
    Label,
    DEFAULT_LABELS,
    PRIMARY_COLOR,
    PRIMARY_COLOR_LIGHTER,
    CHANNELS_PAGE_NAME,
    EVENTS_PAGE_NAME,
    NO_FILE_STATE,
    STATE_KEY,
)
from poreflow_dash.utils.io import (
    get_handle,
    close_handle,
    get_handle_from_path,
)

from poreflow_dash.components.ui import (
    IconButton,
    ToggleIconButton,
    register_icon_button_callbacks,
)
from poreflow_dash.schema import ConfigSchema, is_no_file

from poreflow import _version

__version__ = _version.__version__

submodules = [
    "config",
    "pages",
    "components",
]

__all__ = (
    submodules
    + constants.__all__
    + [
        "get_handle",
        "close_handle",
        "get_handle_from_path",
        "IconButton",
        "ToggleIconButton",
        "register_icon_button_callbacks",
        "ConfigSchema",
        "is_no_file",
    ]
)


def __dir__():
    return __all__


def __getattr__(name):
    if name in submodules:
        return _importlib.import_module(f"poreflow_dash.{name}")
    else:
        try:
            return globals()[name]
        except KeyError:
            raise AttributeError(
                f"Module 'poreflow_dash' has no attribute '{name}'"
            )
