import collections
import multiprocessing
import os
import threading
import time

from multiprocessing.pool import Pool

_spawn_ctx = multiprocessing.get_context("spawn")

import psutil

from tqdm.auto import tqdm

import poreflow as pf


def _imap_worker_wrapper(args):
    func, func_args, kwargs = args
    return func(*func_args, **kwargs)


def _monitor_progress_and_memory(
    pool: Pool, pbar, stop_event, update_interval=10
):
    """Monitors and updates progress bar with memory usage and timing information.

    This function runs in a separate thread to monitor the progress
    of a multiprocessing pool and update a progress bar with memory usage and
    timing information.

    Args:
        pool (Pool): The multiprocessing pool being monitored.
        pbar: The tqdm progress bar to update.
        stop_event (threading.Event): Event to signal when monitoring should stop.
        update_interval (int): Time interval in seconds between updates. Defaults to 10.

    Returns:
        None
    """
    processes = pool._processes
    cpu_count = multiprocessing.cpu_count()
    while not stop_event.is_set():
        try:
            # Calculate memory usage
            total_memory = psutil.Process().memory_info().rss / 1024 / 1024
            for proc in pool._pool:
                if proc.is_alive():
                    try:
                        total_memory += (
                            psutil.Process(proc.pid).memory_info().rss
                            / 1024
                            / 1024
                        )
                    except psutil.NoSuchProcess:
                        pass

            # Update progress bar description with current stats
            pbar.set_description(
                f"{processes}/{cpu_count} Processes | RAM: {total_memory:.1f} MB | Time: {time.strftime('%H:%M:%S')}"
            )

            # Force refresh the display
            pbar.refresh()

            # Wait for the specified interval
            time.sleep(update_interval)
        except Exception as e:
            print(f"Monitor error: {e}")
            break


class MemoryMonitor:
    """Context manager for monitoring memory usage and progress during parallel processing.

    Attributes:
        n_tasks (int): Total number of tasks to be completed.
        pool (multiprocessing.pool.Pool): The multiprocessing pool being monitored.
        update_interval (int): Time interval in seconds between updates.
        stop_event (threading.Event): Event to signal when monitoring should stop.
        pbar (tqdm.tqdm): The progress bar to be updated.
        thread: The monitoring thread.
    """

    def __init__(self, n_tasks: int, pool, update_interval=10):
        """Initializes the MemoryMonitor.

        Args:
            n_tasks (int): Total number of tasks to be completed.
            pool (multiprocessing.pool.Pool): The multiprocessing pool being monitored.
            update_interval (int): Time interval in seconds between updates. Defaults to 10.
        """
        self.n_tasks = n_tasks
        self.pool = pool
        self.update_interval = update_interval
        self.stop_event = threading.Event()

        self.pbar = None
        self.thread = None

    def __enter__(self):
        """Enters the context and starts monitoring.

        Creates a progress bar and starts the monitoring thread.

        Returns:
            tqdm: The progress bar instance.
        """
        # Create progress bar (tqdm.auto works better in Jupyter)
        self.pbar = tqdm(
            total=self.n_tasks,
            desc="Starting...",
            ncols=None,  # Auto-adjust width in Jupyter
            leave=True,  # Keep progress bar after completion
        )

        # Start monitoring thread with 10-second updates
        self.thread = threading.Thread(
            target=_monitor_progress_and_memory,
            args=(
                self.pool,
                self.pbar,
                self.stop_event,
                10,
            ),  # Update every 10 seconds
            daemon=True,
        )
        self.thread.start()

        return self.pbar

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exits the context and stops monitoring.

        Stops the monitoring thread and updates the progress bar with final statistics.

        Args:
            exc_type: Exception type if an exception occurred.
            exc_val: Exception value if an exception occurred.
            exc_tb: Exception traceback if an exception occurred.

        Returns:
            None
        """
        self.stop_event.set()
        self.thread.join(timeout=1)

        # Final update
        memory = psutil.Process().memory_info().rss / 1024 / 1024
        for proc in self.pool._pool:
            if proc.is_alive():
                try:
                    memory += (
                        psutil.Process(proc.pid).memory_info().rss / 1024 / 1024
                    )
                except Exception:
                    pass

        self.pbar.set_description(
            f"Completed: {self.pbar.n} / {self.n_tasks} tasks | Final RAM: {memory:.1f} MB"
        )
        self.pbar.close()


class MonitoredPool(Pool):
    """A multiprocessing Pool with built-in memory and progress monitoring.

    This class extends the standard multiprocessing Pool to include
    automatic memory usage and progress monitoring through a context manager.

    Attributes:
        n_tasks (int): Total number of tasks to complete..
        pbar: The tqdm progress bar instance.
    """

    def __init__(self, n_tasks, *args, **kwargs):
        """Initializes the MonitoredPool.



        Args:
            n_tasks (int): Total number of tasks to complete.
            *args: Additional arguments for Pool.__init__, consult See Also section.
            **kwargs: Additional keyword arguments for Pool.__init__, consult See Also section.

        See Also:
            `multiprocessing.pool.Pool`_.

        .. _multiprocessing.pool.Pool: https://docs.python.org/3/library/multiprocessing.html#multiprocessing.pool.Pool
        """
        super().__init__(*args, context=_spawn_ctx, **kwargs)
        self.n_tasks = n_tasks
        self.pbar = None
        self._monitor = None

    def __enter__(self):
        """Enters the context and starts monitoring.

        Initializes the parent Pool context and starts the memory monitor.

        Returns:
            MonitoredPool: The pool instance for use in the context.
        """
        super().__enter__()
        self._monitor = MemoryMonitor(self.n_tasks, self)
        self.pbar = self._monitor.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exits the context and stops monitoring.

        Stops the memory monitor and cleans up the parent Pool context.

        Args:
            exc_type: Exception type if an exception occurred.
            exc_val: Exception value if an exception occurred.
            exc_tb: Exception traceback if an exception occurred.

        Returns:
            None
        """
        if self._monitor:
            self._monitor.__exit__(exc_type, exc_val, exc_tb)
        super().__exit__(exc_type, exc_val, exc_tb)


def mapper(
    worker_func: collections.abc.Callable,
    fname: os.PathLike | str,
    pointers: list[pf.Pointer],
    callback: collections.abc.Callable = None,
    processes: int | bool = None,
    verbose: int = 0,
    kwargs: dict = None,
):
    """Executes a worker function in parallel across multiple items.

    This function provides parallel processing capabilities with optional
    progress monitoring and callback functionality. It handles
    argument packing, process management, and result collection.

    Useful for doing tasks over a large number of channels/events. Generally,
    each worker reads data from a (Fast5) file, does processing, and returns
    an output. HDF5 supports a `Single Writer Multiple Reader`_ arrangement,
    so each worker is free to read from file. Writing to the annotations file
    has to be done for one worker at a time, which is done at the completion
    of a task by a worker using a callback function in the main thread.

    Args:
        fname:
        worker_func (collections.abc.Callable): The function to execute in parallel.
            Must accept (fname, pointer, **kwargs) as arguments.
        handle (os.PathLike | str): The filename or path to pass to worker_func.
        pointers (list): Iterable of pointers to process in parallel.
        callback (collections.abc.Callable, optional): Function to call with each
            result. If provided, will be called as callback(result, lock=lock)
            or callback(result) depending on signature.
        processes (int | bool, optional): Number of worker processes. If None, uses
            multiprocessing.cpu_count(). If False, runs workers sequentially
            without using a pool.
        verbose (int, optional): Verbosity level:
            0: Silent operation
            1: Print worker startup information
            2: Show progress bar with memory monitoring
        kwargs (dict, optional): Additional keyword arguments to pass to worker_func.

    Returns:
        list: List of results from worker_func calls, in order of completion.


    .. _Single Writer Multiple Reader: https://docs.h5py.org/en/latest/swmr.html
    """
    if kwargs is None:
        kwargs = {}

    args = [
        (
            worker_func,
            (fname, pointer),
            dict(**kwargs),
        )
        for pointer in pointers
    ]

    results = []

    # Handle sequential execution when processes=False
    if processes is False:
        if verbose > 0:
            print(f"Running workers sequentially for {len(pointers)} items")

        for arg_set in args:
            result = _imap_worker_wrapper(arg_set)
            if callback:
                callback(result)
            results.append(result)
    else:
        pool_type = (
            MonitoredPool(len(args), processes)
            if verbose > 1
            else _spawn_ctx.Pool(processes=processes)
        )

        with pool_type as pool:
            if verbose > 0:
                print(
                    f"Starting {pool._processes} workers for {len(pointers)} items"
                )

            for result in pool.imap(_imap_worker_wrapper, args, chunksize=1):
                if callback:
                    callback(result)

                results.append(result)

                if verbose > 1:
                    if hasattr(pool, "pbar"):
                        pool.pbar.update(1)

    return results
