import numpy as np
import pandas as pd

import poreflow as pf
from poreflow import utils


class StepsDataFrame(pd.DataFrame):
    """Steps data frame

    Data frame must contain the following columns:
    - start_idx (integers): The start index of the step in the event
    - end_idx (integers): The end index of the step in the event
    - std (float): The standard deviation of the current during the step
    - mean (float): The mean of the current during the step
    - n_pts (int): The number of points in the step

    Other optional columns are:
    - start_time (float): The start time of the step
    - end_time (float): The end time of the step
    - dwell_time (float): The dwell time of the step
    - event (int): The event number of the step. Useful when concatenating
      multiple step dataframes
    - step_idx (int): The index of the step in the event


    """

    _metadata = [
        "sfreq",
    ]

    def __init__(self, data=None, *args, sfreq=None, **kwargs):
        super().__init__(data, *args, **kwargs)
        self.sfreq = sfreq

    @property
    def has_times(self):
        return (
            pf.START_TIME_COL in self.columns
            and pf.END_TIME_COL in self.columns
            and pf.DWELL_TIME_COL in self.columns
        )

    def calculate_times(self):
        utils.calculate_times(self, self.sfreq, duration_col=pf.DWELL_TIME_COL)

    def ensure_times(self):
        if not self.has_times:
            self.calculate_times()

    @property
    def _constructor(self):
        return StepsDataFrame

    def as_dataframe(self):
        """Converts the StepsDataFrame to a regular pandas DataFrame.

        Returns:
            pd.DataFrame: Regular pandas DataFrame without poreflow metadata.
        """
        return pd.DataFrame(self)

    def add_channel(self, channel: int = 1):
        """Adds a channel column to the DataFrame.

        Args:
            channel (int): Channel number to add. Defaults to 1.

        Returns:
            None
        """
        self[pf.CHANNEL_COL] = channel

    def add_event(self, event: int = 1):
        """Adds an event column to the DataFrame.

        Args:
            event (int): Event number to add. Defaults to 1.

        Returns:
            None
        """
        self[pf.EVENT_COL] = event

    def add_step_idx(self):
        """Adds a step index column to the DataFrame.

        Adds sequential step indices starting from 0.

        Returns:
            None
        """
        self[pf.STEP_IDX_COL] = np.arange(len(self), dtype=int)


class NoStepsDataFrame(StepsDataFrame):
    def __init__(self, sfreq: float = None):
        super().__init__(
            columns=[
                pf.START_IDX_COL,
                pf.END_IDX_COL,
                pf.N_PTS_COL,
                pf.MEAN_COL,
                pf.STD_COL,
            ],
            sfreq=sfreq,
        )
