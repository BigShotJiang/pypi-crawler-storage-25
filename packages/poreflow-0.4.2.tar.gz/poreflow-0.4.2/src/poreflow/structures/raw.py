import os
import typing

import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

import poreflow as pf
from poreflow import BaseDataFrame, EventsDataFrame
from poreflow.utils import poly_text


class RawDataFrame(BaseDataFrame):
    @property
    def _constructor(self):
        return RawDataFrame

    def plot(
        self,
        y: str = "i",
        x: str | np.ndarray = "abs",
        ax=None,
        ms=False,
        stats: bool | str = True,
        ios: bool = True,
        max_points=0,
        hue=None,
        events: pf.EventsDataFrame = None,
        **kwargs,
    ):
        """

        Args:
            y:
            events:
            ios:
            ms:
            stats:
            x:
            ax:
            max_points:
            hue (str, optional): Column to find states in
            **kwargs:

        Returns:

        """
        if ax is None:
            fig, ax = plt.subplots(figsize=pf.FIGSIZE_WIDE, dpi=150)

        plot_obj = _plot_downsample_to_max_points(self, max_points)

        if hue is not None:
            y_array = plot_obj._plot_y_parse(y)
            hues = plot_obj[hue].unique()
            hues.sort()
            for hue_sele in hues:
                y_masked = np.ma.masked_where(
                    plot_obj[hue] != hue_sele, y_array
                )
                super(RawDataFrame, plot_obj).plot(
                    y_masked, x, ax, ms, stats, ios=False, label=hue_sele
                )
            ax.legend(loc="lower left", title=hue, ncol=1)
        else:
            super(RawDataFrame, plot_obj).plot(
                y, x, ax, ms, stats, ios=False, **kwargs
            )

        if events is not None:
            _plot_event_spans(events, ax)

        self.plot_ios(ax, ios, x, y)

        return ax

    def _add_plot_labels(self, ax, y):
        ax.set_xlabel("$t$ (s)")
        ax.set_ylabel(pf.Y_LABELS.get(y, "Value"))
        ax.set_title(getattr(self, "name", ""), fontsize=7)

    def plot_ios(self, ax, ios, x: str | np.ndarray, y="i") -> plt.Axes:
        if not ios or y != "i" or self.ios is None:
            return ax

        if not isinstance(self.ios, np.polynomial.Polynomial):
            raise TypeError(
                "Open state current fit 'ios' should be a polynomial"
            )

        x = self._plot_x_parse(x, 50)
        y = self.ios(x)

        ax.plot(x, y, color=pf.IOS_COLOR, linestyle="--")
        text = poly_text(self.ios, decimals=4)

        ax.text(
            0.99,
            0.99,
            text,
            ha="right",
            va="top",
            transform=ax.transAxes,
            color=pf.IOS_COLOR,
        )
        return ax

    def has_state(self):
        """Checks if the DataFrame has a state column.

        Returns:
            bool: True if the DataFrame contains a state column.
        """
        return pf.STATE_FIELD_NAME in self

    def reset_states(self):
        """Resets all states to the good state value.

        Returns:
            None
        """
        self[pf.STATE_FIELD_NAME] = pf.GOOD_STATE

    @classmethod
    def from_labview(
        cls,
        filename: os.PathLike,
        sfreq: typing.Optional[float] = 5000,
        bfreq: float = None,
        bamp: float = None,
        verbose: bool = False,
    ) -> "RawDataFrame":
        """
        Reads measurement data from a LabView .dat file and creates a Raw data object.

        Args:
            verbose:
            filename (os.PathLike): Path to the measurement data file to be loaded.
            sfreq (typing.Optional[float]): Target frequency for optional downsampling. Defaults to 5000 Hz.
            bfreq (typing.Optional[float]): Bias voltage frequency in Hz. Defaults to None, which corresponds to a constant
                voltage measurement.
            bamp (typing.Optional[float]): Bias voltage amplitude in mV. Defaults to None, which corresponds to a constant
                voltage measurement.

        Returns:
            poreflow.base.RawDataFrame: A RawDataFrame object containing the processed voltage and current data.
        """

        from poreflow.io import labview

        return labview.read_measurement_dat(
            filename,
            verbose=verbose,
            downsample_to_freq=sfreq,
            bfreq=bfreq,
            bamp=bamp,
        )

    @property
    def i_loc(self):
        """Get column index for current data.

        Returns:
            int: Column index of the current data column.
        """
        return self.columns.get_loc(pf.CURRENT_COL)

    @property
    def v_loc(self):
        """Get column index for voltage data.

        Returns:
            int: Column index of the voltage data column.
        """
        return self.columns.get_loc(pf.VOLTAGE_COL)

    def find_events(self, **kwargs) -> pf.EventsDataFrame:
        from poreflow.events import detection

        return detection.find_events(self, **kwargs)

    def add_event_number_to_raw(self, events: pf.EventsDataFrame):

        if self.sfreq != events.sfreq:
            raise ValueError(
                f"Sampling rate of events and raw must be equal. "
                f"Raw has a sampling rate {self.sfreq}, while events have {events.sfreq}."
            )

        raw = self.copy()
        raw.loc[:, pf.EVENT_COL] = 0
        col_idx = raw.columns.get_loc(pf.EVENT_COL)

        idxs = events[[pf.START_IDX_COL, pf.END_IDX_COL]]
        idxs -= raw.start_idx

        for j, (start, end) in idxs.iterrows():
            raw.iloc[start : end - 1, col_idx] = j + 1

        return raw

    def plot_with_events(
        self,
        events: pf.EventsDataFrame,
        ax=None,
        edgecolor=None,
        s=1,
        legend=False,
        **kwargs,
    ) -> plt.Axes:
        if len(self) > pf.RAW_PLOT_TARGET_POINTS:
            target_freq = pf.RAW_PLOT_TARGET_POINTS / (len(self) / self.sfreq)
            raw = self.downsample(target_freq)
        else:
            raw = self

        raw = raw.add_event_number_to_raw(events)

        if ax is None:
            fig, ax = plt.subplots(figsize=pf.FIGSIZE_WIDE, dpi=150)

        mask = raw[pf.EVENT_COL] != 0

        kwargs["edgecolor"] = edgecolor
        kwargs["s"] = s
        kwargs["y"] = "i"
        kwargs["ax"] = ax
        kwargs["legend"] = legend

        if mask.any():
            sns.scatterplot(
                data=raw[mask], x=raw.t[mask], hue=pf.EVENT_COL, **kwargs
            )

        mask = ~mask  # Invert mask
        alpha = kwargs.pop("alpha", 1)
        kwargs.pop("palette", None)

        sns.scatterplot(
            data=raw[mask],
            x=raw.t[mask],
            alpha=0.25 * alpha,
            color=".5",
            **kwargs,
        )

        self._add_plot_labels(ax, "i")

        return ax


def _plot_event_spans(events: EventsDataFrame, ax: plt.Axes):
    """Overlays event regions as shaded spans on the axes."""
    from matplotlib.patches import Patch

    for start, end in zip(events[pf.START_TIME_COL], events[pf.END_TIME_COL]):
        ax.axvspan(start, end, color=".5", alpha=0.1, ec=None, zorder=-1)

    ax.legend(
        handles=[Patch(facecolor="0.5", alpha=0.3, label="Events")],
        loc="upper left",
    )


def _plot_downsample_to_max_points(
    df: RawDataFrame, max_points: int
) -> RawDataFrame:
    """Downsamples DataFrame to a maximum number of points for plotting.

    Args:
        df (RawDataFrame): DataFrame to downsample.
        max_points (int): Maximum number of points for plotting.

    Returns:
        RawDataFrame: Downsampled DataFrame.
    """
    if (max_points <= 0) or (len(df) < max_points):
        plot_obj = df
    else:
        target_freq = max_points / (len(df) / df.sfreq)
        plot_obj = df.downsample(target_freq)
    return plot_obj
