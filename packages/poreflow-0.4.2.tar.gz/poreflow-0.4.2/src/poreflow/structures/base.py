#
#      Copyright (C) 2024 Thijn Hoekstra
#
#      This program is free software: you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation, either version 3 of the License, or
#      (at your option) any later version.
#
#      This program is distributed in the hope that it will be useful,
#      but WITHOUT ANY WARRANTY; without even the implied warranty of
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#      GNU General Public License for more details.
#
#      You should have received a copy of the GNU General Public License
#      along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#
import pathlib
import typing
import warnings

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from numpy import ndarray

import poreflow as pf
from poreflow import utils


class BaseDataFrame(pd.DataFrame):
    # normal properties
    _metadata = [
        "sfreq",
        "name",
        "bdc",
        "bamp",
        "bfreq",
        "ios",
        "channel",
        "start_idx",
        "sfreq_original",
        "filter_cutoff",
    ]

    def __init__(
        self,
        data=None,
        *args,
        sfreq=None,
        name=None,
        bdc: float = None,
        bamp: float = None,
        bfreq: float = None,
        ios: float | np.polynomial.Polynomial = None,
        channel: int = 0,
        start_idx: int = 0,
        **kwargs,
    ):
        super().__init__(data, *args, **kwargs)
        self.sfreq = sfreq
        self.name = name
        self.bdc = bdc
        self.bamp = bamp
        self.bfreq = bfreq
        self.ios = ios
        self.channel = channel
        self.start_idx = start_idx
        self.sfreq_original = sfreq
        self.filter_cutoff = None

        if isinstance(data, BaseDataFrame):
            self._copy_attrs(data)

    def _copy_attrs(self, other: "BaseDataFrame"):
        """Copy attributes from other DataFrame to this DataFrame."""
        for attr in other._metadata:
            other_value = getattr(other, attr)
            value = getattr(self, attr)
            setattr(self, attr, value or other_value)

    @property
    def _constructor(self):
        return BaseDataFrame

    @property
    def duration(self):
        return len(self) / self.sfreq

    def get_nyquist(self):
        """Calculates the Nyquist frequency.

        The Nyquist frequency is half the sampling frequency and represents
        the highest frequency that can be accurately represented in the signal.

        Returns:
            float: Nyquist frequency in Hz.
        """
        return self.sfreq / 2

    @property
    def t(self) -> np.ndarray:
        return self.get_t()

    @property
    def start_time(self) -> float:
        return self.start_idx / self.sfreq

    def get_t(self, absolute=False, n: int = None) -> np.ndarray:
        """Get time array

        Args:
            absolute (bool, optional): Whether to return absolute time (start from start time). Defaults to False.
            n (int, optional): Number of time points to return. Defaults to None, in which case an number of time points is equal to the current data is returned

        Returns:

        """
        if n is None:
            t = np.arange(len(self)) / self.sfreq
        else:
            t = np.linspace(0, self.duration, n)

        if absolute:
            t += self.start_idx / self.sfreq
        return t

    @property
    def t_ms(self):
        return self.t * 1000

    def downsample(
        self,
        to: float = None,
        cols: list = None,
    ):
        if to is None or to >= self.sfreq:
            return self
        df = self.apply_filter(to, cols, method="decimate")

        if df.start_idx is not None:
            df.start_idx = int(self.start_idx * df.sfreq / self.sfreq)

        return df

    def apply_filter(
        self,
        cutoff: float,
        cols: list = None,
        method="bessel4",
        verbose: int = 0,
    ):

        if cols is None:
            cols = [pf.VOLTAGE_COL, pf.CURRENT_COL]

        mask = self.columns.isin(cols)
        if not mask.all():
            message = f"Downsampling columns {cols}. Other columns among columns {self.columns} will be truncated."
            if verbose == 1:
                print(message)
            elif verbose == 2:
                warnings.warn(message)

        if mask.sum() == 0:
            raise ValueError(
                f"No columns to downsample. Requested {cols}, while columns in DataFrame are {self.columns}."
            )

        cols = self.columns[mask]

        df = self.copy()
        n = None
        for col in cols:
            col_idx = self.columns.get_loc(col)

            x = self[col]

            dtype = x.dtype
            x = utils.apply_filter(
                x.astype(np.float64), self.sfreq, cutoff, method=method
            )
            n = x.shape[0]

            df.iloc[:n, col_idx] = x.astype(dtype)

        if method == "decimate":
            q = round(len(self) / n)  # Find downscale factor used

            if q == 1:
                return self

            other_cols = self.columns.get_indexer(self.columns[~mask])
            df.iloc[:n, other_cols] = df.iloc[::q, other_cols]

            df = df.truncate(
                after=self.index[n - 1]
            )  # Sample every q-th value in other columns

            # Calculate new sfreq if using decimation
            df.sfreq = self.sfreq / q
        else:
            df.filter_cutoff = cutoff

        return df

    def plot(
        self,
        y: str | np.ndarray = "i",
        x: str | np.ndarray = "abs",
        ax: plt.Axes = None,
        ms=False,
        stats: bool | str = True,
        ios: bool = True,
        **kwargs,
    ):
        if ax is None:
            fig, ax = plt.subplots(figsize=pf.FIGSIZE_WIDE, dpi=150)

        ax.plot(self._plot_x_parse(x), self._plot_y_parse(y), **kwargs)

        if ios and y != "v" and self.ios is not None:
            ax.axhline(self.ios, color=".5", linestyle="--")

        ax.set_xlabel("$t$ (s)")
        ax.set_ylabel(
            pf.Y_LABELS.get(y, "Value") if isinstance(y, str) else "Value"
        )
        title = getattr(self, "name", "")

        ax.set_title(title, fontsize=7 if len(title) > 25 else None)

        if stats:
            ax.text(
                0.98,
                0.02,
                self._plot_stats_parse(stats),
                ha="right",
                va="bottom",
                transform=ax.transAxes,
                color=pf.IOS_COLOR,
                bbox=dict(
                    facecolor="white",
                    edgecolor=".85",
                    boxstyle="round,pad=.1",
                    alpha=0.75,
                ),
            )

        return ax

    def _plot_y_parse(self, y: str | ndarray) -> pd.Series | ndarray:
        return self.loc[:, y] if isinstance(y, str) else y

    def _plot_x_parse(
        self, x: str | ndarray, n: int = None
    ) -> np.ndarray | pd.Series:
        if x == "abs":
            return self.get_t(True, n)
        elif x == "rel":
            return self.get_t(False, n)
        elif isinstance(x, str):  # Column in dataframe
            x = self.loc[:, x]

            if n is not None:
                # Sample n values in x
                x = x[np.linspace(0, len(self) - 1, n, dtype=int)]

            return x
        else:
            return x

    def _plot_stats_parse(self, stats: str = True) -> str:
        if stats is True:
            stats = ""
        stats += (
            r"$f_s^{\,\text{original}}= " + f"{self.sfreq_original:.0f}$ Hz"
        )
        if self.sfreq != self.sfreq_original:
            stats += "\n $f_s = " + f"{self.sfreq:.0f}$ Hz"

        if self.filter_cutoff is not None:
            stats += (
                "\n " + r"$f_\text{cutoff}= " + f"{self.filter_cutoff:.0f}$ Hz"
            )
        return stats

    def reset_indices(self):
        """Resets indices of data.

        Resets the start_idx to the first index and resets the DataFrame index
        to start from 0.

        Returns:
            None
        """
        self.start_idx = self.index[0]
        self.reset_index(inplace=True, drop=True)

    def save(self, path: typing.Union[str, pathlib.Path]):
        """Save data to an HDF5 file.

        Args:
            path (str or pathlib.Path): Path to save the file to.
        """
        with pd.HDFStore(path, "w") as store:
            store.put("data", self)
            metadata = {
                key: getattr(self, key)
                for key in self._metadata
                if hasattr(self, key) and getattr(self, key) is not None
            }
            store.get_storer("data").attrs.metadata = metadata

    @classmethod
    def load(cls, path: typing.Union[str, pathlib.Path]):
        """Load data from an HDF5 file.

        Args:
            path (str or pathlib.Path): Path to load the file from.

        Returns:
            BaseData: The loaded data.
        """
        with pd.HDFStore(path, "r") as store:
            data = store.get("data")
            metadata = store.get_storer("data").attrs.metadata
            sfreq = metadata.pop("sfreq", None)
            sfreq = metadata.pop("sfreq_original", None)
            return cls(data, sfreq=sfreq, **metadata)

    def is_varv(self):
        """Checks if the measurement uses variable voltage

        Returns:
            bool: True if bias frequency (bfreq) is not None, indicating
                 a variable voltage measurement.
        """
        return self.bfreq is not None

    def as_dataframe(self):
        """Converts the BaseDataFrame to a regular pandas DataFrame.

        Returns:
            pd.DataFrame: Regular pandas DataFrame without poreflow metadata.
        """
        return pd.DataFrame(self)
