"""CLI for poreflow."""

import webbrowser
from typing import Annotated

import typer
import waitress

from poreflow_dash.app import app as dash_app

app = typer.Typer()


@app.callback(invoke_without_command=True)
def main(
    port: int = 8041,
    prevent_open: Annotated[
        bool, typer.Option("--no-open", help="Do not open webpage in browser.")
    ] = False,
):
    """Main entry point for the poreflow CLI."""
    typer.echo("Starting poreFlow server...")
    url = f"http://localhost:{port}"

    typer.echo(typer.style(f"Serving app at {url}", fg="blue", underline=True))

    if not prevent_open:
        webbrowser.open(url)

    waitress.serve(
        dash_app.server, host="0.0.0.0", port=port, url_scheme="https"
    )


if __name__ == "__main__":
    main()
