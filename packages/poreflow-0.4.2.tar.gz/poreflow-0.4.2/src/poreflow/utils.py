#
#      Copyright (C) 2024 Thijn Hoekstra
#
#      This program is free software: you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation, either version 3 of the License, or
#      (at your option) any later version.
#
#      This program is distributed in the hope that it will be useful,
#      but WITHOUT ANY WARRANTY; without even the implied warranty of
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#      GNU General Public License for more details.
#
#      You should have received a copy of the GNU General Public License
#      along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import warnings

import scipy
import numpy as np
from matplotlib import pyplot as plt
from IPython.display import display, HTML
from numpy import ndarray

import poreflow as pf


def show_text(text: str) -> None:
    """Displays styled text in a Jupyter notebook output cell."""
    display(
        HTML(
            f'<p style="font-size:1.3em; font-weight:600; color:#576A8F">{text}</p>'
        )
    )


def apply_bessel_filter(
    x: np.ndarray,
    sfreq: float,
    cutoff: float = 1000,
    order: int = 4,
) -> np.ndarray:
    """Applies a zero-phase Bessel low-pass filter."""
    nyquist = sfreq / 2

    b, a = scipy.signal.bessel(order, cutoff / nyquist, btype="low")

    return scipy.signal.filtfilt(b, a, x)


def downsample(x: np.ndarray, sfreq: float, to: float = False) -> np.ndarray:
    """Downsamples a signal to a target sampling frequency.

    Args:
        x (np.ndarray): Input signal to downsample.
        sfreq (float): Original sampling frequency in Hz.
        to (float): Target sampling frequency in Hz. If False, no downsampling is performed.

    Returns:
        np.ndarray: Downsampled signal.
    """
    return apply_filter(x, sfreq, to, method="decimate")


def apply_filter(
    x: np.ndarray,
    sfreq: float,
    cutoff: float = False,
    verbose=False,
    method="bessel4",
) -> np.ndarray:
    """

    Args:
        x:
        sfreq:
        cutoff:
        verbose:
        method:

    Returns:

    Notes:
        With mode 'decimate' (default), the downsampled rate of the new signal
        is not garaunteed to be exactly the same as `downsample`.

    """
    if cutoff is False or cutoff is None:
        return x

    elif cutoff >= sfreq:
        if verbose:
            warnings.warn(
                f"Downsample frequency ({cutoff} Hz) is greater than or "
                f"equal to the original sampling frequency ({sfreq} Hz). "
                "No downsampling will be performed."
            )
        return x

    elif method == "decimate":
        return decimate(x, sfreq, cutoff)

    elif method == "bessel4":
        return apply_bessel_filter(x, sfreq, cutoff, order=4)

    else:
        raise ValueError(f"Unrecognized downsample method '{method}'")


def decimate(
    x: ndarray, sfreq: float, downsample: float, warn=False
) -> np.ndarray:
    q = float(sfreq / downsample)

    if warn and not q.is_integer():
        warnings.warn(
            f"Decimate ran with downsample set to {downsample} Hz, but "
            f"could only downsample by a exact factor 1/{q:.0f}, resulting "
            f"in a new sampling frequency {sfreq / q:0.1f} Hz."
        )
    q = round(q)

    if q > 1:
        x = scipy.signal.decimate(x, q)

    return x


def add_attrs(obj, **kwargs):
    """Adds attributes to an object.

    Args:
        obj: Object to add attributes to.
        **kwargs: Attribute names and values to add.

    Returns:
        None
    """
    for k, v in kwargs.items():
        setattr(obj, k, v)


def check_if_array_is_half_cycle(a: np.ndarray, period: int) -> None:
    """Checks if array contains data on half a cycle

    Checks if array contains data on half a bias votlage cycle. Such an array
    is referred to a 'long' matrix by Noakes et. al. (2019). In such an array,
    each row now corresponds to a single voltage, as opposed to a single phase
    point (each voltage point corresponds to two phase points, one for the up
    swing of the voltage cycle and one for the down swing.

    Args:
        a (np.ndarray): An array to check.
        period (int): The period of the bias votlage cycle in samples.
    """
    if a.ndim != 2:
        raise ValueError("Expected array to be 2-dimensional.")
    elif a.shape[0] == period:
        raise ValueError(
            f"Expected half-cycle array to have "
            f"{period // 2} rows, but instead got {a.shape[0]}. "
            f"You might have accidentally used a full-cycle array "
            f"instead."
        )
    elif a.shape[0] != period // 2:
        raise ValueError(
            f"Expected half-cycle array to have "
            f"{period // 2} rows, but instead got {a.shape[0]}."
        )


def check_if_array_is_full_cycle(a: np.ndarray, period: int) -> None:
    """Checks if array contains data on half a cycle

    Checks if array contains data on the full bias votlage cycle. In such an
    array each column contains the voltage/current data of a full bias votlage
    cycle. Each voltage has two columns, one for the up swing of the voltage
    cycle and one for the down swing.

    Args:
        a (np.ndarray): An array to check.
        period (int): The period of the bias votlage cycle in samples.
    """
    if a.ndim != 2:
        raise ValueError("Expected array to be 2-dimensional.")
    elif a.shape[0] == period // 2:
        raise ValueError(
            f"Expected half-cycle array to have "
            f"{period} rows, but instead got {a.shape[0]}. "
            f"You might have accidentally used a half-cycle array "
            f"instead."
        )
    elif a.shape[0] != period:
        raise ValueError(
            f"Expected half-cycle array to have "
            f"{period} rows, but instead got {a.shape[0]}."
        )


def get_tu_delft_cmap():
    """Gets a list of colors from the Delft University of Technology style guide"""
    # Matplotlib style
    # return [
    #     "#0076C2",
    #     "#EC6842",
    #     "#009B77",
    #     "#A50034",
    #     "#6F1D77",
    #     "#0C2340",
    #     "#EF60A3",
    #     "#6CC24A",
    #     "#FFB81C",
    #     "#00B8C8",
    # ]

    # Mixed style
    return [
        "#0C2340",
        "#00B8C8",
        "#0076C2",
        "#E03C31",
        "#EC6842",
        "#FFB81C",
        "#6F1D77",
        "#EF60A3",
        "#A50034",
        "#6CC24A",
        "#009B77",
        "#5C5C5C",
    ]

    # Rainbow style
    # return [
    #     "#0C2340",
    #     "#00B8C8",
    #     "#0076C2",
    #     "#6F1D77",
    #     "#EF60A3",
    #     "#E03C31",
    #     "#EC6842",
    #     "#FFB81C",
    #     "#6CC24A",
    #     "#009B77",
    #     "#5C5C5C",
    # ]


def get_phase_of_period(
    v_data: np.ndarray,
    period: int,
    max_length_to_check: int = 10000,
    min_amplitude: float = 1,
    invert: bool = True,
) -> int:
    """Finds the phase of a frequency of a known period.

    Args:
        v_data (np.ndarray): A numpy array containing the time series of bias
            voltage.
        period (int): The period in samples of the known bias frequency.
        max_length_to_check (int): Maximum number of samples in which to find a
            period and phase. Defaults to 10,000 samples. Speeds up Fourier
            transform.
        min_amplitude (float): The minimum amplitude in mV the bias frequency
            component should have. If this is not the case, the bias frequency
            is assumed to not be present and an error is raised.
       invert (bool): Whether to invert the phase. Defaults to True in which
            case the value returned is equivalent to a sample in the signal
            with zero phase shift. When set to False, the phase returned is
            the mathematical phase shift.

    Returns:
        An integer specifying the phase (offset) in samples of the bias
        frequency signal.


    Raises:
        ValueError: This error is raised when no Fourier component of
            significant amplitude is found in the arrays. This might mean that
            no AC bias votlage was applied during the measurement.
    """
    N = min(max_length_to_check, len(v_data))
    x = v_data[:N]
    k = N / period  # Frequency to look for
    fourier_component = (
        1 / N * np.sum(x * np.exp(-1j * k * 2 * np.pi / N * np.arange(N)))
    )

    if np.abs(fourier_component) < min_amplitude:
        raise ValueError(
            f"No AC voltage applied in first {N} points of file - could not "
            f"determine phase of component with period {period}. Found "
            f"component with magnitude {np.abs(fourier_component)}."
        )

    phase = get_phase_from_fourier_component(fourier_component, period)
    if invert:
        phase = (period - phase) % period
    return phase


def get_phase_from_fourier_component(
    fourier_component: np.complex128, period: int
) -> int:
    """Finds the phase in samples for a known complex fourier component.

    The complex fourier component is assumed to be the component associated to
    the frequency equivalent to `period`.

    Args:
        fourier_component (np.complex128): A complex fourier component of
            frequency related to the period.
        period (int): The period in samples.

    Returns:
        The phase in samples of that complex component.
    """
    phase = np.angle(fourier_component) / (2 * np.pi) * period

    if phase < 0:
        phase += period

    phase = round(phase % period)

    if phase == period:
        phase = 0

    return phase


def get_cov_cols(d: int) -> list:
    """Gets the columns of the covariance matrix in a feature dataframe

    Args:
        d: An integer specifying the number of features.
    """
    return [
        pf.COV_FORMAT.format(j, k)
        for j, k in np.mgrid[:d, :d].reshape((2, d**2)).T
    ]


def get_coef_cols(d):
    """Gets the columns of the feature coefficients in a feature dataframe

    Args:
        d: An integer specifying the number of features.
    """
    return [pf.COEF_FORMAT.format(j) for j in range(d)]


def fewer_ticks(ax, n_y: int = 3, n_x: int = None) -> None:
    """Makes a plot have fewer ticks"""
    ax.yaxis.set_major_locator(plt.MaxNLocator(n_y))
    if n_x is not None:
        ax.yaxis.set_major_locator(plt.MaxNLocator(n_x))


def bhattacharyya_distance(
    mu_1: np.ndarray, sigma_1: np.ndarray, mu_2: np.ndarray, sigma_2: np.ndarray
) -> float:
    """Computes the Bhattacharyya distance between two multivariate Gaussians.

    Supports array broadcasting for fast distance computations across multiple distirbutions.

    Args:
        mu_1: The mean of the first multivariate Gaussian.
        sigma_1: The covariance matrix of the first multivariate Gaussian.
        mu_2: The mean of the second multivariate Gaussian.
        sigma_2: The covariance matrix of the second multivariate Gaussian.
    """
    sigma = (sigma_1 + sigma_2) / 2

    term_1 = 0.125 * np.vecdot(
        mu_1 - mu_2, np.matvec(np.linalg.inv(sigma), (mu_1 - mu_2))
    )
    term_2 = 0.5 * np.log(
        np.linalg.det(sigma)
        / np.sqrt(np.linalg.det(sigma_1) * np.linalg.det(sigma_2))
    )

    return term_1 + term_2


def calculate_times(df, sfreq, duration_col: str = None):
    """Calculates time-related columns for a DataFrame.

    Adds start_time, end_time, and duration columns based on index columns
    and sampling frequency.

    Args:
        df: DataFrame containing index columns.
        sfreq: Sampling frequency in Hz.
        duration_col (str, optional): Name of the duration column. Defaults to pf.DURATION_COL.

    Returns:
        None: Modifies the DataFrame in place.

    Raises:
        ValueError: If sfreq is None.
    """
    if sfreq is None:
        raise ValueError("sfreq cannot be None")

    if duration_col is None:
        duration_col = pf.DURATION_COL

    df[pf.N_PTS_COL] = df[pf.END_IDX_COL] - df[pf.START_IDX_COL]
    df[pf.START_TIME_COL] = df[pf.START_IDX_COL] / df.sfreq
    df[pf.END_TIME_COL] = df[pf.END_IDX_COL] / df.sfreq
    df[duration_col] = df[pf.N_PTS_COL] / df.sfreq


def poly_text(
    poly: np.polynomial.Polynomial, decimals: int = 0, format="latex"
) -> str:
    poly = np.polynomial.Polynomial(poly.coef.round(decimals))
    if format == "latex":
        return r"$I_\text{OS}=" + f"{poly:ascii}$".replace("x", "t").replace(
            "**", "^"
        )
    elif format == "ascii":
        return f"{poly:ascii}".replace("x", "t")
    elif format == "unicode":
        return f"{poly:unicode}".replace("x", "t")

    else:
        raise ValueError(f"Unknown format '{format}' requested")
