class NoEventsDetectedException(Exception):
    """Exception raised when no events are detected in a nanopore sequencing file.

    This exception is raised by event detection when they fail to
    identify any events in the provided data.
    """

    pass
