import typing
from dataclasses import dataclass

from fast5_research.util import time_interval_to_index


@dataclass
class Pointer:
    """Pointer to location of data in a Fast5 file

    Attributes:
        channel (int): The channel in poreFlow notation (starting from 0)
        start_idx (int): The start index of the data
        end_idx (int): The end index of the data
        meta (dict): Metadata, e.g. event number.

    """

    channel: int
    start_idx: int = None
    end_idx: int = None
    meta: dict = None

    @property
    def raw_indices(self) -> tuple[int, int]:
        """Indices in ONT Fast5 format"""
        return self.start_idx, self.end_idx

    @property
    def tuples(self):
        """Useful for unpacking into BulkFast5.get_raw.

        Example:
            >>> pointer = Pointer(channel=0, start_idx=0, end_idx=1)
            >>> BulkFast5.get_raw(*pointer.tuples)

        Returns:
            A tuple with the channel, the times (always None), and the
            start and end indices. The first value of the tuple specifying the
            channel is +1 to conform to ONT channel conting.

        """
        return self.channel + 1, None, (self.start_idx, self.end_idx)

    def to_dict(self):
        """Converts the Pointer to a dictionary.

        Returns:
            dict: Dictionary representation of the Pointer.
        """
        return self.__dict__

    @classmethod
    def from_times_or_indices(
        cls,
        sfreq: float,
        channel: int = 0,
        times: typing.Optional[typing.Tuple[float, float]] = None,
        index: typing.Optional[typing.Tuple[int, int]] = None,
    ):
        if times and index:
            raise ValueError("Provide either 'times' or 'index', not both.")

        raw_indices = (0, None)
        if times:
            raw_indices = time_interval_to_index(times, sfreq)
        elif index:
            raw_indices = index

        return cls(channel, *raw_indices)
