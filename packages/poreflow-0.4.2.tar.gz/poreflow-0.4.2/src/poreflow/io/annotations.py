import os
import pathlib

import h5py
import numpy as np
import pandas as pd

import poreflow as pf

META_GROUP_NAME = "Meta"


DESCRIBES_ATTR_NAME = "describes"


def _remove_index(df):
    """Removes index column from DataFrame if present.

    Args:
        df: DataFrame to process.

    Returns:
        DataFrame: DataFrame with index column removed and set as actual index.
    """
    if "index" in df.columns:
        df = df.set_index("index")
        df.index.name = None
    return df


def is_annotation(fname: str | os.PathLike) -> bool:
    """Checks if a file is an annotation file.

    Args:
        fname (str | os.PathLike): File path to check.

    Returns:
        bool: True if the file has the annotation file extension.
    """
    return "".join(pathlib.Path(fname).suffixes) == pf.ANNOT_SUFFIX


def get_stem(fname: str) -> str:
    """Get stem twice to remove double extensions.

    Args:
        fname (str): File path to process.

    Returns:
        str: File stem with double extensions removed.
    """
    fname = pathlib.Path(fname).stem
    return pathlib.Path(fname).stem


def with_suffix(fname: str, ext: str = None) -> pathlib.Path:
    """Adds or replaces file extension.

    Args:
        fname (str): Original file path.
        ext (str, optional): Extension to use. Defaults to annotation extension.

    Returns:
        pathlib.Path: Path with new extension.
    """
    if ext is None:
        ext = pf.ANNOT_SUFFIX
    fname = get_stem(fname)
    return pathlib.Path(fname).with_suffix(ext)


def get_default_annotations_filename(fname: str | os.PathLike) -> pathlib.Path:
    """Gets the default annotation filename for a data file.

    Args:
        fname (str | os.PathLike): Data file path.

    Returns:
        pathlib.Path: Default annotation file path.
    """
    return pathlib.Path(fname).with_suffix(pf.ANNOT_SUFFIX)


class Annotation(h5py.File):
    def __init__(self, fname, mode="r+", **kwargs):
        """

        Args:
            fname:
            mode:
            **kwargs:
        """
        if mode in ("r", "r+"):
            kwargs.setdefault("locking", False)
        super().__init__(fname, mode=mode, **kwargs)

        self.directory = pathlib.Path(fname).parent
        self.describes = self[META_GROUP_NAME].attrs[DESCRIBES_ATTR_NAME]

    @classmethod
    def New(cls, fname: os.PathLike, describes: os.PathLike):
        """Construct a new annotation.

        Args:
            fname:
            describes: Must be just the filename, annotation is supposed to be next to the file.

        """

        # Start a new file, populate it with meta
        with h5py.File(fname, "w") as h:
            import platform

            g = h.create_group(META_GROUP_NAME)
            g.attrs["poreflow_version"] = pf.__version__
            g.attrs["python_version"] = platform.python_version()
            g.attrs[DESCRIBES_ATTR_NAME] = str(describes)

        # return instance from new file
        return cls(fname, "r+")

    def _dataset_setter(
        self, df: pd.DataFrame | None, dataset: str, mode, update_index=True
    ) -> None:
        if df is None:
            if dataset in self:
                del self[dataset]
            return None

        if df is None and mode != "w":
            raise ValueError(
                "Cannot delete events in append (a) mode, set to write (w)."
            )
        # Convert to records
        rec = df.to_records(index=True)
        if mode not in ("w", "a"):
            raise ValueError(f"Mode {mode} not recognized. Use 'w' or 'a'.")
        if (mode == "a") and (dataset in self):
            dset = self[dataset]

            n = dset.shape[0]
            if update_index:
                rec["index"] += n  # Update index of inserted table

            dset.resize((n + rec.shape[0],))
            dset[-rec.shape[0] :] = rec
            return None

        elif (mode == "w") and (dataset in self):
            del self[dataset]  # Overwrite later

        self.create_dataset(dataset, data=rec, maxshape=(None,), chunks=True)
        return None

    def _dataset_getter(self, dataset, strict=False) -> pd.DataFrame | None:
        if dataset not in self and strict:
            raise KeyError(f"{dataset} not found in {self.filename}")
        elif dataset not in self:
            return None

        dset = self[dataset]
        data = dset[:]

        return pd.DataFrame.from_records(data)

    @property
    def has_events(self) -> bool:
        """Checks if events are stored in on disk.

        Returns:
            bool: True if events dataset exists in annotation, False otherwise.
        """
        return pf.EVENTS_DATASET in self

    def get_events(self) -> pd.DataFrame | None:
        """Reads events from disk.

        Returns:
            pandas.DataFrame: DataFrame containing events.
        """

        df = self._dataset_getter(pf.EVENTS_DATASET)
        if df is None:
            return None
        return _remove_index(df)

    @property
    def events(self) -> pd.DataFrame:
        return self.get_events()

    @events.setter
    def events(self, df: pd.DataFrame) -> None:
        self.set_events(df)

    def set_events(
        self, df_events: pd.DataFrame | None, mode: str = "w"
    ) -> None:
        """Saves events to disk.

        Args:
            df_events (pandas.DataFrame): Events to save. Set None to delete all events store on disk.
            mode (str): Whether to replace ('w') or append ('a') to existing events on disk.
        """

        self._dataset_setter(df_events, pf.EVENTS_DATASET, mode)

    def remove_events(
        self,
        channels: int | list[int] | None = None,
        events: int | list[int] | None = None,
        include_steps=True,
    ) -> None:
        """Removes events from specific channels or all events.

        Args:
            include_steps:
            events:
            channels (int | list[int] | None):
                - If int: Remove events from the specified channel only.
                - If list[int]: Remove events from the specified channels.
                - If None: Remove all events from all channels.

            include_ios (bool): Whether to also delete the ios fit for the specified channels.

        Returns:
            None

        Todo: Docs

        """
        if not self.has_events:
            return

        existing_df = self.get_events()

        if events is not None and channels is not None:
            raise ValueError(
                "Must either specify either events or channels with events to delete, not both"
            )

        elif events is None and channels is None:
            self.set_events(None)
            if include_steps:
                self.set_steps(None)

            return

        if channels is not None:
            if isinstance(channels, (int, np.integer)):
                channels = [channels]

            events = existing_df.index.to_numpy()[
                existing_df[pf.CHANNEL_COL].isin(channels)
            ]
        else:
            if isinstance(events, (int, np.integer)):
                events = [events]

        updated_df = existing_df.drop(events, axis=0)

        if len(updated_df) > 0:
            updated_df = updated_df.reset_index(drop=True)

            self.set_events(updated_df)
            if include_steps:
                self.remove_steps(events, reindex=True)

            return

        self.set_events(None)
        if include_steps:
            self.set_steps(None)

    @property
    def has_steps(self) -> bool:
        """Checks if the file contains steps.

        Returns:
            bool: True if steps dataset exists in annotation, False otherwise.
        """
        return pf.STEPS_DATASET in self

    @property
    def steps(self) -> pd.DataFrame:
        return self.get_steps()

    @steps.setter
    def steps(self, df: pd.DataFrame) -> None:
        self.set_steps(df)

    def get_steps(self) -> pd.DataFrame | None:
        """Reads events from disk.

        Returns:
           pf.StepsDataFrame: DataFrame containing events.
        """

        df = self._dataset_getter(pf.STEPS_DATASET)
        if df is None:
            return None
        return _remove_index(df)

    def set_steps(self, df_steps: pd.DataFrame | None, mode: str = "w") -> None:
        """Saves steps to disk.

        Args:
            df_steps (poreflow.StepsDataFrame): Steps to save. Set None to delete all events store on disk.
            mode (str): Whether to replace ('w') or append ('a') to existing steps on disk.
        """
        self._dataset_setter(df_steps, pf.STEPS_DATASET, mode)

    def create_ios_fit_dataset(self, degree: int, channels: list[int]):

        if pf.IOS_FIT_DATASET in self:
            del self[pf.IOS_FIT_DATASET]
        columns = [f"c{j}" for j in range(degree + 1)]
        df = pd.DataFrame(0, columns=columns, index=channels, dtype=float)
        rec = df.to_records()

        return self.create_dataset(
            pf.IOS_FIT_DATASET,
            rec.shape,
            data=rec,
        )

    @property
    def has_ios(self) -> bool:
        """Checks if the file contains open state current fit data.

        Returns:
            bool: True if steps dataset exists in annotation, False otherwise.
        """
        return pf.IOS_FIT_DATASET in self

    def set_ios(self, p: np.polynomial.Polynomial, channel: int = 0) -> None:
        """Stores the open state current for a channel on disk.

        Stores the open state current, expressed as a polynomial of degree
        `N`, on disk. Creates an `N` x `M` array on disk, where `M` is the
        number of channels and stores the coefficients of the polynomial in
        this table.

        Args:
            p (np.polynomial.Polynomial): A polynomial describing the open state current for a channel.
            channel (int): Which channel the polynomial describes.

        Todo:
            Raise an error if the existing table if for a different degree than
            the input polynomial `p`.
        """
        if pf.IOS_FIT_DATASET not in self:
            raise IOError(
                f"Open state current dataset ({pf.IOS_FIT_DATASET}) not found in {self.filename}. Please create it first."
            )

        dset = self[pf.IOS_FIT_DATASET]

        if p is None:
            n_coef = len(dset[0]) - 1
            coef = np.full(n_coef, np.nan)
        else:
            coef = p.coef

        index = np.argmax(dset["index"] == channel)
        dset[index] = [tuple([channel] + coef.tolist())]

    @property
    def ios_table(self) -> pd.DataFrame | None:
        """Retrieves the polynomial coefficients for the open state current fits on disk.

        Retrieves the open state currents, expressed as a polynomial of degree
        `N`, on disk. The returned table is `N` x `M` table, where `M` is the
        number of channels. This table contains the coefficients of the polynomial of
        the open state fit of the various channels of the measurement.

        Returns:
            pd.DataFrame: DataFrame containing open state current polynomial fits for each channel. None if no data on disk.

        """

        if pf.IOS_FIT_DATASET not in self:
            return None

        dset = self[pf.IOS_FIT_DATASET]

        df = pd.DataFrame.from_records(dset[:])

        return _remove_index(df)

    @property
    def ios_n_coef(self):
        """Number of open state fit coefficients in the table"""
        return self.ios_table.columns.size

    @property
    def ios_degree(self):
        """Order of the open state fits stored in the table"""
        return self.ios_n_coef - 1

    def get_ios(self, channel: int = 0) -> np.polynomial.Polynomial | None:
        """Gets the polynomial fit of a channel's open state current fit

        Args:
            channel (int, optional): Which channel to retrieve the open state fit for. Defaults to 0.

        Returns:
            np.polynomial.Polynomial: Polynomial describing open state current polynomial fits for a channel.

        """
        if pf.IOS_FIT_DATASET not in self:
            return None

        df = self.ios_table
        coef = df.loc[channel]

        if np.isnan(coef).all() or (coef == 0).all():
            return None

        return np.polynomial.Polynomial(coef)

    def remove_ios(self, channels: int | list[int] | None = None) -> None:
        """Removes open state current fits from specific channels or all channels.

        Instead of deleting the entries, sets the polynomial coefficients to NaN
        to preserve the dataset structure.

        Args:
            channels (int | list[int] | None):
                - If int: Remove IOS fit from the specified channel only.
                - If list[int]: Remove IOS fits from the specified channels.
                - If None: Remove IOS fits from all channels.

        Returns:
            None
        """
        if not self.has_ios:
            return

        dset = self[pf.IOS_FIT_DATASET]

        if channels is None:
            del self[pf.IOS_FIT_DATASET]
        else:
            if isinstance(channels, (int, np.integer)):
                channels = [channels]

            for channel in channels:
                index = np.argmax(dset["index"] == channel)
                n_coef = (
                    len(dset[index]) - 1
                )  # Subtract 1 for the channel index
                coef = np.full(n_coef, np.nan)
                dset[index] = tuple([channel] + coef.tolist())

    def remove_steps(
        self, events: int | list[int] = None, reindex: bool = False
    ) -> None:

        if not self.has_steps:
            return

        if events is not None:
            if isinstance(events, (int, np.integer)):
                events = [events]

            updated_steps = self.steps[~self.steps[pf.EVENT_COL].isin(events)]

            if len(updated_steps) > 0:
                updated_steps = updated_steps.reset_index(drop=True)

                if reindex:
                    # Replace event index in steps table
                    to_replace = updated_steps[pf.EVENT_COL].unique()
                    values = np.arange(len(to_replace), dtype=int)

                    updated_steps.loc[:, pf.EVENT_COL] = updated_steps[
                        pf.EVENT_COL
                    ].replace(to_replace, values)
                    updated_steps = updated_steps.reset_index(drop=True)

                self.steps = updated_steps
                return

        # Clear all if none left
        self.set_steps(None)
