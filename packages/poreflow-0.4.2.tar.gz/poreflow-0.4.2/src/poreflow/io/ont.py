#
#  Copyright (C) 2024 Thijn Hoekstra
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
import os
import pathlib
import typing
import warnings
import functools

import numpy as np
import pandas as pd

from fast5_research.fast5_bulk import BulkFast5

import poreflow as pf
from poreflow.parallel import mapper
from poreflow.io import annotations

META_GROUP_NAME = "Meta"
META_DURATION_ATTR_NAME = "duration_samples"
META_SFREQ_ATTR_NAME = "sample_rate"


def _handle_conversion(
    filename, verbose, force_conversion: bool = False
) -> pathlib.Path:
    """
    Validates the file path and converts .dat to .fast5 if necessary.
    """

    p = pathlib.Path(filename)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {filename}")

    if p.suffix == ".fast5":
        return p
    elif p.suffix == ".dat":
        from poreflow.io import labview

        fast5_path = p.with_suffix(".fast5")
        if not force_conversion and fast5_path.exists():
            return fast5_path
        else:
            warning_message = f"Converting {filename} to {fast5_path}. This may take a moment..."
            if verbose == 2:
                warnings.warn(warning_message)
            elif verbose == 1:
                print(warning_message)

            labview.convert_to_fast5(filename, fast5_path)
            return fast5_path
    else:
        raise ValueError("File must be a .fast5 or .dat file")


def _handle_annotation(
    fname: os.PathLike,
    annotation_name: os.PathLike = None,
    search_path: os.PathLike = None,
    verbose: int = 0,
    mode: str = "r+",
):
    fname = pathlib.Path(fname)
    parent = fname.parent

    if annotation_name is None:
        expected_annot_path = annotations.get_default_annotations_filename(
            fname
        )
    else:
        expected_annot_path = annotations.with_suffix(annotation_name)
        expected_annot_path = parent / expected_annot_path

    if search_path is not None:
        search_path = pathlib.Path(search_path)

        if not search_path.is_absolute():
            search_path = parent / search_path

        expected_annot_path = search_path / expected_annot_path.name

    expected_exists = expected_annot_path.exists()

    if annotations.is_annotation(fname) and annotation_name is not None:
        raise ValueError(
            f"Requested file using annotation file {fname} but also specified name annotation name to create {annotation_name}. "
            f"Keep annotation_name None if loading a data file using an annotation."
        )
    elif annotations.is_annotation(fname):
        # File is annotation.
        try:
            annotator = annotations.Annotation(fname, mode=mode)
        except FileNotFoundError as e:
            raise FileNotFoundError(
                f"Requested file using annotation file {fname} but not found on disk."
            ) from e

        if verbose:
            print(
                f"Requested file using annotation file, loading data file {annotator.describes}."
            )

        if search_path is None:
            data_path = annotator.describes  # Search current directory
        else:
            data_path = search_path / annotator.describes
        return annotator, data_path

    elif fname.suffix in pf.SUFFIXES and expected_exists:
        # File already has default annotation. Open this annotation
        annotator = annotations.Annotation(expected_annot_path, mode=mode)

        if pathlib.Path(annotator.describes).stem != fname.stem:
            raise ValueError(
                f"Loading data file {fname}. \n"
                f"Found default annotation file {annotator.filename}, \n"
                f"but this file annotates was written for "
                f"{annotator.describes} instead."
            )

        if verbose:
            print(
                f"Requested file {fname.name}, found default annotation file {expected_annot_path} which will be used."
            )

        return annotator, fname

    elif fname.suffix in pf.SUFFIXES:
        # No annotation yet, create it
        if search_path is not None:
            search_path.mkdir(parents=True, exist_ok=True)
        annotator = annotations.Annotation.New(expected_annot_path, fname.name)

        if verbose:
            print(
                f"Requested file {fname.name}, no annotation file found. Creating annotation file {expected_annot_path}."
            )

        return annotator, fname

    else:
        raise ValueError(
            f"Could not interpret whether file {fname} is an annotation or a data file. "
            f"Ensure it's a {pf.ONT_SUFFIX}, {pf.UTUBE}, or .annot.fast5 file. "
            f""
        )


class DataFile(BulkFast5):
    def __init__(self, filename, verbose=0, force_conversion=False):
        filename = _handle_conversion(filename, verbose, force_conversion)

        super().__init__(str(filename), "r")

        self._name = None

    @property
    def name(self) -> str:
        """Gets or sets a pretty name for the file.

        Gets a human-readable name for the file. If no custom name is set,
        returns the filename.

        Returns:
            str: The pretty name
        """
        return (
            self._name
            if self._name is not None
            else pathlib.Path(self.filename).stem
        )

    @name.setter
    def name(self, value: str):
        """Sets a custom pretty name for the file.

        Args:
            value (str): The custom name to set.

        Returns:
            None
        """
        self._name = value

    @property
    def device(self):
        """Identifies the device type from tracking metadata.

        Returns:
            str: Either pf.UTUBE or pf.ONT depending on device ID.
        """
        if self.tracking_meta["device_id"] == pf.UTUBE:
            return pf.UTUBE
        else:
            return pf.ONT

    def get_channels(self):
        """Gets a list of available channels in the file.

        Retrieves channel numbers from the file, converting from ONT's 1-based
        indexing to poreFlow's 0-based indexing.

        Returns:
            list: List of channel numbers (0-indexed) available in the file.

        Note:
            ONT stores channels in Fast5 files starting from 1. Channels
            in poreFlow are indexed from 0. So 0 --> Channel 1, etc.
        """
        data = self[self.__intermediate_data__]
        return sorted([int(name.strip("Channel_")) - 1 for name in data.keys()])

    def get_current(self, pointer: pf.Pointer) -> np.ndarray:
        return super().get_raw(*pointer.tuples)

    def get_voltage(self, pointer: pf.Pointer) -> np.ndarray:
        return super().get_voltage(None, pointer.raw_indices)

    def get_data(
        self, pointer: pf.Pointer, voltage: bool = False
    ) -> pf.BaseDataFrame:
        """
        Get data from a measurement as a poreflow.BaseDataFrame object.

        This method retrieves the raw current data from a specified channel,
        allows for slicing and downsampling, and returns it as a
        ``poreflow.BaseDataFrame`` object.

        Args:
            pointer (poreflow.Pointer): Pointer to the Data
            voltage (bool, optional): Whether to return voltage data.

        Returns:
            poreflow.base.BaseData: An object containing the current data and metadata.

        Notes:
            This method is intended as abstract/general way to get data. Usage of
            the methods get_raw, get_event, etc. is preferred.
        """

        data = {pf.CURRENT_COL: self.get_current(pointer)}

        if voltage:
            data[pf.VOLTAGE_COL] = self.get_voltage(pointer)

        return pf.BaseDataFrame(
            data,
            sfreq=self.sfreq,
            channel=pointer.channel,
            name=self.name,
            start_idx=0 if pointer.start_idx is None else pointer.start_idx,
        )

    def get_ios(self, channel: int = 0) -> None:
        """Overridden in File class, which can save and load the open state current."""
        return None

    @property
    def tracking_meta(self) -> dict:
        """Gets tracking metadata from the file.

        Returns:
            dict: Tracking metadata containing device information and identifiers.
        """
        return self.get_tracking_meta()

    @property
    def context_meta(self) -> dict:
        """Gets context metadata from the file.

        Returns:
            dict: Context metadata containing experimental context information.
        """
        return self.get_context_meta()

    @property
    def sfreq(self) -> float:
        """Gets the sampling frequency of the data.

        Retrieves the sampling frequency from metadata sources in the Fast5 file.

        Returns:
            float: Sampling frequency in Hz.
        """
        if hasattr(self, "sample_rate"):
            return self.sample_rate
        else:  # In write mode, the sample rate is not read out at first
            try:
                return float(self[META_GROUP_NAME].attrs[META_SFREQ_ATTR_NAME])
            except Exception:
                return float(
                    self.get_metadata(self.channels[0])[META_SFREQ_ATTR_NAME]
                )

    def __len__(self) -> int:
        """Gets the total number of samples in the file.

        Returns:
            int: Total number of samples across all channels.
        """
        return int(self[META_GROUP_NAME].attrs[META_DURATION_ATTR_NAME])

    @property
    def duration(self):
        return len(self) / self.sfreq

    def get_t(self, n: int = None) -> np.ndarray:
        """Get time array

        Args:
            n (int, optional): Number of time points to return. Defaults to None, in which case an number of time points is equal to the current data is returned

        Returns:

        """
        if n is None:
            return np.arange(len(self)) / self.sfreq
        else:
            return np.linspace(0, self.duration, n)


class File(DataFile):
    """
    An interface for handline of sequencing files.

    This class extends ``fast5_research.BulkFast5`` to provide
    more convenient methods for data retrieval and interaction, returning
    data as ``poreflow`` objects. Supports both UTube (.dat) and ONT (.fast5)
    files.

    Extra data created when analyzing the file, like event or step data, is
    stored in a separate "annotations" file with, thus preserving the original data.

    Attributes:
        annotator (Annotation): Annotation handler for the file.

    Examples:
        Opening an ONT file and reading the entire "raw" measurement from
        the first channel.

        >>> import poreflow as pf
        >>> f = pf.File("example.fast5")
        >>> raw_data = f.get_raw(channel=0)
        >>> f.close()

        Closing the file can be done automatically using a ``with`` statement.

        >>> with pf.File("example.fast5") as f:
        >>>     raw_data = f.get_raw(channel=0)

        UTube device measurements are opened identically:

        >>> with pf.File("example_utube.dat") as f:
        >>>     raw_data = f.get_raw()

        Note that these measurements only have one channel, so the
        `channel` argument in ``File.get_raw`` can be left out. Loading
        a UTube file will place a Fast5 file next to the .dat file, which is
        used for I/O.

    """

    def __init__(
        self,
        filename,
        verbose=0,
        annotation_name=None,
        search_path=None,
        force_conversion=False,
        mode="r+",
    ):
        """
        Initializes the File object.

        Args:
            filename (str or pathlib.Path): Path to the .fast5 or .dat file.
            verbose (int): Controls warning messages for .dat file conversion.
                2 (default): Use warnings.warn.
                1: Use print().
                0: Suppress messages.
            force_conversion (bool): Force re-conversion of .dat file to .fast5
            search_path (str or pathlib.Path, optional): Path to search for annotations when loading a file. Defaults to None, in which
                case annotation (.annot.fast5) files are searched in the same directory as the data (.fast5) file. Conversely,
                If `filename` is an annotation `search_path` is searched for a data file.

        Returns:
            None
        """

        annotator, filename = _handle_annotation(
            filename, annotation_name, search_path, verbose, mode=mode
        )
        super().__init__(filename, verbose, force_conversion)
        self.annotator: annotations.Annotation = annotator  # Opened

    def close(self):
        """Closes the file and along with the annotation file.

        Returns:
            None
        """
        self.annotator.close()
        super().close()

    @property
    def n_events(self) -> int:
        """Gets the number of events saved on disk.

        Returns:
            int: Number of events stored in the annotation file.
        """
        return len(self.annotator[pf.EVENTS_DATASET]) if self.has_events else 0

    @property
    def n_steps(self) -> int:
        """Gets the number of steps saved on disk.

        Returns:
            int: Number of steps stored in the annotation file.
        """
        return len(self.annotator[pf.STEPS_DATASET]) if self.has_steps else 0

    def get_raw(
        self,
        channel: int = 0,
        times: tuple[float, float] = None,
        index: tuple[int, int] = None,
    ) -> pf.RawDataFrame:
        """
        Get data from a channel as a poreflow.RawDataFrame object.

        This method retrieves the raw current and voltage data from a specified
        channel, allows for slicing and downsampling, and returns it packaged
        as a dataframe-type object.

        Args:
            channel (int): The channel number to retrieve data from. Defaults to 0.
            times (tuple[float, float], optional): A tuple of (start_time, end_time)
                in seconds to slice the data. Defaults to None (all data).
            index (tuple[int, int], optional): A tuple of (start_index, end_index)
                to slice the data. Defaults to None (all data).
            downsample (float, optional): The new sampling frequency to downsample
                to. If None, no downsampling is performed. Defaults to None.

        Returns:
            poreflow.RawDataFrame: An object containing the current and voltage
            data and metadata.
        """
        pointer = pf.Pointer.from_times_or_indices(
            self.sfreq, channel, times, index
        )

        return pf.RawDataFrame(
            {
                pf.CURRENT_COL: self.get_current(pointer),
                pf.VOLTAGE_COL: self.get_voltage(pointer),
            },
            sfreq=self.sfreq,
            channel=channel,
            name=f"Channel {channel} of {self.name}",
            ios=self.get_ios(channel),
            start_idx=pointer.start_idx,
        )

    @property
    def channels(self) -> list:
        """List of channels in poreFlow notation"""
        return [c - 1 for c in self._channels]

    @property
    def has_events(self):
        return self.annotator.has_events

    @property
    def events(self) -> pf.EventsDataFrame:
        """Gets all events from the file.

        Returns:
            pf.EventsDataFrame: DataFrame containing all events.
        """
        return self.get_events()

    @events.setter
    def events(self, events: pf.EventsDataFrame):
        self.annotator.set_events(events)

    def get_events(self, channel: int | list = None) -> pf.EventsDataFrame:
        """Reads events from disk.

        Args:
          channel (int, optional): Only return events from a specific channel. Defaults to None, in which case events
              from all channels are returned.

        Returns:
          pf.EventsDataFrame: DataFrame containing events.
        """
        df = self.annotator.get_events()

        if df is None:
            return pf.NoEventsDataFrame(self.sfreq)

        if channel is not None:
            if isinstance(channel, (int, np.integer)):
                channel = [channel]

            df = df[df[pf.CHANNEL_COL].isin(channel)]

        return pf.EventsDataFrame(df, sfreq=self.sfreq)

    def set_events(
        self, df_events: pf.EventsDataFrame | None, mode: str = "w"
    ) -> None:
        return self.annotator.set_events(df_events, mode)

    def remove_events(
        self,
        channels: int | list[int] | None = None,
        events: int | list[int] | None = None,
        include_ios: bool = True,
        include_steps: bool = True,
    ) -> None:
        """Removes events from specific channels or all events.

        Args:
            events:
            channels (int | list[int] | None):
                - If int: Remove events from the specified channel only.
                - If list[int]: Remove events from the specified channels.
                - If None: Remove all events from all channels.
            include_ios (bool): Whether to also remove IOS fits from the specified channels.
                Defaults to True.
            include_steps (bool): Whether to also remove steps in channel
                Defaults to True.

        Returns:
            None

        Todo:
            Docs
        """

        if not self.has_events:
            return

        if events is not None and channels is not None:
            raise ValueError(
                "Must either specify either events or channels with events to delete, or none to delete all, but not both"
            )

        elif events is None and include_ios:
            # Channels specified or None
            self.annotator.remove_ios(channels)

        self.annotator.remove_events(channels, events, include_steps)

    def remove_ios(self, channels: int | list[int] | None = None) -> None:
        """Removes open state current fits from specific channels or all channels.

        Instead of deleting the entries, sets the polynomial coefficients to NaN
        to preserve the dataset structure.

        Args:
            channels (int | list[int] | None):
                - If int: Remove IOS fit from the specified channel only.
                - If list[int]: Remove IOS fits from the specified channels.
                - If None: Remove IOS fits from all channels.

        Returns:
            None

        Examples:
            Remove IOS fit from channel 0 only:
            >>> f.remove_ios(0)

            Remove IOS fits from channels 0 and 2:
            >>> f.remove_ios([0, 2])

            Remove all IOS fits:
            >>> f.remove_ios(None)
        """
        return self.annotator.remove_ios(channels)

    def remove_steps(
        self, events: int | list[int] = None, reindex: bool = False
    ) -> None:
        """Removes steps from specific events or all events.

        Args:
            events (int | list[int] | None):
                - If int: Remove steps from the specified event only.
                - If list[int]: Remove steps from the specified events.
                - If None: Remove steps from all events.
            reindex (bool): Whether to reindex the remaining steps. Defaults to False.

        Returns:
            None
        """
        return self.annotator.remove_steps(events, reindex)

    @property
    def has_steps(self):
        return self.annotator.has_steps

    @property
    def steps(self) -> pf.StepsDataFrame:
        """Gets all steps from the file.

        Returns:
            pf.StepsDataFrame: DataFrame containing all steps.
        """
        return self.get_steps()

    @steps.setter
    def steps(self, steps: pf.StepsDataFrame):
        self.annotator.set_steps(steps)

    def get_steps(self, event: int = None) -> pf.StepsDataFrame:
        """Reads events from disk.

        Args:
           event (int, optional): Only return events from a specific event. Defaults to None, in which case steps
               from all events are returned.

        Returns:
           pf.StepsDataFrame: DataFrame containing events.
        """
        df = self.annotator.get_steps()

        if df is None:
            return pf.NoStepsDataFrame(self.sfreq)

        if (event is not None) and (event not in df[pf.EVENT_COL].values):
            raise IndexError(f"Event {event} not found in {self.filename}")
        elif event is not None:
            df = df[df[pf.EVENT_COL] == event]

        return pf.StepsDataFrame(df, sfreq=self.sfreq)

    def set_steps(
        self, df_steps: pf.StepsDataFrame | None, mode: str = "w"
    ) -> None:
        """Saves steps to disk.

        Args:
            df_steps (poreflow.StepsDataFrame): Steps to save. Set None to delete all events store on disk.
            mode (str): Whether to replace ('w') or append ('a') to existing steps on disk.
        """
        return self.annotator.set_steps(df_steps, mode)

    def set_ios(
        self, p: np.polynomial.Polynomial, channel: int = 0, force=False
    ) -> None:
        if not self.annotator.has_ios:
            self.annotator.create_ios_fit_dataset(p.degree(), self.channels)

        elif self.annotator.ios_degree != p.degree() and force:
            self.annotator.create_ios_fit_dataset(p.degree(), self.channels)

        return self.annotator.set_ios(p, channel)

    def get_ios(self, channel: int = 0) -> np.polynomial.Polynomial | None:
        return self.annotator.get_ios(channel)

    def get_event(self, item: int) -> pf.EventDataFrame:
        """
        Get data from an events as a poreflow.EventDataFrame object.

        This method retrieves the raw current data from a specified
        event. Requires events to have been found and stored in
        the annotation object.

        Args:
            item (int): The event number to retrieve data from.
            downsample (float, optional): The new sampling frequency to downsample
                to. If None, no downsampling is performed. Defaults to None.

        Returns:
            poreflow.EventDataFrame: An object containing the current of
            an event.
        """

        dset = self.annotator[pf.EVENTS_DATASET]
        row = dset[item]

        pointer = pf.Pointer(
            row[pf.CHANNEL_COL], row[pf.START_IDX_COL], row[pf.END_IDX_COL]
        )

        return pf.EventDataFrame(
            {pf.CURRENT_COL: self.get_current(pointer)},
            sfreq=self.sfreq,
            channel=pointer.channel,
            start_idx=int(pointer.start_idx),
            ios=row[pf.IOS_COL],
            name=f"Event {item} in channel {pointer.channel} of {self.name}",
            quality=row[pf.QUALITY_COL],
            label=row[pf.LABEL_COL],
        )

    def map(
        self,
        worker_func: typing.Callable,
        pointers: list[pf.Pointer],
        processes: int = None,
        verbose: int = 0,
        callback: typing.Callable = None,
        **kwargs,
    ):
        """Run a worker function in parallel over some mappable.

        Args:
            worker_func: Function to run. Must accept (fname, channel, lock, **kwargs).
            pointers: List of pointers.
            processes: Number of worker processes to use. If processes is None (default) then the number
                of logical CPUs in the system is used.
            verbose: Verbosity level.
            callback: Function to call with each result.
            **kwargs: Keyword arguments to pass to the worker function.

        Returns:
            list: List of results from the worker function.

        Notes:
            This is a method intended for advanced users. For examples of usages,
            check out source code of File.find_events or File.find_steps.
        """
        results = mapper(
            worker_func,
            self.filename,
            pointers,
            callback,
            processes,
            verbose,
            kwargs,
        )

        # Reset to an open handle
        return results

    def find_events(
        self,
        processes=None,
        verbose=0,
        channels: list = None,
        index=None,
        **kwargs,
    ):
        """Find events in the file using parallel processing.

        Finds events in channels. Also stores open-state current fits
        for all channels searched.

        Args:
            processes (int): Number of workers.
            verbose: Verbosity level.
            channels: specific channels to search.
            index (tuple):
            **kwargs: Additional arguments for event detection. See

        """

        from poreflow.events import detection

        self.set_events(None)
        degree = kwargs.get("degree", detection.DEFAULT_DEGREE)
        self.annotator.create_ios_fit_dataset(degree, self.channels)

        if channels is None:
            channels = self.get_channels()

        if index is None:
            index = ()
        pointers = [pf.Pointer(channel, *index) for channel in channels]

        results = self.map(
            detection.event_detection_worker,
            pointers,
            processes=processes,
            verbose=verbose,
            callback=functools.partial(
                detection.save_events_to_file,
                handle=self.annotator,  # Pass annotator handle
                verbose=verbose,
            ),
            **kwargs,
        )

        if verbose > 0:
            detection.summarize_events(results)

    def iter_events(self):
        for j in range(self.n_events):
            yield self.get_event(j)

    def find_steps(
        self, processes=None, verbose=0, events: list = None, **kwargs
    ):
        from poreflow.steps import changepoint

        self.set_steps(None)

        if events is None:
            events = self.events  # All events
        else:
            events = self.events.loc[events]

        pointers = list(events.iter_pointers())

        results = self.map(
            changepoint.step_finding_worker,
            pointers,
            processes=processes,
            verbose=verbose,
            callback=functools.partial(
                changepoint.save_steps_to_file,
                handle=self.annotator,
            ),
            **kwargs,
        )

        if verbose > 0:
            changepoint.summarize_steps(results)

    def filter_events(self, mask: pd.Series | np.ndarray) -> None:
        """Filter events based on mask.

        Args:
            mask (pd.Series | np.ndarray): True is keep

        """
        self.remove_events(events=self.events.index.to_numpy()[~mask])
