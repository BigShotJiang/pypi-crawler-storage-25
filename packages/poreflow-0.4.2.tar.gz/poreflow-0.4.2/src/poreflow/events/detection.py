# Created by Ruben Marchau
# Refactored and documented by Thijn Hoekstra
import os

import scipy
import numpy as np
import pandas as pd

import poreflow as pf
from poreflow.events import open_state, voltage_state
from poreflow.io.annotations import Annotation
from poreflow.io.ont import DataFile

DEFAULT_DEGREE = 3


def find_events(
    raw: pf.RawDataFrame,
    open_state_range: tuple[float, float] = (200, 300),
    voltage_range: tuple[float, float] = (175, 185),
    closing_iterations: int | bool = 10,
    boundary_trim: list = [1, 1],
    n_components: int = 3,
    degree: int = DEFAULT_DEGREE,
    min_frac_os: float = 0.01,
    min_duration: float = 0.01,
) -> pf.EventsDataFrame | None:
    """

    Args:
        raw:
        open_state_range:
        voltage_range:
        closing_iterations:
        boundary_trim (tuple): Times in ms to remove from the start and ends of an event in ms.
        n_components:
        degree:
        min_frac_os:
        min_duration:

    Returns:

    """
    component = open_state.find_open_state(raw, open_state_range, n_components)

    bad_state = open_state.get_open_state_mask(raw, component)

    if bad_state.sum() / len(raw) < min_frac_os:
        return None

    poly = open_state.get_open_state_fit(raw, bad_state, degree)
    raw.ios = poly

    # Boolean OR: want to include all samples either with bad voltage or
    # in an open state
    bad_state = bad_state | ~voltage_state.get_voltage_state_mask(
        raw, voltage_range
    )
    bad_state = bad_state.to_numpy(dtype=bool)

    # Do binary closing to clean up mask
    if closing_iterations is not False:
        bad_state = scipy.ndimage.binary_closing(
            bad_state, iterations=closing_iterations
        )

    df = pf.EventsDataFrame(
        get_event_indices(bad_state),
        sfreq=raw.sfreq,
    )

    df.trim_events(time_ms=boundary_trim, recalculate_times=False)
    df.clip_events(
        lower=0, upper=len(raw), recalculate_times=False
    )  # Times are recalculated here

    # Handle raw data frames with start_idx != 0
    df[pf.START_IDX_COL] += raw.start_idx
    df[pf.END_IDX_COL] += raw.start_idx

    df.calculate_times()

    df = df.filter_by_duration(min_duration)

    add_local_open_state(df, poly)

    df[pf.CHANNEL_COL] = raw.channel
    df[pf.QUALITY_COL] = 0.0
    df[pf.LABEL_COL] = 0

    return df


def get_event_indices(bad_state: np.ndarray[np.bool] | pd.Series) -> dict:
    if isinstance(bad_state, pd.Series):
        bad_state = bad_state.to_numpy()

    diff = np.diff(bad_state.astype(np.int8))

    if not np.any(diff):
        raise RuntimeError(
            "Did not find any states. Please run "
            "find_open_state() and find_bad_voltages() first."
        )

    start_indices = np.where(diff == -1)[0] + 1
    end_indices = np.where(diff == 1)[0] + 1
    # If starting/ending at a good state, also add events here
    if not bad_state[0]:
        start_indices = np.insert(start_indices, 0, 0)
    if not bad_state[-1]:
        end_indices = np.append(end_indices, len(bad_state))
    return {
        pf.START_IDX_COL: start_indices,
        pf.END_IDX_COL: end_indices,
    }


def add_local_open_state(
    df: pd.DataFrame, poly: np.polynomial.Polynomial
) -> None:
    start_ios = poly(df[pf.START_TIME_COL])
    end_ios = poly(df[pf.END_TIME_COL])

    df[pf.IOS_COL] = (start_ios + end_ios) / 2


def event_detection_worker(
    fname: str | os.PathLike,
    pointer: pf.Pointer,
    **kwargs,
):
    # Intended for use in a separate process so passing file
    downsample = kwargs.pop("downsample", None)

    # lock not needed as opening in read-only
    with DataFile(fname) as f:  # Just get the data (no annotation)
        raw = f.get_data(pointer, voltage=True).downsample(downsample)
        raw = pf.RawDataFrame(raw, channel=pointer.channel)

    error = None
    events = []
    try:
        events = raw.find_events(**kwargs)
    except pf.NoEventsDetectedException as e:
        error = e

    if error is None:
        return {
            "channel": pointer.channel,
            "result": f"Worker {os.getpid()} processed channel {pointer.channel}",
            "success": True,
            "n_events": len(events) if events is not None else 0,
            "events": events,
            "coef": raw.ios,
        }
    else:
        return {
            "channel": pointer.channel,
            "result": str(
                f"Could not find events in channel {pointer.channel}: {error}"
            ),
            "success": False,
            "n_events": 0,
            "events": None,
            "coef": None,
        }


def summarize_events(results):
    n_channels = len(results)
    n_events = sum(r.get("n_events", 0) for r in results)

    print("------- SUMMARY -------")
    failed_channels = sorted(
        [r["channel"] for r in results if not r["success"]]
    )
    error_str = ""
    if failed_channels:
        failed_str = ", ".join(map(str, failed_channels[:10]))
        if len(failed_channels) > 10:
            failed_str += ", ..."
        error_str = (
            f"Error finding events in {len(failed_channels)} channels "
            f"({len(failed_channels) / n_channels:.0%}), channels {failed_str}. \n"
        )
    n_good = len(results) - len(failed_channels)
    avg_events = n_events / n_good if n_good > 0 else 0.0
    print(
        f"Searched {n_channels} channels and found {n_events} events. \n{error_str}"
        f"Good channels had {avg_events:.2f} events on average."
    )


def save_events_to_file(
    result,
    handle: Annotation,
    verbose: int = 0,
):
    if verbose > 2:
        print(result["result"])

    channel = result["channel"]

    events = None
    if result["success"] and result["n_events"] > 0:
        events = result.pop("events")

    coef = result.get("coef")

    try:
        if events is not None:
            handle.set_events(events, mode="a")
            result["events"] = None

            handle.set_ios(coef, channel=channel)
    except Exception as e:
        raise IOError(f"Error in saving data from channel {channel}") from e
