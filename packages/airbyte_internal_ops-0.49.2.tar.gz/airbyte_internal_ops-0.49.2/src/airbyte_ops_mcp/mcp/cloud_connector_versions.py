# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""MCP tools for cloud connector version management.

This module provides MCP tools for viewing and managing connector version
overrides (pins) in Airbyte Cloud. These tools enable admins to pin connectors
to specific versions for troubleshooting or stability purposes.

Uses direct API client calls with either bearer token or client credentials auth.

## MCP reference

.. include:: ../../../docs/mcp-generated/cloud_connector_versions.md
    :start-line: 2
"""

# NOTE: We intentionally do NOT use `from __future__ import annotations` here.
# FastMCP has issues resolving forward references when PEP 563 deferred annotations
# are used. See: https://github.com/jlowin/fastmcp/issues/905
# Python 3.12+ supports modern type hint syntax natively, so this is not needed.

__all__: list[str] = []

import logging
from dataclasses import dataclass
from typing import Annotated, Literal

import requests as _requests
from airbyte import constants
from airbyte.exceptions import PyAirbyteInputError
from fastmcp import Context, FastMCP
from fastmcp_extensions import get_mcp_config, mcp_tool, register_mcp_tools
from pydantic import Field

from airbyte_ops_mcp.approval_resolution import (
    ApprovalResolutionError,
    resolve_admin_email_from_approval,
)
from airbyte_ops_mcp.cloud_admin import api_client
from airbyte_ops_mcp.cloud_admin.api_client import (
    _get_access_token,
    _ScopeType,
)
from airbyte_ops_mcp.cloud_admin.auth import (
    CloudAuthError,
    require_internal_admin_flag_only,
)
from airbyte_ops_mcp.cloud_admin.models import (
    ConnectorVersionInfo,
    OrganizationVersionOverrideResult,
    VersionOverrideOperationResult,
    WorkspaceVersionOverrideResult,
)
from airbyte_ops_mcp.cloud_admin.version_guard import (
    check_existing_pins,
)
from airbyte_ops_mcp.constants import USER_AGENT, ServerConfigKey, WorkspaceAliasEnum
from airbyte_ops_mcp.tier_cache import TierFilter, get_org_tier, resolve_workspace


def _build_tier_warning(customer_tier: str) -> str | None:
    """Build a warning message for sensitive customer tiers."""
    if customer_tier == "TIER_0":
        return (
            "WARNING: This is a TIER_0 (highest-value) customer. "
            "Proceed with extreme caution."
        )
    if customer_tier == "TIER_1":
        return "WARNING: This is a TIER_1 (high-value) customer. Proceed with caution."
    return None


def _validate_tier_filter(
    actual_tier: str,
    requested_filter: TierFilter,
) -> tuple[bool, str | None]:
    """Check if actual tier matches the requested filter.

    Returns `(ok, error_message)`.  When `ok` is `False` the caller should
    reject the operation with `error_message`.
    """
    if requested_filter == "ALL":
        return True, None
    if actual_tier != requested_filter:
        return False, (
            f"Tier mismatch: the target entity is {actual_tier} but the requested "
            f"tier filter is {requested_filter}. Either specify the correct tier "
            f"or use 'ALL' to proceed with a warning."
        )
    return True, None


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _ResolvedCloudAuth:
    """Resolved authentication for Airbyte Cloud API calls.

    Either bearer_token OR (client_id AND client_secret) will be set, not both.
    """

    bearer_token: str | None = None
    client_id: str | None = None
    client_secret: str | None = None


def _resolve_cloud_auth(ctx: Context) -> _ResolvedCloudAuth:
    """Resolve authentication credentials for Airbyte Cloud API.

    Credentials are resolved in priority order:
    1. Bearer token (Authorization header or AIRBYTE_CLOUD_BEARER_TOKEN env var)
    2. Client credentials (X-Airbyte-Cloud-Client-Id/Secret headers or env vars)

    Args:
        ctx: FastMCP Context object from the current tool invocation.

    Returns:
        _ResolvedCloudAuth with either bearer_token or client credentials set.

    Raises:
        CloudAuthError: If credentials cannot be resolved from headers or env vars.
    """
    # Try bearer token first (preferred, but not required)
    bearer_token = get_mcp_config(ctx, ServerConfigKey.BEARER_TOKEN)
    if bearer_token:
        return _ResolvedCloudAuth(bearer_token=bearer_token)

    # Fall back to client credentials
    try:
        client_id = get_mcp_config(ctx, ServerConfigKey.CLIENT_ID)
        client_secret = get_mcp_config(ctx, ServerConfigKey.CLIENT_SECRET)
        return _ResolvedCloudAuth(
            client_id=client_id,
            client_secret=client_secret,
        )
    except ValueError as e:
        raise CloudAuthError(
            f"Failed to resolve credentials. Ensure credentials are provided "
            f"via Authorization header (Bearer token), "
            f"HTTP headers (X-Airbyte-Cloud-Client-Id, X-Airbyte-Cloud-Client-Secret), "
            f"or environment variables. Error: {e}"
        ) from e


@mcp_tool(
    read_only=True,
    idempotent=True,
    open_world=True,
)
def get_cloud_connector_version(
    workspace_id: Annotated[
        str | WorkspaceAliasEnum,
        Field(
            description="The Airbyte Cloud workspace ID (UUID) or alias. "
            "Accepts '@devin-ai-sandbox' as an alias for the Devin AI sandbox workspace."
        ),
    ],
    actor_id: Annotated[
        str, "The ID of the deployed connector (source or destination)"
    ],
    actor_type: Annotated[
        Literal["source", "destination"],
        "The type of connector (source or destination)",
    ],
    config_api_root: Annotated[
        str | None,
        Field(
            description="Optional API root URL override for the Config API. "
            "Defaults to Airbyte Cloud (https://cloud.airbyte.com/api/v1). "
            "Use this to target local or self-hosted deployments.",
            default=None,
        ),
    ] = None,
    *,
    ctx: Context,
) -> ConnectorVersionInfo:
    """Get the current version information for a deployed connector.

    Returns version details including the current version string and whether
    an override (pin) is applied.

    Authentication credentials are resolved in priority order:
    1. Bearer token (Authorization header or AIRBYTE_CLOUD_BEARER_TOKEN env var)
    2. HTTP headers: X-Airbyte-Cloud-Client-Id, X-Airbyte-Cloud-Client-Secret
    3. Environment variables: AIRBYTE_CLOUD_CLIENT_ID, AIRBYTE_CLOUD_CLIENT_SECRET
    """
    # Resolve workspace ID alias
    resolved_workspace_id = WorkspaceAliasEnum.resolve(workspace_id)

    auth = _resolve_cloud_auth(ctx)

    # Use vendored API client instead of connector.get_connector_version()
    # Use Config API root for version management operations
    # Pass workspace_id to get detailed scoped configuration context
    version_data = api_client.get_connector_version(
        connector_id=actor_id,
        connector_type=actor_type,
        config_api_root=config_api_root or constants.CLOUD_CONFIG_API_ROOT,
        client_id=auth.client_id,
        client_secret=auth.client_secret,
        bearer_token=auth.bearer_token,
        workspace_id=resolved_workspace_id,
    )

    # Determine if version is pinned from scoped config context (more reliable)
    # The API's isVersionOverrideApplied only returns true for USER-created pins,
    # not system-generated pins (e.g., breaking_change origin). Check scopedConfigs
    # for a more accurate picture of whether ANY pin exists.
    scoped_configs = version_data.get("scopedConfigs", {})
    has_any_pin = (
        any(config is not None for config in scoped_configs.values())
        if scoped_configs
        else False
    )

    # Use scoped config existence as the source of truth for "is pinned"
    # Fall back to API's isVersionOverrideApplied if no scoped config data
    is_pinned = (
        has_any_pin if scoped_configs else version_data["isVersionOverrideApplied"]
    )

    return ConnectorVersionInfo(
        connector_id=actor_id,
        connector_type=actor_type,
        version=version_data["dockerImageTag"],
        is_version_pinned=is_pinned,
    )


@mcp_tool(
    destructive=True,
    idempotent=False,
    open_world=True,
)
def set_cloud_connector_version_override(
    workspace_id: Annotated[
        str | WorkspaceAliasEnum,
        Field(
            description="The Airbyte Cloud workspace ID (UUID) or alias. "
            "Accepts '@devin-ai-sandbox' as an alias for the Devin AI sandbox workspace."
        ),
    ],
    actor_id: Annotated[
        str, "The ID of the deployed connector (source or destination)"
    ],
    actor_type: Annotated[
        Literal["source", "destination"],
        "The type of connector (source or destination)",
    ],
    approval_comment_url: Annotated[
        str | None,
        Field(
            description="URL to the Slack approval record. Obtain this by calling the "
            "`escalate_to_human` tool with `approval_requested=True`; the backend delivers "
            "the approval record URL when a human clicks Approve. "
            "Format: https://<workspace>.slack.com/archives/... "
            "The admin email is automatically resolved from the approver's identity "
            "via the team roster.",
            default=None,
        ),
    ],
    version: Annotated[
        str | None,
        Field(
            description="The semver version string to pin to (e.g., '0.1.0'). "
            "Must be None if unset is True.",
            default=None,
        ),
    ],
    unset: Annotated[
        bool,
        Field(
            description="If True, removes any existing version override. "
            "Cannot be True if version is provided.",
            default=False,
        ),
    ],
    override_reason: Annotated[
        str | None,
        Field(
            description="Required when setting a version. "
            "Explanation for the override (min 10 characters).",
            default=None,
        ),
    ],
    override_reason_reference_url: Annotated[
        str | None,
        Field(
            description="Optional URL with more context (e.g., issue link).",
            default=None,
        ),
    ],
    issue_url: Annotated[
        str | None,
        Field(
            description="URL to the GitHub issue providing context for this operation. "
            "Must be a valid GitHub URL (https://github.com/...). Required for authorization.",
            default=None,
        ),
    ],
    ai_agent_session_url: Annotated[
        str | None,
        Field(
            description="URL to the AI agent session driving this operation, if applicable. "
            "Provides additional auditability for AI-driven operations.",
            default=None,
        ),
    ] = None,
    force: Annotated[
        bool,
        Field(
            description="If `True`, allow overwriting an existing version pin. "
            "Existing pins may have been set by rollouts, breaking-change migrations, "
            "or other operators. Defaults to `False`. NOTE: `force=True` only "
            "bypasses the existing-pin check — major-version crossings are always "
            "blocked and cannot be overridden.",
            default=False,
        ),
    ] = False,
    config_api_root: Annotated[
        str | None,
        Field(
            description="Optional API root URL override for the Config API. "
            "Defaults to Airbyte Cloud (https://cloud.airbyte.com/api/v1). "
            "Use this to target local or self-hosted deployments.",
            default=None,
        ),
    ] = None,
    customer_tier_filter: Annotated[
        TierFilter,
        Field(
            description=(
                "Required tier filter: 'TIER_0', 'TIER_1', 'TIER_2', or 'ALL'. "
                "The operation will be rejected if the actual customer tier does not match. "
                "Use 'ALL' to proceed regardless of tier (a warning is shown for sensitive tiers)."
            ),
        ),
    ] = "TIER_2",
    *,
    ctx: Context,
) -> VersionOverrideOperationResult:
    """Set or clear a version override for a deployed connector.

    **Admin-only operation** - Requires:
    - AIRBYTE_INTERNAL_ADMIN_FLAG=airbyte.io environment variable
    - issue_url parameter (GitHub issue URL for context)
    - approval_comment_url (Slack approval record URL from `escalate_to_human`)

    The admin user email is automatically derived from the Slack approval record,
    resolving the approver's @airbyte.io email via the team roster.

    You must specify EXACTLY ONE of `version` OR `unset=True`, but not both.
    When setting a version, `override_reason` is required.

    The `customer_tier_filter` parameter gates the operation: the call fails if
    the actual tier of the workspace's organization does not match.  Use `ALL`
    to bypass the check (a warning is still emitted for sensitive tiers).

    Business rules enforced:
    - Dev versions (-dev): Only creator can unpin their own dev version override
    - Production versions: Require strong justification mentioning customer/support/investigation
    - Release candidates (-rc): Any admin can pin/unpin RC versions

    Authentication credentials are resolved in priority order:
    1. Bearer token (Authorization header or AIRBYTE_CLOUD_BEARER_TOKEN env var)
    2. HTTP headers: X-Airbyte-Cloud-Client-Id, X-Airbyte-Cloud-Client-Secret
    3. Environment variables: AIRBYTE_CLOUD_CLIENT_ID, AIRBYTE_CLOUD_CLIENT_SECRET
    """
    # Resolve workspace ID alias (workspace_id is required, so resolved value is never None)
    resolved_workspace_id = WorkspaceAliasEnum.resolve(workspace_id)
    assert resolved_workspace_id is not None  # Type narrowing: workspace_id is required

    # Validate admin access (check env var flag)
    try:
        require_internal_admin_flag_only()
    except CloudAuthError as e:
        return VersionOverrideOperationResult(
            success=False,
            message=f"Admin authentication failed: {e}",
            connector_id=actor_id,
            connector_type=actor_type,
        )

    # Validate authorization parameters
    validation_errors: list[str] = []

    if not issue_url:
        validation_errors.append(
            "issue_url is required for authorization (GitHub issue URL)"
        )
    elif not issue_url.startswith("https://github.com/"):
        validation_errors.append(
            f"issue_url must be a valid GitHub URL (https://github.com/...), got: {issue_url}"
        )

    if not approval_comment_url:
        validation_errors.append(
            "'approval_comment_url' is required. Use `escalate_to_human` with "
            "`approval_requested=True` to obtain a Slack approval record URL."
        )

    if validation_errors:
        return VersionOverrideOperationResult(
            success=False,
            message="Authorization validation failed: " + "; ".join(validation_errors),
            connector_id=actor_id,
            connector_type=actor_type,
        )

    # Derive admin email from the approval URL (domain-based dispatch)
    try:
        admin_user_email = resolve_admin_email_from_approval(
            approval_comment_url=approval_comment_url,
        )
    except ApprovalResolutionError as e:
        return VersionOverrideOperationResult(
            success=False,
            message=str(e),
            connector_id=actor_id,
            connector_type=actor_type,
        )

    # Tier guardrail: resolve workspace tier BEFORE the destructive operation
    ws_resolution = resolve_workspace(resolved_workspace_id)
    if not ws_resolution.organization_id:
        return VersionOverrideOperationResult(
            success=False,
            message=f"Could not resolve organization for workspace {resolved_workspace_id}",
            connector_id=actor_id,
            connector_type=actor_type,
        )

    customer_tier = ws_resolution.customer_tier
    is_eu = (
        ws_resolution.dataplane_name == "EU" if ws_resolution.dataplane_name else None
    )
    tier_warning = _build_tier_warning(customer_tier)

    tier_ok, tier_error = _validate_tier_filter(customer_tier, customer_tier_filter)
    if not tier_ok:
        return VersionOverrideOperationResult(
            success=False,
            message=tier_error or "Tier filter mismatch",
            connector_id=actor_id,
            connector_type=actor_type,
            customer_tier=customer_tier,
            is_eu=is_eu,
            tier_warning=tier_warning,
        )

    # Build enhanced override reason with audit fields (only for 'set' operations)
    enhanced_override_reason = override_reason
    if not unset and override_reason:
        audit_parts = [override_reason]
        audit_parts.append(f"Issue: {issue_url}")
        audit_parts.append(f"Approval: {approval_comment_url}")
        if ai_agent_session_url:
            audit_parts.append(f"AI Session: {ai_agent_session_url}")
        enhanced_override_reason = " | ".join(audit_parts)

    # Resolve auth and get current version info
    resolved_config_api_root = config_api_root or constants.CLOUD_CONFIG_API_ROOT
    try:
        auth = _resolve_cloud_auth(ctx)

        # Get current version info before the operation
        current_version_data = api_client.get_connector_version(
            connector_id=actor_id,
            connector_type=actor_type,
            config_api_root=resolved_config_api_root,
            client_id=auth.client_id,
            client_secret=auth.client_secret,
            bearer_token=auth.bearer_token,
        )
        current_version = current_version_data["dockerImageTag"]
        was_pinned_before = current_version_data["isVersionOverrideApplied"]

    except CloudAuthError as e:
        return VersionOverrideOperationResult(
            success=False,
            message=f"Failed to resolve credentials or get connector: {e}",
            connector_id=actor_id,
            connector_type=actor_type,
        )

    # Existing-pin guard: check actor, workspace, and org scopes (skip when unsetting)
    if not unset and version:
        try:
            access_token = _get_access_token(
                auth.client_id, auth.client_secret, auth.bearer_token
            )
            # Get actor_definition_id from the connector info
            get_endpoint = f"{resolved_config_api_root}/{actor_type}s/get"
            get_resp = _requests.post(
                get_endpoint,
                json={f"{actor_type}Id": actor_id},
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "User-Agent": USER_AGENT,
                    "Content-Type": "application/json",
                },
                timeout=30,
            )
            get_resp.raise_for_status()
            actor_definition_id = get_resp.json().get(f"{actor_type}DefinitionId")
            if not actor_definition_id:
                return VersionOverrideOperationResult(
                    success=False,
                    message=f"Could not find {actor_type}DefinitionId in connector info for actor {actor_id}",
                    connector_id=actor_id,
                    connector_type=actor_type,
                    previous_version=current_version,
                    was_pinned_before=was_pinned_before,
                )

            guard = check_existing_pins(
                scopes=[
                    (_ScopeType.ACTOR, actor_id, "actor"),
                    (_ScopeType.WORKSPACE, resolved_workspace_id, "workspace"),
                    (
                        _ScopeType.ORGANIZATION,
                        ws_resolution.organization_id,
                        "organization",
                    ),
                ],
                actor_definition_id=actor_definition_id,
                config_api_root=resolved_config_api_root,
                access_token=access_token,
                target_version=version,
                force=force,
            )
            if guard.blocked:
                assert guard.error_msg is not None  # narrowing for type checker
                return VersionOverrideOperationResult(
                    success=False,
                    message=guard.error_msg,
                    connector_id=actor_id,
                    connector_type=actor_type,
                    previous_version=current_version,
                    was_pinned_before=was_pinned_before,
                )
        except (
            PyAirbyteInputError,
            CloudAuthError,
            _requests.exceptions.HTTPError,
        ) as e:
            return VersionOverrideOperationResult(
                success=False,
                message=f"Pin guard check failed: {e}",
                connector_id=actor_id,
                connector_type=actor_type,
                previous_version=current_version,
                was_pinned_before=was_pinned_before,
            )

    # Call vendored API client's set_connector_version_override method
    try:
        result = api_client.set_connector_version_override(
            connector_id=actor_id,
            connector_type=actor_type,
            config_api_root=resolved_config_api_root,
            client_id=auth.client_id,
            client_secret=auth.client_secret,
            workspace_id=resolved_workspace_id,
            version=version,
            unset=unset,
            override_reason=enhanced_override_reason,
            override_reason_reference_url=override_reason_reference_url,
            user_email=admin_user_email,
            bearer_token=auth.bearer_token,
        )

        # Get updated version info after the operation
        updated_version_data = api_client.get_connector_version(
            connector_id=actor_id,
            connector_type=actor_type,
            config_api_root=resolved_config_api_root,
            client_id=auth.client_id,
            client_secret=auth.client_secret,
            bearer_token=auth.bearer_token,
        )
        new_version = updated_version_data["dockerImageTag"] if not unset else None
        is_pinned_after = updated_version_data["isVersionOverrideApplied"]

        if unset:
            if result:
                message = "Successfully cleared version override. Connector will now use default version."
            else:
                message = "No version override was active (nothing to clear)"
        else:
            message = f"Successfully pinned connector to version {version}"

        if tier_warning:
            message = f"{tier_warning} {message}"

        return VersionOverrideOperationResult(
            success=True,
            message=message,
            connector_id=actor_id,
            connector_type=actor_type,
            previous_version=current_version,
            new_version=new_version,
            was_pinned_before=was_pinned_before,
            is_pinned_after=is_pinned_after,
            customer_tier=customer_tier,
            is_eu=is_eu,
            tier_warning=tier_warning,
        )

    except PyAirbyteInputError as e:
        # PyAirbyte raises this for validation errors and permission denials
        return VersionOverrideOperationResult(
            success=False,
            message=str(e),
            connector_id=actor_id,
            connector_type=actor_type,
            previous_version=current_version,
            was_pinned_before=was_pinned_before,
        )


@mcp_tool(
    destructive=True,
    idempotent=False,
    open_world=True,
)
def set_workspace_connector_version_override(
    workspace_id: Annotated[
        str | WorkspaceAliasEnum,
        Field(
            description="The Airbyte Cloud workspace ID (UUID) or alias. "
            "Accepts '@devin-ai-sandbox' as an alias for the Devin AI sandbox workspace."
        ),
    ],
    connector_name: Annotated[
        str,
        Field(
            description="The connector name (e.g., 'source-github', 'destination-bigquery')."
        ),
    ],
    connector_type: Annotated[
        Literal["source", "destination"],
        "The type of connector (source or destination)",
    ],
    approval_comment_url: Annotated[
        str | None,
        Field(
            description="URL to the Slack approval record. Obtain this by calling the "
            "`escalate_to_human` tool with `approval_requested=True`; the backend delivers "
            "the approval record URL when a human clicks Approve. "
            "Format: https://<workspace>.slack.com/archives/... "
            "The admin email is automatically resolved from the approver's identity "
            "via the team roster.",
            default=None,
        ),
    ],
    version: Annotated[
        str | None,
        Field(
            description="The semver version string to pin to (e.g., '0.1.0'). "
            "Must be None if unset is True.",
            default=None,
        ),
    ],
    unset: Annotated[
        bool,
        Field(
            description="If True, removes any existing version override. "
            "Cannot be True if version is provided.",
            default=False,
        ),
    ],
    override_reason: Annotated[
        str | None,
        Field(
            description="Required when setting a version. "
            "Explanation for the override (min 10 characters).",
            default=None,
        ),
    ],
    override_reason_reference_url: Annotated[
        str | None,
        Field(
            description="Optional URL with more context (e.g., issue link).",
            default=None,
        ),
    ],
    issue_url: Annotated[
        str | None,
        Field(
            description="URL to the GitHub issue providing context for this operation. "
            "Must be a valid GitHub URL (https://github.com/...). Required for authorization.",
            default=None,
        ),
    ],
    ai_agent_session_url: Annotated[
        str | None,
        Field(
            description="URL to the AI agent session driving this operation, if applicable. "
            "Provides additional auditability for AI-driven operations.",
            default=None,
        ),
    ] = None,
    force: Annotated[
        bool,
        Field(
            description="If `True`, allow overwriting an existing version pin. "
            "Existing pins may have been set by rollouts, breaking-change migrations, "
            "or other operators. Defaults to `False`. NOTE: `force=True` only "
            "bypasses the existing-pin check — major-version crossings are always "
            "blocked and cannot be overridden.",
            default=False,
        ),
    ] = False,
    config_api_root: Annotated[
        str | None,
        Field(
            description="Optional API root URL override for the Config API. "
            "Defaults to Airbyte Cloud (https://cloud.airbyte.com/api/v1). "
            "Use this to target local or self-hosted deployments.",
            default=None,
        ),
    ] = None,
    customer_tier_filter: Annotated[
        TierFilter,
        Field(
            description=(
                "Required tier filter: 'TIER_0', 'TIER_1', 'TIER_2', or 'ALL'. "
                "The operation will be rejected if the actual customer tier does not match. "
                "Use 'ALL' to proceed regardless of tier (a warning is shown for sensitive tiers)."
            ),
        ),
    ] = "TIER_2",
    *,
    ctx: Context,
) -> WorkspaceVersionOverrideResult:
    """Set or clear a workspace-level version override for a connector type.

    This pins ALL instances of a connector type within a workspace to a specific version.
    For example, pinning 'source-github' at workspace level means all GitHub sources
    in that workspace will use the pinned version.

    **Admin-only operation** - Requires:
    - AIRBYTE_INTERNAL_ADMIN_FLAG=airbyte.io environment variable
    - issue_url parameter (GitHub issue URL for context)
    - approval_comment_url (Slack approval record URL from `escalate_to_human`)

    You must specify EXACTLY ONE of `version` OR `unset=True`, but not both.
    When setting a version, `override_reason` is required.

    The `customer_tier_filter` parameter gates the operation: the call fails if
    the actual tier of the workspace's organization does not match.  Use `ALL`
    to bypass the check (a warning is still emitted for sensitive tiers).
    """
    # Resolve workspace ID alias (workspace_id is required, so resolved value is never None)
    resolved_workspace_id = WorkspaceAliasEnum.resolve(workspace_id)
    assert resolved_workspace_id is not None  # Type narrowing: workspace_id is required

    # Validate admin access (check env var flag)
    try:
        require_internal_admin_flag_only()
    except CloudAuthError as e:
        return WorkspaceVersionOverrideResult(
            success=False,
            message=f"Admin authentication failed: {e}",
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    # Validate authorization parameters
    validation_errors: list[str] = []

    if not issue_url:
        validation_errors.append(
            "issue_url is required for authorization (GitHub issue URL)"
        )
    elif not issue_url.startswith("https://github.com/"):
        validation_errors.append(
            f"issue_url must be a valid GitHub URL (https://github.com/...), got: {issue_url}"
        )

    if not approval_comment_url:
        validation_errors.append(
            "'approval_comment_url' is required. Use `escalate_to_human` with "
            "`approval_requested=True` to obtain a Slack approval record URL."
        )

    if validation_errors:
        return WorkspaceVersionOverrideResult(
            success=False,
            message="Authorization validation failed: " + "; ".join(validation_errors),
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    # Derive admin email from the approval URL (domain-based dispatch)
    try:
        admin_user_email = resolve_admin_email_from_approval(
            approval_comment_url=approval_comment_url,
        )
    except ApprovalResolutionError as e:
        return WorkspaceVersionOverrideResult(
            success=False,
            message=str(e),
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    # Tier guardrail: resolve workspace tier BEFORE the destructive operation
    ws_resolution = resolve_workspace(resolved_workspace_id)
    if not ws_resolution.organization_id:
        return WorkspaceVersionOverrideResult(
            success=False,
            message=f"Could not resolve organization for workspace {resolved_workspace_id}",
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    customer_tier = ws_resolution.customer_tier
    is_eu = (
        ws_resolution.dataplane_name == "EU" if ws_resolution.dataplane_name else None
    )
    tier_warning = _build_tier_warning(customer_tier)

    tier_ok, tier_error = _validate_tier_filter(customer_tier, customer_tier_filter)
    if not tier_ok:
        return WorkspaceVersionOverrideResult(
            success=False,
            message=tier_error or "Tier filter mismatch",
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
            customer_tier=customer_tier,
            is_eu=is_eu,
            tier_warning=tier_warning,
        )

    # Build enhanced override reason with audit fields (only for 'set' operations)
    enhanced_override_reason = override_reason
    if not unset and override_reason:
        audit_parts = [override_reason]
        audit_parts.append(f"Issue: {issue_url}")
        audit_parts.append(f"Approval: {approval_comment_url}")
        if ai_agent_session_url:
            audit_parts.append(f"AI Session: {ai_agent_session_url}")
        enhanced_override_reason = " | ".join(audit_parts)

    # Existing-pin guard: check workspace and org scopes (skip when unsetting)
    if not unset and version:
        try:
            auth = _resolve_cloud_auth(ctx)
            resolved_config_api_root = (
                config_api_root or constants.CLOUD_CONFIG_API_ROOT
            )
            access_token = _get_access_token(
                auth.client_id, auth.client_secret, auth.bearer_token
            )
            from airbyte_ops_mcp.mcp.prod_db_queries import (
                _resolve_canonical_name_to_definition_id,
            )

            actor_definition_id = _resolve_canonical_name_to_definition_id(
                connector_name
            )

            guard = check_existing_pins(
                scopes=[
                    (_ScopeType.WORKSPACE, resolved_workspace_id, "workspace"),
                    (
                        _ScopeType.ORGANIZATION,
                        ws_resolution.organization_id,
                        "organization",
                    ),
                ],
                actor_definition_id=actor_definition_id,
                config_api_root=resolved_config_api_root,
                access_token=access_token,
                target_version=version,
                force=force,
            )
            if guard.blocked:
                assert guard.error_msg is not None  # narrowing for type checker
                return WorkspaceVersionOverrideResult(
                    success=False,
                    message=guard.error_msg,
                    workspace_id=resolved_workspace_id,
                    connector_name=connector_name,
                    connector_type=connector_type,
                )
        except (PyAirbyteInputError, CloudAuthError) as e:
            return WorkspaceVersionOverrideResult(
                success=False,
                message=f"Pin guard check failed: {e}",
                workspace_id=resolved_workspace_id,
                connector_name=connector_name,
                connector_type=connector_type,
            )

    # Resolve auth and call API client
    try:
        auth = _resolve_cloud_auth(ctx)

        result = api_client.set_workspace_connector_version_override(
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
            config_api_root=config_api_root or constants.CLOUD_CONFIG_API_ROOT,
            client_id=auth.client_id,
            client_secret=auth.client_secret,
            bearer_token=auth.bearer_token,
            version=version,
            unset=unset,
            override_reason=enhanced_override_reason,
            override_reason_reference_url=override_reason_reference_url,
            user_email=admin_user_email,
        )

        if unset:
            if result:
                message = f"Successfully cleared workspace-level version override for {connector_name}."
            else:
                message = f"No workspace-level version override was active for {connector_name} (nothing to clear)"
        else:
            message = f"Successfully pinned {connector_name} to version {version} at workspace level."

        if tier_warning:
            message = f"{tier_warning} {message}"

        return WorkspaceVersionOverrideResult(
            success=True,
            message=message,
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
            version=version if not unset else None,
            customer_tier=customer_tier,
            is_eu=is_eu,
            tier_warning=tier_warning,
        )

    except PyAirbyteInputError as e:
        return WorkspaceVersionOverrideResult(
            success=False,
            message=str(e),
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )
    except CloudAuthError as e:
        return WorkspaceVersionOverrideResult(
            success=False,
            message=f"Authentication failed: {e}",
            workspace_id=resolved_workspace_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )


@mcp_tool(
    destructive=True,
    idempotent=False,
    open_world=True,
)
def set_organization_connector_version_override(
    organization_id: Annotated[
        str,
        Field(description="The Airbyte Cloud organization ID."),
    ],
    connector_name: Annotated[
        str,
        Field(
            description="The connector name (e.g., 'source-github', 'destination-bigquery')."
        ),
    ],
    connector_type: Annotated[
        Literal["source", "destination"],
        "The type of connector (source or destination)",
    ],
    approval_comment_url: Annotated[
        str | None,
        Field(
            description="URL to the Slack approval record. Obtain this by calling the "
            "`escalate_to_human` tool with `approval_requested=True`; the backend delivers "
            "the approval record URL when a human clicks Approve. "
            "Format: https://<workspace>.slack.com/archives/... "
            "The admin email is automatically resolved from the approver's identity "
            "via the team roster.",
            default=None,
        ),
    ],
    version: Annotated[
        str | None,
        Field(
            description="The semver version string to pin to (e.g., '0.1.0'). "
            "Must be None if unset is True.",
            default=None,
        ),
    ],
    unset: Annotated[
        bool,
        Field(
            description="If True, removes any existing version override. "
            "Cannot be True if version is provided.",
            default=False,
        ),
    ],
    override_reason: Annotated[
        str | None,
        Field(
            description="Required when setting a version. "
            "Explanation for the override (min 10 characters).",
            default=None,
        ),
    ],
    override_reason_reference_url: Annotated[
        str | None,
        Field(
            description="Optional URL with more context (e.g., issue link).",
            default=None,
        ),
    ],
    issue_url: Annotated[
        str | None,
        Field(
            description="URL to the GitHub issue providing context for this operation. "
            "Must be a valid GitHub URL (https://github.com/...). Required for authorization.",
            default=None,
        ),
    ],
    ai_agent_session_url: Annotated[
        str | None,
        Field(
            description="URL to the AI agent session driving this operation, if applicable. "
            "Provides additional auditability for AI-driven operations.",
            default=None,
        ),
    ] = None,
    force: Annotated[
        bool,
        Field(
            description="If `True`, allow overwriting an existing version pin. "
            "Existing pins may have been set by rollouts, breaking-change migrations, "
            "or other operators. Defaults to `False`. NOTE: `force=True` only "
            "bypasses the existing-pin check — major-version crossings are always "
            "blocked and cannot be overridden.",
            default=False,
        ),
    ] = False,
    config_api_root: Annotated[
        str | None,
        Field(
            description="Optional API root URL override for the Config API. "
            "Defaults to Airbyte Cloud (https://cloud.airbyte.com/api/v1). "
            "Use this to target local or self-hosted deployments.",
            default=None,
        ),
    ] = None,
    customer_tier_filter: Annotated[
        TierFilter,
        Field(
            description=(
                "Required tier filter: 'TIER_0', 'TIER_1', 'TIER_2', or 'ALL'. "
                "The operation will be rejected if the actual customer tier does not match. "
                "Use 'ALL' to proceed regardless of tier (a warning is shown for sensitive tiers)."
            ),
        ),
    ] = "TIER_2",
    *,
    ctx: Context,
) -> OrganizationVersionOverrideResult:
    """Set or clear an organization-level version override for a connector type.

    This pins ALL instances of a connector type across an entire organization to a
    specific version. For example, pinning 'source-github' at organization level means
    all GitHub sources in all workspaces within that organization will use the pinned version.

    **Admin-only operation** - Requires:
    - AIRBYTE_INTERNAL_ADMIN_FLAG=airbyte.io environment variable
    - issue_url parameter (GitHub issue URL for context)
    - approval_comment_url (Slack approval record URL from `escalate_to_human`)

    You must specify EXACTLY ONE of `version` OR `unset=True`, but not both.
    When setting a version, `override_reason` is required.

    The `customer_tier_filter` parameter gates the operation: the call fails if
    the actual tier of the organization does not match.  Use `ALL` to bypass
    the check (a warning is still emitted for sensitive tiers).
    """
    # Validate admin access (check env var flag)
    try:
        require_internal_admin_flag_only()
    except CloudAuthError as e:
        return OrganizationVersionOverrideResult(
            success=False,
            message=f"Admin authentication failed: {e}",
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    # Validate authorization parameters
    validation_errors: list[str] = []

    if not issue_url:
        validation_errors.append(
            "issue_url is required for authorization (GitHub issue URL)"
        )
    elif not issue_url.startswith("https://github.com/"):
        validation_errors.append(
            f"issue_url must be a valid GitHub URL (https://github.com/...), got: {issue_url}"
        )

    if not approval_comment_url:
        validation_errors.append(
            "'approval_comment_url' is required. Use `escalate_to_human` with "
            "`approval_requested=True` to obtain a Slack approval record URL."
        )

    if validation_errors:
        return OrganizationVersionOverrideResult(
            success=False,
            message="Authorization validation failed: " + "; ".join(validation_errors),
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    # Derive admin email from the approval URL (domain-based dispatch)
    try:
        admin_user_email = resolve_admin_email_from_approval(
            approval_comment_url=approval_comment_url,
        )
    except ApprovalResolutionError as e:
        return OrganizationVersionOverrideResult(
            success=False,
            message=str(e),
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )

    # Tier guardrail: resolve org tier BEFORE the destructive operation
    # (placed after auth checks to avoid exposing tier info to unauthenticated callers)
    tier_result = get_org_tier(organization_id)
    customer_tier = tier_result.customer_tier
    tier_warning = _build_tier_warning(customer_tier)

    tier_ok, tier_error = _validate_tier_filter(customer_tier, customer_tier_filter)
    if not tier_ok:
        return OrganizationVersionOverrideResult(
            success=False,
            message=tier_error or "Tier filter mismatch",
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
            customer_tier=customer_tier,
            tier_warning=tier_warning,
        )

    # Build enhanced override reason with audit fields (only for 'set' operations)
    enhanced_override_reason = override_reason
    if not unset and override_reason:
        audit_parts = [override_reason]
        audit_parts.append(f"Issue: {issue_url}")
        audit_parts.append(f"Approval: {approval_comment_url}")
        if ai_agent_session_url:
            audit_parts.append(f"AI Session: {ai_agent_session_url}")
        enhanced_override_reason = " | ".join(audit_parts)

    # Existing-pin guard: check org scope (skip when unsetting)
    if not unset and version:
        try:
            auth = _resolve_cloud_auth(ctx)
            resolved_config_api_root = (
                config_api_root or constants.CLOUD_CONFIG_API_ROOT
            )
            access_token = _get_access_token(
                auth.client_id, auth.client_secret, auth.bearer_token
            )
            from airbyte_ops_mcp.mcp.prod_db_queries import (
                _resolve_canonical_name_to_definition_id,
            )

            actor_definition_id = _resolve_canonical_name_to_definition_id(
                connector_name
            )

            guard = check_existing_pins(
                scopes=[
                    (_ScopeType.ORGANIZATION, organization_id, "organization"),
                ],
                actor_definition_id=actor_definition_id,
                config_api_root=resolved_config_api_root,
                access_token=access_token,
                target_version=version,
                force=force,
            )
            if guard.blocked:
                assert guard.error_msg is not None  # narrowing for type checker
                return OrganizationVersionOverrideResult(
                    success=False,
                    message=guard.error_msg,
                    organization_id=organization_id,
                    connector_name=connector_name,
                    connector_type=connector_type,
                )
        except (PyAirbyteInputError, CloudAuthError) as e:
            return OrganizationVersionOverrideResult(
                success=False,
                message=f"Pin guard check failed: {e}",
                organization_id=organization_id,
                connector_name=connector_name,
                connector_type=connector_type,
            )

    # Resolve auth and call API client
    try:
        auth = _resolve_cloud_auth(ctx)

        result = api_client.set_organization_connector_version_override(
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
            config_api_root=config_api_root or constants.CLOUD_CONFIG_API_ROOT,
            client_id=auth.client_id,
            client_secret=auth.client_secret,
            bearer_token=auth.bearer_token,
            version=version,
            unset=unset,
            override_reason=enhanced_override_reason,
            override_reason_reference_url=override_reason_reference_url,
            user_email=admin_user_email,
        )

        if unset:
            if result:
                message = f"Successfully cleared organization-level version override for {connector_name}."
            else:
                message = f"No organization-level version override was active for {connector_name} (nothing to clear)"
        else:
            message = f"Successfully pinned {connector_name} to version {version} at organization level."

        if tier_warning:
            message = f"{tier_warning} {message}"

        return OrganizationVersionOverrideResult(
            success=True,
            message=message,
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
            version=version if not unset else None,
            customer_tier=customer_tier,
            tier_warning=tier_warning,
        )

    except PyAirbyteInputError as e:
        return OrganizationVersionOverrideResult(
            success=False,
            message=str(e),
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )
    except CloudAuthError as e:
        return OrganizationVersionOverrideResult(
            success=False,
            message=f"Authentication failed: {e}",
            organization_id=organization_id,
            connector_name=connector_name,
            connector_type=connector_type,
        )


def register_cloud_connector_version_tools(app: FastMCP) -> None:
    """Register cloud connector version management tools with the FastMCP app.

    Args:
        app: FastMCP application instance
    """
    register_mcp_tools(app, mcp_module=__name__)
