import re
import time
import json
import requests
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
from lexicont.config_loader import load_config, load_rules, get_patterns_path
from lexicont.logger import get_logger
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct, Distance, VectorParams
from sentence_transformers import SentenceTransformer

logger = get_logger("llm_judge")

rules_data = load_rules()
llm_rules = rules_data.get("llm", {})
THREAT_MARKERS = llm_rules.get("threat_markers", [])

BACKEND = None
MODEL = None
API_URL = None
RAG_ENABLED = None
COLLECTION_NAME = None
EMBEDDING_MODEL_NAME = None
TOP_K = None
SCORE_THRESHOLD = None
STORE_BACKEND = None
SERVER_HOST = None
SERVER_PORT = None
SERVER_API_KEY = None
AUTO_CREATE = None
AUTO_LOAD = None
PATTERNS_REL_PATH = None

_rag_client = None
_rag_embedder = None


def _get_cfg():
    return load_config()["llm_judge"]


def _get_rag_cfg(cfg):
    return cfg.get("rag", {"enabled": False})


def _resolve_module_vars():
    global BACKEND, MODEL, API_URL, RAG_ENABLED, COLLECTION_NAME
    global EMBEDDING_MODEL_NAME, TOP_K, SCORE_THRESHOLD, STORE_BACKEND
    global SERVER_HOST, SERVER_PORT, SERVER_API_KEY, AUTO_CREATE, AUTO_LOAD
    global PATTERNS_REL_PATH

    cfg = _get_cfg()
    rag_cfg = _get_rag_cfg(cfg)

    BACKEND = cfg["backend"]
    MODEL = cfg[BACKEND]["model"]
    API_URL = cfg[BACKEND]["url"]

    RAG_ENABLED = rag_cfg.get("enabled", False)
    COLLECTION_NAME = rag_cfg.get("collection_name", "rag_patterns")
    EMBEDDING_MODEL_NAME = rag_cfg.get("embedding_model", "intfloat/multilingual-e5-small")
    TOP_K = rag_cfg.get("top_k", 1)
    SCORE_THRESHOLD = rag_cfg.get("score_threshold", 0.65)
    STORE_BACKEND = rag_cfg.get("store_backend", "inmemory")

    SERVER_HOST = rag_cfg.get("server_host", "localhost")
    SERVER_PORT = rag_cfg.get("server_port", 6333)
    SERVER_API_KEY = rag_cfg.get("server_api_key", None) or None

    AUTO_CREATE = rag_cfg.get("auto_create", False)
    AUTO_LOAD = rag_cfg.get("auto_load", False)

    PATTERNS_REL_PATH = rag_cfg.get("patterns_path", "rag/patterns.jsonl")


def _load_patterns_into_collection():
    path = get_patterns_path()

    with open(path, encoding="utf-8") as f:
        lines = f.readlines()

    patterns = [
        json.loads(line.strip())
        for line in lines
        if line.strip() and not line.startswith("#")
    ]

    texts = [p["text"] for p in patterns]
    embeddings = _rag_embedder.encode(texts, normalize_embeddings=True)

    points = [
        PointStruct(
            id=i,
            vector=emb.tolist(),
            payload={
                "text": p["text"],
                "label": p["label"],
                "category": p.get("category", ""),
            },
        )
        for i, (emb, p) in enumerate(zip(embeddings, patterns))
    ]

    _rag_client.upsert(collection_name=COLLECTION_NAME, points=points)


def _init_rag():
    global _rag_client, _rag_embedder

    if _rag_embedder is not None:
        return

    _rag_embedder = SentenceTransformer(EMBEDDING_MODEL_NAME)
    _rag_client = QdrantClient(":memory:")

    dim = _rag_embedder.get_sentence_embedding_dimension()

    _rag_client.create_collection(
        collection_name=COLLECTION_NAME,
        vectors_config=VectorParams(size=dim, distance=Distance.COSINE),
    )

    _load_patterns_into_collection()


def get_rag_context(text):
    if not RAG_ENABLED:
        return ""

    if _rag_embedder is None:
        _init_rag()

    try:
        query_vec = _rag_embedder.encode([text], normalize_embeddings=True)[0].tolist()

        results = _rag_client.query_points(
            collection_name=COLLECTION_NAME,
            query=query_vec,
            limit=TOP_K,
            score_threshold=SCORE_THRESHOLD,
        ).points

        if not results:
            return ""

        labels = [hit.payload.get("label", "") for hit in results]

        return (
            "RAG_CONTEXT:\n"
            + "\n".join(f"- {label}" for label in labels)
        )

    except Exception:
        return ""


class LlmJudgeResult(BaseModel):
    stage: str = "llm_judge"
    decision: str
    confidence: float
    reason: Optional[str]
    original_text: str
    normalized_text: str
    meta: Dict[str, Any] = Field(default_factory=dict)


def clamp(val, default=0.0):
    try:
        return max(0.0, min(1.0, float(val)))
    except Exception:
        return default


def parse_json(text):
    if not text:
        return None

    if "</think>" in text:
        text = text.split("</think>", 1)[-1].strip()

    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.DOTALL).strip()

    last_brace = text.rfind("{")
    if last_brace != -1:
        candidate = text[last_brace:]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    try:
        return json.loads(text)
    except Exception:
        return None


def _valid_schema(p):
    if not isinstance(p, dict):
        return False

    required = {"decision", "confidence", "flags", "reason"}
    if not required.issubset(p.keys()):
        return False

    if p["decision"] not in {"block", "review", "pass"}:
        return False

    try:
        float(p["confidence"])
    except Exception:
        return False

    return True


def make_decision(confidence, cfg):
    if confidence >= cfg["block_threshold"]:
        return "block", f"confidence={confidence:.2f}"
    if confidence >= cfg["review_threshold"]:
        return "review", f"confidence={confidence:.2f}"
    return "pass", "no violation"


def call_llm(messages, cfg):
    try:
        payload = {
            "model": MODEL,
            "messages": messages,
            "stream": False,
            # "format": "json",  
            "options": {
                "temperature": 0.0,
                "top_p": 0.9,
                "top_k": 20,
                "num_predict": cfg["max_tokens"],
                "repeat_penalty": 1.1,
            },
            "keep_alive": "5m" 
        }

        timeout_val = cfg.get("timeout", 60)
        r = requests.post(API_URL, json=payload, timeout=timeout_val)
        r.raise_for_status()

        resp = r.json()
        
        message_obj = resp.get("message", {})
        content = message_obj.get("content", "")
        

        if "</think>" in content:
            content = content.split("</think>", 1)[-1].strip()

        return content

    except requests.exceptions.Timeout:
        logger.error(f"llm_judge call timed out after {cfg.get('timeout', 60)}s")
        return ""
    except Exception as e:
        logger.error(f"llm_judge call error: {e}")
        return ""


def run(text, stage1=None, stage2=None, stage3=None, original_text=None):
    _resolve_module_vars()
    cfg = _get_cfg()

    try:
        rag_info = get_rag_context(text)

        system_content = (
            cfg["rag_system_prompt"]
            if RAG_ENABLED and rag_info
            else cfg["system_prompt"]
        )

        text_block = f'Text: """{text}"""'

        if original_text and original_text != text:
            text_block = (
                f'Original: """{original_text}"""\n'
                f'Normalized: """{text}"""'
            )

        user_content = text_block
        if rag_info:
            user_content = f"{text_block}\n\n{rag_info}"

        messages = [
            {"role": "system", "content": system_content},
            {"role": "user", "content": user_content},
        ]

        logger.debug("=== ACTUAL LLM PROMPT ===")
        for msg in messages:
            logger.debug(f"Role: {msg['role']}")
            logger.debug(f"Content:\n{msg['content']}")
            logger.debug("-" * 20)
        logger.debug("=========================")

        parsed = None

        for attempt in range(cfg["retries"]):
            content = call_llm(messages, cfg)

            logger.debug(f"=== RAW LLM RESPONSE (Attempt {attempt + 1}) ===")
            logger.debug(content)
            logger.debug("===============================================")

            if not content:
                time.sleep(1)
                continue

            parsed = parse_json(content)

            if parsed and _valid_schema(parsed):
                break

            parsed = None
            time.sleep(1.5)

        if not parsed:
            return LlmJudgeResult(
                decision="review",
                confidence=0.5,
                reason="invalid llm output",
                original_text=text,
                normalized_text=text.lower(),
                meta={"error": "invalid_schema"},
            )

        confidence = clamp(parsed.get("confidence", 0.5))
        llm_reason = (parsed.get("reason") or "").strip()

        final_decision, confidence_reason = make_decision(confidence, cfg)
        reason = llm_reason if llm_reason else confidence_reason

        return LlmJudgeResult(
            decision=final_decision,
            confidence=round(confidence, 4),
            reason=reason,
            original_text=text,
            normalized_text=text.lower(),
            meta={"rag_used": bool(rag_info)},
        )

    except Exception as e:
        logger.error(f"llm_judge error: {e}")
        return LlmJudgeResult(
            decision="block",
            confidence=1.0,
            reason="system error",
            original_text=text,
            normalized_text=text.lower(),
            meta={"error": str(e)},
        )