import streamlit as st
import requests
import json

st.set_page_config(
    page_title="lexicont",
    page_icon="🛡️",
    layout="centered"
)

st.title("🛡️ lexicont")
st.markdown("Policy-driven real-time text moderation")

# Input
text = st.text_area(
    "Enter text to moderate",
    height=150,
    placeholder="Paste or type the text here...",
    help="Maximum 2,000 characters"
)

col1, col2 = st.columns([1, 1])
with col1:
    moderate_btn = st.button("Moderate", type="primary", use_container_width=True)
with col2:
    clear_btn = st.button("Clear", use_container_width=True)

if clear_btn:
    st.session_state.clear()
    st.rerun()

if moderate_btn and text.strip():
    with st.spinner("Moderating..."):
        try:
            response = requests.post(
                "http://lexicont:8000/moderate",
                json={"text": text},
                timeout=60
            )
            response.raise_for_status()
            data = response.json()

            # Result header
            if data["decision"] == "block":
                st.error(f"DECISION: BLOCK  |  Confidence: {data['confidence']:.3f}")
            elif data["decision"] == "review":
                st.warning(f"DECISION: REVIEW  |  Confidence: {data['confidence']:.3f}")
            else:
                st.success(f"DECISION: PASS  |  Confidence: {data['confidence']:.3f}")

            if data.get("explanation"):
                st.caption(data["explanation"])

            # Trace
            st.subheader("Pipeline Trace")
            st.code(data["trace"], language="text")

            # Stages (collapsible)
            with st.expander("Detailed Stages", expanded=True):
                for stage in data.get("stages", []):
                    with st.container():
                        col_a, col_b = st.columns([3, 1])
                        with col_a:
                            st.markdown(f"**{stage['stage']}**")
                        with col_b:
                            if stage["decision"] == "block":
                                st.error(stage["decision"].upper())
                            elif stage["decision"] == "review":
                                st.warning(stage["decision"].upper())
                            else:
                                st.success(stage["decision"].upper())
                        
                        st.caption(f"Confidence: {stage['confidence']:.3f}")
                        if stage.get("reason"):
                            st.text(stage["reason"])
                        st.divider()

            # Raw JSON (for debugging)
            with st.expander("Raw Response (JSON)"):
                st.json(data)

        except requests.exceptions.ConnectionError:
            st.error("Cannot connect to backend. Is the `lexicont` service running?")
        except Exception as e:
            st.error(f"Error: {str(e)}")

else:
    st.info("Enter text and click **Moderate**")
