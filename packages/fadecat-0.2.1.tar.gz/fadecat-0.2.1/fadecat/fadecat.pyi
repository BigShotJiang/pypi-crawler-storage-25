from typing import Protocol, Tuple

class GradientMethod(Protocol):
    def __call__(self, text: str, tilt: int = 0) -> str: ...

class FadeCat:
    aqua: GradientMethod
    fire: GradientMethod
    purplepink: GradientMethod
    forest: GradientMethod
    blood: GradientMethod
    gold: GradientMethod
    sky: GradientMethod
    rust: GradientMethod
    cyberpunk: GradientMethod
    radioactive: GradientMethod
    synthwave: GradientMethod
    galaxy: GradientMethod
    mango: GradientMethod
    sunset: GradientMethod
    ice: GradientMethod
    rosegold: GradientMethod
    aurora: GradientMethod
    mint: GradientMethod
    twilight: GradientMethod
    amethyst: GradientMethod
    champagne: GradientMethod
    coral: GradientMethod
    sakura: GradientMethod
    lavender: GradientMethod
    dracula: GradientMethod
    peach: GradientMethod
    monokai: GradientMethod
    bubblegum: GradientMethod
    lemonade: GradientMethod
    phantom: GradientMethod
    velvet: GradientMethod
    midnight: GradientMethod
    matrix: GradientMethod
    nebula: GradientMethod
    fusion: GradientMethod

    def custom(self, text: str, start_color: Tuple[int, int, int], 
               end_color: Tuple[int, int, int], tilt: int = 0) -> str: ...
    
    def _apply_gradient(self, text: str, start_color: Tuple[int, int, int], 
                        end_color: Tuple[int, int, int], tilt: int = 0) -> str: ...

    def _enable_ansi(self) -> None: ...
    
    def _interpolate_color(self, ratio: float, start_rgb: Tuple[int, int, int], 
                           end_rgb: Tuple[int, int, int]) -> Tuple[int, int, int]: ...

fadecat: FadeCat