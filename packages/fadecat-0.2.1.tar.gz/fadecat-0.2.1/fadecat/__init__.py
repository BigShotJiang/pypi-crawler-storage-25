from .fadecat import FadeCat
fadecat = FadeCat()
__all__ = ["FadeCat", "fadecat"]