#added changelogs.md, reread after each update
#made by github.com/m2uroy

import sys
import ctypes
import math

class FadeCat:
    PALETTES = {
        "aqua": ((0, 255, 255), (0, 128, 128)),
        "fire": ((255, 0, 0), (255, 255, 0)),
        "purplepink": ((128, 0, 128), (255, 105, 180)),
        "forest": ((0, 75, 31), (118, 255, 3)),
        "blood": ((138, 3, 3), (255, 0, 0)),
        "gold": ((255, 215, 0), (153, 101, 21)),
        "sky": ((0, 191, 255), (240, 255, 255)),
        "rust": ((184, 115, 51), (67, 181, 129)),
        "cyberpunk": ((255, 0, 255), (0, 255, 255)),
        "radioactive": ((255, 255, 0), (50, 205, 50)),
        "synthwave": ((255, 0, 255), (51, 51, 255)),
        "galaxy": ((7, 0, 82), (180, 0, 255)),
        "mango": ((255, 154, 0), (255, 0, 115)),
        "sunset": ((255, 94, 77), (255, 195, 113)),
        "ice": ((180, 248, 255), (0, 119, 182)),
        "rosegold": ((255, 183, 197), (212, 175, 55)),
        "aurora": ((0, 255, 170), (128, 0, 255)),
        "mint": ((0, 255, 127), (0, 100, 0)),
        "twilight": ((75, 0, 130), (255, 20, 147)),
        "amethyst": ((156, 81, 182), (102, 51, 153)),
        "champagne": ((247, 231, 206), (210, 180, 140)),
        "coral": ((255, 127, 80), (255, 69, 0)),
        "sakura": ((255, 192, 203), (255, 105, 180)),
        "lavender": ((230, 230, 250), (147, 112, 219)),
        "dracula": ((255, 121, 198), (189, 147, 249)),
        "peach": ((251, 150, 86), (235, 208, 182)),
        "monokai": ((249, 38, 114), (102, 217, 239)),
        "bubblegum": ((255, 105, 180), (255, 20, 147)),
        "lemonade": ((255, 255, 0), (50, 205, 50)),
        "phantom": ((100, 100, 150), (200, 200, 255)),
        "velvet": ((160, 30, 50), (220, 80, 100)),
        "midnight": ((30, 40, 90), (80, 110, 180)),
        "matrix": ((0, 255, 70), (0, 50, 0)),
        "nebula": ((106, 13, 173), (0, 255, 255)),
        "fusion": ((0, 255, 255), (0, 0, 128)),
    }

    def __init__(self):
        self._enable_ansi()

    def _enable_ansi(self):
        if sys.platform == "win32":
            try:
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.GetStdHandle(-11)
                mode = ctypes.c_ulong()
                kernel32.GetConsoleMode(handle, ctypes.byref(mode))
                if not (mode.value & 0x0004):
                    kernel32.SetConsoleMode(handle, mode.value | 0x0004)
            except Exception:
                pass

    def _interpolate_color(self, ratio, start_rgb, end_rgb):
        r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
        g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
        b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
        return max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))

    def _apply_gradient(self, text, start_color, end_color, tilt=0):
        if not text: return ""
        lines = text.splitlines()
        if not lines: return ""

        max_width = max(len(line) for line in lines)
        height = len(lines)
        if max_width == 0: return ""
        
        ASPECT_RATIO = 0.5
        y_scale = 1.0 / max(1, height - 1)
        x_scale = 1.0 / max_width
        rad = math.radians(tilt)
        cos_a, sin_a = math.cos(rad), math.sin(rad)
        
        min_proj, max_proj = float('inf'), float('-inf')
        char_data = []

        for y, line in enumerate(lines):
            line_data = []
            for x, char in enumerate(line):
                nx, ny = x * x_scale, (y * y_scale) * ASPECT_RATIO
                proj = nx * cos_a + ny * sin_a
                min_proj, max_proj = min(min_proj, proj), max(max_proj, proj)
                line_data.append((char, nx, ny))
            char_data.append(line_data)

        range_proj = max_proj - min_proj if (max_proj - min_proj) > 1e-6 else 1.0
        result = []
        for line_data in char_data:
            for char, nx, ny in line_data:
                proj = nx * cos_a + ny * sin_a
                ratio = max(0.0, min(1.0, (proj - min_proj) / range_proj))
                ratio = ratio * ratio * (3 - 2 * ratio)
                r, g, b = self._interpolate_color(ratio, start_color, end_color)
                result.append(f"\033[38;2;{r};{g};{b}m{char}")
            result.append("\n")

        return ''.join(result).rstrip('\n') + "\033[0m"

    def custom(self, text, start_color, end_color, tilt=0):
        return self._apply_gradient(text, start_color, end_color, tilt)

    def __getattr__(self, name):
        if name in self.PALETTES:
            start, end = self.PALETTES[name]
            return lambda text, tilt=0: self._apply_gradient(text, start, end, tilt)
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

fadecat = FadeCat()