"""
monk serve — watches trace files and exposes Prometheus metrics + JSON endpoint.

Exposes:
  GET /metrics   — Prometheus text format
  GET /findings  — JSON summary of all findings
  GET /health    — liveness check

Usage:
  monk serve ./traces/ --port 9090 --interval 30
"""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from monk.detectors import ALL_DETECTORS
from monk.parsers.auto import parse_traces


class MetricsStore:
    """Thread-safe Prometheus metrics store."""

    def __init__(self):
        self._lock = threading.Lock()
        self._findings_count: dict[tuple, int] = {}
        self._waste: dict[str, float] = {}
        self._sessions_total = 0
        self._calls_total = 0
        self._last_scan_ts = 0.0
        self._high_total = 0
        self._recent: list[dict] = []

    def update(self, findings, calls, sessions: int) -> None:
        with self._lock:
            self._sessions_total += sessions
            self._calls_total += len(calls)
            self._last_scan_ts = time.time()

            for f in findings:
                key = (f.detector, f.severity)
                self._findings_count[key] = self._findings_count.get(key, 0) + 1
                self._waste[f.detector] = (
                    self._waste.get(f.detector, 0.0) + f.estimated_waste_usd_per_day
                )
                if f.severity == "high":
                    self._high_total += 1

                self._recent.append({
                    "detector": f.detector,
                    "severity": f.severity,
                    "title": f.title,
                    "detail": f.detail,
                    "fix": f.fix,
                    "sessions": f.affected_sessions[:3],
                    "waste_per_day": round(f.estimated_waste_usd_per_day, 4),
                    "ts": self._last_scan_ts,
                })

            if len(self._recent) > 500:
                self._recent = self._recent[-500:]

    def to_prometheus(self) -> str:
        with self._lock:
            lines = [
                "# HELP monk_findings_total Total findings by detector and severity",
                "# TYPE monk_findings_total counter",
            ]
            for (det, sev), count in sorted(self._findings_count.items()):
                lines.append(f'monk_findings_total{{detector="{det}",severity="{sev}"}} {count}')

            lines += [
                "# HELP monk_waste_usd_per_day Estimated daily waste USD by detector",
                "# TYPE monk_waste_usd_per_day gauge",
            ]
            for det, waste in sorted(self._waste.items()):
                lines.append(f'monk_waste_usd_per_day{{detector="{det}"}} {waste:.4f}')

            lines += [
                "# HELP monk_sessions_analyzed_total Total agent sessions analyzed",
                "# TYPE monk_sessions_analyzed_total counter",
                f"monk_sessions_analyzed_total {self._sessions_total}",
                "# HELP monk_calls_analyzed_total Total LLM calls analyzed",
                "# TYPE monk_calls_analyzed_total counter",
                f"monk_calls_analyzed_total {self._calls_total}",
                "# HELP monk_last_scan_timestamp Unix timestamp of last scan",
                "# TYPE monk_last_scan_timestamp gauge",
                f"monk_last_scan_timestamp {self._last_scan_ts:.0f}",
                "# HELP monk_high_severity_findings_total High-severity findings total",
                "# TYPE monk_high_severity_findings_total counter",
                f"monk_high_severity_findings_total {self._high_total}",
            ]
            return "\n".join(lines) + "\n"

    def to_json(self) -> str:
        with self._lock:
            total_waste = sum(self._waste.values())
            total = sum(self._findings_count.values())
            return json.dumps({
                "summary": {
                    "total_findings": total,
                    "high": sum(v for (_, s), v in self._findings_count.items() if s == "high"),
                    "medium": sum(v for (_, s), v in self._findings_count.items() if s == "medium"),
                    "low": sum(v for (_, s), v in self._findings_count.items() if s == "low"),
                    "sessions_analyzed": self._sessions_total,
                    "calls_analyzed": self._calls_total,
                    "waste_usd_per_day": round(total_waste, 2),
                    "waste_usd_per_month": round(total_waste * 30, 2),
                    "last_scan": self._last_scan_ts,
                },
                "by_detector": {
                    det: {"waste_per_day": round(w, 4)}
                    for det, w in sorted(self._waste.items())
                },
                "recent_findings": self._recent[-20:],
            }, indent=2)


DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>monk — Agent Cost Control Room</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0c0c0c;--s1:#111;--s2:#161616;--b1:#1f1f1f;--b2:#2a2a2a;
  --t1:#fff;--t2:#a0a0a0;--t3:#555;
  --or:#f97316;--or2:#f9731618;--or3:#f9731630;
  --red:#ff4444;--grn:#22c55e;--blue:#3b82f6;
  --mono:'JetBrains Mono',monospace;
}
html{font-size:14px}
body{font-family:'Inter',-apple-system,sans-serif;background:var(--bg);color:var(--t1);min-height:100vh;-webkit-font-smoothing:antialiased}

/* NAV */
nav{position:sticky;top:0;z-index:50;background:rgba(12,12,12,.92);backdrop-filter:blur(20px);border-bottom:1px solid var(--b1);height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 28px}
.nav-l{display:flex;align-items:center;gap:14px}
.logo{font-size:15px;font-weight:700;letter-spacing:-.2px}
.logo span{color:var(--or)}
.pill{font-size:11px;font-weight:600;padding:2px 8px;border-radius:99px;border:1px solid var(--b2);color:var(--t3);font-family:var(--mono)}
.nav-r{display:flex;align-items:center;gap:16px}
#live-badge{display:flex;align-items:center;gap:6px;font-size:11px;padding:4px 10px;border-radius:99px;border:1px solid var(--b2);color:var(--t3);transition:all .3s;font-family:var(--mono)}
#live-badge.live{color:var(--grn);border-color:#22c55e30;background:#22c55e08}
#live-badge::before{content:'';width:5px;height:5px;border-radius:50%;background:currentColor;flex-shrink:0}
#live-badge.live::before{box-shadow:0 0 5px var(--grn);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
#refresh-btn{font-size:11px;padding:4px 12px;border-radius:6px;border:1px solid var(--b2);background:transparent;color:var(--t2);cursor:pointer;font-family:var(--mono);transition:all .15s}
#refresh-btn:hover{border-color:var(--or3);color:var(--or)}
.nav-ts{font-size:11px;color:var(--t3);font-family:var(--mono)}

/* LAYOUT */
.page{max-width:1400px;margin:0 auto;padding:24px 28px 60px}

/* SECTION */
.sec-label{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--t3);margin-bottom:16px;display:flex;align-items:center;gap:10px}
.sec-label::after{content:'';flex:1;height:1px;background:var(--b1)}

/* KPI STRIP */
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:var(--b1);border:1px solid var(--b1);border-radius:14px;overflow:hidden;margin-bottom:24px}
.kpi{background:var(--s1);padding:24px 22px;position:relative;transition:background .2s;cursor:default}
.kpi:hover{background:var(--s2)}
.kpi-label{font-size:10px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--t3);margin-bottom:10px}
.kpi-val{font-size:36px;font-weight:800;letter-spacing:-1.5px;line-height:1;margin-bottom:6px;transition:all .4s}
.kpi-val.or{color:var(--or)}
.kpi-sub{font-size:11px;color:var(--t3);line-height:1.5}
.kpi:hover::after{content:'';position:absolute;bottom:0;left:22px;right:22px;height:1px;background:var(--or)}

/* GRID */
.g2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
.g32{display:grid;grid-template-columns:3fr 2fr;gap:16px;margin-bottom:16px}
.g21{display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:24px}

/* PANEL (Grafana-style) */
.panel{background:var(--s1);border:1px solid var(--b1);border-radius:12px;overflow:hidden}
.panel-header{padding:14px 18px 0;display:flex;align-items:center;justify-content:space-between}
.panel-title{font-size:11px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;color:var(--t3)}
.panel-badge{font-size:10px;font-family:var(--mono);padding:2px 7px;border-radius:4px;background:var(--or2);color:var(--or);border:1px solid var(--or3)}
.panel-body{padding:16px 18px 20px}

/* WASTE BARS */
.wrow{margin-bottom:12px}
.wrow:last-child{margin-bottom:0}
.wrow-top{display:flex;justify-content:space-between;margin-bottom:5px}
.wrow-name{font-family:var(--mono);font-size:11px;color:var(--t2)}
.wrow-val{font-family:var(--mono);font-size:11px;font-weight:600;color:var(--or)}
.wrow-val.dim{color:var(--t3)}
.wtrack{height:2px;background:var(--b2);border-radius:1px;overflow:hidden}
.wfill{height:100%;border-radius:1px;background:var(--or);transition:width .6s ease}

/* TABLE */
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
thead th{font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--t3);padding:0 16px 10px;text-align:left;border-bottom:1px solid var(--b1)}
thead th:first-child{padding-left:18px}
thead th:last-child{padding-right:18px}
tbody tr{border-bottom:1px solid var(--b1);transition:background .1s}
tbody tr:last-child{border-bottom:none}
tbody tr:hover{background:var(--s2)}
tbody td{padding:11px 16px;font-size:12px;color:var(--t2);vertical-align:middle}
tbody td:first-child{padding-left:18px}
tbody td:last-child{padding-right:18px}
.chip{display:inline-block;font-family:var(--mono);font-size:11px;font-weight:500;padding:2px 7px;border-radius:4px}
.chip-or{background:var(--or2);color:var(--or);border:1px solid var(--or3)}
.chip-w{background:#fff08;color:#666;border:1px solid #1f1f1f}
.sev{font-size:11px;font-weight:700;display:flex;align-items:center;gap:5px}
.dot{width:5px;height:5px;border-radius:50%;flex-shrink:0}
.sev-h{color:var(--red)}.sev-h .dot{background:var(--red);box-shadow:0 0 4px var(--red)}
.sev-m{color:var(--or)}.sev-m .dot{background:var(--or);box-shadow:0 0 4px var(--or)}
.mn{font-family:var(--mono);font-size:12px}

/* SEVERITY TILES */
.sev-tiles{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:16px}
.sev-tile{background:var(--s2);border:1px solid var(--b1);border-radius:8px;padding:12px;text-align:center}
.sev-tile-val{font-size:24px;font-weight:800;letter-spacing:-.5px}
.sev-tile-lbl{font-size:10px;letter-spacing:.8px;text-transform:uppercase;color:var(--t3);margin-top:3px}

/* STREAM (recent findings feed) */
.stream{display:flex;flex-direction:column;gap:8px;max-height:340px;overflow-y:auto}
.stream::-webkit-scrollbar{width:3px}
.stream::-webkit-scrollbar-track{background:transparent}
.stream::-webkit-scrollbar-thumb{background:var(--b2);border-radius:2px}
.stream-item{background:var(--s2);border:1px solid var(--b1);border-radius:8px;padding:10px 14px;border-left:2px solid var(--b2)}
.stream-item.high{border-left-color:var(--red)}
.stream-item.medium{border-left-color:var(--or)}
.stream-item.low{border-left-color:var(--grn)}
.stream-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px}
.stream-det{font-family:var(--mono);font-size:11px;color:var(--or)}
.stream-time{font-size:10px;color:var(--t3);font-family:var(--mono)}
.stream-title{font-size:12px;color:var(--t2);line-height:1.4}
.stream-fix{font-size:11px;color:var(--t3);margin-top:3px;line-height:1.4}

/* ENDPOINT STRIP */
.endpoints{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:24px}
.ep{background:var(--s2);border:1px solid var(--b1);border-radius:10px;padding:14px 16px;display:flex;align-items:center;gap:12px}
.ep-method{font-family:var(--mono);font-size:11px;font-weight:600;color:var(--or);min-width:32px}
.ep-path{font-family:var(--mono);font-size:12px;color:var(--t1)}
.ep-desc{font-size:11px;color:var(--t3);margin-top:2px}

/* FOOTER */
footer{border-top:1px solid var(--b1);padding:20px 28px;display:flex;align-items:center;justify-content:space-between}
footer .left{font-size:12px;color:var(--t3)}
footer .right{display:flex;gap:18px}
footer a{font-size:12px;color:var(--t3);text-decoration:none;transition:color .15s}
footer a:hover{color:var(--or)}
</style>
</head>
<body>

<nav>
  <div class="nav-l">
    <div class="logo">🕵️ mon<span>k</span></div>
    <div class="pill">v__VERSION__</div>
    <div class="pill">14 detectors</div>
  </div>
  <div class="nav-r">
    <span class="nav-ts" id="ts"></span>
    <button id="refresh-btn" onclick="load()">↻ refresh</button>
    <div id="live-badge">connecting…</div>
  </div>
</nav>

<div class="page">

  <!-- KPIs -->
  <div class="sec-label" style="margin-bottom:16px">Overview</div>
  <div class="kpis" style="margin-bottom:24px">
    <div class="kpi">
      <div class="kpi-label">Total Findings</div>
      <div class="kpi-val" id="k-total">—</div>
      <div class="kpi-sub" id="k-total-sub">loading…</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Waste / Day</div>
      <div class="kpi-val or" id="k-day">—</div>
      <div class="kpi-sub" id="k-day-sub">estimated avoidable spend</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Projected / Month</div>
      <div class="kpi-val or" id="k-month">—</div>
      <div class="kpi-sub">all addressable with targeted fixes</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">LLM Calls Analyzed</div>
      <div class="kpi-val" id="k-calls">—</div>
      <div class="kpi-sub" id="k-calls-sub">across all trace files</div>
    </div>
  </div>

  <!-- CHARTS ROW -->
  <div class="sec-label">Detector Analysis</div>
  <div class="g2">
    <div class="panel">
      <div class="panel-header"><div class="panel-title">Findings by Detector</div></div>
      <div class="panel-body"><canvas id="det-chart" height="280"></canvas></div>
    </div>
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">Severity Distribution</div>
      </div>
      <div class="panel-body">
        <div class="sev-tiles">
          <div class="sev-tile">
            <div class="sev-tile-val" id="s-high" style="color:var(--red)">—</div>
            <div class="sev-tile-lbl">High</div>
          </div>
          <div class="sev-tile">
            <div class="sev-tile-val" id="s-med" style="color:var(--or)">—</div>
            <div class="sev-tile-lbl">Medium</div>
          </div>
          <div class="sev-tile">
            <div class="sev-tile-val" id="s-low" style="color:var(--grn)">—</div>
            <div class="sev-tile-lbl">Low</div>
          </div>
        </div>
        <canvas id="sev-chart" height="180"></canvas>
      </div>
    </div>
  </div>

  <!-- WASTE + STREAM -->
  <div class="g21">
    <div class="panel">
      <div class="panel-header"><div class="panel-title">Waste $/day by Detector</div></div>
      <div class="panel-body"><div id="waste-bars"></div></div>
    </div>
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">Recent Findings</div>
        <div class="panel-badge" id="stream-count">0</div>
      </div>
      <div class="panel-body"><div class="stream" id="stream"></div></div>
    </div>
  </div>

  <!-- TOP FINDINGS TABLE -->
  <div class="sec-label">Top Findings & Fixes</div>
  <div class="panel" style="margin-bottom:24px">
    <div class="tbl-wrap">
      <table>
        <thead><tr>
          <th>Detector</th><th>Severity</th><th>Waste/Day</th>
          <th>What it catches</th><th>Fix</th>
        </tr></thead>
        <tbody id="findings-tbody">
          <tr><td colspan="5" style="text-align:center;padding:28px;color:var(--t3)">Loading…</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- API ENDPOINTS -->
  <div class="sec-label">API Endpoints</div>
  <div class="endpoints">
    <div class="ep">
      <div>
        <div style="display:flex;align-items:center;gap:8px"><span class="ep-method">GET</span><span class="ep-path">/findings</span></div>
        <div class="ep-desc">JSON summary — used by this dashboard</div>
      </div>
    </div>
    <div class="ep">
      <div>
        <div style="display:flex;align-items:center;gap:8px"><span class="ep-method">GET</span><span class="ep-path">/metrics</span></div>
        <div class="ep-desc">Prometheus text format — for Grafana / alerting</div>
      </div>
    </div>
    <div class="ep">
      <div>
        <div style="display:flex;align-items:center;gap:8px"><span class="ep-method">GET</span><span class="ep-path">/health</span></div>
        <div class="ep-desc">Liveness check — returns 200 ok</div>
      </div>
    </div>
  </div>

</div>

<footer>
  <div class="left">🕵️ monk v__VERSION__ · Blueconomy AI · Techstars '25 · MIT</div>
  <div class="right">
    <a href="/findings">findings JSON</a>
    <a href="/metrics">prometheus</a>
    <a href="https://github.com/Blueconomy/monk">GitHub ↗</a>
    <a href="https://pypi.org/project/monk-ai">PyPI ↗</a>
  </div>
</footer>

<script>
Chart.defaults.color='#555';
Chart.defaults.font.family="Inter,-apple-system,sans-serif";
Chart.defaults.font.size=11;

const FIXES={
  agent_loop:       {what:'Agent cycling A→B→A→B with no progress',        fix:'Add a visited-state set; break when (tool,args) recurs within a window.'},
  retry_loop:       {what:'Same tool called 3+ consecutive times',           fix:'Result-cache keyed on (tool,args). Eliminate recomputation.'},
  empty_return:     {what:'Tool returns null → agent retries anyway',        fix:'Guard: if result is empty, inject "no data found" before next LLM call.'},
  context_bloat:    {what:'System prompt >55% of context budget',            fix:'Compress system prompt; sliding-window or summarize every N turns.'},
  token_bloat:      {what:'Single tool injected 5× the session median',      fix:'Truncate tool outputs to 1,000–2,000 tokens before injecting into context.'},
  error_cascade:    {what:'Tool fails silently → 6–8 wasted downstream calls',fix:'Guard every tool call — if error, short-circuit before next LLM call.'},
  cross_turn_memory:{what:'Same tool+args re-fetched across turns',           fix:'Session-level tool result cache with 1-turn TTL.'},
  model_overkill:   {what:'Flagship model doing formatting/classification',  fix:'Route sub-tasks to gpt-4o-mini/haiku; reserve Opus for reasoning.'},
  text_io:          {what:'Low output compression or unbounded input growth', fix:'Truncate inputs; validate task clarity; implement rolling context window.'},
  latency_spike:    {what:'Single call outlier vs session median',           fix:'Add timeout + retry with exponential backoff.'},
  output_format:    {what:'Model violates format rules in system prompt',     fix:'Add a format validator after each LLM call; retry on violation.'},
  plan_execution:   {what:'Model planned steps then never executed them',     fix:'Assert each planned step is followed by a matching tool call.'},
  span_consistency: {what:'Model asserts facts with no supporting tool call', fix:'Require a grounding tool call before asserting external facts.'},
  tool_dependency:  {what:'Cycles or deep chains in tool call graph',         fix:'Flatten tool dependencies; eliminate circular tool calls.'},
};

let detChart=null, sevChart=null;

function fmt(n){return n>=1e6?(n/1e6).toFixed(1)+'M':n>=1000?(n/1000).toFixed(1)+'k':String(n)}
function fmtUSD(v){return v>=1000?'$'+(v/1000).toFixed(1)+'k':'$'+Math.round(v)}

async function load(){
  try{
    const r=await fetch('/findings',{signal:AbortSignal.timeout(3000)});
    if(!r.ok)throw new Error(r.status);
    const d=await r.json();
    render(d);
    const b=document.getElementById('live-badge');
    b.textContent='live';b.className='live';
    document.getElementById('ts').textContent=new Date().toLocaleTimeString();
  }catch(e){
    document.getElementById('live-badge').textContent='disconnected';
    document.getElementById('live-badge').className='';
  }
}

function render(d){
  const s=d.summary;
  document.getElementById('k-total').textContent=fmt(s.total_findings);
  document.getElementById('k-total-sub').textContent=`${fmt(s.high)} high · ${fmt(s.medium)} med · ${s.low} low`;
  document.getElementById('k-day').textContent=fmtUSD(s.waste_usd_per_day);
  document.getElementById('k-day-sub').textContent='$'+s.waste_usd_per_day.toFixed(2)+'/day estimated';
  document.getElementById('k-month').textContent=fmtUSD(s.waste_usd_per_month);
  document.getElementById('k-calls').textContent=fmt(s.calls_analyzed);
  document.getElementById('k-calls-sub').textContent=fmt(s.sessions_analyzed)+' sessions';

  document.getElementById('s-high').textContent=fmt(s.high);
  document.getElementById('s-med').textContent=fmt(s.medium);
  document.getElementById('s-low').textContent=fmt(s.low);

  // Detector chart
  const dets=Object.keys(d.by_detector);
  // We don't have per-detector counts in by_detector (only waste), so derive from recent_findings
  const counts={};
  (d.recent_findings||[]).forEach(f=>counts[f.detector]=(counts[f.detector]||0)+1);
  // Use waste as proxy for bar sizing if count missing
  const vals=dets.map(k=>counts[k]||Math.ceil((d.by_detector[k].waste_per_day||0)*10));
  if(detChart){
    detChart.data.labels=dets;
    detChart.data.datasets[0].data=vals;
    detChart.update('active');
  }else{
    detChart=new Chart(document.getElementById('det-chart'),{
      type:'bar',
      data:{labels:dets,datasets:[{
        data:vals,
        backgroundColor:vals.map(v=>v>500?'#f97316cc':v>100?'#f9731680':'#f9731640'),
        borderRadius:3,borderSkipped:false
      }]},
      options:{indexAxis:'y',responsive:true,plugins:{legend:{display:false},
        tooltip:{backgroundColor:'#161616',borderColor:'#2a2a2a',borderWidth:1,
          callbacks:{label:c=>'  '+c.parsed.x+' findings'}}},
        scales:{x:{grid:{color:'#1a1a1a'},ticks:{callback:v=>v>=1000?(v/1000).toFixed(0)+'k':v}},
          y:{grid:{display:false},ticks:{font:{family:'JetBrains Mono,monospace',size:11},color:'#888'}}}}
    });
  }

  // Severity donut
  if(sevChart){
    sevChart.data.datasets[0].data=[s.high,s.medium,s.low];
    sevChart.update('active');
  }else{
    sevChart=new Chart(document.getElementById('sev-chart'),{
      type:'doughnut',
      data:{labels:['High','Medium','Low'],datasets:[{
        data:[s.high,s.medium,s.low],
        backgroundColor:['#ff444488','#f9731688','#22c55e88'],
        borderColor:['#ff4444','#f97316','#22c55e'],
        borderWidth:1.5,hoverOffset:5
      }]},
      options:{responsive:true,cutout:'68%',
        plugins:{legend:{position:'bottom',labels:{color:'#555',padding:12,usePointStyle:true,pointStyleWidth:10}},
          tooltip:{backgroundColor:'#161616',borderColor:'#2a2a2a',borderWidth:1}}}
    });
  }

  // Waste bars
  const maxW=Math.max(...Object.values(d.by_detector).map(v=>v.waste_per_day||0),0.01);
  const wHTML=Object.entries(d.by_detector)
    .sort((a,b)=>(b[1].waste_per_day||0)-(a[1].waste_per_day||0))
    .filter(([,v])=>(v.waste_per_day||0)>0)
    .map(([name,v])=>{
      const pct=((v.waste_per_day/maxW)*100).toFixed(1);
      const dim=v.waste_per_day<1;
      return `<div class="wrow">
        <div class="wrow-top">
          <span class="wrow-name">${name}</span>
          <span class="wrow-val${dim?' dim':''}">${'$'+v.waste_per_day.toFixed(2)}</span>
        </div>
        <div class="wtrack"><div class="wfill" style="width:${pct}%"></div></div>
      </div>`;
    }).join('');
  document.getElementById('waste-bars').innerHTML=wHTML||'<div style="color:var(--t3);font-size:12px;padding:8px 0">No waste data yet.</div>';

  // Recent findings stream
  const recent=(d.recent_findings||[]).slice(-20).reverse();
  document.getElementById('stream-count').textContent=recent.length;
  document.getElementById('stream').innerHTML=recent.map(f=>`
    <div class="stream-item ${f.severity}">
      <div class="stream-top">
        <span class="stream-det">${f.detector}</span>
        <span class="stream-time">${f.severity}</span>
      </div>
      <div class="stream-title">${f.title||''}</div>
      ${f.fix?`<div class="stream-fix">→ ${f.fix.slice(0,120)}${f.fix.length>120?'…':''}</div>`:''}
    </div>`).join('')||'<div style="color:var(--t3);font-size:12px;padding:8px 0">No findings yet — drop trace files into your traces/ folder.</div>';

  // Top findings table
  const rows=Object.entries(d.by_detector)
    .sort((a,b)=>(b[1].waste_per_day||0)-(a[1].waste_per_day||0))
    .slice(0,10)
    .map(([name,v],i)=>{
      const fix=FIXES[name]||{what:'—',fix:'—'};
      const w=v.waste_per_day||0;
      const wStr=w>0?`<span class="mn" style="color:${w>5?'var(--or)':'var(--t2)'}">${'$'+w.toFixed(2)}</span>`:`<span class="mn" style="color:var(--t3)">—</span>`;
      const isH=w>5;
      const sev=isH?`<div class="sev sev-h"><div class="dot"></div>High</div>`:`<div class="sev sev-m"><div class="dot"></div>Medium</div>`;
      return`<tr>
        <td><span class="chip ${w>1?'chip-or':'chip-w'}">${name}</span></td>
        <td>${sev}</td><td>${wStr}</td>
        <td style="color:var(--t3);font-size:11px;max-width:180px">${fix.what}</td>
        <td style="font-size:11px;color:var(--t3);max-width:260px;line-height:1.5">${fix.fix}</td>
      </tr>`;
    }).join('');
  document.getElementById('findings-tbody').innerHTML=rows||'<tr><td colspan="5" style="text-align:center;padding:24px;color:var(--t3)">No findings yet.</td></tr>';
}

load();
setInterval(load,15000);
</script>
</body>
</html>"""


class _Handler(BaseHTTPRequestHandler):
    store: MetricsStore
    version: str = "0.4.2"

    def do_GET(self):
        if self.path in ("/", "/dashboard"):
            html = DASHBOARD_HTML.replace("__VERSION__", self.version).encode()
            self._respond(200, "text/html; charset=utf-8", html)
        elif self.path == "/metrics":
            body = self.store.to_prometheus().encode()
            self._respond(200, "text/plain; version=0.0.4", body)
        elif self.path == "/findings":
            body = self.store.to_json().encode()
            self._respond(200, "application/json", body)
        elif self.path == "/health":
            self._respond(200, "text/plain", b"ok")
        else:
            self._respond(404, "text/plain", b"not found")

    def _respond(self, code, ctype, body):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


def _scan_all(path: Path) -> MetricsStore:
    """Scan all files under path and return a fresh MetricsStore.
    Called on startup and on every rescan — always returns a clean store
    so metrics never double-count.
    """
    from monk.parsers.otel import is_otel_format, parse_spans, spans_to_trace_calls

    fresh = MetricsStore()
    files = list(path.rglob("*.jsonl")) if path.is_dir() else [path]
    total_calls = 0
    total_findings = 0

    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
            if is_otel_format(text):
                roots = parse_spans(text)
                calls = spans_to_trace_calls(roots)
                findings = []
                for det in ALL_DETECTORS:
                    findings.extend(
                        det.run_spans(roots) if det.requires_spans else det.run(calls)
                    )
            else:
                calls = parse_traces(str(f))
                findings = []
                for det in ALL_DETECTORS:
                    if not det.requires_spans:
                        findings.extend(det.run(calls))

            sessions = len({c.session_id for c in calls})
            fresh.update(findings, calls, sessions)
            total_calls += len(calls)
            total_findings += len(findings)
        except Exception as e:
            print(f"[monk] error scanning {f.name}: {e}")

    return fresh, total_calls, total_findings


def serve(path: str, port: int = 9090, interval: int = 30) -> None:
    target = Path(path)
    store  = MetricsStore()
    _lock  = threading.Lock()

    # ── Initial scan ────────────────────────────────────────────────────
    if target.exists():
        fresh, calls, findings = _scan_all(target)
        with _lock:
            # replace store contents atomically
            store.__dict__.update(fresh.__dict__)
        print(f"[monk] initial scan: {calls:,} calls · {findings:,} findings")

    # ── Background rescan thread ────────────────────────────────────────
    def _watch():
        while True:
            time.sleep(interval)
            if not target.exists():
                continue
            try:
                fresh, calls, findings = _scan_all(target)
                with _lock:
                    store.__dict__.update(fresh.__dict__)
                ts = time.strftime("%H:%M:%S")
                print(f"[monk] {ts}  rescanned: {calls:,} calls · {findings:,} findings")
            except Exception as e:
                print(f"[monk] rescan error: {e}")

    threading.Thread(target=_watch, daemon=True).start()

    class Handler(_Handler):
        pass
    Handler.store = store

    httpd = HTTPServer(("0.0.0.0", port), Handler)
    print(f"")
    print(f"  🕵️  monk serve running")
    print(f"")
    print(f"  dashboard  ->  http://localhost:{port}/")
    print(f"  findings   ->  http://localhost:{port}/findings")
    print(f"  metrics    ->  http://localhost:{port}/metrics")
    print(f"  watching   ->  {target}  (rescan every {interval}s)")
    print(f"")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[monk] stopped.")
