The Rotation Library
====================
