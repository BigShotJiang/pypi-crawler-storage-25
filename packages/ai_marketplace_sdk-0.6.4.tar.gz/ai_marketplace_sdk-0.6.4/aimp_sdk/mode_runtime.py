"""Mode runtime orchestration for Model subclass @mode methods."""

from __future__ import annotations

import inspect
from types import GeneratorType
from types import SimpleNamespace
from typing import Any

from ._type_lineage import framework_schema_type
from .decorators import NO_DEFAULT
from .mode import ModeError
from .mode import ModeFunctionContract
from .model import Model
from .registry import normalize_registry_name
from .runtime import get_current_runtime_context


class ModeRuntime:
    """Runtime container that dispatches @mode methods on one Model subclass."""

    def __init__(self, mode_contracts: list[ModeFunctionContract]) -> None:
        if not mode_contracts:
            raise ValueError("No mode contracts.")
        entry_class = mode_contracts[0].owner_class
        for contract in mode_contracts:
            if contract.owner_class is not entry_class:
                raise ValueError(
                    "All public modes must be defined on the same Model subclass."
                )
        self.context: Any = None
        self.process_context: Any = None
        self._setup_done = False
        self._mode_by_name: dict[str, ModeFunctionContract] = {}
        self._model_instances_by_type: dict[type[Model], Model] = {}
        self._register_modes(mode_contracts)
        self._initialize_models_runtime()

    def _register_modes(self, mode_contracts: list[ModeFunctionContract]) -> None:
        for contract in mode_contracts:
            mode_name = normalize_registry_name(contract.mode_name)
            if not mode_name:
                raise ValueError("Mode names must be non-empty.")
            if mode_name in self._mode_by_name:
                raise ValueError(f"Duplicate mode name: {mode_name}")
            self._mode_by_name[mode_name] = contract

    def _initialize_models_runtime(self) -> None:
        entry_class = next(iter(self._mode_by_name.values())).owner_class
        instance = entry_class()
        instance._mode_runtime = self
        self._model_instances_by_type[entry_class] = instance

    def setup(self, ctx: Any | None = None) -> None:
        if self._setup_done:
            return
        if ctx is not None:
            self.process_context = ctx
        for model in self._model_instances_by_type.values():
            model.setup(self.process_context)
        self._setup_done = True

    def teardown(self, ctx: Any | None = None) -> None:
        process_context = ctx or self.process_context
        for model in reversed(list(self._model_instances_by_type.values())):
            model.teardown(process_context)
        self._setup_done = False

    async def dispatch(
        self,
        mode: str,
        input_data: Any,
        parameters: dict[str, Any] | None = None,
    ) -> Any:
        mode_name = normalize_registry_name(mode)
        if not mode_name:
            raise ModeError("Mode name is required.")
        contract = self._mode_by_name.get(mode_name)
        if contract is None:
            available = ", ".join(sorted(self._mode_by_name)) or "(none)"
            raise ModeError(f"Unknown mode '{mode_name}'. Available: {available}")

        runtime_context = get_current_runtime_context()
        if runtime_context is not None:
            self.context = runtime_context

        request = self._materialize_schema_payload(
            mode_name=mode_name,
            payload=input_data,
            schema=contract.inputs_schema,
            schema_cls=contract.inputs_schema_cls,
            location="input",
        )
        params = self._materialize_schema_payload(
            mode_name=mode_name,
            payload=parameters,
            schema=contract.params_schema,
            schema_cls=contract.params_schema_cls,
            location="parameter",
        )

        model_instance = self._model_instances_by_type.get(contract.owner_class)
        if model_instance is None:
            raise ModeError(
                f"Mode '{mode_name}' model '{contract.owner_class.__name__}' is not registered."
            )

        result = contract.func(model_instance, request, params)
        if inspect.isawaitable(result):
            result = await result
        if inspect.isgenerator(result) or isinstance(result, GeneratorType):
            return self._validate_streaming_output(mode_name, contract, result)
        result_payload = self._coerce_result_dict(mode_name, result)
        self._validate_mode_output(mode_name, contract, result_payload)
        return self._build_typed_output(contract, result_payload)

    async def run_tuning(
        self,
        input_data: Any,
        parameters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute the model-owned tuning runner and return a JSON payload."""
        from .tuning import TuneResult, open_tuning_session

        if parameters is None:
            parameters = {}
        if not isinstance(parameters, dict):
            raise ModeError("Tuning parameters must be a JSON object.")
        if not isinstance(input_data, dict):
            raise ModeError("Tuning input must be a JSON object.")
        if len(self._model_instances_by_type) != 1:
            raise ModeError("Tuning requires exactly one registered model.")

        model_instance = next(iter(self._model_instances_by_type.values()))
        tuning_cls = getattr(type(model_instance), "tuning", None)
        if tuning_cls is None:
            raise ModeError(
                f"Model '{type(model_instance).__name__}' does not declare tuning."
            )
        artifacts_schema = getattr(tuning_cls, "artifacts_schema", None)
        if artifacts_schema is None:
            raise ModeError(
                f"Tuning runner '{tuning_cls.__name__}' must declare artifacts_schema."
            )
        runtime_context = get_current_runtime_context()
        if runtime_context is None:
            raise ModeError("Tuning execution requires runtime context.")

        with open_tuning_session(
            input_data,
            parameters,
            process_context=self.process_context,
            runtime_context=runtime_context,
            artifacts_schema=artifacts_schema,
        ) as session:
            result = await model_instance.run_tuning(session)
        if not isinstance(result, TuneResult):
            raise ModeError("Tuning runner must return TuneResult.")
        return result.to_payload()

    def _coerce_result_dict(self, mode_name: str, result: Any) -> dict[str, Any]:
        if isinstance(result, dict):
            return result
        if isinstance(result, framework_schema_type()):
            return {
                field_name: getattr(result, field_name)
                for field_name in result.__class__._fields
                if hasattr(result, field_name)
            }
        raise ModeError(f"Mode '{mode_name}' must return a dict or Schema instance.")

    def _materialize_schema_payload(
        self,
        *,
        mode_name: str,
        payload: Any,
        schema: Any,
        schema_cls: type[Any],
        location: str,
    ) -> Any:
        if payload is None:
            payload = {}
        if not isinstance(payload, dict):
            noun = "input" if location == "input" else "parameters"
            raise ModeError(f"Mode '{mode_name}' expects {noun} to be a JSON object.")

        try:
            return schema_cls.validate(payload)
        except Exception as exc:  # noqa: BLE001
            raise ModeError(str(exc)) from exc

    def _validate_streaming_output(
        self,
        mode_name: str,
        contract: ModeFunctionContract,
        result: Any,
    ) -> Any:
        for chunk in result:
            payload = self._coerce_result_dict(mode_name, chunk)
            self._validate_mode_output(mode_name, contract, payload)
            yield self._build_typed_output(contract, payload)

    def _validate_mode_output(
        self,
        mode_name: str,
        contract: ModeFunctionContract,
        result: dict[str, Any],
    ) -> None:
        schema = contract.outputs_schema
        extras = sorted(set(result) - set(schema.fields))
        if extras:
            raise ModeError(
                f"Mode '{mode_name}' returned unknown outputs: {', '.join(extras)}."
            )
        for field_name in schema.order:
            field_decl = schema.fields[field_name]
            if field_name in result:
                continue
            required = field_decl.required
            if required is None:
                required = (
                    field_decl.default is NO_DEFAULT
                    and field_decl.default_factory is None
                )
            if required:
                raise ModeError(
                    f"Mode '{mode_name}' must return output '{field_name}'."
                )
        try:
            contract.outputs_schema_cls.validate(result)
        except Exception as exc:  # noqa: BLE001
            raise ModeError(str(exc)) from exc

    def _build_typed_output(
        self,
        contract: ModeFunctionContract,
        result: dict[str, Any],
    ) -> dict[str, dict[str, Any]]:
        typed_output: dict[str, dict[str, Any]] = {}
        for field_name in contract.outputs_schema.order:
            if field_name not in result:
                continue
            field_decl = contract.outputs_schema.fields[field_name]
            typed_output[field_name] = {
                "kind": field_decl.kind,
                "content": result[field_name],
            }
        return typed_output

    def modes_contract(self) -> dict[str, dict[str, Any]]:
        contract: dict[str, dict[str, Any]] = {}
        for mode_name, mode_contract in self._mode_by_name.items():
            entry: dict[str, Any] = {
                "label": mode_contract.metadata.label,
                "description": mode_contract.metadata.description,
                "inputs": self._schema_contract_fields(mode_contract.inputs_schema),
                "outputs": self._schema_contract_fields(mode_contract.outputs_schema),
            }
            if (
                mode_contract.params_schema is not None
                and mode_contract.params_schema.order
            ):
                entry["parameters"] = self._schema_contract_parameters(
                    mode_contract.params_schema
                )
            contract[mode_name] = entry
        return contract

    def mode_specs(self) -> dict[str, Any]:
        return {
            mode_name: SimpleNamespace(
                name=mode_name,
                inputs=mode_contract.inputs_schema,
                outputs=mode_contract.outputs_schema,
                parameters=mode_contract.params_schema,
                metadata=mode_contract.metadata,
            )
            for mode_name, mode_contract in self._mode_by_name.items()
        }

    def resources_contract(self) -> dict[str, Any]:
        from .vector_store import Vector

        collections: list[dict[str, Any]] = []
        seen_aliases: set[str] = set()
        for model_instance in self._model_instances_by_type.values():
            declared = getattr(type(model_instance), "vectors", None)
            vector_types: list[type[Any]] = []
            if declared is None:
                continue
            if isinstance(declared, (list, tuple, set)):
                vector_types.extend(
                    [item for item in declared if isinstance(item, type)]
                )
            elif isinstance(declared, type):
                for value in vars(declared).values():
                    if isinstance(value, type):
                        vector_types.append(value)
            else:
                continue

            for vector_type in vector_types:
                if not issubclass(vector_type, Vector):
                    continue
                alias = str(
                    getattr(vector_type, "_aimp_vector_alias", "") or ""
                ).strip()
                name = str(getattr(vector_type, "_aimp_vector_name", "") or "").strip()
                description = str(
                    getattr(vector_type, "_aimp_vector_description", "") or ""
                ).strip()
                dimension = getattr(vector_type, "_aimp_vector_dimension", None)
                if dimension is None:
                    dimension = getattr(vector_type, "dimension", None)
                metric = getattr(vector_type, "_aimp_vector_metric", None)
                if metric is None:
                    metric = getattr(vector_type, "metric", None)
                if not alias:
                    continue
                if dimension is None:
                    raise ModeError(
                        f"Vector '{vector_type.__name__}' must declare dimension."
                    )
                if metric is None:
                    raise ModeError(
                        f"Vector '{vector_type.__name__}' must declare metric."
                    )
                lowered = alias.lower()
                if lowered in seen_aliases:
                    continue
                seen_aliases.add(lowered)
                collections.append(
                    {
                        "alias": alias,
                        "name": name or alias,
                        "description": description or name or alias,
                        "dimension": dimension,
                        "metric": str(metric.value),
                    }
                )
        return {"vector_db": {"collections": collections} if collections else False}

    def _schema_contract_fields(self, schema: Any) -> list[dict[str, Any]]:
        fields: list[dict[str, Any]] = []
        for field_name in schema.order:
            field_decl = schema.fields[field_name]
            required = field_decl.required
            if required is None:
                required = (
                    field_decl.default is NO_DEFAULT
                    and field_decl.default_factory is None
                )
            payload: dict[str, Any] = {
                "name": field_name,
                "kind": field_decl.kind,
                "required": required,
            }
            if field_decl.description:
                payload["description"] = field_decl.description
            if field_decl.multiple:
                payload["multiple"] = True
            if field_decl.label:
                payload["label"] = field_decl.label
            if field_decl.default is not NO_DEFAULT:
                payload["default"] = field_decl.default
            fields.append(payload)
        return fields

    def _schema_contract_parameters(self, schema: Any) -> dict[str, dict[str, Any]]:
        parameters: dict[str, dict[str, Any]] = {}
        for field_name in schema.order:
            field_decl = schema.fields[field_name]
            payload: dict[str, Any] = {"kind": field_decl.kind}
            if field_decl.description:
                payload["description"] = field_decl.description
            if field_decl.default is not NO_DEFAULT:
                payload["default"] = field_decl.default
            if field_decl.label:
                payload["label"] = field_decl.label
            if field_decl.min is not None:
                payload["min"] = field_decl.min
            if field_decl.max is not None:
                payload["max"] = field_decl.max
            if field_decl.step is not None:
                payload["step"] = field_decl.step
            if field_decl.options:
                payload["options"] = [{"value": opt} for opt in field_decl.options]
            parameters[field_name] = payload
        return parameters

    def models_contract(self) -> dict[str, dict[str, Any]]:
        contract: dict[str, dict[str, Any]] = {}
        for model_cls in self._model_instances_by_type:
            actions: dict[str, dict[str, Any]] = {}
            for action_name, sig in model_cls.actions():
                params = [p.name for p in sig.parameters.values() if p.name != "self"]
                actions[action_name] = {"parameters": params}
            contract[model_cls.__name__] = {"actions": actions}
        return contract
