"""Mode metadata and contract introspection for Model subclass methods."""

from __future__ import annotations

from dataclasses import dataclass
import inspect
import sys
from typing import TYPE_CHECKING, Any, Callable, get_type_hints

from ._type_lineage import framework_schema_type
from .decorators import SchemaDecl
from .decorators import schema_decl_from_framework_schema
from .playground import validate_mode_playground
from .registry import normalize_registry_name

if TYPE_CHECKING:
    from aimp_framework.base import Schema as FrameworkSchema

    from .model import Model as SDKModel


class ModeError(Exception):
    """Raised when a mode operation cannot be completed."""


@dataclass(frozen=True)
class ModeMetadata:
    """Decorator-owned public mode metadata."""

    name: str
    label: str | None = None
    description: str | None = None
    playground: type[Any] | None = None


@dataclass(frozen=True)
class ModeFunctionContract:
    """Resolved contract extracted from one decorated async method on a Model subclass."""

    func: Callable[..., Any]
    owner_class: type[SDKModel]
    metadata: ModeMetadata
    mode_name: str
    inputs_schema_cls: type[FrameworkSchema]
    inputs_schema: SchemaDecl
    params_schema_cls: type[FrameworkSchema]
    params_schema: SchemaDecl | None
    outputs_schema_cls: type[FrameworkSchema]
    outputs_schema: SchemaDecl


def mode(
    *,
    name: str,
    label: str | None = None,
    description: str | None = None,
    playground: type[Any] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Declare one public mode on an async method of a Model subclass."""
    raw_name = str(name or "").strip()
    if not raw_name:
        raise TypeError("mode(name=...) requires a non-empty name.")
    normalized_name = normalize_registry_name(raw_name)
    if not normalized_name:
        raise TypeError(f"Invalid mode name: {name!r}.")

    normalized_label: str | None = None
    if label is not None:
        normalized_label = str(label).strip()
        if not normalized_label:
            raise TypeError("mode(label=...) must be non-empty when provided.")

    normalized_description: str | None = None
    if description is not None:
        normalized_description = str(description)

    if playground is not None and not isinstance(playground, type):
        raise TypeError("mode(playground=...) must be a class when provided.")

    metadata = ModeMetadata(
        name=normalized_name,
        label=normalized_label,
        description=normalized_description,
        playground=playground,
    )

    def _decorate(func: Callable[..., Any]) -> Callable[..., Any]:
        if not callable(func):
            raise TypeError("@mode can only decorate callables.")
        setattr(func, "__aimp_mode__", metadata)
        return func

    return _decorate


def _normalize_mode_metadata(func: Callable[..., Any]) -> ModeMetadata:
    raw_metadata = getattr(func, "__aimp_mode__", None)
    if raw_metadata is None:
        raise TypeError(
            f"Callable '{getattr(func, '__name__', '<unknown>')}' is not a @mode."
        )
    if isinstance(raw_metadata, ModeMetadata):
        return raw_metadata
    metadata = ModeMetadata(
        name=str(getattr(raw_metadata, "name", "") or "").strip(),
        label=getattr(raw_metadata, "label", None),
        description=getattr(raw_metadata, "description", None),
        playground=getattr(raw_metadata, "playground", None),
    )
    if not metadata.name:
        raise TypeError(
            f"Callable '{getattr(func, '__name__', '<unknown>')}' has invalid @mode metadata."
        )
    return metadata


def extract_mode_method_contract(
    func: Callable[..., Any],
    *,
    owner_class: type[SDKModel],
) -> ModeFunctionContract:
    """Extract and validate one @mode decorated instance method on a Model subclass."""
    metadata = _normalize_mode_metadata(func)
    if not inspect.iscoroutinefunction(func):
        raise TypeError(f"Mode '{metadata.name}' must be async.")

    signature = inspect.signature(func)
    parameters = list(signature.parameters.values())
    if len(parameters) != 3:
        raise TypeError(
            f"Mode '{metadata.name}' must declare exactly three parameters: "
            "self, inputs, and params."
        )
    self_p, inputs_p, params_p = parameters
    if self_p.name != "self":
        raise TypeError(
            f"Mode '{metadata.name}' first parameter must be named 'self', not '{self_p.name}'."
        )
    if inputs_p.name != "inputs":
        raise TypeError(
            f"Mode '{metadata.name}' second parameter must be named 'inputs', not '{inputs_p.name}'."
        )
    if params_p.name != "params":
        raise TypeError(
            f"Mode '{metadata.name}' third parameter must be named 'params', not '{params_p.name}'."
        )
    for parameter in parameters:
        if parameter.kind not in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            raise TypeError(
                f"Mode '{metadata.name}' has unsupported parameter kind for '{parameter.name}'."
            )

    owner_module = sys.modules.get(owner_class.__module__)
    globalns = dict(vars(owner_module)) if owner_module is not None else {}
    localns = dict(vars(owner_class))
    type_hints = get_type_hints(func, globalns=globalns, localns=localns)

    schema_type = framework_schema_type()

    inputs_schema_cls = type_hints.get("inputs")
    if inputs_schema_cls is None:
        raise TypeError(
            f"Mode '{metadata.name}' parameter 'inputs' must have a type annotation."
        )
    if not (
        isinstance(inputs_schema_cls, type)
        and issubclass(inputs_schema_cls, schema_type)
        and getattr(inputs_schema_cls, "__schema_role__", None) == "inputs"
    ):
        raise TypeError(
            f"Mode '{metadata.name}' parameter 'inputs' must be a Schema.Inputs subclass."
        )

    params_schema_cls = type_hints.get("params")
    if params_schema_cls is None:
        raise TypeError(
            f"Mode '{metadata.name}' parameter 'params' must have a type annotation."
        )
    if not (
        isinstance(params_schema_cls, type)
        and issubclass(params_schema_cls, schema_type)
        and getattr(params_schema_cls, "__schema_role__", None) == "params"
    ):
        raise TypeError(
            f"Mode '{metadata.name}' parameter 'params' must be a Schema.Params subclass."
        )

    return_annotation = type_hints.get("return")
    if return_annotation is None or return_annotation is inspect.Signature.empty:
        return_annotation = signature.return_annotation
    if return_annotation is inspect.Signature.empty:
        raise TypeError(
            f"Mode '{metadata.name}' must declare an Outputs schema return annotation."
        )
    if not (
        isinstance(return_annotation, type)
        and issubclass(return_annotation, schema_type)
    ):
        raise TypeError(
            f"Mode '{metadata.name}' return annotation must be a Schema subclass."
        )
    if not issubclass(return_annotation, schema_type.Outputs):
        raise TypeError(
            f"Mode '{metadata.name}' return annotation '{return_annotation.__name__}' must be a Schema.Outputs subclass."
        )

    outputs_schema = schema_decl_from_framework_schema(
        return_annotation,
        location="output",
        owner_name=f"{return_annotation.__name__}",
    )
    if outputs_schema is None or not outputs_schema.order:
        raise TypeError(
            f"Mode '{metadata.name}' outputs schema '{return_annotation.__name__}' must be non-empty."
        )

    inputs_schema = schema_decl_from_framework_schema(
        inputs_schema_cls,
        location="input",
        owner_name=f"{inputs_schema_cls.__name__}",
    )
    params_schema = schema_decl_from_framework_schema(
        params_schema_cls,
        location="parameter",
        owner_name=f"{params_schema_cls.__name__}",
    )

    if metadata.playground is not None:
        dummy_mode = type(
            f"_{func.__name__}_ModeShim",
            (),
            {
                "__name__": f"{func.__name__}",
                "inputs": inputs_schema,
                "outputs": outputs_schema,
                "params": params_schema_cls,
            },
        )
        validate_mode_playground(dummy_mode, metadata.playground)

    return ModeFunctionContract(
        func=func,
        owner_class=owner_class,
        metadata=metadata,
        mode_name=metadata.name,
        inputs_schema_cls=inputs_schema_cls,
        inputs_schema=inputs_schema,
        params_schema_cls=params_schema_cls,
        params_schema=params_schema,
        outputs_schema_cls=return_annotation,
        outputs_schema=outputs_schema,
    )
