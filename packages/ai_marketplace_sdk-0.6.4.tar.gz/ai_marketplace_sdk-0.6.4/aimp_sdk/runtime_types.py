from enum import Enum


class RuntimeType(str, Enum):
    HTTP = "http"
    LOCAL = "local"
