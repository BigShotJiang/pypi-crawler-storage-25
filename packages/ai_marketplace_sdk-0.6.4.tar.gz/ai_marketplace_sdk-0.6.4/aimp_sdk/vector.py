"""Vector client for platform-aware SDK usage."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import json
import os
import uuid
import urllib.error
import urllib.request

from .runtime import get_current_vector_context

JsonPrimitive = str | int | float | bool | None
JsonValue = JsonPrimitive | dict[str, "JsonValue"] | list["JsonValue"]
Embedding = list[float]


@dataclass(frozen=True)
class VectorSearchResult:
    """Vector search result."""

    id: str
    score: float
    payload: JsonValue | None = None


class VectorClientError(RuntimeError):
    """Raised when vector client operations fail."""


class VectorClient:
    """Platform-aware Vector client using Gateway endpoints.

    The client reads execution context from environment variables by default:
    - AIMP_GATEWAY_URL
    - AIMP_EXECUTION_TOKEN
    - AIMP_VECTOR_RESOURCES
    - AIMP_MODEL_ID
    - AIMP_VECTOR_TIMEOUT (optional, seconds)

    Resolution order for selecting a vector resource:
    1. If `resource_alias` is provided, resolve by alias
    2. If only one resource exists, use it
    3. Otherwise, raise an error
    """

    def __init__(
        self,
        *,
        gateway_url: str | None = None,
        execution_token: str | None = None,
        resource_alias: str | None = None,
        model_id: str | None = None,
        vector_resources: list[dict[str, Any]] | None = None,
        timeout_seconds: float | None = None,
    ) -> None:
        current_context = get_current_vector_context()
        self.gateway_url = (
            gateway_url
            or (current_context.gateway_url if current_context else None)
            or os.environ.get("AIMP_GATEWAY_URL")
            or ""
        ).strip()
        self.execution_token = (
            execution_token
            or (current_context.execution_token if current_context else None)
            or os.environ.get("AIMP_EXECUTION_TOKEN")
            or ""
        ).strip()
        self.model_id = (
            model_id
            or (current_context.model_id if current_context else None)
            or os.environ.get("AIMP_MODEL_ID")
            or ""
        ).strip()
        self.resource_alias = (resource_alias or "").strip()
        self.request_id = (
            current_context.request_id if current_context else None
        ) or str(uuid.uuid4())
        context_resources = (
            list(current_context.vector_resources) if current_context else None
        )
        self.vector_resources = (
            vector_resources or context_resources or self._load_vector_resources()
        )

        if timeout_seconds is None:
            context_timeout = (
                current_context.timeout_seconds if current_context else None
            )
            if context_timeout is not None:
                timeout_seconds = context_timeout
            else:
                timeout_value = os.environ.get("AIMP_VECTOR_TIMEOUT", "10").strip()
                try:
                    timeout_seconds = float(timeout_value)
                except (TypeError, ValueError):
                    timeout_seconds = 10.0
        self.timeout_seconds = timeout_seconds

        if not self.gateway_url:
            raise VectorClientError("Missing AIMP_GATEWAY_URL for VectorClient")
        if not self.execution_token:
            raise VectorClientError("Missing AIMP_EXECUTION_TOKEN for VectorClient")
        if not self.vector_resources:
            raise VectorClientError("Missing AIMP_VECTOR_RESOURCES for VectorClient")
        if not self.model_id:
            raise VectorClientError("Missing AIMP_MODEL_ID for VectorClient")

        self.gateway_url = self.gateway_url.rstrip("/")
        self.resource = self._resolve_resource()

    def _load_vector_resources(self) -> list[dict[str, Any]]:
        raw_value = os.environ.get("AIMP_VECTOR_RESOURCES", "").strip()
        if not raw_value:
            return []
        try:
            parsed = json.loads(raw_value)
        except json.JSONDecodeError as exc:
            raise VectorClientError("AIMP_VECTOR_RESOURCES must be valid JSON") from exc
        if not isinstance(parsed, list):
            raise VectorClientError("AIMP_VECTOR_RESOURCES must be a JSON array")
        resources: list[dict[str, Any]] = []
        for item in parsed:
            if not isinstance(item, dict):
                raise VectorClientError("AIMP_VECTOR_RESOURCES entries must be objects")
            alias = item.get("alias")
            if not isinstance(alias, str) or not alias:
                raise VectorClientError("AIMP_VECTOR_RESOURCES entry missing alias")
            resources.append(item)
        return resources

    def _resolve_resource(self) -> dict[str, Any]:
        if self.resource_alias:
            for item in self.vector_resources:
                if item.get("alias") == self.resource_alias:
                    return item
            available_aliases = ", ".join(
                sorted(
                    str(item.get("alias") or "").strip()
                    for item in self.vector_resources
                    if str(item.get("alias") or "").strip()
                )
            )
            raise VectorClientError(
                f"Requested VectorClient resource_alias '{self.resource_alias}' is not available. "
                f"Available: {available_aliases or '(none)'}"
            )
        if len(self.vector_resources) == 1:
            return self.vector_resources[0]
        raise VectorClientError(
            "Multiple vector resources available; set resource_alias when constructing VectorClient"
        )

    def add(
        self,
        vector: Embedding,
        *,
        id: str | None = None,
        metadata: dict[str, JsonValue] | None = None,
    ) -> str:
        """Index a vector and return its ID."""
        payload: dict[str, Any] = {
            "alias": self.resource["alias"],
            "vector": vector,
            "metadata": metadata or {},
        }
        if id:
            payload["id"] = id

        response = self._request("/v1/data/upsert", payload)
        if "id" not in response:
            raise VectorClientError("Vector index response missing id")
        return str(response["id"])

    def upsert(
        self,
        vector: Embedding,
        *,
        id: str | None = None,
        metadata: dict[str, JsonValue] | None = None,
    ) -> str:
        """Insert or update a vector and return its ID."""
        return self.add(vector, id=id, metadata=metadata)

    def search(
        self,
        vector: Embedding,
        *,
        limit: int = 10,
        score_threshold: float | None = None,
        filters: dict[str, Any] | None = None,
    ) -> list[VectorSearchResult]:
        """Search for nearest vectors."""
        payload: dict[str, Any] = {
            "alias": self.resource["alias"],
            "vector": vector,
            "limit": limit,
        }
        if score_threshold is not None:
            payload["score_threshold"] = score_threshold
        if filters is not None:
            payload["filters"] = filters

        response = self._request("/v1/data/search", payload)
        results = response.get("results", [])
        if not isinstance(results, list):
            raise VectorClientError("Vector search response missing results")
        parsed: list[VectorSearchResult] = []
        for item in results:
            if not isinstance(item, dict):
                continue
            parsed.append(
                VectorSearchResult(
                    id=str(item.get("id", "")),
                    score=float(item.get("score", 0.0)),
                    payload=item.get("payload"),
                )
            )
        return parsed

    def stats(self, *, filters: dict[str, Any] | None = None) -> dict[str, Any]:
        """Return runtime stats for the selected logical vector binding."""
        payload = {
            "alias": self.resource["alias"],
        }
        if filters is not None:
            payload["filters"] = filters
        response = self._request("/v1/data/stats", payload)
        if not isinstance(response, dict):
            raise VectorClientError("Vector stats response invalid")
        return response

    def count(self, *, filters: dict[str, Any] | None = None) -> int:
        """Return the current number of vectors in the selected binding."""
        value = self.stats(filters=filters).get("vector_count", 0)
        try:
            return int(value)
        except (TypeError, ValueError):
            raise VectorClientError(
                "Vector stats response missing valid vector_count"
            ) from None

    def delete(self, ids: list[str]) -> int:
        """Delete vectors by ID and return deleted count."""
        if not ids:
            return 0
        payload = {
            "alias": self.resource["alias"],
            "ids": ids,
        }
        response = self._request("/v1/data/delete", payload)
        deleted = response.get("deleted", 0)
        try:
            return int(deleted)
        except (TypeError, ValueError):
            raise VectorClientError("Vector delete response invalid") from None

    def _request(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.gateway_url}{path}"
        headers = {
            "Content-Type": "application/json",
            "X-Execution-Token": self.execution_token,
            "X-Model-Id": self.model_id,
            "X-Request-Id": self.request_id,
        }
        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(url, data=data, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(
                request, timeout=self.timeout_seconds
            ) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8") if exc.fp else str(exc)
            raise VectorClientError(f"Vector request failed: {detail}") from exc
        except urllib.error.URLError as exc:
            raise VectorClientError(f"Vector request failed: {exc}") from exc

        try:
            parsed = json.loads(body)
        except json.JSONDecodeError as exc:
            raise VectorClientError("Vector response was not valid JSON") from exc
        if not isinstance(parsed, dict):
            raise VectorClientError("Vector response must be a JSON object")
        return parsed
