"""Loader helpers for `@mode` methods on Model subclasses."""

from __future__ import annotations

from importlib import metadata
from types import ModuleType
from typing import Any, Callable, TypedDict

from .package_metadata import load_package_identity as load_package_manifest
from .mode_runtime import ModeRuntime
from .loader import _find_model_subclasses
from .loader import _load_user_module
from .mode import ModeFunctionContract
from .mode import extract_mode_method_contract
from .registry import normalize_registry_name
from .tuning import load_model_tuning_contract


class ModeImplementationStatus(TypedDict):
    """Verification result for one public mode."""

    implemented: bool
    reason: str | None


class VectorBindingContract(TypedDict):
    """One declared vector binding surfaced from static mode inspection."""

    owner_kind: str
    owner_name: str
    declared_alias: str
    dimension: int
    metric: str


class VectorContractPayload(TypedDict):
    """Static vector contract extracted from one module."""

    ok: bool
    framework_version: str | None
    sdk_version: str | None
    vectors: list[VectorBindingContract]
    declared_aliases: list[str]
    issues: list[str]


def _package_version(name: str) -> str | None:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def _load_module(module_path: str) -> ModuleType:
    return _load_user_module(module_path)


def _reject_top_level_mode_functions(module: ModuleType) -> None:
    for name, value in vars(module).items():
        if name.startswith("__"):
            continue
        if not callable(value):
            continue
        if getattr(value, "__aimp_mode__", None) is None:
            continue
        raise ValueError(
            "Top-level @mode functions are not supported; define public modes as "
            "@mode-decorated async methods on your Model subclass."
        )


def _iter_mode_methods(model_cls: type[Any]) -> list[tuple[str, Callable[..., Any]]]:
    found: list[tuple[str, Callable[..., Any]]] = []
    for name, attr in model_cls.__dict__.items():
        if not callable(attr):
            continue
        if getattr(attr, "__aimp_mode__", None) is None:
            continue
        found.append((name, attr))
    return found


def _load_mode_contracts_from_module(module: ModuleType) -> list[ModeFunctionContract]:
    _reject_top_level_mode_functions(module)
    subclasses = _find_model_subclasses(module)
    if not subclasses:
        raise ValueError("No Model subclass found in module")
    if len(subclasses) > 1:
        names = ", ".join(sorted(cls.__name__ for cls in subclasses))
        raise ValueError(f"Multiple Model subclasses found: {names}")

    model_cls = subclasses[0]
    mode_methods = _iter_mode_methods(model_cls)
    if not mode_methods:
        raise ValueError(
            f"No @mode-decorated methods found on Model class '{model_cls.__name__}'."
        )

    contracts: list[ModeFunctionContract] = []
    seen_names: set[str] = set()
    for _method_name, func in sorted(mode_methods, key=lambda item: item[0]):
        contract = extract_mode_method_contract(func, owner_class=model_cls)
        if contract.mode_name in seen_names:
            raise ValueError(f"Duplicate mode name: {contract.mode_name}")
        seen_names.add(contract.mode_name)
        contracts.append(contract)
    return contracts


def _load_mode_contracts(module_path: str) -> list[ModeFunctionContract]:
    module = _load_module(module_path)
    return _load_mode_contracts_from_module(module)


def _apply_module_state(runtime: ModeRuntime, module: ModuleType) -> None:
    for name, value in vars(module).items():
        if name.startswith("__"):
            continue
        if callable(value) or isinstance(value, type):
            continue
        if isinstance(value, ModuleType):
            continue
        setattr(runtime, name, value)


def load_mode_runtime(module_path: str) -> ModeRuntime:
    """Load and validate one mode runtime from a module path."""
    module = _load_module(module_path)
    runtime = ModeRuntime(_load_mode_contracts_from_module(module))
    _apply_module_state(runtime, module)
    return runtime


def load_model_entry_class(module_path: str) -> type[Any]:
    """Return a ModeRuntime factory type for the given module path."""
    module = _load_module(module_path)
    contracts = _load_mode_contracts_from_module(module)
    module_state = {
        name: value
        for name, value in vars(module).items()
        if not name.startswith("__")
        and not callable(value)
        and not isinstance(value, type)
        and not isinstance(value, ModuleType)
    }

    class _LoadedModeRuntime(ModeRuntime):
        def __init__(self) -> None:
            super().__init__(contracts)
            for key, value in module_state.items():
                setattr(self, key, value)

    _LoadedModeRuntime.__name__ = "LoadedModeRuntime"
    return _LoadedModeRuntime


def _iter_runtime_model_classes(runtime: ModeRuntime) -> tuple[type[Any], ...]:
    return tuple(runtime._model_instances_by_type.keys())


def _iter_sdk_model_vector_bindings(
    model_cls: type[Any],
) -> list[VectorBindingContract]:
    from .vector_store import Vector

    declared = getattr(model_cls, "vectors", None)
    bindings: list[VectorBindingContract] = []
    vector_types: list[type[Any]] = []
    if declared is None:
        return bindings
    if isinstance(declared, (list, tuple, set)):
        vector_types.extend([item for item in declared if isinstance(item, type)])
    elif isinstance(declared, type):
        for value in vars(declared).values():
            if isinstance(value, type):
                vector_types.append(value)
    else:
        raise TypeError(
            f"Model '{model_cls.__name__}'.vectors must be a class or list of Vector classes."
        )

    seen: set[str] = set()
    for vector_type in vector_types:
        if not issubclass(vector_type, Vector):
            continue
        declared_alias = str(
            getattr(vector_type, "_aimp_vector_alias", "") or ""
        ).strip()
        if not declared_alias:
            declared_alias = str(getattr(vector_type, "alias", "") or "").strip()
        if not declared_alias:
            raise TypeError(
                f"Vector '{vector_type.__name__}' does not expose static alias metadata."
            )
        dimension = getattr(vector_type, "_aimp_vector_dimension", None)
        if dimension is None:
            dimension = getattr(vector_type, "dimension", None)
        metric = getattr(vector_type, "_aimp_vector_metric", None)
        if metric is None:
            metric = getattr(vector_type, "metric", None)
        if dimension is None:
            raise TypeError(f"Vector '{vector_type.__name__}' must declare dimension.")
        if metric is None:
            raise TypeError(f"Vector '{vector_type.__name__}' must declare metric.")
        if declared_alias.lower() in seen:
            continue
        seen.add(declared_alias.lower())
        bindings.append(
            {
                "owner_kind": "model",
                "owner_name": model_cls.__name__,
                "declared_alias": declared_alias,
                "dimension": int(dimension),
                "metric": str(metric.value),
            }
        )
    return bindings


def load_model_vector_contract(module_path: str) -> VectorContractPayload:
    """Extract static vector declarations without runtime dispatch."""
    runtime = load_mode_runtime(module_path)
    issues: list[str] = []
    bindings: list[VectorBindingContract] = []
    try:
        for model_cls in _iter_runtime_model_classes(runtime):
            bindings.extend(_iter_sdk_model_vector_bindings(model_cls))
    except Exception as exc:  # noqa: BLE001
        issues.append(str(exc))

    declared_aliases = sorted(
        {binding["declared_alias"] for binding in bindings if binding["declared_alias"]}
    )
    return {
        "ok": not issues,
        "framework_version": _package_version("ai-marketplace-framework"),
        "sdk_version": _package_version("ai-marketplace-sdk"),
        "vectors": sorted(
            bindings,
            key=lambda item: (
                item["declared_alias"],
                item["owner_kind"],
                item["owner_name"],
            ),
        ),
        "declared_aliases": declared_aliases,
        "issues": issues,
    }


def load_model_contract(module_path: str) -> dict[str, Any]:
    """Load the canonical contract from pyproject identity plus runtime implementation."""
    runtime = load_mode_runtime(module_path)
    manifest = load_package_manifest(module_path)
    runtime_modes = runtime.modes_contract()
    runtime_models = runtime.models_contract()
    resources_contract = runtime.resources_contract()

    payload: dict[str, Any] = {
        "schema_version": manifest["schema_version"],
        "package": manifest.get("package", {}),
        "resources": resources_contract,
        "modes": runtime_modes,
        "models": runtime_models,
    }
    capabilities: dict[str, bool] = {
        "vector": bool(resources_contract.get("vector_db")),
        "tuning": False,
    }

    model_cls = next(iter(runtime._model_instances_by_type.keys()), None)
    if model_cls is not None and getattr(model_cls, "tuning", None) is not None:
        package_name = str((manifest.get("package") or {}).get("name") or "").strip()
        fallback_model_key = normalize_registry_name(model_cls.__name__)
        model_key = normalize_registry_name(package_name) or fallback_model_key
        payload["tuning"] = load_model_tuning_contract(module_path, model_key=model_key)
        capabilities["tuning"] = True

    payload["capabilities"] = capabilities
    playground = _build_playground_contract(runtime)
    if playground:
        payload["playground"] = playground
    return payload


def load_mode_implementations(module_path: str) -> dict[str, ModeImplementationStatus]:
    """Return implementation readiness for runtime-declared modes."""
    runtime = load_mode_runtime(module_path)
    runtime_modes = set(runtime.modes_contract())
    readiness: dict[str, ModeImplementationStatus] = {}
    for mode_name in sorted(runtime_modes):
        readiness[mode_name] = {
            "implemented": True,
            "reason": None,
        }
    return readiness


def _build_playground_contract(runtime: ModeRuntime) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for mode_name, contract in runtime._mode_by_name.items():
        pg_cls = contract.metadata.playground
        if pg_cls is None:
            continue
        result[mode_name] = pg_cls.to_contract()
    return result
