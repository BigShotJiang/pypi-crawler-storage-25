"""Remote worker adapters for provider-managed execution backends."""

