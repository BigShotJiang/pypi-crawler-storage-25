"""Bridge remote provider jobs to the canonical stdin/stdout model runner."""

from __future__ import annotations

import json
import os
import subprocess
import threading
import uuid
from dataclasses import dataclass
from typing import Any, TextIO

_WORKER_PROTOCOL_VERSION = 2


class RemoteWorkerAdapterError(RuntimeError):
    """Raised when a remote worker payload or runner interaction is invalid."""


@dataclass(frozen=True)
class RunnerResponse:
    """Normalized response returned by the canonical model runner."""

    success: bool
    output: Any
    error: str | None
    raw: dict[str, Any]


class RunnerBridge:
    """Own one warm ``aimp_sdk.model_runner`` subprocess per remote worker."""

    def __init__(
        self,
        *,
        module_path: str = "/app/main.py",
        runner_command: list[str] | None = None,
    ) -> None:
        normalized_module = str(module_path or "").strip() or "/app/main.py"
        self._module_path = normalized_module
        self._runner_command = runner_command or [
            "python",
            "-m",
            "aimp_sdk.model_runner",
            "--module",
            normalized_module,
        ]
        self._custom_runner_command = runner_command is not None
        self._process: subprocess.Popen[str] | None = None
        self._process_startup_key = ""
        self._lock = threading.Lock()

    def execute(self, provider_job: dict[str, Any]) -> RunnerResponse:
        """Translate and execute one provider job payload."""
        request = build_runner_request(provider_job)
        startup_env = _normalize_string_map(request.pop("startup_env", {}))
        with self._lock:
            process = self._ensure_runner(startup_env=startup_env)
            return self._send_request(process=process, request=request)

    def shutdown(self) -> None:
        """Stop the warm subprocess when the provider runtime exits."""
        process = self._process
        self._process = None
        if process is None or process.poll() is not None:
            return
        process.terminate()

    def _ensure_runner(
        self, *, startup_env: dict[str, str]
    ) -> subprocess.Popen[str]:
        command = self._runner_command_for(startup_env)
        startup_key = json.dumps(
            {"command": command, "env": startup_env},
            sort_keys=True,
            separators=(",", ":"),
        )
        process = self._process
        if (
            process is not None
            and process.poll() is None
            and self._process_startup_key == startup_key
        ):
            return process
        if process is not None and process.poll() is None:
            process.terminate()

        env = {**os.environ, **startup_env}
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )
        if process.stdin is None or process.stdout is None:
            process.kill()
            raise RemoteWorkerAdapterError("Model runner did not expose stdin/stdout")

        ready_message = _read_json_line(process.stdout)
        if ready_message.get("type") != "ready":
            process.kill()
            raise RemoteWorkerAdapterError(
                f"Model runner did not become ready: {ready_message}"
            )
        if ready_message.get("protocol_version") not in {
            None,
            _WORKER_PROTOCOL_VERSION,
        }:
            process.kill()
            raise RemoteWorkerAdapterError(
                "Model runner reported unsupported protocol version "
                f"{ready_message.get('protocol_version')!r}"
            )
        self._process = process
        self._process_startup_key = startup_key
        return process

    def _runner_command_for(self, startup_env: dict[str, str]) -> list[str]:
        if self._custom_runner_command:
            return list(self._runner_command)
        module_path = (
            str(startup_env.get("MODEL_ENTRYPOINT") or "").strip() or self._module_path
        )
        return ["python", "-m", "aimp_sdk.model_runner", "--module", module_path]

    def _send_request(
        self, *, process: subprocess.Popen[str], request: dict[str, Any]
    ) -> RunnerResponse:
        if process.stdin is None or process.stdout is None:
            raise RemoteWorkerAdapterError("Model runner stream is unavailable")

        process.stdin.write(json.dumps(request) + "\n")
        process.stdin.flush()
        request_id = str(request.get("request_id") or "").strip()
        while True:
            message = _read_json_line(process.stdout)
            message_type = str(message.get("type") or "").strip()
            if message_type == "event":
                continue
            if message_type != "response":
                raise RemoteWorkerAdapterError(
                    f"Unexpected model runner frame type {message_type!r}"
                )
            response_request_id = str(message.get("request_id") or "").strip()
            if request_id and response_request_id != request_id:
                raise RemoteWorkerAdapterError(
                    "Model runner response request_id did not match the provider job"
                )
            return RunnerResponse(
                success=bool(message.get("success", False)),
                output=message.get("output"),
                error=(
                    str(message.get("error"))
                    if message.get("error") is not None
                    else None
                ),
                raw=message,
            )


def build_runner_request(provider_job: dict[str, Any]) -> dict[str, Any]:
    """Return one canonical runner request from a remote provider job."""
    if not isinstance(provider_job, dict):
        raise RemoteWorkerAdapterError("Provider job must be a JSON object")
    payload = provider_job.get("input")
    if not isinstance(payload, dict):
        raise RemoteWorkerAdapterError("Provider job input must be a JSON object")

    mode = str(payload.get("mode") or payload.get("operation") or "").strip().lower()
    if not mode:
        raise RemoteWorkerAdapterError("Provider job input.mode is required")

    parameters = payload.get("parameters", {})
    if parameters is None:
        parameters = {}
    if not isinstance(parameters, dict):
        raise RemoteWorkerAdapterError(
            "Provider job input.parameters must be an object"
        )

    execution_context = payload.get("execution_context", {})
    if execution_context is None:
        execution_context = {}
    if not isinstance(execution_context, dict):
        raise RemoteWorkerAdapterError(
            "Provider job input.execution_context must be an object"
        )

    request_id = str(
        payload.get("request_id")
        or execution_context.get("request_id")
        or provider_job.get("id")
        or uuid.uuid4()
    ).strip()

    return {
        "request_id": request_id,
        "mode": mode,
        "input": payload.get("input", {}),
        "parameters": parameters,
        "execution_context": execution_context,
        "vector_context": payload.get("vector_context"),
        "startup_env": payload.get("startup_env", {}),
    }


def format_provider_result(response: RunnerResponse) -> dict[str, Any]:
    """Return a provider-safe response object with stable keys."""
    return {
        "success": response.success,
        "output": response.output,
        "error": response.error,
    }


def _read_json_line(stream: TextIO) -> dict[str, Any]:
    line = stream.readline()
    if not line:
        raise RemoteWorkerAdapterError("Model runner exited before sending a frame")
    try:
        payload = json.loads(line)
    except json.JSONDecodeError as exc:
        raise RemoteWorkerAdapterError(
            f"Model runner emitted invalid JSON: {line.strip()}"
        ) from exc
    if not isinstance(payload, dict):
        raise RemoteWorkerAdapterError("Model runner emitted a non-object JSON frame")
    return payload


def _normalize_string_map(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    normalized: dict[str, str] = {}
    for key, item in value.items():
        name = str(key or "").strip()
        if not name:
            continue
        if item is None:
            continue
        normalized[name] = str(item)
    return normalized
