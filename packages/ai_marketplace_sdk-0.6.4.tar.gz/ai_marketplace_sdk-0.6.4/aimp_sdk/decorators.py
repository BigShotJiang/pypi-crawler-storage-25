"""Schema declarations and field factories for the public API surface."""

from __future__ import annotations

import re
from dataclasses import MISSING, dataclass, replace
from typing import Any, Literal

from ._type_lineage import framework_base_types


class _NoDefault:
    """Sentinel class for "no default value"."""

    def __repr__(self) -> str:
        return "NO_DEFAULT"


NO_DEFAULT = _NoDefault()

INPUT_KINDS: frozenset[str] = frozenset(
    {"text", "image", "audio", "video", "file", "json", "messages"}
)
OUTPUT_KINDS: frozenset[str] = frozenset(
    {"text", "image", "audio", "video", "file", "json", "integer", "number", "boolean"}
)
PARAMETER_KINDS: frozenset[str] = frozenset(
    {"text", "number", "integer", "boolean", "select"}
)
MEDIA_PARAM_KINDS = INPUT_KINDS
CONFIG_PARAM_KINDS: frozenset[str] = frozenset(
    {"text", "number", "integer", "boolean", "select"}
)

_SPACE_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
_FIELD_NAME_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


@dataclass(frozen=True)
class ModeArgSpec:
    """Resolved schema metadata for one public mode field."""

    kind: str
    location: Literal["input", "parameter"]
    required: bool
    default: Any = NO_DEFAULT
    default_factory: Any = None
    description: str = ""
    multiple: bool = False
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: tuple[Any, ...] | None = None
    label: str | None = None


@dataclass(frozen=True)
class SchemaFieldDecl:
    """One declared field inside an input or parameter schema."""

    kind: str
    location: Literal["input", "parameter", "output"]
    description: str = ""
    label: str | None = None
    default: Any = NO_DEFAULT
    default_factory: Any = None
    required: bool | None = None
    multiple: bool = False
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: tuple[Any, ...] | None = None


@dataclass(frozen=True)
class SchemaDecl:
    """Resolved schema declaration used by a public mode."""

    location: Literal["input", "parameter", "output"]
    fields: dict[str, SchemaFieldDecl]
    order: list[str]


def schema_decl_from_framework_schema(
    schema_cls: type[Any] | None,
    *,
    location: Literal["input", "parameter", "output"],
    owner_name: str,
) -> SchemaDecl | None:
    """Convert one framework ``Schema`` subclass into an SDK ``SchemaDecl``."""
    if schema_cls is None:
        return None
    framework_types = framework_base_types()
    framework_schema_type = framework_types["Schema"]
    framework_field_type = framework_types["Field"]
    integer_field_type = framework_types["IntegerField"]
    number_field_type = framework_types["NumberField"]
    select_field_type = framework_types["SelectField"]
    if not isinstance(schema_cls, type) or not issubclass(
        schema_cls, framework_schema_type
    ):
        raise TypeError(f"{owner_name} must be a Schema subclass.")

    field_declarations: dict[str, SchemaFieldDecl] = {}
    for field_name, field in schema_cls._fields.items():
        if not isinstance(field, framework_field_type):
            raise TypeError(f"{owner_name}.{field_name} must be a Field instance.")
        default = NO_DEFAULT if not field.has_default() else field.default
        options = tuple(field.options) if isinstance(field, select_field_type) else None
        min_value = (
            field.min
            if isinstance(field, (integer_field_type, number_field_type))
            else None
        )
        max_value = (
            field.max
            if isinstance(field, (integer_field_type, number_field_type))
            else None
        )
        step_value = (
            field.step
            if isinstance(field, (integer_field_type, number_field_type))
            else None
        )
        field_declarations[field_name] = SchemaFieldDecl(
            kind=field.kind,
            location=location,
            description=field.description or "",
            label=field.label,
            default=default,
            required=field.required,
            multiple=field.multiple,
            min=min_value,
            max=max_value,
            step=step_value,
            options=options,
        )
    return _build_schema(location=location, fields=field_declarations)


def _field_decl(
    *,
    kind: str,
    location: Literal["input", "parameter"],
    description: str = "",
    label: str | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    required: bool | None = None,
    multiple: bool = False,
    min: float | None = None,
    max: float | None = None,
    step: float | None = None,
    options: list[Any] | tuple[Any, ...] | None = None,
) -> SchemaFieldDecl:
    if default is not NO_DEFAULT and default_factory is not MISSING:
        raise ValueError("default and default_factory are mutually exclusive")
    normalized_options: tuple[Any, ...] | None = None
    if options is not None:
        normalized_options = tuple(options)
        if not normalized_options:
            raise ValueError("options cannot be empty")
    stored_factory = None if default_factory is MISSING else default_factory
    return SchemaFieldDecl(
        kind=kind,
        location=location,
        description=description,
        label=label,
        default=default,
        default_factory=stored_factory,
        required=required,
        multiple=multiple,
        min=min,
        max=max,
        step=step,
        options=normalized_options,
    )


def text(
    *,
    description: str = "",
    label: str | None = None,
    required: bool | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    multiple: bool = False,
) -> SchemaFieldDecl:
    """Declare one text input field."""
    return _field_decl(
        kind="text",
        location="input",
        description=description,
        label=label,
        required=required,
        default=default,
        default_factory=default_factory,
        multiple=multiple,
    )


def image(
    *,
    description: str = "",
    label: str | None = None,
    required: bool | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    multiple: bool = False,
) -> SchemaFieldDecl:
    """Declare one image input field."""
    return _field_decl(
        kind="image",
        location="input",
        description=description,
        label=label,
        required=required,
        default=default,
        default_factory=default_factory,
        multiple=multiple,
    )


def audio(
    *,
    description: str = "",
    label: str | None = None,
    required: bool | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    multiple: bool = False,
) -> SchemaFieldDecl:
    """Declare one audio input field."""
    return _field_decl(
        kind="audio",
        location="input",
        description=description,
        label=label,
        required=required,
        default=default,
        default_factory=default_factory,
        multiple=multiple,
    )


def video(
    *,
    description: str = "",
    label: str | None = None,
    required: bool | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    multiple: bool = False,
) -> SchemaFieldDecl:
    """Declare one video input field."""
    return _field_decl(
        kind="video",
        location="input",
        description=description,
        label=label,
        required=required,
        default=default,
        default_factory=default_factory,
        multiple=multiple,
    )


def file(
    *,
    description: str = "",
    label: str | None = None,
    required: bool | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    multiple: bool = False,
) -> SchemaFieldDecl:
    """Declare one file input field."""
    return _field_decl(
        kind="file",
        location="input",
        description=description,
        label=label,
        required=required,
        default=default,
        default_factory=default_factory,
        multiple=multiple,
    )


def json(
    *,
    description: str = "",
    label: str | None = None,
    required: bool | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    multiple: bool = False,
) -> SchemaFieldDecl:
    """Declare one JSON input field."""
    return _field_decl(
        kind="json",
        location="input",
        description=description,
        label=label,
        required=required,
        default=default,
        default_factory=default_factory,
        multiple=multiple,
    )


def text_param(
    *,
    description: str = "",
    label: str | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
) -> SchemaFieldDecl:
    """Declare one text parameter field."""
    return _field_decl(
        kind="text",
        location="parameter",
        description=description,
        label=label,
        default=default,
        default_factory=default_factory,
    )


def integer(
    *,
    description: str = "",
    label: str | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    min: float | None = None,
    max: float | None = None,
    step: float | None = None,
) -> SchemaFieldDecl:
    """Declare one integer parameter field."""
    return _field_decl(
        kind="integer",
        location="parameter",
        description=description,
        label=label,
        default=default,
        default_factory=default_factory,
        min=min,
        max=max,
        step=step,
    )


def number(
    *,
    description: str = "",
    label: str | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
    min: float | None = None,
    max: float | None = None,
    step: float | None = None,
) -> SchemaFieldDecl:
    """Declare one numeric parameter field."""
    return _field_decl(
        kind="number",
        location="parameter",
        description=description,
        label=label,
        default=default,
        default_factory=default_factory,
        min=min,
        max=max,
        step=step,
    )


def boolean(
    *,
    description: str = "",
    label: str | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
) -> SchemaFieldDecl:
    """Declare one boolean parameter field."""
    return _field_decl(
        kind="boolean",
        location="parameter",
        description=description,
        label=label,
        default=default,
        default_factory=default_factory,
    )


def select(
    *,
    options: list[Any] | tuple[Any, ...],
    description: str = "",
    label: str | None = None,
    default: Any = NO_DEFAULT,
    default_factory: Any = MISSING,
) -> SchemaFieldDecl:
    """Declare one select parameter field."""
    return _field_decl(
        kind="select",
        location="parameter",
        description=description,
        label=label,
        default=default,
        default_factory=default_factory,
        options=options,
    )


def _build_schema(
    *,
    location: Literal["input", "parameter", "output"],
    fields: dict[str, SchemaFieldDecl],
) -> SchemaDecl:
    order: list[str] = []
    resolved: dict[str, SchemaFieldDecl] = {}
    for name, declaration in fields.items():
        normalized = str(name or "").strip()
        if not normalized:
            raise ValueError("Schema field names must be non-empty")
        if not _FIELD_NAME_PATTERN.fullmatch(normalized):
            raise ValueError(
                f"Schema field '{normalized}' must be a valid Python identifier"
            )
        allowed_locations = {location}
        if location == "output":
            allowed_locations = {"input", "parameter", "output"}
        if declaration.location not in allowed_locations:
            noun = (
                "inputs_schema"
                if location == "input"
                else "parameters_schema"
                if location == "parameter"
                else "outputs_schema"
            )
            raise ValueError(
                f"{noun} cannot contain a {declaration.location} field: '{normalized}'"
            )
        resolved_declaration = declaration
        if location == "output" and declaration.location != "output":
            resolved_declaration = replace(declaration, location="output")
        if resolved_declaration.multiple and location == "parameter":
            raise ValueError(f"Parameter field '{normalized}' cannot use multiple=True")
        if resolved_declaration.step is not None and resolved_declaration.kind not in {
            "number",
            "integer",
        }:
            raise ValueError(
                f"step is only valid for number/integer parameter fields, got '{normalized}'"
            )
        if resolved_declaration.options is not None:
            if resolved_declaration.kind != "select":
                raise ValueError(
                    f"options is only valid for select parameter fields, got '{normalized}'"
                )
            if (
                resolved_declaration.min is not None
                or resolved_declaration.max is not None
            ):
                raise ValueError(
                    f"min/max are not valid for select parameter fields: '{normalized}'"
                )
            if resolved_declaration.step is not None:
                raise ValueError(
                    f"step is not valid for select parameter fields: '{normalized}'"
                )
        elif (
            location == "parameter"
            and (
                resolved_declaration.min is not None
                or resolved_declaration.max is not None
            )
            and resolved_declaration.kind not in {"number", "integer"}
        ):
            raise ValueError(
                f"min/max are only valid for numeric parameter fields, got '{normalized}'"
            )
        if location == "input" and resolved_declaration.kind not in INPUT_KINDS:
            raise ValueError(
                f"inputs_schema cannot contain a {resolved_declaration.kind} field: '{normalized}'"
            )
        if location == "parameter" and resolved_declaration.kind not in PARAMETER_KINDS:
            raise ValueError(
                f"parameters_schema cannot contain a {resolved_declaration.kind} field: '{normalized}'"
            )
        if location == "output" and resolved_declaration.kind not in OUTPUT_KINDS:
            raise ValueError(
                f"outputs_schema cannot contain a {resolved_declaration.kind} field: '{normalized}'"
            )
        resolved[normalized] = resolved_declaration
        order.append(normalized)
    return SchemaDecl(location=location, fields=resolved, order=order)


def _validate_spaces(spaces: list[str] | None) -> list[str] | None:
    """Validate space names follow the allowed pattern."""
    if spaces is None:
        return None
    if not isinstance(spaces, list):
        raise ValueError("spaces must be a list")
    if not spaces:
        raise ValueError("spaces cannot be empty")
    validated: list[str] = []
    seen: set[str] = set()
    for space in spaces:
        if not isinstance(space, str):
            raise ValueError(f"space must be a string, got {type(space).__name__}")
        normalized = space.strip()
        if not normalized:
            raise ValueError("space cannot be empty")
        if not _SPACE_PATTERN.fullmatch(normalized):
            raise ValueError(
                f"space '{normalized}' must start with alphanumeric and contain "
                "only letters, numbers, underscore, and hyphen (max 64 chars)"
            )
        if normalized.lower() in seen:
            raise ValueError(f"duplicate space: {normalized}")
        seen.add(normalized.lower())
        validated.append(normalized)
    return validated
