"""SDK exceptions."""

from __future__ import annotations


class SDKError(Exception):
    """Base exception for SDK errors."""

    pass

