"""CLI helper to output model parameters contract as JSON."""

from __future__ import annotations

import argparse
import json
import sys

from .loader import load_contract


def main() -> None:
    """Load model parameters from a module and print JSON to stdout."""
    parser = argparse.ArgumentParser(description="Export model contract as JSON")
    parser.add_argument(
        "--module",
        dest="module_path",
        required=True,
        help="Path to the model module file (e.g., /workspace/main.py).",
    )
    args = parser.parse_args()

    try:
        contract = load_contract(args.module_path)
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"error": str(exc)}))
        sys.exit(1)

    print(json.dumps(contract))


if __name__ == "__main__":
    main()
