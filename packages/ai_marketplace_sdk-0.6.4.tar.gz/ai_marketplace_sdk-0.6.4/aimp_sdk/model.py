"""Internal typed capability unit with managed engine lifecycle."""

from __future__ import annotations

import asyncio
import inspect
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

from ._type_lineage import framework_schema_type
from .runtime import ProcessContext, RuntimeContext

if TYPE_CHECKING:
    from .mode_runtime import ModeRuntime


class ModelError(Exception):
    """Raised when a model operation cannot be completed."""


class Model:
    """Internal typed capability unit with managed engine lifecycle."""

    _actions: ClassVar[dict[type["Model"], dict[str, inspect.Signature]]] = {}
    engine: ClassVar[type[Any] | None] = None
    vectors: ClassVar[type[Any] | None] = None
    tuning: ClassVar[type[Any] | None] = None

    def __init__(self) -> None:
        self.context: RuntimeContext = RuntimeContext()
        self.process_context: ProcessContext = ProcessContext()
        self._setup_done = False
        self._mode_runtime: ModeRuntime | None = None
        self._engine_instance: Any | None = None
        self._engine_loaded = False
        self._applied_adapter_uris: tuple[str, ...] = ()
        self._tuning_runner: Any | None = None

    def setup(self, ctx: ProcessContext | None = None) -> None:
        if self._setup_done:
            return
        if ctx is not None:
            self.process_context = ctx
        self._ensure_engine_loaded()
        self.on_setup(self.process_context)
        self._setup_done = True

    def teardown(self, ctx: ProcessContext | None = None) -> None:
        if self._engine_instance is not None:
            teardown = getattr(self._engine_instance, "teardown", None)
            if callable(teardown):
                teardown()
        self._engine_instance = None
        self._engine_loaded = False
        self._applied_adapter_uris = ()
        self._tuning_runner = None
        self._setup_done = False

    def on_setup(self, ctx: ProcessContext) -> None:
        _ = ctx

    def engine_instance(self) -> Any:
        """Return the managed engine instance for this model."""
        self._ensure_engine_loaded()
        return self._engine_instance

    def _ensure_engine_loaded(self) -> None:
        if self._engine_loaded:
            self._apply_runtime_adapters_if_needed()
            return
        engine_type = type(self).engine
        if engine_type is None:
            raise ModelError(f"Model '{type(self).__name__}' must declare engine.")
        if self._engine_instance is None:
            self._engine_instance = engine_type()
        load = getattr(self._engine_instance, "load", None)
        if not callable(load):
            raise ModelError(
                f"Engine '{type(self._engine_instance).__name__}' must implement load()."
            )
        load()
        build = getattr(self._engine_instance, "build", None)
        if callable(build):
            build()
        self._apply_runtime_adapters_if_needed()
        self._engine_loaded = True

    def _apply_runtime_adapters_if_needed(self) -> None:
        manifest = getattr(self.context, "composition_manifest", None)
        if not isinstance(manifest, dict):
            return
        adapters = manifest.get("adapters")
        if not isinstance(adapters, list) or not adapters:
            return

        apply_adapter = getattr(self._engine_instance, "apply_adapter", None)
        if not callable(apply_adapter):
            raise ModelError(
                f"Engine '{type(self._engine_instance).__name__}' must implement apply_adapter(adapter_path, adapter_name) "
                "when composition_manifest.adapters is provided."
            )

        artifacts_dir = Path(
            getattr(self.context, "artifacts_dir", Path("/app/artifacts"))
        )
        adapter_root = artifacts_dir.parent / "adapters"
        if not adapter_root.is_absolute():
            raise ModelError("runtime adapter root path must be absolute")

        normalized_adapter_paths: list[str] = []
        for adapter in adapters:
            if not isinstance(adapter, dict):
                raise ModelError(
                    "composition_manifest.adapters entries must be objects"
                )
            adapter_slug = str(adapter.get("slug") or "").strip()
            if not adapter_slug:
                raise ModelError("composition_manifest.adapters[].slug is required")
            artifact = adapter.get("artifact")
            if not isinstance(artifact, dict):
                raise ModelError(
                    "composition_manifest.adapters[].artifact must be an object"
                )
            uri = str(artifact.get("uri") or "").strip()
            if not uri:
                raise ModelError(
                    "composition_manifest.adapters[].artifact.uri is required"
                )
            adapter_path = adapter_root / adapter_slug
            if not adapter_path.is_absolute():
                raise ModelError("resolved adapter path must be absolute")
            if not adapter_path.exists():
                raise ModelError(
                    "composition_manifest adapter not materialized at runtime path "
                    f"'{adapter_path}'"
                )
            normalized_adapter_paths.append(str(adapter_path))
        if tuple(normalized_adapter_paths) == self._applied_adapter_uris:
            return
        for index, adapter_path in enumerate(normalized_adapter_paths):
            apply_adapter(adapter_path, f"adapter_{index}")
        self._applied_adapter_uris = tuple(normalized_adapter_paths)

    def dispatch(
        self,
        action: str,
        input_data: Any,
        parameters: dict[str, Any] | None = None,
    ) -> Any:
        """Execute one model action by name with schema-aware materialization."""
        action_name = str(action or "").strip()
        if not action_name:
            raise ModelError("Model action name is required.")

        handler = getattr(self, action_name, None)
        if handler is None or not callable(handler):
            available = ", ".join(name for name, _ in type(self).actions()) or "(none)"
            raise ModelError(
                f"Unknown model action '{action_name}'. Available: {available}"
            )

        if parameters is None:
            parameters = {}
        if not isinstance(parameters, dict):
            raise ModelError("Model action parameters must be a JSON object.")

        signature = inspect.signature(handler)
        call_kwargs: dict[str, Any] = {}
        action_parameters = [
            parameter
            for parameter in signature.parameters.values()
            if parameter.name != "self"
        ]
        for parameter in action_parameters:
            if parameter.name == "input":
                raw_value = input_data
            elif parameter.name == "parameters":
                raw_value = parameters
            else:
                raise ModelError(
                    f"Action '{action_name}' parameter '{parameter.name}' must be named 'input' or 'parameters'."
                )
            call_kwargs[parameter.name] = self._materialize_action_argument(
                action_name=action_name,
                parameter=parameter,
                raw_value=raw_value,
            )

        result = handler(**call_kwargs)
        if inspect.isawaitable(result):
            result = asyncio.run(result)

        return_annotation = signature.return_annotation
        schema_type = framework_schema_type()
        if isinstance(return_annotation, type) and issubclass(
            return_annotation, schema_type
        ):
            if isinstance(result, return_annotation):
                return {
                    field_name: getattr(result, field_name)
                    for field_name in return_annotation._fields
                    if hasattr(result, field_name)
                }
            if isinstance(result, dict):
                try:
                    validated = return_annotation.validate(result)
                except Exception as exc:  # noqa: BLE001
                    raise ModelError(str(exc)) from exc
                return {
                    field_name: getattr(validated, field_name)
                    for field_name in return_annotation._fields
                    if hasattr(validated, field_name)
                }
            raise ModelError(
                f"Action '{action_name}' must return a dict or {return_annotation.__name__} instance."
            )

        return result

    def _materialize_action_argument(
        self,
        *,
        action_name: str,
        parameter: inspect.Parameter,
        raw_value: Any,
    ) -> Any:
        annotation = parameter.annotation
        if annotation is inspect.Signature.empty:
            return raw_value

        if isinstance(annotation, type) and issubclass(annotation, framework_schema_type()):
            if isinstance(raw_value, annotation):
                return raw_value
            payload = raw_value
            if payload is None:
                payload = {}
            if not isinstance(payload, dict):
                raise ModelError(
                    f"Action '{action_name}' argument '{parameter.name}' expects a JSON object."
                )
            try:
                return annotation.validate(payload)
            except Exception as exc:  # noqa: BLE001
                raise ModelError(str(exc)) from exc

        return raw_value

    def _get_tuning_runner(self) -> Any:
        if self.tuning is None:
            raise ModelError(
                f"Model '{type(self).__name__}' does not declare tuning capability."
            )
        if self._tuning_runner is None:
            self._tuning_runner = self.tuning()
        return self._tuning_runner

    async def run_tuning(self, tuning_context: Any) -> Any:
        """Execute one model-scoped tuning run."""
        runner = self._get_tuning_runner()
        run = getattr(runner, "run", None)
        if not callable(run):
            raise ModelError(
                f"Tuning runner '{type(runner).__name__}' must implement run(tuning_context)."
            )
        result = run(tuning_context)
        if inspect.isawaitable(result):
            return await result
        return result

    @classmethod
    def actions(cls) -> list[tuple[str, inspect.Signature]]:
        """Discover public async methods as actions.

        Returns:
            List of (action_name, signature) tuples for each public async method.
        """
        if cls is Model:
            return []

        if cls not in cls._actions:
            cls._actions[cls] = cls._discover_actions()

        return list(cls._actions[cls].items())

    @classmethod
    def _discover_actions(cls) -> dict[str, inspect.Signature]:
        """Inspect class for public async methods as actions."""
        actions: dict[str, inspect.Signature] = {}
        reserved = {
            "setup",
            "teardown",
            "on_setup",
            "engine_instance",
            "run_tuning",
        }
        for name, attr in cls.__dict__.items():
            if name.startswith("_"):
                continue
            if name in reserved:
                continue
            if not callable(attr):
                continue
            if getattr(attr, "__aimp_mode__", None) is not None:
                continue
            if not inspect.iscoroutinefunction(attr):
                continue
            try:
                sig = inspect.signature(attr)
            except (ValueError, TypeError):
                continue
            actions[name] = sig
        return actions

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if cls is not Model and cls.engine is None:
            raise TypeError(f"Model '{cls.__name__}' must declare engine.")
        cls._actions.pop(cls, None)
