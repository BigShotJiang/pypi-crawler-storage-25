"""Dataset serialization and upload helpers for the SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, BinaryIO
import hashlib
import io
import logging
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from tempfile import SpooledTemporaryFile

from datasets import Dataset

if TYPE_CHECKING:
    from .client import Client

logger = logging.getLogger(__name__)


@dataclass
class DatasetPayload:
    """Serialized dataset payload.

    Attributes:
        stream: Binary stream positioned at the start of the ZIP.
        size_bytes: Total size of the ZIP stream.
        sha256: SHA256 checksum of the ZIP contents.
        file_name: File name to present to upload API.
        content_type: MIME type for upload.
    """

    stream: BinaryIO
    size_bytes: int
    sha256: str
    file_name: str
    content_type: str


def _compute_stream_sha256(stream: BinaryIO) -> str:
    sha256 = hashlib.sha256()
    stream.seek(0)
    while True:
        chunk = stream.read(1024 * 1024)
        if not chunk:
            break
        sha256.update(chunk)
    stream.seek(0)
    return sha256.hexdigest()


def serialize_dataset(dataset: Dataset) -> DatasetPayload:
    """Serialize a Hugging Face dataset to zipped Parquet.

    Args:
        dataset: Hugging Face Dataset instance.

    Returns:
        DatasetPayload for upload.

    Raises:
        TypeError: If dataset is not a Hugging Face Dataset.
    """

    if not isinstance(dataset, Dataset):
        raise TypeError("Please provide a Hugging Face Dataset object.")

    parquet_buffer = SpooledTemporaryFile(max_size=50 * 1024 * 1024)
    dataset.to_parquet(parquet_buffer)
    parquet_buffer.seek(0)

    zip_stream = SpooledTemporaryFile(max_size=50 * 1024 * 1024)
    with zipfile.ZipFile(zip_stream, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        with zf.open("data.parquet", "w") as zipped_file:
            shutil.copyfileobj(parquet_buffer, zipped_file)

    zip_stream.seek(0, io.SEEK_END)
    size_bytes = zip_stream.tell()
    zip_stream.seek(0)

    sha256 = _compute_stream_sha256(zip_stream)

    return DatasetPayload(
        stream=zip_stream,
        size_bytes=size_bytes,
        sha256=sha256,
        file_name="dataset.zip",
        content_type="application/zip",
    )


def _read_exact(stream: BinaryIO, size_bytes: int) -> bytes:
    data = stream.read(size_bytes)
    if len(data) != size_bytes:
        raise ValueError("Unexpected end of dataset stream")
    return data


def _upload_with_retries(
    request: urllib.request.Request,
    *,
    timeout: float,
    request_id: str,
    max_attempts: int = 3,
    backoff_base: float = 0.5,
    backoff_max: float = 4.0,
):
    attempt = 1
    while True:
        try:
            return urllib.request.urlopen(request, timeout=timeout)
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt >= max_attempts:
                raise
            sleep_seconds = min(backoff_max, backoff_base * (2 ** (attempt - 1)))
            logger.warning(
                "Dataset upload retry",
                extra={
                    "request_id": request_id,
                    "operation": "dataset_upload_retry",
                    "model_id": None,
                    "user_id": None,
                    "execution_time": 0,
                    "attempt": attempt,
                    "sleep_seconds": sleep_seconds,
                },
            )
            time.sleep(sleep_seconds)
            attempt += 1


def upload_dataset_stream(client: Client, payload: DatasetPayload) -> str:
    """Upload dataset stream to Gateway dataset upload endpoints.

    Args:
        client: SDK client instance.
        payload: Serialized dataset payload.

    Returns:
        Dataset asset ID.
    """

    payload.stream.seek(0)
    request_id = client._new_request_id()
    start_time = time.time()

    init_payload = {
        "file_name": payload.file_name,
        "file_size_bytes": payload.size_bytes,
        "file_hash_sha256": payload.sha256,
        "content_type": payload.content_type,
    }

    init_response = client._post_json(
        "/api/datasets/upload/init", init_payload, request_id
    )

    upload_id = init_response.get("upload_id")
    parts = init_response.get("parts", [])
    if not upload_id or not isinstance(parts, list):
        raise ValueError("Dataset upload init response missing upload_id or parts")

    completed_parts = []

    for part in parts:
        part_number = part.get("part_number")
        url = part.get("url")
        size_bytes = part.get("size_bytes")
        headers = part.get("headers", {})

        if (
            not isinstance(part_number, int)
            or not isinstance(size_bytes, int)
            or not url
        ):
            raise ValueError("Invalid part data from dataset upload init")

        body = _read_exact(payload.stream, size_bytes)
        request = urllib.request.Request(url, data=body, method="PUT")
        for key, value in headers.items():
            request.add_header(key, value)

        with _upload_with_retries(
            request,
            timeout=client.timeout_seconds,
            request_id=request_id,
        ) as response:
            etag = response.headers.get("ETag") or response.headers.get("etag")

        if not etag:
            raise ValueError("Upload part missing ETag")

        completed_parts.append(
            {
                "part_number": part_number,
                "etag": etag,
                "size_bytes": size_bytes,
            }
        )

    complete_payload = {
        "upload_id": upload_id,
        "parts": completed_parts,
    }

    complete_response = client._post_json(
        "/api/datasets/upload/complete",
        complete_payload,
        request_id,
    )

    dataset_id = complete_response.get("dataset_id")
    if not dataset_id:
        raise ValueError("Dataset upload completion missing dataset_id")

    logger.info(
        "dataset_upload_completed",
        extra={
            "request_id": request_id,
            "operation": "dataset_upload",
            "model_id": None,
            "user_id": None,
            "dataset_id": dataset_id,
            "execution_time": time.time() - start_time,
        },
    )

    return str(dataset_id)
