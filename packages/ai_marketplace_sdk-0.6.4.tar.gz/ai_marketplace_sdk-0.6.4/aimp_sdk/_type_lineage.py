"""Resolve current SDK/framework base types from the active module lineage."""

from __future__ import annotations

from importlib import import_module
from typing import Any


def _resolve_module_type(module_name: str, type_name: str) -> type[Any]:
    module = import_module(module_name)
    resolved = getattr(module, type_name, None)
    if not isinstance(resolved, type):
        raise TypeError(f"{module_name}.{type_name} is not a type.")
    return resolved


def framework_base_types() -> dict[str, type[Any]]:
    """Return framework base types from the active module lineage."""
    return {
        "Field": _resolve_module_type("aimp_framework.base", "Field"),
        "IntegerField": _resolve_module_type("aimp_framework.base", "IntegerField"),
        "NumberField": _resolve_module_type("aimp_framework.base", "NumberField"),
        "Schema": _resolve_module_type("aimp_framework.base", "Schema"),
        "SelectField": _resolve_module_type("aimp_framework.base", "SelectField"),
    }


def framework_schema_type() -> type[Any]:
    """Return the active framework ``Schema`` base class."""
    return framework_base_types()["Schema"]


def sdk_model_type() -> type[Any]:
    """Return the active SDK ``Model`` base class."""
    return _resolve_module_type("aimp_sdk.model", "Model")
