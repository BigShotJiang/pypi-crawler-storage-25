"""High-level streaming helpers for progressive mode outputs."""

from __future__ import annotations

from enum import Enum
from typing import Any, NoReturn

from .mode import ModeError
from .runtime import ExecutionStreamSink
from .runtime import get_current_execution_stream


class StreamState(str, Enum):
    """Framework-owned lifecycle states for streaming status payloads."""

    QUEUED = "queued"
    CONNECTING = "connecting"
    RETRIEVING = "retrieving"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"


STREAM_STATES: frozenset[str] = frozenset(s.value for s in StreamState)

_DEFAULT_STATUS_LABELS: dict[str, str] = {
    StreamState.QUEUED.value: "Queued",
    StreamState.CONNECTING.value: "Connecting",
    StreamState.RETRIEVING.value: "Retrieving",
    StreamState.GENERATING.value: "Generating",
    StreamState.COMPLETED.value: "Completed",
    StreamState.FAILED.value: "Failed",
}


def _state_value(state: str | StreamState) -> str:
    if isinstance(state, StreamState):
        return state.value
    return str(state or "").strip()


def canonical_status_payload(
    state: str | StreamState,
    *,
    label: str | None = None,
    metadata: dict[str, Any] | None = None,
    error: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the framework-owned JSON shape for a streaming status output."""
    normalized = _state_value(state)
    if normalized not in STREAM_STATES:
        raise ModeError(
            f"Invalid stream status state {state!r}. Expected one of: "
            f"{', '.join(sorted(STREAM_STATES))}."
        )
    done = normalized in {
        StreamState.COMPLETED.value,
        StreamState.FAILED.value,
    }
    if label is not None and str(label).strip():
        resolved_label = str(label).strip()
    else:
        resolved_label = _DEFAULT_STATUS_LABELS.get(normalized, normalized.title())
    return {
        "state": normalized,
        "label": resolved_label,
        "done": done,
        "error": error,
        "metadata": dict(metadata or {}),
    }


def _validate_outputs_field_ref(field: Any, *, purpose: str) -> None:
    role = getattr(field, "schema_role", None)
    if role != "outputs":
        raise TypeError(
            f"{purpose} must reference a Schema.Outputs field (for example "
            f"ChatSchema.Outputs.answer), got Schema.{str(role or 'unknown').title()}."
        )
    name = getattr(field, "name", None)
    if not isinstance(name, str) or not name.strip():
        raise TypeError(f"{purpose} must be a named Schema.Outputs field reference.")


def _validate_text_output_field(field: Any) -> None:
    _validate_outputs_field_ref(field, purpose="Stream.text text=")
    kind = str(getattr(field, "kind", "") or "").strip()
    if kind not in {"text", "string"}:
        raise TypeError(
            f"Stream.text requires a text or string output field; field "
            f"{getattr(field, 'name', field)!r} has kind {kind!r}."
        )


def _validate_json_status_field(field: Any) -> None:
    _validate_outputs_field_ref(field, purpose="Stream.text status=")
    kind = str(getattr(field, "kind", "") or "").strip()
    if kind != "json":
        raise TypeError(
            f"Stream.text status= must be a json output field; field "
            f"{getattr(field, 'name', field)!r} has kind {kind!r}."
        )


class Stream:
    """Factory for typed progressive output streams."""

    @staticmethod
    def text(
        *,
        text: Any,
        status: Any | None = None,
    ) -> TextStream:
        """Start a text stream bound to a declared text output field."""
        _validate_text_output_field(text)
        if status is not None:
            _validate_json_status_field(status)
        return TextStream(
            text_field=text,
            status_field=status,
            sink=get_current_execution_stream(),
        )


class TextStream:
    """Progressive text chunks with optional JSON status updates."""

    def __init__(
        self,
        *,
        text_field: Any,
        status_field: Any | None,
        sink: ExecutionStreamSink | None,
    ) -> None:
        self._text_field = text_field
        self._status_field = status_field
        self._sink = sink
        self._parts: list[str] = []
        self._outputs_cls: Any = getattr(text_field, "parent_schema_cls", None)
        self._closed = False

    def write(self, text: str) -> None:
        """Append one text chunk to the declared text output."""
        if self._closed:
            raise ModeError("Stream is finalized; write() is not allowed after done() or fail().")
        if not isinstance(text, str):
            raise TypeError("Stream.write expects a string.")
        self._parts.append(text)
        if self._sink is None:
            return
        self._sink.emit(
            op="append",
            target=self._text_field,
            content=text,
            metadata={},
        )

    def status(
        self,
        state: StreamState | str,
        *,
        label: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Publish a status object to the optional JSON status output."""
        if self._closed:
            raise ModeError("Stream is finalized; status() is not allowed after done() or fail().")
        if self._status_field is None:
            raise ModeError(
                "status() requires Stream.text(..., status=YourSchema.Outputs.status)."
            )
        normalized = _state_value(state)
        if normalized not in STREAM_STATES:
            raise ModeError(
                f"Invalid stream status state {state!r}. Expected one of: "
                f"{', '.join(sorted(STREAM_STATES))}."
            )
        if normalized == StreamState.FAILED.value:
            raise ModeError(
                'Use stream.fail("message") instead of status(FAILED).'
            )
        payload = canonical_status_payload(
            normalized,
            label=label,
            metadata=metadata,
            error=None,
        )
        if self._sink is None:
            return
        self._sink.emit(
            op="replace",
            target=self._status_field,
            content=payload,
            metadata={},
        )

    def done(self, final_text: str | None = None) -> Any:
        """Finish the stream and return validated mode outputs."""
        if self._closed:
            raise ModeError("Stream is already finalized.")
        self._closed = True

        text_value = final_text if final_text is not None else "".join(self._parts)
        field_name = str(getattr(self._text_field, "name", "") or "")
        required = getattr(self._text_field, "required", True)
        if required and final_text is None and not self._parts:
            raise ModeError(
                f"Stream output {field_name!r} is required but no text was written "
                "and final_text was not provided."
            )

        result: dict[str, Any] = {field_name: text_value}
        if self._status_field is not None:
            status_name = str(getattr(self._status_field, "name", "") or "")
            completed = canonical_status_payload(
                StreamState.COMPLETED,
                label=_DEFAULT_STATUS_LABELS[StreamState.COMPLETED.value],
                metadata={},
                error=None,
            )
            if self._sink is not None:
                self._sink.emit(
                    op="replace",
                    target=self._status_field,
                    content=completed,
                    metadata={},
                )
            result[status_name] = completed

        if self._outputs_cls is not None:
            try:
                return self._outputs_cls.validate(result)
            except Exception as exc:  # noqa: BLE001
                raise ModeError(str(exc)) from exc
        return result

    def fail(self, message: str, *, code: str | None = None) -> NoReturn:
        """Emit a failed status (when configured) and abort the mode with an error."""
        if self._closed:
            raise ModeError("Stream is already finalized.")
        self._closed = True
        if self._status_field is not None and self._sink is not None:
            err = {"message": message, "code": code}
            payload = canonical_status_payload(
                StreamState.FAILED,
                label=_DEFAULT_STATUS_LABELS[StreamState.FAILED.value],
                metadata={},
                error=err,
            )
            self._sink.emit(
                op="replace",
                target=self._status_field,
                content=payload,
                metadata={},
            )
        raise ModeError(message)
