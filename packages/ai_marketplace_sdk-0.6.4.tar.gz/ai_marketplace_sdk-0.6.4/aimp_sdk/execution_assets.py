"""Canonical execution bundle layout for ``MODEL_ARTIFACTS_DIR``.

The runtime sets ``MODEL_ARTIFACTS_DIR`` to the **root of the extracted execution bundle**
(the materialized publish archive). Model weights and other runtime assets prepared under
``publish.artifact_path`` (always ``artifacts/`` in the project) appear at
``<bundle_root>/artifacts/`` inside that bundle.
"""

from __future__ import annotations

from pathlib import Path

# Must match ``publish.artifact_path`` (see ``ProjectPublishConfig.validate_artifact_path``).
EXECUTION_BUNDLE_PAYLOAD_SUBDIR = "artifacts"


class ExecutionArtifactContractError(RuntimeError):
    """Raised when the materialized bundle does not match the platform execution-asset contract."""


class ModelLoadError(RuntimeError):
    """Raised when model weights fail to load after artifact paths were resolved."""


def resolve_execution_bundle_payload_dir(
    bundle_root: str | Path,
    *,
    explicit_checkpoint_dir: str | None = None,
) -> Path:
    """Return the directory that holds runtime model assets inside an execution bundle.

    When ``explicit_checkpoint_dir`` is set (e.g. ``AIMP_CLIP_MODEL_DIR``), it must point
    directly at a checkpoint directory; no bundle resolution is applied.

    Otherwise ``bundle_root`` must be the execution bundle root (``MODEL_ARTIFACTS_DIR``),
    and this returns ``bundle_root / EXECUTION_BUNDLE_PAYLOAD_SUBDIR``.
    """
    if explicit_checkpoint_dir is not None and str(explicit_checkpoint_dir).strip():
        path = Path(explicit_checkpoint_dir).expanduser()
        try:
            resolved = path.resolve()
        except OSError as exc:
            raise ExecutionArtifactContractError(
                f"Explicit checkpoint directory is not usable: {explicit_checkpoint_dir!r} ({exc})."
            ) from exc
        if not resolved.is_dir():
            raise ExecutionArtifactContractError(
                f"Explicit checkpoint directory is missing or not a directory: {resolved!s}."
            )
        return resolved

    root = Path(bundle_root).expanduser()
    try:
        root = root.resolve()
    except OSError as exc:
        raise ExecutionArtifactContractError(
            f"MODEL_ARTIFACTS_DIR is not a usable path ({exc!s})."
        ) from exc

    if not root.is_dir():
        raise ExecutionArtifactContractError(
            f"MODEL_ARTIFACTS_DIR must be an existing directory (execution bundle root); got {root!s}."
        )

    payload = root / EXECUTION_BUNDLE_PAYLOAD_SUBDIR
    if not payload.is_dir():
        raise ExecutionArtifactContractError(
            f"Execution bundle at {root!s} is missing the required {EXECUTION_BUNDLE_PAYLOAD_SUBDIR!r} "
            "subdirectory. MODEL_ARTIFACTS_DIR must be the extracted bundle root; publish places model "
            f"files under {EXECUTION_BUNDLE_PAYLOAD_SUBDIR!r}/ relative to that root."
        )
    return payload
