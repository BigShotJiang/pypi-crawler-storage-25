"""Playground DSL — declarative view specs for the Playground UI.

Design rules
------------
- ``PlaygroundSpec`` is declared per-mode in ``playground.py``.
- Each spec is referenced from its mode via the ``playground`` kwarg on ``@mode``.
- ``PlaygroundSpec.validate_against_mode`` is called at mode-definition time,
  not at execution time.
- **Renderable outputs** — only outputs referenced by this spec's views are
  treated as UI-presented fields. Other declared outputs remain contract data
  only (API / telemetry / hidden fields).
- Top-level output field references are validated against the mode schema.
- When a JSON output uses ``JsonField(schema=...)``, item-level view bindings
  must use typed field references (``SourceCard.title``), not string keys.
- Execution responses never include playground metadata.
- The platform (frontend) controls styling; the DSL declares structure and
  semantics only — never storage backends (IndexedDB, localStorage, etc.).

Usage example (playground.py)::

    from aimp_sdk.playground import (
        Cards,
        Image,
        Markdown,
        PlaygroundComputed,
        PlaygroundSources,
        PlaygroundSpec,
        SectionRole,
        When,
        computed,
        source,
    )
    from schemas import SearchSchema

    class SearchPlayground(PlaygroundSpec):
        computed = PlaygroundComputed(
            thumb=computed.asset_ref(SearchSchema.Inputs.image),
        )
        response = Cards(
            SearchSchema.Outputs.matches,
            title=MatchCard.filename,
            image=Image.asset_ref(MatchCard.thumb_ref),
            when=When.HAS_CONTENT,
            role=SectionRole.SECONDARY,
        )
"""

from __future__ import annotations

from enum import Enum
from typing import Any, ClassVar


# ---------------------------------------------------------------------------
# Presentation-only enums (serialized into the Playground contract)
# ---------------------------------------------------------------------------


class When(str, Enum):
    """Controls when a response section is shown (presentation only)."""

    ALWAYS = "always"
    HAS_CONTENT = "has_content"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class SectionRole(str, Enum):
    """Semantic role for layout / accessibility (presentation only)."""

    PRIMARY = "primary"
    SECONDARY = "secondary"
    STATUS = "status"
    DEBUG = "debug"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_field_name(ref: Any, label: str) -> str:
    """Accept a framework Field instance or a plain string; return the field name."""
    name = getattr(ref, "name", None)
    if name is not None:
        if not isinstance(name, str) or not name.strip():
            raise ValueError(
                f"{label}: Field instance has no name set. "
                "Reference a class-level Schema field "
                "(e.g. MySchema.Outputs.results), not a Field() constructor call."
            )
        return name.strip()
    if isinstance(ref, str):
        if not ref.strip():
            raise ValueError(f"{label}: field name must be a non-empty string.")
        return ref.strip()
    raise TypeError(
        f"{label}: expected a Schema Field reference or a string field name, "
        f"got {type(ref).__name__}."
    )


def _resolve_item_field_ref(ref: Any, label: str) -> str:
    """Resolve an item-level Field reference to its wire name."""
    if isinstance(ref, str):
        return _resolve_field_name(ref, label)
    _resolve_field_name(ref, label)  # validates name
    if getattr(ref, "schema_role", None) not in {None, "inputs", "outputs", "params"}:
        raise TypeError(f"{label}: invalid field reference.")
    return str(getattr(ref, "name", "")).strip()


def _fields_dict(schema: Any) -> dict[str, Any]:
    """Return the field name → field mapping from a SDK SchemaDecl or Schema class."""
    if schema is None:
        return {}
    fields = getattr(schema, "fields", None)
    if isinstance(fields, dict):
        return fields
    framework_fields = getattr(schema, "_fields", None)
    if isinstance(framework_fields, dict):
        return framework_fields
    return {}


def _check_output_field(name: str, outputs: Any, label: str) -> None:
    fields = _fields_dict(outputs)
    if name not in fields:
        known = sorted(fields)
        raise ValueError(
            f"{label!r} references output field {name!r} which does not exist. "
            f"Known outputs: {known}"
        )


def _check_input_field(name: str, inputs: Any, label: str) -> None:
    fields = _fields_dict(inputs)
    if name not in fields:
        known = sorted(fields)
        raise ValueError(
            f"{label!r} references input field {name!r} which does not exist. "
            f"Known inputs: {known}"
        )


def _get_output_field(outputs: Any, name: str) -> Any:
    return _fields_dict(outputs).get(name)


_ASSET_INPUT_KINDS: frozenset[str] = frozenset({"image", "file", "audio", "video"})
_ALLOWED_SOURCE_IDS: frozenset[str] = frozenset({"chat_history"})


def _merge_view_contract(
    base: dict[str, Any],
    *,
    when: When,
    role: SectionRole | None,
) -> dict[str, Any]:
    out = dict(base)
    if when != When.ALWAYS:
        out["when"] = when.value
    if role is not None:
        out["role"] = role.value
    return out


def _slot_to_contract(slot: str | Any | None, *, label: str) -> str | dict[str, Any] | None:
    if slot is None:
        return None
    if isinstance(slot, str):
        if not slot.strip():
            raise ValueError(f"{label}: string slot must be non-empty.")
        return slot.strip()
    name = _resolve_item_field_ref(slot, label)
    return {"kind": "field", "name": name}


def _badges_to_contract(badges: list[str] | list[Any] | None) -> list[str | dict[str, Any]]:
    if not badges:
        return []
    out: list[str | dict[str, Any]] = []
    for i, b in enumerate(badges):
        if isinstance(b, str):
            if not b.strip():
                raise ValueError(f"badges[{i}] must be a non-empty string.")
            out.append(b.strip())
        else:
            out.append(_slot_to_contract(b, label=f"badges[{i}]") or {})
    return out


# ---------------------------------------------------------------------------
# Source / computed bindings (platform semantics, not storage details)
# ---------------------------------------------------------------------------


class SourceBinding:
    """Injected platform state (e.g. chat history). Not a mode input default."""

    def __init__(
        self,
        *,
        source: str,
        require_target_field: bool = False,
        target_kind: str | None = None,
    ) -> None:
        normalized = str(source or "").strip()
        if not normalized or normalized not in _ALLOWED_SOURCE_IDS:
            allowed = sorted(_ALLOWED_SOURCE_IDS)
            raise ValueError(f"Unknown source {source!r}. Allowed: {allowed}")
        self.source = normalized
        self.require_target_field = require_target_field
        self.target_kind = target_kind

    def to_contract(self) -> dict[str, Any]:
        return {"hidden": True, "computed": True, "source": self.source}


class ComputedBinding:
    """Deterministic derivation from another declared input."""

    def __init__(self, *, from_field: str, kind: str) -> None:
        self.from_field = str(from_field or "").strip()
        self.kind = str(kind or "").strip()
        if not self.from_field:
            raise ValueError("Computed binding requires from_field.")
        if self.kind not in {"asset_ref", "asset_refs"}:
            raise ValueError(f"Unsupported computed kind {kind!r}.")

    def to_contract(self) -> dict[str, Any]:
        return {
            "hidden": True,
            "computed": True,
            "from": self.from_field,
            "kind": self.kind,
        }


class _SourceNamespace:
    """Factories for ``PlaygroundSources`` values."""

    @staticmethod
    def chat_history() -> SourceBinding:
        """Inject structured chat history into a ``messages`` input field."""
        return SourceBinding(
            source="chat_history",
            require_target_field=True,
            target_kind="messages",
        )


class _ComputedNamespace:
    """Factories for ``PlaygroundComputed`` values."""

    @staticmethod
    def asset_ref(field: Any) -> ComputedBinding:
        """Derive a platform local asset reference from a single media input."""
        name = _resolve_field_name(field, "computed.asset_ref")
        role = getattr(field, "schema_role", None)
        if role not in {None, "inputs"}:
            raise TypeError(
                "computed.asset_ref expects a Schema.Inputs field reference."
            )
        kind = str(getattr(field, "kind", "") or "").strip()
        if kind not in _ASSET_INPUT_KINDS:
            raise TypeError(
                f"computed.asset_ref requires an image, file, audio, or video input; "
                f"field {name!r} has kind {kind!r}."
            )
        if getattr(field, "multiple", False):
            raise TypeError(
                "computed.asset_ref requires a single-value input field; "
                "use computed.asset_refs(...) for multi-value inputs."
            )
        return ComputedBinding(from_field=name, kind="asset_ref")

    @staticmethod
    def asset_refs(field: Any) -> ComputedBinding:
        """Derive platform local asset references from a multi-value media input."""
        name = _resolve_field_name(field, "computed.asset_refs")
        role = getattr(field, "schema_role", None)
        if role not in {None, "inputs"}:
            raise TypeError(
                "computed.asset_refs expects a Schema.Inputs field reference."
            )
        kind = str(getattr(field, "kind", "") or "").strip()
        if kind not in _ASSET_INPUT_KINDS:
            raise TypeError(
                f"computed.asset_refs requires an image, file, audio, or video input; "
                f"field {name!r} has kind {kind!r}."
            )
        if not getattr(field, "multiple", False):
            raise TypeError(
                "computed.asset_refs requires an input field with multiple=True."
            )
        return ComputedBinding(from_field=name, kind="asset_refs")


source = _SourceNamespace()
computed = _ComputedNamespace()


class PlaygroundSources:
    """Declare Playground-only injections from platform state (not schema defaults)."""

    def __init__(self, **field_sources: SourceBinding) -> None:
        for fname, binding in field_sources.items():
            if not isinstance(binding, SourceBinding):
                raise TypeError(
                    f"PlaygroundSources.{fname} must be a source binding "
                    f"(e.g. source.chat_history()), got {type(binding).__name__}."
                )
        self._bindings: dict[str, SourceBinding] = dict(field_sources)

    def validate_against_inputs(self, inputs: Any) -> None:
        fields = _fields_dict(inputs)
        for field_name, binding in self._bindings.items():
            if fields and binding.require_target_field and field_name not in fields:
                known = sorted(fields)
                raise ValueError(
                    f"PlaygroundSources.{field_name} must name a declared input field. "
                    f"Known inputs: {known}"
                )
            if fields and binding.target_kind is not None:
                field = fields.get(field_name)
                field_kind = getattr(field, "kind", None)
                if field_kind != binding.target_kind:
                    raise TypeError(
                        f"PlaygroundSources.{field_name} must target an input with kind "
                        f"{binding.target_kind!r}, got {field_kind!r}."
                    )

    def to_contract(self) -> dict[str, Any]:
        return {name: b.to_contract() for name, b in self._bindings.items()}


class PlaygroundComputed:
    """Declare Playground-only derivations from other inputs."""

    def __init__(self, **field_computed: ComputedBinding) -> None:
        for fname, binding in field_computed.items():
            if not isinstance(binding, ComputedBinding):
                raise TypeError(
                    f"PlaygroundComputed.{fname} must be a computed binding "
                    f"(e.g. computed.asset_ref(field)), got {type(binding).__name__}."
                )
        self._bindings: dict[str, ComputedBinding] = dict(field_computed)

    def validate_against_inputs(self, inputs: Any) -> None:
        fields = _fields_dict(inputs)
        for field_name, binding in self._bindings.items():
            if binding.from_field not in fields:
                known = sorted(fields)
                raise ValueError(
                    f"PlaygroundComputed.{field_name} derives from unknown input "
                    f"field {binding.from_field!r}. Known inputs: {known}"
                )

    def to_contract(self) -> dict[str, Any]:
        return {name: b.to_contract() for name, b in self._bindings.items()}


# ---------------------------------------------------------------------------
# Image slot — composable image element for Cards
# ---------------------------------------------------------------------------


class Image:
    """Declare an image slot inside a ``Cards`` view."""

    def __init__(self, field: str, *, badges: list[str] | None = None) -> None:
        if not isinstance(field, str) or not field.strip():
            raise ValueError("Image: field must be a non-empty string.")
        if badges is not None:
            if not isinstance(badges, list):
                raise TypeError("Image: badges must be a list of strings.")
            for i, b in enumerate(badges):
                if not isinstance(b, str) or not b.strip():
                    raise ValueError(f"Image: badges[{i}] must be a non-empty string.")
        self._mode = "legacy"
        self._legacy_field = field.strip()
        self._asset_ref: Any | None = None
        self.badges: list[str] = list(badges) if badges is not None else []

    @classmethod
    def asset_ref(
        cls,
        field: Any,
        *,
        badges: list[str] | list[Any] | None = None,
    ) -> Image:
        """Mark an item field as a platform local asset reference for preview."""
        inst = cls.__new__(cls)
        inst._mode = "asset_ref"
        inst._legacy_field = ""
        inst._asset_ref = field
        inst.badges = list(badges) if badges is not None else []
        name = _resolve_item_field_ref(field, "Image.asset_ref")
        kind = str(getattr(field, "kind", "") or "").strip()
        if not isinstance(field, str) and kind not in {"text", "string"}:
            raise TypeError(
                f"Image.asset_ref expects a text or string item field; "
                f"field {name!r} has kind {kind!r}."
            )
        return inst

    def to_contract(self) -> dict[str, Any]:
        if self._mode == "asset_ref":
            name = _resolve_item_field_ref(self._asset_ref, "Image.to_contract")
            return {
                "field": name,
                "semantic": "asset_ref",
                "badges": _badges_to_contract(self.badges),
            }
        return {"field": self._legacy_field, "badges": self.badges}


# ---------------------------------------------------------------------------
# ViewBase
# ---------------------------------------------------------------------------


class ViewBase:
    """Sealed base for all built-in Playground view presets."""

    _preset: ClassVar[str]

    def validate_against_outputs(self, outputs: Any) -> None:
        raise NotImplementedError

    def to_contract(self) -> dict[str, Any]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# View presets
# ---------------------------------------------------------------------------


class Cards(ViewBase):
    """Render a list output field as a responsive grid of content cards."""

    _preset = "cards"

    def __init__(
        self,
        field: Any,
        *,
        title: str | Any | None = None,
        subtitle: str | Any | None = None,
        body: str | Any | None = None,
        image: Image | None = None,
        badges: list[str] | list[Any] | None = None,
        metrics: list[str] | list[Any] | None = None,
        action: str | Any | None = None,
        empty: str = "empty",
        when: When = When.ALWAYS,
        role: SectionRole | None = SectionRole.SECONDARY,
    ) -> None:
        if image is not None and not isinstance(image, Image):
            raise TypeError(
                f"Cards: image must be an Image instance, got {type(image).__name__}."
            )
        self._field_ref = field
        self._title = title
        self._subtitle = subtitle
        self._body = body
        self.image = image
        self._badges = badges
        self._metrics = metrics
        self._action = action
        self.empty = empty
        self.when = when
        self.role = role

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Cards")
        _check_output_field(name, outputs, "Cards")
        out_field = _get_output_field(outputs, name)
        item_cls = getattr(out_field, "item_schema_cls", None)
        if item_cls is not None:
            for label, slot in (
                ("title", self._title),
                ("subtitle", self._subtitle),
                ("body", self._body),
                ("action", self._action),
            ):
                if slot is None:
                    continue
                if isinstance(slot, str):
                    raise TypeError(
                        f"Cards: when output {name!r} uses JsonField(schema=...), "
                        f"{label} must be a typed field reference (e.g. ItemSchema.title), "
                        "not a string key."
                    )
                self._check_item_field(slot, item_cls, f"Cards.{label}")
            if self._badges is not None:
                for i, b in enumerate(self._badges):
                    if isinstance(b, str):
                        raise TypeError(
                            "Cards: badges must use typed field references when "
                            "JsonField(schema=...) is set."
                        )
                    self._check_item_field(b, item_cls, f"Cards.badges[{i}]")
            if self._metrics is not None:
                for i, m in enumerate(self._metrics):
                    if isinstance(m, str):
                        raise TypeError(
                            "Cards: metrics must use typed field references when "
                            "JsonField(schema=...) is set."
                        )
                    self._check_item_field(m, item_cls, f"Cards.metrics[{i}]")
            if self.image is not None:
                if self.image._mode == "legacy":
                    raise TypeError(
                        "Cards: when output uses JsonField(schema=...), "
                        "use Image.asset_ref(ItemSchema.field) instead of Image(\"key\")."
                    )
                self._check_item_field(self.image._asset_ref, item_cls, "Cards.image")
                for i, b in enumerate(self.image.badges):
                    if isinstance(b, str):
                        raise TypeError(
                            "Cards: image badges must use typed field references when "
                            "JsonField(schema=...) is set."
                        )
                    self._check_item_field(b, item_cls, f"Cards.image.badges[{i}]")
        else:
            if self._badges is not None:
                for i, b in enumerate(self._badges):
                    if not isinstance(b, str) or not str(b).strip():
                        raise ValueError(f"Cards: badges[{i}] must be a non-empty string.")
            if self._metrics is not None:
                for i, m in enumerate(self._metrics):
                    if not isinstance(m, str) or not str(m).strip():
                        raise ValueError(f"Cards: metrics[{i}] must be a non-empty string.")

    @staticmethod
    def _check_item_field(ref: Any, item_cls: Any, label: str) -> None:
        parent = getattr(ref, "parent_schema_cls", None)
        if parent is not item_cls:
            raise TypeError(
                f"{label} must reference a field declared on the JsonField schema "
                f"{getattr(item_cls, '__name__', item_cls)!r}."
            )

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Cards.to_contract")
        contract: dict[str, Any] = {
            "preset": self._preset,
            "field": name,
            "empty": self.empty,
        }
        if self.image is not None:
            contract["image"] = self.image.to_contract()
        for key, slot in (("title", self._title), ("subtitle", self._subtitle), ("body", self._body), ("action", self._action)):
            ser = _slot_to_contract(slot, label=f"Cards.{key}")
            if ser is not None:
                contract[key] = ser
        if self._badges:
            contract["badges"] = _badges_to_contract(self._badges)
        if self._metrics:
            contract["metrics"] = _badges_to_contract(self._metrics)
        return _merge_view_contract(contract, when=self.when, role=self.role)


class Markdown(ViewBase):
    """Render a text output field as formatted Markdown."""

    _preset = "markdown"

    def __init__(
        self,
        field: Any,
        *,
        when: When = When.ALWAYS,
        role: SectionRole | None = SectionRole.PRIMARY,
        stream: bool = False,
    ) -> None:
        self._field_ref = field
        self.when = when
        self.role = role
        self.stream = stream

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Markdown")
        _check_output_field(name, outputs, "Markdown")
        if self.stream:
            out = _get_output_field(outputs, name)
            kind = str(getattr(out, "kind", "") or "").strip()
            if kind not in {"text", "string"}:
                raise TypeError(
                    f"Markdown(..., stream=True) requires a text or string output field; "
                    f"field {name!r} has kind {kind!r}."
                )

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Markdown.to_contract")
        base: dict[str, Any] = {"preset": self._preset, "field": name}
        if self.stream:
            base["stream"] = True
        return _merge_view_contract(base, when=self.when, role=self.role)


class Text(ViewBase):
    """Render a text output field as plain unformatted text."""

    _preset = "text"

    def __init__(
        self,
        field: Any,
        *,
        when: When = When.ALWAYS,
        role: SectionRole | None = SectionRole.PRIMARY,
    ) -> None:
        self._field_ref = field
        self.when = when
        self.role = role

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Text")
        _check_output_field(name, outputs, "Text")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Text.to_contract")
        return _merge_view_contract(
            {"preset": self._preset, "field": name},
            when=self.when,
            role=self.role,
        )


class ImageOutput(ViewBase):
    """Render an output field containing one or more image URLs."""

    _preset = "image"

    def __init__(
        self,
        field: Any,
        *,
        when: When = When.ALWAYS,
        role: SectionRole | None = SectionRole.PRIMARY,
    ) -> None:
        self._field_ref = field
        self.when = when
        self.role = role

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "ImageOutput")
        _check_output_field(name, outputs, "ImageOutput")
        out = _get_output_field(outputs, name)
        kind = str(getattr(out, "kind", "") or "").strip()
        if kind not in {"image", "text", "string"}:
            raise TypeError(
                f"ImageOutput requires an image, text, or string output field; "
                f"field {name!r} has kind {kind!r}."
            )

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "ImageOutput.to_contract")
        return _merge_view_contract(
            {"preset": self._preset, "field": name},
            when=self.when,
            role=self.role,
        )


class Table(ViewBase):
    """Render a list output field as a data table."""

    _preset = "table"

    def __init__(
        self,
        field: Any,
        *,
        columns: list[str] | None = None,
        when: When = When.ALWAYS,
        role: SectionRole | None = SectionRole.SECONDARY,
    ) -> None:
        self._field_ref = field
        self.columns = list(columns) if columns is not None else None
        self.when = when
        self.role = role

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Table")
        _check_output_field(name, outputs, "Table")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Table.to_contract")
        contract: dict[str, Any] = {"preset": self._preset, "field": name}
        if self.columns:
            contract["columns"] = self.columns
        return _merge_view_contract(contract, when=self.when, role=self.role)


# ---------------------------------------------------------------------------
# Playground wiring
# ---------------------------------------------------------------------------


class _OrderedFieldSurface:
    """Base class for ordered Playground field whitelists."""

    _surface_label: ClassVar[str]

    def __init__(self, *fields: Any) -> None:
        if not fields:
            raise TypeError(f"{self._surface_label} requires at least one field reference.")
        self._field_refs = tuple(fields)
        resolved_names: list[str] = []
        for index, field in enumerate(fields):
            name = _resolve_field_name(field, f"{self._surface_label}[{index}]")
            if name in resolved_names:
                raise ValueError(
                    f"{self._surface_label} cannot declare duplicate field {name!r}."
                )
            resolved_names.append(name)
        self._field_names = tuple(resolved_names)

    def to_contract(self) -> list[str]:
        return list(self._field_names)


class PlaygroundChat(_OrderedFieldSurface):
    """Declare the visible chat inputs for a mode, in UI order."""

    _surface_label = "PlaygroundChat"

    def validate_against_inputs(self, inputs: Any) -> None:
        fields = _fields_dict(inputs)
        for index, (field_ref, field_name) in enumerate(zip(self._field_refs, self._field_names)):
            schema_role = getattr(field_ref, "schema_role", None)
            if schema_role not in {None, "inputs"}:
                raise TypeError(
                    f"PlaygroundChat field {field_name!r} must reference Schema.Inputs, "
                    f"got Schema.{schema_role.title()}."
                )
            _check_input_field(field_name, inputs, self._surface_label)
            field = fields.get(field_name)
            field_kind = getattr(field, "kind", None)
            if index == 0 and field_kind != "text":
                raise TypeError(
                    "PlaygroundChat first field must target an input with kind "
                    "'text'."
                )
            if field_kind == "messages":
                raise TypeError(
                    f"PlaygroundChat cannot expose messages input field {field_name!r}."
                )


class PlaygroundParams(_OrderedFieldSurface):
    """Declare the visible parameter controls for a mode, in UI order."""

    _surface_label = "PlaygroundParams"

    def validate_against_params(self, params: Any) -> None:
        fields = _fields_dict(params)
        for field_ref, field_name in zip(self._field_refs, self._field_names):
            schema_role = getattr(field_ref, "schema_role", None)
            if schema_role not in {None, "params"}:
                raise TypeError(
                    f"PlaygroundParams field {field_name!r} must reference Schema.Params, "
                    f"got Schema.{schema_role.title()}."
                )
            if field_name not in fields:
                known = sorted(fields)
                raise ValueError(
                    f"{self._surface_label} field {field_name!r} does not exist. "
                    f"Known params: {known}"
                )


class PlaygroundSpec:
    """Base class for per-mode playground view specifications.

    Subclass rules
    --------------
    - ``response`` (required): a single ``ViewBase`` instance **or** an ordered list
      of ``ViewBase`` instances.
    - ``chat`` (optional): visible chat composer inputs, in UI order.
    - ``params`` (optional): visible parameter controls, in UI order.
    - ``sources`` (optional): platform-injected inputs (e.g. chat history).
    - ``computed`` (optional): derived hidden inputs (e.g. local asset refs).

    Only outputs referenced by ``response`` views are UI-rendered; other outputs
    remain contract-only data.
    """

    response: ClassVar[ViewBase | list[ViewBase]]
    chat: ClassVar[PlaygroundChat | None] = None
    params: ClassVar[PlaygroundParams | None] = None
    sources: ClassVar[PlaygroundSources | None] = None
    computed: ClassVar[PlaygroundComputed | None] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        _validate_playground_spec_structure(cls)

    @classmethod
    def validate_against_mode(
        cls,
        inputs_schema: Any,
        outputs_schema: Any,
        params_schema: Any,
    ) -> None:
        """Cross-validate all field references against the mode's schema."""
        if cls.chat is not None:
            cls.chat.validate_against_inputs(inputs_schema)
        if cls.params is not None:
            cls.params.validate_against_params(params_schema)
        if cls.sources is not None:
            cls.sources.validate_against_inputs(inputs_schema)
        if cls.computed is not None:
            cls.computed.validate_against_inputs(inputs_schema)
        response = cls.response if isinstance(cls.response, list) else [cls.response]
        for view in response:
            view.validate_against_outputs(outputs_schema)

    @classmethod
    def to_contract(cls) -> dict[str, Any]:
        """Return the JSON-serialisable contract section for this spec."""
        response = cls.response if isinstance(cls.response, list) else [cls.response]
        contract: dict[str, Any] = {
            "response": [v.to_contract() for v in response],
        }
        if cls.chat is not None:
            contract["chat"] = cls.chat.to_contract()
        if cls.params is not None:
            contract["params"] = cls.params.to_contract()
        if cls.sources is not None:
            contract["sources"] = cls.sources.to_contract()
        if cls.computed is not None:
            contract["computed"] = cls.computed.to_contract()
        return contract


def _validate_playground_spec_structure(cls: type) -> None:
    """Check that a PlaygroundSpec subclass has a valid ``response`` declaration."""
    response = cls.__dict__.get("response")
    if response is None:
        raise TypeError(
            f"{cls.__name__} must declare "
            "`response = <ViewBase instance or list[ViewBase]>`"
        )
    if not isinstance(response, ViewBase):
        if isinstance(response, list):
            if not response:
                raise TypeError(f"{cls.__name__}.response list must not be empty.")
            for i, item in enumerate(response):
                if not isinstance(item, ViewBase):
                    raise TypeError(
                        f"{cls.__name__}.response[{i}] must be a ViewBase instance, "
                        f"got {type(item).__name__}."
                    )
        else:
            raise TypeError(
                f"{cls.__name__}.response must be a ViewBase instance or a list of "
                f"ViewBase instances, got {type(response).__name__}."
            )

    chat = cls.__dict__.get("chat")
    if chat is not None and not isinstance(chat, PlaygroundChat):
        raise TypeError(
            f"{cls.__name__}.chat must be a PlaygroundChat instance, "
            f"got {type(chat).__name__}."
        )

    params = cls.__dict__.get("params")
    if params is not None and not isinstance(params, PlaygroundParams):
        raise TypeError(
            f"{cls.__name__}.params must be a PlaygroundParams instance, "
            f"got {type(params).__name__}."
        )

    sources = cls.__dict__.get("sources")
    if sources is not None and not isinstance(sources, PlaygroundSources):
        raise TypeError(
            f"{cls.__name__}.sources must be a PlaygroundSources instance, "
            f"got {type(sources).__name__}."
        )

    computed = cls.__dict__.get("computed")
    if computed is not None and not isinstance(computed, PlaygroundComputed):
        raise TypeError(
            f"{cls.__name__}.computed must be a PlaygroundComputed instance, "
            f"got {type(computed).__name__}."
        )


def validate_mode_playground(mode_cls: type, pg_cls: Any) -> None:
    """Validate *pg_cls* against the mode's schema (definition time)."""
    if not (isinstance(pg_cls, type) and issubclass(pg_cls, PlaygroundSpec)):
        raise TypeError(
            f"Mode '{mode_cls.__name__}.playground' must be a PlaygroundSpec "
            f"subclass, got {type(pg_cls).__name__}."
        )
    outputs_schema = _resolve_mode_outputs(mode_cls)
    if outputs_schema is None:
        raise TypeError(
            f"Cannot validate '{mode_cls.__name__}.playground': "
            "the mode has no accessible Outputs schema."
        )
    inputs_schema = _resolve_mode_inputs(mode_cls)
    params_schema = _resolve_mode_params(mode_cls)
    try:
        pg_cls.validate_against_mode(inputs_schema, outputs_schema, params_schema)
    except (ValueError, TypeError) as exc:
        raise TypeError(
            f"Mode '{mode_cls.__name__}.playground' failed schema validation: {exc}"
        ) from exc


def _resolve_mode_outputs(mode_cls: type) -> Any:
    outputs = getattr(mode_cls, "outputs", None)
    if outputs is not None:
        return outputs
    schema_container = getattr(mode_cls, "schema", None)
    if schema_container is not None:
        return getattr(schema_container, "Outputs", None)
    return None


def _resolve_mode_inputs(mode_cls: type) -> Any:
    inputs = getattr(mode_cls, "inputs", None)
    if inputs is not None:
        return inputs
    schema_container = getattr(mode_cls, "schema", None)
    if schema_container is not None:
        return getattr(schema_container, "Inputs", None)
    return None


def _resolve_mode_params(mode_cls: type) -> Any:
    params = getattr(mode_cls, "params", None)
    if params is not None:
        return params
    schema_container = getattr(mode_cls, "schema", None)
    if schema_container is not None:
        return getattr(schema_container, "Params", None)
    return None
