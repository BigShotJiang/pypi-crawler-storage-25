"""Declarative project settings and legacy typed vector handles."""

from __future__ import annotations

import re
from typing import Any, ClassVar

from .vector import JsonValue, VectorClient, VectorSearchResult

_ALIAS_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")


def _normalize_alias(alias: str) -> str:
    normalized = str(alias or "").strip()
    if not normalized:
        raise ValueError("VectorRef alias must be non-empty")
    if not _ALIAS_PATTERN.fullmatch(normalized):
        raise ValueError(
            f"VectorRef alias '{normalized}' must start with a letter and contain only "
            "letters, numbers, underscore, and hyphen (max 64 chars)"
        )
    return normalized


class VectorRef:
    """Typed execution-scoped vector handle resolved by the platform."""

    def __init__(self, alias: str) -> None:
        self.alias = _normalize_alias(alias)

    def __repr__(self) -> str:
        return f"VectorRef(alias={self.alias!r})"

    def _client(self) -> VectorClient:
        return VectorClient(resource_alias=self.alias)

    def search(
        self,
        vector: list[float],
        *,
        limit: int = 10,
        score_threshold: float | None = None,
        filters: dict[str, Any] | None = None,
    ) -> list[VectorSearchResult]:
        """Search this vector binding."""
        return self._client().search(
            vector,
            limit=limit,
            score_threshold=score_threshold,
            filters=filters,
        )

    def upsert(
        self,
        vector: list[float],
        *,
        id: str | None = None,
        metadata: dict[str, JsonValue] | None = None,
    ) -> str:
        """Insert or update one vector in this binding."""
        return self._client().upsert(vector, id=id, metadata=metadata)

    def delete(self, ids: list[str]) -> int:
        """Delete vectors from this binding."""
        return self._client().delete(ids)


class Settings:
    """Declarative project settings consumed by the SDK contract."""

    timeout: ClassVar[str | None] = None

    def __init_subclass__(cls) -> None:
        super().__init_subclass__()

        timeout = getattr(cls, "timeout", None)
        if timeout is not None and not isinstance(timeout, str):
            raise TypeError("Settings.timeout must be a string like '30s' or None")

    @classmethod
    def vector_aliases(cls) -> list[str]:
        """Return declared vector aliases for this project.

        Public authoring no longer declares vectors in ``settings.py``.
        This stays as a compatibility hook for older internal call sites.
        """
        return []


def serialize_settings_decl(settings_cls: type[Settings]) -> dict[str, object]:
    """Convert a Settings subclass into the contract resources block."""
    payload: dict[str, object] = {}
    timeout = getattr(settings_cls, "timeout", None)
    if isinstance(timeout, str) and timeout.strip():
        payload["timeout"] = timeout.strip()

    payload["vector_db"] = False
    return payload
