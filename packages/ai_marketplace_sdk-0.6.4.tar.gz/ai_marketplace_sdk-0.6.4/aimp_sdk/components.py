"""Project-local runtime components with lazy cached loading."""

from __future__ import annotations

from typing import Any, ClassVar

from .runtime import ProcessContext


class Component:
    """Base class for one project-local runtime component.

    Components are long-lived project objects that own business behavior such as
    ``generate(...)`` or ``search(...)``. For advanced cases they can also lazily
    build and cache a process-local runtime object via ``build(...)`` + ``load(...)``.

    Any ``Vector`` subclass declared as a class attribute is automatically discovered
    and bound to the component instance. This enforces encapsulation — a vector store
    belongs to its engine and is never wired externally.

    Example::

        class TextEngine(Component):
            memory = UserMemory()   # owned here, invisible outside

            def recall(self, query, user_id):
                return self.memory.objects.filter(user_id=user_id).search(query)
    """

    name: ClassVar[str] = ""

    def __init__(self) -> None:
        self._loaded_runtime: Any | None = None
        self._is_loaded = False
        # Discover Vector instances declared on the class and bind them to this instance.
        # Import here to avoid a circular import at module load time.
        from .vector_store import Vector

        self._owned_vectors: dict[str, Any] = {}
        for attr_name in dir(type(self)):
            if attr_name.startswith("_"):
                continue
            value = getattr(type(self), attr_name, None)
            if isinstance(value, Vector):
                self._owned_vectors[attr_name] = value
                # Bind the class-level Vector to this instance so self.<name> works.
                object.__setattr__(self, attr_name, value)

    def build(self, ctx: ProcessContext) -> Any:
        """Build and return the process-local runtime object."""
        raise NotImplementedError("Component classes must implement build(ctx)")

    def teardown(self, runtime: Any, ctx: ProcessContext) -> None:
        """Release the runtime object before worker shutdown."""
        _ = runtime, ctx

    def load(self, model: Any) -> Any:
        """Return the cached runtime object for this component."""
        if not self._is_loaded:
            self._loaded_runtime = self.build(model.process_context)
            self._is_loaded = True
        return self._loaded_runtime

    def tune(self, tuning: Any) -> Any:
        """Run one fine-tune trial for this component."""
        _ = tuning
        raise NotImplementedError(
            "Component classes must implement tune(self, tuning) for fine-tune support"
        )

    def shutdown(self, ctx: ProcessContext) -> None:
        """Release any cached runtime object owned by this component."""
        if not self._is_loaded:
            return
        runtime = self._loaded_runtime
        try:
            self.teardown(runtime, ctx)
        finally:
            self._loaded_runtime = None
            self._is_loaded = False
