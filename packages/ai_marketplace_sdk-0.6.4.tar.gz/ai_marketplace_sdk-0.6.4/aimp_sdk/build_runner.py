"""Build-time runner for framework-driven model projects."""

from __future__ import annotations

import argparse
import os
import sys
from typing import Any

from .model_runtime_loader import load_model_entry_class


def _module_path_from_env() -> str:
    return os.environ.get("MODEL_ENTRYPOINT", "").strip()


def run_build(module_path: str) -> None:
    """Load the model runtime and invoke its engine build hook."""
    model_cls = load_model_entry_class(module_path)
    model = model_cls()

    engine = getattr(model, "engine", None)
    if engine is not None:
        build = getattr(engine, "build", None)
        if build is not None:
            build()


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Marketplace build runner")
    parser.add_argument(
        "--module",
        dest="module_path",
        default=None,
        help="Path to the model module (defaults to MODEL_ENTRYPOINT env var).",
    )
    args = parser.parse_args()
    module_path = args.module_path or _module_path_from_env()
    if not module_path:
        print(
            "Missing model module path. Set MODEL_ENTRYPOINT or pass --module.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    try:
        run_build(module_path)
    except Exception as exc:  # noqa: BLE001
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
