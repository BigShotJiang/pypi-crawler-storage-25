"""Fine-tune schema descriptors and author-facing tuning runtime types."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import base64
from importlib import util
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Generic, Iterator, Literal, TypeVar
import os
import sys

from aimp_framework.base import Field as SchemaField

if TYPE_CHECKING:
    from .tuning_data import LoadedTuningBundle

FieldValidator = Callable[[Any], None]
FieldPreprocessor = Callable[[Any], Any]
TuningFieldType = Literal["image", "audio", "video", "text", "file", "json"]
ArtifactKind = Literal["json", "file"]
MetricGoal = Literal["maximize", "minimize"]
MaterializationStrategy = Literal["append_adapter", "replace_root"]
MaterializationResultKind = Literal["adapter_bundle", "root_bundle"]
MaterializationChaining = Literal["flatten", "replace"]

DatasetT = TypeVar("DatasetT", bound="FineTuneSchema")
ArtifactsT = TypeVar("ArtifactsT", bound="TuneArtifacts")
MetricsT = TypeVar("MetricsT", bound="TuneMetrics")


@dataclass(slots=True)
class TuningField:
    """Descriptor for one fine-tune input field."""

    field_type: TuningFieldType
    required: bool = True
    description: str | None = None
    multiple: bool = False
    validators: tuple[FieldValidator, ...] = ()
    preprocessors: tuple[FieldPreprocessor, ...] = ()

    def to_contract(self, key: str) -> dict[str, Any]:
        """Serialize the field definition into a public contract shape."""
        return {
            "key": key,
            "type": self.field_type,
            "required": self.required,
            "description": self.description,
            "multiple": self.multiple,
        }

    def preprocess_value(self, value: Any) -> Any:
        """Run field preprocessors in declaration order."""
        processed = value
        for preprocessor in self.preprocessors:
            processed = preprocessor(processed)
        return processed

    def validate_value(self, value: Any) -> None:
        """Run field validators in declaration order."""
        for validator in self.validators:
            validator(value)


class ImageField(TuningField):
    """Image fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="image",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class AudioField(TuningField):
    """Audio fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="audio",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class VideoField(TuningField):
    """Video fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="video",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class TextField(TuningField):
    """Text fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="text",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class FileField(TuningField):
    """Generic file fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="file",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class JsonField(TuningField):
    """JSON fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="json",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class FineTuneSchema:
    """Base class for tuning schema definitions."""

    @classmethod
    def fields_contract(cls) -> list[dict[str, Any]]:
        """Return serialized field definitions in source order."""
        fields: list[dict[str, Any]] = []
        for key, value in cls.__dict__.items():
            if isinstance(value, TuningField):
                fields.append(value.to_contract(key))
            elif isinstance(value, SchemaField):
                field_kind = str(value.kind or "").strip()
                if field_kind not in {
                    "text",
                    "string",
                    "integer",
                    "number",
                    "boolean",
                    "json",
                    "image",
                    "audio",
                    "video",
                    "file",
                }:
                    raise ValueError(
                        f"Unsupported FineTuneSchema field kind '{field_kind}' for '{key}'"
                    )
                fields.append(
                    {
                        "key": key,
                        "type": field_kind,
                        "required": value.required,
                        "description": value.description,
                        "multiple": value.multiple,
                    }
                )
        return fields

    @classmethod
    def contract(cls) -> dict[str, Any]:
        """Return the public fine-tune schema contract."""
        fields = cls.fields_contract()
        if not fields:
            raise ValueError("FineTuneSchema must declare at least one TuningField")
        return {"fields": fields}


@dataclass(frozen=True, slots=True)
class ArtifactDescriptor:
    """One produced fine-tune artifact stored inside the tuned-result bundle."""

    path: str
    kind: ArtifactKind
    sha256: str
    size_bytes: int
    source_path: Path | None = None

    def to_contract(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "path": self.path,
            "kind": self.kind,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
        }
        if self.source_path is not None:
            payload["inline_base64"] = base64.b64encode(
                self.source_path.read_bytes()
            ).decode("ascii")
        return payload


@dataclass(frozen=True, slots=True)
class ArtifactField:
    """Descriptor for one typed output artifact."""

    kind: ArtifactKind
    required: bool = True
    description: str | None = None

    def to_contract(self, key: str) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "key": key,
            "kind": self.kind,
            "required": self.required,
        }
        if self.description:
            payload["description"] = self.description
        return payload


class JsonArtifact(ArtifactField):
    """JSON artifact declaration."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
    ) -> None:
        super().__init__(kind="json", required=required, description=description)


class FileArtifact(ArtifactField):
    """Generic file artifact declaration."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
    ) -> None:
        super().__init__(kind="file", required=required, description=description)


class _ArtifactWriter:
    """Typed writer for one declared output artifact."""

    def __init__(self, *, name: str, kind: ArtifactKind, root: Path) -> None:
        self.name = name
        self.kind = kind
        self.root = root

    def write_json(self, payload: Any) -> ArtifactDescriptor:
        if self.kind != "json":
            raise RuntimeError(f"Artifact '{self.name}' is not a JSON artifact")
        import json

        target = self.root / f"{self.name}.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(payload, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return _descriptor_for_path(target, root=self.root, kind="json")

    def write_bytes(
        self, payload: bytes, *, filename: str | None = None
    ) -> ArtifactDescriptor:
        if not isinstance(payload, bytes):
            raise RuntimeError(f"Artifact '{self.name}' payload must be bytes")
        normalized = str(filename or self.name).strip()
        if not normalized:
            raise RuntimeError(f"Artifact '{self.name}' filename must be non-empty")
        target = self.root / normalized
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        return _descriptor_for_path(target, root=self.root, kind=self.kind)


class TuningArtifactWriters:
    """Attribute-access artifact writer collection built from TuneArtifacts."""

    def __init__(self, schema_cls: type["TuneArtifacts"], root: Path) -> None:
        self._schema_cls = schema_cls
        self._root = root
        for name, field in schema_cls.artifact_fields().items():
            setattr(self, name, _ArtifactWriter(name=name, kind=field.kind, root=root))


class TuneArtifacts:
    """Base class for type-safe fine-tune output artifact declarations."""

    def __init__(self, **values: ArtifactDescriptor) -> None:
        fields_by_name = self.__class__.artifact_fields()
        extras = sorted(set(values) - set(fields_by_name))
        if extras:
            raise ValueError(f"Unknown tune artifacts: {', '.join(extras)}")
        for name, field in fields_by_name.items():
            value = values.get(name)
            if value is None:
                if field.required:
                    raise ValueError(f"Tune artifact '{name}' is required")
                continue
            if not isinstance(value, ArtifactDescriptor):
                raise ValueError(
                    f"Tune artifact '{name}' must be an ArtifactDescriptor"
                )
            if value.kind != field.kind:
                raise ValueError(
                    f"Tune artifact '{name}' must be kind '{field.kind}', got '{value.kind}'"
                )
            setattr(self, name, value)

    @classmethod
    def artifact_fields(cls) -> dict[str, ArtifactField]:
        return {
            key: value
            for key, value in cls.__dict__.items()
            if isinstance(value, ArtifactField)
        }

    @classmethod
    def contract(cls) -> dict[str, Any]:
        artifact_fields = cls.artifact_fields()
        if not artifact_fields:
            raise ValueError("TuneArtifacts must declare at least one ArtifactField")
        return {
            "fields": [
                field.to_contract(name) for name, field in artifact_fields.items()
            ]
        }

    def to_payload(self) -> dict[str, dict[str, Any]]:
        payload: dict[str, dict[str, Any]] = {}
        for name in self.__class__.artifact_fields():
            descriptor = getattr(self, name, None)
            if descriptor is not None:
                payload[name] = descriptor.to_contract()
        return payload


@dataclass(frozen=True, slots=True)
class Metric:
    """Descriptor for one typed fine-tune metric."""

    goal: MetricGoal
    required: bool = True
    description: str | None = None

    def to_contract(self, key: str) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "key": key,
            "goal": self.goal,
            "required": self.required,
        }
        if self.description:
            payload["description"] = self.description
        return payload


class TuneMetrics:
    """Base class for type-safe fine-tune metric values."""

    def __init__(self, **values: float) -> None:
        fields_by_name = self.__class__.metric_fields()
        extras = sorted(set(values) - set(fields_by_name))
        if extras:
            raise ValueError(f"Unknown tune metrics: {', '.join(extras)}")
        for name, field in fields_by_name.items():
            raw_value = values.get(name)
            if raw_value is None:
                if field.required:
                    raise ValueError(f"Tune metric '{name}' is required")
                continue
            if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
                raise ValueError(f"Tune metric '{name}' must be numeric")
            setattr(self, name, float(raw_value))

    @classmethod
    def metric_fields(cls) -> dict[str, Metric]:
        return {
            key: value
            for key, value in cls.__dict__.items()
            if isinstance(value, Metric)
        }

    @classmethod
    def contract(cls) -> dict[str, Any]:
        metric_fields = cls.metric_fields()
        if not metric_fields:
            raise ValueError("TuneMetrics must declare at least one Metric")
        return {
            "fields": [field.to_contract(name) for name, field in metric_fields.items()]
        }

    def to_payload(self) -> dict[str, float]:
        payload: dict[str, float] = {}
        for name in self.__class__.metric_fields():
            if hasattr(self, name):
                payload[name] = float(getattr(self, name))
        return payload


def _descriptor_for_path(
    path: Path,
    *,
    root: Path,
    kind: ArtifactKind,
) -> ArtifactDescriptor:
    data = path.read_bytes()
    try:
        relative = path.resolve().relative_to(root.resolve())
    except ValueError as exc:
        raise RuntimeError(f"Artifact path '{path}' is outside artifacts_dir") from exc
    return ArtifactDescriptor(
        path=relative.as_posix(),
        kind=kind,
        sha256=hashlib.sha256(data).hexdigest(),
        size_bytes=len(data),
        source_path=path,
    )


class _TunedArtifactReader:
    """Typed reader for one materialized tuned artifact."""

    def __init__(self, *, descriptor: ArtifactDescriptor, root: Path) -> None:
        self.descriptor = descriptor
        self.root = root

    @property
    def path(self) -> Path:
        return self.root / self.descriptor.path

    def read_json(self) -> Any:
        if self.descriptor.kind != "json":
            raise RuntimeError("Artifact is not JSON")
        import json

        return json.loads(self.path.read_text(encoding="utf-8"))

    def read_bytes(self) -> bytes:
        return self.path.read_bytes()


class TunedResult(Generic[ArtifactsT, MetricsT]):
    """Typed view over a materialized tuned-result bundle."""

    def __init__(
        self,
        *,
        artifacts_schema: type[ArtifactsT],
        metrics_schema: type[MetricsT],
        artifacts: dict[str, ArtifactDescriptor],
        metrics: MetricsT,
        root: Path,
    ) -> None:
        self.metrics = metrics
        self.artifacts = SimpleNamespace()
        for name in artifacts_schema.artifact_fields():
            descriptor = artifacts.get(name)
            if descriptor is not None:
                setattr(
                    self.artifacts,
                    name,
                    _TunedArtifactReader(descriptor=descriptor, root=root),
                )


class TuningRecord(SimpleNamespace):
    """One attribute-access training record materialized from the dataset bundle."""


class TuningParams(SimpleNamespace):
    """One attribute-access view of platform-supplied hyperparameters."""


@dataclass(slots=True)
class TuningDatasetView:
    """Author-facing dataset view that yields attribute-access records."""

    dataset: Any

    @property
    def num_rows(self) -> int:
        """Return the number of records exposed by this view."""
        return len(self.dataset)

    def __len__(self) -> int:
        return len(self.dataset)

    def __iter__(self) -> Iterator[TuningRecord]:
        for item in self.dataset:
            yield _materialize_record(item)

    def __getitem__(self, index: int) -> TuningRecord:
        return _materialize_record(self.dataset[index])


@dataclass(slots=True)
class TuneResult(Generic[ArtifactsT, MetricsT]):
    """Structured tuning result returned by model-owned tuning code."""

    artifacts: ArtifactsT
    metrics: MetricsT

    def __post_init__(self) -> None:
        if not isinstance(self.artifacts, TuneArtifacts):
            raise ValueError("TuneResult.artifacts must extend TuneArtifacts")
        if not isinstance(self.metrics, TuneMetrics):
            raise ValueError("TuneResult.metrics must extend TuneMetrics")

    def to_payload(self) -> dict[str, Any]:
        return {
            "artifacts": self.artifacts.to_payload(),
            "metrics": self.metrics.to_payload(),
        }


@dataclass(slots=True)
class TuningSession(Generic[DatasetT, ArtifactsT]):
    """Author-facing tuning session passed into ``Component.tune(self, tuning)``."""

    train_dataset: TuningDatasetView
    validation_dataset: TuningDatasetView
    params: TuningParams
    output_dir: Path
    artifacts: TuningArtifactWriters
    cache_dir: Path
    work_dir: Path
    limits: Any
    accelerator: Any
    request_id: str | None
    trial_id: int | None
    _bundle: "LoadedTuningBundle"

    @property
    def artifacts_dir(self) -> Path:
        """Return the runtime-provided writable output directory for typed artifact writers."""
        return self.output_dir

    def resolve_path(self, relative_path: str) -> Path:
        """Resolve one dataset-relative asset path to an extracted absolute path."""
        return self._bundle.resolve_path(relative_path)

    def suggest_float(
        self,
        name: str,
        min_val: float,
        max_val: float,
        *,
        default: float,
    ) -> float:
        """Resolve one float parameter from backend values or explicit default."""
        key = _normalize_parameter_name(name)
        _ensure_numeric_bounds(min_val=min_val, max_val=max_val, kind="float", name=key)
        if isinstance(default, bool) or not isinstance(default, (int, float)):
            raise RuntimeError(f"Default for parameter '{key}' must be numeric")
        resolved = self._resolve_suggested_value(key=key, default=float(default))
        if isinstance(resolved, bool) or not isinstance(resolved, (int, float)):
            raise RuntimeError(f"Parameter '{key}' must be numeric")
        number = float(resolved)
        if number < float(min_val) or number > float(max_val):
            raise RuntimeError(
                f"Parameter '{key}' must be between {float(min_val)} and {float(max_val)}"
            )
        return number

    def suggest_int(
        self,
        name: str,
        min_val: int,
        max_val: int,
        *,
        default: int,
    ) -> int:
        """Resolve one integer parameter from backend values or explicit default."""
        key = _normalize_parameter_name(name)
        if isinstance(min_val, bool) or not isinstance(min_val, int):
            raise RuntimeError(f"min_val for parameter '{key}' must be an integer")
        if isinstance(max_val, bool) or not isinstance(max_val, int):
            raise RuntimeError(f"max_val for parameter '{key}' must be an integer")
        _ensure_numeric_bounds(
            min_val=min_val, max_val=max_val, kind="integer", name=key
        )
        if isinstance(default, bool) or not isinstance(default, int):
            raise RuntimeError(f"Default for parameter '{key}' must be an integer")
        resolved = self._resolve_suggested_value(key=key, default=default)
        if isinstance(resolved, bool) or not isinstance(resolved, int):
            raise RuntimeError(f"Parameter '{key}' must be an integer")
        if resolved < min_val or resolved > max_val:
            raise RuntimeError(
                f"Parameter '{key}' must be between {min_val} and {max_val}"
            )
        return resolved

    def suggest_categorical(
        self,
        name: str,
        choices: Sequence[Any],
        *,
        default: Any,
    ) -> Any:
        """Resolve one categorical parameter from backend values or explicit default."""
        key = _normalize_parameter_name(name)
        options = list(choices)
        if not options:
            raise RuntimeError(f"Parameter '{key}' choices must be non-empty")
        if default not in options:
            raise RuntimeError(f"Default for parameter '{key}' must be in choices")
        resolved = self._resolve_suggested_value(key=key, default=default)
        if resolved not in options:
            raise RuntimeError(
                f"Parameter '{key}' value '{resolved}' is not one of: {', '.join(str(item) for item in options)}"
            )
        return resolved

    def _resolve_suggested_value(self, *, key: str, default: Any) -> Any:
        if hasattr(self.params, key):
            return getattr(self.params, key)
        return default


@dataclass(slots=True)
class TuningContext:
    """Generic model-scoped tuning context for one trial/run."""

    input: dict[str, Any]
    parameters: dict[str, Any]
    runtime_context: Any
    process_context: Any


def _namespaceify(value: Any, *, namespace_type: type[SimpleNamespace]) -> Any:
    """Recursively convert JSON-like dict payloads into attribute-access namespaces."""
    if isinstance(value, dict):
        materialized: dict[str, Any] = {}
        for key, item in value.items():
            normalized_key = str(key).strip()
            materialized[normalized_key] = _namespaceify(
                item,
                namespace_type=TuningRecord,
            )
        return namespace_type(**materialized)
    if isinstance(value, list):
        return [_namespaceify(item, namespace_type=TuningRecord) for item in value]
    return value


def _normalize_parameter_name(name: str) -> str:
    normalized = str(name or "").strip()
    if not normalized:
        raise RuntimeError("Parameter name must be non-empty")
    return normalized


def _ensure_numeric_bounds(
    *, min_val: float, max_val: float, kind: str, name: str
) -> None:
    if isinstance(min_val, bool) or not isinstance(min_val, (int, float)):
        raise RuntimeError(f"min_val for parameter '{name}' must be numeric")
    if isinstance(max_val, bool) or not isinstance(max_val, (int, float)):
        raise RuntimeError(f"max_val for parameter '{name}' must be numeric")
    if float(max_val) < float(min_val):
        raise RuntimeError(
            f"max_val for parameter '{name}' must be >= min_val for {kind} suggestion"
        )


def _extract_param_definition(value: Any, *, name: str) -> dict[str, Any]:
    if hasattr(value, "to_contract") and callable(value.to_contract):
        payload = value.to_contract()
        if not isinstance(payload, dict):
            raise RuntimeError(
                f"Tuning parameter '{name}' to_contract() must return a dict"
            )
        return payload
    if isinstance(value, dict):
        return dict(value)
    raise RuntimeError(f"Tuning parameter '{name}' must be a parameter object or dict")


def _normalize_materialization_contract(
    raw_contract: Any,
    *,
    artifact_fields: dict[str, ArtifactField],
) -> dict[str, Any]:
    """Validate one declarative tuned-result materialization contract."""
    if not isinstance(raw_contract, dict):
        raise RuntimeError("Tuning runner must declare materialization as an object")

    strategy = str(raw_contract.get("strategy") or "").strip().lower()
    if strategy not in {"append_adapter", "replace_root"}:
        raise RuntimeError(
            "Tuning runner materialization.strategy must be 'append_adapter' or 'replace_root'"
        )

    result_kind = str(raw_contract.get("result_kind") or "").strip().lower()
    if result_kind not in {"adapter_bundle", "root_bundle"}:
        raise RuntimeError(
            "Tuning runner materialization.result_kind must be 'adapter_bundle' or 'root_bundle'"
        )

    raw_required_artifacts = raw_contract.get("required_artifacts")
    if not isinstance(raw_required_artifacts, list) or not raw_required_artifacts:
        raise RuntimeError(
            "Tuning runner materialization.required_artifacts must be a non-empty array"
        )
    required_artifacts: list[str] = []
    seen_required_artifacts: set[str] = set()
    for item in raw_required_artifacts:
        key = str(item or "").strip()
        if not key:
            raise RuntimeError(
                "Tuning runner materialization.required_artifacts must contain non-empty keys"
            )
        field = artifact_fields.get(key)
        if field is None:
            raise RuntimeError(
                f"Tuning runner materialization.required_artifacts references unknown artifact '{key}'"
            )
        if field.kind != "file":
            raise RuntimeError(
                f"Tuning runner materialization.required_artifacts must reference file artifacts; '{key}' is '{field.kind}'"
            )
        if key in seen_required_artifacts:
            raise RuntimeError(
                "Tuning runner materialization.required_artifacts must not contain duplicates"
            )
        seen_required_artifacts.add(key)
        required_artifacts.append(key)

    chaining = str(raw_contract.get("chaining") or "").strip().lower()
    if chaining not in {"flatten", "replace"}:
        raise RuntimeError(
            "Tuning runner materialization.chaining must be 'flatten' or 'replace'"
        )

    normalized: dict[str, Any] = {
        "strategy": strategy,
        "result_kind": result_kind,
        "required_artifacts": required_artifacts,
        "chaining": chaining,
    }

    if strategy == "append_adapter":
        if result_kind != "adapter_bundle":
            raise RuntimeError(
                "Tuning runner materialization.append_adapter requires result_kind='adapter_bundle'"
            )
        if chaining != "flatten":
            raise RuntimeError(
                "Tuning runner materialization.append_adapter requires chaining='flatten'"
            )
        adapter_format = str(raw_contract.get("adapter_format") or "").strip().lower()
        if not adapter_format:
            raise RuntimeError(
                "Tuning runner materialization.append_adapter requires adapter_format"
            )
        normalized["adapter_format"] = adapter_format
        return normalized

    if result_kind != "root_bundle":
        raise RuntimeError(
            "Tuning runner materialization.replace_root requires result_kind='root_bundle'"
        )
    if chaining != "replace":
        raise RuntimeError(
            "Tuning runner materialization.replace_root requires chaining='replace'"
        )
    return normalized


def _validate_parameter_definition(
    name: str, payload: dict[str, Any]
) -> dict[str, Any]:
    kind = str(payload.get("kind") or "").strip().lower()
    if kind == "number":
        kind = "float"
    if kind not in {"integer", "float", "select"}:
        raise RuntimeError(
            f"Tuning parameter '{name}' kind must be one of: integer, float, select"
        )
    required = bool(payload.get("required", True))
    normalized: dict[str, Any] = {
        "kind": kind,
        "default": payload.get("default"),
        "required": required,
    }
    if kind in {"integer", "float"}:
        min_val = payload.get("min")
        max_val = payload.get("max")
        if min_val is None or max_val is None:
            raise RuntimeError(f"Tuning parameter '{name}' requires min and max")
        _ensure_numeric_bounds(
            min_val=float(min_val), max_val=float(max_val), kind=kind, name=name
        )
        normalized["min"] = int(min_val) if kind == "integer" else float(min_val)
        normalized["max"] = int(max_val) if kind == "integer" else float(max_val)
        if kind == "integer":
            if isinstance(payload.get("default"), bool) or not isinstance(
                payload.get("default"), int
            ):
                raise RuntimeError(
                    f"Tuning parameter '{name}' default must be an integer"
                )
        else:
            default = payload.get("default")
            if isinstance(default, bool) or not isinstance(default, (int, float)):
                raise RuntimeError(f"Tuning parameter '{name}' default must be numeric")
            normalized["default"] = float(default)
        if (
            normalized["default"] < normalized["min"]
            or normalized["default"] > normalized["max"]
        ):
            raise RuntimeError(
                f"Tuning parameter '{name}' default must be within min/max bounds"
            )
        step = payload.get("step")
        if step is not None:
            normalized["step"] = int(step) if kind == "integer" else float(step)
        log = payload.get("log")
        if log:
            normalized["log"] = bool(log)
    else:
        options = payload.get("options")
        if not isinstance(options, list) or not options:
            raise RuntimeError(
                f"Tuning parameter '{name}' select requires non-empty options"
            )
        if payload.get("default") not in options:
            raise RuntimeError(
                f"Tuning parameter '{name}' default must be one of options"
            )
        normalized["options"] = options
    return normalized


def _normalized_hyperparams_schema(
    schema_cls: type[Any] | None,
) -> dict[str, dict[str, Any]]:
    if schema_cls is None:
        return {}
    contract = getattr(schema_cls, "contract", None)
    if not callable(contract):
        raise RuntimeError("Tuning hyperparams_schema must expose contract()")
    payload = contract()
    if not isinstance(payload, list):
        raise RuntimeError("Tuning hyperparams_schema.contract() must return a list")
    normalized: dict[str, dict[str, Any]] = {}
    for field in payload:
        if not isinstance(field, dict):
            raise RuntimeError("Tuning hyperparams_schema fields must be objects")
        name = str(field.get("name") or "").strip()
        if not name:
            raise RuntimeError("Tuning hyperparams_schema fields must declare name")
        normalized[name] = _validate_parameter_definition(name, field)
    return normalized


def _resolve_tuning_model_class(module_path: str, model_key: str) -> type[Any]:
    from .loader import load_model_class

    normalized_key = str(model_key or "").strip().lower()
    if not normalized_key:
        raise RuntimeError("model_key is required to resolve model-scoped tuning")

    entry = Path(module_path).resolve()
    project_root = entry.parent
    model_module_path = project_root / "main.py"
    if not model_module_path.exists():
        raise RuntimeError(
            f"Model key '{model_key}' could not be resolved: {model_module_path} is missing"
        )
    return load_model_class(str(model_module_path))


def load_model_tuning_contract(module_path: str, *, model_key: str) -> dict[str, Any]:
    """Load model-scoped tuning metadata and dataset schema contract from ``main.py``."""
    if not module_path or not os.path.exists(module_path):
        raise FileNotFoundError(f"Model module not found: {module_path}")

    model_cls = _resolve_tuning_model_class(module_path, model_key)
    tuning_runner_cls = getattr(model_cls, "tuning", None)
    if tuning_runner_cls is None:
        raise RuntimeError(
            f"Model '{model_cls.__name__}' does not declare tuning capability (missing tuning class)"
        )
    if not isinstance(tuning_runner_cls, type):
        raise RuntimeError(
            f"Model '{model_cls.__name__}' tuning declaration must reference a class"
        )

    schema_cls = getattr(tuning_runner_cls, "dataset_schema", None)
    if schema_cls is None:
        raise RuntimeError("Tuning runner must declare dataset_schema")
    if not isinstance(schema_cls, type):
        raise RuntimeError("Tuning runner dataset_schema must reference a class")
    if not _is_fine_tune_schema_subclass(schema_cls):
        raise RuntimeError("Tuning runner dataset_schema must extend FineTuneSchema")
    artifacts_schema_cls = getattr(tuning_runner_cls, "artifacts_schema", None)
    if artifacts_schema_cls is None:
        raise RuntimeError("Tuning runner must declare artifacts_schema")
    if not isinstance(artifacts_schema_cls, type) or not issubclass(
        artifacts_schema_cls, TuneArtifacts
    ):
        raise RuntimeError("Tuning runner artifacts_schema must extend TuneArtifacts")
    metrics_schema_cls = getattr(tuning_runner_cls, "metrics_schema", None)
    if metrics_schema_cls is None:
        raise RuntimeError("Tuning runner must declare metrics_schema")
    if not isinstance(metrics_schema_cls, type) or not issubclass(
        metrics_schema_cls, TuneMetrics
    ):
        raise RuntimeError("Tuning runner metrics_schema must extend TuneMetrics")
    run = getattr(tuning_runner_cls, "run", None)
    if not callable(run):
        raise RuntimeError("Tuning runner must implement run(session)")
    apply = getattr(tuning_runner_cls, "apply", None)
    if not callable(apply):
        raise RuntimeError("Tuning runner must implement apply(engine, result)")
    parameters = _normalized_hyperparams_schema(
        getattr(tuning_runner_cls, "hyperparams_schema", None)
    )
    materialization = _normalize_materialization_contract(
        getattr(tuning_runner_cls, "materialization", None),
        artifact_fields=artifacts_schema_cls.artifact_fields(),
    )

    return {
        "supported": True,
        "model_key": str(model_key).strip().lower(),
        "schema": schema_cls.contract(),
        "artifacts": artifacts_schema_cls.contract(),
        "metrics": metrics_schema_cls.contract(),
        "materialization": materialization,
        "supports_chaining": bool(
            getattr(tuning_runner_cls, "supports_chaining", False)
        ),
        "parameters": parameters,
    }


def _materialize_record(value: Any) -> TuningRecord:
    """Convert one dataset record dict into an attribute-access object."""
    if not isinstance(value, dict):
        raise RuntimeError("Fine-tune dataset rows must be JSON objects")
    materialized = _namespaceify(value, namespace_type=TuningRecord)
    if not isinstance(materialized, TuningRecord):
        raise RuntimeError("Failed to materialize fine-tune dataset record")
    return materialized


def _materialize_params(parameters: dict[str, Any]) -> TuningParams:
    """Convert trial parameter payload into an attribute-access namespace."""
    materialized: dict[str, Any] = {}
    for raw_key, raw_value in parameters.items():
        key = str(raw_key).strip()
        if not key:
            raise RuntimeError("Fine-tune parameter names must be non-empty")
        materialized[key] = _namespaceify(raw_value, namespace_type=TuningRecord)
    return TuningParams(**materialized)


def _empty_validation_dataset(dataset: Any) -> Any:
    """Return an empty dataset with the same schema as the training dataset."""
    return dataset.select([])


def _split_bundle_dataset(
    bundle: "LoadedTuningBundle", input_data: dict[str, Any]
) -> tuple[Any, Any]:
    """Split one extracted bundle into train/validation datasets."""
    validation = input_data.get("validation")
    if not isinstance(validation, dict):
        raise RuntimeError("validation must be an object")

    mode = str(validation.get("mode") or "").strip().lower()
    if mode == "disabled":
        return bundle.dataset, _empty_validation_dataset(bundle.dataset)
    if mode != "auto_split":
        raise RuntimeError(f"Unsupported tuning validation.mode: {mode}")

    raw_ratio = validation.get("ratio")
    try:
        ratio = float(raw_ratio)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("validation.ratio must be numeric") from exc

    if not 0.0 < ratio < 1.0:
        raise RuntimeError("validation.ratio must be between 0 and 1")

    if len(bundle.dataset) < 2:
        raise RuntimeError(
            "Fine-tune dataset must contain at least 2 records when validation split is enabled"
        )

    split = bundle.dataset.train_test_split(test_size=ratio, seed=42, shuffle=True)
    return split["train"], split["test"]


def _find_schema_subclasses(module: Any) -> list[type[FineTuneSchema]]:
    subclasses: list[type[FineTuneSchema]] = []
    for value in vars(module).values():
        if (
            isinstance(value, type)
            and _is_fine_tune_schema_subclass(value)
            and getattr(value, "__module__", None) == module.__name__
        ):
            subclasses.append(value)
    return subclasses


def _is_fine_tune_schema_subclass(value: type[Any]) -> bool:
    for base in value.__mro__[1:]:
        if base.__name__ != "FineTuneSchema":
            continue
        if base.__module__.endswith("aimp_sdk.tuning"):
            return True
    return False


def _purge_modules_for_path(module_dir: str) -> None:
    """Remove cached modules loaded from one project directory."""
    normalized_dir = os.path.abspath(module_dir)
    prefix = f"{normalized_dir}{os.sep}"
    for module_name, module in list(sys.modules.items()):
        if (
            module_name == "aimp_user_tuning_schema"
            or module_name == "modes"
            or module_name.startswith("modes.")
            or module_name == "components"
            or module_name.startswith("components.")
            or module_name == "settings"
            or module_name == "resources"
            or module_name == "src"
            or module_name.startswith("src.")
        ):
            sys.modules.pop(module_name, None)
            continue
        module_file = getattr(module, "__file__", None)
        if isinstance(module_file, str):
            normalized_file = os.path.abspath(module_file)
            if normalized_file == normalized_dir or normalized_file.startswith(prefix):
                sys.modules.pop(module_name, None)
                continue
        module_paths = getattr(module, "__path__", None)
        if module_paths is None:
            continue
        for entry in module_paths:
            normalized_entry = os.path.abspath(str(entry))
            if normalized_entry == normalized_dir or normalized_entry.startswith(
                prefix
            ):
                sys.modules.pop(module_name, None)
                break


def load_tuning_schema_class(module_path: str) -> type[FineTuneSchema]:
    """Load a FineTuneSchema subclass from a Python module path."""
    if not module_path or not os.path.exists(module_path):
        msg = f"Tuning schema module not found: {module_path}"
        raise FileNotFoundError(msg)

    spec = util.spec_from_file_location("aimp_user_tuning_schema", module_path)
    if spec is None or spec.loader is None:
        msg = f"Failed to load module spec: {module_path}"
        raise ImportError(msg)

    module = util.module_from_spec(spec)
    module_dir = os.path.dirname(os.path.abspath(module_path))
    _purge_modules_for_path(module_dir)
    sys.modules["aimp_user_tuning_schema"] = module
    sys.path.insert(0, module_dir)
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.remove(module_dir)

    subclasses = _find_schema_subclasses(module)
    if not subclasses:
        raise ValueError("No FineTuneSchema subclass found in module")
    if len(subclasses) > 1:
        names = ", ".join(sorted(cls.__name__ for cls in subclasses))
        raise ValueError(f"Multiple FineTuneSchema subclasses found: {names}")
    return subclasses[0]


def load_tuning_schema_contract(module_path: str) -> dict[str, Any]:
    """Load the serialized fine-tune schema contract from a module path."""
    schema_cls = load_tuning_schema_class(module_path)
    return schema_cls.contract()


@contextmanager
def open_tuning_session(
    input_data: dict[str, Any],
    parameters: dict[str, Any],
    *,
    process_context: Any,
    runtime_context: Any,
    artifacts_schema: type[TuneArtifacts],
) -> Iterator[TuningSession]:
    """Open one validated fine-tune bundle and expose the author-facing tuning session."""
    from .tuning_data import load_tuning_dataset_bundle

    dataset_path = str(input_data.get("dataset_path") or "").strip()
    if not dataset_path:
        raise RuntimeError("dataset_path is required for fine-tune execution")

    bundle = load_tuning_dataset_bundle(dataset_path)
    try:
        runtime_tuning_dir = getattr(runtime_context, "tuning_output_dir", None)
        if runtime_tuning_dir is None:
            raise RuntimeError(
                "Fine-tune execution is missing the runtime-provided writable output_dir"
            )
        artifacts_root = Path(str(runtime_tuning_dir))
        artifacts_root.mkdir(parents=True, exist_ok=True)
        train_dataset, validation_dataset = _split_bundle_dataset(bundle, input_data)
        trial_id_raw = input_data.get("trial_id")
        trial_id = int(trial_id_raw) if isinstance(trial_id_raw, int) else None
        yield TuningSession(
            train_dataset=TuningDatasetView(train_dataset),
            validation_dataset=TuningDatasetView(validation_dataset),
            params=_materialize_params(parameters),
            output_dir=artifacts_root,
            artifacts=TuningArtifactWriters(
                artifacts_schema,
                artifacts_root,
            ),
            cache_dir=Path(str(getattr(runtime_context, "cache_dir", ".cache"))),
            work_dir=Path(str(getattr(runtime_context, "work_dir", "."))),
            limits=getattr(runtime_context, "limits", None),
            accelerator=getattr(runtime_context, "accelerator", None),
            request_id=getattr(runtime_context, "request_id", None),
            trial_id=trial_id,
            _bundle=bundle,
        )
    finally:
        bundle.cleanup()
