"""Executable model runner for long-lived mode dispatch."""

from __future__ import annotations

import argparse
import asyncio
from collections.abc import Iterator
import contextlib
import json
import os
import shutil
import sys
from pathlib import Path
from types import GeneratorType
from typing import Any, TextIO

from .execution_assets import ExecutionArtifactContractError
from .execution_assets import ModelLoadError
from .model_runtime_loader import load_mode_runtime
from .runtime import ExecutionStreamSink
from .runtime import ProcessContext, process_context_from_env
from .runtime import reset_current_execution_context
from .runtime import RuntimeContext
from .runtime import runtime_context_from_payload, set_current_execution_context
from .runtime import VectorExecutionContext
from .runtime import vector_context_from_payload

_WORKER_PROTOCOL_VERSION = 2


class ModelRunner:
    """Own one shared mode runtime instance and serve execution requests."""

    def __init__(self, module_path: str) -> None:
        self.module_path = module_path
        self.process_context: ProcessContext = process_context_from_env()
        self.runtime = load_mode_runtime(module_path)
        self._started = False

    def start(self) -> None:
        if self._started:
            return
        self.runtime.setup(self.process_context)
        self._started = True

    def shutdown(self) -> None:
        if not self._started:
            return
        self.runtime.teardown(self.process_context)
        self._started = False

    def handle_request(
        self,
        request: dict[str, Any],
        *,
        output_stream: TextIO | None = None,
    ) -> dict[str, Any]:
        request_id = str(request.get("request_id", "") or "").strip()
        mode = str(request.get("mode", "") or "").strip().lower()
        input_data = request.get("input", {})
        parameters = request.get("parameters", {})
        if parameters is None:
            parameters = {}
        if not isinstance(parameters, dict):
            raise ValueError("Request parameters must be a JSON object")

        runtime_context = runtime_context_from_payload(
            request.get("execution_context", {}),
            mode=mode,
        )
        vector_context = vector_context_from_payload(request.get("vector_context"))
        output_fields = {}
        mode_spec = self.runtime.mode_specs().get(mode)
        if mode_spec is not None:
            output_fields = dict(getattr(mode_spec.outputs, "fields", {}) or {})
        stream_sink = ExecutionStreamSink(
            request_id=request_id,
            output_fields=output_fields,
            emit_callback=(
                lambda payload: _write_message(
                    output_stream,
                    {
                        "type": "event",
                        "protocol_version": _WORKER_PROTOCOL_VERSION,
                        "request_id": request_id,
                        "payload": payload,
                    },
                )
            )
            if output_stream is not None
            else None,
        )
        self.runtime.context = runtime_context
        tokens = set_current_execution_context(
            runtime_context,
            vector_context,
            stream_sink,
        )
        try:
            with _request_scoped_environment(
                runtime_context=runtime_context,
                vector_context=vector_context,
            ):
                with contextlib.redirect_stdout(sys.stderr):
                    if mode == "tune":
                        output = asyncio.run(
                            self.runtime.run_tuning(input_data, parameters)
                        )
                    else:
                        output = asyncio.run(
                            self.runtime.dispatch(mode, input_data, parameters)
                        )
            if isinstance(output, GeneratorType):
                output = list(output)
        finally:
            reset_current_execution_context(tokens)
            self._cleanup_request_work_dir(runtime_context.work_dir)

        return {
            "type": "response",
            "protocol_version": _WORKER_PROTOCOL_VERSION,
            "request_id": request_id,
            "success": True,
            "output": output,
            "error": None,
        }

    def serve_forever(self, *, input_stream: TextIO, output_stream: TextIO) -> None:
        try:
            self.start()
        except ExecutionArtifactContractError as exc:
            _write_message(
                output_stream,
                {
                    "type": "fatal",
                    "protocol_version": _WORKER_PROTOCOL_VERSION,
                    "error": str(exc),
                    "failure_category": "artifact_contract",
                },
            )
            raise SystemExit(1) from exc
        except ModelLoadError as exc:
            _write_message(
                output_stream,
                {
                    "type": "fatal",
                    "protocol_version": _WORKER_PROTOCOL_VERSION,
                    "error": str(exc),
                    "failure_category": "model_load",
                },
            )
            raise SystemExit(1) from exc
        _write_message(
            output_stream,
            {"type": "ready", "protocol_version": _WORKER_PROTOCOL_VERSION},
        )
        for raw_line in input_stream:
            line = raw_line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
                if not isinstance(request, dict):
                    raise ValueError("Model request must be a JSON object")
                response = self.handle_request(request, output_stream=output_stream)
            except Exception as exc:  # noqa: BLE001
                request_id = ""
                if "request" in locals() and isinstance(locals()["request"], dict):
                    request_id = str(
                        locals()["request"].get("request_id", "") or ""
                    ).strip()
                response = {
                    "type": "response",
                    "protocol_version": _WORKER_PROTOCOL_VERSION,
                    "request_id": request_id,
                    "success": False,
                    "output": None,
                    "error": str(exc),
                }
            _write_message(output_stream, response)

    def _cleanup_request_work_dir(self, work_dir: Path) -> None:
        process_work_dir = self.process_context.work_dir.resolve()
        try:
            resolved_work_dir = work_dir.resolve()
        except OSError:
            return

        if resolved_work_dir == process_work_dir:
            return
        if process_work_dir not in resolved_work_dir.parents:
            return
        shutil.rmtree(resolved_work_dir, ignore_errors=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Marketplace model runner")
    parser.add_argument(
        "--module",
        dest="module_path",
        default=None,
        help="Path to the model module (defaults to MODEL_ENTRYPOINT env var).",
    )
    args = parser.parse_args()
    module_path = args.module_path or _module_path_from_env()
    if not module_path:
        _write_message(
            sys.stdout,
            {
                "type": "fatal",
                "protocol_version": _WORKER_PROTOCOL_VERSION,
                "error": "Missing model module path. Set MODEL_ENTRYPOINT or pass --module.",
            },
        )
        raise SystemExit(1)

    runner = ModelRunner(module_path)
    try:
        runner.serve_forever(input_stream=sys.stdin, output_stream=sys.stdout)
    except Exception as exc:  # noqa: BLE001
        _write_message(
            sys.stdout,
            {
                "type": "fatal",
                "protocol_version": _WORKER_PROTOCOL_VERSION,
                "error": str(exc),
            },
        )
        raise SystemExit(1) from exc
    finally:
        runner.shutdown()


def _module_path_from_env() -> str:
    return os.environ.get("MODEL_ENTRYPOINT", "").strip()


@contextlib.contextmanager
def _request_scoped_environment(
    *,
    runtime_context: RuntimeContext,
    vector_context: VectorExecutionContext | None,
) -> Iterator[None]:
    overrides = _request_env_overrides(
        runtime_context=runtime_context,
        vector_context=vector_context,
    )
    previous_values = {key: os.environ.get(key) for key in overrides}
    try:
        for key, value in overrides.items():
            if value is None:
                os.environ.pop(key, None)
                continue
            os.environ[key] = value
        yield
    finally:
        for key, value in previous_values.items():
            if value is None:
                os.environ.pop(key, None)
                continue
            os.environ[key] = value


def _request_env_overrides(
    *,
    runtime_context: RuntimeContext,
    vector_context: VectorExecutionContext | None,
) -> dict[str, str | None]:
    request_id = str(getattr(runtime_context, "request_id", "") or "").strip() or None
    model_id = str(getattr(runtime_context, "model_id", "") or "").strip() or None
    work_dir = _normalized_optional_path(getattr(runtime_context, "work_dir", None))
    tuning_artifacts_dir = _normalized_optional_path(
        getattr(runtime_context, "tuning_artifacts_dir", None)
    )
    tuning_output_dir = _normalized_optional_path(
        getattr(runtime_context, "tuning_output_dir", None)
    )

    gateway_url = None
    execution_token = None
    vector_resources = None
    vector_timeout = None
    if vector_context is not None:
        gateway_url = (
            str(getattr(vector_context, "gateway_url", "") or "").strip() or None
        )
        execution_token = (
            str(getattr(vector_context, "execution_token", "") or "").strip() or None
        )
        vector_timeout_value = getattr(vector_context, "timeout_seconds", None)
        if vector_timeout_value is not None:
            vector_timeout = str(vector_timeout_value)
        vector_resources = json.dumps(list(vector_context.vector_resources))

    return {
        "AIMP_GATEWAY_URL": gateway_url,
        "AIMP_EXECUTION_TOKEN": execution_token,
        "AIMP_VECTOR_RESOURCES": vector_resources,
        "AIMP_VECTOR_TIMEOUT": vector_timeout,
        "AIMP_MODEL_ID": model_id,
        "AIMP_REQUEST_ID": request_id,
        "MODEL_REQUEST_ID": request_id,
        "MODEL_WORK_DIR": work_dir,
        "MODEL_TUNING_ARTIFACTS_DIR": tuning_artifacts_dir,
        "MODEL_TUNING_OUTPUT_DIR": tuning_output_dir,
    }


def _normalized_optional_path(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _write_message(output_stream: TextIO, payload: dict[str, Any]) -> None:
    output_stream.write(json.dumps(payload) + "\n")
    output_stream.flush()


if __name__ == "__main__":
    main()
