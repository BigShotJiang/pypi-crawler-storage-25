"""Package identity loading from ``pyproject.toml``."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any


def _resolve_project_dir(module_path: str | Path) -> Path:
    """Return the directory that contains the module entrypoint."""
    return Path(module_path).resolve().parent


def _find_pyproject(project_dir: Path) -> Path:
    """Locate ``pyproject.toml`` in *project_dir*.

    Searches ``project_dir`` first, then its parent, stopping at the filesystem root.
    Raises ``FileNotFoundError`` when no ``pyproject.toml`` is found.
    """
    candidate = project_dir / "pyproject.toml"
    if candidate.exists():
        return candidate
    parent = project_dir.parent
    if parent == project_dir:
        raise FileNotFoundError(
            f"pyproject.toml not found for project at {project_dir}"
        )
    return _find_pyproject(parent)


def load_pyproject_metadata(module_path: str | Path) -> dict[str, Any]:
    """Load package identity from ``pyproject.toml``.

    Reads ``[project].name``, ``[project].version``, ``[project].description``,
    and ``[tool.aimp.project].author``.
    """
    project_dir = _resolve_project_dir(module_path)
    pyproject_path = _find_pyproject(project_dir)
    data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    project = data.get("project") or {}
    tool_aimp = (data.get("tool") or {}).get("aimp") or {}
    project_section = tool_aimp.get("project") or {}

    version = str(project.get("version", "") or "").strip()
    if not version:
        raise ValueError(
            f"pyproject.toml [project].version is required but missing or empty "
            f"in {pyproject_path}"
        )

    return {
        "name": str(project.get("name", "") or "").strip(),
        "version": version,
        "description": str(project.get("description", "") or "").strip(),
        "author": str(project_section.get("author", "") or "").strip(),
    }


def load_package_identity(module_path: str | Path) -> dict[str, Any]:
    """Load canonical package identity from ``pyproject.toml``."""
    return {
        "schema_version": 5,
        "package": load_pyproject_metadata(module_path),
    }
