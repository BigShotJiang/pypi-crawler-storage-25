"""Class discovery and named registry helpers for app runtime objects."""

from __future__ import annotations

import importlib
import inspect
import pkgutil
import re
from typing import Any


def normalize_registry_name(value: str) -> str:
    """Normalize user-facing registry keys."""
    return re.sub(r"[^a-z0-9_]+", "_", str(value or "").strip().lower()).strip("_")


def default_registry_name(value: type[Any]) -> str:
    """Return the default registry name for one class."""
    explicit = getattr(value, "name", "")
    if isinstance(explicit, str) and explicit.strip():
        return normalize_registry_name(explicit)
    normalized = re.sub(r"(?<!^)(?=[A-Z])", "_", value.__name__).replace("-", "_").lower()
    return normalize_registry_name(normalized)


def discover_package_classes(
    package_name: str,
    base_cls: type[Any],
    *,
    exclude: tuple[type[Any], ...] = (),
) -> list[type[Any]]:
    """Import one package tree and return stable subclasses defined inside it."""
    package = importlib.import_module(package_name)
    if not hasattr(package, "__path__"):
        return []

    discovered: list[type[Any]] = []
    for module_info in pkgutil.iter_modules(package.__path__):
        module = importlib.import_module(f"{package_name}.{module_info.name}")
        for _, value in inspect.getmembers(module, inspect.isclass):
            if value.__module__ != module.__name__:
                continue
            if value is base_cls or value in exclude:
                continue
            if not issubclass(value, base_cls):
                continue
            if any(value is blocked or issubclass(value, blocked) for blocked in exclude):
                continue
            discovered.append(value)
    return sorted(discovered, key=lambda cls: (cls.__module__, cls.__name__))
