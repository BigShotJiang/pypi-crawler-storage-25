"""Runtime context primitives for model execution."""

from __future__ import annotations

from collections.abc import Callable
from contextvars import ContextVar
from contextvars import Token
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal
import os


@dataclass(frozen=True)
class AcceleratorInfo:
    """Generic accelerator facts resolved by the runtime."""

    kind: Literal["cpu", "gpu", "unknown"] = "unknown"
    backend: str | None = None
    count: int = 0
    identifiers: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecutionLimits:
    """Execution limits applied by the runtime."""

    cpu: str | None = None
    memory_mb: int | None = None
    timeout_seconds: int | None = None


@dataclass(frozen=True)
class ProcessContext:
    """Stable process-local context exposed during model setup/teardown."""

    model_id: str = ""
    artifacts_dir: Path = Path(".")
    cache_dir: Path = Path(".cache")
    work_dir: Path = Path(".")
    limits: ExecutionLimits = ExecutionLimits()
    accelerator: AcceleratorInfo = AcceleratorInfo()
    composition_manifest: dict[str, Any] | None = None

    def component_dir(self, name: str) -> Path:
        """Return the platform-managed directory for one component bundle."""
        normalized = str(name or "").strip()
        if not normalized:
            raise ValueError("component name is required")
        return self.artifacts_dir / "components" / normalized


@dataclass(frozen=True)
class RuntimeContext:
    """Platform-owned execution context exposed to model code."""

    model_id: str = ""
    mode: str = "execute"
    request_id: str | None = None
    artifacts_dir: Path = Path(".")
    tuning_artifacts_dir: Path | None = None
    tuning_output_dir: Path | None = None
    cache_dir: Path = Path(".cache")
    work_dir: Path = Path(".")
    limits: ExecutionLimits = ExecutionLimits()
    accelerator: AcceleratorInfo = AcceleratorInfo()
    composition_manifest: dict[str, Any] | None = None

    def component_dir(self, name: str) -> Path:
        """Return the platform-managed directory for one component bundle."""
        normalized = str(name or "").strip()
        if not normalized:
            raise ValueError("component name is required")
        return self.artifacts_dir / "components" / normalized


@dataclass(frozen=True)
class VectorExecutionContext:
    """Request-scoped vector access metadata resolved by the runtime."""

    gateway_url: str = ""
    execution_token: str = ""
    model_id: str = ""
    vector_resources: tuple[dict[str, Any], ...] = ()
    timeout_seconds: float | None = None
    request_id: str | None = None


class ExecutionStreamSink:
    """Request-scoped sink for progressive execution events."""

    def __init__(
        self,
        *,
        request_id: str,
        output_fields: dict[str, Any] | None = None,
        emit_callback: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.request_id = str(request_id or "").strip()
        self._output_fields = dict(output_fields or {})
        self._emit_callback = emit_callback

    def emit(
        self,
        *,
        op: Literal["append", "replace", "patch", "remove"],
        target: Any,
        content: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        target_name, field_decl = self._resolve_target(target)
        normalized_metadata = metadata or {}
        self._validate_operation(
            op=op,
            field_name=target_name,
            field_decl=field_decl,
            content=content,
        )
        if self._emit_callback is None:
            return
        payload: dict[str, Any] = {
            "op": op,
            "target": target_name,
            "metadata": normalized_metadata,
        }
        if op != "remove":
            payload["content"] = content
        self._emit_callback(payload)

    def _resolve_target(self, target: Any) -> tuple[str, Any]:
        if isinstance(target, str):
            raise TypeError(
                "Execution stream target must be a Schema.Outputs field reference, "
                "not a string field name."
            )

        target_name = getattr(target, "name", None)
        if not isinstance(target_name, str) or not target_name.strip():
            raise TypeError(
                "Execution stream target must be a Schema.Outputs field reference "
                "(for example ChatSchema.Outputs.answer)."
            )
        target_name = target_name.strip()

        target_role = getattr(target, "schema_role", None)
        if target_role not in {None, "outputs"}:
            raise TypeError(
                "Execution stream target must reference Schema.Outputs, "
                f"got Schema.{str(target_role).title()}."
            )

        field_decl = self._output_fields.get(target_name)
        if field_decl is None:
            known_outputs = sorted(self._output_fields)
            raise ValueError(
                f"Execution stream target {target_name!r} is not declared in mode outputs. "
                f"Known outputs: {known_outputs}"
            )
        return target_name, field_decl

    def _validate_operation(
        self,
        *,
        op: str,
        field_name: str,
        field_decl: Any,
        content: Any,
    ) -> None:
        field_kind = str(getattr(field_decl, "kind", "") or "").strip()
        if op == "append":
            if field_kind not in {"text", "string"}:
                raise ValueError(
                    f"Execution stream op 'append' only supports text outputs. "
                    f"Field {field_name!r} has kind {field_kind!r}."
                )
            if not isinstance(content, str):
                raise TypeError(
                    f"Execution stream op 'append' requires string content for "
                    f"field {field_name!r}."
                )
            return

        if op == "patch":
            if field_kind != "json":
                raise ValueError(
                    f"Execution stream op 'patch' only supports json outputs. "
                    f"Field {field_name!r} has kind {field_kind!r}."
                )
            if not isinstance(content, dict):
                raise TypeError(
                    f"Execution stream op 'patch' requires object content for "
                    f"field {field_name!r}."
                )
            return

        if op == "remove":
            return

        if op != "replace":
            raise ValueError(
                "Execution stream op must be one of: append, replace, patch, remove."
            )


_current_runtime_context: ContextVar[RuntimeContext | None] = ContextVar(
    "aimp_current_runtime_context",
    default=None,
)
_current_vector_context: ContextVar[VectorExecutionContext | None] = ContextVar(
    "aimp_current_vector_context",
    default=None,
)
_current_execution_stream: ContextVar[ExecutionStreamSink | None] = ContextVar(
    "aimp_current_execution_stream",
    default=None,
)


def process_context_from_env() -> ProcessContext:
    """Build a process-local context from startup environment variables.

    ``MODEL_ARTIFACTS_DIR`` is the execution bundle root (extracted publish archive), not a
    model-specific checkpoint folder; use ``resolve_execution_bundle_payload_dir`` for the inner
    ``artifacts/`` payload path when loading weights.
    """
    return ProcessContext(
        model_id=_optional_env("AIMP_MODEL_ID") or _optional_env("MODEL_ID") or "",
        artifacts_dir=_path_env("MODEL_ARTIFACTS_DIR", default="/app/artifacts"),
        cache_dir=_path_env("MODEL_CACHE_DIR", default="/tmp/aimp-cache"),
        work_dir=_path_env("MODEL_WORK_DIR", default="/tmp/aimp-work"),
        limits=_execution_limits_from_env(),
        accelerator=_accelerator_info_from_env(),
    )


def runtime_context_from_env(mode: str) -> RuntimeContext:
    """Build a runtime context from the current execution environment."""
    request_id = _optional_env("MODEL_REQUEST_ID") or _optional_env("AIMP_REQUEST_ID")
    process_context = process_context_from_env()
    return RuntimeContext(
        model_id=process_context.model_id,
        mode=str(mode or "execute").strip().lower() or "execute",
        request_id=request_id,
        artifacts_dir=process_context.artifacts_dir,
        tuning_artifacts_dir=_path_env(
            "MODEL_TUNING_ARTIFACTS_DIR",
            default=str(process_context.work_dir / "tuning-artifacts"),
        ),
        tuning_output_dir=_path_env(
            "MODEL_TUNING_OUTPUT_DIR",
            default=str(process_context.work_dir / "tuning-output"),
        ),
        cache_dir=process_context.cache_dir,
        work_dir=process_context.work_dir,
        limits=process_context.limits,
        accelerator=process_context.accelerator,
    )


def runtime_context_from_payload(
    payload: dict[str, Any], *, mode: str
) -> RuntimeContext:
    """Build a runtime context from an execution payload."""
    limits_payload = (
        payload.get("limits") if isinstance(payload.get("limits"), dict) else {}
    )
    accelerator_payload = (
        payload.get("accelerator")
        if isinstance(payload.get("accelerator"), dict)
        else {}
    )
    accelerator_identifiers_raw = accelerator_payload.get("identifiers", [])
    accelerator_identifiers = tuple(
        str(item).strip() for item in accelerator_identifiers_raw if str(item).strip()
    )

    return RuntimeContext(
        model_id=str(payload.get("model_id", "") or "").strip(),
        mode=str(mode or "execute").strip().lower() or "execute",
        request_id=_normalize_optional_string(payload.get("request_id")),
        artifacts_dir=Path(str(payload.get("artifacts_dir", "/app/artifacts"))),
        tuning_artifacts_dir=Path(
            str(
                payload.get("tuning_artifacts_dir")
                or Path(str(payload.get("work_dir", "/tmp/aimp-work")))
                / "tuning-artifacts"
            )
        ),
        tuning_output_dir=Path(
            str(
                payload.get("tuning_output_dir")
                or payload.get("tuning_artifacts_dir")
                or Path(str(payload.get("work_dir", "/tmp/aimp-work")))
                / "tuning-output"
            )
        ),
        cache_dir=Path(str(payload.get("cache_dir", "/tmp/aimp-cache"))),
        work_dir=Path(str(payload.get("work_dir", "/tmp/aimp-work"))),
        limits=ExecutionLimits(
            cpu=_normalize_optional_string(limits_payload.get("cpu")),
            memory_mb=_normalize_optional_int(limits_payload.get("memory_mb")),
            timeout_seconds=_normalize_optional_int(
                limits_payload.get("timeout_seconds")
            ),
        ),
        accelerator=AcceleratorInfo(
            kind=_normalize_accelerator_kind(accelerator_payload.get("kind")),
            backend=_normalize_optional_string(accelerator_payload.get("backend")),
            count=max(
                _normalize_optional_int(accelerator_payload.get("count")) or 0, 0
            ),
            identifiers=accelerator_identifiers,
        ),
        composition_manifest=(
            payload.get("composition_manifest")
            if isinstance(payload.get("composition_manifest"), dict)
            else None
        ),
    )


def vector_context_from_payload(
    payload: dict[str, Any] | None,
) -> VectorExecutionContext | None:
    """Build a vector execution context from a request payload."""
    if not isinstance(payload, dict):
        return None

    vector_resources_raw = payload.get("vector_resources", [])
    vector_resources: list[dict[str, Any]] = []
    if isinstance(vector_resources_raw, list):
        for item in vector_resources_raw:
            if isinstance(item, dict):
                vector_resources.append(item)

    timeout_seconds = payload.get("timeout_seconds")
    normalized_timeout: float | None
    if timeout_seconds is None:
        normalized_timeout = None
    else:
        try:
            normalized_timeout = float(timeout_seconds)
        except (TypeError, ValueError):
            normalized_timeout = None

    return VectorExecutionContext(
        gateway_url=str(payload.get("gateway_url", "") or "").strip(),
        execution_token=str(payload.get("execution_token", "") or "").strip(),
        model_id=str(payload.get("model_id", "") or "").strip(),
        vector_resources=tuple(vector_resources),
        timeout_seconds=normalized_timeout,
        request_id=_normalize_optional_string(payload.get("request_id")),
    )


def set_current_execution_context(
    runtime_context: RuntimeContext,
    vector_context: VectorExecutionContext | None,
    stream_sink: ExecutionStreamSink | None = None,
) -> tuple[
    Token[RuntimeContext | None],
    Token[VectorExecutionContext | None],
    Token[ExecutionStreamSink | None],
]:
    """Store request-scoped runtime/vector context for the current execution."""
    runtime_token = _current_runtime_context.set(runtime_context)
    vector_token = _current_vector_context.set(vector_context)
    stream_token = _current_execution_stream.set(stream_sink)
    return runtime_token, vector_token, stream_token


def reset_current_execution_context(
    tokens: tuple[
        Token[RuntimeContext | None],
        Token[VectorExecutionContext | None],
        Token[ExecutionStreamSink | None],
    ],
) -> None:
    """Reset request-scoped runtime/vector context after execution."""
    runtime_token, vector_token, stream_token = tokens
    _current_runtime_context.reset(runtime_token)
    _current_vector_context.reset(vector_token)
    _current_execution_stream.reset(stream_token)


def get_current_runtime_context() -> RuntimeContext | None:
    """Return the current request-scoped runtime context, if any."""
    return _current_runtime_context.get()


def get_current_vector_context() -> VectorExecutionContext | None:
    """Return the current request-scoped vector context, if any."""
    return _current_vector_context.get()


def get_current_execution_stream() -> ExecutionStreamSink | None:
    """Return the current request-scoped execution stream sink, if any."""
    return _current_execution_stream.get()


def _execution_limits_from_env() -> ExecutionLimits:
    """Build generic execution limits from environment variables."""
    return ExecutionLimits(
        cpu=_optional_env("MODEL_CPU_LIMIT"),
        memory_mb=_int_env("MODEL_MEMORY_MB"),
        timeout_seconds=_int_env("MODEL_TIMEOUT_SECONDS"),
    )


def _accelerator_info_from_env() -> AcceleratorInfo:
    """Build generic accelerator metadata from environment variables."""
    accelerator_kind = _enum_env(
        "MODEL_ACCELERATOR_KIND",
        allowed={"cpu", "gpu", "unknown"},
        default="unknown",
    )
    accelerator_backend = _optional_env("MODEL_ACCELERATOR_BACKEND")
    accelerator_count = _int_env("MODEL_ACCELERATOR_COUNT", default=0) or 0
    accelerator_identifiers = tuple(
        part.strip()
        for part in (_optional_env("MODEL_ACCELERATOR_IDENTIFIERS") or "").split(",")
        if part.strip()
    )
    return AcceleratorInfo(
        kind=accelerator_kind,
        backend=accelerator_backend,
        count=max(accelerator_count, 0),
        identifiers=accelerator_identifiers,
    )


def _optional_env(name: str) -> str | None:
    value = os.environ.get(name, "").strip()
    return value or None


def _path_env(name: str, *, default: str) -> Path:
    value = os.environ.get(name, "").strip() or default
    return Path(value)


def _int_env(name: str, *, default: int | None = None) -> int | None:
    value = os.environ.get(name, "").strip()
    if not value:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _enum_env(
    name: str,
    *,
    allowed: set[str],
    default: Literal["cpu", "gpu", "unknown"],
) -> Literal["cpu", "gpu", "unknown"]:
    value = os.environ.get(name, "").strip().lower()
    if value in allowed:
        return value  # type: ignore[return-value]
    return default


def _normalize_optional_string(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _normalize_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _normalize_accelerator_kind(value: Any) -> Literal["cpu", "gpu", "unknown"]:
    normalized = str(value or "").strip().lower()
    if normalized in {"cpu", "gpu", "unknown"}:
        return normalized  # type: ignore[return-value]
    return "unknown"
