"""High-level SDK client for smart tuning and inference."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .data_utils import DatasetPayload
from .data_utils import serialize_dataset
from .data_utils import upload_dataset_stream
from .vector import JsonValue

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from datasets import Dataset


class ClientError(RuntimeError):
    """Raised when SDK client requests fail."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)


class FineTuneJobError(RuntimeError):
    """Raised when a fine-tune job fails."""

    def __init__(self, message: str, *, error_code: str | None = None) -> None:
        self.error_code = error_code
        super().__init__(message)


class EvaluationJobError(RuntimeError):
    """Raised when an evaluation job fails."""

    def __init__(self, message: str, *, error_code: str | None = None) -> None:
        self.error_code = error_code
        super().__init__(message)


@dataclass
class FineTuneJob:
    """Fine-tune job helper for polling and result access."""

    client: "Client"
    id: str
    status: str | None = None
    _data: dict[str, Any] | None = None

    @property
    def tuned_model_id(self) -> str | None:
        """Return tuned model ID when available."""

        if not self._data:
            return None
        output_asset = self._data.get("output_asset_id") or self._data.get("output_asset")
        return str(output_asset) if output_asset else None

    @property
    def tuned_model_slug(self) -> str | None:
        """Return tuned model slug when available."""
        if not self._data:
            return None
        slug = self._data.get("output_asset_slug")
        return str(slug) if slug else None

    def refresh(self) -> "FineTuneJob":
        """Refresh job status from Gateway."""

        request_id = self.client._new_request_id()
        data = self.client._get_json(f"/api/jobs/{self.id}", request_id)
        normalized = self.client._normalize_fine_tune_job_payload(data)
        self._data = normalized
        self.status = normalized.get("status")
        return self

    def wait_for_completion(
        self,
        *,
        poll_interval_seconds: float = 5.0,
        timeout_seconds: float | None = None,
    ) -> "FineTuneJob":
        """Poll until job completes.

        Raises:
            FineTuneJobError: If job fails or is canceled.
            TimeoutError: If timeout is reached.
        """

        start_time = time.time()
        while True:
            try:
                self.refresh()
            except ClientError as exc:
                if exc.status_code == 429:
                    time.sleep(poll_interval_seconds * 2)
                    continue
                raise
            if self.status in {"succeeded", "failed", "canceled"}:
                break
            if (
                timeout_seconds is not None
                and time.time() - start_time >= timeout_seconds
            ):
                raise TimeoutError("Fine-tune job timed out")
            time.sleep(poll_interval_seconds)

        if self.status in {"failed", "canceled"}:
            error_code = None
            error_message = "Fine-tune job failed"
            if self._data:
                error_code = self._data.get("error_code")
                error_message = self._data.get("error_message") or error_message
            raise FineTuneJobError(error_message, error_code=error_code)

        return self


class ModelsClient:
    """Model operations client."""

    def __init__(self, client: "Client") -> None:
        self._client = client

    def execute(
        self,
        *,
        model: str,
        input: JsonValue,
        parameters: dict[str, Any] | None = None,
        mode: str = "execute",
    ) -> dict[str, Any]:
        """Execute a public model mode via the runs API."""

        normalized_mode = str(mode or "execute").strip().lower() or "execute"
        payload = {
            "model": model,
            "mode": normalized_mode,
            "input": input,
            "params": parameters or {},
        }
        request_id = self._client._new_request_id()
        return self._client._post_json(
            "/api/runs",
            payload,
            request_id,
        )

    def evaluate(self, *, model: str, dataset: "Dataset") -> dict[str, Any]:
        """Evaluate model baseline on a dataset (synchronous)."""
        payload: DatasetPayload = serialize_dataset(dataset)
        dataset_id = upload_dataset_stream(self._client, payload)
        request_id = self._client._new_request_id()
        response = self._client._post_json(
            f"/api/models/{model}/evaluate",
            {"dataset_id": dataset_id},
            request_id,
        )
        job_id = response.get("evaluation_job_id")
        if not job_id:
            raise ClientError("Evaluation response missing evaluation_job_id")
        return self._client._wait_for_evaluation(str(job_id))


class Client:
    """High-level SDK client for tuning and inference."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float | None = None,
    ) -> None:
        """Initialize the SDK client.

        Args:
            api_key: API key for Gateway (defaults to AIMP_API_KEY).
            base_url: Gateway base URL (defaults to AIMP_GATEWAY_URL).
            timeout_seconds: Request timeout in seconds (default 30).
        """

        self.api_key = (api_key or os.environ.get("AIMP_API_KEY") or "").strip()
        self.base_url = (base_url or os.environ.get("AIMP_GATEWAY_URL") or "").strip()
        self.timeout_seconds = timeout_seconds or 30.0

        if not self.api_key:
            raise ClientError("Missing API key. Set AIMP_API_KEY or pass api_key.")
        if not self.base_url:
            raise ClientError(
                "Missing Gateway URL. Set AIMP_GATEWAY_URL or pass base_url."
            )

        self.base_url = self.base_url.rstrip("/")
        self._models = ModelsClient(self)

    @property
    def models(self) -> ModelsClient:
        """Access model operations."""

        return self._models

    def _normalize_fine_tune_job_payload(self, data: dict[str, Any]) -> dict[str, Any]:
        """Normalize one fine-tune job payload into the SDK job shape."""
        details = data.get("details")
        details_payload = details if isinstance(details, dict) else {}
        return {
            "job_id": str(data.get("job_id") or data.get("id") or ""),
            "model_slug": str(data.get("model_slug") or data.get("slug") or ""),
            "status": str(data.get("status") or ""),
            "created_at": data.get("created_at"),
            "started_at": data.get("started_at"),
            "finished_at": data.get("finished_at"),
            "output_asset_id": data.get("output_asset_id")
            or details_payload.get("output_asset_id")
            or data.get("output_asset"),
            "output_asset_slug": data.get("output_asset_slug")
            or details_payload.get("output_asset_slug"),
            "output_kind": data.get("output_kind") or details_payload.get("output_kind"),
            "result_bundle_uri": data.get("result_bundle_uri")
            or details_payload.get("result_bundle_uri"),
            "timeline": data.get("timeline") or [],
            "error_code": data.get("error_code"),
            "error_message": data.get("error_message"),
        }

    def fine_tune(self, *, model: str, dataset: "Dataset") -> FineTuneJob:
        """Legacy method intentionally disabled in operations-only flow."""

        del model
        del dataset
        raise ClientError(
            "fine_tune() is disabled in SDK V1. "
            "Use create_fine_tune_job(...), then wait_for_completion() and execute with the derived model slug.",
        )

    def create_fine_tune_job(
        self,
        *,
        model: str,
        dataset_ref: str,
        max_trials: int = 3,
        labels: dict[str, Any] | None = None,
    ) -> FineTuneJob:
        """Create a fine-tune job via the jobs API."""
        normalized_model = str(model or "").strip()
        normalized_dataset_ref = str(dataset_ref or "").strip()
        if not normalized_model:
            raise ClientError("model is required")
        if not normalized_dataset_ref:
            raise ClientError("dataset_ref is required")
        if max_trials < 1:
            raise ClientError("max_trials must be >= 1")
        payload: dict[str, Any] = {
            "model": normalized_model,
            "input": {
                "dataset_ref": normalized_dataset_ref,
                "budget": {"max_trials": max_trials},
            },
        }
        if labels:
            payload["input"]["labels"] = labels
        request_id = self._new_request_id()
        data = self._post_json("/api/jobs/fine-tune", payload, request_id)
        job_payload = data.get("job") if isinstance(data.get("job"), dict) else data
        normalized = self._normalize_fine_tune_job_payload(job_payload)
        return FineTuneJob(
            client=self,
            id=str(normalized.get("job_id") or ""),
            status=str(normalized.get("status") or ""),
            _data=normalized,
        )

    def fine_tune_job(self, *, job_id: str) -> FineTuneJob:
        """Load an existing fine-tune job helper by job ID."""
        if not job_id.strip():
            raise ClientError("job_id is required")
        job = FineTuneJob(client=self, id=job_id.strip())
        return job.refresh()

    def list_fine_tune_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """List fine-tune jobs via the jobs endpoint."""
        query: dict[str, str] = {
            "type": "fine-tune",
            "page": str(page),
            "page_size": str(page_size),
        }
        if model_slug:
            query["model_slug"] = model_slug
        if status:
            query["status"] = status
        encoded = urllib.parse.urlencode(query)
        request_id = self._new_request_id()
        payload = self._get_json(f"/api/jobs?{encoded}", request_id)
        results = payload.get("results")
        normalized_results = []
        if isinstance(results, list):
            normalized_results = [
                self._normalize_fine_tune_job_payload(item)
                for item in results
                if isinstance(item, dict)
            ]
        pagination = payload.get("pagination") if isinstance(payload.get("pagination"), dict) else {}
        return {"results": normalized_results, "pagination": pagination}

    def _wait_for_evaluation(
        self,
        job_id: str,
        *,
        poll_interval_seconds: float = 5.0,
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        start_time = time.time()
        while True:
            request_id = self._new_request_id()
            try:
                data = self._get_json(f"/api/evaluation-jobs/{job_id}", request_id)
            except ClientError as exc:
                if exc.status_code == 429:
                    time.sleep(poll_interval_seconds * 2)
                    continue
                raise
            status = data.get("status")
            if status in {"succeeded", "failed", "canceled"}:
                if status == "succeeded":
                    return {
                        "metric_name": data.get("metric_name"),
                        "metric_value": data.get("metric_value"),
                        "direction": data.get("objective_direction"),
                        "metadata": data.get("metadata") or {},
                    }
                error_code = data.get("error_code")
                error_message = data.get("error_message") or "Evaluation failed"
                raise EvaluationJobError(error_message, error_code=error_code)
            if (
                timeout_seconds is not None
                and time.time() - start_time >= timeout_seconds
            ):
                raise TimeoutError("Evaluation job timed out")
            time.sleep(poll_interval_seconds)

    def _headers(self, request_id: str) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
            "X-Request-Id": request_id,
        }

    def _new_request_id(self) -> str:
        return str(uuid.uuid4())

    def _post_json(
        self,
        path: str,
        payload: dict[str, Any],
        request_id: str,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            url, data=data, headers=self._headers(request_id)
        )

        start_time = time.time()
        try:
            with urllib.request.urlopen(
                request, timeout=self.timeout_seconds
            ) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8") if exc.fp else str(exc)
            message = self._format_error_message(detail, exc.code)
            raise ClientError(message, status_code=exc.code) from exc
        except urllib.error.URLError as exc:
            raise ClientError(f"Request failed: {exc}") from exc

        result = self._parse_json(body, status_code=None)
        logger.info(
            "sdk_request_completed",
            extra={
                "request_id": request_id,
                "operation": "http_post",
                "execution_time": time.time() - start_time,
            },
        )
        return result

    def _get_json(self, path: str, request_id: str) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        request = urllib.request.Request(
            url, headers=self._headers(request_id), method="GET"
        )

        start_time = time.time()
        try:
            with urllib.request.urlopen(
                request, timeout=self.timeout_seconds
            ) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8") if exc.fp else str(exc)
            message = self._format_error_message(detail, exc.code)
            raise ClientError(message, status_code=exc.code) from exc
        except urllib.error.URLError as exc:
            raise ClientError(f"Request failed: {exc}") from exc

        result = self._parse_json(body, status_code=None)
        logger.info(
            "sdk_request_completed",
            extra={
                "request_id": request_id,
                "operation": "http_get",
                "execution_time": time.time() - start_time,
            },
        )
        return result

    def _parse_json(self, body: str, status_code: int | None) -> dict[str, Any]:
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError as exc:
            raise ClientError(
                "Response was not valid JSON", status_code=status_code
            ) from exc
        if not isinstance(parsed, dict):
            raise ClientError("Response must be a JSON object", status_code=status_code)
        return parsed

    def _format_error_message(self, detail: str, status_code: int | None) -> str:
        message = detail
        try:
            parsed = json.loads(detail)
            if isinstance(parsed, dict):
                message = parsed.get("detail") or parsed.get("message") or detail
        except json.JSONDecodeError:
            pass
        if status_code is not None:
            return f"Request failed ({status_code}): {message}"
        return f"Request failed: {message}"
