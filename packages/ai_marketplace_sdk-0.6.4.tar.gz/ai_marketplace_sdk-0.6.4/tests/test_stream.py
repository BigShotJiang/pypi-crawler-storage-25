"""Tests for the high-level Stream API."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
FRAMEWORK_ROOT = SDK_ROOT.parents[0] / "framework"
sys.path.insert(0, str(SDK_ROOT))
sys.path.insert(0, str(FRAMEWORK_ROOT))

from aimp_framework.base import IntegerField, JsonField, Schema, StringField, TextField
from aimp_sdk.mode import ModeError
from aimp_sdk.runtime import ExecutionStreamSink
from aimp_sdk.runtime import reset_current_execution_context
from aimp_sdk.runtime import RuntimeContext
from aimp_sdk.runtime import set_current_execution_context
from aimp_sdk.stream import Stream
from aimp_sdk.stream import StreamState
from aimp_sdk.stream import canonical_status_payload


class ChatSchema:
    class Outputs(Schema.Outputs):
        answer = TextField(required=True)
        status = JsonField(required=False)


def _sink_with_capture(
    output_fields: dict[str, object],
) -> tuple[ExecutionStreamSink, list[dict[str, object]]]:
    captured: list[dict[str, object]] = []

    def emit_callback(payload: dict[str, object]) -> None:
        captured.append(payload)

    return (
        ExecutionStreamSink(
            request_id="req-1",
            output_fields=output_fields,
            emit_callback=emit_callback,
        ),
        captured,
    )


def test_stream_text_accepts_text_and_string_output_fields() -> None:
    class O(Schema.Outputs):
        t = TextField(required=True)
        s = StringField(required=True)

    Stream.text(text=O.t)
    Stream.text(text=O.s)


def test_stream_text_rejects_non_text_output() -> None:
    class O(Schema.Outputs):
        n = IntegerField(required=True)

    with pytest.raises(TypeError, match="text or string"):
        Stream.text(text=O.n)


def test_status_field_must_be_json() -> None:
    class O(Schema.Outputs):
        answer = TextField(required=True)
        bad = TextField(required=False)

    with pytest.raises(TypeError, match="json output"):
        Stream.text(text=O.answer, status=O.bad)


def test_write_emits_append_events() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(text=ChatSchema.Outputs.answer)
        stream.write("a")
        stream.write("b")
        out = stream.done(final_text="ab")
    finally:
        reset_current_execution_context(tokens)

    assert [ev["op"] for ev in captured] == ["append", "append"]
    assert captured[0]["target"] == "answer"
    assert captured[0]["content"] == "a"
    assert out.answer == "ab"


def test_status_emits_replace_with_canonical_shape() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(
            text=ChatSchema.Outputs.answer,
            status=ChatSchema.Outputs.status,
        )
        stream.status(StreamState.QUEUED, label="Waiting")
        stream.write("z")
        out = stream.done(final_text="z")
    finally:
        reset_current_execution_context(tokens)

    assert captured[0]["op"] == "replace"
    assert captured[0]["target"] == "status"
    assert captured[0]["content"] == canonical_status_payload(
        StreamState.QUEUED,
        label="Waiting",
        metadata={},
        error=None,
    )
    assert captured[-1]["op"] == "replace"
    assert captured[-1]["content"]["state"] == "completed"
    assert out.status["done"] is True


def test_done_accumulates_text_when_final_text_omitted() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, _captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(text=ChatSchema.Outputs.answer)
        stream.write("Hello")
        stream.write(" world")
        out = stream.done()
    finally:
        reset_current_execution_context(tokens)

    assert out.answer == "Hello world"


def test_done_without_text_on_required_field_raises() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, _captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(text=ChatSchema.Outputs.answer)
        with pytest.raises(ModeError, match="no text was written"):
            stream.done()
    finally:
        reset_current_execution_context(tokens)


def test_fail_emits_failed_status_when_configured() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(
            text=ChatSchema.Outputs.answer,
            status=ChatSchema.Outputs.status,
        )
        stream.status(StreamState.GENERATING)
        with pytest.raises(ModeError, match="boom"):
            stream.fail("boom", code="e1")
    finally:
        reset_current_execution_context(tokens)

    failed = [ev for ev in captured if ev.get("content", {}).get("state") == "failed"]
    assert len(failed) == 1
    assert failed[0]["content"]["error"] == {"message": "boom", "code": "e1"}


def test_status_rejects_failed_state() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, _captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(
            text=ChatSchema.Outputs.answer,
            status=ChatSchema.Outputs.status,
        )
        with pytest.raises(ModeError, match="fail"):
            stream.status(StreamState.FAILED)
    finally:
        reset_current_execution_context(tokens)


def test_canonical_status_payload_rules() -> None:
    assert canonical_status_payload(StreamState.GENERATING)["done"] is False
    assert canonical_status_payload(StreamState.COMPLETED)["done"] is True
    err = {"message": "x", "code": None}
    failed = canonical_status_payload(StreamState.FAILED, error=err)
    assert failed["done"] is True
    assert failed["error"] == err


def test_canonical_status_payload_empty_label_falls_back_to_default() -> None:
    assert canonical_status_payload(StreamState.GENERATING, label="")["label"] == "Generating"
    assert canonical_status_payload(StreamState.GENERATING, label="   ")["label"] == "Generating"


def test_status_passes_metadata_and_omitted_label_uses_default() -> None:
    fields = dict(ChatSchema.Outputs._fields)
    sink, captured = _sink_with_capture(fields)
    rt = RuntimeContext(request_id="r1")
    tokens = set_current_execution_context(rt, None, sink)

    try:
        stream = Stream.text(
            text=ChatSchema.Outputs.answer,
            status=ChatSchema.Outputs.status,
        )
        stream.status(
            StreamState.RETRIEVING,
            label="Searching documentation",
            metadata={"provider": "glm", "phase": "retrieval"},
        )
        stream.status(StreamState.GENERATING)
        out = stream.done(final_text="ok")
    finally:
        reset_current_execution_context(tokens)

    retrieving = next(
        ev for ev in captured if ev.get("target") == "status" and ev["content"]["state"] == "retrieving"
    )
    assert retrieving["content"]["metadata"] == {"provider": "glm", "phase": "retrieval"}
    assert retrieving["content"]["label"] == "Searching documentation"

    generating = next(
        ev for ev in captured if ev.get("target") == "status" and ev["content"]["state"] == "generating"
    )
    assert generating["content"]["label"] == "Generating"
    assert generating["content"]["metadata"] == {}
    assert out.answer == "ok"
