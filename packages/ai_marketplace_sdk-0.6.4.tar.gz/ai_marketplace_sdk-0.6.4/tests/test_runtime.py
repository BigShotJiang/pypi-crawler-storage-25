"""Tests for SDK runtime context helpers."""

from __future__ import annotations

from pathlib import Path
import sys

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk.runtime import runtime_context_from_env  # noqa: E402
from aimp_sdk.runtime import runtime_context_from_payload  # noqa: E402


def test_runtime_context_from_env_reads_generic_execution_facts(monkeypatch) -> None:
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    monkeypatch.setenv("MODEL_REQUEST_ID", "req-456")
    monkeypatch.setenv("MODEL_ARTIFACTS_DIR", "/tmp/artifacts")
    monkeypatch.setenv("MODEL_TUNING_ARTIFACTS_DIR", "/tmp/tuning-artifacts")
    monkeypatch.setenv("MODEL_CACHE_DIR", "/tmp/cache")
    monkeypatch.setenv("MODEL_WORK_DIR", "/tmp/work")
    monkeypatch.setenv("MODEL_CPU_LIMIT", "2")
    monkeypatch.setenv("MODEL_MEMORY_MB", "1024")
    monkeypatch.setenv("MODEL_TIMEOUT_SECONDS", "60")
    monkeypatch.setenv("MODEL_ACCELERATOR_KIND", "gpu")
    monkeypatch.setenv("MODEL_ACCELERATOR_BACKEND", "cuda")
    monkeypatch.setenv("MODEL_ACCELERATOR_COUNT", "1")
    monkeypatch.setenv("MODEL_ACCELERATOR_IDENTIFIERS", "0,1")

    context = runtime_context_from_env("execute")

    assert context.model_id == "model-123"
    assert context.mode == "execute"
    assert context.request_id == "req-456"
    assert str(context.artifacts_dir) == "/tmp/artifacts"
    assert str(context.tuning_artifacts_dir) == "/tmp/tuning-artifacts"
    assert str(context.cache_dir) == "/tmp/cache"
    assert str(context.work_dir) == "/tmp/work"
    assert context.limits.cpu == "2"
    assert context.limits.memory_mb == 1024
    assert context.limits.timeout_seconds == 60
    assert context.accelerator.kind == "gpu"
    assert context.accelerator.backend == "cuda"
    assert context.accelerator.count == 1
    assert context.accelerator.identifiers == ("0", "1")


def test_runtime_context_from_payload_includes_composition_manifest() -> None:
    context = runtime_context_from_payload(
        {
            "model_id": "model-123",
            "composition_manifest": {
                "kind": "derived_model_recipe",
                "adapters": [{"artifact": {"uri": "/tmp/adapter-a"}}],
            },
        },
        mode="execute",
    )

    assert context.composition_manifest is not None
    assert context.composition_manifest["kind"] == "derived_model_recipe"


def test_runtime_context_from_payload_includes_tuning_artifacts_dir() -> None:
    context = runtime_context_from_payload(
        {
            "model_id": "model-123",
            "artifacts_dir": "/tmp/artifacts",
            "tuning_artifacts_dir": "/tmp/tuning-artifacts",
            "cache_dir": "/tmp/cache",
            "work_dir": "/tmp/work",
        },
        mode="tune",
    )

    assert str(context.artifacts_dir) == "/tmp/artifacts"
    assert str(context.tuning_artifacts_dir) == "/tmp/tuning-artifacts"
    assert str(context.cache_dir) == "/tmp/cache"
    assert str(context.work_dir) == "/tmp/work"
