"""Tests for the remote worker adapter bridge."""

from __future__ import annotations

import io
from typing import Any

import pytest
from aimp_sdk.remote_worker_adapter.runner_bridge import (
    RemoteWorkerAdapterError,
    RunnerBridge,
    build_runner_request,
    format_provider_result,
)


class _FakeProcess:
    def __init__(self, *, stdout: str, returncode: int | None = None) -> None:
        self.stdin = io.StringIO()
        self.stdout = io.StringIO(stdout)
        self.stderr = io.StringIO()
        self._returncode = returncode
        self.terminated = False

    def poll(self) -> int | None:
        return self._returncode

    def terminate(self) -> None:
        self.terminated = True
        self._returncode = 143

    def kill(self) -> None:
        self.terminated = True
        self._returncode = 137


def test_build_runner_request_translates_provider_job_input() -> None:
    request = build_runner_request(
        {
            "id": "job-1",
            "input": {
                "mode": "generate",
                "input": {"prompt": "hello"},
                "parameters": {"temperature": 0.7},
                "execution_context": {"model_id": "model-1"},
                "vector_context": {"collection": "docs"},
                "startup_env": {"TOKEN": "secret"},
            },
        }
    )

    assert request == {
        "request_id": "job-1",
        "mode": "generate",
        "input": {"prompt": "hello"},
        "parameters": {"temperature": 0.7},
        "execution_context": {"model_id": "model-1"},
        "vector_context": {"collection": "docs"},
        "startup_env": {"TOKEN": "secret"},
    }


def test_build_runner_request_rejects_malformed_payload() -> None:
    with pytest.raises(RemoteWorkerAdapterError, match="input must be a JSON object"):
        build_runner_request({"input": "bad"})


def test_runner_bridge_reads_ready_and_formats_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    processes: list[_FakeProcess] = []

    def _popen(command: list[str], **_: Any) -> _FakeProcess:
        assert command == [
            "python",
            "-m",
            "aimp_sdk.model_runner",
            "--module",
            "/app/main.py",
        ]
        process = _FakeProcess(
            stdout=(
                '{"type":"ready","protocol_version":2}\n'
                '{"type":"event","event":"chunk"}\n'
                '{"type":"response","request_id":"job-1","success":true,"output":{"ok":true},"error":null}\n'
            )
        )
        processes.append(process)
        return process

    monkeypatch.setattr(
        "aimp_sdk.remote_worker_adapter.runner_bridge.subprocess.Popen",
        _popen,
    )
    bridge = RunnerBridge()

    response = bridge.execute({"id": "job-1", "input": {"mode": "generate"}})

    assert format_provider_result(response) == {
        "success": True,
        "output": {"ok": True},
        "error": None,
    }
    assert processes[0].stdin.getvalue().strip().startswith('{"request_id": "job-1"')


def test_runner_bridge_restarts_when_startup_entrypoint_changes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    commands: list[list[str]] = []
    processes: list[_FakeProcess] = []

    def _popen(command: list[str], **_: Any) -> _FakeProcess:
        commands.append(command)
        process = _FakeProcess(
            stdout=(
                '{"type":"ready","protocol_version":2}\n'
                '{"type":"response","request_id":"job-1","success":true,"output":{},"error":null}\n'
            )
        )
        processes.append(process)
        return process

    monkeypatch.setattr(
        "aimp_sdk.remote_worker_adapter.runner_bridge.subprocess.Popen",
        _popen,
    )
    bridge = RunnerBridge()

    bridge.execute(
        {
            "id": "job-1",
            "input": {
                "mode": "generate",
                "startup_env": {"MODEL_ENTRYPOINT": "/app/first.py"},
            },
        }
    )
    bridge.execute(
        {
            "id": "job-1",
            "input": {
                "mode": "generate",
                "startup_env": {"MODEL_ENTRYPOINT": "/app/second.py"},
            },
        }
    )

    assert commands == [
        ["python", "-m", "aimp_sdk.model_runner", "--module", "/app/first.py"],
        ["python", "-m", "aimp_sdk.model_runner", "--module", "/app/second.py"],
    ]
    assert processes[0].terminated
