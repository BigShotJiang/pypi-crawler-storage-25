"""Tests for declarative vector models and managers."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest
import aimp_sdk.vector_store as vector_store_module

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk import IntegerField, JsonField, Metric, StringField, TextField, Vector  # noqa: E402


class _FakeVectorClient:
    def __init__(self) -> None:
        self.search_calls: list[dict[str, object]] = []
        self.upsert_calls: list[dict[str, object]] = []
        self.stats_calls: list[dict[str, object]] = []
        self.delete_calls: list[list[str]] = []

    def search(
        self,
        embedding: list[float],
        *,
        limit: int = 10,
        score_threshold: float | None = None,
        filters: dict[str, object] | None = None,
    ) -> list[dict[str, object]]:
        self.search_calls.append(
            {
                "embedding": embedding,
                "limit": limit,
                "score_threshold": score_threshold,
                "filters": filters,
            }
        )
        return []

    def upsert(
        self,
        embedding: list[float],
        *,
        id: str | None = None,
        metadata: dict[str, object] | None = None,
    ) -> str:
        self.upsert_calls.append(
            {"embedding": embedding, "id": id, "metadata": metadata}
        )
        return "vec-1"

    def stats(self, *, filters: dict[str, object] | None = None) -> dict[str, object]:
        self.stats_calls.append({"filters": filters})
        return {"vector_count": 7}

    def count(self, *, filters: dict[str, object] | None = None) -> int:
        self.stats_calls.append({"filters": filters})
        return 7

    def delete(self, ids: list[str]) -> int:
        self.delete_calls.append(ids)
        return len(ids)


def test_vector_collects_declared_fields_and_config() -> None:
    class Knowledge(Vector):
        alias = "knowledge"
        name = "Knowledge"
        description = "Knowledge vectors."
        dimension = 1536
        metric = Metric.COSINE
        default_limit = 10

        content = TextField(required=True)
        source = StringField(filterable=True, required=True)
        tag = StringField(filterable=True)
        chunk_index = IntegerField(filterable=True, default=0)
        extra = JsonField()

    vector = Knowledge()
    assert vector.vector_alias == "knowledge"
    assert list(vector.declared_fields) == [
        "content",
        "source",
        "tag",
        "chunk_index",
        "extra",
    ]
    assert Knowledge.dimension == 1536
    assert Knowledge.metric is Metric.COSINE
    assert Knowledge.default_limit == 10


def test_vector_rejects_raw_metric_strings() -> None:
    with pytest.raises(TypeError, match="metric must be a Metric enum value"):

        class Knowledge(Vector):
            alias = "knowledge"
            name = "Knowledge"
            description = "Knowledge vectors."
            dimension = 1536
            metric = "cosine"


def test_vector_uses_explicit_alias_and_display_metadata() -> None:
    class WorkspaceKnowledge(Vector):
        alias = "docs"
        name = "Documents"
        description = "Workspace documents."
        dimension = 1536
        metric = Metric.COSINE

    assert WorkspaceKnowledge().vector_alias == "docs"
    assert WorkspaceKnowledge().name == "Documents"
    assert WorkspaceKnowledge().description == "Workspace documents."


def test_vector_client_uses_declared_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    class WorkspaceKnowledge(Vector):
        alias = "docs"
        name = "Documents"
        description = "Workspace documents."
        dimension = 1536
        metric = Metric.COSINE

    captured: list[str | None] = []

    class _ProbeVectorClient:
        def __init__(self, *, resource_alias=None, **kwargs):
            _ = kwargs
            captured.append(resource_alias)

    monkeypatch.setattr(vector_store_module, "VectorClient", _ProbeVectorClient)

    WorkspaceKnowledge()._client()

    assert captured == ["docs"]


def test_vector_objects_filter_validates_fields_and_lookups(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Knowledge(Vector):
        alias = "knowledge"
        name = "Knowledge"
        description = "Knowledge vectors."
        dimension = 1536
        metric = Metric.COSINE
        default_limit = 25
        content = TextField(required=True)
        source = StringField(filterable=True)
        tag = StringField(filterable=True)
        chunk_index = IntegerField(filterable=True, default=0)

    vector = Knowledge()
    fake_client = _FakeVectorClient()
    monkeypatch.setattr(vector, "_client", lambda: fake_client)

    vector.objects.filter(source="kb", chunk_index__gte=1, chunk_index__lte=5).search(
        [0.1, 0.2]
    )
    assert fake_client.search_calls == [
        {
            "embedding": [0.1, 0.2],
            "limit": 25,
            "score_threshold": None,
            "filters": {"source": "kb", "chunk_index": {"$gte": 1, "$lte": 5}},
        }
    ]

    vector.objects.filter(tag__in=["docs", "guides"]).search([0.3, 0.4], limit=5)
    assert fake_client.search_calls[-1] == {
        "embedding": [0.3, 0.4],
        "limit": 5,
        "score_threshold": None,
        "filters": {"tag": {"$in": ["docs", "guides"]}},
    }

    with pytest.raises(TypeError, match="expects an embedding vector"):
        vector.objects.search("deploy docs")

    with pytest.raises(ValueError, match="does not declare a field"):
        vector.objects.filter(missing="value")

    with pytest.raises(ValueError, match="is not filterable"):
        vector.objects.filter(content="deploy docs")

    with pytest.raises(TypeError, match="does not support gte lookups"):
        vector.objects.filter(source__gte="kb")


def test_vector_objects_index_requires_explicit_embedding_and_validates_fields(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Knowledge(Vector):
        alias = "knowledge"
        name = "Knowledge"
        description = "Knowledge vectors."
        dimension = 1536
        metric = Metric.COSINE
        content = TextField(required=True)
        source = StringField(required=True, filterable=True)
        tag = StringField(filterable=True)
        chunk_index = IntegerField(default=0)
        extra = JsonField()

    vector = Knowledge()
    fake_client = _FakeVectorClient()
    monkeypatch.setattr(vector, "_client", lambda: fake_client)

    vector_id = vector.objects.index(
        [0.5, 0.7],
        content="deployment guide",
        source="kb",
        tag="docs",
        extra={"title": "Deploy"},
    )
    assert vector_id == "vec-1"
    assert fake_client.upsert_calls == [
        {
            "embedding": [0.5, 0.7],
            "id": None,
            "metadata": {
                "content": "deployment guide",
                "source": "kb",
                "tag": "docs",
                "chunk_index": 0,
                "extra": {"title": "Deploy"},
            },
        }
    ]

    with pytest.raises(ValueError, match="requires field 'source'"):
        vector.objects.index([0.5, 0.7], content="deployment guide")

    with pytest.raises(TypeError, match="expects an embedding vector"):
        vector.objects.index(
            "deployment guide", content="deployment guide", source="kb"
        )

    with pytest.raises(ValueError, match="undeclared fields: unknown"):
        vector.objects.index(
            [0.1, 0.2], content="deployment guide", source="kb", unknown=True
        )


def test_vector_query_count_uses_filtered_stats(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Knowledge(Vector):
        alias = "knowledge"
        name = "Knowledge"
        description = "Knowledge vectors."
        dimension = 1536
        metric = Metric.COSINE
        content = TextField(required=True)
        source = StringField(filterable=True)

    vector = Knowledge()
    fake_client = _FakeVectorClient()
    monkeypatch.setattr(vector, "_client", lambda: fake_client)

    assert vector.objects.filter(source="docs").count() == 7
    assert fake_client.stats_calls == [{"filters": {"source": "docs"}}]
