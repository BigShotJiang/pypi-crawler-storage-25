"""Tests for fine-tune schema and bundle helpers."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aimp_sdk.tuning import load_tuning_schema_class  # noqa: E402
from aimp_sdk.tuning import load_model_tuning_contract  # noqa: E402
from aimp_sdk.tuning import load_tuning_schema_contract  # noqa: E402
from aimp_sdk.tuning import ArtifactDescriptor  # noqa: E402
from aimp_sdk.tuning import JsonArtifact  # noqa: E402
from aimp_sdk.tuning import Metric  # noqa: E402
from aimp_sdk.tuning import TuneArtifacts  # noqa: E402
from aimp_sdk.tuning import TuneMetrics  # noqa: E402
from aimp_sdk.tuning import TuneResult  # noqa: E402
from aimp_sdk.tuning import open_tuning_session  # noqa: E402
from aimp_sdk.runtime import ProcessContext  # noqa: E402
from aimp_sdk.runtime import RuntimeContext  # noqa: E402
from aimp_sdk.tuning_data import TuningBundleError  # noqa: E402
from aimp_sdk.tuning_data import build_tuning_dataset_bundle  # noqa: E402
from aimp_sdk.tuning_data import load_tuning_dataset_bundle  # noqa: E402


TEMPLATE_ROOT = (
    Path(__file__).resolve().parents[2]
    / "framework"
    / "aimp_framework"
    / "test_templates"
    / "sdk_tuning_fixture"
)


def _render_template(name: str, **values: str) -> str:
    return (TEMPLATE_ROOT / name).read_text(encoding="utf-8").format(**values)


def _write_model_tuning_fixture(
    tmp_path: Path,
    *,
    include_dataset_schema: bool = True,
    include_artifacts_schema: bool = True,
    include_metrics_schema: bool = True,
) -> Path:
    project_dir = tmp_path / "project"
    core_dir = project_dir / "internal"
    tuning_dir = project_dir / "tuning"
    core_dir.mkdir(parents=True)
    tuning_dir.mkdir(parents=True)
    (core_dir / "__init__.py").write_text("", encoding="utf-8")
    (tuning_dir / "__init__.py").write_text("", encoding="utf-8")
    (core_dir / "loader.py").write_text(
        _render_template("loader.py.tpl"), encoding="utf-8"
    )
    (project_dir / "main.py").write_text(
        _render_template("main.py.tpl"), encoding="utf-8"
    )
    (tuning_dir / "dataset.py").write_text(
        _render_template("dataset.py.tpl"),
        encoding="utf-8",
    )
    (tuning_dir / "hyperparams.py").write_text(
        _render_template("hyperparams.py.tpl"),
        encoding="utf-8",
    )
    (tuning_dir / "artifacts.py").write_text(
        _render_template("artifacts.py.tpl"),
        encoding="utf-8",
    )
    (tuning_dir / "metrics.py").write_text(
        _render_template("metrics.py.tpl"),
        encoding="utf-8",
    )
    runner_source = _render_template("runner.py.tpl")
    if not include_dataset_schema:
        runner_source = runner_source.replace("    dataset_schema = DemoSchema\n", "")
    if not include_artifacts_schema:
        runner_source = runner_source.replace(
            "    artifacts_schema = DemoArtifacts\n", ""
        )
    if not include_metrics_schema:
        runner_source = runner_source.replace("    metrics_schema = DemoMetrics\n", "")
    (tuning_dir / "runner.py").write_text(runner_source, encoding="utf-8")
    return project_dir


class _TestArtifacts(TuneArtifacts):
    result = JsonArtifact(required=True)


class _TestMetrics(TuneMetrics):
    validation_loss = Metric(goal="minimize")


def test_load_tuning_schema_contract_from_module(tmp_path: Path) -> None:
    module_path = tmp_path / "schema.py"
    module_path.write_text(_render_template("clip_schema.py.tpl"), encoding="utf-8")

    contract = load_tuning_schema_contract(str(module_path))

    assert list(contract) == ["fields"]
    assert contract["fields"] == [
        {
            "key": "query_image",
            "type": "image",
            "required": True,
            "description": "query",
            "multiple": False,
        },
        {
            "key": "reference_audio",
            "type": "audio",
            "required": False,
            "description": "audio",
            "multiple": False,
        },
        {
            "key": "clip",
            "type": "video",
            "required": False,
            "description": "video",
            "multiple": False,
        },
        {
            "key": "caption",
            "type": "text",
            "required": False,
            "description": None,
            "multiple": False,
        },
    ]


def test_build_and_load_tuning_dataset_bundle(tmp_path: Path) -> None:
    query_image = tmp_path / "query.jpg"
    candidate_image = tmp_path / "candidate.jpg"
    query_image.write_bytes(b"query")
    candidate_image.write_bytes(b"candidate")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "query_image": "query.jpg",
                        "candidate_image": "candidate.jpg",
                        "caption": "pair",
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    schema_contract = {
        "fields": [
            {
                "key": "query_image",
                "type": "image",
                "required": True,
                "multiple": False,
            },
            {
                "key": "candidate_image",
                "type": "image",
                "required": True,
                "multiple": False,
            },
            {"key": "caption", "type": "text", "required": False, "multiple": False},
        ],
    }

    payload = build_tuning_dataset_bundle(
        schema_contract=schema_contract,
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    loaded = load_tuning_dataset_bundle(output_path)
    try:
        assert loaded.manifest["schema"] == schema_contract
        assert loaded.manifest["bundle_format"] == "aimp_tuning_bundle_v1"
        assert isinstance(loaded.manifest["schema_fingerprint"], str)
        assert len(loaded.manifest["schema_fingerprint"]) == 64
        assert loaded.dataset.num_rows == 1
        row = loaded.dataset[0]
        assert loaded.resolve_path(row["query_image"]).read_bytes() == b"query"
        assert loaded.resolve_path(row["candidate_image"]).read_bytes() == b"candidate"
        assert row["caption"] == "pair"
    finally:
        loaded.cleanup()


def test_build_tuning_dataset_bundle_runs_field_preprocessors_and_validators(
    tmp_path: Path,
) -> None:
    schema_module = tmp_path / "schema.py"
    schema_module.write_text(
        _render_template("preprocess_schema.py.tpl"), encoding="utf-8"
    )
    (tmp_path / "one.png").write_bytes(b"one")
    (tmp_path / "two.png").write_bytes(b"two")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "gallery": ["one.png", "two.png"],
                        "caption": "  ready  ",
                        "metadata": {"label": "positive"},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    schema_cls = load_tuning_schema_class(str(schema_module))

    payload = build_tuning_dataset_bundle(
        schema_contract=schema_cls.contract(),
        bundle_path=bundle_path,
        schema_cls=schema_cls,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    loaded = load_tuning_dataset_bundle(output_path)
    try:
        row = loaded.dataset[0]
        assert row["caption"] == "ready"
        assert json.loads(row["metadata"]) == {
            "label": "positive",
            "source": "sdk-test",
        }
        assert len(row["gallery"]) == 2
    finally:
        loaded.cleanup()


def test_build_tuning_dataset_bundle_rejects_post_preprocess_type_mismatch(
    tmp_path: Path,
) -> None:
    schema_module = tmp_path / "schema.py"
    schema_module.write_text(
        _render_template("type_mismatch_schema.py.tpl"), encoding="utf-8"
    )
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"caption": "hello"}]}),
        encoding="utf-8",
    )
    schema_cls = load_tuning_schema_class(str(schema_module))

    with pytest.raises(
        TuningBundleError, match=r"Record 0 field 'caption' item 0 must be text"
    ):
        build_tuning_dataset_bundle(
            schema_contract=schema_cls.contract(),
            bundle_path=bundle_path,
            schema_cls=schema_cls,
        )


def test_build_tuning_dataset_bundle_surfaces_item_index_for_multiple_validator_failures(
    tmp_path: Path,
) -> None:
    schema_module = tmp_path / "schema.py"
    schema_module.write_text(
        _render_template("image_validator_schema.py.tpl"),
        encoding="utf-8",
    )
    (tmp_path / "good.png").write_bytes(b"png")
    (tmp_path / "bad.jpg").write_bytes(b"jpg")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"gallery": ["good.png", "bad.jpg"]}]}),
        encoding="utf-8",
    )
    schema_cls = load_tuning_schema_class(str(schema_module))

    with pytest.raises(
        TuningBundleError,
        match=r"Record 0 field 'gallery' item 1 validation failed: Only PNG files are allowed",
    ):
        build_tuning_dataset_bundle(
            schema_contract=schema_cls.contract(),
            bundle_path=bundle_path,
            schema_cls=schema_cls,
        )


def test_schema_fingerprint_is_stable_and_changes_with_schema(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"input": {"prompt": "hello"}}]}),
        encoding="utf-8",
    )
    base_schema = {
        "fields": [
            {"key": "input", "type": "json", "required": True, "multiple": False}
        ],
    }
    changed_schema = {
        "fields": [
            {"key": "input", "type": "json", "required": False, "multiple": False}
        ],
    }

    first = build_tuning_dataset_bundle(
        schema_contract=base_schema, bundle_path=bundle_path
    )
    second = build_tuning_dataset_bundle(
        schema_contract=base_schema, bundle_path=bundle_path
    )
    third = build_tuning_dataset_bundle(
        schema_contract=changed_schema, bundle_path=bundle_path
    )

    def manifest_for(payload_name: str, payload: object) -> dict[str, object]:
        output_path = tmp_path / payload_name
        with output_path.open("wb") as handle:
            payload.stream.seek(0)
            handle.write(payload.stream.read())
        loaded = load_tuning_dataset_bundle(output_path)
        try:
            return dict(loaded.manifest)
        finally:
            loaded.cleanup()

    first_manifest = manifest_for("first.zip", first)
    second_manifest = manifest_for("second.zip", second)
    third_manifest = manifest_for("third.zip", third)

    assert first_manifest["schema_fingerprint"] == second_manifest["schema_fingerprint"]
    assert first_manifest["schema_fingerprint"] != third_manifest["schema_fingerprint"]


def test_open_tuning_session_requires_dataset_path() -> None:
    with pytest.raises(RuntimeError, match="dataset_path is required"):
        with open_tuning_session(
            {},
            {},
            process_context=ProcessContext(),
            runtime_context=RuntimeContext(),
            artifacts_schema=_TestArtifacts,
        ):
            raise AssertionError("context manager should not yield")


def test_open_tuning_session_requires_runtime_output_dir(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"prompt": "hello", "completion": "world"}]}),
        encoding="utf-8",
    )
    payload = build_tuning_dataset_bundle(
        schema_contract={
            "fields": [
                {"key": "prompt", "type": "text", "required": True, "multiple": False},
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "multiple": False,
                },
            ],
        },
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    with pytest.raises(RuntimeError, match="runtime-provided writable output_dir"):
        with open_tuning_session(
            {"dataset_path": str(output_path)},
            {},
            process_context=ProcessContext(),
            runtime_context=RuntimeContext(),
            artifacts_schema=_TestArtifacts,
        ):
            raise AssertionError("context manager should not yield")


def test_open_tuning_session_materializes_author_facing_views(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {"prompt": "hello", "completion": "world"},
                    {"prompt": "bye", "completion": "moon"},
                ]
            }
        ),
        encoding="utf-8",
    )
    payload = build_tuning_dataset_bundle(
        schema_contract={
            "fields": [
                {"key": "prompt", "type": "text", "required": True, "multiple": False},
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "multiple": False,
                },
            ],
        },
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    extracted_root: Path | None = None
    with open_tuning_session(
        {
            "dataset_path": str(output_path),
            "validation": {"mode": "auto_split", "ratio": 0.5},
            "trial_id": 7,
        },
        {"learning_rate": 0.01, "epochs": 3},
        process_context=ProcessContext(artifacts_dir=tmp_path / "artifacts"),
        runtime_context=RuntimeContext(
            request_id="req-1",
            cache_dir=tmp_path / "cache",
            work_dir=tmp_path / "work",
            tuning_output_dir=tmp_path / "work" / "tuning-output",
        ),
        artifacts_schema=_TestArtifacts,
    ) as tuning:
        extracted_root = tuning.resolve_path("data.parquet").parent
        assert tuning.train_dataset.num_rows == 1
        assert tuning.validation_dataset.num_rows == 1
        record = tuning.train_dataset[0]
        assert record.prompt in {"hello", "bye"}
        assert tuning.params.learning_rate == 0.01
        assert tuning.params.epochs == 3
        assert tuning.request_id == "req-1"
        assert tuning.trial_id == 7
        assert tuning.output_dir == tmp_path / "work" / "tuning-output"
        assert tuning.artifacts_dir == tmp_path / "work" / "tuning-output"
        assert extracted_root.exists()

    assert extracted_root is not None
    assert not extracted_root.exists()


def test_tune_result_rejects_invalid_metrics() -> None:
    artifacts = _TestArtifacts(
        result=ArtifactDescriptor(
            path="result.json",
            kind="json",
            sha256="0" * 64,
            size_bytes=2,
        )
    )

    with pytest.raises(ValueError, match="must extend TuneMetrics"):
        TuneResult(artifacts=artifacts, metrics={})

    with pytest.raises(ValueError, match="must be numeric"):
        _TestMetrics(validation_loss="bad")  # type: ignore[arg-type]


def test_build_tuning_dataset_bundle_rejects_unknown_fields(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"unexpected": "value"}]}), encoding="utf-8"
    )

    with pytest.raises(TuningBundleError, match="unknown fine-tune fields"):
        build_tuning_dataset_bundle(
            schema_contract={
                "fields": [
                    {
                        "key": "input",
                        "type": "json",
                        "required": True,
                        "multiple": False,
                    }
                ],
            },
            bundle_path=bundle_path,
        )


def test_tuning_session_suggest_helpers_use_defaults_and_validate(
    tmp_path: Path,
) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {"prompt": "hello", "completion": "world"},
                    {"prompt": "bye", "completion": "moon"},
                ]
            }
        ),
        encoding="utf-8",
    )
    payload = build_tuning_dataset_bundle(
        schema_contract={
            "fields": [
                {"key": "prompt", "type": "text", "required": True, "multiple": False},
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "multiple": False,
                },
            ],
        },
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    with open_tuning_session(
        {
            "dataset_path": str(output_path),
            "validation": {"mode": "auto_split", "ratio": 0.5},
        },
        {"learning_rate": 0.02, "epochs": 4, "batch_size": 32},
        process_context=ProcessContext(artifacts_dir=tmp_path / "artifacts"),
        runtime_context=RuntimeContext(
            work_dir=tmp_path / "runtime-work",
            tuning_output_dir=tmp_path / "runtime-work" / "tuning-output",
        ),
        artifacts_schema=_TestArtifacts,
    ) as session:
        assert session.output_dir == tmp_path / "runtime-work" / "tuning-output"
        assert session.artifacts_dir == tmp_path / "runtime-work" / "tuning-output"
        assert session.suggest_float("learning_rate", 0.001, 0.1, default=0.01) == 0.02
        assert session.suggest_int("epochs", 1, 10, default=3) == 4
        assert session.suggest_categorical("batch_size", [8, 16, 32], default=16) == 32
        assert session.suggest_int("missing_epochs", 1, 10, default=3) == 3

        with pytest.raises(RuntimeError, match="must be between"):
            session.suggest_float("learning_rate", 0.03, 0.1, default=0.05)

        with pytest.raises(RuntimeError, match="not one of"):
            session.suggest_categorical("batch_size", [8, 16], default=8)


def test_load_model_tuning_contract_requires_model_scoped_runner_metadata(
    tmp_path: Path,
) -> None:
    project_dir = _write_model_tuning_fixture(tmp_path)

    contract = load_model_tuning_contract(
        str(project_dir / "main.py"), model_key="demo_model"
    )
    assert contract["model_key"] == "demo_model"
    assert contract["schema"]["fields"][0]["key"] == "prompt"
    assert contract["artifacts"]["fields"][0]["key"] == "result"
    assert contract["metrics"]["fields"][0]["key"] == "validation_loss"
    assert contract["materialization"] == {
        "strategy": "replace_root",
        "result_kind": "root_bundle",
        "required_artifacts": ["result"],
        "chaining": "replace",
    }
    assert contract["supports_chaining"] is True
    assert list(contract) == [
        "supported",
        "model_key",
        "schema",
        "artifacts",
        "metrics",
        "materialization",
        "supports_chaining",
        "parameters",
    ]


def test_load_model_tuning_contract_fails_when_artifacts_schema_missing(
    tmp_path: Path,
) -> None:
    project_dir = _write_model_tuning_fixture(
        tmp_path,
        include_artifacts_schema=False,
    )

    with pytest.raises(RuntimeError, match="must declare artifacts_schema"):
        load_model_tuning_contract(str(project_dir / "main.py"), model_key="demo_model")


def test_load_model_tuning_contract_fails_when_dataset_schema_missing(
    tmp_path: Path,
) -> None:
    project_dir = _write_model_tuning_fixture(
        tmp_path,
        include_dataset_schema=False,
    )

    with pytest.raises(RuntimeError, match="must declare dataset_schema"):
        load_model_tuning_contract(str(project_dir / "main.py"), model_key="demo_model")


def test_load_model_tuning_contract_fails_when_metrics_schema_missing(
    tmp_path: Path,
) -> None:
    project_dir = _write_model_tuning_fixture(
        tmp_path,
        include_metrics_schema=False,
    )

    with pytest.raises(RuntimeError, match="must declare metrics_schema"):
        load_model_tuning_contract(str(project_dir / "main.py"), model_key="demo_model")
