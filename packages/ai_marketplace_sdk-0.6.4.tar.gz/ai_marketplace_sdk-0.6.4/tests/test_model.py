"""Tests for SDK model runtime behaviors."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk.model import Model  # noqa: E402
from aimp_sdk.model import ModelError  # noqa: E402
from aimp_sdk.runtime import RuntimeContext  # noqa: E402


class _NoopEngine:
    def load(self) -> None:
        self.loaded = True


class _AdapterEngine:
    def __init__(self) -> None:
        self.applied: list[tuple[str, str]] = []

    def load(self) -> None:
        self.loaded = True

    def apply_adapter(self, adapter_path: str, adapter_name: str) -> None:
        self.applied.append((adapter_path, adapter_name))


class _NoAdapterSupportEngine:
    def load(self) -> None:
        self.loaded = True


class _AdapterModel(Model):
    engine = _AdapterEngine


class _NoAdapterModel(Model):
    engine = _NoAdapterSupportEngine


def test_model_applies_composition_adapters_in_deterministic_order() -> None:
    adapter_a = Path("/tmp/adapters/adapter-a")
    adapter_b = Path("/tmp/adapters/adapter-b")
    adapter_a.mkdir(parents=True, exist_ok=True)
    adapter_b.mkdir(parents=True, exist_ok=True)
    model = _AdapterModel()
    model.context = RuntimeContext(
        artifacts_dir=Path("/tmp/artifacts"),
        composition_manifest={
            "adapters": [
                {
                    "slug": "adapter-a",
                    "artifact": {"uri": "s3://bucket/adapter-a.tar.gz"},
                },
                {
                    "slug": "adapter-b",
                    "artifact": {"uri": "s3://bucket/adapter-b.tar.gz"},
                },
            ]
        },
    )

    engine = model.engine_instance()

    assert engine.applied == [
        ("/tmp/adapters/adapter-a", "adapter_0"),
        ("/tmp/adapters/adapter-b", "adapter_1"),
    ]


def test_model_fails_when_adapters_exist_and_engine_cannot_apply() -> None:
    adapter_a = Path("/tmp/adapters/adapter-a")
    adapter_a.mkdir(parents=True, exist_ok=True)
    model = _NoAdapterModel()
    model.context = RuntimeContext(
        artifacts_dir=Path("/tmp/artifacts"),
        composition_manifest={
            "adapters": [
                {
                    "slug": "adapter-a",
                    "artifact": {"uri": "s3://bucket/adapter-a.tar.gz"},
                }
            ]
        },
    )

    with pytest.raises(ModelError, match="must implement apply_adapter"):
        model.engine_instance()


def test_model_skips_adapter_application_when_none_present() -> None:
    model = _AdapterModel()
    model.context = RuntimeContext(composition_manifest={"adapters": []})

    engine = model.engine_instance()

    assert engine.applied == []


def test_model_fails_when_adapter_slug_missing() -> None:
    model = _AdapterModel()
    model.context = RuntimeContext(
        artifacts_dir=Path("/tmp/artifacts"),
        composition_manifest={
            "adapters": [
                {"artifact": {"uri": "s3://bucket/adapter-a.tar.gz"}},
            ]
        },
    )

    with pytest.raises(ModelError, match="slug is required"):
        model.engine_instance()
