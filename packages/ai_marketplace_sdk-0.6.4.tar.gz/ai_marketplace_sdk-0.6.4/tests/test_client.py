"""Tests for SDK client."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest
from datasets import Dataset

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

import aimp_sdk.client as client_module  # noqa: E402
from aimp_sdk.client import Client  # noqa: E402
from aimp_sdk.client import ClientError  # noqa: E402
from aimp_sdk.client import FineTuneJob  # noqa: E402
from aimp_sdk.client import EvaluationJobError  # noqa: E402
from aimp_sdk.client import FineTuneJobError  # noqa: E402


def test_client_requires_api_key() -> None:
    with pytest.raises(Exception):
        Client(api_key="", base_url="http://gateway")


def test_models_execute_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    captured: dict[str, object] = {}

    def fake_post_json(path: str, payload: dict, request_id: str) -> dict:
        captured["path"] = path
        captured["payload"] = payload
        return {"ok": True}

    monkeypatch.setattr(client, "_post_json", fake_post_json)

    result = client.models.execute(model="model-1", input={"text": "hi"}, parameters={"x": 1})
    assert result == {"ok": True}
    assert captured["path"] == "/api/runs"
    assert captured["payload"]["model"] == "model-1"
    assert captured["payload"]["mode"] == "execute"
    assert captured["payload"]["input"] == {"text": "hi"}
    assert captured["payload"]["params"] == {"x": 1}
    assert "fine_tune_job_id" not in captured["payload"]


def test_models_execute_payload_allows_mode_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    captured: dict[str, object] = {}

    def fake_post_json(path: str, payload: dict, request_id: str) -> dict:
        captured["path"] = path
        captured["payload"] = payload
        return {"ok": True}

    monkeypatch.setattr(client, "_post_json", fake_post_json)

    result = client.models.execute(
        model="model-1",
        input={"text": "hi"},
        mode="search",
    )
    assert result == {"ok": True}
    assert captured["path"] == "/api/runs"
    assert captured["payload"]["mode"] == "search"


def test_fine_tune_is_disabled() -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    dataset = Dataset.from_dict({"prompt": ["hi"], "completion": ["there"]})
    with pytest.raises(ClientError, match="create_fine_tune_job"):
        client.fine_tune(model="llama", dataset=dataset)


def test_create_fine_tune_job_uses_jobs_api(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    captured: dict[str, object] = {}

    def fake_post_json(path: str, payload: dict, request_id: str) -> dict:
        captured["path"] = path
        captured["payload"] = payload
        return {
            "id": "ft-1",
            "type": "fine-tune",
            "model_slug": "vision-pro",
            "status": "queued",
            "details": {
                "adapter_format": "lora",
                "output_asset_id": "asset-1",
                "output_asset_slug": "vision-pro-tuned",
            },
        }

    monkeypatch.setattr(client, "_post_json", fake_post_json)

    job = client.create_fine_tune_job(
        model="vision-pro",
        dataset_ref="s3://datasets/vision-pro/bundle.zip",
        max_trials=5,
    )

    assert captured["path"] == "/api/jobs/fine-tune"
    assert captured["payload"] == {
        "model": "vision-pro",
        "input": {
            "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
            "budget": {"max_trials": 5},
        },
    }
    assert job.id == "ft-1"
    assert job.status == "queued"
    assert job.tuned_model_id == "asset-1"
    assert job.tuned_model_slug == "vision-pro-tuned"


def test_fine_tune_job_refresh(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)

    def fake_get_json(path: str, request_id: str) -> dict:
        assert path == "/api/jobs/job-1"
        return {
            "id": "job-1",
            "type": "fine-tune",
            "model_slug": "vision-pro",
            "status": "running",
            "details": {
                "adapter_format": "lora",
                "output_asset_id": "asset-1",
                "output_asset_slug": "vision-pro-tuned",
            },
        }

    monkeypatch.setattr(client, "_get_json", fake_get_json)

    job = client.fine_tune_job(job_id="job-1")
    assert job.id == "job-1"
    assert job.status == "running"
    assert job.tuned_model_id == "asset-1"
    assert job.tuned_model_slug == "vision-pro-tuned"


def test_list_fine_tune_jobs(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)

    def fake_get_json(path: str, request_id: str) -> dict:
        assert path.startswith("/api/jobs?")
        assert "type=fine-tune" in path
        assert "model_slug=vision-pro" in path
        assert "status=running" in path
        assert "page=2" in path
        assert "page_size=50" in path
        return {
            "results": [
                {
                    "id": "ft-1",
                    "type": "fine-tune",
                    "model_slug": "vision-pro",
                    "status": "running",
                    "details": {
                        "adapter_format": "lora",
                        "output_asset_id": "asset-1",
                        "output_asset_slug": "vision-pro-tuned",
                    },
                }
            ],
            "pagination": {"total_items": 1},
        }

    monkeypatch.setattr(client, "_get_json", fake_get_json)

    response = client.list_fine_tune_jobs(
        model_slug="vision-pro",
        status="running",
        page=2,
        page_size=50,
    )
    assert response["results"][0]["job_id"] == "ft-1"
    assert response["results"][0]["output_asset_id"] == "asset-1"
    assert response["results"][0]["output_asset_slug"] == "vision-pro-tuned"
    assert response["pagination"]["total_items"] == 1


def test_fine_tune_job_wait_for_completion(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    job = FineTuneJob(client=client, id="job-1")

    responses = [
        {"id": "job-1", "type": "fine-tune", "model_slug": "vision-pro", "status": "queued"},
        {"id": "job-1", "type": "fine-tune", "model_slug": "vision-pro", "status": "running"},
        {
            "id": "job-1",
            "type": "fine-tune",
            "model_slug": "vision-pro",
            "status": "succeeded",
            "output_asset_id": "model-123",
            "output_asset_slug": "model-123-adapter-u1-1",
            "adapter_format": "lora",
        },
    ]

    def fake_get_json(path: str, request_id: str) -> dict:
        return responses.pop(0)

    monkeypatch.setattr(client, "_get_json", fake_get_json)

    completed = job.wait_for_completion(poll_interval_seconds=0)
    assert completed.status == "succeeded"
    assert completed.tuned_model_id == "model-123"
    assert completed.tuned_model_slug == "model-123-adapter-u1-1"


def test_fine_tune_job_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    job = FineTuneJob(client=client, id="job-1")

    def fake_get_json(path: str, request_id: str) -> dict:
        return {"status": "failed", "error_code": "ERR", "error_message": "Boom"}

    monkeypatch.setattr(client, "_get_json", fake_get_json)

    with pytest.raises(FineTuneJobError):
        job.wait_for_completion(poll_interval_seconds=0)


def test_models_evaluate(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    dataset = Dataset.from_dict({"prompt": ["hi"], "completion": ["there"]})

    def fake_upload_dataset_stream(_client, _payload):
        return "dataset-1"

    def fake_post_json(path: str, payload: dict, request_id: str) -> dict:
        assert path == "/api/models/model-1/evaluate"
        assert payload == {"dataset_id": "dataset-1"}
        return {"evaluation_job_id": "eval-1"}

    responses = [
        {"status": "running"},
        {
            "status": "succeeded",
            "metric_name": "accuracy",
            "metric_value": 0.9,
            "objective_direction": "maximize",
            "metadata": {"k": "v"},
        },
    ]

    def fake_get_json(path: str, request_id: str) -> dict:
        return responses.pop(0)

    monkeypatch.setattr(client_module, "upload_dataset_stream", fake_upload_dataset_stream)
    monkeypatch.setattr(client, "_post_json", fake_post_json)
    monkeypatch.setattr(client, "_get_json", fake_get_json)

    result = client.models.evaluate(model="model-1", dataset=dataset)
    assert result["metric_name"] == "accuracy"
    assert result["metric_value"] == 0.9
    assert result["direction"] == "maximize"
    assert result["metadata"] == {"k": "v"}


def test_models_evaluate_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    dataset = Dataset.from_dict({"prompt": ["hi"], "completion": ["there"]})

    def fake_upload_dataset_stream(_client, _payload):
        return "dataset-1"

    def fake_post_json(path: str, payload: dict, request_id: str) -> dict:
        return {"evaluation_job_id": "eval-1"}

    def fake_get_json(path: str, request_id: str) -> dict:
        return {"status": "failed", "error_code": "EVAL_FAIL", "error_message": "Boom"}

    monkeypatch.setattr(client_module, "upload_dataset_stream", fake_upload_dataset_stream)
    monkeypatch.setattr(client, "_post_json", fake_post_json)
    monkeypatch.setattr(client, "_get_json", fake_get_json)

    with pytest.raises(EvaluationJobError):
        client.models.evaluate(model="model-1", dataset=dataset)


def test_wait_for_evaluation_retries_on_rate_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    calls = {"count": 0}

    def fake_get_json(path: str, request_id: str) -> dict:
        calls["count"] += 1
        if calls["count"] == 1:
            raise ClientError("rate limit", status_code=429)
        return {
            "status": "succeeded",
            "metric_name": "accuracy",
            "metric_value": 0.9,
            "objective_direction": "maximize",
            "metadata": {},
        }

    monkeypatch.setattr(client, "_get_json", fake_get_json)
    monkeypatch.setattr("aimp_sdk.client.time.sleep", lambda _s: None)

    result = client._wait_for_evaluation("job-1", poll_interval_seconds=0)
    assert result["metric_name"] == "accuracy"
    assert calls["count"] == 2


def test_fine_tune_wait_retries_on_rate_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)
    job = FineTuneJob(client=client, id="job-1")
    calls = {"count": 0}

    def fake_get_json(path: str, request_id: str) -> dict:
        calls["count"] += 1
        if calls["count"] == 1:
            raise ClientError("rate limit", status_code=429)
        return {"status": "succeeded", "output_asset": "model-123"}

    monkeypatch.setattr(client, "_get_json", fake_get_json)
    monkeypatch.setattr("aimp_sdk.client.time.sleep", lambda _s: None)

    job.wait_for_completion(poll_interval_seconds=0)
    assert calls["count"] == 2
