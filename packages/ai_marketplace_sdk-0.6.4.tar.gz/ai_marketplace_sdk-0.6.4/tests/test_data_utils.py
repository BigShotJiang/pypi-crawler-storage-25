"""Tests for dataset utilities."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
import hashlib
import sys
import urllib.error
import zipfile

import pytest
from datasets import Dataset

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk.data_utils import DatasetPayload  # noqa: E402
from aimp_sdk.data_utils import serialize_dataset  # noqa: E402
from aimp_sdk.data_utils import upload_dataset_stream  # noqa: E402
from aimp_sdk.client import Client  # noqa: E402


class FakeResponse:
    """Fake response object for urlopen."""

    def __init__(self, headers: dict[str, str]) -> None:
        self.headers = headers

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False


def test_serialize_dataset_creates_zip() -> None:
    dataset = Dataset.from_dict({"prompt": ["hi"], "completion": ["there"]})
    payload = serialize_dataset(dataset)

    assert payload.size_bytes > 0
    assert len(payload.sha256) == 64
    assert payload.file_name == "dataset.zip"
    assert payload.content_type == "application/zip"

    payload.stream.seek(0)
    with zipfile.ZipFile(payload.stream) as zf:
        assert "data.parquet" in zf.namelist()
        with zf.open("data.parquet") as parquet_file:
            parquet_bytes = parquet_file.read()
            assert len(parquet_bytes) > 0

    payload.stream.seek(0)
    sha256 = hashlib.sha256(payload.stream.read()).hexdigest()
    assert sha256 == payload.sha256


def test_upload_dataset_stream_multipart(monkeypatch: pytest.MonkeyPatch) -> None:
    data = b"abcdefghij"
    payload = DatasetPayload(
        stream=BytesIO(data),
        size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        file_name="dataset.zip",
        content_type="application/zip",
    )

    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)

    calls: list[tuple[str, dict]] = []

    def fake_post_json(path: str, payload_in: dict, request_id: str) -> dict:
        calls.append((path, payload_in))
        if path.endswith("/upload/init"):
            return {
                "upload_id": "upload-1",
                "parts": [
                    {
                        "part_number": 1,
                        "url": "http://upload/part1",
                        "size_bytes": 5,
                        "headers": {"Content-Length": "5"},
                    },
                    {
                        "part_number": 2,
                        "url": "http://upload/part2",
                        "size_bytes": 5,
                        "headers": {"Content-Length": "5"},
                    },
                ],
            }
        return {"dataset_id": "dataset-123"}

    uploaded_sizes: list[int] = []

    def fake_urlopen(request, timeout=1):
        uploaded_sizes.append(len(request.data or b""))
        return FakeResponse({"ETag": "etag-value"})

    monkeypatch.setattr(client, "_post_json", fake_post_json)
    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

    dataset_id = upload_dataset_stream(client, payload)

    assert dataset_id == "dataset-123"
    assert uploaded_sizes == [5, 5]
    assert calls[0][0].endswith("/upload/init")
    assert calls[1][0].endswith("/upload/complete")
    assert calls[1][1]["upload_id"] == "upload-1"
    assert len(calls[1][1]["parts"]) == 2


def test_upload_dataset_stream_retries(monkeypatch: pytest.MonkeyPatch) -> None:
    data = b"abcdef"
    payload = DatasetPayload(
        stream=BytesIO(data),
        size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        file_name="dataset.zip",
        content_type="application/zip",
    )

    client = Client(api_key="key", base_url="http://gateway", timeout_seconds=1)

    def fake_post_json(path: str, payload_in: dict, request_id: str) -> dict:
        if path.endswith("/upload/init"):
            return {
                "upload_id": "upload-2",
                "parts": [
                    {
                        "part_number": 1,
                        "url": "http://upload/part1",
                        "size_bytes": 6,
                        "headers": {"Content-Length": "6"},
                    }
                ],
            }
        return {"dataset_id": "dataset-456"}

    attempts = {"count": 0}

    def flaky_urlopen(request, timeout=1):
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise urllib.error.URLError("network")
        return FakeResponse({"ETag": "etag-value"})

    monkeypatch.setattr(client, "_post_json", fake_post_json)
    monkeypatch.setattr("urllib.request.urlopen", flaky_urlopen)
    monkeypatch.setattr("aimp_sdk.data_utils.time.sleep", lambda _: None)

    dataset_id = upload_dataset_stream(client, payload)
    assert dataset_id == "dataset-456"
    assert attempts["count"] == 2
