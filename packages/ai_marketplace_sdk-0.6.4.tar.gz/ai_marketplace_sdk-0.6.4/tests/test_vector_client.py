"""Tests for VectorClient."""

from __future__ import annotations

from pathlib import Path
import json
import sys

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk.vector import VectorClient  # noqa: E402
from aimp_sdk.vector import VectorSearchResult  # noqa: E402
from aimp_sdk.runtime import RuntimeContext  # noqa: E402
from aimp_sdk.runtime import VectorExecutionContext  # noqa: E402
from aimp_sdk.runtime import reset_current_execution_context  # noqa: E402
from aimp_sdk.runtime import set_current_execution_context  # noqa: E402


def test_vector_client_env_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIMP_GATEWAY_URL", "http://gateway")
    monkeypatch.setenv("AIMP_EXECUTION_TOKEN", "token")
    monkeypatch.setenv(
        "AIMP_VECTOR_RESOURCES",
        json.dumps(
            [
                {
                    "alias": "kb",
                    "asset_id": "asset-1",
                    "namespace": "customer_123",
                }
            ]
        ),
    )
    monkeypatch.setenv("AIMP_MODEL_ID", "model")
    client = VectorClient()
    assert client.gateway_url == "http://gateway"
    assert client.execution_token == "token"
    assert client.resource["alias"] == "kb"
    assert client.model_id == "model"


def test_vector_client_add_sends_collection(monkeypatch: pytest.MonkeyPatch) -> None:
    client = VectorClient(
        gateway_url="http://gateway",
        execution_token="token",
        resource_alias="kb",
        model_id="model",
        vector_resources=[
            {
                "alias": "kb",
                "asset_id": "asset-1",
                "namespace": "customer_123",
            }
        ],
        timeout_seconds=1,
    )
    captured: dict[str, object] = {}

    def fake_request(path: str, payload: dict[str, object]) -> dict[str, object]:
        captured["path"] = path
        captured["payload"] = payload
        return {"id": "vec-1"}

    monkeypatch.setattr(client, "_request", fake_request)
    result = client.add([0.1, 0.2], metadata={"tag": "x"})
    assert result == "vec-1"
    assert captured["path"] == "/v1/data/upsert"
    assert captured["payload"]["alias"] == "kb"


def test_vector_client_search_parses_results(monkeypatch: pytest.MonkeyPatch) -> None:
    client = VectorClient(
        gateway_url="http://gateway",
        execution_token="token",
        resource_alias="kb",
        model_id="model",
        vector_resources=[
            {
                "alias": "kb",
                "asset_id": "asset-1",
                "namespace": "customer_123",
            }
        ],
        timeout_seconds=1,
    )

    def fake_request(path: str, payload: dict[str, object]) -> dict[str, object]:
        return {
            "results": [
                {"id": "a", "score": 0.9, "payload": {"k": "v"}},
                {"id": "b", "score": 0.8, "payload": {}},
            ]
        }

    monkeypatch.setattr(client, "_request", fake_request)
    results = client.search([0.1, 0.2], limit=2)
    assert len(results) == 2
    assert isinstance(results[0], VectorSearchResult)
    assert results[0].id == "a"


def test_vector_client_delete_returns_count(monkeypatch: pytest.MonkeyPatch) -> None:
    client = VectorClient(
        gateway_url="http://gateway",
        execution_token="token",
        resource_alias="kb",
        model_id="model",
        vector_resources=[
            {
                "alias": "kb",
                "asset_id": "asset-1",
                "namespace": "customer_123",
            }
        ],
        timeout_seconds=1,
    )

    def fake_request(path: str, payload: dict[str, object]) -> dict[str, object]:
        return {"deleted": 2}

    monkeypatch.setattr(client, "_request", fake_request)
    deleted = client.delete(["a", "b"])
    assert deleted == 2


def test_vector_client_stats_and_count(monkeypatch: pytest.MonkeyPatch) -> None:
    client = VectorClient(
        gateway_url="http://gateway",
        execution_token="token",
        resource_alias="kb",
        model_id="model",
        vector_resources=[
            {
                "alias": "kb",
                "asset_id": "asset-1",
                "namespace": "customer_123",
            }
        ],
        timeout_seconds=1,
    )
    captured: dict[str, object] = {}

    def fake_request(path: str, payload: dict[str, object]) -> dict[str, object]:
        captured["path"] = path
        captured["payload"] = payload
        return {"vector_count": 12}

    monkeypatch.setattr(client, "_request", fake_request)
    assert client.stats() == {"vector_count": 12}
    assert client.count(filters={"tag": "docs"}) == 12
    assert captured["path"] == "/v1/data/stats"
    assert captured["payload"]["alias"] == "kb"
    assert captured["payload"]["filters"] == {"tag": "docs"}


def test_vector_client_requires_model_id(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIMP_GATEWAY_URL", "http://gateway")
    monkeypatch.setenv("AIMP_EXECUTION_TOKEN", "token")
    monkeypatch.setenv(
        "AIMP_VECTOR_RESOURCES",
        json.dumps(
            [
                {
                    "alias": "kb",
                    "asset_id": "asset-1",
                    "namespace": "customer_123",
                }
            ]
        ),
    )
    monkeypatch.delenv("AIMP_MODEL_ID", raising=False)
    from aimp_sdk.vector import VectorClientError  # noqa: E402

    with pytest.raises(VectorClientError, match="Missing AIMP_MODEL_ID"):
        VectorClient()


def test_vector_client_prefers_request_scoped_context(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AIMP_GATEWAY_URL", "http://stale-gateway")
    monkeypatch.setenv("AIMP_EXECUTION_TOKEN", "stale-token")
    monkeypatch.setenv("AIMP_MODEL_ID", "stale-model")
    monkeypatch.setenv("AIMP_VECTOR_RESOURCES", json.dumps([{"alias": "stale"}]))

    runtime_context = RuntimeContext(
        model_id="request-model", mode="search", request_id="req-123"
    )
    vector_context = VectorExecutionContext(
        gateway_url="http://request-gateway",
        execution_token="request-token",
        model_id="request-model",
        vector_resources=(
            {
                "alias": "kb",
                "asset_id": "asset-1",
            },
        ),
        timeout_seconds=3.5,
        request_id="req-123",
    )
    tokens = set_current_execution_context(runtime_context, vector_context)
    try:
        client = VectorClient()
    finally:
        reset_current_execution_context(tokens)

    assert client.gateway_url == "http://request-gateway"
    assert client.execution_token == "request-token"
    assert client.model_id == "request-model"
    assert client.resource["alias"] == "kb"
    assert client.request_id == "req-123"


def test_vector_client_multiple_resources_require_alias_selection() -> None:
    from aimp_sdk.vector import VectorClientError

    with pytest.raises(VectorClientError, match="Multiple vector resources available"):
        VectorClient(
            gateway_url="http://gateway",
            execution_token="token",
            model_id="model",
            vector_resources=[
                {
                    "alias": "kb",
                    "asset_id": "asset-1",
                    "namespace": "myapp.knowledge",
                },
                {
                    "alias": "ctx",
                    "asset_id": "asset-2",
                    "namespace": "myapp.context",
                },
            ],
            timeout_seconds=1,
        )


def test_vector_client_single_resource_without_space_works() -> None:
    client = VectorClient(
        gateway_url="http://gateway",
        execution_token="token",
        model_id="model",
        vector_resources=[
            {
                "alias": "kb",
                "asset_id": "asset-1",
                "namespace": "customer_123",
            }
        ],
        timeout_seconds=1,
    )
    assert client.resource["alias"] == "kb"


def test_vector_client_alias_selects_one_of_multiple_resources() -> None:
    client = VectorClient(
        gateway_url="http://gateway",
        execution_token="token",
        resource_alias="ctx",
        model_id="model",
        vector_resources=[
            {
                "alias": "kb",
                "asset_id": "asset-1",
                "namespace": "myapp.knowledge",
            },
            {
                "alias": "ctx",
                "asset_id": "asset-2",
                "namespace": "myapp.context",
            },
        ],
        timeout_seconds=1,
    )
    assert client.resource["alias"] == "ctx"


def test_vector_client_reports_requested_and_available_aliases() -> None:
    from aimp_sdk.vector import VectorClientError

    with pytest.raises(
        VectorClientError,
        match="Requested VectorClient resource_alias 'documents' is not available. Available: ctx, kb",
    ):
        VectorClient(
            gateway_url="http://gateway",
            execution_token="token",
            resource_alias="documents",
            model_id="model",
            vector_resources=[
                {
                    "alias": "kb",
                    "asset_id": "asset-1",
                    "namespace": "myapp.knowledge",
                },
                {
                    "alias": "ctx",
                    "asset_id": "asset-2",
                    "namespace": "myapp.context",
                },
            ],
            timeout_seconds=1,
        )
