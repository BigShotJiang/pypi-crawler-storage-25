"""Tests for lightweight top-level SDK imports."""

from __future__ import annotations

from pathlib import Path
import sys

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))


def test_import_aimp_sdk_does_not_eagerly_load_tuning_data() -> None:
    sys.modules.pop("aimp_sdk", None)
    sys.modules.pop("aimp_sdk.tuning_data", None)
    import aimp_sdk

    assert "aimp_sdk.tuning_data" not in sys.modules
    assert hasattr(aimp_sdk, "Model")
    assert hasattr(aimp_sdk, "TuneResult")
    assert hasattr(aimp_sdk, "TuningSession")
    assert hasattr(aimp_sdk, "VectorClient")


def test_accessing_tuning_bundle_export_loads_tuning_data() -> None:
    sys.modules.pop("aimp_sdk", None)
    sys.modules.pop("aimp_sdk.tuning_data", None)
    import aimp_sdk

    assert "aimp_sdk.tuning_data" not in sys.modules
    bundle_loader = aimp_sdk.load_tuning_dataset_bundle

    assert callable(bundle_loader)
    assert "aimp_sdk.tuning_data" in sys.modules
