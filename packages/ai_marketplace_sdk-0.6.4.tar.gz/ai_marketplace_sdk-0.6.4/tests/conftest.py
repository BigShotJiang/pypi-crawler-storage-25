"""Shared test bootstrap for local SDK source runs."""

from __future__ import annotations

import sys
from pathlib import Path


SDK_ROOT = Path(__file__).resolve().parents[1]
FRAMEWORK_ROOT = Path(__file__).resolve().parents[2] / "framework"

for path in (str(SDK_ROOT), str(FRAMEWORK_ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)
