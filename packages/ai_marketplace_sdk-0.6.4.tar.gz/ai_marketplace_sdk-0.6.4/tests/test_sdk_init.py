"""Tests for SDK package import behavior."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from types import ModuleType

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))


def _snapshot_sdk_modules() -> dict[str, ModuleType]:
    return {
        module_name: module
        for module_name, module in sys.modules.items()
        if module_name == "aimp_sdk" or module_name.startswith("aimp_sdk.")
    }


def _clear_sdk_modules() -> None:
    for module_name in list(sys.modules):
        if module_name == "aimp_sdk" or module_name.startswith("aimp_sdk."):
            sys.modules.pop(module_name, None)


def _restore_sdk_modules(snapshot: dict[str, ModuleType]) -> None:
    _clear_sdk_modules()
    sys.modules.update(snapshot)


def test_import_aimp_sdk_does_not_import_client_module() -> None:
    """Package import must stay lightweight for contract extraction flows."""
    snapshot = _snapshot_sdk_modules()
    try:
        _clear_sdk_modules()
        aimp_sdk = importlib.import_module("aimp_sdk")

        assert aimp_sdk.Model is not None
        assert "aimp_sdk.client" not in sys.modules
    finally:
        _restore_sdk_modules(snapshot)


def test_contract_module_import_does_not_import_client_module() -> None:
    """Contract entrypoint import must not pull in dataset dependencies."""
    snapshot = _snapshot_sdk_modules()
    try:
        _clear_sdk_modules()
        contract_module = importlib.import_module("aimp_sdk.contract")

        assert contract_module.main is not None
        assert "aimp_sdk.client" not in sys.modules
    finally:
        _restore_sdk_modules(snapshot)


def test_load_model_vector_contract_is_exported_from_package_root() -> None:
    """Runtime verification must rely on the stable package-root SDK surface."""
    snapshot = _snapshot_sdk_modules()
    try:
        _clear_sdk_modules()
        aimp_sdk = importlib.import_module("aimp_sdk")

        assert callable(aimp_sdk.load_model_vector_contract)
        assert aimp_sdk.load_model_vector_contract.__module__ == "aimp_sdk.model_runtime_loader"
        assert "aimp_sdk.client" not in sys.modules
    finally:
        _restore_sdk_modules(snapshot)


def test_legacy_agent_runner_module_is_not_importable() -> None:
    """The SDK exposes only the model runner entrypoint."""
    snapshot = _snapshot_sdk_modules()
    try:
        _clear_sdk_modules()

        try:
            importlib.import_module("aimp_sdk.agent_runner")
        except ModuleNotFoundError:
            pass
        else:  # pragma: no cover - this branch documents the breaking contract.
            raise AssertionError("aimp_sdk.agent_runner must not be importable")
    finally:
        _restore_sdk_modules(snapshot)


def test_client_symbol_loads_lazily_from_package_root() -> None:
    """Public Client export must remain available through lazy loading."""
    snapshot = _snapshot_sdk_modules()
    try:
        _clear_sdk_modules()
        aimp_sdk = importlib.import_module("aimp_sdk")
        client_cls = aimp_sdk.Client

        assert "aimp_sdk.client" in sys.modules
        assert client_cls.__module__ == "aimp_sdk.client"
    finally:
        _restore_sdk_modules(snapshot)
