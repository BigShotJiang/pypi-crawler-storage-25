"""Tests for execution bundle path resolution (MODEL_ARTIFACTS_DIR contract)."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from aimp_sdk.execution_assets import EXECUTION_BUNDLE_PAYLOAD_SUBDIR
from aimp_sdk.execution_assets import ExecutionArtifactContractError
from aimp_sdk.execution_assets import resolve_execution_bundle_payload_dir


def test_resolve_returns_explicit_checkpoint_dir() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        inner = Path(tmp) / "clip"
        inner.mkdir()
        resolved = resolve_execution_bundle_payload_dir(
            "/should/not/matter",
            explicit_checkpoint_dir=str(inner),
        )
        assert resolved == inner.resolve()


def test_resolve_bundle_root_requires_artifacts_subdir() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        with pytest.raises(ExecutionArtifactContractError, match="missing the required"):
            resolve_execution_bundle_payload_dir(root)


def test_resolve_accepts_canonical_layout() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        payload = root / EXECUTION_BUNDLE_PAYLOAD_SUBDIR
        payload.mkdir()
        assert resolve_execution_bundle_payload_dir(root) == payload.resolve()
