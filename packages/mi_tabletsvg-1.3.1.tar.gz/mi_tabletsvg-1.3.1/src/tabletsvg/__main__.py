""" __main__.py """

# System
import logging
import logging.config
import sys
import argparse
from pathlib import Path

# Tablet
from tabletsvg import version

_logpath = Path("tabletsvg.log")
app_name = "Tablet"

def get_logger():
    """ Initiate the logger """
    log_conf_path = Path(__file__).parent / 'log.conf'  # Logging configuration is in this file
    logging.config.fileConfig(fname=log_conf_path, disable_existing_loggers=False)
    return logging.getLogger(__name__)  # Create a logger for this module

# Configure the expected parameters and actions for the argparse module
def parse(cl_input):
    """
    The command line interface is for diagnostic purposes.
    """
    parser = argparse.ArgumentParser(description='Tablet 2D model diagram svg generator')
    parser.add_argument('-demo', action='store',
                        help='name of demo module')
    parser.add_argument('-COLORS', '--colors', action='store_true',
                        help='Show the list of background color stickers')
    parser.add_argument('-T', '--test', action='store_true',
                        help='Run some test features')
    parser.add_argument('-D', '--debug', action='store_true',
                        help='Debug mode'),
    parser.add_argument('-V', '--version', action='store_true',
                        help='Print the current version')
    return parser.parse_args(cl_input)


def main():
    # Start logging
    logger = get_logger()
    logger.info(f'{app_name} version: {version}')
    logger.info('-----------------\n')

    # Parse the command line args
    args = parse(sys.argv[1:])

    if args.version:
        # Just print the version and quit
        print(f'{app_name} version: {version}')
        sys.exit(0)

    if args.demo:
        spath = Path(__file__).parent / f'demo/{args.demo}.py'
        sys.exit(0)

    if args.test:
        from tabletsvg.styledb import StyleDB
        StyleDB.load_config_files()

    if args.colors:
        # Just print the database colors and quit
        from tabletsvg.styledb import StyleDB
        StyleDB.report_colors()

    logger.info("No problemo")  # We didn't die on an exception
    print("\nNo problemo")


if __name__ == "__main__":
    main()