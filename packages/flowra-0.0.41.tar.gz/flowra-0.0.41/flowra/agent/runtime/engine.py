import asyncio
import dataclasses
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from ..definition import AgentDefinition, AgentInstance, AgentRegistry, ChildOutput
from ..flow import (
    AgentInfo,
    CallAgent,
    CallStep,
    ExecutionContext,
    ExecutionFrame,
    FlowingRegistry,
    GotoAgent,
    GotoStep,
    HookEmitter,
    HookSubscription,
    InterruptControl,
    Interrupted,
    InterruptedError,
    InterruptToken,
    InterruptTokenSource,
    Spawn,
    SpawnChild,
)
from ..state import Ephemeral, Named
from .execution import CollectedResult, ExecutionNode, ExecutionStatus
from .scope import NamedScopeRegistry, RuntimeScope, ScopeData
from .spans import AgentSpan, StepSpan
from .spawn_tree import (
    build_spawn_tree,
    collect_needed_indices,
    interrupt_unneeded_from_tasks,
    is_tree_satisfied,
    satisfied_set_from_children,
)

__all__ = [
    "AdvanceResult",
    "Completed",
    "Engine",
    "InstanceFactory",
    "Progressed",
    "ScopeFactory",
    "ScopeRestoreCallback",
]

type ScopeFactory = Callable[[dict[type, Any], ScopeData | None], RuntimeScope]
type ScopeRestoreCallback = Callable[[RuntimeScope, str | None, str, str], Awaitable[None]]
type InstanceFactory = Callable[[AgentDefinition, RuntimeScope, dict[type, Any], Any | None], AgentInstance]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Completed:
    result: Any | None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Progressed:
    pass


type AdvanceResult = Completed | Progressed


class Engine:
    __slots__ = (
        "__flowing",
        "__instance_factory",
        "__live_persistent_keys",
        "__named_scope_registry",
        "__registry",
        "__scope_factory",
        "__scope_restore",
        "__services",
    )

    def __init__(
        self,
        registry: AgentRegistry,
        scope_factory: ScopeFactory,
        instance_factory: InstanceFactory,
        services: dict[type, Any] | None = None,
        scope_restore: ScopeRestoreCallback | None = None,
        named_scope_registry: NamedScopeRegistry | None = None,
    ) -> None:
        self.__registry = registry
        self.__scope_factory = scope_factory
        self.__instance_factory = instance_factory
        self.__services: dict[type, Any] = services or {}
        self.__live_persistent_keys: set[str] = set()
        self.__scope_restore = scope_restore
        self.__named_scope_registry = named_scope_registry
        flowing = self.__services.get(FlowingRegistry)
        self.__flowing: FlowingRegistry = flowing if isinstance(flowing, FlowingRegistry) else FlowingRegistry()

    # -- Flowing context helpers --

    def __fork_flowing(self) -> Any:
        return self.__flowing.fork()

    def __restore_flowing(self, token: Any) -> None:
        self.__flowing.restore(token)

    def __snapshot_flowing(self, node: ExecutionNode) -> None:
        node.flowing_snapshot = self.__flowing.snapshot()

    def __apply_flowing(self, node: ExecutionNode) -> Any:
        return self.__flowing.apply(node.flowing_snapshot) if node.flowing_snapshot is not None else None

    @staticmethod
    def __build_agent_info(agent_name: str, defn: AgentDefinition) -> AgentInfo:
        parts = agent_name.split("/")
        parent: AgentInfo | None = None
        for i in range(len(parts) - 1):
            ancestor_path = "/".join(parts[: i + 1])
            parent = AgentInfo(name=parts[i], path=ancestor_path, source_type=None, parent=parent)
        return AgentInfo(name=parts[-1], path=agent_name, source_type=defn.source_type, parent=parent)

    @classmethod
    def __build_execution_stack(cls, node: ExecutionNode | None) -> tuple[ExecutionFrame, ...]:
        frames: list[ExecutionFrame] = []
        current = node
        while current is not None:
            agent_info = cls.__build_agent_info(current.agent_name, current.defn)
            frames.append(ExecutionFrame(agent=agent_info, spec=current.agent_spec, tag=current.tag))
            current = current.parent
        frames.reverse()
        return tuple(frames)

    def __build_exec_context(
        self,
        agent_name: str,
        defn: AgentDefinition,
        spec: Any,
        tag: str | None,
        parent: ExecutionNode | None,
    ) -> ExecutionContext:
        agent_info = self.__build_agent_info(agent_name, defn)
        parent_stack = self.__build_execution_stack(parent)
        current_frame = ExecutionFrame(agent=agent_info, spec=spec, tag=tag)
        return ExecutionContext(frame=current_frame, stack=(*parent_stack, current_frame))

    def inject_exec_context(
        self,
        merged: dict[type, Any],
        agent_name: str,
        defn: AgentDefinition,
        spec: Any,
        tag: str | None,
        parent: ExecutionNode | None,
    ) -> None:
        context = self.__build_exec_context(agent_name, defn, spec, tag, parent)
        self.__do_inject_exec_context(merged, context)

    def __do_inject_exec_context(self, merged: dict[type, Any], context: ExecutionContext) -> None:
        subscription = merged.get(HookSubscription)
        if isinstance(subscription, HookSubscription):
            merged[HookEmitter] = HookEmitter(
                subscription.get_handlers(), context, span_handlers=subscription.get_span_handlers()
            )

    async def open_resumed_spans(self, root: ExecutionNode) -> None:
        if root.status == ExecutionStatus.COMPLETED:
            return
        tokens = self.__fork_flowing()
        try:
            emitter = root.emitter
            if isinstance(emitter, HookEmitter):
                agent_info = self.__build_agent_info(root.agent_name, root.defn)
                if emitter.has_span_handlers(AgentSpan):
                    root.agent_span = await emitter.open_span(
                        AgentSpan(agent_info=agent_info, spec=root.agent_spec, is_resume=True)
                    )
                if emitter.has_span_handlers(StepSpan):
                    step_name = root.pending_step or root.then_step
                    if step_name is not None:
                        root.step_span = await emitter.open_span(
                            StepSpan(agent_info=agent_info, step=step_name, spec=root.pending_spec)
                        )
            self.__snapshot_flowing(root)
        finally:
            self.__restore_flowing(tokens)
        if root.children:
            for child in root.children:
                await self.open_resumed_spans(child)

    def register_live_persistent_keys(self, root: ExecutionNode) -> None:
        if root.status != ExecutionStatus.COMPLETED and root.persistent_key is not None:
            self.__acquire_persistent_key(root.persistent_key, shared=root.defn.shared_persistent)
        if root.children:
            for child in root.children:
                self.register_live_persistent_keys(child)

    def resolve_persistent_key(self, state: Any, agent_name: str) -> str | None:
        """Resolve the ``state`` parameter to a persistent key (or None for ephemeral)."""
        if state is None:
            return agent_name
        if isinstance(state, str):
            return state
        if isinstance(state, Ephemeral):
            return None
        if isinstance(state, Named):
            # Named scopes are handled separately — persistent_key = None (no separate persistent storage)
            return None
        msg = f"Invalid state parameter: {state!r}"
        raise TypeError(msg)

    def resolve_persistent_scope(self, state: Any) -> ScopeData:
        """Resolve the persistent ScopeData based on the ``state`` parameter."""
        if isinstance(state, Named):
            if state.name is None:
                msg = "persistent.NAMED requires a scope name: persistent.NAMED('name')"
                raise ValueError(msg)
            if self.__named_scope_registry is None:
                msg = "Named scopes not available (no registry)"
                raise RuntimeError(msg)
            return self.__named_scope_registry.get_or_create(state.name)
        return ScopeData()

    async def build_root(
        self,
        agent: str,
        step: str,
        spec: Any | None = None,
        *,
        persistent_key: str | None = None,
        persistent_scope: ScopeData | None = None,
        node_id: str = "root",
        interrupt_source: InterruptTokenSource | None = None,
    ) -> ExecutionNode:
        defn = self.__registry.get(agent)
        return await self.__create_node(
            node_id=node_id,
            agent_name=agent,
            defn=defn,
            step=step,
            spec=spec,
            parent_services={},
            parent=None,
            persistent_key=persistent_key,
            persistent_scope=persistent_scope,
            agent_spec=spec,
            interrupt_source=interrupt_source,
        )

    async def advance(self, root: ExecutionNode) -> AdvanceResult:
        try:
            return await self.__advance_inner(root)
        except BaseException as exc:
            await self.__close_all_spans(root, error=exc)
            raise

    async def __advance_inner(self, root: ExecutionNode) -> AdvanceResult:
        await self.__propagate_completions(root)

        if root.status == ExecutionStatus.COMPLETED:
            return Completed(result=root.result)

        actionable = self.__collect_actionable(root)
        if not actionable:
            msg = "No actionable nodes found but root is not completed"
            raise RuntimeError(msg)

        step_results = await self.__execute_nodes(actionable)

        for node, step_result in zip(actionable, step_results):
            if node.flowing_snapshot is not None:
                tokens = self.__apply_flowing(node)
                try:
                    await self.__apply_result(node, step_result)
                finally:
                    self.__restore_flowing(tokens)
            else:
                await self.__apply_result(node, step_result)

        match ExecutionStatus(root.status):
            case ExecutionStatus.COMPLETED:
                return Completed(result=root.result)
            case ExecutionStatus.PENDING_STEP | ExecutionStatus.WAITING_CHILDREN:
                return Progressed()

    def __collect_actionable(self, node: ExecutionNode) -> list[ExecutionNode]:
        result: list[ExecutionNode] = []
        match node.status:
            case ExecutionStatus.PENDING_STEP:
                result.append(node)
            case ExecutionStatus.WAITING_CHILDREN:
                assert node.children is not None
                for child in node.children:
                    result.extend(self.__collect_actionable(child))
            case ExecutionStatus.COMPLETED:
                pass
        return result

    async def __execute_nodes(self, nodes: Iterable[ExecutionNode]) -> list[Any]:
        node_list = list(nodes)
        tasks: list[asyncio.Task[Any]] = []
        for node in node_list:
            if node.flowing_snapshot is not None:
                tokens = self.__apply_flowing(node)
                tasks.append(asyncio.ensure_future(self.__execute_node(node)))
                self.__restore_flowing(tokens)
            else:
                tasks.append(asyncio.ensure_future(self.__execute_node(node)))

        parent_groups: dict[int, tuple[ExecutionNode, dict[int, asyncio.Task[Any]]]] = {}
        for node, task in zip(node_list, tasks):
            parent = node.parent
            if parent is not None and parent.spawn_tree is not None and parent.children is not None:
                pid = id(parent)
                if pid not in parent_groups:
                    parent_groups[pid] = (parent, {})
                child_idx = parent.children.index(node)
                parent_groups[pid][1][child_idx] = task

        if parent_groups:
            for pid, (parent, task_map) in parent_groups.items():

                def _make_cb(p: ExecutionNode, tm: dict[int, asyncio.Task[Any]]) -> Callable[[asyncio.Task[Any]], None]:
                    def _cb(_: asyncio.Task[Any]) -> None:
                        interrupt_unneeded_from_tasks(p, tm)

                    return _cb

                cb = _make_cb(parent, task_map)
                for task in task_map.values():
                    task.add_done_callback(cb)

        return list(await asyncio.gather(*tasks))

    @staticmethod
    async def __execute_node(node: ExecutionNode) -> Any:
        assert node.pending_step is not None
        child_outputs: list[ChildOutput] | None = None
        had_interrupts = False
        if node.child_results is not None:
            child_outputs = []
            for cr in node.child_results:
                if isinstance(cr.result, Interrupted):
                    had_interrupts = True
                child_outputs.append(ChildOutput(result=cr.result, tag=cr.tag))
        try:
            return await node.instance.call_step(node.pending_step, node.pending_spec, child_outputs)
        except InterruptedError:
            return Interrupted()
        except TypeError:
            if had_interrupts:
                return Interrupted()
            raise

    async def __apply_result(self, node: ExecutionNode, step_result: Any) -> None:
        match step_result:
            case GotoStep(step=next_step, spec=next_spec):
                # GotoStep: same agent, scopes stay the same
                await self.__close_step_span(node, result=step_result)
                node.pending_step = next_step
                node.pending_spec = next_spec
                node.child_results = None
                await self.__open_step_span(node)
                self.__snapshot_flowing(node)

            case GotoAgent(agent=agent_ref, spec=next_spec, state=state):
                await self.__close_step_span(node, result=step_result)
                await self.__close_agent_span(node, result=step_result)

                resolved = self.__registry.resolve(agent_ref, context=node.agent_name)
                entry = resolved.definition.entry_step

                # Release old persistent key, resolve new one
                self.__release_persistent_key(node)
                new_key = self.resolve_persistent_key(state, resolved.name)
                persistent_scope = self.resolve_persistent_scope(state)
                if new_key is not None:
                    self.__acquire_persistent_key(new_key, shared=resolved.definition.shared_persistent)
                node.persistent_key = new_key

                inherited = node.scope.get_inherited_services()
                new_scope = self.__scope_factory(inherited, persistent_scope)

                merged = {**self.__services, **inherited}
                if node.interrupt_source is not None:
                    merged[InterruptToken] = node.interrupt_source.token
                    merged[InterruptControl] = InterruptControl(node.interrupt_source)
                exec_context = self.__build_exec_context(
                    resolved.name, resolved.definition, next_spec, node.tag, node.parent
                )
                self.__do_inject_exec_context(merged, exec_context)
                new_instance = self.__instance_factory(resolved.definition, new_scope, merged, next_spec)
                if self.__scope_restore is not None:
                    await self.__scope_restore(new_scope, new_key, node.node_id, resolved.name)

                node.scope = new_scope
                node.instance = new_instance
                node.agent_name = resolved.name
                node.defn = resolved.definition

                node.pending_step = entry
                node.pending_spec = next_spec
                node.child_results = None
                node.agent_spec = next_spec

                new_emitter = merged.get(HookEmitter)
                node.emitter = new_emitter if isinstance(new_emitter, HookEmitter) else None
                await self.__open_agent_and_step_spans(node)
                self.__snapshot_flowing(node)

            case Spawn(root=root_node, children=calls, then=then_step):
                node.status = ExecutionStatus.WAITING_CHILDREN
                node.pending_step = None
                node.pending_spec = None
                node.child_results = None
                node.then_step = then_step
                node.children = []
                parent_services = node.scope.get_services()
                for child_index, call in enumerate(calls):
                    child = await self.__create_child_node(call, node.defn, parent_services, node, child_index)
                    node.children.append(child)
                node.spawn_tree = build_spawn_tree(root_node, [0])

            case Interrupted():
                await self.__close_step_span(node, result=step_result)
                await self.__close_agent_span(node, error=InterruptedError())
                self.__finalize_completed(node, step_result)

            case _:
                await self.__close_step_span(node, result=step_result)
                await self.__close_agent_span(node, result=step_result)
                self.__finalize_completed(node, step_result)

    async def __propagate_completions(self, root: ExecutionNode) -> None:
        if root.status != ExecutionStatus.WAITING_CHILDREN:
            return
        assert root.children is not None

        for child in root.children:
            await self.__propagate_completions(child)

        if root.spawn_tree is not None:
            satisfied = satisfied_set_from_children(root.children)
            if is_tree_satisfied(root.spawn_tree, satisfied):
                needed = collect_needed_indices(root.spawn_tree, satisfied)
                for i, child in enumerate(root.children):
                    if (
                        child.status != ExecutionStatus.COMPLETED
                        and i not in needed
                        and child.interrupt_source is not None
                    ):
                        child.interrupt_source.interrupt()

        if all(c.status == ExecutionStatus.COMPLETED for c in root.children):
            root.child_results = [
                CollectedResult(agent_name=c.agent_name, result=c.result, tag=c.tag) for c in root.children
            ]
            for child in root.children:
                if child.interrupt_source is not None:
                    child.interrupt_source.dispose()
            root.status = ExecutionStatus.PENDING_STEP
            root.pending_step = root.then_step
            root.pending_spec = None
            root.then_step = None
            root.spawn_tree = None
            root.children = None

    def __acquire_persistent_key(self, key: str, *, shared: bool = False) -> None:
        if not shared and key in self.__live_persistent_keys:
            msg = f"Duplicate persistent key: {key!r}"
            raise ValueError(msg)
        self.__live_persistent_keys.add(key)

    def __finalize_completed(self, node: ExecutionNode, result: Any) -> None:
        node.status = ExecutionStatus.COMPLETED
        node.result = result
        node.pending_step = None
        node.pending_spec = None
        node.child_results = None
        self.__release_persistent_key(node)
        if node.interrupt_source is not None:
            node.interrupt_source.dispose()

    def __release_persistent_key(self, node: ExecutionNode) -> None:
        if node.persistent_key is not None and node.persistent_key in self.__live_persistent_keys:
            self.__live_persistent_keys.discard(node.persistent_key)

    async def __close_all_spans(self, node: ExecutionNode, *, error: BaseException) -> None:
        if node.children:
            for child in node.children:
                await self.__close_all_spans(child, error=error)
        if node.flowing_snapshot is not None:
            tokens = self.__apply_flowing(node)
            try:
                await self.__close_step_span(node, error=error)
                await self.__close_agent_span(node, error=error)
            finally:
                self.__restore_flowing(tokens)
        else:
            await self.__close_step_span(node, error=error)
            await self.__close_agent_span(node, error=error)

    async def __open_agent_and_step_spans(self, node: ExecutionNode) -> None:
        if node.emitter is None:
            return
        agent_info = self.__build_agent_info(node.agent_name, node.defn)
        if node.emitter.has_span_handlers(AgentSpan):
            node.agent_span = await node.emitter.open_span(AgentSpan(agent_info=agent_info, spec=node.agent_spec))
        if node.emitter.has_span_handlers(StepSpan) and node.pending_step is not None:
            node.step_span = await node.emitter.open_span(
                StepSpan(agent_info=agent_info, step=node.pending_step, spec=node.pending_spec)
            )

    async def __close_step_span(
        self, node: ExecutionNode, result: Any = None, error: BaseException | None = None
    ) -> None:
        if node.step_span is not None and node.emitter is not None:
            if result is not None:
                node.step_span.result = result
            await node.emitter.close_span(node.step_span, error=error)
            node.step_span = None

    async def __close_agent_span(
        self, node: ExecutionNode, result: Any = None, error: BaseException | None = None
    ) -> None:
        if node.agent_span is not None and node.emitter is not None:
            if result is not None:
                node.agent_span.result = result
            await node.emitter.close_span(node.agent_span, error=error)
            node.agent_span = None

    async def __open_step_span(self, node: ExecutionNode) -> None:
        if node.emitter is not None and node.emitter.has_span_handlers(StepSpan) and node.pending_step is not None:
            agent_info = self.__build_agent_info(node.agent_name, node.defn)
            node.step_span = await node.emitter.open_span(
                StepSpan(agent_info=agent_info, step=node.pending_step, spec=node.pending_spec)
            )

    async def __create_node(
        self,
        node_id: str,
        agent_name: str,
        defn: AgentDefinition,
        step: str,
        spec: Any | None,
        parent_services: dict[type, Any],
        parent: ExecutionNode | None,
        persistent_key: str | None = None,
        persistent_scope: ScopeData | None = None,
        agent_spec: Any | None = None,
        tag: str | None = None,
        interrupt_source: InterruptTokenSource | None = None,
    ) -> ExecutionNode:
        if persistent_key is not None:
            self.__acquire_persistent_key(persistent_key, shared=defn.shared_persistent)
        merged = {**self.__services, **parent_services}
        if interrupt_source is not None:
            merged[InterruptToken] = interrupt_source.token
            merged[InterruptControl] = InterruptControl(interrupt_source)
        exec_context = self.__build_exec_context(agent_name, defn, agent_spec, tag, parent)
        self.__do_inject_exec_context(merged, exec_context)
        scope = self.__scope_factory(merged, persistent_scope)
        instance = self.__instance_factory(defn, scope, merged, agent_spec)
        if self.__scope_restore is not None:
            await self.__scope_restore(scope, persistent_key, node_id, agent_name)
        emitter = merged.get(HookEmitter)
        node = ExecutionNode(
            node_id=node_id,
            persistent_key=persistent_key,
            agent_name=agent_name,
            defn=defn,
            instance=instance,
            scope=scope,
            status=ExecutionStatus.PENDING_STEP,
            pending_step=step,
            pending_spec=spec,
            parent=parent,
            agent_spec=agent_spec,
            tag=tag,
            interrupt_source=interrupt_source,
            emitter=emitter if isinstance(emitter, HookEmitter) else None,
        )
        tokens = self.__fork_flowing()
        try:
            await self.__open_agent_and_step_spans(node)
            self.__snapshot_flowing(node)
        finally:
            self.__restore_flowing(tokens)
        return node

    async def __create_child_node(
        self,
        call: SpawnChild,
        parent_defn: AgentDefinition,
        parent_services: dict[type, Any],
        parent: ExecutionNode,
        child_index: int,
    ) -> ExecutionNode:
        child_node_id = f"{parent.node_id}.{child_index}"
        child_source = parent.interrupt_source.create_child() if parent.interrupt_source is not None else None
        merged = {**self.__services, **parent_services}
        if child_source is not None:
            merged[InterruptToken] = child_source.token
            merged[InterruptControl] = InterruptControl(child_source)

        match call:
            case CallStep(step=step, spec=spec, fork_ephemeral=do_fork, tag=call_tag):
                exec_context = self.__build_exec_context(
                    parent.agent_name, parent_defn, parent.agent_spec, call_tag, parent
                )
                self.__do_inject_exec_context(merged, exec_context)
                scope = parent.scope.fork_ephemeral(parent_services=merged) if do_fork else parent.scope
                instance = self.__instance_factory(parent_defn, scope, merged, parent.agent_spec)
                if self.__scope_restore is not None and do_fork:
                    await self.__scope_restore(scope, None, child_node_id, parent.agent_name)
                child_emitter = merged.get(HookEmitter)
                child_node = ExecutionNode(
                    node_id=child_node_id,
                    persistent_key=parent.persistent_key,
                    agent_name=parent.agent_name,
                    defn=parent_defn,
                    instance=instance,
                    scope=scope,
                    status=ExecutionStatus.PENDING_STEP,
                    pending_step=step,
                    pending_spec=spec,
                    parent=parent,
                    tag=call_tag,
                    agent_spec=parent.agent_spec,
                    interrupt_source=child_source,
                    emitter=child_emitter if isinstance(child_emitter, HookEmitter) else None,
                )
                tokens = self.__fork_flowing()
                try:
                    await self.__open_agent_and_step_spans(child_node)
                    self.__snapshot_flowing(child_node)
                finally:
                    self.__restore_flowing(tokens)
                return child_node

            case CallAgent(agent=agent_ref, spec=spec, state=state, tag=call_tag):
                resolved = self.__registry.resolve(agent_ref, context=parent.agent_name)
                entry = resolved.definition.entry_step
                persistent_key = self.resolve_persistent_key(state, resolved.name)
                persistent_scope = self.resolve_persistent_scope(state)
                return await self.__create_node(
                    node_id=child_node_id,
                    agent_name=resolved.name,
                    defn=resolved.definition,
                    step=entry,
                    spec=spec,
                    parent_services=parent_services,
                    parent=parent,
                    persistent_key=persistent_key,
                    persistent_scope=persistent_scope if isinstance(state, Named) else None,
                    agent_spec=spec,
                    tag=call_tag,
                    interrupt_source=child_source,
                )
