import asyncio
from typing import Any

from ..._sentinel import UNSET, Unset
from ..definition import AgentDefinition, AgentDefinitionRef, AgentInstance, AgentRef, AgentRegistry
from ..flow import FlowingRegistry, HookEmitter, HookSubscription, InterruptToken, InterruptTokenSource, TimeoutAgent
from ..storage import ChangeSet, SessionStorage
from .engine import Completed, Engine, Progressed
from .execution import CollectedResult, ExecutionNode, ExecutionStatus
from .instance_factory import create_instance_sealed
from .scope import NamedScopeRegistry, RuntimeScope, ScopeData
from .serialization import deserialize_value, serialize_value
from .spawn_tree import deserialize_spawn_tree, serialize_spawn_tree

__all__ = ["AgentRuntime"]


class AgentRuntime:
    __slots__ = (
        "__engine",
        "__interrupt_source",
        "__max_iterations",
        "__named_scope_registry",
        "__registry",
        "__services",
        "__storage",
        "__timeout",
        "__type_registries",
    )

    def __init__(
        self,
        agents: dict[str, AgentDefinitionRef],
        storage: SessionStorage | None = None,
        services: dict[type, Any] | None = None,
        max_iterations: int | None = None,
        timeout: float | None = None,
    ) -> None:
        self.__storage = storage
        self.__max_iterations = max_iterations
        self.__timeout = timeout
        self.__interrupt_source = InterruptTokenSource()
        self.__named_scope_registry = NamedScopeRegistry()
        self.__services: dict[type, Any] = services or {}
        self.__services.setdefault(HookSubscription, HookSubscription())
        self.__services.setdefault(FlowingRegistry, FlowingRegistry())
        agents_with_builtins: dict[str, AgentDefinitionRef] = {"__timeout__": TimeoutAgent, **agents}
        self.__registry = AgentRegistry(agents_with_builtins)
        self.__type_registries = self.__build_type_registries(self.__registry)
        self.__engine = Engine(
            registry=self.__registry,
            scope_factory=self.__create_scope,
            instance_factory=self.__create_instance,
            services=self.__services,
            scope_restore=self.__init_node,
            named_scope_registry=self.__named_scope_registry,
        )

    async def run(
        self,
        *,
        agent: AgentRef,
        spec: Any | None = None,
        state: Any = None,
        max_iterations: int | None | Unset = UNSET,
        timeout: float | None | Unset = UNSET,
    ) -> Any:
        if await self.has_pending_execution():
            msg = "Pending execution exists; call resume() or clear the execution snapshot first"
            raise RuntimeError(msg)

        agent_name = agent if isinstance(agent, str) else self.__registry.name_for_type(agent)
        defn = self.__registry.get(agent_name)

        step_tag = defn.entry_step

        run_id = await self.__next_run_id() if self.__storage else 1
        # Resolve persistent key and scope from state parameter
        persistent_key = self.__engine.resolve_persistent_key(state, agent_name)
        persistent_scope = self.__engine.resolve_persistent_scope(state)
        root = await self.__engine.build_root(
            agent_name,
            step_tag,
            spec,
            persistent_key=persistent_key,
            persistent_scope=persistent_scope,
            node_id=f"r{run_id}",
            interrupt_source=self.__interrupt_source,
        )
        return await self.__run_loop(
            root,
            max_iterations=max_iterations if not isinstance(max_iterations, Unset) else self.__max_iterations,
            timeout=timeout if not isinstance(timeout, Unset) else self.__timeout,
        )

    async def has_pending_execution(self) -> bool:
        if self.__storage is None:
            return False
        return await self.__storage.has_execution()

    async def resume(
        self,
        *,
        max_iterations: int | None | Unset = UNSET,
        timeout: float | None | Unset = UNSET,
    ) -> Any:
        if self.__storage is None:
            msg = "No storage configured for resume"
            raise RuntimeError(msg)
        execution = await self.__storage.load_execution()
        if execution is None:
            msg = "No persisted state to resume from"
            raise RuntimeError(msg)
        root = await self.__restore_tree(execution, parent=None, interrupt_source=self.__interrupt_source)
        self.__engine.register_live_persistent_keys(root)
        await self.__engine.open_resumed_spans(root)
        return await self.__run_loop(
            root,
            max_iterations=max_iterations if not isinstance(max_iterations, Unset) else self.__max_iterations,
            timeout=timeout if not isinstance(timeout, Unset) else self.__timeout,
        )

    @property
    def hooks(self) -> HookSubscription:
        return self.__services[HookSubscription]

    @property
    def flowing(self) -> FlowingRegistry:
        return self.__services[FlowingRegistry]

    def interrupt(self) -> None:
        self.__interrupt_source.interrupt()

    async def __run_loop(
        self,
        root: ExecutionNode,
        *,
        max_iterations: int | None,
        timeout: float | None,
    ) -> Any:
        if timeout is not None:
            return await asyncio.wait_for(
                self.__run_loop_inner(root, max_iterations=max_iterations),
                timeout=timeout,
            )
        return await self.__run_loop_inner(root, max_iterations=max_iterations)

    async def __run_loop_inner(self, root: ExecutionNode, *, max_iterations: int | None) -> Any:
        iteration = 0
        while True:
            if max_iterations is not None and iteration >= max_iterations:
                msg = f"Agent exceeded max_iterations limit ({max_iterations})"
                raise RuntimeError(msg)
            iteration += 1
            result = await self.__engine.advance(root)
            await self.__save_post_advance(root)
            match result:
                case Completed(result=r):
                    if self.__storage:
                        await self.__storage.clear_execution()
                    self.__interrupt_source.clear()
                    return r
                case Progressed():
                    continue

    async def __save_post_advance(self, root: ExecutionNode) -> None:
        if self.__storage is None:
            return
        async with self.__storage.begin_transaction():
            await self.__storage.save_execution(self.__snapshot_tree(root))
            await self.__save_dirty_scopes(root)
            await self.__save_dirty_named_scopes()
        self.__mark_all_clean(root)
        self.__mark_named_scopes_clean()

    async def __save_dirty_scopes(self, node: ExecutionNode) -> None:
        """Save ephemeral and persistent scope changes for a node."""
        assert self.__storage is not None

        # Save ephemeral scope (keyed by node_id)
        eph_tt = self.__tag_by_type(node.agent_name)
        eph_changes = node.scope.ephemeral.get_changes()
        if not eph_changes.empty:
            eph_key = f"__ephemeral__:{node.node_id}"
            serialized = ChangeSet(
                scalars={k: serialize_value(v, eph_tt) for k, v in eph_changes.scalars.items()},
                appends={k: [serialize_value(item, eph_tt) for item in v] for k, v in eph_changes.appends.items()},
            )
            await self.__storage.save_node_state(eph_key, serialized)

        # Save persistent scope (keyed by persistent_key)
        if node.persistent_key is not None:
            p_tt = self.__tag_by_type(node.agent_name)
            p_changes = node.scope.persistent.get_changes()
            if not p_changes.empty:
                p_key = f"__node__:{node.persistent_key}"
                serialized = ChangeSet(
                    scalars={k: serialize_value(v, p_tt) for k, v in p_changes.scalars.items()},
                    appends={k: [serialize_value(item, p_tt) for item in v] for k, v in p_changes.appends.items()},
                )
                await self.__storage.save_node_state(p_key, serialized)

        if node.children:
            for child in node.children:
                await self.__save_dirty_scopes(child)

    async def __save_dirty_named_scopes(self) -> None:
        assert self.__storage is not None
        for scope_name, named_scope in self.__named_scope_registry.all_scopes().items():
            ns_tt = {v: k for k, v in named_scope.type_registry.items()}
            changes = named_scope.get_changes()
            if not changes.empty:
                serialized = ChangeSet(
                    scalars={k: serialize_value(v, ns_tt) for k, v in changes.scalars.items()},
                    appends={k: [serialize_value(item, ns_tt) for item in v] for k, v in changes.appends.items()},
                )
                await self.__storage.save_node_state(scope_name, serialized)

    @classmethod
    def __mark_all_clean(cls, node: ExecutionNode) -> None:
        node.scope.ephemeral.mark_clean()
        node.scope.persistent.mark_clean()
        if node.children:
            for child in node.children:
                cls.__mark_all_clean(child)

    def __mark_named_scopes_clean(self) -> None:
        for named_scope in self.__named_scope_registry.all_scopes().values():
            named_scope.mark_clean()

    def __snapshot_tree(self, node: ExecutionNode) -> dict[str, Any]:
        tt = self.__tag_by_type(node.agent_name)
        child_results_data: list[dict[str, Any]] | None = None
        if node.child_results is not None:
            child_results_data = []
            for cr in node.child_results:
                cr_tt = self.__tag_by_type(cr.agent_name)
                child_results_data.append(
                    {
                        "agent_name": cr.agent_name,
                        "result": serialize_value(cr.result, cr_tt),
                        "tag": cr.tag,
                    }
                )
        return {
            "node_id": node.node_id,
            "persistent_key": node.persistent_key,
            "agent_name": node.agent_name,
            "status": node.status.value,
            "pending_step": node.pending_step,
            "pending_spec": serialize_value(node.pending_spec, tt) if node.pending_spec is not None else None,
            "then_step": node.then_step,
            "goto_counter": node.goto_counter,
            "result": serialize_value(node.result, tt) if node.result is not None else None,
            "child_results": child_results_data,
            "children": [self.__snapshot_tree(c) for c in node.children] if node.children is not None else None,
            "tag": node.tag,
            "agent_spec": serialize_value(node.agent_spec, tt) if node.agent_spec is not None else None,
            "spawn_tree": serialize_spawn_tree(node.spawn_tree) if node.spawn_tree is not None else None,
        }

    async def __restore_tree(
        self,
        data: dict[str, Any],
        parent: ExecutionNode | None,
        interrupt_source: InterruptTokenSource | None = None,
    ) -> ExecutionNode:
        agent_name: str = data["agent_name"]
        node_id: str = data["node_id"]
        persistent_key: str | None = data.get("persistent_key") or data.get("storage_key")
        defn = self.__registry.get(agent_name)

        parent_services = parent.scope.get_services() if parent else {}
        merged = {**self.__services, **parent_services}
        if interrupt_source is not None:
            merged[InterruptToken] = interrupt_source.token

        tr = self.__type_by_tag(agent_name)
        raw_agent_spec = data.get("agent_spec")
        agent_spec = deserialize_value(raw_agent_spec, tr) if raw_agent_spec is not None else None

        tag: str | None = data.get("tag")
        self.__engine.inject_exec_context(merged, agent_name, defn, agent_spec, tag, parent)

        scope = self.__create_scope(merged)
        instance = self.__create_instance(defn, scope, merged, agent_spec)
        await self.__init_node(scope, persistent_key, node_id, agent_name)

        raw_spec = data.get("pending_spec")
        raw_result = data.get("result")
        raw_child_results = data.get("child_results")

        child_results: list[CollectedResult] | None = None
        if raw_child_results is not None:
            child_results = []
            for raw_cr in raw_child_results:
                cr_agent = raw_cr["agent_name"]
                cr_tr = self.__type_by_tag(cr_agent)
                child_results.append(
                    CollectedResult(
                        agent_name=cr_agent,
                        result=deserialize_value(raw_cr["result"], cr_tr),
                        tag=raw_cr.get("tag"),
                    )
                )

        raw_spawn_tree = data.get("spawn_tree")

        emitter = merged.get(HookEmitter)
        node = ExecutionNode(
            node_id=node_id,
            persistent_key=persistent_key,
            agent_name=agent_name,
            defn=defn,
            instance=instance,
            scope=scope,
            status=ExecutionStatus(data["status"]),
            pending_step=data.get("pending_step"),
            pending_spec=deserialize_value(raw_spec, tr) if raw_spec is not None else None,
            then_step=data.get("then_step"),
            goto_counter=data.get("goto_counter", 0),
            result=deserialize_value(raw_result, tr) if raw_result is not None else None,
            child_results=child_results,
            parent=parent,
            tag=data.get("tag"),
            agent_spec=agent_spec,
            interrupt_source=interrupt_source,
            spawn_tree=deserialize_spawn_tree(raw_spawn_tree) if raw_spawn_tree is not None else None,
            emitter=emitter if isinstance(emitter, HookEmitter) else None,
        )

        children_data = data.get("children")
        if children_data is not None:
            node.children = []
            for child_data in children_data:
                child_source = interrupt_source.create_child() if interrupt_source is not None else None
                child_node = await self.__restore_tree(child_data, parent=node, interrupt_source=child_source)
                node.children.append(child_node)

        return node

    @staticmethod
    def __build_type_registries(registry: AgentRegistry) -> dict[str, dict[str, type]]:
        return {agent_name: defn.type_registry for agent_name, defn in registry.all_named_definitions()}

    def __type_by_tag(self, agent_name: str) -> dict[str, type]:
        return self.__type_registries.get(agent_name, {})

    def __tag_by_type(self, agent_name: str) -> dict[type, str]:
        return {v: k for k, v in self.__type_by_tag(agent_name).items()}

    async def __next_run_id(self) -> int:
        assert self.__storage is not None
        meta = await self.__storage.load_node_state("__node__:__meta") or {}
        run_id = meta.get("run_counter", 0) + 1
        await self.__storage.save_node_state("__node__:__meta", ChangeSet(scalars={"run_counter": run_id}, appends={}))
        return run_id

    def __create_scope(self, parent_services: dict[type, Any], persistent: ScopeData | None = None) -> RuntimeScope:
        return RuntimeScope(
            parent_services=parent_services,
            named_scope_registry=self.__named_scope_registry,
            persistent=persistent,
        )

    def __create_instance(
        self, defn: AgentDefinition, scope: RuntimeScope, services: dict[type, Any], agent_spec: Any | None = None
    ) -> AgentInstance:
        return create_instance_sealed(defn, scope, services, agent_spec)

    async def __init_node(self, scope: RuntimeScope, persistent_key: str | None, node_id: str, agent_name: str) -> None:
        if self.__storage is None:
            return
        storage = self.__storage
        tr = self.__type_by_tag(agent_name)
        tt = self.__tag_by_type(agent_name)

        # Hydrate ephemeral scope (keyed by node_id)
        eph_key = f"__ephemeral__:{node_id}"
        eph_state = await storage.load_node_state(eph_key)
        if eph_state:
            deserialized = {k: deserialize_value(v, tr) for k, v in eph_state.items()}
            scope.ephemeral.hydrate(deserialized)
            scope.ephemeral.mark_clean()

        # Hydrate persistent scope (keyed by persistent_key)
        if persistent_key is not None:
            p_key = f"__node__:{persistent_key}"
            p_state = await storage.load_node_state(p_key)
            if p_state:
                deserialized = {k: deserialize_value(v, tr) for k, v in p_state.items()}
                scope.persistent.hydrate(deserialized)
                scope.persistent.mark_clean()

        # Hydrate named scopes discovered during agent construction
        registry = self.__named_scope_registry
        for scope_name, named_scope in registry.all_scopes().items():
            if not registry.is_hydrated(scope_name):
                ns_tr = named_scope.type_registry
                ns_state = await storage.load_node_state(scope_name)
                if ns_state:
                    deserialized = {k: deserialize_value(v, ns_tr) for k, v in ns_state.items()}
                    named_scope.hydrate(deserialized)
                    named_scope.mark_clean()
                registry.mark_hydrated(scope_name)

        async def flush_cb() -> None:
            changes = scope.persistent.get_changes()
            if persistent_key is not None and not changes.empty:
                p_key = f"__node__:{persistent_key}"
                serialized = ChangeSet(
                    scalars={k: serialize_value(v, tt) for k, v in changes.scalars.items()},
                    appends={k: [serialize_value(item, tt) for item in v] for k, v in changes.appends.items()},
                )
                async with storage.begin_transaction():
                    await storage.save_node_state(p_key, serialized)
                scope.persistent.mark_clean()

        scope.set_flush_callback(flush_cb)
