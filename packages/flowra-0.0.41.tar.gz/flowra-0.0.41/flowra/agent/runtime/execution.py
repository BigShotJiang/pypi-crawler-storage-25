import dataclasses
import enum
from typing import Any

from ..definition import AgentDefinition, AgentInstance
from ..flow import HookEmitter, InterruptTokenSource
from .scope import RuntimeScope
from .spawn_tree import SpawnTreeNode

__all__ = [
    "CollectedResult",
    "ExecutionNode",
    "ExecutionStatus",
]


class ExecutionStatus(enum.StrEnum):
    PENDING_STEP = "pending_step"
    WAITING_CHILDREN = "waiting_children"
    COMPLETED = "completed"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CollectedResult:
    agent_name: str
    result: Any
    tag: str | None = None


@dataclasses.dataclass(slots=True, kw_only=True)
class ExecutionNode:
    node_id: str
    persistent_key: str | None
    agent_name: str
    defn: AgentDefinition
    instance: AgentInstance
    scope: RuntimeScope
    status: ExecutionStatus

    pending_step: str | None = None
    pending_spec: Any | None = None
    children: "list[ExecutionNode] | None" = None
    child_results: list[CollectedResult] | None = None
    then_step: str | None = None
    result: Any | None = None
    goto_counter: int = 0
    parent: "ExecutionNode | None" = None
    tag: str | None = None
    agent_spec: Any | None = None
    interrupt_source: InterruptTokenSource | None = None
    spawn_tree: SpawnTreeNode | None = None
    # Transient (not serialized — rebuilt on resume)
    emitter: HookEmitter | None = None
    agent_span: Any | None = None
    step_span: Any | None = None
    flowing_snapshot: Any | None = None
