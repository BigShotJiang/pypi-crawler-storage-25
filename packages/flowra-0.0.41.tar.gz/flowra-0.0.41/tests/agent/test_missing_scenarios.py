"""Tests for scenarios identified as missing during code review."""

import dataclasses
from typing import ClassVar

import pytest

from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentInfo,
    AgentRuntime,
    AgentStore,
    CallAgent,
    ExecutionContext,
    ExecutionFrame,
    GotoStep,
    HookEmitter,
    HookSubscription,
    Scalar,
    Spawn,
    WhenN,
    step,
)
from flowra.agent.runtime.scope import NamedScopeRegistry, RuntimeScope

# -- Fixtures ------------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val:
    v: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Done:
    total: int


# -- 1. ServiceLocator.provide() error paths ----------------------------------


class TestServiceLocatorProvideErrors:
    def test_provide_zero_args_raises(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        with pytest.raises(TypeError, match="takes 1 or 2"):
            scope.provide()  # type: ignore[call-overload]

    def test_provide_three_args_raises(self) -> None:
        scope = RuntimeScope(named_scope_registry=NamedScopeRegistry())
        with pytest.raises(TypeError, match="takes 1 or 2"):
            scope.provide(str, "hello", "extra")  # type: ignore[call-arg]


# -- 2. GotoStep with ephemeral state -----------------------------------------


class GotoStepAgent(Agent[Val, Done]):
    def __init__(self, store: AgentStore) -> None:
        self.counter = store.ephemeral.slot(Scalar[int], "counter")

    @step(entry=True)
    async def start(self, spec: Val) -> GotoStep:
        self.counter.set(spec.v)
        return GotoStep(step=self.continued)

    @step
    async def continued(self) -> Done:
        current = self.counter.get(0)
        self.counter.set(current + 100)
        return Done(total=self.counter.get())


class TestGotoStepEphemeral:
    async def test_goto_step_preserves_ephemeral_state(self) -> None:
        runtime = AgentRuntime(agents={"agent": GotoStepAgent})
        result = await runtime.run(agent=GotoStepAgent, spec=Val(v=5))
        assert isinstance(result, Done)
        assert result.total == 105


# -- 3. max_iterations / timeout per-call override ----------------------------


class SlowAgent(Agent[None, Done]):
    @step(entry=True)
    async def start(self) -> GotoStep:
        return GotoStep(step=self.loop)

    @step
    async def loop(self) -> GotoStep:
        return GotoStep(step=self.loop)


class TestPerCallOverrides:
    async def test_max_iterations_per_call(self) -> None:
        runtime = AgentRuntime(agents={"slow": SlowAgent})
        with pytest.raises(RuntimeError, match="max_iterations"):
            await runtime.run(agent=SlowAgent, max_iterations=3)

    async def test_timeout_per_call(self) -> None:
        runtime = AgentRuntime(agents={"slow": SlowAgent})
        with pytest.raises(TimeoutError):
            await runtime.run(agent=SlowAgent, timeout=0.05)

    async def test_per_call_overrides_constructor_default(self) -> None:
        runtime = AgentRuntime(agents={"slow": SlowAgent}, max_iterations=1000)
        with pytest.raises(RuntimeError, match="max_iterations"):
            await runtime.run(agent=SlowAgent, max_iterations=2)


# -- 5. WhenN(n=0) — trivially satisfied --------------------------------------


class InstantAgent(Agent[Val, Done]):
    @step(entry=True)
    async def run(self, spec: Val) -> Done:
        return Done(total=spec.v)


class WhenN0Orchestrator(Agent[None, Done]):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"instant": InstantAgent}

    @step(entry=True)
    async def start(self) -> Spawn:
        return Spawn(
            WhenN(
                CallAgent(agent=InstantAgent, spec=Val(v=1), state="i1"),
                CallAgent(agent=InstantAgent, spec=Val(v=2), state="i2"),
                n=0,
            ),
            then=self.collect,
        )

    @step
    async def collect(self) -> Done:
        return Done(total=0)


class TestWhenN0:
    async def test_when_n_zero_completes(self) -> None:
        runtime = AgentRuntime(agents={"orch": WhenN0Orchestrator, "instant": InstantAgent})
        result = await runtime.run(agent=WhenN0Orchestrator)
        assert isinstance(result, Done)
        assert result.total == 0


# -- 6. get_frame() without criteria raises TypeError --------------------------


class TestGetFrameNoCriteria:
    def test_raises_type_error(self) -> None:

        info = AgentInfo(name="test", path="test", source_type=None, parent=None)
        frame = ExecutionFrame(agent=info)
        ctx = ExecutionContext(frame=frame, stack=(frame,))
        with pytest.raises(TypeError, match="At least one"):
            ctx.get_frame()  # type: ignore[call-overload]


# -- 7. propagate_to with only + exclude simultaneously -----------------------


class TestPropagateToOnlyAndExclude:
    async def test_only_and_exclude_combined(self) -> None:

        @dataclasses.dataclass(slots=True, kw_only=True)
        class EventA:
            v: int

        @dataclasses.dataclass(slots=True, kw_only=True)
        class EventB:
            v: int

        @dataclasses.dataclass(slots=True, kw_only=True)
        class EventC:
            v: int

        info = AgentInfo(name="test", path="test", source_type=None, parent=None)
        frame = ExecutionFrame(agent=info)
        ctx = ExecutionContext(frame=frame, stack=(frame,))

        source_sub = HookSubscription()
        target_sub = HookSubscription()

        received_a: list[int] = []
        received_b: list[int] = []
        received_c: list[int] = []

        target_sub.on(EventA, lambda e: received_a.append(e.data.v))
        target_sub.on(EventB, lambda e: received_b.append(e.data.v))
        target_sub.on(EventC, lambda e: received_c.append(e.data.v))

        # Register handlers on source so propagation has types to work with
        source_sub.on(EventA, lambda e: None)
        source_sub.on(EventB, lambda e: None)
        source_sub.on(EventC, lambda e: None)

        source = HookEmitter(source_sub.get_handlers(), ctx)
        target = HookEmitter(target_sub.get_handlers(), ctx)

        # only=[A, B], exclude=[B] → should forward only A
        source.propagate_to(target, only=[EventA, EventB], exclude=[EventB])

        await source.emit(EventA(v=1))
        await source.emit(EventB(v=2))
        await source.emit(EventC(v=3))

        assert received_a == [1]
        assert received_b == []
        assert received_c == []
