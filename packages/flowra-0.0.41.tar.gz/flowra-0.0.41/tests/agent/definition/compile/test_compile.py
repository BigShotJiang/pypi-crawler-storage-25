import abc
import dataclasses
from typing import Annotated, Any, get_origin

import pytest

from flowra.agent import (
    Agent,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    CallStep,
    ChildOutput,
    GotoStep,
    Scalar,
    Scope,
    ServiceLocator,
    Spawn,
    agent_arg,
    step,
    step_arg,
)
from flowra.agent.definition import AgentDefinition
from flowra.agent.definition.compile import compile_agent

# -- Test fixtures ------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatSpec:
    message: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatResult:
    reply: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SubResult:
    value: int


class _FakeScope(Scope):
    def slot(self, cls: Any, key: str) -> Any:
        origin = get_origin(cls) or cls
        if origin is Scalar:
            return Scalar()
        if origin is AppendOnlyList:
            return AppendOnlyList()
        raise TypeError(f"Unknown slot type: {cls}")


class FakeAgentStore(AgentStore):
    def __init__(self) -> None:
        self._ephemeral = _FakeScope()
        self._persistent = _FakeScope()

    @property
    def ephemeral(self) -> Scope:
        return self._ephemeral

    @property
    def persistent(self) -> Scope:
        return self._persistent

    def scope(self, name: str) -> Scope:
        raise NotImplementedError

    async def flush(self) -> None:
        pass


class FakeServiceLocator(ServiceLocator):
    def __init__(self) -> None:
        self._store = FakeAgentStore()
        self.__services: dict[type, Any] = {AgentStore: self._store, ServiceLocator: self}

    def _do_provide(self, service_type: type, instance: Any) -> None:
        self.__services[service_type] = instance

    @property
    def services(self) -> dict[type, Any]:
        return dict(self.__services)


class SomeService:
    pass


# -- Specs and Results for agent contract tests --------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ExprSpec:
    expression: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class HelpSpec:
    topic: str = "general"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PromptResult:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class QuitResult:
    pass


type CalcSpec = ExprSpec | HelpSpec
type CalcResult = PromptResult | QuitResult


# -- Test agents (plain classes with @step) -----------------------------------


class SimpleAgent(Agent[ChatSpec, ChatResult]):
    @step(entry=True)
    async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
        return ChatResult(reply=f"echo: {spec.message}")


class AgentWithDI(Agent[ChatSpec, ChatResult]):
    def __init__(self, service: SomeService) -> None:
        self.service = service

    @step(entry=True)
    async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
        return ChatResult(reply="with_di")


class AgentWithServices(Agent[None, ChatResult]):
    def __init__(self, services: ServiceLocator) -> None:
        self.services_loc = services

    @step(entry=True)
    async def start(self) -> ChatResult:
        return ChatResult(reply=f"services={len(self.services_loc.services)}")


class MultiStepAgent(Agent[ChatSpec, ChatResult]):
    @step(entry=True)
    async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> GotoStep:
        return GotoStep(step="finish")

    @step
    async def finish(self) -> ChatResult:
        return ChatResult(reply="done")


class JoinAgent(Agent[ChatSpec, ChatResult]):
    @step(entry=True)
    async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
        return ChatResult(reply="start")

    @step
    async def collect(self, results: Annotated[list[SubResult], step_arg.CHILD]) -> ChatResult:
        total = sum(r.value for r in results)
        return ChatResult(reply=f"total={total}")

    @step
    async def single(self, result: Annotated[SubResult, step_arg.CHILD]) -> ChatResult:
        return ChatResult(reply=f"got={result.value}")


class ParentAgent(Agent[ChatSpec, ChatResult]):
    @step(entry=True)
    async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
        return ChatResult(reply="parent")


class InheritedAgent(ParentAgent):
    @step
    async def added(self) -> ChatResult:
        return ChatResult(reply="added")


class OverridingAgent(ParentAgent):
    @step("start")
    async def start_v2(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
        return ChatResult(reply="overridden")


# -- Tests: compile_agent ----------------------------------------------------


class TestCompileAgent:
    def test_returns_agent_definition(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert isinstance(defn, AgentDefinition)

    def test_steps(self) -> None:
        defn = compile_agent(MultiStepAgent)
        assert set(defn.steps) == {"start", "finish"}

    def test_step_spec_types(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert defn.steps["start"].spec_types == frozenset({ChatSpec})

    def test_step_without_spec(self) -> None:
        defn = compile_agent(MultiStepAgent)
        assert defn.steps["finish"].spec_types == frozenset()

    def test_invalid_return_type_raises(self) -> None:
        with pytest.raises(TypeError, match="not a valid StepResult"):

            class Bad(Agent[None, None]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)  # type: ignore[arg-type]
                async def x(self) -> CallStep:
                    return CallStep(step="y")

    def test_inherits_steps(self) -> None:
        defn = compile_agent(InheritedAgent)
        assert set(defn.steps) == {"start", "added"}

    def test_overrides_step(self) -> None:
        defn = compile_agent(OverridingAgent)
        assert set(defn.steps) == {"start"}


# -- Tests: create + call_step -----------------------------------------------


class TestAgentInstance:
    async def test_call_step_with_spec(self) -> None:
        defn = compile_agent(SimpleAgent)
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start", ChatSpec(message="hello"))
        assert isinstance(result, ChatResult)
        assert result.reply == "echo: hello"

    async def test_unknown_step_raises(self) -> None:
        defn = compile_agent(SimpleAgent)
        instance = defn.create_instance(FakeServiceLocator())
        with pytest.raises(RuntimeError, match="not found"):
            await instance.call_step("nonexistent")


# -- Tests: create with DI ---------------------------------------------------


class TestDI:
    async def test_injects_service(self) -> None:
        svc = SomeService()
        defn = compile_agent(AgentWithDI)
        sl = FakeServiceLocator()
        sl.provide(SomeService, svc)
        instance = defn.create_instance(sl)
        result = await instance.call_step("start", ChatSpec(message="hi"))
        assert isinstance(result, ChatResult)

    async def test_injects_service_locator(self) -> None:
        defn = compile_agent(AgentWithServices)
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)


# -- Tests: call_step --------------------------------------------------------


class TestCallStep:
    async def test_goto_step(self) -> None:
        defn = compile_agent(MultiStepAgent)
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start", ChatSpec(message="hi"))
        assert isinstance(result, GotoStep)
        assert result.step == "finish"

        result2 = await instance.call_step("finish")
        assert isinstance(result2, ChatResult)
        assert result2.reply == "done"

    async def test_join_step_with_list(self) -> None:
        defn = compile_agent(JoinAgent)
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=SubResult(value=10)), ChildOutput(result=SubResult(value=20))]
        result = await instance.call_step("collect", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "total=30"

    async def test_join_step_with_single_result(self) -> None:
        defn = compile_agent(JoinAgent)
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=SubResult(value=42))]
        result = await instance.call_step("single", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "got=42"

    async def test_join_empty_list(self) -> None:
        defn = compile_agent(JoinAgent)
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("collect")
        assert isinstance(result, ChatResult)
        assert result.reply == "total=0"


# -- Tests: compile_agent with subagents -------------------------------------


class TestCompileWithSubagents:
    def test_subagents_stored_in_definition(self) -> None:
        sub_defn = compile_agent(SimpleAgent)
        defn = compile_agent(SimpleAgent, subagents={"helper": sub_defn})
        assert "helper" in defn.subagents
        assert defn.subagents["helper"] is sub_defn


# -- Tests: StepMeta.result_types extraction ---------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class OtherResult:
    value: int


type _AliasResult = ChatResult | OtherResult
type _InnerAlias = ChatResult | OtherResult
type _OuterAlias = _InnerAlias | GotoStep | None
type _AliasA = ChatResult | GotoStep
type _AliasB = OtherResult | None


class TestResultTypesExtraction:
    def test_single_result_type(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert ChatResult in defn.steps["start"].result_types

    def test_multiple_result_types(self) -> None:
        class MultiResultAgent(Agent[None, ChatResult | OtherResult]):
            @step(entry=True)
            async def run(self) -> ChatResult | OtherResult | None:
                return None

        assert MultiResultAgent.__agent_definition__.steps["run"].result_types == frozenset({ChatResult, OtherResult})

    def test_no_result_type(self) -> None:
        class NoneAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def start(self) -> GotoStep:
                return GotoStep(step="work")

            @step
            async def work(self) -> ChatResult:
                return ChatResult(reply="ok")

        assert NoneAgent.__agent_definition__.steps["start"].result_types == frozenset()

    def test_type_alias_return_type(self) -> None:
        class AliasAgent(Agent[None, ChatResult | OtherResult]):
            @step(entry=True)
            async def run(self) -> _AliasResult:
                return ChatResult(reply="ok")

        assert AliasAgent.__agent_definition__.steps["run"].result_types == frozenset({ChatResult, OtherResult})

    def test_nested_type_alias_return_type(self) -> None:
        class NestedAliasAgent(Agent[None, ChatResult | OtherResult]):
            @step(entry=True)
            async def run(self) -> _OuterAlias:
                return ChatResult(reply="ok")

        assert NestedAliasAgent.__agent_definition__.steps["run"].result_types == frozenset({ChatResult, OtherResult})

    def test_union_of_type_aliases(self) -> None:
        class UnionAliasAgent(Agent[None, ChatResult | OtherResult]):
            @step(entry=True)
            async def run(self) -> _AliasA | _AliasB:
                return ChatResult(reply="ok")

        assert UnionAliasAgent.__agent_definition__.steps["run"].result_types == frozenset({ChatResult, OtherResult})


# -- Tests: Abstract service DI ----------------------------------------------


class TestAbstractServiceDI:
    async def test_service_registered_under_abstract_type(self) -> None:
        class AbstractService(abc.ABC):
            @abc.abstractmethod
            def value(self) -> str: ...

        class ConcreteService(AbstractService):
            def value(self) -> str:
                return "concrete"

        class AgentWithAbstract(Agent[None, ChatResult]):
            def __init__(self, svc: AbstractService) -> None:
                self.svc = svc

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=self.svc.value())

        defn = AgentWithAbstract.__agent_definition__
        svc = ConcreteService()
        sl = FakeServiceLocator()
        sl.provide(AbstractService, svc)
        instance = defn.create_instance(sl)
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "concrete"


# -- Tests: Optional service DI ---------------------------------------------


class TestOptionalServiceDI:
    async def test_optional_service_injected_when_provided(self) -> None:
        class AgentWithOptional(Agent[None, ChatResult]):
            def __init__(self, svc: SomeService | None) -> None:
                self.svc = svc

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"has_svc={self.svc is not None}")

        defn = AgentWithOptional.__agent_definition__
        svc = SomeService()
        sl = FakeServiceLocator()
        sl.provide(SomeService, svc)
        instance = defn.create_instance(sl)
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "has_svc=True"

    async def test_optional_service_none_when_not_provided(self) -> None:
        class AgentWithOptional(Agent[None, ChatResult]):
            def __init__(self, svc: SomeService | None = None) -> None:
                self.svc = svc

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"has_svc={self.svc is not None}")

        defn = AgentWithOptional.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "has_svc=False"

    async def test_nullable_service_none_when_not_provided_no_default(self) -> None:
        """T | None without = None still gets None when service is missing."""

        class AgentWithNullable(Agent[None, ChatResult]):
            def __init__(self, svc: SomeService | None) -> None:
                self.svc = svc

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"has_svc={self.svc is not None}")

        defn = AgentWithNullable.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "has_svc=False"


# -- Tests: mixed child result type binding ----------------------------------


class TestMixedChildResults:
    async def test_ambiguous_single_result_raises(self) -> None:
        class AmbiguousAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def collect(self, result: Annotated[ChatResult, step_arg.CHILD]) -> ChatResult:
                return result

        defn = AmbiguousAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=ChatResult(reply="a")), ChildOutput(result=ChatResult(reply="b"))]
        with pytest.raises(RuntimeError, match="Ambiguous binding"):
            await instance.call_step("collect", None, child_outputs)

    async def test_wildcard_binding(self) -> None:
        class WildcardAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def collect(self, result: Annotated[Any, step_arg.CHILD]) -> ChatResult:
                assert isinstance(result, ChatResult)
                return result

        defn = WildcardAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=ChatResult(reply="matched"))]
        result = await instance.call_step("collect", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "matched"

    async def test_wildcard_list_matches_all(self) -> None:
        class WildcardListAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def collect(self, results: Annotated[list[Any], step_arg.CHILD]) -> ChatResult:
                return ChatResult(reply=f"count={len(results)}")

        defn = WildcardListAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=ChatResult(reply="a")), ChildOutput(result=SubResult(value=1))]
        result = await instance.call_step("collect", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "count=2"

    async def test_intermediate_base_type_matches_subtree(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class BaseResult:
            tag: str

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ChildResultA(BaseResult):
            pass

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ChildResultB(BaseResult):
            pass

        class SubtreeAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def collect(self, results: Annotated[list[BaseResult], step_arg.CHILD]) -> ChatResult:
                return ChatResult(reply=",".join(r.tag for r in results))

        defn = SubtreeAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [
            ChildOutput(result=ChildResultA(tag="a")),
            ChildOutput(result=ChildResultB(tag="b")),
            ChildOutput(result=ChatResult(reply="skip")),  # not a BaseResult — should be filtered out
        ]
        result = await instance.call_step("collect", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "a,b"

    async def test_single_result_picks_correct_type(self) -> None:
        class MixedAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def collect(
                self,
                chat: Annotated[ChatResult, step_arg.CHILD],
                other: Annotated[OtherResult, step_arg.CHILD],
            ) -> ChatResult:
                return ChatResult(reply=f"{chat.reply},{other.value}")

        defn = MixedAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=OtherResult(value=42)), ChildOutput(result=ChatResult(reply="hi"))]
        result = await instance.call_step("collect", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "hi,42"


# -- Tests: Spawn with undecorated then -------------------------------------


class TestSpawnUndecoratedThen:
    def test_undecorated_then_raises(self) -> None:
        def plain() -> None:
            pass

        with pytest.raises(TypeError, match="not a @step-decorated method"):
            Spawn(children=[], then=plain)  # type: ignore[arg-type]


# -- Tests: sync steps -------------------------------------------------------


class SyncSimpleAgent(Agent[ChatSpec, ChatResult]):
    @step(entry=True)
    def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:  # type: ignore[arg-type]
        return ChatResult(reply=f"sync: {spec.message}")


class SyncMultiStepAgent(Agent[None, ChatResult]):
    @step(entry=True)
    def start(self) -> GotoStep:  # type: ignore[arg-type]
        return GotoStep(step="finish")

    @step
    def finish(self) -> ChatResult:  # type: ignore[arg-type]
        return ChatResult(reply="sync done")


class TestSyncSteps:
    async def test_sync_step_returns_result(self) -> None:
        defn = compile_agent(SyncSimpleAgent)
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start", ChatSpec(message="hello"))
        assert isinstance(result, ChatResult)
        assert result.reply == "sync: hello"

    async def test_sync_step_returns_goto(self) -> None:
        defn = compile_agent(SyncMultiStepAgent)
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, GotoStep)
        assert result.step == "finish"

        result2 = await instance.call_step("finish")
        assert isinstance(result2, ChatResult)
        assert result2.reply == "sync done"


# -- Tests: static slot compilation ------------------------------------------


class TestSlotInConstructor:
    def test_scalar_slot_in_constructor(self) -> None:
        class AgentWithScalar(Agent[None, ChatResult]):
            def __init__(self, store: AgentStore) -> None:
                self.count = store.ephemeral.slot(Scalar[int], "count")

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = AgentWithScalar.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        assert instance is not None

    def test_append_only_slot_in_constructor(self) -> None:
        class AgentWithList(Agent[None, ChatResult]):
            def __init__(self, store: AgentStore) -> None:
                self.history = store.ephemeral.slot(AppendOnlyList[str], "history")

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = AgentWithList.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        assert instance is not None


# -- Tests: slot containers created on instance -------------------------------


class TestSlotContainers:
    async def test_scalar_slot_usable(self) -> None:
        class CounterAgent(Agent[None, ChatResult]):
            def __init__(self, store: AgentStore) -> None:
                self.count = store.ephemeral.slot(Scalar[int], "count")

            @step(entry=True)
            async def start(self) -> ChatResult:
                self.count.set(42)
                return ChatResult(reply=f"count={self.count.get()}")

        defn = CounterAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "count=42"

    async def test_append_only_slot_usable(self) -> None:
        class LogAgent(Agent[None, ChatResult]):
            def __init__(self, store: AgentStore) -> None:
                self.log = store.ephemeral.slot(AppendOnlyList[str], "log")

            @step(entry=True)
            async def start(self) -> ChatResult:
                self.log.append("hello")
                self.log.append("world")
                return ChatResult(reply=f"log={self.log.get_all()}")

        defn = LogAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "log=['hello', 'world']"

    async def test_slots_isolated_between_instances(self) -> None:
        class StatefulAgent(Agent[None, ChatResult]):
            def __init__(self, store: AgentStore) -> None:
                self.count = store.ephemeral.slot(Scalar[int], "count")

            @step(entry=True)
            async def start(self) -> ChatResult:
                if self.count.has_value():
                    return ChatResult(reply=f"existing={self.count.get()}")
                self.count.set(1)
                return ChatResult(reply="new")

        defn = StatefulAgent.__agent_definition__
        i1 = defn.create_instance(FakeServiceLocator())
        i2 = defn.create_instance(FakeServiceLocator())

        r1 = await i1.call_step("start")
        assert isinstance(r1, ChatResult)
        assert r1.reply == "new"

        r2 = await i2.call_step("start")
        assert isinstance(r2, ChatResult)
        assert r2.reply == "new"


# -- Tests: type_registry ----------------------------------------------------


class TestTypeRegistry:
    def test_registers_step_spec(self) -> None:
        defn = SimpleAgent.__agent_definition__
        assert ChatSpec.__qualname__ in defn.type_registry
        assert defn.type_registry[ChatSpec.__qualname__] is ChatSpec

    def test_registers_result_types(self) -> None:
        defn = SimpleAgent.__agent_definition__
        assert ChatResult.__qualname__ in defn.type_registry
        assert defn.type_registry[ChatResult.__qualname__] is ChatResult

    def test_registers_multiple_result_types(self) -> None:
        class MultiAgent(Agent[None, ChatResult | OtherResult]):
            @step(entry=True)
            async def run(self) -> ChatResult | OtherResult | None:
                return None

        defn = MultiAgent.__agent_definition__
        assert ChatResult.__qualname__ in defn.type_registry
        assert OtherResult.__qualname__ in defn.type_registry

    def test_empty_type_registry_for_no_types(self) -> None:
        class MinimalAgent(Agent[None, None]):
            @step(entry=True)
            async def start(self) -> None:
                pass

        assert MinimalAgent.__agent_definition__.type_registry == {}

    def test_duplicate_qualname_raises(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class DupResult:
            v: int

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class DupResult2:
            v: str

        DupResult2.__qualname__ = DupResult.__qualname__

        with pytest.raises(ValueError, match="Duplicate type tag"):

            class AgentWithDup(Agent[None, DupResult | DupResult2]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)
                async def a(self) -> DupResult:
                    return DupResult(v=1)

                @step
                async def b(self) -> DupResult2:
                    return DupResult2(v="x")

    def test_distinct_qualnames_no_conflict(self) -> None:
        class _Ns1:
            @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
            class Shared:
                v: int

        class _Ns2:
            @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
            class Shared:
                v: str

        class Agent1(Agent[None, _Ns1.Shared | _Ns2.Shared]):
            @step(entry=True)
            async def a(self) -> _Ns1.Shared:
                return _Ns1.Shared(v=1)

            @step
            async def b(self) -> _Ns2.Shared:
                return _Ns2.Shared(v="x")

        defn = Agent1.__agent_definition__
        assert _Ns1.Shared.__qualname__ in defn.type_registry
        assert _Ns2.Shared.__qualname__ in defn.type_registry


# -- Tests: union/alias step params ------------------------------------------


type _UnionResult = ChatResult | SubResult


class TestUnionStepParams:
    async def test_union_param_picks_first_match(self) -> None:
        class AgentWithUnion(Agent[None, ChatResult]):
            @step(entry=True)
            async def run(self, result: Annotated[ChatResult | SubResult, step_arg.CHILD]) -> ChatResult:
                if isinstance(result, ChatResult):
                    return ChatResult(reply=f"chat:{result.reply}")
                return ChatResult(reply=f"sub:{result.value}")

        defn = AgentWithUnion.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=SubResult(value=7))]
        result = await instance.call_step("run", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "sub:7"

    async def test_type_alias_param(self) -> None:
        class AgentWithAlias(Agent[None, ChatResult]):
            @step(entry=True)
            async def run(self, result: Annotated[_UnionResult, step_arg.CHILD]) -> ChatResult:
                if isinstance(result, ChatResult):
                    return ChatResult(reply=f"chat:{result.reply}")
                return ChatResult(reply=f"sub:{result.value}")

        defn = AgentWithAlias.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=ChatResult(reply="hi"))]
        result = await instance.call_step("run", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "chat:hi"

    async def test_list_of_union_param(self) -> None:
        class AgentWithUnionList(Agent[None, ChatResult]):
            @step(entry=True)
            async def run(self, results: Annotated[list[ChatResult | SubResult], step_arg.CHILD]) -> ChatResult:
                return ChatResult(reply=f"count={len(results)}")

        defn = AgentWithUnionList.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=ChatResult(reply="a")), ChildOutput(result=SubResult(value=1))]
        result = await instance.call_step("run", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "count=2"

    async def test_list_of_alias_param(self) -> None:
        class AgentWithAliasList(Agent[None, ChatResult]):
            @step(entry=True)
            async def run(self, results: Annotated[list[_UnionResult], step_arg.CHILD]) -> ChatResult:
                return ChatResult(reply=f"count={len(results)}")

        defn = AgentWithAliasList.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [ChildOutput(result=ChatResult(reply="a")), ChildOutput(result=SubResult(value=1))]
        result = await instance.call_step("run", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "count=2"


# -- Tests: agent contract (generics + entry) --------------------------------


class TestAgentContract:
    def test_single_spec_single_result(self) -> None:
        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
                return ChatResult(reply=spec.message)

        defn = MyAgent.__agent_definition__
        assert defn.entry_step == "run"
        assert defn.spec_types == frozenset({ChatSpec})
        assert defn.result_types == frozenset({ChatResult})

    def test_union_result(self) -> None:
        class MyAgent(Agent[ChatSpec, PromptResult | QuitResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> PromptResult | QuitResult:
                return PromptResult(text="hi")

        defn = MyAgent.__agent_definition__
        assert defn.spec_types == frozenset({ChatSpec})
        assert defn.result_types == frozenset({PromptResult, QuitResult})

    def test_type_alias_spec(self) -> None:
        class MyAgent(Agent[CalcSpec, PromptResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ExprSpec | HelpSpec, step_arg.SPEC]) -> PromptResult:
                return PromptResult(text="ok")

        defn = MyAgent.__agent_definition__
        assert defn.spec_types == frozenset({ExprSpec, HelpSpec})

    def test_type_alias_result(self) -> None:
        class MyAgent(Agent[ChatSpec, CalcResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> PromptResult | QuitResult:
                return PromptResult(text="ok")

        defn = MyAgent.__agent_definition__
        assert defn.result_types == frozenset({PromptResult, QuitResult})

    def test_type_alias_both(self) -> None:
        class MyAgent(Agent[CalcSpec, CalcResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ExprSpec | HelpSpec, step_arg.SPEC]) -> PromptResult:
                return PromptResult(text="ok")

        defn = MyAgent.__agent_definition__
        assert defn.spec_types == frozenset({ExprSpec, HelpSpec})
        assert defn.result_types == frozenset({PromptResult, QuitResult})


# -- Tests: bare Agent is rejected ------------------------------------------


class TestBareAgentRejected:
    def test_bare_agent_without_entry_raises(self) -> None:
        with pytest.raises(TypeError, match="must have exactly one @step\\(entry=True\\)"):

            class BadAgent(Agent):  # pyright: ignore[reportUnusedClass]
                @step
                async def work(self) -> ChatResult:
                    return ChatResult(reply="done")

    def test_bare_agent_without_generic_infers_types(self) -> None:
        class BareAgent(Agent):
            @step(entry=True)
            async def work(self) -> ChatResult:
                return ChatResult(reply="done")

        defn = BareAgent.__agent_definition__
        assert isinstance(defn, AgentDefinition)
        assert defn.result_types == frozenset({ChatResult})


# -- Tests: entry step with Spawn (result comes from different step) ---------


class TestEntryWithSpawn:
    def test_entry_returns_spawn(self) -> None:
        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> Spawn:
                return Spawn(children=[], then=self.finish)

            @step
            async def finish(self) -> ChatResult:
                return ChatResult(reply="done")

        defn = MyAgent.__agent_definition__
        assert defn.entry_step == "start"
        assert defn.spec_types == frozenset({ChatSpec})
        assert defn.result_types == frozenset({ChatResult})


# -- Tests: validation errors ------------------------------------------------


class TestValidationErrors:
    def test_generic_without_entry_raises(self) -> None:
        with pytest.raises(TypeError, match="must have exactly one @step\\(entry=True\\)"):

            class BadAgent1(Agent[ChatSpec, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step
                async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
                    return ChatResult(reply="x")

    def test_entry_without_generic_infers_types(self) -> None:
        class BareAgent2(Agent):
            @step(entry=True)
            async def run(self) -> ChatResult:
                return ChatResult(reply="x")

        defn = BareAgent2.__agent_definition__
        assert isinstance(defn, AgentDefinition)
        assert defn.result_types == frozenset({ChatResult})

    def test_multiple_entry_steps_raises(self) -> None:
        with pytest.raises(TypeError, match="multiple entry steps"):

            class BadAgent3(Agent[ChatSpec, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)
                async def run1(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
                    return ChatResult(reply="x")

                @step(entry=True)
                async def run2(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
                    return ChatResult(reply="y")

    def test_entry_spec_mismatch_raises(self) -> None:
        with pytest.raises(TypeError, match="spec types"):

            class BadAgent4(Agent[ChatSpec, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)
                async def run(self, spec: Annotated[ExprSpec, step_arg.SPEC]) -> ChatResult:
                    return ChatResult(reply="x")

    def test_call_step_return_type_raises(self) -> None:
        with pytest.raises(TypeError, match="not a valid StepResult"):

            class BadAgent5(Agent[None, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)  # type: ignore[arg-type]
                async def run(self) -> CallStep:
                    return CallStep(step="x")

    def test_call_agent_return_type_raises(self) -> None:
        with pytest.raises(TypeError, match="not a valid StepResult"):

            class BadAgent6(Agent[None, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)  # type: ignore[arg-type]
                async def run(self) -> CallAgent:
                    return CallAgent(agent="x")


# -- Tests: None / None ------------------------------------------------


class TestNoneNone:
    def test_no_spec_agent(self) -> None:
        class MyAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def run(self) -> ChatResult:
                return ChatResult(reply="done")

        defn = MyAgent.__agent_definition__
        assert defn.entry_step == "run"
        assert defn.spec_types == frozenset()
        assert defn.result_types == frozenset({ChatResult})

    def test_no_result_agent(self) -> None:
        class MyAgent(Agent[ChatSpec, None]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> None:
                pass

        defn = MyAgent.__agent_definition__
        assert defn.entry_step == "run"
        assert defn.spec_types == frozenset({ChatSpec})
        assert defn.result_types == frozenset()

    def test_no_spec_no_result_agent(self) -> None:
        class MyAgent(Agent[None, None]):
            @step(entry=True)
            async def run(self) -> None:
                pass

        defn = MyAgent.__agent_definition__
        assert defn.entry_step == "run"
        assert defn.spec_types == frozenset()
        assert defn.result_types == frozenset()


# -- Tests: step meta --------------------------------------------------------


class TestStepMeta:
    def test_step_spec_types(self) -> None:
        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult:
                return ChatResult(reply="ok")

        meta = MyAgent.__agent_definition__.steps["run"]
        assert meta.spec_types == frozenset({ChatSpec})
        assert meta.result_types == frozenset({ChatResult})

    def test_step_without_spec(self) -> None:
        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def start(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> Spawn:
                return Spawn(children=[], then=self.finish)

            @step
            async def finish(self) -> ChatResult:
                return ChatResult(reply="done")

        meta = MyAgent.__agent_definition__.steps["finish"]
        assert meta.spec_types == frozenset()
        assert meta.result_types == frozenset({ChatResult})


# -- Tests: tag-based child result binding -----------------------------------


class TestTagBasedBinding:
    async def test_tag_based_child_result(self) -> None:
        class TagAgent(Agent[None, ChatResult]):
            @step(entry=True)
            async def collect(
                self,
                first: Annotated[ChatResult, step_arg.CHILD("first")],
                second: Annotated[SubResult, step_arg.CHILD("second")],
            ) -> ChatResult:
                return ChatResult(reply=f"{first.reply},{second.value}")

        defn = TagAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        child_outputs = [
            ChildOutput(result=SubResult(value=42), tag="second"),
            ChildOutput(result=ChatResult(reply="hi"), tag="first"),
        ]
        result = await instance.call_step("collect", None, child_outputs)
        assert isinstance(result, ChatResult)
        assert result.reply == "hi,42"


# -- Tests: AgentSpec binding -----------------------------------------------


class TestAgentSpecBinding:
    async def test_agent_spec_injected_into_constructor(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MyAgentSpec:
            name: str

        class SpecAgent(Agent[MyAgentSpec, ChatResult]):
            __slots__ = ("__spec",)

            def __init__(self, spec: MyAgentSpec) -> None:
                self.__spec = spec

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"agent_spec={self.__spec.name}")

        defn = SpecAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator(), MyAgentSpec(name="test"))
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "agent_spec=test"


# -- Tests: optional spec patterns ------------------------------------------


class TestOptionalSpecPatterns:
    def test_annotated_optional_inner(self) -> None:
        """Annotated[T | None, step_arg.SPEC] works."""

        class OptAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec | None, step_arg.SPEC]) -> ChatResult:
                if spec is not None:
                    return ChatResult(reply=spec.message)
                return ChatResult(reply="no spec")

        defn = OptAgent.__agent_definition__
        assert defn.steps["run"].spec_types == frozenset({ChatSpec})

    def test_annotated_optional_outer(self) -> None:
        """Annotated[T, step_arg.SPEC] | None works."""

        class OptAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC] | None) -> ChatResult:
                if spec is not None:
                    return ChatResult(reply=spec.message)
                return ChatResult(reply="no spec")

        defn = OptAgent.__agent_definition__
        assert defn.steps["run"].spec_types == frozenset({ChatSpec})


# -- Tests: step param/return type validation --------------------------------


class TestStepTypeValidation:
    def test_non_dataclass_param_raises(self) -> None:
        with pytest.raises(TypeError, match="must be a dataclass"):

            class BadAgent(Agent[None, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)
                async def run(self, something: str = "default") -> ChatResult:
                    return ChatResult(reply=something)

    def test_non_dataclass_param_in_union_raises(self) -> None:
        with pytest.raises(TypeError, match="must be a dataclass"):

            class BadAgent(Agent[None, ChatResult]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)
                async def run(self, spec: ChatSpec | str) -> ChatResult:  # type: ignore[arg-type]
                    return ChatResult(reply="x")

    def test_non_dataclass_return_type_raises(self) -> None:
        with pytest.raises(TypeError, match="must be a dataclass"):

            class BadAgent(Agent[None, None]):  # pyright: ignore[reportUnusedClass]
                @step(entry=True)  # type: ignore[arg-type]
                async def run(self) -> str:
                    return "hello"

    def test_dataclass_param_ok(self) -> None:
        class GoodAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def run(self, spec: ChatSpec) -> ChatResult:
                return ChatResult(reply="ok")

        defn = GoodAgent.__agent_definition__
        assert defn.entry_step == "run"

    def test_optional_dataclass_param_ok(self) -> None:
        class GoodAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def run(self, spec: ChatSpec | None) -> ChatResult:
                return ChatResult(reply="ok")

        defn = GoodAgent.__agent_definition__
        assert defn.entry_step == "run"


# -- Tests: agent_arg markers ------------------------------------------------


class TestAgentArgSpec:
    async def test_explicit_spec_marker(self) -> None:
        """Annotated[T, agent_arg.SPEC] forces spec binding."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MyConfig:
            name: str

        class MyAgent(Agent[MyConfig, ChatResult]):
            __slots__ = ("__config",)

            def __init__(self, config: Annotated[MyConfig, agent_arg.SPEC]) -> None:
                self.__config = config

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=self.__config.name)

        sl = FakeServiceLocator()
        # Even if MyConfig is also in services, SPEC marker wins
        sl.provide(MyConfig(name="from_service"))
        defn = MyAgent.__agent_definition__
        instance = defn.create_instance(sl, MyConfig(name="from_spec"))
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "from_spec"


class TestAgentArgService:
    async def test_explicit_service_marker(self) -> None:
        """Annotated[T, agent_arg.SERVICE] forces service binding even when type matches spec."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MyConfig:
            name: str

        class MyAgent(Agent[MyConfig, ChatResult]):
            __slots__ = ("__config",)

            def __init__(self, config: Annotated[MyConfig, agent_arg.SERVICE]) -> None:
                self.__config = config

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=self.__config.name)

        sl = FakeServiceLocator()
        sl.provide(MyConfig(name="from_service"))
        defn = MyAgent.__agent_definition__
        instance = defn.create_instance(sl, MyConfig(name="from_spec"))
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "from_service"

    async def test_service_marker_nullable_gets_none_when_missing(self) -> None:
        """Annotated[T | None, agent_arg.SERVICE] gets None when service not registered."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MyConfig:
            name: str

        class MyAgent(Agent[MyConfig, ChatResult]):
            __slots__ = ("__config",)

            def __init__(self, config: Annotated[MyConfig | None, agent_arg.SERVICE] = None) -> None:
                self.__config = config

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=str(self.__config))

        sl = FakeServiceLocator()
        defn = MyAgent.__agent_definition__
        # Pass spec, but SERVICE marker means it won't be bound from spec
        instance = defn.create_instance(sl, MyConfig(name="from_spec"))
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "None"


# -- Tests: nullable step param binding --------------------------------------


class TestNullableStepParamBinding:
    async def test_nullable_step_spec_gets_none(self) -> None:
        """Nullable step spec param gets None when no spec provided."""

        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def start(self, spec: ChatSpec | None = None) -> ChatResult:
                return ChatResult(reply=f"spec={spec}")

        defn = MyAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "spec=None"

    async def test_nullable_child_result_gets_none(self) -> None:
        """Nullable child result param gets None when no matching child output."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class WorkerResult:
            value: int

        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def start(self, spec: ChatSpec) -> Spawn:
                return Spawn(CallAgent(agent="w", tag="w"), then="join")

            @step
            async def join(self, result: WorkerResult | None = None) -> ChatResult:
                return ChatResult(reply=f"result={result}")

        defn = MyAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        result = await instance.call_step("join", None, [])
        assert isinstance(result, ChatResult)
        assert result.reply == "result=None"


# -- Tests: agent spec type mismatch in constructor --------------------------


class TestAgentSpecTypeMismatch:
    async def test_wrong_spec_type_nullable_gets_none(self) -> None:
        """Nullable spec param gets None when agent_spec type doesn't match."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MySpec:
            name: str

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class OtherSpec:
            value: int

        class MyAgent(Agent[MySpec, ChatResult]):
            __slots__ = ("__spec",)

            def __init__(self, spec: MySpec | None = None) -> None:
                self.__spec = spec

            @step(entry=True)
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"spec={self.__spec}")

        defn = MyAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator(), OtherSpec(value=42))
        result = await instance.call_step("start")
        assert isinstance(result, ChatResult)
        assert result.reply == "spec=None"


# -- Tests: step param binding without markers (ambiguous) -------------------


class TestStepParamAmbiguousBinding:
    async def test_spec_and_child_same_type_raises(self) -> None:
        """Unmarked param matching both spec and child output raises ambiguous error."""

        class MyAgent(Agent[ChatSpec, ChatResult]):
            @step(entry=True)
            async def start(self, spec: ChatSpec) -> Spawn:
                return Spawn(CallAgent(agent="w", tag="w"), then="join")

            @step
            async def join(self, result: ChatSpec) -> ChatResult:
                return ChatResult(reply=result.message)

        defn = MyAgent.__agent_definition__
        instance = defn.create_instance(FakeServiceLocator())
        with pytest.raises(RuntimeError, match="Ambiguous binding"):
            await instance.call_step(
                "join",
                ChatSpec(message="from_spec"),
                [ChildOutput(result=ChatSpec(message="from_child"))],
            )
