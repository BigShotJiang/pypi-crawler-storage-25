from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict

from .models import Artifact, RunRecord, StepRecord, StepStatus


@dataclass
class PipelineContext:
    run: RunRecord
    artifacts: Dict[str, Artifact] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.run, RunRecord):
            raise TypeError("PipelineContext.run must be a RunRecord instance.")
        if not isinstance(self.artifacts, dict):
            raise TypeError("PipelineContext.artifacts must be a dictionary.")

        normalized_artifacts: Dict[str, Artifact] = {}
        for key, value in self.artifacts.items():
            if not isinstance(key, str) or not key.strip():
                raise ValueError(
                    "PipelineContext.artifacts keys must be non-empty strings."
                )
            if not isinstance(value, Artifact):
                raise TypeError(
                    "PipelineContext.artifacts values must be Artifact instances."
                )
            normalized_artifacts[key] = value

        self.artifacts = normalized_artifacts

    @property
    def run_dir(self) -> Path:
        return Path(self.run.base_dir)

    @property
    def inputs_dir(self) -> Path:
        return self.run_dir / "inputs"

    @property
    def outputs_dir(self) -> Path:
        return self.run_dir / "outputs"

    @property
    def logs_dir(self) -> Path:
        return self.run_dir / "logs"

    @property
    def state_dir(self) -> Path:
        return self.run_dir / "state"

    def ensure_dirs(self) -> None:
        for d in (
            self.run_dir,
            self.inputs_dir,
            self.outputs_dir,
            self.logs_dir,
            self.state_dir,
        ):
            d.mkdir(parents=True, exist_ok=True)

    def add_artifact(self, artifact: Artifact, *, overwrite: bool = True) -> None:
        if not isinstance(artifact, Artifact):
            raise TypeError("add_artifact requires an Artifact instance.")

        existing = self.artifacts.get(artifact.name)
        if existing is not None and not overwrite:
            raise ValueError(
                f"Artifact {artifact.name!r} already exists and overwrite=False."
            )

        self.artifacts[artifact.name] = artifact

    def get_artifact(self, name: str) -> Artifact:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Artifact name must be a non-empty string.")

        if name not in self.artifacts:
            known = ", ".join(sorted(self.artifacts.keys()))
            raise KeyError(f"Artifact {name!r} not found. Known artifacts: {known}")
        return self.artifacts[name]

    def has_artifact(self, name: str) -> bool:
        if not isinstance(name, str) or not name.strip():
            return False
        return name in self.artifacts

    def to_dict(self) -> dict:
        return {
            "run": self.run.to_dict(),
            "artifacts": {k: v.to_dict() for k, v in self.artifacts.items()},
        }

    def save_state(self) -> Path:
        self.ensure_dirs()

        state_file = self.state_dir / "run_state.json"
        tmp_file = self.state_dir / "run_state.json.tmp"

        payload = self.to_dict()
        tmp_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp_file.replace(state_file)

        return state_file

    @classmethod
    def load_from_state(cls, state_file: str | Path) -> "PipelineContext":
        state_path = Path(state_file)

        if not state_path.exists():
            raise FileNotFoundError(f"State file not found: {state_path}")
        if not state_path.is_file():
            raise IsADirectoryError(
                f"Expected state file but found directory: {state_path}"
            )

        try:
            data = json.loads(state_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Failed to parse pipeline state JSON {state_path}: {exc}"
            ) from exc

        if not isinstance(data, dict):
            raise ValueError("Pipeline state payload must be a JSON object.")

        run_data = data.get("run")
        artifacts_data = data.get("artifacts", {})

        if not isinstance(run_data, dict):
            raise ValueError("Pipeline state is missing a valid 'run' object.")
        if not isinstance(artifacts_data, dict):
            raise ValueError("Pipeline state 'artifacts' must be a JSON object.")

        run = RunRecord(
            run_id=run_data["run_id"],
            project_name=run_data["project_name"],
            base_dir=run_data["base_dir"],
            workflow_name=run_data["workflow_name"],
            config=deepcopy(run_data["config"]),
            metadata=deepcopy(run_data.get("metadata", {})),
        )

        for step_data in run_data.get("steps", []):
            if not isinstance(step_data, dict):
                raise ValueError("Each saved step record must be a JSON object.")

            record = StepRecord(
                name=step_data["name"],
                status=StepStatus(step_data["status"]),
                started_at=step_data.get("started_at"),
                finished_at=step_data.get("finished_at"),
                error=step_data.get("error"),
                inputs=deepcopy(step_data.get("inputs", {})),
                log_file=step_data.get("log_file"),
            )

            outputs = step_data.get("outputs", {})
            if not isinstance(outputs, dict):
                raise ValueError(
                    f"Saved outputs for step {record.name!r} must be a JSON object."
                )

            for output_name, artifact_data in outputs.items():
                if not isinstance(artifact_data, dict):
                    raise ValueError(
                        f"Saved artifact {output_name!r} for step {record.name!r} "
                        "must be a JSON object."
                    )
                record.outputs[output_name] = Artifact(
                    name=artifact_data["name"],
                    path=artifact_data["path"],
                    kind=artifact_data["kind"],
                    metadata=deepcopy(artifact_data.get("metadata", {})),
                )

            run.steps.append(record)

        ctx_artifacts: Dict[str, Artifact] = {}
        for artifact_name, artifact_data in artifacts_data.items():
            if not isinstance(artifact_data, dict):
                raise ValueError(
                    f"Saved context artifact {artifact_name!r} must be a JSON object."
                )
            ctx_artifacts[artifact_name] = Artifact(
                name=artifact_data["name"],
                path=artifact_data["path"],
                kind=artifact_data["kind"],
                metadata=deepcopy(artifact_data.get("metadata", {})),
            )

        return cls(run=run, artifacts=ctx_artifacts)