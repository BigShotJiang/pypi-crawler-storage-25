from __future__ import annotations

from typing import Iterable, List

from .context import PipelineContext
from .models import StepStatus
from .step_base import PipelineStep


class PipelineRunner:
    def __init__(self, steps: Iterable[PipelineStep]) -> None:
        self.steps: List[PipelineStep] = list(steps)

        if not self.steps:
            raise ValueError("PipelineRunner requires at least one pipeline step.")

        seen_names: set[str] = set()
        for step in self.steps:
            if not isinstance(step, PipelineStep):
                raise TypeError(
                    "All pipeline runner steps must be PipelineStep instances. "
                    f"Got {type(step).__name__!r}."
                )

            step_name = getattr(step, "name", None)
            if not isinstance(step_name, str) or not step_name.strip():
                raise ValueError(
                    "Each pipeline step must define a non-empty string 'name'."
                )

            if step_name in seen_names:
                raise ValueError(
                    f"Duplicate pipeline step name detected: {step_name!r}."
                )
            seen_names.add(step_name)

    def run(self, ctx: PipelineContext, stop_on_failure: bool = True) -> PipelineContext:
        if not isinstance(ctx, PipelineContext):
            raise TypeError(
                "PipelineRunner.run requires a PipelineContext instance."
            )

        ctx.ensure_dirs()

        failed_record = None

        for step in self.steps:
            record = step.execute(ctx)
            ctx.run.steps.append(record)
            ctx.save_state()

            if record.status == StepStatus.FAILED:
                failed_record = record
                if stop_on_failure:
                    break

        if failed_record is not None and stop_on_failure:
            raise RuntimeError(
                "Pipeline execution failed at step "
                f"{failed_record.step_name!r}. "
                f"See run state and step logs under: {ctx.run.base_dir}"
            )

        return ctx