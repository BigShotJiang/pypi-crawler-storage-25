from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    CACHED = "cached"


@dataclass
class Artifact:
    name: str
    path: str
    kind: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("Artifact.name must be a non-empty string.")
        if not isinstance(self.path, str) or not self.path.strip():
            raise ValueError("Artifact.path must be a non-empty string.")
        if not isinstance(self.kind, str) or not self.kind.strip():
            raise ValueError("Artifact.kind must be a non-empty string.")
        if not isinstance(self.metadata, dict):
            raise TypeError("Artifact.metadata must be a dictionary.")

        self.name = self.name.strip()
        self.path = str(Path(self.path))
        self.kind = self.kind.strip()
        self.metadata = deepcopy(self.metadata)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "path": self.path,
            "kind": self.kind,
            "metadata": deepcopy(self.metadata),
        }


@dataclass
class StepRecord:
    name: str
    status: StepStatus = StepStatus.PENDING
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error: Optional[str] = None
    inputs: Dict[str, Any] = field(default_factory=dict)
    outputs: Dict[str, Artifact] = field(default_factory=dict)
    log_file: Optional[str] = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("StepRecord.name must be a non-empty string.")

        if isinstance(self.status, str):
            self.status = StepStatus(self.status)
        elif not isinstance(self.status, StepStatus):
            raise TypeError("StepRecord.status must be a StepStatus or valid status string.")

        if self.started_at is not None and not isinstance(self.started_at, str):
            raise TypeError("StepRecord.started_at must be a string or None.")
        if self.finished_at is not None and not isinstance(self.finished_at, str):
            raise TypeError("StepRecord.finished_at must be a string or None.")
        if self.error is not None and not isinstance(self.error, str):
            raise TypeError("StepRecord.error must be a string or None.")
        if self.log_file is not None and not isinstance(self.log_file, str):
            raise TypeError("StepRecord.log_file must be a string or None.")
        if not isinstance(self.inputs, dict):
            raise TypeError("StepRecord.inputs must be a dictionary.")
        if not isinstance(self.outputs, dict):
            raise TypeError("StepRecord.outputs must be a dictionary.")

        normalized_outputs: Dict[str, Artifact] = {}
        for key, value in self.outputs.items():
            if not isinstance(key, str) or not key.strip():
                raise ValueError("StepRecord.outputs keys must be non-empty strings.")
            if not isinstance(value, Artifact):
                raise TypeError(
                    "StepRecord.outputs values must be Artifact instances."
                )
            normalized_outputs[key] = value

        self.name = self.name.strip()
        self.inputs = deepcopy(self.inputs)
        self.outputs = normalized_outputs
        if self.log_file is not None:
            self.log_file = str(Path(self.log_file))

    @property
    def step_name(self) -> str:
        return self.name

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "step_name": self.name,
            "status": self.status.value,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "error": self.error,
            "inputs": deepcopy(self.inputs),
            "outputs": {k: v.to_dict() for k, v in self.outputs.items()},
            "log_file": self.log_file,
        }


@dataclass
class RunRecord:
    run_id: str
    project_name: str
    base_dir: str
    workflow_name: str
    config: Dict[str, Any]
    steps: List[StepRecord] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.run_id, str) or not self.run_id.strip():
            raise ValueError("RunRecord.run_id must be a non-empty string.")
        if not isinstance(self.project_name, str) or not self.project_name.strip():
            raise ValueError("RunRecord.project_name must be a non-empty string.")
        if not isinstance(self.base_dir, str) or not self.base_dir.strip():
            raise ValueError("RunRecord.base_dir must be a non-empty string.")
        if not isinstance(self.workflow_name, str) or not self.workflow_name.strip():
            raise ValueError("RunRecord.workflow_name must be a non-empty string.")
        if not isinstance(self.config, dict):
            raise TypeError("RunRecord.config must be a dictionary.")
        if not isinstance(self.steps, list):
            raise TypeError("RunRecord.steps must be a list.")
        if not isinstance(self.metadata, dict):
            raise TypeError("RunRecord.metadata must be a dictionary.")

        normalized_steps: List[StepRecord] = []
        for step in self.steps:
            if not isinstance(step, StepRecord):
                raise TypeError("RunRecord.steps entries must be StepRecord instances.")
            normalized_steps.append(step)

        self.run_id = self.run_id.strip()
        self.project_name = self.project_name.strip()
        self.base_dir = str(Path(self.base_dir))
        self.workflow_name = self.workflow_name.strip()
        self.config = deepcopy(self.config)
        self.steps = normalized_steps
        self.metadata = deepcopy(self.metadata)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "project_name": self.project_name,
            "base_dir": self.base_dir,
            "workflow_name": self.workflow_name,
            "config": deepcopy(self.config),
            "steps": [step.to_dict() for step in self.steps],
            "metadata": deepcopy(self.metadata),
        }