from __future__ import annotations

from typing import Any, List

from .step_base import PipelineStep
from .steps.assemble_system import AssembleSystemStep
from .steps.build_chain import BuildChainStep
from .steps.export_descriptor import ExportDescriptorStep
from .steps.export_generic_handoff import ExportGenericHandoffStep
from .steps.export_gromacs_handoff import ExportGromacsHandoffStep
from .steps.pack_nanoparticle import PackNanoparticleStep
from .steps.parameterize_chain import ParameterizeChainStep
from .steps.prepare_topology_bridge import PrepareTopologyBridgeStep
from .steps.assess_packed_nanoparticle import AssessPackedNanoparticleStep
from .steps.relax_packed_nanoparticle import RelaxPackedNanoparticleStep


REQUIRED_WORKFLOW_SECTIONS = (
    "build_chain",
    "parameterize_chain",
    "pack_nanoparticle",
    "assess_packed_nanoparticle",
    "assemble_system",
    "prepare_topology_bridge",
    "export_gromacs_handoff",
    "export_generic_handoff",
    "export_descriptor",
)


def _require_section(config: dict[str, Any], section_name: str) -> dict[str, Any]:
    value = config.get(section_name)
    if not isinstance(value, dict):
        raise ValueError(
            "Workflow configuration is missing required section "
            f"{section_name!r}, or the section is not a JSON object."
        )
    return value


def build_pack_workflow(config: dict[str, Any]) -> List[PipelineStep]:
    if not isinstance(config, dict):
        raise TypeError(
            "Workflow configuration must be a dictionary of workflow sections."
        )

    sections: dict[str, dict[str, Any]] = {}
    for name in REQUIRED_WORKFLOW_SECTIONS:
        sections[name] = _require_section(config, name)

    steps: List[PipelineStep] = [
        BuildChainStep(sections["build_chain"]),
        ParameterizeChainStep(sections["parameterize_chain"]),
        PackNanoparticleStep(sections["pack_nanoparticle"]),
        AssessPackedNanoparticleStep(sections["assess_packed_nanoparticle"]),
    ]

    if "relax_packed_nanoparticle" in config.get("workflow_config", {}):
        relax_config = config["workflow_config"]["relax_packed_nanoparticle"]
        steps.append(RelaxPackedNanoparticleStep(relax_config))

    steps.extend([
        AssembleSystemStep(sections["assemble_system"]),
        PrepareTopologyBridgeStep(sections["prepare_topology_bridge"]),
        ExportGromacsHandoffStep(sections["export_gromacs_handoff"]),
        ExportGenericHandoffStep(sections["export_generic_handoff"]),
        ExportDescriptorStep(sections["export_descriptor"]),
    ])
    return steps