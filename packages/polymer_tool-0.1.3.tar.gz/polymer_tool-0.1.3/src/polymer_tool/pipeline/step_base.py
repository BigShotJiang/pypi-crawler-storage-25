from __future__ import annotations

from abc import ABC, abstractmethod
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from .context import PipelineContext
from .models import StepRecord, StepStatus


class PipelineStep(ABC):
    name: str = "unnamed_step"

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        if config is None:
            config = {}
        if not isinstance(config, dict):
            raise TypeError(
                f"{self.__class__.__name__} config must be a dictionary, "
                f"got {type(config).__name__!r}."
            )

        step_name = getattr(self, "name", None)
        if not isinstance(step_name, str) or not step_name.strip():
            raise ValueError(
                f"{self.__class__.__name__} must define a non-empty string 'name'."
            )

        self.config = deepcopy(config)

    def make_record(self) -> StepRecord:
        return StepRecord(name=self.name, inputs=deepcopy(self.config))

    def get_log_path(self, ctx: PipelineContext) -> Path:
        return ctx.logs_dir / f"{self.name}.log"

    def timestamp(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def should_skip(self, ctx: PipelineContext) -> bool:
        return False

    def write_log(self, ctx: PipelineContext, message: str) -> None:
        log_path = self.get_log_path(ctx)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as fh:
            fh.write(message.rstrip() + "\n")

    @abstractmethod
    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        raise NotImplementedError

    def execute(self, ctx: PipelineContext) -> StepRecord:
        if not isinstance(ctx, PipelineContext):
            raise TypeError(
                f"{self.__class__.__name__}.execute requires a PipelineContext instance."
            )

        record = self.make_record()
        record.started_at = self.timestamp()
        record.log_file = str(self.get_log_path(ctx))

        self.write_log(ctx, f"[{record.started_at}] START {self.name}")
        self.write_log(ctx, f"[{record.started_at}] INPUTS {record.inputs}")

        try:
            if self.should_skip(ctx):
                record.status = StepStatus.SKIPPED
                self.write_log(ctx, f"[{self.timestamp()}] SKIP {self.name}")
            else:
                record.status = StepStatus.RUNNING
                self.write_log(ctx, f"[{self.timestamp()}] STATUS {self.name} -> running")
                self.run(ctx, record)

                if record.status == StepStatus.RUNNING:
                    record.status = StepStatus.COMPLETED

                self.write_log(
                    ctx,
                    f"[{self.timestamp()}] END {self.name} status={record.status.value}",
                )

        except Exception as exc:
            record.status = StepStatus.FAILED
            record.error = f"{type(exc).__name__}: {exc}"
            self.write_log(
                ctx,
                f"[{self.timestamp()}] FAIL {self.name} error={record.error}",
            )
            raise

        finally:
            record.finished_at = self.timestamp()
            self.write_log(
                ctx,
                f"[{record.finished_at}] FINISH {self.name} "
                f"status={record.status.value}",
            )

        return record