from __future__ import annotations

from polymer_tool.core.builder import build_plga_chain
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class BuildChainStep(PipelineStep):
    name = "build_chain"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        dp = int(self.config["dp"])
        lactic_fraction = float(self.config.get("lactic_fraction", 0.5))
        stereo_pattern = str(self.config.get("stereo_pattern", "alt_RS"))
        end_group = str(self.config.get("end_group", "ester"))
        sequence_mode = str(self.config.get("sequence_mode", "balanced"))

        random_seed = self.config.get("random_seed")
        if random_seed is not None:
            random_seed = int(random_seed)

        self.write_log(
            ctx,
            (
                "Build request: "
                f"dp={dp}, "
                f"lactic_fraction={lactic_fraction}, "
                f"stereo_pattern={stereo_pattern}, "
                f"end_group={end_group}, "
                f"sequence_mode={sequence_mode}, "
                f"random_seed={random_seed}"
            ),
        )

        result = build_plga_chain(
            dp=dp,
            lactic_fraction=lactic_fraction,
            stereo_pattern=stereo_pattern,
            end_group=end_group,
            sequence_mode=sequence_mode,
            random_seed=random_seed,
            out_prefix=str(out_dir / "chain"),
        )

        artifact_specs = (
            ("sdf", "chain_sdf", "structure"),
            ("pdb", "chain_pdb", "structure"),
            ("json", "chain_json", "metadata"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )