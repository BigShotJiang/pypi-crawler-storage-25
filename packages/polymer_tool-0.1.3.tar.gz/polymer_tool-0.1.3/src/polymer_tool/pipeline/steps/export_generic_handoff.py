from __future__ import annotations

from pathlib import Path

from polymer_tool.core.export_generic_handoff import export_generic_handoff
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


def _require_directory(path: str, label: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Expected {label} directory was not created: {p}")
    if not p.is_dir():
        raise NotADirectoryError(
            f"Expected {label} directory but found non-directory: {p}"
        )
    return p


class ExportGenericHandoffStep(PipelineStep):
    name = "export_generic_handoff"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        system_manifest_json = ctx.get_artifact("system_manifest_json").path
        components_json = ctx.get_artifact("components_json").path
        prep_report_json = ctx.get_artifact("prep_report_json").path
        packed_pdb = ctx.get_artifact("packed_pdb").path
        chain_parameterized_sdf = ctx.get_artifact("chain_parameterized_sdf").path
        bundle_name = str(
            self.config.get("bundle_name", "plga_np_generic_handoff_v1")
        )

        require_nonempty_file(
            system_manifest_json,
            f"{self.name}:input system_manifest_json",
        )
        require_nonempty_file(
            components_json,
            f"{self.name}:input components_json",
        )
        require_nonempty_file(
            prep_report_json,
            f"{self.name}:input prep_report_json",
        )
        require_nonempty_file(
            packed_pdb,
            f"{self.name}:input packed_pdb",
        )
        require_nonempty_file(
            chain_parameterized_sdf,
            f"{self.name}:input chain_parameterized_sdf",
        )

        self.write_log(
            ctx,
            (
                "Generic handoff export request: "
                f"system_manifest_json={system_manifest_json}, "
                f"components_json={components_json}, "
                f"prep_report_json={prep_report_json}, "
                f"packed_pdb={packed_pdb}, "
                f"chain_parameterized_sdf={chain_parameterized_sdf}, "
                f"bundle_name={bundle_name}"
            ),
        )

        result = export_generic_handoff(
            system_manifest_json=system_manifest_json,
            components_json=components_json,
            prep_report_json=prep_report_json,
            packed_pdb=packed_pdb,
            chain_parameterized_sdf=chain_parameterized_sdf,
            out_dir=str(out_dir),
            bundle_name=bundle_name,
        )

        artifact_specs = (
            ("generic_bundle_dir", "generic_bundle_dir", "bundle"),
            ("generic_export_manifest_json", "generic_export_manifest_json", "metadata"),
            ("generic_handoff_notes_txt", "generic_handoff_notes_txt", "metadata"),
            ("generic_bundle_checksums_json", "generic_bundle_checksums_json", "metadata"),
            ("generic_archive_targz", "generic_archive_targz", "archive"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            if kind == "bundle":
                _require_directory(path, f"{self.name}:{result_key}")
            else:
                require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )