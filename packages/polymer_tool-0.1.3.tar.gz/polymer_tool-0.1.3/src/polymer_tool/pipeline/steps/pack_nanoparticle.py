from __future__ import annotations

from polymer_tool.core.packmol_runner import pack_nanoparticle
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class PackNanoparticleStep(PipelineStep):
    name = "pack_nanoparticle"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        n_chains = int(self.config["n_chains"])
        shape = str(self.config.get("shape", "sphere"))
        radius_mode = str(self.config.get("radius_mode", "manual"))

        radius_angstrom = self.config.get("radius_angstrom")
        if radius_angstrom is not None:
            radius_angstrom = float(radius_angstrom)

        minimum_radius_angstrom = self.config.get("minimum_radius_angstrom")
        if minimum_radius_angstrom is not None:
            minimum_radius_angstrom = float(minimum_radius_angstrom)

        retry_scale_factors = self.config.get(
            "retry_scale_factors",
            [1.0, 1.2, 1.5, 2.0],
        )
        retry_scale_factors = [float(x) for x in retry_scale_factors]

        result = pack_nanoparticle(
            chain_pdb=ctx.get_artifact("chain_pdb").path,
            chain_json=ctx.get_artifact("chain_json").path,
            n_chains=n_chains,
            shape=shape,
            out_dir=str(out_dir),
            radius_mode=radius_mode,
            radius_angstrom=radius_angstrom,
            target_density_g_cm3=float(self.config.get("target_density_g_cm3", 1.25)),
            packing_slack_factor=float(self.config.get("packing_slack_factor", 1.25)),
            chain_size_factor=float(self.config.get("chain_size_factor", 1.20)),
            minimum_radius_angstrom=minimum_radius_angstrom,
            tolerance=float(self.config.get("tolerance", 2.0)),
            packmol_seed=self.config.get("packmol_seed"),
            retry_scale_factors=retry_scale_factors,
            packmol_maxit=int(self.config.get("packmol_maxit", 200)),
            packmol_nloop=int(self.config.get("packmol_nloop", 2000)),
            packmol_movefrac=float(self.config.get("packmol_movefrac", 0.05)),
            packmol_discale=float(self.config.get("packmol_discale", 1.5)),
            packmol_precision=int(self.config.get("packmol_precision", 2)),
        )

        self.write_log(
            ctx,
            (
                "Packing request: "
                f"n_chains={n_chains}, "
                f"shape={shape}, "
                f"radius_mode={radius_mode}, "
                f"radius_angstrom={radius_angstrom}, "
                f"minimum_radius_angstrom={minimum_radius_angstrom}, "
                f"retry_scale_factors={retry_scale_factors}"
            ),
        )

        for key, kind in (
            ("packed_pdb", "structure"),
            ("packmol_input", "input"),
            ("packing_report_json", "metadata"),
        ):
            path = result.get(key)
            if path:
                require_nonempty_file(path, f"{self.name}:{key}")
                artifact = Artifact(
                    name=key,
                    path=str(path),
                    kind=kind,
                )
                ctx.add_artifact(artifact)
                record.outputs[artifact.name] = artifact
                self.write_log(
                    ctx,
                    f"Registered artifact {artifact.name} -> {artifact.path}",
                )