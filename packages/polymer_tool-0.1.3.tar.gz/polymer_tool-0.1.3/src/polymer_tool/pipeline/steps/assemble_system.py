from __future__ import annotations

from polymer_tool.core.system_assembly import assemble_system
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class AssembleSystemStep(PipelineStep):
    name = "assemble_system"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        chain_json = ctx.get_artifact("chain_json").path
        chain_parameterized_sdf = ctx.get_artifact("chain_parameterized_sdf").path
        chain_parameterization_json = ctx.get_artifact(
            "chain_parameterization_json"
        ).path
        packed_pdb = ctx.get_artifact("packed_pdb").path
        packing_report_json = ctx.get_artifact("packing_report_json").path

        require_nonempty_file(chain_json, f"{self.name}:input chain_json")
        require_nonempty_file(
            chain_parameterized_sdf,
            f"{self.name}:input chain_parameterized_sdf",
        )
        require_nonempty_file(
            chain_parameterization_json,
            f"{self.name}:input chain_parameterization_json",
        )
        require_nonempty_file(packed_pdb, f"{self.name}:input packed_pdb")
        require_nonempty_file(
            packing_report_json,
            f"{self.name}:input packing_report_json",
        )

        system_name = str(
            self.config.get("system_name", "plga_nanoparticle_system")
        )
        molecule_label = str(self.config.get("molecule_label", "PLGA_CHAIN"))

        self.write_log(
            ctx,
            (
                "Assembly request: "
                f"chain_json={chain_json}, "
                f"chain_parameterized_sdf={chain_parameterized_sdf}, "
                f"chain_parameterization_json={chain_parameterization_json}, "
                f"packed_pdb={packed_pdb}, "
                f"packing_report_json={packing_report_json}, "
                f"system_name={system_name}, "
                f"molecule_label={molecule_label}"
            ),
        )

        result = assemble_system(
            chain_json=chain_json,
            parameterized_sdf=chain_parameterized_sdf,
            parameterization_json=chain_parameterization_json,
            packed_pdb=packed_pdb,
            packing_report_json=packing_report_json,
            out_dir=str(out_dir),
            system_name=system_name,
            molecule_label=molecule_label,
        )

        artifact_specs = (
            ("system_manifest_json", "system_manifest_json", "metadata"),
            ("components_json", "components_json", "metadata"),
            ("prep_report_json", "prep_report_json", "metadata"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )