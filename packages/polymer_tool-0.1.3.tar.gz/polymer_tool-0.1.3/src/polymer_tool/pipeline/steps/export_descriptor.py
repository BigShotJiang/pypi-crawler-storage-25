from __future__ import annotations

from pathlib import Path

from polymer_tool.core.export_descriptor import generate_export_descriptor
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


def _require_directory(path: str, label: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Expected {label} directory was not created: {p}")
    if not p.is_dir():
        raise NotADirectoryError(
            f"Expected {label} directory but found non-directory: {p}"
        )
    return p


class ExportDescriptorStep(PipelineStep):
    name = "export_descriptor"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        system_manifest_json = ctx.get_artifact("system_manifest_json").path
        chain_json = ctx.get_artifact("chain_json").path
        chain_parameterized_sdf = ctx.get_artifact("chain_parameterized_sdf").path
        packed_pdb = ctx.get_artifact("packed_pdb").path
        components_json = ctx.get_artifact("components_json").path
        prep_report_json = ctx.get_artifact("prep_report_json").path
        packed_chain_map_json = ctx.get_artifact("packed_chain_map_json").path
        component_index_map_json = ctx.get_artifact("component_index_map_json").path
        topology_prep_manifest_json = ctx.get_artifact(
            "topology_prep_manifest_json"
        ).path
        external_ff_notes_txt = ctx.get_artifact("external_ff_notes_txt").path
        export_manifest_json = ctx.get_artifact("export_manifest_json").path
        handoff_notes_txt = ctx.get_artifact("handoff_notes_txt").path
        workflow_summary_json = ctx.get_artifact("workflow_summary_json").path
        bundle_checksums_json = ctx.get_artifact("bundle_checksums_json").path
        export_archive_targz = ctx.get_artifact("export_archive_targz").path
        export_bundle_dir = ctx.get_artifact("export_bundle_dir").path

        require_nonempty_file(
            system_manifest_json,
            f"{self.name}:input system_manifest_json",
        )
        require_nonempty_file(
            chain_json,
            f"{self.name}:input chain_json",
        )
        require_nonempty_file(
            chain_parameterized_sdf,
            f"{self.name}:input chain_parameterized_sdf",
        )
        require_nonempty_file(
            packed_pdb,
            f"{self.name}:input packed_pdb",
        )
        require_nonempty_file(
            components_json,
            f"{self.name}:input components_json",
        )
        require_nonempty_file(
            prep_report_json,
            f"{self.name}:input prep_report_json",
        )
        require_nonempty_file(
            packed_chain_map_json,
            f"{self.name}:input packed_chain_map_json",
        )
        require_nonempty_file(
            component_index_map_json,
            f"{self.name}:input component_index_map_json",
        )
        require_nonempty_file(
            topology_prep_manifest_json,
            f"{self.name}:input topology_prep_manifest_json",
        )
        require_nonempty_file(
            external_ff_notes_txt,
            f"{self.name}:input external_ff_notes_txt",
        )
        require_nonempty_file(
            export_manifest_json,
            f"{self.name}:input export_manifest_json",
        )
        require_nonempty_file(
            handoff_notes_txt,
            f"{self.name}:input handoff_notes_txt",
        )
        require_nonempty_file(
            workflow_summary_json,
            f"{self.name}:input workflow_summary_json",
        )
        require_nonempty_file(
            bundle_checksums_json,
            f"{self.name}:input bundle_checksums_json",
        )
        require_nonempty_file(
            export_archive_targz,
            f"{self.name}:input export_archive_targz",
        )
        _require_directory(
            export_bundle_dir,
            f"{self.name}:input export_bundle_dir",
        )

        self.write_log(
            ctx,
            (
                "Export descriptor request: "
                f"system_manifest_json={system_manifest_json}, "
                f"chain_json={chain_json}, "
                f"chain_parameterized_sdf={chain_parameterized_sdf}, "
                f"packed_pdb={packed_pdb}, "
                f"components_json={components_json}, "
                f"prep_report_json={prep_report_json}, "
                f"packed_chain_map_json={packed_chain_map_json}, "
                f"component_index_map_json={component_index_map_json}, "
                f"topology_prep_manifest_json={topology_prep_manifest_json}, "
                f"external_ff_notes_txt={external_ff_notes_txt}, "
                f"export_manifest_json={export_manifest_json}, "
                f"handoff_notes_txt={handoff_notes_txt}, "
                f"workflow_summary_json={workflow_summary_json}, "
                f"bundle_checksums_json={bundle_checksums_json}, "
                f"export_archive_targz={export_archive_targz}, "
                f"export_bundle_dir={export_bundle_dir}"
            ),
        )

        result = generate_export_descriptor(
            system_manifest_json=system_manifest_json,
            chain_json=chain_json,
            chain_parameterized_sdf=chain_parameterized_sdf,
            packed_pdb=packed_pdb,
            components_json=components_json,
            prep_report_json=prep_report_json,
            packed_chain_map_json=packed_chain_map_json,
            component_index_map_json=component_index_map_json,
            topology_prep_manifest_json=topology_prep_manifest_json,
            external_ff_notes_txt=external_ff_notes_txt,
            export_manifest_json=export_manifest_json,
            handoff_notes_txt=handoff_notes_txt,
            workflow_summary_json=workflow_summary_json,
            bundle_checksums_json=bundle_checksums_json,
            export_archive_targz=export_archive_targz,
            export_bundle_dir=export_bundle_dir,
            out_dir=str(out_dir),
        )

        artifact_specs = (
            ("export_descriptor_json", "export_descriptor_json", "metadata"),
            ("file_inventory_json", "file_inventory_json", "metadata"),
            ("readiness_report_json", "readiness_report_json", "metadata"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )