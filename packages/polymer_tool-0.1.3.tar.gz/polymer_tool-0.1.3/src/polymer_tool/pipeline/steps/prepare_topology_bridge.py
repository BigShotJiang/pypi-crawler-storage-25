from __future__ import annotations

from polymer_tool.core.topology_prep import prepare_topology_bridge
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class PrepareTopologyBridgeStep(PipelineStep):
    name = "prepare_topology_bridge"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        system_manifest_json = ctx.get_artifact("system_manifest_json").path
        components_json = ctx.get_artifact("components_json").path
        prep_report_json = ctx.get_artifact("prep_report_json").path
        packed_pdb = ctx.get_artifact("packed_pdb").path
        chain_parameterized_sdf = ctx.get_artifact("chain_parameterized_sdf").path

        require_nonempty_file(
            system_manifest_json,
            f"{self.name}:input system_manifest_json",
        )
        require_nonempty_file(
            components_json,
            f"{self.name}:input components_json",
        )
        require_nonempty_file(
            prep_report_json,
            f"{self.name}:input prep_report_json",
        )
        require_nonempty_file(
            packed_pdb,
            f"{self.name}:input packed_pdb",
        )
        require_nonempty_file(
            chain_parameterized_sdf,
            f"{self.name}:input chain_parameterized_sdf",
        )

        self.write_log(
            ctx,
            (
                "Topology bridge request: "
                f"system_manifest_json={system_manifest_json}, "
                f"components_json={components_json}, "
                f"prep_report_json={prep_report_json}, "
                f"packed_pdb={packed_pdb}, "
                f"chain_parameterized_sdf={chain_parameterized_sdf}"
            ),
        )

        result = prepare_topology_bridge(
            system_manifest_json=system_manifest_json,
            components_json=components_json,
            prep_report_json=prep_report_json,
            packed_pdb=packed_pdb,
            chain_parameterized_sdf=chain_parameterized_sdf,
            out_dir=str(out_dir),
        )

        artifact_specs = (
            ("packed_chain_map_json", "packed_chain_map_json", "metadata"),
            ("component_index_map_json", "component_index_map_json", "metadata"),
            ("topology_prep_manifest_json", "topology_prep_manifest_json", "metadata"),
            ("external_ff_notes_txt", "external_ff_notes_txt", "metadata"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )