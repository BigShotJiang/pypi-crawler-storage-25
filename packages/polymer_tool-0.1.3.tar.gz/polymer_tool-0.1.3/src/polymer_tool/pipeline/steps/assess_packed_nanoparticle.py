from __future__ import annotations

from pathlib import Path

from polymer_tool.core.validators import require_nonempty_file
from polymer_tool.core.packing_assessment import run_packing_assessment

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class AssessPackedNanoparticleStep(PipelineStep):
    name = "assess_packed_nanoparticle"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        packed_pdb = ctx.get_artifact("packed_pdb").path
        packing_report_path = ctx.get_artifact("packing_report_json").path

        require_nonempty_file(packed_pdb, f"{self.name}:input packed_pdb")
        require_nonempty_file(packing_report_path, f"{self.name}:input packing_report_json")

        self.write_log(
            ctx,
            (
                "Packing assessment request: "
                f"packed_pdb={packed_pdb}, "
                f"packing_report_json={packing_report_path}, "
                f"out_dir={out_dir}"
            ),
        )

        result = run_packing_assessment(
            pdb_path=packed_pdb,
            output_dir=str(out_dir),
            packing_report_json=str(packing_report_path),
        )

        assessment_json = out_dir / "packing_assessment.json"
        require_nonempty_file(assessment_json, f"{self.name}:packing_assessment_json")

        artifact = Artifact(
            name="packing_assessment_json",
            path=str(assessment_json),
            kind="metadata",
        )
        ctx.add_artifact(artifact)
        record.outputs[artifact.name] = artifact

        self.write_log(
            ctx,
            f"Registered artifact {artifact.name} -> {artifact.path}",
        )

        self.write_log(
            ctx,
            (
                "Packing assessment complete: "
                f"regime={result['structural_regime']}, "
                f"label={result['assessment_label']}, "
                f"rg={result['rg_angstrom']:.4f}, "
                f"min_interchain_distance={result['min_interchain_distance']:.4f}"
            ),
        )