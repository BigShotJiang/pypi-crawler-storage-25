from __future__ import annotations

from pathlib import Path

from polymer_tool.core.export_gromacs_handoff import export_gromacs_handoff
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


def _require_directory(path: str, label: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Expected {label} directory was not created: {p}")
    if not p.is_dir():
        raise NotADirectoryError(
            f"Expected {label} directory but found non-directory: {p}"
        )
    return p


class ExportGromacsHandoffStep(PipelineStep):
    name = "export_gromacs_handoff"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        system_manifest_json = ctx.get_artifact("system_manifest_json").path
        components_json = ctx.get_artifact("components_json").path
        prep_report_json = ctx.get_artifact("prep_report_json").path
        packed_pdb = ctx.get_artifact("packed_pdb").path
        chain_parameterized_sdf = ctx.get_artifact("chain_parameterized_sdf").path
        bundle_name = str(self.config.get("bundle_name", "gromacs_handoff_bundle"))

        require_nonempty_file(
            system_manifest_json,
            f"{self.name}:input system_manifest_json",
        )
        require_nonempty_file(
            components_json,
            f"{self.name}:input components_json",
        )
        require_nonempty_file(
            prep_report_json,
            f"{self.name}:input prep_report_json",
        )
        require_nonempty_file(
            packed_pdb,
            f"{self.name}:input packed_pdb",
        )
        require_nonempty_file(
            chain_parameterized_sdf,
            f"{self.name}:input chain_parameterized_sdf",
        )

        self.write_log(
            ctx,
            (
                "GROMACS handoff export request: "
                f"system_manifest_json={system_manifest_json}, "
                f"components_json={components_json}, "
                f"prep_report_json={prep_report_json}, "
                f"packed_pdb={packed_pdb}, "
                f"chain_parameterized_sdf={chain_parameterized_sdf}, "
                f"bundle_name={bundle_name}"
            ),
        )

        result = export_gromacs_handoff(
            system_manifest_json=system_manifest_json,
            components_json=components_json,
            prep_report_json=prep_report_json,
            packed_pdb=packed_pdb,
            chain_parameterized_sdf=chain_parameterized_sdf,
            out_dir=str(out_dir),
            bundle_name=bundle_name,
        )

        artifact_specs = (
            ("export_manifest_json", "export_manifest_json", "metadata"),
            ("handoff_notes_txt", "handoff_notes_txt", "metadata"),
            ("workflow_summary_json", "workflow_summary_json", "metadata"),
            ("bundle_checksums_json", "bundle_checksums_json", "metadata"),
            ("export_archive_targz", "export_archive_targz", "archive"),
            ("export_bundle_dir", "export_bundle_dir", "bundle"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            if kind == "bundle":
                _require_directory(path, f"{self.name}:{result_key}")
            else:
                require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )