from __future__ import annotations

from pathlib import Path
import json

from polymer_tool.core.validators import require_nonempty_file
from polymer_tool.core.openff_relaxation import run_openff_relaxation
from polymer_tool.core.packing_assessment import run_packing_assessment

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class RelaxPackedNanoparticleStep(PipelineStep):
    name = "relax_packed_nanoparticle"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        packed_pdb = ctx.get_artifact("packed_pdb").path
        chain_sdf = ctx.get_artifact("chain_parameterized_sdf").path

        require_nonempty_file(packed_pdb, "packed_pdb")
        require_nonempty_file(chain_sdf, "chain_parameterized_sdf")

        result = run_openff_relaxation(
            packed_pdb=packed_pdb,
            chain_sdf=chain_sdf,
            output_dir=str(out_dir),
        )

        report_path = out_dir / "openff_relaxation.json"
        relaxed_pdb = out_dir / "relaxed_openff.pdb"

        artifact_specs = (
            ("openff_relaxation_json", str(report_path), "metadata"),
            ("relaxed_openff_pdb", str(relaxed_pdb), "structure"),
        )

        for name, path, kind in artifact_specs:
            artifact = Artifact(name=name, path=path, kind=kind)
            ctx.add_artifact(artifact)
            record.outputs[name] = artifact

        relaxed_assessment = run_packing_assessment(
            pdb_path=str(relaxed_pdb),
            output_dir=str(out_dir),
        )

        relaxed_assessment_path = out_dir / "relaxed_packing_assessment.json"
        relaxed_assessment_path.write_text(json.dumps(relaxed_assessment, indent=2))

        artifact = Artifact(
            name="relaxed_packing_assessment_json",
            path=str(relaxed_assessment_path),
            kind="metadata",
        )
        ctx.add_artifact(artifact)
        record.outputs["relaxed_packing_assessment_json"] = artifact
