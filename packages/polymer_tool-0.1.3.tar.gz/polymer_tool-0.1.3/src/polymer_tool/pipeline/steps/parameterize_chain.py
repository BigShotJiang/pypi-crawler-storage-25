from __future__ import annotations

from polymer_tool.core.parameterize import parameterize_chain
from polymer_tool.core.validators import require_nonempty_file

from ..context import PipelineContext
from ..models import Artifact, StepRecord
from ..step_base import PipelineStep


class ParameterizeChainStep(PipelineStep):
    name = "parameterize_chain"

    def run(self, ctx: PipelineContext, record: StepRecord) -> None:
        chain_sdf = ctx.get_artifact("chain_sdf").path
        require_nonempty_file(chain_sdf, f"{self.name}:input chain_sdf")

        out_dir = ctx.outputs_dir / self.name
        out_dir.mkdir(parents=True, exist_ok=True)

        charge_method = str(self.config.get("charge_method", "auto"))
        forcefield = str(self.config.get("forcefield", "openff-2.3.0"))

        self.write_log(
            ctx,
            (
                "Parameterization request: "
                f"input_sdf={chain_sdf}, "
                f"charge_method={charge_method}, "
                f"forcefield={forcefield}"
            ),
        )

        result = parameterize_chain(
            input_sdf=chain_sdf,
            charge_method=charge_method,
            forcefield=forcefield,
            out_dir=str(out_dir),
        )

        artifact_specs = (
            ("parameterized_sdf", "chain_parameterized_sdf", "structure"),
            ("metadata_json", "chain_parameterization_json", "metadata"),
        )

        for result_key, artifact_name, kind in artifact_specs:
            path = result.get(result_key)
            if not path:
                continue

            require_nonempty_file(path, f"{self.name}:{result_key}")

            artifact = Artifact(
                name=artifact_name,
                path=str(path),
                kind=kind,
            )
            ctx.add_artifact(artifact)
            record.outputs[artifact.name] = artifact
            self.write_log(
                ctx,
                f"Registered artifact {artifact.name} -> {artifact.path}",
            )