"""Dialogs package for PyQt5 GUI."""
