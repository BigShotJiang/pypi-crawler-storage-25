"""Dialog boxes for PyQt5 GUI."""

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTextEdit, QMessageBox, QFileDialog, QTableWidget, QTableWidgetItem,
    QHeaderView, QComboBox, QSpinBox
)
from PyQt5.QtCore import Qt, pyqtSignal


class ConfigComparisonDialog(QDialog):
    """Dialog for comparing two configurations."""
    
    def __init__(self, config1_name: str, config2_name: str, 
                 config1_text: str, config2_text: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Compare: {config1_name} vs {config2_name}")
        self.setGeometry(100, 100, 900, 600)
        self._init_ui(config1_name, config2_name, config1_text, config2_text)
    
    def _init_ui(self, name1, name2, text1, text2):
        """Initialize UI."""
        layout = QVBoxLayout()
        
        # Main comparison area
        main_layout = QHBoxLayout()
        
        # Left side
        left_layout = QVBoxLayout()
        left_layout.addWidget(QLabel(name1))
        left_text = QTextEdit()
        left_text.setPlainText(text1)
        left_text.setReadOnly(True)
        left_layout.addWidget(left_text)
        
        # Right side
        right_layout = QVBoxLayout()
        right_layout.addWidget(QLabel(name2))
        right_text = QTextEdit()
        right_text.setPlainText(text2)
        right_text.setReadOnly(True)
        right_layout.addWidget(right_text)
        
        main_layout.addLayout(left_layout)
        main_layout.addLayout(right_layout)
        layout.addLayout(main_layout)
        
        # Close button
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close)
        
        self.setLayout(layout)


class PreflightValidationDialog(QDialog):
    """Dialog showing preflight validation results."""
    
    def __init__(self, validation_result: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Preflight Validation")
        self.setGeometry(200, 200, 600, 400)
        self._init_ui(validation_result)
    
    def _init_ui(self, result):
        """Initialize UI."""
        layout = QVBoxLayout()
        
        # Status
        ok = result.get("ok", False)
        status_text = "✓ Configuration valid" if ok else "✗ Configuration invalid"
        status_label = QLabel(status_text)
        layout.addWidget(status_label)
        
        # Errors
        errors = result.get("errors", [])
        if errors:
            layout.addWidget(QLabel("Errors:"))
            errors_text = QTextEdit()
            errors_text.setPlainText("\n".join(errors))
            errors_text.setReadOnly(True)
            errors_text.setMaximumHeight(100)
            layout.addWidget(errors_text)
        
        # Warnings
        warnings = result.get("warnings", [])
        if warnings:
            layout.addWidget(QLabel("Warnings:"))
            warnings_text = QTextEdit()
            warnings_text.setPlainText("\n".join(warnings))
            warnings_text.setReadOnly(True)
            warnings_text.setMaximumHeight(100)
            layout.addWidget(warnings_text)
        
        layout.addStretch()
        
        # Close button
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close)
        
        self.setLayout(layout)


class RunProgressDialog(QDialog):
    """Dialog showing workflow execution progress."""
    
    progress_updated = pyqtSignal(str)  # progress message
    
    def __init__(self, run_id: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Running: {run_id}")
        self.setGeometry(300, 300, 500, 300)
        self.run_id = run_id
        self._init_ui()
    
    def _init_ui(self):
        """Initialize UI."""
        layout = QVBoxLayout()
        
        layout.addWidget(QLabel(f"Running workflow: {self.run_id}"))
        
        # Progress text area
        self.progress_text = QTextEdit()
        self.progress_text.setReadOnly(True)
        layout.addWidget(self.progress_text)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        button_layout.addWidget(self.btn_cancel)
        
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
    
    def append_progress(self, message: str):
        """Append progress message."""
        self.progress_text.append(message)
        self.progress_updated.emit(message)


def show_error_dialog(title: str, message: str, parent=None):
    """Show error message dialog."""
    QMessageBox.critical(parent, title, message)


def show_warning_dialog(title: str, message: str, parent=None):
    """Show warning message dialog."""
    QMessageBox.warning(parent, title, message)


def show_info_dialog(title: str, message: str, parent=None):
    """Show info message dialog."""
    QMessageBox.information(parent, title, message)


def ask_yes_no_dialog(title: str, message: str, parent=None) -> bool:
    """Show yes/no question dialog."""
    reply = QMessageBox.question(
        parent, title, message,
        QMessageBox.Yes | QMessageBox.No
    )
    return reply == QMessageBox.Yes


def ask_save_before_close_dialog(parent=None) -> int:
    """Ask if user wants to save before closing."""
    reply = QMessageBox.question(
        parent, "Save Changes?",
        "You have unsaved changes. Do you want to save before closing?",
        QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
    )
    return reply
