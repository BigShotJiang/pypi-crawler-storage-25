"""File operations for PyQt5 GUI."""

import json
import os
from pathlib import Path

from PyQt5.QtWidgets import QFileDialog


class FileOperations:
    """Handle file open/save operations."""

    @staticmethod
    def open_config_file(parent=None, initial_dir=None) -> str:
        if initial_dir is None:
            initial_dir = str(Path.home())

        file_path, _ = QFileDialog.getOpenFileName(
            parent,
            "Open Configuration",
            initial_dir,
            "JSON Files (*.json);;All Files (*)",
        )
        return file_path if file_path else None

    @staticmethod
    def save_config_file(parent=None, initial_dir=None, suggested_name="config.json") -> str:
        if initial_dir is None:
            initial_dir = str(Path.home())

        file_path, _ = QFileDialog.getSaveFileName(
            parent,
            "Save Configuration",
            os.path.join(initial_dir, suggested_name),
            "JSON Files (*.json);;All Files (*)",
        )
        return file_path if file_path else None

    @staticmethod
    def export_bundle_dir(parent=None, initial_dir=None) -> str:
        if initial_dir is None:
            initial_dir = str(Path.home())

        dir_path = QFileDialog.getExistingDirectory(
            parent,
            "Select Directory for Bundle Export",
            initial_dir,
        )
        return dir_path if dir_path else None

    @staticmethod
    def open_folder_in_explorer(folder_path: str):
        import platform
        import shutil
        import subprocess

        path_obj = Path(folder_path).resolve()
        folder_path = str(path_obj)
        system = platform.system()

        if system == "Darwin":
            subprocess.Popen(["open", folder_path])
            return

        if system == "Windows":
            os.startfile(folder_path)
            return

        def _to_windows_path(path_str: str) -> str:
            if shutil.which("wslpath"):
                try:
                    converted = subprocess.check_output(
                        ["wslpath", "-w", path_str],
                        text=True,
                    ).strip()
                    if converted:
                        return converted
                except Exception:
                    pass
            return path_str

        windows_path = _to_windows_path(folder_path)

        if shutil.which("wslview"):
            subprocess.Popen(["wslview", windows_path])
            return

        if shutil.which("explorer.exe"):
            subprocess.Popen(["explorer.exe", windows_path])
            return

        if shutil.which("xdg-open"):
            subprocess.run(["xdg-open", folder_path], check=True)
            return

        if shutil.which("gio"):
            subprocess.run(["gio", "open", folder_path], check=True)
            return

        raise RuntimeError(
            "No supported folder opener was found or configured. "
            "Tried wslview, explorer.exe, xdg-open, and gio."
        )


def load_config_from_file(file_path: str) -> dict:
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config_to_file(file_path: str, config: dict) -> bool:
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    return True