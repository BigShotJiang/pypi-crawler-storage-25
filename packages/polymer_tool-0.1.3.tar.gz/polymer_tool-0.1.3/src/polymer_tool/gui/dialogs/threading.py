"""Threading utilities for long-running operations in PyQt5 GUI."""

from typing import Any, Callable

from PyQt5.QtCore import QObject, QThread, pyqtSignal


class WorkerSignals(QObject):
    """Signals for worker thread communication."""

    finished = pyqtSignal()
    error = pyqtSignal(str)
    progress = pyqtSignal(str)
    result = pyqtSignal(dict)


class Worker(QThread):
    """Worker thread for executing background tasks."""

    def __init__(self, target: Callable, args=None, kwargs=None):
        super().__init__()
        self.target = target
        self.args = args or ()
        self.kwargs = kwargs or {}
        self.signals = WorkerSignals()
        self._is_running = True

    def run(self):
        """Execute the target function."""
        try:
            result = self.target(*self.args, **self.kwargs)
            if isinstance(result, dict):
                self.signals.result.emit(result)
            else:
                self.signals.result.emit({"result": result})
        except Exception as exc:
            self.signals.error.emit(str(exc))
        finally:
            self.signals.finished.emit()

    def stop(self):
        """Request worker to stop."""
        self._is_running = False
        self.wait()


class WorkflowExecutor:
    """Execute workflow in background thread."""

    def __init__(self, app_module):
        self.app_module = app_module
        self.worker = None

    def run_workflow(
        self,
        *,
        run_id: str,
        config_data: dict,
        on_progress: Callable[[str], None] | None = None,
        on_result: Callable[[dict], None] | None = None,
        on_error: Callable[[str], None] | None = None,
        base_dir: str | None = None,
    ) -> None:
        if self.worker and self.worker.isRunning():
            self.worker.stop()

        self.worker = Worker(
            self._execute_workflow,
            kwargs={
                "run_id": run_id,
                "config_data": config_data,
                "base_dir": base_dir,
            },
        )

        if on_result:
            self.worker.signals.result.connect(on_result)
        if on_error:
            self.worker.signals.error.connect(on_error)
        if on_progress:
            on_progress(f"Submitting workflow: {run_id}")

        self.worker.start()

    def _execute_workflow(
        self,
        *,
        run_id: str,
        config_data: dict,
        base_dir: str | None = None,
    ) -> dict:
        try:
            result = self.app_module.run_workflow_request(
                config_data=config_data,
                run_id=run_id,
                base_dir=base_dir,
            )
            return {
                "run_id": run_id,
                "success": True,
                "result": result,
            }
        except Exception as exc:
            return {
                "run_id": run_id,
                "success": False,
                "error": str(exc),
            }


class TaskRunner:
    """Simple task runner for arbitrary background tasks."""

    def __init__(self):
        self.worker = None

    def run_task(
        self,
        task: Callable,
        args=None,
        kwargs=None,
        on_complete: Callable[[Any], None] | None = None,
        on_error: Callable[[str], None] | None = None,
    ):
        if self.worker and self.worker.isRunning():
            self.worker.stop()

        self.worker = Worker(task, args, kwargs)

        if on_complete:
            self.worker.signals.result.connect(on_complete)
        if on_error:
            self.worker.signals.error.connect(on_error)

        self.worker.start()

    def stop(self):
        if self.worker:
            self.worker.stop()