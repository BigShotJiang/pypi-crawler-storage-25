"""PyQt5-based GUI entry point for polymer-tool."""

from __future__ import annotations

import argparse
import sys


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymer-tool-gui",
        description="Launch the PyQt5 GUI for polymer-tool.",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show the polymer-tool version and exit.",
    )
    return parser


def main() -> None:
    """Launch the PyQt5 GUI application."""
    parser = build_parser()
    args = parser.parse_args()

    if args.version:
        from polymer_tool import __version__
        print(__version__)
        return

    try:
        from PyQt5.QtWidgets import QApplication
        from polymer_tool.gui.main_window import PolymerToolGUI
        from polymer_tool.gui.styling.stylesheet import StyleManager
    except ModuleNotFoundError as exc:
        if exc.name == "PyQt5":
            raise SystemExit(
                "PyQt5 is required for the GUI. Install it with: pip install 'polymer-tool[gui]'"
            ) from exc
        raise

    app = QApplication(sys.argv)

    style_manager = StyleManager(app)
    style_manager.apply_light_theme()

    window = PolymerToolGUI()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()