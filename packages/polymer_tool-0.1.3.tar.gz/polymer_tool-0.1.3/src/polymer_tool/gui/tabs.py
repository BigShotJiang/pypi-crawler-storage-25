"""Tab management for main window."""

from PyQt5.QtWidgets import QWidget, QVBoxLayout

from .widgets.config_form import ConfigFormWidget
from .widgets.profile_browser import ProfileBrowserWidget
from .widgets.results_view import ResultsDisplayWidget
from .widgets.config_library import ConfigLibraryWidget
from .widgets.recent_runs import RecentRunsWidget


class ConfigTab(QWidget):
    """Configuration tab widget."""
    
    def __init__(self):
        super().__init__()
        self._init_ui()
    
    def _init_ui(self):
        """Initialize UI."""
        layout = QVBoxLayout()
        self.config_form = ConfigFormWidget()
        layout.addWidget(self.config_form)
        self.setLayout(layout)


class ProfilesTab(QWidget):
    """Launch profiles tab widget."""
    
    def __init__(self):
        super().__init__()
        self._init_ui()
    
    def _init_ui(self):
        """Initialize UI."""
        layout = QVBoxLayout()
        self.profile_browser = ProfileBrowserWidget()
        layout.addWidget(self.profile_browser)
        self.setLayout(layout)


class ResultsTab(QWidget):
    """Results tab widget."""
    
    def __init__(self):
        super().__init__()
        self._init_ui()
    
    def _init_ui(self):
        """Initialize UI."""
        layout = QVBoxLayout()
        self.results_display = ResultsDisplayWidget()
        layout.addWidget(self.results_display)
        self.setLayout(layout)


class SavedConfigsTab(QWidget):
    """Saved configs tab widget."""
    
    def __init__(self):
        super().__init__()
        self._init_ui()
    
    def _init_ui(self):
        """Initialize UI."""
        layout = QVBoxLayout()
        self.config_library = ConfigLibraryWidget()
        layout.addWidget(self.config_library)
        self.setLayout(layout)


class RecentRunsTab(QWidget):
    """Recent runs tab widget."""
    
    def __init__(self):
        super().__init__()
        self._init_ui()
    
    def _init_ui(self):
        """Initialize UI."""
        layout = QVBoxLayout()
        self.recent_runs = RecentRunsWidget()
        layout.addWidget(self.recent_runs)
        self.setLayout(layout)
