"""Configuration form widget for PyQt5 GUI."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QGridLayout,
    QLabel, QSpinBox, QDoubleSpinBox, QComboBox, QLineEdit,
    QScrollArea
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor


class ConfigFormWidget(QWidget):
    """Expandable configuration form with multiple sections."""
    
    # Signal emitted when any value changes
    config_changed = pyqtSignal(dict)
    # Signal emitted when validation state changes
    validation_changed = pyqtSignal(bool, list)  # (is_valid, errors)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.validation_errors = []
        self._init_ui()
        self._connect_signals()
    
    def _init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout()
        
        # Create scroll area for form
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout()
        
        # Build Chain section
        self._create_build_chain_section(scroll_layout)
        
        # Parameterize Chain section
        self._create_parameterize_chain_section(scroll_layout)
        
        # Pack Nanoparticle section
        self._create_pack_nanoparticle_section(scroll_layout)
        
        # Assemble System section
        self._create_assemble_system_section(scroll_layout)
        
        # Add stretch at end
        scroll_layout.addStretch()
        scroll_widget.setLayout(scroll_layout)
        scroll.setWidget(scroll_widget)
        
        layout.addWidget(scroll)
        self.setLayout(layout)
    
    def _create_build_chain_section(self, parent_layout):
        """Create Build Chain configuration section."""
        group = QGroupBox("Build Chain")
        layout = QGridLayout()
        
        # DP (Degree of polymerization)
        layout.addWidget(QLabel("DP (Degree of Polymerization):"), 0, 0)
        self.sp_dp = QSpinBox()
        self.sp_dp.setMinimum(1)
        self.sp_dp.setMaximum(1000)
        self.sp_dp.setValue(24)
        layout.addWidget(self.sp_dp, 0, 1)
        
        # Lactic Fraction
        layout.addWidget(QLabel("Lactic Fraction:"), 1, 0)
        self.dsb_lactic = QDoubleSpinBox()
        self.dsb_lactic.setMinimum(0.0)
        self.dsb_lactic.setMaximum(1.0)
        self.dsb_lactic.setValue(0.5)
        layout.addWidget(self.dsb_lactic, 1, 1)
        
        # Stereo Pattern
        layout.addWidget(QLabel("Stereo Pattern:"), 2, 0)
        self.cb_stereo = QComboBox()
        self.cb_stereo.addItems(["alt_RS", "all_R", "all_S", "random_RS_seeded"])
        layout.addWidget(self.cb_stereo, 2, 1)
        
        # End Group
        layout.addWidget(QLabel("End Group:"), 3, 0)
        self.cb_end_group = QComboBox()
        self.cb_end_group.addItems(["ester", "acid", "other"])
        layout.addWidget(self.cb_end_group, 3, 1)
        
        # Sequence Mode
        layout.addWidget(QLabel("Sequence Mode:"), 4, 0)
        self.cb_sequence = QComboBox()
        self.cb_sequence.addItems(["balanced", "block", "random_seeded", "random_coupled"])
        layout.addWidget(self.cb_sequence, 4, 1)
        
        group.setLayout(layout)
        parent_layout.addWidget(group)
    
    def _create_parameterize_chain_section(self, parent_layout):
        """Create Parameterize Chain configuration section."""
        group = QGroupBox("Parameterize Chain")
        layout = QGridLayout()
        
        # Charge Method
        layout.addWidget(QLabel("Charge Method:"), 0, 0)
        self.cb_charge = QComboBox()
        self.cb_charge.addItems(["gasteiger", "mmff94", "none"])
        layout.addWidget(self.cb_charge, 0, 1)
        
        # Forcefield
        layout.addWidget(QLabel("Forcefield:"), 1, 0)
        self.cb_forcefield = QComboBox()
        self.cb_forcefield.addItems(["openff-2.3.0", "gaff", "amber"])
        layout.addWidget(self.cb_forcefield, 1, 1)
        
        group.setLayout(layout)
        parent_layout.addWidget(group)
    
    def _create_pack_nanoparticle_section(self, parent_layout):
        """Create Pack Nanoparticle configuration section."""
        group = QGroupBox("Pack Nanoparticle")
        layout = QGridLayout()
        
        # Number of Chains
        layout.addWidget(QLabel("Number of Chains:"), 0, 0)
        self.sp_n_chains = QSpinBox()
        self.sp_n_chains.setMinimum(1)
        self.sp_n_chains.setMaximum(100)
        self.sp_n_chains.setValue(4)
        layout.addWidget(self.sp_n_chains, 0, 1)
        
        # Shape
        layout.addWidget(QLabel("Shape:"), 1, 0)
        self.cb_shape = QComboBox()
        self.cb_shape.addItems(["sphere", "cube", "cylinder"])
        layout.addWidget(self.cb_shape, 1, 1)
        
        # Radius Mode
        layout.addWidget(QLabel("Radius Mode:"), 2, 0)
        self.cb_radius_mode = QComboBox()
        self.cb_radius_mode.addItems(["manual", "density_based"])
        layout.addWidget(self.cb_radius_mode, 2, 1)
        
        # Radius (Angstrom)
        layout.addWidget(QLabel("Radius (Å):"), 3, 0)
        self.dsb_radius = QDoubleSpinBox()
        self.dsb_radius.setMinimum(0.0)
        self.dsb_radius.setMaximum(500.0)
        self.dsb_radius.setValue(45.0)
        layout.addWidget(self.dsb_radius, 3, 1)
        
        # Target Density
        layout.addWidget(QLabel("Target Density (g/cm³):"), 4, 0)
        self.dsb_density = QDoubleSpinBox()
        self.dsb_density.setMinimum(0.1)
        self.dsb_density.setMaximum(2.0)
        self.dsb_density.setValue(1.25)
        layout.addWidget(self.dsb_density, 4, 1)
        
        # Packing Slack Factor
        layout.addWidget(QLabel("Packing Slack Factor:"), 5, 0)
        self.dsb_slack = QDoubleSpinBox()
        self.dsb_slack.setMinimum(1.0)
        self.dsb_slack.setMaximum(5.0)
        self.dsb_slack.setValue(1.25)
        layout.addWidget(self.dsb_slack, 5, 1)
        
        group.setLayout(layout)
        parent_layout.addWidget(group)
    
    def _create_assemble_system_section(self, parent_layout):
        """Create Assemble System configuration section."""
        group = QGroupBox("Assemble System")
        layout = QGridLayout()
        
        # System Name
        layout.addWidget(QLabel("System Name:"), 0, 0)
        self.le_system_name = QLineEdit()
        self.le_system_name.setText("demo_system")
        layout.addWidget(self.le_system_name, 0, 1)
        
        # Molecule Label
        layout.addWidget(QLabel("Molecule Label:"), 1, 0)
        self.le_molecule_label = QLineEdit()
        self.le_molecule_label.setText("PLGA_CHAIN")
        layout.addWidget(self.le_molecule_label, 1, 1)
        
        group.setLayout(layout)
        parent_layout.addWidget(group)
    
    def _connect_signals(self):
        """Connect signals for real-time updates."""
        # Connect all widgets to emit config_changed
        widgets_to_connect = [
            self.sp_dp, self.dsb_lactic, self.cb_stereo, self.cb_end_group,
            self.cb_sequence, self.cb_charge, self.cb_forcefield,
            self.sp_n_chains, self.cb_shape, self.cb_radius_mode,
            self.dsb_radius, self.dsb_density, self.dsb_slack,
            self.le_system_name, self.le_molecule_label
        ]
        
        for widget in widgets_to_connect:
            if hasattr(widget, 'valueChanged'):
                widget.valueChanged.connect(self._on_value_changed)
            if hasattr(widget, 'textChanged'):
                widget.textChanged.connect(self._on_value_changed)
            if hasattr(widget, 'currentTextChanged'):
                widget.currentTextChanged.connect(self._on_value_changed)
    
    def _on_value_changed(self):
        """Emit config_changed signal with current config."""
        config = self.get_config()
        self.config_changed.emit(config)
        
        # Validate on change
        self.validate()
    
    def validate(self) -> bool:
        """
        Validate current configuration.
        Returns True if valid, False otherwise.
        Emits validation_changed signal.
        """
        self.validation_errors = []
        
        config = self.get_config()
        
        # Validate radius when in manual mode
        if config["pack_nanoparticle"]["radius_mode"] == "manual":
            if config["pack_nanoparticle"]["radius_angstrom"] <= 0:
                self.validation_errors.append(
                    "Radius must be > 0 when radius_mode is 'manual'"
                )
        
        # Validate system name is not empty
        if not config["assemble_system"]["system_name"].strip():
            self.validation_errors.append("System name cannot be empty")
        
        # Validate molecule label is not empty
        if not config["assemble_system"]["molecule_label"].strip():
            self.validation_errors.append("Molecule label cannot be empty")
        
        # Validate density is positive
        if config["pack_nanoparticle"]["target_density_g_cm3"] <= 0:
            self.validation_errors.append("Target density must be positive")
        
        is_valid = len(self.validation_errors) == 0
        self.validation_changed.emit(is_valid, self.validation_errors)
        return is_valid
    
    def get_validation_errors(self) -> list:
        """Get list of validation errors."""
        return self.validation_errors
    
    def get_config(self) -> dict:
        """Get current configuration as a dictionary."""
        return {
            "build_chain": {
                "dp": self.sp_dp.value(),
                "lactic_fraction": self.dsb_lactic.value(),
                "stereo_pattern": self.cb_stereo.currentText(),
                "end_group": self.cb_end_group.currentText(),
                "sequence_mode": self.cb_sequence.currentText(),
            },
            "parameterize_chain": {
                "charge_method": self.cb_charge.currentText(),
                "forcefield": self.cb_forcefield.currentText(),
            },
            "pack_nanoparticle": {
                "n_chains": self.sp_n_chains.value(),
                "shape": self.cb_shape.currentText(),
                "radius_mode": self.cb_radius_mode.currentText(),
                "radius_angstrom": self.dsb_radius.value(),
                "target_density_g_cm3": self.dsb_density.value(),
                "packing_slack_factor": self.dsb_slack.value(),
            },
            "assemble_system": {
                "system_name": self.le_system_name.text(),
                "molecule_label": self.le_molecule_label.text(),
            },
        }
    
    def _set_combo_value(self, combo: QComboBox, value: str, default: str) -> None:
        """Set combo text, adding the value temporarily if needed."""
        text = str(value if value not in (None, "") else default)
        if combo.findText(text) == -1:
            combo.addItem(text)
        combo.setCurrentText(text)
    
    def set_config(self, config: dict):
        """Set configuration from a dictionary."""
        try:
            if "build_chain" in config:
                bc = config["build_chain"]
                self.sp_dp.setValue(int(bc.get("dp", 24)))
                self.dsb_lactic.setValue(float(bc.get("lactic_fraction", 0.5)))
                self._set_combo_value(
                    self.cb_stereo,
                    bc.get("stereo_pattern", "alt_RS"),
                    "alt_RS",
                )
                self._set_combo_value(
                    self.cb_end_group,
                    bc.get("end_group", "ester"),
                    "ester",
                )
                self._set_combo_value(
                    self.cb_sequence,
                    bc.get("sequence_mode", "balanced"),
                    "balanced",
                )

            if "parameterize_chain" in config:
                pc = config["parameterize_chain"]
                self._set_combo_value(
                    self.cb_charge,
                    pc.get("charge_method", "gasteiger"),
                    "gasteiger",
                )
                self._set_combo_value(
                    self.cb_forcefield,
                    pc.get("forcefield", "openff-2.3.0"),
                    "openff-2.3.0",
                )

            if "pack_nanoparticle" in config:
                pn = config["pack_nanoparticle"]
                self.sp_n_chains.setValue(int(pn.get("n_chains", 4)))
                self._set_combo_value(
                    self.cb_shape,
                    pn.get("shape", "sphere"),
                    "sphere",
                )
                self._set_combo_value(
                    self.cb_radius_mode,
                    pn.get("radius_mode", "manual"),
                    "manual",
                )
                self.dsb_radius.setValue(float(pn.get("radius_angstrom", 45.0)))
                self.dsb_density.setValue(float(pn.get("target_density_g_cm3", 1.25)))
                self.dsb_slack.setValue(float(pn.get("packing_slack_factor", 1.25)))

            if "assemble_system" in config:
                asm = config["assemble_system"]
                self.le_system_name.setText(asm.get("system_name", "demo_system"))
                self.le_molecule_label.setText(asm.get("molecule_label", "PLGA_CHAIN"))
        except (ValueError, KeyError, TypeError):
            pass
