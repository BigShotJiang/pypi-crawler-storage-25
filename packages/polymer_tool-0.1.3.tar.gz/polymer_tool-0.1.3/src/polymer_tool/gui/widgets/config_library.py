"""Config library widget for PyQt5 GUI."""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class ConfigLibraryWidget(QWidget):
    """Browse and manage saved configurations."""

    config_selected = pyqtSignal(str)
    config_load_requested = pyqtSignal(str)
    config_delete_requested = pyqtSignal(str)
    config_compare_requested = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
        self._connect_signals()
        self._update_button_state()

    def _init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout()

        title = QLabel("Saved Configurations")
        layout.addWidget(title)

        self.configs_table = QTableWidget()
        self.configs_table.setColumnCount(3)
        self.configs_table.setHorizontalHeaderLabels(["Name", "Project", "Modified"])
        self.configs_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.configs_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.configs_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.configs_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.configs_table)

        button_layout = QHBoxLayout()

        self.btn_load = QPushButton("Load")
        button_layout.addWidget(self.btn_load)

        self.btn_compare = QPushButton("Compare")
        button_layout.addWidget(self.btn_compare)

        self.btn_delete = QPushButton("Delete")
        button_layout.addWidget(self.btn_delete)

        button_layout.addStretch()

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def _connect_signals(self):
        """Connect signals."""
        self.configs_table.itemSelectionChanged.connect(self._on_selection_changed)
        self.configs_table.itemDoubleClicked.connect(self._on_double_click)
        self.btn_load.clicked.connect(self._on_load_clicked)
        self.btn_compare.clicked.connect(self._on_compare_clicked)
        self.btn_delete.clicked.connect(self._on_delete_clicked)

    def _update_button_state(self):
        """Enable actions only when a config is selected."""
        has_selection = self.get_selected_config() is not None
        self.btn_load.setEnabled(has_selection)
        self.btn_compare.setEnabled(has_selection)
        self.btn_delete.setEnabled(has_selection)

    def _on_selection_changed(self):
        """Handle selection change."""
        selected = self.get_selected_config()
        self._update_button_state()
        if selected:
            self.config_selected.emit(selected)

    def _on_double_click(self):
        """Handle double-click."""
        selected = self.get_selected_config()
        if selected:
            self.config_load_requested.emit(selected)

    def _on_load_clicked(self):
        """Handle load button."""
        selected = self.get_selected_config()
        if selected:
            self.config_load_requested.emit(selected)

    def _on_compare_clicked(self):
        """Handle compare button."""
        selected = self.get_selected_config()
        if selected:
            self.config_compare_requested.emit(selected)

    def _on_delete_clicked(self):
        """Handle delete button."""
        selected = self.get_selected_config()
        if selected:
            self.config_delete_requested.emit(selected)

    def set_configs(self, configs: list):
        """Set configs to display."""
        self.configs_table.clearContents()
        self.configs_table.setRowCount(len(configs))

        for row, config in enumerate(configs):
            name_item = QTableWidgetItem(config.get("name", ""))
            project_item = QTableWidgetItem(config.get("project_name", ""))
            mtime_item = QTableWidgetItem(config.get("mtime_iso", ""))

            for item in (name_item, project_item, mtime_item):
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)

            self.configs_table.setItem(row, 0, name_item)
            self.configs_table.setItem(row, 1, project_item)
            self.configs_table.setItem(row, 2, mtime_item)

        self.configs_table.clearSelection()
        self._update_button_state()

    def get_selected_config(self) -> str | None:
        """Get the currently selected config name."""
        selection_model = self.configs_table.selectionModel()
        if selection_model is None:
            return None

        selected_rows = selection_model.selectedRows()
        if not selected_rows:
            return None

        row = selected_rows[0].row()
        item = self.configs_table.item(row, 0)
        return item.text() if item is not None else None

    def clear_configs(self):
        """Clear all configs."""
        self.configs_table.setRowCount(0)
        self._update_button_state()