"""Results display widget for PyQt5 GUI."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QTextEdit, QLabel
)
from PyQt5.QtCore import pyqtSignal


class ResultsDisplayWidget(QWidget):
    """Display results with export and copy functionality."""
    
    # Signal when export is requested
    export_requested = pyqtSignal()
    # Signal when copy is requested
    copy_requested = pyqtSignal()
    # Signal when clear is requested
    clear_requested = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
        self._connect_signals()
    
    def _init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("Run Results")
        layout.addWidget(title)
        
        # Results text area (read-only)
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setPlaceholderText("Results will appear here...")
        layout.addWidget(self.results_text)
        
        # Button row
        button_layout = QHBoxLayout()
        
        self.btn_copy = QPushButton("Copy Results")
        button_layout.addWidget(self.btn_copy)
        
        self.btn_export = QPushButton("Export Results")
        button_layout.addWidget(self.btn_export)
        
        self.btn_clear = QPushButton("Clear")
        button_layout.addWidget(self.btn_clear)
        
        button_layout.addStretch()
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def _connect_signals(self):
        """Connect button signals."""
        self.btn_copy.clicked.connect(self.copy_requested.emit)
        self.btn_export.clicked.connect(self.export_requested.emit)
        self.btn_clear.clicked.connect(self._on_clear)
    
    def _on_clear(self):
        """Handle clear button."""
        self.results_text.clear()
        self.clear_requested.emit()
    
    def set_results(self, text: str):
        """Set the results text."""
        self.results_text.setText(text)
    
    def append_results(self, text: str):
        """Append text to results."""
        self.results_text.append(text)
    
    def get_results(self) -> str:
        """Get the results text."""
        return self.results_text.toPlainText()
    
    def clear_results(self):
        """Clear the results."""
        self.results_text.clear()
