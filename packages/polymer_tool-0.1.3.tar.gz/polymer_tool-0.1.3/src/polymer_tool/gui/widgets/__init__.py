"""Widgets package for PyQt5 GUI."""
