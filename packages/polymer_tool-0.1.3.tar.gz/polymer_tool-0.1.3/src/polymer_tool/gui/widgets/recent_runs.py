"""Recent runs widget for PyQt5 GUI."""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class RecentRunsWidget(QWidget):
    """Browse recent workflow runs."""

    run_selected = pyqtSignal(str)
    open_folder_requested = pyqtSignal(str)
    view_config_requested = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
        self._connect_signals()
        self._update_button_state()

    def _init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout()

        title = QLabel("Recent Runs")
        layout.addWidget(title)

        self.runs_table = QTableWidget()
        self.runs_table.setColumnCount(4)
        self.runs_table.setHorizontalHeaderLabels(["Run ID", "Status", "Date", "Project"])
        self.runs_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.runs_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.runs_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.runs_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.runs_table)

        button_layout = QHBoxLayout()

        self.btn_open_folder = QPushButton("Open Folder")
        button_layout.addWidget(self.btn_open_folder)

        self.btn_view_config = QPushButton("View Config")
        button_layout.addWidget(self.btn_view_config)

        button_layout.addStretch()

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def _connect_signals(self):
        """Connect signals."""
        self.runs_table.itemSelectionChanged.connect(self._on_selection_changed)
        self.btn_open_folder.clicked.connect(self._on_open_folder_clicked)
        self.btn_view_config.clicked.connect(self._on_view_config_clicked)

    def _update_button_state(self):
        """Enable actions only when a run is selected."""
        has_selection = self.get_selected_run_dir() is not None
        self.btn_open_folder.setEnabled(has_selection)
        self.btn_view_config.setEnabled(has_selection)

    def _on_selection_changed(self):
        """Handle selection change."""
        selected = self.get_selected_run()
        self._update_button_state()
        if selected:
            self.run_selected.emit(selected)

    def _on_open_folder_clicked(self):
        """Handle open folder button."""
        run_dir = self.get_selected_run_dir()
        if run_dir:
            self.open_folder_requested.emit(run_dir)

    def _on_view_config_clicked(self):
        """Handle view config button."""
        run_dir = self.get_selected_run_dir()
        if run_dir:
            self.view_config_requested.emit(run_dir)

    def set_runs(self, runs: list):
        """Set runs to display."""
        self.runs_table.clearContents()
        self.runs_table.setRowCount(len(runs))

        for row, run in enumerate(runs):
            run_id_item = QTableWidgetItem(run.get("run_id", ""))
            status_item = QTableWidgetItem(run.get("status", "unknown"))
            date_item = QTableWidgetItem(run.get("date_iso", ""))
            project_item = QTableWidgetItem(run.get("project_name", ""))

            for item in (run_id_item, status_item, date_item, project_item):
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)

            run_id_item.setData(Qt.UserRole, run.get("base_dir", ""))

            self.runs_table.setItem(row, 0, run_id_item)
            self.runs_table.setItem(row, 1, status_item)
            self.runs_table.setItem(row, 2, date_item)
            self.runs_table.setItem(row, 3, project_item)

        self.runs_table.clearSelection()
        self._update_button_state()

    def get_selected_run(self) -> str | None:
        """Get the currently selected run ID."""
        selection_model = self.runs_table.selectionModel()
        if selection_model is None:
            return None

        selected_rows = selection_model.selectedRows()
        if not selected_rows:
            return None

        row = selected_rows[0].row()
        item = self.runs_table.item(row, 0)
        return item.text() if item is not None else None

    def get_selected_run_dir(self) -> str | None:
        """Get the base directory of the selected run."""
        selection_model = self.runs_table.selectionModel()
        if selection_model is None:
            return None

        selected_rows = selection_model.selectedRows()
        if not selected_rows:
            return None

        row = selected_rows[0].row()
        run_id_item = self.runs_table.item(row, 0)
        return run_id_item.data(Qt.UserRole) if run_id_item is not None else None

    def clear_runs(self):
        """Clear all runs."""
        self.runs_table.setRowCount(0)
        self._update_button_state()