"""Profile browser widget for PyQt5 GUI."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QTableWidget, QTableWidgetItem, QLabel, QHeaderView
)
from PyQt5.QtCore import pyqtSignal, Qt


class ProfileBrowserWidget(QWidget):
    """Browse and select launch profiles."""
    
    # Signal when profile is selected
    profile_selected = pyqtSignal(str)  # profile name
    # Signal when profile is double-clicked (load)
    profile_load_requested = pyqtSignal(str)  # profile name
    # Signal when add to favorites is requested
    favorite_requested = pyqtSignal(str)  # profile name
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
        self._connect_signals()
    
    def _init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("Available Launch Profiles")
        layout.addWidget(title)
        
        # Profiles table
        self.profiles_table = QTableWidget()
        self.profiles_table.setColumnCount(2)
        self.profiles_table.setHorizontalHeaderLabels(["Profile Name", "Description"])
        self.profiles_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch
        )
        layout.addWidget(self.profiles_table)
        
        # Button row
        button_layout = QHBoxLayout()
        
        self.btn_load = QPushButton("Load Profile")
        button_layout.addWidget(self.btn_load)
        
        self.btn_favorite = QPushButton("★ Add to Favorites")
        button_layout.addWidget(self.btn_favorite)
        
        button_layout.addStretch()
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def _connect_signals(self):
        """Connect signals."""
        self.profiles_table.itemSelectionChanged.connect(self._on_selection_changed)
        self.profiles_table.itemDoubleClicked.connect(self._on_double_click)
        self.btn_load.clicked.connect(self._on_load_clicked)
        self.btn_favorite.clicked.connect(self._on_favorite_clicked)
    
    def _on_selection_changed(self):
        """Handle selection change."""
        selected = self.get_selected_profile()
        if selected:
            self.profile_selected.emit(selected)
    
    def _on_double_click(self):
        """Handle double-click."""
        selected = self.get_selected_profile()
        if selected:
            self.profile_load_requested.emit(selected)
    
    def _on_load_clicked(self):
        """Handle load button."""
        selected = self.get_selected_profile()
        if selected:
            self.profile_load_requested.emit(selected)

    def _on_favorite_clicked(self):
        """Handle favorite button."""
        selected = self.get_selected_profile()
        if selected:
            self.favorite_requested.emit(selected)
    
    def set_profiles(self, profiles: list):
        """
        Set profiles to display.
        
        Args:
            profiles: List of dicts with 'name' and 'description' keys
        """
        self.profiles_table.setRowCount(len(profiles))
        for row, profile in enumerate(profiles):
            name_item = QTableWidgetItem(profile.get("name", ""))
            desc_item = QTableWidgetItem(profile.get("description", ""))
            
            # Make items non-editable
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            desc_item.setFlags(desc_item.flags() & ~Qt.ItemIsEditable)
            
            self.profiles_table.setItem(row, 0, name_item)
            self.profiles_table.setItem(row, 1, desc_item)
    
    def get_selected_profile(self) -> str:
        """Get the currently selected profile name."""
        selected = self.profiles_table.selectedItems()
        if selected:
            # Return the profile name (first column)
            row = selected[0].row()
            return self.profiles_table.item(row, 0).text()
        return None
    
    def clear_profiles(self):
        """Clear all profiles."""
        self.profiles_table.setRowCount(0)
