"""Main window for PyQt5 GUI."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QMessageBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from polymer_tool import __version__
from polymer_tool import app as app_api
from polymer_tool.gui.dialogs.file_operations import (
    FileOperations,
    load_config_from_file,
    save_config_to_file,
)
from polymer_tool.gui.dialogs.threading import WorkflowExecutor
from polymer_tool.gui.tabs import (
    ConfigTab,
    ProfilesTab,
    RecentRunsTab,
    ResultsTab,
    SavedConfigsTab,
)


class PolymerToolGUI(QMainWindow):
    """Main application window."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("polymer-tool - PLGA Workflow")
        self.setGeometry(100, 100, 1200, 800)

        self.current_config_data: dict | None = None
        self._saved_config_records: dict[str, dict] = {}
        self._favorite_profiles: set[str] = set()
        self.workflow_executor = WorkflowExecutor(app_api)

        self._create_menu_bar()
        self._create_toolbar()
        self._create_central_widget()
        self.statusBar().showMessage("Ready")

        self._bootstrap_state()

    def _create_menu_bar(self):
        """Create application menu bar."""
        menubar = self.menuBar()

        file_menu = menubar.addMenu("&File")
        file_menu.addAction("&Open Config").triggered.connect(self._on_open_config)
        file_menu.addAction("&Save Config").triggered.connect(self._on_save_config)
        file_menu.addSeparator()
        file_menu.addAction("E&xit").triggered.connect(self.close)

        help_menu = menubar.addMenu("&Help")
        help_menu.addAction("&About").triggered.connect(self._on_about)

    def _create_toolbar(self):
        """Create application toolbar."""
        toolbar = self.addToolBar("Main Toolbar")
        self.action_run_workflow = toolbar.addAction("Run Workflow")
        self.action_save_config = toolbar.addAction("Save Config")
        self.action_open_results = toolbar.addAction("Open Results")

        self.action_run_workflow.triggered.connect(self._on_run_workflow)
        self.action_save_config.triggered.connect(self._on_save_config)
        self.action_open_results.triggered.connect(self._on_open_results)

    def _create_central_widget(self):
        """Create central widget with tabbed interface."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self.tab_config = ConfigTab()
        self.tab_profiles = ProfilesTab()
        self.tab_results = ResultsTab()
        self.tab_saved = SavedConfigsTab()
        self.tab_recent = RecentRunsTab()

        self.tabs.addTab(self.tab_config, "Configuration")
        self.tabs.addTab(self.tab_profiles, "Launch Profiles")
        self.tabs.addTab(self.tab_results, "Results")
        self.tabs.addTab(self.tab_saved, "Saved Configs")
        self.tabs.addTab(self.tab_recent, "Recent Runs")

        self._connect_tab_signals()

    def _connect_tab_signals(self):
        """Connect tab/widget signals to handlers."""
        self.tab_profiles.profile_browser.profile_load_requested.connect(
            self._on_profile_loaded
        )
        self.tab_profiles.profile_browser.favorite_requested.connect(
            self._on_profile_favorited
        )

        self.tab_results.results_display.copy_requested.connect(self._on_copy_results)
        self.tab_results.results_display.export_requested.connect(self._on_export_results)
        self.tab_results.results_display.clear_requested.connect(self._on_results_cleared)

        self.tab_saved.config_library.config_load_requested.connect(
            self._on_saved_config_loaded
        )
        self.tab_saved.config_library.config_compare_requested.connect(
            self._on_saved_config_compared
        )
        self.tab_saved.config_library.config_delete_requested.connect(
            self._on_saved_config_deleted
        )

        self.tab_recent.recent_runs.open_folder_requested.connect(
            self._on_open_run_folder
        )
        self.tab_recent.recent_runs.view_config_requested.connect(
            self._on_view_run_config
        )

    def _bootstrap_state(self):
        """Load initial GUI state from backend sources."""
        default_config = app_api.resolve_config_data()
        self._set_current_config_data(default_config)
        self._refresh_profiles()
        self._refresh_saved_configs()
        self._refresh_recent_runs()

    def _set_current_config_data(self, config_data: dict):
        """Set full config state and push workflow_config into the form."""
        materialized, _notes = app_api.materialize_workflow_config(config_data=config_data)
        self.current_config_data = materialized
        self.tab_config.config_form.set_config(materialized["workflow_config"])

    def _build_request_config_data(self) -> dict:
        """Build a full CLI-compatible request config from GUI state."""
        if self.current_config_data is None:
            base = app_api.resolve_config_data()
        else:
            base = deepcopy(self.current_config_data)

        workflow_config = deepcopy(base.get("workflow_config", {}))
        form_config = self.tab_config.config_form.get_config()

        for section_name, section_payload in form_config.items():
            workflow_config[section_name] = deepcopy(section_payload)

        base["workflow_config"] = workflow_config
        base.setdefault("project_name", "plga_tool_dev")
        base.setdefault("workflow_name", "build_pack_workflow")
        return base

    def _refresh_profiles(self):
        """Reload launch profiles from backend."""
        profiles = app_api.launch_profiles()
        self._favorite_profiles = app_api.load_favorite_launch_profiles()

        decorated = []
        for profile in profiles:
            profile = dict(profile)
            if profile["name"] in self._favorite_profiles:
                profile["description"] = f"★ {profile['description']}"
            decorated.append(profile)

        self.tab_profiles.profile_browser.set_profiles(decorated)

    def _refresh_saved_configs(self):
        """Reload saved user configs from backend."""
        records = app_api.discover_user_configs()
        self._saved_config_records = {record["name"]: record for record in records}
        self.tab_saved.config_library.set_configs(records)

        table = self.tab_saved.config_library.configs_table
        if records and table.rowCount() > 0:
            table.selectRow(0)

    def _refresh_recent_runs(self):
        """Reload recent runs from backend."""
        raw_records = app_api.discover_recent_runs()
        display_records = []
        for record in raw_records:
            display_records.append(
                {
                    "run_id": record.get("run_id", ""),
                    "status": record.get("last_status") or "unknown",
                    "date_iso": record.get("mtime_iso", ""),
                    "project_name": record.get("project_name", ""),
                    "base_dir": record.get("base_dir", ""),
                }
            )
        self.tab_recent.recent_runs.set_runs(display_records)

        table = self.tab_recent.recent_runs.runs_table
        if display_records and table.rowCount() > 0:
            table.selectRow(0)

    def _on_open_config(self):
        """Handle open config action."""
        file_path = FileOperations.open_config_file(self)
        if not file_path:
            self.statusBar().showMessage("Open config cancelled", 3000)
            return

        try:
            config = load_config_from_file(file_path)
            self._set_current_config_data(config)
            self.tabs.setCurrentWidget(self.tab_config)
            self.statusBar().showMessage(f"Loaded config: {Path(file_path).name}", 5000)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open Configuration Failed",
                f"Could not load configuration:\n{file_path}\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to load config", 5000)

    def _on_save_config(self):
        """Handle save config action."""
        config_data = self._build_request_config_data()
        suggested_name = (
            f"{config_data['workflow_config']['assemble_system'].get('system_name', 'config')}.json"
        )

        file_path = FileOperations.save_config_file(self, suggested_name=suggested_name)
        if not file_path:
            self.statusBar().showMessage("Save config cancelled", 3000)
            return

        try:
            save_config_to_file(file_path, config_data)

            library_name = Path(file_path).stem
            app_api.save_named_user_config(library_name, config_data=config_data)
            self._refresh_saved_configs()

            self.statusBar().showMessage(f"Saved config: {Path(file_path).name}", 5000)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Save Configuration Failed",
                f"Could not save configuration:\n{file_path}\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to save config", 5000)

    def _on_run_workflow(self):
        """Handle run workflow toolbar action."""
        config_data = self._build_request_config_data()
        report = app_api.preflight_validate_request(config_data=config_data)

        if not report.get("ok", False):
            text = app_api.format_preflight_report(report)
            self.tab_results.results_display.set_results(text)
            self.tabs.setCurrentWidget(self.tab_results)
            QMessageBox.warning(self, "Preflight Validation Failed", text)
            self.statusBar().showMessage("Preflight validation failed", 5000)
            return

        run_id = app_api.generate_default_run_id(None)
        self.action_run_workflow.setEnabled(False)
        self.statusBar().showMessage(f"Running workflow: {run_id}")

        self.workflow_executor.run_workflow(
            run_id=run_id,
            config_data=config_data,
            on_progress=lambda msg: self.statusBar().showMessage(msg),
            on_result=self._on_workflow_result,
            on_error=self._on_workflow_error,
        )

    def _on_workflow_result(self, payload: dict):
        """Handle workflow completion."""
        self.action_run_workflow.setEnabled(True)

        if not payload.get("success", False):
            error_text = payload.get("error", "Unknown workflow error")
            self._on_workflow_error(error_text)
            return

        result = payload["result"]
        result_text = app_api.format_run_result(result)

        self.tab_results.results_display.set_results(result_text)
        self.tabs.setCurrentWidget(self.tab_results)
        self._refresh_recent_runs()

        self.statusBar().showMessage(
            f"Workflow finished: {payload.get('run_id', 'unknown')}", 5000
        )

    def _on_workflow_error(self, error_text: str):
        """Handle workflow failure."""
        self.action_run_workflow.setEnabled(True)
        self.tab_results.results_display.set_results(f"Workflow failed:\n\n{error_text}")
        self.tabs.setCurrentWidget(self.tab_results)
        QMessageBox.critical(self, "Workflow Failed", error_text)
        self.statusBar().showMessage("Workflow failed", 5000)

    def _on_open_results(self):
        """Handle open results toolbar action."""
        self.tabs.setCurrentWidget(self.tab_results)
        self.statusBar().showMessage("Results tab opened")

    def _on_profile_loaded(self, profile_name: str):
        """Load launch profile into config form."""
        try:
            profile = app_api.get_launch_profile(profile_name)
            self._set_current_config_data(profile["request"])
            self.tabs.setCurrentWidget(self.tab_config)
            self.statusBar().showMessage(f"Loaded profile: {profile_name}", 5000)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Load Profile Failed",
                f"Could not load profile '{profile_name}'.\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to load profile", 5000)

    def _on_profile_favorited(self, profile_name: str):
        """Toggle favorite state for a launch profile."""
        favorites = app_api.toggle_favorite_launch_profile(profile_name)
        self._favorite_profiles = favorites
        self._refresh_profiles()

        if profile_name in favorites:
            self.statusBar().showMessage(
                f"Added to favorites: {profile_name}", 5000
            )
        else:
            self.statusBar().showMessage(
                f"Removed from favorites: {profile_name}", 5000
            )

    def _on_copy_results(self):
        """Handle copy results button."""
        text = self.tab_results.results_display.get_results()
        if not text:
            self.statusBar().showMessage("No results to copy", 3000)
            return

        clipboard = QApplication.clipboard()
        if clipboard is None:
            self.statusBar().showMessage("Clipboard unavailable", 3000)
            return

        clipboard.setText(text)
        self.statusBar().showMessage("Results copied to clipboard", 3000)

    def _on_export_results(self):
        """Handle export results button."""
        text = self.tab_results.results_display.get_results()
        if not text:
            self.statusBar().showMessage("No results to export", 3000)
            return

        file_path = FileOperations.save_config_file(self, suggested_name="results.txt")
        if not file_path:
            self.statusBar().showMessage("Export cancelled", 3000)
            return

        try:
            Path(file_path).write_text(text, encoding="utf-8")
            self.statusBar().showMessage(
                f"Exported results: {Path(file_path).name}", 5000
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Export Results Failed",
                f"Could not export results:\n{file_path}\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to export results", 5000)

    def _on_results_cleared(self):
        """Handle clear results button."""
        self.statusBar().showMessage("Results cleared", 3000)

    def _on_saved_config_loaded(self, config_name: str):
        """Load selected saved config into form."""
        if not config_name:
            QMessageBox.information(
                self,
                "No Saved Config Selected",
                "Select a saved configuration first.",
            )
            self.statusBar().showMessage("No saved config selected", 3000)
            return

        try:
            config = app_api.load_user_config_by_name(config_name)
            self._set_current_config_data(config)
            self.tabs.setCurrentWidget(self.tab_config)
            self.statusBar().showMessage(
                f"Loaded saved config: {config_name}", 5000
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Load Saved Config Failed",
                f"Could not load saved config '{config_name}'.\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to load saved config", 5000)

    def _on_saved_config_compared(self, config_name: str):
        """Compare selected saved config against current GUI form."""
        if not config_name:
            QMessageBox.information(
                self,
                "No Saved Config Selected",
                "Select a saved configuration first.",
            )
            self.statusBar().showMessage("No saved config selected", 3000)
            return

        try:
            saved_config = app_api.load_user_config_by_name(config_name)
            current_materialized, _ = app_api.materialize_workflow_config(
                config_data=self._build_request_config_data()
            )
            saved_materialized, _ = app_api.materialize_workflow_config(
                config_data=saved_config
            )

            diff_text = app_api.compare_materialized_configs(
                current_materialized,
                saved_materialized,
                left_label="current GUI",
                right_label=config_name,
            )
            self.tab_results.results_display.set_results(diff_text)
            self.tabs.setCurrentWidget(self.tab_results)
            self.statusBar().showMessage(
                f"Compared current config with: {config_name}", 5000
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Compare Saved Config Failed",
                f"Could not compare saved config '{config_name}'.\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to compare saved config", 5000)

    def _on_saved_config_deleted(self, config_name: str):
        """Delete selected saved config from the user config library."""
        if not config_name:
            QMessageBox.information(
                self,
                "No Saved Config Selected",
                "Select a saved configuration first.",
            )
            self.statusBar().showMessage("No saved config selected", 3000)
            return

        record = self._saved_config_records.get(config_name)
        if not record:
            self.statusBar().showMessage("Saved config record not found", 3000)
            return

        answer = QMessageBox.question(
            self,
            "Delete Saved Config",
            f"Delete saved config '{config_name}'?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            self.statusBar().showMessage("Delete cancelled", 3000)
            return

        try:
            Path(record["path"]).unlink(missing_ok=False)
            self._refresh_saved_configs()
            self.statusBar().showMessage(
                f"Deleted saved config: {config_name}", 5000
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Delete Saved Config Failed",
                f"Could not delete saved config '{config_name}'.\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to delete saved config", 5000)

    def _on_open_run_folder(self, run_dir: str):
        """Handle open run folder request."""
        if not run_dir:
            self.statusBar().showMessage("No run folder selected", 3000)
            return

        run_path = Path(run_dir)
        if not run_path.exists():
            QMessageBox.warning(
                self,
                "Run Folder Not Found",
                f"The requested run folder does not exist:\n{run_path}",
            )
            self.statusBar().showMessage("Run folder not found", 5000)
            return

        try:
            FileOperations.open_folder_in_explorer(str(run_path))
            self.statusBar().showMessage(f"Opened folder: {run_path}", 5000)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open Folder Failed",
                f"Could not open folder:\n{run_path}\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to open folder", 5000)

    def _on_view_run_config(self, run_dir: str):
        """Load config for selected run from run_state.json."""
        if not run_dir:
            self.statusBar().showMessage("No run selected", 3000)
            return

        try:
            config_data = app_api.load_config_from_run_state(run_dir)
            self._set_current_config_data(config_data)
            self.tabs.setCurrentWidget(self.tab_config)
            self.statusBar().showMessage("Loaded run config", 5000)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "View Run Config Failed",
                f"Could not load run config from:\n{run_dir}\n\n{exc}",
            )
            self.statusBar().showMessage("Failed to load run config", 5000)

    def _on_about(self):
        """Handle about action."""
        QMessageBox.information(
            self,
            "About polymer-tool",
            f"PyQt5-based GUI for PLGA workflow management\nVersion {__version__}",
        )