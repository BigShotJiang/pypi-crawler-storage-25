"""Init file for styling package."""
