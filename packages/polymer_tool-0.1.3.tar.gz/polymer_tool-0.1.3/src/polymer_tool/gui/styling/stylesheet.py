"""PyQt5 QSS stylesheet for GUI styling."""

# Default light theme stylesheet
LIGHT_STYLESHEET = """
/* Main Window */
QMainWindow {
    background-color: #f5f5f5;
    color: #333333;
}

/* Menu Bar */
QMenuBar {
    background-color: #ffffff;
    color: #333333;
    border-bottom: 1px solid #e0e0e0;
    padding: 5px;
}

QMenuBar::item:selected {
    background-color: #e8e8e8;
}

/* Menu */
QMenu {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #cccccc;
}

QMenu::item:selected {
    background-color: #0078d7;
    color: #ffffff;
}

/* Tool Bar */
QToolBar {
    background-color: #f5f5f5;
    border-bottom: 1px solid #e0e0e0;
    padding: 5px;
}

QToolButton {
    background-color: #f5f5f5;
    color: #333333;
    border: none;
    padding: 5px;
    border-radius: 3px;
}

QToolButton:hover {
    background-color: #e0e0e0;
}

QToolButton:pressed {
    background-color: #d0d0d0;
}

/* Status Bar */
QStatusBar {
    background-color: #ffffff;
    color: #333333;
    border-top: 1px solid #e0e0e0;
}

/* Tab Widget */
QTabWidget::pane {
    border: 1px solid #e0e0e0;
}

QTabBar::tab {
    background-color: #e8e8e8;
    color: #333333;
    padding: 8px 20px;
    border: 1px solid #d0d0d0;
    border-bottom: none;
}

QTabBar::tab:selected {
    background-color: #ffffff;
    color: #0078d7;
    border-bottom: 2px solid #0078d7;
}

QTabBar::tab:hover {
    background-color: #f0f0f0;
}

/* Buttons */
QPushButton {
    background-color: #0078d7;
    color: #ffffff;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    font-weight: bold;
    min-width: 80px;
}

QPushButton:hover {
    background-color: #1084d8;
}

QPushButton:pressed {
    background-color: #006cc6;
}

QPushButton:disabled {
    background-color: #cccccc;
    color: #999999;
}

/* Line Edit */
QLineEdit {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #d0d0d0;
    padding: 6px;
    border-radius: 3px;
    selection-background-color: #0078d7;
}

QLineEdit:focus {
    border: 2px solid #0078d7;
}

/* Text Edit */
QTextEdit {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #d0d0d0;
    padding: 4px;
    border-radius: 3px;
    selection-background-color: #0078d7;
}

QTextEdit:focus {
    border: 2px solid #0078d7;
}

/* Combo Box */
QComboBox {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #d0d0d0;
    padding: 6px;
    border-radius: 3px;
}

QComboBox:focus {
    border: 2px solid #0078d7;
}

QComboBox::drop-down {
    border: none;
    width: 30px;
}

QComboBox::down-arrow {
    image: url(:/arrow_down);
}

/* Spin Box */
QSpinBox, QDoubleSpinBox {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #d0d0d0;
    padding: 4px;
    border-radius: 3px;
}

QSpinBox:focus, QDoubleSpinBox:focus {
    border: 2px solid #0078d7;
}

/* Group Box */
QGroupBox {
    color: #333333;
    border: 1px solid #d0d0d0;
    border-radius: 5px;
    margin-top: 10px;
    padding-top: 10px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 3px 0 3px;
}

/* Label */
QLabel {
    color: #333333;
}

/* Table Widget */
QTableWidget {
    background-color: #ffffff;
    alternate-background-color: #f9f9f9;
    gridline-color: #e0e0e0;
    color: #333333;
    border: 1px solid #d0d0d0;
}

QTableWidget::item:selected {
    background-color: #0078d7;
    color: #ffffff;
}

QHeaderView::section {
    background-color: #e8e8e8;
    color: #333333;
    padding: 5px;
    border: 1px solid #d0d0d0;
}

/* Scroll Bar */
QScrollBar:vertical {
    background-color: #f5f5f5;
    width: 12px;
    border: 1px solid #e0e0e0;
}

QScrollBar::handle:vertical {
    background-color: #b0b0b0;
    border-radius: 6px;
    min-height: 20px;
}

QScrollBar::handle:vertical:hover {
    background-color: #a0a0a0;
}

QScrollBar:horizontal {
    background-color: #f5f5f5;
    height: 12px;
    border: 1px solid #e0e0e0;
}

QScrollBar::handle:horizontal {
    background-color: #b0b0b0;
    border-radius: 6px;
    min-width: 20px;
}

QScrollBar::handle:horizontal:hover {
    background-color: #a0a0a0;
}

/* Dialog */
QDialog {
    background-color: #f5f5f5;
    color: #333333;
}
"""

# Dark theme stylesheet (alternative)
DARK_STYLESHEET = """
/* Main Window */
QMainWindow {
    background-color: #1e1e1e;
    color: #e0e0e0;
}

/* Menu Bar */
QMenuBar {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border-bottom: 1px solid #444444;
}

QMenuBar::item:selected {
    background-color: #404040;
}

/* Menu */
QMenu {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: 1px solid #444444;
}

QMenu::item:selected {
    background-color: #0078d7;
    color: #ffffff;
}

/* Tool Bar */
QToolBar {
    background-color: #2d2d2d;
    border-bottom: 1px solid #444444;
}

QToolButton {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: none;
    padding: 5px;
    border-radius: 3px;
}

QToolButton:hover {
    background-color: #3d3d3d;
}

/* Status Bar */
QStatusBar {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border-top: 1px solid #444444;
}

/* Tab Widget */
QTabBar::tab {
    background-color: #3d3d3d;
    color: #e0e0e0;
    padding: 8px 20px;
}

QTabBar::tab:selected {
    background-color: #1e1e1e;
    color: #0078d7;
    border-bottom: 2px solid #0078d7;
}

/* Buttons */
QPushButton {
    background-color: #0078d7;
    color: #ffffff;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    font-weight: bold;
}

QPushButton:hover {
    background-color: #1084d8;
}

/* Line Edit */
QLineEdit {
    background-color: #3d3d3d;
    color: #e0e0e0;
    border: 1px solid #555555;
    padding: 6px;
    border-radius: 3px;
}

QLineEdit:focus {
    border: 2px solid #0078d7;
}

/* Text Edit */
QTextEdit {
    background-color: #3d3d3d;
    color: #e0e0e0;
    border: 1px solid #555555;
}

QTextEdit:focus {
    border: 2px solid #0078d7;
}

/* Label */
QLabel {
    color: #e0e0e0;
}

/* Table Widget */
QTableWidget {
    background-color: #3d3d3d;
    alternate-background-color: #2d2d2d;
    gridline-color: #555555;
    color: #e0e0e0;
}

QTableWidget::item:selected {
    background-color: #0078d7;
    color: #ffffff;
}

QHeaderView::section {
    background-color: #2d2d2d;
    color: #e0e0e0;
    padding: 5px;
    border: 1px solid #555555;
}
"""


class StyleManager:
    """Manage GUI styling."""
    
    LIGHT = "light"
    DARK = "dark"
    
    def __init__(self, app):
        """
        Initialize style manager.
        
        Args:
            app: QApplication instance
        """
        self.app = app
        self.current_theme = self.LIGHT
    
    def apply_light_theme(self):
        """Apply light theme."""
        self.app.setStyleSheet(LIGHT_STYLESHEET)
        self.current_theme = self.LIGHT
    
    def apply_dark_theme(self):
        """Apply dark theme."""
        self.app.setStyleSheet(DARK_STYLESHEET)
        self.current_theme = self.DARK
    
    def toggle_theme(self):
        """Toggle between light and dark themes."""
        if self.current_theme == self.LIGHT:
            self.apply_dark_theme()
        else:
            self.apply_light_theme()
    
    def apply_custom_stylesheet(self, stylesheet: str):
        """
        Apply custom stylesheet.
        
        Args:
            stylesheet: QSS stylesheet string
        """
        self.app.setStyleSheet(stylesheet)
    
    def get_current_theme(self) -> str:
        """Get current theme name."""
        return self.current_theme
