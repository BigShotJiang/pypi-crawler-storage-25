from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


REQUIRED_TOP_LEVEL_KEYS = (
    "project_name",
    "workflow_name",
    "workflow_config",
)

REQUIRED_WORKFLOW_STEP_KEYS = (
    "build_chain",
    "parameterize_chain",
    "pack_nanoparticle",
    "assess_packed_nanoparticle",
    "assemble_system",
    "prepare_topology_bridge",
    "export_gromacs_handoff",
    "export_generic_handoff",
    "export_descriptor",
)


def load_json_config(path: str | Path) -> Dict[str, Any]:
    p = Path(path)

    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    if not p.is_file():
        raise IsADirectoryError(f"Expected config file but found directory: {p}")

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Failed to parse JSON config {p}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"Top-level config must be a JSON object: {p}")

    return data


def _require_nonempty_string(mapping: Dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"Config key {key!r} is required and must be a non-empty string."
        )
    return value


def _require_object(mapping: Dict[str, Any], key: str) -> Dict[str, Any]:
    value = mapping.get(key)
    if not isinstance(value, dict):
        raise ValueError(
            f"Config key {key!r} is required and must be a JSON object."
        )
    return value


def validate_workflow_config(data: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Workflow config payload must be a dictionary.")

    missing_top = [key for key in REQUIRED_TOP_LEVEL_KEYS if key not in data]
    if missing_top:
        raise ValueError(
            "Missing required top-level config key(s): "
            + ", ".join(repr(k) for k in missing_top)
        )

    _require_nonempty_string(data, "project_name")
    _require_nonempty_string(data, "workflow_name")
    workflow_config = _require_object(data, "workflow_config")

    missing_steps = [
        step for step in REQUIRED_WORKFLOW_STEP_KEYS if step not in workflow_config
    ]
    if missing_steps:
        raise ValueError(
            "Missing required workflow step config section(s): "
            + ", ".join(repr(step) for step in missing_steps)
        )

    for step in REQUIRED_WORKFLOW_STEP_KEYS:
        _require_object(workflow_config, step)

    return data