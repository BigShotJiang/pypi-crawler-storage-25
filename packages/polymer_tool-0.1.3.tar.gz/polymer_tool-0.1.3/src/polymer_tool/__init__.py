from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("polymer-tool")
except PackageNotFoundError:
    __version__ = "0.1.3"

__all__ = ["__version__"]