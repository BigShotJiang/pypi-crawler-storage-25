from __future__ import annotations

import argparse
from typing import Any

from polymer_tool import __version__
from polymer_tool.app import (
    available_presets,
    format_run_result,
    run_workflow_request,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the polymer_tool workflow from a JSON config or preset."
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to workflow JSON config file.",
    )
    parser.add_argument(
        "--preset",
        type=str,
        default=None,
        help="Name of preset in bundled presets or config/presets (without .json).",
    )
    parser.add_argument(
        "--list-presets",
        action="store_true",
        help="List available presets and exit.",
    )
    parser.add_argument(
        "--run-id",
        type=str,
        default=None,
        help="Optional override for run_id.",
    )
    parser.add_argument(
        "--base-dir",
        type=str,
        default=None,
        help="Optional override for base_dir.",
    )

    parser.add_argument("--dp", type=int, default=None, help="Override build_chain.dp")
    parser.add_argument(
        "--lactic-fraction",
        type=float,
        default=None,
        help="Override build_chain.lactic_fraction",
    )
    parser.add_argument(
        "--stereo-pattern",
        type=str,
        default=None,
        help="Override build_chain.stereo_pattern",
    )
    parser.add_argument(
        "--end-group",
        type=str,
        default=None,
        help="Override build_chain.end_group",
    )
    parser.add_argument(
        "--sequence-mode",
        type=str,
        default=None,
        help="Override build_chain.sequence_mode",
    )
    parser.add_argument(
        "--random-seed",
        type=int,
        default=None,
        help="Override build_chain.random_seed",
    )

    parser.add_argument(
        "--charge-method",
        type=str,
        default=None,
        help="Override parameterize_chain.charge_method",
    )
    parser.add_argument(
        "--forcefield",
        type=str,
        default=None,
        help="Override parameterize_chain.forcefield",
    )

    parser.add_argument(
        "--n-chains",
        type=int,
        default=None,
        help="Override pack_nanoparticle.n_chains",
    )
    parser.add_argument(
        "--shape",
        type=str,
        default=None,
        help="Override pack_nanoparticle.shape",
    )
    parser.add_argument(
        "--radius",
        "--radius-angstrom",
        dest="radius",
        type=float,
        default=None,
        help="Override pack_nanoparticle.radius_angstrom",
    )
    parser.add_argument(
        "--radius-mode",
        type=str,
        default=None,
        choices=["manual", "density_based"],
        help="Override pack_nanoparticle.radius_mode",
    )
    parser.add_argument(
        "--target-density",
        type=float,
        default=None,
        help="Override pack_nanoparticle.target_density_g_cm3",
    )
    parser.add_argument(
        "--packing-slack",
        type=float,
        default=None,
        help="Override pack_nanoparticle.packing_slack_factor",
    )
    parser.add_argument(
        "--minimum-radius",
        "--minimum-radius-angstrom",
        dest="minimum_radius",
        type=float,
        default=None,
        help="Override pack_nanoparticle.minimum_radius_angstrom",
    )
    parser.add_argument(
        "--retry-scales",
        nargs="+",
        type=float,
        default=None,
        help="Override pack_nanoparticle.retry_scale_factors",
    )
    parser.add_argument(
        "--packmol-tolerance",
        type=float,
        default=None,
        help="Override pack_nanoparticle.tolerance",
    )
    parser.add_argument(
        "--packmol-maxit",
        type=int,
        default=None,
        help="Override pack_nanoparticle.packmol_maxit",
    )
    parser.add_argument(
        "--packmol-nloop",
        type=int,
        default=None,
        help="Override pack_nanoparticle.packmol_nloop",
    )
    parser.add_argument(
        "--packmol-movefrac",
        type=float,
        default=None,
        help="Override pack_nanoparticle.packmol_movefrac",
    )
    parser.add_argument(
        "--packmol-discale",
        type=float,
        default=None,
        help="Override pack_nanoparticle.packmol_discale",
    )
    parser.add_argument(
        "--packmol-precision",
        type=int,
        default=None,
        help="Override pack_nanoparticle.packmol_precision",
    )

    parser.add_argument(
        "--system-name",
        type=str,
        default=None,
        help="Override assemble_system.system_name",
    )
    parser.add_argument(
        "--molecule-label",
        type=str,
        default=None,
        help="Override assemble_system.molecule_label",
    )

    parser.add_argument(
        "--gromacs-bundle-name",
        type=str,
        default=None,
        help="Override export_gromacs_handoff.bundle_name",
    )
    parser.add_argument(
        "--generic-bundle-name",
        type=str,
        default=None,
        help="Override export_generic_handoff.bundle_name",
    )

    parser.add_argument(
        "--ensemble-size",
        type=int,
        default=None,
        help="Generate an ensemble instead of the full workflow.",
    )
    parser.add_argument(
        "--ensemble-seed-start",
        type=int,
        default=1000,
        help="Starting seed for ensemble member generation.",
    )
    parser.add_argument(
        "--ensemble-mode",
        type=str,
        default="chain",
        choices=["chain", "nanoparticle"],
        help="Ensemble generation mode.",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=__version__,
    )

    return parser.parse_args()


def extract_cli_overrides(args: argparse.Namespace) -> dict[str, Any]:
    overrides: dict[str, Any] = {}

    if args.dp is not None:
        overrides["dp"] = args.dp
    if args.lactic_fraction is not None:
        overrides["lactic_fraction"] = args.lactic_fraction
    if args.stereo_pattern is not None:
        overrides["stereo_pattern"] = args.stereo_pattern
    if args.end_group is not None:
        overrides["end_group"] = args.end_group
    if args.sequence_mode is not None:
        overrides["sequence_mode"] = args.sequence_mode
    if args.random_seed is not None:
        overrides["random_seed"] = args.random_seed

    if args.charge_method is not None:
        overrides["charge_method"] = args.charge_method
    if args.forcefield is not None:
        overrides["forcefield"] = args.forcefield

    if args.n_chains is not None:
        overrides["n_chains"] = args.n_chains
    if args.shape is not None:
        overrides["shape"] = args.shape
    if args.radius is not None:
        overrides["radius_angstrom"] = args.radius
    if args.radius_mode is not None:
        overrides["radius_mode"] = args.radius_mode
    if args.target_density is not None:
        overrides["target_density_g_cm3"] = args.target_density
    if args.packing_slack is not None:
        overrides["packing_slack_factor"] = args.packing_slack
    if args.minimum_radius is not None:
        overrides["minimum_radius_angstrom"] = args.minimum_radius
    if args.retry_scales is not None:
        overrides["retry_scale_factors"] = args.retry_scales
    if args.packmol_tolerance is not None:
        overrides["tolerance"] = args.packmol_tolerance
    if args.packmol_maxit is not None:
        overrides["packmol_maxit"] = args.packmol_maxit
    if args.packmol_nloop is not None:
        overrides["packmol_nloop"] = args.packmol_nloop
    if args.packmol_movefrac is not None:
        overrides["packmol_movefrac"] = args.packmol_movefrac
    if args.packmol_discale is not None:
        overrides["packmol_discale"] = args.packmol_discale
    if args.packmol_precision is not None:
        overrides["packmol_precision"] = args.packmol_precision

    if args.system_name is not None:
        overrides["system_name"] = args.system_name
    if args.molecule_label is not None:
        overrides["molecule_label"] = args.molecule_label

    if args.gromacs_bundle_name is not None:
        overrides["gromacs_bundle_name"] = args.gromacs_bundle_name
    if args.generic_bundle_name is not None:
        overrides["generic_bundle_name"] = args.generic_bundle_name

    return overrides


def main() -> None:
    args = parse_args()

    if args.list_presets:
        presets = available_presets()
        if presets:
            print("Available presets:")
            for name in presets:
                print(f"  - {name}")
        else:
            print("No presets found.")
        return

    result = run_workflow_request(
        config_path=args.config,
        preset=args.preset,
        run_id=args.run_id,
        base_dir=args.base_dir,
        overrides=extract_cli_overrides(args),
        ensemble_size=args.ensemble_size,
        ensemble_seed_start=args.ensemble_seed_start,
        ensemble_mode=args.ensemble_mode,
    )
    print(format_run_result(result))


if __name__ == "__main__":
    main()