from __future__ import annotations

import json
import os
import platform
import queue
import shutil
import subprocess
import threading
import traceback
import tkinter as tk
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Any

from polymer_tool import app


def _optional_str(value: str) -> str | None:
    value = value.strip()
    return value or None


def _optional_int(value: str) -> int | None:
    value = value.strip()
    if not value:
        return None
    return int(value)


def _optional_float(value: str) -> float | None:
    value = value.strip()
    if not value:
        return None
    return float(value)


def _optional_float_list_csv(value: str) -> list[float] | None:
    value = value.strip()
    if not value:
        return None
    return [float(part.strip()) for part in value.split(",") if part.strip()]


def _is_wsl() -> bool:
    if os.environ.get("WSL_DISTRO_NAME"):
        return True
    try:
        text = Path("/proc/version").read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    return "microsoft" in text.lower()


def _wsl_windows_path(path: Path) -> str | None:
    if shutil.which("wslpath") is None:
        return None
    try:
        out = subprocess.check_output(
            ["wslpath", "-w", str(path)],
            text=True,
        ).strip()
    except Exception:
        return None
    return out or None


def _try_subprocess_open(cmd: list[str]) -> bool:
    try:
        completed = subprocess.run(
            cmd,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return False
    return completed.returncode == 0


def _open_path(path: str) -> None:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"Path does not exist: {p}")

    system = platform.system()

    if system == "Windows":
        os.startfile(str(p))  # type: ignore[attr-defined]
        return

    if _is_wsl():
        win_path = _wsl_windows_path(p)
        if win_path and shutil.which("explorer.exe"):
            if _try_subprocess_open(["explorer.exe", win_path]):
                return

    if system == "Darwin":
        if _try_subprocess_open(["open", str(p)]):
            return
        raise RuntimeError(f"Failed to open path with macOS 'open': {p}")

    if shutil.which("xdg-open"):
        if _try_subprocess_open(["xdg-open", str(p)]):
            return

    if shutil.which("gio"):
        if _try_subprocess_open(["gio", "open", str(p)]):
            return

    if webbrowser.open(p.as_uri()):
        return

    raise RuntimeError(f"Failed to open path: {p}")


def json_safe_result(result: dict[str, Any], text: str) -> str:
    return json.dumps({"result": result, "text": text})


def _parse_success_payload(payload: str) -> dict[str, Any]:
    data = json.loads(payload)
    return {"result": data["result"], "text": data["text"]}


class PolymerToolGUI:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("polymer-tool")
        self.root.geometry("1580x1040")

        self.result_queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self.run_thread: threading.Thread | None = None
        self.last_result: dict[str, Any] | None = None
        self.recent_runs: list[dict[str, Any]] = []
        self.user_configs: list[dict[str, Any]] = []
        self.favorite_profiles: list[str] = []
        self.loaded_config_data: dict[str, Any] | None = None
        self.launch_profile_defs = app.launch_profiles()

        self.vars: dict[str, tk.StringVar] = {}
        self.widgets: dict[str, tk.Widget] = {}
        self.widget_enabled_state: dict[str, str] = {}

        self._build_vars()
        self._build_ui()
        self._bind_var_traces()
        self._refresh_launch_profiles()
        self._refresh_presets(initial_load=True)
        self._refresh_recent_runs()
        self._refresh_user_configs()
        self._refresh_favorite_profiles()
        self._update_mode_dependent_state()
        self._update_summary()
        self._update_command_preview()
        self.root.after(150, self._poll_result_queue)

    def _build_vars(self) -> None:
        names = [
            "launch_profile",
            "preset",
            "config_path",
            "run_id",
            "base_dir",
            "ensemble_size",
            "ensemble_seed_start",
            "ensemble_mode",
            "dp",
            "lactic_fraction",
            "stereo_pattern",
            "end_group",
            "sequence_mode",
            "random_seed",
            "charge_method",
            "forcefield",
            "n_chains",
            "shape",
            "radius_mode",
            "radius_angstrom",
            "target_density_g_cm3",
            "packing_slack_factor",
            "minimum_radius_angstrom",
            "retry_scale_factors",
            "tolerance",
            "packmol_maxit",
            "packmol_nloop",
            "packmol_movefrac",
            "packmol_discale",
            "packmol_precision",
            "system_name",
            "molecule_label",
            "gromacs_bundle_name",
            "generic_bundle_name",
        ]
        for name in names:
            self.vars[name] = tk.StringVar()

        self.vars["ensemble_seed_start"].set("1000")
        self.vars["ensemble_mode"].set("chain")
        self.vars["radius_mode"].set("manual")
        self.vars["shape"].set("sphere")
        self.vars["launch_profile"].set("")

    def _register_widget(
        self,
        var_name: str,
        widget: tk.Widget,
        *,
        enabled_state: str = "normal",
    ) -> None:
        self.widgets[var_name] = widget
        self.widget_enabled_state[var_name] = enabled_state

    def _set_widget_enabled(self, var_name: str, enabled: bool) -> None:
        widget = self.widgets.get(var_name)
        if widget is None:
            return

        state = self.widget_enabled_state.get(var_name, "normal")
        try:
            widget.configure(state=state if enabled else "disabled")
        except tk.TclError:
            pass

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)

        top_pane = ttk.Panedwindow(outer, orient="horizontal")
        top_pane.pack(fill="both", expand=True, pady=(0, 8))

        left = ttk.Frame(top_pane)
        right = ttk.Frame(top_pane)
        top_pane.add(left, weight=5)
        top_pane.add(right, weight=4)

        self._build_left_panel(left)
        self._build_right_panel(right)

        output_frame = ttk.LabelFrame(outer, text="Output", padding=8)
        output_frame.pack(fill="both", expand=True)

        self.output_text = tk.Text(output_frame, wrap="word", height=16)
        self.output_text.pack(side="left", fill="both", expand=True)

        scroll = ttk.Scrollbar(
            output_frame,
            orient="vertical",
            command=self.output_text.yview,
        )
        scroll.pack(side="right", fill="y")
        self.output_text.configure(yscrollcommand=scroll.set)

    def _build_left_panel(self, parent: ttk.Frame) -> None:
        config_frame = ttk.LabelFrame(parent, text="Config source", padding=10)
        config_frame.pack(fill="x", pady=(0, 8))
        config_frame.grid_columnconfigure(1, weight=1)

        ttk.Label(config_frame, text="Launch profile").grid(
            row=0, column=0, sticky="w", padx=4, pady=4
        )
        self.profile_combo = ttk.Combobox(
            config_frame,
            textvariable=self.vars["launch_profile"],
            width=36,
            state="readonly",
        )
        self.profile_combo.grid(row=0, column=1, sticky="ew", padx=4, pady=4)
        self._register_widget("launch_profile", self.profile_combo, enabled_state="readonly")

        ttk.Button(
            config_frame,
            text="Apply profile",
            command=self._apply_selected_profile,
        ).grid(row=0, column=2, padx=4, pady=4)

        ttk.Button(
            config_frame,
            text="Toggle favorite",
            command=self._toggle_current_profile_favorite,
        ).grid(row=0, column=3, padx=4, pady=4)

        ttk.Label(config_frame, text="Preset").grid(
            row=1, column=0, sticky="w", padx=4, pady=4
        )
        self.preset_combo = ttk.Combobox(
            config_frame,
            textvariable=self.vars["preset"],
            width=36,
            state="readonly",
        )
        self.preset_combo.grid(row=1, column=1, sticky="ew", padx=4, pady=4)
        self._register_widget("preset", self.preset_combo, enabled_state="readonly")
        self.preset_combo.bind("<<ComboboxSelected>>", self._on_preset_selected)

        ttk.Button(
            config_frame,
            text="Refresh presets",
            command=lambda: self._refresh_presets(initial_load=False),
        ).grid(row=1, column=2, padx=4, pady=4)

        ttk.Button(
            config_frame,
            text="Load current source",
            command=self._load_selected_preset,
        ).grid(row=1, column=3, padx=4, pady=4)

        ttk.Label(config_frame, text="Config path").grid(
            row=2, column=0, sticky="w", padx=4, pady=4
        )
        config_entry = ttk.Entry(
            config_frame,
            textvariable=self.vars["config_path"],
            width=70,
        )
        config_entry.grid(row=2, column=1, columnspan=3, sticky="ew", padx=4, pady=4)
        self._register_widget("config_path", config_entry)

        quick_frame = ttk.LabelFrame(parent, text="Quick routine runs", padding=10)
        quick_frame.pack(fill="x", pady=(0, 8))

        ttk.Button(
            quick_frame,
            text="Quick run 24mer NP",
            command=lambda: self._quick_run_profile("24mer_np_ensemble"),
        ).pack(side="left")
        ttk.Button(
            quick_frame,
            text="Quick run 50mer NP",
            command=lambda: self._quick_run_profile("50mer_np_ensemble"),
        ).pack(side="left", padx=8)
        ttk.Button(
            quick_frame,
            text="Quick run 100mer screen",
            command=lambda: self._quick_run_profile("100mer_screen_single"),
        ).pack(side="left", padx=8)

        run_frame = ttk.LabelFrame(parent, text="Run options", padding=10)
        run_frame.pack(fill="x", pady=(0, 8))
        run_frame.grid_columnconfigure(1, weight=1)
        run_frame.grid_columnconfigure(3, weight=1)

        self._add_labeled_entry(run_frame, "Run ID", "run_id", row=0, col=0, width=26)
        self._add_labeled_entry(run_frame, "Base dir", "base_dir", row=0, col=2, width=40)
        self._add_labeled_entry(
            run_frame,
            "Ensemble size",
            "ensemble_size",
            row=1,
            col=0,
            width=10,
        )
        self._add_labeled_entry(
            run_frame,
            "Ensemble seed start",
            "ensemble_seed_start",
            row=1,
            col=2,
            width=10,
        )

        ttk.Label(run_frame, text="Ensemble mode").grid(
            row=2, column=0, sticky="w", padx=4, pady=4
        )
        ensemble_mode_combo = ttk.Combobox(
            run_frame,
            textvariable=self.vars["ensemble_mode"],
            values=["chain", "nanoparticle"],
            width=18,
            state="readonly",
        )
        ensemble_mode_combo.grid(row=2, column=1, sticky="w", padx=4, pady=4)
        self._register_widget(
            "ensemble_mode",
            ensemble_mode_combo,
            enabled_state="readonly",
        )

        notebook = ttk.Notebook(parent)
        notebook.pack(fill="both", expand=True, pady=(0, 8))

        chain_tab = ttk.Frame(notebook, padding=10)
        param_tab = ttk.Frame(notebook, padding=10)
        pack_tab = ttk.Frame(notebook, padding=10)
        advanced_tab = ttk.Frame(notebook, padding=10)
        export_tab = ttk.Frame(notebook, padding=10)

        notebook.add(chain_tab, text="Chain")
        notebook.add(param_tab, text="Parameterization")
        notebook.add(pack_tab, text="Packing")
        notebook.add(advanced_tab, text="Advanced")
        notebook.add(export_tab, text="Assembly / Export")

        self._build_chain_tab(chain_tab)
        self._build_parameterize_tab(param_tab)
        self._build_pack_tab(pack_tab)
        self._build_advanced_tab(advanced_tab)
        self._build_export_tab(export_tab)

        button_frame = ttk.Frame(parent)
        button_frame.pack(fill="x", pady=(0, 8))

        self.run_button = ttk.Button(
            button_frame,
            text="Run",
            command=self._start_run,
        )
        self.run_button.pack(side="left")

        ttk.Button(
            button_frame,
            text="Preflight",
            command=self._run_preflight_only,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Load current source",
            command=self._load_selected_preset,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Save current config...",
            command=self._save_current_config,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Save as named config...",
            command=self._save_named_config,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Export current bundle...",
            command=self._export_current_bundle,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Load selected run",
            command=self._load_selected_run_into_form,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Copy command preview",
            command=self._copy_command_preview,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Open selected run",
            command=self._open_selected_run,
        ).pack(side="left", padx=8)

        ttk.Button(
            button_frame,
            text="Clear output",
            command=self._clear_output,
        ).pack(side="left", padx=8)

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(button_frame, textvariable=self.status_var).pack(side="left", padx=12)

    def _build_right_panel(self, parent: ttk.Frame) -> None:
        summary_frame = ttk.LabelFrame(parent, text="Run summary", padding=8)
        summary_frame.pack(fill="both", expand=True, pady=(0, 8))

        self.summary_text = tk.Text(summary_frame, wrap="word", height=14)
        self.summary_text.pack(side="left", fill="both", expand=True)

        summary_scroll = ttk.Scrollbar(
            summary_frame,
            orient="vertical",
            command=self.summary_text.yview,
        )
        summary_scroll.pack(side="right", fill="y")
        self.summary_text.configure(yscrollcommand=summary_scroll.set)

        command_frame = ttk.LabelFrame(parent, text="Command preview", padding=8)
        command_frame.pack(fill="x", pady=(0, 8))

        self.command_text = tk.Text(command_frame, wrap="word", height=6)
        self.command_text.pack(side="left", fill="both", expand=True)

        command_scroll = ttk.Scrollbar(
            command_frame,
            orient="vertical",
            command=self.command_text.yview,
        )
        command_scroll.pack(side="right", fill="y")
        self.command_text.configure(yscrollcommand=command_scroll.set)

        diagnostics_frame = ttk.LabelFrame(parent, text="Diagnostics / preflight / diff", padding=8)
        diagnostics_frame.pack(fill="both", expand=True, pady=(0, 8))

        self.diagnostics_text = tk.Text(diagnostics_frame, wrap="word", height=10)
        self.diagnostics_text.pack(side="left", fill="both", expand=True)

        diagnostics_scroll = ttk.Scrollbar(
            diagnostics_frame,
            orient="vertical",
            command=self.diagnostics_text.yview,
        )
        diagnostics_scroll.pack(side="right", fill="y")
        self.diagnostics_text.configure(yscrollcommand=diagnostics_scroll.set)

        recent_frame = ttk.LabelFrame(parent, text="Recent runs", padding=8)
        recent_frame.pack(fill="both", expand=True, pady=(0, 8))

        self.recent_listbox = tk.Listbox(recent_frame, height=7)
        self.recent_listbox.pack(side="left", fill="both", expand=True)
        self.recent_listbox.bind("<<ListboxSelect>>", self._on_recent_selection)
        self.recent_listbox.bind("<Double-Button-1>", self._on_recent_double_click)

        recent_scroll = ttk.Scrollbar(
            recent_frame,
            orient="vertical",
            command=self.recent_listbox.yview,
        )
        recent_scroll.pack(side="right", fill="y")
        self.recent_listbox.configure(yscrollcommand=recent_scroll.set)

        recent_button_frame = ttk.Frame(parent)
        recent_button_frame.pack(fill="x", pady=(0, 8))

        ttk.Button(
            recent_button_frame,
            text="Refresh recent runs",
            command=self._refresh_recent_runs,
        ).pack(side="left")

        ttk.Button(
            recent_button_frame,
            text="Load into form",
            command=self._load_selected_run_into_form,
        ).pack(side="left", padx=8)

        ttk.Button(
            recent_button_frame,
            text="Compare to current",
            command=self._compare_selected_run_to_current,
        ).pack(side="left", padx=8)

        ttk.Button(
            recent_button_frame,
            text="Open selected",
            command=self._open_selected_run,
        ).pack(side="left", padx=8)

        favorite_frame = ttk.LabelFrame(parent, text="Favorite launch profiles", padding=8)
        favorite_frame.pack(fill="both", expand=True, pady=(0, 8))

        self.favorite_listbox = tk.Listbox(favorite_frame, height=5)
        self.favorite_listbox.pack(side="left", fill="both", expand=True)

        favorite_scroll = ttk.Scrollbar(
            favorite_frame,
            orient="vertical",
            command=self.favorite_listbox.yview,
        )
        favorite_scroll.pack(side="right", fill="y")
        self.favorite_listbox.configure(yscrollcommand=favorite_scroll.set)

        favorite_button_frame = ttk.Frame(parent)
        favorite_button_frame.pack(fill="x", pady=(0, 8))

        ttk.Button(
            favorite_button_frame,
            text="Refresh favorites",
            command=self._refresh_favorite_profiles,
        ).pack(side="left")

        ttk.Button(
            favorite_button_frame,
            text="Apply favorite",
            command=self._apply_selected_favorite_profile,
        ).pack(side="left", padx=8)

        ttk.Button(
            favorite_button_frame,
            text="Quick run favorite",
            command=self._quick_run_selected_favorite_profile,
        ).pack(side="left", padx=8)

        user_config_frame = ttk.LabelFrame(parent, text="Custom config library", padding=8)
        user_config_frame.pack(fill="both", expand=True)

        self.user_config_listbox = tk.Listbox(user_config_frame, height=7)
        self.user_config_listbox.pack(side="left", fill="both", expand=True)
        self.user_config_listbox.bind("<<ListboxSelect>>", self._on_user_config_selection)
        self.user_config_listbox.bind("<Double-Button-1>", self._on_user_config_double_click)

        user_scroll = ttk.Scrollbar(
            user_config_frame,
            orient="vertical",
            command=self.user_config_listbox.yview,
        )
        user_scroll.pack(side="right", fill="y")
        self.user_config_listbox.configure(yscrollcommand=user_scroll.set)

        user_button_frame = ttk.Frame(parent)
        user_button_frame.pack(fill="x")

        ttk.Button(
            user_button_frame,
            text="Refresh library",
            command=self._refresh_user_configs,
        ).pack(side="left")

        ttk.Button(
            user_button_frame,
            text="Load selected config",
            command=self._load_selected_user_config,
        ).pack(side="left", padx=8)

        ttk.Button(
            user_button_frame,
            text="Compare to current",
            command=self._compare_selected_user_config_to_current,
        ).pack(side="left", padx=8)

        ttk.Button(
            user_button_frame,
            text="Open config library",
            command=self._open_user_config_library,
        ).pack(side="left", padx=8)

    def _build_chain_tab(self, frame: ttk.Frame) -> None:
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_columnconfigure(3, weight=1)
        self._add_labeled_entry(frame, "DP", "dp", row=0, col=0)
        self._add_labeled_entry(frame, "Lactic fraction", "lactic_fraction", row=0, col=2)
        self._add_labeled_entry(frame, "Stereo pattern", "stereo_pattern", row=1, col=0)
        self._add_labeled_entry(frame, "End group", "end_group", row=1, col=2)
        self._add_labeled_entry(frame, "Sequence mode", "sequence_mode", row=2, col=0)
        self._add_labeled_entry(frame, "Random seed", "random_seed", row=2, col=2)

    def _build_parameterize_tab(self, frame: ttk.Frame) -> None:
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_columnconfigure(3, weight=1)
        self._add_labeled_entry(frame, "Charge method", "charge_method", row=0, col=0)
        self._add_labeled_entry(frame, "Forcefield", "forcefield", row=0, col=2)

    def _build_pack_tab(self, frame: ttk.Frame) -> None:
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_columnconfigure(3, weight=1)

        self._add_labeled_entry(frame, "n_chains", "n_chains", row=0, col=0)

        ttk.Label(frame, text="Shape").grid(row=0, column=2, sticky="w", padx=4, pady=4)
        shape_combo = ttk.Combobox(
            frame,
            textvariable=self.vars["shape"],
            values=["sphere"],
            width=24,
            state="readonly",
        )
        shape_combo.grid(row=0, column=3, sticky="ew", padx=4, pady=4)
        self._register_widget("shape", shape_combo, enabled_state="readonly")

        ttk.Label(frame, text="Radius mode").grid(
            row=1, column=0, sticky="w", padx=4, pady=4
        )
        radius_mode_combo = ttk.Combobox(
            frame,
            textvariable=self.vars["radius_mode"],
            values=["manual", "density_based"],
            width=24,
            state="readonly",
        )
        radius_mode_combo.grid(row=1, column=1, sticky="ew", padx=4, pady=4)
        self._register_widget(
            "radius_mode",
            radius_mode_combo,
            enabled_state="readonly",
        )

        self._add_labeled_entry(frame, "Radius Å", "radius_angstrom", row=1, col=2)
        self._add_labeled_entry(
            frame,
            "Target density",
            "target_density_g_cm3",
            row=2,
            col=0,
        )
        self._add_labeled_entry(
            frame,
            "Packing slack",
            "packing_slack_factor",
            row=2,
            col=2,
        )
        self._add_labeled_entry(
            frame,
            "Minimum radius Å",
            "minimum_radius_angstrom",
            row=3,
            col=0,
        )

    def _build_advanced_tab(self, frame: ttk.Frame) -> None:
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_columnconfigure(3, weight=1)

        self._add_labeled_entry(
            frame,
            "Retry scales CSV",
            "retry_scale_factors",
            row=0,
            col=0,
        )
        self._add_labeled_entry(frame, "Tolerance", "tolerance", row=0, col=2)
        self._add_labeled_entry(frame, "Packmol maxit", "packmol_maxit", row=1, col=0)
        self._add_labeled_entry(frame, "Packmol nloop", "packmol_nloop", row=1, col=2)
        self._add_labeled_entry(frame, "Packmol movefrac", "packmol_movefrac", row=2, col=0)
        self._add_labeled_entry(frame, "Packmol discale", "packmol_discale", row=2, col=2)
        self._add_labeled_entry(frame, "Packmol precision", "packmol_precision", row=3, col=0)

    def _build_export_tab(self, frame: ttk.Frame) -> None:
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_columnconfigure(3, weight=1)
        self._add_labeled_entry(frame, "System name", "system_name", row=0, col=0)
        self._add_labeled_entry(frame, "Molecule label", "molecule_label", row=0, col=2)
        self._add_labeled_entry(
            frame,
            "GROMACS bundle name",
            "gromacs_bundle_name",
            row=1,
            col=0,
        )
        self._add_labeled_entry(
            frame,
            "Generic bundle name",
            "generic_bundle_name",
            row=1,
            col=2,
        )

    def _add_labeled_entry(
        self,
        parent: ttk.Frame,
        label: str,
        var_name: str,
        *,
        row: int,
        col: int = 0,
        width: int = 24,
    ) -> None:
        ttk.Label(parent, text=label).grid(
            row=row,
            column=col,
            sticky="w",
            padx=4,
            pady=4,
        )
        entry = ttk.Entry(parent, textvariable=self.vars[var_name], width=width)
        entry.grid(
            row=row,
            column=col + 1,
            sticky="ew",
            padx=4,
            pady=4,
        )
        self._register_widget(var_name, entry)

    def _bind_var_traces(self) -> None:
        for var in self.vars.values():
            var.trace_add("write", self._on_form_change)

    def _on_form_change(self, *_args) -> None:
        self._update_mode_dependent_state()
        self._update_summary()
        self._update_command_preview()

    def _set_diagnostics_text(self, text: str) -> None:
        self.diagnostics_text.delete("1.0", "end")
        self.diagnostics_text.insert("end", text)

    def _append_output(self, text: str) -> None:
        self.output_text.insert("end", text)
        self.output_text.see("end")

    def _refresh_launch_profiles(self) -> None:
        names = [profile["name"] for profile in self.launch_profile_defs]
        self.profile_combo["values"] = names
        if names and self.vars["launch_profile"].get() not in names:
            self.vars["launch_profile"].set(names[0])

    def _refresh_favorite_profiles(self) -> None:
        self.favorite_profiles = app.load_favorite_launch_profiles()
        self.favorite_listbox.delete(0, "end")
        for name in self.favorite_profiles:
            self.favorite_listbox.insert("end", name)

    def _get_selected_favorite_profile(self) -> str | None:
        selection = self.favorite_listbox.curselection()
        if not selection:
            return None
        index = selection[0]
        if index < 0 or index >= len(self.favorite_profiles):
            return None
        return self.favorite_profiles[index]

    def _toggle_current_profile_favorite(self) -> None:
        profile_name = _optional_str(self.vars["launch_profile"].get())
        if not profile_name:
            messagebox.showinfo("polymer-tool", "Select a launch profile first.")
            return

        try:
            names = app.toggle_favorite_launch_profile(profile_name)
            self._refresh_favorite_profiles()
            state = "favorite" if profile_name in names else "not favorite"
            self.status_var.set(f"{profile_name} is now {state}")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to update favorites:\n{exc}")

    def _apply_selected_favorite_profile(self) -> None:
        name = self._get_selected_favorite_profile()
        if not name:
            messagebox.showinfo("polymer-tool", "Select a favorite profile first.")
            return
        self._apply_profile_by_name(name, announce=True)

    def _quick_run_selected_favorite_profile(self) -> None:
        name = self._get_selected_favorite_profile()
        if not name:
            messagebox.showinfo("polymer-tool", "Select a favorite profile first.")
            return
        self._apply_profile_by_name(name, announce=True)
        self._start_run()

    def _override_var_from_key(self, key: str, value: Any) -> None:
        if isinstance(value, list):
            self.vars[key].set(",".join(str(v) for v in value))
        elif value is None:
            self.vars[key].set("")
        else:
            self.vars[key].set(str(value))

    def _populate_form_from_config(self, config: dict[str, Any]) -> None:
        workflow = config["workflow_config"]
        build = workflow["build_chain"]
        param = workflow["parameterize_chain"]
        pack = workflow["pack_nanoparticle"]
        assemble = workflow["assemble_system"]
        gromacs = workflow["export_gromacs_handoff"]
        generic = workflow["export_generic_handoff"]

        self.vars["dp"].set(str(build.get("dp", "")))
        self.vars["lactic_fraction"].set(str(build.get("lactic_fraction", "")))
        self.vars["stereo_pattern"].set(str(build.get("stereo_pattern", "")))
        self.vars["end_group"].set(str(build.get("end_group", "")))
        self.vars["sequence_mode"].set(str(build.get("sequence_mode", "")))
        self.vars["random_seed"].set(
            "" if build.get("random_seed") is None else str(build.get("random_seed"))
        )

        self.vars["charge_method"].set(str(param.get("charge_method", "")))
        self.vars["forcefield"].set(str(param.get("forcefield", "")))

        self.vars["n_chains"].set(str(pack.get("n_chains", "")))
        self.vars["shape"].set(str(pack.get("shape", "sphere")))
        self.vars["radius_mode"].set(str(pack.get("radius_mode", "manual")))
        self.vars["radius_angstrom"].set(
            "" if pack.get("radius_angstrom") is None else str(pack.get("radius_angstrom"))
        )
        self.vars["target_density_g_cm3"].set(str(pack.get("target_density_g_cm3", "")))
        self.vars["packing_slack_factor"].set(str(pack.get("packing_slack_factor", "")))
        self.vars["minimum_radius_angstrom"].set(
            "" if pack.get("minimum_radius_angstrom") is None else str(pack.get("minimum_radius_angstrom"))
        )
        self.vars["retry_scale_factors"].set(
            ",".join(str(x) for x in pack.get("retry_scale_factors", []))
        )
        self.vars["tolerance"].set(str(pack.get("tolerance", "")))
        self.vars["packmol_maxit"].set(str(pack.get("packmol_maxit", "")))
        self.vars["packmol_nloop"].set(str(pack.get("packmol_nloop", "")))
        self.vars["packmol_movefrac"].set(str(pack.get("packmol_movefrac", "")))
        self.vars["packmol_discale"].set(str(pack.get("packmol_discale", "")))
        self.vars["packmol_precision"].set(str(pack.get("packmol_precision", "")))

        self.vars["system_name"].set(str(assemble.get("system_name", "")))
        self.vars["molecule_label"].set(str(assemble.get("molecule_label", "")))
        self.vars["gromacs_bundle_name"].set(str(gromacs.get("bundle_name", "")))
        self.vars["generic_bundle_name"].set(str(generic.get("bundle_name", "")))

    def _apply_request_to_form(self, request: dict[str, Any]) -> None:
        preset = request.get("preset")
        config_path = request.get("config_path")
        config_data = request.get("config_data")

        self.loaded_config_data = None
        self.vars["preset"].set("" if preset is None else str(preset))
        self.vars["config_path"].set("" if config_path is None else str(config_path))
        self.vars["run_id"].set("" if request.get("run_id") is None else str(request["run_id"]))
        self.vars["base_dir"].set("" if request.get("base_dir") is None else str(request["base_dir"]))

        ensemble_size = request.get("ensemble_size")
        self.vars["ensemble_size"].set("" if ensemble_size is None else str(ensemble_size))
        self.vars["ensemble_seed_start"].set(str(request.get("ensemble_seed_start", 1000)))
        self.vars["ensemble_mode"].set(str(request.get("ensemble_mode", "chain")))

        if config_data is not None:
            self.loaded_config_data = deepcopy(config_data)
            self._populate_form_from_config(config_data)
        elif config_path or preset:
            config = app.resolve_config_data(config_path, preset)
            self._populate_form_from_config(config)

        overrides = request.get("overrides", {}) or {}
        for key, value in overrides.items():
            if key in self.vars:
                self._override_var_from_key(key, value)

    def _apply_profile_by_name(self, profile_name: str, announce: bool = True) -> None:
        profile = app.get_launch_profile(profile_name)
        self.vars["launch_profile"].set(profile_name)
        self._apply_request_to_form(profile["request"])
        if announce:
            self._append_output(f"Applied launch profile: {profile_name}\n")
            self.status_var.set(f"Applied profile: {profile_name}")

    def _apply_selected_profile(self) -> None:
        profile_name = _optional_str(self.vars["launch_profile"].get())
        if not profile_name:
            messagebox.showinfo("polymer-tool", "Select a launch profile first.")
            return

        try:
            self._apply_profile_by_name(profile_name, announce=True)
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to apply profile:\n{exc}")

    def _quick_run_profile(self, profile_name: str) -> None:
        try:
            self._apply_profile_by_name(profile_name, announce=True)
            self._start_run()
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed quick run:\n{exc}")

    def _refresh_presets(self, initial_load: bool = False) -> None:
        presets = app.available_presets()
        self.preset_combo["values"] = presets

        current = self.vars["preset"].get()
        if presets:
            if current not in presets:
                self.vars["preset"].set(presets[0])
            if initial_load:
                self._load_selected_preset(silent=False)
        else:
            self.vars["preset"].set("")
            if initial_load:
                self._append_output("No bundled presets found.\n")

    def _refresh_user_configs(self) -> None:
        self.user_configs = app.discover_user_configs(limit=200)
        self.user_config_listbox.delete(0, "end")

        for item in self.user_configs:
            label = f"{item['name']} | {item['project_name']} | {item['workflow_name']}"
            self.user_config_listbox.insert("end", label)

    def _on_preset_selected(self, _event=None) -> None:
        self._load_selected_preset(silent=False)

    def _on_user_config_selection(self, _event=None) -> None:
        config = self._get_selected_user_config()
        if config is not None:
            self.status_var.set(f"Selected config: {config['name']}")

    def _on_user_config_double_click(self, _event=None) -> None:
        self._load_selected_user_config()

    def _load_selected_preset(self, silent: bool = False) -> None:
        preset = _optional_str(self.vars["preset"].get())
        config_path = _optional_str(self.vars["config_path"].get())

        if not preset and not config_path:
            if not silent:
                messagebox.showerror(
                    "polymer-tool",
                    "Select a preset or provide a config path.",
                )
            return

        try:
            config = app.resolve_config_data(config_path, preset)
            self.loaded_config_data = None
            self._populate_form_from_config(config)

            if not silent:
                source_label = config_path or preset or "<unknown>"
                self._append_output(f"Loaded preset/config into form: {source_label}\n")
                self.status_var.set("Preset loaded")
        except Exception as exc:
            if not silent:
                messagebox.showerror(
                    "polymer-tool",
                    f"Failed to load preset/config:\n{exc}",
                )

    def _get_selected_recent_run(self) -> dict[str, Any] | None:
        selection = self.recent_listbox.curselection()
        if not selection:
            return None
        index = selection[0]
        if index < 0 or index >= len(self.recent_runs):
            return None
        return self.recent_runs[index]

    def _get_selected_user_config(self) -> dict[str, Any] | None:
        selection = self.user_config_listbox.curselection()
        if not selection:
            return None
        index = selection[0]
        if index < 0 or index >= len(self.user_configs):
            return None
        return self.user_configs[index]

    def _load_selected_user_config(self) -> None:
        item = self._get_selected_user_config()
        if item is None:
            messagebox.showinfo("polymer-tool", "Select a saved config first.")
            return

        try:
            config = app.load_user_config_by_name(item["name"])
            self.loaded_config_data = None
            self.vars["preset"].set("")
            self.vars["config_path"].set(item["path"])
            self._populate_form_from_config(config)
            self._append_output(f"Loaded saved config into form: {item['path']}\n")
            self.status_var.set("Saved config loaded")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to load saved config:\n{exc}")

    def _load_selected_run_into_form(self) -> None:
        run = self._get_selected_recent_run()
        if run is None:
            messagebox.showinfo("polymer-tool", "Select a recent run first.")
            return

        try:
            config = app.load_config_from_run_state(run["base_dir"])
            snapshot = app.load_run_snapshot(run["base_dir"])
            self.loaded_config_data = config
            self.vars["preset"].set("")
            self.vars["config_path"].set("")
            self.vars["run_id"].set("")
            self.vars["base_dir"].set("")
            self._populate_form_from_config(config)
            self._append_output(
                f"Loaded recent run into form: {snapshot['run_id']} ({snapshot['base_dir']})\n"
            )
            self.status_var.set("Recent run loaded into form")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to load selected run:\n{exc}")

    def _save_current_config(self) -> None:
        try:
            request = self._build_current_request()
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Invalid input:\n{exc}")
            return

        if not request["preset"] and not request["config_path"] and request["config_data"] is None:
            messagebox.showerror(
                "polymer-tool",
                "Select a preset, provide a config path, or load a recent run first.",
            )
            return

        suggested_name = "polymer_tool_config.json"
        preset = _optional_str(self.vars["preset"].get())
        if preset:
            suggested_name = f"{preset}_custom.json"

        output_path = filedialog.asksaveasfilename(
            title="Save workflow config",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile=suggested_name,
        )
        if not output_path:
            return

        try:
            saved = app.save_resolved_config(
                output_path,
                config_path=request["config_path"],
                preset=request["preset"],
                config_data=request["config_data"],
                overrides=request["overrides"],
            )
            self.loaded_config_data = None
            self.vars["preset"].set("")
            self.vars["config_path"].set(saved)
            self._append_output(f"Saved current config to: {saved}\n")
            self.status_var.set("Config saved")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to save config:\n{exc}")

    def _save_named_config(self) -> None:
        try:
            request = self._build_current_request()
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Invalid input:\n{exc}")
            return

        if not request["preset"] and not request["config_path"] and request["config_data"] is None:
            messagebox.showerror(
                "polymer-tool",
                "Select a preset, provide a config path, or load a recent run first.",
            )
            return

        name = simpledialog.askstring(
            "polymer-tool",
            "Enter a name for the saved config:",
        )
        if not name:
            return

        try:
            saved = app.save_named_user_config(
                name,
                config_path=request["config_path"],
                preset=request["preset"],
                config_data=request["config_data"],
                overrides=request["overrides"],
            )
            self.loaded_config_data = None
            self.vars["preset"].set("")
            self.vars["config_path"].set(saved)
            self._refresh_user_configs()
            self._append_output(f"Saved named config to library: {saved}\n")
            self.status_var.set("Named config saved")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to save named config:\n{exc}")

    def _export_current_bundle(self) -> None:
        try:
            request = self._build_current_request()
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Invalid input:\n{exc}")
            return

        if not request["preset"] and not request["config_path"] and request["config_data"] is None:
            messagebox.showerror(
                "polymer-tool",
                "Select a preset, provide a config path, or load a recent run first.",
            )
            return

        parent_dir = filedialog.askdirectory(title="Choose export bundle location")
        if not parent_dir:
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_dir = Path(parent_dir) / f"polymer_tool_bundle_{timestamp}"

        try:
            result = app.export_request_bundle(out_dir, **request)
            self._append_output(f"Exported current bundle to: {result['bundle_dir']}\n")
            self.status_var.set("Current bundle exported")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to export bundle:\n{exc}")

    def _open_user_config_library(self) -> None:
        try:
            path = app.ensure_user_config_root()
            _open_path(str(path))
            self.status_var.set(f"Opened config library: {path}")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to open config library:\n{exc}")

    def _collect_overrides(self) -> dict[str, Any]:
        overrides: dict[str, Any] = {}

        mapping = [
            ("dp", _optional_int),
            ("lactic_fraction", _optional_float),
            ("stereo_pattern", _optional_str),
            ("end_group", _optional_str),
            ("sequence_mode", _optional_str),
            ("random_seed", _optional_int),
            ("charge_method", _optional_str),
            ("forcefield", _optional_str),
            ("n_chains", _optional_int),
            ("shape", _optional_str),
            ("radius_mode", _optional_str),
            ("radius_angstrom", _optional_float),
            ("target_density_g_cm3", _optional_float),
            ("packing_slack_factor", _optional_float),
            ("minimum_radius_angstrom", _optional_float),
            ("retry_scale_factors", _optional_float_list_csv),
            ("tolerance", _optional_float),
            ("packmol_maxit", _optional_int),
            ("packmol_nloop", _optional_int),
            ("packmol_movefrac", _optional_float),
            ("packmol_discale", _optional_float),
            ("packmol_precision", _optional_int),
            ("system_name", _optional_str),
            ("molecule_label", _optional_str),
            ("gromacs_bundle_name", _optional_str),
            ("generic_bundle_name", _optional_str),
        ]

        for key, parser in mapping:
            value = parser(self.vars[key].get())
            if value is not None:
                overrides[key] = value

        return overrides

    def _collect_gui_state(self) -> dict:
        return {
            "dp": self.dp_input.value(),
            "lactic_fraction": self.lactic_fraction_input.value(),
            "stereo_pattern": self.stereo_pattern_input.currentText(),
            "end_group": self.end_group_input.currentText(),
            "sequence_mode": self.sequence_mode_input.currentText(),
            "random_seed": self.random_seed_input.text(),

            "charge_method": getattr(self, "charge_method_input", None),
            "forcefield": getattr(self, "forcefield_input", None),

            "n_chains": getattr(self, "n_chains_input", None),
            "shape": getattr(self, "shape_input", None),
            "radius": getattr(self, "radius_input", None),
            "radius_mode": getattr(self, "radius_mode_input", None),
            "target_density": getattr(self, "target_density_input", None),
            "packing_slack": getattr(self, "packing_slack_input", None),

            "packmol_tolerance": getattr(self, "packmol_tolerance_input", None),
            "packmol_maxit": getattr(self, "packmol_maxit_input", None),
            "packmol_nloop": getattr(self, "packmol_nloop_input", None),
        }

    def _update_mode_dependent_state(self) -> None:
        ensemble_size_text = self.vars["ensemble_size"].get().strip()
        ensemble_enabled = bool(ensemble_size_text)
        ensemble_mode = self.vars["ensemble_mode"].get().strip() or "chain"
        chain_ensemble = ensemble_enabled and ensemble_mode == "chain"

        radius_mode = self.vars["radius_mode"].get().strip() or "manual"
        density_mode = radius_mode == "density_based"

        self._set_widget_enabled("ensemble_seed_start", ensemble_enabled)
        self._set_widget_enabled("ensemble_mode", ensemble_enabled)

        chain_only_fields = [
            "charge_method",
            "forcefield",
            "n_chains",
            "shape",
            "radius_mode",
            "radius_angstrom",
            "target_density_g_cm3",
            "packing_slack_factor",
            "minimum_radius_angstrom",
            "retry_scale_factors",
            "tolerance",
            "packmol_maxit",
            "packmol_nloop",
            "packmol_movefrac",
            "packmol_discale",
            "packmol_precision",
            "system_name",
            "molecule_label",
            "gromacs_bundle_name",
            "generic_bundle_name",
        ]

        for field in chain_only_fields:
            self._set_widget_enabled(field, not chain_ensemble)

        if not chain_ensemble:
            self._set_widget_enabled("radius_angstrom", radius_mode == "manual")
            self._set_widget_enabled("target_density_g_cm3", density_mode)
            self._set_widget_enabled("packing_slack_factor", density_mode)
            self._set_widget_enabled("minimum_radius_angstrom", density_mode)

    def _build_summary_text(self) -> str:
        preset = _optional_str(self.vars["preset"].get())
        config_path = _optional_str(self.vars["config_path"].get())
        profile = _optional_str(self.vars["launch_profile"].get())

        if config_path:
            source = config_path
            source_type = "config path"
        elif preset:
            source = preset
            source_type = "preset"
        elif self.loaded_config_data is not None:
            source = "<loaded recent run snapshot>"
            source_type = "in-memory run snapshot"
        else:
            source = "<none>"
            source_type = "none"

        ensemble_size = self.vars["ensemble_size"].get().strip()
        ensemble_mode = self.vars["ensemble_mode"].get().strip() or "chain"
        radius_mode = self.vars["radius_mode"].get().strip() or "manual"

        lines: list[str] = []
        lines.append("Source")
        lines.append(f"  active source type: {source_type}")
        lines.append(f"  active source: {source}")
        lines.append(f"  preset: {preset or '<none>'}")
        lines.append(f"  config path: {config_path or '<none>'}")
        lines.append(f"  launch profile: {profile or '<none>'}")
        lines.append(f"  user config library: {app.default_user_config_root()}")
        lines.append("")

        if ensemble_size:
            lines.append("Execution mode")
            lines.append("  mode: ensemble")
            lines.append(f"  ensemble mode: {ensemble_mode}")
            lines.append(f"  ensemble size: {ensemble_size}")
            lines.append(
                f"  ensemble seed start: {self.vars['ensemble_seed_start'].get().strip() or '1000'}"
            )
        else:
            lines.append("Execution mode")
            lines.append("  mode: single workflow")

        lines.append("")
        lines.append("Packing mode")
        lines.append(f"  radius mode: {radius_mode}")
        if radius_mode == "manual":
            lines.append(
                f"  radius Å: {self.vars['radius_angstrom'].get().strip() or '<unset>'}"
            )
        else:
            lines.append(
                f"  target density: {self.vars['target_density_g_cm3'].get().strip() or '<unset>'}"
            )
            lines.append(
                f"  packing slack: {self.vars['packing_slack_factor'].get().strip() or '<unset>'}"
            )
            lines.append(
                f"  minimum radius Å: {self.vars['minimum_radius_angstrom'].get().strip() or '<unset>'}"
            )

        lines.append("")
        if ensemble_size and ensemble_mode == "chain":
            lines.append("Active stages")
            lines.append("  build_chain only")
            lines.append("  parameterization/packing/export settings are ignored")
        else:
            lines.append("Active stages")
            lines.append("  build_chain")
            lines.append("  parameterize_chain")
            lines.append("  pack_nanoparticle")
            if not ensemble_size:
                lines.append("  assemble_system")
                lines.append("  prepare_topology_bridge")
                lines.append("  export_gromacs_handoff")
                lines.append("  export_generic_handoff")
                lines.append("  export_descriptor")

        lines.append("")
        lines.append("Parsed overrides")
        try:
            overrides = self._collect_overrides()
            if overrides:
                for key in sorted(overrides):
                    lines.append(f"  {key}: {overrides[key]}")
            else:
                lines.append("  <none>")
        except Exception as exc:
            lines.append(f"  <invalid input: {exc}>")

        if self.last_result:
            lines.append("")
            lines.append("Last completed run")
            lines.append(f"  mode: {self.last_result.get('mode')}")
            lines.append(f"  run_id: {self.last_result.get('run_id')}")
            lines.append(f"  base_dir: {self.last_result.get('base_dir')}")

        return "\n".join(lines)

    def _update_summary(self):
        state = self._collect_gui_state()

        summary = app.summarize_run(
            config=state,
            preset=self.preset_combo.currentText(),
        )

        self.run_summary.setPlainText(summary)

    def _build_current_request(self) -> dict[str, Any]:
        config_path = _optional_str(self.vars["config_path"].get())
        preset = _optional_str(self.vars["preset"].get())
        config_data = None if (config_path or preset) else self.loaded_config_data

        return {
            "config_path": config_path,
            "preset": preset,
            "config_data": config_data,
            "run_id": _optional_str(self.vars["run_id"].get()),
            "base_dir": _optional_str(self.vars["base_dir"].get()),
            "overrides": self._collect_overrides(),
            "ensemble_size": _optional_int(self.vars["ensemble_size"].get()),
            "ensemble_seed_start": int(
                self.vars["ensemble_seed_start"].get().strip() or "1000"
            ),
            "ensemble_mode": self.vars["ensemble_mode"].get().strip() or "chain",
        }

    def _materialize_current_form(self) -> dict[str, Any]:
        request = self._build_current_request()
        materialized, _notes = app.materialize_workflow_config(
            config_path=request["config_path"],
            preset=request["preset"],
            config_data=request["config_data"],
            overrides=request["overrides"],
        )
        return materialized

    def _run_preflight_only(self) -> None:
        try:
            report = app.preflight_validate_request(**self._build_current_request())
            text = app.format_preflight_report(report)
            self._set_diagnostics_text(text)
            self.status_var.set("Preflight complete")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Preflight failed:\n{exc}")

    def _compare_selected_run_to_current(self) -> None:
        run = self._get_selected_recent_run()
        if run is None:
            messagebox.showinfo("polymer-tool", "Select a recent run first.")
            return

        try:
            current_materialized = self._materialize_current_form()
            other = app.load_config_from_run_state(run["base_dir"])
            text = app.compare_materialized_configs(
                current_materialized,
                other,
                left_label="current form",
                right_label=f"run:{run['run_id']}",
            )
            self._set_diagnostics_text(text)
            self.status_var.set("Compared current form to selected run")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to compare selected run:\n{exc}")

    def _compare_selected_user_config_to_current(self) -> None:
        item = self._get_selected_user_config()
        if item is None:
            messagebox.showinfo("polymer-tool", "Select a saved config first.")
            return

        try:
            current_materialized = self._materialize_current_form()
            other = app.load_user_config_by_name(item["name"])
            text = app.compare_materialized_configs(
                current_materialized,
                other,
                left_label="current form",
                right_label=f"config:{item['name']}",
            )
            self._set_diagnostics_text(text)
            self.status_var.set("Compared current form to selected config")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to compare selected config:\n{exc}")

    def _update_command_preview(self):
        state = self._collect_gui_state()
        overrides = app.extract_overrides_from_gui_state(state)

        cmd = app.build_cli_command_preview(
            preset=self.preset_combo.currentText(),
            overrides=overrides,
        )

        self.command_preview.setPlainText(cmd)

    def _copy_command_preview(self) -> None:
        preview = self.command_text.get("1.0", "end").strip()
        self.root.clipboard_clear()
        self.root.clipboard_append(preview)
        self.status_var.set("Command preview copied")

    def _refresh_recent_runs(self) -> None:
        self.recent_runs = app.discover_recent_runs(limit=30)
        self.recent_listbox.delete(0, "end")

        for item in self.recent_runs:
            label = (
                f"{item['mtime_iso']} | {item['project_name']} | "
                f"{item['run_id']} | {item.get('last_status') or 'unknown'}"
            )
            self.recent_listbox.insert("end", label)

    def _on_recent_selection(self, _event=None) -> None:
        run = self._get_selected_recent_run()
        if run is not None:
            self.status_var.set(f"Selected run: {run['run_id']}")

    def _on_recent_double_click(self, _event=None) -> None:
        self._open_selected_run()

    def _open_selected_run(self) -> None:
        run = self._get_selected_recent_run()
        if run is None:
            if self.last_result and self.last_result.get("base_dir"):
                run_dir = self.last_result["base_dir"]
            else:
                messagebox.showinfo(
                    "polymer-tool",
                    "Select a recent run first.",
                )
                return
        else:
            run_dir = run["base_dir"]

        try:
            _open_path(run_dir)
            self.status_var.set(f"Opened: {run_dir}")
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Failed to open run directory:\n{exc}")

    def _start_run(self) -> None:
        if self.run_thread is not None and self.run_thread.is_alive():
            messagebox.showinfo("polymer-tool", "A run is already in progress.")
            return

        try:
            request = self._build_current_request()
        except Exception as exc:
            messagebox.showerror("polymer-tool", f"Invalid input:\n{exc}")
            return

        if (
            not request["preset"]
            and not request["config_path"]
            and request["config_data"] is None
        ):
            messagebox.showerror(
                "polymer-tool",
                "Select a preset, provide a config path, or load a recent run first.",
            )
            return

        report = app.preflight_validate_request(**request)
        self._set_diagnostics_text(app.format_preflight_report(report))
        if not report["ok"]:
            self.status_var.set("Preflight failed")
            messagebox.showerror(
                "polymer-tool",
                "Preflight failed. Review the diagnostics panel.",
            )
            return

        self.run_button.configure(state="disabled")
        self.status_var.set("Running...")
        self._append_output("Starting run...\n")

        self.run_thread = threading.Thread(
            target=self._run_request_worker,
            args=(request,),
            daemon=True,
        )
        self.run_thread.start()

    def _run_request_worker(self, request: dict[str, Any]) -> None:
        try:
            result = app.run_workflow_request(**request)
            message = app.format_run_result(result)
            self.result_queue.put(("success", json_safe_result(result, message)))
        except Exception:
            self.result_queue.put(("error", traceback.format_exc()))

    def _poll_result_queue(self) -> None:
        try:
            while True:
                status, message = self.result_queue.get_nowait()
                if status == "success":
                    payload = _parse_success_payload(message)
                    self.last_result = payload["result"]
                    self._append_output(payload["text"] + "\n\n")
                    self.status_var.set("Run completed")
                    self._refresh_recent_runs()
                    self._update_summary()
                else:
                    self._append_output("Run failed:\n" + message + "\n")
                    self.status_var.set("Run failed")
                    messagebox.showerror(
                        "polymer-tool",
                        "Run failed. See output pane for traceback.",
                    )
                self.run_button.configure(state="normal")
        except queue.Empty:
            pass
        finally:
            self.root.after(150, self._poll_result_queue)

    def _on_user_config_selection(self, _event=None) -> None:
        config = self._get_selected_user_config()
        if config is not None:
            self.status_var.set(f"Selected config: {config['name']}")

    def _on_user_config_double_click(self, _event=None) -> None:
        self._load_selected_user_config()

    def _clear_output(self) -> None:
        self.output_text.delete("1.0", "end")


def main() -> None:
    root = tk.Tk()
    PolymerToolGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()