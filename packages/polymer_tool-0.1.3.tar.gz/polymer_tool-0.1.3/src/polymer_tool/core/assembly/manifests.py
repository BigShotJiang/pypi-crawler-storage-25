from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def write_json(data: Dict[str, Any], path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(p)


def build_system_manifest(
    *,
    system_name: str,
    molecule_label: str,
    n_chains: int,
    chain_atom_count: int,
    total_atom_count: int,
    chain_formula: str | None,
    chain_formal_charge: int | None,
    charge_method_used: str | None,
    packed_pdb: str,
    parameterized_sdf: str,
    chain_json: str,
) -> dict:
    return {
        "system_name": system_name,
        "molecule_label": molecule_label,
        "n_chains": n_chains,
        "chain_atom_count": chain_atom_count,
        "total_atom_count": total_atom_count,
        "chain_formula": chain_formula,
        "chain_formal_charge": chain_formal_charge,
        "estimated_total_formal_charge": (
            None if chain_formal_charge is None else chain_formal_charge * n_chains
        ),
        "charge_method_used": charge_method_used,
        "source_files": {
            "chain_json": chain_json,
            "parameterized_sdf": parameterized_sdf,
            "packed_pdb": packed_pdb,
        },
    }


def build_components_manifest(
    *,
    molecule_label: str,
    n_chains: int,
    chain_atom_count: int,
    total_atom_count: int,
    parameterized_sdf: str,
    packed_pdb: str,
) -> dict:
    return {
        "components": [
            {
                "component_name": molecule_label,
                "component_type": "polymer_chain",
                "copies": n_chains,
                "atoms_per_copy": chain_atom_count,
                "total_atoms": total_atom_count,
                "structure_files": {
                    "parameterized_sdf": parameterized_sdf,
                    "packed_pdb": packed_pdb,
                },
            }
        ]
    }
