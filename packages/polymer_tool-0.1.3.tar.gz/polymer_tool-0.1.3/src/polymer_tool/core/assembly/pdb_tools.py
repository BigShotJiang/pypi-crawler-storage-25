from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List


@dataclass(frozen=True)
class PDBAtomRecord:
    record_name: str
    serial: int
    atom_name: str
    residue_name: str
    chain_id: str
    residue_seq: int
    x: float
    y: float
    z: float
    element: str


def _safe_int(text: str, default: int = 0) -> int:
    try:
        return int(text.strip())
    except ValueError:
        return default


def _safe_float(text: str, default: float = 0.0) -> float:
    try:
        return float(text.strip())
    except ValueError:
        return default


def read_pdb_atom_records(path: str | Path) -> List[PDBAtomRecord]:
    p = Path(path)
    records: List[PDBAtomRecord] = []

    with p.open("r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not (line.startswith("ATOM") or line.startswith("HETATM")):
                continue

            record_name = line[0:6].strip()
            serial = _safe_int(line[6:11], 0)
            atom_name = line[12:16].strip()
            residue_name = line[17:20].strip()
            chain_id = line[21:22].strip() or "?"
            residue_seq = _safe_int(line[22:26], 0)
            x = _safe_float(line[30:38], 0.0)
            y = _safe_float(line[38:46], 0.0)
            z = _safe_float(line[46:54], 0.0)
            element = line[76:78].strip() if len(line) >= 78 else ""

            records.append(
                PDBAtomRecord(
                    record_name=record_name,
                    serial=serial,
                    atom_name=atom_name,
                    residue_name=residue_name,
                    chain_id=chain_id,
                    residue_seq=residue_seq,
                    x=x,
                    y=y,
                    z=z,
                    element=element,
                )
            )

    return records


def write_pdb_atom_records(records: Iterable[PDBAtomRecord], path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    with p.open("w", encoding="utf-8") as fh:
        fh.write("HEADER\n")
        fh.write("TITLE     polymer_tool normalized packed structure\n")
        fh.write("REMARK   residue and chain identifiers normalized by polymer_tool\n")

        for rec in records:
            atom_name = rec.atom_name[:4]
            residue_name = rec.residue_name[:3]
            chain_id = (rec.chain_id or "A")[:1]
            element = (rec.element or "").strip()[:2]

            line = (
                f"{rec.record_name:<6}"
                f"{rec.serial:>5d} "
                f"{atom_name:<4}"
                f" "
                f"{residue_name:>3}"
                f" "
                f"{chain_id:1}"
                f"{rec.residue_seq:>4d}"
                f"    "
                f"{rec.x:>8.3f}"
                f"{rec.y:>8.3f}"
                f"{rec.z:>8.3f}"
                f"{1.00:>6.2f}"
                f"{0.00:>6.2f}"
                f"          "
                f"{element:>2}"
            )
            fh.write(line + "\n")

        fh.write("END\n")

    return str(p)


def compute_coordinate_bounds(records: Iterable[PDBAtomRecord]) -> dict:
    recs = list(records)
    if not recs:
        raise ValueError("No PDB atom records found for coordinate analysis.")

    xs = [r.x for r in recs]
    ys = [r.y for r in recs]
    zs = [r.z for r in recs]

    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    min_z, max_z = min(zs), max(zs)

    extent_x = max_x - min_x
    extent_y = max_y - min_y
    extent_z = max_z - min_z

    return {
        "min": {"x": min_x, "y": min_y, "z": min_z},
        "max": {"x": max_x, "y": max_y, "z": max_z},
        "extent": {"x": extent_x, "y": extent_y, "z": extent_z},
        "max_span": max(extent_x, extent_y, extent_z),
    }