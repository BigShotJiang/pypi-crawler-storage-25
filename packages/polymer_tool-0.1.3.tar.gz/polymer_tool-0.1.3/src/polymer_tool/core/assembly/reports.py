from __future__ import annotations

from typing import Any, Dict, List


def build_prep_report(
    *,
    n_chains: int,
    chain_atom_count: int,
    total_atom_count: int,
    coordinate_bounds: dict,
    packing_radius_angstrom: float | None,
    chain_formal_charge: int | None,
    charge_method_used: str | None,
) -> Dict[str, Any]:
    expected_total_atoms = n_chains * chain_atom_count
    atom_count_matches = total_atom_count == expected_total_atoms

    warnings: List[str] = []
    notes: List[str] = []

    if not atom_count_matches:
        warnings.append(
            "Packed system atom count does not match n_chains × chain_atom_count."
        )
    else:
        notes.append("Packed system atom count matches n_chains × chain_atom_count.")

    max_span = coordinate_bounds["max_span"]
    approx_diameter = max_span

    if packing_radius_angstrom is not None:
        target_diameter = 2.0 * packing_radius_angstrom
        notes.append(
            f"Packing target diameter was approximately {target_diameter:.3f} Å "
            f"based on the Packmol sphere radius."
        )

    return {
        "status": "success",
        "n_chains": n_chains,
        "chain_atom_count": chain_atom_count,
        "total_atom_count": total_atom_count,
        "expected_total_atoms": expected_total_atoms,
        "atom_count_matches_expectation": atom_count_matches,
        "coordinate_bounds": coordinate_bounds,
        "occupied_span_angstrom": approx_diameter,
        "packing_radius_angstrom": packing_radius_angstrom,
        "chain_formal_charge": chain_formal_charge,
        "estimated_total_formal_charge": (
            None if chain_formal_charge is None else chain_formal_charge * n_chains
        ),
        "charge_method_used": charge_method_used,
        "warnings": warnings,
        "notes": notes,
    }
