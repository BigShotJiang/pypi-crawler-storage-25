from __future__ import annotations

from typing import List

from polymer_tool.core.assembly.pdb_tools import PDBAtomRecord


def _chain_id_from_index(idx: int) -> str:
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return alphabet[(idx - 1) % len(alphabet)]


def rewrite_pdb_chain_and_residue(
    records: List[PDBAtomRecord],
    residue_name: str,
) -> List[PDBAtomRecord]:
    """
    Return a new list of records with:
      - unique chain IDs per packed copy
      - normalized residue name (3-char PDB-compatible)
      - residue sequence reset per copy
    """
    new_records: List[PDBAtomRecord] = []

    current_group = None
    chain_index = 0

    for rec in records:
        key = (rec.chain_id, rec.residue_seq, rec.residue_name)

        if key != current_group:
            chain_index += 1
            current_group = key

        new_records.append(
            PDBAtomRecord(
                record_name=rec.record_name,
                serial=rec.serial,
                atom_name=rec.atom_name,
                residue_name=residue_name[:3],
                chain_id=_chain_id_from_index(chain_index),
                residue_seq=1,
                x=rec.x,
                y=rec.y,
                z=rec.z,
                element=rec.element,
            )
        )

    return new_records