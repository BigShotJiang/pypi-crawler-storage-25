from __future__ import annotations

import random
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class SequencePlan:
    dp: int
    lactic_fraction: float
    n_lactic: int
    n_glycolic: int
    sequence_mode: str
    stereo_pattern: str
    random_seed: int | None
    residues: List[str]          # "L" or "G"
    lactic_stereo: List[str]     # "R" or "S" for lactic residues only


def _balanced_residue_sequence(n_lactic: int, n_glycolic: int) -> List[str]:
    total = n_lactic + n_glycolic
    if total == 0:
        return []

    seq: List[str] = []
    used_l = 0
    used_g = 0

    target_l_frac = n_lactic / total if total else 0.0
    target_g_frac = n_glycolic / total if total else 0.0

    for i in range(1, total + 1):
        can_l = used_l < n_lactic
        can_g = used_g < n_glycolic

        if can_l and not can_g:
            seq.append("L")
            used_l += 1
            continue
        if can_g and not can_l:
            seq.append("G")
            used_g += 1
            continue

        l_err = abs(((used_l + 1) / i) - target_l_frac)
        g_err = abs(((used_g + 1) / i) - target_g_frac)

        if l_err < g_err:
            seq.append("L")
            used_l += 1
        elif g_err < l_err:
            seq.append("G")
            used_g += 1
        else:
            rem_l = n_lactic - used_l
            rem_g = n_glycolic - used_g
            if rem_l >= rem_g:
                seq.append("L")
                used_l += 1
            else:
                seq.append("G")
                used_g += 1

    return seq


def _block_residue_sequence(n_lactic: int, n_glycolic: int) -> List[str]:
    return (["L"] * n_lactic) + (["G"] * n_glycolic)


def _random_seeded_residue_sequence(
    n_lactic: int,
    n_glycolic: int,
    random_seed: int | None,
) -> List[str]:
    seq = (["L"] * n_lactic) + (["G"] * n_glycolic)
    rng = random.Random(random_seed)
    rng.shuffle(seq)
    return seq


def _alt_rs_labels(n_lactic: int) -> List[str]:
    return ["R" if i % 2 == 0 else "S" for i in range(n_lactic)]


def _all_r_labels(n_lactic: int) -> List[str]:
    return ["R"] * n_lactic


def _all_s_labels(n_lactic: int) -> List[str]:
    return ["S"] * n_lactic


def _random_rs_seeded_labels(
    n_lactic: int,
    random_seed: int | None,
) -> List[str]:
    rng = random.Random(random_seed)
    return [rng.choice(["R", "S"]) for _ in range(n_lactic)]


def _build_lactic_stereo_labels(
    n_lactic: int,
    stereo_pattern: str,
    random_seed: int | None,
) -> List[str]:
    if stereo_pattern == "alt_RS":
        return _alt_rs_labels(n_lactic)
    if stereo_pattern == "all_R":
        return _all_r_labels(n_lactic)
    if stereo_pattern == "all_S":
        return _all_s_labels(n_lactic)
    if stereo_pattern == "random_RS_seeded":
        return _random_rs_seeded_labels(n_lactic, random_seed)

    raise ValueError(
        "Builder currently supports stereo_pattern in "
        "['alt_RS', 'all_R', 'all_S', 'random_RS_seeded'], "
        f"got {stereo_pattern!r}"
    )


def _validate_coupled_mode(
    sequence_mode: str,
    stereo_pattern: str,
    random_seed: int | None,
) -> None:
    if sequence_mode != "random_coupled":
        return

    if stereo_pattern != "random_RS_seeded":
        raise ValueError(
            "sequence_mode='random_coupled' currently requires "
            "stereo_pattern='random_RS_seeded'."
        )

    if random_seed is None:
        raise ValueError(
            "sequence_mode='random_coupled' requires a non-null random_seed."
        )


def build_sequence_plan(
    dp: int,
    lactic_fraction: float,
    stereo_pattern: str = "alt_RS",
    sequence_mode: str = "balanced",
    random_seed: int | None = None,
) -> SequencePlan:
    if dp <= 0:
        raise ValueError(f"dp must be > 0, got {dp}")
    if not (0.0 <= lactic_fraction <= 1.0):
        raise ValueError(f"lactic_fraction must be between 0 and 1, got {lactic_fraction}")

    _validate_coupled_mode(sequence_mode, stereo_pattern, random_seed)

    n_lactic = int(round(dp * lactic_fraction))
    n_lactic = max(0, min(dp, n_lactic))
    n_glycolic = dp - n_lactic

    if sequence_mode == "balanced":
        residues = _balanced_residue_sequence(n_lactic=n_lactic, n_glycolic=n_glycolic)
    elif sequence_mode == "block":
        residues = _block_residue_sequence(n_lactic=n_lactic, n_glycolic=n_glycolic)
    elif sequence_mode == "random_seeded":
        residues = _random_seeded_residue_sequence(
            n_lactic=n_lactic,
            n_glycolic=n_glycolic,
            random_seed=random_seed,
        )
    elif sequence_mode == "random_coupled":
        residues = _random_seeded_residue_sequence(
            n_lactic=n_lactic,
            n_glycolic=n_glycolic,
            random_seed=random_seed,
        )
    else:
        raise ValueError(
            "Builder currently supports sequence_mode in "
            "['balanced', 'block', 'random_seeded', 'random_coupled'], "
            f"got {sequence_mode!r}"
        )

    lactic_stereo = _build_lactic_stereo_labels(
        n_lactic=n_lactic,
        stereo_pattern=stereo_pattern,
        random_seed=random_seed,
    )

    return SequencePlan(
        dp=dp,
        lactic_fraction=lactic_fraction,
        n_lactic=n_lactic,
        n_glycolic=n_glycolic,
        sequence_mode=sequence_mode,
        stereo_pattern=stereo_pattern,
        random_seed=random_seed,
        residues=residues,
        lactic_stereo=lactic_stereo,
    )