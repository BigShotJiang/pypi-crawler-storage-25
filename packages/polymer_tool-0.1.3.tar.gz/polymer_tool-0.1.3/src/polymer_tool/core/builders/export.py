from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from rdkit import Chem
from rdkit.Chem import AllChem


def _try_embed(mol: Chem.Mol, random_seed: int, use_random_coords: bool) -> int:
    params = AllChem.ETKDGv3()
    params.randomSeed = random_seed
    params.useRandomCoords = use_random_coords
    params.enforceChirality = True
    return AllChem.EmbedMolecule(mol, params)


def mol_from_smiles_3d(smiles: str) -> Chem.Mol:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Failed to parse SMILES: {smiles}")

    Chem.SanitizeMol(mol)
    Chem.AssignStereochemistry(mol, force=True, cleanIt=True)
    mol = Chem.AddHs(mol)

    embed_ok = False

    for seed in (0xF00D, 0xBEEF, 0x1234, 0xCAFE):
        status = _try_embed(mol, random_seed=seed, use_random_coords=False)
        if status == 0:
            embed_ok = True
            break

    if not embed_ok:
        for seed in (0xF00D, 0xBEEF, 0x1234, 0xCAFE):
            status = _try_embed(mol, random_seed=seed, use_random_coords=True)
            if status == 0:
                embed_ok = True
                break

    if not embed_ok:
        raise RuntimeError(f"RDKit embedding failed for SMILES: {smiles}")

    try:
        if AllChem.MMFFHasAllMoleculeParams(mol):
            AllChem.MMFFOptimizeMolecule(mol, maxIters=2000)
        else:
            AllChem.UFFOptimizeMolecule(mol, maxIters=2000)
    except Exception:
        pass

    return mol


def write_sdf(mol: Chem.Mol, path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    writer = Chem.SDWriter(str(p))
    writer.write(mol)
    writer.close()
    return str(p)


def write_pdb(mol: Chem.Mol, path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    Chem.MolToPDBFile(mol, str(p))
    return str(p)


def write_json(data: Dict[str, Any], path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(p)