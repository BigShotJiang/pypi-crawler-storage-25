from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from .sequence import SequencePlan


@dataclass(frozen=True)
class PolymerBuildResult:
    smiles: str
    residue_records: List[Dict[str, str]]


def build_plga_dimethyl_ester_smiles(plan: SequencePlan, end_group: str = "ester") -> PolymerBuildResult:
    """
    Builder v1 creates a linear dimethyl-capped PLGA chain.

    Representation:
      MeO-C(=O)-[residues]-OMe

    Residue encoding:
      Lactic residue:
        R -> [C@H](C)O
        S -> [C@@H](C)O
      Glycolic residue:
        CO

    The chain is assembled as:
      COC(=O) + residue_i + C(=O) + residue_{i+1} + ... + OC

    For one lactic residue:
      COC(=O)[C@H](C)OC

    For one glycolic residue:
      COC(=O)COC
    """
    if end_group != "ester":
        raise ValueError(f"Builder v1 supports only end_group='ester', got {end_group!r}")

    parts: List[str] = ["COC(=O)"]
    residue_records: List[Dict[str, str]] = []
    lactic_index = 0

    for idx, residue in enumerate(plan.residues):
        is_last = idx == (len(plan.residues) - 1)

        if residue == "L":
            stereo = plan.lactic_stereo[lactic_index]
            lactic_index += 1
            token = "[C@H](C)O" if stereo == "R" else "[C@@H](C)O"
            residue_records.append(
                {
                    "index": str(idx + 1),
                    "type": "LA",
                    "stereo": stereo,
                }
            )
        elif residue == "G":
            token = "CO"
            residue_records.append(
                {
                    "index": str(idx + 1),
                    "type": "GA",
                    "stereo": "achiral",
                }
            )
        else:
            raise ValueError(f"Unknown residue code: {residue!r}")

        parts.append(token)

        if is_last:
            parts.append("C")
        else:
            parts.append("C(=O)")

    smiles = "".join(parts)

    return PolymerBuildResult(
        smiles=smiles,
        residue_records=residue_records,
    )
