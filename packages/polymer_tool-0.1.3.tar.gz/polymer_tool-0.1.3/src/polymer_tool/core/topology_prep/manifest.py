from __future__ import annotations

from typing import Dict


def build_topology_prep_manifest(
    *,
    system_name: str,
    molecule_label: str,
    residue_name: str,
    packed_pdb: str,
    chain_parameterized_sdf: str,
    n_detected_copies: int,
    atoms_per_copy: int,
    total_atoms: int,
) -> Dict:
    return {
        "prep_type": "topology_prep_v1",
        "system_name": system_name,
        "molecule_label": molecule_label,
        "normalized_residue_name": residue_name,
        "packed_pdb": packed_pdb,
        "chain_parameterized_sdf": chain_parameterized_sdf,
        "n_detected_copies": n_detected_copies,
        "atoms_per_copy": atoms_per_copy,
        "total_atoms": total_atoms,
        "identity_normalization": {
            "packed_pdb_identifiers_normalized": True,
            "residue_name": residue_name,
            "chain_ids_assigned_per_copy": True,
        },
        "notes": [
            "This manifest is intended to support external topology generation.",
            "Packed copy grouping is derived from normalized packed PDB identifiers.",
            "Validate molecule naming and atom typing in the downstream force-field workflow.",
        ],
    }