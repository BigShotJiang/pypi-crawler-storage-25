from __future__ import annotations


def build_external_ff_notes(
    *,
    system_name: str,
    molecule_label: str,
    residue_name: str,
    n_detected_copies: int,
    atoms_per_copy: int,
    total_atoms: int,
) -> str:
    return f"""External force-field / topology preparation notes
================================================

System name: {system_name}
Molecule label: {molecule_label}
Normalized residue name: {residue_name}
Detected packed copies: {n_detected_copies}
Atoms per copy: {atoms_per_copy}
Total packed atoms: {total_atoms}

Purpose
-------
These files are intended to support external topology generation workflows.
They do not constitute a finished simulation topology.

Identity normalization
----------------------
The packed PDB has already been normalized to use:
- residue name: {residue_name}
- one assigned chain ID per packed copy

Suggested downstream tasks
--------------------------
1. Validate the single-chain chemistry from chain_parameterized.sdf.
2. Generate or assign a production-quality force-field/topology externally.
3. Preserve the copy count, chain IDs, and atom-count bookkeeping from:
   - packed_chain_map.json
   - component_index_map.json
4. Confirm that the generated topology reproduces:
   - {n_detected_copies} polymer copies
   - {atoms_per_copy} atoms per copy
   - {total_atoms} total packed atoms

Recommended checks
------------------
- Residue and molecule naming consistency
- Formal charge consistency
- Per-copy atom count consistency
- Coordinate ordering compatibility with the chosen topology workflow
- Consistency between topology molecule definitions and assigned packed chain IDs

Current limitation
------------------
The current tool records first-pass preparation metadata and indexing, but final
production topology generation must still be completed externally.
"""