from __future__ import annotations

from collections import defaultdict
from typing import Dict, List

from polymer_tool.core.assembly.pdb_tools import PDBAtomRecord


def build_chain_groups(
    records: List[PDBAtomRecord],
    *,
    molecule_label: str,
) -> List[dict]:
    """
    Group packed PDB atom records into per-copy groups.

    Grouping heuristic:
      - chain_id
      - residue_seq
      - residue_name
    """
    grouped: Dict[tuple, List[PDBAtomRecord]] = defaultdict(list)

    for rec in records:
        key = (rec.chain_id, rec.residue_seq, rec.residue_name)
        grouped[key].append(rec)

    groups: List[dict] = []
    for idx, key in enumerate(sorted(grouped.keys()), start=1):
        chain_id, residue_seq, residue_name = key
        atoms = sorted(grouped[key], key=lambda r: r.serial)

        serials = [a.serial for a in atoms]
        xs = [a.x for a in atoms]
        ys = [a.y for a in atoms]
        zs = [a.z for a in atoms]

        groups.append(
            {
                "copy_index": idx,
                "copy_label": f"{molecule_label}_{idx:03d}",
                "assigned_chain_id": chain_id,
                "assigned_residue_name": residue_name,
                "residue_seq": residue_seq,
                "atom_count": len(atoms),
                "atom_serial_range": {
                    "start": min(serials),
                    "end": max(serials),
                },
                "centroid": {
                    "x": sum(xs) / len(xs),
                    "y": sum(ys) / len(ys),
                    "z": sum(zs) / len(zs),
                },
            }
        )

    return groups


def build_component_index_map(
    *,
    molecule_label: str,
    residue_name: str,
    chain_groups: List[dict],
) -> dict:
    return {
        "components": [
            {
                "component_name": molecule_label,
                "component_type": "polymer_chain",
                "normalized_residue_name": residue_name,
                "copy_count": len(chain_groups),
                "copies": chain_groups,
            }
        ]
    }