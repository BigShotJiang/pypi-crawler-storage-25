# Topology-preparation helpers for downstream workflows.
from .bridge import prepare_topology_bridge