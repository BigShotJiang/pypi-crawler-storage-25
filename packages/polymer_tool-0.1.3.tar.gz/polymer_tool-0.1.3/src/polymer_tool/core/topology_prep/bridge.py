from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

from polymer_tool.core.assembly.manifests import write_json
from polymer_tool.core.assembly.pdb_tools import read_pdb_atom_records
from polymer_tool.core.exporters.handoff import write_text
from polymer_tool.core.topology_prep.index_maps import (
    build_chain_groups,
    build_component_index_map,
)
from polymer_tool.core.topology_prep.manifest import build_topology_prep_manifest
from polymer_tool.core.topology_prep.notes import build_external_ff_notes
from polymer_tool.core.validators import require_nonempty_file


def _read_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def prepare_topology_bridge(
    *,
    system_manifest_json: str,
    components_json: str,
    prep_report_json: str,
    packed_pdb: str,
    chain_parameterized_sdf: str,
    out_dir: str,
) -> Dict[str, str]:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    system_manifest_path = require_nonempty_file(system_manifest_json, "system manifest JSON")
    components_path = require_nonempty_file(components_json, "components JSON")
    prep_report_path = require_nonempty_file(prep_report_json, "prep report JSON")
    packed_pdb_path = require_nonempty_file(packed_pdb, "packed nanoparticle PDB")
    chain_sdf_path = require_nonempty_file(chain_parameterized_sdf, "parameterized chain SDF")

    system_manifest = _read_json(system_manifest_path)
    _ = _read_json(components_path)
    _ = _read_json(prep_report_path)

    molecule_label = str(system_manifest.get("molecule_label", "POLYMER"))
    system_name = str(system_manifest.get("system_name", "system"))
    residue_name = "PLG"

    records = read_pdb_atom_records(packed_pdb_path)
    chain_groups = build_chain_groups(
        records,
        molecule_label=molecule_label,
    )

    n_detected_copies = len(chain_groups)
    atoms_per_copy = chain_groups[0]["atom_count"] if chain_groups else 0
    total_atoms = len(records)

    packed_chain_map = {
        "system_name": system_name,
        "molecule_label": molecule_label,
        "normalized_residue_name": residue_name,
        "packed_pdb": str(packed_pdb_path),
        "n_detected_copies": n_detected_copies,
        "copies": chain_groups,
    }

    component_index_map = build_component_index_map(
        molecule_label=molecule_label,
        residue_name=residue_name,
        chain_groups=chain_groups,
    )

    topology_prep_manifest = build_topology_prep_manifest(
        system_name=system_name,
        molecule_label=molecule_label,
        residue_name=residue_name,
        packed_pdb=str(packed_pdb_path),
        chain_parameterized_sdf=str(chain_sdf_path),
        n_detected_copies=n_detected_copies,
        atoms_per_copy=atoms_per_copy,
        total_atoms=total_atoms,
    )

    external_ff_notes = build_external_ff_notes(
        system_name=system_name,
        molecule_label=molecule_label,
        residue_name=residue_name,
        n_detected_copies=n_detected_copies,
        atoms_per_copy=atoms_per_copy,
        total_atoms=total_atoms,
    )

    packed_chain_map_json = out_path / "packed_chain_map.json"
    component_index_map_json = out_path / "component_index_map.json"
    topology_prep_manifest_json = out_path / "topology_prep_manifest.json"
    external_ff_notes_txt = out_path / "external_ff_notes.txt"

    write_json(packed_chain_map, packed_chain_map_json)
    write_json(component_index_map, component_index_map_json)
    write_json(topology_prep_manifest, topology_prep_manifest_json)
    write_text(external_ff_notes, external_ff_notes_txt)

    require_nonempty_file(packed_chain_map_json, "packed chain map JSON")
    require_nonempty_file(component_index_map_json, "component index map JSON")
    require_nonempty_file(topology_prep_manifest_json, "topology prep manifest JSON")
    require_nonempty_file(external_ff_notes_txt, "external FF notes text")

    return {
        "packed_chain_map_json": str(packed_chain_map_json),
        "component_index_map_json": str(component_index_map_json),
        "topology_prep_manifest_json": str(topology_prep_manifest_json),
        "external_ff_notes_txt": str(external_ff_notes_txt),
    }