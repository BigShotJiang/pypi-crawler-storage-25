from __future__ import annotations

from pathlib import Path
import json
import numpy as np

from openmm.app import PDBFile, Simulation, NoCutoff
from openmm import LangevinIntegrator, Platform, unit
from openmm.app import Topology
from openmm import System, VerletIntegrator


def _compute_rg(positions):
    coords = np.array([[p.x, p.y, p.z] for p in positions])
    center = coords.mean(axis=0)
    rg = np.sqrt(((coords - center) ** 2).sum(axis=1).mean())
    return float(rg)


def _max_radius(positions):
    coords = np.array([[p.x, p.y, p.z] for p in positions])
    center = coords.mean(axis=0)
    r = np.sqrt(((coords - center) ** 2).sum(axis=1))
    return float(r.max())


def run_vacuum_relaxation(
    pdb_path: str,
    output_dir: str,
    n_steps: int = 5000,
    temperature_kelvin: float = 300.0,
):
    pdb = PDBFile(pdb_path)

    system = System()
    for atom in pdb.topology.atoms():
        system.addParticle(12.0)  # placeholder mass

    integrator = LangevinIntegrator(
        temperature_kelvin * unit.kelvin,
        1.0 / unit.picosecond,
        0.002 * unit.picoseconds,
    )

    simulation = Simulation(pdb.topology, system, integrator)

    simulation.context.setPositions(pdb.positions)

    # Initial metrics
    state = simulation.context.getState(getPositions=True)
    pos0 = state.getPositions()
    rg0 = _compute_rg(pos0)
    rmax0 = _max_radius(pos0)

    # Minimize
    simulation.minimizeEnergy()

    # Short MD
    simulation.step(n_steps)

    state = simulation.context.getState(getPositions=True)
    pos1 = state.getPositions()
    rg1 = _compute_rg(pos1)
    rmax1 = _max_radius(pos1)

    collapse = (rg0 - rg1) / rg0 if rg0 > 0 else 0.0

    if collapse > 0.3:
        label = "strong_collapse"
    elif collapse > 0.1:
        label = "moderate_collapse"
    else:
        label = "weak_collapse"

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    final_pdb = out_dir / "relaxed.pdb"
    with final_pdb.open("w") as f:
        PDBFile.writeFile(pdb.topology, pos1, f)

    report = {
        "rg_initial_angstrom": rg0,
        "rg_final_angstrom": rg1,
        "max_radius_initial_angstrom": rmax0,
        "max_radius_final_angstrom": rmax1,
        "collapse_fraction": collapse,
        "n_steps": n_steps,
        "temperature_kelvin": temperature_kelvin,
        "assessment_label": label,
        "relaxed_pdb": str(final_pdb),
    }

    report_path = out_dir / "vacuum_assessment.json"
    report_path.write_text(json.dumps(report, indent=2))

    return report
