from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import json

import numpy as np

try:
    from openff.interchange import Interchange
    from openff.toolkit import ForceField, Molecule, Topology
    from openff.units import unit as offunit
    HAS_OPENFF = True
except ImportError:
    HAS_OPENFF = False
    Interchange = None
    ForceField = None
    Molecule = None
    Topology = None
    offunit = None

try:
    from openmm import LangevinIntegrator, unit
    from openmm.app import PDBFile, Simulation
    HAS_OPENMM = True
except ImportError:
    HAS_OPENMM = False
    LangevinIntegrator = None
    unit = None
    PDBFile = None
    Simulation = None

from rdkit import Chem


def _compute_rg(positions) -> float:
    coords_nm = np.array([[p.x, p.y, p.z] for p in positions], dtype=float)
    center_nm = coords_nm.mean(axis=0)
    rg_nm = np.sqrt(((coords_nm - center_nm) ** 2).sum(axis=1).mean())
    return float(rg_nm * 10.0)  # nm -> Å

def _read_chain_coords_from_pdb(packed_pdb: str) -> dict[str, np.ndarray]:
    chains: dict[str, list[list[float]]] = {}

    with open(packed_pdb, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue

            chain_id = line[21].strip() or "?"
            x = float(line[30:38].strip())
            y = float(line[38:46].strip())
            z = float(line[46:54].strip())
            chains.setdefault(chain_id, []).append([x, y, z])

    return {cid: np.asarray(coords, dtype=float) for cid, coords in chains.items()}


def _load_openff_template_with_charges(chain_sdf: str) -> Molecule:
    if not HAS_OPENFF or not HAS_OPENMM:
        raise ImportError(
            "OpenFF toolkit and OpenMM are required for relaxation. "
            "Install 'openff-toolkit', 'openff-forcefields', and 'openmm' to use this feature."
        )
    template = Molecule.from_file(chain_sdf)

    if template.partial_charges is None:
        rdmol = Chem.SDMolSupplier(chain_sdf, removeHs=False)[0]
        if rdmol is None:
            raise ValueError(f"Failed to read RDKit molecule from {chain_sdf}")

        charges = []
        for atom in rdmol.GetAtoms():
            if atom.HasProp("polymer_tool_partial_charge"):
                charges.append(float(atom.GetProp("polymer_tool_partial_charge")))
            elif atom.HasProp("_GasteigerCharge"):
                charges.append(float(atom.GetProp("_GasteigerCharge")))
            else:
                charges.append(0.0)

        template.partial_charges = np.asarray(charges, dtype=float) * offunit.elementary_charge

    if template.partial_charges is None:
        raise ValueError(
            f"Template molecule from {chain_sdf} still has no partial charges after fallback loading."
        )

    return template


def run_openff_relaxation(
    packed_pdb: str,
    chain_sdf: str,
    output_dir: str,
    n_steps: int = 10000,
    temperature_kelvin: float = 300.0,
) -> dict:
    if not HAS_OPENFF or not HAS_OPENMM:
        raise ImportError(
            "OpenFF toolkit and OpenMM are required for relaxation. "
            "Install 'openff-toolkit', 'openff-forcefields', and 'openmm' to use this feature."
        )
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    pdb = PDBFile(packed_pdb)
    chain_coords = _read_chain_coords_from_pdb(packed_pdb)
    chain_ids = sorted(chain_coords.keys())

    if not chain_ids:
        raise ValueError(f"No chains detected in packed PDB: {packed_pdb}")

    template = _load_openff_template_with_charges(chain_sdf)

    molecules: list[Molecule] = []
    for chain_id in chain_ids:
        coords = chain_coords[chain_id]
        if coords.shape[0] != template.n_atoms:
            raise ValueError(
                f"Atom-count mismatch for chain {chain_id!r}: "
                f"PDB has {coords.shape[0]} atoms but template has {template.n_atoms}"
            )

        mol = deepcopy(template)
        mol._conformers = []
        mol.add_conformer(coords * offunit.angstrom)
        molecules.append(mol)

    topology = Topology.from_molecules([molecules[0]])
    for mol in molecules[1:]:
        topology.add_molecule(mol)

    force_field = ForceField("openff-2.3.0.offxml")

    interchange = Interchange.from_smirnoff(
        force_field=force_field,
        topology=topology,
        charge_from_molecules=[template],
        allow_nonintegral_charges=True,
    )

    system = interchange.to_openmm()
    omm_topology = topology.to_openmm()

    integrator = LangevinIntegrator(
        temperature_kelvin * unit.kelvin,
        1.0 / unit.picosecond,
        0.002 * unit.picoseconds,
    )

    simulation = Simulation(omm_topology, system, integrator)
    simulation.context.setPositions(pdb.positions)

    state0 = simulation.context.getState(getPositions=True)
    pos0 = state0.getPositions()
    rg0 = _compute_rg(pos0)

    simulation.minimizeEnergy()
    simulation.step(n_steps)

    state1 = simulation.context.getState(getPositions=True)
    pos1 = state1.getPositions()
    rg1 = _compute_rg(pos1)

    collapse_fraction = (rg0 - rg1) / rg0 if rg0 > 0 else 0.0

    relaxed_pdb = out_dir / "relaxed_openff.pdb"
    with relaxed_pdb.open("w", encoding="utf-8") as fh:
        PDBFile.writeFile(omm_topology, pos1, fh)

    report = {
        "rg_initial_angstrom": rg0,
        "rg_final_angstrom": rg1,
        "collapse_fraction": collapse_fraction,
        "n_steps": int(n_steps),
        "temperature_kelvin": float(temperature_kelvin),
        "n_chains": len(chain_ids),
        "chain_ids": chain_ids,
        "charge_source": "polymer_tool_partial_charge_or__GasteigerCharge",
        "relaxed_pdb": str(relaxed_pdb),
    }

    report_path = out_dir / "openff_relaxation.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    return report