from __future__ import annotations

from pathlib import Path
from typing import Dict

from polymer_tool.core.parameterization.openff_backend import parameterize_with_rdkit
from polymer_tool.core.parameterization.report import (
    write_parameterization_report,
    write_parameterized_sdf,
)
from polymer_tool.core.validators import require_nonempty_file


def parameterize_chain(
    input_sdf: str,
    charge_method: str,
    forcefield: str,
    out_dir: str,
) -> Dict[str, str]:
    """
    Parameterization v1.

    Current behavior:
      - loads the chain from SDF
      - computes molecule metadata
      - assigns RDKit Gasteiger partial charges when requested or as fallback
      - writes a parameterized SDF and a detailed report JSON

    This keeps the step scientifically real while leaving a clean path for
    later OpenFF/AM1-BCC integration.
    """
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    output_sdf = out_path / "chain_parameterized.sdf"
    output_json = out_path / "chain_parameterization.json"

    result = parameterize_with_rdkit(
        input_sdf=input_sdf,
        charge_method=charge_method,
        forcefield=forcefield,
    )

    write_parameterized_sdf(result.mol, output_sdf)
    write_parameterization_report(
        result=result,
        input_sdf=input_sdf,
        output_sdf=str(output_sdf),
        path=output_json,
    )

    require_nonempty_file(output_sdf, "parameterized chain SDF")
    require_nonempty_file(output_json, "parameterization report JSON")

    return {
        "parameterized_sdf": str(output_sdf),
        "metadata_json": str(output_json),
    }
