from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

from polymer_tool.core.assembly.manifests import write_json
from polymer_tool.core.exportmeta.descriptor import build_export_descriptor
from polymer_tool.core.exportmeta.inventory import build_file_inventory
from polymer_tool.core.exportmeta.readiness import build_readiness_report
from polymer_tool.core.validators import require_nonempty_file


def _read_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def generate_export_descriptor(
    *,
    system_manifest_json: str,
    chain_json: str,
    chain_parameterized_sdf: str,
    packed_pdb: str,
    components_json: str,
    prep_report_json: str,
    packed_chain_map_json: str,
    component_index_map_json: str,
    topology_prep_manifest_json: str,
    external_ff_notes_txt: str,
    export_manifest_json: str,
    handoff_notes_txt: str,
    workflow_summary_json: str,
    bundle_checksums_json: str,
    export_archive_targz: str,
    export_bundle_dir: str,
    out_dir: str,
) -> Dict[str, str]:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    system_manifest_path = require_nonempty_file(system_manifest_json, "system manifest JSON")
    chain_json_path = require_nonempty_file(chain_json, "chain metadata JSON")
    chain_param_sdf_path = require_nonempty_file(chain_parameterized_sdf, "chain parameterized SDF")
    packed_pdb_path = require_nonempty_file(packed_pdb, "packed PDB")
    components_path = require_nonempty_file(components_json, "components JSON")
    prep_report_path = require_nonempty_file(prep_report_json, "prep report JSON")
    packed_chain_map_path = require_nonempty_file(packed_chain_map_json, "packed chain map JSON")
    component_index_map_path = require_nonempty_file(component_index_map_json, "component index map JSON")
    topology_prep_manifest_path = require_nonempty_file(topology_prep_manifest_json, "topology prep manifest JSON")
    external_ff_notes_path = require_nonempty_file(external_ff_notes_txt, "external FF notes text")
    export_manifest_path = require_nonempty_file(export_manifest_json, "export manifest JSON")
    handoff_notes_path = require_nonempty_file(handoff_notes_txt, "handoff notes text")
    workflow_summary_path = require_nonempty_file(workflow_summary_json, "workflow summary JSON")
    checksums_path = require_nonempty_file(bundle_checksums_json, "bundle checksums JSON")
    archive_path = require_nonempty_file(export_archive_targz, "export archive")

    system_manifest = _read_json(system_manifest_path)

    descriptor = build_export_descriptor(
        system_name=str(system_manifest.get("system_name")),
        molecule_label=str(system_manifest.get("molecule_label")),
        normalized_residue_name=str(system_manifest.get("normalized_residue_name", "PLG")),
        n_chains=int(system_manifest.get("n_chains")),
        chain_atom_count=int(system_manifest.get("chain_atom_count")),
        total_atom_count=int(system_manifest.get("total_atom_count")),
        charge_method_used=system_manifest.get("charge_method_used"),
    )

    inventory = build_file_inventory(
        chain_json=str(chain_json_path),
        chain_parameterized_sdf=str(chain_param_sdf_path),
        packed_pdb=str(packed_pdb_path),
        system_manifest_json=str(system_manifest_path),
        components_json=str(components_path),
        prep_report_json=str(prep_report_path),
        packed_chain_map_json=str(packed_chain_map_path),
        component_index_map_json=str(component_index_map_path),
        topology_prep_manifest_json=str(topology_prep_manifest_path),
        external_ff_notes_txt=str(external_ff_notes_path),
        export_manifest_json=str(export_manifest_path),
        handoff_notes_txt=str(handoff_notes_path),
        workflow_summary_json=str(workflow_summary_path),
        bundle_checksums_json=str(checksums_path),
        export_archive_targz=str(archive_path),
        export_bundle_dir=str(export_bundle_dir),
    )

    readiness = build_readiness_report(
        n_chains=int(system_manifest.get("n_chains")),
        chain_atom_count=int(system_manifest.get("chain_atom_count")),
        total_atom_count=int(system_manifest.get("total_atom_count")),
        charge_method_used=system_manifest.get("charge_method_used"),
        topology_bridge_ready=True,
        gromacs_handoff_ready=True,
    )

    export_descriptor_json = out_path / "export_descriptor.json"
    file_inventory_json = out_path / "file_inventory.json"
    readiness_report_json = out_path / "readiness_report.json"

    write_json(descriptor, export_descriptor_json)
    write_json(inventory, file_inventory_json)
    write_json(readiness, readiness_report_json)

    require_nonempty_file(export_descriptor_json, "export descriptor JSON")
    require_nonempty_file(file_inventory_json, "file inventory JSON")
    require_nonempty_file(readiness_report_json, "readiness report JSON")

    return {
        "export_descriptor_json": str(export_descriptor_json),
        "file_inventory_json": str(file_inventory_json),
        "readiness_report_json": str(readiness_report_json),
    }