from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

from polymer_tool.core.assembly.manifests import (
    build_components_manifest,
    build_system_manifest,
    write_json,
)
from polymer_tool.core.assembly.pdb_tools import (
    compute_coordinate_bounds,
    read_pdb_atom_records,
)
from polymer_tool.core.assembly.reports import build_prep_report
from polymer_tool.core.validators import require_nonempty_file


def _read_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def assemble_system(
    *,
    chain_json: str,
    parameterized_sdf: str,
    parameterization_json: str,
    packed_pdb: str,
    packing_report_json: str,
    out_dir: str,
    system_name: str = "plga_nanoparticle_system",
    molecule_label: str = "PLGA_CHAIN",
) -> Dict[str, str]:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    chain_json_path = require_nonempty_file(chain_json, "chain metadata JSON")
    parameterized_sdf_path = require_nonempty_file(parameterized_sdf, "parameterized chain SDF")
    parameterization_json_path = require_nonempty_file(parameterization_json, "parameterization JSON")
    packed_pdb_path = require_nonempty_file(packed_pdb, "packed nanoparticle PDB")
    packing_report_path = require_nonempty_file(packing_report_json, "packing report JSON")

    chain_meta = _read_json(chain_json_path)
    param_meta = _read_json(parameterization_json_path)
    packing_meta = _read_json(packing_report_path)

    pdb_records = read_pdb_atom_records(packed_pdb_path)
    total_atom_count = len(pdb_records)
    coordinate_bounds = compute_coordinate_bounds(pdb_records)

    chain_atom_count = int(param_meta["n_atoms"])
    n_chains = int(packing_meta["n_chains"])

    system_manifest = build_system_manifest(
        system_name=system_name,
        molecule_label=molecule_label,
        n_chains=n_chains,
        chain_atom_count=chain_atom_count,
        total_atom_count=total_atom_count,
        chain_formula=param_meta.get("formula"),
        chain_formal_charge=param_meta.get("formal_charge"),
        charge_method_used=param_meta.get("charge_method_used"),
        packed_pdb=str(packed_pdb_path),
        parameterized_sdf=str(parameterized_sdf_path),
        chain_json=str(chain_json_path),
    )

    components_manifest = build_components_manifest(
        molecule_label=molecule_label,
        n_chains=n_chains,
        chain_atom_count=chain_atom_count,
        total_atom_count=total_atom_count,
        parameterized_sdf=str(parameterized_sdf_path),
        packed_pdb=str(packed_pdb_path),
    )

    prep_report = build_prep_report(
        n_chains=n_chains,
        chain_atom_count=chain_atom_count,
        total_atom_count=total_atom_count,
        coordinate_bounds=coordinate_bounds,
        packing_radius_angstrom=packing_meta.get("radius_angstrom"),
        chain_formal_charge=param_meta.get("formal_charge"),
        charge_method_used=param_meta.get("charge_method_used"),
    )

    system_manifest_json = out_path / "system_manifest.json"
    components_json = out_path / "components.json"
    prep_report_json = out_path / "prep_report.json"

    write_json(system_manifest, system_manifest_json)
    write_json(components_manifest, components_json)
    write_json(prep_report, prep_report_json)

    require_nonempty_file(system_manifest_json, "system manifest JSON")
    require_nonempty_file(components_json, "components JSON")
    require_nonempty_file(prep_report_json, "prep report JSON")

    return {
        "system_manifest_json": str(system_manifest_json),
        "components_json": str(components_json),
        "prep_report_json": str(prep_report_json),
    }
