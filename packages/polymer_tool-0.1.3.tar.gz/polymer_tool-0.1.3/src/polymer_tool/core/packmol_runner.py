from __future__ import annotations

import json
import math
import random
import shutil
import subprocess
from pathlib import Path
from typing import Dict, Iterable

from polymer_tool.core.assembly.pdb_edit import rewrite_pdb_chain_and_residue
from polymer_tool.core.assembly.pdb_tools import (
    read_pdb_atom_records,
    write_pdb_atom_records,
)
from polymer_tool.core.validators import require_nonempty_file


AVOGADRO = 6.02214076e23
CM3_TO_ANGSTROM3 = 1.0e24


def _find_packmol_executable() -> str:
    exe = shutil.which("packmol")
    if exe is None:
        raise FileNotFoundError(
            "Packmol executable not found on PATH. Install packmol and ensure "
            "the 'packmol' command is available in this environment."
        )
    return exe


def _load_chain_metadata(chain_json: str | Path) -> dict:
    p = require_nonempty_file(chain_json, "chain metadata JSON")
    return json.loads(Path(p).read_text(encoding="utf-8"))


def _parse_pdb_xyz(pdb_path: str | Path) -> list[tuple[float, float, float]]:
    coords: list[tuple[float, float, float]] = []
    p = require_nonempty_file(pdb_path, "input chain PDB")
    with Path(p).open("r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("ATOM") or line.startswith("HETATM"):
                try:
                    x = float(line[30:38].strip())
                    y = float(line[38:46].strip())
                    z = float(line[46:54].strip())
                except ValueError:
                    continue
                coords.append((x, y, z))
    if not coords:
        raise ValueError(f"No coordinates found in PDB file: {p}")
    return coords


def _compute_chain_geometry_report(chain_pdb: str | Path) -> dict:
    coords = _parse_pdb_xyz(chain_pdb)

    n = len(coords)
    cx = sum(x for x, _, _ in coords) / n
    cy = sum(y for _, y, _ in coords) / n
    cz = sum(z for _, _, z in coords) / n

    radial_distances = []
    xs, ys, zs = [], [], []
    for x, y, z in coords:
        dx = x - cx
        dy = y - cy
        dz = z - cz
        radial_distances.append(math.sqrt(dx * dx + dy * dy + dz * dz))
        xs.append(x)
        ys.append(y)
        zs.append(z)

    max_radial_distance = max(radial_distances)
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    min_z, max_z = min(zs), max(zs)

    span_x = max_x - min_x
    span_y = max_y - min_y
    span_z = max_z - min_z
    max_span = max(span_x, span_y, span_z)

    rg2 = sum(
        (x - cx) ** 2 + (y - cy) ** 2 + (z - cz) ** 2 for x, y, z in coords
    ) / n
    rg = math.sqrt(rg2)

    return {
        "n_atoms": n,
        "centroid": {"x": cx, "y": cy, "z": cz},
        "max_radial_distance_angstrom": max_radial_distance,
        "bounding_box": {
            "min": {"x": min_x, "y": min_y, "z": min_z},
            "max": {"x": max_x, "y": max_y, "z": max_z},
            "span": {"x": span_x, "y": span_y, "z": span_z},
            "max_span_angstrom": max_span,
        },
        "radius_of_gyration_angstrom": rg,
    }


def _compute_density_based_radius_angstrom(
    *,
    exact_mw_g_mol: float,
    n_chains: int,
    target_density_g_cm3: float,
    packing_slack_factor: float,
) -> dict:
    if exact_mw_g_mol <= 0:
        raise ValueError(f"exact_mw_g_mol must be > 0, got {exact_mw_g_mol}")
    if n_chains <= 0:
        raise ValueError(f"n_chains must be > 0, got {n_chains}")
    if target_density_g_cm3 <= 0:
        raise ValueError(
            f"target_density_g_cm3 must be > 0, got {target_density_g_cm3}"
        )
    if packing_slack_factor <= 0:
        raise ValueError(
            f"packing_slack_factor must be > 0, got {packing_slack_factor}"
        )

    total_mass_g = (exact_mw_g_mol * n_chains) / AVOGADRO
    polymer_volume_cm3 = total_mass_g / target_density_g_cm3
    target_volume_cm3 = polymer_volume_cm3 * packing_slack_factor
    target_volume_ang3 = target_volume_cm3 * CM3_TO_ANGSTROM3
    radius_angstrom = ((3.0 * target_volume_ang3) / (4.0 * math.pi)) ** (1.0 / 3.0)

    return {
        "exact_mw_g_mol": exact_mw_g_mol,
        "n_chains": n_chains,
        "target_density_g_cm3": target_density_g_cm3,
        "packing_slack_factor": packing_slack_factor,
        "total_mass_g": total_mass_g,
        "polymer_volume_cm3": polymer_volume_cm3,
        "target_volume_cm3": target_volume_cm3,
        "target_volume_angstrom3": target_volume_ang3,
        "radius_angstrom": radius_angstrom,
    }


def _compute_chain_floor_radius_angstrom(
    *,
    chain_geometry_report: dict,
    n_chains: int,
    chain_size_factor: float,
) -> dict:
    if n_chains <= 0:
        raise ValueError(f"n_chains must be > 0, got {n_chains}")
    if chain_size_factor <= 0:
        raise ValueError(
            f"chain_size_factor must be > 0, got {chain_size_factor}"
        )

    chain_radius = float(chain_geometry_report["max_radial_distance_angstrom"])
    floor_radius = chain_size_factor * chain_radius * (n_chains ** (1.0 / 3.0))

    return {
        "chain_size_factor": chain_size_factor,
        "single_chain_max_radial_distance_angstrom": chain_radius,
        "n_chains": n_chains,
        "radius_angstrom": floor_radius,
    }


def _count_pdb_records(pdb_path: Path) -> dict[str, int]:
    counts = {"ATOM": 0, "HETATM": 0}
    with pdb_path.open("r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("ATOM"):
                counts["ATOM"] += 1
            elif line.startswith("HETATM"):
                counts["HETATM"] += 1
    return counts


def _write_packmol_input(
    path: Path,
    *,
    chain_pdb_name: str,
    output_pdb_name: str,
    n_chains: int,
    shape: str,
    radius_angstrom: float,
    tolerance: float,
    maxit: int,
    nloop: int,
    discale: float,
    precision: int,
    movefrac: float,
    seed: int | None = None,
) -> None:
    if shape != "sphere":
        raise ValueError(f"Packmol v1 supports only shape='sphere', got {shape!r}")
    if radius_angstrom <= 0:
        raise ValueError(f"radius_angstrom must be > 0, got {radius_angstrom}")
    if n_chains <= 0:
        raise ValueError(f"n_chains must be > 0, got {n_chains}")
    if tolerance <= 0:
        raise ValueError(f"tolerance must be > 0, got {tolerance}")
    if maxit <= 0:
        raise ValueError(f"maxit must be > 0, got {maxit}")
    if nloop <= 0:
        raise ValueError(f"nloop must be > 0, got {nloop}")
    if discale <= 0:
        raise ValueError(f"discale must be > 0, got {discale}")
    if precision <= 0:
        raise ValueError(f"precision must be > 0, got {precision}")
    if movefrac <= 0:
        raise ValueError(f"movefrac must be > 0, got {movefrac}")
    if seed is not None and seed <= 0:
        raise ValueError(f"seed must be > 0 or None, got {seed}")

    lines = []
    if seed is not None:
        lines.append(f"seed {int(seed)}")

    lines.extend([
        f"tolerance {float(tolerance):g}",
        "filetype pdb",
        f"output {output_pdb_name}",
        "",
        f"maxit {int(maxit)}",
        f"nloop {int(nloop)}",
        f"discale {float(discale):g}",
        f"precision {int(precision)}",
        "",
        f"structure {chain_pdb_name}",
        f"  number {int(n_chains)}",
        f"  movefrac {float(movefrac):g}",
        f"  inside sphere 0. 0. 0. {float(radius_angstrom):g}",
        "end structure",
        "",
    ])

    path.write_text("\n".join(lines), encoding="utf-8")


def _run_packmol_once(
    *,
    exe: str,
    workdir: Path,
    packmol_input: Path,
    stdout_file: Path,
    stderr_file: Path,
) -> subprocess.CompletedProcess:
    with (
        packmol_input.open("r", encoding="utf-8") as fin,
        stdout_file.open("w", encoding="utf-8") as fout,
        stderr_file.open("w", encoding="utf-8") as ferr,
    ):
        completed = subprocess.run(
            [exe],
            stdin=fin,
            stdout=fout,
            stderr=ferr,
            cwd=workdir,
            check=False,
            text=True,
        )
    return completed


def _chain_id_for_index(index: int) -> str:
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    if index < len(alphabet):
        return alphabet[index]
    raise ValueError(
        f"Too many chains for simple PDB chain-ID assignment: {index + 1}"
    )


def _normalize_packed_pdb(
    packed_pdb: Path,
    *,
    atoms_per_chain: int,
    n_chains: int,
    residue_name: str = "PLG",
) -> None:
    require_nonempty_file(packed_pdb, "packed nanoparticle PDB")

    if atoms_per_chain <= 0:
        raise ValueError(f"atoms_per_chain must be > 0, got {atoms_per_chain}")
    if n_chains <= 0:
        raise ValueError(f"n_chains must be > 0, got {n_chains}")

    lines = packed_pdb.read_text(encoding="utf-8", errors="replace").splitlines()
    atom_indices: list[int] = []
    for idx, line in enumerate(lines):
        if line.startswith("ATOM") or line.startswith("HETATM"):
            atom_indices.append(idx)

    total_atoms = len(atom_indices)
    expected_atoms = atoms_per_chain * n_chains
    if total_atoms != expected_atoms:
        raise ValueError(
            f"Packed PDB atom count mismatch: expected {expected_atoms} "
            f"({atoms_per_chain} atoms/chain × {n_chains} chains), found {total_atoms}"
        )

    new_lines = list(lines)

    for global_atom_index, line_index in enumerate(atom_indices):
        line = new_lines[line_index]
        chain_index = global_atom_index // atoms_per_chain
        chain_id = _chain_id_for_index(chain_index)
        residue_seq = chain_index + 1

        # Preserve line length enough for column edits
        padded = line.rstrip("\n")
        if len(padded) < 80:
            padded = padded.ljust(80)

        # Residue name: cols 18-20 -> 0-based [17:20]
        padded = padded[:17] + f"{residue_name:>3}" + padded[20:]

        # Chain ID: col 22 -> 0-based [21]
        padded = padded[:21] + chain_id + padded[22:]

        # Residue sequence: cols 23-26 -> 0-based [22:26]
        padded = padded[:22] + f"{residue_seq:4d}" + padded[26:]

        new_lines[line_index] = padded.rstrip()

    packed_pdb.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    require_nonempty_file(packed_pdb, "normalized packed nanoparticle PDB")



def _compute_packing_quality(packed_pdb: Path) -> dict:
    coords = []
    chain_ids = []

    with packed_pdb.open("r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("ATOM") or line.startswith("HETATM"):
                try:
                    x = float(line[30:38].strip())
                    y = float(line[38:46].strip())
                    z = float(line[46:54].strip())
                    chain_id = line[21].strip() or "?"
                except ValueError:
                    continue
                coords.append((x, y, z))
                chain_ids.append(chain_id)

    if not coords:
        return {"error": "no coordinates found"}

    n = len(coords)

    # --- global centroid ---
    cx = sum(x for x, _, _ in coords) / n
    cy = sum(y for _, y, _ in coords) / n
    cz = sum(z for _, _, z in coords) / n

    # --- radial distribution ---
    radial = []
    for x, y, z in coords:
        dx, dy, dz = x - cx, y - cy, z - cz
        radial.append(math.sqrt(dx*dx + dy*dy + dz*dz))

    # --- interchain distances ---
    min_dist = float("inf")
    clash_count_1p5 = 0
    clash_count_2p0 = 0

    for i in range(n):
        xi, yi, zi = coords[i]
        ci = chain_ids[i]

        for j in range(i + 1, n):
            if ci == chain_ids[j]:
                continue

            xj, yj, zj = coords[j]
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            d = math.sqrt(dx*dx + dy*dy + dz*dz)

            if d < min_dist:
                min_dist = d

            if d < 1.5:
                clash_count_1p5 += 1
            if d < 2.0:
                clash_count_2p0 += 1

    # Compute percentiles for radial spread
    sorted_radial = sorted(radial)
    n_radial = len(sorted_radial)
    r10_idx = max(0, int(n_radial * 0.1))
    r90_idx = min(n_radial - 1, int(n_radial * 0.9))
    r10 = sorted_radial[r10_idx]
    r90 = sorted_radial[r90_idx]
    radial_spread = r90 - r10
    
    return {
        "min_interchain_distance_angstrom": min_dist,
        "clash_contacts_below_1p5A": clash_count_1p5,
        "close_contacts_below_2p0A": clash_count_2p0,
        "radial_distribution": {
            "min": min(radial),
            "max": max(radial),
            "mean": sum(radial) / len(radial),
            "r10_angstrom": r10,
            "r90_angstrom": r90,
            "radial_spread_angstrom": radial_spread,
        },
    }


def _classify_packing(pq: dict) -> str:
    min_dist = pq.get("min_interchain_distance_angstrom", float("inf"))
    clashes = pq.get("clash_contacts_below_1p5A", 0)

    if min_dist == float("inf") or min_dist > 6.0:
        return "too_loose"

    if clashes > 0:
        return "too_dense"

    return "acceptable"


def _compute_radial_uniformity(pq: dict) -> float:
    rd = pq.get("radial_distribution", {})
    rmin = rd.get("min", 0.0)
    rmax = rd.get("max", 0.0)
    rmean = rd.get("mean", 0.0)

    if rmax == 0:
        return 0.0

    # Normalize spread
    spread = (rmax - rmin) / rmax

    # Ideal NP: moderate spread (not shell-like, not collapsed)
    # Target ~0.5–0.8
    if 0.4 <= spread <= 0.8:
        return 5.0
    elif 0.2 <= spread < 0.4:
        return 2.0
    else:
        return -3.0


def _score_packing(pq: dict) -> float:
    """
    Score packing quality based on interchain distances, contacts, and uniformity.
    
    Scoring strategy:
    - Hard penalties for unphysical geometries (< 1.8 Å)
    - Rewards for soft contacts in optimal range (2-4 Å)
    - Penalizes clashes and loose structures
    - Bonus for radial uniformity
    
    Args:
        pq: Packing quality dict with:
            - min_interchain_distance_angstrom
            - clash_contacts_below_1p5A
            - close_contacts_below_2p0A
            - radial_distribution dict
    
    Returns:
        Score (higher is better)
    """
    min_dist = pq.get("min_interchain_distance_angstrom", float("inf"))
    clashes = pq.get("clash_contacts_below_1p5A", 0)
    close_contacts = pq.get("close_contacts_below_2p0A", 0)

    # Penalize infinite distance heavily (no interaction)
    if min_dist == float("inf"):
        return -1e6

    score = 0.0

    # Prefer distances around 2–4 Å (soft contact regime)
    # Van der Waals contact for C-C is ~3.4 Å; < 1.8 Å is unphysical
    if min_dist < 1.5:
        score -= 1000  # hard clash → severe penalty
    elif min_dist < 1.8:
        score -= 500   # too dense → moderate penalty (unphysical overlap)
    elif 1.5 <= min_dist <= 2.5:
        score += 10    # ideal: soft contact
    elif 2.5 < min_dist <= 4.0:
        score += 7     # good: normal VdW
    elif 4.0 < min_dist <= 6.0:
        score += 3     # acceptable: loose
    else:
        score -= 5     # too loose: chains too far apart

    # Penalize clashes strongly
    score -= clashes * 50

    # Reward some close contacts (but not too many)
    score += min(close_contacts, 50) * 0.2

    # Radial uniformity bonus
    score += _compute_radial_uniformity(pq)

    return score


def _compute_convex_hull_volume(packed_pdb: Path) -> float | None:
    """
    Compute convex hull volume of the packed nanoparticle from atom coordinates.

    Returns None if the computation cannot be performed.
    """
    try:
        import numpy as np
        from scipy.spatial import ConvexHull
    except ImportError:
        return None

    coords = []
    with packed_pdb.open("r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith(("ATOM", "HETATM")):
                try:
                    x = float(line[30:38].strip())
                    y = float(line[38:46].strip())
                    z = float(line[46:54].strip())
                except ValueError:
                    continue
                coords.append((x, y, z))

    if len(coords) < 4:
        return None

    points = np.asarray(coords, dtype=float)

    try:
        hull = ConvexHull(points)
        return float(hull.volume)
    except Exception:
        return None


def _compute_packing_efficiency(
    packed_pdb: Path,
    target_radius_angstrom: float,
) -> dict | None:
    """
    Calculate packing efficiency: actual_volume / ideal_sphere_volume.
    
    Efficiency metric: ratio of convex hull volume to ideal sphere volume.
    - 1.0 = perfect sphere packing (theoretical maximum)
    - 0.6-0.8 = good packing efficiency
    - < 0.5 = poor packing (chains too loose or irregular)
    - None = computation failed (missing scipy or invalid coordinates)
    
    Args:
        packed_pdb: Path to packed PDB file
        target_radius_angstrom: Target sphere radius
    
    Returns:
        Dict with volumes and efficiency metrics, or None if computation fails
    """
    # Compute actual volume (convex hull of all atoms)
    actual_volume = _compute_convex_hull_volume(packed_pdb)
    if actual_volume is None or target_radius_angstrom <= 0:
        return None
    
    # Compute ideal sphere volume
    ideal_volume = (4.0 / 3.0) * math.pi * (target_radius_angstrom ** 3)
    if ideal_volume <= 0:
        return None
    
    # Calculate efficiency
    efficiency = actual_volume / ideal_volume
    
    return {
        "convex_hull_volume_angstrom3": actual_volume,
        "ideal_sphere_volume_angstrom3": ideal_volume,
        "packing_efficiency": efficiency,
        "efficiency_percent": efficiency * 100.0,
    }


def pack_nanoparticle(
    chain_pdb: str,
    n_chains: int,
    shape: str,
    out_dir: str,
    *,
    radius_mode: str = "manual",
    radius_angstrom: float | None = None,
    chain_json: str | None = None,
    target_density_g_cm3: float = 1.25,
    packing_slack_factor: float = 1.25,
    chain_size_factor: float = 1.20,
    minimum_radius_angstrom: float | None = None,
    tolerance: float = 2.0,
    packmol_seed: int | None = None,
    retry_scale_factors: Iterable[float] = (1.0, 1.2, 1.5, 2.0),
    packmol_maxit: int = 200,
    packmol_nloop: int = 2000,
    packmol_movefrac: float = 0.05,
    packmol_maxmove: int | None = None,
    packmol_discale: float = 1.5,
    packmol_precision: int = 2,
    **_ignored_kwargs,
) -> Dict[str, str]:
    if n_chains <= 0:
        raise ValueError(f"n_chains must be > 0, got {n_chains}")

    source_chain_pdb = require_nonempty_file(chain_pdb, "input chain PDB")
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    exe = _find_packmol_executable()
    local_chain_pdb = out_path / "chain_input.pdb"
    shutil.copyfile(source_chain_pdb, local_chain_pdb)

    chain_geometry_report = _compute_chain_geometry_report(local_chain_pdb)

    # Initialize radius selection variables
    radius_source = "unknown"
    base_radius_angstrom = None
    density_radius_angstrom = None
    chain_floor_radius_angstrom = None
    density_report = None
    chain_floor_report = None

    if radius_mode == "manual":
        if radius_angstrom is None or radius_angstrom <= 0:
            raise ValueError(
                f"radius_angstrom must be > 0 for manual mode, got {radius_angstrom}"
            )
        base_radius_angstrom = float(radius_angstrom)
        radius_source = "manual"

    elif radius_mode == "density_based":
        if chain_json is None:
            raise ValueError(
                "density_based radius mode requires chain_json metadata input."
            )

        chain_meta = _load_chain_metadata(chain_json)
        exact_mw = float(chain_meta["exact_mw"])

        density_report = _compute_density_based_radius_angstrom(
            exact_mw_g_mol=exact_mw,
            n_chains=n_chains,
            target_density_g_cm3=float(target_density_g_cm3),
            packing_slack_factor=float(packing_slack_factor),
        )
        density_radius_angstrom = float(density_report["radius_angstrom"])

        chain_floor_report = _compute_chain_floor_radius_angstrom(
            chain_geometry_report=chain_geometry_report,
            n_chains=n_chains,
            chain_size_factor=float(chain_size_factor),
        )
        chain_floor_radius_angstrom = float(chain_floor_report["radius_angstrom"])

        base_radius_angstrom = max(density_radius_angstrom, chain_floor_radius_angstrom)

        # Soft constraint: apply minimum_radius as override
        if minimum_radius_angstrom is not None and base_radius_angstrom < float(minimum_radius_angstrom):
            base_radius_angstrom = float(minimum_radius_angstrom)
            radius_source = "minimum_override"
        elif base_radius_angstrom == chain_floor_radius_angstrom:
            radius_source = "chain_floor"
        else:
            radius_source = "density"

    else:
        raise ValueError(
            "radius_mode must be one of ['manual', 'density_based'], "
            f"got {radius_mode!r}"
        )

    packed_pdb = out_path / "packed_nanoparticle.pdb"
    report_json = out_path / "packing_report.json"

    completed = None
    success_radius = None
    success_attempt = None

    ignored_packmol_options = {}
    if packmol_seed is not None:
        ignored_packmol_options["packmol_seed"] = packmol_seed
    if packmol_maxmove is not None:
        ignored_packmol_options["packmol_maxmove"] = packmol_maxmove

    attempt_records = []
    radius = base_radius_angstrom
    step_scale = 0.25
    max_attempts = 8
    best_score = -1e9
    best_attempt = None
    fallback_mode = False

    for attempt_index in range(1, max_attempts + 1):
        packmol_input = out_path / f"packmol_attempt_{attempt_index:02d}.inp"
        stdout_file = out_path / f"packmol_attempt_{attempt_index:02d}.stdout.txt"
        stderr_file = out_path / f"packmol_attempt_{attempt_index:02d}.stderr.txt"

        # Randomize per attempt
        seed = random.randint(1, 10_000_000)
        radius_jitter = radius * random.uniform(-0.05, 0.05)
        trial_radius = radius + radius_jitter
        trial_movefrac = random.uniform(0.03, 0.08)

        _write_packmol_input(
            packmol_input,
            chain_pdb_name=local_chain_pdb.name,
            output_pdb_name=packed_pdb.name,
            n_chains=n_chains,
            shape=shape,
            radius_angstrom=trial_radius,
            tolerance=float(tolerance),
            maxit=int(packmol_maxit),
            nloop=int(packmol_nloop),
            discale=float(packmol_discale),
            precision=int(packmol_precision),
            movefrac=trial_movefrac,
            seed=seed,
        )

        completed = _run_packmol_once(
            exe=exe,
            workdir=out_path,
            packmol_input=packmol_input,
            stdout_file=stdout_file,
            stderr_file=stderr_file,
        )

        record = {
            "attempt_index": attempt_index,
            "radius_angstrom": radius,
            "trial_radius_angstrom": trial_radius,
            "trial_movefrac": trial_movefrac,
            "seed": seed,
            "packmol_input": str(packmol_input),
            "stdout_file": str(stdout_file),
            "stderr_file": str(stderr_file),
            "returncode": completed.returncode,
        }

        if completed.returncode != 0:
            record["status"] = "operational_fail"
            radius *= 1.0 + step_scale
            attempt_records.append(record)
            continue

        if not (packed_pdb.exists() and packed_pdb.stat().st_size > 0):
            record["status"] = "operational_fail"
            radius *= 1.0 + step_scale
            attempt_records.append(record)
            continue

        # CRITICAL: normalize BEFORE QC
        _normalize_packed_pdb(
            packed_pdb,
            atoms_per_chain=int(chain_geometry_report["n_atoms"]),
            n_chains=n_chains,
            residue_name="PLG",
        )

        # DEBUG: verify chain IDs exist
        chain_ids = set()
        with packed_pdb.open() as fh:
            for line in fh:
                if line.startswith(("ATOM", "HETATM")):
                    chain_ids.add(line[21])

        if len(chain_ids) < 2:
            raise RuntimeError(
                f"Chain ID normalization failed. Found only: {chain_ids}"
            )

        pq = _compute_packing_quality(packed_pdb)
        record["packing_quality"] = pq

        classification = _classify_packing(pq)
        record["classification"] = classification

        score = _score_packing(pq)
        record["score"] = score

        if score > best_score:
            best_score = score
            best_attempt = record

        attempt_records.append(record)

        if classification == "acceptable" and score > 8:
            success_attempt = record
            success_radius = radius
            break

        elif classification == "too_loose":
            radius *= (1.0 - step_scale)

        elif classification == "too_dense":
            radius *= (1.0 + step_scale)

    else:
        # Fallback: use best attempt if no early success
        if best_attempt is not None:
            success_attempt = best_attempt
            success_radius = best_attempt["radius_angstrom"]
            fallback_mode = True
        else:
            failure_report = {
                "status": "failed",
                "returncode": completed.returncode if completed is not None else None,
                "packmol_executable": exe,
                "input_chain_pdb": str(source_chain_pdb),
                "n_chains": n_chains,
                "shape": shape,
                "radius_mode": radius_mode,
                "base_radius_angstrom": base_radius_angstrom,
                "attempts": attempt_records,
            }
            report_json.write_text(
                json.dumps(failure_report, indent=2), encoding="utf-8"
            )
            raise RuntimeError(
                f"Packmol failed to find acceptable packing after {max_attempts} adaptive attempts. "
                f"See {report_json} and attempt-specific stdout/stderr files."
            )

    attempts = attempt_records

    status = "failed"
    if success_radius is not None:
        status = "fallback_best" if fallback_mode else "success"

    report = {
        "status": status,
        "returncode": completed.returncode if completed is not None else None,
        "packmol_executable": exe,
        "input_chain_pdb": str(source_chain_pdb),
        "local_chain_pdb": str(local_chain_pdb),
        "packed_pdb": str(packed_pdb),
        "n_chains": n_chains,
        "shape": shape,
        "radius_mode": radius_mode,
        "base_radius_angstrom": base_radius_angstrom,
        "radius_angstrom": success_radius,
        "attempts": attempts,
        "packmol_controls": {
            "tolerance": float(tolerance),
            "maxit": int(packmol_maxit),
            "nloop": int(packmol_nloop),
            "movefrac": float(packmol_movefrac),
            "discale": float(packmol_discale),
            "precision": int(packmol_precision),
        },
        "ignored_packmol_options": ignored_packmol_options,
        "chain_geometry_report": chain_geometry_report,
        "radius_selection": {
            "density_radius_angstrom": (
                None
                if density_report is None
                else float(density_report["radius_angstrom"])
            ),
            "chain_floor_radius_angstrom": (
                None
                if chain_floor_report is None
                else float(chain_floor_report["radius_angstrom"])
            ),
            "minimum_radius_angstrom": minimum_radius_angstrom,
            "selected_base_radius_angstrom": base_radius_angstrom,
            "radius_source": radius_source,
        },
        "identity_normalization": {
            "normalized_residue_name": "PLG",
            "chain_ids_assigned_per_copy": True,
        },
    }

    if density_report is not None:
        report["density_based_radius_report"] = density_report
    if chain_floor_report is not None:
        report["chain_floor_radius_report"] = chain_floor_report

    if success_radius is None:
        report_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
        raise RuntimeError(
            "Packmol failed for all retry radii. "
            f"See {report_json} and attempt-specific stdout/stderr files."
        )

    _normalize_packed_pdb(
        packed_pdb,
        atoms_per_chain=int(chain_geometry_report["n_atoms"]),
        n_chains=n_chains,
        residue_name="PLG",
    )

    packing_quality = _compute_packing_quality(packed_pdb)
    report["packing_quality"] = packing_quality

    # Calculate packing efficiency (fail-safe: returns None if computation fails)
    packing_efficiency = _compute_packing_efficiency(packed_pdb, float(success_radius))
    if packing_efficiency is not None:
        report["packing_efficiency"] = packing_efficiency

    record_counts = _count_pdb_records(packed_pdb)
    report["pdb_record_counts"] = record_counts
    report["total_coordinate_records"] = (
        record_counts["ATOM"] + record_counts["HETATM"]
    )

    final_packmol_input = out_path / "packmol.inp"
    final_stdout_file = out_path / "packmol.stdout.txt"
    final_stderr_file = out_path / "packmol.stderr.txt"

    if success_attempt is None:
        report["attempts"] = attempt_records
        report_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
        raise RuntimeError(
            f"No accepted packing attempt was recorded. See {report_json}."
        )

    shutil.copyfile(success_attempt["packmol_input"], final_packmol_input)
    shutil.copyfile(success_attempt["stdout_file"], final_stdout_file)
    shutil.copyfile(success_attempt["stderr_file"], final_stderr_file)

    report["packmol_input"] = str(final_packmol_input)
    report["stdout_file"] = str(final_stdout_file)
    report["stderr_file"] = str(final_stderr_file)

    packing_efficiency_value = (
        packing_efficiency.get("packing_efficiency") if packing_efficiency else None
    )

    atom_density_proxy = None
    if packing_efficiency_value is None:
        convex_hull_volume = _compute_convex_hull_volume(packed_pdb)
        total_atom_count = record_counts["ATOM"] + record_counts["HETATM"]
        atom_density_proxy = (
            total_atom_count / convex_hull_volume
            if convex_hull_volume is not None and convex_hull_volume > 0
            else None
        )

    radial_spread = (
        packing_quality.get("radial_distribution", {}).get("radial_spread_angstrom", 0.0)
    )
    radial_spread_threshold = 0.25 * float(success_radius)
    morphology = (
        "core_compact" if radial_spread < radial_spread_threshold else "shell_like"
    )

    radius_reduction_fraction = 0.0
    if base_radius_angstrom is not None and base_radius_angstrom > 0:
        radius_reduction_fraction = (
            (base_radius_angstrom - float(success_radius)) / base_radius_angstrom
        )

    report["selected_attempt"] = {
        "attempt_index": success_attempt.get("attempt_index"),
        "score": success_attempt.get("score"),
        "classification": success_attempt.get("classification"),
        "radius_angstrom": float(success_radius),
        "min_interchain_distance_angstrom": packing_quality.get("min_interchain_distance_angstrom"),
        "packing_efficiency": packing_efficiency_value,
        "atom_density_proxy": atom_density_proxy,
        "morphology": morphology,
        "optimization_trace": {
            "initial_radius": float(base_radius_angstrom),
            "final_radius": float(success_radius),
            "radius_reduction_fraction": radius_reduction_fraction,
        },
    }

    report_json.write_text(json.dumps(report, indent=2), encoding="utf-8")

    return {
        "packed_pdb": str(packed_pdb),
        "packmol_input": str(final_packmol_input),
        "packing_report_json": str(report_json),
    }