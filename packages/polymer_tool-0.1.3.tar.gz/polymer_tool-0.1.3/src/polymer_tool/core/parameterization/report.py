from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from rdkit import Chem

from .openff_backend import ParameterizationResult


def write_parameterized_sdf(mol: Chem.Mol, path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    writer = Chem.SDWriter(str(p))
    writer.write(mol)
    writer.close()
    return str(p)


def write_parameterization_report(
    *,
    result: ParameterizationResult,
    input_sdf: str,
    output_sdf: str,
    path: str | Path,
) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    payload: Dict[str, Any] = {
        "status": "success",
        "backend_used": result.backend_used,
        "charge_method_requested": result.charge_method_requested,
        "charge_method_used": result.charge_method_used,
        "forcefield_requested": result.forcefield_requested,
        "input_sdf": str(input_sdf),
        "output_sdf": str(output_sdf),
        "fallback_used": result.fallback_used,
        "formal_charge": result.formal_charge,
        "net_partial_charge": result.net_partial_charge,
        "formula": result.formula,
        "exact_mw": result.exact_mw,
        "n_atoms": int(result.mol.GetNumAtoms()),
        "n_bonds": int(result.mol.GetNumBonds()),
        "warnings": result.warnings,
        "notes": result.notes,
    }

    p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return str(p)
