from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List
import warnings

from rdkit import Chem
from rdkit.Chem import AllChem, rdMolDescriptors

try:
    from openff.toolkit import Molecule as OFFMolecule
    from openff.units import unit as offunit
    HAS_OPENFF = True
except ImportError:
    HAS_OPENFF = False
    OFFMolecule = None
    offunit = None


MAX_OPENFF_ATOMS = 150


@dataclass
class ParameterizationResult:
    mol: Chem.Mol
    backend_used: str
    charge_method_requested: str
    charge_method_used: str
    forcefield_requested: str
    warnings: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    fallback_used: bool = False
    net_partial_charge: float | None = None
    formal_charge: int | None = None
    formula: str | None = None
    exact_mw: float | None = None


def _load_single_mol_from_sdf(input_sdf: str) -> Chem.Mol:
    supplier = Chem.SDMolSupplier(str(input_sdf), removeHs=False)
    mols = [m for m in supplier if m is not None]
    if not mols:
        raise ValueError(f"No valid molecules found in SDF: {input_sdf}")
    if len(mols) > 1:
        raise ValueError(f"Expected one molecule in SDF, found {len(mols)}: {input_sdf}")
    mol = mols[0]
    Chem.SanitizeMol(mol)
    return mol


def _compute_gasteiger_charges(mol: Chem.Mol) -> float:
    work = Chem.Mol(mol)
    AllChem.ComputeGasteigerCharges(work)

    total = 0.0
    for atom in work.GetAtoms():
        if atom.HasProp("_GasteigerCharge"):
            val = atom.GetProp("_GasteigerCharge")
            try:
                q = float(val)
            except ValueError:
                q = 0.0
            total += q

    for src_atom, dst_atom in zip(work.GetAtoms(), mol.GetAtoms()):
        if src_atom.HasProp("_GasteigerCharge"):
            dst_atom.SetProp("_GasteigerCharge", src_atom.GetProp("_GasteigerCharge"))

    return total


def parameterize_with_rdkit(
    *,
    input_sdf: str,
    charge_method: str,
    forcefield: str,
) -> ParameterizationResult:
    mol = _load_single_mol_from_sdf(input_sdf)

    warnings: List[str] = []
    notes: List[str] = []
    backend_used = "rdkit_v1"
    charge_method_requested = charge_method
    charge_method_used = charge_method
    fallback_used = False

    normalized_charge = charge_method.strip().lower()

    n_atoms = mol.GetNumAtoms()

    if normalized_charge in {"auto", "openff", "am1bcc", "am1-bcc"}:

        if HAS_OPENFF and n_atoms <= MAX_OPENFF_ATOMS:
            try:
                if mol.GetNumConformers() == 0:
                    AllChem.EmbedMolecule(mol)

                offmol = OFFMolecule.from_rdkit(mol, allow_undefined_stereo=True)

                offmol.generate_conformers(n_conformers=1)

                offmol.assign_partial_charges("am1bcc")

                charges = offmol.partial_charges.m_as(offunit.elementary_charge)

                for atom, q in zip(mol.GetAtoms(), charges):
                    qf = str(float(q))
                    atom.SetProp("_GasteigerCharge", qf)                 # backward compatibility
                    atom.SetProp("polymer_tool_partial_charge", qf)      # correct semantic tag

                net_q = float(charges.sum())

                backend_used = "openff_am1bcc"
                charge_method_used = "openff_am1bcc"

                notes.append("Assigned OpenFF AM1-BCC charges.")

            except Exception as e:
                net_q = _compute_gasteiger_charges(mol)
                charge_method_used = "gasteiger"
                fallback_used = True

                warnings.append(
                    f"OpenFF charge assignment failed ({e}); used Gasteiger fallback."
                )

        elif not HAS_OPENFF:
            net_q = _compute_gasteiger_charges(mol)
            charge_method_used = "gasteiger"
            fallback_used = True

            warnings.append(
                "OpenFF toolkit not installed; used RDKit Gasteiger charges. "
                "Install 'openff-toolkit' and 'openff-forcefields' for AM1-BCC charges."
            )

        else:
            net_q = _compute_gasteiger_charges(mol)
            charge_method_used = "gasteiger"
            fallback_used = True

            warnings.append(
                f"Atom count {n_atoms} exceeds cutoff ({MAX_OPENFF_ATOMS}); used Gasteiger."
            )

    elif normalized_charge in {"gasteiger", "rdkit-gasteiger"}:
        net_q = _compute_gasteiger_charges(mol)
        charge_method_used = "gasteiger"
        notes.append("Assigned RDKit Gasteiger partial charges.")
    elif normalized_charge in {"none", "skip"}:
        net_q = None
        charge_method_used = "none"
        notes.append("No partial charges were assigned.")
    else:
        net_q = _compute_gasteiger_charges(mol)
        charge_method_used = "gasteiger"
        fallback_used = True
        warnings.append(
            f"Unrecognized charge method {charge_method!r}; used RDKit Gasteiger charges."
        )

    formal_charge = int(sum(atom.GetFormalCharge() for atom in mol.GetAtoms()))
    formula = rdMolDescriptors.CalcMolFormula(mol)
    exact_mw = float(rdMolDescriptors.CalcExactMolWt(mol))

    mol.SetProp("polymer_tool_parameterization_backend", backend_used)
    mol.SetProp("polymer_tool_charge_method_requested", charge_method_requested)
    mol.SetProp("polymer_tool_charge_method_used", charge_method_used)
    mol.SetProp("polymer_tool_forcefield_requested", forcefield)
    mol.SetProp("polymer_tool_formal_charge", str(formal_charge))
    mol.SetProp("polymer_tool_formula", formula)
    mol.SetProp("polymer_tool_exact_mw", f"{exact_mw:.8f}")
    if net_q is not None:
        mol.SetProp("polymer_tool_net_partial_charge", f"{net_q:.8f}")

    return ParameterizationResult(
        mol=mol,
        backend_used=backend_used,
        charge_method_requested=charge_method_requested,
        charge_method_used=charge_method_used,
        forcefield_requested=forcefield,
        warnings=warnings,
        notes=notes,
        fallback_used=fallback_used,
        net_partial_charge=net_q,
        formal_charge=formal_charge,
        formula=formula,
        exact_mw=exact_mw,
    )
