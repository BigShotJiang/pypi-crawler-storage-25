from __future__ import annotations

from pathlib import Path
from typing import Dict

from rdkit.Chem import rdMolDescriptors

from polymer_tool.core.builders.export import (
    mol_from_smiles_3d,
    write_json,
    write_pdb,
    write_sdf,
)
from polymer_tool.core.builders.plga import build_plga_dimethyl_ester_smiles
from polymer_tool.core.builders.sequence import build_sequence_plan
from polymer_tool.core.validators import require_nonempty_file


def build_plga_chain(
    dp: int,
    lactic_fraction: float,
    stereo_pattern: str,
    end_group: str,
    out_prefix: str,
    sequence_mode: str = "balanced",
    random_seed: int | None = None,
) -> Dict[str, str]:
    """
    Builder v4:
      - linear PLGA
      - selectable sequence architecture:
          balanced | block | random_seeded | random_coupled
      - selectable lactic stereochemistry:
          alt_RS | all_R | all_S | random_RS_seeded
      - ester-capped chain
      - exports SDF, PDB, JSON
    """
    base = Path(out_prefix)
    base.parent.mkdir(parents=True, exist_ok=True)

    sdf = base.with_suffix(".sdf")
    pdb = base.with_suffix(".pdb")
    meta = base.with_suffix(".json")

    plan = build_sequence_plan(
        dp=dp,
        lactic_fraction=lactic_fraction,
        stereo_pattern=stereo_pattern,
        sequence_mode=sequence_mode,
        random_seed=random_seed,
    )

    build = build_plga_dimethyl_ester_smiles(
        plan=plan,
        end_group=end_group,
    )

    debug_smiles = base.with_suffix(".smiles.txt")
    debug_smiles.write_text(build.smiles + "\n", encoding="utf-8")

    mol = mol_from_smiles_3d(build.smiles)

    mol.SetProp("polymer_tool_dp", str(dp))
    mol.SetProp("polymer_tool_lactic_fraction", str(lactic_fraction))
    mol.SetProp("polymer_tool_stereo_pattern", stereo_pattern)
    mol.SetProp("polymer_tool_end_group", end_group)
    mol.SetProp("polymer_tool_sequence_mode", sequence_mode)
    mol.SetProp("polymer_tool_random_seed", "" if random_seed is None else str(random_seed))
    mol.SetProp("polymer_tool_smiles", build.smiles)

    write_sdf(mol, sdf)
    write_pdb(mol, pdb)
    write_json(
        {
            "builder_version": "v4",
            "description": "Linear dimethyl-capped PLGA chain",
            "dp_requested": dp,
            "lactic_fraction_requested": lactic_fraction,
            "stereo_pattern": stereo_pattern,
            "end_group": end_group,
            "sequence_mode": sequence_mode,
            "random_seed": random_seed,
            "n_lactic": plan.n_lactic,
            "n_glycolic": plan.n_glycolic,
            "residue_sequence": plan.residues,
            "realized_sequence_string": "".join(plan.residues),
            "lactic_stereo_labels": plan.lactic_stereo,
            "realized_lactic_stereo_string": "".join(plan.lactic_stereo),
            "residue_records": build.residue_records,
            "smiles": build.smiles,
            "n_atoms_with_h": int(mol.GetNumAtoms()),
            "formula": rdMolDescriptors.CalcMolFormula(mol),
            "exact_mw": rdMolDescriptors.CalcExactMolWt(mol),
        },
        meta,
    )

    require_nonempty_file(sdf, "chain SDF")
    require_nonempty_file(pdb, "chain PDB")
    require_nonempty_file(meta, "chain metadata JSON")

    return {
        "sdf": str(sdf),
        "pdb": str(pdb),
        "json": str(meta),
    }