from __future__ import annotations

from pathlib import Path


def require_file(path: str | Path, label: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Expected {label} file was not created: {p}")
    if p.is_dir():
        raise IsADirectoryError(f"Expected {label} file but found directory: {p}")
    return p


def require_nonempty_file(path: str | Path, label: str) -> Path:
    p = require_file(path, label)
    if p.stat().st_size == 0:
        raise ValueError(f"Expected non-empty {label} file but file is empty: {p}")
    return p
