from __future__ import annotations

from typing import Dict, List


def build_readiness_report(
    *,
    n_chains: int,
    chain_atom_count: int,
    total_atom_count: int,
    charge_method_used: str | None,
    topology_bridge_ready: bool,
    gromacs_handoff_ready: bool,
) -> Dict:
    warnings: List[str] = []
    notes: List[str] = []

    if total_atom_count != n_chains * chain_atom_count:
        warnings.append(
            "Total atom count does not match n_chains × chain_atom_count."
        )
    else:
        notes.append(
            "Total atom count matches n_chains × chain_atom_count."
        )

    if charge_method_used == "gasteiger":
        warnings.append(
            "Current partial charges are first-pass preparation metadata, not a production topology."
        )

    if topology_bridge_ready:
        notes.append("Topology bridge bookkeeping is available.")
    if gromacs_handoff_ready:
        notes.append("GROMACS-oriented handoff bundle is available.")

    return {
        "report_type": "readiness_report_v1",
        "ready": {
            "single_chain_structure": True,
            "packed_coordinates": True,
            "identity_normalization": True,
            "component_bookkeeping": True,
            "topology_bridge": topology_bridge_ready,
            "gromacs_handoff_bundle": gromacs_handoff_ready,
        },
        "not_ready": {
            "production_topology": True,
            "simulation_execution_inputs": True,
            "engine-specific finalized force-field package": True,
        },
        "system_summary": {
            "n_chains": n_chains,
            "chain_atom_count": chain_atom_count,
            "total_atom_count": total_atom_count,
            "charge_method_used": charge_method_used,
        },
        "warnings": warnings,
        "notes": notes,
    }