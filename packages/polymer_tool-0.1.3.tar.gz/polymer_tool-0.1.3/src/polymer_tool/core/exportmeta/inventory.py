from __future__ import annotations

from typing import Dict


def build_file_inventory(
    *,
    chain_json: str,
    chain_parameterized_sdf: str,
    packed_pdb: str,
    system_manifest_json: str,
    components_json: str,
    prep_report_json: str,
    packed_chain_map_json: str,
    component_index_map_json: str,
    topology_prep_manifest_json: str,
    external_ff_notes_txt: str,
    export_manifest_json: str,
    handoff_notes_txt: str,
    workflow_summary_json: str,
    bundle_checksums_json: str,
    export_archive_targz: str,
    export_bundle_dir: str,
) -> Dict:
    return {
        "inventory_type": "file_inventory_v1",
        "structures": {
            "chain_json": chain_json,
            "chain_parameterized_sdf": chain_parameterized_sdf,
            "packed_pdb": packed_pdb,
        },
        "system_metadata": {
            "system_manifest_json": system_manifest_json,
            "components_json": components_json,
            "prep_report_json": prep_report_json,
        },
        "topology_bridge": {
            "packed_chain_map_json": packed_chain_map_json,
            "component_index_map_json": component_index_map_json,
            "topology_prep_manifest_json": topology_prep_manifest_json,
            "external_ff_notes_txt": external_ff_notes_txt,
        },
        "handoff_exports": {
            "export_manifest_json": export_manifest_json,
            "handoff_notes_txt": handoff_notes_txt,
            "workflow_summary_json": workflow_summary_json,
            "bundle_checksums_json": bundle_checksums_json,
            "export_archive_targz": export_archive_targz,
            "export_bundle_dir": export_bundle_dir,
        },
    }