from __future__ import annotations

from typing import Dict


def build_export_descriptor(
    *,
    system_name: str,
    molecule_label: str,
    normalized_residue_name: str,
    n_chains: int,
    chain_atom_count: int,
    total_atom_count: int,
    charge_method_used: str | None,
) -> Dict:
    return {
        "descriptor_type": "export_descriptor_v1",
        "system_name": system_name,
        "molecule_label": molecule_label,
        "normalized_residue_name": normalized_residue_name,
        "n_chains": n_chains,
        "chain_atom_count": chain_atom_count,
        "total_atom_count": total_atom_count,
        "charge_method_used": charge_method_used,
        "supported_downstream_targets": [
            "generic_handoff",
            "gromacs_handoff",
        ],
        "current_scope": {
            "coordinates_prepared": True,
            "copy_bookkeeping_prepared": True,
            "topology_bridge_prepared": True,
            "production_topology_included": False,
            "simulation_execution_inputs_included": False,
        },
    }