from __future__ import annotations

import hashlib
import tarfile
from pathlib import Path
from typing import Dict

from polymer_tool.core.assembly.manifests import write_json
from polymer_tool.core.validators import require_nonempty_file


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def export_generic_handoff(
    *,
    system_manifest_json: str,
    components_json: str,
    prep_report_json: str,
    packed_pdb: str,
    chain_parameterized_sdf: str,
    out_dir: str,
    bundle_name: str,
) -> Dict[str, str]:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    bundle_dir = out_path / "bundle"
    bundle_dir.mkdir(parents=True, exist_ok=True)

    system_manifest = require_nonempty_file(system_manifest_json, "system_manifest")
    components = require_nonempty_file(components_json, "components_json")
    prep_report = require_nonempty_file(prep_report_json, "prep_report")
    packed = require_nonempty_file(packed_pdb, "packed_pdb")
    chain_sdf = require_nonempty_file(chain_parameterized_sdf, "chain_parameterized_sdf")

    files_to_copy = {
        "system_manifest.json": Path(system_manifest),
        "components.json": Path(components),
        "prep_report.json": Path(prep_report),
        "packed_nanoparticle.pdb": Path(packed),
        "chain_parameterized.sdf": Path(chain_sdf),
    }

    bundle_files: Dict[str, Path] = {}

    for name, src in files_to_copy.items():
        dst = bundle_dir / name
        dst.write_bytes(src.read_bytes())
        bundle_files[name] = dst

    manifest = {
        "export_type": "generic_handoff_v1",
        "bundle_name": bundle_name,
        "files": {k: str(v) for k, v in bundle_files.items()},
        "notes": [
            "Engine-agnostic handoff bundle.",
            "Suitable for GROMACS, OpenMM, or custom workflows.",
            "Final topology generation must be completed externally.",
        ],
    }

    manifest_path = out_path / "generic_export_manifest.json"
    write_json(manifest, manifest_path)

    notes_path = out_path / "generic_handoff_notes.txt"
    notes_path.write_text(
        "\n".join(
            [
                "Generic handoff bundle",
                "======================",
                "",
                "This package contains:",
                "- packed coordinates",
                "- single-chain parameterized structure",
                "- system manifests and bookkeeping",
                "",
                "This bundle is NOT a finished simulation system.",
                "You must generate topology/force-field externally.",
            ]
        ),
        encoding="utf-8",
    )

    checksums = {name: _sha256(path) for name, path in bundle_files.items()}

    checksum_path = out_path / "generic_bundle_checksums.json"
    write_json(
        {
            "checksum_type": "sha256",
            "files": checksums,
        },
        checksum_path,
    )

    archive_path = out_path / f"{bundle_name}.tar.gz"
    with tarfile.open(archive_path, "w:gz") as tar:
        tar.add(bundle_dir, arcname="bundle")

    require_nonempty_file(manifest_path, "generic export manifest")
    require_nonempty_file(notes_path, "generic handoff notes")
    require_nonempty_file(checksum_path, "generic bundle checksums")
    require_nonempty_file(archive_path, "generic archive")

    return {
        "generic_bundle_dir": str(bundle_dir),
        "generic_export_manifest_json": str(manifest_path),
        "generic_handoff_notes_txt": str(notes_path),
        "generic_bundle_checksums_json": str(checksum_path),
        "generic_archive_targz": str(archive_path),
    }