from __future__ import annotations

from pathlib import Path
import json
import numpy as np


def _read_pdb_coords_by_chain(pdb_path: str):
    chains = {}

    with open(pdb_path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith(("ATOM", "HETATM")):
                cid = line[21]
                x = float(line[30:38])
                y = float(line[38:46])
                z = float(line[46:54])

                chains.setdefault(cid, []).append([x, y, z])

    return {k: np.array(v) for k, v in chains.items()}


def _rg(coords):
    center = coords.mean(axis=0)
    return float(np.sqrt(((coords - center) ** 2).sum(axis=1).mean()))


def _radial_stats(coords):
    center = coords.mean(axis=0)
    r = np.linalg.norm(coords - center, axis=1)
    return {
        "r10": float(np.percentile(r, 10)),
        "r50": float(np.percentile(r, 50)),
        "r90": float(np.percentile(r, 90)),
    }


def _interchain_contacts(chains):
    chain_ids = list(chains.keys())
    thresholds = [2.0, 2.5, 3.0, 4.0]

    counts = {str(t): 0 for t in thresholds}
    min_dist = float("inf")

    for i in range(len(chain_ids)):
        for j in range(i + 1, len(chain_ids)):
            a = chains[chain_ids[i]]
            b = chains[chain_ids[j]]

            d = np.linalg.norm(a[:, None, :] - b[None, :, :], axis=2)

            min_dist = min(min_dist, float(d.min()))

            for t in thresholds:
                counts[str(t)] += int((d < t).sum())

    return min_dist, counts


def _classify_structure(
    rg: float,
    radius: float,
    radial: dict,
    min_dist: float,
) -> tuple[str, str]:
    """
    Returns:
        (structural_regime, assessment_label)
    """

    if radius <= 0:
        return "unknown", "invalid"

    rg_ratio = rg / radius
    radial_spread = radial["r90"] - radial["r10"]

    # Hard failure
    if min_dist < 1.5:
        return "invalid", "overcompressed"

    # Regime classification (scale-aware)
    if rg_ratio < 0.60:
        regime = "compact"
    elif rg_ratio < 0.80:
        regime = "intermediate"
    else:
        regime = "loose"

    # Morphology refinement
    if regime == "compact" and radial_spread < 10.0:
        label = "compact_precollapse"
    elif regime == "intermediate":
        label = "intermediate_precollapse"
    else:
        label = "loose_precollapse"

    return regime, label


def run_packing_assessment(
    pdb_path: str,
    output_dir: str,
    packing_report_json: str | None = None,
):
    selected_radius = None

    if packing_report_json:
        with open(packing_report_json, encoding="utf-8") as fh:
            packing_report = json.load(fh)

        selected_radius = (
            packing_report.get("radius_angstrom")
            or packing_report.get("selected_attempt", {}).get("radius_angstrom")
        )

    chains = _read_pdb_coords_by_chain(pdb_path)

    all_coords = np.concatenate(list(chains.values()), axis=0)

    rg = _rg(all_coords)
    radial = _radial_stats(all_coords)

    min_dist, contact_counts = _interchain_contacts(chains)

    chain_centroids = {
        cid: coords.mean(axis=0).tolist()
        for cid, coords in chains.items()
    }

    center = all_coords.mean(axis=0)

    chain_radii = {
        cid: float(np.linalg.norm(np.array(c) - center))
        for cid, c in chain_centroids.items()
    }

    regime, label = _classify_structure(
        rg=rg,
        radius=float(selected_radius) if selected_radius is not None else 0.0,
        radial=radial,
        min_dist=min_dist,
    )

    rg_radius_ratio = (rg / float(selected_radius)) if selected_radius else None
    radial_spread_angstrom = radial["r90"] - radial["r10"]

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    report = {
        "n_chains": len(chains),
        "rg_angstrom": rg,
        "selected_radius_angstrom": float(selected_radius) if selected_radius is not None else None,
        "rg_radius_ratio": rg_radius_ratio,
        "radial_spread_angstrom": radial_spread_angstrom,
        "radial_distribution": radial,
        "min_interchain_distance": min_dist,
        "contact_counts": contact_counts,
        "chain_centroids": chain_centroids,
        "chain_radii": chain_radii,
        "structural_regime": regime,
        "assessment_label": label,
    }

    report_path = out_dir / "packing_assessment.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    return report