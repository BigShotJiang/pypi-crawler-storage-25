from __future__ import annotations

import hashlib
import json
import tarfile
from pathlib import Path
from typing import Dict

from polymer_tool.core.exporters.handoff import (
    copy_file,
    ensure_dir,
    write_json,
    write_text,
)
from polymer_tool.core.validators import require_nonempty_file


def _read_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _build_handoff_notes(
    *,
    system_name: str,
    molecule_label: str,
    n_chains: int,
    chain_atom_count: int,
    total_atom_count: int,
    charge_method_used: str | None,
) -> str:
    return f"""GROMACS handoff bundle
======================

System name: {system_name}
Molecule label: {molecule_label}
Number of chains: {n_chains}
Atoms per chain: {chain_atom_count}
Total atoms: {total_atom_count}
Charge method recorded: {charge_method_used}

Contents
--------
- packed_nanoparticle.pdb
  Packed coordinate file for the assembled PLGA nanoparticle model.

- chain_parameterized.sdf
  Single-chain parameterized structure record with first-pass molecular metadata.

- system_manifest.json
  High-level system bookkeeping.

- components.json
  Component-level system composition.

- prep_report.json
  Sanity diagnostics for the packed assembly.

- export_manifest.json
  Handoff bundle summary and file inventory.

- bundle_checksums.json
  SHA256 checksums for the exported bundle files.

- workflow_summary.json
  Compact summary of the prepared system and export content.

Important notes
---------------
1. This bundle is intended for downstream GROMACS-oriented preparation.
2. Coordinates and bookkeeping are prepared here, but final production topology
   generation is still expected to be completed externally.
3. The current parameterization stage records first-pass charge metadata and
   molecule-level preparation information; it does not yet emit a final GROMACS
   topology.
4. Atom-count consistency has already been checked at the assembly stage.

Suggested downstream use
------------------------
- Inspect packed_nanoparticle.pdb visually.
- Use the single-chain parameterized structure and manifests as inputs for your
  external topology/force-field workflow.
- Preserve these JSON manifests alongside any externally generated .top/.itp/.gro files
  so provenance remains explicit.
"""


def export_gromacs_handoff(
    *,
    system_manifest_json: str,
    components_json: str,
    prep_report_json: str,
    packed_pdb: str,
    chain_parameterized_sdf: str,
    out_dir: str,
    bundle_name: str = "gromacs_handoff_bundle",
) -> Dict[str, str]:
    out_path = ensure_dir(out_dir)
    bundle_dir = ensure_dir(Path(out_path) / "bundle")

    system_manifest_path = require_nonempty_file(system_manifest_json, "system manifest JSON")
    components_path = require_nonempty_file(components_json, "components JSON")
    prep_report_path = require_nonempty_file(prep_report_json, "prep report JSON")
    packed_pdb_path = require_nonempty_file(packed_pdb, "packed nanoparticle PDB")
    chain_param_sdf_path = require_nonempty_file(
        chain_parameterized_sdf, "parameterized chain SDF"
    )

    system_manifest = _read_json(system_manifest_path)
    _ = _read_json(components_path)
    _ = _read_json(prep_report_path)

    copied_packed_pdb = copy_file(packed_pdb_path, bundle_dir / "packed_nanoparticle.pdb")
    copied_chain_sdf = copy_file(chain_param_sdf_path, bundle_dir / "chain_parameterized.sdf")
    copied_system_manifest = copy_file(system_manifest_path, bundle_dir / "system_manifest.json")
    copied_components = copy_file(components_path, bundle_dir / "components.json")
    copied_prep_report = copy_file(prep_report_path, bundle_dir / "prep_report.json")

    export_manifest = {
        "export_type": "gromacs_handoff_v1",
        "bundle_name": bundle_name,
        "system_name": system_manifest.get("system_name"),
        "molecule_label": system_manifest.get("molecule_label"),
        "n_chains": system_manifest.get("n_chains"),
        "chain_atom_count": system_manifest.get("chain_atom_count"),
        "total_atom_count": system_manifest.get("total_atom_count"),
        "charge_method_used": system_manifest.get("charge_method_used"),
        "identity_normalization": {
            "normalized_residue_name": "PLG",
            "molecule_label": system_manifest.get("molecule_label"),
            "packed_pdb_identifiers_normalized": True,
        },
        "bundle_dir": str(bundle_dir),
        "files": {
            "packed_nanoparticle_pdb": copied_packed_pdb,
            "chain_parameterized_sdf": copied_chain_sdf,
            "system_manifest_json": copied_system_manifest,
            "components_json": copied_components,
            "prep_report_json": copied_prep_report,
        },
        "notes": [
            "This bundle is intended for downstream GROMACS-oriented preparation.",
            "Final production topology generation is expected to be completed externally.",
            "The included JSON manifests should be kept with downstream-generated files.",
        ],
    }

    workflow_summary = {
        "summary_type": "workflow_summary_v1",
        "system_name": system_manifest.get("system_name"),
        "molecule_label": system_manifest.get("molecule_label"),
        "normalized_residue_name": "PLG",
        "export_type": "gromacs_handoff_v1",
        "n_chains": system_manifest.get("n_chains"),
        "chain_atom_count": system_manifest.get("chain_atom_count"),
        "total_atom_count": system_manifest.get("total_atom_count"),
        "charge_method_used": system_manifest.get("charge_method_used"),
        "bundle_name": bundle_name,
    }

    notes_text = _build_handoff_notes(
        system_name=str(system_manifest.get("system_name")),
        molecule_label=str(system_manifest.get("molecule_label")),
        n_chains=int(system_manifest.get("n_chains")),
        chain_atom_count=int(system_manifest.get("chain_atom_count")),
        total_atom_count=int(system_manifest.get("total_atom_count")),
        charge_method_used=system_manifest.get("charge_method_used"),
    )

    export_manifest_json = Path(out_path) / "export_manifest.json"
    handoff_notes_txt = Path(out_path) / "handoff_notes.txt"
    workflow_summary_json = Path(out_path) / "workflow_summary.json"
    checksums_json = Path(out_path) / "bundle_checksums.json"

    bundle_export_manifest_json = bundle_dir / "export_manifest.json"
    bundle_handoff_notes_txt = bundle_dir / "handoff_notes.txt"
    bundle_workflow_summary_json = bundle_dir / "workflow_summary.json"

    write_json(export_manifest, export_manifest_json)
    write_text(notes_text, handoff_notes_txt)
    write_json(workflow_summary, workflow_summary_json)

    write_json(export_manifest, bundle_export_manifest_json)
    write_text(notes_text, bundle_handoff_notes_txt)
    write_json(workflow_summary, bundle_workflow_summary_json)

    checksum_payload = {
        "checksum_type": "sha256",
        "bundle_dir": str(bundle_dir),
        "files": {
            "packed_nanoparticle.pdb": _sha256_file(copied_packed_pdb),
            "chain_parameterized.sdf": _sha256_file(copied_chain_sdf),
            "system_manifest.json": _sha256_file(copied_system_manifest),
            "components.json": _sha256_file(copied_components),
            "prep_report.json": _sha256_file(copied_prep_report),
            "export_manifest.json": _sha256_file(bundle_export_manifest_json),
            "handoff_notes.txt": _sha256_file(bundle_handoff_notes_txt),
            "workflow_summary.json": _sha256_file(bundle_workflow_summary_json),
        },
    }

    write_json(checksum_payload, checksums_json)
    bundle_checksums_json = bundle_dir / "bundle_checksums.json"
    write_json(checksum_payload, bundle_checksums_json)

    archive_path = Path(out_path) / f"{bundle_name}.tar.gz"
    with tarfile.open(archive_path, "w:gz") as tar:
        tar.add(bundle_dir, arcname=bundle_name)

    require_nonempty_file(export_manifest_json, "export manifest JSON")
    require_nonempty_file(handoff_notes_txt, "handoff notes text")
    require_nonempty_file(workflow_summary_json, "workflow summary JSON")
    require_nonempty_file(checksums_json, "bundle checksums JSON")
    require_nonempty_file(archive_path, "handoff archive")

    return {
        "export_manifest_json": str(export_manifest_json),
        "handoff_notes_txt": str(handoff_notes_txt),
        "workflow_summary_json": str(workflow_summary_json),
        "bundle_checksums_json": str(checksums_json),
        "export_archive_targz": str(archive_path),
        "export_bundle_dir": str(bundle_dir),
    }