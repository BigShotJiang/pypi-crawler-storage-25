from __future__ import annotations

import json
import os
import platform
import re
import shlex
from copy import deepcopy
from datetime import datetime
from importlib.resources import files
from pathlib import Path
from typing import Any

from polymer_tool.config_loader import load_json_config, validate_workflow_config
from polymer_tool.pipeline.context import PipelineContext
from polymer_tool.pipeline.models import RunRecord
from polymer_tool.pipeline.registry import build_pack_workflow
from polymer_tool.pipeline.runner import PipelineRunner

def generate_chain_ensemble(**kwargs):
    from polymer_tool.ensemble import generate_chain_ensemble as _generate_chain_ensemble
    return _generate_chain_ensemble(**kwargs)


def generate_nanoparticle_ensemble(**kwargs):
    from polymer_tool.ensemble import (
        generate_nanoparticle_ensemble as _generate_nanoparticle_ensemble,
    )
    return _generate_nanoparticle_ensemble(**kwargs)

REPO_CONFIG_DIR = Path("config")
REPO_PRESET_DIR = REPO_CONFIG_DIR / "presets"


def _package_config_root():
    return files("polymer_tool").joinpath("data", "config")


def _package_preset_root():
    return _package_config_root().joinpath("presets")


def _load_json_from_resource(resource, label: str) -> dict[str, Any]:
    try:
        text = resource.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Packaged config resource not found: {label}") from exc

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Failed to parse packaged JSON config {label}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"Top-level packaged config must be a JSON object: {label}")

    return data


def available_presets() -> list[str]:
    names: set[str] = set()

    if REPO_PRESET_DIR.exists():
        names.update(p.stem for p in REPO_PRESET_DIR.glob("*.json"))

    package_presets = _package_preset_root()
    try:
        for item in package_presets.iterdir():
            if item.is_file() and item.name.endswith(".json"):
                names.add(Path(item.name).stem)
    except FileNotFoundError:
        pass

    return sorted(names)


def _load_default_config() -> dict[str, Any]:
    repo_default = REPO_CONFIG_DIR / "default_workflow.json"
    if repo_default.exists():
        return load_json_config(repo_default)

    resource = _package_config_root().joinpath("default_workflow.json")
    return _load_json_from_resource(
        resource,
        "polymer_tool:data/config/default_workflow.json",
    )


def _load_preset_config(preset_name: str) -> dict[str, Any]:
    repo_preset = REPO_PRESET_DIR / f"{preset_name}.json"
    if repo_preset.exists():
        return load_json_config(repo_preset)

    resource = _package_preset_root().joinpath(f"{preset_name}.json")
    if not resource.is_file():
        known = ", ".join(available_presets())
        raise FileNotFoundError(
            f"Preset not found: {preset_name}. Available presets: {known}"
        )

    return _load_json_from_resource(
        resource,
        f"polymer_tool:data/config/presets/{preset_name}.json",
    )


def resolve_config_data(
    config_arg: str | None = None,
    preset_arg: str | None = None,
) -> dict[str, Any]:
    if config_arg:
        return load_json_config(Path(config_arg))

    if preset_arg:
        return _load_preset_config(preset_arg)

    return _load_default_config()


def generate_default_run_id(preset: str | None) -> str:
    ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    if preset:
        return f"{ts}_{preset}"
    return f"{ts}_run"


def generate_base_dir(project_name: str, run_id: str) -> str:
    return f"projects/{project_name}/runs/{run_id}"


def _ensure_section(workflow_config: dict[str, Any], section: str) -> dict[str, Any]:
    value = workflow_config.get(section)
    if not isinstance(value, dict):
        value = {}
        workflow_config[section] = value
    return value


def _sanitize_positive_float(value: Any, *, default: float) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return float(default)
    if parsed <= 0:
        return float(default)
    return parsed


def _sanitize_positive_int(value: Any, *, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return int(default)
    if parsed <= 0:
        return int(default)
    return parsed


def _sanitize_positive_float_list(value: Any, *, default: list[float]) -> list[float]:
    if value is None:
        return list(default)

    if isinstance(value, (list, tuple)):
        cleaned: list[float] = []
        for item in value:
            try:
                parsed = float(item)
            except (TypeError, ValueError):
                continue
            if parsed > 0:
                cleaned.append(parsed)
        if cleaned:
            return cleaned

    return list(default)


def sanitize_workflow_config(
    workflow_config: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    wf = workflow_config
    notes: list[str] = []

    pack_cfg = _ensure_section(wf, "pack_nanoparticle")

    if "radius_mode" not in pack_cfg or pack_cfg["radius_mode"] in (None, ""):
        pack_cfg["radius_mode"] = "manual"

    if pack_cfg["radius_mode"] not in {"manual", "density_based"}:
        notes.append(
            f"Adjusted pack_nanoparticle.radius_mode from {pack_cfg['radius_mode']!r} to 'manual'."
        )
        pack_cfg["radius_mode"] = "manual"

    old_precision = pack_cfg.get("packmol_precision")
    new_precision = _sanitize_positive_int(old_precision, default=2)
    if old_precision != new_precision:
        notes.append(
            f"Adjusted pack_nanoparticle.packmol_precision from {old_precision!r} to {new_precision}."
        )
    pack_cfg["packmol_precision"] = new_precision

    old_discale = pack_cfg.get("packmol_discale")
    new_discale = _sanitize_positive_float(old_discale, default=1.5)
    if old_discale != new_discale:
        notes.append(
            f"Adjusted pack_nanoparticle.packmol_discale from {old_discale!r} to {new_discale}."
        )
    pack_cfg["packmol_discale"] = new_discale

    old_tolerance = pack_cfg.get("tolerance")
    new_tolerance = _sanitize_positive_float(old_tolerance, default=2.0)
    if old_tolerance != new_tolerance:
        notes.append(
            f"Adjusted pack_nanoparticle.tolerance from {old_tolerance!r} to {new_tolerance}."
        )
    pack_cfg["tolerance"] = new_tolerance

    old_maxit = pack_cfg.get("packmol_maxit")
    new_maxit = _sanitize_positive_int(old_maxit, default=200)
    if old_maxit != new_maxit:
        notes.append(
            f"Adjusted pack_nanoparticle.packmol_maxit from {old_maxit!r} to {new_maxit}."
        )
    pack_cfg["packmol_maxit"] = new_maxit

    old_nloop = pack_cfg.get("packmol_nloop")
    new_nloop = _sanitize_positive_int(old_nloop, default=2000)
    if old_nloop != new_nloop:
        notes.append(
            f"Adjusted pack_nanoparticle.packmol_nloop from {old_nloop!r} to {new_nloop}."
        )
    pack_cfg["packmol_nloop"] = new_nloop

    old_movefrac = pack_cfg.get("packmol_movefrac")
    new_movefrac = _sanitize_positive_float(old_movefrac, default=0.05)
    if old_movefrac != new_movefrac:
        notes.append(
            f"Adjusted pack_nanoparticle.packmol_movefrac from {old_movefrac!r} to {new_movefrac}."
        )
    pack_cfg["packmol_movefrac"] = new_movefrac

    old_target_density = pack_cfg.get("target_density_g_cm3")
    new_target_density = _sanitize_positive_float(old_target_density, default=1.25)
    if old_target_density != new_target_density:
        notes.append(
            f"Adjusted pack_nanoparticle.target_density_g_cm3 from {old_target_density!r} to {new_target_density}."
        )
    pack_cfg["target_density_g_cm3"] = new_target_density

    old_packing_slack = pack_cfg.get("packing_slack_factor")
    new_packing_slack = _sanitize_positive_float(old_packing_slack, default=1.25)
    if old_packing_slack != new_packing_slack:
        notes.append(
            f"Adjusted pack_nanoparticle.packing_slack_factor from {old_packing_slack!r} to {new_packing_slack}."
        )
    pack_cfg["packing_slack_factor"] = new_packing_slack

    old_chain_size_factor = pack_cfg.get("chain_size_factor")
    new_chain_size_factor = _sanitize_positive_float(
        old_chain_size_factor,
        default=1.20,
    )
    if old_chain_size_factor != new_chain_size_factor:
        notes.append(
            f"Adjusted pack_nanoparticle.chain_size_factor from {old_chain_size_factor!r} to {new_chain_size_factor}."
        )
    pack_cfg["chain_size_factor"] = new_chain_size_factor

    old_retry_scales = pack_cfg.get("retry_scale_factors")
    new_retry_scales = _sanitize_positive_float_list(
        old_retry_scales,
        default=[1.0, 1.2, 1.5, 2.0],
    )
    if old_retry_scales != new_retry_scales:
        notes.append(
            f"Adjusted pack_nanoparticle.retry_scale_factors from {old_retry_scales!r} to {new_retry_scales!r}."
        )
    pack_cfg["retry_scale_factors"] = new_retry_scales

    if pack_cfg.get("minimum_radius_angstrom") is not None:
        old_min_radius = pack_cfg.get("minimum_radius_angstrom")
        try:
            parsed_min_radius = float(old_min_radius)
            if parsed_min_radius <= 0:
                notes.append(
                    f"Adjusted pack_nanoparticle.minimum_radius_angstrom from {old_min_radius!r} to None."
                )
                pack_cfg["minimum_radius_angstrom"] = None
            else:
                pack_cfg["minimum_radius_angstrom"] = parsed_min_radius
        except (TypeError, ValueError):
            notes.append(
                f"Adjusted pack_nanoparticle.minimum_radius_angstrom from {old_min_radius!r} to None."
            )
            pack_cfg["minimum_radius_angstrom"] = None

    if pack_cfg.get("radius_angstrom") is not None:
        old_radius = pack_cfg.get("radius_angstrom")
        try:
            parsed_radius = float(old_radius)
            if parsed_radius <= 0:
                notes.append(
                    f"Adjusted pack_nanoparticle.radius_angstrom from {old_radius!r} to None."
                )
                pack_cfg["radius_angstrom"] = None
            else:
                pack_cfg["radius_angstrom"] = parsed_radius
        except (TypeError, ValueError):
            notes.append(
                f"Adjusted pack_nanoparticle.radius_angstrom from {old_radius!r} to None."
            )
            pack_cfg["radius_angstrom"] = None

    return wf, notes


def apply_overrides(
    workflow_config: dict[str, Any],
    overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    wf = deepcopy(workflow_config)
    overrides = overrides or {}

    build_chain_cfg = _ensure_section(wf, "build_chain")
    parameterize_chain_cfg = _ensure_section(wf, "parameterize_chain")
    pack_cfg = _ensure_section(wf, "pack_nanoparticle")
    assemble_cfg = _ensure_section(wf, "assemble_system")
    export_gromacs_cfg = _ensure_section(wf, "export_gromacs_handoff")
    export_generic_cfg = _ensure_section(wf, "export_generic_handoff")

    if overrides.get("dp") is not None:
        build_chain_cfg["dp"] = overrides["dp"]
    if overrides.get("lactic_fraction") is not None:
        build_chain_cfg["lactic_fraction"] = overrides["lactic_fraction"]
    if overrides.get("stereo_pattern") is not None:
        build_chain_cfg["stereo_pattern"] = overrides["stereo_pattern"]
    if overrides.get("end_group") is not None:
        build_chain_cfg["end_group"] = overrides["end_group"]
    if overrides.get("sequence_mode") is not None:
        build_chain_cfg["sequence_mode"] = overrides["sequence_mode"]
    if overrides.get("random_seed") is not None:
        build_chain_cfg["random_seed"] = overrides["random_seed"]

    if overrides.get("charge_method") is not None:
        parameterize_chain_cfg["charge_method"] = overrides["charge_method"]
    if overrides.get("forcefield") is not None:
        parameterize_chain_cfg["forcefield"] = overrides["forcefield"]

    if overrides.get("n_chains") is not None:
        pack_cfg["n_chains"] = overrides["n_chains"]
    if overrides.get("shape") is not None:
        pack_cfg["shape"] = overrides["shape"]
    if overrides.get("radius_angstrom") is not None:
        pack_cfg["radius_angstrom"] = overrides["radius_angstrom"]
    if overrides.get("radius_mode") is not None:
        pack_cfg["radius_mode"] = overrides["radius_mode"]
    if overrides.get("target_density_g_cm3") is not None:
        pack_cfg["target_density_g_cm3"] = overrides["target_density_g_cm3"]
    if overrides.get("packing_slack_factor") is not None:
        pack_cfg["packing_slack_factor"] = overrides["packing_slack_factor"]
    if overrides.get("minimum_radius_angstrom") is not None:
        pack_cfg["minimum_radius_angstrom"] = overrides["minimum_radius_angstrom"]
    if overrides.get("retry_scale_factors") is not None:
        pack_cfg["retry_scale_factors"] = overrides["retry_scale_factors"]
    if overrides.get("tolerance") is not None:
        pack_cfg["tolerance"] = overrides["tolerance"]
    if overrides.get("packmol_maxit") is not None:
        pack_cfg["packmol_maxit"] = overrides["packmol_maxit"]
    if overrides.get("packmol_nloop") is not None:
        pack_cfg["packmol_nloop"] = overrides["packmol_nloop"]
    if overrides.get("packmol_movefrac") is not None:
        pack_cfg["packmol_movefrac"] = overrides["packmol_movefrac"]
    if overrides.get("packmol_discale") is not None:
        pack_cfg["packmol_discale"] = overrides["packmol_discale"]
    if overrides.get("packmol_precision") is not None:
        pack_cfg["packmol_precision"] = overrides["packmol_precision"]

    if overrides.get("system_name") is not None:
        assemble_cfg["system_name"] = overrides["system_name"]
    if overrides.get("molecule_label") is not None:
        assemble_cfg["molecule_label"] = overrides["molecule_label"]

    if overrides.get("gromacs_bundle_name") is not None:
        export_gromacs_cfg["bundle_name"] = overrides["gromacs_bundle_name"]
    if overrides.get("generic_bundle_name") is not None:
        export_generic_cfg["bundle_name"] = overrides["generic_bundle_name"]

    return wf


def materialize_workflow_config(
    *,
    config_path: str | None = None,
    preset: str | None = None,
    config_data: dict[str, Any] | None = None,
    overrides: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], list[str]]:
    if config_data is not None:
        raw_config = deepcopy(config_data)
    else:
        raw_config = deepcopy(resolve_config_data(config_path, preset))

    validated = validate_workflow_config(raw_config)
    workflow_config = apply_overrides(validated["workflow_config"], overrides)
    workflow_config, sanitation_notes = sanitize_workflow_config(workflow_config)

    materialized = {
        "project_name": str(validated["project_name"]),
        "workflow_name": str(validated["workflow_name"]),
        "workflow_config": workflow_config,
    }
    return materialized, sanitation_notes


def save_resolved_config(
    out_path: str | Path,
    *,
    config_path: str | None = None,
    preset: str | None = None,
    config_data: dict[str, Any] | None = None,
    overrides: dict[str, Any] | None = None,
) -> str:
    materialized, _notes = materialize_workflow_config(
        config_path=config_path,
        preset=preset,
        config_data=config_data,
        overrides=overrides,
    )

    output_path = Path(out_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(materialized, indent=2), encoding="utf-8")
    return str(output_path)


def _slugify_config_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name.strip())
    cleaned = cleaned.strip("._-")
    if not cleaned:
        raise ValueError("Config name must contain at least one valid character.")
    return cleaned


def default_user_config_root() -> Path:
    system = platform.system()

    if system == "Windows":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "polymer-tool" / "configs"
        return Path.home() / "AppData" / "Roaming" / "polymer-tool" / "configs"

    if system == "Darwin":
        return (
            Path.home()
            / "Library"
            / "Application Support"
            / "polymer-tool"
            / "configs"
        )

    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "polymer-tool" / "configs"
    return Path.home() / ".config" / "polymer-tool" / "configs"


def ensure_user_config_root(config_root: str | Path | None = None) -> Path:
    root = Path(config_root) if config_root is not None else default_user_config_root()
    root.mkdir(parents=True, exist_ok=True)
    return root


def discover_user_configs(
    *,
    config_root: str | Path | None = None,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    root = Path(config_root) if config_root is not None else default_user_config_root()
    if not root.exists():
        return []

    records: list[dict[str, Any]] = []

    for path in root.glob("*.json"):
        if not path.is_file():
            continue

        try:
            data = load_json_config(path)
            validated = validate_workflow_config(deepcopy(data))
        except Exception:
            continue

        mtime = path.stat().st_mtime
        records.append(
            {
                "name": path.stem,
                "path": str(path),
                "project_name": str(validated["project_name"]),
                "workflow_name": str(validated["workflow_name"]),
                "mtime": mtime,
                "mtime_iso": datetime.fromtimestamp(mtime).isoformat(timespec="seconds"),
            }
        )

    records.sort(key=lambda item: (-item["mtime"], item["name"].lower()))
    if limit is not None:
        return records[:limit]
    return records


def save_named_user_config(
    name: str,
    *,
    config_root: str | Path | None = None,
    config_path: str | None = None,
    preset: str | None = None,
    config_data: dict[str, Any] | None = None,
    overrides: dict[str, Any] | None = None,
) -> str:
    root = ensure_user_config_root(config_root)
    filename = _slugify_config_name(name) + ".json"
    out_path = root / filename
    return save_resolved_config(
        out_path,
        config_path=config_path,
        preset=preset,
        config_data=config_data,
        overrides=overrides,
    )


def load_user_config_by_name(
    name: str,
    *,
    config_root: str | Path | None = None,
) -> dict[str, Any]:
    root = ensure_user_config_root(config_root)
    filename = _slugify_config_name(name) + ".json"
    path = root / filename
    if not path.is_file():
        raise FileNotFoundError(f"User config not found: {path}")
    return load_json_config(path)


def _resolve_run_state_path(path_or_run_dir: str | Path) -> Path:
    p = Path(path_or_run_dir)

    if p.is_file():
        return p

    if not p.exists():
        raise FileNotFoundError(f"Run path not found: {p}")

    candidate_paths = [
        p / "state" / "run_state.json",
        p / "run_state.json",
    ]
    for candidate in candidate_paths:
        if candidate.is_file():
            return candidate

    raise FileNotFoundError(
        f"Could not find run_state.json under: {p}"
    )


def load_run_snapshot(path_or_run_dir: str | Path) -> dict[str, Any]:
    state_path = _resolve_run_state_path(path_or_run_dir)

    try:
        payload = json.loads(state_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Failed to parse run state JSON {state_path}: {exc}") from exc

    if not isinstance(payload, dict):
        raise ValueError(f"Run state payload must be a JSON object: {state_path}")

    run = payload.get("run")
    if not isinstance(run, dict):
        raise ValueError(f"Run state missing 'run' object: {state_path}")

    workflow_config = run.get("config")
    if not isinstance(workflow_config, dict):
        raise ValueError(f"Run state missing workflow config: {state_path}")

    return {
        "state_file": str(state_path),
        "run_id": str(run.get("run_id", "")),
        "base_dir": str(run.get("base_dir", state_path.parents[1])),
        "project_name": str(run.get("project_name", "")),
        "workflow_name": str(run.get("workflow_name", "")),
        "workflow_config": deepcopy(workflow_config),
    }


def load_config_from_run_state(path_or_run_dir: str | Path) -> dict[str, Any]:
    snapshot = load_run_snapshot(path_or_run_dir)
    return {
        "project_name": snapshot["project_name"],
        "workflow_name": snapshot["workflow_name"],
        "workflow_config": snapshot["workflow_config"],
    }


def _override_flag_pairs(overrides: dict[str, Any] | None) -> list[tuple[str, Any]]:
    overrides = overrides or {}
    mapping = [
        ("dp", "--dp"),
        ("lactic_fraction", "--lactic-fraction"),
        ("stereo_pattern", "--stereo-pattern"),
        ("end_group", "--end-group"),
        ("sequence_mode", "--sequence-mode"),
        ("random_seed", "--random-seed"),
        ("charge_method", "--charge-method"),
        ("forcefield", "--forcefield"),
        ("n_chains", "--n-chains"),
        ("shape", "--shape"),
        ("radius_angstrom", "--radius"),
        ("radius_mode", "--radius-mode"),
        ("target_density_g_cm3", "--target-density"),
        ("packing_slack_factor", "--packing-slack"),
        ("minimum_radius_angstrom", "--minimum-radius"),
        ("retry_scale_factors", "--retry-scales"),
        ("tolerance", "--packmol-tolerance"),
        ("packmol_maxit", "--packmol-maxit"),
        ("packmol_nloop", "--packmol-nloop"),
        ("packmol_movefrac", "--packmol-movefrac"),
        ("packmol_discale", "--packmol-discale"),
        ("packmol_precision", "--packmol-precision"),
        ("system_name", "--system-name"),
        ("molecule_label", "--molecule-label"),
        ("gromacs_bundle_name", "--gromacs-bundle-name"),
        ("generic_bundle_name", "--generic-bundle-name"),
    ]

    pairs: list[tuple[str, Any]] = []
    for key, flag in mapping:
        if overrides.get(key) is not None:
            pairs.append((flag, overrides[key]))
    return pairs


def build_cli_command_preview(
    *,
    config_path: str | None = None,
    preset: str | None = None,
    config_data: dict[str, Any] | None = None,
    run_id: str | None = None,
    base_dir: str | None = None,
    overrides: dict[str, Any] | None = None,
    ensemble_size: int | None = None,
    ensemble_seed_start: int = 1000,
    ensemble_mode: str = "chain",
) -> str:
    if config_data is not None and not config_path and not preset:
        return (
            "<in-memory config loaded from a recent run; "
            "save current config to JSON to obtain a reproducible CLI command>"
        )

    parts: list[str] = ["polymer-tool"]

    if config_path:
        parts.extend(["--config", config_path])
    elif preset:
        parts.extend(["--preset", preset])

    if run_id:
        parts.extend(["--run-id", run_id])
    if base_dir:
        parts.extend(["--base-dir", base_dir])

    for flag, value in _override_flag_pairs(overrides):
        if flag == "--retry-scales" and isinstance(value, (list, tuple)):
            if value:
                parts.append(flag)
                parts.extend(str(v) for v in value)
        else:
            parts.extend([flag, str(value)])

    if ensemble_size is not None:
        parts.extend(["--ensemble-size", str(ensemble_size)])
        parts.extend(["--ensemble-seed-start", str(ensemble_seed_start)])
        parts.extend(["--ensemble-mode", str(ensemble_mode)])

    return " ".join(shlex.quote(part) for part in parts)


def discover_recent_runs(
    *,
    base_root: str | Path = "projects",
    limit: int = 20,
) -> list[dict[str, Any]]:
    root = Path(base_root)
    if not root.exists():
        return []

    records: list[dict[str, Any]] = []

    for state_file in root.glob("*/runs/*/state/run_state.json"):
        if not state_file.is_file():
            continue

        try:
            payload = json.loads(state_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        run = payload.get("run", {})
        if not isinstance(run, dict):
            continue

        steps = run.get("steps", [])
        last_status = None
        if isinstance(steps, list) and steps:
            last = steps[-1]
            if isinstance(last, dict):
                last_status = last.get("status")

        mtime = state_file.stat().st_mtime
        records.append(
            {
                "project_name": run.get("project_name", state_file.parents[3].name),
                "run_id": run.get("run_id", state_file.parents[1].name),
                "workflow_name": run.get("workflow_name"),
                "base_dir": run.get("base_dir", str(state_file.parents[1])),
                "state_file": str(state_file),
                "last_status": last_status,
                "mtime": mtime,
                "mtime_iso": datetime.fromtimestamp(mtime).isoformat(timespec="seconds"),
            }
        )

    records.sort(key=lambda item: item["mtime"], reverse=True)
    return records[:limit]


def run_workflow_request(
    *,
    config_path: str | None = None,
    preset: str | None = None,
    config_data: dict[str, Any] | None = None,
    run_id: str | None = None,
    base_dir: str | None = None,
    overrides: dict[str, Any] | None = None,
    ensemble_size: int | None = None,
    ensemble_seed_start: int = 1000,
    ensemble_mode: str = "chain",
) -> dict[str, Any]:
    materialized, sanitation_notes = materialize_workflow_config(
        config_path=config_path,
        preset=preset,
        config_data=config_data,
        overrides=overrides,
    )

    project_name = str(materialized["project_name"])
    workflow_name = str(materialized["workflow_name"])
    workflow_config = materialized["workflow_config"]

    resolved_run_id = str(run_id or generate_default_run_id(preset))
    resolved_base_dir = str(base_dir or generate_base_dir(project_name, resolved_run_id))

    if ensemble_size is not None:
        if ensemble_mode == "chain":
            result = generate_chain_ensemble(
                out_dir=resolved_base_dir,
                ensemble_size=int(ensemble_size),
                ensemble_seed_start=int(ensemble_seed_start),
                build_chain_config=workflow_config["build_chain"],
            )
        elif ensemble_mode == "nanoparticle":
            result = generate_nanoparticle_ensemble(
                out_dir=resolved_base_dir,
                ensemble_size=int(ensemble_size),
                ensemble_seed_start=int(ensemble_seed_start),
                build_chain_config=workflow_config["build_chain"],
                parameterize_chain_config=workflow_config["parameterize_chain"],
                pack_nanoparticle_config=workflow_config["pack_nanoparticle"],
            )
        else:
            raise ValueError(
                f"ensemble_mode must be 'chain' or 'nanoparticle', got {ensemble_mode!r}"
            )

        return {
            "mode": "ensemble",
            "preset": preset,
            "config_path": config_path,
            "run_id": resolved_run_id,
            "base_dir": resolved_base_dir,
            "workflow_name": workflow_name,
            "project_name": project_name,
            "sanitation_notes": sanitation_notes,
            "ensemble_mode": ensemble_mode,
            "ensemble_size": int(ensemble_size),
            "ensemble_seed_start": int(ensemble_seed_start),
            "ensemble_manifest_json": result["ensemble_manifest_json"],
            "ensemble_members_dir": result["ensemble_members_dir"],
        }

    run = RunRecord(
        run_id=resolved_run_id,
        project_name=project_name,
        base_dir=resolved_base_dir,
        workflow_name=workflow_name,
        config=workflow_config,
    )

    ctx = PipelineContext(run=run)
    steps = build_pack_workflow(workflow_config)
    runner = PipelineRunner(steps)
    runner.run(ctx)

    return {
        "mode": "pipeline",
        "preset": preset,
        "config_path": config_path,
        "run_id": resolved_run_id,
        "base_dir": resolved_base_dir,
        "workflow_name": workflow_name,
        "project_name": project_name,
        "sanitation_notes": sanitation_notes,
        "state_file": str(ctx.state_dir / "run_state.json"),
        "artifacts": {name: artifact.path for name, artifact in sorted(ctx.artifacts.items())},
    }


def format_run_result(result: dict[str, Any]) -> str:
    lines: list[str] = []

    if result.get("sanitation_notes"):
        lines.append("Workflow config adjustments:")
        for note in result["sanitation_notes"]:
            lines.append(f"  - {note}")
        lines.append("")

    if result["mode"] == "ensemble":
        lines.append(
            f"Ensemble finished. Manifest written to: {result['ensemble_manifest_json']}"
        )
        lines.append(
            f"Ensemble members directory: {result['ensemble_members_dir']}"
        )
        return "\n".join(lines).rstrip()

    lines.append(f"Run finished. State written to: {result['state_file']}")
    lines.append("Artifacts:")
    for name, path in result["artifacts"].items():
        lines.append(f"  - {name}: {path}")
    return "\n".join(lines)


# ============================================================
# NEW API FUNCTIONS FOR TESTS & GUI
# ============================================================


def launch_profiles() -> list[dict[str, Any]]:
    """
    Return available launch profiles.
    """
    presets = available_presets()
    profiles = []
    for preset_name in presets:
        try:
            config = _load_preset_config(preset_name)
            profiles.append({
                "name": preset_name,
                "description": f"Preset: {preset_name}",
                "request": config,
            })
        except Exception:
            continue
    return profiles


def get_launch_profile(name: str) -> dict[str, Any]:
    """
    Get a specific launch profile by name.
    """
    try:
        config = _load_preset_config(name)
        return {
            "name": name,
            "description": f"Preset: {name}",
            "request": config,
        }
    except FileNotFoundError:
        raise ValueError(f"Launch profile not found: {name}")


def preflight_validate_request(
    *,
    config_data: dict[str, Any] | None = None,
    **kwargs,
) -> dict[str, Any]:
    """
    Validate a workflow request before execution.
    Returns {ok: bool, errors: list, warnings: list}
    
    Accepts either config_data explicitly or unpacked config dict.
    """
    errors = []
    warnings = []

    # If config_data not provided, try to extract from kwargs (for unpacked configs)
    if config_data is None:
        if "project_name" in kwargs and "workflow_config" in kwargs:
            # User passed unpacked config as kwargs
            config_data = kwargs
        else:
            errors.append("config_data is required")
            return {"ok": False, "errors": errors, "warnings": warnings}

    try:
        validated = validate_workflow_config(config_data)
    except Exception as e:
        errors.append(f"Config validation failed: {str(e)}")
        return {"ok": False, "errors": errors, "warnings": warnings}

    # Check pack_nanoparticle specific constraints
    pack = validated.get("workflow_config", {}).get("pack_nanoparticle", {})
    if pack.get("radius_mode") == "manual" and not pack.get("radius_angstrom"):
        errors.append(
            "pack_nanoparticle.radius_angstrom is required when radius_mode='manual'"
        )

    # Check ensemble mode if present
    ensemble_mode = kwargs.get("ensemble_mode")
    if ensemble_mode and ensemble_mode not in ("nanoparticle", "chain", None):
        errors.append(f"Invalid ensemble_mode: {ensemble_mode}")

    ok = len(errors) == 0
    return {"ok": ok, "errors": errors, "warnings": warnings}


def compare_materialized_configs(
    left: dict[str, Any],
    right: dict[str, Any],
    *,
    left_label: str = "left",
    right_label: str = "right",
) -> str:
    """
    Compare two materialized configs and return a detailed diff.
    """
    lines = []

    def flatten_dict(d: dict, prefix: str = "") -> dict:
        """Flatten nested dict for comparison."""
        result = {}
        for k, v in d.items():
            key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                result.update(flatten_dict(v, key))
            else:
                result[key] = v
        return result

    left_flat = flatten_dict(left)
    right_flat = flatten_dict(right)

    all_keys = set(left_flat.keys()) | set(right_flat.keys())
    changed = {}
    for key in sorted(all_keys):
        left_val = left_flat.get(key)
        right_val = right_flat.get(key)
        if left_val != right_val:
            changed[key] = (left_val, right_val)

    if not changed:
        return "Configs are identical."

    lines.append("Changed values:")
    for key in sorted(changed.keys()):
        left_val, right_val = changed[key]
        lines.append(f"  {key}:")
        lines.append(f"    {left_label}: {left_val}")
        lines.append(f"    {right_label}: {right_val}")

    return "\n".join(lines)


def format_preflight_report(report: dict[str, Any]) -> str:
    """
    Format a preflight validation report for display.
    """
    lines = []

    if report.get("ok"):
        lines.append("✓ Configuration is valid.")
    else:
        lines.append("✗ Configuration has errors:")
        for error in report.get("errors", []):
            lines.append(f"  - {error}")

    warnings = report.get("warnings", [])
    if warnings:
        lines.append("\nWarnings:")
        for warning in warnings:
            lines.append(f"  - {warning}")

    return "\n".join(lines)


def load_favorite_launch_profiles(
    *,
    state_root: str | Path | None = None,
) -> set[str]:
    """
    Load user's favorite launch profile names.
    """
    if state_root is None:
        state_root = Path.home() / ".polymer-tool"
    else:
        state_root = Path(state_root)

    fav_file = state_root / "favorite_profiles.json"
    if not fav_file.is_file():
        return set()

    try:
        data = json.loads(fav_file.read_text(encoding="utf-8"))
        return set(data.get("favorites", []))
    except Exception:
        return set()


def toggle_favorite_launch_profile(
    name: str,
    *,
    state_root: str | Path | None = None,
) -> set[str]:
    """
    Toggle a launch profile as favorite and return updated set of favorites.
    """
    if state_root is None:
        state_root = Path.home() / ".polymer-tool"
    else:
        state_root = Path(state_root)

    fav_file = state_root / "favorite_profiles.json"
    state_root.mkdir(parents=True, exist_ok=True)

    # Load current favorites
    favorites = list(load_favorite_launch_profiles(state_root=state_root))

    # Toggle
    if name in favorites:
        favorites.remove(name)
    else:
        favorites.append(name)

    # Save
    fav_file.write_text(
        json.dumps({"favorites": sorted(favorites)}, indent=2),
        encoding="utf-8",
    )

    return set(favorites)


def export_request_bundle(
    out_dir: str | Path,
    *,
    preset: str | None = None,
    config_data: dict[str, Any] | None = None,
    overrides: dict[str, Any] | None = None,
    ensemble_size: int | None = None,
    ensemble_mode: str | None = None,
    ensemble_seed_start: int | None = None,
) -> dict[str, Any]:
    """
    Export a request bundle with resolved config and command.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Materialize config
    materialized, _notes = materialize_workflow_config(
        preset=preset,
        config_data=config_data,
        overrides=overrides,
    )

    # Save resolved config
    resolved_config_path = out_dir / "resolved_config.json"
    resolved_config_path.write_text(
        json.dumps(materialized, indent=2),
        encoding="utf-8",
    )

    # Build command
    cmd_parts = ["polymer-tool"]
    if preset:
        cmd_parts += ["--preset", preset]
    if ensemble_size:
        cmd_parts += ["--ensemble-size", str(ensemble_size)]
    if ensemble_mode:
        cmd_parts += ["--ensemble-mode", ensemble_mode]
    if ensemble_seed_start:
        cmd_parts += ["--ensemble-seed-start", str(ensemble_seed_start)]

    command_text = " ".join(cmd_parts)
    command_path = out_dir / "command.txt"
    command_path.write_text(command_text, encoding="utf-8")

    # Create manifest
    manifest = {
        "bundle_dir": str(out_dir),
        "resolved_config_json": str(resolved_config_path),
        "command_txt": str(command_path),
        "timestamp": datetime.now().isoformat(),
    }
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    return {
        "bundle_dir": str(out_dir),
        "resolved_config_json": str(resolved_config_path),
        "command_txt": str(command_path),
        "bundle_manifest_json": str(manifest_path),
    }

    return "\n".join(lines).rstrip()