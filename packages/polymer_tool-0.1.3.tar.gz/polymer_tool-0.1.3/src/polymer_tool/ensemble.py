from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from polymer_tool.core.builder import build_plga_chain
from polymer_tool.core.packmol_runner import pack_nanoparticle
from polymer_tool.core.parameterize import parameterize_chain
from polymer_tool.core.validators import require_nonempty_file


def _write_json(data: Dict[str, Any], path: str | Path) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(p)


def _pick_result_path(result: Dict[str, str], *candidate_keys: str) -> str:
    for key in candidate_keys:
        value = result.get(key)
        if value:
            return str(value)
    raise KeyError(
        "None of the expected result keys were found. "
        f"Tried: {candidate_keys}. Available keys: {sorted(result.keys())}"
    )


def _to_optional_float(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)


def _to_positive_float_list(
    value: Any,
    *,
    default: list[float],
) -> list[float]:
    if value is None:
        return list(default)

    if isinstance(value, (list, tuple)):
        cleaned: list[float] = []
        for item in value:
            parsed = float(item)
            if parsed > 0:
                cleaned.append(parsed)
        if cleaned:
            return cleaned

    return list(default)


def _normalized_build_chain_config(build_chain_config: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "dp": int(build_chain_config["dp"]),
        "lactic_fraction": float(build_chain_config.get("lactic_fraction", 0.5)),
        "stereo_pattern": str(build_chain_config.get("stereo_pattern", "alt_RS")),
        "end_group": str(build_chain_config.get("end_group", "ester")),
        "sequence_mode": str(build_chain_config.get("sequence_mode", "balanced")),
    }


def _normalized_parameterize_chain_config(
    parameterize_chain_config: Dict[str, Any],
) -> Dict[str, Any]:
    return {
        "charge_method": str(parameterize_chain_config.get("charge_method", "auto")),
        "forcefield": str(parameterize_chain_config.get("forcefield", "openff-2.3.0")),
    }


def _normalized_pack_nanoparticle_config(
    pack_nanoparticle_config: Dict[str, Any],
) -> Dict[str, Any]:
    return {
        "n_chains": int(pack_nanoparticle_config["n_chains"]),
        "shape": str(pack_nanoparticle_config.get("shape", "sphere")),
        "radius_mode": str(pack_nanoparticle_config.get("radius_mode", "manual")),
        "radius_angstrom": _to_optional_float(
            pack_nanoparticle_config.get("radius_angstrom")
        ),
        "target_density_g_cm3": float(
            pack_nanoparticle_config.get("target_density_g_cm3", 1.25)
        ),
        "packing_slack_factor": float(
            pack_nanoparticle_config.get("packing_slack_factor", 1.25)
        ),
        "chain_size_factor": float(
            pack_nanoparticle_config.get("chain_size_factor", 1.20)
        ),
        "minimum_radius_angstrom": _to_optional_float(
            pack_nanoparticle_config.get("minimum_radius_angstrom")
        ),
        "tolerance": float(pack_nanoparticle_config.get("tolerance", 2.0)),
        "packmol_seed": pack_nanoparticle_config.get("packmol_seed"),
        "retry_scale_factors": _to_positive_float_list(
            pack_nanoparticle_config.get("retry_scale_factors"),
            default=[1.0, 1.2, 1.5, 2.0],
        ),
        "packmol_maxit": int(pack_nanoparticle_config.get("packmol_maxit", 200)),
        "packmol_nloop": int(pack_nanoparticle_config.get("packmol_nloop", 2000)),
        "packmol_movefrac": float(pack_nanoparticle_config.get("packmol_movefrac", 0.05)),
        "packmol_discale": float(pack_nanoparticle_config.get("packmol_discale", 1.5)),
        "packmol_precision": int(pack_nanoparticle_config.get("packmol_precision", 2)),
    }


def generate_chain_ensemble(
    *,
    out_dir: str,
    ensemble_size: int,
    ensemble_seed_start: int,
    build_chain_config: Dict[str, Any],
) -> Dict[str, str]:
    if ensemble_size <= 0:
        raise ValueError(f"ensemble_size must be > 0, got {ensemble_size}")
    if ensemble_seed_start < 0:
        raise ValueError(
            f"ensemble_seed_start must be >= 0, got {ensemble_seed_start}"
        )

    normalized_build_cfg = _normalized_build_chain_config(build_chain_config)

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    members_dir = out_path / "ensemble_members"
    members_dir.mkdir(parents=True, exist_ok=True)

    member_records: List[Dict[str, Any]] = []

    for idx in range(ensemble_size):
        member_index = idx + 1
        seed = ensemble_seed_start + idx

        member_dir = members_dir / f"member_{member_index:04d}"
        member_dir.mkdir(parents=True, exist_ok=True)

        result = build_plga_chain(
            dp=normalized_build_cfg["dp"],
            lactic_fraction=normalized_build_cfg["lactic_fraction"],
            stereo_pattern=normalized_build_cfg["stereo_pattern"],
            end_group=normalized_build_cfg["end_group"],
            sequence_mode=normalized_build_cfg["sequence_mode"],
            random_seed=seed,
            out_prefix=str(member_dir / "chain"),
        )

        chain_json = _pick_result_path(result, "json", "chain_json")
        chain_pdb = _pick_result_path(result, "pdb", "chain_pdb")
        chain_sdf = _pick_result_path(result, "sdf", "chain_sdf")

        require_nonempty_file(chain_json, f"ensemble member {member_index} chain json")
        require_nonempty_file(chain_pdb, f"ensemble member {member_index} chain pdb")
        require_nonempty_file(chain_sdf, f"ensemble member {member_index} chain sdf")

        member_records.append(
            {
                "member_index": member_index,
                "member_name": f"member_{member_index:04d}",
                "random_seed": seed,
                "files": {
                    "chain_json": chain_json,
                    "chain_pdb": chain_pdb,
                    "chain_sdf": chain_sdf,
                },
            }
        )

    manifest = {
        "ensemble_type": "chain_ensemble_v1",
        "ensemble_size": ensemble_size,
        "ensemble_seed_start": ensemble_seed_start,
        "build_chain_config": normalized_build_cfg,
        "members": member_records,
        "notes": [
            "This ensemble contains independently generated PLGA chain realizations.",
            "Each member uses the same chain-build settings except for the member seed.",
            "This ensemble mode generates chains only and does not pack nanoparticles.",
        ],
    }

    manifest_path = out_path / "ensemble_manifest.json"
    _write_json(manifest, manifest_path)
    require_nonempty_file(manifest_path, "ensemble manifest")

    return {
        "ensemble_manifest_json": str(manifest_path),
        "ensemble_members_dir": str(members_dir),
    }


def generate_nanoparticle_ensemble(
    *,
    out_dir: str,
    ensemble_size: int,
    ensemble_seed_start: int,
    build_chain_config: Dict[str, Any],
    parameterize_chain_config: Dict[str, Any],
    pack_nanoparticle_config: Dict[str, Any],
) -> Dict[str, str]:
    if ensemble_size <= 0:
        raise ValueError(f"ensemble_size must be > 0, got {ensemble_size}")
    if ensemble_seed_start < 0:
        raise ValueError(
            f"ensemble_seed_start must be >= 0, got {ensemble_seed_start}"
        )

    normalized_build_cfg = _normalized_build_chain_config(build_chain_config)
    normalized_param_cfg = _normalized_parameterize_chain_config(parameterize_chain_config)
    normalized_pack_cfg = _normalized_pack_nanoparticle_config(pack_nanoparticle_config)

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    members_dir = out_path / "ensemble_members"
    members_dir.mkdir(parents=True, exist_ok=True)

    member_records: List[Dict[str, Any]] = []

    for idx in range(ensemble_size):
        member_index = idx + 1
        seed = ensemble_seed_start + idx
        member_name = f"member_{member_index:04d}"
        member_dir = members_dir / member_name
        member_dir.mkdir(parents=True, exist_ok=True)

        build_dir = member_dir / "build_chain"
        param_dir = member_dir / "parameterize_chain"
        pack_dir = member_dir / "pack_nanoparticle"

        build_result = build_plga_chain(
            dp=normalized_build_cfg["dp"],
            lactic_fraction=normalized_build_cfg["lactic_fraction"],
            stereo_pattern=normalized_build_cfg["stereo_pattern"],
            end_group=normalized_build_cfg["end_group"],
            sequence_mode=normalized_build_cfg["sequence_mode"],
            random_seed=seed,
            out_prefix=str(build_dir / "chain"),
        )

        chain_json = _pick_result_path(build_result, "json", "chain_json")
        chain_pdb = _pick_result_path(build_result, "pdb", "chain_pdb")
        chain_sdf = _pick_result_path(build_result, "sdf", "chain_sdf")

        require_nonempty_file(chain_json, f"{member_name} chain json")
        require_nonempty_file(chain_pdb, f"{member_name} chain pdb")
        require_nonempty_file(chain_sdf, f"{member_name} chain sdf")

        param_result = parameterize_chain(
            input_sdf=chain_sdf,
            charge_method=normalized_param_cfg["charge_method"],
            forcefield=normalized_param_cfg["forcefield"],
            out_dir=str(param_dir),
        )

        chain_parameterized_sdf = _pick_result_path(
            param_result,
            "parameterized_sdf",
            "chain_parameterized_sdf",
            "output_sdf",
        )
        chain_parameterization_json = _pick_result_path(
            param_result,
            "parameterization_json",
            "chain_parameterization_json",
            "metadata_json",
            "report_json",
        )

        require_nonempty_file(
            chain_parameterized_sdf,
            f"{member_name} parameterized sdf",
        )
        require_nonempty_file(
            chain_parameterization_json,
            f"{member_name} parameterization json",
        )

        pack_result = pack_nanoparticle(
            chain_pdb=chain_pdb,
            chain_json=chain_json,
            n_chains=normalized_pack_cfg["n_chains"],
            shape=normalized_pack_cfg["shape"],
            out_dir=str(pack_dir),
            radius_mode=normalized_pack_cfg["radius_mode"],
            radius_angstrom=normalized_pack_cfg["radius_angstrom"],
            target_density_g_cm3=normalized_pack_cfg["target_density_g_cm3"],
            packing_slack_factor=normalized_pack_cfg["packing_slack_factor"],
            chain_size_factor=normalized_pack_cfg["chain_size_factor"],
            minimum_radius_angstrom=normalized_pack_cfg["minimum_radius_angstrom"],
            tolerance=normalized_pack_cfg["tolerance"],
            packmol_seed=normalized_pack_cfg["packmol_seed"],
            retry_scale_factors=normalized_pack_cfg["retry_scale_factors"],
            packmol_maxit=normalized_pack_cfg["packmol_maxit"],
            packmol_nloop=normalized_pack_cfg["packmol_nloop"],
            packmol_movefrac=normalized_pack_cfg["packmol_movefrac"],
            packmol_discale=normalized_pack_cfg["packmol_discale"],
            packmol_precision=normalized_pack_cfg["packmol_precision"],
        )

        packed_pdb = _pick_result_path(pack_result, "packed_pdb")
        packing_report_json = _pick_result_path(
            pack_result,
            "packing_report_json",
            "report_json",
        )
        packmol_input = _pick_result_path(pack_result, "packmol_input")

        require_nonempty_file(packed_pdb, f"{member_name} packed pdb")
        require_nonempty_file(packing_report_json, f"{member_name} packing report")
        require_nonempty_file(packmol_input, f"{member_name} packmol input")

        member_summary = {
            "member_index": member_index,
            "member_name": member_name,
            "random_seed": seed,
            "files": {
                "chain_json": chain_json,
                "chain_pdb": chain_pdb,
                "chain_sdf": chain_sdf,
                "chain_parameterized_sdf": chain_parameterized_sdf,
                "chain_parameterization_json": chain_parameterization_json,
                "packed_pdb": packed_pdb,
                "packing_report_json": packing_report_json,
                "packmol_input": packmol_input,
            },
        }

        summary_path = member_dir / "member_summary.json"
        _write_json(member_summary, summary_path)
        require_nonempty_file(summary_path, f"{member_name} summary")

        member_records.append(member_summary)

    manifest = {
        "ensemble_type": "nanoparticle_ensemble_v1",
        "ensemble_size": ensemble_size,
        "ensemble_seed_start": ensemble_seed_start,
        "build_chain_config": normalized_build_cfg,
        "parameterize_chain_config": normalized_param_cfg,
        "pack_nanoparticle_config": {
            "n_chains": normalized_pack_cfg["n_chains"],
            "shape": normalized_pack_cfg["shape"],
            "radius_mode": normalized_pack_cfg["radius_mode"],
            "radius_angstrom": normalized_pack_cfg["radius_angstrom"],
            "target_density_g_cm3": normalized_pack_cfg["target_density_g_cm3"],
            "packing_slack_factor": normalized_pack_cfg["packing_slack_factor"],
            "chain_size_factor": normalized_pack_cfg["chain_size_factor"],
            "minimum_radius_angstrom": normalized_pack_cfg["minimum_radius_angstrom"],
            "retry_scale_factors": normalized_pack_cfg["retry_scale_factors"],
            "tolerance": normalized_pack_cfg["tolerance"],
            "packmol_maxit": normalized_pack_cfg["packmol_maxit"],
            "packmol_nloop": normalized_pack_cfg["packmol_nloop"],
            "packmol_movefrac": normalized_pack_cfg["packmol_movefrac"],
            "packmol_discale": normalized_pack_cfg["packmol_discale"],
            "packmol_precision": normalized_pack_cfg["packmol_precision"],
        },
        "members": member_records,
        "notes": [
            "This ensemble contains independently generated PLGA nanoparticle realizations.",
            "Each member uses the same workflow settings except for the member seed.",
            "Each member includes build, parameterization, and packing outputs.",
        ],
    }

    manifest_path = out_path / "ensemble_manifest.json"
    _write_json(manifest, manifest_path)
    require_nonempty_file(manifest_path, "ensemble manifest")

    return {
        "ensemble_manifest_json": str(manifest_path),
        "ensemble_members_dir": str(members_dir),
    }