# polymer-tool

[![PyPI version](https://img.shields.io/pypi/v/polymer-tool.svg)](https://pypi.org/project/polymer-tool/)
[![CI](https://github.com/fr-0zt/polymer-tool/actions/workflows/ci.yml/badge.svg)](https://github.com/fr-0zt/polymer-tool/actions/workflows/ci.yml)

`polymer-tool` is a config- and preset-driven PLGA preparation workflow for chain generation, nanoparticle packing, ensemble generation, and downstream handoff exports.

The tool prepares files for downstream modeling workflows. It does **not** run production MD itself.

## Quickstart

Install the CLI:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install polymer-tool

## Current capabilities

### Chain builder
Supported sequence modes:
- `balanced`
- `block`
- `random_seeded`
- `random_coupled`

Supported stereochemistry modes:
- `alt_RS`
- `all_R`
- `all_S`
- `random_RS_seeded`

### Ensemble modes
- `chain`
- `nanoparticle`

### Packing modes
- manual radius
- density-based radius with:
  - density-derived radius
  - chain-geometry floor radius
  - minimum radius floor
  - retry radius scaling

### Packing assessment metrics
- Interchain distance thresholds:
  - min_distance < 1.5 Å: `overcompressed` (hard clash, score -1000)
  - min_distance < 1.8 Å: `too_dense` (unphysical overlap, score -500)
  - min_distance 2.0-4.0 Å: optimal soft contact regime (score +3 to +10)
- Packing efficiency: ratio of actual convex hull volume to ideal sphere volume
  - Ideal range: 0.6-0.8 (good molecular packing)
  - Below 0.5: poor packing quality
- Radial uniformity: measure of how evenly chains fill the sphere
- Contact counting: tracks close contacts at multiple distance thresholds

## Installation

### Core CLI workflow
```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e .
```

### PyQt5 GUI
```bash
pip install -e '.[gui]'
polymer-tool-gui
```

### Development and release checks
```bash
pip install -e '.[dev,gui]'
pytest -q
python -m build
python -m twine check dist/*
```

## Usage

### Command-line
```bash
polymer-tool --preset <preset_name> [options]
```

### GUI application
Launch the PyQt5 GUI:
```bash
polymer-tool-gui
```

A legacy tkinter GUI entry point is also preserved for compatibility:
```bash
polymer-tool-gui-tk
```

## Packaging notes

- The CLI can be installed without PyQt5.
- The PyQt5 GUI is provided through the optional `gui` extra.
- GUI tests are skipped automatically when PyQt5 is not installed.
