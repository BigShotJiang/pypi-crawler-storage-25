from __future__ import annotations

import json
from pathlib import Path

from polymer_tool import app


def test_launch_profiles_include_expected_names() -> None:
    names = {item["name"] for item in app.launch_profiles()}
    assert "24mer_single" in names
    assert "24mer_np_ensemble" in names
    assert "50mer_np_ensemble" in names
    assert "100mer_screen_single" in names


def test_compare_materialized_configs_reports_change() -> None:
    left = {
        "project_name": "proj",
        "workflow_name": "build_pack_workflow",
        "workflow_config": {"build_chain": {"dp": 24}},
    }
    right = {
        "project_name": "proj",
        "workflow_name": "build_pack_workflow",
        "workflow_config": {"build_chain": {"dp": 50}},
    }

    text = app.compare_materialized_configs(
        left,
        right,
        left_label="current",
        right_label="saved",
    )

    assert "Changed values:" in text
    assert "workflow_config.build_chain.dp" in text
    assert "current: 24" in text
    assert "saved: 50" in text


def test_export_request_bundle_writes_expected_files(tmp_path: Path) -> None:
    out_dir = tmp_path / "bundle"

    result = app.export_request_bundle(
        out_dir,
        preset="plga_24mer_seed",
        overrides={
            "dp": 66,
            "radius_mode": "density_based",
            "minimum_radius_angstrom": 45.0,
        },
        ensemble_size=3,
        ensemble_mode="nanoparticle",
        ensemble_seed_start=1000,
    )

    assert Path(result["bundle_dir"]).is_dir()
    assert Path(result["resolved_config_json"]).is_file()
    assert Path(result["command_txt"]).is_file()
    assert Path(result["bundle_manifest_json"]).is_file()

    payload = json.loads(Path(result["resolved_config_json"]).read_text(encoding="utf-8"))
    assert payload["workflow_config"]["build_chain"]["dp"] == 66
    assert payload["workflow_config"]["pack_nanoparticle"]["radius_mode"] == "density_based"
    assert payload["workflow_config"]["pack_nanoparticle"]["minimum_radius_angstrom"] == 45.0

    command_text = Path(result["command_txt"]).read_text(encoding="utf-8")
    assert "--preset" in command_text
    assert "plga_24mer_seed" in command_text
    assert "--ensemble-size" in command_text
    assert "--ensemble-mode" in command_text
