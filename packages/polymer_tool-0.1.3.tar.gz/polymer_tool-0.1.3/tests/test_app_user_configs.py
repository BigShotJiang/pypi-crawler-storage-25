from __future__ import annotations

from pathlib import Path

from polymer_tool import app


def test_save_named_user_config_and_discover(tmp_path: Path) -> None:
    saved = app.save_named_user_config(
        "My 24mer Screen",
        config_root=tmp_path,
        preset="plga_24mer_seed",
        overrides={
            "dp": 66,
            "radius_mode": "density_based",
            "minimum_radius_angstrom": 45.0,
        },
    )

    saved_path = Path(saved)
    assert saved_path.is_file()

    configs = app.discover_user_configs(config_root=tmp_path)
    names = {item["name"] for item in configs}
    assert "My_24mer_Screen" in names

    record = next(item for item in configs if item["name"] == "My_24mer_Screen")
    assert record["path"] == str(saved_path)
    assert record["project_name"] == "plga_tool_dev"
    assert record["workflow_name"] == "build_pack_workflow"


def test_load_user_config_by_name_accepts_unslugged_name(tmp_path: Path) -> None:
    app.save_named_user_config(
        "My 50mer Default",
        config_root=tmp_path,
        preset="plga_50mer_default",
        overrides={"dp": 70},
    )

    loaded = app.load_user_config_by_name(
        "My 50mer Default",
        config_root=tmp_path,
    )

    assert loaded["workflow_config"]["build_chain"]["dp"] == 70


def test_ensure_user_config_root_creates_directory(tmp_path: Path) -> None:
    root = tmp_path / "user_configs"
    created = app.ensure_user_config_root(root)
    assert created.exists()
    assert created.is_dir()
