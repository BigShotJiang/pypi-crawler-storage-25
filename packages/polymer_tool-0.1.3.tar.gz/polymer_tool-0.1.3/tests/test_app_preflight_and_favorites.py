from __future__ import annotations

from pathlib import Path

from polymer_tool import app


def _minimal_config(radius_mode: str = "manual", radius_angstrom=None) -> dict:
    return {
        "project_name": "demo_project",
        "workflow_name": "build_pack_workflow",
        "workflow_config": {
            "build_chain": {
                "dp": 24,
                "lactic_fraction": 0.5,
                "stereo_pattern": "alt_RS",
                "end_group": "ester",
                "sequence_mode": "balanced",
                "random_seed": None,
            },
            "parameterize_chain": {
                "charge_method": "gasteiger",
                "forcefield": "openff-2.3.0",
            },
            "pack_nanoparticle": {
                "n_chains": 4,
                "shape": "sphere",
                "radius_mode": radius_mode,
                "radius_angstrom": radius_angstrom,
                "target_density_g_cm3": 1.25,
                "packing_slack_factor": 1.25,
                "minimum_radius_angstrom": None,
                "retry_scale_factors": [1.0, 1.2, 1.5, 2.0],
                "tolerance": 2.0,
                "packmol_maxit": 200,
                "packmol_nloop": 2000,
                "packmol_movefrac": 0.05,
                "packmol_discale": 1.5,
                "packmol_precision": 2,
            },
            "assess_packed_nanoparticle": {
                "n_steps": 5000,
                "temperature_kelvin": 300.0,
            },
            "assemble_system": {
                "system_name": "demo_system",
                "molecule_label": "PLGA_CHAIN",
            },
            "prepare_topology_bridge": {},
            "export_gromacs_handoff": {"bundle_name": "demo_gmx"},
            "export_generic_handoff": {"bundle_name": "demo_generic"},
            "export_descriptor": {},
        },
    }


def test_preflight_reports_missing_manual_radius() -> None:
    report = app.preflight_validate_request(
        config_data=_minimal_config(radius_mode="manual", radius_angstrom=None)
    )

    assert not report["ok"]
    assert any("radius_angstrom" in item for item in report["errors"])


def test_preflight_accepts_known_launch_profile() -> None:
    profile = app.get_launch_profile("24mer_np_ensemble")

    report = app.preflight_validate_request(**profile["request"])

    assert report["ok"]
    assert not report["errors"]


def test_toggle_favorite_launch_profile_roundtrip(tmp_path: Path) -> None:
    names = app.toggle_favorite_launch_profile(
        "24mer_np_ensemble",
        state_root=tmp_path,
    )
    assert "24mer_np_ensemble" in names

    loaded = app.load_favorite_launch_profiles(state_root=tmp_path)
    assert "24mer_np_ensemble" in loaded

    names = app.toggle_favorite_launch_profile(
        "24mer_np_ensemble",
        state_root=tmp_path,
    )
    assert "24mer_np_ensemble" not in names
