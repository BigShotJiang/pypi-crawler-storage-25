from __future__ import annotations

import json
import os
from pathlib import Path

from polymer_tool import app


def test_build_cli_command_preview_with_preset_and_overrides() -> None:
    text = app.build_cli_command_preview(
        preset="plga_24mer_seed",
        run_id="demo_run",
        base_dir="projects/demo/runs/demo_run",
        overrides={
            "dp": 24,
            "radius_mode": "density_based",
            "minimum_radius_angstrom": 45.0,
            "retry_scale_factors": [1.0, 1.2, 1.5],
        },
        ensemble_size=3,
        ensemble_seed_start=1000,
        ensemble_mode="nanoparticle",
    )

    assert "polymer-tool" in text
    assert "--preset" in text
    assert "plga_24mer_seed" in text
    assert "--run-id" in text
    assert "demo_run" in text
    assert "--radius-mode" in text
    assert "density_based" in text
    assert "--minimum-radius" in text
    assert "45.0" in text
    assert "--retry-scales" in text
    assert "--ensemble-size" in text
    assert "--ensemble-mode" in text
    assert "nanoparticle" in text


def test_resolve_config_data_prefers_explicit_config_path(tmp_path: Path) -> None:
    config_path = tmp_path / "custom.json"
    config_path.write_text(
        json.dumps(
            {
                "project_name": "custom_project",
                "workflow_name": "build_pack_workflow",
                "workflow_config": {
                    "build_chain": {},
                    "parameterize_chain": {},
                    "pack_nanoparticle": {},
                    "assemble_system": {},
                    "prepare_topology_bridge": {},
                    "export_gromacs_handoff": {},
                    "export_generic_handoff": {},
                    "export_descriptor": {},
                },
            }
        ),
        encoding="utf-8",
    )

    data = app.resolve_config_data(str(config_path), "plga_24mer_seed")
    assert data["project_name"] == "custom_project"


def test_discover_recent_runs_returns_sorted_records(tmp_path: Path) -> None:
    base = tmp_path / "projects"

    run_a = base / "projA" / "runs" / "run_a" / "state"
    run_b = base / "projB" / "runs" / "run_b" / "state"
    run_a.mkdir(parents=True)
    run_b.mkdir(parents=True)

    state_a = run_a / "run_state.json"
    state_b = run_b / "run_state.json"

    state_a.write_text(
        json.dumps(
            {
                "run": {
                    "project_name": "projA",
                    "run_id": "run_a",
                    "base_dir": str(run_a.parent),
                    "workflow_name": "build_pack_workflow",
                    "steps": [{"status": "completed"}],
                }
            }
        ),
        encoding="utf-8",
    )
    state_b.write_text(
        json.dumps(
            {
                "run": {
                    "project_name": "projB",
                    "run_id": "run_b",
                    "base_dir": str(run_b.parent),
                    "workflow_name": "build_pack_workflow",
                    "steps": [{"status": "failed"}],
                }
            }
        ),
        encoding="utf-8",
    )

    os.utime(state_a, (100, 100))
    os.utime(state_b, (200, 200))

    records = app.discover_recent_runs(base_root=base, limit=10)

    assert len(records) == 2
    assert records[0]["run_id"] == "run_b"
    assert records[1]["run_id"] == "run_a"
    assert records[0]["last_status"] == "failed"
    assert records[1]["last_status"] == "completed"
