from __future__ import annotations

import json
from pathlib import Path

from polymer_tool import app


def test_save_resolved_config_from_preset_writes_json(tmp_path: Path) -> None:
    out_path = tmp_path / "custom_config.json"

    saved = app.save_resolved_config(
        out_path,
        preset="plga_24mer_seed",
        overrides={
            "dp": 66,
            "radius_mode": "density_based",
            "minimum_radius_angstrom": 45.0,
        },
    )

    assert saved == str(out_path)
    payload = json.loads(out_path.read_text(encoding="utf-8"))

    assert payload["project_name"] == "plga_tool_dev"
    assert payload["workflow_name"] == "build_pack_workflow"
    assert payload["workflow_config"]["build_chain"]["dp"] == 66
    assert payload["workflow_config"]["pack_nanoparticle"]["radius_mode"] == "density_based"
    assert payload["workflow_config"]["pack_nanoparticle"]["minimum_radius_angstrom"] == 45.0


def test_load_run_snapshot_and_config_from_state(tmp_path: Path) -> None:
    run_dir = tmp_path / "projects" / "demo_project" / "runs" / "demo_run"
    state_dir = run_dir / "state"
    state_dir.mkdir(parents=True)

    state_file = state_dir / "run_state.json"
    state_file.write_text(
        json.dumps(
            {
                "run": {
                    "run_id": "demo_run",
                    "project_name": "demo_project",
                    "base_dir": str(run_dir),
                    "workflow_name": "build_pack_workflow",
                    "config": {
                        "build_chain": {},
                        "parameterize_chain": {},
                        "pack_nanoparticle": {},
                        "assemble_system": {},
                        "prepare_topology_bridge": {},
                        "export_gromacs_handoff": {},
                        "export_generic_handoff": {},
                        "export_descriptor": {},
                    },
                }
            }
        ),
        encoding="utf-8",
    )

    snapshot = app.load_run_snapshot(run_dir)
    assert snapshot["run_id"] == "demo_run"
    assert snapshot["project_name"] == "demo_project"
    assert snapshot["workflow_name"] == "build_pack_workflow"
    assert snapshot["base_dir"] == str(run_dir)

    config = app.load_config_from_run_state(run_dir)
    assert config["project_name"] == "demo_project"
    assert config["workflow_name"] == "build_pack_workflow"
    assert "build_chain" in config["workflow_config"]


def test_build_cli_command_preview_for_in_memory_config() -> None:
    text = app.build_cli_command_preview(
        config_data={
            "project_name": "demo_project",
            "workflow_name": "build_pack_workflow",
            "workflow_config": {
                "build_chain": {},
                "parameterize_chain": {},
                "pack_nanoparticle": {},
                "assemble_system": {},
                "prepare_topology_bridge": {},
                "export_gromacs_handoff": {},
                "export_generic_handoff": {},
                "export_descriptor": {},
            },
        }
    )

    assert "save current config to json" in text.lower()