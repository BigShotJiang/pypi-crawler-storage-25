from __future__ import annotations

from pathlib import Path

import pytest

from polymer_tool import app


def test_available_presets_contains_bundled_presets() -> None:
    presets = app.available_presets()
    assert "plga_24mer_seed" in presets
    assert "plga_50mer_default" in presets
    assert "plga_100mer_screen" in presets


def test_sanitize_workflow_config_repairs_pack_defaults() -> None:
    workflow_config = {
        "pack_nanoparticle": {
            "radius_mode": "bad_mode",
            "packmol_precision": 0,
            "packmol_discale": 0,
            "tolerance": 0,
            "packmol_maxit": 0,
            "packmol_nloop": 0,
            "packmol_movefrac": 0,
            "target_density_g_cm3": 0,
            "packing_slack_factor": 0,
            "chain_size_factor": 0,
            "retry_scale_factors": [0, -1, "x"],
            "minimum_radius_angstrom": -5,
            "radius_angstrom": -7,
        }
    }

    sanitized, notes = app.sanitize_workflow_config(workflow_config)

    pack = sanitized["pack_nanoparticle"]
    assert pack["radius_mode"] == "manual"
    assert pack["packmol_precision"] == 2
    assert pack["packmol_discale"] == 1.5
    assert pack["tolerance"] == 2.0
    assert pack["packmol_maxit"] == 200
    assert pack["packmol_nloop"] == 2000
    assert pack["packmol_movefrac"] == 0.05
    assert pack["target_density_g_cm3"] == 1.25
    assert pack["packing_slack_factor"] == 1.25
    assert pack["chain_size_factor"] == 1.2
    assert pack["retry_scale_factors"] == [1.0, 1.2, 1.5, 2.0]
    assert pack["minimum_radius_angstrom"] is None
    assert pack["radius_angstrom"] is None
    assert notes


def test_format_run_result_pipeline() -> None:
    result = {
        "mode": "pipeline",
        "state_file": "projects/demo/state/run_state.json",
        "artifacts": {
            "chain_json": "projects/demo/outputs/build_chain/chain.json",
            "packed_pdb": "projects/demo/outputs/pack_nanoparticle/packed_nanoparticle.pdb",
        },
        "sanitation_notes": [
            "Adjusted pack_nanoparticle.packmol_precision from 0 to 2."
        ],
    }

    text = app.format_run_result(result)
    assert "Workflow config adjustments:" in text
    assert "Run finished. State written to:" in text
    assert "chain_json" in text
    assert "packed_pdb" in text


def test_run_workflow_request_chain_ensemble_uses_monkeypatched_backend(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    captured: dict[str, object] = {}

    def fake_generate_chain_ensemble(
        *,
        out_dir: str,
        ensemble_size: int,
        ensemble_seed_start: int,
        build_chain_config: dict,
    ) -> dict[str, str]:
        captured["out_dir"] = out_dir
        captured["ensemble_size"] = ensemble_size
        captured["ensemble_seed_start"] = ensemble_seed_start
        captured["build_chain_config"] = build_chain_config
        return {
            "ensemble_manifest_json": str(tmp_path / "ensemble_manifest.json"),
            "ensemble_members_dir": str(tmp_path / "ensemble_members"),
        }

    monkeypatch.setattr(app, "generate_chain_ensemble", fake_generate_chain_ensemble)

    result = app.run_workflow_request(
        preset="plga_24mer_seed",
        base_dir=str(tmp_path / "run"),
        ensemble_size=2,
        ensemble_seed_start=123,
        ensemble_mode="chain",
        overrides={"dp": 66, "sequence_mode": "block"},
    )

    assert result["mode"] == "ensemble"
    assert result["ensemble_mode"] == "chain"
    assert result["ensemble_size"] == 2
    assert captured["ensemble_size"] == 2
    assert captured["ensemble_seed_start"] == 123
    assert captured["build_chain_config"]["dp"] == 66
    assert captured["build_chain_config"]["sequence_mode"] == "block"


def test_run_workflow_request_invalid_ensemble_mode_raises(
    tmp_path: Path,
) -> None:
    with pytest.raises(ValueError):
        app.run_workflow_request(
            preset="plga_24mer_seed",
            base_dir=str(tmp_path / "run"),
            ensemble_size=1,
            ensemble_mode="invalid_mode",
        )
