# Cairn context — multi-module — 2026-04-08

_Auto-generated from runtime signal. Do not edit manually._

# cairn

## 🔴 HALT — distill (17 records) [distill]

_Health: **ABLATED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN error in test_backtest.py (414 occurrences)  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestNewRules::test_print_statement_rule  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestNewRules::test_magic_number_rule  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestGitBlame::test_blame_records_returns_empty_for_non_git  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestAnnotateClear::test_clear_dry_run_shows_diff  _(conf: 1.00)_
- _…and 12 more_

## 🟡 ALERT — distill (1 record) [distill]

_Health: **DEGRADED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN AssertionError in test_new_features.py (1 occurrence)  _(conf: 1.00)_

# distill

## 🟡 ALERT — distill (1 record) [distill]

_Health: **DEGRADED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN broad_except in pytest_plugin.py (31 occurrences)  _(conf: 1.00)_

# scripts

## 🟡 ALERT — distill (1 record) [distill]

_Health: **DEGRADED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN print_statement in prime_commons.py (52 occurrences)  _(conf: 1.00)_
