"""Nox sessions for local multi-version compatibility testing.

Usage:
    pip install nox          # one-time
    nox                      # run all sessions
    nox -s test-3.10         # single version
    nox -s lint              # ruff only

Requires Python 3.10, 3.11, and 3.12 to be available on PATH
(e.g. via pyenv: pyenv install 3.10 3.11 3.12).
"""

import nox

PYTHON_VERSIONS = ["3.10", "3.11", "3.12"]


@nox.session(python=PYTHON_VERSIONS, name="test")
def test(session: nox.Session) -> None:
    """Run the full pytest suite on the given Python version."""
    session.install("-e", ".[dev,coverage,config]")
    session.run("pytest", "tests/", "-v", "--tb=short", "-q")


@nox.session(python="3.12")
def lint(session: nox.Session) -> None:
    """Run ruff linter + formatter check."""
    session.install("ruff>=0.3")
    session.run("ruff", "check", "cairn/", "tests/")
    session.run("ruff", "format", "--check", "cairn/", "tests/")
