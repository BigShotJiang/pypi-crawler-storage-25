"""
Cairn — runtime signal capture and distillation for AI-assisted Python development.
"""

from cairn.capture.decorator import watch

__all__ = ["watch"]
__version__ = "0.1.0"
