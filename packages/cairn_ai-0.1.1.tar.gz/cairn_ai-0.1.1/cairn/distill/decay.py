"""Confidence decay model — age-weight TruthRecord confidence scores.

Old truths that are not re-confirmed by new runs fade out of active context.
Decay uses a simple exponential half-life:

    effective_confidence = record.confidence * 0.5 ** (age_days / half_life)

AST records decay faster (structural code changes more often than runtime
behaviour changes); distill records decay slower (they represent synthesised
patterns, not single observations).
"""

from __future__ import annotations

from datetime import datetime, timezone

from cairn.store.schema import TruthRecord

# Default half-lives in days per source type
_HALF_LIFE: dict[str, float] = {
    "pytest":  21.0,   # test results go stale after ~3 weeks
    "monitor": 21.0,
    "ast":     14.0,   # code changes faster
    "git":     30.0,
    "distill": 60.0,   # synthesised patterns are more durable
}
_DEFAULT_HALF_LIFE = 30.0


def _load_half_lives() -> dict[str, float]:
    """Read project-level half-lives from [tool.cairn.decay], merged with defaults."""
    try:
        from cairn.config import get_config
        cfg = get_config().get("decay", {})
        merged = dict(_HALF_LIFE)
        for k, v in cfg.items():
            merged[k] = float(v)
        return merged
    except Exception:
        return dict(_HALF_LIFE)


def decayed_confidence(
    record: TruthRecord,
    as_of: datetime | None = None,
    _half_lives: dict[str, float] | None = None,
) -> float:
    """Return the current effective confidence after age-based decay.

    Args:
        record:       the TruthRecord to evaluate.
        as_of:        reference datetime (defaults to UTC now).
        _half_lives:  pre-loaded half-life map (avoids per-record config reads).

    Returns:
        Effective confidence in [0.0, 1.0].
    """
    now = as_of or datetime.now(tz=timezone.utc)
    # Normalise both to UTC
    occurred = record.occurred_at
    if occurred.tzinfo is None:
        occurred = occurred.replace(tzinfo=timezone.utc)
    age_days = max(0.0, (now - occurred).total_seconds() / 86400)

    if _half_lives is None:
        _half_lives = _load_half_lives()
    half_life = _half_lives.get(record.source, _DEFAULT_HALF_LIFE)

    return record.confidence * (0.5 ** (age_days / half_life))


def apply_decay(
    records: list[TruthRecord],
    as_of: datetime | None = None,
    min_confidence: float = 0.05,
) -> list[TruthRecord]:
    """Return records with effective confidence above *min_confidence*, sorted
    highest-first.

    Args:
        records:        records to evaluate.
        as_of:          reference datetime (defaults to UTC now).
        min_confidence: records below this effective confidence are dropped.
    """
    now = as_of or datetime.now(tz=timezone.utc)
    half_lives = _load_half_lives()  # read config once for the whole batch
    scored = [
        (decayed_confidence(r, now, _half_lives=half_lives), r)
        for r in records
    ]
    return [
        r for score, r in sorted(scored, key=lambda x: -x[0])
        if score >= min_confidence
    ]
