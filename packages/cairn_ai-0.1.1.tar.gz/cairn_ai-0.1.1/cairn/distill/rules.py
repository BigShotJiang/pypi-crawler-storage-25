"""Encode distilled patterns as ruff / flake8 noqa hints.

High-confidence structural patterns (from AST clusters) are mapped to their
corresponding ruff rule codes so the agent can suggest ``# noqa`` comments or
ruff ``select`` additions to prevent silent recurrence.

Runtime failure patterns (pytest/monitor) don't map cleanly to static rules;
those are surfaced in context snippets instead.
"""

from __future__ import annotations

from cairn.store.schema import TruthRecord

# AST check type → (ruff_code, description)
_AST_RULES: dict[str, tuple[str, str]] = {
    "broad_except":      ("BLE001",  "blind exception: do not catch blind exception"),
    "mutable_default":   ("B006",    "do not use mutable data structures for argument defaults"),
    "missing_annotation":("ANN",     "flake8-annotations: missing type annotation"),
    "unreachable_code":  ("RET505",  "unnecessary `else` after `return` statement / unreachable"),
    "deep_nesting":      ("C901",    "function is too complex (McCabe complexity)"),
    "magic_number":      ("PLR2004", "magic value used in comparison"),
    "print_statement":   ("T201",    "print found — use logging instead"),
    "assert_in_library": ("S101",    "use of assert detected — assertions are removed with -O"),
    "fstring_in_logging":("G004",    "logging statement uses f-string — use lazy % formatting"),
}


def encode_as_rule(cluster_name: str, records: list[TruthRecord]) -> str | None:
    """Return a Markdown snippet describing the applicable ruff rule, or None.

    Args:
        cluster_name: human-readable cluster label from ``namer.name_cluster``.
        records:      member records of the cluster.

    Returns:
        A Markdown string with the rule code and remediation hint, or ``None``
        if the pattern cannot be expressed as a static lint rule.
    """
    if not records:
        return None

    source = records[0].source
    if source != "ast":
        return None

    check_type = records[0].content.split(":")[0].strip()
    mapping = _AST_RULES.get(check_type)
    if not mapping:
        return None

    code, description = mapping
    files = sorted({r.source_file for r in records if r.source_file})
    file_list = ", ".join(f"`{f}`" for f in files[:5])
    if len(files) > 5:
        file_list += f" and {len(files) - 5} more"

    return (
        f"**ruff `{code}`** — {description}\n"
        f"Pattern: `{check_type}` ({len(records)} occurrence{'s' if len(records) != 1 else ''})\n"
        f"Files: {file_list}\n"
        f"Fix: add `{code}` to `select` in `pyproject.toml` or add `# noqa: {code}` inline."
    )
