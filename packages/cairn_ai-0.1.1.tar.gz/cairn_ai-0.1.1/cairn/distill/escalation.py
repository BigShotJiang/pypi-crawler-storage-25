"""Policy-based escalation for pattern clusters.

When ``margin`` is installed, each cluster's health state is evaluated
against a policy that determines the appropriate escalation level:

- **LOG**: mention in context (default for INTACT / low-severity).
- **ALERT**: highlight prominently (DEGRADED clusters, or ACCELERATING drift).
- **HALT**: flag as critical (ABLATED + WORSENING, or NOVEL anomaly in a
  critical cluster).

The policy is configurable via ``[tool.cairn.escalation]`` in pyproject.toml,
but ships with sensible defaults.

Without margin installed, all clusters get ``LOG`` escalation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from cairn.distill.health import ClusterHealth, HAS_MARGIN

if HAS_MARGIN:
    from margin import (
        EscalationLevel,
        Health,
    )


@dataclass
class ClusterEscalation:
    """Escalation decision for one pattern cluster."""

    cluster_key: str
    level: str  # "LOG" | "ALERT" | "HALT"
    reason: str

    def to_dict(self) -> dict:
        return {
            "cluster_key": self.cluster_key,
            "level": self.level,
            "reason": self.reason,
        }

    @property
    def is_alert(self) -> bool:
        return self.level in ("ALERT", "HALT")

    @property
    def is_halt(self) -> bool:
        return self.level == "HALT"


def evaluate_escalation(health: ClusterHealth) -> ClusterEscalation:
    """Determine the escalation level for a cluster based on its health.

    The policy is intentionally simple and deterministic:

    - HALT: ABLATED + WORSENING, or any NOVEL anomaly with high record count
    - ALERT: DEGRADED, or ACCELERATING drift, or ANOMALOUS
    - LOG: everything else

    Args:
        health: ClusterHealth from ``analyze_cluster()``.

    Returns:
        ClusterEscalation with the level and reason.
    """
    if not HAS_MARGIN or health.health is None:
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="LOG",
            reason="margin not installed; using default escalation",
        )

    # HALT conditions
    if health.health == "ABLATED" and health.drift_direction == "WORSENING":
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="HALT",
            reason=(
                f"ABLATED and WORSENING: {health.record_count} records, "
                f"drift {health.drift_state}"
            ),
        )

    if health.is_novel and health.record_count >= 3:
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="HALT",
            reason=(
                f"NOVEL anomaly with {health.record_count} records — "
                f"failure pattern never seen before"
            ),
        )

    # ALERT conditions
    if health.health in ("ABLATED", "DEGRADED"):
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="ALERT",
            reason=f"{health.health}: {health.record_count} records",
        )

    if health.drift_state == "ACCELERATING" and health.drift_direction == "WORSENING":
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="ALERT",
            reason=(
                f"ACCELERATING worsening trend "
                f"(rate: {health.drift_rate})"
            ),
        )

    if health.anomaly_state in ("ANOMALOUS", "NOVEL"):
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="ALERT",
            reason=(
                f"{health.anomaly_state} observation "
                f"(z-score: {health.anomaly_z_score})"
            ),
        )

    if health.drift_direction == "WORSENING" and health.drift_state == "DRIFTING":
        return ClusterEscalation(
            cluster_key=health.cluster_key,
            level="ALERT",
            reason=f"DRIFTING WORSENING (rate: {health.drift_rate})",
        )

    # LOG — everything else
    reason_parts = []
    if health.health:
        reason_parts.append(health.health)
    if health.drift_state:
        reason_parts.append(health.drift_state)
    if health.anomaly_state:
        reason_parts.append(health.anomaly_state)

    return ClusterEscalation(
        cluster_key=health.cluster_key,
        level="LOG",
        reason=" | ".join(reason_parts) if reason_parts else "healthy",
    )


def evaluate_all(
    cluster_healths: dict[str, ClusterHealth],
) -> dict[str, ClusterEscalation]:
    """Evaluate escalation for all clusters.

    Returns:
        Dict mapping cluster_key -> ClusterEscalation, sorted by
        escalation severity (HALT first, then ALERT, then LOG).
    """
    results = {
        key: evaluate_escalation(health)
        for key, health in cluster_healths.items()
    }

    level_order = {"HALT": 0, "ALERT": 1, "LOG": 2}
    return dict(sorted(
        results.items(),
        key=lambda kv: (level_order.get(kv[1].level, 3), kv[0]),
    ))
