"""Distillation subsystem: cluster, namer, rules, decay, templates, health,
causality, escalation."""

from cairn.distill.cluster import cluster
from cairn.distill.decay import apply_decay
from cairn.distill.namer import name_cluster
from cairn.distill.rules import encode_as_rule
from cairn.distill.templates import generate_stubs, generate_stubs_markdown
from cairn.distill.health import analyze_cluster, analyze_clusters, ClusterHealth, HAS_MARGIN
from cairn.distill.causality import build_causal_graph, ClusterCausality
from cairn.distill.escalation import evaluate_escalation, evaluate_all, ClusterEscalation

__all__ = [
    "cluster",
    "apply_decay",
    "name_cluster",
    "encode_as_rule",
    "generate_stubs",
    "generate_stubs_markdown",
    # margin-powered (graceful fallback when margin not installed)
    "analyze_cluster",
    "analyze_clusters",
    "ClusterHealth",
    "HAS_MARGIN",
    "build_causal_graph",
    "ClusterCausality",
    "evaluate_escalation",
    "evaluate_all",
    "ClusterEscalation",
]
