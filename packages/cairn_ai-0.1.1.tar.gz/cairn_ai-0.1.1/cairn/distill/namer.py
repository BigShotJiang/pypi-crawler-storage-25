"""Pattern namer — assign human-readable names to failure clusters.

Deterministic heuristics by default; passing ``use_llm=True`` routes through
OpenRouter (``meta-llama/llama-3.3-70b-instruct:free``) for richer labels.

LLM path
--------
Set the ``OPENROUTER_API_KEY`` environment variable (or pass *api_key*
directly).  Falls back to the deterministic heuristic if the API call fails.

Heuristic strategy
------------------
- For ``pytest``/``monitor`` clusters: ``<ExceptionType> in <most-common-file>``
  e.g. ``ValueError in config.py``
- For ``ast`` clusters: ``<check_type> (<count> occurrences)``
  e.g. ``broad_except (12 occurrences)``
- For ``git`` clusters: ``commit correlation (<count> commits)``
- Fallback: ``<source>::<count> records``
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path

from cairn.store.schema import TruthRecord

# Paid model — $0.03 / $0.11 per million tokens, 128k context.
# Upgrade path: swap this string for any OpenRouter model ID.
_LLM_MODEL = "google/gemma-3-27b-it"
_OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"


def name_cluster(
    records: list[TruthRecord],
    use_llm: bool = False,
    api_key: str | None = None,
) -> str:
    """Produce a short human-readable name for a cluster.

    Args:
        records:  member records of the cluster (non-empty).
        use_llm:  when True, call OpenRouter for a richer label; falls back to
                  the heuristic if the API call fails or the key is absent.
        api_key:  OpenRouter API key; defaults to ``$OPENROUTER_API_KEY``.

    Returns:
        A short descriptive string label.
    """
    if not records:
        return "empty cluster"

    if use_llm:
        try:
            return _name_cluster_llm(records, api_key=api_key)
        except Exception:
            # Graceful fallback — never break distill because of an LLM hiccup
            pass

    source = records[0].source
    n = len(records)

    if source in ("pytest", "monitor"):
        return _name_runtime_cluster(records, n)

    if source == "ast":
        check = records[0].content.split(":")[0].strip()
        # Disambiguate by most-common file when available
        file_counts: Counter[str] = Counter(
            Path(r.source_file).name for r in records if r.source_file
        )
        if file_counts:
            top_file = file_counts.most_common(1)[0][0]
            return f"{check} in {top_file} ({n} occurrence{'s' if n != 1 else ''})"
        return f"{check} ({n} occurrence{'s' if n != 1 else ''})"

    if source == "git":
        file_counts_g: Counter[str] = Counter(
            Path(r.source_file).name for r in records if r.source_file
        )
        if file_counts_g:
            top_file = file_counts_g.most_common(1)[0][0]
            return f"git changes in {top_file} ({n} commit{'s' if n != 1 else ''})"
        return f"commit correlation ({n} commit{'s' if n != 1 else ''})"

    return f"{source} ({n} record{'s' if n != 1 else ''})"


def _name_runtime_cluster(records: list[TruthRecord], n: int) -> str:
    # Most common exception type
    exc_counts: Counter[str] = Counter(
        r.exception_type for r in records if r.exception_type
    )
    exc = exc_counts.most_common(1)[0][0] if exc_counts else "error"

    # Most common source file
    file_counts: Counter[str] = Counter(
        Path(r.source_file).name for r in records if r.source_file
    )
    if file_counts:
        filename = file_counts.most_common(1)[0][0]
        return f"{exc} in {filename} ({n} occurrence{'s' if n != 1 else ''})"

    return f"{exc} ({n} occurrence{'s' if n != 1 else ''})"


# ---------------------------------------------------------------------------
# LLM-assisted naming
# ---------------------------------------------------------------------------


def _name_cluster_llm(
    records: list[TruthRecord],
    api_key: str | None = None,
) -> str:
    """Call OpenRouter to generate a descriptive cluster label.

    Uses ``urllib`` (stdlib only, no extra deps).  Raises on any network or
    API error so callers can fall back to the heuristic.
    """
    import json
    import os
    import urllib.request

    key = api_key or os.environ.get("OPENROUTER_API_KEY", "") or _read_dotenv_key()
    if not key:
        raise ValueError(
            "OPENROUTER_API_KEY is not set; cannot use LLM naming. "
            "Set it in $OPENROUTER_API_KEY or in a .env file."
        )

    n = len(records)
    source = records[0].source
    sample_lines = [r.content.splitlines()[0][:120] for r in records[:6]]
    exc_types = sorted({r.exception_type for r in records if r.exception_type})
    files = sorted({Path(r.source_file).name for r in records if r.source_file})[:4]

    summary_parts = [f"Source type: {source}", f"Cluster size: {n}"]
    if exc_types:
        summary_parts.append(f"Exception types: {', '.join(exc_types)}")
    if files:
        summary_parts.append(f"Affected files: {', '.join(files)}")
    summary_parts.append("Sample records:")
    summary_parts.extend(f"  • {line}" for line in sample_lines)
    summary = "\n".join(summary_parts)

    prompt = (
        "You are labelling a cluster of related software failures or code "
        "observations for a developer context document used by an AI coding "
        "assistant.  Given the cluster summary below, produce a concise "
        "(3–8 word) human-readable label.  Reply with ONLY the label — no "
        "punctuation at the end, no surrounding quotes, no explanation.\n\n"
        f"{summary}"
    )

    payload = json.dumps({
        "model": _LLM_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 32,
        "temperature": 0.3,
    }).encode()

    req = urllib.request.Request(
        _OPENROUTER_URL,
        data=payload,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/cairn-dev/cairn",
            "X-Title": "cairn pattern namer",
        },
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=20) as resp:  # noqa: S310
        data = json.loads(resp.read())

    label = data["choices"][0]["message"]["content"].strip().strip("\"'")
    return f"{label} ({n} record{'s' if n != 1 else ''})"


# ---------------------------------------------------------------------------
# Key loading helpers
# ---------------------------------------------------------------------------


def _read_dotenv_key() -> str:
    """Read OPENROUTER_API_KEY from a .env file in the project root.

    Searches cwd and parents for the first .env that contains the key.
    Falls back to ~/.config/cairn/.env (user-level secrets store).
    Returns an empty string if not found.
    """
    from pathlib import Path

    candidates = [
        *[p / ".env" for p in [Path.cwd(), *Path.cwd().parents]],
        Path.home() / ".config" / "cairn" / ".env",
    ]
    for dotenv in candidates:
        if dotenv.exists():
            try:
                for line in dotenv.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("OPENROUTER_API_KEY="):
                        return line[len("OPENROUTER_API_KEY="):].strip().strip("\"'"
                                                                               )
            except OSError:
                continue
    return ""
