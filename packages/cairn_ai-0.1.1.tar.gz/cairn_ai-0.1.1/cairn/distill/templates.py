"""Test template generator — produce property-based test stubs from observed
function behaviour captured by ``sys.monitoring`` (source="monitor").

For each unique (source_file, function_name) pair seen in the truth store,
this module generates a Python pytest stub file that:

- Documents what Cairn observed (call count, return types, argument names)
- Provides a ready-to-edit ``def test_<fn>_observed():`` basic stub
- Provides a ``@given``-decorated Hypothesis stub when argument types can be
  inferred from observed values

Output is plain Python source (``str``); callers decide where to write it.

Usage::

    from cairn.distill.templates import generate_stubs
    stubs = generate_stubs(records)          # {module_stem: python_source}
    for stem, source in stubs.items():
        Path(f".cairn/stubs/test_{stem}.py").write_text(source)

Or via the CLI::

    cairn templates [--output .cairn/stubs]
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from cairn.store.schema import TruthRecord

# ---------------------------------------------------------------------------
# Type inference helpers
# ---------------------------------------------------------------------------

_TYPE_MAP: dict[str, str] = {
    "str": "st.text()",
    "int": "st.integers()",
    "float": "st.floats(allow_nan=False)",
    "bool": "st.booleans()",
    "list": "st.lists(st.integers())",
    "dict": "st.dictionaries(st.text(), st.integers())",
    "bytes": "st.binary()",
    "NoneType": "st.none()",
}


def _infer_strategy(type_name: str) -> str:
    return _TYPE_MAP.get(type_name, "st.text()")


def _type_from_repr(repr_str: str) -> str | None:
    """Guess the Python type from a repr string."""
    s = repr_str.strip()
    if s.startswith(("b'", 'b"')):
        return "bytes"
    if s.startswith(("'", '"')):
        return "str"
    if s in ("True", "False"):
        return "bool"
    if s == "None":
        return "NoneType"
    if s.startswith("{"):
        return "dict"
    if s.startswith("["):
        return "list"
    if s.startswith("(") and "," in s:
        return "tuple"
    try:
        int(s)
        return "int"
    except ValueError:
        pass
    try:
        float(s)
        return "float"
    except ValueError:
        pass
    return None


def _infer_strategy_from_samples(type_name: str, samples: list[str]) -> str:
    """Produce a narrowed Hypothesis strategy using observed value reprs.

    Falls back to the generic default when samples cannot be parsed.
    """
    if type_name == "int":
        try:
            vals = [int(s.strip()) for s in samples
                    if s.strip() not in ("True", "False")]
            if vals:
                lo = min(vals)
                hi = max(vals)
                # Widen by 25 % on each side (floored to int, min range 1)
                margin = max(1, abs(hi - lo) // 4)
                return f"st.integers(min_value={lo - margin}, max_value={hi + margin})"
        except (ValueError, OverflowError):
            pass
        return "st.integers()"

    if type_name == "str":
        try:
            lengths = [
                len(s.strip()[1:-1])  # strip surrounding quotes
                for s in samples
                if s.strip().startswith(("'", '"'))
            ]
            if lengths:
                max_len = max(lengths)
                return f"st.text(max_size={max_len * 2})"
        except Exception:
            pass
        return "st.text()"

    if type_name == "float":
        try:
            vals = [float(s.strip()) for s in samples]
            lo, hi = min(vals), max(vals)
            if lo >= 0.0 and hi <= 1.0:
                return "st.floats(min_value=0.0, max_value=1.0, allow_nan=False)"
            margin = max(0.1, abs(hi - lo) * 0.25)
            return (
                f"st.floats(min_value={lo - margin!r}, "
                f"max_value={hi + margin!r}, allow_nan=False)"
            )
        except (ValueError, TypeError):
            pass
        return "st.floats(allow_nan=False)"

    return _infer_strategy(type_name)


def _extract_return_type(content: str) -> str | None:
    """Parse return type name from a 'RETURN fn → repr' content line."""
    match = re.search(r"RETURN .+ → (.+)$", content.splitlines()[0])
    if not match:
        return None
    return _type_from_repr(match.group(1).strip())


def _extract_fn_name(content: str) -> str | None:
    """Parse a function name from a CALL or RETURN content line."""
    match = re.match(r"(?:CALL|RETURN)\s+([\w.<>]+)", content)
    return match.group(1) if match else None


def _safe_name(qualname: str) -> str:
    """Convert 'ClassName.method_name' to a flat test function name."""
    return re.sub(r"[^a-zA-Z0-9_]", "_", qualname).strip("_").lower()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def generate_stubs(
    records: list[TruthRecord],
) -> dict[str, str]:
    """Generate stub Python source files from a list of monitor TruthRecords.

    Args:
        records: TruthRecord objects, typically filtered to source="monitor".

    Returns:
        Mapping of ``module_stem → python_source`` for each observed module.
        Keys are safe Python identifiers (e.g. ``"config"`` for
        ``/app/config.py``).
    """
    monitor = [r for r in records if r.source == "monitor"]
    if not monitor:
        return {}

    # Group CALL records by (source_file, fn_name)
    # Map: file_stem → {fn_name → FunctionObservation}
    observations: dict[str, dict[str, _FnObservation]] = defaultdict(
        lambda: defaultdict(_FnObservation)
    )

    for r in monitor:
        # RAISE records don't start with CALL/RETURN so handle them first.
        if r.content.startswith("RAISE"):
            exc_match = re.search(r"RAISE (\S+) (\w+):", r.content)
            if exc_match:
                fn = exc_match.group(1)
                exc = exc_match.group(2)
                stem = Path(r.source_file).stem if r.source_file else "unknown"
                obs = observations[stem][fn]
                obs.fn_name = fn
                obs.source_file = r.source_file
                obs.raises.add(exc)
            continue

        # WATCH records come from the @cairn.watch decorator and carry full
        # argument repr data — use them to narrow Hypothesis strategies.
        if r.content.startswith("WATCH"):
            first_line = r.content.splitlines()[0]
            watch_match = re.match(r"WATCH\s+([\w.<>]+)\((.*)\)\s*$", first_line)
            if watch_match:
                fn = watch_match.group(1)
                args_str = watch_match.group(2)
                stem = Path(r.source_file).stem if r.source_file else "unknown"
                obs = observations[stem][fn]
                obs.fn_name = fn
                obs.source_file = r.source_file
                obs.call_count += 1
                obs.depths.append(r.call_depth)
                obs.durations.append(r.duration_ms)
                # Parse "argname=repr_value" pairs
                for pair in re.split(r",\s*(?=[\w]+\s*=)", args_str):
                    if "=" in pair:
                        arg_name, _, arg_val = pair.partition("=")
                        obs.arg_observations.setdefault(
                            arg_name.strip(), []
                        ).append(arg_val.strip())
                # Parse return value line
                for line in r.content.splitlines()[1:]:
                    if line.startswith("return: "):
                        ret_repr = line[8:].strip()
                        ret_type = _type_from_repr(ret_repr)
                        if ret_type:
                            obs.return_types.add(ret_type)
            continue

        fn_name = _extract_fn_name(r.content)
        if not fn_name:
            continue
        file_stem = Path(r.source_file).stem if r.source_file else "unknown"
        obs = observations[file_stem][fn_name]

        if r.content.startswith("CALL"):
            obs.call_count += 1
            obs.source_file = r.source_file
            obs.fn_name = fn_name
            obs.depths.append(r.call_depth)
            obs.durations.append(r.duration_ms)
        elif r.content.startswith("RETURN"):
            obs.call_count_with_return += 1
            ret_type = _extract_return_type(r.content)
            if ret_type:
                obs.return_types.add(ret_type)

    results: dict[str, str] = {}
    for file_stem, fn_map in observations.items():
        source = _render_stub_file(file_stem, dict(fn_map))
        if source:
            results[file_stem] = source

    return results


def generate_stubs_markdown(records: list[TruthRecord]) -> str:
    """Return a single Markdown document summarising all observed functions
    with inline fenced Python stubs.  Suitable for inclusion in context.md."""
    stubs = generate_stubs(records)
    if not stubs:
        return ""

    parts = ["# Cairn — Generated Test Stubs\n",
             "_Auto-generated from runtime observations. Review before use._\n"]
    for stem, source in sorted(stubs.items()):
        parts.append(f"\n## `{stem}.py`\n\n```python\n{source}\n```\n")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


class _FnObservation:
    def __init__(self) -> None:
        self.fn_name: str = ""
        self.source_file: str | None = None
        self.call_count: int = 0
        self.call_count_with_return: int = 0
        self.return_types: set[str] = set()
        self.raises: set[str] = set()
        self.depths: list[int | None] = []
        self.durations: list[float | None] = []
        # argname -> list of observed repr strings (from @cairn.watch records)
        self.arg_observations: dict[str, list[str]] = {}


def _render_stub_file(file_stem: str, fn_map: dict[str, _FnObservation]) -> str:
    now = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    lines: list[str] = [
        f"# cairn-generated test stubs for {file_stem}.py — {now}",
        "# Review and complete before committing.",
        "#",
        "# Generated from runtime observations captured by cairn.",
        "# Each stub reflects the function's observed behaviour.",
        "",
        "from __future__ import annotations",
        "",
        "import pytest",
        "",
    ]

    has_hypothesis = any(obs.return_types for obs in fn_map.values())
    if has_hypothesis:
        lines += [
            "# Uncomment to enable property-based stubs:",
            "# from hypothesis import given, settings",
            "# import hypothesis.strategies as st",
            "",
        ]

    for fn_name, obs in sorted(fn_map.items()):
        if not obs.fn_name:
            obs.fn_name = fn_name
        lines += _render_fn_stub(obs)
        lines.append("")

    return "\n".join(lines)


def _render_fn_stub(obs: _FnObservation) -> list[str]:
    safe = _safe_name(obs.fn_name)
    ret_types = ", ".join(sorted(obs.return_types)) or "unknown"
    raises_str = ", ".join(sorted(obs.raises)) if obs.raises else "none observed"

    valid_depths = [d for d in obs.depths if d is not None]
    depth_avg = (
        f"{sum(valid_depths) / max(1, len(valid_depths)):.1f}"
        if valid_depths else "?"
    )
    valid_durs = [d for d in obs.durations if d is not None]
    dur_avg = (
        f"{sum(valid_durs) / max(1, len(valid_durs)):.2f}ms"
        if valid_durs else "?"
    )

    stub: list[str] = [
        f"# --- {obs.fn_name} ---",
        f"# Observed: {obs.call_count} call(s), return types: {ret_types}",
        f"# Exceptions raised: {raises_str}",
        f"# Avg call depth: {depth_avg}  |  Avg duration: {dur_avg}",
    ]

    if obs.source_file:
        stub.append(f"# Source: {obs.source_file}")
    stub.append("")

    # Basic stub
    stub += [
        f"def test_{safe}_observed():",
        f'    """Basic stub — {obs.call_count} invocation(s) observed.',
        "",
        f"    Return types seen: {ret_types}",
    ]
    if obs.raises:
        stub.append(f"    Exceptions seen: {raises_str}")
    stub += [
        '    """',
        f"    # TODO: import {obs.fn_name.split('.')[0]} and provide representative inputs",
        f"    # result = {obs.fn_name}(...)",
    ]
    if obs.return_types:
        for rt in sorted(obs.return_types):
            if rt != "NoneType":
                stub.append(f"    # assert isinstance(result, {rt})")
    if obs.raises:
        for exc in sorted(obs.raises):
            stub.append(f"    # with pytest.raises({exc}): {obs.fn_name}(<bad input>)")
    stub.append("    pass")

    # Hypothesis stub (only when we know at least one return type)
    if obs.return_types:
        # Build per-argument strategies from observed values
        arg_strategies: list[str] = []
        if obs.arg_observations:
            for arg_name, samples in obs.arg_observations.items():
                # Infer type from the most common repr form
                type_votes: Counter = Counter(
                    t for s in samples if (t := _type_from_repr(s)) is not None
                )
                if type_votes:
                    best_type = type_votes.most_common(1)[0][0]
                    strat = _infer_strategy_from_samples(best_type, samples)
                    arg_strategies.append(f"{arg_name}={strat}")

        if arg_strategies:
            given_args = ", ".join(arg_strategies)
            fn_args = ", ".join(obs.arg_observations.keys())
            stub += [
                "",
                "# Uncomment to enable property-based testing:",
                f"# @given({given_args})",
                f"# def test_{safe}_property({fn_args}):",
                f'#     """Property stub from {obs.call_count} cairn observation(s)."""',
                f"#     result = {obs.fn_name}({fn_args})",
            ]
        else:
            # No arg observations — fall back to generic st.text() placeholder
            stub += [
                "",
                "# Uncomment to enable property-based testing:",
                "# @given(st.text())  # refine strategies to match real arg types",
                f"# def test_{safe}_property(arg):",
                f'#     """Property stub from {obs.call_count} cairn observation(s)."""',
                f"#     result = {obs.fn_name}(arg)",
            ]
        for rt in sorted(obs.return_types):
            if rt != "NoneType":
                stub.append(f"#     assert isinstance(result, {rt})")  # noqa: E501

    return stub
