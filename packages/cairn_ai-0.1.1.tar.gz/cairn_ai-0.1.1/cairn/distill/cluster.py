"""Failure pattern clustering.

Groups TruthRecord objects into clusters by structural similarity:

- **pytest / monitor** records: primary key is ``exception_type``; within that,
  secondary grouping by the first non-whitespace token of the traceback (the
  innermost function name), giving clusters like ``ValueError::parse_config``.
- **ast** records: primary key is the check type (first colon-delimited token
  of ``content``, e.g. ``broad_except``, ``mutable_default``).
- **git** records: grouped as a single ``git::correlation`` cluster.
- **distill** records: pass-through, grouped by their ``pattern_cluster`` value.

The keys returned are stable strings suitable for use as ``pattern_cluster``
values when writing distilled TruthRecords back to the store.
"""

from __future__ import annotations

import re
from pathlib import Path

from cairn.store.schema import TruthRecord


def cluster(records: list[TruthRecord]) -> dict[str, list[TruthRecord]]:
    """Group records into clusters keyed by a stable cluster label.

    Args:
        records: any mix of TruthRecord objects.

    Returns:
        Dict mapping cluster label → member records, sorted by descending
        cluster size.
    """
    buckets: dict[str, list[TruthRecord]] = {}
    for r in records:
        key = _cluster_key(r)
        buckets.setdefault(key, []).append(r)
    # Return largest clusters first
    return dict(sorted(buckets.items(), key=lambda kv: -len(kv[1])))


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------

_INNER_FN = re.compile(r"in (\w+)\s*$", re.MULTILINE)


def _cluster_key(r: TruthRecord) -> str:
    if r.source in ("pytest", "monitor"):
        exc = r.exception_type or "no_exception"
        # Try to extract innermost function name from traceback
        fn_match = _INNER_FN.search(r.content)
        fn = fn_match.group(1) if fn_match else ""
        return f"{exc}::{fn}" if fn else exc

    if r.source == "ast":
        # content starts with "check_type: ..."
        return r.content.split(":")[0].strip()

    if r.source == "git":
        # Cluster by affected file so blame records for different modules
        # don't collapse into one useless mega-cluster.
        if r.source_file:
            stem = Path(r.source_file).stem
            return f"git::{stem}"
        return "git::correlation"

    if r.source == "distill":
        return r.pattern_cluster or "distill::unknown"

    return f"{r.source}::other"
