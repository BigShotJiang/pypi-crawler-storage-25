"""Margin-powered health classification for pattern clusters.

When ``margin`` is installed (``pip install cairn[health]``), each pattern
cluster is tracked as a margin component with:

- **DriftTracker**: trajectory analysis (STABLE / DRIFTING / ACCELERATING /
  DECELERATING / REVERTING / OSCILLATING) on failure count over time.
- **AnomalyTracker**: novelty classification (EXPECTED / UNUSUAL / ANOMALOUS /
  NOVEL) on observation frequency.
- **Health classification**: INTACT / DEGRADED / ABLATED based on failure
  count thresholds.

Without margin installed, all functions return ``None`` and the existing
exponential decay path in ``decay.py`` is used unchanged.

Usage::

    from cairn.distill.health import analyze_clusters, ClusterHealth

    results = analyze_clusters(clusters, all_records)
    for cluster_key, ch in results.items():
        print(ch.drift_state, ch.anomaly_state, ch.health)
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

from cairn.store.schema import TruthRecord

try:
    from margin import (
        Health,
        Thresholds,
        classify,
        Confidence,
    )
    from margin.streaming import DriftTracker, AnomalyTracker

    HAS_MARGIN = True
except ImportError:
    HAS_MARGIN = False


@dataclass
class ClusterHealth:
    """Health analysis for one pattern cluster."""

    cluster_key: str
    record_count: int
    observation_total: int  # sum of observation_count across records

    # margin fields (None when margin not installed)
    health: Optional[str] = None           # Health enum value
    drift_state: Optional[str] = None      # DriftState enum value
    drift_direction: Optional[str] = None  # DriftDirection enum value
    drift_rate: Optional[float] = None     # units/step
    anomaly_state: Optional[str] = None    # AnomalyState enum value
    anomaly_z_score: Optional[float] = None
    is_novel: bool = False

    # time-series data used for analysis
    weekly_counts: list[int] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "cluster_key": self.cluster_key,
            "record_count": self.record_count,
            "observation_total": self.observation_total,
        }
        if self.health is not None:
            d["health"] = self.health
        if self.drift_state is not None:
            d["drift"] = {
                "state": self.drift_state,
                "direction": self.drift_direction,
                "rate": self.drift_rate,
            }
        if self.anomaly_state is not None:
            d["anomaly"] = {
                "state": self.anomaly_state,
                "z_score": self.anomaly_z_score,
                "is_novel": self.is_novel,
            }
        return d

    @property
    def severity_score(self) -> float:
        """Numeric severity for sorting: higher = worse.

        Combines health state, drift direction, and anomaly novelty into
        a single comparable score.
        """
        score = 0.0
        health_weights = {
            "ABLATED": 3.0, "DEGRADED": 2.0, "RECOVERING": 1.5,
            "OOD": 1.0, "INTACT": 0.0,
        }
        score += health_weights.get(self.health or "INTACT", 0.0)

        if self.drift_direction == "WORSENING":
            score += 1.0
            if self.drift_state == "ACCELERATING":
                score += 1.0
        elif self.drift_direction == "IMPROVING":
            score -= 0.5

        anomaly_weights = {
            "NOVEL": 2.0, "ANOMALOUS": 1.5, "UNUSUAL": 0.5, "EXPECTED": 0.0,
        }
        score += anomaly_weights.get(self.anomaly_state or "EXPECTED", 0.0)
        return score

    def summary(self) -> str:
        """One-line human-readable summary."""
        parts = [self.cluster_key]
        if self.health:
            parts.append(self.health)
        if self.drift_state and self.drift_state != "STABLE":
            direction = f" {self.drift_direction}" if self.drift_direction else ""
            parts.append(f"{self.drift_state}{direction}")
        if self.anomaly_state and self.anomaly_state not in ("EXPECTED",):
            parts.append(self.anomaly_state)
        parts.append(f"{self.record_count} records")
        return " | ".join(parts)


def _build_weekly_series(
    records: list[TruthRecord],
    as_of: datetime | None = None,
    weeks: int = 12,
) -> list[int]:
    """Bin records into weekly buckets by occurred_at, most recent last."""
    now = as_of or datetime.now(tz=timezone.utc)
    buckets = [0] * weeks
    for r in records:
        occurred = r.occurred_at
        if occurred.tzinfo is None:
            occurred = occurred.replace(tzinfo=timezone.utc)
        age_days = (now - occurred).total_seconds() / 86400
        week_idx = int(age_days / 7)
        if 0 <= week_idx < weeks:
            # Reverse: index 0 = oldest, index -1 = most recent
            buckets[weeks - 1 - week_idx] += r.observation_count
    return buckets


def analyze_cluster(
    cluster_key: str,
    records: list[TruthRecord],
    as_of: datetime | None = None,
) -> ClusterHealth:
    """Analyze a single cluster using margin if available.

    Args:
        cluster_key: the cluster label.
        records: member records of the cluster.
        as_of: reference datetime (defaults to UTC now).

    Returns:
        ClusterHealth with margin fields populated when margin is installed.
    """
    now = as_of or datetime.now(tz=timezone.utc)
    obs_total = sum(r.observation_count for r in records)
    weekly = _build_weekly_series(records, as_of=now)

    ch = ClusterHealth(
        cluster_key=cluster_key,
        record_count=len(records),
        observation_total=obs_total,
        weekly_counts=weekly,
    )

    if not HAS_MARGIN or not weekly:
        return ch

    # --- Health classification ---
    # Thresholds: 0 failures/week = INTACT, >=5 = ABLATED (lower is better)
    thresholds = Thresholds(intact=0, ablated=5, higher_is_better=False)
    current_value = weekly[-1] if weekly else 0
    health_state = classify(current_value, Confidence.HIGH, thresholds=thresholds)
    ch.health = health_state.value

    # --- Drift tracking ---
    # Feed weekly counts as timestamped values into DriftTracker
    # lower_is_better for failure counts: fewer failures = healthier
    tracker = DriftTracker(
        component=cluster_key,
        window=len(weekly),
        min_samples=3,
    )
    baseline = sum(weekly) / max(1, len(weekly))
    for i, count in enumerate(weekly):
        # Assign synthetic timestamps (one week apart, oldest first)
        week_time = now - timedelta(weeks=len(weekly) - 1 - i)
        tracker.update_value(
            value=float(count),
            baseline=baseline,
            higher_is_better=False,  # fewer failures = better
            measured_at=week_time,
        )

    if tracker.classification:
        dc = tracker.classification
        ch.drift_state = dc.state.value
        ch.drift_direction = dc.direction.value
        ch.drift_rate = round(dc.rate, 4)

    # --- Anomaly tracking ---
    # Use all but last week as reference, classify the latest week
    anomaly_tracker = AnomalyTracker(
        component=cluster_key,
        window=max(4, len(weekly) - 1),
    )
    for count in weekly[:-1]:
        anomaly_tracker.update(float(count))

    if weekly:
        ac = anomaly_tracker.update(float(weekly[-1]))
        if ac:
            ch.anomaly_state = ac.state.value
            ch.anomaly_z_score = round(ac.z_score, 2)
            ch.is_novel = ac.is_novel

    return ch


def analyze_clusters(
    clusters: dict[str, list[TruthRecord]],
    as_of: datetime | None = None,
) -> dict[str, ClusterHealth]:
    """Analyze all clusters and return health info, sorted by severity.

    Args:
        clusters: mapping of cluster_key → member records (from
            ``cairn.distill.cluster.cluster()``).
        as_of: reference datetime (defaults to UTC now).

    Returns:
        Dict mapping cluster_key → ClusterHealth, sorted by severity
        (most severe first).
    """
    results = {}
    for key, members in clusters.items():
        results[key] = analyze_cluster(key, members, as_of=as_of)

    # Sort by severity (highest first), then by record count
    return dict(sorted(
        results.items(),
        key=lambda kv: (-kv[1].severity_score, -kv[1].record_count),
    ))
