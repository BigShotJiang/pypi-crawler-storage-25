"""Cross-cluster causal discovery via margin's correlation engine.

When ``margin`` is installed, this module discovers correlations between
pattern clusters based on their temporal co-occurrence:

- Clusters that spike together get a **CORRELATES** link.
- When one cluster consistently leads another (lag > 0), the leader gets
  a **DEGRADES** link to the follower (heuristic, not proven).

The result is a CausalGraph where nodes are cluster keys and edges are
typed relationships with strength and evidence.

Without margin installed, ``build_causal_graph()`` returns ``None``.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from cairn.store.schema import TruthRecord

try:
    from margin import (
        CauseType,
        CausalLink,
        CausalGraph,
        Observation,
        Health,
        Confidence,
        Ledger,
        Record,
        Expression,
    )
    from margin.correlate import (
        correlate,
        CorrelationMatrix,
    )

    HAS_MARGIN = True
except ImportError:
    HAS_MARGIN = False


@dataclass
class ClusterCausality:
    """Causal analysis results for a set of clusters."""

    graph: object  # CausalGraph when margin available, None otherwise
    root_clusters: list[str] = field(default_factory=list)
    leaf_clusters: list[str] = field(default_factory=list)
    links: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "root_clusters": self.root_clusters,
            "leaf_clusters": self.leaf_clusters,
            "links": self.links,
        }
        return d

    def explain(self, cluster_key: str) -> str:
        """Human-readable explanation of why a cluster is in its state."""
        if not HAS_MARGIN or self.graph is None:
            return ""

        causes = self.graph.causes_of(cluster_key)
        effects = self.graph.effects_of(cluster_key)

        parts = []
        if causes:
            cause_strs = [
                f"{l.source} --{l.cause_type.value}--> {cluster_key} "
                f"(strength {l.strength:.2f})"
                for l in causes
            ]
            parts.append("Caused by: " + "; ".join(cause_strs))

        if effects:
            effect_strs = [
                f"{cluster_key} --{l.cause_type.value}--> {l.target} "
                f"(strength {l.strength:.2f})"
                for l in effects
            ]
            parts.append("Affects: " + "; ".join(effect_strs))

        upstream = self.graph.upstream(cluster_key)
        if upstream:
            parts.append(f"Root causes: {', '.join(upstream)}")

        return " | ".join(parts) if parts else "No causal links discovered."


def _clusters_to_time_series(
    clusters: dict[str, list[TruthRecord]],
    as_of: datetime | None = None,
    weeks: int = 12,
) -> dict[str, list[float]]:
    """Convert clusters to aligned weekly time series for correlation."""
    now = as_of or datetime.now(tz=timezone.utc)
    series: dict[str, list[float]] = {}

    for key, records in clusters.items():
        buckets = [0.0] * weeks
        for r in records:
            occurred = r.occurred_at
            if occurred.tzinfo is None:
                occurred = occurred.replace(tzinfo=timezone.utc)
            age_days = (now - occurred).total_seconds() / 86400
            week_idx = int(age_days / 7)
            if 0 <= week_idx < weeks:
                buckets[weeks - 1 - week_idx] += r.observation_count
        series[key] = buckets

    return series


def build_causal_graph(
    clusters: dict[str, list[TruthRecord]],
    min_correlation: float = 0.7,
    max_lag: int = 3,
    as_of: datetime | None = None,
) -> ClusterCausality | None:
    """Build a CausalGraph from cross-cluster temporal correlations.

    Args:
        clusters: mapping of cluster_key -> member records.
        min_correlation: minimum correlation coefficient to create a link.
        max_lag: maximum lag (in weeks) for lead/follow detection.
        as_of: reference datetime (defaults to UTC now).

    Returns:
        ClusterCausality with the graph and summary, or None if margin
        is not installed or fewer than 2 clusters exist.
    """
    if not HAS_MARGIN:
        return None

    if len(clusters) < 2:
        return ClusterCausality(graph=CausalGraph())

    series = _clusters_to_time_series(clusters, as_of=as_of)

    # Need at least 5 data points for meaningful correlation
    min_samples = 5
    valid_series = {
        k: v for k, v in series.items()
        if sum(1 for x in v if x > 0) >= min_samples
    }

    if len(valid_series) < 2:
        return ClusterCausality(graph=CausalGraph())

    # Use margin's correlation engine
    matrix = correlate(valid_series, min_correlation=min_correlation,
                       max_lag=max_lag, min_samples=min_samples)

    # Convert to CausalGraph
    graph = matrix.to_causal_graph()

    links_dicts = [link.to_dict() for link in graph.links]

    return ClusterCausality(
        graph=graph,
        root_clusters=graph.roots(),
        leaf_clusters=graph.leaves(),
        links=links_dicts,
    )
