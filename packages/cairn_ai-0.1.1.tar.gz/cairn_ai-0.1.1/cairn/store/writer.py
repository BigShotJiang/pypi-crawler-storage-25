"""Idempotent SQLite upsert engine for TruthRecord objects."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from cairn.store.schema import SCHEMA_SQL, TruthRecord, record_to_row, row_to_record

_DEFAULT_DB = Path(".cairn") / "store.db"


def _connect(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA_SQL)
    _migrate(conn)
    return conn


def _migrate(conn: sqlite3.Connection) -> None:
    """Add columns introduced after the initial schema without dropping data."""
    existing = {row[1] for row in conn.execute("PRAGMA table_info(truth_records)")}
    additions = {
        "duration_ms": "REAL",
        "call_depth": "INTEGER",
        "observation_count": "INTEGER DEFAULT 1",
    }
    for col, col_type in additions.items():
        if col not in existing:
            conn.execute(f"ALTER TABLE truth_records ADD COLUMN {col} {col_type}")
    conn.commit()


class Writer:
    """Idempotent writer: upserts TruthRecords into the local SQLite store.

    If a record with the same ``id`` already exists, only ``confidence`` and
    ``occurred_at`` are updated (the content is stable by design).
    """

    def __init__(self, db_path: Path = _DEFAULT_DB) -> None:
        self._conn = _connect(db_path)
        self._embedder_available: bool | None = None  # lazy-checked

    def _try_embed(self, records: list[TruthRecord]) -> None:
        """Embed records in-place if an embedding backend is available."""
        if self._embedder_available is False:
            return
        # Only embed records that don't already have embeddings
        to_embed = [r for r in records if not r.embedding]
        if not to_embed:
            return
        try:
            from cairn.store.embedder import embed
            embed(to_embed)
            self._embedder_available = True
        except ImportError:
            # sentence-transformers not installed — disable permanently
            self._embedder_available = False
        except Exception:
            # Transient failure (OOM, cancelled download) — allow retry next call
            pass

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    _UPSERT_SQL = """
        INSERT INTO truth_records
            (id, source, domain, content, confidence, occurred_at,
             source_file, source_line, exception_type, pattern_cluster,
             duration_ms, call_depth, observation_count, embedding)
        VALUES
            (:id, :source, :domain, :content, :confidence, :occurred_at,
             :source_file, :source_line, :exception_type, :pattern_cluster,
             :duration_ms, :call_depth, :observation_count, :embedding)
        ON CONFLICT(id) DO UPDATE SET
            confidence       = MIN(1.0, truth_records.confidence + 0.005),
            occurred_at      = excluded.occurred_at,
            observation_count = COALESCE(truth_records.observation_count, 1) + 1,
            pattern_cluster  = COALESCE(excluded.pattern_cluster, truth_records.pattern_cluster),
            embedding        = COALESCE(excluded.embedding, truth_records.embedding)
    """

    def write(self, record: TruthRecord) -> None:
        """Upsert a single TruthRecord."""
        self._try_embed([record])
        row = record_to_row(record)
        self._conn.execute(self._UPSERT_SQL, row)
        self._conn.commit()

    def write_many(self, records: list[TruthRecord]) -> None:
        """Upsert a batch of TruthRecords efficiently."""
        self._try_embed(records)
        rows = [record_to_row(r) for r in records]
        self._conn.executemany(self._UPSERT_SQL, rows)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> Writer:
        return self

    def __exit__(self, *_) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Convenience helpers used by other subsystems
# ---------------------------------------------------------------------------

def get_all(db_path: Path = _DEFAULT_DB) -> list[TruthRecord]:
    """Return every record in the store, ordered by most recent first."""
    conn = _connect(db_path)
    rows = conn.execute(
        "SELECT * FROM truth_records ORDER BY occurred_at DESC"
    ).fetchall()
    conn.close()
    return [row_to_record(dict(r)) for r in rows]


def count(db_path: Path = _DEFAULT_DB) -> dict[str, int]:
    """Return per-source record counts."""
    conn = _connect(db_path)
    rows = conn.execute(
        "SELECT source, COUNT(*) AS n FROM truth_records GROUP BY source"
    ).fetchall()
    conn.close()
    return {r["source"]: r["n"] for r in rows}


def delete_by_ids(ids: list[str], db_path: Path = _DEFAULT_DB) -> int:
    """Delete records by their id list.  Returns the number of rows deleted."""
    if not ids:
        return 0
    conn = _connect(db_path)
    placeholders = ",".join("?" * len(ids))
    cur = conn.execute(
        f"DELETE FROM truth_records WHERE id IN ({placeholders})", ids
    )
    conn.commit()
    deleted = cur.rowcount
    conn.close()
    return deleted


def delete_by_source(source: str, db_path: Path = _DEFAULT_DB) -> int:
    """Delete all records with the given source tag.  Returns rows deleted."""
    conn = _connect(db_path)
    cur = conn.execute(
        "DELETE FROM truth_records WHERE source = ?", (source,)
    )
    conn.commit()
    deleted = cur.rowcount
    conn.close()
    return deleted


def update_embeddings(records: list[TruthRecord], db_path: Path = _DEFAULT_DB) -> int:
    """Write embeddings back to existing records without touching any other columns.

    Safe for use after embedding model upgrades or for backfilling records that
    were written by non-Python tools (nASTi-js, nASTi-go, etc.) and arrived
    with ``embedding = NULL``.  Returns the number of rows updated.
    """
    import json as _json

    if not records:
        return 0
    conn = _connect(db_path)
    updated = 0
    for r in records:
        if not r.embedding:
            continue
        conn.execute(
            "UPDATE truth_records SET embedding = ? WHERE id = ?",
            (_json.dumps(r.embedding), r.id),
        )
        updated += 1
    conn.commit()
    conn.close()
    return updated


def tag_cluster(
    ids: list[str],
    cluster_key: str,
    db_path: Path = _DEFAULT_DB,
) -> None:
    """Stamp *cluster_key* onto the ``pattern_cluster`` column for *ids*.

    Called after distillation so that source records carry the named cluster
    label and ``context.py`` doesn't have to re-cluster from scratch each run.
    """
    if not ids:
        return
    conn = _connect(db_path)
    placeholders = ",".join("?" * len(ids))
    conn.execute(
        f"UPDATE truth_records SET pattern_cluster = ?"
        f" WHERE id IN ({placeholders})",
        [cluster_key, *ids],
    )
    conn.commit()
    conn.close()
