"""Query interface — semantic + structured search over the truth store.

Functions
---------
- ``by_source``        — filter by source tag
- ``by_domain``        — filter by domain prefix (supports federation pattern)
- ``from_dbs``         — union query across multiple DB files (multi-tier federation)
- ``recent_failures``  — N most recent records with failure signal
- ``semantic_search``  — cosine similarity over embedded records; falls back to
                         keyword overlap (Jaccard) when embeddings are absent

Federation pattern
------------------
cairn stores are plain SQLite files.  Tiers are encoded in the DB file path
(commons, org, project); language+scope are encoded in the ``domain`` field.
To query across all tiers::

    records = from_dbs(
        [commons_python, org_db, project_db],
        domain_prefix="python/",
    )

Records from all DBs are merged and deduplicated by ``id``; when the same
record appears in multiple DBs the highest-confidence version wins.
"""

from __future__ import annotations

import math
from pathlib import Path

from cairn.store.schema import TruthRecord, row_to_record
from cairn.store.writer import _DEFAULT_DB, _connect


def by_source(source: str, db_path: Path = _DEFAULT_DB) -> list[TruthRecord]:
    """Return all records with the given source tag, newest first."""
    conn = _connect(db_path)
    rows = conn.execute(
        "SELECT * FROM truth_records WHERE source = ? ORDER BY occurred_at DESC",
        (source,),
    ).fetchall()
    conn.close()
    return [row_to_record(dict(r)) for r in rows]


def by_domain(
    domain_prefix: str,
    db_path: Path = _DEFAULT_DB,
) -> list[TruthRecord]:
    """Return all records whose domain matches *domain_prefix*, newest first.

    Matching rules
    ~~~~~~~~~~~~~~
    - Exact match: ``domain == domain_prefix``
    - Prefix match: ``domain`` starts with ``domain_prefix + "/"``

    So ``by_domain("python")`` returns records with domain ``"python"`` AND
    records with domain ``"python/stdlib"``, ``"python/acme.billing"``, etc.
    Passing ``"python/"`` (with trailing slash) performs a pure prefix match
    (no exact match on ``"python"`` itself).

    Returns an empty list (without creating the file) if *db_path* does not
    exist.

    Args:
        domain_prefix: domain string or prefix to match.
        db_path:        path to the SQLite store to query.
    """
    if not Path(db_path).exists():
        return []
    conn = _connect(db_path)
    # Strip trailing slash so "python/" and "python" both produce "python/%" in LIKE.
    like_prefix = domain_prefix.rstrip("/")
    # Use two OR branches so the index on domain is used for both arms.
    rows = conn.execute(
        """
        SELECT * FROM truth_records
        WHERE domain = ?
           OR domain LIKE ?
        ORDER BY occurred_at DESC
        """,
        (domain_prefix, f"{like_prefix}/%"),
    ).fetchall()
    conn.close()
    return [row_to_record(dict(r)) for r in rows]


def from_dbs(
    dbs: list[Path],
    *,
    domain_prefix: str = "",
    min_confidence: float = 0.0,
    top_k: int | None = None,
) -> list[TruthRecord]:
    """Union records from multiple DB files, deduplicating by ``id``.

    This is the primitive for multi-tier federation.  Pass DB paths from
    broadest (commons) to narrowest (project); when the same record appears in
    multiple DBs the highest-confidence copy is kept.

    Args:
        dbs:            DB paths to query.  Missing paths are silently skipped.
        domain_prefix:  if non-empty, filter to records matching this prefix
                        (same semantics as :func:`by_domain`).
        min_confidence: exclude records below this threshold.
        top_k:          cap the result list (sorted by confidence descending).

    Returns:
        Deduplicated list of :class:`~cairn.store.schema.TruthRecord`, sorted
        by confidence descending.

    Example::

        records = from_dbs(
            [Path("commons_python.db"), Path("org.db"), Path("project.db")],
            domain_prefix="python/",
            min_confidence=0.1,
            top_k=50,
        )
    """
    from cairn.store.writer import get_all

    seen: dict[str, TruthRecord] = {}  # id → highest-confidence record

    for db_path in dbs:
        if not Path(db_path).exists():
            continue
        records: list[TruthRecord] = (
            by_domain(domain_prefix, db_path) if domain_prefix else get_all(db_path)
        )
        for r in records:
            if r.confidence < min_confidence:
                continue
            existing = seen.get(r.id)
            if existing is None or r.confidence > existing.confidence:
                seen[r.id] = r

    results = sorted(seen.values(), key=lambda r: -r.confidence)
    if top_k is not None:
        results = results[:top_k]
    return results


def recent_failures(
    n: int = 50,
    db_path: Path = _DEFAULT_DB,
) -> list[TruthRecord]:
    """Return the *n* most recent records that carry failure signal."""
    conn = _connect(db_path)
    rows = conn.execute(
        """
        SELECT * FROM truth_records
        WHERE
            exception_type IS NOT NULL
            OR (source = 'pytest' AND content LIKE 'FAIL %')
            OR (source = 'monitor' AND content LIKE 'RAISE %')
        ORDER BY occurred_at DESC
        LIMIT ?
        """,
        (n,),
    ).fetchall()
    conn.close()
    return [row_to_record(dict(r)) for r in rows]


def semantic_search(
    query: str,
    top_k: int = 10,
    db_path: Path = _DEFAULT_DB,
) -> list[TruthRecord]:
    """Return the *top_k* most similar records to *query*.

    Uses cosine similarity over stored embeddings if available; otherwise falls
    back to Jaccard token overlap.
    """
    from cairn.store.writer import get_all

    records = get_all(db_path)
    if not records:
        return []

    has_embeddings = any(r.embedding for r in records)
    if has_embeddings:
        return _cosine_search(query, records, top_k)
    return _keyword_search(query, records, top_k)


# ---------------------------------------------------------------------------
# Search backends
# ---------------------------------------------------------------------------


def _cosine_search(
    query: str, records: list[TruthRecord], top_k: int
) -> list[TruthRecord]:
    from cairn.store.embedder import embed_query
    q_vec = embed_query(query)
    scored = [
        (_cosine(q_vec, r.embedding), r)
        for r in records if r.embedding
    ]
    scored.sort(key=lambda x: -x[0])
    return [r for _, r in scored[:top_k]]


def _keyword_search(
    query: str, records: list[TruthRecord], top_k: int
) -> list[TruthRecord]:
    from cairn.store.embedder import _tokenize
    q_tokens = set(_tokenize(query))
    if not q_tokens:
        return records[:top_k]
    scored = []
    for r in records:
        r_tokens = set(_tokenize(r.content))
        union = q_tokens | r_tokens
        jaccard = len(q_tokens & r_tokens) / len(union) if union else 0.0
        scored.append((jaccard, r))
    scored.sort(key=lambda x: -x[0])
    return [r for _, r in scored[:top_k]]


def _cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a)) or 1.0
    norm_b = math.sqrt(sum(x * x for x in b)) or 1.0
    return dot / (norm_a * norm_b)
