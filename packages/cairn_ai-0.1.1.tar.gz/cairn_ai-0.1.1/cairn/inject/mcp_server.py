"""MCP server \u2014 expose the Cairn truth store to any MCP-compatible agent.

Implements the Model Context Protocol (JSON-RPC 2.0 over stdio) so that
Claude Code, Cline, or any other MCP client can query the store during a
session without running cairn CLI commands.

Wire protocol
-------------
- Transport: stdio (newline-delimited JSON).
- Messages are JSON-RPC 2.0 objects.
- Server announces itself with ``serverInfo`` on ``initialize``.

Exposed tools
-------------
``cairn_status``
    Return per-source record counts from the truth store.

``cairn_search``
    Search the store by keyword/semantic query.  Returns top-K records.

``cairn_context``
    Return the full pre-built context snippet (same as ``cairn context``).

``cairn_recent_failures``
    Return the N most recent failure records.

Usage::

    cairn serve
    # or, directly:
    python -m cairn.inject.mcp_server
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

_DEFAULT_DB = Path(".cairn") / "store.db"

# Both values are pinned at server start, never accepted from the client.
# This prevents path-traversal via crafted tool arguments.
_server_db: Path = _DEFAULT_DB
_server_token: str | None = None  # None = open access (localhost-only is fine)

# ---------------------------------------------------------------------------
# Tool definitions (sent to client on tools/list)
# ---------------------------------------------------------------------------

_TOOLS = [
    {
        "name": "cairn_status",
        "description": "Return per-source record counts from the Cairn truth store.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "cairn_search",
        "description": (
            "Search the Cairn truth store by query string. "
            "Returns the top-K most relevant TruthRecord objects."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query."},
                "top_k": {"type": "integer", "description": "Max results (default 10)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "cairn_context",
        "description": "Return the full Cairn agent context snippet as Markdown.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "top_n": {"type": "integer", "description": "Max records to include (default 20)."},
            },
        },
    },
    {
        "name": "cairn_recent_failures",
        "description": "Return the N most recent failure records from the truth store.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "n": {"type": "integer", "description": "Number of records (default 20)."},
            },
        },
    },
    {
        "name": "cairn_health",
        "description": (
            "Analyse pattern cluster health using margin's drift tracking, "
            "anomaly detection, causal discovery, and escalation policy. "
            "Requires margin (pip install cairn[health]). Returns per-cluster "
            "health state (INTACT/DEGRADED/ABLATED), drift trajectory "
            "(STABLE/DRIFTING/ACCELERATING), anomaly classification "
            "(EXPECTED/NOVEL), escalation level (LOG/ALERT/HALT), and "
            "cross-cluster causal links."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "top_n": {
                    "type": "integer",
                    "description": "Max clusters to analyse (default 20).",
                },
            },
        },
    },
    {
        "name": "cairn_synthesis",
        "description": (
            "Analyse the Cairn truth store and produce a ranked intervention plan. "
            "Returns the top-N actionable patterns, scored by decayed confidence × "
            "git churn × observation count × category weight.  "
            "Categories: SECURITY (2×), RECURRING_FAILURE (1.5×), TYPE_BOUNDARY (1.3×), "
            "COVERAGE_GAP (1.2×), LINT (1×)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "top": {
                    "type": "integer",
                    "description": "Maximum number of interventions to return (default 5).",
                },
                "repo": {
                    "type": "string",
                    "description": (
                        "Absolute path to the git repository root for churn analysis. "
                        "Defaults to the current working directory."
                    ),
                },
                "since": {
                    "type": "string",
                    "description": "Git revision range for churn history (default: HEAD~30).",
                },
                "as_json": {
                    "type": "boolean",
                    "description": "Return structured JSON instead of Markdown (default false).",
                },
            },
        },
    },
]

# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


def _handle_cairn_status(args: dict) -> dict:
    from cairn.store.writer import count
    totals = count(_server_db) if _server_db.exists() else {}
    return {
        "total": sum(totals.values()),
        "by_source": totals,
        "store_path": str(_server_db),
    }


def _handle_cairn_search(args: dict) -> list[dict]:
    from cairn.store.query import semantic_search
    top_k = int(args.get("top_k", 10))
    records = semantic_search(args["query"], top_k=top_k, db_path=_server_db)
    return [
        {
            "id": r.id,
            "source": r.source,
            "domain": r.domain,
            "content": r.content,
            "confidence": r.confidence,
            "occurred_at": r.occurred_at.isoformat(),
            "source_file": r.source_file,
            "source_line": r.source_line,
            "exception_type": r.exception_type,
            "pattern_cluster": r.pattern_cluster,
        }
        for r in records
    ]


def _handle_cairn_context(args: dict) -> str:
    from cairn.inject.context import build_context
    top_n = int(args.get("top_n", 20))
    return build_context(top_n=top_n, db_path=_server_db)


def _handle_cairn_recent_failures(args: dict) -> list[dict]:
    from datetime import datetime, timezone
    from cairn.distill.decay import decayed_confidence
    from cairn.store.query import recent_failures
    n = int(args.get("n", 20))
    # Over-fetch so decay filtering doesn't starve the result set
    candidates = recent_failures(n=n * 3, db_path=_server_db)
    now = datetime.now(tz=timezone.utc)
    records = [
        r for r in candidates
        if decayed_confidence(r, now) >= 0.05
    ][:n]
    return [
        {
            "id": r.id,
            "source": r.source,
            "content": r.content.splitlines()[0],
            "confidence": r.confidence,
            "decayed_confidence": round(decayed_confidence(r, now), 4),
            "occurred_at": r.occurred_at.isoformat(),
            "exception_type": r.exception_type,
            "source_file": r.source_file,
        }
        for r in records
    ]


def _handle_cairn_health(args: dict) -> dict:
    """Analyse cluster health with margin-powered drift/anomaly/causality."""
    from cairn.distill.health import HAS_MARGIN, analyze_clusters
    from cairn.distill.cluster import cluster
    from cairn.distill.decay import apply_decay
    from cairn.store.writer import get_all

    if not HAS_MARGIN:
        return {"error": "margin not installed. Run: pip install cairn[health]"}

    from cairn.distill.escalation import evaluate_all
    from cairn.distill.causality import build_causal_graph

    top_n = int(args.get("top_n", 20))
    all_records = get_all(_server_db) if _server_db.exists() else []
    if not all_records:
        return {"clusters": [], "causal_links": []}

    live = apply_decay(all_records)[:top_n * 5]
    clusters = cluster(live)

    healths = analyze_clusters(clusters)
    escalations = evaluate_all(healths)
    causality = build_causal_graph(clusters)

    cluster_results = []
    for key, health in list(healths.items())[:top_n]:
        esc = escalations.get(key)
        entry = health.to_dict()
        if esc:
            entry["escalation"] = esc.to_dict()
        cluster_results.append(entry)

    result = {"clusters": cluster_results}
    if causality:
        result["causal_links"] = causality.links
        result["root_clusters"] = causality.root_clusters
        result["leaf_clusters"] = causality.leaf_clusters

    return result


def _handle_cairn_synthesis(args: dict) -> str:
    """Run synthesis analysis and return a ranked intervention report."""
    import sys
    from datetime import datetime, timezone
    from pathlib import Path as _Path

    # Make synthesis importable from the sibling repo layout.
    _automagic = _Path(__file__).resolve().parents[3]
    _synth_repo = _automagic / "synthesis"
    if _synth_repo.exists() and str(_synth_repo) not in sys.path:
        sys.path.insert(0, str(_synth_repo))

    try:
        from synthesis.git_churn import file_churn, normalize_churn
        from synthesis.ranker import rank_interventions
        from synthesis.reporter import render_json, render_report
    except ImportError as exc:
        return (
            f"synthesis package not available ({exc}). "
            "Install it with: pip install -e /path/to/automagic/synthesis/"
        )

    from cairn.store.writer import get_all

    top = int(args.get("top", 5))
    repo_str = args.get("repo", ".")
    since = args.get("since", "HEAD~30")
    as_json = bool(args.get("as_json", False))

    repo_root = _Path(repo_str).resolve()
    now = datetime.now(tz=timezone.utc)
    records = get_all(_server_db)

    raw_churn = file_churn(repo_root, since=since)
    norm_churn = normalize_churn(raw_churn)
    interventions = rank_interventions(records, churn=norm_churn, repo_root=repo_root, now=now)

    if as_json:
        return render_json(interventions, top=top)
    return render_report(
        interventions,
        db_paths=[_server_db],
        repo_root=repo_root,
        churn_raw=raw_churn,
        now=now,
        top=top,
    )


_HANDLERS = {
    "cairn_status": _handle_cairn_status,
    "cairn_search": _handle_cairn_search,
    "cairn_context": _handle_cairn_context,
    "cairn_recent_failures": _handle_cairn_recent_failures,
    "cairn_health": _handle_cairn_health,
    "cairn_synthesis": _handle_cairn_synthesis,
}

# ---------------------------------------------------------------------------
# JSON-RPC helpers
# ---------------------------------------------------------------------------


def _ok(req_id: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _err(req_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


def _send(obj: dict, out=None) -> None:
    out = out or sys.stdout
    out.write(json.dumps(obj) + "\n")
    out.flush()


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------


def dispatch(msg: dict, out=None) -> None:
    """Process one JSON-RPC message and write the response to *out*."""
    req_id = msg.get("id")
    method = msg.get("method", "")

    if method == "initialize":
        _send(_ok(req_id, {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "cairn", "version": "0.1.0"},
        }), out)

    elif method == "notifications/initialized":
        pass  # no response required

    elif method == "tools/list":
        _send(_ok(req_id, {"tools": _TOOLS}), out)

    elif method == "tools/call":
        params = msg.get("params", {})
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        handler = _HANDLERS.get(tool_name)
        if handler is None:
            _send(_err(req_id, -32601, f"Unknown tool: {tool_name}"), out)
            return
        try:
            result = handler(tool_args)
            body = json.dumps(result, indent=2)
            _send(_ok(req_id, {"content": [{"type": "text", "text": body}]}), out)
        except Exception as exc:
            _send(_err(req_id, -32000, str(exc)), out)

    elif method == "ping":
        _send(_ok(req_id, {}), out)

    else:
        if req_id is not None:
            _send(_err(req_id, -32601, f"Method not found: {method}"), out)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def serve(
    host: str = "127.0.0.1",
    port: int = 8765,
    transport: str = "stdio",
    db_path: Path | str = _DEFAULT_DB,
    token: str | None = None,
) -> None:
    """Start the Cairn MCP server.

    Args:
        host:      bind address for HTTP transport (ignored for stdio).
        port:      TCP port for HTTP transport (ignored for stdio).
        transport: ``"stdio"`` (default, for Cline / Claude Code) or
                   ``"http"`` for an HTTP + Server-Sent Events endpoint.
        db_path:   path to the SQLite store (pinned server-side; clients
                   cannot override this).
        token:     optional bearer token for /ingest and /query endpoints.
                   When set, requests without ``Authorization: Bearer <token>``
                   are rejected with 401.  Has no effect on stdio transport.
    """
    global _server_db, _server_token
    _server_db = Path(db_path)
    _server_token = token or None
    if transport == "http":
        _serve_http(host=host, port=port)
    else:
        _serve_stdio()


# ---------------------------------------------------------------------------
# stdio transport
# ---------------------------------------------------------------------------


def _serve_stdio() -> None:
    """Read newline-delimited JSON-RPC from stdin, respond to stdout."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError as exc:
            _send(_err(None, -32700, f"Parse error: {exc}"))
            continue
        dispatch(msg)


# ---------------------------------------------------------------------------
# HTTP + SSE transport
# ---------------------------------------------------------------------------


def _serve_http(host: str = "127.0.0.1", port: int = 8765) -> None:
    """Start an HTTP + Server-Sent Events MCP server.

    Wire protocol (MCP HTTP transport spec):
    - ``GET /sse``        — client opens an SSE stream; server immediately
                            sends an ``endpoint`` event with the POST URL the
                            client must use for its JSON-RPC messages.
    - ``POST /message``   — client sends a JSON-RPC request; server queues
                            the response back through the SSE stream for that
                            session.

    No external dependencies — uses Python's built-in ``http.server``.
    """
    import queue
    import threading
    import uuid
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import parse_qs, urlparse

    # session_id → queue of serialised JSON-RPC response strings
    _sessions: dict[str, queue.Queue] = {}
    _sessions_lock = threading.Lock()

    _host = host  # capture for closure
    _port = port

    class _MCPHandler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:
            pass  # suppress noisy default access log

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/sse":
                self._handle_sse()
            elif parsed.path == "/health":
                self._json_response(200, {"status": "ok", "store": str(_server_db)})
            else:
                self.send_error(404)

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/message":
                self._handle_message()
            elif parsed.path == "/ingest":
                if not self._check_auth():
                    return
                self._handle_rest_ingest()
            elif parsed.path == "/query":
                if not self._check_auth():
                    return
                self._handle_rest_query()
            else:
                self.send_error(404)

        def do_OPTIONS(self) -> None:  # noqa: N802
            self.send_response(204)
            self._cors_headers()
            self.end_headers()

        def _cors_headers(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

        def _check_auth(self) -> bool:
            """Return True if the request is authorised (or no token is required)."""
            if _server_token is None:
                return True
            auth = self.headers.get("Authorization", "")
            if auth == f"Bearer {_server_token}":
                return True
            self.send_error(401, "Unauthorized")
            return False

        def _json_response(self, code: int, data: Any) -> None:
            body = json.dumps(data).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self._cors_headers()
            self.end_headers()
            self.wfile.write(body)

        def _read_body(self) -> bytes:
            length = int(self.headers.get("Content-Length", 0) or 0)
            return self.rfile.read(length) if length else b""

        def _handle_rest_ingest(self) -> None:
            """POST /ingest — accept JSONL body, write TruthRecords to store."""
            from datetime import datetime, timezone
            from cairn.store.schema import TruthRecord
            from cairn.store.writer import Writer

            body = self._read_body().decode("utf-8", errors="replace")
            lines = [l.strip() for l in body.splitlines() if l.strip()]
            if not lines:
                self._json_response(400, {"error": "empty body"})
                return

            now = datetime.now(tz=timezone.utc)
            records: list[TruthRecord] = []
            errors: list[str] = []
            for i, line in enumerate(lines):
                try:
                    obj = json.loads(line)
                    if not isinstance(obj, dict) or "content" not in obj:
                        errors.append(f"line {i+1}: missing 'content' field")
                        continue
                    records.append(TruthRecord(
                        source=obj.get("source", "remote"),
                        domain=obj.get("domain", "remote"),
                        content=obj["content"],
                        confidence=float(obj.get("confidence", 1.0)),
                        occurred_at=now,
                        source_file=obj.get("source_file"),
                        source_line=obj.get("source_line"),
                        exception_type=obj.get("exception_type"),
                    ))
                except (json.JSONDecodeError, TypeError, ValueError) as exc:
                    errors.append(f"line {i+1}: {exc}")

            if records:
                w = Writer(db_path=_server_db)
                w.write_many(records)

            self._json_response(200, {
                "ingested": len(records),
                "errors": errors,
            })

        def _handle_rest_query(self) -> None:
            """POST /query — semantic/keyword search, returns JSON results."""
            from cairn.store.query import semantic_search

            body = self._read_body()
            try:
                params = json.loads(body) if body else {}
            except json.JSONDecodeError as exc:
                self._json_response(400, {"error": f"bad JSON: {exc}"})
                return

            q = params.get("q", "").strip()
            if not q:
                self._json_response(400, {"error": "'q' is required"})
                return

            top_k = int(params.get("top_k", 10))
            source = params.get("source")  # optional source filter applied post-search
            fetch_k = top_k * 3 if source else top_k
            all_records = semantic_search(q, top_k=fetch_k, db_path=_server_db)
            records = [r for r in all_records if r.source == source][:top_k] if source else all_records
            self._json_response(200, {
                "results": [
                    {
                        "id": r.id,
                        "source": r.source,
                        "domain": r.domain,
                        "content": r.content,
                        "confidence": r.confidence,
                        "occurred_at": r.occurred_at.isoformat(),
                        "source_file": r.source_file,
                        "source_line": r.source_line,
                        "exception_type": r.exception_type,
                        "pattern_cluster": r.pattern_cluster,
                    }
                    for r in records
                ]
            })

        def _handle_sse(self) -> None:
            session_id = str(uuid.uuid4())
            q: queue.Queue = queue.Queue()
            with _sessions_lock:
                _sessions[session_id] = q

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self._cors_headers()
            self.end_headers()

            # Tell the client which URL to POST messages to
            endpoint_url = f"http://{_host}:{_port}/message?sessionId={session_id}"
            self.wfile.write(f"event: endpoint\ndata: {endpoint_url}\n\n".encode())
            self.wfile.flush()

            try:
                while True:
                    try:
                        msg_str = q.get(timeout=25)
                    except queue.Empty:
                        # Keepalive comment — prevents proxies from closing the stream
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                        continue

                    if msg_str is None:  # shutdown sentinel
                        break

                    self.wfile.write(f"event: message\ndata: {msg_str}\n\n".encode())
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                with _sessions_lock:
                    _sessions.pop(session_id, None)

        def _handle_message(self) -> None:
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            session_id = (qs.get("sessionId") or [None])[0]

            with _sessions_lock:
                q = _sessions.get(session_id) if session_id else None

            if q is None:
                self.send_error(404, "Session not found — open /sse first")
                return

            body = self._read_body()

            # Acknowledge immediately; response arrives via SSE
            self.send_response(202)
            self.send_header("Content-Length", "0")
            self._cors_headers()
            self.end_headers()

            def _dispatch_and_enqueue() -> None:
                collected: list[str] = []

                class _Collector:
                    def write(self, s: str) -> None:
                        collected.append(s)
                    def flush(self) -> None:
                        pass

                try:
                    rpc_msg = json.loads(body)
                    dispatch(rpc_msg, out=_Collector())
                    for line in collected:
                        stripped = line.strip()
                        if stripped:
                            q.put(stripped)
                except Exception as exc:
                    q.put(json.dumps(_err(None, -32700, str(exc))))

            threading.Thread(target=_dispatch_and_enqueue, daemon=True).start()

    server = HTTPServer((host, port), _MCPHandler)
    print(  # noqa: T201
        f"Cairn MCP HTTP+SSE server → http://{host}:{port}/sse",
        file=sys.stderr,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    serve()

