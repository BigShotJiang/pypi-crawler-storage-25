"""@cairn.watch decorator — fallback capture for Python < 3.12 and targeted tracing.

Wraps a function to record call arguments, return value, exceptions, and duration.
"""

from __future__ import annotations

import functools
import inspect
import time
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import TypeVar

F = TypeVar("F", bound=Callable)

_DEFAULT_DB = Path(".cairn") / "store.db"


def watch(fn: F) -> F:
    """Decorator: instrument a function for Cairn capture.

    Usage::

        import cairn

        @cairn.watch
        def parse_manifest(path: str) -> dict:
            ...
    """

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        try:
            result = fn(*args, **kwargs)
            _record_call(fn, args, kwargs, result, None, time.perf_counter() - start)
            return result
        except Exception as exc:
            _record_call(fn, args, kwargs, None, exc, time.perf_counter() - start)
            raise

    return wrapper  # type: ignore[return-value]


def _record_call(fn, args, kwargs, result, exc, duration: float) -> None:
    """Build and persist a TruthRecord for a single decorated function call."""
    from cairn.store.schema import TruthRecord
    from cairn.store.writer import Writer

    module = fn.__module__ or ""
    qualname = f"{module}.{fn.__qualname__}" if module else fn.__qualname__
    domain = module.split(".")[0] if module else fn.__qualname__

    # Safe repr helpers — never let repr() crash the instrumentation
    def _safe_repr(v, limit: int = 200) -> str:
        try:
            r = repr(v)
            return r if len(r) <= limit else r[:limit] + "…"
        except Exception:
            return "<unrepresentable>"

    # Build argument map using inspect so positional names are included
    try:
        sig = inspect.signature(fn)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        arg_repr = ", ".join(f"{k}={_safe_repr(v)}" for k, v in bound.arguments.items())
    except Exception:
        arg_repr = ", ".join(_safe_repr(a) for a in args)

    if exc is not None:
        exc_type = type(exc).__name__
        content = (
            f"WATCH {qualname}({arg_repr})\n"
            f"exception: {exc_type}: {_safe_repr(exc)}\n"
            f"duration: {duration * 1000:.2f}ms"
        )
    else:
        content = (
            f"WATCH {qualname}({arg_repr})\n"
            f"return: {_safe_repr(result)}\n"
            f"duration: {duration * 1000:.2f}ms"
        )

    # Best-effort: locate source file
    try:
        source_file = inspect.getfile(fn)
        source_line = inspect.getsourcelines(fn)[1]
    except Exception:
        source_file, source_line = None, None

    record = TruthRecord(
        source="monitor",
        domain=domain,
        content=content,
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
        source_file=source_file,
        source_line=source_line,
        exception_type=type(exc).__name__ if exc is not None else None,
    )

    try:
        with Writer(_DEFAULT_DB) as w:
            w.write(record)
    except Exception:
        # Instrumentation must never crash user code
        pass
