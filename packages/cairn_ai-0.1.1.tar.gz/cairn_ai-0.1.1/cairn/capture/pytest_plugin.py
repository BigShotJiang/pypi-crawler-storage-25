"""pytest plugin — auto-registered via the ``pytest11`` entry point.

Captures rich signal per test:
- pass / fail outcome
- assertion values and local variable state at failure
- which source lines were implicated (via ``ExceptionInfo.traceback``)

Records are written to the local Cairn SQLite store at session end.
"""

from __future__ import annotations

import traceback
from datetime import datetime, timezone
from pathlib import Path

import pytest

from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

# ---------------------------------------------------------------------------
# Plugin class
# ---------------------------------------------------------------------------


class CairnPlugin:
    def __init__(self) -> None:
        self._records: list[TruthRecord] = []
        self._domain = _infer_domain()

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item: pytest.Item, call: pytest.CallInfo):
        outcome = yield
        report: pytest.TestReport = outcome.get_result()

        if report.when != "call":
            return

        now = datetime.now(tz=timezone.utc)

        if report.passed:
            self._records.append(
                TruthRecord(
                    source="pytest",
                    domain=self._domain,
                    content=f"PASS {item.nodeid}",
                    confidence=1.0,
                    occurred_at=now,
                    source_file=_item_path(item),
                )
            )
        elif report.failed:
            exc_info = call.excinfo
            exc_type = type(exc_info.value).__name__ if exc_info else "Unknown"
            tb_summary = _format_tb(exc_info)
            local_vars = _local_vars_at_failure(exc_info)

            content_parts = [f"FAIL {item.nodeid}", f"exception: {exc_type}"]
            if tb_summary:
                content_parts.append(f"traceback:\n{tb_summary}")
            if local_vars:
                content_parts.append(f"locals:\n{local_vars}")

            source_file, source_line = _failure_location(exc_info)

            self._records.append(
                TruthRecord(
                    source="pytest",
                    domain=self._domain,
                    content="\n".join(content_parts),
                    confidence=1.0,
                    occurred_at=now,
                    source_file=source_file,
                    source_line=source_line,
                    exception_type=exc_type,
                )
            )

    def pytest_sessionfinish(self, session: pytest.Session, exitstatus: int) -> None:
        if not self._records:
            return
        db_path = Path(session.config.rootpath) / ".cairn" / "store.db"
        with Writer(db_path) as w:
            w.write_many(self._records)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def pytest_configure(config: pytest.Config) -> None:
    config.pluginmanager.register(CairnPlugin(), "cairn_plugin")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _infer_domain() -> str:
    """Best-effort: use the git repo name or cwd name as the domain."""
    try:
        import subprocess

        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode == 0:
            return Path(result.stdout.strip()).name
    except Exception:
        pass
    return Path.cwd().name


def _item_path(item: pytest.Item) -> str | None:
    try:
        return str(item.fspath)
    except Exception:
        return None


def _format_tb(exc_info) -> str:
    if exc_info is None:
        return ""
    try:
        return "".join(traceback.format_tb(exc_info.tb))
    except Exception:
        return ""


def _local_vars_at_failure(exc_info) -> str:
    """Extract local variable state from the innermost frame of the traceback."""
    if exc_info is None:
        return ""
    try:
        tb = exc_info.tb
        while tb.tb_next:
            tb = tb.tb_next
        frame = tb.tb_frame
        lines = []
        for name, value in frame.f_locals.items():
            try:
                repr_val = repr(value)
                # Truncate very long reprs to keep records readable
                if len(repr_val) > 200:
                    repr_val = repr_val[:200] + "…"
                lines.append(f"  {name} = {repr_val}")
            except Exception:
                lines.append(f"  {name} = <unrepresentable>")
        return "\n".join(lines)
    except Exception:
        return ""


def _failure_location(exc_info) -> tuple[str | None, int | None]:
    """Return (file, line) of the innermost traceback frame."""
    if exc_info is None:
        return None, None
    try:
        tb = exc_info.tb
        while tb.tb_next:
            tb = tb.tb_next
        return tb.tb_frame.f_code.co_filename, tb.tb_lineno
    except Exception:
        return None, None
