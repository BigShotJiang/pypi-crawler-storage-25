"""cairn prime — batch-ingest a git repository's history into a baseline store.

Walks a git repository's commit history, filters to high-signal commits
(regression fixes, CVEs, test-correlated changes), and writes TruthRecords
to an output SQLite store.  The resulting ``.db`` is suitable for
distribution as a "baseline" artifact that projects seed with ``cairn sync``.

Filter heuristics (commits are included when ANY condition is true):

* Subject matches ``fix_pattern``  (fix, bug, cve, regression, crash, …)
* Changed files include ``test_*.py`` / ``*_test.py`` patterns

Exclusions (always skipped):

* Merge commits
* Doc-only changes (all changed files carry documentation-only suffixes)
* Empty commits (no changed files at all)

Progress is checkpointed inside the output database so interrupted runs
resume without re-processing already-examined commits.
"""

from __future__ import annotations

import re
import sqlite3
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterator

from cairn.store.schema import TruthRecord

# ---------------------------------------------------------------------------
# Compile-time constants
# ---------------------------------------------------------------------------

_EXCEPTION_RE: re.Pattern = re.compile(
    r"\b([A-Z][a-zA-Z]+(?:Error|Exception|Warning|Fault|Panic|Failure|Abort))\b"
)

DEFAULT_FIX_PATTERN: re.Pattern = re.compile(
    r"\b(fix|bug|error|exception|crash|regression|cve|security|vulnerab"
    r"|workaround|incorrect|broken|invalid|assert|revert|segfault|memory.leak"
    r"|use.after.free|null.pointer|buffer.overflow)\b",
    re.IGNORECASE,
)

_DOC_ONLY_SUFFIXES: frozenset[str] = frozenset({
    ".rst", ".txt", ".md", ".csv", ".cfg", ".ini", ".po", ".pot",
    ".tex", ".texi", ".asciidoc", ".adoc",
})

_TEST_FILE_RE: re.Pattern = re.compile(
    r"(^|[/\\])tests?[/\\]|[/\\]tests?_|_tests?\.py$|test_[^/\\]+\.py$",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Checkpoint helpers
# ---------------------------------------------------------------------------

_CHECKPOINT_DDL = """
CREATE TABLE IF NOT EXISTS _prime_checkpoint (
    sha TEXT PRIMARY KEY
);
"""


def _ensure_checkpoint_table(db_path: Path) -> None:
    conn = sqlite3.connect(db_path)
    conn.executescript(_CHECKPOINT_DDL)
    conn.commit()
    conn.close()


def _load_seen(db_path: Path) -> set[str]:
    if not db_path.exists():
        return set()
    try:
        conn = sqlite3.connect(db_path)
        rows = conn.execute("SELECT sha FROM _prime_checkpoint").fetchall()
        conn.close()
        return {r[0] for r in rows}
    except sqlite3.OperationalError:
        return set()


def _save_seen(db_path: Path, shas: list[str]) -> None:
    if not shas:
        return
    conn = sqlite3.connect(db_path)
    conn.executemany(
        "INSERT OR IGNORE INTO _prime_checkpoint (sha) VALUES (?)",
        [(s,) for s in shas],
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------

def _run_git(args: list[str], cwd: Path, timeout: int = 60) -> str:
    try:
        r = subprocess.run(
            args, cwd=cwd, capture_output=True, text=True, timeout=timeout
        )
        return r.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ""


def _iter_commits(
    repo_root: Path,
    since: str | None = None,
    until: str | None = None,
) -> Iterator[tuple[str, str, datetime]]:
    """Yield (sha, subject, authored_at) for every non-merge commit."""
    fmt = "%H\x1f%aI\x1f%s"
    args = ["git", "log", f"--format={fmt}", "--no-merges"]
    if since:
        args.extend(["--after", since])
    if until:
        args.extend(["--before", until])

    out = _run_git(args, repo_root, timeout=300)
    for line in out.splitlines():
        parts = line.split("\x1f", 2)
        if len(parts) < 3:
            continue
        sha, iso, subject = parts
        sha = sha.strip()
        subject = subject.strip()
        try:
            ts = datetime.fromisoformat(iso.strip())
        except ValueError:
            ts = datetime.now(tz=timezone.utc)
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        yield sha, subject, ts


def _changed_files(repo_root: Path, sha: str) -> list[str]:
    """Return the list of changed paths for a single commit."""
    out = _run_git(
        ["git", "diff-tree", "--no-commit-id", "-r", "--name-only", sha],
        repo_root,
        timeout=10,
    )
    return [f.strip() for f in out.splitlines() if f.strip()]


# ---------------------------------------------------------------------------
# Signal classification helpers
# ---------------------------------------------------------------------------

def _is_doc_only(files: list[str]) -> bool:
    """True when every changed file carries a documentation-only suffix."""
    if not files:
        return True
    return all(Path(f).suffix.lower() in _DOC_ONLY_SUFFIXES for f in files)


def _has_test_file(files: list[str]) -> bool:
    """True when at least one changed file looks like a test module."""
    return any(_TEST_FILE_RE.search(f) for f in files)


def _extract_exceptions(text: str) -> list[str]:
    """Return deduplicated exception/error type names found in *text*."""
    seen: dict[str, None] = {}
    for m in _EXCEPTION_RE.finditer(text):
        seen[m.group(1)] = None
    return list(seen)


def _build_content(
    sha: str,
    subject: str,
    files: list[str],
    exceptions: list[str],
) -> str:
    lines = [f"FIX {sha[:12]} {subject}"]
    if files:
        top = files[:5]
        files_str = ", ".join(Path(f).name for f in top)
        if len(files) > 5:
            files_str += f" (+{len(files) - 5} more)"
        lines.append(f"files: {files_str}")
    if exceptions:
        lines.append(f"exceptions: {', '.join(exceptions)}")
    return "\n".join(lines)


def _commit_confidence(
    subject: str,
    files: list[str],
    fix_pattern: re.Pattern,
) -> float:
    """Assign a base confidence score based on commit signal quality."""
    text_lower = subject.lower()
    if re.search(r"\bcve\b", text_lower):
        conf = 0.85
    elif re.search(r"\b(regression|crash|security|vulnerab|segfault|memory.leak|buffer.overflow)\b",
                   text_lower):
        conf = 0.75
    elif fix_pattern.search(subject):
        conf = 0.65
    else:
        # Included only because of test file — moderate confidence
        conf = 0.55
    if _has_test_file(files):
        conf = min(1.0, conf + 0.05)
    return conf


# ---------------------------------------------------------------------------
# Core public function
# ---------------------------------------------------------------------------

def prime(
    repo_root: Path,
    output_db: Path,
    domain: str | None = None,
    fix_pattern: re.Pattern = DEFAULT_FIX_PATTERN,
    batch_size: int = 200,
    limit: int | None = None,
    since: str | None = None,
    until: str | None = None,
    verbose: bool = False,
    progress_cb: Callable[[int, int], None] | None = None,
) -> tuple[int, int]:
    """Walk *repo_root*'s commit history and write high-signal TruthRecords.

    Args:
        repo_root:   Path to the git repository root.
        output_db:   Path to the output SQLite store (created if absent).
        domain:      Domain tag applied to every written record.
                     Defaults to the repository directory name.
        fix_pattern: Compiled regex matched against commit subjects to decide
                     whether a commit is "high-signal".
        batch_size:  Number of commits examined between each write + checkpoint.
        limit:       Stop after writing this many records (for smoke tests).
        since:       Only examine commits after this date (``YYYY-MM-DD``).
        until:       Only examine commits before this date (``YYYY-MM-DD``).
        verbose:     Print each accepted commit to stderr.
        progress_cb: Optional callable invoked after each batch flush with
                     ``(examined, written)`` counts.

    Returns:
        ``(examined, written)`` — total commits inspected and records written.
    """
    from cairn.store.writer import Writer

    repo_root = repo_root.resolve()
    domain = domain or repo_root.name

    output_db.parent.mkdir(parents=True, exist_ok=True)
    _ensure_checkpoint_table(output_db)
    seen = _load_seen(output_db)

    examined = 0
    written = 0
    write_batch: list[TruthRecord] = []
    checkpoint_batch: list[str] = []

    for sha, subject, ts in _iter_commits(repo_root, since=since, until=until):
        if sha in seen:
            continue

        files = _changed_files(repo_root, sha)

        # --- Exclusions ---
        if not files or _is_doc_only(files):
            seen.add(sha)
            checkpoint_batch.append(sha)
        else:
            # --- Inclusion test ---
            passes = bool(fix_pattern.search(subject)) or _has_test_file(files)

            seen.add(sha)
            checkpoint_batch.append(sha)
            examined += 1

            if passes:
                if limit is not None and written >= limit:
                    break

                exceptions = _extract_exceptions(subject)
                content = _build_content(sha, subject, files, exceptions)
                confidence = _commit_confidence(subject, files, fix_pattern)

                # Pick the first non-doc file as the representative source_file
                rep_file: str | None = next(
                    (f for f in files if not _is_doc_only([f])), None
                )

                write_batch.append(TruthRecord(
                    source="git-prime",
                    domain=domain,
                    content=content,
                    confidence=confidence,
                    occurred_at=ts,
                    source_file=rep_file,
                    exception_type=exceptions[0] if exceptions else None,
                ))
                written += 1

                if verbose:
                    import sys
                    print(f"  [{written:>6}] {sha[:10]} {subject[:65]}", file=sys.stderr)

        # --- Flush batch ---
        if len(checkpoint_batch) >= batch_size:
            if write_batch:
                with Writer(output_db) as w:
                    w.write_many(write_batch)
                write_batch.clear()
            _save_seen(output_db, checkpoint_batch)
            checkpoint_batch.clear()
            if progress_cb:
                progress_cb(examined, written)

    # --- Final flush ---
    if write_batch:
        with Writer(output_db) as w:
            w.write_many(write_batch)
    if checkpoint_batch:
        _save_seen(output_db, checkpoint_batch)
    if progress_cb:
        progress_cb(examined, written)

    return examined, written
