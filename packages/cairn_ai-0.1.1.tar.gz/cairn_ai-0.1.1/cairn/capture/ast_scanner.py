"""AST scanner — structural analysis of Python source files.

Detects and emits TruthRecord objects (source="ast") for:

- **broad_except**      bare ``except:`` or ``except (Exception|BaseException):``
- **mutable_default**   list/dict/set literal as a function-parameter default
- **deep_nesting**      compound statements nested beyond ``MAX_NESTING_DEPTH``
- **missing_annotation** function parameters or return types without annotations
- **unreachable_code**  statements after ``return`` / ``raise`` / ``break`` /
                        ``continue`` in the same block

Confidence is fixed per check type — these are structural observations, not
runtime confirmations.  The distillation pass will weight them against
re-observed runtime failures.
"""

from __future__ import annotations

import ast
from datetime import datetime, timezone
from pathlib import Path

from cairn.store.schema import TruthRecord

# ---------------------------------------------------------------------------
# Tunables
# ---------------------------------------------------------------------------

MAX_NESTING_DEPTH = 4  # compound statements before flagging deep nesting

# Confidence values per check (not yet runtime-corroborated)
_CONF = {
    "broad_except": 0.85,
    "mutable_default": 0.90,
    "deep_nesting": 0.70,
    "missing_annotation": 0.60,
    "unreachable_code": 0.95,
    "magic_number": 0.65,
    "print_statement": 0.75,
    "assert_in_library": 0.80,
    "fstring_in_logging": 0.85,
}

# Types that increase nesting depth
_NESTING_NODES = (
    ast.If,
    ast.For,
    ast.While,
    ast.With,
    ast.Try,
    ast.ExceptHandler,
    ast.AsyncFor,
    ast.AsyncWith,
)

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scan(path: Path) -> list[TruthRecord]:
    """Scan a single ``.py`` file and return structural TruthRecords.

    Args:
        path: path to the Python source file.

    Returns:
        List of ``TruthRecord`` objects; empty list if the file cannot be parsed.
    """
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return []

    domain = _domain_from_path(path)
    visitor = _ASTScanner(str(path), domain)
    visitor.visit(tree)
    return visitor.records


def scan_project(root: Path, exclude: list[str] | None = None) -> list[TruthRecord]:
    """Recursively scan all ``.py`` files under *root*.

    Args:
        root:    directory to walk.
        exclude: directory name fragments to skip (default: common noise dirs).
    """
    defaults = {".venv", "venv", ".git", "__pycache__", "node_modules", "dist", "build"}
    skip = defaults | set(exclude) if exclude else defaults
    records: list[TruthRecord] = []
    for py_file in root.rglob("*.py"):
        if any(part in skip for part in py_file.parts):
            continue
        records.extend(scan(py_file))
    return records


# ---------------------------------------------------------------------------
# Visitor
# ---------------------------------------------------------------------------


class _ASTScanner(ast.NodeVisitor):
    def __init__(self, filepath: str, domain: str) -> None:
        self._file = filepath
        self._domain = domain
        self._nesting: int = 0
        self.records: list[TruthRecord] = []

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _emit(self, check: str, content: str, lineno: int) -> None:
        self.records.append(
            TruthRecord(
                source="ast",
                domain=self._domain,
                content=content,
                confidence=_CONF[check],
                occurred_at=datetime.now(tz=timezone.utc),
                source_file=self._file,
                source_line=lineno,
            )
        )

    # ------------------------------------------------------------------
    # Nesting depth tracker
    # ------------------------------------------------------------------

    def _visit_nesting(self, node: ast.AST) -> None:
        self._nesting += 1
        if self._nesting > MAX_NESTING_DEPTH:
            self._emit(
                "deep_nesting",
                f"deep_nesting: {type(node).__name__} nested {self._nesting} levels deep "
                f"(max {MAX_NESTING_DEPTH}) at line {node.lineno}",  # type: ignore[attr-defined]
                node.lineno,  # type: ignore[attr-defined]
            )
        self.generic_visit(node)
        self._nesting -= 1

    def visit_If(self, node: ast.If) -> None:
        self._visit_nesting(node)

    def visit_For(self, node: ast.For) -> None:
        self._visit_nesting(node)

    def visit_AsyncFor(self, node: ast.AsyncFor) -> None:
        self._visit_nesting(node)

    def visit_While(self, node: ast.While) -> None:
        self._visit_nesting(node)

    def visit_With(self, node: ast.With) -> None:
        self._visit_nesting(node)

    def visit_AsyncWith(self, node: ast.AsyncWith) -> None:
        self._visit_nesting(node)

    def visit_Try(self, node: ast.Try) -> None:
        self._visit_nesting(node)

    # ------------------------------------------------------------------
    # Broad except (also tracks nesting)
    # ------------------------------------------------------------------

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        if node.type is None:
            # bare except:
            self._emit(
                "broad_except",
                f"broad_except: bare 'except:' at line {node.lineno} catches everything "
                "including KeyboardInterrupt and SystemExit",
                node.lineno,
            )
        elif isinstance(node.type, ast.Name) and node.type.id in ("Exception", "BaseException"):
            self._emit(
                "broad_except",
                f"broad_except: 'except {node.type.id}:' at line {node.lineno} — "
                "consider catching a more specific exception type",
                node.lineno,
            )
        elif isinstance(node.type, ast.Tuple):
            broad = [
                n.id for n in node.type.elts
                if isinstance(n, ast.Name) and n.id in ("Exception", "BaseException")
            ]
            if broad:
                self._emit(
                    "broad_except",
                    f"broad_except: except tuple includes {broad} at line {node.lineno}",
                    node.lineno,
                )
        self._visit_nesting(node)

    # ------------------------------------------------------------------
    # Mutable defaults
    # ------------------------------------------------------------------

    def _check_defaults(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        all_args = node.args.args + node.args.posonlyargs + node.args.kwonlyargs
        # defaults align to the *end* of args; kwonlyargs use kw_defaults (may be None)
        defaults = node.args.defaults
        offset = len(all_args) - len(defaults)
        for i, default in enumerate(defaults):
            if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                argname = all_args[offset + i].arg if (offset + i) < len(all_args) else "?"
                kind = type(default).__name__.lower()
                self._emit(
                    "mutable_default",
                    f"mutable_default: parameter '{argname}' in '{node.name}' has a "
                    f"mutable {kind} default at line {default.lineno} — "
                    "shared across all calls; use None and assign inside the function",
                    default.lineno,
                )
        # Also check kw_defaults
        for arg, default in zip(node.args.kwonlyargs, node.args.kw_defaults):
            if default is not None and isinstance(default, (ast.List, ast.Dict, ast.Set)):
                kind = type(default).__name__.lower()
                self._emit(
                    "mutable_default",
                    f"mutable_default: kwarg '{arg.arg}' in '{node.name}' has a "
                    f"mutable {kind} default at line {default.lineno}",
                    default.lineno,
                )

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_defaults(node)
        self._check_annotations(node)
        self._check_unreachable(node.body, node.name)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_defaults(node)
        self._check_annotations(node)
        self._check_unreachable(node.body, node.name)
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Missing annotations
    # ------------------------------------------------------------------

    def _check_annotations(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        # Skip dunder methods — annotations there are optional by convention
        if node.name.startswith("__") and node.name.endswith("__"):
            return
        # Check return annotation
        if node.returns is None:
            self._emit(
                "missing_annotation",
                f"missing_annotation: '{node.name}' has no return type annotation "
                f"at line {node.lineno}",
                node.lineno,
            )
        # Check parameter annotations (skip 'self' and 'cls')
        skip_args = {"self", "cls"}
        unannotated = [
            a.arg
            for a in (node.args.args + node.args.posonlyargs + node.args.kwonlyargs)
            if a.annotation is None and a.arg not in skip_args
        ]
        if unannotated:
            self._emit(
                "missing_annotation",
                f"missing_annotation: '{node.name}' has unannotated parameters: "
                f"{unannotated} at line {node.lineno}",
                node.lineno,
            )

    # ------------------------------------------------------------------
    # Unreachable code
    # ------------------------------------------------------------------

    _TERMINATORS = (ast.Return, ast.Raise, ast.Break, ast.Continue)

    def _check_unreachable(self, body: list[ast.stmt], context: str) -> None:
        for i, stmt in enumerate(body):
            if isinstance(stmt, self._TERMINATORS) and i < len(body) - 1:
                next_stmt = body[i + 1]
                terminator = type(stmt).__name__.lower()
                self._emit(
                    "unreachable_code",
                    f"unreachable_code: statements after '{terminator}' in '{context}' "
                    f"at line {next_stmt.lineno} are unreachable",
                    next_stmt.lineno,
                )
                break  # one report per block is enough

    # ------------------------------------------------------------------
    # Magic numbers — only flag bare literals used as comparands
    # ------------------------------------------------------------------

    # Numbers that are never considered "magic" in comparisons
    _BENIGN_NUMBERS = {0, 1, 2, -1, 0.0, 1.0, 0.5, 100, 1000, 10}

    def visit_Compare(self, node: ast.Compare) -> None:
        """Flag non-benign numeric literals appearing as comparators."""
        for comparator in node.comparators:
            if isinstance(comparator, ast.Constant) and isinstance(
                comparator.value, (int, float)
            ) and comparator.value not in self._BENIGN_NUMBERS:
                self._emit(
                    "magic_number",
                    f"magic_number: bare numeric literal {comparator.value!r} used in "
                    f"comparison at line {comparator.lineno} — "
                    "consider extracting to a named constant",
                    comparator.lineno,
                )
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Stray print() calls in library code
    # ------------------------------------------------------------------

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Name) and node.func.id == "print":
            # Skip test files (by filename, not path)
            basename = Path(self._file).name
            if not basename.startswith("test_") and not basename.endswith("_test.py"):
                self._emit(
                    "print_statement",
                    f"print_statement: stray print() call at line {node.lineno} — "
                    "use logging instead in library code",
                    node.lineno,
                )
        # Check for f-string in logging calls
        if isinstance(node.func, ast.Attribute) and node.func.attr in (
            "debug", "info", "warning", "error", "critical", "exception",
        ):
            if node.args and isinstance(node.args[0], ast.JoinedStr):
                self._emit(
                    "fstring_in_logging",
                    f"fstring_in_logging: f-string used in logging.{node.func.attr}() "
                    f"at line {node.lineno} — use lazy % formatting or extra= instead",
                    node.lineno,
                )
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Assert used for control flow in non-test code
    # ------------------------------------------------------------------

    def visit_Assert(self, node: ast.Assert) -> None:
        # Only flag in non-test files (by filename, not path)
        basename = Path(self._file).name
        if not basename.startswith("test_") and not basename.endswith("_test.py"):
            self._emit(
                "assert_in_library",
                f"assert_in_library: assert used at line {node.lineno} — "
                "assertions are stripped with python -O; use explicit "
                "raises for control flow in library code",
                node.lineno,
            )
        self.generic_visit(node)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _domain_from_path(path: Path) -> str:
    """Infer a domain name from the file path (top-level package or stem)."""
    try:
        parts = path.parts
        for i in range(len(parts) - 1, -1, -1):
            part = parts[i]
            if part.endswith(".py"):
                continue
            if part not in ("src", "lib", ""):
                return part
    except Exception:
        pass
    return path.stem
