"""Project-level configuration loader for Cairn.

Reads ``[tool.cairn]`` from the nearest ``pyproject.toml`` (walking up from
the current working directory), merging with built-in defaults.  Every
subsystem can call ``get_config()`` to respect project-local settings without
repeating CLI flags.

Supported keys in ``pyproject.toml``::

    [tool.cairn]
    db       = ".cairn/store.db"   # SQLite store path
    domain   = "myproject"         # default domain tag written on new records
    language = "python"            # primary language; used as domain prefix when
                                   # no explicit domain is supplied by a capture source

    [tool.cairn.decay]            # exponential half-lives in days
    pytest  = 21.0
    monitor = 21.0
    ast     = 14.0
    git     = 30.0
    distill = 60.0

The config is parsed once and cached; call ``get_config(reload=True)`` to
force a fresh read (e.g. in tests).
"""

from __future__ import annotations

import sys
from pathlib import Path

_DEFAULTS: dict = {
    "db": ".cairn/store.db",
    "domain": "",
    "language": "",
    "decay": {
        "pytest": 21.0,
        "monitor": 21.0,
        "ast": 14.0,
        "git": 30.0,
        "distill": 60.0,
    },
}

_cached: dict | None = None


def get_config(reload: bool = False) -> dict:
    """Return the merged configuration dict.

    Merges ``[tool.cairn]`` from the nearest ``pyproject.toml`` with
    built-in defaults.  Result is cached after the first call unless
    *reload* is ``True``.
    """
    global _cached
    if _cached is not None and not reload:
        return _cached

    # Deep-copy defaults so callers can't mutate the cache
    cfg: dict = {
        k: (dict(v) if isinstance(v, dict) else v)
        for k, v in _DEFAULTS.items()
    }

    pyproject = _find_pyproject()
    if pyproject is not None:
        raw = _load_toml(pyproject)
        tool_cairn = raw.get("tool", {}).get("cairn", {})

        if "db" in tool_cairn:
            cfg["db"] = str(tool_cairn["db"])
        if "domain" in tool_cairn:
            cfg["domain"] = str(tool_cairn["domain"])
        if "language" in tool_cairn:
            cfg["language"] = str(tool_cairn["language"])
        if "decay" in tool_cairn and isinstance(tool_cairn["decay"], dict):
            cfg["decay"].update(
                {k: float(v) for k, v in tool_cairn["decay"].items()}
            )

    _cached = cfg
    return cfg


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _find_pyproject() -> Path | None:
    """Walk up from CWD to find the nearest ``pyproject.toml``."""
    for directory in [Path.cwd(), *Path.cwd().parents]:
        candidate = directory / "pyproject.toml"
        if candidate.exists():
            return candidate
    return None


def _load_toml(path: Path) -> dict:
    """Load a TOML file, preferring the stdlib parser (Python 3.11+)."""
    text = path.read_text(encoding="utf-8")

    if sys.version_info >= (3, 11):
        import tomllib  # stdlib in 3.11+
        return tomllib.loads(text)

    try:
        import tomli  # type: ignore[import]  pip install tomli
        return tomli.loads(text)
    except ImportError:
        pass

    # No TOML parser available — silently use defaults
    return {}
