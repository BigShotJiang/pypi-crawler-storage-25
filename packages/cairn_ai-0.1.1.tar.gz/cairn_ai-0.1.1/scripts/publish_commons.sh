#!/usr/bin/env bash
# scripts/publish_commons.sh — regenerate and publish cairn commons DBs
#
# Usage:
#   ./scripts/publish_commons.sh [--skip-prime] [--dry-run]
#   ./scripts/publish_commons.sh --language fortran --skip-prime
#
# Requires:
#   - cairn-commons repo checked out at ../cairn-commons  (sibling of this repo)
#   - cairn .venv active or python3 resolves to the right interpreter
#
# What it does:
#   1. Re-runs prime_commons.py (Python) or prime_from_oss.py (Fortran/COBOL)
#   2. Copies each DB into ../cairn-commons/<lang>/
#   3. Commits and pushes to sethc5/cairn-commons
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CAIRN_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
COMMONS_ROOT="$(cd "$CAIRN_ROOT/../cairn-commons" && pwd)"

SKIP_PRIME=0
DRY_RUN=0
LANGUAGE="all"
for arg in "$@"; do
  case "$arg" in
    --skip-prime) SKIP_PRIME=1 ;;
    --dry-run)    DRY_RUN=1 ;;
    --language)   shift; LANGUAGE="$1" ;;
    --language=*) LANGUAGE="${arg#--language=}" ;;
  esac
done

PYTHON="${CAIRN_ROOT}/.venv/bin/python3"
if [[ ! -x "$PYTHON" ]]; then
  PYTHON="python3"
fi

publish_one() {
  local lang="$1" db_name="$2" dest_dir="$3"
  local db_src="${CAIRN_ROOT}/${db_name}"

  if [[ "$SKIP_PRIME" -eq 0 ]]; then
    echo "==> Priming ${lang} …"
    if [[ "$lang" == "python" ]]; then
      "$PYTHON" "$SCRIPT_DIR/prime_commons.py" --target "$CAIRN_ROOT/cairn"
    else
      "$PYTHON" "$SCRIPT_DIR/prime_from_oss.py" --language "$lang" \
        --clone-dir /tmp/oss_clones --skip-prime 2>&1 || true
    fi
  else
    echo "==> Skipping prime for ${lang} (--skip-prime)"
  fi

  if [[ ! -f "$db_src" ]]; then
    echo "WARNING: $db_src not found — skipping ${lang}." >&2
    return
  fi

  mkdir -p "${COMMONS_ROOT}/${dest_dir}"
  local dest="${COMMONS_ROOT}/${dest_dir}/${db_name}"
  echo "==> Copying ${lang} DB …"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    cp "$db_src" "$dest"
    echo "    copied → $dest ($(du -h "$dest" | cut -f1))"
  else
    echo "    [dry-run] would copy $db_src → $dest"
  fi
}

# Run the appropriate language(s)
case "$LANGUAGE" in
  python|all) publish_one python commons_python.db python ;;
esac
case "$LANGUAGE" in
  fortran|all) publish_one fortran commons_fortran.db fortran ;;
esac
case "$LANGUAGE" in
  cobol|all) publish_one cobol commons_cobol.db cobol ;;
esac

# ---------------------------------------------------------------------------
# Commit + push all staged changes in cairn-commons
# ---------------------------------------------------------------------------
TODAY="$(date -u +%Y-%m-%d)"
COMMIT_MSG="chore: refresh commons DBs (${TODAY})"

if [[ "$DRY_RUN" -eq 0 ]]; then
  echo "==> Committing to cairn-commons …"
  cd "$COMMONS_ROOT"
  git add python/ fortran/ cobol/ 2>/dev/null || true
  if git diff --cached --quiet; then
    echo "    No changes to commit — DBs unchanged."
  else
    git commit -m "$COMMIT_MSG"
    git push origin main
    echo "==> Pushed to sethc5/cairn-commons."
  fi
else
  echo "    [dry-run] would commit '$COMMIT_MSG' and push"
fi

echo "Done."


SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CAIRN_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
COMMONS_ROOT="$(cd "$CAIRN_ROOT/../cairn-commons" && pwd)"

SKIP_PRIME=0
DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --skip-prime) SKIP_PRIME=1 ;;
    --dry-run)    DRY_RUN=1 ;;
  esac
done

PYTHON="${CAIRN_ROOT}/.venv/bin/python3"
if [[ ! -x "$PYTHON" ]]; then
  PYTHON="python3"
fi

DB_SRC="${CAIRN_ROOT}/commons_python.db"

# ---------------------------------------------------------------------------
# Step 1: Re-prime
# ---------------------------------------------------------------------------
if [[ "$SKIP_PRIME" -eq 0 ]]; then
  echo "==> Regenerating commons_python.db …"
  "$PYTHON" "$SCRIPT_DIR/prime_commons.py" --target "$CAIRN_ROOT/cairn"
else
  echo "==> Skipping prime (--skip-prime)"
fi

if [[ ! -f "$DB_SRC" ]]; then
  echo "ERROR: $DB_SRC not found after prime — aborting." >&2
  exit 1
fi

# ---------------------------------------------------------------------------
# Step 2: Copy into commons repo
# ---------------------------------------------------------------------------
DEST="${COMMONS_ROOT}/python/commons_python.db"
echo "==> Copying into cairn-commons …"
if [[ "$DRY_RUN" -eq 0 ]]; then
  cp "$DB_SRC" "$DEST"
  echo "    copied → $DEST ($(du -h "$DEST" | cut -f1))"
else
  echo "    [dry-run] would copy $DB_SRC → $DEST"
fi

# ---------------------------------------------------------------------------
# Step 3: Commit + push
# ---------------------------------------------------------------------------
TODAY="$(date -u +%Y-%m-%d)"
COMMIT_MSG="chore: refresh commons_python.db (${TODAY})"

if [[ "$DRY_RUN" -eq 0 ]]; then
  echo "==> Committing to cairn-commons …"
  cd "$COMMONS_ROOT"
  git add python/commons_python.db
  if git diff --cached --quiet; then
    echo "    No changes to commit — DB unchanged."
  else
    git commit -m "$COMMIT_MSG"
    git push origin main
    echo "==> Pushed to sethc5/cairn-commons."
  fi
else
  echo "    [dry-run] would commit '$COMMIT_MSG' and push"
fi

echo "Done."
