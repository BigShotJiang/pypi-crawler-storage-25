#!/usr/bin/env python3
"""prime_from_oss.py — seed commons DBs from curated OSS repositories.

Clones each repo into a temp directory (shallow, tag/branch pinned), runs the
appropriate priming tools per language, and accumulates records into the
commons DB for that language.  Idempotent: re-running bumps confidence and
observation_count via UPSERT rather than duplicating rows.

Usage
-----
    # Full run — all manifested repos
    python scripts/prime_from_oss.py

    # Dry run (detect + count, no writes)
    python scripts/prime_from_oss.py --dry-run

    # Single repo by slug
    python scripts/prime_from_oss.py --only psf/requests

    # Skip clone if already cloned (fast re-run)
    python scripts/prime_from_oss.py --no-clone

    # Target a different DB dir (default: repo root, mirrors publish_commons.sh)
    python scripts/prime_from_oss.py --db-dir /tmp/commons

Language gating
---------------
Each language section runs only when the required tools are on PATH:
  Python  — always (ruff + mypy + bandit in cairn venv)
  Rust    — requires `cargo clippy`  (rustup component add clippy)
  Fortran — requires `gfortran`      (sudo apt install gfortran)
  COBOL   — requires `cobc`          (sudo apt install gnucobol)

Skipped tools are reported but do not fail the run.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

# ---------------------------------------------------------------------------
# Path bootstrap (same pattern as prime_commons.py)
# ---------------------------------------------------------------------------

_SCRIPT_DIR  = Path(__file__).resolve().parent
_CAIRN_REPO  = _SCRIPT_DIR.parent
_ROSETTA_REPO = _CAIRN_REPO.parent / "rosetta"

for _p in (_CAIRN_REPO, _ROSETTA_REPO):
    if _p.exists() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

try:
    from rosetta.intermediate import RosettaRecord
    from rosetta.translate.builtins import detect_and_transform
    from rosetta.routing.targets.cairn import write_cairn
except ImportError as exc:
    sys.exit(f"rosetta not found: {exc}")

try:
    from cairn.store.schema import normalize_domain
    from cairn.store.writer import count as db_count
except ImportError as exc:
    sys.exit(f"cairn not found: {exc}")

# ---------------------------------------------------------------------------
# Venv Python (for ruff / mypy / bandit)
# ---------------------------------------------------------------------------

def _find_tool_python() -> str:
    venv_py = _CAIRN_REPO / ".venv" / "bin" / "python3"
    if venv_py.exists():
        r = subprocess.run(
            [str(venv_py), "-m", "ruff", "--version"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        if r.returncode == 0:
            return str(venv_py)
    return sys.executable


_TOOL_PYTHON = _find_tool_python()


def _tool_available(name: str) -> bool:
    return shutil.which(name) is not None


# ---------------------------------------------------------------------------
# OSS repo manifest
# ---------------------------------------------------------------------------

@dataclass
class OSSRepo:
    slug: str                  # "owner/name"
    language: str              # "python" | "rust" | "typescript"
    # Clone ref — pin to a stable recent tag so the run is reproducible.
    ref: str = "HEAD"
    # Subdirectory within the repo to target for analysis (default: src or ".").
    src_subdir: str = "."
    # Override the tests subdir for pytest (defaults to looking for tests/ or src/).
    test_subdir: str | None = None
    # Extra notes (not used at runtime)
    notes: str = ""


# ---------------------------------------------------------------------------
# Python OSS targets — real-world application patterns, not VM internals.
# We pin to stable tags so reruns are reproducible.
# ---------------------------------------------------------------------------
OSS_MANIFEST: list[OSSRepo] = [
    OSSRepo(
        slug="psf/requests",
        language="python",
        ref="v2.32.3",
        src_subdir="src/requests",
        test_subdir="tests",
        notes="Canonical HTTP client; bandit SSL patterns, mypy errors, broad excepts",
    ),
    OSSRepo(
        slug="tiangolo/fastapi",
        language="python",
        ref="0.115.6",
        src_subdir="fastapi",
        test_subdir="tests",
        notes="Async, modern; type annotation patterns, coverage gaps",
    ),
    OSSRepo(
        slug="pallets/flask",
        language="python",
        ref="3.1.0",
        src_subdir="src/flask",
        test_subdir="tests",
        notes="Classic web framework; broad except, error handler patterns",
    ),
    OSSRepo(
        slug="pydantic/pydantic",
        language="python",
        ref="v2.10.4",
        src_subdir="pydantic",
        test_subdir="tests",
        notes="Validation library; mypy-heavy, coverage gaps on edge cases",
    ),
    OSSRepo(
        slug="encode/httpx",
        language="python",
        ref="0.28.1",
        src_subdir="httpx",
        test_subdir="tests",
        notes="Modern async HTTP; async misuse patterns, SSL handling",
    ),
    OSSRepo(
        slug="pallets/click",
        language="python",
        ref="8.1.8",
        src_subdir="src/click",
        test_subdir="tests",
        notes="CLI framework; broad except, type annotation gaps",
    ),
    OSSRepo(
        slug="sqlalchemy/sqlalchemy",
        language="python",
        ref="rel_2_0_36",
        src_subdir="lib/sqlalchemy",
        test_subdir=None,   # skip pytest — test suite needs a DB
        notes="ORM; bandit SQL patterns, broad except in connection handling",
    ),
    # Rust — activates when cargo clippy is available
    OSSRepo(
        slug="serde-rs/serde",
        language="rust",
        ref="v1.0.215",
        src_subdir="serde",
        notes="Serialization; clippy lints on derive macros",
    ),
    OSSRepo(
        slug="tokio-rs/tokio",
        language="rust",
        ref="tokio-1.42.0",
        src_subdir="tokio",
        notes="Async runtime; clippy on unsafe, blocking-in-async",
    ),
    # Fortran — activates when gfortran is available
    OSSRepo(
        slug="Reference-LAPACK/lapack",
        language="fortran",
        ref="v3.12.0",
        src_subdir="SRC",
        notes="Reference LAPACK; decades of Fortran 77/90 patterns; unused args, implicit none",
    ),
    OSSRepo(
        slug="sourceryinstitute/OpenCoarrays",
        language="fortran",
        ref="2.10.2",
        src_subdir=".",
        notes="Fortran coarray runtime; modern F2008/F2018; interface mismatches",
    ),
    OSSRepo(
        slug="opencollab/arpack-ng",
        language="fortran",
        ref="3.9.1",
        src_subdir="SRC",
        notes="Eigenvalue solver; F77 legacy patterns; implicit typing",
    ),
    OSSRepo(
        slug="fortran-lang/stdlib",
        language="fortran",
        ref="v0.7.0",
        src_subdir=".",
        notes="Fortran standard library; modern F2018; type checking, unused vars",
    ),
    OSSRepo(
        slug="Unidata/netcdf-fortran",
        language="fortran",
        ref="v4.6.2",
        src_subdir=".",
        notes="NetCDF Fortran bindings; real-world scientific I/O patterns",
    ),
    OSSRepo(
        slug="wrf-model/WRF",
        language="fortran",
        ref="v4.7.1",
        src_subdir=".",
        notes="Weather Research & Forecasting model; one of the largest real-world Fortran codebases",
    ),
    # cp2k/cp2k skipped — repo is 1.7 GB+, too large for automated shallow clone
    # OSSRepo(slug="cp2k/cp2k", language="fortran", ref="v2026.1", src_subdir="src")
    OSSRepo(
        slug="lanl/SNAP",
        language="fortran",
        ref="ver1.09-04182019",
        src_subdir="src",
        notes="LANL neutron transport mini-app; HPC Fortran 90 patterns",
    ),
    OSSRepo(
        slug="fortran-lang/test-drive",
        language="fortran",
        ref="v0.5.0",
        src_subdir="src",
        notes="Fortran unit test framework; clean modern F2018",
    ),
    OSSRepo(
        slug="NOAA-EMC/NCEPLIBS-bufr",
        language="fortran",
        ref="v12.3.0",
        src_subdir="src",
        notes="NOAA BUFR weather data library; legacy Fortran 77/90 patterns",
    ),
    OSSRepo(
        slug="NOAA-EMC/NCEPLIBS-sp",
        language="fortran",
        ref="v2.5.0",
        src_subdir="src",
        notes="NOAA spectral transform library; scientific HPC Fortran patterns",
    ),
    OSSRepo(
        slug="ElmerCSC/elmerfem",
        language="fortran",
        ref="release-26.1",
        src_subdir="fem/src",
        notes="Elmer multi-physics FEM; large modern Fortran codebase; interface patterns",
    ),
    OSSRepo(
        slug="OpenFAST/openfast",
        language="fortran",
        ref="v5.0.0",
        src_subdir="modules",
        notes="Wind energy simulation; mixed Fortran + C; real engineering patterns",
    ),
    OSSRepo(
        slug="firemodels/fds",
        language="fortran",
        ref="Git-r21",
        src_subdir="Source",
        notes="Fire Dynamics Simulator (NIST); Fortran 90 HPC CFD patterns",
    ),
    OSSRepo(
        slug="grimme-lab/xtb",
        language="fortran",
        ref="v6.7.1",
        src_subdir="src",
        notes="Extended tight-binding quantum chemistry; modern Fortran 2008",
    ),
    # QEF/q-e skipped — repo is ~1 GB+, too large for automated shallow clone
    # OSSRepo(slug="QEF/q-e", language="fortran", ref="qe-7.5", src_subdir=".")
    OSSRepo(
        slug="nasa/NASTRAN-95",
        language="fortran",
        ref="master",
        src_subdir=".",
        notes="NASA legacy structural analysis; classic Fortran 77 patterns",
    ),
    OSSRepo(
        slug="modern-fortran/neural-fortran",
        language="fortran",
        ref="v0.24.0",
        src_subdir="src",
        notes="Deep learning in Fortran; modern F2018; type checking patterns",
    ),
    OSSRepo(
        slug="fortran-lang/fpm",
        language="fortran",
        ref="v0.13.0",
        src_subdir=".",
        notes="Fortran Package Manager; both Fortran and CLI tooling patterns",
    ),
    # COBOL — activates when cobc (GnuCOBOL) is available
    OSSRepo(
        slug="openmainframeproject/cobol-programming-course",
        language="cobol",
        ref="master",
        src_subdir=".",
        notes="IBM/Linux Foundation COBOL course; real COBOL programs; common beginner errors",
    ),
    OSSRepo(
        slug="openmainframeproject/cobol-check",
        language="cobol",
        ref="Developer",
        src_subdir=".",
        notes="COBOL unit test framework; rich set of COBOL programs with known test outcomes",
    ),
    OSSRepo(
        slug="IBM/zopeneditor-sample",
        language="cobol",
        ref="main",
        src_subdir=".",
        notes="IBM Z Open Editor sample programs; real enterprise COBOL patterns",
    ),
    OSSRepo(
        slug="azac/cobol-on-wheelchair",
        language="cobol",
        ref="master",
        src_subdir=".",
        notes="COBOL programs for everyday use; 1k+ stars; diverse real-world patterns",
    ),
    OSSRepo(
        slug="aws-samples/aws-mainframe-modernization-carddemo",
        language="cobol",
        ref="main",
        src_subdir=".",
        notes="AWS mainframe modernization card demo; real legacy mainframe COBOL patterns",
    ),
    OSSRepo(
        slug="IBM/cobol-is-fun",
        language="cobol",
        ref="master",
        src_subdir=".",
        notes="IBM COBOL examples and tutorials; IBM-style COBOL patterns",
    ),
]

# ---------------------------------------------------------------------------
# Shell helpers
# ---------------------------------------------------------------------------

def _run(cmd: list[str], cwd: Path, timeout: int = 300) -> str:
    """Run cmd in cwd; return stdout+stderr regardless of exit code."""
    result = subprocess.run(
        cmd,
        cwd=cwd,
        stdin=subprocess.DEVNULL,   # prevent interactive prompts from blocking
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=timeout,
    )
    return result.stdout or ""


def clone_repo(slug: str, ref: str, dest: Path) -> bool:
    """Shallow-clone slug@ref into dest.  Returns True on success."""
    url = f"https://github.com/{slug}.git"
    print(f"    clone {slug}@{ref} ...", end=" ", flush=True)
    result = subprocess.run(
        ["git", "clone", "--depth=1", f"--branch={ref}", url, str(dest)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=600,
    )
    if result.returncode == 0:
        print("ok")
        return True
    # Some repos use vX.Y.Z tags, some bare X.Y.Z — try stripping leading 'v'
    alt_ref = ref.lstrip("v") if ref.startswith("v") else f"v{ref}"
    result2 = subprocess.run(
        ["git", "clone", "--depth=1", f"--branch={alt_ref}", url, str(dest)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=600,
    )
    if result2.returncode == 0:
        print(f"ok (alt ref {alt_ref})")
        return True
    print(f"FAILED\n    {result2.stdout.strip()[-200:]}")
    return False

# ---------------------------------------------------------------------------
# Rosetta ingestion (shared across languages)
# ---------------------------------------------------------------------------

def _dicts_to_records(dicts: list[dict], now: datetime) -> list[RosettaRecord]:
    _PLACEHOLDER = "1970-01-01T00:00:00Z"
    records: list[RosettaRecord] = []
    for item in dicts:
        if not isinstance(item, dict):
            continue
        try:
            raw_when = item.get("when", "")
            when = now if (not raw_when or raw_when == _PLACEHOLDER) else (
                datetime.fromisoformat(raw_when.replace("Z", "+00:00"))
            )
            records.append(RosettaRecord(
                what=str(item.get("what", "")),
                where=str(item.get("where", "")),
                when=when,
                confidence=float(item.get("confidence", 0.8)),
                source=str(item.get("source", "unknown")),
                metadata=item.get("metadata", {}),
            ))
        except (KeyError, ValueError, TypeError):
            continue
    return records


def ingest_raw(raw: str, *, db: Path, domain: str, dry_run: bool) -> int:
    if not raw.strip():
        return 0
    dummy = Path("output.txt")
    result = detect_and_transform(dummy, raw)
    if result is None:
        return 0
    _fmt, raw_dicts = result
    now = datetime.now(tz=timezone.utc)
    records = _dicts_to_records(raw_dicts, now)
    if not records:
        return 0
    if not dry_run:
        write_cairn(records, db=db, domain=domain)
    return len(records)

# ---------------------------------------------------------------------------
# Per-language prime runners
# ---------------------------------------------------------------------------

def prime_python(
    repo_dir: Path,
    repo: OSSRepo,
    db: Path,
    dry_run: bool,
) -> dict[str, int]:
    """Run ruff + mypy + bandit (+ optionally pytest) against a Python repo."""
    totals: dict[str, int] = {}

    src = repo_dir / repo.src_subdir
    if not src.exists():
        # Fallback: try the repo root itself
        src = repo_dir

    # --- ruff ---
    raw = _run(
        [_TOOL_PYTHON, "-m", "ruff", "check", "--output-format=concise",
         "--no-cache", str(src)],
        cwd=repo_dir,
    )
    totals["python/ruff"] = ingest_raw(raw, db=db, domain="python/ruff", dry_run=dry_run)

    # --- mypy ---
    raw = _run(
        [_TOOL_PYTHON, "-m", "mypy", "--output", "json",
         "--ignore-missing-imports", str(src)],
        cwd=repo_dir,
    )
    totals["python/mypy"] = ingest_raw(raw, db=db, domain="python/mypy", dry_run=dry_run)

    # --- bandit ---
    raw = _run(
        [_TOOL_PYTHON, "-m", "bandit", "-r", "--format", "json", "-q", str(src)],
        cwd=repo_dir,
    )
    totals["python/bandit"] = ingest_raw(raw, db=db, domain="python/bandit", dry_run=dry_run)

    # --- pytest --- (only when a test dir is specified)
    if repo.test_subdir is not None:
        test_dir = repo_dir / repo.test_subdir
        if test_dir.exists():
            raw = _run(
                [_TOOL_PYTHON, "-m", "pytest", "-v", "--tb=line",
                 "--no-header", "-p", "no:cairn",   # disable cairn plugin if installed
                 str(test_dir)],
                cwd=repo_dir,
                timeout=180,
            )
            totals["python/pytest"] = ingest_raw(
                raw, db=db, domain="python/pytest", dry_run=dry_run
            )

    return totals


def prime_rust(
    repo_dir: Path,
    repo: OSSRepo,
    db: Path,
    dry_run: bool,
) -> dict[str, int]:
    """Run cargo clippy --message-format json. Skip if clippy unavailable."""
    if not shutil.which("cargo") or not _clippy_available():
        return {"rust/clippy": -1}   # -1 = tool absent
    totals: dict[str, int] = {}
    src = repo_dir / repo.src_subdir
    if not src.exists():
        src = repo_dir
    raw = _run(
        ["cargo", "clippy", "--message-format=json", "--", "-D", "warnings"],
        cwd=src,
        timeout=600,
    )
    totals["rust/clippy"] = ingest_raw(raw, db=db, domain="rust/clippy", dry_run=dry_run)
    return totals


def _clippy_available() -> bool:
    r = subprocess.run(
        ["cargo", "clippy", "--version"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    return r.returncode == 0


def _gfortran_available() -> bool:
    return shutil.which("gfortran") is not None


def _cobc_available() -> bool:
    return shutil.which("cobc") is not None


# Free-format Fortran: column-insensitive, modern (.f90 and up)
_FORTRAN_FREE_EXTS = frozenset([
    ".f90", ".f95", ".f03", ".f08",
    ".F90", ".F95", ".F03", ".F08",
])
# Fixed-format Fortran: column 7 for code, 72-char lines (.f, .for, .ftn, .f77)
_FORTRAN_FIXED_EXTS = frozenset([
    ".f", ".for", ".ftn", ".f77",
    ".F", ".FOR", ".FTN", ".F77",
])
_FORTRAN_EXTS = tuple(_FORTRAN_FREE_EXTS | _FORTRAN_FIXED_EXTS)

# COBOL: fixed-format is the IBM/ANSI default for .cob/.cbl/.cpy
# Only .cobol (lowercase long extension) is typically free-format GnuCOBOL
_COBOL_FIXED_EXTS = frozenset([".cob", ".cbl", ".cpy", ".COB", ".CBL", ".CPY"])
_COBOL_FREE_EXTS  = frozenset([".cobol"])
_COBOL_EXTS = tuple(_COBOL_FIXED_EXTS | _COBOL_FREE_EXTS)


def _find_source_files(root: Path, exts: tuple[str, ...]) -> list[Path]:
    """Recursively collect source files matching the given extensions."""
    files: list[Path] = []
    for ext in exts:
        files.extend(root.rglob(f"*{ext}"))
    # Deduplicate and sort for stable ordering
    return sorted(set(files))


def prime_fortran(
    repo_dir: Path,
    repo: OSSRepo,
    db: Path,
    dry_run: bool,
) -> dict[str, int]:
    """Run gfortran -fsyntax-only -Wall -Wextra on each Fortran source file.

    Each file is compiled independently (no project-level build system needed),
    so we can process repos without a Makefile/CMake.  Module dependencies are
    skipped gracefully — we still capture warnings on files that compile cleanly.
    """
    if not _gfortran_available():
        return {"fortran/gfortran": -1}

    src = repo_dir / repo.src_subdir
    if not src.exists():
        src = repo_dir

    files = _find_source_files(src, _FORTRAN_EXTS)
    if not files:
        print(f"    [fortran] no source files found under {src}")
        return {"fortran/gfortran": 0}

    # Split files by format: fixed-format needs -ffixed-form to avoid spurious
    # "Line truncated" / "Non-numeric character in statement label" noise.
    free_files  = [f for f in files if f.suffix in _FORTRAN_FREE_EXTS]
    fixed_files = [f for f in files if f.suffix in _FORTRAN_FIXED_EXTS]

    base_flags = [
        "gfortran", "-fsyntax-only", "-Wall", "-Wextra",
        "-fno-module-private",
        "-Wno-tabs", "-Wno-conversion",
    ]

    total = 0
    batch_size = 50

    for fmt_flag, fmt_files in [("-ffree-form", free_files), ("-ffixed-form", fixed_files)]:
        for i in range(0, len(fmt_files), batch_size):
            batch = fmt_files[i : i + batch_size]
            raw = _run(
                [*base_flags, fmt_flag, *[str(f) for f in batch]],
                cwd=src,
                timeout=120,
            )
            n = ingest_raw(raw, db=db, domain="fortran/gfortran", dry_run=dry_run)
            total += n

    return {"fortran/gfortran": total}


def prime_cobol(
    repo_dir: Path,
    repo: OSSRepo,
    db: Path,
    dry_run: bool,
) -> dict[str, int]:
    """Run cobc -fsyntax-check -Wall on each COBOL source file.

    Like the Fortran runner, each file is checked independently so we don't
    need a project build system.  Missing copybooks are reported but don't
    stop the run.
    """
    if not _cobc_available():
        return {"cobol/cobc": -1}

    src = repo_dir / repo.src_subdir
    if not src.exists():
        src = repo_dir

    files = _find_source_files(src, _COBOL_EXTS)
    if not files:
        print(f"    [cobol] no source files found under {src}")
        return {"cobol/cobc": 0}

    total = 0
    for f in files:
        # Fixed-format is the IBM/ANSI default for .cob/.cbl/.cpy
        # .cobol (long extension) signals GnuCOBOL free-format source
        fmt_flag = "-free" if f.suffix.lower() in _COBOL_FREE_EXTS else "-fixed"
        raw = _run(
            ["cobc", "-Wall", fmt_flag, "-fsyntax-only", str(f)],
            cwd=src,
            timeout=30,
        )
        n = ingest_raw(raw, db=db, domain="cobol/cobc", dry_run=dry_run)
        total += n

    return {"cobol/cobc": total}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

_RUNNERS: dict[str, Callable] = {
    "python": prime_python,
    "rust": prime_rust,
    "fortran": prime_fortran,
    "cobol": prime_cobol,
}

_DB_NAMES: dict[str, str] = {
    "python": "commons_python.db",
    "rust": "commons_rust.db",
    "fortran": "commons_fortran.db",
    "cobol": "commons_cobol.db",
}


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Prime cairn commons DBs from curated OSS repositories.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--dry-run", action="store_true",
                   help="Detect + count without writing to DB.")
    p.add_argument("--only", metavar="SLUG",
                   help="Process only this repo slug (e.g. psf/requests).")
    p.add_argument("--no-clone", action="store_true",
                   help="Skip cloning; use existing dirs in CLONE_DIR.")
    p.add_argument("--db-dir", type=Path, default=_CAIRN_REPO,
                   help="Directory where commons_*.db files are written.")
    p.add_argument("--clone-dir", type=Path, default=None,
                   help="Persistent clone directory (default: a new temp dir).")
    p.add_argument("--language", metavar="LANG",
                   help="Restrict to repos of this language (python|rust|fortran|cobol).")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    dry_run = args.dry_run
    db_dir: Path = args.db_dir.resolve()
    db_dir.mkdir(parents=True, exist_ok=True)

    # Filter manifest
    repos = OSS_MANIFEST
    if args.only:
        repos = [r for r in repos if r.slug == args.only]
        if not repos:
            sys.exit(f"No repo matching {args.only!r} in manifest.")
    if args.language:
        repos = [r for r in repos if r.language == args.language]

    # Accumulate totals per domain across all repos
    grand_totals: dict[str, int] = {}
    skipped: list[str] = []

    use_tmp = args.clone_dir is None and not args.no_clone
    clone_root = args.clone_dir or Path(tempfile.mkdtemp(prefix="cairn_oss_"))

    print(f"prime_from_oss  repos={len(repos)}  db_dir={db_dir}  dry_run={dry_run}")
    print(f"                clone_root={clone_root}")
    print()

    try:
        for repo in repos:
            print(f"{'='*60}")
            print(f"  {repo.slug}  [{repo.language}@{repo.ref}]")
            db = db_dir / _DB_NAMES.get(repo.language, f"commons_{repo.language}.db")

            # Clone
            repo_dir = clone_root / repo.slug.replace("/", "__")
            if not repo_dir.exists():
                if args.no_clone:
                    print(f"  SKIP — no clone dir and --no-clone set")
                    skipped.append(repo.slug)
                    continue
                ok = clone_repo(repo.slug, repo.ref, repo_dir)
                if not ok:
                    skipped.append(repo.slug)
                    continue
            else:
                print(f"    using existing clone at {repo_dir}")

            # Run language-specific priming
            runner = _RUNNERS.get(repo.language)
            if runner is None:
                print(f"  SKIP — no runner for language {repo.language!r}")
                skipped.append(repo.slug)
                continue

            repo_totals = runner(repo_dir, repo, db, dry_run)

            # Report per stream
            repo_total = 0
            for domain, n in sorted(repo_totals.items()):
                if n == -1:
                    print(f"    {domain:30s}  [tool absent — skipped]")
                else:
                    verb = "would write" if dry_run else "wrote"
                    print(f"    {domain:30s}  {n:>5d} records ({verb})")
                    repo_total += n
                    grand_totals[domain] = grand_totals.get(domain, 0) + n

            print(f"  ── repo total: {repo_total} records")

    finally:
        if use_tmp and clone_root.exists():
            print(f"\nCleaning up temp clones at {clone_root} ...")
            shutil.rmtree(clone_root, ignore_errors=True)

    # Grand summary
    print(f"\n{'='*60}")
    print(f"GRAND TOTAL across {len(repos) - len(skipped)} repos:")
    for domain, n in sorted(grand_totals.items()):
        print(f"  {domain:30s}  {n:>6d}")
    total = sum(grand_totals.values())
    verb = "would write" if dry_run else "wrote"
    print(f"  {'TOTAL':30s}  {total:>6d}  ({verb})")

    if skipped:
        print(f"\nSkipped ({len(skipped)}): {', '.join(skipped)}")

    # DB stats
    if not dry_run:
        print()
        for lang, db_name in _DB_NAMES.items():
            db = db_dir / db_name
            if db.exists():
                try:
                    by_src = db_count(db)
                    total_records = sum(by_src.values())
                    print(f"{db_name}  ({db.stat().st_size // 1024} KB, {total_records} records total)")
                    for src, n in sorted(by_src.items()):
                        print(f"  {src:20s}  {n:>6d}")
                except Exception:
                    pass


if __name__ == "__main__":
    main()
