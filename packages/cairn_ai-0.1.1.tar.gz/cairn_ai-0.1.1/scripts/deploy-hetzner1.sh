#!/usr/bin/env bash
# Deploy/update cairn on hetzner1 and optionally sync the local store.
#
# Usage:
#   ./scripts/deploy-hetzner1.sh          # push code + restart service
#   ./scripts/deploy-hetzner1.sh --sync   # also pull remote store into local
#   ./scripts/deploy-hetzner1.sh --push   # also push local store to remote

set -euo pipefail

REMOTE=hetzner1
REMOTE_SRC=/opt/cairn/src
REMOTE_VENV=/opt/cairn/venv
REMOTE_STORE=/opt/cairn/store/store.db
LOCAL_STORE="${CAIRN_DB:-.cairn/store.db}"

echo "→ Syncing cairn source to $REMOTE:$REMOTE_SRC"
rsync -az --delete \
  --exclude='.venv' \
  --exclude='__pycache__' \
  --exclude='*.egg-info' \
  --exclude='.pytest_cache' \
  --exclude='.cairn' \
  --exclude='scripts' \
  "$(dirname "$0")/../" \
  "root@95.216.246.55:$REMOTE_SRC/"

echo "→ Reinstalling cairn on remote"
ssh "$REMOTE" "$REMOTE_VENV/bin/pip install -e $REMOTE_SRC -q"

echo "→ Restarting cairn service"
ssh "$REMOTE" "systemctl restart cairn && sleep 1 && systemctl is-active cairn"

if [[ "${1:-}" == "--sync" ]]; then
  echo "→ Pulling remote store → $LOCAL_STORE"
  mkdir -p "$(dirname "$LOCAL_STORE")"
  scp "root@95.216.246.55:$REMOTE_STORE" "$LOCAL_STORE"
  echo "   Done. Run 'cairn stats' to see merged records."
fi

if [[ "${1:-}" == "--push" ]]; then
  echo "→ Pushing local store → remote"
  scp "$LOCAL_STORE" "root@95.216.246.55:$REMOTE_STORE"
  ssh "$REMOTE" "systemctl restart cairn"
  echo "   Done."
fi

echo "✓ cairn deployed to hetzner1"
echo "  MCP endpoint (after tunnel): http://localhost:8765/sse"
echo "  Tunnel:  ssh -N cairn-tunnel"
echo "  Status:  ssh hetzner1 'systemctl status cairn --no-pager'"
