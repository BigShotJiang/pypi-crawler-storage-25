#!/usr/bin/env python3
"""prime_commons.py — seed a commons_python.db from real Python tool output.

Self-bootstrapping: this script injects the cairn and rosetta source trees onto
sys.path at startup, so it can be invoked with any Python 3.11+ interpreter
that has the standard library only — no venv activation needed, as long as the
cairn and rosetta repos live side-by-side (e.g. /dev/automagic/cairn + rosetta).

The script will prefer an already-installed cairn/rosetta over the injected
source trees (sys.path injection happens after site-packages).

Usage
-----
    python scripts/prime_commons.py [--target DIR] [--db PATH] [--dry-run]

    # defaults: target = this repo's cairn/ package, db = ./commons_python.db
    python scripts/prime_commons.py

    # seed from a different tree (e.g. CPython stdlib)
    python scripts/prime_commons.py --target /usr/lib/python3.12 --db commons_python.db

    # preview without writing
    python scripts/prime_commons.py --dry-run

What it does
------------
1.  Runs ``ruff check`` and ``pytest --tb=line`` against TARGET.
2.  Routes each output through rosetta's builtin detectors
    (detect_and_transform — zero-shot, no LLM cost).
3.  Writes the resulting TruthRecords to DB with domain tags:
      python/ruff    — style / lint signal
      python/pytest  — test outcome signal
4.  All writes are idempotent UPSERT — safe to re-run; duplicate runs bump
    confidence and observation_count rather than inserting new rows.

Domain convention
-----------------
The DB file path encodes the tier (commons vs org vs project).
The domain field encodes the language and the originating tool:

    python/ruff     — ruff style findings
    python/pytest   — pytest pass/fail/error records
    python/mypy     — type errors (mypy --output json)
    python/bandit   — security findings (bandit -r --format json)
    python/coverage — coverage gaps (coverage json after coverage run -m pytest)

This is step 2 of the commons seeding sequence.

Sequence
--------
  1. [done] Pin domain convention  (schema.py + query.py)
  2. [this] prime_commons.py       — validate format with real data
  3. cairn query --db CLI          — consume from_dbs() from the CLI
  4. sethc5/cairn-commons git repo — distribute the seeded DBs
  5. synthesis run                 — orchestrate nasti→rosetta→cairn
  6. cairn export --strip-scope    — optional signal donation
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

# ---------------------------------------------------------------------------
# Path bootstrap — make cairn + rosetta importable regardless of invoking venv.
# scripts/prime_commons.py lives at  <cairn_repo>/scripts/prime_commons.py
# so the repo root is two levels up from __file__.
# ---------------------------------------------------------------------------

_SCRIPT_DIR = Path(__file__).resolve().parent          # .../cairn/scripts/
_CAIRN_REPO  = _SCRIPT_DIR.parent                      # .../cairn/
_AUTOMAGIC   = _CAIRN_REPO.parent                      # .../automagic/
_ROSETTA_REPO = _AUTOMAGIC / "rosetta"                 # .../automagic/rosetta/

for _p in (_CAIRN_REPO, _ROSETTA_REPO):
    if _p.exists() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

try:
    from rosetta.intermediate import RosettaRecord
    from rosetta.translate.builtins import detect_and_transform
    from rosetta.routing.targets.cairn import write_cairn
except ImportError as exc:
    sys.exit(
        f"rosetta not found: {exc}\n"
        "Run:  pip install -e /path/to/rosetta  (into the same venv as cairn)"
    )

try:
    from cairn.store.schema import normalize_domain
    from cairn.store.writer import count as db_count
except ImportError as exc:
    sys.exit(f"cairn not found: {exc}")


# ---------------------------------------------------------------------------
# Tool runners
# ---------------------------------------------------------------------------

def _find_tool_python() -> str:
    """Return the best Python interpreter for running ruff / pytest.

    Priority:
    1. Cairn venv python (../cairn/.venv/bin/python3) if exists and has ruff.
    2. The interpreter running *this* script (sys.executable).
    """
    venv_py = _CAIRN_REPO / ".venv" / "bin" / "python3"
    if venv_py.exists():
        # Quick check: can it import ruff?
        import subprocess as _sp
        r = _sp.run(
            [str(venv_py), "-m", "ruff", "--version"],
            stdout=_sp.PIPE, stderr=_sp.PIPE,
        )
        if r.returncode == 0:
            return str(venv_py)
    return sys.executable


_TOOL_PYTHON: str = _find_tool_python()

def _run(cmd: list[str], cwd: Path) -> str:
    """Run cmd in cwd; return combined stdout+stderr regardless of exit code."""
    result = subprocess.run(
        cmd,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return result.stdout or ""


def run_ruff(target: Path) -> str:
    """ruff check --output-format=concise <target> — file:line:col: code msg per line."""
    return _run(
        [_TOOL_PYTHON, "-m", "ruff", "check", "--output-format=concise", str(target)],
        cwd=target,
    )


def run_pytest(target: Path) -> str:
    """pytest -v --tb=line <target> — verbose node IDs so the rosetta detector fires.

    -v produces  'tests/foo.py::test_bar PASSED'  lines that the builtin
    pytest detector requires.  --tb=line keeps failure tracebacks compact.
    """
    return _run(
        [_TOOL_PYTHON, "-m", "pytest", "-v", "--tb=line", str(target)],
        cwd=target.parent,  # run from repo root so imports resolve
    )


def run_mypy(target: Path) -> str:
    """mypy --output json <target> — newline-delimited JSON, one object per finding."""
    return _run(
        [_TOOL_PYTHON, "-m", "mypy", "--output", "json", str(target)],
        cwd=target.parent,
    )


def run_bandit(target: Path) -> str:
    """bandit -r --format json <target> — full JSON report."""
    return _run(
        [_TOOL_PYTHON, "-m", "bandit", "-r", "--format", "json", "-q", str(target)],
        cwd=target.parent,
    )


def run_coverage(target: Path, test_target: Path) -> str:
    """Run coverage run -m pytest, then coverage json.

    Writes coverage data into a temp dir so it doesn't pollute the repo.
    Returns the JSON text regardless of pytest exit code.
    """
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        cov_file = Path(tmp) / "coverage.json"
        data_file = Path(tmp) / ".coverage"
        # Step 1: collect coverage — pass --data-file explicitly so nothing
        # lands in the working directory.
        _run(
            [_TOOL_PYTHON, "-m", "coverage", "run",
             f"--data-file={data_file}",
             f"--source={target}",
             "-m", "pytest", "-q", str(test_target)],
            cwd=target.parent,
        )
        # Step 2: export JSON
        subprocess.run(
            [_TOOL_PYTHON, "-m", "coverage", "json",
             f"--data-file={data_file}",
             "-o", str(cov_file)],
            cwd=target.parent,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        if cov_file.exists():
            return cov_file.read_text()
        return ""


# ---------------------------------------------------------------------------
# Rosetta pipeline: raw text → RosettaRecord list
# ---------------------------------------------------------------------------

def _dicts_to_records(dicts: list[dict], now: datetime) -> list[RosettaRecord]:
    """Convert detect_and_transform raw dicts into RosettaRecord objects."""
    _PLACEHOLDER = "1970-01-01T00:00:00Z"
    records: list[RosettaRecord] = []
    for item in dicts:
        if not isinstance(item, dict):
            continue
        try:
            raw_when = item.get("when", "")
            when = now if (not raw_when or raw_when == _PLACEHOLDER) else (
                datetime.fromisoformat(raw_when.replace("Z", "+00:00"))
            )
            records.append(RosettaRecord(
                what=str(item.get("what", "")),
                where=str(item.get("where", "")),
                when=when,
                confidence=float(item.get("confidence", 0.8)),
                source=str(item.get("source", "unknown")),
                metadata=item.get("metadata", {}),
            ))
        except (KeyError, ValueError, TypeError):
            continue
    return records


def ingest_raw(
    raw: str,
    *,
    db: Path,
    domain: str,
    dry_run: bool = False,
) -> int:
    """Route *raw* through rosetta detectors, write matches to *db*.

    Returns the number of records that would/were written.
    Domain is already normalised by the caller.
    Returns 0 if no rosetta detector matched the raw output.
    """
    if not raw.strip():
        return 0

    # Use a dummy path — detectors use the sample content, not the file path.
    dummy_path = Path("output.txt")
    result = detect_and_transform(dummy_path, raw)
    if result is None:
        return 0

    _format_name, raw_dicts = result
    now = datetime.now(tz=timezone.utc)
    records = _dicts_to_records(raw_dicts, now)
    if not records:
        return 0

    if not dry_run:
        write_cairn(records, db=db, domain=domain)

    return len(records)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).parent.parent
    default_src    = repo_root / "cairn"   # source tree for ruff
    default_tests  = repo_root / "tests"   # test tree for pytest
    default_db     = repo_root / "commons_python.db"

    p = argparse.ArgumentParser(
        description="Seed commons_python.db from real Python tool output.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument(
        "--target", type=Path, default=default_src,
        help=f"Source dir for ruff (default: {default_src})",
    )
    p.add_argument(
        "--test-target", type=Path, default=default_tests,
        help=f"Test dir for pytest (default: {default_tests})",
    )
    p.add_argument(
        "--db", type=Path, default=default_db,
        help=f"Output cairn SQLite database (default: {default_db})",
    )
    p.add_argument(
        "--dry-run", action="store_true",
        help="Detect and count records without writing to DB.",
    )
    p.add_argument("--skip-ruff",     action="store_true", help="Skip ruff.")
    p.add_argument("--skip-pytest",   action="store_true", help="Skip pytest.")
    p.add_argument("--skip-mypy",     action="store_true", help="Skip mypy.")
    p.add_argument("--skip-bandit",   action="store_true", help="Skip bandit.")
    p.add_argument("--skip-coverage", action="store_true", help="Skip coverage.")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    target: Path = args.target.resolve()
    test_target: Path = args.test_target.resolve()
    db: Path = args.db.resolve()
    dry_run: bool = args.dry_run

    print(f"prime_commons  ruff={target}  pytest={test_target}")
    print(f"               mypy/bandit/coverage target={target}  db={db}  dry_run={dry_run}")
    print()

    totals: dict[str, int] = {}

    # --- ruff ---
    if not args.skip_ruff:
        print("› ruff check ...", end=" ", flush=True)
        raw = run_ruff(target)
        domain = normalize_domain("python/ruff")
        n = ingest_raw(raw, db=db, domain=domain, dry_run=dry_run)
        totals["python/ruff"] = n
        print(f"{n} records")
        if n == 0 and raw.strip():
            preview = "\n".join(raw.splitlines()[:3])
            print(f"  [no detector match]\n  {preview}")

    # --- pytest ---
    if not args.skip_pytest:
        print("› pytest --tb=line ...", end=" ", flush=True)
        raw = run_pytest(test_target)
        domain = normalize_domain("python/pytest")
        n = ingest_raw(raw, db=db, domain=domain, dry_run=dry_run)
        totals["python/pytest"] = n
        print(f"{n} records")
        if n == 0 and raw.strip():
            preview = "\n".join(raw.splitlines()[:3])
            print(f"  [no detector match]\n  {preview}")

    # --- mypy ---
    if not args.skip_mypy:
        print("› mypy --output json ...", end=" ", flush=True)
        raw = run_mypy(target)
        domain = normalize_domain("python/mypy")
        n = ingest_raw(raw, db=db, domain=domain, dry_run=dry_run)
        totals["python/mypy"] = n
        print(f"{n} records")
        if n == 0 and raw.strip():
            preview = "\n".join(raw.splitlines()[:3])
            print(f"  [no detector match]\n  {preview}")

    # --- bandit ---
    if not args.skip_bandit:
        print("› bandit -r --format json ...", end=" ", flush=True)
        raw = run_bandit(target)
        domain = normalize_domain("python/bandit")
        n = ingest_raw(raw, db=db, domain=domain, dry_run=dry_run)
        totals["python/bandit"] = n
        print(f"{n} records")
        if n == 0 and raw.strip():
            preview = "\n".join(raw.splitlines()[:3])
            print(f"  [no detector match]\n  {preview}")

    # --- coverage ---
    if not args.skip_coverage:
        print("› coverage run + json ...", end=" ", flush=True)
        raw = run_coverage(target, test_target)
        domain = normalize_domain("python/coverage")
        n = ingest_raw(raw, db=db, domain=domain, dry_run=dry_run)
        totals["python/coverage"] = n
        print(f"{n} records")
        if n == 0 and raw.strip():
            preview = "\n".join(raw.splitlines()[:3])
            print(f"  [no detector match]\n  {preview}")

    # --- summary ---
    print()
    total = sum(totals.values())
    label = "would write" if dry_run else "wrote"
    print(f"Total: {label} {total} records across {len(totals)} domains")
    for dom, n in sorted(totals.items()):
        print(f"  {dom:25s}  {n:>6d}")

    if not dry_run and db.exists():
        print()
        print(f"DB: {db}  ({db.stat().st_size // 1024} KB)")
        try:
            by_src = db_count(db)
            print("Records by source:")
            for src, n in sorted(by_src.items()):
                print(f"  {src:15s}  {n:>6d}")
        except Exception:
            pass


if __name__ == "__main__":
    main()
