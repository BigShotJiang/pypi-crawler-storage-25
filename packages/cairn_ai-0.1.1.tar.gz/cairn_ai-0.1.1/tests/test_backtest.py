"""Backtest suite — evidence-based validation of Cairn's signal pipeline.

For each published claim the library makes, this module provides a deterministic
ground-truth test.  Together they form a reproducible specification:

  - **AST detection precision/recall**: known-bad code produces expected findings;
    clean, idiomatic code produces zero false positives.
  - **Decay model**: exact formula correctness (±1e-6) at known time intervals.
  - **Writer idempotency**: no duplicate records on re-write; observation_count
    increments; confidence bumps by exactly 0.005 per re-observation; hard cap at 1.0.
  - **Clustering accuracy**: correct grouping by exception type and AST check
    type; largest cluster returned first.
  - **Context quality**: stale records filtered at min_confidence threshold;
    lint-rule section emitted for AST patterns; context empty for empty store.
  - **Pipeline end-to-end**: create records → cluster → name → verify the
    named pattern is accurate and the context snippet is coherent.

This file is designed to be publishable alongside the library as a spec: if
you change an algorithm, the backtest immediately tells you *what* changed and
by how much.

Run the full suite::

    pytest tests/test_backtest.py -v

No external services, network calls, or large model downloads required.
"""

from __future__ import annotations

import textwrap
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from cairn.store.schema import TruthRecord


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    return datetime.now(tz=timezone.utc)


def _record(
    *,
    source: str = "pytest",
    domain: str = "myapp",
    content: str = "FAIL test_thing: AssertionError",
    confidence: float = 0.9,
    age_days: float = 0.0,
    exception_type: str | None = None,
    source_file: str | None = None,
    source_line: int | None = None,
) -> TruthRecord:
    occurred = _now() - timedelta(days=age_days)
    return TruthRecord(
        source=source,
        domain=domain,
        content=content,
        confidence=confidence,
        occurred_at=occurred,
        exception_type=exception_type,
        source_file=source_file,
        source_line=source_line,
    )


# ---------------------------------------------------------------------------
# Part 1 — AST scanner precision and recall
# ---------------------------------------------------------------------------

# Each entry: (label, Python source code, set of expected check_type prefixes)
# All code is written to a file named "mylib.py" so that filename-gated checks
# (print_statement, assert_in_library) fire normally.
_CORPUS = [
    (
        "broad_except_bare",
        """\
def f():
    try:
        x = 1
    except:
        pass
""",
        {"broad_except"},
    ),
    (
        "broad_except_base_exception",
        """\
def f():
    try:
        x = 1
    except BaseException:
        pass
""",
        {"broad_except"},
    ),
    (
        "broad_except_base_in_tuple",
        """\
def f():
    try:
        x = 1
    except (ValueError, BaseException):
        pass
""",
        {"broad_except"},
    ),
    (
        "mutable_default_list",
        """\
def f(items=[]):
    items.append(1)
""",
        {"mutable_default"},
    ),
    (
        "mutable_default_dict",
        """\
def f(cache={}):
    return cache
""",
        {"mutable_default"},
    ),
    (
        "mutable_default_set",
        # set() is ast.Call, not ast.Set literal — scanner flags List/Dict/Set literals only.
        # Fully annotated so missing_annotation does not fire incidentally.
        "def f(seen: set = set()) -> None:\n    seen.add(1)\n",
        set(),
    ),
    (
        "unreachable_after_return",
        """\
def f():
    return 1
    x = 2
""",
        {"unreachable_code"},
    ),
    (
        "unreachable_after_raise",
        """\
def f():
    raise ValueError("oops")
    x = 2
""",
        {"unreachable_code"},
    ),
    (
        "magic_number_in_comparison",
        """\
def f(x):
    return x > 9000
""",
        {"magic_number"},
    ),
    (
        "magic_number_not_flagged_for_benign_zero",
        # 0 is in _BENIGN_NUMBERS — must NOT be flagged.
        # Fully annotated so missing_annotation does not fire incidentally.
        "def f(x: int) -> bool:\n    return x > 0\n",
        set(),
    ),
    (
        "magic_number_not_flagged_for_benign_one",
        # 1 is in _BENIGN_NUMBERS — must NOT be flagged.
        "def f(x: int) -> bool:\n    return x > 1\n",
        set(),
    ),
    (
        "print_in_library",
        """\
def f():
    print("hello")
""",
        {"print_statement"},
    ),
    (
        "fstring_in_logging_info",
        """\
import logging
def f(x):
    logging.info(f"value is {x}")
""",
        {"fstring_in_logging"},
    ),
    (
        "fstring_in_logging_warning",
        """\
import logging
def f(x):
    logging.warning(f"bad value: {x}")
""",
        {"fstring_in_logging"},
    ),
    (
        "assert_in_library",
        """\
def f(x):
    assert x > 0
""",
        {"assert_in_library"},
    ),
    (
        "missing_annotation_return_only",
        """\
def f(x: int):
    return x
""",
        {"missing_annotation"},
    ),
    (
        "missing_annotation_param_only",
        """\
def f(x) -> int:
    return x
""",
        {"missing_annotation"},
    ),
    (
        "deep_nesting_5_levels",
        """\
def f():
    if True:
        for i in range(10):
            while True:
                with open("x") as fp:
                    if fp:
                        pass
""",
        {"deep_nesting"},
    ),
    (
        "deep_nesting_not_flagged_at_4_levels",
        # depth = 3 levels (if>for>while ≤ MAX_NESTING_DEPTH 4) — must NOT fire.
        # Annotated so missing_annotation does not fire incidentally.
        "def f() -> None:\n    if True:\n        for i in range(10):\n            while True:\n                pass\n",
        set(),
    ),
    (
        "dunder_method_no_annotation_flag",
        """\
class C:
    def __init__(self, x):
        self.x = x
""",
        # Dunder methods are excluded from annotation checks by convention
        set(),
    ),
]

# Clean, well-written code — zero findings expected from any check type
_CLEAN_CODE = """\
import logging

MAX_RETRIES: int = 3
logger = logging.getLogger(__name__)


def process_batch(
    items: list[str],
    retries: int = 0,
) -> list[bool]:
    results: list[bool] = []
    for item in items:
        if retries >= MAX_RETRIES:
            results.append(False)
            continue
        try:
            results.append(bool(item.strip()))
        except (TypeError, AttributeError) as err:
            logger.warning("Failed to process item: %s", err)
            results.append(False)
    return results
"""


class TestASTCorpus:
    """Precision and recall for every pattern the AST scanner claims to detect."""

    @pytest.mark.parametrize("label,code,expected_checks", _CORPUS, ids=[t[0] for t in _CORPUS])
    def test_ast_scanner_corpus(self, tmp_path: Path, label: str, code: str, expected_checks: set) -> None:
        """Each corpus entry verifies that expected check types are (or are not) detected."""
        from cairn.capture.ast_scanner import scan

        src_file = tmp_path / "mylib.py"
        src_file.write_text(textwrap.dedent(code))
        records = scan(src_file)

        found_checks = {r.content.split(":")[0].strip() for r in records}

        for expected in expected_checks:
            assert expected in found_checks, (
                f"[{label}] Expected check '{expected}' not found. "
                f"Found: {found_checks!r}"
            )

        if not expected_checks:
            # Negative test — ensure only the expected check types are absent
            assert not found_checks or found_checks == set(), (
                f"[{label}] Expected no findings but got: {found_checks!r}"
            )

    def test_no_false_positives_on_clean_idiomatic_code(self, tmp_path: Path) -> None:
        """Canonical well-written Python produces zero AST findings.

        This is the precision baseline.  If the scanner flags this code, a
        check has a false-positive that needs to be tightened.
        """
        from cairn.capture.ast_scanner import scan

        src_file = tmp_path / "mylib.py"
        src_file.write_text(_CLEAN_CODE)
        records = scan(src_file)

        check_types = {r.content.split(":")[0].strip() for r in records}
        assert not records, (
            f"Clean code produced unexpected findings: {check_types!r}\n"
            + "\n".join(r.content.splitlines()[0] for r in records)
        )

    def test_scanner_returns_empty_for_syntax_error(self, tmp_path: Path) -> None:
        """Files that cannot be parsed return an empty list, not an exception."""
        from cairn.capture.ast_scanner import scan

        broken = tmp_path / "broken.py"
        broken.write_text("def f(\n    x =\n")  # syntax error
        assert scan(broken) == []

    def test_scan_project_skips_venv(self, tmp_path: Path) -> None:
        """scan_project never recurses into .venv or venv directories."""
        from cairn.capture.ast_scanner import scan_project

        venv_file = tmp_path / ".venv" / "lib" / "site-packages" / "bad.py"
        venv_file.parent.mkdir(parents=True)
        venv_file.write_text("def f():\n    print('hello')\n")

        real_file = tmp_path / "mylib.py"
        real_file.write_text("def f(x: int) -> int:\n    return x\n")

        records = scan_project(tmp_path)
        source_files = {r.source_file for r in records}
        assert str(venv_file) not in source_files

    def test_scan_project_exclude_extends_defaults(self, tmp_path: Path) -> None:
        """--exclude extra dirs are added to the built-in exclusion set, not replacing it."""
        from cairn.capture.ast_scanner import scan_project

        # File in default-excluded dir
        cache_file = tmp_path / "__pycache__" / "cached.py"
        cache_file.parent.mkdir()
        cache_file.write_text("def f():\n    print('hello')\n")

        # File in custom-excluded dir
        generated_file = tmp_path / "generated" / "auto.py"
        generated_file.parent.mkdir()
        generated_file.write_text("def f():\n    print('hello')\n")

        # Real file that should be scanned
        real_file = tmp_path / "mylib.py"
        real_file.write_text("def f():\n    print('hello')\n")

        records = scan_project(tmp_path, exclude=["generated"])
        source_files = {r.source_file for r in records}

        assert str(cache_file) not in source_files, "Default exclusion (__pycache__) was stripped"
        assert str(generated_file) not in source_files, "Custom exclusion (generated) not applied"
        assert str(real_file) in source_files, "Real file was incorrectly excluded"


# ---------------------------------------------------------------------------
# Part 2 — Decay model ground truth
# ---------------------------------------------------------------------------

class TestDecayModel:
    """Exact formula verification: conf × 0.5^(age_days / half_life)."""

    def test_decay_at_half_life_is_half_confidence(self) -> None:
        """At exactly one half-life, decayed confidence should be half the original."""
        from cairn.distill.decay import decayed_confidence

        r = _record(source="pytest", confidence=1.0, age_days=21.0)
        result = decayed_confidence(r, as_of=_now())
        assert abs(result - 0.5) < 1e-6

    def test_decay_at_double_half_life(self) -> None:
        """At two half-lives, confidence decays to one quarter."""
        from cairn.distill.decay import decayed_confidence

        r = _record(source="pytest", confidence=1.0, age_days=42.0)
        result = decayed_confidence(r, as_of=_now())
        assert abs(result - 0.25) < 1e-6

    def test_decay_at_zero_age_is_original(self) -> None:
        """Freshly written record should have full confidence."""
        from cairn.distill.decay import decayed_confidence

        r = _record(confidence=0.7, age_days=0.0)
        result = decayed_confidence(r, as_of=_now())
        assert abs(result - 0.7) < 1e-4

    def test_ast_half_life_is_shorter_than_pytest(self) -> None:
        """AST records (14-day half-life) decay faster than pytest records (21-day)."""
        from cairn.distill.decay import decayed_confidence

        age = 10.0  # 10 days
        r_ast = _record(source="ast", confidence=1.0, age_days=age)
        r_pytest = _record(source="pytest", confidence=1.0, age_days=age)
        assert decayed_confidence(r_ast, _now()) < decayed_confidence(r_pytest, _now())

    def test_distill_half_life_is_longer_than_pytest(self) -> None:
        """Distilled patterns (60-day half-life) are more durable than pytest records."""
        from cairn.distill.decay import decayed_confidence

        age = 30.0
        r_distill = _record(source="distill", confidence=1.0, age_days=age)
        r_pytest = _record(source="pytest", confidence=1.0, age_days=age)
        assert decayed_confidence(r_distill, _now()) > decayed_confidence(r_pytest, _now())

    def test_apply_decay_filters_below_min_confidence(self) -> None:
        """apply_decay drops records whose effective confidence is below min_confidence."""
        from cairn.distill.decay import apply_decay

        very_old = _record(source="pytest", confidence=1.0, age_days=1000.0)
        fresh = _record(source="pytest", confidence=0.9, age_days=0.0,
                        content="FAIL test_different: AssertionError")

        live = apply_decay([very_old, fresh], min_confidence=0.05)
        ids = {r.id for r in live}

        assert fresh.id in ids, "Fresh record should survive decay filter"
        assert very_old.id not in ids, "1000-day-old record should be filtered out"

    def test_apply_decay_sorted_highest_first(self) -> None:
        """apply_decay returns records ordered by decayed confidence, highest first."""
        from cairn.distill.decay import apply_decay

        records = [
            _record(confidence=0.3, age_days=0.0, content="FAIL low: E"),
            _record(confidence=1.0, age_days=0.0, content="FAIL high: E"),
            _record(confidence=0.6, age_days=0.0, content="FAIL mid: E"),
        ]
        live = apply_decay(records)
        confs = [r.confidence for r in live]
        assert confs == sorted(confs, reverse=True)

    def test_naive_datetime_treated_as_utc(self) -> None:
        """A record with a naive occurred_at does not crash; treated as UTC."""
        from cairn.distill.decay import decayed_confidence

        naive_occurred = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=7)
        r = TruthRecord(
            source="pytest", domain="myapp",
            content="FAIL test_naive: AssertionError",
            confidence=1.0,
            occurred_at=naive_occurred,
        )
        result = decayed_confidence(r, as_of=_now())
        # Should be positive and less than 1.0
        assert 0.0 < result < 1.0


# ---------------------------------------------------------------------------
# Part 3 — Writer idempotency and observation counting
# ---------------------------------------------------------------------------

class TestWriterIdempotency:
    """Re-writing the same record must not create duplicates."""

    def test_no_duplicate_records_on_rewrite(self, tmp_path: Path) -> None:
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        r = _record()
        with Writer(db) as w:
            for _ in range(5):
                w.write(r)

        records = get_all(db)
        assert len(records) == 1, f"Expected 1 record, got {len(records)}"

    def test_observation_count_increments_on_upsert(self, tmp_path: Path) -> None:
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        r = _record()
        with Writer(db) as w:
            for _ in range(7):
                w.write(r)

        assert get_all(db)[0].observation_count == 7

    def test_confidence_bumps_by_fixed_delta_per_upsert(self, tmp_path: Path) -> None:
        """Each re-observation bumps confidence by exactly 0.005."""
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        r = _record(confidence=0.5)
        upserts = 4  # 1 insert + 3 updates = 4 total writes, 3 bumps

        with Writer(db) as w:
            for _ in range(upserts):
                w.write(r)

        stored = get_all(db)[0]
        expected = 0.5 + (upserts - 1) * 0.005
        assert abs(stored.confidence - expected) < 1e-9

    def test_confidence_hard_capped_at_one(self, tmp_path: Path) -> None:
        """Confidence never exceeds 1.0 regardless of re-observation count."""
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        r = _record(confidence=0.999)
        with Writer(db) as w:
            for _ in range(50):
                w.write(r)

        assert get_all(db)[0].confidence <= 1.0

    def test_distinct_contents_create_distinct_records(self, tmp_path: Path) -> None:
        """Different content → different IDs → separate rows in the store."""
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        records = [_record(content=f"FAIL test_{i}: E") for i in range(10)]
        with Writer(db) as w:
            w.write_many(records)

        stored = get_all(db)
        assert len(stored) == 10

    def test_embedding_preserved_on_upsert_when_new_has_none(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """If the new record has no embedding, the stored embedding is preserved.

        Auto-embedding is disabled via monkeypatch so the test is not sensitive
        to whether sentence-transformers is installed.
        """
        from cairn.store.writer import Writer, get_all

        # Disable auto-embedding: we control embeddings manually in this test
        monkeypatch.setattr(Writer, "_try_embed", lambda self, records: None)

        db = tmp_path / "store.db"
        r = _record()
        r.embedding = [0.1, 0.2, 0.3]

        r_no_emb = _record()
        r_no_emb.embedding = []

        with Writer(db) as w:
            w.write(r)          # inserts with embedding
            w.write(r_no_emb)   # upserts; should preserve existing embedding

        stored = get_all(db)[0]
        assert stored.embedding == [0.1, 0.2, 0.3]


# ---------------------------------------------------------------------------
# Part 4 — Clustering accuracy
# ---------------------------------------------------------------------------

class TestClusteringAccuracy:
    """Failure pattern clustering groups by exception type, check type, etc."""

    def _make_failures(
        self, exc: str, fn: str = "parse_config", n: int = 3, domain: str = "myapp"
    ) -> list[TruthRecord]:
        return [
            _record(
                source="pytest",
                domain=domain,
                content=f"FAIL test_fn_{i}: {exc}\n{exc}: bad value\nin {fn}",
                exception_type=exc,
            )
            for i in range(n)
        ]

    def test_groups_by_exception_type(self) -> None:
        from cairn.distill.cluster import cluster

        records = self._make_failures("ValueError", n=3) + self._make_failures("TypeError", n=2)
        clusters = cluster(records)
        assert len(clusters) == 2

    def test_largest_cluster_returned_first(self) -> None:
        from cairn.distill.cluster import cluster

        records = self._make_failures("ValueError", n=5) + self._make_failures("TypeError", n=2)
        clusters = cluster(records)
        first_key, first_members = next(iter(clusters.items()))
        assert len(first_members) == 5
        assert "ValueError" in first_key

    def test_ast_records_grouped_by_check_type(self) -> None:
        from cairn.distill.cluster import cluster

        broad = [
            _record(source="ast", content=f"broad_except: bare except at line {i}",
                    exception_type=None) for i in range(3)
        ]
        magic = [
            _record(source="ast", content="magic_number: literal 9000 at line 5",
                    exception_type=None)
        ]
        clusters = cluster(broad + magic)
        assert "broad_except" in clusters
        assert "magic_number" in clusters
        assert len(clusters["broad_except"]) == 3

    def test_single_exception_type_single_cluster(self) -> None:
        from cairn.distill.cluster import cluster

        records = self._make_failures("AssertionError", n=10)
        clusters = cluster(records)
        assert len(clusters) == 1

    def test_empty_input_returns_empty_dict(self) -> None:
        from cairn.distill.cluster import cluster

        assert cluster([]) == {}


# ---------------------------------------------------------------------------
# Part 5 — Namer accuracy
# ---------------------------------------------------------------------------

class TestNamerAccuracy:
    """Pattern names should reflect the dominant signal in each cluster."""

    def test_names_runtime_cluster_with_exception_and_file(self) -> None:
        from cairn.distill.namer import name_cluster

        records = [
            _record(source="pytest", exception_type="ValueError",
                    source_file="/app/config.py",
                    content=f"FAIL test_{i}: ValueError")
            for i in range(5)
        ]
        name = name_cluster(records)
        assert "ValueError" in name
        assert "config.py" in name
        assert "5" in name

    def test_names_ast_cluster_with_check_type_and_file(self) -> None:
        from cairn.distill.namer import name_cluster

        records = [
            _record(source="ast",
                    content=f"broad_except: bare except at line {i}",
                    source_file=f"/app/utils.py")
            for i in range(3)
        ]
        name = name_cluster(records)
        assert "broad_except" in name

    def test_empty_cluster_returns_empty_cluster_label(self) -> None:
        from cairn.distill.namer import name_cluster

        assert name_cluster([]) == "empty cluster"

    def test_fallback_naming_for_unknown_source(self) -> None:
        from cairn.distill.namer import name_cluster

        records = [_record(source="custom_source", content=f"obs {i}") for i in range(2)]
        name = name_cluster(records)
        assert "custom_source" in name


# ---------------------------------------------------------------------------
# Part 6 — Context quality
# ---------------------------------------------------------------------------

class TestContextQuality:
    """The Markdown context snippet must reflect the quality of the signals."""

    def test_context_empty_when_store_missing(self, tmp_path: Path) -> None:
        from cairn.inject.context import build_context

        ctx = build_context(db_path=tmp_path / "nonexistent.db")
        assert ctx == ""

    def test_context_empty_when_store_is_empty(self, tmp_path: Path) -> None:
        from cairn.inject.context import build_context
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        # Initialise the store (creates the file) but write nothing
        Writer(db).close()
        ctx = build_context(db_path=db)
        assert ctx == ""

    def test_stale_records_filtered_from_context(self, tmp_path: Path) -> None:
        """Very old records should decay below min_confidence and not appear."""
        from cairn.inject.context import build_context
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        ancient = _record(source="pytest", confidence=1.0, age_days=1000.0,
                          content="FAIL test_ancient: AncientError",
                          exception_type="AncientError")
        fresh = _record(source="pytest", confidence=0.9, age_days=0.0,
                        content="FAIL test_fresh: FreshError",
                        exception_type="FreshError")
        with Writer(db) as w:
            w.write(ancient)
            w.write(fresh)

        ctx = build_context(db_path=db, min_confidence=0.05)
        assert "AncientError" not in ctx, "1000-day-old record should not appear in context"
        assert "FreshError" in ctx

    def test_lint_rules_section_emitted_for_ast_patterns(self, tmp_path: Path) -> None:
        """AST records whose check_type maps to a ruff rule should produce a Lint section."""
        from cairn.inject.context import build_context
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        r = _record(
            source="ast",
            content="magic_number: bare literal 9000 in comparison at line 5",
            confidence=0.65,
            source_file="/app/mylib.py",
            source_line=5,
        )
        with Writer(db) as w:
            w.write(r)

        ctx = build_context(db_path=db)
        assert "PLR2004" in ctx, "ruff PLR2004 rule should appear for magic_number pattern"
        assert "Lint rules" in ctx

    def test_context_includes_confidence_annotations(self, tmp_path: Path) -> None:
        """Every record line in the context should show its decayed confidence."""
        from cairn.inject.context import build_context
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        r = _record(confidence=0.9, content="FAIL test_x: ImportError",
                    exception_type="ImportError")
        with Writer(db) as w:
            w.write(r)

        ctx = build_context(db_path=db)
        assert "conf:" in ctx.lower() or "conf" in ctx

    def test_context_groups_by_domain(self, tmp_path: Path) -> None:
        """Records from different domains should appear in separate sections."""
        from cairn.inject.context import build_context
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        records = [
            _record(domain="frontend", content=f"FAIL test_ui_{i}: UIError",
                    exception_type="UIError")
            for i in range(3)
        ] + [
            _record(domain="backend", content=f"FAIL test_api_{i}: APIError",
                    exception_type="APIError")
            for i in range(3)
        ]
        with Writer(db) as w:
            w.write_many(records)

        ctx = build_context(db_path=db)
        assert "frontend" in ctx
        assert "backend" in ctx


# ---------------------------------------------------------------------------
# Part 7 — Search recall
# ---------------------------------------------------------------------------

class TestSearchRecall:
    """The truth store must return the right records for structured queries."""

    def test_recent_failures_sorted_newest_first(self, tmp_path: Path) -> None:
        from cairn.store.query import recent_failures
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        now = _now()
        failures = [
            _record(
                source="pytest",
                content=f"FAIL test_{i}: AssertionError",
                exception_type="AssertionError",
                age_days=float(i),  # older as i increases
            )
            for i in range(5)
        ]
        with Writer(db) as w:
            w.write_many(failures)

        results = recent_failures(n=10, db_path=db)
        assert len(results) == 5
        dates = [r.occurred_at for r in results]
        assert dates == sorted(dates, reverse=True), "recent_failures must be newest-first"

    def test_recent_failures_excludes_non_failures(self, tmp_path: Path) -> None:
        from cairn.store.query import recent_failures
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        failure = _record(content="FAIL test_x: AssertionError", exception_type="AssertionError")
        passing = _record(content="PASS test_y", exception_type=None)
        with Writer(db) as w:
            w.write_many([failure, passing])

        results = recent_failures(n=10, db_path=db)
        ids = {r.id for r in results}
        assert failure.id in ids
        assert passing.id not in ids

    def test_keyword_search_fallback_ranks_by_token_overlap(self, tmp_path: Path) -> None:
        """Keyword (Jaccard) fallback should surface the most relevant record first."""
        from cairn.store.query import semantic_search
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        # No embeddings → keyword fallback
        relevant = _record(content="FAIL test_parse: ValueError in parse_config",
                           exception_type="ValueError")
        unrelated = _record(content="CALL helper.format_output → None",
                            exception_type=None)
        with Writer(db) as w:
            w.write_many([unrelated, relevant])  # write unrelated first

        results = semantic_search("ValueError config", top_k=5, db_path=db)
        assert results, "Search returned no results"
        assert results[0].id == relevant.id, "Most relevant record should rank first"

    def test_by_source_filters_correctly(self, tmp_path: Path) -> None:
        from cairn.store.query import by_source
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        ast_rec = _record(source="ast", content="broad_except: bare except at line 1")
        pytest_rec = _record(source="pytest", content="FAIL test_x: AssertionError",
                             exception_type="AssertionError")
        with Writer(db) as w:
            w.write_many([ast_rec, pytest_rec])

        ast_results = by_source("ast", db_path=db)
        assert all(r.source == "ast" for r in ast_results)
        assert ast_rec.id in {r.id for r in ast_results}
        assert pytest_rec.id not in {r.id for r in ast_results}


# ---------------------------------------------------------------------------
# Part 8 — Pipeline end-to-end
# ---------------------------------------------------------------------------

class TestPipelineEndToEnd:
    """Full pipeline: records in → distill → named clusters → context out."""

    def test_distillation_names_repeated_valueerror_cluster(self) -> None:
        """5 records with the same exception type and file should cluster and be named."""
        from cairn.distill.cluster import cluster as do_cluster
        from cairn.distill.namer import name_cluster

        records = [
            _record(
                source="pytest",
                content=f"FAIL test_config_{i}: ValueError in parse_config",
                exception_type="ValueError",
                source_file="/app/config.py",
            )
            for i in range(5)
        ]
        clusters = do_cluster(records)
        assert len(clusters) == 1

        members = list(clusters.values())[0]
        assert len(members) == 5

        name = name_cluster(members)
        assert "ValueError" in name
        assert "config.py" in name
        assert "5" in name

    def test_rules_encodes_ast_pattern_as_ruff_rule(self) -> None:
        """encode_as_rule should return a ruff snippet for known AST check types."""
        from cairn.distill.rules import encode_as_rule

        records = [
            _record(source="ast",
                    content="broad_except: bare except at line 5",
                    source_file="/app/mylib.py")
        ]
        snippet = encode_as_rule("broad_except (1 occurrence)", records)
        assert snippet is not None
        assert "BLE001" in snippet

    def test_rules_returns_none_for_runtime_records(self) -> None:
        """Runtime records (pytest/monitor) have no direct ruff rule mapping."""
        from cairn.distill.rules import encode_as_rule

        records = [_record(source="pytest", exception_type="ValueError")]
        result = encode_as_rule("ValueError", records)
        assert result is None

    def test_full_scan_distill_context_pipeline(self, tmp_path: Path) -> None:
        """Scan Python code → distill → build context → confirm pattern appears."""
        from cairn.capture.ast_scanner import scan
        from cairn.distill.cluster import cluster as do_cluster
        from cairn.distill.namer import name_cluster
        from cairn.inject.context import build_context
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"

        # Write code with a known pattern
        src = tmp_path / "mylib.py"
        src.write_text("def f():\n    try:\n        pass\n    except:\n        pass\n")

        ast_records = scan(src)
        assert any("broad_except" in r.content for r in ast_records)

        with Writer(db) as w:
            w.write_many(ast_records)

        # Distill: cluster + name
        clusters = do_cluster(ast_records)
        assert "broad_except" in clusters

        # Context output should mention the pattern and the ruff rule
        ctx = build_context(db_path=db)
        assert "broad_except" in ctx
        assert "BLE001" in ctx  # ruff rule for broad_except = BLE001

    def test_observation_count_compounds_across_multiple_runs(self, tmp_path: Path) -> None:
        """Simulating test-suite re-runs: same failure accumulates evidence."""
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        failure = _record(
            source="pytest",
            content="FAIL test_auth: AssertionError: response.status_code not 200",
            confidence=0.8,
            exception_type="AssertionError",
        )

        # Simulate 10 test suite runs hitting the same failure
        with Writer(db) as w:
            for _ in range(10):
                w.write(failure)

        stored = get_all(db)
        assert len(stored) == 1, "10 re-runs must not create 10 duplicate records"
        assert stored[0].observation_count == 10
        # Confidence should have compounded (never exceeding 1.0)
        expected = min(1.0, 0.8 + 9 * 0.005)
        assert abs(stored[0].confidence - expected) < 1e-9

    def test_prune_removes_only_matching_records(self, tmp_path: Path) -> None:
        """delete_by_ids must remove exactly the targeted records."""
        from cairn.store.writer import Writer, delete_by_ids, get_all

        db = tmp_path / "store.db"
        keep = [_record(content=f"FAIL test_keep_{i}: E") for i in range(3)]
        drop = [_record(content=f"FAIL test_drop_{i}: E") for i in range(2)]

        with Writer(db) as w:
            w.write_many(keep + drop)

        assert len(get_all(db)) == 5

        delete_by_ids([r.id for r in drop], db)
        remaining = get_all(db)
        assert len(remaining) == 3
        remaining_ids = {r.id for r in remaining}
        for r in keep:
            assert r.id in remaining_ids


# ---------------------------------------------------------------------------
# Part 9 — Export roundtrip fidelity
# ---------------------------------------------------------------------------

class TestExportRoundtrip:
    """JSON and CSV exports must faithfully serialise every field in TruthRecord."""

    def test_json_export_all_fields_preserved(self, tmp_path: Path) -> None:
        """JSON roundtrip: every field in the original record survives export."""
        import json
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        r = _record(
            source="pytest",
            content="FAIL test_parse: ValueError",
            confidence=0.75,
            exception_type="ValueError",
            source_file="/app/parser.py",
            source_line=42,
        )
        with Writer(db) as w:
            w.write(r)

        result = CliRunner().invoke(main, ["export", "--db", str(db), "--format", "json"])
        assert result.exit_code == 0, result.output

        rows = json.loads(result.output)
        assert len(rows) == 1
        row = rows[0]
        assert row["id"] == r.id
        assert row["source"] == "pytest"
        assert row["exception_type"] == "ValueError"
        assert row["source_line"] == 42
        assert abs(row["confidence"] - 0.75) < 1e-9
        assert row["observation_count"] == 1

    def test_csv_export_has_required_headers(self, tmp_path: Path) -> None:
        """CSV export must include all schema columns as headers."""
        import csv
        import io
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write(_record())

        result = CliRunner().invoke(main, ["export", "--db", str(db), "--format", "csv"])
        assert result.exit_code == 0

        reader = csv.DictReader(io.StringIO(result.output))
        headers = set(reader.fieldnames or [])
        for col in (
            "id", "source", "domain", "content", "confidence",
            "occurred_at", "observation_count", "pattern_cluster",
        ):
            assert col in headers, f"Missing CSV column: {col!r}"

    def test_csv_row_count_matches_store(self, tmp_path: Path) -> None:
        """Each record in the store produces exactly one CSV row."""
        import csv
        import io
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write_many([_record(content=f"FAIL test_{i}: E") for i in range(7)])

        result = CliRunner().invoke(main, ["export", "--db", str(db), "--format", "csv"])
        assert result.exit_code == 0

        rows = list(csv.DictReader(io.StringIO(result.output)))
        assert len(rows) == 7

    def test_json_export_source_filter(self, tmp_path: Path) -> None:
        """--source flag limits JSON output to only records with that source tag."""
        import json
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write_many([
                _record(source="ast", content="broad_except: bare except"),
                _record(source="pytest", content="FAIL test_x: E", exception_type="E"),
            ])

        result = CliRunner().invoke(
            main, ["export", "--db", str(db), "--format", "json", "--source", "ast"]
        )
        assert result.exit_code == 0
        rows = json.loads(result.output)
        assert len(rows) == 1
        assert rows[0]["source"] == "ast"

    def test_export_to_file_writes_valid_json(self, tmp_path: Path) -> None:
        """--output writes the JSON to a file rather than stdout."""
        import json
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write_many([_record(content=f"FAIL test_{i}: E") for i in range(3)])

        out = tmp_path / "records.json"
        result = CliRunner().invoke(
            main, ["export", "--db", str(db), "--format", "json", "--output", str(out)]
        )
        assert result.exit_code == 0
        assert out.exists()
        rows = json.loads(out.read_text())
        assert len(rows) == 3

    def test_json_observation_count_survives_roundtrip(self, tmp_path: Path) -> None:
        """observation_count from repeated upserts is preserved in the JSON export."""
        import json
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer

        db = tmp_path / "store.db"
        r = _record(content="FAIL test_repeated: AssertionError", exception_type="AssertionError")
        with Writer(db) as w:
            for _ in range(6):
                w.write(r)

        result = CliRunner().invoke(main, ["export", "--db", str(db), "--format", "json"])
        assert result.exit_code == 0
        rows = json.loads(result.output)
        assert rows[0]["observation_count"] == 6


# ---------------------------------------------------------------------------
# Part 10 — CLI integration
# ---------------------------------------------------------------------------

class TestCLIIntegration:
    """Click CLI commands produce correct output shapes against a real store."""

    def _populated_db(self, tmp_path: Path) -> Path:
        from cairn.store.writer import Writer
        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write_many([
                _record(source="pytest", content="FAIL test_auth: AssertionError",
                        exception_type="AssertionError"),
                _record(source="ast", content="broad_except: bare except at line 5"),
                _record(source="pytest", content="FAIL test_config: ValueError",
                        exception_type="ValueError", age_days=100.0),
            ])
        return db

    def test_status_reports_total_count(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        db = self._populated_db(tmp_path)
        result = CliRunner().invoke(main, ["status", "--db", str(db)])
        assert result.exit_code == 0
        assert "Total records: 3" in result.output

    def test_status_shows_stale_breakdown(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        db = self._populated_db(tmp_path)
        result = CliRunner().invoke(main, ["status", "--db", str(db)])
        assert result.exit_code == 0
        # The 100-day-old record should appear in the stale count
        assert "stale" in result.output.lower()

    def test_distill_dry_run_does_not_write(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import get_all

        db = self._populated_db(tmp_path)
        before = len(get_all(db))
        result = CliRunner().invoke(main, ["distill", "--db", str(db), "--dry-run"])
        assert result.exit_code == 0
        assert len(get_all(db)) == before, "--dry-run must not write any records"

    def test_query_surfaces_matching_content(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        db = self._populated_db(tmp_path)
        result = CliRunner().invoke(main, ["query", "ValueError", "--db", str(db)])
        assert result.exit_code == 0
        assert "ValueError" in result.output

    def test_context_cmd_produces_markdown_heading(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        db = self._populated_db(tmp_path)
        result = CliRunner().invoke(main, ["context", "--db", str(db)])
        assert result.exit_code == 0
        assert "#" in result.output

    def test_prune_dry_run_does_not_delete(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import get_all

        db = self._populated_db(tmp_path)
        before = len(get_all(db))
        result = CliRunner().invoke(
            main, ["prune", "--db", str(db), "--older-than", "7d", "--dry-run"]
        )
        assert result.exit_code == 0
        assert len(get_all(db)) == before, "--dry-run must not actually delete records"

    def test_scan_writes_ast_findings_to_store(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer, get_all

        db = tmp_path / "store.db"
        Writer(db).close()

        src = tmp_path / "mylib.py"
        src.write_text("def f():\n    try:\n        pass\n    except:\n        pass\n")

        result = CliRunner().invoke(main, ["scan", str(src), "--db", str(db)])
        assert result.exit_code == 0
        records = get_all(db)
        assert any("broad_except" in r.content for r in records)

    def test_stats_cmd_shows_per_source_breakdown(self, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        db = self._populated_db(tmp_path)
        result = CliRunner().invoke(main, ["stats", "--db", str(db)])
        assert result.exit_code == 0
        assert "pytest" in result.output
        assert "ast" in result.output


# ---------------------------------------------------------------------------
# Part 11 — Template generator
# ---------------------------------------------------------------------------

class TestTemplateGenerator:
    """generate_stubs converts monitor records into valid, parseable Python stubs."""

    def _monitor_record(self, fn: str = "parse_config", module: str = "/app/config.py") -> TruthRecord:
        from cairn.store.schema import TruthRecord as _TR
        return _TR(
            source="monitor",
            domain="myapp",
            content=f'CALL {fn}(path="config.yaml") → None',
            confidence=0.8,
            occurred_at=_now(),
            source_file=module,
        )

    def test_returns_dict_keyed_by_module_stem(self) -> None:
        from cairn.distill.templates import generate_stubs

        stubs = generate_stubs([self._monitor_record(module="/app/config.py")])
        assert isinstance(stubs, dict)
        assert "config" in stubs

    def test_generated_stub_is_valid_python(self) -> None:
        import ast as _ast
        from cairn.distill.templates import generate_stubs

        stubs = generate_stubs([self._monitor_record()])
        for stem, src in stubs.items():
            try:
                _ast.parse(src)
            except SyntaxError as exc:
                pytest.fail(f"Stub for {stem!r} is invalid Python: {exc}\n---\n{src[:300]}")

    def test_stub_references_observed_function_name(self) -> None:
        from cairn.distill.templates import generate_stubs

        stubs = generate_stubs([self._monitor_record(fn="parse_config")])
        combined = "\n".join(stubs.values())
        assert "parse_config" in combined

    def test_empty_input_returns_empty_dict(self) -> None:
        from cairn.distill.templates import generate_stubs

        assert generate_stubs([]) == {}

    def test_non_monitor_records_are_ignored(self) -> None:
        from cairn.distill.templates import generate_stubs

        records = [
            _record(source="pytest", content="FAIL test_x: AssertionError"),
            _record(source="ast", content="broad_except: bare except"),
        ]
        assert generate_stubs(records) == {}

    def test_multiple_modules_produce_separate_stubs(self) -> None:
        from cairn.distill.templates import generate_stubs

        records = [
            self._monitor_record(fn="parse_config", module="/app/config.py"),
            self._monitor_record(fn="load_schema", module="/app/schema.py"),
        ]
        stubs = generate_stubs(records)
        assert "config" in stubs
        assert "schema" in stubs
        assert stubs["config"] != stubs["schema"]

    def test_markdown_summary_is_non_empty_for_monitor_records(self) -> None:
        from cairn.distill.templates import generate_stubs_markdown

        records = [self._monitor_record()]
        md = generate_stubs_markdown(records)
        assert isinstance(md, str)
        assert len(md) > 0
        assert "parse_config" in md


# ---------------------------------------------------------------------------
# Part 12 — Store sync / multi-store merge
# ---------------------------------------------------------------------------

class TestStoreSync:
    """write_many is the sync primitive — verifies that merging stores is correct."""

    def test_sync_copies_all_source_records(self, tmp_path: Path) -> None:
        from cairn.store.writer import Writer, get_all

        src_db = tmp_path / "src.db"
        dst_db = tmp_path / "dst.db"

        src_records = [_record(content=f"FAIL test_{i}: E") for i in range(5)]
        with Writer(src_db) as w:
            w.write_many(src_records)

        with Writer(dst_db) as w:
            w.write_many(get_all(src_db))

        assert len(get_all(dst_db)) == 5

    def test_sync_is_idempotent(self, tmp_path: Path) -> None:
        """Syncing the same source store twice never creates duplicate records."""
        from cairn.store.writer import Writer, get_all

        src_db = tmp_path / "src.db"
        dst_db = tmp_path / "dst.db"

        with Writer(src_db) as w:
            w.write_many([_record(content=f"FAIL test_{i}: E") for i in range(3)])

        for _ in range(3):  # sync three times
            with Writer(dst_db) as w:
                w.write_many(get_all(src_db))

        assert len(get_all(dst_db)) == 3, "Repeated sync from the same source must not create duplicates"

    def test_sync_preserves_records_unique_to_each_store(self, tmp_path: Path) -> None:
        """After merging src → dst, records originally unique to dst survive."""
        from cairn.store.writer import Writer, get_all

        src_db = tmp_path / "src.db"
        dst_db = tmp_path / "dst.db"

        src_only = [_record(content=f"FAIL src_{i}: E") for i in range(3)]
        dst_only = [_record(content=f"FAIL dst_{i}: E") for i in range(4)]

        with Writer(src_db) as w:
            w.write_many(src_only)
        with Writer(dst_db) as w:
            w.write_many(dst_only)

        # Merge src into dst
        with Writer(dst_db) as w:
            w.write_many(get_all(src_db))

        merged = get_all(dst_db)
        assert len(merged) == 7
        merged_ids = {r.id for r in merged}
        for r in src_only + dst_only:
            assert r.id in merged_ids

    def test_sync_increments_observation_count_for_shared_records(self, tmp_path: Path) -> None:
        """A record that exists in both stores has its observation_count incremented."""
        from cairn.store.writer import Writer, get_all

        src_db = tmp_path / "src.db"
        dst_db = tmp_path / "dst.db"

        shared = _record(content="FAIL test_shared: AssertionError", exception_type="AssertionError")
        with Writer(src_db) as w:
            w.write(shared)
        with Writer(dst_db) as w:
            w.write(shared)

        # Sync: src record upserts into dst where it already exists
        with Writer(dst_db) as w:
            w.write_many(get_all(src_db))

        dst_records = get_all(dst_db)
        assert len(dst_records) == 1
        assert dst_records[0].observation_count >= 2

    def test_cli_sync_cmd_merges_stores(self, tmp_path: Path) -> None:
        """cairn sync SOURCE_DB --db DEST_DB merges SOURCE into DEST via the CLI."""
        from click.testing import CliRunner
        from cairn.cli import main
        from cairn.store.writer import Writer, get_all

        src_db = tmp_path / "src.db"
        dst_db = tmp_path / "dst.db"

        with Writer(src_db) as w:
            w.write_many([_record(content=f"FAIL src_{i}: E") for i in range(4)])
        with Writer(dst_db) as w:
            w.write(_record(content="FAIL dst_0: E"))

        result = CliRunner().invoke(
            main, ["sync", str(src_db), "--db", str(dst_db)]
        )
        assert result.exit_code == 0
        assert len(get_all(dst_db)) == 5
