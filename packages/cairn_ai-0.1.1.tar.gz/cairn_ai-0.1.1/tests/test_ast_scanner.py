"""Tests for the AST scanner."""

from __future__ import annotations

import textwrap
from pathlib import Path

from cairn.capture.ast_scanner import MAX_NESTING_DEPTH, scan, scan_project

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write(tmp_path: Path, name: str, src: str) -> Path:
    p = tmp_path / name
    p.write_text(textwrap.dedent(src))
    return p


def _content_contains(records, fragment: str) -> bool:
    return any(fragment in r.content for r in records)


def _sources(records) -> list[str]:
    return [r.source for r in records]


# ---------------------------------------------------------------------------
# source field
# ---------------------------------------------------------------------------


class TestSourceField:
    def test_all_records_have_ast_source(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo():
                pass
        """)
        records = scan(p)
        assert all(r.source == "ast" for r in records)


# ---------------------------------------------------------------------------
# Broad except
# ---------------------------------------------------------------------------


class TestBroadExcept:
    def test_bare_except(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            try:
                pass
            except:
                pass
        """)
        records = scan(p)
        assert _content_contains(records, "bare 'except:'")

    def test_except_exception(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            try:
                pass
            except Exception:
                pass
        """)
        records = scan(p)
        assert _content_contains(records, "except Exception:")

    def test_except_base_exception(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            try:
                pass
            except BaseException:
                pass
        """)
        records = scan(p)
        assert _content_contains(records, "except BaseException:")

    def test_specific_except_not_flagged(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            try:
                pass
            except ValueError:
                pass
        """)
        records = scan(p)
        assert not _content_contains(records, "broad_except")

    def test_except_tuple_with_broad(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            try:
                pass
            except (ValueError, Exception):
                pass
        """)
        records = scan(p)
        assert _content_contains(records, "broad_except")


# ---------------------------------------------------------------------------
# Mutable defaults
# ---------------------------------------------------------------------------


class TestMutableDefault:
    def test_list_default(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(items=[]):
                return items
        """)
        records = scan(p)
        assert _content_contains(records, "mutable_default")
        assert _content_contains(records, "items")

    def test_dict_default(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(cfg={}):
                return cfg
        """)
        records = scan(p)
        assert _content_contains(records, "mutable_default")

    def test_set_default(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(seen=set()):
                return seen
        """)
        # set() is a Call node, not ast.Set — should NOT be flagged at this stage
        # (we only catch literal {1,2,3}, not set())
        records = scan(p)
        assert not _content_contains(records, "mutable_default")

    def test_set_literal_default(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(s={1, 2, 3}):
                return s
        """)
        records = scan(p)
        assert _content_contains(records, "mutable_default")

    def test_immutable_default_not_flagged(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(x=None, y=0, z="hello"):
                return x, y, z
        """)
        records = scan(p)
        assert not _content_contains(records, "mutable_default")

    def test_kwonly_mutable_default(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(*, items=[]):
                return items
        """)
        records = scan(p)
        assert _content_contains(records, "mutable_default")


# ---------------------------------------------------------------------------
# Deep nesting
# ---------------------------------------------------------------------------


class TestDeepNesting:
    def test_deep_if_nesting(self, tmp_path):
        depth = MAX_NESTING_DEPTH + 1
        indent = "    "
        lines = ["def foo(x):"]
        for i in range(depth):
            lines.append(indent * (i + 1) + f"if x > {i}:")
        lines.append(indent * (depth + 1) + "pass")
        p = _write(tmp_path, "f.py", "\n".join(lines))
        records = scan(p)
        assert _content_contains(records, "deep_nesting")

    def test_shallow_nesting_not_flagged(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(x):
                if x:
                    for i in range(x):
                        pass
        """)
        records = scan(p)
        assert not _content_contains(records, "deep_nesting")


# ---------------------------------------------------------------------------
# Missing annotations
# ---------------------------------------------------------------------------


class TestMissingAnnotation:
    def test_unannotated_param(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(x) -> int:
                return x
        """)
        records = scan(p)
        assert _content_contains(records, "missing_annotation")
        assert _content_contains(records, "'x'")

    def test_missing_return_annotation(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(x: int):
                return x
        """)
        records = scan(p)
        assert _content_contains(records, "missing_annotation")
        assert _content_contains(records, "return type")

    def test_fully_annotated_passes(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo(x: int) -> int:
                return x
        """)
        records = scan(p)
        assert not _content_contains(records, "missing_annotation")

    def test_dunder_methods_skipped(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            class Foo:
                def __init__(self, x):
                    self.x = x
        """)
        records = scan(p)
        assert not _content_contains(records, "missing_annotation")

    def test_self_not_flagged(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            class Foo:
                def method(self, x: int) -> int:
                    return x
        """)
        records = scan(p)
        assert not _content_contains(records, "missing_annotation")


# ---------------------------------------------------------------------------
# Unreachable code
# ---------------------------------------------------------------------------


class TestUnreachableCode:
    def test_code_after_return(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo():
                return 1
                x = 2
        """)
        records = scan(p)
        assert _content_contains(records, "unreachable_code")
        assert _content_contains(records, "return")

    def test_code_after_raise(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo():
                raise ValueError("bad")
                x = 2
        """)
        records = scan(p)
        assert _content_contains(records, "unreachable_code")

    def test_return_at_end_not_flagged(self, tmp_path):
        p = _write(tmp_path, "f.py", """
            def foo():
                x = 1
                return x
        """)
        records = scan(p)
        assert not _content_contains(records, "unreachable_code")


# ---------------------------------------------------------------------------
# scan_project
# ---------------------------------------------------------------------------


class TestScanProject:
    def test_finds_files_recursively(self, tmp_path):
        sub = tmp_path / "pkg"
        sub.mkdir()
        _write(sub, "a.py", """
            def foo(x=[]):
                pass
        """)
        _write(sub, "b.py", """
            try:
                pass
            except:
                pass
        """)
        records = scan_project(tmp_path)
        assert _content_contains(records, "mutable_default")
        assert _content_contains(records, "broad_except")

    def test_skips_venv(self, tmp_path):
        venv = tmp_path / ".venv" / "lib"
        venv.mkdir(parents=True)
        _write(venv, "bad.py", """
            try:
                pass
            except:
                pass
        """)
        records = scan_project(tmp_path)
        assert len(records) == 0

    def test_syntax_error_returns_empty(self, tmp_path):
        p = _write(tmp_path, "bad.py", "def foo(:\n    pass\n")
        records = scan(p)
        assert records == []
