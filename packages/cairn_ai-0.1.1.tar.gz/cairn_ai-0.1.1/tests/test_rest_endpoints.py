"""Tests for the org-shared-store REST endpoints: /health, /ingest, /query."""

from __future__ import annotations

import json
import socket
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import pytest

import cairn.inject.mcp_server as _mcp_mod
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

_NOW = datetime.now(tz=timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_port(host: str, port: int, timeout: float = 3.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.1):
                return
        except OSError:
            time.sleep(0.05)
    raise RuntimeError(f"Server did not start on {host}:{port} within {timeout}s")


class _HttpServer:
    """Start cairn HTTP server in a daemon thread for the duration of a `with` block."""

    def __init__(self, db: Path, token: str | None = None) -> None:
        self.db = db
        self.token = token
        self.port = _free_port()
        self.base = f"http://127.0.0.1:{self.port}"

    def __enter__(self) -> "_HttpServer":
        self._thread = threading.Thread(
            target=_mcp_mod.serve,
            kwargs=dict(
                host="127.0.0.1",
                port=self.port,
                transport="http",
                db_path=self.db,
                token=self.token,
            ),
            daemon=True,
        )
        self._thread.start()
        _wait_for_port("127.0.0.1", self.port)
        return self

    def __exit__(self, *_) -> None:
        pass  # daemon thread dies automatically

    def _request(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, bytes]:
        url = self.base + path
        req = urllib.request.Request(url, data=body, method=method)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def get(self, path: str, headers: dict[str, str] | None = None) -> tuple[int, bytes]:
        return self._request("GET", path, headers=headers)

    def post(self, path: str, body: bytes = b"", headers: dict[str, str] | None = None) -> tuple[int, bytes]:
        return self._request("POST", path, body=body, headers=headers)


def _seed(db: Path, records: list[TruthRecord]) -> None:
    with Writer(db) as w:
        w.write_many(records)


def _r(content: str = "test failure", source: str = "pytest") -> TruthRecord:
    return TruthRecord(
        source=source, domain="test", content=content,
        confidence=1.0, occurred_at=_NOW,
    )


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------

class TestHealth:
    def test_health_returns_200(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, _ = srv.get("/health")
        assert code == 200

    def test_health_body_has_status_ok(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            _, body = srv.get("/health")
        assert json.loads(body)["status"] == "ok"

    def test_health_body_has_store_path(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            _, body = srv.get("/health")
        assert "store" in json.loads(body)

    def test_health_no_auth_required_even_when_token_set(self, tmp_path):
        with _HttpServer(tmp_path / "store.db", token="s3cr3t") as srv:
            code, _ = srv.get("/health")
        assert code == 200


# ---------------------------------------------------------------------------
# /ingest — no-auth mode
# ---------------------------------------------------------------------------

class TestIngestNoAuth:
    def test_ingest_single_record(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, body = srv.post("/ingest", body=b'{"content":"hello world","source":"test"}')
        data = json.loads(body)
        assert code == 200
        assert data["ingested"] == 1
        assert data["errors"] == []

    def test_ingest_multiple_records(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            lines = b"\n".join(
                json.dumps({"content": f"fact {i}", "source": "test"}).encode()
                for i in range(5)
            )
            _, body = srv.post("/ingest", body=lines)
        assert json.loads(body)["ingested"] == 5

    def test_ingest_bad_json_line_reported_as_error(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            _, resp = srv.post("/ingest", body=b'{"content":"ok"}\nnot-json\n{"content":"also ok"}')
        data = json.loads(resp)
        assert data["ingested"] == 2
        assert len(data["errors"]) == 1

    def test_ingest_missing_content_reported_as_error(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            _, resp = srv.post("/ingest", body=b'{"source":"test","domain":"x"}')
        data = json.loads(resp)
        assert data["ingested"] == 0
        assert len(data["errors"]) == 1

    def test_ingest_empty_body_returns_400(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, _ = srv.post("/ingest", body=b"")
        assert code == 400

    def test_ingest_records_appear_in_store(self, tmp_path):
        db = tmp_path / "store.db"
        with _HttpServer(db) as srv:
            srv.post("/ingest", body=b'{"content":"unique fact xyz","source":"rest"}')
        from cairn.store.writer import get_all
        assert any("unique fact xyz" in r.content for r in get_all(db))

    def test_ingest_optional_fields_stored(self, tmp_path):
        db = tmp_path / "store.db"
        payload = json.dumps({
            "content": "optional fields test",
            "source": "rest",
            "domain": "myapp",
            "confidence": 0.8,
            "exception_type": "RuntimeError",
            "source_file": "/app/foo.py",
            "source_line": 42,
        }).encode()
        with _HttpServer(db) as srv:
            srv.post("/ingest", body=payload)
        from cairn.store.writer import get_all
        r = next(r for r in get_all(db) if "optional fields" in r.content)
        assert r.domain == "myapp"
        assert r.confidence == pytest.approx(0.8)
        assert r.exception_type == "RuntimeError"
        assert r.source_file == "/app/foo.py"
        assert r.source_line == 42


# ---------------------------------------------------------------------------
# /ingest — with bearer auth
# ---------------------------------------------------------------------------

class TestIngestAuth:
    TOKEN = "my-secret-token"

    def test_ingest_without_token_returns_401(self, tmp_path):
        with _HttpServer(tmp_path / "store.db", token=self.TOKEN) as srv:
            code, _ = srv.post("/ingest", body=b'{"content":"x","source":"t"}')
        assert code == 401

    def test_ingest_with_correct_token_succeeds(self, tmp_path):
        with _HttpServer(tmp_path / "store.db", token=self.TOKEN) as srv:
            code, body = srv.post(
                "/ingest",
                body=b'{"content":"x","source":"t"}',
                headers={"Authorization": f"Bearer {self.TOKEN}"},
            )
        assert code == 200
        assert json.loads(body)["ingested"] == 1

    def test_ingest_with_wrong_token_returns_401(self, tmp_path):
        with _HttpServer(tmp_path / "store.db", token=self.TOKEN) as srv:
            code, _ = srv.post(
                "/ingest",
                body=b'{"content":"x","source":"t"}',
                headers={"Authorization": "Bearer wrong-token"},
            )
        assert code == 401


# ---------------------------------------------------------------------------
# /query
# ---------------------------------------------------------------------------

class TestQueryNoAuth:
    def test_query_returns_results(self, tmp_path):
        db = tmp_path / "store.db"
        _seed(db, [_r("KeyError in config loader"), _r("ValueError in parser")])
        with _HttpServer(db) as srv:
            code, resp = srv.post("/query", body=b'{"q":"config loader"}')
        assert code == 200
        data = json.loads(resp)
        assert "results" in data
        assert len(data["results"]) >= 1

    def test_query_missing_q_returns_400(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, _ = srv.post("/query", body=b'{"top_k":5}')
        assert code == 400

    def test_query_empty_body_returns_400(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, _ = srv.post("/query", body=b"")
        assert code == 400

    def test_query_respects_top_k(self, tmp_path):
        db = tmp_path / "store.db"
        _seed(db, [_r(f"record number {i}") for i in range(10)])
        with _HttpServer(db) as srv:
            _, resp = srv.post("/query", body=b'{"q":"record","top_k":3}')
        assert len(json.loads(resp)["results"]) <= 3

    def test_query_result_fields(self, tmp_path):
        db = tmp_path / "store.db"
        _seed(db, [_r("important crash in handler")])
        with _HttpServer(db) as srv:
            _, resp = srv.post("/query", body=b'{"q":"crash"}')
        results = json.loads(resp)["results"]
        assert results
        for field in ("id", "source", "domain", "content", "confidence", "occurred_at"):
            assert field in results[0], f"missing field: {field}"

    def test_query_source_filter(self, tmp_path):
        db = tmp_path / "store.db"
        _seed(db, [
            _r("error from monitor", source="monitor"),
            _r("error from pytest", source="pytest"),
        ])
        with _HttpServer(db) as srv:
            _, resp = srv.post("/query", body=b'{"q":"error","source":"monitor"}')
        results = json.loads(resp)["results"]
        assert all(r["source"] == "monitor" for r in results)


class TestQueryAuth:
    TOKEN = "query-token"

    def test_query_without_token_returns_401(self, tmp_path):
        with _HttpServer(tmp_path / "store.db", token=self.TOKEN) as srv:
            code, _ = srv.post("/query", body=b'{"q":"anything"}')
        assert code == 401

    def test_query_with_correct_token_succeeds(self, tmp_path):
        db = tmp_path / "store.db"
        _seed(db, [_r("test record")])
        with _HttpServer(db, token=self.TOKEN) as srv:
            code, _ = srv.post(
                "/query",
                body=b'{"q":"test"}',
                headers={"Authorization": f"Bearer {self.TOKEN}"},
            )
        assert code == 200


# ---------------------------------------------------------------------------
# Unknown routes
# ---------------------------------------------------------------------------

class TestUnknownRoutes:
    def test_get_unknown_returns_404(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, _ = srv.get("/does-not-exist")
        assert code == 404

    def test_post_unknown_returns_404(self, tmp_path):
        with _HttpServer(tmp_path / "store.db") as srv:
            code, _ = srv.post("/does-not-exist", body=b"{}")
        assert code == 404
