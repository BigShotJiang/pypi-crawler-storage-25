"""Tests for Tier 1–3 features: scan --with-git, --exclude, --blame,
context multi-domain, confidence bumping, annotate --clear, export, and
new AST checks."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest
from click.testing import CliRunner

from cairn.cli import main
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer, get_all

_NOW = datetime.now(tz=timezone.utc)


def _seed(db: Path, records: list[TruthRecord]) -> None:
    with Writer(db) as w:
        w.write_many(records)


def _r(
    source: str = "pytest",
    domain: str = "proj",
    content: str = "FAIL tests/test_x.py::test_y\nAssertionError",
    confidence: float = 1.0,
    exception_type: str | None = "AssertionError",
    source_file: str | None = None,
    source_line: int | None = None,
) -> TruthRecord:
    return TruthRecord(
        source=source, domain=domain, content=content,
        confidence=confidence, occurred_at=_NOW,
        exception_type=exception_type,
        source_file=source_file,
        source_line=source_line,
    )


# ---------------------------------------------------------------------------
# Tier 1: cairn scan --with-git
# ---------------------------------------------------------------------------

class TestScanWithGit:
    def test_scan_with_git_flag_accepted(self, tmp_path):
        """--with-git should be accepted and produce output (even if no git repo)."""
        py_file = tmp_path / "example.py"
        py_file.write_text("x = 1\n")
        runner = CliRunner()
        result = runner.invoke(main, [
            "scan", str(py_file), "--no-write", "--with-git", "--since", "HEAD~5",
        ])
        assert result.exit_code == 0
        # Should either show git results or "no commits" message
        assert "Git linker" in result.output or "No structural issues" in result.output


# ---------------------------------------------------------------------------
# Tier 1: cairn scan --exclude
# ---------------------------------------------------------------------------

class TestScanExclude:
    def test_exclude_dirs(self, tmp_path):
        """--exclude should skip specified directories."""
        # Create files in regular and excluded dirs
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "good.py").write_text("def f():\n    try:\n        pass\n    except:\n        pass\n")
        (tmp_path / "vendor").mkdir()
        (tmp_path / "vendor" / "bad.py").write_text("def g():\n    try:\n        pass\n    except:\n        pass\n")

        runner = CliRunner()
        # Without exclude - should find issues in both
        result = runner.invoke(main, ["scan", str(tmp_path), "--no-write"])
        assert "broad_except" in result.output

        # With exclude - should skip vendor
        result_excluded = runner.invoke(main, [
            "scan", str(tmp_path), "--no-write", "--exclude", "vendor",
        ])
        # Should still find the src one but not vendor
        assert result_excluded.exit_code == 0


# ---------------------------------------------------------------------------
# Tier 1: Context builder multi-domain
# ---------------------------------------------------------------------------

class TestContextMultiDomain:
    def test_single_domain_uses_domain_name(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(domain="myproject")])
        from cairn.inject.context import build_context
        ctx = build_context(db_path=db)
        assert "myproject" in ctx

    def test_multi_domain_groups_separately(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(domain="auth", content="FAIL auth::login\nValueError"),
            _r(domain="billing", content="FAIL billing::charge\nTypeError",
               exception_type="TypeError"),
        ])
        from cairn.inject.context import build_context
        ctx = build_context(db_path=db)
        assert "multi-module" in ctx
        assert "auth" in ctx
        assert "billing" in ctx


# ---------------------------------------------------------------------------
# Tier 2: Confidence bumping on re-observation
# ---------------------------------------------------------------------------

class TestConfidenceBump:
    def test_confidence_increases_on_reobservation(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        r = _r(confidence=0.80)
        with Writer(db) as w:
            w.write(r)
            w.write(r)  # re-observation
            w.write(r)  # third observation

        records = get_all(db)
        assert len(records) == 1
        assert records[0].observation_count == 3
        # After 3 writes: bump = 0.80 + 0.02*1 = 0.82, then 0.80 + 0.02*2 = 0.84
        assert records[0].confidence > 0.80

    def test_confidence_capped_at_one(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        r = _r(confidence=0.99)
        with Writer(db) as w:
            for _ in range(100):
                w.write(r)
        records = get_all(db)
        assert records[0].confidence <= 1.0


# ---------------------------------------------------------------------------
# Tier 2: New AST scanner checks
# ---------------------------------------------------------------------------

class TestNewASTChecks:
    def test_print_statement(self, tmp_path):
        py_file = tmp_path / "lib.py"
        py_file.write_text("def hello():\n    print('debug')\n")
        from cairn.capture.ast_scanner import scan
        records = scan(py_file)
        assert any("print_statement" in r.content for r in records)

    def test_assert_in_library(self, tmp_path):
        py_file = tmp_path / "lib.py"
        py_file.write_text("def validate(x):\n    assert x > 0\n")
        from cairn.capture.ast_scanner import scan
        records = scan(py_file)
        assert any("assert_in_library" in r.content for r in records)

    def test_assert_not_flagged_in_test(self, tmp_path):
        py_file = tmp_path / "test_something.py"
        py_file.write_text("def test_ok():\n    assert True\n")
        from cairn.capture.ast_scanner import scan
        records = scan(py_file)
        assert not any("assert_in_library" in r.content for r in records)

    def test_fstring_in_logging(self, tmp_path):
        py_file = tmp_path / "lib.py"
        py_file.write_text(
            "import logging\n"
            "log = logging.getLogger()\n"
            "def run(x):\n"
            "    log.info(f'processing {x}')\n"
        )
        from cairn.capture.ast_scanner import scan
        records = scan(py_file)
        assert any("fstring_in_logging" in r.content for r in records)

    def test_magic_number(self, tmp_path):
        py_file = tmp_path / "lib.py"
        py_file.write_text("def calc(x):\n    if x == 42:\n        return True\n")
        from cairn.capture.ast_scanner import scan
        records = scan(py_file)
        assert any("magic_number" in r.content for r in records)

    def test_benign_numbers_not_flagged(self, tmp_path):
        py_file = tmp_path / "lib.py"
        py_file.write_text("def f(x):\n    if x == 1:\n        return True\n")
        from cairn.capture.ast_scanner import scan
        records = scan(py_file)
        assert not any("magic_number" in r.content for r in records)


# ---------------------------------------------------------------------------
# Tier 3: cairn export
# ---------------------------------------------------------------------------

class TestExport:
    def test_export_json(self, tmp_path):
        import json
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL test_a"), _r(content="FAIL test_b")])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--db", str(db), "--format", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 2

    def test_export_csv(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL test_a")])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--db", str(db), "--format", "csv"])
        assert result.exit_code == 0
        assert "id,source,domain" in result.output

    def test_export_filter_by_source(self, tmp_path):
        import json
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(source="pytest", content="FAIL a"),
            _r(source="ast", content="broad_except: line 5", exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, [
            "export", "--db", str(db), "--format", "json", "--source", "ast",
        ])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["source"] == "ast"

    def test_export_to_file(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r()])
        out = tmp_path / "out.json"
        runner = CliRunner()
        result = runner.invoke(main, [
            "export", "--db", str(db), "-o", str(out),
        ])
        assert result.exit_code == 0
        assert out.exists()

    def test_strip_scope_drops_non_donatable_sources(self, tmp_path):
        """pytest records must be excluded from donation output."""
        import json
        db = tmp_path / ".cairn" / "store.db"
        out = tmp_path / "anon.json"
        _seed(db, [
            _r(source="pytest", domain="python/acme", content="FAIL test_a"),
            _r(source="ruff", domain="python/acme", content="E501 line too long",
               exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "json",
                                      "--output", str(out), "--db", str(db)])
        assert result.exit_code == 0
        data = json.loads(out.read_text())
        assert len(data) == 1
        assert data[0]["source"] == "ruff"

    def test_strip_scope_strips_org_domain(self, tmp_path):
        """Org-scoped domain python/acme.billing must be anonymised to python."""
        import json
        db = tmp_path / ".cairn" / "store.db"
        out = tmp_path / "anon.json"
        _seed(db, [
            _r(source="ruff", domain="python/acme.billing", content="E501 line too long",
               exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "json",
                                      "--output", str(out), "--db", str(db)])
        assert result.exit_code == 0
        data = json.loads(out.read_text())
        assert data[0]["domain"] == "python"

    def test_strip_scope_keeps_tool_domain(self, tmp_path):
        """Tool-scoped domain python/mypy must be preserved (not stripped)."""
        import json
        db = tmp_path / ".cairn" / "store.db"
        out = tmp_path / "anon.json"
        _seed(db, [
            _r(source="mypy", domain="python/mypy", content="error: arg missing",
               exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "json",
                                      "--output", str(out), "--db", str(db)])
        assert result.exit_code == 0
        data = json.loads(out.read_text())
        assert data[0]["domain"] == "python/mypy"

    def test_strip_scope_nulls_source_file(self, tmp_path):
        """source_file must be None in donation output."""
        import json
        db = tmp_path / ".cairn" / "store.db"
        out = tmp_path / "anon.json"
        _seed(db, [
            _r(source="ruff", domain="python/acme", content="E501 line too long",
               source_file="/home/seth/dev/acme/billing.py", source_line=10,
               exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "json",
                                      "--output", str(out), "--db", str(db)])
        assert result.exit_code == 0
        data = json.loads(out.read_text())
        assert data[0]["source_file"] is None
        assert data[0]["source_line"] is None

    def test_strip_scope_recomputes_id(self, tmp_path):
        """Anonymised record must have a different id when domain changes."""
        import json
        db = tmp_path / ".cairn" / "store.db"
        out = tmp_path / "anon.json"
        rec = _r(source="ruff", domain="python/acme.billing", content="E501 line too long",
                 exception_type=None)
        _seed(db, [rec])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "json",
                                      "--output", str(out), "--db", str(db)])
        assert result.exit_code == 0
        data = json.loads(out.read_text())
        assert data[0]["id"] != rec.id

    def test_strip_scope_db_format_writes_sqlite(self, tmp_path):
        """--format db must produce a readable SQLite file with the anon records."""
        import sqlite3
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(source="ruff", domain="python/acme", content="E501 line too long",
               exception_type=None),
            _r(source="pytest", domain="python/acme", content="FAIL test_a"),
        ])
        out_db = tmp_path / "anon.db"
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "db",
                                      "--output", str(out_db), "--db", str(db)])
        assert result.exit_code == 0
        assert out_db.exists()
        con = sqlite3.connect(out_db)
        rows = con.execute("SELECT source FROM truth_records").fetchall()
        con.close()
        sources = {r[0] for r in rows}
        assert sources == {"ruff"}

    def test_strip_scope_skips_bare_domain(self, tmp_path):
        """Records with a bare domain (no language prefix) must be skipped."""
        db = tmp_path / ".cairn" / "store.db"
        out = tmp_path / "anon.json"
        _seed(db, [
            _r(source="ruff", domain="acme", content="E501 line too long",
               exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["export", "--strip-scope", "--format", "json",
                                      "--output", str(out), "--db", str(db)])
        assert result.exit_code == 0
        # All records skipped due to bare domain — output file not written
        assert not out.exists()


# ---------------------------------------------------------------------------
# Tier 3: cairn annotate --clear
# ---------------------------------------------------------------------------

class TestAnnotateClear:
    def test_clear_removes_annotations(self, tmp_path):
        py_file = tmp_path / "annotated.py"
        py_file.write_text(
            "# cairn[ast]: broad_except at line 3 (conf=0.85)\n"
            "def f():\n"
            "    try:\n"
            "        pass\n"
            "    except:\n"
            "        pass\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["annotate", str(py_file), "--clear"])
        assert result.exit_code == 0
        content = py_file.read_text()
        assert "# cairn[" not in content
        assert "def f():" in content

    def test_clear_dry_run_shows_diff(self, tmp_path):
        py_file = tmp_path / "annotated.py"
        py_file.write_text(
            "# cairn[ast]: something\n"
            "x = 1\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["annotate", str(py_file), "--clear", "--dry-run"])
        assert result.exit_code == 0
        # File should be unchanged
        content = py_file.read_text()
        assert "# cairn[" in content


# ---------------------------------------------------------------------------
# Tier 3: git blame integration
# ---------------------------------------------------------------------------

class TestGitBlame:
    def test_blame_records_returns_empty_for_non_git(self, tmp_path):
        from cairn.capture.git_linker import blame_records
        results = blame_records(tmp_path)
        assert results == []


# ---------------------------------------------------------------------------
# Tier 2: rules mapping for new checks
# ---------------------------------------------------------------------------

class TestNewRules:
    def test_magic_number_rule(self):
        from cairn.distill.rules import encode_as_rule
        records = [_r(
            source="ast", content="magic_number: bare numeric literal",
            exception_type=None,
        )]
        rule = encode_as_rule("magic_number (1 occurrence)", records)
        assert rule is not None
        assert "PLR2004" in rule

    def test_print_statement_rule(self):
        from cairn.distill.rules import encode_as_rule
        records = [_r(
            source="ast", content="print_statement: stray print()",
            exception_type=None,
        )]
        rule = encode_as_rule("print_statement (1 occurrence)", records)
        assert rule is not None
        assert "T201" in rule
