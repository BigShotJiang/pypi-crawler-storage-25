"""Tests for the Cairn pytest plugin (self-referential — exercises the plugin
that is also active during this test run)."""

from __future__ import annotations

from pathlib import Path


def test_plugin_creates_store(pytestconfig):
    """After this test session the store should exist (populated by the plugin)."""
    db = Path(pytestconfig.rootpath) / ".cairn" / "store.db"
    # The store may not exist yet if this is the very first run with no prior tests,
    # but it will exist after this session completes. We just assert the path is valid.
    assert db.parent.name == ".cairn"
