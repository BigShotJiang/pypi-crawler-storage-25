"""Tests for cairn annotate and cairn install-hook CLI commands."""

from __future__ import annotations

import stat
from datetime import datetime, timezone
from pathlib import Path

from click.testing import CliRunner

from cairn.cli import main
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

_NOW = datetime.now(tz=timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _seed(db: Path, records: list[TruthRecord]) -> None:
    with Writer(db) as w:
        w.write_many(records)


def _r(source_file: str | None = None, source_line: int | None = None,
       content: str = "broad_except: except at line 5",
       source: str = "ast", confidence: float = 0.9) -> TruthRecord:
    return TruthRecord(
        source=source, domain="proj", content=content, confidence=confidence,
        occurred_at=_NOW, source_file=source_file, source_line=source_line,
    )


# ---------------------------------------------------------------------------
# cairn annotate
# ---------------------------------------------------------------------------


class TestAnnotateCommand:
    def test_no_store_prints_message(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["annotate", "."])
        assert result.exit_code == 0
        assert "No store found" in result.output

    def test_no_source_file_records_prints_message(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        # Record without source_file
        _seed(db, [_r(source_file=None, source_line=None)])
        runner = CliRunner()
        result = runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db)])
        assert result.exit_code == 0
        assert "No records with source_file" in result.output

    def test_annotates_file_in_place(self, tmp_path):
        py_file = tmp_path / "target.py"
        py_file.write_text("def foo():\n    pass\n")
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(source_file=str(py_file), source_line=1,
                      content="broad_except: oops", source="ast")])

        runner = CliRunner()
        result = runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db)])
        assert result.exit_code == 0
        text = py_file.read_text()
        assert "# cairn[ast]:" in text
        assert "broad_except: oops" in text

    def test_annotation_placed_before_target_line(self, tmp_path):
        py_file = tmp_path / "target.py"
        py_file.write_text("x = 1\ndef bar():\n    pass\n")
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(source_file=str(py_file), source_line=2,
                      content="deep_nesting: line 2")])

        runner = CliRunner()
        runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db)])
        lines = py_file.read_text().splitlines()
        # annotation must appear immediately before "def bar():"
        bar_idx = next(i for i, line in enumerate(lines) if "def bar" in line)
        assert "# cairn[" in lines[bar_idx - 1]

    def test_dry_run_does_not_write(self, tmp_path):
        py_file = tmp_path / "module.py"
        original = "def baz():\n    pass\n"
        py_file.write_text(original)
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(source_file=str(py_file), source_line=1)])

        runner = CliRunner()
        result = runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db), "--dry-run"])
        assert result.exit_code == 0
        assert py_file.read_text() == original  # not modified
        assert "cairn[" in result.output  # diff shown

    def test_idempotent_no_double_annotation(self, tmp_path):
        py_file = tmp_path / "thing.py"
        py_file.write_text("def cfg():\n    pass\n")
        db = tmp_path / ".cairn" / "store.db"
        rec = _r(source_file=str(py_file), source_line=1, content="broad_except")
        _seed(db, [rec])

        runner = CliRunner()
        runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db)])
        text_after_first = py_file.read_text()
        runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db)])
        text_after_second = py_file.read_text()
        assert text_after_first == text_after_second

    def test_skips_nonexistent_source_files(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(source_file="/no/such/file.py", source_line=1)])
        py_file = tmp_path / "real.py"
        py_file.write_text("pass\n")
        runner = CliRunner()
        result = runner.invoke(main, ["annotate", str(tmp_path), "--db", str(db)])
        assert result.exit_code == 0
        assert "# cairn[" not in py_file.read_text()


# ---------------------------------------------------------------------------
# cairn install-hook
# ---------------------------------------------------------------------------


class TestInstallHookCommand:
    def _init_git(self, path: Path) -> Path:
        """Create a minimal .git structure."""
        git_dir = path / ".git"
        (git_dir / "hooks").mkdir(parents=True)
        return git_dir

    def test_installs_hook_in_fresh_repo(self, tmp_path):
        self._init_git(tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        assert result.exit_code == 0
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        assert hook_path.exists()
        content = hook_path.read_text()
        assert "cairn distill" in content
        assert "installed by cairn" in content

    def test_hook_is_executable(self, tmp_path):
        self._init_git(tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        mode = hook_path.stat().st_mode
        assert mode & stat.S_IXUSR

    def test_hook_shebang_present(self, tmp_path):
        self._init_git(tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        assert hook_path.read_text().startswith("#!/bin/sh")

    def test_idempotent_no_duplicate(self, tmp_path):
        self._init_git(tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        count = hook_path.read_text().count("cairn distill")
        assert count == 1

    def test_appends_to_existing_hook(self, tmp_path):
        self._init_git(tmp_path)
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        hook_path.write_text("#!/bin/sh\necho 'custom hook'\n")
        runner = CliRunner()
        result = runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        assert result.exit_code == 0
        content = hook_path.read_text()
        assert "custom hook" in content
        assert "cairn distill" in content

    def test_custom_hook_name(self, tmp_path):
        self._init_git(tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path),
                                      "--hook", "pre-push"])
        assert result.exit_code == 0
        hook_path = tmp_path / ".git" / "hooks" / "pre-push"
        assert hook_path.exists()
        assert "cairn distill" in hook_path.read_text()

    def test_no_git_dir_exits_nonzero(self, tmp_path):
        runner = CliRunner()
        result = runner.invoke(main, ["install-hook", "--repo-root", str(tmp_path)])
        assert result.exit_code != 0
