"""Tests for embedder, query, MCP server, and cline integration."""

from __future__ import annotations

import io
import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from cairn.inject.cline import write_context_file, write_copilot_instructions
from cairn.inject.mcp_server import dispatch
from cairn.store.embedder import _hash_embed, _tokenize, embed, embed_query
from cairn.store.query import _cosine, by_source, recent_failures, semantic_search
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

_NOW = datetime.now(tz=timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _r(
    source: str = "pytest",
    content: str = "FAIL tests/test_foo.py::test_bar",
    confidence: float = 1.0,
    exception_type: str | None = "ValueError",
    source_file: str | None = "/repo/foo.py",
    domain: str = "proj",
) -> TruthRecord:
    return TruthRecord(
        source=source, domain=domain, content=content,
        confidence=confidence, occurred_at=_NOW,
        exception_type=exception_type, source_file=source_file,
    )


def _seed(db: Path, records: list[TruthRecord]) -> None:
    with Writer(db) as w:
        w.write_many(records)


# ---------------------------------------------------------------------------
# Embedder
# ---------------------------------------------------------------------------


class TestEmbedder:
    def test_hash_embed_returns_fixed_dim(self):
        vec = _hash_embed("some text about ValueError in config.py")
        assert len(vec) == 512

    def test_hash_embed_is_normalised(self):
        import math
        vec = _hash_embed("hello world")
        norm = math.sqrt(sum(x * x for x in vec))
        assert norm == pytest.approx(1.0, abs=1e-6)

    def test_hash_embed_deterministic(self):
        a = _hash_embed("same input")
        b = _hash_embed("same input")
        assert a == b

    def test_hash_embed_different_inputs_differ(self):
        a = _hash_embed("ValueError in config")
        b = _hash_embed("KeyError in parser")
        assert a != b

    def test_tokenize_lowercases(self):
        tokens = _tokenize("ValueError IN Config.py")
        assert "valueerror" in tokens
        assert "config" in tokens

    def test_embed_populates_records(self):
        records = [_r(content="ValueError in config"), _r(content="KeyError in parser")]
        result = embed(records)
        assert all(len(r.embedding) > 0 for r in result)
        assert result is records  # mutated in-place, same list returned

    def test_embed_empty_list(self):
        assert embed([]) == []

    def test_embed_query_returns_vector(self):
        vec = embed_query("find ValueError failures")
        assert len(vec) > 0
        assert all(isinstance(x, float) for x in vec)


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------


class TestQuery:
    def test_by_source_filters_correctly(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [
            _r(source="pytest", content="PASS a"),
            _r(source="ast", content="broad_except: line 5", exception_type=None),
        ]
        _seed(db, records)
        ast_records = by_source("ast", db)
        assert len(ast_records) == 1
        assert ast_records[0].source == "ast"

    def test_by_source_empty_when_none_match(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(source="pytest", content="PASS a")])
        assert by_source("git", db) == []

    def test_recent_failures_returns_failures(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [
            _r(content="FAIL tests/test_a::test_x\nexception: ValueError"),
            _r(content="PASS tests/test_b::test_y", exception_type=None),
            _r(content="RAISE boom ValueError", source="monitor"),
        ]
        _seed(db, records)
        failures = recent_failures(n=10, db_path=db)
        contents = [r.content for r in failures]
        assert any("FAIL" in c for c in contents)
        assert not any("PASS" in c for c in contents)

    def test_recent_failures_excludes_failover_false_positive(self, tmp_path):
        """Words like 'failover' should not be matched as failures."""
        db = tmp_path / ".cairn" / "store.db"
        records = [
            _r(content="CALL failover_to_backup", source="monitor", exception_type=None),
            _r(content="FAIL tests/test_real.py::test_a", exception_type="AssertionError"),
        ]
        _seed(db, records)
        failures = recent_failures(n=10, db_path=db)
        contents = [r.content for r in failures]
        assert any("FAIL" in c for c in contents)
        assert not any("failover" in c for c in contents)

    def test_mcp_ignores_client_db_path(self, tmp_path):
        """MCP handlers should use server-pinned db, not client-supplied path."""
        import cairn.inject.mcp_server as _mcp
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL x", exception_type="E")])
        _mcp._server_db = db

        # Even if a rogue client sends a db_path, it's ignored
        result = _mcp._handle_cairn_status({"db_path": "/etc/shadow"})
        assert result["total"] == 1  # used the pinned db, not the client path

    def test_recent_failures_cap(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [_r(content=f"FAIL test_{i}", exception_type="E") for i in range(20)]
        _seed(db, records)
        result = recent_failures(n=5, db_path=db)
        assert len(result) == 5

    def test_semantic_search_keyword_fallback(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [
            _r(content="FAIL ValueError in config parsing", exception_type="ValueError"),
            _r(content="FAIL KeyError in database layer", exception_type="KeyError"),
            _r(content="PASS green test", exception_type=None),
        ]
        _seed(db, records)
        results = semantic_search("ValueError config", top_k=2, db_path=db)
        assert len(results) <= 2
        # Best match should be the ValueError record
        assert "ValueError" in results[0].content

    def test_semantic_search_with_embeddings(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [
            _r(content="FAIL ValueError in config parsing", exception_type="ValueError"),
            _r(content="FAIL KeyError in database layer", exception_type="KeyError"),
        ]
        embed(records)  # populate embeddings
        _seed(db, records)
        # Re-read from DB (embeddings stored as JSON)
        results = semantic_search("ValueError config failure", top_k=1, db_path=db)
        assert len(results) == 1

    def test_cosine_identical_vectors(self):
        v = [1.0, 0.0, 0.0]
        assert _cosine(v, v) == pytest.approx(1.0)

    def test_cosine_orthogonal_vectors(self):
        assert _cosine([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)

    def test_cosine_mismatched_dims(self):
        assert _cosine([1.0, 0.0], [1.0, 0.0, 0.0]) == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------


class TestMCPServer:
    def _dispatch(self, msg: dict) -> dict:
        buf = io.StringIO()
        dispatch(msg, out=buf)
        out = buf.getvalue().strip()
        return json.loads(out) if out else {}

    def test_initialize(self):
        resp = self._dispatch({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        assert resp["result"]["serverInfo"]["name"] == "cairn"
        assert "tools" in resp["result"]["capabilities"]

    def test_tools_list(self):
        resp = self._dispatch({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        names = [t["name"] for t in resp["result"]["tools"]]
        assert "cairn_status" in names
        assert "cairn_search" in names
        assert "cairn_context" in names
        assert "cairn_recent_failures" in names

    def test_tools_call_status(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="PASS a", exception_type=None)])
        import cairn.inject.mcp_server as _mcp
        _mcp._server_db = db
        resp = self._dispatch({
            "jsonrpc": "2.0", "id": 3,
            "method": "tools/call",
            "params": {"name": "cairn_status", "arguments": {}},
        })
        result = json.loads(resp["result"]["content"][0]["text"])
        assert result["total"] == 1
        assert "pytest" in result["by_source"]

    def test_tools_call_search(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(content="FAIL ValueError in parser", exception_type="ValueError"),
            _r(content="PASS green test", exception_type=None),
        ])
        import cairn.inject.mcp_server as _mcp
        _mcp._server_db = db
        resp = self._dispatch({
            "jsonrpc": "2.0", "id": 4,
            "method": "tools/call",
            "params": {"name": "cairn_search",
                       "arguments": {"query": "ValueError parser"}},
        })
        results = json.loads(resp["result"]["content"][0]["text"])
        assert isinstance(results, list)
        assert len(results) >= 1

    def test_tools_call_recent_failures(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL test_x", exception_type="TypeError")])
        import cairn.inject.mcp_server as _mcp
        _mcp._server_db = db
        resp = self._dispatch({
            "jsonrpc": "2.0", "id": 5,
            "method": "tools/call",
            "params": {"name": "cairn_recent_failures",
                       "arguments": {"n": 5}},
        })
        results = json.loads(resp["result"]["content"][0]["text"])
        assert isinstance(results, list)
        assert len(results) == 1

    def test_unknown_tool_returns_error(self):
        resp = self._dispatch({
            "jsonrpc": "2.0", "id": 6,
            "method": "tools/call",
            "params": {"name": "nonexistent_tool", "arguments": {}},
        })
        assert "error" in resp

    def test_unknown_method_returns_error(self):
        resp = self._dispatch({"jsonrpc": "2.0", "id": 7, "method": "bogus/method"})
        assert "error" in resp

    def test_notification_no_response(self):
        """notifications/initialized has no id — server must not send a response."""
        buf = io.StringIO()
        dispatch({"jsonrpc": "2.0", "method": "notifications/initialized"}, out=buf)
        assert buf.getvalue().strip() == ""

    def test_ping(self):
        resp = self._dispatch({"jsonrpc": "2.0", "id": 8, "method": "ping"})
        assert resp["result"] == {}


# ---------------------------------------------------------------------------
# Cline integration
# ---------------------------------------------------------------------------


class TestClineIntegration:
    def test_write_context_file_creates_file(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL test_x")])
        out = write_context_file(
            output_path=tmp_path / ".cairn" / "context.md",
            db_path=db,
        )
        assert out.exists()
        text = out.read_text()
        assert "Cairn context" in text

    def test_write_context_file_placeholder_when_empty(self, tmp_path):
        db = tmp_path / ".cairn" / "empty.db"
        out = write_context_file(
            output_path=tmp_path / "context.md",
            db_path=db,
        )
        assert out.exists()
        assert "No records yet" in out.read_text()

    def test_write_copilot_instructions_creates_file(self, tmp_path):
        out_path = tmp_path / ".github" / "copilot-instructions.md"
        result = write_copilot_instructions(output_path=out_path)
        assert result.exists()
        text = result.read_text()
        assert "copilot-instructions" in text.lower() or "cairn" in text.lower()

    def test_write_copilot_instructions_does_not_overwrite(self, tmp_path):
        out_path = tmp_path / "instructions.md"
        out_path.write_text("# manual content\n")
        write_copilot_instructions(output_path=out_path)
        assert out_path.read_text() == "# manual content\n"
