"""Tests for @cairn.watch decorator and sys.monitoring capture."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

import cairn
from cairn.capture import decorator as dec_mod
from cairn.store.writer import get_all

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_db(tmp_path: Path) -> Path:
    return tmp_path / ".cairn" / "store.db"


# Monkey-patch _DEFAULT_DB inside the decorator module so calls write to tmp
def _patch_db(monkeypatch, db_path: Path):
    monkeypatch.setattr(dec_mod, "_DEFAULT_DB", db_path)


# ---------------------------------------------------------------------------
# @cairn.watch — success path
# ---------------------------------------------------------------------------


class TestWatchDecorator:
    def test_decorated_function_returns_normally(self, tmp_path, monkeypatch):
        db = _make_db(tmp_path)
        _patch_db(monkeypatch, db)

        @cairn.watch
        def add(x: int, y: int) -> int:
            return x + y

        result = add(2, 3)
        assert result == 5

    def test_watch_writes_record_on_success(self, tmp_path, monkeypatch):
        db = _make_db(tmp_path)
        _patch_db(monkeypatch, db)

        @cairn.watch
        def greet(name: str) -> str:
            return f"hello {name}"

        greet("world")
        records = get_all(db)
        assert len(records) == 1
        assert records[0].source == "monitor"
        assert "greet" in records[0].content
        assert "'hello world'" in records[0].content

    def test_watch_writes_record_on_exception(self, tmp_path, monkeypatch):
        db = _make_db(tmp_path)
        _patch_db(monkeypatch, db)

        @cairn.watch
        def boom(x):
            raise ValueError(f"bad value: {x}")

        with pytest.raises(ValueError):
            boom(42)

        records = get_all(db)
        assert len(records) == 1
        r = records[0]
        assert r.exception_type == "ValueError"
        assert "RAISE" not in r.content  # decorator uses "exception:" not "RAISE"
        assert "ValueError" in r.content

    def test_exception_propagates(self, tmp_path, monkeypatch):
        """The decorator must never swallow exceptions."""
        db = _make_db(tmp_path)
        _patch_db(monkeypatch, db)

        @cairn.watch
        def fail():
            raise RuntimeError("sentinel")

        with pytest.raises(RuntimeError, match="sentinel"):
            fail()

    def test_records_are_idempotent(self, tmp_path, monkeypatch):
        """Calling the same function with the same args twice should upsert, not duplicate."""
        db = _make_db(tmp_path)
        _patch_db(monkeypatch, db)

        @cairn.watch
        def constant() -> int:
            return 1

        constant()
        constant()
        records = get_all(db)
        # Same content → same id → one record
        assert len(records) == 1

    def test_functools_wraps_preserved(self):
        @cairn.watch
        def documented(x: int) -> int:
            """My docstring."""
            return x

        assert documented.__name__ == "documented"
        assert documented.__doc__ == "My docstring."


# ---------------------------------------------------------------------------
# sys.monitoring capture
# ---------------------------------------------------------------------------


@pytest.mark.skipif(sys.version_info < (3, 12), reason="sys.monitoring requires 3.12+")
class TestSysMonitoring:
    def setup_method(self):
        from cairn.capture import monitor
        if monitor.is_active():
            monitor.stop()

    def teardown_method(self):
        from cairn.capture import monitor
        if monitor.is_active():
            monitor.stop()

    def test_start_stop_cycle(self, tmp_path):
        from cairn.capture import monitor
        db = _make_db(tmp_path)
        monitor.start(domains=["tests"], db_path=db)
        assert monitor.is_active()
        monitor.stop()
        assert not monitor.is_active()

    def test_start_is_idempotent(self, tmp_path):
        from cairn.capture import monitor
        db = _make_db(tmp_path)
        monitor.start(domains=["tests"], db_path=db)
        monitor.start(domains=["tests"], db_path=db)  # second call is a no-op
        assert monitor.is_active()
        monitor.stop()

    def test_stop_when_not_started_is_safe(self):
        from cairn.capture import monitor
        assert not monitor.is_active()
        monitor.stop()  # should not raise
        assert not monitor.is_active()
