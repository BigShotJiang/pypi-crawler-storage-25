"""Tests for core CLI commands: status, distill, scan, serve, install."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from click.testing import CliRunner

from cairn.cli import main
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

_NOW = datetime.now(tz=timezone.utc)


def _seed(db: Path, records: list[TruthRecord]) -> None:
    with Writer(db) as w:
        w.write_many(records)


def _r(
    source: str = "pytest",
    content: str = "FAIL tests/test_x.py::test_y\nAssertionError",
    confidence: float = 1.0,
    exception_type: str | None = "AssertionError",
    domain: str = "proj",
) -> TruthRecord:
    return TruthRecord(
        source=source, domain=domain, content=content,
        confidence=confidence, occurred_at=_NOW,
        exception_type=exception_type,
    )


class TestStatusCommand:
    def test_no_store(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "No .cairn/store.db found" in result.output

    def test_empty_store(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        # create empty store via writer constructor
        with Writer(db) as _:
            pass
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--db", str(db)])
        assert result.exit_code == 0
        assert "empty" in result.output.lower()

    def test_populated_store(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(), _r(source="ast", content="broad_except: line 5", exception_type=None)])
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--db", str(db)])
        assert result.exit_code == 0
        assert "Total records: 2" in result.output
        assert "pytest" in result.output
        assert "ast" in result.output
        assert "Active" in result.output  # decay-adjusted summary line


class TestDistillCommand:
    def test_no_store(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["distill"])
        assert result.exit_code == 0
        assert "No store found" in result.output

    def test_empty_store(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        with Writer(db) as _:
            pass
        runner = CliRunner()
        result = runner.invoke(main, ["distill", "--db", str(db)])
        assert result.exit_code == 0
        assert "empty" in result.output.lower()

    def test_distill_with_records(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [
            _r(content="FAIL tests/a.py::test_a\nValueError: bad"),
            _r(content="FAIL tests/b.py::test_b\nValueError: worse", exception_type="ValueError"),
        ]
        _seed(db, records)
        runner = CliRunner()
        result = runner.invoke(main, ["distill", "--db", str(db)])
        assert result.exit_code == 0
        assert "Distilling" in result.output
        assert "distilled pattern" in result.output.lower()


class TestScanCommand:
    def test_scan_clean_file(self, tmp_path):
        py_file = tmp_path / "clean.py"
        py_file.write_text("def greet(name: str) -> str:\n    return f'Hi {name}'\n")
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(py_file), "--no-write"])
        assert result.exit_code == 0
        assert "No structural issues" in result.output

    def test_scan_finds_issues(self, tmp_path):
        py_file = tmp_path / "messy.py"
        py_file.write_text("def foo():\n    try:\n        pass\n    except:\n        pass\n")
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(py_file), "--no-write"])
        assert result.exit_code == 0
        assert "broad_except" in result.output

    def test_scan_writes_to_store(self, tmp_path):
        py_file = tmp_path / "messy.py"
        py_file.write_text("def foo():\n    try:\n        pass\n    except:\n        pass\n")
        db = tmp_path / ".cairn" / "store.db"
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(py_file), "--db", str(db)])
        assert result.exit_code == 0
        assert "Written to" in result.output
        from cairn.store.writer import count
        totals = count(db)
        assert totals.get("ast", 0) > 0


class TestContextCommand:
    def test_empty_store(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        runner = CliRunner()
        result = runner.invoke(main, ["context", "--db", str(db)])
        assert result.exit_code == 0
        assert "empty" in result.output.lower() or "decayed" in result.output.lower()

    def test_context_outputs_markdown(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r()])
        runner = CliRunner()
        result = runner.invoke(main, ["context", "--db", str(db)])
        assert result.exit_code == 0
        assert "Cairn context" in result.output

    def test_context_writes_to_file(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r()])
        out = tmp_path / "ctx.md"
        runner = CliRunner()
        result = runner.invoke(main, ["context", "--db", str(db), "-o", str(out)])
        assert result.exit_code == 0
        assert out.exists()
        assert "Cairn context" in out.read_text()


class TestInstallCommand:
    def test_creates_copilot_instructions(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["install"])
        assert result.exit_code == 0
        assert "copilot-instructions" in result.output.lower() or "Copilot" in result.output


# ---------------------------------------------------------------------------
# cairn prune
# ---------------------------------------------------------------------------

_OLD = datetime(2020, 1, 1, tzinfo=timezone.utc)  # ~6 years before March 2026


def _old_r(
    source: str = "pytest",
    content: str = "FAIL tests/old.py::test_old\nAssertionError",
    confidence: float = 0.9,
    exception_type: str | None = "AssertionError",
) -> TruthRecord:
    """A record so old its decayed confidence is effectively 0."""
    return TruthRecord(
        source=source, domain="proj", content=content,
        confidence=confidence, occurred_at=_OLD,
        exception_type=exception_type,
    )


class TestPruneCommand:
    def test_requires_at_least_one_filter(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r()])
        runner = CliRunner()
        result = runner.invoke(main, ["prune", "--db", str(db)])
        assert result.exit_code != 0
        assert "--older-than" in result.output or "--below-confidence" in result.output

    def test_no_store(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["prune", "--below-confidence", "0.1"])
        assert result.exit_code == 0
        assert "No store found" in result.output

    def test_dry_run_shows_count_without_deleting(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_old_r(), _old_r(content="FAIL tests/b.py::test_b\nValueError")])
        runner = CliRunner()
        result = runner.invoke(main, ["prune", "--db", str(db),
                                      "--below-confidence", "0.05", "--dry-run"])
        assert result.exit_code == 0
        assert "Would delete" in result.output
        assert "Dry run" in result.output
        # Records must still be present
        from cairn.store.writer import get_all
        assert len(get_all(db)) == 2

    def test_below_confidence_deletes_stale_records(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        # one very old (stale) and one fresh record
        _seed(db, [_old_r(), _r()])
        runner = CliRunner()
        result = runner.invoke(main, ["prune", "--db", str(db),
                                      "--below-confidence", "0.05"])
        assert result.exit_code == 0
        assert "Deleted" in result.output
        from cairn.store.writer import get_all
        remaining = get_all(db)
        assert len(remaining) == 1  # only the fresh record survives

    def test_older_than_deletes_old_records(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_old_r(), _r()])
        runner = CliRunner()
        result = runner.invoke(main, ["prune", "--db", str(db), "--older-than", "365d"])
        assert result.exit_code == 0
        assert "Deleted" in result.output
        from cairn.store.writer import get_all
        remaining = get_all(db)
        assert len(remaining) == 1

    def test_source_filter_restricts_deletion(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _old_r(source="pytest"),
            _old_r(source="ast", content="broad_except: old", exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["prune", "--db", str(db),
                                      "--below-confidence", "0.05", "--source", "ast"])
        assert result.exit_code == 0
        assert "Deleted" in result.output
        from cairn.store.writer import get_all
        remaining = get_all(db)
        assert len(remaining) == 1
        assert remaining[0].source == "pytest"


# ---------------------------------------------------------------------------
# cairn query
# ---------------------------------------------------------------------------


class TestQueryCommand:
    def test_no_store(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["query", "ValueError"])
        assert result.exit_code == 0
        assert "No store found" in result.output

    def test_returns_matching_records(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(content="FAIL tests/test_a.py::test_a\nValueError: bad value"),
            _r(content="FAIL tests/test_b.py::test_b\nAssertionError"),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["query", "ValueError", "--db", str(db)])
        assert result.exit_code == 0
        # Output table always includes at least one row
        assert "pytest" in result.output

    def test_source_filter(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(source="pytest", content="FAIL tests/x.py\nValueError"),
            _r(source="ast", content="broad_except: line 5", exception_type=None),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["query", "ValueError", "--db", str(db),
                                      "--source", "pytest"])
        assert result.exit_code == 0
        assert "broad_except" not in result.output

    def test_no_results(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL tests/x.py\nAssertionError")])
        runner = CliRunner()
        result = runner.invoke(main, ["query", "xyzzy_completely_unrelated",
                                      "--db", str(db), "--top-k", "1"])
        assert result.exit_code == 0
        assert result.output  # no crash


# ---------------------------------------------------------------------------
# cairn query — federation (multi-DB)
# ---------------------------------------------------------------------------


class TestQueryFederation:
    """Tests for the --db-repeatable multi-DB federation path."""

    def _write(self, db, records):
        from cairn.store.writer import Writer
        db.parent.mkdir(parents=True, exist_ok=True)
        with Writer(db) as w:
            w.write_many(records)

    def test_multi_db_union(self, tmp_path):
        """Records from both DBs appear in the output."""
        db_a = tmp_path / "a.db"
        db_b = tmp_path / "b.db"
        self._write(db_a, [_r(content="FAIL a.py::test_a\nValueError here")])
        self._write(db_b, [_r(content="FAIL b.py::test_b\nValueError here")])
        runner = CliRunner()
        result = runner.invoke(main, [
            "query", "ValueError",
            "--db", str(db_a), "--db", str(db_b),
        ])
        assert result.exit_code == 0
        assert "a.py" in result.output
        assert "b.py" in result.output

    def test_domain_filter(self, tmp_path):
        """--domain restricts output to records matching that prefix."""
        db = tmp_path / "store.db"
        self._write(db, [
            _r(content="python hit", domain="python/stdlib"),
            _r(content="rust hit", domain="rust/tokio"),
        ])
        runner = CliRunner()
        result = runner.invoke(main, [
            "query", "--db", str(db), "--domain", "python/",
        ])
        assert result.exit_code == 0
        assert "python hit" in result.output
        assert "rust hit" not in result.output

    def test_min_confidence_filter(self, tmp_path):
        """--min-confidence excludes low-confidence records."""
        db = tmp_path / "store.db"
        self._write(db, [
            _r(content="high conf record", confidence=0.9),
            _r(content="low conf record", confidence=0.01),
        ])
        runner = CliRunner()
        result = runner.invoke(main, [
            "query", "--db", str(db), "--min-confidence", "0.5",
        ])
        assert result.exit_code == 0
        assert "high conf record" in result.output
        assert "low conf record" not in result.output

    def test_json_output(self, tmp_path):
        """--json produces a valid JSON array with expected fields."""
        import json
        db = tmp_path / "store.db"
        self._write(db, [_r(content="FAIL x.py::test\nTypeError: bad")])
        runner = CliRunner()
        result = runner.invoke(main, ["query", "--db", str(db), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) >= 1
        assert "id" in data[0]
        assert "source" in data[0]
        assert "domain" in data[0]
        assert "content" in data[0]
        assert "confidence" in data[0]

    def test_missing_db_skipped(self, tmp_path):
        """A missing DB path is silently skipped; existing DBs are still queried."""
        db = tmp_path / "real.db"
        ghost = tmp_path / "ghost.db"
        self._write(db, [_r(content="FAIL r.py::test\nOSError: real error")])
        runner = CliRunner()
        result = runner.invoke(main, [
            "query", "--db", str(db), "--db", str(ghost),
        ])
        assert result.exit_code == 0
        assert "r.py" in result.output

    def test_query_arg_optional_no_crash(self, tmp_path):
        """Omitting QUERY with --db and no filter returns records sorted by confidence."""
        db = tmp_path / "store.db"
        self._write(db, [_r(content="some record content")])
        runner = CliRunner()
        result = runner.invoke(main, ["query", "--db", str(db)])
        assert result.exit_code == 0
        assert result.output


# ---------------------------------------------------------------------------
# cairn distill — pattern_cluster writeback
# ---------------------------------------------------------------------------


class TestDistillClusterWriteback:
    def test_distill_tags_source_records(self, tmp_path):
        """After distill, source records should have pattern_cluster set."""
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(content="FAIL tests/a.py::test_a\nValueError: x", exception_type="ValueError"),
            _r(content="FAIL tests/b.py::test_b\nValueError: y", exception_type="ValueError"),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["distill", "--db", str(db)])
        assert result.exit_code == 0

        from cairn.store.writer import get_all
        source_records = [r for r in get_all(db) if r.source == "pytest"]
        tagged = [r for r in source_records if r.pattern_cluster is not None]
        assert tagged, "distill did not write pattern_cluster back to source records"


# ---------------------------------------------------------------------------
# cairn status — cluster breakdown
# ---------------------------------------------------------------------------


class TestStatusClusterBreakdown:
    def test_status_shows_distilled_clusters(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL tests/a.py\nValueError", exception_type="ValueError")])
        runner = CliRunner()
        runner.invoke(main, ["distill", "--db", str(db)])
        result = runner.invoke(main, ["status", "--db", str(db)])
        assert result.exit_code == 0
        assert "Distilled clusters" in result.output


# ---------------------------------------------------------------------------
# cairn config show
# ---------------------------------------------------------------------------


class TestConfigShow:
    def test_shows_default_config(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["config", "show"])
        assert result.exit_code == 0
        assert "db" in result.output
        assert ".cairn" in result.output
        assert "decay" in result.output

    def test_shows_config_source(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(main, ["config", "show"])
        assert result.exit_code == 0
        assert "Config source" in result.output


# ---------------------------------------------------------------------------
# cairn stats
# ---------------------------------------------------------------------------


class TestStats:
    def test_no_store(self, tmp_path):
        runner = CliRunner()
        result = runner.invoke(main, ["stats", "--db", str(tmp_path / "missing.db")])
        assert result.exit_code == 0
        assert "No store found" in result.output

    def test_shows_counts(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(content="FAIL tests/a.py::test_a", source="pytest"),
            _r(content="FAIL tests/b.py::test_b", source="pytest"),
            _r(content="magic_number: 42", source="ast"),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["stats", "--db", str(db)])
        assert result.exit_code == 0
        assert "3 records total" in result.output
        assert "pytest" in result.output
        assert "ast" in result.output

    def test_shows_confidence_distribution(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL tests/a.py::test_a", confidence=0.9)])
        runner = CliRunner()
        result = runner.invoke(main, ["stats", "--db", str(db)])
        assert result.exit_code == 0
        assert "high" in result.output
        assert "Confidence distribution" in result.output

    def test_shows_last_write(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [_r(content="FAIL tests/a.py::test_a")])
        runner = CliRunner()
        result = runner.invoke(main, ["stats", "--db", str(db)])
        assert result.exit_code == 0
        assert "Last write" in result.output


# ---------------------------------------------------------------------------
# cairn distill --dry-run
# ---------------------------------------------------------------------------


class TestDistillDryRun:
    def test_dry_run_prints_clusters_without_writing(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        _seed(db, [
            _r(content="FAIL tests/a.py::test_a\nValueError: x", exception_type="ValueError"),
            _r(content="FAIL tests/b.py::test_b\nValueError: y", exception_type="ValueError"),
        ])
        runner = CliRunner()
        result = runner.invoke(main, ["distill", "--db", str(db), "--dry-run"])
        assert result.exit_code == 0
        assert "dry-run" in result.output.lower() or "Dry run" in result.output
        assert "Nothing changed" in result.output or "would be written" in result.output

        # No distill records should be in the store
        from cairn.store.writer import get_all
        distill_recs = [r for r in get_all(db) if r.source == "distill"]
        assert distill_recs == [], "dry-run should not persist any distill records"
