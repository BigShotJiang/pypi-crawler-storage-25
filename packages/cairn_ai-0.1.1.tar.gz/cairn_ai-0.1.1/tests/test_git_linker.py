"""Tests for the git linker."""

from __future__ import annotations

import subprocess
from pathlib import Path

from cairn.capture.git_linker import (
    _index_failures,
    link_commits,
)
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _init_repo(path: Path) -> None:
    """Create a minimal git repo with one commit."""
    subprocess.run(["git", "init"], cwd=path, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=path, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=path, capture_output=True)
    (path / "a.py").write_text("x = 1\n")
    subprocess.run(["git", "add", "."], cwd=path, capture_output=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=path, capture_output=True)


# ---------------------------------------------------------------------------
# _index_failures
# ---------------------------------------------------------------------------


class TestIndexFailures:
    def test_missing_db_returns_empty(self, tmp_path):
        result = _index_failures(tmp_path / "nonexistent.db")
        assert result == {}

    def test_indexes_failure_records(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        from datetime import datetime, timezone
        r = TruthRecord(
            source="pytest",
            domain="proj",
            content="FAIL tests/test_x.py::test_y\nexception: ValueError",
            confidence=1.0,
            occurred_at=datetime.now(tz=timezone.utc),
            source_file="/repo/src/foo.py",
            exception_type="ValueError",
        )
        with Writer(db) as w:
            w.write(r)
        index = _index_failures(db)
        assert "/repo/src/foo.py" in index
        assert index["/repo/src/foo.py"] == 1

    def test_pass_records_not_indexed(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        from datetime import datetime, timezone
        r = TruthRecord(
            source="pytest",
            domain="proj",
            content="PASS tests/test_x.py::test_y",
            confidence=1.0,
            occurred_at=datetime.now(tz=timezone.utc),
            source_file="/repo/src/foo.py",
        )
        with Writer(db) as w:
            w.write(r)
        index = _index_failures(db)
        assert index == {}


# ---------------------------------------------------------------------------
# link_commits — with a real git repo
# ---------------------------------------------------------------------------


class TestLinkCommits:
    def test_returns_empty_for_non_git_dir(self, tmp_path):
        records = link_commits(tmp_path, since="HEAD~1")
        assert records == []

    def test_returns_records_for_real_repo(self, tmp_path):
        _init_repo(tmp_path)
        records = link_commits(tmp_path, since="HEAD~1")
        # Either no commits in range (only one commit) or one record
        assert isinstance(records, list)
        assert all(r.source == "git" for r in records)

    def test_records_have_git_source(self, tmp_path):
        _init_repo(tmp_path)
        # Add a second commit so we have a range
        (tmp_path / "b.py").write_text("y = 2\n")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "add b"], cwd=tmp_path, capture_output=True)

        records = link_commits(tmp_path, since="HEAD~1")
        assert len(records) >= 1
        assert records[0].source == "git"
        assert "GIT" in records[0].content

    def test_correlated_failure_raises_confidence(self, tmp_path):
        _init_repo(tmp_path)

        # Seed the store with a failure on a.py
        db = tmp_path / ".cairn" / "store.db"
        from datetime import datetime, timezone
        r = TruthRecord(
            source="pytest",
            domain="repo",
            content="FAIL tests/test_a.py::test_x\nexception: TypeError",
            confidence=1.0,
            occurred_at=datetime.now(tz=timezone.utc),
            source_file=str(tmp_path / "a.py"),
            exception_type="TypeError",
        )
        with Writer(db) as w:
            w.write(r)

        # Make a second commit that touches a.py
        (tmp_path / "a.py").write_text("x = 2\n")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "touch a"], cwd=tmp_path, capture_output=True)

        records = link_commits(tmp_path, since="HEAD~1", db_path=db)
        assert len(records) == 1
        r = records[0]
        assert r.confidence > 0.3  # correlated, so confidence > uncorrelated baseline
        assert "correlated" in r.content
