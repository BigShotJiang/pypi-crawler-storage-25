"""Pytest configuration for the Cairn test suite."""
