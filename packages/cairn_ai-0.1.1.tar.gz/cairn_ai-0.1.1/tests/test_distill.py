"""Tests for the distillation subsystem: cluster, decay, namer, rules."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from cairn.distill.cluster import cluster
from cairn.distill.decay import apply_decay, decayed_confidence
from cairn.distill.namer import name_cluster
from cairn.distill.rules import encode_as_rule
from cairn.store.schema import TruthRecord

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOW = datetime(2026, 3, 14, 12, 0, 0, tzinfo=timezone.utc)


def _r(
    source: str = "pytest",
    content: str = "FAIL tests/test_foo.py::test_bar\nexception: ValueError",
    confidence: float = 1.0,
    occurred_at: datetime | None = None,
    exception_type: str | None = "ValueError",
    source_file: str | None = "/repo/src/config.py",
    pattern_cluster: str | None = None,
    domain: str = "myproject",
) -> TruthRecord:
    return TruthRecord(
        source=source,
        domain=domain,
        content=content,
        confidence=confidence,
        occurred_at=occurred_at or _NOW,
        exception_type=exception_type,
        source_file=source_file,
        pattern_cluster=pattern_cluster,
    )


# ---------------------------------------------------------------------------
# cluster()
# ---------------------------------------------------------------------------


class TestCluster:
    def test_groups_by_exception_type(self):
        records = [
            _r(content="FAIL a\nexception: ValueError", exception_type="ValueError"),
            _r(content="FAIL b\nexception: ValueError", exception_type="ValueError"),
            _r(content="FAIL c\nexception: KeyError", exception_type="KeyError"),
        ]
        result = cluster(records)
        # Two clusters: ValueError::..., KeyError::...
        keys = list(result.keys())
        assert any("ValueError" in k for k in keys)
        assert any("KeyError" in k for k in keys)

    def test_largest_cluster_first(self):
        records = [
            _r(content="FAIL a", exception_type="KeyError"),
            _r(content="FAIL b", exception_type="ValueError"),
            _r(content="FAIL c", exception_type="ValueError"),
            _r(content="FAIL d", exception_type="ValueError"),
        ]
        result = cluster(records)
        first_key = list(result.keys())[0]
        assert "ValueError" in first_key

    def test_ast_records_cluster_by_check_type(self):
        records = [
            _r(source="ast", content="broad_except: bare 'except:' at line 10",
               exception_type=None, source_file="/f.py"),
            _r(source="ast", content="broad_except: except Exception at line 20",
               exception_type=None, source_file="/f.py"),
            _r(source="ast", content="mutable_default: param 'x' at line 5",
               exception_type=None, source_file="/f.py"),
        ]
        result = cluster(records)
        assert "broad_except" in result
        assert "mutable_default" in result
        assert len(result["broad_except"]) == 2
        assert len(result["mutable_default"]) == 1

    def test_git_records_grouped_by_file(self):
        records = [
            _r(source="git", content="GIT abc123 fix: update config\nchanged 2 .py files",
               exception_type=None, source_file="/repo/config.py"),
            _r(source="git", content="GIT def456 feat: add parser\nchanged 1 .py file",
               exception_type=None, source_file="/repo/parser.py"),
        ]
        result = cluster(records)
        assert "git::config" in result
        assert "git::parser" in result
        assert len(result["git::config"]) == 1
        assert len(result["git::parser"]) == 1

    def test_git_records_without_file_fallback(self):
        records = [
            _r(source="git", content="GIT abc123",
               exception_type=None, source_file=None),
        ]
        result = cluster(records)
        assert "git::correlation" in result

    def test_empty_input(self):
        assert cluster([]) == {}


# ---------------------------------------------------------------------------
# decay
# ---------------------------------------------------------------------------


class TestDecay:
    def test_fresh_record_full_confidence(self):
        r = _r(confidence=1.0, occurred_at=_NOW)
        assert decayed_confidence(r, as_of=_NOW) == pytest.approx(1.0)

    def test_confidence_decays_over_time(self):
        r = _r(source="pytest", confidence=1.0, occurred_at=_NOW)
        # 21 days later = exactly one half-life for pytest
        future = _NOW + timedelta(days=21)
        conf = decayed_confidence(r, as_of=future)
        assert conf == pytest.approx(0.5, abs=1e-6)

    def test_ast_decays_faster_than_distill(self):
        ast_r = _r(source="ast", confidence=1.0, occurred_at=_NOW)
        distill_r = _r(source="distill", confidence=1.0, occurred_at=_NOW)
        future = _NOW + timedelta(days=30)
        assert decayed_confidence(ast_r, future) < decayed_confidence(distill_r, future)

    def test_apply_decay_filters_below_min(self):
        old = _r(confidence=0.1, occurred_at=_NOW - timedelta(days=200))
        fresh = _r(confidence=1.0, occurred_at=_NOW, content="FAIL b")
        result = apply_decay([old, fresh], as_of=_NOW, min_confidence=0.05)
        # old record decays to near-zero; fresh stays high
        assert fresh in result

    def test_apply_decay_sorted_descending(self):
        high = _r(confidence=1.0, occurred_at=_NOW, content="FAIL a")
        low = _r(confidence=0.5, occurred_at=_NOW - timedelta(days=10), content="FAIL b")
        result = apply_decay([low, high], as_of=_NOW)
        assert result[0].content == "FAIL a"

    def test_decay_with_preloaded_half_lives(self):
        """_half_lives parameter avoids per-record config reads."""
        r = _r(occurred_at=_NOW - timedelta(days=14), source="ast")
        half_lives = {"ast": 14.0}
        conf = decayed_confidence(r, as_of=_NOW, _half_lives=half_lives)
        assert conf == pytest.approx(0.5, abs=0.01)

    def test_naive_datetime_handled(self):
        """Records with naive datetimes should not raise."""
        r = _r(occurred_at=datetime(2026, 1, 1))  # no tzinfo
        conf = decayed_confidence(r, as_of=_NOW)
        assert 0.0 <= conf <= 1.0


# ---------------------------------------------------------------------------
# namer
# ---------------------------------------------------------------------------


class TestNamer:
    def test_runtime_cluster_name(self):
        records = [
            _r(exception_type="ValueError", source_file="/repo/config.py"),
            _r(exception_type="ValueError", source_file="/repo/config.py"),
        ]
        name = name_cluster(records)
        assert "ValueError" in name
        assert "config.py" in name

    def test_ast_cluster_name(self):
        records = [
            _r(source="ast", content="broad_except: bare except at line 5",
               exception_type=None),
        ] * 3
        name = name_cluster(records)
        assert "broad_except" in name
        assert "3" in name

    def test_git_cluster_name_with_file(self):
        records = [
            _r(source="git", content="GIT abc fix", exception_type=None,
               source_file="/repo/config.py"),
        ] * 2
        name = name_cluster(records)
        assert "config.py" in name
        assert "git" in name.lower()

    def test_git_cluster_name_without_file(self):
        records = [
            _r(source="git", content="GIT abc fix", exception_type=None, source_file=None),
        ] * 2
        name = name_cluster(records)
        assert "commit" in name

    def test_ast_cluster_name_disambiguated_by_file(self):
        records = [
            _r(source="ast", content="broad_except: bare except at line 5",
               exception_type=None, source_file="/repo/api.py"),
        ] * 3
        name = name_cluster(records)
        assert "broad_except" in name
        assert "api.py" in name

    def test_empty_cluster(self):
        assert name_cluster([]) == "empty cluster"


# ---------------------------------------------------------------------------
# rules
# ---------------------------------------------------------------------------


class TestRules:
    def test_broad_except_rule(self):
        records = [
            _r(source="ast", content="broad_except: bare except", exception_type=None),
        ]
        result = encode_as_rule("broad_except", records)
        assert result is not None
        assert "BLE001" in result

    def test_mutable_default_rule(self):
        records = [
            _r(source="ast", content="mutable_default: param x", exception_type=None),
        ]
        result = encode_as_rule("mutable_default", records)
        assert result is not None
        assert "B006" in result

    def test_runtime_record_returns_none(self):
        records = [_r(source="pytest")]
        assert encode_as_rule("ValueError", records) is None

    def test_empty_records_returns_none(self):
        assert encode_as_rule("broad_except", []) is None


# ---------------------------------------------------------------------------
# Integration: cluster → name → rule pipeline
# ---------------------------------------------------------------------------


class TestDistillPipeline:
    def test_full_pipeline_ast(self):
        records = [
            _r(source="ast", content="broad_except: bare except at line 5",
               exception_type=None, source_file="/repo/api.py"),
            _r(source="ast", content="broad_except: except Exception at line 12",
               exception_type=None, source_file="/repo/api.py"),
            _r(source="ast", content="mutable_default: param items at line 3",
               exception_type=None, source_file="/repo/utils.py"),
        ]
        clusters = cluster(records)
        for key, members in clusters.items():
            name = name_cluster(members)
            assert name  # non-empty name
            # rule may or may not be present depending on check type
            encode_as_rule(name, members)  # just ensure it doesn't raise
