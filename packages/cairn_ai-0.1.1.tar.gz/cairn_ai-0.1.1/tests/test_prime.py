"""Tests for cairn.capture.prime and the ``cairn prime`` CLI command."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

import pytest

from cairn.capture.prime import (
    DEFAULT_FIX_PATTERN,
    _build_content,
    _commit_confidence,
    _extract_exceptions,
    _has_test_file,
    _is_doc_only,
    prime,
)


# ---------------------------------------------------------------------------
# Unit tests — filter helpers
# ---------------------------------------------------------------------------


class TestIsDocOnly:
    def test_all_rst_is_doc(self):
        assert _is_doc_only(["docs/api.rst", "CHANGES.rst"])

    def test_py_file_is_not_doc(self):
        assert not _is_doc_only(["cairn/store/writer.py"])

    def test_mixed_files_not_doc_only(self):
        assert not _is_doc_only(["docs/api.rst", "cairn/store/writer.py"])

    def test_empty_list_is_doc(self):
        assert _is_doc_only([])

    def test_md_is_doc(self):
        assert _is_doc_only(["README.md", "CHANGELOG.md"])

    def test_cfg_is_doc(self):
        assert _is_doc_only(["setup.cfg"])

    def test_mixed_md_and_py(self):
        assert not _is_doc_only(["README.md", "src/app.py"])


class TestHasTestFile:
    def test_test_underscore_prefix(self):
        assert _has_test_file(["tests/test_writer.py"])

    def test_underscore_test_suffix(self):
        assert _has_test_file(["lib/config_test.py"])

    def test_tests_directory(self):
        assert _has_test_file(["Lib/test/test_asyncio.py"])

    def test_no_test_files(self):
        assert not _has_test_file(["cairn/store/writer.py", "cairn/cli.py"])

    def test_empty_list(self):
        assert not _has_test_file([])

    def test_test_in_dirname_only(self):
        # File named "tester.py" in a non-test dir should not match
        assert not _has_test_file(["src/tester.py"])


class TestExtractExceptions:
    def test_finds_valueerror(self):
        assert "ValueError" in _extract_exceptions("Fix ValueError in config parser")

    def test_finds_multiple(self):
        result = _extract_exceptions("Fix TypeError and RuntimeError in parser")
        assert "TypeError" in result
        assert "RuntimeError" in result

    def test_deduplicates(self):
        result = _extract_exceptions("Fix ValueError: ValueError raised again")
        assert result.count("ValueError") == 1

    def test_no_exceptions(self):
        assert _extract_exceptions("Update README") == []

    def test_preserves_order(self):
        result = _extract_exceptions("Fix TypeError then RuntimeError")
        assert result.index("TypeError") < result.index("RuntimeError")

    def test_finds_oserror(self):
        assert "OSError" in _extract_exceptions("Fix OSError on Windows")

    def test_does_not_find_lowercase(self):
        assert _extract_exceptions("fix valueerror in parser") == []


class TestBuildContent:
    def test_sha_truncated_to_12(self):
        content = _build_content("abcdef123456789", "Fix crash", ["src/a.py"], [])
        assert "abcdef123456" in content

    def test_subject_included(self):
        content = _build_content("abc123def456", "Fix ValueError in parser", [], [])
        assert "Fix ValueError in parser" in content

    def test_files_included(self):
        content = _build_content("abc123def456", "Fix crash", ["src/parser.py"], [])
        assert "parser.py" in content

    def test_exceptions_included(self):
        content = _build_content("abc123def456", "Fix crash", [], ["ValueError"])
        assert "ValueError" in content

    def test_no_files_section_when_empty(self):
        content = _build_content("abc123def456", "Fix crash", [], [])
        assert "files:" not in content

    def test_no_exceptions_section_when_empty(self):
        content = _build_content("abc123def456", "Fix crash", ["a.py"], [])
        assert "exceptions:" not in content

    def test_many_files_truncated(self):
        files = [f"src/module{i}.py" for i in range(10)]
        content = _build_content("abc123def456", "Fix bug", files, [])
        assert "+5 more" in content

    def test_exactly_five_files_no_truncation(self):
        files = [f"src/module{i}.py" for i in range(5)]
        content = _build_content("abc123def456", "Fix bug", files, [])
        assert "more" not in content


class TestCommitConfidence:
    def test_cve_is_highest(self):
        conf = _commit_confidence("CVE-2024-1234 fix buffer overflow", [], DEFAULT_FIX_PATTERN)
        assert conf >= 0.85

    def test_regression_is_high(self):
        conf = _commit_confidence("Fix regression in async event loop", [], DEFAULT_FIX_PATTERN)
        assert conf >= 0.75

    def test_security_is_high(self):
        conf = _commit_confidence("Fix security issue in auth module", [], DEFAULT_FIX_PATTERN)
        assert conf >= 0.75

    def test_crash_is_high(self):
        conf = _commit_confidence("Fix crash on empty input", [], DEFAULT_FIX_PATTERN)
        assert conf >= 0.75

    def test_generic_fix_is_medium(self):
        conf = _commit_confidence("Fix bug in config parser", [], DEFAULT_FIX_PATTERN)
        assert 0.60 <= conf < 0.80

    def test_test_file_bumps_confidence(self):
        base = _commit_confidence("Add test for edge case", [], DEFAULT_FIX_PATTERN)
        bumped = _commit_confidence("Add test for edge case", ["tests/test_parser.py"], DEFAULT_FIX_PATTERN)
        assert bumped > base

    def test_confidence_capped_at_1(self):
        conf = _commit_confidence(
            "CVE-2024-9999 critical security regression crash",
            ["tests/test_security.py"],
            DEFAULT_FIX_PATTERN,
        )
        assert conf <= 1.0


# ---------------------------------------------------------------------------
# Integration fixture — minimal git repo
# ---------------------------------------------------------------------------


@pytest.fixture
def temp_git_repo(tmp_path: Path) -> Path:
    """Create a minimal git repo with a mix of signal-rich and noise commits."""
    repo = tmp_path / "testrepo"
    repo.mkdir()

    def git(*args: str) -> None:
        subprocess.run(["git"] + list(args), cwd=repo, capture_output=True, check=False)

    git("init", "-b", "main")
    git("config", "user.email", "test@test.com")
    git("config", "user.name", "Test User")

    def commit(message: str, filename: str = "code.py", content: str = "x = 1") -> None:
        f = repo / filename
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(content)
        git("add", ".")
        git("commit", "-m", message)

    # Noise: will be filtered out
    commit("Initial commit", "code.py", "x = 1")
    commit("Update README", "README.md", "# Project")
    commit("Update CHANGELOG", "CHANGELOG.md", "- changed things")
    commit("Tweak docs", "docs.rst", "documentation")

    # Signal: should be included
    commit("Fix ValueError in config parser", "config.py", "x = 2")
    commit("Add test for edge case", "tests/test_config.py", "def test_x(): pass")
    commit("CVE-2024-1234: Fix security issue in auth", "auth.py", "z = 0")
    commit("Fix regression in async handling", "async_mod.py", "a = 5")
    commit("bpo-12345: Fix crash on empty input", "parser.py", "b = 6")

    return repo


# ---------------------------------------------------------------------------
# Integration tests — prime() function
# ---------------------------------------------------------------------------


class TestPrimeFunction:
    def test_writes_high_signal_records(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        examined, written = prime(repo_root=temp_git_repo, output_db=output_db)
        assert written >= 4  # fix, test, cve, regression, crash
        assert examined >= written
        assert output_db.exists()

    def test_skips_doc_only_commits(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        _, written = prime(repo_root=temp_git_repo, output_db=output_db)
        # README, CHANGELOG, docs.rst — 3 doc-only commits — should not appear in written count
        assert written < 9  # fewer than total non-merge commits

    def test_limit_respected(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        _, written = prime(repo_root=temp_git_repo, output_db=output_db, limit=2)
        assert written <= 2

    def test_resumable_does_not_duplicate(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        # First run: only 2 records
        _, first = prime(repo_root=temp_git_repo, output_db=output_db, limit=2)
        # Second run: picks up the rest
        _, second = prime(repo_root=temp_git_repo, output_db=output_db)

        from cairn.store.writer import get_all
        records = get_all(output_db)
        prime_records = [r for r in records if r.source == "git-prime"]
        # Total rows should equal first + second with no duplicates
        assert len(prime_records) == first + second

    def test_domain_applied(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        prime(repo_root=temp_git_repo, output_db=output_db, domain="myproject")

        from cairn.store.writer import get_all
        records = get_all(output_db)
        prime_records = [r for r in records if r.source == "git-prime"]
        assert prime_records
        assert all(r.domain == "myproject" for r in prime_records)

    def test_default_domain_is_repo_name(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        prime(repo_root=temp_git_repo, output_db=output_db)

        from cairn.store.writer import get_all
        records = get_all(output_db)
        prime_records = [r for r in records if r.source == "git-prime"]
        assert all(r.domain == "testrepo" for r in prime_records)

    def test_source_is_git_prime(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        prime(repo_root=temp_git_repo, output_db=output_db)

        from cairn.store.writer import get_all
        records = get_all(output_db)
        prime_records = [r for r in records if r.source == "git-prime"]
        assert len(prime_records) >= 1

    def test_cve_record_has_high_confidence(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        prime(repo_root=temp_git_repo, output_db=output_db)

        from cairn.store.writer import get_all
        records = get_all(output_db)
        cve_recs = [r for r in records if "CVE" in r.content and r.source == "git-prime"]
        assert cve_recs
        assert all(r.confidence >= 0.85 for r in cve_recs)

    def test_exception_type_extracted(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        prime(repo_root=temp_git_repo, output_db=output_db)

        from cairn.store.writer import get_all
        records = get_all(output_db)
        # The "Fix ValueError in config parser" commit should have exception_type set
        valueerror_recs = [
            r for r in records
            if r.source == "git-prime" and r.exception_type == "ValueError"
        ]
        assert valueerror_recs

    def test_since_filter(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        # Use a future date — nothing should be included
        _, written = prime(repo_root=temp_git_repo, output_db=output_db, since="2099-01-01")
        assert written == 0

    def test_progress_callback_called(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "baseline.db"
        calls: list[tuple[int, int]] = []
        prime(
            repo_root=temp_git_repo,
            output_db=output_db,
            batch_size=2,
            progress_cb=lambda e, w: calls.append((e, w)),
        )
        assert len(calls) >= 1

    def test_output_db_created_if_absent(self, temp_git_repo: Path, tmp_path: Path) -> None:
        output_db = tmp_path / "deep" / "nested" / "baseline.db"
        prime(repo_root=temp_git_repo, output_db=output_db)
        assert output_db.exists()

    def test_invalid_repo_returns_zero(self, tmp_path: Path) -> None:
        not_a_repo = tmp_path / "notarepo"
        not_a_repo.mkdir()
        output_db = tmp_path / "baseline.db"
        examined, written = prime(repo_root=not_a_repo, output_db=output_db)
        assert examined == 0
        assert written == 0


# ---------------------------------------------------------------------------
# CLI integration tests
# ---------------------------------------------------------------------------


class TestPrimeCli:
    def test_help_text(self) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        runner = CliRunner()
        result = runner.invoke(main, ["prime", "--help"])
        assert result.exit_code == 0
        assert "OUTPUT_DB" in result.output

    def test_runs_on_temp_repo(self, temp_git_repo: Path, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        output_path = tmp_path / "cli-baseline.db"
        runner = CliRunner()
        result = runner.invoke(main, [
            "prime", str(temp_git_repo),
            "--output", str(output_path),
            "--domain", "testrepo",
            "--limit", "5",
        ])
        assert result.exit_code == 0, f"CLI failed:\n{result.output}"
        assert output_path.exists()
        assert "written" in result.output.lower()

    def test_invalid_filter_exits_nonzero(self, temp_git_repo: Path, tmp_path: Path) -> None:
        from click.testing import CliRunner
        from cairn.cli import main

        output_path = tmp_path / "baseline.db"
        runner = CliRunner()
        result = runner.invoke(main, [
            "prime", str(temp_git_repo),
            "--output", str(output_path),
            "--filter", "[invalid regex(",
        ])
        assert result.exit_code != 0

    def test_sync_of_prime_output(self, temp_git_repo: Path, tmp_path: Path) -> None:
        """End-to-end: prime → sync → records appear in project store."""
        from click.testing import CliRunner
        from cairn.cli import main

        runner = CliRunner()
        baseline_db = tmp_path / "baseline.db"
        project_db = tmp_path / "project.db"

        # Build baseline
        result = runner.invoke(main, [
            "prime", str(temp_git_repo),
            "--output", str(baseline_db),
            "--domain", "testrepo",
        ])
        assert result.exit_code == 0, result.output

        # Sync into project store
        result = runner.invoke(main, [
            "sync", str(baseline_db),
            "--db", str(project_db),
        ])
        assert result.exit_code == 0, result.output

        from cairn.store.writer import get_all
        records = get_all(project_db)
        prime_records = [r for r in records if r.source == "git-prime"]
        assert len(prime_records) >= 4
