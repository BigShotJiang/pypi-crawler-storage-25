"""FiberHMM core per-read HMM inference engine."""

import numpy as np
import pysam
from typing import Optional, Tuple, Set

from fiberhmm.core.hmm import FiberHMM
from fiberhmm.core.bam_reader import (
    encode_from_query_sequence,
    detect_daf_strand,
    has_iupac_encoding,
    extract_daf_iupac_positions,
    parse_mm_tag_query_positions,
)


def predict_footprints(model: FiberHMM, encoded_read: np.ndarray,
                       with_scores: bool = False) -> Tuple[np.ndarray, np.ndarray, int, Optional[np.ndarray]]:
    """
    Run HMM Viterbi prediction to call footprints.

    Args:
        model: Trained FiberHMM model
        encoded_read: Encoded observation sequence
        with_scores: If True, compute posterior probability scores per footprint

    Returns:
        (starts, sizes, count, scores) - footprint positions in read coordinates
        scores is None if with_scores=False, otherwise array of mean posteriors per footprint
    """
    if len(encoded_read) == 0:
        return np.array([]), np.array([]), 0, None

    # Predict states (0 = footprint, 1 = accessible)
    if with_scores:
        states, confidence = model.predict_with_confidence(encoded_read)
    else:
        states = model.predict(encoded_read)
        confidence = None

    # Count footprint positions (state 0)
    if np.sum(states == 0) == 0:
        return np.array([]), np.array([]), 0, None

    # Find transitions (pad with 1s = accessible at edges)
    # State 0 = footprint, State 1 = accessible
    states_padded = np.concatenate([[1], states, [1]])
    diff = np.diff(states_padded)

    # Footprint starts where we transition from 1 (accessible) to 0 (footprint): diff == -1
    # Footprint ends where we transition from 0 (footprint) to 1 (accessible): diff == 1
    starts = np.where(diff == -1)[0]
    ends = np.where(diff == 1)[0]

    if len(starts) == 0:
        return np.array([]), np.array([]), 0, None

    sizes = ends - starts

    # Compute per-footprint scores
    scores = None
    if with_scores and confidence is not None:
        scores = np.zeros(len(starts), dtype=np.float32)
        for i, (s, e) in enumerate(zip(starts, ends)):
            # Mean posterior probability for footprint state within this footprint
            scores[i] = np.mean(confidence[s:e])

    return starts, sizes, len(starts), scores


def _extract_footprints_from_states(states: np.ndarray, confidence: Optional[np.ndarray],
                                     msp_min_size: int, with_scores: bool,
                                     nuc_min_size: int = 85) -> dict:
    """
    Extract footprints and MSPs from HMM states (without running HMM again).

    States: 0 = footprint, 1 = accessible

    MSPs are bounded by nucleosome-sized footprints (>= nuc_min_size) only.
    Small footprints do not break MSPs, matching the fibertools convention.

    Used for timing breakdown to separate HMM time from post-processing.
    """
    result = {
        'footprint_starts': np.array([], dtype=np.int32),
        'footprint_sizes': np.array([], dtype=np.int32),
        'footprint_scores': None,
        'msp_starts': np.array([], dtype=np.int32),
        'msp_sizes': np.array([], dtype=np.int32),
        'msp_scores': None,
    }

    if len(states) == 0:
        return result

    # Find footprints (state 0 regions)
    # Pad with 1 (accessible) at edges
    states_padded = np.concatenate([[1], states, [1]])
    diff = np.diff(states_padded)

    # Footprint starts: transition from 1 to 0 (diff == -1)
    # Footprint ends: transition from 0 to 1 (diff == 1)
    fp_starts = np.where(diff == -1)[0]
    fp_ends = np.where(diff == 1)[0]

    if len(fp_starts) > 0:
        result['footprint_starts'] = fp_starts.astype(np.int32)
        result['footprint_sizes'] = (fp_ends - fp_starts).astype(np.int32)

        if with_scores and confidence is not None:
            fp_scores = np.zeros(len(fp_starts), dtype=np.float32)
            for i, (s, e) in enumerate(zip(fp_starts, fp_ends)):
                fp_scores[i] = np.mean(confidence[s:e])
            result['footprint_scores'] = fp_scores

    # Find MSPs (accessible regions between nucleosome-sized footprints)
    # Only footprints >= nuc_min_size act as MSP boundaries
    if len(states) > 0:
        if len(fp_starts) > 0:
            fp_sizes_arr = fp_ends - fp_starts
            nuc_mask = fp_sizes_arr >= nuc_min_size
            nuc_starts = fp_starts[nuc_mask]
            nuc_ends = fp_ends[nuc_mask]
        else:
            nuc_starts = np.array([], dtype=np.int64)
            nuc_ends = np.array([], dtype=np.int64)

        msp_start_list = []
        msp_size_list = []

        if len(nuc_starts) > 0:
            if nuc_starts[0] > 0:
                msp_start_list.append(0)
                msp_size_list.append(int(nuc_starts[0]))
            for i in range(len(nuc_starts) - 1):
                gap_start = int(nuc_ends[i])
                gap_size = int(nuc_starts[i + 1]) - gap_start
                if gap_size > 0:
                    msp_start_list.append(gap_start)
                    msp_size_list.append(gap_size)
            if nuc_ends[-1] < len(states):
                msp_start_list.append(int(nuc_ends[-1]))
                msp_size_list.append(len(states) - int(nuc_ends[-1]))
        else:
            # No nucleosome-sized footprints: entire read is one MSP
            msp_start_list.append(0)
            msp_size_list.append(len(states))

        if msp_start_list:
            msp_starts_arr = np.array(msp_start_list, dtype=np.int32)
            msp_sizes_arr = np.array(msp_size_list, dtype=np.int32)

            size_mask = msp_sizes_arr >= msp_min_size
            msp_starts_arr = msp_starts_arr[size_mask]
            msp_sizes_arr = msp_sizes_arr[size_mask]

            if len(msp_starts_arr) > 0:
                result['msp_starts'] = msp_starts_arr
                result['msp_sizes'] = msp_sizes_arr

                if with_scores and confidence is not None:
                    msp_scores = np.zeros(len(msp_starts_arr), dtype=np.float32)
                    for i, (s, sz) in enumerate(zip(msp_starts_arr, msp_sizes_arr)):
                        msp_scores[i] = np.mean(1.0 - confidence[s:s+sz])
                    result['msp_scores'] = msp_scores

    return result


def predict_footprints_and_msps(model: FiberHMM, encoded_read: np.ndarray,
                                 msp_min_size: int = 147,
                                 with_scores: bool = False,
                                 return_posteriors: bool = False,
                                 nuc_min_size: int = 85) -> dict:
    """
    Run HMM prediction to call both footprints (ns/nl) and MSPs (as/al).

    States: 0 = footprint, 1 = accessible

    MSPs (Methylase-Sensitive Patches) are accessible regions between
    nucleosome-sized footprints (>= nuc_min_size). Small footprints do not
    break MSPs, matching the fibertools convention.

    Args:
        model: Trained FiberHMM model
        encoded_read: Encoded observation sequence
        msp_min_size: Minimum size for an accessible region to be called as MSP
        with_scores: If True, compute confidence scores
        return_posteriors: If True, return full posterior array for CNN training
        nuc_min_size: Minimum footprint size (bp) to count as nucleosome-sized
            for MSP boundary detection (default: 85)

    Returns:
        dict with:
            'footprint_starts': query positions where footprints start
            'footprint_sizes': footprint lengths
            'footprint_scores': per-footprint confidence (if with_scores)
            'msp_starts': query positions where MSPs start
            'msp_sizes': MSP lengths
            'msp_scores': per-MSP confidence (if with_scores)
            'states': raw HMM state array
            'posteriors': P(footprint) per position (if return_posteriors)
    """
    result = {
        'footprint_starts': np.array([], dtype=np.int32),
        'footprint_sizes': np.array([], dtype=np.int32),
        'footprint_scores': None,
        'msp_starts': np.array([], dtype=np.int32),
        'msp_sizes': np.array([], dtype=np.int32),
        'msp_scores': None,
        'states': np.array([], dtype=np.int8),
        'posteriors': None,
    }

    if len(encoded_read) == 0:
        return result

    # Predict states (0 = footprint, 1 = accessible)
    # Use predict_with_posteriors if we need posteriors or scores (shares computation)
    if with_scores or return_posteriors:
        states, posteriors_full = model.predict_with_posteriors(encoded_read)
        confidence = posteriors_full[np.arange(len(states)), states]

        if return_posteriors:
            # P(footprint) = posteriors_full[:, 0]
            result['posteriors'] = posteriors_full[:, 0].astype(np.float16)
    else:
        states = model.predict(encoded_read)
        confidence = None

    result['states'] = states

    # Find footprints (state 0 regions)
    # Pad with 1 (accessible) at edges
    states_padded = np.concatenate([[1], states, [1]])
    diff = np.diff(states_padded)

    # Footprint starts: transition from 1 to 0 (diff == -1)
    # Footprint ends: transition from 0 to 1 (diff == 1)
    fp_starts = np.where(diff == -1)[0]
    fp_ends = np.where(diff == 1)[0]

    if len(fp_starts) > 0:
        result['footprint_starts'] = fp_starts.astype(np.int32)
        result['footprint_sizes'] = (fp_ends - fp_starts).astype(np.int32)

        if with_scores and confidence is not None:
            fp_scores = np.zeros(len(fp_starts), dtype=np.float32)
            for i, (s, e) in enumerate(zip(fp_starts, fp_ends)):
                fp_scores[i] = np.mean(confidence[s:e])
            result['footprint_scores'] = fp_scores

    # Find MSPs (accessible regions between nucleosome-sized footprints)
    # Following fibertools convention: only nucleosome-sized footprints
    # (>= nuc_min_size) act as MSP boundaries. Small footprints are
    # absorbed into the surrounding MSP.
    if len(states) > 0:
        if len(fp_starts) > 0:
            fp_sizes_arr = fp_ends - fp_starts
            nuc_mask = fp_sizes_arr >= nuc_min_size
            nuc_starts = fp_starts[nuc_mask]
            nuc_ends = fp_ends[nuc_mask]
        else:
            nuc_starts = np.array([], dtype=np.int64)
            nuc_ends = np.array([], dtype=np.int64)

        # MSP regions are the gaps between nucleosome-sized footprints
        # (and between read edges and the first/last nucleosome)
        msp_start_list = []
        msp_size_list = []

        if len(nuc_starts) > 0:
            # Gap before first nucleosome
            if nuc_starts[0] > 0:
                msp_start_list.append(0)
                msp_size_list.append(int(nuc_starts[0]))
            # Gaps between consecutive nucleosomes
            for i in range(len(nuc_starts) - 1):
                gap_start = int(nuc_ends[i])
                gap_size = int(nuc_starts[i + 1]) - gap_start
                if gap_size > 0:
                    msp_start_list.append(gap_start)
                    msp_size_list.append(gap_size)
            # Gap after last nucleosome
            if nuc_ends[-1] < len(states):
                msp_start_list.append(int(nuc_ends[-1]))
                msp_size_list.append(len(states) - int(nuc_ends[-1]))
        else:
            # No nucleosome-sized footprints: entire read is one MSP
            msp_start_list.append(0)
            msp_size_list.append(len(states))

        if msp_start_list:
            msp_starts_arr = np.array(msp_start_list, dtype=np.int32)
            msp_sizes_arr = np.array(msp_size_list, dtype=np.int32)

            # Filter by minimum size
            size_mask = msp_sizes_arr >= msp_min_size
            msp_starts_arr = msp_starts_arr[size_mask]
            msp_sizes_arr = msp_sizes_arr[size_mask]

            if len(msp_starts_arr) > 0:
                result['msp_starts'] = msp_starts_arr
                result['msp_sizes'] = msp_sizes_arr

                if with_scores and confidence is not None:
                    msp_scores = np.zeros(len(msp_starts_arr), dtype=np.float32)
                    for i, (s, sz) in enumerate(zip(msp_starts_arr, msp_sizes_arr)):
                        msp_scores[i] = np.mean(1.0 - confidence[s:s+sz])
                    result['msp_scores'] = msp_scores

    return result


def detect_mode_from_bam(bam_path: str, n_sample: int = 100) -> str:
    """
    Auto-detect the appropriate mode from MM tags in the BAM file.

    Samples the first n_sample reads with MM tags and checks:
    - DAF-seq: Has T-a (C→T deamination) or A+a (G→A deamination) tags
    - PacBio fiber-seq: Has A+a only (m6A methylation)
    - Nanopore fiber-seq: Has A+a only but typically lower modification rates

    Returns: 'daf', 'pacbio-fiber', 'nanopore-fiber', or 'unknown'
    """
    try:
        with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam:
            t_minus_a_count = 0  # T-a tags (DAF + strand)
            a_plus_a_count = 0   # A+a tags (DAF - strand or m6A)
            c_plus_m_count = 0   # C+m tags (5mC methylation)
            other_count = 0
            reads_with_mm = 0
            # Also track IUPAC indicators in the same pass
            iupac_count = 0
            st_count = 0
            n_scanned = 0

            for read in bam.fetch(until_eof=True):
                if reads_with_mm >= n_sample and n_scanned >= n_sample:
                    break

                if read.is_unmapped or read.query_sequence is None:
                    continue

                # Track IUPAC indicators (always, up to n_sample)
                if n_scanned < n_sample:
                    n_scanned += 1
                    if has_iupac_encoding(read.query_sequence):
                        iupac_count += 1
                    if read.has_tag('st'):
                        st_count += 1

                # Get MM tag
                if reads_with_mm < n_sample:
                    try:
                        mm_tag = read.get_tag('MM') if read.has_tag('MM') else \
                                 read.get_tag('Mm') if read.has_tag('Mm') else None
                    except KeyError:
                        mm_tag = None

                    if mm_tag:
                        reads_with_mm += 1

                        # Parse MM tag to identify modification types
                        for mod_spec in mm_tag.split(';'):
                            if not mod_spec:
                                continue
                            parts = mod_spec.split(',')
                            if len(parts) < 2:
                                continue
                            base_mod = parts[0].strip()

                            if base_mod.startswith('T-a') or base_mod.startswith('T+a'):
                                t_minus_a_count += 1
                            elif base_mod.startswith('A+a') or base_mod.startswith('A-a'):
                                a_plus_a_count += 1
                            elif base_mod.startswith('C+m') or base_mod.startswith('C-m'):
                                c_plus_m_count += 1
                            else:
                                other_count += 1

            # Determine mode based on tag patterns
            if reads_with_mm == 0:
                # No MM tags found — check for IUPAC R/Y encoding
                if iupac_count > 0 and st_count > 0:
                    return 'daf'
                return 'unknown'

            # DAF-seq uses T-a for + strand deamination (C→T)
            # and A+a for - strand deamination (G→A)
            if t_minus_a_count > 0:
                # T-a tags are DAF-specific (deaminated C shows as T)
                return 'daf'
            elif a_plus_a_count > 0 and c_plus_m_count == 0:
                # Only A+a without 5mC - could be m6A fiber-seq or DAF - strand only
                # Check if we also see patterns suggesting DAF
                # For now, assume pacbio-fiber unless we see T-a
                return 'pacbio-fiber'
            else:
                return 'unknown'

    except Exception as e:
        print(f"  Warning: Could not auto-detect mode from BAM: {e}")
        return 'unknown'


# ---------------------------------------------------------------------------
# Slim IPC support for fiberhmm-apply (mirrors the recall_tfs pattern).
#
# The serial main process used to call _extract_fiber_read_from_pysam per
# read — which decodes the query sequence (1-2 ms for a 20 kb PacBio read)
# AND parses MM/ML (1-2 ms).  At ~3-7 ms/read serial in main, the apply
# pipeline ceiling was ~150-300 r/s regardless of worker count, leaving
# -c 4 workers at ~38% CPU instead of 400%.
#
# The slim-IPC path moves the MM/ML parse into the workers: main does
# only the cheap pysam tag access + sequence decode, builds a slim
# payload, ships it.  Workers parse + encode + Viterbi + decode.  This
# shifts ~1-3 ms/read off the main-process critical path.
# ---------------------------------------------------------------------------


class _ApplyPayloadRead:
    """Minimal duck-type for pysam.AlignedSegment used inside apply workers.

    _extract_fiber_read_from_pysam only reads .query_name, .query_sequence,
    .is_reverse, .has_tag(t), .get_tag(t) — the same surface this class
    exposes — so it works unchanged on either a real pysam segment (in main)
    or this slim payload wrapper (in worker).

    For the DAF MD-fallback path (--mode daf with raw input), the producer
    side (``make_apply_payload``) computes ``_daf_md_result`` from
    ``read.get_aligned_pairs(with_seq=True)`` once, and stashes it on the
    stub. The MD branch in _extract_fiber_read_from_pysam reads it back
    from there instead of trying to call get_aligned_pairs (which the stub
    does not implement).
    """
    __slots__ = ('query_name', 'query_sequence', 'is_reverse', '_tags',
                 '_daf_md_result')

    def __init__(self, query_name, query_sequence, is_reverse, tags,
                 daf_md_result=None):
        self.query_name = query_name
        self.query_sequence = query_sequence
        self.is_reverse = is_reverse
        self._tags = tags
        self._daf_md_result = daf_md_result

    def has_tag(self, t):
        return t in self._tags

    def get_tag(self, t):
        return self._tags[t]


def make_apply_payload(read, mode: str = 'fiber', ref_fasta=None) -> Optional[dict]:
    """Extract slim payload from a pysam read for the apply slim-IPC path.

    Runs in the *main* process.  Does NOT parse MM/ML — that moves to the
    worker via extract_fiber_read_from_payload().

    When ``mode == 'daf'`` and the read carries no R/Y IUPAC encoding,
    additionally pre-computes the MD-derived deamination positions so the
    worker can run the HMM directly on the raw BAM without an upstream
    ``fiberhmm-daf-encode`` pass. The MD walk has to happen here because
    the slim ``_ApplyPayloadRead`` stub in the worker has no access to the
    live pysam alignment API. Cost: ~1-3ms per read for raw DAF input;
    zero cost for pre-encoded BAMs (the IUPAC fast path triggers first).

    Returns None only if the read has no sequence (caller treats as skip).
    """
    seq = read.query_sequence
    if not seq:
        return None

    tags = {}
    for t in ('MM', 'Mm', 'ML', 'Ml', 'st'):
        if read.has_tag(t):
            val = read.get_tag(t)
            if t in ('ML', 'Ml'):
                # array.array('B', ...) → bytes via buffer protocol: fast memcpy,
                # avoids ~5000 PyInt allocations per Hia5 PacBio read.
                try:
                    val = bytes(val)
                except TypeError:
                    pass
            tags[t] = val

    payload = {
        'query_name': read.query_name,
        'query_sequence': seq,
        'is_reverse': read.is_reverse,
        'tags': tags,
    }

    # DAF MD-fallback precomputation (live-read side, before slim-IPC handoff).
    if mode == 'daf':
        from fiberhmm.core.bam_reader import has_iupac_encoding
        if not has_iupac_encoding(seq):
            from fiberhmm.daf.encoder import get_daf_positions
            md_res = get_daf_positions(read, ref_fasta=ref_fasta)
            if md_res is not None:
                payload['_daf_md_result'] = md_res   # (ct_list, ga_list, strand_tag)

    return payload


def extract_fiber_read_from_payload(payload: dict, mode: str, prob_threshold: int) -> Optional[dict]:
    """Worker-side: turn a slim payload into a fiber_read dict.

    Equivalent to _extract_fiber_read_from_pysam(real_read, mode, prob_threshold)
    but takes the slim payload built by make_apply_payload().  Returns None
    on read with no usable modification data (no MM/ML, no IUPAC codes,
    extraction failure) — caller treats result=None as 'no footprints'.
    """
    return _extract_fiber_read_from_pysam(
        _ApplyPayloadRead(
            payload['query_name'], payload['query_sequence'],
            payload['is_reverse'], payload['tags'],
            daf_md_result=payload.get('_daf_md_result'),
        ),
        mode, prob_threshold,
    )


def _extract_fiber_read_from_pysam(read, mode: str, prob_threshold: int,
                                    ref_fasta=None) -> Optional[dict]:
    """Extract minimal data needed for HMM processing from a pysam read."""
    query_sequence = read.query_sequence
    if not query_sequence:
        return None

    # IUPAC R/Y branch: DAF-seq reads with deamination encoded in the sequence
    if mode == 'daf' and has_iupac_encoding(query_sequence):
        st_tag = read.get_tag('st') if read.has_tag('st') else None
        mod_positions, strand, conv_seq = extract_daf_iupac_positions(query_sequence, st_tag)
        if not mod_positions:
            return None
        return {
            'read_id': read.query_name,
            'query_sequence': conv_seq,       # Y→T, R→A (pure ACGT)
            'm6a_query_positions': mod_positions,
            'query_length': len(conv_seq),
            '_daf_strand': strand,            # pre-computed from st tag
        }

    # MD fallback for DAF mode: raw aligned BAM (no R/Y in sequence yet).
    # Parse MD on the fly into the same (mod_positions, strand) the R/Y
    # path would have produced, so the HMM emits byte-identical calls vs.
    # the two-pass `fiberhmm-daf-encode | fiberhmm-call` pipeline.
    #
    # Two sources for the MD result:
    #   (a) Live pysam AlignedSegment with get_aligned_pairs available
    #       (region-parallel workers fetch reads directly).
    #   (b) Pre-computed by make_apply_payload and stashed on the slim
    #       payload stub as ``_daf_md_result`` (slim-IPC path).
    if mode == 'daf':
        md_result = getattr(read, '_daf_md_result', None)
        if md_result is None and hasattr(read, 'get_aligned_pairs'):
            from fiberhmm.daf.encoder import get_daf_positions
            md_result = get_daf_positions(read, ref_fasta=ref_fasta)
        if md_result is not None:
            ct_pos, ga_pos, strand_tag = md_result
            mod_positions = set(ct_pos) if strand_tag == 'CT' else set(ga_pos)
            if not mod_positions:
                return None
            # query_sequence is already raw ACGT (no R/Y to decode);
            # uppercase to match what extract_daf_iupac_positions emits.
            return {
                'read_id': read.query_name,
                'query_sequence': query_sequence.upper(),
                'm6a_query_positions': mod_positions,
                'query_length': len(query_sequence),
                '_daf_strand': '+' if strand_tag == 'CT' else '-',
            }

    # Legacy MM/ML path: use the fast vectorized parser instead of
    # read.modified_bases.  pysam's modified_bases returns a dict of
    # (base, strand, mod_code) -> [(pos, qual), ...] which forces a Python
    # iteration over every modification (~5000 per Hia5 PacBio read =
    # ~5-10 ms/read).  parse_mm_tag_query_positions does the same parse in
    # vectorized numpy and accepts ML as bytes (no PyInt materialization).
    try:
        mm_tag = read.get_tag('MM') if read.has_tag('MM') else (
                  read.get_tag('Mm') if read.has_tag('Mm') else '')
    except KeyError:
        mm_tag = ''
    try:
        ml_raw = read.get_tag('ML') if read.has_tag('ML') else (
                  read.get_tag('Ml') if read.has_tag('Ml') else None)
    except KeyError:
        ml_raw = None

    if not mm_tag or ml_raw is None:
        return None

    # Empty-ML guard (also avoids the parser doing real work for nothing).
    try:
        if len(ml_raw) == 0:
            return None
    except TypeError:
        pass

    # Convert ML to bytes once (fast memcpy, no PyInt allocations).
    try:
        ml_bytes = bytes(ml_raw)
    except TypeError:
        ml_bytes = ml_raw

    try:
        mod_pos_set = parse_mm_tag_query_positions(
            mm_tag, ml_bytes, query_sequence, read.is_reverse,
            prob_threshold=prob_threshold, mode=mode,
        )
    except Exception:
        return None

    return {
        'read_id': read.query_name,
        'query_sequence': query_sequence,
        'm6a_query_positions': mod_pos_set,
        'query_length': len(query_sequence)
    }


def _process_single_read(fiber_read: dict, model, edge_trim: int, circular: bool,
                          mode: str, context_size: int, msp_min_size: int,
                          with_scores: bool, return_posteriors: bool = False,
                          nuc_min_size: int = 85,
                          include_encoded: bool = False) -> Optional[dict]:
    """Process a single read through HMM. Returns footprint data or None.

    When include_encoded=True the encoded observation array and strand are
    attached to the result as 'encoded' and 'strand'.  Used by the fused
    apply+recall worker to avoid re-encoding the sequence for the TF scan.
    """

    query_sequence = fiber_read['query_sequence']
    m6a_positions = fiber_read['m6a_query_positions']

    # Detect strand
    if mode == 'daf':
        strand = fiber_read.get('_daf_strand') or detect_daf_strand(query_sequence, m6a_positions)
    elif mode == 'nanopore-fiber':
        strand = '.'  # No strand detection for nanopore
    else:
        strand = '.'

    # Encode
    encoded = encode_from_query_sequence(
        query_sequence, m6a_positions, edge_trim,
        mode=mode, strand=strand, context_size=context_size
    )

    if len(encoded) == 0:
        return None

    # Predict
    fp_result = predict_footprints_and_msps(model, encoded, msp_min_size, with_scores,
                                             return_posteriors=return_posteriors,
                                             nuc_min_size=nuc_min_size)

    # If no footprints and we don't need posteriors or encoded, skip
    if len(fp_result['footprint_starts']) == 0 and len(fp_result['msp_starts']) == 0:
        if not return_posteriors and not include_encoded:
            return None

    result = {
        'ns': fp_result['footprint_starts'],
        'nl': fp_result['footprint_sizes'],
        'ns_scores': fp_result.get('footprint_scores'),
        'as': fp_result['msp_starts'],
        'al': fp_result['msp_sizes'],
        'as_scores': fp_result.get('msp_scores')
    }

    # Include posteriors data if requested
    if return_posteriors and fp_result.get('posteriors') is not None:
        result['posteriors'] = fp_result['posteriors']
        result['strand'] = strand

    # Include encoded obs for the fused recall pass (no re-encoding cost)
    if include_encoded:
        result['encoded'] = encoded
        result['strand'] = strand

    return result
