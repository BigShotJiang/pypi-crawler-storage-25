# minorun365

minorun365のプロフィールを表示するCLIカードパッケージ（Python版）です。

```zsh
uvx minorun365
```

または

```zsh
pip install minorun365
minorun365
```

Node.js版は [NPM](https://www.npmjs.com/package/minorun365) で公開しています：

```zsh
npx minorun365
```

ソースコード： https://github.com/minorun365/minorun365-card
