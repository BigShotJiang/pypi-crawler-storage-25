from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ....models.get_tenant_response import GetTenantResponse
    from .invites.invites_request_builder import InvitesRequestBuilder
    from .settings.settings_request_builder import SettingsRequestBuilder
    from .switch.switch_request_builder import SwitchRequestBuilder
    from .users.users_request_builder import UsersRequestBuilder
    from .verify_access.verify_access_request_builder import VerifyAccessRequestBuilder

class IdentifierItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/tenants/{identifier-id}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new IdentifierItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/tenants/{identifier%2Did}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[GetTenantResponse]:
        """
        GET_api_tenants_identifier
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[GetTenantResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ....models.get_tenant_response import GetTenantResponse

        return await self.request_adapter.send_async(request_info, GetTenantResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_tenants_identifier
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> IdentifierItemRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: IdentifierItemRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return IdentifierItemRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def invites(self) -> InvitesRequestBuilder:
        """
        The invites property
        """
        from .invites.invites_request_builder import InvitesRequestBuilder

        return InvitesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def settings(self) -> SettingsRequestBuilder:
        """
        The settings property
        """
        from .settings.settings_request_builder import SettingsRequestBuilder

        return SettingsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def switch(self) -> SwitchRequestBuilder:
        """
        The switch property
        """
        from .switch.switch_request_builder import SwitchRequestBuilder

        return SwitchRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def users(self) -> UsersRequestBuilder:
        """
        The users property
        """
        from .users.users_request_builder import UsersRequestBuilder

        return UsersRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def verify_access(self) -> VerifyAccessRequestBuilder:
        """
        The verifyAccess property
        """
        from .verify_access.verify_access_request_builder import VerifyAccessRequestBuilder

        return VerifyAccessRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class IdentifierItemRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

