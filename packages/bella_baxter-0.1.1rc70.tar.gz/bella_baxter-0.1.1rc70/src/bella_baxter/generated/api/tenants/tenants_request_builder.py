from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ...models.command import Command
    from ...models.create_tenant_response import CreateTenantResponse
    from ...models.list_tenants_response import ListTenantsResponse
    from .invites.invites_request_builder import InvitesRequestBuilder
    from .item.identifier_item_request_builder import IdentifierItemRequestBuilder
    from .my_tenants.my_tenants_request_builder import MyTenantsRequestBuilder
    from .new.new_request_builder import NewRequestBuilder

class TenantsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/tenants
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new TenantsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/tenants{?page*,pageSize*}", path_parameters)
    
    def by_identifier_id(self,identifier_id: str) -> IdentifierItemRequestBuilder:
        """
        Gets an item from the bella_baxter.generated.api.tenants.item collection
        param identifier_id: Unique identifier of the item
        Returns: IdentifierItemRequestBuilder
        """
        if identifier_id is None:
            raise TypeError("identifier_id cannot be null.")
        from .item.identifier_item_request_builder import IdentifierItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["identifier%2Did"] = identifier_id
        return IdentifierItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[TenantsRequestBuilderGetQueryParameters]] = None) -> Optional[list[ListTenantsResponse]]:
        """
        GET_api_tenants
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[list[ListTenantsResponse]]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ...models.list_tenants_response import ListTenantsResponse

        return await self.request_adapter.send_collection_async(request_info, ListTenantsResponse, None)
    
    async def post(self,body: Command, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[CreateTenantResponse]:
        """
        POST_api_tenants
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[CreateTenantResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ...models.create_tenant_response import CreateTenantResponse

        return await self.request_adapter.send_async(request_info, CreateTenantResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[TenantsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        GET_api_tenants
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: Command, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        POST_api_tenants
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> TenantsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: TenantsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return TenantsRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def invites(self) -> InvitesRequestBuilder:
        """
        The invites property
        """
        from .invites.invites_request_builder import InvitesRequestBuilder

        return InvitesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def my_tenants(self) -> MyTenantsRequestBuilder:
        """
        The myTenants property
        """
        from .my_tenants.my_tenants_request_builder import MyTenantsRequestBuilder

        return MyTenantsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def new(self) -> NewRequestBuilder:
        """
        The new property
        """
        from .new.new_request_builder import NewRequestBuilder

        return NewRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class TenantsRequestBuilderGetQueryParameters():
        """
        GET_api_tenants
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "page_size":
                return "pageSize"
            if original_name == "page":
                return "page"
            return original_name
        
        page: Optional[int] = None

        page_size: Optional[int] = None

    
    @dataclass
    class TenantsRequestBuilderGetRequestConfiguration(RequestConfiguration[TenantsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class TenantsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

