from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ......models.create_environment_command import CreateEnvironmentCommand
    from ......models.environment_operation_response import EnvironmentOperationResponse
    from ......models.environment_response import EnvironmentResponse
    from .item.with_env_slug_item_request_builder import WithEnvSlugItemRequestBuilder

class EnvironmentsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/projects/{-id}/environments
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new EnvironmentsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/projects/{%2Did}/environments", path_parameters)
    
    def by_env_slug(self,env_slug: str) -> WithEnvSlugItemRequestBuilder:
        """
        Gets an item from the bella_baxter.generated.api.v1.projects.item.environments.item collection
        param env_slug: Unique identifier of the item
        Returns: WithEnvSlugItemRequestBuilder
        """
        if env_slug is None:
            raise TypeError("env_slug cannot be null.")
        from .item.with_env_slug_item_request_builder import WithEnvSlugItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["envSlug"] = env_slug
        return WithEnvSlugItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[list[EnvironmentResponse]]:
        """
        GET_api_v1_projects_projectRef_environments
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[list[EnvironmentResponse]]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ......models.environment_response import EnvironmentResponse

        return await self.request_adapter.send_collection_async(request_info, EnvironmentResponse, None)
    
    async def post(self,body: CreateEnvironmentCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[EnvironmentOperationResponse]:
        """
        POST_api_v1_projects_projectRef_environments
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[EnvironmentOperationResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        from ......models.environment_operation_response import EnvironmentOperationResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": EnvironmentOperationResponse,
            "401": EnvironmentOperationResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ......models.environment_operation_response import EnvironmentOperationResponse

        return await self.request_adapter.send_async(request_info, EnvironmentOperationResponse, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_projects_projectRef_environments
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: CreateEnvironmentCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        POST_api_v1_projects_projectRef_environments
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> EnvironmentsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: EnvironmentsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return EnvironmentsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class EnvironmentsRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class EnvironmentsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

