from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .encryption_key.encryption_key_request_builder import EncryptionKeyRequestBuilder
    from .sso.sso_request_builder import SsoRequestBuilder
    from .zke.zke_request_builder import ZkeRequestBuilder

class MeRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/tenants/me
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new MeRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/tenants/me", path_parameters)
    
    @property
    def encryption_key(self) -> EncryptionKeyRequestBuilder:
        """
        The encryptionKey property
        """
        from .encryption_key.encryption_key_request_builder import EncryptionKeyRequestBuilder

        return EncryptionKeyRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def sso(self) -> SsoRequestBuilder:
        """
        The sso property
        """
        from .sso.sso_request_builder import SsoRequestBuilder

        return SsoRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def zke(self) -> ZkeRequestBuilder:
        """
        The zke property
        """
        from .zke.zke_request_builder import ZkeRequestBuilder

        return ZkeRequestBuilder(self.request_adapter, self.path_parameters)
    

