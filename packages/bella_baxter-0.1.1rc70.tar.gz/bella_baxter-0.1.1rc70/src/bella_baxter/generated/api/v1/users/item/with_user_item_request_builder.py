from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.operation_response import OperationResponse
    from .....models.user_response import UserResponse
    from .reactivate.reactivate_request_builder import ReactivateRequestBuilder

class WithUserItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/users/{userId}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithUserItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/users/{userId}{?reason*}", path_parameters)
    
    async def delete(self,request_configuration: Optional[RequestConfiguration[WithUserItemRequestBuilderDeleteQueryParameters]] = None) -> Optional[OperationResponse]:
        """
        DELETE_api_v1_users_userId
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[OperationResponse]
        """
        request_info = self.to_delete_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.operation_response import OperationResponse

        return await self.request_adapter.send_async(request_info, OperationResponse, None)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[UserResponse]:
        """
        GET_api_v1_users_userId
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[UserResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.user_response import UserResponse

        return await self.request_adapter.send_async(request_info, UserResponse, None)
    
    def to_delete_request_information(self,request_configuration: Optional[RequestConfiguration[WithUserItemRequestBuilderDeleteQueryParameters]] = None) -> RequestInformation:
        """
        DELETE_api_v1_users_userId
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.DELETE, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_users_userId
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> WithUserItemRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: WithUserItemRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return WithUserItemRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def reactivate(self) -> ReactivateRequestBuilder:
        """
        The reactivate property
        """
        from .reactivate.reactivate_request_builder import ReactivateRequestBuilder

        return ReactivateRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class WithUserItemRequestBuilderDeleteQueryParameters():
        """
        DELETE_api_v1_users_userId
        """
        reason: Optional[str] = None

    
    @dataclass
    class WithUserItemRequestBuilderDeleteRequestConfiguration(RequestConfiguration[WithUserItemRequestBuilderDeleteQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class WithUserItemRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

