from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ca_public_key.ca_public_key_request_builder import CaPublicKeyRequestBuilder
    from .configure.configure_request_builder import ConfigureRequestBuilder
    from .roles.roles_request_builder import RolesRequestBuilder
    from .sign.sign_request_builder import SignRequestBuilder

class SshRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/projects/{-id}/environments/{envSlug}/ssh
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SshRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/projects/{%2Did}/environments/{envSlug}/ssh", path_parameters)
    
    @property
    def ca_public_key(self) -> CaPublicKeyRequestBuilder:
        """
        The caPublicKey property
        """
        from .ca_public_key.ca_public_key_request_builder import CaPublicKeyRequestBuilder

        return CaPublicKeyRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def configure(self) -> ConfigureRequestBuilder:
        """
        The configure property
        """
        from .configure.configure_request_builder import ConfigureRequestBuilder

        return ConfigureRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def roles(self) -> RolesRequestBuilder:
        """
        The roles property
        """
        from .roles.roles_request_builder import RolesRequestBuilder

        return RolesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def sign(self) -> SignRequestBuilder:
        """
        The sign property
        """
        from .sign.sign_request_builder import SignRequestBuilder

        return SignRequestBuilder(self.request_adapter, self.path_parameters)
    

