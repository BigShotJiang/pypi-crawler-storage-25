from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .health.health_request_builder import HealthRequestBuilder
    from .integration_info.integration_info_request_builder import IntegrationInfoRequestBuilder
    from .rate_limit.rate_limit_request_builder import RateLimitRequestBuilder

class SystemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/system
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SystemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/system", path_parameters)
    
    @property
    def health(self) -> HealthRequestBuilder:
        """
        The health property
        """
        from .health.health_request_builder import HealthRequestBuilder

        return HealthRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def integration_info(self) -> IntegrationInfoRequestBuilder:
        """
        The integrationInfo property
        """
        from .integration_info.integration_info_request_builder import IntegrationInfoRequestBuilder

        return IntegrationInfoRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def rate_limit(self) -> RateLimitRequestBuilder:
        """
        The rateLimit property
        """
        from .rate_limit.rate_limit_request_builder import RateLimitRequestBuilder

        return RateLimitRequestBuilder(self.request_adapter, self.path_parameters)
    

