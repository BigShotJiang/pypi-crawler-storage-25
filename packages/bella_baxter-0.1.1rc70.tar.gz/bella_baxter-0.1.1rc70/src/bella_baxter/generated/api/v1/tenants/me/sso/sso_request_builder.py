from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ......models.i_result import IResult
    from ......models.sso_config_response import SsoConfigResponse
    from ......models.sso_status_response import SsoStatusResponse
    from ......models.update_sso_config_request import UpdateSsoConfigRequest
    from .enforce.enforce_request_builder import EnforceRequestBuilder
    from .oidc.oidc_request_builder import OidcRequestBuilder
    from .request.request_request_builder import RequestRequestBuilder
    from .saml.saml_request_builder import SamlRequestBuilder

class SsoRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/tenants/me/sso
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SsoRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/tenants/me/sso", path_parameters)
    
    async def delete(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[IResult]:
        """
        DELETE_api_v1_tenants_me_sso
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[IResult]
        """
        request_info = self.to_delete_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ......models.i_result import IResult

        return await self.request_adapter.send_async(request_info, IResult, None)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[SsoStatusResponse]:
        """
        GET_api_v1_tenants_me_sso
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[SsoStatusResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ......models.sso_status_response import SsoStatusResponse

        return await self.request_adapter.send_async(request_info, SsoStatusResponse, None)
    
    async def put(self,body: UpdateSsoConfigRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[SsoConfigResponse]:
        """
        PUT_api_v1_tenants_me_sso
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[SsoConfigResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_put_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ......models.sso_config_response import SsoConfigResponse

        return await self.request_adapter.send_async(request_info, SsoConfigResponse, None)
    
    def to_delete_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        DELETE_api_v1_tenants_me_sso
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.DELETE, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_tenants_me_sso
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_put_request_information(self,body: UpdateSsoConfigRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        PUT_api_v1_tenants_me_sso
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.PUT, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> SsoRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: SsoRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return SsoRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def enforce(self) -> EnforceRequestBuilder:
        """
        The enforce property
        """
        from .enforce.enforce_request_builder import EnforceRequestBuilder

        return EnforceRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def oidc(self) -> OidcRequestBuilder:
        """
        The oidc property
        """
        from .oidc.oidc_request_builder import OidcRequestBuilder

        return OidcRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def request(self) -> RequestRequestBuilder:
        """
        The request property
        """
        from .request.request_request_builder import RequestRequestBuilder

        return RequestRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def saml(self) -> SamlRequestBuilder:
        """
        The saml property
        """
        from .saml.saml_request_builder import SamlRequestBuilder

        return SamlRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class SsoRequestBuilderDeleteRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class SsoRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class SsoRequestBuilderPutRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

