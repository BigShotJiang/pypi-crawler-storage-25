from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ca.ca_request_builder import CaRequestBuilder
    from .certificates.certificates_request_builder import CertificatesRequestBuilder
    from .issue.issue_request_builder import IssueRequestBuilder
    from .revoke.revoke_request_builder import RevokeRequestBuilder
    from .roles.roles_request_builder import RolesRequestBuilder
    from .tidy.tidy_request_builder import TidyRequestBuilder

class PkiRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/projects/{-id}/environments/{envSlug}/pki
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new PkiRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/projects/{%2Did}/environments/{envSlug}/pki", path_parameters)
    
    @property
    def ca(self) -> CaRequestBuilder:
        """
        The ca property
        """
        from .ca.ca_request_builder import CaRequestBuilder

        return CaRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def certificates(self) -> CertificatesRequestBuilder:
        """
        The certificates property
        """
        from .certificates.certificates_request_builder import CertificatesRequestBuilder

        return CertificatesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def issue(self) -> IssueRequestBuilder:
        """
        The issue property
        """
        from .issue.issue_request_builder import IssueRequestBuilder

        return IssueRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def revoke(self) -> RevokeRequestBuilder:
        """
        The revoke property
        """
        from .revoke.revoke_request_builder import RevokeRequestBuilder

        return RevokeRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def roles(self) -> RolesRequestBuilder:
        """
        The roles property
        """
        from .roles.roles_request_builder import RolesRequestBuilder

        return RolesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def tidy(self) -> TidyRequestBuilder:
        """
        The tidy property
        """
        from .tidy.tidy_request_builder import TidyRequestBuilder

        return TidyRequestBuilder(self.request_adapter, self.path_parameters)
    

