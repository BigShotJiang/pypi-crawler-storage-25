from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.i_result import IResult
    from .....models.update_webhook_request import UpdateWebhookRequest
    from .....models.webhook_operation_response import WebhookOperationResponse
    from .deactivate.deactivate_request_builder import DeactivateRequestBuilder
    from .deliveries.deliveries_request_builder import DeliveriesRequestBuilder
    from .link_provider.link_provider_request_builder import LinkProviderRequestBuilder
    from .reactivate.reactivate_request_builder import ReactivateRequestBuilder
    from .rotate_secret.rotate_secret_request_builder import RotateSecretRequestBuilder
    from .test.test_request_builder import TestRequestBuilder

class WebhooksItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/webhooks/{id}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WebhooksItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/webhooks/{id}", path_parameters)
    
    async def delete(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[WebhookOperationResponse]:
        """
        DELETE_api_v1_webhooks_id
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[WebhookOperationResponse]
        """
        request_info = self.to_delete_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.webhook_operation_response import WebhookOperationResponse

        return await self.request_adapter.send_async(request_info, WebhookOperationResponse, None)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[IResult]:
        """
        GET_api_v1_webhooks_id
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[IResult]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.i_result import IResult

        return await self.request_adapter.send_async(request_info, IResult, None)
    
    async def put(self,body: UpdateWebhookRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[WebhookOperationResponse]:
        """
        PUT_api_v1_webhooks_id
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[WebhookOperationResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_put_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.webhook_operation_response import WebhookOperationResponse

        return await self.request_adapter.send_async(request_info, WebhookOperationResponse, None)
    
    def to_delete_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        DELETE_api_v1_webhooks_id
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.DELETE, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_webhooks_id
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_put_request_information(self,body: UpdateWebhookRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        PUT_api_v1_webhooks_id
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.PUT, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> WebhooksItemRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: WebhooksItemRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return WebhooksItemRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def deactivate(self) -> DeactivateRequestBuilder:
        """
        The deactivate property
        """
        from .deactivate.deactivate_request_builder import DeactivateRequestBuilder

        return DeactivateRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def deliveries(self) -> DeliveriesRequestBuilder:
        """
        The deliveries property
        """
        from .deliveries.deliveries_request_builder import DeliveriesRequestBuilder

        return DeliveriesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def link_provider(self) -> LinkProviderRequestBuilder:
        """
        The linkProvider property
        """
        from .link_provider.link_provider_request_builder import LinkProviderRequestBuilder

        return LinkProviderRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def reactivate(self) -> ReactivateRequestBuilder:
        """
        The reactivate property
        """
        from .reactivate.reactivate_request_builder import ReactivateRequestBuilder

        return ReactivateRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def rotate_secret(self) -> RotateSecretRequestBuilder:
        """
        The rotateSecret property
        """
        from .rotate_secret.rotate_secret_request_builder import RotateSecretRequestBuilder

        return RotateSecretRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def test(self) -> TestRequestBuilder:
        """
        The test property
        """
        from .test.test_request_builder import TestRequestBuilder

        return TestRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class WebhooksItemRequestBuilderDeleteRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class WebhooksItemRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class WebhooksItemRequestBuilderPutRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

