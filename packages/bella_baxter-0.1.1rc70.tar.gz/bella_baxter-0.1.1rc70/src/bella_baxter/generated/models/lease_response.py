from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class LeaseResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The expiredAt property
    expired_at: Optional[datetime.datetime] = None
    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The grantedAt property
    granted_at: Optional[datetime.datetime] = None
    # The holderId property
    holder_id: Optional[UUID] = None
    # The holderName property
    holder_name: Optional[str] = None
    # The id property
    id: Optional[UUID] = None
    # The revocationReason property
    revocation_reason: Optional[str] = None
    # The revokedAt property
    revoked_at: Optional[datetime.datetime] = None
    # The revokedBy property
    revoked_by: Optional[UUID] = None
    # The secretCount property
    secret_count: Optional[int] = None
    # The secretKeysSnapshot property
    secret_keys_snapshot: Optional[list[str]] = None
    # The status property
    status: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LeaseResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LeaseResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LeaseResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "expiredAt": lambda n : setattr(self, 'expired_at', n.get_datetime_value()),
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "grantedAt": lambda n : setattr(self, 'granted_at', n.get_datetime_value()),
            "holderId": lambda n : setattr(self, 'holder_id', n.get_uuid_value()),
            "holderName": lambda n : setattr(self, 'holder_name', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "revocationReason": lambda n : setattr(self, 'revocation_reason', n.get_str_value()),
            "revokedAt": lambda n : setattr(self, 'revoked_at', n.get_datetime_value()),
            "revokedBy": lambda n : setattr(self, 'revoked_by', n.get_uuid_value()),
            "secretCount": lambda n : setattr(self, 'secret_count', n.get_int_value()),
            "secretKeysSnapshot": lambda n : setattr(self, 'secret_keys_snapshot', n.get_collection_of_primitive_values(str)),
            "status": lambda n : setattr(self, 'status', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("expiredAt", self.expired_at)
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_datetime_value("grantedAt", self.granted_at)
        writer.write_uuid_value("holderId", self.holder_id)
        writer.write_str_value("holderName", self.holder_name)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("revocationReason", self.revocation_reason)
        writer.write_datetime_value("revokedAt", self.revoked_at)
        writer.write_uuid_value("revokedBy", self.revoked_by)
        writer.write_int_value("secretCount", self.secret_count)
        writer.write_collection_of_primitive_values("secretKeysSnapshot", self.secret_keys_snapshot)
        writer.write_str_value("status", self.status)
        writer.write_additional_data_value(self.additional_data)
    

