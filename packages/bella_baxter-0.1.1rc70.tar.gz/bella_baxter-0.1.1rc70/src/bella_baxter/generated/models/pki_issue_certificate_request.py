from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PkiIssueCertificateRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The altNames property
    alt_names: Optional[str] = None
    # The commonName property
    common_name: Optional[str] = None
    # The ipSans property
    ip_sans: Optional[str] = None
    # The roleName property
    role_name: Optional[str] = None
    # The ttl property
    ttl: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PkiIssueCertificateRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PkiIssueCertificateRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PkiIssueCertificateRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "altNames": lambda n : setattr(self, 'alt_names', n.get_str_value()),
            "commonName": lambda n : setattr(self, 'common_name', n.get_str_value()),
            "ipSans": lambda n : setattr(self, 'ip_sans', n.get_str_value()),
            "roleName": lambda n : setattr(self, 'role_name', n.get_str_value()),
            "ttl": lambda n : setattr(self, 'ttl', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("altNames", self.alt_names)
        writer.write_str_value("commonName", self.common_name)
        writer.write_str_value("ipSans", self.ip_sans)
        writer.write_str_value("roleName", self.role_name)
        writer.write_str_value("ttl", self.ttl)
        writer.write_additional_data_value(self.additional_data)
    

