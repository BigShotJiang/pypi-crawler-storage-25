from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .tenant_invite_role import TenantInviteRole

@dataclass
class InviteListResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The acceptedAt property
    accepted_at: Optional[datetime.datetime] = None
    # The acceptedByUserId property
    accepted_by_user_id: Optional[UUID] = None
    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The isExpired property
    is_expired: Optional[bool] = None
    # The isRevoked property
    is_revoked: Optional[bool] = None
    # The role property
    role: Optional[TenantInviteRole] = None
    # The tenantId property
    tenant_id: Optional[UUID] = None
    # The token property
    token: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> InviteListResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: InviteListResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return InviteListResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .tenant_invite_role import TenantInviteRole

        from .tenant_invite_role import TenantInviteRole

        fields: dict[str, Callable[[Any], None]] = {
            "acceptedAt": lambda n : setattr(self, 'accepted_at', n.get_datetime_value()),
            "acceptedByUserId": lambda n : setattr(self, 'accepted_by_user_id', n.get_uuid_value()),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "isExpired": lambda n : setattr(self, 'is_expired', n.get_bool_value()),
            "isRevoked": lambda n : setattr(self, 'is_revoked', n.get_bool_value()),
            "role": lambda n : setattr(self, 'role', n.get_enum_value(TenantInviteRole)),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_uuid_value()),
            "token": lambda n : setattr(self, 'token', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("acceptedAt", self.accepted_at)
        writer.write_uuid_value("acceptedByUserId", self.accepted_by_user_id)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_bool_value("isExpired", self.is_expired)
        writer.write_bool_value("isRevoked", self.is_revoked)
        writer.write_enum_value("role", self.role)
        writer.write_uuid_value("tenantId", self.tenant_id)
        writer.write_uuid_value("token", self.token)
        writer.write_additional_data_value(self.additional_data)
    

