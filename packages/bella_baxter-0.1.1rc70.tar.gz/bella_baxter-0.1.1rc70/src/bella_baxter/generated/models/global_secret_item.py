from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .global_secret_item_tags import GlobalSecretItem_tags

@dataclass
class GlobalSecretItem(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The description property
    description: Optional[str] = None
    # The ignoreInScan property
    ignore_in_scan: Optional[bool] = None
    # The key property
    key: Optional[str] = None
    # The tags property
    tags: Optional[GlobalSecretItem_tags] = None
    # The type property
    type: Optional[str] = None
    # The updatedAt property
    updated_at: Optional[datetime.datetime] = None
    # The value property
    value: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GlobalSecretItem:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GlobalSecretItem
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return GlobalSecretItem()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .global_secret_item_tags import GlobalSecretItem_tags

        from .global_secret_item_tags import GlobalSecretItem_tags

        fields: dict[str, Callable[[Any], None]] = {
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "ignoreInScan": lambda n : setattr(self, 'ignore_in_scan', n.get_bool_value()),
            "key": lambda n : setattr(self, 'key', n.get_str_value()),
            "tags": lambda n : setattr(self, 'tags', n.get_object_value(GlobalSecretItem_tags)),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
            "value": lambda n : setattr(self, 'value', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("description", self.description)
        writer.write_bool_value("ignoreInScan", self.ignore_in_scan)
        writer.write_str_value("key", self.key)
        writer.write_object_value("tags", self.tags)
        writer.write_str_value("type", self.type)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_str_value("value", self.value)
        writer.write_additional_data_value(self.additional_data)
    

