from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class RegisterTenantEncryptionKeyRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The keyLossAcknowledged property
    key_loss_acknowledged: Optional[bool] = None
    # The masterPublicKey property
    master_public_key: Optional[str] = None
    # The recoveryPublicKey property
    recovery_public_key: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RegisterTenantEncryptionKeyRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RegisterTenantEncryptionKeyRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RegisterTenantEncryptionKeyRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "keyLossAcknowledged": lambda n : setattr(self, 'key_loss_acknowledged', n.get_bool_value()),
            "masterPublicKey": lambda n : setattr(self, 'master_public_key', n.get_str_value()),
            "recoveryPublicKey": lambda n : setattr(self, 'recovery_public_key', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("keyLossAcknowledged", self.key_loss_acknowledged)
        writer.write_str_value("masterPublicKey", self.master_public_key)
        writer.write_str_value("recoveryPublicKey", self.recovery_public_key)
        writer.write_additional_data_value(self.additional_data)
    

