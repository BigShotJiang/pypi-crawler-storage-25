from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .get_project_response_members import GetProjectResponse_members

@dataclass
class GetProjectResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The currentUserRole property
    current_user_role: Optional[str] = None
    # The deletedAt property
    deleted_at: Optional[datetime.datetime] = None
    # The description property
    description: Optional[str] = None
    # The globalSecretProviderId property
    global_secret_provider_id: Optional[UUID] = None
    # The id property
    id: Optional[UUID] = None
    # The members property
    members: Optional[GetProjectResponse_members] = None
    # The name property
    name: Optional[str] = None
    # The ownerId property
    owner_id: Optional[UUID] = None
    # The ownerName property
    owner_name: Optional[str] = None
    # The slug property
    slug: Optional[str] = None
    # The status property
    status: Optional[str] = None
    # The tags property
    tags: Optional[list[str]] = None
    # The updatedAt property
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GetProjectResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GetProjectResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return GetProjectResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .get_project_response_members import GetProjectResponse_members

        from .get_project_response_members import GetProjectResponse_members

        fields: dict[str, Callable[[Any], None]] = {
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "currentUserRole": lambda n : setattr(self, 'current_user_role', n.get_str_value()),
            "deletedAt": lambda n : setattr(self, 'deleted_at', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "globalSecretProviderId": lambda n : setattr(self, 'global_secret_provider_id', n.get_uuid_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "members": lambda n : setattr(self, 'members', n.get_object_value(GetProjectResponse_members)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "ownerId": lambda n : setattr(self, 'owner_id', n.get_uuid_value()),
            "ownerName": lambda n : setattr(self, 'owner_name', n.get_str_value()),
            "slug": lambda n : setattr(self, 'slug', n.get_str_value()),
            "status": lambda n : setattr(self, 'status', n.get_str_value()),
            "tags": lambda n : setattr(self, 'tags', n.get_collection_of_primitive_values(str)),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("currentUserRole", self.current_user_role)
        writer.write_datetime_value("deletedAt", self.deleted_at)
        writer.write_str_value("description", self.description)
        writer.write_uuid_value("globalSecretProviderId", self.global_secret_provider_id)
        writer.write_uuid_value("id", self.id)
        writer.write_object_value("members", self.members)
        writer.write_str_value("name", self.name)
        writer.write_uuid_value("ownerId", self.owner_id)
        writer.write_str_value("ownerName", self.owner_name)
        writer.write_str_value("slug", self.slug)
        writer.write_str_value("status", self.status)
        writer.write_collection_of_primitive_values("tags", self.tags)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_additional_data_value(self.additional_data)
    

