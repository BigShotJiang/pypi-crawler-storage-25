from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class AuthConfigResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The cliClientId property
    cli_client_id: Optional[str] = None
    # The issuer property
    issuer: Optional[str] = None
    # The keycloakUrl property
    keycloak_url: Optional[str] = None
    # The realm property
    realm: Optional[str] = None
    # The webAppClientId property
    web_app_client_id: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AuthConfigResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AuthConfigResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AuthConfigResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "cliClientId": lambda n : setattr(self, 'cli_client_id', n.get_str_value()),
            "issuer": lambda n : setattr(self, 'issuer', n.get_str_value()),
            "keycloakUrl": lambda n : setattr(self, 'keycloak_url', n.get_str_value()),
            "realm": lambda n : setattr(self, 'realm', n.get_str_value()),
            "webAppClientId": lambda n : setattr(self, 'web_app_client_id', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("cliClientId", self.cli_client_id)
        writer.write_str_value("issuer", self.issuer)
        writer.write_str_value("keycloakUrl", self.keycloak_url)
        writer.write_str_value("realm", self.realm)
        writer.write_str_value("webAppClientId", self.web_app_client_id)
        writer.write_additional_data_value(self.additional_data)
    

