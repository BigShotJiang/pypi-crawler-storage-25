from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .tenant_role import TenantRole

@dataclass
class TenantAccess(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The role property
    role: Optional[TenantRole] = None
    # The slug property
    slug: Optional[str] = None
    # The tenantId property
    tenant_id: Optional[UUID] = None
    # The tenantName property
    tenant_name: Optional[str] = None
    # The userEmail property
    user_email: Optional[str] = None
    # The userId property
    user_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TenantAccess:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TenantAccess
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TenantAccess()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .tenant_role import TenantRole

        from .tenant_role import TenantRole

        fields: dict[str, Callable[[Any], None]] = {
            "role": lambda n : setattr(self, 'role', n.get_enum_value(TenantRole)),
            "slug": lambda n : setattr(self, 'slug', n.get_str_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_uuid_value()),
            "tenantName": lambda n : setattr(self, 'tenant_name', n.get_str_value()),
            "userEmail": lambda n : setattr(self, 'user_email', n.get_str_value()),
            "userId": lambda n : setattr(self, 'user_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("role", self.role)
        writer.write_str_value("slug", self.slug)
        writer.write_uuid_value("tenantId", self.tenant_id)
        writer.write_str_value("tenantName", self.tenant_name)
        writer.write_str_value("userEmail", self.user_email)
        writer.write_uuid_value("userId", self.user_id)
        writer.write_additional_data_value(self.additional_data)
    

