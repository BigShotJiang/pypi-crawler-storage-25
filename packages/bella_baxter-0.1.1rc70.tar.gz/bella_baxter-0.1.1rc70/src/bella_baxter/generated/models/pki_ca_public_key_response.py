from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PkiCaPublicKeyResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The acmeDirectoryUrl property
    acme_directory_url: Optional[str] = None
    # The caChain property
    ca_chain: Optional[str] = None
    # The certificate property
    certificate: Optional[str] = None
    # The instructions property
    instructions: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PkiCaPublicKeyResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PkiCaPublicKeyResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PkiCaPublicKeyResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "acmeDirectoryUrl": lambda n : setattr(self, 'acme_directory_url', n.get_str_value()),
            "caChain": lambda n : setattr(self, 'ca_chain', n.get_str_value()),
            "certificate": lambda n : setattr(self, 'certificate', n.get_str_value()),
            "instructions": lambda n : setattr(self, 'instructions', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("acmeDirectoryUrl", self.acme_directory_url)
        writer.write_str_value("caChain", self.ca_chain)
        writer.write_str_value("certificate", self.certificate)
        writer.write_str_value("instructions", self.instructions)
        writer.write_additional_data_value(self.additional_data)
    

