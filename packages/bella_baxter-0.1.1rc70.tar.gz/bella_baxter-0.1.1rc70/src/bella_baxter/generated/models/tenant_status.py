from enum import Enum

class TenantStatus(str, Enum):
    Active = "Active",
    Suspended = "Suspended",
    Archived = "Archived",

