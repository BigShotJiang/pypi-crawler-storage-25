from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PkiCaSetupRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The keyType property
    key_type: Optional[str] = "rsa"
    # The ttl property
    ttl: Optional[str] = "87600h"
    # The commonName property
    common_name: Optional[str] = None
    # The country property
    country: Optional[str] = None
    # The keyBits property
    key_bits: Optional[int] = None
    # The organization property
    organization: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PkiCaSetupRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PkiCaSetupRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PkiCaSetupRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "commonName": lambda n : setattr(self, 'common_name', n.get_str_value()),
            "country": lambda n : setattr(self, 'country', n.get_str_value()),
            "keyBits": lambda n : setattr(self, 'key_bits', n.get_int_value()),
            "keyType": lambda n : setattr(self, 'key_type', n.get_str_value()),
            "organization": lambda n : setattr(self, 'organization', n.get_str_value()),
            "ttl": lambda n : setattr(self, 'ttl', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("commonName", self.common_name)
        writer.write_str_value("country", self.country)
        writer.write_int_value("keyBits", self.key_bits)
        writer.write_str_value("keyType", self.key_type)
        writer.write_str_value("organization", self.organization)
        writer.write_str_value("ttl", self.ttl)
        writer.write_additional_data_value(self.additional_data)
    

