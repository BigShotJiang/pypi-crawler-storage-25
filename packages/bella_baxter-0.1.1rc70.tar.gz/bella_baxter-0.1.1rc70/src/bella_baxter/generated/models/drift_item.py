from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DriftItem(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The envSpecific property
    env_specific: Optional[bool] = None
    # The inheritedIn property
    inherited_in: Optional[list[str]] = None
    # The isGlobal property
    is_global: Optional[bool] = None
    # The key property
    key: Optional[str] = None
    # The missingIn property
    missing_in: Optional[list[str]] = None
    # The presentIn property
    present_in: Optional[list[str]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DriftItem:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DriftItem
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DriftItem()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "envSpecific": lambda n : setattr(self, 'env_specific', n.get_bool_value()),
            "inheritedIn": lambda n : setattr(self, 'inherited_in', n.get_collection_of_primitive_values(str)),
            "isGlobal": lambda n : setattr(self, 'is_global', n.get_bool_value()),
            "key": lambda n : setattr(self, 'key', n.get_str_value()),
            "missingIn": lambda n : setattr(self, 'missing_in', n.get_collection_of_primitive_values(str)),
            "presentIn": lambda n : setattr(self, 'present_in', n.get_collection_of_primitive_values(str)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("envSpecific", self.env_specific)
        writer.write_collection_of_primitive_values("inheritedIn", self.inherited_in)
        writer.write_bool_value("isGlobal", self.is_global)
        writer.write_str_value("key", self.key)
        writer.write_collection_of_primitive_values("missingIn", self.missing_in)
        writer.write_collection_of_primitive_values("presentIn", self.present_in)
        writer.write_additional_data_value(self.additional_data)
    

