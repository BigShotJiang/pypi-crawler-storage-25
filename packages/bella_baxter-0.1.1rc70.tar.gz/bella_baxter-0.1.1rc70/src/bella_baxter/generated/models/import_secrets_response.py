from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .import_failure import ImportFailure

@dataclass
class ImportSecretsResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The failed property
    failed: Optional[list[ImportFailure]] = None
    # The imported property
    imported: Optional[int] = None
    # The skipped property
    skipped: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImportSecretsResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImportSecretsResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImportSecretsResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .import_failure import ImportFailure

        from .import_failure import ImportFailure

        fields: dict[str, Callable[[Any], None]] = {
            "failed": lambda n : setattr(self, 'failed', n.get_collection_of_object_values(ImportFailure)),
            "imported": lambda n : setattr(self, 'imported', n.get_int_value()),
            "skipped": lambda n : setattr(self, 'skipped', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("failed", self.failed)
        writer.write_int_value("imported", self.imported)
        writer.write_int_value("skipped", self.skipped)
        writer.write_additional_data_value(self.additional_data)
    

