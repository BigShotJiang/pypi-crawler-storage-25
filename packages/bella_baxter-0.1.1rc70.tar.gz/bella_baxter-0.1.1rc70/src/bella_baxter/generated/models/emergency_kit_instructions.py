from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EmergencyKitInstructions(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The step1 property
    step1: Optional[str] = None
    # The step2 property
    step2: Optional[str] = None
    # The step3 property
    step3: Optional[str] = None
    # The warning property
    warning: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EmergencyKitInstructions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EmergencyKitInstructions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EmergencyKitInstructions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "step1": lambda n : setattr(self, 'step1', n.get_str_value()),
            "step2": lambda n : setattr(self, 'step2', n.get_str_value()),
            "step3": lambda n : setattr(self, 'step3', n.get_str_value()),
            "warning": lambda n : setattr(self, 'warning', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("step1", self.step1)
        writer.write_str_value("step2", self.step2)
        writer.write_str_value("step3", self.step3)
        writer.write_str_value("warning", self.warning)
        writer.write_additional_data_value(self.additional_data)
    

