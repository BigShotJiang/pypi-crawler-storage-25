from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .notification_channel_operation_response_channel_member1 import NotificationChannelOperationResponse_channelMember1
    from .notification_channel_response import NotificationChannelResponse

@dataclass
class NotificationChannelOperationResponse_channel(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes NotificationChannelOperationResponse_channelMember1, NotificationChannelResponse
    """
    # Composed type representation for type NotificationChannelOperationResponse_channelMember1
    notification_channel_operation_response_channel_member1: Optional[NotificationChannelOperationResponse_channelMember1] = None
    # Composed type representation for type NotificationChannelResponse
    notification_channel_response: Optional[NotificationChannelResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NotificationChannelOperationResponse_channel:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NotificationChannelOperationResponse_channel
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = NotificationChannelOperationResponse_channel()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .notification_channel_operation_response_channel_member1 import NotificationChannelOperationResponse_channelMember1

            result.notification_channel_operation_response_channel_member1 = NotificationChannelOperationResponse_channelMember1()
        elif mapping_value and mapping_value.casefold() == "NotificationChannelResponse".casefold():
            from .notification_channel_response import NotificationChannelResponse

            result.notification_channel_response = NotificationChannelResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .notification_channel_operation_response_channel_member1 import NotificationChannelOperationResponse_channelMember1
        from .notification_channel_response import NotificationChannelResponse

        if self.notification_channel_operation_response_channel_member1:
            return self.notification_channel_operation_response_channel_member1.get_field_deserializers()
        if self.notification_channel_response:
            return self.notification_channel_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.notification_channel_operation_response_channel_member1:
            writer.write_object_value(None, self.notification_channel_operation_response_channel_member1)
        elif self.notification_channel_response:
            writer.write_object_value(None, self.notification_channel_response)
    

