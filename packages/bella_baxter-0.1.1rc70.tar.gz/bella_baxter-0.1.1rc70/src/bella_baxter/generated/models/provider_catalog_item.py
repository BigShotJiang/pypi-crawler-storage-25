from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ProviderCatalogItem(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The available property
    available: Optional[bool] = None
    # The description property
    description: Optional[str] = None
    # The documentationUrl property
    documentation_url: Optional[str] = None
    # The features property
    features: Optional[list[str]] = None
    # The name property
    name: Optional[str] = None
    # The type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProviderCatalogItem:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProviderCatalogItem
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProviderCatalogItem()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "available": lambda n : setattr(self, 'available', n.get_bool_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "documentationUrl": lambda n : setattr(self, 'documentation_url', n.get_str_value()),
            "features": lambda n : setattr(self, 'features', n.get_collection_of_primitive_values(str)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("available", self.available)
        writer.write_str_value("description", self.description)
        writer.write_str_value("documentationUrl", self.documentation_url)
        writer.write_collection_of_primitive_values("features", self.features)
        writer.write_str_value("name", self.name)
        writer.write_str_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

