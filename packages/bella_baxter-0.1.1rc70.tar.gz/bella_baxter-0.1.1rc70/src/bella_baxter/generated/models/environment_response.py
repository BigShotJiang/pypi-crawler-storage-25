from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EnvironmentResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The creatorId property
    creator_id: Optional[str] = None
    # The creatorUsername property
    creator_username: Optional[str] = None
    # The currentUserRole property
    current_user_role: Optional[str] = None
    # The description property
    description: Optional[str] = None
    # The id property
    id: Optional[str] = None
    # The memberCount property
    member_count: Optional[int] = None
    # The name property
    name: Optional[str] = None
    # The projectId property
    project_id: Optional[str] = None
    # The projectName property
    project_name: Optional[str] = None
    # The providerCount property
    provider_count: Optional[int] = None
    # The secretCount property
    secret_count: Optional[int] = None
    # The slug property
    slug: Optional[str] = None
    # The updatedAt property
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "creatorId": lambda n : setattr(self, 'creator_id', n.get_str_value()),
            "creatorUsername": lambda n : setattr(self, 'creator_username', n.get_str_value()),
            "currentUserRole": lambda n : setattr(self, 'current_user_role', n.get_str_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "memberCount": lambda n : setattr(self, 'member_count', n.get_int_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_str_value()),
            "projectName": lambda n : setattr(self, 'project_name', n.get_str_value()),
            "providerCount": lambda n : setattr(self, 'provider_count', n.get_int_value()),
            "secretCount": lambda n : setattr(self, 'secret_count', n.get_int_value()),
            "slug": lambda n : setattr(self, 'slug', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("creatorId", self.creator_id)
        writer.write_str_value("creatorUsername", self.creator_username)
        writer.write_str_value("currentUserRole", self.current_user_role)
        writer.write_str_value("description", self.description)
        writer.write_str_value("id", self.id)
        writer.write_int_value("memberCount", self.member_count)
        writer.write_str_value("name", self.name)
        writer.write_str_value("projectId", self.project_id)
        writer.write_str_value("projectName", self.project_name)
        writer.write_int_value("providerCount", self.provider_count)
        writer.write_int_value("secretCount", self.secret_count)
        writer.write_str_value("slug", self.slug)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_additional_data_value(self.additional_data)
    

