from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class HandshakeResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The isNewTenant property
    is_new_tenant: Optional[bool] = None
    # The requiresTokenRefresh property
    requires_token_refresh: Optional[bool] = None
    # The tenantId property
    tenant_id: Optional[UUID] = None
    # The tenantName property
    tenant_name: Optional[str] = None
    # The tenantSlug property
    tenant_slug: Optional[str] = None
    # The userId property
    user_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> HandshakeResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: HandshakeResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return HandshakeResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "isNewTenant": lambda n : setattr(self, 'is_new_tenant', n.get_bool_value()),
            "requiresTokenRefresh": lambda n : setattr(self, 'requires_token_refresh', n.get_bool_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_uuid_value()),
            "tenantName": lambda n : setattr(self, 'tenant_name', n.get_str_value()),
            "tenantSlug": lambda n : setattr(self, 'tenant_slug', n.get_str_value()),
            "userId": lambda n : setattr(self, 'user_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("isNewTenant", self.is_new_tenant)
        writer.write_bool_value("requiresTokenRefresh", self.requires_token_refresh)
        writer.write_uuid_value("tenantId", self.tenant_id)
        writer.write_str_value("tenantName", self.tenant_name)
        writer.write_str_value("tenantSlug", self.tenant_slug)
        writer.write_uuid_value("userId", self.user_id)
        writer.write_additional_data_value(self.additional_data)
    

