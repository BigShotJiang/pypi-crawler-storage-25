from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .secret_version_info import SecretVersionInfo

@dataclass
class SecretVersionsMetadata(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The currentVersion property
    current_version: Optional[int] = None
    # The maxVersions property
    max_versions: Optional[int] = None
    # The oldestVersion property
    oldest_version: Optional[int] = None
    # The versions property
    versions: Optional[list[SecretVersionInfo]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SecretVersionsMetadata:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SecretVersionsMetadata
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SecretVersionsMetadata()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .secret_version_info import SecretVersionInfo

        from .secret_version_info import SecretVersionInfo

        fields: dict[str, Callable[[Any], None]] = {
            "currentVersion": lambda n : setattr(self, 'current_version', n.get_int_value()),
            "maxVersions": lambda n : setattr(self, 'max_versions', n.get_int_value()),
            "oldestVersion": lambda n : setattr(self, 'oldest_version', n.get_int_value()),
            "versions": lambda n : setattr(self, 'versions', n.get_collection_of_object_values(SecretVersionInfo)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("currentVersion", self.current_version)
        writer.write_int_value("maxVersions", self.max_versions)
        writer.write_int_value("oldestVersion", self.oldest_version)
        writer.write_collection_of_object_values("versions", self.versions)
        writer.write_additional_data_value(self.additional_data)
    

