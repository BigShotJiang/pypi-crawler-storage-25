from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class KeyContextResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environmentId property
    environment_id: Optional[str] = None
    # The environmentName property
    environment_name: Optional[str] = None
    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The keyId property
    key_id: Optional[str] = None
    # The projectId property
    project_id: Optional[str] = None
    # The projectName property
    project_name: Optional[str] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    # The role property
    role: Optional[str] = None
    # The tenantId property
    tenant_id: Optional[str] = None
    # The tenantName property
    tenant_name: Optional[str] = None
    # The tenantSlug property
    tenant_slug: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> KeyContextResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: KeyContextResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return KeyContextResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_str_value()),
            "environmentName": lambda n : setattr(self, 'environment_name', n.get_str_value()),
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "keyId": lambda n : setattr(self, 'key_id', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_str_value()),
            "projectName": lambda n : setattr(self, 'project_name', n.get_str_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
            "role": lambda n : setattr(self, 'role', n.get_str_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_str_value()),
            "tenantName": lambda n : setattr(self, 'tenant_name', n.get_str_value()),
            "tenantSlug": lambda n : setattr(self, 'tenant_slug', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("environmentId", self.environment_id)
        writer.write_str_value("environmentName", self.environment_name)
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_str_value("keyId", self.key_id)
        writer.write_str_value("projectId", self.project_id)
        writer.write_str_value("projectName", self.project_name)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_str_value("role", self.role)
        writer.write_str_value("tenantId", self.tenant_id)
        writer.write_str_value("tenantName", self.tenant_name)
        writer.write_str_value("tenantSlug", self.tenant_slug)
        writer.write_additional_data_value(self.additional_data)
    

