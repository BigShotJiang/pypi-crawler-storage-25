from enum import Enum

class ClaimOperator(str, Enum):
    Equals = "Equals",
    StartsWith = "StartsWith",
    Contains = "Contains",

