from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .project_operation_response_project_member1 import ProjectOperationResponse_projectMember1
    from .project_response import ProjectResponse

@dataclass
class ProjectOperationResponse_project(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ProjectOperationResponse_projectMember1, ProjectResponse
    """
    # Composed type representation for type ProjectOperationResponse_projectMember1
    project_operation_response_project_member1: Optional[ProjectOperationResponse_projectMember1] = None
    # Composed type representation for type ProjectResponse
    project_response: Optional[ProjectResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectOperationResponse_project:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectOperationResponse_project
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ProjectOperationResponse_project()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .project_operation_response_project_member1 import ProjectOperationResponse_projectMember1

            result.project_operation_response_project_member1 = ProjectOperationResponse_projectMember1()
        elif mapping_value and mapping_value.casefold() == "ProjectResponse".casefold():
            from .project_response import ProjectResponse

            result.project_response = ProjectResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .project_operation_response_project_member1 import ProjectOperationResponse_projectMember1
        from .project_response import ProjectResponse

        if self.project_operation_response_project_member1:
            return self.project_operation_response_project_member1.get_field_deserializers()
        if self.project_response:
            return self.project_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.project_operation_response_project_member1:
            writer.write_object_value(None, self.project_operation_response_project_member1)
        elif self.project_response:
            writer.write_object_value(None, self.project_response)
    

