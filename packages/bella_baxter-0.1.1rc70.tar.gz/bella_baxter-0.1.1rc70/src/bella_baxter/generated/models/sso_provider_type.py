from enum import Enum

class SsoProviderType(str, Enum):
    Saml = "Saml",
    Oidc = "Oidc",

