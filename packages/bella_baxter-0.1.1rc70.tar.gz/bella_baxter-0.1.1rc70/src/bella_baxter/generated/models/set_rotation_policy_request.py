from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .set_rotation_policy_request_rotation_credentials import SetRotationPolicyRequest_rotationCredentials
    from .set_rotation_policy_request_static_params import SetRotationPolicyRequest_staticParams

@dataclass
class SetRotationPolicyRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The enabled property
    enabled: Optional[bool] = None
    # The intervalDays property
    interval_days: Optional[int] = None
    # The revokePreviousAfterDays property
    revoke_previous_after_days: Optional[int] = None
    # The rotationCredentials property
    rotation_credentials: Optional[SetRotationPolicyRequest_rotationCredentials] = None
    # The rotatorDefinitionId property
    rotator_definition_id: Optional[str] = None
    # The staticParams property
    static_params: Optional[SetRotationPolicyRequest_staticParams] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SetRotationPolicyRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SetRotationPolicyRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SetRotationPolicyRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .set_rotation_policy_request_rotation_credentials import SetRotationPolicyRequest_rotationCredentials
        from .set_rotation_policy_request_static_params import SetRotationPolicyRequest_staticParams

        from .set_rotation_policy_request_rotation_credentials import SetRotationPolicyRequest_rotationCredentials
        from .set_rotation_policy_request_static_params import SetRotationPolicyRequest_staticParams

        fields: dict[str, Callable[[Any], None]] = {
            "enabled": lambda n : setattr(self, 'enabled', n.get_bool_value()),
            "intervalDays": lambda n : setattr(self, 'interval_days', n.get_int_value()),
            "revokePreviousAfterDays": lambda n : setattr(self, 'revoke_previous_after_days', n.get_int_value()),
            "rotationCredentials": lambda n : setattr(self, 'rotation_credentials', n.get_object_value(SetRotationPolicyRequest_rotationCredentials)),
            "rotatorDefinitionId": lambda n : setattr(self, 'rotator_definition_id', n.get_str_value()),
            "staticParams": lambda n : setattr(self, 'static_params', n.get_object_value(SetRotationPolicyRequest_staticParams)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("enabled", self.enabled)
        writer.write_int_value("intervalDays", self.interval_days)
        writer.write_int_value("revokePreviousAfterDays", self.revoke_previous_after_days)
        writer.write_object_value("rotationCredentials", self.rotation_credentials)
        writer.write_str_value("rotatorDefinitionId", self.rotator_definition_id)
        writer.write_object_value("staticParams", self.static_params)
        writer.write_additional_data_value(self.additional_data)
    

