from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .provider_operation_response_provider_member1 import ProviderOperationResponse_providerMember1
    from .provider_response import ProviderResponse

@dataclass
class ProviderOperationResponse_provider(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ProviderOperationResponse_providerMember1, ProviderResponse
    """
    # Composed type representation for type ProviderOperationResponse_providerMember1
    provider_operation_response_provider_member1: Optional[ProviderOperationResponse_providerMember1] = None
    # Composed type representation for type ProviderResponse
    provider_response: Optional[ProviderResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProviderOperationResponse_provider:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProviderOperationResponse_provider
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ProviderOperationResponse_provider()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .provider_operation_response_provider_member1 import ProviderOperationResponse_providerMember1

            result.provider_operation_response_provider_member1 = ProviderOperationResponse_providerMember1()
        elif mapping_value and mapping_value.casefold() == "ProviderResponse".casefold():
            from .provider_response import ProviderResponse

            result.provider_response = ProviderResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .provider_operation_response_provider_member1 import ProviderOperationResponse_providerMember1
        from .provider_response import ProviderResponse

        if self.provider_operation_response_provider_member1:
            return self.provider_operation_response_provider_member1.get_field_deserializers()
        if self.provider_response:
            return self.provider_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.provider_operation_response_provider_member1:
            writer.write_object_value(None, self.provider_operation_response_provider_member1)
        elif self.provider_response:
            writer.write_object_value(None, self.provider_response)
    

