from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ProjectEncryptionKeyStatusResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The hasProjectDek property
    has_project_dek: Optional[bool] = None
    # The hasTenantDek property
    has_tenant_dek: Optional[bool] = None
    # The lastKeyEventAt property
    last_key_event_at: Optional[datetime.datetime] = None
    # The tenantEncryptionEnabled property
    tenant_encryption_enabled: Optional[bool] = None
    # The usingFallback property
    using_fallback: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectEncryptionKeyStatusResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectEncryptionKeyStatusResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectEncryptionKeyStatusResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "hasProjectDek": lambda n : setattr(self, 'has_project_dek', n.get_bool_value()),
            "hasTenantDek": lambda n : setattr(self, 'has_tenant_dek', n.get_bool_value()),
            "lastKeyEventAt": lambda n : setattr(self, 'last_key_event_at', n.get_datetime_value()),
            "tenantEncryptionEnabled": lambda n : setattr(self, 'tenant_encryption_enabled', n.get_bool_value()),
            "usingFallback": lambda n : setattr(self, 'using_fallback', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("hasProjectDek", self.has_project_dek)
        writer.write_bool_value("hasTenantDek", self.has_tenant_dek)
        writer.write_datetime_value("lastKeyEventAt", self.last_key_event_at)
        writer.write_bool_value("tenantEncryptionEnabled", self.tenant_encryption_enabled)
        writer.write_bool_value("usingFallback", self.using_fallback)
        writer.write_additional_data_value(self.additional_data)
    

