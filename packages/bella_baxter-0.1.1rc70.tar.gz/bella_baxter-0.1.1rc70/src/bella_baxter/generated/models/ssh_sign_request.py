from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SshSignRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The publicKey property
    public_key: Optional[str] = None
    # The roleName property
    role_name: Optional[str] = None
    # The ttl property
    ttl: Optional[str] = None
    # The validPrincipals property
    valid_principals: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SshSignRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SshSignRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SshSignRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "publicKey": lambda n : setattr(self, 'public_key', n.get_str_value()),
            "roleName": lambda n : setattr(self, 'role_name', n.get_str_value()),
            "ttl": lambda n : setattr(self, 'ttl', n.get_str_value()),
            "validPrincipals": lambda n : setattr(self, 'valid_principals', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("publicKey", self.public_key)
        writer.write_str_value("roleName", self.role_name)
        writer.write_str_value("ttl", self.ttl)
        writer.write_str_value("validPrincipals", self.valid_principals)
        writer.write_additional_data_value(self.additional_data)
    

