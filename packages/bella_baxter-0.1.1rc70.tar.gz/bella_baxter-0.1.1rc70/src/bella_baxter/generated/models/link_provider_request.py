from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class LinkProviderRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The autoRotateDays property
    auto_rotate_days: Optional[int] = None
    # The environmentId property
    environment_id: Optional[UUID] = None
    # The keyName property
    key_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinkProviderRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinkProviderRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinkProviderRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "autoRotateDays": lambda n : setattr(self, 'auto_rotate_days', n.get_int_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_uuid_value()),
            "keyName": lambda n : setattr(self, 'key_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("autoRotateDays", self.auto_rotate_days)
        writer.write_uuid_value("environmentId", self.environment_id)
        writer.write_str_value("keyName", self.key_name)
        writer.write_additional_data_value(self.additional_data)
    

