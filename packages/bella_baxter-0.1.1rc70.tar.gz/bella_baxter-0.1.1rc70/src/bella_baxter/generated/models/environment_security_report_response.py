from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .security_insight_response import SecurityInsightResponse
    from .security_report_summary import SecurityReportSummary

@dataclass
class EnvironmentSecurityReportResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The breachCheckSkipped property
    breach_check_skipped: Optional[bool] = None
    # The environmentId property
    environment_id: Optional[UUID] = None
    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The insights property
    insights: Optional[list[SecurityInsightResponse]] = None
    # The notYetScanned property
    not_yet_scanned: Optional[bool] = None
    # The overallRisk property
    overall_risk: Optional[str] = None
    # The projectId property
    project_id: Optional[UUID] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    # The providerFetchFailed property
    provider_fetch_failed: Optional[bool] = None
    # The scannedAt property
    scanned_at: Optional[datetime.datetime] = None
    # The summary property
    summary: Optional[SecurityReportSummary] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentSecurityReportResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentSecurityReportResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentSecurityReportResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .security_insight_response import SecurityInsightResponse
        from .security_report_summary import SecurityReportSummary

        from .security_insight_response import SecurityInsightResponse
        from .security_report_summary import SecurityReportSummary

        fields: dict[str, Callable[[Any], None]] = {
            "breachCheckSkipped": lambda n : setattr(self, 'breach_check_skipped', n.get_bool_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_uuid_value()),
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "insights": lambda n : setattr(self, 'insights', n.get_collection_of_object_values(SecurityInsightResponse)),
            "notYetScanned": lambda n : setattr(self, 'not_yet_scanned', n.get_bool_value()),
            "overallRisk": lambda n : setattr(self, 'overall_risk', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_uuid_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
            "providerFetchFailed": lambda n : setattr(self, 'provider_fetch_failed', n.get_bool_value()),
            "scannedAt": lambda n : setattr(self, 'scanned_at', n.get_datetime_value()),
            "summary": lambda n : setattr(self, 'summary', n.get_object_value(SecurityReportSummary)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("breachCheckSkipped", self.breach_check_skipped)
        writer.write_uuid_value("environmentId", self.environment_id)
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_collection_of_object_values("insights", self.insights)
        writer.write_bool_value("notYetScanned", self.not_yet_scanned)
        writer.write_str_value("overallRisk", self.overall_risk)
        writer.write_uuid_value("projectId", self.project_id)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_bool_value("providerFetchFailed", self.provider_fetch_failed)
        writer.write_datetime_value("scannedAt", self.scanned_at)
        writer.write_object_value("summary", self.summary)
        writer.write_additional_data_value(self.additional_data)
    

