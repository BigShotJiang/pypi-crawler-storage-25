from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DriftSummary(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The driftedKeys property
    drifted_keys: Optional[int] = None
    # The envSpecificKeys property
    env_specific_keys: Optional[int] = None
    # The globalKeys property
    global_keys: Optional[int] = None
    # The totalKeys property
    total_keys: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DriftSummary:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DriftSummary
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DriftSummary()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "driftedKeys": lambda n : setattr(self, 'drifted_keys', n.get_int_value()),
            "envSpecificKeys": lambda n : setattr(self, 'env_specific_keys', n.get_int_value()),
            "globalKeys": lambda n : setattr(self, 'global_keys', n.get_int_value()),
            "totalKeys": lambda n : setattr(self, 'total_keys', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("driftedKeys", self.drifted_keys)
        writer.write_int_value("envSpecificKeys", self.env_specific_keys)
        writer.write_int_value("globalKeys", self.global_keys)
        writer.write_int_value("totalKeys", self.total_keys)
        writer.write_additional_data_value(self.additional_data)
    

