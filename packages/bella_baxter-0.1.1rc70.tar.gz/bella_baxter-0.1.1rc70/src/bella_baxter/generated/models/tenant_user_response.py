from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class TenantUserResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The email property
    email: Optional[str] = None
    # The fullName property
    full_name: Optional[str] = None
    # The joinedAt property
    joined_at: Optional[datetime.datetime] = None
    # The membershipId property
    membership_id: Optional[str] = None
    # The role property
    role: Optional[str] = None
    # The status property
    status: Optional[str] = None
    # The userId property
    user_id: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TenantUserResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TenantUserResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TenantUserResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "email": lambda n : setattr(self, 'email', n.get_str_value()),
            "fullName": lambda n : setattr(self, 'full_name', n.get_str_value()),
            "joinedAt": lambda n : setattr(self, 'joined_at', n.get_datetime_value()),
            "membershipId": lambda n : setattr(self, 'membership_id', n.get_str_value()),
            "role": lambda n : setattr(self, 'role', n.get_str_value()),
            "status": lambda n : setattr(self, 'status', n.get_str_value()),
            "userId": lambda n : setattr(self, 'user_id', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("email", self.email)
        writer.write_str_value("fullName", self.full_name)
        writer.write_datetime_value("joinedAt", self.joined_at)
        writer.write_str_value("membershipId", self.membership_id)
        writer.write_str_value("role", self.role)
        writer.write_str_value("status", self.status)
        writer.write_str_value("userId", self.user_id)
        writer.write_additional_data_value(self.additional_data)
    

