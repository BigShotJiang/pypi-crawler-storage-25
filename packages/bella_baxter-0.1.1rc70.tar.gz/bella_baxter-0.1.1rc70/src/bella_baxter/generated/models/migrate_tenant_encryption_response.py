from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class MigrateTenantEncryptionResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environmentsProcessed property
    environments_processed: Optional[int] = None
    # The message property
    message: Optional[str] = None
    # The notificationsEncrypted property
    notifications_encrypted: Optional[int] = None
    # The projectsProcessed property
    projects_processed: Optional[int] = None
    # The providersEncrypted property
    providers_encrypted: Optional[int] = None
    # The secretsEncrypted property
    secrets_encrypted: Optional[int] = None
    # The secretsSkipped property
    secrets_skipped: Optional[int] = None
    # The success property
    success: Optional[bool] = None
    # The webhooksEncrypted property
    webhooks_encrypted: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> MigrateTenantEncryptionResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: MigrateTenantEncryptionResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return MigrateTenantEncryptionResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "environmentsProcessed": lambda n : setattr(self, 'environments_processed', n.get_int_value()),
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "notificationsEncrypted": lambda n : setattr(self, 'notifications_encrypted', n.get_int_value()),
            "projectsProcessed": lambda n : setattr(self, 'projects_processed', n.get_int_value()),
            "providersEncrypted": lambda n : setattr(self, 'providers_encrypted', n.get_int_value()),
            "secretsEncrypted": lambda n : setattr(self, 'secrets_encrypted', n.get_int_value()),
            "secretsSkipped": lambda n : setattr(self, 'secrets_skipped', n.get_int_value()),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
            "webhooksEncrypted": lambda n : setattr(self, 'webhooks_encrypted', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("environmentsProcessed", self.environments_processed)
        writer.write_str_value("message", self.message)
        writer.write_int_value("notificationsEncrypted", self.notifications_encrypted)
        writer.write_int_value("projectsProcessed", self.projects_processed)
        writer.write_int_value("providersEncrypted", self.providers_encrypted)
        writer.write_int_value("secretsEncrypted", self.secrets_encrypted)
        writer.write_int_value("secretsSkipped", self.secrets_skipped)
        writer.write_bool_value("success", self.success)
        writer.write_int_value("webhooksEncrypted", self.webhooks_encrypted)
        writer.write_additional_data_value(self.additional_data)
    

