from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class WebhookResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The autoRotateDays property
    auto_rotate_days: Optional[int] = None
    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The createdBy property
    created_by: Optional[str] = None
    # The environmentId property
    environment_id: Optional[str] = None
    # The eventTypes property
    event_types: Optional[list[str]] = None
    # The id property
    id: Optional[str] = None
    # The isActive property
    is_active: Optional[bool] = None
    # The keyPrefix property
    key_prefix: Optional[str] = None
    # The linkedEnvironmentId property
    linked_environment_id: Optional[UUID] = None
    # The linkedKeyName property
    linked_key_name: Optional[str] = None
    # The name property
    name: Optional[str] = None
    # The nextRotationAt property
    next_rotation_at: Optional[datetime.datetime] = None
    # The projectId property
    project_id: Optional[str] = None
    # The targetUrl property
    target_url: Optional[str] = None
    # The updatedAt property
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WebhookResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WebhookResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WebhookResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "autoRotateDays": lambda n : setattr(self, 'auto_rotate_days', n.get_int_value()),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "createdBy": lambda n : setattr(self, 'created_by', n.get_str_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_str_value()),
            "eventTypes": lambda n : setattr(self, 'event_types', n.get_collection_of_primitive_values(str)),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "isActive": lambda n : setattr(self, 'is_active', n.get_bool_value()),
            "keyPrefix": lambda n : setattr(self, 'key_prefix', n.get_str_value()),
            "linkedEnvironmentId": lambda n : setattr(self, 'linked_environment_id', n.get_uuid_value()),
            "linkedKeyName": lambda n : setattr(self, 'linked_key_name', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "nextRotationAt": lambda n : setattr(self, 'next_rotation_at', n.get_datetime_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_str_value()),
            "targetUrl": lambda n : setattr(self, 'target_url', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("autoRotateDays", self.auto_rotate_days)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("createdBy", self.created_by)
        writer.write_str_value("environmentId", self.environment_id)
        writer.write_collection_of_primitive_values("eventTypes", self.event_types)
        writer.write_str_value("id", self.id)
        writer.write_bool_value("isActive", self.is_active)
        writer.write_str_value("keyPrefix", self.key_prefix)
        writer.write_uuid_value("linkedEnvironmentId", self.linked_environment_id)
        writer.write_str_value("linkedKeyName", self.linked_key_name)
        writer.write_str_value("name", self.name)
        writer.write_datetime_value("nextRotationAt", self.next_rotation_at)
        writer.write_str_value("projectId", self.project_id)
        writer.write_str_value("targetUrl", self.target_url)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_additional_data_value(self.additional_data)
    

