from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class IssueEnvironmentTokenRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The reason property
    reason: Optional[str] = None
    # The scopes property
    scopes: Optional[list[str]] = None
    # The ttlMinutes property
    ttl_minutes: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> IssueEnvironmentTokenRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: IssueEnvironmentTokenRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return IssueEnvironmentTokenRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "reason": lambda n : setattr(self, 'reason', n.get_str_value()),
            "scopes": lambda n : setattr(self, 'scopes', n.get_collection_of_primitive_values(str)),
            "ttlMinutes": lambda n : setattr(self, 'ttl_minutes', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("reason", self.reason)
        writer.write_collection_of_primitive_values("scopes", self.scopes)
        writer.write_int_value("ttlMinutes", self.ttl_minutes)
        writer.write_additional_data_value(self.additional_data)
    

