from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .claim_rule import ClaimRule

@dataclass
class TrustDomainResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The claimRules property
    claim_rules: Optional[list[ClaimRule]] = None
    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The description property
    description: Optional[str] = None
    # The environmentId property
    environment_id: Optional[UUID] = None
    # The grantedRole property
    granted_role: Optional[str] = None
    # The id property
    id: Optional[UUID] = None
    # The isEnabled property
    is_enabled: Optional[bool] = None
    # The issuedTokenTtlMinutes property
    issued_token_ttl_minutes: Optional[int] = None
    # The name property
    name: Optional[str] = None
    # The oidcIssuerUrl property
    oidc_issuer_url: Optional[str] = None
    # The oidcJwksUri property
    oidc_jwks_uri: Optional[str] = None
    # The updatedAt property
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TrustDomainResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TrustDomainResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TrustDomainResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .claim_rule import ClaimRule

        from .claim_rule import ClaimRule

        fields: dict[str, Callable[[Any], None]] = {
            "claimRules": lambda n : setattr(self, 'claim_rules', n.get_collection_of_object_values(ClaimRule)),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_uuid_value()),
            "grantedRole": lambda n : setattr(self, 'granted_role', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "isEnabled": lambda n : setattr(self, 'is_enabled', n.get_bool_value()),
            "issuedTokenTtlMinutes": lambda n : setattr(self, 'issued_token_ttl_minutes', n.get_int_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "oidcIssuerUrl": lambda n : setattr(self, 'oidc_issuer_url', n.get_str_value()),
            "oidcJwksUri": lambda n : setattr(self, 'oidc_jwks_uri', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("claimRules", self.claim_rules)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("description", self.description)
        writer.write_uuid_value("environmentId", self.environment_id)
        writer.write_str_value("grantedRole", self.granted_role)
        writer.write_uuid_value("id", self.id)
        writer.write_bool_value("isEnabled", self.is_enabled)
        writer.write_int_value("issuedTokenTtlMinutes", self.issued_token_ttl_minutes)
        writer.write_str_value("name", self.name)
        writer.write_str_value("oidcIssuerUrl", self.oidc_issuer_url)
        writer.write_str_value("oidcJwksUri", self.oidc_jwks_uri)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_additional_data_value(self.additional_data)
    

