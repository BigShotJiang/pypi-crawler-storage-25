from enum import Enum

class TenantInviteRole(str, Enum):
    Admin = "Admin",
    User = "User",
    Viewer = "Viewer",

