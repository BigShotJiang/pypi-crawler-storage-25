from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .sort_object import SortObject

@dataclass
class PageableObject(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The offset property
    offset: Optional[int] = None
    # The pageNumber property
    page_number: Optional[int] = None
    # The pageSize property
    page_size: Optional[int] = None
    # The paged property
    paged: Optional[bool] = None
    # The sort property
    sort: Optional[SortObject] = None
    # The unpaged property
    unpaged: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PageableObject:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PageableObject
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PageableObject()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .sort_object import SortObject

        from .sort_object import SortObject

        fields: dict[str, Callable[[Any], None]] = {
            "offset": lambda n : setattr(self, 'offset', n.get_int_value()),
            "pageNumber": lambda n : setattr(self, 'page_number', n.get_int_value()),
            "pageSize": lambda n : setattr(self, 'page_size', n.get_int_value()),
            "paged": lambda n : setattr(self, 'paged', n.get_bool_value()),
            "sort": lambda n : setattr(self, 'sort', n.get_object_value(SortObject)),
            "unpaged": lambda n : setattr(self, 'unpaged', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("offset", self.offset)
        writer.write_int_value("pageNumber", self.page_number)
        writer.write_int_value("pageSize", self.page_size)
        writer.write_bool_value("paged", self.paged)
        writer.write_object_value("sort", self.sort)
        writer.write_bool_value("unpaged", self.unpaged)
        writer.write_additional_data_value(self.additional_data)
    

