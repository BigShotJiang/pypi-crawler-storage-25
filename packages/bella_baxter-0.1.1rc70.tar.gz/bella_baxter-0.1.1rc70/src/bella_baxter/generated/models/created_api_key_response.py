from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class CreatedApiKeyResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The apiKey property
    api_key: Optional[str] = None
    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The id property
    id: Optional[str] = None
    # The keyPrefix property
    key_prefix: Optional[str] = None
    # The message property
    message: Optional[str] = None
    # The success property
    success: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreatedApiKeyResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreatedApiKeyResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CreatedApiKeyResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "apiKey": lambda n : setattr(self, 'api_key', n.get_str_value()),
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "keyPrefix": lambda n : setattr(self, 'key_prefix', n.get_str_value()),
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("apiKey", self.api_key)
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_str_value("id", self.id)
        writer.write_str_value("keyPrefix", self.key_prefix)
        writer.write_str_value("message", self.message)
        writer.write_bool_value("success", self.success)
        writer.write_additional_data_value(self.additional_data)
    

