from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PkiIssuedCertificateResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The caChain property
    ca_chain: Optional[list[str]] = None
    # The certificate property
    certificate: Optional[str] = None
    # The expiration property
    expiration: Optional[int] = None
    # The instructions property
    instructions: Optional[str] = None
    # The issuingCa property
    issuing_ca: Optional[str] = None
    # The privateKey property
    private_key: Optional[str] = None
    # The privateKeyType property
    private_key_type: Optional[str] = None
    # The serialNumber property
    serial_number: Optional[str] = None
    # The success property
    success: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PkiIssuedCertificateResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PkiIssuedCertificateResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PkiIssuedCertificateResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "caChain": lambda n : setattr(self, 'ca_chain', n.get_collection_of_primitive_values(str)),
            "certificate": lambda n : setattr(self, 'certificate', n.get_str_value()),
            "expiration": lambda n : setattr(self, 'expiration', n.get_int_value()),
            "instructions": lambda n : setattr(self, 'instructions', n.get_str_value()),
            "issuingCa": lambda n : setattr(self, 'issuing_ca', n.get_str_value()),
            "privateKey": lambda n : setattr(self, 'private_key', n.get_str_value()),
            "privateKeyType": lambda n : setattr(self, 'private_key_type', n.get_str_value()),
            "serialNumber": lambda n : setattr(self, 'serial_number', n.get_str_value()),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("caChain", self.ca_chain)
        writer.write_str_value("certificate", self.certificate)
        writer.write_int_value("expiration", self.expiration)
        writer.write_str_value("instructions", self.instructions)
        writer.write_str_value("issuingCa", self.issuing_ca)
        writer.write_str_value("privateKey", self.private_key)
        writer.write_str_value("privateKeyType", self.private_key_type)
        writer.write_str_value("serialNumber", self.serial_number)
        writer.write_bool_value("success", self.success)
        writer.write_additional_data_value(self.additional_data)
    

