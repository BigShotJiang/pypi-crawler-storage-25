from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PkiCreateRoleRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The defaultTtl property
    default_ttl: Optional[str] = "720h"
    # The keyType property
    key_type: Optional[str] = "rsa"
    # The maxTtl property
    max_ttl: Optional[str] = "8760h"
    # The allowAnyName property
    allow_any_name: Optional[bool] = None
    # The allowLocalhost property
    allow_localhost: Optional[bool] = None
    # The allowSubdomains property
    allow_subdomains: Optional[bool] = None
    # The allowedDomains property
    allowed_domains: Optional[str] = None
    # The keyBits property
    key_bits: Optional[int] = None
    # The name property
    name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PkiCreateRoleRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PkiCreateRoleRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PkiCreateRoleRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "allowAnyName": lambda n : setattr(self, 'allow_any_name', n.get_bool_value()),
            "allowLocalhost": lambda n : setattr(self, 'allow_localhost', n.get_bool_value()),
            "allowSubdomains": lambda n : setattr(self, 'allow_subdomains', n.get_bool_value()),
            "allowedDomains": lambda n : setattr(self, 'allowed_domains', n.get_str_value()),
            "defaultTtl": lambda n : setattr(self, 'default_ttl', n.get_str_value()),
            "keyBits": lambda n : setattr(self, 'key_bits', n.get_int_value()),
            "keyType": lambda n : setattr(self, 'key_type', n.get_str_value()),
            "maxTtl": lambda n : setattr(self, 'max_ttl', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("allowAnyName", self.allow_any_name)
        writer.write_bool_value("allowLocalhost", self.allow_localhost)
        writer.write_bool_value("allowSubdomains", self.allow_subdomains)
        writer.write_str_value("allowedDomains", self.allowed_domains)
        writer.write_str_value("defaultTtl", self.default_ttl)
        writer.write_int_value("keyBits", self.key_bits)
        writer.write_str_value("keyType", self.key_type)
        writer.write_str_value("maxTtl", self.max_ttl)
        writer.write_str_value("name", self.name)
        writer.write_additional_data_value(self.additional_data)
    

