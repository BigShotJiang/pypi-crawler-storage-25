from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class TenantUsageResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The currentMonth property
    current_month: Optional[str] = None
    # The estimatedOverageCost property
    estimated_overage_cost: Optional[float] = None
    # The freeMonthlyQuota property
    free_monthly_quota: Optional[int] = None
    # The hasActiveSubscription property
    has_active_subscription: Optional[bool] = None
    # The isOperatorManaged property
    is_operator_managed: Optional[bool] = None
    # The isUnlimited property
    is_unlimited: Optional[bool] = None
    # The overageRatePerRequest property
    overage_rate_per_request: Optional[float] = None
    # The plan property
    plan: Optional[str] = None
    # The requestsRemaining property
    requests_remaining: Optional[int] = None
    # The requestsUsed property
    requests_used: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TenantUsageResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TenantUsageResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TenantUsageResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "currentMonth": lambda n : setattr(self, 'current_month', n.get_str_value()),
            "estimatedOverageCost": lambda n : setattr(self, 'estimated_overage_cost', n.get_float_value()),
            "freeMonthlyQuota": lambda n : setattr(self, 'free_monthly_quota', n.get_int_value()),
            "hasActiveSubscription": lambda n : setattr(self, 'has_active_subscription', n.get_bool_value()),
            "isOperatorManaged": lambda n : setattr(self, 'is_operator_managed', n.get_bool_value()),
            "isUnlimited": lambda n : setattr(self, 'is_unlimited', n.get_bool_value()),
            "overageRatePerRequest": lambda n : setattr(self, 'overage_rate_per_request', n.get_float_value()),
            "plan": lambda n : setattr(self, 'plan', n.get_str_value()),
            "requestsRemaining": lambda n : setattr(self, 'requests_remaining', n.get_int_value()),
            "requestsUsed": lambda n : setattr(self, 'requests_used', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("currentMonth", self.current_month)
        writer.write_float_value("estimatedOverageCost", self.estimated_overage_cost)
        writer.write_int_value("freeMonthlyQuota", self.free_monthly_quota)
        writer.write_bool_value("hasActiveSubscription", self.has_active_subscription)
        writer.write_bool_value("isOperatorManaged", self.is_operator_managed)
        writer.write_bool_value("isUnlimited", self.is_unlimited)
        writer.write_float_value("overageRatePerRequest", self.overage_rate_per_request)
        writer.write_str_value("plan", self.plan)
        writer.write_int_value("requestsRemaining", self.requests_remaining)
        writer.write_int_value("requestsUsed", self.requests_used)
        writer.write_additional_data_value(self.additional_data)
    

