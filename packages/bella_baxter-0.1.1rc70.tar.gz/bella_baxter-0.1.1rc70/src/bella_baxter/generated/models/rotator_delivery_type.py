from enum import Enum

class RotatorDeliveryType(str, Enum):
    Internal = "Internal",
    HttpWebhook = "HttpWebhook",

