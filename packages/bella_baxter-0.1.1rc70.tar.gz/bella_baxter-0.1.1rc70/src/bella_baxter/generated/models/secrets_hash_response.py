from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SecretsHashResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The computedAt property
    computed_at: Optional[datetime.datetime] = None
    # The hash property
    hash: Optional[str] = None
    # The secretCount property
    secret_count: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SecretsHashResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SecretsHashResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SecretsHashResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "computedAt": lambda n : setattr(self, 'computed_at', n.get_datetime_value()),
            "hash": lambda n : setattr(self, 'hash', n.get_str_value()),
            "secretCount": lambda n : setattr(self, 'secret_count', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("computedAt", self.computed_at)
        writer.write_str_value("hash", self.hash)
        writer.write_int_value("secretCount", self.secret_count)
        writer.write_additional_data_value(self.additional_data)
    

