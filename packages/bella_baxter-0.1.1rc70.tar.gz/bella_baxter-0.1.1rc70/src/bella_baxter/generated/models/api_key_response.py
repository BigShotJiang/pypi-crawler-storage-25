from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ApiKeyResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The allowedScopes property
    allowed_scopes: Optional[list[str]] = None
    # The clientName property
    client_name: Optional[str] = None
    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The description property
    description: Optional[str] = None
    # The environmentId property
    environment_id: Optional[str] = None
    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The id property
    id: Optional[str] = None
    # The isActive property
    is_active: Optional[bool] = None
    # The isExpired property
    is_expired: Optional[bool] = None
    # The isValid property
    is_valid: Optional[bool] = None
    # The keyPrefix property
    key_prefix: Optional[str] = None
    # The lastUsedAt property
    last_used_at: Optional[datetime.datetime] = None
    # The projectId property
    project_id: Optional[str] = None
    # The revokedAt property
    revoked_at: Optional[datetime.datetime] = None
    # The role property
    role: Optional[str] = None
    # The usageCount property
    usage_count: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ApiKeyResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ApiKeyResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ApiKeyResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "allowedScopes": lambda n : setattr(self, 'allowed_scopes', n.get_collection_of_primitive_values(str)),
            "clientName": lambda n : setattr(self, 'client_name', n.get_str_value()),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_str_value()),
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "isActive": lambda n : setattr(self, 'is_active', n.get_bool_value()),
            "isExpired": lambda n : setattr(self, 'is_expired', n.get_bool_value()),
            "isValid": lambda n : setattr(self, 'is_valid', n.get_bool_value()),
            "keyPrefix": lambda n : setattr(self, 'key_prefix', n.get_str_value()),
            "lastUsedAt": lambda n : setattr(self, 'last_used_at', n.get_datetime_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_str_value()),
            "revokedAt": lambda n : setattr(self, 'revoked_at', n.get_datetime_value()),
            "role": lambda n : setattr(self, 'role', n.get_str_value()),
            "usageCount": lambda n : setattr(self, 'usage_count', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("allowedScopes", self.allowed_scopes)
        writer.write_str_value("clientName", self.client_name)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("description", self.description)
        writer.write_str_value("environmentId", self.environment_id)
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_str_value("id", self.id)
        writer.write_bool_value("isActive", self.is_active)
        writer.write_bool_value("isExpired", self.is_expired)
        writer.write_bool_value("isValid", self.is_valid)
        writer.write_str_value("keyPrefix", self.key_prefix)
        writer.write_datetime_value("lastUsedAt", self.last_used_at)
        writer.write_str_value("projectId", self.project_id)
        writer.write_datetime_value("revokedAt", self.revoked_at)
        writer.write_str_value("role", self.role)
        writer.write_int_value("usageCount", self.usage_count)
        writer.write_additional_data_value(self.additional_data)
    

