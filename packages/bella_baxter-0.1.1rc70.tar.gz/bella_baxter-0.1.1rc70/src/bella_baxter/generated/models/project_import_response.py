from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class ProjectImportResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environmentsCreated property
    environments_created: Optional[int] = None
    # The message property
    message: Optional[str] = None
    # The projectId property
    project_id: Optional[UUID] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    # The providersMatched property
    providers_matched: Optional[int] = None
    # The success property
    success: Optional[bool] = None
    # The warnings property
    warnings: Optional[list[str]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectImportResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectImportResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectImportResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "environmentsCreated": lambda n : setattr(self, 'environments_created', n.get_int_value()),
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_uuid_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
            "providersMatched": lambda n : setattr(self, 'providers_matched', n.get_int_value()),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
            "warnings": lambda n : setattr(self, 'warnings', n.get_collection_of_primitive_values(str)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("environmentsCreated", self.environments_created)
        writer.write_str_value("message", self.message)
        writer.write_uuid_value("projectId", self.project_id)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_int_value("providersMatched", self.providers_matched)
        writer.write_bool_value("success", self.success)
        writer.write_collection_of_primitive_values("warnings", self.warnings)
        writer.write_additional_data_value(self.additional_data)
    

