from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class RotatorFieldDefDto(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The helpText property
    help_text: Optional[str] = None
    # The key property
    key: Optional[str] = None
    # The label property
    label: Optional[str] = None
    # The placeholder property
    placeholder: Optional[str] = None
    # The required property
    required: Optional[bool] = None
    # The type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RotatorFieldDefDto:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RotatorFieldDefDto
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RotatorFieldDefDto()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "helpText": lambda n : setattr(self, 'help_text', n.get_str_value()),
            "key": lambda n : setattr(self, 'key', n.get_str_value()),
            "label": lambda n : setattr(self, 'label', n.get_str_value()),
            "placeholder": lambda n : setattr(self, 'placeholder', n.get_str_value()),
            "required": lambda n : setattr(self, 'required', n.get_bool_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("helpText", self.help_text)
        writer.write_str_value("key", self.key)
        writer.write_str_value("label", self.label)
        writer.write_str_value("placeholder", self.placeholder)
        writer.write_bool_value("required", self.required)
        writer.write_str_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

