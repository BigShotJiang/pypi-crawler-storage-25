from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class BillingStatementResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The finalizedAt property
    finalized_at: Optional[datetime.datetime] = None
    # The freeQuota property
    free_quota: Optional[int] = None
    # The id property
    id: Optional[UUID] = None
    # The isFinalized property
    is_finalized: Optional[bool] = None
    # The lastUpdatedAt property
    last_updated_at: Optional[datetime.datetime] = None
    # The month property
    month: Optional[str] = None
    # The overageCost property
    overage_cost: Optional[float] = None
    # The overageRate property
    overage_rate: Optional[float] = None
    # The overageRequests property
    overage_requests: Optional[int] = None
    # The plan property
    plan: Optional[str] = None
    # The requestsUsed property
    requests_used: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> BillingStatementResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: BillingStatementResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return BillingStatementResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "finalizedAt": lambda n : setattr(self, 'finalized_at', n.get_datetime_value()),
            "freeQuota": lambda n : setattr(self, 'free_quota', n.get_int_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "isFinalized": lambda n : setattr(self, 'is_finalized', n.get_bool_value()),
            "lastUpdatedAt": lambda n : setattr(self, 'last_updated_at', n.get_datetime_value()),
            "month": lambda n : setattr(self, 'month', n.get_str_value()),
            "overageCost": lambda n : setattr(self, 'overage_cost', n.get_float_value()),
            "overageRate": lambda n : setattr(self, 'overage_rate', n.get_float_value()),
            "overageRequests": lambda n : setattr(self, 'overage_requests', n.get_int_value()),
            "plan": lambda n : setattr(self, 'plan', n.get_str_value()),
            "requestsUsed": lambda n : setattr(self, 'requests_used', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("finalizedAt", self.finalized_at)
        writer.write_int_value("freeQuota", self.free_quota)
        writer.write_uuid_value("id", self.id)
        writer.write_bool_value("isFinalized", self.is_finalized)
        writer.write_datetime_value("lastUpdatedAt", self.last_updated_at)
        writer.write_str_value("month", self.month)
        writer.write_float_value("overageCost", self.overage_cost)
        writer.write_float_value("overageRate", self.overage_rate)
        writer.write_int_value("overageRequests", self.overage_requests)
        writer.write_str_value("plan", self.plan)
        writer.write_int_value("requestsUsed", self.requests_used)
        writer.write_additional_data_value(self.additional_data)
    

