from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .provider_export_info_public_configuration import ProviderExportInfo_publicConfiguration

@dataclass
class ProviderExportInfo(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The description property
    description: Optional[str] = None
    # The name property
    name: Optional[str] = None
    # The publicConfiguration property
    public_configuration: Optional[ProviderExportInfo_publicConfiguration] = None
    # The slug property
    slug: Optional[str] = None
    # The source property
    source: Optional[str] = None
    # The type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProviderExportInfo:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProviderExportInfo
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProviderExportInfo()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .provider_export_info_public_configuration import ProviderExportInfo_publicConfiguration

        from .provider_export_info_public_configuration import ProviderExportInfo_publicConfiguration

        fields: dict[str, Callable[[Any], None]] = {
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "publicConfiguration": lambda n : setattr(self, 'public_configuration', n.get_object_value(ProviderExportInfo_publicConfiguration)),
            "slug": lambda n : setattr(self, 'slug', n.get_str_value()),
            "source": lambda n : setattr(self, 'source', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("description", self.description)
        writer.write_str_value("name", self.name)
        writer.write_object_value("publicConfiguration", self.public_configuration)
        writer.write_str_value("slug", self.slug)
        writer.write_str_value("source", self.source)
        writer.write_str_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

