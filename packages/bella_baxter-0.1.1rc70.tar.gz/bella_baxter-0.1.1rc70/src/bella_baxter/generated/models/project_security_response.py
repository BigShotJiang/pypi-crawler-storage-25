from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .environment_security_summary_entry import EnvironmentSecuritySummaryEntry
    from .project_security_response_global_secrets import ProjectSecurityResponse_globalSecrets

@dataclass
class ProjectSecurityResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environments property
    environments: Optional[list[EnvironmentSecuritySummaryEntry]] = None
    # The globalSecrets property
    global_secrets: Optional[ProjectSecurityResponse_globalSecrets] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectSecurityResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectSecurityResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectSecurityResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .environment_security_summary_entry import EnvironmentSecuritySummaryEntry
        from .project_security_response_global_secrets import ProjectSecurityResponse_globalSecrets

        from .environment_security_summary_entry import EnvironmentSecuritySummaryEntry
        from .project_security_response_global_secrets import ProjectSecurityResponse_globalSecrets

        fields: dict[str, Callable[[Any], None]] = {
            "environments": lambda n : setattr(self, 'environments', n.get_collection_of_object_values(EnvironmentSecuritySummaryEntry)),
            "globalSecrets": lambda n : setattr(self, 'global_secrets', n.get_object_value(ProjectSecurityResponse_globalSecrets)),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("environments", self.environments)
        writer.write_object_value("globalSecrets", self.global_secrets)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_additional_data_value(self.additional_data)
    

