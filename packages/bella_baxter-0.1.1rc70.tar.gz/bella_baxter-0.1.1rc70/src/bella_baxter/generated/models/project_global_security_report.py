from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .security_insight import SecurityInsight

@dataclass
class ProjectGlobalSecurityReport(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The breachCheckSkipped property
    breach_check_skipped: Optional[bool] = None
    # The critical property
    critical: Optional[int] = None
    # The high property
    high: Optional[int] = None
    # The insights property
    insights: Optional[list[SecurityInsight]] = None
    # The low property
    low: Optional[int] = None
    # The medium property
    medium: Optional[int] = None
    # The noProviderConfigured property
    no_provider_configured: Optional[bool] = None
    # The overallRisk property
    overall_risk: Optional[str] = None
    # The providerFetchFailed property
    provider_fetch_failed: Optional[bool] = None
    # The scannedAt property
    scanned_at: Optional[datetime.datetime] = None
    # The totalSecretsScanned property
    total_secrets_scanned: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectGlobalSecurityReport:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectGlobalSecurityReport
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectGlobalSecurityReport()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .security_insight import SecurityInsight

        from .security_insight import SecurityInsight

        fields: dict[str, Callable[[Any], None]] = {
            "breachCheckSkipped": lambda n : setattr(self, 'breach_check_skipped', n.get_bool_value()),
            "critical": lambda n : setattr(self, 'critical', n.get_int_value()),
            "high": lambda n : setattr(self, 'high', n.get_int_value()),
            "insights": lambda n : setattr(self, 'insights', n.get_collection_of_object_values(SecurityInsight)),
            "low": lambda n : setattr(self, 'low', n.get_int_value()),
            "medium": lambda n : setattr(self, 'medium', n.get_int_value()),
            "noProviderConfigured": lambda n : setattr(self, 'no_provider_configured', n.get_bool_value()),
            "overallRisk": lambda n : setattr(self, 'overall_risk', n.get_str_value()),
            "providerFetchFailed": lambda n : setattr(self, 'provider_fetch_failed', n.get_bool_value()),
            "scannedAt": lambda n : setattr(self, 'scanned_at', n.get_datetime_value()),
            "totalSecretsScanned": lambda n : setattr(self, 'total_secrets_scanned', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("breachCheckSkipped", self.breach_check_skipped)
        writer.write_int_value("critical", self.critical)
        writer.write_int_value("high", self.high)
        writer.write_collection_of_object_values("insights", self.insights)
        writer.write_int_value("low", self.low)
        writer.write_int_value("medium", self.medium)
        writer.write_bool_value("noProviderConfigured", self.no_provider_configured)
        writer.write_str_value("overallRisk", self.overall_risk)
        writer.write_bool_value("providerFetchFailed", self.provider_fetch_failed)
        writer.write_datetime_value("scannedAt", self.scanned_at)
        writer.write_int_value("totalSecretsScanned", self.total_secrets_scanned)
        writer.write_additional_data_value(self.additional_data)
    

