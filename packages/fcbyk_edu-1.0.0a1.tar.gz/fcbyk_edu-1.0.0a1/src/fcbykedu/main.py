from __future__ import annotations

import click

from .pick.cli import pick
from .slide.cli import slide


def register(cli: click.Group) -> str:
    cli.add_command(pick)
    cli.add_command(slide)
    return "pick、slide (教学工具)"
