# fcbyk-edu

`fcbyk-cli` 的教育工具插件，提供教学辅助功能。

安装 `fcbyk-edu` 后，会自动安装 `fcbyk-cli`，安装完成后即可使用 `byk pick` 和 `byk slide` 命令。

## 安装

```bash
pip install fcbyk-edu
```

## 功能模块

### Pick - 随机抽取工具

用于课堂随机点名或文件选择：

```bash
byk pick
```

指定端口：

```bash
byk pick -p 8080
```

启动文件模式（需指定目录）：

```bash
byk pick -f /path/to/files
```

设置管理员密码：

```bash
byk pick --password
```

后台运行：

```bash
byk pick -D
```

### Slide - PPT 远程控制

通过手机网页控制 PPT 翻页：

```bash
byk slide
```

指定端口：

```bash
byk slide -p 8080
```

后台运行：

```bash
byk slide -D
```

启动后会输出访问地址，用手机浏览器打开即可控制 PPT。

## 参数说明

### Pick 命令

- `-p, --port`：指定端口（默认 80）
- `-f, --files`：指定文件目录
- `--password`：设置管理员密码
- `-D, --daemon`：后台运行
- `--no-browser`：不自动打开浏览器

### Slide 命令

- `-p, --port`：指定端口（默认 80）
- `-D, --daemon`：后台运行

查看帮助：

```bash
byk pick -h
byk slide -h
```