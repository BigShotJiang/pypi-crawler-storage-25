import quadint.quad.int
import quadint.quad.rings.special
from quadint.quad.int import QuadInt as QuadInt
from quadint.quad.rings.base import QuadraticRing as QuadraticRing
from quadint.quad.rings.special import _ZE as _ZE
from typing import ClassVar as _ClassVar

class dualint(quadint.quad.int.QuadInt):
    """
    Represents a dual number with integer real and dual parts.

    Properties:
        real (int): The real component.
        dual (int): The dual or epsilon component.
    """
    SYMBOL: _ClassVar[str] = ...
    DEFAULT_RING: _ClassVar[quadint.quad.rings.special.DualRing] = ...
    @property
    def real(self):
        """Alias for dualint
        Alias for dualint"""
    @property
    def dual(self):
        """Alias for dualint
        Alias for dualint"""
    @property
    def epsilon(self):
        """Alias for dualint
        Alias for dualint"""
