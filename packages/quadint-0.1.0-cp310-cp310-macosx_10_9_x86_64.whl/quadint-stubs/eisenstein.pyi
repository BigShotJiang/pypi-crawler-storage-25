import quadint.quad.int
from quadint.quad.int import QuadInt as QuadInt
from quadint.quad.rings.base import QuadraticRing as QuadraticRing
from quadint.quad.rings.cornacchia import _ZW as _ZW
from typing import ClassVar

class eisensteinint(quadint.quad.int.QuadInt):
    """
    Represents an Eisenstein number with integer real and omega parts.

    Properties:
        real (int): The real component.
        omega (int): The omega component.
    """
    BASIS_TO_INTERNAL: ClassVar[tuple] = ...
    INTERNAL_TO_BASIS: ClassVar[tuple] = ...
    INTERNAL_TO_BASIS_DEN: ClassVar[int] = ...
    def __init__(self, a: int = ..., b: int = ..., ring: QuadraticRing | None = ...) -> None:
        """Initialize an eisensteinint instance."""
    @property
    def real(self):
        """Alias for eisensteinint
        Alias for eisensteinint"""
    @property
    def omega(self):
        """Alias for eisensteinint
        Alias for eisensteinint"""
