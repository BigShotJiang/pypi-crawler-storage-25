import typing
from typing import Iterable

P: typing.ParamSpec
R: typing.TypeVar
def requires_modules(modules: Iterable[str], *, message: str | None = ..., exc_type: type[Exception] = ...):
    """
    Decorator factory to require that at least one of the given modules is importable.

    Parameters
        modules:
            Iterable of module names to try importing, in order. If any import succeeds,
            the function is allowed to run.
        message:
            Error message to raise if none import. If omitted, a default is used.
        exc_type:
            Exception type to raise (default: ValueError), matching your existing pattern.

    Returns:
        The decorator.

    Raises:
        ValueError: If the modules list is empty.
    """
