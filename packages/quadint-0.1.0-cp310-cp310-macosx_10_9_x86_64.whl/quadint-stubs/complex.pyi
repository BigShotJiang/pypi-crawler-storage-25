import quadint.quad.int
import quadint.quad.rings.cornacchia
from quadint.quad.int import QuadInt as QuadInt
from quadint.quad.rings.base import QuadraticRing as QuadraticRing
from quadint.quad.rings.cornacchia import _ZI as _ZI
from typing import ClassVar as _ClassVar

class complexint(quadint.quad.int.QuadInt):
    """
    Represents a complex number with integer real and imaginary parts.

    Properties:
        real (int): The real component.
        imag (int): The imaginary component.
    """
    SYMBOL: _ClassVar[str] = ...
    DEFAULT_RING: _ClassVar[quadint.quad.rings.cornacchia.GaussianRing] = ...
    @property
    def real(self):
        """Alias for complexint
        Alias for complexint"""
    @property
    def imag(self):
        """Alias for complexint
        Alias for complexint"""
