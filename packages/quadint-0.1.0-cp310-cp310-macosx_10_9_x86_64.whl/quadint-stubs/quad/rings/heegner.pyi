import quadint.quad.rings.cornacchia
from quadint.quad.rings.cornacchia import CornacchiaRing as CornacchiaRing, EisensteinRing as EisensteinRing
from typing import ClassVar as _ClassVar

TYPE_CHECKING: bool

class HeegnerDen2Ring(quadint.quad.rings.cornacchia.EisensteinRing):
    """Shared split-prime factorization helper for D=-7 and D=-11 (den=2)."""
    SPLIT_K: _ClassVar[int] = ...
    def _is_split_prime(self, p: int) -> bool: ...
    def _is_inert_prime(self, p: int) -> bool: ...
    def _ramified_generator(self, x: QuadInt) -> QuadInt: ...
    def _decompose_prime(self, p: int) -> tuple[int, int]:
        """Return odd representatives of the two sqrt(D) roots modulo p."""
    def _split_generator(self, x: QuadInt, p: int) -> QuadInt: ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""

class HeegnerSevenRing(HeegnerDen2Ring):
    """Specialized factorization strategy for the maximal order with D=-7."""
    RAMIFIED_PRIME: _ClassVar[int] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""

class HeegnerElevenRing(HeegnerDen2Ring):
    """Specialized factorization strategy for the maximal order with D=-11."""
    RAMIFIED_PRIME: _ClassVar[int] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""

class HeegnerNonEuclidUfdRing(quadint.quad.rings.cornacchia.CornacchiaRing):
    """
    Factorization for imaginary quadratic maximal orders with class number 1 but *not* Euclidean.

    This covers the remaining Heegner (class number 1) fields beyond the norm-Euclidean ones:
        D in {-19, -43, -67, -163}   (all have default den=2)

    Key point:
      - We do NOT rely on divmod()/Euclidean division.
      - We generate split prime elements π with N(π)=p using Cornacchia-style integer work.
      - Then we strip valuations using exact_div (fast, and works even when supports_division()==False).
    """
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    SUPPORTS_FACTORIZATION: _ClassVar[bool] = ...
    HEEGNER_NON_EUCLID_D: _ClassVar[set] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Return True iff this ring override should be selected for (D, den)."""
    def divmod(self, x: QuadInt, y: QuadInt) -> tuple[QuadInt, QuadInt]:
        """This ring is not Euclidean; divmod is intentionally unavailable."""
    def _ramified_prime(self) -> int: ...
    def _is_split_prime(self, p: int) -> bool: ...
    def _is_inert_prime(self, p: int) -> bool: ...
    def _ramified_generator(self, x: QuadInt) -> QuadInt: ...
    def _inert_generator(self, x: QuadInt, p: int) -> QuadInt: ...
    def _decompose_prime(self, p: int) -> tuple[int, int]:
        '''
        Return (A,B) such that:
            A^2 - D*B^2 = 4p
        with A ≡ B (mod 2), so that π = (A + B*sqrt(D))/2 is in this maximal order and N(π)=p.

        We do this in two passes:

        1) "even-even" case: find x,y with p = x^2 + (-D)*y^2, then set (A,B)=(2x,2y).
           (This corresponds to elements that actually lie in the suborder Z[sqrt(D)].)

        2) "odd-odd" case: scan Euclidean remainders from (p, r) where r^2 ≡ D (mod p),
           and test b as a candidate A for 4p = b^2 + (-D)*B^2. This finds the genuinely den=2 generators.

        Returns:
            tuple: The decomposed prime.

        Raises:
            ValueError: If it is not possible to split the prime.
        '''
