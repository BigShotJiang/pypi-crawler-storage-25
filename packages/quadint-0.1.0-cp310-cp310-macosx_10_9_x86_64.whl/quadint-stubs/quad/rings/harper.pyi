import quadint.quad.rings.norm_euclid
from quadint.quad.rings.base import QuadraticRing as QuadraticRing, _NeighborhoodSearch as _NeighborhoodSearch, _round_div_ties_away_from_zero as _round_div_ties_away_from_zero
from quadint.quad.rings.norm_euclid import RealNormEuclidRing as RealNormEuclidRing
from quadint.utils import requires_modules as requires_modules
from typing import ClassVar as _ClassVar

TYPE_CHECKING: bool
def _is_squarefree(n: int) -> bool: ...

class Clark69Ring(quadint.quad.rings.norm_euclid.RealNormEuclidRing):
    '''
    Euclidean division for the maximal order of Q(sqrt(69)), i.e. Z[(1+sqrt(69))/2].

    This ring is Euclidean but not norm-Euclidean (Clark, 1994).

    A working Euclidean function can be taken as: |N(x)| with a single tweak that replaces each prime
        factor "23" in |N(x)| by "26". Equivalently: if v23(|N(x)|)=e then
        phi(x) = (|N(x)| / 23**e) * 26**e

    The obstruction to norm-Euclidean-ness lives entirely at the primes above 23;
        inflating 23->26 fixes Euclidean descent.
    '''
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    _BAD_P: _ClassVar[int] = ...
    _BAD_REPL: _ClassVar[int] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Supported for the maximal order for D=69 only"""
    @classmethod
    def _phi_from_abs_norm(cls, abs_norm: int) -> int:
        """Compute Clark's adjusted Euclidean function value from the integer |N(x)|."""
    def phi(self, x: QuadInt) -> int:
        """Return Clark's adjusted Euclidean function for the `D=69` maximal order."""
    def divmod(self, x: QuadInt, y: QuadInt) -> tuple[QuadInt, QuadInt]:
        """Divide `x` by `y` and return a Clark-admissible quotient and remainder."""

class HarperRing(quadint.quad.rings.norm_euclid.RealNormEuclidRing):
    """
    Harper-style Euclidean division for selected real quadratic maximal orders.

    This implementation uses admissible prime-pair witnesses to define a weighted
    Euclidean score `phi` and then performs a nearest-lattice quotient search.

    We can really only do the Harper-like method with cypari, and even then it requires care to
        test the witness speedup.

    Therefor without cypari, this will only work for the D values that have been hard-coded and validated.
    Even with cypari, the default behavior will be to tend towards accuracy, so division algorithms may be slow
        (or heck, untested or incorrect).
    """
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    _HARDCODED: _ClassVar[dict] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Read the above docstring and comments to understand the logic in this method."""
    def _find_admissible_witness_primes(self, *args, **kwargs) -> tuple[int, int, int, int] | None:
        """
        Search for a Harper-style admissible prime-ideal pair for the real quadratic field
        with discriminant `disc`, and return a *Harper-like* witness (small generators).

        Returns:
            None if not found within prime_bound.
            Otherwise (p1, i1, p2, i2) where:
              - p1, p2 are rational primes
              - i1 is the 1-based index of the chosen prime ideal in idealprimedec(nf,p1)
              - i2 is the 1-based index of the chosen prime ideal in idealprimedec(nf,p2)
        """
    def _principal_generator_from_witness_prime(self, *args, **kwargs) -> QuadInt:
        """
        Convert one PARI witness component (p, i) into a principal generator π of the
            chosen prime ideal P = idealprimedec(nf,p)[i], returned as a QuadInt.

        The result is only defined up to multiplication by a unit.

        Returns:
            QuadInt: The principal generator π.
        """
    def _principal_generators_from_witness(self, witness: tuple[int, int, int, int]) -> tuple[QuadInt, QuadInt]:
        """Convert a full admissible witness (p1,i1,p2,i2) into two prime generators."""
    def _phi_from_abs_norm(self, abs_norm: int, witness: tuple) -> int:
        """
        Weighted-norm score used as a Harper-style search heuristic.

        Start from |N(x)| and replace selected rational-prime factors p by p+1
            (based on an admissible-pair witness), analogous in spirit to Clark69's 23->26 trick.

        Returns:
            int: Phi
        """
    def phi(self, x: QuadInt) -> int:
        """Return Harper's weighted Euclidean size for `x`."""
    def _valuation_at_generator(self, x: QuadInt, pi: QuadInt) -> int:
        """v_pi(x) for a fixed chosen principal prime generator pi (ideal-specific)."""
    def divmod(self, x: QuadInt, y: QuadInt) -> tuple[QuadInt, QuadInt]:
        """
        Practical Harper-style division search.

        This reuses the local lattice search used in RealNormEuclidRing / Clark69Ring,
        but scores candidates with a weighted norm heuristic based on an admissible-pair
        witness (when available). Empirical validation via tests is essential.

        Returns:
            tuple: The quotient and remainder.

        Raises:
            ZeroDivisionError: If y has an absolute norm of 0.
            ArithmeticError: TODO: Remove?
            NotImplementedError: If we were unable to find a quotient and remainder.
                Shouldn't happen. If it does, please contact a developer. Preferably one smarter than me.
        """
_POST_HARDCODED: dict
D_: int
den_: int
p1_a_: int
p1_b_: int
p2_a_: int
p2_b_: int
_ring: HarperRing
