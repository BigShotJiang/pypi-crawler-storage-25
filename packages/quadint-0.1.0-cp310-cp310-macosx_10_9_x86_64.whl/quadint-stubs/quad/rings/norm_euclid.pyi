import quadint.quad.rings.base
from quadint.quad.rings.base import QuadraticRing as QuadraticRing, _NeighborhoodSearch as _NeighborhoodSearch, _round_div_ties_away_from_zero as _round_div_ties_away_from_zero
from typing import ClassVar as _ClassVar

TYPE_CHECKING: bool
NORM_EUCLID_D: set

class RealNormEuclidRing(quadint.quad.rings.base.QuadraticRing):
    """
    Handle overrides where the ring of integers is norm-Euclidean.

    This class provides the general division algorithm used for both positive and negative
        discriminants in NORM_EUCLID_D (excluding D=0 and D=1 special cases).
    """
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""
    def divmod(self, x: QuadInt, y: QuadInt):
        """
        Division in a norm-Euclidean real quadratic ring.

        We use the absolute norm as the Euclidean function:
            f(z) = |N(z)|.

        For the known finite list of D where the ring of integers is norm-Euclidean,
        there exists q such that |N(x - qy)| < |N(y)|.

        Returns:
            q, r: The quotient and remainder

        Raises:
            ZeroDivisionError: If the magnitude of the divisor is 0.
            ArithmeticError: In the event of a parity mismatch.
        """
