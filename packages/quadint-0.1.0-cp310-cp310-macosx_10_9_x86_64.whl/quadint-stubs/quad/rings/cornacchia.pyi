import quadint.quad.rings.norm_euclid
from quadint.quad.rings.base import Factorization as Factorization
from quadint.quad.rings.norm_euclid import RealNormEuclidRing as RealNormEuclidRing
from typing import ClassVar as _ClassVar

TYPE_CHECKING: bool

class CornacchiaRing(quadint.quad.rings.norm_euclid.RealNormEuclidRing):
    """Shared split-prime factorization flow for rings with norm form x**2 + k*y**2."""
    SUPPORTS_FACTORIZATION: _ClassVar[bool] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""
    def _is_split_prime(self, p: int) -> bool: ...
    def _is_inert_prime(self, p: int) -> bool: ...
    def _ramified_generator(self, x: QuadInt) -> QuadInt: ...
    def _ramified_prime(self) -> int: ...
    def _inert_generator(self, x: QuadInt, p: int) -> QuadInt: ...
    def _split_generator(self, x: QuadInt, p: int) -> QuadInt: ...
    def _decompose_prime(self, p: int) -> tuple[int, int]:
        """Find x,y with p = x**2 + k*y**2 for split primes, where k=abs(D)."""
    def factor_detail(self, x: QuadInt) -> Factorization:
        """
        Return a structured factorization for Cornacchia-style imaginary quadratic rings.

        The result is returned as `Factorization(unit, primes)` where `primes` is a
            mapping ``{prime_element: exponent}`` and:

        * `unit * prod(p**e for p, e in primes.items()) == x`
        * each listed `prime_element` is a non-unit irreducible in this ring

        Strategy:

        1. Normalize by extracting a canonical unit associate.
        2. Remove powers of the ramified prime generator.
        3. Factor the remaining integer norm with ``sympy.factorint``.
        4. For each rational prime factor, use split/inert classification:
           * inert primes stay prime in the ring,
           * split primes are decomposed via Cornacchia's method and tested (with conjugates)
             as divisors.

        Args:
            x: A non-zero element of this ring.

        Returns:
            Factorization: The unit and prime-power data for ``x``.

        Raises:
            ValueError: If `x` is zero (zero has no finite prime factorization).
        """

class GaussianRing(CornacchiaRing):
    """Specialized factorization strategy for Gaussian integers Z[i]."""
    RAMIFIED_PRIME: _ClassVar[int] = ...
    def _is_split_prime(self, p: int) -> bool: ...
    def _is_inert_prime(self, p: int) -> bool: ...
    def _ramified_generator(self, x: QuadInt) -> QuadInt: ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""

class SqrtMinusTwoRing(CornacchiaRing):
    """Specialized factorization strategy for Z[sqrt(-2)]."""
    RAMIFIED_PRIME: _ClassVar[int] = ...
    def _is_split_prime(self, p: int) -> bool: ...
    def _is_inert_prime(self, p: int) -> bool: ...
    def _ramified_generator(self, x: QuadInt) -> QuadInt: ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""

class EisensteinRing(CornacchiaRing):
    """Specialized factorization strategy for Eisenstein integers Z[ω]."""
    RAMIFIED_PRIME: _ClassVar[int] = ...
    def _is_split_prime(self, p: int) -> bool: ...
    def _is_inert_prime(self, p: int) -> bool: ...
    def _ramified_generator(self, x: QuadInt) -> QuadInt: ...
    def _inert_generator(self, x: QuadInt, p: int) -> QuadInt: ...
    def _split_generator(self, x: QuadInt, p: int) -> QuadInt: ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""
