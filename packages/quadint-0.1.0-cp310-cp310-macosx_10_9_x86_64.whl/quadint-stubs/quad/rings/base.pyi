import dataclasses
from _typeshed import Incomplete
from collections.abc import Callable
from quadint.quad.int import QuadInt as QuadInt
from quadint.utils import requires_modules as requires_modules
from typing import ClassVar as _ClassVar

class Factorization:
    """x = unit * P1 * P2 * ... * Pk"""
    __dataclass_params__: _ClassVar[dataclasses._DataclassParams] = ...
    __dataclass_fields__: _ClassVar[dict] = ...
    __match_args__: _ClassVar[tuple] = ...
    def prod(self):
        """Recreate the number using prod"""
    def __replace__(self, **changes): ...
    def __hash__(self) -> int: ...
    def __init__(self, unit: QuadInt, primes: dict[QuadInt, int]) -> None: ...
    def __eq__(self, other) -> bool: ...
    def __setattr__(self, name, value): ...
    def __delattr__(self, name): ...
def _check_den(den: int) -> int:
    """Validate and return ring denominator."""
def _round_div_ties_away_from_zero(n: int, d: int) -> int:
    """Round n/d to nearest int; ties go away from 0. d must be > 0."""
def _split_uv(x: QuadInt) -> tuple[int, int]:
    """Return (u,v) for D=1 split-complex where u=(a+b)/den, v=(a-b)/den."""

class _NeighborhoodSearch:
    """
    Incremental local lattice search around (A0, B0_for_A(A)).

    Expanding from radius r to R only evaluates the newly-added Chebyshev shells
    (r+1, r+2, ..., R), so repeated calls do not rescan the interior.
    """
    A0: Incomplete
    B0_for_A: Incomplete
    _best_a: Incomplete
    _best_b: Incomplete
    _best_score: Incomplete
    _expanded_radius: Incomplete
    den: Incomplete
    score_for_AB: Incomplete
    def __init__(self, *, A0: int, B0_for_A: Callable[[int], int], score_for_AB: Callable[[int, int], tuple[int, ...]], den: int) -> None: ...
    def _consider(self, A: int, B: int) -> None: ...
    def _scan_shell(self, radius: int) -> None:
        """Scan exactly the Chebyshev shell at the given radius (new points only)."""
    def expand_to(self, radius: int) -> tuple[int, int]:
        """Expand the search incrementally up to `radius` and return current best (A,B)."""
    @property
    def best_score(self): ...
    @property
    def best_ab(self): ...
def _key(z: tuple, factors: dict[QuadInt, int]):
    """This is required (for now) as it appears that mypyc is having problems with sub-functions/lambdas"""
def _choose_best_in_neighborhood(*, A0: int, B0_for_A: Callable, score_for_AB: Callable, den: int, radius: int = ...) -> tuple[int, int]:
    """
    Search (A0±radius) * (B0(A)±radius) and return best (A,B).

    This is a tiny local lattice search used by all our divmod implementations.

    Args:
        A0: Initial guess for A.
        B0_for_A: Given A, return an initial guess for B (may depend on A).
        score_for_AB: Lexicographic score; smaller is better.
        den: Ring denominator (1 or 2). If den==2, enforce parity constraint A ≡ B (mod 2).
        radius: Search radius around the initial guess(es). radius=1 reproduces the old behavior.

    Returns:
        (bestA, bestB): Best candidate found.
    """

class QuadraticRing:
    """
    The quadratic integer ring (order) with basis (1, sqrt(D)) and fixed denominator den in {1,2}.

    Elements are represented as:
        (a + b*sqrt(D)) / den

    where a,b are integers stored as numerators.
    When den==2, integrality requires a ≡ b (mod 2).

    This object is *not* a type factory (no nested classes) — it just carries parameters.
    """
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    SUPPORTS_FACTORIZATION: _ClassVar[bool] = ...
    _CACHE: _ClassVar[dict] = ...
    D: Incomplete
    DEFAULT_KLASS: Incomplete
    den: Incomplete
    def __init__(self, D: int, den: int | None = ...) -> None:
        """Initialize the ring settings"""
    @classmethod
    def _subclasses(cls):
        """Recursively yield all subclasses of cls (depth-first)."""
    def __call__(self, a: int = ..., b: int = ...) -> QuadInt:
        """Create element (a + b*sqrt(D))/den with numerator coefficients a,b."""
    def __contains__(self, x: object) -> bool:
        """Return True iff x is a QuadInt element of this ring (by parameters)."""
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    def from_obj(self, n: complex | int | float | QuadInt) -> QuadInt:
        """Embed integer (or float) n as (n*den + 0*sqrt(D))/den. Also supports complex if D==-1"""
    def from_ab(self, a: int, b: int) -> QuadInt:
        """Create an integer keeping in mind the denominator"""
    def supports_division(self) -> bool:
        """
        Return whether this ring advertises Euclidean-style ``divmod`` support.

        Returns:
            bool: Whether this ring class sets ``SUPPORTS_DIVISION``.
        """
    def supports_factorization(self) -> bool:
        """
        Return whether this ring advertises prime-factorization support.

        Returns:
            bool: Whether this ring class sets ``SUPPORTS_FACTORIZATION``.
        """
    def phi(self, x: QuadInt) -> int:
        """Return the default Euclidean size `|N(x)|` used for division heuristics."""
    def discriminant(self) -> int:
        """Return the discriminant of the order represented by this ring."""
    def class_number(self, *args, **kwargs) -> int:
        """Return the ideal class number of this order using PARI/GP."""
    def divmod(self, x: QuadInt, y: QuadInt) -> tuple[QuadInt, QuadInt]:
        """An override for defining division algorithms in subclasses for different D values"""
    def exact_div(self, x: QuadInt, y: QuadInt) -> QuadInt | None:
        """
        Return q if x == q*y exactly in this ring, else None.

        Uses the identity q = self*conj(divisor)/N(divisor) and then checks integrality
            in the order (including den=2 parity constraint).

        Returns:
            QuadInt: Solely the quotient if the remainder is 0, else None.
        """
    def divides(self, x: QuadInt, y: QuadInt) -> bool:
        """Return True iff x | y in this ring."""
    def _canonicalize_bezout_result(self, g: QuadInt, s: QuadInt, t: QuadInt) -> tuple[QuadInt, QuadInt, QuadInt]:
        """
        Normalize a Bézout triple to the ring's canonical gcd representative.

        Given a triple (g, s, t) produced for some fixed inputs a and b
        with s*a + t*b == g, replace g by its canonical associate and
        multiply s and t by the same torsion unit so that the Bézout
        identity remains exactly true.

        This is a post-processing helper for xgcd-style routines. It makes gcd
        output deterministic across associate choices while preserving the original
        linear relation.

        Args:
            g: A gcd candidate, defined only up to multiplication by a unit.
            s: Bézout coefficient for the first input.
            t: Bézout coefficient for the second input.

        Returns:
            tuple[QuadInt, QuadInt, QuadInt]: A triple (g_can, s_can, t_can)
            where g_can == g._canonical_associate() and the same Bézout identity
            still holds with the adjusted coefficients.

        Notes:
            - Only torsion units are used to transport the identity.
            - If g is already canonical, the input triple is returned unchanged.
        """
    def xgcd(self, a: QuadInt, b: QuadInt) -> tuple[QuadInt, QuadInt, QuadInt]:
        """
        Extended gcd in Euclidean quadratic rings.

        Notes:
            - This is only implemented for rings with divmod support (Euclidean-style division).
            - The gcd is only defined up to multiplication by a unit; this returns a stable
              associate using QuadInt._canonical_associate() and adjusts (s,t) accordingly
              using the (finite) torsion unit list.

        Returns:
            (g, s, t): such that s*a + t*b == g
        """
    def gcd(self, a: QuadInt, b: QuadInt) -> QuadInt:
        """
        Greatest common divisor in Euclidean quadratic rings.

        The result is only defined up to multiplication by a unit; this method returns the
        same stable representative as `xgcd()` (via `_canonical_associate()`), so callers
        get deterministic output.

        Notes:
            - Implemented via `xgcd()`, so it is available exactly when `xgcd()` is available.
            - Raises `NotImplementedError` for non-Euclidean rings (supports_division()==False)
              and for D==0 where the ring is not a domain.

        Returns:
            g: A *canonical associate* such that g divides both `a` and `b`,
                and for any `d` dividing both `a` and `b`, `d` also divides `g`.
        """
    def inv_mod(self, a: QuadInt, m: QuadInt) -> QuadInt:
        """
        Modular inverse in Euclidean quadratic rings.

        Returns:
            inv: such that (a * inv) % m == 1 % m

        Raises:
            ZeroDivisionError: if m == 0.
            ValueError: if a is not invertible modulo m (i.e. gcd(a, m) is not a unit).
        """
    def factor_detail(self, x: QuadInt) -> Factorization:
        """Factor `x` and return structured details when supported by this ring."""
    def factor(self, x: QuadInt) -> dict[QuadInt, int]:
        """
        Factor x and return a dict of factors whose product is exactly `x`.

        The unit part is folded into the first factor so users get a simple factor list
            (matching familiar integer-factorization APIs).

        Returns:
            dict: A simple dictionary containing the factorization similar to sympy's factorint.
        """
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""
    @property
    def zero(self):
        """Additive identity (0).
        Additive identity (0)."""
    @property
    def one(self):
        """Multiplicative identity (1).
        Multiplicative identity (1)."""
