import quadint.quad.rings.base
from quadint.quad.rings.base import QuadraticRing as QuadraticRing, _choose_best_in_neighborhood as _choose_best_in_neighborhood, _round_div_ties_away_from_zero as _round_div_ties_away_from_zero, _split_uv as _split_uv
from typing import ClassVar as _ClassVar

TYPE_CHECKING: bool
def _int_xgcd(a: int, b: int) -> tuple[int, int, int]:
    """Extended GCD for integers. Returns (g, s, t) with s*a + t*b == g, g >= 0."""

class DualRing(quadint.quad.rings.base.QuadraticRing):
    """
    Handle overrides for D=0, dual integer solutions

    While the general algorith in RealNormEuclidRing will find a solution for D=0,
        it does not take into account that the ε part is not part of the norm,
        so is not relevant in the division algorithm.

    This class will solve division for the real part while trying to minimize the ε part.
    """
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""
    def divmod(self, x: QuadInt, y: QuadInt) -> tuple[QuadInt, QuadInt]:
        """Division with D=0"""

class SplitRing(quadint.quad.rings.base.QuadraticRing):
    """
    Handle overrides for D=1, split integer solutions

    This class performs division in the split (u, v) coordinates (where multiplication
        is component-wise), choosing a quotient that reduces both components and yields a
        more stable, integer-like remainder.

    This structural shortcut is only possible with D=1 (because Z[sqrt(1)]... well, splits.)
    """
    SUPPORTS_DIVISION: _ClassVar[bool] = ...
    @classmethod
    def accept_override(cls, D: int, den: int, default_den: int) -> bool:
        """Should this class be used for the given values?"""
    def divmod(self, x: QuadInt, y: QuadInt) -> tuple[QuadInt, QuadInt]:
        """Division with D=1"""
    def _uv_to_ab(self, u: int, v: int) -> QuadInt:
        """Convert split coordinates (u, v) back to stored numerator coordinates (a, b)."""
    def exact_div(self, x: QuadInt, y: QuadInt) -> QuadInt | None:
        """Exact division in split coordinates (handles zero-norm divisors)."""
    def _split_gcd(self, u1: int, v1: int, u2: int, v2: int) -> tuple[int, int]:
        """Compute GCD in split coordinates, respecting den=1 parity constraints."""
    def gcd(self, a: QuadInt, b: QuadInt) -> QuadInt:
        """GCD in split coordinates, respecting sublattice parity constraints."""
    def xgcd(self, a: QuadInt, b: QuadInt) -> tuple[QuadInt, QuadInt, QuadInt]:
        """Extended GCD in split coordinates (den=2 only; den=1 ring is not a PID)."""
