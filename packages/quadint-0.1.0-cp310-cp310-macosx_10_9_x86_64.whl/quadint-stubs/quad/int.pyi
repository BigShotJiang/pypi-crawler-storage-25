from _typeshed import Incomplete
from typing import ClassVar as _ClassVar, Iterator

TYPE_CHECKING: bool
_OTHER_OP_TYPES: tuple
def _key(w_: QuadInt) -> tuple[int, int, int, int, int]:
    """This is required (for now) as it appears that mypyc is having problems with sub-functions/lambdas"""

class QuadInt:
    """
    Element of a specific QuadraticRing.

    Stored as numerators a,b for (a + b*sqrt(D)) / den.
    """
    SYMBOL: _ClassVar[str] = ...
    DEFAULT_RING: _ClassVar[None] = ...
    BASIS_TO_INTERNAL: _ClassVar[tuple] = ...
    INTERNAL_TO_BASIS: _ClassVar[tuple] = ...
    INTERNAL_TO_BASIS_DEN: _ClassVar[int] = ...
    a: Incomplete
    b: Incomplete
    ring: Incomplete
    def __init__(self, a: int = ..., b: int = ..., ring: QuadraticRing | None = ...) -> None:
        """Init and validate the integer works for this ring"""
    @classmethod
    def __init_subclass__(cls, *args: tuple, **kwargs: dict):
        """Register a subclass with the ring if it is defined"""
    def _make(self, a: int, b: int):
        """Construct a new value of *this* conceptual type from internal numerators a,b."""
    def _canonical_associate(self) -> QuadInt:
        """Return canonical representative among associates for stable factor output."""
    def _from_obj(self, n: complex | int | float | QuadInt):
        """Make a QuadInt on the current ring from a given object"""
    def assert_same_ring(self, other: QuadInt):
        """Raise an error if other is not in the same ring as self"""
    def conjugate(self):
        """(a + b√D)/den -> (a - b√D)/den."""
    @classmethod
    def _internal_to_basis(cls, a: int, b: int) -> tuple[int, int]:
        """Convert from internal a and b coords to basis coords"""
    @classmethod
    def _basis_to_internal(cls, x: int, y: int) -> tuple[int, int]:
        """Convert from basis coords to internal a and b coords"""
    def __add__(self, other: complex | int | float | QuadInt): ...
    def __radd__(self, other: int | float | complex): ...
    def __sub__(self, other: complex | int | float | QuadInt): ...
    def __rsub__(self, other: int | float | complex): ...
    def __neg__(self): ...
    def __pos__(self): ...
    def __mul__(self, other: complex | int | float | QuadInt): ...
    def __rmul__(self, other: int | float | complex): ...
    def __pow__(self, exp: float, mod: complex | int | float | QuadInt | None = ...): ...
    def __divmod__(self, other: complex | int | float | QuadInt):
        """
        Nearest-lattice division for D <= 0 (imaginary quadratic).

        Intended for Euclidean rings (e.g., D=-1, -2, -3, -7, -11 in the maximal order).

        Returns:
            tuple: The quotient and remainder of the division with other.
        """
    def __truediv__(self, other: complex | int | float | QuadInt): ...
    def __rtruediv__(self, other: int | float | complex): ...
    def __floordiv__(self, other: complex | int | float | QuadInt): ...
    def __rfloordiv__(self, other: int | float | complex): ...
    def __mod__(self, other: complex | int | float | QuadInt): ...
    def __rmod__(self, other: int | float | complex): ...
    def exact_div(self, divisor: complex | int | float | QuadInt) -> QuadInt | None:
        """Return q if y * q == self in this ring, else None."""
    def divides(self, x: complex | int | float | QuadInt) -> bool:
        """Return True iff self | x in this ring."""
    def xgcd(self, x: QuadInt) -> tuple[QuadInt, QuadInt, QuadInt]:
        """Extended gcd in Euclidean quadratic rings."""
    def gcd(self, x: QuadInt) -> QuadInt:
        """Greatest common divisor in Euclidean quadratic rings."""
    def inv_mod(self, mod: complex | int | float | QuadInt) -> QuadInt:
        """Return the modular inverse of self modulo mod (if it exists)."""
    def is_unit(self) -> bool:
        """Return True iff this element is a unit (invertible) in its ring."""
    def __abs__(self) -> int:
        """
        N((a+b√D)/den) = (a^2 - D*b^2) / den^2

        Always an integer for valid ring elements.

        Returns:
            int: The norm for the ring.

        Raises:
            ArithmeticError: If there is a non-integral norm for the ring.
        """
    def factor(self) -> dict[QuadInt, int]:
        """Return a plain factor dict whose product is `self`."""
    def factor_detail(self) -> Factorization:
        """Return structured `Factorization(unit, primes)` details."""
    def content(self) -> int:
        """Largest positive integer n such that x = n*y for some y in this ring."""
    def __int__(self) -> int:
        """Return an int for pure integers (delegates to __index__)."""
    def __index__(self) -> int:
        """Return an integer if this element is a plain integer (b == 0), else raise TypeError."""
    def __float__(self) -> float:
        """Return a float if this element is a plain integer (b == 0), else raise TypeError."""
    def __complex__(self) -> complex:
        """Return a complex if this element is a Gaussian integer (D == -1, den == 1), else raise TypeError."""
    def __bool__(self) -> bool: ...
    def __iter__(self) -> Iterator[int]: ...
    def __len__(self) -> int: ...
    def __getitem__(self, idx: int) -> int: ...
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...
    @property
    def zero(self):
        """Additive identity (0).
        Additive identity (0)."""
    @property
    def one(self):
        """Multiplicative identity (1).
        Multiplicative identity (1)."""
    @property
    def units(self):
        """
        Return the torsion units (roots of unity) in this order.

        Notes:
            This intentionally returns a finite subgroup only. In real quadratic rings
            (D >= 0), the full unit group is infinite; here we expose just the torsion
            part (typically `{±1}` except for D=1) because it is what canonical-associate and
            factorization normalization need.


        Return the torsion units (roots of unity) in this order.

        Notes:
            This intentionally returns a finite subgroup only. In real quadratic rings
            (D >= 0), the full unit group is infinite; here we expose just the torsion
            part (typically `{±1}` except for D=1) because it is what canonical-associate and
            factorization normalization need.
        """
    @property
    def basis(self):
        """The number in the basis vector
        The number in the basis vector"""
    @property
    def basis_a(self):
        """a in the basis vector
        a in the basis vector"""
    @property
    def basis_b(self):
        """b in the basis vector
        b in the basis vector"""
