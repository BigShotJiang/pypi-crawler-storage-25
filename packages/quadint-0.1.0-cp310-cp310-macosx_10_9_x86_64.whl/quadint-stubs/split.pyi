import quadint.quad.int
import quadint.quad.rings.special
from quadint.quad.int import QuadInt as QuadInt
from quadint.quad.rings.base import QuadraticRing as QuadraticRing
from quadint.quad.rings.special import _ZJ as _ZJ
from typing import ClassVar as _ClassVar

class splitint(quadint.quad.int.QuadInt):
    """
    Represents a split-complex (hyperbolic) number with integer real and j parts, where j**2 = 1.

    Properties:
        real (int): The real component.
        hyper (int): The hyperbolic (j) component.
    """
    SYMBOL: _ClassVar[str] = ...
    DEFAULT_RING: _ClassVar[quadint.quad.rings.special.SplitRing] = ...
    @property
    def real(self):
        """Alias for splitint
        Alias for splitint"""
    @property
    def hyper(self):
        """Alias for splitint
        Alias for splitint"""
    @property
    def j(self):
        """Alias for splitint
        Alias for splitint"""
