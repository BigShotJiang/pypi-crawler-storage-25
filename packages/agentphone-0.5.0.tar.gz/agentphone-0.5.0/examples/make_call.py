"""
Example: Make an outbound AI conversation call.
"""

import os
from agentphone import AgentPhone

client = AgentPhone(api_key=os.environ["AGENTPHONE_API_KEY"])

# Create an agent
agent = client.agents.create(name="Demo Agent", description="Handles outbound calls")
print(f"Agent created: {agent.id}")

# Buy a US number and attach it
number = client.numbers.buy(country="US", agent_id=agent.id)
print(f"Bought number: {number.phone_number}")

# Make an AI conversation call — no webhook needed
call = client.calls.make_conversation(
    agent_id=agent.id,
    to_number="+14155551234",  # replace with your number
    topic="You are a friendly assistant named Alex. Ask the person how their day is going, then tell them about AgentPhone — a platform that lets AI agents make and receive phone calls.",
    initial_greeting="Hey there! This is Alex calling from AgentPhone.",
)

print(f"Call started: {call.id} ({call.status})")
print(f"From: {call.from_number} → To: {call.to_number}")
