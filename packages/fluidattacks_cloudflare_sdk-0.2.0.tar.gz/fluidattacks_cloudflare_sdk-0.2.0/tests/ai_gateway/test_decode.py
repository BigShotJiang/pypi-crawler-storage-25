from datetime import UTC, datetime, timedelta, timezone

from cloudflare.types.ai_gateway import LogListResponse
from fa_purity import Maybe, Unsafe
from fa_purity.date_time import DatetimeUTC

from fluidattacks_cloudflare_sdk.ai_gateway._decode import decode_log
from fluidattacks_cloudflare_sdk.ai_gateway.core import LogRecord

_DURATION_FULL = 150
_DURATION_MINIMAL = 300

_CREATED_AT_FULL = (
    DatetimeUTC.assert_utc(datetime(2026, 4, 7, 23, 30, 0, tzinfo=UTC))
    .alt(Unsafe.raise_exception)
    .to_union()
)

_CREATED_AT_MINIMAL = (
    DatetimeUTC.assert_utc(datetime(2026, 4, 7, 23, 45, 0, tzinfo=UTC))
    .alt(Unsafe.raise_exception)
    .to_union()
)


def _full_raw() -> LogListResponse:
    return LogListResponse(
        id="abc123",
        cached=True,
        created_at=datetime(2026, 4, 7, 23, 30, 0, tzinfo=UTC),
        duration=_DURATION_FULL,
        model="gpt-4o",
        path="/v1/chat/completions",
        provider="openai",
        success=True,
        tokens_in=100,
        tokens_out=50,
        cost=0.003,
        custom_cost=False,
        metadata='{"email":"user@example.com"}',
        model_type="chat",
        request_content_type="application/json",
        request_type="universal",
        response_content_type="application/json",
        status_code=200,
        step=1,
    )


def _minimal_raw() -> LogListResponse:
    return LogListResponse(
        id="xyz789",
        cached=False,
        created_at=datetime(2026, 4, 7, 23, 45, 0, tzinfo=UTC),
        duration=_DURATION_MINIMAL,
        model="claude-3-5-sonnet",
        path="/v1/messages",
        provider="anthropic",
        success=False,
    )


_EXPECTED_FULL = LogRecord(
    id="abc123",
    cached=True,
    created_at=_CREATED_AT_FULL,
    duration=_DURATION_FULL,
    model="gpt-4o",
    path="/v1/chat/completions",
    provider="openai",
    success=True,
    tokens_in=Maybe.some(100),
    tokens_out=Maybe.some(50),
    cost=Maybe.some(0.003),
    custom_cost=Maybe.some(value=False),
    metadata=Maybe.some('{"email":"user@example.com"}'),
    model_type=Maybe.some("chat"),
    request_content_type=Maybe.some("application/json"),
    request_type=Maybe.some("universal"),
    response_content_type=Maybe.some("application/json"),
    status_code=Maybe.some(200),
    step=Maybe.some(1),
)

_EXPECTED_MINIMAL = LogRecord(
    id="xyz789",
    cached=False,
    created_at=_CREATED_AT_MINIMAL,
    duration=_DURATION_MINIMAL,
    model="claude-3-5-sonnet",
    path="/v1/messages",
    provider="anthropic",
    success=False,
    tokens_in=Maybe.empty(),
    tokens_out=Maybe.empty(),
    cost=Maybe.empty(),
    custom_cost=Maybe.empty(),
    metadata=Maybe.empty(),
    model_type=Maybe.empty(),
    request_content_type=Maybe.empty(),
    request_type=Maybe.empty(),
    response_content_type=Maybe.empty(),
    status_code=Maybe.empty(),
    step=Maybe.empty(),
)


def test_decode_full_record() -> None:
    record = decode_log(_full_raw()).alt(Unsafe.raise_exception).to_union()
    assert record == _EXPECTED_FULL


def test_decode_minimal_record_optional_fields_are_empty() -> None:
    record = decode_log(_minimal_raw()).alt(Unsafe.raise_exception).to_union()
    assert record == _EXPECTED_MINIMAL


def test_decode_non_utc_datetime_fails() -> None:
    raw = LogListResponse(
        id="bad",
        cached=False,
        created_at=datetime(2026, 4, 7, 18, 0, 0, tzinfo=timezone(timedelta(hours=-5))),
        duration=0,
        model="x",
        path="/",
        provider="y",
        success=True,
    )
    assert (
        decode_log(raw)
        .to_coproduct()
        .map(
            lambda _: False,
            lambda _: True,
        )
    )
