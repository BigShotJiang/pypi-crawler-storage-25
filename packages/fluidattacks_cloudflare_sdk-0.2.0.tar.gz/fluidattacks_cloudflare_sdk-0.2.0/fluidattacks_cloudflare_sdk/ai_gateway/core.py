"""Domain types and client interface for the Cloudflare AI Gateway resource."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from fa_purity import Maybe

if TYPE_CHECKING:
    from collections.abc import Callable

    from fa_purity import Cmd, FrozenList, ResultE
    from fa_purity.date_time import DatetimeUTC
    from fa_purity.json import JsonObj


LogsOrderByField = Literal["created_at", "provider", "model", "model_type", "success", "cached"]
LogsOrderByDirection = Literal["asc", "desc"]


@dataclass(frozen=True)
class LogId:
    """Identifier for a single AI Gateway log entry."""

    raw: str


@dataclass(frozen=True)
class StartDate:
    """Inclusive lower bound for AI Gateway log queries."""

    raw: DatetimeUTC


@dataclass(frozen=True)
class EndDate:
    """Exclusive upper bound for AI Gateway log queries."""

    raw: DatetimeUTC


@dataclass(frozen=True)
class LogsOrderBy:
    """Ordering configuration for AI Gateway log queries."""

    field: LogsOrderByField
    direction: LogsOrderByDirection

    @staticmethod
    def default() -> LogsOrderBy:
        """Default ordering: created_at ascending."""
        return LogsOrderBy(field="created_at", direction="asc")


@dataclass(frozen=True)
class LogsQuery:
    """Filter and ordering options for AI Gateway log queries."""

    start: Maybe[StartDate]
    end: Maybe[EndDate]
    order_by: Maybe[LogsOrderBy]

    @staticmethod
    def all() -> LogsQuery:
        """Query with no filters and default ordering."""
        return LogsQuery(
            start=Maybe.empty(),
            end=Maybe.empty(),
            order_by=Maybe.some(LogsOrderBy.default()),
        )


@dataclass(frozen=True)
class LogRecord:
    """A single AI Gateway request log entry."""

    id: str
    cached: bool
    created_at: DatetimeUTC
    duration: int
    model: str
    path: str
    provider: str
    success: bool
    tokens_in: Maybe[int]
    tokens_out: Maybe[int]
    cost: Maybe[float]
    custom_cost: Maybe[bool]
    metadata: Maybe[str]
    model_type: Maybe[str]
    request_content_type: Maybe[str]
    request_type: Maybe[str]
    response_content_type: Maybe[str]
    status_code: Maybe[int]
    step: Maybe[int]


@dataclass(frozen=True)
class AiGatewayClient:
    """Interface for Cloudflare AI Gateway operations."""

    list_logs: Callable[
        [LogsQuery],
        Cmd[ResultE[FrozenList[LogRecord]]],
    ]
    get_log_request: Callable[[LogId], Cmd[ResultE[JsonObj]]]
    get_log_response: Callable[[LogId], Cmd[ResultE[JsonObj]]]
