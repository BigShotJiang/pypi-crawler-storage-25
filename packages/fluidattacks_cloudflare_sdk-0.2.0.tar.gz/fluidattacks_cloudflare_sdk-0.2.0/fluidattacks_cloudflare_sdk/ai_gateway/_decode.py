from __future__ import annotations

from typing import TYPE_CHECKING

from fa_purity import Maybe
from fa_purity.date_time import DatetimeUTC

from fluidattacks_cloudflare_sdk.ai_gateway.core import LogRecord

if TYPE_CHECKING:
    from cloudflare.types.ai_gateway import LogListResponse
    from fa_purity import ResultE


def decode_log(raw: LogListResponse) -> ResultE[LogRecord]:
    return DatetimeUTC.assert_utc(raw.created_at).map(
        lambda created_at: LogRecord(
            id=raw.id,
            cached=raw.cached,
            created_at=created_at,
            duration=raw.duration,
            model=raw.model,
            path=raw.path,
            provider=raw.provider,
            success=raw.success,
            tokens_in=Maybe.from_optional(raw.tokens_in),
            tokens_out=Maybe.from_optional(raw.tokens_out),
            cost=Maybe.from_optional(raw.cost),
            custom_cost=Maybe.from_optional(raw.custom_cost),
            metadata=Maybe.from_optional(raw.metadata),
            model_type=Maybe.from_optional(raw.ai_model_type),
            request_content_type=Maybe.from_optional(raw.request_content_type),
            request_type=Maybe.from_optional(raw.request_type),
            response_content_type=Maybe.from_optional(raw.response_content_type),
            status_code=Maybe.from_optional(raw.status_code),
            step=Maybe.from_optional(raw.step),
        )
    )
