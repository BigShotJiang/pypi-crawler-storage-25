from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from cloudflare import NOT_GIVEN
from fa_purity import Cmd, FrozenList, Result, ResultE, Unsafe
from fa_purity.json import JsonObj, UnfoldedFactory

from fluidattacks_cloudflare_sdk.ai_gateway._decode import decode_log
from fluidattacks_cloudflare_sdk.ai_gateway.core import (
    LogId,
    LogRecord,
    LogsOrderBy,
    LogsQuery,
)

if TYPE_CHECKING:
    from fluidattacks_cloudflare_sdk._client import Client
    from fluidattacks_cloudflare_sdk.core import AccountId, GatewayId

LOG = logging.getLogger(__name__)


def list_logs(
    cloudflare: Client,
    account_id: AccountId,
    gateway_id: GatewayId,
    query: LogsQuery,
) -> Cmd[ResultE[FrozenList[LogRecord]]]:
    _order = query.order_by.value_or(LogsOrderBy.default())
    _start = query.start.map(lambda s: s.raw.date_time.strftime("%Y-%m-%dT%H:%M:%SZ")).value_or(
        NOT_GIVEN
    )
    _end = query.end.map(lambda e: e.raw.date_time.strftime("%Y-%m-%dT%H:%M:%SZ")).value_or(
        NOT_GIVEN
    )

    def _action() -> ResultE[FrozenList[LogRecord]]:
        try:
            LOG.info("fetching ai gateway logs for gateway %s", gateway_id.raw)
            first_page = cloudflare.client.ai_gateway.logs.list(
                gateway_id.raw,
                account_id=account_id.raw,
                start_date=_start,
                end_date=_end,
                order_by=_order.field,
                order_by_direction=_order.direction,
            )
            items: list[LogRecord] = []
            for page in first_page.iter_pages():
                page_records = page.result
                items.extend(
                    decode_log(raw).alt(Unsafe.raise_exception).to_union() for raw in page_records
                )
                LOG.info(
                    "page fetched: %d records (%d total so far)",
                    len(page_records),
                    len(items),
                )
            LOG.info(
                "finished: %d log records from gateway %s",
                len(items),
                gateway_id.raw,
            )
            return Result.success(tuple(items))
        except Exception as err:
            LOG.exception("failed to fetch ai gateway logs")
            return ResultE[FrozenList[LogRecord]].failure(err)

    return Cmd.wrap_impure(_action)


def get_log_request(
    cloudflare: Client,
    account_id: AccountId,
    gateway_id: GatewayId,
    log_id: LogId,
) -> Cmd[ResultE[JsonObj]]:
    def _action() -> ResultE[JsonObj]:
        try:
            LOG.info(
                "fetching request for log %s on gateway %s",
                log_id.raw,
                gateway_id.raw,
            )
            result = cloudflare.client.ai_gateway.logs.request(
                log_id.raw,
                account_id=account_id.raw,
                gateway_id=gateway_id.raw,
            )
            return UnfoldedFactory.json_from_any(result)
        except Exception as err:
            LOG.exception("failed to fetch log request")
            return ResultE[JsonObj].failure(err)

    return Cmd.wrap_impure(_action)


def get_log_response(
    cloudflare: Client,
    account_id: AccountId,
    gateway_id: GatewayId,
    log_id: LogId,
) -> Cmd[ResultE[JsonObj]]:
    def _action() -> ResultE[JsonObj]:
        try:
            LOG.info(
                "fetching response for log %s on gateway %s",
                log_id.raw,
                gateway_id.raw,
            )
            result = cloudflare.client.ai_gateway.logs.response(
                log_id.raw,
                account_id=account_id.raw,
                gateway_id=gateway_id.raw,
            )
            return UnfoldedFactory.json_from_any(result)
        except Exception as err:
            LOG.exception("failed to fetch log response")
            return ResultE[JsonObj].failure(err)

    return Cmd.wrap_impure(_action)
