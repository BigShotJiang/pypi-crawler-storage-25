"""AI Gateway sub-package for the Cloudflare SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from fluidattacks_cloudflare_sdk._client import CloudflareClientFactory
from fluidattacks_cloudflare_sdk.ai_gateway._client import (
    get_log_request,
    get_log_response,
    list_logs,
)
from fluidattacks_cloudflare_sdk.ai_gateway.core import (
    AiGatewayClient,
    EndDate,
    LogId,
    LogRecord,
    LogsOrderBy,
    LogsQuery,
    StartDate,
)

if TYPE_CHECKING:
    from fluidattacks_cloudflare_sdk._client import Client, Token
    from fluidattacks_cloudflare_sdk.core import AccountId, GatewayId


def _from_client(
    cloudflare: Client,
    account_id: AccountId,
    gateway_id: GatewayId,
) -> AiGatewayClient:
    return AiGatewayClient(
        list_logs=lambda q: list_logs(cloudflare, account_id, gateway_id, q),
        get_log_request=lambda log_id: get_log_request(cloudflare, account_id, gateway_id, log_id),
        get_log_response=lambda log_id: get_log_response(
            cloudflare, account_id, gateway_id, log_id
        ),
    )


@dataclass(frozen=True)
class AiGatewayClientFactory:
    """Factory for AiGatewayClient."""

    @staticmethod
    def new(
        token: Token,
        account_id: AccountId,
        gateway_id: GatewayId,
    ) -> AiGatewayClient:
        """Build an AiGatewayClient from a token and identifiers."""
        return _from_client(CloudflareClientFactory.new(token), account_id, gateway_id)


__all__ = [
    "AiGatewayClient",
    "AiGatewayClientFactory",
    "EndDate",
    "LogId",
    "LogRecord",
    "LogsOrderBy",
    "LogsQuery",
    "StartDate",
]
