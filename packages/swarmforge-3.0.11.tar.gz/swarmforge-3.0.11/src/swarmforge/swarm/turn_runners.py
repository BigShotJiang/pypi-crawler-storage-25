"""Reusable turn runner implementations for provider-backed runtime flows."""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING, Any, Dict, List, Protocol

from .models import SwarmNode
from .orchestrator import AgentTurnConfig, AgentTurnResult, AgentTurnRunner

if TYPE_CHECKING:
    from ..evaluation.provider import ModelConfig


class OpenAICompatibleClient(Protocol):
    """Minimal client contract needed by the OpenAI-compatible turn runner."""

    def chat_completion(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]] | None = None,
    ) -> Any: ...


class OpenAICompatibleTurnRunner:
    """Adapt an OpenAI-compatible chat client to the runtime turn-runner contract."""

    def __init__(self, client: OpenAICompatibleClient) -> None:
        self.client = client

    async def run_turn(
        self,
        *,
        agent_node: SwarmNode,
        contents: List[Dict[str, Any]],
        config: AgentTurnConfig,
    ) -> AgentTurnResult:
        del agent_node
        messages: List[Dict[str, Any]] = []
        if config.system_instruction:
            messages.append({"role": "system", "content": config.system_instruction})

        for item in contents:
            role = str(item.get("role") or "user").strip()
            if role == "model":
                role = "assistant"
            raw_content = item.get("content", "")
            # Pass list content (multimodal parts) through unchanged; coerce
            # everything else to a string so the OpenAI client is always given
            # a valid content value.
            content_value = raw_content if isinstance(raw_content, list) else str(raw_content or "")
            message: Dict[str, Any] = {"role": role, "content": content_value}
            if role == "tool":
                if item.get("tool_call_id"):
                    message["tool_call_id"] = item.get("tool_call_id")
                if item.get("name"):
                    message["name"] = item.get("name")
            messages.append(message)

        response = self.client.chat_completion(messages=messages, tools=config.tools)
        assistant_message = response.choices[0].message
        tool_calls: List[Dict[str, Any]] = []
        if assistant_message.tool_calls:
            for tool_call in assistant_message.tool_calls:
                args = tool_call.function.arguments
                if not isinstance(args, dict):
                    args = json.loads(args or "{}")
                tool_calls.append(
                    {
                        "id": tool_call.id,
                        "name": tool_call.function.name,
                        "args": args,
                    }
                )

        return AgentTurnResult(
            response_text=assistant_message.content or "",
            tool_calls=tool_calls,
            raw_response=response,
        )

    async def stream_turn(
        self,
        *,
        agent_node: SwarmNode,
        contents: List[Dict[str, Any]],
        config: AgentTurnConfig,
    ) -> AsyncGenerator[tuple[str, None] | tuple[None, AgentTurnResult], None]:
        """Stream one agent turn.

        Yields ``(text_chunk, None)`` for each incremental text token, then a
        final ``(None, AgentTurnResult)`` containing the complete response and
        any tool calls once the stream is exhausted.

        Falls back to a single blocking ``run_turn`` call when the underlying
        client does not expose ``stream_chat_completion``.
        """
        if not hasattr(self.client, "stream_chat_completion"):
            result = await self.run_turn(agent_node=agent_node, contents=contents, config=config)
            yield None, result
            return

        messages: List[Dict[str, Any]] = []
        if config.system_instruction:
            messages.append({"role": "system", "content": config.system_instruction})

        for item in contents:
            role = str(item.get("role") or "user").strip()
            if role == "model":
                role = "assistant"
            raw_content = item.get("content", "")
            content_value = raw_content if isinstance(raw_content, list) else str(raw_content or "")
            message: Dict[str, Any] = {"role": role, "content": content_value}
            if role == "tool":
                if item.get("tool_call_id"):
                    message["tool_call_id"] = item.get("tool_call_id")
                if item.get("name"):
                    message["name"] = item.get("name")
            messages.append(message)

        full_text = ""
        tool_calls: List[Dict[str, Any]] = []

        for text_delta, assembled_tool_calls in self.client.stream_chat_completion(  # type: ignore[union-attr]
            messages=messages,
            tools=config.tools or None,
        ):
            if text_delta is not None:
                full_text += text_delta
                yield text_delta, None
            elif assembled_tool_calls is not None:
                tool_calls = assembled_tool_calls

        yield None, AgentTurnResult(response_text=full_text, tool_calls=tool_calls)


def build_openai_compatible_turn_runner(client: OpenAICompatibleClient) -> AgentTurnRunner:
    """Build an AgentTurnRunner from an OpenAI-compatible chat client."""

    return OpenAICompatibleTurnRunner(client)


def build_turn_runner(model_config: "ModelConfig") -> AgentTurnRunner:
    """Build the default provider-backed turn runner from a model configuration."""

    from ..evaluation.provider import OpenAIClientWrapper

    return build_openai_compatible_turn_runner(OpenAIClientWrapper(model_config))
