"""Pydantic request models and OpenAPI examples for the FastAPI transport."""

from __future__ import annotations

from typing import Any, Dict, List, Union

from pydantic import AliasChoices, BaseModel, Field

from ..authoring import build_swarm_definition

# A multimodal content item as accepted by OpenAI-compatible endpoints.
# Supports text (``{"type": "text", "text": "..."}``), image URLs
# (``{"type": "image_url", "image_url": {"url": "...", "detail": "auto"}}``),
# and audio (``{"type": "input_audio", "input_audio": {"data": "<base64>", "format": "wav"}}``).
UserInputContent = Union[str, List[Dict[str, Any]]]

RUN_SWARM_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Run a swarm turn with server-configured provider defaults",
        "value": {
            "swarm": {
                "id": "support",
                "name": "Support Swarm",
                "nodes": [
                    {
                        "node_key": "assistant",
                        "name": "Assistant",
                        "system_prompt": "You are a helpful assistant.",
                        "is_entry_node": True,
                    }
                ],
                "edges": [],
                "variables": [],
            },
            "user_input": "Give me a concise answer.",
            "state": {"account_id": "ACME-991"},
        },
    },
    "fast_mode": {
        "summary": "Run a swarm turn with fast mode enabled",
        "description": (
            "When the entry node has behavior_config.fast_mode_enabled=true and at least one "
            "enabled tool has fast_enabled=true, the runtime executes those tools immediately "
            "without calling the model. Supply per-tool arguments through state.fast_tool_params."
        ),
        "value": {
            "swarm": {
                "id": "ops",
                "name": "Ops Swarm",
                "nodes": [
                    {
                        "node_key": "ops",
                        "name": "Ops",
                        "system_prompt": "You are an operations specialist.",
                        "behavior_config": {"fast_mode_enabled": True},
                        "enabled_tools": [
                            {
                                "type": "function",
                                "function": {
                                    "name": "lookup_order",
                                    "description": "Fetch order status",
                                    "parameters": {
                                        "type": "object",
                                        "properties": {"order_id": {"type": "string"}},
                                        "required": ["order_id"],
                                    },
                                },
                                "fast_enabled": True,
                                "fast_default_args": {"order_id": "A-77"},
                            }
                        ],
                        "is_entry_node": True,
                    }
                ],
                "edges": [],
                "variables": [],
            },
            "user_input": "Track my order",
            "state": {
                "fast_tool_params": {"lookup_order": {"order_id": "A-99"}},
            },
        },
    },
    "fast_mode_response_templates": {
        "summary": "Fast mode with mode:fast response template parameters",
        "description": (
            "Parameters with mode='fast' are LLM-filled in normal mode. In fast mode they are "
            "excluded from auto-inference; the tool handler returns a string that becomes the "
            "assistant message directly, skipping the generic summary."
        ),
        "value": {
            "swarm": {
                "id": "ops",
                "name": "Ops Swarm",
                "nodes": [
                    {
                        "node_key": "ops",
                        "name": "Ops",
                        "system_prompt": "You are an operations specialist.",
                        "behavior_config": {"fast_mode_enabled": True},
                        "enabled_tools": [
                            {
                                "type": "function",
                                "function": {
                                    "name": "lookup_order",
                                    "description": "Fetch order status",
                                    "parameters": {
                                        "type": "object",
                                        "properties": {
                                            "order_id": {
                                                "type": "string",
                                                "description": "The order ID",
                                            },
                                            "order_not_success": {
                                                "type": "string",
                                                "mode": "fast",
                                                "description": "Message if the order lookup fails",
                                            },
                                            "order_success": {
                                                "type": "string",
                                                "mode": "fast",
                                                "description": "Message if the order lookup succeeds",
                                            },
                                        },
                                        "required": ["order_id"],
                                    },
                                },
                                "fast_enabled": True,
                                "fast_default_args": {"order_id": "A-77"},
                            }
                        ],
                        "is_entry_node": True,
                    }
                ],
                "edges": [],
                "variables": [],
            },
            "user_input": "Track my order",
            "state": {},
        },
    },
}

SEND_MESSAGE_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Send a session message with server-configured provider defaults",
        "value": {
            "user_input": "Help me with this request.",
            "state": {"account_id": "ACME-991", "priority": "high"},
        },
    },
    "fast_mode": {
        "summary": "Send a session message with fast tool params",
        "description": (
            "Override fast-tool arguments for the current turn by sending "
            "fast_tool_params inside the state payload."
        ),
        "value": {
            "user_input": "Track my order",
            "state": {
                "fast_tool_params": {"lookup_order": {"order_id": "A-99"}},
            },
        },
    },
    "fast_mode_response_templates": {
        "summary": "Send a session message with mode:fast response template params",
        "description": (
            "When tools have parameters with mode='fast', the tool handler's return value "
            "is used directly as the assistant message in fast mode."
        ),
        "value": {
            "user_input": "Track my order",
            "state": {
                "fast_tool_params": {
                    "lookup_order": {
                        "order_id": "A-99",
                        "order_success": "Custom success message for this order.",
                    },
                },
            },
        },
    },
}

CREATE_SESSION_OPENAPI_EXAMPLE = {
    "summary": "Create a swarm session",
    "value": {
        "session_id": "session-1",
        "swarm": {
            "id": "single-agent",
            "name": "Single Agent",
            "nodes": [
                {
                    "node_key": "assistant",
                    "name": "Assistant",
                    "system_prompt": "You are a helpful assistant.",
                    "is_entry_node": True,
                }
            ],
            "edges": [],
            "variables": [],
        },
        "state": {"account_id": "ACME-991"},
    },
}


class SwarmVariablePayload(BaseModel):
    key_name: str
    description: str = ""
    reducer_rule: str = "overwrite"


class SwarmEdgePayload(BaseModel):
    source_node_key: str
    target_node_key: str
    handoff_description: str
    required_variables: List[str] = Field(default_factory=list)


class SwarmNodeSubAgentPayload(BaseModel):
    sub_agent: str
    handoff_description: str
    required_variables: List[str] = Field(default_factory=list)


class SwarmNodePayload(BaseModel):
    node_key: str
    name: str
    system_prompt: str = ""
    intent: str = ""
    capabilities: List[str] = Field(default_factory=list)
    persona: str = ""
    model_choice: str = ""
    enabled_tools: List[Dict[str, Any]] = Field(default_factory=list)
    sub_agents: List[SwarmNodeSubAgentPayload] = Field(default_factory=list)
    behavior_config: Dict[str, Any] = Field(default_factory=dict)
    is_entry_node: bool = False


class SwarmDefinitionPayload(BaseModel):
    id: str = "swarm"
    name: str = "Swarm"
    graph_version: int = 1
    nodes: List[SwarmNodePayload]
    edges: List[SwarmEdgePayload] = Field(default_factory=list)
    variables: List[SwarmVariablePayload] = Field(default_factory=list)

    def to_runtime(self):
        return build_swarm_definition(
            {
                "nodes": [node.model_dump(mode="python") for node in self.nodes],
                "edges": [edge.model_dump(mode="python") for edge in self.edges],
                "variables": [variable.model_dump(mode="python") for variable in self.variables],
            },
            swarm_id=self.id,
            name=self.name,
            graph_version=self.graph_version,
        )


class VariableInjectionPayload(BaseModel):
    state: Dict[str, Any] = Field(
        default_factory=dict,
        validation_alias=AliasChoices("state", "variables", "global_variables"),
    )

    @property
    def variables(self) -> Dict[str, Any]:
        return self.state

    @property
    def global_variables(self) -> Dict[str, Any]:
        return self.state


class TurnVariableInjectionPayload(VariableInjectionPayload):
    pass


class CreateSessionRequest(VariableInjectionPayload):
    session_id: str | None = None
    swarm: SwarmDefinitionPayload


class SendMessageRequest(TurnVariableInjectionPayload):
    user_input: UserInputContent


class RunSwarmRequest(VariableInjectionPayload):
    session_id: str | None = None
    swarm: SwarmDefinitionPayload
    user_input: UserInputContent


class CreateConfiguredSessionRequest(VariableInjectionPayload):
    session_id: str | None = None


class SessionVariableUpdateRequest(BaseModel):
    state: Dict[str, Any] = Field(
        default_factory=dict,
        validation_alias=AliasChoices("state", "values", "variables", "global_variables"),
    )
    mode: str = Field(
        default="merge",
        validation_alias=AliasChoices("mode", "state_mode", "variable_mode", "global_variable_mode"),
    )

    @property
    def values(self) -> Dict[str, Any]:
        return self.state

    @property
    def variables(self) -> Dict[str, Any]:
        return self.state

    @property
    def global_variables(self) -> Dict[str, Any]:
        return self.state
