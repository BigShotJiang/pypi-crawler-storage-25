"""Python SDK for authoring, running, and evaluating multi-agent systems."""

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

_SOURCE_VERSION = "3.0.11"
_PYPROJECT_PATH = Path(__file__).resolve().parents[2] / "pyproject.toml"

if _PYPROJECT_PATH.exists():
    __version__ = _SOURCE_VERSION
else:
    try:
        __version__ = version("swarmforge")
    except PackageNotFoundError:  # pragma: no cover - source tree fallback
        __version__ = _SOURCE_VERSION

__all__ = ["api", "authoring", "evaluation", "swarm"]
