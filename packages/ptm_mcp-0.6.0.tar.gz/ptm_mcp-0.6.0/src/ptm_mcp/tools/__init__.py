"""Tool registry for ptm-mcp.

The ``mcp`` SDK wires tools through a single ``@server.list_tools()`` +
``@server.call_tool()`` decorator pair per ``Server`` instance. This
registry centralizes the dispatch so every tool file can stay focused on
schema + argument handling.

Commit 3 additions:
- Write-tool files (``evals``, ``optimization_writes``) export a
  ``specs(settings)`` function so handlers can close over the
  ``Settings.read_only`` flag for the gate check.
- Module-level ``TOOL_SPECS`` is built eagerly with a default
  ``read_only=True`` settings so CI smoke checks (``len(TOOL_SPECS)``)
  do not require any env vars to import the module.
- ``register_tools(server, client, settings=None)`` accepts an explicit
  ``Settings`` at server bootstrap; the server.run() call threads the
  real settings through from ``load_settings``.

Adding a tool:
  1. Drop a new module under ``tools/`` with a ``specs()`` (read) or
     ``specs(settings)`` (write) function returning
     ``list[tuple[Tool, async handler]]``.
  2. Add the module's call to ``_build_tool_specs`` below.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

from mcp.server import Server
from mcp.types import TextContent, Tool
from ptm_client import PTMClient

from ..config import Settings
from . import (
    evals,
    optimization,
    optimization_writes,
    prompts,
    prompts_write,
    providers,
    registry,
    runs,
    versions,
)

ToolHandler = Callable[[PTMClient, dict[str, Any]], Awaitable[Any]]


def _build_tool_specs(settings: Settings) -> list[tuple[Tool, ToolHandler]]:
    """Eager aggregation of every tool spec. Write modules get ``settings``."""
    return [
        *providers.specs(),
        *prompts.specs(),
        *versions.specs(),
        *runs.specs(),
        *optimization.specs(),
        *registry.specs(settings),
        *evals.specs(settings),
        *optimization_writes.specs(settings),
        *prompts_write.specs(settings),
    ]


# Module-level registry built with a default ``read_only=True`` Settings
# so import-time smoke checks do not require PTM_API_BASE_URL/TOKEN to
# count tools. The server-bootstrap path in server.py passes the real
# ``Settings`` through ``register_tools`` and rebuilds the registry there.
_DEFAULT_SETTINGS = Settings(
    ptm_api_base_url="http://smoke.invalid",
    ptm_api_token="smoke",
    read_only=True,
)
TOOL_SPECS: list[tuple[Tool, ToolHandler]] = _build_tool_specs(_DEFAULT_SETTINGS)


def _render_result(result: Any) -> str:
    """Pass strings through verbatim (reports, diffs); JSON-encode everything else."""
    if isinstance(result, str):
        return result
    return json.dumps(result, indent=2, default=str)


def register_tools(
    server: Server,
    client: PTMClient,
    settings: Settings | None = None,
) -> None:
    """Register all ptm-mcp tools on the given server.

    ``settings`` is required for the write-tool read-only gate. When omitted
    (older call sites / tests), the module-level default is used.
    """
    effective_settings = settings or _DEFAULT_SETTINGS
    specs = _build_tool_specs(effective_settings)
    schemas = [spec for spec, _ in specs]
    handlers: dict[str, ToolHandler] = {spec.name: handler for spec, handler in specs}

    @server.list_tools()
    async def _list_tools() -> list[Tool]:
        return schemas

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        handler = handlers.get(name)
        if handler is None:
            raise ValueError(f"Unknown tool: {name}")
        result = await handler(client, arguments or {})
        return [TextContent(type="text", text=_render_result(result))]


__all__ = ["TOOL_SPECS", "ToolHandler", "register_tools"]
