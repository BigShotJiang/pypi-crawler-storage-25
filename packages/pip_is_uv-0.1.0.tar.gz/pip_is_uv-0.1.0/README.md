# pip-is-uv

Stub package that replaces `pip` with [`uv pip`](https://docs.astral.sh/uv/pip/) inside a virtual environment.  All invocation paths are intercepted:

- `pip` / `pip3` scripts
- `python -m pip`
- `import pip; pip.main(...)` (legacy API)

## Requirements

[uv](https://docs.astral.sh/uv/) must be installed and available on `PATH`, or present in the same `bin/` directory as the Python interpreter (e.g., `uv` installed into the venv alongside this package).

## How it works

`pip-is-uv` installs a `pip` Python package that shadows the real pip.  When any pip entry point is invoked, it locates the `uv` binary and calls `uv pip` with all arguments passed through unchanged, replacing the current process (`execvp` on Unix, subprocess on Windows).

## Limitations

- Commands not supported by `uv pip` (e.g., `pip wheel`, `pip hash`) will fail with an error from uv.
- `uv` must be installed separately; this package does not depend on it.
