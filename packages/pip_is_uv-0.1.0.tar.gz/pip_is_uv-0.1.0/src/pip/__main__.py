"""Entry point for ``python -m pip`` and the ``pip``/``pip3`` scripts."""

import os
import shutil
import sys


def _find_uv():
    # Prefer uv installed alongside this Python (e.g. inside the same venv)
    venv_bin = os.path.dirname(os.path.abspath(sys.executable))
    candidate = os.path.join(venv_bin, "uv")
    if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
        return candidate
    found = shutil.which("uv")
    if found:
        return found
    raise SystemExit(
        "pip-is-uv: uv not found. Install uv: https://docs.astral.sh/uv/"
    )


def main():
    uv = _find_uv()
    argv = ["uv", "pip"] + sys.argv[1:]
    if os.name == "nt":
        import subprocess
        sys.exit(subprocess.call(argv, executable=uv))
    else:
        os.execvp(uv, argv)


if __name__ == "__main__":
    main()
