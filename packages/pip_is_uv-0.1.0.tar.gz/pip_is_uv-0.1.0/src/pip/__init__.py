"""Stub pip package that delegates all operations to uv pip.

Provided for compatibility with tools that import pip directly (e.g.,
``import pip; pip.main(...)``). For normal usage, invoke via the ``pip``
script or ``python -m pip``.
"""

# Hardcoded to a plausible recent pip version. Tools checking __version__
# may reject non-numeric values.
__version__ = "25.0"


def main():
    from pip.__main__ import main as _main
    _main()
