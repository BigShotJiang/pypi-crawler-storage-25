class LoginError(Exception):
    pass
