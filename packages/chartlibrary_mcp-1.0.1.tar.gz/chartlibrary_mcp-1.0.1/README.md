# Chart Library MCP Server

Give your AI agent 10 years of chart pattern intelligence. Search 24 million historical patterns and see what happened next.

## Install

```bash
pip install chartlibrary-mcp
```

## Usage with Claude

```bash
# Claude Code
claude mcp add chart-library -- chartlibrary-mcp

# Or run directly
CHART_LIBRARY_API_KEY=cl_your_key chartlibrary-mcp
```

## Tools

| Tool | Description |
|------|-------------|
| `analyze_pattern` | Search + forward returns + AI summary (recommended) |
| `search_charts` | Find 10 most similar historical patterns |
| `get_follow_through` | Forward returns (1/3/5/10-day) for matches |
| `get_pattern_summary` | AI-generated plain-English summary |
| `get_discover_picks` | Daily top patterns ranked by interest score |
| `search_batch` | Multi-symbol parallel search (up to 20) |
| `get_status` | Database stats and coverage |

## Example Conversation

> **User:** What does NVDA's chart look like right now?
>
> **Claude (using Chart Library):** NVDA's current pattern matches 10 historical setups. The closest is AAPL from May 2016 (93% similarity). Of the 10 matches, 8 went up over 5 days with an average gain of +3.0%. The current market regime resembles the post-SVB period of early 2023, which historically resolved bullishly.

## API Key

Get a free API key (500 calls/day) at [chartlibrary.io/developers](https://chartlibrary.io/developers).

Set it as an environment variable:
```bash
export CHART_LIBRARY_API_KEY=cl_your_key
```

## Links

- Website: [chartlibrary.io](https://chartlibrary.io)
- API Docs: [chartlibrary.io/api/docs](https://chartlibrary.io/api/docs)
- Developer Portal: [chartlibrary.io/developers](https://chartlibrary.io/developers)
- Regime Tracker: [chartlibrary.io/regime](https://chartlibrary.io/regime)

<!-- mcp-name: io.github.grahammccain/chart-library -->
