import requests
import time

ADS_BASE_URLS = {
    'NA': 'https://advertising-api.amazon.com',
    'EU': 'https://advertising-api-eu.amazon.com',
    'FE': 'https://advertising-api-fe.amazon.com',
}


def zv_ads_client_access(username, region):
    """
    Authentication process for Amazon Ads API.
    Only works for ZV Data Automation Clients.

    Parameters:
    - username: the client's registered username on zvdataautomation.com
    - region: 'NA', 'EU', or 'FE'

    Returns:
    - dict with 'access_token' and 'client_id'
    """
    url = "https://zvdataautomation.com/zvadsauth/"
    payload = {"username": username, "region": region}
    response = requests.post(url, json=payload)

    if response.status_code == 200:
        data = response.json()
        print('Ads Access Token granted 1 hour validity.')
        return {'access_token': data['access_token'], 'client_id': data['client_id']}
    else:
        error_msg = response.json().get('error', 'Not Authenticated')
        raise ValueError(f'Error: {error_msg}')


def get_ads_profiles(access_token, client_id, region):
    """
    Returns all Amazon Ads profiles tied to the authenticated account.
    Use this to find the profileId needed for all other Ads API calls.

    Parameters:
    - access_token: from zv_ads_client_access()
    - client_id: from zv_ads_client_access()
    - region: 'NA', 'EU', or 'FE'

    Returns:
    - list of profile dicts (profileId, countryCode, accountInfo, etc.)
    """
    base_url = ADS_BASE_URLS[region]
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Amazon-Advertising-API-ClientId': client_id,
        'Content-Type': 'application/json',
    }
    response = requests.get(f'{base_url}/v2/profiles', headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        raise ValueError(f'get_ads_profiles failed: {response.status_code} - {response.text}')
