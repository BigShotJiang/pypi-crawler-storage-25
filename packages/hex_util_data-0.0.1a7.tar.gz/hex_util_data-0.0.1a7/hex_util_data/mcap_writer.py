#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-14
################################################################

import os, time, threading, traceback
import foxglove
import cv2
import numpy as np
from typing import Any
from collections import deque
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from foxglove.schemas import Timestamp, CompressedImage
from hex_util_runtime import ns_now, ns_to_hex_ts


class HexMcapWriter:

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8765,
    ):
        self.__record_time = None
        self.__record_cnt = {"color": 0, "depth": 0, "state": 0, "single": {}}
        self.__record_ts = {}

        self.__mcap_ctx = None
        self.__exit_stack = None
        self.__is_recording = threading.Event()

        self.__msg_queue = deque(maxlen=10240)
        self.__queue_event = threading.Event()
        self.__queue_event.clear()

        self.__encode_pool = ThreadPoolExecutor(max_workers=4)
        self.__stop_event = threading.Event()
        self.__stop_event.clear()

        self.__worker = threading.Thread(
            target=self.__worker_loop,
            daemon=True,
        )

        self.__foxglove_lock = threading.Lock()
        self.__server = foxglove.start_server(
            host=host,
            port=port,
            channel_filter=lambda ch: not ch.topic.endswith("depth"),
        )
        self.__worker.start()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def close(self):
        if self.__stop_event.is_set():
            return
        self.__stop_event.set()
        self.__queue_event.set()

        if self.__worker.is_alive():
            self.__worker.join()
            if self.__worker.is_alive():
                print("[HexMcapWriter] worker did not exit in time")

        self.__encode_pool.shutdown(wait=True, cancel_futures=True)
        self.stop_record()
        self.__server.stop()

    def start_record(self, path: str, name: str = "hex"):
        with self.__foxglove_lock:
            if self.__is_recording.is_set():
                return
            self.__is_recording.set()

            os.makedirs(path, exist_ok=True)
            mcap_path = f"{path}/{name}.mcap"
            if os.path.exists(mcap_path):
                os.remove(mcap_path)

            self.__exit_stack = ExitStack()
            self.__mcap_ctx = self.__exit_stack.enter_context(
                foxglove.open_mcap(
                    mcap_path,
                    channel_filter=lambda ch: not ch.topic.endswith(
                        "depth_cmap"),
                ))
            self.__record_time = ns_now()
            self.__record_cnt = {
                "color": 0,
                "depth": 0,
                "state": 0,
                "single": {},
            }
            self.__record_ts = {}

    def stop_record(self):
        with self.__foxglove_lock:
            print("stop_record")
            if not self.__is_recording.is_set():
                return
            self.__is_recording.clear()

            end_time = ns_now()
            if self.__exit_stack is not None:
                self.__exit_stack.close()
                self.__exit_stack = None
                self.__mcap_ctx = None

            self.__summary(end_time)
            print("Recording stopped")
            print("#" * 50)

    def append_data(self, data: dict[str, Any]):
        if self.__stop_event.is_set():
            return

        item = (ns_now(), data)
        self.__msg_queue.append(item)
        self.__queue_event.set()

    def __summary(self, end_time=None):
        record_cnt = {
            "color": self.__record_cnt["color"],
            "depth": self.__record_cnt["depth"],
            "state": self.__record_cnt["state"],
            "single": dict(self.__record_cnt["single"]),
        }
        record_ts = {k: dict(v) for k, v in self.__record_ts.items()}

        print("#" * 50)
        if end_time is not None and self.__record_time is not None:
            duration = (end_time - self.__record_time) * 1e-9
            print(f"Record duration: {duration:.2f}s")

        total_count = (record_cnt["color"] + record_cnt["depth"] +
                       record_cnt["state"])
        print(f"Record total count: {total_count}")
        print(f"--Record color count: {record_cnt['color']}")
        print(f"--Record depth count: {record_cnt['depth']}")
        print(f"--Record state count: {record_cnt['state']}")

        for key, value in record_cnt["single"].items():
            hz_str = ""
            ts = record_ts.get(key)
            if ts is not None:
                topic_dur = (ts["last"] - ts["first"]) * 1e-9
                if topic_dur > 0:
                    hz_str = f", Hz: {(value - 1) / topic_dur:.3f}"
            print(f"----Record {key} count: {value}{hz_str}")
        print("#" * 50)

    def __worker_loop(self):
        print_cnt = 0
        print_interval = 10_000

        while not self.__stop_event.is_set():
            try:
                item = self.__msg_queue.popleft()
            except IndexError:
                self.__queue_event.clear()
                if len(self.__msg_queue) > 0:
                    continue
                self.__queue_event.wait(timeout=0.1)
                continue

            try:
                get_ts, data_dict = item
                self.__process_data(get_ts, data_dict)

                if self.__is_recording.is_set():
                    print_cnt += 1
                    if print_cnt >= print_interval:
                        print_cnt = 0
                        self.__summary()
                else:
                    print_cnt = 0
            except Exception as e:
                print(f"[HexMcapWriter] worker error: {e}")
                traceback.print_exc()
                time.sleep(0.001)

    def __process_data(self, get_ts, data_dict):
        for key, value in data_dict.items():
            if key == "ts_ns":
                continue
            elif key.endswith("state"):
                self.__log_state(key, value, get_ts)
            elif key.endswith("color"):
                self.__encode_pool.submit(self.__safe_call, self.__log_color,
                                          key, value, get_ts)
            elif key.endswith("depth"):
                self.__encode_pool.submit(self.__safe_call, self.__log_depth,
                                          key, value, get_ts)
            else:
                print(f"Warning: unsupported data type: {key}")

    def __safe_call(self, fn, *args, **kwargs):
        if self.__stop_event.is_set():
            return
        try:
            fn(*args, **kwargs)
        except Exception as e:
            print(f"[HexMcapWriter] async task error: {e}")
            traceback.print_exc()

    def __foxglove_log(self, topic, msg, log_time, category):
        if self.__stop_event.is_set():
            return
        with self.__foxglove_lock:
            foxglove.log(topic, msg, log_time=log_time)
            if category == "cmap":
                return

            if self.__is_recording.is_set():
                self.__record_cnt[category] += 1
                self.__record_cnt["single"][topic] = (
                    self.__record_cnt["single"].get(topic, 0) + 1)
                if topic not in self.__record_ts:
                    self.__record_ts[topic] = {
                        "first": log_time,
                        "last": log_time,
                    }
                else:
                    self.__record_ts[topic]["last"] = log_time

    def __log_state(self, topic, state_msg, get_ts):
        msg = {}
        for key in state_msg.dtype.names:
            if key == "ts_ns":
                hex_ts = ns_to_hex_ts(int(state_msg["ts_ns"]))
                msg["timestamp"] = {"sec": hex_ts["s"], "nsec": hex_ts["ns"]}
            else:
                msg[key] = state_msg[key].tolist()

        self.__foxglove_log(topic, msg, get_ts, "state")

    def __log_color(self, topic, color_msg, get_ts):
        color = color_msg["data"]
        if color is None:
            return

        ok, buf = cv2.imencode(
            ".jpg",
            color,
            [cv2.IMWRITE_JPEG_QUALITY, 75],
        )
        if not ok:
            return

        hex_ts = ns_to_hex_ts(color_msg["ts_ns"])
        msg = CompressedImage(
            timestamp=Timestamp(sec=hex_ts["s"], nsec=hex_ts["ns"]),
            format="jpeg",
            data=buf.tobytes(),
        )
        self.__foxglove_log(topic, msg, get_ts, "color")

    def __log_depth(self, topic, depth_msg, get_ts):
        depth = depth_msg["data"]
        if depth is None:
            return

        hex_ts = ns_to_hex_ts(depth_msg["ts_ns"])
        ts = Timestamp(sec=hex_ts["s"], nsec=hex_ts["ns"])

        # cmap
        resized_depth = cv2.resize(
            depth,
            (depth.shape[1] // 8, depth.shape[0] // 8),
            interpolation=cv2.INTER_NEAREST,
        )
        buf_f = resized_depth.astype(np.float32)
        np.subtract(buf_f, 70.0, out=buf_f)
        np.multiply(buf_f, 0.274193548, out=buf_f)
        np.clip(buf_f, 0.0, 255.0, out=buf_f)
        cmap = cv2.applyColorMap(buf_f.astype(np.uint8), cv2.COLORMAP_JET)

        ok, buf = cv2.imencode(
            ".jpg",
            cmap,
            [cv2.IMWRITE_JPEG_QUALITY, 75],
        )
        if not ok:
            return

        msg = CompressedImage(
            timestamp=ts,
            format="jpeg",
            data=buf.tobytes(),
        )
        self.__foxglove_log(f"{topic}_cmap", msg, get_ts, "cmap")

        # compressed depth
        if self.__is_recording.is_set():
            ok, buf = cv2.imencode(
                ".png",
                depth,
                [cv2.IMWRITE_PNG_COMPRESSION, 1],
            )
            if not ok:
                return

            msg = CompressedImage(
                timestamp=ts,
                format="png",
                data=buf.tobytes(),
            )
            self.__foxglove_log(topic, msg, get_ts, "depth")
