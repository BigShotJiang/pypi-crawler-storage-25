#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-07
################################################################

import os, sys
import numpy as np

try:
    from hex_util_data import HexMcapReader
except ImportError:
    sys.path.insert(
        0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from hex_util_data import HexMcapReader

# DEFAULT_MCAP = os.path.join(os.path.abspath("multi_arm_rgbd"),
#                             "mcap_data.mcap")
DEFAULT_MCAP = os.path.join(os.path.abspath("multi_arm_rgbd"),
                            "episode_000001.mcap")

JNT_NUM = 40
COLOR_SHAPE = (480, 640, 3)
DEPTH_SHAPE = (480, 640)


def main():
    mcap_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_MCAP
    assert os.path.exists(mcap_path), f"MCAP not found: {mcap_path}"

    print(f"Reading MCAP: {mcap_path}")
    reader = HexMcapReader(mcap_path)
    reader.summary()

    print(f"  topic_dict keys = {reader.topic_dict()}")
    print("=" * 5 + " right_arm_state " + "=" * 35)
    state_data = reader.get_data('right_arm_state')
    print(f"  get_data state: len = {len(state_data)}")
    print(state_data[0])

    print("=" * 5 + " left_color " + "=" * 35)
    color_data = reader.get_data('left_color')
    print(f"  get_data color: len = {len(color_data)}")
    print(color_data[0])

    print("=" * 5 + " head_depth " + "=" * 35)
    depth_data = reader.get_data('head_depth')
    print(f"  get_data depth: len = {len(depth_data)}")
    print(depth_data[0])

    print("=" * 5 + " not exist " + "=" * 35)
    print(
        f"  get_data not exist: len = {len(reader.get_data('nonexistent/topic'))}"
    )
    print("=" * 50)


if __name__ == '__main__':
    main()
