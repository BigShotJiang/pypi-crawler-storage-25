"""PA-CONF* — Configuration security scanner."""

import hashlib
import os
import re
import stat
from pathlib import Path
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class ConfScanner(BaseScanner):
    category = Category.CONF
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        all_checks = {
            "PA-CONF01": self._conf01_file_permissions,
            "PA-CONF02": self._conf02_dangerous_flags,
            "PA-CONF03": self._conf03_shell_allowlist,
            "PA-CONF04": self._conf04_baseline_drift,
            "PA-CONF05": self._conf05_cors_wildcard,
        }
        return self._dispatch(all_checks, checks)

    # ------------------------------------------------------------------
    # PA-CONF01: Config file permissions too open
    # ------------------------------------------------------------------
    def _conf01_file_permissions(self, needs):
        check_id = "PA-CONF01"
        title = "Config file permissions too open"
        remediation = needs.get("remediation", "")
        bad_files = []
        bad_paths = []

        match = self._get_match(needs)
        for f in match.get("paths", []):
            if not f.is_file():
                continue
            try:
                st = f.stat()
                mode = st.st_mode
                # Check if group or others have any read/write/execute
                if mode & (stat.S_IRGRP | stat.S_IWGRP | stat.S_IXGRP |
                           stat.S_IROTH | stat.S_IWOTH | stat.S_IXOTH):
                    perm = oct(mode & 0o777)
                    bad_files.append(f"{f.name} ({perm})")
                    bad_paths.append(str(f))
            except OSError:
                continue

        if bad_files:
            fix_actions = [
                FixAction(
                    description=f"chmod 600 {path}",
                    fix_type="command",
                    command=f"chmod 600 {path}",
                )
                for path in bad_paths
            ]
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Loose permissions: {', '.join(bad_files)}",
                             remediation=remediation or "chmod 600 on config files",
                             fix_actions=fix_actions)
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-CONF02: dangerously*/insecure* flags
    # ------------------------------------------------------------------
    # Flags already covered by AUTH02 — skip to avoid duplicate reports
    _AUTH02_FLAGS = {"dangerouslydisabledeviceauth", "allowinsecureauth"}

    def _conf02_dangerous_flags(self, needs):
        check_id = "PA-CONF02"
        title = "Dangerous configuration flags enabled"
        remediation = needs.get("remediation", "")

        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        pat_str = patterns[0] if patterns else r'(["\']?(dangerously\w+|insecure\w+)["\']?\s*[:=]\s*["\']?)(true|yes|1|enabled)(["\']?)'

        pattern = re.compile(pat_str, re.IGNORECASE)
        found_flags = []
        fix_actions = []

        for f in match.get("paths", []):
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for m in pattern.finditer(text):
                flag_name = m.group(2)
                if flag_name.lower() in self._AUTH02_FLAGS:
                    continue
                found_flags.append(f"{flag_name}={m.group(3)} in {f.name}")
                fix_actions.append(FixAction(
                    description=f"Set {flag_name} to false in {f.name}",
                    fix_type="file_edit",
                    target_file=str(f),
                    old_value=m.group(0),
                    new_value=m.group(1) + "false" + m.group(4),
                ))

        if found_flags:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(found_flags),
                             remediation=remediation or "Disable all dangerously*/insecure* flags",
                             fix_actions=fix_actions)
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-CONF03: Shell command allowlist missing
    # ------------------------------------------------------------------
    def _conf03_shell_allowlist(self, needs):
        check_id = "PA-CONF03"
        title = "Shell command allowlist (safeBins) not configured"
        remediation = needs.get("remediation", "")

        match = self._get_match(needs)
        for f in match.get("paths", []):
            try:
                config = self.discovery.read_config(f)
            except Exception:
                continue
            safe_bins = config.get("tools", {}).get("exec", {}).get("safeBins")
            if isinstance(safe_bins, list) and len(safe_bins) > 0:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                                 detail=f"safeBins configured with {len(safe_bins)} command(s) in {f.name}")
                return

        self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                         remediation=remediation or "Configure safeBins under tools.exec to restrict shell execution",
                         fix_actions=[
                             FixAction(
                                 description="Configure shell command allowlist",
                                 fix_type="manual",
                                 manual_steps=(
                                     'Add a safeBins allowlist to openclaw.json under tools.exec. Example:\n'
                                     '  "tools": {"exec": {"safeBins": ["jq", "cut", "uniq", "head", "tail", "tr", "wc"]}}\n'
                                     'Only include commands your agents actually need. '
                                     'This prevents agents from executing arbitrary shell commands.'
                                 ),
                             ),
                         ])

    # ------------------------------------------------------------------
    # PA-CONF04: Config baseline drift
    # ------------------------------------------------------------------
    def _conf04_baseline_drift(self, needs):
        check_id = "PA-CONF04"
        title = "Configuration baseline drift"
        remediation = needs.get("remediation", "")

        match = self._get_match(needs)
        match_paths = match.get("paths", [])
        if not match_paths:
            self.skip(check_id, title, Severity.HIGH,
                      "No baseline directory configured")
            return
        baseline_file = match_paths[0] / "config-baseline.sha256"
        if not baseline_file.is_file():
            self.skip(check_id, title, Severity.HIGH,
                      "No baseline file found. Run: clawaudit baseline init")
            return

        # Compare current hashes to baseline
        try:
            raw = baseline_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            self.skip(check_id, title, Severity.HIGH,
                      "Cannot read baseline file")
            return

        baseline_data = {}
        for line in raw.splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2 and len(parts[0]) == 64:
                baseline_data[parts[1]] = parts[0]

        if not baseline_data:
            self.skip(check_id, title, Severity.HIGH,
                      "Baseline file is empty or corrupted. Run: clawaudit baseline init")
            return

        drifted = []
        for path_str, expected_hash in baseline_data.items():
            p = Path(path_str)
            if not p.is_file():
                drifted.append(f"missing: {path_str}")
                continue
            actual = hashlib.sha256(p.read_bytes()).hexdigest()
            if actual != expected_hash:
                drifted.append(f"changed: {path_str}")

        if drifted:
            drift_detail = "; ".join(drifted)
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=drift_detail,
                             remediation=remediation or "Review config changes and update baseline",
                             fix_actions=[
                                 FixAction(
                                     description="Review configuration drift",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Detected {len(drifted)} file(s) drifted from baseline:\n"
                                         + "\n".join(f"  - {d}" for d in drifted) + "\n"
                                         "Step 1: Review each changed file to confirm changes are intentional.\n"
                                         "Step 2: If changes are legitimate, update baseline: clawaudit baseline init\n"
                                         "Step 3: If changes are unauthorized, restore from backup and investigate."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="Config matches baseline")

    # ------------------------------------------------------------------
    # PA-CONF05: Gateway CORS allowedOrigins wildcard
    # ------------------------------------------------------------------
    def _conf05_cors_wildcard(self, needs):
        check_id = "PA-CONF05"
        title = "Gateway CORS allowedOrigins wildcard"
        remediation = needs.get("remediation", "")

        match = self._get_match(needs)
        offenders = []
        checked = False

        for f in match.get("paths", []):
            try:
                config = self.discovery.read_config(f)
            except Exception:
                continue
            checked = True
            origins = config.get("gateway", {}).get("allowedOrigins")
            if isinstance(origins, list) and any(o == "*" for o in origins):
                offenders.append(f.name)
            elif origins == "*":
                offenders.append(f.name)

        if not checked:
            self.skip(check_id, title, Severity.HIGH, "No config file found")
            return

        if offenders:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"gateway.allowedOrigins contains '*' in: {', '.join(offenders)}",
                             remediation=remediation or "Replace '*' with explicit trusted origins",
                             fix_actions=[
                                 FixAction(
                                     description="Restrict gateway CORS origins",
                                     fix_type="manual",
                                     manual_steps=(
                                         'Edit openclaw.json and replace gateway.allowedOrigins with an explicit allowlist, e.g.:\n'
                                         '  "gateway": {"allowedOrigins": ["https://console.example.com"]}\n'
                                         'Wildcard "*" lets any origin call the gateway from a browser context.'
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")
