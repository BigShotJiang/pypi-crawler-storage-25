# undisk-mcp

> [!TIP]
> Home: https://mcp.undisk.app
> Issues: https://github.com/kiarashplusplus/undisk-mcp-tracker/issues

Python SDK for [Undisk MCP](https://mcp.undisk.app) — undo-first versioned file storage for AI agents.

## Install

```bash
pip install undisk-mcp
```

## Quick Start

```python
import asyncio
from undisk_mcp import UndiskClient

async def main():
    async with UndiskClient(api_key="your-api-key") as client:
        await client.initialize()

        # Write a file
        await client.write_file("hello.txt", "Hello from Python!")

        # Read it back
        result = await client.read_file("hello.txt")
        print(result.text)

        # List all files
        files = await client.list_files()
        print(files.text)

asyncio.run(main())
```

## Features

- **Typed client** with convenience methods for common MCP tools
- **Session management** (automatic `Mcp-Session-Id` tracking)
- **Retry with exponential backoff** (configurable)
- **Async-first** design using `httpx`
- **Context manager** support (`async with`)

## API Reference

### UndiskClient

```python
client = UndiskClient(
    api_key="your-key",
    endpoint="https://mcp.undisk.app",  # default
    max_retries=3,                       # default
    timeout=60.0,                        # default
)
```

### Methods

| Method | Description |
|--------|-------------|
| `initialize()` | Initialize MCP session |
| `call_tool(name, args)` | Call any MCP tool by name |
| `read_file(path)` | Read a file |
| `write_file(path, content)` | Write a file |
| `create_file(path, content)` | Create a new file (fails if exists) |
| `list_files(path)` | List files |
| `delete_file(path)` | Delete a file |
| `move_file(from_path, to_path)` | Move or rename a file |
| `search_files(pattern)` | Search file contents |
| `list_versions(path)` | Get version history |
| `restore_version(path, version_id)` | Restore a version |
| `get_diff(path, from_version, to_version)` | Compare two versions |
| `append_log(path, content)` | Append to a log file |
| `close()` | Close the client |

## License

MIT
