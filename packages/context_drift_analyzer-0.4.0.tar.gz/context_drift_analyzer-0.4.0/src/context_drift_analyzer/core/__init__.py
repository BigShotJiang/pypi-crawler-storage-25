"""Core drift analysis engine."""
