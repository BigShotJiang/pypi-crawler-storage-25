from buf.validate import validate_pb2 as _validate_pb2
from flyteidl2.common import identifier_pb2 as _identifier_pb2
from flyteidl2.common import list_pb2 as _list_pb2
from flyteidl2.common import run_pb2 as _run_pb2
from flyteidl2.task import common_pb2 as _common_pb2
from flyteidl2.task import run_pb2 as _run_pb2_1
from flyteidl2.task import task_definition_pb2 as _task_definition_pb2
from flyteidl2.workflow import run_definition_pb2 as _run_definition_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateRunRequest(_message.Message):
    __slots__ = ["run_id", "project_id", "task_id", "task_spec", "trigger_name", "inputs", "offloaded_input_data", "run_spec", "source"]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_SPEC_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_NAME_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    OFFLOADED_INPUT_DATA_FIELD_NUMBER: _ClassVar[int]
    RUN_SPEC_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    run_id: _identifier_pb2.RunIdentifier
    project_id: _identifier_pb2.ProjectIdentifier
    task_id: _task_definition_pb2.TaskIdentifier
    task_spec: _task_definition_pb2.TaskSpec
    trigger_name: _identifier_pb2.TriggerName
    inputs: _common_pb2.Inputs
    offloaded_input_data: _run_pb2.OffloadedInputData
    run_spec: _run_pb2_1.RunSpec
    source: _run_definition_pb2.RunSource
    def __init__(self, run_id: _Optional[_Union[_identifier_pb2.RunIdentifier, _Mapping]] = ..., project_id: _Optional[_Union[_identifier_pb2.ProjectIdentifier, _Mapping]] = ..., task_id: _Optional[_Union[_task_definition_pb2.TaskIdentifier, _Mapping]] = ..., task_spec: _Optional[_Union[_task_definition_pb2.TaskSpec, _Mapping]] = ..., trigger_name: _Optional[_Union[_identifier_pb2.TriggerName, _Mapping]] = ..., inputs: _Optional[_Union[_common_pb2.Inputs, _Mapping]] = ..., offloaded_input_data: _Optional[_Union[_run_pb2.OffloadedInputData, _Mapping]] = ..., run_spec: _Optional[_Union[_run_pb2_1.RunSpec, _Mapping]] = ..., source: _Optional[_Union[_run_definition_pb2.RunSource, str]] = ...) -> None: ...

class CreateRunResponse(_message.Message):
    __slots__ = ["run"]
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: _run_definition_pb2.Run
    def __init__(self, run: _Optional[_Union[_run_definition_pb2.Run, _Mapping]] = ...) -> None: ...

class AbortRunRequest(_message.Message):
    __slots__ = ["run_id", "reason"]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    run_id: _identifier_pb2.RunIdentifier
    reason: str
    def __init__(self, run_id: _Optional[_Union[_identifier_pb2.RunIdentifier, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class AbortRunResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class GetRunDetailsRequest(_message.Message):
    __slots__ = ["run_id"]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: _identifier_pb2.RunIdentifier
    def __init__(self, run_id: _Optional[_Union[_identifier_pb2.RunIdentifier, _Mapping]] = ...) -> None: ...

class GetRunDetailsResponse(_message.Message):
    __slots__ = ["details"]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    details: _run_definition_pb2.RunDetails
    def __init__(self, details: _Optional[_Union[_run_definition_pb2.RunDetails, _Mapping]] = ...) -> None: ...

class WatchRunDetailsRequest(_message.Message):
    __slots__ = ["run_id"]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: _identifier_pb2.RunIdentifier
    def __init__(self, run_id: _Optional[_Union[_identifier_pb2.RunIdentifier, _Mapping]] = ...) -> None: ...

class WatchRunDetailsResponse(_message.Message):
    __slots__ = ["details"]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    details: _run_definition_pb2.RunDetails
    def __init__(self, details: _Optional[_Union[_run_definition_pb2.RunDetails, _Mapping]] = ...) -> None: ...

class GetActionDetailsRequest(_message.Message):
    __slots__ = ["action_id"]
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    action_id: _identifier_pb2.ActionIdentifier
    def __init__(self, action_id: _Optional[_Union[_identifier_pb2.ActionIdentifier, _Mapping]] = ...) -> None: ...

class GetActionDetailsResponse(_message.Message):
    __slots__ = ["details"]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    details: _run_definition_pb2.ActionDetails
    def __init__(self, details: _Optional[_Union[_run_definition_pb2.ActionDetails, _Mapping]] = ...) -> None: ...

class WatchActionDetailsRequest(_message.Message):
    __slots__ = ["action_id"]
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    action_id: _identifier_pb2.ActionIdentifier
    def __init__(self, action_id: _Optional[_Union[_identifier_pb2.ActionIdentifier, _Mapping]] = ...) -> None: ...

class WatchActionDetailsResponse(_message.Message):
    __slots__ = ["details"]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    details: _run_definition_pb2.ActionDetails
    def __init__(self, details: _Optional[_Union[_run_definition_pb2.ActionDetails, _Mapping]] = ...) -> None: ...

class GetActionDataRequest(_message.Message):
    __slots__ = ["action_id"]
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    action_id: _identifier_pb2.ActionIdentifier
    def __init__(self, action_id: _Optional[_Union[_identifier_pb2.ActionIdentifier, _Mapping]] = ...) -> None: ...

class GetActionDataResponse(_message.Message):
    __slots__ = ["inputs", "outputs"]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    inputs: _common_pb2.Inputs
    outputs: _common_pb2.Outputs
    def __init__(self, inputs: _Optional[_Union[_common_pb2.Inputs, _Mapping]] = ..., outputs: _Optional[_Union[_common_pb2.Outputs, _Mapping]] = ...) -> None: ...

class ListRunsRequest(_message.Message):
    __slots__ = ["request", "org", "project_id", "trigger_name", "task_name", "task_id"]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    ORG_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_NAME_FIELD_NUMBER: _ClassVar[int]
    TASK_NAME_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    request: _list_pb2.ListRequest
    org: str
    project_id: _identifier_pb2.ProjectIdentifier
    trigger_name: _identifier_pb2.TriggerName
    task_name: _task_definition_pb2.TaskName
    task_id: _task_definition_pb2.TaskIdentifier
    def __init__(self, request: _Optional[_Union[_list_pb2.ListRequest, _Mapping]] = ..., org: _Optional[str] = ..., project_id: _Optional[_Union[_identifier_pb2.ProjectIdentifier, _Mapping]] = ..., trigger_name: _Optional[_Union[_identifier_pb2.TriggerName, _Mapping]] = ..., task_name: _Optional[_Union[_task_definition_pb2.TaskName, _Mapping]] = ..., task_id: _Optional[_Union[_task_definition_pb2.TaskIdentifier, _Mapping]] = ...) -> None: ...

class ListRunsResponse(_message.Message):
    __slots__ = ["runs", "token"]
    RUNS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[_run_definition_pb2.Run]
    token: str
    def __init__(self, runs: _Optional[_Iterable[_Union[_run_definition_pb2.Run, _Mapping]]] = ..., token: _Optional[str] = ...) -> None: ...

class WatchRunsRequest(_message.Message):
    __slots__ = ["org", "cluster_id", "project_id", "task_id"]
    ORG_FIELD_NUMBER: _ClassVar[int]
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    org: str
    cluster_id: _identifier_pb2.ClusterIdentifier
    project_id: _identifier_pb2.ProjectIdentifier
    task_id: _task_definition_pb2.TaskIdentifier
    def __init__(self, org: _Optional[str] = ..., cluster_id: _Optional[_Union[_identifier_pb2.ClusterIdentifier, _Mapping]] = ..., project_id: _Optional[_Union[_identifier_pb2.ProjectIdentifier, _Mapping]] = ..., task_id: _Optional[_Union[_task_definition_pb2.TaskIdentifier, _Mapping]] = ...) -> None: ...

class WatchRunsResponse(_message.Message):
    __slots__ = ["runs"]
    RUNS_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[_run_definition_pb2.Run]
    def __init__(self, runs: _Optional[_Iterable[_Union[_run_definition_pb2.Run, _Mapping]]] = ...) -> None: ...

class ListActionsRequest(_message.Message):
    __slots__ = ["request", "run_id"]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    request: _list_pb2.ListRequest
    run_id: _identifier_pb2.RunIdentifier
    def __init__(self, request: _Optional[_Union[_list_pb2.ListRequest, _Mapping]] = ..., run_id: _Optional[_Union[_identifier_pb2.RunIdentifier, _Mapping]] = ...) -> None: ...

class ListActionsResponse(_message.Message):
    __slots__ = ["actions", "token"]
    ACTIONS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    actions: _containers.RepeatedCompositeFieldContainer[_run_definition_pb2.Action]
    token: str
    def __init__(self, actions: _Optional[_Iterable[_Union[_run_definition_pb2.Action, _Mapping]]] = ..., token: _Optional[str] = ...) -> None: ...

class WatchActionsRequest(_message.Message):
    __slots__ = ["run_id", "filter"]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    run_id: _identifier_pb2.RunIdentifier
    filter: _containers.RepeatedCompositeFieldContainer[_list_pb2.Filter]
    def __init__(self, run_id: _Optional[_Union[_identifier_pb2.RunIdentifier, _Mapping]] = ..., filter: _Optional[_Iterable[_Union[_list_pb2.Filter, _Mapping]]] = ...) -> None: ...

class WatchActionsResponse(_message.Message):
    __slots__ = ["enriched_actions"]
    ENRICHED_ACTIONS_FIELD_NUMBER: _ClassVar[int]
    enriched_actions: _containers.RepeatedCompositeFieldContainer[_run_definition_pb2.EnrichedAction]
    def __init__(self, enriched_actions: _Optional[_Iterable[_Union[_run_definition_pb2.EnrichedAction, _Mapping]]] = ...) -> None: ...

class WatchClusterEventsRequest(_message.Message):
    __slots__ = ["id", "attempt"]
    ID_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.ActionIdentifier
    attempt: int
    def __init__(self, id: _Optional[_Union[_identifier_pb2.ActionIdentifier, _Mapping]] = ..., attempt: _Optional[int] = ...) -> None: ...

class WatchClusterEventsResponse(_message.Message):
    __slots__ = ["cluster_events"]
    CLUSTER_EVENTS_FIELD_NUMBER: _ClassVar[int]
    cluster_events: _containers.RepeatedCompositeFieldContainer[_run_definition_pb2.ClusterEvent]
    def __init__(self, cluster_events: _Optional[_Iterable[_Union[_run_definition_pb2.ClusterEvent, _Mapping]]] = ...) -> None: ...

class AbortActionRequest(_message.Message):
    __slots__ = ["action_id", "reason"]
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    action_id: _identifier_pb2.ActionIdentifier
    reason: str
    def __init__(self, action_id: _Optional[_Union[_identifier_pb2.ActionIdentifier, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class AbortActionResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class WatchGroupsRequest(_message.Message):
    __slots__ = ["project_id", "start_date", "end_date", "request", "known_sort_fields"]
    class KnownSortField(_message.Message):
        __slots__ = ["created_at"]
        CREATED_AT_FIELD_NUMBER: _ClassVar[int]
        created_at: _list_pb2.Sort.Direction
        def __init__(self, created_at: _Optional[_Union[_list_pb2.Sort.Direction, str]] = ...) -> None: ...
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    KNOWN_SORT_FIELDS_FIELD_NUMBER: _ClassVar[int]
    project_id: _identifier_pb2.ProjectIdentifier
    start_date: _timestamp_pb2.Timestamp
    end_date: _timestamp_pb2.Timestamp
    request: _list_pb2.ListRequest
    known_sort_fields: _containers.RepeatedCompositeFieldContainer[WatchGroupsRequest.KnownSortField]
    def __init__(self, project_id: _Optional[_Union[_identifier_pb2.ProjectIdentifier, _Mapping]] = ..., start_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., end_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., request: _Optional[_Union[_list_pb2.ListRequest, _Mapping]] = ..., known_sort_fields: _Optional[_Iterable[_Union[WatchGroupsRequest.KnownSortField, _Mapping]]] = ...) -> None: ...

class WatchGroupsResponse(_message.Message):
    __slots__ = ["task_groups", "sentinel"]
    TASK_GROUPS_FIELD_NUMBER: _ClassVar[int]
    SENTINEL_FIELD_NUMBER: _ClassVar[int]
    task_groups: _containers.RepeatedCompositeFieldContainer[_run_definition_pb2.TaskGroup]
    sentinel: bool
    def __init__(self, task_groups: _Optional[_Iterable[_Union[_run_definition_pb2.TaskGroup, _Mapping]]] = ..., sentinel: bool = ...) -> None: ...
