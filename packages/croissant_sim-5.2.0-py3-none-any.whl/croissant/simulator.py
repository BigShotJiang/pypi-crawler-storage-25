from functools import partial

import equinox as eqx
import jax
import jax.numpy as jnp
import s2fft
from astropy.coordinates import AltAz, EarthLocation
from astropy.time import Time as EarthTime
from lunarsky import LunarTopo, MoonLocation
from lunarsky import Time as LunarTime

from . import constants, rotations, utils
from .beam import Beam
from .sky import Sky


def rot_alm_z(lmax, N_times=None, delta_t=None, times=None, world="moon"):
    """
    Compute the complex phases that rotate the sky for a range of times.
    The first time is the reference time and the phases are computed
    relative to this time. Can either provide `N_times` and `delta_t`
    for uniform times, or arbitrary time sampling with the `times`
    argument.

    Parameters
    ----------
    lmax : int
        The maximum ell value.
    N_times : int
        The number of times to compute the convolution at.
    delta_t : float
        The time difference between the times.
    times : array_like
        Explicit time array in seconds. Times are interpreted as
        absolute values and will be converted to differences relative
        to the first time. If provided, `N_times` and `delta_t` are
        ignored.
    world : str
        ``earth'' or ``moon''. Default is ``moon''.

    Returns
    -------
    phases : jnp.ndarray
        The phases that rotate the sky, of the form exp(-i*m*phi(t)).
        Shape (N_times, 2*lmax+1).

    """
    if times is not None:
        times = jnp.atleast_1d(jnp.asarray(times))
        if times.size == 0:
            raise ValueError("`times` must be a non-empty array-like object.")
        dt = times - times[0]
    else:
        if N_times is None or delta_t is None:
            raise ValueError(
                "Must specify `times` or both `N_times` and `delta_t`."
            )
        dt = jnp.arange(N_times) * delta_t
    day = constants.sidereal_day[world]
    phi = 2 * jnp.pi * dt / day  # rotation angle
    emms = jnp.arange(-lmax, lmax + 1)  # m values
    phases = jnp.exp(-1j * emms[None] * phi[:, None])
    return phases


@jax.jit
def convolve(beam_alm, sky_alm, phases):
    """
    Compute the convolution for a range of times in jax. The convolution
    is a dot product in l,m space.
    Axes are in the order: time, freq, ell, emm.

    Note that normalization is not included in this function. The usual
    normalization factor can be computed with utils.total_power.

    Parameters
    ----------
    beam_alm : jnp.ndarray
        The beam alms. Shape (N_freqs, lmax+1, 2*lmax+1).
    sky_alm : jnp.ndarray
        The sky alms. Shape (N_freqs, lmax+1, 2*lmax+1).
    phases : jnp.ndarray
        The phases that rotate the sky, of the form exp(-i*m*phi(t)).
        Shape (N_times, 2*lmax+1). See the function ``rot_alm_z''.

    Returns
    -------
    res : jnp.ndarray
        The convolution. Shape (N_times, N_freqs).

    """
    res = jnp.einsum("flm,tm,flm->tf", sky_alm.conjugate(), phases, beam_alm)
    return res


@jax.jit
def correct_ground_loss(vis, fgnd, Tgnd):
    """
    Correct for ground loss in the simulated visibilities. This
    function recovers the true sky temperature if the assumed ground
    fraction and ground temperature are correct. In simulations, these
    can be accessed with the `compute_fgnd` method of the beam and the
    `Tgnd` attribute of the Simulator, respectively. On real data, they
    have to be estimated or measured.

    Parameters
    ----------
    vis : jax.Array
       The simulated visibilities that include ground loss.
    fgnd : jax.Array
       The assumed ground fraction to use for the correction.
    Tgnd : jax.Array
       The assumed ground temperature to use for the correction. Must
       be spatially uniform in this implementation.

    Returns
    -------
    corrected_vis : jax.Array
       The simulated visibilities with the ground loss corrected.

    """
    fsky = 1 - fgnd
    corrected_vis = vis - fgnd * Tgnd
    corrected_vis /= fsky
    return corrected_vis


class Simulator(eqx.Module):
    beam: Beam
    sky: Sky
    times_jd: jax.Array  # times in Julian day
    freqs: jax.Array  # in MHz
    lon: jax.Array  # longitude of in degrees
    lat: jax.Array  # latitude in degrees
    alt: jax.Array  # altitude in meters
    lmax: int = eqx.field(static=True)
    _L: int = eqx.field(static=True)
    eul_topo: tuple = eqx.field(static=True)  # euler angles for topo to eq
    dl_topo: jax.Array  # dl array for topocentric to eq frame
    Tgnd: jax.Array  # ground temperature in K
    world: str = eqx.field(static=True)  # "earth" or "moon"
    phases: jax.Array  # precomputed phases for sky rotation
    _et_ref: float = eqx.field(static=True)  # MEPA reference epoch

    def __init__(
        self,
        beam,
        sky,
        times_jd,
        freqs,
        lon,
        lat,
        alt=0,
        lmax=None,
        world="moon",
        Tgnd=300.0,
    ):
        """
        Configure a simulation. This class holds all the relevant
        parameters for a simulation and provides necessary methods
        for coordinate transforms and spherical harmonics transforms.

        Note that beam and sky models must be consistent in terms of
        frequencies and lmax values.

        Parameters
        ----------
        beam : Beam
            The beam model to use for the simulation.
        sky : Sky
            The sky model to use for the simulation.
        times_jd : jax.Array
            The times in Julian day at which to simulate the
            observations.
        freqs : jax.Array
            The frequencies in MHz for the simulation. Must be
            consistent with the frequencies used for the beam and the
            sky models.
        lon : float
            The longitude of the observer in degrees.
        lat : float
            The latitude of the observer in degrees.
        alt : float
            The altitude of the observer in meters.
        lmax : int or None
            The maximum ell value to use for the simulation. Must be
            smaller than or equal to the lmax values of the beam and
            sky models. If None, the minimum of the beam and sky lmax
            values is used.
        world : {"moon", "earth"}
            Run the simulations on the moon or the Earth
        Tgnd : float
            The ground temperature in Kelvin. Only a constant
            temperature is supported for now.

        """
        if not (
            jnp.allclose(beam.freqs, freqs) and jnp.allclose(sky.freqs, freqs)
        ):
            raise ValueError(
                "Beam, sky and simulation frequencies do not match. Check "
                "beam.freqs, sky.freqs and the freqs argument passed to the "
                "Simulator."
            )
        self.freqs = freqs
        self.beam = beam
        self.sky = sky
        self.times_jd = times_jd

        if lmax is None:
            lmax = min(beam.lmax, sky.lmax)
        elif lmax > beam.lmax or lmax > sky.lmax:
            raise ValueError(
                "lmax for the simulation must be smaller than or equal to the "
                "lmax of the beam and sky models."
            )
        self.lmax = lmax
        self._L = self.lmax + 1

        self.Tgnd = jnp.array(Tgnd)

        self.lon = jnp.array(lon)
        self.lat = jnp.array(lat)
        self.alt = jnp.array(alt)

        if world == "earth":
            loc = EarthLocation(lon, lat, height=alt)
            t0 = EarthTime(times_jd[0], format="jd")
            topo = AltAz(location=loc, obstime=t0)
            eul_topo, dl_topo = rotations.generate_euler_dl(
                self.beam.lmax, topo, "fk5"
            )
            self._et_ref = 0.0
        elif world == "moon":
            loc = MoonLocation(lon, lat, height=alt)
            t0 = LunarTime(times_jd[0], format="jd")
            topo = LunarTopo(location=loc, obstime=t0)
            self._et_ref = float(rotations.jd_to_et(t0.tdb.jd))
            eul_topo, dl_topo = rotations.generate_euler_dl(
                self.beam.lmax, topo, "mepa"
            )
        else:
            raise ValueError("`world` must be either 'earth' or 'moon'.")
        self.world = world
        self.eul_topo = tuple(float(angle) for angle in eul_topo)
        self.dl_topo = jnp.array(dl_topo)

        # precompute the phases
        dt_sec = (self.times_jd - self.times_jd[0]) * 24 * 3600
        self.phases = rot_alm_z(self.lmax, times=dt_sec, world=self.world)

    @jax.jit
    def compute_beam_eq(self):
        """
        Compute the beam alm in equatorial coordinates. This uses the
        pre-computed Euler angles and dl array for the topocentric to
        equatorial transformation.

        Returns
        -------
        beam_eq_alm : jax.Array
            The beam alm in equatorial coordinates. Shape is
            (Nfreqs, lmax+1, 2*lmax+1).

        """
        beam_alm = self.beam.compute_alm()
        eq2topo = partial(
            s2fft.utils.rotation.rotate_flms,
            L=self.beam._L,
            rotation=self.eul_topo,
            dl_array=self.dl_topo,
        )
        beam_eq_alm = jax.vmap(eq2topo)(beam_alm)
        return beam_eq_alm

    @jax.jit
    def compute_ground_contribution(self):
        """
        Compute the ground contribution to the visibility. This is
        simply the beam response below the horizon multiplied by the
        ground temperature.

        Note that we do not include scattering of the sky temperature
        by the ground or non-uniform ground temperature in this model.

        Returns
        -------
        vis_gnd : jax.Array
            The ground contribution to the visibility.

        """
        return self.beam.compute_fgnd() * self.Tgnd

    def precompute_sky_alm(self):
        """
        Compute the sky ALM in the simulation frame (equatorial or
        MEPA coordinates). Use this to avoid redundant spherical
        harmonic transforms when calling ``sim`` in a loop with
        different beam orientations but the same sky.

        Returns
        -------
        sky_alm : jax.Array
            The sky ALM in the simulation frame. Shape is
            (N_freqs, lmax+1, 2*lmax+1) where lmax is the sky's
            lmax (not the Simulator's lmax — truncation is handled
            inside ``sim``).

        Notes
        -----
        The returned array is suitable for passing to
        ``sim(sky_alm=...)``.  It is tied to this simulator's
        ``world`` and, for lunar observations with a galactic sky,
        the reference epoch derived from the start time. Only reuse
        it with simulators that share the same ``world`` and start
        time.

        If you need gradients with respect to ``sky.data``, compute
        ``sky_alm`` **inside** the ``jax.grad``-traced function
        rather than pre-computing it outside. Pre-computing outside
        the gradient boundary severs the computation graph from the
        simulation output back to the sky pixel data.

        Examples
        --------
        >>> sky_alm = sim0.precompute_sky_alm()
        >>> for beam in beams:
        ...     sim = Simulator(beam, sky, times, freqs, **kw)
        ...     result = sim.sim(sky_alm=sky_alm)

        """
        return self.sky.compute_alm_eq(world=self.world, et=self._et_ref)

    @jax.jit
    def sim(self, sky_alm=None):
        """
        Compute the antenna temperature as the convolution of the beam
        and the sky, plus the ground contribution.

        The antenna temperature is reported in the same units as the
        sky and ground temperatures, which is typically Kelvin. To
        recover an estimate of the sky temperature, the ground loss can
        be corrected for with the `correct_ground_loss` function.

        Parameters
        ----------
        sky_alm : jax.Array or None
            Pre-computed sky ALM in the simulation frame (equatorial
            or MEPA). When provided, the sky's forward SHT and
            coordinate rotation are skipped. Use
            ``precompute_sky_alm`` to obtain this. When ``None``
            (default), the sky ALM is computed internally and
            behaviour is identical to previous versions.

        Returns
        -------
        vis : jax.Array
            The simulated antenna temperature as a function of time and
            frequency. Shape is (N_times, N_freqs).

        Notes
        -----
        If you need gradients with respect to ``sky.data``, either
        omit ``sky_alm`` or compute it inside the ``jax.grad``-traced
        function. Pre-computing outside the gradient boundary severs
        the chain from the output back to the sky pixel data.

        """
        # compute beam and sky alms in equatorial coordinates
        beam_eq_alm = self.compute_beam_eq()
        if sky_alm is None:
            sky_eq_alm = self.sky.compute_alm_eq(
                world=self.world, et=self._et_ref
            )
        else:
            if sky_alm.ndim != 3:
                raise ValueError(
                    "sky_alm must be a 3D array with shape "
                    "(N_freqs, lmax+1, 2*lmax+1). "
                    f"Got ndim={sky_alm.ndim}, "
                    f"shape={sky_alm.shape}."
                )
            if sky_alm.shape[0] != len(self.freqs):
                raise ValueError(
                    "sky_alm has wrong number of frequency "
                    f"channels: expected {len(self.freqs)}, "
                    f"got {sky_alm.shape[0]}."
                )
            sky_alm_lmax = utils.lmax_from_shape(sky_alm.shape)
            if sky_alm_lmax < self.lmax:
                raise ValueError(
                    "sky_alm lmax is too small: expected at "
                    f"least {self.lmax}, got {sky_alm_lmax}."
                )
            sky_eq_alm = sky_alm
        # resize to the simulation lmax
        beam_eq_alm = utils.reduce_lmax(beam_eq_alm, self.lmax)
        sky_eq_alm = utils.reduce_lmax(sky_eq_alm, self.lmax)

        # this is the sky contribution, with implict ground loss
        vis_sky = convolve(beam_eq_alm, sky_eq_alm, self.phases)
        vis_sky /= self.beam.compute_norm()[None, :]
        # add the ground contribution
        vis_gnd = self.compute_ground_contribution()
        vis = vis_sky + vis_gnd
        return vis.real
