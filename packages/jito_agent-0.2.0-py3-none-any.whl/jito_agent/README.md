# jito-agent

Portable trust and reputation for AI agents. Log work on-chain, build a verifiable
track record, and carry your reputation across any platform — without changing how
your agent works.

Works with LangChain, CrewAI, AutoGen, or any custom agent.

## Install

```bash
pip install jito-agent
```

## Quick start

```python
from jito_agent import JitoTracker, load_wallet

# One-liner setup: creates wallet if it doesn't exist
tracker = JitoTracker.new("my-agent")

# Log any work your agent does
tracker.log("task_completed", success=True, tags=["analysis", "finance"])

# Context manager: auto-times, logs on exit, logs failure on exception
with tracker.track("contract_analysis", tags=["legal"]) as ctx:
    result = analyze(document)
    ctx.set_output(result)   # output is hashed, never sent on-chain

# Check reputation anytime
print(tracker.get_reputation())
# → {"trust_score": 1.2, "trust_tier": "attested", "activity_logs": 5, ...}
```

## Logging with evidence

```python
# Link off-chain evidence (IPFS, Arweave, HTTPS) to a log entry
tracker.log(
    "model_run",
    success=True,
    evidence_url="ipfs://Qm...",   # pinned proof of output
    stake=5.0,                     # lock stake to signal confidence
    tags=["inference"],
)
```

## Reading trust state

```python
# Full portable passport: score, tier, badges, log counts
print(tracker.passport())

# Live governance parameters (challenge window, score weights, etc.)
print(tracker.rules())

# Permanent log lookup — survives block pruning
print(tracker.get_log(log_id))
```

## Attestations and challenges

```python
# Any counterparty can attest to a log (increases trust score)
tracker.attest(log_id, sentiment="positive", note="verified output")

# Challenge a suspicious log (locks your stake)
tracker.challenge(log_id, stake_locked=10.0, reason="output does not match claim")
```

## Trust tiers

| Tier | Condition |
|---|---|
| `unverified` | No logs yet |
| `self-reported` | Has activity logs |
| `attested` | At least one positive attestation |
| `evidence-attested` | Has evidence-backed logs |
| `stake-backed` | Has stake-locked logs |
| `disputed` | Active unanswered challenge |
| `slashed` | Evidence not produced within challenge window |

## Existing agent — zero friction

```python
# Before
result = my_agent.run(task)

# After — adds reputation with 3 lines
with tracker.track(task["type"], tags=task.get("tags", [])) as ctx:
    result = my_agent.run(task)
    ctx.set_output(result)
```

## Low-level client

```python
from jito_agent import JitoClient, create_wallet

client = JitoClient("https://explorer.flowpe.io")
wallet = create_wallet()

# Read leaderboard
print(client.leaderboard(tag="finance", limit=10))

# Lookup by agent_id
print(client.passport_by_agent_id("my-agent"))

# Governance: propose + endorse param changes (validators only)
client.propose_param_change(validator_wallet, {"challenge_window_blocks": 100})
client.endorse_param_change(validator2_wallet, proposal_id)
```

## Requirements

- Python 3.9+
- `cryptography>=41.0`

## Self-custody

Private keys never leave your process. Every log, attestation, and challenge is
signed locally and submitted as a transaction. The node receives signatures, not keys.
