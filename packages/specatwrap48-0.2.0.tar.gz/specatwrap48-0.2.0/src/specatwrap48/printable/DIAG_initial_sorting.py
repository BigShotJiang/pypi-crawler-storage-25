import polars as pl
# {[paste:begin]}
allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER", "Death"]

lf = (
    pl.scan_parquet(r"..\combined_diag_death.parquet")
    .filter(
        pl.col("TDiag").is_in(allowed_events).all().over("case:PNR")
        & pl.all_horizontal(
            [
                pl.col("TDiag").eq(ev).any().over("case:PNR")
                for ev in allowed_events[:-1]
            ]
        )
    )
    .filter(
        # If contains Death then it must be the last
        ~((pl.col("TDiag") == "Death").any().over("case:PNR"))
        | ((pl.col("TDiag") == "Death").last().over("case:PNR"))
    )
    .unique(subset=["case:PNR", "ADiag"], keep="first", maintain_order=True)
)
