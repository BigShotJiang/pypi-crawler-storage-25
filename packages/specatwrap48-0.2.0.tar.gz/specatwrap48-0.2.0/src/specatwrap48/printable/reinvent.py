import polars as pl

lf: pl.LazyFrame = None
# {[paste:begin]}
import polars as pl

# {{paste:reinvent}}

# {{paste:DIAG_stats}}

lf_buggy = (
    lf.with_columns(
        [
            (pl.col("TDiag") == "Death").any().over("case:PNR").alias("has_death"),
            (pl.col("TDiag").last().over("case:PNR") == "Death").alias("is_death_last"),
        ]
    )
    .filter(pl.col("has_death") & ~pl.col("is_death_last"))
    .group_by("case:PNR")
    .agg(pl.col("TDiag").str.join(" -> ").alias("trace"))
)

lf = lf.filter((pl.col("TDiag") == "Death").last().over("case:PNR"))

lf = lf.with_columns(
    pl.col("TDiag")
    + (pl.col("TDiag").cum_count().over("TDiag") + 1).cast(pl.String).alias("TDiag")
)
