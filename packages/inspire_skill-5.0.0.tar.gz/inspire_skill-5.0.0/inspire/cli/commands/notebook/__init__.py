"""Notebook / Interactive instance commands.

Usage:
    inspire notebook list
    inspire notebook status <name>
    inspire notebook top
    inspire notebook create --quota 1,20,200
    inspire notebook stop <name>
    inspire notebook ssh <notebook>             # establish cached connection
    inspire notebook exec <notebook> "<cmd>"
    inspire notebook scp <src> <dst>
    inspire notebook connections                # list cached notebook connections
    inspire notebook refresh <notebook>
    inspire notebook forget <notebook>
"""

from __future__ import annotations

import click

from inspire.cli.commands.batch import notebook_batch
from inspire.cli.commands.workload_profile import make_profile_command

from .notebook_commands import (
    create_notebook_cmd,
    delete_notebook_cmd,
    list_notebooks,
    notebook_id_cmd,
    notebook_status,
    set_path_alias_cmd,
    ssh_notebook_cmd,
    start_notebook_cmd,
    stop_notebook_cmd,
)
from .top import notebook_top
from .notebook_events import events as notebook_events
from .notebook_lifecycle import lifecycle as notebook_lifecycle
from .notebook_metrics import notebook_metrics

# Remote operations on a cached notebook connection.
from .install_deps import install_deps_cmd
from .remote_exec import exec_command as _remote_exec
from .remote_scp import bridge_scp as _remote_scp
from .remote_shell import bridge_ssh as _remote_shell

# Local notebook connection cache management.
from .connections_cmd import tunnel_list as _connections
from .forget_cmd import tunnel_remove as _forget
from .refresh_cmd import tunnel_update as _refresh
from .connection_test_cmd import tunnel_test as _connection_test


@click.group()
def notebook():
    """Manage notebook/interactive instances.

    \b
    Examples:
        inspire notebook list                          # List all instances
        inspire notebook ssh <notebook>                # Establish cached connection
        inspire notebook exec <notebook> "nvidia-smi"  # Run a command on a cached notebook
        inspire notebook metrics <notebook> --window 30m
    """
    pass


# Core lifecycle (existing).
notebook.add_command(list_notebooks)            # list
notebook.add_command(notebook_status)           # status
notebook.add_command(notebook_id_cmd)           # id
notebook.add_command(create_notebook_cmd)       # create
notebook.add_command(make_profile_command("notebook"))  # profile
notebook.add_command(notebook_batch)            # batch
notebook.add_command(stop_notebook_cmd)         # stop
notebook.add_command(start_notebook_cmd)        # start
notebook.add_command(delete_notebook_cmd)       # delete
notebook.add_command(ssh_notebook_cmd)          # ssh
notebook.add_command(notebook_top)              # top
notebook.add_command(notebook_events)           # events (K8s scheduling / pod lifecycle)
notebook.add_command(notebook_lifecycle)        # lifecycle (run-cycle timeline; /run_index/list)
notebook.add_command(notebook_metrics)          # metrics (资源视图 time-series, no SSH needed)
notebook.add_command(set_path_alias_cmd)        # set-path (project remote path aliases)

# Remote operations on a cached notebook connection.
notebook.add_command(_remote_exec,  name="exec")
notebook.add_command(_remote_scp,   name="scp")
notebook.add_command(_remote_shell, name="shell")
notebook.add_command(install_deps_cmd, name="install-deps")

# Local cache management.
notebook.add_command(_connections,     name="connections")
notebook.add_command(_refresh,         name="refresh")
notebook.add_command(_forget,          name="forget")
notebook.add_command(_connection_test, name="test")
