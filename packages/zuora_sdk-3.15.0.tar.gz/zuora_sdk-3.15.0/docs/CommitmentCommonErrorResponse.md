# CommitmentCommonErrorResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**request_id** | **str** | The requestId field is a UUID used for request tracing and debugging across services. | [optional] 
**timestamp** | **datetime** | The timestamp field is an ISO 8601 formatted timestamp that indicates when the error occurred. This timestamp is automatically generated when the error response is created. | [optional] 
**errors** | [**List[CommitmentCommonErrorResponseErrorsInner]**](CommitmentCommonErrorResponseErrorsInner.md) |  | [optional] 

## Example

```python
from zuora_sdk.models.commitment_common_error_response import CommitmentCommonErrorResponse

# TODO update the JSON string below
json = "{}"
# create an instance of CommitmentCommonErrorResponse from a JSON string
commitment_common_error_response_instance = CommitmentCommonErrorResponse.from_json(json)
# print the JSON string representation of the object
print(CommitmentCommonErrorResponse.to_json())

# convert the object into a dict
commitment_common_error_response_dict = commitment_common_error_response_instance.to_dict()
# create an instance of CommitmentCommonErrorResponse from a dict
commitment_common_error_response_from_dict = CommitmentCommonErrorResponse.from_dict(commitment_common_error_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


