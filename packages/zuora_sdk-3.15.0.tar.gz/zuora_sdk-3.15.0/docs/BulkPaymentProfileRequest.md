# BulkPaymentProfileRequest

Request to bulk create or update payment profiles for subscriptions. Maximum of 50 payment profiles can be processed in a single request. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bulk_payment_option_items** | [**List[BulkPaymentOptionItem]**](BulkPaymentOptionItem.md) | Array of payment profile items to create or update. Maximum of 50 items allowed.  | 

## Example

```python
from zuora_sdk.models.bulk_payment_profile_request import BulkPaymentProfileRequest

# TODO update the JSON string below
json = "{}"
# create an instance of BulkPaymentProfileRequest from a JSON string
bulk_payment_profile_request_instance = BulkPaymentProfileRequest.from_json(json)
# print the JSON string representation of the object
print(BulkPaymentProfileRequest.to_json())

# convert the object into a dict
bulk_payment_profile_request_dict = bulk_payment_profile_request_instance.to_dict()
# create an instance of BulkPaymentProfileRequest from a dict
bulk_payment_profile_request_from_dict = BulkPaymentProfileRequest.from_dict(bulk_payment_profile_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


