# CreditMemosResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**process_id** | **str** | The Id of the process that handle the operation.  | [optional] 
**request_id** | **str** | Unique request identifier. If you need to contact us about a specific request, providing the request identifier will ensure the fastest possible resolution.  | [optional] 
**reasons** | [**List[FailedReason]**](FailedReason.md) |  | [optional] 
**success** | **bool** | Indicates whether the call succeeded.  | [optional] [default to True]
**creditmemos** | [**List[CreditMemo]**](CreditMemo.md) | Container for credit memos.  | [optional] 
**next_page** | **str** | URL to retrieve the next page of the response if it exists; otherwise absent. | [optional] 

## Example

```python
from zuora_sdk.models.credit_memos_response import CreditMemosResponse

# TODO update the JSON string below
json = "{}"
# create an instance of CreditMemosResponse from a JSON string
credit_memos_response_instance = CreditMemosResponse.from_json(json)
# print the JSON string representation of the object
print(CreditMemosResponse.to_json())

# convert the object into a dict
credit_memos_response_dict = credit_memos_response_instance.to_dict()
# create an instance of CreditMemosResponse from a dict
credit_memos_response_from_dict = CreditMemosResponse.from_dict(credit_memos_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


