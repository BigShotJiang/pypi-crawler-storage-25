# CommonRevenueAttributes


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adjustment_liability_accounting_code** | **str** | The accounting code on the Commitment object for customers using [Zuora Order - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Billing/B_Set_up_Zuora_Billing/Enable_Order_to_Revenue/Order_to_Revenue_introduction/AA_Overview_of_Order_to_Revenue).  | [optional] 
**adjustment_revenue_accounting_code** | **str** | The accounting code on the Commitment object for customers using [Zuora Order - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Billing/B_Set_up_Zuora_Billing/Enable_Order_to_Revenue/Order_to_Revenue_introduction/AA_Overview_of_Order_to_Revenue).  | [optional] 
**contract_asset_accounting_code** | **str** | The accounting code on the Commitment object for customers using [Zuora Order - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Billing/B_Set_up_Zuora_Billing/Enable_Order_to_Revenue/Order_to_Revenue_introduction/AA_Overview_of_Order_to_Revenue).  | [optional] 
**contract_liability_accounting_code** | **str** | The accounting code on the Commitment object for customers using [Zuora Order - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Billing/B_Set_up_Zuora_Billing/Enable_Order_to_Revenue/Order_to_Revenue_introduction/AA_Overview_of_Order_to_Revenue).  | [optional] 
**contract_recognized_revenue_accounting_code** | **str** | The accounting code on the Commitment object for customers using [Zuora Order - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Billing/B_Set_up_Zuora_Billing/Enable_Order_to_Revenue/Order_to_Revenue_introduction/AA_Overview_of_Order_to_Revenue).  | [optional] 
**deferred_revenue_accounting_code** | **str** | The deferred revenue accounting code for the Commitment.  | [optional] 
**exclude_item_billing_from_revenue_accounting** | **bool** | The flag to exclude Commitment related invoice items, invoice item adjustments, credit memo items, and debit memo items from revenue accounting.   **Note**: This field is only available if you have the Order - Revenue Integration feature enabled.   | [optional] 
**is_allocation_eligible** | **bool** | This field is used to identify if the charge is allocation eligible in revenue recognition.  | [optional] 
**is_unbilled** | **bool** | This field is used to dictate how to perform the accounting during revenue recognition.  | [optional] 
**recognized_revenue_accounting_code** | **str** | The recognized revenue accounting code for the Commitment.  | [optional] 
**revenue_recognition_rule** | **str** | The Revenue Recognition rule for the Commitment.  | [optional] 
**unbilled_receivables_accounting_code** | **str** | The accounting code on the Commitment object for customers using [Zuora Order - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Billing/B_Set_up_Zuora_Billing/Enable_Order_to_Revenue/Order_to_Revenue_introduction/AA_Overview_of_Order_to_Revenue).  | [optional] 
**revenue_recognition_timing** | **str** | The revenue recognition timing for the Commitment period.  | [optional] 
**revenue_amortization_method** | **str** | The revenue amortization method for the Commitment period.  | [optional] 
**account_receivable_accounting_code** | **str** | The accounting code on the Commitment period object for customers using [Zuora Billing - Revenue Integration](https://knowledgecenter.zuora.com/Zuora_Revenue/Zuora_Billing_-_Revenue_Integration). | [optional] 

## Example

```python
from zuora_sdk.models.common_revenue_attributes import CommonRevenueAttributes

# TODO update the JSON string below
json = "{}"
# create an instance of CommonRevenueAttributes from a JSON string
common_revenue_attributes_instance = CommonRevenueAttributes.from_json(json)
# print the JSON string representation of the object
print(CommonRevenueAttributes.to_json())

# convert the object into a dict
common_revenue_attributes_dict = common_revenue_attributes_instance.to_dict()
# create an instance of CommonRevenueAttributes from a dict
common_revenue_attributes_from_dict = CommonRevenueAttributes.from_dict(common_revenue_attributes_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


