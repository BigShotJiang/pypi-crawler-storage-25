# BasePeriod


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_date** | **date** | Start date of the commitment period. | [optional] 
**end_date** | **date** | End date of the commitment period. | [optional] 
**is_prorated** | **bool** | Indicates if the period is prorated. | [optional] 
**amount** | **float** | The committed amount of the each commitment period | [optional] 

## Example

```python
from zuora_sdk.models.base_period import BasePeriod

# TODO update the JSON string below
json = "{}"
# create an instance of BasePeriod from a JSON string
base_period_instance = BasePeriod.from_json(json)
# print the JSON string representation of the object
print(BasePeriod.to_json())

# convert the object into a dict
base_period_dict = base_period_instance.to_dict()
# create an instance of BasePeriod from a dict
base_period_from_dict = BasePeriod.from_dict(base_period_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


