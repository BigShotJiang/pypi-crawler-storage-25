# BulkPaymentProfileResponseReasonsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | Error code | [optional] 
**message** | **str** | Error message | [optional] 

## Example

```python
from zuora_sdk.models.bulk_payment_profile_response_reasons_inner import BulkPaymentProfileResponseReasonsInner

# TODO update the JSON string below
json = "{}"
# create an instance of BulkPaymentProfileResponseReasonsInner from a JSON string
bulk_payment_profile_response_reasons_inner_instance = BulkPaymentProfileResponseReasonsInner.from_json(json)
# print the JSON string representation of the object
print(BulkPaymentProfileResponseReasonsInner.to_json())

# convert the object into a dict
bulk_payment_profile_response_reasons_inner_dict = bulk_payment_profile_response_reasons_inner_instance.to_dict()
# create an instance of BulkPaymentProfileResponseReasonsInner from a dict
bulk_payment_profile_response_reasons_inner_from_dict = BulkPaymentProfileResponseReasonsInner.from_dict(bulk_payment_profile_response_reasons_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


