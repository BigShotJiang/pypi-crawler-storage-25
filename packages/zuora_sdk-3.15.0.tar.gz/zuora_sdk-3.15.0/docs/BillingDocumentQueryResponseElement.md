# BillingDocumentQueryResponseElement


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**process_id** | **str** | The Id of the process that handle the operation.  | [optional] 
**request_id** | **str** | Unique request identifier. If you need to contact us about a specific request, providing the request identifier will ensure the fastest possible resolution.  | [optional] 
**reasons** | [**List[FailedReason]**](FailedReason.md) |  | [optional] 
**success** | **bool** | Indicates whether the call succeeded.  | [optional] [default to True]
**documents** | [**List[GetBillingDocumentsResponse]**](GetBillingDocumentsResponse.md) | Container for billing documents.  | [optional] 
**next_page** | **str** | URL to retrieve the next page of the response if it exists; otherwise absent. | [optional] 

## Example

```python
from zuora_sdk.models.billing_document_query_response_element import BillingDocumentQueryResponseElement

# TODO update the JSON string below
json = "{}"
# create an instance of BillingDocumentQueryResponseElement from a JSON string
billing_document_query_response_element_instance = BillingDocumentQueryResponseElement.from_json(json)
# print the JSON string representation of the object
print(BillingDocumentQueryResponseElement.to_json())

# convert the object into a dict
billing_document_query_response_element_dict = billing_document_query_response_element_instance.to_dict()
# create an instance of BillingDocumentQueryResponseElement from a dict
billing_document_query_response_element_from_dict = BillingDocumentQueryResponseElement.from_dict(billing_document_query_response_element_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


