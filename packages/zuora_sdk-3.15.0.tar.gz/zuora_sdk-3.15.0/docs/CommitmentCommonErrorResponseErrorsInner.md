# CommitmentCommonErrorResponseErrorsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | an human readable error code like: \&quot;invalid_format_or_value\&quot; | [optional] 
**message** | **str** | the error message | [optional] 
**parameter** | **str** | This will be the exact field that caused the error. e.g. &#39;periods[0].startDate&#39; | [optional] 

## Example

```python
from zuora_sdk.models.commitment_common_error_response_errors_inner import CommitmentCommonErrorResponseErrorsInner

# TODO update the JSON string below
json = "{}"
# create an instance of CommitmentCommonErrorResponseErrorsInner from a JSON string
commitment_common_error_response_errors_inner_instance = CommitmentCommonErrorResponseErrorsInner.from_json(json)
# print the JSON string representation of the object
print(CommitmentCommonErrorResponseErrorsInner.to_json())

# convert the object into a dict
commitment_common_error_response_errors_inner_dict = commitment_common_error_response_errors_inner_instance.to_dict()
# create an instance of CommitmentCommonErrorResponseErrorsInner from a dict
commitment_common_error_response_errors_inner_from_dict = CommitmentCommonErrorResponseErrorsInner.from_dict(commitment_common_error_response_errors_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


