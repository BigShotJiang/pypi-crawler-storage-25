# CreateBatchQueryResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_version** | **str** | The API version for the query. If an API version is not specified, the latest version is used by default. Using the latest WSDL version is most useful for reporting use cases. For integration purposes, specify the WSDL version to ensure consistent query behavior, that is, what is supported and included in the response returned by the API.  **Note**: As of API version 69 and later, Zuora changed the format of certain fields. See &lt;a href&#x3D;\&quot;https://knowledgecenter.zuora.com/Zuora_Central_Platform/API/G_SOAP_API/AB_Getting_started_with_the__SOAP_API/C_Date_Field_Changes_in_the_SOAP_API\&quot; target&#x3D;\&quot;_blank\&quot;&gt;Date Field Changes in the SOAP API&lt;/a&gt; for more information and a list of affected fields.  | [optional] 
**batch_id** | **str** | A 32-character ID of the query batch.  | [optional] 
**batch_type** | [**BatchQueryBatchType**](BatchQueryBatchType.md) |  | [optional] 
**deleted** | [**DeletedRecord**](DeletedRecord.md) |  | [optional] 
**full** | **bool** | This field indicates a full or incremental load. &#x60;True&#x60; &#x3D; Full and &#x60;False&#x60; &#x3D; Incremental.            | [optional] 
**name** | **str** | Name of the query supplied in the request.  | [optional] 
**query** | **str** | The requested query string.  | [optional] 
**record_count** | **float** | The number of records included in the query output file.  | [optional] 
**localized_status** | [**BatchQueryStatus**](BatchQueryStatus.md) |  | [optional] 
**status** | [**BatchQueryStatus**](BatchQueryStatus.md) |  | [optional] 

## Example

```python
from zuora_sdk.models.create_batch_query_response import CreateBatchQueryResponse

# TODO update the JSON string below
json = "{}"
# create an instance of CreateBatchQueryResponse from a JSON string
create_batch_query_response_instance = CreateBatchQueryResponse.from_json(json)
# print the JSON string representation of the object
print(CreateBatchQueryResponse.to_json())

# convert the object into a dict
create_batch_query_response_dict = create_batch_query_response_instance.to_dict()
# create an instance of CreateBatchQueryResponse from a dict
create_batch_query_response_from_dict = CreateBatchQueryResponse.from_dict(create_batch_query_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


