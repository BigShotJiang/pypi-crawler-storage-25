# AlignmentOptionEnum

Options for aligning the commitment periods within a commitment schedule.

## Enum

* `COMMITMENTSTARTDATE` (value: `'CommitmentStartDate'`)

* `SPECIFICDATE` (value: `'SpecificDate'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


