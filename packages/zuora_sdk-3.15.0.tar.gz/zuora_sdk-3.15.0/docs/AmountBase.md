# AmountBase

The level for which the committed amount applies to.

## Enum

* `COMMITMENTPERIOD` (value: `'CommitmentPeriod'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


