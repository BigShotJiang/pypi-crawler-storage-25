# CreateHostedPageRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The type of payment method that the hosted page will support.   Valid values: - &#x60;hp_creditcard&#x60; - For credit card payments - &#x60;hp_ach&#x60; - For ACH (Automated Clearing House) payments - &#x60;hp_directdebituk&#x60; - For bank transfer payments (UK Direct Debit) - &#x60;hp_sepa&#x60; - For SEPA payments - &#x60;hp_paypal&#x60; - For PayPal payments - &#x60;hp_directentryau&#x60; - For Direct Entry AU payments - &#x60;hp_betalingsservice&#x60; - For Betalingsservice payments - &#x60;hp_autogiro&#x60; - For Autogiro payments - &#x60;hp_directdebitnz&#x60; - For Direct Debit NZ payments - &#x60;hp_pad&#x60; - For PAD payments - &#x60;hp_ccref&#x60; - For credit card reference transactions  | 
**page_name** | **str** | The display name for the hosted payment page. This name will be used for identification purposes in the Zuora UI.  | 
**domain** | **str** | The domain where the hosted payment page will be accessible. Must be a valid URL format.  Example: &#x60;https://example.com&#x60;  | 
**gateway** | **str** | The name or identifier of the payment gateway that will process payments from this hosted page.  The gateway must be configured and active in your Zuora tenant.  | 
**callback_path** | **str** | The callback URL path that will be used after payment processing is completed.  This path will be appended to the domain to form the complete callback URL.  Example: &#x60;/callback&#x60; will result in &#x60;https://example.com/callback&#x60;  | [optional] 
**allow_sub_domain** | **bool** | Specifies whether the hosted page can be accessed from subdomains of the specified domain.  - &#x60;true&#x60; - Allow access from subdomains (e.g., &#x60;pay.example.com&#x60;) - &#x60;false&#x60; - Only allow access from the exact domain specified  | [optional] [default to False]
**display_fields** | **List[str]** | An array of field names that should be displayed on the hosted payment page.  Common field options include: - &#x60;cardHolderName&#x60; - Cardholder&#39;s name - &#x60;address1&#x60; - Primary address line - &#x60;address2&#x60; - Secondary address line   - &#x60;city&#x60; - City - &#x60;state&#x60; - State or province - &#x60;zipcode&#x60; - ZIP or postal code - &#x60;country&#x60; - Country - &#x60;phone&#x60; - Phone number - &#x60;email&#x60; - Email address  | [optional] 
**require_fields** | **List[str]** | An array of field names that are required to be filled out on the hosted payment page. All fields specified in this array must also be included in the &#x60;displayFields&#x60; array.  | [optional] 
**css** | **str** | Custom CSS styling that will be applied to the hosted payment page. Use this to customize the appearance and branding of the page to match your website.  Example: &#x60;&#x60;&#x60;css body { font-family: Arial, sans-serif; } .form-container { max-width: 500px; margin: 0 auto; } &#x60;&#x60;&#x60;  | [optional] 

## Example

```python
from zuora_sdk.models.create_hosted_page_request import CreateHostedPageRequest

# TODO update the JSON string below
json = "{}"
# create an instance of CreateHostedPageRequest from a JSON string
create_hosted_page_request_instance = CreateHostedPageRequest.from_json(json)
# print the JSON string representation of the object
print(CreateHostedPageRequest.to_json())

# convert the object into a dict
create_hosted_page_request_dict = create_hosted_page_request_instance.to_dict()
# create an instance of CreateHostedPageRequest from a dict
create_hosted_page_request_from_dict = CreateHostedPageRequest.from_dict(create_hosted_page_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


