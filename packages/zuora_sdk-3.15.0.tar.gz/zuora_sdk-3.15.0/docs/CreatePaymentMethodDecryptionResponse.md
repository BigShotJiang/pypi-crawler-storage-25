# CreatePaymentMethodDecryptionResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**process_id** | **str** | The Id of the process that handle the operation.  | [optional] 
**request_id** | **str** | Unique request identifier. If you need to contact us about a specific request, providing the request identifier will ensure the fastest possible resolution.  | [optional] 
**reasons** | [**List[FailedReason]**](FailedReason.md) |  | [optional] 
**success** | **bool** | Indicates whether the call succeeded.  | [optional] [default to True]
**amount** | **str** | The payment amount contained within the encrypted token.  | [optional] 
**payment_id** | **str** | The ID of newly processed payment,  | [optional] 
**payment_method_id** | **str** | ID of the newly-created payment method.  | [optional] 

## Example

```python
from zuora_sdk.models.create_payment_method_decryption_response import CreatePaymentMethodDecryptionResponse

# TODO update the JSON string below
json = "{}"
# create an instance of CreatePaymentMethodDecryptionResponse from a JSON string
create_payment_method_decryption_response_instance = CreatePaymentMethodDecryptionResponse.from_json(json)
# print the JSON string representation of the object
print(CreatePaymentMethodDecryptionResponse.to_json())

# convert the object into a dict
create_payment_method_decryption_response_dict = create_payment_method_decryption_response_instance.to_dict()
# create an instance of CreatePaymentMethodDecryptionResponse from a dict
create_payment_method_decryption_response_from_dict = CreatePaymentMethodDecryptionResponse.from_dict(create_payment_method_decryption_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


