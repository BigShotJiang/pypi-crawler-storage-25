# CommonTaxationAttributes


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taxable** | **bool** | Determines whether a transaction line item in the billing document is taxable. If this field is set to true, both the fields taxCode and taxMode are required.  | [optional] 
**tax_code** | **str** | The identifier or set of characters assigned to a transaction line item to determine the applicable tax rate and calculate the tax amount. This field is available when the field &#39;taxable&#39; is set to true.  | [optional] 
**tax_mode** | **str** | Determines whether the tax amount is inclusive or exclusive for the transaction line item. This field is available when the field &#39;taxable&#39; is set to true.  | [optional] 

## Example

```python
from zuora_sdk.models.common_taxation_attributes import CommonTaxationAttributes

# TODO update the JSON string below
json = "{}"
# create an instance of CommonTaxationAttributes from a JSON string
common_taxation_attributes_instance = CommonTaxationAttributes.from_json(json)
# print the JSON string representation of the object
print(CommonTaxationAttributes.to_json())

# convert the object into a dict
common_taxation_attributes_dict = common_taxation_attributes_instance.to_dict()
# create an instance of CommonTaxationAttributes from a dict
common_taxation_attributes_from_dict = CommonTaxationAttributes.from_dict(common_taxation_attributes_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


