"""
Local command execution — runs commands on the user's machine at the agent's request.

Security model:
  1. Blocked commands (sudo, mkfs, rm -rf /, etc.) are ALWAYS rejected.
  2. Safe commands (ls, cat, grep, EDA tools, compilers) are ALWAYS auto-approved.
  3. Mutating commands (rm, mv, chmod, git push, pip install, etc.) depend on
     the user's command_approval preference:
       - "autonomous": auto-approve everything (agent has full control)
       - "supervised": prompt the user for each mutating command
     The preference is set on first run and saved to ~/.sigmanticai/preferences.json.
  4. Unknown commands always prompt the user.
  5. Hard timeout of 5 minutes per command.
  6. stdout/stderr capped at 500KB/100KB.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel

console = Console()

# ── Preferences ──────────────────────────────────────────────────────

_PREFS_DIR = Path.home() / ".sigmanticai"
_PREFS_FILE = _PREFS_DIR / "preferences.json"

# Module-level cache so we only prompt once per CLI session
_session_approval_mode: Optional[str] = None


def _load_preferences() -> dict:
    """Load user preferences from ~/.sigmanticai/preferences.json."""
    if _PREFS_FILE.exists():
        try:
            return json.loads(_PREFS_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_preferences(prefs: dict) -> None:
    """Save user preferences to ~/.sigmanticai/preferences.json."""
    _PREFS_DIR.mkdir(parents=True, exist_ok=True)
    _PREFS_FILE.write_text(json.dumps(prefs, indent=2) + "\n")


def get_command_approval_mode() -> str:
    """Get the user's command approval preference, prompting on first run.

    Returns "autonomous" or "supervised".
    """
    global _session_approval_mode

    if _session_approval_mode is not None:
        return _session_approval_mode

    prefs = _load_preferences()
    mode = prefs.get("command_approval")

    if mode in ("autonomous", "supervised"):
        _session_approval_mode = mode
        return mode

    # First run — ask the user
    console.print()
    console.print(Panel(
        "[bold]Command Approval Mode[/bold]\n\n"
        "When the agent needs to run commands on your machine, how should it behave?\n\n"
        "  [bold cyan]1[/bold cyan]. [bold]Autonomous[/bold] — Agent runs all commands freely\n"
        "     [dim]Best for experienced users. The agent can compile, simulate,\n"
        "     delete build artifacts, and modify files without asking.[/dim]\n\n"
        "  [bold cyan]2[/bold cyan]. [bold]Supervised[/bold] — Agent asks before mutating commands\n"
        "     [dim]Read-only commands and compilations run automatically.\n"
        "     Commands that delete/move/modify files will ask for your approval.[/dim]\n\n"
        "[dim]You can change this later: sigmanticai config --command-approval <mode>[/dim]",
        title="First-Time Setup",
        border_style="cyan",
    ))

    try:
        choice = input("  Select [1/2]: ").strip()
    except (EOFError, KeyboardInterrupt):
        choice = "2"

    if choice == "1":
        mode = "autonomous"
        console.print("  [green]Autonomous mode — agent has full control.[/green]")
    else:
        mode = "supervised"
        console.print("  [yellow]Supervised mode — agent will ask before deleting/modifying files.[/yellow]")

    prefs["command_approval"] = mode
    _save_preferences(prefs)
    _session_approval_mode = mode
    console.print(f"  [dim]Saved to {_PREFS_FILE}[/dim]")
    console.print()
    return mode


def set_command_approval_mode(mode: str) -> None:
    """Programmatically set the command approval mode."""
    global _session_approval_mode
    if mode not in ("autonomous", "supervised"):
        raise ValueError(f"Invalid mode: {mode!r}. Use 'autonomous' or 'supervised'.")
    prefs = _load_preferences()
    prefs["command_approval"] = mode
    _save_preferences(prefs)
    _session_approval_mode = mode


# ── Command classification ──────────────────────────────────────────

# Safe commands: read-only operations + compilation/simulation.
# These NEVER need user approval regardless of mode.
_SAFE_COMMANDS = {
    # Read-only / inspection
    "ls", "cat", "head", "tail", "grep", "find", "wc", "diff",
    "which", "echo", "env", "pwd", "cd", "file", "stat", "tree",
    "source", ".",
    # EDA tools (compile, simulate, lint, coverage)
    "verilator", "iverilog", "vvp", "yosys",
    "vcs", "simv", "urg", "vcf", "verdi", "spyglass", "sg_shell",
    "xrun", "xmsim", "xmvlog", "xmvhdl", "xmelab", "imc", "jg",
    "irun", "ncsim", "ncvlog",
    "vlog", "vopt", "vsim", "vlib", "vmap", "vcover", "qverify", "visualizer",
    "xvlog", "xvhdl", "xelab", "xsim", "xcrg", "vivado",
    # Build tools
    "make", "cmake", "gcc", "g++",
    "python3", "python",
}

# Mutating commands: these modify the filesystem or system state.
# In supervised mode, these prompt the user.
_MUTATING_COMMANDS = {
    "rm", "mv", "chmod", "chown",
    "cp", "mkdir", "touch",
    "pip", "pip3",
    "git",
    "sed", "awk", "tee",
    "tar", "gzip", "gunzip", "unzip",
}

# Always blocked — catastrophic or security-sensitive
BLOCKED_PATTERNS = [
    "curl ", "wget ", "ssh ", "scp ", "rsync ",
    "nc ", "netcat ", "ncat ",
    "> /dev/", "| /dev/",
    "sudo ", "su ",
    "mkfs", "dd if=",
    ":(){ ", "fork",
]

# rm -rf targeting root or home — matched via regex to avoid
# false positives like "rm -rf /tmp/build"
_BLOCKED_RM_RE = re.compile(
    r"rm\s+(-[a-zA-Z]*r[a-zA-Z]*\s+)*(/\s*$|/\s+|~\s*$|~\s+|~/)(?!tmp|var/tmp)",
)

COMMAND_TIMEOUT = 300  # 5 minutes
MAX_STDOUT = 500_000   # 500 KB
MAX_STDERR = 100_000   # 100 KB


def _get_base_command(command: str) -> str:
    """Extract the primary command from a shell string."""
    cmd_stripped = command.strip()
    # For chained commands, check the last one (cd /tmp && rm foo → rm)
    if "&&" in cmd_stripped:
        cmd_stripped = cmd_stripped.split("&&")[-1].strip()
    elif ";" in cmd_stripped:
        cmd_stripped = cmd_stripped.split(";")[-1].strip()
    first_word = cmd_stripped.split()[0] if cmd_stripped else ""
    return os.path.basename(first_word).lower()


def _classify_command(command: str) -> str:
    """Classify a command as 'safe', 'mutating', or 'unknown'.

    Also checks intermediate commands in chains (e.g. 'rm foo && ls' → 'mutating').
    Handles quoted strings to avoid false splits on ';' inside quotes.
    """
    parts = _split_command_chain(command)

    worst = "safe"
    for part in parts:
        first_word = part.split()[0] if part else ""
        base = os.path.basename(first_word).lower()
        if base in _MUTATING_COMMANDS:
            worst = "mutating"
        elif base not in _SAFE_COMMANDS:
            return "unknown"
    return worst


def _split_command_chain(command: str) -> list:
    """Split a command on && and ; while respecting quotes."""
    parts = []
    current = []
    in_single = False
    in_double = False
    i = 0
    s = command.strip()

    while i < len(s):
        c = s[i]
        if c == "'" and not in_double:
            in_single = not in_single
            current.append(c)
        elif c == '"' and not in_single:
            in_double = not in_double
            current.append(c)
        elif not in_single and not in_double:
            if c == ';':
                parts.append("".join(current).strip())
                current = []
            elif c == '&' and i + 1 < len(s) and s[i + 1] == '&':
                parts.append("".join(current).strip())
                current = []
                i += 1  # skip second &
            else:
                current.append(c)
        else:
            current.append(c)
        i += 1

    remainder = "".join(current).strip()
    if remainder:
        parts.append(remainder)

    return [p for p in parts if p]


def _is_blocked(command: str) -> bool:
    """Check if a command matches blocked patterns."""
    cmd_lower = command.lower()
    if any(pattern in cmd_lower for pattern in BLOCKED_PATTERNS):
        return True
    if _BLOCKED_RM_RE.search(cmd_lower):
        return True
    return False


# ── Main entry point ──────────────────────────────────────────────


async def execute_local_command(
    command: str,
    cwd: str = ".",
    auto_approve: bool = False,
) -> dict:
    """Execute a command locally with security controls.

    Args:
        command: Shell command to execute.
        cwd: Working directory (must be within the project).
        auto_approve: Skip user approval for all commands.

    Returns:
        {"stdout": str, "stderr": str, "exit_code": int}
    """
    # Always block catastrophic commands
    if _is_blocked(command):
        return {
            "stdout": "",
            "stderr": f"BLOCKED: Command rejected by security policy: {command[:100]}",
            "exit_code": -1,
        }

    # Determine if we need to prompt
    if auto_approve:
        approved = True
    else:
        classification = _classify_command(command)
        mode = get_command_approval_mode()

        if classification == "safe":
            approved = True
        elif classification == "mutating" and mode == "autonomous":
            approved = True
        else:
            # supervised + mutating, or unknown command → prompt
            approved = False

    if not approved:
        label = _classify_command(command)
        tag = "[yellow]mutating[/yellow]" if label == "mutating" else "[red]unknown[/red]"
        console.print()
        console.print(Panel(
            f"[bold yellow]The agent wants to run a command on your machine:[/bold yellow]\n\n"
            f"  [bold white]{command}[/bold white]\n\n"
            f"  Type: {tag}\n"
            f"[dim]Working directory: {cwd}[/dim]",
            title="Command Approval Required",
            border_style="yellow",
        ))
        try:
            response = input("  Allow? (y/n/always): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return {
                "stdout": "",
                "stderr": "Command rejected by user",
                "exit_code": -1,
            }

        if response in ("always", "a"):
            set_command_approval_mode("autonomous")
            console.print("  [green]Switched to autonomous mode for this and future sessions.[/green]")
            approved = True
        elif response in ("y", "yes"):
            approved = True
        else:
            console.print("  [red]Rejected.[/red]")
            return {
                "stdout": "",
                "stderr": "Command rejected by user",
                "exit_code": -1,
            }

    # Show what's running
    cmd_short = command[:120] + ("..." if len(command) > 120 else "")
    console.print(f"  [dim]Running locally:[/dim] [cyan]{cmd_short}[/cyan]")

    # Execute with timeout
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=COMMAND_TIMEOUT
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            console.print(f"  [red]Timed out after {COMMAND_TIMEOUT}s[/red]")
            return {
                "stdout": "",
                "stderr": f"Command timed out after {COMMAND_TIMEOUT} seconds",
                "exit_code": -1,
            }

        stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_STDOUT]
        stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_STDERR]
        exit_code = proc.returncode or 0

        if exit_code == 0:
            console.print(f"  [green]Done[/green] [dim](exit 0, {len(stdout)} chars)[/dim]")
        else:
            console.print(f"  [red]Failed[/red] [dim](exit {exit_code})[/dim]")

        return {"stdout": stdout, "stderr": stderr, "exit_code": exit_code}

    except Exception as e:
        console.print(f"  [red]Error: {e}[/red]")
        return {
            "stdout": "",
            "stderr": f"Execution error: {e}",
            "exit_code": -1,
        }
