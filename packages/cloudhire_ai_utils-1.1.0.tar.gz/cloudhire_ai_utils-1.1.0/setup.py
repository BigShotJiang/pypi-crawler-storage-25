"""Setup script for cloudhire-ai-utils."""

from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cloudhire-ai-utils",
    version="1.1.0",
    author="Venkatsai",
    author_email="venkatsai@example.com",
    description="Smart Recruitment Utility Library — job matching, resume parsing, validation & response formatting",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/venkatsai/cloudhire-ai-utils",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Topic :: Office/Business",
        "Intended Audience :: Developers",
    ],
    python_requires=">=3.8",
    keywords="recruitment, job matching, resume parser, hiring, AI, CloudHire",
)
