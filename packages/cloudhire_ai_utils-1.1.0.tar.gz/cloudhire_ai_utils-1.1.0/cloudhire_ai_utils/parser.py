"""
Resume Skill Extractor
======================

Extracts technical and soft skills from resume / CV text by matching
against a built-in skills database.  Supports custom skill lists and
returns structured output.

OOP Concepts Used:
    - Encapsulation  : skills database is a private attribute
    - Inheritance     : extendable via subclassing
    - Polymorphism    : ``extract`` works on any string input
"""

import logging
import re

logger = logging.getLogger("cloudhire_ai_utils.parser")


class ResumeParser:
    """Extracts skills from raw resume text.

    The parser ships with a comprehensive default skills database but
    also accepts custom skill lists.

    Examples
    --------
    >>> parser = ResumeParser()
    >>> parser.extract_skills("Experienced in Python, AWS, and SQL.")
    ['aws', 'python', 'sql']
    """

    # Default skills database — covers common tech + soft skills
    DEFAULT_SKILLS = [
        # Programming languages
        "python", "java", "javascript", "typescript", "c++", "c#", "ruby",
        "go", "rust", "php", "swift", "kotlin", "scala", "r",
        # Web frameworks & libraries
        "react", "angular", "vue", "django", "flask", "express", "nextjs",
        "spring", "laravel", "fastapi", "node.js", "nodejs",
        # Cloud & DevOps
        "aws", "azure", "gcp", "docker", "kubernetes", "terraform",
        "ci/cd", "jenkins", "github actions", "ansible",
        # Databases
        "sql", "mysql", "postgresql", "mongodb", "redis", "firebase",
        "dynamodb", "cassandra", "elasticsearch",
        # Data & AI
        "machine learning", "deep learning", "nlp", "tensorflow",
        "pytorch", "pandas", "numpy", "scikit-learn", "data analysis",
        "power bi", "tableau",
        # Other technical
        "git", "linux", "rest api", "graphql", "microservices",
        "agile", "scrum", "jira",
        # Soft skills
        "leadership", "communication", "teamwork", "problem solving",
        "critical thinking", "time management", "project management",
    ]

    def __init__(self, custom_skills=None):
        """Initialise the parser.

        Parameters
        ----------
        custom_skills : list[str], optional
            Extra skills to add to the default database.
        """
        self._skills_db = list(self.DEFAULT_SKILLS)
        if custom_skills:
            self._skills_db.extend(s.lower().strip() for s in custom_skills)
        # Sort longest first so multi-word skills are matched before substrings
        self._skills_db = sorted(set(self._skills_db), key=len, reverse=True)
        logger.info("ResumeParser initialised with %d skills in database", len(self._skills_db))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _clean_text(self, text):
        """Lowercase and collapse whitespace."""
        text = text.lower()
        text = re.sub(r"\s+", " ", text)
        return text

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract_skills(self, text):
        """Return a sorted list of unique skills found in *text*.

        Parameters
        ----------
        text : str
            Raw resume / CV text.

        Returns
        -------
        list[str]
            Alphabetically-sorted list of matched skills.
        """
        cleaned = self._clean_text(text)
        found = []

        for skill in self._skills_db:
            # Use word-boundary matching for single-word skills
            pattern = re.escape(skill)
            if re.search(rf"(?<!\w){pattern}(?!\w)", cleaned):
                found.append(skill)

        result = sorted(set(found))
        logger.info("Extracted %d skills from text (%d chars)", len(result), len(text))
        return result

    def extract_skills_with_count(self, text):
        """Return skills with their occurrence count.

        Returns
        -------
        dict[str, int]
            ``{skill: count}``
        """
        cleaned = self._clean_text(text)
        result = {}

        for skill in self._skills_db:
            pattern = re.escape(skill)
            matches = re.findall(rf"(?<!\w){pattern}(?!\w)", cleaned)
            if matches:
                result[skill] = len(matches)

        return dict(sorted(result.items()))

    def extract_summary(self, text):
        """Return a structured summary of the parsed resume.

        Returns
        -------
        dict
            Keys: ``skills``, ``skill_count``, ``text_length``,
            ``word_count``
        """
        skills = self.extract_skills(text)
        return {
            "skills": skills,
            "skill_count": len(skills),
            "text_length": len(text),
            "word_count": len(text.split()),
        }

    @property
    def skills_database(self):
        """Return a copy of the current skills database."""
        return list(self._skills_db)
