"""
CloudHire AI Utils - Smart Recruitment Utility Library
======================================================

A Python library providing intelligent recruitment-related functionalities
such as job matching, resume skill extraction, skill normalisation,
resume-to-job matching, validation, and response formatting to enhance
the efficiency and scalability of the CloudHire platform.

Modules
-------
- recommender  : Job Recommendation Engine (weighted, TF-IDF, similarity)
- parser       : Resume Skill Extractor — extracts skills from resume text
- normalizer   : Skill Normalizer — converts synonyms to canonical forms
- matcher      : Resume-to-Job Matcher — end-to-end matching pipeline
- validator    : Job Validation Module — validates job data before saving
- formatter    : API Response Formatter — standardises API responses
"""

import logging

__version__ = "1.1.0"
__author__ = "Venkatsai"

# Configure library-level logging (users can override)
logging.getLogger("cloudhire_ai_utils").addHandler(logging.NullHandler())

from cloudhire_ai_utils.recommender import JobRecommender
from cloudhire_ai_utils.parser import ResumeParser
from cloudhire_ai_utils.normalizer import SkillNormalizer
from cloudhire_ai_utils.matcher import ResumeJobMatcher
from cloudhire_ai_utils.validator import JobValidator
from cloudhire_ai_utils.formatter import ResponseFormatter

__all__ = [
    "JobRecommender",
    "ResumeParser",
    "SkillNormalizer",
    "ResumeJobMatcher",
    "JobValidator",
    "ResponseFormatter",
]
