"""
Skill Normalizer Module
=======================

Converts skill synonyms, abbreviations, and alternate spellings to
their canonical forms.  Ensures consistent skill matching across the
entire CloudHire platform.

OOP Concepts Used:
    - Encapsulation  : synonym map is a private attribute
    - Open/Closed    : add custom synonyms without modifying the class
    - Strategy Pattern : normalisation logic is swappable
"""

import logging
import re

logger = logging.getLogger("cloudhire_ai_utils.normalizer")


class SkillNormalizer:
    """Normalise skill names to canonical forms.

    Handles common abbreviations, alternate spellings, and synonyms
    so that ``"js"`` and ``"javascript"`` are treated as the same skill.

    Examples
    --------
    >>> normalizer = SkillNormalizer()
    >>> normalizer.normalize("js")
    'javascript'
    >>> normalizer.normalize_list(["py", "JS", "node"])
    ['javascript', 'nodejs', 'python']
    """

    # Built-in synonym mapping: abbreviation/alias → canonical name
    DEFAULT_SYNONYMS = {
        # Languages
        "js": "javascript",
        "javascript": "javascript",
        "py": "python",
        "python3": "python",
        "python 3": "python",
        "ts": "typescript",
        "rb": "ruby",
        "cpp": "c++",
        "c plus plus": "c++",
        "csharp": "c#",
        "c sharp": "c#",
        "golang": "go",
        "objective-c": "objective-c",
        "objc": "objective-c",

        # Web & Frameworks
        "react.js": "react",
        "reactjs": "react",
        "react js": "react",
        "vue.js": "vue",
        "vuejs": "vue",
        "vue js": "vue",
        "angular.js": "angular",
        "angularjs": "angular",
        "angular js": "angular",
        "next.js": "nextjs",
        "next js": "nextjs",
        "node": "nodejs",
        "node.js": "nodejs",
        "node js": "nodejs",
        "express.js": "express",
        "expressjs": "express",

        # Cloud
        "amazon web services": "aws",
        "amazon aws": "aws",
        "google cloud": "gcp",
        "google cloud platform": "gcp",
        "microsoft azure": "azure",

        # Databases
        "postgres": "postgresql",
        "mongo": "mongodb",
        "mongo db": "mongodb",
        "dynamodb": "dynamodb",
        "dynamo db": "dynamodb",

        # DevOps & Tools
        "k8s": "kubernetes",
        "kube": "kubernetes",
        "ci cd": "ci/cd",
        "cicd": "ci/cd",
        "continuous integration": "ci/cd",
        "github action": "github actions",
        "gh actions": "github actions",

        # Data & AI
        "ml": "machine learning",
        "dl": "deep learning",
        "artificial intelligence": "ai",
        "natural language processing": "nlp",
        "tf": "tensorflow",
        "sklearn": "scikit-learn",
        "sk-learn": "scikit-learn",
        "sci-kit learn": "scikit-learn",
        "np": "numpy",
        "pd": "pandas",

        # Methodologies
        "agile methodology": "agile",
        "scrum methodology": "scrum",
        "project mgmt": "project management",
        "pm": "project management",

        # Others
        "restful": "rest api",
        "rest": "rest api",
        "restful api": "rest api",
        "ui": "user interface",
        "ux": "user experience",
        "ui/ux": "ui/ux design",
    }

    def __init__(self, custom_synonyms=None):
        """Initialise the normalizer.

        Parameters
        ----------
        custom_synonyms : dict, optional
            Extra synonym mappings ``{alias: canonical}``.
        """
        self._synonyms = dict(self.DEFAULT_SYNONYMS)
        if custom_synonyms:
            for alias, canonical in custom_synonyms.items():
                self._synonyms[alias.lower().strip()] = canonical.lower().strip()
        logger.info(
            "SkillNormalizer initialised with %d synonym mappings",
            len(self._synonyms),
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _clean(self, skill):
        """Lowercase, strip, and collapse whitespace."""
        skill = skill.lower().strip()
        skill = re.sub(r"\s+", " ", skill)
        return skill

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def normalize(self, skill):
        """Return the canonical form of a skill.

        If no synonym is found, the skill is returned lowered and stripped.

        Parameters
        ----------
        skill : str
            Skill name or abbreviation.

        Returns
        -------
        str
            Canonical skill name.
        """
        cleaned = self._clean(skill)
        canonical = self._synonyms.get(cleaned, cleaned)
        if canonical != cleaned:
            logger.debug("Normalised '%s' → '%s'", cleaned, canonical)
        return canonical

    def normalize_list(self, skills):
        """Normalise a list of skills and return sorted unique results.

        Parameters
        ----------
        skills : list[str]
            Raw skill names.

        Returns
        -------
        list[str]
            Sorted list of unique canonical skill names.
        """
        normalised = {self.normalize(s) for s in skills if isinstance(s, str) and s.strip()}
        logger.info("Normalised %d skills → %d unique canonical skills", len(skills), len(normalised))
        return sorted(normalised)

    def add_synonym(self, alias, canonical):
        """Register a new synonym at runtime.

        Parameters
        ----------
        alias : str
            The abbreviation or alternate spelling.
        canonical : str
            The canonical/standard form.
        """
        self._synonyms[alias.lower().strip()] = canonical.lower().strip()
        logger.info("Added synonym: '%s' → '%s'", alias, canonical)

    def get_synonyms_for(self, canonical):
        """Return all aliases that map to a given canonical name.

        Parameters
        ----------
        canonical : str
            The canonical skill name.

        Returns
        -------
        list[str]
            All registered aliases.
        """
        canonical = canonical.lower().strip()
        return sorted(
            alias for alias, canon in self._synonyms.items() if canon == canonical
        )

    @property
    def synonym_count(self):
        """Return the total number of synonym mappings."""
        return len(self._synonyms)

    @property
    def all_canonical_skills(self):
        """Return a sorted list of all unique canonical skill names."""
        return sorted(set(self._synonyms.values()))
