"""
API Response Formatter
======================

Provides a standardised structure for API responses across the entire
CloudHire platform.  Ensures every endpoint returns consistent JSON
with ``status``, ``data`` / ``message``, and optional metadata.

OOP Concepts Used:
    - Static methods  : utility methods that don't need instance state
    - Encapsulation   : internal timestamp helper is private
    - Class methods   : alternative constructors for common patterns
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger("cloudhire_ai_utils.formatter")


class ResponseFormatter:
    """Standardise API response dictionaries.

    Every response contains at minimum:
    - ``status``    : ``"success"`` or ``"error"``
    - ``timestamp`` : ISO-8601 UTC timestamp

    Examples
    --------
    >>> ResponseFormatter.success({"id": 1, "title": "Dev"})
    {'status': 'success', 'data': {'id': 1, 'title': 'Dev'}, 'timestamp': '...'}

    >>> ResponseFormatter.error("Not found", code=404)
    {'status': 'error', 'message': 'Not found', 'code': 404, 'timestamp': '...'}
    """

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _timestamp():
        """Return the current UTC time as an ISO-8601 string."""
        return datetime.now(timezone.utc).isoformat()

    # ------------------------------------------------------------------
    # Core responses
    # ------------------------------------------------------------------

    @staticmethod
    def success(data, message=None, meta=None):
        """Build a success response.

        Parameters
        ----------
        data : any
            Payload (dict, list, primitive, etc.).
        message : str, optional
            Optional human-readable message.
        meta : dict, optional
            Optional metadata (pagination, counts, etc.).

        Returns
        -------
        dict
        """
        resp = {
            "status": "success",
            "data": data,
            "timestamp": ResponseFormatter._timestamp(),
        }
        if message:
            resp["message"] = message
        if meta:
            resp["meta"] = meta
        logger.debug("Success response built")
        return resp

    @staticmethod
    def error(message, code=None, details=None):
        """Build an error response.

        Parameters
        ----------
        message : str
            Human-readable error description.
        code : int, optional
            HTTP status code hint.
        details : any, optional
            Extra error context (validation errors, stack traces, etc.).

        Returns
        -------
        dict
        """
        resp = {
            "status": "error",
            "message": message,
            "timestamp": ResponseFormatter._timestamp(),
        }
        if code is not None:
            resp["code"] = code
        if details is not None:
            resp["details"] = details
        logger.warning("Error response: [%s] %s", code, message)
        return resp

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @staticmethod
    def paginated(data, page, per_page, total):
        """Build a paginated success response.

        Parameters
        ----------
        data : list
            Items for the current page.
        page : int
            Current page number (1-based).
        per_page : int
            Items per page.
        total : int
            Total number of items across all pages.

        Returns
        -------
        dict
        """
        total_pages = -(-total // per_page)  # ceil division
        meta = {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": total_pages,
            "has_next": page < total_pages,
            "has_prev": page > 1,
        }
        return ResponseFormatter.success(data, meta=meta)

    @staticmethod
    def created(data, message="Resource created successfully"):
        """Shortcut for 201-Created responses."""
        resp = ResponseFormatter.success(data, message=message)
        resp["code"] = 201
        return resp

    @staticmethod
    def deleted(resource_id, message="Resource deleted successfully"):
        """Shortcut for delete-confirmation responses."""
        return ResponseFormatter.success(
            {"deleted_id": resource_id},
            message=message,
        )

    @staticmethod
    def not_found(resource="Resource"):
        """Shortcut for 404 responses."""
        return ResponseFormatter.error(f"{resource} not found", code=404)

    @staticmethod
    def unauthorized(message="Authentication required"):
        """Shortcut for 401 responses."""
        return ResponseFormatter.error(message, code=401)

    @staticmethod
    def validation_error(errors):
        """Shortcut for 422 validation-error responses."""
        return ResponseFormatter.error(
            "Validation failed",
            code=422,
            details=errors if isinstance(errors, list) else [errors],
        )
