"""
Job Validation Module
=====================

Validates job posting data before it is saved to a database or sent
to an API.  Supports required-field checks, type validation, salary
range validation, and custom rule registration.

OOP Concepts Used:
    - Encapsulation  : validation rules stored privately
    - Open/Closed    : add custom rules without modifying the class
    - Single Responsibility : only handles validation
"""

import logging
import re
from datetime import datetime

logger = logging.getLogger("cloudhire_ai_utils.validator")


class ValidationError(Exception):
    """Raised when one or more validation rules fail.

    Attributes
    ----------
    errors : list[str]
        Human-readable error messages.
    """

    def __init__(self, errors):
        self.errors = errors if isinstance(errors, list) else [errors]
        super().__init__("; ".join(self.errors))


class JobValidator:
    """Validates job posting dictionaries against configurable rules.

    Examples
    --------
    >>> validator = JobValidator()
    >>> validator.validate({"title": "Dev", "skills": ["python"]})
    True
    >>> validator.validate({})  # raises ValidationError
    """

    # Fields that must be present and non-empty
    REQUIRED_FIELDS = ["title", "skills"]

    # Maximum allowed lengths
    MAX_LENGTHS = {
        "title": 200,
        "description": 5000,
        "location": 200,
        "company": 200,
    }

    VALID_STATUSES = {"active", "inactive", "draft", "closed"}
    VALID_JOB_TYPES = {"full-time", "part-time", "contract", "internship", "freelance"}

    def __init__(self, extra_required=None):
        """Initialise the validator.

        Parameters
        ----------
        extra_required : list[str], optional
            Additional fields to treat as required.
        """
        self._required = list(self.REQUIRED_FIELDS)
        if extra_required:
            self._required.extend(extra_required)
        self._custom_rules = []
        logger.info("JobValidator initialised with %d required fields", len(self._required))

    # ------------------------------------------------------------------
    # Rule registration
    # ------------------------------------------------------------------

    def add_rule(self, rule_fn, message="Custom validation failed"):
        """Register a custom validation rule.

        Parameters
        ----------
        rule_fn : callable
            A function that takes ``job`` dict and returns ``True`` (pass)
            or ``False`` (fail).
        message : str
            Error message if the rule fails.
        """
        self._custom_rules.append((rule_fn, message))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _check_required(self, job):
        errors = []
        for field in self._required:
            value = job.get(field)
            if value is None or (isinstance(value, str) and not value.strip()):
                errors.append(f"'{field}' is required and cannot be empty")
            elif isinstance(value, list) and len(value) == 0:
                errors.append(f"'{field}' must contain at least one item")
        return errors

    def _check_types(self, job):
        errors = []
        if "skills" in job and not isinstance(job["skills"], list):
            errors.append("'skills' must be a list")
        if "title" in job and not isinstance(job["title"], str):
            errors.append("'title' must be a string")
        if "salary_min" in job and not isinstance(job["salary_min"], (int, float)):
            errors.append("'salary_min' must be a number")
        if "salary_max" in job and not isinstance(job["salary_max"], (int, float)):
            errors.append("'salary_max' must be a number")
        return errors

    def _check_lengths(self, job):
        errors = []
        for field, max_len in self.MAX_LENGTHS.items():
            if field in job and isinstance(job[field], str) and len(job[field]) > max_len:
                errors.append(f"'{field}' exceeds maximum length of {max_len}")
        return errors

    def _check_salary_range(self, job):
        errors = []
        s_min = job.get("salary_min")
        s_max = job.get("salary_max")
        if s_min is not None and s_max is not None:
            if s_min < 0 or s_max < 0:
                errors.append("Salary values cannot be negative")
            elif s_min > s_max:
                errors.append("'salary_min' cannot exceed 'salary_max'")
        return errors

    def _check_status(self, job):
        errors = []
        status = job.get("status")
        if status is not None and status.lower() not in self.VALID_STATUSES:
            errors.append(
                f"Invalid status '{status}'. Must be one of: {', '.join(sorted(self.VALID_STATUSES))}"
            )
        return errors

    def _check_job_type(self, job):
        errors = []
        job_type = job.get("type") or job.get("job_type")
        if job_type is not None and job_type.lower() not in self.VALID_JOB_TYPES:
            errors.append(
                f"Invalid job type '{job_type}'. Must be one of: {', '.join(sorted(self.VALID_JOB_TYPES))}"
            )
        return errors

    def _check_email(self, job):
        errors = []
        email = job.get("contact_email")
        if email is not None:
            pattern = r"^[\w\.\+\-]+@[\w\-]+\.[\w\.\-]+$"
            if not re.match(pattern, email):
                errors.append(f"Invalid email format: '{email}'")
        return errors

    def _run_custom_rules(self, job):
        errors = []
        for rule_fn, message in self._custom_rules:
            try:
                if not rule_fn(job):
                    errors.append(message)
            except Exception as exc:
                errors.append(f"Custom rule error: {exc}")
        return errors

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(self, job):
        """Validate a job dictionary and return ``True`` or raise
        :class:`ValidationError`.

        Parameters
        ----------
        job : dict
            Job posting data.

        Returns
        -------
        bool
            ``True`` if all validations pass.

        Raises
        ------
        ValidationError
            If one or more rules fail.
        """
        if not isinstance(job, dict):
            raise ValidationError("Job data must be a dictionary")

        errors = []
        errors.extend(self._check_required(job))
        errors.extend(self._check_types(job))
        errors.extend(self._check_lengths(job))
        errors.extend(self._check_salary_range(job))
        errors.extend(self._check_status(job))
        errors.extend(self._check_job_type(job))
        errors.extend(self._check_email(job))
        errors.extend(self._run_custom_rules(job))

        if errors:
            logger.warning("Validation failed with %d errors: %s", len(errors), errors)
            raise ValidationError(errors)

        logger.info("Job validated successfully: '%s'", job.get('title', '?'))
        return True

    def is_valid(self, job):
        """Return ``True`` / ``False`` without raising."""
        try:
            return self.validate(job)
        except ValidationError:
            return False

    def get_errors(self, job):
        """Return a list of error strings (empty if valid)."""
        try:
            self.validate(job)
            return []
        except ValidationError as exc:
            return exc.errors
