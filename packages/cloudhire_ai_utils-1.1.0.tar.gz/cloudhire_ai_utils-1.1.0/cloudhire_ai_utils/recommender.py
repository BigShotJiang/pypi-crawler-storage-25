"""
Job Recommendation Engine
=========================

Provides intelligent job matching by comparing a candidate's skills against
job listings and returning ranked results based on multiple scoring methods:

- **Weighted scoring**   : custom skill weights for prioritisation
- **TF-IDF scoring**     : term frequency–inverse document frequency
- **Similarity scoring**  : Jaccard similarity coefficient

OOP Concepts Used:
    - Encapsulation  : internal scoring logic is private
    - Abstraction    : simple public API hides complexity
    - Single Responsibility : only handles recommendation logic
    - Strategy Pattern : multiple scoring algorithms available
"""

import logging
import math

logger = logging.getLogger("cloudhire_ai_utils.recommender")


class JobRecommender:
    """Matches candidate skills to job listings and ranks them by relevance.

    Supports three scoring strategies:
    - ``"weighted"`` (default) — uses custom skill weights
    - ``"tfidf"`` — TF-IDF based scoring across all job listings
    - ``"similarity"`` — Jaccard similarity coefficient

    Attributes
    ----------
    skill_weights : dict
        Optional dictionary mapping skill names to numeric weights.
        Skills not listed default to a weight of 1.

    Examples
    --------
    >>> recommender = JobRecommender()
    >>> jobs = [
    ...     {"id": 1, "title": "Backend Dev", "skills": ["python", "sql", "aws"]},
    ...     {"id": 2, "title": "Frontend Dev", "skills": ["react", "css", "js"]},
    ... ]
    >>> recommender.recommend_jobs(["python", "aws"], jobs)
    [({'id': 1, 'title': 'Backend Dev', 'skills': ['python', 'sql', 'aws']}, 2)]
    """

    def __init__(self, skill_weights=None):
        """Initialise the recommender with optional skill weights.

        Parameters
        ----------
        skill_weights : dict, optional
            e.g. ``{"python": 3, "aws": 2}`` — higher weight = more important.
        """
        self._skill_weights = skill_weights or {}
        logger.info("JobRecommender initialised with %d skill weights", len(self._skill_weights))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _normalise(self, skills):
        """Return a set of lower-cased, stripped skill strings."""
        return {s.strip().lower() for s in skills if isinstance(s, str)}

    def _calculate_score(self, user_skills_set, job_skills_set):
        """Return a weighted score for the overlap between two skill sets."""
        overlap = user_skills_set & job_skills_set
        score = sum(self._skill_weights.get(skill, 1) for skill in overlap)
        return score

    def _match_percentage(self, user_skills_set, job_skills_set):
        """Return the percentage of job skills the candidate covers."""
        if not job_skills_set:
            return 0.0
        overlap = user_skills_set & job_skills_set
        return round(len(overlap) / len(job_skills_set) * 100, 2)

    # ------------------------------------------------------------------
    # Scoring strategies
    # ------------------------------------------------------------------

    def similarity_score(self, user_skills, job_skills):
        """Calculate Jaccard similarity between candidate and job skills.

        Jaccard = |intersection| / |union|

        Parameters
        ----------
        user_skills : list[str]
            Candidate skills.
        job_skills : list[str]
            Job required skills.

        Returns
        -------
        float
            Similarity score between 0.0 and 1.0.
        """
        user_set = self._normalise(user_skills)
        job_set = self._normalise(job_skills)
        if not user_set and not job_set:
            return 0.0
        intersection = user_set & job_set
        union = user_set | job_set
        score = len(intersection) / len(union) if union else 0.0
        logger.debug("Jaccard similarity: %.4f (intersection=%d, union=%d)", score, len(intersection), len(union))
        return round(score, 4)

    def tfidf_score(self, user_skills, job, all_jobs):
        """Calculate a TF-IDF inspired score for a candidate-job pair.

        - **TF (Term Frequency)**: How many of the user's skills appear in
          this job's requirements.
        - **IDF (Inverse Document Frequency)**: Skills required by fewer
          jobs are weighted higher (rarer = more valuable match).

        Parameters
        ----------
        user_skills : list[str]
            Candidate skills.
        job : dict
            Single job with a ``"skills"`` key.
        all_jobs : list[dict]
            All jobs — used to calculate IDF.

        Returns
        -------
        float
            TF-IDF score (higher = better match).
        """
        user_set = self._normalise(user_skills)
        job_set = self._normalise(job.get("skills", []))
        overlap = user_set & job_set

        if not overlap or not job_set:
            return 0.0

        total_jobs = len(all_jobs)
        score = 0.0

        for skill in overlap:
            # TF: fraction of job skills matched
            tf = 1 / len(job_set)
            # IDF: log(total_jobs / jobs_with_this_skill)
            jobs_with_skill = sum(
                1 for j in all_jobs
                if skill in self._normalise(j.get("skills", []))
            )
            idf = math.log((total_jobs + 1) / (jobs_with_skill + 1)) + 1
            score += tf * idf

        logger.debug("TF-IDF score for job '%s': %.4f", job.get("title", "?"), score)
        return round(score, 4)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def recommend_jobs(self, user_skills, jobs, min_score=1):
        """Return a list of ``(job, score)`` tuples sorted by score descending.

        Uses weighted scoring by default.

        Parameters
        ----------
        user_skills : list[str]
            Skills the candidate possesses.
        jobs : list[dict]
            Each dict must contain a ``"skills"`` key with a list of strings.
        min_score : int, optional
            Minimum score threshold (default ``1``).

        Returns
        -------
        list[tuple[dict, int]]
            Matched jobs with their scores, best first.
        """
        logger.info("recommend_jobs called with %d user skills, %d jobs", len(user_skills), len(jobs))
        user_set = self._normalise(user_skills)
        matched = []

        for job in jobs:
            job_set = self._normalise(job.get("skills", []))
            score = self._calculate_score(user_set, job_set)
            if score >= min_score:
                matched.append((job, score))

        logger.info("Found %d matching jobs (min_score=%d)", len(matched), min_score)
        return sorted(matched, key=lambda x: x[1], reverse=True)

    def recommend_jobs_detailed(self, user_skills, jobs, min_score=1):
        """Return detailed recommendation results including match percentage.

        Parameters
        ----------
        user_skills : list[str]
            Skills the candidate possesses.
        jobs : list[dict]
            Each dict must contain a ``"skills"`` key.
        min_score : int, optional
            Minimum score threshold (default ``1``).

        Returns
        -------
        list[dict]
            Each dict contains ``job``, ``score``, ``match_pct``,
            ``matched_skills``, and ``missing_skills``.
        """
        logger.info("recommend_jobs_detailed called with %d user skills, %d jobs", len(user_skills), len(jobs))
        user_set = self._normalise(user_skills)
        results = []

        for job in jobs:
            job_set = self._normalise(job.get("skills", []))
            score = self._calculate_score(user_set, job_set)

            if score >= min_score:
                overlap = user_set & job_set
                missing = job_set - user_set
                similarity = self.similarity_score(user_skills, job.get("skills", []))
                tfidf = self.tfidf_score(user_skills, job, jobs)

                results.append({
                    "job": job,
                    "score": score,
                    "match_pct": self._match_percentage(user_set, job_set),
                    "similarity": similarity,
                    "tfidf_score": tfidf,
                    "matched_skills": sorted(overlap),
                    "missing_skills": sorted(missing),
                })

        return sorted(results, key=lambda x: x["score"], reverse=True)

    def recommend_by_similarity(self, user_skills, jobs, min_similarity=0.1):
        """Rank jobs using Jaccard similarity scoring.

        Parameters
        ----------
        user_skills : list[str]
            Candidate skills.
        jobs : list[dict]
            Job listings.
        min_similarity : float, optional
            Minimum similarity threshold (0.0–1.0). Default ``0.1``.

        Returns
        -------
        list[tuple[dict, float]]
            ``(job, similarity)`` sorted descending.
        """
        logger.info("recommend_by_similarity called (min=%.2f)", min_similarity)
        results = []
        for job in jobs:
            sim = self.similarity_score(user_skills, job.get("skills", []))
            if sim >= min_similarity:
                results.append((job, sim))
        return sorted(results, key=lambda x: x[1], reverse=True)

    def recommend_by_tfidf(self, user_skills, jobs, min_score=0.1):
        """Rank jobs using TF-IDF scoring.

        Parameters
        ----------
        user_skills : list[str]
            Candidate skills.
        jobs : list[dict]
            Job listings (also used as corpus for IDF).
        min_score : float, optional
            Minimum TF-IDF threshold. Default ``0.1``.

        Returns
        -------
        list[tuple[dict, float]]
            ``(job, tfidf_score)`` sorted descending.
        """
        logger.info("recommend_by_tfidf called (min=%.2f)", min_score)
        results = []
        for job in jobs:
            score = self.tfidf_score(user_skills, job, jobs)
            if score >= min_score:
                results.append((job, score))
        return sorted(results, key=lambda x: x[1], reverse=True)

    def top_n(self, user_skills, jobs, n=5):
        """Convenience method — return the top *n* matched jobs."""
        return self.recommend_jobs(user_skills, jobs)[:n]
