"""
Resume-to-Job Matcher (High-Level Bridge)
==========================================

Combines the ResumeParser, SkillNormalizer, and JobRecommender into
a single high-level interface.  Pass in raw resume text and a list of
jobs — get ranked matches back in one call.

OOP Concepts Used:
    - Composition     : composes Parser, Normalizer, and Recommender
    - Facade Pattern  : single entry point hides multi-step workflow
    - Encapsulation   : internal pipeline is private
"""

import logging

from cloudhire_ai_utils.parser import ResumeParser
from cloudhire_ai_utils.normalizer import SkillNormalizer
from cloudhire_ai_utils.recommender import JobRecommender

logger = logging.getLogger("cloudhire_ai_utils.matcher")


class ResumeJobMatcher:
    """One-call resume-to-job matching pipeline.

    Internally:
    1. Extracts skills from resume text  (``ResumeParser``)
    2. Normalises extracted skills        (``SkillNormalizer``)
    3. Matches normalised skills to jobs  (``JobRecommender``)

    Examples
    --------
    >>> matcher = ResumeJobMatcher()
    >>> jobs = [
    ...     {"id": 1, "title": "Backend Dev", "skills": ["python", "aws"]},
    ...     {"id": 2, "title": "Frontend Dev", "skills": ["react", "css"]},
    ... ]
    >>> results = matcher.match("Experienced in py and AWS", jobs)
    >>> results[0]["job"]["title"]
    'Backend Dev'
    """

    def __init__(self, skill_weights=None, custom_skills=None, custom_synonyms=None):
        """Initialise all sub-components.

        Parameters
        ----------
        skill_weights : dict, optional
            Passed to ``JobRecommender``.
        custom_skills : list[str], optional
            Extra skills for ``ResumeParser``.
        custom_synonyms : dict, optional
            Extra synonym mappings for ``SkillNormalizer``.
        """
        self._parser = ResumeParser(custom_skills=custom_skills)
        self._normalizer = SkillNormalizer(custom_synonyms=custom_synonyms)
        self._recommender = JobRecommender(skill_weights=skill_weights)
        logger.info("ResumeJobMatcher initialised")

    # ------------------------------------------------------------------
    # Private pipeline
    # ------------------------------------------------------------------

    def _extract_and_normalise(self, resume_text):
        """Extract skills from text, then normalise them."""
        raw_skills = self._parser.extract_skills(resume_text)
        normalised = self._normalizer.normalize_list(raw_skills)
        logger.info(
            "Extracted %d raw skills → %d normalised",
            len(raw_skills),
            len(normalised),
        )
        return raw_skills, normalised

    def _normalise_job_skills(self, jobs):
        """Return a copy of jobs with normalised skill lists."""
        normalised_jobs = []
        for job in jobs:
            job_copy = dict(job)
            job_copy["skills"] = self._normalizer.normalize_list(
                job.get("skills", [])
            )
            normalised_jobs.append(job_copy)
        return normalised_jobs

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def match(self, resume_text, jobs, min_score=1):
        """Match a resume against job listings.

        Parameters
        ----------
        resume_text : str
            Raw CV / resume content.
        jobs : list[dict]
            Job postings with a ``"skills"`` key.
        min_score : int, optional
            Minimum match score threshold.

        Returns
        -------
        list[dict]
            Detailed results with ``job``, ``score``, ``match_pct``,
            ``matched_skills``, ``missing_skills``, and
            ``candidate_skills``.
        """
        raw_skills, normalised_skills = self._extract_and_normalise(resume_text)
        normalised_jobs = self._normalise_job_skills(jobs)

        results = self._recommender.recommend_jobs_detailed(
            normalised_skills, normalised_jobs, min_score=min_score
        )

        # Attach the candidate's extracted skills to each result
        for r in results:
            r["candidate_skills"] = normalised_skills

        logger.info(
            "Matched resume (%d skills) against %d jobs → %d results",
            len(normalised_skills),
            len(jobs),
            len(results),
        )
        return results

    def match_top_n(self, resume_text, jobs, n=5):
        """Return only the top *n* matches."""
        return self.match(resume_text, jobs)[:n]

    def quick_match(self, resume_text, jobs):
        """Return simple ``(job, score)`` tuples (no details).

        Parameters
        ----------
        resume_text : str
            Raw resume text.
        jobs : list[dict]
            Job listings.

        Returns
        -------
        list[tuple[dict, int]]
        """
        _, normalised_skills = self._extract_and_normalise(resume_text)
        normalised_jobs = self._normalise_job_skills(jobs)
        return self._recommender.recommend_jobs(normalised_skills, normalised_jobs)

    def analyse_resume(self, resume_text):
        """Return a full analysis of a resume without matching to jobs.

        Returns
        -------
        dict
            ``raw_skills``, ``normalised_skills``, ``summary``
        """
        raw_skills, normalised_skills = self._extract_and_normalise(resume_text)
        summary = self._parser.extract_summary(resume_text)
        return {
            "raw_skills": raw_skills,
            "normalised_skills": normalised_skills,
            "summary": summary,
        }
