"""Google Search Console API client.

Uses a service account for authentication and wraps the
``searchanalytics.query`` endpoint with pagination support.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Literal

from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build, Resource

logger = logging.getLogger(__name__)

# GSC API hard-caps rows at 25 000 per request.
_MAX_ROWS_PER_REQUEST = 25_000

DimensionType = Literal["query", "page", "country", "device", "date"]


class GSCClient:
    """Thin wrapper around the Search Console ``searchanalytics`` API."""

    def __init__(self, credentials_path: str | Path, site_url: str) -> None:
        self._site_url = site_url
        self._service = self._build_service(credentials_path)

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    @staticmethod
    def _build_service(credentials_path: str | Path) -> Resource:
        scopes = ["https://www.googleapis.com/auth/webmasters.readonly"]
        creds = Credentials.from_service_account_file(str(credentials_path), scopes=scopes)
        return build("searchconsole", "v1", credentials=creds, cache_discovery=False)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fetch_data(
        self,
        start_date: date,
        end_date: date,
        dimensions: list[DimensionType] | DimensionType = "query",
        row_limit: int = 50_000,
        dimension_filter_groups: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch query-level or page-level data with automatic pagination.

        Parameters
        ----------
        start_date, end_date:
            Date range (inclusive).
        dimensions:
            One or more dimensions to group by.
        row_limit:
            Maximum total rows to retrieve across all pages.
        dimension_filter_groups:
            Optional GSC API filter groups.

        Returns
        -------
        list[dict]:
            Each dict has ``keys`` (list[str]) matching requested dimensions,
            plus ``clicks``, ``impressions``, ``ctr``, ``position``.
        """
        if isinstance(dimensions, str):
            dimensions = [dimensions]

        all_rows: list[dict[str, Any]] = []
        start_row = 0

        while start_row < row_limit:
            page_size = min(_MAX_ROWS_PER_REQUEST, row_limit - start_row)
            body: dict[str, Any] = {
                "startDate": start_date.isoformat(),
                "endDate": end_date.isoformat(),
                "dimensions": dimensions,
                "rowLimit": page_size,
                "startRow": start_row,
                "dataState": "final",
            }
            if dimension_filter_groups:
                body["dimensionFilterGroups"] = dimension_filter_groups

            response = self._execute_query(body)
            rows = response.get("rows", [])

            if not rows:
                break

            all_rows.extend(rows)
            start_row += len(rows)

            # Fewer rows than requested means we've exhausted the data.
            if len(rows) < page_size:
                break

        logger.info("Fetched %d rows for dimensions=%s (%s to %s)", len(all_rows), dimensions, start_date, end_date)
        return all_rows

    def fetch_site_totals(self, start_date: date, end_date: date) -> dict[str, float]:
        """Return aggregate totals (no dimension grouping).

        Returns
        -------
        dict with ``clicks``, ``impressions``, ``ctr``, ``position``.
        """
        body = {
            "startDate": start_date.isoformat(),
            "endDate": end_date.isoformat(),
            "dataState": "final",
        }
        response = self._execute_query(body)
        rows = response.get("rows", [])
        if rows:
            return {
                "clicks": rows[0].get("clicks", 0),
                "impressions": rows[0].get("impressions", 0),
                "ctr": rows[0].get("ctr", 0.0),
                "position": rows[0].get("position", 0.0),
            }
        return {"clicks": 0, "impressions": 0, "ctr": 0.0, "position": 0.0}

    # ------------------------------------------------------------------
    # Convenience date helpers
    # ------------------------------------------------------------------

    @staticmethod
    def last_7_days(ref: date | None = None) -> tuple[date, date]:
        """Return (start, end) for the 7-day window ending 3 days ago (GSC lag)."""
        ref = ref or date.today()
        end = ref - timedelta(days=3)
        start = end - timedelta(days=6)
        return start, end

    @staticmethod
    def previous_7_days(ref: date | None = None) -> tuple[date, date]:
        """Return the 7-day window immediately before ``last_7_days``."""
        ref = ref or date.today()
        end = ref - timedelta(days=10)
        start = end - timedelta(days=6)
        return start, end

    @staticmethod
    def last_28_days(ref: date | None = None) -> tuple[date, date]:
        ref = ref or date.today()
        end = ref - timedelta(days=3)
        start = end - timedelta(days=27)
        return start, end

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _execute_query(self, body: dict[str, Any]) -> dict[str, Any]:
        """Execute a single ``searchanalytics.query`` request."""
        return (
            self._service.searchanalytics()
            .query(siteUrl=self._site_url, body=body)
            .execute()
        )
