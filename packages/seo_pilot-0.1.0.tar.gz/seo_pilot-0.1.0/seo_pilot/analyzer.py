"""SEO analysis engine.

Takes aggregated GSC data for two consecutive periods and produces
actionable findings: low-hanging fruit, content gaps, rising queries,
position drops, auto-tracked pages, and plain-English recommendations.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Expected CTR benchmarks by position (rounded midpoints from industry data)
# ---------------------------------------------------------------------------

EXPECTED_CTR: dict[int, float] = {
    1: 0.28,
    2: 0.16,
    3: 0.11,
    4: 0.08,
    5: 0.07,
    6: 0.05,
    7: 0.04,
    8: 0.035,
    9: 0.03,
    10: 0.03,
}


def expected_ctr_for_position(pos: float) -> float:
    """Return the expected CTR for a given average position.

    Interpolates linearly between benchmark positions.  For positions
    beyond 10 we extrapolate a 1.5 % floor.
    """
    if pos <= 1:
        return EXPECTED_CTR[1]
    if pos >= 10:
        return 0.015

    lower = int(pos)
    upper = lower + 1
    frac = pos - lower
    ctr_low = EXPECTED_CTR.get(lower, 0.015)
    ctr_high = EXPECTED_CTR.get(upper, 0.015)
    return ctr_low + (ctr_high - ctr_low) * frac


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------

def _score_low_hanging_fruit(row: dict[str, Any]) -> float:
    """Score a query/page for low-hanging-fruit potential.

    Weights per guidelines:
        impressions  30 %
        position     25 %  (closer to page 1 = higher)
        CTR gap      25 %  (actual vs expected)
        clicks       20 %  (existing traction)
    """
    imp = row.get("impressions", 0)
    pos = row.get("position", 50.0)
    ctr = row.get("ctr", 0.0)
    clicks = row.get("clicks", 0)

    # Normalise impressions (log-ish scale, cap at 1.0)
    imp_score = min(imp / 1000, 1.0)

    # Position score: 1 = best, decays as position grows
    pos_score = max(0.0, 1.0 - (pos - 1) / 20)

    # CTR gap: how much below expected CTR
    exp = expected_ctr_for_position(pos)
    gap = max(0.0, exp - ctr)
    gap_score = min(gap / exp, 1.0) if exp > 0 else 0.0

    # Click traction
    click_score = min(clicks / 100, 1.0)

    return round(
        imp_score * 0.30
        + pos_score * 0.25
        + gap_score * 0.25
        + click_score * 0.20,
        4,
    )


def _pct_change(current: float, previous: float) -> float | None:
    if previous == 0:
        return None
    return (current - previous) / previous


# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------

@dataclass
class AnalysisResult:
    low_hanging_fruit: list[dict[str, Any]] = field(default_factory=list)
    content_gaps: list[dict[str, Any]] = field(default_factory=list)
    rising_queries: list[dict[str, Any]] = field(default_factory=list)
    position_drops: list[dict[str, Any]] = field(default_factory=list)
    auto_tracked: list[dict[str, Any]] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


def analyze(
    pages_this: list[dict[str, Any]],
    pages_prev: list[dict[str, Any]],
    queries_this: list[dict[str, Any]],
    queries_prev: list[dict[str, Any]],
    blog_slugs: list[str] | None = None,
) -> AnalysisResult:
    """Run the full analysis suite and return an ``AnalysisResult``.

    Parameters
    ----------
    pages_this / pages_prev:
        Aggregated page-dimension data for the current and previous period.
        Each entry: ``{"key": str, "impressions": int, "clicks": int,
        "ctr": float, "position": float}``.
    queries_this / queries_prev:
        Same structure but for the query dimension.
    blog_slugs:
        Optional list of URL path prefixes that identify blog content.
    """
    result = AnalysisResult()
    blog_slugs = blog_slugs or []

    prev_queries_map = {q["key"]: q for q in queries_prev}
    prev_pages_map = {p["key"]: p for p in pages_prev}

    # ----- Low-hanging fruit (queries) -----
    for q in queries_this:
        pos = q.get("position", 50)
        imp = q.get("impressions", 0)
        if 4 <= pos <= 20 and imp >= 10:
            score = _score_low_hanging_fruit(q)
            result.low_hanging_fruit.append({**q, "lhf_score": score})

    result.low_hanging_fruit.sort(key=lambda x: x["lhf_score"], reverse=True)

    # ----- Rising queries (>30 % WoW impression growth) -----
    for q in queries_this:
        prev = prev_queries_map.get(q["key"])
        if not prev:
            # Brand new query with decent volume counts as rising
            if q.get("impressions", 0) >= 20:
                result.rising_queries.append({
                    **q,
                    "growth_pct": None,
                    "note": "new query this period",
                })
            continue

        change = _pct_change(q.get("impressions", 0), prev.get("impressions", 0))
        if change is not None and change > 0.30 and q.get("impressions", 0) >= 10:
            result.rising_queries.append({
                **q,
                "prev_impressions": prev.get("impressions", 0),
                "growth_pct": round(change * 100, 1),
            })

    result.rising_queries.sort(key=lambda x: x.get("impressions", 0), reverse=True)

    # ----- Position drops (>2 position drop, impressions >= 10) -----
    for q in queries_this:
        prev = prev_queries_map.get(q["key"])
        if not prev:
            continue
        pos_diff = q.get("position", 0) - prev.get("position", 0)
        if pos_diff > 2 and q.get("impressions", 0) >= 10:
            result.position_drops.append({
                **q,
                "prev_position": prev.get("position", 0),
                "position_change": round(pos_diff, 1),
            })

    result.position_drops.sort(key=lambda x: x.get("position_change", 0), reverse=True)

    # ----- Content gaps (queries with impressions but no/minimal clicks) -----
    for q in queries_this:
        imp = q.get("impressions", 0)
        clicks = q.get("clicks", 0)
        pos = q.get("position", 50)
        if imp >= 50 and clicks <= 1 and pos <= 30:
            expected = expected_ctr_for_position(pos)
            result.content_gaps.append({
                **q,
                "expected_ctr": round(expected, 4),
                "ctr_gap": round(expected - q.get("ctr", 0), 4),
            })

    result.content_gaps.sort(key=lambda x: x.get("impressions", 0), reverse=True)

    # ----- Auto-tracked pages (50+ impressions) -----
    for p in pages_this:
        if p.get("impressions", 0) >= 50:
            prev = prev_pages_map.get(p["key"])
            entry: dict[str, Any] = {**p}
            if prev:
                imp_change = _pct_change(p["impressions"], prev.get("impressions", 0))
                pos_change = p.get("position", 0) - prev.get("position", 0)
                entry["imp_change_pct"] = round(imp_change * 100, 1) if imp_change is not None else None
                entry["pos_change"] = round(pos_change, 1)
            result.auto_tracked.append(entry)

    result.auto_tracked.sort(key=lambda x: x.get("impressions", 0), reverse=True)

    # ----- Recommendations -----
    result.recommendations = _build_recommendations(result, blog_slugs)

    logger.info(
        "Analysis complete: %d LHF, %d rising, %d drops, %d gaps, %d tracked",
        len(result.low_hanging_fruit),
        len(result.rising_queries),
        len(result.position_drops),
        len(result.content_gaps),
        len(result.auto_tracked),
    )
    return result


def _build_recommendations(r: AnalysisResult, blog_slugs: list[str]) -> list[str]:
    """Generate plain-English recommendations from analysis findings."""
    recs: list[str] = []

    # Top LHF
    for item in r.low_hanging_fruit[:5]:
        key = item["key"]
        pos = item.get("position", 0)
        imp = item.get("impressions", 0)
        score = item.get("lhf_score", 0)
        recs.append(
            f"Low-hanging fruit: \"{key}\" (pos {pos:.1f}, {imp} imp, score {score:.2f}) "
            f"-- optimise title/H1 and internal links to push into top 3."
        )

    # Rising queries worth creating content for
    new_rising = [q for q in r.rising_queries if q.get("note") == "new query this period"]
    for item in new_rising[:3]:
        recs.append(
            f"New rising query: \"{item['key']}\" ({item.get('impressions', 0)} imp) "
            f"-- consider a dedicated page or FAQ section."
        )

    # Position drops
    for item in r.position_drops[:3]:
        key = item["key"]
        change = item.get("position_change", 0)
        recs.append(
            f"Position drop: \"{key}\" dropped {change:.1f} positions "
            f"-- check for content freshness, lost backlinks, or competitor moves."
        )

    # Content gaps
    if len(r.content_gaps) > 5:
        recs.append(
            f"{len(r.content_gaps)} queries have impressions but almost no clicks. "
            f"Review meta titles and descriptions for the top queries."
        )

    # Blog coverage
    if blog_slugs:
        blog_pages = [p for p in r.auto_tracked if any(s in p.get("key", "") for s in blog_slugs)]
        non_blog = [p for p in r.auto_tracked if not any(s in p.get("key", "") for s in blog_slugs)]
        if non_blog and blog_pages:
            recs.append(
                f"{len(blog_pages)} blog pages and {len(non_blog)} non-blog pages are tracked. "
                f"Ensure blog posts link to core product/service pages."
            )

    return recs


def measure_resolved_impact(
    pages_current: list[dict[str, Any]],
    storage: Any,
) -> list[dict[str, Any]]:
    """Measure the impact of recently resolved actions and backfill impact_notes.

    Looks at actions resolved in the last 30 days that have no ``impact_notes``
    yet.  For LHF-type actions, extracts the URL from the title, finds current
    GSC page data, and computes position and CTR deltas vs the snapshot stored
    in ``details_json``.

    Parameters
    ----------
    pages_current:
        Current-period aggregated page data (list of dicts with ``key``,
        ``position``, ``ctr``, ``impressions``, ``clicks``).
    storage:
        A ``Storage`` instance used to query and update actions.

    Returns a list of dicts describing the measured impact for each action.
    """
    from datetime import datetime, timedelta

    cutoff = datetime.utcnow() - timedelta(days=30)
    resolved = storage.get_actions(status="resolved", limit=200)
    pages_map = {p["key"]: p for p in pages_current}

    results: list[dict[str, Any]] = []

    for action in resolved:
        # Skip if already has impact notes or resolved before the window
        if action.impact_notes:
            continue
        if action.resolved_at and action.resolved_at < cutoff:
            continue

        # Only measure LHF actions for now
        if action.type != "low_hanging_fruit":
            continue

        details = action.details
        url = details.get("url") or details.get("key", "")
        if not url:
            # Try extracting URL from the title (format: "LHF: <url> ...")
            parts = action.title.split()
            for part in parts:
                if part.startswith("http"):
                    url = part.rstrip(")")
                    break

        if not url or url not in pages_map:
            continue

        current = pages_map[url]
        old_pos = details.get("position", 0.0)
        old_ctr = details.get("ctr", 0.0)
        new_pos = current.get("position", 0.0)
        new_ctr = current.get("ctr", 0.0)

        pos_delta = old_pos - new_pos  # positive = improved
        ctr_delta = new_ctr - old_ctr  # positive = improved

        note = (
            f"Position: {old_pos:.1f} -> {new_pos:.1f} ({pos_delta:+.1f}), "
            f"CTR: {old_ctr:.4f} -> {new_ctr:.4f} ({ctr_delta:+.4f})"
        )

        # Update the action in storage
        action.impact_notes = note
        storage.upsert_action(action)

        results.append({
            "action_id": action.id,
            "title": action.title,
            "url": url,
            "position_delta": round(pos_delta, 1),
            "ctr_delta": round(ctr_delta, 4),
            "impact_notes": note,
        })

        logger.info("Impact measured for action #%s: %s", action.id, note)

    logger.info("Measured impact for %d resolved actions", len(results))
    return results


def result_to_dict(r: AnalysisResult) -> dict[str, Any]:
    """Serialise an ``AnalysisResult`` to a plain dict (JSON-safe)."""
    return {
        "low_hanging_fruit": r.low_hanging_fruit,
        "content_gaps": r.content_gaps,
        "rising_queries": r.rising_queries,
        "position_drops": r.position_drops,
        "auto_tracked": r.auto_tracked,
        "recommendations": r.recommendations,
    }
