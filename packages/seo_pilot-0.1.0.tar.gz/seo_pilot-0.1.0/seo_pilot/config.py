"""Configuration loader for seo-pilot.

Reads config.yaml (or a custom path) and resolves env-var references
for secrets (fields ending with ``_env`` are looked up in ``os.environ``).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class SiteConfig:
    domain: str = ""
    gsc_property: str = ""
    sitemap: str = ""


@dataclass
class AuthConfig:
    gsc_credentials: str = "./credentials.json"


@dataclass
class StorageConfig:
    type: str = "sqlite"
    path: str = "./seo-pilot.db"
    url: str = ""


@dataclass
class NotificationConfig:
    type: str = "telegram"
    token: str = ""
    token_env: str = ""
    chat_id: str = ""
    webhook_url: str = ""
    webhook_env: str = ""
    url: str = ""

    def resolve(self) -> None:
        """Populate secret fields from environment variables."""
        if self.token_env and not self.token:
            self.token = os.environ.get(self.token_env, "")
        if self.webhook_env and not self.webhook_url:
            self.webhook_url = os.environ.get(self.webhook_env, "")


@dataclass
class LLMConfig:
    provider: str = "gemini"
    model: str = "gemini-2.0-flash"
    api_key: str = ""
    api_key_env: str = ""
    base_url: str = ""

    def resolve(self) -> None:
        if self.api_key_env and not self.api_key:
            self.api_key = os.environ.get(self.api_key_env, "")


@dataclass
class ScheduleConfig:
    weekly_review: str = "monday 05:30"
    monthly_review: str = "first_monday"


@dataclass
class ContentConfig:
    blog_url_pattern: str = "/blog/"
    manual_urls: list[str] = field(default_factory=list)


@dataclass
class GuidelinesConfig:
    path: str = "./guidelines/default.md"


@dataclass
class BaselineConfig:
    weekly_impressions: int | None = None
    weekly_clicks: int | None = None
    avg_position: float | None = None


@dataclass
class Config:
    site: SiteConfig = field(default_factory=SiteConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    notifications: list[NotificationConfig] = field(default_factory=list)
    llm: LLMConfig = field(default_factory=LLMConfig)
    schedule: ScheduleConfig = field(default_factory=ScheduleConfig)
    content: ContentConfig = field(default_factory=ContentConfig)
    guidelines: GuidelinesConfig = field(default_factory=GuidelinesConfig)
    baseline: BaselineConfig = field(default_factory=BaselineConfig)

    # Absolute path to the config file (set after loading)
    _config_dir: Path = field(default_factory=lambda: Path("."), repr=False)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def resolve_path(self, relative: str) -> Path:
        """Resolve a path relative to the config file location."""
        p = Path(relative)
        if p.is_absolute():
            return p
        return (self._config_dir / p).resolve()

    @property
    def gsc_credentials_path(self) -> Path:
        return self.resolve_path(self.auth.gsc_credentials)

    @property
    def db_path(self) -> Path:
        if self.storage.type == "sqlite":
            return self.resolve_path(self.storage.path)
        raise ValueError("db_path only applies to sqlite storage")

    @property
    def guidelines_path(self) -> Path:
        return self.resolve_path(self.guidelines.path)


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


def _build_dataclass(cls: type, data: dict[str, Any] | None):
    """Instantiate a dataclass from a dict, ignoring unknown keys."""
    if not data:
        return cls()
    known = {f.name for f in cls.__dataclass_fields__.values()}
    return cls(**{k: v for k, v in data.items() if k in known})


def load_config(path: str | Path = "config.yaml") -> Config:
    """Load and return a fully-resolved ``Config`` from *path*.

    Environment variable references (``token_env``, ``api_key_env``, etc.)
    are resolved at load time.  Missing env vars result in empty strings
    rather than exceptions so that read-only / partial configs still work.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as fh:
        raw: dict[str, Any] = yaml.safe_load(fh) or {}

    cfg = Config()
    cfg._config_dir = path.resolve().parent

    cfg.site = _build_dataclass(SiteConfig, raw.get("site"))
    cfg.auth = _build_dataclass(AuthConfig, raw.get("auth"))
    cfg.storage = _build_dataclass(StorageConfig, raw.get("storage"))
    cfg.llm = _build_dataclass(LLMConfig, raw.get("llm"))
    cfg.schedule = _build_dataclass(ScheduleConfig, raw.get("schedule"))
    cfg.content = _build_dataclass(ContentConfig, raw.get("content"))
    cfg.guidelines = _build_dataclass(GuidelinesConfig, raw.get("guidelines"))
    cfg.baseline = _build_dataclass(BaselineConfig, raw.get("baseline"))

    # Notifications (list of dicts)
    for entry in raw.get("notifications") or []:
        n = _build_dataclass(NotificationConfig, entry)
        n.resolve()
        cfg.notifications.append(n)

    cfg.llm.resolve()

    return cfg
