"""Auto-changelog generator.

Compares the current review snapshot against the previous one and appends
a Markdown entry describing significant changes in position, CTR, and
impressions for tracked queries and pages.
"""

from __future__ import annotations

import logging
from datetime import date, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Thresholds for what counts as "significant"
_POSITION_CHANGE_THRESHOLD = 2.0  # positions
_CTR_CHANGE_THRESHOLD = 0.02  # absolute (2 pp)
_IMPRESSIONS_CHANGE_THRESHOLD = 0.25  # 25 % relative


def update_changelog(
    current_data: dict[str, Any],
    previous_data: dict[str, Any] | None,
    changelog_path: str | Path = "CHANGELOG.md",
) -> str:
    """Compare current vs previous review data and append to the changelog.

    Parameters
    ----------
    current_data:
        The serialised ``AnalysisResult`` dict for the current period.
    previous_data:
        Same structure for the previous period, or ``None`` for the first run.
    changelog_path:
        Path to the Markdown changelog file.

    Returns
    -------
    The Markdown text that was appended (empty string if nothing significant).
    """
    changelog_path = Path(changelog_path)
    entries: list[str] = []
    today = date.today().isoformat()
    header = f"## {today}"

    if previous_data is None:
        # First snapshot -- write a baseline entry
        summary = _baseline_summary(current_data)
        if summary:
            entries.append(summary)
    else:
        entries.extend(_diff_section("Low-hanging fruit", current_data.get("low_hanging_fruit", []), previous_data.get("low_hanging_fruit", [])))
        entries.extend(_diff_tracked_pages(current_data.get("auto_tracked", []), previous_data.get("auto_tracked", [])))
        entries.extend(_diff_rising(current_data.get("rising_queries", []), previous_data.get("rising_queries", [])))
        entries.extend(_diff_drops(current_data.get("position_drops", [])))
        entries.extend(_diff_recommendations(current_data.get("recommendations", [])))

    if not entries:
        logger.info("No significant changes for changelog")
        return ""

    block = f"{header}\n\n" + "\n".join(entries) + "\n\n---\n\n"

    # Prepend to existing file (newest first) or create new
    existing = ""
    if changelog_path.exists():
        existing = changelog_path.read_text()

    # If file starts with a title, insert after it
    if existing.startswith("# "):
        first_nl = existing.index("\n") if "\n" in existing else len(existing)
        title_line = existing[: first_nl + 1]
        rest = existing[first_nl + 1 :]
        changelog_path.write_text(title_line + "\n" + block + rest)
    else:
        changelog_path.write_text(f"# SEO Pilot Changelog\n\n{block}{existing}")

    logger.info("Appended %d changelog entries for %s", len(entries), today)
    return block


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _baseline_summary(data: dict[str, Any]) -> str:
    """Generate a first-run baseline entry."""
    lhf = data.get("low_hanging_fruit", [])
    tracked = data.get("auto_tracked", [])
    gaps = data.get("content_gaps", [])
    lines = ["**Baseline snapshot recorded.**\n"]
    if tracked:
        total_imp = sum(p.get("impressions", 0) for p in tracked)
        total_clicks = sum(p.get("clicks", 0) for p in tracked)
        lines.append(f"- Tracked pages: {len(tracked)} (total {total_imp:,} imp, {total_clicks:,} clicks)")
    if lhf:
        lines.append(f"- Low-hanging fruit queries: {len(lhf)}")
    if gaps:
        lines.append(f"- Content gap queries: {len(gaps)}")
    return "\n".join(lines)


def _diff_section(label: str, current: list[dict], previous: list[dict]) -> list[str]:
    """Compare two lists by key and note entries that appeared or disappeared."""
    entries: list[str] = []
    curr_keys = {item.get("key", "") for item in current}
    prev_keys = {item.get("key", "") for item in previous}

    new_keys = curr_keys - prev_keys
    gone_keys = prev_keys - curr_keys

    if new_keys:
        sample = sorted(new_keys)[:5]
        entries.append(f"**{label} -- new entries:** {', '.join(f'`{k}`' for k in sample)}" + (f" (+{len(new_keys) - 5} more)" if len(new_keys) > 5 else ""))

    if gone_keys:
        sample = sorted(gone_keys)[:5]
        entries.append(f"**{label} -- resolved:** {', '.join(f'`{k}`' for k in sample)}" + (f" (+{len(gone_keys) - 5} more)" if len(gone_keys) > 5 else ""))

    return entries


def _diff_tracked_pages(current: list[dict], previous: list[dict]) -> list[str]:
    """Flag tracked pages with significant position or impression changes."""
    entries: list[str] = []
    prev_map = {p.get("key", ""): p for p in previous}

    improvements: list[str] = []
    declines: list[str] = []

    for page in current:
        key = page.get("key", "")
        prev = prev_map.get(key)
        if not prev:
            continue

        pos_now = page.get("position", 0)
        pos_prev = prev.get("position", 0)
        pos_diff = pos_now - pos_prev  # negative = improvement

        imp_now = page.get("impressions", 0)
        imp_prev = prev.get("impressions", 0)
        imp_pct = (imp_now - imp_prev) / imp_prev if imp_prev else None

        if pos_diff <= -_POSITION_CHANGE_THRESHOLD:
            improvements.append(f"`{key}`: position {pos_prev:.1f} -> {pos_now:.1f} ({pos_diff:+.1f})")
        elif pos_diff >= _POSITION_CHANGE_THRESHOLD:
            declines.append(f"`{key}`: position {pos_prev:.1f} -> {pos_now:.1f} ({pos_diff:+.1f})")

    if improvements:
        entries.append("**Position improvements:**")
        for line in improvements[:10]:
            entries.append(f"- {line}")

    if declines:
        entries.append("**Position declines:**")
        for line in declines[:10]:
            entries.append(f"- {line}")

    return entries


def _diff_rising(current: list[dict], previous: list[dict]) -> list[str]:
    """Highlight new rising queries."""
    prev_keys = {q.get("key", "") for q in previous}
    new_rising = [q for q in current if q.get("key", "") not in prev_keys]

    if not new_rising:
        return []

    entries = ["**Newly rising queries:**"]
    for q in new_rising[:8]:
        growth = q.get("growth_pct")
        note = q.get("note", "")
        desc = f"{growth:.0f}% growth" if growth is not None else note
        entries.append(f"- `{q.get('key', '')}` ({q.get('impressions', 0)} imp, {desc})")
    return entries


def _diff_drops(drops: list[dict]) -> list[str]:
    """List current position drops."""
    if not drops:
        return []
    entries = ["**Position drops this period:**"]
    for d in drops[:8]:
        entries.append(
            f"- `{d.get('key', '')}`: dropped {d.get('position_change', 0):.1f} positions "
            f"(now {d.get('position', 0):.1f}, {d.get('impressions', 0)} imp)"
        )
    return entries


def _diff_recommendations(recs: list[str]) -> list[str]:
    """Include top recommendations."""
    if not recs:
        return []
    entries = ["**Recommendations:**"]
    for rec in recs[:5]:
        entries.append(f"- {rec}")
    return entries
