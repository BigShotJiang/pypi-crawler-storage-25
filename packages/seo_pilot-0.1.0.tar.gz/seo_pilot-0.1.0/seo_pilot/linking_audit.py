"""Internal linking auditor.

Crawls a site (from sitemap or by following links) and produces a map
of internal links, orphan pages, and broken links.  Output is a
Markdown file (``linking-map.md``) plus structured data.
"""

from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 15.0
_DEFAULT_HEADERS = {
    "User-Agent": "seo-pilot/0.1 (internal-linking-audit)",
}


@dataclass
class LinkAuditResult:
    """Container for crawl results."""

    pages_crawled: int = 0
    outbound_links: dict[str, list[str]] = field(default_factory=lambda: defaultdict(list))
    inbound_links: dict[str, list[str]] = field(default_factory=lambda: defaultdict(list))
    orphan_pages: list[str] = field(default_factory=list)
    broken_links: list[dict[str, str]] = field(default_factory=list)  # {"source": ..., "target": ..., "status": ...}
    external_links: dict[str, list[str]] = field(default_factory=lambda: defaultdict(list))


def audit_site(
    domain: str,
    sitemap_url: str | None = None,
    max_pages: int = 500,
    timeout: float = _DEFAULT_TIMEOUT,
) -> LinkAuditResult:
    """Crawl *domain* and build an internal link map.

    Parameters
    ----------
    domain:
        The domain to audit (e.g. ``example.com``).  The scheme ``https://``
        is prepended if missing.
    sitemap_url:
        Optional sitemap URL.  If not provided, ``/sitemap.xml`` is tried,
        then ``robots.txt`` is checked.
    max_pages:
        Maximum number of pages to crawl.
    timeout:
        HTTP request timeout in seconds.
    """
    if not domain.startswith(("http://", "https://")):
        domain = f"https://{domain}"

    base = urlparse(domain)
    base_netloc = base.netloc

    result = LinkAuditResult()

    # Discover seed URLs
    seed_urls = _discover_urls(domain, sitemap_url, timeout)
    if not seed_urls:
        seed_urls = {domain.rstrip("/") + "/"}

    logger.info("Starting link audit for %s with %d seed URLs (max %d pages)", base_netloc, len(seed_urls), max_pages)

    visited: set[str] = set()
    queue: list[str] = list(seed_urls)
    known_urls: set[str] = set(seed_urls)  # all URLs we know about (from sitemap)

    client = httpx.Client(timeout=timeout, headers=_DEFAULT_HEADERS, follow_redirects=True)

    try:
        while queue and len(visited) < max_pages:
            url = queue.pop(0)
            if url in visited:
                continue

            norm = _normalise(url)
            if norm in visited:
                continue

            page_links = _crawl_page(client, url, base_netloc, result)
            visited.add(norm)
            result.pages_crawled += 1

            if result.pages_crawled % 50 == 0:
                logger.info("Crawled %d / %d pages ...", result.pages_crawled, max_pages)

            # Enqueue newly discovered internal links
            for link in page_links:
                nlink = _normalise(link)
                if nlink not in visited and nlink not in {_normalise(u) for u in queue}:
                    if _is_same_domain(link, base_netloc):
                        queue.append(link)
                        known_urls.add(link)
    finally:
        client.close()

    # Identify orphan pages (in sitemap / known but never linked to)
    linked_to = set(result.inbound_links.keys())
    for url in known_urls:
        norm = _normalise(url)
        if norm not in linked_to and norm in visited:
            result.orphan_pages.append(url)

    result.orphan_pages.sort()

    logger.info(
        "Audit complete: %d pages crawled, %d orphans, %d broken links",
        result.pages_crawled,
        len(result.orphan_pages),
        len(result.broken_links),
    )
    return result


def write_linking_map(result: LinkAuditResult, output_path: str | Path = "linking-map.md") -> Path:
    """Write the audit result as a Markdown file.

    Returns the path to the written file.
    """
    output_path = Path(output_path)
    lines: list[str] = []

    lines.append("# Internal linking map")
    lines.append("")
    lines.append(f"Pages crawled: {result.pages_crawled}")
    lines.append(f"Orphan pages: {len(result.orphan_pages)}")
    lines.append(f"Broken links: {len(result.broken_links)}")
    lines.append("")

    # Orphans
    if result.orphan_pages:
        lines.append("## Orphan pages")
        lines.append("")
        lines.append("Pages with no internal links pointing to them:")
        lines.append("")
        for url in result.orphan_pages:
            lines.append(f"- {url}")
        lines.append("")

    # Broken links
    if result.broken_links:
        lines.append("## Broken links")
        lines.append("")
        lines.append("| Source | Target | Status |")
        lines.append("|--------|--------|--------|")
        for bl in result.broken_links:
            lines.append(f"| {bl['source']} | {bl['target']} | {bl['status']} |")
        lines.append("")

    # Pages sorted by inbound link count (ascending = least linked first)
    lines.append("## Pages by inbound links")
    lines.append("")
    inbound_counts = [(url, len(sources)) for url, sources in result.inbound_links.items()]
    inbound_counts.sort(key=lambda x: x[1])

    lines.append("| Page | Inbound links | Outbound links |")
    lines.append("|------|---------------|----------------|")
    for url, in_count in inbound_counts:
        out_count = len(result.outbound_links.get(url, []))
        lines.append(f"| {url} | {in_count} | {out_count} |")
    lines.append("")

    # Top linked pages
    top = sorted(inbound_counts, key=lambda x: x[1], reverse=True)[:20]
    if top:
        lines.append("## Most linked pages (top 20)")
        lines.append("")
        for url, count in top:
            lines.append(f"- {url} ({count} inbound)")
        lines.append("")

    content = "\n".join(lines)
    output_path.write_text(content)
    logger.info("Linking map written to %s", output_path)
    return output_path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _discover_urls(domain: str, sitemap_url: str | None, timeout: float) -> set[str]:
    """Try to get seed URLs from a sitemap."""
    urls: set[str] = set()

    sitemap_candidates = []
    if sitemap_url:
        sitemap_candidates.append(sitemap_url)
    else:
        sitemap_candidates.append(domain.rstrip("/") + "/sitemap.xml")

    # Try robots.txt for sitemap references
    try:
        client = httpx.Client(timeout=timeout, headers=_DEFAULT_HEADERS, follow_redirects=True)
        robots_resp = client.get(domain.rstrip("/") + "/robots.txt")
        if robots_resp.status_code == 200:
            for line in robots_resp.text.splitlines():
                if line.lower().startswith("sitemap:"):
                    candidate = line.split(":", 1)[1].strip()
                    if candidate not in sitemap_candidates:
                        sitemap_candidates.append(candidate)
        client.close()
    except httpx.HTTPError:
        pass

    for candidate in sitemap_candidates:
        found = _parse_sitemap(candidate, timeout)
        urls.update(found)
        if urls:
            break

    return urls


def _parse_sitemap(url: str, timeout: float) -> set[str]:
    """Parse a sitemap XML and return all <loc> URLs."""
    urls: set[str] = set()
    try:
        client = httpx.Client(timeout=timeout, headers=_DEFAULT_HEADERS, follow_redirects=True)
        resp = client.get(url)
        client.close()
        if resp.status_code != 200:
            return urls

        root = ET.fromstring(resp.text)
        # Handle namespace
        ns = ""
        if root.tag.startswith("{"):
            ns = root.tag.split("}")[0] + "}"

        # Check if it's a sitemap index
        for sitemap_elem in root.findall(f"{ns}sitemap"):
            loc = sitemap_elem.find(f"{ns}loc")
            if loc is not None and loc.text:
                urls.update(_parse_sitemap(loc.text.strip(), timeout))

        # Regular sitemap entries
        for url_elem in root.findall(f"{ns}url"):
            loc = url_elem.find(f"{ns}loc")
            if loc is not None and loc.text:
                urls.add(loc.text.strip())

    except (httpx.HTTPError, ET.ParseError) as exc:
        logger.debug("Could not parse sitemap %s: %s", url, exc)

    return urls


def _crawl_page(
    client: httpx.Client,
    url: str,
    base_netloc: str,
    result: LinkAuditResult,
) -> list[str]:
    """Fetch a single page and extract links. Returns internal links found."""
    internal_links: list[str] = []

    try:
        resp = client.get(url)
    except httpx.HTTPError as exc:
        result.broken_links.append({"source": "(direct)", "target": url, "status": str(exc)})
        return internal_links

    if resp.status_code >= 400:
        result.broken_links.append({"source": "(direct)", "target": url, "status": str(resp.status_code)})
        return internal_links

    content_type = resp.headers.get("content-type", "")
    if "text/html" not in content_type:
        return internal_links

    soup = BeautifulSoup(resp.text, "html.parser")

    for anchor in soup.find_all("a", href=True):
        href: str = anchor["href"].strip()

        # Skip fragment-only, mailto, tel, javascript
        if href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue

        absolute = urljoin(url, href)
        # Strip fragment
        parsed = urlparse(absolute)
        clean = parsed._replace(fragment="").geturl()

        if _is_same_domain(clean, base_netloc):
            norm_source = _normalise(url)
            norm_target = _normalise(clean)
            result.outbound_links[norm_source].append(norm_target)
            result.inbound_links[norm_target].append(norm_source)
            internal_links.append(clean)
        else:
            result.external_links[_normalise(url)].append(clean)

    return internal_links


def _is_same_domain(url: str, netloc: str) -> bool:
    parsed = urlparse(url)
    return parsed.netloc == netloc or parsed.netloc == ""


def _normalise(url: str) -> str:
    """Normalise a URL for deduplication: lowercase host, strip trailing slash and fragment."""
    parsed = urlparse(url)
    path = parsed.path.rstrip("/") or "/"
    return f"{parsed.scheme}://{parsed.netloc.lower()}{path}"
