"""SEO Pilot — Self-improving SEO agent."""

__version__ = "0.1.0"
