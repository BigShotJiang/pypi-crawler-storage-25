"""Notification system supporting multiple backends.

Sends messages to Telegram, Slack, or generic webhook endpoints.
Auto-chunks long messages for APIs with size limits.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# Telegram Bot API hard limit
_TELEGRAM_MAX_LEN = 4096
# Slack recommended limit
_SLACK_MAX_LEN = 40000

_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


@dataclass(frozen=True)
class NotifyResult:
    """Outcome of a single notification attempt."""

    channel: str
    success: bool
    detail: str = ""


def _chunk_text(text: str, max_len: int) -> list[str]:
    """Split *text* into chunks of at most *max_len* characters.

    Tries to break on newlines first, then falls back to hard splits.
    """
    if len(text) <= max_len:
        return [text]

    chunks: list[str] = []
    remaining = text
    while remaining:
        if len(remaining) <= max_len:
            chunks.append(remaining)
            break

        # Try to find a newline near the limit to split cleanly
        split_at = remaining.rfind("\n", 0, max_len)
        if split_at <= 0:
            split_at = max_len

        chunks.append(remaining[:split_at])
        remaining = remaining[split_at:].lstrip("\n")

    return chunks


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------

def _resolve_env_var(name: str) -> str:
    """Read an environment variable, raise if missing."""
    import os

    value = os.environ.get(name, "")
    if not value:
        raise ValueError(f"Environment variable '{name}' is not set")
    return value


def _send_telegram(message: str, *, token_env: str, chat_id: str, parse_mode: str = "HTML") -> list[NotifyResult]:
    """Send a message via Telegram Bot API. Auto-chunks if needed."""
    token = _resolve_env_var(token_env)
    url = f"https://api.telegram.org/bot{token}/sendMessage"

    chunks = _chunk_text(message, _TELEGRAM_MAX_LEN)
    results: list[NotifyResult] = []

    with httpx.Client(timeout=_TIMEOUT) as client:
        for i, chunk in enumerate(chunks, 1):
            payload = {
                "chat_id": chat_id,
                "text": chunk,
                "parse_mode": parse_mode,
                "disable_web_page_preview": True,
            }
            try:
                resp = client.post(url, json=payload)
                resp.raise_for_status()
                results.append(NotifyResult("telegram", True, f"chunk {i}/{len(chunks)}"))
            except httpx.HTTPError as exc:
                detail = f"chunk {i}/{len(chunks)} failed: {exc}"
                logger.error("Telegram send error: %s", detail)
                results.append(NotifyResult("telegram", False, detail))

    return results


# ---------------------------------------------------------------------------
# Slack
# ---------------------------------------------------------------------------

def _send_slack(message: str, *, webhook_env: str) -> list[NotifyResult]:
    """Send a message via Slack incoming webhook. Markdown formatting."""
    webhook_url = _resolve_env_var(webhook_env)

    chunks = _chunk_text(message, _SLACK_MAX_LEN)
    results: list[NotifyResult] = []

    with httpx.Client(timeout=_TIMEOUT) as client:
        for i, chunk in enumerate(chunks, 1):
            payload = {"text": chunk}
            try:
                resp = client.post(webhook_url, json=payload)
                resp.raise_for_status()
                results.append(NotifyResult("slack", True, f"chunk {i}/{len(chunks)}"))
            except httpx.HTTPError as exc:
                detail = f"chunk {i}/{len(chunks)} failed: {exc}"
                logger.error("Slack send error: %s", detail)
                results.append(NotifyResult("slack", False, detail))

    return results


# ---------------------------------------------------------------------------
# Generic webhook
# ---------------------------------------------------------------------------

def _send_webhook(message: str, *, url: str, extra_headers: dict[str, str] | None = None) -> list[NotifyResult]:
    """POST JSON to an arbitrary webhook endpoint."""
    headers = {"Content-Type": "application/json"}
    if extra_headers:
        headers.update(extra_headers)

    payload = {"text": message, "source": "seo-pilot"}

    with httpx.Client(timeout=_TIMEOUT) as client:
        try:
            resp = client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            return [NotifyResult("webhook", True, url)]
        except httpx.HTTPError as exc:
            detail = f"webhook {url} failed: {exc}"
            logger.error("Webhook send error: %s", detail)
            return [NotifyResult("webhook", False, detail)]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_SENDERS: dict[str, Any] = {
    "telegram": _send_telegram,
    "slack": _send_slack,
    "webhook": _send_webhook,
}


def notify(message: str, config: dict[str, Any]) -> list[NotifyResult]:
    """Send *message* to every notification channel defined in *config*.

    *config* should be the full parsed config dict (or at least the
    ``notifications`` section). Each entry needs a ``type`` key plus
    backend-specific fields.

    Returns a list of :class:`NotifyResult` objects (one per chunk per channel).
    Never raises on delivery failure — check the results instead.
    """
    channels: list[dict[str, Any]] = config.get("notifications", [])
    if not channels:
        logger.warning("No notification channels configured")
        return []

    all_results: list[NotifyResult] = []

    for ch in channels:
        ch_type = ch.get("type", "").lower()

        try:
            if ch_type == "telegram":
                results = _send_telegram(
                    message,
                    token_env=ch["token_env"],
                    chat_id=str(ch["chat_id"]),
                    parse_mode=ch.get("parse_mode", "HTML"),
                )
            elif ch_type == "slack":
                results = _send_slack(
                    message,
                    webhook_env=ch["webhook_env"],
                )
            elif ch_type == "webhook":
                results = _send_webhook(
                    message,
                    url=ch["url"],
                    extra_headers=ch.get("headers"),
                )
            else:
                logger.warning("Unknown notification type: %s", ch_type)
                results = [NotifyResult(ch_type, False, "unknown channel type")]
        except (KeyError, ValueError) as exc:
            logger.error("Notification config error (%s): %s", ch_type, exc)
            results = [NotifyResult(ch_type, False, str(exc))]

        all_results.extend(results)

    return all_results
