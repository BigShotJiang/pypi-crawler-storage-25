"""LLM-agnostic interface for SEO title and meta suggestions.

Supports Claude (Anthropic), OpenAI, Gemini, and Ollama as providers.
Returns empty results on failure instead of crashing.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_TIMEOUT = httpx.Timeout(60.0, connect=10.0)

SYSTEM_PROMPT = (
    "You are an SEO specialist. Suggest 2 title tag options (max 60 chars) "
    "for each page that would improve CTR. Include primary keyword naturally. "
    "Return valid JSON: a list of objects with keys \"url\", \"current_title\", "
    "\"suggestions\" (list of strings). Nothing else."
)


@dataclass
class TitleSuggestion:
    """Title suggestions for a single page."""

    url: str
    current_title: str
    suggestions: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------

def _build_user_prompt(pages: list[dict[str, str]], queries: list[dict[str, Any]] | None = None) -> str:
    """Build the user prompt from page and query data."""
    lines = ["Analyze these pages and suggest improved title tags:\n"]

    for p in pages:
        lines.append(f"URL: {p.get('url', '')}")
        lines.append(f"Current title: {p.get('title', '(none)')}")
        if p.get("description"):
            lines.append(f"Meta description: {p['description']}")
        lines.append("")

    if queries:
        lines.append("Top search queries driving traffic to these pages:")
        for q in queries[:30]:  # cap to keep prompt reasonable
            lines.append(
                f"  - \"{q.get('query', '')}\" "
                f"(clicks: {q.get('clicks', 0)}, "
                f"impressions: {q.get('impressions', 0)}, "
                f"position: {q.get('position', '-')})"
            )

    return "\n".join(lines)


def _parse_suggestions(raw: str) -> list[TitleSuggestion]:
    """Extract JSON from the LLM response text."""
    # Try to find JSON array in the response
    text = raw.strip()

    # Strip markdown code fences if present
    if text.startswith("```"):
        first_newline = text.find("\n")
        last_fence = text.rfind("```")
        if last_fence > first_newline:
            text = text[first_newline + 1 : last_fence].strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # Try to find array brackets
        start = text.find("[")
        end = text.rfind("]")
        if start >= 0 and end > start:
            try:
                data = json.loads(text[start : end + 1])
            except json.JSONDecodeError:
                logger.warning("Could not parse LLM response as JSON")
                return []
        else:
            logger.warning("No JSON array found in LLM response")
            return []

    results: list[TitleSuggestion] = []
    for item in data:
        if isinstance(item, dict):
            results.append(
                TitleSuggestion(
                    url=item.get("url", ""),
                    current_title=item.get("current_title", ""),
                    suggestions=item.get("suggestions", []),
                )
            )
    return results


def _call_claude(
    user_prompt: str,
    *,
    api_key: str,
    model: str,
) -> str:
    """Call Anthropic Messages API."""
    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": model,
        "max_tokens": 4096,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_prompt}],
    }

    with httpx.Client(timeout=_TIMEOUT) as client:
        resp = client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        # Anthropic returns content as a list of blocks
        blocks = data.get("content", [])
        return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")


def _call_openai(
    user_prompt: str,
    *,
    api_key: str,
    model: str,
    base_url: str = "https://api.openai.com/v1",
) -> str:
    """Call OpenAI Chat Completions API (or compatible endpoint)."""
    url = f"{base_url.rstrip('/')}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.4,
        "max_tokens": 4096,
    }

    with httpx.Client(timeout=_TIMEOUT) as client:
        resp = client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]


def _call_gemini(
    user_prompt: str,
    *,
    api_key: str,
    model: str,
) -> str:
    """Call Google Gemini (Generative Language) API."""
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}"
        f":generateContent?key={api_key}"
    )
    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": [{"parts": [{"text": user_prompt}]}],
        "generationConfig": {"temperature": 0.4, "maxOutputTokens": 4096},
    }

    with httpx.Client(timeout=_TIMEOUT) as client:
        resp = client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
        candidates = data.get("candidates", [])
        if not candidates:
            return ""
        parts = candidates[0].get("content", {}).get("parts", [])
        return "".join(p.get("text", "") for p in parts)


def _call_ollama(
    user_prompt: str,
    *,
    model: str,
    base_url: str = "http://localhost:11434",
) -> str:
    """Call Ollama local API."""
    url = f"{base_url.rstrip('/')}/api/chat"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "stream": False,
        "options": {"temperature": 0.4},
    }

    with httpx.Client(timeout=httpx.Timeout(120.0, connect=10.0)) as client:
        resp = client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("content", "")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def suggest_titles(
    pages: list[dict[str, str]],
    queries: list[dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
) -> list[TitleSuggestion]:
    """Generate title tag suggestions for the given pages.

    Parameters
    ----------
    pages:
        List of dicts with at least ``url`` and ``title`` keys.
    queries:
        Optional list of GSC query dicts (``query``, ``clicks``, ``impressions``, ``position``).
    config:
        Full config dict. The ``llm`` section is used to pick the provider.

    Returns an empty list if the LLM call fails or no LLM is configured.
    """
    if not pages:
        return []

    llm_cfg = (config or {}).get("llm", {})
    provider = llm_cfg.get("provider", "").lower()
    model = llm_cfg.get("model", "")

    if not provider:
        logger.info("No LLM provider configured, skipping title suggestions")
        return []

    # Resolve API key from env
    api_key_env = llm_cfg.get("api_key_env", "")
    api_key = os.environ.get(api_key_env, "") if api_key_env else ""

    user_prompt = _build_user_prompt(pages, queries)

    try:
        if provider == "claude":
            if not api_key:
                raise ValueError(f"Missing env var: {api_key_env}")
            raw = _call_claude(user_prompt, api_key=api_key, model=model or "claude-sonnet-4-20250514")

        elif provider == "openai":
            if not api_key:
                raise ValueError(f"Missing env var: {api_key_env}")
            base_url = llm_cfg.get("base_url", "https://api.openai.com/v1")
            raw = _call_openai(user_prompt, api_key=api_key, model=model or "gpt-4o-mini", base_url=base_url)

        elif provider == "gemini":
            if not api_key:
                raise ValueError(f"Missing env var: {api_key_env}")
            raw = _call_gemini(user_prompt, api_key=api_key, model=model or "gemini-2.0-flash")

        elif provider == "ollama":
            base_url = llm_cfg.get("base_url", "http://localhost:11434")
            raw = _call_ollama(user_prompt, model=model or "llama3", base_url=base_url)

        else:
            logger.warning("Unknown LLM provider: %s", provider)
            return []

    except Exception as exc:
        logger.error("LLM call failed (%s): %s", provider, exc)
        return []

    return _parse_suggestions(raw)
