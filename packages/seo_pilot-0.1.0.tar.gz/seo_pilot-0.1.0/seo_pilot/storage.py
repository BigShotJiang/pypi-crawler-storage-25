"""SQLite-backed storage layer using SQLModel.

Tables
------
- ``GSCDailyData``  -- raw daily GSC rows (query or page dimension).
- ``SEOAction``     -- tracked SEO actions / tasks with priority and status.
- ``ReviewSnapshot`` -- point-in-time snapshots of periodic review data.
"""

from __future__ import annotations

import json
import logging
from datetime import date, datetime
from pathlib import Path
from typing import Any, Optional

from sqlmodel import Field, Session, SQLModel, create_engine, select

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class GSCDailyData(SQLModel, table=True):
    __tablename__ = "gsc_daily_data"

    id: int | None = Field(default=None, primary_key=True)
    date: date = Field(index=True)
    dimension_type: str = Field(index=True)  # "query" | "page"
    key: str = Field(index=True)  # the query string or page URL
    impressions: int = 0
    clicks: int = 0
    ctr: float = 0.0
    position: float = 0.0


class SEOAction(SQLModel, table=True):
    __tablename__ = "seo_actions"

    id: int | None = Field(default=None, primary_key=True)
    type: str = ""  # e.g. "low_hanging_fruit", "position_drop", "content_gap"
    source: str = ""  # e.g. "analyzer", "manual"
    priority: int = 0  # higher = more urgent
    status: str = "open"  # open | in_progress | resolved | dismissed
    title: str = ""
    details_json: str = "{}"  # JSON blob for arbitrary metadata
    created_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    impact_notes: str = ""

    # ----- helpers for the JSON field -----

    @property
    def details(self) -> dict[str, Any]:
        return json.loads(self.details_json)

    @details.setter
    def details(self, value: dict[str, Any]) -> None:
        self.details_json = json.dumps(value, default=str)


class ReviewSnapshot(SQLModel, table=True):
    __tablename__ = "review_snapshots"

    id: int | None = Field(default=None, primary_key=True)
    period_start: date
    period_end: date
    data_json: str = "{}"  # JSON blob
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @property
    def data(self) -> dict[str, Any]:
        return json.loads(self.data_json)

    @data.setter
    def data(self, value: dict[str, Any]) -> None:
        self.data_json = json.dumps(value, default=str)


# ---------------------------------------------------------------------------
# Storage class
# ---------------------------------------------------------------------------


class Storage:
    """Manages all DB operations via SQLModel / SQLite."""

    def __init__(self, db_path: str | Path = "seo-pilot.db") -> None:
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._engine = create_engine(f"sqlite:///{db_path}", echo=False)
        SQLModel.metadata.create_all(self._engine)
        logger.info("Storage initialised at %s", db_path)

    # ------------------------------------------------------------------
    # GSC daily data
    # ------------------------------------------------------------------

    def save_daily_data(self, rows: list[GSCDailyData]) -> int:
        """Bulk-insert daily GSC rows. Returns number of rows saved."""
        if not rows:
            return 0
        with Session(self._engine) as session:
            for row in rows:
                session.add(row)
            session.commit()
        logger.info("Saved %d GSC daily rows", len(rows))
        return len(rows)

    def get_daily_data(
        self,
        start_date: date,
        end_date: date,
        dimension_type: str = "query",
    ) -> list[GSCDailyData]:
        """Retrieve daily rows for a date range and dimension type."""
        with Session(self._engine) as session:
            stmt = (
                select(GSCDailyData)
                .where(GSCDailyData.dimension_type == dimension_type)
                .where(GSCDailyData.date >= start_date)
                .where(GSCDailyData.date <= end_date)
                .order_by(GSCDailyData.date, GSCDailyData.key)
            )
            return list(session.exec(stmt).all())

    def get_aggregated_data(
        self,
        start_date: date,
        end_date: date,
        dimension_type: str = "query",
    ) -> list[dict[str, Any]]:
        """Return rows aggregated by key across the date range.

        Each returned dict: ``key``, ``impressions``, ``clicks``, ``ctr``,
        ``position`` (weighted average by impressions).
        """
        raw = self.get_daily_data(start_date, end_date, dimension_type)
        agg: dict[str, dict[str, float]] = {}
        for r in raw:
            bucket = agg.setdefault(r.key, {"impressions": 0, "clicks": 0, "pos_sum": 0.0})
            bucket["impressions"] += r.impressions
            bucket["clicks"] += r.clicks
            bucket["pos_sum"] += r.position * r.impressions

        result: list[dict[str, Any]] = []
        for key, v in agg.items():
            imp = v["impressions"]
            clicks = v["clicks"]
            result.append({
                "key": key,
                "impressions": imp,
                "clicks": clicks,
                "ctr": clicks / imp if imp else 0.0,
                "position": v["pos_sum"] / imp if imp else 0.0,
            })
        return sorted(result, key=lambda x: x["impressions"], reverse=True)

    # ------------------------------------------------------------------
    # SEO actions
    # ------------------------------------------------------------------

    def upsert_action(self, action: SEOAction) -> SEOAction:
        """Insert or update an action. Returns the persisted instance."""
        with Session(self._engine) as session:
            if action.id is not None:
                existing = session.get(SEOAction, action.id)
                if existing:
                    for field_name in ("type", "source", "priority", "status", "title", "details_json", "resolved_at", "impact_notes"):
                        setattr(existing, field_name, getattr(action, field_name))
                    session.add(existing)
                    session.commit()
                    session.refresh(existing)
                    return existing
            session.add(action)
            session.commit()
            session.refresh(action)
            return action

    def get_open_actions(self, action_type: str | None = None) -> list[SEOAction]:
        """Return all open / in_progress actions, optionally filtered by type."""
        with Session(self._engine) as session:
            stmt = select(SEOAction).where(SEOAction.status.in_(["open", "in_progress"]))
            if action_type:
                stmt = stmt.where(SEOAction.type == action_type)
            stmt = stmt.order_by(SEOAction.priority.desc(), SEOAction.created_at)
            return list(session.exec(stmt).all())

    def get_actions(self, status: str | None = None, limit: int = 100) -> list[SEOAction]:
        """Return actions with optional status filter."""
        with Session(self._engine) as session:
            stmt = select(SEOAction).order_by(SEOAction.created_at.desc()).limit(limit)
            if status:
                stmt = stmt.where(SEOAction.status == status)
            return list(session.exec(stmt).all())

    # ------------------------------------------------------------------
    # Review snapshots
    # ------------------------------------------------------------------

    def save_snapshot(self, snapshot: ReviewSnapshot) -> ReviewSnapshot:
        with Session(self._engine) as session:
            session.add(snapshot)
            session.commit()
            session.refresh(snapshot)
        logger.info("Saved review snapshot for %s - %s", snapshot.period_start, snapshot.period_end)
        return snapshot

    def get_latest_snapshot(self) -> ReviewSnapshot | None:
        with Session(self._engine) as session:
            stmt = select(ReviewSnapshot).order_by(ReviewSnapshot.created_at.desc()).limit(1)
            return session.exec(stmt).first()

    def get_snapshot_by_period(self, period_start: date, period_end: date) -> ReviewSnapshot | None:
        with Session(self._engine) as session:
            stmt = (
                select(ReviewSnapshot)
                .where(ReviewSnapshot.period_start == period_start)
                .where(ReviewSnapshot.period_end == period_end)
            )
            return session.exec(stmt).first()
