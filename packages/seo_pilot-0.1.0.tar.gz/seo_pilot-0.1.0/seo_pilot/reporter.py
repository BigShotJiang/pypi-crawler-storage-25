"""Report generator using Jinja2 templates.

Produces weekly and monthly SEO reports in HTML (for Telegram)
or plain text format.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

logger = logging.getLogger(__name__)

# Default template directory (relative to package root)
_DEFAULT_TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"


def _get_template_dir(config: dict[str, Any] | None = None) -> Path:
    """Resolve the template directory from config or use the default."""
    if config and config.get("templates", {}).get("path"):
        custom = Path(config["templates"]["path"])
        if custom.is_dir():
            return custom
        logger.warning("Custom template dir %s not found, using default", custom)
    return _DEFAULT_TEMPLATE_DIR


def _create_env(template_dir: Path) -> Environment:
    """Create a Jinja2 environment with common filters."""
    env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(["html", "j2"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )

    # Custom filters
    env.filters["pct"] = _fmt_pct
    env.filters["num"] = _fmt_num
    env.filters["pos"] = _fmt_pos
    env.filters["delta"] = _fmt_delta

    return env


# ---------------------------------------------------------------------------
# Formatting filters
# ---------------------------------------------------------------------------

def _fmt_pct(value: float | int | None) -> str:
    """Format a percentage value, e.g. 12.3 -> '+12.3%', -5.0 -> '-5.0%'."""
    if value is None:
        return "n/a"
    sign = "+" if value > 0 else ""
    return f"{sign}{value:.1f}%"


def _fmt_num(value: float | int | None) -> str:
    """Format a number with thousand separators."""
    if value is None:
        return "n/a"
    if isinstance(value, float):
        return f"{value:,.1f}"
    return f"{value:,}"


def _fmt_pos(value: float | None) -> str:
    """Format a search position (lower is better)."""
    if value is None:
        return "n/a"
    return f"{value:.1f}"


def _fmt_delta(value: float | int | None) -> str:
    """Format a delta with arrow indicator."""
    if value is None:
        return ""
    if value > 0:
        return f"↑ {abs(value):.1f}"
    elif value < 0:
        return f"↓ {abs(value):.1f}"
    return "→ 0"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_weekly_report(
    analysis_data: dict[str, Any],
    config: dict[str, Any] | None = None,
    *,
    output_format: str = "html",
) -> str:
    """Render the weekly SEO report.

    Parameters
    ----------
    analysis_data:
        Dict containing analysis results. Expected top-level keys:

        - ``site_totals``: dict with ``impressions``, ``clicks``,
          ``impressions_change_pct``, ``clicks_change_pct``,
          ``avg_position``, ``position_change``
        - ``low_hanging_fruit``: list of dicts (``url``, ``query``,
          ``score``, ``urgency``, ``position``, ``impressions``)
        - ``content_gaps``: list of dicts (``query``, ``impressions``,
          ``position``, ``suggested_url``)
        - ``rising_queries``: list of dicts (``query``, ``clicks``,
          ``impressions``, ``position_change``)
        - ``position_drops``: list of dicts (``url``, ``query``,
          ``old_position``, ``new_position``, ``change``)
        - ``auto_tracked_pages``: list of dicts (``url``, ``impressions``,
          ``clicks``, ``position``)
        - ``recommendations``: list of strings
        - ``open_actions_count``: int
        - ``period``: dict with ``start``, ``end``

    config:
        Full config dict. Used to locate templates.
    output_format:
        ``"html"`` (default, for Telegram) or ``"text"`` for plain text.

    Returns the rendered report string.
    """
    template_dir = _get_template_dir(config)
    env = _create_env(template_dir)

    template_name = "weekly_report.j2"
    try:
        template = env.get_template(template_name)
    except Exception as exc:
        logger.error("Failed to load template %s: %s", template_name, exc)
        return _fallback_weekly(analysis_data)

    rendered = template.render(
        data=analysis_data,
        format=output_format,
    )

    if output_format == "text":
        # Strip HTML tags for plain text
        rendered = _strip_html(rendered)

    return rendered


def generate_monthly_report(
    analysis_data: dict[str, Any],
    monthly_breakdown: list[dict[str, Any]],
    config: dict[str, Any] | None = None,
    *,
    output_format: str = "html",
) -> str:
    """Render the monthly SEO report with trend data.

    Parameters
    ----------
    analysis_data:
        Same structure as weekly, with additional month-level aggregation.
    monthly_breakdown:
        List of dicts, one per month, each containing:

        - ``month``: str (e.g. "2025-03")
        - ``impressions``, ``clicks``, ``avg_position``
        - ``impressions_change_pct``, ``clicks_change_pct``

    config:
        Full config dict.
    output_format:
        ``"html"`` or ``"text"``.

    Returns the rendered report string.
    """
    template_dir = _get_template_dir(config)
    env = _create_env(template_dir)

    template_name = "monthly_report.j2"
    try:
        template = env.get_template(template_name)
    except Exception as exc:
        logger.error("Failed to load template %s: %s", template_name, exc)
        return _fallback_monthly(analysis_data, monthly_breakdown)

    rendered = template.render(
        data=analysis_data,
        months=monthly_breakdown,
        format=output_format,
    )

    if output_format == "text":
        rendered = _strip_html(rendered)

    return rendered


# ---------------------------------------------------------------------------
# Fallbacks (if templates are missing)
# ---------------------------------------------------------------------------

def _fallback_weekly(data: dict[str, Any]) -> str:
    """Minimal plain-text weekly report when template is unavailable."""
    totals = data.get("site_totals", {})
    period = data.get("period", {})
    lhf = data.get("low_hanging_fruit", [])

    lines = [
        f"SEO Weekly Report ({period.get('start', '?')} - {period.get('end', '?')})",
        "",
        f"Impressions: {_fmt_num(totals.get('impressions'))} ({_fmt_pct(totals.get('impressions_change_pct'))})",
        f"Clicks: {_fmt_num(totals.get('clicks'))} ({_fmt_pct(totals.get('clicks_change_pct'))})",
        f"Avg position: {_fmt_pos(totals.get('avg_position'))}",
        "",
        f"Low hanging fruit: {len(lhf)} opportunities",
        f"Open actions: {data.get('open_actions_count', 0)}",
    ]
    return "\n".join(lines)


def _fallback_monthly(data: dict[str, Any], months: list[dict[str, Any]]) -> str:
    """Minimal plain-text monthly report when template is unavailable."""
    lines = [_fallback_weekly(data), "", "Monthly trend:"]
    for m in months:
        lines.append(
            f"  {m.get('month', '?')}: "
            f"{_fmt_num(m.get('impressions'))} imp, "
            f"{_fmt_num(m.get('clicks'))} clicks, "
            f"pos {_fmt_pos(m.get('avg_position'))}"
        )
    return "\n".join(lines)


def _strip_html(text: str) -> str:
    """Remove HTML tags from text. Lightweight, no dependency."""
    import re

    clean = re.sub(r"<[^>]+>", "", text)
    # Collapse multiple blank lines
    clean = re.sub(r"\n{3,}", "\n\n", clean)
    return clean.strip()
