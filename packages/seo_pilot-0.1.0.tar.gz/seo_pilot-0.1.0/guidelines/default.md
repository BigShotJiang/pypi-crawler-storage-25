# SEO Expert Guidelines — Default

This is the default SEO rulebook for seo-pilot. Customize it for your site.

---

## Title tag rules

### Hard limits
- Max 60 characters (desktop) — Google truncates beyond this
- Min 40 characters — too short loses relevance signal
- Must be unique per page
- Primary keyword within first 3 words where possible

### What works (prioritized by CTR impact)
1. Question format — "Can You...?", "Does...?", "What Is...?" — avg +14% CTR
2. Number in title — "47 Stats", "9 Ways" — visual anchor
3. Year included — signals freshness; Google prefers recently updated
4. Parenthetical hooks — "(Data Inside)", "(Updated)" — +8-12% CTR
5. Front-loaded keyword — first 3 words should contain primary keyword
6. Specific claim over generic — "Cost You 9% Revenue" beats "Impact on Revenue"

### What kills CTR
- Passive phrases: "What Still Works", "What the Data Shows"
- Vague benefit claims: "Everything You Need to Know"
- Keyword stuffing: "Google Reviews Google Rating Google SEO"
- Year mismatch: "2025" in April 2026

---

## Meta description rules

### Hard limits
- 120-158 characters (Google rewrites 60-70% above this)
- Must not duplicate any other page's meta

### What works
1. Treat as ad copy — one job: win the click
2. Lead with the user's problem or the data point
3. Include a specific promise: "fix it in 10 min/day", "templates inside"
4. Social proof where real: "100+ restaurants", "50+ sources"
5. Active verbs: "Fix", "Learn", "Get", "See"

---

## Content scoring (low hanging fruit prioritization)

| Factor | Weight | Notes |
|---|---|---|
| Impression volume (28d) | 30% | 100+ = high opportunity |
| Current position | 25% | Pos 5-15 = highest ROI band |
| CTR gap vs expected | 25% | See benchmarks below |
| Title quality | 10% | Below 85 = auto-flag |
| Content freshness | 10% | Outdated year = -10 |

Pages scoring 70+ get actioned. Pages scoring 85+ are flagged as urgent.

### Expected CTR by position (2026 benchmarks)
- Pos 1: 28%
- Pos 2: 15%
- Pos 3: 11%
- Pos 4-5: 7-8%
- Pos 6-10: 3-5%
- Pos 11-20: 1-2%

---

## Content gap rules

A content gap is worth acting on if:
- 5+ impressions in 28d with no dedicated page
- Query has clear informational or commercial intent
- Not a duplicate of existing content

Not worth acting on if:
- Impressions < 5 and pos > 50 (too weak a signal)
- Existing page can be expanded to cover it

---

## Internal linking rules

- Every page must link to 2-3 related pages
- Every page must link to at least 1 product/conversion page
- Pillar pages should receive the most inbound internal links
- 2-5 contextual links per 1000 words
- Anchor text: descriptive, varied, natural
- No orphan pages (every page needs at least 1 inbound link)

---

## Priority decision tree

1. Pages with 200+ imp AND CTR < expected — title/meta fix (highest ROI)
2. Pages with pos 3-15 AND CTR < 50% of expected — title/meta fix
3. Year mismatch in title — update year (5-minute win)
4. Content gaps with 10+ impressions — blog brief
5. Position drops > 5 places from top 20 — content audit
6. Everything else — backlog

Never create new content while existing pages with pos 5-20 have broken titles.

---

## Measurement windows

- Title/meta changes: minimum 14 days before measuring
- Content changes: 28 days
- New pages: 90 days (young domain needs re-evaluation time)

### What counts as success
- CTR improvement > 0.5% for pages with 100+ impressions
- Position improvement > 2 places for pages in pos 5-20

### What counts as failure
- CTR unchanged after 28 days — rewrite again
- Position dropped further — investigate content/technical issue
