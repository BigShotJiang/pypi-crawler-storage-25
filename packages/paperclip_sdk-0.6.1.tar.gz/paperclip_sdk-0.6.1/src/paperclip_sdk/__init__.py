# src/paperclip_sdk/__init__.py

from paperclip_sdk._exceptions import (PaperclipAuthenticationError,
                                       PaperclipClientError,
                                       PaperclipHTTPError,
                                       PaperclipInvalidResponseError,
                                       PaperclipNotFoundError,
                                       PaperclipPermissionError,
                                       PaperclipRateLimitError,
                                       PaperclipServerError,
                                       PaperclipTransportError)
from paperclip_sdk._shared import (API_KEY_ENV_VAR, DEFAULT_BASE_URL,
                                   RetryPolicy, get_sdk_version)
from paperclip_sdk.async_client import AsyncPaperclip
from paperclip_sdk.client import Paperclip

__version__ = get_sdk_version()

__all__ = [
    "__version__",
    "API_KEY_ENV_VAR",
    "DEFAULT_BASE_URL",
    "RetryPolicy",
    "Paperclip",
    "AsyncPaperclip",
    "PaperclipClientError",
    "PaperclipTransportError",
    "PaperclipHTTPError",
    "PaperclipAuthenticationError",
    "PaperclipPermissionError",
    "PaperclipNotFoundError",
    "PaperclipRateLimitError",
    "PaperclipServerError",
    "PaperclipInvalidResponseError",
]
