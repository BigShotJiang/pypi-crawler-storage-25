# src/paperclip_sdk/async_client.py

import asyncio
import logging
import os
import random
import time
import uuid
from typing import Any, Protocol

import httpx

from paperclip_sdk._exceptions import (PaperclipClientError,
                                       PaperclipInvalidResponseError,
                                       PaperclipTransportError)
from paperclip_sdk._facade import AsyncToolPath
from paperclip_sdk._shared import (API_KEY_ENV_VAR, DEFAULT_BASE_URL,
                                   TOOL_EXECUTE_PATH, TOOL_MANIFEST_PATH,
                                   RetryPolicy, build_payload,
                                   build_request_headers, compute_retry_delay,
                                   configure_default_client_debug_logger,
                                   extract_error_message,
                                   extract_result_from_response,
                                   extract_suppressed_error,
                                   extract_tools_from_manifest,
                                   map_http_status_error, parse_response_json,
                                   should_retry_connect_error,
                                   should_retry_response, to_ms)

_DEBUG_HANDLER_NAME = "paperclip-sdk-async-client-debug-handler"
_MASKED_NAMESPACE_BLOCKLIST = frozenset({"call", "run", "function"})

logger = logging.getLogger(__name__)


class AsyncHttpClientProtocol(Protocol):
    async def post(
        self,
        url: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        ...

    async def get(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        ...

    async def aclose(self) -> None:
        ...


class AsyncPaperclip:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        http_client: AsyncHttpClientProtocol | None = None,
        retry_policy: RetryPolicy | None = None,
        client_logger: logging.Logger | None = None,
        log_server_meta: bool = False,
        debug: bool = False,
        suppress_errors: bool = True,
    ) -> None:
        self._owns_http_client = http_client is None
        self._retry_policy = retry_policy or RetryPolicy()
        self._retry_policy.validate()
        self._random = random.Random()
        self._logger = client_logger or logger
        self._log_server_meta = log_server_meta
        self._suppress_errors = suppress_errors
        self.last_error: PaperclipClientError | None = None

        if debug:
            if client_logger is None:
                configure_default_client_debug_logger(
                    self._logger,
                    handler_name=_DEBUG_HANDLER_NAME,
                )
            else:
                self._logger.setLevel(logging.DEBUG)

        if http_client is not None:
            self._http_client = http_client
        else:
            resolved_base_url = f"{(base_url or DEFAULT_BASE_URL).rstrip('/')}/"
            resolved_api_key = (
                api_key if api_key is not None else os.getenv(API_KEY_ENV_VAR)
            )

            headers = {"Content-Type": "application/json"}
            if resolved_api_key:
                headers["Authorization"] = f"Bearer {resolved_api_key}"

            self._http_client = httpx.AsyncClient(
                base_url=resolved_base_url,
                timeout=timeout,
                headers=headers,
            )

        self.tools = AsyncToolPath(self)

    def __getattr__(self, name: str) -> AsyncToolPath:
        if name.startswith("_"):
            raise AttributeError(name)

        if name in _MASKED_NAMESPACE_BLOCKLIST:
            raise AttributeError(name)

        return getattr(self.tools, name)

    def __getitem__(self, name: str) -> AsyncToolPath:
        return self.tools[name]

    async def _post_tool_request(
        self,
        payload: dict[str, Any],
        request_id: str,
    ) -> httpx.Response:
        return await self._http_client.post(
            TOOL_EXECUTE_PATH,
            json=payload,
            headers=build_request_headers(request_id),
        )

    async def _get_manifest_request(self, request_id: str) -> httpx.Response:
        return await self._http_client.get(
            TOOL_MANIFEST_PATH,
            headers=build_request_headers(request_id),
        )

    def _debug_log_server_meta(
        self,
        tool_name: str,
        request_id: str,
        meta: Any,
    ) -> None:
        if not self._log_server_meta:
            return
        if not self._logger.isEnabledFor(logging.DEBUG):
            return
        if not isinstance(meta, dict):
            return

        self._logger.debug(
            "Paperclip tool server meta tool=%s request_id=%s server_request_id=%s handler_duration_ms=%s server_duration_ms=%s",
            tool_name,
            request_id,
            meta.get("request_id"),
            meta.get("handler_duration_ms"),
            meta.get("server_duration_ms"),
        )

    def _suppress_error(
        self,
        error: PaperclipClientError,
        *,
        tool_name: str,
        request_id: str,
        attempt: int,
        total_duration: float,
    ) -> None:
        self.last_error = error
        self._logger.warning(
            "Paperclip tool error suppressed tool=%s request_id=%s attempt=%d/%d total_duration_ms=%.2f error_type=%s error=%s",
            tool_name,
            request_id,
            attempt,
            self._retry_policy.max_attempts,
            to_ms(total_duration),
            error.__class__.__name__,
            str(error),
        )

    async def manifest(self) -> dict[str, Any] | None:
        self.last_error = None

        request_id = uuid.uuid4().hex
        max_attempts = self._retry_policy.max_attempts
        started_at = time.perf_counter()

        self._logger.debug(
            "Paperclip manifest request started request_id=%s max_attempts=%d base_url=%s",
            request_id,
            max_attempts,
            getattr(self._http_client, "base_url", "custom-http-client"),
        )

        for attempt in range(1, max_attempts + 1):
            attempt_started_at = time.perf_counter()

            self._logger.debug(
                "Paperclip manifest attempt started request_id=%s attempt=%d/%d",
                request_id,
                attempt,
                max_attempts,
            )

            try:
                response = await self._get_manifest_request(request_id)
                request_duration = time.perf_counter() - attempt_started_at

                self._logger.debug(
                    "Paperclip manifest response received request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f",
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                )

                response.raise_for_status()

                parse_started_at = time.perf_counter()
                data = parse_response_json(response)
                parse_duration = time.perf_counter() - parse_started_at

                tools = extract_tools_from_manifest(data)
                data["tools"] = tools

                attempt_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                self._logger.debug(
                    "Paperclip manifest request succeeded request_id=%s attempt=%d/%d status_code=%d tools_count=%d request_duration_ms=%.2f parse_duration_ms=%.2f attempt_duration_ms=%.2f total_duration_ms=%.2f",  # NoQA
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    len(tools),
                    to_ms(request_duration),
                    to_ms(parse_duration),
                    to_ms(attempt_duration),
                    to_ms(total_duration),
                )
                return data

            except PaperclipInvalidResponseError as exc:
                total_duration = time.perf_counter() - started_at
                if self._suppress_errors:
                    self._suppress_error(
                        exc,
                        tool_name="manifest",
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = exc
                self._logger.error(
                    "Paperclip manifest invalid response request_id=%s attempt=%d/%d total_duration_ms=%.2f",
                    request_id,
                    attempt,
                    max_attempts,
                    to_ms(total_duration),
                )
                raise

            except httpx.HTTPStatusError as exc:
                response = exc.response
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at
                error_message = extract_error_message(response)

                if not should_retry_response(
                    response.status_code,
                    attempt=attempt,
                    retry_policy=self._retry_policy,
                ):
                    mapped_error = map_http_status_error(
                        status_code=response.status_code,
                        message=error_message,
                    )

                    if self._suppress_errors:
                        self._suppress_error(
                            mapped_error,
                            tool_name="manifest",
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = mapped_error
                    self._logger.error(
                        "Paperclip manifest HTTP failure request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f detail=%s",
                        request_id,
                        attempt,
                        max_attempts,
                        response.status_code,
                        to_ms(request_duration),
                        to_ms(total_duration),
                        error_message,
                    )
                    raise mapped_error from exc

                retry_delay = compute_retry_delay(
                    attempt,
                    retry_policy=self._retry_policy,
                    random_source=self._random,
                    response=response,
                )
                self._logger.warning(
                    "Paperclip manifest retry scheduled request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f detail=%s",
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                    to_ms(total_duration),
                    to_ms(retry_delay),
                    error_message,
                )
                if retry_delay > 0:
                    await asyncio.sleep(retry_delay)

            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as exc:
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                if not should_retry_connect_error(
                    attempt=attempt,
                    retry_policy=self._retry_policy,
                ):
                    transport_error = PaperclipTransportError(str(exc))

                    if self._suppress_errors:
                        self._suppress_error(
                            transport_error,
                            tool_name="manifest",
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = transport_error
                    self._logger.error(
                        "Paperclip manifest transport failure request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f error=%s",
                        request_id,
                        attempt,
                        max_attempts,
                        exc.__class__.__name__,
                        to_ms(request_duration),
                        to_ms(total_duration),
                        str(exc),
                    )
                    raise transport_error from exc

                retry_delay = compute_retry_delay(
                    attempt,
                    retry_policy=self._retry_policy,
                    random_source=self._random,
                )
                self._logger.warning(
                    "Paperclip manifest transport retry scheduled request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f error=%s",
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    to_ms(request_duration),
                    to_ms(total_duration),
                    to_ms(retry_delay),
                    str(exc),
                )
                if retry_delay > 0:
                    await asyncio.sleep(retry_delay)

            except httpx.RequestError as exc:
                total_duration = time.perf_counter() - started_at
                transport_error = PaperclipTransportError(str(exc))

                if self._suppress_errors:
                    self._suppress_error(
                        transport_error,
                        tool_name="manifest",
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = transport_error
                self._logger.error(
                    "Paperclip manifest non-retryable request failure request_id=%s attempt=%d/%d error_type=%s total_duration_ms=%.2f error=%s",
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    to_ms(total_duration),
                    str(exc),
                )
                raise transport_error from exc

            except PaperclipClientError as exc:
                total_duration = time.perf_counter() - started_at
                if self._suppress_errors:
                    self._suppress_error(
                        exc,
                        tool_name="manifest",
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = exc
                raise

        total_duration = time.perf_counter() - started_at
        error = PaperclipClientError("Manifest request failed after retries")

        if self._suppress_errors:
            self._suppress_error(
                error,
                tool_name="manifest",
                request_id=request_id,
                attempt=max_attempts,
                total_duration=total_duration,
            )
            return None

        self.last_error = error
        self._logger.error(
            "Paperclip manifest exhausted retries request_id=%s max_attempts=%d total_duration_ms=%.2f",
            request_id,
            max_attempts,
            to_ms(total_duration),
        )
        raise error

    async def list_tools(self) -> list[str] | None:
        manifest = await self.manifest()
        if manifest is None:
            return None
        return list(manifest["tools"])

    async def _invoke(self, tool_name: str, *args: Any, **kwargs: Any) -> Any:
        self.last_error = None

        request_id = uuid.uuid4().hex
        max_attempts = self._retry_policy.max_attempts
        started_at = time.perf_counter()
        payload = build_payload(
            tool_name,
            request_id,
            args,
            kwargs,
            suppress_errors=self._suppress_errors,
        )

        self._logger.debug(
            "Paperclip tool call started tool=%s request_id=%s max_attempts=%d base_url=%s",
            tool_name,
            request_id,
            max_attempts,
            getattr(self._http_client, "base_url", "custom-http-client"),
        )

        for attempt in range(1, max_attempts + 1):
            attempt_started_at = time.perf_counter()

            self._logger.debug(
                "Paperclip tool attempt started tool=%s request_id=%s attempt=%d/%d args_count=%d kwargs_keys=%s",
                tool_name,
                request_id,
                attempt,
                max_attempts,
                len(args),
                sorted(kwargs.keys()),
            )

            try:
                response = await self._post_tool_request(payload, request_id)
                request_duration = time.perf_counter() - attempt_started_at

                self._logger.debug(
                    "Paperclip tool response received tool=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f",
                    tool_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                )

                response.raise_for_status()

                parse_started_at = time.perf_counter()
                data = parse_response_json(response)
                parse_duration = time.perf_counter() - parse_started_at

                self._debug_log_server_meta(
                    tool_name=tool_name,
                    request_id=request_id,
                    meta=data.get("meta"),
                )

                suppressed_error = extract_suppressed_error(
                    data,
                    tool_name=tool_name,
                )
                if suppressed_error is not None:
                    total_duration = time.perf_counter() - started_at
                    if self._suppress_errors:
                        self._suppress_error(
                            suppressed_error,
                            tool_name=tool_name,
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = suppressed_error
                    raise suppressed_error

                result = extract_result_from_response(
                    data,
                    tool_name=tool_name,
                )

                attempt_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                self._logger.debug(
                    "Paperclip tool call succeeded tool=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f parse_duration_ms=%.2f attempt_duration_ms=%.2f total_duration_ms=%.2f",
                    tool_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                    to_ms(parse_duration),
                    to_ms(attempt_duration),
                    to_ms(total_duration),
                )
                return result

            except PaperclipInvalidResponseError as exc:
                total_duration = time.perf_counter() - started_at
                if self._suppress_errors:
                    self._suppress_error(
                        exc,
                        tool_name=tool_name,
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = exc
                self._logger.error(
                    "Paperclip tool invalid response tool=%s request_id=%s attempt=%d/%d total_duration_ms=%.2f",
                    tool_name,
                    request_id,
                    attempt,
                    max_attempts,
                    to_ms(total_duration),
                )
                raise

            except httpx.HTTPStatusError as exc:
                response = exc.response
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at
                error_message = extract_error_message(response)

                if not should_retry_response(
                    response.status_code,
                    attempt=attempt,
                    retry_policy=self._retry_policy,
                ):
                    mapped_error = map_http_status_error(
                        status_code=response.status_code,
                        message=error_message,
                    )

                    if self._suppress_errors:
                        self._suppress_error(
                            mapped_error,
                            tool_name=tool_name,
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = mapped_error
                    self._logger.error(
                        "Paperclip tool HTTP failure tool=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f detail=%s",
                        tool_name,
                        request_id,
                        attempt,
                        max_attempts,
                        response.status_code,
                        to_ms(request_duration),
                        to_ms(total_duration),
                        error_message,
                    )
                    raise mapped_error from exc

                retry_delay = compute_retry_delay(
                    attempt,
                    retry_policy=self._retry_policy,
                    random_source=self._random,
                    response=response,
                )
                self._logger.warning(
                    "Paperclip tool retry scheduled tool=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f detail=%s",
                    tool_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                    to_ms(total_duration),
                    to_ms(retry_delay),
                    error_message,
                )
                if retry_delay > 0:
                    await asyncio.sleep(retry_delay)

            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as exc:
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                if not should_retry_connect_error(
                    attempt=attempt,
                    retry_policy=self._retry_policy,
                ):
                    transport_error = PaperclipTransportError(str(exc))

                    if self._suppress_errors:
                        self._suppress_error(
                            transport_error,
                            tool_name=tool_name,
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = transport_error
                    self._logger.error(
                        "Paperclip tool transport failure tool=%s request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f error=%s",
                        tool_name,
                        request_id,
                        attempt,
                        max_attempts,
                        exc.__class__.__name__,
                        to_ms(request_duration),
                        to_ms(total_duration),
                        str(exc),
                    )
                    raise transport_error from exc

                retry_delay = compute_retry_delay(
                    attempt,
                    retry_policy=self._retry_policy,
                    random_source=self._random,
                )
                self._logger.warning(
                    "Paperclip tool transport retry scheduled tool=%s request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f error=%s",
                    tool_name,
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    to_ms(request_duration),
                    to_ms(total_duration),
                    to_ms(retry_delay),
                    str(exc),
                )
                if retry_delay > 0:
                    await asyncio.sleep(retry_delay)

            except httpx.RequestError as exc:
                total_duration = time.perf_counter() - started_at
                transport_error = PaperclipTransportError(str(exc))

                if self._suppress_errors:
                    self._suppress_error(
                        transport_error,
                        tool_name=tool_name,
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = transport_error
                self._logger.error(
                    "Paperclip tool non-retryable request failure tool=%s request_id=%s attempt=%d/%d error_type=%s total_duration_ms=%.2f error=%s",
                    tool_name,
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    to_ms(total_duration),
                    str(exc),
                )
                raise transport_error from exc

            except PaperclipClientError as exc:
                total_duration = time.perf_counter() - started_at
                if self._suppress_errors:
                    self._suppress_error(
                        exc,
                        tool_name=tool_name,
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = exc
                raise

        total_duration = time.perf_counter() - started_at
        error = PaperclipClientError(f"Tool call failed after retries: {tool_name}")

        if self._suppress_errors:
            self._suppress_error(
                error,
                tool_name=tool_name,
                request_id=request_id,
                attempt=max_attempts,
                total_duration=total_duration,
            )
            return None

        self.last_error = error
        self._logger.error(
            "Paperclip tool exhausted retries tool=%s request_id=%s max_attempts=%d total_duration_ms=%.2f",
            tool_name,
            request_id,
            max_attempts,
            to_ms(total_duration),
        )
        raise error

    async def close(self) -> None:
        if self._owns_http_client:
            await self._http_client.aclose()

    async def __aenter__(self) -> "AsyncPaperclip":
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.close()


__all__ = ["AsyncPaperclip"]
