# src/paperclip_sdk/_facade.py

from __future__ import annotations

from typing import Any, Protocol


class SupportsSyncToolInvocation(Protocol):
    def _invoke(
        self,
        tool_name: str,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        ...


class SupportsAsyncToolInvocation(Protocol):
    async def _invoke(
        self,
        tool_name: str,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        ...


def _extend_parts(parts: tuple[str, ...], name: str) -> tuple[str, ...]:
    cleaned_name = name.strip().strip(".")
    if not cleaned_name:
        raise ValueError("Tool path segment must not be empty")

    return parts + tuple(part for part in cleaned_name.split(".") if part)


class ToolPath:
    __slots__ = ("_client", "_parts")

    def __init__(
        self,
        client: SupportsSyncToolInvocation,
        parts: tuple[str, ...] = (),
    ) -> None:
        self._client = client
        self._parts = parts

    def __getattr__(self, name: str) -> "ToolPath":
        if name.startswith("_"):
            raise AttributeError(name)

        return ToolPath(
            self._client,
            _extend_parts(self._parts, name),
        )

    def __getitem__(self, name: str) -> "ToolPath":
        if not isinstance(name, str):
            raise TypeError("Tool path segment must be a string")

        return ToolPath(
            self._client,
            _extend_parts(self._parts, name),
        )

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if not self._parts:
            raise AttributeError("Root tool path is not callable")

        return self._client._invoke(".".join(self._parts), *args, **kwargs)

    def __repr__(self) -> str:
        path = ".".join(self._parts) or "<root>"
        return f"<ToolPath {path}>"


class AsyncToolPath:
    __slots__ = ("_client", "_parts")

    def __init__(
        self,
        client: SupportsAsyncToolInvocation,
        parts: tuple[str, ...] = (),
    ) -> None:
        self._client = client
        self._parts = parts

    def __getattr__(self, name: str) -> "AsyncToolPath":
        if name.startswith("_"):
            raise AttributeError(name)

        return AsyncToolPath(
            self._client,
            _extend_parts(self._parts, name),
        )

    def __getitem__(self, name: str) -> "AsyncToolPath":
        if not isinstance(name, str):
            raise TypeError("Tool path segment must be a string")

        return AsyncToolPath(
            self._client,
            _extend_parts(self._parts, name),
        )

    async def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if not self._parts:
            raise AttributeError("Root tool path is not callable")

        return await self._client._invoke(".".join(self._parts), *args, **kwargs)

    def __repr__(self) -> str:
        path = ".".join(self._parts) or "<root>"
        return f"<AsyncToolPath {path}>"
