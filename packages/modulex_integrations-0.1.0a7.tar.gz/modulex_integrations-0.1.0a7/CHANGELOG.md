# Changelog

All notable changes to `modulex-integrations` are recorded here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added (Wave 4 — fourth bulk migration batch)

- **5 new integrations** — 60 LangChain `@tool` actions across the
  mid-size band, half on the token-based runtime convention:
  - `linear` (7 actions) — Linear project + issue management.
    **First GraphQL integration** in the package; uses raw
    `Authorization: <key>` (no Bearer prefix). Filter clauses
    interpolated into the GraphQL string verbatim (matching legacy).
  - `airtable` (7 actions) — base discovery + table CRUD. Auto-
    batches at Airtable's 10-records-per-request limit;
    `update_records` accepts both `{id, fields: {…}}` and
    `{id, field_a: v}` shapes (legacy dual-shape preserved). camelCase
    `createdTime` field silenced via per-file N815 ignore.
  - `telegram` (17 actions) — Telegram Bot API for messaging, media,
    chat management, moderation, and long-polling. **Unique
    credential pattern**: bot token lives **inside the URL path**
    (`/bot{token}/...`), not a header.
  - `servicenow` (7 actions) — ITSM Trouble-Ticket API + Table API
    CRUD. Paired `oauth2 + bearer_token` schemas; instance-name
    substitution in URLs (`https://{instance_name}.service-now.com`).
    Token-based runtime convention with `_validate` for instance +
    token both being present.
  - `intercom` (13 actions) — customer-communication CRUD across
    contacts, conversations, tags, admins, and messages. Paired
    `oauth2 + bearer_token` schemas. **Three actions chain two API
    calls internally** — `upsert_contact` (search → PUT/POST),
    `create_note` (/me → POST note), `send_incoming_message`
    (/contacts → POST conversation).
- 90 new tests (`isinstance(result, dict)` + roundtrip-via-
  `model_validate` pattern, plus multi-call coverage for the
  Intercom two-step workflows); total: 247 → 337 passing.

### Added (Wave 3 — third bulk migration batch)

- **5 new integrations** — 43 LangChain `@tool` actions across the
  mid-size band, exercising every remaining auth pattern at least once:
  - `short_io` (8 actions) — URL shortening + analytics + link metadata.
    `api_key` (raw header, no `Bearer` prefix). Per-file `N815` ignore
    for the camelCase outputs (`originalURL`, `shortURL`, etc.).
  - `nasdaq` (7 actions) — financial data via the `nasdaqdatalink` SDK
    (first non-LangChain vendor SDK in this phase). `api_key` via
    `?api_key={api_key}` query string — re-proves the
    `TestEndpoint.params` path introduced in Wave 2. Pandas DataFrames
    coerced to JSON-safe records with NaN→None cleanup (handles
    pandas 3.x behavior change).
  - `firecrawl` (7 actions) — AI web scraping/crawling/search.
    **First integration with paired `api_key + modulex_key` schemas**
    (both Bearer-authed; runtime picks which credential to inject).
    Long-running jobs use 180s timeouts.
  - `jina_ai` (7 actions) — embeddings, rerank, reader, search, deep
    search, segment, classify. Second paired-schemas integration. Six
    distinct subdomains (`api.jina.ai`, `r.jina.ai`, `s.jina.ai`,
    `deepsearch.jina.ai`, `segment.jina.ai`). Reader/Search consume
    configuration via `X-*` request headers (legacy pattern preserved).
  - `calendly` (11 actions) — events, invitees, event types,
    scheduling links, availability, organization members, groups,
    webhook subscriptions. **First `oauth2 + bearer_token` integration
    since github/slack** (token-based runtime convention with
    `auth_type, auth_data` first args). Auto-resolves missing
    `user`/`organization` filters via a side call to `/users/me`.
- 73 new tests (`isinstance(result, dict)` + roundtrip-via-
  `model_validate` pattern, plus SDK-mock + paired-schema coverage);
  total: 174 → 247 passing.
- `nasdaq/dependencies.toml` declares `nasdaq-data-link>=1.0.0`.
  Added to `[project.optional-dependencies] dev` extras so the SDK
  module is importable for `patch.dict(sys.modules)` test mocks.
  Pandas comes in transitively.

### Added (Wave 2 — second bulk migration batch)

- **5 new integrations** — 31 LangChain `@tool` actions, mostly
  small/simple HTTP across `api_key` and one `modulex_key`:
  - `klaviyo` (5 actions) — list/profile/subscription management
    against the Klaviyo REST API (revision `2024-10-15`).
  - `convertapi` (4 actions) — file/base64/web URL conversion plus
    format discovery. First integration to use `test_endpoint.params`
    for query-string credential validation (`?Secret={api_key}`).
  - `appdrag` (3 actions) — cloud function invocation and raw
    INSERT/UPDATE against the AppDrag CloudDB. First integration with
    **two env vars** (`APPDRAG_API_KEY` + `APPDRAG_APP_ID`), both
    auto-injected by the runtime.
  - `hackernews` (10 actions) — search via hnrss.org RSS feeds plus
    direct Firebase JSON API (`top/new/best/ask/show/job` stories,
    item, user). Public API — `modulex_key` auth_schema, no
    `test_endpoint`.
  - `lemon_squeezy` (10 actions) — customers/orders/products/
    subscriptions/stores via the JSON:API v1 endpoints. Each list
    method returns `data` + `meta` page-state unchanged.
- 69 new tests (`isinstance(result, dict)` + roundtrip-via-
  `model_validate` pattern); total: 105 → 174 passing.

### Changed (schema)

- `TestEndpoint.params: dict[str, str]` added — additive, defaults
  to `{}`. Lets integrations whose credential test auths via query
  string (ConvertAPI's `?Secret={api_key}`; nasdaq in Wave 3 follows
  the same pattern) match the modulex runtime, which already reads
  `test_endpoint.get("params", {})` in `credential_service.py`. Fully
  backward-compatible — existing manifests are unaffected.

### Added

- Initial repository skeleton (src/ layout, hatchling build, pytest/ruff/mypy config).
- `IntegrationManifest` pydantic schema with discriminated-union `auth_schemas` covering oauth2, bearer_token, api_key, modulex_key, custom, internal.
- Contract tests on a github-shaped manifest.
- `CLAUDE.md` — project rules for Claude Code sessions in this repo.
- `external-briefs/` workflow scaffold (`README.md` spec + `modulex/` placeholder) for coordinating changes in sibling repos.
- Community meta files: `.github/CODEOWNERS`, `.github/PULL_REQUEST_TEMPLATE.md`, `.github/ISSUE_TEMPLATE/{bug_report.md,integration_request.md,config.yml}`, `SECURITY.md`, `CODE_OF_CONDUCT.md` (Contributor Covenant v2.1).
- `.github/workflows/validate.yml` — lint + type-check + test on Python 3.12 and 3.13.
- `.editorconfig` and `.python-version` for consistent local tooling.

### Changed

- `README.md` expanded with "Why this repo exists", badges, per-integration layout, and a roadmap section.
- `.gitignore` no longer ignores `.python-version` (file is now committed); now also ignores the hatch-vcs-generated `src/modulex_integrations/_version.py`.
- `pyproject.toml`: switched to `dynamic = ["version"]` driven by `hatch-vcs`; static `version = "0.0.1"` removed. Static `__version__` in `__init__.py` replaced by `importlib.metadata`-based resolution.

### Added (release infrastructure)

- `.github/workflows/release.yml` — tag-triggered (`v*`) workflow that classifies pre-release vs stable via PEP 440, enforces branch-of-origin (stable from `main`, pre-release from `staging`), builds sdist + wheel, and publishes to PyPI via Trusted Publishing OIDC in the `release-pypi` environment.
- `RELEASING.md` — release process, PyPI Trusted Publisher setup checklist, and the modulex-side per-branch pinning policy.

### Added (Wave 1 — first bulk migration batch)

- **5 new integrations** — 19 LangChain `@tool` actions across simple
  HTTP + validated auth types (`api_key`, `modulex_key`):
  - `instacart` (3 actions) — public Instacart recipe/list/retailer endpoints
  - `tinyurl` (3 actions) — URL shortening + analytics + metadata
  - `customerio` (3 actions) — first integration using HTTP Basic Auth
    (site_id + api_key pair); runtime injects both, tool builds Basic
    header
  - `npm` (6 actions) — public npm registry: info, search, popular,
    versions, deps, downloads. First integration where api_key is
    optional (public registry)
  - `pinterest` (4 actions) — boards + sections + pins; supports both
    `api_key` and `oauth2` auth schemas (both resolve to Bearer)
- 44 new tests (`isinstance(result, dict)` + roundtrip-via-`model_validate`
  pattern); total: 61 → 105 passing.

### Changed (schema)

- `_AuthSchemaBase.test_endpoint` is now optional
  (`TestEndpoint | None = None`). Public-API integrations like
  instacart and hackernews legitimately ship no credential test
  endpoint — the legacy modulex JSON omitted the field. Purely
  additive change.

### Fixed

- **Critical**: `@tool` functions now return plain dicts at runtime
  (via the new `@serialize_pydantic_return` decorator), not pydantic
  ``BaseModel`` instances. modulex's downstream code serializes every
  tool result via plain ``json.dumps()``, which cannot encode pydantic
  models — calling `exa.search` or `tavily.web_search` from a modulex
  agent crashed with ``TypeError: Object of type SearchOutput is not
  JSON serializable``. All four integrations (github, slack, exa,
  tavily) updated. Return-type annotations stay as pydantic classes
  so modulex's ``package_loader.py`` can still derive the LLM-facing
  output_schema via ``typing.get_type_hints``.

### Added

- `modulex_integrations.serialize_pydantic_return` — decorator that
  auto-dumps pydantic returns to dicts. Top-level re-export.
  Implementation in `src/modulex_integrations/_internal/serialize.py`.
- `tests/test_serialize.py` — 4 unit tests pinning down the contract
  (pydantic → dict; non-pydantic → passthrough; annotation preserved
  for `get_type_hints`; nested fields dump correctly).
- All existing tests updated to assert `isinstance(result, dict)` and
  roundtrip through `Model.model_validate(result)` for attribute
  access. Test count: 57 → 61.

### Added (Phase 3 — SDK pattern + further migrations)

- **tavily integration** — 3 LangChain `@tool` async actions:
  `web_search`, `answer_search`, `news_search`. First SDK-based
  integration: wraps `langchain_tavily.TavilySearch` via lazy import
  inside each tool. The lazy import + graceful "install with pip
  install langchain-tavily" fallback matches legacy modulex behavior.
- `tavily/dependencies.toml` declares `langchain-tavily>=0.2.0` for
  the future assemble script.
- `pyproject.toml` `dev` extras include `langchain-tavily` so tests
  can exercise the real SDK class via `unittest.mock.patch` — the
  CONTRIBUTING.md-specified pattern for SDK tools, now validated.
- Tests use `patch.dict(sys.modules, {"langchain_tavily": ...})` to
  both substitute a mock SDK class (happy path) and simulate the
  missing-SDK ImportError (graceful-degradation path).

### Added (Phase 3 — first bulk migrations)

- **slack integration** — 8 LangChain `@tool` async actions:
  `list_channels`, `post_message`, `reply_to_thread`, `add_reaction`,
  `get_channel_history`, `get_thread_replies`, `get_users`,
  `get_user_profile`. OAuth2 + Bot Token auth schemas. Slack's
  HTTP-200-with-`ok:false` error model is preserved as
  `success=False` + `error` on every output model.
- **exa integration** — 4 LangChain `@tool` async actions: `search`,
  `get_contents`, `find_similar`, `answer`. First migration to use
  the `api_key` runtime convention (signature is
  `(query, api_key, ...)` rather than `(auth_type, auth_data, ...)`)
  and to exercise the `api_key` + `modulex_key` auth schema variants.
- `pyproject.toml`: entry-point lines for `slack` and `exa`. End-to-end
  discovery now reports 3 integrations contributing 28 tools.
- 24 new tests (12 slack + 12 exa, includes failure-branch coverage
  for the `ok:false` and non-2xx + empty-key paths). Total package
  test count: **49**.

### Changed (schema)

- `IntegrationManifest.auth_schemas[*].test_endpoint.body` — new
  optional field (`dict[str, Any] | None = None`). Needed for POST-based
  credential checks (e.g. Exa's `POST /search` with a probe payload).
  Purely additive; existing manifests are unaffected.

### Added (github POC migration)

- First integration: `modulex_integrations.tools.github` — 16 LangChain `@tool` async actions ported from the legacy modulex inline implementation:
  `list_repositories`, `create_repository`, `delete_repository`, `get_repository`,
  `list_issues`, `create_issue`, `get_issue`, `update_issue`,
  `list_pull_requests`, `create_pull_request`, `get_pull_request`, `merge_pull_request`,
  `create_branch`, `get_file_content`, `create_commit`, `search_code`.
- `manifest.py` — pydantic `IntegrationManifest` replacing the legacy 1180-line JSON; OAuth2 + Personal Access Token auth schemas with credential test endpoints.
- `outputs.py` — 16 pydantic response models; the runtime derives output JSONSchema via `Model.model_json_schema()` (no `output_schema` field in the manifest).
- `tests/test_github.py` — 16 happy-path tests using `pytest-httpx`'s `httpx_mock` fixture plus three manifest sanity tests. Total package test count: 8 schema + 19 github = 27.
- `pyproject.toml`: entry-point line `github = "modulex_integrations.tools.github"` registered under `[project.entry-points."modulex.tools"]`. Validated end-to-end via `importlib.metadata.entry_points(group="modulex.tools")` — modulex's runtime discovery path works without changes.

## [0.0.1] — 2026-05-15

Project bootstrap.
