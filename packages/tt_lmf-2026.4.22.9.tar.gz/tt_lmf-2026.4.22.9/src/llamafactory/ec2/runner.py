# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""EC2 SFT runner — Python port of scripts/ec2_sft/train_existing.sh.

Full lifecycle: start instance -> wait SSH -> rsync repo -> launch training
in tmux -> poll for completion -> rsync results back -> publish hook -> stop.

Error-handling design:
- Training runs in a remote tmux session, surviving SSH and local disconnects.
- Unless ``lifecycle.after_training`` is ``nothing``/``none``, the orchestrator stops
  the instance after each run (it is not left running indefinitely).
- If results could not be synced (host disconnect, rsync failure), bootstrap_ec2.sh
  compresses the checkpoint to a tar.gz on the persistent EBS volume before halting.
  Start the instance later and pull the archive to recover.
- SIGINT (Ctrl+C) and SIGTERM are caught and trigger graceful cleanup.
- bootstrap_ec2.sh (on EC2) waits up to auto_shutdown_grace_sec for a
  .ec2_results_sync_ack file, then halts regardless.
"""

from __future__ import annotations

import logging
import os
import shlex
import signal
import stat
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Optional

import yaml

from .config import EC2RunConfig, EC2SSHSettings
from .pip_stamp import STAMP_FILENAME, pip_install_needed, record_stamp_after_pip_install


logger = logging.getLogger("llamafactory.ec2")

TMUX_SESSION = "llamafactory-train"
SYNC_ACK_NAME = ".ec2_results_sync_ack"
STATE_FILENAME = ".ec2_state"


class EC2TrainingError(Exception):
    """Raised when EC2 training fails at any lifecycle stage."""

    def __init__(self, message: str, exit_code: int = 1):
        super().__init__(message)
        self.exit_code = exit_code


def _log(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.info("[%s] %s", ts, msg)


def _warn(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.warning("[%s] WARN: %s", ts, msg)


def _err(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.error("[%s] ERROR: %s", ts, msg)


def ensure_local_venv_matches_pip_spec(pip_spec: str, repo_root: str | None = None) -> None:
    """Refresh the **local** install before EC2 training or chat (same policy as remote bootstrap).

    * If ``package.pip_spec`` is set: force-reinstall that root requirement (``--no-deps``), then a
      normal upgrade pass for any new dependency edges.
    * If it is empty but ``repo_root/pyproject.toml`` exists: same two-step pattern for
      ``pip install -e repo_root`` (or ``uv pip install -e repo_root``).

    For **PyPI** ``package.pip_spec`` (non-VCS), always runs both pip steps so EC2 and laptops
    pick up new ``tt-lmf`` releases. Skips only apply to **git/VCS** specs (unchanged resolved
    SHA) and **editable** installs when the workspace fingerprint matches (see ``pip_stamp``).

    ``repo_root`` defaults to the current working directory.
    """
    base = [sys.executable, "-m", "pip", "install", "-U", "--no-cache-dir"]
    root_path = Path(os.path.abspath(os.path.expanduser(repo_root or os.getcwd()))).resolve()
    stamp_path = root_path / STAMP_FILENAME
    spec = pip_spec.strip()
    try:
        needed, skip_msg = pip_install_needed(root_path, pip_spec, stamp_path)
    except Exception as e:
        _warn(f"Could not evaluate {STAMP_FILENAME}; running pip install ({e})")
        needed, skip_msg = True, ""
    if not needed:
        if skip_msg:
            _log(skip_msg)
        return

    if spec:
        _log("Local pip: force-reinstall from package.pip_spec (then resolve deps)...")
        subprocess.run([*base, "--force-reinstall", "--no-deps", spec], check=True)
        subprocess.run([*base, "--upgrade-strategy", "only-if-needed", spec], check=True)
        try:
            record_stamp_after_pip_install(root_path, pip_spec)
        except Exception as e:
            _warn(f"Could not update {STAMP_FILENAME}: {e}")
        return

    root = str(root_path)
    if os.path.isfile(os.path.join(root, "pyproject.toml")):
        _log("Local pip: force-reinstall editable repo (no package.pip_spec; then resolve deps)...")
        subprocess.run([*base, "--force-reinstall", "--no-deps", "-e", root], check=True)
        subprocess.run([*base, "--upgrade-strategy", "only-if-needed", "-e", root], check=True)
        try:
            record_stamp_after_pip_install(root_path, pip_spec)
        except Exception as e:
            _warn(f"Could not update {STAMP_FILENAME}: {e}")


def _ssh_opts(cfg: EC2RunConfig) -> list[str]:
    return [
        "-i",
        cfg.key_file,
        "-o",
        "StrictHostKeyChecking=accept-new",
        "-o",
        "ConnectTimeout=5",
        "-o",
        "BatchMode=yes",
    ]


def _ssh_target(cfg: EC2RunConfig) -> str:
    return f"{cfg.ssh_user}@{cfg.private_ip}"


def _ssh_opts_settings(s: EC2SSHSettings) -> list[str]:
    return [
        "-i",
        s.key_file,
        "-o",
        "StrictHostKeyChecking=accept-new",
        "-o",
        "ConnectTimeout=5",
        "-o",
        "BatchMode=yes",
    ]


def _ssh_target_settings(s: EC2SSHSettings) -> str:
    return f"{s.ssh_user}@{s.private_ip}"


def _ssh_run_settings(s: EC2SSHSettings, remote_cmd: str, check: bool = True) -> subprocess.CompletedProcess:
    cmd = ["ssh"] + _ssh_opts_settings(s) + [_ssh_target_settings(s), remote_cmd]
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


def _ssh_run(cfg: EC2RunConfig, remote_cmd: str, check: bool = True) -> subprocess.CompletedProcess:
    """Run a command on the EC2 instance over SSH."""
    cmd = ["ssh"] + _ssh_opts(cfg) + [_ssh_target(cfg), remote_cmd]
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


# ── 0. Pre-flight checks ────────────────────────────────────────────────


def _preflight_aws_credentials(cfg: EC2RunConfig) -> None:
    """Verify AWS credentials are valid before touching any EC2 resources."""
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError

    try:
        sts = boto3.client("sts", region_name=cfg.region)
        identity = sts.get_caller_identity()
        _log(f"AWS credentials OK (account: {identity['Account']})")
    except NoCredentialsError:
        raise EC2TrainingError("AWS credentials not configured. Run: aws configure  or  aws sso login")
    except (BotoCoreError, ClientError) as e:
        raise EC2TrainingError(f"AWS credential check failed: {e}")


def preflight_ssh_key_permissions(key_file: str) -> None:
    """Ensure SSH key file has safe permissions (chmod 600). SSH refuses overly permissive keys."""
    try:
        fd = os.open(key_file, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            st = os.fstat(fd)
            if st.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
                os.fchmod(fd, 0o600)
                _log(f"Fixed key file permissions to 600: {key_file}")
        finally:
            os.close(fd)
    except OSError as e:
        _warn(f"Could not verify SSH key permissions: {e}")


def _preflight_key_permissions(cfg: EC2RunConfig) -> None:
    preflight_ssh_key_permissions(cfg.key_file)


def _preflight_training_hint(cfg: EC2RunConfig) -> None:
    """Read the training YAML and log expected runtime info (epochs, steps, max_hours)."""
    train_yaml_path = os.path.join(cfg.repo_root, cfg.training_config)
    try:
        with open(train_yaml_path) as f:
            tc = yaml.safe_load(f) or {}
    except Exception:
        return

    parts = []
    epochs = tc.get("num_train_epochs")
    max_steps = tc.get("max_steps")
    if epochs is not None:
        parts.append(f"num_train_epochs={epochs}")
    if max_steps is not None:
        parts.append(f"max_steps={max_steps}")

    hint = ", ".join(parts) if parts else "(no num_train_epochs / max_steps in YAML)"
    cap = f"lifecycle.max_hours={cfg.max_hours}" if cfg.max_hours else "no max_hours cap"
    _log(f"Runtime hint: {hint}; {cap}.")
    _log("Wall time varies by dataset size, GPU count, and cutoff_len — use monitor.sh and max_hours as guardrails.")


# ── 1. Start instance ───────────────────────────────────────────────────


def start_ec2_instance(instance_id: str, region: str) -> None:
    """Start an EC2 instance and wait until the ``running`` state (shared with recovery CLI)."""
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError

    _log(f"Starting instance {instance_id}...")
    ec2 = boto3.client("ec2", region_name=region)
    try:
        ec2.start_instances(InstanceIds=[instance_id])
    except (BotoCoreError, ClientError) as e:
        raise EC2TrainingError(
            f"aws ec2 start-instances failed: {e}\n"
            "  Typical causes: IAM missing ec2:StartInstances, wrong AWS_PROFILE/region, or invalid instance ID."
        )

    _log("Waiting for instance to reach 'running' state...")
    try:
        waiter = ec2.get_waiter("instance_running")
        waiter.wait(InstanceIds=[instance_id])
    except (BotoCoreError, ClientError) as e:
        raise EC2TrainingError(
            f"Waiting for instance running state failed: {e}\n"
            "  The instance may have started — check AWS Console and stop it manually if needed."
        )
    _log("Instance running.")


def _start_instance(cfg: EC2RunConfig) -> None:
    """Start the EC2 instance using boto3 and wait until it is running."""
    start_ec2_instance(cfg.instance_id, cfg.region)


# ── 2. Wait for SSH ─────────────────────────────────────────────────────


def wait_ssh_ready(s: EC2SSHSettings, max_attempts: int = 36, interval: int = 10) -> None:
    """Poll SSH until the instance is reachable (up to ``max_attempts`` × ``interval`` seconds)."""
    _log(f"Waiting for SSH on {s.private_ip} (make sure VPN is connected)...")
    for _attempt in range(1, max_attempts + 1):
        result = _ssh_run_settings(s, "echo ok", check=False)
        if result.returncode == 0:
            _log("SSH ready.")
            return
        time.sleep(interval)

    raise EC2TrainingError(
        f"SSH did not become available after {max_attempts * interval}s.\n"
        f"  Is VPN connected?\n"
        f"  Is {s.private_ip} reachable?  ping {s.private_ip}"
    )


def _wait_ssh(cfg: EC2RunConfig, max_attempts: int = 36, interval: int = 10) -> None:
    """Poll SSH until the instance is reachable (up to max_attempts * interval seconds)."""
    wait_ssh_ready(cfg.ssh_settings(), max_attempts=max_attempts, interval=interval)


# ── 3. Clear stale sync ack ─────────────────────────────────────────────


def _clear_remote_sync_ack(cfg: EC2RunConfig) -> None:
    """Remove stale .ec2_results_sync_ack so a new run is not confused with a previous pull."""
    _ssh_run(cfg, f"rm -f {shlex.quote(cfg.remote_repo)}/{SYNC_ACK_NAME}", check=False)


# ── 4. Rsync workspace to EC2 ────────────────────────────────────────────────


def _rsync_exclude_file(cfg: EC2RunConfig) -> str:
    """Prefer repo's scripts/ec2_sft/.rsyncignore; else bundled default (Orbi workspace mode)."""
    legacy = os.path.join(cfg.repo_root, "scripts", "ec2_sft", ".rsyncignore")
    if os.path.isfile(legacy):
        return legacy
    bundled = Path(__file__).resolve().parent / "remote" / "default.rsyncignore"
    if bundled.is_file():
        return str(bundled)
    raise EC2TrainingError(f"No rsync exclude file (missing {legacy} and {bundled})")


def _rsync_to_ec2(cfg: EC2RunConfig) -> None:
    """Sync the local workspace to EC2 (YAML, data/, optional pyproject — not HF weights)."""
    _log(f"Syncing workspace to {cfg.private_ip}:{cfg.remote_repo}...")
    _log("  (Large weights: use Hugging Face hub IDs or sync.extra_uploads in pipeline YAML.)")
    rsync_ignore = _rsync_exclude_file(cfg)

    ssh_arg = "ssh " + " ".join(shlex.quote(o) for o in _ssh_opts(cfg))
    cmd = [
        "rsync",
        "-az",
        "--progress",
        "--exclude-from",
        rsync_ignore,
        "-e",
        ssh_arg,
        f"{cfg.repo_root}/",
        f"{_ssh_target(cfg)}:{cfg.remote_repo}/",
    ]
    subprocess.run(cmd, check=True)
    _log("Workspace synced.")


def _rsync_extra_uploads(cfg: EC2RunConfig) -> None:
    """Upload local model trees or other large paths not covered by the main workspace rsync."""
    if not cfg.extra_uploads:
        return
    ssh_arg = "ssh " + " ".join(shlex.quote(o) for o in _ssh_opts(cfg))
    host = _ssh_target(cfg)
    for ex in cfg.extra_uploads:
        src = os.path.realpath(os.path.expanduser(ex.source))
        remote_sub = ex.target.strip("/").replace("\\", "/")
        remote_dir = f"{cfg.remote_repo}/{remote_sub}"
        _log(f"Extra rsync: {src} -> {remote_dir}")
        _ssh_run(cfg, f"mkdir -p {shlex.quote(remote_dir)}", check=True)
        if os.path.isdir(src):
            dest = f"{host}:{remote_dir}/"
            subprocess.run(
                ["rsync", "-az", "--progress", "-e", ssh_arg, f"{src}/", dest],
                check=True,
            )
        else:
            dest = f"{host}:{remote_dir}/"
            subprocess.run(
                ["rsync", "-az", "--progress", "-e", ssh_arg, src, dest],
                check=True,
            )


def _push_remote_bootstrap(cfg: EC2RunConfig) -> None:
    """Upload the package-bundled bootstrap script (full LlamaFactory git checkout not required)."""
    local_script = Path(__file__).resolve().parent / "remote" / "bootstrap_remote.sh"
    if not local_script.is_file():
        raise EC2TrainingError(f"Bundled EC2 bootstrap missing: {local_script}")
    remote_path = f"{cfg.remote_repo}/.lf_bootstrap.sh"
    cmd = ["scp", *_ssh_opts(cfg), str(local_script), f"{_ssh_target(cfg)}:{remote_path}"]
    subprocess.run(cmd, check=True)
    _log(f"Uploaded remote bootstrap -> {remote_path}")


# ── 5. Write HF token ──────────────────────────────────────────────────


def _write_hf_token(cfg: EC2RunConfig) -> None:
    """Write HF token to a temp file on EC2 via stdin (never appears in process list)."""
    if not cfg.hf_token:
        return
    cmd = ["ssh"] + _ssh_opts(cfg) + [_ssh_target(cfg), f"cat > {shlex.quote(cfg.remote_repo)}/.hf_token"]
    subprocess.run(cmd, input=cfg.hf_token, text=True, check=True)


# ── 6. Launch training in tmux ──────────────────────────────────────────


def _launch_tmux(cfg: EC2RunConfig) -> bool:
    """Launch bundled ``.lf_bootstrap.sh`` in a remote tmux session.

    Returns True if a new session was created, False if reconnecting to existing.
    Training in tmux survives SSH disconnects and local process crashes.
    """
    result = _ssh_run(cfg, f"tmux has-session -t {TMUX_SESSION} 2>/dev/null && echo yes || echo no")
    existing = result.stdout.strip() == "yes"

    if existing:
        # Check whether the session is still actively training or is a stale completed run.
        stale_result = _ssh_run(
            cfg, f"cat {shlex.quote(cfg.remote_repo)}/training_status 2>/dev/null || true", check=False
        )
        stale_status = stale_result.stdout.strip()
        if stale_status.startswith("SUCCESS") or stale_status.startswith("FAILED"):
            _warn(
                f"Found existing tmux session '{TMUX_SESSION}' but training_status='{stale_status}' — "
                "this looks like a completed prior run. Killing stale session and starting fresh."
            )
            _ssh_run(cfg, f"tmux kill-session -t {TMUX_SESSION}", check=False)
            existing = False
        else:
            _log(
                f"Found existing tmux session '{TMUX_SESSION}' (status='{stale_status or 'none'}') — reconnecting to poll..."
            )
            return False

    _log("=" * 64)
    _log(f"Launching training in tmux session '{TMUX_SESSION}'...")
    _log("Training survives SSH disconnects.")
    _log(f"After training, EC2 halts after {SYNC_ACK_NAME} appears (successful saves/ pull),")
    _log(f"  or after {cfg.auto_shutdown_grace_sec}s with no ack. Checkpoint is compressed on EBS before halt.")
    _log("=" * 64)

    # Clear stale status/log from prior runs
    _rr = shlex.quote(cfg.remote_repo)
    _ssh_run(cfg, f"rm -f {_rr}/training_status {_rr}/training.log", check=False)

    auto_sd_flag = 1 if cfg.auto_shutdown_after_training else 0
    bs = f"{cfg.remote_repo}/.lf_bootstrap.sh"
    inner_parts: list[str] = []
    pip_spec = cfg.remote_pip_spec.strip()
    if pip_spec:
        inner_parts.append(f"export LF_REMOTE_PACKAGE_SPEC={shlex.quote(pip_spec)}")
    inner_parts.append(
        f"export AFTER_TRAINING={shlex.quote(cfg.after_training)} "
        f"AUTO_SHUTDOWN_AFTER_TRAINING={auto_sd_flag} "
        f"AUTO_SHUTDOWN_GRACE_SEC={cfg.auto_shutdown_grace_sec}"
    )
    inner_parts.append(f"bash {shlex.quote(bs)} {shlex.quote(cfg.remote_repo)} {shlex.quote(cfg.training_config)}")
    inner_parts.append("sleep 5")
    inner = "; ".join(inner_parts)

    _ssh_run(cfg, f"chmod +x {shlex.quote(bs)}")
    tmux_line = f"tmux new-session -d -s {TMUX_SESSION} -- bash -lc {shlex.quote(inner)}"
    _ssh_run(cfg, tmux_line)

    _log("Training launched. Polling for completion...")
    return True


# ── 7. Poll training_status ────────────────────────────────────────────


def _poll_training(cfg: EC2RunConfig, poll_interval: int = 30) -> int:
    """Block until training_status shows SUCCESS or FAILED. Returns the training exit code."""
    _log("Polling for completion...")
    _log("Streaming training output below. Ctrl+C detaches — training continues on EC2.")
    start_time = time.monotonic()
    unreachable_count = 0
    last_checkpoint_sync = time.monotonic()
    sync_interval_sec = cfg.checkpoint_sync_minutes * 60 if cfg.checkpoint_sync_minutes > 0 else 0

    if sync_interval_sec > 0:
        _log(
            f"Intermediate checkpoint sync enabled: every {cfg.checkpoint_sync_minutes} min -> {cfg.local_output_dir}"
        )

    tail_proc = _start_log_stream(cfg)

    try:
        while True:
            time.sleep(poll_interval)

            result = _ssh_run(cfg, f"cat {shlex.quote(cfg.remote_repo)}/training_status 2>/dev/null", check=False)
            status = result.stdout.strip() if result.returncode == 0 else "UNREACHABLE"

            if status.startswith("SUCCESS"):
                return 0

            if status.startswith("FAILED"):
                code_str = status.split(":", 1)[1] if ":" in status else "1"
                try:
                    return int(code_str)
                except ValueError:
                    return 1

            if status == "RUNNING":
                unreachable_count = 0
                tmux_check = _ssh_run(
                    cfg, f"tmux has-session -t {TMUX_SESSION} 2>/dev/null && echo yes || echo no", check=False
                )
                if tmux_check.stdout.strip() == "no":
                    _warn("tmux session gone but status=RUNNING — bootstrap may have crashed.")
                    return 1

                # Intermediate checkpoint sync
                if sync_interval_sec > 0:
                    now = time.monotonic()
                    if now - last_checkpoint_sync >= sync_interval_sec:
                        if _sync_intermediate_checkpoint(cfg):
                            _log("Intermediate checkpoint synced to local (overwriting previous).")
                        last_checkpoint_sync = now

            elif status == "UNREACHABLE":
                unreachable_count += 1
                _warn(f"SSH unreachable (attempt {unreachable_count}/10). Check VPN.")
                if unreachable_count >= 10:
                    raise EC2TrainingError("SSH unreachable for 5+ minutes. Training may still be running on EC2.")

            # max_hours guard
            if cfg.max_hours and cfg.max_hours > 0:
                elapsed_h = (time.monotonic() - start_time) / 3600
                if elapsed_h >= cfg.max_hours:
                    _warn(f"Training exceeded max_hours ({cfg.max_hours}). Stopping.")
                    _ssh_run(cfg, f"tmux kill-session -t {TMUX_SESSION}", check=False)
                    return 124
    finally:
        _stop_log_stream(tail_proc)


# ── 8. Log streaming ───────────────────────────────────────────────────


def _start_log_stream(cfg: EC2RunConfig) -> Optional[subprocess.Popen]:
    """Start a background SSH tail -f of training.log (matches bash ServerAliveInterval behavior)."""
    ssh_cmd = (
        ["ssh"]
        + _ssh_opts(cfg)
        + ["-o", "ServerAliveInterval=30", "-o", "ServerAliveCountMax=10"]
        + [_ssh_target(cfg)]
        + [f"tail -n 50 -f {shlex.quote(cfg.remote_repo)}/training.log 2>/dev/null"]
    )
    try:
        return subprocess.Popen(ssh_cmd, stdout=None, stderr=subprocess.DEVNULL)
    except Exception as e:
        _warn(f"Failed to start log stream: {e}")
        return None


def _stop_log_stream(proc: Optional[subprocess.Popen]) -> None:
    """Terminate the background log stream process."""
    if proc is None:
        return
    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


# ── 9. Intermediate checkpoint sync ───────────────────────────────────


def _sync_intermediate_checkpoint(cfg: EC2RunConfig) -> bool:
    """Rsync the latest checkpoint from EC2 into an isolated staging subdir.

    Writes to ``{local_output_dir}/_intermediate_ckpt/`` with ``--delete`` so
    only the latest checkpoint state is kept locally (bounded disk usage).
    The final sync (_rsync_results) pulls directly into ``local_output_dir``
    without ``--delete`` so user files there are never clobbered.
    Returns True if new data was synced.
    """
    staging = os.path.join(cfg.local_output_dir, "_intermediate_ckpt")
    os.makedirs(staging, exist_ok=True)
    ssh_arg = "ssh " + " ".join(shlex.quote(o) for o in _ssh_opts(cfg))
    cmd = [
        "rsync",
        "-az",
        "-L",  # follow symlinks on source (saves/ may be a symlink to NVMe)
        "--delete",
        "-e",
        ssh_arg,
        f"{_ssh_target(cfg)}:{cfg.remote_repo}/saves/",
        f"{staging}/",
    ]
    result = subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return result.returncode == 0


# ── 10. Rsync final results back ────────────────────────────────────────


def _save_id_for_messages(local_output_dir: str) -> str:
    """Short label for user-facing logs (e.g. ``exp/run_timestamp``)."""
    p = Path(local_output_dir).expanduser().resolve()
    if p.name and p.parent.name:
        return f"{p.parent.name}/{p.name}"
    return p.name or str(p)


def recovery_cli_command(repo_root: str) -> str:
    """Shell command users can paste after a failed final rsync (requires ``.ec2_state`` in repo)."""
    state_path = os.path.join(repo_root, STATE_FILENAME)
    return f"{shlex.quote(sys.executable)} -m llamafactory.ec2.recover_saves --state-file {shlex.quote(state_path)}"


def _remote_checkpoint_rsync_suffix(s: EC2SSHSettings) -> str:
    """Prefer ``saves_ebs_backup`` when it is larger than ``saves`` (e.g. empty NVMe after stop/start)."""
    rr = shlex.quote(s.remote_repo)
    script = (
        f"sv=0; bv=0; "
        f"if [ -d {rr}/saves ]; then sv=$(du -sm {rr}/saves 2>/dev/null | awk '{{print $1}}' || echo 0); fi; "
        f"if [ -d {rr}/saves_ebs_backup ]; then "
        f"bv=$(du -sm {rr}/saves_ebs_backup 2>/dev/null | awk '{{print $1}}' || echo 0); fi; "
        f'if [ "$bv" -gt "$sv" ]; then echo saves_ebs_backup; else echo saves; fi'
    )
    r = _ssh_run_settings(s, script, check=False)
    if r.returncode != 0:
        return "saves"
    lines = [ln.strip() for ln in (r.stdout or "").splitlines() if ln.strip()]
    last = lines[-1] if lines else "saves"
    return last if last in ("saves", "saves_ebs_backup") else "saves"


def cleanup_remote_ebs_backup_artifacts(s: EC2SSHSettings) -> None:
    """Remove ``saves_checkpoint_*.tar.gz`` and ``saves_ebs_backup/*`` on the instance after a verified pull."""
    rr = shlex.quote(s.remote_repo)
    remote = f"cd {rr} && rm -f saves_checkpoint_*.tar.gz 2>/dev/null; rm -rf saves_ebs_backup/* 2>/dev/null; echo ok"
    r = _ssh_run_settings(s, remote, check=False)
    if r.returncode == 0:
        _log("Removed remote saves_checkpoint_*.tar.gz and saves_ebs_backup/* to free EBS space.")
    else:
        _warn("Could not remove remote EBS backup artifacts — inspect disk on the instance if EBS is full.")


def pull_saves_from_remote(
    s: EC2SSHSettings,
    *,
    write_ack: bool = True,
    cleanup_ebs_artifacts: bool = True,
) -> bool:
    """Rsync checkpoint tree from EC2 into ``local_output_dir``; optionally write sync ack and prune EBS copies."""
    if not s.local_output_dir:
        _err("local_output_dir / RESULTS_LOCAL is empty — cannot pull saves.")
        return False

    suffix = _remote_checkpoint_rsync_suffix(s)
    _log(f"Syncing remote {suffix}/ to: {s.local_output_dir}")
    os.makedirs(s.local_output_dir, exist_ok=True)

    ssh_arg = "ssh " + " ".join(shlex.quote(o) for o in _ssh_opts_settings(s))
    rsync_cmd = ["rsync", "-az"]
    if suffix == "saves":
        rsync_cmd.append("-L")
    rsync_cmd.extend(
        [
            "--progress",
            "-e",
            ssh_arg,
            f"{_ssh_target_settings(s)}:{s.remote_repo}/{suffix}/",
            f"{s.local_output_dir}/",
        ]
    )
    result = subprocess.run(rsync_cmd, check=False)
    if result.returncode != 0:
        _warn(
            f"Checkpoint rsync failed (remote source was {suffix}/). {SYNC_ACK_NAME} not written. "
            "A tarball may still exist on the instance root under the repo (saves_checkpoint_*.tar.gz)."
        )
        return False

    log_cmd = [
        "rsync",
        "-az",
        "-e",
        ssh_arg,
        f"{_ssh_target_settings(s)}:{s.remote_repo}/training.log",
        os.path.join(s.local_output_dir, "training.log"),
    ]
    log_result = subprocess.run(log_cmd, check=False)
    if log_result.returncode != 0:
        _warn("Could not retrieve training.log")

    ack_ok = not write_ack
    if write_ack:
        ts = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        ack_dest = f"{s.remote_repo.rstrip('/')}/{SYNC_ACK_NAME}"
        ack_line = f"echo {shlex.quote(ts + ' ec2_runner')} > {shlex.quote(ack_dest)}"
        ack_result = _ssh_run_settings(s, ack_line, check=False)
        ack_ok = ack_result.returncode == 0
        if not ack_ok:
            _warn(
                f"Could not write {SYNC_ACK_NAME} on EC2 — sync incomplete; "
                "remote EBS backups left in place. Re-run recovery when SSH is stable."
            )

    if cleanup_ebs_artifacts and ack_ok:
        cleanup_remote_ebs_backup_artifacts(s)
    elif cleanup_ebs_artifacts and write_ack and not ack_ok:
        _warn("Skipping remote EBS backup cleanup until sync ack can be written.")

    if write_ack and not ack_ok:
        return False

    _log(f"Results saved to: {s.local_output_dir}")
    return True


def _rsync_results(cfg: EC2RunConfig) -> bool:
    """Pull checkpoints from EC2. Returns True on success."""
    return pull_saves_from_remote(cfg.ssh_settings(), write_ack=True, cleanup_ebs_artifacts=True)


# ── 11. Publish hook ────────────────────────────────────────────────────


def _run_publish_hook(cfg: EC2RunConfig) -> None:
    """Run the orbi publish command if configured."""
    if not cfg.orbi_publish_cmd:
        return

    cmd = cfg.orbi_publish_cmd.format(
        local_output_dir=shlex.quote(cfg.local_output_dir),
        run_id=shlex.quote(datetime.now(UTC).strftime("%Y%m%d-%H%M%S")),
        instance_id=shlex.quote(cfg.instance_id),
        training_config=shlex.quote(cfg.training_config),
    )

    _log(f"Running publish hook: {cmd}")
    result = subprocess.run(shlex.split(cmd), check=False, cwd=cfg.repo_root)
    if result.returncode != 0:
        _warn(f"Publish hook exited with code {result.returncode}")
    else:
        _log("Publish hook completed successfully.")


# ── 12. Stop instance ──────────────────────────────────────────────────


def stop_ec2_instance(instance_id: str, region: str) -> None:
    """Stop an EC2 instance via boto3 (best-effort logging on failure)."""
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError

    _log(f"Stopping instance {instance_id}...")
    ec2 = boto3.client("ec2", region_name=region)
    try:
        ec2.stop_instances(InstanceIds=[instance_id])
        _log("Instance stopped.")
    except (BotoCoreError, ClientError) as e:
        _warn(f"Instance stop may have failed. Check AWS Console: {instance_id}. Error: {e}")


def _stop_instance(cfg: EC2RunConfig) -> None:
    """Stop the EC2 instance via boto3 when lifecycle allows."""
    after = cfg.after_training.lower()
    if after in ("nothing", "none"):
        _log(f"lifecycle.after_training={cfg.after_training} — leaving instance running.")
        return

    stop_ec2_instance(cfg.instance_id, cfg.region)


# ── 13. State file (for monitor.sh compatibility) ──────────────────────


def _write_state_file(cfg: EC2RunConfig) -> str:
    """Write .ec2_state for monitor.sh compatibility. Returns the path."""
    state_path = os.path.join(cfg.repo_root, STATE_FILENAME)
    lines = [
        f"INSTANCE_ID={cfg.instance_id}",
        f"PRIVATE_IP={cfg.private_ip}",
        f"KEY_FILE={cfg.key_file}",
        f"SSH_USER={cfg.ssh_user}",
        f"REMOTE_REPO={cfg.remote_repo}",
        f"RESULTS_LOCAL={cfg.local_output_dir}",
        f"REGION={cfg.region}",
        f"AFTER_TRAINING={cfg.after_training}",
        f"AUTO_SHUTDOWN_AFTER_TRAINING={1 if cfg.auto_shutdown_after_training else 0}",
        f"AUTO_SHUTDOWN_GRACE_SEC={cfg.auto_shutdown_grace_sec}",
        f"LAUNCHED_AT={datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ')}",
        "CONFIG_FILE=<python-api>",
    ]
    import tempfile

    content = "\n".join(lines) + "\n"
    dir_name = os.path.dirname(state_path)
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, prefix=".ec2_state_tmp_")
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.rename(tmp_path, state_path)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    return state_path


def _cleanup_state_file(cfg: EC2RunConfig) -> None:
    state_path = os.path.join(cfg.repo_root, STATE_FILENAME)
    if os.path.isfile(state_path):
        os.remove(state_path)


# ═════════════════════════════════════════════════════════════════════════
# Public API
# ═════════════════════════════════════════════════════════════════════════


def run_ec2_training(config: EC2RunConfig | str | Path) -> int:
    """Run the full EC2 SFT lifecycle.

    Args:
        config: An EC2RunConfig instance, or a path to a pipeline YAML file.

    Returns:
        Training exit code on failure or when training succeeded and saves synced.
        Returns ``1`` when training reported success on EC2 but the final checkpoint
        rsync to this machine failed (``save id`` and recovery command are logged).

    Raises:
        EC2TrainingError: On fatal infrastructure failures (SSH unreachable, etc.).
        ValueError: On invalid configuration.
        FileNotFoundError: On missing key file or training config.

    Error-handling guarantees:
        - Training runs in tmux on EC2 and survives local disconnects.
        - The instance is stopped after a run when ``lifecycle.after_training`` is not
          ``nothing``/``none``.
        - If results could not be synced, bootstrap_ec2.sh compresses the
          checkpoint to a tar.gz on the persistent EBS volume before halting.
          Start the instance later and pull the archive to recover.
        - SIGINT (Ctrl+C) and SIGTERM are caught and handled gracefully.
        - monitor.sh and sync_results.sh remain fully compatible.
    """
    if isinstance(config, (str, Path)):
        config = EC2RunConfig.from_yaml(config)

    cfg = config
    cfg.validate()

    start_time = time.monotonic()
    instance_started = False
    training_launched = False
    results_synced = False

    # Install signal handlers so SIGTERM triggers the same cleanup as SIGINT
    original_sigterm = signal.getsignal(signal.SIGTERM)

    def _sigterm_handler(signum, frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, _sigterm_handler)

    _log("=" * 64)
    _log("LlamaFactory EC2 SFT — Python Runner")
    _log(f"  Instance:  {cfg.instance_id} ({cfg.private_ip})")
    _log(f"  Training:  {cfg.training_config}")
    _log(f"  After:     {cfg.after_training}")
    _log(
        f"  EC2 halt:  auto_shutdown_after_training={cfg.auto_shutdown_after_training} "
        f"(wait for sync ack up to {cfg.auto_shutdown_grace_sec}s)"
    )
    _log("=" * 64)

    try:
        # 0. Pre-flight checks
        ensure_local_venv_matches_pip_spec(cfg.remote_pip_spec, cfg.repo_root)
        _preflight_aws_credentials(cfg)
        _preflight_key_permissions(cfg)
        _preflight_training_hint(cfg)

        # 1. Start instance
        _start_instance(cfg)
        instance_started = True

        # 2. State file (for monitor.sh)
        _write_state_file(cfg)
        _log(f"Session state written to {STATE_FILENAME}")
        _log("  Monitor in another terminal: ./scripts/ec2_sft/monitor.sh")

        # 3. Wait SSH
        _wait_ssh(cfg)

        # 4. Clear stale sync ack
        _clear_remote_sync_ack(cfg)

        # 5. Rsync workspace (+ optional large bundle paths)
        _rsync_to_ec2(cfg)
        _rsync_extra_uploads(cfg)
        _push_remote_bootstrap(cfg)

        # 6. HF token
        _write_hf_token(cfg)

        # 7. Launch training in tmux
        _launch_tmux(cfg)
        training_launched = True

        # 8. Poll for completion
        train_exit = _poll_training(cfg)

        _log("=" * 64)
        _log("Training SUCCEEDED" if train_exit == 0 else f"Training FAILED (exit: {train_exit})")
        _log("=" * 64)

        # 9. Sync results
        results_synced = _rsync_results(cfg)

        if train_exit == 0 and training_launched and not results_synced:
            _err(
                "Training reported SUCCESS on EC2 but checkpoint download to this machine failed "
                f"(save id {_save_id_for_messages(cfg.local_output_dir)}). Exiting with code 1."
            )
            return 1

        # 10. Publish hook (only on success + synced)
        if results_synced and train_exit == 0:
            _run_publish_hook(cfg)

        return train_exit

    except (KeyboardInterrupt, SystemExit):
        _warn("Local process interrupted (Ctrl+C or SIGTERM).")
        raise

    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        elapsed_min = int((time.monotonic() - start_time) / 60)

        # Always stop the instance. It is never left running.
        if instance_started:
            if training_launched and not results_synced:
                _warn("Final checkpoint rsync did not finish — local results may be missing or partial.")
                _warn(f"  Save id:   {_save_id_for_messages(cfg.local_output_dir)}")
                _warn(f"  Instance:  {cfg.instance_id}")
                _warn(f"  Target:    {cfg.local_output_dir}")
                _warn("  Recovery:  start the instance (AWS Console), connect VPN, then:")
                _warn(f"    {recovery_cli_command(cfg.repo_root)}")
                _warn("  Shell alternative (same `.ec2_state`): ./scripts/ec2_sft/sync_results.sh")
                _warn(f"  `.ec2_state` kept at {os.path.join(cfg.repo_root, STATE_FILENAME)} for the commands above.")
            else:
                _cleanup_state_file(cfg)

            _stop_instance(cfg)

        _log("=" * 64)
        if training_launched and not results_synced:
            _log("Run finished — checkpoint download failed (see WARN lines above). Not a fully successful run.")
        else:
            _log("Run complete.")
        _log(f"  Instance:  {cfg.instance_id}")
        _log(f"  Runtime:   {elapsed_min} min")
        _log(f"  Results:   {cfg.local_output_dir}")
        if results_synced:
            _log(f"  Pull:      checkpoints synced to this machine; {SYNC_ACK_NAME} written on EC2")
        elif training_launched:
            _log("  Pull:      FAILED — EBS/NVMe may still hold data until you run recovery")
            _log(f"  Save id:   {_save_id_for_messages(cfg.local_output_dir)}")
        else:
            _log("  Pull:      (no training launch — nothing to sync)")
        _log(f"  Synced:    {results_synced}")
        _log("=" * 64)

        signal.signal(signal.SIGTERM, original_sigterm)
        signal.signal(signal.SIGINT, signal.SIG_DFL)
