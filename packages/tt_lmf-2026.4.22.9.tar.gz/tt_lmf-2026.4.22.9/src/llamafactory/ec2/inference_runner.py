# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""EC2 orchestration for inference sessions: chat REPL or shell payload server."""

from __future__ import annotations

import os
import shlex
import signal
import subprocess
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Optional, Union

from .config import EC2SSHSettings, ExtraUpload
from .inference_config import EC2InferencePipelineConfig
from .runner import (
    EC2TrainingError,
    _clear_remote_sync_ack,
    _log,
    _preflight_aws_credentials,
    _preflight_key_permissions,
    _rsync_extra_uploads,
    _rsync_to_ec2,
    _ssh_opts,
    _ssh_run,
    _ssh_target,
    _start_instance,
    _stop_instance,
    _wait_ssh,
    _warn,
    _write_hf_token,
    ensure_local_venv_matches_pip_spec,
)


@dataclass
class InferenceEC2ConfigBridge:
    """Duck-types ``EC2RunConfig`` for shared runner helpers (rsync, ``_ssh_run``, …).

    Implements ``ssh_settings()`` so ``_wait_ssh`` / ``wait_ssh_ready`` work after runner refactors.
    """

    instance_id: str
    private_ip: str
    key_file: str
    region: str
    ssh_user: str
    remote_repo: str
    repo_root: str
    hf_token: str
    extra_uploads: list[ExtraUpload]
    local_output_dir: str

    def ssh_settings(self) -> EC2SSHSettings:
        return EC2SSHSettings(
            instance_id=self.instance_id,
            private_ip=self.private_ip,
            key_file=self.key_file,
            region=self.region,
            ssh_user=self.ssh_user,
            remote_repo=self.remote_repo,
            local_output_dir=self.local_output_dir,
        )


def _bridge(cfg: EC2InferencePipelineConfig) -> InferenceEC2ConfigBridge:
    return InferenceEC2ConfigBridge(
        instance_id=cfg.instance_id,
        private_ip=cfg.private_ip,
        key_file=cfg.key_file,
        region=cfg.region,
        ssh_user=cfg.ssh_user,
        remote_repo=cfg.remote_repo,
        repo_root=cfg.repo_root,
        hf_token=cfg.hf_token,
        extra_uploads=cfg.extra_uploads,
        local_output_dir=cfg.local_output_dir,
    )


def _push_inference_prepare(cfg: EC2InferencePipelineConfig) -> None:
    local_script = Path(__file__).resolve().parent / "remote" / "inference_prepare.sh"
    if not local_script.is_file():
        raise EC2TrainingError(f"Bundled inference prepare script missing: {local_script}")
    remote_path = f"{cfg.remote_repo}/.lf_inference_prepare.sh"
    cmd = ["scp", *_ssh_opts(_bridge(cfg)), str(local_script), f"{_ssh_target(_bridge(cfg))}:{remote_path}"]
    subprocess.run(cmd, check=True)
    _log(f"Uploaded remote inference helper -> {remote_path}")


def _rsync_nvme_models(cfg: EC2InferencePipelineConfig) -> Optional[str]:
    """Upload weight trees to instance NVMe layout (same root as training bootstrap when NVMe exists).

    On permission or rsync failures, logs a warning and returns None so the session can continue
    without ``LF_EC2_MODEL_PATH`` (use Hub ``model_name_or_path`` or paths under the synced workspace).
    """
    if not cfg.model_syncs:
        return None

    br = _bridge(cfg)
    base = "/opt/dlami/nvme/lf-workspace/inference_models"
    base_mk = _ssh_run(br, f"mkdir -p {shlex.quote(base)}", check=False)
    if base_mk.returncode != 0:
        err = (base_mk.stderr or base_mk.stdout or "").strip()
        _warn(
            "NVMe model sync skipped: could not create remote directory "
            f"{base} (ssh exit {base_mk.returncode}).{f' {err}' if err else ''} "
            "Continuing without LF_EC2_MODEL_PATH; set model_name_or_path in your inference YAML."
        )
        return None

    ssh_arg = "ssh " + " ".join(shlex.quote(o) for o in _ssh_opts(br))
    host = _ssh_target(br)
    remote_paths: list[str] = []

    for ms in cfg.model_syncs:
        src = os.path.realpath(os.path.expanduser(ms.source))
        remote_dir = f"{base}/{ms.remote_name.strip('/')}"
        dir_mk = _ssh_run(br, f"mkdir -p {shlex.quote(remote_dir)}", check=False)
        if dir_mk.returncode != 0:
            err = (dir_mk.stderr or dir_mk.stdout or "").strip()
            _warn(
                "NVMe model sync skipped: could not create "
                f"{remote_dir} (ssh exit {dir_mk.returncode}).{f' {err}' if err else ''} "
                "Continuing without LF_EC2_MODEL_PATH."
            )
            return None
        if os.path.isdir(src):
            dest = f"{host}:{remote_dir}/"
            sync = subprocess.run(
                ["rsync", "-az", "--progress", "-e", ssh_arg, f"{src}/", dest],
                check=False,
            )
        else:
            dest = f"{host}:{remote_dir}/"
            sync = subprocess.run(
                ["rsync", "-az", "--progress", "-e", ssh_arg, src, dest],
                check=False,
            )
        if sync.returncode != 0:
            _warn(
                f"NVMe model sync skipped: rsync failed for {src!r} -> {remote_dir} "
                f"(exit {sync.returncode}). Continuing without LF_EC2_MODEL_PATH."
            )
            return None
        remote_paths.append(remote_dir)

    if len(remote_paths) == 1:
        _log(f"Single model bundle on NVMe — exporting LF_EC2_MODEL_PATH={remote_paths[0]}")
        return remote_paths[0]

    manual = ", ".join(remote_paths)
    _log("Multiple model_syncs — set model_name_or_path in your inference YAML to one of:")
    _log(f"  {manual}")
    return None


def _stop_bridge(cfg: EC2InferencePipelineConfig) -> SimpleNamespace:
    after = cfg.after_training
    if not cfg.auto_shutdown_after_training:
        after = "nothing"
    return SimpleNamespace(instance_id=cfg.instance_id, region=cfg.region, after_training=after)


def _launch_http_server(cfg: EC2InferencePipelineConfig, model_override: str | None) -> None:
    br = _bridge(cfg)
    prep_q = shlex.quote(f"{cfg.remote_repo}/.lf_inference_prepare.sh")
    remote_repo_q = shlex.quote(cfg.remote_repo)
    infer_rel_q = shlex.quote(cfg.inference_config)

    parts = [f"chmod +x {prep_q}"]
    pip_spec = cfg.remote_pip_spec.strip()
    if pip_spec:
        parts.append(f"export LF_REMOTE_PACKAGE_SPEC={shlex.quote(pip_spec)}")
    if model_override:
        parts.append(f"export LF_EC2_MODEL_PATH={shlex.quote(model_override)}")
    parts.append("export LF_EC2_INFERENCE_MODE=http")
    parts.append(f"export LF_EC2_BACKEND_PROFILE={shlex.quote(cfg.backend_profile)}")
    parts.append(f"export LF_EC2_SERVER_HOST={shlex.quote(cfg.server_host)}")
    parts.append(f"export LF_EC2_SERVER_PORT={cfg.server_port}")
    parts.append(f"export LF_EC2_SERVER_READY_TIMEOUT_SEC={cfg.server_ready_timeout_sec}")
    if cfg.server_api_keys_file.strip():
        parts.append(f"export LF_EC2_SERVER_API_KEYS_FILE={shlex.quote(cfg.server_api_keys_file.strip())}")
    if cfg.server_vllm_api_key.strip():
        parts.append(f"export LF_EC2_VLLM_API_KEY={shlex.quote(cfg.server_vllm_api_key.strip())}")
    if cfg.server_vllm_pip_spec.strip():
        parts.append(f"export LF_VLLM_PIP_SPEC={shlex.quote(cfg.server_vllm_pip_spec.strip())}")
    if cfg.server_vllm_use_v1 is not None:
        parts.append(f"export LF_VLLM_USE_V1={1 if cfg.server_vllm_use_v1 else 0}")
    parts.append(f"exec bash {prep_q} {remote_repo_q} {infer_rel_q}")
    remote_line = " && ".join(parts)

    result = _ssh_run(br, remote_line, check=False)
    if result.returncode != 0:
        output = (result.stderr or result.stdout or "").strip()
        raise EC2TrainingError(
            f"Remote server bootstrap failed with exit {result.returncode}"
            + (f": {output}" if output else ".")
        )
    if result.stdout.strip():
        _log(result.stdout.strip())


def run_ec2_inference(config: Union[EC2InferencePipelineConfig, str, Path]) -> int:
    if isinstance(config, (str, Path)):
        config = EC2InferencePipelineConfig.from_yaml(config)

    cfg = config
    cfg.validate()

    br = _bridge(cfg)
    instance_started = False
    original_sigterm = signal.getsignal(signal.SIGTERM)

    def _sigterm_handler(signum, frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, _sigterm_handler)

    _log("=" * 64)
    _log("LlamaFactory EC2 inference (http mode)")
    _log(f"  Instance:  {cfg.instance_id} ({cfg.private_ip})")
    _log(f"  Inference: {cfg.inference_config}")
    _log(f"  Backend:   {cfg.backend_profile}")
    _log(f"  After:     {cfg.after_training} (auto_shutdown={cfg.auto_shutdown_after_training})")
    _log("=" * 64)

    try:
        ensure_local_venv_matches_pip_spec(cfg.remote_pip_spec, cfg.repo_root)
        _preflight_aws_credentials(br)
        _preflight_key_permissions(br)
        _start_instance(br)
        instance_started = True
        _wait_ssh(br)
        _clear_remote_sync_ack(br)
        _rsync_to_ec2(br)
        _rsync_extra_uploads(br)
        model_override = _rsync_nvme_models(cfg)
        _push_inference_prepare(cfg)
        _write_hf_token(br)
        _launch_http_server(cfg, model_override)
        bind_host = cfg.server_host
        _log(f"HTTP inference server started at {bind_host}:{cfg.server_port} on EC2.")
        _log("Use lifecycle.after_training=nothing (or auto_shutdown_after_training=false) to keep the instance up.")
        return 0

    except (KeyboardInterrupt, SystemExit):
        _warn("Local interrupt — closing SSH and applying lifecycle.after_training policy.")
        raise

    except EC2TrainingError:
        raise

    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        if instance_started:
            _stop_instance(_stop_bridge(cfg))
        signal.signal(signal.SIGTERM, original_sigterm)


__all__ = ["run_ec2_inference"]
