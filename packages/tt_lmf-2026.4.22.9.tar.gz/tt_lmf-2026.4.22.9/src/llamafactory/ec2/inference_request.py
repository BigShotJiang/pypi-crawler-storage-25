# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Send one prompt to the HTTP chat inference server."""

from __future__ import annotations

import argparse
import json
import urllib.error
import urllib.request
from pathlib import Path

import yaml


def _load_endpoint_from_pipeline(path: str) -> tuple[str, int]:
    cfg_path = Path(path).expanduser().resolve()
    with open(cfg_path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Pipeline YAML must be a mapping: {cfg_path}")
    infer = data.get("inference", {})
    if not isinstance(infer, dict):
        infer = {}
    host = str(infer.get("host", "127.0.0.1") or "127.0.0.1").strip()
    public = infer.get("public", False)
    if isinstance(public, str):
        public = public.lower() in ("1", "true", "yes")
    if public:
        host = "127.0.0.1"
    port = int(infer.get("port", 8000) or 8000)
    return host, port


def request(prompt: str, host: str, port: int, timeout_sec: int, api_key: str | None = None) -> int:
    payload = {"prompt": prompt}
    url = f"http://{host}:{port}/chat"
    req = urllib.request.Request(
        url=url,
        method="POST",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")

    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            if resp.status != 200:
                print(f"ERROR: HTTP {resp.status}")
                return 1
            for raw in resp:
                line = raw.decode("utf-8", errors="replace").strip()
                if not line or not line.startswith("data: "):
                    continue
                payload_line = line[6:]
                if payload_line == "[DONE]":
                    print("")
                    return 0
                try:
                    chunk = json.loads(payload_line)
                except json.JSONDecodeError:
                    continue
                if "error" in chunk:
                    print(f"ERROR: {chunk['error']}")
                    return 1
                token = chunk.get("token")
                if isinstance(token, str):
                    print(token, end="", flush=True)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace").strip()
        print(f"ERROR: HTTP {e.code} {detail}")
        return 1
    except urllib.error.URLError as e:
        print(f"ERROR: {e.reason}")
        return 1
    return 1


def main() -> None:
    parser = argparse.ArgumentParser(description="Send one prompt to the HTTP chat inference server.")
    parser.add_argument("--prompt", required=True, help="User prompt payload")
    parser.add_argument(
        "--pipeline-config",
        help="Optional EC2 inference pipeline YAML; when set, host/port are read from inference.host/port.",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--timeout-sec", type=int, default=600)
    parser.add_argument("--api-key", default="", help="Optional API key for Authorization: Bearer <key>")
    args = parser.parse_args()
    host = args.host
    port = args.port
    if args.pipeline_config:
        host, port = _load_endpoint_from_pipeline(args.pipeline_config)
    raise SystemExit(request(args.prompt, host, port, args.timeout_sec, args.api_key.strip() or None))


if __name__ == "__main__":
    main()
