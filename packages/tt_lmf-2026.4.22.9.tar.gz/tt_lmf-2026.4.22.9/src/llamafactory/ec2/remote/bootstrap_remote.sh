#!/usr/bin/env bash
# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# ================================================================
# bootstrap_remote.sh — Runs ON the EC2 instance (uploaded by llamafactory.ec2 runner)
#
# Works with a **workspace directory** (Orbi bundle layout): data/, YAML, etc.
# Does NOT require a full LlamaFactory git checkout when LF_REMOTE_PACKAGE_SPEC
# is set to the same pip/uv spec you installed on your laptop (git URL, version, etc.).
#
# USAGE: bash .lf_bootstrap.sh <workspace_dir> <training_config_relative>
#
# ENV (set by orchestrator):
#   LF_REMOTE_PACKAGE_SPEC  — if non-empty: pip install -U "$LF_REMOTE_PACKAGE_SPEC"
#                             else if workspace has pyproject.toml: pip install -e "$WORKSPACE"
#                             else: fail
# ================================================================

set -euo pipefail

WORK_DIR="${1:?Error: workspace_dir required. Usage: $0 <workspace_dir> <training_config_relative>}"
TRAIN_REL="${2:?Error: training_config_relative required}"

LOG_FILE="${WORK_DIR}/training.log"
STATUS_FILE="${WORK_DIR}/training_status"
TRAIN_CFG_ABS="${WORK_DIR}/${TRAIN_REL}"

exec > >(tee -a "$LOG_FILE") 2>&1

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

log "================================================================"
log "LlamaFactory EC2 bootstrap (package / workspace mode)"
log "Workspace: $WORK_DIR"
log "Config:    $TRAIN_REL -> $TRAIN_CFG_ABS"
log "Host:      $(hostname)"
log "================================================================"

echo "RUNNING" > "$STATUS_FILE"

trap_handler() {
    local exit_code=$?
    if [ "$exit_code" -ne 0 ]; then
        log "Bootstrap exited unexpectedly with code $exit_code"
        echo "FAILED:${exit_code}" > "$STATUS_FILE"
    fi
}
trap trap_handler EXIT

if ! command -v tmux &>/dev/null; then
    log "ERROR: tmux not found. Install with: sudo apt-get install -y tmux"
    echo "FAILED:1" > "$STATUS_FILE"
    exit 1
fi

log "Checking GPU..."
if ! command -v nvidia-smi &>/dev/null; then
    log "ERROR: nvidia-smi not found."
    echo "FAILED:1" > "$STATUS_FILE"
    exit 1
fi

nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader | \
    while IFS=',' read -r name vram driver; do
        log "GPU: ${name} | VRAM: ${vram} | Driver: ${driver}"
    done

VENV_DIR="${HOME}/llamafactory-venv"
if [ ! -f "${VENV_DIR}/bin/activate" ]; then
    log "ERROR: venv not found at ${VENV_DIR}. Run instance setup first."
    echo "FAILED:1" > "$STATUS_FILE"
    exit 1
fi
# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"
log "Activated venv: ${VENV_DIR} ($(python3 --version))"

# If a legacy "llamafactory" wheel exists in site-packages, it can shadow editable
# installs from this workspace and hide newer modules. Remove it proactively.
if python3 -m pip show llamafactory >/dev/null 2>&1; then
    log "Removing legacy site-packages distribution: llamafactory"
    python3 -m pip uninstall -y llamafactory >/dev/null 2>&1 || true
fi

PIP_STAMP_PY="${WORK_DIR}/src/llamafactory/ec2/pip_stamp.py"
NVME_BASE="/opt/dlami/nvme"
NVME_WORKSPACE=""
if [ -d "$NVME_BASE" ] && df "$NVME_BASE" >/dev/null 2>&1; then
    NVME_WORKSPACE="${NVME_BASE}/lf-workspace"
    CACHE_ROOT="${NVME_WORKSPACE}/runtime-cache"
    TMP_ROOT="${NVME_WORKSPACE}/tmp"
    mkdir -p \
        "${CACHE_ROOT}/xdg" \
        "${CACHE_ROOT}/huggingface" \
        "${CACHE_ROOT}/huggingface/hub" \
        "${CACHE_ROOT}/huggingface/assets" \
        "${CACHE_ROOT}/pip" \
        "${CACHE_ROOT}/triton" \
        "${CACHE_ROOT}/torchinductor" \
        "${CACHE_ROOT}/xet" \
        "${TMP_ROOT}"
    export TMPDIR="${TMP_ROOT}"
    export TEMP="${TMP_ROOT}"
    export TMP="${TMP_ROOT}"
    export XDG_CACHE_HOME="${CACHE_ROOT}/xdg"
    export HF_HOME="${CACHE_ROOT}/huggingface"
    export HF_HUB_CACHE="${CACHE_ROOT}/huggingface/hub"
    export HF_ASSETS_CACHE="${CACHE_ROOT}/huggingface/assets"
    export HF_XET_CACHE="${CACHE_ROOT}/xet"
    export TRANSFORMERS_CACHE="${CACHE_ROOT}/huggingface/hub"
    export PIP_CACHE_DIR="${CACHE_ROOT}/pip"
    export TRITON_CACHE_DIR="${CACHE_ROOT}/triton"
    export TORCHINDUCTOR_CACHE_DIR="${CACHE_ROOT}/torchinductor"
    log "NVMe cache mode enabled: ${CACHE_ROOT} (free: $(df -h "$NVME_BASE" | awk 'NR==2{print $4}'))"
else
    log "WARN: NVMe not found at ${NVME_BASE}; cache/temp will use root EBS."
fi

log "Installing LlamaFactory on instance..."
if [ -n "${LF_REMOTE_PACKAGE_SPEC:-}" ]; then
    _run_lf_pip=1
    if [ -f "$PIP_STAMP_PY" ] && skip_msg="$(python3 "$PIP_STAMP_PY" check "$WORK_DIR" "${LF_REMOTE_PACKAGE_SPEC:-}")"; then
        log "$skip_msg"
        _run_lf_pip=0
    fi

    if [ "$_run_lf_pip" -eq 1 ]; then
    log "  pip install from package spec (LF_REMOTE_PACKAGE_SPEC)"

    # Detect the CUDA version the driver actually supports (from nvidia-smi header),
    # NOT what torch was compiled against — these can differ if torch was previously
    # installed for a newer CUDA than the driver supports (e.g. cu128 on driver 550
    # which only supports CUDA 12.4). Using the driver-reported version ensures pip
    # picks a wheel that is actually compatible at runtime.
    # nvidia-smi header line: "| CUDA Version: 12.4     |"
    # The field after "Version:" may have trailing spaces/pipes; extract just the number.
    DRIVER_CUDA_VER=$(nvidia-smi | grep -oP 'CUDA Version:\s*\K[0-9]+\.[0-9]+' | head -1)
    if [ -n "$DRIVER_CUDA_VER" ]; then
        # Convert "12.4" -> "cu124", "12.8" -> "cu128", etc.
        TORCH_CUDA_TAG="cu$(echo "$DRIVER_CUDA_VER" | tr -d '.')"
        log "  Driver supports CUDA ${DRIVER_CUDA_VER} — using wheel index: ${TORCH_CUDA_TAG}"
    else
        # Fallback: read from existing torch installation
        TORCH_CUDA_TAG=$(python3 -c "
import torch, sys
v = getattr(torch.version, 'cuda', None)
if v:
    print('cu' + v.replace('.', ''))
else:
    print('')
" 2>/dev/null || echo "")
        if [ -n "$TORCH_CUDA_TAG" ]; then
            log "  WARN: nvidia-smi CUDA parse failed — falling back to torch compiled tag: ${TORCH_CUDA_TAG}"
        fi
    fi

    if [ -n "$TORCH_CUDA_TAG" ]; then
        EXTRA_INDEX="--extra-index-url https://download.pytorch.org/whl/${TORCH_CUDA_TAG}"
    else
        log "  WARN: Could not detect CUDA tag — using default PyPI index"
        log "  If torchaudio/torchvision fail with libcudart errors, set TORCH_CUDA_TAG manually."
        EXTRA_INDEX=""
    fi

    # Force-reinstall the root pip spec every time for PyPI (tt-lmf); pip_stamp skips only
    # VCS unchanged-SHA and editable unchanged-fingerprint cases. Then a second pass resolves deps.
    # shellcheck disable=SC2086
    pip install -U --no-cache-dir --force-reinstall --no-deps $EXTRA_INDEX \
        "$LF_REMOTE_PACKAGE_SPEC" 2>&1 | tail -20
    # shellcheck disable=SC2086
    pip install -U --no-cache-dir --upgrade-strategy only-if-needed $EXTRA_INDEX \
        "$LF_REMOTE_PACKAGE_SPEC" 2>&1 | tail -20
    if [ -f "$PIP_STAMP_PY" ]; then
        python3 "$PIP_STAMP_PY" write-stamp "$WORK_DIR" "${LF_REMOTE_PACKAGE_SPEC:-}" || log "  WARN: could not write pip stamp"
    fi
    fi

elif [ -f "${WORK_DIR}/pyproject.toml" ]; then
    _run_lf_pip=1
    if [ -f "$PIP_STAMP_PY" ] && skip_msg="$(python3 "$PIP_STAMP_PY" check "$WORK_DIR")"; then
        log "$skip_msg"
        _run_lf_pip=0
    fi
    if [ "$_run_lf_pip" -eq 1 ]; then
    log "  pip install -e from workspace (legacy dev layout, force-reinstall)"
    pip install -U --no-cache-dir --force-reinstall --no-deps -e "$WORK_DIR" -q 2>&1 | tail -10
    pip install -U --no-cache-dir --upgrade-strategy only-if-needed -e "$WORK_DIR" -q 2>&1 | tail -10
    if [ -f "$PIP_STAMP_PY" ]; then
        python3 "$PIP_STAMP_PY" write-stamp "$WORK_DIR" || log "  WARN: could not write pip stamp"
    fi
    fi
else
    log "ERROR: No LF_REMOTE_PACKAGE_SPEC and no pyproject.toml in workspace."
    log "  Set package.pip_spec in your EC2 pipeline YAML,"
    log "  or pass EC2RunConfig.remote_pip_spec from Python."
    echo "FAILED:1" > "$STATUS_FILE"
    exit 1
fi

log "Verifying package imports before training..."
python3 - <<'PYCHECK'
import sys
failures = []

try:
    import torch
    cuda_ok = torch.cuda.is_available()
    cuda_tag = "cu" + (torch.version.cuda or "").replace(".", "")
except ImportError as e:
    failures.append(f"torch import failed: {e}")
    torch = None
    cuda_ok = False
    cuda_tag = "unknown"

try:
    import torchaudio
except OSError as e:
    failures.append(
        f"torchaudio load failed (CUDA version mismatch): {e}\n"
        f"  Installed torch CUDA: {cuda_tag}\n"
        f"  Fix: pip install torchaudio --index-url https://download.pytorch.org/whl/{cuda_tag}"
    )
except ImportError as e:
    failures.append(f"torchaudio import failed: {e}")

try:
    import llamafactory
except ImportError as e:
    failures.append(f"llamafactory import failed: {e}")

if failures:
    for f in failures:
        print(f"  IMPORT ERROR: {f}", file=sys.stderr)
    sys.exit(1)

if not cuda_ok:
    print("  ERROR: PyTorch cannot see CUDA.", file=sys.stderr)
    sys.exit(3)

device = torch.cuda.get_device_properties(0)
vram_gb = device.total_memory / 1024**3
print(f"  CUDA device: {device.name}")
print(f"  VRAM: {vram_gb:.1f} GB")
print(f"  Compute capability: sm_{device.major}{device.minor}")
print(f"  PyTorch: {torch.__version__}")
print(f"  torchaudio: {torchaudio.__version__}")
PYCHECK

if [ $? -ne 0 ]; then
    log "ERROR: Import verification failed — see errors above."
    log "  Most common cause: torchaudio compiled for wrong CUDA version."
    log "  To fix on the instance:"
    log "    source ~/llamafactory-venv/bin/activate"
    log "    pip cache purge"
    log "    CUDA_TAG=$(python3 -c \"import torch; print('cu'+torch.version.cuda.replace('.',''))\")"
    log "    pip install --force-reinstall torch torchaudio --index-url https://download.pytorch.org/whl/\$CUDA_TAG"
    echo "FAILED:1" > "$STATUS_FILE"
    exit 1
fi

log "LlamaFactory ready."

HF_TOKEN_FILE="${WORK_DIR}/.hf_token"
if [ -z "${HF_TOKEN:-}" ] && [ -f "$HF_TOKEN_FILE" ]; then
    HF_TOKEN=$(cat "$HF_TOKEN_FILE")
    rm -f "$HF_TOKEN_FILE"
fi
if [ -n "${HF_TOKEN:-}" ]; then
    export HF_TOKEN
    log "HuggingFace token exported (used automatically by transformers/huggingface_hub)."
fi

# ── NVMe workspace (fast I/O for checkpoints) ────────────────────
if [ -d "$NVME_BASE" ] && df "$NVME_BASE" >/dev/null 2>&1; then
    mkdir -p "${NVME_WORKSPACE}/saves"
    log "NVMe detected at ${NVME_BASE} ($(df -h "$NVME_BASE" | awk 'NR==2{print $4}') free)"

    if [ -L "${WORK_DIR}/saves" ]; then
        log "  saves/ symlink already exists -> $(readlink "${WORK_DIR}/saves")"
    else
        rm -rf "${WORK_DIR}/saves"
        ln -s "${NVME_WORKSPACE}/saves" "${WORK_DIR}/saves"
        log "  saves/ -> ${NVME_WORKSPACE}/saves (symlinked to NVMe)"
    fi
else
    log "WARN: NVMe instance store not found at ${NVME_BASE} — using EBS for saves/"
fi

if [ ! -f "$TRAIN_CFG_ABS" ]; then
    log "ERROR: Training config not found: $TRAIN_CFG_ABS"
    echo "FAILED:1" > "$STATUS_FILE"
    exit 1
fi

log "================================================================"
log "Starting training: $TRAIN_CFG_ABS"
log "================================================================"

cd "$WORK_DIR"
GPU_COUNT=$(nvidia-smi --list-gpus | wc -l)
log "Detected ${GPU_COUNT} GPU(s) — llamafactory-cli train (launcher auto-detects GPUs)"
# Do NOT wrap in torchrun — llamafactory's launcher.py detects multi-GPU and
# calls torchrun internally. Wrapping causes double-torchrun → NCCL conflict.
set +e
WANDB_DISABLED=true llamafactory-cli train "$TRAIN_CFG_ABS"
TRAIN_EXIT=$?
set -e

log "================================================================"
log "Training exit code: $TRAIN_EXIT"
log "================================================================"

trap - EXIT

SAVES_DIR="${WORK_DIR}/saves"
EBS_SAVES_DIR="${WORK_DIR}/saves_ebs_backup"
if [ -n "$NVME_WORKSPACE" ] && [ -L "${WORK_DIR}/saves" ] && [ -d "$SAVES_DIR" ] && [ "$(ls -A "$SAVES_DIR" 2>/dev/null)" ]; then
    log "Copying saves from NVMe to EBS backup (before signalling orchestrator)..."
    mkdir -p "$EBS_SAVES_DIR"
    rsync -a --delete "${SAVES_DIR}/" "${EBS_SAVES_DIR}/"
    log "NVMe saves copied to EBS: ${EBS_SAVES_DIR} ($(du -sh "$EBS_SAVES_DIR" | awk '{print $1}'))"
fi

# Write training_status AFTER the NVMe→EBS copy so the orchestrator's rsync
# never races with the copy — it only starts pulling once saves/ is safely on EBS.
if [ "$TRAIN_EXIT" -eq 0 ]; then
    log "Training SUCCEEDED"
    echo "SUCCESS:0" > "$STATUS_FILE"
else
    log "Training FAILED (exit code: $TRAIN_EXIT)"
    echo "FAILED:${TRAIN_EXIT}" > "$STATUS_FILE"
fi

_archive_src="$SAVES_DIR"
if [ -d "$EBS_SAVES_DIR" ] && [ "$(ls -A "$EBS_SAVES_DIR" 2>/dev/null)" ]; then
    _archive_src="$EBS_SAVES_DIR"
fi
_archive=""
if [ -d "$_archive_src" ] && [ "$(ls -A "$_archive_src" 2>/dev/null)" ]; then
    _archive="saves_checkpoint_$(date +%Y%m%d_%H%M%S).tar.gz"
    _avail_mb=$(df -m "$WORK_DIR" | awk 'NR==2{print $4}')
    _saves_mb=$(du -sm "$_archive_src" | awk '{print $1}')
    if [ "$_avail_mb" -gt $((_saves_mb + 1024)) ]; then
        log "Compressing checkpoint to EBS: ${_archive}..."
        tar czf "${WORK_DIR}/${_archive}" -C "$_archive_src" .
        log "Checkpoint archived: ${WORK_DIR}/${_archive} ($(du -h "${WORK_DIR}/${_archive}" | awk '{print $1}'))"
    else
        log "WARN: Not enough EBS space to compress (${_avail_mb}MB free, saves=${_saves_mb}MB)."
        _archive=""
    fi
else
    log "No saves/ directory to compress."
fi

_after="${AFTER_TRAINING:-stop}"
_after_lc=$(echo "$_after" | tr '[:upper:]' '[:lower:]')
_auto="${AUTO_SHUTDOWN_AFTER_TRAINING:-0}"
case "$_auto" in 1|true|yes) _auto=1 ;; *) _auto=0 ;; esac
SYNC_ACK_FILE="${WORK_DIR}/.ec2_results_sync_ack"

_do_halt() {
    log "Initiating halt (sudo shutdown -h now)..."
    if sudo -n shutdown -h now 2>/dev/null; then
        :
    else
        log "WARN: passwordless sudo for shutdown not available — stop the instance in AWS Console."
    fi
}

if [ "$_auto" -eq 1 ] && [ "$_after_lc" != "nothing" ] && [ "$_after_lc" != "none" ]; then
    _grace="${AUTO_SHUTDOWN_GRACE_SEC:-900}"
    case "$_grace" in
        ''|*[!0-9]*) _grace=900 ;;
    esac
    rm -f "$SYNC_ACK_FILE"
    _interval=30
    _elapsed=0
    log "================================================================"
    log "Auto-shutdown enabled: waiting up to ${_grace}s for results sync ack."
    log "  Checkpoint preserved on EBS: ${_archive:-'(saves/ on EBS)'}"
    log "================================================================"
    while [ "$_elapsed" -lt "$_grace" ]; do
        if [ -f "$SYNC_ACK_FILE" ]; then
            log "Sync ack received — results pulled successfully."
            rm -f "$SYNC_ACK_FILE"
            _do_halt
            exit "$TRAIN_EXIT"
        fi
        sleep "$_interval"
        _elapsed=$((_elapsed + _interval))
    done
    log "No sync ack within ${_grace}s — halting with checkpoint preserved on EBS."
    _do_halt
fi

exit "$TRAIN_EXIT"
