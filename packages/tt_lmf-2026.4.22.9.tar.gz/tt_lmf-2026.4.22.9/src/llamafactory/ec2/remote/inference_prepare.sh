#!/usr/bin/env bash
# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# On EC2: align venv with package.pip_spec (same as clients), then launch HTTP inference server in tmux.
# Args: <workspace_dir> <inference_yaml_relative_to_workspace>
#
# Env:
#   LF_REMOTE_PACKAGE_SPEC — identical pip requirement clients use (see package.pip_spec).
#                            When set: force-reinstall root + deps pass (parity with bootstrap_remote.sh).
#   HF_TOKEN               — optional; pipeline may write .hf_token on workspace
#   LF_EC2_INFERENCE_MODE  — http (default)
#   LF_EC2_SERVER_HOST     — HTTP bind host (default: 127.0.0.1)
#   LF_EC2_SERVER_PORT     — HTTP bind port (default: 8000)
#   LF_EC2_SERVER_API_KEYS_FILE — optional API key store path on EC2
#   LF_EC2_BACKEND_PROFILE     — vllm (default) or hf; see inference YAML inference.backend_profile
#   LF_EC2_VLLM_API_KEY        — optional; vLLM reads from env (not argv)
#   LF_VLLM_PIP_SPEC           — pip requirement for vLLM when backend is vllm (default: vllm on host; orchestrator often sets vllm==0.8.5 + cu124)
#                                to match your torch/CUDA. Installed only after the torch stack is driver-aligned.
#   LF_VLLM_FORCE_REINSTALL   — if 1, always run pip install for vLLM (ignore skip-if-OK), e.g. when bumping vllm_pip_spec.
#                                Default 0: skip expensive reinstall when torch matches driver and vllm._C already loads.
#   LF_VLLM_TRANSFORMERS_PIP_SPEC — optional pip spec(s) to enforce when backend=vllm.
#                                Default: "transformers>=4.51.1,<5,!=4.57.0" (vLLM 0.8.x compatibility).
#   LF_HF_TRANSFORMERS_PIP_SPEC   — optional pip spec(s) to enforce when backend=hf.
#                                Default: auto-detect by model_name_or_path; for gemma4 installs
#                                "transformers>=5.5.0 tokenizers>=0.22.0", otherwise no action.
#   VLLM_USE_V1 / LF_VLLM_USE_V1 — v0.8+ uses V1 engine by default. V1 pulls flashinfer/torch_c_dlpack_ext, whose wheels can
#                                OSError (undefined c10::Device symbols) against the same venv’s torch. We default VLLM_USE_V1=0
#                                in the server process. Set LF_VLLM_USE_V1=1 when your torch + extensions are a clean pair.
#   PIP cache: large wheels (torch, vllm) reuse pip’s download cache. NVMe/EBS branches set PIP_CACHE_DIR; when neither
#              runs, PIP_CACHE_DIR falls back to ~/.cache/pip. (Previously every pip used --no-cache-dir and re-fetched.)
#   LF_PIP_NO_CACHE         — if 1, add --no-cache-dir to all pip install lines (CI/repro “cold” install).

set -euo pipefail

WORK_DIR="${1:?workspace dir required}"
INFER_REL="${2:?inference yaml path relative to workspace required}"

VENV_DIR="${HOME}/llamafactory-venv"
if [ ! -f "${VENV_DIR}/bin/activate" ]; then
  echo "ERROR: venv not found at ${VENV_DIR}. Use the same EC2 image/setup as training." >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

PIP_COLD_FLAGS=()
if [ "${LF_PIP_NO_CACHE:-0}" = "1" ]; then
  PIP_COLD_FLAGS=(--no-cache-dir)
fi

PIP_STAMP_PY="${WORK_DIR}/src/llamafactory/ec2/pip_stamp.py"

# If a legacy "llamafactory" wheel exists in site-packages, it can shadow editable
# installs from this workspace and hide newly added modules. Remove it proactively.
if python3 -m pip show llamafactory >/dev/null 2>&1; then
  echo "[inference_prepare] Removing legacy site-packages distribution: llamafactory"
  python3 -m pip uninstall -y llamafactory >/dev/null 2>&1 || true
fi

# Put runtime caches / temp files on NVMe when available so root EBS only keeps
# repo + venv (persistent essentials). Inference model caches are safe on ephemeral NVMe.
# If NVMe exists but is not writable, fall back to a tree under ~/.cache (EBS) instead of aborting.
NVME_BASE="/opt/dlami/nvme"
CACHE_ROOT=""
TMP_ROOT=""

_set_cache_exports() {
  export TMPDIR="${TMP_ROOT}"
  export TEMP="${TMP_ROOT}"
  export TMP="${TMP_ROOT}"
  export XDG_CACHE_HOME="${CACHE_ROOT}/xdg"
  export HF_HOME="${CACHE_ROOT}/huggingface"
  export HF_HUB_CACHE="${CACHE_ROOT}/huggingface/hub"
  export HF_ASSETS_CACHE="${CACHE_ROOT}/huggingface/assets"
  export HF_XET_CACHE="${CACHE_ROOT}/xet"
  # Do not set TRANSFORMERS_CACHE (deprecated in HF 4.57+); HF_HOME/HF_HUB_CACHE above are enough.
  export PIP_CACHE_DIR="${CACHE_ROOT}/pip"
  export TRITON_CACHE_DIR="${CACHE_ROOT}/triton"
  export TORCHINDUCTOR_CACHE_DIR="${CACHE_ROOT}/torchinductor"
}

_mkdir_cache_tree() {
  mkdir -p \
    "${CACHE_ROOT}/xdg" \
    "${CACHE_ROOT}/huggingface" \
    "${CACHE_ROOT}/huggingface/hub" \
    "${CACHE_ROOT}/huggingface/assets" \
    "${CACHE_ROOT}/pip" \
    "${CACHE_ROOT}/triton" \
    "${CACHE_ROOT}/torchinductor" \
    "${CACHE_ROOT}/xet" \
    "${TMP_ROOT}"
}

if [ -d "$NVME_BASE" ] && df "$NVME_BASE" >/dev/null 2>&1; then
  _nvme_ws="${NVME_BASE}/lf-workspace"
  CACHE_ROOT="${_nvme_ws}/runtime-cache"
  TMP_ROOT="${_nvme_ws}/tmp"
  if _mkdir_cache_tree; then
    _set_cache_exports
    echo "[inference_prepare] NVMe cache mode: ${CACHE_ROOT} (free: $(df -h "$NVME_BASE" | awk 'NR==2{print $4}'))"
  else
    echo "[inference_prepare] WARN: NVMe at ${NVME_BASE} is present but not writable (cannot create ${CACHE_ROOT}). Skipping NVMe cache; using EBS-backed cache at ${HOME}/.cache/lf-inference-runtime." >&2
    CACHE_ROOT="${HOME}/.cache/lf-inference-runtime"
    TMP_ROOT="${CACHE_ROOT}/tmp"
    if ! _mkdir_cache_tree; then
      echo "ERROR: NVMe cache was skipped but EBS fallback cache could not be created at ${CACHE_ROOT}." >&2
      exit 1
    fi
    _set_cache_exports
    echo "[inference_prepare] EBS cache mode (NVMe skipped): ${CACHE_ROOT}"
  fi
else
  echo "[inference_prepare] WARN: NVMe not found at ${NVME_BASE}; cache/temp will use root EBS." >&2
  if [ -z "${PIP_CACHE_DIR:-}" ]; then
    PIP_CACHE_DIR="${HOME}/.cache/pip"
    mkdir -p "${PIP_CACHE_DIR}"
    export PIP_CACHE_DIR
    echo "[inference_prepare] pip download cache: ${PIP_CACHE_DIR}"
  fi
fi

DRIVER_CUDA_VER=$(nvidia-smi 2>/dev/null | grep -oP 'CUDA Version:\s*\K[0-9]+\.[0-9]+' | head -1 || true)
if [ -n "${DRIVER_CUDA_VER}" ]; then
  TORCH_CUDA_TAG="cu$(echo "${DRIVER_CUDA_VER}" | tr -d '.')"
  EXTRA_INDEX=(--extra-index-url "https://download.pytorch.org/whl/${TORCH_CUDA_TAG}")
else
  TORCH_CUDA_TAG=$(python3 -c "
import torch
v = getattr(torch.version, 'cuda', None)
if v:
    print('cu' + v.replace('.', ''))
" 2>/dev/null || true)
  if [ -n "${TORCH_CUDA_TAG}" ]; then
    echo "[inference_prepare] WARN: nvidia-smi CUDA parse failed; falling back to torch CUDA tag: ${TORCH_CUDA_TAG}" >&2
    EXTRA_INDEX=(--extra-index-url "https://download.pytorch.org/whl/${TORCH_CUDA_TAG}")
  else
    echo "[inference_prepare] WARN: Could not detect CUDA tag; using default PyPI index." >&2
    EXTRA_INDEX=()
  fi
fi

# Same policy as training: when package.pip_spec is set, force-reinstall root spec then resolve deps
# (matches client ensure_local_venv_matches_pip_spec + bootstrap_remote.sh). For PyPI tt-lmf specs,
# pip_stamp never skips (see pip_install_needed) so every run upgrades to the latest matching release.
if [ -n "${LF_REMOTE_PACKAGE_SPEC:-}" ]; then
  _run_lf_pip=1
  if [ -f "$PIP_STAMP_PY" ] && skip_msg="$(python3 "$PIP_STAMP_PY" check "$WORK_DIR" "${LF_REMOTE_PACKAGE_SPEC:-}")"; then
    echo "[inference_prepare] ${skip_msg}"
    _run_lf_pip=0
  fi
  if [ "$_run_lf_pip" -eq 1 ]; then
    echo "[inference_prepare] pip force-reinstall from LF_REMOTE_PACKAGE_SPEC (client + EC2 use same spec)..."
    # shellcheck disable=SC2068,SC2086
    pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --force-reinstall --no-deps ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      "${LF_REMOTE_PACKAGE_SPEC}" 2>&1 | tail -40
    # shellcheck disable=SC2068,SC2086
    pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --upgrade-strategy only-if-needed ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      "${LF_REMOTE_PACKAGE_SPEC}" 2>&1 | tail -40
    if [ -f "$PIP_STAMP_PY" ]; then
      python3 "$PIP_STAMP_PY" write-stamp "$WORK_DIR" "${LF_REMOTE_PACKAGE_SPEC:-}" || true
    fi
  fi
elif [ -f "${WORK_DIR}/pyproject.toml" ]; then
  _run_lf_pip=1
  if [ -f "$PIP_STAMP_PY" ] && skip_msg="$(python3 "$PIP_STAMP_PY" check "$WORK_DIR")"; then
    echo "[inference_prepare] ${skip_msg}"
    _run_lf_pip=0
  fi
  if [ "$_run_lf_pip" -eq 1 ]; then
    echo "[inference_prepare] No package.pip_spec — pip install -e from synced workspace..."
    # shellcheck disable=SC2068,SC2086
    pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --force-reinstall --no-deps ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      -e "$WORK_DIR" 2>&1 | tail -40
    # shellcheck disable=SC2068,SC2086
    pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --upgrade-strategy only-if-needed ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      -e "$WORK_DIR" 2>&1 | tail -40
    if [ -f "$PIP_STAMP_PY" ]; then
      python3 "$PIP_STAMP_PY" write-stamp "$WORK_DIR" || true
    fi
  fi
elif ! python3 -c "import llamafactory.chat.chat_server, llamafactory.ec2.inference_server" 2>/dev/null; then
  echo "ERROR: inference modules missing and no package.pip_spec." >&2
  echo "  Set package.pip_spec in the pipeline YAML (same string clients use with pip install -U)" >&2
  echo "  or sync a workspace that contains pyproject.toml." >&2
  exit 1
fi

# Ensure torch stack matches the CUDA capability exposed by the EC2 driver.
# package.pip_spec may keep a newer incompatible torch around (>= constraint),
# so we force-reinstall torch/torchaudio/torchvision when compiled CUDA tag differs.
if [ -n "${TORCH_CUDA_TAG:-}" ]; then
  INSTALLED_TORCH_CUDA_TAG=$(python3 -c "
import torch
v = getattr(torch.version, 'cuda', None)
print('cu' + v.replace('.', '') if v else '')
" 2>/dev/null || true)
  if [ -z "${INSTALLED_TORCH_CUDA_TAG}" ] || [ "${INSTALLED_TORCH_CUDA_TAG}" != "${TORCH_CUDA_TAG}" ]; then
    echo "[inference_prepare] Reinstalling torch stack for driver-compatible CUDA tag ${TORCH_CUDA_TAG} (found: ${INSTALLED_TORCH_CUDA_TAG:-none})..."
    # shellcheck disable=SC2086
    pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --force-reinstall \
      --index-url "https://download.pytorch.org/whl/${TORCH_CUDA_TAG}" \
      torch torchvision torchaudio 2>&1 | tail -40
  fi
fi

python3 -c "import llamafactory.chat.chat_server, llamafactory.ec2.inference_server" || {
  echo "ERROR: required inference modules still not importable after install." >&2
  echo "  Fix package.pip_spec / network / private index auth, or sync a tree that contains chat_server." >&2
  exit 1
}

# Gemma4 and other modern stacks may JIT-compile Triton helpers that include Python.h.
# Fail fast with an actionable message (or auto-install) before model loading.
PY_INCLUDE_DIR="$(python3 - <<'PY'
import sysconfig
print(sysconfig.get_paths().get("include", ""))
PY
)"
PY_MM="$(python3 - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
)"
if [ -z "${PY_INCLUDE_DIR}" ] || [ ! -f "${PY_INCLUDE_DIR}/Python.h" ]; then
  echo "[inference_prepare] WARN: Python.h not found (expected at ${PY_INCLUDE_DIR}/Python.h)." >&2
  if command -v apt-get >/dev/null 2>&1 && sudo -n true >/dev/null 2>&1; then
    echo "[inference_prepare] Attempting to install Python development headers via apt..." >&2
    sudo apt-get update -y >/dev/null 2>&1 || true
    sudo apt-get install -y "python${PY_MM}-dev" >/dev/null 2>&1 || sudo apt-get install -y python3-dev >/dev/null 2>&1 || true
  fi
  PY_INCLUDE_DIR="$(python3 - <<'PY'
import sysconfig
print(sysconfig.get_paths().get("include", ""))
PY
)"
fi
if [ -z "${PY_INCLUDE_DIR}" ] || [ ! -f "${PY_INCLUDE_DIR}/Python.h" ]; then
  echo "ERROR: Missing Python development headers (Python.h)." >&2
  echo "  Required by Triton/CUDA JIT compilation for some models (including Gemma4)." >&2
  echo "  Run on the EC2 host:" >&2
  echo "    sudo apt-get update && sudo apt-get install -y python${PY_MM}-dev" >&2
  echo "  Then rerun lmf-ec2-chat." >&2
  exit 4
fi

python3 - <<'PYCHECK'
import sys

failures = []
try:
    import torch
    cuda_ok = torch.cuda.is_available()
    cuda_tag = "cu" + (torch.version.cuda or "").replace(".", "")
except ImportError as e:
    failures.append(f"torch import failed: {e}")
    torch = None
    cuda_ok = False
    cuda_tag = "unknown"

try:
    import torchaudio
except OSError as e:
    failures.append(
        f"torchaudio load failed (CUDA version mismatch): {e}\n"
        f"  Installed torch CUDA: {cuda_tag}\n"
        f"  Fix: pip install torchaudio --index-url https://download.pytorch.org/whl/{cuda_tag}"
    )
except ImportError as e:
    failures.append(f"torchaudio import failed: {e}")

try:
    import llamafactory
except ImportError as e:
    failures.append(f"llamafactory import failed: {e}")

if failures:
    for f in failures:
        print(f"  IMPORT ERROR: {f}", file=sys.stderr)
    sys.exit(1)

if not cuda_ok:
    print("  ERROR: PyTorch cannot see CUDA.", file=sys.stderr)
    sys.exit(3)

device = torch.cuda.get_device_properties(0)
vram_gb = device.total_memory / 1024**3
print(f"[inference_prepare] CUDA device: {device.name}")
print(f"[inference_prepare] VRAM: {vram_gb:.1f} GB")
print(f"[inference_prepare] Compute capability: sm_{device.major}{device.minor}")
print(f"[inference_prepare] PyTorch: {torch.__version__}")
print(f"[inference_prepare] torchaudio: {torchaudio.__version__}")
PYCHECK

# --- vLLM: atomic torch→vllm install order + extension ABI preflight (backend_profile=vllm) ---
# vLLM wheels are compiled against a specific libtorch ABI; a mismatched torch (or pip upgrading
# torch after vllm) causes: ImportError vllm._C.abi3.so: undefined symbol ...
# Policy: (1) torch stack is already aligned to ${TORCH_CUDA_TAG} above; (2) reinstall vllm; (3) if
# vllm pulled a different torch, re-align torch once and reinstall vllm again; (4) import vllm._C.
_check_torch_cuda_tag_match() {
  local want="$1"
  local have
  have=$(
    python3 -c "
import torch
v = getattr(torch.version, 'cuda', None)
print('cu' + v.replace('.', '') if v else '')" 2>/dev/null || true
  )
  if [ -n "$have" ] && [ "$have" = "$want" ]; then
    return 0
  fi
  return 1
}

_realign_torch_stack() {
  if [ -z "${TORCH_CUDA_TAG:-}" ]; then
    return 0
  fi
  echo "[inference_prepare] (vLLM) Reinstalling torch/vision/audio for CUDA tag ${TORCH_CUDA_TAG} (PyTorch wheel index)..."
  # shellcheck disable=SC2086
  pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --force-reinstall \
    --index-url "https://download.pytorch.org/whl/${TORCH_CUDA_TAG}" \
    torch torchvision torchaudio 2>&1 | tail -40
}

# Return 0 if vLLM native ext loads against the current (already-installed) torch.
_vllm_abi_import_ok() {
  python3 - <<'VLLM_ABI'
import torch
print(f"[vllm_abi] torch {torch.__version__} cu={torch.version.cuda!s} cuda={torch.cuda.is_available()!s}")
import vllm
print(f"[vllm_abi] vllm {vllm.__version__!s}")
import vllm._C  # noqa: F401
print("[vllm_abi] vllm._C OK", flush=True)
VLLM_ABI
}

_ensure_vllm_abi_stack() {
  if [ "${LF_EC2_BACKEND_PROFILE:-vllm}" != "vllm" ]; then
    return 0
  fi
  if [ -z "${TORCH_CUDA_TAG:-}" ]; then
    echo "ERROR: backend_profile=vllm needs a driver CUDA tag (nvidia-smi) to install a matching torch stack. TORCH_CUDA_TAG is empty." >&2
    exit 2
  fi
  local vllm_spec
  vllm_spec="${LF_VLLM_PIP_SPEC:-vllm}"
  local did_realign=0
  if ! _check_torch_cuda_tag_match "${TORCH_CUDA_TAG}"; then
    echo "[inference_prepare] (vLLM) torch CUDA tag does not match ${TORCH_CUDA_TAG}; re-aligning before vLLM..."
    _realign_torch_stack
    did_realign=1
  fi

  # If torch was already correct and vLLM already works, skip a slow pip round-trip (unless user forces reinstall).
  if [ "$did_realign" = "0" ] && [ "${LF_VLLM_FORCE_REINSTALL:-0}" != "1" ] && _vllm_abi_import_ok; then
    echo "[inference_prepare] (vLLM) Native extension already OK for current torch; skipping vLLM reinstall. Set LF_VLLM_FORCE_REINSTALL=1 to repin/reinstall."
    return 0
  fi

  echo "[inference_prepare] (vLLM) Reinstalling ${vllm_spec} against current torch (ABI pair)..."
  pip uninstall -y vllm >/dev/null 2>&1 || true
  # shellcheck disable=SC2086
  pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --force-reinstall "${vllm_spec}" 2>&1 | tail -50

  if ! _check_torch_cuda_tag_match "${TORCH_CUDA_TAG}"; then
    echo "[inference_prepare] (vLLM) pip may have changed torch; re-aligning torch and reinstalling vLLM once..."
    _realign_torch_stack
    # shellcheck disable=SC2086
    pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} --force-reinstall "${vllm_spec}" 2>&1 | tail -50
  fi

  echo "[inference_prepare] (vLLM) ABI preflight: import vllm._C..."
  if ! _vllm_abi_import_ok; then
    echo "ERROR: vLLM native extension failed to load (torch/vllm ABI mismatch or unsupported GPU build)." >&2
    echo "  Fix: set LF_VLLM_PIP_SPEC to a vLLM version matching your torch (e.g. vllm==0.8.5) and keep HuggingFace transformers<5, or re-run after a clean venv." >&2
    echo "  Or use inference.backend_profile: hf in the pipeline YAML." >&2
    exit 2
  fi
}

_ensure_vllm_abi_stack

HF_TOKEN_FILE="${WORK_DIR}/.hf_token"
if [ -z "${HF_TOKEN:-}" ] && [ -f "$HF_TOKEN_FILE" ]; then
  HF_TOKEN=$(cat "$HF_TOKEN_FILE")
  export HF_TOKEN
  rm -f "$HF_TOKEN_FILE"
fi

INFER_ABS="${WORK_DIR}/${INFER_REL}"
if [ ! -f "$INFER_ABS" ]; then
  echo "ERROR: inference yaml not found: $INFER_ABS" >&2
  exit 1
fi

cd "$WORK_DIR"
MODE="${LF_EC2_INFERENCE_MODE:-http}"
if [ "$MODE" != "http" ]; then
  echo "ERROR: unsupported LF_EC2_INFERENCE_MODE=$MODE (expected http)." >&2
  exit 1
fi

BACKEND_PROFILE="${LF_EC2_BACKEND_PROFILE:-vllm}"
HOST="${LF_EC2_SERVER_HOST:-127.0.0.1}"
PORT="${LF_EC2_SERVER_PORT:-8000}"
API_KEYS_FILE="${LF_EC2_SERVER_API_KEYS_FILE:-}"
VLLM_API_KEY="${LF_EC2_VLLM_API_KEY:-}"
READY_TIMEOUT_SEC="${LF_EC2_SERVER_READY_TIMEOUT_SEC:-900}"
SESSION_NAME="llamafactory-http"
LOG_PATH="${WORK_DIR}/chat_server.log"

_ensure_backend_transformers_stack() {
  local backend="$1"
  local model_name="$2"
  local spec_line=""
  if [ "$backend" = "vllm" ]; then
    spec_line="${LF_VLLM_TRANSFORMERS_PIP_SPEC:-transformers>=4.51.1,<5,!=4.57.0}"
  elif [ "$backend" = "hf" ]; then
    spec_line="${LF_HF_TRANSFORMERS_PIP_SPEC:-}"
    if [ -z "$spec_line" ]; then
      local lower_model
      lower_model=$(printf '%s' "$model_name" | tr '[:upper:]' '[:lower:]')
      case "$lower_model" in
      *gemma-4* | *gemma4*) spec_line="transformers>=5.5.0 tokenizers>=0.22.0" ;;
      esac
    fi
  fi

  if [ -z "$spec_line" ]; then
    return 0
  fi

  local specs=()
  # shellcheck disable=SC2206
  specs=($spec_line)
  if [ "${#specs[@]}" -eq 0 ]; then
    return 0
  fi

  echo "[inference_prepare] (${backend}) Aligning Python stack for model '${model_name}' with: ${spec_line}"
  # shellcheck disable=SC2086
  pip install -U ${PIP_COLD_FLAGS[@]+"${PIP_COLD_FLAGS[@]}"} "${specs[@]}" 2>&1 | tail -40
}

MODEL_NAME_FOR_STACK="$(
  python3 - <<'PY' "$INFER_ABS"
import sys
from pathlib import Path
import yaml

cfg = yaml.safe_load(Path(sys.argv[1]).read_text(encoding="utf-8")) or {}
print(str(cfg.get("model_name_or_path", "") or "").strip())
PY
)"
_ensure_backend_transformers_stack "$BACKEND_PROFILE" "$MODEL_NAME_FOR_STACK"

if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
  tmux kill-session -t "$SESSION_NAME"
fi
if [ "$BACKEND_PROFILE" = "vllm" ]; then
  # vLLM is installed and vllm._C verified in _ensure_vllm_abi_stack (after PYCHECK).
  readarray -t _vllm_cfg < <(python3 - <<'PY' "$INFER_ABS"
import sys
from pathlib import Path
import yaml

cfg = yaml.safe_load(Path(sys.argv[1]).read_text(encoding="utf-8")) or {}
model = str(cfg.get("model_name_or_path", "") or "").strip()
default_model_id = str(cfg.get("default_model_id", "") or "").strip() or model
max_model_len = cfg.get("max_model_len")
if max_model_len in ("", None):
    max_model_len = ""
else:
    max_model_len = str(max_model_len).strip()
adapters = []
for row in cfg.get("adapter_registry", []) or []:
    if not isinstance(row, dict):
        continue
    mid = str(row.get("id", "") or "").strip()
    path = str(row.get("path", "") or "").strip()
    if mid and path:
        adapters.append(f"{mid}={path}")
if not adapters:
    adapter_field = str(cfg.get("adapter_name_or_path", "") or "").strip()
    if adapter_field:
        adapters.append(f"adapter={adapter_field}")
vel = cfg.get("vllm_enable_lora", True)
if isinstance(vel, str):
    vllm_enable_lora = vel.lower() in ("1", "true", "yes")
else:
    vllm_enable_lora = bool(vel)
print(model)
print(default_model_id)
print(";".join(adapters))
print("true" if vllm_enable_lora else "false")
print(max_model_len)
PY
  )
  VLLM_MODEL="${_vllm_cfg[0]}"
  VLLM_MODEL_ID="${_vllm_cfg[1]}"
  VLLM_ADAPTERS="${_vllm_cfg[2]}"
  VLLM_ENABLE_LORA="${_vllm_cfg[3]:-true}"
  VLLM_MAX_MODEL_LEN="${_vllm_cfg[4]:-}"
  if [ -z "$VLLM_MODEL" ]; then
    echo "ERROR: model_name_or_path is required in inference YAML for vLLM profile." >&2
    exit 2
  fi
  if [ -n "${LF_VLLM_USE_V1+x}" ]; then
    _v1_val="${LF_VLLM_USE_V1}"
  else
    _v1_val="${VLLM_USE_V1:-0}"
  fi
  VLLM_V1_PREFIX="export VLLM_USE_V1=${_v1_val@Q} && "
  VLLM_ENV=""
  if [ -n "$VLLM_API_KEY" ]; then
    # Keep API keys out of process argv; vLLM reads VLLM_API_KEY from env.
    VLLM_ENV="export VLLM_API_KEY=${VLLM_API_KEY@Q} && "
  fi
  VLLM_CMD="python3 -u -m vllm.entrypoints.openai.api_server --host ${HOST@Q} --port ${PORT@Q} --model ${VLLM_MODEL@Q} --served-model-name ${VLLM_MODEL_ID@Q}"
  if [ -n "${HF_TOKEN:-}" ]; then
    VLLM_CMD="export HF_TOKEN=${HF_TOKEN@Q} && ${VLLM_CMD}"
  fi
  if [ -n "$VLLM_ADAPTERS" ] && [ "$VLLM_ENABLE_LORA" != "true" ]; then
    echo "[inference_prepare] vllm_enable_lora=false: skipping --enable-lora (adapters in YAML are ignored for vLLM; use HF profile or merge weights if you need LoRA)." >&2
  fi
  if [ -n "$VLLM_ADAPTERS" ] && [ "$VLLM_ENABLE_LORA" = "true" ]; then
    IFS=';' read -r -a _adapter_rows <<< "$VLLM_ADAPTERS"
    VLLM_CMD="${VLLM_CMD} --enable-lora"
    for _entry in "${_adapter_rows[@]}"; do
      _name="${_entry%%=*}"
      _path="${_entry#*=}"
      if [ -n "$_name" ] && [ -n "$_path" ]; then
        VLLM_CMD="${VLLM_CMD} --lora-modules ${_name@Q}=${_path@Q}"
      fi
    done
  fi
  if [ -n "$VLLM_MAX_MODEL_LEN" ]; then
    VLLM_CMD="${VLLM_CMD} --max-model-len ${VLLM_MAX_MODEL_LEN@Q}"
  fi
  tmux new-session -d -s "$SESSION_NAME" \
    "cd ${WORK_DIR@Q} && ${VLLM_V1_PREFIX}${VLLM_ENV}${VLLM_CMD} 2>&1 | tee ${LOG_PATH@Q}"
else
  if [ -n "$API_KEYS_FILE" ]; then
    tmux new-session -d -s "$SESSION_NAME" \
      "cd ${WORK_DIR@Q} && python3 -u -m llamafactory.chat.chat_server --config ${INFER_ABS@Q} --host ${HOST@Q} --port ${PORT@Q} --api-keys-file ${API_KEYS_FILE@Q} 2>&1 | tee ${LOG_PATH@Q}"
  else
    tmux new-session -d -s "$SESSION_NAME" \
      "cd ${WORK_DIR@Q} && python3 -u -m llamafactory.chat.chat_server --config ${INFER_ABS@Q} --host ${HOST@Q} --port ${PORT@Q} 2>&1 | tee ${LOG_PATH@Q}"
  fi
fi

_deadline=$((SECONDS + READY_TIMEOUT_SEC))
while [ "$SECONDS" -lt "$_deadline" ]; do
  if ! tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    echo "ERROR: tmux session ${SESSION_NAME} exited before readiness. Check ${LOG_PATH}" >&2
    exit 1
  fi
  _health_host="$HOST"
  if [ "$_health_host" = "0.0.0.0" ]; then
    _health_host="127.0.0.1"
  fi
  if python3 - <<'PY' "$_health_host" "$PORT"
import sys
import urllib.request

host = sys.argv[1]
port = int(sys.argv[2])
url = f"http://{host}:{port}/health"
try:
    with urllib.request.urlopen(url, timeout=2) as resp:
        ok = resp.status == 200
except Exception:
    ok = False
raise SystemExit(0 if ok else 1)
PY
  then
    echo "[inference_prepare] HTTP server ready: http://${HOST}:${PORT} (backend_profile=${BACKEND_PROFILE})"
    echo "[inference_prepare] tmux session: ${SESSION_NAME}"
    echo "[inference_prepare] log file: ${LOG_PATH}"
    exit 0
  fi
  sleep 2
done

echo "ERROR: HTTP server did not become ready within ${READY_TIMEOUT_SEC}s. Check ${LOG_PATH}" >&2
exit 1
