# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import os
import re
import stat
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .config import ExtraUpload


@dataclass
class ModelSync:
    """Local directory or file to rsync to EC2 instance NVMe (see inference_runner)."""

    source: str
    remote_name: str


@dataclass
class EC2InferencePipelineConfig:
    """EC2 interactive chat pipeline YAML (mirrors EC2 SFT layout; uses inference.config instead of training.config)."""

    instance_id: str = ""
    private_ip: str = ""
    key_file: str = ""
    region: str = "us-east-2"
    ssh_user: str = "ubuntu"
    remote_repo: str = "/home/ubuntu/LlamaFactory"

    inference_config: str = ""
    inference_mode: str = "http"
    backend_profile: str = "vllm"
    server_host: str = "127.0.0.1"
    server_port: int = 8000
    server_public: bool = False
    server_api_keys_file: str = ""
    server_vllm_api_key: str = field(default="", repr=False)
    # from_yaml: key omitted => "vllm==0.8.5"; key present and "" => unpin
    server_vllm_pip_spec: str = ""
    # None: leave unset (prepare defaults to V0 engine, VLLM_USE_V1=0). True/False: export LF_VLLM_USE_V1.
    server_vllm_use_v1: bool | None = None
    server_ready_timeout_sec: int = 900
    remote_pip_spec: str = ""

    local_output_dir: str = "./saves"
    hf_token: str = field(default="", repr=False)
    extra_uploads: list[ExtraUpload] = field(default_factory=list)
    model_syncs: list[ModelSync] = field(default_factory=list)

    after_training: str = "stop"
    auto_shutdown_after_training: bool = True

    repo_root: str = field(default="", repr=False)

    def __post_init__(self) -> None:
        if not self.repo_root:
            self.repo_root = os.getcwd()

        self.key_file = os.path.expanduser(self.key_file)

        if self.local_output_dir and not os.path.isabs(self.local_output_dir):
            self.local_output_dir = os.path.join(self.repo_root, self.local_output_dir)

    def validate(self) -> None:
        required = {
            "instance_id": "ec2.instance_id",
            "private_ip": "ec2.private_ip",
            "key_file": "ec2.key_file",
            "inference_config": "inference.config — path to inference YAML relative to workspace root",
        }
        for attr, hint in required.items():
            if not getattr(self, attr):
                raise ValueError(f"Required config field is empty: {hint}")

        if not os.path.isfile(self.key_file):
            raise FileNotFoundError(f"SSH key not found: {self.key_file}")

        if not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", self.private_ip):
            raise ValueError(f"private_ip is not a valid IPv4 address: {self.private_ip}")
        if not re.match(r"^[\w./-]+$", self.remote_repo):
            raise ValueError(f"remote_repo contains invalid characters: {self.remote_repo}")
        if not re.match(r"^[\w.-]+$", self.ssh_user):
            raise ValueError(f"ssh_user contains invalid characters: {self.ssh_user}")

        try:
            fd = os.open(self.key_file, os.O_RDONLY | os.O_NOFOLLOW)
            try:
                st = os.fstat(fd)
                if st.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
                    os.fchmod(fd, 0o600)
            finally:
                os.close(fd)
        except OSError as e:
            import warnings

            warnings.warn(f"Could not verify SSH key permissions for {self.key_file}: {e}", stacklevel=2)

        workspace = os.path.realpath(self.repo_root)
        infer_yaml = os.path.realpath(os.path.join(self.repo_root, self.inference_config))
        if not infer_yaml.startswith(workspace):
            raise ValueError(f"inference_config escapes workspace root: {self.inference_config}")
        if not os.path.isfile(infer_yaml):
            raise FileNotFoundError(f"Inference config not found: {infer_yaml}")
        if self.inference_mode != "http":
            raise ValueError(f"inference.mode must be 'http' (got {self.inference_mode!r})")
        if self.backend_profile not in {"vllm", "hf"}:
            raise ValueError(f"inference.backend_profile must be 'vllm' or 'hf' (got {self.backend_profile!r})")
        if not isinstance(self.server_port, int) or self.server_port <= 0 or self.server_port > 65535:
            raise ValueError(f"inference.port must be an integer in 1..65535 (got {self.server_port!r})")
        if (
            not isinstance(self.server_ready_timeout_sec, int)
            or self.server_ready_timeout_sec < 30
            or self.server_ready_timeout_sec > 3600
        ):
            raise ValueError(
                f"inference.ready_timeout_sec must be an integer in 30..3600 (got {self.server_ready_timeout_sec!r})"
            )
        if not isinstance(self.server_public, bool):
            raise ValueError(f"inference.public must be a boolean (got {self.server_public!r})")
        if self.server_vllm_use_v1 is not None and not isinstance(self.server_vllm_use_v1, bool):
            raise ValueError(f"inference.vllm_use_v1 must be a boolean (got {self.server_vllm_use_v1!r})")
        if self.server_host.strip() and not re.match(r"^[A-Za-z0-9_.:-]+$", self.server_host.strip()):
            raise ValueError(f"inference.host contains invalid characters: {self.server_host!r}")
        if self.server_public and not self.server_api_keys_file.strip():
            raise ValueError("inference.api_keys_file is required when inference.public is true")
        if self.server_public and self.backend_profile == "vllm" and not self.server_vllm_api_key.strip():
            raise ValueError("inference.vllm_api_key is required when backend_profile is vllm and inference.public is true")

        has_pyproject = os.path.isfile(os.path.join(workspace, "pyproject.toml"))
        if not self.remote_pip_spec.strip() and not has_pyproject:
            raise ValueError(
                "Workspace has no pyproject.toml. Set remote_pip_spec (YAML: package.pip_spec) to the "
                "same pip/uv requirement you use locally."
            )

        for ex in self.extra_uploads:
            tgt = (ex.target or "").strip().replace("\\", "/")
            if not tgt or ".." in Path(tgt).parts or tgt.startswith("/"):
                raise ValueError(f"sync.extra_uploads target must be a relative path without '..': {ex.target!r}")
            src_abs = os.path.realpath(os.path.expanduser(ex.source))
            if not os.path.exists(src_abs):
                raise FileNotFoundError(f"sync.extra_uploads source not found: {ex.source}")

        for ms in self.model_syncs:
            name = (ms.remote_name or "").strip().replace("\\", "/")
            if not name or ".." in Path(name).parts or name.startswith("/"):
                raise ValueError(f"inference.model_syncs remote_name must be a plain name without '..': {ms.remote_name!r}")
            if not re.match(r"^[\w.-]+(/[\w.-]+)*$", name):
                raise ValueError(
                    f"inference.model_syncs remote_name contains invalid characters (must be alphanumeric, dots, dashes, or slashes): {ms.remote_name!r}"
                )
            src_abs = os.path.realpath(os.path.expanduser(ms.source))
            if not os.path.exists(src_abs):
                raise FileNotFoundError(f"model_syncs source not found: {ms.source}")

    @classmethod
    def from_yaml(cls, path: str | Path) -> EC2InferencePipelineConfig:
        path = Path(path)
        with open(path) as f:
            data = yaml.safe_load(f) or {}

        ec2 = data.get("ec2", {})
        inference = data.get("inference", {})
        package = data.get("package", {})
        sync = data.get("sync", {})
        lifecycle = data.get("lifecycle", {})
        paths_cfg = data.get("paths", {})

        auto_sd = lifecycle.get("auto_shutdown_after_training", True)
        if isinstance(auto_sd, str):
            auto_sd = auto_sd.lower() in ("1", "true", "yes")

        server_host = str(inference.get("host", "127.0.0.1") or "127.0.0.1").strip()
        server_public = inference.get("public", False)
        if isinstance(server_public, str):
            server_public = server_public.lower() in ("1", "true", "yes")
        if server_public:
            server_host = "0.0.0.0"

        extra_uploads: list[ExtraUpload] = []
        for row in sync.get("extra_uploads") or []:
            if not isinstance(row, dict):
                continue
            s, t = row.get("source", ""), row.get("target", "")
            if s and t:
                extra_uploads.append(ExtraUpload(source=str(s), target=str(t)))

        model_syncs: list[ModelSync] = []
        for row in inference.get("model_syncs") or []:
            if not isinstance(row, dict):
                continue
            s, name = row.get("source", ""), row.get("remote_name", "")
            if s and name:
                model_syncs.append(ModelSync(source=str(s), remote_name=str(name)))

        workspace_override = paths_cfg.get("workspace_root", "") or paths_cfg.get("workspace", "")
        if workspace_override:
            repo_root = os.path.realpath(os.path.expanduser(str(workspace_override)))
        else:
            path_parent = path.resolve().parent
            repo_root = str(path_parent)
            candidate = path_parent
            for _ in range(10):
                if (candidate / "pyproject.toml").exists() or (candidate / ".git").exists():
                    repo_root = str(candidate)
                    break
                if candidate.parent == candidate:
                    break
                candidate = candidate.parent

        server_vllm_use_v1: bool | None
        if "vllm_use_v1" in inference:
            _vu = inference.get("vllm_use_v1", False)
            if isinstance(_vu, str):
                server_vllm_use_v1 = _vu.lower() in ("1", "true", "yes")
            else:
                server_vllm_use_v1 = bool(_vu)
        else:
            server_vllm_use_v1 = None

        return cls(
            instance_id=str(ec2.get("instance_id", "") or ""),
            private_ip=str(ec2.get("private_ip", "") or ""),
            key_file=str(ec2.get("key_file", "") or ""),
            region=str(ec2.get("region", "us-east-2") or "us-east-2"),
            ssh_user=str(ec2.get("ssh_user", "ubuntu") or "ubuntu"),
            remote_repo=str(ec2.get("remote_repo", "/home/ubuntu/LlamaFactory") or "/home/ubuntu/LlamaFactory"),
            inference_config=str(inference.get("config", "") or ""),
            inference_mode=str(inference.get("mode", "http") or "http").strip().lower(),
            backend_profile=str(inference.get("backend_profile", "vllm") or "vllm").strip().lower(),
            server_host=server_host,
            server_port=int(inference.get("port", 8000) or 8000),
            server_public=bool(server_public),
            server_api_keys_file=str(inference.get("api_keys_file", "") or ""),
            server_vllm_api_key=str(inference.get("vllm_api_key", "") or ""),
            server_vllm_pip_spec=(str(inference.get("vllm_pip_spec", "") or "").strip()
            if "vllm_pip_spec" in inference
            else "vllm==0.8.5"),
            server_vllm_use_v1=server_vllm_use_v1,
            server_ready_timeout_sec=int(inference.get("ready_timeout_sec", 900) or 900),
            remote_pip_spec=str(package.get("pip_spec", "") or ""),
            local_output_dir=str(sync.get("local_output_dir", "./saves") or "./saves"),
            hf_token=str(sync.get("hf_token", "") or ""),
            extra_uploads=extra_uploads,
            model_syncs=model_syncs,
            after_training=str(lifecycle.get("after_training", "stop") or "stop"),
            auto_shutdown_after_training=bool(auto_sd),
            repo_root=repo_root,
        )
