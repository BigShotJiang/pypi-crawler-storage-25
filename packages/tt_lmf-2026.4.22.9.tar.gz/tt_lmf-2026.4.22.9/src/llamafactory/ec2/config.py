# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import os
import re
import stat
from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class ExtraUpload:
    """Extra local path to rsync into ``remote_repo`` after the main workspace sync."""

    source: str
    target: str


@dataclass
class EC2SSHSettings:
    """SSH + sync parameters shared by the runner and manual recovery (no training YAML required)."""

    instance_id: str
    private_ip: str
    key_file: str
    region: str
    ssh_user: str = "ubuntu"
    remote_repo: str = "/home/ubuntu/LlamaFactory"
    local_output_dir: str = ""

    def __post_init__(self) -> None:
        self.key_file = os.path.expanduser(self.key_file)
        self.local_output_dir = os.path.expanduser(self.local_output_dir)

    @classmethod
    def from_ec2_state_file(cls, path: str | Path) -> EC2SSHSettings:
        """Parse ``.ec2_state`` (KEY=value lines) written by ``run_ec2_training``."""
        path = Path(path)
        if not path.is_file():
            raise FileNotFoundError(f"EC2 state file not found: {path}")

        data: dict[str, str] = {}
        for raw in path.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            data[key.strip()] = val.strip().strip('"').strip("'")

        def req(name: str) -> str:
            v = data.get(name, "").strip()
            if not v:
                raise ValueError(f"Missing {name} in {path}")
            return v

        remote_repo = data.get("REMOTE_REPO", "/home/ubuntu/LlamaFactory") or "/home/ubuntu/LlamaFactory"
        private_ip = req("PRIVATE_IP")
        ssh_user = data.get("SSH_USER", "ubuntu") or "ubuntu"
        if not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", private_ip):
            raise ValueError(f"private_ip is not a valid IPv4 address: {private_ip}")
        if not re.match(r"^[\w./-]+$", remote_repo):
            raise ValueError(f"remote_repo contains invalid characters: {remote_repo}")
        if not re.match(r"^[\w.-]+$", ssh_user):
            raise ValueError(f"ssh_user contains invalid characters: {ssh_user}")

        return cls(
            instance_id=req("INSTANCE_ID"),
            private_ip=private_ip,
            key_file=req("KEY_FILE"),
            region=data.get("REGION", "us-east-2") or "us-east-2",
            ssh_user=ssh_user,
            remote_repo=remote_repo,
            local_output_dir=data.get("RESULTS_LOCAL", "") or "",
        )


@dataclass
class EC2RunConfig:
    """Typed representation of an EC2 SFT run YAML (see examples/ec2_pipeline/config_template.yaml)."""

    # ec2 section
    instance_id: str = ""
    private_ip: str = ""
    key_file: str = ""
    region: str = "us-east-2"
    ssh_user: str = "ubuntu"
    remote_repo: str = "/home/ubuntu/LlamaFactory"

    # training section
    training_config: str = ""

    # package section (Orbi / pip-install-on-EC2 — same spec as your local venv)
    remote_pip_spec: str = ""

    # sync section
    local_output_dir: str = "./saves"
    hf_token: str = field(default="", repr=False)
    extra_uploads: list[ExtraUpload] = field(default_factory=list)
    checkpoint_sync_minutes: int = 0

    # lifecycle section
    after_training: str = "stop"
    max_hours: int = 12
    auto_shutdown_after_training: bool = True
    auto_shutdown_grace_sec: int = 900

    # cortex hook (optional)
    orbi_publish_cmd: str = ""

    # resolved at runtime
    repo_root: str = field(default="", repr=False)

    def __post_init__(self) -> None:
        if not self.repo_root:
            self.repo_root = os.getcwd()

        self.key_file = os.path.expanduser(self.key_file)

        if self.local_output_dir and not os.path.isabs(self.local_output_dir):
            self.local_output_dir = os.path.join(self.repo_root, self.local_output_dir)

    def validate(self) -> None:
        """Raise ValueError if required fields are missing."""
        required = {
            "instance_id": "ec2.instance_id — existing EC2 instance ID (e.g. i-0abc123def456)",
            "private_ip": "ec2.private_ip — private IP reachable via VPN",
            "key_file": "ec2.key_file — path to your SSH private key",
            "training_config": "training.config — path to training YAML relative to workspace root",
        }
        for attr, hint in required.items():
            if not getattr(self, attr):
                raise ValueError(f"Required config field is empty: {hint}")

        if not os.path.isfile(self.key_file):
            raise FileNotFoundError(f"SSH key not found: {self.key_file}")

        if not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", self.private_ip):
            raise ValueError(f"private_ip is not a valid IPv4 address: {self.private_ip}")
        if not re.match(r"^[\w./-]+$", self.remote_repo):
            raise ValueError(f"remote_repo contains invalid characters: {self.remote_repo}")
        if not re.match(r"^[\w.-]+$", self.ssh_user):
            raise ValueError(f"ssh_user contains invalid characters: {self.ssh_user}")

        try:
            fd = os.open(self.key_file, os.O_RDONLY | os.O_NOFOLLOW)
            try:
                st = os.fstat(fd)
                if st.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
                    os.fchmod(fd, 0o600)
            finally:
                os.close(fd)
        except OSError as e:
            _warn = f"Could not verify SSH key permissions for {self.key_file}: {e}"
            import warnings

            warnings.warn(_warn, stacklevel=2)

        workspace = os.path.realpath(self.repo_root)
        train_yaml = os.path.realpath(os.path.join(self.repo_root, self.training_config))
        if not train_yaml.startswith(workspace):
            raise ValueError(f"training_config escapes workspace root: {self.training_config}")
        if not os.path.isfile(train_yaml):
            raise FileNotFoundError(f"Training config not found: {train_yaml}")

        has_pyproject = os.path.isfile(os.path.join(workspace, "pyproject.toml"))
        if not self.remote_pip_spec.strip() and not has_pyproject:
            raise ValueError(
                "Workspace has no pyproject.toml. Set remote_pip_spec (YAML: package.pip_spec) to the "
                "same pip/uv requirement you use locally, e.g. "
                "'tt-lmf[ec2]==2026.4.7.1'."
            )

        for ex in self.extra_uploads:
            tgt = (ex.target or "").strip().replace("\\", "/")
            if not tgt or ".." in Path(tgt).parts or tgt.startswith("/"):
                raise ValueError(f"sync.extra_uploads target must be a relative path without '..': {ex.target!r}")
            src_abs = os.path.realpath(os.path.expanduser(ex.source))
            if not os.path.exists(src_abs):
                raise FileNotFoundError(f"sync.extra_uploads source not found: {ex.source}")

        if self.orbi_publish_cmd:
            if not re.match(r"^[a-zA-Z0-9./_\-{} ]+$", self.orbi_publish_cmd):
                raise ValueError(
                    "orbi.publish_cmd contains invalid characters. "
                    "Allowed: alphanumeric, spaces, dots, dashes, underscores, slashes, and {placeholder} fields. "
                    f"Got: {self.orbi_publish_cmd!r}"
                )

    def ssh_settings(self) -> EC2SSHSettings:
        """Connection settings for rsync/SSH without training metadata."""
        return EC2SSHSettings(
            instance_id=self.instance_id,
            private_ip=self.private_ip,
            key_file=self.key_file,
            region=self.region,
            ssh_user=self.ssh_user,
            remote_repo=self.remote_repo,
            local_output_dir=self.local_output_dir,
        )

    @classmethod
    def from_yaml(cls, path: str | Path) -> EC2RunConfig:
        """Load an EC2RunConfig from a pipeline YAML file."""
        path = Path(path)
        with open(path) as f:
            data = yaml.safe_load(f) or {}

        ec2 = data.get("ec2", {})
        training = data.get("training", {})
        package = data.get("package", {})
        sync = data.get("sync", {})
        lifecycle = data.get("lifecycle", {})
        orbi = data.get("orbi", {})
        paths_cfg = data.get("paths", {})

        auto_sd = lifecycle.get("auto_shutdown_after_training", True)
        if isinstance(auto_sd, str):
            auto_sd = auto_sd.lower() in ("1", "true", "yes")

        extra_uploads: list[ExtraUpload] = []
        for row in sync.get("extra_uploads") or []:
            if not isinstance(row, dict):
                continue
            s, t = row.get("source", ""), row.get("target", "")
            if s and t:
                extra_uploads.append(ExtraUpload(source=str(s), target=str(t)))

        workspace_override = paths_cfg.get("workspace_root", "") or paths_cfg.get("workspace", "")
        if workspace_override:
            repo_root = os.path.realpath(os.path.expanduser(str(workspace_override)))
        else:
            path_parent = path.resolve().parent
            repo_root = str(path_parent)
            candidate = path_parent
            for _ in range(10):
                if (candidate / "pyproject.toml").exists() or (candidate / ".git").exists():
                    repo_root = str(candidate)
                    break
                if candidate.parent == candidate:
                    break
                candidate = candidate.parent

        return cls(
            instance_id=str(ec2.get("instance_id", "") or ""),
            private_ip=str(ec2.get("private_ip", "") or ""),
            key_file=str(ec2.get("key_file", "") or ""),
            region=str(ec2.get("region", "us-east-2") or "us-east-2"),
            ssh_user=str(ec2.get("ssh_user", "ubuntu") or "ubuntu"),
            remote_repo=str(ec2.get("remote_repo", "/home/ubuntu/LlamaFactory") or "/home/ubuntu/LlamaFactory"),
            training_config=str(training.get("config", "") or ""),
            remote_pip_spec=str(package.get("pip_spec", "") or ""),
            local_output_dir=str(sync.get("local_output_dir", "./saves") or "./saves"),
            hf_token=str(sync.get("hf_token", "") or ""),
            extra_uploads=extra_uploads,
            checkpoint_sync_minutes=int(sync.get("checkpoint_sync_minutes", 0) or 0),
            after_training=str(lifecycle.get("after_training", "stop") or "stop"),
            max_hours=int(lifecycle.get("max_hours", 12) or 12),
            auto_shutdown_after_training=bool(auto_sd),
            auto_shutdown_grace_sec=int(lifecycle.get("auto_shutdown_grace_sec", 900) or 900),
            orbi_publish_cmd=str(orbi.get("publish_cmd", "") or ""),
            repo_root=repo_root,
        )
