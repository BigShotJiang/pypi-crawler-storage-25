# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Persistent EC2 inference server for prompt payloads over localhost TCP."""

from __future__ import annotations

import argparse
import json
import logging
import socket
import threading
from collections.abc import Generator
from pathlib import Path
from typing import Any

import torch

from ..data import get_template_and_fix_tokenizer
from ..extras.constants import EngineName
from ..hparams import get_infer_args
from ..model import load_model, load_tokenizer
from .inference_repl import _apply_env_overrides, _load_infer_dict


logger = logging.getLogger(__name__)
MAX_PAYLOAD_BYTES = 10 * 1024 * 1024  # 10MB limit for socket payloads


class InferenceRuntime:
    def __init__(self, yaml_path: str | Path):
        infer_dict = _apply_env_overrides(_load_infer_dict(Path(yaml_path).resolve()))
        self.infer_dict = infer_dict
        model_args, data_args, finetuning_args, generating_args = get_infer_args(infer_dict)
        if model_args.infer_backend != EngineName.HF:
            raise ValueError(f"infer_backend must be huggingface (got {model_args.infer_backend!r})")

        # Load tokenizer and model
        tokenizer_module = load_tokenizer(model_args)
        self.tokenizer = tokenizer_module["tokenizer"]
        # Gemma 4 and other multimodal hubs still load AutoProcessor; text-only chat uses tokenizer +
        # generate(input_ids=...) only. Image/audio/video inputs are not supported on this server.
        if tokenizer_module.get("processor") is not None:
            logger.warning(
                "Multimodal processor present; using text-only path (tokenizer + generate)"
            )

        get_template_and_fix_tokenizer(self.tokenizer, data_args)
        self.model = load_model(self.tokenizer, model_args, finetuning_args, is_trainable=False)
        self.model.eval()
        self.device = next(self.model.parameters()).device
        self.generating_args = generating_args
        self.default_gen_kwargs: dict[str, Any] = {
            "max_new_tokens": generating_args.max_new_tokens if generating_args.max_new_tokens > 0 else generating_args.max_length,
            "do_sample": generating_args.do_sample,
            "temperature": generating_args.temperature,
            "top_p": generating_args.top_p,
            "top_k": generating_args.top_k,
            "num_beams": generating_args.num_beams,
            "repetition_penalty": generating_args.repetition_penalty,
            "length_penalty": generating_args.length_penalty,
            "pad_token_id": self.tokenizer.pad_token_id,
        }
        self.default_gen_kwargs = {k: v for k, v in self.default_gen_kwargs.items() if v is not None}
        if getattr(self.tokenizer, "chat_template", None) is None:
            raise ValueError("Tokenizer has no chat_template after template fix; cannot run payload inference.")
        self.skip_special_tokens = generating_args.skip_special_tokens
        self.lock = threading.Lock()
        adapter_cfg = infer_dict.get("adapter_registry", [])
        self.adapter_registry: dict[str, str] = {}
        if isinstance(adapter_cfg, list):
            for row in adapter_cfg:
                if isinstance(row, dict):
                    model_id = str(row.get("id", "")).strip()
                    adapter_path = str(row.get("path", "")).strip()
                    if model_id and adapter_path:
                        self.adapter_registry[model_id] = adapter_path

        configured_id = str(infer_dict.get("default_model_id", "")).strip()
        if configured_id:
            self.default_model_id = configured_id
        elif self.adapter_registry:
            self.default_model_id = sorted(self.adapter_registry.keys())[0]
        else:
            self.default_model_id = str(model_args.model_name_or_path)
        if self.default_model_id not in self.adapter_registry:
            self.adapter_registry[self.default_model_id] = str(model_args.adapter_name_or_path or "")
        self.available_model_ids = set(self.adapter_registry.keys())

    @staticmethod
    def _truncate_on_stop(text: str, stop: list[str]) -> tuple[str, bool]:
        cut_points = [text.find(marker) for marker in stop if marker]
        cut_points = [idx for idx in cut_points if idx >= 0]
        if not cut_points:
            return text, False
        min_idx = min(cut_points)
        return text[:min_idx], True

    @staticmethod
    def _normalize_stop(raw_stop: Any) -> list[str]:
        if raw_stop is None:
            return []
        if isinstance(raw_stop, str):
            return [raw_stop]
        if isinstance(raw_stop, list):
            return [str(item) for item in raw_stop if str(item)]
        raise ValueError("'stop' must be a string or list of strings.")

    def _resolve_requested_model(self, payload: dict[str, Any]) -> str:
        requested = str(payload.get("model", "")).strip() or self.default_model_id
        if requested not in self.available_model_ids:
            available = ", ".join(sorted(self.available_model_ids))
            raise ValueError(f"Unknown model {requested!r}. Available models: {available}")
        if requested != self.default_model_id:
            raise ValueError(
                f"HF backend loaded default model {self.default_model_id!r}; dynamic switching to {requested!r} is not supported. "
                "Use backend_profile=vllm for multi-LoRA serving."
            )
        return requested

    def list_models(self) -> list[dict[str, str]]:
        model_id = self.default_model_id
        return [
            {
                "id": model_id,
                "object": "model",
                "owned_by": "tt-lmf",
                "backend": "hf",
                "adapter_path": self.adapter_registry.get(model_id, ""),
            }
        ]

    def _build_generation_kwargs(self, payload: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
        req_gen = payload.get("generation", {}) if isinstance(payload.get("generation"), dict) else {}
        gen_kwargs = dict(self.default_gen_kwargs)
        gen_kwargs.update({k: v for k, v in req_gen.items() if v is not None})

        for key in ("temperature", "top_p", "top_k", "num_beams", "repetition_penalty", "length_penalty"):
            if payload.get(key) is not None:
                gen_kwargs[key] = payload[key]
        if payload.get("max_tokens") is not None:
            gen_kwargs["max_new_tokens"] = int(payload["max_tokens"])
        if payload.get("max_new_tokens") is not None:
            gen_kwargs["max_new_tokens"] = int(payload["max_new_tokens"])
        if payload.get("seed") is not None:
            torch.manual_seed(int(payload["seed"]))
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(int(payload["seed"]))
        if float(gen_kwargs.get("temperature", 1.0) or 0.0) == 0.0:
            gen_kwargs["do_sample"] = False

        stop_sequences = self._normalize_stop(payload.get("stop"))
        if not stop_sequences and "stop" in req_gen:
            stop_sequences = self._normalize_stop(req_gen.get("stop"))
        return gen_kwargs, stop_sequences

    def _prepare_inputs(
        self, payload: dict[str, Any]
    ) -> tuple[torch.Tensor, torch.Tensor | None, dict[str, Any], list[str]]:
        """Parse payload and prepare tokenized inputs and generation kwargs.

        Returns:
            Tuple of (inputs, attention_mask, gen_kwargs)
        """
        prompt = str(payload.get("prompt", "") or "").strip()
        messages = payload.get("messages")
        if messages is None:
            if not prompt:
                raise ValueError("Payload must provide either non-empty 'prompt' or 'messages'.")
            messages = [{"role": "user", "content": prompt}]
        if not isinstance(messages, list) or not messages:
            raise ValueError("'messages' must be a non-empty list.")

        encoded = self.tokenizer.apply_chat_template(
            conversation=messages,
            add_generation_prompt=True,
            tokenize=True,
            return_tensors="pt",
        )
        attention_mask = None
        if hasattr(encoded, "input_ids"):
            inputs = encoded.input_ids
            attention_mask = getattr(encoded, "attention_mask", None)
        elif isinstance(encoded, dict):
            inputs = encoded["input_ids"]
            attention_mask = encoded.get("attention_mask")
        elif isinstance(encoded, torch.Tensor):
            inputs = encoded
        else:
            inputs = torch.tensor(encoded, dtype=torch.long)

        inputs = inputs.to(self.device)
        if inputs.dim() == 1:
            inputs = inputs.unsqueeze(0)
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)
            if attention_mask.dim() == 1:
                attention_mask = attention_mask.unsqueeze(0)
        else:
            attention_mask = torch.ones_like(inputs, dtype=torch.long, device=self.device)

        gen_kwargs, stop_sequences = self._build_generation_kwargs(payload)
        return inputs, attention_mask, gen_kwargs, stop_sequences

    def infer_stream(self, payload: dict[str, Any]) -> Generator[str, None, None]:
        """Stream inference results token by token."""
        self._resolve_requested_model(payload)
        inputs, attention_mask, gen_kwargs, stop_sequences = self._prepare_inputs(payload)

        try:
            from transformers import TextIteratorStreamer

            streamer = TextIteratorStreamer(
                self.tokenizer,
                timeout=30.0,
                skip_prompt=True,
                skip_special_tokens=self.skip_special_tokens
            )

            gen_kwargs["streamer"] = streamer
            thread = None

            try:
                with self.lock:
                    thread = threading.Thread(
                        target=self._generate_thread_target,
                        kwargs={"inputs": inputs, "attention_mask": attention_mask, "gen_kwargs": gen_kwargs},
                    )
                    thread.start()

                    generated = ""
                    emitted_len = 0
                    for token in streamer:
                        if token:
                            generated += token
                            if stop_sequences:
                                truncated, hit_stop = self._truncate_on_stop(generated, stop_sequences)
                                if hit_stop:
                                    if len(truncated) > emitted_len:
                                        yield truncated[emitted_len:]
                                    break
                            if len(generated) > emitted_len:
                                yield generated[emitted_len:]
                                emitted_len = len(generated)

                    if thread is not None:
                        thread.join()
            except Exception:
                if thread is not None:
                    thread.join()
                raise

        except ImportError as e:
            logger.error("TextIteratorStreamer not available: %s", e)
            raise RuntimeError("Streaming not supported in this environment") from e

    def infer(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Generate inference result (non-streaming)."""
        model_id = self._resolve_requested_model(payload)
        inputs, attention_mask, gen_kwargs, stop_sequences = self._prepare_inputs(payload)

        with self.lock, torch.inference_mode():
            output_ids = self.model.generate(input_ids=inputs, attention_mask=attention_mask, **gen_kwargs)

        seq = output_ids[0].tolist()
        prompt_len = int(inputs.shape[-1])
        completion_token_ids = seq[prompt_len:]
        reply = self.tokenizer.decode(completion_token_ids, skip_special_tokens=self.skip_special_tokens)
        finish_reason = "length"
        if stop_sequences:
            reply, hit_stop = self._truncate_on_stop(reply, stop_sequences)
            if hit_stop:
                finish_reason = "stop"
        prompt_tokens = prompt_len
        completion_tokens = len(completion_token_ids)
        return {
            "model": model_id,
            "text": reply,
            "finish_reason": finish_reason,
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            },
        }

    def infer_openai_completions(self, payload: dict[str, Any]) -> dict[str, Any]:
        model_id = self._resolve_requested_model(payload)
        if payload.get("stream"):
            raise ValueError("stream=true is not supported on HF fallback backend for /v1/completions.")
        result = self.infer(payload)
        return {
            "id": "cmpl-lmf",
            "object": "text_completion",
            "model": model_id,
            "choices": [
                {
                    "index": 0,
                    "text": result["text"],
                    "finish_reason": result["finish_reason"],
                }
            ],
            "usage": result["usage"],
        }

    def infer_openai_chat_completions(self, payload: dict[str, Any]) -> dict[str, Any]:
        model_id = self._resolve_requested_model(payload)
        if payload.get("stream"):
            raise ValueError("stream=true is not supported on HF fallback backend for /v1/chat/completions.")
        result = self.infer(payload)
        return {
            "id": "chatcmpl-lmf",
            "object": "chat.completion",
            "model": model_id,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": result["text"]},
                    "finish_reason": result["finish_reason"],
                }
            ],
            "usage": result["usage"],
        }

    def _generate_thread_target(
        self,
        inputs: torch.Tensor,
        attention_mask: torch.Tensor | None,
        gen_kwargs: dict[str, Any],
    ) -> None:
        with torch.inference_mode():
            self.model.generate(input_ids=inputs, attention_mask=attention_mask, **gen_kwargs)


def serve(yaml_path: str, host: str, port: int) -> int:
    """Run the TCP inference server."""
    runtime = InferenceRuntime(yaml_path)
    logger.info("Inference server ready on %s:%d", host, port)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((host, port))
        server.listen(8)
        while True:
            conn, addr = server.accept()
            with conn:
                try:
                    raw = b""
                    while not raw.endswith(b"\n"):
                        chunk = conn.recv(4096)
                        if not chunk:
                            break
                        raw += chunk
                        if len(raw) > MAX_PAYLOAD_BYTES:
                            raise ValueError(f"Payload exceeds {MAX_PAYLOAD_BYTES} bytes")
                    payload = json.loads(raw.decode("utf-8").strip() or "{}")
                    response = runtime.infer(payload)
                except Exception as e:
                    logger.error("Error processing request from %s: %s", addr, e)
                    response = {"error": str(e)}
                conn.sendall((json.dumps(response, ensure_ascii=True) + "\n").encode("utf-8"))
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Run EC2 local inference payload server.")
    parser.add_argument("yaml_path", help="Inference YAML path")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    args = parser.parse_args()
    raise SystemExit(serve(args.yaml_path, args.host, args.port))


if __name__ == "__main__":
    main()
