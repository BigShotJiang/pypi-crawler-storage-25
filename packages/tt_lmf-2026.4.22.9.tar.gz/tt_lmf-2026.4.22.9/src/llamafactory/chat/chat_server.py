# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import json
import logging
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from llamafactory.chat.api_keys import ApiKeyStore
from llamafactory.ec2.inference_server import InferenceRuntime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _extract_api_key(handler: BaseHTTPRequestHandler) -> str | None:
    auth = handler.headers.get("Authorization")
    if auth and auth.lower().startswith("bearer "):
        return auth[7:].strip()
    x = handler.headers.get("X-API-Key")
    return x.strip() if x else None


class ChatHandler(BaseHTTPRequestHandler):
    """HTTP handler for chat inference requests."""

    def __init__(
        self,
        inference_runtime: InferenceRuntime,
        key_store: ApiKeyStore | None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        self.inference_runtime = inference_runtime
        self.key_store = key_store
        super().__init__(*args, **kwargs)

    def do_POST(self) -> None:
        """Handle POST requests with streaming responses."""
        if self.path not in {"/chat", "/v1/completions", "/v1/chat/completions"}:
            self.send_error(404, "Not Found")
            return

        if self.key_store is not None:
            if not self.key_store.verify(_extract_api_key(self)):
                self._send_json_error(401, "unauthorized", "Missing or invalid API key")
                return

        try:
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length > 10 * 1024 * 1024:  # 10MB limit
                self._send_json_error(413, "payload_too_large", "Request payload exceeds 10MB")
                return
            post_data = self.rfile.read(content_length)
            request_data = json.loads(post_data.decode("utf-8"))
            if self.path == "/chat":
                self._handle_legacy_chat_stream(request_data)
            elif self.path == "/v1/completions":
                self._handle_openai_completion(request_data)
            elif self.path == "/v1/chat/completions":
                self._handle_openai_chat_completion(request_data)

        except ValueError as e:
            logger.error("Invalid request: %s", e)
            self._send_json_error(400, "invalid_request_error", str(e))
        except Exception as e:
            logger.error("Error processing request: %s", e)
            self._send_json_error(500, "internal_error", "Internal server error")

    def _handle_legacy_chat_stream(self, request_data: dict[str, Any]) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "null")
        self.end_headers()

        try:
            for token in self.inference_runtime.infer_stream(request_data):
                if token:
                    event_data = f"data: {json.dumps({'token': token})}\n\n"
                    self.wfile.write(event_data.encode("utf-8"))
                    self.wfile.flush()
        except Exception as e:
            logger.error("Error during streaming: %s", e)
            error_data = f"data: {json.dumps({'error': 'Internal server error'})}\n\n"
            self.wfile.write(error_data.encode("utf-8"))

        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()

    def _handle_openai_completion(self, request_data: dict[str, Any]) -> None:
        result = self.inference_runtime.infer_openai_completions(request_data)
        self._send_json_response(200, result)

    def _handle_openai_chat_completion(self, request_data: dict[str, Any]) -> None:
        result = self.inference_runtime.infer_openai_chat_completions(request_data)
        self._send_json_response(200, result)

    def _send_json_response(self, code: int, body: dict[str, Any]) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "null")
        self.end_headers()
        self.wfile.write(json.dumps(body).encode("utf-8"))

    def _send_json_error(self, code: int, err: str, detail: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("WWW-Authenticate", 'Bearer realm="lmf-chat"')
        self.end_headers()
        self.wfile.write(json.dumps({"error": err, "detail": detail}).encode("utf-8"))

    def do_GET(self) -> None:
        """Handle GET requests for health check."""
        if self.path == "/health":
            self._send_json_response(200, {"status": "healthy"})
        elif self.path == "/v1/models":
            self._send_json_response(200, {"object": "list", "data": self.inference_runtime.list_models()})
        else:
            self.send_error(405, "Method Not Allowed")

    def do_OPTIONS(self) -> None:
        """Handle CORS preflight requests."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "null")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-API-Key",
        )
        self.end_headers()

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        logger.info(
            "%s - - [%s] %s",
            self.client_address[0],
            self.log_date_time_string(),
            format % args,
        )


def create_handler_class(
    inference_runtime: InferenceRuntime,
    key_store: ApiKeyStore | None = None,
) -> type[ChatHandler]:
    """Factory: bind runtime and optional API key store."""

    class Handler(ChatHandler):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(inference_runtime, key_store, *args, **kwargs)

    return Handler


def _run_key_admin(api_keys_file: Path, args: argparse.Namespace) -> int:
    store = ApiKeyStore(api_keys_file)
    if args.generate_key is not None:
        label = args.generate_key.strip() or "unnamed"
        raw = store.generate_key(label)
        print("API key created (save it now; it will not be shown again):")
        print(raw)
        print(f"(label={label!r}, file={api_keys_file})")
        return 0
    if args.list_keys:
        rows = store.list_meta()
        if not rows:
            print("(no keys)")
            return 0
        for m in rows:
            print(f"{m.key_id}\t{m.created}\t{m.label}")
        return 0
    if args.revoke_key:
        ok = store.revoke(args.revoke_key)
        if not ok:
            logger.error("No key with that id: %s", args.revoke_key)
            return 1
        print(f"Revoked key id {args.revoke_key!r}")
        return 0
    return 1


def run_chat_server() -> int:
    """CLI entry: inference server and/or API key management."""
    parser = argparse.ArgumentParser(description="HTTP streaming inference server (or API key admin)")
    parser.add_argument(
        "--config",
        help="Path to inference configuration YAML (required to start the server)",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument(
        "--api-keys-file",
        type=Path,
        help="JSON file storing key hashes. If set, POST /chat requires Authorization: Bearer <key> or X-API-Key.",
    )
    parser.add_argument(
        "--generate-key",
        metavar="LABEL",
        help="Create a new API key with this label, print the secret once, and exit (requires --api-keys-file)",
    )
    parser.add_argument(
        "--list-keys",
        action="store_true",
        help="List key ids and labels (requires --api-keys-file); no secrets printed",
    )
    parser.add_argument(
        "--revoke-key",
        metavar="KEY_ID",
        help="Remove a key by id (requires --api-keys-file)",
    )

    args = parser.parse_args()
    key_admin = (
        args.generate_key is not None
        or args.list_keys
        or args.revoke_key is not None
    )

    if args.api_keys_file is None and key_admin:
        logger.error("--api-keys-file is required for --generate-key / --list-keys / --revoke-key")
        return 1

    if key_admin:
        if not args.api_keys_file:
            return 1
        return _run_key_admin(args.api_keys_file, args)

    if not args.config:
        logger.error("--config is required to start the server (unless using key admin flags)")
        return 1

    if not Path(args.config).exists():
        logger.error("Config file not found: %s", args.config)
        return 1

    key_store: ApiKeyStore | None = None
    if args.api_keys_file is not None:
        key_store = ApiKeyStore(args.api_keys_file)
        n = key_store.key_count()
        if n == 0:
            logger.warning(
                "API key file %s has no keys; POST /chat will return 401 until you run: "
                "lmf chat --api-keys-file %s --generate-key <label>",
                args.api_keys_file,
                args.api_keys_file,
            )
        else:
            logger.info("API key auth enabled (%d key(s)); /chat requires Bearer or X-API-Key", n)

    logger.info("Loading inference configuration from: %s", args.config)

    try:
        inference_runtime = InferenceRuntime(args.config)
    except Exception as e:
        logger.error("Failed to initialize inference runtime: %s", e)
        return 1

    handler_class = create_handler_class(inference_runtime, key_store)
    server = ThreadingHTTPServer((args.host, args.port), handler_class)

    logger.info("Starting chat server on http://%s:%s", args.host, args.port)
    logger.info("Health check: http://%s:%s/health", args.host, args.port)
    logger.info("Chat endpoint: http://%s:%s/chat", args.host, args.port)
    logger.info("OpenAI completions: http://%s:%s/v1/completions", args.host, args.port)
    logger.info("OpenAI chat completions: http://%s:%s/v1/chat/completions", args.host, args.port)
    logger.info("Model discovery: http://%s:%s/v1/models", args.host, args.port)
    logger.info("Press Ctrl+C to stop the server")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Shutting down chat server...")
        server.shutdown()

    return 0


def main() -> int:
    """Entry point for the ``lmf-chat-server`` console script and ``python -m`` use."""
    return int(run_chat_server() or 0)


if __name__ == "__main__":

    raise SystemExit(main())
