# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Persistent API key storage for the HTTP chat inference server."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


KEY_STORE_VERSION = 1
KEY_PREFIX = "lmf_"


def _hash_secret(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


@dataclass
class ApiKeyMeta:
    """Non-secret metadata for one key (for list/revoke)."""

    key_id: str
    label: str
    created: str


class ApiKeyStore:
    """Load/save API keys as SHA-256 hashes in a JSON file."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path).expanduser()

    def _load_raw(self) -> dict[str, Any]:
        if not self.path.is_file():
            return {"version": KEY_STORE_VERSION, "keys": []}
        text = self.path.read_text(encoding="utf-8")
        data = json.loads(text) if text.strip() else {}
        if not isinstance(data, dict):
            raise ValueError(f"Invalid API key file format: {self.path}")
        keys = data.get("keys")
        if keys is None:
            data["keys"] = []
        elif not isinstance(keys, list):
            raise ValueError(f"Invalid API key file: 'keys' must be a list: {self.path}")
        data.setdefault("version", KEY_STORE_VERSION)
        return data

    def save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        payload = json.dumps(data, indent=2, sort_keys=True) + "\n"
        tmp.write_text(payload, encoding="utf-8")
        tmp.replace(self.path)
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    def generate_key(self, label: str) -> str:
        """Append a new key; returns the raw secret once (never stored)."""
        data = self._load_raw()
        raw = KEY_PREFIX + secrets.token_urlsafe(32)
        entry = {
            "id": str(uuid.uuid4()),
            "label": (label or "unnamed").strip() or "unnamed",
            "secret_hash": _hash_secret(raw),
            "created": _utc_now_iso(),
        }
        data["keys"].append(entry)
        self.save(data)
        return raw

    def verify(self, raw: str | None) -> bool:
        if not raw or not isinstance(raw, str):
            return False
        digest = _hash_secret(raw.strip())
        data = self._load_raw()
        for entry in data.get("keys", []):
            stored = entry.get("secret_hash")
            if isinstance(stored, str) and hmac.compare_digest(digest, stored):
                return True
        return False

    def list_meta(self) -> list[ApiKeyMeta]:
        data = self._load_raw()
        out: list[ApiKeyMeta] = []
        for entry in data.get("keys", []):
            out.append(
                ApiKeyMeta(
                    key_id=str(entry.get("id", "")),
                    label=str(entry.get("label", "")),
                    created=str(entry.get("created", "")),
                )
            )
        return out

    def revoke(self, key_id: str) -> bool:
        data = self._load_raw()
        before = len(data["keys"])
        data["keys"] = [k for k in data["keys"] if str(k.get("id", "")) != key_id]
        if len(data["keys"]) == before:
            return False
        self.save(data)
        return True

    def key_count(self) -> int:
        return len(self._load_raw().get("keys", []))
