# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from llamafactory.ec2.inference_request import _load_endpoint_from_pipeline
from llamafactory.ec2.inference_runner import run_ec2_inference


@dataclass
class BenchmarkConfig:
    backend_profile: str
    mode: str
    endpoint: str
    api_key: str
    ec2_pipeline_config: str
    model: str
    max_workers: int
    output_dir: str
    leaderboard_path: str
    request_defaults: dict[str, Any]
    general_checks: list[dict[str, Any]]
    custom_jsonl: dict[str, Any]


def _load_config(path: str) -> BenchmarkConfig:
    cfg_path = Path(path).expanduser().resolve()
    with open(cfg_path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError("Benchmark config YAML must be a mapping.")

    backend = data.get("backend", {}) if isinstance(data.get("backend"), dict) else {}
    run = data.get("run", {}) if isinstance(data.get("run"), dict) else {}
    tasks = data.get("tasks", {}) if isinstance(data.get("tasks"), dict) else {}
    inference = data.get("inference", {}) if isinstance(data.get("inference"), dict) else {}
    leaderboard = data.get("leaderboard", {}) if isinstance(data.get("leaderboard"), dict) else {}

    profile = str(backend.get("profile", "vllm") or "vllm").strip().lower()
    if profile not in {"vllm", "hf", "external_openai_compatible"}:
        raise ValueError("backend.profile must be one of: vllm, hf, external_openai_compatible.")

    return BenchmarkConfig(
        backend_profile=profile,
        mode=str(backend.get("mode", "attach") or "attach").strip().lower(),
        endpoint=str(backend.get("endpoint", "") or "").strip(),
        api_key=str(backend.get("api_key", "") or "").strip(),
        ec2_pipeline_config=str(backend.get("ec2_pipeline_config", "") or "").strip(),
        model=str(run.get("model", "") or "").strip(),
        max_workers=int(run.get("max_workers", 8) or 8),
        output_dir=str(run.get("output_dir", "saves/benchmarks") or "saves/benchmarks"),
        leaderboard_path=str(
            leaderboard.get("path", "saves/benchmarks/leaderboard.jsonl") or "saves/benchmarks/leaderboard.jsonl"
        ),
        request_defaults={k: v for k, v in inference.items() if v is not None},
        general_checks=tasks.get("general_checks", []) if isinstance(tasks.get("general_checks", []), list) else [],
        custom_jsonl=tasks.get("custom_jsonl", {}) if isinstance(tasks.get("custom_jsonl", {}), dict) else {},
    )


def _resolve_endpoint(cfg: BenchmarkConfig) -> str:
    if cfg.mode == "attach":
        if not cfg.endpoint:
            raise ValueError("backend.endpoint is required when backend.mode=attach.")
        return cfg.endpoint.rstrip("/")
    if cfg.mode == "ec2":
        if not cfg.ec2_pipeline_config:
            raise ValueError("backend.ec2_pipeline_config is required when backend.mode=ec2.")
        rc = run_ec2_inference(cfg.ec2_pipeline_config)
        if rc != 0:
            raise RuntimeError(f"EC2 inference startup failed with exit code {rc}.")
        host, port = _load_endpoint_from_pipeline(cfg.ec2_pipeline_config)
        return f"http://{host}:{port}"
    raise ValueError(f"Unsupported backend.mode={cfg.mode!r}. Use 'attach' or 'ec2'.")


def _post_json(url: str, payload: dict[str, Any], api_key: str, timeout_sec: int = 120) -> dict[str, Any]:
    req = urllib.request.Request(
        url=url,
        method="POST",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")
    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"HTTP {e.code} at {url}: {detail}") from e


def _get_json(url: str, api_key: str, timeout_sec: int = 30) -> dict[str, Any]:
    req = urllib.request.Request(url=url, method="GET")
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")
    with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _validate_backend_contract(base_url: str, api_key: str, model: str, request_defaults: dict[str, Any]) -> None:
    # /health is best-effort because OpenAI-compatible servers are not required to expose it.
    try:
        _get_json(f"{base_url}/health", api_key)
    except Exception:
        pass
    # /v1/models is preferred but tolerate non-standard response shapes.
    try:
        _get_json(f"{base_url}/v1/models", api_key)
    except Exception:
        pass

    probe_payload = {"model": model, "prompt": "ping", "max_tokens": 1, "temperature": 0, **request_defaults}
    response = _post_json(f"{base_url}/v1/completions", probe_payload, api_key, timeout_sec=30)
    if not isinstance(response, dict) or "choices" not in response:
        raise RuntimeError("Backend contract probe failed: /v1/completions did not return choices.")


def _run_general_checks(cfg: BenchmarkConfig, base_url: str) -> dict[str, Any]:
    checks = cfg.general_checks
    if not checks:
        return {"count": 0, "passed": 0, "results": []}

    url = f"{base_url}/v1/chat/completions"

    def _one(check: dict[str, Any]) -> dict[str, Any]:
        prompt = str(check.get("prompt", "")).strip()
        expected = check.get("expected_substrings", [])
        if not prompt:
            return {"id": check.get("id", "unknown"), "ok": False, "error": "missing prompt"}
        payload = {
            "model": cfg.model,
            "messages": [{"role": "user", "content": prompt}],
            **cfg.request_defaults,
        }
        response = _post_json(url, payload, cfg.api_key)
        content = response["choices"][0]["message"]["content"]
        ok = True
        for marker in expected:
            if str(marker) not in content:
                ok = False
                break
        return {
            "id": str(check.get("id", prompt[:40])),
            "ok": ok,
            "output": content,
            "expected_substrings": expected,
            "usage": response.get("usage", {}),
        }

    with ThreadPoolExecutor(max_workers=max(1, cfg.max_workers)) as pool:
        results = list(pool.map(_one, checks))
    passed = sum(1 for row in results if row.get("ok"))
    return {"count": len(results), "passed": passed, "results": results}


def _run_custom_jsonl(cfg: BenchmarkConfig, base_url: str) -> dict[str, Any]:
    custom = cfg.custom_jsonl
    path = str(custom.get("path", "")).strip()
    if not path:
        return {"count": 0, "passed": 0, "results": []}

    prompt_field = str(custom.get("prompt_field", "prompt"))
    expected_field = str(custom.get("expected_field", "expected"))
    ignore_case = bool(custom.get("ignore_case", True))
    mode = str(custom.get("match_mode", "contains")).strip().lower()
    timeout_sec = int(custom.get("timeout_sec", 120))
    url = f"{base_url}/v1/completions"
    rows = []
    with open(Path(path).expanduser().resolve(), encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if stripped:
                rows.append(json.loads(stripped))

    def _one(row: dict[str, Any]) -> dict[str, Any]:
        prompt = str(row.get(prompt_field, "") or "")
        expected = str(row.get(expected_field, "") or "")
        payload = {
            "model": cfg.model,
            "prompt": prompt,
            **cfg.request_defaults,
        }
        response = _post_json(url, payload, cfg.api_key, timeout_sec=timeout_sec)
        output = str(response["choices"][0].get("text", "") or "")
        lhs = output.lower() if ignore_case else output
        rhs = expected.lower() if ignore_case else expected
        if mode == "exact":
            ok = lhs == rhs
        else:
            ok = rhs in lhs
        return {
            "prompt": prompt,
            "expected": expected,
            "output": output,
            "ok": ok,
            "usage": response.get("usage", {}),
        }

    with ThreadPoolExecutor(max_workers=max(1, cfg.max_workers)) as pool:
        results = list(pool.map(_one, rows))
    passed = sum(1 for row in results if row.get("ok"))
    return {"count": len(results), "passed": passed, "results": results}


def _print_comparison(run_record: dict[str, Any], previous: dict[str, Any] | None) -> None:
    current_rate = run_record["summary"]["pass_rate"]
    if previous is None:
        print("comparison: no previous run found")
        print(f"current pass_rate: {current_rate:.2%}")
        return
    prev_rate = float(previous.get("summary", {}).get("pass_rate", 0.0))
    delta = current_rate - prev_rate
    print("comparison:")
    print(f"- previous run_id: {previous.get('run_id', 'n/a')}")
    print(f"- previous pass_rate: {prev_rate:.2%}")
    print(f"- current run_id: {run_record['run_id']}")
    print(f"- current pass_rate: {current_rate:.2%}")
    print(f"- delta: {delta:+.2%}")


def run_benchmark(config_path: str) -> int:
    cfg = _load_config(config_path)
    base_url = _resolve_endpoint(cfg)
    _validate_backend_contract(base_url, cfg.api_key, cfg.model, cfg.request_defaults)
    if not cfg.model:
        raise ValueError("run.model is required for benchmark requests.")

    started = int(time.time())
    general = _run_general_checks(cfg, base_url)
    custom = _run_custom_jsonl(cfg, base_url)
    total_count = int(general["count"]) + int(custom["count"])
    total_pass = int(general["passed"]) + int(custom["passed"])
    pass_rate = (total_pass / total_count) if total_count else 0.0

    run_record = {
        "run_id": f"bench-{started}",
        "timestamp": started,
        "backend_profile": cfg.backend_profile,
        "backend_mode": cfg.mode,
        "endpoint": base_url,
        "model": cfg.model,
        "summary": {
            "total_count": total_count,
            "total_pass": total_pass,
            "pass_rate": pass_rate,
        },
        "general_checks": general,
        "custom_jsonl": custom,
    }

    output_dir = Path(cfg.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    run_path = output_dir / f"{run_record['run_id']}.json"
    run_path.write_text(json.dumps(run_record, indent=2), encoding="utf-8")

    leaderboard_path = Path(cfg.leaderboard_path).expanduser().resolve()
    leaderboard_path.parent.mkdir(parents=True, exist_ok=True)
    previous = None
    if leaderboard_path.exists():
        lines = [line.strip() for line in leaderboard_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if lines:
            previous = json.loads(lines[-1])
    with open(leaderboard_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(run_record, ensure_ascii=True) + "\n")

    print(f"run artifact: {run_path}")
    print(f"leaderboard: {leaderboard_path}")
    _print_comparison(run_record, previous)
    return 0


def run_benchmark_cli() -> int:
    parser = argparse.ArgumentParser(description="Run benchmark suite against OpenAI-compatible inference backend.")
    parser.add_argument("--config", required=True, help="Path to benchmark YAML config.")
    args = parser.parse_args()
    return run_benchmark(args.config)


__all__ = ["run_benchmark", "run_benchmark_cli"]
