#!/usr/bin/env python3
"""Arbitrary command pass-through with approval dialog."""

import hashlib
import os
import subprocess
import sys

import click

from ozm.approve import request_cmd_approval
from ozm.config import is_command_allowed, project_key
from ozm.run import load_hashes, save_hashes

CMD_PREFIX = "cmd:"


def _cmd_hash(command: str) -> str:
    return hashlib.sha256(command.encode()).hexdigest()


WRAPPERS = {"uv", "npx", "bunx", "poetry", "pipx", "run", "exec"}


def _find_script_in_args(args: tuple[str, ...]) -> tuple[str, str] | None:
    """Return (script_path, suggested_shebang) if args look like script execution."""
    interpreter = None
    for arg in args:
        if arg.startswith("-"):
            continue
        _, ext = os.path.splitext(arg)
        if ext and os.path.isfile(arg):
            shebang = f"#!/usr/bin/env {interpreter}" if interpreter else "#!/usr/bin/env <interpreter>"
            return arg, shebang
        if arg in WRAPPERS:
            continue
        if not interpreter and "/" not in arg:
            interpreter = arg
    return None


@click.command(
    "cmd",
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
@click.argument("command_and_args", nargs=-1, type=click.UNPROCESSED, required=True)
def cmd_cmd(command_and_args: tuple[str, ...]) -> None:
    """Run an arbitrary command after approval."""
    if not command_and_args:
        raise click.ClickException("Nothing to run.")

    match = _find_script_in_args(command_and_args)
    if match:
        script, shebang = match
        click.echo(
            f"ozm: use 'ozm run {script}' instead — "
            f"make sure the script has a shebang ({shebang})",
            err=True,
        )
        sys.exit(1)

    command = " ".join(command_and_args)

    if is_command_allowed(command):
        result = subprocess.run(command, shell=True)
        sys.exit(result.returncode)

    key = project_key(CMD_PREFIX + command)
    current_hash = _cmd_hash(command)
    hashes = load_hashes()

    if hashes.get(key) == current_hash:
        result = subprocess.run(command, shell=True)
        sys.exit(result.returncode)

    approval = request_cmd_approval(command)

    if approval.approved is True:
        run_command = approval.command or command
        run_key = project_key(CMD_PREFIX + run_command)
        run_hash = _cmd_hash(run_command)
        hashes[run_key] = run_hash
        save_hashes(hashes)
        if run_command != command:
            click.echo(f"ozm: approved cmd (edited)", err=True)
        if approval.feedback:
            click.echo(f"ozm: {approval.feedback}", err=True)
        result = subprocess.run(run_command, shell=True)
        sys.exit(result.returncode)

    if approval.approved is False:
        if approval.feedback:
            click.echo(f"ozm: denied cmd — {approval.feedback}", err=True)
        else:
            click.echo("ozm: denied cmd", err=True)
        sys.exit(1)

    click.echo(f"ozm: {command}")
    click.echo("No approval dialog available. Review the command above.")
    sys.exit(1)
