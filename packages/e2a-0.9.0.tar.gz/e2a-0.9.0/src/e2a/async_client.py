from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Any, AsyncIterator, Optional

import httpx

from e2a.client import E2AError, _check_response, _serialize_attachments
from e2a.models import Attachment, MessageList, MessageSummary, SendResult

if TYPE_CHECKING:
    from e2a.handler import AsyncInboundEmail


class AsyncE2AClient:
    """Async client for the e2a API.

    Drop-in async replacement for :class:`E2AClient`. Use this in async
    frameworks like FastAPI to avoid blocking the event loop.

    .. code-block:: python

        from e2a import AsyncE2AClient

        # Single-agent: set agent_email at init
        client = AsyncE2AClient(
            api_key="e2a_...",
            agent_email="my-agent@agents.e2a.dev",
        )

        # Multi-agent webhook: omit agent_email, it auto-resolves from the payload
        client = AsyncE2AClient(api_key="e2a_...")

        @app.post("/webhook")
        async def webhook(request: Request):
            email = client.parse(await request.body())
            await email.reply("Got it!")  # uses email.recipient as agent_email
            return {"ok": True}

    Args:
        api_key: Your API key.
            Falls back to the ``E2A_API_KEY`` environment variable.
        agent_email: The agent's email address (e.g. ``"my-agent@agents.e2a.dev"``).
            Required for polling and direct reply/send methods. Falls back to
            ``E2A_AGENT_EMAIL``. Optional for webhook-only usage where
            ``AsyncInboundEmail.reply()`` auto-resolves it from the payload.
        base_url: e2a API base URL. Defaults to ``https://e2a.dev``.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_email: Optional[str] = None,
        base_url: str = "https://e2a.dev",
        timeout: float = 30,
    ) -> None:
        self.api_key = api_key or os.environ.get("E2A_API_KEY", "")
        self.agent_email = agent_email or os.environ.get("E2A_AGENT_EMAIL", "")
        self.base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def _require_agent_email(self, agent_email: Optional[str] = None) -> str:
        email = agent_email or self.agent_email
        if not email:
            raise ValueError(
                "agent_email is required. Pass it to AsyncE2AClient(), set E2A_AGENT_EMAIL, "
                "or use AsyncInboundEmail.reply() which auto-resolves it from the webhook payload."
            )
        return email

    # ── Webhook parsing ──────────────────────────────────────────────

    def parse(self, body: bytes, headers: dict[str, str] | None = None) -> "AsyncInboundEmail":
        """Parse a webhook payload, returning an AsyncInboundEmail.

        This method is synchronous (no I/O needed for parsing).
        The returned email's ``.reply()`` method is async.

        Args:
            body: Raw request body bytes.
            headers: HTTP request headers (currently unused, reserved for future use).

        Returns:
            A parsed :class:`AsyncInboundEmail` with async ``.reply()``.
        """
        from e2a.handler import build_inbound_email_async

        data = json.loads(body)
        return build_inbound_email_async(data, headers or {}, self)

    # ── Polling methods ──────────────────────────────────────────────

    async def get_messages(
        self,
        status: str = "unread",
        page_size: int = 50,
        token: str | None = None,
    ) -> MessageList:
        """Fetch messages for a poll-mode agent.

        Args:
            status: Filter by status — ``"unread"``, ``"read"``, or ``"all"``.
            page_size: Maximum number of messages to return (1–100).
            token: Opaque pagination token from a previous response's ``next_token``.

        Returns:
            A :class:`MessageList` with message summaries and pagination info.

        Raises:
            E2AError: If the API returns an error.
        """
        email = self._require_agent_email()
        params: dict[str, str] = {"status": status, "page_size": str(page_size)}
        if token:
            params["token"] = token

        resp = await self._client.get(f"/api/agents/{email}/messages", params=params)
        _check_response(resp)
        data = resp.json()
        messages = [
            MessageSummary(
                message_id=m["message_id"],
                conversation_id=m.get("conversation_id"),
                sender=m["from"],
                recipient=m["to"],
                subject=m.get("subject", ""),
                status=m.get("status", ""),
                created_at=m.get("created_at", ""),
            )
            for m in data.get("messages", [])
        ]
        return MessageList(messages=messages, next_token=data.get("next_token"))

    async def get_message(self, message_id: str) -> "AsyncInboundEmail":
        """Fetch a single message with full content (marks it as read).

        Returns the same :class:`AsyncInboundEmail` object as ``parse()`` — so
        ``.reply()`` works identically whether you use push or poll mode.

        Args:
            message_id: The message ID to fetch.

        Returns:
            A parsed :class:`AsyncInboundEmail` with async ``.reply()``.

        Raises:
            E2AError: If the API returns an error.
        """
        from e2a.handler import build_inbound_email_async

        email = self._require_agent_email()
        resp = await self._client.get(f"/api/agents/{email}/messages/{message_id}")
        _check_response(resp)
        data = resp.json()
        return build_inbound_email_async(data, {}, self)

    # ── API methods ────────────────────────────────────────────────────

    async def reply(
        self,
        message_id: str,
        body: str,
        html_body: Optional[str] = None,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
        agent_email: Optional[str] = None,
    ) -> SendResult:
        """Reply to an inbound email.

        Args:
            message_id: The ``message_id`` from the webhook payload.
            body: Plain-text reply body.
            html_body: Optional HTML body for rich replies.
            conversation_id: Optional opaque ID for your conversation/thread.
            attachments: Optional list of :class:`Attachment` objects to include.
            agent_email: Override the agent email for this call. Falls back to
                ``self.agent_email``.

        Returns:
            A SendResult with status, message_id, and delivery method.

        Raises:
            E2AError: If the API returns an error.
        """
        email = self._require_agent_email(agent_email)
        payload: dict = {"body": body}
        if html_body:
            payload["html_body"] = html_body
        if conversation_id:
            payload["conversation_id"] = conversation_id
        serialized = _serialize_attachments(attachments)
        if serialized:
            payload["attachments"] = serialized

        resp = await self._client.post(f"/api/agents/{email}/messages/{message_id}/reply", json=payload)
        _check_response(resp)
        data = resp.json()
        return SendResult(
            status=data["status"],
            message_id=data["message_id"],
            method=data["method"],
        )

    async def send(
        self,
        to: str,
        subject: str,
        body: str,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
        agent_email: Optional[str] = None,
    ) -> SendResult:
        """Send a new email.

        Args:
            to: Recipient email address.
            subject: Email subject.
            body: Email body.
            conversation_id: Optional opaque ID for your conversation/thread.
            attachments: Optional list of :class:`Attachment` objects to include.
            agent_email: Override the agent email for this call. Falls back to
                ``self.agent_email``.

        Returns:
            A SendResult with status, message_id, and delivery method.

        Raises:
            E2AError: If the API returns an error.
        """
        email = self._require_agent_email(agent_email)
        payload: dict = {"to": to, "subject": subject, "body": body, "from": email}
        if conversation_id:
            payload["conversation_id"] = conversation_id
        serialized = _serialize_attachments(attachments)
        if serialized:
            payload["attachments"] = serialized

        resp = await self._client.post("/api/send", json=payload)
        _check_response(resp)
        data = resp.json()
        return SendResult(
            status=data["status"],
            message_id=data["message_id"],
            method=data["method"],
        )

    def listen(
        self,
        agent_email: Optional[str] = None,
        reconnect: bool = True,
        max_backoff: float = 30.0,
    ) -> AsyncIterator["AsyncInboundEmail"]:
        """Listen for emails via WebSocket (requires ``websockets`` package).

        Connects to e2a's WebSocket endpoint and yields full
        :class:`AsyncInboundEmail` objects as they arrive. Handles
        reconnection with exponential backoff.

        Install the extra with ``pip install e2a[ws]``.

        .. code-block:: python

            async with AsyncE2AClient(api_key="e2a_...") as client:
                async for email in client.listen("my-agent@agents.e2a.dev"):
                    print(f"From: {email.sender}")
                    await email.reply("Got it!")

        Args:
            agent_email: The agent's email. Falls back to ``self.agent_email``.
            reconnect: Reconnect on disconnect. Defaults to True.
            max_backoff: Maximum reconnect delay in seconds. Defaults to 30.

        Yields:
            :class:`AsyncInboundEmail` objects as emails arrive.
        """
        from e2a.websocket import listen as _ws_listen

        return _ws_listen(
            client=self,
            agent_email=agent_email,
            reconnect=reconnect,
            max_backoff=max_backoff,
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> AsyncE2AClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
