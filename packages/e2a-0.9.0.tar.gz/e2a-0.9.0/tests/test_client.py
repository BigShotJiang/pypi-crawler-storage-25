import base64
import json

import httpx
import pytest

from e2a.client import E2AClient, E2AError
from e2a.models import MessageList, MessageSummary


def test_reply_success(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_123/reply",
        method="POST",
        json={"status": "sent", "message_id": "reply_456", "method": "smtp"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.reply("msg_123", "Thanks!")

    assert result.status == "sent"
    assert result.message_id == "reply_456"
    assert result.method == "smtp"

    request = httpx_mock.get_request()
    assert request.headers["Authorization"] == "Bearer e2a_test"
    body = json.loads(request.content)
    assert body == {"body": "Thanks!"}


def test_reply_with_html(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_123/reply",
        method="POST",
        json={"status": "sent", "message_id": "reply_789", "method": "smtp"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.reply("msg_123", "Thanks!", html_body="<p>Thanks!</p>")

    body = json.loads(httpx_mock.get_request().content)
    assert body == {"body": "Thanks!", "html_body": "<p>Thanks!</p>"}


def test_reply_not_found(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_bad/reply",
        method="POST",
        status_code=404,
        text="message not found",
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        with pytest.raises(E2AError) as exc_info:
            client.reply("msg_bad", "Hello")

    assert exc_info.value.status_code == 404
    assert "message not found" in exc_info.value.message


def test_send_success(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/send",
        method="POST",
        json={"status": "sent", "message_id": "send_abc", "method": "webhook"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.send("alice@example.com", "Hello", "Hi Alice")

    assert result.status == "sent"
    assert result.method == "webhook"

    body = json.loads(httpx_mock.get_request().content)
    assert body == {"to": "alice@example.com", "subject": "Hello", "body": "Hi Alice", "from": "bot@agent.dev"}


def test_send_unauthorized(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/send",
        method="POST",
        status_code=401,
        text="unauthorized",
    )

    with E2AClient(api_key="bad_key", agent_email="bot@agent.dev") as client:
        with pytest.raises(E2AError) as exc_info:
            client.send("alice@example.com", "Hello", "Hi")

    assert exc_info.value.status_code == 401


def test_reply_with_conversation_id(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_123/reply",
        method="POST",
        json={"status": "sent", "message_id": "reply_cid", "method": "smtp"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.reply("msg_123", "Thanks!", conversation_id="conv_abc")

    body = json.loads(httpx_mock.get_request().content)
    assert body == {"body": "Thanks!", "conversation_id": "conv_abc"}


def test_send_with_conversation_id(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/send",
        method="POST",
        json={"status": "sent", "message_id": "send_cid", "method": "smtp"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.send("alice@example.com", "Hello", "Hi", conversation_id="conv_xyz")

    body = json.loads(httpx_mock.get_request().content)
    assert body["conversation_id"] == "conv_xyz"


def test_client_init_from_env_vars(monkeypatch):
    monkeypatch.setenv("E2A_API_KEY", "e2a_env_key")
    monkeypatch.setenv("E2A_AGENT_EMAIL", "bot@agent.dev")

    client = E2AClient()
    assert client.api_key == "e2a_env_key"
    assert client.agent_email == "bot@agent.dev"
    client.close()


def test_client_init_explicit_overrides_env(monkeypatch):
    monkeypatch.setenv("E2A_API_KEY", "e2a_env_key")

    client = E2AClient(api_key="explicit_key", agent_email="bot@agent.dev")
    assert client.api_key == "explicit_key"
    client.close()


def test_client_allows_omitting_agent_email(monkeypatch):
    monkeypatch.delenv("E2A_AGENT_EMAIL", raising=False)

    client = E2AClient(api_key="e2a_test")
    assert client.agent_email == ""
    client.close()


def test_client_requires_agent_email_at_point_of_use(monkeypatch):
    monkeypatch.delenv("E2A_AGENT_EMAIL", raising=False)

    with E2AClient(api_key="e2a_test") as client:
        with pytest.raises(ValueError, match="agent_email is required"):
            client.get_messages()
        with pytest.raises(ValueError, match="agent_email is required"):
            client.reply("msg_123", "Hello")
        with pytest.raises(ValueError, match="agent_email is required"):
            client.send("alice@example.com", "Subject", "Body")


def test_custom_base_url(httpx_mock):
    httpx_mock.add_response(
        url="http://localhost:8080/api/send",
        method="POST",
        json={"status": "sent", "message_id": "local_123", "method": "smtp"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev", base_url="http://localhost:8080") as client:
        result = client.send("alice@example.com", "Test", "Body")

    assert result.message_id == "local_123"


# ── Polling (get_messages / get_message) ─────────────────────────


def test_get_messages(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        json={
            "messages": [
                {
                    "message_id": "msg_1",
                    "from": "alice@example.com",
                    "to": "bot@agent.dev",
                    "subject": "Hello",
                    "conversation_id": "conv_1",
                    "status": "unread",
                    "created_at": "2026-03-26T10:00:00Z",
                },
                {
                    "message_id": "msg_2",
                    "from": "bob@example.com",
                    "to": "bot@agent.dev",
                    "subject": "Hi",
                    "status": "unread",
                    "created_at": "2026-03-26T10:01:00Z",
                },
            ],
        },
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.get_messages()

    assert isinstance(result, MessageList)
    assert len(result.messages) == 2
    assert result.next_token is None

    msg = result.messages[0]
    assert msg.message_id == "msg_1"
    assert msg.sender == "alice@example.com"
    assert msg.recipient == "bot@agent.dev"
    assert msg.subject == "Hello"
    assert msg.conversation_id == "conv_1"
    assert msg.status == "unread"


def test_get_messages_with_params(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=all&page_size=10&token=abc123",
        method="GET",
        json={"messages": []},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.get_messages(status="all", page_size=10, token="abc123")

    assert result.messages == []
    assert result.next_token is None


def test_get_messages_empty(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        json={"messages": []},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.get_messages()

    assert result.messages == []
    assert result.next_token is None


def test_get_messages_error(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        status_code=403,
        text="this endpoint is only available for local-mode agents",
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        with pytest.raises(E2AError) as exc_info:
            client.get_messages()

    assert exc_info.value.status_code == 403


def test_get_messages_next_token(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        json={
            "messages": [
                {
                    "message_id": "msg_hm",
                    "from": "alice@example.com",
                    "to": "bot@agent.dev",
                    "subject": "More",
                    "status": "unread",
                    "created_at": "2026-03-26T10:00:00Z",
                },
            ],
            "next_token": "opaque_token_abc",
        },
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = client.get_messages()

    assert result.next_token == "opaque_token_abc"
    assert len(result.messages) == 1


def _make_raw_email():
    lines = [
        "From: alice@example.com",
        "To: bot@agent.dev",
        "Subject: Test Subject",
        "Content-Type: text/plain; charset=utf-8",
        "",
        "Hello from poll mode!",
    ]
    return "\r\n".join(lines).encode()


def test_get_message(httpx_mock):
    raw = _make_raw_email()
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_123",
        method="GET",
        json={
            "message_id": "msg_123",
            "from": "alice@example.com",
            "to": "bot@agent.dev",
            "subject": "Test Subject",
            "conversation_id": "conv_abc",
            "status": "read",
            "created_at": "2026-03-26T10:00:00Z",
            "auth_headers": {
                "X-E2A-Auth-Verified": "true",
                "X-E2A-Auth-Sender": "alice@example.com",
                "X-E2A-Auth-Entity-Type": "human",
            },
            "raw_message": base64.b64encode(raw).decode(),
        },
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        email = client.get_message("msg_123")

    assert email.message_id == "msg_123"
    assert email.sender == "alice@example.com"
    assert email.recipient == "bot@agent.dev"
    assert email.subject == "Test Subject"
    assert email.text_body == "Hello from poll mode!"
    assert email.conversation_id == "conv_abc"
    assert email.is_verified is True


def test_get_message_not_found(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_bad",
        method="GET",
        status_code=404,
        text="message not found",
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        with pytest.raises(E2AError) as exc_info:
            client.get_message("msg_bad")

    assert exc_info.value.status_code == 404


def test_get_message_reply(httpx_mock):
    raw = _make_raw_email()
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_poll",
        method="GET",
        json={
            "message_id": "msg_poll",
            "from": "alice@example.com",
            "to": "bot@agent.dev",
            "raw_message": base64.b64encode(raw).decode(),
            "auth_headers": {},
        },
    )
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_poll/reply",
        method="POST",
        json={"status": "sent", "message_id": "reply_poll", "method": "smtp"},
    )

    with E2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        email = client.get_message("msg_poll")
        result = email.reply("Got your message!")

    assert result.status == "sent"
    assert result.message_id == "reply_poll"
