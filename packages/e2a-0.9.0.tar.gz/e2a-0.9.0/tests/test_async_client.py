import base64
import json

import pytest

from e2a import AsyncE2AClient, AsyncInboundEmail
from e2a.models import MessageList


def _make_raw_email(subject="Hello", text="Hi there"):
    lines = [
        "From: alice@gmail.com",
        "To: bot@agent.example.com",
        f"Subject: {subject}",
        "Content-Type: text/plain; charset=utf-8",
        "",
        text,
    ]
    return "\r\n".join(lines).encode()


def _make_webhook_body(raw_email, message_id="msg_123", conversation_id=None):
    data = {
        "message_id": message_id,
        "from": "alice@gmail.com",
        "to": "bot@agent.example.com",
        "raw_message": base64.b64encode(raw_email).decode(),
        "auth_headers": {
            "X-E2A-Auth-Verified": "true",
            "X-E2A-Auth-Sender": "alice@gmail.com",
            "X-E2A-Auth-Entity-Type": "human",
        },
    }
    if conversation_id:
        data["conversation_id"] = conversation_id
    return json.dumps(data).encode()


@pytest.mark.anyio
async def test_async_reply(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_123/reply",
        method="POST",
        json={"status": "sent", "message_id": "reply_456", "method": "smtp"},
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = await client.reply("msg_123", "Thanks!")

    assert result.status == "sent"
    assert result.message_id == "reply_456"

    request = httpx_mock.get_request()
    assert request.headers["Authorization"] == "Bearer e2a_test"


@pytest.mark.anyio
async def test_async_send(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/send",
        method="POST",
        json={"status": "sent", "message_id": "send_abc", "method": "webhook"},
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = await client.send("alice@example.com", "Hello", "Hi", conversation_id="conv_1")

    body = json.loads(httpx_mock.get_request().content)
    assert body["conversation_id"] == "conv_1"
    assert result.method == "webhook"


@pytest.mark.anyio
async def test_async_parse():
    raw = _make_raw_email(subject="Test", text="Hello agent")
    body = _make_webhook_body(raw, conversation_id="conv_abc")

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        email = client.parse(body)

    assert isinstance(email, AsyncInboundEmail)
    assert email.message_id == "msg_123"
    assert email.sender == "alice@gmail.com"
    assert email.subject == "Test"
    assert email.text_body == "Hello agent"
    assert email.conversation_id == "conv_abc"
    assert email.is_verified is True



def test_async_client_init_from_env_vars(monkeypatch):
    monkeypatch.setenv("E2A_API_KEY", "e2a_env_async")
    monkeypatch.setenv("E2A_AGENT_EMAIL", "bot@agent.dev")

    client = AsyncE2AClient()
    assert client.api_key == "e2a_env_async"
    assert client.agent_email == "bot@agent.dev"


def test_async_client_init_explicit_overrides_env(monkeypatch):
    monkeypatch.setenv("E2A_API_KEY", "e2a_env_async")

    client = AsyncE2AClient(api_key="explicit", agent_email="bot@agent.dev")
    assert client.api_key == "explicit"


def test_async_client_allows_omitting_agent_email(monkeypatch):
    monkeypatch.delenv("E2A_AGENT_EMAIL", raising=False)

    client = AsyncE2AClient(api_key="e2a_test")
    assert client.agent_email == ""


@pytest.mark.anyio
async def test_async_client_requires_agent_email_at_point_of_use(monkeypatch):
    monkeypatch.delenv("E2A_AGENT_EMAIL", raising=False)

    async with AsyncE2AClient(api_key="e2a_test") as client:
        with pytest.raises(ValueError, match="agent_email is required"):
            await client.get_messages()
        with pytest.raises(ValueError, match="agent_email is required"):
            await client.reply("msg_123", "Hello")
        with pytest.raises(ValueError, match="agent_email is required"):
            await client.send("alice@example.com", "Subject", "Body")


# ── Async polling tests ─────────────────────────────────────────


@pytest.mark.anyio
async def test_get_messages_async(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        json={
            "messages": [
                {
                    "message_id": "msg_1",
                    "from": "alice@example.com",
                    "to": "bot@agent.dev",
                    "subject": "Hello",
                    "status": "unread",
                    "created_at": "2026-03-26T10:00:00Z",
                },
            ],
            "next_token": "opaque_token_abc",
        },
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = await client.get_messages()

    assert isinstance(result, MessageList)
    assert len(result.messages) == 1
    assert result.next_token == "opaque_token_abc"
    assert result.messages[0].message_id == "msg_1"


@pytest.mark.anyio
async def test_get_messages_async_with_params(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=all&page_size=10&token=tok_5",
        method="GET",
        json={"messages": []},
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = await client.get_messages(status="all", page_size=10, token="tok_5")

    assert result.messages == []
    assert result.next_token is None


@pytest.mark.anyio
async def test_get_messages_async_empty(httpx_mock):
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        json={"messages": []},
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        result = await client.get_messages()

    assert result.messages == []
    assert result.next_token is None


@pytest.mark.anyio
async def test_get_messages_async_error(httpx_mock):
    from e2a.client import E2AError

    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages?status=unread&page_size=50",
        method="GET",
        status_code=403,
        text="this endpoint is only available for local-mode agents",
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        with pytest.raises(E2AError) as exc_info:
            await client.get_messages()

    assert exc_info.value.status_code == 403


@pytest.mark.anyio
async def test_get_message_async(httpx_mock):
    raw = _make_raw_email(subject="Async Test", text="Async body")
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_async",
        method="GET",
        json={
            "message_id": "msg_async",
            "from": "alice@gmail.com",
            "to": "bot@agent.example.com",
            "raw_message": base64.b64encode(raw).decode(),
            "auth_headers": {
                "X-E2A-Auth-Verified": "true",
                "X-E2A-Auth-Sender": "alice@gmail.com",
            },
        },
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        email = await client.get_message("msg_async")

    assert isinstance(email, AsyncInboundEmail)
    assert email.message_id == "msg_async"
    assert email.text_body == "Async body"
    assert email.subject == "Async Test"


@pytest.mark.anyio
async def test_get_message_async_not_found(httpx_mock):
    from e2a.client import E2AError

    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_bad",
        method="GET",
        status_code=404,
        text="message not found",
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        with pytest.raises(E2AError) as exc_info:
            await client.get_message("msg_bad")

    assert exc_info.value.status_code == 404


@pytest.mark.anyio
async def test_get_message_async_reply(httpx_mock):
    raw = _make_raw_email(subject="Reply Test", text="Reply body")
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.dev/messages/msg_areply",
        method="GET",
        json={
            "message_id": "msg_areply",
            "from": "alice@gmail.com",
            "to": "bot@agent.example.com",
            "raw_message": base64.b64encode(raw).decode(),
            "auth_headers": {},
        },
    )
    httpx_mock.add_response(
        url="https://e2a.dev/api/agents/bot@agent.example.com/messages/msg_areply/reply",
        method="POST",
        json={"status": "sent", "message_id": "reply_async", "method": "smtp"},
    )

    async with AsyncE2AClient(api_key="e2a_test", agent_email="bot@agent.dev") as client:
        email = await client.get_message("msg_areply")
        result = await email.reply("Got it!")

    assert result.status == "sent"
    assert result.message_id == "reply_async"

