"""Exceptions hierarchy mirror des codes d'erreur de l'API."""
from __future__ import annotations

from typing import Any


class PermisAPIError(Exception):
    """Base : toute erreur renvoyee par l'API."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
        detail: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.detail = detail


class PermisAPIUnauthorized(PermisAPIError):
    """401 : cle manquante ou invalide."""


class PermisAPIForbidden(PermisAPIError):
    """403 : compte desactive."""


class PermisAPIRateLimited(PermisAPIError):
    """429 : quota minute atteint (retry apres X secondes)."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: int | None = None,
        status_code: int | None = None,
        error_code: str | None = None,
        detail: Any = None,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            error_code=error_code,
            detail=detail,
        )
        self.retry_after = retry_after


class PermisAPIQuotaExceeded(PermisAPIRateLimited):
    """Quota mensuel depasse : il faut upgrade ou attendre le prochain mois."""


class PermisAPIValidationError(PermisAPIError):
    """400 : un parametre n'est pas au bon format."""


class PermisAPINotFound(PermisAPIError):
    """404 : permit ou ressource inexistante."""


def error_from_response(status_code: int, payload: dict[str, Any]) -> PermisAPIError:
    """Construit la bonne sous-classe selon le status + payload de l'API."""
    error_code = payload.get("error")
    message = payload.get("message") or payload.get("detail") or "Erreur API"
    detail = payload.get("detail")

    if status_code == 401:
        return PermisAPIUnauthorized(
            message, status_code=status_code, error_code=error_code, detail=detail
        )
    if status_code == 403:
        return PermisAPIForbidden(
            message, status_code=status_code, error_code=error_code, detail=detail
        )
    if status_code == 404:
        return PermisAPINotFound(
            message, status_code=status_code, error_code=error_code, detail=detail
        )
    if status_code == 429:
        retry_after = payload.get("retry_after")
        if error_code == "quota_exceeded":
            return PermisAPIQuotaExceeded(
                message,
                retry_after=retry_after,
                status_code=status_code,
                error_code=error_code,
                detail=detail,
            )
        return PermisAPIRateLimited(
            message,
            retry_after=retry_after,
            status_code=status_code,
            error_code=error_code,
            detail=detail,
        )
    if status_code == 400:
        return PermisAPIValidationError(
            message, status_code=status_code, error_code=error_code, detail=detail
        )
    return PermisAPIError(
        message, status_code=status_code, error_code=error_code, detail=detail
    )
