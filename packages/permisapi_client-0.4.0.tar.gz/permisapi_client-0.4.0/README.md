# permisapi-client

Client Python officiel pour [PermisAPI](https://permisapi.fr) : accede aux 311k+ permis de construire France via une API REST moderne.

## Installation

```bash
pip install permisapi-client
```

## Quickstart

```python
from permisapi_client import PermisAPI

client = PermisAPI(api_key="pk_live_...")  # obtenue sur https://permisapi.fr/#pricing

# Liste
data = client.permits.list(dep_code="75", limit=10)
for permit in data["items"]:
    print(permit["num_pa"], permit["adr_localite_ter"])

# Recherche geographique (PostGIS)
nearby = client.permits.near(lat=48.85, lng=2.35, radius_m=500)

# Detail
permit = client.permits.get("PC 075 115 24 B0001")

# Stats par commune
stats = client.stats.commune("75115")
print(stats["total"], stats["granted"])

# Itere sur toutes les pages
for p in client.permits.iter_all(dep_code="75"):
    print(p["num_pa"])
```

## Async

```python
import asyncio
from permisapi_client import AsyncPermisAPI

async def main():
    async with AsyncPermisAPI(api_key="pk_live_...") as client:
        data = await client.permits.list(dep_code="75")
        async for p in client.permits.iter_all(dep_code="75"):
            print(p["num_pa"])

asyncio.run(main())
```

## Alertes webhook

```python
alert = client.alerts.create(
    name="Paris 18e renovations",
    center_lat=48.88,
    center_lng=2.35,
    radius_km=3,
    permit_types=["PC_LOGEMENT"],
    webhook_url="https://tonapp.fr/permisapi-hook",
)
# Le webhook_secret n'est renvoye QU'ICI. Stocke-le pour verifier les HMAC.
print(alert["webhook_secret"])
```

## Gestion des erreurs

```python
from permisapi_client import (
    PermisAPI,
    PermisAPIRateLimited,
    PermisAPIQuotaExceeded,
    PermisAPIUnauthorized,
)

try:
    client.permits.list()
except PermisAPIUnauthorized:
    print("Cle API invalide")
except PermisAPIQuotaExceeded as e:
    print(f"Quota mensuel atteint, retry dans {e.retry_after}s")
except PermisAPIRateLimited as e:
    print(f"Burst limit, retry dans {e.retry_after}s")
```

## Licence

MIT. Source : SDES, base Sitadel, data.gouv.fr (Licence Ouverte Etalab).

## Liens

- Documentation : https://permisapi.fr/docs
- Reference API complete : https://api.permisapi.fr/docs
- Changelog : https://permisapi.fr/changelog
