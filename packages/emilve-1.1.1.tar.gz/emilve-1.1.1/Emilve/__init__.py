# Emilve/__init__.py
from .core import CaseSensivity
from .Braces import Braces
# Al importar esto, se ejecuta el código que pusimos al final de AutoPip.py
from . import AutoPip