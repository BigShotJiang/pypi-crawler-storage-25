"""Report generation modules."""
