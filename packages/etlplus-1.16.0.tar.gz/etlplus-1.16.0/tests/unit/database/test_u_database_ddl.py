"""
:mod:`tests.unit.database.test_u_database_ddl` module.

Unit tests for :mod:`etlplus.database._ddl`.
"""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

import etlplus.database._ddl as ddl

# SECTION: PRAGMAS ========================================================== #

# pylint: disable=import-outside-toplevel,protected-access,unused-argument

# SECTION: FIXTURES ========================================================= #


@pytest.fixture(name='sample_spec')
def fixture_sample_spec() -> dict[str, object]:
    """Sample table specification for testing."""
    return {
        'schema': 'dbo',
        'table': 'widgets',
        'create_schema': False,
        'columns': [
            {
                'name': 'id',
                'type': 'INT',
                'nullable': False,
                'identity': {'seed': 1, 'increment': 1},
            },
            {
                'name': 'name',
                'type': 'NVARCHAR(255)',
                'nullable': True,
            },
        ],
        'primary_key': {
            'columns': ['id'],
        },
        'indexes': [
            {
                'name': 'IX_widgets_name',
                'columns': ['name'],
                'unique': True,
            },
        ],
        'foreign_keys': [],
    }


# SECTION: TESTS ============================================================ #


class TestLoadTableSpec:
    """Unit tests for :func:`load_table_spec`."""

    def test_json_import_error_is_reraised(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """
        Test that ImportError is re-raised for JSON specs.
        """
        spec_path = tmp_path / 'spec.json'
        spec_path.write_text('{}', encoding='utf-8')

        def _raise_import_error(self: object) -> dict[str, object]:
            raise ImportError('forced json import failure')

        monkeypatch.setattr(ddl.File, 'read', _raise_import_error)

        with pytest.raises(ImportError):
            ddl.load_table_spec(spec_path)

    def test_missing_yaml_dependency(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Test that loading a YAML spec without PyYAML raises RuntimeError."""
        yaml = pytest.importorskip('yaml')
        spec_path = tmp_path / 'spec.yaml'
        spec_path.write_text(
            yaml.safe_dump(sample_spec, sort_keys=False),
            encoding='utf-8',
        )
        import etlplus.file.yaml as file_mod

        def _raise_import_error() -> None:
            raise ImportError('forced failure for test')

        monkeypatch.setattr(file_mod, 'get_yaml', _raise_import_error)

        with pytest.raises(RuntimeError):
            ddl.load_table_spec(spec_path)

    def test_requires_mapping(self, tmp_path: Path) -> None:
        """Test that loading a spec requires a mapping at the top level."""
        spec_path = tmp_path / 'array.json'
        spec_path.write_text(
            json.dumps([{'not': 'mapping'}]),
            encoding='utf-8',
        )
        with pytest.raises(TypeError):
            ddl.load_table_spec(spec_path)

    @pytest.mark.parametrize(
        'extension',
        ['json', 'yaml'],
        ids=['json', 'yaml'],
    )
    def test_roundtrip(
        self,
        tmp_path: Path,
        extension: str,
        sample_spec: dict[str, object],
    ) -> None:
        """Test loading a table spec from JSON and YAML formats."""
        spec_path = tmp_path / f'spec.{extension}'
        materialized = deepcopy(sample_spec)
        if extension == 'json':
            spec_path.write_text(json.dumps(materialized), encoding='utf-8')
        else:
            yaml = pytest.importorskip('yaml')
            spec_path.write_text(
                yaml.safe_dump(materialized, sort_keys=False),
                encoding='utf-8',
            )

        loaded = ddl.load_table_spec(spec_path)
        assert loaded == materialized

    def test_unsupported_suffix(self, tmp_path: Path) -> None:
        """
        Test that loading a spec with an unsupported suffix raises ValueError.
        """
        spec_path = tmp_path / 'spec.txt'
        spec_path.write_text('{}', encoding='utf-8')

        with pytest.raises(
            ValueError,
            match=r'Spec must be \.json, \.yml, or \.yaml',
        ):
            ddl.load_table_spec(spec_path)


class TestRenderTableSql:
    """Unit tests for :func:`render_table_sql`."""

    def test_custom_template_path(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
    ) -> None:
        """Test rendering SQL with a custom template path."""
        template_path = tmp_path / 'custom.sql.j2'
        template_path.write_text('{{ spec.table }}', encoding='utf-8')

        sql = ddl.render_table_sql(
            sample_spec,
            template_path=str(template_path),
        )

        assert sql == f'{sample_spec["table"]}\n'

    def test_default_template(
        self,
        sample_spec: dict[str, object],
    ) -> None:
        """Test rendering SQL with the default template."""
        sql = ddl.render_table_sql(sample_spec)
        assert f'CREATE TABLE [dbo].[{sample_spec["table"]}' in sql
        assert '[id] INT' in sql

    def test_env_override(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Test rendering SQL with a template-path environment override."""
        template_path = tmp_path / 'env_template.sql.j2'
        template_path.write_text(
            '{{ spec.schema }}.{{ spec.table }}',
            encoding='utf-8',
        )
        monkeypatch.setenv('TEMPLATE_NAME', str(template_path))

        sql = ddl.render_table_sql(sample_spec, template=None)

        assert sql == 'dbo.widgets\n'

    def test_missing_template_path(
        self,
        sample_spec: dict[str, object],
    ) -> None:
        """Test that a missing template path raises FileNotFoundError."""
        missing = Path('/nonexistent/template.sql.j2')
        with pytest.raises(FileNotFoundError):
            ddl.render_table_sql(sample_spec, template_path=str(missing))

    @pytest.mark.parametrize(
        'payload',
        [
            [],
            ['not a mapping'],
            [{'not_template': 'value'}],
            {'template': 'wrong shape'},
        ],
    )
    def test_template_override_requires_template_text(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
        monkeypatch: pytest.MonkeyPatch,
        payload: object,
    ) -> None:
        """
        Test that template override payload must expose text at index 0.
        """
        template_path = tmp_path / 'bad_template.sql.j2'
        template_path.write_text('ignored', encoding='utf-8')

        class _Reader:
            def read(self) -> object:
                return payload

        monkeypatch.setattr(ddl._JINJA2_HANDLER, 'at', lambda _: _Reader())

        with pytest.raises(TypeError):
            ddl.render_table_sql(
                sample_spec,
                template_path=str(template_path),
            )

    def test_unknown_template_key(
        self,
        sample_spec: dict[str, object],
    ) -> None:
        """Test that an unknown template key raises ValueError."""
        with pytest.raises(ValueError, match='Unknown template key'):
            ddl.render_table_sql(
                sample_spec,
                template='does not exist',  # type: ignore[arg-type]
            )


class TestRenderTables:
    """Unit tests for :func:`render_tables`."""

    def test_preserves_input_order_when_any_spec_lacks_table_name(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
    ) -> None:
        """Test anonymous specs bypass dependency ordering."""
        template_path = tmp_path / 'names.sql.j2'
        template_path.write_text(
            '{{ spec.table|default(spec.columns[0].name) }}',
            encoding='utf-8',
        )
        anonymous = deepcopy(sample_spec)
        named = deepcopy(sample_spec)
        anonymous.pop('table')
        named['table'] = 'named'

        rendered = ddl.render_tables(
            [anonymous, named],
            template_path=template_path,
        )

        assert rendered == ['id\n', 'named\n']

    def test_rejects_duplicate_table_names(
        self,
        sample_spec: dict[str, object],
    ) -> None:
        """Test duplicate table specs fail instead of being overwritten."""
        duplicate = deepcopy(sample_spec)

        with pytest.raises(ValueError, match='Duplicate table spec name'):
            ddl.render_tables([sample_spec, duplicate])

    def test_renders_multiple_specs(
        self,
        sample_spec: dict[str, object],
    ) -> None:
        """Test rendering an iterable of table specs into SQL strings."""
        first = deepcopy(sample_spec)
        second = deepcopy(sample_spec)
        second['table'] = 'widgets_history'

        rendered = ddl.render_tables([first, second])

        assert len(rendered) == 2
        assert 'widgets' in rendered[0]
        assert 'widgets_history' in rendered[1]

    def test_renders_specs_in_foreign_key_dependency_order(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
    ) -> None:
        """Test that in-batch foreign-key dependencies render first."""
        template_path = tmp_path / 'names.sql.j2'
        template_path.write_text('{{ spec.table }}', encoding='utf-8')
        parent = deepcopy(sample_spec)
        child = deepcopy(sample_spec)
        parent['table'] = 'accounts'
        child['table'] = 'orders'
        child['foreign_keys'] = [
            {
                'columns': ['account_id'],
                'ref_table': 'accounts',
                'ref_columns': ['id'],
            },
        ]

        rendered = ddl.render_tables([child, parent], template_path=template_path)

        assert rendered == ['accounts\n', 'orders\n']

    def test_orders_by_name_key_when_table_key_is_blank(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
    ) -> None:
        """Test table-name resolution falls back to a nonblank name key."""
        template_path = tmp_path / 'names.sql.j2'
        template_path.write_text('{{ spec.name }}', encoding='utf-8')
        parent = deepcopy(sample_spec)
        child = deepcopy(sample_spec)
        parent['table'] = ' '
        parent['name'] = 'accounts'
        child['table'] = ' '
        child['name'] = 'orders'
        child['foreign_keys'] = [{'ref_table': 'accounts'}]

        rendered = ddl.render_tables([child, parent], template_path=template_path)

        assert rendered == ['accounts\n', 'orders\n']


class TestRenderTablesToString:
    """
    Unit tests for :func:`render_tables_to_string`.
    """

    def test_custom_template(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
    ) -> None:
        """Test rendering multiple table specs with a custom template."""
        template_path = tmp_path / 'concat_template.sql.j2'
        template_path.write_text('{{ spec.table }}', encoding='utf-8')

        path = tmp_path / 'spec.json'
        path.write_text(json.dumps(sample_spec), encoding='utf-8')

        sql = ddl.render_tables_to_string(
            [path],
            template_path=template_path,
        )

        assert sql == f'{sample_spec["table"]}\n'

    def test_from_paths(
        self,
        tmp_path: Path,
        sample_spec: dict[str, object],
    ) -> None:
        """
        Test rendering multiple table specs from file paths to one SQL
        string.
        """
        spec_paths: list[Path] = []
        for idx, table_name in enumerate(('widgets', 'widgets_history')):
            materialized = deepcopy(sample_spec)
            materialized['table'] = table_name
            path = tmp_path / f'spec_{idx}.json'
            path.write_text(json.dumps(materialized), encoding='utf-8')
            spec_paths.append(path)

        sql = ddl.render_tables_to_string(spec_paths)

        assert 'widgets' in sql
        assert 'widgets_history' in sql

    def test_templates_constant_exposes_builtin_keys(self) -> None:
        """Test that ``TEMPLATES`` constant includes expected built-in keys."""
        assert {'ddl', 'view'}.issubset(set(ddl.TEMPLATES))
