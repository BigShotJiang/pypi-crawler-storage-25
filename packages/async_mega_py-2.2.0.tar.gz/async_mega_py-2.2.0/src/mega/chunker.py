from __future__ import annotations

import dataclasses
import logging
from collections.abc import Generator
from typing import TYPE_CHECKING, NamedTuple

from Crypto.Cipher import AES
from Crypto.Util import Counter

from mega.crypto import EMPTY_IV, a32_to_bytes, pad_bytes, str_to_a32

if TYPE_CHECKING:
    from collections.abc import Generator


logger = logging.getLogger(__name__)


class ChunkBoundary(NamedTuple):
    offset: int
    size: int


def get_chunks(size: int) -> Generator[ChunkBoundary]:
    """Yield chunk boundaries for Mega's MAC computation.

    Chunk sizes double from 128 KiB (0x20000) up to 1 MiB (0x100000).
    The last chunk may be smaller
    """
    offset = 0
    current_size = init_size = 0x20000
    while offset + current_size < size:
        yield ChunkBoundary(offset, current_size)
        offset += current_size
        if current_size < 0x100000:
            current_size += init_size
    yield ChunkBoundary(offset, size - offset)


@dataclasses.dataclass(slots=True)
class MegaChunker:
    """Decrypts/encrypts a flow of chunks using AES-128-CCM (CTR + CBC-MAC) algorithm"""

    key: tuple[int, int, int, int]
    iv: tuple[int, int]
    expected_meta_mac: tuple[int, int] | None = None

    _gen: Generator[bytes, bytes | None, tuple[int, int]] = dataclasses.field(init=False, repr=False)
    _computed_meta_mac: tuple[int, int] | None = dataclasses.field(init=False, default=None)

    def __post_init__(self) -> None:
        self._gen = _iter_chunks(self.key, self.iv, decrypt=bool(self.expected_meta_mac))
        _ = next(self._gen)

    def read(self, raw_chunk: bytes) -> bytes:
        return self._gen.send(raw_chunk)

    def compute_meta_mac(self) -> tuple[int, int]:
        if self._computed_meta_mac is None:
            try:
                _ = self._gen.send(None)
            except StopIteration as e:
                self._computed_meta_mac = e.value
            else:
                raise RuntimeError
        assert self._computed_meta_mac
        return self._computed_meta_mac

    def check_integrity(self) -> None:
        if not self.expected_meta_mac:
            raise RuntimeError
        meta_mac = self.compute_meta_mac()
        if self.expected_meta_mac != meta_mac:
            raise RuntimeError("Mismatched mac")


def _iter_chunks(
    key: tuple[int, int, int, int],
    iv: tuple[int, int],
    *,
    decrypt: bool,
) -> Generator[bytes, bytes | None, tuple[int, int]]:
    """AES-128-CCM (CTR + CBC-MAC) implementation"""
    # TODO: pycrypto probably has its own implementation
    key_bytes = a32_to_bytes(key)
    mac_bytes = EMPTY_IV
    iv_bytes = a32_to_bytes([iv[0], iv[1], iv[0], iv[1]])
    nonce = ((iv[0] << 32) + iv[1]) << 64

    aes = AES.new(key_bytes, AES.MODE_CTR, counter=Counter.new(128, initial_value=nonce))
    mac_cypher = AES.new(key_bytes, AES.MODE_CBC, EMPTY_IV)
    data_in: bytes | None = yield b""

    while data_in is not None:
        if not data_in:
            data_in = yield b""
            continue

        if decrypt:
            decrypted_data = data_out = aes.decrypt(data_in)
        else:
            decrypted_data = data_in
            data_out = aes.encrypt(data_in)

        mem_view = memoryview(decrypted_data)
        last_block_index = (len(decrypted_data) % AES.block_size) or AES.block_size
        last_block = pad_bytes(mem_view[-last_block_index:])

        chunk_cypher = AES.new(key_bytes, AES.MODE_CBC, iv_bytes)
        chunk_cypher.encrypt(mem_view[:-last_block_index])
        mac_bytes = mac_cypher.encrypt(chunk_cypher.encrypt(last_block))
        data_in = yield data_out

    file_mac = str_to_a32(mac_bytes)
    meta_mac = file_mac[0] ^ file_mac[1], file_mac[2] ^ file_mac[3]
    return meta_mac
