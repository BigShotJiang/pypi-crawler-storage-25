"""A read-only representation of the Mega.nz's filesystem

NOTE: Mega's filesystem is **not POSIX-compliant**: multiple nodes may have the same path
"""

from __future__ import annotations

import dataclasses
import errno
from pathlib import PurePosixPath
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, NamedTuple, Self

from mega.data_structures import Node, NodeID, NodeType, _DictDumper
from mega.errors import MultipleNodesFoundError

if TYPE_CHECKING:
    from collections.abc import Generator, Iterable, Iterator
    from os import PathLike

POSIX_ROOT: Final = PurePosixPath("/")


class _NodeLookup(NamedTuple):
    node_id: NodeID
    path: PurePosixPath
    was_deleted: bool


def _resolve_paths(walker: _NodeWalker, *roots: Node) -> Generator[_NodeLookup]:
    def walk(node_id: str, current_path: PurePosixPath) -> Generator[tuple[NodeID, PurePosixPath]]:
        for node in walker.iterdir(node_id):
            node_path = current_path / node.attributes.name
            yield node.id, node_path

            if not node.is_file:
                yield from walk(node.id, node_path)

    for root in roots:
        name = root.attributes.name
        path = POSIX_ROOT if root.type is NodeType.ROOT_FOLDER else POSIX_ROOT / name

        yield _NodeLookup(root.id, path, False)
        deleted = root.type is NodeType.TRASH
        for child_id, child_path in walk(root.id, path):
            yield _NodeLookup(child_id, child_path, deleted)


@dataclasses.dataclass(slots=True, frozen=True, kw_only=True, weakref_slot=True)
class _NodeWalker:
    _nodes: MappingProxyType[NodeID, Node] = dataclasses.field(repr=False)
    _children: MappingProxyType[NodeID, tuple[NodeID, ...]] = dataclasses.field(repr=False)

    def _ls(self, node_id: NodeID, *, recursive: bool) -> Iterable[NodeID]:
        """Get ID of every child of this node"""
        for child_id in self._children.get(node_id, ()):
            yield child_id
            if recursive:
                yield from self._ls(child_id, recursive=recursive)

    def iterdir(self, node_id: NodeID, *, recursive: bool = False) -> Iterable[Node]:
        """Iterate over the children in this node"""
        for child_id in self._ls(node_id, recursive=recursive):
            yield self._nodes[child_id]

    def listdir(self, node_id: NodeID) -> list[Node]:
        """Get a list of children of this node (non recursive)"""
        return list(self.iterdir(node_id))


@dataclasses.dataclass(slots=True, frozen=True, kw_only=True, weakref_slot=True)
class SimpleFileSystem(_NodeWalker, _DictDumper):
    """A simple representation of Mega.nz's file system.

    Supports lookups and traversal of nodes by node ID.
    """

    root: Node | None
    inbox: Node | None
    trash_bin: Node | None

    file_count: int
    folder_count: int

    def __len__(self) -> int:
        return len(self.nodes)

    def __iter__(self) -> Iterator[Node]:
        return iter(self.nodes.values())

    def __contains__(self, item: object) -> bool:
        return item in self.nodes

    def __getitem__(self, node_id: NodeID) -> Node:
        """Get the node with this ID"""
        return self.nodes[node_id]

    @property
    def nodes(self) -> MappingProxyType[NodeID, Node]:
        """A mapping of every node"""
        return self._nodes

    @property
    def children(self) -> MappingProxyType[NodeID, tuple[NodeID, ...]]:
        """A mapping of nodes to their inmediate children"""
        return self._children

    @property
    def deleted(self) -> Iterable[Node]:
        """Files or folders currently on the trash bin (Non recursive)"""
        if self.trash_bin:
            yield from self.iterdir(self.trash_bin.id)

    @classmethod
    def build(cls, nodes: Iterable[Node]) -> Self:
        root = inbox = trash_bin = None
        file_count = folder_count = 0

        nodes_map: dict[NodeID, Node] = {}
        children: dict[NodeID, list[NodeID]] = {}

        for node in nodes:
            nodes_map[node.id] = node
            if node.parent_id:
                children.setdefault(node.parent_id, []).append(node.id)
            match node.type:
                case NodeType.FILE:
                    file_count += 1
                case NodeType.FOLDER:
                    folder_count += 1
                case NodeType.ROOT_FOLDER:
                    root = node
                case NodeType.INBOX:
                    inbox = node
                case NodeType.TRASH:
                    trash_bin = node
                case _:
                    raise RuntimeError  # pyright: ignore[reportUnreachable]

        return cls(
            root=root,
            inbox=inbox,
            trash_bin=trash_bin,
            file_count=file_count,
            folder_count=folder_count,
            _nodes=MappingProxyType(nodes_map),
            _children=MappingProxyType({node_id: tuple(nodes) for node_id, nodes in children.items()}),
        )

    def dump(self) -> dict[str, Any]:
        """Get a JSONable dict representation of this object"""
        return dict(  # noqa: C408
            file_count=self.file_count,
            folder_count=self.folder_count,
            root=self.root.dump() if self.root else None,
            inbox=self.inbox.dump() if self.inbox else None,
            trash_bin=self.trash_bin.dump() if self.trash_bin else None,
            nodes={node_id: node.dump() for node_id, node in self.nodes.items()},
        )

    @classmethod
    def from_dump(cls, dump: dict[str, Any], /) -> Self:
        return cls.build(Node.from_dump(node) for node in dump["nodes"].values())


@dataclasses.dataclass(slots=True, frozen=True, kw_only=True, weakref_slot=True)
class FileSystem(SimpleFileSystem):
    """Mega.nz's file system.

    - Supports lookups and traversal of nodes by node ID.
    - Supports lookups and traversal of nodes by their paths.

    NOTE: Mega's filesystem is **not POSIX-compliant**: multiple nodes may have the same path
    """

    _paths: MappingProxyType[NodeID, PurePosixPath] = dataclasses.field(repr=False)
    _inv_paths: MappingProxyType[PurePosixPath, tuple[NodeID, ...]] = dataclasses.field(repr=False)
    _deleted: frozenset[NodeID] = dataclasses.field(repr=False)

    @classmethod
    def build(cls, nodes: Iterable[Node]) -> Self:
        # This is really expensive
        # We do 5 loops over all nodes:
        # SimpleFileSystem:
        # - 1. Create a map to all nodes
        # - 2. Freeze children (list -> tuple)
        #
        # FileSystem:
        # - 3. Resolve their paths
        # - 4. Sort their paths
        # - 5. Freeze inv paths (list -> tuple)

        self = SimpleFileSystem.build(nodes)

        roots = list(filter(None, (self.root, self.inbox, self.trash_bin))) or [next(iter(self.nodes.values()))]
        paths: dict[NodeID, PurePosixPath] = {}
        inv_paths: dict[PurePosixPath, list[NodeID]] = {}
        deleted_ids: set[NodeID] = set()

        for node_id, path, was_deleted in sorted(_resolve_paths(self, *roots), key=lambda x: str(x[1]).casefold()):
            paths[node_id] = path
            inv_paths.setdefault(path, []).append(node_id)
            if was_deleted:
                deleted_ids.add(node_id)

        return cls(
            root=self.root,
            inbox=self.inbox,
            trash_bin=self.trash_bin,
            file_count=self.file_count,
            folder_count=self.folder_count,
            _nodes=self.nodes,
            _children=self.children,
            _paths=MappingProxyType(paths),
            _inv_paths=MappingProxyType({path: tuple(nodes) for path, nodes in inv_paths.items()}),
            _deleted=frozenset(deleted_ids),
        )

    @property
    def paths(self) -> MappingProxyType[NodeID, PurePosixPath]:
        """A mapping of every node to its absolute path within the filesystem"""
        return self._paths

    @property
    def inv_paths(self) -> MappingProxyType[PurePosixPath, tuple[NodeID, ...]]:
        """A mapping of paths to every node located at that path

        Mega's filesystem is **not POSIX-compliant**: multiple nodes may have the same path
        """
        return self._inv_paths

    @property
    def files(self) -> Iterable[Node]:
        """All files that are NOT deleted (recursive)"""
        for node in self:
            if node.is_file and node.id not in self._deleted:
                yield node

    @property
    def folders(self) -> Iterable[Node]:
        """All folders that are NOT deleted (recursive)"""
        for node in self:
            if node.is_folder and node.id not in self._deleted:
                yield node

    def dirmap(self, node_id: str, *, recursive: bool = False) -> dict[NodeID, PurePosixPath]:
        """Creates a mapping from `node id` -> `Path` only including children of this node"""
        pairs = (
            (child_id, self.absolute_path(child_id))
            for child_id in self._ls(
                node_id,
                recursive=recursive,
            )
        )
        return dict(sorted(pairs, key=lambda x: str(x[1]).casefold()))

    def relative_path(self, node_id: NodeID) -> PurePosixPath:
        """Get the path of this node relative to the root folder"""
        return self.absolute_path(node_id).relative_to(POSIX_ROOT)

    def absolute_path(self, node_id: NodeID) -> PurePosixPath:
        """Get the absolute path of this node"""
        return self._paths[node_id]

    def search(
        self,
        query: str | PathLike[str],
        *,
        exclude_deleted: bool = True,
    ) -> Iterable[tuple[NodeID, PurePosixPath]]:
        """Returns nodes that have "query" as a substring on their path"""
        query = PurePosixPath(query).as_posix()

        for node_id, path in self._paths.items():
            if query not in path.as_posix():
                continue

            if exclude_deleted and node_id in self._deleted:
                continue

            yield node_id, path

    def find(self, path: str | PathLike[str]) -> Node:
        """Return the single node located at *path*.

        NOTE: Mega's filesystem is **not POSIX-compliant**: multiple nodes may have the same path

        Raises `MultipleNodesFoundError` if more that one node has this path

        Raises `FileNotFoundError` if this path does not exists on the filesystem

        """
        path = POSIX_ROOT / PurePosixPath(path)
        try:
            nodes = self._inv_paths[path]
        except LookupError:
            msg = f'A node with path "{path!s}" does not exists'
            raise FileNotFoundError(errno.ENOENT, msg) from None
        else:
            if len(nodes) > 1:
                msg = f'There is more that one node with path = "{path!s}"'
                raise MultipleNodesFoundError(msg, nodes)

            assert nodes
            return self[nodes[0]]

    def files_from(self, node_id: NodeID | None) -> Iterable[Node]:
        """Yield every file that is reachable from `node_id`.

        - If `node_id` is `None`: yield all non deleted files on the file system.
        - If `node_id` points to a file: yield only that file.
        - Any other case: yield all files within that node (recursively).

        """
        if not node_id:
            yield from self.files
            return

        root = self[node_id]
        if root.is_file:
            yield root
        else:
            for child in self.iterdir(root.id, recursive=True):
                if child.is_file:
                    yield child

    def dump(self, *, simple: bool = False) -> dict[str, Any]:
        """Get a JSONable dict representation of this object"""
        dump = super(FileSystem, self).dump()
        if simple:
            return dump

        return dump | dict(  # noqa: C408
            deleted=sorted(self._deleted),
            paths={node_id: str(path) for node_id, path in self._paths.items()},
            inv_paths={str(path): node_id for path, node_id in self._inv_paths.items()},
            children=dict(self.children),
        )


@dataclasses.dataclass(slots=True, frozen=True, kw_only=True, weakref_slot=True)
class UserFileSystem(FileSystem):
    root: Node
    inbox: Node
    trash_bin: Node

    @classmethod
    def build_unsafe(cls, nodes: Iterable[Node]) -> Self:
        """Build a filesystem from a pre-ordered node stream without validation

        Nodes MUST be topologically sorted:
        - The first three nodes are ROOT, INBOX and TRASH_BIN.
        - Every parent appears before its descendants.
        """
        # Build fs using only 3 loops:
        # - 1. Create a map to all nodes and resolve their paths
        # - 2. Freeze children (list -> tuple)
        # - 3. Freeze inv paths (list -> tuple)
        root = inbox = trash_bin = None
        file_count = folder_count = 0

        paths: dict[NodeID, PurePosixPath] = {}
        inv_paths: dict[PurePosixPath, list[NodeID]] = {}
        deleted_ids: set[NodeID] = set()
        nodes_map: dict[NodeID, Node] = {}
        children: dict[NodeID, list[NodeID]] = {}
        trash_bin_id = None

        for node in nodes:
            nodes_map[node.id] = node
            if node.parent_id:
                children.setdefault(node.parent_id, []).append(node.id)

            path = None
            match node.type:
                case NodeType.FILE:
                    file_count += 1
                case NodeType.FOLDER:
                    folder_count += 1
                case NodeType.ROOT_FOLDER:
                    path = POSIX_ROOT
                    root = node
                case NodeType.INBOX:
                    path = POSIX_ROOT / node.attributes.name
                    inbox = node
                case NodeType.TRASH:
                    path = POSIX_ROOT / node.attributes.name
                    trash_bin_id = node.id
                    trash_bin = node
                case _:
                    raise RuntimeError  # pyright: ignore[reportUnreachable]

            path = path or (paths[node.parent_id] / node.attributes.name)
            paths[node.id] = path
            inv_paths.setdefault(path, []).append(node.id)
            if node.parent_id == trash_bin_id or node.parent_id in deleted_ids:
                deleted_ids.add(node.id)

        assert root and inbox and trash_bin
        return cls(
            root=root,
            inbox=inbox,
            trash_bin=trash_bin,
            file_count=file_count,
            folder_count=folder_count,
            _nodes=MappingProxyType(nodes_map),
            _children=MappingProxyType({node_id: tuple(nodes) for node_id, nodes in children.items()}),
            _paths=MappingProxyType(paths),
            _inv_paths=MappingProxyType({path: tuple(nodes) for path, nodes in inv_paths.items()}),
            _deleted=frozenset(deleted_ids),
        )


if __name__ == "__main__":
    import json
    import timeit
    from pathlib import Path

    path = Path(__file__).parent.parent.parent / "tests" / "fake_fs.json"
    dump = json.loads(path.read_text())

    nodes = [Node.from_dump(node) for node in dump["nodes"].values()]
    print(f"Testing filesystem build of {len(nodes):_} nodes")  # noqa: T201

    iterations = 1_000
    unsafe = timeit.timeit(lambda: UserFileSystem.build_unsafe(nodes), number=iterations)
    print(f"{iterations} [UNSAFE] calls took {unsafe:.4f}s")  # noqa: T201
    safe = timeit.timeit(lambda: UserFileSystem.build(nodes), number=iterations)
    print(f"{iterations} [SAFE] calls took {safe:.4f}s")  # noqa: T201
