"""Dialect-aware database connection + script execution helpers (P.9d).

Used by the CLI (``demo apply``) and the e2e harness fixtures. Both
need to:

  - Open a DB-API 2.0 connection against either Postgres (psycopg2)
    or Oracle (oracledb), keyed off ``cfg.dialect``.
  - Run multi-statement DDL/DML scripts. psycopg2 accepts the whole
    script in one ``cursor.execute`` call; oracledb requires per-
    statement execution and treats PL/SQL blocks (``BEGIN…END;``) as
    one unit.

Both surfaces existed inline in ``cli.py`` before P.9d. Lifting them
here lets ``tests/e2e/test_harness_end_to_end.py`` consume the same
helpers instead of hardcoding psycopg2 (which raised
``ProgrammingError`` at setup when the harness ran against an Oracle
config — see PLAN.md P.9d).
"""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs, urlparse

from quicksight_gen.common.config import Config
from quicksight_gen.common.sql import Dialect


__all__ = [
    "batch_oracle_inserts",
    "connect_demo_db",
    "execute_script",
    "oracle_dsn",
    "split_oracle_script",
]


def oracle_dsn(url: str) -> str:
    """Translate a SQLAlchemy-style Oracle URL into an oracledb DSN.

    Accepts either form:
      - ``oracle+oracledb://user:pass@host:port/?service_name=XEPDB1``
      - ``user/pass@host:port/XEPDB1`` (oracledb's native format)

    Returns a string ``oracledb.connect()`` understands.
    """
    if url.startswith(("oracle://", "oracle+oracledb://")):
        parsed = urlparse(url)
        user = parsed.username or ""
        pw = parsed.password or ""
        host = parsed.hostname or "localhost"
        port = parsed.port or 1521
        service = (
            parse_qs(parsed.query).get("service_name", [None])[0]
            or parsed.path.lstrip("/")
            or "FREEPDB1"
        )
        return f"{user}/{pw}@{host}:{port}/{service}"
    return url


def connect_demo_db(cfg: Config) -> Any:
    """Open a DB-API 2.0 connection to ``cfg.demo_database_url``.

    Branches on ``cfg.dialect``:
      - Postgres: psycopg2 (from the ``[demo]`` extra).
      - Oracle: oracledb thin client (from the ``[demo-oracle]`` extra).

    Raises:
      ImportError: if the matching driver isn't installed. The error
        message names the extras-install command.
      ValueError: if ``cfg.demo_database_url`` is unset or
        ``cfg.dialect`` isn't recognized.
    """
    if cfg.demo_database_url is None:
        raise ValueError(
            "cfg.demo_database_url is unset; set it in your config YAML "
            "or via QS_GEN_DEMO_DATABASE_URL."
        )
    if cfg.dialect is Dialect.POSTGRES:
        try:
            import psycopg2  # type: ignore[import-untyped]
        except ImportError as e:
            raise ImportError(
                "psycopg2 is required for Postgres connections. "
                "Install it with: pip install 'quicksight-gen[demo]'"
            ) from e
        return psycopg2.connect(cfg.demo_database_url)
    if cfg.dialect is Dialect.ORACLE:
        try:
            import oracledb  # type: ignore[import-untyped]
        except ImportError as e:
            raise ImportError(
                "oracledb is required for Oracle connections. "
                "Install it with: pip install 'quicksight-gen[demo-oracle]'"
            ) from e
        return oracledb.connect(oracle_dsn(cfg.demo_database_url))
    raise ValueError(
        f"Unknown dialect {cfg.dialect!r}. "
        "Set 'dialect: postgres' or 'dialect: oracle' in your config."
    )


def execute_script(
    cur: Any, sql: str, *, dialect: Dialect, oracle_insert_batch: int = 500,
) -> None:
    """Run a multi-statement SQL string against ``cur``.

    Postgres (psycopg2): the whole string in one ``execute`` call works.
    Oracle (oracledb): ``cursor.execute`` requires single statements (not
    PL/SQL blocks; not ``;``-separated). Splits via
    ``split_oracle_script`` and executes each statement individually,
    surfacing which statement (out of N) failed and the first 1500
    characters of its body for triage.

    Oracle bulk-INSERT batching (R.4.a): consecutive
    ``INSERT INTO same_table VALUES (...)`` statements get coalesced
    into ``INSERT ALL`` blocks of ``oracle_insert_batch`` rows. Cuts
    Phase R seed apply from ~30+ minutes (60k per-row round-trips at
    ~20ms each) to ~30 seconds. Set ``oracle_insert_batch=1`` to
    disable batching for debug.
    """
    if dialect is Dialect.POSTGRES:
        cur.execute(sql)
        return
    statements = split_oracle_script(sql)
    if oracle_insert_batch > 1:
        statements = batch_oracle_inserts(
            statements, batch_size=oracle_insert_batch,
        )
    for i, stmt in enumerate(statements):
        try:
            cur.execute(stmt)
        except Exception as e:
            preview = stmt.strip()[:1500]
            raise RuntimeError(
                f"Oracle stmt #{i} failed ({type(e).__name__}: {e})\n"
                f"  Preview: {preview}"
            ) from e


def split_oracle_script(sql: str) -> list[str]:
    """Split an Oracle-style script into individual statements.

    Handles PL/SQL blocks (anything starting with ``BEGIN`` or
    ``DECLARE`` and ending with ``END;``) as one unit; everything else
    splits on bare ``;``.

    Trailing-semicolon contract differs between the two:

    - **PL/SQL blocks**: the ``;`` is part of the ``END;`` terminator
      and Oracle's parser rejects the block without it
      (PLS-00103 "encountered end-of-file"). Keep it.
    - **Plain SQL statements**: ``oracledb.Cursor.execute`` rejects
      a trailing ``;`` ("invalid character"). Strip it.
    """
    return _split_oracle_script_impl(sql)


_INSERT_HEAD_RE = __import__("re").compile(
    r"^\s*INSERT\s+INTO\s+(\S+)\s*(\([^)]*\))\s*VALUES\s*",
    __import__("re").IGNORECASE | __import__("re").DOTALL,
)

# Match the FIRST value in a VALUES tuple (the PK-id column for our seed
# tables). Pattern: leading "(", optional whitespace, then either a
# quoted string ('...') or a bare token. Used by batch_oracle_inserts
# to detect same-id rows that would collide under Oracle's INSERT ALL +
# IDENTITY behavior (the IDENTITY column allocates one value PER
# STATEMENT, not per row, so same-id rows in one INSERT ALL violate the
# composite (id, entry) PK).
_FIRST_VALUE_RE = __import__("re").compile(
    r"^\(\s*'((?:[^']|'')*)'",
)


def batch_oracle_inserts(
    statements: list[str], *, batch_size: int = 500,
) -> list[str]:
    """Coalesce consecutive ``INSERT INTO same_table ... VALUES (...)``
    statements into Oracle ``INSERT ALL`` blocks of up to ``batch_size``
    rows each.

    Format produced::

        INSERT ALL
          INTO sasquatch_pr_transactions (col1, col2) VALUES ('a', 'b')
          INTO sasquatch_pr_transactions (col1, col2) VALUES ('c', 'd')
          ...
        SELECT 1 FROM dual

    Cuts Phase R seed-apply round-trips from ~60k to ~120 (60k rows /
    500 per batch). Each Oracle round-trip is ~10-30ms remote, so the
    total seed-insert time drops from ~20 minutes to ~30 seconds.

    Statements that DON'T match the simple ``INSERT INTO foo VALUES``
    shape (CREATE TABLE, ALTER, complex INSERT...SELECT, PL/SQL blocks,
    etc.) pass through unchanged. The matcher only batches statements
    whose ``INSERT INTO <table> (<cols>)`` head is identical to the
    accumulating batch's head — different tables / column lists flush
    the current batch before starting a new one.
    """
    if batch_size < 2:
        return statements

    out: list[str] = []
    pending_head: str | None = None
    pending_table: str | None = None
    pending_cols: str | None = None
    pending_values: list[str] = []
    # PK ids in the current batch — Oracle's IDENTITY column allocates
    # ONE value per INSERT ALL statement (not per row). With composite
    # PK (id, entry), two rows with the same id in one INSERT ALL get
    # the same entry → ORA-00001 unique violation. Track ids to flush
    # before adding a duplicate.
    pending_ids: set[str] = set()

    def _flush() -> None:
        nonlocal pending_head, pending_table, pending_cols, pending_values
        nonlocal pending_ids
        if not pending_values:
            return
        if len(pending_values) == 1 and pending_head is not None:
            # Single-row batch: just re-emit as a regular INSERT INTO.
            out.append(
                f"INSERT INTO {pending_table} {pending_cols} VALUES "
                f"{pending_values[0]}"
            )
        elif pending_head is not None:
            into_clauses = "\n".join(
                f"  INTO {pending_table} {pending_cols} VALUES {v}"
                for v in pending_values
            )
            out.append(f"INSERT ALL\n{into_clauses}\nSELECT 1 FROM dual")
        pending_head = None
        pending_table = None
        pending_cols = None
        pending_values = []
        pending_ids = set()

    for stmt in statements:
        m = _INSERT_HEAD_RE.match(stmt)
        if m is None:
            _flush()
            out.append(stmt)
            continue
        table = m.group(1)
        cols = m.group(2)
        head_key = f"{table.lower()} {cols}"
        # Extract the VALUES tuple (everything after the matched head).
        values_part = stmt[m.end():].strip().rstrip(";").strip()
        # Pull the first PK column value (the row's id) for collision
        # detection. Falls back to a unique sentinel if the regex
        # misses — keeps the batcher safe for non-conforming shapes.
        id_match = _FIRST_VALUE_RE.match(values_part)
        row_id = (
            id_match.group(1) if id_match is not None
            else f"__no_id_{len(pending_values)}__"
        )
        if pending_head is not None and pending_head != head_key:
            _flush()
        # Same-id collision: flush before adding so the new row starts
        # a fresh INSERT ALL block (with a fresh IDENTITY allocation).
        if row_id in pending_ids:
            _flush()
        if pending_head is None:
            pending_head = head_key
            pending_table = table
            pending_cols = cols
        pending_values.append(values_part)
        pending_ids.add(row_id)
        if len(pending_values) >= batch_size:
            _flush()
    _flush()
    return out


def _split_oracle_script_impl(sql: str) -> list[str]:
    """Inner implementation kept separate to avoid recursion through the
    public ``split_oracle_script`` symbol when adding tests that mock it.
    """
    statements: list[str] = []
    buffer: list[str] = []
    in_plsql = False
    for raw_line in sql.splitlines():
        line = raw_line.rstrip()
        # Strip the trailing ``-- comment`` before checking for the
        # statement terminator; a ``;`` inside a SQL line-comment is
        # commentary, not a statement boundary, and treating it as one
        # falsely splits the next CREATE block off into a comment-only
        # "statement" that Oracle rejects with ORA-00900.
        code = line.split("--", 1)[0].rstrip()
        stripped_code = code.strip()
        if not in_plsql and stripped_code.upper().startswith(
            ("BEGIN ", "DECLARE")
        ):
            in_plsql = True
        buffer.append(line)
        if in_plsql:
            # PL/SQL block ends at "END;" (the ; is the PL/SQL
            # statement terminator — keep it, the parser needs it).
            if stripped_code.upper().endswith("END;"):
                statements.append("\n".join(buffer).rstrip())
                buffer = []
                in_plsql = False
        else:
            if stripped_code.endswith(";"):
                # Plain SQL: oracledb rejects the trailing ; — strip.
                stmt = "\n".join(buffer).rstrip().rstrip(";")
                # Skip comment-only buffers (the buffer is all whitespace
                # + comment text). We only need stripped-code non-empty;
                # the actual SQL body content doesn't matter for emit.
                if stripped_code:
                    statements.append(stmt)
                buffer = []
    # Trailing buffer (no final semicolon)
    tail = "\n".join(buffer).strip()
    if tail:
        statements.append(tail)
    return statements
