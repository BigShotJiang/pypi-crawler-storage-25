"""Cleanup orphaned QuickSight resources managed by quicksight-gen.

Lists every resource in the configured account+region that carries the
``ManagedBy: quicksight-gen`` tag and is NOT present in the current
generate output directory, prints them, and (after a single y/n
confirmation) deletes them.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import boto3
import click
from botocore.exceptions import ClientError

from quicksight_gen.common.config import Config


MANAGED_TAG_KEY = "ManagedBy"
MANAGED_TAG_VALUE = "quicksight-gen"
L2_INSTANCE_TAG_KEY = "L2Instance"
RESOURCE_PREFIX_TAG_KEY = "ResourcePrefix"


def _read_managed_tags(client, resource_arn: str) -> dict[str, str] | None:
    """Return the resource's tag map IF it carries ``ManagedBy: quicksight-gen``.

    Returns None if the resource is not ours (or we can't read its tags).
    Caller uses the returned map to additionally filter on ``L2Instance``
    when ``cfg.l2_instance_prefix`` is set (M.2d.3).
    """
    try:
        resp = client.list_tags_for_resource(ResourceArn=resource_arn)
    except ClientError:
        return None
    tag_map: dict[str, str] = {}
    for tag in resp.get("Tags", []):
        key = tag.get("Key")
        value = tag.get("Value")
        if isinstance(key, str) and isinstance(value, str):
            tag_map[key] = value
    if tag_map.get(MANAGED_TAG_KEY) != MANAGED_TAG_VALUE:
        return None
    return tag_map


def _expected_ids_from_out(out_dir: Path, cfg: Config) -> dict[str, set[str]]:
    """Collect the IDs of every resource produced by the current generate run.

    The currently-configured ``datasource_arn`` is always treated as active —
    ``generate`` never writes a datasource.json (only ``demo apply`` does), so
    without this the active datasource would be flagged stale on every run.
    """
    expected: dict[str, set[str]] = {
        "dashboard": set(),
        "analysis": set(),
        "dataset": set(),
        "theme": set(),
        "datasource": set(),
    }

    if cfg.datasource_arn:
        expected["datasource"].add(cfg.datasource_arn.rsplit("/", 1)[-1])

    if not out_dir.exists():
        return expected

    for path in out_dir.glob("*-dashboard.json"):
        expected["dashboard"].add(json.loads(path.read_text())["DashboardId"])
    for path in out_dir.glob("*-analysis.json"):
        expected["analysis"].add(json.loads(path.read_text())["AnalysisId"])
    datasets_dir = out_dir / "datasets"
    if datasets_dir.is_dir():
        for path in datasets_dir.glob("*.json"):
            expected["dataset"].add(json.loads(path.read_text())["DataSetId"])
    theme_path = out_dir / "theme.json"
    if theme_path.exists():
        expected["theme"].add(json.loads(theme_path.read_text())["ThemeId"])
    datasource_path = out_dir / "datasource.json"
    if datasource_path.exists():
        expected["datasource"].add(json.loads(datasource_path.read_text())["DataSourceId"])
    return expected


def _iter_dashboards(client, account_id: str) -> Iterable[tuple[str, str]]:
    paginator = client.get_paginator("list_dashboards")
    for page in paginator.paginate(AwsAccountId=account_id):
        for item in page.get("DashboardSummaryList", []):
            yield item["DashboardId"], item["Arn"]


def _iter_analyses(client, account_id: str) -> Iterable[tuple[str, str]]:
    paginator = client.get_paginator("list_analyses")
    for page in paginator.paginate(AwsAccountId=account_id):
        for item in page.get("AnalysisSummaryList", []):
            if item.get("Status") == "DELETED":
                continue
            yield item["AnalysisId"], item["Arn"]


def _iter_datasets(client, account_id: str) -> Iterable[tuple[str, str]]:
    paginator = client.get_paginator("list_data_sets")
    for page in paginator.paginate(AwsAccountId=account_id):
        for item in page.get("DataSetSummaries", []):
            yield item["DataSetId"], item["Arn"]


def _iter_themes(client, account_id: str) -> Iterable[tuple[str, str]]:
    paginator = client.get_paginator("list_themes")
    for page in paginator.paginate(AwsAccountId=account_id, Type="CUSTOM"):
        for item in page.get("ThemeSummaryList", []):
            yield item["ThemeId"], item["Arn"]


def _iter_datasources(client, account_id: str) -> Iterable[tuple[str, str]]:
    paginator = client.get_paginator("list_data_sources")
    for page in paginator.paginate(AwsAccountId=account_id):
        for item in page.get("DataSources", []):
            yield item["DataSourceId"], item["Arn"]


def _collect_stale(
    client,
    account_id: str,
    expected: dict[str, set[str]],
    *,
    l2_instance_prefix: str | None = None,
    resource_prefix: str | None = None,
    tagging_enabled: bool = True,
) -> dict[str, list[tuple[str, str]]]:
    """Return stale (id, arn) tuples grouped by resource type.

    Two layers of scoping, both fail-CLOSED (untagged resources stay
    safe — they were deployed by a previous version of the library
    and the operator hasn't opted into the new scope):

    - **``ResourcePrefix``** (v8.4.0): the strongest isolation. When
      ``resource_prefix`` is passed, only resources whose
      ``ResourcePrefix`` tag matches the cfg's resource_prefix are
      eligible for deletion. This is what makes parallel CI runs +
      coexisting local deploys safe — each deploy stamps its own
      ``ResourcePrefix`` (e.g. ``qs-ci-<run_id>-pg`` for CI,
      ``qs-gen-postgres`` for a local deploy) and cleanup only ever
      sweeps its own scope. Resources tagged with a different
      ``ResourcePrefix`` value AND resources with no
      ``ResourcePrefix`` tag at all (pre-v8.4.0 deploys) are skipped.

    - **``L2Instance``** (M.2d.3): per-institution scope. Applied
      AFTER the ``ResourcePrefix`` filter when both are set.

    When ``resource_prefix`` is None (callers that haven't been
    updated, or the legacy un-prefixed sweep), the function falls
    back to the pre-v8.4.0 behavior: any ``ManagedBy=quicksight-gen``
    resource is eligible (subject to the ``L2Instance`` filter if
    set). New callers should always pass ``resource_prefix``.

    When ``tagging_enabled=False`` (v8.6.11), the tag check is
    bypassed entirely. ``resource_prefix`` becomes mandatory and
    cleanup matches by ID-prefix (``rid.startswith(resource_prefix)``)
    instead — significantly weaker isolation, but the only option
    when the IAM principal can't ``Tag*Resource``. See the docs
    reference for the loss-of-safety implications.
    """
    if not tagging_enabled and resource_prefix is None:
        raise ValueError(
            "tagging_enabled=False requires resource_prefix — without "
            "either tags or an ID-prefix scope, cleanup has no way to "
            "tell our resources from anyone else's."
        )

    stale: dict[str, list[tuple[str, str]]] = {
        "dashboard": [],
        "analysis": [],
        "dataset": [],
        "theme": [],
        "datasource": [],
    }
    iterators = {
        "dashboard": _iter_dashboards,
        "analysis": _iter_analyses,
        "dataset": _iter_datasets,
        "theme": _iter_themes,
        "datasource": _iter_datasources,
    }
    for kind, it in iterators.items():
        for rid, arn in it(client, account_id):
            if rid in expected[kind]:
                continue
            if not tagging_enabled:
                # ID-prefix fallback (v8.6.11). resource_prefix asserted
                # non-None above. Match anything starting with the
                # prefix; trust the operator's prefix uniqueness.
                assert resource_prefix is not None
                if not rid.startswith(f"{resource_prefix}-"):
                    continue
                stale[kind].append((rid, arn))
                continue
            tags = _read_managed_tags(client, arn)
            if tags is None:
                # Not ours.
                continue
            if resource_prefix is not None:
                # Strongest scope: per-deploy ResourcePrefix match.
                # Fail-CLOSED on missing tag — pre-v8.4.0 deploys
                # without the tag are NOT eligible for sweep by a
                # prefix-aware caller. The operator can still
                # legacy-clean them by running with no prefix scope.
                if tags.get(RESOURCE_PREFIX_TAG_KEY) != resource_prefix:
                    continue
            if l2_instance_prefix is not None:
                # Per-instance scope: only sweep matching-tag resources.
                if tags.get(L2_INSTANCE_TAG_KEY) != l2_instance_prefix:
                    continue
            stale[kind].append((rid, arn))
    return stale


def _delete_stale(
    client, account_id: str, stale: dict[str, list[tuple[str, str]]],
) -> int:
    """Delete stale resources in dependency order. Returns failure count."""
    failures = 0

    for rid, _ in stale["dashboard"]:
        click.echo(f"  deleting dashboard {rid}")
        try:
            client.delete_dashboard(AwsAccountId=account_id, DashboardId=rid)
        except ClientError as exc:
            click.echo(f"    error: {exc}")
            failures += 1
    for rid, _ in stale["analysis"]:
        click.echo(f"  deleting analysis {rid}")
        try:
            client.delete_analysis(
                AwsAccountId=account_id,
                AnalysisId=rid,
                ForceDeleteWithoutRecovery=True,
            )
        except ClientError as exc:
            click.echo(f"    error: {exc}")
            failures += 1
    for rid, _ in stale["dataset"]:
        click.echo(f"  deleting dataset {rid}")
        try:
            client.delete_data_set(AwsAccountId=account_id, DataSetId=rid)
        except ClientError as exc:
            click.echo(f"    error: {exc}")
            failures += 1
    for rid, _ in stale["theme"]:
        click.echo(f"  deleting theme {rid}")
        try:
            client.delete_theme(AwsAccountId=account_id, ThemeId=rid)
        except ClientError as exc:
            click.echo(f"    error: {exc}")
            failures += 1
    for rid, _ in stale["datasource"]:
        click.echo(f"  deleting datasource {rid}")
        try:
            client.delete_data_source(AwsAccountId=account_id, DataSourceId=rid)
        except ClientError as exc:
            click.echo(f"    error: {exc}")
            failures += 1
    return failures


def run_cleanup(
    cfg: Config,
    out_dir: Path,
    *,
    dry_run: bool = False,
    skip_confirm: bool = False,
    purge_all: bool = False,
) -> int:
    """Entrypoint for the `cleanup` CLI command.

    By default, ``out_dir`` is the carve-out: anything currently emitted
    there stays, everything else matching the cfg's tag/prefix scope is
    stale.

    With ``purge_all=True`` (v8.6.13 ``--all`` flag), ``out_dir`` is
    ignored entirely — every resource matching the scope is treated as
    stale, including the live deploy. Use to nuke everything we own
    from a QS account (e.g. tearing down a CI run, decommissioning an
    L2 instance).
    """
    client = boto3.client("quicksight", region_name=cfg.aws_region)
    account_id = cfg.aws_account_id

    scope_parts: list[str] = []
    scope_parts.append(f"ResourcePrefix={cfg.resource_prefix!r}")
    if cfg.l2_instance_prefix:
        scope_parts.append(f"L2Instance={cfg.l2_instance_prefix!r}")
    scope_label = f" scoped to {', '.join(scope_parts)}"
    if not cfg.tagging_enabled:
        scope_label += (
            " (tagging disabled — matching by ID prefix only; weaker"
            " isolation, see docs reference)"
        )
    if purge_all:
        scope_label += (
            " — PURGE-ALL mode: ignoring out/, every matching resource"
            " is eligible for deletion (including the live deploy)"
        )
    click.echo(
        f"Scanning QuickSight resources in {account_id} "
        f"({cfg.aws_region}){scope_label}..."
    )
    expected = (
        # Empty carve-out = every matching resource is stale.
        {kind: set() for kind in (
            "dashboard", "analysis", "dataset", "theme", "datasource",
        )}
        if purge_all
        else _expected_ids_from_out(out_dir, cfg)
    )
    stale = _collect_stale(
        client, account_id, expected,
        l2_instance_prefix=cfg.l2_instance_prefix,
        resource_prefix=cfg.resource_prefix,
        tagging_enabled=cfg.tagging_enabled,
    )

    total = sum(len(items) for items in stale.values())
    if total == 0:
        click.echo("No stale tagged resources found. Nothing to do.")
        return 0

    click.echo(f"\nFound {total} stale tagged resource(s):")
    for kind in ("dashboard", "analysis", "dataset", "theme", "datasource"):
        for rid, _ in stale[kind]:
            click.echo(f"  [{kind}] {rid}")

    if dry_run:
        click.echo("\n(dry-run) not deleting anything.")
        return 0

    if not skip_confirm:
        if not click.confirm("\nDelete all of these?", default=False):
            click.echo("Aborted.")
            return 0

    click.echo()
    failures = _delete_stale(client, account_id, stale)
    click.echo()
    if failures:
        click.echo(f"Completed with {failures} failure(s).")
        return 1
    click.echo("Cleanup complete.")
    return 0
