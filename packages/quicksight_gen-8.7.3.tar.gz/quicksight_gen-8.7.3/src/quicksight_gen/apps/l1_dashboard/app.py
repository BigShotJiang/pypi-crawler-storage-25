"""L1 Dashboard — generic L2-fed reconciliation dashboard.

Tree-built from scratch around the M.1a.7 L1 invariant views. Replaces
the v5 idiom translation layer (apps/account_recon/_l2_datasets.py) with
direct view consumption — each sheet IS one L1 SHOULD-constraint
visualized.

Architecture (M.2a.1 decision): parallel-stack with the legacy
apps/account_recon/ — the v5 AR app keeps working against its v5
schema deployment until M.2a.10 deprecates it. The L1 dashboard builds
fresh tree-built sheets against the v6 prefixed schema + L1 invariant
views per L2 instance, with no v5-idiom column shims.

Build pipeline:
    build_l1_dashboard_app(cfg, *, l2_instance=None) -> App

Default L2 instance is the canonical Sasquatch AR fixture (same as the
AR legacy stack); callers MAY override (tests, alternative-persona
deployments) via the kwarg.

Substep landmarks:
    M.2a.1 — package skeleton + Analysis + Dashboard registered
    M.2a.2 — Getting Started sheet with description-driven prose
    M.2a.3 — Drift sheet — KPIs + leaf + ledger drift tables
    M.2a.4 — Overdraft sheet — KPI + violations table
    M.2a.5 — Limit Breach sheet — KPI + breach table
    M.2a.6 — Today's Exceptions sheet — UNION across L1 views
    M.2a.7 — Description-driven prose across every sheet (this commit)
    M.2a.8 — Hash-lock the seed at the M.2a structure
    M.2a.9 — Deploy + verify against Aurora
    M.2a.10 — Iteration gate; decide on apps/account_recon/ deprecation
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from quicksight_gen.apps.l1_dashboard._l2 import default_l2_instance
from quicksight_gen.apps.l1_dashboard.datasets import (
    DS_DAILY_STATEMENT_SUMMARY,
    DS_DAILY_STATEMENT_TRANSACTIONS,
    DS_DRIFT,
    DS_DRIFT_TIMELINE,
    DS_LEDGER_DRIFT,
    DS_LEDGER_DRIFT_TIMELINE,
    DS_LIMIT_BREACH,
    DS_OVERDRAFT,
    DS_STUCK_PENDING,
    DS_STUCK_UNBUNDLED,
    DS_SUPERSESSION_DAILY_BALANCES,
    DS_SUPERSESSION_TRANSACTIONS,
    DS_TODAYS_EXCEPTIONS,
    DS_TRANSACTIONS,
    build_all_l1_dashboard_datasets,
)
from quicksight_gen.common import rich_text as rt
from quicksight_gen.common.config import Config
from quicksight_gen.common.ids import ParameterName, SheetId
from quicksight_gen.common.l2 import L2Instance
from quicksight_gen.common.models import DateTimeDefaultValues
from quicksight_gen.common.dataset_contract import ColumnShape
from quicksight_gen.common.sheets.app_info import (
    APP_INFO_SHEET_DESCRIPTION,
    APP_INFO_SHEET_NAME,
    APP_INFO_SHEET_TITLE,
    DS_APP_INFO_LIVENESS,
    DS_APP_INFO_MATVIEWS,
    populate_app_info_sheet,
)
from quicksight_gen.common.l2 import ThemePreset
from quicksight_gen.common.theme import resolve_l2_theme
from quicksight_gen.common.tree import (
    AUTO,
    Analysis,
    App,
    AutoResolved,
    CalcField,
    CategoryFilter,
    CellAccentText,
    Dataset,
    DateTimeParam,
    Dim,
    Drill,
    DrillParam,
    DrillResetSentinel,
    DrillStaticDateTime,
    FilterGroup,
    LineChart,
    LinkedValues,
    Measure,
    Sheet,
    StringParam,
    TextBox,
    TimeEqualityFilter,
    TimeRangeFilter,
)


# Layout constants — mirror apps/account_recon/app.py so visual heights
# read consistently across the two AR stacks.
_FULL = 36
_HALF = 18
_KPI_ROW_SPAN = 6
_CHART_ROW_SPAN = 12
_TABLE_ROW_SPAN = 18


# Sheet IDs — inlined in app.py per the greenfield-app convention
# (L.7 Executives) since the L1 dashboard isn't dragging legacy URL
# stability constraints from a previous deploy.
SHEET_GETTING_STARTED = SheetId("l1-sheet-getting-started")
SHEET_DRIFT = SheetId("l1-sheet-drift")
SHEET_DRIFT_TIMELINES = SheetId("l1-sheet-drift-timelines")
SHEET_OVERDRAFT = SheetId("l1-sheet-overdraft")
SHEET_LIMIT_BREACH = SheetId("l1-sheet-limit-breach")
SHEET_PENDING_AGING = SheetId("l1-sheet-pending-aging")
SHEET_UNBUNDLED_AGING = SheetId("l1-sheet-unbundled-aging")
SHEET_SUPERSESSION_AUDIT = SheetId("l1-sheet-supersession-audit")
SHEET_TODAYS_EXCEPTIONS = SheetId("l1-sheet-todays-exceptions")
SHEET_DAILY_STATEMENT = SheetId("l1-sheet-daily-statement")
SHEET_TRANSACTIONS = SheetId("l1-sheet-transactions")
SHEET_APP_INFO = SheetId("l1-sheet-app-info")


# Parameter names — analysis-level parameters that drive the universal
# date-range filter (M.2b.1). Each data-bearing sheet has paired
# date-time picker controls bound to these params, so all 4 sheets'
# pickers stay in sync via shared parameter values.
P_L1_DATE_START = ParameterName("pL1DateStart")
P_L1_DATE_END = ParameterName("pL1DateEnd")

# M.2b.4 — Daily Statement parameters. Single-value account_id +
# single-value business_day_start drive the per-account-day filter on
# both the summary KPIs and the transactions detail table.
P_L1_DS_ACCOUNT = ParameterName("pL1DsAccount")
P_L1_DS_BALANCE_DATE = ParameterName("pL1DsBalanceDate")

# M.2b.7 — Drill-target parameters (sentinel-pattern, mirror of AR).
# These never appear as visible sheet controls — they're only written
# by drill actions. Each per-invariant sheet (Drift / Overdraft /
# Limit Breach) carries a calc-field-backed FilterGroup that reads
# ``pL1FilterAccount`` to narrow its dataset to one account; the
# Transactions sheet does the same for ``pL1TxTransfer``. The "__ALL__"
# sentinel default means "no filter" — destination calc fields special-
# case it to PASS so the un-drilled state shows everything.
P_L1_FILTER_ACCOUNT = ParameterName("pL1FilterAccount")
P_L1_TX_TRANSFER = ParameterName("pL1TxTransfer")

# Sentinel value the M.2b.7 drill calc fields treat as PASS — same
# string AR uses (mirror).
_DRILL_RESET_SENTINEL = "__ALL__"

# Typed DrillParam constants — pair each ParameterName with its
# expected ColumnShape so cross_sheet_drill() refuses shape-mismatched
# writes at construction time (the K.2 invariant).
_DP_FILTER_ACCOUNT = DrillParam(P_L1_FILTER_ACCOUNT, ColumnShape.ACCOUNT_ID)
_DP_TX_TRANSFER = DrillParam(P_L1_TX_TRANSFER, ColumnShape.TRANSFER_ID)
_DP_DS_ACCOUNT = DrillParam(P_L1_DS_ACCOUNT, ColumnShape.ACCOUNT_ID)
_DP_DS_BALANCE_DATE = DrillParam(
    P_L1_DS_BALANCE_DATE, ColumnShape.DATETIME_DAY,
)
# v8.5.7 — universal date-range params, exposed as drill targets so a
# cross-sheet drill from an unscoped current-state sheet (Pending Aging,
# Unbundled Aging, Supersession Audit) into a date-scoped sheet
# (Transactions) can widen the window to "all time" so the drill
# target row is in scope. See ``_WIDE_DATE_WRITES`` below.
_DP_DATE_START = DrillParam(P_L1_DATE_START, ColumnShape.DATETIME_DAY)
_DP_DATE_END = DrillParam(P_L1_DATE_END, ColumnShape.DATETIME_DAY)

# Far-past + far-future ISO-8601 literals the drill writes use when
# widening the universal date range. The destination sheet's picker
# will visibly snap to these values (a known QuickSight UX wart with
# in-app drill writes) — analysts re-narrow if they want a tighter
# slice. Mirrors the L2 Flow Tracing app's ``1900-01-01`` static
# default convention; we picked 1990 instead because it predates any
# realistic banking dataset while still being "modern" enough not to
# look like an off-by-error. End at 2099 keeps the picker from
# showing dates an analyst would mistake for a typo.
_WIDE_DATE_START_VALUE = "1990-01-01T00:00:00.000Z"
_WIDE_DATE_END_VALUE = "2099-12-31T00:00:00.000Z"


def _wide_date_writes() -> list[tuple[DrillParam, DrillStaticDateTime]]:
    """Pair of writes that widen the universal date range to "all time".

    Caller appends these to ``writes=`` on cross-sheet drills whose
    destination sheet is universally-date-scoped AND whose source
    sheet is not — i.e. drills FROM Pending Aging / Unbundled Aging /
    Supersession Audit (current-state views, unscoped) INTO
    Transactions (universally scoped). Without these writes the drill
    target row falls outside the destination's default 7-day window
    and the table renders empty.

    Same-scope drills (e.g. Today's Exceptions → Drift, both already
    in the universal date filter) do NOT need these writes — the
    user's existing window is preserved across the drill.
    """
    return [
        (_DP_DATE_START, DrillStaticDateTime(_WIDE_DATE_START_VALUE)),
        (_DP_DATE_END, DrillStaticDateTime(_WIDE_DATE_END_VALUE)),
    ]


_GETTING_STARTED_NAME = "Getting Started"
_GETTING_STARTED_TITLE = "L1 Reconciliation Dashboard"
_GETTING_STARTED_DESCRIPTION = (
    "Where to start. The dashboard groups every L1 SHOULD-constraint "
    "into one tab per exception kind — drift, overdraft, limit breach, "
    "expected EOD balance variance — plus a Today's Exceptions roll-up. "
    "Each tab queries one L1 invariant view directly; rows ARE the "
    "constraint violations."
)


_DRIFT_NAME = "Drift"
_DRIFT_TITLE = "Account Balance Drift"
_DRIFT_DESCRIPTION = (
    "Stored vs computed balance disagreements at end-of-day. Leaf table "
    "covers individual posting accounts (computed = cumulative net of "
    "every Money record through that BusinessDay's end). Ledger table "
    "covers parent accounts (computed = sum of child accounts' stored "
    "balances). Both tables only show rows where stored ≠ computed — "
    "every row is one SHOULD-constraint violation."
)


_DRIFT_TIMELINES_NAME = "Drift Timelines"
_DRIFT_TIMELINES_TITLE = "Drift Magnitude Over Time"
_DRIFT_TIMELINES_DESCRIPTION = (
    "Σ ABS(drift) per BusinessDay end, one line per account_role. "
    "Healthy days sit on the zero baseline; spikes mark when the feed "
    "or the parent-roll-up diverged. Use this to spot recurring "
    "violations vs one-off events — a role that spikes every Monday is "
    "a different problem than a role that spiked once after a deploy. "
    "KPIs surface the largest single-day magnitude in the past 7 days."
)


_OVERDRAFT_NAME = "Overdraft"
_OVERDRAFT_TITLE = "Internal Account Overdrafts"
_OVERDRAFT_DESCRIPTION = (
    "Internal accounts holding negative money at end-of-day. The L1 "
    "invariant is 'no internal account holds negative balance' — every "
    "row in the table below is one violation. External accounts are "
    "excluded by the underlying view (banks may legitimately overdraft "
    "us; we MUST NOT overdraft them)."
)


_LIMIT_BREACH_NAME = "Limit Breach"
_LIMIT_BREACH_TITLE = "Outbound Transfer Limit Breaches"
_LIMIT_BREACH_DESCRIPTION = (
    "Per-account, per-day, per-transfer-type cells where cumulative "
    "outbound debit exceeded the L2-configured cap. Caps are pulled "
    "from the L2 instance's LimitSchedules at schema-emit time and "
    "embedded inline in the underlying view — no JSON path lookups in "
    "the dataset SQL. Every row is one violation."
)


_PENDING_AGING_NAME = "Pending Aging"
_PENDING_AGING_TITLE = "Pending Transactions Aging Past Cap"
_PENDING_AGING_DESCRIPTION = (
    "Transactions stuck in `status='Pending'` past their rail's "
    "configured `max_pending_age` cap. Each Rail in the L2 instance "
    "with an aging watch contributes its own threshold; the underlying "
    "view inlines these caps at schema-emit time. KPI shows total stuck "
    "count; the aging bar chart breaks the population into 5 buckets "
    "(0–6h, 6–24h, 1–3d, 3–7d, >7d) so operators can see whether they're "
    "fighting one big spike or a slow drift. Right-click any row → "
    "View Transactions to see every leg of that transfer."
)


_UNBUNDLED_AGING_NAME = "Unbundled Aging"
_UNBUNDLED_AGING_TITLE = "Unbundled Posted Legs Aging Past Cap"
_UNBUNDLED_AGING_DESCRIPTION = (
    "Posted transactions whose `bundle_id` is still NULL past their "
    "rail's `max_unbundled_age` cap. An AggregatingRail's job is to "
    "pick up these legs and group them into a Bundle; an unbundled leg "
    "older than the rail's cadence means the bundler hasn't fired or "
    "is failing to match. KPI shows total stuck count; the aging bar "
    "chart breaks the population into 4 buckets (<1d, 1–2d, 2–7d, >7d) "
    "— the typical max_unbundled_age cadence is a day or two, so "
    "buckets are wider than Pending Aging's. Right-click any row → "
    "View Transactions to see every leg of that transfer."
)


_SUPERSESSION_AUDIT_NAME = "Supersession Audit"
_SUPERSESSION_AUDIT_TITLE = "Supersession Audit Trail"
_SUPERSESSION_AUDIT_DESCRIPTION = (
    "Every logical row whose append-only `entry` column has more than "
    "one version. Each rewrite carries a `supersedes` reason from L1's "
    "v1 vocabulary (Inflight / BundleAssignment / TechnicalCorrection). "
    "Reads from the BASE tables, not Current* — by definition Current* "
    "hides the prior entries we want to audit here. Use the supersedes "
    "filter to slice by reason: high TechnicalCorrection volume signals "
    "a feed problem; high Inflight is normal in a busy bundling cadence."
)


_TODAYS_EXCEPTIONS_NAME = "Today's Exceptions"
_TODAYS_EXCEPTIONS_TITLE = "Today's Exceptions"
_TODAYS_EXCEPTIONS_DESCRIPTION = (
    "The 9am scan — every L1 SHOULD-constraint violation across all 5 "
    "invariant views (drift, ledger drift, overdraft, limit breach, "
    "expected EOD balance), scoped to the most recent business day in "
    "the data. Replaces v5's ar_unified_exceptions matview with a live "
    "UNION; no REFRESH contract. KPI tracks total open count; bar chart "
    "breaks down by check_type; detail table sorts by magnitude so the "
    "biggest variances surface first."
)


_DAILY_STATEMENT_NAME = "Daily Statement"
_DAILY_STATEMENT_TITLE = "Per-Account Daily Statement"
_DAILY_STATEMENT_DESCRIPTION = (
    "Per-account, per-day walk: opening balance + day's debits + "
    "credits + closing balance + drift. Pick one account and one "
    "business day via the controls; KPIs surface the 5-number summary "
    "and the detail table lists every Money record posted that day. "
    "Drift = stored closing − (opening + signed-net flow); on a healthy "
    "feed it's exactly zero, so non-zero drift here is the single "
    "visual cue the underlying ledger doesn't reconcile for that "
    "account-day. Mirrors AR's Daily Statement pattern."
)


_TRANSACTIONS_NAME = "Transactions"
_TRANSACTIONS_TITLE = "Posting Ledger"
_TRANSACTIONS_DESCRIPTION = (
    "The raw posting ledger — one row per Money record (leg). "
    "Supersession-aware: the underlying view filters out replaced "
    "entries so what you see IS the current truth. Filter by account, "
    "transfer, status (Pending / Posted / Failed), origin "
    "(InternalInitiated / ExternalForcePosted / ExternalAggregated), "
    "or transfer type. Drill out to Daily Statement for the account-day "
    "context any leg sits in (drill wiring lands at M.2b.7)."
)


def _analysis_name(cfg: Config, l2_instance: L2Instance) -> str:
    """Title shown on the deployed QuickSight Analysis."""
    return f"L1 Reconciliation Dashboard ({l2_instance.instance})"


# -- L2-prose helpers --------------------------------------------------------
#
# M.2a.7's "description-driven prose" core: pull facts about the configured
# L2 instance into per-sheet text boxes so each sheet IS the handbook page
# for that L1 invariant under this institution. Switching L2 instance
# switches the prose across every sheet — tested at the substep that
# introduces each helper's call site.


def _l2_inventory_lines(l2_instance: L2Instance) -> list[str]:
    """Compact inventory bullets for the Getting Started coverage block."""
    accounts = l2_instance.accounts
    internal = sum(1 for a in accounts if a.scope == "internal")
    external = sum(1 for a in accounts if a.scope == "external")
    return [
        f"{internal} internal accounts, {external} external accounts",
        f"{len(l2_instance.account_templates)} account templates "
        f"(role classes that bind to specific accounts at posting time)",
        f"{len(l2_instance.rails)} rails "
        f"(reconciliation patterns the integrator declares)",
        f"{len(l2_instance.transfer_templates)} transfer templates "
        f"(multi-leg shared transfers)",
        f"{len(l2_instance.chains)} chains "
        f"(transfer-of-transfers ordered flows)",
        f"{len(l2_instance.limit_schedules)} limit schedules "
        f"(daily outbound caps by parent role × transfer type)",
    ]


def _l2_limit_schedule_lines(l2_instance: L2Instance) -> list[str]:
    """Per-LimitSchedule bullets — name, cap, and L2-supplied prose."""
    if not l2_instance.limit_schedules:
        return [
            "No limit schedules configured on this L2 instance — "
            "the limit-breach view returns zero rows by construction.",
        ]
    lines: list[str] = []
    for ls in l2_instance.limit_schedules:
        # Money is a Decimal; format with thousands separators + 2dp.
        cap_str = f"${ls.cap:,.2f}/day"
        head = f"{ls.parent_role} × {ls.transfer_type}: {cap_str}"
        if ls.description:
            lines.append(f"{head} — {ls.description}")
        else:
            lines.append(head)
    return lines


def _l2_internal_account_role_lines(l2_instance: L2Instance) -> list[str]:
    """One bullet per internal account or template with prose."""
    lines: list[str] = []
    for a in l2_instance.accounts:
        if a.scope != "internal":
            continue
        head = f"{a.role or a.id} ({a.id})"
        if a.description:
            lines.append(f"{head} — {a.description}")
        else:
            lines.append(head)
    for t in l2_instance.account_templates:
        if t.scope != "internal":
            continue
        head = f"{t.role} (template)"
        if t.description:
            lines.append(f"{head} — {t.description}")
        else:
            lines.append(head)
    return lines


def _l1_datasets(
    cfg: Config, l2_instance: L2Instance,
) -> dict[str, Dataset]:
    """Build every L1 dataset and return tree-ref Datasets keyed by id.

    Each AWS DataSet's ``DataSetId`` becomes the tree Dataset's ARN
    path component; the visual identifier (the registry key passed to
    `build_dataset()`) becomes the tree Dataset's ``identifier`` field.
    The contract is registered as a side-effect of `build_dataset()`,
    so subsequent ``ds["col"]`` accesses validate.

    M.4.4.5 — App Info ("i") sheet datasets land at the end of the
    list; their order matches `build_all_l1_dashboard_datasets`'s
    appended App Info pair.
    """
    aws_datasets = build_all_l1_dashboard_datasets(cfg, l2_instance)
    # `build_all_l1_dashboard_datasets` returns AWS DataSets in the same
    # order as the visual identifiers below; map each to a tree Dataset.
    visual_ids = [
        DS_DRIFT, DS_LEDGER_DRIFT, DS_OVERDRAFT,
        DS_LIMIT_BREACH, DS_TODAYS_EXCEPTIONS,
        DS_DAILY_STATEMENT_SUMMARY, DS_DAILY_STATEMENT_TRANSACTIONS,
        DS_TRANSACTIONS,
        DS_DRIFT_TIMELINE, DS_LEDGER_DRIFT_TIMELINE,
        DS_STUCK_PENDING, DS_STUCK_UNBUNDLED,
        DS_SUPERSESSION_TRANSACTIONS, DS_SUPERSESSION_DAILY_BALANCES,
        DS_APP_INFO_LIVENESS, DS_APP_INFO_MATVIEWS,
    ]
    return {
        vid: Dataset(identifier=vid, arn=cfg.dataset_arn(aws.DataSetId))
        for vid, aws in zip(visual_ids, aws_datasets)
    }


def _populate_getting_started(
    cfg: Config,
    sheet: Sheet,
    l2_instance: L2Instance,
    *,
    theme: ThemePreset,
) -> None:
    """Render the Getting Started sheet using the L2 instance's prose.

    M.2a's "description-driven prose" core: the welcome text uses
    `l2_instance.description` as the body, and the coverage block lists
    the L2 inventory (account counts, rail counts, etc.) — both
    derived from the L2 instance, NOT hardcoded persona strings.
    Switching L2 instance switches the prose.
    """
    accent = theme.accent

    welcome_body = (
        l2_instance.description
        if l2_instance.description
        else "(L2 instance description missing — fill the top-level "
             "`description` field in the L2 YAML.)"
    )

    sheet.layout.row(height=8).add_text_box(
        TextBox(
            text_box_id="l1-gs-welcome",
            content=rt.text_box(
                rt.inline(
                    _GETTING_STARTED_TITLE,
                    font_size="36px",
                    color=accent,
                ),
                rt.BR, rt.BR,
                rt.markdown(welcome_body),
            ),
        ),
        width=_FULL,
    )

    sheet.layout.row(height=8).add_text_box(
        TextBox(
            text_box_id="l1-gs-coverage",
            content=rt.text_box(
                rt.subheading("L2 Coverage", color=accent),
                rt.BR,
                rt.markdown(
                    "What this dashboard reconciles, derived from the "
                    "configured L2 instance:"
                ),
                rt.bullets(_l2_inventory_lines(l2_instance)),
            ),
        ),
        width=_FULL,
    )


def _populate_drift_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    l2_instance: L2Instance,
    daily_statement_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Drift sheet — 2 KPIs + leaf-drift table + ledger-drift table.

    Both tables are unaggregated row passthroughs: the L1 views
    pre-filter to violations only (``stored_balance != computed_balance``)
    so each row is one SHOULD-constraint failure.

    M.2a.7: top-of-sheet TextBox enumerates the L2's internal accounts
    + their roles + L2-supplied prose so analysts see the universe of
    accounts drift can surface against.
    """
    accent = theme.accent
    ds_drift = datasets[DS_DRIFT]
    ds_ledger_drift = datasets[DS_LEDGER_DRIFT]

    sheet.layout.row(height=8).add_text_box(
        TextBox(
            text_box_id="l1-drift-accounts",
            content=rt.text_box(
                rt.subheading("Internal Accounts in Scope", color=accent),
                rt.BR,
                rt.markdown(
                    "Accounts where drift is checked — drift surfaces "
                    "where stored balance disagrees with the cumulative "
                    "net of posted Money records (leaf) or the sum of "
                    "child stored balances (parent):"
                ),
                rt.bullets(_l2_internal_account_role_lines(l2_instance)),
            ),
        ),
        width=_FULL,
    )

    # Row 2: two KPIs side-by-side — one count per drift-violation kind.
    half = _FULL // 2
    kpi_row = sheet.layout.row(height=_KPI_ROW_SPAN)
    kpi_row.add_kpi(
        width=half,
        title="Leaf Accounts in Drift",
        subtitle=(
            "Count of leaf-account day-rows where stored balance "
            "disagrees with the cumulative net of posted Money records."
        ),
        values=[ds_drift["account_id"].count()],
    )
    kpi_row.add_kpi(
        width=half,
        title="Parent Accounts in Drift",
        subtitle=(
            "Count of parent-account day-rows where stored balance "
            "disagrees with the sum of child accounts' stored balances."
        ),
        values=[ds_ledger_drift["account_id"].count()],
    )

    # Row 2: leaf-drift table. Pull account_id + business_day_end Dims
    # local so the link tint + drill can reference the same field_id
    # as the columns. Right-click → View Daily Statement narrows the
    # forward investigation to that account-day.
    leaf_account_col = ds_drift["account_id"].dim()
    leaf_day_col = ds_drift["business_day_end"].date()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Leaf Account Drift",
        subtitle=(
            "Each leaf account's stored vs computed balance per "
            "BusinessDay. Computed = cumulative Σ signed Money through "
            "that day's end. Drift = stored − computed; non-zero ⇒ feed "
            "diverged from the underlying ledger. Right-click any row "
            "→ View Daily Statement to open that account-day."
        ),
        columns=[
            leaf_account_col,
            ds_drift["account_name"].dim(),
            ds_drift["account_role"].dim(),
            ds_drift["account_parent_role"].dim(),
            leaf_day_col,
            ds_drift["stored_balance"].numerical(currency=True),
            ds_drift["computed_balance"].numerical(currency=True),
            ds_drift["drift"].numerical(currency=True),
        ],
        actions=[
            _l1_drill(
                target_sheet=daily_statement_sheet,
                name="View Daily Statement for this account-day",
                writes=[
                    (_DP_DS_ACCOUNT, leaf_account_col),
                    (_DP_DS_BALANCE_DATE, leaf_day_col),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=leaf_account_col, color=accent),
        ],
    )

    # Row 3: ledger (parent-account) drift table — same shape minus
    # account_parent_role (parents ARE the parents). Same Daily
    # Statement drill.
    parent_account_col = ds_ledger_drift["account_id"].dim()
    parent_day_col = ds_ledger_drift["business_day_end"].date()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Parent Account Drift",
        subtitle=(
            "Each parent account's stored vs computed balance per "
            "BusinessDay. Computed = Σ stored balances of its child "
            "accounts on that day. Drift = stored − computed; non-zero "
            "⇒ a child posting didn't roll up correctly. Right-click "
            "any row → View Daily Statement to open that account-day."
        ),
        columns=[
            parent_account_col,
            ds_ledger_drift["account_name"].dim(),
            ds_ledger_drift["account_role"].dim(),
            parent_day_col,
            ds_ledger_drift["stored_balance"].numerical(currency=True),
            ds_ledger_drift["computed_balance"].numerical(currency=True),
            ds_ledger_drift["drift"].numerical(currency=True),
        ],
        actions=[
            _l1_drill(
                target_sheet=daily_statement_sheet,
                name="View Daily Statement for this account-day",
                writes=[
                    (_DP_DS_ACCOUNT, parent_account_col),
                    (_DP_DS_BALANCE_DATE, parent_day_col),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=parent_account_col, color=accent),
        ],
    )


def _populate_drift_timelines_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
) -> None:
    """Drift Timelines sheet — 2 KPIs + 2 line charts.

    KPIs surface the largest single-day Σ ABS(drift) over the past 7
    days for leaf and parent accounts respectively. Line charts plot
    Σ ABS(drift) per BusinessDay end with one line per account_role,
    so a recurring-drift role visually separates from a one-off spike.

    Datasets pre-aggregate via `GROUP BY business_day_end, account_role`
    on the (already small) drift / ledger_drift matviews. The line-chart
    Y-axis is the SUM of the pre-aggregated `abs_drift` measure since
    the dataset rows are already at (day, role) grain — the SUM is a
    no-op per cell but lets QS render the line chart.
    """
    ds_drift_timeline = datasets[DS_DRIFT_TIMELINE]
    ds_ledger_drift_timeline = datasets[DS_LEDGER_DRIFT_TIMELINE]

    # Row 1: 2 KPIs side-by-side — max single-day Σ ABS(drift) per kind.
    half = _FULL // 2
    kpi_row = sheet.layout.row(height=_KPI_ROW_SPAN)
    kpi_row.add_kpi(
        width=half,
        title="Largest Leaf Drift Day",
        subtitle=(
            "Max Σ ABS(drift) on any single BusinessDay across leaf "
            "accounts in the visible date range. Healthy = $0."
        ),
        values=[ds_drift_timeline["abs_drift"].max(currency=True)],
    )
    kpi_row.add_kpi(
        width=half,
        title="Largest Parent Drift Day",
        subtitle=(
            "Max Σ ABS(drift) on any single BusinessDay across parent "
            "accounts in the visible date range. Healthy = $0."
        ),
        values=[ds_ledger_drift_timeline["abs_drift"].max(currency=True)],
    )

    # Row 2: leaf drift line chart — one line per account_role.
    leaf_day_col = ds_drift_timeline["business_day_end"].date()
    sheet.layout.row(height=_CHART_ROW_SPAN).add_line_chart(
        width=_FULL,
        title="Leaf Account Drift Over Time",
        subtitle=(
            "Σ ABS(drift) per BusinessDay end for leaf accounts, one "
            "line per role. A role hugging zero is healthy; persistent "
            "non-zero ⇒ ongoing feed divergence; one-off spike ⇒ "
            "isolated event worth drilling into."
        ),
        category=[leaf_day_col],
        values=[ds_drift_timeline["abs_drift"].sum(currency=True)],
        colors=[ds_drift_timeline["account_role"].dim()],
        category_label="BusinessDay end",
        value_label="Σ |drift|",
        sort_by=(leaf_day_col, "ASC"),
    )

    # Row 3: ledger (parent) drift line chart — same shape.
    parent_day_col = ds_ledger_drift_timeline["business_day_end"].date()
    sheet.layout.row(height=_CHART_ROW_SPAN).add_line_chart(
        width=_FULL,
        title="Parent Account Drift Over Time",
        subtitle=(
            "Σ ABS(drift) per BusinessDay end for parent accounts, one "
            "line per role. Non-zero ⇒ child postings didn't roll up "
            "correctly that day."
        ),
        category=[parent_day_col],
        values=[ds_ledger_drift_timeline["abs_drift"].sum(currency=True)],
        colors=[ds_ledger_drift_timeline["account_role"].dim()],
        category_label="BusinessDay end",
        value_label="Σ |drift|",
        sort_by=(parent_day_col, "ASC"),
    )


def _populate_overdraft_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    daily_statement_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Overdraft sheet — KPI (count of violations) + violations table.

    Single dataset (`<prefix>_overdraft`) — only internal accounts, only
    days where stored balance < 0. Right-click any row → Daily Statement
    for that account-day (M.2b.7).
    """
    accent = theme.accent
    ds_overdraft = datasets[DS_OVERDRAFT]

    sheet.layout.row(height=_KPI_ROW_SPAN).add_kpi(
        width=_FULL,
        title="Internal Accounts in Overdraft",
        subtitle=(
            "Count of internal-account day-rows holding negative stored "
            "balance — every row in the table below is one violation."
        ),
        values=[ds_overdraft["account_id"].count()],
    )

    account_col = ds_overdraft["account_id"].dim()
    day_col = ds_overdraft["business_day_end"].date()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Overdraft Violations",
        subtitle=(
            "Each internal account-day where stored balance < 0. "
            "Negative magnitude indicates how far below zero the account "
            "ended the day. Right-click any row → View Daily Statement."
        ),
        columns=[
            account_col,
            ds_overdraft["account_name"].dim(),
            ds_overdraft["account_role"].dim(),
            ds_overdraft["account_parent_role"].dim(),
            day_col,
            ds_overdraft["stored_balance"].numerical(currency=True),
        ],
        actions=[
            _l1_drill(
                target_sheet=daily_statement_sheet,
                name="View Daily Statement for this account-day",
                writes=[
                    (_DP_DS_ACCOUNT, account_col),
                    (_DP_DS_BALANCE_DATE, day_col),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=account_col, color=accent),
        ],
    )


def _populate_todays_exceptions_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    l2_instance: L2Instance,
    drift_sheet: Sheet,
    daily_statement_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Today's Exceptions sheet — KPI + check-type breakdown bar +
    sorted detail table.

    Backed by the live UNION ALL dataset across all 5 L1 invariant views
    (drift, ledger_drift, overdraft, limit_breach, expected_eod_balance_breach),
    pre-filtered to the most recent business day at the SQL layer. This
    is the v5 ar_unified_exceptions matview's replacement — no REFRESH
    contract; queries are live.

    M.2a.7: footer TextBox carries the L2 instance's top-level
    description, mirroring the Getting Started welcome — the unified
    view's job is to be the morning landing page, so it gets the
    institution's "what we are" prose at the bottom for context.
    """
    accent = theme.accent
    ds = datasets[DS_TODAYS_EXCEPTIONS]

    # Row 1: total count KPI (full width — single headline number).
    sheet.layout.row(height=_KPI_ROW_SPAN).add_kpi(
        width=_FULL,
        title="Open Exceptions",
        subtitle=(
            "Total count of L1 SHOULD-constraint violations on today's "
            "business day across all 5 invariant checks."
        ),
        values=[ds["account_id"].count()],
    )

    # Row 2: bar chart broken out by check_type (count per check kind).
    # Q.1.c — plain-English axis labels in place of the raw column
    # names QuickSight defaults to ("check_type" / "Count of account_id").
    sheet.layout.row(height=_CHART_ROW_SPAN).add_bar_chart(
        width=_FULL,
        title="Exceptions by Check Type",
        subtitle=(
            "How today's open exceptions distribute across the 5 L1 "
            "invariants. Spikes in one check kind point at a recurring "
            "error class to investigate first."
        ),
        category=[ds["check_type"].dim()],
        values=[ds["account_id"].count()],
        orientation="HORIZONTAL",
        category_label="Check Type",
        value_label="Open Exceptions",
    )

    # Row 3: detail table — every row is one violation, sorted by
    # magnitude DESC so the biggest variances surface first. Drills:
    # left-click → Drift (back-toward per-invariant source); right-click
    # menu → Daily Statement (forward into the per-account-day walk).
    magnitude_col = ds["magnitude"].numerical(currency=True)
    account_col = ds["account_id"].dim()
    business_day_col = ds["business_day"].date()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Exception Detail",
        subtitle=(
            "Every violation on today's business day. Sorted by "
            "magnitude (largest first) so the biggest variances are "
            "the top rows. Left-click an account_id to narrow Drift "
            "to that account; right-click → View Daily Statement to "
            "open the per-account-day walk."
        ),
        columns=[
            ds["check_type"].dim(),
            account_col,
            ds["account_name"].dim(),
            ds["account_role"].dim(),
            ds["account_parent_role"].dim(),
            business_day_col,
            ds["transfer_type"].dim(),
            magnitude_col,
        ],
        sort_by=(magnitude_col, "DESC"),
        actions=[
            _l1_drill(
                target_sheet=drift_sheet,
                name="Narrow Drift to this account",
                writes=[(_DP_FILTER_ACCOUNT, account_col)],
                trigger="DATA_POINT_CLICK",
            ),
            _l1_drill(
                target_sheet=daily_statement_sheet,
                name="View Daily Statement for this account-day",
                writes=[
                    (_DP_DS_ACCOUNT, account_col),
                    (_DP_DS_BALANCE_DATE, business_day_col),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=account_col, color=accent),
        ],
    )

    # Row 4: L2-description footer — the institution's "what we are"
    # prose. Mirrors the Getting Started welcome at the bottom of the
    # unified-view landing page.
    footer_body = (
        l2_instance.description
        if l2_instance.description
        else "(L2 instance description missing — fill the top-level "
             "`description` field in the L2 YAML.)"
    )
    sheet.layout.row(height=6).add_text_box(
        TextBox(
            text_box_id="l1-te-l2-footer",
            content=rt.text_box(
                rt.subheading("Institution Context", color=accent),
                rt.BR,
                rt.markdown(footer_body),
            ),
        ),
        width=_FULL,
    )


def _populate_limit_breach_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    l2_instance: L2Instance,
    daily_statement_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Limit Breach sheet — KPI + per-(account, day, type) breach table.

    Single dataset (`<prefix>_limit_breach`). Each row is one cell where
    cumulative outbound debit on that (account, day, transfer_type)
    exceeded the L2-configured cap. The cap column lives next to the
    outbound_total so analysts can read both numbers at once. Right-click
    any row → Daily Statement for that account-day (M.2b.7).

    M.2a.7: top-of-sheet TextBox enumerates the L2 LimitSchedules
    (parent_role × transfer_type → cap, plus L2-supplied prose) so
    analysts see "what's configured" before "what got breached" —
    description-driven, not hardcoded.
    """
    accent = theme.accent
    ds_lb = datasets[DS_LIMIT_BREACH]

    sheet.layout.row(height=8).add_text_box(
        TextBox(
            text_box_id="l1-lb-config",
            content=rt.text_box(
                rt.subheading("Configured Caps", color=accent),
                rt.BR,
                rt.markdown(
                    "Outbound debit caps from the L2 instance's "
                    "LimitSchedules — these are the thresholds the "
                    "view below compares against:"
                ),
                rt.bullets(_l2_limit_schedule_lines(l2_instance)),
            ),
        ),
        width=_FULL,
    )

    sheet.layout.row(height=_KPI_ROW_SPAN).add_kpi(
        width=_FULL,
        title="Limit Breach Cells",
        subtitle=(
            "Count of (account, day, transfer_type) cells where the "
            "outbound total exceeded the L2-configured cap."
        ),
        values=[ds_lb["account_id"].count()],
    )

    account_col = ds_lb["account_id"].dim()
    day_col = ds_lb["business_day"].date()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Limit Breach Detail",
        subtitle=(
            "Each (account, day, transfer_type) cell where outbound "
            "debit > cap. `outbound_total` and `cap` shown side-by-side "
            "so the magnitude of the breach is readable in-line. "
            "Right-click any row → View Daily Statement."
        ),
        columns=[
            account_col,
            ds_lb["account_name"].dim(),
            ds_lb["account_role"].dim(),
            ds_lb["account_parent_role"].dim(),
            day_col,
            ds_lb["transfer_type"].dim(),
            ds_lb["outbound_total"].numerical(currency=True),
            ds_lb["cap"].numerical(currency=True),
        ],
        actions=[
            _l1_drill(
                target_sheet=daily_statement_sheet,
                name="View Daily Statement for this account-day",
                writes=[
                    (_DP_DS_ACCOUNT, account_col),
                    (_DP_DS_BALANCE_DATE, day_col),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=account_col, color=accent),
        ],
    )


# Aging-bucket helper. Number-prefixed labels keep the QS horizontal
# bar chart sorted correctly without an explicit sort_by override.
# Mirrors AR's aging-bucket convention.

# Pending Aging buckets — finer-grained at the short end since
# max_pending_age caps are typically hours-to-1-day.
_PENDING_AGING_BUCKETS: tuple[tuple[int, str], ...] = (
    (6 * 3600,       "1: 0-6h"),
    (24 * 3600,      "2: 6-24h"),
    (3 * 24 * 3600,  "3: 1-3d"),
    (7 * 24 * 3600,  "4: 3-7d"),
)
_PENDING_AGING_OVERFLOW = "5: >7d"

# Unbundled Aging buckets — coarser at the short end since
# max_unbundled_age is typically a day or two; finer-grained beyond
# that to surface stale shouldn't-still-be-unbundled legs.
_UNBUNDLED_AGING_BUCKETS: tuple[tuple[int, str], ...] = (
    (24 * 3600,      "1: <1d"),
    (2 * 24 * 3600,  "2: 1-2d"),
    (7 * 24 * 3600,  "3: 2-7d"),
)
_UNBUNDLED_AGING_OVERFLOW = "4: >7d"


def _aging_bucket_expression(
    age_col: str,
    *,
    buckets: tuple[tuple[int, str], ...],
    overflow_label: str,
) -> str:
    """Build the QS calc-field expression that buckets a numeric age
    column (in seconds) into labelled bands.

    Each ``(cutoff_seconds, label)`` defines a band; values <= cutoff
    get that label. Anything bigger than the last cutoff falls into
    ``overflow_label``. Builds a nested ``ifelse(...)`` chain.
    """
    expr = f"'{overflow_label}'"
    for cutoff, label in reversed(buckets):
        expr = f"ifelse({{{age_col}}} <= {cutoff}, '{label}', {expr})"
    return expr


def _populate_pending_aging_sheet(
    cfg: Config,
    analysis: Analysis,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    transactions_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Pending Aging sheet — KPI + horizontal aging BarChart + detail.

    Backed by the M.2b.8 `<prefix>_stuck_pending` matview. Aging
    buckets come from a per-dataset CalcField on `age_seconds` (5
    bands; number-prefixed labels keep the bar chart sort stable).
    Right-click any detail-table row → Transactions narrowed to that
    transfer (M.2b.7 drill plumbing).
    """
    accent = theme.accent
    ds = datasets[DS_STUCK_PENDING]

    # Aging-bucket calc field (analysis-level so the BarChart category
    # + detail-table column read the same dim).
    aging_bucket = analysis.add_calc_field(CalcField(
        name="stuck_pending_aging_bucket",
        dataset=ds,
        expression=_aging_bucket_expression(
            "age_seconds",
            buckets=_PENDING_AGING_BUCKETS,
            overflow_label=_PENDING_AGING_OVERFLOW,
        ),
    ))

    # Row 1: total stuck count KPI.
    sheet.layout.row(height=_KPI_ROW_SPAN).add_kpi(
        width=_FULL,
        title="Stuck Pending",
        subtitle=(
            "Count of Pending transactions whose live age has exceeded "
            "their rail's `max_pending_age` cap. Healthy = 0."
        ),
        values=[ds["transaction_id"].count()],
    )

    # Row 2: horizontal aging bar chart — count per bucket.
    sheet.layout.row(height=_CHART_ROW_SPAN).add_bar_chart(
        width=_FULL,
        title="Stuck Pending by Age Bucket",
        category_label="Age Bucket",
        value_label="Transactions",
        subtitle=(
            "Distribution of stuck-Pending transactions across 5 age "
            "bands. Right-skewed (>3d, >7d) ⇒ slow drift; spike at "
            "0-6h ⇒ a recent batch failed to post."
        ),
        category=[Dim(ds, aging_bucket)],
        values=[ds["transaction_id"].count()],
        orientation="HORIZONTAL",
    )

    # Row 3: detail table — every stuck-Pending leg, drillable to
    # Transactions for that transfer.
    transfer_col = ds["transfer_id"].dim()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Stuck Pending Detail",
        subtitle=(
            "Every stuck-Pending leg with rail / amount / posting / "
            "live age. `max_pending_age_seconds` is the rail's cap "
            "(inlined at view-emit time from L2). Right-click any "
            "row → View Transactions to see every leg of that transfer."
        ),
        columns=[
            ds["account_id"].dim(),
            ds["account_name"].dim(),
            transfer_col,
            ds["transfer_type"].dim(),
            ds["rail_name"].dim(),
            ds["amount_money"].numerical(currency=True),
            ds["amount_direction"].dim(),
            ds["posting"].date(),
            Dim(ds, aging_bucket),
            ds["max_pending_age_seconds"].numerical(),
            ds["age_seconds"].numerical(),
        ],
        actions=[
            _l1_drill(
                target_sheet=transactions_sheet,
                name="View Transactions for this transfer",
                # v8.5.7 — widen the destination's universal date
                # filter on drill so a stuck-pending row older than
                # the picker's default 7-day window still surfaces in
                # Transactions. See ``_wide_date_writes`` for why.
                writes=[
                    (_DP_TX_TRANSFER, transfer_col),
                    *_wide_date_writes(),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=transfer_col, color=accent),
        ],
    )


def _populate_unbundled_aging_sheet(
    cfg: Config,
    analysis: Analysis,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    transactions_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Unbundled Aging sheet — KPI + horizontal aging BarChart + detail.

    Mirror of `_populate_pending_aging_sheet` but backed by
    `<prefix>_stuck_unbundled` and using the `_UNBUNDLED_AGING_BUCKETS`
    bucket cadence (4 bands sized for the typical 1-2 day
    `max_unbundled_age` configuration).
    """
    accent = theme.accent
    ds = datasets[DS_STUCK_UNBUNDLED]

    aging_bucket = analysis.add_calc_field(CalcField(
        name="stuck_unbundled_aging_bucket",
        dataset=ds,
        expression=_aging_bucket_expression(
            "age_seconds",
            buckets=_UNBUNDLED_AGING_BUCKETS,
            overflow_label=_UNBUNDLED_AGING_OVERFLOW,
        ),
    ))

    sheet.layout.row(height=_KPI_ROW_SPAN).add_kpi(
        width=_FULL,
        title="Stuck Unbundled",
        subtitle=(
            "Count of Posted transactions whose `bundle_id` is still "
            "NULL past their rail's `max_unbundled_age` cap. Healthy = 0."
        ),
        values=[ds["transaction_id"].count()],
    )

    sheet.layout.row(height=_CHART_ROW_SPAN).add_bar_chart(
        width=_FULL,
        title="Stuck Unbundled by Age Bucket",
        category_label="Age Bucket",
        value_label="Transactions",
        subtitle=(
            "Distribution of stuck-Unbundled transactions across 4 age "
            "bands. Right-skewed (>2d, >7d) ⇒ the bundler hasn't fired "
            "for those rails in a while."
        ),
        category=[Dim(ds, aging_bucket)],
        values=[ds["transaction_id"].count()],
        orientation="HORIZONTAL",
    )

    transfer_col = ds["transfer_id"].dim()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Stuck Unbundled Detail",
        subtitle=(
            "Every stuck-Unbundled leg with rail / amount / posting / "
            "live age. `max_unbundled_age_seconds` is the rail's cap "
            "(inlined at view-emit time from L2). Right-click any "
            "row → View Transactions to see every leg of that transfer."
        ),
        columns=[
            ds["account_id"].dim(),
            ds["account_name"].dim(),
            transfer_col,
            ds["transfer_type"].dim(),
            ds["rail_name"].dim(),
            ds["amount_money"].numerical(currency=True),
            ds["amount_direction"].dim(),
            ds["posting"].date(),
            Dim(ds, aging_bucket),
            ds["max_unbundled_age_seconds"].numerical(),
            ds["age_seconds"].numerical(),
        ],
        actions=[
            _l1_drill(
                target_sheet=transactions_sheet,
                name="View Transactions for this transfer",
                # v8.5.7 — widen the destination's universal date
                # filter on drill (mirror of Pending Aging).
                writes=[
                    (_DP_TX_TRANSFER, transfer_col),
                    *_wide_date_writes(),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=transfer_col, color=accent),
        ],
    )


def _populate_supersession_audit_sheet(
    cfg: Config,
    analysis: Analysis,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    theme: ThemePreset,
) -> None:
    """Supersession Audit sheet — 2 KPIs + 2 detail tables.

    Both detail tables read from BASE tables (not Current*), filtered
    to only logical keys with multiple `entry` versions. The audit
    trail is sorted top-down per logical row so the analyst can read
    what changed across re-postings.

    KPIs: (1) count of distinct logical keys in the transactions audit
    (not row count — one entity can have N entries; we want the entity
    count); (2) count of higher-Entry rows whose `supersedes` reason is
    blank (target value = 0 — every supersession should declare its
    cause per the L1 SPEC).

    `supersedes` filter dropdown applies to the transactions table
    (the daily-balances superceding pattern is so rare in practice
    that adding a second filter would be noise).
    """
    accent = theme.accent
    ds_tx = datasets[DS_SUPERSESSION_TRANSACTIONS]
    ds_db = datasets[DS_SUPERSESSION_DAILY_BALANCES]

    # Q.1.c — analysis-level CalcField returning 1 for higher-Entry
    # rows with no `supersedes` reason and 0 otherwise. SUM over the
    # dataset = count of policy-violating supersessions; healthy
    # value is 0. Defined per-dataset (not in the SQL) so the dataset
    # stays the audit detail surface and the KPI logic stays at the
    # analysis layer where the rest of the L1 calc fields live.
    no_reason_calc = analysis.add_calc_field(CalcField(
        name="l1_supersession_no_reason",
        dataset=ds_tx,
        expression=(
            "ifelse({entry} > 1 AND isNull({supersedes}), 1, 0)"
        ),
    ))

    # Row 1: two half-width KPIs — total supersessions on the left,
    # the no-reason policy-violation count on the right.
    kpi_row = sheet.layout.row(height=_KPI_ROW_SPAN)
    kpi_row.add_kpi(
        width=_HALF,
        title="Logical Keys with Supersession",
        subtitle=(
            "Count of distinct transaction_id values whose append-only "
            "`entry` column has more than one row. Healthy demos may "
            "be 0; production workloads typically have a small steady "
            "trickle of TechnicalCorrection / BundleAssignment events."
        ),
        values=[ds_tx["transaction_id"].distinct_count()],
    )
    kpi_row.add_kpi(
        width=_HALF,
        title="Supersessions with No Reason",
        subtitle=(
            "Count of higher-Entry rows whose `supersedes` reason is "
            "blank. Target value = 0 — every supersession SHOULD "
            "declare its cause (Inflight / BundleAssignment / "
            "TechnicalCorrection) per the L1 SPEC."
        ),
        values=[Measure.sum(dataset=ds_tx, column=no_reason_calc)],
    )

    # Row 2: transactions audit detail — every entry of every
    # superseded logical row, sorted by (transaction_id, entry).
    tx_id_col = ds_tx["transaction_id"].dim()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Transactions Audit",
        subtitle=(
            "Every entry of every logical transaction with >1 entry. "
            "The `supersedes` column on the higher-entry row tells you "
            "why it exists. Use the supersedes filter (Inflight / "
            "BundleAssignment / TechnicalCorrection) to narrow the "
            "audit to one cause class."
        ),
        columns=[
            ds_tx["entry"].numerical(),
            tx_id_col,
            ds_tx["supersedes"].dim(),
            ds_tx["account_id"].dim(),
            ds_tx["account_name"].dim(),
            ds_tx["transfer_id"].dim(),
            ds_tx["transfer_type"].dim(),
            ds_tx["rail_name"].dim(),
            ds_tx["amount_money"].numerical(currency=True),
            ds_tx["amount_direction"].dim(),
            ds_tx["status"].dim(),
            ds_tx["posting"].date(),
            ds_tx["bundle_id"].dim(),
        ],
        conditional_formatting=[
            CellAccentText(on=tx_id_col, color=accent),
        ],
    )

    # Row 3: daily-balances audit detail — every entry of every
    # superseded (account_id, business_day_start) cell.
    db_account_col = ds_db["account_id"].dim()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Daily Balances Audit",
        subtitle=(
            "Every entry of every (account, business_day) cell with "
            "more than one stored value. The `money` column changing "
            "across entries is the audit trail for an end-of-day "
            "re-statement."
        ),
        columns=[
            ds_db["entry"].numerical(),
            db_account_col,
            ds_db["account_name"].dim(),
            ds_db["account_role"].dim(),
            ds_db["supersedes"].dim(),
            ds_db["business_day_start"].date(),
            ds_db["business_day_end"].date(),
            ds_db["money"].numerical(currency=True),
        ],
        conditional_formatting=[
            CellAccentText(on=db_account_col, color=accent),
        ],
    )


def _populate_transactions_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    theme: ThemePreset,
) -> None:
    """Transactions sheet — single detail table over the per-leg ledger.

    No KPIs above the table — the value of this sheet is "show me every
    leg + filter to the slice I care about." Filter dropdowns (wired in
    `_wire_per_sheet_dropdowns`) cover account / transfer / status /
    origin / transfer_type. M.2b.2 link tint on `account_id` +
    `transfer_id` cues the M.2b.7 drill plumbing.
    """
    accent = theme.accent
    ds_tx = datasets[DS_TRANSACTIONS]

    account_col = ds_tx["account_id"].dim()
    transfer_col = ds_tx["transfer_id"].dim()
    posting_col = ds_tx["posting"].date()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Posting Ledger",
        subtitle=(
            "Every Money record (leg) in the L2 instance's current "
            "view — supersession-aware, so replaced entries don't "
            "show. Sorted by posting time DESC so the most recent "
            "activity is at the top."
        ),
        columns=[
            account_col,
            ds_tx["account_name"].dim(),
            ds_tx["account_role"].dim(),
            transfer_col,
            ds_tx["transfer_type"].dim(),
            ds_tx["rail_name"].dim(),
            ds_tx["amount_money"].numerical(currency=True),
            ds_tx["amount_direction"].dim(),
            ds_tx["status"].dim(),
            ds_tx["origin"].dim(),
            posting_col,
        ],
        sort_by=(posting_col, "DESC"),
        conditional_formatting=[
            CellAccentText(on=account_col, color=accent),
            CellAccentText(on=transfer_col, color=accent),
        ],
    )


def _populate_daily_statement_sheet(
    cfg: Config,
    sheet: Sheet,
    *,
    datasets: dict[str, Dataset],
    transactions_sheet: Sheet,
    theme: ThemePreset,
) -> None:
    """Daily Statement — 5 KPIs across the day's walk + detail table.

    KPIs read the summary dataset (one row per account-day after sheet
    filters narrow). Detail table reads the per-leg transactions
    dataset. Both filtered by the M.2b.4 sheet-local
    (P_L1_DS_ACCOUNT, P_L1_DS_BALANCE_DATE) parameters via the filter
    groups wired in `_wire_daily_statement_filters`.
    """
    ds_summary = datasets[DS_DAILY_STATEMENT_SUMMARY]
    ds_txn = datasets[DS_DAILY_STATEMENT_TRANSACTIONS]

    # Row 1: 5 KPIs at width 7 each (sums to 35 of 36 grid cols; 1
    # column slack on the right).
    kpi_width = 7
    kpi_row = sheet.layout.row(height=_KPI_ROW_SPAN)
    kpi_row.add_kpi(
        width=kpi_width,
        title="Opening Balance",
        subtitle="End-of-prior-day stored balance for the picked account.",
        values=[ds_summary["opening_balance"].max(currency=True)],
    )
    kpi_row.add_kpi(
        width=kpi_width,
        title="Debits",
        subtitle="Sum of Debit-direction Money records posted today.",
        values=[ds_summary["total_debits"].max(currency=True)],
    )
    kpi_row.add_kpi(
        width=kpi_width,
        title="Credits",
        subtitle="Sum of Credit-direction Money records posted today.",
        values=[ds_summary["total_credits"].max(currency=True)],
    )
    kpi_row.add_kpi(
        width=kpi_width,
        title="Closing Stored",
        subtitle="The day's stored closing balance from the feed.",
        values=[ds_summary["closing_balance_stored"].max(currency=True)],
    )
    kpi_row.add_kpi(
        width=kpi_width,
        title="Drift",
        subtitle=(
            "Stored − recomputed. Non-zero ⇒ feed doesn't reconcile."
        ),
        values=[ds_summary["drift"].max(currency=True)],
    )

    # Row 2: detail table — every Money record posted that day for the
    # picked account, after sheet filters narrow. Right-click any row →
    # Transactions narrowed to that transfer_id (every leg of the
    # multi-leg transfer the clicked row is part of).
    accent = theme.accent
    transfer_col = ds_txn["transfer_id"].dim()
    sheet.layout.row(height=_TABLE_ROW_SPAN).add_table(
        width=_FULL,
        title="Posted Money Records",
        subtitle=(
            "Every leg posted on the picked account-day. Direction "
            "shows Debit / Credit; status filters out Failed legs in "
            "the summary KPIs but not here. Right-click any row → "
            "View Transactions to see every leg of that transfer."
        ),
        columns=[
            ds_txn["transaction_id"].dim(),
            transfer_col,
            ds_txn["transfer_type"].dim(),
            ds_txn["amount_money"].numerical(currency=True),
            ds_txn["amount_direction"].dim(),
            ds_txn["status"].dim(),
            ds_txn["origin"].dim(),
            ds_txn["posting"].date(),
        ],
        actions=[
            _l1_drill(
                target_sheet=transactions_sheet,
                name="View Transactions for this transfer",
                # v8.5.7 — widen the destination's universal date
                # filter on drill (mirror of Pending Aging).
                writes=[
                    (_DP_TX_TRANSFER, transfer_col),
                    *_wide_date_writes(),
                ],
                trigger="DATA_POINT_MENU",
            ),
        ],
        conditional_formatting=[
            CellAccentText(on=transfer_col, color=accent),
        ],
    )


# -- M.2b.1: Universal date-range filter -------------------------------------
#
# Two analysis-level DateTimeParams drive a per-dataset FilterGroup family:
# every data-bearing sheet has paired date-time picker controls bound to the
# same params, so changing the date range on one sheet propagates to all.
# Per-dataset FilterGroups (rather than a single ALL_DATASETS group) because
# the L1 invariant views don't share a single date column name — daily-balance
# views expose `business_day_start`, while limit_breach + todays_exceptions
# expose `business_day` (DATE_TRUNC of posting). Per-dataset binding sidesteps
# the column-name mismatch without a schema migration.


# Default = last 7 days. QuickSight rolling-date expressions handle the
# "today" anchor; addDateTime yields the start-of-window 7 days back.
_DATE_END_DEFAULT_EXPR = "truncDate('DD', now())"
_DATE_START_DEFAULT_EXPR = "addDateTime(-7, 'DD', truncDate('DD', now()))"


def _wire_date_range_filter(
    analysis: Analysis,
    *,
    datasets: dict[str, Dataset],
    drift_sheet: Sheet,
    drift_timelines_sheet: Sheet,
    overdraft_sheet: Sheet,
    limit_breach_sheet: Sheet,
    pending_aging_sheet: Sheet,
    unbundled_aging_sheet: Sheet,
    supersession_audit_sheet: Sheet,
    todays_exceptions_sheet: Sheet,
    transactions_sheet: Sheet,
) -> None:
    """Wire the universal date-range filter (params + groups + controls).

    Adds 2 DateTimeParams (P_L1_DATE_START + P_L1_DATE_END) with rolling
    7-day defaults; 5 SINGLE_DATASET FilterGroups (one per data-bearing
    dataset, each scoped to its sheet); paired ParameterDateTimePicker
    controls on every data-bearing sheet so the analyst sets the window
    once and it propagates.
    """
    date_start = analysis.add_parameter(DateTimeParam(
        name=P_L1_DATE_START,
        time_granularity="DAY",
        default=DateTimeDefaultValues(
            RollingDate={"Expression": _DATE_START_DEFAULT_EXPR},
        ),
    ))
    date_end = analysis.add_parameter(DateTimeParam(
        name=P_L1_DATE_END,
        time_granularity="DAY",
        default=DateTimeDefaultValues(
            RollingDate={"Expression": _DATE_END_DEFAULT_EXPR},
        ),
    ))

    # Param-bound dict literals — TimeRangeFilter.minimum/maximum are
    # passthrough dicts; {"Parameter": "<name>"} is the AWS shape for
    # parameter-driven bounds (mirrors how DateTimeDefaultValues
    # passthrough works).
    min_bound: dict[str, str] = {"Parameter": P_L1_DATE_START}
    max_bound: dict[str, str] = {"Parameter": P_L1_DATE_END}

    def _scope_one(
        dataset_key: str, date_col: str, sheet: Sheet, fg_id: str,
    ) -> None:
        ds = datasets[dataset_key]
        fg = analysis.add_filter_group(FilterGroup(
            filter_group_id=fg_id,  # type: ignore[arg-type]
            cross_dataset="SINGLE_DATASET",
            filters=[TimeRangeFilter(
                filter_id=f"filter-{fg_id}",
                dataset=ds,
                column=ds[date_col],
                null_option="NON_NULLS_ONLY",
                time_granularity="DAY",
                minimum=min_bound,
                maximum=max_bound,
            )],
        ))
        fg.scope_sheet(sheet)

    # Drift sheet — both leaf-drift + parent-drift datasets share
    # business_day_start.
    _scope_one(DS_DRIFT, "business_day_start", drift_sheet,
               "fg-l1-date-drift")
    _scope_one(DS_LEDGER_DRIFT, "business_day_start", drift_sheet,
               "fg-l1-date-ledger-drift")
    # Drift Timelines uses pre-aggregated datasets keyed on
    # business_day_end (one row per (day, role)).
    _scope_one(DS_DRIFT_TIMELINE, "business_day_end",
               drift_timelines_sheet, "fg-l1-date-drift-timeline")
    _scope_one(DS_LEDGER_DRIFT_TIMELINE, "business_day_end",
               drift_timelines_sheet, "fg-l1-date-ledger-drift-timeline")
    _scope_one(DS_OVERDRAFT, "business_day_start", overdraft_sheet,
               "fg-l1-date-overdraft")
    # Limit breach + today's exceptions expose `business_day` (truncated
    # posting), not `business_day_start`.
    _scope_one(DS_LIMIT_BREACH, "business_day", limit_breach_sheet,
               "fg-l1-date-limit-breach")
    _scope_one(DS_TODAYS_EXCEPTIONS, "business_day",
               todays_exceptions_sheet, "fg-l1-date-todays-exceptions")
    # Q.1.b — Transactions sheet over the per-leg ledger; same `posting`
    # column shape as Pending/Unbundled Aging.
    _scope_one(DS_TRANSACTIONS, "posting", transactions_sheet,
               "fg-l1-date-transactions")
    # NOTE: stuck_pending / stuck_unbundled / supersession sheets
    # intentionally skip date scoping. Their matviews are current-state
    # (no posting/business_day filter on the audit query side either) —
    # a "stuck" item is stuck until cleared, regardless of the analyst's
    # period of interest. Adding a date filter here makes the dashboard
    # diverge from the audit PDF (PDF surfaces every current-state row;
    # filtered dashboard could drop them) and breaks U.8.b's three-way
    # agreement contract.

    # Per-sheet date pickers — bound to the shared params so every
    # date-scoped sheet's pickers sync. The current-state sheets
    # (pending_aging, unbundled_aging, supersession_audit) are
    # intentionally absent — see _scope_one note above.
    for sheet in (
        drift_sheet, drift_timelines_sheet, overdraft_sheet,
        limit_breach_sheet, todays_exceptions_sheet,
        transactions_sheet,
    ):
        sheet.add_parameter_datetime_picker(
            parameter=date_start, title="Date From",
        )
        sheet.add_parameter_datetime_picker(
            parameter=date_end, title="Date To",
        )


def _wire_per_sheet_dropdowns(
    analysis: Analysis,
    *,
    datasets: dict[str, Dataset],
    drift_sheet: Sheet,
    drift_timelines_sheet: Sheet,
    overdraft_sheet: Sheet,
    limit_breach_sheet: Sheet,
    pending_aging_sheet: Sheet,
    unbundled_aging_sheet: Sheet,
    supersession_audit_sheet: Sheet,
    todays_exceptions_sheet: Sheet,
    transactions_sheet: Sheet,
) -> None:
    """M.2b.3 — per-sheet category filter dropdowns.

    Each dropdown is a multi-select with empty-default-means-all
    (`select_all_options="FILTER_ALL_VALUES"`), keyed off a
    `CategoryFilter.with_values(values=[])` per AR's pattern. Single-
    sheet scope (cross_dataset SINGLE_DATASET) for sheets backed by one
    dataset; cross_dataset ALL_DATASETS only on the Drift sheet, which
    has both leaf-drift + parent-drift datasets sharing the same
    column names.
    """

    def _dropdown(
        *,
        fg_id: str,
        ds: Dataset,
        col: str,
        title: str,
        sheet: Sheet,
        cross_dataset: str = "SINGLE_DATASET",
    ) -> None:
        cat_filter = CategoryFilter.with_values(
            filter_id=f"filter-{fg_id}",
            dataset=ds,
            column=ds[col],
            values=[],
            select_all_options="FILTER_ALL_VALUES",
        )
        fg = analysis.add_filter_group(FilterGroup(
            filter_group_id=fg_id,  # type: ignore[arg-type]
            cross_dataset=cross_dataset,  # type: ignore[arg-type]
            filters=[cat_filter],
        ))
        fg.scope_sheet(sheet)
        sheet.add_filter_dropdown(filter=cat_filter, title=title)

    ds_drift = datasets[DS_DRIFT]
    ds_overdraft = datasets[DS_OVERDRAFT]
    ds_lb = datasets[DS_LIMIT_BREACH]
    ds_te = datasets[DS_TODAYS_EXCEPTIONS]

    # Drift — both drift + ledger_drift datasets share column names, so
    # ALL_DATASETS lets one dropdown filter both tables on the sheet.
    _dropdown(
        fg_id="fg-l1-drift-account", ds=ds_drift, col="account_id",
        title="Account", sheet=drift_sheet, cross_dataset="ALL_DATASETS",
    )
    _dropdown(
        fg_id="fg-l1-drift-role", ds=ds_drift, col="account_role",
        title="Account Role", sheet=drift_sheet,
        cross_dataset="ALL_DATASETS",
    )

    # Drift Timelines — both timeline datasets share column names too.
    ds_drift_tl = datasets[DS_DRIFT_TIMELINE]
    _dropdown(
        fg_id="fg-l1-drift-tl-role", ds=ds_drift_tl, col="account_role",
        title="Account Role", sheet=drift_timelines_sheet,
        cross_dataset="ALL_DATASETS",
    )

    # Overdraft — single dataset.
    _dropdown(
        fg_id="fg-l1-overdraft-account", ds=ds_overdraft,
        col="account_id", title="Account", sheet=overdraft_sheet,
    )
    _dropdown(
        fg_id="fg-l1-overdraft-role", ds=ds_overdraft,
        col="account_role", title="Account Role",
        sheet=overdraft_sheet,
    )

    # Limit Breach — single dataset; account + transfer_type.
    _dropdown(
        fg_id="fg-l1-limit-breach-account", ds=ds_lb, col="account_id",
        title="Account", sheet=limit_breach_sheet,
    )
    _dropdown(
        fg_id="fg-l1-limit-breach-type", ds=ds_lb, col="transfer_type",
        title="Transfer Type", sheet=limit_breach_sheet,
    )

    # Pending Aging — account / transfer_type / rail_name (per the
    # M.2b.10 plan).
    ds_sp = datasets[DS_STUCK_PENDING]
    _dropdown(
        fg_id="fg-l1-pending-account", ds=ds_sp, col="account_id",
        title="Account", sheet=pending_aging_sheet,
    )
    _dropdown(
        fg_id="fg-l1-pending-type", ds=ds_sp, col="transfer_type",
        title="Transfer Type", sheet=pending_aging_sheet,
    )
    _dropdown(
        fg_id="fg-l1-pending-rail", ds=ds_sp, col="rail_name",
        title="Rail", sheet=pending_aging_sheet,
    )

    # Unbundled Aging — same 3 dropdowns over the stuck_unbundled
    # dataset.
    ds_su = datasets[DS_STUCK_UNBUNDLED]
    _dropdown(
        fg_id="fg-l1-unbundled-account", ds=ds_su, col="account_id",
        title="Account", sheet=unbundled_aging_sheet,
    )
    _dropdown(
        fg_id="fg-l1-unbundled-type", ds=ds_su, col="transfer_type",
        title="Transfer Type", sheet=unbundled_aging_sheet,
    )
    _dropdown(
        fg_id="fg-l1-unbundled-rail", ds=ds_su, col="rail_name",
        title="Rail", sheet=unbundled_aging_sheet,
    )

    # Supersession Audit — supersedes-reason dropdown narrows the
    # transactions table to one cause class (Inflight /
    # BundleAssignment / TechnicalCorrection). The daily-balances
    # table doesn't get a paired filter — supersession on
    # daily_balances is rare enough that a second control would be
    # noise.
    ds_sa_tx = datasets[DS_SUPERSESSION_TRANSACTIONS]
    _dropdown(
        fg_id="fg-l1-supersession-reason", ds=ds_sa_tx, col="supersedes",
        title="Supersedes Reason", sheet=supersession_audit_sheet,
    )

    # Today's Exceptions — check_type narrows the unified UNION; account
    # + transfer_type are the secondary narrow-downs.
    _dropdown(
        fg_id="fg-l1-todays-exc-check-type", ds=ds_te, col="check_type",
        title="Check Type", sheet=todays_exceptions_sheet,
    )
    _dropdown(
        fg_id="fg-l1-todays-exc-account", ds=ds_te, col="account_id",
        title="Account", sheet=todays_exceptions_sheet,
    )
    _dropdown(
        fg_id="fg-l1-todays-exc-type", ds=ds_te, col="transfer_type",
        title="Transfer Type", sheet=todays_exceptions_sheet,
    )

    # Transactions — 5 dropdowns covering the analyst's narrow vectors:
    # account / transfer / status / origin / transfer_type.
    ds_tx = datasets[DS_TRANSACTIONS]
    _dropdown(
        fg_id="fg-l1-tx-account", ds=ds_tx, col="account_id",
        title="Account", sheet=transactions_sheet,
    )
    _dropdown(
        fg_id="fg-l1-tx-transfer", ds=ds_tx, col="transfer_id",
        title="Transfer", sheet=transactions_sheet,
    )
    _dropdown(
        fg_id="fg-l1-tx-status", ds=ds_tx, col="status",
        title="Status", sheet=transactions_sheet,
    )
    _dropdown(
        fg_id="fg-l1-tx-origin", ds=ds_tx, col="origin",
        title="Origin", sheet=transactions_sheet,
    )
    _dropdown(
        fg_id="fg-l1-tx-type", ds=ds_tx, col="transfer_type",
        title="Transfer Type", sheet=transactions_sheet,
    )


def _wire_daily_statement_filters(
    analysis: Analysis,
    *,
    datasets: dict[str, Dataset],
    daily_statement_sheet: Sheet,
) -> None:
    """M.2b.4 — wire the Daily Statement sheet's per-account-day filter.

    Two analysis-level parameters (P_L1_DS_ACCOUNT, P_L1_DS_BALANCE_DATE)
    drive both the summary dataset and the transactions dataset via two
    SINGLE_DATASET FilterGroups each — same-shape (account_id +
    business_day_start) on the summary, (account_id + business_day) on
    the transactions. ParameterDropdown + ParameterDateTimePicker
    controls on the sheet bind to the params, so changing either
    propagates to KPIs + table at once.

    No defaults are pinned (no `RollingDate` / `default=...`) — at
    first load the controls render empty and the analyst picks. This
    avoids the no-hardcoded-data trap where a default account_id
    would have to know an L2-specific value.
    """
    ds_account = analysis.add_parameter(StringParam(
        name=P_L1_DS_ACCOUNT,
    ))
    ds_balance_date = analysis.add_parameter(DateTimeParam(
        name=P_L1_DS_BALANCE_DATE,
        time_granularity="DAY",
        # M.4.4.10ab — must have a default; QS UI errors with
        # "epochMilliseconds must be a number, you gave: null"
        # when the picker initializes with no value.
        #
        # Q.1.c — default to YESTERDAY rather than today. Today's
        # daily-balance row may not exist yet (the EOD job hasn't run
        # for today's business day), so a today-default lands on a
        # blank statement until late-day. Yesterday is the latest day
        # guaranteed to have closed-out balance rows.
        default=DateTimeDefaultValues(
            RollingDate={
                "Expression": "addDateTime(-1, 'DD', truncDate('DD', now()))",
            },
        ),
    ))

    summary_ds = datasets[DS_DAILY_STATEMENT_SUMMARY]
    txn_ds = datasets[DS_DAILY_STATEMENT_TRANSACTIONS]

    # Summary dataset: account_id + business_day_start.
    summary_account_fg = analysis.add_filter_group(FilterGroup(
        filter_group_id="fg-l1-ds-summary-account",  # type: ignore[arg-type]
        cross_dataset="SINGLE_DATASET",
        filters=[CategoryFilter.with_parameter(
            filter_id="filter-l1-ds-summary-account",
            dataset=summary_ds,
            column=summary_ds["account_id"],
            parameter=ds_account,
        )],
    ))
    summary_account_fg.scope_sheet(daily_statement_sheet)

    summary_date_fg = analysis.add_filter_group(FilterGroup(
        filter_group_id="fg-l1-ds-summary-date",  # type: ignore[arg-type]
        cross_dataset="SINGLE_DATASET",
        filters=[TimeEqualityFilter(
            filter_id="filter-l1-ds-summary-date",
            dataset=summary_ds,
            column=summary_ds["business_day_start"],
            parameter=ds_balance_date,
            time_granularity="DAY",
        )],
    ))
    summary_date_fg.scope_sheet(daily_statement_sheet)

    # Transactions dataset: account_id + business_day (DATE_TRUNC of
    # posting); same parameter-bound shape.
    txn_account_fg = analysis.add_filter_group(FilterGroup(
        filter_group_id="fg-l1-ds-txn-account",  # type: ignore[arg-type]
        cross_dataset="SINGLE_DATASET",
        filters=[CategoryFilter.with_parameter(
            filter_id="filter-l1-ds-txn-account",
            dataset=txn_ds,
            column=txn_ds["account_id"],
            parameter=ds_account,
        )],
    ))
    txn_account_fg.scope_sheet(daily_statement_sheet)

    txn_date_fg = analysis.add_filter_group(FilterGroup(
        filter_group_id="fg-l1-ds-txn-date",  # type: ignore[arg-type]
        cross_dataset="SINGLE_DATASET",
        filters=[TimeEqualityFilter(
            filter_id="filter-l1-ds-txn-date",
            dataset=txn_ds,
            column=txn_ds["business_day"],
            parameter=ds_balance_date,
            time_granularity="DAY",
        )],
    ))
    txn_date_fg.scope_sheet(daily_statement_sheet)

    # Sheet controls — single-select dropdown + datetime picker bound
    # to the params. The dropdown's options are auto-populated from the
    # summary dataset's `account_id` column (LinkedValues), so the
    # analyst sees the institution's actual accounts. Without this,
    # QuickSight has no source for the dropdown and only shows the
    # empty-state "All" placeholder — which on a SINGLE_SELECT
    # parameter-bound CategoryFilter narrows to nothing, so every
    # KPI / table on the sheet renders empty until the analyst can
    # pick a value (which they can't, because the dropdown is empty).
    # `hidden_select_all=True` because SINGLE_SELECT semantically
    # requires picking exactly one — "All" doesn't apply.
    daily_statement_sheet.add_parameter_dropdown(
        parameter=ds_account, title="Account",
        type="SINGLE_SELECT",
        selectable_values=LinkedValues.from_column(summary_ds["account_id"]),
        hidden_select_all=True,
    )
    daily_statement_sheet.add_parameter_datetime_picker(
        parameter=ds_balance_date, title="Business Day",
    )


# ---------------------------------------------------------------------------
# M.2b.7 — Cross-sheet drill plumbing
# ---------------------------------------------------------------------------
#
# Two sentinel-pattern parameters (`pL1FilterAccount`, `pL1TxTransfer`)
# carry the drill-target value. Each destination sheet has a calc-field-
# backed FilterGroup that reads its parameter and either narrows the
# dataset to one row or PASSes everything through (when the param is
# the `__ALL__` sentinel).
#
# Drill writes auto-reset every sentinel-pattern param the caller didn't
# explicitly write — so a stale "I drilled to account-A on Drift earlier"
# value doesn't leak into the next drill's filtered view. Mirrors the
# AR `_ar_drill_to_transactions` pattern.

# Auto-reset list — only the sentinel-pattern params. Picker-driven
# params (P_L1_DS_*, P_L1_DATE_*) stay sticky across drills, since
# clearing a DateTimeParam to a string sentinel would break it.
_L1_DRILL_RESET_PARAMS = (_DP_FILTER_ACCOUNT, _DP_TX_TRANSFER)


def _l1_drill(
    *,
    target_sheet: Sheet,
    name: str,
    writes: list,  # list[tuple[DrillParam, ...]]
    trigger: str = "DATA_POINT_CLICK",
    action_id: str | AutoResolved = AUTO,
) -> Drill:
    """Cross-sheet drill with auto-reset on un-written sentinel params.

    Caller writes only the params that should narrow the destination;
    any sentinel-pattern param the caller doesn't write gets a
    DrillResetSentinel write, so a prior drill's value can't leak.
    """
    written = {param.name for param, _ in writes}
    full_writes = list(writes)
    for param in _L1_DRILL_RESET_PARAMS:
        if param.name not in written:
            full_writes.append((param, DrillResetSentinel()))
    return Drill(
        target_sheet=target_sheet,
        writes=full_writes,
        name=name,
        trigger=trigger,  # type: ignore[arg-type]
        action_id=action_id,
    )


def _wire_drill_filter_groups(
    analysis: Analysis,
    *,
    datasets: dict[str, Dataset],
    sheets: dict[str, Sheet],
) -> None:
    """5 sentinel-pattern FilterGroups + their backing calc fields.

    Each spec encodes one drill-destination filter:
    - parameter to test (sentinel-pattern StringParam, default "__ALL__")
    - destination dataset + the column to compare against
    - destination sheet to scope the FilterGroup to

    The calc-field expression is the K.2 sentinel-or-match pattern;
    the FilterGroup uses ``CategoryFilter.with_literal(value="PASS")``
    so the parameter test lives in the calc field — sidesteps the
    parameter-bound CustomFilterConfiguration's empty-string narrowing
    bug AR's docstring calls out.

    Parameters are added to the analysis via ``_wire_drill_parameters``;
    this helper wires the per-destination calc field + filter group.
    """
    # Declare the 2 drill-target StringParams with sentinel defaults.
    analysis.add_parameter(StringParam(
        name=P_L1_FILTER_ACCOUNT,
        default=[_DRILL_RESET_SENTINEL],
    ))
    analysis.add_parameter(StringParam(
        name=P_L1_TX_TRANSFER,
        default=[_DRILL_RESET_SENTINEL],
    ))

    @dataclass(frozen=True)
    class _DrillDest:
        fg_id: str
        param_name: str
        dataset_id: str
        column_name: str
        sheet_id: str

    specs: list[_DrillDest] = [
        _DrillDest(
            fg_id="fg-l1-drill-account-on-drift",
            param_name=P_L1_FILTER_ACCOUNT,
            dataset_id=DS_DRIFT,
            column_name="account_id",
            sheet_id=SHEET_DRIFT,
        ),
        _DrillDest(
            fg_id="fg-l1-drill-account-on-ledger-drift",
            param_name=P_L1_FILTER_ACCOUNT,
            dataset_id=DS_LEDGER_DRIFT,
            column_name="account_id",
            sheet_id=SHEET_DRIFT,
        ),
        _DrillDest(
            fg_id="fg-l1-drill-account-on-overdraft",
            param_name=P_L1_FILTER_ACCOUNT,
            dataset_id=DS_OVERDRAFT,
            column_name="account_id",
            sheet_id=SHEET_OVERDRAFT,
        ),
        _DrillDest(
            fg_id="fg-l1-drill-account-on-limit-breach",
            param_name=P_L1_FILTER_ACCOUNT,
            dataset_id=DS_LIMIT_BREACH,
            column_name="account_id",
            sheet_id=SHEET_LIMIT_BREACH,
        ),
        _DrillDest(
            fg_id="fg-l1-drill-transfer-on-transactions",
            param_name=P_L1_TX_TRANSFER,
            dataset_id=DS_TRANSACTIONS,
            column_name="transfer_id",
            sheet_id=SHEET_TRANSACTIONS,
        ),
    ]

    for spec in specs:
        ds = datasets[spec.dataset_id]
        # Sentinel-or-match calc field. Mirrors AR's
        # `_drill_pass_<param>_on_<suffix>` shape so the analyst-facing
        # calc-field name reads consistently across apps.
        on_suffix = spec.fg_id.split("on-", 1)[-1].replace("-", "_")
        calc_name = f"_drill_pass_{spec.param_name}_on_{on_suffix}"
        calc = analysis.add_calc_field(CalcField(
            name=calc_name,
            dataset=ds,
            expression=(
                f"ifelse("
                f"${{{spec.param_name}}} = '{_DRILL_RESET_SENTINEL}', "
                f"'PASS', "
                f"ifelse({{{spec.column_name}}} = ${{{spec.param_name}}}, "
                f"'PASS', 'FAIL')"
                f")"
            ),
        ))
        fg = analysis.add_filter_group(FilterGroup(
            filter_group_id=spec.fg_id,  # type: ignore[arg-type]
            cross_dataset="SINGLE_DATASET",
            filters=[CategoryFilter.with_literal(
                filter_id=f"filter-{spec.fg_id}",
                dataset=ds,
                column=calc,
                value="PASS",
                null_option="NON_NULLS_ONLY",
            )],
        ))
        fg.scope_sheet(sheets[spec.sheet_id])


def build_l1_dashboard_app(
    cfg: Config,
    *,
    l2_instance: L2Instance | None = None,
) -> App:
    """Construct the L1 Reconciliation Dashboard App as a tree.

    M.2a.3: registers Analysis + Dashboard + Getting Started + Drift
    sheets, plus the 2 L1 invariant datasets (drift + ledger_drift).
    Substeps M.2a.4-M.2a.6 add the remaining per-invariant sheets
    (Overdraft, Limit Breach, Today's Exceptions). Each sheet IS one
    L1 SHOULD-constraint visualized via the M.1a.7 invariant views.

    Dashboard ID convention: ``<resource_prefix>-<l2_prefix>-l1-dashboard``
    (M.2d.3) — the L2 instance prefix becomes the middle segment so N
    apps (L1, PR, Exec) can deploy against the same L2 instance, AND
    the same app can deploy against N L2 instances, all in one QS
    account without collision. The L2 instance prefix is derived
    automatically from ``l2_instance.instance`` here so callers don't
    have to pre-stamp ``cfg.l2_instance_prefix``; if the caller HAS
    pre-set it (e.g. an integrator running a custom build), that
    value is preserved.
    """
    if l2_instance is None:
        l2_instance = default_l2_instance()

    if cfg.l2_instance_prefix is None:
        cfg = cfg.with_l2_instance_prefix(str(l2_instance.instance))

    # N.1.e / N.4.k — resolve theme once from the L2 instance, coerced
    # to the registry default for in-canvas accent colors when the
    # instance declares no inline ``theme:`` block. The CLI uses the
    # un-coerced ``resolve_l2_theme`` return to decide whether to
    # deploy a custom Theme resource (silent-fallback to AWS CLASSIC).
    from quicksight_gen.common.theme import DEFAULT_PRESET
    theme = resolve_l2_theme(l2_instance) or DEFAULT_PRESET

    app = App(name="l1-dashboard", cfg=cfg)
    analysis = app.set_analysis(Analysis(
        analysis_id_suffix="l1-dashboard-analysis",
        name=_analysis_name(cfg, l2_instance),
    ))

    # Datasets first — registers contracts so visual ds["col"] refs validate.
    datasets = _l1_datasets(cfg, l2_instance)
    for ds in datasets.values():
        app.add_dataset(ds)

    # M.2b.7 — sheets built upfront so populators can drill across.
    getting_started = analysis.add_sheet(Sheet(
        sheet_id=SHEET_GETTING_STARTED,
        name=_GETTING_STARTED_NAME,
        title=_GETTING_STARTED_TITLE,
        description=_GETTING_STARTED_DESCRIPTION,
    ))
    drift_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_DRIFT,
        name=_DRIFT_NAME,
        title=_DRIFT_TITLE,
        description=_DRIFT_DESCRIPTION,
    ))
    drift_timelines_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_DRIFT_TIMELINES,
        name=_DRIFT_TIMELINES_NAME,
        title=_DRIFT_TIMELINES_TITLE,
        description=_DRIFT_TIMELINES_DESCRIPTION,
    ))
    overdraft_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_OVERDRAFT,
        name=_OVERDRAFT_NAME,
        title=_OVERDRAFT_TITLE,
        description=_OVERDRAFT_DESCRIPTION,
    ))
    limit_breach_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_LIMIT_BREACH,
        name=_LIMIT_BREACH_NAME,
        title=_LIMIT_BREACH_TITLE,
        description=_LIMIT_BREACH_DESCRIPTION,
    ))
    pending_aging_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_PENDING_AGING,
        name=_PENDING_AGING_NAME,
        title=_PENDING_AGING_TITLE,
        description=_PENDING_AGING_DESCRIPTION,
    ))
    unbundled_aging_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_UNBUNDLED_AGING,
        name=_UNBUNDLED_AGING_NAME,
        title=_UNBUNDLED_AGING_TITLE,
        description=_UNBUNDLED_AGING_DESCRIPTION,
    ))
    supersession_audit_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_SUPERSESSION_AUDIT,
        name=_SUPERSESSION_AUDIT_NAME,
        title=_SUPERSESSION_AUDIT_TITLE,
        description=_SUPERSESSION_AUDIT_DESCRIPTION,
    ))
    todays_exceptions_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_TODAYS_EXCEPTIONS,
        name=_TODAYS_EXCEPTIONS_NAME,
        title=_TODAYS_EXCEPTIONS_TITLE,
        description=_TODAYS_EXCEPTIONS_DESCRIPTION,
    ))
    daily_statement_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_DAILY_STATEMENT,
        name=_DAILY_STATEMENT_NAME,
        title=_DAILY_STATEMENT_TITLE,
        description=_DAILY_STATEMENT_DESCRIPTION,
    ))
    transactions_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_TRANSACTIONS,
        name=_TRANSACTIONS_NAME,
        title=_TRANSACTIONS_TITLE,
        description=_TRANSACTIONS_DESCRIPTION,
    ))
    # M.4.4.5 — App Info ("i") sheet, ALWAYS LAST. Diagnostic canary;
    # see common/sheets/app_info.py.
    app_info_sheet = analysis.add_sheet(Sheet(
        sheet_id=SHEET_APP_INFO,
        name=APP_INFO_SHEET_NAME,
        title=APP_INFO_SHEET_TITLE,
        description=APP_INFO_SHEET_DESCRIPTION,
    ))

    # Populators — each receives the sheets it drills into so the drill
    # actions can reference target_sheet by typed ref. ``theme`` is the
    # N.1-resolved L2 brand theme (or the registry default fallback).
    _populate_getting_started(cfg, getting_started, l2_instance, theme=theme)
    _populate_drift_sheet(
        cfg, drift_sheet, datasets=datasets, l2_instance=l2_instance,
        daily_statement_sheet=daily_statement_sheet, theme=theme,
    )
    _populate_drift_timelines_sheet(
        cfg, drift_timelines_sheet, datasets=datasets,
    )
    _populate_overdraft_sheet(
        cfg, overdraft_sheet, datasets=datasets,
        daily_statement_sheet=daily_statement_sheet, theme=theme,
    )
    _populate_limit_breach_sheet(
        cfg, limit_breach_sheet,
        datasets=datasets, l2_instance=l2_instance,
        daily_statement_sheet=daily_statement_sheet, theme=theme,
    )
    _populate_pending_aging_sheet(
        cfg, analysis, pending_aging_sheet,
        datasets=datasets,
        transactions_sheet=transactions_sheet, theme=theme,
    )
    _populate_unbundled_aging_sheet(
        cfg, analysis, unbundled_aging_sheet,
        datasets=datasets,
        transactions_sheet=transactions_sheet, theme=theme,
    )
    _populate_supersession_audit_sheet(
        cfg, analysis, supersession_audit_sheet,
        datasets=datasets, theme=theme,
    )
    _populate_todays_exceptions_sheet(
        cfg, todays_exceptions_sheet,
        datasets=datasets, l2_instance=l2_instance,
        drift_sheet=drift_sheet,
        daily_statement_sheet=daily_statement_sheet, theme=theme,
    )
    _populate_daily_statement_sheet(
        cfg, daily_statement_sheet, datasets=datasets,
        transactions_sheet=transactions_sheet, theme=theme,
    )
    _populate_transactions_sheet(
        cfg, transactions_sheet, datasets=datasets, theme=theme,
    )
    populate_app_info_sheet(
        cfg, app_info_sheet,
        liveness_ds=datasets[DS_APP_INFO_LIVENESS],
        matview_status_ds=datasets[DS_APP_INFO_MATVIEWS],
        theme=theme,
    )

    # M.2b.1 — Universal date-range filter wires the sheets together.
    # Lands AFTER all sheets are populated since the FilterGroups scope
    # by sheet ref + the controls register on the sheets directly.
    _wire_date_range_filter(
        analysis,
        datasets=datasets,
        drift_sheet=drift_sheet,
        drift_timelines_sheet=drift_timelines_sheet,
        overdraft_sheet=overdraft_sheet,
        limit_breach_sheet=limit_breach_sheet,
        pending_aging_sheet=pending_aging_sheet,
        unbundled_aging_sheet=unbundled_aging_sheet,
        supersession_audit_sheet=supersession_audit_sheet,
        todays_exceptions_sheet=todays_exceptions_sheet,
        transactions_sheet=transactions_sheet,
    )

    # M.2b.3 + M.2b.5 + M.2b.10 + M.2b.11 + M.2b.12 — Per-sheet
    # category filter dropdowns (account / role / transfer_type /
    # check_type / status / origin / rail_name / supersedes as
    # appropriate per sheet).
    _wire_per_sheet_dropdowns(
        analysis,
        datasets=datasets,
        drift_sheet=drift_sheet,
        drift_timelines_sheet=drift_timelines_sheet,
        overdraft_sheet=overdraft_sheet,
        limit_breach_sheet=limit_breach_sheet,
        pending_aging_sheet=pending_aging_sheet,
        unbundled_aging_sheet=unbundled_aging_sheet,
        supersession_audit_sheet=supersession_audit_sheet,
        todays_exceptions_sheet=todays_exceptions_sheet,
        transactions_sheet=transactions_sheet,
    )

    # M.2b.4 — Daily Statement per-account-day parameter filters.
    _wire_daily_statement_filters(
        analysis,
        datasets=datasets,
        daily_statement_sheet=daily_statement_sheet,
    )

    # M.2b.7 — Cross-sheet drill filter groups (sentinel-pattern).
    _wire_drill_filter_groups(
        analysis,
        datasets=datasets,
        sheets={
            SHEET_DRIFT: drift_sheet,
            SHEET_OVERDRAFT: overdraft_sheet,
            SHEET_LIMIT_BREACH: limit_breach_sheet,
            SHEET_TRANSACTIONS: transactions_sheet,
        },
    )

    app.create_dashboard(
        dashboard_id_suffix="l1-dashboard",
        name=_analysis_name(cfg, l2_instance),
    )
    return app


# ---------------------------------------------------------------------------
# CLI / external-caller shims. The CLI imports these directly and writes
# the emit_analysis() / emit_dashboard() output to JSON files, mirroring
# the AR / PR / Investigation / Executives shape.
# ---------------------------------------------------------------------------


def build_analysis(
    cfg: Config,
    *,
    l2_instance: L2Instance | None = None,
):
    """Build the complete L1 Dashboard Analysis resource via the tree.

    Forwards ``l2_instance`` to ``build_l1_dashboard_app``; default
    behaviour (unset) auto-loads the canonical Sasquatch AR L2 fixture.
    Return type is the AWS-shape Analysis dataclass from common.models.
    """
    return build_l1_dashboard_app(cfg, l2_instance=l2_instance).emit_analysis()


def build_l1_dashboard_dashboard(
    cfg: Config,
    *,
    l2_instance: L2Instance | None = None,
):
    """Build the L1 Dashboard Dashboard resource via the tree."""
    return build_l1_dashboard_app(
        cfg, l2_instance=l2_instance,
    ).emit_dashboard()
