"""Custom-SQL datasets for the Executives app (L.6.3).

Two datasets, both reading the shared base tables:

- ``exec_transaction_summary`` — one row per ``(posted_date,
  transfer_type)`` aggregated from ``transactions``. Drives the
  Transaction Volume Over Time + Money Moved sheets.
- ``exec_account_summary`` — one row per ``account_id`` joined
  against an activity rollup over ``transactions``. Drives the
  Account Coverage sheet.

**Aggregation choices.** Both queries aggregate per ``transfer_id``
first, then roll up to (date, type). Aggregating at the leg grain
would double-count multi-leg transfers — e.g. a $100 ACH transfer
posts as a +$100 + a -$100 leg, both with ``amount=100``; raw
``SUM(amount)`` gives $200 of "money moved" when only $100 actually
moved. The per-transfer pre-aggregation collapses each transfer to
one row (``MAX(amount)`` since both legs share the magnitude;
``SUM(signed_amount)`` for the net flow which is 0 for balanced
multi-leg, non-zero for single-leg or unbalanced).

**Status filter.** Both datasets filter to ``status = 'Posted'`` —
the canonical settled-leg status across the v6 schema (matching the
L1 invariant matviews + Investigation datasets). Pending / Failed
legs are excluded; including them would inflate the executive trends
with operational noise.
"""

from __future__ import annotations

from quicksight_gen.common.config import Config
from quicksight_gen.common.dataset_contract import (
    ColumnShape,
    ColumnSpec,
    DatasetContract,
    build_dataset,
    register_contract,
)
from quicksight_gen.common.models import DataSet
from quicksight_gen.common.sheets.app_info import (
    build_liveness_dataset,
    build_matview_status_dataset,
)
from quicksight_gen.common.sql import to_date


# M.4.4.5 — Executives reads base tables only; no app-specific
# matviews. V.3 — but we still surface the base tables themselves on
# the App Info sheet so the operator can see ETL freshness at a
# glance. Sourced from cfg.l2_instance_prefix (always set when the
# Executives app is built via resolve_l2_for_demo); empty list when
# the prefix is None (legacy single-tenant mode that doesn't use
# this app).
def exec_matview_specs(cfg: Config) -> list[tuple[str, str | None]]:
    """Tables Executives reads, paired with their date columns for
    App Info's ``latest_date`` KPI. No app-specific matviews — just
    the base tables (which is what the Executives sheets aggregate
    over)."""
    p = cfg.l2_instance_prefix
    if not p:
        return []
    return [
        (f"{p}_transactions", "posting"),
        (f"{p}_daily_balances", "business_day_start"),
    ]


# Identifier strings used as the DataSetIdentifier in visuals + filters.
DS_EXEC_TRANSACTION_SUMMARY = "exec-transaction-summary-ds"
DS_EXEC_ACCOUNT_SUMMARY = "exec-account-summary-ds"


# ---------------------------------------------------------------------------
# Contracts
# ---------------------------------------------------------------------------

EXEC_TRANSACTION_SUMMARY_CONTRACT = DatasetContract(columns=[
    ColumnSpec("posted_date", "DATETIME"),
    ColumnSpec("transfer_type", "STRING", shape=ColumnShape.TRANSFER_TYPE),
    ColumnSpec("transfer_count", "INTEGER"),
    ColumnSpec("gross_amount", "DECIMAL"),
    ColumnSpec("net_amount", "DECIMAL"),
])


EXEC_ACCOUNT_SUMMARY_CONTRACT = DatasetContract(columns=[
    ColumnSpec("account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("account_name", "STRING"),
    ColumnSpec("account_type", "STRING"),
    ColumnSpec("last_activity_date", "DATETIME"),
    ColumnSpec("activity_count", "INTEGER"),
])


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------

def _require_prefix(cfg: Config) -> str:
    """Return ``cfg.l2_instance_prefix`` or raise.

    Executives under L2-fed (N.4) requires ``build_executives_app`` to
    have set ``cfg.l2_instance_prefix`` before any dataset SQL is
    rendered. Build entry points either pre-stamp the field on the cfg
    or auto-derive it from ``l2_instance.instance``.
    """
    if cfg.l2_instance_prefix is None:
        raise ValueError(
            "Executives datasets require cfg.l2_instance_prefix to be "
            "set; build_executives_app derives it from the L2 instance."
        )
    return cfg.l2_instance_prefix


def build_transaction_summary_dataset(cfg: Config) -> DataSet:
    """Per-(date, transfer_type) aggregates: transfer count, gross + net dollars.

    Aggregates per ``transfer_id`` first so multi-leg transfers are
    counted once, not once per leg. ``gross_amount`` is the per-transfer
    handle; ``net_amount`` is the per-transfer net flow (0 for balanced
    multi-leg, non-zero for single-leg or unbalanced transfers).

    N.4.a: reads from ``<prefix>_transactions`` (per-instance prefixed
    base table). v6 column rename: posted_at → posting; amount →
    ``ABS(amount_money)`` (the per-leg signed Decimal — magnitude is
    abs); signed_amount → amount_money (already signed in v6).
    """
    p = _require_prefix(cfg)
    posted_date_expr = to_date("MIN(t.posting)", cfg.dialect)
    sql = f"""\
WITH per_transfer AS (
    SELECT
        {posted_date_expr}     AS posted_date,
        t.transfer_id,
        t.transfer_type,
        MAX(ABS(t.amount_money)) AS transfer_amount,
        SUM(t.amount_money)      AS transfer_net
    FROM {p}_transactions t
    WHERE t.status = 'Posted'
    GROUP BY t.transfer_id, t.transfer_type
)
SELECT
    posted_date,
    transfer_type,
    COUNT(*)                   AS transfer_count,
    SUM(transfer_amount)       AS gross_amount,
    SUM(transfer_net)          AS net_amount
FROM per_transfer
GROUP BY posted_date, transfer_type"""
    return build_dataset(
        cfg,
        cfg.prefixed("exec-transaction-summary-dataset"),
        "Executives Transaction Summary",
        "exec-transaction-summary",
        sql,
        EXEC_TRANSACTION_SUMMARY_CONTRACT,
        visual_identifier=DS_EXEC_TRANSACTION_SUMMARY,
    )


def build_account_summary_dataset(cfg: Config) -> DataSet:
    """One row per account that has ever appeared in ``daily_balances``.

    LEFT JOINs an activity rollup so accounts with zero activity in
    the dataset (just opened, never moved money) still show up with
    ``last_activity_date = NULL``, ``activity_count = 0``. The
    Account Coverage sheet's "active accounts" KPI applies a visual-
    scoped filter on ``activity_count > 0`` to narrow the count.

    N.4.a: reads from ``<prefix>_transactions`` + ``<prefix>_daily_balances``.
    v6 column rename: posted_at → posting; account_type → account_role
    (output column kept as ``account_type`` so dashboard-side consumers
    don't need to follow the rename — only the SELECT does).
    """
    p = _require_prefix(cfg)
    last_activity_expr = to_date("t.posting", cfg.dialect)
    sql = f"""\
WITH activity AS (
    SELECT
        t.account_id,
        MAX({last_activity_expr})    AS last_activity_date,
        COUNT(*)                AS activity_count
    FROM {p}_transactions t
    WHERE t.status = 'Posted'
    GROUP BY t.account_id
),
accounts AS (
    SELECT DISTINCT
        d.account_id,
        d.account_name,
        d.account_role          AS account_type
    FROM {p}_daily_balances d
)
SELECT
    a.account_id,
    a.account_name,
    a.account_type,
    act.last_activity_date,
    COALESCE(act.activity_count, 0)  AS activity_count
FROM accounts a
LEFT JOIN activity act ON act.account_id = a.account_id"""
    return build_dataset(
        cfg,
        cfg.prefixed("exec-account-summary-dataset"),
        "Executives Account Summary",
        "exec-account-summary",
        sql,
        EXEC_ACCOUNT_SUMMARY_CONTRACT,
        visual_identifier=DS_EXEC_ACCOUNT_SUMMARY,
    )


def build_all_datasets(cfg: Config) -> list[DataSet]:
    """Return every dataset used by the Executives app."""
    return [
        build_transaction_summary_dataset(cfg),
        build_account_summary_dataset(cfg),
        # M.4.4.5 — App Info ("i") sheet datasets, ALWAYS LAST.
        # M.4.4.7 — per-app segment so deploy <single-app> doesn't
        # delete-then-create another app's App Info dataset.
        build_liveness_dataset(cfg, app_segment="exec"),
        build_matview_status_dataset(
            cfg, app_segment="exec", view_specs=exec_matview_specs(cfg),
        ),
    ]


# Register contracts at module import so the L.1.17 emit-time validator
# can resolve every ds["col"] ref in the visuals below. ``build_dataset()``
# re-registers each contract too — idempotent for the same
# (visual_identifier, contract) pair.
_CONTRACT_REGISTRATIONS: tuple[tuple[str, DatasetContract], ...] = (
    (DS_EXEC_TRANSACTION_SUMMARY, EXEC_TRANSACTION_SUMMARY_CONTRACT),
    (DS_EXEC_ACCOUNT_SUMMARY, EXEC_ACCOUNT_SUMMARY_CONTRACT),
)
for _vid, _contract in _CONTRACT_REGISTRATIONS:
    register_contract(_vid, _contract)
