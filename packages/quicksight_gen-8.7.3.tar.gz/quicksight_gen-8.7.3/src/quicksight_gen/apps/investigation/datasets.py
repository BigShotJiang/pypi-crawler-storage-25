"""Custom-SQL datasets for the Investigation app.

K.4.3 ships the recipient-fanout dataset. K.4.4 adds the rolling-window
anomaly dataset (read from the ``inv_pair_rolling_anomalies`` matview).
K.4.5 adds the money-trail dataset (read from the
``inv_money_trail_edges`` matview, which precomputes the
``WITH RECURSIVE`` walk over ``parent_transfer_id``). K.4.8 wraps the
same matview as a second dataset so the account-centric filters
(anchor account, min amount) don't cross-contaminate K.4.5's
chain-rooted filters.

All datasets read the shared `transactions` + `daily_balances` base
tables — Investigation has no app-specific schema. The K.4.4 + K.4.5
matviews are computed at refresh time, not dataset time, because the
rolling-window z-score and the recursive chain walk were both too heavy
for QuickSight Direct Query at realistic transaction volumes.
"""

from __future__ import annotations

from quicksight_gen.apps.investigation.constants import (
    DS_INV_ACCOUNT_NETWORK,
    DS_INV_ANETWORK_ACCOUNTS,
    DS_INV_MONEY_TRAIL,
    DS_INV_RECIPIENT_FANOUT,
    DS_INV_VOLUME_ANOMALIES,
)
from quicksight_gen.common.config import Config
from quicksight_gen.common.dataset_contract import (
    ColumnShape,
    ColumnSpec,
    DatasetContract,
    build_dataset,
    register_contract,
)
from quicksight_gen.common.models import DataSet
from quicksight_gen.common.sheets.app_info import (
    build_liveness_dataset,
    build_matview_status_dataset,
)


# M.4.4.5 — matviews the Investigation app reads, surfaced on the
# App Info ("i") sheet's matview-status table. V.3 — paired with the
# date column the App Info ``latest_date`` KPI takes its MAX from.
# `inv_pair_rolling_anomalies` carries `window_end` in its outer
# projection (the most recent day the rolling 2-day window covers —
# semantically the "freshest day this matview is current through").
# Note: `posted_day` lives in an inner CTE but is not projected.
# `inv_money_trail_edges` is a recursive-CTE walk over edge metadata
# with no natural date dimension (each row is a hop, not a posting),
# so it gets None.
_INV_MATVIEW_BARE_SPECS: list[tuple[str, str | None]] = [
    ("inv_pair_rolling_anomalies", "window_end"),
    ("inv_money_trail_edges", None),
]


def inv_matview_specs(
    l2_instance: L2Instance,
) -> list[tuple[str, str | None]]:
    """The L2-prefixed Inv matviews + base tables the dashboard reads,
    paired with the date column for App Info's ``latest_date`` KPI.

    Includes the base tables (transactions / daily_balances) so the
    operator can spot stale matviews against fresh ETL loads at a
    glance. Mirrors ``l1_matview_specs`` / ``l2ft_matview_specs``.
    """
    p = str(l2_instance.instance)
    return [
        (f"{p}_transactions", "posting"),
        (f"{p}_daily_balances", "business_day_start"),
        *((f"{p}_{name}", date_col) for name, date_col in _INV_MATVIEW_BARE_SPECS),
    ]


# ---------------------------------------------------------------------------
# Contracts
# ---------------------------------------------------------------------------

# One row per (recipient leg, sender leg) pair sharing a transfer_id.
# Visuals aggregate to one row per recipient via COUNT_DISTINCT(sender_id)
# + SUM(amount), so the dataset stays at the legs grain to support both
# the fanout count and the per-row drill into AR Transactions in K.4.7.
RECIPIENT_FANOUT_CONTRACT = DatasetContract(columns=[
    ColumnSpec("recipient_account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("recipient_account_name", "STRING"),
    ColumnSpec("recipient_account_type", "STRING"),
    ColumnSpec("sender_account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("sender_account_name", "STRING"),
    ColumnSpec("sender_account_type", "STRING"),
    ColumnSpec("transfer_id", "STRING", shape=ColumnShape.TRANSFER_ID),
    ColumnSpec("posted_at", "DATETIME"),
    ColumnSpec("amount", "DECIMAL"),
])


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------

# One row per (sender, recipient, posted_day) with that day's rolling
# 2-day SUM, transfer count, and z-score against the population of all
# pair-windows. Computed by the ``inv_pair_rolling_anomalies`` matview;
# see ``schema.sql`` for the windowing CTE.
VOLUME_ANOMALIES_CONTRACT = DatasetContract(columns=[
    ColumnSpec("recipient_account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("recipient_account_name", "STRING"),
    ColumnSpec("recipient_account_type", "STRING"),
    ColumnSpec("sender_account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("sender_account_name", "STRING"),
    ColumnSpec("sender_account_type", "STRING"),
    ColumnSpec("window_start", "DATETIME"),
    ColumnSpec("window_end", "DATETIME"),
    ColumnSpec("window_sum", "DECIMAL"),
    ColumnSpec("transfer_count", "INTEGER"),
    ColumnSpec("pop_mean", "DECIMAL"),
    ColumnSpec("pop_stddev", "DECIMAL"),
    ColumnSpec("z_score", "DECIMAL"),
    ColumnSpec("z_bucket", "STRING"),
])


# One row per (chain root, transfer, source-leg × target-leg) edge in the
# precomputed money-trail matview. ``root_transfer_id`` is the chain's
# top-most transfer (no parent); ``transfer_id`` is the transfer this
# edge belongs to; ``depth`` is the hop's distance from the root (0 =
# root). Edges include only multi-leg transfers — single-leg sales /
# external arrivals appear as chain members in the recursive walk but
# don't surface as visible edges. See ``schema.sql`` for the recursive
# CTE shape and the multi-leg-only rationale.
MONEY_TRAIL_CONTRACT = DatasetContract(columns=[
    ColumnSpec("root_transfer_id", "STRING", shape=ColumnShape.TRANSFER_ID),
    ColumnSpec("transfer_id", "STRING", shape=ColumnShape.TRANSFER_ID),
    ColumnSpec("depth", "INTEGER"),
    ColumnSpec("source_account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("source_account_name", "STRING"),
    ColumnSpec("source_account_type", "STRING"),
    ColumnSpec("target_account_id", "STRING", shape=ColumnShape.ACCOUNT_ID),
    ColumnSpec("target_account_name", "STRING"),
    ColumnSpec("target_account_type", "STRING"),
    ColumnSpec("hop_amount", "DECIMAL"),
    ColumnSpec("posted_at", "DATETIME"),
    ColumnSpec("transfer_type", "STRING"),
    # Concatenated display labels, computed in the dataset SQL (see
    # ``_money_trail_base_sql``). Used by the Account Network sheet as the
    # walk-the-flow anchor — they're both human-readable AND uniquely
    # keyed (embedded account_id disambiguates name collisions). Money
    # Trail doesn't read these but they project cleanly through its
    # own dataset wrapper and stay zero-cost at query time.
    ColumnSpec("source_display", "STRING", shape=ColumnShape.ACCOUNT_DISPLAY),
    ColumnSpec("target_display", "STRING", shape=ColumnShape.ACCOUNT_DISPLAY),
])


# Both money-trail-shaped datasets project the same matview; the
# wrapper computes the display columns inline so the matview stays a
# pure shape over base tables. N.3.d: matview name is per-instance
# prefixed (was global ``inv_money_trail_edges`` pre-N.3).
def _money_trail_base_sql(prefix: str) -> str:
    # Oracle disallows ``SELECT *, expr FROM ...`` — the star must be
    # qualified when other columns appear in the same SELECT list. The
    # ``e.*`` qualified form parses on both Postgres and Oracle.
    return (
        f"SELECT\n"
        f"    e.*,\n"
        f"    source_account_name || ' (' || source_account_id || ')' "
        f"AS source_display,\n"
        f"    target_account_name || ' (' || target_account_id || ')' "
        f"AS target_display\n"
        f"FROM {prefix}_inv_money_trail_edges e\n"
    )


# K.4.8k — narrow dataset feeding only the anchor-account dropdown.
# Single column ``source_display`` (the same concatenated label the
# Account Network dataset uses) so the anchor parameter, the calc
# fields, and the dropdown population all speak the same string. The
# DISTINCT happens INSIDE the SELECT so PG dedupes the (id, name) pairs
# before computing the per-row concat — O(distinct accounts) instead
# of O(matview rows). At dataset-load time the planner gets one column
# of ~tens of values; the dropdown loads instantly.
ANETWORK_ACCOUNTS_CONTRACT = DatasetContract(columns=[
    ColumnSpec(
        "source_display", "STRING", shape=ColumnShape.ACCOUNT_DISPLAY,
    ),
])

def _anetwork_accounts_sql(prefix: str) -> str:
    return (
        f"SELECT DISTINCT\n"
        f"    source_account_name || ' (' || source_account_id || ')' "
        f"AS source_display\n"
        f"FROM {prefix}_inv_money_trail_edges\n"
    )


def _require_prefix(cfg: Config) -> str:
    """Return ``cfg.l2_instance_prefix`` or raise.

    Investigation under L2-fed (N.3) requires ``build_investigation_app``
    to have set ``cfg.l2_instance_prefix`` before any dataset SQL is
    rendered. Build entry points either pre-stamp the field on the cfg
    or auto-derive it from ``l2_instance.instance``.
    """
    if cfg.l2_instance_prefix is None:
        raise ValueError(
            "Investigation datasets require cfg.l2_instance_prefix to be "
            "set; build_investigation_app derives it from the L2 instance."
        )
    return cfg.l2_instance_prefix


def build_recipient_fanout_dataset(cfg: Config) -> DataSet:
    """Recipient × sender × transfer rows, one per (recipient leg, sender leg).

    Filters to leaf-internal recipients (``account_scope='internal'``
    AND ``account_parent_role IS NOT NULL`` — the v6 equivalent of the
    v5 ``account_type IN ('dda', 'merchant_dda')`` filter, mirroring
    the Inv matview convention) so administrative sweeps into control
    accounts don't dominate the fanout ranking. v5 column names kept
    in the output projection (``_account_type``) so downstream consumers
    aren't sensitive to the source-side rename.
    """
    p = _require_prefix(cfg)
    sql = f"""\
WITH inflows AS (
    SELECT
        t.transfer_id,
        t.account_id            AS recipient_account_id,
        t.account_name          AS recipient_account_name,
        t.account_role          AS recipient_account_type,
        t.amount_money          AS amount,
        t.posting               AS posted_at
    FROM {p}_transactions t
    WHERE t.amount_money > 0
      AND t.status = 'Posted'
      AND t.account_scope = 'internal'
      AND t.account_parent_role IS NOT NULL
),
outflows AS (
    SELECT
        t.transfer_id,
        t.account_id            AS sender_account_id,
        t.account_name          AS sender_account_name,
        t.account_role          AS sender_account_type
    FROM {p}_transactions t
    WHERE t.amount_money < 0
      AND t.status = 'Posted'
)
SELECT
    i.recipient_account_id,
    i.recipient_account_name,
    i.recipient_account_type,
    o.sender_account_id,
    o.sender_account_name,
    o.sender_account_type,
    i.transfer_id,
    i.posted_at,
    i.amount
FROM inflows i
JOIN outflows o ON o.transfer_id = i.transfer_id"""
    return build_dataset(
        cfg,
        cfg.prefixed("inv-recipient-fanout-dataset"),
        "Investigation Recipient Fanout",
        "inv-recipient-fanout",
        sql,
        RECIPIENT_FANOUT_CONTRACT,
        visual_identifier=DS_INV_RECIPIENT_FANOUT,
    )


def build_volume_anomalies_dataset(cfg: Config) -> DataSet:
    """Pair-grain rolling-window anomalies sourced from the matview.

    The dataset is a thin SELECT over ``inv_pair_rolling_anomalies`` —
    every column is computed at refresh time. Visuals filter via a
    NumericRangeFilter on ``z_score`` bound to the σ-threshold parameter.
    """
    p = _require_prefix(cfg)
    sql = f"SELECT * FROM {p}_inv_pair_rolling_anomalies"
    return build_dataset(
        cfg,
        cfg.prefixed("inv-volume-anomalies-dataset"),
        "Investigation Volume Anomalies",
        "inv-volume-anomalies",
        sql,
        VOLUME_ANOMALIES_CONTRACT,
        visual_identifier=DS_INV_VOLUME_ANOMALIES,
    )


def build_money_trail_dataset(cfg: Config) -> DataSet:
    """Per-edge money trail rows sourced from the recursive-CTE matview.

    The dataset is a thin SELECT over ``inv_money_trail_edges``; the
    recursive walk happens at refresh time. Visuals filter via:

    - ``CategoryFilter`` on ``root_transfer_id`` bound to
      ``pInvMoneyTrailRoot`` — narrows to a single chain.
    - ``NumericRangeFilter`` on ``depth`` bound to
      ``pInvMoneyTrailMaxHops`` — caps chain depth.
    - ``NumericRangeFilter`` on ``hop_amount`` bound to
      ``pInvMoneyTrailMinAmount`` — drops noise edges.
    """
    sql = _money_trail_base_sql(_require_prefix(cfg))
    return build_dataset(
        cfg,
        cfg.prefixed("inv-money-trail-dataset"),
        "Investigation Money Trail",
        "inv-money-trail",
        sql,
        MONEY_TRAIL_CONTRACT,
        visual_identifier=DS_INV_MONEY_TRAIL,
    )


def build_account_network_dataset(cfg: Config) -> DataSet:
    """Per-edge account-network rows — same matview as money trail.

    Reuses ``inv_money_trail_edges``; a second dataset registration so
    the account-centric calc field (``is_anchor_edge``) and filters
    (anchor account, min amount) live independently of the K.4.5
    chain-root filters. Contract is identical because the underlying
    rows are.
    """
    sql = _money_trail_base_sql(_require_prefix(cfg))
    return build_dataset(
        cfg,
        cfg.prefixed("inv-account-network-dataset"),
        "Investigation Account Network",
        "inv-account-network",
        sql,
        MONEY_TRAIL_CONTRACT,
        visual_identifier=DS_INV_ACCOUNT_NETWORK,
    )


def build_account_network_accounts_dataset(cfg: Config) -> DataSet:
    """Narrow accounts dataset feeding the K.4.8 anchor dropdown only.

    Single column ``source_display`` distinct'd over the matview so
    QuickSight's dropdown can ``SELECT DISTINCT source_display FROM ...``
    in O(distinct accounts) work instead of O(matview rows). Originally
    the dropdown pointed at the full Account Network dataset; that
    dataset wraps the matview with a per-row concat that the dropdown's
    DISTINCT couldn't push past, so the dropdown started timing out as
    the matview grew. This dataset puts the DISTINCT inside the SELECT
    so PG dedupes the (id, name) pairs before concatenating.

    Reuses ``inv_money_trail_edges`` — no new matview needed.
    """
    return build_dataset(
        cfg,
        cfg.prefixed("inv-anetwork-accounts-dataset"),
        "Investigation Account Network — Accounts",
        "inv-anetwork-accounts",
        _anetwork_accounts_sql(_require_prefix(cfg)),
        ANETWORK_ACCOUNTS_CONTRACT,
        visual_identifier=DS_INV_ANETWORK_ACCOUNTS,
    )


def build_all_datasets(
    cfg: Config, l2_instance: L2Instance,
) -> list[DataSet]:
    """Return every dataset Investigation's sheets reference.

    ``l2_instance`` is required for App Info matview names (which need
    the L2 prefix). Mirrors the L1 / L2FT / Exec ``build_all_datasets``
    signatures — every L2-fed app threads the instance explicitly.
    """
    return [
        build_recipient_fanout_dataset(cfg),
        build_volume_anomalies_dataset(cfg),
        build_money_trail_dataset(cfg),
        build_account_network_dataset(cfg),
        build_account_network_accounts_dataset(cfg),
        # M.4.4.5 — App Info ("i") sheet datasets, ALWAYS LAST.
        # M.4.4.7 — per-app segment so deploy <single-app> doesn't
        # delete-then-create another app's App Info dataset.
        build_liveness_dataset(cfg, app_segment="inv"),
        build_matview_status_dataset(
            cfg, app_segment="inv",
            view_specs=inv_matview_specs(l2_instance),
        ),
    ]


# Register contracts at module import so visuals built later resolve
# drill source-field shapes without depending on dataset construction
# order.
_CONTRACT_REGISTRATIONS: tuple[tuple[str, DatasetContract], ...] = (
    (DS_INV_RECIPIENT_FANOUT, RECIPIENT_FANOUT_CONTRACT),
    (DS_INV_VOLUME_ANOMALIES, VOLUME_ANOMALIES_CONTRACT),
    (DS_INV_MONEY_TRAIL, MONEY_TRAIL_CONTRACT),
    (DS_INV_ACCOUNT_NETWORK, MONEY_TRAIL_CONTRACT),
    (DS_INV_ANETWORK_ACCOUNTS, ANETWORK_ACCOUNTS_CONTRACT),
)
for _vid, _contract in _CONTRACT_REGISTRATIONS:
    register_contract(_vid, _contract)
