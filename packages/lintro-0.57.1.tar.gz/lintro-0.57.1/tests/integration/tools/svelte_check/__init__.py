"""Svelte-check integration tests."""
