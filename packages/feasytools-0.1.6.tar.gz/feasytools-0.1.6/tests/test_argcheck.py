from feasytools import ArgChecker

def test_argcheck():
    args = ArgChecker('''--sdji="-dsf -sdf" -d 123 -e " -d 'hello   world'" -sdfsdf -v "-asdb" -g "-ff 'wqsfd  asdf' -sdf " --musd=-sdfi''',['g'])
    assert args.pop_int('d') == 123, "Expected integer value for argument 'd'."
    assert args.pop_str('e') == " -d 'hello   world'", "Expected string value for argument 'e'."
    assert args.pop_str('g') == "-ff 'wqsfd  asdf' -sdf ", "Expected string value for argument 'g'."
    assert args.pop_bool('asdb') == True
    assert args.pop_bool('sdfsdf') == True
    assert args.pop_str('musd') == '-sdfi', "Expected string value for argument 'musd'."
    assert args.pop_str('sdji') == '-dsf -sdf', "Expected string value for argument 'sdji'."

    eh_flag = False
    def eh(x:Exception):
        nonlocal eh_flag
        eh_flag = True
    ArgChecker.ErrorHandler = eh

    try:
        args.pop_int('f')
    except:
        pass
    assert eh_flag, "Expected error handler to be called for missing argument 'f'."


    args = ArgChecker('''--sdji="-dsf -sdf" --de 123 --ee " -d 'hello   world'" -sdf -V "-ab" --ge "-ff 'wqsfd  asdf' --sdf " --musd=-sdfi''', force_parametric=['ge'], strict=True)
    print(args.to_dict())
    assert args.pop_str('sdji') == '-dsf -sdf', "Expected string value for argument 'sdji'."
    assert args.pop_int('de') == 123, "Expected integer value for argument 'de'."
    assert args.pop_str('ee') == " -d 'hello   world'", "Expected string value for argument 'ee'."
    assert args.pop_bool('s') == True
    assert args.pop_bool('d') == True
    assert args.pop_bool('a') == True
    assert args.pop_bool('b') == True
    assert args.pop_bool('f') == True
    assert args.pop_bool('V') == True
    assert args.pop_bool('v') == False
    assert args.pop_str('musd') == '-sdfi', "Expected string value for argument 'musd'."
    assert args.pop_str('ge') == "-ff 'wqsfd  asdf' --sdf ", "Expected string value for argument 'ge'."