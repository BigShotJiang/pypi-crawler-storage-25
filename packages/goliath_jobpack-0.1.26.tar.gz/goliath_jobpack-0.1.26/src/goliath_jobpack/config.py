from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


class BuildConfig(BaseModel):
    include: list[str] = Field(default_factory=lambda: ["handler.py"])
    requirements: str = "requirements.txt"


class JobConfig(BaseModel):
    name: str
    version: str = "0.1.0"
    runtime: str = "python3.11"
    entrypoint: str = "handler:main"
    timeout_seconds: int = 300
    build: BuildConfig = Field(default_factory=BuildConfig)

    @field_validator("runtime")
    @classmethod
    def validate_runtime(cls, value: str) -> str:
        allowed = {"python3.11", "python3.12"}
        if value not in allowed:
            raise ValueError(f"Unsupported runtime '{value}'. Allowed: {sorted(allowed)}")
        return value

    @field_validator("entrypoint")
    @classmethod
    def validate_entrypoint(cls, value: str) -> str:
        if ":" not in value:
            raise ValueError("Entrypoint must look like module:function, e.g. handler:main")
        return value


def load_job_config(project_dir: Path) -> JobConfig:
    config_path = project_dir / "job.toml"
    if not config_path.exists():
        raise FileNotFoundError(f"Missing job.toml in {project_dir}")

    data: dict[str, Any]
    with config_path.open("rb") as f:
        data = tomllib.load(f)

    return JobConfig(**data)