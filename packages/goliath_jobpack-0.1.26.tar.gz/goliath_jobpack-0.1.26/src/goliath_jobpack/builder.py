from __future__ import annotations

import ast
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import JobConfig, load_job_config
from .utils import sha256_file, utc_now_iso, write_json


# Top-level packages that map to a different PyPI name
_IMPORT_TO_PYPI: dict[str, str] = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "yaml": "PyYAML",
    "bs4": "beautifulsoup4",
    "dateutil": "python-dateutil",
    "dotenv": "python-dotenv",
    "attr": "attrs",
    "gi": "PyGObject",
    "serial": "pyserial",
    "usb": "pyusb",
    "wx": "wxPython",
}


@dataclass
class BuildResult:
    zip_path: Path
    manifest_path: Path
    manifest: dict[str, Any] = field(default_factory=dict)


def _scan_imports(project_dir: Path, config: JobConfig) -> set[str]:
    """Scan all included .py files and return top-level import names."""
    imports: set[str] = set()
    for relative in config.build.include:
        src = project_dir / relative
        if src.is_file() and src.suffix == ".py":
            _extract_imports_from_file(src, imports)
        elif src.is_dir():
            for py_file in src.rglob("*.py"):
                _extract_imports_from_file(py_file, imports)
    return imports


def _extract_imports_from_file(path: Path, imports: set[str]) -> None:
    """Parse a Python file's AST and collect top-level import names."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError:
        return
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:
                imports.add(node.module.split(".")[0])


def _get_stdlib_modules() -> set[str]:
    """Return the set of standard library top-level module names."""
    if sys.version_info >= (3, 10):
        import sys as _sys
        return set(_sys.stdlib_module_names)
    # Fallback for older Python
    import pkgutil
    return {m.name for m in pkgutil.iter_modules() if m.module_finder is None} | {
        "os", "sys", "io", "re", "json", "math", "time", "datetime", "pathlib",
        "collections", "itertools", "functools", "typing", "logging", "unittest",
        "subprocess", "shutil", "tempfile", "hashlib", "hmac", "secrets",
        "socket", "http", "urllib", "email", "html", "xml", "csv", "sqlite3",
        "threading", "multiprocessing", "asyncio", "concurrent", "ctypes",
        "struct", "codecs", "abc", "contextlib", "dataclasses", "enum",
        "copy", "pprint", "textwrap", "string", "operator", "decimal",
        "fractions", "random", "statistics", "uuid", "base64", "binascii",
        "pickle", "shelve", "glob", "fnmatch", "argparse", "configparser",
        "traceback", "warnings", "inspect", "dis", "ast", "token", "tokenize",
        "importlib", "zipfile", "tarfile", "gzip", "bz2", "lzma", "zlib",
        "signal", "platform", "errno", "webbrowser", "getpass", "os",
        "__future__", "builtins", "_thread",
    }


def _parse_requirements(req_path: Path) -> set[str]:
    """Parse requirements.txt and return normalized package names."""
    if not req_path.exists():
        return set()
    packages: set[str] = set()
    for line in req_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        # Strip version specifiers: requests>=2.0 -> requests
        for sep in (">=", "<=", "==", "!=", "~=", ">", "<", "[", ";"):
            line = line.split(sep)[0]
        packages.add(line.strip().lower())
    return packages


def _get_local_modules(project_dir: Path, config: JobConfig) -> set[str]:
    """Return module names from included files (these aren't external deps)."""
    local: set[str] = set()
    for relative in config.build.include:
        src = project_dir / relative
        if src.is_file() and src.suffix == ".py":
            local.add(src.stem)
        elif src.is_dir():
            local.add(src.name)
    return local


def check_missing_dependencies(project_dir: Path, config: JobConfig) -> list[str]:
    """Return list of import names not covered by stdlib, local files, or requirements.txt."""
    imports = _scan_imports(project_dir, config)
    stdlib = _get_stdlib_modules()
    local = _get_local_modules(project_dir, config)
    req_path = project_dir / config.build.requirements
    declared = _parse_requirements(req_path)

    missing = []
    for name in sorted(imports):
        if name in stdlib or name in local:
            continue
        # Check if the import (or its PyPI alias) is in requirements
        pypi_name = _IMPORT_TO_PYPI.get(name, name).lower()
        if name.lower() in declared or pypi_name in declared:
            continue
        missing.append(name)

    return missing


def get_pypi_name(import_name: str) -> str:
    """Map an import name to its likely PyPI package name."""
    return _IMPORT_TO_PYPI.get(import_name, import_name)


def _copy_included_files(project_dir: Path, build_dir: Path, config: JobConfig) -> None:
    for relative in config.build.include:
        src = project_dir / relative
        if not src.exists():
            raise FileNotFoundError(f"Included file not found: {src}")

        dest = build_dir / relative
        dest.parent.mkdir(parents=True, exist_ok=True)

        if src.is_dir():
            shutil.copytree(src, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dest)


def _install_requirements(project_dir: Path, build_dir: Path, config: JobConfig) -> None:
    req_path = project_dir / config.build.requirements
    if not req_path.exists():
        return

    # Skip if requirements.txt is empty
    content = req_path.read_text(encoding="utf-8").strip()
    if not content or all(l.startswith("#") for l in content.splitlines() if l.strip()):
        return

    # Extract Python version from runtime (e.g. "python3.11" -> "3.11")
    python_version = config.runtime.replace("python", "")

    # Always target Linux x86_64 since the worker runs on Linux.
    # pip supports --platform for cross-platform installs.
    # uv doesn't support --platform on `pip install`, so we use
    # `uv pip compile` to resolve, then `uv pip install` from the lockfile.
    platform = "manylinux2014_x86_64"

    uv = shutil.which("uv")
    if uv:
        # Step 1: resolve deps for Linux using uv pip compile
        lock_path = build_dir / "_resolved.txt"
        compile_cmd = [
            uv, "pip", "compile",
            str(req_path),
            "--output-file", str(lock_path),
            "--python-platform", "linux",
            "--python-version", python_version,
            "--only-binary", ":all:",
        ]
        result = subprocess.run(compile_cmd, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"dependency resolve failed (exit {result.returncode})")

        # Step 2: install the resolved deps into the build dir (targeting Linux)
        # --only-binary :all: prevents building from source (e.g. numpy on Windows)
        install_cmd = [
            uv, "pip", "install",
            "-r", str(lock_path),
            "--target", str(build_dir),
            "--python-platform", "linux",
            "--python-version", python_version,
            "--only-binary", ":all:",
        ]
        result = subprocess.run(install_cmd, text=True)
        lock_path.unlink(missing_ok=True)
    else:
        cmd = [
            sys.executable, "-m", "pip", "install",
            "-r", str(req_path),
            "-t", str(build_dir),
            "--platform", platform,
            "--python-version", python_version,
            "--only-binary=:all:",
        ]
        result = subprocess.run(cmd, text=True)

    if result.returncode != 0:
        raise RuntimeError(f"dependency install failed (exit {result.returncode})")


def validate_project(project_dir: Path) -> JobConfig:
    if not project_dir.exists():
        raise FileNotFoundError(f"Project directory not found: {project_dir}")

    config = load_job_config(project_dir)

    module_name, function_name = config.entrypoint.split(":", 1)
    expected_file = project_dir / f"{module_name}.py"
    if not expected_file.exists():
        raise FileNotFoundError(
            f"Entrypoint module file not found: {expected_file} "
            f"(from entrypoint '{config.entrypoint}')"
        )

    req = project_dir / config.build.requirements
    if req.exists() and not req.is_file():
        raise ValueError(f"Requirements path is not a file: {req}")

    return config


def build_project(project_dir: Path, dist_dir: Path | None = None) -> BuildResult:
    project_dir = project_dir.resolve()
    config = validate_project(project_dir)

    if dist_dir is None:
        dist_dir = project_dir / "dist"
    dist_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="goliath_jobpack_build_") as tmp:
        build_dir = Path(tmp) / "package"
        build_dir.mkdir(parents=True, exist_ok=True)

        _copy_included_files(project_dir, build_dir, config)
        _install_requirements(project_dir, build_dir, config)

        zip_base = dist_dir / config.name
        zip_path = Path(shutil.make_archive(str(zip_base), "zip", root_dir=build_dir))

        manifest = {
            "name": config.name,
            "runtime": config.runtime,
            "entrypoint": config.entrypoint,
            "timeout_seconds": config.timeout_seconds,
            "built_at_utc": utc_now_iso(),
            "zip_filename": zip_path.name,
            "zip_sha256": sha256_file(zip_path),
        }

        manifest_path = dist_dir / f"{config.name}.manifest.json"
        write_json(manifest_path, manifest)

        return BuildResult(
            zip_path=zip_path,
            manifest_path=manifest_path,
            manifest=manifest,
        )