from __future__ import annotations

import json
import random
import shutil
from pathlib import Path

import click

from .builder import build_project, check_missing_dependencies, get_pypi_name, validate_project
from .uploader import upload_file_to_s3


TEMPLATES_DIR = Path(__file__).parent / "templates"

BUILD_SAYINGS = [
    "You're about to change the world, one package at a time.",
    "The world isn't ready for what you're about to deploy.",
    "Great software starts with a single upload. This is yours.",
    "Your code is packed and ready to make an impact.",
    "Today's build, tomorrow's revolution.",
    "Ship it and let the world catch up.",
]

INIT_SAYINGS = [
    "Your job is ready to cause trouble.",
    "Another one fresh off the assembly line.",
    "Job scaffolded. No refunds.",
    "Congratulations, it's a job!",
    "Built different. Literally, we just built it.",
    "Your job has entered the chat.",
    "Ship it. Or don't. We're not your boss.",
    "Job created. May the cloud be ever in your favor.",
    "That's one small step for a dev, one giant leap for this job.",
    "New job, who dis?",
    "Freshly baked and ready to deploy.",
    "Your job package has achieved sentience. Just kidding. Maybe.",
    "Init complete. Time to mass produce.",
]


def _copy_template(src_name: str, dest_path: Path) -> None:
    src = TEMPLATES_DIR / src_name
    shutil.copy2(src, dest_path)


def _set_toml_field(toml_path: Path, field: str, value: str) -> None:
    import re
    text = toml_path.read_text(encoding="utf-8")
    text = re.sub(rf'^{field}\s*=\s*"[^"]*"', f'{field} = "{value}"', text, count=1, flags=re.MULTILINE)
    toml_path.write_text(text, encoding="utf-8")


@click.group()
def cli() -> None:
    """Build and upload Python job packages for Goliath."""
    pass


@cli.command()
@click.argument("project_dir", type=click.Path(path_type=Path), default=".")
def init(project_dir: Path) -> None:
    """Create a starter job project."""
    project_dir.mkdir(parents=True, exist_ok=True)

    job_toml = project_dir / "job.toml"
    handler_py = project_dir / "handler.py"
    requirements_txt = project_dir / "requirements.txt"

    main_py = project_dir / "main.py"
    if main_py.exists():
        if click.confirm(f"A main.py already exists in {project_dir}. Remove it?"):
            main_py.unlink()
            click.echo("Removed main.py")
        else:
            click.echo("Skipping init.")
            return

    if not job_toml.exists():
        _copy_template("job.toml", job_toml)
        project_name = project_dir.resolve().name
        _set_toml_field(job_toml, "name", project_name)

    if not handler_py.exists():
        _copy_template("handler.py", handler_py)

    if not requirements_txt.exists():
        requirements_txt.write_text("", encoding="utf-8")

    click.secho(random.choice(INIT_SAYINGS), fg="green", bold=True)


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def clean(project_dir: Path) -> None:
    """Remove all files created by init and build."""
    targets = [
        project_dir / "job.toml",
        project_dir / "handler.py",
        project_dir / "requirements.txt",
        project_dir / "dist",
    ]
    removed = []
    for target in targets:
        if target.is_dir():
            shutil.rmtree(target)
            removed.append(str(target))
        elif target.is_file():
            target.unlink()
            removed.append(str(target))

    if removed:
        for r in removed:
            click.echo(f"Removed: {r}")
    else:
        click.echo("Nothing to clean.")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def validate(project_dir: Path) -> None:
    """Validate a job project."""
    validate_project(project_dir)
    click.secho("✔ Package is valid.", fg="green", bold=True)


@cli.command()
@click.argument("name")
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def rename(name: str, project_dir: Path) -> None:
    """Change the job name in job.toml."""
    toml_path = project_dir / "job.toml"
    if not toml_path.exists():
        raise click.ClickException(f"No job.toml found in {project_dir}")
    _set_toml_field(toml_path, "name", name)
    click.echo(f"Renamed job to: {name}")


def _bump_version(project_dir: Path, level: str) -> None:
    from .config import load_job_config

    config = load_job_config(project_dir)
    major, minor, patch = (int(x) for x in config.version.split("."))

    if level == "major":
        major, minor, patch = major + 1, 0, 0
    elif level == "minor":
        major, minor, patch = major, minor + 1, 0
    else:
        patch += 1

    new_version = f"{major}.{minor}.{patch}"
    toml_path = project_dir / "job.toml"
    _set_toml_field(toml_path, "version", new_version)
    click.secho(f"{config.version} → {new_version}", fg="green", bold=True)


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def bump(project_dir: Path) -> None:
    """Bump the patch version in job.toml."""
    _bump_version(project_dir, "patch")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def patch(project_dir: Path) -> None:
    """Bump the patch version in job.toml (same as bump)."""
    _bump_version(project_dir, "patch")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def minor(project_dir: Path) -> None:
    """Bump the minor version in job.toml (resets patch to 0)."""
    _bump_version(project_dir, "minor")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def major(project_dir: Path) -> None:
    """Bump the major version in job.toml (resets minor and patch to 0)."""
    _bump_version(project_dir, "major")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
@click.option("--dist-dir", type=click.Path(path_type=Path), default=None)
def build(project_dir: Path, dist_dir: Path | None) -> None:
    """Build a zip package."""
    from .config import load_job_config

    config = load_job_config(project_dir)
    missing = check_missing_dependencies(project_dir, config)

    if missing:
        req_path = project_dir / config.build.requirements
        pypi_names = [get_pypi_name(m) for m in missing]

        click.secho("\nMissing dependencies detected:", fg="yellow", bold=True)
        for imp, pypi in zip(missing, pypi_names):
            label = f"  - {imp}" if imp == pypi else f"  - {imp} ({pypi})"
            click.echo(label)

        click.echo()
        if click.confirm("Add these to requirements.txt?"):
            with req_path.open("a", encoding="utf-8") as f:
                for pypi in pypi_names:
                    f.write(f"{pypi}\n")
            click.secho(f"Updated {req_path}", fg="green")
        else:
            raise click.ClickException(
                f"Build aborted. Add missing dependencies to {req_path} and try again."
            )

    result = build_project(project_dir, dist_dir=dist_dir)
    click.echo(f"Built zip: {result.zip_path}")
    click.echo(f"Manifest:  {result.manifest_path}")
    click.secho(random.choice(BUILD_SAYINGS), fg="green", bold=True)
    click.echo("\nRun 'goliath deploy' to deploy your package.")



@cli.command()
@click.option("--region", default=None)
def deploy(region: str | None) -> None:
    """Build and upload with an interactive wizard."""
    from .config import load_job_config as _load_config

    project_dir = Path(".")
    config = _load_config(project_dir)
    zip_path = project_dir / "dist" / f"{config.name}.zip"

    if not zip_path.exists():
        raise click.ClickException(f"No build found at {zip_path}. Run 'goliath build' first.")

    click.echo(f"Using zip: {zip_path}")

    deploy_config_path = project_dir / ".goliath-deploy.json"
    saved = {}
    if deploy_config_path.exists():
        saved = json.loads(deploy_config_path.read_text(encoding="utf-8"))

    deployment_name = click.prompt("Deployment name", default=saved.get("deployment_name"))
    bucket = click.prompt("S3 bucket", default=saved.get("s3_bucket", "mto-lambdas"))

    key = f"{deployment_name}/{deployment_name}.zip"

    click.echo(f"Uploading to s3://{bucket}/{key} ...")
    upload_result = upload_file_to_s3(
        file_path=zip_path,
        bucket=bucket,
        key=key,
        region=region,
    )
    click.echo(json.dumps(upload_result, indent=2))

    deploy_config_path.write_text(
        json.dumps({"deployment_name": deployment_name, "s3_bucket": bucket}, indent=2),
        encoding="utf-8",
    )
    sample_payload = json.dumps({
        "s3_bucket": bucket,
        "s3_key": key,
        "entrypoint": config.entrypoint,
        "runtime": config.runtime,
        "args": {},
    }, indent=2)
    click.echo("\nSample job payload:")
    click.secho(sample_payload, fg="magenta")
    click.echo("\nDeploy complete.")


if __name__ == "__main__":
    cli()