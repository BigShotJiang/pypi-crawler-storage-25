from __future__ import annotations

from pathlib import Path

import boto3
from botocore.exceptions import BotoCoreError, ClientError


def upload_file_to_s3(
    *,
    file_path: Path,
    bucket: str,
    key: str,
    region: str | None = None,
) -> dict:
    session = boto3.session.Session(region_name=region) if region else boto3.session.Session()
    s3 = session.client("s3")

    try:
        s3.upload_file(str(file_path), bucket, key)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        msg = exc.response.get("Error", {}).get("Message", str(exc))
        raise RuntimeError(f"S3 upload failed ({code}): {msg}") from exc
    except BotoCoreError as exc:
        raise RuntimeError(f"S3 upload failed: {exc}") from exc

    return {
        "bucket": bucket,
        "key": key,
        "file_name": file_path.name,
    }