from __future__ import annotations

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def main(event: dict, context: dict) -> dict:
    logger.info("Hello from Goliath job packager")
    logger.info("Event: %s", event)
    logger.info("Context: %s", context)

    return {
        "success": True,
        "message": "Job completed successfully",
    }
