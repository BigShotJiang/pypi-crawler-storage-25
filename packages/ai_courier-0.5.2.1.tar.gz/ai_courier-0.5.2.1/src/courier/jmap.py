"""Thin JMAP client for Fastmail.

JMAP is JSON-over-HTTP with a session discovery endpoint. This module implements
just enough of RFC 8620/8621 to be a complete email client — no more.
"""

from __future__ import annotations

import asyncio
import html as _html
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import httpx

from .config import AccountConfig


# ── v0.5.2: HTML email body support ─────────────────────────────────


_VALID_CONTENT_TYPES = ("text/plain", "text/html")


def _validate_content_type(content_type: str) -> None:
    """Raise ValueError if content_type isn't one of the two allowed values."""
    if content_type not in _VALID_CONTENT_TYPES:
        raise ValueError(
            f"content_type must be one of {_VALID_CONTENT_TYPES!r} "
            f"(got {content_type!r})"
        )


def _build_email_body(
    body: str, content_type: str
) -> tuple[list[dict[str, str]], list[dict[str, str]] | None, dict[str, dict[str, str]]]:
    """Build the (textBody, htmlBody, bodyValues) triple for an Email/set payload.

    Plain mode: textBody only, single part.
    HTML mode: multipart/alternative — htmlBody holds the raw HTML, textBody
    gets an auto-generated plain-text twin via ``JMAPClient._strip_to_text``.

    Pure function — no network, no JMAP client needed. Feeds directly into
    the email_obj dict inside create_draft / reply_to / forward.
    """
    _validate_content_type(content_type)
    if content_type == "text/plain":
        return (
            [{"partId": "body", "type": "text/plain"}],
            None,
            {"body": {"value": body}},
        )
    # text/html: multipart/alternative
    plain_fallback = JMAPClient._strip_to_text(body)
    return (
        [{"partId": "text", "type": "text/plain"}],
        [{"partId": "html", "type": "text/html"}],
        {
            "text": {"value": plain_fallback},
            "html": {"value": body},
        },
    )


@dataclass
class JMAPSession:
    """Parsed JMAP session resource."""

    api_url: str
    download_url: str
    upload_url: str
    account_id: str
    capabilities: dict[str, Any] = field(default_factory=dict)


@dataclass
class Attachment:
    """A single attachment on an email (inline or regular)."""

    blob_id: str
    name: str
    type: str  # MIME type
    size: int
    part_id: str = ""
    disposition: str = "attachment"  # "attachment" or "inline"
    cid: str | None = None  # Content-ID for inline images

    def summary_dict(self) -> dict[str, Any]:
        return {
            "blob_id": self.blob_id,
            "name": self.name,
            "type": self.type,
            "size": self.size,
            "disposition": self.disposition,
        }


@dataclass
class Email:
    """Context-window-optimized email representation.

    Not a MIME tree. Just what an AI agent needs to understand and act on an email.
    """

    id: str
    thread_id: str
    mailbox_ids: list[str]
    from_address: str
    from_name: str
    to: list[str]
    cc: list[str]
    subject: str
    date: str
    preview: str  # First ~256 chars
    body_text: str  # Full plain-text body
    is_unread: bool
    is_flagged: bool
    has_attachment: bool
    has_calendar_invite: bool = False  # True if any MIME part is text/calendar
    in_reply_to: str | None = None
    references: list[str] = field(default_factory=list)
    size: int = 0
    attachments: list[Attachment] = field(default_factory=list)
    message_id: list[str] = field(default_factory=list)
    reply_to_addrs: list[str] = field(default_factory=list)
    blob_id: str = ""  # RFC 8621 §4.1.1 — reference to the raw RFC 5322 MIME

    def summary(
        self,
        max_body: int = 200,
        include_body: bool = True,
    ) -> dict[str, Any]:
        """Token-efficient representation for context windows.

        ``max_body`` defaults to 200 for snippet semantics (v0.5.1) — a tight
        triage-surface bound that keeps ``email_inbox(limit=50)`` inline-readable
        even on HTML-heavy inboxes. Callers that need more characters should
        use ``email_read(email_id)`` instead; that's the full-read path.

        ``include_body=False`` omits the body entirely (v0.5.1 — used by
        ``email_inbox(body_mode="none")``). Metadata only; useful when triage
        can decide from sender/subject/reason alone.
        """
        result: dict[str, Any] = {
            "id": self.id,
            "thread_id": self.thread_id,
            "from": f"{self.from_name} <{self.from_address}>" if self.from_name else self.from_address,
            "to": self.to,
            "subject": self.subject,
            "date": self.date,
            "unread": self.is_unread,
            "flagged": self.is_flagged,
            "has_attachment": self.has_attachment,
            "attachments": [a.summary_dict() for a in self.attachments],
        }
        if include_body:
            body = self.body_text[:max_body] + (
                "..." if len(self.body_text) > max_body else ""
            )
            result["body"] = body
        return result


def _first_or_str(value: Any) -> str | None:
    """Normalize a JMAP field that may be a string, a list of strings, or None.

    RFC 8621 Email.inReplyTo is defined as String[], but some clients have
    historically received/passed it as a single String. This helper returns
    the first element of a list, the string itself, or None.
    """
    if value is None:
        return None
    if isinstance(value, list):
        return value[0] if value else None
    return value


class JMAPClient:
    """Async JMAP client for email operations."""

    MAIL_PROPERTIES = [
        "id", "blobId", "threadId", "mailboxIds", "from", "to", "cc", "subject",
        "receivedAt", "preview", "textBody", "htmlBody", "bodyStructure",
        "bodyValues", "keywords", "hasAttachment", "inReplyTo", "references",
        "size", "messageId", "replyTo",
    ]

    # ── v0.5.2: HTML body support — stripper for plain-text fallback ─────

    @staticmethod
    def _strip_to_text(html: str) -> str:
        """Zero-dep HTML → readable plain-text fallback.

        Used to auto-generate the ``textBody`` twin of an HTML ``htmlBody``
        in ``multipart/alternative`` sends — so plain-text-only receivers
        still get a legible version.

        Rules (applied in order):
          1. Decode HTML entities via ``html.unescape``.
          2. Anchors become ``text (url)`` — link destinations are
             important enough to keep inline.
          3. ``<br>``, ``<br/>``, ``<br />`` → single newline.
          4. ``<li>`` → ``\\n- `` (dash bullet).
          5. Block-closing tags (``</p>``, ``</div>``, ``</h1>..</h6>``,
             ``</ul>``, ``</ol>``, ``</blockquote>``) → paragraph break.
          6. All remaining tags are dropped.
          7. Runs of 3+ newlines collapse to exactly 2.
          8. Leading/trailing whitespace trimmed.

        Not a full HTML → Markdown converter. Good enough for what typical
        email clients send (paragraphs, bold, lists, links). If we see
        messages in the wild that strip badly, replace with ``html2text``.
        """
        if not html:
            return ""

        # 2. Anchors first (before dropping tags) so href survives.
        s = re.sub(
            r"<a\s+[^>]*?href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>",
            r"\2 (\1)",
            html,
            flags=re.DOTALL | re.IGNORECASE,
        )
        # 3. Line breaks.
        s = re.sub(r"<br\s*/?>", "\n", s, flags=re.IGNORECASE)
        # 4. List items — one per line, dash bullet.
        s = re.sub(r"<li[^>]*>", "\n- ", s, flags=re.IGNORECASE)
        # 5. Block-closing tags → paragraph break.
        s = re.sub(
            r"</(p|div|h[1-6]|ul|ol|blockquote|tr)>",
            "\n\n",
            s,
            flags=re.IGNORECASE,
        )
        # 6. Everything else: drop the tag, keep content.
        s = re.sub(r"<[^>]+>", "", s)
        # 1. Decode entities after tag removal so raw entities in text survive.
        s = _html.unescape(s)
        # 7. Collapse runs of 3+ newlines.
        s = re.sub(r"\n{3,}", "\n\n", s)
        # 8. Trim overall.
        return s.strip()

    def __init__(self, account: AccountConfig):
        self.account = account
        self.session: JMAPSession | None = None
        self._client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {account.api_token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def connect(self) -> JMAPSession:
        """Discover JMAP session and capabilities."""
        resp = await self._client.get(self.account.jmap_url)
        resp.raise_for_status()
        data = resp.json()

        # Fastmail returns primaryAccounts keyed by capability URI
        primary = data.get("primaryAccounts", {})
        account_id = primary.get(
            "urn:ietf:params:jmap:mail",
            next(iter(data.get("accounts", {}).keys()), ""),
        )

        self.session = JMAPSession(
            api_url=data["apiUrl"],
            download_url=data["downloadUrl"],
            upload_url=data["uploadUrl"],
            account_id=account_id,
            capabilities=data.get("capabilities", {}),
        )
        return self.session

    async def _call(self, method_calls: list[list]) -> list[list]:
        """Execute JMAP method calls."""
        if not self.session:
            await self.connect()

        payload = {
            "using": [
                "urn:ietf:params:jmap:core",
                "urn:ietf:params:jmap:mail",
                "urn:ietf:params:jmap:submission",
            ],
            "methodCalls": method_calls,
        }

        resp = await self._client.post(self.session.api_url, json=payload)
        resp.raise_for_status()
        return resp.json()["methodResponses"]

    @staticmethod
    def _has_calendar_part(structure: dict[str, Any] | None) -> bool:
        """Walk JMAP bodyStructure tree looking for text/calendar MIME parts."""
        if not structure:
            return False
        if (structure.get("type", "") + "/" + structure.get("subtype", "")).lower() == "text/calendar":
            return True
        # JMAP also uses a flat "type" field like "text/calendar" in some implementations
        if structure.get("type", "").lower() == "text/calendar":
            return True
        for sub in structure.get("subParts", []):
            if JMAPClient._has_calendar_part(sub):
                return True
        return False

    @staticmethod
    def _extract_attachments(
        structure: dict[str, Any] | None,
        text_body_part_ids: set[str] | None = None,
    ) -> list[Attachment]:
        """Walk bodyStructure and collect attachment parts.

        A part is an attachment if it has a blobId AND either:
          - disposition=="attachment", OR
          - disposition=="inline" AND has a filename (inline images with names), OR
          - it's a leaf with blobId that isn't part of textBody/htmlBody
        """
        text_ids = text_body_part_ids or set()
        found: list[Attachment] = []

        def walk(p: dict[str, Any]) -> None:
            if not p:
                return
            sub_parts = p.get("subParts") or []
            if sub_parts:
                for sp in sub_parts:
                    walk(sp)
                return
            # Leaf part
            blob_id = p.get("blobId")
            if not blob_id:
                return
            part_id = p.get("partId", "")
            # Skip the email body itself
            if part_id and part_id in text_ids:
                return
            disposition = (p.get("disposition") or "").lower()
            name = p.get("name") or ""
            # JMAP uses type+subtype or "type" field; normalize
            mime_type = p.get("type", "")
            if p.get("subtype"):
                mime_type = f"{mime_type}/{p['subtype']}"
            # Any leaf part with a blobId that isn't part of the body is an
            # attachment (inline image without a partId, .ics calendar invite,
            # signed application/pkcs7, etc.). Skip only plain-text/html leafs
            # with no name — those are stray body representations.
            mt_lower = mime_type.lower()
            is_stray_body = (
                mt_lower in ("text/plain", "text/html") and not name
                and disposition != "attachment"
            )
            if is_stray_body:
                return
            found.append(Attachment(
                blob_id=blob_id,
                name=name or f"part-{part_id}",
                type=mime_type or "application/octet-stream",
                size=int(p.get("size", 0)),
                part_id=part_id,
                disposition=disposition or "attachment",
                cid=p.get("cid"),
            ))

        walk(structure or {})
        return found

    @staticmethod
    def _compute_path(mailbox_id: str, mailboxes: list[dict[str, Any]]) -> str:
        """Walk parentId chain to build a slash-separated path.

        Cycle-safe: bails out after 20 hops.
        """
        by_id = {mb["id"]: mb for mb in mailboxes}
        parts: list[str] = []
        seen: set[str] = set()
        cur = mailbox_id
        for _ in range(20):
            if cur in seen or cur not in by_id:
                break
            seen.add(cur)
            mb = by_id[cur]
            parts.append(mb.get("name", ""))
            parent = mb.get("parentId")
            if not parent:
                break
            cur = parent
        return "/".join(reversed(parts))

    @staticmethod
    def _resolve_mailbox(target: str, mailboxes: list[dict[str, Any]]) -> str:
        """Resolve a mailbox identifier to its JMAP ID.

        Resolution order:
          1. Exact ID match
          2. Full path (e.g. 'Clients/Guardian')
          3. Unique leaf name (fails if ambiguous)

        Raises ValueError if not found or ambiguous.
        """
        by_id = {mb["id"]: mb for mb in mailboxes}
        # 1. ID
        if target in by_id:
            return target
        # 2. Path
        if "/" in target:
            for mb in mailboxes:
                if JMAPClient._compute_path(mb["id"], mailboxes) == target:
                    return mb["id"]
            raise ValueError(f"Mailbox path {target!r} not found")
        # 3. Leaf name
        matches = [mb for mb in mailboxes if mb.get("name") == target]
        if not matches:
            raise ValueError(f"Mailbox {target!r} not found")
        if len(matches) > 1:
            paths = [JMAPClient._compute_path(m["id"], mailboxes) for m in matches]
            raise ValueError(
                f"Mailbox name {target!r} is ambiguous — matches: {paths}. "
                "Use the full path."
            )
        return matches[0]["id"]

    @staticmethod
    def _build_reply_headers(
        original: "Email",
        body: str,
        cc: list[dict[str, str]] | None,
        include_quote: bool = False,
        content_type: str = "text/plain",
    ) -> dict[str, Any]:
        """Compose reply fields from the original email.

        Returns a dict with keys: subject, in_reply_to, references, to, cc, body.

        ``content_type`` (v0.5.2) determines how ``include_quote`` renders the
        quoted-original block:
          - ``"text/plain"``: ``> ``-prefixed attribution + body_text lines
          - ``"text/html"``: ``<blockquote><pre>…</pre></blockquote>`` with
            HTML-escaped body_text, since we don't retain the original's HTML
            body. Loses original formatting but is injection-safe.
        """
        # Subject: add "Re: " if not already there (case-insensitive)
        subj = original.subject or ""
        if subj.lower().startswith("re:"):
            reply_subject = subj
        else:
            reply_subject = f"Re: {subj}"

        # In-Reply-To: first Message-ID header of the original
        orig_mid = original.message_id[0] if original.message_id else ""

        # References: original.references + original Message-ID (deduped, ordered)
        refs = list(original.references or [])
        if orig_mid and orig_mid not in refs:
            refs.append(orig_mid)

        # To: Reply-To if present, else From
        if original.reply_to_addrs:
            to = [{"email": addr} for addr in original.reply_to_addrs]
        else:
            to_entry: dict[str, str] = {"email": original.from_address}
            if original.from_name:
                to_entry["name"] = original.from_name
            to = [to_entry]

        # Body: optionally prepend quoted original. Shape depends on content_type.
        if include_quote and original.body_text:
            if content_type == "text/html":
                escaped = _html.escape(original.body_text)
                attribution = (
                    f"On {_html.escape(original.date)}, "
                    f"{_html.escape(original.from_name)} "
                    f"&lt;{_html.escape(original.from_address)}&gt; wrote:"
                )
                body = (
                    f"{body}<br><br>{attribution}"
                    f"<blockquote><pre>{escaped}</pre></blockquote>"
                )
            else:
                attribution = (
                    f"On {original.date}, {original.from_name} "
                    f"<{original.from_address}> wrote:\n"
                )
                quoted = "\n".join(
                    f"> {line}" for line in original.body_text.splitlines()
                )
                body = f"{body}\n\n{attribution}{quoted}"

        return {
            "subject": reply_subject,
            "in_reply_to": orig_mid,
            "references": refs,
            "to": to,
            "cc": cc,
            "body": body,
        }

    @staticmethod
    def _build_forward_headers(
        original: "Email",
        to: list[dict[str, str]],
        cc: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        """Compose forward fields from the original email.

        Unlike reply, forward starts a new thread — no In-Reply-To — but
        still chains References for client-side threading heuristics.
        Returns a dict with keys: subject, references, to, cc.
        """
        subj = original.subject or ""
        fwd_subject = subj if subj.lower().startswith("fwd:") else f"Fwd: {subj}"

        orig_mid = original.message_id[0] if original.message_id else ""
        refs = list(original.references or [])
        if orig_mid and orig_mid not in refs:
            refs.append(orig_mid)

        return {
            "subject": fwd_subject,
            "references": refs,
            "to": to,
            "cc": cc,
        }

    def _parse_email(self, raw: dict[str, Any]) -> Email:
        """Parse JMAP Email object into our optimized representation."""
        from_addr = raw.get("from", [{}])
        first_from = from_addr[0] if from_addr else {}

        # Extract plain text body
        body_text = ""
        body_values = raw.get("bodyValues", {})
        for part in raw.get("textBody", []):
            part_id = part.get("partId", "")
            if part_id in body_values:
                body_text += body_values[part_id].get("value", "")

        keywords = raw.get("keywords", {})

        # Detect calendar invite via MIME structure
        structure = raw.get("bodyStructure")
        has_calendar = self._has_calendar_part(structure)

        # Extract attachments, excluding the body parts themselves
        text_body_part_ids = {p.get("partId", "") for p in raw.get("textBody", []) or []}
        html_body_part_ids = {p.get("partId", "") for p in raw.get("htmlBody", []) or []}
        body_part_ids = text_body_part_ids | html_body_part_ids
        attachments = self._extract_attachments(structure, body_part_ids)

        return Email(
            id=raw["id"],
            thread_id=raw.get("threadId", ""),
            mailbox_ids=list(raw.get("mailboxIds", {}).keys()),
            from_address=first_from.get("email", ""),
            from_name=first_from.get("name", ""),
            to=[a.get("email", "") for a in raw.get("to", []) or []],
            cc=[a.get("email", "") for a in raw.get("cc", []) or []],
            subject=raw.get("subject", ""),
            date=raw.get("receivedAt", ""),
            preview=raw.get("preview", ""),
            body_text=body_text,
            is_unread=not keywords.get("$seen", False),
            is_flagged=keywords.get("$flagged", False),
            has_attachment=raw.get("hasAttachment", False),
            has_calendar_invite=has_calendar,
            in_reply_to=_first_or_str(raw.get("inReplyTo")),
            references=raw.get("references", []) or [],
            size=raw.get("size", 0),
            attachments=attachments,
            message_id=raw.get("messageId") or [],
            reply_to_addrs=[a.get("email", "") for a in raw.get("replyTo") or []],
            blob_id=raw.get("blobId", ""),
        )

    # ── Query operations ─────────────────────────────────────────────

    async def get_mailboxes(self) -> list[dict[str, Any]]:
        """List all mailboxes (folders/labels)."""
        responses = await self._call([
            ["Mailbox/get", {"accountId": self.session.account_id}, "0"],
        ])
        return responses[0][1].get("list", [])

    async def list_mailboxes_enriched(self) -> list[dict[str, Any]]:
        """Get mailboxes with computed path + summary-shaped output."""
        mailboxes = await self.get_mailboxes()
        return [
            {
                "id": mb["id"],
                "name": mb.get("name", ""),
                "path": self._compute_path(mb["id"], mailboxes),
                "role": mb.get("role") or "",
                "parent_id": mb.get("parentId") or "",
                "total_emails": mb.get("totalEmails", 0),
                "unread_emails": mb.get("unreadEmails", 0),
                "sort_order": mb.get("sortOrder", 0),
            }
            for mb in mailboxes
        ]

    async def get_mailbox_id(self, role: str = "inbox") -> str:
        """Get mailbox ID by role (inbox, drafts, sent, trash, archive, junk)."""
        mailboxes = await self.get_mailboxes()
        for mb in mailboxes:
            if mb.get("role") == role:
                return mb["id"]
        raise ValueError(f"No mailbox with role '{role}'")

    async def create_mailbox(
        self, name: str, parent_id: str | None = None
    ) -> str:
        """Create a mailbox. Returns the new mailbox ID.

        Idempotent at the caller's level: check existence before calling.
        """
        create_obj: dict[str, Any] = {"name": name}
        if parent_id:
            create_obj["parentId"] = parent_id
        responses = await self._call([
            [
                "Mailbox/set",
                {
                    "accountId": self.session.account_id,
                    "create": {"new": create_obj},
                },
                "0",
            ],
        ])
        created = responses[0][1].get("created", {})
        if "new" not in created:
            not_created = responses[0][1].get("notCreated", {})
            err = not_created.get("new", not_created)
            err_type = err.get("type", "unknown") if isinstance(err, dict) else "unknown"
            err_desc = err.get("description", err) if isinstance(err, dict) else err
            raise RuntimeError(f"Mailbox create failed ({err_type}): {err_desc}")
        return created["new"]["id"]

    async def list_emails(
        self,
        mailbox_id: str | None = None,
        limit: int = 50,
        position: int = 0,
        sort: str = "receivedAt",
        ascending: bool = False,
    ) -> list[Email]:
        """List emails from a mailbox with full body text."""
        if not mailbox_id:
            mailbox_id = await self.get_mailbox_id("inbox")

        responses = await self._call([
            [
                "Email/query",
                {
                    "accountId": self.session.account_id,
                    "filter": {"inMailbox": mailbox_id},
                    "sort": [{"property": sort, "isAscending": ascending}],
                    "position": position,
                    "limit": limit,
                },
                "0",
            ],
            [
                "Email/get",
                {
                    "accountId": self.session.account_id,
                    "#ids": {"resultOf": "0", "name": "Email/query", "path": "/ids"},
                    "properties": self.MAIL_PROPERTIES,
                    "fetchTextBodyValues": True,
                },
                "1",
            ],
        ])

        emails_data = responses[1][1].get("list", [])
        return [self._parse_email(e) for e in emails_data]

    @staticmethod
    def _normalize_utcdate(value: str) -> str:
        """Ensure a date string is full UTCDate for JMAP (RFC 8621).

        JMAP's ``after`` and ``before`` filters require strict UTCDate
        format (``YYYY-MM-DDTHH:MM:SSZ``) — Fastmail silently returns
        empty results for anything non-conforming (bare dates, microseconds,
        non-Z UTC offsets, non-UTC timezones).

        Accepts any ISO-8601 string Python can parse and coerces it:
            "2026-04-11"                    → "2026-04-11T00:00:00Z"
            "2026-04-17T18:16:23"           → "2026-04-17T18:16:23Z"
            "2026-04-17T18:16:23.454444+00:00" → "2026-04-17T18:16:23Z"
            "2026-04-17T18:16:23Z"          → "2026-04-17T18:16:23Z"

        Rejects non-UTC offsets (e.g. ``-05:00``) with ValueError — the
        caller should convert to UTC explicitly rather than have the
        normalizer silently shift the instant. Also rejects malformed
        input (e.g. ``""`` or ``"not-a-date"``) with ValueError rather
        than silently producing a bogus string.
        """
        # Let datetime.fromisoformat do all the validation. On 3.11+ it
        # accepts bare dates, naive datetimes, 'Z', '+00:00', microseconds,
        # and the space separator. Everything we want — anything it
        # rejects is malformed and becomes a useful ValueError.
        try:
            parsed = datetime.fromisoformat(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Invalid ISO-8601 datetime {value!r}: {exc}"
            ) from exc

        if parsed.tzinfo is None:
            # Naive → treat as UTC (matches prior behavior of appending 'Z')
            return parsed.replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")

        if parsed.utcoffset() != timezone.utc.utcoffset(parsed):
            raise ValueError(
                f"UTCDate must be UTC (got offset {parsed.utcoffset()}). "
                f"Convert to UTC before passing to JMAP filter."
            )

        return parsed.astimezone(timezone.utc).replace(microsecond=0).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

    _ORIGINAL_MESSAGE_RE = re.compile(
        r"^-{2,}\s*Original Message\s*-{2,}\s*$", re.IGNORECASE
    )
    _ON_WROTE_RE = re.compile(r"^On .+wrote:\s*$")

    @staticmethod
    def _strip_quoted_reply(body: str) -> str:
        """Trim quoted-reply noise from the end of an email body.

        Handles three common patterns: Outlook "-----Original Message-----"
        headers, Gmail/RFC "On <date>, <sender> wrote:" attributions, and
        bare trailing ``>``-prefixed blocks. Cuts at the earliest match.
        """
        if not body:
            return ""
        lines = body.splitlines()
        cut = len(lines)
        for i, line in enumerate(lines):
            stripped = line.strip()
            if JMAPClient._ORIGINAL_MESSAGE_RE.match(stripped):
                cut = i
                break
            if JMAPClient._ON_WROTE_RE.match(stripped):
                cut = i
                break
            if line.startswith(">") and any(
                not prev.startswith(">") and prev.strip() for prev in lines[:i]
            ):
                cut = i
                break
        return "\n".join(lines[:cut]).rstrip()

    async def search_emails(
        self,
        query: str | None = None,
        from_addr: str | None = None,
        subject: str | None = None,
        after: str | None = None,
        before: str | None = None,
        has_attachment: bool | None = None,
        is_unread: bool | None = None,
        mailbox_id: str | None = None,
        limit: int = 50,
    ) -> list[Email]:
        """Search emails with flexible filters."""
        filter_obj: dict[str, Any] = {}
        if query:
            filter_obj["text"] = query
        if from_addr:
            filter_obj["from"] = from_addr
        if subject:
            filter_obj["subject"] = subject
        if after:
            filter_obj["after"] = self._normalize_utcdate(after)
        if before:
            filter_obj["before"] = self._normalize_utcdate(before)
        if has_attachment is not None:
            filter_obj["hasAttachment"] = has_attachment
        if is_unread is not None:
            filter_obj["hasKeyword" if not is_unread else "notKeyword"] = "$seen"
        if mailbox_id:
            filter_obj["inMailbox"] = mailbox_id

        responses = await self._call([
            [
                "Email/query",
                {
                    "accountId": self.session.account_id,
                    "filter": filter_obj,
                    "sort": [{"property": "receivedAt", "isAscending": False}],
                    "limit": limit,
                },
                "0",
            ],
            [
                "Email/get",
                {
                    "accountId": self.session.account_id,
                    "#ids": {"resultOf": "0", "name": "Email/query", "path": "/ids"},
                    "properties": self.MAIL_PROPERTIES,
                    "fetchTextBodyValues": True,
                },
                "1",
            ],
        ])

        emails_data = responses[1][1].get("list", [])
        return [self._parse_email(e) for e in emails_data]

    async def list_sent(self, after: str, limit: int = 20) -> list[Email]:
        """List messages from the Sent mailbox since ``after``.

        Dedicated primitive for "what did I send recently?" — promotes a
        pattern that previously required a manual ``from:me`` search chain.
        """
        sent_id = await self.get_mailbox_id("sent")
        return await self.search_emails(
            mailbox_id=sent_id,
            after=after,
            limit=limit,
        )

    async def get_email(self, email_id: str) -> Email:
        """Get a single email by ID."""
        responses = await self._call([
            [
                "Email/get",
                {
                    "accountId": self.session.account_id,
                    "ids": [email_id],
                    "properties": self.MAIL_PROPERTIES,
                    "fetchTextBodyValues": True,
                },
                "0",
            ],
        ])
        emails = responses[0][1].get("list", [])
        if not emails:
            raise ValueError(f"Email {email_id} not found")
        return self._parse_email(emails[0])

    async def get_thread(self, thread_id: str) -> list[Email]:
        """Get all emails in a thread, ordered chronologically."""
        responses = await self._call([
            [
                "Thread/get",
                {
                    "accountId": self.session.account_id,
                    "ids": [thread_id],
                },
                "0",
            ],
        ])
        thread = responses[0][1].get("list", [{}])[0]
        email_ids = thread.get("emailIds", [])
        if not email_ids:
            return []

        responses = await self._call([
            [
                "Email/get",
                {
                    "accountId": self.session.account_id,
                    "ids": email_ids,
                    "properties": self.MAIL_PROPERTIES,
                    "fetchTextBodyValues": True,
                },
                "0",
            ],
        ])
        emails = responses[0][1].get("list", [])
        return [self._parse_email(e) for e in emails]

    async def build_thread_digest(
        self, thread_id: str, max_tokens: int = 4000
    ) -> dict[str, Any]:
        """Compact, quote-stripped thread payload for direct agent consumption.

        Returns the chronological messages with quoted-reply noise removed and
        the running body-char total capped at roughly ``max_tokens`` tokens
        (heuristic: 4 chars ≈ 1 token). Messages beyond the budget are dropped
        and ``truncated`` is set True.
        """
        thread = await self.get_thread(thread_id)
        char_budget = max_tokens * 4
        char_total = 0
        messages: list[dict[str, Any]] = []
        for email in thread:
            stripped = self._strip_quoted_reply(email.body_text)
            if char_total + len(stripped) > char_budget and messages:
                break
            char_total += len(stripped)
            messages.append({
                "id": email.id,
                "from": (
                    f"{email.from_name} <{email.from_address}>"
                    if email.from_name
                    else email.from_address
                ),
                "date": email.date,
                "subject": email.subject,
                "body": stripped,
                "attachments": [a.summary_dict() for a in email.attachments],
            })
        return {
            "thread_id": thread_id,
            "message_count": len(thread),
            "included": len(messages),
            "truncated": len(messages) < len(thread),
            "messages": messages,
        }

    # ── Mutation operations ──────────────────────────────────────────

    async def move_emails(self, email_ids: list[str], to_mailbox_id: str) -> None:
        """Move emails to a mailbox (batch)."""
        # First get current mailboxes to know what to remove
        responses = await self._call([
            [
                "Email/get",
                {
                    "accountId": self.session.account_id,
                    "ids": email_ids,
                    "properties": ["mailboxIds"],
                },
                "0",
            ],
        ])

        update = {}
        for email in responses[0][1].get("list", []):
            patch: dict[str, Any] = {f"mailboxIds/{to_mailbox_id}": True}
            for old_mb in email.get("mailboxIds", {}):
                if old_mb != to_mailbox_id:
                    patch[f"mailboxIds/{old_mb}"] = None
            update[email["id"]] = patch

        await self._call([
            [
                "Email/set",
                {"accountId": self.session.account_id, "update": update},
                "0",
            ],
        ])

    async def move_emails_by_name(
        self, email_ids: list[str], target: str
    ) -> dict[str, str]:
        """Move emails to a mailbox identified by ID, path, or name.

        Returns {'mailbox_id': <resolved id>, 'mailbox_name': <name>}.
        """
        mailboxes = await self.get_mailboxes()
        target_id = self._resolve_mailbox(target, mailboxes)
        await self.move_emails(email_ids, target_id)
        name = next(
            (mb.get("name", "") for mb in mailboxes if mb["id"] == target_id),
            "",
        )
        return {"mailbox_id": target_id, "mailbox_name": name}

    async def set_mailbox_memberships(
        self,
        email_ids: list[str],
        targets: list[str],
        add: bool = True,
    ) -> dict[str, Any]:
        """Add or remove mailbox memberships without touching other memberships.

        Uses Email/set patch form: mailboxIds/<id>: true (or null to remove).
        Non-destructive — existing memberships are preserved.
        """
        mailboxes = await self.get_mailboxes()
        target_ids = [self._resolve_mailbox(t, mailboxes) for t in targets]

        update = {}
        for eid in email_ids:
            patch = {}
            for tid in target_ids:
                patch[f"mailboxIds/{tid}"] = True if add else None
            update[eid] = patch

        await self._call([
            [
                "Email/set",
                {"accountId": self.session.account_id, "update": update},
                "0",
            ],
        ])
        name_by_id = {mb["id"]: mb.get("name", "") for mb in mailboxes}
        return {
            "updated": len(email_ids),
            "labels": [{"id": tid, "name": name_by_id.get(tid, "")} for tid in target_ids],
        }

    async def set_keywords(
        self, email_ids: list[str], keywords: dict[str, bool]
    ) -> None:
        """Set keywords on emails (batch). Use for read/unread, flagged, etc."""
        update = {}
        for eid in email_ids:
            patch = {}
            for kw, val in keywords.items():
                patch[f"keywords/{kw}"] = val if val else None
            update[eid] = patch

        await self._call([
            [
                "Email/set",
                {"accountId": self.session.account_id, "update": update},
                "0",
            ],
        ])

    async def mark_read(self, email_ids: list[str]) -> None:
        """Mark emails as read (batch)."""
        await self.set_keywords(email_ids, {"$seen": True})

    async def mark_unread(self, email_ids: list[str]) -> None:
        """Mark emails as unread (batch)."""
        await self.set_keywords(email_ids, {"$seen": False})

    async def flag(self, email_ids: list[str]) -> None:
        """Flag/star emails (batch)."""
        await self.set_keywords(email_ids, {"$flagged": True})

    async def archive(self, email_ids: list[str]) -> None:
        """Archive emails — move to Archive mailbox (batch)."""
        archive_id = await self.get_mailbox_id("archive")
        await self.move_emails(email_ids, archive_id)

    async def trash(self, email_ids: list[str]) -> None:
        """Trash emails (batch)."""
        trash_id = await self.get_mailbox_id("trash")
        await self.move_emails(email_ids, trash_id)

    async def test_cleanup(
        self,
        prefix: str = "[courier-",
        dry_run: bool = False,
        limit: int = 500,
    ) -> dict[str, int]:
        """Sweep E2E test + probe artifacts matching a subject prefix to Trash.

        Finds stray ``[courier-*]`` messages left behind by E2E fixture
        teardowns that timed out or crashed pre-yield (``[courier-e2e*]``) or
        by ad-hoc probe scripts (``[courier-probe*]``), and moves them to
        Trash. Messages already in Trash are skipped. Safe to run anytime —
        the fixture's happy-path cleanup and this sweeper are idempotent.

        Returns ``{"found": N, "to_trash": M, "trashed": M}`` (``trashed``
        is 0 when ``dry_run=True``).
        """
        trash_id = await self.get_mailbox_id("trash")
        emails = await self.search_emails(subject=prefix, limit=limit)
        to_trash = [e.id for e in emails if trash_id not in e.mailbox_ids]
        result: dict[str, int] = {
            "found": len(emails),
            "to_trash": len(to_trash),
            "trashed": 0,
        }
        if not to_trash or dry_run:
            return result
        await self.trash(to_trash)
        result["trashed"] = len(to_trash)
        return result

    async def create_draft(
        self,
        to: list[dict[str, str]],
        subject: str,
        body: str,
        cc: list[dict[str, str]] | None = None,
        in_reply_to: str | None = None,
        references: list[str] | None = None,
        from_addr: dict[str, str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
        content_type: str = "text/plain",
    ) -> str:
        """Create a draft email. Returns the draft email ID.

        attachments: list of {blobId, type, name, size?} dicts. Blobs must be
        uploaded first via upload_blob(). For convenience use send_email() with
        file paths.

        content_type (v0.5.2): ``"text/plain"`` (default) sends body as plain
        text unchanged. ``"text/html"`` sends the body as HTML with an
        auto-generated plain-text fallback — proper ``multipart/alternative``
        so every receiver client renders correctly. Anything else raises
        ``ValueError``.
        """
        drafts_id = await self.get_mailbox_id("drafts")

        text_body, html_body, body_values = _build_email_body(
            body=body, content_type=content_type,
        )
        email_obj: dict[str, Any] = {
            "mailboxIds": {drafts_id: True},
            "to": to,
            "subject": subject,
            "textBody": text_body,
            "bodyValues": body_values,
            "keywords": {"$draft": True},
        }
        if html_body is not None:
            email_obj["htmlBody"] = html_body
        if from_addr:
            email_obj["from"] = [from_addr]
        if cc:
            email_obj["cc"] = cc
        if in_reply_to:
            # JMAP Email.inReplyTo is String[] per RFC 8621 §4.1.3.1
            email_obj["inReplyTo"] = (
                [in_reply_to] if isinstance(in_reply_to, str) else list(in_reply_to)
            )
        if references:
            email_obj["references"] = references
        if attachments:
            # JMAP EmailBodyPart entries — must include disposition and blobId
            email_obj["attachments"] = [
                {
                    "blobId": a["blobId"],
                    "type": a.get("type", "application/octet-stream"),
                    "name": a.get("name", ""),
                    "disposition": a.get("disposition", "attachment"),
                    **({"size": a["size"]} if "size" in a else {}),
                }
                for a in attachments
            ]

        responses = await self._call([
            [
                "Email/set",
                {
                    "accountId": self.session.account_id,
                    "create": {"draft": email_obj},
                },
                "0",
            ],
        ])
        created = responses[0][1].get("created", {})
        return created.get("draft", {}).get("id", "")

    async def send_email(
        self,
        to: list[dict[str, str]],
        subject: str,
        body: str,
        cc: list[dict[str, str]] | None = None,
        in_reply_to: str | None = None,
        references: list[str] | None = None,
        identity_id: str | None = None,
        attachment_paths: list[str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
        content_type: str = "text/plain",
    ) -> str:
        """Create and send an email. Returns the sent email ID.

        attachment_paths: list of local file paths — uploaded and attached.
        attachments: list of pre-uploaded blob dicts (bypasses upload).
        content_type (v0.5.2): ``"text/plain"`` (default) or ``"text/html"``
        for multipart/alternative with auto-generated plain fallback.
        """
        import mimetypes
        import os

        resolved_attachments: list[dict[str, Any]] = list(attachments or [])
        if attachment_paths:
            for path in attachment_paths:
                with open(path, "rb") as f:
                    data = f.read()
                ctype, _ = mimetypes.guess_type(path)
                ctype = ctype or "application/octet-stream"
                upload = await self.upload_blob(data, content_type=ctype)
                resolved_attachments.append({
                    "blobId": upload["blobId"],
                    "type": upload.get("type", ctype),
                    "name": os.path.basename(path),
                    "size": upload.get("size", len(data)),
                    "disposition": "attachment",
                })

        # Create the email in drafts first
        draft_id = await self.create_draft(
            to=to, subject=subject, body=body,
            cc=cc, in_reply_to=in_reply_to, references=references,
            attachments=resolved_attachments or None,
            content_type=content_type,
        )

        # Get identity for sending
        if not identity_id:
            identity_id = await self._get_default_identity()

        # Resolve mailbox IDs for the atomic post-submission move. Per
        # RFC 8621 §7.3, onSuccessUpdateEmail patches the Email as part of
        # the same method call that submits it — without this, the draft
        # stays stranded in Drafts and `email_sent_since` never sees it.
        drafts_id = await self.get_mailbox_id("drafts")
        sent_id = await self.get_mailbox_id("sent")

        # Submit for delivery; on success, move draft → Sent and clear $draft.
        await self._call([
            [
                "EmailSubmission/set",
                {
                    "accountId": self.session.account_id,
                    "create": {
                        "send": {
                            "identityId": identity_id,
                            "emailId": draft_id,
                        }
                    },
                    "onSuccessUpdateEmail": {
                        "#send": {
                            f"mailboxIds/{drafts_id}": None,
                            f"mailboxIds/{sent_id}": True,
                            "keywords/$draft": None,
                        },
                    },
                },
                "0",
            ],
        ])
        return draft_id

    async def reply_to(
        self,
        email_id: str,
        body: str,
        send: bool = False,
        include_quote: bool = False,
        cc: list[dict[str, str]] | None = None,
        content_type: str = "text/plain",
    ) -> dict[str, str]:
        """Reply to an email (threaded). Returns {id, status}.

        Pulls the original's Message-ID, References, Reply-To, From, and
        Subject; builds In-Reply-To and References correctly; composes the
        reply body; then creates a draft (send=False) or sends (send=True).

        content_type (v0.5.2): ``"text/plain"`` or ``"text/html"``. When
        ``include_quote=True``, the quoted-original block is rendered as
        ``> ``-prefixed lines (plain) or ``<blockquote><pre>…</pre>
        </blockquote>`` with HTML-escaped body (html).
        """
        original = await self.get_email(email_id)
        composed = self._build_reply_headers(
            original, body=body, cc=cc,
            include_quote=include_quote, content_type=content_type,
        )
        if send:
            new_id = await self.send_email(
                to=composed["to"],
                subject=composed["subject"],
                body=composed["body"],
                cc=composed["cc"],
                in_reply_to=composed["in_reply_to"],
                references=composed["references"],
                content_type=content_type,
            )
            return {"id": new_id, "status": "sent"}
        else:
            draft_id = await self.create_draft(
                to=composed["to"],
                subject=composed["subject"],
                body=composed["body"],
                cc=composed["cc"],
                in_reply_to=composed["in_reply_to"],
                references=composed["references"],
                content_type=content_type,
            )
            return {"id": draft_id, "status": "draft"}

    async def forward(
        self,
        email_id: str,
        to: list[str],
        body: str,
        include_original: bool = True,
        send: bool = False,
        cc: list[str] | None = None,
        content_type: str = "text/plain",
    ) -> dict[str, str]:
        """Forward an email, optionally re-attaching the original as .eml.

        Defaults to draft (``send=False``), matching ``reply_to`` semantics.
        When ``include_original`` is True, the original's raw RFC 5322 MIME
        is downloaded via ``Email.blobId`` and re-uploaded as a
        ``message/rfc822`` attachment.

        content_type (v0.5.2): ``"text/plain"`` or ``"text/html"``.

        Returns ``{"id": <email_id>, "status": "draft" | "sent"}``.
        """
        original = await self.get_email(email_id)
        to_dicts = [{"email": addr} for addr in to]
        cc_dicts = [{"email": addr} for addr in cc] if cc else None
        headers = self._build_forward_headers(
            original, to=to_dicts, cc=cc_dicts,
        )

        attachments: list[dict[str, Any]] | None = None
        if include_original:
            if not original.blob_id:
                raise ValueError(
                    f"Cannot forward {email_id}: no blobId on Email (RFC 8621 "
                    "§4.1.1 mandates it — refetch or upgrade the server)."
                )
            raw = await self.download_blob(
                original.blob_id, content_type="message/rfc822"
            )
            upload = await self.upload_blob(raw, content_type="message/rfc822")
            # Derive a safe .eml filename from the original subject.
            safe_subj = (original.subject or "forwarded").replace("/", "_")[:200]
            attachments = [{
                "blobId": upload["blobId"],
                "type": "message/rfc822",
                "name": f"{safe_subj}.eml",
                "size": upload.get("size", len(raw)),
                "disposition": "attachment",
            }]

        if send:
            new_id = await self.send_email(
                to=headers["to"],
                subject=headers["subject"],
                body=body,
                cc=headers["cc"],
                references=headers["references"],
                attachments=attachments,
                content_type=content_type,
            )
            return {"id": new_id, "status": "sent"}
        else:
            draft_id = await self.create_draft(
                to=headers["to"],
                subject=headers["subject"],
                body=body,
                cc=headers["cc"],
                references=headers["references"],
                attachments=attachments,
                content_type=content_type,
            )
            return {"id": draft_id, "status": "draft"}

    # ── Blob (attachment) operations ────────────────────────────────

    async def download_blob(self, blob_id: str, content_type: str = "application/octet-stream", name: str = "") -> bytes:
        """Download raw bytes for a blob (attachment).

        Uses the JMAP downloadUrl template — substitutes {accountId}, {blobId},
        {type}, and {name} per RFC 8620 §6.2.
        """
        if not self.session:
            await self.connect()
        url = self.session.download_url
        url = (
            url.replace("{accountId}", self.session.account_id)
            .replace("{blobId}", blob_id)
            .replace("{type}", content_type)
            .replace("{name}", name or blob_id)
        )
        resp = await self._client.get(url)
        resp.raise_for_status()
        return resp.content

    async def upload_blob(self, data: bytes, content_type: str = "application/octet-stream") -> dict[str, Any]:
        """Upload raw bytes as a blob. Returns the JMAP upload response with blobId, type, size.

        Uses the JMAP uploadUrl template — substitutes {accountId}.
        """
        if not self.session:
            await self.connect()
        url = self.session.upload_url.replace("{accountId}", self.session.account_id)
        resp = await self._client.post(
            url,
            content=data,
            headers={"Content-Type": content_type},
        )
        resp.raise_for_status()
        return resp.json()

    async def _get_default_identity(self) -> str:
        """Get the default sending identity."""
        responses = await self._call([
            ["Identity/get", {"accountId": self.session.account_id}, "0"],
        ])
        identities = responses[0][1].get("list", [])
        if not identities:
            raise ValueError("No sending identities configured")
        return identities[0]["id"]

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, *args):
        await self.close()
