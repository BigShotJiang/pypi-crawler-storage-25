"""Configuration management for Courier."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_CONFIG_DIR = Path.home() / ".config" / "courier"
DEFAULT_DB_PATH = DEFAULT_CONFIG_DIR / "courier.db"


@dataclass
class AccountConfig:
    """Configuration for a single email/calendar account."""

    account_id: str
    provider: str  # "fastmail" for now; extensible later
    api_token: str  # JMAP token (for email)
    app_password: str = ""  # App password (for CalDAV)
    jmap_url: str = "https://api.fastmail.com/jmap/session"
    caldav_url: str = ""  # Auto-built from username for Fastmail
    username: str = ""
    timezone: str = "America/Chicago"  # Local timezone for calendar output


def _account_to_dict(acct: AccountConfig) -> dict:
    return {
        "provider": acct.provider,
        "api_token": acct.api_token,
        "app_password": acct.app_password,
        "jmap_url": acct.jmap_url,
        "caldav_url": acct.caldav_url,
        "username": acct.username,
        "timezone": acct.timezone,
    }


@dataclass
class CourierConfig:
    """Top-level Courier configuration."""

    accounts: dict[str, AccountConfig] = field(default_factory=dict)
    db_path: Path = DEFAULT_DB_PATH
    default_account: str = ""
    # v0.4.1: read-only delegate calendar accounts (for cross-account free/busy).
    # Each delegate typically only has app_password + username populated (calendar-only).
    delegate_accounts: list[AccountConfig] = field(default_factory=list)

    @classmethod
    def load(cls, path: Path | None = None) -> CourierConfig:
        """Load config from JSON file."""
        path = path or (DEFAULT_CONFIG_DIR / "config.json")
        if not path.exists():
            return cls()
        data = json.loads(path.read_text())
        accounts = {}
        for aid, acct in data.get("accounts", {}).items():
            accounts[aid] = AccountConfig(account_id=aid, **acct)
        delegates = [
            AccountConfig(account_id=d.pop("account_id"), **d)
            for d in data.get("delegate_accounts", [])
        ]
        return cls(
            accounts=accounts,
            db_path=Path(data.get("db_path", DEFAULT_DB_PATH)),
            default_account=data.get("default_account", ""),
            delegate_accounts=delegates,
        )

    def save(self, path: Path | None = None) -> None:
        """Save config to JSON file."""
        path = path or (DEFAULT_CONFIG_DIR / "config.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "accounts": {
                aid: _account_to_dict(acct) for aid, acct in self.accounts.items()
            },
            "db_path": str(self.db_path),
            "default_account": self.default_account,
            "delegate_accounts": [
                {"account_id": d.account_id, **_account_to_dict(d)}
                for d in self.delegate_accounts
            ],
        }
        path.write_text(json.dumps(data, indent=2))

    def get_account(self, account_id: str | None = None) -> AccountConfig:
        """Get account config by ID, or default."""
        aid = account_id or self.default_account
        if not aid or aid not in self.accounts:
            if len(self.accounts) == 1:
                return next(iter(self.accounts.values()))
            raise ValueError(f"No account found for '{aid}'. Configure one first.")
        return self.accounts[aid]
