"""Courier — AI-native email & calendar client over JMAP and CalDAV."""

__version__ = "0.5.2.1"
