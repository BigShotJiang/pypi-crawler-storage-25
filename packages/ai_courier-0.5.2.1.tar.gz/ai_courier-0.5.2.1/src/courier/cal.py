"""CalDAV calendar client with sane TZID handling.

Wraps python-caldav with timezone normalization, recurrence expansion,
and context-window-optimized output.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any
from zoneinfo import ZoneInfo

import caldav
from caldav.elements import dav

from .config import AccountConfig


@dataclass
class Event:
    """Context-window-optimized event representation."""

    uid: str
    summary: str
    start: datetime
    end: datetime
    location: str = ""
    description: str = ""
    attendees: list[str] = field(default_factory=list)
    organizer: str = ""
    status: str = ""  # CONFIRMED, TENTATIVE, CANCELLED
    is_recurring: bool = False
    recurrence_id: str | None = None
    calendar_name: str = ""
    raw_url: str = ""  # For mutations
    show_as: str = "busy"  # "busy" (TRANSP:OPAQUE) or "free" (TRANSP:TRANSPARENT)

    @property
    def duration_minutes(self) -> int:
        delta = self.end - self.start
        return int(delta.total_seconds() / 60)

    @property
    def is_all_day(self) -> bool:
        return (
            self.start.hour == 0 and self.start.minute == 0
            and self.end.hour == 0 and self.end.minute == 0
        )

    def summary_dict(self, local_tz: ZoneInfo | None = None) -> dict[str, Any]:
        """Token-efficient representation for context windows.

        If local_tz is provided, start/end are converted to that timezone
        for human-friendly output. Otherwise UTC is used.
        """
        start = self.start
        end = self.end
        if local_tz and not self.is_all_day:
            start = start.astimezone(local_tz)
            end = end.astimezone(local_tz)

        result: dict[str, Any] = {
            "uid": self.uid,
            "summary": self.summary,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "duration_min": self.duration_minutes,
        }
        if self.location:
            result["location"] = self.location
        if self.calendar_name:
            result["calendar"] = self.calendar_name
        if self.attendees:
            result["attendees"] = self.attendees
        if self.status and self.status != "CONFIRMED":
            result["status"] = self.status
        if self.is_all_day:
            result["all_day"] = True
        if self.show_as != "busy":
            result["show_as"] = self.show_as
        return result


class CalDAVClient:
    """CalDAV client with timezone normalization."""

    def __init__(self, account: AccountConfig):
        self.account = account
        self._client: caldav.DAVClient | None = None
        self._calendar_home: Any | None = None
        # Local timezone for output — defaults to America/Chicago (CT)
        self.local_tz: ZoneInfo = ZoneInfo(getattr(account, "timezone", "America/Chicago"))

    def connect(self) -> None:
        """Connect to CalDAV server.

        Fastmail rejects principal discovery (405 on PROPFIND). We connect
        the DAVClient to the calendar-home-set URL directly and build
        Calendar objects from a raw PROPFIND response.
        """
        url = self.account.caldav_url
        if not url and self.account.provider == "fastmail":
            url = f"https://caldav.fastmail.com/dav/calendars/user/{self.account.username}/"
        if not url:
            raise ValueError("No caldav_url configured and can't auto-detect for this provider")
        self._client = caldav.DAVClient(
            url=url,
            username=self.account.username,
            password=self.account.app_password,
        )
        # Discover calendars via raw PROPFIND (bypasses broken principal discovery)
        self._calendars = self._discover_calendars(url)

    def create_calendar(self, name: str) -> None:
        """Create a calendar collection on the principal.

        `name` becomes the displayname; the URL slug is derived via
        ``name.lower().replace(" ", "-")``, so name must be a plain ASCII
        string without slashes or punctuation (e.g. "Courier Tests").

        Idempotent at caller's level — raises if the name already exists.
        """
        self._ensure_connected()
        # Build a new calendar URL under the home
        home_url = self.account.caldav_url or (
            f"https://caldav.fastmail.com/dav/calendars/user/{self.account.username}/"
        )
        # Use a slug derived from name (lowercase, no spaces)
        slug = name.lower().replace(" ", "-")
        cal_url = f"{home_url.rstrip('/')}/{slug}/"
        # MKCALENDAR request
        body = (
            '<?xml version="1.0" encoding="utf-8"?>'
            '<c:mkcalendar xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
            '<d:set><d:prop>'
            f'<d:displayname>{name}</d:displayname>'
            '</d:prop></d:set>'
            '</c:mkcalendar>'
        )
        response = self._client.request(
            cal_url, method="MKCALENDAR", body=body,
            headers={"Content-Type": "application/xml"},
        )
        if response.status >= 400 and response.status != 201:
            raise RuntimeError(
                f"MKCALENDAR failed (status {response.status}) — "
                f"does {name!r} already exist?"
            )
        # Refresh cache
        self._calendars = self._discover_calendars(home_url)

    def _discover_calendars(self, home_url: str) -> list:
        """PROPFIND the calendar-home-set and build Calendar objects.

        Uses the DAVClient's raw PROPFIND + lxml tree (response.tree)
        to bypass python-caldav's broken principal discovery on Fastmail.
        """
        body = (
            '<?xml version="1.0"?>'
            '<d:propfind xmlns:d="DAV:">'
            '<d:prop><d:resourcetype/><d:displayname/></d:prop>'
            '</d:propfind>'
        )
        response = self._client.request(home_url, method="PROPFIND", body=body, headers={"Depth": "1"})

        if response.status >= 400:
            raise ConnectionError(
                f"CalDAV PROPFIND failed with status {response.status}. "
                f"Check app_password and caldav_url."
            )

        from lxml import etree
        root = response.tree
        if root is None:
            # Fallback: parse raw bytes
            raw = response._raw if isinstance(response._raw, bytes) else response._raw.encode()
            root = etree.XML(raw, parser=etree.XMLParser(recover=True))

        DAV = "DAV:"
        CALDAV = "urn:ietf:params:xml:ns:caldav"
        calendars = []
        for resp in root.findall(f"{{{DAV}}}response"):
            href = resp.findtext(f"{{{DAV}}}href", "")
            # Skip the home-set collection itself
            home_path = home_url.replace("https://caldav.fastmail.com", "").rstrip("/")
            if href.rstrip("/") == home_path:
                continue
            # Only include resources with <calendar/> in resourcetype
            rt = resp.find(f".//{{{DAV}}}resourcetype")
            if rt is not None and rt.find(f"{{{CALDAV}}}calendar") is not None:
                name = resp.findtext(f".//{{{DAV}}}displayname", "")
                cal_url = f"https://caldav.fastmail.com{href}" if href.startswith("/") else href
                cal = caldav.Calendar(client=self._client, url=cal_url, name=name)
                calendars.append(cal)
        return calendars

    def _ensure_connected(self) -> None:
        if not hasattr(self, '_calendars') or not self._calendars:
            self.connect()

    def _normalize_dt(self, dt: Any) -> datetime:
        """Normalize any datetime-like to timezone-aware UTC datetime."""
        if isinstance(dt, date) and not isinstance(dt, datetime):
            # All-day event — treat as midnight UTC
            return datetime(dt.year, dt.month, dt.day, tzinfo=timezone.utc)
        if isinstance(dt, datetime):
            if dt.tzinfo is None:
                # Naive datetime — assume UTC
                return dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        # String fallback
        return datetime.fromisoformat(str(dt)).astimezone(timezone.utc)

    def _parse_event(self, vevent: Any, calendar_name: str = "") -> Event:
        """Parse a vEvent into our optimized representation."""
        comp = vevent.vobject_instance.vevent

        start = self._normalize_dt(comp.dtstart.value)
        end = start  # Default
        if hasattr(comp, "dtend"):
            end = self._normalize_dt(comp.dtend.value)
        elif hasattr(comp, "duration"):
            end = start + comp.duration.value

        attendees = []
        if hasattr(comp, "attendee"):
            att_list = comp.attendee if isinstance(comp.attendee, list) else [comp.attendee]
            for att in att_list:
                addr = str(att.value).replace("mailto:", "").replace("MAILTO:", "")
                attendees.append(addr)

        organizer = ""
        if hasattr(comp, "organizer"):
            organizer = str(comp.organizer.value).replace("mailto:", "").replace("MAILTO:", "")

        # RFC 5545 §3.8.2.7: TRANSP defaults to OPAQUE when absent.
        transp = (
            str(comp.transp.value).upper() if hasattr(comp, "transp") else "OPAQUE"
        )
        show_as = "free" if transp == "TRANSPARENT" else "busy"

        return Event(
            uid=str(comp.uid.value) if hasattr(comp, "uid") else "",
            summary=str(comp.summary.value) if hasattr(comp, "summary") else "",
            start=start,
            end=end,
            location=str(comp.location.value) if hasattr(comp, "location") else "",
            description=str(comp.description.value) if hasattr(comp, "description") else "",
            attendees=attendees,
            organizer=organizer,
            status=str(comp.status.value) if hasattr(comp, "status") else "CONFIRMED",
            is_recurring=hasattr(comp, "rrule"),
            recurrence_id=str(comp.recurrence_id.value) if hasattr(comp, "recurrence_id") else None,
            calendar_name=calendar_name,
            raw_url=str(vevent.url) if hasattr(vevent, "url") else "",
            show_as=show_as,
        )

    # ── Query operations ─────────────────────────────────────────────

    def list_calendars(self) -> list[dict[str, str]]:
        """List available calendars."""
        self._ensure_connected()
        calendars = self._calendars
        return [{"name": c.name, "url": str(c.url)} for c in calendars]

    def get_events(
        self,
        start: datetime | date | None = None,
        end: datetime | date | None = None,
        calendar_name: str | None = None,
        expand_recurring: bool = True,
    ) -> list[Event]:
        """Get events in a date range. Recurrence expanded by default.

        If no range specified, defaults to today + 7 days.
        """
        self._ensure_connected()

        if start is None:
            start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        if end is None:
            end = self._normalize_dt(start) + timedelta(days=7)

        start = self._normalize_dt(start)
        end = self._normalize_dt(end)

        calendars = self._calendars
        if calendar_name:
            calendars = [c for c in calendars if c.name == calendar_name]

        events: list[Event] = []
        for cal in calendars:
            try:
                results = cal.date_search(
                    start=start, end=end, expand=expand_recurring
                )
                for vevent in results:
                    try:
                        events.append(self._parse_event(vevent, cal.name))
                    except Exception:
                        continue  # Skip malformed events
            except Exception:
                continue  # Skip inaccessible calendars

        # Deduplicate by (uid, recurrence_id) — same event appearing
        # in multiple calendars or via sync duplicates.
        events = self._deduplicate_events(events)

        # Sort chronologically
        events.sort(key=lambda e: e.start)
        return events

    @staticmethod
    def _deduplicate_events(events: list[Event]) -> list[Event]:
        """Remove duplicate events. Keeps first seen per (uid, recurrence_id)."""
        seen: dict[tuple[str, str], Event] = {}
        for e in events:
            if not e.uid:
                # No UID — can't deduplicate, keep it
                seen[(""  , id(e).__str__())] = e
                continue
            key = (e.uid, e.recurrence_id or "")
            if key not in seen:
                seen[key] = e
        return list(seen.values())

    def get_today(self) -> list[Event]:
        """Get today's events."""
        now = datetime.now(timezone.utc)
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        return self.get_events(start=start, end=end)

    def get_week(self) -> list[Event]:
        """Get this week's events (today through +7 days)."""
        return self.get_events()  # Default is 7 days

    def free_busy(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
        slot_minutes: int = 30,
        localize: bool = True,
        working_hours: tuple[int, int] | None = None,
        working_days: tuple[int, ...] = (0, 1, 2, 3, 4),  # Mon-Fri
    ) -> list[dict[str, Any]]:
        """Find free time slots in a date range.

        Returns list of free slots as {start, end, duration_min}.
        If localize=True, times are converted to self.local_tz.

        working_hours: (start_hour, end_hour) in local tz. Pass None to disable
          the constraint and return 24/7 gaps.
        working_days: weekday ints (Mon=0..Sun=6). Default Mon-Fri.
        """
        if start is None:
            start = datetime.now(timezone.utc)
        if end is None:
            end = start + timedelta(days=7)

        events = self.get_events(start=start, end=end)
        return self._free_slots_from_event_lists(
            event_lists=[events],
            start=start,
            end=end,
            slot_minutes=slot_minutes,
            local_tz=self.local_tz,
            working_hours=working_hours,
            working_days=working_days,
            localize=localize,
        )

    # ── v0.4.1: cross-account free/busy ─────────────────────────────────

    @staticmethod
    def free_busy_multi(
        clients: list[CalDAVClient],
        start: datetime | None = None,
        end: datetime | None = None,
        slot_minutes: int = 30,
        working_hours: tuple[int, int] | None = None,
        working_days: tuple[int, ...] = (0, 1, 2, 3, 4),
        localize: bool = True,
    ) -> list[dict[str, Any]]:
        """Find slots free across *all* given CalDAV clients (read-only).

        Each client fetches its own events; busy intervals are unioned across
        calendars; working-hours + day constraints apply to the merged result.
        """
        if not clients:
            raise ValueError("free_busy_multi requires at least one client")
        if start is None:
            start = datetime.now(timezone.utc)
        if end is None:
            end = start + timedelta(days=7)

        event_lists = [c.get_events(start=start, end=end) for c in clients]
        # Localize output to the first client's local_tz (typically the primary).
        local_tz = clients[0].local_tz if localize else timezone.utc
        return CalDAVClient._free_slots_from_event_lists(
            event_lists=event_lists,
            start=start,
            end=end,
            slot_minutes=slot_minutes,
            local_tz=local_tz,
            working_hours=working_hours,
            working_days=working_days,
            localize=localize,
        )

    @staticmethod
    def _free_slots_from_event_lists(
        event_lists: list[list[Event]],
        start: datetime,
        end: datetime,
        slot_minutes: int,
        local_tz,
        working_hours: tuple[int, int] | None,
        working_days: tuple[int, ...],
        localize: bool = True,
    ) -> list[dict[str, Any]]:
        """Pure function: union busy intervals from multiple event lists → free slots.

        Skips all-day events (never block free/busy) and transparent events
        (RFC 5545 §3.8.2.7: TRANSP:TRANSPARENT doesn't occupy the slot).
        Callable with a single-element list for single-account free/busy.
        """
        busy: list[tuple[datetime, datetime]] = []
        for events in event_lists:
            for e in events:
                if not e.is_all_day and e.show_as == "busy":
                    busy.append((e.start, e.end))
        return CalDAVClient._compute_free_slots(
            busy_intervals=busy,
            start=start,
            end=end,
            slot_minutes=slot_minutes,
            local_tz=local_tz,
            working_hours=working_hours,
            working_days=working_days,
            localize=localize,
        )

    @staticmethod
    def _compute_free_slots(
        busy_intervals: list[tuple[datetime, datetime]],
        start: datetime,
        end: datetime,
        slot_minutes: int,
        local_tz,
        working_hours: tuple[int, int] | None,
        working_days: tuple[int, ...],
        localize: bool = True,
    ) -> list[dict[str, Any]]:
        """Pure: busy intervals + constraints → free slots meeting min duration.

        Merges overlapping busy intervals, finds gaps in [start, end],
        optionally trims by working hours (per day in local_tz) and filters
        to working_days. Output is emitted in local_tz when localize=True,
        UTC otherwise.
        """
        busy = sorted(busy_intervals, key=lambda x: x[0])

        # Merge overlapping
        merged: list[tuple[datetime, datetime]] = []
        for b_start, b_end in busy:
            if merged and b_start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], b_end))
            else:
                merged.append((b_start, b_end))

        # Find raw gaps
        raw_gaps: list[tuple[datetime, datetime]] = []
        current = start
        for b_start, b_end in merged:
            if current < b_start:
                raw_gaps.append((current, b_start))
            current = max(current, b_end)
        if current < end:
            raw_gaps.append((current, end))

        # Split/trim gaps by working hours (local tz) and working days
        tz = local_tz if localize else timezone.utc
        constrained: list[tuple[datetime, datetime]] = []
        if working_hours is None:
            constrained = raw_gaps
        else:
            wh_start, wh_end = working_hours
            for g_start, g_end in raw_gaps:
                gs_local = g_start.astimezone(tz)
                ge_local = g_end.astimezone(tz)
                day = gs_local.date()
                while day <= ge_local.date():
                    if day.weekday() in working_days:
                        day_open = datetime.combine(
                            day, datetime.min.time(), tzinfo=tz
                        ).replace(hour=wh_start)
                        day_close = datetime.combine(
                            day, datetime.min.time(), tzinfo=tz
                        ).replace(hour=wh_end)
                        slot_s = max(gs_local, day_open)
                        slot_e = min(ge_local, day_close)
                        if slot_s < slot_e:
                            constrained.append((slot_s, slot_e))
                    day += timedelta(days=1)

        out_tz = local_tz if localize else None
        free: list[dict[str, Any]] = []
        for s_dt, e_dt in constrained:
            gap_minutes = int((e_dt - s_dt).total_seconds() / 60)
            if gap_minutes >= slot_minutes:
                s = s_dt.astimezone(out_tz) if out_tz else s_dt
                e = e_dt.astimezone(out_tz) if out_tz else e_dt
                free.append({
                    "start": s.isoformat(),
                    "end": e.isoformat(),
                    "duration_min": gap_minutes,
                })
        return free

    # ── Mutation operations ──────────────────────────────────────────

    def create_event(
        self,
        summary: str,
        start: datetime | date,
        end: datetime | date,
        calendar_name: str | None = None,
        location: str = "",
        description: str = "",
        attendees: list[str] | None = None,
        all_day: bool = False,
        show_as: str = "busy",
    ) -> Event:
        """Create a new calendar event.

        For all-day events, pass date objects (not datetime) or set all_day=True.
        All-day events use VALUE=DATE per RFC 5545 §3.6.1, with DTEND set to
        the day *after* the last day of the event.

        ``show_as`` controls free/busy transparency per RFC 5545 §3.8.2.7:
          - ``"busy"`` (default) emits ``TRANSP:OPAQUE`` — event occupies the
            slot in free/busy queries and renders as busy in calendar clients.
          - ``"free"`` emits ``TRANSP:TRANSPARENT`` — event appears on the
            calendar but the slot stays available in free/busy queries.
        Honored by Fastmail web, Apple Calendar, and every RFC-compliant
        CalDAV client.
        """
        if show_as not in ("busy", "free"):
            raise ValueError(
                f"show_as must be 'busy' or 'free' (got {show_as!r})"
            )
        self._ensure_connected()

        calendars = self._calendars
        cal = calendars[0]  # Default
        if calendar_name:
            for c in calendars:
                if c.name == calendar_name:
                    cal = c
                    break

        # Build iCalendar string
        attendee_lines = ""
        if attendees:
            for addr in attendees:
                attendee_lines += f"\nATTENDEE;RSVP=TRUE:mailto:{addr}"

        # Detect all-day: explicit flag, or both start/end are date (not datetime)
        is_all_day = all_day or (
            isinstance(start, date) and not isinstance(start, datetime)
            and isinstance(end, date) and not isinstance(end, datetime)
        )

        if is_all_day:
            # Coerce to date if datetime was passed
            start_date = start if isinstance(start, date) and not isinstance(start, datetime) else start.date() if isinstance(start, datetime) else start
            end_date = end if isinstance(end, date) and not isinstance(end, datetime) else end.date() if isinstance(end, datetime) else end
            # RFC 5545: DTEND is exclusive — a 1-day event on May 5 needs
            # DTEND:20260506. If start == end, bump end by 1 day.
            if end_date <= start_date:
                end_date = start_date + timedelta(days=1)
            dt_start_line = f"DTSTART;VALUE=DATE:{start_date.strftime('%Y%m%d')}"
            dt_end_line = f"DTEND;VALUE=DATE:{end_date.strftime('%Y%m%d')}"
        else:
            # Timed event — ensure datetime, normalize to UTC
            if isinstance(start, date) and not isinstance(start, datetime):
                start = datetime(start.year, start.month, start.day, tzinfo=timezone.utc)
            if isinstance(end, date) and not isinstance(end, datetime):
                end = datetime(end.year, end.month, end.day, tzinfo=timezone.utc)
            dt_start_line = f"DTSTART:{start.strftime('%Y%m%dT%H%M%SZ')}"
            dt_end_line = f"DTEND:{end.strftime('%Y%m%dT%H%M%SZ')}"

        transp_line = "TRANSP:TRANSPARENT" if show_as == "free" else "TRANSP:OPAQUE"

        ical = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Courier//AI-Native Calendar//EN
BEGIN:VEVENT
SUMMARY:{summary}
{dt_start_line}
{dt_end_line}
LOCATION:{location}
DESCRIPTION:{description}{attendee_lines}
STATUS:CONFIRMED
{transp_line}
END:VEVENT
END:VCALENDAR"""

        vevent = cal.save_event(ical)
        return self._parse_event(vevent, cal.name)

    def rsvp(self, event_uid: str, response: str) -> bool:
        """Respond to a calendar invite with ACCEPTED/TENTATIVE/DECLINED.

        Locates the event by UID across all calendars, rewrites the
        ``PARTSTAT`` parameter on the ``ATTENDEE`` line matching this
        account's email, and saves the event back. For recurring events,
        the master is updated — per-occurrence RSVP is v0.5.2 scope.

        Returns ``True`` on success. Raises ``ValueError`` if ``response``
        is not one of the three valid values, if the UID is not found,
        or if no ``ATTENDEE`` line matches the account email.

        **Known limitation (2026-04-21):** Fastmail does NOT auto-send an
        iTIP REPLY email to the organizer when PARTSTAT changes via CalDAV.
        This method updates the calendar entry only. The organizer will
        not see your response until either (a) v0.5.2's REPLY generator
        lands, or (b) you manually follow up via email. See
        ``tests/e2e/test_itip_reply_probe.py`` for the regression signal.
        """
        partstat = response.upper()
        if partstat not in ("ACCEPTED", "TENTATIVE", "DECLINED"):
            raise ValueError(
                "response must be accepted/tentative/declined "
                f"(got {response!r})"
            )

        self._ensure_connected()
        for cal in self._calendars:
            try:
                event = cal.event_by_uid(event_uid)
            except Exception:
                continue
            new_ical = self._update_partstat(
                event.data, self.account.username, partstat,
            )
            event.data = new_ical
            event.save()
            return True

        raise ValueError(f"Event not found: UID={event_uid}")

    @staticmethod
    def _update_partstat(ical_text: str, email: str, partstat: str) -> str:
        """Rewrite ``PARTSTAT`` on the ATTENDEE line matching ``email``.

        Pure string transform — testable without network. Case-insensitive
        email match. If the attendee has no existing ``PARTSTAT`` parameter,
        one is appended. Other ATTENDEE lines (and all non-ATTENDEE content)
        are preserved verbatim.

        Raises ``ValueError`` if no ATTENDEE line references ``email``.

        Limitation: does not unfold RFC 5545 §3.1 long-line continuations.
        If a real payload in the wild contains folded ATTENDEE lines we'll
        handle it then — better to fail loudly than paper over it.
        """
        mailto_token = f"mailto:{email.lower()}"
        lines = ical_text.split("\n")
        matched = False
        for i, line in enumerate(lines):
            # iCal lines use CRLF; preserve the trailing \r if present
            had_cr = line.endswith("\r")
            stripped = line.rstrip("\r")
            if not stripped.startswith("ATTENDEE"):
                continue
            if mailto_token not in stripped.lower():
                continue
            if ":" not in stripped:
                continue  # malformed — skip defensively
            prop_with_params, _, uri = stripped.partition(":")
            parts = prop_with_params.split(";")
            # parts[0] == "ATTENDEE"; parts[1:] are the parameters
            new_params: list[str] = []
            found_partstat = False
            for param in parts[1:]:
                if param.upper().startswith("PARTSTAT="):
                    new_params.append(f"PARTSTAT={partstat}")
                    found_partstat = True
                else:
                    new_params.append(param)
            if not found_partstat:
                new_params.append(f"PARTSTAT={partstat}")
            new_prop = parts[0]
            if new_params:
                new_prop += ";" + ";".join(new_params)
            new_line = f"{new_prop}:{uri}"
            if had_cr:
                new_line += "\r"
            lines[i] = new_line
            matched = True

        if not matched:
            raise ValueError(
                f"no ATTENDEE line matches {email!r} in the event iCal"
            )
        return "\n".join(lines)

    # ── v0.5.2.1: iTIP REPLY generator (Phase C.2) ─────────────────────

    @staticmethod
    def _extract_organizer_email(ical_text: str) -> str | None:
        """Extract the organizer's email from an ``ORGANIZER`` line.

        Handles both bare (``ORGANIZER:mailto:…``) and parameter-laden
        (``ORGANIZER;CN="Alice":mailto:…``) forms. Case-insensitive on
        the ``mailto:`` scheme. Returns ``None`` if no ORGANIZER present.
        """
        for line in ical_text.splitlines():
            line = line.rstrip("\r")
            if line.startswith("ORGANIZER:") or line.startswith("ORGANIZER;"):
                idx = line.lower().find("mailto:")
                if idx >= 0:
                    return line[idx + len("mailto:"):].strip()
        return None

    @staticmethod
    def _extract_event_summary(ical_text: str) -> str:
        """Extract the first SUMMARY line's value. Returns '' if absent."""
        for line in ical_text.splitlines():
            line = line.rstrip("\r")
            if line.startswith("SUMMARY:"):
                return line[len("SUMMARY:"):]
        return ""

    @staticmethod
    def _build_itip_reply(
        source_ical: str,
        attendee_email: str,
        partstat: str,
        now_iso: str | None = None,
    ) -> str:
        """Compose an iTIP REPLY VCALENDAR from the source event's iCal.

        Per RFC 5546, a REPLY carries exactly one ATTENDEE line — the
        responder's — with the new PARTSTAT. Other attendee entries are
        stripped. METHOD:REPLY is set at VCALENDAR level so receiving
        mail clients (Outlook, Google Calendar, Apple) auto-process it.

        Pure string transform — testable without network. ``now_iso``
        enables deterministic DTSTAMP in tests; production calls should
        leave it ``None`` to use current UTC.

        Raises ``ValueError`` on invalid ``partstat`` (not one of
        ACCEPTED/TENTATIVE/DECLINED), missing UID, or missing ORGANIZER.
        """
        if partstat not in ("ACCEPTED", "TENTATIVE", "DECLINED"):
            raise ValueError(
                "partstat must be ACCEPTED, TENTATIVE, or DECLINED "
                f"(got {partstat!r})"
            )

        fields: dict[str, str] = {}
        for raw in source_ical.splitlines():
            line = raw.rstrip("\r")
            if line.startswith("UID:"):
                fields["UID"] = line[len("UID:"):]
            elif line.startswith("ORGANIZER:") or line.startswith("ORGANIZER;"):
                fields["ORGANIZER"] = line
            elif line.startswith("SUMMARY:"):
                fields["SUMMARY"] = line[len("SUMMARY:"):]
            elif line.startswith("DTSTART:") or line.startswith("DTSTART;"):
                fields["DTSTART"] = line
            elif line.startswith("DTEND:") or line.startswith("DTEND;"):
                fields["DTEND"] = line
            elif line.startswith("SEQUENCE:"):
                fields["SEQUENCE"] = line[len("SEQUENCE:"):]

        uid = fields.get("UID", "")
        if not uid:
            raise ValueError("Source iCal missing UID — cannot build REPLY")
        organizer_line = fields.get("ORGANIZER", "")
        if not organizer_line:
            raise ValueError(
                "Source iCal missing ORGANIZER — no REPLY target"
            )

        if now_iso is None:
            now_iso = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

        out_lines = [
            "BEGIN:VCALENDAR",
            "PRODID:-//Courier//AI-Native Calendar//EN",
            "VERSION:2.0",
            "METHOD:REPLY",
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{now_iso}",
            organizer_line,
            f"ATTENDEE;PARTSTAT={partstat}:mailto:{attendee_email}",
        ]
        if "SUMMARY" in fields:
            out_lines.append(f"SUMMARY:{fields['SUMMARY']}")
        if "DTSTART" in fields:
            out_lines.append(fields["DTSTART"])
        if "DTEND" in fields:
            out_lines.append(fields["DTEND"])
        out_lines.append(f"SEQUENCE:{fields.get('SEQUENCE', '0')}")
        out_lines.extend(["END:VEVENT", "END:VCALENDAR"])
        return "\r\n".join(out_lines) + "\r\n"

    def _find_event_by_uid(self, uid: str):
        """Return ``(calendar, event)`` for a UID, or ``None`` if not found.

        Probes every connected calendar; ignores per-calendar lookup errors
        (missing UID in a calendar is expected, not exceptional).
        """
        self._ensure_connected()
        for cal in self._calendars:
            try:
                event = cal.event_by_uid(uid)
            except Exception:
                continue
            return (cal, event)
        return None

    def delete_event(self, uid: str) -> bool:
        """Delete an event by UID. Returns ``False`` if UID not found."""
        found = self._find_event_by_uid(uid)
        if not found:
            return False
        _cal, event = found
        event.delete()
        return True

    def move_event(self, uid: str, target_calendar_name: str) -> Event:
        """Move an event to a different calendar on the primary account.

        Finds the event by UID, saves its iCal into the target calendar,
        then deletes it from the source. Non-atomic: if the delete fails
        after the save succeeds, the event exists in both calendars; the
        caller is told explicitly so they can clean up manually.

        No-op when target matches the source (by URL). Returns the refetched
        ``Event`` from the target calendar.

        Raises ``ValueError`` if the UID isn't found on any connected
        calendar, or if ``target_calendar_name`` doesn't match any calendar's
        ``name``. Raises ``RuntimeError`` on partial-failure (saved to target
        but couldn't delete source) — message names both calendars and tells
        the caller what to clean up.
        """
        found = self._find_event_by_uid(uid)
        if not found:
            raise ValueError(f"Event not found: UID={uid}")
        source_cal, event = found

        target_cal = None
        for c in self._calendars:
            if c.name == target_calendar_name:
                target_cal = c
                break
        if target_cal is None:
            known = [c.name for c in self._calendars]
            raise ValueError(
                f"Target calendar not found: {target_calendar_name!r}. "
                f"Known calendars: {known}"
            )

        # No-op when target is the same calendar as source (URL compare).
        if str(source_cal.url) == str(target_cal.url):
            refetched = source_cal.event_by_uid(uid)
            return self._parse_event(refetched, source_cal.name)

        # Delete-then-save, not save-then-delete. Fastmail's CalDAV enforces
        # UID-uniqueness across calendars per user, so attempting to PUT an
        # event whose UID already exists in another calendar returns 403.
        # Save the iCal first so we can restore on rollback if the target
        # save fails.
        original_ical = event.data
        try:
            event.delete()
        except Exception as exc:
            raise RuntimeError(
                f"Failed to remove event {uid} from source "
                f"{source_cal.name!r} before moving: {exc}. "
                "No changes made."
            ) from exc

        try:
            target_cal.save_event(original_ical)
        except Exception as save_exc:
            # Rollback: restore to source so we don't lose the event.
            try:
                source_cal.save_event(original_ical)
            except Exception as restore_exc:
                raise RuntimeError(
                    f"Event {uid} LOST: deleted from source "
                    f"{source_cal.name!r} and save to target "
                    f"{target_calendar_name!r} failed ({save_exc!r}); "
                    f"restore to source also failed ({restore_exc!r}). "
                    "Recreate the event manually in Fastmail web."
                ) from save_exc
            raise RuntimeError(
                f"Failed to save event {uid} to target "
                f"{target_calendar_name!r}: {save_exc!r}. Source "
                f"{source_cal.name!r} has been restored."
            ) from save_exc

        refetched = target_cal.event_by_uid(uid)
        return self._parse_event(refetched, target_cal.name)

    def update_event(self, uid: str, **fields: Any) -> Event:
        """Update fields on an existing event. Returns the refetched Event.

        See ``_apply_update_to_ical`` for the list of supported fields.

        Recurring events: updates the master VEVENT only. If the stored
        event contains ``RRULE`` or ``RECURRENCE-ID``, a ``UserWarning`` is
        emitted — per-occurrence edits are v0.5.2 scope.

        Raises ``ValueError`` if the UID is not found on any connected
        calendar, or if any of ``fields`` is unsupported / invalid.
        """
        found = self._find_event_by_uid(uid)
        if not found:
            raise ValueError(f"Event not found: UID={uid}")
        cal, event = found

        if "RRULE:" in event.data or "RECURRENCE-ID" in event.data:
            import warnings
            warnings.warn(
                f"Event {uid} is recurring — update_event applies to the "
                "master only. Per-occurrence editing is v0.5.2 scope.",
                UserWarning,
                stacklevel=2,
            )

        new_ical = self._apply_update_to_ical(event.data, **fields)
        event.data = new_ical
        event.save()

        refetched = cal.event_by_uid(uid)
        return self._parse_event(refetched, cal.name)

    # ── v0.5: calendar_update ───────────────────────────────────────────

    @staticmethod
    def _format_dt_line(prop: str, value: date | datetime) -> str:
        """Format a DTSTART/DTEND iCal line.

        Datetime → ``PROP:YYYYMMDDTHHMMSSZ`` (UTC).
        Date (not datetime) → ``PROP;VALUE=DATE:YYYYMMDD`` per RFC 5545 §3.6.1.
        """
        if isinstance(value, datetime):
            return f"{prop}:{value.strftime('%Y%m%dT%H%M%SZ')}"
        if isinstance(value, date):
            return f"{prop};VALUE=DATE:{value.strftime('%Y%m%d')}"
        raise TypeError(
            f"{prop} expects datetime or date (got {type(value).__name__})"
        )

    @staticmethod
    def _apply_update_to_ical(ical_text: str, **fields: Any) -> str:
        """Rewrite VEVENT property lines per the given field overrides.

        Pure string transform — testable without network. Mirrors the
        line-preserving approach of ``_update_partstat``.

        Supported fields:
          ``summary``, ``location``, ``description`` (strings)
          ``show_as`` — ``"busy"`` → TRANSP:OPAQUE, ``"free"`` → TRANSP:TRANSPARENT
          ``start``, ``end`` — ``datetime`` (timed) or ``date`` (all-day)
          ``attendees`` — ``list[str]`` of email addresses; replaces existing set

        Unsupported fields or invalid ``show_as`` raise ``ValueError``.

        Limitation: does not unfold RFC 5545 §3.1 long-line continuations.
        If a real payload has folded property lines we'll handle it then —
        fail loudly beats paper-over.
        """
        supported = {
            "summary", "location", "description",
            "show_as", "start", "end", "attendees",
        }
        unknown = set(fields) - supported
        if unknown:
            raise ValueError(
                f"unsupported field(s): {sorted(unknown)}. "
                f"Supported: {sorted(supported)}"
            )
        if "show_as" in fields and fields["show_as"] not in ("busy", "free"):
            raise ValueError(
                f"show_as must be 'busy' or 'free' (got {fields['show_as']!r})"
            )

        # Reject CRLF in any user-controlled string — iCal uses line-oriented
        # encoding, so an unescaped newline could inject arbitrary properties.
        for _f in ("summary", "location", "description"):
            _v = fields.get(_f)
            if isinstance(_v, str) and ("\r" in _v or "\n" in _v):
                raise ValueError(
                    f"{_f!r} must not contain newlines (iCal injection risk)"
                )
        if "attendees" in fields:
            for _addr in fields["attendees"]:
                if "\r" in _addr or "\n" in _addr:
                    raise ValueError(
                        "attendee addresses must not contain newlines"
                    )

        attendees_param = fields.get("attendees")  # None means "don't touch"

        lines = ical_text.split("\n")
        out_lines: list[str] = []

        for line in lines:
            had_cr = line.endswith("\r")
            s = line.rstrip("\r")

            # Drop existing ATTENDEE lines when replacing the attendee set.
            if attendees_param is not None and s.startswith("ATTENDEE"):
                continue

            # Just before END:VEVENT, inject the new ATTENDEE set.
            if attendees_param is not None and s == "END:VEVENT":
                for addr in attendees_param:
                    new_att = f"ATTENDEE;RSVP=TRUE:mailto:{addr}"
                    out_lines.append(new_att + ("\r" if had_cr else ""))

            replaced: str | None = None
            if s.startswith("SUMMARY:") and "summary" in fields:
                replaced = f"SUMMARY:{fields['summary']}"
            elif s.startswith("LOCATION:") and "location" in fields:
                replaced = f"LOCATION:{fields['location']}"
            elif s.startswith("DESCRIPTION:") and "description" in fields:
                replaced = f"DESCRIPTION:{fields['description']}"
            elif s.startswith("TRANSP:") and "show_as" in fields:
                val = "TRANSPARENT" if fields["show_as"] == "free" else "OPAQUE"
                replaced = f"TRANSP:{val}"
            elif (s.startswith("DTSTART:") or s.startswith("DTSTART;")) and "start" in fields:
                replaced = CalDAVClient._format_dt_line("DTSTART", fields["start"])
            elif (s.startswith("DTEND:") or s.startswith("DTEND;")) and "end" in fields:
                replaced = CalDAVClient._format_dt_line("DTEND", fields["end"])

            if replaced is not None:
                out_lines.append(replaced + ("\r" if had_cr else ""))
            else:
                out_lines.append(line)

        result = "\n".join(out_lines)

        # Post-hoc consistency: DTSTART and DTEND must agree on timed/all-day.
        # A single-side update that changes type would produce a malformed event
        # (VALUE=DATE on one side, DATETIME on the other). Fail loudly.
        has_date_start = "DTSTART;VALUE=DATE" in result
        has_date_end = "DTEND;VALUE=DATE" in result
        if has_date_start != has_date_end:
            raise ValueError(
                "DTSTART and DTEND must both be all-day or both be timed. "
                "Update both start and end together when switching timing."
            )

        return result
