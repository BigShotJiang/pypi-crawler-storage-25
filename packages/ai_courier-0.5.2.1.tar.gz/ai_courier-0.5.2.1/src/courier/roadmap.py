"""Courier roadmap renderer — v0.5 PR D.

Reads:
  - ``CHANGELOG.md`` — shipped tools by version (parsed section-wise)
  - ``docs/roadmap-planned.yaml`` — editorial source for planned rows
  - ``src/courier/server.py`` — current ``TOOLS`` list for drift cross-check
  - ``pyproject.toml`` — current published version

Emits a markdown document suitable for ``Tech/Courier/courier-roadmap.md``.

Pure functions — no network. A separate follow-up may add ``gh`` issue
fetching for bug rows. This module is deliberately dependency-light; only
``pyyaml`` (already a core dep) is required at runtime.
"""
from __future__ import annotations

import ast
import re
import warnings
from pathlib import Path
from typing import Any

import yaml

# ── Parsers ─────────────────────────────────────────────────────────


def load_planned(path: Path) -> dict[str, Any]:
    """Parse ``docs/roadmap-planned.yaml`` into a normalized manifest.

    Returns a dict with keys ``releases`` (dict, possibly empty) and
    ``enhancements`` (list, possibly empty). Missing sections default
    to empty rather than raising.
    """
    text = Path(path).read_text()
    data = yaml.safe_load(text) or {}
    return {
        "releases": data.get("releases") or {},
        "enhancements": data.get("enhancements") or [],
    }


_SECTION_HEADER = re.compile(r"^## \[(?P<version>[\d.]+)\]\s*[—-]\s*(?P<date>[\d-]+)\s*$")
# Tools are bullets whose bold+backtick token contains a call signature:
# ``- **`name(...)`** — ...``. This filters out field names (``Email.blob_id``),
# parameter callouts (``show_as``), and CLI verbs (``courier sent``) which
# don't belong in the MCP-tools shipped list.
_TOOL_BULLET = re.compile(
    r"^-\s*\*\*`(?P<name>[a-z_][a-z0-9_]*)\s*\([^`]*\)`\*\*"
)


def parse_changelog(path: Path) -> list[dict[str, Any]]:
    """Walk ``CHANGELOG.md`` and return per-version entries.

    Each entry: ``{"version": str, "date": str, "tools": list[str]}``.
    ``tools`` are extracted from ``### Added`` bullets whose first bold
    backtick-wrapped token matches an identifier pattern — this catches
    ``- **`email_forward(args...)`** — forward``-style entries while
    ignoring prose-only bullets.

    Returns entries in the order they appear in the file (newest first
    by convention).
    """
    text = Path(path).read_text()
    lines = text.splitlines()

    entries: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    in_added = False

    for line in lines:
        header = _SECTION_HEADER.match(line)
        if header:
            if current is not None:
                entries.append(current)
            current = {
                "version": header.group("version"),
                "date": header.group("date"),
                "tools": [],
            }
            in_added = False
            continue

        if current is None:
            continue

        stripped = line.strip()
        # Track Added subsection; any other ### header ends it.
        if stripped.startswith("### "):
            in_added = stripped.lower().startswith("### added")
            continue

        if in_added:
            m = _TOOL_BULLET.match(stripped)
            if m:
                current["tools"].append(m.group("name"))

    if current is not None:
        entries.append(current)
    return entries


def current_tools_from_server_py(path: Path) -> set[str]:
    """AST-walk ``server.py`` and return the set of ``Tool(name=...)`` strings.

    Used for a drift cross-check against ``parse_changelog`` — if a tool
    appears in CHANGELOG but not here, either CHANGELOG is wrong or the
    tool was removed. Renderer warns via ``warnings.warn`` on mismatch.
    """
    tree = ast.parse(Path(path).read_text())
    names: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        # Match Tool(name="...") calls — identify by the callable name.
        called = node.func
        if isinstance(called, ast.Name) and called.id != "Tool":
            continue
        if isinstance(called, ast.Attribute) and called.attr != "Tool":
            continue
        for kw in node.keywords:
            if kw.arg == "name" and isinstance(kw.value, ast.Constant):
                if isinstance(kw.value.value, str):
                    names.add(kw.value.value)
    return names


# ── Renderer ────────────────────────────────────────────────────────


_BANNER = """> 🤖 Auto-generated from `~/Repos/courier`. Don't hand-edit — a launchd
> agent sweeps this file like a Roomba every 15 minutes, and your edits
> will end up in the dust bin along with the cheerios. Instead:
> - Planned rows → edit `docs/roadmap-planned.yaml`
> - Shipped rows → update `CHANGELOG.md` (you do this per release anyway)
> - Bugs / enhancements → [open or close a GitHub issue](https://github.com/iamdadzilla/courier/issues)
>
> Last regenerated: {timestamp}"""


def render_markdown(
    changelog: list[dict[str, Any]],
    planned: dict[str, Any],
    current_tools: set[str],
    current_version: str,
    timestamp: str,
) -> str:
    """Render the full roadmap markdown.

    - Banner at the top (Roomba callback per `courier design discussions.md`).
    - Shipped section driven by ``changelog`` entries.
    - Planned section driven by ``planned.releases``; features already in
      ``changelog`` are dropped to avoid duplication.
    - Enhancements section driven by ``planned.enhancements``.
    - Drift warnings (via ``warnings.warn``) for CHANGELOG tools missing
      from ``current_tools``.
    """
    shipped_tools: set[str] = set()
    for entry in changelog:
        for t in entry["tools"]:
            shipped_tools.add(t)
            if t not in current_tools:
                warnings.warn(
                    f"drift: CHANGELOG mentions {t!r} but server.py TOOLS does not "
                    f"include it. Either remove from CHANGELOG or re-register the tool.",
                    UserWarning,
                    stacklevel=2,
                )

    lines: list[str] = []
    lines.append(_BANNER.format(timestamp=timestamp))
    lines.append("")
    lines.append(f"# Courier MCP — Feature Roadmap (v{current_version})")
    lines.append("")

    # Shipped
    lines.append("## Shipped")
    lines.append("")
    if not changelog:
        lines.append("_(No shipped versions yet.)_")
        lines.append("")
    else:
        lines.append("| Version | Date | Tools |")
        lines.append("|---------|------|-------|")
        for entry in changelog:
            tools = ", ".join(f"`{t}`" for t in entry["tools"]) or "_(no new tools)_"
            lines.append(f"| ✅ v{entry['version']} | {entry['date']} | {tools} |")
        lines.append("")

    # Planned
    lines.append("## Planned")
    lines.append("")
    releases = planned.get("releases") or {}
    if not releases:
        lines.append("_(No planned releases.)_")
        lines.append("")
    else:
        for version, rel in releases.items():
            theme = rel.get("theme", "")
            target = rel.get("target", "")
            lines.append(f"### 📋 {version} — {theme}")
            if target:
                lines.append(f"_Target: {target}_")
            lines.append("")
            features = rel.get("features") or []
            rendered_features: list[str] = []
            for feat in features:
                tool = feat.get("tool")
                label = feat.get("label") or tool or "(unnamed)"
                # Drop duplicates already in Shipped.
                if tool and tool in shipped_tools:
                    continue
                notes = feat.get("notes", "")
                area = feat.get("area", "")
                parts = [f"- **{label}**"]
                if area:
                    parts.append(f"({area})")
                if notes:
                    parts.append(f"— {notes}")
                rendered_features.append(" ".join(parts))
            if rendered_features:
                lines.extend(rendered_features)
            else:
                lines.append("_(all features now shipped)_")
            lines.append("")

    # Enhancements
    enhancements = planned.get("enhancements") or []
    if enhancements:
        lines.append("## Open Enhancements")
        lines.append("")
        for enh in enhancements:
            label = enh.get("label") or enh.get("tool") or "(unnamed)"
            area = enh.get("area", "")
            issue = enh.get("issue")
            parts = [f"- 💡 **{label}**"]
            if area:
                parts.append(f"({area})")
            if issue:
                parts.append(
                    f"— [#{issue}](https://github.com/iamdadzilla/courier/issues/{issue})"
                )
            lines.append(" ".join(parts))
        lines.append("")

    return "\n".join(lines)


# ── Orchestration ───────────────────────────────────────────────────


def render_from_repo(repo_root: Path, timestamp: str) -> str:
    """Convenience: render the roadmap by reading all sources from ``repo_root``.

    Expects the standard Courier layout (``CHANGELOG.md``,
    ``docs/roadmap-planned.yaml``, ``src/courier/server.py``,
    ``pyproject.toml`` at ``repo_root``).
    """
    import tomllib

    changelog = parse_changelog(repo_root / "CHANGELOG.md")
    planned = load_planned(repo_root / "docs" / "roadmap-planned.yaml")
    current_tools = current_tools_from_server_py(
        repo_root / "src" / "courier" / "server.py"
    )
    pyproject = tomllib.loads((repo_root / "pyproject.toml").read_text())
    current_version = pyproject["project"]["version"]

    return render_markdown(
        changelog=changelog,
        planned=planned,
        current_tools=current_tools,
        current_version=current_version,
        timestamp=timestamp,
    )
