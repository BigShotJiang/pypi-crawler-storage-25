"""CLI verb tests. Network-free — prompts and file I/O only."""

from __future__ import annotations

from argparse import Namespace

from courier import cli
from courier import config as config_module
from courier.config import AccountConfig, CourierConfig


class TestAddDelegate:
    """`courier add-delegate` appends a read-only calendar account to config."""

    async def test_appends_delegate_to_existing_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config_module, "DEFAULT_CONFIG_DIR", tmp_path)

        # Seed a primary account so load() has something non-empty.
        existing = CourierConfig(
            accounts={
                "fastmail": AccountConfig(
                    account_id="fastmail",
                    provider="fastmail",
                    api_token="primary-token",
                    username="jim@example.com",
                ),
            },
            default_account="fastmail",
        )
        existing.save(tmp_path / "config.json")

        # Feed prompts: account_id then email via input(); app password via getpass().
        inputs = iter(["richard", "richard@example.com"])
        monkeypatch.setattr("builtins.input", lambda *_, **__: next(inputs))
        monkeypatch.setattr("getpass.getpass", lambda *_, **__: "pw-richard")

        await cli.cmd_add_delegate(Namespace())

        loaded = CourierConfig.load(tmp_path / "config.json")
        assert len(loaded.delegate_accounts) == 1
        d = loaded.delegate_accounts[0]
        assert d.account_id == "richard"
        assert d.username == "richard@example.com"
        assert d.app_password == "pw-richard"
        assert d.provider == "fastmail"
        # Primary account untouched.
        assert "fastmail" in loaded.accounts
        assert loaded.default_account == "fastmail"

    async def test_appends_without_overwriting_existing_delegate(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config_module, "DEFAULT_CONFIG_DIR", tmp_path)

        existing = CourierConfig(
            accounts={
                "fastmail": AccountConfig(
                    account_id="fastmail", provider="fastmail", api_token="t",
                ),
            },
            default_account="fastmail",
            delegate_accounts=[
                AccountConfig(
                    account_id="linda",
                    provider="fastmail",
                    api_token="",
                    app_password="pw-l",
                    username="linda@example.com",
                ),
            ],
        )
        existing.save(tmp_path / "config.json")

        inputs = iter(["richard", "richard@example.com"])
        monkeypatch.setattr("builtins.input", lambda *_, **__: next(inputs))
        monkeypatch.setattr("getpass.getpass", lambda *_, **__: "pw-richard")

        await cli.cmd_add_delegate(Namespace())

        loaded = CourierConfig.load(tmp_path / "config.json")
        assert [d.account_id for d in loaded.delegate_accounts] == ["linda", "richard"]
