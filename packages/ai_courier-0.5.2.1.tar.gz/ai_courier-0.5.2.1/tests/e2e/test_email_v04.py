"""v0.4 new tools E2E."""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

import pytest


@pytest.mark.asyncio
async def test_email_sent_since_roundtrip(live_jmap, self_sent_email):
    """list_sent finds a freshly self-sent message in the Sent mailbox."""
    after = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )

    # The inbox copy arrives first via the self_sent_email fixture's poll;
    # the Sent copy follows shortly, but Fastmail's Email/query indexing
    # against the Sent mailbox lags further than delivery to Inbox — match
    # the fixture's 30s budget.
    found = None
    for _ in range(30):
        results = await live_jmap.list_sent(after=after, limit=20)
        for e in results:
            if e.subject == self_sent_email.subject:
                found = e
                break
        if found:
            break
        await asyncio.sleep(1)

    assert found is not None, (
        f"list_sent did not surface {self_sent_email.subject!r} within 30s"
    )
    # Sanity: the sent copy is a distinct JMAP Email from the inbox copy.
    assert found.id != self_sent_email.id


@pytest.mark.asyncio
async def test_email_thread_digest(live_jmap, self_sent_email):
    """build_thread_digest returns a 2-message thread with quotes stripped."""
    # Reply (send=True, include_quote=True) to create a second message in the
    # thread and force a "> quoted" block into the reply body.
    reply_marker = "reply-body-marker-XYZ"
    result = await live_jmap.reply_to(
        email_id=self_sent_email.id,
        body=reply_marker,
        send=True,
        include_quote=True,
    )
    assert result["status"] == "sent"

    # Poll for the reply to appear in the thread (up to ~30s).
    digest = None
    for _ in range(30):
        digest = await live_jmap.build_thread_digest(
            thread_id=self_sent_email.thread_id
        )
        if digest["message_count"] >= 2:
            break
        await asyncio.sleep(1)

    assert digest is not None and digest["message_count"] >= 2, (
        f"Reply did not join thread within 30s: {digest}"
    )
    # Find the reply message (the one containing our marker)
    reply_msgs = [m for m in digest["messages"] if reply_marker in m["body"]]
    assert reply_msgs, "Reply marker missing from digest"
    reply_body = reply_msgs[0]["body"]
    # Quote block should be stripped
    assert "wrote:" not in reply_body
    assert "> " not in reply_body
    # Original marker shouldn't bleed through as quoted content in the reply
    assert "E2E marker" not in reply_body

    # Cleanup: trash the reply's sent copy and its inbox copy (self-send).
    # Poll for the inbox copy — indexing lag can exceed a single search
    # round-trip (observed up to ~20s on Fastmail for self-sends). Match the
    # fixture's 30s budget so a slow Inbox copy doesn't leak into the account.
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    reply_subject = "Re: " + self_sent_email.subject
    inbox_copies: list = []
    for _ in range(30):
        inbox_copies = await live_jmap.search_emails(
            subject=reply_subject, mailbox_id=inbox_id, limit=5,
        )
        if inbox_copies:
            break
        await asyncio.sleep(1)
    to_trash = [result["id"]] + [e.id for e in inbox_copies]
    try:
        await live_jmap.trash(to_trash)
    except Exception:
        pass


@pytest.mark.asyncio
async def test_email_forward_roundtrip(live_jmap, self_sent_email, live_config):
    """forward re-attaches the original as a .eml and arrives intact."""
    account = live_config.get_account()
    result = await live_jmap.forward(
        email_id=self_sent_email.id,
        to=[account.username],
        body="forward cover note",
        include_original=True,
        send=True,
    )
    assert result["status"] == "sent"

    # Poll inbox for the forwarded copy (subject starts with Fwd:).
    fwd_subject = "Fwd: " + self_sent_email.subject
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    received = None
    for _ in range(30):
        hits = await live_jmap.search_emails(
            subject=fwd_subject, mailbox_id=inbox_id, limit=5,
        )
        if hits:
            received = hits[0]
            break
        await asyncio.sleep(1)
    assert received is not None, (
        f"Forwarded message {fwd_subject!r} did not arrive in 30s"
    )
    # Fetch full so attachments are populated
    full = await live_jmap.get_email(received.id)
    eml_attachments = [
        a for a in full.attachments if a.type == "message/rfc822"
    ]
    assert eml_attachments, (
        f"Expected a .eml attachment; got {[a.type for a in full.attachments]}"
    )
    eml = eml_attachments[0]
    # Size should be in the same order of magnitude as the original.
    # self_sent_email.size is the original's MIME size; Fastmail re-encodes so
    # sizes may differ modestly (~10%). Use a loose lower bound only.
    assert eml.size > 0

    # Cleanup: trash the forward's inbox + sent copies.
    to_trash = [result["id"], received.id]
    try:
        await live_jmap.trash(to_trash)
    except Exception:
        pass
