"""v0.4.1 calendar E2E — cross-account free/busy against a live delegate.

Requires both COURIER_LIVE_TESTS=1 (network) and a configured delegate
(``courier add-delegate``). These tests do NOT write to the delegate's
calendar — they read busy blocks and verify the merge produces the
right shape. Sandbox-based write tests can be added once a "Courier
Tests" calendar exists on the delegate's account.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

import pytest

from courier.cal import CalDAVClient
from courier.config import CourierConfig

DELEGATE_CONFIGURED = os.environ.get("COURIER_DELEGATE_CONFIGURED") == "1"

pytestmark = pytest.mark.skipif(
    not DELEGATE_CONFIGURED,
    reason="Set COURIER_DELEGATE_CONFIGURED=1 and configure a delegate with `courier add-delegate`",
)


@pytest.fixture(scope="session")
def live_config_with_delegate() -> CourierConfig:
    cfg = CourierConfig.load()
    if not cfg.accounts:
        pytest.skip("No primary account — run `courier setup`")
    if not cfg.delegate_accounts:
        pytest.skip("No delegate accounts — run `courier add-delegate`")
    return cfg


@pytest.fixture(scope="session")
def live_multi_clients(live_config_with_delegate) -> list[CalDAVClient]:
    """One CalDAVClient per configured account (primary + delegates)."""
    clients: list[CalDAVClient] = []
    primary = CalDAVClient(live_config_with_delegate.get_account())
    primary.connect()
    clients.append(primary)
    for d in live_config_with_delegate.delegate_accounts:
        c = CalDAVClient(d)
        c.connect()
        clients.append(c)
    return clients


def test_free_busy_multi_shape(live_multi_clients):
    """free_busy_multi across primary + delegate returns a well-shaped slot list."""
    # Query tomorrow 24h to get a stable-ish window.
    tomorrow = (
        datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        + timedelta(days=1)
    )
    slots = CalDAVClient.free_busy_multi(
        clients=live_multi_clients,
        start=tomorrow,
        end=tomorrow + timedelta(days=1),
        slot_minutes=30,
        working_hours=(9, 17),
        localize=False,
    )
    assert isinstance(slots, list)
    for s in slots:
        assert set(s.keys()) == {"start", "end", "duration_min"}
        assert s["duration_min"] >= 30


def test_free_busy_multi_stricter_than_single_account(live_multi_clients):
    """The union of busy intervals can only shrink free slots vs. one account alone.

    Assertion: free_busy_multi over N>=2 clients returns ≤ the free total minutes
    of free_busy over any single client. (The delegate adds busy, never subtracts.)
    """
    if len(live_multi_clients) < 2:
        pytest.skip("Need at least 2 clients to compare")

    start = (
        datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        + timedelta(days=1)
    )
    end = start + timedelta(days=1)

    multi = CalDAVClient.free_busy_multi(
        clients=live_multi_clients,
        start=start, end=end,
        slot_minutes=15,
        working_hours=(9, 17),
        localize=False,
    )
    primary_only = live_multi_clients[0].free_busy(
        start=start, end=end,
        slot_minutes=15,
        working_hours=(9, 17),
        localize=False,
    )

    multi_total = sum(s["duration_min"] for s in multi)
    primary_total = sum(s["duration_min"] for s in primary_only)
    assert multi_total <= primary_total, (
        f"Multi-account free total ({multi_total}min) should be ≤ primary-only "
        f"total ({primary_total}min) — delegate only adds busy."
    )
