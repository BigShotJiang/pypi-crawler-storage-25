"""v0.5.1 E2E — email_inbox payload size stays under the overflow bar.

Incident 2026-04-22: full-body inbox payload overflowed Cowork's
inline-read budget, silently clipping the sweep to 2 emails. Fix was to
change `email_inbox`'s default from 500-char bodies to 200-char
snippets, and add an opt-in body_mode="none" for when even snippets
are too much.

This test is a regression signal: if a future change grows the payload
back past ~40 KB for a 50-email inbox, this fails and someone has to
re-read the incident post-mortem before shipping.
"""
from __future__ import annotations

import json

import pytest


@pytest.mark.asyncio
async def test_email_inbox_snippet_mode_payload_under_threshold(live_jmap):
    """50-email inbox in snippet mode stays under 40 KB serialized JSON."""
    emails = await live_jmap.list_emails(limit=50)
    if len(emails) < 10:
        pytest.skip(f"Need >=10 emails to measure; have {len(emails)}")

    total = sum(
        len(json.dumps({**e.summary(max_body=200), "triage_reason": "fyi"}))
        for e in emails
    )
    threshold = 40_000
    assert total <= threshold, (
        f"Snippet-mode payload {total:,} bytes for {len(emails)} emails "
        f"exceeds {threshold:,}-byte threshold. The default max_body=200 "
        f"in Email.summary() was supposed to keep this bounded; either "
        f"bodies grew, or the default regressed. See incident-2026-04-22-"
        f"inbox-overflow.md."
    )


@pytest.mark.asyncio
async def test_email_inbox_none_mode_omits_body(live_jmap):
    """body_mode='none' => no 'body' key in any summary; payload < snippet."""
    emails = await live_jmap.list_emails(limit=10)
    if not emails:
        pytest.skip("No emails in inbox")

    for e in emails:
        s = e.summary(include_body=False)
        assert "body" not in s, f"Expected no 'body' key; got: {list(s.keys())}"

    none_total = sum(
        len(json.dumps(e.summary(include_body=False))) for e in emails
    )
    snippet_total = sum(
        len(json.dumps(e.summary(max_body=200))) for e in emails
    )
    assert none_total < snippet_total, (
        f"none-mode payload ({none_total}) should be smaller than snippet "
        f"({snippet_total}) - bodies should actually drop out."
    )
