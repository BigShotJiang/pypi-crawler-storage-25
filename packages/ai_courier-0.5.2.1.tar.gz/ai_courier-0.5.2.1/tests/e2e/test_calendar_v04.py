"""v0.4 calendar E2E — RSVP round-trip."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone


def _sandbox_calendar_obj(live_caldav, sandbox_calendar):
    """Resolve the underlying caldav.Calendar for the sandbox dict.

    Copy of the helper in test_calendar_v02.py — kept local so v0.4 tests
    don't couple to v0.2 test layout.
    """
    from urllib.parse import unquote, urlparse

    def _norm(raw: str) -> tuple[str, str, str]:
        u = urlparse(raw)
        host = (u.hostname or "").lower()
        path = unquote(u.path or "").rstrip("/")
        return (u.scheme.lower(), host, path)

    target = _norm(sandbox_calendar["url"])
    for cal in live_caldav._calendars:
        if _norm(str(cal.url)) == target:
            return cal
    raise RuntimeError(
        f"Sandbox calendar at {sandbox_calendar['url']!r} not found"
    )


def _tomorrow() -> datetime:
    return datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0,
    ) + timedelta(days=1)


def test_calendar_rsvp_sets_partstat(live_caldav, sandbox_calendar, live_config):
    """rsvp updates PARTSTAT on the ATTENDEE line matching our email."""
    account = live_config.get_account()
    start = _tomorrow() + timedelta(hours=14)
    end = start + timedelta(hours=1)

    event = live_caldav.create_event(
        summary="[courier-e2e] rsvp",
        start=start,
        end=end,
        calendar_name="Courier Tests",
        attendees=[account.username],
    )
    cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
    try:
        # Sanity: the attendee is present with no PARTSTAT yet (implicit
        # NEEDS-ACTION per RFC 5545 §3.2.12)
        pre = cal_obj.event_by_url(event.raw_url).data
        assert f"mailto:{account.username}" in pre

        ok = live_caldav.rsvp(event.uid, "accepted")
        assert ok is True

        # Re-fetch and verify PARTSTAT=ACCEPTED landed on our line
        post = cal_obj.event_by_url(event.raw_url).data
        # Partial-match is robust across param orderings
        assert "PARTSTAT=ACCEPTED" in post, (
            f"PARTSTAT=ACCEPTED not found in round-tripped iCal:\n{post}"
        )
        # And it should be on the line that targets our email specifically
        our_line = None
        for line in post.splitlines():
            if line.startswith("ATTENDEE") and account.username in line:
                our_line = line
                break
        assert our_line is not None, "ATTENDEE line for self not found after RSVP"
        assert "PARTSTAT=ACCEPTED" in our_line, (
            f"ATTENDEE line missing PARTSTAT=ACCEPTED: {our_line!r}"
        )
    finally:
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass
