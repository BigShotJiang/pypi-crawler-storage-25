"""v0.5.2 E2E — HTML email body round-trip against live Fastmail.

Sends a self-addressed HTML email, fetches it from Inbox, and verifies
both the HTML body and the auto-generated plain-text fallback survive
the round trip. Ensures multipart/alternative semantics are written
correctly on the way out and parsed correctly on the way in.
"""
from __future__ import annotations

import asyncio
import uuid
import warnings


async def test_send_html_roundtrip(live_jmap, live_config):
    """HTML body lands in htmlBody; plain fallback lands in textBody."""
    account = live_config.get_account()
    marker = uuid.uuid4().hex
    subject = f"[courier-e2e-html] {marker}"
    to = [{"name": "Self", "email": account.username}]

    html_body = (
        "<p>Hello <strong>world</strong>!</p>"
        f"<p>Marker: {marker}</p>"
        '<p><a href="https://example.com">Example link</a></p>'
        "<ul><li>one</li><li>two</li></ul>"
    )

    sent_id = await live_jmap.send_email(
        to=to,
        subject=subject,
        body=html_body,
        content_type="text/html",
    )

    # Poll INBOX for the message
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    received = None
    for _ in range(30):
        emails = await live_jmap.search_emails(
            subject=subject, mailbox_id=inbox_id, limit=5,
        )
        if emails:
            received = emails[0]
            break
        await asyncio.sleep(1)

    if not received:
        try:
            await live_jmap.trash([sent_id])
        except Exception:
            pass
        raise RuntimeError(f"Self-sent HTML email {subject!r} did not arrive within 30s")

    try:
        # The plain-text fallback is what ends up in body_text (text/plain part).
        # Must contain the marker and the stripped link/list content.
        assert marker in received.body_text
        assert "Hello" in received.body_text
        assert "world" in received.body_text
        # HTML tags must have been stripped from text body
        assert "<strong>" not in received.body_text
        # Auto-generated text fallback should preserve the link URL in parens
        assert "https://example.com" in received.body_text
        # List items become dash bullets in the fallback
        assert "- one" in received.body_text or "one" in received.body_text
    finally:
        try:
            await live_jmap.trash([received.id, sent_id])
        except Exception as exc:
            warnings.warn(f"Teardown failed: {exc}", stacklevel=1)


async def test_send_plain_unchanged(live_jmap, live_config):
    """Default content_type='text/plain' is byte-identical to pre-v0.5.2 behavior.

    Regression guard: adding the content_type parameter shouldn't change
    what plain-text sends look like on the wire.
    """
    account = live_config.get_account()
    marker = uuid.uuid4().hex
    subject = f"[courier-e2e-plain] {marker}"
    to = [{"name": "Self", "email": account.username}]

    plain_body = f"Plain marker: {marker}\n"

    # No content_type arg — exercises the default path
    sent_id = await live_jmap.send_email(to=to, subject=subject, body=plain_body)

    inbox_id = await live_jmap.get_mailbox_id("inbox")
    received = None
    for _ in range(30):
        emails = await live_jmap.search_emails(
            subject=subject, mailbox_id=inbox_id, limit=5,
        )
        if emails:
            received = emails[0]
            break
        await asyncio.sleep(1)

    if not received:
        try:
            await live_jmap.trash([sent_id])
        except Exception:
            pass
        raise RuntimeError(f"Self-sent plain email {subject!r} did not arrive within 30s")

    try:
        assert marker in received.body_text
        # No HTML tags whatsoever — nothing was converted.
        assert "<p>" not in received.body_text
    finally:
        try:
            await live_jmap.trash([received.id, sent_id])
        except Exception as exc:
            warnings.warn(f"Teardown failed: {exc}", stacklevel=1)
