"""v0.5.2.1 — iTIP REPLY E2E.

Pre-v0.5.2.1 behavior: Fastmail's CalDAV did not auto-send an iTIP REPLY
on PARTSTAT change, so `calendar_rsvp` was half-complete — Jim's local
calendar reflected his response but external organizers never found out.

Phase C.2 (v0.5.2.1) closes that gap: Courier now builds and sends the
REPLY itself via the `_rsvp_with_notification` orchestrator. This test
asserts the new reality: after `calendar_rsvp`, the organizer gets an
email with a `text/calendar; method=REPLY` attachment carrying the
updated PARTSTAT.

The test waits ~30s for Fastmail to index the newly-sent email. Don't
shorten below 15s without checking issue #14 (Fastmail indexing lag).
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from uuid import uuid4

import pytest

from courier.server import _rsvp_with_notification


@pytest.mark.asyncio
async def test_calendar_rsvp_sends_itip_reply_to_organizer(
    live_caldav, live_jmap, live_config,
):
    """After RSVP, an email with METHOD:REPLY iCal lands in Sent addressed to the organizer."""
    account = live_config.get_account()
    primary_email = account.username  # jim@hi-team.net

    # Organizer is a distinct alias Jim controls (+-alias stays within account).
    organizer_email = (
        f"{primary_email.split('@')[0]}+itip-probe@{primary_email.split('@')[1]}"
    )

    uid = f"courier-e2e-itip-reply-{uuid4().hex[:8]}"
    start = (datetime.now(timezone.utc) + timedelta(days=2)).replace(
        hour=14, minute=0, second=0, microsecond=0,
    )
    end = start + timedelta(hours=1)

    # Hand-construct an "external organizer invited me" event on Jim's calendar.
    ical = (
        "BEGIN:VCALENDAR\r\n"
        "VERSION:2.0\r\n"
        "PRODID:-//Courier//iTIP Probe//EN\r\n"
        "METHOD:REQUEST\r\n"
        "BEGIN:VEVENT\r\n"
        f"UID:{uid}\r\n"
        "SUMMARY:[courier-e2e] iTIP reply test\r\n"
        f"DTSTART:{start.strftime('%Y%m%dT%H%M%SZ')}\r\n"
        f"DTEND:{end.strftime('%Y%m%dT%H%M%SZ')}\r\n"
        f"ORGANIZER:mailto:{organizer_email}\r\n"
        f"ATTENDEE;RSVP=TRUE:mailto:{primary_email}\r\n"
        "STATUS:CONFIRMED\r\n"
        "TRANSP:OPAQUE\r\n"
        "END:VEVENT\r\n"
        "END:VCALENDAR\r\n"
    )

    target_cal = None
    for c in live_caldav._calendars:
        if c.name == "Courier Tests":
            target_cal = c
            break
    assert target_cal is not None, "Sandbox 'Courier Tests' calendar missing"
    target_cal.save_event(ical)

    try:
        # Snapshot Sent state just before RSVP.
        snapshot_iso = (
            datetime.now(timezone.utc) - timedelta(seconds=5)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
        before = await live_jmap.list_sent(after=snapshot_iso, limit=20)
        before_ids = {e.id for e in before}

        # Call the orchestrator that calendar_rsvp MCP tool uses.
        result = await _rsvp_with_notification(
            cal=live_caldav,
            jmap=live_jmap,
            event_uid=uid,
            response="accepted",
            notify_organizer=True,
        )

        assert result["ok"] is True
        assert result["notify_status"] == "sent", (
            f"Expected notify_status='sent', got {result.get('notify_status')!r}. "
            f"Full result: {result}"
        )
        assert result["notified_organizer"] == organizer_email
        assert result.get("reply_email_id")

        # Wait for Fastmail to index the send.
        await asyncio.sleep(30)

        # Find the matching message in Sent — addressed to organizer.
        after_messages = await live_jmap.list_sent(after=snapshot_iso, limit=20)
        new_to_organizer = [
            m for m in after_messages
            if m.id not in before_ids
            and any(
                organizer_email.lower() in (t or "").lower()
                for t in (m.to or [])
            )
        ]
        assert new_to_organizer, (
            f"No Sent message to organizer {organizer_email!r} found after RSVP. "
            "Orchestrator reported notify_status='sent' but the message "
            f"didn't land in Sent within 30s. new sent count: "
            f"{len([m for m in after_messages if m.id not in before_ids])}"
        )

        reply_msg = new_to_organizer[0]
        assert reply_msg.subject.lower().startswith("accepted"), (
            f"Subject {reply_msg.subject!r} should begin with 'Accepted:'"
        )
        assert "iTIP reply test" in reply_msg.subject

    finally:
        live_caldav.delete_event(uid)
        try:
            after_messages = await live_jmap.list_sent(after=snapshot_iso, limit=20)
            cleanup_ids = [
                m.id for m in after_messages
                if m.id not in before_ids
                and "iTIP reply test" in (m.subject or "")
            ]
            if cleanup_ids:
                await live_jmap.trash(cleanup_ids)
        except Exception:
            pass
