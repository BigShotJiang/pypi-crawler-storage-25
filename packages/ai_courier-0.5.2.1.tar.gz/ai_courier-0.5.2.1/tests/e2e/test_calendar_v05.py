"""v0.5 calendar E2E — update_event + delete_event round-trips."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest


def _tomorrow() -> datetime:
    return datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0,
    ) + timedelta(days=1)


def _create_test_event(live_caldav, suffix: str = "update"):
    """Helper: create a sandboxed event, return it. Caller is responsible for teardown."""
    start = _tomorrow() + timedelta(hours=14)
    end = start + timedelta(hours=1)
    return live_caldav.create_event(
        summary=f"[courier-e2e] {suffix}",
        start=start,
        end=end,
        location="Original location",
        description="Original description",
        calendar_name="Courier Tests",
    )


def test_update_event_summary_roundtrip(live_caldav):
    """Create → update summary → fetch → assert new summary."""
    event = _create_test_event(live_caldav, "update-summary")
    try:
        updated = live_caldav.update_event(event.uid, summary="[courier-e2e] renamed")
        assert updated.uid == event.uid
        assert updated.summary == "[courier-e2e] renamed"
    finally:
        live_caldav.delete_event(event.uid)


def test_update_event_multiple_fields(live_caldav):
    """Single call can update summary + location + description."""
    event = _create_test_event(live_caldav, "update-multi")
    try:
        updated = live_caldav.update_event(
            event.uid,
            summary="[courier-e2e] multi-updated",
            location="Zoom link",
            description="Agenda: ship v0.5",
        )
        assert updated.summary == "[courier-e2e] multi-updated"
        assert updated.location == "Zoom link"
        assert "ship v0.5" in updated.description
    finally:
        live_caldav.delete_event(event.uid)


def test_update_event_show_as_free(live_caldav):
    """Flip busy → free; TRANSP:TRANSPARENT should round-trip."""
    event = _create_test_event(live_caldav, "update-transp")
    try:
        updated = live_caldav.update_event(event.uid, show_as="free")
        assert updated.show_as == "free"
    finally:
        live_caldav.delete_event(event.uid)


def test_update_timed_to_all_day(live_caldav):
    """Change a timed event to an all-day event via date objects on start/end."""
    event = _create_test_event(live_caldav, "update-all-day")
    try:
        tomorrow = (datetime.now(timezone.utc) + timedelta(days=1)).date()
        day_after = tomorrow + timedelta(days=1)
        updated = live_caldav.update_event(
            event.uid, start=tomorrow, end=day_after,
        )
        assert updated.is_all_day, (
            f"expected all_day after update, got start={updated.start} end={updated.end}"
        )
    finally:
        live_caldav.delete_event(event.uid)


def test_update_event_not_found_raises(live_caldav):
    """Unknown UID → ValueError."""
    with pytest.raises(ValueError, match="Event not found"):
        live_caldav.update_event("nonexistent-uid-v05-test", summary="nope")


def test_delete_event_removes_it(live_caldav):
    """Create → delete → subsequent lookup via update should fail."""
    event = _create_test_event(live_caldav, "delete")
    ok = live_caldav.delete_event(event.uid)
    assert ok is True
    # Follow-up operation should now fail — event is gone.
    with pytest.raises(ValueError, match="Event not found"):
        live_caldav.update_event(event.uid, summary="ghost")


def test_delete_event_unknown_returns_false(live_caldav):
    """delete_event returns False (not exception) when UID not found."""
    assert live_caldav.delete_event("nonexistent-uid-v05-delete-test") is False


# ── move_event (PR B) ───────────────────────────────────────────────


def test_move_event_roundtrip(live_caldav, live_config):
    """Create in Courier Tests → move to Hi-Team → verify present in target + absent from source."""
    start = _tomorrow() + timedelta(hours=14)
    end = start + timedelta(hours=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] move-source",
        start=start,
        end=end,
        calendar_name="Courier Tests",
    )
    try:
        moved = live_caldav.move_event(event.uid, target_calendar_name="Hi-Team")
        assert moved.uid == event.uid
        assert moved.calendar_name == "Hi-Team"

        # Re-query: event should resolve to Hi-Team now, and Courier Tests
        # should no longer have it.
        found = live_caldav._find_event_by_uid(event.uid)
        assert found is not None
        landed_cal, _landed_event = found
        assert landed_cal.name == "Hi-Team"
    finally:
        # Cleanup: delete from wherever it ended up
        live_caldav.delete_event(event.uid)


def test_move_event_same_calendar_is_noop(live_caldav):
    """Moving to the calendar the event already lives on is a no-op."""
    start = _tomorrow() + timedelta(hours=15)
    end = start + timedelta(hours=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] move-noop",
        start=start,
        end=end,
        calendar_name="Courier Tests",
    )
    try:
        moved = live_caldav.move_event(event.uid, target_calendar_name="Courier Tests")
        assert moved.uid == event.uid
        assert moved.calendar_name == "Courier Tests"
    finally:
        live_caldav.delete_event(event.uid)


def test_move_event_unknown_target_raises(live_caldav):
    """Unknown target calendar → ValueError, no side effects."""
    import pytest
    start = _tomorrow() + timedelta(hours=16)
    end = start + timedelta(hours=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] move-unknown-target",
        start=start,
        end=end,
        calendar_name="Courier Tests",
    )
    try:
        with pytest.raises(ValueError, match="Target calendar not found"):
            live_caldav.move_event(event.uid, target_calendar_name="This Calendar Does Not Exist")
        # Event must still be in Courier Tests (no side effect from the failed move)
        found = live_caldav._find_event_by_uid(event.uid)
        assert found is not None
        assert found[0].name == "Courier Tests"
    finally:
        live_caldav.delete_event(event.uid)


def test_move_event_unknown_uid_raises(live_caldav):
    """Unknown event UID → ValueError."""
    import pytest
    with pytest.raises(ValueError, match="Event not found"):
        live_caldav.move_event(
            "nonexistent-uid-v05-move-test",
            target_calendar_name="Hi-Team",
        )
