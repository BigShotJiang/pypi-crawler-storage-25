"""v0.2 regression — calendar read + create, including all-day VALUE=DATE.

Third of three tests that validate the v0.2 "stale vault note" claims.
Specifically disproves 'Courier breaks all-day events' by verifying
VALUE=DATE is present in the generated iCal per RFC 5545 §3.6.1.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone


def _sandbox_calendar_obj(live_caldav, sandbox_calendar):
    """Return the underlying caldav.Calendar for the sandbox dict.

    sandbox_calendar fixture returns a dict; for event creation and
    teardown we need the real Calendar object. This helper does the
    cross-reference by URL, normalized to handle python-caldav's
    inconsistent URL rendering (%40 vs @, :443 vs implicit port,
    trailing slashes).
    """
    from urllib.parse import unquote, urlparse

    def _norm(raw: str) -> tuple[str, str, str]:
        u = urlparse(raw)
        host = (u.hostname or "").lower()
        path = unquote(u.path or "").rstrip("/")
        return (u.scheme.lower(), host, path)

    target = _norm(sandbox_calendar["url"])
    for cal in live_caldav._calendars:
        if _norm(str(cal.url)) == target:
            return cal
    raise RuntimeError(
        f"Sandbox calendar at {sandbox_calendar['url']!r} (normalized {target}) "
        f"not found among {[str(c.url) for c in live_caldav._calendars]}"
    )


def _tomorrow() -> datetime:
    return datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0,
    ) + timedelta(days=1)


def test_today_and_week_return_list(live_caldav):
    today = live_caldav.get_today()
    week = live_caldav.get_week()
    assert isinstance(today, list)
    assert isinstance(week, list)


def test_create_timed_event_in_sandbox(live_caldav, sandbox_calendar):
    start = _tomorrow() + timedelta(hours=9)
    end = start + timedelta(hours=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] timed",
        start=start,
        end=end,
        calendar_name="Courier Tests",
    )
    try:
        assert event.summary == "[courier-e2e] timed"
        assert event.duration_minutes == 60
    finally:
        cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass  # Cleanup-only — don't mask test failure


def test_create_all_day_event_uses_value_date(live_caldav, sandbox_calendar):
    """All-day events must emit VALUE=DATE per RFC 5545 §3.6.1."""
    start = date.today() + timedelta(days=1)
    end = start + timedelta(days=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] all-day",
        start=start,
        end=end,
        calendar_name="Courier Tests",
        all_day=True,
    )
    cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
    try:
        assert event.is_all_day

        # Verify the raw iCal contains VALUE=DATE
        obj = cal_obj.event_by_url(event.raw_url)
        ical_text = obj.data
        assert "VALUE=DATE" in ical_text, (
            "All-day event did not emit VALUE=DATE — check cal.create_event "
            "all_day branch (RFC 5545 §3.6.1)."
        )
    finally:
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass  # Cleanup-only


def test_free_busy_respects_working_hours(live_caldav):
    """free_busy with working_hours=(9, 17) should not return 24/7 gaps."""
    start = _tomorrow()
    end = start + timedelta(days=3)
    slots = live_caldav.free_busy(
        start=start,
        end=end,
        slot_minutes=30,
        working_hours=(9, 17),
        working_days=(0, 1, 2, 3, 4),  # Mon-Fri
    )
    assert isinstance(slots, list)
    # No slot should be longer than 8 hours (9 to 17)
    for s in slots:
        dur = s["duration_min"]
        assert dur <= 8 * 60, f"Slot {s} exceeds an 8-hour working day"


def test_show_as_free_emits_transp_transparent_and_preserves_free_busy(
    live_caldav, sandbox_calendar,
):
    """Create a show_as='free' event, verify:
      1. Raw iCal contains TRANSP:TRANSPARENT (per RFC 5545 §3.8.2.7)
      2. free_busy over the event's time range reports the slot as available
         (transparent events must not block free/busy queries)
    """
    # Far-future Sunday to avoid colliding with real events on Jim's calendar
    # (Sunday because working_days defaults to Mon–Fri, so we can use
    # all_hours=True reliably without fighting weekday filters)
    start = _tomorrow() + timedelta(days=14)
    # Skip forward to Sunday so we're definitely on a weekend
    while start.weekday() != 6:
        start += timedelta(days=1)
    start = start.replace(hour=10)
    end = start + timedelta(hours=2)

    event = live_caldav.create_event(
        summary="[courier-e2e] transparent",
        start=start,
        end=end,
        calendar_name="Courier Tests",
        show_as="free",
    )
    cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
    try:
        # 1. Raw iCal assertion
        obj = cal_obj.event_by_url(event.raw_url)
        ical_text = obj.data
        assert "TRANSP:TRANSPARENT" in ical_text, (
            "show_as='free' should emit TRANSP:TRANSPARENT per RFC 5545 §3.8.2.7; "
            f"got:\n{ical_text}"
        )
        assert "TRANSP:OPAQUE" not in ical_text

        # 2. free_busy round-trip — transparent event must not block the slot.
        # Query a window that tightly brackets the event.
        query_start = start - timedelta(minutes=30)
        query_end = end + timedelta(minutes=30)
        slots = live_caldav.free_busy(
            start=query_start,
            end=query_end,
            slot_minutes=15,
            working_hours=None,  # all hours, so weekend is OK
        )
        # The event's entire span (start..end) should be inside a free slot.
        # Find a slot that contains the event's midpoint.
        from datetime import datetime
        event_midpoint = start + (end - start) / 2
        covering = [
            s for s in slots
            if datetime.fromisoformat(s["start"]) <= event_midpoint
            <= datetime.fromisoformat(s["end"])
        ]
        assert covering, (
            f"Expected a free slot covering {event_midpoint.isoformat()} "
            f"(the transparent event's midpoint); free_busy returned slots: "
            f"{[(s['start'], s['end']) for s in slots]}"
        )
    finally:
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass


def test_show_as_busy_default_blocks_free_busy(live_caldav, sandbox_calendar):
    """Default show_as='busy' must continue to block free/busy slots.

    Complement to the 'free' test: proves we haven't accidentally inverted
    the semantics or made every event transparent.
    """
    start = _tomorrow() + timedelta(days=14)
    while start.weekday() != 6:
        start += timedelta(days=1)
    start = start.replace(hour=14)
    end = start + timedelta(hours=1)

    event = live_caldav.create_event(
        summary="[courier-e2e] opaque",
        start=start,
        end=end,
        calendar_name="Courier Tests",
        # show_as omitted on purpose — default is 'busy'
    )
    cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
    try:
        obj = cal_obj.event_by_url(event.raw_url)
        ical_text = obj.data
        assert "TRANSP:OPAQUE" in ical_text, (
            f"Default show_as should emit TRANSP:OPAQUE; got:\n{ical_text}"
        )

        # free_busy should NOT offer a slot that covers the event's midpoint
        query_start = start - timedelta(minutes=30)
        query_end = end + timedelta(minutes=30)
        slots = live_caldav.free_busy(
            start=query_start,
            end=query_end,
            slot_minutes=15,
            working_hours=None,
        )
        from datetime import datetime
        event_midpoint = start + (end - start) / 2
        covering = [
            s for s in slots
            if datetime.fromisoformat(s["start"]) <= event_midpoint
            <= datetime.fromisoformat(s["end"])
        ]
        assert not covering, (
            f"Opaque event at {event_midpoint.isoformat()} should block "
            f"free/busy; got slots covering it: "
            f"{[(s['start'], s['end']) for s in covering]}"
        )
    finally:
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass


def test_show_as_invalid_raises(live_caldav):
    """Guard: invalid show_as value raises ValueError before any network call."""
    import pytest

    start = _tomorrow() + timedelta(hours=10)
    end = start + timedelta(hours=1)
    with pytest.raises(ValueError, match="must be 'busy' or 'free'"):
        live_caldav.create_event(
            summary="[courier-e2e] bad",
            start=start,
            end=end,
            calendar_name="Courier Tests",
            show_as="tentative",
        )
