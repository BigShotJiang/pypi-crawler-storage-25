"""v0.5.2 unit tests — HTML body support (issue #12).

Pure helpers + JMAP wire-format shape checks. No network.
E2E coverage lives in tests/e2e/test_email_v05_html.py.
"""
from __future__ import annotations

import pytest

from courier.jmap import JMAPClient


# ── _strip_to_text (HTML → plain fallback) ────────────────────────────


class TestStripToText:
    """Pure function: HTML string → reasonable plain-text fallback.

    For `multipart/alternative` sends, we emit the raw HTML as `htmlBody`
    and auto-generate a plain-text twin for `textBody`. Receivers on
    plain-text-only clients (or search indexes) get something readable.
    """

    def test_passes_plain_text_through(self):
        assert JMAPClient._strip_to_text("hello world") == "hello world"

    def test_strips_simple_tags(self):
        out = JMAPClient._strip_to_text("<p>hello</p>")
        assert "hello" in out
        assert "<" not in out
        assert ">" not in out

    def test_paragraphs_get_blank_line(self):
        out = JMAPClient._strip_to_text("<p>Hi</p><p>There</p>")
        assert "Hi" in out
        assert "There" in out
        # Paragraphs separated by at least one newline
        assert out.index("There") > out.index("Hi")
        assert "\n" in out[out.index("Hi"):out.index("There")]

    def test_br_becomes_newline(self):
        out = JMAPClient._strip_to_text("line one<br>line two")
        assert "line one" in out
        assert "line two" in out
        assert "\n" in out[out.index("line one"):out.index("line two")]

    def test_br_self_closing_becomes_newline(self):
        out = JMAPClient._strip_to_text("line one<br/>line two")
        assert "\n" in out[out.index("line one"):out.index("line two")]

    def test_anchor_preserves_url_in_parens(self):
        out = JMAPClient._strip_to_text(
            'Visit <a href="https://example.com">our site</a> today.'
        )
        assert "our site" in out
        assert "https://example.com" in out
        # Link text should appear before the URL
        assert out.index("our site") < out.index("https://example.com")

    def test_list_items_become_dash_bullets(self):
        out = JMAPClient._strip_to_text("<ul><li>apples</li><li>pears</li></ul>")
        assert "- apples" in out
        assert "- pears" in out

    def test_html_entities_decoded(self):
        cases = [
            ("Jim &amp; Richard", "Jim & Richard"),
            ("1 &lt; 2", "1 < 2"),
            ("3 &gt; 2", "3 > 2"),
            ("&quot;hello&quot;", '"hello"'),
            ("it&#39;s", "it's"),
            ("a&nbsp;b", "a\u00a0b"),
        ]
        for inp, expected_fragment in cases:
            out = JMAPClient._strip_to_text(inp)
            assert expected_fragment in out, f"{inp!r} → {out!r}; expected to contain {expected_fragment!r}"

    def test_collapses_triple_newlines(self):
        """No more than two consecutive newlines (single blank line)."""
        out = JMAPClient._strip_to_text("<p>a</p><p>b</p><p>c</p>")
        assert "\n\n\n" not in out

    def test_empty_input_returns_empty(self):
        assert JMAPClient._strip_to_text("") == ""

    def test_only_tags_returns_empty_or_whitespace(self):
        out = JMAPClient._strip_to_text("<div><span></span></div>")
        assert out.strip() == ""

    def test_nested_tags(self):
        out = JMAPClient._strip_to_text("<div><p><strong>bold</strong> text</p></div>")
        assert "bold" in out
        assert "text" in out
        assert "<" not in out


# ── content_type validation on email-write surface ────────────────────


class TestCreateDraftContentType:
    """Input validation on the content_type parameter.

    Wire-format shape is covered below; this class only checks rejection
    of invalid inputs. These tests don't need a live JMAP client.
    """

    def test_invalid_content_type_raises(self):
        """Anything outside {'text/plain', 'text/html'} is a hard error."""
        from courier.jmap import _validate_content_type

        with pytest.raises(ValueError, match="content_type must be"):
            _validate_content_type("text/markdown")

    def test_unknown_mime_raises(self):
        from courier.jmap import _validate_content_type

        with pytest.raises(ValueError, match="content_type must be"):
            _validate_content_type("application/json")

    def test_plain_accepted(self):
        from courier.jmap import _validate_content_type

        _validate_content_type("text/plain")  # no raise

    def test_html_accepted(self):
        from courier.jmap import _validate_content_type

        _validate_content_type("text/html")  # no raise


# ── build_email_body helper — wire format for multipart/alternative ───


class TestBuildEmailBody:
    """Pure function: body string + content_type → JMAP wire structure.

    Returns the (textBody, htmlBody, bodyValues) triple that gets spliced
    into the Email/set payload. Testing the shape lets us verify we
    generate proper multipart/alternative without needing a JMAP server.
    """

    def test_plain_text_single_part(self):
        from courier.jmap import _build_email_body

        text_body, html_body, body_values = _build_email_body(
            body="Hello world", content_type="text/plain",
        )
        # Plain → textBody only, no htmlBody
        assert text_body == [{"partId": "body", "type": "text/plain"}]
        assert html_body is None
        assert body_values == {"body": {"value": "Hello world"}}

    def test_html_multipart_alternative(self):
        from courier.jmap import _build_email_body

        html_src = "<p>Hello <strong>world</strong></p>"
        text_body, html_body, body_values = _build_email_body(
            body=html_src, content_type="text/html",
        )
        # Both bodies present — multipart/alternative semantics
        assert text_body == [{"partId": "text", "type": "text/plain"}]
        assert html_body == [{"partId": "html", "type": "text/html"}]
        # Both bodyValues entries
        assert "text" in body_values
        assert "html" in body_values
        # HTML preserved verbatim
        assert body_values["html"]["value"] == html_src
        # Plain fallback auto-generated from HTML — contains the words
        assert "Hello" in body_values["text"]["value"]
        assert "world" in body_values["text"]["value"]
        # And the HTML is stripped
        assert "<strong>" not in body_values["text"]["value"]


# ── Reply-quote rendering in HTML mode ────────────────────────────────


class TestReplyQuoteHtml:
    """_build_reply_headers handles include_quote + content_type combos."""

    def _make_original(self, body_text="Line 1\nLine 2", subject="Test"):
        from tests.conftest import make_email
        return make_email(
            body_text=body_text,
            subject=subject,
            from_name="Alice",
            from_address="alice@example.com",
            date="2026-04-22T10:00:00Z",
            message_id=["<orig@example.com>"],
        )

    def test_plain_reply_with_quote_uses_gt_prefix(self):
        """Backward-compat: plain mode still emits the '> '-prefixed block."""
        orig = self._make_original(body_text="hello\nworld")
        composed = JMAPClient._build_reply_headers(
            orig, body="thanks!", cc=None, include_quote=True,
        )
        assert "> hello" in composed["body"]
        assert "> world" in composed["body"]
        assert "<blockquote>" not in composed["body"]

    def test_html_reply_with_quote_uses_blockquote(self):
        """HTML mode wraps the original in <blockquote><pre>…</pre></blockquote>."""
        orig = self._make_original(body_text="hello\nworld")
        composed = JMAPClient._build_reply_headers(
            orig, body="<p>thanks!</p>", cc=None,
            include_quote=True, content_type="text/html",
        )
        assert "<blockquote>" in composed["body"]
        assert "</blockquote>" in composed["body"]
        assert "<pre>" in composed["body"]
        assert "hello" in composed["body"]
        assert "world" in composed["body"]
        # The `> `-prefixed fallback shouldn't also appear
        assert "\n> hello" not in composed["body"]

    def test_html_reply_escapes_dangerous_content_in_quote(self):
        """HTML-escape the original body_text to avoid injection in the quote."""
        orig = self._make_original(body_text='<script>alert("x")</script>')
        composed = JMAPClient._build_reply_headers(
            orig, body="reply", cc=None,
            include_quote=True, content_type="text/html",
        )
        # Raw <script> should be escaped — won't appear as a live tag
        assert "<script>" not in composed["body"]
        # Escaped form should appear
        assert "&lt;script&gt;" in composed["body"]

    def test_html_reply_without_quote_passes_body_through(self):
        """No quote: body is the reply verbatim."""
        orig = self._make_original()
        composed = JMAPClient._build_reply_headers(
            orig, body="<p>thanks!</p>", cc=None,
            include_quote=False, content_type="text/html",
        )
        assert composed["body"] == "<p>thanks!</p>"
