"""v0.5 unit tests — pure helpers for calendar_update.

Mirrors the pattern from test_cal_v04.py: pure string transforms on iCal
text, testable without network. The full read-modify-write path is
exercised by the E2E suite under tests/e2e/test_calendar_v05.py.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

import pytest

from courier.cal import CalDAVClient


def _ical(summary="Test", location="",
          description="", transp="OPAQUE",
          dtstart="20260501T140000Z", dtend="20260501T150000Z",
          attendees=""):
    """Build a minimal VCALENDAR for a single timed VEVENT."""
    attendee_block = attendees if not attendees or attendees.startswith("\n") else f"\n{attendees}"
    return (
        "BEGIN:VCALENDAR\r\n"
        "VERSION:2.0\r\n"
        "PRODID:-//Courier//Test//EN\r\n"
        "BEGIN:VEVENT\r\n"
        "UID:evt-001\r\n"
        f"SUMMARY:{summary}\r\n"
        f"DTSTART:{dtstart}\r\n"
        f"DTEND:{dtend}\r\n"
        f"LOCATION:{location}\r\n"
        f"DESCRIPTION:{description}{attendee_block}\r\n"
        "STATUS:CONFIRMED\r\n"
        f"TRANSP:{transp}\r\n"
        "END:VEVENT\r\n"
        "END:VCALENDAR\r\n"
    )


class TestApplyUpdateToIcal:
    """Pure helper: rewrite VEVENT property lines in-place."""

    def test_rewrites_summary(self):
        ical = _ical(summary="Old Title")
        out = CalDAVClient._apply_update_to_ical(ical, summary="New Title")
        assert "SUMMARY:New Title" in out
        assert "SUMMARY:Old Title" not in out

    def test_rewrites_location(self):
        ical = _ical(location="Room 1")
        out = CalDAVClient._apply_update_to_ical(ical, location="Room 2")
        assert "LOCATION:Room 2" in out
        assert "LOCATION:Room 1" not in out

    def test_rewrites_description(self):
        ical = _ical(description="old")
        out = CalDAVClient._apply_update_to_ical(ical, description="new")
        assert "DESCRIPTION:new" in out
        assert "DESCRIPTION:old" not in out

    def test_show_as_free_writes_transparent(self):
        ical = _ical(transp="OPAQUE")
        out = CalDAVClient._apply_update_to_ical(ical, show_as="free")
        assert "TRANSP:TRANSPARENT" in out
        assert "TRANSP:OPAQUE" not in out

    def test_show_as_busy_writes_opaque(self):
        ical = _ical(transp="TRANSPARENT")
        out = CalDAVClient._apply_update_to_ical(ical, show_as="busy")
        assert "TRANSP:OPAQUE" in out
        assert "TRANSP:TRANSPARENT" not in out

    def test_show_as_invalid_raises(self):
        ical = _ical()
        with pytest.raises(ValueError, match="show_as must be"):
            CalDAVClient._apply_update_to_ical(ical, show_as="maybe")

    def test_rewrites_timed_start_and_end(self):
        ical = _ical(dtstart="20260501T140000Z", dtend="20260501T150000Z")
        new_start = datetime(2026, 5, 1, 16, 0, tzinfo=timezone.utc)
        new_end = datetime(2026, 5, 1, 17, 0, tzinfo=timezone.utc)
        out = CalDAVClient._apply_update_to_ical(ical, start=new_start, end=new_end)
        assert "DTSTART:20260501T160000Z" in out
        assert "DTEND:20260501T170000Z" in out
        assert "DTSTART:20260501T140000Z" not in out

    def test_rewrites_all_day_start_and_end(self):
        """Passing date (not datetime) switches to VALUE=DATE format."""
        ical = _ical(dtstart="20260501T140000Z", dtend="20260501T150000Z")
        out = CalDAVClient._apply_update_to_ical(
            ical, start=date(2026, 6, 10), end=date(2026, 6, 11),
        )
        assert "DTSTART;VALUE=DATE:20260610" in out
        assert "DTEND;VALUE=DATE:20260611" in out

    def test_multiple_fields_in_one_call(self):
        ical = _ical(summary="Old", location="Old Loc", transp="OPAQUE")
        out = CalDAVClient._apply_update_to_ical(
            ical, summary="New", location="New Loc", show_as="free",
        )
        assert "SUMMARY:New" in out
        assert "LOCATION:New Loc" in out
        assert "TRANSP:TRANSPARENT" in out

    def test_preserves_unmodified_properties(self):
        """Fields not in the update call must pass through verbatim."""
        ical = _ical(summary="Keep", location="Keep Loc", transp="OPAQUE")
        out = CalDAVClient._apply_update_to_ical(ical, description="only this")
        assert "SUMMARY:Keep" in out
        assert "LOCATION:Keep Loc" in out
        assert "TRANSP:OPAQUE" in out
        assert "DESCRIPTION:only this" in out

    def test_replaces_all_attendees(self):
        """Passing attendees replaces the set, doesn't append."""
        ical = _ical(attendees="ATTENDEE;RSVP=TRUE:mailto:old@example.com")
        out = CalDAVClient._apply_update_to_ical(
            ical, attendees=["new1@example.com", "new2@example.com"],
        )
        assert "mailto:new1@example.com" in out
        assert "mailto:new2@example.com" in out
        assert "old@example.com" not in out

    def test_empty_update_returns_unchanged(self):
        ical = _ical(summary="Hello")
        out = CalDAVClient._apply_update_to_ical(ical)
        assert out == ical

    def test_unknown_field_raises(self):
        ical = _ical()
        with pytest.raises(ValueError, match="unsupported field"):
            CalDAVClient._apply_update_to_ical(ical, weather="sunny")

    # ── CRLF injection guards (fix #1) ───────────────────────────────

    def test_rejects_crlf_in_summary(self):
        ical = _ical()
        with pytest.raises(ValueError, match="must not contain newlines"):
            CalDAVClient._apply_update_to_ical(
                ical, summary="Title\r\nX-EVIL:pwned",
            )

    def test_rejects_lf_in_summary(self):
        ical = _ical()
        with pytest.raises(ValueError, match="must not contain newlines"):
            CalDAVClient._apply_update_to_ical(ical, summary="Title\ninjected")

    def test_rejects_newline_in_location(self):
        ical = _ical()
        with pytest.raises(ValueError, match="must not contain newlines"):
            CalDAVClient._apply_update_to_ical(ical, location="Room\n42")

    def test_rejects_newline_in_description(self):
        ical = _ical()
        with pytest.raises(ValueError, match="must not contain newlines"):
            CalDAVClient._apply_update_to_ical(ical, description="a\nb")

    def test_rejects_newline_in_attendee(self):
        ical = _ical()
        with pytest.raises(ValueError, match="must not contain newlines"):
            CalDAVClient._apply_update_to_ical(
                ical, attendees=["ok@example.com", "bad\n@example.com"],
            )

    # ── DTSTART/DTEND type consistency (fix #2) ──────────────────────

    def test_updating_only_start_to_date_when_end_is_datetime_raises(self):
        ical = _ical(dtstart="20260501T140000Z", dtend="20260501T150000Z")
        with pytest.raises(ValueError, match="must both be all-day or both be timed"):
            CalDAVClient._apply_update_to_ical(ical, start=date(2026, 5, 1))

    def test_updating_only_end_to_date_when_start_is_datetime_raises(self):
        ical = _ical(dtstart="20260501T140000Z", dtend="20260501T150000Z")
        with pytest.raises(ValueError, match="must both be all-day or both be timed"):
            CalDAVClient._apply_update_to_ical(ical, end=date(2026, 5, 2))

    def test_updating_only_start_to_datetime_when_end_is_date_raises(self):
        all_day_ical = _ical().replace(
            "DTSTART:20260501T140000Z", "DTSTART;VALUE=DATE:20260501",
        ).replace("DTEND:20260501T150000Z", "DTEND;VALUE=DATE:20260502")
        with pytest.raises(ValueError, match="must both be all-day or both be timed"):
            CalDAVClient._apply_update_to_ical(
                all_day_ical,
                start=datetime(2026, 5, 1, 10, 0, tzinfo=timezone.utc),
            )

    def test_single_side_datetime_update_ok_when_end_is_datetime(self):
        """Single-side update is fine when types already match."""
        ical = _ical(dtstart="20260501T140000Z", dtend="20260501T150000Z")
        out = CalDAVClient._apply_update_to_ical(
            ical, start=datetime(2026, 5, 1, 16, 0, tzinfo=timezone.utc),
        )
        assert "DTSTART:20260501T160000Z" in out
        assert "DTEND:20260501T150000Z" in out

    def test_both_sides_date_update_ok(self):
        """Both-at-once with date values preserved from earlier test — sanity."""
        ical = _ical()
        out = CalDAVClient._apply_update_to_ical(
            ical, start=date(2026, 6, 10), end=date(2026, 6, 11),
        )
        assert "DTSTART;VALUE=DATE:20260610" in out
        assert "DTEND;VALUE=DATE:20260611" in out


class _FakeCal:
    """Tiny stand-in for a python-caldav Calendar object — network-free."""
    def __init__(self, name: str):
        self.name = name
        self.url = f"https://fake.example/cal/{name}/"


class TestMoveEventValidation:
    """Error-path coverage for move_event without hitting the network.

    Network path (save/delete/rollback) is exercised by the E2E suite.
    """

    def test_unknown_uid_raises(self, account, monkeypatch):
        client = CalDAVClient(account)
        client._calendars = [_FakeCal("Hi-Team"), _FakeCal("Courier Tests")]
        monkeypatch.setattr(client, "_find_event_by_uid", lambda uid: None)

        with pytest.raises(ValueError, match="Event not found"):
            client.move_event("missing-uid", target_calendar_name="Hi-Team")

    def test_unknown_target_raises(self, account, monkeypatch):
        client = CalDAVClient(account)
        fake_source = _FakeCal("Courier Tests")
        client._calendars = [_FakeCal("Hi-Team"), fake_source]

        class _FakeEvent:
            data = "BEGIN:VCALENDAR\r\nEND:VCALENDAR\r\n"

        monkeypatch.setattr(
            client, "_find_event_by_uid",
            lambda uid: (fake_source, _FakeEvent()),
        )

        with pytest.raises(ValueError, match="Target calendar not found"):
            client.move_event("some-uid", target_calendar_name="Nope")


# ── v0.5.2.1: iTIP REPLY generator (Phase C.2) ──────────────────────


def _sample_invite_ical(
    organizer="mailto:alice@example.com",
    attendee="jim@hi-team.net",
    uid="evt-itip-001",
    summary="Weekly sync",
    sequence=None,
) -> str:
    """Canonical 'external organizer invited me' iCal for REPLY tests."""
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Test//EN",
        "METHOD:REQUEST",
        "BEGIN:VEVENT",
        f"UID:{uid}",
        f"ORGANIZER:{organizer}",
        f"ATTENDEE;RSVP=TRUE:mailto:{attendee}",
        "DTSTART:20260501T140000Z",
        "DTEND:20260501T150000Z",
        f"SUMMARY:{summary}",
        "STATUS:CONFIRMED",
    ]
    if sequence is not None:
        lines.append(f"SEQUENCE:{sequence}")
    lines.extend(["END:VEVENT", "END:VCALENDAR"])
    return "\r\n".join(lines) + "\r\n"


class TestBuildItipReply:
    """Pure function: source iCal + response → iTIP REPLY iCal."""

    def test_emits_method_reply_at_vcalendar_level(self):
        src = _sample_invite_ical()
        out = CalDAVClient._build_itip_reply(
            src, attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        assert "METHOD:REPLY" in out
        assert "METHOD:REQUEST" not in out

    def test_preserves_uid_and_organizer(self):
        src = _sample_invite_ical(uid="specific-uid-42", organizer="mailto:alice@example.com")
        out = CalDAVClient._build_itip_reply(
            src, attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        assert "UID:specific-uid-42" in out
        assert "ORGANIZER:mailto:alice@example.com" in out

    def test_only_responding_attendee_listed(self):
        """REPLY carries exactly one ATTENDEE line — the responder's."""
        src = (
            "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\n"
            "UID:x\r\nORGANIZER:mailto:alice@example.com\r\n"
            "ATTENDEE;RSVP=TRUE:mailto:bob@example.com\r\n"
            "ATTENDEE;RSVP=TRUE:mailto:jim@hi-team.net\r\n"
            "ATTENDEE;RSVP=TRUE:mailto:carol@example.com\r\n"
            "SUMMARY:Test\r\nDTSTART:20260501T140000Z\r\nDTEND:20260501T150000Z\r\n"
            "END:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        out = CalDAVClient._build_itip_reply(
            src, attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        attendee_lines = [
            line for line in out.splitlines()
            if line.startswith("ATTENDEE")
        ]
        assert len(attendee_lines) == 1
        assert "jim@hi-team.net" in attendee_lines[0]
        assert "bob@example.com" not in out
        assert "carol@example.com" not in out

    def test_partstat_reflects_response(self):
        for partstat in ("ACCEPTED", "TENTATIVE", "DECLINED"):
            out = CalDAVClient._build_itip_reply(
                _sample_invite_ical(),
                attendee_email="jim@hi-team.net",
                partstat=partstat,
                now_iso="20260422T180000Z",
            )
            assert f"PARTSTAT={partstat}" in out

    def test_dtstamp_uses_provided_timestamp(self):
        out = CalDAVClient._build_itip_reply(
            _sample_invite_ical(),
            attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        assert "DTSTAMP:20260422T180000Z" in out

    def test_preserves_summary_and_times(self):
        out = CalDAVClient._build_itip_reply(
            _sample_invite_ical(summary="Weekly sync"),
            attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        assert "SUMMARY:Weekly sync" in out
        assert "DTSTART:20260501T140000Z" in out
        assert "DTEND:20260501T150000Z" in out

    def test_defaults_sequence_to_zero_when_absent(self):
        out = CalDAVClient._build_itip_reply(
            _sample_invite_ical(sequence=None),
            attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        assert "SEQUENCE:0" in out

    def test_preserves_sequence_when_present(self):
        out = CalDAVClient._build_itip_reply(
            _sample_invite_ical(sequence=3),
            attendee_email="jim@hi-team.net", partstat="ACCEPTED",
            now_iso="20260422T180000Z",
        )
        assert "SEQUENCE:3" in out

    def test_missing_uid_raises(self):
        src = (
            "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\n"
            "ORGANIZER:mailto:alice@example.com\r\nSUMMARY:x\r\n"
            "END:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        with pytest.raises(ValueError, match="UID"):
            CalDAVClient._build_itip_reply(
                src, attendee_email="jim@hi-team.net", partstat="ACCEPTED",
                now_iso="20260422T180000Z",
            )

    def test_missing_organizer_raises(self):
        """Can't REPLY if there's no organizer to send to."""
        src = (
            "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:x\r\n"
            "SUMMARY:y\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        with pytest.raises(ValueError, match="ORGANIZER"):
            CalDAVClient._build_itip_reply(
                src, attendee_email="jim@hi-team.net", partstat="ACCEPTED",
                now_iso="20260422T180000Z",
            )

    def test_invalid_partstat_raises(self):
        with pytest.raises(ValueError, match="partstat"):
            CalDAVClient._build_itip_reply(
                _sample_invite_ical(),
                attendee_email="jim@hi-team.net", partstat="MAYBE",
                now_iso="20260422T180000Z",
            )


class TestExtractOrganizerEmail:
    def test_plain_mailto(self):
        src = _sample_invite_ical(organizer="mailto:alice@example.com")
        assert CalDAVClient._extract_organizer_email(src) == "alice@example.com"

    def test_organizer_with_cn_param(self):
        src = (
            "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\n"
            'ORGANIZER;CN="Alice Example":mailto:alice@example.com\r\n'
            "END:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        assert CalDAVClient._extract_organizer_email(src) == "alice@example.com"

    def test_no_organizer_returns_none(self):
        src = "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:x\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n"
        assert CalDAVClient._extract_organizer_email(src) is None


class TestExtractEventSummary:
    def test_summary_present(self):
        src = _sample_invite_ical(summary="Weekly sync")
        assert CalDAVClient._extract_event_summary(src) == "Weekly sync"

    def test_summary_absent_returns_empty(self):
        src = (
            "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\n"
            "UID:x\r\nORGANIZER:mailto:a@b.com\r\n"
            "END:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        assert CalDAVClient._extract_event_summary(src) == ""
