"""v0.4 unit tests — pure helpers on JMAPClient."""
from __future__ import annotations

from courier.jmap import JMAPClient
from tests.conftest import make_email

# ── _strip_quoted_reply ──────────────────────────────────────────────


class TestStripQuotedReply:
    """The three quote patterns the plan calls out."""

    def test_outlook_original_message_header(self):
        body = (
            "Thanks — sounds good.\n"
            "\n"
            "-----Original Message-----\n"
            "From: Alice\n"
            "To: Bob\n"
            "\n"
            "Here's the original\n"
        )
        result = JMAPClient._strip_quoted_reply(body)
        assert "Thanks — sounds good." in result
        assert "Original Message" not in result
        assert "Here's the original" not in result

    def test_on_date_wrote_with_quote_lines(self):
        body = (
            "Short reply.\n"
            "\n"
            "On 2026-04-17, Alice <a@example.com> wrote:\n"
            "> Original body line 1\n"
            "> Original body line 2\n"
        )
        result = JMAPClient._strip_quoted_reply(body)
        assert "Short reply." in result
        assert "Alice <a@example.com> wrote" not in result
        assert "Original body line 1" not in result

    def test_trailing_quoted_block(self):
        body = (
            "My reply here.\n"
            "\n"
            "> Some prior line\n"
            "> Another prior line\n"
        )
        result = JMAPClient._strip_quoted_reply(body)
        assert "My reply here." in result
        assert "Some prior line" not in result

    def test_no_quote_returns_unchanged(self):
        body = "Plain message with no quote.\n\nSecond paragraph."
        assert JMAPClient._strip_quoted_reply(body) == body

    def test_only_quote_returns_empty_or_whitespace(self):
        body = (
            "On 2026-04-17, Alice wrote:\n"
            "> All of this is quote\n"
        )
        result = JMAPClient._strip_quoted_reply(body)
        assert "Alice wrote" not in result
        assert "All of this is quote" not in result

    def test_strips_trailing_whitespace(self):
        body = "hello\n\n\n"
        assert JMAPClient._strip_quoted_reply(body) == "hello"

    def test_handles_empty_string(self):
        assert JMAPClient._strip_quoted_reply("") == ""

    def test_preserves_internal_blank_lines(self):
        body = "Paragraph one.\n\nParagraph two.\n\n-----Original Message-----\nquoted"
        result = JMAPClient._strip_quoted_reply(body)
        assert "Paragraph one." in result
        assert "Paragraph two." in result
        assert "quoted" not in result


# ── _build_forward_headers ──────────────────────────────────────────


class TestBuildForwardHeaders:
    """Subject prefixing, references chaining, no In-Reply-To."""

    def test_subject_adds_fwd_prefix(self):
        original = make_email(subject="Weekly sync")
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["subject"] == "Fwd: Weekly sync"

    def test_subject_skips_duplicate_fwd(self):
        original = make_email(subject="Fwd: Weekly sync")
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["subject"] == "Fwd: Weekly sync"

    def test_subject_skips_case_insensitive_fwd(self):
        original = make_email(subject="fwd: WEEKLY")
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["subject"] == "fwd: WEEKLY"

    def test_subject_handles_empty(self):
        original = make_email(subject="")
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["subject"] == "Fwd: "

    def test_references_chain(self):
        original = make_email(
            message_id=["<orig@example.com>"],
            references=["<a@example.com>", "<b@example.com>"],
        )
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["references"] == [
            "<a@example.com>",
            "<b@example.com>",
            "<orig@example.com>",
        ]

    def test_references_dedupes_message_id(self):
        original = make_email(
            message_id=["<orig@example.com>"],
            references=["<orig@example.com>"],
        )
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["references"] == ["<orig@example.com>"]

    def test_no_in_reply_to_key(self):
        """Forward starts a new thread — no In-Reply-To."""
        original = make_email(message_id=["<orig@example.com>"])
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert "in_reply_to" not in headers

    def test_passes_through_to_and_cc(self):
        original = make_email()
        to = [{"email": "bob@example.com"}]
        cc = [{"email": "carol@example.com"}]
        headers = JMAPClient._build_forward_headers(original, to=to, cc=cc)
        assert headers["to"] == to
        assert headers["cc"] == cc

    def test_cc_defaults_to_none(self):
        original = make_email()
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["cc"] is None

    def test_handles_empty_references_and_no_message_id(self):
        original = make_email(message_id=[], references=[])
        headers = JMAPClient._build_forward_headers(
            original, to=[{"email": "bob@example.com"}]
        )
        assert headers["references"] == []
