"""v0.4 unit tests — pure helpers on CalDAVClient."""
from __future__ import annotations

import pytest

from courier.cal import CalDAVClient

# ── _update_partstat ────────────────────────────────────────────────


class TestUpdatePartstat:
    """Rewrite the PARTSTAT parameter on the ATTENDEE line matching an email."""

    def _ical(self, attendee_line: str) -> str:
        return (
            "BEGIN:VCALENDAR\r\n"
            "VERSION:2.0\r\n"
            "BEGIN:VEVENT\r\n"
            "UID:evt-001\r\n"
            "SUMMARY:Test\r\n"
            f"{attendee_line}\r\n"
            "END:VEVENT\r\n"
            "END:VCALENDAR\r\n"
        )

    def test_adds_partstat_when_missing(self):
        ical = self._ical("ATTENDEE;RSVP=TRUE:mailto:jim@example.com")
        out = CalDAVClient._update_partstat(ical, "jim@example.com", "ACCEPTED")
        assert "PARTSTAT=ACCEPTED" in out
        # RSVP param should survive
        assert "RSVP=TRUE" in out

    def test_replaces_existing_partstat(self):
        ical = self._ical(
            "ATTENDEE;PARTSTAT=NEEDS-ACTION;RSVP=TRUE:mailto:jim@example.com"
        )
        out = CalDAVClient._update_partstat(ical, "jim@example.com", "DECLINED")
        assert "PARTSTAT=DECLINED" in out
        assert "PARTSTAT=NEEDS-ACTION" not in out
        assert "RSVP=TRUE" in out

    def test_replaces_partstat_at_any_position(self):
        """PARTSTAT can be any position among the params."""
        ical = self._ical(
            "ATTENDEE;CN=Jim;RSVP=TRUE;PARTSTAT=TENTATIVE:mailto:jim@example.com"
        )
        out = CalDAVClient._update_partstat(ical, "jim@example.com", "ACCEPTED")
        assert "PARTSTAT=ACCEPTED" in out
        assert "PARTSTAT=TENTATIVE" not in out
        # Other params preserved
        assert "CN=Jim" in out
        assert "RSVP=TRUE" in out

    def test_case_insensitive_email_match(self):
        ical = self._ical("ATTENDEE;RSVP=TRUE:mailto:Jim@Example.COM")
        out = CalDAVClient._update_partstat(ical, "jim@example.com", "ACCEPTED")
        assert "PARTSTAT=ACCEPTED" in out

    def test_only_matching_attendee_updated(self):
        ical = (
            "BEGIN:VCALENDAR\r\n"
            "VERSION:2.0\r\n"
            "BEGIN:VEVENT\r\n"
            "UID:evt-002\r\n"
            "SUMMARY:Multi-attendee\r\n"
            "ATTENDEE;PARTSTAT=ACCEPTED:mailto:alice@example.com\r\n"
            "ATTENDEE;PARTSTAT=NEEDS-ACTION:mailto:jim@example.com\r\n"
            "ATTENDEE;PARTSTAT=TENTATIVE:mailto:bob@example.com\r\n"
            "END:VEVENT\r\n"
            "END:VCALENDAR\r\n"
        )
        out = CalDAVClient._update_partstat(ical, "jim@example.com", "DECLINED")
        # Jim's status updated
        assert "PARTSTAT=DECLINED:mailto:jim@example.com" in out
        # Others untouched
        assert "PARTSTAT=ACCEPTED:mailto:alice@example.com" in out
        assert "PARTSTAT=TENTATIVE:mailto:bob@example.com" in out

    def test_raises_when_no_attendee_matches(self):
        ical = self._ical("ATTENDEE;RSVP=TRUE:mailto:alice@example.com")
        with pytest.raises(ValueError, match="no ATTENDEE"):
            CalDAVClient._update_partstat(ical, "jim@example.com", "ACCEPTED")

    def test_raises_when_no_attendees_at_all(self):
        ical = (
            "BEGIN:VCALENDAR\r\n"
            "VERSION:2.0\r\n"
            "BEGIN:VEVENT\r\n"
            "UID:evt-003\r\n"
            "SUMMARY:No attendees\r\n"
            "END:VEVENT\r\n"
            "END:VCALENDAR\r\n"
        )
        with pytest.raises(ValueError, match="no ATTENDEE"):
            CalDAVClient._update_partstat(ical, "jim@example.com", "ACCEPTED")

    def test_preserves_line_structure(self):
        """Other lines around the attendee should be unchanged."""
        ical = self._ical("ATTENDEE;RSVP=TRUE:mailto:jim@example.com")
        out = CalDAVClient._update_partstat(ical, "jim@example.com", "ACCEPTED")
        assert "BEGIN:VCALENDAR" in out
        assert "UID:evt-001" in out
        assert "SUMMARY:Test" in out
        assert "END:VCALENDAR" in out


# ── _compute_free_slots (v0.4.1 — pure helper for cross-account free/busy) ──

from datetime import datetime, timezone  # noqa: E402


class TestComputeFreeSlots:
    """Pure function: busy intervals + constraints → list of free slots.

    Shared by `free_busy` (single account) and `free_busy_multi` (cross-account).
    Tests cover the merge + gap-finding + working-hours logic without network.
    """

    tz = timezone.utc
    MON = datetime(2026, 4, 20, tzinfo=tz)  # Monday 00:00 UTC — weekday=0

    def _dt(self, hour: int, minute: int = 0) -> datetime:
        return self.MON.replace(hour=hour, minute=minute)

    def test_unions_non_overlapping_busy_across_accounts(self):
        """Jim busy 9-10, Richard busy 10-11 → merged busy 9-11 → two free gaps."""
        busy = [
            (self._dt(9), self._dt(10)),   # Jim
            (self._dt(10), self._dt(11)),  # Richard
        ]
        free = CalDAVClient._compute_free_slots(
            busy_intervals=busy,
            start=self._dt(8),
            end=self._dt(13),
            slot_minutes=30,
            local_tz=self.tz,
            working_hours=None,
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        assert len(free) == 2
        assert free[0]["duration_min"] == 60   # 8-9
        assert free[1]["duration_min"] == 120  # 11-13

    def test_merges_overlapping_busy(self):
        """Jim 9-11, Richard 10-12 → merged 9-12 → free 8-9 and 12-14."""
        busy = [
            (self._dt(9), self._dt(11)),
            (self._dt(10), self._dt(12)),
        ]
        free = CalDAVClient._compute_free_slots(
            busy_intervals=busy,
            start=self._dt(8),
            end=self._dt(14),
            slot_minutes=30,
            local_tz=self.tz,
            working_hours=None,
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        assert len(free) == 2
        assert free[0]["duration_min"] == 60
        assert free[1]["duration_min"] == 120

    def test_excludes_gaps_shorter_than_slot_minutes(self):
        """20-minute gap between busy blocks is filtered out at slot_minutes=30."""
        busy = [
            (self._dt(9), self._dt(10)),
            (self._dt(10, 20), self._dt(11)),
        ]
        free = CalDAVClient._compute_free_slots(
            busy_intervals=busy,
            start=self._dt(9),
            end=self._dt(11),
            slot_minutes=30,
            local_tz=self.tz,
            working_hours=None,
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        assert free == []

    def test_no_busy_returns_full_range(self):
        free = CalDAVClient._compute_free_slots(
            busy_intervals=[],
            start=self._dt(9),
            end=self._dt(11),
            slot_minutes=30,
            local_tz=self.tz,
            working_hours=None,
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        assert len(free) == 1
        assert free[0]["duration_min"] == 120

    def test_working_hours_trims_gaps(self):
        """Range 06:00-20:00 constrained to 09:00-17:00 → single 8h free block."""
        free = CalDAVClient._compute_free_slots(
            busy_intervals=[],
            start=self._dt(6),
            end=self._dt(20),
            slot_minutes=30,
            local_tz=self.tz,
            working_hours=(9, 17),
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        assert len(free) == 1
        assert free[0]["duration_min"] == 8 * 60

    def test_working_days_skips_weekend(self):
        """Range across Fri-Mon with weekend excluded → only Fri + Mon blocks."""
        fri = datetime(2026, 4, 24, tzinfo=self.tz)  # weekday=4 (Fri)
        mon = datetime(2026, 4, 27, tzinfo=self.tz)  # weekday=0 (Mon)
        free = CalDAVClient._compute_free_slots(
            busy_intervals=[],
            start=fri.replace(hour=9),
            end=mon.replace(hour=17),
            slot_minutes=60,
            local_tz=self.tz,
            working_hours=(9, 17),
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        # Expect 2 slots: Fri 9-17 and Mon 9-17. Sat + Sun skipped.
        assert len(free) == 2
        assert all(f["duration_min"] == 8 * 60 for f in free)


class TestFreeBusyMultiMerges:
    """Orchestrator-level test using the pure helper indirectly.

    Feeds synthetic event lists (bypassing the network fetch) to confirm
    `free_busy_multi` unions busy across callers' calendars correctly.
    """

    def test_merges_busy_from_events_across_calendars(self):
        """Synthetic events from two calendars union into a single busy set."""
        from courier.cal import Event

        tz = timezone.utc
        start = datetime(2026, 4, 20, 8, tzinfo=tz)
        end = datetime(2026, 4, 20, 13, tzinfo=tz)

        jim_events = [
            Event(
                uid="jim-1",
                summary="Standup",
                start=datetime(2026, 4, 20, 9, tzinfo=tz),
                end=datetime(2026, 4, 20, 10, tzinfo=tz),
            ),
        ]
        richard_events = [
            Event(
                uid="r-1",
                summary="Review",
                start=datetime(2026, 4, 20, 10, tzinfo=tz),
                end=datetime(2026, 4, 20, 11, tzinfo=tz),
            ),
        ]

        free = CalDAVClient._free_slots_from_event_lists(
            event_lists=[jim_events, richard_events],
            start=start,
            end=end,
            slot_minutes=30,
            local_tz=tz,
            working_hours=None,
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        assert len(free) == 2
        assert free[0]["duration_min"] == 60
        assert free[1]["duration_min"] == 120

    def test_skips_transparent_and_all_day_events(self):
        """show_as='free' and all-day events do not occupy busy slots."""
        from courier.cal import Event

        tz = timezone.utc
        start = datetime(2026, 4, 20, 9, tzinfo=tz)
        end = datetime(2026, 4, 20, 12, tzinfo=tz)

        jim_events = [
            Event(
                uid="jim-free",
                summary="Tentative hold",
                start=datetime(2026, 4, 20, 9, tzinfo=tz),
                end=datetime(2026, 4, 20, 10, tzinfo=tz),
                show_as="free",  # transparent — shouldn't block
            ),
            Event(
                uid="jim-allday",
                summary="OOO (all day)",
                start=datetime(2026, 4, 20, 0, tzinfo=tz),
                end=datetime(2026, 4, 21, 0, tzinfo=tz),
                # all-day — shouldn't block
            ),
        ]

        free = CalDAVClient._free_slots_from_event_lists(
            event_lists=[jim_events],
            start=start,
            end=end,
            slot_minutes=30,
            local_tz=tz,
            working_hours=None,
            working_days=(0, 1, 2, 3, 4),
            localize=False,
        )
        # Nothing is busy → full 3-hour window free.
        assert len(free) == 1
        assert free[0]["duration_min"] == 180
