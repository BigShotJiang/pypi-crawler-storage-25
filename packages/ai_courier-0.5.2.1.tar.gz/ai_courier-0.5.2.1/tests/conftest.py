"""Shared fixtures for Courier tests."""

from __future__ import annotations

import pytest

from courier.config import AccountConfig
from courier.jmap import Email


@pytest.fixture
def account() -> AccountConfig:
    """Minimal account config for testing."""
    return AccountConfig(
        account_id="test-account",
        provider="fastmail",
        api_token="fake-token",
        app_password="fake-password",
        username="test@example.com",
    )


def make_email(**overrides) -> Email:
    """Factory for test Email objects with sensible defaults."""
    defaults = dict(
        id="msg-001",
        thread_id="thread-001",
        mailbox_ids=["inbox-id"],
        from_address="alice@example.com",
        from_name="Alice",
        to=["bob@example.com"],
        cc=[],
        subject="Hello",
        date="2026-04-13T12:00:00Z",
        preview="Hey Bob, just checking in.",
        body_text="Hey Bob, just checking in. Let me know if you need anything.",
        is_unread=True,
        is_flagged=False,
        has_attachment=False,
        has_calendar_invite=False,
        in_reply_to=None,
        references=[],
        size=1500,
        message_id=[],
        reply_to_addrs=[],
        blob_id="",
    )
    defaults.update(overrides)
    return Email(**defaults)
