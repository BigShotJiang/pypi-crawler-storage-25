"""Tests for courier.config — save/load round-trip, account lookup."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from courier.config import AccountConfig, CourierConfig


@pytest.fixture
def tmp_config(tmp_path) -> Path:
    return tmp_path / "config.json"


class TestAccountConfig:
    def test_defaults(self):
        a = AccountConfig(account_id="x", provider="fastmail", api_token="tok")
        assert a.app_password == ""
        assert a.caldav_url == ""
        assert a.jmap_url == "https://api.fastmail.com/jmap/session"


class TestCourierConfigSaveLoad:
    def test_round_trip(self, tmp_config):
        cfg = CourierConfig(
            accounts={
                "acct1": AccountConfig(
                    account_id="acct1",
                    provider="fastmail",
                    api_token="tok-1",
                    app_password="pw-1",
                    username="user@example.com",
                ),
            },
            default_account="acct1",
        )
        cfg.save(tmp_config)
        loaded = CourierConfig.load(tmp_config)

        assert "acct1" in loaded.accounts
        a = loaded.accounts["acct1"]
        assert a.api_token == "tok-1"
        assert a.app_password == "pw-1"
        assert a.username == "user@example.com"
        assert a.provider == "fastmail"
        assert loaded.default_account == "acct1"

    def test_load_missing_file_returns_empty(self, tmp_path):
        cfg = CourierConfig.load(tmp_path / "nonexistent.json")
        assert cfg.accounts == {}
        assert cfg.default_account == ""

    def test_save_creates_parent_dirs(self, tmp_path):
        deep = tmp_path / "a" / "b" / "c" / "config.json"
        cfg = CourierConfig()
        cfg.save(deep)
        assert deep.exists()

    def test_multiple_accounts(self, tmp_config):
        cfg = CourierConfig(
            accounts={
                "a1": AccountConfig(account_id="a1", provider="fastmail", api_token="t1"),
                "a2": AccountConfig(account_id="a2", provider="fastmail", api_token="t2"),
            },
            default_account="a1",
        )
        cfg.save(tmp_config)
        loaded = CourierConfig.load(tmp_config)
        assert len(loaded.accounts) == 2


class TestGetAccount:
    def test_get_by_id(self):
        cfg = CourierConfig(
            accounts={
                "a1": AccountConfig(account_id="a1", provider="fastmail", api_token="t1"),
                "a2": AccountConfig(account_id="a2", provider="fastmail", api_token="t2"),
            },
            default_account="a1",
        )
        assert cfg.get_account("a2").api_token == "t2"

    def test_get_default(self):
        cfg = CourierConfig(
            accounts={
                "a1": AccountConfig(account_id="a1", provider="fastmail", api_token="t1"),
            },
            default_account="a1",
        )
        assert cfg.get_account().api_token == "t1"

    def test_single_account_auto_selects(self):
        """When there's only one account and no default, return it."""
        cfg = CourierConfig(
            accounts={
                "only": AccountConfig(account_id="only", provider="fastmail", api_token="tok"),
            },
        )
        assert cfg.get_account().account_id == "only"

    def test_missing_account_raises(self):
        cfg = CourierConfig(
            accounts={
                "a1": AccountConfig(account_id="a1", provider="fastmail", api_token="t1"),
                "a2": AccountConfig(account_id="a2", provider="fastmail", api_token="t2"),
            },
        )
        with pytest.raises(ValueError, match="No account found"):
            cfg.get_account("nonexistent")

    def test_no_accounts_raises(self):
        cfg = CourierConfig()
        with pytest.raises(ValueError):
            cfg.get_account()


class TestDelegateAccounts:
    """v0.4.1 — cross-account free/busy requires read-only delegate accounts."""

    def test_delegate_accounts_default_empty(self):
        cfg = CourierConfig()
        assert cfg.delegate_accounts == []

    def test_delegate_accounts_round_trip(self, tmp_config):
        cfg = CourierConfig(
            accounts={
                "fastmail": AccountConfig(
                    account_id="fastmail", provider="fastmail", api_token="tok",
                ),
            },
            default_account="fastmail",
            delegate_accounts=[
                AccountConfig(
                    account_id="richard",
                    provider="fastmail",
                    api_token="",  # calendar-only; no JMAP token needed
                    app_password="pw-richard",
                    username="richard@example.com",
                ),
            ],
        )
        cfg.save(tmp_config)
        loaded = CourierConfig.load(tmp_config)

        assert len(loaded.delegate_accounts) == 1
        d = loaded.delegate_accounts[0]
        assert d.account_id == "richard"
        assert d.app_password == "pw-richard"
        assert d.username == "richard@example.com"
        assert d.provider == "fastmail"

    def test_load_tolerates_absent_delegate_accounts_field(self, tmp_config):
        """Pre-v0.4.1 configs don't have this field; load must default to []."""
        tmp_config.write_text(json.dumps({
            "accounts": {
                "fastmail": {
                    "provider": "fastmail",
                    "api_token": "t",
                    "app_password": "",
                    "jmap_url": "https://api.fastmail.com/jmap/session",
                    "caldav_url": "",
                    "username": "",
                    "timezone": "America/Chicago",
                },
            },
            "db_path": "/tmp/foo.db",
            "default_account": "fastmail",
        }))
        loaded = CourierConfig.load(tmp_config)
        assert loaded.delegate_accounts == []

    def test_multiple_delegates_round_trip(self, tmp_config):
        cfg = CourierConfig(
            accounts={
                "fastmail": AccountConfig(
                    account_id="fastmail", provider="fastmail", api_token="tok",
                ),
            },
            default_account="fastmail",
            delegate_accounts=[
                AccountConfig(
                    account_id="richard",
                    provider="fastmail",
                    api_token="",
                    app_password="pw-r",
                    username="richard@example.com",
                ),
                AccountConfig(
                    account_id="linda",
                    provider="fastmail",
                    api_token="",
                    app_password="pw-l",
                    username="linda@example.com",
                ),
            ],
        )
        cfg.save(tmp_config)
        loaded = CourierConfig.load(tmp_config)
        assert [d.account_id for d in loaded.delegate_accounts] == ["richard", "linda"]
