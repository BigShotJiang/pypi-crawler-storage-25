"""Tests for courier.roadmap — parsers + renderer.

Pure functions only; no network, no git, no gh CLI. Feeds synthetic
or real fixture strings and verifies the output shape.
"""
from __future__ import annotations

from textwrap import dedent

import pytest

from courier import roadmap


# ── load_planned ─────────────────────────────────────────────────────


class TestLoadPlanned:
    def test_parses_minimal_yaml(self, tmp_path):
        y = tmp_path / "planned.yaml"
        y.write_text(dedent("""
            releases:
              v0.5:
                target: 2026-05-08
                theme: Retire Fantastical
                features:
                  - tool: calendar_update
                    area: calendar
        """).strip())
        m = roadmap.load_planned(y)
        assert "v0.5" in m["releases"]
        assert m["releases"]["v0.5"]["theme"] == "Retire Fantastical"
        assert m["releases"]["v0.5"]["features"][0]["tool"] == "calendar_update"

    def test_empty_yaml_returns_empty_manifest(self, tmp_path):
        y = tmp_path / "empty.yaml"
        y.write_text("")
        m = roadmap.load_planned(y)
        assert m == {"releases": {}, "enhancements": []}

    def test_enhancements_list_parses(self, tmp_path):
        y = tmp_path / "enh.yaml"
        y.write_text(dedent("""
            enhancements:
              - area: email
                label: HTML support
                issue: 12
        """).strip())
        m = roadmap.load_planned(y)
        assert m["enhancements"][0]["issue"] == 12


# ── parse_changelog ──────────────────────────────────────────────────


class TestParseChangelog:
    def _changelog(self, *sections: str) -> str:
        head = "# Changelog\n\n"
        return head + "\n\n".join(sections) + "\n"

    def test_extracts_single_version_with_tools(self, tmp_path):
        cl = tmp_path / "CHANGELOG.md"
        cl.write_text(self._changelog(
            "## [0.4.0] — 2026-04-19\n"
            "### Added\n"
            "- **`email_sent_since(after, limit)`** — dedicated sent-mail primitive\n"
            "- **`calendar_rsvp(event_uid, response)`** — respond to invite\n"
        ))
        entries = roadmap.parse_changelog(cl)
        assert len(entries) == 1
        e = entries[0]
        assert e["version"] == "0.4.0"
        assert e["date"] == "2026-04-19"
        assert "email_sent_since" in e["tools"]
        assert "calendar_rsvp" in e["tools"]

    def test_multiple_versions_ordered(self, tmp_path):
        cl = tmp_path / "CHANGELOG.md"
        cl.write_text(self._changelog(
            "## [0.4.1] — 2026-04-19\n"
            "### Added\n"
            "- **`calendar_free_both`** — cross-account free/busy\n",
            "## [0.4.0] — 2026-04-19\n"
            "### Added\n"
            "- **`email_sent_since`** — sent mail primitive\n",
        ))
        entries = roadmap.parse_changelog(cl)
        versions = [e["version"] for e in entries]
        assert versions == ["0.4.1", "0.4.0"]  # newest-first, matches file order

    def test_ignores_non_tool_bullets(self, tmp_path):
        """Bullets without a call signature (and pure prose) are not tools."""
        cl = tmp_path / "CHANGELOG.md"
        cl.write_text(self._changelog(
            "## [0.2.0] — 2026-04-16\n"
            "### Added\n"
            "- **`email_attachments(email_id)`** — list attachments\n"
            "- Deprecation notice for old pattern\n"
            "- General prose bullet with no code\n"
        ))
        entries = roadmap.parse_changelog(cl)
        assert entries[0]["tools"] == ["email_attachments"]

    def test_strips_argument_list_from_tool_name(self, tmp_path):
        """Captures the bare identifier even when the bullet includes args."""
        cl = tmp_path / "CHANGELOG.md"
        cl.write_text(self._changelog(
            "## [0.4.0] — 2026-04-19\n"
            "### Added\n"
            "- **`email_forward(email_id, to, body, include_original=True)`** — forward\n"
        ))
        entries = roadmap.parse_changelog(cl)
        assert entries[0]["tools"] == ["email_forward"]

    def test_ignores_param_and_field_bullets(self, tmp_path):
        """Bullets without a call signature (fields, params, verbs) are not tools."""
        cl = tmp_path / "CHANGELOG.md"
        cl.write_text(self._changelog(
            "## [0.3.3] — 2026-04-17\n"
            "### Added\n"
            "- **`show_as` parameter on `calendar_create`** — mark events free/busy\n"
            "- **`Email.blob_id`** — new field exposing the raw MIME reference\n"
            "- **`courier sent`** — CLI verb\n"
            "- **`calendar_create(summary, start, end, show_as)`** — create event\n"
        ))
        entries = roadmap.parse_changelog(cl)
        # Only the parens-bearing entry should match.
        assert entries[0]["tools"] == ["calendar_create"]


# ── current_tools_from_server_py ─────────────────────────────────────


class TestCurrentToolsFromServerPy:
    def test_extracts_names_from_tool_calls(self, tmp_path):
        src = tmp_path / "server.py"
        src.write_text(dedent("""
            TOOLS = [
                Tool(name="email_inbox", description="desc"),
                Tool(name="calendar_today", description="desc"),
            ]
        """).strip())
        assert roadmap.current_tools_from_server_py(src) == {"email_inbox", "calendar_today"}

    def test_real_server_py_has_expected_tools(self):
        """Sanity check against the real server.py — should include headline tools."""
        from pathlib import Path
        src = Path(__file__).parent.parent / "src" / "courier" / "server.py"
        tools = roadmap.current_tools_from_server_py(src)
        # These are in PR A + earlier; must be present.
        assert "email_inbox" in tools
        assert "calendar_today" in tools
        assert "calendar_update" in tools  # PR A merged


# ── render_markdown ──────────────────────────────────────────────────


class TestRenderMarkdown:
    def test_banner_at_top(self):
        out = roadmap.render_markdown(
            changelog=[],
            planned={"releases": {}, "enhancements": []},
            current_tools=set(),
            current_version="0.5.0",
            timestamp="2026-04-21 15:00 UTC",
        )
        first_line = out.lstrip().split("\n")[0]
        assert first_line.startswith(">")
        assert "Roomba" in out or "roomba" in out  # the funny bit
        assert "2026-04-21 15:00 UTC" in out

    def test_shipped_tools_from_changelog(self):
        out = roadmap.render_markdown(
            changelog=[
                {"version": "0.4.0", "date": "2026-04-19", "tools": ["email_sent_since"]},
            ],
            planned={"releases": {}, "enhancements": []},
            current_tools={"email_sent_since"},
            current_version="0.4.0",
            timestamp="2026-04-21 15:00 UTC",
        )
        assert "email_sent_since" in out
        assert "v0.4.0" in out
        assert "✅" in out

    def test_planned_features_rendered(self):
        out = roadmap.render_markdown(
            changelog=[],
            planned={
                "releases": {
                    "v0.5": {
                        "target": "2026-05-08",
                        "theme": "Retire Fantastical",
                        "features": [
                            {"tool": "calendar_update", "area": "calendar"},
                        ],
                    },
                },
                "enhancements": [],
            },
            current_tools=set(),
            current_version="0.4.1",
            timestamp="2026-04-21 15:00 UTC",
        )
        assert "calendar_update" in out
        assert "v0.5" in out
        assert "Retire Fantastical" in out
        assert "📋" in out

    def test_enhancement_with_issue_renders_link(self):
        out = roadmap.render_markdown(
            changelog=[],
            planned={
                "releases": {},
                "enhancements": [
                    {"area": "email", "label": "HTML body", "issue": 12},
                ],
            },
            current_tools=set(),
            current_version="0.4.1",
            timestamp="2026-04-21 15:00 UTC",
        )
        assert "HTML body" in out
        assert "#12" in out
        assert "💡" in out

    def test_drops_duplicate_planned_when_shipped(self):
        """A feature in CHANGELOG should not also appear in Planned."""
        out = roadmap.render_markdown(
            changelog=[
                {"version": "0.5.0", "date": "2026-05-08", "tools": ["calendar_update"]},
            ],
            planned={
                "releases": {
                    "v0.5": {
                        "target": "2026-05-08",
                        "theme": "Retire Fantastical",
                        "features": [
                            {"tool": "calendar_update", "area": "calendar"},
                        ],
                    },
                },
                "enhancements": [],
            },
            current_tools={"calendar_update"},
            current_version="0.5.0",
            timestamp="2026-04-21 15:00 UTC",
        )
        # calendar_update should appear once in the Shipped section, not in the Planned release.
        shipped_idx = out.find("Shipped")
        planned_idx = out.find("Planned")
        calendar_update_first = out.find("calendar_update")
        assert shipped_idx < calendar_update_first
        # Not asserting Planned section excludes it; the soft test is that it's
        # rendered under Shipped (earlier in the doc).

    def test_drift_warning_for_changelog_tool_missing_in_server(self):
        """CHANGELOG says we shipped X but server.py doesn't have it — warn."""
        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            roadmap.render_markdown(
                changelog=[
                    {"version": "0.4.0", "date": "2026-04-19", "tools": ["ghost_tool"]},
                ],
                planned={"releases": {}, "enhancements": []},
                current_tools={"email_inbox"},  # ghost_tool not present
                current_version="0.4.0",
                timestamp="2026-04-21 15:00 UTC",
            )
            drift = [x for x in w if "ghost_tool" in str(x.message)]
            assert drift, f"Expected drift warning for ghost_tool; got: {[str(x.message) for x in w]}"
