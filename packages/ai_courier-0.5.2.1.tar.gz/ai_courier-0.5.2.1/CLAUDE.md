# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Courier is an AI-native email & calendar client — an MCP server (and companion CLI) that talks directly to **JMAP** (email) and **CalDAV** (calendar) as a first-class peer client, not as a wrapper around a human-facing app. It is Fastmail-only today, but `AccountConfig.provider` is intended to be extensible.

Two entry points, both defined as `[project.scripts]` in `pyproject.toml`:

- `courier` — CLI (`src/courier/cli.py:main`)
- `courier-mcp` — MCP server over stdio (`src/courier/server.py:main`)

## Commands

```bash
# Install for development (editable + dev extras)
pip install -e ".[dev]"

# Run all tests
pytest

# Run a single test file / test
pytest tests/test_triage_rules.py
pytest tests/test_triage_rules.py::test_noreply_sender

# Lint
ruff check .

# Run CLI against the configured Fastmail account
courier setup           # first-time account config (prompts for JMAP token + CalDAV app password)
courier inbox           # triaged inbox
courier new             # delta since last check (watermark-based)
courier status

# Run MCP server (stdio)
courier-mcp
```

`pyproject.toml` sets `asyncio_mode = "auto"` for pytest-asyncio, so `async def test_*` functions run without an explicit marker. Ruff is configured for `py311`, line length 100, rules `E,F,I,W`.

## Architecture

The codebase is a flat package under `src/courier/`. The dependency graph runs one direction: `cli.py` / `server.py` → `triage.py` → `triage_rules.py` → `jmap.py`, with `cal.py`, `state.py`, and `config.py` as leaves. There is no circular coupling.

### Layers

1. **Protocol clients** (`jmap.py`, `cal.py`)
   - `JMAPClient` implements just enough of RFC 8620/8621 to be a complete email client: session discovery, Email/get, Email/query, Email/set, Mailbox/get, blob download/upload.
   - `Email` (in `jmap.py`) and `Event` (in `cal.py`) are **context-window-optimized** dataclasses — flat, agent-shaped representations with a `summary()`/`summary_dict()` method for token-efficient serialization. They are **not** MIME trees or VObject graphs.
   - `CalDAVClient` bypasses python-caldav's broken Fastmail principal discovery by doing a raw PROPFIND on the calendar-home-set URL. If you touch CalDAV setup, preserve this — it's intentional.
   - `free_busy` respects working hours and splits multi-day gaps at day boundaries; the default for the CLI is Mon–Fri 09:00–17:00 local (see CHANGELOG 0.2.0).

2. **Persistence** (`state.py`)
   - `StateStore` is a thin SQLite wrapper. Four tables: `watermarks`, `triage`, `contact_signals`, `session_state`. Every table has `account_id` as part of the primary key — **the schema is multi-account from day one**, even though today only one Fastmail account is configured. Preserve this pattern when adding columns or tables.
   - `contact_signals` tracks per-address send/receive counts and is what `requires_known_contact` / `requires_unknown_contact` triage guards read.

3. **Triage** (`triage.py`, `triage_rules.py`, `default_rules.yaml`)
   - `triage.py` is a **backward-compatible facade**: it re-exports `URGENT`/`NEEDS_REPLY`/`ACTIONABLE`/`FYI`/`BULK` constants and wraps `triage_rules.classify_email` / `classify_batch` with a lazy default ruleset. Don't regress this — existing callers (including tests) depend on the old signature.
   - `triage_rules.py` loads YAML rules from `src/courier/default_rules.yaml` (shipped) and merges `~/.config/courier/triage-rules.yaml` (user). Rules are evaluated top-to-bottom; first match wins; no match → `fyi`.
   - User-override merge semantics (important): `sender_overrides` are **additive**, but if the user defines `rules`, those **replace** the defaults entirely. This is documented at the top of `default_rules.yaml`.
   - The default ruleset is lazy-loaded once per process and **never invalidated** — rule file changes require a restart.

4. **Config** (`config.py`)
   - JSON config at `~/.config/courier/config.json`. `AccountConfig` holds **two** credentials per account: a JMAP API token (`api_token`) for email and a CalDAV app password (`app_password`) for calendar — Fastmail issues these separately.
   - `db_path` defaults to `~/.config/courier/courier.db`.

5. **Surfaces** (`cli.py`, `server.py`)
   - `server.py` defines the MCP tool surface (see README's tool table) and uses module-level singletons (`_config`, `_jmap`, `_caldav`, `_state`) lazily initialized on first use. The MCP tool names are the public API — renaming them is a breaking change for anyone who has added Courier to their Claude/agent config.
   - `server._ensure_list()` exists because some MCP runtimes (e.g. Cowork) serialize arrays as JSON strings. Keep the coercion when adding new batch tools.
   - The MCP layer passes the Fastmail account's local timezone (`account.timezone`, default `America/Chicago`) into `Event.summary_dict(local_tz=...)` so calendar output is rendered in local time.

### A few load-bearing conventions

- `Email.summary(max_body=...)` is the token-budget knob. `email_read` uses 10 000 chars; `email_thread` uses 2 000 per message; list endpoints use the 500 default. Respect this when adding new read endpoints.
- `email_new` is watermark-driven: it reads `watermarks` for the inbox, filters, then writes the newest seen `date`+`id` back. Don't short-circuit this — the whole "what's new since last session" UX depends on it.
- All-day events use `VALUE=DATE` (RFC 5545 §3.6.1). `server.calendar_create` sniffs `"T" not in raw_start` to decide all-day vs. timed; `cal.create_event(all_day=True)` is the underlying flag. Don't route bare-date strings through `datetime.fromisoformat`.
- `Email.has_calendar_invite` is populated by walking JMAP `bodyStructure` for `text/calendar` parts and is consumed by the `requires_calendar_invite` triage guard and the `calendar-invite-mime` default rule.

## Testing notes

- Tests are pure unit tests against the dataclasses and state layer — nothing hits the network. `tests/conftest.py` provides an `account` fixture and a `make_email(**overrides)` factory; prefer these over constructing `Email` objects inline.
- `test_triage_rules.py` is the largest suite and exercises the YAML loader, guards, and override semantics. When changing `default_rules.yaml` or adding rule guards, extend that file.
- There is no end-to-end JMAP/CalDAV test — connection behaviour is exercised manually via `courier status` / `courier setup`.
- `tests/e2e/` is the opt-in live integration suite, gated by `COURIER_LIVE_TESTS=1`. It uses a sandbox mailbox `Courier/Tests` and calendar `Courier Tests`, both created by `courier test-setup`. Every write test self-cleans via a `self_sent_email` fixture that sends a timestamped test message to the configured account, yields it, and trashes both copies on teardown. Do not add live tests outside `tests/e2e/`.
- `asyncio_default_test_loop_scope = "session"` is set in `pyproject.toml` so function-scoped tests share the same event loop as session-scoped fixtures (required for reusing the `live_jmap` httpx client). Don't change this without checking every async fixture.

## Scope discipline

- Don't introduce a provider abstraction for a second provider that doesn't exist yet. `AccountConfig.provider` is a string and `cal.py` already branches on `"fastmail"` for URL auto-build — that's the pattern to extend.
- Don't add fallback strategies (HTML-to-text scraping, IMAP fallback, etc.) on your own initiative. Fail fast and loud; the surrounding user instructions in `~/.claude/CLAUDE.md` explicitly prohibit silent fallbacks.

## Git workflow

- **Commits:** only when Jim asks. Never amend; always create a new commit. Never skip hooks (`--no-verify`, `--no-gpg-sign`, etc.).
- **Pushes and PRs:** Claude may run `git push` and `gh pr create` — each one still requires Jim's explicit OK for that specific action. Draft the PR title/body and show it before pushing when practical.
- **Force-push, reset --hard, branch -D, etc.:** never without a direct instruction for that specific destructive operation.
