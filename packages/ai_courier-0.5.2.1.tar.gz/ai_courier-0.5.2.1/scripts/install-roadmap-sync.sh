#!/usr/bin/env bash
# Install the courier-roadmap-sync launchd agent on macOS.
#
# Renders the plist template with the local repo path + vault target,
# writes to ~/Library/LaunchAgents/, and launchctl-loads it. Agent polls
# every 15 min: git pull + cp docs/ROADMAP.md to the vault.
#
# Usage: scripts/install-roadmap-sync.sh [path-to-vault-roadmap.md]
# Default vault target: ~/Sync/Hi-Team/Knowledge/Tech/Courier/courier-roadmap.md
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VAULT_ROADMAP="${1:-$HOME/Sync/Hi-Team/Knowledge/Tech/Courier/courier-roadmap.md}"
TEMPLATE="$REPO_ROOT/scripts/launchd/net.jperry.courier-roadmap-sync.plist.template"
TARGET="$HOME/Library/LaunchAgents/net.jperry.courier-roadmap-sync.plist"

if [[ ! -f "$TEMPLATE" ]]; then
  echo "Template not found at $TEMPLATE" >&2
  exit 1
fi

# Verify vault target directory exists (the file itself may not yet).
vault_dir="$(dirname "$VAULT_ROADMAP")"
if [[ ! -d "$vault_dir" ]]; then
  echo "Vault directory $vault_dir does not exist. Edit script or create it first." >&2
  exit 1
fi

# Render the plist from the template.
mkdir -p "$HOME/Library/LaunchAgents"
sed \
  -e "s|__REPO_ROOT__|$REPO_ROOT|g" \
  -e "s|__VAULT_ROADMAP__|$VAULT_ROADMAP|g" \
  "$TEMPLATE" > "$TARGET"

echo "Rendered plist at $TARGET"

# Unload first (idempotent) then load.
launchctl unload "$TARGET" 2>/dev/null || true
launchctl load "$TARGET"

echo "Loaded. Logs: /tmp/courier-roadmap-sync.log"
echo "Initial run will fire at load; subsequent runs every 15 minutes."
