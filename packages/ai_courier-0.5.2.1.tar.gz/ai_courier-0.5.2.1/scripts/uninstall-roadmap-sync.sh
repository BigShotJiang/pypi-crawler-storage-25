#!/usr/bin/env bash
# Uninstall the courier-roadmap-sync launchd agent.
set -euo pipefail

TARGET="$HOME/Library/LaunchAgents/net.jperry.courier-roadmap-sync.plist"

if [[ -f "$TARGET" ]]; then
  launchctl unload "$TARGET" 2>/dev/null || true
  rm -f "$TARGET"
  echo "Removed $TARGET and unloaded."
else
  echo "Nothing to do: $TARGET does not exist."
fi
