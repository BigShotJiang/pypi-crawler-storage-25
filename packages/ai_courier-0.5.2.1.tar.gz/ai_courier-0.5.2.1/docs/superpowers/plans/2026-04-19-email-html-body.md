# v0.5.1 — HTML Email Body Support

**Goal:** `email_send`, `email_reply`, `email_forward`, `email_draft` all accept HTML bodies in addition to plain text, sending `multipart/alternative` so every mail client renders correctly. Closes [#12](https://github.com/iamdadzilla/courier/issues/12).

**Release slot:** v0.5.1 — standalone dot release after v0.5 (Retire Fantastical) ships. No runtime coupling to calendar work; v0.5 and v0.5.1 can be developed on parallel branches but v0.5 ships first to avoid release-engineering interleave.

**Scope:** all four email-write tools (`email_send`, `email_reply`, `email_forward`, `email_draft`). Default behavior unchanged (text/plain); `content_type` is optional.

**Explicit non-goals for v0.5.1:**
- `match_sender` auto-detection from the original email's Content-Type — deferred.
- User-provided plain-text fallback override — fallback is auto-generated from HTML.
- Outbound HTML sanitization / safety scrubbing — we're the sender; the agent authoring the HTML is trusted.
- Rich editing helpers (tables, inline images) — pass raw HTML; clients render it.

---

## Interface

MCP tool schema additions (all four tools):

```json
"content_type": {
  "type": "string",
  "enum": ["text/plain", "text/html"],
  "default": "text/plain",
  "description": "Body MIME type. 'text/html' sends multipart/alternative with an auto-generated plain-text fallback."
}
```

CLI flag addition (all four verbs):

```
--html        send body as text/html with auto-generated plain-text fallback
              (shorthand for --content-type text/html)
```

Python API on `JMAPClient`:

```python
async def create_draft(
    self,
    to: list[dict[str, str]],
    subject: str,
    body: str,
    *,
    content_type: str = "text/plain",  # "text/plain" | "text/html"
    cc=None, in_reply_to=None, references=None, from_addr=None, attachments=None,
) -> str: ...
```

`send_email`, `reply_to`, `forward` get the same `content_type` kwarg passed through.

---

## JMAP wire format

Current text-only shape (from `create_draft` at jmap.py:951):

```json
{
  "mailboxIds": {...},
  "textBody": [{"partId": "body", "type": "text/plain"}],
  "bodyValues": {"body": {"value": "<text>"}}
}
```

New HTML + fallback shape when `content_type="text/html"`:

```json
{
  "mailboxIds": {...},
  "textBody": [{"partId": "text", "type": "text/plain"}],
  "htmlBody": [{"partId": "html", "type": "text/html"}],
  "bodyValues": {
    "text": {"value": "<auto-stripped>"},
    "html": {"value": "<original html>"}
  }
}
```

JMAP handles the `multipart/alternative` MIME construction server-side per RFC 8621 §4.1.4. We only populate both body pointers + both body values.

---

## Fallback strategy — HTML → text

**Recommendation:** add `html2text` (≈90 KB, MIT, stable since 2012) as a runtime dep.

```python
import html2text

def _strip_to_text(html: str) -> str:
    h = html2text.HTML2Text()
    h.ignore_images = True
    h.body_width = 0  # no auto-wrap
    return h.handle(html).strip()
```

**Alternative (zero-dep):** regex-strip tags + normalize whitespace. Crude but adequate for simple HTML. Open to this if Jim prefers minimum deps; trade-off is uglier fallback text in niche cases (tables, nested lists, links).

**Decision deferred to Phase 1 TDD** — if the zero-dep variant passes the Phase-1 test cases (basic paragraphs, bullet lists, links, inline formatting), we skip the dep. If not, adopt html2text.

---

## Phase 1 — Core `jmap.py` support (+ tests)

**Files:** `src/courier/jmap.py`, `tests/test_jmap_v05.py` (new).

- [ ] Private helper: `_strip_to_text(html: str) -> str`. Start with zero-dep regex; fall back to html2text if tests reveal gaps.
- [ ] `create_draft(..., content_type="text/plain")` — when `"text/html"`, populate `htmlBody` + `textBody` with the two partIds described above.
- [ ] Validate: `content_type` ∈ {`"text/plain"`, `"text/html"`}. Anything else → `ValueError("content_type must be 'text/plain' or 'text/html'")`. Fail loudly, no silent default.
- [ ] Tests (TDD order):
  - `test_strip_paragraph` — `<p>Hi</p><p>There</p>` → `"Hi\n\nThere"`.
  - `test_strip_links` — `<a href="url">text</a>` → reasonable output (either `text` or `text (url)`). Pick one, assert.
  - `test_strip_list` — `<ul><li>a</li><li>b</li></ul>` → `"- a\n- b"` (or similar).
  - `test_content_type_invalid_raises`.
  - `test_create_draft_plain` — default path unchanged; assert exact JMAP payload.
  - `test_create_draft_html_builds_multipart` — asserts both `textBody` and `htmlBody` present, `bodyValues` has both parts, plain is stripped.
- [ ] Snapshot tests: golden JMAP payload for a fixed HTML input (saves debugging time if the wire format changes).

**Acceptance for Phase 1:** running `pytest tests/test_jmap_v05.py` is green without needing any other phase.

---

## Phase 2 — Downstream write paths

**Files:** `src/courier/jmap.py` (`send_email`, `reply_to`, `forward`), tests.

- [ ] `send_email(..., content_type="text/plain")` — passes through to `create_draft`.
- [ ] `reply_to(..., content_type="text/plain")` — passes through. For quoted-original scenarios (`include_quote=True`), preserve behavior: the quoted block stays as whatever content type the caller passed. If quoted + HTML, wrap original as a `<blockquote>`; if quoted + plain, keep the `> ` prefixed block.
- [ ] `forward(..., content_type="text/plain")` — passes through.
- [ ] Tests: one per downstream path, asserting the payload reaches `create_draft` with correct `content_type`.

**Tricky bit — reply quoting:**
- Plain mode + `include_quote=True`: existing `> `-prefix logic runs.
- HTML mode + `include_quote=True`: wrap original body in `<blockquote>…</blockquote>`. If original was plain, escape it and wrap in `<pre>`.
- HTML mode + `include_quote=True` + original was HTML: embed original HTML inside `<blockquote>` verbatim. Open question for Phase 2: do we strip scripts/images from embedded HTML, or trust the original? Default: trust, don't scrub. Revisit if demo spam ever exploits this.

---

## Phase 3 — MCP tool schema + dispatch

**File:** `src/courier/server.py`.

- [ ] Add `content_type` property to `email_send`, `email_reply`, `email_forward`, `email_draft` tool schemas (see "Interface" above).
- [ ] Dispatch: read `arguments.get("content_type", "text/plain")` and pass through.
- [ ] Description update on each tool: "Set content_type='text/html' to send HTML with auto-generated plain-text fallback. Default is text/plain."

Open reminder from v0.3.3 experience: MCP JSON Schema silently accepts unknown parameter values. Validation happens in `jmap.py`'s `ValueError`, not at the schema boundary. That's fine — we want loud failures at the code layer.

---

## Phase 4 — CLI flags

**File:** `src/courier/cli.py`.

- [ ] `courier send`, `courier reply`, `courier forward`, `courier draft` — add:
  ```
  --html                shorthand for --content-type text/html
  --content-type {text/plain,text/html}
  ```
  `--html` wins if both passed.
- [ ] Body source still supports the existing `-` / file-path / literal string pattern (from `cmd_forward`). Works for HTML too — Jim can pipe an HTML file via stdin.

---

## Phase 5 — E2E + release

**File:** `tests/e2e/test_email_v051.py` (new), `CHANGELOG.md`, version bumps.

- [ ] E2E (gated on `COURIER_LIVE_TESTS=1`):
  - `test_send_html_roundtrip` — send a multipart/alternative self-sent message; fetch via `email_read`; assert both `textBody` and `htmlBody` present in the parsed `Email` dataclass.
  - `test_reply_html_preserves_thread_headers` — reply in HTML mode, verify `In-Reply-To` + `References` still set.
  - `test_forward_html_reattaches_original` — the v0.4 `rawBlobId` re-attach path must still work when the forwarding body is HTML.
- [ ] CHANGELOG `[0.5.1]` entry.
- [ ] `pyproject.toml` + `__init__.py` version → `0.5.1`.
- [ ] PR + merge + tag + `uv build && uv publish` per the standard ship sequence.
- [ ] Post-ship: refresh Cowork so MCP tool schemas pick up `content_type`.

---

## Open questions (resolve during Phase 1)

1. **html2text vs zero-dep regex** — decide based on Phase 1 fallback quality tests.
2. **Link rendering in plain fallback** — `text` alone, or `text (url)`? Recommendation: `text (url)` because it's the one reasonable way to preserve link destinations in plain text.
3. **HTML mode + attachments** — pure orthogonality; attachments should just work. Verify in Phase 2 tests.

## Acceptance criteria

1. `email_send(to, subject, body, content_type="text/html")` round-trips through JMAP → Sent folder → `email_read` with both HTML and plain parts.
2. `email_reply(email_id, body, content_type="text/html", include_quote=True)` produces a threaded HTML reply with the original wrapped as blockquote; thread headers preserved.
3. Default `content_type="text/plain"` behavior across all four tools is byte-identical to v0.5. No regressions.
4. Invalid `content_type` (e.g. `"text/markdown"`) raises `ValueError` with a clear message. No silent fallthrough.
5. CLI `--html` flag exercised end-to-end against live Fastmail for at least `send` and `reply`.
