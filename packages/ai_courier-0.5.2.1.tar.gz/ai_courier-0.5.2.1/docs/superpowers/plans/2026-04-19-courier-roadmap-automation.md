# v0.5 — Courier Roadmap Automation

**Goal:** Eliminate hand-maintenance of `Tech/Courier/courier-roadmap.md` in the vault. A merge to `main` on `iamdadzilla/courier` results in the vault roadmap reflecting the change within 15 minutes, zero human action.

**Scope separation:** This is additive to v0.5's main theme ("Retire Fantastical" — `calendar_update`, `calendar_delete`, `calendar_move`, recurrence editing). Roadmap automation is orthogonal; it can land in the same release without coupling to the calendar-write features.

**Architecture:** Three surfaces — renderer (in-repo, Python), CI (GitHub Actions), sync bridge (local launchd). No runtime coupling to the MCP server; the `courier roadmap` CLI is a one-shot tool, not a server tool.

---

## Source-of-truth split

| Column in the roadmap | Source | Mutability |
|---|---|---|
| Shipped tools + versions | `CHANGELOG.md` section headers + bullet lists | Edited per release (existing habit) |
| Current MCP surface (cross-check) | `src/courier/server.py` `TOOLS = [...]` | Edited per feature (existing habit) |
| Current published version | `pyproject.toml` `project.version` | Bumped per release (existing habit) |
| Open bugs / enhancements | `gh api /repos/iamdadzilla/courier/issues` | GitHub — no repo surface needed |
| Planned rows + release themes | **new:** `docs/roadmap-planned.yaml` | Edited when plans shift |

`docs/roadmap-planned.yaml` is the only new hand-edited surface.

### Proposed yaml shape

```yaml
# docs/roadmap-planned.yaml — editorial source for the "Planned" rows.
releases:
  v0.5:
    target: 2026-05-08
    theme: "Retire Fantastical"
    features:
      - tool: calendar_update
        area: calendar
        notes: "Update existing event fields"
      - tool: calendar_delete
        area: calendar
      - tool: calendar_move
        area: calendar
        notes: "Move event calendar → calendar"
      - tool: null                     # non-tool feature
        area: calendar
        label: "Per-occurrence RSVP / edit (recurrence)"
      - tool: null
        area: calendar
        label: "iTIP REPLY generation to organizer"
        notes: "Only if Fastmail doesn't auto-send"
  v0.6:
    target: 2026-05-15
    theme: "Reliability / CI"
    features:
      - tool: null
        area: infra
        label: "Fake JMAP / replay / backoff"
  v0.7:
    target: 2026-05-22
    theme: "Docs / first-run polish"
    features:
      - tool: null
        area: infra
        label: "mkdocs site"
      - tool: null
        area: infra
        label: "courier setup UX"
  v1.0:
    target: 2026-05-29
    theme: "Public announcement"
    features:
      - tool: null
        area: infra
        label: "HN Show + blog post"

# Out-of-release standing intentions (no target; 💡 enhancements only)
enhancements:
  - area: email
    label: "HTML body support"
    issue: 12
  - area: email
    label: "Triage calibration wizard"
    issue: 5
  - area: multi-account
    label: "Gmail / Workspace provider"
    issue: 2
  - area: multi-account
    label: "iCloud provider"
    issue: 3
  - area: multi-account
    label: "Exchange / Graph provider"
    issue: 1
```

---

## Phase 1 — `courier roadmap` renderer

**Files:** `src/courier/roadmap.py` (new), `src/courier/cli.py` (register verb), `tests/test_roadmap.py` (new).

- [ ] `src/courier/roadmap.py`:
  - `parse_changelog(path) -> list[ReleaseEntry]` — walks `## [X.Y.Z]` sections, extracts `### Added` tool lines matching `- **\`tool_name(args)?\`**`. Returns list of `(version, date, tools_added)`.
  - `load_planned(path) -> PlannedManifest` — parses yaml.
  - `current_tools_from_server_py(path) -> set[str]` — AST-walks `TOOLS = [...]` and pulls `name=` kwargs. Used only for a drift cross-check (warn if CHANGELOG and server.py disagree).
  - `fetch_open_issues() -> list[Issue]` — shells out to `gh api /repos/iamdadzilla/courier/issues?state=open&per_page=100`. Fails loudly if `gh` isn't authenticated (matches the existing "no fallback" style).
  - `render_markdown(changelog, planned, tools, issues, pypi_version) -> str` — emits the exact layout currently in `courier-roadmap.md`, plus the banner (see below).
- [ ] `cli.py`: `courier roadmap [--output PATH]`. Defaults to stdout; `--output` writes (and creates parent dirs).
- [ ] Tests:
  - `test_parse_changelog` — fixture with a synthetic 3-release CHANGELOG; assert exact tool extraction.
  - `test_load_planned` — fixture yaml → typed structs.
  - `test_current_tools_from_server_py` — tiny stub server.py with 2 tools.
  - `test_render_markdown_snapshot` — golden-file test: feed known inputs, compare to `tests/fixtures/roadmap-snapshot.md`.
  - `test_drift_warning` — CHANGELOG lists tool X but server.py doesn't → renderer prints a stderr warning (doesn't fail).
  - `test_fetch_open_issues` uses a recorded `gh` fixture (JSON cassette), NOT live `gh` — network-free.

TDD order: load_planned → parse_changelog → current_tools_from_server_py → render_markdown → fetch_open_issues → CLI wiring.

---

## Phase 2 — Funny banner

Required at the top of every generated `ROADMAP.md`:

```markdown
> 🤖 Auto-generated from `~/Repos/courier`. Don't hand-edit — a launchd
> agent sweeps this file like a Roomba every 15 minutes, and your edits
> will end up in the dust bin along with the cheerios. Instead:
> - Planned rows → edit `docs/roadmap-planned.yaml`
> - Shipped rows → update `CHANGELOG.md` (you do this per release anyway)
> - Bugs / enhancements → [open or close a GitHub issue](https://github.com/iamdadzilla/courier/issues)
> Last regenerated: {ISO timestamp, UTC}
```

Roomba callback is deliberate — matches the project's own thesis ([[courier design discussions]]).

- [ ] Timestamp emitted as `YYYY-MM-DD HH:MM UTC` (second precision would just thrash the diff).
- [ ] Banner is rendered at the very top, above the H1. Obsidian renders blockquotes fine inline.

---

## Phase 3 — GitHub Action

**File:** `.github/workflows/roadmap.yml` (new).

- [ ] Trigger: `push` to `main`, with `paths:` filter:
  ```yaml
  paths:
    - CHANGELOG.md
    - src/courier/server.py
    - docs/roadmap-planned.yaml
    - pyproject.toml
  ```
- [ ] Steps:
  1. checkout (with `fetch-depth: 0` so `gh` can see tags)
  2. setup-python + `pip install -e .`
  3. `courier roadmap --output docs/ROADMAP.md`
  4. `git diff --quiet docs/ROADMAP.md || (git add docs/ROADMAP.md && git commit -m "docs: auto-regenerate ROADMAP.md" && git push)`
- [ ] Runs as `github-actions[bot]`. Needs `contents: write` permission.
- [ ] Skip-commit on empty diff avoids thrash.
- [ ] `GH_TOKEN` auto-provided; `gh api` calls inside the renderer use it without extra config.

**Open question for when we build:** Does the auto-commit trigger a re-run of this same workflow (infinite loop)? Solve with `if: github.actor != 'github-actions[bot]'` or a `[skip ci]` in the commit message.

---

## Phase 4 — Local launchd sync bridge

**File:** `~/Library/LaunchAgents/net.jperry.courier-roadmap-sync.plist` (on Jim's Mac only; not checked into the repo since it's machine-local).

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
  <dict>
    <key>Label</key><string>net.jperry.courier-roadmap-sync</string>
    <key>ProgramArguments</key>
    <array>
      <string>/bin/bash</string>
      <string>-c</string>
      <string>cd /Users/jim/Repos/courier && git pull --rebase --autostash >/dev/null 2>&1 && cmp -s docs/ROADMAP.md /Users/jim/Sync/Hi-Team/Knowledge/Tech/Courier/courier-roadmap.md || cp docs/ROADMAP.md /Users/jim/Sync/Hi-Team/Knowledge/Tech/Courier/courier-roadmap.md</string>
    </array>
    <key>StartInterval</key><integer>900</integer>
    <key>RunAtLoad</key><true/>
    <key>StandardOutPath</key><string>/tmp/courier-roadmap-sync.log</string>
    <key>StandardErrorPath</key><string>/tmp/courier-roadmap-sync.log</string>
  </dict>
</plist>
```

- [ ] Check in a template at `scripts/launchd/net.jperry.courier-roadmap-sync.plist.template` so other contributors can adapt. The actual installed plist is local-only.
- [ ] Scripted install: `scripts/install-roadmap-sync.sh` — renders the template with the local repo path and `launchctl load`s it.
- [ ] Scripted uninstall: `scripts/uninstall-roadmap-sync.sh`.
- [ ] Document both in `README.md` under a new "Vault bridge (optional)" section.

**Brittleness notes:**
- `git pull --rebase --autostash` silently stashes + restores any local edits in the repo. On a laptop that's a dev machine, this is fine. If someone else adopts this pattern, flag it.
- If `git pull` fails (conflict, network), the cp still runs with whatever ROADMAP.md is currently on disk. That's usually what you want — last known good. Worst case: stale vault copy by up to one push.

---

## Phase 5 — Tests, polish, ship

- [ ] README update: short "Roadmap" section pointing at `docs/ROADMAP.md` on GitHub (rendered there too for public visibility).
- [ ] CHANGELOG `[0.5.0]` entry — bullet for the renderer, bullet for the GH Action, note that the vault bridge is local-only.
- [ ] Bump version to `0.5.0` — expect v0.5 main theme (Retire Fantastical) to bump too, don't double-bump.
- [ ] Delete the current hand-rolled `Tech/Courier/courier-roadmap.md` **one release after** the automation goes live. Keep both for one cycle to confirm the machine output matches expectations.

---

## Out of scope (explicit non-goals)

- **Webhooks from GitHub → Jim's Mac.** Too much infrastructure for a roadmap file.
- **Putting the vault in git.** Separate, larger decision.
- **Symlinking the vault file to the repo file.** Rejected — Obsidian + Sync.com + symlinks have historically been weird.
- **Editing the roadmap from Obsidian.** Banner reminds Jim; enforcement is social.

---

## Acceptance criteria

1. `courier roadmap` CLI produces a markdown roadmap identical to the hand-curated v0.4.1 version (within whitespace and the timestamp line) when fed the current repo state.
2. A push to main that bumps `CHANGELOG.md` results in `docs/ROADMAP.md` updating within one CI run and the vault copy updating within one launchd tick (max 15 min).
3. Hand-edit the vault file → next launchd tick reverts it silently. (Manual acceptance: edit once, wait, check.)
4. `gh` unavailability fails fast with a clear error; doesn't emit a half-rendered file.
5. Unit tests cover parsers, render golden, and drift warnings. Full suite stays green.
