> 🤖 Auto-generated from `~/Repos/courier`. Don't hand-edit — a launchd
> agent sweeps this file like a Roomba every 15 minutes, and your edits
> will end up in the dust bin along with the cheerios. Instead:
> - Planned rows → edit `docs/roadmap-planned.yaml`
> - Shipped rows → update `CHANGELOG.md` (you do this per release anyway)
> - Bugs / enhancements → [open or close a GitHub issue](https://github.com/iamdadzilla/courier/issues)
>
> Last regenerated: 2026-04-22 21:47 UTC

# Courier MCP — Feature Roadmap (v0.5.2.1)

## Shipped

| Version | Date | Tools |
|---------|------|-------|
| ✅ v0.5.2.1 | 2026-04-22 | _(no new tools)_ |
| ✅ v0.5.2 | 2026-04-22 | _(no new tools)_ |
| ✅ v0.5.1 | 2026-04-22 | `email_inbox` |
| ✅ v0.5.0 | 2026-04-21 | `calendar_update`, `calendar_delete`, `calendar_move` |
| ✅ v0.4.1 | 2026-04-19 | `calendar_free_both` |
| ✅ v0.4.0 | 2026-04-19 | `email_sent_since`, `email_thread_digest`, `email_forward`, `calendar_rsvp` |
| ✅ v0.3.3 | 2026-04-17 | _(no new tools)_ |
| ✅ v0.3.2 | 2026-04-17 | _(no new tools)_ |
| ✅ v0.3.1 | 2026-04-17 | _(no new tools)_ |
| ✅ v0.3.0 | 2026-04-17 | _(no new tools)_ |
| ✅ v0.2.0 | 2026-04-16 | _(no new tools)_ |
| ✅ v0.1.0 | 2026-04-13 | _(no new tools)_ |

## Planned

### 📋 v0.5 — Retire Fantastical
_Target: 2026-05-08_

- **courier_roadmap** (infra) — Auto-regenerate Tech/Courier/courier-roadmap.md via GH Action + launchd bridge
- **iTIP REPLY probe** (calendar) — Probe documented Fastmail doesn't auto-send; Phase C.2 (Courier-built REPLY) deferred

### 📋 v0.5.1 — Inbox overflow fix
_Target: 2026-04-22 (shipped — emergency)_

_(all features now shipped)_

### 📋 v0.5.2 — HTML email body
_Target: 2026-04-22 (shipped)_

- **content_type="text/html" on all four write tools** (email) — email_send / email_reply / email_forward / email_draft with auto-generated plain-text fallback + HTML-aware reply quoting

### 📋 v0.5.3 — Recurrence + client-LLM guidance + saturation signal
_Target: TBD_

- **Per-occurrence recurrence editing (RECURRENCE-ID overrides)** (calendar)
- **MCP Server(instructions=...) + per-tool description audit** (infra) — Move design principles (triage-first, email_read for deep-read, etc.) into the MCP manifest so fresh clients pick them up without config.
- **email_inbox saturation signal (`_meta.saturated`) + default limit bump** (email) — Surface "more available" when inbox > limit so sweeps don't silently clip the tail.

### 📋 v0.6 — Reliability / CI
_Target: 2026-05-15_

- **Fake JMAP harness + replay mode** (infra)
- **Exponential backoff on JMAP/CalDAV network errors** (infra)

### 📋 v0.7 — Docs / first-run polish
_Target: 2026-05-22_

- **mkdocs documentation site** (infra)
- **courier setup UX improvements** (infra)

### 📋 v1.0 — Public announcement
_Target: 2026-05-29_

- **HN Show + blog post ("Your AI Agent Deserves Its Own Email Client")** (infra)

## Open Enhancements

- 💡 **Triage calibration wizard** (email) — [#5](https://github.com/iamdadzilla/courier/issues/5)
- 💡 **Gmail / Workspace provider** (multi-account) — [#2](https://github.com/iamdadzilla/courier/issues/2)
- 💡 **iCloud provider** (multi-account) — [#3](https://github.com/iamdadzilla/courier/issues/3)
- 💡 **Exchange / Graph provider** (multi-account) — [#1](https://github.com/iamdadzilla/courier/issues/1)
