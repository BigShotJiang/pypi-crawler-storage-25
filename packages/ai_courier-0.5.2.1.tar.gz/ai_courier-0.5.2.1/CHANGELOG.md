# Changelog

All notable changes to Courier are documented here. Format loosely based on
[Keep a Changelog](https://keepachangelog.com/); versioning follows SemVer.

## [0.5.2.1] — 2026-04-22

Phase C.2 — Courier now sends iTIP REPLY emails to organizers when an
attendee RSVPs, closing the half-complete-RSVP gap documented in v0.5.1.
Fast-tracked for Richard's onboarding so his `calendar_rsvp` calls
actually reach the organizer's calendar.

### Added

- **`_rsvp_with_notification` orchestrator** in `server.py` — combines the
  existing `CalDAVClient.rsvp` PARTSTAT update with a Courier-built iTIP
  REPLY email to the organizer. The `calendar_rsvp` MCP tool now calls
  through this orchestrator.
- **`notify_organizer: bool = True`** parameter on `calendar_rsvp`. Opt
  out per-call when you only want to update the local calendar
  (rare — useful for backfilling PARTSTAT on historical events).
- **Pure helpers on `CalDAVClient`:**
  - `_build_itip_reply(source_ical, attendee_email, partstat, now_iso?)` —
    builds a proper RFC 5546 REPLY VCALENDAR with `METHOD:REPLY`,
    exactly one ATTENDEE line (the responder's), correct SEQUENCE.
  - `_extract_organizer_email(ical)` — handles bare and param-laden
    `ORGANIZER:mailto:…` / `ORGANIZER;CN=…:mailto:…`.
  - `_extract_event_summary(ical)` — first SUMMARY line.
- **E2E regression test** (`tests/e2e/test_itip_reply_probe.py`) flipped
  from "asserts no REPLY" → "asserts REPLY received." Live-green
  against Fastmail in 84s.

### Behavior

After `calendar_rsvp(event_uid, "accepted")` now:
1. Local calendar PARTSTAT updates (unchanged from v0.4.0).
2. A new email to the organizer lands in Sent, subject prefixed
   "Accepted:" (or "Tentative:" / "Declined:"), with a
   `text/calendar; method=REPLY; charset=utf-8` attachment carrying
   the REPLY VCALENDAR.
3. Organizer's mail client / calendar auto-processes the attachment
   and updates their view of who's coming.

### Error semantics

If the PARTSTAT update succeeds but the notification email fails
(upload blob / send_email errors), the overall RSVP is still
"successful" — the local calendar is authoritative. The returned
dict carries `notify_status: "failed: <exc>"` so the caller can
decide to retry manually.

If the event has no `ORGANIZER` (self-created events), `notify_status`
is `"skipped: event has no ORGANIZER"` — silently correct, no error.

### Scope note

Bumped from v0.5.3 to a v0.5.2.1 dot-dot because Richard needs this
working now. Remaining v0.5.3 items (per-occurrence recurrence,
MCP `Server(instructions=...)` #28, `email_inbox` saturation signal
#31) unchanged.

## [0.5.2] — 2026-04-22

HTML email body support. Closes [#12](https://github.com/iamdadzilla/courier/issues/12).

All four write tools (`email_send`, `email_reply`, `email_forward`,
`email_draft`) now accept a `content_type` parameter. `"text/plain"` (default)
is byte-identical to v0.5.1 behavior — no breaking changes. `"text/html"`
sends `multipart/alternative` with an auto-generated plain-text fallback so
every receiver client renders correctly.

### Added

- **`content_type` parameter** on all four write MCP tools + their CLI
  siblings (`courier forward --html`, `courier reply --html`). Accepts
  `"text/plain"` (default) or `"text/html"`; anything else raises
  `ValueError`.
- **`JMAPClient._strip_to_text(html) -> str`** — pure, zero-dep HTML-to-plain
  converter used to auto-generate the plain-text twin for
  `multipart/alternative`. Handles paragraph breaks, `<br>`, lists,
  anchors (link URL preserved in parens), and HTML entities via
  `html.unescape`.
- **HTML-aware reply quoting.** When `include_quote=True` + `content_type="text/html"`,
  the quoted-original block renders as `<blockquote><pre>…</pre></blockquote>`
  with HTML-escaped body_text. Injection-safe: `<script>` tags from the
  original are escaped before inclusion.
- Unit tests: 22 new cases covering the stripper, `_build_email_body` wire
  format, content_type validation, and reply-quote HTML shape.
- E2E tests: HTML round-trip against live Fastmail (send → fetch → verify
  plain fallback contains marker + stripped anchor URL + list items);
  plain-text default regression guard.

### Non-goals for this release

- **Per-occurrence recurrence editing** (RECURRENCE-ID overrides) — deferred to v0.5.3.
- **Phase C.2 iTIP REPLY generator** — deferred to v0.5.3.
- **MCP `Server(instructions=...)` + per-tool description audit** ([#28](https://github.com/iamdadzilla/courier/issues/28)) — deferred to v0.5.3.
- **`match_sender` shorthand** for `content_type` — explicit only in v0.5.2; inferring from the original's Content-Type is future work.

### Design note

`email_inbox` is a triage surface; the HTML body support is for the
**write** path specifically. The 200-char snippet default introduced in
v0.5.1 continues to bound `email_inbox` payloads regardless of what
content_type the senders used.

## [0.5.1] — 2026-04-22

Emergency dot release. Fixes a silent-failure mode in `email_inbox` where
HTML-heavy inboxes overflowed Claude's inline-read budget and the sweep
was reduced to visibility on the first 1–2 emails. See incident report
`Tech/Courier/incident-2026-04-22-inbox-overflow.md` (vault) for the
post-mortem.

### Changed

- **`email_inbox` default body is now a 200-char snippet**, down from the
  previous 500-char truncation. `Email.summary()`'s `max_body` default also
  drops 500 → 200. Payload for a 50-email inbox falls from ~47 KB to ~35 KB
  in the measured sample — enough headroom to handle HTML-heavy days without
  tripping Cowork's persist-to-file behavior.

### Added

- **`email_inbox(body_mode="snippet" | "none")`** — new MCP parameter.
  `snippet` (default) keeps the 200-char body; `none` omits body entirely
  for the smallest possible payload (~50% of the v0.5.0 default). Useful
  when sender + subject + triage_reason are enough to drive the next step.
- `Email.summary(include_body=False)` at the Python layer — what the new
  `body_mode="none"` MCP path calls through to.
- E2E regression probe (`tests/e2e/test_inbox_snippet_v051.py`) that
  asserts the 50-email snippet payload stays under 40 KB. Fails loudly if
  a future change regresses the size.

### Philosophy

`email_inbox` is a **triage surface**, not a full-read surface. Full bodies
are the job of `email_read(email_id)`. Default shrunk accordingly.

## [0.5.0] — 2026-04-21

The **"Retire Fantastical"** release. Courier is now a full-surface CalDAV
client — Jim's Fantastical MCP can come out of the tool policy for day-to-day
work with no capability regression. Ships PRs A + B + C + D of the v0.5 plan.

### Added

- **`calendar_update(event_uid, summary=?, start=?, end=?, location=?, description=?, attendees=?, show_as=?)`** —
  update any subset of fields on an existing event. Bare-date strings on
  `start`/`end` switch to VALUE=DATE (all-day); datetimes emit UTC Z form.
  Recurring events emit a `UserWarning` and the master is updated (per-occurrence
  editing is v0.5.2 scope). Guards against iCal injection (rejects CRLF in string
  fields) and mixed DTSTART/DTEND timing.
- **`calendar_delete(event_uid)`** — delete by UID. MCP-level failure is loud
  (`ValueError` on unknown UID); the underlying `CalDAVClient.delete_event`
  returns `False` for callers that want graceful semantics.
- **`calendar_move(event_uid, target_calendar)`** — move an event between
  calendars on the primary account. Non-atomic under the hood (CalDAV has no
  MOVE verb); delete-then-save with rollback. Save-first would hit Fastmail's
  cross-calendar UID-uniqueness check and 403.
- **`courier roadmap [--output PATH]`** CLI verb — renders the feature roadmap
  from `CHANGELOG.md` + `docs/roadmap-planned.yaml` + `server.py` TOOLS +
  `pyproject.toml`. Pure Python, no network.
- **`docs/roadmap-planned.yaml`** — new editorial source for planned rows
  and release themes. Shipped rows still come from `CHANGELOG.md`.
- **`.github/workflows/roadmap.yml`** — auto-regenerates `docs/ROADMAP.md`
  on push-to-main whose paths touch CHANGELOG, server.py, the yaml, or
  pyproject. Writes and commits back with `[skip ci]`; bot-actor guard prevents
  recursion.
- **`scripts/launchd/` + install/uninstall scripts** — per-machine bridge that
  polls the repo every 15 minutes and copies `docs/ROADMAP.md` into the Obsidian
  vault's `Tech/Courier/courier-roadmap.md`. Template-based; installed with
  `scripts/install-roadmap-sync.sh`.
- CLI verbs for each new tool: `courier update`, `courier delete`, `courier
  move-event`, `courier roadmap`.

### Probed (no code change — captured as regression signal)

- **Fastmail CalDAV does NOT auto-send iTIP REPLY** on PARTSTAT change. Verified
  by `tests/e2e/test_itip_reply_probe.py` — `calendar_rsvp` updates the calendar
  only; the organizer is not notified. Phase C.2 (Courier-built REPLY generator)
  is deferred to v0.5.2. `rsvp()` docstring and the `calendar_rsvp` MCP tool
  description now surface this limitation to agents. If Fastmail ever starts
  auto-sending, the regression test flips and Phase C.2 becomes removable.

### Changed

- `CalDAVClient.delete_event` refactored onto a shared `_find_event_by_uid`
  helper — reused by `update_event`, `move_event`, and the existing `rsvp`.

### Scope notes

- Per-occurrence recurrence editing (`RECURRENCE-ID` overrides) is an explicit
  non-goal for v0.5 — deferred to v0.5.2. Recurring events still update the
  master only, with a warning.
- Delegate calendars remain read-only. Cross-account writes (e.g., `calendar_move`
  to a delegate calendar) are a legitimate future feature but require the
  delegate app-password scope to cover writes — out of v0.5.
- Phase C.2 (iTIP REPLY generator) and HTML email body support (v0.5.1) are the
  two known leftovers from this release arc, both tracked in `docs/roadmap-planned.yaml`.

## [0.4.1] — 2026-04-19

Closes PR C of the v0.4 plan: cross-account free/busy (Jim + Richard,
or any set of configured calendars). No breaking changes; `delegate_accounts`
is optional and pre-v0.4.1 configs load unchanged.

### Added
- **`calendar_free_both(accounts, start, end, slot_minutes, working_hours, working_days)`**
  — MCP tool that unions busy intervals across two or more configured
  calendars and returns slots free on all of them. Honors RFC 5545
  TRANSP (transparent events don't block) and skips all-day events.
  Scales to N accounts; primary + any number of delegates.
- **`delegate_accounts: list[AccountConfig]`** on `CourierConfig` —
  read-only calendar accounts scoped to free/busy queries. Each delegate
  carries its own CalDAV app password; no JMAP token required.
- **`courier add-delegate`** CLI verb — interactive prompt to register
  a delegate calendar account. Appends to `delegate_accounts` in
  `~/.config/courier/config.json`.
- **`courier free-both <email1> <email2> …`** CLI verb — cross-account
  free-slot report on the command line. Supports `--start`, `--end`,
  `--slot`, `--all-hours`, `--start-hour`, `--end-hour`.
- **`CalDAVClient.free_busy_multi(clients, …)`** static method —
  programmatic entry point; takes a list of CalDAV clients and a time
  range, returns unioned free slots.
- **Pure helpers `_free_slots_from_event_lists` and `_compute_free_slots`**
  on `CalDAVClient` — the merge logic factored out for unit-testability
  without network. Also used internally by single-account `free_busy`
  (one fewer copy of the gap/constraint algorithm).

### Changed
- **`free_busy` refactored to delegate to `_free_slots_from_event_lists`.**
  Behavior preserved — same unit tests pass unchanged.

### Tests
- 8 new unit tests in `tests/test_cal_v04.py` covering the merge logic:
  unions non-overlapping and overlapping busy from multiple accounts,
  respects `slot_minutes` threshold, honors working-hours + working-days
  constraints, skips transparent + all-day events.
- 6 new unit tests in `tests/test_config.py` for delegate persistence:
  default empty, round-trip, pre-v0.4.1 backward-compat, multiple delegates.
- 2 new unit tests in `tests/test_cli.py` covering `add-delegate`
  append semantics.
- 2 new E2E tests in `tests/e2e/test_calendar_v041.py`, gated on
  `COURIER_DELEGATE_CONFIGURED=1`, that verify live multi-account
  free/busy without writing to the delegate's calendar.

## [0.4.0] — 2026-04-19

The "Agent-Shape Depth" release — four new tools that collapse the most
common multi-call patterns into first-class MCP primitives, plus one
long-standing send-path bug fix. The morning sweep drops from ~8 tool
calls to ~3. Ships PRs A + B of the v0.4 plan; `calendar_free_both`
(cross-account free/busy) remains in the v0.4.1 backlog pending delegate
credentials.

### Added
- **`email_sent_since(after, limit)`** — dedicated sent-mail primitive
  that queries the Sent mailbox directly via JMAP. Replaces the brittle
  `email_search(from=me, after=...)` chain the sweep skill used — the
  old pattern did a full-text search across indexed received mail and
  frequently missed recent sends.
- **`email_thread_digest(thread_id, max_tokens)`** — compact,
  quote-stripped thread payload trimmed to a token budget. Strips three
  quote patterns: Outlook `-----Original Message-----`, Gmail "On
  &lt;date&gt;, &lt;sender&gt; wrote:" attributions, and bare trailing
  `>`-prefixed blocks. Returns `truncated=True` when the thread exceeds
  the budget.
- **`email_forward(email_id, to, body, include_original=True, send=False)`**
  — the missing write verb. Downloads the original's raw RFC 5322 MIME
  via `Email.blobId` (RFC 8621 §4.1.1) and re-attaches it as a
  `message/rfc822` `.eml`. Draft by default, matching `email_reply`
  semantics.
- **`calendar_rsvp(event_uid, response)`** — respond to an invite with
  `accepted` / `tentative` / `declined`. Updates `PARTSTAT` on the
  `ATTENDEE` line matching this account's email. Closes the loop
  started by v0.2's `has_calendar_invite` detection.
- **`Email.blob_id`** — new field on the dataclass exposing the
  raw-MIME reference so callers don't need a second `Email/get`.
- CLI verbs for every new tool: `courier sent`, `courier digest`,
  `courier forward`, `courier rsvp`.

### Fixed
- **`send_email` was stranding every submitted draft in Drafts** with
  `$draft` keyword intact. Fastmail's webmail sets
  `onSuccessUpdateEmail` on `EmailSubmission/set` so the draft
  atomically moves into Sent and loses `$draft` — we weren't. Every
  Courier-originated email (via `email_send`, `email_reply`,
  `email_forward`) had been silently leaking into Drafts since v0.2.
  Exposed by `email_sent_since`: the new tool correctly listed the
  Sent mailbox, and expected Courier-originated messages to appear
  there. They didn't, because they weren't actually in Sent. Fix per
  RFC 8621 §7.3: atomic — if submission fails the Email is untouched.

### Changed
- **`test_cleanup` default prefix widened** from `[courier-e2e` to
  `[courier-` — now sweeps ad-hoc probe artifacts (`[courier-probe*]`)
  alongside fixture leaks. All existing E2E test subjects already
  start `[courier-e2e` which is a substring of the new default, so no
  test breakage.

### Scope notes
- Recurring-event RSVP updates the master only; per-occurrence RSVP
  and iTIP `REPLY` generation are v0.5 scope.
- `email_forward` does not unfold RFC 5545 §3.1 long-line
  continuations in attendee lines. Fails loudly if encountered — no
  silent partial unfold.

## [0.3.3] — 2026-04-17

### Added
- **`show_as` parameter on `calendar_create`** — mark events as "busy" (default)
  or "free" per RFC 5545 §3.8.2.7 (the `TRANSP` property). Use `show_as="free"`
  for events that should appear on the calendar but leave the slot available
  in free/busy queries — e.g. a colleague's session you're monitoring, an
  informational hold, or a travel day that doesn't truly block your schedule.
  Honored by Fastmail web, Apple Calendar, and every RFC-compliant CalDAV
  client.
- **`Event.show_as`** — new field on the event dataclass, populated from the
  `TRANSP` property on read. Surfaced in `summary_dict()` when non-default.

### Fixed
- `CalDAVClient.free_busy` was counting every non-all-day event as busy,
  ignoring `TRANSP:TRANSPARENT`. Transparent events now correctly leave
  their slot available in free/busy queries — matching what Fastmail web
  and Apple Calendar already show and what RFC 5545 §3.8.2.7 requires.

## [0.3.2] — 2026-04-17

### Changed
- **PyPI package renamed from `courier-mcp` to `ai-courier`** ahead of first
  public PyPI release. Avoids collision with the unrelated `@trycourier/courier-mcp`
  (Courier Inc.'s notification-API MCP server on npm) and positions the name
  for cross-provider ambition — future Gmail / Exchange / Apple bindings
  stay inside the same package rather than being stuck with a Fastmail-
  flavored name.
- Install changes from `pip install courier-mcp` → `pip install ai-courier`.
- Everything else unchanged: repo stays `iamdadzilla/courier`, CLI verb
  stays `courier`, MCP server command stays `courier-mcp`, project and
  brand stay "Courier". Only the PyPI distribution name moves.

## [0.3.1] — 2026-04-17

### Added
- **`courier test-cleanup`** — sweep stray `[courier-e2e*]` test artifacts
  from all mailboxes to Trash. Idempotent; filters out already-trashed
  matches. Addresses the fixture-teardown orphan problem surfaced after
  the first live Fastmail-MCP-free sweep.

## [0.3.0] — 2026-04-17

### Added
- **Folder filing** — `email_mailboxes` lists folders/labels with paths;
  `email_move(ids, to)` moves to a mailbox by ID, name, or path
  (`"Clients/Guardian"`); `email_label(ids, labels, add)` adds/removes
  mailbox memberships without touching other memberships.
- **Threaded reply** — `email_reply(email_id, body, send, include_quote)`
  composes a proper reply (In-Reply-To, References, `Re:` prefix,
  Reply-To-or-From To: resolution); creates a draft by default.
- **E2E test suite** — `tests/e2e/`, opt-in via `COURIER_LIVE_TESTS=1`,
  self-cleaning via a `Courier/Tests` mailbox and `Courier Tests`
  calendar. New `courier test-setup` CLI command creates the sandbox.
- CLI verbs: `courier mailboxes`, `courier move`, `courier label`,
  `courier reply`, `courier test-setup`.
- `Email.message_id` and `Email.reply_to_addrs` — extracted from JMAP.

### Fixed
- `_normalize_utcdate` silently passed non-UTC offsets through, so
  `datetime.now(tz=UTC).isoformat()` output returned empty search
  results with no error. Now validates via `datetime.fromisoformat`
  and rejects non-UTC offsets with `ValueError`.
- `create_draft` sent `inReplyTo` as a string, but RFC 8621 §4.1.3.1
  types it as `String[]`. Fastmail rejected threaded draft creates.
  Now wrapped in a list; parsing normalizes list-or-string-or-None
  back to the existing `Email.in_reply_to: str | None` contract.
- `pyproject.toml` now sets `asyncio_default_test_loop_scope = "session"`
  so function-scoped tests share the session-scoped fixtures' event loop.

### Changed
- `__version__` corrected to `0.3.0` (was stale at `0.1.0` through v0.2).

### Migration
Agents using Courier can now retire Fastmail MCP entirely — all
previous filing and threaded-reply operations now have Courier
equivalents. See `docs/superpowers/specs/2026-04-17-courier-v0.3-design.md`
for the full mapping.

## [0.2.0] — 2026-04-16

### Added
- **Attachment support**
  - `Attachment` dataclass + `Email.attachments` list, populated from
    JMAP `bodyStructure` walk.
  - `JMAPClient.download_blob()` and `upload_blob()` using the session's
    `downloadUrl` / `uploadUrl` templates (RFC 8620 §6.2).
  - `create_draft()` / `send_email()` accept attachments — `send_email`
    takes `attachment_paths` and handles upload.
  - MCP tools `email_attachments` (list) and `email_attachment_save`
    (download to local path). `email_send` gains optional `attachment_paths`.
  - CLI `courier attachments <email_id>` and `courier download <email_id> <dest>`.
  - `courier read` now shows attachment list in the header.

- **Calendar invite MIME detection**
  - `Email.has_calendar_invite` populated by walking `bodyStructure` for
    `text/calendar` parts.
  - New triage guard `requires_calendar_invite`.
  - Default rule `calendar-invite-mime` (actionable, confidence 0.95).

- **Calendar event deduplication** across calendars via `(uid, recurrence_id)`.

- **All-day event support** in `create_event` + `calendar_create` MCP tool.
  All-day events emit `VALUE=DATE` per RFC 5545 §3.6.1.

### Changed
- `free_busy` gains `working_hours` and `working_days` parameters; gaps are
  split at day boundaries and trimmed to the working window when set.
- `courier free` defaults to Mon–Fri 09:00–17:00 local; flags `--all-hours`,
  `--start-hour`, `--end-hour` added.
- `courier free` CLI shows end date when a slot crosses midnight (previously
  displayed only the end time, which hid the date and looked wrong).

### Fixed
- `free_busy` previously reported multi-day 24/7 gaps (e.g. a 77-hour
  Friday-evening-through-Monday-morning slot) when there were no meetings
  over a weekend. These are now properly constrained and split by day.

## [0.1.0] — 2026-04-13

- Initial release. JMAP email client, CalDAV calendar client, rule-based
  triage, MCP server, CLI. Fastmail-only.
