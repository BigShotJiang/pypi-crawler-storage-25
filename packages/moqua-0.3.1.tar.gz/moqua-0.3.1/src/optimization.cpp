
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <cmath>
#include <complex>
#include <vector>
#include <random>
#include <iostream>
#include <algorithm>
#include <limits>

#include "lets_be_rational.h"
#include "rolling_ols.h"

namespace py = pybind11;

// ==========================================
// CONSTANTS & UTILS
// ==========================================
const double PI = 3.14159265358979323846;

// ==========================================
// HESTON PRICING ENGINE (Manual Integration)
// ==========================================
// Characteristic Function of ln(S_T)
std::complex<double> heston_characteristic_function(std::complex<double> u, double S0, double T, double r, 
                                                    double v0, double kappa, double theta, double sigma, double rho) {
    std::complex<double> i(0.0, 1.0);
    
    // Albrecher et al. formulation
    std::complex<double> xi = kappa - sigma * rho * i * u;
    std::complex<double> d = std::sqrt(xi*xi + sigma*sigma * (u*u + i*u));
    
    std::complex<double> g_num = xi - d;
    std::complex<double> g_den = xi + d;
    std::complex<double> g = g_num / g_den;
    
    std::complex<double> A_term = (kappa * theta) / (sigma*sigma) * ((xi - d) * T - 2.0 * std::log((1.0 - g * std::exp(-d * T)) / (1.0 - g)));
    std::complex<double> B_term = (v0 / (sigma*sigma)) * ((xi - d) * (1.0 - std::exp(-d * T)) / (1.0 - g * std::exp(-d * T)));
    
    return std::exp(A_term + B_term + i * u * (std::log(S0) + r * T));
}

// Manual Trapezoidal Integration
double integrate_trapezoidal(std::function<double(double)> func, double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.5 * (func(a) + func(b));
    for (int i = 1; i < n; ++i) {
        sum += func(a + i * h);
    }
    return sum * h;
}

double heston_call_price_cpp(double S0, double K, double T, double r, 
                             double v0, double kappa, double theta, double sigma, double rho) {
    
    // Integration limit and steps
    double limit = 200.0;
    int steps = 200; // 200 steps is usually enough for Gil-Pelaez if limit is reasonable
    
    auto P1_integrand = [&](double u) -> double {
        if (u == 0.0) return 0.0;
        std::complex<double> cu(u, 0.0);
        std::complex<double> num = std::exp(std::complex<double>(0.0, -1.0) * cu * std::log(K)) * 
                                   heston_characteristic_function(cu - std::complex<double>(0.0, 1.0), S0, T, r, v0, kappa, theta, sigma, rho);
        std::complex<double> denom = std::complex<double>(0.0, 1.0) * cu * S0 * std::exp(r * T);
        return (num / denom).real();
    };

    auto P2_integrand = [&](double u) -> double {
        if (u == 0.0) return 0.0;
        std::complex<double> cu(u, 0.0);
        std::complex<double> num = std::exp(std::complex<double>(0.0, -1.0) * cu * std::log(K)) * 
                                   heston_characteristic_function(cu, S0, T, r, v0, kappa, theta, sigma, rho);
        std::complex<double> denom = std::complex<double>(0.0, 1.0) * cu;
        return (num / denom).real();
    };
    
    double int1 = integrate_trapezoidal(P1_integrand, 1e-5, limit, steps); // Start slightly > 0 to avoid singularity
    double int2 = integrate_trapezoidal(P2_integrand, 1e-5, limit, steps);
    
    double P1 = 0.5 + (1.0 / PI) * int1;
    double P2 = 0.5 + (1.0 / PI) * int2;
    
    return S0 * P1 - K * std::exp(-r * T) * P2;
}

// Implied Volatility (Jäckel) - Kept for legacy compatibility
double implied_volatility(double price, double F, double K, double T, double q) {
    return ImpliedBlackVolatility(price, F, K, T, q);
}

// BINDING
PYBIND11_MODULE(_cpp_core, m) {
    m.doc() = "Optimization module with Jackel IV and Heston Calibration";
    
    m.def("implied_volatility", &implied_volatility, "Jäckel IV");
    
    // Calibrations removed (moved to Python)
    // m.def("calibrate_heston_de", ...);
    
    m.def("heston_call_price", &heston_call_price_cpp, "Heston Pricing (Trapezoidal)");

    m.def("rolling_ols", &rolling_ols, "Rolling OLS (3 Regressors)",
          py::arg("y"), py::arg("x1"), py::arg("x2"), 
          py::arg("window"), py::arg("min_obs"), py::arg("ridge_lambda")=0.0);

    m.def("fast_adf", &fast_adf, "Fast Augmented Dickey-Fuller Test",
          py::arg("y"), py::arg("max_lag"), py::arg("regression")="c", py::arg("autolag")="AIC");

    m.def("fast_kpss", &fast_kpss, "Fast KPSS Test",
          py::arg("y"), py::arg("regression")="c", py::arg("nlags")="auto");
}
