#include "rolling_ols.h"
#include <vector>
#include <cmath>
#include <iostream>
#include <limits>
#include <numeric>
#include <algorithm>

// Helper to inverse 3x3 symmetric matrix
// Matrix is:
// [ m00 m01 m02 ]
// [ m01 m11 m12 ]
// [ m02 m12 m22 ]
bool invert_3x3_sym(const double A[3][3], double Inv[3][3]) {
    double det = A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1]) -
                 A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0]) +
                 A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]);

    if (std::abs(det) < 1e-12) return false;

    double invDet = 1.0 / det;

    Inv[0][0] = (A[1][1] * A[2][2] - A[1][2] * A[2][1]) * invDet;
    Inv[0][1] = (A[0][2] * A[2][1] - A[0][1] * A[2][2]) * invDet;
    Inv[0][2] = (A[0][1] * A[1][2] - A[0][2] * A[1][1]) * invDet;

    Inv[1][0] = Inv[0][1]; // Symmetric
    Inv[1][1] = (A[0][0] * A[2][2] - A[0][2] * A[2][0]) * invDet;
    Inv[1][2] = (A[1][0] * A[0][2] - A[0][0] * A[1][2]) * invDet;

    Inv[2][0] = Inv[0][2];
    Inv[2][1] = Inv[1][2];
    Inv[2][2] = (A[0][0] * A[1][1] - A[1][0] * A[0][1]) * invDet;

    return true;
}

std::map<std::string, py::array_t<double>> rolling_ols(
    py::array_t<double> y_array,
    py::array_t<double> x1_array,
    py::array_t<double> x2_array,
    int window,
    int min_obs,
    double ridge_lambda
) {
    auto y = y_array.unchecked<1>();
    auto x1 = x1_array.unchecked<1>();
    auto x2 = x2_array.unchecked<1>();

    Py_ssize_t n = y.shape(0);
    if (x1.shape(0) != n || x2.shape(0) != n) {
        throw std::runtime_error("Input arrays must have the same length");
    }

    // Allocate outputs initialized to NaN
    auto alpha = py::array_t<double>(n);
    auto b1 = py::array_t<double>(n);
    auto b2 = py::array_t<double>(n);
    auto yhat = py::array_t<double>(n);
    auto r2 = py::array_t<double>(n);
    
    // We initialize ptrs for fast access
    double* ptr_alpha = alpha.mutable_data();
    double* ptr_b1 = b1.mutable_data();
    double* ptr_b2 = b2.mutable_data();
    double* ptr_yhat = yhat.mutable_data();
    double* ptr_r2 = r2.mutable_data();

    // Fill with NaNs
    double nan = std::numeric_limits<double>::quiet_NaN();
    for(Py_ssize_t i=0; i<n; ++i) {
        ptr_alpha[i] = nan;
        ptr_b1[i] = nan;
        ptr_b2[i] = nan;
        ptr_yhat[i] = nan;
        ptr_r2[i] = nan;
    }

    // Temp buffers for loop
    // XtX is 3x3, XtY is 3x1
    double XtX[3][3];
    double XtY[3];
    double Inv[3][3];

    for (Py_ssize_t t = window - 1; t < n; ++t) {
        Py_ssize_t start = t - window + 1;
        
        // Reset accumulators
        for(int i=0; i<3; ++i) {
            XtY[i] = 0.0;
            for(int j=0; j<3; ++j) XtX[i][j] = 0.0;
        }

        int count = 0;
        double sum_y = 0.0;
        double sum_yy = 0.0; // sum of y^2 for TSS

        for (Py_ssize_t k = start; k <= t; ++k) {
            double Y = y(k);
            double X1 = x1(k);
            double X2 = x2(k);

            if (std::isfinite(Y) && std::isfinite(X1) && std::isfinite(X2)) {
                // X row is [1.0, X1, X2]
                // XtX update
                XtX[0][0] += 1.0;
                XtX[0][1] += X1;
                XtX[0][2] += X2;
                
                XtX[1][1] += X1 * X1;
                XtX[1][2] += X1 * X2;
                
                XtX[2][2] += X2 * X2;

                // XtY update
                XtY[0] += Y;
                XtY[1] += X1 * Y;
                XtY[2] += X2 * Y;

                sum_y += Y;
                sum_yy += Y * Y;
                count++;
            }
        }


        // Symmetric fill
        XtX[1][0] = XtX[0][1];
        XtX[2][0] = XtX[0][2];
        XtX[2][1] = XtX[1][2];

        if (count < std::max(min_obs, 3)) continue;

        // Add Ridge
        if (ridge_lambda > 0) {
            XtX[0][0] += ridge_lambda;
            XtX[1][1] += ridge_lambda;
            XtX[2][2] += ridge_lambda;
        }

        // Solve: Beta = Inv(XtX) * XtY
        if (!invert_3x3_sym(XtX, Inv)) continue; // Singular

        double beta0 = Inv[0][0]*XtY[0] + Inv[0][1]*XtY[1] + Inv[0][2]*XtY[2];
        double beta1 = Inv[1][0]*XtY[0] + Inv[1][1]*XtY[1] + Inv[1][2]*XtY[2];
        double beta2 = Inv[2][0]*XtY[0] + Inv[2][1]*XtY[1] + Inv[2][2]*XtY[2];

        // Store computation
        ptr_alpha[t] = beta0;
        ptr_b1[t] = beta1;
        ptr_b2[t] = beta2;
        
        // Compute yhat for current time t
        // Needs current X values (at time t)
        // Check if current is valid
        double Y_now = y(t);
        double X1_now = x1(t);
        double X2_now = x2(t);
        
        if (std::isfinite(Y_now) && std::isfinite(X1_now) && std::isfinite(X2_now)) {
            double yh = beta0 + beta1 * X1_now + beta2 * X2_now;
            ptr_yhat[t] = yh;
            
            // R2 calculation for the WINDOW
            double rss = sum_yy - (beta0*XtY[0] + beta1*XtY[1] + beta2*XtY[2]);
            double mean_y = sum_y / count;
            double tss = sum_yy - count * mean_y * mean_y;
            
            if (tss > 1e-9) {
                ptr_r2[t] = 1.0 - (rss / tss);
            } else {
                ptr_r2[t] = 1.0; // Perfect fit or constant
            }
        }
    }

    std::map<std::string, py::array_t<double>> results;
    results["alpha"] = alpha;
    results["beta_B"] = b1;
    results["beta_Index"] = b2;
    results["yhat"] = yhat; 
    results["r2"] = r2;
    
    return results;
}


// ==========================================
// FAST ADF IMPLEMENTATION
// ==========================================

// Helper: Solve Linear System Ax = b using Gaussian Elimination with partial pivoting
// A is NxN, b is Nx1. Returns true if successful.
// Result stored in b.
bool solve_linear_system(std::vector<std::vector<double>>& A, std::vector<double>& b) {
    int n = A.size();
    
    for (int i = 0; i < n; ++i) {
        // Pivot
        int pivot = i;
        double max_val = std::abs(A[i][i]);
        for (int k = i + 1; k < n; ++k) {
            if (std::abs(A[k][i]) > max_val) {
                max_val = std::abs(A[k][i]);
                pivot = k;
            }
        }
        
        if (max_val < 1e-12) return false; // Singular
        
        std::swap(A[i], A[pivot]);
        std::swap(b[i], b[pivot]);
        
        // Eliminate
        for (int k = i + 1; k < n; ++k) {
            double factor = A[k][i] / A[i][i];
            b[k] -= factor * b[i];
            for (int j = i; j < n; ++j) {
                A[k][j] -= factor * A[i][j];
            }
        }
    }
    
    // Back substitution
    for (int i = n - 1; i >= 0; --i) {
        double sum = 0.0;
        for (int j = i + 1; j < n; ++j) {
            sum += A[i][j] * b[j];
        }
        b[i] = (b[i] - sum) / A[i][i];
    }
    
    return true;
}

std::map<std::string, double> fast_adf(
    py::array_t<double> y_array,
    int max_lag,
    std::string regression,
    std::string autolag
) {
    auto y_ptr = y_array.unchecked<1>();
    Py_ssize_t n = y_ptr.shape(0);
    
    if (n < max_lag + 2) {
         // Not enough data
         return {{"adf_stat", std::numeric_limits<double>::quiet_NaN()}, 
                 {"p_value", std::numeric_limits<double>::quiet_NaN()},
                 {"used_lag", -1.0}};
    }

    // 1. Compute First Differences (dy)
    std::vector<double> y(n);
    std::vector<double> dy(n - 1);
    for(int i=0; i<n; ++i) y[i] = y_ptr(i);
    for(int i=0; i<n-1; ++i) dy[i] = y[i+1] - y[i];

    // Determine sample size
    int start_idx = max_lag;
    int end_idx = n - 2;
    int sample_size = end_idx - start_idx + 1;
    
    if (sample_size < 5) {
         return {{"adf_stat", std::numeric_limits<double>::quiet_NaN()}, 
                 {"p_value", std::numeric_limits<double>::quiet_NaN()},
                 {"used_lag", -1.0}};
    }

    // Best lag selection based on AIC
    double best_aic = 1e9;
    int best_lag = -1;
    double best_stat = 0.0;
    
    // Loop lags (high to low typically)
    for (int lag = max_lag; lag >= 0; --lag) {
        // Build Design Matrix X and Target Y
        
        // Number of regressors
        int n_params = 1; // y[k]
        bool has_const = (regression == "c" || regression == "ct");
        bool has_trend = (regression == "ct");
        
        if (has_const) n_params++;
        if (has_trend) n_params++;
        n_params += lag;
        
        // Matrices XtX, XtY computed directly
        std::vector<std::vector<double>> XtX(n_params, std::vector<double>(n_params, 0.0));
        std::vector<double> XtY(n_params, 0.0);
        double sum_YY = 0.0;
        
        for (int i = 0; i < sample_size; ++i) {
            int time_idx = start_idx + i; 
            double Y_val = dy[time_idx];
            
            std::vector<double> row;
            row.reserve(n_params);
            
            if (has_const) row.push_back(1.0);
            if (has_trend) row.push_back((double)(time_idx + 1)); 
            
            // Lagged Level y[k] -> y[time_idx]
            row.push_back(y[time_idx]);
            
            // Lagged Diffs
            for (int L = 1; L <= lag; ++L) {
                row.push_back(dy[time_idx - L]);
            }
            
            // Update Normal Equations
            for (int r = 0; r < n_params; ++r) {
                for (int c = 0; c < n_params; ++c) {
                    XtX[r][c] += row[r] * row[c];
                }
                XtY[r] += row[r] * Y_val;
            }
            sum_YY += Y_val * Y_val;
        }
        
        // Solve
        auto A = XtX;
        auto b = XtY;
        
        if (!solve_linear_system(A, b)) {
            continue; // Singular
        }
        
        // RSS
        double beta_XtY = 0.0;
        for (int j = 0; j < n_params; ++j) {
            beta_XtY += b[j] * XtY[j];
        }
        double rss = sum_YY - beta_XtY;
        
        // AIC
        if (rss <= 1e-9) rss = 1e-9;
        double aic = sample_size * std::log(rss / sample_size) + 2 * n_params;
        
        // Check if best
        if (aic < best_aic || best_lag == -1) {
            best_aic = aic;
            best_lag = lag;
            
            // Calculate t-stat for gamma
            int gamma_idx = -1;
            if (has_const && has_trend) gamma_idx = 2;
            else if (has_const) gamma_idx = 1;
            else gamma_idx = 0;
            
            double gamma = b[gamma_idx];
            
            // Standard Error
            std::vector<double> unit_vec(n_params, 0.0);
            unit_vec[gamma_idx] = 1.0;
            
            auto A2 = XtX; 
            solve_linear_system(A2, unit_vec);
            
            double sigma2 = rss / (sample_size - n_params);
            double var_gamma = sigma2 * unit_vec[gamma_idx];
            
            if (var_gamma > 1e-12) {
                best_stat = gamma / std::sqrt(var_gamma);
            } else {
                best_stat = 0.0;
            }
        }
    }
    
    // Approximate p-value lookup
    double p_val = 0.99;
    if (regression == "c") {
        if (best_stat < -3.43) p_val = 0.01;
        else if (best_stat < -2.86) p_val = 0.05;
        else if (best_stat < -2.57) p_val = 0.10;
        else if (best_stat < -1.62) p_val = 0.45; // Approx median
    } else if (regression == "ct") {
        if (best_stat < -3.96) p_val = 0.01;
        else if (best_stat < -3.41) p_val = 0.05;
        else if (best_stat < -3.12) p_val = 0.10;
    } else { // "n"
        if (best_stat < -2.56) p_val = 0.01;
        else if (best_stat < -1.94) p_val = 0.05;
        else if (best_stat < -1.62) p_val = 0.10;
    }

    std::map<std::string, double> res;
    res["adf_stat"] = best_stat;
    res["p_value"] = p_val;
    res["used_lag"] = (double)best_lag;
    res["best_aic"] = best_aic;
    
    return res;
}

// ==========================================
// FAST KPSS IMPLEMENTATION
// ==========================================

std::map<std::string, double> fast_kpss(
    py::array_t<double> y_array,
    std::string regression,
    std::string nlags
) {
    auto y_ptr = y_array.unchecked<1>();
    Py_ssize_t n = y_ptr.shape(0);
    
    // 1. OLS Residuals
    std::vector<double> residuals(n);
    
    if (regression == "c") {
        double sum = 0.0;
        for(int i=0; i<n; ++i) sum += y_ptr(i);
        double mean = sum / n;
        for(int i=0; i<n; ++i) residuals[i] = y_ptr(i) - mean;
    } else if (regression == "ct") {
        // Regress y on [1, t]
        double sum_t = 0.0, sum_y = 0.0, sum_ty = 0.0, sum_tt = 0.0;
        for(int i=0; i<n; ++i) {
            double t = (double)(i + 1);
            double y = y_ptr(i);
            sum_t += t;
            sum_y += y;
            sum_ty += t * y;
            sum_tt += t * t;
        }
        
        double det = n * sum_tt - sum_t * sum_t;
        if (std::abs(det) < 1e-9) det = 1e-9;
        
        double b = (n * sum_ty - sum_t * sum_y) / det;
        double a = (sum_y - b * sum_t) / n;
        
        for(int i=0; i<n; ++i) {
            residuals[i] = y_ptr(i) - (a + b * (i + 1));
        }
    } else {
        // Assume zero mean (not standard for KPSS but fallback)
        for(int i=0; i<n; ++i) residuals[i] = y_ptr(i);
    }
    
    // 2. Partial Sums
    std::vector<double> S(n);
    double current_sum = 0.0;
    for(int i=0; i<n; ++i) {
        current_sum += residuals[i];
        S[i] = current_sum;
    }
    
    // 3. Numerator (eta)
    double sum_S2 = 0.0;
    for(int i=0; i<n; ++i) sum_S2 += S[i] * S[i];
    double eta = sum_S2 / (double)(n * n);
    
    // 4. Denominator (Long-run variance)
    // Lags
    int lags = 0;
    if (nlags == "auto" || nlags == "legacy") {
        lags = (int)std::ceil(12.0 * std::pow(n / 100.0, 0.25));
    } else {
        try {
            lags = std::stoi(nlags);
        } catch (...) {
            lags = (int)std::ceil(12.0 * std::pow(n / 100.0, 0.25));
        }
    }
    
    // Newey-West / Bartlett Kernel
    double gamma_0 = 0.0;
    for(int t=0; t<n; ++t) gamma_0 += residuals[t] * residuals[t];
    gamma_0 /= n;
    
    double sigma2 = gamma_0;
    
    for(int j=1; j<=lags; ++j) {
        double gamma_j = 0.0;
        for(int t=j; t<n; ++t) {
            gamma_j += residuals[t] * residuals[t-j];
        }
        gamma_j /= n;
        
        double w_j = 1.0 - (double)j / (lags + 1.0);
        sigma2 += 2.0 * w_j * gamma_j;
    }
    
    double kpss_stat = eta / sigma2;
    
    // 5. p-value lookup
    // Table values for KPSS (Null = Stationary)
    // High stat => Reject Null => Non-Stationary (p-value small)
    // Low stat => Accept Null => Stationary (p-value large)
    
    double p_val = 0.10; // Default conservative (stationary)
    
    if (regression == "c") {
        // Critical values: 10%: 0.347, 5%: 0.463, 2.5%: 0.574, 1%: 0.739
        if (kpss_stat > 0.739) p_val = 0.01;
        else if (kpss_stat > 0.463) p_val = 0.05;
        else if (kpss_stat > 0.347) p_val = 0.10;
        else p_val = 0.20; // > 10%
    } else if (regression == "ct") {
        // Critical: 10%: 0.119, 5%: 0.146, 1%: 0.216
        if (kpss_stat > 0.216) p_val = 0.01;
        else if (kpss_stat > 0.146) p_val = 0.05;
        else if (kpss_stat > 0.119) p_val = 0.10;
        else p_val = 0.20;
    }
    
    std::map<std::string, double> res;
    res["kpss_stat"] = kpss_stat;
    res["p_value"] = p_val;
    res["lags"] = (double)lags;
    
    return res;
}
