import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import f as f_dist
from scipy.special import ndtr
from statsmodels.tsa.stattools import adfuller as statsmodels_adfuller, kpss as statsmodels_kpss, coint, mackinnonp
try:
    from ._cpp_core import fast_adf as fast_adf_cpp, fast_kpss as fast_kpss_cpp
except ImportError:
    try:
        from moqua._cpp_core import fast_adf as fast_adf_cpp, fast_kpss as fast_kpss_cpp
    except ImportError:
        fast_adf_cpp = None
        fast_kpss_cpp = None
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant
from statsmodels.tsa.seasonal import STL
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch, breaks_cusumolsresid
from statsmodels.tsa.vector_ar.var_model import VAR
from statsmodels.tsa.vector_ar.vecm import coint_johansen
from statsmodels.tsa.ar_model import AutoReg
from typing import List, Tuple, Dict, Any, Optional

# Constants
BDAYS_PER_YEAR = 252.0
DT = 1.0 / BDAYS_PER_YEAR
INV_SQRT_2PI = 0.3989422804014327

# ==========================================
# Math Basics
# ==========================================

def pdf(x):
    """Calcule la PDF d'une distribution normale standard."""
    return INV_SQRT_2PI * np.exp(-0.5 * x * x)

def cdf(x):
    """Calcule la CDF d'une distribution normale standard (via ndtr)."""
    return ndtr(x)

# ==========================================
# Indicators
# ==========================================

def moving_average(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window=window).mean()

def rolling_std(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window=window).std()

def z_score(series: pd.Series, window: int) -> pd.Series:
    ma = moving_average(series, window)
    std = rolling_std(series, window)
    return (series - ma) / std

def log_returns(series: pd.Series) -> pd.Series:
    return np.log(series / series.shift(1)).dropna()

def deviation_from_ma(series: pd.Series, window: int) -> pd.Series:
    ma = moving_average(series, window)
    # Rates/Spreads often < 20. Equities often > 20.
    avg_price = series.mean()
    if abs(avg_price) < 20:
            # Additive Deviation: (Val - Mean) * 100 (bps)
            return (series - ma) * 100
    else:
            # Relative Deviation: (Val - Mean) / Mean * 10000 (bps)
            return (series - ma) / ma * 10000

# ==========================================
# Statistical Tests
# ==========================================

def adf(series: pd.Series, maxlag: int = None, autolag: str = "AIC", regression: str = "c") -> tuple:
    """
    Optimized Augmented Dickey-Fuller test using C++ implementation when available.
    Returns: (adf_stat, p_value, usedlag, nobs, critical_values, icbest)
    """
    series = series.dropna()
    n = len(series)
    
    # Default maxlag logic similar to statsmodels if None
    if maxlag is None:
        maxlag = int(12 * (n / 100) ** 0.25)
        
    if fast_adf_cpp is not None:
        try:
            # Call C++ Fast ADF
            # returns dict: {"adf_stat", "p_value" (placeholder), "used_lag", "best_aic"}
            # Ensure regression arg is passed correctly (c, ct, nc)
            res = fast_adf_cpp(series.values, maxlag, regression, autolag)
            
            stat = res["adf_stat"]
            lag = int(res["used_lag"])
            aic = res["best_aic"]
            
            if np.isnan(stat):
                 raise ValueError("C++ ADF returned NaN")

            # Calculate P-value using Mackinnon approximate surface
            # regression: 'c' (constant only), 'ct' (constant and trend), 'nc' (no constant)
            p_val = mackinnonp(stat, regression=regression, N=1)
            
            # Critical values (optional / omitted for speed, or calculated if needed)
            # For now return empty dict + other values for compatibility with adfuller return signature:
            # (stat, p, lag, nobs, crit_values, resstore)
            
            crit_values = {} 
            
            return stat, p_val, lag, n - lag - 1, crit_values, aic
            
        except Exception:
            # Fallback to pure python/statsmodels if C++ fails
            pass
            
    return statsmodels_adfuller(series, maxlag=maxlag, regression=regression, autolag=autolag)

def kpss(series: pd.Series, regression: str = "c", nlags: str = "auto") -> tuple:
    """
    Optimized KPSS test using C++ implementation when available.
    Returns: (kpss_stat, p_value, lags, critical_values)
    """
    series = series.dropna()
    
    if fast_kpss_cpp is not None:
        try:
            # Call C++ Fast KPSS
            res = fast_kpss_cpp(series.values, regression, nlags)
            
            stat = res["kpss_stat"]
            p_val = res["p_value"]
            lags = int(res["lags"])
            
            if np.isnan(stat):
                 raise ValueError("C++ KPSS returned NaN")
                 
            # Critical values placeholder (approx for C)
            # 10%: 0.347, 5%: 0.463, 1%: 0.739
            crit = {
                "10%": 0.347 if regression == "c" else 0.119,
                "5%": 0.463 if regression == "c" else 0.146,
                "1%": 0.739 if regression == "c" else 0.216,
                "2.5%": 0.574 if regression == "c" else 0.176
            }
            
            return stat, p_val, lags, crit
            
        except Exception:
            pass

    return statsmodels_kpss(series, regression=regression, nlags=nlags)

def stationarity_tests(x: pd.Series, kpss_regression: str = "c") -> dict:
    x = x.dropna()
    res = {}
    # ADF
    try:
        # returns (stat: float, p: float, lag: int, n: int, crit: dict, icbest: float)
        adf_stat, adf_p, _, _, _, _ = adf(x, autolag="AIC")
        res["adf_stat"] = float(adf_stat)
        res["adf_p"] = float(adf_p)
    except Exception:
        res["adf_stat"] = np.nan
        res["adf_p"] = np.nan

    # KPSS
    try:
        kpss_res = kpss(x, regression=kpss_regression, nlags="auto")
        res["kpss_stat"] = float(kpss_res[0])
        res["kpss_p"] = float(kpss_res[1])
    except Exception:
        res["kpss_stat"] = np.nan
        res["kpss_p"] = np.nan
    
    return res

def coint_pvalue(y: pd.Series, x: pd.Series) -> float:
    """
    Engle-Granger cointegration test p-value.
    Null hypothesis: no cointegration.
    """
    df = pd.concat([y, x], axis=1).dropna()
    if len(df) < 20: 
        return np.nan
    try:
        # coint returns (score, pvalue, critical_values)
        _, pval, _ = coint(df.iloc[:, 0], df.iloc[:, 1])
        return float(pval)
    except Exception:
        return np.nan

def johansen_test(logA: pd.Series, logB: pd.Series) -> dict:
    df = pd.concat([logA, logB], axis=1).dropna()
    df.columns = ["logA", "logB"]
    if len(df) < 40:
        return {"johansen_trace_r0_minus_crit": np.nan, "johansen_trace_r1_minus_crit": np.nan, "johansen_k_ar_diff": np.nan}

    sel = VAR(df).select_order(maxlags=min(10, max(1, len(df)//20)))
    best_lag = None
    for crit in ("bic", "hqic", "aic"):
        val = getattr(sel, crit)
        if val is not None:
            try:
                best_lag = int(val)
                break
            except Exception:
                continue
    if best_lag is None:
        best_lag = 1
    k_ar_diff = max(0, best_lag - 1)

    best = None
    for det_order in (0, 1):
        try:
            joh = coint_johansen(df, det_order=det_order, k_ar_diff=k_ar_diff)
            tr = joh.lr1
            crit = joh.cvt[:, 1]  # 95%
            r0 = float(tr[0] - crit[0])
            r1 = float(tr[1] - crit[1])
            score = r0
            if (best is None) or (score > best[0]):
                best = (score, r0, r1, det_order)
        except Exception:
            continue

    if best is None:
            return {"johansen_trace_r0_minus_crit": np.nan, "johansen_trace_r1_minus_crit": np.nan, "johansen_k_ar_diff": k_ar_diff}

    return {
        "johansen_trace_r0_minus_crit": best[1],
        "johansen_trace_r1_minus_crit": best[2],
        "johansen_k_ar_diff": k_ar_diff,
    }

def gregory_hansen_intercept_proxy(logA: pd.Series, logB: pd.Series) -> dict:
    """
    Runs ADF on residuals of: logA_t = c + I(t>tau)*break + beta*logB_t + eps_t
    for various tau.
    """
    n = len(logA)
    if n < 50:
            return {"gh_proxy_stat": np.nan, "gh_proxy_p": np.nan, "gh_break_idx": np.nan}
    
    y = logA.values
    x = logB.values
    t_stats = []
    
    # Search range: 15% to 85%
    start_idx = int(0.15 * n)
    end_idx = int(0.85 * n)
    idx_map = []

    X_base = np.column_stack([np.ones(n), x])
    
    for k in range(start_idx, end_idx):
        # Dummy for intercept break
        D = np.zeros(n)
        D[k:] = 1.0
        
        X = np.column_stack([X_base, D])
        try:
            beta = np.linalg.lstsq(X, y, rcond=None)[0]
            resid = y - X @ beta
            # ADF on residuals (const already in regression, so ADF with no const? 
            # Standard GH theory uses specific critical values. We use standard ADF as PROXY)
            res_adf = adfuller(resid, regression='n', autolag='AIC')
            t_stats.append(res_adf[0])
            idx_map.append(k)
        except:
            continue
            
    if not t_stats:
            return {"gh_proxy_stat": np.nan, "gh_proxy_p": np.nan, "gh_break_idx": np.nan}
            
    min_t = np.min(t_stats)
    min_idx = np.argmin(t_stats)
    best_k = idx_map[min_idx]
    
    # Approximate p-value (standard ADF p-value is conservative for GH, but serves as proxy)
    # We can just return the stat.
    return {
        "gh_proxy_stat": float(min_t),
        "gh_proxy_p": np.nan, # Not strictly valid to use standard ADF p-value
        "gh_break_idx": int(best_k)
    }

def chow_mid_sample(y: pd.Series) -> dict:
    y = y.dropna()
    n = len(y)
    if n < 40:
            return {"F": np.nan, "p": np.nan}
    
    split = n // 2
    
    def rss(seg_y):
        if len(seg_y) < 2: return 0.0
        x_ = np.arange(len(seg_y))
        X_ = add_constant(x_)
        model = OLS(seg_y, X_)
        res = model.fit()
        return np.sum(res.resid**2)
        
    rss_pool = rss(y)
    rss1 = rss(y.iloc[:split])
    rss2 = rss(y.iloc[split:])
    
    k = 2 # intercept + slope
    df1 = k
    df2 = n - 2*k
    
    if rss1 + rss2 == 0 or df2 <= 0:
        return {"F": np.nan, "p": np.nan}
        
    num = (rss_pool - (rss1 + rss2)) / df1
    den = (rss1 + rss2) / df2
    F = num / den
    p_val = 1.0 - f_dist.cdf(F, df1, df2)
    
    return {"F": float(F), "p": float(p_val)}

def chow_multiple_points(y: pd.Series, n_points: int = 5) -> dict:
    y = y.dropna()
    n = len(y)
    if n < 50:
            return {"F": np.nan, "p": np.nan, "best_split": np.nan}
            
    def chow_test_at_point(y, split):
        if split < 10 or split > len(y)-10:
            return -np.inf, 1.0
            
        def rss(seg_y):
            if len(seg_y) < 5: return 1e9
            x_ = np.arange(len(seg_y))
            X_ = add_constant(x_)
            model = OLS(seg_y, X_)
            res = model.fit()
            return np.sum(res.resid**2)

        rss_pool = rss(y)
        rss1 = rss(y.iloc[:split])
        rss2 = rss(y.iloc[split:])
        
        k = 2 
        df1 = k
        df2 = n - 2*k
        
        if df2 <= 0 or (rss1+rss2) == 0:
            return -np.inf, 1.0
            
        num = (rss_pool - (rss1 + rss2)) / df1
        den = (rss1 + rss2) / df2
        if den == 0: return -np.inf, 1.0
        
        F = num / den
        p = 1.0 - f_dist.cdf(F, df1, df2)
        return F, p

    splits = np.linspace(0.2, 0.8, n_points)
    best_F = -np.inf
    best_p = 1.0
    best_split = n // 2
    
    for r in splits:
        s_idx = int(r * n)
        F, p = chow_test_at_point(y, s_idx)
        if F > best_F:
            best_F = F
            best_p = p
            best_split = s_idx
            
    return {
        "F": float(best_F) if best_F != -np.inf else np.nan,
        "p": float(best_p),
        "best_split": float(best_split)
    }

def test_beta_stability(logA: pd.Series, logB: pd.Series, window: int = 252, step: int = 30) -> dict:
    df = pd.concat([logA, logB], axis=1).dropna()
    y = df.iloc[:, 0]
    x = df.iloc[:, 1]
    n = len(y)
    
    if n < window + 20:
            return {"beta_cv": np.nan, "beta_min": np.nan, "beta_max": np.nan}
            
    betas = []
    for start in range(0, n - window, step):
        end = start + window
        y_sub = y.iloc[start:end]
        x_sub = x.iloc[start:end]
        X_sub = add_constant(x_sub)
        try:
            res = OLS(y_sub, X_sub).fit()
            betas.append(res.params.iloc[1])
        except:
            pass
            
    if not betas:
            return {"beta_cv": np.nan, "beta_min": np.nan, "beta_max": np.nan}
            
    betas = np.array(betas)
    mean_b = np.mean(betas)
    std_b = np.std(betas)
    cv = std_b / abs(mean_b) if mean_b != 0 else np.inf
    
    return {
        "beta_cv": float(cv),
        "beta_min": float(np.min(betas)),
        "beta_max": float(np.max(betas))
    }

def cusum_on_residuals(y: pd.Series) -> float:
    y = y.dropna()
    if len(y) < 30: return 1.0
    
    x = np.arange(len(y))
    X = add_constant(x)
    try:
        res = OLS(y, X).fit()
        # breaks_cusumolsresid returns (stat, p-value, crit_val)
        # Warning: statsmodels 0.14+ API might differ slightly, but typically:
        c_res = breaks_cusumolsresid(res.resid)
        # return p-value (index 1)
        return float(c_res[1])
    except:
        return 1.0

def ar1_arch_diagnostics(x: pd.Series, arch_max_lags: int = 10) -> dict:
    x = x.dropna()
    out = {"ar1_phi": np.nan, "lb_p": np.nan, "arch_p": np.nan, "arch_lags": np.nan}
    n = len(x)
    if n < 40: return out
    
    # 1. AR(1)
    try:
        mod = AutoReg(x, lags=1).fit()
        out["ar1_phi"] = float(mod.params.iloc[-1]) # param of lag 1
        resid = mod.resid
    except:
        resid = x # Fallback
        
    # 2. Ljung-Box (on residuals)
    try:
        # Check white noise
        lb_res = acorr_ljungbox(resid, lags=[10], return_df=False)
        # lb_res is dict or df in newer versions, or tuple in older.
        # Assuming return_df=False returns (lb_stat, lb_pvalue) (array-like)
        if isinstance(lb_res, pd.DataFrame):
                out["lb_p"] = float(lb_res["lb_pvalue"].iloc[0])
        else:
                # Older statsmodels
                out["lb_p"] = float(lb_res[1][0]) 
    except:
        pass
        
    # 3. ARCH
    try:
        # Engle's Test for Autoregressive Conditional Heteroscedasticity
        # returns (lm, lmpval, fval, fpval)
        lags = min(arch_max_lags, n//10)
        if lags > 0:
            arch = het_arch(resid, maxlag=lags)
            out["arch_p"] = float(arch[1])
            out["arch_lags"] = lags
    except:
        pass
        
    return out

# ==========================================
# Statistical Analysis / Models
# ==========================================

def eg_spread(logA: pd.Series, logB: pd.Series) -> pd.Series:
    df = pd.concat([logA, logB], axis=1).dropna()
    y = df.iloc[:, 0]
    x = df.iloc[:, 1]
    X = add_constant(x)
    res = OLS(y, X).fit()
    return res.resid

def fit_ou_discrete(x: pd.Series) -> dict:
    x = x.dropna()
    if len(x) < 30:
            return {"ou_kappa": np.nan, "ou_mu": np.nan, "ou_sigma": np.nan, "ou_halflife": np.nan}
            
    # OU: dx_t = kappa(mu - x_t)dt + sigma dW_t
    # Discrete AR(1): x_{t+1} = a + b x_t + eps
    # b = exp(-kappa dt), mu = a / (1-b), etc.
    x_curr = x.iloc[:-1].values
    x_next = x.iloc[1:].values
    
    X = add_constant(x_curr)
    res = OLS(x_next, X).fit()
    a, b = res.params
    res_std = np.std(res.resid)
    
    dt = 1.0 / 252.0
    # kappa = -log(b) / dt
    if b <= 0 or b >= 1:
            kappa = np.nan
            hl = np.nan
    else:
            kappa = -np.log(b) / dt
            hl = np.log(2) / kappa
            
    if not np.isnan(kappa) and kappa != 0:
            mu = a / (1 - b)
            sigma = res_std * np.sqrt((-2*np.log(b)) / (dt * (1 - b**2)))
    else:
            mu = np.nan
            sigma = np.nan
            
    return {
        "ou_kappa": kappa,
        "ou_mu": mu,
        "ou_sigma": sigma,
        "ou_halflife": hl
    }

def seasonality_strength(x: pd.Series, periods: list = [5, 21]) -> float:
    # Simple heuristic or usage of STL
    x = x.dropna()
    if len(x) < 252: return 0.0
    
    best_strength = 0.0
    
    for p in periods:
            if len(x) < 2 * p: continue
            try:
                res = STL(x, period=p, robust=True).fit()
                var_rem = np.var(res.resid)
                var_seas = np.var(res.seasonal)
                strength = max(0, 1 - (var_rem / (var_seas + var_rem)))
                if strength > best_strength:
                    best_strength = strength
            except:
                continue
                
    return float(best_strength)

def jumps_metrics(x: pd.Series, mad_k: float = 5.0, scaled: bool = False) -> dict:
    x_clean = x.dropna()
    if len(x_clean) < 30: return {"jumps_rate": 0.0}
    
    diff = x_clean.diff().dropna()
    med = diff.median()
    mad = (diff - med).abs().median()
    
    # If scaled, we work on z-scores of diffs
    if scaled:
            z = (diff - diff.mean()) / diff.std()
            outliers = (z.abs() > mad_k)
    else:
            # Using MAD-based threshold
            # consistent estimator of sigma is 1.4826 * MAD
            sigma_mad = 1.4826 * mad
            threshold = mad_k * sigma_mad
            outliers = ((diff - med).abs() > threshold)
            
    rate = outliers.sum() / len(diff)
    return {"jumps_rate": float(rate)}

def bh_fdr_adjust(p_values: list) -> list:
    """
    Benjamini-Hochberg FDR adjustment.
    """
    p_vals = np.array(p_values)
    # Handle NaNs: preserve them
    mask = np.isfinite(p_vals)
    if not mask.any():
            return list(p_vals)
            
    pv_valid = p_vals[mask]
    m = len(pv_valid)
    
    # Sort desc
    sort_idxs = np.argsort(pv_valid)
    pv_sorted = pv_valid[sort_idxs]
    
    # Ranks: m, m-1, ..., 1 ? No, BH is k/m
    # Adjusted p = min(1, p * m / k)
    # but enforced to be increasing.
    # Typically: sort ascending.
    # k = 1..m
    # p_adj_k = min( p_adj_{k+1}, p_val_k * m / k )
    
    # Re-sort statsmodels way or standard way
    # Standard: sort ascending
    sorted_indices = np.argsort(pv_valid)
    sorted_p = pv_valid[sorted_indices]
    
    adj_p = np.zeros(m)
    min_p = 1.0
    
    # Iterating from largest p-value to smallest
    for k in range(m, 0, -1):
        idx = k - 1 # 0-based
        p_curr = sorted_p[idx]
        # m / k factor
        p_corrected = p_curr * m / k
        p_corrected = min(1.0, p_corrected)
        min_p = min(min_p, p_corrected)
        adj_p[idx] = min_p
        
    # Map back to original order
    final_valid = np.zeros(m)
    final_valid[sorted_indices] = adj_p
    
    # Merge with NaNs
    final = np.full(len(p_vals), np.nan)
    final[mask] = final_valid
    
    return list(final)

def kalman_dynamic_beta(y: pd.Series, x: pd.Series, delta: float = 1e-5) -> dict:
    """
    Implements a simple Kalman Filter to estimate time-varying beta.
    Model: y = alpha + beta * x + noise
    """
    y_val = y.values
    x_val = x.values
    n = len(y_val)
    
    full_X = np.column_stack([np.ones(n), x_val])
    start_beta = np.linalg.lstsq(full_X, y_val, rcond=None)[0]
    
    state_mean = start_beta.copy()
    state_cov = np.eye(2) * 0.1
    
    Q = np.eye(2) * delta 
    
    residuals = y_val - (start_beta[0] + start_beta[1] * x_val)
    R = np.var(residuals)
    if R == 0: R = 1e-5
    
    betas = np.zeros(n)
    alphas = np.zeros(n)
    
    for i in range(n):
        state_mean_pred = state_mean
        state_cov_pred = state_cov + Q
        
        H = np.array([1.0, x_val[i]])
        
        y_pred = np.dot(H, state_mean_pred)
        y_res = y_val[i] - y_pred
        
        S = np.dot(H, np.dot(state_cov_pred, H.T)) + R
        K = np.dot(state_cov_pred, H.T) / S
        
        state_mean = state_mean_pred + K * y_res
        state_cov = state_cov_pred - np.outer(K, H).dot(state_cov_pred)
        
        alphas[i] = state_mean[0]
        betas[i] = state_mean[1]
    
    return {
        "alphas": pd.Series(alphas, index=y.index),
        "betas": pd.Series(betas, index=x.index)
    }

def rolling_half_life(prices: pd.Series, min_window: int = 60, max_window: int = 252) -> pd.Series:
    """
    Calculates the rolling Ornstein-Uhlenbeck half-life.
    """
    log_prices = np.log(prices.dropna())
    half_life_series = pd.Series(index=log_prices.index, dtype=float)
    
    for i in range(min_window, len(log_prices)):
        window_len = min(i + 1, max_window)
        start_idx = i + 1 - window_len
        end_idx = i + 1
        
        window_data = log_prices.iloc[start_idx:end_idx]
        
        if len(window_data) < min_window:
            continue
            
        try:
            dx = window_data.diff().dropna()
            if len(dx) < 30:
                continue
            
            # Regress dx on previous value (Ornstein-Uhlenbeck discretization)
            X = add_constant(window_data.shift(1).reindex(dx.index))
            reg = OLS(dx, X, missing="drop").fit()
            b = float(reg.params.iloc[-1])
            kappa = -b / DT
            
            if kappa > 0:
                half_life = (np.log(2.0) / kappa) * BDAYS_PER_YEAR
                if np.isfinite(half_life) and 0 < half_life < 10000:
                    half_life_series.iloc[i] = half_life
        except Exception:
            continue
    
    return half_life_series

# ==========================================
# Structural Breaks & Filtering
# ==========================================

def detect_breakpoints(spread: pd.Series, window: int = 60, min_gap: int = 30) -> List[Tuple[int, int]]:
    """Détecte les points de rupture dans une série"""
    if len(spread) < 2 * window:
        return [(0, len(spread))]
    
    spread_clean = spread.dropna()
    if len(spread_clean) < 2 * window:
        return [(0, len(spread))]
    
    chow_stats = []
    positions = []
    
    # Test Chow sur fenêtre glissante
    for i in range(window, len(spread_clean) - window, min_gap):
        try:
            # Diviser en deux périodes
            period1 = spread_clean.iloc[:i]
            period2 = spread_clean.iloc[i:]
            
            if len(period1) < 30 or len(period2) < 30:
                continue
                
            # Régression simple (y = a + b*t)
            # Pour chaque période, on prend les valeurs de spread
            # X1, X2 sont des indices temporels 0..N
            # Calculer les moyennes et sommes des carrés
            
            y1_mean = period1.mean()
            y2_mean = period2.mean()
            
            ss1 = ((period1 - y1_mean) ** 2).sum()
            ss2 = ((period2 - y2_mean) ** 2).sum()
            
            n1, n2 = len(period1), len(period2)
            
            # Statistique Chow simplifiée (différence de moyennes normalisée par variance poolée)
            if ss1 > 0 and ss2 > 0:
                chow_stat = abs(y1_mean - y2_mean) / np.sqrt(ss1/n1 + ss2/n2)
                chow_stats.append(chow_stat)
                positions.append(i)
        except Exception:
            continue
    
    if not chow_stats:
        return [(0, len(spread_clean))]
    
    # Trouver les ruptures significatives
    threshold = np.percentile(chow_stats, 90)  # Top 10% des statistiques
    breakpoints = [0]
    
    for i, stat in enumerate(chow_stats):
        if stat > threshold:
            breakpoints.append(positions[i])
    
    breakpoints.append(len(spread_clean))
    
    # Créer les périodes
    periods = []
    for i in range(len(breakpoints) - 1):
        start, end = breakpoints[i], breakpoints[i + 1]
        if end - start > 50:  # Au moins 50 observations
            periods.append((start, end))
    
            asset_counts[asset_a] = asset_counts.get(asset_a, 0) + 1
            asset_counts[asset_b] = asset_counts.get(asset_b, 0) + 1
            
            # Arrêter si on a assez de paires
            if len(selected_pairs) >= top_n:
                break
    
    # Créer le DataFrame final
    if selected_pairs:
        result_df = pd.DataFrame(selected_pairs)
        # Supprimer les colonnes temporaires
        result_df = result_df.drop(columns=['asset_a', 'asset_b'])
        return result_df
    else:
        return pd.DataFrame()


# -----------------------------------------------------------------------------
# KALMAN FILTER (Dynamic Beta)
# -----------------------------------------------------------------------------

class KalmanStateSpace:
    """
    Filtre de Kalman pour estimer un Bêta dynamique entre deux actifs.
    Modèle : Y = alpha + beta * X + bruit
    L'état (alpha, beta) évolue selon une marche aléatoire.
    """
    def __init__(self, delta=1e-5, ve=1e-3):
        """
        :param delta: Variance du bruit de transition (souplesse du Bêta)
        :param ve: Variance du bruit de mesure (confiance dans le prix)
        """
        self.delta = delta
        self.ve = ve

    def run(self, y, x):
        """
        Exécute le filtre sur les séries temporelles.
        :param y: Série cible (ex: Actif A) - numpy array
        :param x: Série hedge (ex: Actif B) - numpy array
        :return: dictionnaire {residuals, beta, alpha}
        """
        # Assurer format numpy
        y = np.array(y)
        x = np.array(x)
        n = len(y)
        
        # Initialisation
        # État : [alpha, beta]
        state_mean = np.zeros(2)
        state_cov = np.ones((2, 2))
        
        # Matrice de transition du bruit (Process Noise)
        # Q contrôle à quel point alpha/beta peuvent bouger
        Q = self.delta / (1 - self.delta) * np.eye(2)
        
        # Stockage
        kf_residuals = np.zeros(n)
        kf_beta = np.zeros(n)
        kf_alpha = np.zeros(n)
        
        for t in range(n):
            # 1. Prédiction (Time Update)
            # L'état est une marche aléatoire, donc pred = prev
            state_cov = state_cov + Q
            
            # Matrice d'observation H = [1, x_t]
            H = np.array([1, x[t]])
            
            # Prédiction de la mesure
            y_pred = H @ state_mean
            
            # Innovation (Erreur)
            error = y[t] - y_pred
            
            # Variance de l'innovation
            S = H @ state_cov @ H.T + self.ve
            
            # Gain de Kalman
            K = state_cov @ H.T / S
            
            # 2. Correction (Measurement Update)
            state_mean = state_mean + K * error
            state_cov = (np.eye(2) - np.outer(K, H)) @ state_cov
            
            # Stockage
            kf_residuals[t] = error # Innovation
            kf_alpha[t] = state_mean[0]
            kf_beta[t] = state_mean[1]
            
        return {
            "residuals": kf_residuals,
            "beta": kf_beta,
            "alpha": kf_alpha
        }
