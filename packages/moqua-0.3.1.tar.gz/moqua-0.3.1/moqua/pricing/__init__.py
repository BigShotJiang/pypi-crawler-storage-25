import numpy as np
import pandas as pd
from scipy.optimize import brentq
from moqua.core import pdf, cdf
try:
    from moqua import _cpp_core
    # Enable fallback for dev environment if needed, but keeping simple
except ImportError:
    # If C++ not built, we will fail at runtime if called
    pass

# ==========================================
# 1. LE MOTEUR MATHEMATIQUE (Fonctions Pures)
# ==========================================
# "Stateless" : Ne stockent rien, ne connaissent pas les objets.
# Vectorisation : Acceptent (souvent) des np.array pour aller vite.



def implied_volatility(price, S, K, T, r, q=0.0, option_type='call'):
    """
    Calculate Implied Volatility using Peter Jäckel's 'Let's be rational' method.
    Wrapper around the high-precision C++ implementation.
    """
    if price <= 0 or S <= 0 or K <= 0 or T <= 0:
        return np.nan

    # Calculate Forward price
    # Note: q argument here is dividend yield, but Jäckel uses q for sign.
    F = S * np.exp((r - q) * T)

    # Jäckel's sign convention: +1 for Call, -1 for Put
    cp_sign = 1.0 if str(option_type).lower() == 'call' else -1.0

    # Jäckel's ImpliedBlackVolatility expects Undiscounted Price (Future Value)
    # The solver receives F, K, T. It does not know 'r' to discount back.
    # We must convert Market Price (PV) to Forward Price (FV).
    undiscounted_price = price * np.exp(r * T)

    try:
        return _cpp_core.implied_volatility(undiscounted_price, F, K, T, cp_sign)
    except:
        return np.nan


# --- Moteur Black-Scholes (Options) ---
def bs_d1(S, K, T, r, sigma):
    with np.errstate(divide='ignore', invalid='ignore'): 
        val = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    return val

def bs_d2(d1, sigma, T):
    return d1 - sigma * np.sqrt(T)

def bs_price(S, K, T, r, sigma, option_type='call'):
    if np.ndim(T) == 0 and T <= 0:
        return max(0, S - K) if option_type == 'call' else max(0, K - S)

    d1 = bs_d1(S, K, T, r, sigma)
    d2 = bs_d2(d1, sigma, T)
    
    if option_type == 'call':
        return S * cdf(d1) - K * np.exp(-r * T) * cdf(d2)
    else:
        return K * np.exp(-r * T) * cdf(-d2) - S * cdf(-d1)

def bs_delta(S, K, T, r, sigma, option_type='call'):
    if np.ndim(T) == 0 and T <= 0: return 0.0
    d1 = bs_d1(S, K, T, r, sigma)
    if option_type == 'call':
        return cdf(d1)
    else:
        return cdf(d1) - 1.0

def bs_vega(S, K, T, r, sigma):
    if np.ndim(T) == 0 and T <= 0: return 0.0
    d1 = bs_d1(S, K, T, r, sigma)
    return S * pdf(d1) * np.sqrt(T)

def bs_gamma(S, K, T, r, sigma):
    if np.ndim(T) == 0 and (T <= 0 or S <= 0 or sigma <= 0): return 0.0
    d1 = bs_d1(S, K, T, r, sigma)
    return pdf(d1) / (S * sigma * np.sqrt(T))

def bs_rho(S, K, T, r, sigma, option_type='call'):
    if np.ndim(T) == 0 and T <= 0: return 0.0
    d2 = bs_d2(bs_d1(S, K, T, r, sigma), sigma, T)
    if option_type == 'call':
        return K * T * np.exp(-r * T) * cdf(d2)
    else:
        return -K * T * np.exp(-r * T) * cdf(-d2)

def bs_theta(S, K, T, r, sigma, option_type='call'):
    if np.ndim(T) == 0 and T <= 0: return 0.0
    d1 = bs_d1(S, K, T, r, sigma)
    d2 = bs_d2(d1, sigma, T)
    term1 = -(S * pdf(d1) * sigma) / (2 * np.sqrt(T))
    if option_type == 'call':
        term2 = -r * K * np.exp(-r * T) * cdf(d2)
    else:
        term2 = r * K * np.exp(-r * T) * cdf(-d2)
    return (term1 + term2) / 365.0

# --- Moteur Fixed Income (Obligations) ---
def bond_cash_flows(face_value, coupon_rate, T, frequency):
    """Génère les cash flows (temps, montant)."""
    # Note: Difficile à vectoriser sur T car la taille du tableau change.
    # On garde une boucle simple ici pour l'instant.
    flows = []
    n_periods = int(T * frequency)
    coupon_amount = (coupon_rate * face_value) / frequency
    
    for i in range(1, n_periods + 1):
        t = i / frequency
        amount = coupon_amount
        if i == n_periods:
            amount += face_value
        flows.append((t, amount))
    return flows

def bond_price(face_value, coupon_rate, T, ytm, frequency=1):
    """Calcule le prix d'une obligation (Dirty)."""
    # Version simplifiée, non-vectorisée sur les arrays de cash flows (car T variable)
    flows = bond_cash_flows(face_value, coupon_rate, T, frequency)
    price = 0.0
    for t, amount in flows:
        periods = t * frequency
        price += amount / ((1 + ytm / frequency) ** periods)
    return price

def bond_macaulay_duration(face_value, coupon_rate, T, ytm, frequency=1):
    """Calcule la Duration Macaulay."""
    flows = bond_cash_flows(face_value, coupon_rate, T, frequency)
    current_price = 0.0
    weighted_time = 0.0
    
    for t, amount in flows:
        periods = t * frequency
        pv = amount / ((1 + ytm / frequency) ** periods)
        current_price += pv
        weighted_time += t * pv
        
    if current_price == 0: return 0.0
    return weighted_time / current_price

def bond_modified_duration(face_value, coupon_rate, T, ytm, frequency=1):
    """Calcule la Duration Modifiée."""
    mac_d = bond_macaulay_duration(face_value, coupon_rate, T, ytm, frequency)
    return mac_d / (1 + ytm / frequency)

def bond_convexity(face_value, coupon_rate, T, ytm, frequency=1):
    """Calcule la Convexité."""
    flows = bond_cash_flows(face_value, coupon_rate, T, frequency)
    current_price = 0.0
    conv_sum = 0.0
    
    for t, amount in flows:
        periods = t * frequency
        pv = amount / ((1 + ytm / frequency) ** periods)
        current_price += pv
        # Term: PV * periods * (periods + 1) / (1+y/f)^2
        # On divise par freq^2 à la toute fin
        term = pv * (periods * (periods + 1)) / ((1 + ytm / frequency)**2)
        conv_sum += term
        
    if current_price == 0: return 0.0
    return conv_sum / (current_price * (frequency ** 2))


# ==========================================
# 2. LOGIQUE METIER (Classes / Objets)
# ==========================================
# Ces classes utilisent le Moteur ci-dessus.

class Option:
    def __init__(self, S, K, T, r, sigma, option_type='call'):
        self.S = S
        self.K = K
        self.T = T
        self.r = r
        self.sigma = sigma
        self.option_type = option_type.lower()
        
    def price(self, sigma=None):
        raise NotImplementedError

class EuropeanOption(Option):
    def price(self, sigma=None):
        vol = self.sigma if sigma is None else sigma
        return bs_price(self.S, self.K, self.T, self.r, vol, self.option_type)

    def delta(self):
        return bs_delta(self.S, self.K, self.T, self.r, self.sigma, self.option_type)

    def vega(self):
        return bs_vega(self.S, self.K, self.T, self.r, self.sigma)
    
    def gamma(self):
        return bs_gamma(self.S, self.K, self.T, self.r, self.sigma)

    def rho(self):
        return bs_rho(self.S, self.K, self.T, self.r, self.sigma, self.option_type)
    
    def theta(self):
        return bs_theta(self.S, self.K, self.T, self.r, self.sigma, self.option_type)

    def implied_volatility(self, market_price):
        # Use the high-precision C++ Jäckel solver
        # q=0 assumed if not present (EuropeanOption doesn't store q currently)
        # If we wanted to support q, we'd need to add self.q to __init__
        return implied_volatility(market_price, self.S, self.K, self.T, self.r, q=0.0, option_type=self.option_type)



# ==========================================
# 3. UTILITIES (Pricing & Data)
# ==========================================

def put_call_parity(option_price, S, K, T, r, q=0.0, price_type='call'):
    """
    Convert Call Price to Put Price (or vice-versa) using Put-Call Parity.
    Formula: C - P = S*e^-qT - K*e^-rT
    
    Args:
        price_type: 'call' if input is call price (returns put), 'put' if input is put (returns call).
    """
    df_r = np.exp(-r * T)
    df_q = np.exp(-q * T)
    fwd_term = S * df_q - K * df_r
    
    if price_type.lower() == 'call':
        # P = C - FwdTerm
        return option_price - fwd_term
    elif price_type.lower() == 'put':
        # C = P + FwdTerm
        return option_price + fwd_term
    else:
        raise ValueError("price_type must be 'call' or 'put'")

def implied_forward(call_price, put_price, K, T, r):
    """
    Calculate Implied Forward Price from ATM Call/Put pair.
    Based on Put-Call Parity: F = K + (C - P) * e^rT
    """
    return K + (call_price - put_price) * np.exp(r * T)

def extract_otm_surface(options_df, F=None, strike_col='strike', type_col='type', price_col='mid'):
    """
    Extract Out-of-The-Money (OTM) options surface.
    - Select Puts for K < F
    - Select Calls for K > F
    
    Args:
        options_df: DataFrame with strikes, types ('C'/'P'), and prices.
        F: Forward price. If None, must be calculated externally or inferred.
    Returns:
        DataFrame containing only OTM options.
    """
    if F is None:
        raise ValueError("Forward price F required to determine OTM cutoff.")
        
    # Standardize types
    types = options_df[type_col].astype(str).str.upper().str.strip()
    
    # Logic:
    # Keep Put (P) if Strike < F
    # Keep Call (C) if Strike > F
    # At K approx F? Usually average or keep both if liquid. Here strict OTM.
    
    mask_put_otm = (types == 'P') & (options_df[strike_col] < F)
    mask_call_otm = (types == 'C') & (options_df[strike_col] >= F)
    
    return options_df[mask_put_otm | mask_call_otm].copy()


class Bond:
    """Obligation à taux fixe."""
    def __init__(self, face_value, coupon_rate, T, ytm, frequency=1):
        self.face_value = float(face_value)
        self.coupon_rate = float(coupon_rate)
        self.T = float(T)
        self.ytm = float(ytm)
        self.frequency = int(frequency)
        
    def _cash_flows(self):
        return bond_cash_flows(self.face_value, self.coupon_rate, self.T, self.frequency)
        
    def price(self, ytm_override=None):
        y = self.ytm if ytm_override is None else ytm_override
        return bond_price(self.face_value, self.coupon_rate, self.T, y, self.frequency)
        
    def duration_macaulay(self, ytm_override=None):
        y = self.ytm if ytm_override is None else ytm_override
        return bond_macaulay_duration(self.face_value, self.coupon_rate, self.T, y, self.frequency)
        
    def duration_modified(self, ytm_override=None):
        y = self.ytm if ytm_override is None else ytm_override
        return bond_modified_duration(self.face_value, self.coupon_rate, self.T, y, self.frequency)
    
    def convexity(self, ytm_override=None):
        y = self.ytm if ytm_override is None else ytm_override
        return bond_convexity(self.face_value, self.coupon_rate, self.T, y, self.frequency)

    def dv01(self):
        return self.duration_modified() * self.price() * 0.0001
        
    def cs01(self):
        return self.dv01()


class BondOption(EuropeanOption):
    """Option sur Obligation."""
    def __init__(self, bond: Bond, K, T, r, sigma, option_type='call'):
        self.bond_underlying = bond
        S = bond.price() 
        super().__init__(S, K, T, r, sigma, option_type)

    def update_underlying_price(self):
        self.S = self.bond_underlying.price()

    def dv01(self):
        self.update_underlying_price()
        # Mixte : Moteur Option (via self.delta) * Chiffre Bond
        # self.delta() utilise déjà le moteur bs_delta
        return self.delta() * self.bond_underlying.dv01()

    def duration_equivalent(self):
        self.update_underlying_price()
        opt_price = self.price()
        if opt_price == 0: return 0
        
        bond_price = self.S
        bond_mod_dur = self.bond_underlying.duration_modified()
        gearing = (self.delta() * bond_price) / opt_price
        
        return gearing * bond_mod_dur






# ==========================================
# 4. VARIANCE PRICING (VIX / VAR SWAPS)
# ==========================================

def cboe_vix_single_term(options_df, expiration_minutes, risk_free_rate, manual_forward=None):
    options_df['mid'] = (options_df['bid'] + options_df['ask']) / 2.0
    T = expiration_minutes / 525600.0
    calls = options_df[options_df['type'] == 'C'].set_index('strike')['mid']
    puts = options_df[options_df['type'] == 'P'].set_index('strike')['mid']
    F, K0 = manual_forward, None
    if F is None:
        common = calls.index.intersection(puts.index)
        if len(common) > 0:
            atm = abs(calls.loc[common] - puts.loc[common]).idxmin()
            F = implied_forward(calls.loc[atm], puts.loc[atm], atm, T, risk_free_rate)
    all_strikes = sorted(options_df['strike'].unique())
    below = [k for k in all_strikes if k < F]
    K0 = below[-1] if below else all_strikes[0]
    selected = []
    for _, row in options_df[(options_df['type'] == 'P') & (options_df['strike'] < K0)].iterrows():
        selected.append({'strike': row['strike'], 'mid': row['mid'], 'type': 'P'})
    for _, row in options_df[(options_df['type'] == 'C') & (options_df['strike'] > K0)].iterrows():
        selected.append({'strike': row['strike'], 'mid': row['mid'], 'type': 'C'})
    k0_price = (calls.get(K0, 0) + puts.get(K0, 0)) / 2.0
    selected.append({'strike': K0, 'mid': k0_price, 'type': 'K0'})
    calc = pd.DataFrame(selected).sort_values('strike').set_index('strike')
    strikes = calc.index.values
    dK = np.zeros(len(strikes))
    if len(strikes) > 1:
        dK[0] = strikes[1]-strikes[0]
        dK[-1] = strikes[-1]-strikes[-2]
        dK[1:-1] = (strikes[2:] - strikes[:-2]) / 2.0
    contrib = (dK / strikes**2) * np.exp(risk_free_rate*T) * calc['mid']
    return max((2/T)*contrib.sum() - (1/T)*((F/K0 - 1)**2), 0)

def cboe_vix(near_term_df, next_term_df, near_minutes, next_minutes, risk_free_rate, manual_forward=None):
    var1 = cboe_vix_single_term(near_term_df, near_minutes, risk_free_rate, manual_forward)
    var2 = cboe_vix_single_term(next_term_df, next_minutes, risk_free_rate, manual_forward)
    T1, T2 = near_minutes / 525600.0, next_minutes / 525600.0
    N30, N365 = 43200, 525600
    if T1 == T2: return 100 * np.sqrt(var1)
    return 100 * np.sqrt(max((T1*var1*((next_minutes-N30)/(next_minutes-near_minutes)) + T2*var2*((N30-near_minutes)/(next_minutes-near_minutes)))*(N365/N30), 0))

# ==========================================
# 5. HESTON MODEL (C++ Backend with Python Fallback)
# ==========================================

# Import C++ Backend functions locally to this scope if available
try:
    from moqua._cpp_core import heston_call_price as _price
    HESTON_CPP_AVAILABLE = True
except ImportError:
    HESTON_CPP_AVAILABLE = False

# Default aliases (Point to optimization module?)
# To avoid circle, we remove aliases here. Consumers must import optimization.
# calibrate_heston = ... REMOVED 

def heston_call_price(S0, K, T, r, v0, kappa, theta, sigma, rho):
    """
    Price European Call using Heston Model (C++ engine).
    """
    if not HESTON_CPP_AVAILABLE: 
        raise RuntimeError("C++ module missing for Heston Pricing")
    return _price(S0, K, T, r, v0, kappa, theta, sigma, rho)


# --- Monte Carlo Engine (Asian Options) ---
# Kept in Python for flexibility/testing, as C++ port was only for standard options.
def heston_asian_mc(S0, K, T, r, v0, kappa, theta, sigma, rho, num_sims=10000, steps=100):
    """
    Price Asian Call Option using Monte Carlo simulation under Heston Model.
    Uses Euler-Maruyama discretization.
    """
    dt = T / steps
    sqrt_dt = np.sqrt(dt)
    
    # Initialize arrays
    S = np.full(num_sims, S0)
    v = np.full(num_sims, v0)
    
    # Accumulator for Asian average
    sum_S = np.zeros(num_sims)
    
    for i in range(steps):
        # Correlated Brownian Motions
        Z1 = np.random.normal(0, 1, num_sims)
        Z2 = rho * Z1 + np.sqrt(1 - rho**2) * np.random.normal(0, 1, num_sims)
        
        # Variance Process (Reflection)
        v_next = v + kappa * (theta - np.maximum(v, 0)) * dt + sigma * np.sqrt(np.maximum(v, 0)) * sqrt_dt * Z2
        v = np.maximum(v_next, 0) 
        
        # Asset Process
        S_next = S * np.exp((r - 0.5 * v) * dt + np.sqrt(v) * sqrt_dt * Z1)
        S = S_next
        
        sum_S += S
        
    avg_S = sum_S / steps
    payoffs = np.maximum(avg_S - K, 0)
    
    return np.exp(-r * T) * np.mean(payoffs)
