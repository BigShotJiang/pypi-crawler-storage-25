import numpy as np
from moqua.core import pdf, cdf
from moqua.pricing.contracts import Calculator, Engine, Option, Market
from functools import cached_property

class Black76Calculator(Calculator):

    def __init__(self, F, K, T, r, sigma, w):
        self.F     = np.asarray(F, float)
        self.K     = np.asarray(K, float)
        self.T     = np.asarray(T, float)
        self.r     = np.asarray(r, float)
        self.sigma = np.asarray(sigma, float)
        self.w     = np.asarray(w, float)

    @cached_property
    def discount(self):
        return np.exp(-self.r * self.T)

    @cached_property
    def mask(self):
        return (self.T <= 0.0) | (self.sigma <= 1e-10)

    @cached_property
    def vol_sqrt_T(self):
        return self.sigma * np.sqrt(np.maximum(self.T, 0.0))

    @cached_property
    def safe_vol(self):
        return np.where(~self.mask, self.vol_sqrt_T, 1.0)

    @cached_property
    def d1(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            return (np.log(self.F / self.K) + (0.5 * self.sigma ** 2) * self.T) / self.safe_vol
    
    @cached_property
    def d2(self):
        return self.d1 - self.vol_sqrt_T

    @cached_property
    def price(self):
        val = self.w * self.discount * (self.F * cdf(self.w * self.d1) - self.K * cdf(self.w * self.d2))
        payoff = np.maximum(0.0, self.w * (self.F - self.K))

        return self._result(np.where(self.mask, payoff, val))

    @cached_property
    def delta(self):

        val = self.w * self.discount * cdf(self.w * self.d1)
        payoff = np.where(self.w * (self.F - self.K) > 0, self.w * self.discount, 0.0)
        
        return self._result(np.where(self.mask, payoff, val))

    @cached_property
    def gamma(self):

        with np.errstate(divide='ignore', invalid='ignore'):
            val = self.discount * pdf(self.d1) / (self.F * self.vol_sqrt_T)
        bad = self.mask | (self.F <= 0)
        
        return self._result(np.where(bad, 0.0, val))

    @cached_property
    def vega(self):
        val = self.F * self.discount * pdf(self.d1) * np.sqrt(np.maximum(self.T, 0.0))
        return self._result(np.where(self.mask, 0.0, val))

    @cached_property
    def rho(self):
        val = -self.T * self.price
        return self._result(np.where(self.T <= 0, 0.0, val))

    @cached_property
    def theta(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            term1 = -(self.F * self.discount * pdf(self.d1) * self.sigma) / (2.0 * np.sqrt(np.maximum(self.T, 1e-10)))
        
        term2 = self.r * self.price
        val = (term1 + term2) / 365.0
        return self._result(np.where(self.T <= 0, 0.0, val))


class Black76Engine(Engine):
    def calculator(self, option: Option, market: Market):
        if market.F is None and market.S is None:
            raise ValueError("Black76 requires 'forward' or 'spot'.")
        
        F = market.F if market.F is not None else market.S * np.exp(market.r * option.T)
        
        return Black76Calculator(
            F=np.maximum(F, 1e-10), K=option.K, 
            T=option.T, r=market.r, sigma=market.sigma, w=option.w
        )