import numpy as np
from moqua.core import pdf, cdf
from moqua.pricing.contracts import Calculator, Engine, Option, Market
from functools import cached_property

class BachelierCalculator(Calculator):

    def __init__(self, F, K, T, r, sigma_N, w):
        self.F       = np.asarray(F, float)
        self.K       = np.asarray(K, float)
        self.T       = np.asarray(T, float)
        self.r       = np.asarray(r, float)
        self.sigma_N = np.asarray(sigma_N, float)
        self.w       = np.asarray(w, float)

    @cached_property
    def discount(self):
        return np.exp(-self.r * self.T)

    @cached_property
    def mask(self):
        return (self.T <= 0.0) | (self.sigma_N <= 1e-10)

    @cached_property
    def safe_sqrt_T(self):
        return np.where(~self.mask, np.sqrt(self.T), 1.0)

    @cached_property
    def d(self):
        return (self.F - self.K) / (self.sigma_N * self.safe_sqrt_T)

    @cached_property
    def price(self):
        val = self.discount * (
            self.w * (self.F - self.K) * cdf(self.w * self.d) + 
            self.sigma_N * np.sqrt(np.maximum(self.T, 0.0)) * pdf(self.d)
        )
        payoff = np.maximum(0.0, self.w * (self.F - self.K))
        return self._result(np.where(self.mask, payoff, val))

    @cached_property
    def delta(self):
        val = self.w * self.discount * cdf(self.w * self.d)
        payoff = np.where(self.w * (self.F - self.K) > 0, self.w * self.discount, 0.0)
        return self._result(np.where(self.mask, payoff, val))

    @cached_property
    def gamma(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            val = self.discount * pdf(self.d) / (self.sigma_N * self.safe_sqrt_T)
        return self._result(np.where(self.mask, 0.0, val))

    @cached_property
    def vega(self):
        val = self.discount * self.safe_sqrt_T * pdf(self.d)
        return self._result(np.where(self.mask, 0.0, val))

    @cached_property
    def rho(self):
        val = -self.T * self.price
        return self._result(np.where(self.T <= 0, 0.0, val))

    @cached_property
    def theta(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            term1 = -(self.discount * self.sigma_N * pdf(self.d)) / (2.0 * np.sqrt(np.maximum(self.T, 1e-10)))
        
        term2 = self.r * self.price
        val = (term1 + term2) / 365.0
        return self._result(np.where(self.T <= 0, 0.0, val))


class BachelierEngine(Engine):
    def calculator(self, option: Option, market: Market):
        if market.F is None and market.S is None:
            raise ValueError("Bachelier requires 'forward' or 'spot'.")
        
        F = market.F if market.F is not None else market.S * np.exp(market.r * option.T)
        
        return BachelierCalculator(
            F=F, K=option.K,   # No np.maximum(F, 1e-10) because Bachelier handles negative F and K!
            T=option.T, r=market.r, sigma_N=market.sigma, w=option.w
        )
