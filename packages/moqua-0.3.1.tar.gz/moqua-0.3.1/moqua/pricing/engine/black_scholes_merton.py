import numpy as np
from moqua.core import pdf, cdf
from moqua.pricing.contracts import Calculator, Engine, Option, Market
from functools import cached_property

class BlackScholesMertonCalculator(Calculator):
    def __init__(self, S, K, T, r, q, sigma, w):
        self.S     = np.asarray(S,     float)
        self.K     = np.asarray(K,     float)
        self.T     = np.asarray(T,     float)
        self.r     = np.asarray(r,     float)
        self.q     = np.asarray(q,     float)
        self.sigma = np.asarray(sigma, float)
        self.w     = np.asarray(w,     float)

    def discount(self):
        return np.exp(-self.r * self.T)

    @cached_property
    def yield_factor(self):
        return np.exp(-self.q * self.T)

    @cached_property
    def mask(self):
        return (self.T <= 0.0) | (self.sigma <= 1e-10)

    @cached_property
    def vol_sqrt_T(self):
        return self.sigma * np.sqrt(np.maximum(self.T, 0.0))

    @cached_property
    def safe_vol(self):
        return np.where(~self.mask, self.vol_sqrt_T, 1.0)

    @cached_property
    def d1(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            return (np.log(self.S / self.K) + (self.r - self.q + 0.5 * self.sigma**2) * self.T) / self.safe_vol

    @cached_property
    def d2(self):
        return self.d1 - self.vol_sqrt_T

    
    @cached_property
    def price(self):
        # C = S*e^(-qT)*N(d1) - K*e^(-rT)*N(d2)   [call, w=+1]
        # P = K*e^(-rT)*N(-d2) - S*e^(-qT)*N(-d1) [put,  w=-1]
        val    = self.w * (self.S * self.yield_factor * cdf(self.w * self.d1)
                         - self.K * self.discount     * cdf(self.w * self.d2))
        payoff = np.maximum(0.0, self.w * (self.S - self.K))
        return self._result(np.where(self.mask, payoff, val))

    @cached_property
    def delta(self):
        val    = self.w * self.yield_factor * cdf(self.w * self.d1)
        payoff = np.where(self.w * (self.S - self.K) > 0, self.w, 0.0)
        return self._result(np.where(self.mask, payoff, val))

    @cached_property
    def gamma(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            val = self.yield_factor * pdf(self.d1) / (self.S * self.vol_sqrt_T)
        bad = self.mask | (self.S <= 0)
        return self._result(np.where(bad, 0.0, val))

    @cached_property
    def vega(self):
        val = self.S * self.yield_factor * pdf(self.d1) * np.sqrt(np.maximum(self.T, 0.0))
        return self._result(np.where(self.mask, 0.0, val))

    @cached_property
    def rho(self):
        val = self.w * self.K * self.T * self.discount * cdf(self.w * self.d2)
        return self._result(np.where(self.T <= 0, 0.0, val))

    @cached_property
    def theta(self):
        with np.errstate(divide='ignore', invalid='ignore'):
            term_vol = -(self.S * self.yield_factor * pdf(self.d1) * self.sigma) \
                       / (2.0 * np.sqrt(np.maximum(self.T, 1e-10)))
        term_div = self.q * self.S * self.yield_factor * cdf(self.w * self.d1) * self.w
        term_r   = self.r * self.K * self.discount     * cdf(self.w * self.d2) * self.w
        val = (term_vol + term_div - term_r) / 365.0
        return self._result(np.where(self.T <= 0, 0.0, val))


class BlackScholesMertonEngine(Engine):

    def calculator(self, option: Option, market: Market) -> BlackScholesMertonCalculator:
        if market.S is None:
            raise ValueError("BlackScholesMertonEngine requiert 'spot' (S) dans le Market.")
        q = market.q if market.q is not None else 0.0
        return BlackScholesMertonCalculator(
            S=market.S, K=option.K, T=option.T,
            r=market.r, q=q, sigma=market.sigma, w=option.w
        )

