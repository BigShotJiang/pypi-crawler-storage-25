import numpy as np
from ..contracts import Calculator, Engine, Option, Market

class PortfolioCalculator(Calculator):

    def __init__(self, calculators: list[Calculator]):
        self.calculators = calculators
        
    @property
    def price(self):
        return sum(c.price for c in self.calculators)

    @property
    def delta(self):
        return sum(c.delta for c in self.calculators)

    @property
    def gamma(self):
        return sum(c.gamma for c in self.calculators)

    @property
    def vega(self):
        return sum(c.vega for c in self.calculators)

    @property
    def theta(self):
        return sum(c.theta for c in self.calculators)

    @property
    def rho(self):
        return sum(c.rho for c in self.calculators)


class StrategyPricer:

    def __init__(self, engine: Engine):
        self.engine = engine

    def straddle(self, K, T, spot=None, forward=None, r=0.0, sigma=0.0):
        """
        Long Straddle: Buy 1 Call and 1 Put with the same strike and maturity.
        """
        call_opt = Option(K=K, T=T, w=1.0)
        put_opt = Option(K=K, T=T, w=-1.0)
        market = Market(r=r, sigma=sigma, S=spot, F=forward)
        
        calc_call = self.engine.calculator(call_opt, market)
        calc_put = self.engine.calculator(put_opt, market)
        
        return PortfolioCalculator([calc_call, calc_put])
        
    def strangle(self, K_call, K_put, T, spot=None, forward=None, r=0.0, sigma=0.0):
        """
        Long Strangle: Buy 1 Call at K_call and 1 Put at K_put with the same maturity.
        Usually K_put < K_call (Out of the money).
        """
        call_opt = Option(K=K_call, T=T, w=1.0)
        put_opt = Option(K=K_put, T=T, w=-1.0)
        market = Market(r=r, sigma=sigma, S=spot, F=forward)
        
        calc_call = self.engine.calculator(call_opt, market)
        calc_put = self.engine.calculator(put_opt, market)
        
        return PortfolioCalculator([calc_call, calc_put])
        