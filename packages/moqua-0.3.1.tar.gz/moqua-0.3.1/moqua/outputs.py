# -*- coding: utf-8 -*-
"""
Generic Output and Visualization Tools for Quantitative Strategies
"""

import pandas as pd
import numpy as np
import logging
import pickle
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.dates import DateFormatter


# -----------------------------------------------------------------------------
# LEGACY FUNCTIONS (Kept for compatibility)
# -----------------------------------------------------------------------------

def create_excel_report(pairs_results: list, filename="pairs_analysis_report.xlsx"):
    """
    Crée un rapport Excel avec les résultats de l'analyse.
    """
    if not pairs_results:
        print("Aucun résultat à exporter.")
        return

    df = pd.DataFrame(pairs_results)
    
    # Ordonner les colonnes (si présentes)
    cols = ['pair', 'score', 'z_score', 'coint_t', 'coint_pvalue', 
            'half_life', 'hurst', 'kpss_stat', 'kpss_pvalue', 'intercept', 
            'beta', 'status', 'r_squared']
    
    existing_cols = [c for c in cols if c in df.columns]
    other_cols = [c for c in df.columns if c not in cols]
    final_cols = existing_cols + other_cols
    
    df = df[final_cols]

    try:
        # Créer le dossier parent si nécessaire
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Analysis Results', index=False)
            
            # Formatage conditionnel simple
            worksheet = writer.sheets['Analysis Results']
            for idx, col in enumerate(df.columns):
                max_len = max(df[col].astype(str).map(len).max(), len(col)) + 2
                worksheet.column_dimensions[chr(65 + idx)].width = min(max_len, 50)
                
        print(f"Rapport Excel généré : {filename}")
        
    except Exception as e:
        print(f"Erreur lors de la génération du rapport Excel : {e}")

def create_pdf_report(pairs_results: list, price_data: dict, filename="pairs_analysis_report.pdf"):
    """
    Génère un rapport PDF avec les graphiques des meilleures paires.
    Legacy function: Use PairPlotter class for new implementations.
    """
    if not pairs_results:
        return

    # Convertir en DataFrame si nécessaire pour trier
    if isinstance(pairs_results, list):
        df_res = pd.DataFrame(pairs_results)
    else:
        df_res = pairs_results

    # Filtrer les paires valides
    valid_pairs = df_res[df_res['status'] == 'VALID'].copy()
    
    # Trier par score décroissant
    if 'score' in valid_pairs.columns:
        top_pairs = valid_pairs.sort_values('score', ascending=False).head(20)
    else:
        top_pairs = valid_pairs.head(20)

    if top_pairs.empty:
        print("Aucune paire valide à tracer.")
        return

    print(f"Génération du PDF ({len(top_pairs)} paires)...")

    try:
        with PdfPages(filename) as pdf:
            for _, row in top_pairs.iterrows():
                try:
                    pair = row['pair']
                    assets = pair.split('-')
                    if len(assets) != 2: continue
                    
                    a, b = assets[0], assets[1]
                    
                    # Récupérer les données
                    # Note: price_data structure depend du format passé (dict de df ou autre)
                    # Implementation simplifiée pour compatibilité
                    pass 

                except Exception as e:
                    print(f"Erreur plot {pair}: {e}")
                    continue
                    
        print(f"PDF généré : {filename}")

    except Exception as e:
        print(f"Erreur globale PDF : {e}")


# -----------------------------------------------------------------------------
# PAIR PLOTTER BASE CLASS (Strategy Visualization)
# -----------------------------------------------------------------------------

class PairPlotter:
    """
    Base class for visualizing trading pairs.
    Handles generic plotting logic (PDF generation, price normalization, data loading)
    while allowing strategies to customize the 'spread' or specific chart visualization.
    """
    def __init__(self, viz_data_path: str = None):
        self.viz_data_path = viz_data_path
        self.equities_df = None
        self.index_df = None
        self.results = pd.DataFrame()
        self.pair_data = {}
        
        # Configuration Matplotlib Standard (A4 Landscape / 2:1 Ratio aspect but A4 width)
        # 11.69 x 5.85 inches (Half of A4 Landscape essentially)
        self.figsize = (11.69, 5.85)
        plt.rcParams['font.size'] = 10
        plt.rcParams['figure.figsize'] = self.figsize

    def load_data(self):
        """Loads visualization data from PKL"""
        # Determine path if not provided
        if not self.viz_data_path:
            # Try default locations
            possible_paths = [
                Path("visualization_data.pkl"),
                Path(__file__).resolve().parent.parent / "LS EQUITY" / "SELECTION" / "SELECTION MARKET NEUTRAL" / "visualization_data.pkl"
            ]
            for p in possible_paths:
                if p.exists():
                    self.viz_data_path = p
                    break
        
        if not self.viz_data_path or not Path(self.viz_data_path).exists():
            logging.error(f"Visualization data not found: {self.viz_data_path}")
            return False

        try:
            logging.info(f"Loading visualization data from {self.viz_data_path}...")
            with open(self.viz_data_path, 'rb') as f:
                viz_data = pickle.load(f)
            
            price_data = viz_data.get('price_data', {})
            self.equities_df = price_data.get('equities_df')
            self.index_df = price_data.get('index_df')
            self.pair_data = viz_data.get('pair_data', {})
            self.results = viz_data.get('results_summary', pd.DataFrame())
            
            # Filter results to match pair_data availability
            if not self.results.empty and self.pair_data:
                available = list(self.pair_data.keys())
                 # Check where pair name is stored
                if 'pair' in self.results.columns:
                    self.results = self.results[self.results['pair'].isin(available)].copy()
                elif 'pair' not in self.results.columns and self.results.index.name == 'pair':
                     self.results = self.results[self.results.index.isin(available)].copy()
                     self.results['pair'] = self.results.index
            
            logging.info(f"Data Loaded: {len(self.results)} pairs ready.")
            return True
        except Exception as e:
            logging.error(f"Error loading data: {e}")
            return False

    def plot_normalized_prices(self, ax, pair_name):
        """Generic plot: Normalized Prices (Asset A vs Asset B)"""
        if pair_name not in self.pair_data: return
        
        # Basic parsing (assumes "AssetA-AssetB" format)
        try:
            a, b = pair_name.split("-", 1)
        except ValueError:
            ax.text(0.5, 0.5, f"Invalid Pair Name: {pair_name}", ha='center')
            return

        price_a = self.equities_df[a].dropna() if a in self.equities_df.columns else pd.Series(dtype=float)
        price_b = self.equities_df[b].dropna() if b in self.equities_df.columns else pd.Series(dtype=float)
        
        common = price_a.index.intersection(price_b.index)
        
        if len(common) > 10:
            p_a = price_a.loc[common]
            p_b = price_b.loc[common]
            
            # Rebase to 1.0
            ax.plot(common, p_a / p_a.iloc[0], label=a, linewidth=0.9)
            ax.plot(common, p_b / p_b.iloc[0], label=b, linewidth=0.9)
            
            ax.set_title(f'Normalized Prices - {pair_name}', fontweight='bold')
            ax.legend()
            ax.grid(True, alpha=0.3)
            ax.xaxis.set_major_formatter(DateFormatter('%y-%m'))
            ax.set_ylabel('Normalized Price')
            ax.set_xlabel('Date')
        else:
            ax.text(0.5, 0.5, "Insufficient Price Data", ha='center')

    def plot_spread(self, ax, pair_name, **kwargs):
        """Abstract method: Must be implemented by strategy subclass"""
        ax.text(0.5, 0.5, "Spread Plot Not Implemented (Base Class)", ha='center')

    def generate_pdf(self, filename="analysis_results.pdf", top_n=10, asset_filter=None):
        """Orchestrates PDF generation"""
        if self.results.empty:
            logging.warning("No results to plot.")
            return

        # Filter by asset if requested
        if asset_filter:
             df_plot = self.results[self.results['pair'].str.contains(asset_filter, na=False)].copy()
        else:
             df_plot = self.results.copy()

        # Deduplicate and slice
        if 'pair' in df_plot.columns:
            top_pairs = df_plot.drop_duplicates(subset=['pair']).head(top_n)
        else:
            top_pairs = df_plot.head(top_n) # Fallback
        
        if top_pairs.empty:
            logging.warning(f"No pairs found for filter: {asset_filter}")
            return

        logging.info(f"Generating PDF: {filename} ({len(top_pairs)} pairs)...")
        
        with PdfPages(filename) as pdf:
            for i, (_, row) in enumerate(top_pairs.iterrows()):
                pair_name = row['pair'] if 'pair' in row else row.name
                
                # Standard A4 Landscape / 2:1 Ratio Layout
                fig, axes = plt.subplots(1, 2, figsize=self.figsize)
                
                # Plot 1: Standard Normalized Prices
                self.plot_normalized_prices(axes[0], pair_name)
                
                # Plot 2: Strategy Specific Spread
                self.plot_spread(axes[1], pair_name, row=row)
                
                # Title
                score = row.get('score', 0)
                z = row.get('current_z', 0)
                # Handle half-life unit (days or years) display logic if needed upstream
                hl = row.get('half_life_days', row.get('half_life', 0))

                univ = row.get('universe', '?')
                title = f"Opportunity {i+1}: {pair_name} ({univ}) - Score: {score:.4f} | Z: {z:.2f} | HL: {hl:.1f}d"
                fig.suptitle(title, fontsize=12, fontweight='bold', y=0.98)
                
                plt.tight_layout(rect=[0, 0.03, 1, 0.95])
                # USER REQUEST: "que la page soit en fonction du graphique"
                # bbox_inches='tight' forces the page to wrap the content exactly
                pdf.savefig(fig, bbox_inches='tight') 
                plt.close(fig)
        
        logging.info("PDF Generation Complete.")
