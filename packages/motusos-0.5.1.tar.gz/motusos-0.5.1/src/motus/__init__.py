# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Motus: local event-backed work ledger.

Motus records bounded work as Store runs and append-only events, then derives
operator-facing packets, evidence lists, decisions, and receipts as projections.
"""

from __future__ import annotations

__version__ = "0.5.1"
__author__ = "Motus Contributors"

from .exceptions import (  # noqa: E402
    ConfigError,
    MCError,
    SessionError,
    SessionNotFoundError,
    SessionParseError,
    TranscriptError,
    WebError,
)


def get_logger(*args, **kwargs):  # type: ignore[no-untyped-def]
    """Return a Motus logger without importing logging/config at package import."""

    from .logging import get_logger as _get_logger

    return _get_logger(*args, **kwargs)

__all__ = [
    "MCError",
    "SessionError",
    "SessionNotFoundError",
    "SessionParseError",
    "ConfigError",
    "WebError",
    "TranscriptError",
    "get_logger",
    "__version__",
]
