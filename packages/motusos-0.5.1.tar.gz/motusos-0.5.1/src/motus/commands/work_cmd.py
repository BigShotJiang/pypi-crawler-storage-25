# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Work command handlers.

Implements CLI access to work transactions and supporting lease utilities.
"""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from typing import Any, Literal

from rich.console import Console

from ..coordination.schemas import ClaimedResource as Resource
from . import work_store_bridge

console = Console()
_BRIDGE_OK_STATUSES = {"recorded", "replayed", "disabled"}


def _get_agent_id() -> str:
    """Get agent ID from env or default."""
    return os.environ.get("MC_AGENT_ID", "default")


def _decision(decision: str, reason_code: str, message: str) -> SimpleNamespace:
    return SimpleNamespace(
        decision=decision,
        reason_code=reason_code,
        human_message=message,
        owner=None,
    )


def _lease(
    lease_id: str,
    *,
    agent_id: str,
    ttl_s: int = 3600,
    status: str = "active",
    outcome: str | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        lease_id=lease_id,
        status=status,
        owner_agent_id=agent_id,
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=ttl_s),
        outcome=outcome,
    )


class _StoreOnlyWorkCompiler:
    """Minimal Store-backed work compiler used when legacy internals are absent.

    The public wheel intentionally excludes internal context/lens machinery. The
    CLI work loop still needs a compatibility shape, so this adapter returns the
    same response fields while the Store bridge owns durable truth.
    """

    def __init__(self, *_args: Any, **_kwargs: Any) -> None:
        pass

    def claim_work(
        self,
        *,
        task_id: str,
        resources: list[Resource],
        intent: str,
        agent_id: str,
        ttl_s: int = 3600,
    ) -> SimpleNamespace:
        lease_id = f"lease-{uuid.uuid4().hex[:12]}"
        return SimpleNamespace(
            decision=_decision("GRANTED", "STORE_ONLY_COMPAT", "claimed"),
            lease=_lease(lease_id, agent_id=agent_id, ttl_s=ttl_s),
        )

    def get_context(self, lease_id: str, *, intent: str | None = None) -> SimpleNamespace:
        snapshot = work_store_bridge.snapshot_for_lease(lease_id)
        if snapshot is None:
            return SimpleNamespace(
                decision=_decision("DENIED", "LEASE_NOT_FOUND", "Lease not found."),
                lens={},
                lease=None,
            )
        return SimpleNamespace(
            decision=_decision("GRANTED", "STORE_CONTEXT", "Context available from Store."),
            lens={"lens_version": "store-only", "intent": intent},
            lease=_lease(lease_id, agent_id=_get_agent_id()),
        )

    def put_outcome(
        self,
        lease_id: str,
        outcome_type: str,
        *,
        path: str | None = None,
        description: str | None = None,
    ) -> SimpleNamespace:
        if not self._open_run_exists(lease_id):
            return SimpleNamespace(accepted=False, outcome_id=None, message="Lease not found.")
        return SimpleNamespace(
            accepted=True,
            outcome_id=f"outcome-{uuid.uuid4().hex[:12]}",
            message="outcome",
        )

    def record_evidence(
        self,
        lease_id: str,
        evidence_type: str,
        *,
        test_results: dict[str, Any] | None = None,
        diff_summary: str | None = None,
        log_excerpt: str | None = None,
    ) -> SimpleNamespace:
        if not self._open_run_exists(lease_id):
            return SimpleNamespace(accepted=False, evidence_id=None, message="Lease not found.")
        return SimpleNamespace(
            accepted=True,
            evidence_id=f"evidence-{uuid.uuid4().hex[:12]}",
            message="evidence",
        )

    def record_decision(
        self,
        lease_id: str,
        decision: str,
        *,
        rationale: str | None = None,
        alternatives_considered: list[str] | None = None,
    ) -> SimpleNamespace:
        if not self._open_run_exists(lease_id):
            return SimpleNamespace(accepted=False, decision_id=None, message="Lease not found.")
        return SimpleNamespace(
            accepted=True,
            decision_id=f"decision-{uuid.uuid4().hex[:12]}",
            message="decision",
        )

    def release_work(
        self,
        lease_id: str,
        outcome: str,
        *,
        rollback: Literal["auto", "skip"] = "auto",
    ) -> SimpleNamespace:
        snapshot = work_store_bridge.snapshot_for_lease(lease_id)
        if snapshot is None:
            return SimpleNamespace(
                decision=_decision("DENIED", "LEASE_NOT_FOUND", "Lease not found."),
                lease=None,
            )
        run = snapshot.get("run", {})
        if run.get("outcome") is not None:
            reason = "RELEASED_IDEMPOTENT_REPLAY"
            message = "released replay"
        else:
            reason = "RELEASED_OK"
            message = "released"
        return SimpleNamespace(
            decision=_decision("GRANTED", reason, message),
            lease=_lease(lease_id, agent_id=_get_agent_id(), status="released", outcome=outcome),
        )

    def get_receipt(self, _lease_id: str) -> None:
        return None

    def cleanup_leases(self) -> int:
        return 0

    def get_lease(self, _lease_id: str) -> None:
        return None

    def get_outcomes(self, _lease_id: str) -> list[dict[str, object]]:
        return []

    def get_evidence(self, _lease_id: str) -> list[dict[str, object]]:
        return []

    def get_decisions(self, _lease_id: str) -> list[dict[str, object]]:
        return []

    def _open_run_exists(self, lease_id: str) -> bool:
        snapshot = work_store_bridge.snapshot_for_lease(lease_id)
        if snapshot is None:
            return False
        return snapshot.get("run", {}).get("outcome") is None


def _get_work_compiler() -> Any:
    """Return the Store-only compatibility compiler.

    The public work command writes durable truth through `work_store_bridge`.
    The old WorkCompiler remains importable as a compatibility shim, but the CLI
    no longer selects the legacy lease/lens implementation in source checkouts.
    """

    return _StoreOnlyWorkCompiler()


def _kernel_snapshot(run_id: str) -> dict[str, Any] | None:
    store_path = work_store_bridge.configured_store_path()
    if store_path is None:
        return None
    if not store_path.is_file():
        return None
    try:
        from motus.kernel import Store

        return Store(store_path, migrate=False, readonly=True).snapshot(run_id)
    except (KeyError, OSError, RuntimeError, ValueError):
        return None


def _kernel_work_packet(run_id: str) -> dict[str, Any] | None:
    snapshot = _kernel_snapshot(run_id)
    if snapshot is None:
        return None
    from motus.kernel import project_work_packet

    return project_work_packet(snapshot)


def _kernel_receipt(run_id: str) -> dict[str, Any] | None:
    snapshot = _kernel_snapshot(run_id)
    if snapshot is None:
        return None
    from motus.kernel import project_receipt

    return project_receipt(snapshot)


def _attach_bridge(output: dict[str, Any], bridge: work_store_bridge.BridgeResult) -> None:
    output["kernel_bridge"] = bridge.as_json()
    if bridge.run_id:
        output["kernel_run_id"] = bridge.run_id


def _bridge_required_error(bridge: work_store_bridge.BridgeResult) -> str | None:
    if bridge.status in _BRIDGE_OK_STATUSES:
        return None
    detail = f"Store bridge did not record durable truth (status={bridge.status})"
    if bridge.error:
        detail = f"{detail}: {bridge.error}"
    return detail


def _attach_bridge_required_error(
    output: dict[str, Any],
    bridge: work_store_bridge.BridgeResult,
) -> str | None:
    error = _bridge_required_error(bridge)
    if error is not None:
        output["store_required_error"] = error
        output["next_action"] = (
            "Fix the Store write failure or set MOTUS_WORK_STORE_BRIDGE=disabled "
            "for explicit legacy compatibility recovery."
        )
    return error


def _parse_resource(spec: str) -> Resource:
    """Parse TYPE:PATH resource spec into Resource."""
    if ":" not in spec:
        # Default to file type
        return Resource(type="file", path=spec)
    type_part, path_part = spec.split(":", 1)
    return Resource(type=type_part, path=path_part)


def cmd_work_claim(args: Any) -> int:
    """Handle: motus work claim <task_id>"""
    wc = _get_work_compiler()
    agent_id = getattr(args, "agent", None) or _get_agent_id()
    as_json = getattr(args, "json", False)

    # Parse resources
    resource_specs = getattr(args, "resources", None) or []
    resources = [_parse_resource(r) for r in resource_specs]

    # If no resources specified, use task_id as placeholder
    if not resources:
        resources = [Resource(type="task", path=args.task_id)]

    intent = getattr(args, "intent", None) or f"Work on {args.task_id}"
    ttl_s = getattr(args, "ttl", 3600)

    result = wc.claim_work(
        task_id=args.task_id,
        resources=resources,
        intent=intent,
        agent_id=agent_id,
        ttl_s=ttl_s,
    )
    bridge = (
        work_store_bridge.record_claim(
            lease_id=result.lease.lease_id,
            work_id=args.task_id,
            intent=intent,
            agent_id=agent_id,
            resources=resources,
            ttl_s=ttl_s,
        )
        if result.decision.decision == "GRANTED" and result.lease
        else work_store_bridge.BridgeResult("not_applicable")
    )

    if as_json:
        output = {
            "decision": result.decision.decision,
            "reason_code": result.decision.reason_code,
            "lease_id": result.lease.lease_id if result.lease else None,
            "message": result.decision.human_message,
        }
        _attach_bridge(output, bridge)
        bridge_error = (
            _attach_bridge_required_error(output, bridge)
            if result.decision.decision == "GRANTED"
            else None
        )
        console.print_json(json.dumps(output))
        return 0 if result.decision.decision == "GRANTED" and bridge_error is None else 1

    if result.decision.decision == "GRANTED":
        bridge_error = _bridge_required_error(bridge)
        if bridge_error is not None:
            console.print(f"[red]{bridge_error}[/red]")
            console.print(
                "[dim]Set MOTUS_WORK_STORE_BRIDGE=disabled only for explicit legacy recovery.[/dim]"
            )
            return 1
        console.print(f"[green]Claimed: {args.task_id}[/green]")
        console.print(f"[cyan]Lease ID: {result.lease.lease_id}[/cyan]")
        if bridge.run_id:
            console.print(f"[cyan]Store Run: {bridge.run_id}[/cyan]")
        console.print(f"[dim]Expires: {result.lease.expires_at.isoformat()}[/dim]")
        console.print(
            f"\n[dim]Next: motus work evidence {result.lease.lease_id} test_result --passed 1 --failed 0[/dim]"
        )
        console.print(f"[dim]Optional: motus work context {result.lease.lease_id}[/dim]")
    else:
        console.print(f"[red]{result.decision.human_message}[/red]")
        if result.decision.owner:
            console.print(f"[yellow]Held by: {result.decision.owner.agent_id}[/yellow]")

    return 0 if result.decision.decision == "GRANTED" else 1


def cmd_work_context(args: Any) -> int:
    """Handle: motus work context <lease_id>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)
    intent = getattr(args, "intent", None)

    result = wc.get_context(args.lease_id, intent=intent)

    if as_json:
        output = {
            "decision": result.decision.decision,
            "reason_code": result.decision.reason_code,
            "lens": result.lens,
            "lease_status": result.lease.status if result.lease else None,
        }
        console.print_json(json.dumps(output, default=str))
        return 0 if result.decision.decision == "GRANTED" else 1

    if result.decision.decision == "GRANTED":
        console.print("[green]Context assembled[/green]")
        console.print(f"[dim]Lens version: {result.lens.get('lens_version', 'unknown')}[/dim]")
        console.print(f"[dim]Policy version: {result.lens.get('policy_version', 'unknown')}[/dim]")

        # Show resource specs count
        resource_specs = result.lens.get("resource_specs", [])
        policy_snippets = result.lens.get("policy_snippets", [])
        console.print(f"\nResources: {len(resource_specs)}")
        console.print(f"Policy snippets: {len(policy_snippets)}")

        # Show warnings if any
        warnings = result.lens.get("warnings", [])
        if warnings:
            console.print("\n[yellow]Warnings:[/yellow]")
            for w in warnings:
                console.print(f"  - {w.get('message', str(w))}")
    else:
        console.print(f"[red]{result.decision.human_message}[/red]")

    return 0 if result.decision.decision == "GRANTED" else 1


def cmd_work_outcome(args: Any) -> int:
    """Handle: motus work outcome <lease_id> <type>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    result = wc.put_outcome(
        args.lease_id,
        args.outcome_type,
        path=getattr(args, "path", None),
        description=getattr(args, "description", None),
    )
    bridge = (
        work_store_bridge.record_outcome(
            lease_id=args.lease_id,
            outcome_id=result.outcome_id,
            outcome_type=args.outcome_type,
            path_value=getattr(args, "path", None),
            description=getattr(args, "description", None),
            agent_id=_get_agent_id(),
        )
        if result.accepted
        else work_store_bridge.BridgeResult("not_applicable")
    )

    if as_json:
        output = {
            "accepted": result.accepted,
            "outcome_id": result.outcome_id,
            "message": result.message,
        }
        _attach_bridge(output, bridge)
        bridge_error = _attach_bridge_required_error(output, bridge) if result.accepted else None
        console.print_json(json.dumps(output))
        return 0 if result.accepted and bridge_error is None else 1

    if result.accepted:
        bridge_error = _bridge_required_error(bridge)
        if bridge_error is not None:
            console.print(f"[red]{bridge_error}[/red]")
            return 1
        console.print(f"[green]Outcome registered: {result.outcome_id}[/green]")
        console.print(f"[dim]Type: {args.outcome_type}[/dim]")
    else:
        console.print(f"[red]{result.message}[/red]")

    return 0 if result.accepted else 1


def cmd_work_evidence(args: Any) -> int:
    """Handle: motus work evidence <lease_id> <type>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    # Build test results if provided
    test_results = None
    if any([getattr(args, "passed", None), getattr(args, "failed", None), getattr(args, "skipped", None)]):
        test_results = {
            "passed": getattr(args, "passed", 0) or 0,
            "failed": getattr(args, "failed", 0) or 0,
            "skipped": getattr(args, "skipped", 0) or 0,
        }

    result = wc.record_evidence(
        args.lease_id,
        args.evidence_type,
        test_results=test_results,
        diff_summary=getattr(args, "diff", None),
        log_excerpt=getattr(args, "log", None),
    )
    bridge = (
        work_store_bridge.record_evidence(
            lease_id=args.lease_id,
            evidence_id=result.evidence_id,
            evidence_type=args.evidence_type,
            test_results=test_results,
            diff_summary=getattr(args, "diff", None),
            log_excerpt=getattr(args, "log", None),
            agent_id=_get_agent_id(),
        )
        if result.accepted
        else work_store_bridge.BridgeResult("not_applicable")
    )

    if as_json:
        output = {
            "accepted": result.accepted,
            "evidence_id": result.evidence_id,
            "message": result.message,
        }
        _attach_bridge(output, bridge)
        bridge_error = _attach_bridge_required_error(output, bridge) if result.accepted else None
        console.print_json(json.dumps(output))
        return 0 if result.accepted and bridge_error is None else 1

    if result.accepted:
        bridge_error = _bridge_required_error(bridge)
        if bridge_error is not None:
            console.print(f"[red]{bridge_error}[/red]")
            return 1
        console.print(f"[green]Evidence recorded: {result.evidence_id}[/green]")
        console.print(f"[dim]Type: {args.evidence_type}[/dim]")
    else:
        console.print(f"[red]{result.message}[/red]")

    return 0 if result.accepted else 1


def cmd_work_decision(args: Any) -> int:
    """Handle: motus work decision <lease_id> <text>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    result = wc.record_decision(
        args.lease_id,
        args.decision_text,
        rationale=getattr(args, "rationale", None),
        alternatives_considered=getattr(args, "alternatives", None),
    )
    bridge = (
        work_store_bridge.record_decision(
            lease_id=args.lease_id,
            decision_id=result.decision_id,
            decision_text=args.decision_text,
            rationale=getattr(args, "rationale", None),
            alternatives=getattr(args, "alternatives", None),
            agent_id=_get_agent_id(),
        )
        if result.accepted
        else work_store_bridge.BridgeResult("not_applicable")
    )

    if as_json:
        output = {
            "accepted": result.accepted,
            "decision_id": result.decision_id,
            "message": result.message,
        }
        _attach_bridge(output, bridge)
        bridge_error = _attach_bridge_required_error(output, bridge) if result.accepted else None
        console.print_json(json.dumps(output))
        return 0 if result.accepted and bridge_error is None else 1

    if result.accepted:
        bridge_error = _bridge_required_error(bridge)
        if bridge_error is not None:
            console.print(f"[red]{bridge_error}[/red]")
            return 1
        console.print(f"[green]Decision logged: {result.decision_id}[/green]")
    else:
        console.print(f"[red]{result.message}[/red]")

    return 0 if result.accepted else 1


def cmd_work_release(args: Any) -> int:
    """Handle: motus work release <lease_id> <outcome>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)
    rollback: Literal["auto", "skip"] = "skip" if getattr(args, "no_rollback", False) else "auto"

    result = wc.release_work(
        args.lease_id,
        args.outcome,
        rollback=rollback,
    )
    bridge = (
        work_store_bridge.record_release(
            lease_id=args.lease_id,
            outcome=args.outcome,
            decision=result.decision.decision,
            reason_code=result.decision.reason_code,
            message=result.decision.human_message,
            agent_id=_get_agent_id(),
        )
        if result.decision.decision == "GRANTED"
        else work_store_bridge.BridgeResult("not_applicable")
    )
    receipt = wc.get_receipt(args.lease_id)
    kernel_receipt = work_store_bridge.receipt_for_lease(args.lease_id)

    if as_json:
        output: dict[str, Any] = {
            "decision": result.decision.decision,
            "reason_code": result.decision.reason_code,
            "message": result.decision.human_message,
            "lease_status": result.lease.status if result.lease else None,
            "receipt_id": (
                receipt.receipt_id
                if receipt
                else kernel_receipt["receipt_id"]
                if kernel_receipt
                else None
            ),
            "next_action": (
                receipt.next_action
                if receipt
                else kernel_receipt["next_action"]
                if kernel_receipt
                else None
            ),
        }
        _attach_bridge(output, bridge)
        if kernel_receipt is not None:
            output["kernel_receipt"] = kernel_receipt
        bridge_error = (
            _attach_bridge_required_error(output, bridge)
            if result.decision.decision == "GRANTED"
            else None
        )
        console.print_json(json.dumps(output, default=str))
        return 0 if result.decision.decision == "GRANTED" and bridge_error is None else 1

    if result.decision.decision == "GRANTED":
        bridge_error = _bridge_required_error(bridge)
        if bridge_error is not None:
            console.print(f"[red]{bridge_error}[/red]")
            return 1
        console.print(f"[green]Released: {result.decision.reason_code}[/green]")
        if result.lease:
            console.print(f"[dim]Final status: {result.lease.status}[/dim]")
        if bridge.run_id:
            console.print(f"[cyan]Store Run: {bridge.run_id}[/cyan]")
        if receipt:
            console.print(f"[cyan]Receipt ID: {receipt.receipt_id}[/cyan]")
            console.print(f"[dim]Inspect: motus work receipt {args.lease_id}[/dim]")
    else:
        console.print(f"[red]{result.decision.human_message}[/red]")

    return 0 if result.decision.decision == "GRANTED" else 1


def cmd_work_status(args: Any) -> int:
    """Handle: motus work status <lease_id>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    # Keep status truthful if the lease expired between CLI invocations.
    wc.cleanup_leases()
    lease = wc.get_lease(args.lease_id)
    outcomes = wc.get_outcomes(args.lease_id)
    evidence = wc.get_evidence(args.lease_id)
    decisions = wc.get_decisions(args.lease_id)

    if as_json:
        kernel_packet = work_store_bridge.packet_for_lease(args.lease_id)
        if kernel_packet is None and lease is None:
            kernel_packet = _kernel_work_packet(args.lease_id)
        if lease is None and kernel_packet is not None:
            output = {
                "lease_id": args.lease_id,
                "status": kernel_packet["status"],
                "lease_status": kernel_packet["status"],
                "kernel_run": True,
                "work_packet": kernel_packet,
                "packet": kernel_packet,
            }
            console.print_json(json.dumps(output, default=str))
            return 0
        output = {
            "lease_id": args.lease_id,
            "lease_status": lease.status if lease else "not_found",
            "outcomes": outcomes,
            "evidence": evidence,
            "decisions": decisions,
        }
        if kernel_packet is not None:
            output["kernel_run"] = True
            output["work_packet"] = kernel_packet
        console.print_json(json.dumps(output, default=str))
        return 0

    if lease is None:
        kernel_packet = work_store_bridge.packet_for_lease(args.lease_id) or _kernel_work_packet(args.lease_id)
        if kernel_packet is not None:
            console.print(f"[bold]Run: {args.lease_id}[/bold]")
            console.print(f"Status: {kernel_packet['status']}")
            console.print(f"Intent: {kernel_packet['intent']}")
            console.print(f"Events: {len(kernel_packet['events'])}")
            if kernel_packet["receipt_id"]:
                console.print(f"Receipt: {kernel_packet['receipt_id']}")
            return 0
        console.print(f"[red]Lease not found: {args.lease_id}[/red]")
        return 1

    console.print(f"[bold]Lease: {args.lease_id}[/bold]")
    console.print(f"Status: {lease.status}")
    console.print(f"Agent: {lease.owner_agent_id}")
    console.print(f"Expires: {lease.expires_at.isoformat()}")

    if outcomes:
        console.print(f"\n[cyan]Outcomes ({len(outcomes)}):[/cyan]")
        for o in outcomes:
            console.print(f"  - {o['outcome_type']}: {o.get('path', o.get('description', 'N/A'))}")

    if evidence:
        console.print(f"\n[cyan]Evidence ({len(evidence)}):[/cyan]")
        for e in evidence:
            console.print(f"  - {e['evidence_type']}: {e['evidence_id']}")

    if decisions:
        console.print(f"\n[cyan]Decisions ({len(decisions)}):[/cyan]")
        for d in decisions:
            console.print(f"  - {d['decision']}")

    return 0


def cmd_work_receipt(args: Any) -> int:
    """Handle: motus work receipt <lease_id>"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    wc.cleanup_leases()
    kernel_receipt = work_store_bridge.receipt_for_lease(args.lease_id)
    if kernel_receipt is not None:
        if as_json:
            output = {
                "lease_id": args.lease_id,
                "kernel_run": True,
                "receipt": kernel_receipt,
            }
            console.print_json(json.dumps(output, default=str))
            return 0
        console.print(f"[bold]Receipt: {kernel_receipt['receipt_id']}[/bold]")
        console.print(f"Run: {kernel_receipt['run_id']}")
        console.print(f"Status: {kernel_receipt['status']}")
        console.print(f"Outcome: {kernel_receipt['outcome']}")
        console.print(f"Recorded: {kernel_receipt['recorded_at']}")
        console.print(f"Accepted close: {'yes' if kernel_receipt['accepted_close'] else 'no'}")
        console.print(f"\nSummary: {kernel_receipt['summary']}")
        console.print(f"\nNext: {kernel_receipt['next_action']}")
        return 0

    receipt = wc.get_receipt(args.lease_id)

    if receipt is None:
        kernel_receipt = _kernel_receipt(args.lease_id)
        if kernel_receipt is not None:
            if as_json:
                output = {
                    "lease_id": args.lease_id,
                    "kernel_run": True,
                    "receipt": kernel_receipt,
                }
                console.print_json(json.dumps(output, default=str))
                return 0
            console.print(f"[bold]Receipt: {kernel_receipt['receipt_id']}[/bold]")
            console.print(f"Run: {kernel_receipt['run_id']}")
            console.print(f"Status: {kernel_receipt['status']}")
            console.print(f"Outcome: {kernel_receipt['outcome']}")
            console.print(f"Recorded: {kernel_receipt['recorded_at']}")
            console.print(f"Accepted close: {'yes' if kernel_receipt['accepted_close'] else 'no'}")
            console.print(f"\nSummary: {kernel_receipt['summary']}")
            console.print(f"\nNext: {kernel_receipt['next_action']}")
            return 0
        kernel_packet = work_store_bridge.packet_for_lease(args.lease_id) or _kernel_work_packet(args.lease_id)
        lease = wc.get_lease(args.lease_id)
        if as_json:
            output = {
                "lease_id": args.lease_id,
                "found": False,
                "kernel_run": kernel_packet is not None,
                "message": (
                    "Receipt is not available until the work reaches a terminal state."
                    if lease is not None or kernel_packet is not None
                    else "Lease not found."
                ),
            }
            console.print_json(json.dumps(output))
        else:
            if lease is None and kernel_packet is None:
                console.print(f"[red]Lease not found: {args.lease_id}[/red]")
            else:
                console.print(
                    "[yellow]Receipt is not available until the work reaches a terminal state.[/yellow]"
                )
        return 1

    if as_json:
        console.print_json(json.dumps(receipt.__dict__, default=str))
        return 0

    console.print(f"[bold]Receipt: {receipt.receipt_id}[/bold]")
    console.print(f"Lease: {receipt.lease_id}")
    if receipt.work_id:
        console.print(f"Work: {receipt.work_id}")
    console.print(f"Status: {receipt.status}")
    if receipt.outcome:
        console.print(f"Outcome: {receipt.outcome}")
    if receipt.recorded_at:
        console.print(f"Recorded: {receipt.recorded_at}")
    console.print(f"Accepted close: {'yes' if receipt.accepted_close else 'no'}")
    console.print(f"\nSummary: {receipt.summary}")

    if receipt.outcomes:
        console.print(f"\n[cyan]Outcomes ({len(receipt.outcomes)}):[/cyan]")
        for item in receipt.outcomes:
            target = item.get("path") or item.get("description") or "N/A"
            console.print(f"  - {item['outcome_type']}: {target}")

    if receipt.evidence_ids:
        console.print(f"\n[cyan]Evidence ({len(receipt.evidence_ids)}):[/cyan]")
        for evidence_id in receipt.evidence_ids:
            console.print(f"  - {evidence_id}")

    if receipt.decision_summaries:
        console.print(f"\n[cyan]Decisions ({len(receipt.decision_summaries)}):[/cyan]")
        for summary in receipt.decision_summaries:
            console.print(f"  - {summary}")

    console.print(f"\nNext: {receipt.next_action}")
    return 0


def cmd_work_cleanup(args: Any) -> int:
    """Handle: motus work cleanup"""
    wc = _get_work_compiler()
    as_json = getattr(args, "json", False)

    expired_count = wc.cleanup_leases()

    if as_json:
        output = {
            "expired_count": expired_count,
        }
        console.print_json(json.dumps(output))
        return 0

    console.print(f"[green]Expired leases: {expired_count}[/green]")
    return 0


def cmd_work_list(args: Any) -> int:
    """Handle: motus work list"""
    as_json = getattr(args, "json", False)
    include_all = getattr(args, "all", False)

    items = work_store_bridge.list_work_items(include_all=include_all)
    if not items:
        legacy_db_path = _existing_legacy_db_path()
        if legacy_db_path is not None:
            items = _legacy_work_items(legacy_db_path, include_all=include_all)

    if as_json:
        console.print_json(json.dumps({"items": items, "count": len(items)}))
        return 0

    if not items:
        console.print("[yellow]No Store-backed work runs found.[/yellow]")
        return 0

    from rich.table import Table

    table = Table(title="Active Work Runs" if not include_all else "Work Runs")
    table.add_column("Lease ID", style="dim")
    table.add_column("Task ID")
    table.add_column("Agent")
    table.add_column("Claimed")
    table.add_column("Expires")
    table.add_column("Status", style="dim")

    for item in items:
        table.add_row(
            item["lease_id"],
            item["task_id"] or "-",
            item["agent_id"],
            item["claimed_at"],
            item["expires_at"],
            item["status"],
        )

    console.print(table)
    return 0


def _legacy_work_items(db_path: Path, *, include_all: bool) -> list[dict[str, Any]]:
    from ..core.database_connection import DatabaseManager

    db = DatabaseManager(db_path)
    with db.readonly_connection() as conn:
        table = conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'coordination_leases'"
        ).fetchone()
        if table is None:
            return []

        if include_all:
            query = """
                SELECT lease_id, owner_agent_id, work_id, issued_at, expires_at, status
                FROM coordination_leases
                ORDER BY issued_at DESC
            """
            params: tuple[Any, ...] = ()
        else:
            query = """
                SELECT lease_id, owner_agent_id, work_id, issued_at, expires_at, status
                FROM coordination_leases
                WHERE status = 'active'
                AND expires_at > mc_now_iso()
                AND heartbeat_deadline > mc_now_iso()
                ORDER BY issued_at DESC
            """
            params = ()

        rows = conn.execute(query, params).fetchall()

    return [
        {
            "lease_id": r["lease_id"],
            "task_id": r["work_id"],
            "agent_id": r["owner_agent_id"],
            "claimed_at": r["issued_at"],
            "expires_at": r["expires_at"],
            "status": r["status"],
        }
        for r in rows
    ]


def _existing_legacy_db_path() -> Path | None:
    candidates: list[Path] = []
    raw_env = os.environ.get("MC_DB_PATH")
    if raw_env and raw_env.strip():
        candidates.append(Path(raw_env).expanduser())

    config_path = Path.home() / ".motus" / "config.json"
    if config_path.is_file():
        try:
            data = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {}
        for key in ("db_path", "database.path"):
            value = data.get(key)
            if isinstance(value, str) and value.strip():
                candidates.append(Path(value).expanduser())

    candidates.append(Path.home() / ".motus" / "coordination.db")

    seen: set[Path] = set()
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.is_file():
            return candidate
    return None


def handle_work_command(args: Any) -> int:
    """Dispatch work subcommand."""
    subcommand = getattr(args, "work_command", None)

    if subcommand == "claim":
        return cmd_work_claim(args)
    elif subcommand == "context":
        return cmd_work_context(args)
    elif subcommand == "outcome":
        return cmd_work_outcome(args)
    elif subcommand == "evidence":
        return cmd_work_evidence(args)
    elif subcommand == "decision":
        return cmd_work_decision(args)
    elif subcommand == "release":
        return cmd_work_release(args)
    elif subcommand == "status":
        return cmd_work_status(args)
    elif subcommand == "receipt":
        return cmd_work_receipt(args)
    elif subcommand == "cleanup":
        return cmd_work_cleanup(args)
    elif subcommand == "list":
        return cmd_work_list(args)
    else:
        console.print(
            "[yellow]Usage: motus work <claim|context|outcome|evidence|decision|release|status|receipt|cleanup|list>[/yellow]"
        )
        console.print("\nQuickstart loop:")
        console.print("  1. motus work claim <task_id>     - Claim work and get a lease")
        console.print("  2. motus work evidence <lease_id> - Attach proof while work happens")
        console.print("  3. motus work release <lease_id>  - Close with a terminal outcome")
        console.print("  4. motus work receipt <lease_id>  - Inspect the durable close record")
        console.print("\nOptional supporting commands:")
        console.print("  - motus work context <lease_id>   - Refresh bounded context")
        console.print("  - motus work outcome <lease_id>   - Register primary deliverable")
        console.print("  - motus work decision <lease_id>  - Log a decision rationale")
        return 0
