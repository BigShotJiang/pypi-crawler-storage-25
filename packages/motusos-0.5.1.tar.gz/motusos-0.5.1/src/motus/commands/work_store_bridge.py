# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Store bridge for the legacy ``motus work`` command loop."""

from __future__ import annotations

import dataclasses
import os
import re
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from motus.kernel import Store

SOURCE = "motus-work"
PRODUCER_PREFIX = "motus-work:"
DEFAULT_STORE_PATH = Path(".motus") / "kernel-store.db"


@dataclasses.dataclass(frozen=True)
class BridgeResult:
    status: str
    run_id: str | None = None
    store_path: str | None = None
    event_id: str | None = None
    error: str | None = None

    def as_json(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"status": self.status}
        if self.run_id:
            payload["run_id"] = self.run_id
        if self.store_path:
            payload["store_path"] = self.store_path
        if self.event_id:
            payload["event_id"] = self.event_id
        if self.error:
            payload["error"] = self.error
        return payload


def configured_store_path() -> Path | None:
    """Return the Store path, or ``None`` when bridge is explicitly disabled."""

    mode = os.environ.get("MOTUS_WORK_STORE_BRIDGE", "auto").strip().lower()
    if mode in {"0", "false", "off", "disabled", "no"}:
        return None
    raw = os.environ.get("MOTUS_KERNEL_STORE_PATH") or os.environ.get("MOTUS_STORE_PATH")
    if raw and raw.strip():
        return Path(raw).expanduser()
    return Path.cwd() / DEFAULT_STORE_PATH


def receipt_for_lease(lease_id: str) -> dict[str, Any] | None:
    snapshot = snapshot_for_lease(lease_id)
    if snapshot is None:
        return None
    from motus.kernel import project_receipt

    return project_receipt(snapshot)


def packet_for_lease(lease_id: str) -> dict[str, Any] | None:
    snapshot = snapshot_for_lease(lease_id)
    if snapshot is None:
        return None
    from motus.kernel import project_work_packet

    return project_work_packet(snapshot)


def snapshot_for_lease(lease_id: str) -> dict[str, Any] | None:
    path = configured_store_path()
    if path is None or not path.is_file():
        return None
    try:
        store = Store(path, migrate=False, readonly=True)
        run_id = find_run_id_for_lease(store, lease_id)
        return store.snapshot(run_id) if run_id else None
    except (KeyError, OSError, RuntimeError, ValueError):
        return None


def list_work_items(*, include_all: bool = False) -> list[dict[str, Any]]:
    path = configured_store_path()
    if path is None or not path.is_file():
        return []
    try:
        store = Store(path, migrate=False, readonly=True)
        runs = list(reversed(store.list_runs(source=SOURCE)))
    except (OSError, RuntimeError, ValueError):
        return []

    items: list[dict[str, Any]] = []
    for run in runs:
        if not include_all and run.outcome is not None:
            continue
        try:
            snapshot = store.snapshot(run.id)
        except (KeyError, OSError, RuntimeError, ValueError):
            continue
        claim = _claim_payload(snapshot)
        lease_id = str(claim.get("lease_id") or run.id)
        ttl_s = claim.get("ttl_s")
        items.append(
            {
                "lease_id": lease_id,
                "task_id": str(claim.get("work_id") or run.id),
                "agent_id": str(claim.get("agent_id") or run.producer_id),
                "claimed_at": run.started_at,
                "expires_at": _expires_at(run.started_at, ttl_s),
                "status": "active" if run.outcome is None else "released",
            }
        )
    return items


def record_claim(
    *,
    lease_id: str,
    work_id: str,
    intent: str,
    agent_id: str,
    resources: list[Any],
    ttl_s: int,
) -> BridgeResult:
    path = configured_store_path()
    if path is None:
        return BridgeResult("disabled")
    try:
        store = _writable_store(path)
        hashes = register_work_kinds(store)
        producer = _producer(agent_id)
        run = store.start_run(
            source=SOURCE,
            intent=intent,
            cwd=str(Path.cwd()),
            git_sha=_git_sha(Path.cwd()),
            idempotency_key=f"claim:{lease_id}",
            producer_id=producer,
        )
        event = store.log_event(
            run_id=run.id,
            schema_kind="work.claim",
            schema_hash=hashes["work.claim"],
            payload={
                "lease_id": lease_id,
                "work_id": work_id,
                "agent_id": agent_id,
                "intent": intent,
                "resource_specs": [_resource_payload(item) for item in resources],
                "ttl_s": int(ttl_s),
            },
            idempotency_key=f"claim:{lease_id}:event",
            producer_id=producer,
        )
        return BridgeResult("recorded", run.id, str(path), event.id)
    except Exception as exc:
        return BridgeResult("failed", store_path=str(path), error=type(exc).__name__)


def record_outcome(
    *,
    lease_id: str,
    outcome_id: str | None,
    outcome_type: str,
    path_value: str | None,
    description: str | None,
    agent_id: str,
) -> BridgeResult:
    payload = {
        "lease_id": lease_id,
        "legacy_outcome_id": outcome_id,
        "outcome_type": outcome_type,
        "path": path_value,
        "description": description,
        "summary": description or path_value or outcome_type,
    }
    return _record_event(
        lease_id=lease_id,
        schema_kind=f"outcome.{_kind_suffix(outcome_type)}",
        schema=_schema(
            ["lease_id", "outcome_type", "summary"],
            {
                "lease_id": {"type": "string"},
                "legacy_outcome_id": {"type": ["string", "null"]},
                "outcome_type": {"type": "string"},
                "path": {"type": ["string", "null"]},
                "description": {"type": ["string", "null"]},
                "summary": {"type": "string"},
            },
        ),
        payload=payload,
        idempotency_key=f"outcome:{lease_id}:{outcome_id or outcome_type}",
        agent_id=agent_id,
    )


def record_evidence(
    *,
    lease_id: str,
    evidence_id: str | None,
    evidence_type: str,
    test_results: dict[str, Any] | None,
    diff_summary: str | None,
    log_excerpt: str | None,
    agent_id: str,
) -> BridgeResult:
    payload = {
        "lease_id": lease_id,
        "legacy_evidence_id": evidence_id,
        "evidence_type": evidence_type,
        "summary": _evidence_summary(evidence_type, test_results, diff_summary),
        "test_results": test_results,
        "diff_summary": diff_summary,
        "log_excerpt": log_excerpt,
    }
    return _record_event(
        lease_id=lease_id,
        schema_kind=f"evidence.motus_work.{_kind_suffix(evidence_type)}",
        schema=_schema(
            ["lease_id", "evidence_type", "summary"],
            {
                "lease_id": {"type": "string"},
                "legacy_evidence_id": {"type": ["string", "null"]},
                "evidence_type": {"type": "string"},
                "summary": {"type": "string"},
                "test_results": {"type": ["object", "null"]},
                "diff_summary": {"type": ["string", "null"]},
                "log_excerpt": {"type": ["string", "null"]},
            },
        ),
        payload=payload,
        idempotency_key=f"evidence:{lease_id}:{evidence_id or evidence_type}",
        agent_id=agent_id,
    )


def record_decision(
    *,
    lease_id: str,
    decision_id: str | None,
    decision_text: str,
    rationale: str | None,
    alternatives: list[str] | None,
    agent_id: str,
) -> BridgeResult:
    payload = {
        "lease_id": lease_id,
        "legacy_decision_id": decision_id,
        "decision": decision_text,
        "rationale": rationale,
        "alternatives_considered": alternatives or [],
    }
    return _record_event(
        lease_id=lease_id,
        schema_kind="decision.motus_work",
        schema=_schema(
            ["lease_id", "decision"],
            {
                "lease_id": {"type": "string"},
                "legacy_decision_id": {"type": ["string", "null"]},
                "decision": {"type": "string"},
                "rationale": {"type": ["string", "null"]},
                "alternatives_considered": {"type": "array"},
            },
        ),
        payload=payload,
        idempotency_key=f"decision:{lease_id}:{decision_id or _kind_suffix(decision_text)}",
        agent_id=agent_id,
    )


def record_release(
    *,
    lease_id: str,
    outcome: str,
    decision: str,
    reason_code: str,
    message: str,
    agent_id: str,
) -> BridgeResult:
    path = configured_store_path()
    if path is None:
        return BridgeResult("disabled")
    try:
        if not path.is_file():
            return BridgeResult("not_found", store_path=str(path))
        store = Store(path)
        run_id = find_run_id_for_lease(store, lease_id)
        if run_id is None:
            return BridgeResult("not_found", store_path=str(path))
        existing = _closed_release_event(store, run_id)
        if existing is not None:
            return BridgeResult("replayed", run_id, str(path), existing.get("event_id"))
        hashes = register_work_kinds(store)
        producer = _producer(agent_id)
        event = store.log_event(
            run_id=run_id,
            schema_kind="work.release",
            schema_hash=hashes["work.release"],
            payload={
                "lease_id": lease_id,
                "outcome": outcome,
                "decision": decision,
                "reason_code": reason_code,
                "message": message,
            },
            idempotency_key=f"release:{lease_id}:{outcome}",
            producer_id=producer,
        )
        store.end_run(
            run_id=run_id,
            outcome=_store_outcome(outcome),
            outcome_note=f"motus work released {outcome}: {reason_code}",
            idempotency_key=f"release:{lease_id}:close:{outcome}",
            producer_id=producer,
        )
        return BridgeResult("recorded", run_id, str(path), event.id)
    except Exception as exc:
        return BridgeResult("failed", store_path=str(path), error=type(exc).__name__)


def register_work_kinds(store: Store) -> dict[str, str]:
    return {
        "work.claim": store.register_kind(
            "work.claim",
            _schema(
                ["lease_id", "work_id", "agent_id", "intent", "resource_specs"],
                {
                    "lease_id": {"type": "string"},
                    "work_id": {"type": "string"},
                    "agent_id": {"type": "string"},
                    "intent": {"type": "string"},
                    "resource_specs": {"type": "array"},
                    "ttl_s": {"type": "integer"},
                },
            ),
        ),
        "work.release": store.register_kind(
            "work.release",
            _schema(
                ["lease_id", "outcome", "decision", "reason_code"],
                {
                    "lease_id": {"type": "string"},
                    "outcome": {"type": "string"},
                    "decision": {"type": "string"},
                    "reason_code": {"type": "string"},
                    "message": {"type": "string"},
                },
            ),
        ),
    }


def find_run_id_for_lease(store: Store, lease_id: str) -> str | None:
    for run in reversed(store.list_runs(source=SOURCE)):
        if run.id == lease_id:
            return run.id
        snapshot = store.snapshot(run.id)
        for event in snapshot.get("events", []):
            if event.get("schema_kind") != "work.claim":
                continue
            payload = _event_payload(event)
            if payload.get("lease_id") == lease_id:
                return run.id
    return None


def _record_event(
    *,
    lease_id: str,
    schema_kind: str,
    schema: dict[str, Any],
    payload: dict[str, Any],
    idempotency_key: str,
    agent_id: str,
) -> BridgeResult:
    path = configured_store_path()
    if path is None:
        return BridgeResult("disabled")
    try:
        if not path.is_file():
            return BridgeResult("not_found", store_path=str(path))
        store = Store(path)
        run_id = find_run_id_for_lease(store, lease_id)
        if run_id is None:
            return BridgeResult("not_found", store_path=str(path))
        schema_hash = store.register_kind(schema_kind, schema)
        producer = _producer(agent_id)
        event = store.log_event(
            run_id=run_id,
            schema_kind=schema_kind,
            schema_hash=schema_hash,
            payload=payload,
            idempotency_key=idempotency_key,
            producer_id=producer,
        )
        return BridgeResult("recorded", run_id, str(path), event.id)
    except Exception as exc:
        return BridgeResult("failed", store_path=str(path), error=type(exc).__name__)


def _writable_store(path: Path) -> Store:
    path.parent.mkdir(parents=True, exist_ok=True)
    return Store(path)


def _schema(required: list[str], properties: dict[str, dict[str, Any]]) -> dict[str, Any]:
    return {"type": "object", "required": required, "properties": properties}


def _producer(agent_id: str) -> str:
    return f"{PRODUCER_PREFIX}{agent_id or 'default'}"


def _resource_payload(item: Any) -> dict[str, Any]:
    return {
        "type": str(getattr(item, "type", "resource")),
        "path": str(getattr(item, "path", item)),
    }


def _event_payload(event: dict[str, Any]) -> dict[str, Any]:
    payload_json = event.get("payload_json")
    if isinstance(payload_json, str):
        import json

        parsed = json.loads(payload_json)
        if isinstance(parsed, dict):
            return parsed
    payload = event.get("payload")
    return payload if isinstance(payload, dict) else {}


def _claim_payload(snapshot: dict[str, Any]) -> dict[str, Any]:
    for event in snapshot.get("events", []):
        if event.get("schema_kind") == "work.claim":
            return _event_payload(event)
    return {}


def _expires_at(started_at: str, ttl_s: Any) -> str:
    if not isinstance(ttl_s, int):
        return ""
    try:
        started = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
    except ValueError:
        return ""
    return (started + timedelta(seconds=ttl_s)).astimezone(timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )


def _kind_suffix(value: str) -> str:
    suffix = re.sub(r"[^a-zA-Z0-9_.-]+", "_", value.strip().lower()).strip("._-")
    return suffix or "other"


def _evidence_summary(
    evidence_type: str,
    test_results: dict[str, Any] | None,
    diff_summary: str | None,
) -> str:
    if test_results:
        passed = test_results.get("passed", 0)
        failed = test_results.get("failed", 0)
        skipped = test_results.get("skipped", 0)
        return f"{evidence_type}: passed={passed} failed={failed} skipped={skipped}"
    if diff_summary:
        return diff_summary
    return f"{evidence_type} evidence recorded"


def _store_outcome(outcome: str) -> str:
    if outcome in {"success", "partial"}:
        return "success"
    if outcome == "aborted":
        return "aborted"
    return "failure"


def _closed_release_event(store: Store, run_id: str) -> dict[str, Any] | None:
    snapshot = store.snapshot(run_id)
    if snapshot.get("run", {}).get("outcome") is None:
        return None
    for event in reversed(snapshot.get("events", [])):
        if event.get("schema_kind") != "work.release":
            continue
        view = {
            "event_id": event.get("id"),
            "payload": _event_payload(event),
        }
        return view
    return None


def _git_sha(cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    return result.stdout.strip() if result.returncode == 0 and result.stdout.strip() else None
