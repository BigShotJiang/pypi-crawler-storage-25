# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""CLI command: `motus doctor` (health diagnostics)."""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import time
from dataclasses import dataclass
from enum import Enum
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Callable, Dict

from rich.console import Console

from motus.cli.exit_codes import EXIT_ERROR, EXIT_SUCCESS
from motus.config_loader import get_config_path
from motus.kernel import Store

MIN_DISK_FREE_BYTES = 100 * 1024 * 1024
MAX_LOG_BYTES = 100 * 1024 * 1024
MAX_WAL_BYTES = 50 * 1024 * 1024
CONFLICTING_DISTS = ("motus", "motus-command")
SHADOWED_MARKERS = ("motus-command", "motus-internal")


class HealthStatus(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"


@dataclass(frozen=True)
class HealthResult:
    name: str
    status: HealthStatus
    message: str | None = None
    details: Dict[str, Any] | None = None
    duration_ms: float | None = None


HealthCheck = Callable[[], HealthResult]


class HealthChecker:
    def __init__(self) -> None:
        self._checks: list[HealthCheck] = []

    def register(self, check: HealthCheck) -> None:
        self._checks.append(check)

    def run_all(self) -> list[HealthResult]:
        results: list[HealthResult] = []
        for check in self._checks:
            start = time.monotonic()
            try:
                result = check()
                status = result.status
                message = result.message
                details = result.details
                name = result.name
            except Exception as exc:
                status = HealthStatus.FAIL
                message = str(exc)
                details = None
                name = getattr(check, "__name__", "health_check")
            results.append(
                HealthResult(
                    name=name,
                    status=status,
                    message=message,
                    details=details,
                    duration_ms=(time.monotonic() - start) * 1000,
                )
            )
        return results


@dataclass(frozen=True)
class PackageConflictResult:
    conflict: bool
    conflicts: dict[str, str]
    origin: str | None
    shadowed: bool


def detect_package_conflicts() -> PackageConflictResult:
    conflicts: dict[str, str] = {}
    for dist in CONFLICTING_DISTS:
        try:
            conflicts[dist] = version(dist)
        except PackageNotFoundError:
            continue

    origin = None
    shadowed = False
    try:
        import motus as motus_pkg  # type: ignore

        origin = str(Path(motus_pkg.__file__).resolve())
        shadowed = any(marker in origin for marker in SHADOWED_MARKERS)
    except Exception:
        pass

    return PackageConflictResult(
        conflict=bool(conflicts) or shadowed,
        conflicts=conflicts,
        origin=origin,
        shadowed=shadowed,
    )


def _package_conflict_check() -> HealthResult:
    result = detect_package_conflicts()
    if not result.conflict:
        return HealthResult(
            name="package_conflict",
            status=HealthStatus.PASS,
            message="No conflicting Motus packages detected",
            details={"origin": result.origin},
        )

    if result.conflicts:
        installed = ", ".join(f"{name}=={ver}" for name, ver in result.conflicts.items())
        message = (
            "Conflicting packages installed: "
            f"{installed}. Remove with: pip uninstall motus motus-command -y "
            "and install motusos. If motus-internal is on PYTHONPATH, remove it."
        )
    else:
        message = (
            "Motus import resolves to a non-packaged path. "
            "Remove old packages: pip uninstall motus motus-command -y and install motusos. "
            "If motus-internal is on PYTHONPATH, remove it."
        )

    return HealthResult(
        name="package_conflict",
        status=HealthStatus.FAIL,
        message=message,
        details={"conflicts": result.conflicts, "origin": result.origin},
    )


def _get_store_path() -> Path:
    raw = (
        os.environ.get("MOTUS_KERNEL_STORE_PATH")
        or os.environ.get("MOTUS_STORE_PATH")
        or ""
    ).strip()
    if raw:
        return Path(raw).expanduser()
    return Path.cwd() / ".motus" / "kernel-store.db"


def _store_exists_check(store_path: Path) -> HealthResult:
    if store_path.exists():
        return HealthResult(
            name="store_exists",
            status=HealthStatus.PASS,
            message=f"Store exists: {store_path}",
        )
    return HealthResult(
        name="store_exists",
        status=HealthStatus.WARN,
        message=f"Store not initialized: {store_path}",
    )


def _store_readable_check(store_path: Path) -> HealthResult:
    if not store_path.exists():
        return HealthResult(
            name="store_readable",
            status=HealthStatus.WARN,
            message="Store missing; readability check skipped",
        )
    try:
        Store(store_path, migrate=False, readonly=True).list_runs()
    except (OSError, RuntimeError, sqlite3.DatabaseError, ValueError) as exc:
        return HealthResult(
            name="store_readable",
            status=HealthStatus.FAIL,
            message=str(exc),
        )
    return HealthResult(
        name="store_readable",
        status=HealthStatus.PASS,
        message="Store readable",
    )


def _store_integrity_check(store_path: Path) -> HealthResult:
    if not store_path.exists():
        return HealthResult(
            name="store_integrity",
            status=HealthStatus.WARN,
            message="Store missing; integrity check skipped",
        )
    try:
        result = Store(store_path, migrate=False, readonly=True).integrity_check()
    except (OSError, RuntimeError, sqlite3.DatabaseError, ValueError) as exc:
        return HealthResult(
            name="store_integrity",
            status=HealthStatus.FAIL,
            message=str(exc),
        )
    if result == "ok":
        return HealthResult(
            name="store_integrity",
            status=HealthStatus.PASS,
            message="Integrity check ok",
        )
    return HealthResult(
        name="store_integrity",
        status=HealthStatus.FAIL,
        message=f"Integrity check failed: {result}",
    )


def _store_schema_check(store_path: Path) -> HealthResult:
    if not store_path.exists():
        return HealthResult(
            name="store_schema",
            status=HealthStatus.WARN,
            message="Store missing; schema check skipped",
        )
    try:
        tables = Store(store_path, migrate=False, readonly=True).table_names()
        expected = {"runs", "events", "kind_versions", "locks"}
        missing = sorted(expected - tables)
        extra = sorted(tables - expected)
    except (OSError, RuntimeError, sqlite3.DatabaseError, ValueError) as exc:
        return HealthResult(
            name="store_schema",
            status=HealthStatus.FAIL,
            message=str(exc),
        )
    if missing:
        return HealthResult(
            name="store_schema",
            status=HealthStatus.FAIL,
            message=f"Store schema missing tables: {', '.join(missing)}",
        )
    if extra:
        return HealthResult(
            name="store_schema",
            status=HealthStatus.WARN,
            message=f"Store schema has unexpected tables: {', '.join(extra)}",
        )
    return HealthResult(
        name="store_schema",
        status=HealthStatus.PASS,
        message="Store schema present",
    )


def _config_check() -> HealthResult:
    config_path = get_config_path()
    if not config_path.exists():
        return HealthResult(
            name="config",
            status=HealthStatus.PASS,
            message="Config not found; defaults in use",
        )
    try:
        raw = config_path.read_text(encoding="utf-8")
        json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        return HealthResult(
            name="config",
            status=HealthStatus.FAIL,
            message=f"Config parse error: {exc}",
        )
    return HealthResult(
        name="config",
        status=HealthStatus.PASS,
        message="Config valid",
    )


def _disk_space_check(db_path: Path) -> HealthResult:
    check_path = db_path.parent if db_path.parent.exists() else Path.cwd()
    try:
        usage = shutil.disk_usage(check_path)
    except OSError as exc:
        return HealthResult(
            name="disk_space",
            status=HealthStatus.WARN,
            message=f"Disk space check failed: {exc}",
        )
    if usage.free < MIN_DISK_FREE_BYTES:
        return HealthResult(
            name="disk_space",
            status=HealthStatus.WARN,
            message=f"Low disk space: {usage.free / (1024 * 1024):.1f} MB free",
        )
    return HealthResult(
        name="disk_space",
        status=HealthStatus.PASS,
        message=f"Disk space ok: {usage.free / (1024 * 1024):.1f} MB free",
    )


def _log_size_check() -> HealthResult:
    log_file = Path.home() / ".motus" / "logs" / "motus.log"
    if not log_file.exists():
        return HealthResult(
            name="log_size",
            status=HealthStatus.PASS,
            message="Log file not present",
        )
    size = log_file.stat().st_size
    if size > MAX_LOG_BYTES:
        return HealthResult(
            name="log_size",
            status=HealthStatus.WARN,
            message=f"Log size {size / (1024 * 1024):.1f} MB (rotate recommended)",
        )
    return HealthResult(
        name="log_size",
        status=HealthStatus.PASS,
        message=f"Log size {size / (1024 * 1024):.1f} MB",
    )


def _wal_check(store_path: Path, *, fix: bool = False) -> HealthResult:
    wal_path = Path(str(store_path) + "-wal")
    size = wal_path.stat().st_size if wal_path.exists() else 0
    if size <= MAX_WAL_BYTES:
        return HealthResult(
            name="wal_size",
            status=HealthStatus.PASS,
            message=f"WAL size {size / (1024 * 1024):.1f} MB",
            details={"wal_size_bytes": size},
        )
    if fix:
        try:
            Store(store_path, migrate=False).checkpoint_wal()
        except (OSError, RuntimeError, sqlite3.DatabaseError, ValueError) as exc:
            return HealthResult(
                name="wal_size",
                status=HealthStatus.FAIL,
                message=f"WAL checkpoint failed: {exc}",
                details={"wal_size_bytes": size},
            )
        size = wal_path.stat().st_size if wal_path.exists() else 0
        status = HealthStatus.PASS if size <= MAX_WAL_BYTES else HealthStatus.WARN
        return HealthResult(
            name="wal_size",
            status=status,
            message="WAL checkpointed" if status == HealthStatus.PASS else "WAL still large",
            details={"wal_size_bytes": size},
        )
    return HealthResult(
        name="wal_size",
        status=HealthStatus.WARN,
        message=f"WAL size {size / (1024 * 1024):.1f} MB (consider: motus db checkpoint)",
        details={"wal_size_bytes": size},
    )


def doctor_command(*, json_output: bool = False, fix: bool = False) -> int:
    console = Console()
    checker = HealthChecker()
    store_path = _get_store_path()
    if fix and not store_path.exists():
        store_path.parent.mkdir(parents=True, exist_ok=True)
        Store(store_path)
    checker.register(_package_conflict_check)
    checker.register(lambda: _store_exists_check(store_path))
    checker.register(lambda: _store_readable_check(store_path))
    checker.register(lambda: _store_integrity_check(store_path))
    checker.register(lambda: _store_schema_check(store_path))
    checker.register(_config_check)
    checker.register(lambda: _disk_space_check(store_path))
    checker.register(_log_size_check)
    checker.register(lambda: _wal_check(store_path, fix=fix))
    results = checker.run_all()

    worst = HealthStatus.PASS
    for r in results:
        if r.status == HealthStatus.FAIL:
            worst = HealthStatus.FAIL
            break
        if r.status == HealthStatus.WARN:
            worst = HealthStatus.WARN

    passed = sum(1 for r in results if r.status == HealthStatus.PASS)
    warned = sum(1 for r in results if r.status == HealthStatus.WARN)
    failed = sum(1 for r in results if r.status == HealthStatus.FAIL)

    if json_output:
        payload: Dict[str, Any] = {
            "status": worst.value,
            "summary": {"passed": passed, "warned": warned, "failed": failed},
            "checks": [
                {
                    "name": r.name,
                    "status": r.status.value,
                    "message": r.message,
                    "details": r.details,
                    "duration_ms": r.duration_ms,
                }
                for r in results
            ],
        }
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        for r in results:
            msg = f"{r.name}: {r.status.value}"
            if r.message:
                msg += f" - {r.message}"
            console.print(msg, markup=False)
        console.print(f"Summary: {passed} passed, {warned} warning, {failed} failed", markup=False)
        console.print(f"overall: {worst.value}", markup=False)

    return EXIT_SUCCESS if worst != HealthStatus.FAIL else EXIT_ERROR
