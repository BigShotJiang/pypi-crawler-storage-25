# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Store-backed MCP tool implementations."""

from __future__ import annotations

import os
import secrets
from pathlib import Path
from typing import Any, TypedDict

from motus.kernel import Store
from motus.mcp.serialization import redact_obj, serialize_for_mcp


class RunResult(TypedDict):
    run: dict[str, Any]


class EventResult(TypedDict):
    event: dict[str, Any]


class SnapshotResult(TypedDict):
    snapshot: dict[str, Any]


class ListRunsResult(TypedDict):
    runs: list[dict[str, Any]]


class LockResult(TypedDict):
    lock: dict[str, Any] | None
    released: bool | None


def _store_path() -> Path:
    raw = os.environ.get("MOTUS_KERNEL_STORE_PATH") or os.environ.get("MOTUS_STORE_PATH")
    if raw and raw.strip():
        return Path(raw).expanduser()
    return Path.cwd() / ".motus" / "kernel-store.db"


def _store() -> Store:
    path = _store_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    return Store(path)


def _safe(obj: Any) -> Any:
    return redact_obj(serialize_for_mcp(obj))


def _new_idempotency_key(prefix: str) -> str:
    return f"{prefix}:{secrets.token_hex(16)}"


def motus_start(
    intent: str,
    source: str = "mcp",
    cwd: str | None = None,
    git_sha: str | None = None,
    idempotency_key: str | None = None,
    producer_id: str = "mcp",
) -> RunResult:
    """Start a Store run."""

    run = _store().start_run(
        source=source,
        intent=intent,
        cwd=cwd or str(Path.cwd()),
        git_sha=git_sha,
        idempotency_key=idempotency_key or _new_idempotency_key("mcp:start"),
        producer_id=producer_id,
    )
    return {"run": _safe(run)}


def motus_log(
    run_id: str,
    schema_kind: str,
    payload: dict[str, Any],
    idempotency_key: str,
    producer_id: str = "mcp",
    schema_hash: str | None = None,
    schema: dict[str, Any] | None = None,
) -> EventResult:
    """Append an event to an open Store run.

    If `schema` is supplied, the kind is registered first and the resulting
    schema hash pins this event. Otherwise `schema_hash` or the latest
    registered schema for `schema_kind` must already exist.
    """

    store = _store()
    if schema is not None:
        schema_hash = store.register_kind(schema_kind, schema)
    event = store.log_event(
        run_id=run_id,
        schema_kind=schema_kind,
        payload=payload,
        idempotency_key=idempotency_key,
        producer_id=producer_id,
        schema_hash=schema_hash,
    )
    return {"event": _safe(event)}


def motus_end(
    run_id: str,
    outcome: str,
    outcome_note: str | None = None,
    idempotency_key: str = "mcp:end",
    producer_id: str = "mcp",
) -> RunResult:
    """End a Store run."""

    run = _store().end_run(
        run_id=run_id,
        outcome=outcome,
        outcome_note=outcome_note,
        idempotency_key=idempotency_key,
        producer_id=producer_id,
    )
    return {"run": _safe(run)}


def motus_snapshot(run_id: str) -> SnapshotResult:
    """Return a deterministic Store snapshot."""

    snapshot = Store(_store_path(), migrate=False, readonly=True).snapshot(run_id)
    return {"snapshot": _safe(snapshot)}


def motus_list(source: str | None = None, limit: int = 50) -> ListRunsResult:
    """List Store runs."""

    limit = max(1, min(int(limit), 200))
    runs = Store(_store_path(), migrate=False, readonly=True).list_runs(source=source)[:limit]
    return {"runs": _safe(runs)}


def motus_lock(resource: str, holder: str, ttl_seconds: int = 3600) -> LockResult:
    """Acquire or refresh a fenced Store lock."""

    lock = _store().acquire_lock(resource=resource, holder=holder, ttl_seconds=ttl_seconds)
    return {"lock": _safe(lock), "released": None}


def motus_unlock(resource: str, holder: str, fencing_token: int) -> LockResult:
    """Release a fenced Store lock."""

    released = _store().release_lock(
        resource=resource,
        holder=holder,
        fencing_token=fencing_token,
    )
    return {"lock": None, "released": released}
