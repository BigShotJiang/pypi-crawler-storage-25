# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""MCP server implementation using FastMCP (stdio transport)."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .tools import (
    motus_end,
    motus_list,
    motus_lock,
    motus_log,
    motus_snapshot,
    motus_start,
    motus_unlock,
)


def create_server() -> FastMCP:
    """Create and configure the Store-backed MCP server."""

    mcp = FastMCP("motus")
    mcp.tool(structured_output=True)(motus_start)
    mcp.tool(structured_output=True)(motus_log)
    mcp.tool(structured_output=True)(motus_end)
    mcp.tool(structured_output=True)(motus_snapshot)
    mcp.tool(structured_output=True)(motus_list)
    mcp.tool(structured_output=True)(motus_lock)
    mcp.tool(structured_output=True)(motus_unlock)
    return mcp


def run_server() -> None:
    """Run the MCP server (stdio transport)."""

    server = create_server()
    server.run()
