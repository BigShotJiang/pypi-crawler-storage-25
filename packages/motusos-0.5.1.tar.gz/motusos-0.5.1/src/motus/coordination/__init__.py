# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Narrow lease-compatibility primitives.

The public kernel owns durable run/event truth. This package remains only for
the legacy ``motus work`` resource shape while that command bridges to Store.
"""

from __future__ import annotations

from motus.coordination.schemas import ClaimedResource

__all__ = [
    "ClaimedResource",
]
