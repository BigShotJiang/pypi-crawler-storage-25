# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""GitHub Action adapter over the Motus Store-backed command wrapper."""

from __future__ import annotations

import argparse
import json
import os
import shlex
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO

from motus.kernel import Store, project_receipt
from motus.wrap import DEFAULT_MAX_OUTPUT_BYTES, run_wrap


@dataclass(frozen=True)
class GitHubActionResult:
    exit_code: int
    run_id: str | None
    store_path: Path | None
    export_path: Path | None
    receipt_path: Path | None
    outcome: str | None


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def _write_github_output(path: Path, values: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        for key, value in values.items():
            handle.write(f"{key}={value}\n")


def _emit_outputs(values: dict[str, str], output_path: Path | None) -> None:
    if output_path is None:
        return
    _write_github_output(output_path, values)


def run_github_action(
    *,
    command: str,
    store_path: Path,
    export_path: Path,
    receipt_path: Path,
    max_output_bytes: int = DEFAULT_MAX_OUTPUT_BYTES,
    timeout_seconds: float | None = None,
    github_output_path: Path | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> GitHubActionResult:
    """Run a GitHub Action command and emit Store export/receipt artifacts."""

    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    argv = shlex.split(command)
    if not argv:
        stderr.write("motus github action requires a non-empty command\n")
        _emit_outputs({"exit_code": "2", "outcome": "failure"}, github_output_path)
        return GitHubActionResult(2, None, None, None, None, "failure")

    result = run_wrap(
        argv,
        db_path=store_path,
        source="github-actions",
        producer_id=os.environ.get("GITHUB_RUN_ID") or "github-actions",
        idempotency_key=os.environ.get("GITHUB_RUN_ATTEMPT")
        and f"github-actions:{os.environ.get('GITHUB_RUN_ID', 'run')}:{os.environ['GITHUB_RUN_ATTEMPT']}",
        max_output_bytes=max_output_bytes,
        timeout_seconds=timeout_seconds,
        stdout=stdout,
        stderr=stderr,
    )
    if result.run_id is None or result.store_path is None:
        _emit_outputs({"exit_code": str(result.exit_code), "outcome": "failure"}, github_output_path)
        return GitHubActionResult(result.exit_code, None, None, None, None, result.outcome)

    store = Store(result.store_path, migrate=False, readonly=True)
    snapshot = store.snapshot(result.run_id)
    export_path.parent.mkdir(parents=True, exist_ok=True)
    export_path.write_text(store.export_run(result.run_id) + "\n", encoding="utf-8")
    receipt = project_receipt(snapshot)
    _write_json(receipt_path, receipt or {"error": "run is not closed", "run_id": result.run_id})

    outputs = {
        "run_id": result.run_id,
        "store_path": str(result.store_path),
        "export_path": str(export_path),
        "receipt_path": str(receipt_path),
        "outcome": result.outcome or "",
        "exit_code": str(result.exit_code),
    }
    _emit_outputs(outputs, github_output_path)
    return GitHubActionResult(
        result.exit_code,
        result.run_id,
        result.store_path,
        export_path,
        receipt_path,
        result.outcome,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m motus.github_action",
        description="Run a command and write Motus Store export/receipt artifacts.",
    )
    parser.add_argument("--command", required=True, help="Command to run; parsed as shell-like argv")
    parser.add_argument("--store-path", default=".motus/kernel-store.db")
    parser.add_argument("--export-path", default="motus-run-export.json")
    parser.add_argument("--receipt-path", default="motus-receipt.json")
    parser.add_argument("--max-output-bytes", type=int, default=DEFAULT_MAX_OUTPUT_BYTES)
    parser.add_argument("--timeout", type=float)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    output_path = os.environ.get("GITHUB_OUTPUT")
    result = run_github_action(
        command=args.command,
        store_path=Path(args.store_path).expanduser(),
        export_path=Path(args.export_path),
        receipt_path=Path(args.receipt_path),
        max_output_bytes=args.max_output_bytes,
        timeout_seconds=args.timeout,
        github_output_path=Path(output_path) if output_path else None,
    )
    return result.exit_code


if __name__ == "__main__":
    raise SystemExit(main())
