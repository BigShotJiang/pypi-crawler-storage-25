"""Small SQLite Store for the Motus event kernel.

The Store is intentionally isolated from existing CLI/userland machinery. It
proves the run/event/kind/lock invariants before compatibility wrappers are
introduced in a later slice.
"""

from __future__ import annotations

import contextlib
import dataclasses
import datetime as dt
import hashlib
import json
import secrets
import sqlite3
import time
from pathlib import Path
from typing import Any, Iterator
from urllib.parse import quote


class StoreError(RuntimeError):
    """Base Store error."""


class StoreConflictError(StoreError):
    """Raised when an idempotency key or fencing token conflicts."""


class StoreSchemaError(StoreError):
    """Raised when a kind schema or event payload is invalid."""


@dataclasses.dataclass(frozen=True)
class RunRecord:
    id: str
    idempotency_key: str
    producer_id: str
    source: str
    started_at: str
    ended_at: str | None
    intent: str
    cwd: str
    git_sha: str | None
    outcome: str | None
    outcome_note: str | None
    end_idempotency_key: str | None
    end_payload_hash: str | None
    ended_by_producer_id: str | None


@dataclasses.dataclass(frozen=True)
class EventRecord:
    run_id: str
    seq: int
    idempotency_key: str
    id: str
    payload_hash: str
    schema_hash: str
    schema_kind: str
    ts: str
    payload_json: str
    producer_id: str

    @property
    def payload(self) -> dict[str, Any]:
        return json.loads(self.payload_json)


@dataclasses.dataclass(frozen=True)
class LockRecord:
    resource: str
    holder: str
    fencing_token: int
    acquired_at: str
    expires_at: str


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_time(value: str) -> dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _sha256_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _hash_json(value: Any) -> str:
    return _sha256_text(_canonical_json(value))


def _new_id(prefix: str) -> str:
    return f"{prefix}_{time.time_ns():020d}_{secrets.token_hex(6)}"


def _require_non_empty(value: str, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} is required")


class Store:
    """Invariant-enforcing SQLite Store."""

    def __init__(self, path: str | Path, *, migrate: bool = True, readonly: bool = False) -> None:
        if migrate and readonly:
            raise ValueError("readonly Store cannot run migrations")
        store_path = Path(path).expanduser()
        if migrate and str(store_path) != ":memory:":
            store_path.parent.mkdir(parents=True, exist_ok=True)
        self.path = str(store_path)
        self._readonly = readonly
        if migrate:
            self._migrate()

    def start_run(
        self,
        *,
        source: str,
        intent: str,
        cwd: str,
        git_sha: str | None,
        idempotency_key: str,
        producer_id: str,
    ) -> RunRecord:
        self._require_writable()
        _require_non_empty(source, "source")
        _require_non_empty(intent, "intent")
        _require_non_empty(cwd, "cwd")
        _require_non_empty(idempotency_key, "idempotency_key")
        _require_non_empty(producer_id, "producer_id")

        with self._transaction(immediate=True) as conn:
            existing = conn.execute(
                """
                SELECT * FROM runs
                WHERE source=? AND producer_id=? AND idempotency_key=?
                """,
                (source, producer_id, idempotency_key),
            ).fetchone()
            if existing is not None:
                run = _run_from_row(existing)
                if run.intent == intent and run.cwd == cwd and run.git_sha == git_sha:
                    return run
                raise StoreConflictError("start_run idempotency key reused with different payload")

            run_id = _new_id("run")
            started_at = _now()
            conn.execute(
                """
                INSERT INTO runs (
                  id, idempotency_key, producer_id, source, started_at, ended_at,
                  intent, cwd, git_sha, outcome, outcome_note, end_idempotency_key,
                  end_payload_hash, ended_by_producer_id
                ) VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, NULL, NULL, NULL, NULL, NULL)
                """,
                (run_id, idempotency_key, producer_id, source, started_at, intent, cwd, git_sha),
            )
            return self._get_run(conn, run_id)

    def register_kind(self, schema_kind: str, schema: dict[str, Any]) -> str:
        self._require_writable()
        _require_non_empty(schema_kind, "schema_kind")
        self._validate_schema_shape(schema)
        schema_json = _canonical_json(schema)
        schema_hash = _sha256_text(schema_json)

        with self._transaction(immediate=True) as conn:
            existing = conn.execute(
                """
                SELECT schema_json FROM kind_versions
                WHERE schema_kind=? AND schema_hash=?
                """,
                (schema_kind, schema_hash),
            ).fetchone()
            if existing is not None:
                return schema_hash

            latest = conn.execute(
                """
                SELECT schema_json FROM kind_versions
                WHERE schema_kind=?
                ORDER BY rowid DESC
                LIMIT 1
                """,
                (schema_kind,),
            ).fetchone()
            if latest is not None:
                self._ensure_additive(json.loads(latest["schema_json"]), schema)

            conn.execute(
                """
                INSERT INTO kind_versions(schema_kind, schema_hash, schema_json, registered_at)
                VALUES (?, ?, ?, ?)
                """,
                (schema_kind, schema_hash, schema_json, _now()),
            )
            return schema_hash

    def log_event(
        self,
        *,
        run_id: str,
        schema_kind: str,
        payload: dict[str, Any],
        idempotency_key: str,
        producer_id: str,
        schema_hash: str | None = None,
    ) -> EventRecord:
        self._require_writable()
        _require_non_empty(run_id, "run_id")
        _require_non_empty(schema_kind, "schema_kind")
        _require_non_empty(idempotency_key, "idempotency_key")
        _require_non_empty(producer_id, "producer_id")
        payload_hash = _hash_json(payload)

        with self._transaction(immediate=True) as conn:
            existing = conn.execute(
                "SELECT * FROM events WHERE run_id=? AND idempotency_key=?",
                (run_id, idempotency_key),
            ).fetchone()
            if existing is not None:
                event = _event_from_row(existing)
                if (
                    event.payload_hash == payload_hash
                    and event.schema_kind == schema_kind
                    and (schema_hash is None or event.schema_hash == schema_hash)
                ):
                    return event
                raise StoreConflictError("log_event idempotency key reused with different payload")

            run = self._get_run(conn, run_id)
            if run.ended_at is not None:
                raise StoreConflictError("cannot append event to closed run")

            schema_hash = schema_hash or self._latest_schema_hash(conn, schema_kind)
            schema = self._get_schema(conn, schema_kind, schema_hash)
            self._validate_payload(schema, payload)

            seq = int(
                conn.execute(
                    "SELECT COALESCE(MAX(seq), 0) + 1 AS next_seq FROM events WHERE run_id=?",
                    (run_id,),
                ).fetchone()["next_seq"]
            )
            event_id = _sha256_text(f"{run_id}\0{idempotency_key}")
            conn.execute(
                """
                INSERT INTO events (
                  run_id, seq, idempotency_key, id, payload_hash, schema_hash,
                  schema_kind, ts, payload_json, producer_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    seq,
                    idempotency_key,
                    event_id,
                    payload_hash,
                    schema_hash,
                    schema_kind,
                    _now(),
                    _canonical_json(payload),
                    producer_id,
                ),
            )
            return self._get_event(conn, run_id, seq)

    def end_run(
        self,
        *,
        run_id: str,
        outcome: str,
        outcome_note: str | None,
        idempotency_key: str,
        producer_id: str,
    ) -> RunRecord:
        self._require_writable()
        _require_non_empty(run_id, "run_id")
        _require_non_empty(outcome, "outcome")
        _require_non_empty(idempotency_key, "idempotency_key")
        _require_non_empty(producer_id, "producer_id")
        if outcome not in {"success", "failure", "aborted"}:
            raise ValueError("outcome must be success, failure, or aborted")
        terminal_payload = {
            "outcome": outcome,
            "outcome_note": outcome_note,
            "producer_id": producer_id,
        }
        terminal_hash = _hash_json(terminal_payload)

        with self._transaction(immediate=True) as conn:
            run = self._get_run(conn, run_id)
            if run.ended_at is not None:
                if (
                    run.end_idempotency_key == idempotency_key
                    and run.end_payload_hash == terminal_hash
                    and run.outcome == outcome
                    and run.outcome_note == outcome_note
                    and run.ended_by_producer_id == producer_id
                ):
                    return run
                raise StoreConflictError("run is already closed")

            conn.execute(
                """
                UPDATE runs
                SET ended_at=?, outcome=?, outcome_note=?, end_idempotency_key=?,
                    end_payload_hash=?, ended_by_producer_id=?
                WHERE id=? AND ended_at IS NULL
                """,
                (_now(), outcome, outcome_note, idempotency_key, terminal_hash, producer_id, run_id),
            )
            return self._get_run(conn, run_id)

    def snapshot(self, run_id: str) -> dict[str, Any]:
        _require_non_empty(run_id, "run_id")
        with self._transaction(immediate=False) as conn:
            run = dataclasses.asdict(self._get_run(conn, run_id))
            events = [
                dataclasses.asdict(_event_from_row(row))
                for row in conn.execute(
                    "SELECT * FROM events WHERE run_id=? ORDER BY seq ASC",
                    (run_id,),
                ).fetchall()
            ]
            return {"run": run, "events": events}

    def export_run(self, run_id: str) -> str:
        return _canonical_json(self.snapshot(run_id))

    def list_runs(self, *, source: str | None = None) -> list[RunRecord]:
        with self._transaction(immediate=False) as conn:
            if source is None:
                rows = conn.execute("SELECT * FROM runs ORDER BY id ASC").fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM runs WHERE source=? ORDER BY id ASC",
                    (source,),
                ).fetchall()
            return [_run_from_row(row) for row in rows]

    def integrity_check(self) -> str | None:
        """Return SQLite integrity_check result for Store health checks."""

        with self._transaction(immediate=False) as conn:
            row = conn.execute("PRAGMA integrity_check").fetchone()
            return str(row[0]) if row else None

    def table_names(self) -> set[str]:
        """Return Store table names for schema health checks."""

        with self._transaction(immediate=False) as conn:
            rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
            return {str(row[0]) for row in rows}

    def checkpoint_wal(self) -> None:
        """Truncate the Store WAL file."""

        self._require_writable()
        conn = self._connect()
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:
            conn.close()

    def acquire_lock(
        self,
        *,
        resource: str,
        holder: str,
        ttl_seconds: int,
        now: dt.datetime | None = None,
    ) -> LockRecord:
        self._require_writable()
        _require_non_empty(resource, "resource")
        _require_non_empty(holder, "holder")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        now_dt = now or dt.datetime.now(dt.timezone.utc)
        acquired_at = now_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        expires_at = (now_dt + dt.timedelta(seconds=ttl_seconds)).strftime("%Y-%m-%dT%H:%M:%SZ")

        with self._transaction(immediate=True) as conn:
            existing = conn.execute("SELECT * FROM locks WHERE resource=?", (resource,)).fetchone()
            if existing is None:
                conn.execute(
                    """
                    INSERT INTO locks(resource, holder, fencing_token, acquired_at, expires_at)
                    VALUES (?, ?, 1, ?, ?)
                    """,
                    (resource, holder, acquired_at, expires_at),
                )
                return self._get_lock(conn, resource)

            lock = _lock_from_row(existing)
            if _parse_time(lock.expires_at) > now_dt:
                if lock.holder == holder:
                    conn.execute(
                        """
                        UPDATE locks
                        SET expires_at=?
                        WHERE resource=? AND holder=? AND fencing_token=?
                        """,
                        (expires_at, resource, holder, lock.fencing_token),
                    )
                    return self._get_lock(conn, resource)
                raise StoreConflictError("resource lock is held")

            conn.execute(
                """
                UPDATE locks
                SET holder=?, fencing_token=?, acquired_at=?, expires_at=?
                WHERE resource=?
                """,
                (holder, lock.fencing_token + 1, acquired_at, expires_at, resource),
            )
            return self._get_lock(conn, resource)

    def assert_lock(
        self,
        *,
        resource: str,
        holder: str,
        fencing_token: int,
        now: dt.datetime | None = None,
    ) -> None:
        now_dt = now or dt.datetime.now(dt.timezone.utc)
        with self._transaction(immediate=False) as conn:
            row = conn.execute("SELECT * FROM locks WHERE resource=?", (resource,)).fetchone()
            if row is None:
                raise StoreConflictError("resource lock is missing")
            lock = _lock_from_row(row)
            if (
                lock.holder != holder
                or lock.fencing_token != fencing_token
                or _parse_time(lock.expires_at) <= now_dt
            ):
                raise StoreConflictError("resource lock fencing token is invalid")

    def release_lock(
        self,
        *,
        resource: str,
        holder: str,
        fencing_token: int,
        now: dt.datetime | None = None,
    ) -> bool:
        self._require_writable()
        now_dt = now or dt.datetime.now(dt.timezone.utc)
        released_at = now_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._transaction(immediate=True) as conn:
            cur = conn.execute(
                """
                UPDATE locks
                SET expires_at=?
                WHERE resource=? AND holder=? AND fencing_token=?
                """,
                (released_at, resource, holder, fencing_token),
            )
            return cur.rowcount == 1

    @contextlib.contextmanager
    def _transaction(self, *, immediate: bool) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _connect(self) -> sqlite3.Connection:
        if self._readonly:
            uri = "file:" + quote(str(Path(self.path).resolve()), safe="/") + "?mode=ro"
            conn = sqlite3.connect(uri, timeout=30, isolation_level=None, uri=True)
        else:
            conn = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _require_writable(self) -> None:
        if self._readonly:
            raise StoreError("Store is open read-only")

    def _migrate(self) -> None:
        with self._connect() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS runs (
                  id TEXT PRIMARY KEY,
                  idempotency_key TEXT NOT NULL,
                  producer_id TEXT NOT NULL,
                  source TEXT NOT NULL,
                  started_at TEXT NOT NULL,
                  ended_at TEXT,
                  intent TEXT NOT NULL,
                  cwd TEXT NOT NULL,
                  git_sha TEXT,
                  outcome TEXT,
                  outcome_note TEXT,
                  end_idempotency_key TEXT,
                  end_payload_hash TEXT,
                  ended_by_producer_id TEXT,
                  UNIQUE (source, producer_id, idempotency_key),
                  CHECK ((ended_at IS NULL) = (outcome IS NULL)),
                  CHECK (outcome IS NULL OR outcome IN ('success','failure','aborted'))
                );

                CREATE TABLE IF NOT EXISTS kind_versions (
                  schema_kind TEXT NOT NULL,
                  schema_hash TEXT NOT NULL,
                  schema_json TEXT NOT NULL,
                  registered_at TEXT NOT NULL,
                  PRIMARY KEY (schema_kind, schema_hash)
                );

                CREATE TABLE IF NOT EXISTS events (
                  run_id TEXT NOT NULL REFERENCES runs(id),
                  seq INTEGER NOT NULL,
                  idempotency_key TEXT NOT NULL,
                  id TEXT NOT NULL,
                  payload_hash TEXT NOT NULL,
                  schema_hash TEXT NOT NULL,
                  schema_kind TEXT NOT NULL,
                  ts TEXT NOT NULL,
                  payload_json TEXT NOT NULL,
                  producer_id TEXT NOT NULL,
                  PRIMARY KEY (run_id, seq),
                  UNIQUE (run_id, idempotency_key),
                  UNIQUE (id),
                  FOREIGN KEY (schema_kind, schema_hash)
                    REFERENCES kind_versions(schema_kind, schema_hash)
                );

                CREATE TABLE IF NOT EXISTS locks (
                  resource TEXT PRIMARY KEY,
                  holder TEXT NOT NULL,
                  fencing_token INTEGER NOT NULL,
                  acquired_at TEXT NOT NULL,
                  expires_at TEXT NOT NULL
                );

                CREATE TRIGGER IF NOT EXISTS events_no_update
                BEFORE UPDATE ON events
                BEGIN
                  SELECT RAISE(ABORT, 'events are append-only');
                END;

                CREATE TRIGGER IF NOT EXISTS events_no_delete
                BEFORE DELETE ON events
                BEGIN
                  SELECT RAISE(ABORT, 'events are append-only');
                END;

                CREATE TRIGGER IF NOT EXISTS events_closed_run_guard
                BEFORE INSERT ON events
                WHEN (SELECT ended_at FROM runs WHERE id=NEW.run_id) IS NOT NULL
                BEGIN
                  SELECT RAISE(ABORT, 'cannot append event to closed run');
                END;

                CREATE TRIGGER IF NOT EXISTS runs_closed_outcome_guard
                BEFORE UPDATE OF ended_at, outcome, outcome_note, end_idempotency_key,
                  end_payload_hash, ended_by_producer_id ON runs
                WHEN OLD.ended_at IS NOT NULL AND (
                  NEW.ended_at IS NOT OLD.ended_at OR
                  NEW.outcome IS NOT OLD.outcome OR
                  NEW.outcome_note IS NOT OLD.outcome_note OR
                  NEW.end_idempotency_key IS NOT OLD.end_idempotency_key OR
                  NEW.end_payload_hash IS NOT OLD.end_payload_hash OR
                  NEW.ended_by_producer_id IS NOT OLD.ended_by_producer_id
                )
                BEGIN
                  SELECT RAISE(ABORT, 'closed run outcome is final');
                END;
                """
            )

    def _get_run(self, conn: sqlite3.Connection, run_id: str) -> RunRecord:
        row = conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        if row is None:
            raise KeyError(run_id)
        return _run_from_row(row)

    def _get_event(self, conn: sqlite3.Connection, run_id: str, seq: int) -> EventRecord:
        row = conn.execute(
            "SELECT * FROM events WHERE run_id=? AND seq=?",
            (run_id, seq),
        ).fetchone()
        if row is None:
            raise KeyError((run_id, seq))
        return _event_from_row(row)

    def _get_lock(self, conn: sqlite3.Connection, resource: str) -> LockRecord:
        row = conn.execute("SELECT * FROM locks WHERE resource=?", (resource,)).fetchone()
        if row is None:
            raise KeyError(resource)
        return _lock_from_row(row)

    def _latest_schema_hash(self, conn: sqlite3.Connection, schema_kind: str) -> str:
        row = conn.execute(
            """
            SELECT schema_hash FROM kind_versions
            WHERE schema_kind=?
            ORDER BY rowid DESC
            LIMIT 1
            """,
            (schema_kind,),
        ).fetchone()
        if row is None:
            raise StoreSchemaError(f"schema kind is not registered: {schema_kind}")
        return str(row["schema_hash"])

    def _get_schema(
        self, conn: sqlite3.Connection, schema_kind: str, schema_hash: str
    ) -> dict[str, Any]:
        row = conn.execute(
            """
            SELECT schema_json FROM kind_versions
            WHERE schema_kind=? AND schema_hash=?
            """,
            (schema_kind, schema_hash),
        ).fetchone()
        if row is None:
            raise StoreSchemaError(f"schema version is not registered: {schema_kind} {schema_hash}")
        return json.loads(row["schema_json"])

    def _validate_schema_shape(self, schema: dict[str, Any]) -> None:
        if not isinstance(schema, dict):
            raise StoreSchemaError("schema must be an object")
        if schema.get("type") != "object":
            raise StoreSchemaError("schema type must be object")
        if not isinstance(schema.get("properties", {}), dict):
            raise StoreSchemaError("schema properties must be an object")
        for name, definition in schema.get("properties", {}).items():
            if not isinstance(name, str) or not isinstance(definition, dict):
                raise StoreSchemaError("schema property definitions must be objects")
        required = schema.get("required", [])
        if not isinstance(required, list) or not all(isinstance(item, str) for item in required):
            raise StoreSchemaError("schema required must be a string list")
        missing = set(required) - set(schema.get("properties", {}))
        if missing:
            raise StoreSchemaError(f"required fields missing from properties: {sorted(missing)}")

    def _ensure_additive(self, old: dict[str, Any], new: dict[str, Any]) -> None:
        old_props = old.get("properties", {})
        new_props = new.get("properties", {})
        old_required = set(old.get("required", []))
        new_required = set(new.get("required", []))
        if new_required != old_required:
            raise StoreSchemaError("schema evolution cannot add or remove required fields")
        for name, old_def in old_props.items():
            if name not in new_props:
                raise StoreSchemaError(f"schema evolution removed field: {name}")
            if _canonical_json(new_props[name]) != _canonical_json(old_def):
                raise StoreSchemaError(f"schema evolution changed field definition: {name}")

    def _validate_payload(self, schema: dict[str, Any], payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            raise StoreSchemaError("payload must be an object")
        properties = schema.get("properties", {})
        for field in schema.get("required", []):
            if field not in payload:
                raise StoreSchemaError(f"payload missing required field: {field}")
        for field, value in payload.items():
            if field in properties:
                self._validate_value(field, value, properties[field])

    def _validate_value(self, field: str, value: Any, schema: dict[str, Any]) -> None:
        if "enum" in schema and value not in schema["enum"]:
            raise StoreSchemaError(f"payload field {field} not in enum")
        expected = schema.get("type")
        if expected is None:
            return
        allowed = expected if isinstance(expected, list) else [expected]
        if not any(_matches_json_type(value, item) for item in allowed):
            raise StoreSchemaError(f"payload field {field} has wrong type")


def _matches_json_type(value: Any, expected: str) -> bool:
    if expected == "null":
        return value is None
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return (isinstance(value, int) or isinstance(value, float)) and not isinstance(value, bool)
    if expected == "string":
        return isinstance(value, str)
    if expected == "array":
        return isinstance(value, list)
    if expected == "object":
        return isinstance(value, dict)
    raise StoreSchemaError(f"unsupported JSON Schema type: {expected}")


StoreConflict = StoreConflictError


def _run_from_row(row: sqlite3.Row) -> RunRecord:
    return RunRecord(
        id=row["id"],
        idempotency_key=row["idempotency_key"],
        producer_id=row["producer_id"],
        source=row["source"],
        started_at=row["started_at"],
        ended_at=row["ended_at"],
        intent=row["intent"],
        cwd=row["cwd"],
        git_sha=row["git_sha"],
        outcome=row["outcome"],
        outcome_note=row["outcome_note"],
        end_idempotency_key=row["end_idempotency_key"],
        end_payload_hash=row["end_payload_hash"],
        ended_by_producer_id=row["ended_by_producer_id"],
    )


def _event_from_row(row: sqlite3.Row) -> EventRecord:
    return EventRecord(
        run_id=row["run_id"],
        seq=int(row["seq"]),
        idempotency_key=row["idempotency_key"],
        id=row["id"],
        payload_hash=row["payload_hash"],
        schema_hash=row["schema_hash"],
        schema_kind=row["schema_kind"],
        ts=row["ts"],
        payload_json=row["payload_json"],
        producer_id=row["producer_id"],
    )


def _lock_from_row(row: sqlite3.Row) -> LockRecord:
    return LockRecord(
        resource=row["resource"],
        holder=row["holder"],
        fencing_token=int(row["fencing_token"]),
        acquired_at=row["acquired_at"],
        expires_at=row["expires_at"],
    )
