"""Read-only product projections over Store snapshots.

The kernel Store records runs and events. These helpers preserve Motus product
language without adding a second packet or receipt store.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _sha256_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _event_payload(event: dict[str, Any]) -> dict[str, Any]:
    payload = event.get("payload")
    if isinstance(payload, dict):
        return payload
    payload_json = event.get("payload_json")
    if isinstance(payload_json, str):
        parsed = json.loads(payload_json)
        if isinstance(parsed, dict):
            return parsed
    return {}


def _event_view(event: dict[str, Any]) -> dict[str, Any]:
    return {
        "seq": event["seq"],
        "event_id": event["id"],
        "schema_kind": event["schema_kind"],
        "schema_hash": event["schema_hash"],
        "payload_hash": event["payload_hash"],
        "producer_id": event["producer_id"],
        "ts": event["ts"],
        "payload": _event_payload(event),
    }


def _events(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    return [_event_view(event) for event in snapshot.get("events", [])]


def _claim_payload(snapshot: dict[str, Any]) -> dict[str, Any]:
    for event in _events(snapshot):
        if event["schema_kind"] == "work.claim":
            return event["payload"]
    return {}


def _release_payload(snapshot: dict[str, Any]) -> dict[str, Any]:
    for event in reversed(_events(snapshot)):
        if event["schema_kind"] == "work.release":
            return event["payload"]
    return {}


def _terminal_outcome(snapshot: dict[str, Any]) -> str | None:
    release = _release_payload(snapshot)
    return release.get("outcome") or snapshot["run"]["outcome"]


def _accepted_close(snapshot: dict[str, Any]) -> bool:
    release = _release_payload(snapshot)
    if release:
        return release.get("outcome") in {"success", "failure", "partial"}
    return snapshot["run"]["outcome"] == "success"


def _kind_suffix(kind: str, prefix: str) -> str:
    if kind.startswith(prefix):
        return kind[len(prefix) :]
    return kind


def project_evidence(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    """Return evidence events as product-level evidence references."""

    evidence = []
    for event in _events(snapshot):
        kind = event["schema_kind"]
        if not kind.startswith("evidence."):
            continue
        evidence.append(
            {
                "evidence_id": event["event_id"],
                "evidence_type": _kind_suffix(kind, "evidence."),
                "recorded_at": event["ts"],
                "producer_id": event["producer_id"],
                "payload": event["payload"],
                "schema_hash": event["schema_hash"],
                "payload_hash": event["payload_hash"],
            }
        )
    return evidence


def project_decisions(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    """Return decision events as product-level decision summaries."""

    decisions = []
    for event in _events(snapshot):
        kind = event["schema_kind"]
        if not kind.startswith("decision."):
            continue
        payload = event["payload"]
        summary = (
            payload.get("decision")
            or payload.get("summary")
            or payload.get("message")
            or kind
        )
        decisions.append(
            {
                "decision_id": event["event_id"],
                "decision_type": _kind_suffix(kind, "decision."),
                "decision": summary,
                "recorded_at": event["ts"],
                "producer_id": event["producer_id"],
                "payload": payload,
                "schema_hash": event["schema_hash"],
                "payload_hash": event["payload_hash"],
            }
        )
    return decisions


def project_route_summary(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Return declared route events plus terminal outcome state."""

    route_events = [
        event for event in _events(snapshot) if event["schema_kind"].startswith("route.")
    ]
    run = snapshot["run"]
    return {
        "schema_version": "motus.route_summary.projection.v1",
        "run_id": run["id"],
        "status": "closed" if run["outcome"] else "open",
        "outcome": _terminal_outcome(snapshot),
        "route_events": route_events,
    }


def project_receipt(snapshot: dict[str, Any]) -> dict[str, Any] | None:
    """Derive a terminal receipt from a closed Store run."""

    run = snapshot["run"]
    if run["outcome"] is None:
        return None

    evidence = project_evidence(snapshot)
    decisions = project_decisions(snapshot)
    route_summary = project_route_summary(snapshot)
    claim = _claim_payload(snapshot)
    lease_id = claim.get("lease_id") or run["id"]
    work_id = claim.get("work_id") or run["id"]
    outcome = _terminal_outcome(snapshot)
    body = {
        "schema_version": "motus.receipt.projection.v1",
        "run_id": run["id"],
        "lease_id": lease_id,
        "work_id": work_id,
        "status": "closed",
        "outcome": outcome,
        "outcome_note": run["outcome_note"],
        "recorded_at": run["ended_at"],
        "accepted_close": _accepted_close(snapshot),
        "summary": run["outcome_note"] or f"Run closed with {outcome}.",
        "evidence": evidence,
        "evidence_ids": [item["evidence_id"] for item in evidence],
        "decisions": decisions,
        "decision_summaries": [item["decision"] for item in decisions],
        "event_count": len(snapshot.get("events", [])),
        "route_summary": route_summary,
        "next_action": "inspect receipt and route summary",
    }
    body["receipt_id"] = _sha256_text("motus.receipt.projection.v1\0" + _canonical_json(body))
    return body


def project_work_packet(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Project a Store run into the operator-facing work packet shape."""

    run = snapshot["run"]
    receipt = project_receipt(snapshot)
    claim = _claim_payload(snapshot)
    return {
        "schema_version": "motus.work_packet.projection.v1",
        "work_id": claim.get("work_id") or run["id"],
        "run_id": run["id"],
        "lease_id": claim.get("lease_id"),
        "intent": run["intent"],
        "source": run["source"],
        "producer_id": run["producer_id"],
        "cwd": run["cwd"],
        "git_sha": run["git_sha"],
        "status": "closed" if run["outcome"] else "open",
        "started_at": run["started_at"],
        "ended_at": run["ended_at"],
        "outcome": _terminal_outcome(snapshot),
        "outcome_note": run["outcome_note"],
        "events": _events(snapshot),
        "evidence": project_evidence(snapshot),
        "decisions": project_decisions(snapshot),
        "route_summary": project_route_summary(snapshot),
        "receipt_id": receipt["receipt_id"] if receipt else None,
    }


def project_handoff(
    parent_snapshot: dict[str, Any],
    child_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Project handoff events from one run, optionally linked to a child run."""

    handoff_events = [
        event for event in _events(parent_snapshot) if event["schema_kind"].startswith("handoff.")
    ]
    child_run = child_snapshot["run"] if child_snapshot else None
    return {
        "schema_version": "motus.handoff.projection.v1",
        "parent_run_id": parent_snapshot["run"]["id"],
        "child_run_id": child_run["id"] if child_run else None,
        "handoff_events": handoff_events,
    }
