# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Compatibility facade over the Store-first work bridge."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from motus.commands import work_store_bridge
from motus.commands.work_cmd import _StoreOnlyWorkCompiler


@dataclass
class OutcomeResponse:
    """Response from put_outcome()."""

    accepted: bool
    outcome_id: str | None = None
    message: str = ""


@dataclass
class EvidenceResponse:
    """Response from record_evidence()."""

    accepted: bool
    evidence_id: str | None = None
    message: str = ""


@dataclass
class DecisionResponse:
    """Response from record_decision()."""

    accepted: bool
    decision_id: str | None = None
    message: str = ""


@dataclass
class DraftDecisionResponse:
    """Response from draft-decision compatibility calls."""

    accepted: bool
    draft_id: str | None = None
    message: str = ""


class WorkCompiler(_StoreOnlyWorkCompiler):
    """Narrow 6-call compatibility facade.

    Public durable truth now lives in `motus.kernel.Store`. This class remains
    only so historical `from motus.api import WorkCompiler` imports keep a
    minimal shape while the CLI and adapters write Store run/event truth.
    """

    def claim_work(
        self,
        *,
        task_id: str,
        resources: list[Any],
        intent: str,
        agent_id: str,
        ttl_s: int = 3600,
    ) -> Any:
        result = super().claim_work(
            task_id=task_id,
            resources=resources,
            intent=intent,
            agent_id=agent_id,
            ttl_s=ttl_s,
        )
        bridge = work_store_bridge.record_claim(
            lease_id=result.lease.lease_id,
            work_id=task_id,
            intent=intent,
            agent_id=agent_id,
            resources=resources,
            ttl_s=ttl_s,
        )
        result.kernel_bridge = bridge.as_json()
        return result

    def put_outcome(
        self,
        lease_id: str,
        outcome_type: str,
        *,
        path: str | None = None,
        description: str | None = None,
    ) -> Any:
        result = super().put_outcome(
            lease_id,
            outcome_type,
            path=path,
            description=description,
        )
        if result.accepted:
            bridge = work_store_bridge.record_outcome(
                lease_id=lease_id,
                outcome_id=result.outcome_id,
                outcome_type=outcome_type,
                path_value=path,
                description=description,
                agent_id="api",
            )
            result.kernel_bridge = bridge.as_json()
        return result

    def record_evidence(
        self,
        lease_id: str,
        evidence_type: str,
        *,
        test_results: dict[str, Any] | None = None,
        diff_summary: str | None = None,
        log_excerpt: str | None = None,
        artifacts: list[Any] | None = None,
    ) -> Any:
        del artifacts
        result = super().record_evidence(
            lease_id,
            evidence_type,
            test_results=test_results,
            diff_summary=diff_summary,
            log_excerpt=log_excerpt,
        )
        if result.accepted:
            bridge = work_store_bridge.record_evidence(
                lease_id=lease_id,
                evidence_id=result.evidence_id,
                evidence_type=evidence_type,
                test_results=test_results,
                diff_summary=diff_summary,
                log_excerpt=log_excerpt,
                agent_id="api",
            )
            result.kernel_bridge = bridge.as_json()
        return result

    def record_decision(
        self,
        lease_id: str,
        decision: str,
        *,
        rationale: str | None = None,
        alternatives_considered: list[str] | None = None,
    ) -> Any:
        result = super().record_decision(
            lease_id,
            decision,
            rationale=rationale,
            alternatives_considered=alternatives_considered,
        )
        if result.accepted:
            bridge = work_store_bridge.record_decision(
                lease_id=lease_id,
                decision_id=result.decision_id,
                decision_text=decision,
                rationale=rationale,
                alternatives=alternatives_considered,
                agent_id="api",
            )
            result.kernel_bridge = bridge.as_json()
        return result

    def release_work(self, lease_id: str, outcome: str, **_kwargs: Any) -> Any:
        result = super().release_work(lease_id, outcome)
        if result.decision.decision == "GRANTED":
            bridge = work_store_bridge.record_release(
                lease_id=lease_id,
                outcome=outcome,
                decision=result.decision.decision,
                reason_code=result.decision.reason_code,
                message=result.decision.human_message,
                agent_id="api",
            )
            result.kernel_bridge = bridge.as_json()
        return result

    def emit_draft_decision(self, *_args: Any, **_kwargs: Any) -> DraftDecisionResponse:
        return DraftDecisionResponse(
            accepted=False,
            message="Draft decisions are not part of the reduced public kernel.",
        )
