# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Motus API compatibility module.

The installed `motus.api` surface is deliberately narrow. It keeps the legacy
6-call `WorkCompiler` facade for historical callers while the durable kernel
surface lives at `motus.kernel.Store`: Store runs, append-only events, event
kinds, deterministic snapshots, projections, and optional fenced locks.

Reference/shadow contracts, hosted orchestration experiments, model/runtime
resilience helpers, and governance policy surfaces are not public `motus.api`
exports. They belong above the kernel as userland or internal process code.

Compatibility usage:

    from motus.api import WorkCompiler

    wc = WorkCompiler()
    result = wc.claim_work(task_id="PA-047", ...)
    if result.decision.decision == "GRANTED":
        wc.get_context(result.lease.lease_id)
        wc.put_outcome(...)
        wc.record_evidence(...)
        wc.record_decision(...)
        wc.release_work(result.lease.lease_id, outcome="success")
"""

from __future__ import annotations

from motus.api.facade import (
    DecisionResponse,
    DraftDecisionResponse,
    EvidenceResponse,
    OutcomeResponse,
    WorkCompiler,
)

__all__ = [
    # 6-call compatibility facade.
    "WorkCompiler",
    "OutcomeResponse",
    "EvidenceResponse",
    "DecisionResponse",
    "DraftDecisionResponse",
]
