# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Entry point, argument parsing, and command dispatch for the public CLI."""

from __future__ import annotations

import logging
import sys

from rich.console import Console

from .commands.dispatch import dispatch_command
from .commands.registry import build_parser
from .help import compute_visible_help_tier, first_command_token, print_top_level_help

logger = logging.getLogger("motus.cli")
console = Console()
error_console = Console(stderr=True)


def main() -> None:
    """Run the Motus CLI."""

    argv = sys.argv[1:]
    command_token = first_command_token(argv)
    help_all = "--help-all" in argv
    if command_token is None and (help_all or "--help" in argv or "-h" in argv or not argv):
        print_top_level_help(console, 3 if help_all else compute_visible_help_tier())
        return

    bundle = build_parser()
    args = bundle.parser.parse_args()

    dispatch_command(
        args,
        bundle=bundle,
        console=console,
        error_console=error_console,
        logger=logger,
    )


if __name__ == "__main__":
    main()
