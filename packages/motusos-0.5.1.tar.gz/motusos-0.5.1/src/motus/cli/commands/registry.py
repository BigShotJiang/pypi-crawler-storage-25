# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Parser construction for the reduced public CLI command surface."""

from __future__ import annotations

import argparse
from dataclasses import dataclass

from motus import __version__

from .db import register_db_parsers
from .system import register_system_parsers
from .work import register_work_parsers
from .wrap import register_wrap_parser


@dataclass(frozen=True)
class ParserBundle:
    """Bundle of parser objects used for CLI dispatch and help output."""

    parser: argparse.ArgumentParser
    work_parser: argparse.ArgumentParser
    db_parser: argparse.ArgumentParser


def build_parser() -> ParserBundle:
    """Build the public CLI argument parser tree."""

    parser = argparse.ArgumentParser(
        description="""
Motus: local event-backed work ledger.
Run 'motus --help' for the quickstart command path.
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        "-V",
        action="version",
        version=f"motus {__version__} (Apache 2.0)",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    register_system_parsers(subparsers, include_legacy=False)
    work_parser = register_work_parsers(subparsers)
    db_parser = register_db_parsers(subparsers)
    register_wrap_parser(subparsers)

    return ParserBundle(parser=parser, work_parser=work_parser, db_parser=db_parser)
