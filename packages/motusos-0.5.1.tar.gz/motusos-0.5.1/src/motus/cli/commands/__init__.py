# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Command implementations for CLI (list, context, summary, teleport, etc).

PERFORMANCE: Rich and other heavy imports deferred to function level.
"""

import sys

from ..exit_codes import EXIT_ERROR

_console = None


def _get_console():
    """Get or create Rich console instance."""
    global _console
    if _console is None:
        try:
            from rich.console import Console

            _console = Console()
        except ImportError:
            sys.stderr.write("Missing dependency: rich\n")
            sys.stderr.write("Run: pip install rich\n")
            raise SystemExit(EXIT_ERROR)
    return _console


__all__ = [
    "context_command",
    "summary_command",
    "teleport_command",
    "list_sessions",
]


def __getattr__(name):
    """Lazy-load legacy session helpers only when they are present."""

    if name == "context_command":
        from .commands_context import context_command

        return context_command
    if name in ("list_sessions", "summary_command", "teleport_command"):
        from .commands_session import list_sessions, summary_command, teleport_command

        return {
            "list_sessions": list_sessions,
            "summary_command": summary_command,
            "teleport_command": teleport_command,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
