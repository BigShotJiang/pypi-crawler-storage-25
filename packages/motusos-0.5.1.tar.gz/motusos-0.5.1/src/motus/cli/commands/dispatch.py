# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Command dispatch for the reduced public CLI entrypoint."""

from __future__ import annotations

from pathlib import Path

from motus.cli.exit_codes import EXIT_ERROR, EXIT_USAGE
from motus.cli.help import print_parser_help
from motus.cli.public_commands import is_public_command
from motus.migration.path_migration import (
    check_legacy_path,
    find_legacy_workspace_dir,
    legacy_workspace_warning,
)

LEGACY_DB_COMMANDS = {"db"}


def dispatch_command(
    args,
    *,
    bundle,
    console,
    error_console,
    logger,
) -> None:
    """Dispatch supported public commands."""

    command = args.command
    if not is_public_command(command):
        error_console.print(
            f"Unsupported public command: {command}. Run 'motus --help' for supported commands.",
            markup=False,
        )
        raise SystemExit(EXIT_USAGE)

    legacy_warning = check_legacy_path()
    if legacy_warning:
        error_console.print(f"[yellow]{legacy_warning}[/yellow]", markup=False)
    legacy_workspace = find_legacy_workspace_dir(Path.cwd())
    if legacy_workspace:
        error_console.print(
            f"[yellow]{legacy_workspace_warning(legacy_workspace)}[/yellow]", markup=False
        )

    if command == "wrap":
        from motus.wrap import wrap_command

        raise SystemExit(wrap_command(args))

    if command in LEGACY_DB_COMMANDS:
        try:
            from motus.core.bootstrap import ensure_database

            ensure_database()
        except Exception as exc:
            logger.debug("Database bootstrap skipped: %s", exc)

        try:
            from motus.core.database import get_db_manager
            from motus.core.shutdown import ShutdownManager

            shutdown = ShutdownManager()
            shutdown.register("db_checkpoint_and_close", get_db_manager().checkpoint_and_close)
            shutdown.install_signal_handlers()
        except Exception as exc:
            logger.debug("Shutdown manager skipped: %s", exc)

    if command == "db":
        from motus.commands.db_cmd import (
            db_analyze_command,
            db_checkpoint_command,
            db_lock_info_command,
            db_migrate_path_command,
            db_recover_command,
            db_stats_command,
            db_vacuum_command,
            db_wait_command,
        )

        db_cmd = getattr(args, "db_command", None)
        if db_cmd == "vacuum":
            raise SystemExit(db_vacuum_command(args))
        if db_cmd == "analyze":
            raise SystemExit(db_analyze_command(args))
        if db_cmd == "stats":
            raise SystemExit(db_stats_command(args))
        if db_cmd == "checkpoint":
            raise SystemExit(db_checkpoint_command(args))
        if db_cmd == "lock-info":
            raise SystemExit(db_lock_info_command(args))
        if db_cmd == "wait":
            raise SystemExit(db_wait_command(args))
        if db_cmd == "recover":
            raise SystemExit(db_recover_command(args))
        if db_cmd == "migrate-path":
            raise SystemExit(db_migrate_path_command(args))

        print_parser_help(console, bundle.db_parser)
        raise SystemExit(EXIT_USAGE)

    if command == "doctor":
        from motus.commands.doctor_cmd import doctor_command

        raise SystemExit(
            doctor_command(
                json_output=getattr(args, "json", False),
                fix=getattr(args, "fix", False),
            )
        )

    if command == "mcp":
        try:
            from motus.mcp import run_server
        except ImportError:
            error_console.print(
                "MCP not installed. Run: pip install -e '.[mcp]'",
                style="red",
                markup=False,
            )
            raise SystemExit(EXIT_ERROR)
        run_server()
        return

    if command == "init":
        from motus.commands.init_cmd import init_command

        init_command(args)
        return

    if command == "install":
        from motus.commands.install_cmd import install_command

        install_command(args)
        return

    if command == "config":
        from motus.commands.config_cmd import config_command

        config_command(getattr(args, "config_args", []))
        return

    if command == "work":
        from motus.commands.work_cmd import handle_work_command

        raise SystemExit(handle_work_command(args))

    if command is None:
        console.print("[bold]Motus - Local event-backed work ledger[/bold]\n")
        console.print("Common commands:")
        console.print("  motus wrap -- <cmd>        Record a command as a Store-backed run", markup=False)
        console.print("  motus doctor               Verify Store and environment health", markup=False)
        console.print("  motus init --empty --path . Initialize a neutral Motus workspace", markup=False)
        console.print("  motus work claim <id>      Compatibility work loop over Store truth", markup=False)
        console.print("  motus --help  Full command reference\n", markup=False)
        print_parser_help(console, bundle.parser)
        return

    print_parser_help(console, bundle.parser)
    raise SystemExit(EXIT_USAGE)
