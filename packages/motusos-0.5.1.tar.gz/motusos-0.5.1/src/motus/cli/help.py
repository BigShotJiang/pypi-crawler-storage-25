# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""CLI help-tier utilities and formatting."""

from __future__ import annotations

import argparse
import os

from rich.console import Console

from motus.cli.exit_codes import EXIT_ERROR, EXIT_SUCCESS, EXIT_USAGE
from motus.cli.public_commands import PUBLIC_COMMAND_TEXTS, PUBLIC_COMMAND_TIERS

_HELP_TIER_ENV = "MC_HELP_TIER"

_COMMAND_HELP_TIERS = PUBLIC_COMMAND_TIERS
_COMMAND_HELP_TEXTS = PUBLIC_COMMAND_TEXTS


def _visible_help_tier_from_env() -> int | None:
    raw = os.environ.get(_HELP_TIER_ENV, "").strip()
    if not raw:
        return None
    try:
        value = int(raw)
    except ValueError:
        return None
    return max(0, min(3, value))


def compute_visible_help_tier() -> int:
    """Compute visible help tier.

    Precedence:
    1) `MC_HELP_TIER` env override (deterministic tests)
    2) Store-first default (tier 0)
    """
    override = _visible_help_tier_from_env()
    if override is not None:
        return override

    return 0


def first_command_token(argv: list[str]) -> str | None:
    """Return the first non-flag token from argv.

    Args:
        argv: CLI argv tokens.

    Returns:
        First command token or None when not found.
    """
    for token in argv:
        if not token.startswith("-"):
            return token
    return None


def print_top_level_help(console: Console, visible_tier: int) -> None:
    """Render the top-level CLI help output.

    Args:
        console: Rich console for output.
        visible_tier: Highest help tier to display.
    """
    console.print("[bold]Motus[/bold]\n")
    console.print("Usage: motus <command> [args]\n")
    console.print(
        "First run: use [cyan]motus wrap -- <cmd>[/cyan] to record a Store run. "
        "[cyan]motus doctor[/cyan] verifies Store health without creating legacy state.\n"
    )

    tiers = [
        (0, "Tier 0 (First Run)"),
        (1, "Tier 1 (Supporting)"),
        (2, "Tier 2 (Standard)"),
        (3, "Tier 3 (Advanced)"),
    ]
    for tier, label in tiers:
        if tier > visible_tier:
            continue
        console.print(f"{label}:")
        for name in sorted(k for k, v in _COMMAND_HELP_TIERS.items() if v == tier):
            desc = _COMMAND_HELP_TEXTS.get(name, "")
            console.print(f"  {name:<12} {desc}".rstrip(), markup=False)
        console.print("")

    if visible_tier < 3:
        console.print("Run [cyan]motus --help-all[/cyan] to show all commands.")

    console.print("\n[bold]Environment:[/bold]")
    console.print(f"  {_HELP_TIER_ENV}  Visible help tier override (0-3)", markup=False)
    console.print("  Additional command-specific variables are documented with their commands.", markup=False)
    console.print("\n[bold]Exit Codes:[/bold]")
    console.print(f"  {EXIT_SUCCESS}  Success", markup=False)
    console.print(f"  {EXIT_ERROR}  Operational error", markup=False)
    console.print(f"  {EXIT_USAGE}  Invalid arguments", markup=False)


def print_parser_help(console: Console, parser: argparse.ArgumentParser) -> None:
    """Render argparse help text.

    Args:
        console: Rich console for output.
        parser: Argument parser to format.
    """
    console.print(parser.format_help(), markup=False)


def format_cli_resource_id(command: str | None, args: argparse.Namespace) -> str:
    """Format a CLI resource identifier for telemetry.

    Args:
        command: Top-level command token.
        args: Parsed argparse namespace.

    Returns:
        Resource identifier string or empty string when unknown.
    """
    if not command:
        return ""

    if command == "policy":
        sub = getattr(args, "policy_command", None)
        return f"policy:{sub}" if sub else "policy"
    if command == "standards":
        sub = getattr(args, "standards_command", None)
        return f"standards:{sub}" if sub else "standards"
    if command == "claims":
        sub = getattr(args, "claims_command", None)
        return f"claims:{sub}" if sub else "claims"
    if command == "scratch":
        sub = getattr(args, "scratch_command", None)
        return f"scratch:{sub}" if sub else "scratch"

    return command
