# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Public CLI package."""

from __future__ import annotations

from .core import main

__all__ = ["main"]
