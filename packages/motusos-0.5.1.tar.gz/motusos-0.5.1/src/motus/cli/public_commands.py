# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Public CLI command surface for the installable wheel.

The built public wheel must advertise only the Store-first command surface and
explicit compatibility shims.
"""

from __future__ import annotations

PUBLIC_COMMAND_TIERS: dict[str, int] = {
    # First-run path.
    "doctor": 0,
    "wrap": 0,
    # Supporting operations.
    "config": 1,
    "init": 1,
    "install": 1,
    # Advanced local maintenance / adapters.
    "db": 2,
    "mcp": 2,
    "work": 2,
}

PUBLIC_COMMAND_TEXTS: dict[str, str] = {
    "config": "Manage Motus configuration",
    "db": "Database maintenance utilities",
    "doctor": "Run Store and environment health checks",
    "init": "Initialize a Motus workspace (.motus/)",
    "install": "Install Motus local defaults",
    "mcp": "Start MCP server (stdio transport)",
    "work": "Run the compatibility work loop over Store truth",
    "wrap": "Record a command as a Store-backed run",
}

PUBLIC_COMMANDS = frozenset(PUBLIC_COMMAND_TIERS)


def is_public_command(command: str | None) -> bool:
    """Return whether a parsed top-level command is supported in the public wheel."""

    return command is None or command in PUBLIC_COMMANDS


def legacy_command_modules_available() -> bool:
    """Return whether legacy command modules should be registered.

    The 0.5 source tree no longer uses a source-checkout-only command surface.
    Compatibility belongs in explicit shims, not hidden parser expansion.
    """

    return False


def is_supported_command(command: str | None) -> bool:
    """Return whether a command is public or backed by legacy source modules."""

    return is_public_command(command) or legacy_command_modules_available()
