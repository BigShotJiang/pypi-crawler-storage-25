from django.urls import path

from django_workflows.users.views import (
    AdminUserCreateView,
    ChangePasswordView,
    ForgotPasswordView,
    UserCreateView,
    UserDetailView,
    UserListView,
    VerifyCodeView,
)

urlpatterns = [
    path("user/", UserDetailView.as_view(), name="user-detail"),
    path("users/", UserListView.as_view(), name="user-list"),
    path("admin-register/", AdminUserCreateView.as_view(), name="admin-register"),
    path("forgot-password/", ForgotPasswordView.as_view(), name="forgot-password"),
    path("verify-code/", VerifyCodeView.as_view(), name="verify-code"),
    path("change-password/", ChangePasswordView.as_view(), name="change-password"),
    path("register/", UserCreateView.as_view(), name="register"),
]