"""Shared service modules used across workflow domains."""

from .email import send_email

__all__ = ["send_email"]