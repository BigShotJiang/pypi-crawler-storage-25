from setuptools import setup, find_packages

# Read version from VERSION file
with open("VERSION") as f:
    version = f.read().strip()

setup(
    name="BmorricalDjangoWorkflows",
    version=version,
    description="Reusable Django Workflows",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Bradley Morrical",
    url="https://github.com/Bmorrical/django-workflows",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Django>=4.0",
        "djangorestframework>=3.14",
        "requests>=2.31.0",
    ],
    python_requires=">=3.11",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Framework :: Django",
    ],
)
