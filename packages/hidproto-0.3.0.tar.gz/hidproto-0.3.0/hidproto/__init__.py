"""hidproto - A Python DSL for HID device protocols on Linux."""

from .checksum import sum_checksum, xor_checksum
from .command import CommandSpec, command
from .device import HIDDevice
from .discovery import DeviceInfo, find_device, list_devices
from .effect import EffectSpec, Step, apply_effect, effect, step
from .layout import Key
from .protocol import HIDProtocol
from .registry import discover, get, names, register
from .transport import HidrawTransport

try:
    from .transport_hidapi import HidapiTransport
except ImportError:
    HidapiTransport = None  # type: ignore[assignment, misc]

__all__ = [
    "CommandSpec",
    "DeviceInfo",
    "EffectSpec",
    "Step",
    "HIDDevice",
    "HIDProtocol",
    "HidrawTransport",
    "Key",
    "apply_effect",
    "command",
    "effect",
    "step",
    "find_device",
    "list_devices",
    "sum_checksum",
    "discover",
    "get",
    "names",
    "register",
    "xor_checksum",
]
