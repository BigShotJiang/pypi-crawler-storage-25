from __future__ import annotations
import time
from dataclasses import dataclass, field


def format_uptime(create_time: float) -> str:
    """Format process uptime from create_time to a human-readable string."""
    elapsed = max(0, time.time() - create_time)
    if elapsed < 60:
        return f"{int(elapsed)}s"
    if elapsed < 3600:
        return f"{int(elapsed / 60)}m {int(elapsed % 60)}s"
    hours = int(elapsed / 3600)
    mins = int((elapsed % 3600) / 60)
    if hours < 24:
        return f"{hours}h {mins}m"
    days = hours // 24
    hours = hours % 24
    return f"{days}d {hours}h"


@dataclass
class ConnectionInfo:
    protocol: str          # 'tcp' | 'udp'
    local_addr: str
    local_port: int
    remote_addr: str
    remote_port: int
    status: str            # 'LISTEN' | 'ESTABLISHED' | 'TIME_WAIT' etc.
    pid: int | None


@dataclass
class ProcessInfo:
    pid: int
    name: str
    cmdline: str
    username: str
    create_time: float
    memory_mb: float


@dataclass
class PortEntry:
    port: int
    protocol: str
    process: ProcessInfo | None
    status: str
    local_addr: str
    remote_addr: str
    remote_port: int
    connection_count: int = 0

    def to_dict(self) -> dict:
        return {
            'port': self.port,
            'protocol': self.protocol,
            'pid': self.process.pid if self.process else None,
            'process': self.process.name if self.process else None,
            'status': self.status,
            'local_addr': self.local_addr,
            'connection_count': self.connection_count,
        }


@dataclass
class ScanResult:
    entries: list[PortEntry]
    opened: list[PortEntry] = field(default_factory=list)
    closed: list[PortEntry] = field(default_factory=list)
    timestamp: float = 0.0


@dataclass
class Conflict:
    port: int
    entries: list[PortEntry] = field(default_factory=list)
