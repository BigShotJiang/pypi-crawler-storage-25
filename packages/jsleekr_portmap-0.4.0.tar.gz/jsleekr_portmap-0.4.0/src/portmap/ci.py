"""CI helper -- run portmap checks suitable for CI/CD pipelines.

Usage:
    portmap-ci          # Runs conflict check, exits non-zero if conflicts found
    python -m portmap.ci
"""
from __future__ import annotations

import json
import sys

from .scanner import ConflictDetector, PortScanner
from .system import SystemInfo


def main() -> None:
    """Run CI checks: scan ports, detect conflicts, exit with status code."""
    system = SystemInfo()
    scanner = PortScanner(system)
    detector = ConflictDetector()

    result = scanner.scan()
    conflicts = detector.detect(result.entries)

    report = {
        "total_ports": len(result.entries),
        "conflicts": len(conflicts),
        "conflict_details": [
            {
                "port": c.port,
                "pids": [e.process.pid if e.process else None for e in c.entries],
            }
            for c in conflicts
        ],
    }
    print(json.dumps(report, indent=2))

    if conflicts:
        print(f"\nFAIL: {len(conflicts)} port conflict(s) detected.", file=sys.stderr)
        sys.exit(1)
    else:
        print("\nOK: No port conflicts.")
        sys.exit(0)


if __name__ == "__main__":
    main()
