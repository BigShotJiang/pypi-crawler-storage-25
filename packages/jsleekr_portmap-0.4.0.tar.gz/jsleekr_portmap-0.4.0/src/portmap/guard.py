from __future__ import annotations

from .models import ProcessInfo

PROTECTED_PROCESSES: frozenset[str] = frozenset({
    'sshd', 'systemd', 'init', 'dockerd', 'containerd',
    'wininit', 'csrss', 'lsass', 'services', 'svchost',
    'explorer', 'winlogon',
})


class ProcessGuard:
    def __init__(self, extra_protected: set[str] | None = None):
        self._protected = PROTECTED_PROCESSES | (extra_protected or set())

    def is_protected(self, process: ProcessInfo) -> bool:
        if process.pid <= 4:
            return True
        # Strip null bytes and whitespace to prevent bypass via padding
        clean_name = process.name.strip().replace('\x00', '').lower()
        if clean_name in self._protected:
            return True
        # Also check with .exe suffix stripped (Windows processes)
        if clean_name.endswith('.exe') and clean_name[:-4] in self._protected:
            return True
        clean_user = process.username.strip().replace('\x00', '')
        if clean_user in ('root', 'SYSTEM'):
            return True
        return False

    def can_kill(self, process: ProcessInfo) -> tuple[bool, str]:
        if self.is_protected(process):
            return False, f"Protected system process: {process.name}"
        return True, "OK"
