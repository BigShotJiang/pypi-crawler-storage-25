from __future__ import annotations

import click
import datetime
import json
import time

from .config import load_config
from .scanner import ConflictDetector, PortScanner, ScanHistory
from .system import SystemInfo


@click.group(invoke_without_command=True)
@click.option('--interval', default=None, type=float, help='Refresh interval in seconds')
@click.option('--port', default=None, help='Port range filter (e.g., 3000-9000)')
@click.option('--process', default=None, help='Process name filter')
@click.option('--protocol', default=None, type=click.Choice(['tcp', 'udp']))
@click.option('--no-refresh', is_flag=True, help='Single scan, no TUI')
@click.pass_context
def cli(ctx, interval, port, process, protocol, no_refresh):
    """portmap - Terminal port monitor with TUI dashboard."""
    if ctx.invoked_subcommand is not None:
        return

    if no_refresh:
        # Snapshot mode
        config = load_config()
        system = SystemInfo()
        scanner = PortScanner(system)
        result = scanner.scan()
        entries = result.entries
        if protocol:
            entries = [e for e in entries if e.protocol == protocol]
        if process:
            q = process.lower()
            entries = [e for e in entries if e.process and q in e.process.name.lower()]
        if port:
            try:
                if '-' in port:
                    lo, hi = port.split('-', 1)
                    lo, hi = int(lo), int(hi)
                    entries = [e for e in entries if lo <= e.port <= hi]
                else:
                    p = int(port)
                    entries = [e for e in entries if e.port == p]
            except ValueError:
                pass
        for entry in entries:
            pid = str(entry.process.pid) if entry.process else '\u2014'
            name = entry.process.name if entry.process else '\u2014'
            print(f"{entry.port:>6}  {entry.protocol:>4}  {entry.status:<12}  {pid:>6}  {name}")
    else:
        from .app import PortmapApp
        config = load_config()
        if interval:
            config.refresh_interval = interval
        app = PortmapApp(config=config)
        app.run()


@cli.command()
@click.option('--json', 'as_json', is_flag=True, help='JSON output')
@click.option('--csv', 'as_csv', is_flag=True, help='CSV output')
@click.option('--sort', type=click.Choice(['port', 'pid', 'process', 'status']),
              default='port', help='Sort by field')
def list(as_json, as_csv, sort):
    """List all open ports (non-TUI)."""
    system = SystemInfo()
    scanner = PortScanner(system)
    detector = ConflictDetector()
    result = scanner.scan()
    conflicts = detector.detect(result.entries)
    conflict_ports = {c.port for c in conflicts}

    # Sort entries
    sort_keys = {
        'port': lambda e: e.port,
        'pid': lambda e: (e.process.pid if e.process else 0),
        'process': lambda e: (e.process.name if e.process else ''),
        'status': lambda e: e.status,
    }
    entries = sorted(result.entries, key=sort_keys[sort])

    if as_json:
        data = {
            'timestamp': result.timestamp,
            'timestamp_iso': datetime.datetime.fromtimestamp(
                result.timestamp, tz=datetime.timezone.utc
            ).isoformat(),
            'total': len(entries),
            'conflicts': [
                {'port': c.port, 'pids': [
                    e.process.pid if e.process else None for e in c.entries
                ]} for c in conflicts
            ],
            'entries': [e.to_dict() for e in entries],
        }
        print(json.dumps(data, indent=2))
    elif as_csv:
        import csv
        import sys
        writer = csv.writer(sys.stdout)
        writer.writerow(['port', 'protocol', 'status', 'pid', 'process', 'local_addr',
                         'connection_count', 'conflict'])
        for e in entries:
            writer.writerow([
                e.port, e.protocol, e.status,
                e.process.pid if e.process else '',
                e.process.name if e.process else '',
                e.local_addr, e.connection_count,
                'yes' if e.port in conflict_ports else 'no',
            ])
    else:
        print(f"{'PORT':>6}  {'PROTO':>5}  {'STATUS':<12}  {'PID':>6}  {'PROCESS'}")
        print("-" * 55)
        for e in entries:
            pid = str(e.process.pid) if e.process else '\u2014'
            name = e.process.name if e.process else '\u2014'
            print(f"{e.port:>6}  {e.protocol:>5}  {e.status:<12}  {pid:>6}  {name}")


@cli.command()
def conflicts():
    """Show port conflicts only."""
    system = SystemInfo()
    scanner = PortScanner(system)
    detector = ConflictDetector()
    result = scanner.scan()
    conflicts = detector.detect(result.entries)
    if not conflicts:
        print("No port conflicts detected.")
        return
    for c in conflicts:
        print(f"\n\u26a0 Port {c.port} \u2014 {len(c.entries)} processes:")
        for e in c.entries:
            name = e.process.name if e.process else '\u2014'
            pid = str(e.process.pid) if e.process else '\u2014'
            print(f"  PID {pid}: {name}")


@cli.command()
@click.option('--interval', default=3.0, type=float, help='Scan interval in seconds')
def watch(interval):
    """Watch mode -- print port changes as they happen."""
    system = SystemInfo()
    scanner = PortScanner(system)
    config = load_config()
    history = ScanHistory(max_size=config.max_history)

    click.echo(f"Watching ports (interval={interval}s). Press Ctrl+C to stop.")
    try:
        while True:
            result = scanner.scan()
            history.add(result)
            now = datetime.datetime.now().strftime("%H:%M:%S")
            for entry in result.opened:
                name = entry.process.name if entry.process else "unknown"
                pid = entry.process.pid if entry.process else "?"
                click.echo(f"[{now}] Port {entry.port} OPENED ({name}, PID {pid})")
            for entry in result.closed:
                name = entry.process.name if entry.process else "unknown"
                pid = entry.process.pid if entry.process else "?"
                click.echo(f"[{now}] Port {entry.port} CLOSED ({name}, PID {pid})")
            time.sleep(interval)
    except KeyboardInterrupt:
        click.echo(f"\nStopped. {len(history)} scans recorded.")
