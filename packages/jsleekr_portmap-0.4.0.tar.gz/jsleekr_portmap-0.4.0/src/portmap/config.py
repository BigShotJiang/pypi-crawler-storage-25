from __future__ import annotations
from dataclasses import dataclass, field
import logging
import os
import yaml

logger = logging.getLogger(__name__)

@dataclass
class PortmapConfig:
    refresh_interval: float = 2.0
    protected_processes: list[str] = field(default_factory=list)
    show_established: bool = True
    max_history: int = 100
    theme: str = 'dark'

DEFAULT_CONFIG_DIR = os.path.expanduser('~/.portmap')
DEFAULT_CONFIG_PATH = os.path.join(DEFAULT_CONFIG_DIR, 'config.yaml')

def load_config(path: str | None = None) -> PortmapConfig:
    config_path = path or DEFAULT_CONFIG_PATH
    if not os.path.exists(config_path):
        return PortmapConfig()
    try:
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f) or {}
        return PortmapConfig(**{k: v for k, v in data.items() if k in PortmapConfig.__dataclass_fields__})
    except (yaml.YAMLError, TypeError, OSError, UnicodeDecodeError, ValueError) as exc:
        logger.warning("Failed to load config from %s: %s", config_path, exc)
        return PortmapConfig()

def save_default_config(path: str | None = None) -> str:
    config_path = path or DEFAULT_CONFIG_PATH
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    config = PortmapConfig()
    data = {
        'refresh_interval': config.refresh_interval,
        'protected_processes': config.protected_processes,
        'show_established': config.show_established,
        'max_history': config.max_history,
        'theme': config.theme,
    }
    with open(config_path, 'w') as f:
        yaml.dump(data, f, default_flow_style=False)
    return config_path
