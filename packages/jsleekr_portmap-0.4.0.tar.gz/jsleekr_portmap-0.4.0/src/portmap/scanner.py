from __future__ import annotations

import logging
import time
from collections import deque

from .models import ConnectionInfo, Conflict, PortEntry, ProcessInfo, ScanResult

logger = logging.getLogger(__name__)


class PortScanner:
    def __init__(self, system, interval: float = 2.0):
        self._system = system
        self._interval = interval
        self._previous: dict[tuple[int, str, int | None], PortEntry] = {}
        self._current: dict[tuple[int, str, int | None], PortEntry] = {}

    def scan(self) -> ScanResult:
        connections = self._system.get_connections()

        # Group by (port, protocol, pid) for LISTEN, count ESTABLISHED
        new_current: dict[tuple[int, str, int | None], PortEntry] = {}
        established_counts: dict[int, int] = {}

        for conn in connections:
            if conn.status == 'ESTABLISHED':
                established_counts[conn.local_port] = established_counts.get(conn.local_port, 0) + 1
                continue

            key = (conn.local_port, conn.protocol, conn.pid)
            if key not in new_current:
                process = None
                if conn.pid:
                    try:
                        process = self._system.get_process(conn.pid)
                    except Exception as exc:
                        logger.debug("Failed to get process info for PID %s: %s", conn.pid, exc)
                        process = None
                new_current[key] = PortEntry(
                    port=conn.local_port, protocol=conn.protocol,
                    process=process, status=conn.status,
                    local_addr=conn.local_addr,
                    remote_addr=conn.remote_addr, remote_port=conn.remote_port,
                    connection_count=0,
                )

        # Attach established counts
        for key, entry in new_current.items():
            entry.connection_count = established_counts.get(entry.port, 0)

        # Detect changes (compare against last scan's current)
        prev_keys = set(self._current.keys())
        curr_keys = set(new_current.keys())
        opened = [new_current[k] for k in curr_keys - prev_keys]
        closed = [self._current[k] for k in prev_keys - curr_keys]

        # Memory safe swap
        self._previous = self._current
        self._current = new_current

        entries = sorted(new_current.values(), key=lambda e: e.port)
        return ScanResult(entries=entries, opened=opened, closed=closed, timestamp=time.time())


class ScanHistory:
    """Keeps the last N scan results for tracking port changes over time."""

    def __init__(self, max_size: int = 100):
        self._history: deque[ScanResult] = deque(maxlen=max_size)
        self._max_size = max_size

    def add(self, result: ScanResult) -> None:
        self._history.append(result)

    def get_recent_changes(self, n: int = 10) -> list[dict]:
        changes = []
        recent = list(self._history)[-n:]
        for result in reversed(recent):
            if result.opened or result.closed:
                changes.append({
                    'timestamp': result.timestamp,
                    'opened': [e.port for e in result.opened],
                    'closed': [e.port for e in result.closed],
                })
        return changes

    def clear(self) -> None:
        self._history.clear()

    def __len__(self) -> int:
        return len(self._history)


class ConflictDetector:
    def detect(self, entries: list[PortEntry]) -> list[Conflict]:
        by_port_proto: dict[tuple[int, str], list[PortEntry]] = {}
        for e in entries:
            if e.status == 'LISTEN':
                by_port_proto.setdefault((e.port, e.protocol), []).append(e)

        conflicts = []
        for (port, _proto), port_entries in by_port_proto.items():
            pids = set(e.process.pid if e.process else None for e in port_entries)
            if len(pids) > 1:
                conflicts.append(Conflict(port=port, entries=port_entries))
        return conflicts
