from __future__ import annotations

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Footer, Header, Input, Static

from .config import PortmapConfig
from .guard import ProcessGuard
from .models import PortEntry
from .scanner import ConflictDetector, PortScanner
from .system import SystemInfo
from .widgets.detail_panel import DetailPanel
from .widgets.filter_bar import FilterBar
from .widgets.port_table import PortTable
from .widgets.status_bar import StatusBar


class KillConfirmScreen(ModalScreen[bool]):
    """Kill confirmation dialog."""

    def __init__(self, process_info):
        super().__init__()
        self.process_info = process_info

    def compose(self) -> ComposeResult:
        yield Vertical(
            Static(
                f"Kill process?\n\n"
                f"PID: {self.process_info.pid}\n"
                f"Name: {self.process_info.name}\n"
                f"CMD: {self.process_info.cmdline}"
            ),
            Horizontal(
                Button("Confirm", variant="error", id="confirm-kill"),
                Button("Cancel", variant="default", id="cancel-kill"),
            ),
            id="kill-dialog",
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "confirm-kill":
            self.dismiss(True)
        else:
            self.dismiss(False)


class PortmapApp(App):
    """Portmap TUI application."""

    CSS = """
    FilterBar {
        height: 3;
        padding: 0 1;
    }
    FilterBar Input {
        width: 1fr;
    }
    FilterBar Static {
        width: auto;
        padding: 0 2;
        content-align: center middle;
    }
    DetailPanel {
        height: auto;
        min-height: 5;
        padding: 1;
        border-top: solid green;
    }
    StatusBar {
        height: 1;
        padding: 0 1;
    }
    PortTable {
        height: 1fr;
    }
    #kill-dialog {
        width: 50;
        height: auto;
        border: solid red;
        padding: 1;
        background: $surface;
    }
    KillConfirmScreen {
        align: center middle;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("slash", "focus_filter", "Filter"),
        ("k", "kill_process", "Kill"),
        ("r", "refresh_now", "Refresh"),
        ("p", "toggle_protocol", "Protocol"),
        ("s", "toggle_status", "Status"),
    ]

    TITLE = "portmap"

    def __init__(
        self,
        config: PortmapConfig | None = None,
        system: SystemInfo | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._config = config or PortmapConfig()
        self._system = system or SystemInfo()
        self._scanner = PortScanner(self._system, self._config.refresh_interval)
        self._conflict_detector = ConflictDetector()
        self._guard = ProcessGuard(set(self._config.protected_processes))
        self._entries: list[PortEntry] = []
        self._conflicts = []
        self._protocol_filter: str | None = None  # None = ALL
        self._status_filter: str | None = None
        self._text_filter: str = ""
        self._selected_entry: PortEntry | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield FilterBar()
        yield PortTable()
        yield DetailPanel()
        yield StatusBar()
        yield Footer()

    def on_mount(self) -> None:
        self._do_refresh()
        self.set_interval(self._config.refresh_interval, self._do_refresh)

    def _do_refresh(self) -> None:
        result = self._scanner.scan()
        self._entries = result.entries
        self._conflicts = self._conflict_detector.detect(result.entries)
        self._update_table()
        self._update_status()

    def _update_table(self) -> None:
        filtered = self._apply_filters(self._entries)
        table = self.query_one(PortTable)
        table.update_entries(filtered, self._conflicts, self._guard)

    def _update_status(self) -> None:
        protected = sum(
            1
            for e in self._entries
            if e.process and self._guard.is_protected(e.process)
        )
        self.query_one(StatusBar).update_stats(
            len(self._entries),
            len(self._conflicts),
            protected,
            self._config.refresh_interval,
        )

    def _apply_filters(self, entries: list[PortEntry]) -> list[PortEntry]:
        result = entries
        if self._protocol_filter:
            result = [e for e in result if e.protocol == self._protocol_filter]
        if self._status_filter:
            result = [e for e in result if e.status == self._status_filter]
        if self._text_filter:
            q = self._text_filter.lower()
            result = [
                e
                for e in result
                if q in str(e.port)
                or (e.process and q in e.process.name.lower())
            ]
        return result

    def on_data_table_row_selected(self, event) -> None:
        """Update detail panel when a row is selected."""
        row_key = event.row_key.value if event.row_key else None
        if not row_key:
            return
        entry = self._find_entry_by_key(row_key)
        self._selected_entry = entry
        if entry and entry.process:
            can_kill, reason = self._guard.can_kill(entry.process)
            self.query_one(DetailPanel).update_detail(entry, can_kill, reason)
        else:
            self.query_one(DetailPanel).update_detail(entry, False, "No process info")

    def _find_entry_by_key(self, key: str) -> PortEntry | None:
        for e in self._entries:
            pid = str(e.process.pid) if e.process else "\u2014"
            if f"{e.port}-{e.protocol}-{pid}" == key:
                return e
        return None

    def _get_selected_entry(self) -> PortEntry | None:
        """Get the entry for the currently highlighted table row."""
        table = self.query_one(PortTable)
        if table.row_count == 0:
            return None
        try:
            row_key = table.get_row_at(table.cursor_row)
            # We need the key, not the row data
            # Get the key from the coordinate
            cursor_row = table.cursor_row
            keys = list(table.rows.keys())
            if 0 <= cursor_row < len(keys):
                key = keys[cursor_row].value
                return self._find_entry_by_key(key)
        except Exception:
            pass
        return self._selected_entry

    def action_focus_filter(self) -> None:
        self.query_one("#filter-input", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "filter-input":
            self._text_filter = event.value
            self._update_table()

    def action_toggle_protocol(self) -> None:
        cycle = [None, "tcp", "udp"]
        idx = cycle.index(self._protocol_filter) if self._protocol_filter in cycle else 0
        self._protocol_filter = cycle[(idx + 1) % len(cycle)]
        label = self._protocol_filter.upper() if self._protocol_filter else "ALL"
        self.query_one("#proto-filter", Static).update(f"Proto: {label}")
        self._update_table()

    def action_toggle_status(self) -> None:
        cycle = [None, "LISTEN", "ESTABLISHED"]
        idx = cycle.index(self._status_filter) if self._status_filter in cycle else 0
        self._status_filter = cycle[(idx + 1) % len(cycle)]
        label = self._status_filter or "ALL"
        self.query_one("#status-filter", Static).update(f"Status: {label}")
        self._update_table()

    def action_refresh_now(self) -> None:
        self._do_refresh()

    async def action_kill_process(self) -> None:
        entry = self._get_selected_entry()
        if not entry or not entry.process:
            self.notify("No process selected", severity="warning")
            return

        can_kill, reason = self._guard.can_kill(entry.process)
        if not can_kill:
            self.notify(f"\U0001f512 {reason}", severity="error")
            return

        def on_confirm(confirmed: bool) -> None:
            if confirmed and entry.process:
                success = self._system.kill_process(entry.process.pid)
                if success:
                    self.notify(
                        f"Killed {entry.process.name} (PID {entry.process.pid})",
                        severity="information",
                    )
                    self._do_refresh()
                else:
                    self.notify("Failed to kill process", severity="error")

        await self.push_screen(KillConfirmScreen(entry.process), on_confirm)
