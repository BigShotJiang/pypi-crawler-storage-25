from __future__ import annotations

from textual.widgets import Static

from ..models import PortEntry, format_uptime


class DetailPanel(Static):
    """Shows details of the selected port."""

    def on_mount(self) -> None:
        self.update("Select a port to see details")

    def update_detail(
        self,
        entry: PortEntry | None,
        can_kill: bool,
        kill_reason: str,
    ) -> None:
        if not entry:
            self.update("Select a port to see details")
            return

        lines: list[str] = []
        lines.append(f"Port: {entry.port} ({entry.protocol.upper()})")
        if entry.process:
            p = entry.process
            lines.append(f"Process: {p.name} (PID {p.pid})")
            uptime = format_uptime(p.create_time)
            lines.append(f"User: {p.username} | Memory: {p.memory_mb:.1f} MB | Uptime: {uptime}")
            lines.append(f"CMD: {p.cmdline}")
            lines.append(f"Connections: {entry.connection_count} ESTABLISHED")
            if not can_kill:
                lines.append(f"\U0001f512 {kill_reason}")
            else:
                lines.append("[K] Press 'k' to kill this process")
        else:
            lines.append("Process: \u2014 (no permission or process ended)")

        self.update("\n".join(lines))
