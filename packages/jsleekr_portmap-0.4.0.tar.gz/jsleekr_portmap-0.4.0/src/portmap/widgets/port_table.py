from __future__ import annotations

from textual.widgets import DataTable

from ..guard import ProcessGuard
from ..models import Conflict, PortEntry


class PortTable(DataTable):
    """Port listing table with color-coded rows."""

    COLUMNS = ["PORT", "PROTO", "STATUS", "PID", "PROCESS", "CMD"]

    def on_mount(self) -> None:
        for col in self.COLUMNS:
            self.add_column(col, key=col.lower())
        self.cursor_type = "row"

    def update_entries(
        self,
        entries: list[PortEntry],
        conflicts: list[Conflict],
        guard: ProcessGuard,
    ) -> None:
        """Clear and re-populate table from scan results."""
        self.clear()
        conflict_ports = {c.port for c in conflicts}

        for entry in entries:
            is_protected = entry.process is not None and guard.is_protected(
                entry.process
            )
            is_conflict = entry.port in conflict_ports

            port_label = str(entry.port)
            if is_protected:
                port_label = f"\U0001f512{entry.port}"
            elif is_conflict:
                port_label = f"\u26a0{entry.port}"

            pid = str(entry.process.pid) if entry.process else "\u2014"
            name = entry.process.name if entry.process else "\u2014"
            cmd = (
                entry.process.cmdline[:30] if entry.process else "\u2014"
            )

            self.add_row(
                port_label,
                entry.protocol.upper(),
                entry.status,
                pid,
                name,
                cmd,
                key=f"{entry.port}-{entry.protocol}-{pid}",
            )
