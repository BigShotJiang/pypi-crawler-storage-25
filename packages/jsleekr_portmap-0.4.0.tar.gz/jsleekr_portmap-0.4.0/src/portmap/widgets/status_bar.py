from textual.widgets import Static


class StatusBar(Static):
    """Bottom status bar showing scan statistics."""

    def update_stats(
        self,
        total_ports: int,
        conflicts_count: int,
        protected_count: int,
        interval: float,
    ) -> None:
        self.update(
            f"\u25cf {total_ports} ports | \u26a0 {conflicts_count} conflicts | "
            f"\U0001f512 {protected_count} protected | {interval}s refresh"
        )
