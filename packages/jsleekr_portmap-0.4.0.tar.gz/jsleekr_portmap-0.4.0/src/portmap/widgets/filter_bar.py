from textual.containers import Horizontal
from textual.widgets import Input, Static


class FilterBar(Horizontal):
    """Filter bar with text input and protocol/status toggles."""

    def compose(self):
        yield Input(placeholder="Filter by port or process...", id="filter-input")
        yield Static("Proto: ALL", id="proto-filter")
        yield Static("Status: ALL", id="status-filter")
