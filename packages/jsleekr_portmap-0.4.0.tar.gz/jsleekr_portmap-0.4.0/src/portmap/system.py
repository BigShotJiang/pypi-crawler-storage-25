from __future__ import annotations

import socket

import psutil

from .models import ConnectionInfo, ProcessInfo


class SystemInfo:
    def get_connections(self) -> list[ConnectionInfo]:
        conns = psutil.net_connections('all')
        result = []
        for c in conns:
            if not c.laddr:
                continue
            result.append(ConnectionInfo(
                protocol='tcp' if c.type == socket.SOCK_STREAM else 'udp',
                local_addr=c.laddr.ip if c.laddr else '',
                local_port=c.laddr.port if c.laddr else 0,
                remote_addr=c.raddr.ip if c.raddr else '',
                remote_port=c.raddr.port if c.raddr else 0,
                status=c.status if c.status else 'NONE',
                pid=c.pid,
            ))
        return result

    def get_process(self, pid: int) -> ProcessInfo | None:
        try:
            p = psutil.Process(pid)
            return ProcessInfo(
                pid=p.pid, name=p.name(),
                cmdline=' '.join(p.cmdline()) or p.name(),
                username=p.username(), create_time=p.create_time(),
                memory_mb=p.memory_info().rss / (1024 * 1024),
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return None

    def kill_process(self, pid: int) -> bool:
        try:
            p = psutil.Process(pid)
            p.terminate()
            try:
                p.wait(timeout=3)
            except psutil.TimeoutExpired:
                p.kill()
            return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False
