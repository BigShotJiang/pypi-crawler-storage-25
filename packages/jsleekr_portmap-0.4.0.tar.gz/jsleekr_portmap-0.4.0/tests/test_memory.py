import tracemalloc
from portmap.scanner import PortScanner
from portmap.models import ConnectionInfo, ProcessInfo

class MockSystemInfo:
    def __init__(self):
        self._connections = [
            ConnectionInfo('tcp', '0.0.0.0', port, '', 0, 'LISTEN', port)
            for port in range(3000, 3020)
        ]
        self._processes = {
            port: ProcessInfo(port, f'proc-{port}', f'cmd-{port}', 'user', 0.0, 10.0)
            for port in range(3000, 3020)
        }
    def get_connections(self):
        return self._connections
    def get_process(self, pid):
        return self._processes.get(pid)
    def kill_process(self, pid):
        return pid in self._processes

def test_no_memory_leak_after_2000_scans():
    system = MockSystemInfo()
    scanner = PortScanner(system)

    tracemalloc.start()
    # Warm up
    for _ in range(10):
        scanner.scan()

    snapshot1 = tracemalloc.take_snapshot()

    for _ in range(2000):
        scanner.scan()

    snapshot2 = tracemalloc.take_snapshot()
    tracemalloc.stop()

    stats = snapshot2.compare_to(snapshot1, 'lineno')
    total_growth = sum(s.size_diff for s in stats if s.size_diff > 0)
    assert total_growth < 500_000, f"Memory grew by {total_growth} bytes after 2000 scans"

def test_no_memory_leak_100_ports():
    """Memory test with 100 ports -- broader scan surface."""
    class BigMockSystem:
        def __init__(self):
            self._connections = [
                ConnectionInfo('tcp', '0.0.0.0', port, '', 0, 'LISTEN', port)
                for port in range(3000, 3100)
            ]
            self._processes = {
                port: ProcessInfo(port, f'proc-{port}', f'cmd-{port}', 'user', 0.0, 10.0)
                for port in range(3000, 3100)
            }
        def get_connections(self):
            return self._connections
        def get_process(self, pid):
            return self._processes.get(pid)

    system = BigMockSystem()
    scanner = PortScanner(system)

    tracemalloc.start()
    for _ in range(10):
        scanner.scan()

    snapshot1 = tracemalloc.take_snapshot()

    for _ in range(500):
        scanner.scan()

    snapshot2 = tracemalloc.take_snapshot()
    tracemalloc.stop()

    stats = snapshot2.compare_to(snapshot1, 'lineno')
    total_growth = sum(s.size_diff for s in stats if s.size_diff > 0)
    assert total_growth < 1_000_000, f"Memory grew by {total_growth} bytes with 100 ports"


def test_scan_throughput():
    """Scanning 20 ports should complete 1000 iterations in under 2 seconds."""
    import time
    system = MockSystemInfo()
    scanner = PortScanner(system)

    start = time.perf_counter()
    for _ in range(1000):
        scanner.scan()
    elapsed = time.perf_counter() - start

    assert elapsed < 2.0, f"1000 scans took {elapsed:.2f}s (expected < 2s)"


def test_scan_clears_previous_references():
    system = MockSystemInfo()
    scanner = PortScanner(system)
    scanner.scan()
    scanner.scan()
    # _previous should only have current scan's data
    assert len(scanner._previous) <= 20  # 20 ports max


def test_stress_5000_scans_memory():
    """Stress test: 5000 scans with 50 ports should not leak memory."""

    class StressMockSystem:
        def __init__(self):
            self._connections = [
                ConnectionInfo('tcp', '0.0.0.0', port, '', 0, 'LISTEN', port)
                for port in range(4000, 4050)
            ]
            self._processes = {
                port: ProcessInfo(port, f'proc-{port}', f'cmd-{port}', 'user', 0.0, 10.0)
                for port in range(4000, 4050)
            }

        def get_connections(self):
            return self._connections

        def get_process(self, pid):
            return self._processes.get(pid)

    system = StressMockSystem()
    scanner = PortScanner(system)

    tracemalloc.start()
    # Warm up
    for _ in range(20):
        scanner.scan()

    snapshot1 = tracemalloc.take_snapshot()

    for _ in range(5000):
        scanner.scan()

    snapshot2 = tracemalloc.take_snapshot()
    tracemalloc.stop()

    stats = snapshot2.compare_to(snapshot1, 'lineno')
    total_growth = sum(s.size_diff for s in stats if s.size_diff > 0)
    assert total_growth < 1_000_000, f"Memory grew by {total_growth} bytes after 5000 scans"


def test_stress_rapid_config_reload():
    """Stress test: rapidly loading config 1000 times should not crash or leak."""
    import tempfile
    import os
    import yaml
    from portmap.config import load_config, save_default_config

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'config.yaml')
        save_default_config(path)

        tracemalloc.start()
        for _ in range(10):
            load_config(path)

        snapshot1 = tracemalloc.take_snapshot()

        for i in range(1000):
            config = load_config(path)
            assert config.refresh_interval == 2.0
            # Simulate config file change every 100 iterations
            if i % 100 == 0:
                with open(path, 'w') as f:
                    yaml.dump({'refresh_interval': 2.0, 'theme': 'dark'}, f)

        snapshot2 = tracemalloc.take_snapshot()
        tracemalloc.stop()

        stats = snapshot2.compare_to(snapshot1, 'lineno')
        total_growth = sum(s.size_diff for s in stats if s.size_diff > 0)
        assert total_growth < 2_000_000, f"Memory grew by {total_growth} bytes after 1000 config reloads"


def test_stress_scan_history_churn():
    """Stress test: ScanHistory under heavy churn stays bounded."""
    from portmap.scanner import ScanHistory
    from portmap.models import PortEntry, ScanResult

    history = ScanHistory(max_size=200)
    for i in range(5000):
        entry = PortEntry(
            port=8000 + (i % 100), protocol="tcp", process=None,
            status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0,
        )
        result = ScanResult(
            entries=[entry],
            opened=[entry] if i % 3 == 0 else [],
            closed=[entry] if i % 7 == 0 else [],
            timestamp=float(i),
        )
        history.add(result)

    assert len(history) == 200
    changes = history.get_recent_changes(n=50)
    assert isinstance(changes, list)
    assert len(changes) <= 50
