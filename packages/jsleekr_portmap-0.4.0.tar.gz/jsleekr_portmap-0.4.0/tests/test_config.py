import logging
import os, tempfile, pytest, yaml
from portmap.config import PortmapConfig, load_config, save_default_config

def test_defaults():
    config = PortmapConfig()
    assert config.refresh_interval == 2.0
    assert config.theme == 'dark'
    assert config.protected_processes == []

def test_load_missing_file():
    config = load_config('/nonexistent/path.yaml')
    assert config.refresh_interval == 2.0  # defaults

def test_load_valid_yaml():
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump({'refresh_interval': 5.0, 'theme': 'light'}, f)
        path = f.name
    try:
        config = load_config(path)
        assert config.refresh_interval == 5.0
        assert config.theme == 'light'
    finally:
        os.unlink(path)

def test_load_invalid_yaml():
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write('{{{invalid yaml')
        path = f.name
    try:
        config = load_config(path)
        assert config.refresh_interval == 2.0  # defaults on error
    finally:
        os.unlink(path)

def test_save_default_creates_file():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'config.yaml')
        result = save_default_config(path)
        assert os.path.exists(result)
        with open(result) as f:
            data = yaml.safe_load(f)
        assert data['refresh_interval'] == 2.0


def test_load_binary_garbage_config():
    """Binary garbage in config file should fall back to defaults."""
    with tempfile.NamedTemporaryFile(mode='wb', suffix='.yaml', delete=False) as f:
        f.write(b'\x00\x01\x89PNG\r\n\x1a\n\xff\xfe\xfd')
        path = f.name
    try:
        config = load_config(path)
        assert config.refresh_interval == 2.0
        assert config.theme == 'dark'
    finally:
        os.unlink(path)


def test_load_empty_config_file():
    """Empty config file should return defaults."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write('')
        path = f.name
    try:
        config = load_config(path)
        assert config.refresh_interval == 2.0
    finally:
        os.unlink(path)


def test_load_yaml_with_injection_attempt():
    """YAML with potentially dangerous values should be handled safely."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        # yaml.safe_load does not execute Python objects, so this is safe
        f.write("refresh_interval: !!python/object/apply:os.system ['echo pwned']\n")
        path = f.name
    try:
        config = load_config(path)
        # Should fall back to defaults since safe_load rejects this
        assert config.refresh_interval == 2.0
    finally:
        os.unlink(path)


def test_load_yaml_with_extreme_values():
    """Config with extreme numeric values should load without crashing."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump({'refresh_interval': -999.0, 'max_history': 0, 'theme': ''}, f)
        path = f.name
    try:
        config = load_config(path)
        assert config.refresh_interval == -999.0  # We load it; validation is caller's job
        assert config.max_history == 0
        assert config.theme == ''
    finally:
        os.unlink(path)


def test_load_yaml_with_unknown_fields():
    """Unknown fields in YAML should be silently ignored."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump({'refresh_interval': 3.0, 'unknown_field': 'ignored', 'theme': 'light'}, f)
        path = f.name
    try:
        config = load_config(path)
        assert config.refresh_interval == 3.0
        assert config.theme == 'light'
    finally:
        os.unlink(path)


def test_load_invalid_yaml_logs_warning(caplog):
    """Invalid YAML should log a warning, not fail silently."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write('{{{invalid yaml')
        path = f.name
    try:
        with caplog.at_level(logging.WARNING, logger="portmap.config"):
            config = load_config(path)
        assert config.refresh_interval == 2.0  # defaults
        assert any("Failed to load config" in msg for msg in caplog.messages)
    finally:
        os.unlink(path)
