from portmap.scanner import PortScanner, ConflictDetector, ScanHistory
from portmap.guard import ProcessGuard
from portmap.config import PortmapConfig, load_config, save_default_config
from portmap.models import ConnectionInfo, ProcessInfo, ScanResult, PortEntry
from conftest import MockSystemInfo, make_process, make_conn, make_entry
import tempfile
import os
import json


def test_full_scan_cycle(sample_connections_and_processes):
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    result = scanner.scan()
    assert len(result.entries) >= 3
    # Second scan same data
    result2 = scanner.scan()
    assert len(result2.opened) == 0
    assert len(result2.closed) == 0


def test_conflict_detection_integration(sample_connections_and_processes):
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    detector = ConflictDetector()
    result = scanner.scan()
    conflicts = detector.detect(result.entries)
    assert len(conflicts) == 1
    assert conflicts[0].port == 3000


def test_guard_with_scan(sample_connections_and_processes):
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    guard = ProcessGuard()
    result = scanner.scan()
    protected = [e for e in result.entries if e.process and guard.is_protected(e.process)]
    assert any(e.process.name == 'sshd' for e in protected)


def test_config_integration():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'config.yaml')
        save_default_config(path)
        config = load_config(path)
        guard = ProcessGuard(set(config.protected_processes))
        assert guard is not None


def test_list_json_format(sample_connections_and_processes):
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    result = scanner.scan()
    data = [e.to_dict() for e in result.entries]
    json_str = json.dumps(data)
    parsed = json.loads(json_str)
    assert isinstance(parsed, list)
    assert all('port' in item for item in parsed)


def test_json_output_includes_metadata(sample_connections_and_processes):
    """JSON output should include timestamp, total, conflicts, and entries."""
    import datetime
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    detector = ConflictDetector()
    result = scanner.scan()
    conflicts = detector.detect(result.entries)

    data = {
        'timestamp': result.timestamp,
        'timestamp_iso': datetime.datetime.fromtimestamp(
            result.timestamp, tz=datetime.timezone.utc
        ).isoformat(),
        'total': len(result.entries),
        'conflicts': [
            {'port': c.port, 'pids': [
                e.process.pid if e.process else None for e in c.entries
            ]} for c in conflicts
        ],
        'entries': [e.to_dict() for e in result.entries],
    }
    json_str = json.dumps(data)
    parsed = json.loads(json_str)
    assert 'timestamp' in parsed
    assert 'timestamp_iso' in parsed
    assert 'total' in parsed
    assert isinstance(parsed['total'], int)
    assert 'conflicts' in parsed
    assert len(parsed['conflicts']) == 1
    assert parsed['conflicts'][0]['port'] == 3000
    assert 'entries' in parsed
    assert isinstance(parsed['entries'], list)


def test_entries_sort_by_pid(sample_connections_and_processes):
    """Entries can be sorted by PID."""
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    result = scanner.scan()

    sort_key = lambda e: (e.process.pid if e.process else 0)
    sorted_entries = sorted(result.entries, key=sort_key)
    pids = [e.process.pid for e in sorted_entries if e.process]
    assert pids == sorted(pids)


def test_csv_output_format(sample_connections_and_processes):
    """CSV output should have correct headers and rows."""
    import csv
    import io
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    detector = ConflictDetector()
    result = scanner.scan()
    conflicts = detector.detect(result.entries)
    conflict_ports = {c.port for c in conflicts}

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['port', 'protocol', 'status', 'pid', 'process', 'local_addr',
                     'connection_count', 'conflict'])
    for e in result.entries:
        writer.writerow([
            e.port, e.protocol, e.status,
            e.process.pid if e.process else '',
            e.process.name if e.process else '',
            e.local_addr, e.connection_count,
            'yes' if e.port in conflict_ports else 'no',
        ])

    output.seek(0)
    reader = csv.reader(output)
    rows = list(reader)
    header = rows[0]
    assert header == ['port', 'protocol', 'status', 'pid', 'process', 'local_addr',
                      'connection_count', 'conflict']
    assert len(rows) > 1
    port_3000_rows = [r for r in rows[1:] if r[0] == '3000']
    assert all(r[7] == 'yes' for r in port_3000_rows)


def test_watch_mode_output_format(sample_connections_and_processes):
    """Watch mode should format opened/closed port messages correctly."""
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo([], {})
    scanner = PortScanner(system)
    scanner.scan()  # initial empty scan

    system._connections = conns
    system._processes = procs
    result = scanner.scan()

    assert len(result.opened) >= 3
    for entry in result.opened:
        port = entry.port
        name = entry.process.name if entry.process else "unknown"
        pid = entry.process.pid if entry.process else "?"
        msg = f"Port {port} OPENED ({name}, PID {pid})"
        assert "OPENED" in msg
        assert str(port) in msg


def test_full_scan_filter_by_protocol(sample_connections_and_processes):
    """Full scan then filter by protocol should return only matching entries."""
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    result = scanner.scan()
    tcp_entries = [e for e in result.entries if e.protocol == 'tcp']
    udp_entries = [e for e in result.entries if e.protocol == 'udp']
    assert len(tcp_entries) >= 3
    assert len(udp_entries) == 0


def test_full_scan_filter_by_process_name(sample_connections_and_processes):
    """Full scan then filter by process name substring."""
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    result = scanner.scan()
    node_entries = [e for e in result.entries if e.process and 'node' in e.process.name]
    assert len(node_entries) >= 1
    assert all(e.process.name == 'node' for e in node_entries)
    none_entries = [e for e in result.entries if e.process and 'nonexistent' in e.process.name]
    assert len(none_entries) == 0


def test_guard_with_custom_config_protected():
    """Guard with custom protected processes from config."""
    config = PortmapConfig(protected_processes=['myapp', 'speciald'])
    guard = ProcessGuard(extra_protected=set(config.protected_processes))
    proc_custom = ProcessInfo(5000, 'myapp', 'myapp --serve', 'user', 0.0, 20.0)
    assert guard.is_protected(proc_custom) is True
    ok, reason = guard.can_kill(proc_custom)
    assert ok is False
    proc_normal = ProcessInfo(6000, 'otherapp', 'otherapp', 'user', 0.0, 10.0)
    assert guard.is_protected(proc_normal) is False


def test_scan_history_max_size_enforced():
    """ScanHistory should enforce max_size by dropping oldest entries."""
    history = ScanHistory(max_size=100)
    for i in range(200):
        entry = make_entry(port=8080 + (i % 50), pid=100 + i, name=f"app{i}")
        result = ScanResult(entries=[entry], opened=[entry] if i % 2 == 0 else [],
                            closed=[], timestamp=float(i))
        history.add(result)
    assert len(history) == 100
    changes = history.get_recent_changes(n=100)
    assert len(changes) <= 100


def test_full_pipeline_scan_filter_conflict_guard_stats(sample_connections_and_processes):
    """End-to-end: scan -> filter -> conflict detect -> guard check -> stats."""
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    detector = ConflictDetector()
    guard = ProcessGuard()

    # 1. Scan
    result = scanner.scan()
    assert len(result.entries) >= 3

    # 2. Filter by protocol
    tcp_only = [e for e in result.entries if e.protocol == 'tcp']
    assert len(tcp_only) == len(result.entries)  # all are TCP in test data

    # 3. Conflict detection
    conflicts = detector.detect(result.entries)
    assert len(conflicts) == 1
    assert conflicts[0].port == 3000
    conflict_ports = {c.port for c in conflicts}

    # 4. Guard check
    for entry in result.entries:
        if entry.process:
            ok, reason = guard.can_kill(entry.process)
            if entry.process.name == 'sshd':
                assert ok is False
                assert "Protected" in reason
            elif entry.process.username not in ('root', 'SYSTEM'):
                assert ok is True

    # 5. Stats
    total = len(result.entries)
    conflict_count = len(conflicts)
    protected_count = sum(
        1 for e in result.entries
        if e.process and guard.is_protected(e.process)
    )
    assert total >= 3
    assert conflict_count == 1
    assert protected_count >= 1  # at least sshd


def test_pipeline_scan_change_detection_history(sample_connections_and_processes):
    """Pipeline: initial scan -> add ports -> detect changes -> store in history."""
    conns, procs = sample_connections_and_processes
    system = MockSystemInfo([], {})
    scanner = PortScanner(system)
    history = ScanHistory(max_size=50)

    # Initial empty scan
    result1 = scanner.scan()
    history.add(result1)
    assert len(result1.entries) == 0

    # Add ports
    system._connections = conns
    system._processes = procs
    result2 = scanner.scan()
    history.add(result2)
    assert len(result2.opened) >= 3
    assert len(result2.closed) == 0

    # Remove some ports
    system._connections = [conns[0]]  # keep only port 22
    system._processes = {100: procs[100]}
    result3 = scanner.scan()
    history.add(result3)
    assert len(result3.opened) == 0
    assert len(result3.closed) >= 2

    # Verify history tracks changes
    assert len(history) == 3
    changes = history.get_recent_changes(n=10)
    assert len(changes) == 2  # result2 and result3 had changes


def test_pipeline_guard_blocks_kill_of_scanned_protected_process():
    """Scan finds sshd -> guard blocks kill -> can_kill returns False."""
    conns = [make_conn(port=22, pid=100, status="LISTEN")]
    procs = {100: ProcessInfo(100, 'sshd', '/usr/sbin/sshd', 'root', 0.0, 5.0)}
    system = MockSystemInfo(conns, procs)
    scanner = PortScanner(system)
    guard = ProcessGuard()

    result = scanner.scan()
    entry = result.entries[0]
    assert entry.process is not None
    assert entry.process.name == 'sshd'

    ok, reason = guard.can_kill(entry.process)
    assert ok is False
    assert "Protected" in reason

    # Verify kill_process is not called (would be guarded in real app)
    assert guard.is_protected(entry.process) is True
