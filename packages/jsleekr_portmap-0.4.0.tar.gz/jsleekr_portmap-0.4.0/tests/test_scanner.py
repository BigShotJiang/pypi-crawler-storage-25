from portmap.models import ConnectionInfo, ProcessInfo, PortEntry, ScanResult
from portmap.scanner import PortScanner, ConflictDetector, ScanHistory


class MockSystemInfo:
    def __init__(self, connections=None, processes=None):
        self._connections = connections or []
        self._processes = processes or {}

    def get_connections(self):
        return self._connections

    def get_process(self, pid):
        return self._processes.get(pid)

    def kill_process(self, pid):
        return pid in self._processes


def _make_process(pid=100, name="myapp", username="user1"):
    return ProcessInfo(
        pid=pid, name=name, cmdline=name,
        username=username, create_time=1000.0, memory_mb=50.0,
    )


def _make_conn(port=8080, protocol="tcp", status="LISTEN", pid=100,
               local_addr="0.0.0.0", remote_addr="", remote_port=0):
    return ConnectionInfo(
        protocol=protocol, local_addr=local_addr, local_port=port,
        remote_addr=remote_addr, remote_port=remote_port,
        status=status, pid=pid,
    )


# 1. scan returns PortEntry for LISTEN connection
def test_scan_returns_port_entry_for_listen():
    proc = _make_process(pid=100)
    mock = MockSystemInfo(
        connections=[_make_conn(port=8080, pid=100, status="LISTEN")],
        processes={100: proc},
    )
    scanner = PortScanner(mock)
    result = scanner.scan()
    assert len(result.entries) == 1
    assert result.entries[0].port == 8080
    assert result.entries[0].process == proc
    assert result.entries[0].status == "LISTEN"


# 2. scan groups ESTABLISHED connections (connection_count)
def test_scan_groups_established_connections():
    proc = _make_process(pid=100)
    mock = MockSystemInfo(
        connections=[
            _make_conn(port=8080, pid=100, status="LISTEN"),
            _make_conn(port=8080, pid=100, status="ESTABLISHED", remote_addr="1.2.3.4", remote_port=5000),
            _make_conn(port=8080, pid=100, status="ESTABLISHED", remote_addr="1.2.3.5", remote_port=5001),
        ],
        processes={100: proc},
    )
    scanner = PortScanner(mock)
    result = scanner.scan()
    assert len(result.entries) == 1
    assert result.entries[0].connection_count == 2


# 3. scan handles pid=None
def test_scan_handles_pid_none():
    mock = MockSystemInfo(
        connections=[_make_conn(port=53, pid=None, status="LISTEN")],
        processes={},
    )
    scanner = PortScanner(mock)
    result = scanner.scan()
    assert len(result.entries) == 1
    assert result.entries[0].process is None


# 4. scan detects newly opened ports
def test_scan_detects_opened_ports():
    mock = MockSystemInfo(connections=[], processes={})
    scanner = PortScanner(mock)
    scanner.scan()  # first scan, empty

    proc = _make_process(pid=200)
    mock._connections = [_make_conn(port=3000, pid=200, status="LISTEN")]
    mock._processes = {200: proc}
    result = scanner.scan()
    assert len(result.opened) == 1
    assert result.opened[0].port == 3000


# 5. scan detects closed ports
def test_scan_detects_closed_ports():
    proc = _make_process(pid=200)
    mock = MockSystemInfo(
        connections=[_make_conn(port=3000, pid=200, status="LISTEN")],
        processes={200: proc},
    )
    scanner = PortScanner(mock)
    scanner.scan()  # first scan with port 3000

    mock._connections = []
    result = scanner.scan()
    assert len(result.closed) == 1
    assert result.closed[0].port == 3000


# 6. scan second scan same data: no opened/closed
def test_scan_same_data_no_changes():
    proc = _make_process(pid=100)
    mock = MockSystemInfo(
        connections=[_make_conn(port=8080, pid=100, status="LISTEN")],
        processes={100: proc},
    )
    scanner = PortScanner(mock)
    scanner.scan()
    result = scanner.scan()
    assert len(result.opened) == 0
    assert len(result.closed) == 0


# 7. scan clears previous data (memory safety)
def test_scan_clears_previous_data():
    proc = _make_process(pid=100)
    mock = MockSystemInfo(
        connections=[_make_conn(port=8080, pid=100, status="LISTEN")],
        processes={100: proc},
    )
    scanner = PortScanner(mock)
    scanner.scan()
    scanner.scan()
    # After two scans, _previous should only hold the data from the last scan
    assert len(scanner._previous) == 1


# 8. ConflictDetector detects two PIDs on same LISTEN port
def test_conflict_detector_detects_conflict():
    entries = [
        PortEntry(port=8080, protocol="tcp", process=_make_process(pid=100, name="app1"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=8080, protocol="tcp", process=_make_process(pid=200, name="app2"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 1
    assert conflicts[0].port == 8080
    assert len(conflicts[0].entries) == 2


# 9. ConflictDetector returns empty for no conflicts
def test_conflict_detector_no_conflicts():
    entries = [
        PortEntry(port=8080, protocol="tcp", process=_make_process(pid=100),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 0


# 10. ConflictDetector ignores ESTABLISHED
def test_conflict_detector_ignores_established():
    entries = [
        PortEntry(port=8080, protocol="tcp", process=_make_process(pid=100),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=8080, protocol="tcp", process=_make_process(pid=200),
                  status="ESTABLISHED", local_addr="0.0.0.0", remote_addr="1.2.3.4", remote_port=5000),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 0


# 11. scan handles empty connections
def test_scan_handles_empty_connections():
    mock = MockSystemInfo(connections=[], processes={})
    scanner = PortScanner(mock)
    result = scanner.scan()
    assert len(result.entries) == 0
    assert len(result.opened) == 0
    assert len(result.closed) == 0


# 12. scan handles process that dies (get_process returns None)
def test_scan_handles_dead_process():
    mock = MockSystemInfo(
        connections=[_make_conn(port=9090, pid=999, status="LISTEN")],
        processes={},  # pid 999 not in processes — simulates dead process
    )
    scanner = PortScanner(mock)
    result = scanner.scan()
    assert len(result.entries) == 1
    assert result.entries[0].process is None
    assert result.entries[0].port == 9090


# 13. scan detects both opened and closed ports when data changes between scans
def test_scan_detects_added_and_removed_ports():
    proc1 = _make_process(pid=100, name="app1")
    mock = MockSystemInfo(
        connections=[_make_conn(port=8080, pid=100, status="LISTEN")],
        processes={100: proc1},
    )
    scanner = PortScanner(mock)
    scanner.scan()  # first scan: port 8080

    # Second scan: port 8080 removed, port 9090 added
    proc2 = _make_process(pid=200, name="app2")
    mock._connections = [_make_conn(port=9090, pid=200, status="LISTEN")]
    mock._processes = {200: proc2}
    result = scanner.scan()
    assert len(result.opened) == 1
    assert result.opened[0].port == 9090
    assert len(result.closed) == 1
    assert result.closed[0].port == 8080


# 14. ConflictDetector detects conflicts on UDP ports
def test_conflict_detector_udp_conflict():
    entries = [
        PortEntry(port=5353, protocol="udp", process=_make_process(pid=100, name="mdns1"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=5353, protocol="udp", process=_make_process(pid=200, name="mdns2"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 1
    assert conflicts[0].port == 5353
    assert len(conflicts[0].entries) == 2


# 15. PortEntry equality comparison (dataclass default)
def test_port_entry_equality():
    proc = _make_process(pid=100, name="app")
    e1 = PortEntry(port=8080, protocol="tcp", process=proc, status="LISTEN",
                   local_addr="0.0.0.0", remote_addr="", remote_port=0, connection_count=5)
    e2 = PortEntry(port=8080, protocol="tcp", process=proc, status="LISTEN",
                   local_addr="0.0.0.0", remote_addr="", remote_port=0, connection_count=5)
    assert e1 == e2
    e3 = PortEntry(port=9090, protocol="tcp", process=proc, status="LISTEN",
                   local_addr="0.0.0.0", remote_addr="", remote_port=0, connection_count=5)
    assert e1 != e3


# 16. ScanResult timestamp is set after scan
def test_scan_result_timestamp_is_set():
    import time
    mock = MockSystemInfo(
        connections=[_make_conn(port=8080, pid=100, status="LISTEN")],
        processes={100: _make_process(pid=100)},
    )
    scanner = PortScanner(mock)
    before = time.time()
    result = scanner.scan()
    after = time.time()
    assert result.timestamp >= before
    assert result.timestamp <= after


# 17. ScanHistory add and get_recent_changes
def test_scan_history_add_and_recent_changes():
    history = ScanHistory(max_size=50)
    proc = _make_process(pid=100)
    entry = PortEntry(port=8080, protocol="tcp", process=proc, status="LISTEN",
                      local_addr="0.0.0.0", remote_addr="", remote_port=0)
    result_no_change = ScanResult(entries=[entry], opened=[], closed=[], timestamp=1000.0)
    result_with_open = ScanResult(entries=[entry], opened=[entry], closed=[], timestamp=2000.0)

    history.add(result_no_change)
    history.add(result_with_open)
    assert len(history) == 2

    changes = history.get_recent_changes(n=10)
    assert len(changes) == 1
    assert changes[0]['timestamp'] == 2000.0
    assert 8080 in changes[0]['opened']
    assert changes[0]['closed'] == []


# 18. ScanHistory respects max_size
def test_scan_history_max_size():
    history = ScanHistory(max_size=5)
    for i in range(10):
        result = ScanResult(entries=[], opened=[], closed=[], timestamp=float(i))
        history.add(result)
    assert len(history) == 5


# 19. ScanHistory clear
def test_scan_history_clear():
    history = ScanHistory(max_size=50)
    for i in range(5):
        result = ScanResult(entries=[], opened=[], closed=[], timestamp=float(i))
        history.add(result)
    assert len(history) == 5
    history.clear()
    assert len(history) == 0


# 20. ScanHistory get_recent_changes with empty history
def test_scan_history_empty_recent_changes():
    history = ScanHistory(max_size=50)
    changes = history.get_recent_changes(n=10)
    assert changes == []


# 21. ConflictDetector with process=None entries
def test_conflict_detector_none_process():
    entries = [
        PortEntry(port=53, protocol="udp", process=None,
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=53, protocol="udp", process=None,
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    # Both have process=None so both have pid=None -- same PID, no conflict
    conflicts = detector.detect(entries)
    assert len(conflicts) == 0


# 22. ConflictDetector one None process and one real -- conflict
def test_conflict_detector_none_vs_real_process():
    entries = [
        PortEntry(port=53, protocol="udp", process=None,
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=53, protocol="udp", process=_make_process(pid=100, name="dnsmasq"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 1
    assert conflicts[0].port == 53


# 23. Multiple scans with changing port counts
def test_scan_multiple_port_changes():
    mock = MockSystemInfo(connections=[], processes={})
    scanner = PortScanner(mock)
    scanner.scan()  # empty

    # Add 5 ports
    procs = {i: _make_process(pid=i, name=f"app{i}") for i in range(100, 105)}
    mock._connections = [_make_conn(port=8000+i, pid=100+i, status="LISTEN") for i in range(5)]
    mock._processes = procs
    result = scanner.scan()
    assert len(result.opened) == 5
    assert len(result.closed) == 0

    # Remove 3, keep 2
    mock._connections = [_make_conn(port=8000, pid=100, status="LISTEN"),
                         _make_conn(port=8001, pid=101, status="LISTEN")]
    mock._processes = {100: procs[100], 101: procs[101]}
    result = scanner.scan()
    assert len(result.opened) == 0
    assert len(result.closed) == 3


# 24. Scanner handles get_process raising exception (simulates AccessDenied)
def test_scan_handles_get_process_exception():
    """If get_process raises an exception, scan should still succeed with process=None."""

    class FailingSystemInfo:
        def get_connections(self):
            return [_make_conn(port=4000, pid=999, status="LISTEN")]
        def get_process(self, pid):
            raise PermissionError("Access denied")
        def kill_process(self, pid):
            return False

    scanner = PortScanner(FailingSystemInfo())
    result = scanner.scan()
    assert len(result.entries) == 1
    assert result.entries[0].port == 4000
    assert result.entries[0].process is None


# 25. Scanner handles get_connections returning mixed valid/invalid data
def test_scan_handles_connections_with_missing_pid():
    """Connections with pid=None should be scanned without error."""
    mock = MockSystemInfo(
        connections=[
            _make_conn(port=80, pid=100, status="LISTEN"),
            _make_conn(port=443, pid=None, status="LISTEN"),
        ],
        processes={100: _make_process(pid=100, name="nginx")},
    )
    scanner = PortScanner(mock)
    result = scanner.scan()
    assert len(result.entries) == 2
    # pid=None entry should have process=None
    entry_443 = [e for e in result.entries if e.port == 443][0]
    assert entry_443.process is None


# 26. ScanHistory uses deque -- verify max_size overflow does not raise
def test_scan_history_deque_overflow():
    """ScanHistory should handle rapid overflow without error (deque-backed)."""
    history = ScanHistory(max_size=3)
    for i in range(100):
        result = ScanResult(entries=[], opened=[], closed=[], timestamp=float(i))
        history.add(result)
    assert len(history) == 3
    changes = history.get_recent_changes(n=10)
    assert isinstance(changes, list)


# 27. ConflictDetector should NOT flag same port on different protocols as conflict
def test_conflict_detector_different_protocols_no_conflict():
    """TCP port 53 and UDP port 53 with different PIDs are NOT a conflict."""
    entries = [
        PortEntry(port=53, protocol="tcp", process=_make_process(pid=100, name="dns-tcp"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=53, protocol="udp", process=_make_process(pid=200, name="dns-udp"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 0


# 28. ConflictDetector still detects same-protocol conflict
def test_conflict_detector_same_protocol_conflict():
    """Two different PIDs on TCP port 80 is a conflict."""
    entries = [
        PortEntry(port=80, protocol="tcp", process=_make_process(pid=100, name="nginx"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
        PortEntry(port=80, protocol="tcp", process=_make_process(pid=200, name="apache"),
                  status="LISTEN", local_addr="0.0.0.0", remote_addr="", remote_port=0),
    ]
    detector = ConflictDetector()
    conflicts = detector.detect(entries)
    assert len(conflicts) == 1
    assert conflicts[0].port == 80
