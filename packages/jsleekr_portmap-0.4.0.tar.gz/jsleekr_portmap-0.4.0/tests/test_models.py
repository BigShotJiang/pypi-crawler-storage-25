import pytest
import time
from unittest.mock import patch
from portmap.models import ConnectionInfo, ProcessInfo, PortEntry, ScanResult, Conflict, format_uptime


def test_connection_info_creation():
    c = ConnectionInfo('tcp', '0.0.0.0', 8080, '', 0, 'LISTEN', 1234)
    assert c.protocol == 'tcp'
    assert c.local_port == 8080
    assert c.pid == 1234


def test_process_info_creation():
    p = ProcessInfo(1234, 'node', 'node server.js', 'user', 1000.0, 50.5)
    assert p.name == 'node'
    assert p.memory_mb == 50.5


def test_port_entry_to_dict():
    proc = ProcessInfo(1234, 'nginx', 'nginx', 'root', 0.0, 12.3)
    entry = PortEntry(80, 'tcp', proc, 'LISTEN', '0.0.0.0', '', 0, 15)
    d = entry.to_dict()
    assert d['port'] == 80
    assert d['pid'] == 1234
    assert d['process'] == 'nginx'
    assert d['connection_count'] == 15


def test_port_entry_none_process():
    entry = PortEntry(8080, 'tcp', None, 'LISTEN', '0.0.0.0', '', 0)
    d = entry.to_dict()
    assert d['pid'] is None
    assert d['process'] is None


def test_scan_result_with_changes():
    e1 = PortEntry(80, 'tcp', None, 'LISTEN', '0.0.0.0', '', 0)
    e2 = PortEntry(443, 'tcp', None, 'LISTEN', '0.0.0.0', '', 0)
    result = ScanResult(entries=[e1, e2], opened=[e2], closed=[], timestamp=1000.0)
    assert len(result.entries) == 2
    assert len(result.opened) == 1
    assert result.opened[0].port == 443


# format_uptime tests
def test_format_uptime_seconds():
    with patch('portmap.models.time') as mock_time:
        mock_time.time.return_value = 1000.0
        assert format_uptime(970.0) == "30s"
        assert format_uptime(995.0) == "5s"


def test_format_uptime_minutes_and_hours():
    with patch('portmap.models.time') as mock_time:
        mock_time.time.return_value = 10000.0
        # 5 minutes ago = 300s
        assert format_uptime(9700.0) == "5m 0s"
        # 2 hours 30 minutes ago = 9000s
        assert format_uptime(1000.0) == "2h 30m"


def test_format_uptime_days():
    with patch('portmap.models.time') as mock_time:
        mock_time.time.return_value = 200000.0
        # 2 days 3 hours 46 minutes = 186960s
        create_time = 200000.0 - (2 * 86400 + 3 * 3600)
        assert format_uptime(create_time) == "2d 3h"
