<div align="center">

# 🔌 portmap

### See what's running on your ports

[![GitHub Stars](https://img.shields.io/github/stars/JSLEEKR/portmap?style=for-the-badge&logo=github&color=yellow)](https://github.com/JSLEEKR/portmap/stargazers)
[![License](https://img.shields.io/badge/license-MIT-blue?style=for-the-badge)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.12%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](#)
[![Tests](https://img.shields.io/badge/tests-84%20passing-brightgreen?style=for-the-badge)](#)

<br/>

**Real-time terminal port monitor with a Textual TUI dashboard.**

Live Dashboard + Conflict Detection + Process Guard

[Quick Start](#quick-start) | [Features](#features)

</div>

---

## Why This Exists

`netstat` and `ss` are snapshots -- you run them, read the output, and run them again. portmap refreshes automatically and highlights changes as they happen. Port conflicts silently cause random failures when two services bind to the same port; portmap detects them instantly and flags them in the dashboard. Killing the wrong process can be catastrophic, so portmap protects system-critical processes like sshd, systemd, and dockerd from accidental termination.

```
+-- portmap ---------------------------------------------------------+
| [Filter by port or process...] [Proto: ALL] [Status: ALL]          |
+--------------------------------------------------------------------+
| PORT    | PROTO | STATUS      | PID   | PROCESS   | CMD            |
|---------+-------+-------------+-------+-----------+----------------|
| 🔒22   | TCP   | LISTEN      | 1234  | sshd      | /usr/sbin/ss.. |
|    80   | TCP   | LISTEN      | 5678  | nginx     | nginx -g dae.. |
| ⚠3000  | TCP   | LISTEN      | 9012  | node      | node server.js |
| ⚠3000  | TCP   | LISTEN      | 3456  | python    | python app.py  |
|  5432   | TCP   | LISTEN      | 7890  | postgres  | postgres -D .. |
|  8080   | TCP   | LISTEN      | 2345  | java      | java -jar ap.. |
+--------------------------------------------------------------------+
| Port: 80 (TCP)                                                     |
| Process: nginx (PID 5678)                                          |
| User: www-data | Memory: 12.3 MB | Uptime: 2h 15m                 |
| Connections: 15 ESTABLISHED                                        |
| [K] Press 'k' to kill this process                                 |
+--------------------------------------------------------------------+
| ● 6 ports | ⚠ 1 conflict | 🔒 1 protected | 2.0s refresh         |
+--------------------------------------------------------------------+
```

## Features

| Feature | Description |
|---------|-------------|
| Live TUI dashboard | Auto-refreshing port table with Textual |
| Change detection | Highlights newly opened/closed ports between scans |
| Conflict detection | Flags ports bound by multiple processes |
| Process guard | Prevents killing protected system processes |
| Detail panel | PID, user, memory, uptime, connection count for selected port |
| Kill with confirmation | Modal dialog before terminating a process; protected processes blocked |
| CLI mode | `portmap list` and `portmap conflicts` for scripts |
| JSON output | `portmap list --json` for piping to jq |
| CSV export | `portmap list --csv` for pipe-friendly spreadsheet output |
| Sort options | `portmap list --sort pid` sorts by port, pid, process, or status |
| Connection history | `ScanHistory` tracks the last N scan results for change review |
| Process uptime | Human-readable uptime display (e.g., `2h 15m`, `3d 5h`) in detail panel |
| Watch mode | `portmap watch --interval 3` prints real-time OPENED/CLOSED events |
| YAML config | Customize refresh interval, protected processes, theme |
| Memory safe | Reference-swap scanning with no accumulation leaks |

## Requirements

| Dependency | Version |
|------------|---------|
| Python | >= 3.12 |
| psutil | >= 5.9.0 |
| textual | >= 0.70.0 |
| click | >= 8.0 |
| pyyaml | >= 6.0 |

Dev extras: `pytest >= 8.0`, `pytest-asyncio >= 0.23.0`

## Quick Start

```bash
# Install (editable, with dev tools)
pip install -e ".[dev]"

# Or install without dev extras
pip install -e .

# Launch TUI dashboard
portmap

# Single snapshot (no TUI)
portmap --no-refresh

# List ports as table
portmap list

# List as JSON (with metadata)
portmap list --json

# List as CSV
portmap list --csv

# Sort by PID
portmap list --sort pid

# Watch mode -- real-time port changes
portmap watch
portmap watch --interval 5

# Show conflicts only
portmap conflicts
```

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Arrow keys (Up/Down) | Navigate port list |
| `/` | Focus filter input |
| `Enter` | Show detail panel for selected port |
| `k` | Kill selected process (with confirmation) |
| `r` | Force refresh |
| `p` | Cycle protocol filter (ALL / TCP / UDP) |
| `s` | Cycle status filter (ALL / LISTEN / ESTABLISHED) |
| `q` | Quit |

## Understanding the TUI

### Layout

The TUI is divided into four horizontal zones, top to bottom:

1. **Filter bar** -- text input for searching by port number or process name, plus toggle labels for protocol and status filters.
2. **Port table** -- scrollable data table showing all matching ports. Each row shows port number, protocol, status, PID, process name, and truncated command line.
3. **Detail panel** -- expanded information for the selected row: user, memory usage, uptime, connection count, and kill eligibility.
4. **Status bar** -- one-line summary: total ports, conflict count, protected count, and refresh interval.

### Icons

| Icon | Meaning |
|------|---------|
| `🔒` (lock) | Protected process -- cannot be killed (system-critical or root/SYSTEM owned) |
| `⚠` (warning) | Port conflict -- multiple processes listening on the same port |

### Filters

Filters are cumulative (AND logic). All three can be active simultaneously:

- **Text filter** (`/`): free-text substring match against port number or process name. Case-insensitive.
- **Protocol filter** (`p`): cycles through ALL, TCP, UDP.
- **Status filter** (`s`): cycles through ALL, LISTEN, ESTABLISHED.

The table updates immediately as you type or toggle filters.

### Kill workflow

1. Navigate to a row with arrow keys.
2. Press `k`. If the process is protected, a notification appears and nothing happens.
3. A modal dialog shows PID, name, and command line. Press **Confirm** to terminate or **Cancel** to abort.
4. On confirmation, portmap sends SIGTERM (or TerminateProcess on Windows), waits 3 seconds, then escalates to SIGKILL if the process is still alive.

## How It Works

```
                          portmap architecture
  ┌─────────────┐     ┌──────────────┐     ┌────────────────────┐
  │  SystemInfo  │────▶│  PortScanner │────▶│   ScanResult       │
  │  (psutil)    │     │              │     │  .entries           │
  └─────────────┘     │  gen(N) ─────│──┐  │  .opened / .closed  │
                      │  gen(N-1) ───│─┘   └────────┬───────────┘
                      └──────────────┘              │
                           │                        ▼
                      ┌────┴─────┐        ┌─────────────────┐
                      │ Process  │        │ ConflictDetector │
                      │  Guard   │        │ (multi-PID port) │
                      └──────────┘        └─────────────────┘
                           │                        │
                      ┌────┴────────────────────────┴───┐
                      │          CLI / TUI App           │
                      │  list  │ conflicts │ dashboard   │
                      └─────────────────────────────────┘
```

**Scan cycle**: `SystemInfo` reads live connections from `psutil`. `PortScanner` groups them into `PortEntry` objects, compares against the previous generation, and emits `opened`/`closed` deltas. `ConflictDetector` flags ports with multiple LISTEN PIDs. `ProcessGuard` prevents accidental kills of system-critical processes.

## CLI Commands

```bash
# Default: launch TUI with 2s refresh
portmap

# Custom refresh interval
portmap --interval 5

# Single scan, print and exit
portmap --no-refresh

# Single scan with filters
portmap --no-refresh --protocol tcp
portmap --no-refresh --port 3000-9000
portmap --no-refresh --process nginx

# Non-TUI list
portmap list
portmap list --json
portmap list --csv
portmap list --sort pid

# Watch mode (non-TUI, prints changes)
portmap watch
portmap watch --interval 5

# Conflicts only
portmap conflicts
```

## Configuration

Config file: `~/.portmap/config.yaml`

```yaml
refresh_interval: 2.0
protected_processes: []
show_established: true
max_history: 100
theme: dark
```

Generate default config:

```python
from portmap.config import save_default_config
save_default_config()
```

## Memory Safety

portmap is designed for long-running sessions without memory growth. The scanner uses a **2-generation design**:

```
Scan N:    _current  = { port data }     _previous = { old data }
Scan N+1:  _previous = _current (swap)   _current  = { new data }
           old _previous is dropped (GC'd)
```

- **Reference-swap scanning**: Each scan creates a new dict and swaps references. The previous generation is replaced, not accumulated. At most 2 snapshots exist in memory at any time.
- **No history accumulation**: Only `_current` (for display) and `_previous` (for change detection) are retained. No unbounded lists or caches.
- **Verified by tracemalloc tests**: Memory tests confirm <1MB growth after 1000+ scan cycles with 20 ports.

## API Reference

### Core Classes

```python
from portmap.system import SystemInfo
from portmap.scanner import PortScanner, ConflictDetector, ScanHistory
from portmap.guard import ProcessGuard
from portmap.config import load_config, save_default_config, PortmapConfig
from portmap.models import ConnectionInfo, ProcessInfo, PortEntry, ScanResult, Conflict
```

**SystemInfo** -- psutil wrapper for connections and process info.

**PortScanner(system, interval=2.0)** -- Scans ports via `system.get_connections()`, returns `ScanResult` with change detection (opened/closed).

**ConflictDetector** -- `detect(entries)` returns list of `Conflict` for ports with multiple LISTEN PIDs on the same protocol.

**ScanHistory(max_size=100)** -- `add(result)` stores scan results, `get_recent_changes(n)` returns recent opened/closed events, `clear()` resets.

**ProcessGuard(extra_protected=None)** -- `is_protected(process)` checks system-critical processes. `can_kill(process)` returns `(bool, reason)`.

**PortmapConfig** -- Dataclass with `refresh_interval`, `protected_processes`, `show_established`, `max_history`, `theme`.

## Data Formats

### JSON output (`portmap list --json`)

```json
{
  "timestamp": 1711440000.123,
  "timestamp_iso": "2026-03-26T12:00:00.123000+00:00",
  "total": 3,
  "conflicts": [
    { "port": 3000, "pids": [300, 400] }
  ],
  "entries": [
    {
      "port": 22,
      "protocol": "tcp",
      "pid": 100,
      "process": "sshd",
      "status": "LISTEN",
      "local_addr": "0.0.0.0",
      "connection_count": 0
    }
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `timestamp` | float | Unix epoch seconds |
| `timestamp_iso` | string | ISO 8601 UTC timestamp |
| `total` | int | Number of port entries |
| `conflicts` | array | Ports with multiple LISTEN PIDs |
| `conflicts[].port` | int | Conflicted port number |
| `conflicts[].pids` | int[] | PIDs binding the port |
| `entries` | array | All port entries |
| `entries[].port` | int | Port number |
| `entries[].protocol` | string | `"tcp"` or `"udp"` |
| `entries[].pid` | int\|null | Process ID (null if inaccessible) |
| `entries[].process` | string\|null | Process name |
| `entries[].status` | string | `"LISTEN"`, `"ESTABLISHED"`, etc. |
| `entries[].local_addr` | string | Local bind address |
| `entries[].connection_count` | int | ESTABLISHED connections on this port |

### CSV output (`portmap list --csv`)

Columns: `port, protocol, status, pid, process, local_addr, connection_count, conflict`

- `conflict` is `yes` or `no`
- Empty string for `pid`/`process` when inaccessible

### CI output (`portmap-ci`)

```json
{
  "total_ports": 5,
  "conflicts": 0,
  "conflict_details": []
}
```

Exit code: `0` = no conflicts, `1` = conflicts found.

## Usage Examples

```bash
# Find which process is using port 8080
portmap list | grep 8080

# Export all ports to JSON for scripting
portmap list --json > ports.json

# Parse with jq: get PIDs of all LISTEN ports
portmap list --json | jq '.entries[] | select(.status=="LISTEN") | .pid'

# Export to CSV for spreadsheet analysis
portmap list --csv > ports.csv

# Monitor ports sorted by process name
portmap list --sort process

# Watch for port changes every 10 seconds
portmap watch --interval 10

# Single snapshot (no TUI, no refresh)
portmap --no-refresh

# Check for port conflicts in CI/CD
portmap conflicts && echo "No conflicts" || echo "Conflicts found"
```

## Troubleshooting

### "Permission denied" or empty port list

On Linux/macOS, scanning all connections requires elevated privileges:

```bash
sudo portmap list
```

On Windows, run your terminal as Administrator.

### "No module named portmap"

Make sure you installed in the correct Python environment:

```bash
pip install -e ".[dev]"
python -m portmap.main --help
```

### TUI does not render correctly

Ensure your terminal supports ANSI escape codes. Try a different terminal
emulator (e.g., Windows Terminal, iTerm2, GNOME Terminal). If running over
SSH, confirm `TERM` is set (e.g., `export TERM=xterm-256color`).

### "psutil.AccessDenied" for some processes

This is normal. portmap gracefully handles processes it cannot inspect and
shows them with `\u2014` (em-dash) for missing fields. Run as root/Administrator to see
all process details.

### Config file not loading

Verify the file exists at `~/.portmap/config.yaml` and contains valid YAML.
You can regenerate the default config:

```python
from portmap.config import save_default_config
save_default_config()
```

## License

MIT License. See [LICENSE](LICENSE).
