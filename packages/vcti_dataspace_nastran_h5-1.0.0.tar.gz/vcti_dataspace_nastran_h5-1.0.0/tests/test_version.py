# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Version tests for vcti-dataspace-nastran-h5."""

import re

import vcti.dataspace_nastran_h5


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.dataspace_nastran_h5, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.dataspace_nastran_h5.__version__)
