# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for NastranH5File and NastranSolutionFolder."""

import shutil
from pathlib import Path

import h5py
import numpy as np
import pytest

from vcti.dataspace_nastran_h5 import (
    MODAL_GROUP,
    MODAL_PARTICIPATION_FACTOR,
    NastranH5File,
    NastranSolutionFolder,
)


@pytest.fixture
def nastran_h5_file(tmp_path: Path) -> Path:
    """Create a mock Nastran HDF5 file with NASTRAN/RESULT/MODAL structure."""
    f = tmp_path / "sol103.h5"
    with h5py.File(f, "w") as h5:
        h5.attrs["solver"] = "MSC.Nastran"
        h5.attrs["version_bytes"] = b"2024.1"
        h5.attrs["codes"] = np.array([b"A", b"B", b"C"])
        modal = h5.create_group("NASTRAN/RESULT/MODAL")
        modal.create_dataset(
            "MODAL_PARTICIPATION_FACTOR",
            data=np.array(
                [(1, 0.5, 0.3), (2, 0.8, 0.1)], dtype=[("mode", "i4"), ("x", "f8"), ("y", "f8")]
            ),
        )
        modal.create_dataset("EIGENVALUE", data=np.array([1.0, 2.0, 3.0]))
    return f


@pytest.fixture
def nastran_folder(tmp_path: Path, nastran_h5_file: Path) -> Path:
    """Create a solution folder with an H5 file."""
    folder = tmp_path / "sol103_results"
    folder.mkdir()
    shutil.copy(nastran_h5_file, folder / "sol103.h5")
    return folder


# -- Constants -----------------------------------------------------------------


class TestConstants:
    def test_modal_group_path(self):
        assert MODAL_GROUP == "NASTRAN/RESULT/MODAL"

    def test_modal_participation_factor_path(self):
        assert MODAL_PARTICIPATION_FACTOR == "NASTRAN/RESULT/MODAL/MODAL_PARTICIPATION_FACTOR"


# -- NastranH5File tests ------------------------------------------------------


class TestNastranH5File:
    def test_open(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        assert h5.is_valid
        h5.close()

    def test_open_with_string_path(self, nastran_h5_file: Path):
        h5 = NastranH5File(str(nastran_h5_file))
        assert h5.is_valid
        h5.close()

    def test_context_manager(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            assert h5.is_valid
        assert not h5.is_valid

    def test_nonexistent_raises(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            NastranH5File(tmp_path / "missing.h5")

    def test_default_name(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        assert h5.name == "sol103.h5"
        h5.close()

    def test_custom_name(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file, name="my-sim")
        assert h5.name == "my-sim"
        h5.close()

    def test_repr_open(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            r = repr(h5)
            assert "NastranH5File" in r
            assert "open" in r

    def test_repr_closed(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        r = repr(h5)
        assert "closed" in r

    def test_double_close(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        h5.close()  # Should not raise
        assert not h5.is_valid


class TestModalAccess:
    def test_get_modal_tables(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            tables = h5.get_modal_tables()
            assert "MODAL_PARTICIPATION_FACTOR" in tables
            assert "EIGENVALUE" in tables

    def test_get_modal_participation_factors(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            mpf = h5.get_modal_participation_factors()
            assert len(mpf) == 2
            assert mpf.dtype.names is not None

    def test_get_dataset(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            ev = h5.get_dataset("NASTRAN/RESULT/MODAL/EIGENVALUE")
            assert np.array_equal(ev, [1.0, 2.0, 3.0])

    def test_get_missing_dataset_raises(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5, pytest.raises(KeyError):
            h5.get_dataset("NASTRAN/MISSING/PATH")


class TestGroupNavigation:
    def test_get_group_keys(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            keys = h5.get_group_keys("NASTRAN/RESULT/MODAL")
            assert "MODAL_PARTICIPATION_FACTOR" in keys

    def test_get_group_keys_on_dataset_raises(self, nastran_h5_file: Path):
        with (
            NastranH5File(nastran_h5_file) as h5,
            pytest.raises(TypeError, match="dataset, not a group"),
        ):
            h5.get_group_keys("NASTRAN/RESULT/MODAL/EIGENVALUE")

    def test_get_attributes_root(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            attrs = h5.get_attributes("/")
            assert attrs["solver"] == "MSC.Nastran"

    def test_get_attributes_non_root(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            attrs = h5.get_attributes("NASTRAN/RESULT/MODAL")
            assert isinstance(attrs, dict)

    def test_get_attributes_decodes_bytes(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            attrs = h5.get_attributes("/")
            # h5py may store strings as bytes; get_attributes should decode them
            assert isinstance(attrs["version_bytes"], str)
            assert attrs["version_bytes"] == "2024.1"

    def test_get_attributes_decodes_byte_array(self, nastran_h5_file: Path):
        with NastranH5File(nastran_h5_file) as h5:
            attrs = h5.get_attributes("/")
            codes = attrs["codes"]
            assert isinstance(codes, list)
            assert codes == ["A", "B", "C"]


class TestClosedFileGuard:
    def test_get_dataset_on_closed_raises(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        with pytest.raises(RuntimeError, match="closed"):
            h5.get_dataset("NASTRAN/RESULT/MODAL/EIGENVALUE")

    def test_get_modal_tables_on_closed_raises(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        with pytest.raises(RuntimeError, match="closed"):
            h5.get_modal_tables()

    def test_get_modal_participation_factors_on_closed_raises(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        with pytest.raises(RuntimeError, match="closed"):
            h5.get_modal_participation_factors()

    def test_get_group_keys_on_closed_raises(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        with pytest.raises(RuntimeError, match="closed"):
            h5.get_group_keys("NASTRAN/RESULT/MODAL")

    def test_get_attributes_on_closed_raises(self, nastran_h5_file: Path):
        h5 = NastranH5File(nastran_h5_file)
        h5.close()
        with pytest.raises(RuntimeError, match="closed"):
            h5.get_attributes("/")


# -- NastranSolutionFolder tests -----------------------------------------------


class TestNastranSolutionFolder:
    def test_open(self, nastran_folder: Path):
        folder = NastranSolutionFolder(nastran_folder)
        assert folder.is_valid
        folder.close()

    def test_open_with_string_path(self, nastran_folder: Path):
        folder = NastranSolutionFolder(str(nastran_folder))
        assert folder.is_valid
        folder.close()

    def test_context_manager(self, nastran_folder: Path):
        with NastranSolutionFolder(nastran_folder) as folder:
            assert folder.is_valid

    def test_nonexistent_raises(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            NastranSolutionFolder(tmp_path / "missing_folder")

    def test_empty_folder(self, tmp_path: Path):
        empty = tmp_path / "empty"
        empty.mkdir()
        folder = NastranSolutionFolder(empty)
        assert not folder.is_valid

    def test_default_name(self, nastran_folder: Path):
        folder = NastranSolutionFolder(nastran_folder)
        assert folder.name == nastran_folder.name
        folder.close()

    def test_custom_name(self, nastran_folder: Path):
        folder = NastranSolutionFolder(nastran_folder, name="my-run")
        assert folder.name == "my-run"
        folder.close()

    def test_get_dataset_modes(self, nastran_folder: Path):
        with NastranSolutionFolder(nastran_folder) as folder:
            data = folder.get_dataset({"type": "modes"})
            assert len(data) == 2

    def test_get_dataset_unsupported_raises(self, nastran_folder: Path):
        with (
            NastranSolutionFolder(nastran_folder) as folder,
            pytest.raises(KeyError, match="not supported"),
        ):
            folder.get_dataset({"type": "unknown"})

    def test_get_dataset_no_h5_raises(self, tmp_path: Path):
        empty = tmp_path / "empty"
        empty.mkdir()
        folder = NastranSolutionFolder(empty)
        with pytest.raises(RuntimeError, match="No H5 file"):
            folder.get_dataset({"type": "modes"})

    def test_get_dataset_modes_missing_in_h5(self, tmp_path: Path):
        """H5 file exists but has no MODAL group — raises KeyError from h5py."""
        folder = tmp_path / "non_modal"
        folder.mkdir()
        with h5py.File(folder / "static.h5", "w") as h5:
            h5.create_group("NASTRAN/RESULT/STATIC")
            h5.create_dataset("NASTRAN/RESULT/STATIC/DISPLACEMENT", data=np.array([1.0]))
        sf = NastranSolutionFolder(folder)
        assert sf.is_valid
        with pytest.raises(KeyError):
            sf.get_dataset({"type": "modes"})
        sf.close()

    def test_get_modal_tables(self, nastran_folder: Path):
        with NastranSolutionFolder(nastran_folder) as folder:
            tables = folder.get_modal_tables()
            assert "MODAL_PARTICIPATION_FACTOR" in tables

    def test_get_modal_tables_no_h5_raises(self, tmp_path: Path):
        empty = tmp_path / "empty"
        empty.mkdir()
        folder = NastranSolutionFolder(empty)
        with pytest.raises(RuntimeError, match="No H5 file"):
            folder.get_modal_tables()

    def test_repr_with_h5(self, nastran_folder: Path):
        folder = NastranSolutionFolder(nastran_folder)
        r = repr(folder)
        assert "NastranSolutionFolder" in r
        assert "h5=True" in r
        folder.close()

    def test_repr_without_h5(self, tmp_path: Path):
        empty = tmp_path / "empty"
        empty.mkdir()
        folder = NastranSolutionFolder(empty)
        r = repr(folder)
        assert "h5=False" in r

    def test_double_close(self, nastran_folder: Path):
        folder = NastranSolutionFolder(nastran_folder)
        folder.close()
        folder.close()  # Should not raise

    def test_deterministic_file_selection(self, tmp_path: Path):
        """When multiple H5 files exist, the alphabetically first is used."""
        folder = tmp_path / "multi"
        folder.mkdir()
        for name in ["zzz.h5", "aaa.h5", "mmm.h5"]:
            with h5py.File(folder / name, "w") as h5:
                h5.attrs["name"] = name
        sf = NastranSolutionFolder(folder)
        assert sf.h5_file is not None
        assert sf.h5_file.path.name == "aaa.h5"
        sf.close()

    def test_list_h5_files(self, tmp_path: Path):
        """list_h5_files returns all H5 files sorted by name."""
        folder = tmp_path / "multi"
        folder.mkdir()
        for name in ["zzz.h5", "aaa.h5", "mmm.h5"]:
            with h5py.File(folder / name, "w") as h5:
                h5.attrs["name"] = name
        sf = NastranSolutionFolder(folder)
        files = sf.list_h5_files()
        assert len(files) == 3
        assert [f.name for f in files] == ["aaa.h5", "mmm.h5", "zzz.h5"]
        sf.close()

    def test_list_h5_files_empty(self, tmp_path: Path):
        empty = tmp_path / "empty"
        empty.mkdir()
        sf = NastranSolutionFolder(empty)
        assert sf.list_h5_files() == []
