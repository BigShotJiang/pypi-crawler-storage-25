# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.dataspace_nastran_h5 — Nastran HDF5 solution file access."""

from importlib.metadata import version

from .h5file import MODAL_GROUP, MODAL_PARTICIPATION_FACTOR, NastranH5File
from .solution_folder import DatasetQuery, NastranSolutionFolder

__version__ = version("vcti-dataspace-nastran-h5")

__all__ = [
    "MODAL_GROUP",
    "MODAL_PARTICIPATION_FACTOR",
    "DatasetQuery",
    "NastranH5File",
    "NastranSolutionFolder",
    "__version__",
]
