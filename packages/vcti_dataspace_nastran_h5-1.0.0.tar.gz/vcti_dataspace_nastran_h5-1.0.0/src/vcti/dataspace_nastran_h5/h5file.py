# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""NastranH5File — access Nastran HDF5 solution output files."""

import logging
from pathlib import Path

import h5py
import numpy as np

logger = logging.getLogger(__name__)

# Standard Nastran HDF5 paths
MODAL_GROUP = "NASTRAN/RESULT/MODAL"
MODAL_PARTICIPATION_FACTOR = f"{MODAL_GROUP}/MODAL_PARTICIPATION_FACTOR"


def _decode_attr(value: object) -> object:
    """Decode h5py attribute values, converting bytes to str.

    HDF5 attributes may contain Python ``bytes``, NumPy ``bytes_``, or
    NumPy byte-string arrays (dtype kind ``"S"``).  This function
    normalizes them to ``str`` (or ``list[str]`` for arrays).
    """
    if isinstance(value, bytes):
        # Also covers np.bytes_, which is a subclass of bytes
        return value.decode("utf-8", errors="replace")
    if isinstance(value, np.ndarray) and value.dtype.kind == "S":
        return value.astype(str).tolist()
    return value


class NastranH5File:
    """Access and query data from Nastran HDF5 (H5) solution output files.

    Provides navigation of the Nastran HDF5 hierarchy (NASTRAN/RESULT/MODAL, etc.)
    and extraction of specific datasets like modal participation factors.

    Example:
        >>> h5 = NastranH5File(Path("sol103.h5"))
        >>> tables = h5.get_modal_tables()
        >>> mpf = h5.get_modal_participation_factors()
        >>> h5.close()
    """

    def __init__(self, path: str | Path, name: str | None = None) -> None:
        """Open a Nastran H5 file.

        Args:
            path: Path to the HDF5 file.
            name: Optional logical name. Defaults to filename.

        Raises:
            FileNotFoundError: If the file does not exist.
            OSError: If the file cannot be opened.
        """
        self.path = Path(path)
        self.name = name or self.path.name
        if not self.path.exists():
            raise FileNotFoundError(f"File not found: {self.path}")
        self._h5: h5py.File | None = h5py.File(self.path, "r")
        logger.info("Opened %s", self.path)

    def get_modal_tables(self) -> list[str]:
        """List modal tables under NASTRAN/RESULT/MODAL.

        Returns:
            List of modal table names.

        Raises:
            KeyError: If the MODAL group does not exist.
        """
        self._ensure_open()
        return list(self._h5[MODAL_GROUP].keys())  # type: ignore[index]

    def get_modal_participation_factors(self) -> np.ndarray:
        """Get modal participation factors.

        Returns:
            NumPy array with modal participation factor data.

        Raises:
            KeyError: If the dataset does not exist.
        """
        self._ensure_open()
        return self._h5[MODAL_PARTICIPATION_FACTOR][:]  # type: ignore[index,no-any-return]

    def get_dataset(self, path: str) -> np.ndarray:
        """Get a dataset by HDF5 path.

        Args:
            path: Path within the HDF5 file (e.g., "NASTRAN/RESULT/MODAL/...").

        Returns:
            Dataset as a NumPy array.

        Raises:
            KeyError: If the path does not exist.
        """
        self._ensure_open()
        return self._h5[path][:]  # type: ignore[index,no-any-return]

    def get_group_keys(self, path: str) -> list[str]:
        """List keys in an HDF5 group.

        Args:
            path: Path to the group.

        Returns:
            List of child keys.

        Raises:
            KeyError: If the path does not exist.
            TypeError: If the path points to a dataset, not a group.
        """
        self._ensure_open()
        obj = self._h5[path]  # type: ignore[index]
        if isinstance(obj, h5py.Dataset):
            raise TypeError(
                f"Path '{path}' is a dataset, not a group. "
                "Use get_dataset() to read dataset values."
            )
        return list(obj.keys())

    def get_attributes(self, path: str = "/") -> dict[str, object]:
        """Get HDF5 attributes for a group or dataset.

        Byte-string attributes (common in HDF5) are decoded to ``str``.
        NumPy byte arrays are converted to lists of ``str``.

        Args:
            path: Path within the HDF5 file. Defaults to root.

        Returns:
            Dict of attribute name to value.
        """
        self._ensure_open()
        obj = self._h5[path]  # type: ignore[index]
        return {k: _decode_attr(obj.attrs[k]) for k in obj.attrs}

    @property
    def is_valid(self) -> bool:
        """Check if the file is open and accessible."""
        return self._h5 is not None and bool(self._h5.id)

    def close(self) -> None:
        """Close the HDF5 file. Safe to call multiple times."""
        if self._h5 is not None and self._h5.id:
            self._h5.close()
            logger.info("Closed %s", self.path)
        self._h5 = None

    def _ensure_open(self) -> None:
        """Raise if the file has been closed."""
        if not self.is_valid:
            raise RuntimeError(f"HDF5 file is closed: {self.path}")

    def __enter__(self) -> "NastranH5File":
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.close()

    def __repr__(self) -> str:
        status = "open" if self.is_valid else "closed"
        return f"NastranH5File(name={self.name!r}, path={self.path}, {status})"
