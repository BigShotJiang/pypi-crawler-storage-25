# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""NastranSolutionFolder — manage Nastran solution folders with H5 files."""

import logging
from pathlib import Path
from typing import Literal, TypedDict

import numpy as np

from .h5file import MODAL_PARTICIPATION_FACTOR, NastranH5File

logger = logging.getLogger(__name__)


class DatasetQuery(TypedDict):
    """Query dict for dataset retrieval by logical type."""

    type: Literal["modes"]


class NastranSolutionFolder:
    """Access Nastran solution folders containing H5 result files.

    Scans a folder for .h5 files and provides access to the first
    Nastran H5 file found (sorted by name for deterministic selection).
    Supports dataset retrieval by type.

    Example:
        >>> folder = NastranSolutionFolder(Path("sol103_results/"))
        >>> if folder.is_valid:
        ...     data = folder.get_dataset({"type": "modes"})
        >>> folder.close()
    """

    def __init__(
        self,
        path: str | Path,
        name: str | None = None,
    ) -> None:
        """Initialize from a solution folder path.

        Args:
            path: Path to the solution folder.
            name: Optional logical name. Defaults to folder name.

        Raises:
            FileNotFoundError: If the folder does not exist.
        """
        self.path = Path(path)
        self.name = name or self.path.name

        if not self.path.is_dir():
            raise FileNotFoundError(f"Folder not found: {self.path}")

        self._h5_file: NastranH5File | None = None

        h5_files = sorted(self.path.glob("*.h5"))
        if h5_files:
            self._h5_file = NastranH5File(h5_files[0], name=self.name)
            logger.info(
                "Found %d H5 file(s) in %s, using %s",
                len(h5_files),
                self.path,
                h5_files[0].name,
            )
        else:
            logger.warning("No H5 files found in %s", self.path)

    @property
    def h5_file(self) -> NastranH5File | None:
        """The active NastranH5File, or None if no H5 file was found."""
        return self._h5_file

    def list_h5_files(self) -> list[Path]:
        """List all H5 files in the solution folder, sorted by name.

        Returns:
            Sorted list of paths to .h5 files in the folder.
        """
        return sorted(self.path.glob("*.h5"))

    def get_dataset(self, dsattr: DatasetQuery) -> np.ndarray:
        """Retrieve a dataset by type attributes.

        Args:
            dsattr: Query with a ``"type"`` key. Supported types:
                - ``"modes"`` -> modal participation factors

        Returns:
            Dataset as NumPy array.

        Raises:
            KeyError: If dataset type is not supported.
            RuntimeError: If no H5 file is available.
        """
        if self._h5_file is None:
            raise RuntimeError("No H5 file found in solution folder")

        ds_type = dsattr.get("type")
        if ds_type == "modes":
            return self._h5_file.get_dataset(MODAL_PARTICIPATION_FACTOR)

        raise KeyError(f"Dataset type '{ds_type}' is not supported")

    def get_modal_tables(self) -> list[str]:
        """List modal tables from the H5 file.

        Raises:
            RuntimeError: If no H5 file is available.
        """
        if self._h5_file is None:
            raise RuntimeError("No H5 file found in solution folder")
        return self._h5_file.get_modal_tables()

    @property
    def is_valid(self) -> bool:
        """Check if the folder has a valid H5 file."""
        return self._h5_file is not None and self._h5_file.is_valid

    def close(self) -> None:
        """Close the H5 file. Safe to call multiple times."""
        if self._h5_file is not None:
            self._h5_file.close()

    def __enter__(self) -> "NastranSolutionFolder":
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.close()

    def __repr__(self) -> str:
        has_h5 = self._h5_file is not None
        return f"NastranSolutionFolder(name={self.name!r}, path={self.path}, h5={has_h5})"
