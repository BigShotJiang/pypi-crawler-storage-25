#****************************************************************************
#* proj_info.py
#*
#* Copyright 2018-2024 Matthew Ballance and Contributors
#*
#* Licensed under the Apache License, Version 2.0 (the "License"); you may 
#* not use this file except in compliance with the License.  
#* You may obtain a copy of the License at:
#*
#*   http://www.apache.org/licenses/LICENSE-2.0
#*
#* Unless required by applicable law or agreed to in writing, software 
#* distributed under the License is distributed on an "AS IS" BASIS, 
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
#* See the License for the specific language governing permissions and 
#* limitations under the License.
#*
#* Created on: Jan 19, 2020
#*     Author: mballance
#*
#****************************************************************************
import os
import dataclasses as dc
from enum import Enum, auto
from ivpm.packages_info import PackagesInfo
from .ivpm_yaml_reader import IvpmYamlReader
from .msg import error, fatal, note
from typing import Dict, List, Optional
from .env_spec import EnvSpec


class VenvMode(str, Enum):
    """Controls how (or whether) the python handler creates a virtual environment."""
    SKIP = "false"  # do not create a venv / skip all Python installation
    AUTO = "true"   # create venv, auto-detect tool (uv if available, else pip)
    UV   = "uv"     # create venv, force uv
    PIP  = "pip"    # create venv, force pip

    @staticmethod
    def parse(value) -> 'VenvMode':
        """Parse a yaml value (bool or str) into a VenvMode."""
        if isinstance(value, bool):
            return VenvMode.AUTO if value else VenvMode.SKIP
        s = str(value).strip().lower()
        for member in VenvMode:
            if member.value == s:
                return member
        valid = ", ".join(m.value for m in VenvMode)
        raise ValueError("Invalid venv value %r — expected one of: %s" % (value, valid))


@dc.dataclass
class PythonConfig:
    """Configuration for the python handler, parsed from ``package.with.python:``."""
    venv: VenvMode = VenvMode.AUTO
    system_site_packages: bool = False
    pre_release: bool = False


class ProjInfo():
    """Holds information read about a project from its IVPM file"""
    def __init__(self, is_src):
        self.is_src = is_src
        self.dependencies = []
        self.is_legacy = False

        # Dep-set to use when loading sub-dependencies
        self.target_dep_set = "default"
        self.dep_set_m : Dict[str,PackagesInfo] = {}
        self.setup_deps = set()
        
        self.ivpm_info = {}
        self.requirements_txt = None

        self.name = None
        self.version = None
        # This should be set to the dep-set specified by the 'dep' 
        # statement or on the command-line
        self.default_dep_set = None
        self.deps_dir = "packages"

        self.process_deps = True
        self.paths : Dict[str, Dict[str, List[str]]] = {}
        self.env_settings : List[EnvSpec] = []
        # Raw (type_name, opts) pairs from 'package: { type: … }' in this project's ivpm.yaml.
        self.self_types : list = []
        # Configuration for the python handler from 'package.with.python:'.
        # None means the project did not declare ``with.python`` at all.
        self.python_config : Optional[PythonConfig] = None
        # Generic handler configuration from 'package.with.<key>:' entries
        # that are not handled by the core reader.  Keyed by the with-key
        # name (e.g. "cbwa"), value is the raw dict/value from YAML.
        self.handler_configs : Dict[str, object] = {}

    def has_dep_set(self, name):
        return name in self.dep_set_m.keys()
            
    def get_dep_set(self, name):
        return self.dep_set_m[name]
    
    def get_target_dep_set(self):
        if self.target_dep_set is None:
            raise Exception("target_dep_set is not specified")
        if self.target_dep_set not in self.dep_set_m.keys():
            raise Exception("Dep-set %s is not present in project %s" % (
                self.target_dep_set, self.name))
        return self.dep_set_m[self.target_dep_set]
    
    def set_dep_set(self, name, ds):
        self.dep_set_m[name] = ds

    def add_dependency(self, dep):
        self.dependencies.append(dep)

    @staticmethod
    def mkFromProj(proj_dir : str) -> 'ProjInfo':
        ret : ProjInfo = None
        
        # First, see if this is a new-style project
        if os.path.isfile(os.path.join(proj_dir, "ivpm.yaml")):
            note("Reading ivpm.yaml from project %s" % proj_dir)
            path = os.path.join(proj_dir, "ivpm.yaml");
            with open(path, "r") as fp:
                ret = IvpmYamlReader().read(fp, path)
        else:
            # This doesn't appear to be an IVPM project
            # No IVPM-specific data to rely on here
            pass
        return ret

#    @property        
#    def deps(self):
#        return self.dependencies
