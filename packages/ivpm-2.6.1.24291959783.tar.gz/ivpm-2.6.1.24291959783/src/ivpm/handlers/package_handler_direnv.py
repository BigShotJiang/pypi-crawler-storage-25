#****************************************************************************
#* package_handler_direnv.py
#*
#* Copyright 2024 Matthew Ballance and Contributors
#*
#* Licensed under the Apache License, Version 2.0 (the "License"); you may
#* not use this file except in compliance with the License.  
#* You may obtain a copy of the License at:
#*
#*   http://www.apache.org/licenses/LICENSE-2.0
#*
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS, 
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
#* See the License for the specific language governing permissions and
#* limitations under the License.
#*
#****************************************************************************
import dataclasses as dc
import logging
import os
import toposort
from typing import Dict
from ..package import Package
from ..project_ops_info import ProjectUpdateInfo
from .package_handler import PackageHandler

_logger = logging.getLogger("ivpm.handlers.package_handler_direnv")

@dc.dataclass
class PackageHandlerDirenv(PackageHandler):
    name               = "direnv"
    description        = "Collects envrc files from packages and generates a combined packages.envrc"
    leaf_when          = None
    root_when          = None
    phase              = 0
    conditions_summary = "leaf: non-PyPI packages with export.envrc, or with direnv.envrc specified in package.with; root: only when at least one such package is present"

    @classmethod
    def handler_info(cls):
        from ..show.info_types import HandlerInfo
        return HandlerInfo(
            name=cls.name,
            description=cls.description,
            phase=cls.phase,
            conditions=cls.conditions_summary,
            notes=(
                "Generates packages/packages.envrc that sources each package's envrc in topological order. "
                "By default, only export.envrc is collected. A package can publish any envrc file by "
                "specifying package: { with: { direnv: { envrc: <relpath> } } } in its ivpm.yaml."
            ),
        )
    # package name -> (Package, envrc filename)
    envrc_pkgs: Dict[str, tuple] = dc.field(default_factory=dict)

    def reset(self):
        self.envrc_pkgs = {}

    def on_leaf_post_load(self, pkg: Package, update_info):
        """Record packages that publish an envrc file.

        The envrc file is chosen as follows:
        1. If the package's own ivpm.yaml specifies
           ``package: { with: { direnv: { envrc: <relpath> } } }``, that path
           is used (relative to the package root).
        2. Otherwise, only ``export.envrc`` is looked for automatically.
           A bare ``.envrc`` is intentionally not collected unless the package
           explicitly opts in via the config above.
        """
        if not hasattr(pkg, "path") or pkg.path is None:
            return
        if getattr(pkg, "src_type", None) == "pypi":
            return

        # Check whether the package's own ivpm.yaml declares an explicit envrc.
        explicit_envrc = None
        if pkg.proj_info is not None:
            direnv_cfg = pkg.proj_info.handler_configs.get("direnv")
            if isinstance(direnv_cfg, dict):
                explicit_envrc = direnv_cfg.get("envrc")

        if explicit_envrc is not None:
            candidate = explicit_envrc
            if os.path.isfile(os.path.join(pkg.path, candidate)):
                with self._lock:
                    self.envrc_pkgs[pkg.name] = (pkg, candidate)
                _logger.debug("Package %s exports %s (explicit)", pkg.name, candidate)
            else:
                _logger.warning(
                    "Package %s specifies direnv.envrc=%s but file not found",
                    pkg.name, candidate)
        else:
            # Default: only auto-collect export.envrc
            if os.path.isfile(os.path.join(pkg.path, "export.envrc")):
                with self._lock:
                    self.envrc_pkgs[pkg.name] = (pkg, "export.envrc")
                _logger.debug("Package %s has export.envrc", pkg.name)

    def on_root_post_load(self, update_info: ProjectUpdateInfo):
        if not self.envrc_pkgs:
            _logger.debug("No packages with envrc files; skipping packages.envrc generation")
            return

        # Build dependency map for topological sort (only among envrc packages)
        deps_m: Dict[str, set] = {}
        for pkg_name, (pkg, _) in self.envrc_pkgs.items():
            if pkg_name not in deps_m:
                deps_m[pkg_name] = set()

            if pkg.proj_info is not None:
                target = pkg.proj_info.target_dep_set
                if pkg.proj_info.has_dep_set(target):
                    for dep_name in pkg.proj_info.get_dep_set(target).keys():
                        if dep_name in self.envrc_pkgs:
                            dep_pkg, _ = self.envrc_pkgs[dep_name]
                            # Only add edge if this package resolved the dependency
                            if dep_pkg.resolved_by == pkg_name:
                                deps_m[pkg_name].add(dep_name)

        # Topological order: dependencies before dependents
        ordered = []
        for pkg_set in toposort.toposort(deps_m):
            for pkg_name in pkg_set:
                ordered.append(pkg_name)

        deps_dir = update_info.deps_dir
        output_path = os.path.join(deps_dir, "packages.envrc")

        _logger.debug("Writing packages.envrc to %s", output_path)

        with open(output_path, "w") as fp:
            fp.write("# Generated by IVPM — do not edit manually\n")
            for pkg_name in ordered:
                _, envrc_file = self.envrc_pkgs[pkg_name]
                fp.write("source_env ./%s/%s\n" % (pkg_name, envrc_file))

        from ..utils import note
        note("Generated packages.envrc with %d entries" % len(ordered))
