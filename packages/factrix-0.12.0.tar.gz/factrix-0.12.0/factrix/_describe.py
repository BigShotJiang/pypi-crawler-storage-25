"""v0.5 introspection helpers — `describe_analysis_modes` + `suggest_config`.

Both helpers reverse-query the registry SSOT (§4.4 A1) so the
"which cells exist" knowledge stays in one place. Plan §7.1 / §7.2.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from factrix._analysis_config import AnalysisConfig
from factrix._axis import FactorScope, Metric, Mode, Signal
from factrix._codes import WarningCode, cross_section_tier
from factrix._errors import IncompatibleAxisError
from factrix._evaluate import _derive_mode
from factrix._metric_index import user_facing_rows
from factrix._registry import (
    _DISPATCH_REGISTRY,
    _dispatch_key_for,
    _ScopeCollapsedSentinel,
)
from factrix._stats.constants import (
    MIN_ASSETS_WARN,
    MIN_PERIODS_HARD,
    MIN_PERIODS_WARN,
)

# Sparsity threshold above which `factor` is treated as an event series.
_SPARSITY_THRESHOLD: float = 0.5

# Canonical key set on ``SuggestConfigResult.detected``. Module-level so
# tests + future programmatic consumers can membership-check without
# duplicating the literal set; the dataclass docstring carries the
# per-key types/meanings.
DETECTED_KEYS: frozenset[str] = frozenset(
    {
        "scope",
        "signal",
        "mode",
        "n_assets",
        "n_periods",
        "sparsity",
    }
)


# ---------------------------------------------------------------------------
# describe_analysis_modes
# ---------------------------------------------------------------------------


def _user_facing_axis_tuples() -> list[tuple[FactorScope, Signal, Metric | None]]:
    """Distinct ``(scope, signal, metric)`` triples drawn from the registry.

    The sentinel-keyed entry expands to both ``INDIVIDUAL`` and
    ``COMMON`` because ``individual_sparse()`` and ``common_sparse()``
    are both legal user-facing constructions that converge at N=1
    (§5.4.1).
    """
    seen: set[tuple[FactorScope, Signal, Metric | None]] = set()
    for entry in _DISPATCH_REGISTRY.values():
        scope = entry.key.scope
        if isinstance(scope, _ScopeCollapsedSentinel):
            scopes: list[FactorScope] = [
                FactorScope.INDIVIDUAL,
                FactorScope.COMMON,
            ]
        else:
            scopes = [scope]
        for s in scopes:
            seen.add((s, entry.key.signal, entry.key.metric))

    def _sort_key(t: tuple[FactorScope, Signal, Metric | None]) -> tuple:
        return (
            t[0].value,
            t[1].value,
            t[2].value if t[2] is not None else "",
        )

    return sorted(seen, key=_sort_key)


def _entry_for(
    scope: FactorScope,
    signal: Signal,
    metric: Metric | None,
    mode: Mode,
) -> Any:
    """Return the registry entry routing this user-facing axis at ``mode``."""
    return _DISPATCH_REGISTRY.get(_dispatch_key_for(scope, signal, metric, mode))


def _stats_keys_for(entry: Any) -> list[str]:
    """Sorted ``.value`` strings for the procedure's possible-stats set.

    Pulled from ``FactorProcedure.EMITS_STATS`` (declared per-class at
    procedure-definition time). Returns the **possible-set** —
    always-emitted ∪ conditionally-emitted — so agents can branch on
    "is this gate reachable?" without running the procedure.
    """
    return sorted(s.value for s in entry.procedure.EMITS_STATS)


def _row_for_tuple(
    scope: FactorScope,
    signal: Signal,
    metric: Metric | None,
) -> dict[str, Any]:
    panel = _entry_for(scope, signal, metric, Mode.PANEL)
    timeseries = _entry_for(scope, signal, metric, Mode.TIMESERIES)
    return {
        "scope": scope.value,
        "signal": signal.value,
        "metric": metric.value if metric is not None else None,
        "panel": (
            {
                "use_case": panel.canonical_use_case,
                "references": list(panel.references),
                "stats_keys": _stats_keys_for(panel),
            }
            if panel is not None
            else None
        ),
        "timeseries": (
            {
                "use_case": timeseries.canonical_use_case,
                "references": list(timeseries.references),
                "scope_collapsed": (signal is Signal.SPARSE),
                "stats_keys": _stats_keys_for(timeseries),
            }
            if timeseries is not None
            else "raises ModeAxisError; see _FALLBACK_MAP"
        ),
    }


def _factory_call_for(
    scope: str,
    signal: str,
    metric: str | None,
) -> str:
    """Render the AnalysisConfig factory call for a `(scope, signal, metric)` row.

    UX-5 from review: ``describe_analysis_modes`` text output should
    answer "which factory do I call?" without forcing the reader to
    cross-reference the README factory table.
    """
    if scope == "individual" and signal == "continuous":
        m = "Metric.IC" if metric == "ic" else "Metric.FM"
        return f"AnalysisConfig.individual_continuous(metric={m})"
    if scope == "individual" and signal == "sparse":
        return "AnalysisConfig.individual_sparse()"
    if scope == "common" and signal == "continuous":
        return "AnalysisConfig.common_continuous()"
    if scope == "common" and signal == "sparse":
        return "AnalysisConfig.common_sparse()"
    return f"AnalysisConfig({scope=}, {signal=}, {metric=})"  # pragma: no cover


def _render_text(rows: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    for row in rows:
        header = f"({row['scope']}, {row['signal']}, {row['metric']})"
        lines.append(f"Cell: {header}")
        lines.append(
            f"  Factory: {_factory_call_for(row['scope'], row['signal'], row['metric'])}",
        )
        panel = row["panel"]
        if panel is None:
            lines.append("  PANEL: not registered")
        else:
            lines.append(f"  PANEL: {panel['use_case']}")
            if panel["references"]:
                lines.append(f"    refs: {'; '.join(panel['references'])}")
        ts = row["timeseries"]
        if isinstance(ts, str):
            lines.append(f"  TIMESERIES: {ts}")
        else:
            # A-8 from review: name what the TIMESERIES null actually tests
            # rather than implying parity with PANEL's cross-asset null.
            # Sparse TIMESERIES genuinely collapses the scope axis (sentinel
            # routes both INDIVIDUAL and COMMON sparse to one procedure);
            # continuous TIMESERIES is a single-series β whose null is
            # distinct from the cross-asset E[β]=0 of PANEL.
            if ts.get("scope_collapsed"):
                note = " — scope axis collapsed at N=1"
            else:
                note = " — single-series test (null differs from PANEL)"
            lines.append(
                f"  TIMESERIES: {ts['use_case']}{note}",
            )
            if ts["references"]:
                lines.append(f"    refs: {'; '.join(ts['references'])}")
        lines.append("")
    return "\n".join(lines).rstrip("\n")


def describe_analysis_modes(
    *,
    format: Literal["text", "json"] = "text",
) -> str | list[dict[str, Any]]:
    """Enumerate the legal analysis cells with PANEL / TIMESERIES routing notes.

    Iterates ``_DISPATCH_REGISTRY`` (single source of truth for "which
    cells exist") and groups by user-facing ``(scope, signal, metric)``
    so each row carries both ``PANEL`` and ``TIMESERIES`` information
    when registered. Plan §7.1.
    """
    rows = [_row_for_tuple(*t) for t in _user_facing_axis_tuples()]
    if format == "json":
        return rows
    return _render_text(rows)


# ---------------------------------------------------------------------------
# suggest_config
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SuggestConfigResult:
    """Auto-detected ``AnalysisConfig`` plus structured observations + reasoning.

    ``detected`` carries the **structured panel observations** that drove
    the suggestion (machine-readable; AI agents and pipeline gates branch
    on these without parsing strings). ``reasoning`` is the human-readable
    mirror of the same information per axis.

    ``warnings`` is a list of ``WarningCode`` enums — pre-computed
    evaluate-time warnings the user can act on before running the
    suggested config.

    ``detected`` keys (always present, type-stable):

    | Key                  | Type      | Meaning                                   |
    |----------------------|-----------|-------------------------------------------|
    | ``scope``            | str       | ``"individual"`` / ``"common"``           |
    | ``signal``           | str       | ``"continuous"`` / ``"sparse"``           |
    | ``mode``             | str       | ``"panel"`` / ``"timeseries"``            |
    | ``n_assets``         | int       | unique ``asset_id`` count                 |
    | ``n_periods``        | int       | unique ``date`` count                     |
    | ``sparsity``         | float     | zero-ratio in ``factor`` column           |
    """

    suggested: AnalysisConfig
    detected: dict[str, Any]
    reasoning: dict[str, str]
    warnings: list[WarningCode] = field(default_factory=list)

    def diagnose(self) -> dict[str, Any]:
        """JSON-shaped view, symmetric with ``FactorProfile.diagnose()``.

        Python callers continue to read ``.warnings`` as a list of
        ``WarningCode`` enums. Cross-wire / log / agent consumers call
        ``diagnose()`` to get a fully serialisable dict where
        ``warnings`` is a sorted list of ``.value`` strings (matching
        the shape produced by ``FactorProfile.diagnose()``).

        Returns:
            A plain-Python dict with the suggested config serialised
            via ``AnalysisConfig.to_dict()``, the detected observations,
            the per-axis reasoning strings, and warnings as a sorted
            list of ``.value`` strings.
        """
        return {
            "suggested": self.suggested.to_dict(),
            "detected": dict(self.detected),
            "reasoning": dict(self.reasoning),
            "warnings": sorted(w.value for w in self.warnings),
        }


def _detect_signal(raw: Any) -> tuple[Signal, str, float]:
    """Sparsity ratio in ``factor`` ≥ 0.5 → SPARSE, else CONTINUOUS.

    Returns ``(signal, reason, sparsity)`` where ``sparsity`` is the
    zero-ratio in the factor column, surfaced on
    ``SuggestConfigResult.detected`` so callers can branch on the raw
    observation rather than re-deriving it from the panel.
    """
    import math

    n = len(raw)
    if n == 0:
        # nan, not 0.0 — there is no zero-ratio with zero observations.
        # Reporting 0.0 would falsely imply "fully dense".
        return (
            Signal.CONTINUOUS,
            "factor column empty: defaulting to CONTINUOUS",
            math.nan,
        )
    n_zero = int((raw["factor"] == 0).sum())
    sparsity = n_zero / n
    signal = Signal.SPARSE if sparsity >= _SPARSITY_THRESHOLD else Signal.CONTINUOUS
    reason = (
        f"sparsity ratio = {sparsity:.2f} "
        f"(threshold {_SPARSITY_THRESHOLD}): → {signal.value.upper()}"
    )
    return signal, reason, sparsity


def _detect_scope(raw: Any) -> tuple[FactorScope, str]:
    """COMMON if factor is constant per date across assets, else INDIVIDUAL."""
    import polars as pl

    n_assets = int(raw["asset_id"].n_unique())
    if n_assets <= 1:
        return (
            FactorScope.COMMON,
            f"n_assets = {n_assets}: scope axis trivially COMMON at N=1",
        )
    per_date_unique = raw.group_by("date").agg(
        pl.col("factor").n_unique().alias("n_unique_per_date")
    )
    is_broadcast = bool(
        (per_date_unique["n_unique_per_date"] == 1).all(),
    )
    decision = "COMMON" if is_broadcast else "INDIVIDUAL"
    return (
        FactorScope.COMMON if is_broadcast else FactorScope.INDIVIDUAL,
        f"factor varies across assets at given date: "
        f"{'NO' if is_broadcast else 'YES'} → {decision}",
    )


def _build_suggested(
    scope: FactorScope,
    signal: Signal,
    *,
    forward_periods: int,
) -> AnalysisConfig:
    if signal is Signal.SPARSE:
        if scope is FactorScope.INDIVIDUAL:
            return AnalysisConfig.individual_sparse(
                forward_periods=forward_periods,
            )
        return AnalysisConfig.common_sparse(forward_periods=forward_periods)
    if scope is FactorScope.INDIVIDUAL:
        return AnalysisConfig.individual_continuous(
            metric=Metric.IC,
            forward_periods=forward_periods,
        )
    return AnalysisConfig.common_continuous(forward_periods=forward_periods)


def _estimate_common_panel_inference_n(raw: Any) -> int:
    """Mirror ``compute_ts_betas``' MIN_TS_OBS filter for the suggest_config preview.

    Row-aligned non-null on ``(factor, forward_return)`` is a close
    approximation; ``compute_ts_betas`` itself drops nulls per column
    independently then takes ``min(len)`` positionally — equivalent on
    aligned panels, mildly tighter when nulls are non-overlapping.
    Falls back to factor-only if ``forward_return`` is not yet present.
    """
    import polars as pl

    from factrix.metrics.ts_beta import MIN_TS_OBS

    cond = pl.col("factor").is_not_null()
    if "forward_return" in raw.columns:
        cond = cond & pl.col("forward_return").is_not_null()
    counts = raw.filter(cond).group_by("asset_id").len()
    if len(counts) == 0:
        return 0
    return int((counts["len"] >= MIN_TS_OBS).sum())


def suggest_config(
    raw: Any,
    *,
    forward_periods: int = 5,
) -> SuggestConfigResult:
    """Inspect ``raw`` and propose an ``AnalysisConfig`` with reasoning.

    Plan §7.2: this is a *suggestion* — never auto-applied. The
    caller (or an AI agent) reads ``reasoning`` and ``warnings`` to
    decide whether to override.
    """
    signal, signal_reason, sparsity = _detect_signal(raw)
    scope, scope_reason = _detect_scope(raw)

    n_assets = int(raw["asset_id"].n_unique())
    n_periods = int(raw["date"].n_unique())
    mode = _derive_mode(raw)

    mode_reason = (
        f"n_assets = {n_assets} detected → "
        f"{'TIMESERIES' if mode is Mode.TIMESERIES else 'PANEL'}"
    )
    if mode is Mode.PANEL and scope is FactorScope.COMMON:
        n_inference = _estimate_common_panel_inference_n(raw)
    else:
        n_inference = n_assets
    n_tier = cross_section_tier(n_inference) if mode is Mode.PANEL else None
    if n_tier is not None:
        if n_inference != n_assets:
            mode_reason += (
                f" (post-MIN_TS_OBS filter n_inference = {n_inference} "
                f"< MIN_ASSETS_WARN = {MIN_ASSETS_WARN}; union n_assets "
                f"= {n_assets} would be optimistic — see "
                f"WarningCode.{n_tier.name})"
            )
        else:
            mode_reason += (
                f" (n_inference = {n_inference} < MIN_ASSETS_WARN = "
                f"{MIN_ASSETS_WARN} → cross-asset df low, see "
                f"WarningCode.{n_tier.name})"
            )

    suggested = _build_suggested(scope, signal, forward_periods=forward_periods)

    if suggested.metric is None:
        if scope is FactorScope.COMMON:
            metric_reason = "scope=COMMON: metric axis collapsed (no IC/FM choice)"
        else:
            metric_reason = "signal=SPARSE: metric axis collapsed (no IC/FM choice)"
    else:
        metric_reason = (
            f"scope=INDIVIDUAL × signal=CONTINUOUS: defaulting metric="
            f"{suggested.metric.value.upper()} (rank predictive ordering)"
        )

    reasoning = {
        "scope": scope_reason,
        "signal": signal_reason,
        "metric": metric_reason,
        "mode": mode_reason,
    }

    warnings: list[WarningCode] = []
    if mode is Mode.TIMESERIES and MIN_PERIODS_HARD <= n_periods < MIN_PERIODS_WARN:
        warnings.append(WarningCode.UNRELIABLE_SE_SHORT_PERIODS)
    if n_tier is not None:
        warnings.append(n_tier)

    detected: dict[str, Any] = {
        "scope": scope.value,
        "signal": signal.value,
        "mode": mode.value,
        "n_assets": n_assets,
        "n_periods": n_periods,
        "sparsity": sparsity,
    }

    return SuggestConfigResult(
        suggested=suggested,
        detected=detected,
        reasoning=reasoning,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# list_metrics
# ---------------------------------------------------------------------------


def list_metrics(
    scope: FactorScope,
    signal: Signal,
    *,
    format: Literal["text", "json"] = "text",
    with_import: bool = False,
) -> list[str] | list[dict[str, Any]]:
    """Return standalone metrics applicable to ``(scope, signal)``.

    Mode is intentionally not an input — applicability does not change
    across PANEL / TIMESERIES (per ``docs/reference/metric-applicability.md``).
    Source of truth is the ``Matrix-row:`` tag in each metric module's
    docstring, parsed by :mod:`factrix._metric_index`.

    Parameters
    ----------
    scope, signal
        Cell axes to filter on.
    format
        ``"text"`` (default) returns metric names sorted by
        ``(module, name)``. ``"json"`` returns ``list[dict]`` rows with
        keys ``name``, ``module``, ``cell``, ``agg_order``,
        ``inference_se``, ``import_path``, ``input_kind``,
        ``docs_anchor``, ``emitted_name`` — JSON-serialisable, suitable
        for tooling. ``docs_anchor`` follows
        :data:`factrix._metric_index.DOCS_ANCHOR_FMT` (a docs-root-relative
        path + mkdocstrings symbol fragment).
        ``emitted_name`` is the literal ``MetricOutput.name`` value at
        runtime — usually equal to ``name`` (the function name), but
        differs for a small set of historical exceptions. Consumers
        holding a ``MetricOutput`` should resolve via ``emitted_name``.
    with_import
        ``"text"`` only. When ``True``, returns a two-column
        ``"name → factrix.metrics.<module>"`` list so each row is
        copy-paste-ready into ``from factrix.metrics import <name>``.
        Ignored under ``format="json"`` (the ``import_path`` field is
        always present there).

    Raises
    ------
    IncompatibleAxisError
        ``(scope, signal)`` matches no registered metric. In practice
        all four combos are populated, so this is defensive.

    Notes
    -----
    Filter ``input_kind == "panel"`` on the JSON form to find candidates
    for the date-slicing dispatcher :func:`factrix.by_slice`; ``"scalar"``
    rows (``breakeven_cost``, ``net_spread``) consume pre-aggregated
    scalars and are not eligible.
    """
    rows = [r for r in user_facing_rows() if r.cell.matches(scope, signal)]
    if not rows:
        raise IncompatibleAxisError(
            f"no standalone metrics registered for "
            f"(scope={scope.value}, signal={signal.value})"
        )
    if format == "json":
        return [
            {
                "name": r.name,
                "module": r.module,
                "cell": r.cell.raw,
                "agg_order": r.agg_order,
                "inference_se": r.inference_se,
                "import_path": r.import_path,
                "input_kind": r.input_kind,
                "docs_anchor": r.docs_anchor,
                "emitted_name": r.emitted_name,
            }
            for r in rows
        ]
    if with_import:
        width = max(len(r.name) for r in rows)
        return [f"{r.name:<{width}} → {r.import_path}" for r in rows]
    return [r.name for r in rows]


# ---------------------------------------------------------------------------
# list_estimators (#170)
# ---------------------------------------------------------------------------


def list_estimators(
    scope: FactorScope,
    signal: Signal,
    *,
    format: Literal["text", "json"] = "text",
    with_import: bool = False,
) -> list[str] | list[dict[str, Any]]:
    """Return Estimator instances applicable to ``(scope, signal)``.

    Mirrors :func:`list_metrics` shape so callers can build a single
    pre-flight pattern: ``list_metrics`` says which scalars a cell can
    emit, ``list_estimators`` says which inference methods can drive
    family-verb ``estimator=`` for that cell. Mode is intentionally
    not an input — Estimator applicability is not mode-dependent.

    Parameters
    ----------
    scope, signal
        Cell axes to filter on.
    format
        ``"text"`` (default) returns Estimator names sorted
        alphabetically. ``"json"`` returns ``list[dict]`` rows with
        keys ``name``, ``description``, ``import_path``.
    with_import
        ``"text"`` only. When ``True``, returns ``"name → import_path"``
        two-column lines so each row is copy-paste-ready into
        ``from factrix.stats import <name>``. Ignored under JSON
        (``import_path`` is always present there).

    Raises
    ------
    IncompatibleAxisError
        ``(scope, signal)`` matches no registered Estimator. ``NeweyWest``
        applies to every user-facing cell, so as long as it stays in the
        registry this branch is defensive.
    """
    from factrix.stats import _ESTIMATOR_REGISTRY

    matches = [e for e in _ESTIMATOR_REGISTRY if e.applicable_to(scope, signal)]
    if not matches:
        raise IncompatibleAxisError(
            f"no estimators applicable to (scope={scope.value}, signal={signal.value})"
        )

    matches.sort(key=lambda e: e.name)

    rows = [
        {
            "name": e.name,
            "description": e.description,
            "import_path": f"factrix.stats.{type(e).__name__}",
        }
        for e in matches
    ]
    if format == "json":
        return rows
    if with_import:
        width = max(len(r["name"]) for r in rows)
        return [f"{r['name']:<{width}} → {r['import_path']}" for r in rows]
    return [r["name"] for r in rows]
