"""
alphainfo SDK — Synchronous and Async Clients

Production-grade Python client for the alphainfo Structural Intelligence API.
Supports all endpoints with automatic retry, rate limit tracking, and typed responses.

Example (sync):
    >>> from alphainfo import AlphaInfo
    >>> client = AlphaInfo(api_key="ai_xxxxxxxxxxxxx")
    >>> result = client.analyze(signal=[...], sampling_rate=250.0)
    >>> print(result.structural_score, result.confidence_band)

Example (async):
    >>> from alphainfo import AsyncAlphaInfo
    >>> async with AsyncAlphaInfo(api_key="ai_xxx") as client:
    ...     result = await client.analyze(signal=[...], sampling_rate=250.0)
"""

import asyncio
import time
from typing import Any, Dict, List, Optional
import warnings
import weakref

import httpx

from .exceptions import (
    APIError,
    AuthError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .exceptions import (
    TimeoutError as SDKTimeoutError,
)
from .models import (
    MIN_FINGERPRINT_SAMPLES,
    MIN_FINGERPRINT_SAMPLES_WITH_BASELINE,
    AnalysisResult,
    AuditReplay,
    AuditSummary,
    BatchItemResult,
    BatchResult,
    ChannelResult,
    FingerprintResult,
    HealthStatus,
    MatrixResult,
    PlanInfo,
    RateLimitInfo,
    SemanticResult,
    VectorResult,
)


def _warn_if_too_short_for_fingerprint(
    signal: List[float], baseline: Optional[List[float]]
) -> None:
    """Emit a UserWarning before a likely-incomplete fingerprint call.

    The engine needs at least ``MIN_FINGERPRINT_SAMPLES`` samples (or
    ``MIN_FINGERPRINT_SAMPLES_WITH_BASELINE`` when a baseline of
    comparable length is supplied) to produce a full 5D fingerprint.
    Below that, ``fingerprint_available`` comes back False and the
    caller's retry / ANN-index pipeline has wasted one round-trip.
    Warn at call-time so the caller can switch to ``analyze()`` or
    skip the signal before the HTTP request.
    """
    n = len(signal)
    threshold = (
        MIN_FINGERPRINT_SAMPLES_WITH_BASELINE
        if baseline is not None
        else MIN_FINGERPRINT_SAMPLES
    )
    if n >= threshold:
        return
    qualifier = "with baseline" if baseline is not None else "without baseline"
    warnings.warn(
        f"Signal has {n} samples; the 5D fingerprint needs \u2265{threshold} "
        f"{qualifier}. The response will most likely come back with "
        f"fingerprint_available=False (reason='signal_too_short'). "
        f"Use client.analyze() for shorter signals.",
        UserWarning,
        stacklevel=3,
    )


def _validate_signal_quality(
    signal: List[float],
    *,
    arg_name: str = "signal",
    skip_warnings: bool = False,
) -> None:
    """Catch common signal-quality pitfalls before the round-trip.

    Each error message names a recipe or helper that addresses the
    specific failure mode \u2014 so the user gets pointed at the right tool
    instead of having to read docs cold. The eval doc (Prio Alta #2)
    explicitly asked for "validadores que apontem para recipes".

    Hard errors (raise ValidationError):
      - signal is None / not iterable / bytes / bytearray
      - signal contains a non-numeric element
      - signal length is 0 (engine rejects, but failing here is faster)
      - signal contains ANY NaN / Inf \u2014 JSON can't serialise them, so
        they have to go before the round-trip; the message names the
        recipe + the one-line filter / interpolate fix
      - constant signal is now a UserWarning, not an error (the engine
        handles a stuck reading gracefully \u2014 see below)

    Warnings (UserWarning, only when skip_warnings=False):
      - very short signal (<32 samples) \u2014 engine still runs but scores
        are unreliable
      - very few unique values (<20 across 50+ samples) \u2014 looks
        categorical, recipes.event_grammar is more appropriate
      - constant signal \u2014 degenerate but the engine handles it
        gracefully; the warning points at the right recipe instead of
        breaking legitimate use cases (e.g. detecting stuck sensors)
    """
    if signal is None:
        raise ValidationError(
            f"{arg_name} is None. Pass a list of floats \u2014 for empty / "
            f"missing data see recipes.encoding_guide.discover_encoding "
            f"to pick the right preprocessing."
        )

    # bytes / bytearray "look like" sequences (have len, are iterable),
    # but they iterate as ints in 0-255 and cannot be JSON-serialised
    # by httpx. Reject them with a clear message before the user hits a
    # cryptic ValueError downstream. Native input to the API is JSON
    # numeric arrays \u2014 bytes / strings / structured data go through
    # an encoder first.
    if isinstance(signal, (bytes, bytearray)):
        raise ValidationError(
            f"{arg_name} is {type(signal).__name__}. Native API input is "
            f"a JSON array of numbers \u2014 convert raw bytes via "
            f"`np.frombuffer(...).tolist()` first, or use "
            f"recipes.encoding_guide.discover_encoding to pick the "
            f"right encoding for binary data."
        )

    try:
        n = len(signal)
    except TypeError:
        raise ValidationError(
            f"{arg_name} must be a sequence of numbers (got "
            f"{type(signal).__name__}). For nested / structured data see "
            f"recipes.schema_drift (JSON) or recipes.event_grammar (token "
            f"sequences)."
        )

    if n == 0:
        raise ValidationError(
            f"{arg_name} is empty (0 samples). Engine minimum is 10. "
            f"For very short or sparse data see recipes.event_grammar "
            f"(n-gram encoding) or recipes.encoding_guide.discover_encoding."
        )

    # Try a vectorised pass for speed when numpy is around;
    # fall back to pure-python loops otherwise (we don't ship numpy).
    n_finite = 0
    n_nan = 0
    smin = float("inf")
    smax = float("-inf")
    sum_v = 0.0
    sum_sq = 0.0
    seen_first = False
    first_val = 0.0
    all_constant = True
    for x in signal:
        try:
            f = float(x)
        except (TypeError, ValueError):
            raise ValidationError(
                f"{arg_name} contains non-numeric value {x!r}. Convert "
                f"to floats first; for token / categorical data see "
                f"recipes.event_grammar."
            )
        if f != f:  # NaN \u2014 fastest pure-python check
            n_nan += 1
            continue
        if f == float("inf") or f == float("-inf"):
            n_nan += 1  # treat Inf as bad too
            continue
        n_finite += 1
        if not seen_first:
            first_val = f
            seen_first = True
        elif f != first_val:
            all_constant = False
        if f < smin:
            smin = f
        if f > smax:
            smax = f
        sum_v += f
        sum_sq += f * f

    if n_finite == 0:
        raise ValidationError(
            f"{arg_name} is all NaN/Inf ({n_nan}/{n} bad samples). "
            f"Filter or impute first \u2014 see recipes.encoding_guide for "
            f"missing-data preprocessing patterns."
        )

    # Partial NaN / Inf is a hard error too. JSON serialisation rejects
    # them ("Out of range float values are not JSON compliant") with a
    # cryptic ValueError that comes back as a ValidationError-without-
    # context to the user. Catching it here gives a recipe pointer
    # before the round-trip and makes the failure mode obvious.
    if n_nan > 0:
        raise ValidationError(
            f"{arg_name} contains {n_nan}/{n} NaN/Inf samples. JSON "
            f"can't serialise these \u2014 filter or impute before sending. "
            f"For missing-data preprocessing patterns see "
            f"recipes.encoding_guide. Quick fix: "
            f"`signal = [x for x in signal if math.isfinite(x)]` (drop) "
            f"or interpolate via `pandas.Series(signal).interpolate()`."
        )

    if skip_warnings:
        return

    # Constant signal: warn, don't error. The engine handles it
    # gracefully (returns score=0 or a low-confidence band) and there
    # are legitimate cases where a temporarily-flat reading is the
    # right input (e.g. a stuck sensor that the user is trying to
    # detect by comparing to a varying baseline).
    if all_constant or smax == smin:
        warnings.warn(
            f"{arg_name} is constant (every sample is {first_val}). "
            f"There's no internal structure to compare; the score will "
            f"likely come back as 'no signal' or low confidence. If "
            f"this is a sensor reading and you're checking for stuck "
            f"instrumentation, run with a varying baseline. For token / "
            f"categorical data see recipes.event_grammar.",
            UserWarning,
            stacklevel=3,
        )

    # Warning thresholds \u2014 these still allow the call to proceed.
    if n < 32:
        warnings.warn(
            f"{arg_name} has only {n} samples. Engine minimum is 10 but "
            f"scores below 32 samples are unreliable; 200+ recommended. "
            f"For short / sparse data see recipes.encoding_guide for "
            f"intent='local_anomaly' patterns.",
            UserWarning,
            stacklevel=3,
        )

    # (Partial NaN/Inf already rejected above as a hard error.)

    if n >= 50:
        # Cheap categorical-likeness check: count unique rounded values.
        # SDK is single-dep (httpx); use a pure-python set
        # operation \u2014 O(n) and fine for typical signal sizes.
        try:
            uniq = len({round(float(x), 6) for x in signal if x == x})
            if uniq < 20:
                warnings.warn(
                    f"{arg_name} has only {uniq} unique values across "
                    f"{n} samples \u2014 looks categorical, not continuous. "
                    f"Consider recipes.event_grammar for n-gram / "
                    f"transition encoding instead of structural analysis.",
                    UserWarning,
                    stacklevel=3,
                )
        except (TypeError, ValueError):
            pass  # already caught above; just don't crash the validator

__all__ = ["AlphaInfo", "AsyncAlphaInfo"]

_SDK_VERSION = "1.5.23"

# ---------------------------------------------------------------------------
# HTTP/2 auto-detection
# ---------------------------------------------------------------------------

try:
    import h2  # noqa: F401
    _H2_AVAILABLE = True
except ImportError:
    _H2_AVAILABLE = False


def _resolve_http2(http2: Optional[bool]) -> bool:
    """Resolve http2 flag: explicit value wins, otherwise auto-detect h2 package."""
    if http2 is not None:
        return http2
    return _H2_AVAILABLE


def _build_url(base_url: str, endpoint: str) -> str:
    """Build full URL safely."""
    base = base_url.rstrip("/")
    path = endpoint if endpoint.startswith("/") else f"/{endpoint}"
    return f"{base}{path}"


# ---------------------------------------------------------------------------
# Response handling (shared)
# ---------------------------------------------------------------------------

def _handle_error_response(response: httpx.Response) -> None:
    """Raise typed exception for non-2xx responses."""
    status = response.status_code

    try:
        data = response.json()
    except Exception:
        data = {}

    if status == 401:
        raise AuthError(
            "Invalid or missing API key. "
            "Get a free key at https://www.alphainfo.io/register and pass it as "
            "AlphaInfo(api_key='ai_...').",
            status_code=401,
            response_data=data,
        )

    if status == 400:
        detail = data.get("detail", "Bad request")
        msg = detail if isinstance(detail, str) else str(detail)
        raise ValidationError(f"Validation error: {msg}", status_code=400, response_data=data)

    if status == 413:
        detail = data.get("detail", {})
        msg = detail.get("message", "Signal too large") if isinstance(detail, dict) else str(detail)
        raise ValidationError(f"Payload too large: {msg}", status_code=413, response_data=data)

    if status == 404:
        detail = data.get("detail", "Not found")
        raise NotFoundError(str(detail), status_code=404, response_data=data)

    if status == 429:
        retry_after = int(response.headers.get("Retry-After", "60"))
        detail = data.get("detail", {})
        if isinstance(detail, dict):
            msg = detail.get("message", "Rate limit exceeded")
        else:
            msg = str(detail)
        raise RateLimitError(
            msg, status_code=429,
            retry_after=retry_after, response_data=data,
        )

    if status >= 500:
        detail = data.get("detail", "Internal server error")
        raise APIError(f"Server error: {detail}", status_code=status, response_data=data)

    if status >= 400:
        raise APIError(f"HTTP {status}", status_code=status, response_data=data)


def _extract_rate_limit(headers: httpx.Headers) -> Optional[RateLimitInfo]:
    """Extract rate limit info from response headers."""
    try:
        limit = int(headers.get("x-ratelimit-limit", "0"))
        if limit > 0:
            return RateLimitInfo(
                limit=limit,
                remaining=int(headers.get("x-ratelimit-remaining", "0")),
                reset=int(headers.get("x-ratelimit-reset", "0")),
            )
    except (ValueError, TypeError):
        pass
    return None


# ---------------------------------------------------------------------------
# Result parsers (shared between sync and async)
# ---------------------------------------------------------------------------

def _parse_semantic(raw: Any) -> Optional[SemanticResult]:
    """Parse semantic dict into SemanticResult dataclass."""
    if raw is None or not isinstance(raw, dict):
        return None
    _known = {"summary", "alert_level", "recommended_action", "trend", "severity", "severity_score"}
    return SemanticResult(
        summary=raw.get("summary", ""),
        alert_level=raw.get("alert_level", "normal"),
        recommended_action=raw.get("recommended_action"),
        trend=raw.get("trend"),
        severity=raw.get("severity"),
        severity_score=raw.get("severity_score"),
        details={k: v for k, v in raw.items() if k not in _known} or None,
    )


def _parse_analysis(data: Dict[str, Any]) -> AnalysisResult:
    return AnalysisResult(
        structural_score=data["structural_score"],
        change_detected=data["change_detected"],
        change_score=data["change_score"],
        confidence_band=data["confidence_band"],
        engine_version=data["engine_version"],
        analysis_id=data["analysis_id"],
        metrics=data.get("metrics"),
        provenance=data.get("provenance"),
        semantic=_parse_semantic(data.get("semantic")),
        warning=data.get("warning"),
        # 1.5.12+: server always returns domain_applied, and domain_inference
        # only when the caller asked for "auto". Fall back to None for older
        # servers (and so the SDK is forward-compatible with any response).
        domain_applied=data.get("domain_applied"),
        domain_inference=data.get("domain_inference"),
    )


def _parse_batch(data: Dict[str, Any]) -> BatchResult:
    items: List[BatchItemResult] = []
    for r in data.get("results", []):
        items.append(BatchItemResult(
            index=r.get("index", len(items)),
            structural_score=r.get("structural_score"),
            change_detected=r.get("change_detected"),
            change_score=r.get("change_score"),
            confidence_band=r.get("confidence_band"),
            engine_version=r.get("engine_version"),
            analysis_id=r.get("analysis_id"),
            metrics=r.get("metrics"),
            semantic=_parse_semantic(r.get("semantic")),
            error=r.get("error"),
        ))
    return BatchResult(
        results=items,
        analyses_consumed=data.get("analyses_consumed", len(items)),
        total_signals=data.get("total_signals", len(items)),
    )


def _parse_vector(data: Dict[str, Any]) -> VectorResult:
    channels: Dict[str, ChannelResult] = {}
    for name, ch in data.get("channels", {}).items():
        channels[name] = ChannelResult(
            name=name,
            structural_score=ch.get("structural_score"),
            change_detected=ch.get("change_detected"),
            change_score=ch.get("change_score"),
            confidence_band=ch.get("confidence_band"),
            engine_version=ch.get("engine_version"),
            error=ch.get("error"),
        )
    return VectorResult(
        analysis_id=data["analysis_id"],
        structural_score=data["structural_score"],
        change_detected=data["change_detected"],
        change_score=data.get("change_score", 0.0),
        n_channels=data.get("n_channels", len(channels)),
        channels=channels,
        confidence_band=data.get("confidence_band"),
        analyses_consumed=data.get("analyses_consumed", 1),
        semantic=_parse_semantic(data.get("semantic")),
        warning=data.get("warning"),
    )


def _parse_audit_replay(data: Dict[str, Any]) -> AuditReplay:
    params = data.get("parameters", {})
    # sampling_rate lives inside parameters; fall back to top-level for compat
    sampling_rate = data.get("sampling_rate") or params.get("sampling_rate", 0.0)
    return AuditReplay(
        analysis_id=data["analysis_id"],
        timestamp=data["timestamp"],
        signal_length=data.get("signal_length", data.get("n_samples", 0)),
        sampling_rate=float(sampling_rate),
        parameters=params,
        output=data.get("output", {}),
        engine_version=data.get("engine_version", ""),
        client_id=data.get("client_id"),
        request_id=data.get("request_id"),
    )


def _parse_matrix(data: Dict[str, Any]) -> MatrixResult:
    """Parse matrix response."""
    return MatrixResult(
        matrix=data["matrix"],
        labels=data.get("labels", []),
        n_signals=data["n_signals"],
        n_pairs=data["n_pairs"],
        analyses_consumed=data["analyses_consumed"],
        errors=data.get("errors"),
    )


def _parse_health(data: Dict[str, Any]) -> HealthStatus:
    """Parse health response."""
    return HealthStatus(
        status=data["status"],
        version=data["version"],
        message=data.get("message", ""),
    )


def _parse_plans(data: Any) -> List[PlanInfo]:
    """Parse plans response."""
    items = data.get("plans", []) if isinstance(data, dict) else data
    return [
        PlanInfo(
            id=p["id"],
            name=p["name"],
            slug=p["slug"],
            price_cents=p["price_cents"],
            currency=p.get("currency", "USD"),
            monthly_limit=p.get("monthly_limit", 0),
            features=p.get("features"),
            stripe_price_id=p.get("stripe_price_id"),
        )
        for p in items
    ]


def _parse_fingerprint(data: Dict[str, Any]) -> FingerprintResult:
    """Parse analysis response into a FingerprintResult (5D vector + status)."""
    metrics = data.get("metrics") or {}

    # Preserve nulls from the server. If a sim_* field is missing or None
    # we pass None through — callers must not treat absence as zero
    # divergence. See fingerprint_available / fingerprint_reason for the
    # structured status of each decomposition.
    sim_local = metrics.get("sim_local")
    sim_spectral = metrics.get("sim_spectral")
    sim_fractal = metrics.get("sim_fractal")
    sim_transition = metrics.get("sim_transition")
    sim_trend = metrics.get("sim_trend")

    # Derive availability and reason from the server fields when present.
    # Older responses without the new contract fall back to checking whether
    # all five sim_* values are non-None.
    has_flag = "fingerprint_available" in metrics
    if has_flag:
        fingerprint_available = bool(metrics.get("fingerprint_available"))
        fingerprint_reason = metrics.get("fingerprint_reason")
    else:
        fingerprint_available = all(
            v is not None
            for v in (sim_local, sim_spectral, sim_fractal, sim_transition, sim_trend)
        )
        fingerprint_reason = None if fingerprint_available else "internal_error"

    return FingerprintResult(
        analysis_id=data["analysis_id"],
        structural_score=data["structural_score"],
        confidence_band=data["confidence_band"],
        sim_local=sim_local,
        sim_spectral=sim_spectral,
        sim_fractal=sim_fractal,
        sim_transition=sim_transition,
        sim_trend=sim_trend,
        fingerprint_available=fingerprint_available,
        fingerprint_reason=fingerprint_reason,
    )


def _parse_audit_list(data: Any) -> List[AuditSummary]:
    """Parse audit list response."""
    items = data if isinstance(data, list) else data.get("analyses", [])
    return [
        AuditSummary(
            analysis_id=a.get("analysis_id") or a.get("id", ""),
            timestamp=a.get("timestamp", ""),
            signal_length=a.get("signal_length", 0),
            domain=a.get("domain"),
            structural_score=a.get("structural_score"),
            change_detected=a.get("change_detected"),
        )
        for a in items
    ]


# ---------------------------------------------------------------------------
# Payload builders (shared between sync and async)
# ---------------------------------------------------------------------------

def _build_analyze_payload(
    signal: List[float],
    sampling_rate: float,
    domain: str,
    baseline: Optional[List[float]],
    metadata: Optional[Dict[str, Any]],
    include_semantic: bool,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build analyze payload."""
    _validate_signal_quality(signal, arg_name="signal")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    if baseline is not None:
        # Baselines get the same quality checks but suppress the
        # "looks categorical" / "very short" UserWarnings — those are
        # already loud on the signal itself.
        _validate_signal_quality(
            baseline, arg_name="baseline", skip_warnings=True
        )
    payload: Dict[str, Any] = {
        "signal": signal,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "include_semantic": include_semantic,
        "use_multiscale": use_multiscale,
    }
    if baseline is not None:
        payload["baseline"] = baseline
    if metadata is not None:
        payload["metadata"] = metadata
    return payload


def _build_batch_payload(
    signals: List[List[float]],
    sampling_rate: float,
    domain: str,
    baselines: Optional[List[Optional[List[float]]]],
    include_semantic: bool,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build batch payload."""
    if not signals:
        raise ValidationError("signals list cannot be empty")
    if len(signals) > 100:
        raise ValidationError("Maximum 100 signals per batch")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    if baselines is not None and len(baselines) != len(signals):
        raise ValidationError(
            f"baselines length ({len(baselines)}) must match "
            f"signals length ({len(signals)})"
        )
    payload: Dict[str, Any] = {
        "signals": signals,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "include_semantic": include_semantic,
        "use_multiscale": use_multiscale,
    }
    if baselines is not None:
        payload["baselines"] = baselines
    return payload


def _build_matrix_payload(
    signals: List[List[float]],
    sampling_rate: float,
    domain: str,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build matrix payload."""
    if len(signals) < 2:
        raise ValidationError("Need at least 2 signals for matrix")
    if len(signals) > 50:
        raise ValidationError("Maximum 50 signals per matrix request")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    return {
        "signals": signals,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "use_multiscale": use_multiscale,
    }


def _build_vector_payload(
    channels: Dict[str, List[float]],
    sampling_rate: float,
    domain: str,
    baselines: Optional[Dict[str, List[float]]],
    include_semantic: bool,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build vector payload."""
    if not channels:
        raise ValidationError("channels cannot be empty")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    if baselines is not None:
        unknown = set(baselines.keys()) - set(channels.keys())
        if unknown:
            raise ValidationError(f"Baseline keys {sorted(unknown)} don't match any channel")
    payload: Dict[str, Any] = {
        "channels": channels,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "include_semantic": include_semantic,
        "use_multiscale": use_multiscale,
    }
    if baselines is not None:
        payload["baselines"] = baselines
    return payload


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------

class AlphaInfo:
    """
    Synchronous client for the alphainfo Structural Intelligence API.

    Args:
        api_key: Your API key (starts with 'ai_').
        base_url: API base URL (default: https://www.alphainfo.io).
        timeout: Default request timeout in seconds.
        max_retries: Maximum retries on transient failures (5xx, timeouts, rate limits).
        retry_base_delay: Base delay (seconds) for exponential backoff (default: 1.0).
        retry_max_delay: Maximum delay (seconds) between retries (default: 32.0).
        http2: Enable HTTP/2. Auto-detected if h2 package is installed.
            Install with: pip install alphainfo[http2]

    Usage:
        >>> client = AlphaInfo(api_key="ai_your_key")
        >>> result = client.analyze([1.0, 2.0, 3.0, ...], sampling_rate=250.0)
        >>> print(result.confidence_band)  # 'stable', 'transition', or 'unstable'
    """

    DEFAULT_BASE_URL = "https://www.alphainfo.io"
    DEFAULT_TIMEOUT = 30.0
    ANALYZE_TIMEOUT = 60.0
    HEALTH_TIMEOUT = 10.0
    MAX_RETRIES = 3
    RETRY_BASE_DELAY = 1.0
    RETRY_MAX_DELAY = 32.0

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
        retry_base_delay: float = RETRY_BASE_DELAY,
        retry_max_delay: float = RETRY_MAX_DELAY,
        http2: Optional[bool] = None,
    ):
        if not api_key:
            raise ValueError(
                "api_key is required. Get one at "
                "https://www.alphainfo.io/register (format: 'ai_...')"
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_base_delay = retry_base_delay
        self._retry_max_delay = retry_max_delay
        self._http2 = _resolve_http2(http2)
        self._client = httpx.Client(timeout=timeout, http2=self._http2)
        self._rate_limit: Optional[RateLimitInfo] = None

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "AlphaInfo":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @property
    def rate_limit_info(self) -> Optional[RateLimitInfo]:
        """Rate limit info from the most recent request."""
        return self._rate_limit

    def _headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": f"alphainfo-python/{_SDK_VERSION}",
        }

    def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Execute HTTP request with retry on transient errors."""
        url = _build_url(self._base_url, endpoint)
        headers = self._headers()
        effective_timeout = timeout or self._timeout
        last_exc: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                if method == "GET":
                    resp = self._client.get(url, headers=headers, timeout=effective_timeout)
                else:
                    resp = self._client.post(
                        url, json=json, headers=headers,
                        timeout=effective_timeout,
                    )

                self._rate_limit = _extract_rate_limit(resp.headers)

                if resp.status_code < 400:
                    result: Dict[str, Any] = resp.json()
                    return result

                _handle_error_response(resp)

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self._max_retries:
                    time.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise SDKTimeoutError(
                    f"Request to {endpoint} timed out after {self._max_retries + 1} attempts"
                ) from e

            except RateLimitError as e:
                last_exc = e
                if attempt < self._max_retries:
                    delay = e.retry_after or self._retry_base_delay * (2 ** attempt)
                    time.sleep(min(delay, self._retry_max_delay))
                    continue
                raise

            except (AuthError, ValidationError, NotFoundError):
                raise  # Non-retryable

            except APIError as e:
                last_exc = e
                if attempt < self._max_retries and e.status_code and e.status_code >= 500:
                    time.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise

        raise NetworkError(f"Failed after {self._max_retries + 1} attempts") from last_exc

    # -- analyze --------------------------------------------------------------

    def analyze(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> AnalysisResult:
        """
        Analyze a time series signal for structural regime changes.

        Args:
            signal: Signal data (list of floats, min 10 samples).
            sampling_rate: Sampling rate in Hz (must be > 0).
            domain: Calibration to apply. Defaults to ``"generic"`` — a safe
                universal setting. Pass ``"auto"`` to let the server infer
                the domain from the signal (then check
                ``result.domain_inference`` for confidence/reasoning). Pass a
                specific name (``"biomedical"``, ``"finance"``, ``"seismic"``,
                ``"power_grid"``, ``"ai_ml"``, ``"sensors"``,
                ``"traffic"``, ``"security"``) for fine-tuned sensitivity.
                Common aliases (``"fintech"``, ``"biomed"``, ``"grid"``, …)
                also resolve.
            baseline: Optional baseline signal for comparison.
            metadata: Optional metadata dict (max 10KB serialized).
            include_semantic: Include human-readable interpretation.
            use_multiscale: Enable multi-scale analysis (more thorough, slower).

        Returns:
            AnalysisResult with structural_score, confidence_band, analysis_id,
            ``domain_applied`` (always populated) and, when ``domain="auto"``,
            ``domain_inference`` carrying the inference metadata.

        Raises:
            ValidationError: Invalid input (empty signal, bad sampling rate,
                or an unknown domain — the server's error includes a
                "Did you mean …?" suggestion when the typo is close to a
                valid name).
            AuthError: Invalid API key.
            RateLimitError: Monthly quota or concurrent limit exceeded.
        """
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata, include_semantic, use_multiscale,
        )
        data = self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_analysis(data)

    # -- analyze_auto ----------------------------------------------------------

    def analyze_auto(
        self,
        signal: List[float],
        sampling_rate: float,
        *,
        baseline: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> AnalysisResult:
        """
        Syntactic sugar for ``analyze(..., domain="auto")``.

        The server picks the most likely calibration from cheap, documentable
        signal statistics. Inspect ``result.domain_applied`` to see which
        calibration ran, and ``result.domain_inference`` for confidence and
        the reason the engine picked it.

        Same contract as :meth:`analyze`; see its docstring for details.
        """
        return self.analyze(
            signal, sampling_rate, domain="auto",
            baseline=baseline, metadata=metadata,
            include_semantic=include_semantic, use_multiscale=use_multiscale,
        )

    # -- analyze_batch ---------------------------------------------------------

    def analyze_batch(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[List[Optional[List[float]]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> BatchResult:
        """
        Analyze multiple signals in a single request.

        Args:
            signals: List of signal arrays (max 100 signals per batch).
            sampling_rate: Common sampling rate for all signals.
            domain: Analysis domain.
            baselines: Optional per-signal baselines. Same length as signals.
                Use None for signals that don't need a baseline.
            include_semantic: Include semantic interpretation per signal.
            use_multiscale: Enable multi-scale analysis.

        Returns:
            BatchResult with per-signal results and quota usage.

        Note:
            Each signal in the batch counts as 1 analysis against your quota.
        """
        payload = _build_batch_payload(
            signals, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = self._request(
            "POST", "/v1/analyze/batch",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_batch(data)

    # -- analyze_matrix --------------------------------------------------------

    def analyze_matrix(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        use_multiscale: bool = True,
    ) -> MatrixResult:
        """
        Compute pairwise structural similarity matrix for N signals.

        Args:
            signals: List of signal arrays (2-50 signals).
            sampling_rate: Common sampling rate for all signals.
            domain: Analysis domain.
            use_multiscale: Enable multi-scale analysis.

        Returns:
            MatrixResult with NxN similarity matrix and helper methods.

        Note:
            Consumes N*(N-1)/2 analyses (one per unique pair).
        """
        payload = _build_matrix_payload(signals, sampling_rate, domain, use_multiscale)
        data = self._request(
            "POST", "/v1/analyze/matrix",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_matrix(data)

    # -- analyze_vector --------------------------------------------------------

    def analyze_vector(
        self,
        channels: Dict[str, List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[Dict[str, List[float]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> VectorResult:
        """
        Analyze multi-channel signal data (e.g., multi-lead ECG, multi-axis sensors).

        Args:
            channels: Dict mapping channel names to signal arrays.
                Example: {"lead_I": [...], "lead_II": [...]}
            sampling_rate: Common sampling rate for all channels.
            domain: Analysis domain.
            baselines: Optional per-channel baselines for comparison.
                Keys must match channel names.
                Example: {"lead_I": [...], "lead_II": [...]}
            include_semantic: Include semantic interpretation.
            use_multiscale: Enable multi-scale analysis.

        Returns:
            VectorResult with per-channel results and aggregated score.

        Note:
            Vector analysis consumes only 1 analysis regardless of channel count.
        """
        payload = _build_vector_payload(
            channels, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = self._request(
            "POST", "/v1/analyze/vector",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_vector(data)

    # -- audit -----------------------------------------------------------------

    def audit_replay(self, analysis_id: str) -> AuditReplay:
        """
        Replay a past analysis by its unique ID.

        Args:
            analysis_id: UUID from a previous analysis result.

        Returns:
            AuditReplay with full inputs, parameters, and outputs.

        Raises:
            NotFoundError: Analysis ID not found.
        """
        if not analysis_id:
            raise ValidationError("analysis_id cannot be empty")
        data = self._request("GET", f"/v1/audit/replay/{analysis_id}")
        return _parse_audit_replay(data)

    def audit_list(self, limit: int = 100) -> List[AuditSummary]:
        """
        List recent analyses for your API key.

        Args:
            limit: Maximum number of results (default 100).

        Returns:
            List of AuditSummary objects.
        """
        data = self._request("GET", f"/v1/audit/list?limit={limit}")
        return _parse_audit_list(data)

    # -- health ----------------------------------------------------------------

    def health(self) -> HealthStatus:
        """Check API health status."""
        data = self._request("GET", "/health", timeout=self.HEALTH_TIMEOUT)
        return _parse_health(data)

    # -- plans -----------------------------------------------------------------

    def plans(self) -> List[PlanInfo]:
        """List available billing plans."""
        data = self._request("GET", "/api/plans")
        return _parse_plans(data)

    # -- guide -----------------------------------------------------------------

    def guide(self) -> Dict[str, Any]:
        """
        Fetch the universal encoding guide from the API.

        Returns a dict with sections: encoding_patterns, usage_modes, endpoints,
        common_mistakes, performance_tips, debugging_tips,
        fingerprint_interpretation, signal_requirements, baseline_guide, and
        more.

        No authentication required. Useful for discoverability and AI agent
        introspection.

        Returns:
            Dict with guide version and all sections.
        """
        return self._request("GET", "/v1/guide", timeout=self.HEALTH_TIMEOUT)

    # -- fingerprint -----------------------------------------------------------

    def fingerprint(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
    ) -> FingerprintResult:
        """
        Extract the 5D structural fingerprint of a signal (fast path).

        Skips semantic interpretation and multi-scale analysis for speed.
        Returns a 5-dimensional vector capturing the signal's structural
        identity. Use ``result.vector`` for nearest-neighbor / ANN indexing.

        Minimum length: the engine needs at least
        ``alphainfo.MIN_FINGERPRINT_SAMPLES`` (192) samples when no baseline
        is provided, or ``alphainfo.MIN_FINGERPRINT_SAMPLES_WITH_BASELINE``
        (50) samples with a baseline of comparable length. Below the
        threshold, ``fingerprint_available`` will be False and
        ``fingerprint_reason`` will be ``"signal_too_short"`` — the SDK
        emits a UserWarning at call time so you can switch to
        :meth:`analyze` for shorter signals.

        Args:
            signal: Signal data (list of floats, min 10 samples). For a
                complete 5D fingerprint you typically want 192+ samples
                (or 50+ with a baseline).
            sampling_rate: Sampling rate in Hz.
            domain: Analysis domain.
            baseline: Optional baseline for comparison.

        Returns:
            FingerprintResult with the 5 structural dimensions and a
            ``.vector`` property ready for pgvector / Qdrant / Faiss.
            Always check ``.is_complete`` before indexing the vector.
        """
        _warn_if_too_short_for_fingerprint(signal, baseline)
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata=None,
            include_semantic=False,
            use_multiscale=False,
        )
        data = self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_fingerprint(data)

    # -- High-level intent-based helpers --------------------------------------
    # Thin ergonomic wrappers over analyze / analyze_batch for the most common
    # usage patterns surfaced by the external review (April 2026). They don't
    # change the API contract — each helper expands to one or more existing
    # endpoints with sensible defaults. Heavier patterns that need numpy
    # client-side (feature ensemble, schema drift, event grammar, motif
    # search) live in the public ``recipes/`` directory of the main repo
    # rather than the SDK so the SDK stays single-dependency.

    def compare(
        self,
        signal: List[float],
        baseline: List[float],
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        intent: str = "regime_change",
        include_semantic: bool = True,
        use_multiscale: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AnalysisResult:
        """Compare a signal against a known baseline (intent-based wrapper).

        The most common use case: "is the current signal still behaving
        like the baseline?". Returns the same :class:`AnalysisResult`
        you'd get from :meth:`analyze` — but the named ``intent`` argument
        makes call sites self-documenting and lets future SDK versions
        adopt smarter per-intent defaults without breaking callers.

        Recognised intents (purely a discoverability hint today, no
        preprocessing magic):

        - ``regime_change`` (default) — generic structural comparison
        - ``similarity_general`` — alias of ``regime_change``
        - ``amplitude_sensitive`` — raw shape; amplitude DOES register
          (default behaviour, no preprocessing applied)
        - ``amplitude_invariant`` — recommends z-normalising signal AND
          baseline before calling. The SDK can't apply numpy ops, so the
          recipe lives in user space::

              def z_norm(x):
                  return (np.array(x) - np.mean(x)) / (np.std(x) + 1e-9)
              client.compare(z_norm(obs), z_norm(hist), intent="amplitude_invariant")

        - ``frequency_sensitive`` / ``distribution_shift`` — generic call
          works; the engine surfaces these in the per-axis breakdown

        For local-anomaly localisation use :meth:`analyze_windowed`. For
        schema drift / event grammar / motif search see ``recipes/`` in
        the public repo.
        """
        result = self.analyze(
            signal=signal,
            sampling_rate=sampling_rate,
            domain=domain,
            baseline=baseline,
            metadata=metadata,
            include_semantic=include_semantic,
            use_multiscale=use_multiscale,
        )
        # Stash the intent so callers can introspect what they asked for.
        # We don't use it server-side yet, but it's discoverable.
        if metadata is None and intent:
            try:
                setattr(result, "_intent", intent)
            except Exception:
                pass
        return result

    def detect_internal_change(
        self,
        signal: List[float],
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        intent: str = "local_anomaly",
        include_semantic: bool = True,
        use_multiscale: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AnalysisResult:
        """Detect structural change WITHIN a single signal (no baseline).

        Triage / exploration mode. Asks "does this series contain an
        internal regime change?". Less decisive than baseline mode — for
        production-grade anomaly localisation use :meth:`analyze_windowed`.

        Recognised intents (discoverability hint):

        - ``local_anomaly`` (default) — point/burst anomaly
        - ``regime_internal`` — internal regime shift
        - ``distribution_internal`` — within-series distribution change
        """
        return self.analyze(
            signal=signal,
            sampling_rate=sampling_rate,
            domain=domain,
            baseline=None,
            metadata=metadata,
            include_semantic=include_semantic,
            use_multiscale=use_multiscale,
        )

    def analyze_windowed(
        self,
        signal: List[float],
        window_size: int,
        step: int,
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        baseline: Optional[List[float]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> Dict[str, Any]:
        """Slide a window over a long signal and analyze each via batch.

        Answers "where in the signal did the change happen?". Useful for
        point-event detection on long histories where a single
        :meth:`analyze` call would dilute the local change.

        Args:
            signal: long signal (list of floats).
            window_size: number of samples per window. Engine minimum 10;
                200-500 recommended for reliable scores.
            step: stride between consecutive windows. Smaller = more
                overlap = more analyses consumed.
            baseline: optional baseline compared against EVERY window.
                Useful for "did the signal drift away from normal anywhere
                in this stretch?".

        Returns:
            ``Dict[str, Any]`` (not a dataclass — use ``result["..."]``
            access, not ``result.attribute``):

            - ``windows``: ``List[Tuple[start_idx, end_idx, score]]`` —
              one tuple per window. ``score`` is ``None`` if that window
              failed.
            - ``worst_window``: ``Tuple (start, end, score)`` — minimum
              score (most-divergent window).
            - ``best_window``: ``Tuple (start, end, score)`` — maximum
              score.
            - ``batch_result``: the underlying :class:`BatchResult`.
            - ``window_size``: ``int``.
            - ``step``: ``int``.

        Example::

            out = client.analyze_windowed(signal=long, window_size=200, step=50)
            start, end, score = out["worst_window"]   # NOT out.worst_window
            print(f"divergence at samples {start}-{end}, score={score}")

        Note:
            Each window consumes one analysis against your quota. Use a
            step of ``window_size // 2`` or larger to keep cost down on
            long signals. Batch is capped at 100 signals per request, so
            very long signals may need chunking client-side.
        """
        if window_size < 10:
            raise ValueError("window_size must be >= 10 (engine minimum)")
        if step < 1:
            raise ValueError("step must be >= 1")
        if len(signal) < window_size:
            raise ValueError(
                f"signal too short ({len(signal)} samples) for "
                f"window_size={window_size}"
            )

        windows: List[List[float]] = []
        starts: List[int] = []
        i = 0
        while i + window_size <= len(signal):
            windows.append(list(signal[i : i + window_size]))
            starts.append(i)
            i += step

        if not windows:
            raise ValueError(
                "no windows produced — check signal length, window_size, step"
            )

        baselines: Optional[List[Optional[List[float]]]] = (
            [baseline] * len(windows) if baseline is not None else None
        )
        batch = self.analyze_batch(
            signals=windows,
            sampling_rate=sampling_rate,
            domain=domain,
            baselines=baselines,
            include_semantic=include_semantic,
            use_multiscale=use_multiscale,
        )

        window_scores: List[tuple] = []
        for start, item in zip(starts, batch.results):
            if item.success and item.structural_score is not None:
                window_scores.append(
                    (start, start + window_size, item.structural_score)
                )
            else:
                window_scores.append((start, start + window_size, None))

        valid = [w for w in window_scores if w[2] is not None]
        worst = min(valid, key=lambda w: w[2]) if valid else None
        best = max(valid, key=lambda w: w[2]) if valid else None

        return {
            "windows": window_scores,
            "worst_window": worst,
            "best_window": best,
            "batch_result": batch,
            "window_size": window_size,
            "step": step,
        }

    def fit_parameter_grid(
        self,
        target_signal: List[float],
        candidates: Dict[str, List[float]],
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        use_multiscale: bool = True,
    ) -> Dict[str, Any]:
        """Find the candidate signal most structurally similar to a target.

        Calls :meth:`analyze_batch` with each candidate compared against
        ``target_signal`` as baseline. Returns a ranked list of
        ``(name, score)`` sorted descending by ``structural_score`` (most
        similar first).

        Args:
            target_signal: the observed signal to fit. Used as the
                baseline for every candidate.
            candidates: dict mapping candidate name to its signal.
                Example::

                    {"k=1.0": sim1, "k=1.5": sim2, "k=2.0": sim3}

        Returns:
            ``Dict[str, Any]`` (not a dataclass — use ``result["..."]``
            access, not ``result.attribute``):

            - ``ranked``: ``List[Tuple[str, float]]`` — (name, score) desc
            - ``best``: ``Tuple[str, float]`` — top match (or ``None``
              if every candidate failed)
            - ``batch_result``: the underlying :class:`BatchResult`

        Example::

            out = client.fit_parameter_grid(
                target_signal=observed,
                candidates={"k=1.0": sim_a, "k=1.5": sim_b, "k=2.0": sim_c},
            )
            best_name, best_score = out["best"]   # NOT out.best
            for name, score in out["ranked"][:3]:
                print(f"  {name}: {score:.3f}")

        Use case:
            Parameter search for simulators / physics models / regime
            classifiers without gradient descent. Useful for calibrating
            ODE simulators, finding which regime matches observed data,
            or A/B comparing competing model candidates.

        Note:
            Each candidate consumes one analysis against your quota. Cap
            ``candidates`` at 100 entries per call (batch limit).
        """
        if not candidates:
            raise ValueError("candidates dict is empty")

        names = list(candidates.keys())
        signals = [candidates[n] for n in names]
        baselines: List[Optional[List[float]]] = [target_signal] * len(signals)

        batch = self.analyze_batch(
            signals=signals,
            sampling_rate=sampling_rate,
            domain=domain,
            baselines=baselines,
            include_semantic=False,
            use_multiscale=use_multiscale,
        )

        ranked: List[tuple] = []
        for name, item in zip(names, batch.results):
            if item.success and item.structural_score is not None:
                ranked.append((name, item.structural_score))

        ranked.sort(key=lambda x: x[1], reverse=True)

        return {
            "ranked": ranked,
            "best": ranked[0] if ranked else None,
            "batch_result": batch,
        }

    # -- version ---------------------------------------------------------------

    def version(self) -> Dict[str, Any]:
        """
        Get API version and compatibility information.

        Returns:
            Dict with api_version, sdk_compat, engine_version, etc.
        """
        return self._request("GET", "/v1/version", timeout=self.HEALTH_TIMEOUT)


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

def _warn_unclosed_async_client(client_repr: str) -> None:
    """weakref.finalize hook — fires when AsyncAlphaInfo is GC'd without close.

    Runs without access to the event loop, so we cannot actually call
    ``await client.aclose()`` here. The underlying httpx.AsyncClient
    emits its own ResourceWarning about the leaked socket; we emit a
    friendlier one pointing at the idiomatic fix.
    """
    warnings.warn(
        f"{client_repr} was not closed — wrap it in 'async with "
        f"AsyncAlphaInfo(...) as client:' or call 'await client.close()' "
        f"explicitly. Open sockets may be leaked.",
        ResourceWarning,
        stacklevel=2,
    )


class AsyncAlphaInfo:
    """
    Asynchronous client for the alphainfo Structural Intelligence API.

    Args:
        api_key: Your API key (starts with 'ai_').
        base_url: API base URL (default: https://www.alphainfo.io).
        timeout: Default request timeout in seconds.
        max_retries: Maximum retries on transient failures (5xx, timeouts, rate limits).
        retry_base_delay: Base delay (seconds) for exponential backoff (default: 1.0).
        retry_max_delay: Maximum delay (seconds) between retries (default: 32.0).
        http2: Enable HTTP/2. Auto-detected if h2 package is installed.
            Install with: pip install alphainfo[http2]

    Usage:
        >>> async with AsyncAlphaInfo(api_key="ai_xxx") as client:
        ...     result = await client.analyze([1.0, 2.0, ...], sampling_rate=250.0)

    **Always wrap in ``async with`` (or call ``await client.close()`` when
    you're done).** If the client is garbage-collected without being
    closed, the SDK emits a ResourceWarning and the underlying TCP/TLS
    sockets are released by the OS rather than cleanly by httpx.
    """

    DEFAULT_BASE_URL = AlphaInfo.DEFAULT_BASE_URL
    DEFAULT_TIMEOUT = AlphaInfo.DEFAULT_TIMEOUT
    ANALYZE_TIMEOUT = AlphaInfo.ANALYZE_TIMEOUT
    HEALTH_TIMEOUT = AlphaInfo.HEALTH_TIMEOUT
    MAX_RETRIES = AlphaInfo.MAX_RETRIES
    RETRY_BASE_DELAY = AlphaInfo.RETRY_BASE_DELAY
    RETRY_MAX_DELAY = AlphaInfo.RETRY_MAX_DELAY

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
        retry_base_delay: float = RETRY_BASE_DELAY,
        retry_max_delay: float = RETRY_MAX_DELAY,
        http2: Optional[bool] = None,
    ):
        if not api_key:
            raise ValueError(
                "api_key is required. Get one at "
                "https://www.alphainfo.io/register (format: 'ai_...')"
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_base_delay = retry_base_delay
        self._retry_max_delay = retry_max_delay
        self._http2 = _resolve_http2(http2)
        self._client = httpx.AsyncClient(timeout=timeout, http2=self._http2)
        self._rate_limit: Optional[RateLimitInfo] = None
        self._closed = False
        # Emit a clear warning if this instance is GC'd without ever being
        # closed. We can't actually close the httpx client from here (no
        # event loop available at finalize time), but the warning makes
        # the bug obvious in test and dev environments where
        # ResourceWarning is typically surfaced.
        self._finalizer = weakref.finalize(
            self, _warn_unclosed_async_client, repr(self)
        )

    async def close(self) -> None:
        """Close the underlying HTTP client. Safe to call more than once."""
        if self._closed:
            return
        self._closed = True
        # The finalizer is no longer useful once we've closed cleanly.
        if self._finalizer.alive:
            self._finalizer.detach()
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncAlphaInfo":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    @property
    def rate_limit_info(self) -> Optional[RateLimitInfo]:
        return self._rate_limit

    def _headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": f"alphainfo-python/{_SDK_VERSION}",
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        url = _build_url(self._base_url, endpoint)
        headers = self._headers()
        effective_timeout = timeout or self._timeout
        last_exc: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                if method == "GET":
                    resp = await self._client.get(url, headers=headers, timeout=effective_timeout)
                else:
                    resp = await self._client.post(
                        url, json=json, headers=headers,
                        timeout=effective_timeout,
                    )

                self._rate_limit = _extract_rate_limit(resp.headers)

                if resp.status_code < 400:
                    result: Dict[str, Any] = resp.json()
                    return result

                _handle_error_response(resp)

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self._max_retries:
                    await asyncio.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise SDKTimeoutError(
                    f"Request to {endpoint} timed out "
                    f"after {self._max_retries + 1} attempts"
                ) from e

            except RateLimitError as e:
                last_exc = e
                if attempt < self._max_retries:
                    delay = e.retry_after or (
                        self._retry_base_delay * (2 ** attempt)
                    )
                    await asyncio.sleep(min(delay, self._retry_max_delay))
                    continue
                raise

            except (AuthError, ValidationError, NotFoundError):
                raise

            except APIError as e:
                last_exc = e
                if (
                    attempt < self._max_retries
                    and e.status_code
                    and e.status_code >= 500
                ):
                    await asyncio.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise

        raise NetworkError(
            f"Failed after {self._max_retries + 1} attempts",
        ) from last_exc

    # -- All endpoints use shared builders and parsers -------------------------

    async def analyze(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> AnalysisResult:
        """Analyze a signal for structural regime changes (async).

        Pass ``domain="auto"`` to let the server infer the calibration —
        inspect ``result.domain_applied`` and ``result.domain_inference``
        on the returned :class:`AnalysisResult` for details.
        """
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata, include_semantic, use_multiscale,
        )
        data = await self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_analysis(data)

    async def analyze_auto(
        self,
        signal: List[float],
        sampling_rate: float,
        *,
        baseline: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> AnalysisResult:
        """Async sugar for ``await analyze(..., domain="auto")``."""
        return await self.analyze(
            signal, sampling_rate, domain="auto",
            baseline=baseline, metadata=metadata,
            include_semantic=include_semantic, use_multiscale=use_multiscale,
        )

    async def analyze_batch(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[List[Optional[List[float]]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> BatchResult:
        """Analyze multiple signals in one request (async)."""
        payload = _build_batch_payload(
            signals, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = await self._request(
            "POST", "/v1/analyze/batch",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_batch(data)

    async def analyze_matrix(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        use_multiscale: bool = True,
    ) -> MatrixResult:
        """Compute pairwise structural similarity matrix (async)."""
        payload = _build_matrix_payload(signals, sampling_rate, domain, use_multiscale)
        data = await self._request(
            "POST", "/v1/analyze/matrix",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_matrix(data)

    async def analyze_vector(
        self,
        channels: Dict[str, List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[Dict[str, List[float]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> VectorResult:
        """Analyze multi-channel signal data (async)."""
        payload = _build_vector_payload(
            channels, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = await self._request(
            "POST", "/v1/analyze/vector",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_vector(data)

    async def audit_replay(self, analysis_id: str) -> AuditReplay:
        """Replay a past analysis (async)."""
        if not analysis_id:
            raise ValidationError("analysis_id cannot be empty")
        data = await self._request("GET", f"/v1/audit/replay/{analysis_id}")
        return _parse_audit_replay(data)

    async def audit_list(self, limit: int = 100) -> List[AuditSummary]:
        """List recent analyses (async)."""
        data = await self._request("GET", f"/v1/audit/list?limit={limit}")
        return _parse_audit_list(data)

    async def health(self) -> HealthStatus:
        """Check API health (async)."""
        data = await self._request("GET", "/health", timeout=self.HEALTH_TIMEOUT)
        return _parse_health(data)

    async def plans(self) -> List[PlanInfo]:
        """List available plans (async)."""
        data = await self._request("GET", "/api/plans")
        return _parse_plans(data)

    async def guide(self) -> Dict[str, Any]:
        """Fetch the universal encoding guide (async). No auth required."""
        return await self._request("GET", "/v1/guide", timeout=self.HEALTH_TIMEOUT)

    async def fingerprint(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
    ) -> FingerprintResult:
        """Extract the 5D structural fingerprint (async, fast path).

        Same minimum-length requirements as the sync client: ``\u2265192``
        samples without a baseline, ``\u226550`` with one. Emits a
        UserWarning when the signal is shorter so callers can fall back
        to :meth:`analyze` before paying a round-trip.
        """
        _warn_if_too_short_for_fingerprint(signal, baseline)
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata=None,
            include_semantic=False,
            use_multiscale=False,
        )
        data = await self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_fingerprint(data)

    # -- High-level intent-based helpers (async mirrors of the sync ones) -----

    async def compare(
        self,
        signal: List[float],
        baseline: List[float],
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        intent: str = "regime_change",
        include_semantic: bool = True,
        use_multiscale: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AnalysisResult:
        """Compare a signal against a baseline (async). See :meth:`AlphaInfo.compare`."""
        return await self.analyze(
            signal=signal,
            sampling_rate=sampling_rate,
            domain=domain,
            baseline=baseline,
            metadata=metadata,
            include_semantic=include_semantic,
            use_multiscale=use_multiscale,
        )

    async def detect_internal_change(
        self,
        signal: List[float],
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        intent: str = "local_anomaly",
        include_semantic: bool = True,
        use_multiscale: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AnalysisResult:
        """Detect change within a single signal (async). See :meth:`AlphaInfo.detect_internal_change`."""
        return await self.analyze(
            signal=signal,
            sampling_rate=sampling_rate,
            domain=domain,
            baseline=None,
            metadata=metadata,
            include_semantic=include_semantic,
            use_multiscale=use_multiscale,
        )

    async def analyze_windowed(
        self,
        signal: List[float],
        window_size: int,
        step: int,
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        baseline: Optional[List[float]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> Dict[str, Any]:
        """Slide a window over a long signal (async). See :meth:`AlphaInfo.analyze_windowed`."""
        if window_size < 10:
            raise ValueError("window_size must be >= 10 (engine minimum)")
        if step < 1:
            raise ValueError("step must be >= 1")
        if len(signal) < window_size:
            raise ValueError(
                f"signal too short ({len(signal)} samples) for "
                f"window_size={window_size}"
            )

        windows: List[List[float]] = []
        starts: List[int] = []
        i = 0
        while i + window_size <= len(signal):
            windows.append(list(signal[i : i + window_size]))
            starts.append(i)
            i += step

        if not windows:
            raise ValueError(
                "no windows produced — check signal length, window_size, step"
            )

        baselines: Optional[List[Optional[List[float]]]] = (
            [baseline] * len(windows) if baseline is not None else None
        )
        batch = await self.analyze_batch(
            signals=windows,
            sampling_rate=sampling_rate,
            domain=domain,
            baselines=baselines,
            include_semantic=include_semantic,
            use_multiscale=use_multiscale,
        )

        window_scores: List[tuple] = []
        for start, item in zip(starts, batch.results):
            if item.success and item.structural_score is not None:
                window_scores.append(
                    (start, start + window_size, item.structural_score)
                )
            else:
                window_scores.append((start, start + window_size, None))

        valid = [w for w in window_scores if w[2] is not None]
        worst = min(valid, key=lambda w: w[2]) if valid else None
        best = max(valid, key=lambda w: w[2]) if valid else None

        return {
            "windows": window_scores,
            "worst_window": worst,
            "best_window": best,
            "batch_result": batch,
            "window_size": window_size,
            "step": step,
        }

    async def fit_parameter_grid(
        self,
        target_signal: List[float],
        candidates: Dict[str, List[float]],
        *,
        sampling_rate: float = 1.0,
        domain: str = "generic",
        use_multiscale: bool = True,
    ) -> Dict[str, Any]:
        """Find the closest candidate (async). See :meth:`AlphaInfo.fit_parameter_grid`."""
        if not candidates:
            raise ValueError("candidates dict is empty")

        names = list(candidates.keys())
        signals = [candidates[n] for n in names]
        baselines: List[Optional[List[float]]] = [target_signal] * len(signals)

        batch = await self.analyze_batch(
            signals=signals,
            sampling_rate=sampling_rate,
            domain=domain,
            baselines=baselines,
            include_semantic=False,
            use_multiscale=use_multiscale,
        )

        ranked: List[tuple] = []
        for name, item in zip(names, batch.results):
            if item.success and item.structural_score is not None:
                ranked.append((name, item.structural_score))

        ranked.sort(key=lambda x: x[1], reverse=True)

        return {
            "ranked": ranked,
            "best": ranked[0] if ranked else None,
            "batch_result": batch,
        }

    async def version(self) -> Dict[str, Any]:
        """Get API version and compatibility info (async)."""
        return await self._request("GET", "/v1/version", timeout=self.HEALTH_TIMEOUT)
