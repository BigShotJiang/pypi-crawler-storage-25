"""alphainfo — Structural Intelligence for time series analysis.

Quick start:
    import alphainfo
    alphainfo.health()           # no API key required
    alphainfo.guide()            # no API key required

    client = alphainfo.AlphaInfo(api_key="ai_...")
    result = client.analyze(signal=[...], sampling_rate=1.0)

Get a free API key: https://www.alphainfo.io/register
Full documentation:  https://www.alphainfo.io/quickstart

Tip: use ``alphainfo.guide()`` instead of ``help(alphainfo)`` for
exploration — ``help()`` recurses into every class and is noisy.
"""

from typing import Any, Dict, cast

from .client import AlphaInfo, AsyncAlphaInfo
from .exceptions import (
    AlphaInfoError,
    APIError,
    AuthError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)
from .models import (
    MIN_FINGERPRINT_SAMPLES,
    MIN_FINGERPRINT_SAMPLES_WITH_BASELINE,
    AnalysisResult,
    AuditReplay,
    AuditSummary,
    BatchItemResult,
    BatchResult,
    ChannelResult,
    FingerprintResult,
    HealthStatus,
    MatrixResult,
    PlanInfo,
    RateLimitInfo,
    SemanticResult,
    VectorResult,
)

__version__ = "1.5.23"


# ---------------------------------------------------------------------------
# Module-level helpers — no API key required.
# Let curious developers try the library before signing up.
# ---------------------------------------------------------------------------


def guide(
    base_url: str = "https://www.alphainfo.io",
    timeout: float = 10.0,
) -> Dict[str, Any]:
    """Fetch the public encoding guide from /v1/guide. No API key needed.

    Useful for exploring the API surface before signing up:

        >>> import alphainfo
        >>> g = alphainfo.guide()
        >>> print(list(g.keys()))
        >>> print(g['three_questions'])

    Get a free key to actually analyze signals:
    https://www.alphainfo.io/register
    """
    import httpx
    url = f"{base_url.rstrip('/')}/v1/guide"
    resp = httpx.get(url, timeout=timeout)
    resp.raise_for_status()
    return cast(Dict[str, Any], resp.json())


def health(
    base_url: str = "https://www.alphainfo.io",
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """Fetch API health status. No API key needed.

        >>> import alphainfo
        >>> alphainfo.health()
        {'status': 'healthy', 'version': '2.3.0', ...}
    """
    import httpx
    url = f"{base_url.rstrip('/')}/health"
    resp = httpx.get(url, timeout=timeout)
    resp.raise_for_status()
    return cast(Dict[str, Any], resp.json())


__all__ = [
    # Clients
    "AlphaInfo",
    "AsyncAlphaInfo",
    # No-auth helpers
    "guide",
    "health",
    # Public constants
    "MIN_FINGERPRINT_SAMPLES",
    "MIN_FINGERPRINT_SAMPLES_WITH_BASELINE",
    # Result models
    "AnalysisResult",
    "SemanticResult",
    "BatchResult",
    "BatchItemResult",
    "VectorResult",
    "ChannelResult",
    "MatrixResult",
    "FingerprintResult",
    # Audit
    "AuditReplay",
    "AuditSummary",
    # Infrastructure
    "HealthStatus",
    "PlanInfo",
    "RateLimitInfo",
    # Exceptions
    "AlphaInfoError",
    "APIError",
    "AuthError",
    "NetworkError",
    "NotFoundError",
    "RateLimitError",
    "TimeoutError",
    "ValidationError",
]
