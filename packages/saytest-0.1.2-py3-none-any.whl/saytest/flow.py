"""
flow.py — cluster origin 환경값 + Pipeline 구축

CLUSTER_DEFAULTS dict 가 cluster UI 에서 사용자가 선택한 값들.
IDE 에서 직접 편집 가능. 또는 env / toml 로 외부 override.
"""

import os
from pathlib import Path

from xgen_harness import HarnessConfig, Pipeline, PipelineState
from xgen_harness.config import DictConfigSource, EnvConfigSource, FileConfigSource
from xgen_harness.adapters import create_provider


# === Cluster origin default — cluster UI 에서 사용자가 선택한 환경값 ===
# IDE 에서 직접 편집 가능. env / toml 로 외부 override 도 가능.
CLUSTER_DEFAULTS = {
    "provider": "vllm",
    "model": "Qwen3.5-27b",
    "temperature": 0.7,
    "max_tokens": 8192,
    "aux_max_tokens": 500,
    "openai_model": "",
    "anthropic_model": "",
    "max_iterations": 10,
    "max_tool_rounds": None,
    "max_retries": 10,
    "validation_threshold": 0.7,
    "system_prompt": "You are a helpful AI assistant.",
    "disabled_stages": [],
    "artifacts": {},
    "stage_params": {
        "s04_tool": {
            "selected_tools": {
                "mcp-sessions": []
            }
        },
        "s03_prompt": {
            "selected_prompt": "_default"
        },
        "s06_context": {}
    },
    "active_strategies": {
        "s00_harness": "streaming",
        "s02_history": "default",
        "s06_context": "cascade",
        "s08_decide": "threshold",
        "s09_finalize": "default"
    },
    "strategy_variants": {},
    "capabilities": [],
    "capability_params": {},
    "external_inputs": {},
    "cost_budget_usd": None,
    "context_window": 200000,
    "thinking_enabled": False,
    "thinking_budget_tokens": 10000,
    "verbose_events": False,
    "judge_provider": "",
    "judge_model": "",
    "judge_use_main": False,
    "preset": "standard",
    "_schema_version": 1
}


def build_pipeline() -> Pipeline:
    """Pipeline 인스턴스 생성. 5 단계 resolution + 외부 인프라 wire."""
    config_toml = Path("./xgen-harness.toml")
    config = HarnessConfig.resolve(sources=[
        EnvConfigSource(prefix="XGEN_HARNESS_"),
        FileConfigSource(config_toml) if config_toml.exists() else None,
        DictConfigSource(CLUSTER_DEFAULTS),
    ])

    # === 외부 인프라 wire — env 변수에서 받음 ===
    provider = create_provider(
        os.environ.get("XGEN_HARNESS_PROVIDER", config.provider or "openai"),
        api_key=_resolve_api_key(config.provider or "openai"),
        model=config.model or None,
    )

    doc_service = _build_doc_service()

    return Pipeline.from_config(
        config,
        doc_service=doc_service,
        provider=provider,
    )


def _resolve_api_key(provider_name: str) -> str:
    """provider 이름 → API key env 변수 lookup."""
    env_map = {
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "google": "GEMINI_API_KEY",
        "vllm": "VLLM_API_KEY",
    }
    env_key = env_map.get(provider_name, f"{provider_name.upper()}_API_KEY")
    return os.environ.get(env_key, "")


def _build_doc_service():
    """Qdrant URL 박혀있으면 QdrantDocService, 아니면 None."""
    qdrant_url = os.environ.get("QDRANT_URL")
    if not qdrant_url:
        return None
    from xgen_harness.adapters import QdrantDocService
    return QdrantDocService(
        url=qdrant_url,
        api_key=os.environ.get("QDRANT_API_KEY"),
    )
