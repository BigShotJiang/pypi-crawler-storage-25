"""__main__ — CLI entry point.

사용: python -m saytest "사용자 입력"
"""

import asyncio
import sys

from xgen_harness import PipelineState

from .flow import build_pipeline


async def _run(user_input: str) -> str:
    pipeline = build_pipeline()
    state = PipelineState(user_input=user_input)
    result = await pipeline.run(state)
    return getattr(result, "final_text", "") or ""


def cli_main() -> None:
    user_input = sys.argv[1] if len(sys.argv) > 1 else ""
    if not user_input:
        print("Usage: python -m " + __package__ + " \"사용자 입력\"", file=sys.stderr)
        sys.exit(1)
    output = asyncio.run(_run(user_input))
    print(output)


if __name__ == "__main__":
    cli_main()
