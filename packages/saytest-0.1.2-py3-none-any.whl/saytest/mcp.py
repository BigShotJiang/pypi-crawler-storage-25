"""MCP 서버 entry — FastMCP stdio.

사용:
    claude mcp add my-wf -- python -m saytest.mcp

FastMCP 의존성:
    pip install saytest[mcp]
"""

from xgen_harness import PipelineState

from .flow import build_pipeline


def _build_server():
    """FastMCP 서버 인스턴스 구축 — 도구 1 개 등록."""
    try:
        from fastmcp import FastMCP
    except ImportError as e:
        raise ImportError(
            "FastMCP 미설치. `pip install saytest[mcp]` 또는 `pip install fastmcp` 박으세요."
        ) from e

    mcp = FastMCP("saytest")

    @mcp.tool
    async def run_workflow(user_input: str) -> str:
        """xgen 워크플로우 실행. user_input 받아 final_text 반환."""
        pipeline = build_pipeline()
        state = PipelineState(user_input=user_input)
        result = await pipeline.run(state)
        return getattr(result, "final_text", "") or ""

    return mcp


def main() -> None:
    server = _build_server()
    server.run()


if __name__ == "__main__":
    main()
