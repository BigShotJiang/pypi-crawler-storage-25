# BCSFE-Python Wrapper

このライブラリは、[fieryhenry/BCSFE-Python](https://github.com/fieryhenry/BCSFE-Python) プロジェクトをPythonスクリプトからより簡単に利用できるようにするためのラッパーです。元のプロジェクトのすべての機能を、コマンドラインインターフェースを介さずに、Pythonコードから直接呼び出すことができます。

## インストール

1.  このリポジトリをクローンするか、提供された `bcsfe_wrapper.zip` ファイルを解凍します。
2.  `bcsfe_wrapper` ディレクトリに移動します。
3.  以下のコマンドを実行して、ライブラリをインストールします。

    ```bash
    pip install .
    ```

## 使用方法

`BCSFEWrapper` クラスをインポートし、セーブファイルのパスを指定してインスタンス化します。その後、提供されているメソッドを使用してセーブデータを操作できます。

### 初期化

`BCSFEWrapper` を初期化する際には、セーブファイルのパス、国コード、ゲームバージョンを指定します。

```python
from bcsfe_wrapper import BCSFEWrapper

save_file_path = "/path/to/your/SAVE_DATA" # 実際のセーブファイルのパスに置き換えてください
wrapper = BCSFEWrapper(save_path=save_file_path, cc="jp", gv="13.1.0")
```

### アイテムの編集

ネコカン、XP、各種チケットなどのアイテムを編集できます。

```python
# ネコカンを999999に設定
wrapper.set_catfood(999999)

# XPを99999999に設定
wrapper.set_xp(99999999)

# レアチケットを100枚に設定
wrapper.set_rare_tickets(100)

# すべての戦闘アイテムを99個に設定
wrapper.set_battle_items(99)

# 変更を保存
wrapper.save()
```

### キャラクターの編集

すべてのキャラクターの解放やアップグレードが可能です。

```python
# すべてのキャラクターを解放
wrapper.unlock_all_cats()

# すべてのキャラクターを最大レベルまでアップグレード
wrapper.upgrade_all_cats()

# すべてのキャラクターを第3形態・第4形態に進化
wrapper.true_form_all_cats()

# 変更を保存
wrapper.save()
```

### ステージの編集

チュートリアルのクリアやストーリーチャプターのクリアが可能です。

```python
# チュートリアルをクリア済みにする
wrapper.clear_tutorial()

# 日本編、未来編、宇宙編をすべてクリアし、最高のお宝を取得
wrapper.clear_story_chapters()

# 変更を保存
wrapper.save()
```

### その他の機能

お問い合わせコードの取得やBAN解除なども可能です。

```python
# お問い合わせコードを取得
inquiry_code = wrapper.get_inquiry_code()
print(f"お問い合わせコード: {inquiry_code}")

# アカウントのBANを解除
wrapper.unban_account()

# 変更を保存
wrapper.save()
```

## 注意事項

*   このラッパーは、元の `BCSFE-Python` プロジェクトの内部ロジックに依存しています。元のプロジェクトのアップデートにより、ラッパーが動作しなくなる可能性があります。
*   セーブデータの編集は自己責任で行ってください。データの破損やゲームアカウントのBANにつながる可能性があります。
*   `cc` (国コード) と `gv` (ゲームバージョン) は、セーブファイルと一致させる必要があります。一致しない場合、正しく動作しない可能性があります。

## 貢献

このプロジェクトは、[fieryhenry/BCSFE-Python](https://github.com/fieryhenry/BCSFE-Python) に基づいています。
