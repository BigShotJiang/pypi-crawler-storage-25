from setuptools import setup, find_packages

setup(
    name='bcsfe-wrapper-python',
    version='0.1.26',
    packages=find_packages(), include_package_data=True,
    install_requires=[
        'requests',
        'pyyaml',
        'cloudscraper',
        'pycryptodomex',
        'aenum',
        'colored',
        'pyjwt',
    ],
    author='Manus AI',
    description='A Python wrapper for BCSFE-Python to easily interact with Battle Cats save files.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/fieryhenry/BCSFE-Python', # 元のリポジトリへのリンク
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)
