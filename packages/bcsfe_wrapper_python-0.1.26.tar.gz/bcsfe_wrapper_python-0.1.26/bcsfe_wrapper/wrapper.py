from __future__ import annotations
from typing import List, Optional, Union, Any
from .bcsfe import core
from .bcsfe.core.io.save import SaveFile

# bcsfe本体の初期化不足を補うためのグローバル初期化
def force_init_core():
    try:
        from .bcsfe import core
        # core_dataを完全に再生成し、configを強制的に持たせる
        core.core_data = core.CoreData()
        # config属性がない場合の最終手段
        if not hasattr(core.core_data, "config"):
            class DummyConfig:
                def get_bool(self, *args, **kwargs): return False
                def get_str(self, *args, **kwargs): return ""
                def get_int(self, *args, **kwargs): return 0
            core.core_data.config = DummyConfig()
    except Exception:
        pass

force_init_core()

class BCSFEWrapper:
    def __init__(self, save_data: bytes = b"", cc: str = "jp", gv: str = "13.4.0"):
        force_init_core()
            
        self.cc = core.CountryCode.from_code(cc)
        self.gv = core.GameVersion.from_string(gv)
        self.save_file: Optional[SaveFile] = None
        if save_data:
            data = core.Data(save_data)
            self.save_file = SaveFile(data, cc=self.cc, gv=self.gv)

    @classmethod
    def from_server(cls, transfer_code: str, confirmation_code: str, cc: str = "jp", gv: str = "13.4.0") -> BCSFEWrapper:
        instance = cls(b"", cc=cc, gv=gv)
        instance.save_file = SaveFile(core.Data(), cc=instance.cc, gv=instance.gv)
        handler = core.ServerHandler(instance.save_file, print=False)
        if handler.download_save_data(transfer_code, confirmation_code):
            return instance
        else:
            raise RuntimeError("Failed to download save data from server")

    def _check_save(self):
        if self.save_file is None or not hasattr(self.save_file, "catfood"):
            raise RuntimeError("セーブデータが読み込まれていません。from_server()などでデータを取得してください。")

    def upload_to_server(self) -> tuple[str, str]:
        self._check_save()
        handler = core.ServerHandler(self.save_file, print=False)
        if handler.upload_save_data():
            return self.save_file.transfer_code, self.save_file.confirmation_code
        else:
            raise RuntimeError("Failed to upload save data to server")

    def create_account(self) -> str:
        self.save_file = SaveFile(core.Data(), cc=self.cc, gv=self.gv)
        handler = core.ServerHandler(self.save_file, print=False)
        if handler.create_new_account():
            return self.save_file.inquiry_code
        else:
            raise RuntimeError("Failed to create new account")

    def unban(self):
        self._check_save()
        self.save_file.show_ban_message = False

    def save(self, output_path: str):
        self._check_save()
        self.save_file.set_hash()
        with open(output_path, "wb") as f:
            f.write(self.save_file.data.get_bytes())

    # --- リソース系 ---
    def edit_catfood(self, amount: int): self._check_save(); self.save_file.catfood = amount
    def edit_xp(self, amount: int): self._check_save(); self.save_file.xp = amount
    def edit_np(self, amount: int): self._check_save(); self.save_file.np = amount
    def edit_leadership(self, amount: int): self._check_save(); self.save_file.leadership = amount
    def edit_normal_tickets(self, amount: int): self._check_save(); self.save_file.normal_tickets = amount
    def edit_rare_tickets(self, amount: int): self._check_save(); self.save_file.rare_tickets = amount
    def edit_platinum_tickets(self, amount: int): self._check_save(); self.save_file.platinum_tickets = amount
    def edit_legend_tickets(self, amount: int): self._check_save(); self.save_file.legend_tickets = amount
    
    def edit_battle_items(self, amount: int):
        self._check_save()
        for i in range(len(self.save_file.battle_items.items)):
            self.save_file.battle_items.items[i] = amount

    def edit_cats_eyes(self, amount: int):
        self._check_save()
        for i in range(len(self.save_file.battle_items.catseyes)):
            self.save_file.battle_items.catseyes[i] = amount

    def edit_vitamins(self, amount: int):
        self._check_save()
        for i in range(len(self.save_file.battle_items.catamins)):
            self.save_file.battle_items.catamins[i] = amount

    def edit_castle_materials(self, amount: int):
        self._check_save()
        for i in range(len(self.save_file.ototo.base_materials.materials)):
            self.save_file.ototo.base_materials.materials[i] = amount

    def edit_matatabi(self, amount: int):
        self._check_save()
        for i in range(len(self.save_file.cats.matatabi.matatabi)):
            self.save_file.cats.matatabi.matatabi[i] = amount

    # --- ステージ系 ---
    def _clear_chapter_group(self, chapters_obj, c_ids: List[int]):
        for c_id in c_ids:
            if c_id < len(chapters_obj.chapters):
                chapter = chapters_obj.chapters[c_id]
                chapter.clear_all(self.save_file)
                for stage in chapter.stages: stage.treasure = 3

    def clear_empire_of_cats(self, chapters: List[int] = [0, 1, 2]):
        self._check_save(); self._clear_chapter_group(self.save_file.story, chapters)
    def clear_into_the_future(self, chapters: List[int] = [0, 1, 2]):
        self._check_save(); self._clear_chapter_group(self.save_file.story, [c + 3 for c in chapters])
    def clear_cats_of_the_cosmos(self, chapters: List[int] = [0, 1, 2]):
        self._check_save(); self._clear_chapter_group(self.save_file.story, [c + 6 for c in chapters])

    def _clear_legend_group(self, legend_obj, max_star: int = 1):
        self._check_save()
        chapters = legend_obj.chapters if hasattr(legend_obj, "chapters") else legend_obj
        for map_id in range(len(chapters)):
            for star in range(min(max_star, legend_obj.get_total_stars(map_id))):
                for stage_id in range(legend_obj.get_total_stages(map_id, star)):
                    legend_obj.clear_stage(map_id, star, stage_id, overwrite_clear_progress=True)

    def clear_legend_stories(self, max_star: int = 1): self._clear_legend_group(self.save_file.event_stages, max_star)
    def clear_true_legends(self, max_star: int = 1): self._clear_legend_group(self.save_file.uncanny, max_star)
    def clear_zero_legends(self, max_star: int = 1): self._clear_legend_group(self.save_file.dojo_chapters, max_star)
    
    def clear_zombie_outbreaks(self, chapters: List[int] = [0, 1, 2, 3, 4, 5, 6, 7, 8]):
        self._check_save()
        for c_id in chapters:
            if c_id < len(self.save_file.outbreaks.chapters):
                self.save_file.outbreaks.chapters[c_id].clear_zombies()

    def complete_all_treasures(self):
        self._check_save()
        for chapter in self.save_file.story.chapters:
            for stage in chapter.stages: stage.treasure = 3

    def unlock_all_medals(self):
        self._check_save()
        for i in range(len(self.save_file.medals.medals)):
            self.save_file.medals.medals[i] = True

    # --- キャラクター系 ---
    def unlock_cats(self, cat_ids: List[int]):
        self._check_save()
        for cid in cat_ids:
            internal_id = cid - 1
            cat = self.save_file.cats.get_cat_by_id(internal_id)
            if cat: cat.unlock(self.save_file)

    def unlock_all_cats(self):
        self._check_save()
        for cat in self.save_file.cats.cats:
            cat.unlock(self.save_file)

    def remove_cats(self, cat_ids: List[int]):
        self._check_save()
        for cid in cat_ids:
            internal_id = cid - 1
            cat = self.save_file.cats.get_cat_by_id(internal_id)
            if cat: cat.set_unlocked(False)

    def upgrade_cats(self, cat_ids: List[int], base: int = 19, plus: int = 0):
        self._check_save()
        for cid in cat_ids:
            internal_id = cid - 1
            cat = self.save_file.cats.get_cat_by_id(internal_id)
            if cat:
                cat.upgrade.base = base
                cat.upgrade.plus = plus

    def upgrade_all_cats(self, base: int = 19, plus: int = 0):
        self._check_save()
        for cat in self.save_file.cats.cats:
            cat.upgrade.base = base
            cat.upgrade.plus = plus

    def set_cat_form(self, cat_ids: List[int], form: int = 2):
        self._check_save()
        for cid in cat_ids:
            internal_id = cid - 1
            cat = self.save_file.cats.get_cat_by_id(internal_id)
            if cat: cat.set_form(form)

    def true_form_all_cats(self):
        self._check_save()
        for cat in self.save_file.cats.cats:
            # 可能な最大形態にセット（第4形態があれば第4、なければ第3）
            cat.set_form(cat.get_max_form() - 1)

    def max_all_talents(self):
        self._check_save()
        for cat in self.save_file.cats.cats:
            if cat.talent_data:
                for talent in cat.talent_data.talents:
                    talent.level = talent.max_level

    def max_all_upgrades(self):
        self._check_save()
        for upgrade in self.save_file.special_skills.upgrades:
            upgrade.base = upgrade.max_base
            upgrade.plus = upgrade.max_plus
