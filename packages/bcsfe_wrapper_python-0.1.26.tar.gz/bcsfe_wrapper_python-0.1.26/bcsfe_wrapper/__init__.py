import os
import sys

# パッケージ内のbcsfeをインポート可能にするためのパス調整
_current_dir = os.path.dirname(os.path.abspath(__file__))
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

from .wrapper import BCSFEWrapper
