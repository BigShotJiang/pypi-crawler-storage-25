#!/usr/bin/env bash
# deja-recall.sh — pre-tool-use hook for Claude Code
#
# Fires before each Bash tool call. Classifies the command against a short
# allowlist of high-signal operations (deploy, migrate, rotate, etc.), runs
# `deja search` for matching ones, and injects relevant gotchas/procedures
# into the agent's context before the command executes.
#
# INSTALL:
#   cp hooks/deja-recall.sh ~/.claude/hooks/deja-recall.sh
#   chmod +x ~/.claude/hooks/deja-recall.sh
#
# Then add to ~/.claude/settings.json (user-level, all projects) or
# .claude/settings.json (project-level):
#
#   {
#     "hooks": {
#       "PreToolUse": [
#         {
#           "matcher": "Bash",
#           "hooks": [{ "type": "command", "command": "~/.claude/hooks/deja-recall.sh" }]
#         }
#       ]
#     }
#   }
#
# The hook receives tool JSON on stdin and writes a JSON response to stdout.
# Exit 0 (no output)  → allow silently
# Exit 0 (JSON output) → allow, inject additionalContext before the command
# Exit 2               → block the command

set -euo pipefail

INPUT=$(cat)

TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // ""')
CMD=$(echo "$INPUT"       | jq -r '.tool_input.command // ""')

# Only fire for Bash tool calls
[ "$TOOL_NAME" != "Bash" ] && exit 0

# ── Classification allowlist ─────────────────────────────────────────────────
# Add or remove patterns here. Keep this list short and specific — the goal is
# to fire rarely and precisely on actions where past gotchas are most valuable.

INTENT=""

if echo "$CMD" | grep -qE "kubectl apply|helm upgrade|kubectl rollout"; then
  INTENT="deploy kubernetes"
elif echo "$CMD" | grep -qE "alembic upgrade|alembic downgrade|flask db upgrade|python manage.py migrate"; then
  INTENT="database migration"
elif echo "$CMD" | grep -qE "terraform apply|terraform destroy|terraform import"; then
  INTENT="terraform infrastructure"
elif echo "$CMD" | grep -qE "git push.*(--force|-f)|git push.*(main|master)"; then
  INTENT="git push force main"
elif echo "$CMD" | grep -qE "aws.*deploy|aws.*update|aws.*delete|aws.*terminate"; then
  INTENT="aws deploy infrastructure"
elif echo "$CMD" | grep -qE "secret|credential|rotate|revoke|vault"; then
  INTENT="secret rotation credentials"
elif echo "$CMD" | grep -qE "docker.*push|docker.*deploy|docker.*prod"; then
  INTENT="docker deploy production"
elif echo "$CMD" | grep -qE "pg_dump|mysqldump|mongodump|pg_restore|mongorestore"; then
  INTENT="database backup restore"
elif echo "$CMD" | grep -qE "npm publish|pip publish|cargo publish|gem push"; then
  INTENT="publish package release"
fi

# Low-signal command (ls, cat, grep, read, etc.) — skip silently
[ -z "$INTENT" ] && exit 0

# ── Recall ────────────────────────────────────────────────────────────────────
# Run deja search. Suppress errors (deja may not be installed / vault empty).
MEMORIES=$(deja search "$INTENT" 2>/dev/null || true)

# Nothing found — allow silently
[ -z "$MEMORIES" ] && exit 0

# ── Inject context ────────────────────────────────────────────────────────────
# Write JSON to stdout. Claude Code reads hookSpecificOutput.additionalContext
# and prepends it to the tool context before the command runs.
jq -n --arg ctx "$MEMORIES" '{
  "hookSpecificOutput": {
    "additionalContext": ("[deja recall]\n" + $ctx)
  }
}'
