#!/usr/bin/env bash
# deja-precompact.sh — PreCompact hook for Claude Code
#
# Fires before context compaction. Loads the most relevant deja memories and
# injects them as additionalContext so they survive the compaction summary.
# Without this, the agent loses memory orientation after every compact.

set -euo pipefail

INPUT=$(cat)
CWD=$(echo "$INPUT" | jq -r '.cwd // ""')
PROJECT=$(basename "$CWD")

MEMORIES=$(deja load --project "$PROJECT" --context "context compaction in progress" 2>/dev/null || true)

[ -z "$MEMORIES" ] && exit 0

jq -n --arg ctx "$MEMORIES" '{
  "additionalContext": ("[deja — memories to carry through compaction]\n" + $ctx)
}'
