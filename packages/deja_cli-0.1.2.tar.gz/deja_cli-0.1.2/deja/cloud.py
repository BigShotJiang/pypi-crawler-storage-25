from __future__ import annotations

import json
import secrets
import stat
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlparse

import httpx

CLI_REDIRECT_PORT = 51234

AUTH_FILE = Path.home() / ".deja" / "auth.json"
SYNC_STATE_FILE = Path.home() / ".deja" / "sync_state.json"

DEFAULT_ENDPOINT = "https://api.deja.sh"


def _get_endpoint(config=None) -> str:
    if config is None:
        return DEFAULT_ENDPOINT
    cloud = getattr(config, "cloud", None)
    if cloud is None:
        return DEFAULT_ENDPOINT
    return getattr(cloud, "endpoint", DEFAULT_ENDPOINT).rstrip("/")


# ── Token storage ─────────────────────────────────────────────────────


def load_auth() -> Optional[dict]:
    if not AUTH_FILE.exists():
        return None
    return json.loads(AUTH_FILE.read_text())


def save_auth(data: dict) -> None:
    AUTH_FILE.parent.mkdir(exist_ok=True)
    AUTH_FILE.write_text(json.dumps(data, indent=2))
    AUTH_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 600


def clear_auth() -> None:
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()


def get_token(config=None) -> Optional[str]:
    """Return the stored PAT, or None if not logged in."""
    auth = load_auth()
    if not auth:
        return None
    return auth.get("access_token")


# ── Browser login flow ────────────────────────────────────────────────


def login_browser(config=None) -> str:
    """Open deja.sh in the browser, wait for the CLI callback, exchange code for PAT."""
    endpoint = _get_endpoint(config)
    web_url = getattr(getattr(config, "cloud", None), "web_url", None) or endpoint.replace("api.", "www.", 1)

    state = secrets.token_urlsafe(16)
    code_holder: dict = {}
    ready = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            qs = parse_qs(urlparse(self.path).query)
            code_holder["code"] = qs.get("code", [None])[0]
            code_holder["error"] = qs.get("error", [None])[0]
            self.send_response(200)
            self.end_headers()
            self.wfile.write(
                b"<html><body style='font-family:sans-serif;background:#09090b;color:#fff;"
                b"display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>"
                b"<p>CLI authorized. Return to your terminal.</p>"
                b"<script>window.close()</script></body></html>"
            )
            ready.set()

        def log_message(self, *args):
            pass

    server = HTTPServer(("localhost", CLI_REDIRECT_PORT), Handler)

    auth_url = f"{web_url}/auth/cli?state={state}&port={CLI_REDIRECT_PORT}"
    webbrowser.open(auth_url)
    print(f"Opening deja.sh in your browser…")
    print(f"If it doesn't open, visit: {auth_url}")

    server.handle_request()

    if code_holder.get("error"):
        raise RuntimeError(f"Auth error: {code_holder['error']}")
    if not code_holder.get("code"):
        raise RuntimeError("No auth code received")

    # Exchange one-time code for a PAT
    resp = httpx.post(
        f"{endpoint}/auth/cli/exchange",
        json={"code": code_holder["code"]},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()["token"]


# ── Whoami ────────────────────────────────────────────────────────────


def whoami(config=None) -> Optional[dict]:
    token = get_token(config)
    if not token:
        return None
    endpoint = _get_endpoint(config)
    resp = httpx.get(
        f"{endpoint}/auth/me",
        headers={"Authorization": f"Bearer {token}"},
        timeout=10,
    )
    if not resp.is_success:
        return None
    return resp.json()


# ── Save to cloud ─────────────────────────────────────────────────────


_PUSH_FIELDS = {"content", "type", "project", "confidence", "triggerCmds", "category"}


def push_memory(memory: dict, config=None) -> bool:
    """Push a single memory to cloud. Returns True on success, False on failure (non-fatal)."""
    token = get_token(config)
    if not token:
        return False
    endpoint = _get_endpoint(config)
    payload = _sanitize_for_push(memory)
    try:
        resp = httpx.post(
            f"{endpoint}/v1/memories",
            json=payload,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        return resp.is_success
    except Exception:
        return False


# ── Sync ──────────────────────────────────────────────────────────────


def load_sync_state() -> dict:
    if not SYNC_STATE_FILE.exists():
        return {}
    return json.loads(SYNC_STATE_FILE.read_text())


def save_sync_state(state: dict) -> None:
    SYNC_STATE_FILE.parent.mkdir(exist_ok=True)
    SYNC_STATE_FILE.write_text(json.dumps(state, indent=2))


def _sanitize_for_push(memory: dict) -> dict:
    """Convert a local memory dict to the shape the cloud API accepts."""
    payload = {k: v for k, v in memory.items() if k in _PUSH_FIELDS}
    if "id" in memory:
        payload["localId"] = memory["id"]
    # Local scope uses 'global' or 'project:xyz'; API uses 'local'|'global'.
    payload["scope"] = "global"
    if memory.get("last_confirmed"):
        payload["lastConfirmed"] = memory["last_confirmed"]
    return payload


def sync_push(memories: list[dict], config=None) -> dict:
    token = get_token(config)
    if not token:
        raise RuntimeError("Not logged in. Run `deja login`.")
    endpoint = _get_endpoint(config)
    sanitized = [_sanitize_for_push(m) for m in memories]
    resp = httpx.post(
        f"{endpoint}/v1/sync/push",
        json={"memories": sanitized},
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    if not resp.is_success:
        raise RuntimeError(f"sync push failed ({resp.status_code}): {resp.text}")
    return resp.json()


def sync_pull(since: Optional[str] = None, config=None) -> dict:
    token = get_token(config)
    if not token:
        raise RuntimeError("Not logged in. Run `deja login`.")
    endpoint = _get_endpoint(config)
    params = f"?since={since}" if since else ""
    resp = httpx.get(
        f"{endpoint}/v1/sync/pull{params}",
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()
