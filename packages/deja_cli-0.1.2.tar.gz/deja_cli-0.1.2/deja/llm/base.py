from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class LLMResponse:
    content: str
    raw: Any = None


class LLMAdapter(ABC):
    @abstractmethod
    async def complete(self, system: str, user: str, **kwargs) -> LLMResponse: ...

    async def complete_structured(self, system: str, user: str, schema: dict) -> dict:
        """Prompt-engineer JSON mode for providers without native JSON output."""
        prompt = (
            f"{user}\n\nRespond ONLY with valid JSON matching this schema:\n"
            f"{json.dumps(schema, indent=2)}"
        )
        response = await self.complete(
            system=system + "\nRespond with valid JSON only. No markdown fences, no explanation.",
            user=prompt,
        )
        return self._parse_json(response.content)

    def _parse_json(self, content: str) -> dict:
        cleaned = re.sub(r"^```(?:json)?\n?|\n?```$", "", content.strip())
        return json.loads(cleaned)
