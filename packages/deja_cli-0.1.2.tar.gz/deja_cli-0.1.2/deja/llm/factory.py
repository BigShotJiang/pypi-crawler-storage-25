from __future__ import annotations

import sys
from typing import Literal, Optional

import httpx

from deja.config import Config, LLMProviderConfig
from deja.llm.base import LLMAdapter
from deja.llm.embedding import EmbeddingAdapter, OllamaEmbeddingAdapter
from deja.llm.providers.anthropic import AnthropicAdapter
from deja.llm.providers.ollama import OllamaAdapter


async def _ollama_available(base_url: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(f"{base_url.rstrip('/')}/api/tags")
            return response.status_code == 200
    except Exception:
        return False


def _build_adapter(provider_cfg: LLMProviderConfig) -> LLMAdapter:
    if provider_cfg.provider == "ollama":
        return OllamaAdapter(
            model=provider_cfg.model,
            base_url=provider_cfg.base_url,
        )
    elif provider_cfg.provider == "anthropic":
        return AnthropicAdapter(
            model=provider_cfg.model,
            api_key=provider_cfg.api_key,
        )
    else:
        raise ValueError(f"Unknown provider: {provider_cfg.provider}")


async def create_adapter(
    config: Config,
    task: Literal["extraction", "reflection"] = "extraction",
) -> Optional[LLMAdapter]:
    """Create an LLM adapter for the given task.

    Returns None when provider is 'none' — the agent handles extraction itself
    via deja save, or the watcher falls back to saving raw content.
    """
    provider_cfg = (
        config.llm.extraction if task == "extraction" else config.llm.reflection
    )

    if provider_cfg.provider == "none":
        return None

    if provider_cfg.provider == "ollama":
        if await _ollama_available(provider_cfg.base_url):
            return _build_adapter(provider_cfg)
        else:
            print(
                f"[deja] Ollama unavailable at {provider_cfg.base_url}, "
                f"falling back to {config.llm.fallback.provider}",
                file=sys.stderr,
            )
            return _build_adapter(config.llm.fallback)

    return _build_adapter(provider_cfg)


async def create_embedding_adapter(config: Config) -> Optional[EmbeddingAdapter]:
    """Create an embedding adapter for semantic search.

    Returns None when provider is 'none' — search falls back to BM25 (FTS5) only.
    """
    if config.embedding.provider == "none":
        return None

    if config.embedding.provider == "ollama":
        if await _ollama_available(config.embedding.base_url):
            return OllamaEmbeddingAdapter(
                model=config.embedding.model,
                base_url=config.embedding.base_url,
            )
        print(
            f"[deja] Ollama unavailable at {config.embedding.base_url} — embedding search disabled",
            file=sys.stderr,
        )
        return None

    print(f"[deja] Unknown embedding provider: {config.embedding.provider}", file=sys.stderr)
    return None
