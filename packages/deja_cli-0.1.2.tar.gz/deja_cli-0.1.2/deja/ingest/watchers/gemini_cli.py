from __future__ import annotations

import json
import sys
from pathlib import Path

from deja.ingest.watchers.base import BaseWatcher


class GeminiCLIWatcher(BaseWatcher):
    """Watches ~/.gemini/tmp/**/chats/session-*.json for Gemini CLI session files.

    File structure:
      ~/.gemini/tmp/<project-dir>/chats/session-<timestamp>.json

    Each file is a JSON object:
      {
        "sessionId": "...",
        "projectHash": "...",
        "startTime": "...",
        "lastUpdated": "...",
        "messages": [
          {"type": "user",   "content": [{"text": "..."}]},
          {"type": "gemini", "content": "..."},
          {"type": "info",   ...},   # skip
          {"type": "error",  ...},   # skip
        ]
      }

    Project name is read from .project_root in the project directory, which
    contains the absolute path to the project on disk.
    """

    def get_watch_paths(self) -> list[Path]:
        return [Path.home() / ".gemini" / "tmp"]

    def should_process(self, path: Path) -> bool:
        """Process session-*.json files inside chats/ directories."""
        return (
            path.suffix == ".json"
            and path.stem.startswith("session-")
            and path.parent.name == "chats"
        )

    def get_project_name(self, path: Path) -> str:
        """Extract project name from .project_root file.

        Path structure: ~/.gemini/tmp/<project-dir>/chats/session-*.json
        The .project_root file in <project-dir> contains the absolute project path.
        """
        try:
            project_dir = path.parent.parent  # <project-dir>
            project_root_file = project_dir / ".project_root"
            if project_root_file.exists():
                root_path = project_root_file.read_text(encoding="utf-8").strip()
                if root_path:
                    return Path(root_path).name
            # Fallback: use the project dir name as-is (may be a hash or human name)
            return project_dir.name
        except Exception as e:
            print(
                f"[deja] Could not determine project name for {path}: {e}",
                file=sys.stderr,
            )
            return "unknown"

    def parse_transcript(self, content: str) -> str:
        """Parse Gemini session JSON into a plain-text conversation transcript."""
        try:
            data = json.loads(content)
        except (json.JSONDecodeError, ValueError):
            return content  # not valid JSON — pass raw, extractor will handle it

        turns = []
        for msg in data.get("messages", []):
            msg_type = msg.get("type", "")

            if msg_type == "user":
                raw_content = msg.get("content", [])
                if isinstance(raw_content, list):
                    text = " ".join(
                        c.get("text", "")
                        for c in raw_content
                        if isinstance(c, dict)
                    ).strip()
                else:
                    text = str(raw_content).strip()
                if text:
                    turns.append(f"User: {text}")

            elif msg_type == "gemini":
                text = msg.get("content", "")
                if isinstance(text, str) and text.strip():
                    turns.append(f"Gemini: {text.strip()}")

        return "\n\n".join(turns)
