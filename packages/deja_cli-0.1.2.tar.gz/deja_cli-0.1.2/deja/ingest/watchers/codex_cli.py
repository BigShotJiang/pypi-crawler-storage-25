from __future__ import annotations

import json
import sys
from pathlib import Path

from deja.ingest.watchers.base import BaseWatcher


class CodexCLIWatcher(BaseWatcher):
    """Watches ~/.codex/sessions/**/rollout-*.jsonl for Codex CLI session files.

    File structure:
      ~/.codex/sessions/<year>/<month>/<day>/rollout-<timestamp>-<uuid>.jsonl

    Each line is a JSON object with a "type" field:
      - session_meta: payload.cwd gives the project directory
      - response_item: payload.role in (user, assistant, developer)
          user:      payload.content[].type == "input_text"
          assistant: payload.content[].type == "output_text"
          developer: system context — skipped
      - event_msg, turn_context: metadata — skipped

    Project name is derived from cwd in the session_meta line.
    """

    def get_watch_paths(self) -> list[Path]:
        return [Path.home() / ".codex" / "sessions"]

    def should_process(self, path: Path) -> bool:
        """Process rollout-*.jsonl session files."""
        return path.suffix == ".jsonl" and path.stem.startswith("rollout-")

    def get_project_name(self, path: Path) -> str:
        """Extract project name from cwd in the session_meta line."""
        try:
            for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                try:
                    d = json.loads(raw_line)
                    if d.get("type") == "session_meta":
                        cwd = d.get("payload", {}).get("cwd", "")
                        if cwd:
                            return Path(cwd).name
                except (json.JSONDecodeError, KeyError):
                    continue
        except OSError as e:
            print(
                f"[deja] Could not determine project name for {path}: {e}",
                file=sys.stderr,
            )
        # Fallback: stem of the filename (rollout-<timestamp>-<uuid>)
        return path.stem

    def parse_transcript(self, content: str) -> str:
        """Parse Codex JSONL into a plain-text conversation transcript.

        Extracts user and assistant turns from response_item lines.
        Skips developer (system context), event_msg, and turn_context lines.
        """
        turns = []

        for raw_line in content.splitlines():
            try:
                d = json.loads(raw_line)
            except (json.JSONDecodeError, ValueError):
                continue

            if d.get("type") != "response_item":
                continue

            payload = d.get("payload", {})
            role = payload.get("role", "")
            if role not in ("user", "assistant"):
                continue

            content_items = payload.get("content", [])
            if not isinstance(content_items, list):
                continue

            texts = []
            for item in content_items:
                if not isinstance(item, dict):
                    continue
                item_type = item.get("type", "")
                # user turns use input_text; assistant turns use output_text
                if item_type in ("input_text", "output_text"):
                    text = item.get("text", "").strip()
                    if text:
                        texts.append(text)

            if texts:
                label = "User" if role == "user" else "Codex"
                turns.append(f"{label}: {chr(10).join(texts)}")

        return "\n\n".join(turns)
