from __future__ import annotations

import asyncio
import json
import threading
from pathlib import Path
from typing import Optional

import typer
import yaml

from deja.config import Config
from deja.llm.embedding import EmbeddingAdapter
from deja.llm.factory import create_adapter, create_embedding_adapter
from ._helpers import (
    _get_config,
    _get_store,
    _init_store,
    _embed_and_save,
    _format_load_result,
    _format_memory_text,
)


def register(app: typer.Typer) -> None:

    @app.command()
    def init():
        """First-time setup: create ~/.deja/ directory structure."""
        ms_dir = Path("~/.deja").expanduser()
        store_dir = ms_dir / "store"
        vault_dir = store_dir / "vault"
        config_path = ms_dir / "config.yaml"

        store_dir.mkdir(parents=True, exist_ok=True)
        vault_dir.mkdir(parents=True, exist_ok=True)

        if not config_path.exists():
            default_config = Config()
            with open(config_path, "w") as f:
                yaml.dump(default_config.model_dump(), f, default_flow_style=False)
            typer.echo(f"Created config at {config_path}")
        else:
            typer.echo(f"Config already exists at {config_path}")

        store = _get_store()
        asyncio.run(_init_store(store))
        asyncio.run(store.close())

        typer.echo(f"Memory service initialized at {ms_dir}")

    @app.command()
    def load(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name. Omit to load global memories only."),
        format: str = typer.Option("text", "--format", "-f", help="Output format: json|text"),
        context: Optional[str] = typer.Option(None, "--context", "-c", help="Task context query: re-ranks memories by relevance instead of raw confidence."),
    ):
        """Load memories as context for a session (type-slot budgeted).

        With --project: returns global memories + that project's memories.
        Without --project: returns global memories only.

        Selects top-N per type (5 gotcha, 5 decision, 5 preference, 5 pattern,
        3 procedure by reuse, 3 recent progress). Overflow count shown with search hint.

        With --context: re-ranks within each type slot by relevance to the given query
        (hybrid BM25 + embedding) instead of sorting by raw confidence.
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                if config.cloud.enabled:
                    from deja.cloud import get_token, sync_pull, load_sync_state, save_sync_state
                    token = get_token(config)
                    if token:
                        try:
                            state = load_sync_state()
                            endpoint = config.cloud.endpoint
                            last_synced = state.get(endpoint)
                            pull_result = sync_pull(since=last_synced, config=config)
                            cloud_memories = pull_result.get("memories", [])
                            server_time = pull_result.get("serverTime")
                            for m in cloud_memories:
                                await store.upsert(m, merge_strategy="update-confidence")
                            if server_time:
                                state[endpoint] = server_time
                                save_sync_state(state)
                        except Exception:
                            pass  # offline or error: use local results only

                embedding_adapter = await create_embedding_adapter(config) if context else None
                result = await store.load_budgeted(project, context=context, embedding_adapter=embedding_adapter)
                await store.confirm_memories([m["id"] for m in result["memories"]])
                return result
            finally:
                await store.close()

        result = asyncio.run(_run())

        if format == "json":
            typer.echo(json.dumps(result, indent=2, default=str))
        else:
            typer.echo(_format_load_result(result))

    @app.command()
    def save(
        content: str = typer.Argument(..., help="Memory content to save"),
        type: str = typer.Option("pattern", "--type", "-t", help="Memory type: preference|pattern|decision|gotcha|progress|procedure"),
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name. Omit to save as global (cross-project)."),
        confidence: float = typer.Option(1.0, "--confidence", "-c", help="Confidence score 0.0-1.0"),
        category: str = typer.Option("agent", "--category", help="Category: user|agent"),
        trigger: Optional[str] = typer.Option(None, "--trigger", help="Comma-separated phrases that activate this memory (e.g. 'kubectl apply, deploy k8s')."),
    ):
        """Save a memory directly (no LLM extraction).

        Omit --project to save globally — the memory will appear in deja load for
        every project. Use this for user preferences and broadly applicable patterns.

        Use --project to scope the memory to a specific project — it only appears
        in deja load --project <name>.

        If embedding.provider is configured, generates an embedding automatically.
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()

            embedding_bytes = None
            embedding_adapter = await create_embedding_adapter(config)
            if embedding_adapter is not None:
                try:
                    emb = await embedding_adapter.embed(content)
                    embedding_bytes = EmbeddingAdapter.to_bytes(emb)
                except Exception as e:
                    typer.echo(f"[deja] Embedding generation failed: {e}", err=True)

            try:
                scope = f"project:{project}" if project else "global"
                memory = {
                    "type": type,
                    "category": category,
                    "content": content,
                    "scope": scope,
                    "project": project,
                    "source": "manual",
                    "confidence": confidence,
                    "trigger": trigger,
                }
                mem_id, is_new, cloud_data = await store.save(memory, embedding=embedding_bytes)
                return mem_id, cloud_data
            finally:
                await store.close()

        mem_id, cloud_data = asyncio.run(_run())
        typer.echo(f"Saved memory: {mem_id}")

        # Cloud push (synchronous, best-effort)
        # cloud_data reflects the actual stored state (new insert or dedup-updated memory),
        # including the id so the cloud can upsert correctly.
        config = _get_config()
        if config.cloud.sync_on_save:
            from deja.cloud import get_token, push_memory
            if get_token(config):
                trigger_str = cloud_data.get("trigger") or ""
                push_payload = {**cloud_data, "triggerCmds": [t.strip() for t in trigger_str.split(",") if t.strip()]}
                push_payload.pop("trigger", None)
                push_memory(push_payload, config)

    @app.command()
    def search(
        query: str = typer.Argument(..., help="Search query"),
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Narrow to global + this project. Omit to search all scopes."),
        type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type"),
        format: str = typer.Option("text", "--format", "-f", help="Output format: json|text"),
    ):
        """Search memories using hybrid BM25 + embedding search.

        BM25 (keyword) always runs first. When BM25 returns fewer than 3 results
        and embedding.provider is configured, semantic similarity search runs as
        a fallback. Results are ranked by activation score (task_match, confidence,
        recency, reuse_count). Enable semantic search in ~/.deja/config.yaml:
          embedding:
            provider: ollama
            model: nomic-embed-text
        Then run 'deja embed' to backfill embeddings for existing memories.
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            embedding_adapter = await create_embedding_adapter(config)
            try:
                results = await store.search(
                    query, project, mem_type=type, embedding_adapter=embedding_adapter
                )
                return results
            finally:
                await store.close()

        results = asyncio.run(_run())

        if format == "json":
            typer.echo(json.dumps(results, indent=2, default=str))
        else:
            if not results:
                typer.echo("No memories found.")
                return
            for mem in results:
                typer.echo(_format_memory_text(mem))

    @app.command(name="list")
    def list_cmd(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter to global + this project. Omit to list everything."),
        type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type"),
        format: str = typer.Option("text", "--format", "-f", help="Output format: json|text"),
    ):
        """List all active memories.

        Without --project: shows every memory across all projects and global scope.
        With --project: shows global + that project's memories only.
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                if project:
                    memories = await store.load(project)
                else:
                    memories = await store.list_all()
                if type:
                    memories = [m for m in memories if m["type"] == type]
                return memories
            finally:
                await store.close()

        memories = asyncio.run(_run())

        if format == "json":
            typer.echo(json.dumps(memories, indent=2, default=str))
        else:
            if not memories:
                typer.echo("No memories found.")
                return
            for mem in memories:
                typer.echo(_format_memory_text(mem))

    @app.command()
    def show(
        memory_id: str = typer.Argument(..., help="Memory ID to show"),
    ):
        """Show details for a specific memory."""
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                return await store.get(memory_id)
            finally:
                await store.close()

        mem = asyncio.run(_run())

        if mem is None:
            typer.echo(f"Memory {memory_id} not found.", err=True)
            raise typer.Exit(1)
        typer.echo(json.dumps(mem, indent=2, default=str))

    @app.command()
    def update(
        memory_id: str = typer.Argument(..., help="Memory ID to update"),
        trigger: Optional[str] = typer.Option(None, "--trigger", help="Comma-separated trigger phrases to add (merged with existing)."),
        type: Optional[str] = typer.Option(None, "--type", "-t", help="New memory type: preference|pattern|decision|gotcha|progress|procedure"),
    ):
        """Update metadata on an existing memory.

        Only trigger and type can be updated. Content changes should use
        deja save (which deduplicates automatically).

        Trigger phrases are merged with any existing trigger, not replaced.

        Example:
          deja update 01JKB... --trigger "kubectl apply, helm upgrade"
          deja update 01JKB... --type gotcha
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                fields = {}
                if trigger is not None:
                    fields["trigger"] = trigger
                if type is not None:
                    fields["type"] = type
                if not fields:
                    typer.echo("No fields to update. Use --trigger or --type.", err=True)
                    raise typer.Exit(1)
                updated = await store.update_memory(memory_id, fields)
                return updated
            finally:
                await store.close()

        updated = asyncio.run(_run())
        if updated:
            typer.echo(f"Updated memory: {memory_id}")
        else:
            typer.echo(f"Memory not found or already archived: {memory_id}", err=True)
            raise typer.Exit(1)

    @app.command()
    def archive(
        memory_id: str = typer.Argument(..., help="Memory ID to archive"),
    ):
        """Archive a memory (soft delete)."""
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                await store.archive(memory_id)
            finally:
                await store.close()

        asyncio.run(_run())
        typer.echo(f"Archived memory: {memory_id}")

    @app.command()
    def stats(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project to show stats for."),
    ):
        """Show memory vault statistics: counts by type, token estimate, last reflection times."""
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                return await store.get_stats(project)
            finally:
                await store.close()

        s = asyncio.run(_run())

        typer.echo(f"Project:        {s['project']}")
        typer.echo(f"Active:         {s['active']}")
        for t, cnt in sorted(s["by_type"].items()):
            typer.echo(f"  {t:<16} {cnt}")
        typer.echo(f"Archived:       {s['archived']}")
        typer.echo(f"Invalidated:    {s['invalidated']}")
        typer.echo(f"Observations:   {s['observations']}")
        typer.echo(f"Token estimate: ~{s['token_estimate']}")
        if s["last_observer_at"]:
            typer.echo(f"Last observer:  {s['last_observer_at'][:19]}")
        if s["last_reflector_at"]:
            typer.echo(f"Last reflector: {s['last_reflector_at'][:19]}")
        if s["last_decay_at"]:
            typer.echo(f"Last decay:     {s['last_decay_at'][:19]}")
        typer.echo(f"With embeddings: {s.get('with_embeddings', 0)}/{s['active']}")
