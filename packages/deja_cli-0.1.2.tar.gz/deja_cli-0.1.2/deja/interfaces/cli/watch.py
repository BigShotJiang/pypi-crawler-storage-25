from __future__ import annotations

import asyncio
import threading
from pathlib import Path

import typer
from watchdog.events import FileSystemEventHandler, FileSystemEvent
from watchdog.observers import Observer

from deja.core.extractor import extract_memories
from deja.ingest.watchers.claude_code import ClaudeCodeWatcher
from deja.ingest.watchers.gemini_cli import GeminiCLIWatcher
from deja.ingest.watchers.codex_cli import CodexCLIWatcher
from deja.llm.factory import create_adapter, create_embedding_adapter
from ._helpers import _get_config, _get_store


def register(app: typer.Typer) -> None:

    @app.command()
    def viewer(
        host: str = typer.Option("127.0.0.1", "--host", help="Host to bind to."),
        port: int = typer.Option(8888, "--port", "-p", help="Port to listen on."),
        no_browser: bool = typer.Option(False, "--no-browser", help="Don't open browser automatically."),
    ):
        """Launch the deja web viewer.

        Opens a browser UI to browse, search, and manage your memory vault.
        Press Ctrl+C to stop.
        """
        try:
            import uvicorn
        except ImportError:
            typer.echo("uvicorn not installed. Run: uv add uvicorn", err=True)
            raise typer.Exit(1)

        from deja.interfaces.web import app as web_app

        if not no_browser:
            import webbrowser
            import time

            def _open():
                time.sleep(0.8)
                webbrowser.open(f"http://{host}:{port}")

            threading.Thread(target=_open, daemon=True).start()

        typer.echo(f"deja viewer → http://{host}:{port}  (Ctrl+C to stop)")
        uvicorn.run(web_app, host=host, port=port, log_level="warning")

    @app.command()
    def watch():
        """Start watching for session files from enabled agents.

        Agents watched (configured in ~/.deja/config.yaml):
          claude_code: ~/.claude/projects/**/session-memory/summary.md
          gemini_cli:  ~/.gemini/tmp/**/chats/session-*.json
          codex_cli:   ~/.codex/sessions/**/rollout-*.jsonl

        Enable additional watchers by setting them to true in config:
          watchers:
            gemini_cli: true
            codex_cli: true
        """
        config = _get_config()
        store = _get_store(config)

        loop = asyncio.new_event_loop()

        def start_loop():
            asyncio.set_event_loop(loop)
            loop.run_forever()

        loop_thread = threading.Thread(target=start_loop, daemon=True)
        loop_thread.start()

        future = asyncio.run_coroutine_threadsafe(store.init_db(), loop)
        future.result(timeout=10)

        adapter_future = asyncio.run_coroutine_threadsafe(
            create_adapter(config, "extraction"), loop
        )
        adapter = adapter_future.result(timeout=10)
        if adapter is None:
            typer.echo(
                "Note: no LLM configured. Watcher will save raw session summaries as "
                "progress memories. Set extraction.provider in ~/.deja/config.yaml "
                "to enable structured extraction."
            )

        embedding_adapter_future = asyncio.run_coroutine_threadsafe(
            create_embedding_adapter(config), loop
        )
        embedding_adapter = embedding_adapter_future.result(timeout=10)

        watcher_kwargs = dict(
            store=store,
            extractor_fn=extract_memories,
            adapter=adapter,
            debounce_seconds=config.watchers.debounce_seconds,
            embedding_adapter=embedding_adapter,
        )
        watchers = []
        if config.watchers.claude_code:
            watchers.append(ClaudeCodeWatcher(**watcher_kwargs))
        if config.watchers.gemini_cli:
            watchers.append(GeminiCLIWatcher(**watcher_kwargs))
        if config.watchers.codex_cli:
            watchers.append(CodexCLIWatcher(**watcher_kwargs))

        if not watchers:
            typer.echo(
                "No watchers enabled. Set at least one to true in ~/.deja/config.yaml:\n"
                "  watchers:\n"
                "    claude_code: true\n"
                "    gemini_cli: true\n"
                "    codex_cli: true",
                err=True,
            )
            raise typer.Exit(1)

        observer = Observer()

        for watcher in watchers:
            class _Handler(FileSystemEventHandler):
                def __init__(self, w):
                    self._watcher = w

                def on_modified(self, event: FileSystemEvent):
                    if not event.is_directory:
                        path = Path(event.src_path)
                        loop.call_soon_threadsafe(self._watcher.handle_file_event, path)

                def on_created(self, event: FileSystemEvent):
                    if not event.is_directory:
                        path = Path(event.src_path)
                        loop.call_soon_threadsafe(self._watcher.handle_file_event, path)

            handler = _Handler(watcher)
            for watch_path in watcher.get_watch_paths():
                watch_path.mkdir(parents=True, exist_ok=True)
                observer.schedule(handler, str(watch_path), recursive=True)
                typer.echo(f"Watching [{watcher.__class__.__name__}]: {watch_path}")

        observer.start()
        typer.echo("Memory service watcher running. Press Ctrl+C to stop.")

        stop_event = threading.Event()
        try:
            stop_event.wait()
        except KeyboardInterrupt:
            pass
        finally:
            observer.stop()
            observer.join()
            loop.call_soon_threadsafe(loop.stop)
            asyncio.run_coroutine_threadsafe(store.close(), loop)
            typer.echo("\nWatcher stopped.")
