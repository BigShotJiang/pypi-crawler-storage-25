from __future__ import annotations

import json
import stat
from pathlib import Path
from typing import Optional

import typer

from ._helpers import _get_config


_RECALL_HOOK_SCRIPT = r"""#!/usr/bin/env bash
# deja-recall.sh — pre-tool-use hook for Claude Code
#
# Fires before each Bash tool call. Classifies the command against a short
# allowlist of high-signal operations (deploy, migrate, rotate, etc.), runs
# `deja search` for matching ones, and injects relevant gotchas/procedures
# into the agent's context before the command executes.

set -euo pipefail

INPUT=$(cat)

TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // ""')
CMD=$(echo "$INPUT"       | jq -r '.tool_input.command // ""')

# Only fire for Bash tool calls
[ "$TOOL_NAME" != "Bash" ] && exit 0

INTENT=""

if echo "$CMD" | grep -qE "kubectl apply|helm upgrade|kubectl rollout"; then
  INTENT="deploy kubernetes"
elif echo "$CMD" | grep -qE "alembic upgrade|alembic downgrade|flask db upgrade|python manage.py migrate"; then
  INTENT="database migration"
elif echo "$CMD" | grep -qE "terraform apply|terraform destroy|terraform import"; then
  INTENT="terraform infrastructure"
elif echo "$CMD" | grep -qE "git push.*(--force|-f)|git push.*(main|master)"; then
  INTENT="git push force main"
elif echo "$CMD" | grep -qE "aws.*deploy|aws.*update|aws.*delete|aws.*terminate"; then
  INTENT="aws deploy infrastructure"
elif echo "$CMD" | grep -qE "secret|credential|rotate|revoke|vault"; then
  INTENT="secret rotation credentials"
elif echo "$CMD" | grep -qE "docker.*push|docker.*deploy|docker.*prod"; then
  INTENT="docker deploy production"
elif echo "$CMD" | grep -qE "pg_dump|mysqldump|mongodump|pg_restore|mongorestore"; then
  INTENT="database backup restore"
elif echo "$CMD" | grep -qE "npm publish|pip publish|cargo publish|gem push"; then
  INTENT="publish package release"
fi

[ -z "$INTENT" ] && exit 0

MEMORIES=$(deja search "$INTENT" 2>/dev/null || true)

[ -z "$MEMORIES" ] && exit 0

jq -n --arg ctx "$MEMORIES" '{
  "hookSpecificOutput": {
    "additionalContext": ("[deja recall]\n" + $ctx)
  }
}'
"""

_POST_FAIL_HOOK_SCRIPT = r"""#!/usr/bin/env bash
# deja-post-fail.sh — post-tool-use hook for Claude Code
#
# Fires after each Bash tool call. If the command was high-signal AND failed
# (non-zero exit / is_error), searches deja for related gotchas and injects
# them so the agent debugs with past context immediately.

set -euo pipefail

INPUT=$(cat)

TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // ""')
CMD=$(echo "$INPUT"       | jq -r '.tool_input.command // ""')

[ "$TOOL_NAME" != "Bash" ] && exit 0

EXIT_CODE=$(echo "$INPUT" | jq -r '.tool_result.exit_code // 0')
IS_ERROR=$(echo "$INPUT"  | jq -r '.tool_result.is_error // false')

if [ "$EXIT_CODE" = "0" ] && [ "$IS_ERROR" = "false" ]; then
  exit 0
fi

INTENT=""

if echo "$CMD" | grep -qE "kubectl apply|helm upgrade|kubectl rollout"; then
  INTENT="deploy kubernetes"
elif echo "$CMD" | grep -qE "alembic upgrade|alembic downgrade|flask db upgrade|python manage.py migrate"; then
  INTENT="database migration"
elif echo "$CMD" | grep -qE "terraform apply|terraform destroy|terraform import"; then
  INTENT="terraform infrastructure"
elif echo "$CMD" | grep -qE "git push.*(--force|-f)|git push.*(main|master)"; then
  INTENT="git push force main"
elif echo "$CMD" | grep -qE "aws.*deploy|aws.*update|aws.*delete|aws.*terminate"; then
  INTENT="aws deploy infrastructure"
elif echo "$CMD" | grep -qE "secret|credential|rotate|revoke|vault"; then
  INTENT="secret rotation credentials"
elif echo "$CMD" | grep -qE "docker.*push|docker.*deploy|docker.*prod"; then
  INTENT="docker deploy production"
elif echo "$CMD" | grep -qE "pg_dump|mysqldump|mongodump|pg_restore|mongorestore"; then
  INTENT="database backup restore"
elif echo "$CMD" | grep -qE "npm publish|pip publish|cargo publish|gem push"; then
  INTENT="publish package release"
fi

[ -z "$INTENT" ] && exit 0

MEMORIES=$(deja search "$INTENT" 2>/dev/null || true)

[ -z "$MEMORIES" ] && exit 0

jq -n --arg ctx "$MEMORIES" '{
  "systemMessage": ("[deja recall — command failed, related gotchas]\n" + $ctx)
}'
"""

_SESSION_END_HOOK_SCRIPT = r"""#!/usr/bin/env bash
# deja-session-end.sh — session-end hook for Claude Code
#
# Fires when the Claude Code session ends (including /exit). Reads the
# transcript path from stdin JSON and runs `deja save-session --transcript`
# to automatically extract and save memories from the session.
#
# Requires a provider configured: deja config set provider anthropic
# (or openai, google, etc.). Exits silently if no provider is set.

set -euo pipefail

INPUT=$(cat)
TRANSCRIPT=$(echo "$INPUT" | jq -r '.transcript_path // ""')
CWD=$(echo "$INPUT"        | jq -r '.cwd // ""')

[ -z "$TRANSCRIPT" ] && exit 0
[ ! -f "$TRANSCRIPT" ] && exit 0

PROJECT=$(basename "$CWD")

CMD=(deja save-session --transcript "$TRANSCRIPT")
[ -n "$PROJECT" ] && CMD+=(--project "$PROJECT")

if timeout 55s "${CMD[@]}" 2>/dev/null; then
    echo "[deja] Session memories saved."
else
    EXIT=$?
    if [ $EXIT -eq 124 ]; then
        echo "[deja] save-session timed out — running in background." >&2
        nohup "${CMD[@]}" >/dev/null 2>&1 &
    fi
fi
"""

_PRECOMPACT_HOOK_SCRIPT = r"""#!/usr/bin/env bash
# deja-precompact.sh — PreCompact hook for Claude Code
#
# Fires before context compaction. Loads the most relevant deja memories and
# injects them as additionalContext so they survive the compaction summary.
# Without this, the agent loses memory orientation after every compact.

set -euo pipefail

INPUT=$(cat)
CWD=$(echo "$INPUT" | jq -r '.cwd // ""')
PROJECT=$(basename "$CWD")

MEMORIES=$(deja load --project "$PROJECT" --context "context compaction in progress" 2>/dev/null || true)

[ -z "$MEMORIES" ] && exit 0

jq -n --arg ctx "$MEMORIES" '{
  "additionalContext": ("[deja — memories to carry through compaction]\n" + $ctx)
}'
"""

_DEJA_BLOCK_MARKER = "## Deja"

_AGENT_CONFIGS: dict[str, dict] = {
    "claude-code": {
        "global": Path("~/.claude/CLAUDE.md"),
        "project": Path("./CLAUDE.md"),
    },
    "gemini-cli": {
        "global": Path("~/.gemini/GEMINI.md"),
        "project": Path("./GEMINI.md"),
    },
    "codex": {
        "global": Path("~/.codex/AGENTS.md"),
        "project": Path("./AGENTS.md"),
    },
    "cursor": {
        "global": Path("~/.cursor/rules/deja.md"),
        "project": Path("./.cursorrules"),
    },
    "windsurf": {
        "global": None,
        "project": Path("./.windsurfrules"),
    },
}


def _build_deja_block(project: Optional[str]) -> str:
    project_flag = f" --project {project}" if project else ""
    session_cmd = f"deja save-session --project {project}" if project else "deja save-session"
    return (
        f"## Deja\n"
        f"\n"
        f"At session START: run `deja load{project_flag} --context \"<brief description of what you're working on>\"`"
        f" and read the output. Assemble the context string from the user's first message, CWD, and"
        f" primary language before running the command.\n"
        f"\n"
        f"DURING the session, run `deja save` when you discover:\n"
        f"- Something that took >10 min to figure out    → --type gotcha\n"
        f"- A non-obvious architectural decision          → --type decision\n"
        f"- A pattern reusable across files/projects      → --type pattern\n"
        f"- A significant chunk of work completed         → --type progress\n"
        f"- A user preference                             → --type preference\n"
        f"\n"
        f"At session END: run `{session_cmd}` to flush remaining context."
    )


def _inject_block(path: Path, block: str, force: bool) -> str:
    """Inject or replace the deja block in a config file.

    Returns "injected" | "replaced" | "already_configured".
    """
    if path.exists():
        content = path.read_text(encoding="utf-8")
        has_marker = ("\n## Deja\n" in content or content.startswith("## Deja\n"))
        if has_marker:
            if not force:
                return "already_configured"
            lines = content.split("\n")
            start = None
            for i, line in enumerate(lines):
                if line == _DEJA_BLOCK_MARKER:
                    start = i
                    break
            if start is None:
                pass
            else:
                end = len(lines)
                for i in range(start + 1, len(lines)):
                    if lines[i].startswith("## "):
                        end = i
                        break
                while end > start + 1 and lines[end - 1] == "":
                    end -= 1
                block_lines = block.split("\n")
                new_lines = lines[:start] + block_lines + lines[end:]
                path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
                return "replaced"
        sep = "\n" if content.endswith("\n") else "\n\n"
        if content.endswith("\n\n"):
            sep = ""
        path.write_text(content + sep + block + "\n", encoding="utf-8")
        return "injected"
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(block + "\n", encoding="utf-8")
        return "injected"


def _detect_claude_plugin() -> list[str]:
    """Return a list of human-readable signals indicating the Claude Code plugin is active.

    Checks four independent sources so partial installs are also caught:
      1. ## Memory (deja) block in ~/.claude/CLAUDE.md (written by session-start.sh)
      2. enabledPlugins entry containing "deja" in ~/.claude/settings.json
      3. installed_plugins.json in ~/.claude/plugins/ containing a "deja" entry
      4. CLAUDE_PLUGIN_ROOT hook commands in ~/.claude/settings.json (plugin-registered hooks)
    """
    signals: list[str] = []

    claude_md = Path("~/.claude/CLAUDE.md").expanduser()
    if claude_md.exists():
        try:
            content = claude_md.read_text(encoding="utf-8")
            if "\n## Memory (deja)\n" in content or content.startswith("## Memory (deja)\n"):
                signals.append("## Memory (deja) block found in ~/.claude/CLAUDE.md")
        except OSError:
            pass

    settings_path = Path("~/.claude/settings.json").expanduser()
    settings_text = ""
    settings: dict = {}
    if settings_path.exists():
        try:
            settings_text = settings_path.read_text(encoding="utf-8")
            settings = json.loads(settings_text)
        except (OSError, json.JSONDecodeError):
            pass

    for key, enabled in settings.get("enabledPlugins", {}).items():
        if "deja" in key.lower() and enabled:
            signals.append(f"plugin '{key}' enabled in ~/.claude/settings.json (enabledPlugins)")

    installed_plugins_path = Path("~/.claude/plugins/installed_plugins.json").expanduser()
    if installed_plugins_path.exists():
        try:
            registry = json.loads(installed_plugins_path.read_text(encoding="utf-8"))
            for key in registry.get("plugins", {}):
                if "deja" in key.lower():
                    signals.append(
                        f"plugin '{key}' found in ~/.claude/plugins/installed_plugins.json"
                    )
        except (OSError, json.JSONDecodeError):
            pass

    if "CLAUDE_PLUGIN_ROOT" in settings_text:
        signals.append(
            "plugin hook commands (CLAUDE_PLUGIN_ROOT) found in ~/.claude/settings.json"
        )

    return signals


def _detect_deja_setup(target_path: Path, agent: str) -> list[str]:
    """Return signals indicating deja setup has already been run for this agent/path.

    Checks the config file for the ## Deja block, and for claude-code additionally
    checks for hook scripts and settings.json registrations.
    """
    signals: list[str] = []
    display = str(target_path).replace(str(Path.home()), "~")

    if target_path.exists():
        try:
            content = target_path.read_text(encoding="utf-8")
            if "\n## Deja\n" in content or content.startswith("## Deja\n"):
                signals.append(f"## Deja block found in {display}")
        except OSError:
            pass

    if agent != "claude-code":
        return signals

    hooks_dir = Path("~/.claude/hooks").expanduser()
    for name in ("deja-recall.sh", "deja-post-fail.sh", "deja-session-end.sh", "deja-precompact.sh"):
        if (hooks_dir / name).exists():
            signals.append(f"{name} found in ~/.claude/hooks/")

    settings_path = Path("~/.claude/settings.json").expanduser()
    if settings_path.exists():
        try:
            settings_text = settings_path.read_text(encoding="utf-8")
            for name in ("deja-recall.sh", "deja-post-fail.sh", "deja-session-end.sh", "deja-precompact.sh"):
                if name in settings_text:
                    signals.append(f"{name} registered in ~/.claude/settings.json")
        except OSError:
            pass

    return signals


def _install_claude_hooks() -> None:
    """Write hook scripts and register them in ~/.claude/settings.json."""
    hooks_dir = Path("~/.claude/hooks").expanduser()
    hooks_dir.mkdir(parents=True, exist_ok=True)

    recall_path = hooks_dir / "deja-recall.sh"
    post_fail_path = hooks_dir / "deja-post-fail.sh"
    session_end_path = hooks_dir / "deja-session-end.sh"
    precompact_path = hooks_dir / "deja-precompact.sh"

    for path, content in [
        (recall_path, _RECALL_HOOK_SCRIPT.lstrip("\n")),
        (post_fail_path, _POST_FAIL_HOOK_SCRIPT.lstrip("\n")),
        (session_end_path, _SESSION_END_HOOK_SCRIPT.lstrip("\n")),
        (precompact_path, _PRECOMPACT_HOOK_SCRIPT.lstrip("\n")),
    ]:
        path.write_text(content, encoding="utf-8")
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        display = str(path).replace(str(Path.home()), "~")
        typer.echo(f"deja: hooks installed → {display}")

    settings_path = Path("~/.claude/settings.json").expanduser()
    settings_text = settings_path.read_text(encoding="utf-8") if settings_path.exists() else ""
    try:
        settings = json.loads(settings_text) if settings_text.strip() else {}
    except json.JSONDecodeError:
        settings = {}

    hooks_obj = settings.setdefault("hooks", {})
    changed = False

    if "deja-recall.sh" not in settings_text:
        hooks_obj.setdefault("PreToolUse", []).append({
            "matcher": "Bash",
            "hooks": [{"type": "command", "command": "~/.claude/hooks/deja-recall.sh"}],
        })
        changed = True

    if "deja-post-fail.sh" not in settings_text:
        hooks_obj.setdefault("PostToolUse", []).append({
            "matcher": "Bash",
            "hooks": [{"type": "command", "command": "~/.claude/hooks/deja-post-fail.sh"}],
        })
        changed = True

    if "deja-session-end.sh" not in settings_text:
        hooks_obj.setdefault("SessionEnd", []).append({
            "hooks": [{"type": "command", "command": "~/.claude/hooks/deja-session-end.sh"}],
        })
        changed = True

    if "deja-precompact.sh" not in settings_text:
        hooks_obj.setdefault("PreCompact", []).append({
            "hooks": [{"type": "command", "command": "~/.claude/hooks/deja-precompact.sh"}],
        })
        changed = True

    if changed:
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
        typer.echo("deja: settings.json updated → hooks registered")


def register(app: typer.Typer) -> None:

    @app.command()
    def setup(
        agent: str = typer.Argument(..., help="Agent: claude-code, gemini-cli, codex, cursor, windsurf"),
        project: Optional[str] = typer.Option(None, "--project", help="Write to local project config instead of global"),
        hooks: bool = typer.Option(True, "--hooks/--no-hooks", help="Install hooks for claude-code (use --no-hooks to skip)"),
        force: bool = typer.Option(False, "--force", help="Overwrite existing deja block"),
    ):
        """Inject the deja memory protocol into an agent's config file.

        Without --project, writes to the agent's global config (~/.claude/CLAUDE.md etc.).
        With --project <name>, writes to the local project config (./CLAUDE.md etc.) and
        scopes deja load/save-session to that project name.
        """
        if agent not in _AGENT_CONFIGS:
            valid = ", ".join(sorted(_AGENT_CONFIGS.keys()))
            typer.echo(f"deja: unknown agent '{agent}'. Valid: {valid}", err=True)
            raise typer.Exit(1)

        if agent == "claude-code":
            signals = _detect_claude_plugin()
            if signals:
                lines = ["deja: Claude Code plugin installation detected — stopping."]
                lines.append("The plugin and `deja setup` are separate paths; use one, not both.")
                lines.append("Signals found:")
                for s in signals:
                    lines.append(f"  • {s}")
                lines.append(
                    "To switch to the manual path: uninstall the plugin, remove the "
                    "## Memory (deja) block from ~/.claude/CLAUDE.md, then re-run."
                )
                typer.echo("\n".join(lines), err=True)
                raise typer.Exit(1)

        cfg = _AGENT_CONFIGS[agent]

        if project:
            raw_path: Optional[Path] = cfg["project"]
        else:
            raw_path = cfg.get("global")
            if raw_path is None:
                typer.echo(
                    f"deja: {agent} has no known global config path. "
                    f"Use --project <name> to write to a local project config.",
                    err=True,
                )
                raise typer.Exit(1)

        target_path = raw_path.expanduser()
        display = str(target_path).replace(str(Path.home()), "~")

        if agent == "claude-code" and hooks:
            _install_claude_hooks()

        setup_signals = _detect_deja_setup(target_path, agent)
        if setup_signals and not force:
            lines = [f"deja: {agent} already configured — stopping."]
            lines.append("Signals found:")
            for s in setup_signals:
                lines.append(f"  • {s}")
            lines.append("Use --force to update.")
            typer.echo("\n".join(lines))
            raise typer.Exit(0)

        block = _build_deja_block(project)
        result = _inject_block(target_path, block, force)

        if result == "replaced":
            typer.echo(f"deja: {agent} configured (updated) → {display}")
        else:
            typer.echo(f"deja: {agent} configured → {display}")
