from __future__ import annotations

import asyncio
import gzip
import json
from pathlib import Path
from typing import Optional

import typer
from ulid import ULID

from ._helpers import _get_config, _get_store, _prepare_import_memory

VALID_MERGE_STRATEGIES = {"skip", "overwrite", "update-confidence"}


def register(app: typer.Typer) -> None:

    @app.command()
    def export(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Export only this project's memories."),
        type: Optional[str] = typer.Option(None, "--type", "-t", help="Comma-separated list of memory types to include."),
        output: str = typer.Option("memories.jsonl", "--output", "-o", help="Output file path."),
        compress: bool = typer.Option(False, "--compress", help="Compress output with gzip."),
        include_archived: bool = typer.Option(False, "--include-archived", help="Include archived memories."),
    ):
        """Export memories to a JSONL file.

        Format: JSONL (one memory per line).
        Filters: --project, --type, --include-archived.
        Compression: --compress (gzip).
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                types = type.split(",") if type else None
                memories = await store.list_for_export(project, types, include_archived)
                return memories
            finally:
                await store.close()

        memories = asyncio.run(_run())

        if not memories:
            typer.echo("No memories found to export.")
            return

        output_path = Path(output)
        if compress and not output_path.suffix == ".gz":
            output_path = output_path.with_suffix(output_path.suffix + ".gz")

        open_fn = gzip.open if compress or output_path.suffix == ".gz" else open
        mode = "wt" if not (compress or output_path.suffix == ".gz") else "wb"

        try:
            with open_fn(output_path, mode) as f:
                for mem in memories:
                    line = json.dumps(mem, default=str) + "\n"
                    if "b" in mode:
                        f.write(line.encode("utf-8"))
                    else:
                        f.write(line)
            typer.echo(f"Exported {len(memories)} memories to {output_path}")
        except Exception as e:
            typer.echo(f"Export failed: {e}", err=True)
            raise typer.Exit(1)

    @app.command(name="import")
    def import_cmd(
        file: Path = typer.Argument(..., help="Path to the JSONL file to import."),
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Overwrite scope and project for all imported memories."),
        dry_run: bool = typer.Option(False, "--dry-run", help="Preview what would happen without modifying the database."),
        merge_strategy: str = typer.Option("skip", "--merge-strategy", "-m", help="Strategy for handling ID collisions: skip|overwrite|update-confidence"),
    ):
        """Import memories from a JSONL file.

        Format: JSONL or JSONL.gz (auto-detected).
        Strategies: skip (default), overwrite, update-confidence.
        """
        if not file.exists():
            typer.echo(f"Import file not found: {file}", err=True)
            raise typer.Exit(1)
        merge_strategy = merge_strategy.strip().lower()
        if merge_strategy not in VALID_MERGE_STRATEGIES:
            typer.echo(
                f"Invalid merge strategy: {merge_strategy}. "
                "Use one of: skip, overwrite, update-confidence",
                err=True,
            )
            raise typer.Exit(1)

        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()

            stats = {
                "inserted": 0,
                "skipped": 0,
                "updated": 0,
                "overwritten": 0,
                "invalid": 0,
            }

            try:
                is_gz = file.suffix == ".gz"
                open_fn = gzip.open if is_gz else open
                mode = "rt" if not is_gz else "rb"

                with open_fn(file, mode) as f:
                    for line_no, line_bytes in enumerate(f, start=1):
                        line = line_bytes.decode("utf-8") if is_gz else line_bytes
                        if not line.strip():
                            continue

                        try:
                            raw_memory = json.loads(line)
                        except json.JSONDecodeError:
                            typer.echo(
                                f"Warning: skipped malformed line {line_no} in {file}",
                                err=True,
                            )
                            stats["invalid"] += 1
                            continue

                        memory, validation_error = _prepare_import_memory(raw_memory, project)
                        if validation_error:
                            typer.echo(
                                f"Warning: skipped invalid line {line_no} in {file}: {validation_error}",
                                err=True,
                            )
                            stats["invalid"] += 1
                            continue

                        existing = await store.get(memory["id"])
                        if project and existing:
                            target_scope = f"project:{project}"
                            existing_scope = existing.get("scope")
                            existing_project = existing.get("project")
                            if existing_scope != target_scope or existing_project != project:
                                memory["id"] = str(ULID())
                                existing = None

                        if dry_run:
                            if not existing:
                                stats["inserted"] += 1
                            elif merge_strategy == "skip":
                                stats["skipped"] += 1
                            elif merge_strategy == "overwrite":
                                stats["overwritten"] += 1
                            elif merge_strategy == "update-confidence":
                                if memory["content"] == existing["content"]:
                                    stats["updated"] += 1
                                else:
                                    stats["skipped"] += 1
                        else:
                            result = await store.upsert(memory, merge_strategy)
                            stats[result] += 1

                return stats
            finally:
                await store.close()

        stats = asyncio.run(_run())

        action = "Would import" if dry_run else "Imported"
        total = stats["inserted"] + stats["skipped"] + stats["updated"] + stats["overwritten"]
        typer.echo(f"{action}: {total} memories")
        if stats["inserted"]:
            typer.echo(f"  - {stats['inserted']} new ({'would insert' if dry_run else 'inserted'})")
        if stats["skipped"]:
            typer.echo(f"  - {stats['skipped']} already exist ({'would skip' if dry_run else 'skipped'})")
        if stats["updated"]:
            typer.echo(f"  - {stats['updated']} confidence bumped ({'would update' if dry_run else 'updated'})")
        if stats["overwritten"]:
            typer.echo(f"  - {stats['overwritten']} records replaced ({'would overwrite' if dry_run else 'overwritten'})")
        if stats["invalid"]:
            typer.echo(f"  - {stats['invalid']} invalid records ({'would skip' if dry_run else 'skipped'})")
