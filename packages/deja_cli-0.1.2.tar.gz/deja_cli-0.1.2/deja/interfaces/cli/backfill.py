from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Optional

import typer

from deja.core.extractor import extract_memories
from deja.llm.factory import create_adapter, create_embedding_adapter
from ._helpers import _get_config, _get_store, _embed_and_save


def _get_project_name_from_dir(project_dir: Path) -> str:
    """Resolve a human-readable project name from a ~/.claude/projects/<hash> dir.

    Priority:
    1. sessions-index.json → entries[0].projectPath → basename
    2. First .jsonl file → cwd field → basename
    3. Reconstruct from dir name (/ → - encoding); check if path exists on disk
    4. Last hyphen-delimited token of dir name
    """
    index_file = project_dir / "sessions-index.json"
    if index_file.exists():
        try:
            data = json.loads(index_file.read_text(encoding="utf-8"))
            for entry in data.get("entries", []):
                pp = entry.get("projectPath")
                if pp:
                    return Path(pp).name
        except Exception:
            pass

    for jsonl_file in sorted(project_dir.glob("*.jsonl")):
        try:
            for raw in jsonl_file.read_text(encoding="utf-8", errors="replace").splitlines():
                d = json.loads(raw)
                cwd = d.get("cwd")
                if cwd:
                    return Path(cwd).name
        except Exception:
            continue

    raw = project_dir.name
    reconstructed = Path("/" + raw.lstrip("-").replace("-", "/"))
    if reconstructed.exists():
        return reconstructed.name
    return raw.split("-")[-1] or raw


def _sessions_index_transcript(index_path: Path) -> str:
    """Build a lightweight transcript from sessions-index.json per-session metadata."""
    try:
        data = json.loads(index_path.read_text(encoding="utf-8"))
        parts = []
        for entry in data.get("entries", []):
            summary = (entry.get("summary") or "").strip()
            first_prompt = (entry.get("firstPrompt") or "").strip()
            if summary or first_prompt:
                parts.append(f"Session summary: {summary}\nUser's first message: {first_prompt}")
        return "\n\n---\n\n".join(parts)
    except Exception:
        return ""


def _parse_jsonl_transcript(jsonl_path: Path, max_chars: int = 30_000) -> str:
    """Extract a readable transcript from a Claude Code .jsonl session file.

    Keeps user messages and assistant text blocks; skips thinking blocks and
    tool results to keep the text focused.
    """
    turns = []
    try:
        for raw in jsonl_path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                d = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if d.get("type") not in ("user", "assistant"):
                continue

            msg = d.get("message", {})
            role = msg.get("role", d["type"])
            content = msg.get("content", "")

            if isinstance(content, str):
                text = content.strip()
            elif isinstance(content, list):
                parts = [
                    item.get("text", "").strip()
                    for item in content
                    if isinstance(item, dict) and item.get("type") == "text"
                ]
                text = "\n".join(p for p in parts if p)
            else:
                continue

            if text:
                turns.append(f"{role.capitalize()}: {text}")
    except Exception:
        return ""

    full = "\n\n".join(turns)
    return full[:max_chars]


def register(app: typer.Typer) -> None:

    @app.command()
    def backfill(
        project: Optional[str] = typer.Option(
            None, "--project", "-p",
            help="Only backfill this project. Omit to backfill all projects."
        ),
        include_sessions: Optional[bool] = typer.Option(
            None, "--include-sessions/--no-include-sessions", "-s/-S",
            help="Process full .jsonl session transcripts. Defaults to True in --agent-mode, False otherwise."
        ),
        dry_run: bool = typer.Option(
            False, "--dry-run",
            help="Show what would be processed without calling the LLM or saving."
        ),
        agent_mode: bool = typer.Option(
            False, "--agent-mode",
            help=(
                "Print session content + instructions for the active agent to extract memories. "
                "No LLM API call needed — the agent running IS the model. "
                "Defaults --include-sessions to True."
            ),
        ),
        claude_dir: str = typer.Option(
            "~/.claude/projects",
            "--claude-dir",
            help="Path to the Claude projects directory.",
        ),
    ):
        """Backfill memories from existing Claude Code session history.

        Processes for each project (in order):
          1. session-memory/summary.md files (structured session summaries)
          2. sessions-index.json per-session summaries (lightweight, one LLM call per project)
          3. Full .jsonl session transcripts (with --include-sessions or --agent-mode)

        --agent-mode: prints all session content to stdout with deja save instructions.
        The active coding agent reads the output and calls deja save for each memory.
        No API key required — the agent already running is the LLM.

        Deduplication is handled automatically — re-running backfill is safe.
        Without --agent-mode, requires extraction.provider set in ~/.deja/config.yaml.
        """
        effective_include_sessions = include_sessions if include_sessions is not None else agent_mode

        projects_root = Path(claude_dir).expanduser()
        if not projects_root.exists():
            typer.echo(f"Claude projects directory not found: {projects_root}", err=True)
            raise typer.Exit(1)

        # ── Agent mode: dump content + instructions, no LLM call ─────────────────
        if agent_mode:
            from deja.core.extractor import EXTRACTION_SYSTEM

            project_dirs = sorted(p for p in projects_root.iterdir() if p.is_dir())
            total_sources = 0

            for project_dir in project_dirs:
                proj_name = _get_project_name_from_dir(project_dir)

                if project and proj_name != project:
                    continue

                typer.echo(f"\n{'='*60}")
                typer.echo(f"=== Backfill: {proj_name} ===")
                typer.echo(f"{'='*60}\n")

                for summary_file in sorted(project_dir.rglob("session-memory/summary.md")):
                    content = summary_file.read_text(encoding="utf-8", errors="replace").strip()
                    if not content:
                        continue
                    total_sources += 1
                    typer.echo(f"--- summary.md ---")
                    typer.echo(content)
                    typer.echo()

                index_file = project_dir / "sessions-index.json"
                if index_file.exists():
                    transcript = _sessions_index_transcript(index_file)
                    if transcript.strip():
                        try:
                            entry_count = len(json.loads(index_file.read_text()).get("entries", []))
                        except Exception:
                            entry_count = "?"
                        total_sources += 1
                        typer.echo(f"--- sessions-index.json ({entry_count} sessions) ---")
                        typer.echo(transcript)
                        typer.echo()

                if effective_include_sessions:
                    jsonl_files = sorted(
                        f for f in project_dir.glob("*.jsonl")
                        if f.parent.name != "subagents"
                    )
                    for jsonl_file in jsonl_files:
                        transcript = _parse_jsonl_transcript(jsonl_file)
                        if not transcript.strip():
                            continue
                        total_sources += 1
                        typer.echo(f"--- {jsonl_file.name} ---")
                        typer.echo(transcript)
                        typer.echo()

            if total_sources == 0:
                typer.echo("No session content found to process.")
                return

            project_flag = f" --project {project}" if project else ""
            typer.echo(f"\n{'='*60}")
            typer.echo("=== Instructions ===")
            typer.echo(f"{'='*60}")
            typer.echo(
                f"\nReview all session content above and identify memories worth keeping.\n\n"
                f"{EXTRACTION_SYSTEM}\n\n"
                f"For each memory you identify, call:\n"
                f"  deja save \"<content>\" --type <type>{project_flag}\n"
                f"  (omit --project for global memories that apply across all projects)\n\n"
                f"Only save things that are non-obvious, reusable, and important.\n"
                f"If nothing is worth saving, do nothing.\n"
                f"\n({total_sources} sources printed above)"
            )
            return

        # ── Auto mode: use configured LLM ────────────────────────────────────────
        async def _run():
            config = _get_config()
            if dry_run:
                adapter = None
            else:
                adapter = await create_adapter(config, "extraction")
                if adapter is None:
                    typer.echo(
                        "No LLM configured for extraction. Set extraction.provider in "
                        "~/.deja/config.yaml, or use --agent-mode to let the "
                        "active coding agent extract memories without an API call.",
                        err=True,
                    )
                    raise typer.Exit(1)

            store = _get_store(config)
            await store.init_db()
            embedding_adapter = await create_embedding_adapter(config)

            total_sources = 0
            total_memories = 0

            try:
                project_dirs = sorted(p for p in projects_root.iterdir() if p.is_dir())

                for project_dir in project_dirs:
                    proj_name = _get_project_name_from_dir(project_dir)

                    if project and proj_name != project:
                        continue

                    typer.echo(f"\nProject: {proj_name}  ({project_dir.name})")

                    for summary_file in sorted(project_dir.rglob("session-memory/summary.md")):
                        total_sources += 1
                        content = summary_file.read_text(encoding="utf-8", errors="replace").strip()
                        if not content:
                            typer.echo(f"  summary.md  (empty, skipped)")
                            continue

                        if dry_run:
                            typer.echo(f"  [dry-run] summary.md  ({len(content)} chars)")
                            continue

                        memories = await extract_memories(content, proj_name, "backfill", adapter)
                        total_memories += await _embed_and_save(memories, store, embedding_adapter)
                        typer.echo(f"  summary.md  → {len(memories)} memories")

                    index_file = project_dir / "sessions-index.json"
                    if index_file.exists():
                        total_sources += 1
                        transcript = _sessions_index_transcript(index_file)
                        if not transcript.strip():
                            typer.echo(f"  sessions-index.json  (no summaries, skipped)")
                        elif dry_run:
                            entry_count = len(json.loads(index_file.read_text()).get("entries", []))
                            typer.echo(f"  [dry-run] sessions-index.json  ({entry_count} sessions)")
                        else:
                            entry_count = len(json.loads(index_file.read_text()).get("entries", []))
                            memories = await extract_memories(transcript, proj_name, "backfill", adapter)
                            total_memories += await _embed_and_save(memories, store, embedding_adapter)
                            typer.echo(f"  sessions-index.json  ({entry_count} sessions) → {len(memories)} memories")

                    if effective_include_sessions:
                        jsonl_files = sorted(
                            f for f in project_dir.glob("*.jsonl")
                            if f.parent.name != "subagents"
                        )
                        for jsonl_file in jsonl_files:
                            total_sources += 1
                            transcript = _parse_jsonl_transcript(jsonl_file)
                            if not transcript.strip():
                                continue

                            if dry_run:
                                typer.echo(f"  [dry-run] {jsonl_file.name}  ({len(transcript)} chars)")
                                continue

                            memories = await extract_memories(transcript, proj_name, "backfill", adapter)
                            total_memories += await _embed_and_save(memories, store, embedding_adapter)
                            typer.echo(f"  {jsonl_file.name}  → {len(memories)} memories")

            finally:
                await store.close()

            return total_sources, total_memories

        total_sources, total_memories = asyncio.run(_run())
        typer.echo(f"\nDone. {total_sources} sources processed, {total_memories} memories saved.")
