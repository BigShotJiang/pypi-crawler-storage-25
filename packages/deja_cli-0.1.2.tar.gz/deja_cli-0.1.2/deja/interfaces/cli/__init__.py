from __future__ import annotations

import typer

from . import memory, session, transfer, maintenance, backfill, watch, cloud
from . import setup as setup_mod
from ._helpers import _embed_and_save, _format_load_result  # re-exported for backwards compat

app = typer.Typer(name="deja", help="Deja — persistent coding memory CLI")

memory.register(app)
session.register(app)
transfer.register(app)
maintenance.register(app)
backfill.register(app)
watch.register(app)
setup_mod.register(app)
cloud.register(app)

__all__ = ["app", "_embed_and_save", "_format_load_result"]
