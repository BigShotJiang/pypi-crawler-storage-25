from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Optional

import typer

from ._helpers import _get_config, _get_store


def register(app: typer.Typer) -> None:

    @app.command()
    def login(
        token: Optional[str] = typer.Option(None, "--token", "-t", help="Paste a PAT directly (skips browser, for headless/CI)."),
        endpoint: Optional[str] = typer.Option(None, "--endpoint", help="Custom API endpoint, e.g. http://localhost:3001"),
    ):
        """Log in to deja.sh cloud sync.

        Opens deja.sh in your browser. If you're already logged in, authorization
        completes instantly with no clicks required.

        For headless / CI environments, pass a token directly:

          deja login --token deja_<your_token>
        """
        from deja.cloud import save_auth, whoami as cloud_whoami, clear_auth

        config = _get_config()
        if endpoint:
            config.cloud.endpoint = endpoint

        if token:
            if not token.startswith("deja_"):
                typer.echo("Invalid token: must start with 'deja_'.", err=True)
                raise typer.Exit(1)
            pat = token
        else:
            from deja.cloud import login_browser
            try:
                pat = login_browser(config)
            except Exception as e:
                typer.echo(f"Login failed: {e}", err=True)
                raise typer.Exit(1)

        save_auth({"access_token": pat})

        try:
            user = cloud_whoami(config)
            if not user:
                raise RuntimeError("/auth/me returned nothing — token may be invalid")
            typer.echo(f"Logged in as {user.get('email', 'unknown')}")
        except Exception as e:
            clear_auth()
            typer.echo(f"Login failed: {e}", err=True)
            raise typer.Exit(1)

    @app.command()
    def logout():
        """Log out of deja.sh and remove local credentials."""
        from deja.cloud import clear_auth, load_auth

        if not load_auth():
            typer.echo("Not logged in.")
            return

        clear_auth()
        typer.echo("Logged out.")

    @app.command()
    def whoami():
        """Show the currently logged-in deja.sh account."""
        from deja.cloud import whoami as cloud_whoami

        config = _get_config()
        user = cloud_whoami(config)
        if not user:
            typer.echo("Not logged in. Run `deja login`.")
            return

        typer.echo(f"Email:    {user.get('email', 'unknown')}")
        typer.echo(f"Plan:     {user.get('plan', 'unknown')}")
        typer.echo(f"Memories: {user.get('memoryCount', 'unknown')}")

    @app.command()
    def sync(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Scope push to this project only."),
        push_only: bool = typer.Option(False, "--push", help="Push local changes only, skip pull."),
        pull_only: bool = typer.Option(False, "--pull", help="Pull cloud changes only, skip push."),
    ):
        """Sync memories with deja.sh cloud (push local + pull remote)."""
        from deja.cloud import (
            get_token, sync_push, sync_pull,
            load_sync_state, save_sync_state,
        )

        config = _get_config()
        if not get_token(config):
            typer.echo("Not logged in. Run `deja login`.", err=True)
            raise typer.Exit(1)

        async def _run():
            store = _get_store(config)
            await store.init_db()
            state = load_sync_state()
            endpoint = config.cloud.endpoint
            last_synced = state.get(endpoint)
            pushed = 0
            pulled = 0

            try:
                if not pull_only:
                    all_memories = await store.list_all()
                    if project:
                        all_memories = [m for m in all_memories if m.get("project") == project]
                    if last_synced:
                        cutoff = datetime.fromisoformat(last_synced).replace(tzinfo=timezone.utc)
                        to_push = [
                            m for m in all_memories
                            if datetime.fromisoformat(
                                m.get("updated_at", "1970-01-01")
                            ).replace(tzinfo=timezone.utc) > cutoff
                        ]
                    else:
                        to_push = all_memories

                    if to_push:
                        result = sync_push(to_push, config)
                        pushed = result.get("accepted", 0)

                if not push_only:
                    result = sync_pull(since=last_synced, config=config)
                    cloud_memories = result.get("memories", [])
                    server_time = result.get("serverTime")

                    for m in cloud_memories:
                        await store.upsert(m, merge_strategy="update-confidence")
                    pulled = len(cloud_memories)

                    if server_time:
                        state[endpoint] = server_time
                        save_sync_state(state)

            finally:
                await store.close()

            return pushed, pulled

        pushed, pulled = asyncio.run(_run())
        typer.echo(f"Sync complete. Pushed: {pushed}, pulled: {pulled}")
