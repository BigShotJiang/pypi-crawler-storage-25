# deja

Local-first persistent memory CLI for coding agents. Memories accumulate across sessions, deduplicate automatically, and stay on your machine.

## Install

```bash
uv tool install deja-cli
```

## Quick Start

```bash
deja init                        # first-time setup
deja setup claude-code           # inject memory instructions into Claude Code
```

## Core Commands

**Save a memory:**
```bash
deja save "Always use explicit error handling over try/catch" --type preference
deja save "Auth tokens stored in localStorage, not cookies" --type decision --project myapp
deja save "Prisma migrations fail silently if DB_URL has wrong port" --type gotcha --project myapp
```

**Load at session start:**
```bash
deja load --project myapp --context "what you're working on"
```

**Search mid-session:**
```bash
deja search "authentication" --project myapp
```

**Extract memories from a session:**
```bash
deja save-session --project myapp
```

## Memory Types

| Type | When to use |
|---|---|
| `preference` | How you like to code — style, tools, habits |
| `pattern` | Reusable solution that applies across contexts |
| `decision` | Non-obvious architectural choice with reasoning |
| `gotcha` | Bug, trap, or non-obvious issue to avoid |
| `progress` | Current state of in-progress work |
| `procedure` | Ordered steps for a recurring task |

## Setup for Coding Agents

```bash
deja setup claude-code     # Claude Code — global config + recall hooks
deja setup gemini-cli      # Gemini CLI
deja setup codex           # Codex CLI
deja setup cursor          # Cursor
```

## MCP Server

```bash
claude mcp add --scope user deja -- ~/.local/bin/deja-mcp
```

Registers `memory_load`, `memory_save`, and `memory_search` as native tools in every Claude Code session.
