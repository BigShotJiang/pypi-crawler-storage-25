# NeuralBridge SDK

**Self-healing decision engine for LLM APIs** — Automatic fault diagnosis, cascade recovery, and predictive model switching.

## Version 0.3.3

### Features

- **LLM Fault Semantic Diagnosis**: Automatically identifies 46+ LLM-specific error categories across OpenAI, Azure, Anthropic, Google, DashScope/DeepSeek
- **4-Level Cascade Recovery**: Hierarchical retry strategy — fast retry → wait with jitter → model fallback → circuit breaker
- **Predictive Self-Healing**: Proactively switches models based on latency/error rate trends before failures occur
- **Flywheel Learning Engine**: Learns from every error-recovery cycle, optimizing strategies over time
- **Intelligent Load Balancing**: 5 strategies (random, round-robin, weighted response time, least connections, predictive)
- **3 Jitter Algorithms**: FullJitter (AWS recommended), EqualJitter, DecorrelatedJitter
- **Request Tracing & Observability**: Full request trace log, model health metrics, recovery statistics
- **License Protection**: Feature gating (FREE/PRO/ENTERPRISE) with watermark tracking
- **Async Support**: Full async/await interface with `httpx`
- **Drop-in Replacement**: Compatible with OpenAI SDK interface

### Installation

```bash
pip install neuralbridge-sdk
```

### Quick Start

```python
from neuralbridge import NeuralBridge

# Drop-in replacement for openai.OpenAI
client = NeuralBridge(
    api_key="sk-xxx",
    fallback_models=["gpt-4o-mini", "gpt-3.5-turbo"],
    max_retries=3,
)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

### DashScope / Qwen / DeepSeek

```python
from neuralbridge import NeuralBridge

client = NeuralBridge(
    api_key="YOUR_API_KEY",
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    fallback_models=["qwen-plus", "qwen-turbo"],
)

response = client.chat.completions.create(
    model="qwen-plus",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

### Predictive Self-Healing (PRO)

```python
from neuralbridge import NeuralBridge, PredictiveConfig

client = NeuralBridge(
    api_key="sk-xxx",
    license_key="NB-PRO-xxxx-xxxx-xxxx",
    predictive_config=PredictiveConfig(
        latency_threshold_ms=2000,
        error_rate_threshold=0.1,
        auto_switch=True,
    ),
)

# Check model health proactively
prediction = client.engine.check_model_health("gpt-4o")
if prediction and prediction.should_switch:
    print(f"Switch recommended: {prediction.reason}")
```

### Flywheel Learning Engine (PRO)

```python
from neuralbridge import NeuralBridge

client = NeuralBridge(
    api_key="sk-xxx",
    license_key="NB-PRO-xxxx-xxxx-xxxx",
    enable_learning=True,
)

# The engine learns from every error-recovery cycle
# After enough observations, it extracts rules automatically
rules = client.engine._learner.get_learned_rules()
for rule in rules:
    print(f"Pattern: {rule.pattern}, Action: {rule.action}, Confidence: {rule.confidence:.1%}")

# Export/import rules for persistence
data = client.engine._learner.export_rules()
client.engine._learner.import_rules(data)
```

### Observability

```python
# Request traces
traces = client.engine.get_traces(limit=50, status="recovered")

# Model health
health = client.engine.get_health_status()
print(f"Healthy: {health.healthy}")
print(f"Active models: {health.active_models}")
print(f"Degraded: {health.degraded_models}")

# Recovery statistics
stats = client.engine.get_recovery_stats()
print(f"Total recoveries: {stats.total_recoveries}")
```

### Load Balancer (PRO)

```python
from neuralbridge import LoadBalancer, LoadBalancerConfig, LoadBalancingStrategy

lb = LoadBalancer(
    models=["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet"],
    config=LoadBalancerConfig(strategy=LoadBalancingStrategy.WEIGHTED_RESPONSE_TIME),
)

model = lb.select_model()
lb.record_result(model, latency_ms=150, success=True)
```

### License Tiers

| Feature | FREE | PRO | ENTERPRISE |
|---------|------|-----|------------|
| Basic self-heal & retry | ✅ | ✅ | ✅ |
| Error diagnosis | ✅ | ✅ | ✅ |
| Jitter backoff | ✅ | ✅ | ✅ |
| Model fallback | ✅ | ✅ | ✅ |
| Basic observability | ✅ | ✅ | ✅ |
| Predictive engine | ❌ | ✅ | ✅ |
| Flywheel learner | ❌ | ✅ | ✅ |
| Load balancer | ❌ | ✅ | ✅ |
| Advanced diagnostics | ❌ | ✅ | ✅ |
| Remote attestation | ❌ | ❌ | ✅ |
| Custom strategies | ❌ | ❌ | ✅ |
| SLA guarantee | ❌ | ❌ | ✅ |

### Performance Benchmarks

| Metric | Value |
|--------|-------|
| Timeout recovery rate | 93.4% |
| Invalid model recovery | 83.6% |
| Empty body recovery | 97.3% |
| Normal optimization | 97.6% |
| D-group (degraded) | 96.5% vs baseline 24.4% |
| Diagnosis-to-recovery latency | <10ms |

### Architecture

```
neuralbridge/
├── __init__.py          # Main exports
├── engine.py            # FlywheelEngine + DiagnosisEngine (core)
├── predictive.py        # Predictive self-healing engine
├── learner.py           # Flywheel learning engine
├── load_balancer.py     # Intelligent load balancer
├── license.py           # License & protection system
├── strategies.py        # 4 recovery strategies
├── jitter.py            # 3 Jitter algorithms
├── types.py             # Type definitions + observability types
├── async_client.py      # Async HTTP client
└── adapters/
    └── openai_adapter.py  # OpenAI drop-in replacement
```

### Recovery Cascade Levels

1. **L1 Retry**: Simple retry with same model
2. **L2 Wait**: Wait with exponential backoff and jitter
3. **L3 Switch**: Switch to fallback model
4. **L4 Heal**: Deep diagnosis and repair (auth refresh)
5. **L5 Circuit**: Circuit breaker activation

### Jitter Strategies

| Strategy | Formula | Best For |
|----------|---------|----------|
| FullJitter | `random(0, base * 2^attempt)` | Rate-limited resources (AWS recommended) |
| EqualJitter | `(base * 2^attempt / 2) + random(0, base * 2^attempt / 2)` | Balanced approach |
| DecorrelatedJitter | `random(base, 3 * last_delay)` | Varying latency |

### Supported Platforms

| Platform | Error Patterns | Status |
|----------|---------------|--------|
| OpenAI | rate limit, auth, model not found, server error | ✅ |
| Azure OpenAI | throttling, quota, deployment not found | ✅ |
| Anthropic | overloaded (529), auth, context length | ✅ |
| Google/VertexAI | resource exhausted, permission denied | ✅ |
| DashScope/Qwen | rate limit, model not found, auth | ✅ |
| DeepSeek | reasoning_content missing | ✅ |

### Contact

- Email: wgg234114134@163.com
- PyPI: https://pypi.org/project/neuralbridge-sdk/

## License

Proprietary - All rights reserved.
