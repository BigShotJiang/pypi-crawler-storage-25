"""
Setup script for NeuralBridge SDK.

NeuralBridge - Self-healing decision engine for AI API calls.

Drop-in replacement for OpenAI SDK with automatic fault diagnosis,
cascade recovery, and transparent model switching.

Usage:
    from neuralbridge import NeuralBridge

    client = NeuralBridge(api_key="sk-xxx")
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}],
    )
"""

from setuptools import setup, find_packages

# Read version from __init__.py
_version = {}
with open("neuralbridge/__init__.py") as f:
    for line in f:
        if line.startswith("__version__"):
            exec(line, _version)

# Read long description from README
try:
    with open("README.md", encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "Self-healing decision engine for AI API calls"

setup(
    name="neuralbridge-sdk",
    version=_version.get("__version__", "0.3.0"),
    description="Self-healing decision engine for AI API calls",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="NeuralBridge Team",
    author_email="team@neuralbridge.dev",
    url="https://github.com/neuralbridge/neuralbridge",
    license="MIT",
    packages=find_packages(),
    package_data={
        "neuralbridge": ["py.typed"],
    },
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=["httpx>=0.24.0"],
    extras_require={
        "async": ["httpx>=0.24.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
            "types-requests>=2.28.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Typed",
    ],
    keywords=[
        "ai", "api", "fault-tolerance", "retry", "self-healing",
        "openai", "llm", "fallback", "circuit-breaker"
    ],
    zip_safe=False,
)
