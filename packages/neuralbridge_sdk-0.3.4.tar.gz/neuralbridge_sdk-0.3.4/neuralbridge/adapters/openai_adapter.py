"""
OpenAI Adapter for NeuralBridge SDK.

Provides a drop-in replacement for openai.OpenAI with self-healing capabilities.
"""

import time
from typing import Any, Dict, List, Optional, Union, Iterator, Callable, TypeVar

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

from ..engine import FlywheelEngine
from ..types import DiagnosisResult, ErrorCategory, RecoveryRecord
from ..jitter import JitterConfig, DEFAULT_JITTER_CONFIG


T = TypeVar('T')


class NeuralBridge:
    """
    NeuralBridge - Self-healing OpenAI API client.
    
    Drop-in replacement for openai.OpenAI with automatic fault diagnosis,
    cascade recovery, and transparent model switching.
    
    Example:
        from neuralbridge import NeuralBridge
        
        client = NeuralBridge(api_key="sk-xxx")
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        fallback_models: Optional[List[str]] = None,
        max_retries: int = 3,
        timeout: float = 60.0,
        verbose: bool = False,
        jitter_config: Optional[JitterConfig] = None,
        api_key_refresher: Optional[Callable[[], str]] = None,
        httpx_client: Optional[Any] = None,
        license_key: Optional[str] = None,
        predictive_config: Optional[Any] = None,
        enable_learning: bool = False,
    ):
        """
        Initialize NeuralBridge client.
        
        Args:
            api_key: API key for OpenAI authentication
            base_url: Base URL for API endpoint (default: OpenAI)
            fallback_models: Ordered list of fallback model names
            max_retries: Maximum retry attempts per request (default: 3)
            timeout: Request timeout in seconds (default: 60.0)
            verbose: Enable verbose logging (default: False)
            jitter_config: Custom jitter configuration
            api_key_refresher: Optional function to refresh API key
            httpx_client: Optional pre-configured httpx client
            license_key: Optional license key for PRO features (predictive, learner, load balancer)
            predictive_config: Optional configuration for predictive self-healing
            enable_learning: Enable flywheel learning engine (requires PRO license)
        """
        if not HTTPX_AVAILABLE:
            raise ImportError(
                "httpx is required for NeuralBridge. "
                "Install it with: pip install httpx"
            )
        
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.verbose = verbose
        
        # Initialize the flywheel engine
        self.engine = FlywheelEngine(
            fallback_models=fallback_models,
            max_retries=max_retries,
            verbose=verbose,
            jitter_config=jitter_config,
            api_key_refresher=api_key_refresher,
            predictive_config=predictive_config,
            enable_learning=enable_learning,
            license_key=license_key,
        )
        
        # HTTP client
        self._httpx_client = httpx_client
        
        # API key getter/setter for auth refresh
        self._api_key_getter: Optional[Callable[[], str]] = None
        self._api_key_setter: Optional[Callable[[str], None]] = None
        
        if api_key_refresher:
            self._api_key_getter = lambda: self.api_key
            self._api_key_setter = lambda new_key: setattr(self, 'api_key', new_key)
    
    def _get_client(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._httpx_client is None:
            self._httpx_client = httpx.Client(
                timeout=httpx.Timeout(self.timeout),
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._httpx_client
    
    def _build_url(self, endpoint: str) -> str:
        """Build full URL for endpoint."""
        return f"{self.base_url}/{endpoint.lstrip('/')}"
    
    def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        """Handle HTTP response and raise appropriate errors."""
        if not response.is_success:
            metadata = {"status_code": response.status_code}
            
            # Check for rate limit headers
            if "retry-after" in response.headers:
                metadata["retry_after"] = float(response.headers["retry-after"])
            
            # Try to parse error body
            try:
                error_data = response.json()
                if "error" in error_data:
                    metadata["error_message"] = error_data["error"].get("message", "")
                    metadata["error_type"] = error_data["error"].get("type", "")
            except Exception:
                pass
            
            # Create appropriate error
            error_msg = f"HTTP {response.status_code}: {response.text[:500]}"
            error = HTTPError(error_msg, status_code=response.status_code, metadata=metadata)
            raise error
        
        return response.json()
    
    def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make an HTTP request with automatic healing.
        
        This is the core method that wraps all API calls with the flywheel engine.
        """
        def _make_request() -> Dict[str, Any]:
            client = self._get_client()
            url = self._build_url(endpoint)
            
            response = client.request(method, url, **kwargs)
            return self._handle_response(response)
        
        # Use engine's heal for automatic recovery
        result = self.engine.heal(
            _make_request,
            api_key_getter=self._api_key_getter,
            api_key_setter=self._api_key_setter,
        )
        
        return result
    
    def chat(self) -> "ChatCompletions":
        """Access chat completions namespace."""
        return ChatCompletions(self)
    
    def close(self) -> None:
        """Close the HTTP client."""
        if self._httpx_client:
            self._httpx_client.close()
            self._httpx_client = None
    
    def __enter__(self) -> "NeuralBridge":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()
    
    @property
    def model_performance(self) -> Dict[str, Any]:
        """Get model performance metrics."""
        return {
            model: {
                "total_calls": perf.total_calls,
                "successful_calls": perf.successful_calls,
                "failed_calls": perf.failed_calls,
                "avg_latency": perf.avg_latency,
                "reliability_score": perf.reliability_score,
            }
            for model, perf in self.engine.model_performance.items()
        }
    
    @property
    def health_status(self) -> Dict[str, Any]:
        """Get health status."""
        status = self.engine.get_health_status()
        return {
            "healthy": status.healthy,
            "active_models": status.active_models,
            "degraded_models": status.degraded_models,
            "failed_models": status.failed_models,
            "recommendations": status.recommendations,
        }


class ChatCompletions:
    """Chat completions namespace for NeuralBridge."""
    
    def __init__(self, client: NeuralBridge):
        self._client = client
    
    def create(
        self,
        model: str,
        messages: List[Dict[str, str]],
        temperature: float = 1.0,
        top_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        stop: Optional[Union[str, List[str]]] = None,
        **kwargs
    ) -> Union[Dict[str, Any], Iterator[Dict[str, Any]]]:
        """
        Create a chat completion.
        
        Args:
            model: Model identifier (e.g., "gpt-4o", "gpt-3.5-turbo")
            messages: List of message dictionaries with "role" and "content"
            temperature: Sampling temperature (0.0 to 2.0)
            top_p: Nucleus sampling parameter
            max_tokens: Maximum tokens to generate
            stream: Enable streaming responses
            stop: Stop sequences
            **kwargs: Additional OpenAI API parameters
            
        Returns:
            Chat completion response or stream iterator
        """
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
        }
        
        if top_p is not None:
            payload["top_p"] = top_p
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop is not None:
            payload["stop"] = stop
        
        # Merge additional parameters
        payload.update(kwargs)
        
        if stream:
            return self._stream(payload)
        
        return self._client._request("POST", "/chat/completions", json=payload)
    
    def _stream(self, payload: Dict[str, Any]) -> Iterator[Dict[str, Any]]:
        """Handle streaming chat completions."""
        client = self._client._get_client()
        url = self._client._build_url("/chat/completions")
        
        with client.stream("POST", url, json=payload) as response:
            if not response.is_success:
                error = HTTPError(
                    f"HTTP {response.status_code}: {response.text[:500]}",
                    status_code=response.status_code,
                )
                raise error
            
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        import json
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        continue


class HTTPError(Exception):
    """HTTP error with status code and metadata."""
    
    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.metadata = metadata or {}


# Convenience function
def create_client(
    api_key: str,
    **kwargs
) -> NeuralBridge:
    """Create a NeuralBridge client."""
    return NeuralBridge(api_key=api_key, **kwargs)
