"""
Jitter Algorithms for NeuralBridge SDK.

Implements exponential backoff with jitter to prevent thundering herd
and avalanche effects during API retries.

Based on AWS Architecture Blog recommendations:
- FullJitter: Best for rate-limited resources
- EqualJitter: Balanced approach
- DecorrelatedJitter: Good for varying latency conditions
"""

import asyncio
import random
from enum import Enum
from functools import wraps
from typing import Callable, Optional, TypeVar, Union


class JitterStrategy(str, Enum):
    """Supported jitter strategies."""
    NONE = "none"                    # No jitter, pure exponential backoff
    FULL = "full"                    # Full jitter (AWS recommended)
    EQUAL = "equal"                  # Equal jitter
    DECORRELATED = "decorrelated"    # Decorrelated jitter


T = TypeVar('T')


class JitterConfig:
    """Configuration for jitter behavior."""
    
    def __init__(
        self,
        strategy: JitterStrategy = JitterStrategy.FULL,
        base: float = 1.0,
        cap: float = 60.0,
        exponent: float = 2.0,
    ):
        """
        Initialize jitter configuration.
        
        Args:
            strategy: Jitter strategy to use
            base: Base delay in seconds (default: 1.0)
            cap: Maximum delay cap in seconds (default: 60.0)
            exponent: Exponential base multiplier (default: 2.0)
        """
        self.strategy = strategy
        self.base = base
        self.cap = cap
        self.exponent = exponent
    
    def calculate_delay(self, attempt: int, last_delay: float = 0.0) -> float:
        """
        Calculate delay for a given attempt using the configured jitter strategy.
        
        Args:
            attempt: Current retry attempt number (0-indexed)
            last_delay: Last delay used (for DECORRELATED strategy)
            
        Returns:
            Calculated delay in seconds
        """
        if self.strategy == JitterStrategy.NONE:
            return self._exponential_delay(attempt)
        
        elif self.strategy == JitterStrategy.FULL:
            return self._full_jitter(attempt)
        
        elif self.strategy == JitterStrategy.EQUAL:
            return self._equal_jitter(attempt)
        
        elif self.strategy == JitterStrategy.DECORRELATED:
            return self._decorrelated_jitter(attempt, last_delay)
        
        # Fallback to no jitter
        return self._exponential_delay(attempt)
    
    def _exponential_delay(self, attempt: int) -> float:
        """Pure exponential backoff without jitter."""
        delay = self.base * (self.exponent ** attempt)
        return min(delay, self.cap)
    
    def _full_jitter(self, attempt: int) -> float:
        """
        Full Jitter - AWS Recommended.
        
        Random delay in range [0, base * 2^attempt]
        Best for rate-limited resources as it provides maximum randomization.
        """
        max_delay = self.base * (self.exponent ** attempt)
        return min(random.uniform(0, max_delay), self.cap)
    
    def _equal_jitter(self, attempt: int) -> float:
        """
        Equal Jitter.
        
        Delay = (base * 2^attempt / 2) + random(0, base * 2^attempt / 2)
        Provides middle ground between full jitter and no jitter.
        """
        temp = self.base * (self.exponent ** attempt)
        middle = temp / 2
        return min(middle + random.uniform(0, middle), self.cap)
    
    def _decorrelated_jitter(self, attempt: int, last_delay: float) -> float:
        """
        Decorrelated Jitter.
        
        Based on the last delay instead of attempt number.
        Delay = random(base, 3 * last_delay) where last_delay starts at base.
        Good for varying latency conditions.
        """
        if last_delay <= 0:
            last_delay = self.base
        
        new_delay = random.uniform(self.base, last_delay * 3)
        return min(new_delay, self.cap)
    
    async def calculate_delay_async(self, attempt: int, last_delay: float = 0.0) -> float:
        """Async version of calculate_delay for use with asyncio."""
        # For calculation, we can use the sync version since it's fast
        return self.calculate_delay(attempt, last_delay)


def with_jitter(
    func: Optional[Callable] = None,
    *,
    jitter_config: Optional[JitterConfig] = None,
    max_retries: int = 3,
) -> Union[Callable, Callable[..., T]]:
    """
    Decorator to add jitter-based retry logic to a function.
    
    Args:
        func: Function to wrap (when used without arguments)
        jitter_config: Jitter configuration
        max_retries: Maximum number of retries
        
    Example:
        @with_jitter(jitter_config=JitterConfig(JitterStrategy.FULL))
        async def my_api_call():
            ...
    """
    if jitter_config is None:
        jitter_config = JitterConfig()
    
    def decorator(fn: Callable[..., T]) -> Callable[..., T]:
        @wraps(fn)
        def sync_wrapper(*args, **kwargs) -> T:
            last_delay = 0.0
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries:
                        delay = jitter_config.calculate_delay(attempt, last_delay)
                        last_delay = delay
                        import time
                        time.sleep(delay)
                    else:
                        raise last_exception
            
            raise last_exception  # Should never reach here
        
        @wraps(fn)
        async def async_wrapper(*args, **kwargs) -> T:
            last_delay = 0.0
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return await fn(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries:
                        delay = await jitter_config.calculate_delay_async(attempt, last_delay)
                        last_delay = delay
                        await asyncio.sleep(delay)
                    else:
                        raise last_exception
            
            raise last_exception  # Should never reach here
        
        # Return appropriate wrapper based on whether function is async
        if asyncio.iscoroutinefunction(fn):
            return async_wrapper
        return sync_wrapper
    
    # Handle both @with_jitter and @with_jitter(config) syntax
    if func is not None:
        return decorator(func)
    return decorator


class JitterManager:
    """
    Manager for jitter state across multiple operations.
    
    Useful when you want to maintain consistent jitter behavior
    across multiple API calls in a session.
    """
    
    def __init__(self, config: Optional[JitterConfig] = None):
        self.config = config or JitterConfig()
        self._state: dict[str, float] = {}  # track last_delay per operation
    
    def get_delay(self, operation_id: str, attempt: int) -> float:
        """Get delay for a specific operation."""
        last_delay = self._state.get(operation_id, 0.0)
        delay = self.config.calculate_delay(attempt, last_delay)
        self._state[operation_id] = delay
        return delay
    
    async def get_delay_async(self, operation_id: str, attempt: int) -> float:
        """Async version of get_delay."""
        return self.get_delay(operation_id, attempt)
    
    def reset(self, operation_id: Optional[str] = None) -> None:
        """Reset jitter state."""
        if operation_id:
            self._state.pop(operation_id, None)
        else:
            self._state.clear()


# Default jitter config for SDK use
DEFAULT_JITTER_CONFIG = JitterConfig(
    strategy=JitterStrategy.FULL,
    base=1.0,
    cap=60.0,
    exponent=2.0,
)
