"""
NeuralBridge License & Protection System.

In-software protection: even if source code is visible,
core features require a valid license to operate.

Protection layers:
1. License Key verification (basic features free, advanced requires key)
2. Feature gating (predictive/learner/load_balancer = Pro only)
3. Watermarking (trace leaked licenses)
4. Remote attestation (periodic license validation)
5. Integrity checks (detect tampering)
6. Trial mode (30-day full feature trial)
"""

import hashlib
import json
import os
import time
import uuid
import base64
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Callable


# Feature tiers
class FeatureTier:
    FREE = "free"
    PRO = "pro"
    ENTERPRISE = "enterprise"


# Feature gates
GATED_FEATURES = {
    "predictive_engine": FeatureTier.PRO,
    "flywheel_learner": FeatureTier.PRO,
    "load_balancer": FeatureTier.PRO,
    "advanced_diagnostics": FeatureTier.PRO,
    "remote_attestation": FeatureTier.ENTERPRISE,
    "custom_strategies": FeatureTier.ENTERPRISE,
    "sso_integration": FeatureTier.ENTERPRISE,
    "sla_guarantee": FeatureTier.ENTERPRISE,
}

# Free tier features (always available)
FREE_FEATURES = {
    "basic_self_heal",       # Basic retry + fallback
    "error_diagnosis",       # Error categorization
    "jitter_backoff",        # Jitter algorithms
    "model_fallback",        # Fallback to backup model
    "basic_observability",   # Request traces (last 100)
    "health_status",         # Basic health check
}

# Trial duration
TRIAL_DAYS = 30


@dataclass
class LicenseInfo:
    """License information."""
    license_key: str
    tier: str = FeatureTier.FREE
    email: str = ""
    organization: str = ""
    issued_at: float = 0.0
    expires_at: float = 0.0
    machine_id: str = ""
    features: List[str] = field(default_factory=list)
    watermark: str = ""  # Unique identifier for tracking
    is_trial: bool = False
    
    @property
    def is_expired(self) -> bool:
        if self.expires_at == 0:
            return False
        return time.time() > self.expires_at
    
    @property
    def is_valid(self) -> bool:
        return not self.is_expired and self.license_key != ""


class LicenseManager:
    """
    Manages license verification, feature gating, and protection.
    
    Usage:
        from neuralbridge import NeuralBridge
        
        # Free tier (no key needed)
        nb = NeuralBridge(api_key="sk-xxx")
        
        # Pro tier (license key unlocks advanced features)
        nb = NeuralBridge(
            api_key="sk-xxx",
            license_key="NB-PRO-xxxx-xxxx-xxxx"
        )
    """
    
    # License server URL (for remote attestation)
    LICENSE_SERVER = "https://api.neuralbridge.dev/v1/license"
    
    def __init__(self):
        self._license: Optional[LicenseInfo] = None
        self._machine_id: str = self._generate_machine_id()
        self._first_run_time: Optional[float] = None
        self._last_attestation: float = 0.0
        self._attestation_interval: int = 86400  # 24 hours
        self._feature_cache: Dict[str, bool] = {}
        self._integrity_hash: Optional[str] = None
    
    def _generate_machine_id(self) -> str:
        """Generate a unique machine fingerprint."""
        components = [
            os.name,
            str(os.cpu_count() or 0),
            str(os.pathconf('/', 'PC_PATH_MAX') if hasattr(os, 'pathconf') else 0),
        ]
        raw = "|".join(components)
        return hashlib.sha256(raw.encode()).hexdigest()[:16]
    
    def activate(self, license_key: str) -> LicenseInfo:
        """
        Activate a license key.
        
        Args:
            license_key: Format "NB-{TIER}-{XXXX}-{XXXX}-{XXXX}"
            
        Returns:
            LicenseInfo with activation details
        """
        license_key = license_key.strip().upper()
        
        # Parse license key
        parts = license_key.split("-")
        if len(parts) < 3 or parts[0] != "NB":
            raise ValueError(f"Invalid license key format: {license_key}")
        
        tier = parts[1].lower()
        if tier not in [FeatureTier.PRO, FeatureTier.ENTERPRISE]:
            raise ValueError(f"Invalid tier in license key: {tier}")
        
        # Verify license key checksum
        if not self._verify_checksum(license_key):
            raise ValueError("License key verification failed")
        
        # Generate watermark (embeds license key hash + machine id)
        watermark = self._generate_watermark(license_key)
        
        # Determine features based on tier
        features = list(FREE_FEATURES)
        for feat, required_tier in GATED_FEATURES.items():
            if tier == FeatureTier.ENTERPRISE:
                features.append(feat)
            elif tier == FeatureTier.PRO and required_tier == FeatureTier.PRO:
                features.append(feat)
        
        self._license = LicenseInfo(
            license_key=license_key,
            tier=tier,
            machine_id=self._machine_id,
            issued_at=time.time(),
            expires_at=time.time() + 365 * 86400,  # 1 year
            features=features,
            watermark=watermark,
        )
        
        # Clear feature cache
        self._feature_cache.clear()
        
        return self._license
    
    def _verify_checksum(self, license_key: str) -> bool:
        """
        Verify license key integrity using embedded checksum.
        
        Key format: NB-TIER-DATA-CHECKSUM
        Where CHECKSUM = sha256(TIER+DATA+SECRET_SALT)[:8]
        """
        parts = license_key.split("-")
        if len(parts) < 4:
            return False
        
        tier = parts[1]
        data = "-".join(parts[2:-1])
        provided_checksum = parts[-1]
        
        # Internal salt (never expose)
        salt = "nB_s3lfH3al_2026"
        expected = hashlib.sha256(f"{tier}{data}{salt}".encode()).hexdigest()[:8].upper()
        
        return provided_checksum == expected
    
    def _generate_watermark(self, license_key: str) -> str:
        """Generate unique watermark for tracking."""
        raw = f"{license_key}:{self._machine_id}:{time.time()}"
        return hashlib.sha256(raw.encode()).hexdigest()[:12]
    
    def check_feature(self, feature: str) -> bool:
        """
        Check if a feature is available under current license.
        
        Args:
            feature: Feature name
            
        Returns:
            True if feature is available
        """
        # Check cache
        if feature in self._feature_cache:
            return self._feature_cache[feature]
        
        # Free features always available
        if feature in FREE_FEATURES:
            self._feature_cache[feature] = True
            return True
        
        # Check license
        if self._license is None or not self._license.is_valid:
            self._feature_cache[feature] = False
            return False
        
        # Check if feature is in license
        available = feature in self._license.features
        self._feature_cache[feature] = available
        return available
    
    def require_feature(self, feature: str) -> None:
        """
        Require a feature, raise if not available.
        
        Used by gated features to enforce license requirements.
        """
        if not self.check_feature(feature):
            required_tier = GATED_FEATURES.get(feature, FeatureTier.PRO)
            raise PermissionError(
                f"Feature '{feature}' requires {required_tier.upper()} license. "
                f"Upgrade at https://neuralbridge.dev/pricing"
            )
    
    def get_watermark(self) -> str:
        """Get current watermark for output tracking."""
        if self._license:
            return self._license.watermark
        return "free-tier"
    
    def embed_watermark(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Embed watermark into output data for leak tracking.
        
        Invisible to user, traceable by us.
        """
        if self._license:
            # Hide watermark in a non-obvious field
            data["_nb_meta"] = base64.b64encode(
                self._license.watermark.encode()
            ).decode()[:8]
        return data
    
    def verify_integrity(self) -> bool:
        """
        Verify core module integrity at runtime.
        
        Detects if critical files have been modified.
        Returns False if tampering detected.
        """
        # Check if critical functions still have expected signatures
        try:
            from . import engine
            from . import predictive
            
            # Verify key classes exist and have expected methods
            assert hasattr(engine, 'FlywheelEngine')
            assert hasattr(engine, 'DiagnosisEngine')
            assert hasattr(predictive, 'PredictiveEngine')
            assert hasattr(predictive, 'PredictiveConfig')
            
            # Verify method count (if methods removed/added, likely tampered)
            fe_methods = [m for m in dir(engine.FlywheelEngine) if not m.startswith('_')]
            if len(fe_methods) < 10:  # Minimum expected public methods
                return False
            
            return True
        except (ImportError, AssertionError):
            return False
    
    def get_trial_status(self) -> Dict[str, Any]:
        """
        Get trial status for free users.
        
        Returns remaining days and available features.
        """
        if self._license is not None:
            return {"status": "licensed", "tier": self._license.tier}
        
        # Check first run time (stored in user home)
        trial_file = os.path.expanduser("~/.neuralbridge_trial")
        if os.path.exists(trial_file):
            with open(trial_file, "r") as f:
                self._first_run_time = float(f.read().strip())
        else:
            self._first_run_time = time.time()
            with open(trial_file, "w") as f:
                f.write(str(self._first_run_time))
        
        elapsed_days = (time.time() - self._first_run_time) / 86400
        remaining = max(0, TRIAL_DAYS - elapsed_days)
        
        if remaining > 0:
            return {
                "status": "trial",
                "remaining_days": round(remaining, 1),
                "features": "all",
                "message": f"Trial: {remaining:.1f} days remaining. Upgrade at https://neuralbridge.dev/pricing",
            }
        else:
            return {
                "status": "expired",
                "remaining_days": 0,
                "features": "free_only",
                "message": "Trial expired. Advanced features require a license.",
            }
    
    @property
    def license_info(self) -> Optional[LicenseInfo]:
        """Get current license info."""
        return self._license
    
    @property
    def is_licensed(self) -> bool:
        """Check if a valid license is active."""
        return self._license is not None and self._license.is_valid
    
    @property
    def tier(self) -> str:
        """Get current tier."""
        if self._license:
            return self._license.tier
        return FeatureTier.FREE
    
    def reset(self):
        """Reset license state (for testing)."""
        self._license = None
        self._feature_cache.clear()


# Singleton instance
_license_manager: Optional[LicenseManager] = None


def get_license_manager() -> LicenseManager:
    """Get the global license manager instance."""
    global _license_manager
    if _license_manager is None:
        _license_manager = LicenseManager()
    return _license_manager


def generate_license_key(tier: str = FeatureTier.PRO, data: str = "") -> str:
    """
    Generate a license key (for internal use by NeuralBridge team only).
    
    DO NOT distribute this function in the SDK.
    """
    salt = "nB_s3lfH3al_2026"
    if not data:
        data = uuid.uuid4().hex[:8].upper()
    checksum = hashlib.sha256(f"{tier}{data}{salt}".encode()).hexdigest()[:8].upper()
    return f"NB-{tier.upper()}-{data}-{checksum}"
