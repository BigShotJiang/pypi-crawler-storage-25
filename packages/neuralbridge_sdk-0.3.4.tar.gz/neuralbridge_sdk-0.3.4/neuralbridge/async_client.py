"""
Async HTTP client for NeuralBridge SDK.

Provides async/await interface for AI API calls with full self-healing support.
Built on httpx for robust async HTTP handling.
"""

import asyncio
import json
import time
from typing import Any, AsyncIterator, Dict, List, Optional, Union, Callable
from urllib.parse import urlencode

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

from .engine import FlywheelEngine, DiagnosisEngine
from .types import DiagnosisResult, RecoveryAction
from .jitter import JitterConfig, JitterStrategy, DEFAULT_JITTER_CONFIG


class AsyncNeuralBridgeClient:
    """
    Async version of NeuralBridge client.
    
    Provides async/await interface for AI API calls with:
    - Automatic fault diagnosis
    - Cascading recovery strategies
    - Jittered exponential backoff
    - Model fallback switching
    
    Example:
        async with AsyncNeuralBridgeClient(api_key="sk-xxx") as client:
            response = await client.chat.completions.acreate(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hello!"}],
            )
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        fallback_models: Optional[List[str]] = None,
        max_retries: int = 3,
        timeout: float = 60.0,
        verbose: bool = False,
        jitter_config: Optional[JitterConfig] = None,
        api_key_refresher: Optional[Callable[[], str]] = None,
    ):
        """
        Initialize async NeuralBridge client.
        
        Args:
            api_key: API key for authentication
            base_url: Base URL for API endpoint
            fallback_models: Ordered list of fallback model names
            max_retries: Maximum retry attempts
            timeout: Request timeout in seconds
            verbose: Enable verbose logging
            jitter_config: Jitter configuration
            api_key_refresher: Optional function to refresh API key
        """
        if not HTTPX_AVAILABLE:
            raise ImportError(
                "httpx is required for async support. "
                "Install it with: pip install httpx"
            )
        
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.verbose = verbose
        
        # Initialize engine
        self.engine = FlywheelEngine(
            fallback_models=fallback_models,
            max_retries=max_retries,
            verbose=verbose,
            jitter_config=jitter_config,
            api_key_refresher=api_key_refresher,
        )
        
        # HTTP client
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._client
    
    async def _api_call(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make an API call with automatic healing.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            **kwargs: Additional request parameters
            
        Returns:
            API response as dictionary
        """
        async def _make_request() -> Dict[str, Any]:
            client = await self._get_client()
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            
            response = await client.request(method, url, **kwargs)
            
            if not response.is_success:
                # Convert httpx response to error with metadata
                error = httpx.HTTPStatusError(
                    message=response.text,
                    request=response.request,
                    response=response,
                )
                
                # Add status code to metadata
                metadata = {"status_code": response.status_code}
                
                # Check for rate limit headers
                if "retry-after" in response.headers:
                    metadata["retry_after"] = float(response.headers["retry-after"])
                
                # Try to parse error body
                try:
                    error_data = response.json()
                    if "error" in error_data:
                        metadata["error_message"] = error_data["error"].get("message", "")
                        metadata["error_type"] = error_data["error"].get("type", "")
                except Exception:
                    pass
                
                # Raise with metadata
                raise HTTPErrorWithMetadata(error, metadata)
            
            return response.json()
        
        # Use engine's heal for automatic recovery
        return await self.engine.heal_async(_make_request)
    
    async def acreate(
        self,
        model: str,
        messages: List[Dict[str, str]],
        temperature: float = 1.0,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> Union[Dict[str, Any], AsyncIterator[Dict[str, Any]]]:
        """
        Create a chat completion (async version).
        
        Args:
            model: Model identifier
            messages: List of message dictionaries
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stream: Enable streaming responses
            **kwargs: Additional parameters
            
        Returns:
            Response dict or async iterator for streaming
        """
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
        }
        
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        
        # Merge additional kwargs
        payload.update(kwargs)
        
        if stream:
            return self._stream_chat_completion(payload)
        
        return await self._api_call("POST", "/chat/completions", json=payload)
    
    async def _stream_chat_completion(
        self,
        payload: Dict[str, Any]
    ) -> AsyncIterator[Dict[str, Any]]:
        """Handle streaming chat completion."""
        client = await self._get_client()
        url = f"{self.base_url}/chat/completions"
        
        async with client.stream("POST", url, json=payload) as response:
            if not response.is_success:
                error = httpx.HTTPStatusError(
                    message=await response.aread(),
                    request=response.request,
                    response=response,
                )
                metadata = {"status_code": response.status_code}
                raise HTTPErrorWithMetadata(error, metadata)
            
            async for line in response.aiter_lines():
                if line.startswith("data: "):
                    data = line[6:]  # Remove "data: " prefix
                    if data == "[DONE]":
                        break
                    try:
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        continue
    
    @property
    def chat(self) -> "ChatCompletionsAsync":
        """Access chat completions namespace."""
        return ChatCompletionsAsync(self)
    
    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
    
    async def __aenter__(self) -> "AsyncNeuralBridgeClient":
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()


class ChatCompletionsAsync:
    """Async chat completions namespace."""
    
    def __init__(self, client: AsyncNeuralBridgeClient):
        self._client = client
    
    async def acreate(
        self,
        model: str,
        messages: List[Dict[str, str]],
        temperature: float = 1.0,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> Union[Dict[str, Any], AsyncIterator[Dict[str, Any]]]:
        """
        Create a chat completion (async).
        
        Example:
            response = await client.chat.completions.acreate(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hello!"}],
            )
        """
        return await self._client.acreate(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            **kwargs
        )
    
    async def create(
        self,
        model: str,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> Dict[str, Any]:
        """
        Create a chat completion (async, non-streaming).
        
        Alias for acreate with stream=False.
        """
        return await self.acreate(model=model, messages=messages, stream=False, **kwargs)


class HTTPErrorWithMetadata(Exception):
    """HTTP error with additional metadata."""
    
    def __init__(self, error: Exception, metadata: Dict[str, Any]):
        super().__init__(str(error))
        self.metadata = metadata
        self.error = error


# Utility function for creating async client with context manager
async def create_async_client(
    api_key: str,
    **kwargs
) -> AsyncNeuralBridgeClient:
    """
    Create an async NeuralBridge client.
    
    This is a convenience function that creates the client
    and returns it ready for use with async context manager.
    
    Example:
        async with create_async_client(api_key="sk-xxx") as client:
            response = await client.chat.completions.acreate(...)
    """
    return AsyncNeuralBridgeClient(api_key=api_key, **kwargs)
