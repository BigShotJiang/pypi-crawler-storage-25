"""
NeuralBridge SDK - Self-healing decision engine for AI API calls.

Drop-in replacement for OpenAI SDK with automatic fault diagnosis,
cascade recovery, and transparent model switching.

Usage:
    from neuralbridge import NeuralBridge

    # Synchronous usage (drop-in replacement for openai.OpenAI)
    client = NeuralBridge(api_key="sk-xxx")
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}],
    )

    # Async usage
    from neuralbridge.async_client import AsyncNeuralBridgeClient
    
    async with AsyncNeuralBridgeClient(api_key="sk-xxx") as client:
        response = await client.chat.completions.acreate(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )

    # Direct engine usage for custom integrations
    from neuralbridge import FlywheelEngine
    
    engine = FlywheelEngine(fallback_models=["gpt-4o-mini", "gpt-3.5-turbo"])
    result = engine.heal(my_api_call_function)
"""

from .engine import FlywheelEngine, DiagnosisEngine
from .learner import FlywheelLearner, LearnedRule, ErrorRecoveryPair
from .types import (
    DiagnosisResult,
    RecoveryAction,
    RecoveryRecord,
    ModelPerformance,
    CascadeLevel,
    ErrorCategory,
    HealthStatus,
    RequestTrace,
    ModelHealth,
    RecoveryStats,
)
from .predictive import PredictiveEngine, PredictiveConfig, Prediction
from .strategies import (
    RecoveryStrategy,
    RateLimitStrategy,
    AuthRefreshStrategy,
    ModelFallbackStrategy,
    NetworkRetryStrategy,
    StrategyRegistry,
)
from .jitter import (
    JitterConfig,
    JitterStrategy,
    JitterManager,
    with_jitter,
    DEFAULT_JITTER_CONFIG,
)
from .license import (
    LicenseManager,
    LicenseInfo,
    FeatureTier,
    GATED_FEATURES,
    FREE_FEATURES,
    generate_license_key,
)
from .load_balancer import (
    LoadBalancer,
    LoadBalancerConfig,
    LoadBalancingStrategy,
    ModelLoadInfo,
    generate_test_key,
)
from .async_client import AsyncNeuralBridgeClient
from .adapters.openai_adapter import NeuralBridge, ChatCompletions, HTTPError

__version__ = "0.3.4"
__all__ = [
    # Main client (drop-in for openai.OpenAI)
    "NeuralBridge",
    "ChatCompletions",
    "HTTPError",
    
    # Async client
    "AsyncNeuralBridgeClient",
    
    # Core engine
    "FlywheelEngine",
    "DiagnosisEngine",
    
    # Flywheel Learner
    "FlywheelLearner",
    "LearnedRule",
    "ErrorRecoveryPair",
    
    # Types
    "DiagnosisResult",
    "RecoveryAction",
    "RecoveryRecord",
    "ModelPerformance",
    "CascadeLevel",
    "ErrorCategory",
    "HealthStatus",
    "RequestTrace",
    "ModelHealth",
    "RecoveryStats",
    "PredictiveConfig",
    "Prediction",
    
    # Predictive Engine
    "PredictiveEngine",
    
    # Strategies
    "RecoveryStrategy",
    "RateLimitStrategy",
    "AuthRefreshStrategy",
    "ModelFallbackStrategy",
    "NetworkRetryStrategy",
    "StrategyRegistry",
    
    # Jitter
    "JitterConfig",
    "JitterStrategy",
    "JitterManager",
    "with_jitter",
    "DEFAULT_JITTER_CONFIG",
    
    # License & Protection
    "LicenseManager",
    "LicenseInfo",
    "FeatureTier",
    "GATED_FEATURES",
    "FREE_FEATURES",
    "generate_license_key",
    
    # Load Balancer
    "LoadBalancer",
    "LoadBalancerConfig",
    "LoadBalancingStrategy",
    "ModelLoadInfo",
    "generate_test_key",
]
