"""
Recovery strategies for NeuralBridge SDK.

Implements the four core recovery strategies:
1. RateLimitStrategy - Handles 429 errors with smart backoff
2. AuthRefreshStrategy - Handles authentication token refresh
3. ModelFallbackStrategy - Switches to fallback models on failure
4. NetworkRetryStrategy - Retries with jitter on network errors
"""

import asyncio
import random
import time
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, TypeVar, Generic

from .jitter import JitterConfig, JitterStrategy, DEFAULT_JITTER_CONFIG
from .types import (
    DiagnosisResult,
    ErrorCategory,
    RecoveryAction,
    CascadeLevel,
    ModelPerformance,
)


T = TypeVar('T')


class RecoveryStrategy(ABC):
    """Base class for all recovery strategies."""
    
    @abstractmethod
    def should_activate(self, diagnosis: DiagnosisResult) -> bool:
        """Check if this strategy should be activated for the diagnosis."""
        pass
    
    @abstractmethod
    def get_action(self, diagnosis: DiagnosisResult, context: Dict[str, Any]) -> RecoveryAction:
        """Get the recovery action for this strategy."""
        pass
    
    def execute(
        self,
        func: Callable[..., T],
        *args,
        **kwargs
    ) -> T:
        """Execute a function with this strategy's recovery logic."""
        raise NotImplementedError


class RateLimitStrategy(RecoveryStrategy):
    """
    Handles rate limit (429) errors with smart backoff.
    
    Features:
    - Respects Retry-After header when available
    - Jittered exponential backoff for thundering herd prevention
    - Configurable base delay and cap
    - Token bucket aware if X-RateLimit headers present
    """
    
    def __init__(
        self,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        max_retries: int = 5,
        jitter_config: Optional[JitterConfig] = None,
    ):
        """
        Initialize rate limit strategy.
        
        Args:
            base_delay: Base delay in seconds (default: 1.0)
            max_delay: Maximum delay cap in seconds (default: 60.0)
            max_retries: Maximum number of retries (default: 5)
            jitter_config: Jitter configuration (default: FullJitter)
        """
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.max_retries = max_retries
        self.jitter_config = jitter_config or DEFAULT_JITTER_CONFIG
    
    def should_activate(self, diagnosis: DiagnosisResult) -> bool:
        """Activate only for rate limit errors."""
        return diagnosis.category == ErrorCategory.RATE_LIMIT
    
    def get_action(
        self,
        diagnosis: DiagnosisResult,
        context: Dict[str, Any]
    ) -> RecoveryAction:
        """Get rate limit recovery action."""
        # Check for Retry-After header
        retry_after = diagnosis.metadata.get("retry_after")
        
        if retry_after:
            delay = float(retry_after)
        else:
            attempt = context.get("attempt", 0)
            delay = self.jitter_config.calculate_delay(attempt)
        
        return RecoveryAction(
            level=CascadeLevel.L2_WAIT,
            action_type="wait_and_retry",
            params={"delay": delay, "attempt": context.get("attempt", 0)},
            reason=f"Rate limited, waiting {delay:.2f}s before retry",
        )
    
    def calculate_delay(self, attempt: int, retry_after: Optional[float] = None) -> float:
        """
        Calculate delay for current attempt.
        
        Args:
            attempt: Current retry attempt
            retry_after: Explicit retry-after value from server
            
        Returns:
            Delay in seconds
        """
        if retry_after is not None:
            return retry_after
        
        return self.jitter_config.calculate_delay(attempt)
    
    def reset(self) -> None:
        """Reset strategy state."""
        pass
    
    async def wait(self, delay: float) -> None:
        """Async wait for rate limit to clear."""
        await asyncio.sleep(delay)
    
    def execute(
        self,
        func: Callable[..., T],
        *args,
        **kwargs
    ) -> T:
        """Execute with rate limit handling."""
        last_exception = None
        
        for attempt in range(self.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries:
                    delay = self.calculate_delay(attempt)
                    time.sleep(delay)
                else:
                    break
        
        raise last_exception


class AuthRefreshStrategy(RecoveryStrategy):
    """
    Handles authentication errors (401/403) with token refresh.
    
    Features:
    - Automatic token refresh on 401 errors
    - Respects refresh token if provided
    - Can use custom auth refresh callback
    - Maximum refresh attempts configurable
    """
    
    def __init__(
        self,
        refresh_func: Optional[Callable[[], str]] = None,
        max_refresh_attempts: int = 2,
        refresh_callback: Optional[Callable[[Exception], None]] = None,
    ):
        """
        Initialize auth refresh strategy.
        
        Args:
            refresh_func: Optional function that returns a new API key
            max_refresh_attempts: Max token refresh retries (default: 2)
            refresh_callback: Optional callback when auth refresh occurs
        """
        self.refresh_func = refresh_func
        self.max_refresh_attempts = max_refresh_attempts
        self.refresh_callback = refresh_callback
        self._refresh_count = 0
    
    def should_activate(self, diagnosis: DiagnosisResult) -> bool:
        """Activate only for auth errors."""
        return diagnosis.category == ErrorCategory.AUTH_ERROR
    
    def get_action(
        self,
        diagnosis: DiagnosisResult,
        context: Dict[str, Any]
    ) -> RecoveryAction:
        """Get auth refresh action."""
        return RecoveryAction(
            level=CascadeLevel.L4_HEAL,
            action_type="refresh_auth",
            params={"refresh_count": self._refresh_count},
            reason="Authentication failed, attempting token refresh",
        )
    
    def can_refresh(self) -> bool:
        """Check if another refresh attempt is possible."""
        return (
            self.refresh_func is not None and
            self._refresh_count < self.max_refresh_attempts
        )
    
    def attempt_refresh(self) -> Optional[str]:
        """
        Attempt to refresh authentication.
        
        Returns:
            New API key if successful, None otherwise
        """
        if not self.can_refresh():
            return None
        
        try:
            new_key = self.refresh_func()
            self._refresh_count += 1
            
            if self.refresh_callback:
                self.refresh_callback(Exception("Auth refreshed"))
            
            return new_key
        except Exception:
            return None
    
    def reset(self) -> None:
        """Reset refresh counter."""
        self._refresh_count = 0
    
    def execute(
        self,
        func: Callable[..., T],
        *args,
        api_key_getter: Optional[Callable[[], str]] = None,
        api_key_setter: Optional[Callable[[str], None]] = None,
        **kwargs
    ) -> T:
        """Execute with auth refresh handling."""
        last_exception = None
        
        for attempt in range(self.max_refresh_attempts + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if attempt < self.max_refresh_attempts:
                    new_key = None
                    if self.refresh_func:
                        new_key = self.attempt_refresh()
                    elif api_key_getter and api_key_setter:
                        new_key = api_key_getter()
                        new_key = self.attempt_refresh()
                    
                    if new_key and api_key_setter:
                        api_key_setter(new_key)
                else:
                    break
        
        raise last_exception


class ModelFallbackStrategy(RecoveryStrategy):
    """
    Switches to fallback models on persistent failures.
    
    Features:
    - Ordered fallback list based on priority
    - Performance tracking to avoid degraded models
    - Configurable fallback selection logic
    - Model health status tracking
    """
    
    def __init__(
        self,
        fallback_models: Optional[List[str]] = None,
        performance_tracker: Optional[Dict[str, ModelPerformance]] = None,
        min_reliability: float = 0.5,
    ):
        """
        Initialize model fallback strategy.
        
        Args:
            fallback_models: Ordered list of fallback model names
            performance_tracker: Dict tracking model performance
            min_reliability: Minimum reliability score to consider (default: 0.5)
        """
        self.fallback_models = fallback_models or []
        self.performance_tracker = performance_tracker or {}
        self.min_reliability = min_reliability
        self._current_index = 0
    
    def should_activate(self, diagnosis: DiagnosisResult) -> bool:
        """Activate for retryable errors when model unavailable."""
        return (
            diagnosis.category == ErrorCategory.MODEL_UNAVAILABLE or
            (diagnosis.retryable and diagnosis.category == ErrorCategory.SERVER_ERROR)
        )
    
    def get_action(
        self,
        diagnosis: DiagnosisResult,
        context: Dict[str, Any]
    ) -> RecoveryAction:
        """Get model switch action."""
        next_model = self.get_next_model(context.get("current_model", ""))
        
        if next_model:
            return RecoveryAction(
                level=CascadeLevel.L3_SWITCH,
                action_type="switch_model",
                target=next_model,
                reason=f"Model {context.get('current_model')} unavailable, switching to {next_model}",
            )
        
        return RecoveryAction(
            level=CascadeLevel.L3_SWITCH,
            action_type="exhausted_models",
            reason="No more fallback models available",
        )
    
    def get_next_model(self, current_model: str) -> Optional[str]:
        """
        Get the next available fallback model.
        
        Args:
            current_model: Currently failing model
            
        Returns:
            Next model name or None if exhausted
        """
        # Reset if we've gone through all models
        if self._current_index >= len(self.fallback_models):
            return None
        
        # Skip the current model
        while self._current_index < len(self.fallback_models):
            candidate = self.fallback_models[self._current_index]
            self._current_index += 1
            
            if candidate == current_model:
                continue
            
            # Check reliability if we have performance data
            if candidate in self.performance_tracker:
                perf = self.performance_tracker[candidate]
                if perf.reliability_score < self.min_reliability:
                    continue
            
            return candidate
        
        return None
    
    def update_performance(self, model: str, success: bool, latency: float) -> None:
        """Update performance metrics for a model."""
        if model not in self.performance_tracker:
            self.performance_tracker[model] = ModelPerformance(model=model)
        
        self.performance_tracker[model].update(success, latency)
    
    def get_healthy_models(self) -> List[str]:
        """Get list of models with acceptable reliability."""
        return [
            model for model, perf in self.performance_tracker.items()
            if perf.reliability_score >= self.min_reliability
        ]
    
    def reset(self) -> None:
        """Reset fallback index for a new request."""
        self._current_index = 0


class NetworkRetryStrategy(RecoveryStrategy):
    """
    Retries with jitter on network errors.
    
    Features:
    - Jittered exponential backoff
    - Configurable retry conditions
    - Timeout handling
    - Configurable jitter strategy
    """
    
    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        jitter_config: Optional[JitterConfig] = None,
        retryable_exceptions: Optional[List[type]] = None,
    ):
        """
        Initialize network retry strategy.
        
        Args:
            max_retries: Maximum retry attempts (default: 3)
            base_delay: Base delay in seconds (default: 1.0)
            max_delay: Maximum delay cap (default: 60.0)
            jitter_config: Jitter configuration (default: FullJitter)
            retryable_exceptions: List of exception types to retry
        """
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.jitter_config = jitter_config or DEFAULT_JITTER_CONFIG
        self.retryable_exceptions = retryable_exceptions or [Exception]
    
    def should_activate(self, diagnosis: DiagnosisResult) -> bool:
        """Activate for network errors and retryable server errors."""
        return (
            diagnosis.category == ErrorCategory.NETWORK_ERROR or
            (diagnosis.retryable and diagnosis.category == ErrorCategory.SERVER_ERROR)
        )
    
    def get_action(
        self,
        diagnosis: DiagnosisResult,
        context: Dict[str, Any]
    ) -> RecoveryAction:
        """Get network retry action."""
        attempt = context.get("attempt", 0)
        delay = self.jitter_config.calculate_delay(attempt)
        
        return RecoveryAction(
            level=CascadeLevel.L1_RETRY,
            action_type="retry",
            params={"delay": delay, "attempt": attempt + 1},
            reason=f"Network error, retrying with {delay:.2f}s backoff",
        )
    
    def is_retryable(self, exception: Exception) -> bool:
        """Check if exception type is retryable."""
        return any(isinstance(exception, exc_type) for exc_type in self.retryable_exceptions)
    
    def calculate_delay(self, attempt: int) -> float:
        """Calculate jittered delay for attempt."""
        return self.jitter_config.calculate_delay(attempt)
    
    def reset(self) -> None:
        """Reset strategy state."""
        pass
    
    def execute(
        self,
        func: Callable[..., T],
        *args,
        **kwargs
    ) -> T:
        """Execute with network retry handling."""
        last_exception = None
        last_delay = 0.0
        
        for attempt in range(self.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if not self.is_retryable(e):
                    raise
                
                if attempt < self.max_retries:
                    delay = self.jitter_config.calculate_delay(attempt, last_delay)
                    last_delay = delay
                    time.sleep(delay)
                else:
                    break
        
        raise last_exception
    
    async def execute_async(
        self,
        func: Callable[..., T],
        *args,
        **kwargs
    ) -> T:
        """Async execute with network retry handling."""
        last_exception = None
        last_delay = 0.0
        
        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if not self.is_retryable(e):
                    raise
                
                if attempt < self.max_retries:
                    delay = await self.jitter_config.calculate_delay_async(attempt, last_delay)
                    last_delay = delay
                    await asyncio.sleep(delay)
                else:
                    break
        
        raise last_exception


class StrategyRegistry:
    """
    Registry for managing multiple recovery strategies.
    
    Allows strategies to be added, removed, and queried.
    """
    
    def __init__(self):
        self._strategies: Dict[str, RecoveryStrategy] = {}
        self._strategies_by_category: Dict[ErrorCategory, List[RecoveryStrategy]] = {}
    
    def register(self, name: str, strategy: RecoveryStrategy) -> None:
        """Register a named strategy."""
        self._strategies[name] = strategy
    
    def unregister(self, name: str) -> Optional[RecoveryStrategy]:
        """Unregister a named strategy."""
        return self._strategies.pop(name, None)
    
    def get(self, name: str) -> Optional[RecoveryStrategy]:
        """Get a registered strategy by name."""
        return self._strategies.get(name)
    
    def get_for_diagnosis(
        self,
        diagnosis: DiagnosisResult
    ) -> List[RecoveryStrategy]:
        """Get all strategies that should activate for a diagnosis."""
        return [
            strategy for strategy in self._strategies.values()
            if strategy.should_activate(diagnosis)
        ]
    
    def get_all(self) -> Dict[str, RecoveryStrategy]:
        """Get all registered strategies."""
        return dict(self._strategies)
    
    def clear(self) -> None:
        """Clear all registered strategies."""
        self._strategies.clear()
        self._strategies_by_category.clear()
