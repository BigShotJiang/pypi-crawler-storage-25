"""
NeuralBridge Flywheel Learner.

Self-healing flywheel learning engine that learns from every error-recovery cycle,
automatically optimizing recovery strategies over time.

Features:
- Records error patterns and recovery outcomes
- Extracts learned rules when patterns repeat 3+ times
- Adjusts rule parameters based on success rates
- Prunes low-performing/expired rules
- Exports/imports rules for persistence
"""

import re
import uuid
import hashlib
import statistics
from collections import deque, defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple


# ========== Data Classes ==========


@dataclass
class LearnedRule:
    """
    A recovery rule learned from error-recovery history.
    
    Attributes:
        rule_id: Unique identifier for the rule
        pattern: Normalized error pattern (regex or keyword)
        action: Recovery action type
        action_params: Parameters for the action
        confidence: Learning confidence (0-1, increases with more samples)
        sample_count: Number of times this pattern was observed
        success_count: Number of successful recoveries using this rule
        success_rate: Success rate of this rule (success_count / sample_count)
        created_at: When the rule was first created
        last_used: When the rule was last used
        last_updated: When the rule was last modified
    """
    rule_id: str
    pattern: str
    action: str
    action_params: Dict[str, Any]
    confidence: float = 0.0
    sample_count: int = 0
    success_count: int = 0
    success_rate: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    last_used: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)
    
    def update_success(self) -> None:
        """Record a successful recovery using this rule."""
        self.sample_count += 1
        self.success_count += 1
        self.success_rate = self.success_count / self.sample_count
        self.last_used = datetime.now()
        self.last_updated = datetime.now()
        self._update_confidence()
    
    def update_failure(self) -> None:
        """Record a failed recovery using this rule."""
        self.sample_count += 1
        self.success_rate = self.success_count / self.sample_count
        self.last_used = datetime.now()
        self.last_updated = datetime.now()
        self._update_confidence()
    
    def _update_confidence(self) -> None:
        """
        Update confidence based on sample count and success rate.
        
        Confidence formula:
        - Base confidence from success rate
        - Bonus from more samples (diminishing returns after 10 samples)
        """
        base_confidence = self.success_rate
        
        # Sample-based bonus (max 0.2 bonus at 10+ samples)
        sample_bonus = min(0.2, self.sample_count * 0.02)
        
        self.confidence = min(1.0, base_confidence + sample_bonus)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to serializable dictionary."""
        d = asdict(self)
        # Convert datetime to ISO format strings
        d["created_at"] = self.created_at.isoformat()
        d["last_used"] = self.last_used.isoformat()
        d["last_updated"] = self.last_updated.isoformat()
        return d
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "LearnedRule":
        """Create from serialized dictionary."""
        # Convert ISO format strings back to datetime
        if isinstance(d.get("created_at"), str):
            d["created_at"] = datetime.fromisoformat(d["created_at"])
        if isinstance(d.get("last_used"), str):
            d["last_used"] = datetime.fromisoformat(d["last_used"])
        if isinstance(d.get("last_updated"), str):
            d["last_updated"] = datetime.fromisoformat(d["last_updated"])
        return cls(**d)


@dataclass
class ErrorRecoveryPair:
    """
    A single error-recovery observation pair.
    
    Attributes:
        pattern: Normalized error pattern
        original_error: Original error message
        action: Recovery action taken
        action_params: Parameters of the action
        success: Whether recovery succeeded
        latency: Recovery latency in seconds
        timestamp: When this observation occurred
    """
    pattern: str
    original_error: str
    action: str
    action_params: Dict[str, Any]
    success: bool
    latency: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)


# ========== FlywheelLearner Class ==========


class FlywheelLearner:
    """
    Self-healing flywheel learning engine.
    
    Learns from every error-recovery cycle, automatically optimizing recovery
    strategies over time. The more it is used, the smarter it becomes.
    
    Learning Process:
    1. Record each error-recovery pair
    2. Normalize error patterns (remove specific values)
    3. When pattern appears 3+ times, extract a learned rule
    4. Adjust rule parameters based on success rates
    5. Prune low-performing or expired rules
    
    Usage:
        learner = FlywheelLearner(min_samples=3, decay_days=30)
        
        # Record observations
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.5)
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=3.1)
        learner.record("rate limit exceeded", "retry_with_delay", True, latency=2.8)
        
        # Learn rules from history
        new_rules = learner.learn()
        
        # Match new errors to learned rules
        rule = learner.match_rule("rate limit exceeded")
        if rule:
            print(f"Apply learned rule: {rule.action} with {rule.action_params}")
    """
    
    def __init__(
        self,
        min_samples: int = 3,
        decay_days: int = 30,
        max_history: int = 10000,
        min_confidence: float = 0.3,
    ):
        """
        Initialize the flywheel learner.
        
        Args:
            min_samples: Minimum observations before extracting a rule (default: 3)
            decay_days: Days before unused rules decay (default: 30)
            max_history: Maximum history entries to keep (default: 10000)
            min_confidence: Minimum confidence to keep a rule (default: 0.3)
        """
        self._min_samples = min_samples
        self._decay_days = decay_days
        self._max_history = max_history
        self._min_confidence = min_confidence
        
        # History of error-recovery pairs
        self._error_recovery_pairs: deque = deque(maxlen=max_history)
        
        # Learned rules indexed by pattern
        self._learned_rules: Dict[str, LearnedRule] = {}
        
        # Statistics
        self._total_recordings: int = 0
        self._total_learned: int = 0
    
    def record(
        self,
        error_pattern: str,
        recovery_action: str,
        success: bool,
        latency: float = 0.0,
        action_params: Optional[Dict[str, Any]] = None,
        original_error: Optional[str] = None,
    ) -> None:
        """
        Record an error-recovery observation pair.
        
        Args:
            error_pattern: The error message or pattern
            recovery_action: The recovery action taken (e.g., "retry_with_delay")
            success: Whether the recovery succeeded
            latency: Recovery latency in seconds
            action_params: Parameters of the action
            original_error: Original error message (if different from pattern)
        """
        self._total_recordings += 1
        
        # Normalize the error pattern
        normalized_pattern = self._extract_pattern(error_pattern)
        
        # Create observation pair
        pair = ErrorRecoveryPair(
            pattern=normalized_pattern,
            original_error=original_error or error_pattern,
            action=recovery_action,
            action_params=action_params or {},
            success=success,
            latency=latency,
        )
        
        self._error_recovery_pairs.append(pair)
        
        # Update existing rule if matched
        if normalized_pattern in self._learned_rules:
            rule = self._learned_rules[normalized_pattern]
            if success:
                rule.update_success()
            else:
                rule.update_failure()
    
    def learn(self) -> List[LearnedRule]:
        """
        Analyze history and extract/optimize learned rules.
        
        This method:
        1. Groups observations by normalized pattern
        2. For patterns with 3+ observations, extracts or updates rules
        3. Returns newly created or significantly updated rules
        
        Returns:
            List of rules that were created or updated
        """
        # Group observations by pattern
        pattern_groups: Dict[str, List[ErrorRecoveryPair]] = defaultdict(list)
        for pair in self._error_recovery_pairs:
            pattern_groups[pair.pattern].append(pair)
        
        updated_rules: List[LearnedRule] = []
        
        for pattern, pairs in pattern_groups.items():
            # Skip if not enough samples
            if len(pairs) < self._min_samples:
                continue
            
            # Calculate statistics for this pattern
            successes = sum(1 for p in pairs if p.success)
            success_rate = successes / len(pairs)
            
            # Calculate median latency for retry actions
            latencies = [p.latency for p in pairs if p.latency > 0]
            median_latency = statistics.median(latencies) if latencies else 2.0
            
            # Find best performing action for this pattern
            action_stats: Dict[str, Tuple[int, int]] = defaultdict(lambda: (0, 0))
            for p in pairs:
                total, success = action_stats[p.action]
                action_stats[p.action] = (total + 1, success + (1 if p.success else 0))
            
            best_action = max(action_stats.items(), key=lambda x: x[1][1] / x[1][0] if x[1][0] > 0 else 0)
            best_action_name = best_action[0]
            best_action_total, best_action_success = best_action[1]
            best_action_rate = best_action_success / best_action_total if best_action_total > 0 else 0
            
            # Determine optimal action params
            action_params = self._optimize_action_params(best_action_name, pairs, median_latency)
            
            # Create or update rule
            if pattern in self._learned_rules:
                # Update existing rule
                rule = self._learned_rules[pattern]
                old_confidence = rule.confidence
                
                # Update statistics
                rule.sample_count = len(pairs)
                rule.success_count = successes
                rule.success_rate = success_rate
                rule.action = best_action_name
                rule.action_params = action_params
                rule.last_updated = datetime.now()
                rule._update_confidence()
                
                # Only report significant updates
                if abs(rule.confidence - old_confidence) > 0.05:
                    updated_rules.append(rule)
            else:
                # Create new rule
                rule = LearnedRule(
                    rule_id=self._generate_rule_id(pattern),
                    pattern=pattern,
                    action=best_action_name,
                    action_params=action_params,
                    confidence=0.0,  # Will be calculated
                    sample_count=len(pairs),
                    success_count=successes,
                    success_rate=success_rate,
                )
                rule._update_confidence()
                
                self._learned_rules[pattern] = rule
                self._total_learned += 1
                updated_rules.append(rule)
        
        return updated_rules
    
    def get_learned_rules(self) -> List[LearnedRule]:
        """
        Get all learned rules.
        
        Returns:
            List of all LearnedRule objects, sorted by confidence (descending)
        """
        rules = list(self._learned_rules.values())
        rules.sort(key=lambda r: r.confidence, reverse=True)
        return rules
    
    def match_rule(self, error_pattern: str) -> Optional[LearnedRule]:
        """
        Match an error pattern to the best learned rule.
        
        Args:
            error_pattern: The error message or pattern to match
            
        Returns:
            The best matching LearnedRule, or None if no match found
        """
        normalized_pattern = self._extract_pattern(error_pattern)
        
        # Exact match
        if normalized_pattern in self._learned_rules:
            rule = self._learned_rules[normalized_pattern]
            rule.last_used = datetime.now()
            return rule
        
        # Fuzzy match: check if any rule pattern is a substring
        best_match: Optional[LearnedRule] = None
        best_score = 0.0
        
        for pattern, rule in self._learned_rules.items():
            # Check if normalized pattern contains the rule pattern
            if pattern in normalized_pattern or normalized_pattern in pattern:
                score = rule.confidence * 0.8  # Slight penalty for fuzzy match
                if score > best_score:
                    best_score = score
                    best_match = rule
        
        if best_match:
            best_match.last_used = datetime.now()
        
        return best_match
    
    def prune(self) -> int:
        """
        Remove low-performing or expired rules.
        
        A rule is pruned if:
        1. Confidence falls below min_confidence threshold
        2. Hasn't been used in decay_days
        
        Returns:
            Number of rules pruned
        """
        now = datetime.now()
        cutoff = now - timedelta(days=self._decay_days)
        
        rules_to_remove = []
        
        for pattern, rule in self._learned_rules.items():
            # Check confidence threshold
            if rule.confidence < self._min_confidence:
                rules_to_remove.append(pattern)
                continue
            
            # Check decay (hasn't been used in a long time)
            if rule.last_used < cutoff:
                # Apply decay penalty
                days_unused = (now - rule.last_used).days
                decay_factor = max(0.5, 1.0 - (days_unused / (self._decay_days * 2)))
                rule.confidence *= decay_factor
                
                # Remove if decayed too much
                if rule.confidence < self._min_confidence:
                    rules_to_remove.append(pattern)
        
        # Remove the rules
        for pattern in rules_to_remove:
            del self._learned_rules[pattern]
        
        return len(rules_to_remove)
    
    def export_rules(self) -> Dict[str, Any]:
        """
        Export all rules to a serializable format.
        
        Returns:
            Dictionary containing all rules and metadata
        """
        return {
            "version": "1.0",
            "exported_at": datetime.now().isoformat(),
            "total_rules": len(self._learned_rules),
            "total_recordings": self._total_recordings,
            "total_learned": self._total_learned,
            "rules": [rule.to_dict() for rule in self._learned_rules.values()],
        }
    
    def import_rules(self, data: Dict[str, Any]) -> int:
        """
        Import rules from a serialized format.
        
        Args:
            data: Dictionary from export_rules()
            
        Returns:
            Number of rules imported
        """
        if "rules" not in data:
            return 0
        
        imported = 0
        for rule_dict in data["rules"]:
            try:
                rule = LearnedRule.from_dict(rule_dict)
                self._learned_rules[rule.pattern] = rule
                imported += 1
            except (KeyError, TypeError, ValueError):
                # Skip invalid rules
                continue
        
        if "total_recordings" in data:
            self._total_recordings = data["total_recordings"]
        if "total_learned" in data:
            self._total_learned = data["total_learned"]
        
        return imported
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get learner statistics.
        
        Returns:
            Dictionary with learner stats
        """
        rules = list(self._learned_rules.values())
        avg_confidence = statistics.mean([r.confidence for r in rules]) if rules else 0.0
        avg_success_rate = statistics.mean([r.success_rate for r in rules]) if rules else 0.0
        
        return {
            "total_recordings": self._total_recordings,
            "total_learned": self._total_learned,
            "active_rules": len(self._learned_rules),
            "average_confidence": avg_confidence,
            "average_success_rate": avg_success_rate,
            "history_size": len(self._error_recovery_pairs),
            "min_samples_threshold": self._min_samples,
            "decay_days": self._decay_days,
        }
    
    def reset(self) -> None:
        """Reset all learning data."""
        self._error_recovery_pairs.clear()
        self._learned_rules.clear()
        self._total_recordings = 0
        self._total_learned = 0
    
    # ========== Private Methods ==========
    
    def _extract_pattern(self, error_msg: str) -> str:
        """
        Extract a normalized pattern from error message.
        
        This removes specific values while preserving the error structure:
        - Removes quoted strings
        - Removes numbers
        - Removes UUIDs
        - Normalizes whitespace
        
        Examples:
            "OpenAI model gpt-5 does not exist" → "openai model * does not exist"
            "Rate limit exceeded. Retry after 30 seconds" → "rate limit exceeded retry after * seconds"
        
        Args:
            error_msg: The original error message
            
        Returns:
            Normalized pattern string
        """
        if not error_msg:
            return ""
        
        # Convert to lowercase
        text = error_msg.lower()
        
        # Remove quoted strings (both single and double quotes)
        text = re.sub(r"['\"`].*?['\"`]", "*", text)
        
        # Remove UUIDs (various formats)
        text = re.sub(
            r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            "*", text, flags=re.IGNORECASE
        )
        
        # Remove common ID patterns (numeric IDs, request IDs, etc.)
        text = re.sub(r"(id|request_id|trace_id)[\s:=]+[\w-]+", r"\1 *", text, flags=re.IGNORECASE)
        
        # Remove numbers (but keep structure)
        text = re.sub(r"\b\d+(?:\.\d+)?\b", "*", text)
        
        # Remove model names (common patterns)
        text = re.sub(
            r"(gpt|claude|gemini|qwen|llama|deepseek)[\d.\-\w]*",
            "*", text, flags=re.IGNORECASE
        )
        
        # Remove API key patterns
        text = re.sub(r"sk-[a-zA-Z0-9\-]+", "*", text)
        
        # Remove timestamps
        text = re.sub(r"\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}[^\s]*", "*", text)
        
        # Normalize whitespace
        text = re.sub(r"\s+", " ", text).strip()
        
        return text
    
    def _optimize_action_params(
        self,
        action: str,
        pairs: List[ErrorRecoveryPair],
        median_latency: float,
    ) -> Dict[str, Any]:
        """
        Optimize action parameters based on history.
        
        Args:
            action: The action type
            pairs: Historical observations
            median_latency: Median latency from observations
            
        Returns:
            Optimized action parameters
        """
        if action == "retry_with_delay":
            # Optimize delay: use median of successful retries
            successful_pairs = [p for p in pairs if p.success and p.latency > 0]
            if successful_pairs:
                successful_latencies = [p.latency for p in successful_pairs]
                optimized_delay = statistics.median(successful_latencies)
            else:
                optimized_delay = median_latency
            
            return {
                "delay": round(optimized_delay, 2),
                "max_delay": round(optimized_delay * 3, 2),
            }
        
        elif action == "fallback_to":
            # Find best performing fallback model
            model_stats: Dict[str, Tuple[int, int]] = defaultdict(lambda: (0, 0))
            for p in pairs:
                model = p.action_params.get("fallback_model", "unknown")
                total, success = model_stats[model]
                model_stats[model] = (total + 1, success + (1 if p.success else 0))
            
            best_model = max(
                model_stats.items(),
                key=lambda x: x[1][1] / x[1][0] if x[1][0] > 0 else 0
            )
            
            return {
                "fallback_model": best_model[0],
                "success_rate": best_model[1][1] / best_model[1][0] if best_model[1][0] > 0 else 0,
            }
        
        elif action == "circuit_break":
            return {
                "circuit_timeout": 300,  # 5 minutes default
            }
        
        return {}
    
    def _generate_rule_id(self, pattern: str) -> str:
        """
        Generate a unique rule ID from pattern.
        
        Args:
            pattern: The error pattern
            
        Returns:
            Unique rule ID
        """
        # Create short hash from pattern
        hash_input = f"{pattern}_{uuid.uuid4()}"
        short_hash = hashlib.md5(hash_input.encode()).hexdigest()[:8]
        return f"rule_{short_hash}"
    
    def _suggest_action(
        self,
        pattern: str,
        history: List[ErrorRecoveryPair],
    ) -> Tuple[str, Dict[str, Any], float]:
        """
        Suggest the best action based on history.
        
        Args:
            pattern: The error pattern
            history: Historical observations for this pattern
            
        Returns:
            Tuple of (action_name, action_params, confidence)
        """
        if not history:
            return "retry_with_delay", {"delay": 2.0}, 0.0
        
        # Group by action
        action_groups: Dict[str, List[ErrorRecoveryPair]] = defaultdict(list)
        for p in history:
            action_groups[p.action].append(p)
        
        # Calculate success rate for each action
        action_scores = {}
        for action, pairs in action_groups.items():
            successes = sum(1 for p in pairs if p.success)
            rate = successes / len(pairs) if pairs else 0
            action_scores[action] = (rate, pairs)
        
        # Find best action
        if not action_scores:
            return "retry_with_delay", {"delay": 2.0}, 0.0
        
        best_action = max(action_scores.items(), key=lambda x: x[1][0])
        best_action_name = best_action[0]
        best_action_rate = best_action[1][0]
        best_action_pairs = best_action[1][1]
        
        # Calculate confidence based on sample size and success rate
        confidence = min(1.0, best_action_rate + (len(best_action_pairs) * 0.02))
        
        # Optimize params for best action
        action_params = self._optimize_action_params(
            best_action_name,
            best_action_pairs,
            statistics.median([p.latency for p in best_action_pairs if p.latency > 0]) if best_action_pairs else 2.0
        )
        
        return best_action_name, action_params, confidence


# ========== Convenience Functions ==========


def create_learner(
    min_samples: int = 3,
    decay_days: int = 30,
) -> FlywheelLearner:
    """
    Create a new FlywheelLearner instance.
    
    Args:
        min_samples: Minimum observations before extracting a rule
        decay_days: Days before unused rules decay
        
    Returns:
        Configured FlywheelLearner instance
    """
    return FlywheelLearner(min_samples=min_samples, decay_days=decay_days)
