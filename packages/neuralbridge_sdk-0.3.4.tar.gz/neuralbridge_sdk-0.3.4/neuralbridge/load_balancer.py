"""
NeuralBridge Load Balancer.

Provides intelligent model selection with multiple balancing strategies:
1. Random - Pure random selection
2. RoundRobin - Cyclic rotation
3. WeightedResponseTime - Prefer faster models
4. LeastConnections - Prefer models with fewer active requests
5. Predictive - Use predictive engine for proactive selection

Features:
- Sliding window performance tracking
- Automatic model health assessment
- Configurable fallback strategies
- Real-time statistics
"""

import random
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class LoadBalancingStrategy(str, Enum):
    """Available load balancing strategies."""
    RANDOM = "random"                    # Pure random selection
    ROUND_ROBIN = "round_robin"          # Cyclic rotation
    WEIGHTED_RESPONSE_TIME = "weighted_response_time"  # Prefer faster models
    LEAST_CONNECTIONS = "least_connections"  # Prefer models with fewer requests
    PREDICTIVE = "predictive"            # Use predictive engine (PRO only)


@dataclass
class LoadBalancerConfig:
    """Configuration for load balancer."""
    strategy: LoadBalancingStrategy = LoadBalancingStrategy.WEIGHTED_RESPONSE_TIME
    window_seconds: int = 300           # Performance window (5 min)
    health_check_interval: int = 60     # Health check interval (1 min)
    min_sample_count: int = 3           # Minimum samples before considering
    enable_auto_recovery: bool = True   # Auto-recover from degraded models
    fallback_strategy: LoadBalancingStrategy = LoadBalancingStrategy.RANDOM


@dataclass
class ModelLoadInfo:
    """Load information for a model."""
    model: str
    active_connections: int = 0
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    total_latency_ms: float = 0.0
    recent_latencies: deque = field(default_factory=lambda: deque(maxlen=100))
    last_request_time: float = 0.0
    health_score: float = 1.0  # 0.0 to 1.0
    
    @property
    def avg_latency_ms(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.total_latency_ms / self.total_requests
    
    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 1.0
        return self.successful_requests / self.total_requests
    
    @property
    def p95_latency_ms(self) -> float:
        if not self.recent_latencies:
            return 0.0
        sorted_latencies = sorted(self.recent_latencies)
        idx = int(len(sorted_latencies) * 0.95)
        return sorted_latencies[min(idx, len(sorted_latencies) - 1)]


class LoadBalancer:
    """
    Intelligent load balancer for model selection.
    
    Distributes requests across multiple models using various strategies
    to optimize for performance, reliability, and cost.
    
    Usage:
        lb = LoadBalancer(
            models=["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet"],
            config=LoadBalancerConfig(strategy=LoadBalancingStrategy.WEIGHTED_RESPONSE_TIME)
        )
        
        selected_model = lb.select_model()
        lb.record_result(selected_model, latency_ms=150, success=True)
    """
    
    def __init__(
        self,
        models: List[str],
        config: Optional[LoadBalancerConfig] = None,
        predictive_engine=None,  # Optional PredictiveEngine for predictive strategy
        license_manager=None,     # Optional LicenseManager for feature gating
    ):
        """
        Initialize load balancer.
        
        Args:
            models: List of available model names
            config: Load balancer configuration
            predictive_engine: Optional PredictiveEngine instance
            license_manager: Optional LicenseManager for feature gating
        """
        self.models = models
        self.config = config or LoadBalancerConfig()
        self.predictive_engine = predictive_engine
        self.license_manager = license_manager
        
        # Model load information
        self._model_info: Dict[str, ModelLoadInfo] = {
            m: ModelLoadInfo(model=m) for m in models
        }
        
        # Round robin state
        self._round_robin_index: int = 0
        self._round_robin_locked: bool = False
        
        # Statistics
        self._total_selections: int = 0
        self._selection_history: deque = deque(maxlen=1000)
        
        # Check PRO features
        self._predictive_enabled = (
            self.config.strategy == LoadBalancingStrategy.PREDICTIVE and
            self.predictive_engine is not None
        )
        
        if self.config.strategy == LoadBalancingStrategy.PREDICTIVE and self._predictive_enabled:
            if license_manager and not license_manager.check_feature("load_balancer"):
                # Fallback to weighted response time if PRO feature not available
                self.config.strategy = LoadBalancingStrategy.WEIGHTED_RESPONSE_TIME
                self._predictive_enabled = False
    
    def select_model(self) -> str:
        """
        Select a model using the configured strategy.
        
        Returns:
            Selected model name
        """
        # Filter out unhealthy models
        available_models = self._get_healthy_models()
        
        if not available_models:
            # All models unhealthy, fall back to all models
            available_models = self.models
        
        # Select based on strategy
        if self.config.strategy == LoadBalancingStrategy.RANDOM:
            selected = self._select_random(available_models)
        elif self.config.strategy == LoadBalancingStrategy.ROUND_ROBIN:
            selected = self._select_round_robin(available_models)
        elif self.config.strategy == LoadBalancingStrategy.WEIGHTED_RESPONSE_TIME:
            selected = self._select_weighted_response_time(available_models)
        elif self.config.strategy == LoadBalancingStrategy.LEAST_CONNECTIONS:
            selected = self._select_least_connections(available_models)
        elif self.config.strategy == LoadBalancingStrategy.PREDICTIVE:
            selected = self._select_predictive(available_models)
        else:
            selected = self._select_weighted_response_time(available_models)
        
        # Update connection count
        self._model_info[selected].active_connections += 1
        self._model_info[selected].last_request_time = time.time()
        
        # Record selection
        self._total_selections += 1
        self._selection_history.append({
            "timestamp": time.time(),
            "model": selected,
            "strategy": self.config.strategy.value,
        })
        
        return selected
    
    def _get_healthy_models(self) -> List[str]:
        """Get list of healthy models based on health scores."""
        return [
            m for m in self.models
            if self._model_info[m].health_score >= 0.5
        ]
    
    def _select_random(self, models: List[str]) -> str:
        """Random selection strategy."""
        return random.choice(models)
    
    def _select_round_robin(self, models: List[str]) -> str:
        """Round robin selection strategy."""
        if not models:
            return self.models[0]
        
        # Find the next index that corresponds to a healthy model
        attempts = 0
        while attempts < len(models):
            index = self._round_robin_index % len(models)
            model = self.models[index]
            
            if model in models:
                self._round_robin_index = (index + 1) % len(models)
                return model
            
            self._round_robin_index = (index + 1) % len(models)
            attempts += 1
        
        # Fallback to first model
        return models[0]
    
    def _select_weighted_response_time(self, models: List[str]) -> str:
        """
        Weighted response time selection.
        
        Models with lower average latency have higher weight.
        Weight = 1 / (avg_latency + 1) to avoid division by zero.
        """
        if len(models) == 1:
            return models[0]
        
        weights = []
        for model in models:
            info = self._model_info[model]
            avg_latency = info.avg_latency_ms if info.total_requests > 0 else 100  # Default 100ms
            
            # Weight inversely proportional to latency
            # Add small epsilon to prevent division issues
            weight = 1.0 / (avg_latency + 10)
            weights.append(weight)
        
        # Weighted random selection
        total_weight = sum(weights)
        if total_weight == 0:
            return random.choice(models)
        
        normalized_weights = [w / total_weight for w in weights]
        return random.choices(models, weights=normalized_weights)[0]
    
    def _select_least_connections(self, models: List[str]) -> str:
        """Select model with least active connections."""
        if len(models) == 1:
            return models[0]
        
        # Find model with minimum connections
        min_connections = float('inf')
        selected = models[0]
        
        for model in models:
            connections = self._model_info[model].active_connections
            if connections < min_connections:
                min_connections = connections
                selected = model
        
        return selected
    
    def _select_predictive(self, models: List[str]) -> str:
        """Select model using predictive engine."""
        if not self._predictive_enabled or not self.predictive_engine:
            return self._select_weighted_response_time(models)
        
        # Use predictive engine to find the best model
        predictions = []
        for model in models:
            pred = self.predictive_engine.predict(model)
            predictions.append((model, pred))
        
        # Sort by confidence (higher is better)
        predictions.sort(key=lambda x: x[1].confidence, reverse=True)
        
        # Return the model with highest prediction confidence
        # If all are low confidence, fall back to weighted response time
        for model, pred in predictions:
            if pred.should_switch and pred.recommended_model:
                if pred.recommended_model in models:
                    return pred.recommended_model
        
        # Fallback to best performing model
        return self._select_weighted_response_time(models)
    
    def record_result(
        self,
        model: str,
        latency_ms: float,
        success: bool,
        error: Optional[str] = None
    ) -> None:
        """
        Record the result of a request for a model.
        
        Args:
            model: The model that was used
            latency_ms: Request latency in milliseconds
            success: Whether the request succeeded
            error: Optional error message
        """
        if model not in self._model_info:
            return
        
        info = self._model_info[model]
        
        # Decrement active connections
        info.active_connections = max(0, info.active_connections - 1)
        
        # Update statistics
        info.total_requests += 1
        info.total_latency_ms += latency_ms
        info.recent_latencies.append(latency_ms)
        
        if success:
            info.successful_requests += 1
        else:
            info.failed_requests += 1
        
        # Update health score
        self._update_health_score(model)
        
        # Record to predictive engine if available
        if self.predictive_engine:
            self.predictive_engine.record_request(model, latency_ms, success)
    
    def _update_health_score(self, model: str) -> None:
        """Update the health score for a model based on recent performance."""
        info = self._model_info[model]
        
        if info.total_requests < self.config.min_sample_count:
            info.health_score = 1.0  # Not enough data, assume healthy
            return
        
        # Calculate health score components
        success_score = info.success_rate
        
        # Latency score (normalize against 5000ms threshold)
        latency_score = 1.0
        if info.avg_latency_ms > 5000:
            latency_score = max(0.0, 1.0 - (info.avg_latency_ms - 5000) / 5000)
        elif info.avg_latency_ms > 1000:
            latency_score = max(0.5, 1.0 - (info.avg_latency_ms - 1000) / 4000)
        
        # Combined health score
        info.health_score = (success_score * 0.7) + (latency_score * 0.3)
    
    def release_connection(self, model: str) -> None:
        """Manually release a connection for a model."""
        if model in self._model_info:
            self._model_info[model].active_connections = max(
                0, self._model_info[model].active_connections - 1
            )
    
    def get_model_stats(self, model: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a specific model."""
        if model not in self._model_info:
            return None
        
        info = self._model_info[model]
        return {
            "model": model,
            "active_connections": info.active_connections,
            "total_requests": info.total_requests,
            "successful_requests": info.successful_requests,
            "failed_requests": info.failed_requests,
            "success_rate": round(info.success_rate * 100, 2),
            "avg_latency_ms": round(info.avg_latency_ms, 2),
            "p95_latency_ms": round(info.p95_latency_ms, 2),
            "health_score": round(info.health_score, 3),
            "last_request_time": info.last_request_time,
        }
    
    def get_all_stats(self) -> Dict[str, Any]:
        """Get statistics for all models."""
        return {
            "strategy": self.config.strategy.value,
            "total_selections": self._total_selections,
            "models": {m: self.get_model_stats(m) for m in self.models},
            "healthy_models": self._get_healthy_models(),
        }
    
    def reset(self) -> None:
        """Reset all statistics and state."""
        self._model_info = {
            m: ModelLoadInfo(model=m) for m in self.models
        }
        self._round_robin_index = 0
        self._total_selections = 0
        self._selection_history.clear()


def generate_test_key(tier: str = "PRO") -> str:
    """
    Generate a test license key for development/testing.
    
    Args:
        tier: License tier ("PRO" or "ENTERPRISE")
        
    Returns:
        Formatted license key
    """
    import hashlib
    
    tier_prefix = tier.upper()
    random_data = str(uuid.uuid4()).replace("-", "")[:12]
    
    # Generate checksum
    salt = "nB_s3lfH3al_2026"
    checksum_source = f"{tier_prefix}{random_data}{salt}"
    checksum = hashlib.sha256(checksum_source.encode()).hexdigest()[:8].upper()
    
    return f"NB-{tier_prefix}-{random_data[:4]}-{random_data[4:8]}-{checksum}"
