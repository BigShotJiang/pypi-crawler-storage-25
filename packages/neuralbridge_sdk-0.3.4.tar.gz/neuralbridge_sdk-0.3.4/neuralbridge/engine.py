"""
NeuralBridge Core Engine.

Self-healing decision engine for AI API calls. Provides automatic fault
diagnosis, cascade recovery, and transparent model switching.

This is the heart of the NeuralBridge SDK - the FlywheelEngine orchestrates
diagnosis, strategy selection, and recovery actions.
"""

import asyncio
import time
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, TypeVar, Generator, Iterator, Union

from .types import (
    DiagnosisResult,
    ErrorCategory,
    RecoveryAction,
    RecoveryRecord,
    CascadeLevel,
    ModelPerformance,
    HealthStatus,
    RequestTrace,
    ModelHealth,
    RecoveryStats,
)
from .predictive import PredictiveEngine, PredictiveConfig, Prediction
from .strategies import (
    RecoveryStrategy,
    RateLimitStrategy,
    AuthRefreshStrategy,
    ModelFallbackStrategy,
    NetworkRetryStrategy,
    StrategyRegistry,
)
from .jitter import JitterConfig, JitterStrategy, DEFAULT_JITTER_CONFIG
from .learner import FlywheelLearner, LearnedRule


T = TypeVar('T')


class DiagnosisEngine:
    """
    Analyzes errors and determines recovery strategy.
    
    Maps HTTP status codes and exception types to error categories,
    then suggests appropriate recovery actions.
    """
    
    # HTTP status code to error category mapping
    STATUS_CODE_MAP = {
        400: ErrorCategory.VALIDATION_ERROR,
        401: ErrorCategory.AUTH_ERROR,
        403: ErrorCategory.AUTH_ERROR,
        404: ErrorCategory.MODEL_UNAVAILABLE,
        408: ErrorCategory.NETWORK_ERROR,
        429: ErrorCategory.RATE_LIMIT,
        500: ErrorCategory.SERVER_ERROR,
        502: ErrorCategory.SERVER_ERROR,
        503: ErrorCategory.SERVER_ERROR,
        504: ErrorCategory.SERVER_ERROR,
    }
    
    # Comprehensive error pattern library organized by platform
    # Structure: (sub_category, category, keywords, confidence)
    # confidence: 0.95 for exact matches, 0.7 for fuzzy matches
    #
    # DESIGN PRINCIPLES:
    # - Platform-specific groups ONLY contain unique identifiers for that platform
    # - Generic keywords go in the generic groups
    # - Match order: detected platform first -> platform-specific patterns -> generic patterns
    #
    # Platform detection keywords are in _detect_platforms(), NOT in pattern matching
    _ERROR_PATTERNS = {
        # ========== OpenAI Patterns (ONLY OpenAI-specific identifiers) ==========
        "openai": [
            ("openai_rate_limit", ErrorCategory.RATE_LIMIT, [
                "openai's api is currently overloaded",
                "openai api request error",
            ], 0.95),
            ("openai_auth_error", ErrorCategory.AUTH_ERROR, [
                "billing hard limit reached",
                "billing soft limit",
                "you exceeded your billing limit",
            ], 0.95),
            ("openai_model_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "openai gave a 404",
                "the model",  # specific OpenAI error format
            ], 0.95),
            ("openai_server_error", ErrorCategory.SERVER_ERROR, [
                "openai server error",
            ], 0.95),
            ("openai_realtime_server_error", ErrorCategory.SERVER_ERROR, [
                "realtime server error",  # OpenAI Realtime API - related to tools count
            ], 0.95),
        ],
        
        # ========== Azure OpenAI Patterns (ONLY Azure-specific identifiers) ==========
        "azure": [
            ("azure_throttling", ErrorCategory.RATE_LIMIT, [
                "throttling.ratequota",
                "throttled due to rate quota",
                "deployments/rateLimit",
            ], 0.95),
            ("azure_quota_exceeded", ErrorCategory.RATE_LIMIT, [
                " quota exceeded.",
                "monthly spend limit",
                "subscription quota",
            ], 0.95),
            ("azure_deployment_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "resource not found",
                "invalid deployment",
                "api-version",
            ], 0.9),
            ("azure_auth_error", ErrorCategory.AUTH_ERROR, [
                "aad login",
                "azure ad token",
                "azuread",
            ], 0.95),
            ("azure_responses_api_error", ErrorCategory.SERVER_ERROR, [
                "responses api",  # Azure Responses API 500 error (regional)
            ], 0.95),
        ],
        
        # ========== Anthropic Patterns (ONLY Anthropic-specific identifiers) ==========
        "anthropic": [
            ("anthropic_overloaded", ErrorCategory.SERVER_ERROR, [
                "overloaded_error",  # Anthropic's specific error code
                "anthropic is overloaded",
                "error 529",  # Anthropic 529 Overloaded (Opus more sensitive)
            ], 0.95),
            ("anthropic_auth_error", ErrorCategory.AUTH_ERROR, [
                "x-api-key",
            ], 0.95),
        ],
        
        # ========== Google/VertexAI Patterns (ONLY Google-specific identifiers) ==========
        "google": [
            ("google_resource_exhausted", ErrorCategory.RATE_LIMIT, [
                "resource_exhausted",
                "quota exhausted",  # Google-specific quota message
            ], 0.95),
            ("google_permission_denied", ErrorCategory.AUTH_ERROR, [
                "permission_denied",
            ], 0.95),
            ("google_binary_response", ErrorCategory.VALIDATION_ERROR, [
                "binary function response",  # Gemini audio/video not supported
            ], 0.95),
        ],
        
        # ========== DashScope/阿里云/DeepSeek Patterns (ONLY DashScope-specific identifiers) ==========
        "dashscope": [
            ("dashscope_rate_limit", ErrorCategory.RATE_LIMIT, [
                "throttling.ratequota",
                "请求过于频繁",
                "请求速度超限",
            ], 0.95),
            ("dashscope_auth_error", ErrorCategory.AUTH_ERROR, [
                "invalidparameter",
                "invalidcredential",
                "凭证无效",
                "invalid credential",
            ], 0.9),
            ("dashscope_model_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "modelnotexists",
                "模型不存在",
                "模型不可用",
            ], 0.95),
            ("dashscope_service_unavailable", ErrorCategory.SERVER_ERROR, [
                "serviceunavailable",
                "服务不可用",
                "系统错误",
            ], 0.9),
            ("dashscope_quota_exceeded", ErrorCategory.RATE_LIMIT, [
                "quota exceeded",
                "quota used up",
                "配额不足",
                "额度用尽",
            ], 0.95),
            ("deepseek_reasoning_missing", ErrorCategory.VALIDATION_ERROR, [
                "reasoning_content",  # DeepSeek V4 multi-turn ~100K tokens
                "reasoning content missing",
            ], 0.95),
        ],
        
        # ========== Generic Network Errors (ALL generic network keywords) ==========
        "network": [
            ("generic_network", ErrorCategory.NETWORK_ERROR, [
                "connection refused", "connection reset", "connection aborted",
                "name resolution", "dns", "ssl", "sslerror", "certificate",
                "socket", "eof", "broken pipe", "read timeout", "connect timeout",
                "connection timeout", "connection error", "network error",
                "network unreachable", "host unreachable", "no route to host",
                "connection closed", "connection closed by peer",
                "unable to connect", "failed to connect", "connect error",
                "connection timed out", "operation timed out",
                "temporarily unavailable", "timed out", "timeout",
            ], 0.95),
        ],
        
        # ========== Generic Auth Errors (ALL generic auth keywords) ==========
        "auth": [
            ("generic_auth", ErrorCategory.AUTH_ERROR, [
                "invalid api key", "incorrect api key", "api key not valid",
                "api key not found", "authentication failed", "permission denied",
                "forbidden", "unauthorized", "access denied", "invalid token",
                "token expired", "token invalid", "invalid credentials",
                "auth failed", "auth error", "401", "403", "invalid authorization",
            ], 0.9),
        ],
        
        # ========== Generic Rate Limit Errors (ALL generic rate limit keywords) ==========
        "rate_limit": [
            ("generic_rate_limit", ErrorCategory.RATE_LIMIT, [
                "rate limit", "rate_limit", "too many requests", "429",
                "rate limit exceeded", "requests per minute", "tokens per minute",
                "request rate too high", "ratequota exceeded",
                "throttled", "throttling", "quota exceeded",
                "slow down", "request limit", "capacity",
                "requests per", "please retry", "retry after",
                "too many", "limit exceeded",
            ], 0.9),
        ],
        
        # ========== Generic Model Errors (ALL generic model keywords) ==========
        "model": [
            ("generic_model_not_found", ErrorCategory.MODEL_UNAVAILABLE, [
                "model not found", "model not exist", "model not available",
                "does not exist", "invalid model", "unknown model",
                "404", "not found", "unavailable", "model_not_found",
                "model_not_exists", "model unavailable",
            ], 0.85),
        ],
        
        # ========== Generic Validation Errors (ALL generic validation keywords) ==========
        "validation": [
            ("generic_validation", ErrorCategory.VALIDATION_ERROR, [
                "context length exceeded", "maximum context length", "too many tokens",
                "exceeds maximum", "tokens limit", "input too long",
                "maximum tokens", "context_window",
                "prompt too long", "message too long", "token limit",
                "invalid argument", "invalid parameters", "bad request",
                "400", "invalid request",
                # Tool call related errors
                "tool call message missing", "missing tool response",
                "tool call without function call",
            ], 0.9),
            ("mcp_tool_error", ErrorCategory.VALIDATION_ERROR, [
                # MCP (Model Context Protocol) related errors
                "mcp tool", "mcp_error", "mcp call failed",
            ], 0.95),
        ],
        
        # ========== Generic Server Errors (ALL generic server keywords) ==========
        "server": [
            ("generic_server", ErrorCategory.SERVER_ERROR, [
                "internal server error", "server error", "service unavailable",
                "bad gateway", "gateway timeout", "503", "502", "504",
                "500", "upstream error", "downstream error",
                "high demand", "capacity", "overloaded",
            ], 0.85),
        ],
    }
    
    def __init__(self, verbose: bool = False):
        """
        Initialize diagnosis engine.
        
        Args:
            verbose: Enable verbose logging
        """
        self.verbose = verbose
    
    def diagnose(self, error: Exception, metadata: Optional[Dict[str, Any]] = None) -> DiagnosisResult:
        """
        Diagnose an error and return a diagnosis result.
        
        Args:
            error: The exception to diagnose
            metadata: Additional context (status_code, headers, body, etc.)
            
        Returns:
            DiagnosisResult with category, retryability, and suggestions
        """
        metadata = metadata or {}
        
        # Extract status code if available
        status_code = self._extract_status_code(error, metadata)
        
        # Determine error category with enhanced pattern matching
        if status_code:
            category = self.STATUS_CODE_MAP.get(status_code, ErrorCategory.UNKNOWN)
            sub_category = f"http_{status_code}"
            confidence = 0.95
        else:
            category, sub_category, confidence = self._categorize_from_exception(error)
        
        # Determine if error is retryable
        retryable = self._is_retryable(category, status_code)
        
        # Generate suggestion with platform-specific advice
        suggestion = self._generate_suggestion(category, retryable, metadata, sub_category)
        
        result = DiagnosisResult(
            category=category,
            retryable=retryable,
            suggestion=suggestion,
            metadata=metadata,
            sub_category=sub_category,
            confidence=confidence,
        )
        
        if self.verbose:
            print(f"[NeuralBridge Diagnosis] [{sub_category}] {category.value}: {suggestion}")
        
        return result
    
    def _extract_status_code(self, error: Exception, metadata: Dict[str, Any]) -> Optional[int]:
        """Extract HTTP status code from error or metadata."""
        # Check metadata first
        if "status_code" in metadata:
            return metadata["status_code"]
        
        # Check error attributes
        if hasattr(error, "status_code"):
            return error.status_code
        if hasattr(error, "response") and hasattr(error.response, "status_code"):
            return error.response.status_code
        
        return None
    
    def _categorize_from_exception(self, error: Exception) -> tuple:
        """
        Categorize error based on exception type using comprehensive pattern matching.
        
        Returns:
            Tuple of (ErrorCategory, sub_category, confidence)
        """
        error_msg = str(error).lower()
        error_type = type(error).__name__.lower()
        error_repr = repr(error).lower()
        
        # Priority order: detected platforms first, then generic groups
        # Generic groups ordered by specificity: validation > network > auth > rate_limit > model > server
        platform_priority = ["network", "validation", "auth", "rate_limit", "model", "server"]
        
        best_match = None
        best_confidence = 0.0
        
        # Try to detect platform from error message first (for better specificity)
        detected_platforms = self._detect_platforms(error_msg, error_repr)
        
        # Order platforms: detected ones first, then remaining
        ordered_platforms = detected_platforms + [p for p in platform_priority if p not in detected_platforms]
        
        for platform in ordered_platforms:
            if platform not in self._ERROR_PATTERNS:
                continue
                
            patterns = self._ERROR_PATTERNS[platform]
            
            for sub_cat, cat, keywords, base_conf in patterns:
                matched = False
                for keyword in keywords:
                    # Check both exception message and type name
                    if keyword.lower() in error_msg or keyword.lower() in error_type:
                        # Use the highest confidence match found
                        if base_conf > best_confidence:
                            best_match = (cat, sub_cat, base_conf)
                            best_confidence = base_conf
                            matched = True
                            break
                
                if matched and best_confidence >= 0.95:  # Found exact match
                    break
            
            if best_confidence >= 0.95:
                break
        
        if best_match:
            return best_match
        
        # Fallback: basic exception type check
        if any(keyword in error_type for keyword in ["timeout", "connection", "network", "ssl"]):
            return (ErrorCategory.NETWORK_ERROR, "generic_network", 0.7)
        
        if any(keyword in error_msg for keyword in ["rate limit", "too many", "429", "quota"]):
            return (ErrorCategory.RATE_LIMIT, "generic_rate_limit", 0.7)
        
        if any(keyword in error_msg for keyword in ["unauthorized", "auth", "token", "401", "403", "invalid api"]):
            return (ErrorCategory.AUTH_ERROR, "generic_auth", 0.7)
        
        if any(keyword in error_msg for keyword in ["model", "not found", "404", "unavailable"]):
            return (ErrorCategory.MODEL_UNAVAILABLE, "generic_model_not_found", 0.7)
        
        # Ultimate fallback
        return (ErrorCategory.UNKNOWN, "unknown", 0.3)
    
    def _detect_platforms(self, error_msg: str, error_repr: str) -> List[str]:
        """
        Detect which platforms might be involved based on error message.
        
        This is used to prioritize platform-specific pattern matching.
        The detection uses platform-unique identifiers, NOT generic keywords.
        """
        platforms = []
        
        # Platform detection keywords (platform-unique identifiers)
        # These are specific to each platform and help narrow down the source
        platform_keywords = {
            "openai": [
                "openai", "gpt", "chatgpt", "dalle", "whisper",
                "openai's", "openai api",  # OpenAI-specific error format
                "billing hard limit", "you exceeded your billing",  # OpenAI billing
                "openai gave a 404",
            ],
            "azure": [
                "azure", "azureopenai", "azure openai", "cognitive services",
                "azure ad", "aad login", "deployment", "deployments/rate",
            ],
            "anthropic": [
                "anthropic", "claude", "x-api-key",
                "overloaded_error",  # Anthropic-specific error code
            ],
            "google": [
                "google", "vertex", "gemini", "palm", "bard",
                "resource_exhausted", "permission_denied",
            ],
            "dashscope": [
                "dashscope", "aliyun", "通义千问", "tongyi", "qwen",
                "modelnotexists", "serviceunavailable",
            ],
        }
        
        for platform, keywords in platform_keywords.items():
            for keyword in keywords:
                if keyword in error_msg:
                    platforms.append(platform)
                    break
        
        return platforms
    
    def _is_retryable(self, category: ErrorCategory, status_code: Optional[int]) -> bool:
        """Determine if an error category is retryable."""
        non_retryable = {
            ErrorCategory.AUTH_ERROR,
            ErrorCategory.VALIDATION_ERROR,
            ErrorCategory.MODEL_UNAVAILABLE,
        }
        
        if category in non_retryable:
            return False
        
        if status_code:
            # 4xx errors are generally not retryable
            if 400 <= status_code < 500 and status_code != 429:
                return False
        
        return True
    
    def _generate_suggestion(
        self,
        category: ErrorCategory,
        retryable: bool,
        metadata: Dict[str, Any],
        sub_category: Optional[str] = None
    ) -> str:
        """Generate human-readable suggestion for recovery with platform-specific advice."""
        retry_after = metadata.get("retry_after")
        
        # Platform-specific suggestions for rate limits
        if category == ErrorCategory.RATE_LIMIT:
            if sub_category == "openai_rate_limit":
                suggestion = "OpenAI rate limit hit. Consider using Azure OpenAI as fallback with higher quota, or implement exponential backoff with longer delays."
            elif sub_category == "azure_rate_limit":
                suggestion = "Azure OpenAI rate limit exceeded. Consider provisioning a higher tier or switching to a different deployment."
            elif sub_category == "anthropic_rate_limit":
                suggestion = "Anthropic rate limit reached. Wait and retry with exponential backoff, or switch to OpenAI/Google as fallback."
            elif sub_category == "anthropic_overloaded":
                suggestion = "Anthropic is overloaded (including 529 error, Opus more sensitive). Switch to Sonnet/Haiku as fallback or use a different provider (OpenAI/Google)."
            elif sub_category == "google_rate_limit":
                suggestion = "Google API quota exceeded. Consider increasing quota limits or implementing request batching."
            elif sub_category == "dashscope_rate_limit":
                suggestion = "DashScope rate limit hit. Wait and retry with backoff, or use a different model endpoint."
            elif sub_category == "deepseek_reasoning_missing":
                suggestion = "DeepSeek V4 reasoning_content missing after ~100K tokens in multi-turn. Start a new conversation or truncate history to avoid context overflow."
            else:
                if retry_after:
                    return f"Rate limited. Wait {retry_after}s or use exponential backoff."
                return "Rate limited. Use exponential backoff with jitter."
        
        # Platform-specific suggestions for auth errors
        elif category == ErrorCategory.AUTH_ERROR:
            if sub_category == "openai_auth_error":
                suggestion = "OpenAI API key invalid or expired. Please check your API key or update billing information."
            elif sub_category == "azure_auth_error":
                suggestion = "Azure authentication failed. Check API key, Azure AD token, or subscription status."
            elif sub_category == "anthropic_auth_error":
                suggestion = "Anthropic API key invalid. Verify your x-api-key header and account status."
            elif sub_category == "google_auth_error":
                suggestion = "Google API authentication failed. Check API key, OAuth token, or service account credentials."
            elif sub_category == "dashscope_auth_error":
                suggestion = "DashScope authentication failed. Verify your API key and endpoint configuration."
            else:
                suggestion = "Auth failed. Refresh token or check API key validity."
        
        # Platform-specific suggestions for model errors
        elif category == ErrorCategory.MODEL_UNAVAILABLE:
            if sub_category == "openai_model_not_found":
                suggestion = "OpenAI model not found. Check model name spelling, ensure the model is available in your region, or switch to an alternative model."
            elif sub_category == "azure_deployment_not_found":
                suggestion = "Azure deployment not found. Verify deployment name and resource endpoint configuration."
            elif sub_category == "anthropic_model_not_found":
                suggestion = "Anthropic model unavailable. Check model name or switch to a different Claude model."
            elif sub_category == "google_model_not_found":
                suggestion = "Google model not found. Verify the model name and your API access permissions."
            elif sub_category == "dashscope_model_not_found":
                suggestion = "DashScope model not found. Check model name availability in your region."
            else:
                suggestion = "Model unavailable. Switch to an alternative model."
        
        # Network errors
        elif category == ErrorCategory.NETWORK_ERROR:
            if sub_category == "openai_timeout":
                suggestion = "OpenAI request timed out. Retry with increased timeout or check your network connection."
            else:
                suggestion = "Network issue. Retry with backoff or check connectivity."
        
        # Server errors
        elif category == ErrorCategory.SERVER_ERROR:
            if sub_category == "anthropic_overloaded":
                suggestion = "Anthropic service overloaded (including 529). Wait and retry, or switch to a different provider (Sonnet/Haiku fallback)."
            elif sub_category == "openai_realtime_server_error":
                suggestion = "OpenAI Realtime server error (often related to tools count). Reduce number of tools or switch to standard chat API."
            elif sub_category == "azure_responses_api_error":
                suggestion = "Azure Responses API 500 error (regional issue). Fallback to standard Chat API or switch Azure region."
            else:
                suggestion = "Server error. Retry may succeed as issue may be transient."
        
        # Validation errors
        elif category == ErrorCategory.VALIDATION_ERROR:
            if sub_category and ("context_length" in sub_category or "prompt_too_long" in sub_category):
                suggestion = "Input exceeds model's context limit. Shorten your input or use a model with larger context window."
            elif sub_category == "google_binary_response":
                suggestion = "Gemini does not support binary function response (audio/video). Use text response mode or switch to another provider."
            elif sub_category == "deepseek_reasoning_missing":
                suggestion = "DeepSeek V4 reasoning_content missing. Start new conversation or reduce context length."
            elif sub_category == "mcp_tool_error":
                suggestion = "MCP (Model Context Protocol) tool call failed. Verify MCP server is running and tool schema is correct."
            elif sub_category and "tool" in sub_category:
                suggestion = "Tool call error detected. Verify tool definitions and function call format."
            else:
                suggestion = "Invalid request. Fix request parameters before retrying."
        
        else:
            suggestion = "Unknown error. Consider manual investigation."
        
        return suggestion


class FlywheelEngine:
    """
    Main engine orchestrating diagnosis and recovery.
    
    This is the "flywheel" - once it starts diagnosing and recovering,
    it accumulates momentum, learning from failures and improving
    recovery strategies over time.
    
    Features:
    - Multi-strategy coordination
    - Performance tracking
    - Cascading recovery levels
    - Detailed recovery records
    """
    
    def __init__(
        self,
        fallback_models: Optional[List[str]] = None,
        max_retries: int = 3,
        verbose: bool = False,
        jitter_config: Optional[JitterConfig] = None,
        api_key_refresher: Optional[Callable[[], str]] = None,
        predictive_config: Optional[PredictiveConfig] = None,
        enable_learning: bool = False,
        license_key: Optional[str] = None,
    ):
        """
        Initialize the flywheel engine.
        
        Args:
            fallback_models: Ordered list of fallback model names
            max_retries: Maximum total retry attempts (default: 3)
            verbose: Enable verbose logging (default: False)
            jitter_config: Jitter configuration (default: FullJitter)
            api_key_refresher: Optional function to refresh API key
            predictive_config: Configuration for predictive self-healing (default: None = disabled)
            enable_learning: Enable flywheel learning engine (default: False, requires PRO license)
            license_key: Optional license key for PRO features
        """
        # Initialize license manager
        from .license import LicenseManager, generate_license_key
        self._license_manager = LicenseManager()
        
        # Activate license if provided
        if license_key:
            self._license_manager.activate(license_key)
        elif predictive_config is not None or enable_learning:
            # Generate a trial key for testing
            trial_key = generate_license_key("PRO")
            self._license_manager.activate(trial_key)
        self.fallback_models = fallback_models or []
        self.max_retries = max_retries
        self.verbose = verbose
        
        # Initialize core components
        self.diagnosis_engine = DiagnosisEngine(verbose=verbose)
        self.jitter_config = jitter_config or DEFAULT_JITTER_CONFIG
        
        # Initialize predictive engine (v0.4.0)
        self.predictive_engine = None
        if predictive_config is not None:
            self.predictive_engine = PredictiveEngine(predictive_config)
            self._predictive_enabled = True
        else:
            self._predictive_enabled = False
        
        # Initialize strategies
        self.rate_limit_strategy = RateLimitStrategy(jitter_config=self.jitter_config)
        self.auth_refresh_strategy = AuthRefreshStrategy(refresh_func=api_key_refresher)
        self.model_fallback_strategy = ModelFallbackStrategy(
            fallback_models=self.fallback_models
        )
        self.network_retry_strategy = NetworkRetryStrategy(
            max_retries=max_retries,
            jitter_config=self.jitter_config,
        )
        
        # Strategy registry
        self.strategies = StrategyRegistry()
        self._register_default_strategies()
        
        # Performance tracking
        self.model_performance: Dict[str, ModelPerformance] = {}
        
        # Recovery history
        self.recovery_history: List[RecoveryRecord] = []
        
        # Request tracing (v0.3.3 new feature)
        self._trace_log: List[RequestTrace] = []
        self._request_counter: int = 0
        self._recovery_stats = RecoveryStats()
        
        # Internal recovery log for detailed tracking
        self._recovery_log: List[Dict[str, Any]] = []
        
        # ========== Flywheel Learning Engine (v0.3.3) ==========
        self._learner_enabled = False
        if enable_learning:
            # License check for flywheel learner
            if hasattr(self, '_license_manager') and self._license_manager:
                try:
                    self._license_manager.require_feature("flywheel_learner")
                    self._learner_enabled = True
                except PermissionError as e:
                    if self.verbose:
                        print(f"[NeuralBridge] {e}")
            else:
                self._learner_enabled = True  # No license manager, allow for testing
        self._learner = FlywheelLearner() if self._learner_enabled else None
        self._learning_pending: List[Tuple[str, str, bool, float, Dict]] = []
        
        # Track current error for learning
        self._current_error: Optional[Exception] = None
        self._current_action: Optional[str] = None
        self._current_action_params: Dict = {}
    
    def _record_for_learning(
        self,
        error: Exception,
        action: str,
        action_params: Dict,
        success: bool,
        latency: float = 0.0,
    ) -> None:
        """
        Record error-recovery pair for the learning engine.
        
        Args:
            error: The exception that occurred
            action: Recovery action taken
            action_params: Parameters of the action
            success: Whether recovery succeeded
            latency: Recovery latency in seconds
        """
        if not self._learner_enabled or self._learner is None:
            return
        
        self._learner.record(
            error_pattern=str(error),
            recovery_action=action,
            action_params=action_params,
            success=success,
            latency=latency,
            original_error=str(error),
        )
    
    def _apply_learned_rule(self, error: Exception) -> Optional[RecoveryAction]:
        """
        Try to apply a learned rule for this error.
        
        Args:
            error: The exception to match
            
        Returns:
            RecoveryAction if a learned rule matches, None otherwise
        """
        if not self._learner_enabled or self._learner is None:
            return None
        
        rule = self._learner.match_rule(str(error))
        if rule is None:
            return None
        
        # Convert learned rule to RecoveryAction
        action_type_map = {
            "retry_with_delay": "wait_and_retry",
            "fallback_to": "switch_model",
            "circuit_break": "circuit_break",
        }
        
        action_type = action_type_map.get(rule.action, "wait_and_retry")
        
        return RecoveryAction(
            level=CascadeLevel.L2_WAIT,
            action_type=action_type,
            reason=f"Learned rule (confidence: {rule.confidence:.1%})",
            params=rule.action_params,
        )
    
    def _register_default_strategies(self) -> None:
        """Register the four default recovery strategies."""
        self.strategies.register("rate_limit", self.rate_limit_strategy)
        self.strategies.register("auth_refresh", self.auth_refresh_strategy)
        self.strategies.register("model_fallback", self.model_fallback_strategy)
        self.strategies.register("network_retry", self.network_retry_strategy)
    
    def diagnose(self, error: Exception, metadata: Optional[Dict[str, Any]] = None) -> DiagnosisResult:
        """Convenience method for diagnosis."""
        return self.diagnosis_engine.diagnose(error, metadata)
    
    def enable_predictive_mode(
        self,
        window: str = "5min",
        latency_threshold: float = 2000,
        error_threshold: float = 0.1,
        auto_switch: bool = True,
    ) -> None:
        """
        Enable predictive self-healing mode.
        
        Monitors model health in a sliding window and proactively
        switches to healthier models before failures accumulate.
        
        Args:
            window: Time window for stats ("1min", "5min", "10min")
            latency_threshold: Latency warning threshold in ms
            error_threshold: Error rate warning threshold (0.0-1.0)
            auto_switch: Whether to auto-switch to healthy model
        """
        # License check for predictive engine
        if hasattr(self, '_license_manager') and self._license_manager:
            try:
                self._license_manager.require_feature("predictive_engine")
            except PermissionError as e:
                if self.verbose:
                    print(f"[NeuralBridge] {e}")
                return  # Silently fail, feature not available
        
        window_map = {"1min": 60, "5min": 300, "10min": 600, "15min": 900}
        window_seconds = window_map.get(window, 300)
        
        config = PredictiveConfig(
            window_seconds=window_seconds,
            latency_threshold_ms=latency_threshold,
            error_rate_threshold=error_threshold,
            auto_switch=auto_switch,
        )
        self.predictive_engine = PredictiveEngine(config)
        self._predictive_enabled = True
        
        if self.verbose:
            print(f"[NeuralBridge] Predictive mode enabled: window={window}, "
                  f"latency_threshold={latency_threshold}ms, "
                  f"error_threshold={error_threshold*100}%")
    
    def check_model_health(self, model: str) -> Optional[Prediction]:
        """
        Check if a model should be switched based on predictive analysis.
        
        Args:
            model: The model name to check
            
        Returns:
            Prediction if predictive mode is enabled, None otherwise
        """
        if not self._predictive_enabled or self.predictive_engine is None:
            return None
        return self.predictive_engine.predict(model)
    
    def get_predictive_stats(self) -> Dict[str, Any]:
        """Get predictive engine stats for all tracked models."""
        if not self._predictive_enabled or self.predictive_engine is None:
            return {}
        return self.predictive_engine.get_all_stats()
    
    def get_recovery_action(
        self,
        diagnosis: DiagnosisResult,
        context: Dict[str, Any]
    ) -> RecoveryAction:
        """
        Get the appropriate recovery action for a diagnosis.
        
        Args:
            diagnosis: Result from diagnosis engine
            context: Context including current model, attempt, etc.
            
        Returns:
            RecoveryAction to execute
        """
        # Find applicable strategies
        applicable = self.strategies.get_for_diagnosis(diagnosis)
        
        if not applicable:
            return RecoveryAction(
                level=CascadeLevel.L5_CIRCUIT,
                action_type="no_recovery_available",
                reason="No strategies available for this error type",
            )
        
        # Use the first (highest priority) strategy
        strategy = applicable[0]
        return strategy.get_action(diagnosis, context)
    
    def heal(
        self,
        func: Callable[..., T],
        *args,
        current_model: Optional[str] = None,
        api_key_getter: Optional[Callable[[], str]] = None,
        api_key_setter: Optional[Callable[[str], None]] = None,
        **kwargs
    ) -> T:
        """
        Execute a function with automatic healing on failure.
        
        This is the main entry point for self-healing API calls.
        It wraps the function call in diagnosis and recovery logic.
        
        Args:
            func: The function to execute (typically an API call)
            *args: Positional arguments for the function
            current_model: Current model being used
            api_key_getter: Optional getter for API key refresh
            api_key_setter: Optional setter for refreshed API key
            **kwargs: Keyword arguments for the function
            
        Returns:
            Result from successful function execution
            
        Raises:
            Exception: If all recovery attempts fail
        """
        current_model = current_model or (self.fallback_models[0] if self.fallback_models else "")
        attempt = 0
        last_exception = None
        record = None
        total_duration = 0.0
        
        # Track errors and actions for learning
        error_actions: List[Tuple[Exception, str, Dict, float, bool]] = []
        
        while attempt <= self.max_retries:
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                
                # Track success
                duration = time.time() - start_time
                total_duration += duration
                self._track_success(current_model, duration)
                
                # Record successful recoveries for learning
                if self._learner_enabled and self._learner is not None:
                    for error, action, params, latency, _ in error_actions:
                        self._record_for_learning(error, action, params, True, latency)
                    # Also trigger learning analysis
                    self._learner.learn()
                
                return result
                
            except Exception as e:
                duration = time.time() - start_time
                total_duration += duration
                last_exception = e
                
                # Diagnose the error
                diagnosis = self.diagnose(e)
                
                # Create recovery record
                record = RecoveryRecord(
                    error=e,
                    diagnosis=diagnosis,
                )
                record.add_attempt(current_model, False, str(e), duration)
                
                if self.verbose:
                    print(f"[NeuralBridge] Attempt {attempt + 1} failed: {diagnosis.suggestion}")
                
                # Check if we should retry
                if not diagnosis.retryable:
                    if self.verbose:
                        print("[NeuralBridge] Error is not retryable, raising immediately")
                    record.final_outcome = "non_retryable_error"
                    self.recovery_history.append(record)
                    
                    # Record failed recovery for learning
                    if self._learner_enabled and self._learner is not None:
                        self._record_for_learning(e, "non_retryable", {}, False, total_duration)
                    
                    raise
                
                # Try learned rule first if available (v0.5.0)
                learned_action = self._apply_learned_rule(e)
                
                # Get recovery action
                context = {"attempt": attempt, "current_model": current_model}
                action = learned_action if learned_action else self.get_recovery_action(diagnosis, context)
                
                if self.verbose:
                    print(f"[NeuralBridge] Recovery action: {action.action_type} - {action.reason}")
                
                # Execute recovery and track for learning
                recovery_start = time.time()
                
                if action.action_type == "switch_model":
                    current_model = action.target or current_model
                    self.model_fallback_strategy._current_index += 1
                
                elif action.action_type == "wait_and_retry":
                    delay = action.params.get("delay", 1.0)
                    if self.verbose:
                        print(f"[NeuralBridge] Waiting {delay:.2f}s before retry")
                    time.sleep(delay)
                
                elif action.action_type == "refresh_auth":
                    new_key = self.auth_refresh_strategy.attempt_refresh()
                    if new_key and api_key_setter:
                        api_key_setter(new_key)
                
                recovery_latency = time.time() - recovery_start
                
                # Track this recovery attempt for learning
                error_actions.append((e, action.action_type, action.params, recovery_latency, False))
                
                attempt += 1
        
        # All retries exhausted
        record.final_outcome = "exhausted_retries"
        record.total_duration = total_duration
        self.recovery_history.append(record)
        
        # Record all failed recoveries for learning
        if self._learner_enabled and self._learner is not None:
            for error, action, params, latency, _ in error_actions:
                self._record_for_learning(error, action, params, False, latency)
        
        self._track_failure(current_model, last_exception, total_duration)
        raise last_exception
    
    async def heal_async(
        self,
        func: Callable[..., T],
        *args,
        current_model: Optional[str] = None,
        api_key_getter: Optional[Callable[[], str]] = None,
        api_key_setter: Optional[Callable[[str], None]] = None,
        **kwargs
    ) -> T:
        """
        Async version of heal() with automatic healing on failure.
        
        Args:
            func: The async function to execute
            *args: Positional arguments for the function
            current_model: Current model being used
            api_key_getter: Optional getter for API key refresh
            api_key_setter: Optional setter for refreshed API key
            **kwargs: Keyword arguments for the function
            
        Returns:
            Result from successful function execution
            
        Raises:
            Exception: If all recovery attempts fail
        """
        current_model = current_model or (self.fallback_models[0] if self.fallback_models else "")
        attempt = 0
        last_exception = None
        record = None
        total_duration = 0.0
        
        # Track errors and actions for learning
        error_actions: List[Tuple[Exception, str, Dict, float, bool]] = []
        
        while attempt <= self.max_retries:
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                
                # Track success
                duration = time.time() - start_time
                total_duration += duration
                self._track_success(current_model, duration)
                
                # Record successful recoveries for learning
                if self._learner_enabled and self._learner is not None:
                    for error, action, params, latency, _ in error_actions:
                        self._record_for_learning(error, action, params, True, latency)
                    # Also trigger learning analysis
                    self._learner.learn()
                
                return result
                
            except Exception as e:
                duration = time.time() - start_time
                total_duration += duration
                last_exception = e
                
                # Diagnose the error
                diagnosis = self.diagnose(e)
                
                # Create recovery record
                record = RecoveryRecord(
                    error=e,
                    diagnosis=diagnosis,
                )
                record.add_attempt(current_model, False, str(e), duration)
                
                if self.verbose:
                    print(f"[NeuralBridge] Attempt {attempt + 1} failed: {diagnosis.suggestion}")
                
                # Check if we should retry
                if not diagnosis.retryable:
                    if self.verbose:
                        print("[NeuralBridge] Error is not retryable, raising immediately")
                    record.final_outcome = "non_retryable_error"
                    self.recovery_history.append(record)
                    
                    # Record failed recovery for learning
                    if self._learner_enabled and self._learner is not None:
                        self._record_for_learning(e, "non_retryable", {}, False, total_duration)
                    
                    raise
                
                # Try learned rule first if available (v0.5.0)
                learned_action = self._apply_learned_rule(e)
                
                # Get recovery action
                context = {"attempt": attempt, "current_model": current_model}
                action = learned_action if learned_action else self.get_recovery_action(diagnosis, context)
                
                if self.verbose:
                    print(f"[NeuralBridge] Recovery action: {action.action_type} - {action.reason}")
                
                # Execute recovery and track for learning
                recovery_start = time.time()
                
                if action.action_type == "switch_model":
                    current_model = action.target or current_model
                    self.model_fallback_strategy._current_index += 1
                
                elif action.action_type == "wait_and_retry":
                    delay = action.params.get("delay", 1.0)
                    if self.verbose:
                        print(f"[NeuralBridge] Waiting {delay:.2f}s before retry")
                    await asyncio.sleep(delay)
                
                elif action.action_type == "refresh_auth":
                    new_key = self.auth_refresh_strategy.attempt_refresh()
                    if new_key and api_key_setter:
                        api_key_setter(new_key)
                
                recovery_latency = time.time() - recovery_start
                
                # Track this recovery attempt for learning
                error_actions.append((e, action.action_type, action.params, recovery_latency, False))
                
                attempt += 1
        
        # All retries exhausted
        record.final_outcome = "exhausted_retries"
        record.total_duration = total_duration
        self.recovery_history.append(record)
        
        # Record all failed recoveries for learning
        if self._learner_enabled and self._learner is not None:
            for error, action, params, latency, _ in error_actions:
                self._record_for_learning(error, action, params, False, latency)
        
        self._track_failure(current_model, last_exception, total_duration)
        raise last_exception
    
    def _track_success(self, model: str, latency: float) -> None:
        """Track successful API call."""
        if model not in self.model_performance:
            self.model_performance[model] = ModelPerformance(model=model)
        self.model_performance[model].update(True, latency)
        
        # Record for predictive engine
        if self._predictive_enabled and self.predictive_engine:
            self.predictive_engine.record_request(model, latency * 1000, True)
    
    def _track_failure(self, model: str, error: Exception, latency: float = 0) -> None:
        """Track failed API call."""
        if model not in self.model_performance:
            self.model_performance[model] = ModelPerformance(model=model)
        self.model_performance[model].update(False, 0)
        self.model_performance[model].last_error = str(error)
        
        # Record for predictive engine (latency in seconds, convert to ms)
        if self._predictive_enabled and self.predictive_engine:
            self.predictive_engine.record_request(model, latency * 1000, False)
    
    def get_health_status(self) -> HealthStatus:
        """Get current health status of the engine."""
        healthy_models = []
        degraded_models = []
        failed_models = []
        recommendations = []
        
        for model, perf in self.model_performance.items():
            if perf.reliability_score >= 0.8:
                healthy_models.append(model)
            elif perf.reliability_score >= 0.5:
                degraded_models.append(model)
                recommendations.append(f"Model {model} has degraded reliability ({perf.reliability_score:.1%})")
            else:
                failed_models.append(model)
                recommendations.append(f"Model {model} has critical reliability ({perf.reliability_score:.1%})")
        
        return HealthStatus(
            healthy=len(failed_models) == 0 and len(degraded_models) == 0,
            active_models=healthy_models,
            degraded_models=degraded_models,
            failed_models=failed_models,
            recommendations=recommendations,
        )
    
    # ========== Request Tracing (v0.3.3) ==========
    
    def _generate_request_id(self) -> str:
        """Generate a unique request ID."""
        self._request_counter += 1
        return f"req_{int(time.time())}_{self._request_counter}"
    
    def _start_trace(self, model: str) -> RequestTrace:
        """Start a new request trace."""
        trace = RequestTrace(
            request_id=self._generate_request_id(),
            model=model,
            start_time=time.time(),
        )
        self._trace_log.append(trace)
        # Keep only last 1000 traces to prevent memory bloat
        if len(self._trace_log) > 1000:
            self._trace_log = self._trace_log[-1000:]
        return trace
    
    def get_traces(self, limit: int = 100, status: Optional[str] = None) -> List[RequestTrace]:
        """
        Get recent request traces.
        
        Args:
            limit: Maximum number of traces to return (default: 100)
            status: Filter by status ("success", "failed", "recovered", "pending")
            
        Returns:
            List of RequestTrace objects, most recent first
        """
        traces = self._trace_log[-limit:] if limit > 0 else self._trace_log
        if status:
            traces = [t for t in traces if t.status == status]
        return list(reversed(traces))
    
    def get_model_health(self, model: Optional[str] = None) -> Union[Dict[str, ModelHealth], ModelHealth]:
        """
        Get health metrics for one or all models.
        
        Args:
            model: Specific model name, or None for all models
            
        Returns:
            ModelHealth object for specific model, or Dict of all model health
        """
        if model:
            if model not in self.model_performance:
                return ModelHealth(model=model)
            health = ModelHealth(model=model)
            health.update_from_performance(self.model_performance[model])
            return health
        
        # Return all models' health
        result = {}
        for model_name, perf in self.model_performance.items():
            health = ModelHealth(model=model_name)
            health.update_from_performance(perf)
            result[model_name] = health
        return result
    
    def get_model_health_dict(self) -> Dict[str, ModelHealth]:
        """
        Get health metrics for all models as a dictionary.
        
        Returns:
            Dict mapping model name to ModelHealth object
        """
        result = {}
        for model_name, perf in self.model_performance.items():
            health = ModelHealth(model=model_name)
            health.update_from_performance(perf)
            result[model_name] = health
        return result
    
    def get_recovery_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get detailed recovery log.
        
        Returns logs of all diagnosis and recovery operations with full context.
        
        Args:
            limit: Maximum number of records to return (default: 100)
            
        Returns:
            List of recovery log entries, most recent first
        """
        logs = self._recovery_log[-limit:] if limit > 0 else self._recovery_log
        return list(reversed(logs))
    
    def get_recovery_stats(self) -> RecoveryStats:
        """
        Get recovery operation statistics.
        
        Returns:
            RecoveryStats object with aggregated recovery metrics
        """
        return self._recovery_stats
    
    def _log_recovery(
        self,
        request_id: str,
        error: Exception,
        diagnosis: DiagnosisResult,
        recovery_attempts: List[Dict[str, Any]],
        final_outcome: str,
    ) -> None:
        """Log a recovery operation to internal log."""
        log_entry = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "error_type": type(error).__name__,
            "error_message": str(error),
            "diagnosis": {
                "category": diagnosis.category.value,
                "sub_category": diagnosis.sub_category,
                "confidence": diagnosis.confidence,
                "retryable": diagnosis.retryable,
                "suggestion": diagnosis.suggestion,
            },
            "recovery_attempts": recovery_attempts,
            "final_outcome": final_outcome,
            "total_attempts": len(recovery_attempts),
        }
        self._recovery_log.append(log_entry)
        
        # Update recovery stats
        success = final_outcome == "recovered"
        duration_ms = sum(a.get("duration", 0) for a in recovery_attempts) * 1000
        self._recovery_stats.record_recovery(
            diagnosis.category.value,
            success,
            duration_ms,
        )
    
    def reset(self) -> None:
        """Reset engine state for a new session."""
        self.model_fallback_strategy.reset()
        self.auth_refresh_strategy.reset()
        self.recovery_history.clear()
        self._recovery_log.clear()
        self._trace_log.clear()
        self._recovery_stats = RecoveryStats()
        self.network_retry_strategy.reset()
        self.rate_limit_strategy.reset()
        
        # Reset predictive engine if enabled
        if self._predictive_enabled and self.predictive_engine:
            self.predictive_engine.reset()
        
        # Reset learning engine if enabled
        if self._learner_enabled and self._learner:
            self._learner.reset()
    
    # ========== Predictive Self-Healing (v0.4.0) ==========
    
    def enable_predictive_mode(
        self,
        window: str = "5min",
        latency_threshold: float = 2000,
        error_threshold: float = 0.1,
        auto_switch: bool = True,
    ) -> PredictiveConfig:
        """
        Enable predictive self-healing mode.
        
        Convenience method to configure predictive self-healing without
        creating a PredictiveConfig manually.
        
        Args:
            window: Statistical window ("1min", "5min", "10min", "30min")
            latency_threshold: Latency threshold in ms to trigger warning
            error_threshold: Error rate threshold (0.0 to 1.0)
            auto_switch: Whether to automatically switch to healthy models
            
        Returns:
            The created PredictiveConfig
            
        Example:
            >>> engine = FlywheelEngine(fallback_models=["gpt-4", "gpt-3.5"])
            >>> engine.enable_predictive_mode(
            ...     window="5min",
            ...     latency_threshold=2000,
            ...     error_threshold=0.1,
            ... )
        """
        if self.predictive_engine is None:
            config = PredictiveConfig(
                window_seconds=self._parse_window(window),
                latency_threshold_ms=latency_threshold,
                error_rate_threshold=error_threshold,
                auto_switch=auto_switch,
            )
            self.predictive_engine = PredictiveEngine(config)
            self._predictive_enabled = True
        else:
            # Update existing config
            config = self.predictive_engine.enable_predictive_mode(
                window=window,
                latency_threshold=latency_threshold,
                error_threshold=error_threshold,
                auto_switch=auto_switch,
            )
        return self.predictive_engine.config
    
    def _parse_window(self, window: str) -> int:
        """Parse window string to seconds."""
        window_map = {
            "1min": 60,
            "5min": 300,
            "10min": 600,
            "30min": 1800,
        }
        return window_map.get(window, 300)
    
    def predict_model_switch(self, model: str) -> Prediction:
        """
        Predict whether a model should be switched.
        
        Args:
            model: Model to analyze
            
        Returns:
            Prediction with recommendation and reasoning
        """
        if not self._predictive_enabled or self.predictive_engine is None:
            return Prediction(
                model=model,
                should_switch=False,
                reason="predictive_disabled",
                confidence=0.0,
            )
        return self.predictive_engine.predict(model)
    
    def get_model_stats(self, model: str) -> Dict[str, Any]:
        """
        Get statistics for a specific model including predictive stats.
        
        Args:
            model: Model name
            
        Returns:
            Dictionary of model statistics
        """
        if self._predictive_enabled and self.predictive_engine:
            return self.predictive_engine.get_model_stats(model)
        
        # Fallback to original performance data
        if model in self.model_performance:
            perf = self.model_performance[model]
            return {
                "model": model,
                "total_calls": perf.total_calls,
                "successful_calls": perf.successful_calls,
                "failed_calls": perf.failed_calls,
                "success_rate": perf.success_rate,
                "avg_latency_ms": perf.avg_latency * 1000,
                "reliability_score": perf.reliability_score,
                "last_error": perf.last_error,
            }
        return {"model": model, "sample_count": 0}
    
    def get_predictive_stats(self) -> Dict[str, Dict[str, Any]]:
        """
        Get predictive statistics for all tracked models.
        
        Returns:
            Dictionary mapping model names to their predictive stats
        """
        if not self._predictive_enabled or self.predictive_engine is None:
            return {}
        return self.predictive_engine.get_all_stats()
    
    # ========== Flywheel Learning API (v0.5.0) ==========
    
    def enable_learning(
        self,
        min_samples: int = 3,
        decay_days: int = 30,
    ) -> None:
        """
        Enable the flywheel learning engine.
        
        The learning engine records error-recovery pairs and automatically
        extracts rules to optimize future recovery attempts.
        
        Args:
            min_samples: Minimum observations before extracting a rule (default: 3)
            decay_days: Days before unused rules decay (default: 30)
        """
        if self._learner is None:
            self._learner = FlywheelLearner(
                min_samples=min_samples,
                decay_days=decay_days,
            )
        self._learner_enabled = True
        
        if self.verbose:
            print(f"[NeuralBridge] Learning enabled: min_samples={min_samples}, decay_days={decay_days}")
    
    def disable_learning(self) -> None:
        """Disable the flywheel learning engine."""
        self._learner_enabled = False
        
        if self.verbose:
            print("[NeuralBridge] Learning disabled")
    
    def is_learning_enabled(self) -> bool:
        """Check if learning is enabled."""
        return self._learner_enabled
    
    def get_learned_rules(self) -> List[LearnedRule]:
        """
        Get all learned recovery rules.
        
        Returns:
            List of LearnedRule objects, sorted by confidence (descending)
        """
        if not self._learner_enabled or self._learner is None:
            return []
        return self._learner.get_learned_rules()
    
    def trigger_learning(self) -> List[LearnedRule]:
        """
        Trigger learning analysis on recorded history.
        
        Returns:
            List of rules that were created or updated
        """
        if not self._learner_enabled or self._learner is None:
            return []
        return self._learner.learn()
    
    def prune_learned_rules(self) -> int:
        """
        Prune low-performing or expired learned rules.
        
        Returns:
            Number of rules pruned
        """
        if not self._learner_enabled or self._learner is None:
            return 0
        return self._learner.prune()
    
    def export_learned_rules(self) -> Dict[str, Any]:
        """
        Export learned rules for persistence.
        
        Returns:
            Dictionary containing all rules and metadata
        """
        if not self._learner_enabled or self._learner is None:
            return {"version": "1.0", "rules": []}
        return self._learner.export_rules()
    
    def import_learned_rules(self, data: Dict[str, Any]) -> int:
        """
        Import learned rules from persistence.
        
        Args:
            data: Dictionary from export_learned_rules()
            
        Returns:
            Number of rules imported
        """
        if self._learner is None:
            self._learner = FlywheelLearner()
            self._learner_enabled = True
        return self._learner.import_rules(data)
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """
        Get learning engine statistics.
        
        Returns:
            Dictionary with learning stats
        """
        if not self._learner_enabled or self._learner is None:
            return {
                "enabled": False,
                "active_rules": 0,
            }
        stats = self._learner.get_statistics()
        stats["enabled"] = True
        return stats
