"""
NeuralBridge Predictive Engine.

Implements predictive self-healing: monitors model health metrics
in a sliding window and proactively switches to healthier models
before failures occur.
"""

import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class PredictiveConfig:
    """Configuration for predictive self-healing."""
    window_seconds: int = 300          # Sliding window duration (5 min)
    latency_threshold_ms: float = 2000 # Latency warning threshold
    error_rate_threshold: float = 0.1  # Error rate warning threshold (10%)
    min_samples: int = 5               # Minimum samples before predicting
    auto_switch: bool = True           # Auto-switch to healthy model
    cooldown_seconds: int = 60         # Cooldown after switching
    degradation_streak: int = 3        # Consecutive degrading samples to trigger


@dataclass
class Prediction:
    """Result of a predictive analysis."""
    model: str
    should_switch: bool
    reason: Optional[str] = None       # "high_error_rate" / "high_latency" / "degrading_trend"
    confidence: float = 0.0
    current_stats: Dict[str, Any] = field(default_factory=dict)
    recommended_model: Optional[str] = None


class ModelStats:
    """
    Sliding window statistics for a single model.
    
    Tracks request outcomes within a time window to compute
    real-time health metrics.
    """
    
    def __init__(self, model: str, window_seconds: int = 300):
        self.model = model
        self.window_seconds = window_seconds
        self._samples: deque = deque()  # (timestamp, latency_ms, success)
        self._latency_history: deque = deque(maxlen=100)  # For trend detection
    
    def record(self, latency_ms: float, success: bool) -> None:
        """Record a request result."""
        now = time.time()
        self._samples.append((now, latency_ms, success))
        self._latency_history.append(latency_ms)
        self._prune(now)
    
    def _prune(self, now: float) -> None:
        """Remove samples outside the sliding window."""
        cutoff = now - self.window_seconds
        while self._samples and self._samples[0][0] < cutoff:
            self._samples.popleft()
    
    @property
    def sample_count(self) -> int:
        return len(self._samples)
    
    @property
    def success_rate(self) -> float:
        """Success rate within the window."""
        if not self._samples:
            return 1.0
        successes = sum(1 for _, _, s in self._samples if s)
        return successes / len(self._samples)
    
    @property
    def error_rate(self) -> float:
        """Error rate within the window."""
        return 1.0 - self.success_rate
    
    @property
    def avg_latency(self) -> float:
        """Average latency within the window."""
        if not self._samples:
            return 0.0
        latencies = [lat for _, lat, _ in self._samples]
        return sum(latencies) / len(latencies)
    
    @property
    def p95_latency(self) -> float:
        """P95 latency within the window."""
        if not self._samples:
            return 0.0
        latencies = sorted([lat for _, lat, _ in self._samples])
        idx = int(len(latencies) * 0.95)
        return latencies[min(idx, len(latencies) - 1)]
    
    @property
    def trend(self) -> str:
        """
        Latency trend: "improving", "stable", "degrading".
        
        Compares recent samples to older samples in the window.
        """
        if len(self._latency_history) < 6:
            return "stable"
        
        recent = list(self._latency_history)
        half = len(recent) // 2
        older_avg = sum(recent[:half]) / half
        newer_avg = sum(recent[half:]) / (len(recent) - half)
        
        if newer_avg > older_avg * 1.3:
            return "degrading"
        elif newer_avg < older_avg * 0.7:
            return "improving"
        return "stable"
    
    @property
    def status(self) -> str:
        """Overall model status: "healthy", "degraded", "down"."""
        if self.sample_count == 0:
            return "healthy"  # No data yet, assume healthy
        
        if self.success_rate < 0.5:
            return "down"
        elif self.success_rate < 0.9 or self.avg_latency > 3000:
            return "degraded"
        return "healthy"
    
    def to_dict(self) -> Dict[str, Any]:
        """Export stats as a dictionary."""
        return {
            "model": self.model,
            "status": self.status,
            "success_rate": round(self.success_rate, 4),
            "error_rate": round(self.error_rate, 4),
            "avg_latency_ms": round(self.avg_latency, 1),
            "p95_latency_ms": round(self.p95_latency, 1),
            "sample_count": self.sample_count,
            "trend": self.trend,
        }


class PredictiveEngine:
    """
    Predictive self-healing engine.
    
    Monitors model health metrics in sliding windows and proactively
    switches to healthier models before failures accumulate.
    
    This is the key differentiator: instead of waiting for errors,
    NeuralBridge predicts degradation and acts preemptively.
    """
    
    def __init__(self, config: Optional[PredictiveConfig] = None):
        self.config = config or PredictiveConfig()
        self._model_stats: Dict[str, ModelStats] = {}
        self._switch_history: deque = deque(maxlen=50)  # (timestamp, from_model, to_model, reason)
        self._last_switch_time: Dict[str, float] = {}  # model -> last switch timestamp
    
    def _get_stats(self, model: str) -> ModelStats:
        """Get or create stats for a model."""
        if model not in self._model_stats:
            self._model_stats[model] = ModelStats(
                model=model,
                window_seconds=self.config.window_seconds,
            )
        return self._model_stats[model]
    
    def record_request(self, model: str, latency_ms: float, success: bool) -> None:
        """
        Record a request outcome.
        
        Called by FlywheelEngine after each request (success or failure).
        """
        stats = self._get_stats(model)
        stats.record(latency_ms, success)
    
    def predict(self, model: str) -> Prediction:
        """
        Predict whether the model should be switched.
        
        Returns a Prediction with:
        - should_switch: True if model is degrading
        - reason: Why the switch is recommended
        - confidence: How confident the prediction is
        - recommended_model: Best alternative (if available)
        """
        stats = self._get_stats(model)
        
        # Not enough data to predict
        if stats.sample_count < self.config.min_samples:
            return Prediction(
                model=model,
                should_switch=False,
                reason="insufficient_data",
                confidence=0.0,
                current_stats=stats.to_dict(),
            )
        
        # Check cooldown
        now = time.time()
        if model in self._last_switch_time:
            elapsed = now - self._last_switch_time[model]
            if elapsed < self.config.cooldown_seconds:
                return Prediction(
                    model=model,
                    should_switch=False,
                    reason="cooldown",
                    confidence=0.0,
                    current_stats=stats.to_dict(),
                )
        
        # Check error rate
        if stats.error_rate > self.config.error_rate_threshold:
            confidence = min(stats.error_rate / self.config.error_rate_threshold, 1.0)
            return Prediction(
                model=model,
                should_switch=True,
                reason="high_error_rate",
                confidence=round(confidence, 2),
                current_stats=stats.to_dict(),
            )
        
        # Check latency
        if stats.avg_latency > self.config.latency_threshold_ms:
            confidence = min(
                stats.avg_latency / self.config.latency_threshold_ms, 1.0
            )
            return Prediction(
                model=model,
                should_switch=True,
                reason="high_latency",
                confidence=round(confidence, 2),
                current_stats=stats.to_dict(),
            )
        
        # Check degrading trend (lower confidence, but still act)
        if stats.trend == "degrading" and stats.error_rate > self.config.error_rate_threshold * 0.5:
            return Prediction(
                model=model,
                should_switch=True,
                reason="degrading_trend",
                confidence=0.6,
                current_stats=stats.to_dict(),
            )
        
        # Model is healthy
        return Prediction(
            model=model,
            should_switch=False,
            reason=None,
            confidence=0.0,
            current_stats=stats.to_dict(),
        )
    
    def get_recommended_model(self, models: List[str]) -> Optional[str]:
        """
        From a list of candidate models, recommend the healthiest one.
        
        Scoring: success_rate * 0.6 + latency_score * 0.3 + trend_score * 0.1
        """
        if not models:
            return None
        
        scored = []
        for model in models:
            stats = self._get_stats(model)
            if stats.sample_count < self.config.min_samples:
                # No data, assume neutral score
                scored.append((model, 0.7))
                continue
            
            # Success rate component (0-1)
            sr_score = stats.success_rate
            
            # Latency component (lower is better, normalize to 0-1)
            if stats.avg_latency > 0:
                lat_score = max(0, 1 - stats.avg_latency / 5000)
            else:
                lat_score = 1.0
            
            # Trend component
            trend_scores = {"improving": 1.0, "stable": 0.8, "degrading": 0.3}
            tr_score = trend_scores.get(stats.trend, 0.5)
            
            total = sr_score * 0.6 + lat_score * 0.3 + tr_score * 0.1
            scored.append((model, total))
        
        # Sort by score descending
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[0][0] if scored else None
    
    def record_switch(self, from_model: str, to_model: str, reason: str) -> None:
        """Record a model switch event."""
        self._switch_history.append((time.time(), from_model, to_model, reason))
        self._last_switch_time[from_model] = time.time()
    
    def get_model_stats(self, model: str) -> Dict[str, Any]:
        """Get stats for a specific model."""
        stats = self._get_stats(model)
        return stats.to_dict()
    
    def get_all_stats(self) -> Dict[str, Dict[str, Any]]:
        """Get stats for all tracked models."""
        return {model: stats.to_dict() for model, stats in self._model_stats.items()}
    
    def get_switch_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent switch history."""
        history = []
        for ts, from_m, to_m, reason in list(self._switch_history)[-limit:]:
            history.append({
                "timestamp": ts,
                "from_model": from_m,
                "to_model": to_m,
                "reason": reason,
            })
        return history
    
    def reset(self) -> None:
        """Reset all stats and history."""
        self._model_stats.clear()
        self._switch_history.clear()
        self._last_switch_time.clear()
