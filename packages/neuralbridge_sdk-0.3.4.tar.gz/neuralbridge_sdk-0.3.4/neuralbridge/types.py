"""
Type definitions for NeuralBridge SDK.

Core types used throughout the SDK for type hints and documentation.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union


class ErrorCategory(str, Enum):
    """Categorizes the type of error detected."""
    RATE_LIMIT = "rate_limit"           # 429 Too Many Requests
    AUTH_ERROR = "auth_error"           # 401/403 Authentication issues
    MODEL_UNAVAILABLE = "model_unavailable"  # 404/503 Model not found
    NETWORK_ERROR = "network_error"     # Connection/timeout errors
    SERVER_ERROR = "server_error"       # 5xx Internal errors
    VALIDATION_ERROR = "validation_error"  # 400 Bad request
    UNKNOWN = "unknown"                 # Unclassified errors


class CascadeLevel(int, Enum):
    """
    Recovery cascade levels, ordered by escalation severity.
    
    Higher levels represent more aggressive recovery strategies.
    """
    L1_RETRY = 1      # Simple retry with same model
    L2_WAIT = 2       # Wait and retry with backoff
    L3_SWITCH = 3     # Switch to fallback model
    L4_HEAL = 4       # Deep diagnosis and repair
    L5_CIRCUIT = 5    # Circuit breaker activation


@dataclass
class DiagnosisResult:
    """
    Result of error diagnosis.
    
    Attributes:
        category: Type of error detected
        retryable: Whether the error is safe to retry
        suggestion: Human-readable suggestion for recovery
        metadata: Additional diagnostic information
        sub_category: Platform-specific error sub-category (e.g., "openai_rate_limit")
        confidence: Confidence score (0.0-1.0) for the diagnosis
    """
    category: ErrorCategory
    retryable: bool
    suggestion: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    sub_category: Optional[str] = None
    confidence: float = 1.0


@dataclass
class RecoveryAction:
    """
    A recovery action to be taken.
    
    Attributes:
        level: Cascade level for this action
        action_type: Type of action (retry, switch, heal, etc.)
        target: Target model or endpoint (if applicable)
        params: Additional parameters for the action
        reason: Why this action was chosen
    """
    level: CascadeLevel
    action_type: str
    target: Optional[str] = None
    params: Dict[str, Any] = field(default_factory=dict)
    reason: str = ""


@dataclass
class RecoveryRecord:
    """
    Record of a recovery operation.
    
    Tracks the history of attempts and outcomes for debugging
    and performance analysis.
    """
    error: Exception
    diagnosis: DiagnosisResult
    attempts: List[Dict[str, Any]] = field(default_factory=list)
    final_outcome: str = "pending"
    total_duration: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    
    def add_attempt(
        self,
        model: str,
        success: bool,
        error: Optional[str] = None,
        duration: float = 0.0,
    ) -> None:
        """Add a record of an attempt."""
        self.attempts.append({
            "model": model,
            "success": success,
            "error": error,
            "duration": duration,
            "timestamp": datetime.now().isoformat(),
        })


@dataclass
class ModelPerformance:
    """
    Performance metrics for a model.
    
    Tracks success rates, latency, and reliability scores
    to inform model selection decisions.
    """
    model: str
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    avg_latency: float = 0.0
    last_error: Optional[str] = None
    last_success: Optional[datetime] = None
    reliability_score: float = 1.0  # 0.0 to 1.0
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage."""
        if self.total_calls == 0:
            return 100.0
        return (self.successful_calls / self.total_calls) * 100
    
    def update(self, success: bool, latency: float) -> None:
        """Update metrics with a new result."""
        self.total_calls += 1
        if success:
            self.successful_calls += 1
            self.last_success = datetime.now()
        else:
            self.failed_calls += 1
        
        # Update running average latency
        self.avg_latency = (
            (self.avg_latency * (self.total_calls - 1) + latency) / self.total_calls
        )
        
        # Update reliability score
        self.reliability_score = self.successful_calls / max(self.total_calls, 1)


@dataclass
class HealthStatus:
    """Overall health status of the NeuralBridge client."""
    healthy: bool
    active_models: List[str] = field(default_factory=list)
    degraded_models: List[str] = field(default_factory=list)
    failed_models: List[str] = field(default_factory=list)
    last_check: datetime = field(default_factory=datetime.now)
    recommendations: List[str] = field(default_factory=list)


@dataclass
class RequestTrace:
    """
    Trace record for a single request through the self-healing pipeline.
    
    Tracks the complete lifecycle of a request including diagnosis,
    recovery attempts, and final outcome.
    
    Attributes:
        request_id: Unique identifier for this request
        model: Model that was used for this request
        start_time: Timestamp when request started
        end_time: Timestamp when request completed (None if in progress)
        status: Request status ("success", "failed", "recovered")
        latency_ms: Request latency in milliseconds
        diagnosis: Diagnosis result if error occurred
        recovery_attempts: List of recovery attempts made
        token_usage: Token usage information if available
    """
    request_id: str
    model: str
    start_time: float
    end_time: Optional[float] = None
    status: str = "pending"  # "pending", "success", "failed", "recovered"
    latency_ms: Optional[float] = None
    diagnosis: Optional[DiagnosisResult] = None
    recovery_attempts: List[Dict[str, Any]] = field(default_factory=list)
    token_usage: Optional[Dict[str, int]] = None  # {"prompt": x, "completion": y, "total": z}
    
    def mark_success(self, end_time: float, latency_ms: float, 
                     token_usage: Optional[Dict[str, int]] = None) -> None:
        """Mark the request as successful."""
        self.end_time = end_time
        self.status = "success"
        self.latency_ms = latency_ms
        if token_usage:
            self.token_usage = token_usage
    
    def mark_failed(self, end_time: float, diagnosis: Optional[DiagnosisResult] = None) -> None:
        """Mark the request as failed."""
        self.end_time = end_time
        self.status = "failed"
        self.diagnosis = diagnosis
    
    def mark_recovered(self, end_time: float, latency_ms: float) -> None:
        """Mark the request as recovered after self-healing."""
        self.end_time = end_time
        self.status = "recovered"
        self.latency_ms = latency_ms


@dataclass
class ModelHealth:
    """
    Health metrics for a specific model.
    
    Provides detailed health information for monitoring and alerting.
    
    Attributes:
        model: Model identifier
        success_rate: Success rate as percentage (0-100)
        avg_latency_ms: Average latency in milliseconds
        total_requests: Total number of requests
        successful_requests: Number of successful requests
        failed_requests: Number of failed requests
        last_error: Last error message if any
        last_error_time: Timestamp of last error
        last_success_time: Timestamp of last success
        status: Overall health status ("healthy", "degraded", "down")
    """
    model: str
    success_rate: float = 100.0
    avg_latency_ms: float = 0.0
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    last_error: Optional[str] = None
    last_error_time: Optional[datetime] = None
    last_success_time: Optional[datetime] = None
    status: str = "healthy"  # "healthy", "degraded", "down"
    
    def update_from_performance(self, perf: "ModelPerformance") -> None:
        """Update health from ModelPerformance object."""
        self.total_requests = perf.total_calls
        self.successful_requests = perf.successful_calls
        self.failed_requests = perf.failed_calls
        self.success_rate = perf.success_rate
        self.avg_latency_ms = perf.avg_latency * 1000 if perf.avg_latency else 0.0
        self.last_error = perf.last_error
        if perf.last_success:
            self.last_success_time = perf.last_success
        
        # Update status based on success rate
        if self.total_requests == 0:
            self.status = "healthy"
        elif self.success_rate >= 80.0:
            self.status = "healthy"
        elif self.success_rate >= 50.0:
            self.status = "degraded"
        else:
            self.status = "down"


@dataclass
class RecoveryStats:
    """
    Statistics about recovery operations.
    
    Tracks recovery success rates and patterns for analysis.
    
    Attributes:
        total_recoveries: Total number of recovery attempts
        successful_recoveries: Number of successful recoveries
        failed_recoveries: Number of failed recoveries
        avg_recovery_time_ms: Average time to recover in milliseconds
        recovery_by_category: Recovery counts by error category
    """
    total_recoveries: int = 0
    successful_recoveries: int = 0
    failed_recoveries: int = 0
    avg_recovery_time_ms: float = 0.0
    recovery_by_category: Dict[str, Dict[str, int]] = field(default_factory=dict)
    
    @property
    def recovery_rate(self) -> float:
        """Calculate recovery success rate as percentage."""
        if self.total_recoveries == 0:
            return 100.0
        return (self.successful_recoveries / self.total_recoveries) * 100
    
    def record_recovery(self, category: str, success: bool, 
                       duration_ms: float) -> None:
        """Record a recovery attempt."""
        self.total_recoveries += 1
        if success:
            self.successful_recoveries += 1
        else:
            self.failed_recoveries += 1
        
        # Update average
        self.avg_recovery_time_ms = (
            (self.avg_recovery_time_ms * (self.total_recoveries - 1) + duration_ms) 
            / self.total_recoveries
        )
        
        # Track by category
        if category not in self.recovery_by_category:
            self.recovery_by_category[category] = {"success": 0, "failed": 0}
        key = "success" if success else "failed"
        self.recovery_by_category[category][key] += 1


# Type aliases for common patterns
APIResponse = Dict[str, Any]
ChatMessage = Dict[str, str]
ChatMessages = List[ChatMessage]
StreamChunk = Dict[str, Any]

# Request/Response types
CreateChatCompletionRequest = Dict[str, Any]
CreateChatCompletionResponse = Dict[str, Any]
