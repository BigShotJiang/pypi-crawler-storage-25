class AscenderScopeError(Exception):
    pass