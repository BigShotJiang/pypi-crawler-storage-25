use pyo3::prelude::*;

use crate::color::Color;
use crate::outcome::GameOutcome;

#[pyclass(name = "GameOutcome")]
#[derive(Clone, Copy, Debug)]
pub struct PyGameOutcome {
    pub(super) outcome: GameOutcome,
}

#[hotpath::measure_all]
#[pymethods]
impl PyGameOutcome {
    pub fn winner(&self) -> Option<i8> {
        self.outcome.winner().map(|color| color as i8)
    }

    pub fn encode_winner_absolute(&self) -> f32 {
        self.outcome.encode_winner_absolute()
    }

    pub fn encode_winner_from_perspective(&self, perspective: i8) -> f32 {
        self.outcome.encode_winner_from_perspective(
            Color::from_int(perspective).expect("Unrecognized perspective"),
        )
    }

    pub fn is_draw(&self) -> bool {
        self.outcome.is_draw()
    }

    pub fn is_checkmate(&self) -> bool {
        matches!(self.outcome, GameOutcome::WhiteWin | GameOutcome::BlackWin)
    }

    pub fn is_stalemate(&self) -> bool {
        self.outcome == GameOutcome::Stalemate
    }

    pub fn is_insufficient_material(&self) -> bool {
        self.outcome == GameOutcome::InsufficientMaterial
    }

    pub fn is_threefold_repetition(&self) -> bool {
        self.outcome == GameOutcome::ThreefoldRepetition
    }

    pub fn is_fifty_move_rule(&self) -> bool {
        self.outcome == GameOutcome::FiftyMoveRule
    }

    pub fn reason(&self) -> String {
        self.outcome.to_string()
    }

    pub fn __str__(&self) -> String {
        self.outcome.to_string()
    }

    pub fn __repr__(&self) -> String {
        format!("GameOutcome({})", self.outcome.to_string())
    }

    pub fn __eq__(&self, other: &PyGameOutcome) -> bool {
        self.outcome == other.outcome
    }

    pub fn __hash__(&self) -> u64 {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        self.outcome.hash(&mut hasher);
        hasher.finish()
    }
}
