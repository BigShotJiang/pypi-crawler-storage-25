import math
import time
from pythagorean_snap import PythagoreanManifold, Triple


def test_basic():
    m = PythagoreanManifold(100)
    assert len(m) > 0


def test_full_circle():
    m = PythagoreanManifold(1000)
    lo, hi = m.angle_range()
    assert lo < 0.1
    assert hi > 6.2


def test_all_verify():
    m = PythagoreanManifold(5000)
    for t in m.iter_triples():
        assert t.verify(), f"({t.x}, {t.y}, {t.c}) failed"


def test_binary_agrees_brute():
    m = PythagoreanManifold(5000)
    for i in range(1000):
        theta = (i / 1000.0) * 2 * math.pi
        bs = m.snap_angle(theta)
        bf = m.snap_brute(theta)
        assert bs == bf, f"theta={theta:.4f}: {bs} != {bf}"


def test_idempotency():
    m = PythagoreanManifold(5000)
    for i in range(100):
        theta = (i / 100.0) * 2 * math.pi
        t1 = m.snap_angle(theta)
        t2 = m.snap_angle(t1.angle())
        assert t1 == t2


def test_determinism():
    m = PythagoreanManifold(5000)
    for i in range(100):
        theta = (i / 100.0) * 2 * math.pi
        assert m.snap_angle(theta) == m.snap_angle(theta)


def test_known_triples():
    m = PythagoreanManifold(100)
    found = any(t.c == 5 and {abs(t.x), abs(t.y)} == {3, 4}
                for t in m.iter_triples())
    assert found, "should contain (3,4,5)"


def test_angle_wrapping():
    m = PythagoreanManifold(5000)
    assert m.snap_angle(0.0) == m.snap_angle(2 * math.pi)
    assert m.snap_angle(-0.5).verify()


def test_performance():
    m = PythagoreanManifold(50000)
    assert len(m) > 40000
    t0 = time.perf_counter()
    for i in range(100000):
        m.snap_angle((i * 0.0001) % (2 * math.pi))
    elapsed = time.perf_counter() - t0
    assert elapsed < 2.0, f"100K snaps took {elapsed:.2f}s"
