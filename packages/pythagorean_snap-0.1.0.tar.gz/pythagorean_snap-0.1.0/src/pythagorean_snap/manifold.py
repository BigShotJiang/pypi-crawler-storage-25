"""Full-circle Pythagorean manifold with binary-search snap."""

from __future__ import annotations
import math
from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from typing import List, Tuple

TWO_PI = 2.0 * math.pi


@dataclass(frozen=True)
class Triple:
    """A Pythagorean triple with signed legs for full-circle coverage."""
    x: int   # Signed x-component (leg a)
    y: int   # Signed y-component (leg b)  
    c: int   # Hypotenuse (always positive)

    def angle(self) -> float:
        """Angle on the unit circle [0, 2pi)."""
        a = math.atan2(self.y, self.x)
        return a if a >= 0 else a + TWO_PI

    def norm(self) -> float:
        """Euclidean norm."""
        return math.sqrt(self.x ** 2 + self.y ** 2)

    def verify(self) -> bool:
        """Check x^2 + y^2 == c^2 exactly."""
        return self.x * self.x + self.y * self.y == self.c * self.c


def _gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a


def _angle_diff(a: float, b: float) -> float:
    d = abs(a - b)
    return min(d, TWO_PI - d)


class PythagoreanManifold:
    """Precomputed Pythagorean manifold for fast angular nearest-neighbor queries.

    Generates all primitive triples up to max_c, mirrors across 8 octants,
    and provides O(log n) binary-search snap queries.
    """

    def __init__(self, max_c: int = 50000):
        self._max_c = max_c
        self._triples: List[Triple] = []
        self._angles: List[float] = []
        self._build(max_c)

    def _build(self, max_c: int) -> None:
        base = []
        max_m = int(math.sqrt(max_c / 2.0)) + 1

        for m in range(1, max_m):
            m2 = m * m
            if m2 * 2 > max_c * max_c:
                break
            max_n = min(m, int(math.sqrt(max_c - m2)))
            for n in range(1, max_n + 1):
                if (m + n) % 2 == 1 and _gcd(m, n) == 1:
                    a = m2 - n * n
                    b = 2 * m * n
                    c = m2 + n * n
                    if c <= max_c:
                        base.append((a, b, c))

        # Mirror to 8 octants
        seen = set()
        for a, b, c in base:
            for sa, sb in [(a,b), (b,a), (-a,b), (-b,a),
                           (-a,-b), (-b,-a), (a,-b), (b,-a)]:
                key = (sa, sb, c)
                if key not in seen:
                    seen.add(key)
                    self._triples.append(Triple(sa, sb, c))

        # Sort by angle
        self._triples.sort(key=lambda t: t.angle())
        self._angles = [t.angle() for t in self._triples]

    def __len__(self) -> int:
        return len(self._triples)

    @property
    def max_c(self) -> int:
        return self._max_c

    def snap_angle(self, theta: float) -> Triple:
        """Find nearest triple to angle (radians). O(log n)."""
        theta = theta % TWO_PI
        if theta < 0:
            theta += TWO_PI

        idx = bisect_left(self._angles, theta)

        if idx == 0:
            return self._triples[0]
        if idx >= len(self._angles):
            return self._triples[-1]

        # Compare neighbors
        d_lo = _angle_diff(self._angles[idx - 1], theta)
        d_hi = _angle_diff(self._angles[idx], theta)
        return self._triples[idx - 1] if d_lo <= d_hi else self._triples[idx]

    def snap_brute(self, theta: float) -> Triple:
        """Brute-force nearest triple (for verification)."""
        theta = theta % TWO_PI
        if theta < 0:
            theta += TWO_PI

        best = self._triples[0]
        best_d = float('inf')
        for t in self._triples:
            d = _angle_diff(t.angle(), theta)
            if d < best_d:
                best_d = d
                best = t
        return best

    def constraint_distance(self, theta: float) -> float:
        """Angular distance to nearest triple."""
        t = self.snap_angle(theta)
        return _angle_diff(t.angle(), theta % TWO_PI)

    def angle_range(self) -> Tuple[float, float]:
        """(min_angle, max_angle) in radians."""
        if not self._angles:
            return (0.0, 0.0)
        return (self._angles[0], self._angles[-1])

    def iter_triples(self):
        """Iterate over all triples."""
        return iter(self._triples)

    def __getitem__(self, index: int) -> Triple:
        return self._triples[index]
