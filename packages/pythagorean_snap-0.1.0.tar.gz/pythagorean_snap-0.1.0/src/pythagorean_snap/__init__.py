"""Pythagorean Snap — O(log n) nearest-neighbor on the full-circle Pythagorean manifold."""

from .manifold import PythagoreanManifold, Triple

__version__ = "0.1.0"
__all__ = ["PythagoreanManifold", "Triple"]
