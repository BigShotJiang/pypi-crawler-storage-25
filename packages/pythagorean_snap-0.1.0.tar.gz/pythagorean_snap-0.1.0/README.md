# pythagorean-snap

**O(log n) nearest-neighbor search on the full-circle Pythagorean manifold** — zero drift, 1000x+ faster than brute force.

## Install

```bash
pip install pythagorean-snap
```

## Quick Start

```python
from pythagorean_snap import PythagoreanManifold

m = PythagoreanManifold(50_000)
t = m.snap_angle(0.785)  # snap to nearest triple at ~45°
print(f"({t.x}, {t.y}, {t.c}) — angle: {t.angle():.4f} rad")
assert t.verify()  # x² + y² = c² — always exact
```

## Performance

At `max_c = 50,000` (41K+ triples):
- Binary search: O(log n) per query
- 100% agreement with brute-force
- Zero floating-point drift

## API

| Method | Description |
|--------|-------------|
| `PythagoreanManifold(max_c)` | Build manifold |
| `.snap_angle(theta)` | Nearest triple to angle (rad) |
| `.snap_brute(theta)` | Brute-force (verification) |
| `.constraint_distance(theta)` | Angular distance |
| `.angle_range()` | (min, max) angle |
| `.iter_triples()` | Iterate all triples |

## License

MIT
