"""Tests for Claude setup templates and installed skills."""

from unittest.mock import patch

from steerdev_agent.setup.claude_setup import ClaudeSetup, check_cli_dependencies


class TestClaudeSetup:
    """Tests for lean default setup guidance."""

    def test_setup_skills_installs_focused_merge_skills(self, tmp_path):
        setup = ClaudeSetup(project_dir=tmp_path)

        skills_path = setup.setup_skills(force=True)

        assert (skills_path / "steerdev-task-management-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-progress-logging-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-single-task-merge-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-wave-tasks-merge-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-merge-into-canal-skill" / "SKILL.md").exists()
        # Deprecated shims are not installed
        assert not (skills_path / "steerdev-git-workflow-skill" / "SKILL.md").exists()
        assert not (skills_path / "steerdev-canal-workflow-skill" / "SKILL.md").exists()

    def test_update_claude_md_excludes_merge_instructions(self, tmp_path):
        setup = ClaudeSetup(project_dir=tmp_path)

        updated = setup.update_claude_md(force=True)
        content = (tmp_path / "CLAUDE.md").read_text()

        assert updated is True
        assert "steerdev-task-management-skill" in content
        assert "gh pr create" not in content
        assert "git checkout -b task" not in content
        assert "steerdev canal merge" not in content

    def test_task_management_skill_excludes_merge_instructions(self, tmp_path):
        setup = ClaudeSetup(project_dir=tmp_path)

        skills_path = setup.setup_skills(force=True)
        content = (skills_path / "steerdev-task-management-skill" / "SKILL.md").read_text()

        assert "agent-browser" in content
        assert "--waves/--no-waves" in content
        assert "gh pr create" not in content
        assert "git checkout -b task" not in content
        assert "steerdev canal merge" not in content
        assert (
            "steerdev-single-task-merge-skill" in content
        )  # skill now references merge skills by name


class TestCheckCliDependencies:
    """Tests for CLI dependency checking."""

    def test_returns_all_expected_tools(self):
        deps = check_cli_dependencies()
        names = {d.name for d in deps}
        assert "git" in names
        assert "Claude Code" in names
        assert "GitHub CLI" in names
        assert "Worktrunk" in names
        assert "Node.js" in names

    def test_git_is_required(self):
        deps = check_cli_dependencies()
        git_dep = next(d for d in deps if d.name == "git")
        assert git_dep.required is True

    def test_worktrunk_is_optional(self):
        deps = check_cli_dependencies()
        wt_dep = next(d for d in deps if d.name == "Worktrunk")
        assert wt_dep.required is False

    def test_missing_tool_detected(self):
        with patch("shutil.which", return_value=None):
            deps = check_cli_dependencies()
            for dep in deps:
                assert dep.found is False
                assert dep.path is None

    def test_found_tool_has_path(self):
        # git should be available in any dev environment
        deps = check_cli_dependencies()
        git_dep = next(d for d in deps if d.name == "git")
        if git_dep.found:
            assert git_dep.path is not None
            assert git_dep.version is not None
