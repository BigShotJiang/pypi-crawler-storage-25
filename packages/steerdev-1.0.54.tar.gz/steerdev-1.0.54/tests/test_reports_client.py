"""Tests for ReportsClient and evidence report submission."""

from unittest.mock import MagicMock, patch

from steerdev_agent.api.reports import ReportsClient
from steerdev_agent.config.models import EvidenceConfig


class TestReportsClient:
    def test_submit_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "success": True,
            "report_id": "rpt-123",
            "is_reviewable": True,
        }

        client = ReportsClient(api_key="test-key")
        with patch.object(client, "post", return_value=mock_response):
            result = client.submit(
                project_id="proj-1",
                summary="Task: Fix bug - Completed",
                blocks=[{"type": "text", "content": "Done", "order": 0}],
                task_id="task-1",
            )

        assert result is not None
        assert result["report_id"] == "rpt-123"
        assert result["is_reviewable"] is True

    def test_submit_with_evaluation_steps(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "success": True,
            "report_id": "rpt-456",
            "is_reviewable": True,
        }

        client = ReportsClient(api_key="test-key")
        with patch.object(client, "post", return_value=mock_response) as mock_post:
            client.submit(
                project_id="proj-1",
                summary="Test summary",
                blocks=[{"type": "text", "content": "Content", "order": 0}],
                task_id="task-1",
                wave_id="wave-2",
                agent_id="agent-1",
                evaluation_steps=[
                    {"title": "Task Execution", "result": "pass", "order": 0},
                ],
            )

        payload = mock_post.call_args[1]["json"]
        assert payload["project_id"] == "proj-1"
        assert payload["task_id"] == "task-1"
        assert payload["wave_id"] == "wave-2"
        assert payload["agent_id"] == "agent-1"
        assert len(payload["evaluation_steps"]) == 1

    def test_submit_failure_returns_none(self):
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.text = "Validation error"

        client = ReportsClient(api_key="test-key")
        with patch.object(client, "post", return_value=mock_response):
            result = client.submit(
                project_id="proj-1",
                summary="Test",
                blocks=[{"type": "text", "content": "Content", "order": 0}],
            )

        assert result is None

    def test_submit_exception_returns_none(self):
        client = ReportsClient(api_key="test-key")
        with patch.object(client, "post", side_effect=Exception("Network error")):
            result = client.submit(
                project_id="proj-1",
                summary="Test",
                blocks=[{"type": "text", "content": "Content", "order": 0}],
            )

        assert result is None

    def test_submit_omits_optional_none_fields(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"report_id": "rpt-1", "is_reviewable": False}

        client = ReportsClient(api_key="test-key")
        with patch.object(client, "post", return_value=mock_response) as mock_post:
            client.submit(
                project_id="proj-1",
                summary="Test",
                blocks=[{"type": "text", "content": "Content", "order": 0}],
            )

        payload = mock_post.call_args[1]["json"]
        assert "task_id" not in payload
        assert "wave_id" not in payload
        assert "agent_id" not in payload
        assert "evaluation_steps" not in payload


class TestEvidenceConfig:
    def test_defaults(self):
        cfg = EvidenceConfig()
        assert cfg.enabled is False

    def test_enabled(self):
        cfg = EvidenceConfig(enabled=True)
        assert cfg.enabled is True
