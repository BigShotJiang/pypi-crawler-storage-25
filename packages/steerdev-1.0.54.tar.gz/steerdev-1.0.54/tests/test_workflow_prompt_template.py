"""Tests for workflow prompt template rendering."""

from steerdev_agent.prompt.workflow_template import render_workflow_prompt_template


class TestWorkflowPromptTemplate:
    """Tests for workflow prompt template rendering."""

    def test_renders_dollar_placeholders(self):
        result = render_workflow_prompt_template(
            "Plan $task_title using ${task_description}",
            {
                "task_title": "Login Feature",
                "task_description": "Add OAuth2 login",
            },
        )
        assert result == "Plan Login Feature using Add OAuth2 login"

    def test_leaves_unknown_dollar_placeholders_unchanged(self):
        result = render_workflow_prompt_template(
            "Plan $task_title with $unknown_value",
            {
                "task_title": "Login Feature",
            },
        )
        assert result == "Plan Login Feature with $unknown_value"

    def test_leaves_plain_braces_unchanged(self):
        result = render_workflow_prompt_template(
            "Plan {task_title} with {unknown_value}",
            {"task_title": "Login Feature"},
        )
        assert result == "Plan {task_title} with {unknown_value}"
