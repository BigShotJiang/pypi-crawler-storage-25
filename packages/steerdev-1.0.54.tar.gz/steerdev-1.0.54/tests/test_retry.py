"""Tests for retry utilities."""

import asyncio
from unittest.mock import AsyncMock

import pytest

from steerdev_agent.config.models import RetryConfig
from steerdev_agent.retry import execute_with_retry


def _run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


class TestExecuteWithRetry:
    """Tests for execute_with_retry."""

    def test_no_retry_when_disabled(self):
        """When retry is disabled, execute_fn is called exactly once."""
        config = RetryConfig(enabled=False)
        fn = AsyncMock(return_value={"success": False, "error": "fail"})

        result = _run(execute_with_retry(fn, config))

        assert result == {"success": False, "error": "fail"}
        assert fn.call_count == 1

    def test_no_retry_when_max_retries_zero(self):
        """When max_retries is 0, execute_fn is called exactly once."""
        config = RetryConfig(enabled=True, max_retries=0)
        fn = AsyncMock(return_value={"success": False, "error": "fail"})

        result = _run(execute_with_retry(fn, config))

        assert result == {"success": False, "error": "fail"}
        assert fn.call_count == 1

    def test_no_retry_on_success(self):
        """When the first attempt succeeds, no retries are made."""
        config = RetryConfig(enabled=True, max_retries=3, delay_seconds=0.01)
        fn = AsyncMock(return_value={"success": True})

        result = _run(execute_with_retry(fn, config))

        assert result == {"success": True}
        assert fn.call_count == 1

    def test_retry_on_failure(self):
        """Retries up to max_retries times on failure."""
        config = RetryConfig(enabled=True, max_retries=2, delay_seconds=0.01)
        fn = AsyncMock(return_value={"success": False, "error": "still broken"})

        result = _run(execute_with_retry(fn, config))

        assert result == {"success": False, "error": "still broken"}
        # 1 initial + 2 retries = 3 total calls
        assert fn.call_count == 3

    def test_retry_succeeds_on_second_attempt(self):
        """Stops retrying once execute_fn returns success."""
        config = RetryConfig(enabled=True, max_retries=3, delay_seconds=0.01)
        fn = AsyncMock(
            side_effect=[
                {"success": False, "error": "transient"},
                {"success": True, "data": "ok"},
            ]
        )

        result = _run(execute_with_retry(fn, config))

        assert result == {"success": True, "data": "ok"}
        assert fn.call_count == 2

    def test_retry_succeeds_on_third_attempt(self):
        """Retries multiple times before succeeding."""
        config = RetryConfig(enabled=True, max_retries=5, delay_seconds=0.01)
        fn = AsyncMock(
            side_effect=[
                {"success": False, "error": "fail1"},
                {"success": False, "error": "fail2"},
                {"success": True},
            ]
        )

        result = _run(execute_with_retry(fn, config))

        assert result == {"success": True}
        assert fn.call_count == 3

    def test_exception_propagates(self):
        """Exceptions from execute_fn propagate (not caught by retry)."""
        config = RetryConfig(enabled=True, max_retries=3, delay_seconds=0.01)
        fn = AsyncMock(side_effect=ValueError("boom"))

        with pytest.raises(ValueError, match="boom"):
            _run(execute_with_retry(fn, config))

    def test_keyboard_interrupt_propagates(self):
        """KeyboardInterrupt during execution propagates."""
        config = RetryConfig(enabled=True, max_retries=3, delay_seconds=0.01)
        fn = AsyncMock(side_effect=KeyboardInterrupt())

        with pytest.raises(KeyboardInterrupt):
            _run(execute_with_retry(fn, config))

    def test_cancelled_error_propagates(self):
        """CancelledError during execution propagates."""
        config = RetryConfig(enabled=True, max_retries=3, delay_seconds=0.01)
        fn = AsyncMock(side_effect=asyncio.CancelledError())

        with pytest.raises(asyncio.CancelledError):
            _run(execute_with_retry(fn, config))


class TestRetryConfig:
    """Tests for RetryConfig model."""

    def test_defaults(self):
        """Test default values."""
        config = RetryConfig()
        assert config.enabled is False
        assert config.max_retries == 3
        assert config.delay_seconds == 3600.0
        assert config.backoff_multiplier == 1.0
        assert config.max_delay_seconds == 7200.0

    def test_custom_values(self):
        """Test custom values."""
        config = RetryConfig(
            enabled=True,
            max_retries=5,
            delay_seconds=60.0,
            backoff_multiplier=2.0,
            max_delay_seconds=300.0,
        )
        assert config.enabled is True
        assert config.max_retries == 5
        assert config.delay_seconds == 60.0
        assert config.backoff_multiplier == 2.0
        assert config.max_delay_seconds == 300.0

    def test_config_from_yaml(self):
        """Test that RetryConfig is loaded from SteerDevConfig."""
        import tempfile
        from pathlib import Path

        from steerdev_agent.config.models import SteerDevConfig

        yaml_content = """
retry:
  enabled: true
  max_retries: 5
  delay_seconds: 120
  backoff_multiplier: 2.0
  max_delay_seconds: 600
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            config = SteerDevConfig.from_yaml(Path(f.name))

        assert config.retry.enabled is True
        assert config.retry.max_retries == 5
        assert config.retry.delay_seconds == 120.0
        assert config.retry.backoff_multiplier == 2.0
        assert config.retry.max_delay_seconds == 600.0

    def test_steerdev_config_default_has_retry(self):
        """SteerDevConfig includes retry with defaults."""
        from steerdev_agent.config.models import SteerDevConfig

        config = SteerDevConfig()
        assert config.retry.enabled is False
        assert config.retry.max_retries == 3
