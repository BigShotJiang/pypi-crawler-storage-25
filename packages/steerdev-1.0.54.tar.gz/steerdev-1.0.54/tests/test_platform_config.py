"""Tests for platform configuration models."""

from steerdev_agent.config.platform import (
    EnvVarsConfig,
    PlatformConfig,
    SystemPromptConfig,
    WorkflowConfig,
    WorkflowPhaseConfig,
)


class TestSystemPromptConfig:
    """Tests for SystemPromptConfig."""

    def test_create(self):
        config = SystemPromptConfig(
            id="sp-1",
            name="Default",
            content="You are a helpful assistant.",
        )
        assert config.id == "sp-1"
        assert config.description is None
        assert config.version == 1

    def test_with_description(self):
        config = SystemPromptConfig(
            id="sp-1",
            name="Custom",
            description="A custom prompt",
            content="Be concise.",
            version=2,
        )
        assert config.description == "A custom prompt"
        assert config.version == 2


class TestEnvVarsConfig:
    """Tests for EnvVarsConfig."""

    def test_create(self):
        config = EnvVarsConfig(
            id="ev-1",
            name="Dev Env",
            variables={"API_KEY": "test123", "DEBUG": "true"},
        )
        assert len(config.variables) == 2
        assert config.variables["API_KEY"] == "test123"

    def test_from_api_response(self):
        data = {
            "id": "ev-1",
            "name": "Production",
            "description": "Prod env vars",
            "content": {"variables": {"DB_URL": "postgres://...", "NODE_ENV": "production"}},
            "version": 3,
        }
        config = EnvVarsConfig.from_api_response(data)
        assert config.id == "ev-1"
        assert config.name == "Production"
        assert config.description == "Prod env vars"
        assert config.variables["DB_URL"] == "postgres://..."
        assert config.version == 3

    def test_from_api_response_missing_content(self):
        """Should handle missing content gracefully."""
        data = {"id": "ev-1", "name": "Empty"}
        config = EnvVarsConfig.from_api_response(data)
        assert config.variables == {}
        assert config.version == 1


class TestPlatformConfig:
    """Tests for PlatformConfig."""

    def test_from_api_response(self):
        data = {
            "system_prompts": [
                {
                    "id": "sp-1",
                    "name": "Default",
                    "content": {"prompt": "Be helpful."},
                }
            ],
            "skills": [
                {
                    "id": "sk-1",
                    "name": "Code Review",
                    "content": {"instructions": "Review carefully"},
                }
            ],
            "mcps": [],
            "env_vars": [
                {
                    "id": "ev-1",
                    "name": "Dev",
                    "content": {"variables": {"KEY": "val"}},
                }
            ],
            "synced_at": "2026-01-01T00:00:00Z",
        }
        config = PlatformConfig.from_api_response(data)
        assert len(config.system_prompts) == 1
        assert config.system_prompts[0].content == "Be helpful."
        assert len(config.skills) == 1
        assert config.skills[0].name == "Code Review"
        assert len(config.mcps) == 0
        assert len(config.env_vars) == 1

    def test_get_combined_system_prompt(self):
        config = PlatformConfig(
            system_prompts=[
                SystemPromptConfig(id="1", name="A", content="First prompt."),
                SystemPromptConfig(id="2", name="B", content="Second prompt."),
            ],
            skills=[],
            mcps=[],
            env_vars=[],
            synced_at="2026-01-01",
        )
        combined = config.get_combined_system_prompt()
        assert combined is not None
        assert "First prompt." in combined
        assert "Second prompt." in combined

    def test_get_combined_system_prompt_empty(self):
        config = PlatformConfig(
            system_prompts=[],
            skills=[],
            mcps=[],
            env_vars=[],
            synced_at="2026-01-01",
        )
        assert config.get_combined_system_prompt() is None

    def test_get_combined_env_vars(self):
        config = PlatformConfig(
            system_prompts=[],
            skills=[],
            mcps=[],
            env_vars=[
                EnvVarsConfig(id="1", name="A", variables={"KEY1": "a", "SHARED": "from_a"}),
                EnvVarsConfig(id="2", name="B", variables={"KEY2": "b", "SHARED": "from_b"}),
            ],
            synced_at="2026-01-01",
        )
        combined = config.get_combined_env_vars()
        assert combined["KEY1"] == "a"
        assert combined["KEY2"] == "b"
        # Later env vars override earlier ones
        assert combined["SHARED"] == "from_b"


class TestWorkflowPhaseConfig:
    """Tests for WorkflowPhaseConfig."""

    def test_defaults(self):
        phase = WorkflowPhaseConfig(id="p1", name="Plan")
        assert phase.phase_type == "custom"
        assert phase.phase_order == 0
        assert phase.required_for_completion is True
        assert phase.can_skip_on_failure is False

    def test_render_prompt_basic(self):
        phase = WorkflowPhaseConfig(
            id="p1",
            name="Plan",
            prompt_template="Plan the implementation of $task_title: ${task_description}",
        )
        result = phase.render_prompt(
            task_title="Login Feature",
            task_description="Add OAuth2 login",
        )
        assert result == "Plan the implementation of Login Feature: Add OAuth2 login"

    def test_render_prompt_with_context(self):
        phase = WorkflowPhaseConfig(
            id="p1",
            name="Implement",
            prompt_template="Build $task_title using context: ${context}",
        )
        result = phase.render_prompt(
            task_title="API",
            context={"prior_plan": "REST endpoints"},
        )
        assert result is not None
        assert "API" in result
        assert "prior_plan" in result

    def test_render_prompt_with_dollar_syntax(self):
        phase = WorkflowPhaseConfig(
            id="p1",
            name="Plan",
            prompt_template="Plan $task_title with ${task_description}",
        )
        result = phase.render_prompt(
            task_title="Login Feature",
            task_description="Add OAuth2 login",
        )
        assert result == "Plan Login Feature with Add OAuth2 login"

    def test_render_prompt_none_template(self):
        phase = WorkflowPhaseConfig(id="p1", name="Plan", prompt_template=None)
        assert phase.render_prompt(task_title="Test") is None


class TestWorkflowConfig:
    """Tests for WorkflowConfig."""

    def _make_workflow(self) -> WorkflowConfig:
        return WorkflowConfig(
            id="wf-1",
            name="Standard",
            phases=[
                WorkflowPhaseConfig(id="p1", name="Plan", phase_order=0),
                WorkflowPhaseConfig(id="p2", name="Implement", phase_order=1),
                WorkflowPhaseConfig(id="p3", name="Test", phase_order=2),
            ],
        )

    def test_get_phase_by_order(self):
        wf = self._make_workflow()
        phase_0 = wf.get_phase_by_order(0)
        assert phase_0 is not None
        assert phase_0.name == "Plan"
        phase_1 = wf.get_phase_by_order(1)
        assert phase_1 is not None
        assert phase_1.name == "Implement"
        phase_2 = wf.get_phase_by_order(2)
        assert phase_2 is not None
        assert phase_2.name == "Test"
        assert wf.get_phase_by_order(99) is None

    def test_get_phase_by_id(self):
        wf = self._make_workflow()
        phase_p1 = wf.get_phase_by_id("p1")
        assert phase_p1 is not None
        assert phase_p1.name == "Plan"
        phase_p2 = wf.get_phase_by_id("p2")
        assert phase_p2 is not None
        assert phase_p2.name == "Implement"
        assert wf.get_phase_by_id("nonexistent") is None

    def test_get_next_phase(self):
        wf = self._make_workflow()
        next_p1 = wf.get_next_phase("p1")
        assert next_p1 is not None
        assert next_p1.name == "Implement"
        next_p2 = wf.get_next_phase("p2")
        assert next_p2 is not None
        assert next_p2.name == "Test"
        assert wf.get_next_phase("p3") is None  # Last phase has no next

    def test_get_next_phase_invalid_id(self):
        wf = self._make_workflow()
        assert wf.get_next_phase("nonexistent") is None

    def test_from_api_response(self):
        data = {
            "id": "wf-1",
            "name": "CI Pipeline",
            "description": "Full CI workflow",
            "is_default": True,
            "max_retries_per_phase": 2,
            "phase_timeout_seconds": 1800,
            "phases": [
                {
                    "id": "p1",
                    "name": "Lint",
                    "phase_type": "verify",
                    "phase_order": 0,
                    "required_for_completion": True,
                },
                {
                    "id": "p2",
                    "name": "Test",
                    "phase_type": "test",
                    "phase_order": 1,
                    "can_skip_on_failure": True,
                },
            ],
        }
        wf = WorkflowConfig.from_api_response(data)
        assert wf.name == "CI Pipeline"
        assert wf.is_default is True
        assert wf.max_retries_per_phase == 2
        assert len(wf.phases) == 2
        assert wf.phases[0].phase_type == "verify"
        assert wf.phases[1].can_skip_on_failure is True
