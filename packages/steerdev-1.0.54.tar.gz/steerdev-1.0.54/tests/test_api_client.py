"""Tests for base API client utilities."""

import os
from unittest.mock import patch

from steerdev_agent.api.client import (
    DEFAULT_API_ENDPOINT,
    SteerDevClient,
    get_agent_id,
    get_agent_name,
    get_api_endpoint,
    get_api_key,
    get_project_id,
)


class TestEnvHelpers:
    """Tests for environment variable helper functions."""

    def test_get_api_key_set(self):
        with patch.dict(os.environ, {"STEERDEV_API_KEY": "test-key-123"}):
            assert get_api_key() == "test-key-123"

    def test_get_api_key_unset(self):
        with patch.dict(os.environ, {}, clear=True):
            assert get_api_key() is None

    def test_get_project_id_set(self):
        with patch.dict(os.environ, {"STEERDEV_PROJECT_ID": "proj-abc"}):
            assert get_project_id() == "proj-abc"

    def test_get_project_id_unset(self):
        with patch.dict(os.environ, {}, clear=True):
            assert get_project_id() is None

    def test_get_agent_id_set(self):
        with patch.dict(os.environ, {"STEERDEV_AGENT_ID": "agent-1"}):
            assert get_agent_id() == "agent-1"

    def test_get_agent_id_unset(self):
        with patch.dict(os.environ, {}, clear=True):
            assert get_agent_id() is None

    def test_get_agent_name_set(self):
        with patch.dict(os.environ, {"STEERDEV_AGENT_NAME": "my-agent"}):
            assert get_agent_name() == "my-agent"

    def test_get_agent_name_unset(self):
        with patch.dict(os.environ, {}, clear=True):
            assert get_agent_name() is None

    def test_get_api_endpoint_default(self):
        with patch.dict(os.environ, {}, clear=True):
            assert get_api_endpoint() == DEFAULT_API_ENDPOINT

    def test_get_api_endpoint_custom(self):
        with patch.dict(os.environ, {"STEERDEV_API_ENDPOINT": "http://localhost:3000/api/v1"}):
            assert get_api_endpoint() == "http://localhost:3000/api/v1"


class TestSteerDevClient:
    """Tests for SteerDevClient."""

    def test_init_with_api_key(self):
        client = SteerDevClient(api_key="my-key")
        assert client.api_key == "my-key"

    def test_init_from_env(self):
        with patch.dict(os.environ, {"STEERDEV_API_KEY": "env-key"}):
            client = SteerDevClient()
            assert client.api_key == "env-key"

    def test_headers(self):
        client = SteerDevClient(api_key="test-key")
        headers = client.headers
        assert headers["Authorization"] == "Bearer test-key"
        assert headers["Content-Type"] == "application/json"

    def test_check_api_key_present(self):
        client = SteerDevClient(api_key="my-key")
        assert client.check_api_key() is True

    def test_check_api_key_missing(self):
        with patch.dict(os.environ, {}, clear=True):
            client = SteerDevClient(api_key=None)
            assert client.check_api_key() is False

    def test_context_manager(self):
        """Client should work as a context manager."""
        with SteerDevClient(api_key="key") as client:
            assert client.api_key == "key"
        # After exit, _client should be None
        assert client._client is None

    def test_close_without_client(self):
        """Closing without creating an HTTP client should not error."""
        client = SteerDevClient(api_key="key")
        client.close()  # Should not raise

    def test_timeout_setting(self):
        client = SteerDevClient(api_key="key", timeout=60.0)
        assert client.timeout == 60.0
