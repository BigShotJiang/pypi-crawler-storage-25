"""Extended tests for configuration models — validation edge cases and YAML error handling."""

import tempfile

import pytest
import yaml
from pydantic import ValidationError

from steerdev_agent.config.models import (
    AgentConfig,
    AgentLoopConfig,
    CanalConfig,
    EventsConfig,
    ExecutorConfig,
    SteerDevConfig,
    WorkspaceConfig,
)

# ---------------------------------------------------------------------------
# AgentConfig validation
# ---------------------------------------------------------------------------


class TestAgentConfigValidation:
    """Edge case tests for AgentConfig."""

    def test_timeout_minimum(self):
        """timeout_seconds has a minimum of 60."""
        with pytest.raises(ValidationError):
            AgentConfig(timeout_seconds=30)

    def test_timeout_at_boundary(self):
        config = AgentConfig(timeout_seconds=60)
        assert config.timeout_seconds == 60

    def test_workflow_id_optional(self):
        config = AgentConfig(workflow_id="wf-123")
        assert config.workflow_id == "wf-123"

    def test_max_turns_zero(self):
        """max_turns=0 should be allowed (no explicit minimum)."""
        config = AgentConfig(max_turns=0)
        assert config.max_turns == 0


# ---------------------------------------------------------------------------
# EventsConfig validation
# ---------------------------------------------------------------------------


class TestEventsConfigValidation:
    """Edge case tests for EventsConfig."""

    def test_batch_size_minimum(self):
        with pytest.raises(ValidationError):
            EventsConfig(batch_size=0)

    def test_batch_size_maximum(self):
        with pytest.raises(ValidationError):
            EventsConfig(batch_size=101)

    def test_batch_size_at_boundaries(self):
        config_min = EventsConfig(batch_size=1)
        assert config_min.batch_size == 1
        config_max = EventsConfig(batch_size=100)
        assert config_max.batch_size == 100

    def test_flush_interval_minimum(self):
        with pytest.raises(ValidationError):
            EventsConfig(flush_interval_seconds=0.5)

    def test_flush_interval_at_boundary(self):
        config = EventsConfig(flush_interval_seconds=1.0)
        assert config.flush_interval_seconds == 1.0


# ---------------------------------------------------------------------------
# ExecutorConfig
# ---------------------------------------------------------------------------


class TestExecutorConfigEdgeCases:
    """Edge case tests for ExecutorConfig."""

    def test_disallowed_tools(self):
        config = ExecutorConfig(disallowed_tools=["bash", "write"])
        assert config.disallowed_tools == ["bash", "write"]

    def test_allowed_and_disallowed_both_set(self):
        """Both lists can be set simultaneously."""
        config = ExecutorConfig(
            allowed_tools=["read"],
            disallowed_tools=["bash"],
        )
        assert config.allowed_tools == ["read"]
        assert config.disallowed_tools == ["bash"]

    def test_empty_lists_by_default(self):
        config = ExecutorConfig()
        assert config.allowed_tools == []
        assert config.disallowed_tools == []


# ---------------------------------------------------------------------------
# AgentLoopConfig boundary tests
# ---------------------------------------------------------------------------


class TestAgentLoopConfigBoundaries:
    """Boundary tests for AgentLoopConfig."""

    def test_gap_seconds_negative_rejected(self):
        with pytest.raises(ValidationError):
            AgentLoopConfig(gap_seconds=-1.0)

    def test_gap_seconds_zero_allowed(self):
        config = AgentLoopConfig(gap_seconds=0.0)
        assert config.gap_seconds == 0.0

    def test_max_consecutive_errors_minimum(self):
        with pytest.raises(ValidationError):
            AgentLoopConfig(max_consecutive_errors=0)

    def test_idle_poll_minimum(self):
        with pytest.raises(ValidationError):
            AgentLoopConfig(idle_poll_interval_seconds=0.5)


# ---------------------------------------------------------------------------
# WorkspaceConfig boundary tests
# ---------------------------------------------------------------------------


class TestWorkspaceConfigBoundaries:
    """Boundary tests for WorkspaceConfig."""

    def test_max_concurrent_tasks_at_boundaries(self):
        config_min = WorkspaceConfig(max_concurrent_tasks=1)
        assert config_min.max_concurrent_tasks == 1
        config_max = WorkspaceConfig(max_concurrent_tasks=10)
        assert config_max.max_concurrent_tasks == 10

    def test_project_refresh_at_boundary(self):
        config = WorkspaceConfig(project_refresh_interval=30)
        assert config.project_refresh_interval == 30


# ---------------------------------------------------------------------------
# SteerDevConfig YAML edge cases
# ---------------------------------------------------------------------------


class TestSteerDevConfigYAMLEdgeCases:
    """Edge case tests for YAML loading/saving."""

    def test_from_yaml_with_unknown_fields_ignored(self):
        """Unknown top-level fields should be ignored (Pydantic default)."""
        yaml_content = """
agent:
  timeout_seconds: 1800
unknown_section:
  foo: bar
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            config = SteerDevConfig.from_yaml(f.name)
            assert config.agent.timeout_seconds == 1800

    def test_from_yaml_invalid_yaml_raises(self):
        """Invalid YAML content raises yaml.YAMLError."""
        yaml_content = "{{invalid: yaml: content"
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            with pytest.raises(yaml.YAMLError):
                SteerDevConfig.from_yaml(f.name)

    def test_from_yaml_invalid_values_raises(self):
        """Valid YAML but invalid config values raises ValidationError."""
        yaml_content = """
agent:
  timeout_seconds: 10
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            with pytest.raises(ValidationError):
                SteerDevConfig.from_yaml(f.name)

    def test_to_yaml_creates_file(self, tmp_path):
        """to_yaml creates a valid YAML file on disk."""
        config = SteerDevConfig()
        path = tmp_path / "config.yaml"
        config.to_yaml(path)

        assert path.exists()
        with open(path) as f:
            data = yaml.safe_load(f)
        assert data is not None
        assert "agent" in data

    def test_yaml_roundtrip_preserves_all_fields(self, tmp_path):
        """Full roundtrip preserves all custom values."""
        config = SteerDevConfig()
        config.agent.model = "test-model"
        config.agent.max_turns = 10
        config.agent.timeout_seconds = 7200
        config.executor.type = "codex"
        config.executor.permission_mode = "plan"
        config.events.batch_size = 50
        config.events.flush_interval_seconds = 2.0
        config.worktrees.enabled = True
        config.agent_loop.poll_interval_seconds = 3.0
        config.agent_loop.gap_seconds = 2.0
        config.workspace.auto_clone = False
        config.workspace.max_concurrent_tasks = 5
        config.canal.enabled = True
        config.canal.base_branch = "main"

        path = tmp_path / "full_config.yaml"
        config.to_yaml(path)
        loaded = SteerDevConfig.from_yaml(path)

        assert loaded.agent.model == "test-model"
        assert loaded.agent.max_turns == 10
        assert loaded.agent.timeout_seconds == 7200
        assert loaded.executor.type == "codex"
        assert loaded.executor.permission_mode == "plan"
        assert loaded.events.batch_size == 50
        assert loaded.events.flush_interval_seconds == 2.0
        assert loaded.worktrees.enabled is True
        assert loaded.agent_loop.poll_interval_seconds == 3.0
        assert loaded.agent_loop.gap_seconds == 2.0
        assert loaded.workspace.auto_clone is False
        assert loaded.workspace.max_concurrent_tasks == 5
        assert loaded.canal.enabled is True
        assert loaded.canal.base_branch == "main"

    def test_from_yaml_with_partial_sections(self):
        """Loading YAML with only some sections uses defaults for others."""
        yaml_content = """
canal:
  enabled: true
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            config = SteerDevConfig.from_yaml(f.name)

        assert config.canal.enabled is True
        assert config.agent.timeout_seconds == 3600  # Default
        assert config.workspace.auto_clone is True  # Default


# ---------------------------------------------------------------------------
# CanalConfig edge cases
# ---------------------------------------------------------------------------


class TestCanalConfigEdgeCases:
    """Edge case tests for CanalConfig."""

    def test_empty_base_branch(self):
        """Empty string is technically valid for base_branch."""
        config = CanalConfig(base_branch="")
        assert config.base_branch == ""

    def test_various_branch_names(self):
        for branch in ["main", "develop", "release/v1.0", "feature/my-feature"]:
            config = CanalConfig(base_branch=branch)
            assert config.base_branch == branch
