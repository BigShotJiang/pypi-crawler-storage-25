"""Tests for SteerDevClient HTTP methods (get, post, patch) and context manager."""

from unittest.mock import MagicMock

import httpx

from steerdev_agent.api.client import SteerDevClient


class TestSteerDevClientHTTPMethods:
    """Tests for SteerDevClient.get, .post, .patch HTTP methods."""

    def _make_client(self) -> tuple[SteerDevClient, MagicMock]:
        client = SteerDevClient(api_key="test-key")
        mock_http = MagicMock(spec=httpx.Client)
        client._client = mock_http
        return client, mock_http

    def test_get_sends_correct_url_and_headers(self):
        client, mock_http = self._make_client()
        mock_response = MagicMock(spec=httpx.Response)
        mock_http.get.return_value = mock_response

        result = client.get("/tasks")

        mock_http.get.assert_called_once_with(
            f"{client.api_base}/tasks",
            headers=client.headers,
            params=None,
        )
        assert result is mock_response

    def test_get_with_params(self):
        client, mock_http = self._make_client()
        mock_response = MagicMock(spec=httpx.Response)
        mock_http.get.return_value = mock_response

        result = client.get("/tasks", params={"status": "started", "limit": 10})

        mock_http.get.assert_called_once_with(
            f"{client.api_base}/tasks",
            headers=client.headers,
            params={"status": "started", "limit": 10},
        )
        assert result is mock_response

    def test_post_sends_correct_url_and_json(self):
        client, mock_http = self._make_client()
        mock_response = MagicMock(spec=httpx.Response)
        mock_http.post.return_value = mock_response

        payload = {"title": "Test task", "prompt": "Do something"}
        result = client.post("/tasks", json=payload)

        mock_http.post.assert_called_once_with(
            f"{client.api_base}/tasks",
            headers=client.headers,
            json=payload,
        )
        assert result is mock_response

    def test_post_without_json(self):
        client, mock_http = self._make_client()
        mock_response = MagicMock(spec=httpx.Response)
        mock_http.post.return_value = mock_response

        result = client.post("/tasks")

        mock_http.post.assert_called_once_with(
            f"{client.api_base}/tasks",
            headers=client.headers,
            json=None,
        )
        assert result is mock_response

    def test_patch_sends_correct_url_and_json(self):
        client, mock_http = self._make_client()
        mock_response = MagicMock(spec=httpx.Response)
        mock_http.patch.return_value = mock_response

        payload = {"status": "started"}
        result = client.patch("/tasks/task-123", json=payload)

        mock_http.patch.assert_called_once_with(
            f"{client.api_base}/tasks/task-123",
            headers=client.headers,
            json=payload,
        )
        assert result is mock_response

    def test_get_client_creates_httpx_client(self):
        """_get_client lazily creates an httpx.Client."""
        client = SteerDevClient(api_key="key", timeout=45.0)
        assert client._client is None

        http_client = client._get_client()
        assert http_client is not None
        assert client._client is http_client

        # Second call returns same client
        assert client._get_client() is http_client
        client.close()

    def test_close_sets_client_to_none(self):
        """close() properly closes and nullifies the HTTP client."""
        client = SteerDevClient(api_key="key")
        _ = client._get_client()  # Force creation
        assert client._client is not None

        client.close()
        assert client._client is None

    def test_context_manager_closes_client(self):
        """Context manager ensures client is closed on exit."""
        with SteerDevClient(api_key="key") as client:
            _ = client._get_client()
            assert client._client is not None
        assert client._client is None

    def test_context_manager_closes_on_exception(self):
        """Context manager closes client even if exception occurs."""
        client: SteerDevClient | None = None
        try:
            with SteerDevClient(api_key="key") as client:
                _ = client._get_client()
                raise ValueError("test error")
        except ValueError:
            pass
        assert client is not None
        assert client._client is None
