"""Tests for agent_loop module (AgentLoopError, CommandExecutor logic)."""

import asyncio
from pathlib import Path
from typing import cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from steerdev_agent.agent_loop import AgentLoopError, CommandExecutor
from steerdev_agent.api.commands import CommandResponse
from steerdev_agent.config.models import (
    AgentLoopConfig,
    EvidenceConfig,
    ExecutorConfig,
    WorktreeConfig,
)


def _make_command_response(**overrides) -> CommandResponse:
    """Create a CommandResponse for testing."""
    defaults = {
        "id": "cmd-test-1",
        "agent_id": "agent-1",
        "project_id": "proj-1",
        "command_type": "task",
        "status": "claimed",
        "created_at": "2025-01-01T00:00:00Z",
        "updated_at": "2025-01-01T00:00:00Z",
    }
    defaults.update(overrides)
    return CommandResponse(**defaults)


def _make_executor() -> tuple["ConcreteCommandExecutor", AsyncMock, AsyncMock]:
    """Create a ConcreteCommandExecutor and return it with its mock clients."""
    executor = ConcreteCommandExecutor()
    commands_mock = cast("AsyncMock", executor._commands_client)
    sessions_mock = cast("AsyncMock", executor._sessions_client)
    return executor, commands_mock, sessions_mock


class ConcreteCommandExecutor(CommandExecutor):
    """Concrete subclass for testing the shared CommandExecutor logic."""

    def __init__(self) -> None:
        self._api_key = "test-key"
        self.agent_type = "claude"
        self.agent_name = "test-agent"
        self.model = None
        self.max_turns = None
        self._executor_config = ExecutorConfig()
        self._workflow_id = None
        self._worktree_config = WorktreeConfig()
        self._evidence_config = EvidenceConfig()
        self._agent_loop_config = AgentLoopConfig()
        self._commands_client = AsyncMock()  # pyright: ignore[reportIncompatibleVariableOverride]
        self._sessions_client = AsyncMock()  # pyright: ignore[reportIncompatibleVariableOverride]
        self._shutdown_event = asyncio.Event()
        self._commands_executed = 0
        self._commands_succeeded = 0
        self._commands_failed = 0
        self._is_busy = False


class TestAgentLoopError:
    """Tests for AgentLoopError."""

    def test_is_exception(self):
        err = AgentLoopError("test error")
        assert isinstance(err, Exception)
        assert str(err) == "test error"


class TestCommandExecutor:
    """Tests for CommandExecutor._execute_command dispatch logic."""

    @pytest.mark.asyncio
    async def test_execute_unknown_command_type(self):
        """Unknown command types are marked as failed."""
        executor, commands_mock, _ = _make_executor()
        cmd = _make_command_response(command_type="control", control_action="stop")

        await executor._execute_command(cmd, "proj-1", Path("/code"))

        commands_mock.mark_failed.assert_awaited_once()
        call_args = commands_mock.mark_failed.call_args
        # error can be positional or keyword arg
        error_msg = call_args.kwargs.get("error") or call_args.args[1]
        assert "Unknown command type" in error_msg
        assert executor._commands_failed == 1
        assert executor._commands_executed == 1
        assert executor._is_busy is False

    @pytest.mark.asyncio
    async def test_execute_task_command_missing_task_id(self):
        """Task command without task_id is marked as failed."""
        executor, commands_mock, _ = _make_executor()
        cmd = _make_command_response(command_type="task")
        assert cmd.task_id is None

        await executor._execute_command(cmd, "proj-1", Path("/code"))

        commands_mock.mark_failed.assert_awaited()
        assert executor._commands_failed == 1

    @pytest.mark.asyncio
    async def test_execute_prompt_command_missing_prompt(self):
        """Prompt command without prompt is marked as failed."""
        executor, commands_mock, _ = _make_executor()
        cmd = _make_command_response(command_type="prompt")
        assert cmd.prompt is None

        await executor._execute_command(cmd, "proj-1", Path("/code"))

        commands_mock.mark_failed.assert_awaited()
        assert executor._commands_failed == 1

    @pytest.mark.asyncio
    async def test_execute_command_tracks_busy_state(self):
        """Command execution sets and unsets _is_busy."""
        executor, _, _ = _make_executor()
        cmd = _make_command_response(command_type="control")

        assert executor._is_busy is False
        await executor._execute_command(cmd, "proj-1", Path("/code"))
        # After execution completes, _is_busy should be False
        assert executor._is_busy is False

    @pytest.mark.asyncio
    async def test_execute_command_increments_counter(self):
        """Each execute_command increments _commands_executed."""
        executor, _, _ = _make_executor()
        cmd = _make_command_response(command_type="control")

        await executor._execute_command(cmd, "proj-1", Path("/code"))
        assert executor._commands_executed == 1

        await executor._execute_command(cmd, "proj-1", Path("/code"))
        assert executor._commands_executed == 2

    @pytest.mark.asyncio
    async def test_execute_command_handles_unexpected_exception(self):
        """Unexpected exceptions during execution are caught and command marked failed."""
        executor, commands_mock, _ = _make_executor()
        cmd = _make_command_response(command_type="task", task_id="task-1")

        # Make _execute_task_command raise an unexpected error
        with patch.object(executor, "_execute_task_command", side_effect=RuntimeError("boom")):
            await executor._execute_command(cmd, "proj-1", Path("/code"))

        commands_mock.mark_failed.assert_awaited_once()
        assert executor._commands_failed == 1
        assert executor._is_busy is False

    @pytest.mark.asyncio
    async def test_execute_prompt_command_session_creation_failure(self):
        """Prompt command fails gracefully when session creation fails."""
        executor, commands_mock, sessions_mock = _make_executor()
        sessions_mock.create_session = AsyncMock(return_value=None)
        cmd = _make_command_response(command_type="prompt", prompt="do something")

        await executor._execute_command(cmd, "proj-1", Path("/code"))

        commands_mock.mark_failed.assert_awaited()
        assert executor._commands_failed == 1

    @pytest.mark.asyncio
    async def test_execute_task_command_task_not_found(self):
        """Task command fails when task is not found in API."""
        executor, commands_mock, _ = _make_executor()
        cmd = _make_command_response(command_type="task", task_id="task-missing")

        # Mock Runner and TasksClient
        mock_tasks_client = MagicMock()
        mock_tasks_client.get_task.return_value = None
        mock_tasks_client.__enter__ = MagicMock(return_value=mock_tasks_client)
        mock_tasks_client.__exit__ = MagicMock(return_value=False)

        with patch("steerdev_agent.agent_loop.TasksClient", return_value=mock_tasks_client):
            await executor._execute_command(cmd, "proj-1", Path("/code"))

        commands_mock.mark_failed.assert_awaited()
        assert executor._commands_failed == 1
