"""SteerDev Agent - Backend task runner for steerdev.com.

Orchestrates CLI coding agents (Claude Code, Gemini CLI, Codex)
with activity reporting to steerdev.com API and notification integrations.
"""

from steerdev_agent.version import get_version

__version__ = get_version()
__all__ = ["__version__"]
