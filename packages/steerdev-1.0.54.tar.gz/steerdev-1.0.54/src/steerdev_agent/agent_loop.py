"""Persistent agent loop mode.

Runs indefinitely, polling for commands from the API. Each command
execution creates a session with full event streaming, reusing the
existing Runner infrastructure for task execution.

Two modes:
- AgentLoop: single-project agent (original). Fixed project_id + working_directory.
- WorkspaceAgentLoop: multi-project workspace agent. Resolves project_id +
  working_directory per command from project assignments.

Both share execution logic via the CommandExecutor base class.
"""

from __future__ import annotations

import asyncio
import contextlib
import signal
import socket
from pathlib import Path
from typing import TYPE_CHECKING

import httpx
from loguru import logger
from rich.console import Console
from rich.panel import Panel

if TYPE_CHECKING:
    from steerdev_agent.api.agents import AgentsClient, ProjectAssignment
    from steerdev_agent.workspace.project_manager import ProjectManager

from steerdev_agent.api.commands import CommandResponse, CommandsClient
from steerdev_agent.api.events import EventsClient
from steerdev_agent.api.sessions import SessionCreateRequest, SessionsClient
from steerdev_agent.api.tasks import TasksClient
from steerdev_agent.config.models import (
    AgentLoopConfig,
    EvidenceConfig,
    ExecutorConfig,
    RetryConfig,
    WorkspaceConfig,
    WorktreeConfig,
)
from steerdev_agent.executor import ExecutorFactory
from steerdev_agent.executor.base import EventType
from steerdev_agent.executor.claude import ClaudeExecutorError

console = Console()


class AgentLoopError(Exception):
    """Error during agent loop execution."""


# ---------------------------------------------------------------------------
# Shared execution logic
# ---------------------------------------------------------------------------


class CommandExecutor:
    """Shared command execution dispatch for both project and workspace agents.

    Subclasses provide: _api_key, agent_type, agent_name, model, max_turns,
    _executor_config, _workflow_id, _worktree_config, _agent_loop_config,
    _commands_client, _sessions_client, _shutdown_event, and the stats counters.
    """

    # These are populated by subclass __init__
    _api_key: str | None
    agent_type: str
    agent_name: str
    model: str | None
    max_turns: int | None
    _executor_config: ExecutorConfig
    _retry_config: RetryConfig
    _workflow_id: str | None
    _enable_waves: bool
    _enable_canals: bool
    _worktree_config: WorktreeConfig
    _evidence_config: EvidenceConfig
    _agent_loop_config: AgentLoopConfig
    _commands_client: CommandsClient | None
    _sessions_client: SessionsClient | None
    _shutdown_event: asyncio.Event
    _current_task: asyncio.Task[bool] | None
    _signal_count: int
    _commands_executed: int
    _commands_succeeded: int
    _commands_failed: int
    _is_busy: bool

    async def _execute_command(
        self,
        command: CommandResponse,
        project_id: str,
        working_directory: Path,
    ) -> None:
        """Execute a single command.

        For task-type commands, delegates to Runner for the full execution
        pipeline (workflow, wave context, worktrees).

        For prompt-type commands, executes the prompt directly.
        """
        assert self._commands_client is not None

        self._is_busy = True
        self._commands_executed += 1

        cmd_desc = (
            f"task={command.task_id}"
            if command.command_type == "task"
            else f"prompt={command.prompt[:50]}..."
            if command.prompt and len(command.prompt) > 50
            else f"prompt={command.prompt}"
            if command.prompt
            else command.command_type
        )
        console.print(f"\n[bold cyan]Executing command: {cmd_desc}[/bold cyan]")
        console.print(f"[dim]Command ID: {command.id}[/dim]")

        try:
            if command.command_type == "task":
                await self._execute_task_command(command, project_id, working_directory)
            elif command.command_type == "prompt":
                await self._execute_prompt_command(command, project_id, working_directory)
            else:
                await self._commands_client.mark_failed(
                    command.id, error=f"Unknown command type: {command.command_type}"
                )
                self._commands_failed += 1
        except Exception as e:
            error_msg = str(e)
            logger.exception(f"Unexpected error executing command: {error_msg}")
            await self._commands_client.mark_failed(command.id, error=error_msg)
            self._commands_failed += 1
        finally:
            self._is_busy = False

    async def _execute_task_command(
        self,
        command: CommandResponse,
        project_id: str,
        working_directory: Path,
    ) -> None:
        """Execute a task command using the Runner's full pipeline.

        This ensures the agent uses the exact same execution path as `steerdev run`:
        - Workflow support (multi-phase execution)
        - Wave context (wave-aware prompts)
        - Worktree isolation
        - Full prompt building with project/task/wave context
        """
        assert self._commands_client is not None

        if not command.task_id:
            await self._commands_client.mark_failed(
                command.id, error="Task command missing task_id"
            )
            self._commands_failed += 1
            return

        from steerdev_agent.runner import Runner

        # Create a Runner that shares our configuration
        runner = Runner(
            project_id=project_id,
            working_directory=str(command.working_directory or working_directory),
            api_key=self._api_key,
            agent_type=self.agent_type,
            agent_name=self.agent_name,
            model=self.model,
            max_turns=self.max_turns,
            enable_waves=self._enable_waves,
            enable_canals=self._enable_canals,
            worktree_config=self._worktree_config,
            evidence_config=self._evidence_config,
            executor_config=self._executor_config,
            force_workflow_id=None,
            shutdown_event=self._shutdown_event,
        )

        # Fetch task details
        with TasksClient(api_key=self._api_key) as tasks_client:
            task = tasks_client.get_task(command.task_id)
            if not task:
                await self._commands_client.mark_failed(
                    command.id, error=f"Task not found: {command.task_id}"
                )
                self._commands_failed += 1
                return

        # Fetch wave context
        wave_ctx = None
        if self._enable_waves:
            try:
                from steerdev_agent.runner import extract_task_and_wave_context

                with TasksClient(api_key=self._api_key) as tasks_client:
                    wave_response = tasks_client.get_next_wave(project_id=project_id)
                    _, wave_ctx, _ = extract_task_and_wave_context(wave_response)
            except Exception:
                logger.debug("Wave fetch failed, continuing without wave context", exc_info=True)

        # Resolve workflow: force override > default workflow fallback
        workflow_id = self._workflow_id
        if not workflow_id:
            try:
                from steerdev_agent.api.workflows import WorkflowsClient

                async with WorkflowsClient(api_key=self._api_key) as wf_client:
                    default_wf = await wf_client.get_default_workflow(project_id)
                    if default_wf:
                        workflow_id = default_wf.id
            except Exception:
                logger.debug("Failed to fetch default workflow", exc_info=True)

        # If using workflows, create a run record
        if workflow_id:
            runner.db_run_id = await runner.create_run_record()

        # Mark command as executing (Runner creates the actual session internally)
        await self._commands_client.update_command(command.id, status="executing")

        # Delegate to Runner.execute_task — the full pipeline (with retry)
        from steerdev_agent.retry import execute_with_retry

        result = await execute_with_retry(
            lambda: runner.execute_task(task, wave_context=wave_ctx, workflow_id=workflow_id),
            self._retry_config,
            task.get("title", "Unknown"),
        )

        # Update command based on result
        if result.get("success"):
            session_id = runner.session_id
            if session_id:
                await self._commands_client.update_command(command.id, session_id=session_id)
            await self._commands_client.mark_completed(
                command.id,
                result=f"Completed successfully. Events: {result.get('events_sent', 0)}",
            )
            self._commands_succeeded += 1
            console.print("[green]Command completed successfully[/green]")
        else:
            error_msg = result.get("error", "Unknown error")
            await self._commands_client.mark_failed(command.id, error=error_msg)
            self._commands_failed += 1
            console.print(f"[red]Command failed: {error_msg}[/red]")

        # Complete or fail the run record
        if runner.db_run_id:
            from steerdev_agent.api.runs import RunsClient

            runs_client = RunsClient(api_key=self._api_key)
            try:
                if result.get("success"):
                    await runs_client.complete_run(
                        runner.db_run_id, tasks_executed=1, tasks_succeeded=1
                    )
                else:
                    await runs_client.fail_run(
                        runner.db_run_id, error_message=result.get("error", "")
                    )
            finally:
                await runs_client.close()

    async def _execute_prompt_command(
        self,
        command: CommandResponse,
        project_id: str,
        working_directory: Path,
    ) -> None:
        """Execute a freeform prompt command directly (no task/workflow pipeline)."""
        assert self._commands_client is not None
        assert self._sessions_client is not None

        if not command.prompt:
            await self._commands_client.mark_failed(
                command.id, error="Prompt command missing prompt"
            )
            self._commands_failed += 1
            return

        # Create session
        session = await self._sessions_client.create_session(
            SessionCreateRequest(
                project_id=project_id,
                task_id=command.task_id,
                agent_name=self.agent_name,
                agent_type=self.agent_type,
                prompt=command.prompt,
                working_directory=str(command.working_directory or working_directory),
            )
        )

        if not session:
            await self._commands_client.mark_failed(command.id, error="Failed to create session")
            self._commands_failed += 1
            return

        # Mark command as executing with session_id
        await self._commands_client.mark_executing(command.id, session.id)
        await self._sessions_client.mark_running(session.id)

        # Execute
        events_client = EventsClient(session_id=session.id, api_key=self._api_key)
        await events_client.start()
        events_sent = 0

        try:
            executor = ExecutorFactory.create(
                config=self._executor_config,
                working_directory=str(command.working_directory or working_directory),
                model=self.model,
                max_turns=self.max_turns,
            )

            await executor.start(command.prompt)
            console.print("[dim]Agent started, streaming output...[/dim]")

            async def _run_execution() -> int:
                nonlocal events_sent
                async for event in executor.stream_events():
                    await events_client.add_event(
                        event_type=event.event_type.value,
                        data=event.data,
                        raw_json=event.raw_json,
                        timestamp=event.timestamp,
                    )
                    events_sent += 1

                    if event.event_type == EventType.ASSISTANT:
                        msg = event.data.get("message", {})
                        content = msg.get("content", "")
                        if isinstance(content, str) and content:
                            preview = content[:100] + "..." if len(content) > 100 else content
                            console.print(f"[cyan]Assistant:[/cyan] {preview}")

                    if self._shutdown_event.is_set():
                        logger.info("Shutdown during execution, stopping executor")
                        await executor.stop()
                        return -1

                return await executor.wait()

            exit_code = await asyncio.wait_for(
                _run_execution(),
                timeout=self._agent_loop_config.command_timeout_seconds,
            )

            agent_session_id = executor.session_id

            if exit_code != 0:
                stderr = await executor.get_stderr()
                error_msg = stderr.strip() if stderr else f"Process exited with code {exit_code}"
                await self._commands_client.mark_failed(command.id, error=error_msg)
                await self._sessions_client.mark_failed(
                    session.id,
                    metadata={"error": error_msg, "exit_code": exit_code},
                )
                self._commands_failed += 1
                console.print(f"[red]Command failed: {error_msg}[/red]")
            else:
                await self._commands_client.mark_completed(
                    command.id,
                    result=f"Completed successfully. Events: {events_sent}",
                )
                await self._sessions_client.mark_completed(
                    session.id,
                    agent_session_id=agent_session_id,
                )
                self._commands_succeeded += 1
                console.print("[green]Command completed successfully[/green]")

        except TimeoutError:
            error_msg = (
                f"Command timed out after {self._agent_loop_config.command_timeout_seconds}s"
            )
            logger.error(error_msg)
            await self._commands_client.mark_failed(command.id, error=error_msg)
            await self._sessions_client.mark_failed(session.id, metadata={"error": error_msg})
            self._commands_failed += 1
            console.print(f"[red]{error_msg}[/red]")

        except ClaudeExecutorError as e:
            error_msg = str(e)
            logger.error(f"Executor error: {error_msg}")
            await self._commands_client.mark_failed(command.id, error=error_msg)
            await self._sessions_client.mark_failed(session.id, metadata={"error": error_msg})
            self._commands_failed += 1

        except Exception as e:
            error_msg = str(e)
            logger.exception(f"Unexpected error executing prompt command: {error_msg}")
            await self._commands_client.mark_failed(command.id, error=error_msg)
            await self._sessions_client.mark_failed(session.id, metadata={"error": error_msg})
            self._commands_failed += 1

        finally:
            await events_client.close()


# ---------------------------------------------------------------------------
# Project-scoped agent (original)
# ---------------------------------------------------------------------------


class AgentLoop(CommandExecutor):
    """Persistent agent that polls for commands and executes them.

    Single-project mode: fixed project_id and working_directory.

    Lifecycle:
    1. Register agent (get/create agent_id via API)
    2. Recover stale commands from previous crash (reset to pending)
    3. Start heartbeat background task
    4. Enter poll loop:
       a. Poll /commands/next
       b. If command found -> execute it
       c. If nothing -> sleep(idle_poll_interval)
       d. Check for shutdown signal
    5. On shutdown: send offline heartbeat, exit
    """

    def __init__(
        self,
        project_id: str,
        agent_name: str,
        working_directory: str | Path | None = None,
        api_key: str | None = None,
        agent_type: str = "claude",
        model: str | None = None,
        max_turns: int | None = None,
        agent_loop_config: AgentLoopConfig | None = None,
        executor_config: ExecutorConfig | None = None,
        force_workflow_id: str | None = None,
        enable_waves: bool = True,
        enable_canals: bool = False,
        worktree_config: WorktreeConfig | None = None,
        evidence_config: EvidenceConfig | None = None,
        retry_config: RetryConfig | None = None,
    ) -> None:
        self.project_id = project_id
        self.agent_name = agent_name
        self.working_directory = Path(working_directory or Path.cwd())
        self._api_key = api_key
        self.agent_type = agent_type
        self.model = model
        self.max_turns = max_turns
        self._agent_loop_config = agent_loop_config or AgentLoopConfig()
        self._executor_config = executor_config or ExecutorConfig()
        self._retry_config = retry_config or RetryConfig()
        self._workflow_id = force_workflow_id
        self._enable_waves = enable_waves
        self._enable_canals = enable_canals
        self._worktree_config = worktree_config or WorktreeConfig()
        self._evidence_config = evidence_config or EvidenceConfig()

        # State
        self._agent_id: str | None = None
        self._shutdown_event = asyncio.Event()
        self._current_task: asyncio.Task[bool] | None = None
        self._signal_count = 0
        self._is_busy = False
        self._consecutive_errors = 0
        self._commands_executed = 0
        self._commands_succeeded = 0
        self._commands_failed = 0

        # Components
        self._commands_client: CommandsClient | None = None
        self._sessions_client: SessionsClient | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        """Start the agent loop."""
        self._setup_signal_handlers()

        workflow_status = self._workflow_id or "single-phase"
        waves_status = "enabled" if self._enable_waves else "disabled"
        canals_status = "enabled" if self._enable_canals else "disabled"
        worktree_status = (
            f"enabled ({self._worktree_config.provider})"
            if self._worktree_config.enabled
            else "disabled"
        )

        console.print(
            Panel(
                f"[bold blue]SteerDev Agent[/bold blue]\n"
                f"Project: {self.project_id}\n"
                f"Agent: {self.agent_name}\n"
                f"Working Dir: {self.working_directory}\n"
                f"Poll Interval: {self._agent_loop_config.poll_interval_seconds}s\n"
                f"Workflow: {workflow_status}\n"
                f"Waves: {waves_status}\n"
                f"Canals: {canals_status}\n"
                f"Worktrees: {worktree_status}",
                title="Starting Agent",
            )
        )

        try:
            # Step 1: Register agent
            self._agent_id = await self._register_agent()
            if not self._agent_id:
                raise AgentLoopError("Failed to register agent")

            logger.info(f"Agent registered: {self._agent_id}")

            # Initialize clients
            self._commands_client = CommandsClient(
                agent_id=self._agent_id,
                api_key=self._api_key,
            )
            self._sessions_client = SessionsClient(api_key=self._api_key)

            # Step 2: Recover stale commands
            await self._recover_stale_commands()

            # Step 3: Start heartbeat
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

            # Step 4: Main poll loop
            await self._poll_loop()

        except AgentLoopError as e:
            logger.error(f"Agent error: {e}")
            console.print(f"[red]Agent error: {e}[/red]")
        except Exception as e:
            logger.exception(f"Unexpected agent error: {e}")
            console.print(f"[red]Unexpected error: {e}[/red]")
        finally:
            # Step 5: Shutdown
            await self._shutdown()

    async def _register_agent(self) -> str | None:
        """Register this agent via the API and return the agent_id."""
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                from steerdev_agent.api.client import get_api_endpoint, get_api_key

                api_key = self._api_key or get_api_key()
                api_base = get_api_endpoint()

                response = await client.post(
                    f"{api_base}/agents",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "name": self.agent_name,
                        "project_id": self.project_id,
                        "application": self.agent_type,
                        "hostname": socket.gethostname(),
                    },
                )

                if response.status_code in (200, 201):
                    data = response.json()
                    return data["id"]

                logger.error(f"Failed to register agent: {response.status_code} - {response.text}")
                return None
        except httpx.RequestError as e:
            logger.error(f"Request error registering agent: {e}")
            return None

    async def _recover_stale_commands(self) -> None:
        """Reset any claimed/executing commands from a previous crash back to pending."""
        if not self._commands_client:
            return

        for stale_status in ("claimed", "executing"):
            result = await self._commands_client.list_commands(status=stale_status)  # type: ignore[arg-type]
            if not result:
                continue

            for cmd in result.commands:
                logger.warning(
                    f"Resetting stale command {cmd.id} back to pending (was {cmd.status})"
                )
                await self._commands_client.mark_pending(cmd.id)

    async def _poll_loop(self) -> None:
        """Main loop: poll for commands and execute them."""
        logger.info("Entering poll loop")
        console.print("[green]Agent ready, polling for commands...[/green]")

        while not self._shutdown_event.is_set():
            try:
                task = asyncio.create_task(self._poll_once())
                self._current_task = task
                try:
                    executed = await task
                except asyncio.CancelledError:
                    break
                finally:
                    self._current_task = None

                if executed:
                    self._consecutive_errors = 0
                    interval = max(
                        self._agent_loop_config.gap_seconds,
                        self._agent_loop_config.poll_interval_seconds,
                    )
                else:
                    interval = self._agent_loop_config.idle_poll_interval_seconds

            except Exception as e:
                self._consecutive_errors += 1
                logger.error(f"Poll error ({self._consecutive_errors}): {e}")

                if self._consecutive_errors >= self._agent_loop_config.max_consecutive_errors:
                    logger.error("Max consecutive errors reached, shutting down")
                    console.print("[red]Max consecutive errors reached, shutting down[/red]")
                    break

                # Exponential backoff: 2^n seconds, capped at 60s
                backoff = min(2**self._consecutive_errors, 60)
                interval = backoff

            # Sleep with cancellation support
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=interval,
                )
                # If we get here, shutdown was signaled
                break
            except TimeoutError:
                # Normal timeout, continue polling
                pass

    async def _poll_once(self) -> bool:
        """Poll for one command. Returns True if something was executed."""
        assert self._commands_client is not None

        # Try command queue
        command = await self._commands_client.poll_next()

        if command:
            # Handle control commands specially
            if command.command_type == "control":
                return await self._handle_control_command(command)

            # Project agent: fixed project_id and working_directory
            await self._execute_command(command, self.project_id, self.working_directory)
            return True

        return False

    async def _handle_control_command(self, command: CommandResponse) -> bool:
        """Handle control commands (shutdown, etc.)."""
        assert self._commands_client is not None

        if command.control_action == "shutdown":
            logger.info("Received shutdown command")
            console.print("[yellow]Received shutdown command[/yellow]")
            await self._commands_client.mark_completed(command.id, result="Shutdown acknowledged")
            self._shutdown_event.set()
            return True

        logger.warning(f"Unknown control action: {command.control_action}")
        await self._commands_client.mark_failed(
            command.id,
            error=f"Unknown control action: {command.control_action}",
        )
        return True

    async def _heartbeat_loop(self) -> None:
        """Background task: send heartbeat every N seconds."""
        while not self._shutdown_event.is_set():
            try:
                await self._send_heartbeat()
            except Exception as e:
                logger.warning(f"Heartbeat error: {e}")

            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=self._agent_loop_config.heartbeat_interval_seconds,
                )
                break  # Shutdown signaled
            except TimeoutError:
                pass

    async def _send_heartbeat(self) -> None:
        """Send a heartbeat to update agent status."""
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                from steerdev_agent.api.client import get_api_endpoint, get_api_key

                api_key = self._api_key or get_api_key()
                api_base = get_api_endpoint()

                # Re-register to update heartbeat (getOrCreateAgent updates last_heartbeat_at)
                await client.post(
                    f"{api_base}/agents",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "name": self.agent_name,
                        "project_id": self.project_id,
                        "application": self.agent_type,
                        "hostname": socket.gethostname(),
                    },
                )
        except httpx.RequestError as e:
            logger.debug(f"Heartbeat request error: {e}")

    def _setup_signal_handlers(self) -> None:
        """Set up SIGINT/SIGTERM handlers for graceful shutdown."""
        loop = asyncio.get_running_loop()

        def _sigint_handler() -> None:
            self._signal_count += 1
            if self._signal_count == 1:
                logger.info("Received shutdown signal")
                console.print(
                    "\n[yellow]Received shutdown signal, finishing current work...[/yellow]"
                )
                console.print("[dim]Press Ctrl-C again to force stop[/dim]")
                self._shutdown_event.set()
            else:
                logger.info("Force stop requested")
                console.print("\n[red]Force stopping...[/red]")
                if self._current_task and not self._current_task.done():
                    self._current_task.cancel()

        def _sigterm_handler() -> None:
            logger.info("Received SIGTERM")
            self._shutdown_event.set()

        loop.add_signal_handler(signal.SIGINT, _sigint_handler)
        loop.add_signal_handler(signal.SIGTERM, _sigterm_handler)

    async def _shutdown(self) -> None:
        """Clean up resources and send offline heartbeat."""
        console.print("[dim]Shutting down agent...[/dim]")

        # Cancel heartbeat task
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task

        # Send offline heartbeat (best effort)
        with contextlib.suppress(Exception):
            await self._send_heartbeat()

        # Close clients
        if self._commands_client:
            await self._commands_client.close()
        if self._sessions_client:
            await self._sessions_client.close()

        # Print summary
        console.print(
            Panel(
                f"[bold]Agent Summary[/bold]\n"
                f"Commands Executed: {self._commands_executed}\n"
                f"Commands Succeeded: {self._commands_succeeded}\n"
                f"Commands Failed: {self._commands_failed}",
                title="Shutdown Complete",
                border_style="yellow",
            )
        )


# ---------------------------------------------------------------------------
# Workspace agent (multi-project)
# ---------------------------------------------------------------------------


class WorkspaceAgentLoop(CommandExecutor):
    """Multi-project workspace agent.

    Differs from AgentLoop in:
    - Registration: kind="workspace" with workspace_path (no project_id)
    - Working directory: resolved per-command from project assignments
    - Project sync: periodic fetch of assigned projects + auto-setup
    - Polling: same endpoint (GET /agents/:id/commands/next)

    Everything else — command execution, session creation, event streaming,
    task/wave handling, heartbeat — is identical via CommandExecutor.
    """

    def __init__(
        self,
        workspace_path: str | Path,
        agent_name: str,
        api_key: str | None = None,
        agent_type: str = "claude",
        model: str | None = None,
        max_turns: int | None = None,
        agent_loop_config: AgentLoopConfig | None = None,
        executor_config: ExecutorConfig | None = None,
        workspace_config: WorkspaceConfig | None = None,
        force_workflow_id: str | None = None,
        enable_waves: bool = True,
        enable_canals: bool = False,
        worktree_config: WorktreeConfig | None = None,
        evidence_config: EvidenceConfig | None = None,
        retry_config: RetryConfig | None = None,
    ) -> None:
        self.workspace_path = Path(workspace_path)
        self.agent_name = agent_name
        self._api_key = api_key
        self.agent_type = agent_type
        self.model = model
        self.max_turns = max_turns
        self._agent_loop_config = agent_loop_config or AgentLoopConfig()
        self._executor_config = executor_config or ExecutorConfig()
        self._retry_config = retry_config or RetryConfig()
        self._workspace_config = workspace_config or WorkspaceConfig()
        self._workflow_id = force_workflow_id
        self._enable_waves = enable_waves
        self._enable_canals = enable_canals
        self._worktree_config = worktree_config or WorktreeConfig()
        self._evidence_config = evidence_config or EvidenceConfig()

        # State
        self._agent_id: str | None = None
        self._shutdown_event = asyncio.Event()
        self._current_task: asyncio.Task[bool] | None = None
        self._signal_count = 0
        self._is_busy = False
        self._consecutive_errors = 0
        self._commands_executed = 0
        self._commands_succeeded = 0
        self._commands_failed = 0

        # Components
        self._commands_client: CommandsClient | None = None
        self._sessions_client: SessionsClient | None = None
        self._agents_client: AgentsClient | None = None
        self._project_manager: ProjectManager | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._project_sync_task: asyncio.Task[None] | None = None

        # Project assignments cache: project_id -> ProjectAssignment
        self._assignments: dict[str, ProjectAssignment] = {}

    async def start(self) -> None:
        """Start the workspace agent loop."""
        self._setup_signal_handlers()

        waves_status = "enabled" if self._enable_waves else "disabled"
        canals_status = "enabled" if self._enable_canals else "disabled"
        worktree_status = (
            f"enabled ({self._worktree_config.provider})"
            if self._worktree_config.enabled
            else "disabled"
        )

        console.print(
            Panel(
                f"[bold blue]SteerDev Workspace Agent[/bold blue]\n"
                f"Workspace: {self.workspace_path}\n"
                f"Agent: {self.agent_name}\n"
                f"Poll Interval: {self._agent_loop_config.poll_interval_seconds}s\n"
                f"Project Refresh: {self._workspace_config.project_refresh_interval}s\n"
                f"Waves: {waves_status}\n"
                f"Canals: {canals_status}\n"
                f"Worktrees: {worktree_status}",
                title="Starting Workspace Agent",
            )
        )

        # Ensure workspace directory exists
        self.workspace_path.mkdir(parents=True, exist_ok=True)

        try:
            # Step 1: Register workspace agent
            self._agent_id = await self._register_workspace_agent()
            if not self._agent_id:
                raise AgentLoopError("Failed to register workspace agent")

            logger.info(f"Workspace agent registered: {self._agent_id}")

            # Initialize clients
            self._commands_client = CommandsClient(
                agent_id=self._agent_id,
                api_key=self._api_key,
            )
            self._sessions_client = SessionsClient(api_key=self._api_key)

            from steerdev_agent.api.agents import AgentsClient
            from steerdev_agent.workspace.project_manager import ProjectManager

            self._agents_client = AgentsClient(api_key=self._api_key)
            self._project_manager = ProjectManager(
                workspace_dir=self.workspace_path,
                api_client=self._agents_client,
                agent_id=self._agent_id,
                api_key=self._api_key,
            )

            # Step 2: Recover stale commands
            await self._recover_stale_commands()

            # Step 3: Initial project sync
            await self._sync_projects()

            # Step 4: Start background tasks
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
            self._project_sync_task = asyncio.create_task(self._project_sync_loop())

            # Step 5: Main poll loop
            await self._poll_loop()

        except AgentLoopError as e:
            logger.error(f"Workspace agent error: {e}")
            console.print(f"[red]Workspace agent error: {e}[/red]")
        except Exception as e:
            logger.exception(f"Unexpected workspace agent error: {e}")
            console.print(f"[red]Unexpected error: {e}[/red]")
        finally:
            await self._shutdown()

    async def _register_workspace_agent(self) -> str | None:
        """Register this workspace agent via the API."""
        from steerdev_agent.api.agents import AgentsClient
        from steerdev_agent.workspace.tool_detection import detect_installed_tools

        agents_client = AgentsClient(api_key=self._api_key)
        try:
            result = await agents_client.register_workspace(
                name=self.agent_name,
                application=self.agent_type,
                hostname=socket.gethostname(),
                workspace_path=str(self.workspace_path),
                capabilities=detect_installed_tools(),
            )
            if result:
                return result.id
            return None
        finally:
            await agents_client.close()

    async def _recover_stale_commands(self) -> None:
        """Reset any claimed/executing commands from a previous crash back to pending."""
        if not self._commands_client:
            return

        for stale_status in ("claimed", "executing"):
            result = await self._commands_client.list_commands(status=stale_status)  # type: ignore[arg-type]
            if not result:
                continue

            for cmd in result.commands:
                logger.warning(
                    f"Resetting stale command {cmd.id} back to pending (was {cmd.status})"
                )
                await self._commands_client.mark_pending(cmd.id)

    async def _sync_projects(self) -> None:
        """Fetch project assignments and set up missing projects."""
        if not self._agents_client or not self._agent_id or not self._project_manager:
            return

        assignments = await self._agents_client.get_projects(self._agent_id)

        # Update cache
        self._assignments = {a.project_id: a for a in assignments if a.is_active}

        project_count = len(self._assignments)
        logger.info(f"Synced {project_count} project assignment(s)")

        if self._workspace_config.auto_clone:
            await self._project_manager.sync_projects(assignments)

    async def _project_sync_loop(self) -> None:
        """Background task: refresh project assignments periodically."""
        while not self._shutdown_event.is_set():
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=self._workspace_config.project_refresh_interval,
                )
                break  # Shutdown signaled
            except TimeoutError:
                pass

            try:
                await self._sync_projects()
            except Exception as e:
                logger.warning(f"Project sync error: {e}")

    async def _poll_loop(self) -> None:
        """Main loop: poll for commands and execute them."""
        logger.info("Entering poll loop")
        console.print("[green]Workspace agent ready, polling for commands...[/green]")

        while not self._shutdown_event.is_set():
            try:
                task = asyncio.create_task(self._poll_once())
                self._current_task = task
                try:
                    executed = await task
                except asyncio.CancelledError:
                    break
                finally:
                    self._current_task = None

                if executed:
                    self._consecutive_errors = 0
                    interval = max(
                        self._agent_loop_config.gap_seconds,
                        self._agent_loop_config.poll_interval_seconds,
                    )
                else:
                    interval = self._agent_loop_config.idle_poll_interval_seconds

            except Exception as e:
                self._consecutive_errors += 1
                logger.error(f"Poll error ({self._consecutive_errors}): {e}")

                if self._consecutive_errors >= self._agent_loop_config.max_consecutive_errors:
                    logger.error("Max consecutive errors reached, shutting down")
                    console.print("[red]Max consecutive errors reached, shutting down[/red]")
                    break

                backoff = min(2**self._consecutive_errors, 60)
                interval = backoff

            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=interval,
                )
                break
            except TimeoutError:
                pass

    async def _poll_once(self) -> bool:
        """Poll for one command. Returns True if something was executed."""
        assert self._commands_client is not None

        command = await self._commands_client.poll_next()

        if command:
            if command.command_type == "control":
                return await self._handle_control_command(command)

            # Workspace agent: resolve project_id and working_directory from assignments
            project_id = command.project_id
            working_directory = self._resolve_working_directory(command)

            if not working_directory:
                logger.error(
                    f"No local path for project {project_id}, skipping command {command.id}"
                )
                await self._commands_client.mark_failed(
                    command.id,
                    error=f"No local path configured for project {project_id}",
                )
                self._commands_failed += 1
                return True

            await self._execute_command(command, project_id, working_directory)
            return True

        return False

    def _resolve_working_directory(self, command: CommandResponse) -> Path | None:
        """Resolve the working directory for a command from project assignments."""
        # 1. Command-level override
        if command.working_directory:
            path = Path(command.working_directory)
            if path.is_dir():
                return path

        # 2. Project manager cache
        if self._project_manager:
            path = self._project_manager.get_project_path(command.project_id)
            if path:
                return path

        # 3. Assignment local_path
        assignment = self._assignments.get(command.project_id)
        if assignment and assignment.local_path:
            path = Path(assignment.local_path)
            if path.is_dir():
                return path

        return None

    async def _handle_control_command(self, command: CommandResponse) -> bool:
        """Handle control commands (shutdown, etc.)."""
        assert self._commands_client is not None

        if command.control_action == "shutdown":
            logger.info("Received shutdown command")
            console.print("[yellow]Received shutdown command[/yellow]")
            await self._commands_client.mark_completed(command.id, result="Shutdown acknowledged")
            self._shutdown_event.set()
            return True

        logger.warning(f"Unknown control action: {command.control_action}")
        await self._commands_client.mark_failed(
            command.id,
            error=f"Unknown control action: {command.control_action}",
        )
        return True

    async def _heartbeat_loop(self) -> None:
        """Background task: send heartbeat every N seconds."""
        while not self._shutdown_event.is_set():
            try:
                await self._send_heartbeat()
            except Exception as e:
                logger.warning(f"Heartbeat error: {e}")

            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=self._agent_loop_config.heartbeat_interval_seconds,
                )
                break
            except TimeoutError:
                pass

    async def _send_heartbeat(self) -> None:
        """Send a heartbeat by re-registering the workspace agent."""
        from steerdev_agent.api.agents import AgentsClient
        from steerdev_agent.workspace.tool_detection import detect_installed_tools

        agents_client = AgentsClient(api_key=self._api_key)
        try:
            await agents_client.register_workspace(
                name=self.agent_name,
                application=self.agent_type,
                hostname=socket.gethostname(),
                workspace_path=str(self.workspace_path),
                capabilities=detect_installed_tools(),
            )
        except Exception as e:
            logger.debug(f"Heartbeat error: {e}")
        finally:
            await agents_client.close()

    def _setup_signal_handlers(self) -> None:
        """Set up SIGINT/SIGTERM handlers for graceful shutdown."""
        loop = asyncio.get_running_loop()

        def _sigint_handler() -> None:
            self._signal_count += 1
            if self._signal_count == 1:
                logger.info("Received shutdown signal")
                console.print(
                    "\n[yellow]Received shutdown signal, finishing current work...[/yellow]"
                )
                console.print("[dim]Press Ctrl-C again to force stop[/dim]")
                self._shutdown_event.set()
            else:
                logger.info("Force stop requested")
                console.print("\n[red]Force stopping...[/red]")
                if self._current_task and not self._current_task.done():
                    self._current_task.cancel()

        def _sigterm_handler() -> None:
            logger.info("Received SIGTERM")
            self._shutdown_event.set()

        loop.add_signal_handler(signal.SIGINT, _sigint_handler)
        loop.add_signal_handler(signal.SIGTERM, _sigterm_handler)

    async def _shutdown(self) -> None:
        """Clean up resources and send offline heartbeat."""
        console.print("[dim]Shutting down workspace agent...[/dim]")

        # Cancel background tasks
        for task in (self._heartbeat_task, self._project_sync_task):
            if task and not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

        # Send final heartbeat (best effort)
        with contextlib.suppress(Exception):
            await self._send_heartbeat()

        # Close clients
        if self._commands_client:
            await self._commands_client.close()
        if self._sessions_client:
            await self._sessions_client.close()
        if self._agents_client:
            await self._agents_client.close()

        # Print summary
        console.print(
            Panel(
                f"[bold]Workspace Agent Summary[/bold]\n"
                f"Projects: {len(self._assignments)}\n"
                f"Commands Executed: {self._commands_executed}\n"
                f"Commands Succeeded: {self._commands_succeeded}\n"
                f"Commands Failed: {self._commands_failed}",
                title="Shutdown Complete",
                border_style="yellow",
            )
        )


# ---------------------------------------------------------------------------
# Convenience functions
# ---------------------------------------------------------------------------


async def run_agent_loop(
    project_id: str,
    agent_name: str,
    working_directory: str | None = None,
    api_key: str | None = None,
    agent_type: str = "claude",
    model: str | None = None,
    max_turns: int | None = None,
    agent_loop_config: AgentLoopConfig | None = None,
    executor_config: ExecutorConfig | None = None,
    force_workflow_id: str | None = None,
    enable_waves: bool = True,
    enable_canals: bool = False,
    worktree_config: WorktreeConfig | None = None,
    evidence_config: EvidenceConfig | None = None,
    retry_config: RetryConfig | None = None,
) -> None:
    """Run the project-scoped agent loop.

    Convenience function for running the agent loop with minimal setup.
    """
    agent = AgentLoop(
        project_id=project_id,
        agent_name=agent_name,
        working_directory=working_directory,
        api_key=api_key,
        agent_type=agent_type,
        model=model,
        max_turns=max_turns,
        agent_loop_config=agent_loop_config,
        executor_config=executor_config,
        force_workflow_id=force_workflow_id,
        enable_waves=enable_waves,
        enable_canals=enable_canals,
        worktree_config=worktree_config,
        evidence_config=evidence_config,
        retry_config=retry_config,
    )
    await agent.start()


async def run_workspace_agent_loop(
    workspace_path: str,
    agent_name: str,
    api_key: str | None = None,
    agent_type: str = "claude",
    model: str | None = None,
    max_turns: int | None = None,
    agent_loop_config: AgentLoopConfig | None = None,
    executor_config: ExecutorConfig | None = None,
    workspace_config: WorkspaceConfig | None = None,
    force_workflow_id: str | None = None,
    enable_waves: bool = True,
    enable_canals: bool = False,
    worktree_config: WorktreeConfig | None = None,
    evidence_config: EvidenceConfig | None = None,
    retry_config: RetryConfig | None = None,
) -> None:
    """Run the workspace (multi-project) agent loop.

    Convenience function for running the workspace agent loop.
    """
    agent = WorkspaceAgentLoop(
        workspace_path=workspace_path,
        agent_name=agent_name,
        api_key=api_key,
        agent_type=agent_type,
        model=model,
        max_turns=max_turns,
        agent_loop_config=agent_loop_config,
        executor_config=executor_config,
        workspace_config=workspace_config,
        force_workflow_id=force_workflow_id,
        enable_waves=enable_waves,
        enable_canals=enable_canals,
        worktree_config=worktree_config,
        evidence_config=evidence_config,
        retry_config=retry_config,
    )
    await agent.start()
