"""Evidence collection: run a verification session after task completion.

After a task or workflow finishes, this module spawns a short agent session
that reviews what was done — checking git changes, using agent-browser for
visual verification, and writing a structured review.
"""

from __future__ import annotations

import asyncio
import contextlib
from typing import Any

from loguru import logger
from rich.console import Console

from steerdev_agent.executor import ExecutorFactory
from steerdev_agent.executor.base import EventType

console = Console()

# Maximum turns for the evidence-collection session.  Enough for:
# git diff/log (2), optional file reads (3), agent-browser (4), summary (1)
EVIDENCE_MAX_TURNS = 25


def build_evidence_prompt(
    task: dict[str, Any],
    success: bool,
    phase_summaries: list[dict[str, Any]] | None = None,
    evidence_messages: list[str] | None = None,
) -> str:
    """Build the prompt sent to the agent for evidence collection.

    Args:
        task: The completed task dict.
        success: Whether the task succeeded.
        phase_summaries: Per-phase summaries (workflow tasks only).
        evidence_messages: Assistant messages collected during execution
            (non-workflow tasks only).
    """
    task_title = task.get("title", "Unknown Task")
    task_prompt = task.get("prompt", "")
    status = "Completed successfully" if success else "Failed"

    sections: list[str] = [
        "# Evidence Collection\n",
        "You have just completed a task. Your job now is to **review and document "
        "what was accomplished** so a human reviewer can verify the work.\n",
        f"## Task\n- **Title:** {task_title}\n- **Status:** {status}\n",
    ]

    if task_prompt:
        sections.append(f"## Original Requirement\n{task_prompt[:2000]}\n")

    # Include work output from the execution
    if phase_summaries:
        lines = ["## Workflow Phase Results\n"]
        for ps in phase_summaries:
            name = ps.get("phase_name", "Phase")
            ok = "Pass" if ps.get("success") else "Fail"
            text = ps.get("summary", "")
            lines.append(f"### {name} ({ok})\n{text[:1500]}\n")
        sections.append("\n".join(lines))
    elif evidence_messages:
        last = evidence_messages[-1][:3000]
        sections.append(f"## Agent Output (last message)\n{last}\n")

    sections.append(
        "## Your Instructions\n\n"
        "Collect evidence that the work is correct. Follow these steps:\n\n"
        "### 1. File Changes\n"
        "Run `git diff --stat` and `git log --oneline -5` to see what changed.\n"
        "Summarize the key modifications.\n\n"
        "### 2. Visual Verification\n"
        "If the task involved **UI or frontend changes**:\n"
        "- Use `agent-browser open <url>` to navigate to the relevant page\n"
        "- Use `agent-browser screenshot` to capture it\n"
        "- Describe what you see and whether it matches the acceptance criteria\n\n"
        "If the task was backend-only, verify via tests or logs instead.\n\n"
        "### 3. Tests\n"
        "If there are relevant tests, run them and report the results.\n\n"
        "### 4. Review Summary\n"
        "Write a structured review covering:\n"
        "- What was implemented or changed\n"
        "- Key files modified and why\n"
        "- Visual verification or test results\n"
        "- Any concerns, edge cases, or issues found\n\n"
        "Be specific and factual. Include code snippets or file paths where relevant.\n"
    )

    return "\n".join(sections)


async def collect_evidence(
    *,
    task: dict[str, Any],
    success: bool,
    working_directory: str,
    executor_config: Any,
    model: str | None,
    api_key: str | None,
    dry_run: bool = False,
    phase_summaries: list[dict[str, Any]] | None = None,
    evidence_messages: list[str] | None = None,
) -> list[str]:
    """Run a short agent session to collect evidence of completed work.

    Returns a list of assistant messages produced during the evidence session.
    Best-effort: returns an empty list on any failure.
    """
    prompt = build_evidence_prompt(
        task,
        success=success,
        phase_summaries=phase_summaries,
        evidence_messages=evidence_messages,
    )

    if dry_run:
        console.print("[dim]Evidence collection (dry run): would run evidence prompt[/dim]")
        return []

    executor = ExecutorFactory.create(
        config=executor_config,
        working_directory=working_directory,
        model=model,
        max_turns=EVIDENCE_MAX_TURNS,
        dry_run=False,
    )

    collected: list[str] = []

    try:
        await executor.start(prompt)
        console.print("[dim]Evidence collection started...[/dim]")

        async for event in executor.stream_events():
            if event.event_type == EventType.ASSISTANT:
                message = event.data.get("message", {})
                content = message.get("content", "") if isinstance(message, dict) else str(message)
                if isinstance(content, str) and content.strip():
                    collected.append(content)

        await executor.wait()
        console.print(f"[dim]Evidence collection done ({len(collected)} messages)[/dim]")

    except Exception:
        logger.debug("Evidence collection session failed", exc_info=True)
        console.print("[dim]Evidence collection failed, using fallback[/dim]")

    finally:
        if executor.is_running:
            with contextlib.suppress(asyncio.CancelledError, TimeoutError, Exception):
                await asyncio.wait_for(executor.stop(), timeout=3.0)

    return collected
