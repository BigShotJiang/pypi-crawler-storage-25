"""Worktrunk (wt) CLI client for managing git worktrees.

Wraps the `wt` CLI (https://worktrunk.dev/) to provide worktree lifecycle
management: creation, removal, listing, and merge gating. The runner uses
this module instead of the old Claude CLI `--worktree` flag.
"""

from __future__ import annotations

import asyncio
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from steerdev_agent.prompt.builder import WaveContext


class WorktrunkError(Exception):
    """Error during worktrunk CLI operation."""


@dataclass
class WorktreeInfo:
    """Parsed worktree entry from `wt list --format=json`."""

    branch: str
    path: str
    is_main: bool = False
    marker: str = ""
    extra: dict[str, Any] = field(default_factory=dict)


class WorktrunkClient:
    """Async client for the worktrunk (`wt`) CLI.

    All methods run `wt` as a subprocess using asyncio. The client expects
    `wt` to be installed and available in PATH.
    """

    WT_CLI = "wt"

    def __init__(self, repo_path: str | Path) -> None:
        """Initialize the client.

        Args:
            repo_path: Path to the main repository (where `wt` commands run).
        """
        self.repo_path = Path(repo_path)

    def ensure_installed(self) -> str:
        """Check that the `wt` CLI is available in PATH.

        Returns:
            Path to the wt executable.

        Raises:
            WorktrunkError: If wt is not found.
        """
        wt_path = shutil.which(self.WT_CLI)
        if wt_path is None:
            raise WorktrunkError(
                f"'{self.WT_CLI}' CLI not found in PATH. Install worktrunk: https://worktrunk.dev/"
            )
        return wt_path

    async def _run(self, *args: str, check: bool = True) -> str:
        """Run a wt command and return stdout.

        Args:
            args: Command arguments (e.g., "switch", "--create", "branch").
            check: If True, raise on non-zero exit code.

        Returns:
            Stdout as a string.

        Raises:
            WorktrunkError: If the command fails and check is True.
        """
        wt_path = self.ensure_installed()
        cmd = [wt_path, *args]
        logger.debug(f"Running: {' '.join(cmd)}")

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(self.repo_path),
        )
        stdout_bytes, stderr_bytes = await proc.communicate()
        stdout = stdout_bytes.decode("utf-8", errors="replace").strip()
        stderr = stderr_bytes.decode("utf-8", errors="replace").strip()

        if check and proc.returncode != 0:
            raise WorktrunkError(
                f"wt {' '.join(args)} failed (exit {proc.returncode}): {stderr or stdout}"
            )

        if stderr:
            logger.debug(f"wt stderr: {stderr}")

        return stdout

    async def switch(self, branch: str, *, create: bool = True) -> Path:
        """Create or switch to a worktree for the given branch.

        Args:
            branch: Branch name (e.g., "task/PROJ-123-slug" or "wave/3").
            create: If True, create the worktree if it doesn't exist.

        Returns:
            Path to the worktree directory.

        Raises:
            WorktrunkError: If the switch fails.
        """
        args = ["switch"]
        if create:
            args.append("--create")
        args.append(branch)

        await self._run(*args)
        logger.info(f"Switched to worktree: {branch}")

        # Resolve the worktree path
        path = await self.get_worktree_path(branch)
        if path is None:
            raise WorktrunkError(f"Worktree created but path not found for branch: {branch}")
        return path

    async def remove(self, branch: str) -> None:
        """Remove a worktree.

        Args:
            branch: Branch name of the worktree to remove.

        Raises:
            WorktrunkError: If removal fails.
        """
        await self._run("remove", branch)
        logger.info(f"Removed worktree: {branch}")

    async def list_worktrees(self) -> list[WorktreeInfo]:
        """List all worktrees.

        Returns:
            List of WorktreeInfo entries.
        """
        output = await self._run("list", "--format=json")
        if not output:
            return []

        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse wt list output: {output[:200]}")
            return []

        entries: list[WorktreeInfo] = []
        items = data if isinstance(data, list) else data.get("worktrees", [])
        for item in items:
            entries.append(
                WorktreeInfo(
                    branch=item.get("branch", ""),
                    path=item.get("path", ""),
                    is_main=item.get("is_main", False),
                    marker=item.get("marker", ""),
                    extra={
                        k: v
                        for k, v in item.items()
                        if k not in ("branch", "path", "is_main", "marker")
                    },
                )
            )
        return entries

    async def merge(self, branch: str) -> None:
        """Merge a worktree branch.

        Args:
            branch: Branch name to merge.

        Raises:
            WorktrunkError: If merge fails.
        """
        await self._run("merge", branch)
        logger.info(f"Merged worktree: {branch}")

    async def get_worktree_path(self, branch: str) -> Path | None:
        """Get the filesystem path for a worktree by branch name.

        Args:
            branch: Branch name to look up.

        Returns:
            Path to the worktree directory, or None if not found.
        """
        worktrees = await self.list_worktrees()
        for wt in worktrees:
            if wt.branch == branch:
                return Path(wt.path)
        return None


def compute_branch_name(
    task: dict[str, Any],
    wave_context: WaveContext | None = None,
) -> str:
    """Compute the branch name for a task or wave.

    Naming conventions aligned with merge skill branch patterns:
    - Wave: "wave/{wave_number}" (e.g., "wave/3")
    - Task with external ID: "task/{TICKET-ID}-{slug}" (e.g., "task/PROJ-123-add-auth")
    - Task without external ID: "task/{short-id}-{slug}" (e.g., "task/abc12345-add-auth")

    Args:
        task: Task data from the API.
        wave_context: Wave metadata, if this task is part of a wave.

    Returns:
        Branch name string.
    """
    if wave_context:
        return f"wave/{wave_context.wave_number}"

    # Try external ticket ID first (e.g., Linear "PROJ-123")
    external_id = task.get("linear_identifier") or task.get("external_id")
    task_id = task.get("id", "unknown")
    title = task.get("title", "")

    # Build slug from title
    slug = _slugify(title) if title else ""

    prefix = external_id or (task_id[:8] if len(task_id) > 8 else task_id)

    if slug:
        return f"task/{prefix}-{slug}"
    return f"task/{prefix}"


def _slugify(text: str, max_length: int = 40) -> str:
    """Convert text to a URL/branch-safe slug.

    Args:
        text: Text to slugify.
        max_length: Maximum length of the slug.

    Returns:
        Lowercase, hyphenated slug.
    """
    import re

    # Lowercase and replace non-alphanumeric with hyphens
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower())
    # Strip leading/trailing hyphens
    slug = slug.strip("-")
    # Truncate
    if len(slug) > max_length:
        slug = slug[:max_length].rstrip("-")
    return slug
