"""Repository setup for cloning project repos during steerdev setup."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from typing import TYPE_CHECKING

from loguru import logger
from rich.console import Console
from rich.table import Table

if TYPE_CHECKING:
    from pathlib import Path

console = Console()


@dataclass
class RepoInfo:
    """Repository information from the API."""

    name: str
    owner: str
    full_name: str
    default_branch: str


@dataclass
class RepoStatus:
    """Status of a repository after detection/cloning."""

    repo: RepoInfo
    found: bool = False
    local_path: Path | None = None
    cloned: bool = False
    skipped: bool = False
    error: str | None = None


_ssh_available: bool | None = None


def _check_ssh_access() -> bool:
    """Check if SSH access to GitHub is available. Cached per session."""
    global _ssh_available
    if _ssh_available is not None:
        return _ssh_available

    try:
        result = subprocess.run(
            ["ssh", "-T", "-o", "StrictHostKeyChecking=accept-new", "git@github.com"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        # GitHub SSH returns exit code 1 with "successfully authenticated"
        _ssh_available = "successfully authenticated" in result.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        _ssh_available = False

    logger.debug(f"SSH access to GitHub: {_ssh_available}")
    return _ssh_available


def _build_clone_url(repo: RepoInfo) -> str:
    """Construct clone URL, preferring SSH if available."""
    if _check_ssh_access():
        return f"git@github.com:{repo.owner}/{repo.name}.git"
    return f"https://github.com/{repo.owner}/{repo.name}.git"


def _normalize_github_url(url: str) -> str | None:
    """Extract owner/name from a GitHub SSH or HTTPS URL.

    Returns full_name like "org/repo" or None if not a GitHub URL.
    """
    # SSH: git@github.com:owner/repo.git
    m = re.match(r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$", url)
    if m:
        return f"{m.group(1)}/{m.group(2)}"

    # HTTPS: https://github.com/owner/repo.git
    m = re.match(r"https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?$", url)
    if m:
        return f"{m.group(1)}/{m.group(2)}"

    return None


def _get_git_remote_url(repo_path: Path) -> str | None:
    """Get the origin remote URL for a git repo."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return None


def _list_remote_branches(clone_url: str) -> list[str]:
    """List remote branches via git ls-remote."""
    try:
        result = subprocess.run(
            ["git", "ls-remote", "--heads", clone_url],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0:
            branches = []
            for line in result.stdout.strip().splitlines():
                # Format: <sha>\trefs/heads/<branch>
                parts = line.split("\t")
                if len(parts) == 2 and parts[1].startswith("refs/heads/"):
                    branches.append(parts[1].removeprefix("refs/heads/"))
            return sorted(branches)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return []


def detect_local_repos(workspace_dir: Path, repos: list[RepoInfo]) -> dict[str, RepoStatus]:
    """Scan workspace for existing repos, matching by git remote URL.

    Returns a dict keyed by full_name with detection results.
    """
    statuses: dict[str, RepoStatus] = {}
    for repo in repos:
        statuses[repo.full_name] = RepoStatus(repo=repo)

    # Build lookup of full_name -> RepoInfo
    lookup = {r.full_name.lower(): r.full_name for r in repos}

    if not workspace_dir.is_dir():
        return statuses

    def _try_match(directory: Path) -> None:
        """Try to match a directory against the repo lookup."""
        if not directory.is_dir() or not (directory / ".git").exists():
            return

        # Try matching by remote URL
        remote_url = _get_git_remote_url(directory)
        if remote_url:
            normalized = _normalize_github_url(remote_url)
            if normalized and normalized.lower() in lookup:
                key = lookup[normalized.lower()]
                if not statuses[key].found:
                    statuses[key].found = True
                    statuses[key].local_path = directory
                return

        # Fallback: match by directory name == repo name
        for repo in repos:
            if (
                directory.name == repo.name
                and repo.full_name in statuses
                and not statuses[repo.full_name].found
            ):
                statuses[repo.full_name].found = True
                statuses[repo.full_name].local_path = directory

    # Check workspace_dir itself (user may be running setup from inside the repo)
    _try_match(workspace_dir)

    # Scan immediate children of workspace_dir
    for child in workspace_dir.iterdir():
        if child == workspace_dir:
            continue
        _try_match(child)

    return statuses


def _clone_repo(clone_url: str, target_dir: Path, branch: str) -> None:
    """Clone a repository to target_dir on the given branch."""
    cmd = ["git", "clone", "--branch", branch, clone_url, str(target_dir)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"git clone exited with {result.returncode}")


def _prompt_clone(repo: RepoInfo) -> bool:
    """Prompt user to clone a repo. Returns True if yes."""
    import typer

    return typer.confirm(
        f"Clone {repo.full_name}? (default branch: {repo.default_branch})",
        default=True,
    )


def _prompt_branch(repo: RepoInfo, branches: list[str]) -> str:
    """Prompt user to choose a branch. Returns branch name."""
    import typer

    console.print(f"\n[bold]Branches for {repo.full_name}:[/bold]")
    # Put default branch first
    ordered = [repo.default_branch] if repo.default_branch in branches else []
    ordered += [b for b in branches if b != repo.default_branch]

    for i, branch in enumerate(ordered, 1):
        suffix = " [dim](default)[/dim]" if branch == repo.default_branch else ""
        console.print(f"  [cyan]{i}[/cyan]) {branch}{suffix}")

    while True:
        choice = typer.prompt("Select branch", default="1")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(ordered):
                return ordered[idx]
        except ValueError:
            # Allow typing branch name directly
            if choice in ordered:
                return choice
        console.print(f"[red]Invalid choice '{choice}'[/red]")


def check_and_clone_repos(
    workspace_dir: Path,
    repositories: list[dict],
    interactive: bool = True,
    clone_all: bool = False,
    choose_branch: bool = False,
) -> list[RepoStatus]:
    """Main entry point: detect existing repos and optionally clone missing ones.

    Args:
        workspace_dir: Directory to scan and clone into.
        repositories: List of repo dicts from the API (name, owner, full_name, default_branch).
        interactive: Whether to prompt for cloning (False in CI/piped stdin).
        clone_all: Clone all missing repos without prompting.
        choose_branch: Show interactive branch picker per repo.

    Returns:
        List of RepoStatus objects.
    """
    # Parse repo dicts into RepoInfo
    repos = [
        RepoInfo(
            name=r["name"],
            owner=r["owner"],
            full_name=r["full_name"],
            default_branch=r.get("default_branch", "main"),
        )
        for r in repositories
    ]

    if not repos:
        console.print("[dim]No repositories configured for this project.[/dim]")
        return []

    console.print("\n[blue]Checking project repositories...[/blue]\n")

    # Detect existing repos
    statuses = detect_local_repos(workspace_dir, repos)

    # Display table
    table = Table(title="Project Repositories", show_header=True, header_style="bold")
    table.add_column("Repository", style="cyan")
    table.add_column("Status")

    for full_name, status in statuses.items():
        if status.found:
            rel = (
                f"./{status.local_path.relative_to(workspace_dir)}/"
                if status.local_path
                else "found"
            )
            table.add_row(full_name, f"[green]Found: {rel}[/green]")
        else:
            table.add_row(full_name, "[yellow]Not found locally[/yellow]")

    console.print(table)
    console.print()

    # Determine which repos to clone
    missing = [s for s in statuses.values() if not s.found]
    if not missing:
        console.print("[dim]All repositories already present.[/dim]")
        return list(statuses.values())

    # Non-interactive and not clone_all -> skip
    if not interactive and not clone_all:
        for s in missing:
            s.skipped = True
        console.print(
            f"[dim]{len(missing)} repository(ies) not found (non-interactive mode, skipping).[/dim]"
        )
        return list(statuses.values())

    # Clone missing repos
    cloned_count = 0
    skipped_count = 0

    for status in missing:
        repo = status.repo

        # Decide whether to clone
        should_clone = clone_all
        if not should_clone and interactive:
            should_clone = _prompt_clone(repo)

        if not should_clone:
            status.skipped = True
            skipped_count += 1
            console.print(f"[dim]  Skipped {repo.full_name}[/dim]")
            continue

        # Determine branch
        branch = repo.default_branch
        if choose_branch and interactive:
            clone_url = _build_clone_url(repo)
            branches = _list_remote_branches(clone_url)
            if branches:
                branch = _prompt_branch(repo, branches)
            else:
                console.print(
                    f"[yellow]  Could not list branches, using default: {branch}[/yellow]"
                )

        # Clone
        target = workspace_dir / repo.name
        if target.exists():
            if (target / ".git").exists():
                # Somehow exists but wasn't detected - skip
                status.found = True
                status.local_path = target
                console.print(f"[dim]  Directory already exists: ./{repo.name}/[/dim]")
                continue
            else:
                status.error = f"Directory ./{repo.name}/ exists but is not a git repo"
                status.skipped = True
                skipped_count += 1
                console.print(f"[yellow]  {status.error}[/yellow]")
                continue

        clone_url = _build_clone_url(repo)
        console.print(f"  Cloning {repo.full_name} (branch: {branch})...")

        try:
            _clone_repo(clone_url, target, branch)
            status.cloned = True
            status.local_path = target
            cloned_count += 1
            console.print(f"[green]  Cloned to ./{repo.name}/[/green]")
        except (RuntimeError, subprocess.TimeoutExpired) as e:
            status.error = str(e)
            skipped_count += 1
            console.print(f"[red]  Failed to clone {repo.full_name}: {e}[/red]")

    # Summary
    found_count = sum(1 for s in statuses.values() if s.found and not s.cloned)
    console.print()
    if cloned_count:
        console.print(f"[green]Cloned {cloned_count} repository(ies)[/green]")
    if found_count:
        console.print(f"[dim]{found_count} repository(ies) already present[/dim]")
    if skipped_count:
        console.print(f"[dim]{skipped_count} repository(ies) skipped[/dim]")

    return list(statuses.values())
