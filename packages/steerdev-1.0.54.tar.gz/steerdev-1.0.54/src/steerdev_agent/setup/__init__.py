"""Setup module for configuring Claude Code integration."""

from steerdev_agent.setup.claude_setup import ClaudeSetup
from steerdev_agent.setup.repo_setup import check_and_clone_repos

__all__ = ["ClaudeSetup", "check_and_clone_repos"]
