# Merge Into Canal Skill

> **IMPORTANT: This skill is opt-in only.** Only use it when the `--canals` flag was explicitly passed to `steerdev run` or `steerdev agent`. If you are unsure whether canals are enabled, use `steerdev-wave-tasks-merge-skill` or `steerdev-single-task-merge-skill` instead.

Use this skill when a workflow phase tells you to merge the **current task branch or wave branch into a canal**.

## When to Use

- The workflow prompt explicitly references `merge-into-canal`
- `--canals` is active
- The prerequisite branch and PR work for the current branch is already done

## Expected Outcome

- The current branch is merged into a canal
- The task result includes the PR URL and canal identifier
- If wave context is present, the shared wave branch is treated as the merge source

## Pre-check

Before merging into a canal, verify your current branch has been pushed and has a PR. Do NOT switch branches or sync to main — this skill operates on the current task/wave branch.

## Workflow

1. Confirm the workflow phase says the branch is ready for canal integration
2. Find the target canal:

```bash
steerdev canal next
```

3. If no canal is available, create one:

```bash
steerdev canal create
```

4. Merge the current branch into the canal:

```bash
steerdev canal merge --task-id TASK_ID [--canal-id ID]
```

5. Update the task result with the PR URL and canal identifier
6. If the current branch represents a wave, update all related tasks accordingly
7. When the workflow says the canal is ready for review, create the canal PR:

```bash
steerdev canal pr CANAL_ID
```

## Constraints

- This skill does **not** define CI/CD waiting semantics; follow the active workflow prompt for prerequisite gates
- Do not force-push to resolve canal conflicts
- Do not manually resolve canal merge conflicts outside the supported tooling
- If canal merge fails, report the blocker with task comments or status updates

## Example

```bash
steerdev canal next
steerdev canal create
steerdev canal merge --task-id abc12345...
steerdev tasks update abc12345... --result "PR: https://github.com/org/repo/pull/42. Canal: canal/1"
steerdev canal pr canal-1
```
