# Single Task Merge Skill

Use this skill when a workflow phase tells you to complete **one task on one branch with one pull request**.

## When to Use

- The workflow prompt explicitly references `single-task-merge`
- `--no-waves` is active, or no wave context is present
- Canals are not explicitly enabled for this project (canal mode requires `--canals` flag and explicit setup)

## Expected Outcome

- One task branch
- One pull request
- One task result update that includes the PR URL

## Worktree Mode

If you are running in a **worktrunk worktree**, you are already on the correct branch in an isolated directory. **Skip branch creation and pre-flight sync** — go directly to implementation.

## Pre-flight Sync (non-worktree mode only)

If NOT in a worktrunk worktree, sync before creating your task branch:

1. Stash any uncommitted changes (if any):
   ```bash
   git stash push -m "steerdev-preflight" 2>/dev/null || true
   ```

2. Switch to the default branch and pull latest:
   ```bash
   git checkout main && git pull origin main --ff-only
   ```
   If `main` doesn't exist, try `master`. If `--ff-only` fails (local main diverged), force-reset:
   ```bash
   git fetch origin && git reset --hard origin/main
   ```

3. Now proceed to create your task branch from the up-to-date default branch.

**Why:** The agent may still be on a previous task's branch. Without this step, new branches are created from stale code, causing desync with merged PRs.

## Workflow

1. Ensure the task is already marked `started`
2. Create or switch to the task branch (skip if in a worktrunk worktree):

```bash
steerdev git branch TASK_ID [--name NAME]
```

This fetches the task from the API and builds the branch name automatically:
- If the task has an external ticket ID (e.g. Linear `PROJ-123`): `task/PROJ-123-<slug-from-title>`
- If no external ID exists: `task/<short-uuid>-<slug-from-title>`
- Use `--name` to override the auto-generated slug

3. Implement the requested changes
4. Commit with a conventional commit message that explains why the change exists
5. Push the current branch:

```bash
git push -u origin HEAD
```

6. Create the pull request:

```bash
steerdev git pr --title "TITLE" --task-id TASK_ID [--body "BODY"]
```

7. Update the task result with the PR URL
8. Log completion in the root `docs/` progress files

## Branch Naming Convention

Branch names should link to the external ticket tracker (e.g. Linear) for traceability on GitHub:

| Has External ID? | Format | Example |
|---|---|---|
| Yes | `task/<TICKET-ID>-<slug>` | `task/PROJ-123-add-user-auth` |
| No  | `task/<short-uuid>-<slug>` | `task/abc12345-add-user-auth` |

**Why this matters:** GitHub integrations (Linear, Jira, etc.) match ticket IDs in branch names to link PRs/branches back to issues. Using internal UUIDs breaks this linkage.

## Conventions

- Always use `steerdev git branch` to create branches (it resolves the external ticket ID automatically)
- Create exactly one PR for the task
- Include the PR URL in the task result summary

## Example

```bash
steerdev tasks update abc12345... --status started
steerdev git branch abc12345...
# → Creates: task/PROJ-123-add-user-authentication (if Linear ID exists)
# → Creates: task/abc12345-add-user-authentication (fallback)
# ... implement changes ...
git add .
git commit -m "feat: add user authentication"
git push -u origin HEAD
steerdev git pr --title "PROJ-123: Add user authentication" --task-id abc12345...
steerdev tasks update abc12345... --result "PR: https://github.com/org/repo/pull/42"
```
