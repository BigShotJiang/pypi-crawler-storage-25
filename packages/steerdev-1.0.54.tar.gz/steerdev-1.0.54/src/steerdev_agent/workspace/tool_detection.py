"""Detect installed CLI tools available for workspace agents."""

from __future__ import annotations

import shutil


def detect_installed_tools() -> list[str]:
    """Detect which AI coding tools are installed on this machine.

    Returns:
        List of tool names that are available (e.g., ["claude", "codex"]).
    """
    tools = [
        ("claude", "claude"),
        ("codex", "codex"),
        ("gemini_cli", "gemini"),
        ("aider", "aider"),
    ]
    return [name for name, cmd in tools if shutil.which(cmd)]
