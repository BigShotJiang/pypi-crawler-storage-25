"""Project manager for workspace agents.

Handles auto-setup of assigned projects by wrapping existing
`steerdev setup` primitives (ClaudeSetup, check_and_clone_repos).
No new setup logic — just orchestration.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from steerdev_agent.api.agents import AgentsClient, BootstrapBundle, ProjectAssignment
    from steerdev_agent.setup.claude_setup import ClaudeSetup


class ProjectManager:
    """Manages local project directories for a workspace agent.

    Syncs project assignments from the platform, clones repos, and
    configures projects using the existing ClaudeSetup primitives.
    """

    def __init__(
        self,
        workspace_dir: Path,
        api_client: AgentsClient,
        agent_id: str,
        api_key: str | None = None,
    ) -> None:
        self.workspace_dir = workspace_dir
        self.api_client = api_client
        self.agent_id = agent_id
        self.api_key = api_key
        # Cache: project_id -> local path
        self._path_cache: dict[str, Path] = {}

    async def sync_projects(self, assignments: list[ProjectAssignment]) -> None:
        """Check each assigned project, set up if missing."""
        for assignment in assignments:
            # Use cached or assignment-provided path
            local_path = self._resolve_path(assignment)
            if local_path and local_path.is_dir():
                self._path_cache[assignment.project_id] = local_path
                continue

            # Project not found locally — bootstrap it
            try:
                path = await self.setup_project(assignment)
                if path:
                    self._path_cache[assignment.project_id] = path
            except Exception:
                logger.exception(f"Failed to setup project {assignment.project_id}")

    async def setup_project(self, assignment: ProjectAssignment) -> Path | None:
        """Bootstrap a project using existing setup primitives.

        1. Fetch bootstrap bundle from API
        2. Clone repos via check_and_clone_repos()
        3. Configure via ClaudeSetup
        4. Update assignment with local_path
        """
        bundle = await self.api_client.get_bootstrap(self.agent_id, assignment.project_id)
        if not bundle:
            logger.error(f"No bootstrap bundle for project {assignment.project_id}")
            return None

        project_name = bundle.project.get("name", assignment.project_id[:8])
        project_dir = self.workspace_dir / project_name
        project_dir.mkdir(parents=True, exist_ok=True)

        # 1. Clone repos — reuse check_and_clone_repos() from repo_setup.py
        if bundle.repositories:
            self._clone_repos(project_dir, bundle)

        # 2. Run setup — reuse ClaudeSetup from claude_setup.py
        self._run_setup(
            project_dir,
            bundle,
            project_id=assignment.project_id,
        )

        # 3. Update assignment with local_path via API
        await self.api_client.update_assignment(
            self.agent_id,
            assignment.project_id,
            local_path=str(project_dir),
        )

        logger.info(f"Project {project_name} set up at {project_dir}")
        return project_dir

    def get_project_path(self, project_id: str) -> Path | None:
        """Get the local path for a project, or None if not set up."""
        return self._path_cache.get(project_id)

    def _resolve_path(self, assignment: ProjectAssignment) -> Path | None:
        """Resolve local path from cache or assignment data."""
        # Check cache first
        if assignment.project_id in self._path_cache:
            return self._path_cache[assignment.project_id]

        # Check assignment's stored local_path
        if assignment.local_path:
            path = Path(assignment.local_path)
            if path.is_dir():
                return path

        # Scan workspace for matching directory
        if self.workspace_dir.is_dir():
            for child in self.workspace_dir.iterdir():
                if child.is_dir() and (child / ".env").exists():
                    # Check if .env contains this project_id
                    try:
                        env_content = (child / ".env").read_text()
                        if assignment.project_id in env_content:
                            return child
                    except OSError:
                        continue

        return None

    def _clone_repos(self, project_dir: Path, bundle: BootstrapBundle) -> None:
        """Clone repositories using existing repo_setup primitives."""
        from steerdev_agent.setup.repo_setup import check_and_clone_repos

        check_and_clone_repos(
            workspace_dir=project_dir,
            repositories=bundle.repositories,
            interactive=False,
            clone_all=True,
        )

    def _run_setup(
        self,
        project_dir: Path,
        bundle: BootstrapBundle,
        project_id: str,
    ) -> None:
        """Configure project using existing ClaudeSetup primitives."""
        from steerdev_agent.setup.claude_setup import ClaudeSetup

        setup = ClaudeSetup(project_dir, install_target="project")

        # .env with project_id and api_key
        setup.setup_env(
            project_id=project_id,
            api_key=self.api_key,
        )

        # .claude/settings.json with permissions and hooks
        setup.setup_settings(force=False, include_hooks=True)

        # .claude/skills/
        setup.setup_skills(force=False)

        # CLAUDE.md task management section
        setup.update_claude_md(force=False)

        # steerdev.yaml
        setup.setup_steerdev_config(force=False)

        # Platform configs (system prompts, skills, MCPs, env vars)
        if bundle.agent_configs:
            self._apply_platform_configs(setup, bundle)

    def _apply_platform_configs(self, setup: ClaudeSetup, bundle: BootstrapBundle) -> None:
        """Apply platform-synced configs if available."""
        from steerdev_agent.config.platform import PlatformConfig

        try:
            config = PlatformConfig.from_api_response(bundle.agent_configs)
            setup.apply_platform_configs(config)
        except Exception:
            logger.warning("Failed to apply platform configs", exc_info=True)
