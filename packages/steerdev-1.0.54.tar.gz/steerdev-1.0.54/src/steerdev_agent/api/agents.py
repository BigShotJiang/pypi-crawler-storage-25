"""Agent registration API client."""

from __future__ import annotations

from typing import Any, Self

import httpx
from loguru import logger
from pydantic import BaseModel, Field

from steerdev_agent.api.client import get_api_endpoint, get_api_key


class AgentRegisterRequest(BaseModel):
    """Request model for registering an agent."""

    name: str = Field(description="Agent name for identification")
    application: str | None = Field(default=None, description="Application type (e.g., claude)")
    hostname: str | None = Field(default=None, description="Hostname where agent is running")


class AgentResponse(BaseModel):
    """Response model for agent data."""

    id: str
    project_id: str | None = None
    name: str | None = None
    application: str | None = None
    hostname: str | None = None
    status: str
    last_heartbeat_at: str | None = None
    created_at: str
    updated_at: str
    kind: str | None = None
    user_id: str | None = None
    organization_id: str | None = None
    workspace_path: str | None = None
    capabilities: dict | None = None


class ProjectAssignment(BaseModel):
    """Project assignment for a workspace agent."""

    agent_id: str
    project_id: str
    local_path: str | None = None
    default_branch: str | None = None
    repo_full_name: str | None = None
    preferred_tool: str | None = None
    is_active: bool = True
    updated_at: str | None = None


class BootstrapBundle(BaseModel):
    """Bootstrap data for setting up a project locally."""

    project: dict = Field(default_factory=dict)
    repositories: list[dict] = Field(default_factory=list)
    agent_configs: dict = Field(default_factory=dict)
    settings: dict = Field(default_factory=dict)


class AgentsClient:
    """Async HTTP client for Agent registration API.

    Allows agents to register themselves and get their agent_id.
    """

    def __init__(self, api_key: str | None = None, timeout: float = 30.0) -> None:
        """Initialize the client.

        Args:
            api_key: API key for authentication. If not provided, reads from STEERDEV_API_KEY.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or get_api_key()
        self.api_base = get_api_endpoint()
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> Self:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager."""
        await self.close()

    async def register(self, request: AgentRegisterRequest) -> AgentResponse | None:
        """Register an agent or get existing one.

        This is idempotent - calling with the same name will return the existing agent.

        Args:
            request: Agent registration request with name and optional metadata.

        Returns:
            Agent data including the agent_id, or None on failure.
        """
        client = await self._get_client()
        logger.debug(f"Registering agent '{request.name}' at {self.api_base}/agents")

        try:
            response = await client.post(
                f"{self.api_base}/agents",
                headers=self.headers,
                json=request.model_dump(exclude_none=True),
            )

            if response.status_code in (200, 201):
                data = response.json()
                logger.info(f"Agent registered successfully with ID: {data.get('id')}")
                return AgentResponse(**data)

            logger.error(f"Failed to register agent: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error registering agent: {e}")
            return None

    async def list_agents(self, limit: int = 50, offset: int = 0) -> list[AgentResponse]:
        """List agents for the project.

        Args:
            limit: Maximum number of agents to return.
            offset: Offset for pagination.

        Returns:
            List of agent data.
        """
        client = await self._get_client()

        try:
            response = await client.get(
                f"{self.api_base}/agents",
                headers=self.headers,
                params={"limit": limit, "offset": offset},
            )

            if response.status_code == 200:
                data = response.json()
                return [AgentResponse(**agent) for agent in data.get("agents", [])]

            logger.error(f"Failed to list agents: {response.status_code} - {response.text}")
            return []

        except httpx.RequestError as e:
            logger.error(f"Request error listing agents: {e}")
            return []

    async def register_workspace(
        self,
        name: str,
        application: str | None = None,
        hostname: str | None = None,
        workspace_path: str | None = None,
        capabilities: list[str] | None = None,
    ) -> AgentResponse | None:
        """Register a workspace agent (not project-scoped).

        Args:
            name: Agent name for identification.
            application: Application type (e.g., claude).
            hostname: Hostname where agent is running.
            workspace_path: Path to the workspace directory.
            capabilities: List of agent capabilities.

        Returns:
            Agent data including the agent_id, or None on failure.
        """
        client = await self._get_client()
        payload: dict[str, Any] = {
            "name": name,
            "kind": "workspace",
        }
        if application:
            payload["application"] = application
        if hostname:
            payload["hostname"] = hostname
        if workspace_path:
            payload["workspace_path"] = workspace_path
        if capabilities:
            payload["capabilities"] = capabilities

        try:
            response = await client.post(
                f"{self.api_base}/agents",
                headers=self.headers,
                json=payload,
            )
            if response.status_code in (200, 201):
                return AgentResponse(**response.json())
            logger.error(
                f"Failed to register workspace agent: {response.status_code} - {response.text}"
            )
            return None
        except httpx.RequestError as e:
            logger.error(f"Request error registering workspace agent: {e}")
            return None

    async def get_projects(self, agent_id: str) -> list[ProjectAssignment]:
        """List project assignments for a workspace agent.

        Args:
            agent_id: The agent ID to list projects for.

        Returns:
            List of project assignments.
        """
        client = await self._get_client()
        try:
            response = await client.get(
                f"{self.api_base}/agents/{agent_id}/projects",
                headers=self.headers,
            )
            if response.status_code == 200:
                data = response.json()
                assignments = data.get("assignments", data) if isinstance(data, dict) else data
                if isinstance(assignments, list):
                    return [ProjectAssignment(**a) for a in assignments]
                return []
            logger.error(f"Failed to list projects: {response.status_code} - {response.text}")
            return []
        except httpx.RequestError as e:
            logger.error(f"Request error listing projects: {e}")
            return []

    async def get_bootstrap(self, agent_id: str, project_id: str) -> BootstrapBundle | None:
        """Fetch bootstrap bundle for a project assignment.

        Args:
            agent_id: The agent ID.
            project_id: The project ID to bootstrap.

        Returns:
            Bootstrap bundle data, or None on failure.
        """
        client = await self._get_client()
        try:
            response = await client.get(
                f"{self.api_base}/agents/{agent_id}/projects/{project_id}/bootstrap",
                headers=self.headers,
            )
            if response.status_code == 200:
                return BootstrapBundle(**response.json())
            logger.error(f"Failed to get bootstrap: {response.status_code} - {response.text}")
            return None
        except httpx.RequestError as e:
            logger.error(f"Request error getting bootstrap: {e}")
            return None

    async def update_assignment(
        self,
        agent_id: str,
        project_id: str,
        local_path: str | None = None,
    ) -> bool:
        """Update a project assignment (e.g., set local_path after cloning).

        Args:
            agent_id: The agent ID.
            project_id: The project ID to update.
            local_path: Local filesystem path for the project.

        Returns:
            True if the update succeeded, False otherwise.
        """
        client = await self._get_client()
        payload: dict[str, Any] = {}
        if local_path is not None:
            payload["local_path"] = local_path
        if not payload:
            return True

        try:
            response = await client.patch(
                f"{self.api_base}/agents/{agent_id}/projects/{project_id}",
                headers=self.headers,
                json=payload,
            )
            return response.status_code == 200
        except httpx.RequestError as e:
            logger.error(f"Request error updating assignment: {e}")
            return False
