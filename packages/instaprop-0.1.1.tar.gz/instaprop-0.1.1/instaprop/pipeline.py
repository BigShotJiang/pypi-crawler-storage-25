"""
Pipeline orchestrator: wire writer agent and review panel into
best-of-N revision loop.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from rich.console import Console
from rich.rule import Rule

from .config import Config
from .agents.brief_refiner import BriefRefiner
from .agents.writer import WriterAgent
from .agents.aggregator import CritiqueAggregator
from .reviewers.panel import ReviewPanel
from .rubric import RubricScorecard, aggregate, scorecard_to_dict, format_scorecard_md, tier_label


@dataclass
class PipelineResult:
    best_draft: str
    best_round: int
    completed_rounds: int
    round_scores: list[float]          # avg overall per round (1-4 scale)
    scorecard: dict                    # full JSON-serialisable scorecard
    revision_log: str
    rubric_scorecards: list[RubricScorecard]  # one per round
    converged: bool
    converged_round: int | None


def _tier_color(tier: str) -> str:
    return {
        "Highly competitive": "green",
        "Competitive":        "blue",
        "Low competitive":    "yellow",
        "Not recommended":    "red",
    }.get(tier, "white")


def _solicitation_label(cfg: Config) -> str:
    if cfg.solicitation_path is not None:
        return cfg.solicitation_path.name
    if cfg.solicitation_pdf is not None:
        return cfg.solicitation_pdf.name
    if cfg.solicitation_url:
        return cfg.solicitation_id or cfg.solicitation_title or cfg.solicitation_url
    return "unknown"


def _meets_stop_conditions(cfg: Config, rubric_sc: RubricScorecard) -> bool:
    if cfg.target_score is None and not cfg.stop_on_no_fatal_flags:
        return False
    if cfg.target_score is not None and rubric_sc.overall_score < cfg.target_score:
        return False
    if cfg.stop_on_no_fatal_flags and rubric_sc.fatal_criteria:
        return False
    return True


def run_pipeline(cfg: Config, console: Console) -> PipelineResult:
    """Execute the full instaprop pipeline and return the best draft."""

    cfg.load_inputs()

    writer    = WriterAgent(cfg)
    brief_refiner = BriefRefiner(cfg)
    panel     = ReviewPanel(cfg)
    aggregator = CritiqueAggregator(cfg)

    drafts:               list[str]              = []
    round_scores:         list[float]            = []
    all_round_data:       list[dict]             = []
    rubric_scorecards:    list[RubricScorecard]  = []
    revision_log_parts:   list[str]              = []

    current_draft:  str | None = None
    prior_critique: str | None = None
    effective_max_rounds = cfg.max_rounds or cfg.rounds
    converged = False
    converged_round: int | None = None

    for round_num in range(1, effective_max_rounds + 1):
        console.print(Rule(f"[bold]Round {round_num} / {effective_max_rounds}[/bold]", style="dim"))

        # ── Step 1: Write ──────────────────────────────────────────────
        console.print("[dim]  Writer agent drafting...[/dim]")
        t0 = time.time()
        current_draft = writer.draft(
            round_num=round_num,
            prior_draft=current_draft,
            prior_critique=prior_critique,
        )
        elapsed = time.time() - t0
        console.print(
            f"  [green]✓[/green] Draft complete "
            f"({elapsed:.1f}s, ~{len(current_draft.split()):,} words)"
        )

        if cfg.verbose:
            console.print(Rule("draft preview", style="dim"))
            console.print(current_draft[:800] + "\n[dim]…[/dim]")

        # ── Step 2: Panel review ───────────────────────────────────────
        console.print("[dim]  Review panel reading...[/dim]")
        t0 = time.time()
        reviews = panel.review(current_draft)
        elapsed = time.time() - t0

        avg_overall = sum(r["overall"] for r in reviews) / len(reviews)
        tier = tier_label(avg_overall)
        color = _tier_color(tier)
        fatal_count = sum(1 for r in reviews if r.get("fatal_flags"))

        console.print(
            f"  [green]✓[/green] Panel done ({elapsed:.1f}s) · "
            f"[bold]{avg_overall:.2f}[/bold]/4 · "
            f"[{color}]{tier}[/{color}]"
            + (f" · [red]{fatal_count} fatal flag(s)[/red]" if fatal_count else "")
        )

        if cfg.verbose:
            for r in reviews:
                flags = " [red]⚑[/red]" if r.get("fatal_flags") else ""
                console.print(
                    f"    [dim]{r['reviewer']:30s}[/dim] "
                    f"[bold]{r['overall']}[/bold]/4  "
                    f"[dim]{r.get('tier','')}[/dim]{flags}"
                )

        # ── Step 3: Rubric aggregation ─────────────────────────────────
        console.print("[dim]  Computing rubric scorecard...[/dim]")
        rubric_sc = aggregate(reviews, round_num=round_num)
        rubric_scorecards.append(rubric_sc)

        if cfg.verbose:
            for section_id, ss in rubric_sc.sections.items():
                if ss.criteria_scores:
                    console.print(
                        f"    [dim]{ss.label:25s}[/dim] "
                        f"{ss.section_avg:.2f}  (weight {ss.weight:.0%})"
                    )
            if rubric_sc.fatal_criteria:
                console.print(
                    f"    [red]fatal:[/red] "
                    f"{', '.join(rubric_sc.fatal_criteria)}"
                )
            if rubric_sc.unscored_criteria:
                console.print(
                    f"    [dim]unscored: "
                    f"{', '.join(rubric_sc.unscored_criteria)}[/dim]"
                )

        # ── Step 4: Aggregate critique ─────────────────────────────────
        console.print("[dim]  Panel discussion + revision brief...[/dim]")
        t0 = time.time()
        prior_critique = aggregator.synthesize(
            reviews, round_num=round_num, scorecard=rubric_sc
        )
        elapsed = time.time() - t0
        console.print(f"  [green]✓[/green] Brief ready ({elapsed:.1f}s)")

        if cfg.verbose:
            console.print(Rule("revision brief", style="dim"))
            console.print(prior_critique[:600] + "\n[dim]…[/dim]")

        # ── Store round data ───────────────────────────────────────────
        drafts.append(current_draft)
        round_scores.append(avg_overall)
        all_round_data.append({
            "round":   round_num,
            "reviews": reviews,
            "avg":     avg_overall,
            "tier":    tier,
            "rubric":  scorecard_to_dict(rubric_sc),
        })

        revision_log_parts.append(
            f"## Round {round_num}\n\n"
            f"**Avg overall:** {avg_overall:.2f} / 4  ·  **{tier}**\n\n"
            + format_scorecard_md(rubric_sc)
            + f"\n\n**Revision brief:**\n\n{prior_critique}\n\n---\n"
        )

        if cfg.evolve_brief and round_num < effective_max_rounds:
            console.print("[dim]  Updating contribution brief for next round...[/dim]")
            cfg.contributions_text = brief_refiner.refine(
                cfg.contributions_text,
                prior_critique,
                round_num,
            ).strip()
            if cfg.verbose:
                console.print(Rule("updated contribution brief", style="dim"))
                console.print(cfg.contributions_text[:700] + "\n[dim]…[/dim]")

        if _meets_stop_conditions(cfg, rubric_sc):
            converged = True
            converged_round = round_num
            console.print(
                f"  [green]✓[/green] Stop criteria met after round {round_num}"
            )
            break

    # ── Select best round ──────────────────────────────────────────────
    best_idx    = round_scores.index(max(round_scores))
    best_round  = best_idx + 1
    best_draft  = drafts[best_idx]
    best_sc     = rubric_scorecards[best_idx]

    color = _tier_color(best_sc.overall_tier)
    console.print(
        f"\n[green]★[/green] Best draft: round [bold]{best_round}[/bold]  "
        f"[bold]{best_sc.overall_score:.2f}[/bold]/4  "
        f"[{color}]{best_sc.overall_tier}[/{color}]"
    )

    solicitation_label = _solicitation_label(cfg)

    scorecard = {
        "model":           cfg.model,
        "solicitation":    solicitation_label,
        "rounds":          all_round_data,
        "best_round":      best_round,
        "best_score":      best_sc.overall_score,
        "best_tier":       best_sc.overall_tier,
        "best_rubric":     scorecard_to_dict(best_sc),
        "completed_rounds": len(round_scores),
        "target_score":     cfg.target_score,
        "max_rounds":       effective_max_rounds,
        "stop_on_no_fatal_flags": cfg.stop_on_no_fatal_flags,
        "evolve_brief":      cfg.evolve_brief,
        "converged":        converged,
        "converged_round":  converged_round,
    }

    revision_log = (
        f"# instaprop revision log\n\n"
        f"**Solicitation:** `{solicitation_label}`  \n"
        f"**Model:** {cfg.model}  \n"
        f"**Rounds completed:** {len(round_scores)} / {effective_max_rounds}  \n"
        + (
            f"**Target score:** {cfg.target_score:.2f} / 4  \n"
            if cfg.target_score is not None
            else ""
        )
        + (
            f"**Stop on no fatal flags:** {'yes' if cfg.stop_on_no_fatal_flags else 'no'}  \n"
            if cfg.target_score is not None or cfg.stop_on_no_fatal_flags
            else ""
        )
        + (
            f"**Converged:** yes (round {converged_round})  \n\n"
            if converged_round is not None
            else "\n"
        )
        + "\n".join(revision_log_parts)
    )

    return PipelineResult(
        best_draft=best_draft,
        best_round=best_round,
        completed_rounds=len(round_scores),
        round_scores=round_scores,
        scorecard=scorecard,
        revision_log=revision_log,
        rubric_scorecards=rubric_scorecards,
        converged=converged,
        converged_round=converged_round,
    )
