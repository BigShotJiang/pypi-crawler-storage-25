"""Shared LLM client helpers for OpenAI and Anthropic backends."""

from __future__ import annotations


def resolve_provider(model: str, provider: str | None = None) -> str:
    """Resolve the backend provider from an explicit provider or model name."""
    choice = (provider or "auto").strip().lower()
    if choice in {"openai", "anthropic"}:
        return choice
    if model.startswith("claude-"):
        return "anthropic"
    return "openai"


def generate_text(
    *,
    model: str,
    instructions: str,
    prompt: str,
    max_tokens: int,
    provider: str | None = None,
) -> str:
    """Generate text from the selected provider."""
    resolved = resolve_provider(model, provider)

    if resolved == "anthropic":
        import anthropic

        client = anthropic.Anthropic()
        response = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=instructions,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    from openai import OpenAI

    client = OpenAI()
    response = client.responses.create(
        model=model,
        max_output_tokens=max_tokens,
        instructions=instructions,
        input=prompt,
    )
    return response.output_text or ""
