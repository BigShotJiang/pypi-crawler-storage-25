"""
Configuration dataclass passed through the full pipeline.

Solicitation input accepts three forms:
  1. NSF.gov URL  (--solicitation URL)       → fetcher.py
  2. PDF file     (--solicitation-pdf PATH)  → pdf_reader.py
  3. Text file    (--solicitation-file PATH) → read directly
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Config:
    # Solicitation source — exactly one must be set
    solicitation_url:  str | None  = None   # NSF.gov URL
    solicitation_pdf:  Path | None = None   # local PDF
    solicitation_path: Path | None = None   # plain text file

    contributions_path: Path | None = None

    output_path: Path = field(default_factory=lambda: Path("draft.md"))

    rounds: int = 3
    provider: str = "anthropic"
    model: str = "claude-opus-4-5"
    extraction_provider: str = "anthropic"
    extraction_model: str = "claude-haiku-4-5-20251001"  # used for PDF extraction
    pages: int = 5
    verbose: bool = False
    emit_scorecard: bool = True
    emit_log: bool = True
    target_score: float | None = None
    max_rounds: int | None = None
    stop_on_no_fatal_flags: bool = False
    evolve_brief: bool = False

    # Derived at runtime — not set by user
    solicitation_text:  str = field(default="", init=False)
    contributions_text: str = field(default="", init=False)
    solicitation_title: str = field(default="", init=False)
    solicitation_id:    str = field(default="", init=False)

    def load_inputs(self):
        """
        Load solicitation text (from URL, PDF, or file) and contributions.
        Populates solicitation_text, solicitation_title, solicitation_id.
        """
        if self.contributions_path:
            self.contributions_text = self.contributions_path.read_text(
                encoding="utf-8", errors="replace"
            )

        sources = [
            self.solicitation_url,
            self.solicitation_pdf,
            self.solicitation_path,
        ]
        if not any(sources):
            raise ValueError(
                "Provide one of: --solicitation URL, "
                "--solicitation-pdf PATH, or --solicitation-file PATH"
            )

        if self.solicitation_url:
            self._load_from_url()
        elif self.solicitation_pdf:
            self._load_from_pdf()
        else:
            self.solicitation_text = self.solicitation_path.read_text(
                encoding="utf-8", errors="replace"
            )

    def _load_from_url(self):
        from .fetcher import fetch_solicitation, format_for_writer
        data = fetch_solicitation(self.solicitation_url)
        self.solicitation_text = format_for_writer(data)
        self.solicitation_title = data.title
        self.solicitation_id = data.solicitation_id

    def _load_from_pdf(self):
        from .pdf_reader import read_pdf_solicitation, pdf_page_count
        from .fetcher import format_for_writer
        n = pdf_page_count(self.solicitation_pdf)
        if n:
            # page count available before extraction — useful for CLI progress
            self._pdf_page_count = n
        data = read_pdf_solicitation(
            self.solicitation_pdf,
            provider=self.extraction_provider,
            model=self.extraction_model,
        )
        self.solicitation_text = format_for_writer(data)
        self.solicitation_title = data.title
        self.solicitation_id = data.solicitation_id
