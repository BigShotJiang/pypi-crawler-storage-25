"""
Review panel: runs all five reviewer personas concurrently and
returns structured critique dicts.
"""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..config import Config
from ..llm import generate_text
from ..prompts.reviewer_prompts import REVIEWER_PERSONAS, build_reviewer_prompt


class ReviewPanel:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def review(self, draft: str) -> list[dict]:
        """Run all reviewers concurrently. Returns list of review dicts."""

        def _review_one(persona: dict) -> dict:
            system_prompt, user_prompt = build_reviewer_prompt(
                persona, draft, self.cfg
            )
            raw = generate_text(
                model=self.cfg.model,
                instructions=system_prompt,
                prompt=user_prompt,
                max_tokens=1024,
                provider=self.cfg.provider,
            )
            return _parse_review(raw, persona["display_name"])

        reviews = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {
                executor.submit(_review_one, persona): persona
                for persona in REVIEWER_PERSONAS
            }
            for future in as_completed(futures):
                reviews.append(future.result())

        # Sort to canonical order for reproducibility
        order = [p["display_name"] for p in REVIEWER_PERSONAS]
        reviews.sort(key=lambda r: order.index(r["reviewer"]) if r["reviewer"] in order else 99)
        return reviews


def _parse_review(raw: str, reviewer_name: str) -> dict:
    """
    Parse reviewer JSON output. Falls back gracefully if the model
    returns malformed JSON.
    """
    text = raw.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])
    # Strip trailing commas before closing braces/brackets (common LLM error)
    import re
    text = re.sub(r",\s*([}\]])", r"\1", text)

    try:
        data = json.loads(text)
        data["reviewer"] = reviewer_name
        # Normalise: ensure expected keys exist
        data.setdefault("overall", 2)
        data.setdefault("tier", "Low competitive")
        data.setdefault("criteria", {})
        data.setdefault("strengths", "")
        data.setdefault("concerns", "")
        data.setdefault("fatal_flags", [])
        data.setdefault("top_fix", "")
        data.setdefault("panel_statement", "")
        return data
    except json.JSONDecodeError:
        # Graceful fallback — extract overall score heuristically
        score_match = re.search(r'"?overall"?\s*[:\-]\s*([1-4])', raw)
        score = int(score_match.group(1)) if score_match else 2
        tier_map = {1: "Not recommended", 2: "Low competitive",
                    3: "Competitive", 4: "Highly competitive"}
        return {
            "reviewer": reviewer_name,
            "overall": score,
            "tier": tier_map.get(score, "Low competitive"),
            "criteria": {},
            "strengths": "Could not parse structured review.",
            "concerns": "Could not parse structured review.",
            "fatal_flags": [],
            "top_fix": raw[:200],
            "panel_statement": "",
            "_raw": raw,
        }
