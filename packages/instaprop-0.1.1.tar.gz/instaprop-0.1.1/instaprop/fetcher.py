"""
NSF solicitation fetcher.

Handles the canonical NSF solicitation URL pattern:
  https://www.nsf.gov/funding/opportunities/<slug>/<nsf-id>/solicitation

Also accepts the opportunity landing page:
  https://www.nsf.gov/funding/opportunities/<slug>
and auto-follows the solicitation link embedded in that page.

Based on direct inspection of real NSF solicitation pages (nsf26-501, nsf24-539).
Uses only stdlib — no beautifulsoup, no lxml, no httpx required.
"""

from __future__ import annotations

import re
import urllib.request
import urllib.error
from dataclasses import dataclass, field


# ── Data model ─────────────────────────────────────────────────────────────────

@dataclass
class SolicitationData:
    """Structured content extracted from an NSF solicitation page."""

    # Identity
    url: str                        # original URL supplied by user
    solicitation_id: str            # e.g. "NSF 26-501"
    title: str                      # full program title from <h1>
    program_title: str              # from "Program Title:" field

    # Core content (used by writer agent and reviewer prompts)
    synopsis: str                   # Synopsis of Program paragraph(s)
    program_description: str        # Section II full text
    priority_areas: list[str]       # explicit priority bullet points
    review_criteria: str            # Section VI.A including solicitation-specific criteria
    additional_review_criteria: str # "Additional Solicitation Specific Review Criteria"
    award_info: str                 # award type, count, amount, duration
    eligibility: str                # who may submit / PI limits
    tracks: list[dict]              # named submission tracks with descriptions
    deadlines: str                  # all due dates (LOI + full proposal)
    program_contacts: str           # name, email for program officers

    # Provenance
    solicitation_url: str           # URL of the solicitation doc fetched
    opportunity_url: str            # URL of the opportunity landing page

    # Raw fallback (first 15k chars of stripped text)
    raw_text: str = field(default="", repr=False)


# ── URL detection ──────────────────────────────────────────────────────────────

# Solicitation:  .../opportunities/<slug>/<nsf-id>/solicitation
_SOL_RE = re.compile(
    r"https?://(?:www\.)?nsf\.gov"
    r"/funding/opportunities/([^/\s?#]+)/([^/\s?#]+)/solicitation",
    re.I,
)

# Opportunity landing page: .../opportunities/<slug>  (no further path segments)
_OPP_RE = re.compile(
    r"https?://(?:www\.)?nsf\.gov"
    r"/funding/opportunities/([^/\s?#]+)/?$",
    re.I,
)


def _url_type(url: str) -> str:
    if _SOL_RE.search(url):
        return "solicitation"
    if _OPP_RE.match(url):
        return "opportunity"
    return "unknown"


def _normalise(url: str) -> str:
    url = url.strip().rstrip("/")
    if not url.startswith("http"):
        url = "https://" + url
    return url


# ── HTTP fetch ─────────────────────────────────────────────────────────────────

_UA = (
    "Mozilla/5.0 (compatible; instaprop/0.1; "
    "+https://github.com/kavasserirocks/instaprop)"
)


def _fetch_html(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "text/html"})
    with urllib.request.urlopen(req, timeout=20) as r:
        charset = "utf-8"
        m = re.search(r"charset=([^\s;]+)", r.headers.get("Content-Type", ""))
        if m:
            charset = m.group(1)
        return r.read().decode(charset, errors="replace")


# ── HTML → clean text ──────────────────────────────────────────────────────────

def _to_text(html: str) -> str:
    """
    Convert HTML to clean plain text.
    Preserves logical line breaks; strips all tags.
    """
    # Drop script/style entirely
    html = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", html, flags=re.S | re.I)
    # Block-level tags → newline
    html = re.sub(r"</?(?:p|div|section|article|h[1-6]|li|tr|br|blockquote)[^>]*>",
                  "\n", html, flags=re.I)
    # All remaining tags → nothing
    html = re.sub(r"<[^>]+>", "", html)
    # Entity decode
    for ent, ch in [
        ("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
        ("&nbsp;", " "), ("&#39;", "'"), ("&quot;", '"'),
        ("&#8212;", "—"), ("&#8211;", "–"), ("&#8220;", '"'), ("&#8221;", '"'),
    ]:
        html = html.replace(ent, ch)
    # Normalise whitespace per-line; drop blank runs
    lines = []
    for ln in html.splitlines():
        ln = ln.strip()
        if ln:
            lines.append(ln)
    return "\n".join(lines)


# ── Section extraction helpers ─────────────────────────────────────────────────

def _between(text: str, start: str, *ends: str, max_chars: int = 6000) -> str:
    """
    Extract text between `start` marker and first matching `end` marker.
    Case-insensitive. Returns empty string if start not found.
    """
    lo = text.lower()
    s = lo.find(start.lower())
    if s == -1:
        return ""
    s += len(start)
    best = len(text)
    for end in ends:
        e = lo.find(end.lower(), s)
        if e != -1 and e < best:
            best = e
    return text[s:best].strip()[:max_chars]


def _find_sol_link(html: str) -> str | None:
    """
    Find the /solicitation link on an opportunity landing page.
    NSF embeds it as href=".../<nsf-id>/solicitation" or full URL.
    """
    patterns = [
        r'href="(https?://(?:www\.)?nsf\.gov/funding/opportunities/[^"]+/[^"]+/solicitation)"',
        r'href="(/funding/opportunities/[^"]+/[^"]+/solicitation)"',
    ]
    for pat in patterns:
        m = re.search(pat, html, re.I)
        if m:
            link = m.group(1)
            if not link.startswith("http"):
                link = "https://www.nsf.gov" + link
            return link
    return None


# ── Field extractors (grounded in real page structure) ────────────────────────

def _extract_title(html: str) -> str:
    m = re.search(r"<h1[^>]*>(.*?)</h1>", html, re.S | re.I)
    if m:
        return re.sub(r"<[^>]+>", "", m.group(1)).strip()
    return ""


def _extract_solicitation_id(text: str) -> str:
    # "NSF 26-501:" or "NSF 24-539" anywhere in first 500 chars
    m = re.search(r"NSF\s+(\d{2}-\d{3,4})", text[:2000])
    return f"NSF {m.group(1)}" if m else ""


def _extract_program_title(text: str) -> str:
    # "Program Title:\n> Some Title" or "Program Title:\nSome Title"
    m = re.search(r"Program Title:\s*>?\s*(.+)", text)
    return m.group(1).strip() if m else ""


def _extract_synopsis(text: str) -> str:
    """
    NSF synopsis appears after "Synopsis of Program:" (sometimes "> " prefixed).
    Ends at "Cognizant Program Officer" or "Expanding Participation" or similar.
    """
    block = _between(
        text, "Synopsis of Program:",
        "Cognizant Program Officer",
        "Expanding Participation",
        "NSF Priorities",
        max_chars=3000,
    )
    # Clean leading "> " quote markers
    lines = [ln.lstrip("> ").strip() for ln in block.splitlines() if ln.strip()]
    return "\n".join(lines)


def _extract_program_description(text: str) -> str:
    return _between(
        text,
        "II. Program Description",
        "III. Award Information",
        max_chars=8000,
    ) or _between(
        text,
        "Program Description",
        "Award Information",
        max_chars=8000,
    )


def _extract_deadlines(text: str) -> str:
    """
    Extract all deadline information. NSF pages list:
      - Letter of Intent Due Date (if required)
      - Full Proposal Deadline(s)
    Capture all of them.
    """
    lines = []
    # LOI deadline
    m = re.search(
        r"Letter of Intent Due Date[^:]*:?\s*\*?\s*"
        r"((?:\(required\)[^:]*:?\s*)?([\w\s,]+\d{4}|Proposals Accepted Anytime))",
        text, re.I
    )
    if m:
        lines.append(f"LOI deadline: {m.group(2).strip()}")

    # Full proposal deadlines — may appear multiple times for phased programs
    for m in re.finditer(
        r"Full Proposal Deadline[^:]*:\s*(?:\(due[^)]+\))?\s*\n?\s*"
        r"([\w\s,]+\d{4}|Proposals Accepted Anytime)",
        text, re.I
    ):
        date = m.group(1).strip()
        if date and date not in "\n".join(lines):
            lines.append(f"Full proposal: {date}")

    if not lines:
        # Fallback: grab anything that looks like a date near "deadline"
        m = re.search(
            r"(?:deadline|due date)[^\n]*\n\s*([A-Z][a-z]+ \d{1,2},\s*\d{4}|Proposals Accepted Anytime)",
            text, re.I
        )
        if m:
            lines.append(m.group(1).strip())

    return "\n".join(lines) if lines else "See solicitation for deadlines."


def _extract_award_info(text: str) -> str:
    block = _between(
        text, "III. Award Information",
        "IV. Eligibility Information",
        max_chars=800,
    ) or _between(
        text, "Award Information",
        "Eligibility Information",
        max_chars=800,
    )
    return block


def _extract_eligibility(text: str) -> str:
    return _between(
        text, "IV. Eligibility Information",
        "V. Proposal Preparation",
        max_chars=1200,
    ) or _between(
        text, "Eligibility Information",
        "Proposal Preparation",
        max_chars=1200,
    )


def _extract_review_criteria(text: str) -> str:
    """Extract both the standard merit criteria and solicitation-specific criteria."""
    block = _between(
        text,
        "A. Merit Review Principles and Criteria",
        "B. Review and Selection Process",
        max_chars=4000,
    ) or _between(
        text,
        "Merit Review Principles and Criteria",
        "Review and Selection Process",
        max_chars=4000,
    )
    return block


def _extract_additional_criteria(text: str) -> str:
    """Extract the 'Additional Solicitation Specific Review Criteria' block."""
    return _between(
        text,
        "Additional Solicitation Specific Review Criteria",
        "B. Review and Selection Process",
        "Review and Selection Process",
        max_chars=3000,
    )


def _extract_contacts(text: str) -> str:
    block = _between(
        text,
        "VIII. Agency Contacts",
        "IX. Other Information",
        max_chars=600,
    ) or _between(
        text,
        "Agency Contacts",
        "Other Information",
        max_chars=600,
    )
    # Also try the summary section contacts
    if not block:
        block = _between(
            text, "Cognizant Program Officer",
            "Applicable Catalog",
            max_chars=400,
        )
    return block


def _extract_priority_areas(text: str) -> list[str]:
    """
    Extract explicit priority bullets. NSF uses several patterns:
      1. Bold bullets: * **Theme:** description
      2. Explicit measures: "Proposals should advance one or more of the following"
         followed by either bullet lines or plain lines (from <li>)
      3. Numbered list: (i) ... (ii) ...
    """
    found = []

    # Pattern 1: bold-starred bullets  * **Label:** content
    for m in re.finditer(r"\*\s*\*\*([^*\n]{3,60})\*\*[:\s]+([^\n*]{15,200})", text):
        item = f"{m.group(1).strip()}: {m.group(2).strip()}"
        if item not in found:
            found.append(item)

    # Pattern 2: trigger phrases followed by a list (bullet or plain lines from <li>)
    triggers = [
        "following measures of success",
        "following priority",
        "following criteria",
        "high priority to projects that",
        "all of them place a high priority",
        "advance one or more of the following",
    ]
    lo = text.lower()
    for trigger in triggers:
        pos = lo.find(trigger)
        if pos == -1:
            continue
        # Grab up to 800 chars after the trigger
        block = text[pos + len(trigger): pos + len(trigger) + 800]
        for line in block.splitlines():
            line = line.strip().lstrip("*-–> ").strip()
            # Accept lines of plausible bullet length
            if 10 < len(line) < 200 and not line.startswith("#"):
                if line not in found:
                    found.append(line)
                if len(found) >= 15:
                    return found

    # Pattern 3: (i) / (ii) / (iii) numbered list
    for m in re.finditer(r"\(\s*(?:i{1,3}|iv|v|vi|vii|viii|ix|x)\s*\)\s+([^;()\n]{20,200})", text):
        item = m.group(1).strip().rstrip(";")
        if item and item not in found:
            found.append(item)

    return found[:15]


def _extract_tracks(text: str) -> list[dict]:
    """
    Extract named submission tracks or phases.
    Common patterns: IntBIO, EPSCoR, CAREER, Phase I / Phase II, RAPID, EAGER.
    """
    tracks = []
    seen = set()

    # Explicit phase structure (CAMEL-style)
    for m in re.finditer(
        r"(Phase [I|II]+:\s*[^\n]+)\n(.*?)(?=\nPhase [I|II]+:|\nIII\.|\Z)",
        text, re.S
    ):
        name = m.group(1).strip()[:80]
        desc = m.group(2).strip()[:400]
        if name not in seen:
            seen.add(name)
            tracks.append({"name": name, "description": desc})

    # Named track patterns
    track_names = [
        ("IntBIO", r"Integrative Research in Biology \(IntBIO\).*?(?=\n\n[A-Z*]|\Z)"),
        ("EXPAND EPSCoR", r"EXPAND MCB in EPSCoR.*?(?=\n\n[A-Z*]|\Z)"),
        ("CAREER", r"Faculty Early Career Development.*?(?=\n\n[A-Z*]|\Z)"),
        ("RAPID", r"Grants for Rapid Response.*?(?=\n\n[A-Z*]|\Z)"),
        ("EAGER", r"Early-concept Grants.*?(?=\n\n[A-Z*]|\Z)"),
    ]
    for name, pattern in track_names:
        if name not in seen:
            m = re.search(pattern, text, re.S)
            if m:
                seen.add(name)
                tracks.append({"name": name, "description": m.group(0)[:400].strip()})

    return tracks


# ── Main public API ────────────────────────────────────────────────────────────

def fetch_solicitation(url: str) -> SolicitationData:
    """
    Fetch and parse an NSF solicitation.

    Accepts:
      - Solicitation page URL: .../opportunities/<slug>/<nsf-id>/solicitation
      - Opportunity page URL:  .../opportunities/<slug>
        (auto-follows the embedded solicitation link)

    Returns SolicitationData with all structured fields populated.
    Raises urllib.error.URLError on network failure.
    """
    url = _normalise(url)
    kind = _url_type(url)

    opportunity_url = ""
    solicitation_url = ""

    if kind == "solicitation":
        solicitation_url = url
        sol_html = _fetch_html(url)
        # Derive opportunity URL by stripping /<nsf-id>/solicitation
        m = _SOL_RE.match(url)
        if m:
            opportunity_url = (
                f"https://www.nsf.gov/funding/opportunities/{m.group(1)}"
            )

    elif kind == "opportunity":
        opportunity_url = url
        opp_html = _fetch_html(url)
        sol_link = _find_sol_link(opp_html)
        if sol_link:
            solicitation_url = sol_link
            sol_html = _fetch_html(sol_link)
        else:
            # No solicitation link found — use the opportunity page directly
            solicitation_url = url
            sol_html = opp_html

    else:
        # Unknown pattern — attempt fetch anyway
        solicitation_url = url
        opportunity_url = url
        sol_html = _fetch_html(url)

    # Convert to clean text for extraction
    text = _to_text(sol_html)

    return SolicitationData(
        url=url,
        solicitation_id=_extract_solicitation_id(text),
        title=_extract_title(sol_html),
        program_title=_extract_program_title(text),
        synopsis=_extract_synopsis(text),
        program_description=_extract_program_description(text),
        priority_areas=_extract_priority_areas(text),
        review_criteria=_extract_review_criteria(text),
        additional_review_criteria=_extract_additional_criteria(text),
        award_info=_extract_award_info(text),
        eligibility=_extract_eligibility(text),
        tracks=_extract_tracks(text),
        deadlines=_extract_deadlines(text),
        program_contacts=_extract_contacts(text),
        solicitation_url=solicitation_url,
        opportunity_url=opportunity_url,
        raw_text=text[:15000],
    )


def format_for_writer(data: SolicitationData) -> str:
    """
    Format SolicitationData into a clean, structured text block for the writer agent.
    Ordered to surface the most decision-relevant content first.
    """
    parts = [
        f"# {data.title}",
        f"**Solicitation:** {data.solicitation_id}",
        f"**Program:** {data.program_title}" if data.program_title else "",
        f"**Deadlines:** {data.deadlines}",
        "",
    ]

    if data.synopsis:
        parts += ["## Program synopsis", data.synopsis, ""]

    if data.priority_areas:
        parts += ["## Program priorities"]
        parts += [f"- {p}" for p in data.priority_areas]
        parts += [""]

    if data.program_description:
        parts += ["## Program description", data.program_description[:5000], ""]

    if data.tracks:
        parts += ["## Submission tracks / phases"]
        for t in data.tracks:
            parts += [f"### {t['name']}", t["description"][:400], ""]

    if data.review_criteria:
        parts += ["## Merit review criteria", data.review_criteria[:2500], ""]

    if data.additional_review_criteria:
        parts += [
            "## Solicitation-specific review criteria",
            data.additional_review_criteria[:2000],
            "",
        ]

    if data.award_info:
        parts += ["## Award information", data.award_info, ""]

    if data.eligibility:
        parts += ["## Eligibility", data.eligibility[:600], ""]

    if data.program_contacts:
        parts += ["## Program contacts", data.program_contacts, ""]

    parts += [f"**Source:** {data.solicitation_url}"]

    return "\n".join(p for p in parts if p is not None)
