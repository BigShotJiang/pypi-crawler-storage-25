"""
PDF-based NSF solicitation reader.

Strategy: extract raw text from PDF -> send to an OpenAI model for structured extraction.

This is more robust than HTML regex parsing because:
  - NSF PDF structure is consistent across programs (numbered sections, fixed headers)
  - The model handles layout variations, formatting noise, and edge cases naturally
  - No brittle regex patterns to maintain as NSF redesigns their website

Usage:
    from instaprop.pdf_reader import read_pdf_solicitation
    data = read_pdf_solicitation("nsf26-501.pdf", model="claude-haiku-4-5-20251001")
    # returns SolicitationData — same type as fetch_solicitation()

The model parameter defaults to Claude Haiku (fast + cheap for extraction
tasks). Larger models are usually overkill here — extraction is a
well-structured task.
"""

from __future__ import annotations

import json
from pathlib import Path

from .fetcher import SolicitationData
from .llm import generate_text

# Optional PDF libraries — imported at module level for mockability
try:
    from pypdf import PdfReader as _PdfReader
except ImportError:
    _PdfReader = None  # type: ignore

try:
    import pdfplumber as _pdfplumber
except ImportError:
    _pdfplumber = None


# ── PDF text extraction ────────────────────────────────────────────────────────

def _clean_pdf_text(text: str) -> str:
    """
    Clean up text extracted from a browser-printed NSF PDF.

    Browser "Print to PDF" from NSF.gov produces:
    - Timestamps like "3/24/26, 5:58 AM NSF 26-501: ..."
    - URL footers like "https://www.nsf.gov/funding/..."
    - A table-of-contents block where section headers appear without body text
    - A "Feedback" artifact from the page feedback button

    We strip these so section extractors don't hit TOC entries instead of body text.
    """
    import re

    lines = text.splitlines()
    cleaned = []

    for line in lines:
        stripped = line.strip()

        # Skip URL lines (headers/footers from browser print)
        if re.match(r'https?://', stripped):
            continue

        # Skip timestamp lines like "3/24/26, 5:58 AM NSF 26-501: ..."
        if re.match(r'\d{1,2}/\d{1,2}/\d{2,4},?\s+\d{1,2}:\d{2}\s+[AP]M', stripped):
            continue

        # Skip "F e e dba c k" / "Feedback" button artifact
        if re.match(r'^F\s*e\s*e\s*d\s*b', stripped, re.I):
            continue
        if stripped == "Feedback":
            continue

        # Skip page number lines like "1/11", "2/11" etc.
        if re.match(r'^\d{1,3}/\d{1,3}$', stripped):
            continue

        cleaned.append(line)

    text = "\n".join(cleaned)

    # Remove the TOC block: the section headers that appear in sequence
    # without body text (TOC entries are consecutive heading lines).
    # Strategy: find runs of "Roman numeral. Section Name" lines with no
    # substantive body between them and collapse to a single blank line.
    toc_pattern = re.compile(
        r'((?:(?:I{1,3}V?|VI{0,3}|IX|X)\.[ \t]+[A-Z][^\n]{5,80}\n){3,})',
        re.MULTILINE
    )
    text = toc_pattern.sub('\n', text)

    # Collapse runs of blank lines to a single blank
    text = re.sub(r'\n{3,}', '\n\n', text)

    return text.strip()


def _extract_pdf_text(path: Path, max_chars: int = 40_000) -> str:
    """
    Extract and clean raw text from a PDF using pypdf (with pdfplumber fallback).

    Handles browser-printed NSF PDFs (the most common format researchers supply).
    Cleans URL noise, timestamps, and TOC duplicates before returning.
    """
    if _PdfReader is not None:
        try:
            reader = _PdfReader(str(path))
            pages = []
            for i, page in enumerate(reader.pages):
                txt = page.extract_text() or ""
                if txt.strip():
                    pages.append(f"--- Page {i+1} ---\n{txt}")
            text = "\n\n".join(pages)
            if text.strip():
                return _clean_pdf_text(text)[:max_chars]
        except Exception:
            pass

    if _pdfplumber is not None:
        try:
            with _pdfplumber.open(str(path)) as pdf:
                pages = []
                for i, page in enumerate(pdf.pages):
                    txt = page.extract_text() or ""
                    if txt.strip():
                        pages.append(f"--- Page {i+1} ---\n{txt}")
                text = "\n\n".join(pages)
                if text.strip():
                    return _clean_pdf_text(text)[:max_chars]
        except Exception:
            pass

    raise ValueError(
        f"Could not extract text from {path}. "
        "Ensure pypdf or pdfplumber is installed and the PDF is not scanned/image-only."
    )


# ── Claude extraction prompt ───────────────────────────────────────────────────

_EXTRACTION_SYSTEM = """\
You are a precise document parser. You extract structured information from
NSF grant solicitation PDFs. You return only valid JSON — no preamble,
no markdown fences, no commentary.

Be conservative: if a field is not present or unclear, use an empty string
or empty list. Never invent content. Quote directly from the document where
the field asks for exact text."""

_EXTRACTION_PROMPT = """\
Extract structured information from this NSF solicitation document.

Return ONLY a valid JSON object with exactly these fields:

{{
  "solicitation_id": "e.g. NSF 26-501 — from the document header",
  "title": "full program title from the document header",
  "program_title": "from the 'Program Title:' field in the summary table",
  "synopsis": "full text of the 'Synopsis of Program:' section — preserve all paragraphs",
  "program_description": "full text of Section II (Program Description) — include all subsections",
  "priority_areas": ["list of explicit priority bullets, measures of success, or named themes from the program description"],
  "review_criteria": "text of Section VI.A including both standard NSF criteria and any additional solicitation-specific criteria",
  "additional_review_criteria": "text of the 'Additional Solicitation Specific Review Criteria' subsection only, empty string if none",
  "award_info": "award type, estimated number of awards, anticipated funding amount, and duration",
  "eligibility": "who may submit, PI limits, any other eligibility restrictions",
  "tracks": [
    {{"name": "track or phase name", "description": "brief description of that track"}}
  ],
  "deadlines": "all deadlines including LOI date (if required) and full proposal deadline(s)",
  "program_contacts": "names, emails, and phone numbers of cognizant program officers"
}}

Rules:
- program_description should be substantial — include the full section, not a summary
- priority_areas should be a flat list of strings, one item per priority/measure
- tracks should include Phase I/II, named tracks (IntBIO, EPSCoR, CAREER etc.) if present
- deadlines: list all dates clearly labeled (LOI, Phase I, Phase II, etc.)
- If a section is absent from the document, use "" or [] as appropriate

## NSF Solicitation Text

{text}"""


# ── Main public function ───────────────────────────────────────────────────────

def read_pdf_solicitation(
    path: Path | str,
    provider: str = "auto",
    model: str = "claude-haiku-4-5-20251001",
    api_key: str | None = None,
) -> SolicitationData:
    """
    Extract structured solicitation data from an NSF PDF.

    Args:
        path:    Path to the solicitation PDF
        provider: Backend provider ("openai", "anthropic", or "auto")
        model:   Model to use for extraction
        api_key: Reserved for future explicit per-call auth support

    Returns:
        SolicitationData — same type returned by fetch_solicitation()

    Raises:
        ValueError: if PDF text cannot be extracted
        Provider-specific API error on API failure
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {path}")

    # Step 1: extract raw text
    raw_text = _extract_pdf_text(path)

    # Step 2: send to the configured model for structured extraction
    raw_json = generate_text(
        model=model,
        instructions=_EXTRACTION_SYSTEM,
        prompt=_EXTRACTION_PROMPT.format(text=raw_text),
        max_tokens=4096,
        provider=provider,
    ).strip()

    # Strip markdown fences if present (defensive)
    if raw_json.startswith("```"):
        lines = raw_json.splitlines()
        raw_json = "\n".join(
            lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
        )

    # Step 3: parse and validate
    try:
        data = json.loads(raw_json)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Model returned malformed JSON: {e}\n"
            f"Raw output (first 500 chars):\n{raw_json[:500]}"
        ) from e

    # Step 4: assemble SolicitationData
    # Normalise tracks — Claude may return strings instead of dicts
    tracks = []
    for t in data.get("tracks", []):
        if isinstance(t, dict):
            tracks.append({
                "name": str(t.get("name", "")),
                "description": str(t.get("description", "")),
            })
        elif isinstance(t, str):
            tracks.append({"name": t, "description": ""})

    # Normalise priority_areas — must be list[str]
    priority_areas = []
    for item in data.get("priority_areas", []):
        if isinstance(item, str) and item.strip():
            priority_areas.append(item.strip())

    return SolicitationData(
        url=str(path),
        solicitation_id=str(data.get("solicitation_id", "")),
        title=str(data.get("title", path.stem)),
        program_title=str(data.get("program_title", "")),
        synopsis=str(data.get("synopsis", "")),
        program_description=str(data.get("program_description", "")),
        priority_areas=priority_areas,
        review_criteria=str(data.get("review_criteria", "")),
        additional_review_criteria=str(data.get("additional_review_criteria", "")),
        award_info=str(data.get("award_info", "")),
        eligibility=str(data.get("eligibility", "")),
        tracks=tracks,
        deadlines=str(data.get("deadlines", "")),
        program_contacts=str(data.get("program_contacts", "")),
        solicitation_url=str(path),
        opportunity_url="",
        raw_text=raw_text[:15000],
    )


def pdf_page_count(path: Path | str) -> int:
    """Quick page count without full extraction — useful for progress feedback."""
    try:
        if _PdfReader is not None:
            return len(_PdfReader(str(path)).pages)
    except Exception:
        pass
    return 0
