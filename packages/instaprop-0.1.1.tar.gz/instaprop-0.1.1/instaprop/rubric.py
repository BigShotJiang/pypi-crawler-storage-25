"""
Rubric aggregation: merges sparse per-reviewer criteria scores into a
complete, section-weighted rubric scorecard.

Each reviewer scores only the criteria in their primary + secondary focus.
When multiple reviewers score the same criterion, they are averaged with
weights based on focus level (primary > secondary).

Section weights match the interactive rubric:
  first2:   25%  (non-specialists decide here)
  merit:    35%  (the scientific core)
  impact:   20%  (broader impacts criterion)
  writing:  20%  (affects all reviewer types)
"""

from __future__ import annotations

from dataclasses import dataclass

from .prompts.reviewer_prompts import RUBRIC_CRITERIA, REVIEWER_PERSONAS


# ── Section metadata ───────────────────────────────────────────────────────────

SECTION_WEIGHTS: dict[str, float] = {
    "first2":  0.25,
    "merit":   0.35,
    "impact":  0.20,
    "writing": 0.20,
}

SECTION_LABELS: dict[str, str] = {
    "first2":  "First two pages",
    "merit":   "Intellectual merit",
    "impact":  "Broader impacts",
    "writing": "Writing quality",
}

# Contribution weight per focus tier when averaging across reviewers
FOCUS_WEIGHTS: dict[str, float] = {
    "primary":   2.0,
    "secondary": 1.0,
}

# Tier thresholds (1–4 scale, matching interactive rubric)
TIER_THRESHOLDS = [
    (3.5, "Highly competitive"),
    (2.5, "Competitive"),
    (1.5, "Low competitive"),
    (0.0, "Not recommended"),
]


def tier_label(avg: float) -> str:
    """Map a 1–4 average score to the NSF panel tier label."""
    if avg >= 3.5:
        return "Highly competitive"
    if avg >= 2.5:
        return "Competitive"
    if avg >= 1.5:
        return "Low competitive"
    return "Not recommended"


# ── Data structures ────────────────────────────────────────────────────────────

@dataclass
class CriterionScore:
    criterion_id: str
    score: float                       # weighted average across reviewers
    contributing_reviewers: list[str]  # who scored this
    reviewer_scores: dict[str, int]    # reviewer -> raw score
    is_fatal: bool                     # any reviewer gave it a 1


@dataclass
class SectionScore:
    section_id: str
    label: str
    weight: float
    criteria_scores: dict[str, CriterionScore]
    section_avg: float                 # unweighted avg of criteria in section
    weighted_contribution: float       # section_avg * weight


@dataclass
class RubricScorecard:
    overall_score: float               # weighted avg across all sections
    overall_tier: str
    sections: dict[str, SectionScore]
    fatal_criteria: list[str]          # criterion IDs with score == 1
    unscored_criteria: list[str]       # criteria no reviewer covered
    coverage_pct: float                # % of all criteria scored
    round_num: int
    per_reviewer_overall: dict[str, int]  # reviewer -> their overall score


# ── Build a lookup: criterion_id -> {reviewer_name -> focus_level} ─────────────

def _build_focus_map() -> dict[str, dict[str, str]]:
    """
    Returns {criterion_id: {reviewer_display_name: "primary"|"secondary"}}.
    Light criteria are excluded — they are never scored.
    """
    fmap: dict[str, dict[str, str]] = {}
    for persona in REVIEWER_PERSONAS:
        name = persona["display_name"]
        for level in ("primary", "secondary"):
            for cid in persona["rubric_focus"].get(level, []):
                fmap.setdefault(cid, {})[name] = level
    return fmap


_FOCUS_MAP = _build_focus_map()


# ── Core aggregation ───────────────────────────────────────────────────────────

def aggregate(reviews: list[dict], round_num: int = 1) -> RubricScorecard:
    """
    Aggregate per-reviewer criteria scores into a complete rubric scorecard.

    Args:
        reviews:    List of parsed review dicts from panel.py
        round_num:  Which round this scorecard is for

    Returns:
        RubricScorecard with section and overall scores
    """
    # Collect all criteria scores: {criterion_id: [(score, focus_level, reviewer_name)]}
    raw_scores: dict[str, list[tuple[int, str, str]]] = {}

    for review in reviews:
        reviewer_name = review.get("reviewer", "unknown")
        criteria = review.get("criteria", {})
        fatal_flags = {
            # parse "criterion_id: ..." format from fatal_flags list
            flag.split(":")[0].strip()
            for flag in review.get("fatal_flags", [])
            if ":" in flag
        }

        for cid, score in criteria.items():
            if not isinstance(score, (int, float)):
                continue
            score = int(max(1, min(4, score)))  # clamp to 1–4

            # Determine this reviewer's focus level for this criterion
            focus_level = _FOCUS_MAP.get(cid, {}).get(reviewer_name, "secondary")
            raw_scores.setdefault(cid, []).append((score, focus_level, reviewer_name))

        # Any criterion flagged as fatal that wasn't already scored 1 → force to 1
        for cid in fatal_flags:
            if cid in raw_scores:
                existing = raw_scores[cid]
                # Override any score from this reviewer to 1
                raw_scores[cid] = [
                    (1 if r == reviewer_name else s, fl, r)
                    for s, fl, r in existing
                ]
            else:
                raw_scores.setdefault(cid, []).append((1, "primary", reviewer_name))

    # Build per-criterion aggregated scores
    criterion_scores: dict[str, CriterionScore] = {}
    all_criteria = [c for cats in RUBRIC_CRITERIA.values() for c in cats]

    for cid in all_criteria:
        entries = raw_scores.get(cid, [])
        if not entries:
            continue

        weighted_sum = 0.0
        weight_total = 0.0
        reviewer_raw: dict[str, int] = {}
        reviewers_contributing = []

        for score, focus_level, reviewer_name in entries:
            w = FOCUS_WEIGHTS.get(focus_level, 1.0)
            weighted_sum += score * w
            weight_total += w
            reviewer_raw[reviewer_name] = score
            reviewers_contributing.append(reviewer_name)

        avg = weighted_sum / weight_total if weight_total > 0 else 0.0
        is_fatal = any(s == 1 for s, _, _ in entries)

        criterion_scores[cid] = CriterionScore(
            criterion_id=cid,
            score=round(avg, 2),
            contributing_reviewers=reviewers_contributing,
            reviewer_scores=reviewer_raw,
            is_fatal=is_fatal,
        )

    # Build per-section scores
    section_scores: dict[str, SectionScore] = {}
    for section_id, criteria_ids in RUBRIC_CRITERIA.items():
        scored = {
            cid: criterion_scores[cid]
            for cid in criteria_ids
            if cid in criterion_scores
        }
        if scored:
            section_avg = sum(cs.score for cs in scored.values()) / len(scored)
        else:
            section_avg = 0.0

        weight = SECTION_WEIGHTS[section_id]
        section_scores[section_id] = SectionScore(
            section_id=section_id,
            label=SECTION_LABELS[section_id],
            weight=weight,
            criteria_scores=scored,
            section_avg=round(section_avg, 3),
            weighted_contribution=round(section_avg * weight, 3),
        )

    # Overall weighted score
    scored_sections = [s for s in section_scores.values() if s.criteria_scores]
    if scored_sections:
        total_weight = sum(s.weight for s in scored_sections)
        overall = sum(s.weighted_contribution for s in scored_sections) / total_weight
    else:
        overall = 0.0
    overall = round(overall, 3)

    # Tier
    overall_tier = "Not recommended"
    for threshold, label in TIER_THRESHOLDS:
        if overall >= threshold:
            overall_tier = label
            break

    # Fatal criteria
    fatal_criteria = [cid for cid, cs in criterion_scores.items() if cs.is_fatal]

    # Unscored criteria
    unscored = [cid for cid in all_criteria if cid not in criterion_scores]

    coverage = len(criterion_scores) / len(all_criteria) if all_criteria else 0.0

    # Per-reviewer overall
    per_reviewer = {
        r.get("reviewer", "unknown"): r.get("overall", 0)
        for r in reviews
    }

    return RubricScorecard(
        overall_score=overall,
        overall_tier=overall_tier,
        sections=section_scores,
        fatal_criteria=fatal_criteria,
        unscored_criteria=unscored,
        coverage_pct=round(coverage * 100, 1),
        round_num=round_num,
        per_reviewer_overall=per_reviewer,
    )


# ── Serialisation ──────────────────────────────────────────────────────────────

def scorecard_to_dict(sc: RubricScorecard) -> dict:
    """Convert a RubricScorecard to a JSON-serialisable dict."""
    return {
        "round": sc.round_num,
        "overall_score": sc.overall_score,
        "overall_tier": sc.overall_tier,
        "coverage_pct": sc.coverage_pct,
        "fatal_criteria": sc.fatal_criteria,
        "unscored_criteria": sc.unscored_criteria,
        "per_reviewer_overall": sc.per_reviewer_overall,
        "sections": {
            sid: {
                "label": ss.label,
                "weight": ss.weight,
                "section_avg": ss.section_avg,
                "weighted_contribution": ss.weighted_contribution,
                "criteria": {
                    cid: {
                        "score": cs.score,
                        "is_fatal": cs.is_fatal,
                        "reviewers": cs.reviewer_scores,
                    }
                    for cid, cs in ss.criteria_scores.items()
                },
            }
            for sid, ss in sc.sections.items()
        },
    }


def format_scorecard_md(sc: RubricScorecard) -> str:
    """Format a RubricScorecard as a readable Markdown table for the revision log."""
    lines = [
        f"### Rubric scorecard — round {sc.round_num}",
        "",
        f"**Overall:** {sc.overall_score:.2f} / 4.0  ·  **{sc.overall_tier}**  "
        f"·  coverage: {sc.coverage_pct}% of criteria scored",
        "",
    ]

    if sc.fatal_criteria:
        lines.append(
            f"> **Fatal flags:** {', '.join(f'`{c}`' for c in sc.fatal_criteria)}"
        )
        lines.append("")

    lines.append("| Section | Weight | Score | Weighted |")
    lines.append("|---------|--------|-------|----------|")

    for ss in sc.sections.values():
        if not ss.criteria_scores:
            row_score = "—"
            row_contrib = "—"
        else:
            row_score = f"{ss.section_avg:.2f}"
            row_contrib = f"{ss.weighted_contribution:.3f}"
        lines.append(
            f"| {ss.label} | {ss.weight:.0%} | {row_score} | {row_contrib} |"
        )

    lines.append("")
    lines.append("**Criterion detail:**")
    lines.append("")

    for section_id, ss in sc.sections.items():
        if not ss.criteria_scores:
            continue
        lines.append(f"*{ss.label}*")
        for cid, cs in ss.criteria_scores.items():
            fatal_marker = " ⚑" if cs.is_fatal else ""
            reviewer_detail = ", ".join(
                f"{r}: {s}" for r, s in cs.reviewer_scores.items()
            )
            lines.append(
                f"  - `{cid}`: **{cs.score:.2f}**{fatal_marker}  "
                f"({reviewer_detail})"
            )
        lines.append("")

    return "\n".join(lines)
