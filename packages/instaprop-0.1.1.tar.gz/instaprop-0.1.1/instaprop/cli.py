"""
instaprop — agentic NSF proposal first-draft generator
"""

import json
import os
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .pipeline import run_pipeline
from .config import Config
from .rubric import tier_label

console = Console()


@click.group()
@click.version_option(version="0.1.0", prog_name="instaprop")
def cli():
    """instaprop — generate NSF proposal drafts with an agentic review panel."""
    pass


@cli.command()
@click.option(
    "--solicitation", "-s",
    default=None,
    help="NSF.gov solicitation URL (e.g. .../nsf26-501/solicitation).",
)
@click.option(
    "--solicitation-pdf", "solicitation_pdf",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="Local NSF solicitation PDF file.",
)
@click.option(
    "--solicitation-file", "solicitation_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="Local plain-text solicitation file (alternative to URL or PDF).",
)
@click.option(
    "--contributions", "-c",
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help="Markdown or text file with intellectual merit bullet points.",
)
@click.option(
    "--output", "-o",
    default="draft.md",
    type=click.Path(path_type=Path),
    help="Output path for the final proposal draft (default: draft.md).",
)
@click.option(
    "--rounds", "-r",
    default=3,
    type=click.IntRange(1, 5),
    show_default=True,
    help="Number of writer-panel revision rounds (best-of-N selected).",
)
@click.option(
    "--target-score",
    default=None,
    type=click.FloatRange(1.0, 4.0),
    help="Optional stop threshold for rubric overall score. If reached, generation stops early.",
)
@click.option(
    "--max-rounds",
    default=None,
    type=click.IntRange(1, 10),
    help="Maximum rounds when using stop criteria. Defaults to --rounds if omitted.",
)
@click.option(
    "--stop-on-no-fatal-flags",
    is_flag=True,
    help="Stop early once a round has no fatal rubric criteria.",
)
@click.option(
    "--evolve-brief",
    is_flag=True,
    help="Rewrite the contribution brief between rounds using reviewer feedback.",
)
@click.option(
    "--provider",
    type=click.Choice(["auto", "openai", "anthropic"], case_sensitive=False),
    default="anthropic",
    show_default=True,
    help="LLM backend for writer and reviewer agents.",
)
@click.option(
    "--model",
    default="claude-opus-4-5",
    show_default=True,
    help="Model for writer and reviewer agents.",
)
@click.option(
    "--extraction-provider",
    type=click.Choice(["auto", "openai", "anthropic"], case_sensitive=False),
    default="anthropic",
    show_default=True,
    help="LLM backend for PDF extraction.",
)
@click.option(
    "--extraction-model",
    default="claude-haiku-4-5-20251001",
    show_default=True,
    help="Model for PDF extraction.",
)
@click.option(
    "--pages",
    default=5,
    type=click.IntRange(2, 15),
    show_default=True,
    help="Target page count for the proposal.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Stream reviewer critiques and revision diffs to stdout.",
)
@click.option(
    "--scorecard/--no-scorecard",
    default=True,
    show_default=True,
    help="Emit a JSON scorecard alongside the draft.",
)
@click.option(
    "--log/--no-log",
    default=True,
    show_default=True,
    help="Save a revision log (what changed each round).",
)
def generate(
    solicitation, solicitation_pdf, solicitation_file,
    contributions, output, rounds, target_score, max_rounds, stop_on_no_fatal_flags,
    evolve_brief,
    provider, model, extraction_provider, extraction_model,
    pages, verbose, scorecard, log
):
    """
    Generate a proposal draft from a solicitation and contribution bullets.

    \b
    Examples:
      # From NSF.gov solicitation URL (recommended):
      instaprop generate \\
        --solicitation https://www.nsf.gov/funding/opportunities/.../nsf26-501/solicitation \\
        --contributions my_bullets.md

      # From downloaded PDF:
      instaprop generate \\
        --solicitation-pdf nsf26-501.pdf \\
        --contributions my_bullets.md

      # From plain text file:
      instaprop generate \\
        --solicitation-file solicitation.txt \\
        --contributions my_bullets.md
    """
    sources = [s for s in [solicitation, solicitation_pdf, solicitation_file] if s]
    if len(sources) == 0:
        raise click.UsageError(
            "Provide one of: --solicitation URL, "
            "--solicitation-pdf PATH, or --solicitation-file PATH."
        )
    if len(sources) > 1:
        raise click.UsageError(
            "Provide only one solicitation source at a time."
        )

    console.print(
        Panel.fit(
            "[bold]instaprop[/bold] · agentic NSF proposal generator",
            subtitle=f"provider: {provider} · model: {model} · rounds: {rounds} · target: {pages}p",
            border_style="dim",
        )
    )

    # Source-specific feedback
    if solicitation:
        if "nsf.gov" not in solicitation:
            console.print("[yellow]Warning:[/yellow] URL doesn't look like NSF.gov.")
        console.print("[dim]  Fetching solicitation from URL...[/dim]")
    elif solicitation_pdf:
        from .pdf_reader import pdf_page_count
        n = pdf_page_count(solicitation_pdf)
        pg_str = f" ({n} pages)" if n else ""
        console.print(
            f"[dim]  Extracting solicitation from PDF{pg_str} "
            f"via {extraction_provider}/{extraction_model}...[/dim]"
        )

    cfg = Config(
        solicitation_url=solicitation,
        solicitation_pdf=solicitation_pdf,
        solicitation_path=solicitation_file,
        contributions_path=contributions,
        output_path=output,
        rounds=rounds,
        target_score=target_score,
        max_rounds=max_rounds,
        stop_on_no_fatal_flags=stop_on_no_fatal_flags,
        evolve_brief=evolve_brief,
        provider=provider,
        model=model,
        extraction_provider=extraction_provider,
        extraction_model=extraction_model,
        pages=pages,
        verbose=verbose,
        emit_scorecard=scorecard,
        emit_log=log,
    )

    try:
        result = run_pipeline(cfg, console)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"\n[red]Error:[/red] {e}")
        if verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)

    # ── Write outputs ──────────────────────────────────────────────────
    output.write_text(result.best_draft, encoding="utf-8")
    console.print(f"\n[green]✓[/green] Draft written → [bold]{output}[/bold]")

    if scorecard:
        sc_path = output.with_suffix(".scorecard.json")
        sc_path.write_text(
            json.dumps(result.scorecard, indent=2), encoding="utf-8"
        )
        console.print(f"[green]✓[/green] Scorecard   → [bold]{sc_path}[/bold]")

    if log:
        log_path = output.with_suffix(".revlog.md")
        log_path.write_text(result.revision_log, encoding="utf-8")
        console.print(f"[green]✓[/green] Revision log→ [bold]{log_path}[/bold]")

    _print_summary(result)


@cli.command()
@click.argument("scorecard", type=click.Path(exists=True, path_type=Path))
def scores(scorecard):
    """Pretty-print a .scorecard.json file."""
    data = json.loads(scorecard.read_text())
    _render_scorecard(data)


@cli.command()
def reviewers():
    """List the five panel reviewer personas."""
    table = Table(title="instaprop review panel", show_lines=True)
    table.add_column("Reviewer", style="bold")
    table.add_column("Focus")
    table.add_column("Key questions")

    personas = [
        (
            "Domain expert",
            "Field-specific depth",
            "Is the science correct? Are citations current? Does this advance the state of the art?",
        ),
        (
            "Program officer",
            "NSF fit & fundability",
            "Does this match solicitation priorities? Is the framing fundable? Budget plausibility?",
        ),
        (
            "Methodological skeptic",
            "Rigor & validity",
            "Are methods sound? Are claims supported? What are the failure modes?",
        ),
        (
            "Interdisciplinary generalist",
            "Clarity & framing",
            "Is the problem statement clear to non-specialists? Is the narrative compelling?",
        ),
        (
            "Societal impact",
            "Real-world stakes",
            "Who benefits and how? Is the broader impact section concrete and credible?",
        ),
    ]

    for name, focus, questions in personas:
        table.add_row(name, focus, questions)

    console.print(table)


@cli.command()
@click.option(
    "--provider",
    type=click.Choice(["openai", "anthropic"], case_sensitive=False),
    default="anthropic",
    show_default=True,
    help="Backend provider to check.",
)
@click.option("--api-key", default=None, help="Override API key for the selected backend.")
def check(provider, api_key):
    """Verify environment and API connectivity."""
    from .llm import generate_text

    console.print("[dim]Checking environment...[/dim]")

    env_var = "ANTHROPIC_API_KEY" if provider == "anthropic" else "OPENAI_API_KEY"
    key = api_key or os.environ.get(env_var)
    if not key:
        console.print(f"[red]✗[/red] {env_var} not set.")
        sys.exit(1)
    console.print(f"[green]✓[/green] {env_var} found.")

    try:
        if provider == "anthropic":
            os.environ["ANTHROPIC_API_KEY"] = key
            model = "claude-haiku-4-5-20251001"
        else:
            os.environ["OPENAI_API_KEY"] = key
            model = "gpt-5-mini"
        generate_text(
            model=model,
            instructions="Reply with pong.",
            prompt="ping",
            max_tokens=8,
            provider=provider,
        )
        console.print(f"[green]✓[/green] {provider.title()} API reachable.")
    except Exception as e:
        console.print(f"[red]✗[/red] API error: {e}")
        sys.exit(1)

    console.print("\n[bold green]All checks passed.[/bold green] You're ready to run instaprop.")


# ── helpers ────────────────────────────────────────────────────────────────────

def _print_summary(result):
    tier_colors = {
        "Not recommended": "red",
        "Low competitive": "yellow",
        "Competitive": "blue",
        "Highly competitive": "green",
    }
    table = Table(title="round scores", show_lines=False, box=None)
    table.add_column("Round", justify="center", style="dim")
    table.add_column("Avg", justify="center")
    table.add_column("Tier", justify="left")
    table.add_column("Best?", justify="center")

    best_round = result.best_round
    for i, sc in enumerate(result.round_scores, start=1):
        tier = tier_label(sc)
        color = tier_colors.get(tier, "white")
        marker = "[bold green]★[/bold green]" if i == best_round else ""
        table.add_row(str(i), f"{sc:.2f}/4", f"[{color}]{tier}[/{color}]", marker)

    console.print()
    console.print(table)


def _render_scorecard(data):
    for round_data in data.get("rounds", []):
        rnum = round_data["round"]
        avg = round_data.get("avg", 0)
        console.print(f"\n[bold]Round {rnum}[/bold]  avg {avg:.2f}/4")
        table = Table(show_lines=True)
        table.add_column("Reviewer")
        table.add_column("Overall", justify="center")
        table.add_column("Tier")
        table.add_column("Top fix")
        table.add_column("Fatal flags", justify="center")
        for r in round_data["reviews"]:
            flags = str(len(r.get("fatal_flags", []))) or "0"
            flag_style = "red" if int(flags) > 0 else "dim"
            table.add_row(
                r["reviewer"],
                str(r.get("overall", "—")),
                r.get("tier", "—"),
                r.get("top_fix", "—")[:60],
                f"[{flag_style}]{flags}[/{flag_style}]",
            )
        console.print(table)
