"""
Contribution brief refiner.

Takes the current contribution brief plus reviewer feedback and rewrites the
brief into a stronger input for the next draft round.
"""

from __future__ import annotations

from ..config import Config
from ..llm import generate_text

BRIEF_REFINER_SYSTEM = """\
You are a research strategist preparing the writer's working brief for the next
proposal iteration.

Your job is not to write the proposal itself. Your job is to rewrite the
underlying contribution brief so the next draft has stronger raw material.

Focus on:
- sharpening novelty claims
- making the research question explicit
- adding missing literature positioning when reviewers asked for it
- making methods, evaluation, and feasibility more concrete
- preserving strong broader impacts and framing that already work

Return only the revised contribution brief in clean Markdown or plain text.
Do not include meta-commentary, rationale, or notes to the user.
"""


class BriefRefiner:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def refine(
        self,
        current_brief: str,
        critique: str,
        round_num: int,
    ) -> str:
        prompt = f"""\
Rewrite the contribution brief for the next proposal round.

## Current contribution brief
{current_brief}

## Reviewer critique and revision brief
{critique}

## Instructions

Produce a stronger contribution brief for round {round_num + 1}.

Requirements:
1. Preserve the core project idea.
2. Integrate concrete fixes implied by the critique.
3. Add missing research framing, literature differentiation, evaluation, and
   technical detail where needed.
4. Keep the result concise enough to remain a high-signal writer input.
5. Prefer specific claims, aims, methods, and metrics over general aspirations.

Output only the revised contribution brief.
"""

        return generate_text(
            model=self.cfg.model,
            instructions=BRIEF_REFINER_SYSTEM,
            prompt=prompt,
            max_tokens=1800,
            provider=self.cfg.provider,
        )
