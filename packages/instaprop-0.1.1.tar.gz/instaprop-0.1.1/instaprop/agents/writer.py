"""
Writer agent: generates and revises the proposal draft each round.
"""

from __future__ import annotations

from ..config import Config
from ..llm import generate_text
from ..prompts.writer_prompts import (
    WRITER_SYSTEM,
    build_initial_prompt,
    build_revision_prompt,
)


class WriterAgent:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def draft(
        self,
        round_num: int,
        prior_draft: str | None,
        prior_critique: str | None,
    ) -> str:
        """Produce a draft (initial or revised)."""

        if round_num == 1 or prior_draft is None:
            user_msg = build_initial_prompt(self.cfg)
        else:
            user_msg = build_revision_prompt(self.cfg, prior_draft, prior_critique or "")

        return generate_text(
            model=self.cfg.model,
            instructions=WRITER_SYSTEM,
            prompt=user_msg,
            max_tokens=8192,
            provider=self.cfg.provider,
        )
