"""Agent implementations for instaprop."""
