"""
Critique aggregator: simulates panel discussion dynamics, then synthesizes
a prioritised revision brief for the writer agent.

Two-stage design:
  Stage 1 — Panel simulation: the five panel_statements are rendered as
             a simulated discussion transcript. This surfaces disagreements
             between reviewers before the brief is written, and forces the
             aggregator to resolve them explicitly.
  Stage 2 — Revision brief: synthesises the full reviews + simulated
             discussion into a prioritised, rubric-aligned action list.
"""

from __future__ import annotations

from ..config import Config
from ..llm import generate_text
from ..rubric import RubricScorecard, format_scorecard_md


# -- Stage 1: Panel discussion simulation -------------------------------------

DISCUSSION_SYSTEM = """\
You are the facilitator of an NSF review panel discussion.
You have received written reviews from five panelists. Now you are
moderating the live discussion of this proposal.

Render a brief panel discussion transcript (6-10 exchanges) that:
- Opens with the lead reviewer (domain expert) giving their overall take
- Surfaces the most significant disagreements between reviewers honestly
- Has other reviewers respond to each other's points where they conflict
- Ends with a rough sense of where the panel landed

Use the reviewers' names and their panel_statement as the seed for what
they say — but let the conversation develop naturally from there.

Format:
  DOMAIN EXPERT: ...
  PROGRAM OFFICER: ...
  [etc.]

Keep each turn to 1-2 sentences. Total transcript under 300 words.
The goal is to surface the *real* tension in the reviews, not produce
a sanitised summary. If one reviewer would kill a proposal that another
would fund, that conflict should be visible in the transcript."""


BRIEF_SYSTEM = """\
You are the lead program director closing an NSF review panel discussion.
You have the full written reviews, a simulated panel discussion, and a
rubric scorecard. Your job is to write a precise, prioritised revision
brief for the proposal writer.

The brief must be:
- Ordered by severity: fatal issues first, then significant concerns,
  then minor suggestions, then preservation notes
- Specific: name the section, page, or claim that needs fixing
- Actionable: tell the writer exactly what to do, not just what is wrong
- Honest about fatal flags: if a criterion scored 1, say so explicitly
  and explain what a score of 4 would look like

Format:

## Fatal issues (must fix — any one of these alone prevents funding)
- [criterion_id] ...

## Significant concerns (strongly recommended — will affect score)
- ...

## Minor suggestions (optional polish)
- ...

## Preserve (working well — do not regress)
- ...

## Disagreements to note
- [if any reviewer gave a substantially different score on a criterion,
  note it here so the writer understands the uncertainty]

Keep the full brief under 500 words. Be direct. The writer needs to act
on this, not just feel informed."""


class CritiqueAggregator:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def synthesize(
        self,
        reviews: list[dict],
        round_num: int,
        scorecard: RubricScorecard | None = None,
    ) -> str:
        """
        Two-stage synthesis: panel discussion -> revision brief.
        Returns the final revision brief as a Markdown string.
        """
        # -- Stage 1: Simulate panel discussion ----------------------------
        discussion = self._simulate_discussion(reviews)

        # -- Stage 2: Synthesise revision brief ----------------------------
        brief = self._build_brief(reviews, discussion, scorecard, round_num)

        return brief

    # -- Private helpers ---------------------------------------------------

    def _simulate_discussion(self, reviews: list[dict]) -> str:
        """Render a brief panel discussion transcript from panel_statements."""
        statements_block = "\n\n".join(
            f"**{r['reviewer']}** (overall: {r.get('overall', '?')}/4 — "
            f"{r.get('tier', '?')})\n"
            f"Written statement: \"{r.get('panel_statement', '')}\"\n"
            f"Top fix: {r.get('top_fix', 'N/A')}\n"
            f"Fatal flags: {'; '.join(r.get('fatal_flags', [])) or 'None'}"
            for r in reviews
        )

        return generate_text(
            model=self.cfg.model,
            instructions=DISCUSSION_SYSTEM,
            prompt=(
                "Please simulate the panel discussion for this proposal.\n\n"
                "## Reviewer statements\n\n"
                f"{statements_block}"
            ),
            max_tokens=600,
            provider=self.cfg.provider,
        )

    def _build_brief(
        self,
        reviews: list[dict],
        discussion: str,
        scorecard: RubricScorecard | None,
        round_num: int,
    ) -> str:
        """Synthesise full reviews + discussion into a revision brief."""

        # Build the full review block with criteria detail
        review_block = "\n\n".join(
            f"### {r['reviewer']} (overall: {r.get('overall','?')}/4 — "
            f"{r.get('tier','')})\n"
            f"**Strengths:** {r.get('strengths', 'N/A')}\n"
            f"**Concerns:** {r.get('concerns', 'N/A')}\n"
            f"**Fatal flags:** {'; '.join(r.get('fatal_flags', [])) or 'None'}\n"
            f"**Top fix:** {r.get('top_fix', 'N/A')}\n"
            f"**Criteria scores:** "
            f"{', '.join(f'{k}={v}' for k,v in r.get('criteria', {}).items())}"
            for r in reviews
        )

        scorecard_block = (
            format_scorecard_md(scorecard)
            if scorecard
            else "(scorecard not available this round)"
        )

        user_msg = (
            f"## Round {round_num} panel reviews\n\n{review_block}\n\n"
            f"## Simulated panel discussion\n\n{discussion}\n\n"
            f"## Rubric scorecard\n\n{scorecard_block}\n\n"
            "Please write the revision brief."
        )

        return generate_text(
            model=self.cfg.model,
            instructions=BRIEF_SYSTEM,
            prompt=user_msg,
            max_tokens=1200,
            provider=self.cfg.provider,
        )
