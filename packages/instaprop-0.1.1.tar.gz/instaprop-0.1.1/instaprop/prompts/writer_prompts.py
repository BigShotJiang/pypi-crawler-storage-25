"""
Prompts for the writer agent.
"""

from __future__ import annotations

from ..config import Config

WRITER_SYSTEM = """\
You are an expert scientific writer specializing in NSF proposals.
You write with precision, clarity, and persuasive authority.
You understand NSF review criteria deeply: intellectual merit and broader impacts.
You write for two audiences simultaneously: domain experts and program officers.

Your proposals are characterized by:
- A compelling opening that situates the work in a larger scientific conversation
- Specific, falsifiable hypotheses and aims — not vague goals
- Concrete methodological detail that signals feasibility
- Clear articulation of what makes this work non-trivially novel
- Broader impacts that are specific and credible, not boilerplate

Format all output as clean Markdown suitable for direct submission.
Use headings, subheadings, and appropriate lists where they aid clarity.
Never pad with filler. Every sentence must earn its place."""


def build_initial_prompt(cfg: Config) -> str:
    return f"""\
Generate a {cfg.pages}-page NSF concept note / proposal draft.

## NSF Solicitation
{cfg.solicitation_text}

## Intellectual Merit & Key Contributions
{cfg.contributions_text}

## Instructions

Write a complete draft with the following sections:

1. **Project Summary** (~half page)
   Overview, intellectual merit, broader impacts.

2. **Introduction & Motivation** (~1 page)
   Situate the problem. Why now? What gap exists?

3. **Intellectual Merit & Technical Approach** (~2 pages)
   The core science. Non-trivial contributions. Methods. Preliminary work if any.

4. **Broader Impacts** (~half page)
   Specific, credible, tied to the research.

5. **Timeline & Feasibility** (~quarter page)
   Milestones showing the work is achievable.

Write the full draft now. Do not include meta-commentary.
Output only the proposal text.
"""


def build_revision_prompt(
    cfg: Config,
    prior_draft: str,
    critique: str,
) -> str:
    return f"""\
Revise the proposal draft below based on the panel critique.

## Panel Critique (prioritized)
{critique}

## Updated Contribution Brief
{cfg.contributions_text}

## Prior Draft
{prior_draft}

## Instructions

Revise the draft to address the critique using the updated contribution brief
as your canonical statement of the project's aims, novelty, methods, and
evaluation framing. Prioritize:
1. Critical issues — these must be fixed
2. Significant concerns — address unless there's a strong reason not to
3. Minor suggestions — use judgment

Preserve what is working well. Do not regress on strong sections.
The revised draft should still be approximately {cfg.pages} pages.

Output only the revised proposal text. No meta-commentary.
"""
