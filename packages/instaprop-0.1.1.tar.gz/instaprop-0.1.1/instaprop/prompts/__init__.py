"""Prompt builders for instaprop."""
