from enum import Enum
from typing import Callable, Iterable, Literal

from rich.text import TextType
from textual.widgets._option_list import Option  # noqa

from .options import FilteredItems, SelectionStrategy
from .searchable_list_app import SearchableListApp
from .searchable_list_widget import SelectionItemType, SelectionType

type SelectionResultType[T] = T | Option


def select(
    selections: Iterable[SelectionItemType],
    selection_strategy: SelectionStrategy,
    search_title: str | None = None,
    description: TextType | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[SelectionType]], TextType | None] | None = None,
    **kwargs,
) -> list[SelectionResultType]:
    """
    Select one or more items.

    See Textual's ``App.run(...)`` for more options.

    :param selections: The items to choose from.
    :param selection_strategy: What to do when more than one item is detected.
        See ``SelectionStrategy`` for more details.
    :param search_title: Title of the search.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param app_title: Title of the Textual app.
    :param inline: Run the app inline (under the prompt).
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    # if selection_strategy is SelectionStrategy.ALL:
    #     return list(selections)

    app: SearchableListApp = SearchableListApp(
        selections,
        selection_strategy,
        search_title=search_title,
        description=description,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )
    if app_title:
        app.title = app_title
    selected = app.run(inline=inline)
    return selected or []


def select_enum[T_Enum: Enum](
    enum_type: type[T_Enum],
    select_by: Literal['name', 'value'] = 'name',
    selection_strategy: SelectionStrategy = SelectionStrategy.ONE,
    search_title: str | None = None,
    description: TextType | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[T_Enum]], TextType | None] | None = None,
    exclude: Iterable[T_Enum] | None = None,
    **kwargs,
) -> list[T_Enum]:
    """
    Select from an enum.

    See Textual's ``App.run(...)`` for more options.

    :param enum_type: The enum type to select from.
    :param select_by: Whether to select by enum name or value.
    :param selection_strategy: What to do when more than one item is detected.
        See ``SelectionStrategy`` for more details.
    :param search_title: Title of the search. Defaults to 'Select from <EnumName>'.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param app_title: Title of the Textual app.
    :param inline: Run the app inline (under the prompt).
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param exclude: An iterable of enum values to exclude from selection.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    selectable_items = [item for item in enum_type if item not in (exclude or [])]

    selections = (
        [(item.name, item) for item in selectable_items]
        if select_by == 'name'
        else [(item.value, item) for item in selectable_items]
    )

    search_title = search_title or f'Select from {enum_type.__name__}'

    return select(  # type: ignore
        selections=selections,
        selection_strategy=selection_strategy,
        search_title=search_title,
        description=description,
        app_title=app_title,
        inline=inline,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )


def select_one(
    selections: Iterable[SelectionItemType],
    search_title: str | None = None,
    description: TextType | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[SelectionType]], TextType | None] | None = None,
    **kwargs,
) -> SelectionResultType:
    """
    Select one item.

    Similar to running ``select`` with ``SelectionStrategy.ONE``.

    See Textual's ``App.run(...)`` for more options.

    :param selections: The items to choose from.
    :param search_title: Title of the search.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param app_title: Title of the Textual app.
    :param inline: Run the app inline (under the prompt).
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    selected = select(
        selections,
        SelectionStrategy.ONE,
        search_title=search_title,
        description=description,
        app_title=app_title,
        inline=inline,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )

    if not selected:
        raise ValueError('No selection made.')

    return selected[0]


def select_multiple(
    selections: Iterable[SelectionItemType],
    search_title: str | None = None,
    description: TextType | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    filtered_items: FilteredItems = FilteredItems.DIM,
    selected_callback: Callable[[list[SelectionType]], TextType | None] | None = None,
    **kwargs,
) -> list[SelectionResultType]:
    """
    Select one or more items.

    Similar to running ``select`` with ``SelectionStrategy.MULTIPLE``.

    See Textual's ``App.run(...)`` for more options.

    :param selections: The items to choose from.
    :param search_title: Title of the search.
    :param description: Description text. Can be formatted by using markup in ``Text``.
    :param app_title: Title of the Textual app.
    :param inline: Run the app inline (under the prompt).
    :param filtered_items: What happens to items as they are filtered out.
        See ``FilteredItems`` for more details.
    :param selected_callback: Callback invoked with selected values when a selection is made.
        If a ``Text`` (or string) is returned, it will be shown under the list.
    :param kwargs: Additional ``textual.app.App`` arguments.
    """
    selected = select(
        selections,
        SelectionStrategy.MULTIPLE,
        search_title=search_title,
        description=description,
        app_title=app_title,
        inline=inline,
        filtered_items=filtered_items,
        selected_callback=selected_callback,
        **kwargs,
    )

    if not selected:
        raise ValueError('No selection made.')

    return selected
