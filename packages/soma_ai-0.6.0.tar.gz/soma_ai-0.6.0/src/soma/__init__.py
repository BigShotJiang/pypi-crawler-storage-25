"""SOMA Core — Behavioral monitoring and directive control for AI agents."""

__version__ = "0.6.0"

from soma.types import (
    Action, ResponseMode, AutonomyMode, DriftMode,
    VitalsSnapshot, AgentConfig, InterventionOutcome, PressureVector,
)
# Deprecated alias — import from soma.types if needed
from soma.types import Level  # noqa: F401
from soma.engine import SOMAEngine, ActionResult
from soma.budget import MultiBudget
from soma.events import EventBus
from soma.recorder import SessionRecorder
from soma.replay import replay_session
from soma.wrap import wrap, WrappedClient, SomaBlocked, SomaBudgetExhausted
from soma.persistence import save_engine_state, load_engine_state
from soma.sdk.track import track, SomaTracker
from soma.policy import PolicyEngine, guardrail
from soma.audit import AuditLogger
from soma.proxy import SOMAProxy, SOMABlockError

def quickstart(budget=None, agents=None):
    """Fastest way to start. Returns a configured engine.

    Usage:
        engine = soma.quickstart(budget={"tokens": 50000}, agents=["agent-1", "agent-2"])
    """
    if budget is None:
        try:
            from soma.cli.config_loader import load_config
            config = load_config()
            budget_cfg = config.get("budget", {})
            budget = {k: v for k, v in budget_cfg.items() if v}
        except Exception:
            pass
    engine = SOMAEngine(budget=budget or {"tokens": 100_000}, auto_export=True)
    for agent_id in (agents or ["default"]):
        engine.register_agent(agent_id)
    return engine


__all__ = [
    "SOMAEngine", "Action", "ActionResult", "ResponseMode", "Level",
    "AutonomyMode", "DriftMode", "VitalsSnapshot", "AgentConfig",
    "InterventionOutcome", "PressureVector", "MultiBudget", "EventBus",
    "SessionRecorder", "replay_session",
    "wrap", "WrappedClient", "SomaBlocked", "SomaBudgetExhausted",
    "quickstart",
    "save_engine_state", "load_engine_state",
    "track", "SomaTracker",
    "PolicyEngine", "guardrail",
    "AuditLogger",
    "SOMAProxy", "SOMABlockError",
]
