# Sequence Markets Python SDK

Zero-dependency Python client for the [Sequence Markets](https://sequencemkts.com) execution engine.

## Install

```bash
pip install sequence-markets
```

## Quick Start

```python
from sequence_markets import Sequence

seq = Sequence("seq_live_...", "https://api.sequencemkts.com")

# See the market
quote = seq.quote("BTC-USD")
print(f"BTC: ${quote['nbbo']['mid']:,.2f}")

# Place an order (SOR routes across venues)
order = seq.buy("ETH-USD", 50, urgency="medium")

# Build a multi-leg graph
graph = seq.graph(
    nodes=[
        seq.node("spot", "ETH-USD", "buy", 200),
        seq.node("hedge", "ETH-PERP", "sell", 200, instrument_type="perp"),
    ],
    edges=[seq.edge("spot", "hedge", trigger="fill_pct", value=0.5)],
)

# Sandbox mode (simulated fills against real book)
order = seq.buy("BTC-USD", 0.001, sandbox=True)
```

## Features

- **Zero dependencies** — just Python stdlib (`urllib`, `json`)
- **Full product ladder** — connect, quote, trade, orchestrate, automate, monitor
- **Execution graphs** — TWAP, bracket orders, conditional hedges
- **40+ methods** — every REST API endpoint covered
- **Sandbox mode** — paper trading with live market data

## Documentation

[docs.sequencemkts.com/sdks/python](https://docs.sequencemkts.com/sdks/python/)
