"""Sequence Markets Python client — mirrors the Rust SDK API surface."""

import json
import time
import urllib.request
import urllib.error
import urllib.parse
import warnings
from typing import Any, Dict, Iterator, List, Optional


class SequenceError(Exception):
    """API error with status code and message."""
    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"API error ({status}): {message}")


class Sequence:
    """Client for the Sequence Markets execution engine.

    Organized around the product ladder:
        Level 0: Connect   — connect_venue, disconnect_venue, venues
        Level 1: See       — quote, balances, positions, symbols, edges
        Level 2: Trade     — buy, sell, order, orders, cancel, fills
        Level 3: Orchestrate — graph, graph_status, graph_cancel
        Level 4: Automate  — deploy_algo, algo_status, algo_start, algo_stop
        Level 5: Monitor   — tca, intel, slippage, forecast, trace
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.sequencemkts.com",
        max_retries: int = 3,
        max_concurrent: Optional[int] = None,
    ):
        """Construct a Sequence client.

        max_retries: number of attempts for transient failures (502/503/504/
            429 + connection/timeout errors). Default 3 attempts total
            (1 initial + 2 retries). Set 0 to disable retries entirely.
            Backoff: 0.5s, 1s, 2s, capped. 429 honors `Retry-After` header
            verbatim instead of the exponential schedule.
        max_concurrent: optional soft concurrency cap. When set, every
            HTTP call goes through an internal `threading.Semaphore(N)`
            so a multi-threaded fan-out from the caller can't exceed N
            simultaneous in-flight requests. Default `None` = no cap
            (preserves backward-compatible behavior). Useful for callers
            doing wide fee/quote sweeps who hit upstream rate limits;
            set to 8 or 16 to keep within Sequence's documented capacity.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max(0, int(max_retries))
        if max_concurrent is not None and max_concurrent > 0:
            import threading
            self._sem: Optional[Any] = threading.Semaphore(int(max_concurrent))
        else:
            self._sem = None

    # ═══════════════════════════════════════════════════════════════════════
    # Level 0: Connect
    # ═══════════════════════════════════════════════════════════════════════

    def connect_venue(
        self,
        venue: str,
        api_key: str,
        api_secret: str,
        passphrase: Optional[str] = None,
        extra_json: Optional[Any] = None,
    ) -> None:
        """Store venue API credentials."""
        body = {"api_key": api_key, "api_secret": api_secret}
        if passphrase:
            body["passphrase"] = passphrase
        if extra_json is not None:
            body["extra_json"] = extra_json
        self._put(f"/v1/credentials/{venue}", body)

    def disconnect_venue(self, venue: str) -> None:
        """Remove venue credentials."""
        self._delete(f"/v1/credentials/{venue}")

    def venues(self) -> Any:
        """List connected venues."""
        return self._get("/v1/credentials")

    # ═══════════════════════════════════════════════════════════════════════
    # Level 1: See
    # ═══════════════════════════════════════════════════════════════════════

    def quote(self, symbol: str, depth: int = 10, nowait: bool = False) -> Dict:
        """Get NBBO + per-venue BBO + merged order book for a symbol.

        depth: book levels per side (default 10, max 100). Polymarket markets
            routinely have 50+ levels of depth on each side; raise this when
            you want to see the full active range.
        nowait: skip the up-to-2s wait for a dynamic subscribe to populate.
            Returns immediately with whatever is cached right now — edge data
            if the symbol is already subscribed, otherwise the
            `venue_public_api` REST fallback, otherwise `unavailable`. The
            subscribe still fires in the background so a subsequent quote
            (~2s later) can upgrade to `edge_nbbo`.
            **Research-grade only.** Trading code must never pass nowait=True.
        """
        d = max(1, min(int(depth), 100))
        qs = f"?depth={d}"
        if nowait:
            qs += "&nowait=true"
        return self._get(f"/v1/quotes/{_enc(symbol)}{qs}")

    def quotes(self, symbols: List[str]) -> Any:
        """Get quotes for multiple symbols (thin /v1/quotes pass-through).

        For bulk-scan workloads (50+ symbols) prefer `quotes_batch()` — it's
        ~2800× faster on cold prediction-market paths thanks to server-side
        fan-out + bounded concurrency + shared cache dedup.
        """
        joined = ",".join(_enc(s) for s in symbols)
        return self._get(f"/v1/quotes?symbols={joined}")

    def quotes_batch(
        self,
        symbols: List[str],
        depth: int = 10,
        nowait: bool = True,
        concurrency: int = 64,
        instrument_type: Optional[str] = None,
    ) -> Dict:
        """Fetch many quotes in one round-trip (POST /v1/quotes_batch).

        Server-side tokio fan-out across symbols with semaphore-bounded
        concurrency. Returns per-symbol partial results — one bad symbol
        doesn't fail the batch. Much faster than looping `quote()` for
        bulk-scan workloads.

        Args:
            symbols: tickers, token_ids, slugs, or URLs — same resolution
                rules as `quote()`. Hard cap 2000 per batch; split larger.
            depth: uniform book depth per side (default 10, max 100).
            nowait: skip the 2s subscribe-wait per cold symbol. Defaults to
                True because the serial wait is catastrophic at batch scale
                (one cold symbol would stall the response). Research-only.
            concurrency: max concurrent upstream quote-fetches inside CC.
                Default 64, cap 256. Higher = faster but pressures venue REST
                fallbacks (Polymarket CLOB, Kalshi public orderbook).
            instrument_type: optional uniform override; auto-detects otherwise
                (token_id/Kalshi-ticker → `prediction`, else `spot`).

        Returns:
            {
              "quotes": [
                 {"symbol", "source", "nbbo", "venues", "book"}  # success
                 | {"symbol", "error"}                           # failure
              ],
              "count": int,
              "elapsed_ms": int,  # server-side wall time
            }

        Example:
            >>> r = seq.quotes_batch([m["yes_token_id"] for m in all_sports],
            ...                       depth=20, nowait=True, concurrency=64)
            >>> for q in r["quotes"]:
            ...     if "error" in q:
            ...         print(f"skipped {q['symbol']}: {q['error']}")
            ...     else:
            ...         books[q["symbol"]] = q
        """
        body: Dict[str, Any] = {
            "symbols": list(symbols),
            "depth": max(1, min(int(depth), 100)),
            "nowait": bool(nowait),
            "concurrency": max(1, min(int(concurrency), 256)),
        }
        if instrument_type:
            body["instrument_type"] = instrument_type
        return self._post("/v1/quotes_batch", body)

    def balances(self) -> Dict:
        """Get unified balances across all venues.

        .. deprecated::
            Use ``positions_unified(kinds=["fiat", "crypto"])`` instead.
        """
        warnings.warn(
            "balances() is deprecated; use positions_unified(kinds=['fiat','crypto']) instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._get("/v1/balances")

    def positions(self) -> List[Dict]:
        """Get current positions with mark price and P&L.

        .. deprecated::
            Use ``positions_unified()`` instead.
        """
        warnings.warn(
            "positions() is deprecated; use positions_unified() instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._get("/v1/positions")

    def positions_unified(
        self,
        venues: Optional[List[str]] = None,
        kinds: Optional[List[str]] = None,
        include_closed: bool = False,
    ) -> Dict:
        """Unified positions across all instrument kinds.

        Replaces ``balances()``, ``positions()``, ``perp_positions()``, and
        ``portfolio()`` in one endpoint. All values denominated in USD.

        Args:
            venues: Optional list of venues to include (e.g., ["kraken", "polymarket"]).
            kinds: Optional list of instrument kinds to include. Valid values:
                ``"fiat"``, ``"crypto"``, ``"perp"``, ``"event_contract"``.
            include_closed: Include closed/resolved/redeemed rows (default: active only).

        Returns:
            Dict with keys:
                ``positions``: List of position views with qty, prices, P&L, lifecycle.
                ``totals``: Portfolio totals (nav_usd_1e9, cash_usd_1e9, etc.).
                ``as_of_ns``: Nanosecond timestamp when the snapshot was taken.

        Example:
            >>> seq = Sequence("seq_live_...")
            >>> # All active positions
            >>> resp = seq.positions_unified()
            >>> # Cash only (fiat + crypto)
            >>> cash = seq.positions_unified(kinds=["fiat", "crypto"])
            >>> # Event contracts on Kalshi + Polymarket
            >>> events = seq.positions_unified(
            ...     kinds=["event_contract"],
            ...     venues=["kalshi", "polymarket"],
            ... )
        """
        params = {}
        if venues:
            params["venues"] = ",".join(venues)
        if kinds:
            params["kinds"] = ",".join(kinds)
        if include_closed:
            params["include_closed"] = "true"
        query = ("?" + urllib.parse.urlencode(params)) if params else ""
        return self._get(f"/v1/positions/unified{query}")

    def symbols(self) -> List[Dict]:
        """Get all tradable symbols across venues."""
        return self._get("/v1/symbols")

    def price_history(
        self,
        symbol: str,
        range: str = "1d",
        fidelity_secs: int = 60,
        paginate: bool = False,
        start_ts: Optional[int] = None,
        end_ts: Optional[int] = None,
        venue: Optional[str] = None,
        limit: Optional[int] = None,
        underlying: bool = False,
    ) -> Dict:
        """Price history — uniform shape for every venue (CEX, perp, DEX,
        prediction market).

        range: one of "1h", "6h", "1d", "1w", "1m", "3m", "6m", "1y", "2y",
            "5y", "max". Ignored when fidelity_secs=0 or when both start_ts
            and end_ts are set.
        fidelity_secs: point cadence in seconds. `0` → TICK MODE: return
            raw trade prints with `qty_1e8`, `side`, `venue_id` populated.
            Behavior depends on the symbol:
            - Polymarket token: paginates the venue's /data-api/trades and
              returns every print since market creation (lifecycle backfill,
              up to `limit`, cap 50_000).
            - Kalshi ticker: paginates /markets/trades then /historical/trades
              for lifecycle backfill.
            - CEX/perp/DEX symbol: returns the live in-memory tape ring
              (most-recent `limit` prints, cap 500).
            Positive values bucket into bars.
        limit: tick-mode cap. Default 100 for tape, 50_000 for prediction-
            market lifecycle backfill.
        paginate: walk backward in 7-day windows to bypass Polymarket's
            per-call ~4-5k point cap. Polymarket-only.
        start_ts / end_ts: explicit unix-seconds window. When BOTH are set,
            Polymarket's startTs/endTs API is used directly.
        venue: REQUIRED for long-range queries (>24h) on CEX / perp / DEX
            symbols — names which venue's public klines API to proxy
            through. Examples: "binance", "coinbase", "kraken", "okx",
            "bybit", "hyperliquid", "dex_ethereum", "solana".
            Ignored for Polymarket tokens, Kalshi tickers, and short-range
            (≤24h) queries.

        Dispatch (server-side, all transparent to caller):
        - Polymarket token (60+ digit symbol): proxied to Polymarket REST.
        - Kalshi market ticker: proxied to Kalshi /candlesticks.
        - Short range (≤24h): in-memory trade tape, venue-aggregated.
        - Long range (>24h) with venue=: proxied live to the venue's
          public klines endpoint via HistoryAdapter. No caching yet —
          expect 2-3s for 1y of hourly data, longer for fine intervals.

        Example — year of Coinbase BTC-USDC at 1h fidelity:
            btc = seq.price_history("BTC-USDC", range="1y",
                                    fidelity_secs=3600, venue="coinbase")
            # points: [{"ts_ns": ..., "price_1e9": ...}, ...]
        """
        qs = f"?range={range}&fidelity_secs={int(fidelity_secs)}"
        if paginate:
            qs += "&paginate=true"
        if start_ts is not None:
            qs += f"&start_ts={int(start_ts)}"
        if end_ts is not None:
            qs += f"&end_ts={int(end_ts)}"
        if venue is not None:
            qs += f"&venue={_enc(venue)}"
        if limit is not None:
            qs += f"&limit={int(limit)}"
        if underlying:
            qs += "&underlying=true"
        return self._get(f"/v1/price_history/{_enc(symbol)}{qs}")

    def funding_history(
        self,
        symbol: str,
        venue: str,
        range: str = "1m",
        start_ts: Optional[int] = None,
        end_ts: Optional[int] = None,
    ) -> Dict:
        """Historical perpetual funding rates for `symbol` on `venue`.

        venue: one of "binance", "bybit", "okx", "hyperliquid" (spot venues
            return 400 — they don't have funding).
        range: "1d" | "1w" | "1m" | "3m" | "6m" | "1y" | "2y" | "5y" | "max".
            Default "1m". Ignored when start_ts AND end_ts are both set.
        start_ts / end_ts: explicit window in unix SECONDS. When both are
            provided they override `range` — use for arbitrary windows
            (e.g. a specific trading session, a known vol regime).

        Returns:
            {symbol, venue, count, points: [{ts_ns, rate_1e9, mark_price_1e9?}]}
        where `rate_1e9` is a SIGNED fraction × 1e9. Positive means longs pay
        shorts. Divide by 1e9 and multiply by 10_000 for per-settlement bps.

        Examples:
            # Last 30 days (preset range):
            r = seq.funding_history("BTC-USDT", "binance", "1m")

            # Arbitrary window — Apr 1 → Apr 15 2026:
            r = seq.funding_history("BTC-USDT", "binance",
                                    start_ts=1774483200, end_ts=1775692800)
        """
        qs = f"?venue={_enc(venue)}&range={_enc(range)}"
        if start_ts is not None:
            qs += f"&start_ts={int(start_ts)}"
        if end_ts is not None:
            qs += f"&end_ts={int(end_ts)}"
        return self._get(f"/v1/funding_history/{_enc(symbol)}{qs}")

    def markets(
        self,
        venue: str = "polymarket",
        q: Optional[str] = None,
        slug: Optional[str] = None,
        clob_token_id: Optional[str] = None,
        tag: Optional[str] = None,
        tag_id: Optional[int] = None,
        related_tags: bool = False,
        exclude_tag_id: Optional[int] = None,
        active: bool = True,
        closed: bool = False,
        limit: int = 20,
        offset: int = 0,
        order: str = "",
        cursor: Optional[str] = None,
        expand: Optional[str] = None,
    ) -> Dict:
        """Discover prediction markets on a venue.

        venue: `polymarket` or `kalshi` — both are wired. Returns the same
            unified `Market` shape regardless of venue so the rest of the
            call chain (`seq.quote(m["yes_token_id"])`, `seq.buy(...)`) is
            venue-agnostic.
        q: free-text search — case-insensitive match against question + slug.
            E.g. `q="bitcoin"`, `q="election"`, `q="fed cut"`.
        slug: direct slug lookup (short-circuits discovery). Maps to
            Gamma `?slug=`. Use this when you already have a URL.
        tag: Polymarket tag slug — server-side narrowing. Examples:
            `"bitcoin"`, `"crypto"`, `"politics"`, `"sports"`, `"pop-culture"`.
        tag_id: Polymarket tag id — faster than tag_slug if you have the id
            from `/tags`. Pass `related_tags=True` to widen to related tags.
        exclude_tag_id: exclude a tag from results.
        active: only return currently-trading markets (default True).
        closed: include resolved markets (default False — pass True for
            historical discovery, per Polymarket's default closed=false).
        limit: max markets to return (1–100, default 20).
        offset: pagination offset (Gamma `offset=`). Mostly unnecessary
            with `expand="outcomes"` since real outcomes sort first within
            an event — a single `limit=200` call usually covers every real
            candidate plus a margin of placeholders to skip.
        order: sort field. Accepts `volume` (24h), `volume_week`,
            `volume_total`, `liquidity`, `end_date`, `start_date`, `created`,
            `competitive`, `closed_time` — mirrors Polymarket's documented
            `order` options on the events endpoint. **Default is `""` (no
            sort).** For Kalshi, asking for `volume` triggers a wide
            client-side rerank that breaks exhaustive cursor pagination
            (cursor jumps 4× per call); pass `order="volume"` only when you
            actually want top-by-volume and aren't walking the catalog.
        cursor: opaque pagination cursor returned by a previous response's
            `next_cursor`. Use this to walk page-by-page exhaustively. For
            full-catalog walks prefer `iter_markets()` which threads cursors
            for you.
        expand: comma-separated expansion modes. Currently supported:
            `"outcomes"` flat-maps each multi-outcome Polymarket event into
            N binary rows — one per outcome token — with `symbol`,
            `parent_condition_id`, `outcome_name`, `raw_outcome_name`,
            `is_placeholder_outcome`, `outcome_index`, and `parent_slug`
            populated. Real candidates sort before placeholder slots
            (`Person CC`, `Driver B`, `Other`) so paged consumers exhaust
            real names first. Required for pure-equivalence matchers — use
            `is_placeholder_outcome` to skip slots that aren't real
            candidates yet.

        Returns `{markets: [{slug, question, outcomes, outcome_token_ids,
        yes_token_id, no_token_id, volume_24h, volume_week, end_date,
        url, …}], count, venue}`. Slugs and token_ids are immediately
        usable with seq.settlement() and seq.quote().

        Freshness: each call is a live Gamma fetch — markets minted seconds
        ago surface immediately. Use `order="created"` to sort newest-first
        when hunting for brand-new contracts.
        """
        qs: List[str] = [
            f"venue={_enc(venue)}",
            # Server cap is 500 per page (the actual Gamma /events ceiling
            # for Polymarket; Kalshi mirrors it for cross-venue
            # consistency). Asking for more silently truncated to ~499
            # which surprised callers who expected `limit=1000` to mean
            # 1000. For full-catalog walks use `iter_markets()` which
            # threads `next_cursor` for you across pages.
            f"limit={max(1, min(int(limit), 500))}",
            f"active={'true' if active else 'false'}",
        ]
        # Only forward `order` when the caller actually requested one. The
        # server's empty-string default routes Kalshi through the cheap
        # cursor-native path; sending order=volume silently triggers a 4×
        # over-fetch + client-side rerank that breaks cursor invariants.
        if order:          qs.append(f"order={_enc(order)}")
        if closed:         qs.append("closed=true")
        if offset > 0:     qs.append(f"offset={int(offset)}")
        if q:              qs.append(f"q={_enc(q)}")
        if slug:           qs.append(f"slug={_enc(slug)}")
        if clob_token_id:  qs.append(f"clob_token_id={_enc(clob_token_id)}")
        if tag:            qs.append(f"tag={_enc(tag)}")
        if cursor:         qs.append(f"cursor={_enc(cursor)}")
        if tag_id is not None:
            qs.append(f"tag_id={int(tag_id)}")
            if related_tags: qs.append("related_tags=true")
        if exclude_tag_id is not None:
            qs.append(f"exclude_tag_id={int(exclude_tag_id)}")
        if expand:         qs.append(f"expand={_enc(expand)}")
        return self._get(f"/v1/markets?{'&'.join(qs)}")

    def iter_markets(
        self,
        venue: str = "polymarket",
        page_size: int = 1000,
        **kwargs: Any,
    ) -> Iterator[Dict]:
        """Yield every market on `venue` matching the filters, page by page.

        Threads `next_cursor` between calls so callers don't have to. Stops
        when the server reports `has_more=false`. Same filter kwargs as
        `markets()` — `q`, `tag`, `active`, `closed`, `expand`, etc. — but
        `cursor`, `offset`, and `limit` are managed internally and any
        caller-supplied values for them are ignored.

        Example — exhaustive Kalshi walk:
            for m in seq.iter_markets(venue="kalshi", active=True):
                process(m)

        Example — every Polymarket binary outcome:
            for m in seq.iter_markets(
                venue="polymarket", expand="outcomes", active=True,
            ):
                if not m.get("is_placeholder_outcome"):
                    process(m)
        """
        kwargs.pop("cursor", None)
        kwargs.pop("offset", None)
        kwargs.pop("limit", None)
        cursor: Optional[str] = None
        while True:
            page = self.markets(
                venue=venue, limit=page_size, cursor=cursor, **kwargs
            )
            for m in page.get("markets", []):
                yield m
            if not page.get("has_more"):
                return
            nxt = page.get("next_cursor")
            if not nxt:
                return
            cursor = nxt

    def market(self, identifier: str, venue: str = "polymarket") -> Optional[Dict]:
        """Fetch a single market by slug, ERC-1155 token id, or Kalshi ticker.

        Returns the market dict or None if not found. Auto-detects the
        identifier shape and routes to the right lookup path:

          - 60+-digit decimal string → Polymarket `clob_token_id` lookup
            (single upstream call against `gamma /markets?clob_token_ids=`).
          - Kalshi `<TICKER>:YES` / `<TICKER>:NO` → strips the suffix and
            looks up the ticker via Kalshi `tickers=` filter (the canonical
            Kalshi `ticker` field has no Yes/No suffix).
          - Kalshi-shaped prefix (`KX*`, `INX*`, `NASDAQ100*`) when the
            venue arg is "kalshi" → direct ticker lookup.
          - Anything else → slug lookup (`gamma /events?slug=` for
            Polymarket; ticker lookup for Kalshi).

        Examples:
            # By slug
            m = seq.market("fed-decision-in-october")

            # By Polymarket token_id
            m = seq.market("18812649149814341758733697580460697418474693998558159483117100240528657629879")

            # By Kalshi ticker (full canonical form, with or without suffix)
            m = seq.market("KXNBAGAME-26MAY01LALHOU-LAL:YES", venue="kalshi")
            m = seq.market("KXNBAGAME-26MAY01LALHOU-LAL",     venue="kalshi")

            print(m["end_date"])
            seq.quote(m["yes_token_id"])  # → trade-ready
        """
        is_poly_token = (
            venue == "polymarket"
            and identifier.isdigit()
            and len(identifier) >= 60
        )
        if is_poly_token:
            r = self.markets(
                venue=venue, clob_token_id=identifier, limit=1,
                # `active` filter doesn't apply to direct token_id lookup —
                # callers may legitimately need metadata for resolved markets
                # (e.g. settlement reconciliation). Pass active=False so the
                # server-side `clob_token_ids` fast-path runs unconditionally.
                active=False,
            )
        elif venue == "kalshi":
            # Strip the canonical `:YES`/`:NO` outcome suffix — Kalshi's
            # native `ticker` field has no suffix, and the server's `slug=`
            # filter for kalshi proxies to `tickers=` upstream.
            ticker = identifier
            if ticker.upper().endswith(":YES") or ticker.upper().endswith(":NO"):
                ticker = ticker.rsplit(":", 1)[0]
            r = self.markets(venue=venue, slug=ticker, limit=1, active=True)
        else:
            r = self.markets(venue=venue, slug=identifier, limit=1, active=True)
        items = r.get("markets", []) if isinstance(r, dict) else []
        return items[0] if items else None

    def search_markets(self, query: str, limit: int = 20, **kwargs) -> Dict:
        """Convenience wrapper — `seq.markets(q=query, limit=limit, ...)`."""
        return self.markets(q=query, limit=limit, **kwargs)

    def new_markets(self, limit: int = 20, **kwargs) -> Dict:
        """Newest markets first — wrapper around `seq.markets(order="created")`.

        Use this to poll for brand-new contracts. Typical pattern:
            seen = set()
            while True:
                for m in seq.new_markets(limit=50)["markets"]:
                    if m["condition_id"] not in seen:
                        seen.add(m["condition_id"])
                        print("NEW:", m["slug"], m["question"])
                time.sleep(10)

        Dedupe on `condition_id` — slugs/token_ids churn across recurring
        contracts (e.g. 5-minute BTC hourly), condition_id is the stable id.
        """
        return self.markets(order="created", limit=limit, **kwargs)

    def settlement(self, slug: str, underlying: bool = False) -> Dict:
        """Prediction-market settlement: ground-truth outcome (+ optional Chainlink curve).

        slug: Polymarket event slug (e.g. "btc-updown-5m-1776537600") or URL.
        underlying: include the Chainlink underlying curve (default False — fast
            path; metadata + outcome only). Set True for ML-label reconstruction
            where you need the on-chain price feed resampled inside the event
            window; expect higher latency bounded by the server-side RPC cap.

        Returns a dict with keys:
            slug, question, yes_token_id, no_token_id, condition_id, neg_risk,
            status ("open"|"resolving"|"resolved"), resolved_outcome
            ("Up"|"Down"|None), outcome_source ("polymarket_gamma"),
            yes_price, no_price, event_start_s, event_end_s,
            resolution_source, underlying.

        `resolved_outcome` is the actual Polymarket settlement — never derived
        from our Chainlink reconstruction. Use it as ground-truth ML label.
        """
        return self._get(
            f"/v1/settlement/{_enc(slug)}?underlying={str(bool(underlying)).lower()}"
        )

    # `trades()` was removed. Use:
    #   seq.price_history(symbol, fidelity_secs=0, limit=N)
    # The returned points carry `qty_1e8`, `side`, `venue_id` in tick mode.

    def funding_rates(
        self,
        venue: Optional[str] = None,
        symbol: Optional[str] = None,
    ) -> Dict:
        """Get perpetual funding rates across venues.

        Rates are normalized to per-hour basis points regardless of each
        venue's native settlement cadence (`rate_bps_per_hour`). Returned
        envelope:

            {
                "unit": "bps_per_hour",
                "rates": [
                    {
                        "venue": "binance",
                        "symbol": "BTC-USDT",
                        "rate_bps_per_hour": 0.125,
                        "predicted_rate_bps_per_hour": 0.125,
                        "mark_price_1e9": 85_000_000_000_000,
                        "open_interest_1e8": ...,
                        "next_settlement_ns": ...,
                        "snapshot_age_ms": 41
                    },
                    ...
                ]
            }

        Args:
            venue: Optional filter ("binance", "bybit", "okx", "hyperliquid").
            symbol: Optional filter by canonical symbol (e.g. "BTC-USDT").
        """
        qs = []
        if venue:
            qs.append(f"venue={_enc(venue)}")
        if symbol:
            qs.append(f"symbol={_enc(symbol)}")
        suffix = ("?" + "&".join(qs)) if qs else ""
        return self._get(f"/v1/market/funding-rates{suffix}")

    def funding_rate(self, venue: str, symbol: str) -> Optional[Dict]:
        """Get a single venue+symbol funding rate, or None if unknown."""
        resp = self.funding_rates(venue=venue, symbol=symbol)
        rates = resp.get("rates", []) if isinstance(resp, dict) else []
        return rates[0] if rates else None

    def perp_positions(self) -> Any:
        """Get perpetual positions.

        .. deprecated::
            Use ``positions_unified(kinds=["perp"])`` instead.
        """
        warnings.warn(
            "perp_positions() is deprecated; use positions_unified(kinds=['perp']) instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._get("/v1/positions/perp")

    def edges(self) -> Any:
        """Get connected edges (venue adapters)."""
        return self._get("/v1/edges")

    def account(self) -> Any:
        """Get account info."""
        return self._get("/v1/account")

    def portfolio(self) -> Any:
        """Get portfolio summary.

        .. deprecated::
            Use ``positions_unified()`` and read the ``totals`` field instead.
        """
        warnings.warn(
            "portfolio() is deprecated; use positions_unified() and read .totals instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._get("/v1/portfolio/summary")

    def health(self) -> bool:
        """Health check (no auth required)."""
        try:
            req = urllib.request.Request(f"{self._base_url}/v1/health/live")
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status == 200
        except Exception:
            return False

    def risk_limits(self) -> Any:
        """Get risk limits."""
        return self._get("/v1/risk_limits")

    # ─── Pre-trade discovery: fees + preview ───────────────────────────────

    def fees(self, ticker: str, venues: Optional[List[str]] = None) -> Dict:
        """Maker/taker fees per venue for a ticker. `GET /v1/fees`

        Returns ``{"ticker": str, "fees": [{"venue": str, "maker_bps": int|None,
        "taker_bps": int|None}, ...]}``. ``None`` taker/maker means the venue
        has no fee data yet — treat as "do not route here," not "free."

        Prediction-venue caveat: Polymarket and Kalshi both charge
        ``fee = rate × contracts × p × (1 − p)`` (taker only — makers never
        pay; rebates flow separately). The bps reported here is the value at
        midprice (p=0.5). The effective rate as fraction of cost scales as
        ``rate × (1 − p) × 10000`` and gets larger at low prices — a Sports
        market at p=0.05 charges ~285 bps even though midprice reads 150.

        For size- and price-aware estimates (the right answer for an actual
        order), use ``preview``.
        """
        qs = f"?ticker={_enc(ticker)}"
        if venues:
            qs += f"&venues={_enc(','.join(venues))}"
        return self._get(f"/v1/fees{qs}")

    def preview(self, symbol: str, side: str, qty: float,
                order_type: str = "market") -> Dict:
        """Pre-trade dry-run: estimated fee, slippage, total cost, and
        candidate venues — without submitting. `POST /v1/orders/preview`
        """
        body = {
            "symbol": symbol,
            "side": side,
            "order_type": order_type,
            "qty": qty,
        }
        return self._post("/v1/orders/preview", body)

    # ─── Risk ops: kill switch + bulk cancel ───────────────────────────────

    def kill_switch_engage(self, reason: Optional[str] = None) -> Dict:
        """Engage the global kill switch. `POST /v1/kill_switch`

        Halts new order submission for the caller. Existing open orders are
        NOT cancelled — pair with ``cancel_all_on_venue`` for stop-everything.
        """
        return self._post("/v1/kill_switch", {"reason": reason})

    def kill_switch_clear(self) -> Dict:
        """Clear the global kill switch (admin only).
        `POST /v1/kill_switch/clear`
        """
        return self._post("/v1/kill_switch/clear", {})

    def cancel_all_on_venue(self, venue: str) -> Any:
        """Cancel every open order on a single venue.
        `POST /v1/venue_cancel_all/:venue`
        """
        return self._post(f"/v1/venue_cancel_all/{_enc(venue)}", {})

    # ═══════════════════════════════════════════════════════════════════════
    # Level 2: Trade
    # ═══════════════════════════════════════════════════════════════════════

    def buy(self, symbol: str, qty: float, **kwargs) -> Dict:
        """Submit a buy order. Returns {graph_id, status, node_count, edge_count}.

        kwargs: venue, limit_price, urgency, max_slippage_bps, policy, horizon_ms,
                tif, sandbox
        """
        return self._submit_order(symbol, "buy", qty, **kwargs)

    def sell(self, symbol: str, qty: float, **kwargs) -> Dict:
        """Submit a sell order."""
        return self._submit_order(symbol, "sell", qty, **kwargs)

    def order(self, node_order_id: str) -> Dict:
        """Get a single order by ID."""
        resp = self._get(f"/v1/orders?node_order_id={_enc(node_order_id)}")
        orders = resp.get("orders", []) if isinstance(resp, dict) else resp
        if not orders:
            raise SequenceError(404, f"order {node_order_id} not found")
        return orders[0]

    def orders(self, limit: int = 50, offset: int = 0,
               symbol: Optional[str] = None) -> Dict:
        """List orders with pagination. Returns {orders, total, limit, offset, has_more}."""
        path = f"/v1/orders?limit={limit}&offset={offset}"
        if symbol:
            path += f"&symbol={_enc(symbol)}"
        return self._get(path)

    def cancel(self, graph_or_order_id: str) -> None:
        """Cancel an order or execution graph."""
        graph_id = graph_or_order_id.split(":")[0] if ":" in graph_or_order_id else graph_or_order_id
        self._delete(f"/v1/execution_graphs/{graph_id}")

    # ═══════════════════════════════════════════════════════════════════════
    # Unified prediction-market verbs — same call on Kalshi + Polymarket
    # ═══════════════════════════════════════════════════════════════════════

    def amend(
        self,
        order_id: str,
        new_price: Optional[float] = None,
        new_qty: Optional[float] = None,
    ) -> Dict:
        """Modify a resting order's price and/or quantity. Venue-agnostic.

        Routes through ``PATCH /v1/orders/{order_id}``. The graph engine
        currently executes this as a parent-order amend / cancel-replace
        workflow; queue position is not guaranteed through this SDK path.
        Kalshi's venue transport supports native ``/amend`` below this layer,
        but CC does not yet preserve that native amend window end-to-end.
        Queue-sensitive strategies should branch on ``mode``.

        Args:
            order_id: The ``node_order_id`` returned by buy/sell/graph.
            new_price: New limit price in the venue's natural units
                (0.0–1.0 for prediction markets). Omit to keep current.
            new_qty: New total quantity (not a delta). Omit to keep current.

        Returns:
            ``{"order_id": str, "mode": "cancel_replace", "status": str}``
        """
        if new_price is None and new_qty is None:
            raise ValueError("amend: must pass at least one of new_price or new_qty")
        body: Dict[str, Any] = {}
        if new_qty is not None:
            body["new_qty_1e8"] = int(new_qty * 1e8)
        if new_price is not None:
            body["new_constraints"] = {"max_price_1e9": int(new_price * 1e9)}
        resp = self._patch(f"/v1/orders/{_enc(order_id)}", body)
        return {
            "order_id": (resp or {}).get("node_order_id", order_id),
            "mode": "cancel_replace",
            "status": (resp or {}).get("status"),
        }

    def decrease(self, order_id: str, reduce_by: float) -> Dict:
        """Shrink a resting order without touching its price.

        Two round-trips today: reads the current size, computes the new
        total, then issues an amend. Kalshi's venue transport supports native
        ``/decrease`` below this layer, but CC does not yet preserve that
        native decrease path end-to-end through this SDK method.

        Raises ``SequenceError(400)`` if ``reduce_by`` would bring the
        remaining qty to ≤ 0 — callers should ``cancel()`` instead.
        """
        if reduce_by <= 0:
            raise ValueError("decrease: reduce_by must be > 0")
        current = self.order(order_id)
        current_qty_1e8 = int(current.get("qty_1e8", 0))
        new_qty = (current_qty_1e8 / 1e8) - reduce_by
        if new_qty <= 0:
            raise SequenceError(
                400,
                "decrease: reduce_by exceeds remaining quantity — cancel instead",
            )
        amend = self.amend(order_id, new_qty=new_qty)
        return {
            "order_id": amend["order_id"],
            "mode": "cancel_replace_shrink",
            "status": amend.get("status"),
        }

    def redeem(self, slug: str, venue: str) -> Dict:
        """Claim winnings from a resolved prediction market. Uniform verb.

        - **Kalshi** auto-settles on the venue side. Returns immediately
          with ``mode="auto_settled"`` — no action taken, nothing to do.
          Balance already reflects the payout.
        - **Polymarket** submits an L2-HMAC-signed request to the CLOB
          relayer using the credentials stored via ``connect_venue()``.
          Returns ``mode="relayer_submitted"``; on-chain USDC transfer
          completes asynchronously (typically minutes).

        Returns:
            ``{
                "mode": "auto_settled" | "relayer_submitted" | "noop",
                "venue": str,
                "slug": str,
                "condition_id": Optional[str],   # Polymarket only
                "token_ids": Optional[List[str]], # Polymarket only
                "note": str,
            }``
        """
        return self._post(
            f"/v1/markets/{_enc(slug)}/redeem?venue={_enc(venue)}",
            {},
        )

    def batch(self, venue: str) -> "_BatchBuilder":
        """Start a batch of submits/cancels targeted at one venue.

        Usage:
            with seq.batch("kalshi") as b:
                b.buy_limit("KXBTCZ-26DEC31-T99000", 10, 0.55)
                b.cancel("some_resting_order_id")
            # result = b.result  (populated on __exit__)

        Or explicit:
            result = (
                seq.batch("kalshi")
                .buy("KXBTCZ-...", 10)
                .cancel("id")
                .end()
            )

        This SDK builder submits graph roots serially and returns
        ``mode="serial"``. Kalshi and Polymarket both have native venue batch
        endpoints below this graph layer, but CC does not yet preserve a
        native venue batch window end-to-end through this helper.
        """
        return _BatchBuilder(self, venue)

    def fills(self, limit: int = 50, offset: int = 0,
              symbol: Optional[str] = None) -> Any:
        """Get fill history."""
        path = f"/v1/fills?limit={limit}&offset={offset}"
        if symbol:
            path += f"&symbol={_enc(symbol)}"
        return self._get(path)

    # ═══════════════════════════════════════════════════════════════════════
    # Level 3: Orchestrate
    # ═══════════════════════════════════════════════════════════════════════

    def node(self, node_id: str, symbol: str, side: str, qty: float,
             venue: Optional[str] = None, policy: Optional[str] = None,
             urgency: Optional[str] = None, limit_price: Optional[float] = None,
             instrument_type: str = "spot") -> Dict:
        """Build a graph node (helper for graph())."""
        order_type = "market"
        if limit_price is not None:
            order_type = {"limit": {"price_1e9": int(limit_price * 1e9)}}
        n = {
            "node_id": node_id,
            "instrument": {"symbol": symbol, "type": instrument_type, "venue": venue},
            "side": side,
            "order_type": order_type,
            "quantity": {"fixed": {"qty_1e8": int(qty * 1e8)}},
            "execution": {},
            "activation": "root",
        }
        if policy:
            n["execution"]["policy"] = policy
        if urgency:
            n["execution"]["urgency"] = urgency
        return n

    def edge(self, from_node: str, to_node: str,
             trigger: str = "on_fill", value: Optional[float] = None) -> Dict:
        """Build a graph edge (helper for graph())."""
        e = {"edge_id": f"e_{from_node}_{to_node}",
             "from_node": from_node, "to_node": to_node, "trigger": trigger}
        if trigger == "fill_pct" and value is not None:
            e["trigger"] = "on_fill_ratio"
            e["condition"] = {"fill_ratio_gte": value}
        return e

    def graph(self, nodes: List[Dict], edges: Optional[List[Dict]] = None,
              sandbox: bool = False) -> Dict:
        """Submit an execution graph. Returns {graph_id, status, node_count, edge_count}."""
        # Set activation: first node without incoming edges = root, rest = wait
        incoming = {e["to_node"] for e in (edges or [])}
        for n in nodes:
            n["activation"] = "wait" if n["node_id"] in incoming else "root"
        payload = {"nodes": nodes, "edges": edges or [], "is_sandbox": sandbox}
        return self._post("/v1/orders", payload)

    def graph_status(self, graph_id: str) -> Dict:
        """Get execution graph status."""
        return self._get(f"/v1/execution_graphs/{graph_id}")

    def graph_cancel(self, graph_id: str) -> None:
        """Cancel an execution graph."""
        self._delete(f"/v1/execution_graphs/{graph_id}")

    def graph_resume(self, graph_id: str) -> None:
        """Resume a paused execution graph."""
        self._post_empty(f"/v1/execution_graphs/{graph_id}/resume")

    # ═══════════════════════════════════════════════════════════════════════
    # Level 4: Automate
    # ═══════════════════════════════════════════════════════════════════════

    def deploy_algo(self, name: str, wasm_path: str,
                    symbols: List[str]) -> Dict:
        """Deploy a WASM algo from a file path."""
        import base64
        with open(wasm_path, "rb") as f:
            wasm_b64 = base64.b64encode(f.read()).decode()
        return self._post("/v1/deployments", {
            "name": name, "wasm_base64": wasm_b64,
            "symbols": symbols, "start_immediately": True,
        })

    def algo_status(self, deployment_id: str) -> Dict:
        """Get deployment status."""
        return self._get(f"/v1/deployments/{deployment_id}")

    def algo_start(self, deployment_id: str) -> None:
        self._post_empty(f"/v1/deployments/{deployment_id}/start")

    def algo_stop(self, deployment_id: str) -> None:
        self._post_empty(f"/v1/deployments/{deployment_id}/stop")

    def algo_undeploy(self, deployment_id: str) -> None:
        self._delete(f"/v1/deployments/{deployment_id}")

    def algo_logs(self, deployment_id: str, limit: int = 200) -> Any:
        return self._get(f"/v1/deployments/{deployment_id}/logs?limit={limit}")

    def algo_mesh(self, deployment_id: str) -> Any:
        return self._get(f"/v1/deployments/{deployment_id}/mesh")

    # ─── Algos keyed by symbol (Level-4 product surface) ───────────────────
    # /v1/algos/* is keyed by symbol (one running WASM per symbol per
    # client). Distinct from /v1/deployments/* which is the underlying
    # CRUD primitive.

    def algos(self, detail: Optional[str] = None) -> Any:
        """List deployed algos. ``detail='edge'`` for per-edge breakdown.
        `GET /v1/algos`
        """
        path = "/v1/algos"
        if detail:
            path += f"?detail={_enc(detail)}"
        return self._get(path)

    def algo(self, symbol: str) -> Any:
        """Algo status for a symbol. `GET /v1/algos/:symbol`"""
        return self._get(f"/v1/algos/{_enc(symbol)}")

    def algo_start_by_symbol(self, symbol: str) -> None:
        """Start an algo by symbol. `POST /v1/algos/:symbol/start`"""
        self._post_empty(f"/v1/algos/{_enc(symbol)}/start")

    def algo_stop_by_symbol(self, symbol: str) -> None:
        """Stop an algo by symbol. `POST /v1/algos/:symbol/stop`"""
        self._post_empty(f"/v1/algos/{_enc(symbol)}/stop")

    def algo_logs_by_symbol(self, symbol: str) -> Any:
        """Algo logs. `GET /v1/algos/:symbol/logs`"""
        return self._get(f"/v1/algos/{_enc(symbol)}/logs")

    def algo_stats(self, symbol: str) -> Any:
        """Algo runtime stats. `GET /v1/algos/:symbol/stats`"""
        return self._get(f"/v1/algos/{_enc(symbol)}/stats")

    # ─── Hosted strategies (Level 4-5 lifecycle) ───────────────────────────
    # Full CRUD is wrapped here. The `sequence strategy push` CLI is one
    # ergonomic frontend (it tar+base64-encodes a project tree); programmatic
    # callers can construct artifacts however they like and call create_strategy
    # directly. The CC enforces tier quotas, validates the artifact, and
    # encrypts secrets/sequence_api_key before storage.

    def create_strategy(
        self,
        name: str,
        runtime: str,
        entrypoint: str,
        artifact_base64: str,
        manifest: Optional[Dict] = None,
        placement: Optional[Dict] = None,
        risk: Optional[Dict] = None,
        resources: Optional[Dict] = None,
        start_immediately: bool = False,
        sequence_api_key: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        secrets: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """Create a hosted strategy. `POST /v1/strategies`

        name: Human-readable strategy name.
        runtime: Currently only `"python"` is supported.
        entrypoint: File or binary entrypoint path inside the artifact.
        artifact_base64: Base64-encoded zip/tar of the strategy project tree.
            Caller is responsible for the encoding (e.g. `base64.b64encode(
            tarfile_bytes).decode()`).
        manifest: Original manifest content, retained for reproducibility.
        placement: Placement hints, e.g. `{"mode":"auto","latency_target":["kalshi","polymarket"]}`.
        risk: Runtime risk envelope. CC enforcement remains authoritative.
        resources: Container resource request. CC default is small (250m CPU,
            512MiB RAM) for sandbox MVP; raise for production loads.
        start_immediately: If True, mark desired state as running so a runner
            picks it up without a separate `strategy_start` call.
        sequence_api_key: Raw Sequence API key to inject into the strategy as
            SEQUENCE_API_KEY. CC validates ownership, encrypts before storage,
            never returns it. Pass None to inherit the runner's default.
        env: Plain (non-secret) env vars merged into the strategy process.
            Visible in `strategy()` get responses.
        secrets: Secret env vars. AEAD-sealed before persistence; never
            returned in API responses. Decrypted only when a runner claims.
        """
        body: Dict[str, Any] = {
            "name": name,
            "runtime": runtime,
            "entrypoint": entrypoint,
            "artifact_base64": artifact_base64,
            "start_immediately": start_immediately,
        }
        if manifest is not None:    body["manifest"] = manifest
        if placement is not None:   body["placement"] = placement
        if risk is not None:        body["risk"] = risk
        if resources is not None:   body["resources"] = resources
        if sequence_api_key:        body["sequence_api_key"] = sequence_api_key
        if env:                     body["env"] = env
        if secrets:                 body["secrets"] = secrets
        return self._post("/v1/strategies", body)

    def strategies(self) -> Any:
        """List hosted strategies. `GET /v1/strategies`"""
        return self._get("/v1/strategies")

    def strategy(self, strategy_id: str) -> Any:
        """Get a hosted strategy. `GET /v1/strategies/:id`"""
        return self._get(f"/v1/strategies/{_enc(strategy_id)}")

    def strategy_start(self, strategy_id: str) -> Any:
        """Start a hosted strategy. `POST /v1/strategies/:id/start`"""
        return self._post(f"/v1/strategies/{_enc(strategy_id)}/start", {})

    def strategy_stop(self, strategy_id: str) -> Any:
        """Stop a hosted strategy. `POST /v1/strategies/:id/stop`"""
        return self._post(f"/v1/strategies/{_enc(strategy_id)}/stop", {})

    def strategy_logs(self, strategy_id: str, run_id: Optional[str] = None) -> Any:
        """Hosted strategy logs. `GET /v1/strategies/:id/logs[?run_id=…]`

        run_id: Optional — return logs for a specific historical run rather
            than the latest one. Useful for post-mortem debugging when a
            strategy has been restarted multiple times.
        """
        path = f"/v1/strategies/{_enc(strategy_id)}/logs"
        if run_id:
            path += f"?run_id={_enc(run_id)}"
        return self._get(path)

    def strategy_delete(self, strategy_id: str) -> None:
        """Delete a hosted strategy. `DELETE /v1/strategies/:id`"""
        self._delete(f"/v1/strategies/{_enc(strategy_id)}")

    # ═══════════════════════════════════════════════════════════════════════
    # Level 5: Monitor
    # ═══════════════════════════════════════════════════════════════════════

    def tca(self, symbol: Optional[str] = None) -> Any:
        path = "/v1/tca"
        if symbol:
            path += f"?symbol={_enc(symbol)}"
        return self._get(path)

    def intel(self, symbol: str) -> Any:
        return self._get(f"/v1/intelligence/venues?symbol={_enc(symbol)}")

    def slippage(self, symbol: str, side: str = "buy") -> Any:
        return self._get(
            f"/v1/intelligence/slippage?symbol={_enc(symbol)}&side={side}"
            f"&sizes=1000,10000,100000,1000000")

    def routing(self, symbol: str, side: str = "buy", qty: float = 1.0) -> Any:
        return self._get(
            f"/v1/intelligence/routing?symbol={_enc(symbol)}&side={side}&qty={qty}")

    def depth(self, symbol: str) -> Any:
        return self._get(f"/v1/intelligence/depth?symbol={_enc(symbol)}")

    def polymarket_rewards(self, token_id: Optional[str] = None) -> Any:
        """Polymarket maker-rewards config.

        Without ``token_id``: list every token currently in an active
        rewards program. With ``token_id``: config for one token (404s
        if not in any program).

        Each entry has:
            token_id, condition_id, rewards_min_size, rewards_max_spread,
            rate_per_day_usdc, current_spread, reward_end_unix_s.

        Server-side cache refreshes every 5 min (override via
        ``POLYMARKET_REWARDS_POLL_SECS``). Use this to:

          - Filter MM strategies to only rewards-eligible markets.
          - Estimate daily reward accrual = ``rate_per_day_usdc *
            (your_resting_notional / total_resting_notional)`` —
            assumes you're within the spread band.
          - Compare true MM P&L = spread_capture + accrued_rewards.
        """
        if token_id:
            return self._get(f"/v1/polymarket/rewards/{_enc(token_id)}")
        return self._get("/v1/polymarket/rewards")

    def forecast(self, symbol: str, side: str, qty: float) -> Any:
        return self._get(
            f"/v1/execution/forecast?symbol={_enc(symbol)}&side={side}&qty={qty}")

    def execution_live(self, node_order_id: str) -> Any:
        return self._get(f"/v1/execution/live/{_enc(node_order_id)}")

    def execution_review(self, node_order_id: str) -> Any:
        return self._get(f"/v1/execution/review/{_enc(node_order_id)}")

    def execution_summary(self) -> Any:
        return self._get("/v1/execution/summary")

    def trace(self, node_order_id: str) -> Any:
        return self._get(f"/v1/traces?node_order_id={_enc(node_order_id)}&limit=100")

    # ═══════════════════════════════════════════════════════════════════════
    # Internal
    # ═══════════════════════════════════════════════════════════════════════

    def _submit_order(self, symbol: str, side: str, qty: float, **kwargs) -> Dict:
        """Build and submit an order as a 1-node ExecutionGraph."""
        qty_1e8 = int(qty * 1e8)
        order_type = "market"
        if kwargs.get("limit_price"):
            order_type = {"limit": {"price_1e9": int(kwargs["limit_price"] * 1e9)}}

        execution = {}
        for key in ("urgency", "policy", "max_slippage_bps", "horizon_ms", "tif"):
            if key in kwargs and kwargs[key] is not None:
                execution[key] = kwargs[key]

        node = {
            "node_id": "order",
            "instrument": {
                "symbol": symbol,
                "type": kwargs.get("instrument_type", "spot"),
                "venue": kwargs.get("venue"),
            },
            "side": side,
            "order_type": order_type,
            "quantity": {"fixed": {"qty_1e8": qty_1e8}},
            "execution": execution,
            "activation": "root",
        }
        payload = {
            "nodes": [node],
            "edges": [],
            "is_sandbox": kwargs.get("sandbox", False),
        }
        return self._post("/v1/orders", payload)

    # ═══════════════════════════════════════════════════════════════════════
    # Streaming (Level 5) — async iterator over the unified /v1/stream WS
    # ═══════════════════════════════════════════════════════════════════════

    async def stream(self, channels: List[str]):
        """Async iterator yielding (channel, data) tuples from /v1/stream.

        `channels` is a list of channel strings. Valid channels:
            - prices:{symbol}       — NBBO updates. Payload:
                                      {"bid","ask","mid","bid_sz","ask_sz",
                                       "ts_ns"}.
            - book:{symbol}         — consolidated full-depth book, up to
                                      100 levels per side (MAX_LEVELS).
                                      Payload: {"bids":[[px,sz],...],
                                      "asks":[[px,sz],...], "ts_ns"}.
                                      Each frame is a full snapshot, not a
                                      delta — no reconstruction needed.
                                      Cadence: edge ticks every CC_BOOK_MS
                                      (default 25ms, Polymarket 5ms) and
                                      only emits when the top-N hash
                                      changes — quiet markets send nothing.
                                      A burst of raw updates between ticks
                                      coalesces into one frame. Cold-
                                      subscribe first frame ~900ms.
            - orders                — your order lifecycle events
            - fills                 — your fills
            - routing               — SOR routing decisions
            - tca                   — post-completion TCA reports per order
                                      (achieved VWAP vs arrival, fees,
                                      savings vs single-venue, venue mix)
            - traces:{deploy_id}    — algo trace events
            - deployment:{deploy_id} — deployment lifecycle events
            - fair_price            — VWAP-across-depth fair price (all
                                      underlyings)
            - fair_price:{underlying} — fair price for one underlying
            - funding               — funding rate updates (all venues)
            - funding:{venue}       — funding for one venue
            - funding:{venue}:{symbol} — funding for one instrument

        Subscribe/unsubscribe acks ({"subscribed":[...],"rejected":[...]})
        and error envelopes are silently filtered — only frames carrying a
        "channel" field are yielded as (channel, data) tuples.

        Symbols are venue-agnostic: CEX tickers (e.g. "BTC-USD"), Kalshi
        tickers (e.g. "KXBTCD-26APR3018-T62500"), and Polymarket outcome
        token-id strings all plug into `prices:` and `book:` identically.

        Requires the optional `websockets` dependency:
            pip install sequence-markets[stream]

        Example:
            async for channel, data in seq.stream(["fills", "tca"]):
                if channel == "fills":
                    print(f"fill: {data}")
                elif channel == "tca":
                    print(f"tca: achieved={data['achieved_vwap_1e9']} "
                          f"vs benchmark={data['benchmark_vwap_1e9']}")

        Raises `ImportError` if `websockets` is not installed.
        """
        try:
            import websockets
        except ImportError as e:
            raise ImportError(
                "streaming requires the 'websockets' package — "
                "install with: pip install sequence-markets[stream]"
            ) from e

        # http:// -> ws://, https:// -> wss://
        ws_url = self._base_url.replace("http://", "ws://", 1).replace("https://", "wss://", 1) + "/v1/stream"
        headers = {"Authorization": f"Bearer {self._api_key}"}

        # `close_timeout` bounds the cleanup when the consumer stops iterating
        # (Jupyter stop button, loop break, kernel interrupt). Without it, an
        # ungraceful close can hang long enough to crash the notebook kernel.
        ws = await websockets.connect(
            ws_url,
            additional_headers=headers,
            close_timeout=2,
            open_timeout=10,
        )
        try:
            await ws.send(json.dumps({"subscribe": channels}))
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                ch = msg.get("channel")
                data = msg.get("data")
                if ch is not None:
                    yield ch, data
        finally:
            # Close deterministically regardless of how we got here (break,
            # GeneratorExit, CancelledError, upstream exception). Swallow
            # close-time errors — the consumer has already stopped caring.
            try:
                await ws.close()
            except Exception:
                pass

    async def stream_new_markets(self):
        """Async iterator yielding each prediction market the moment it's minted.

        Backed by `/v1/ws/new_markets`. Emits a dict per market with the full
        payload you need to quote and trade it immediately (no follow-up REST):

            {
              "kind": "new_market",
              "venue": "polymarket",
              "slug": "btc-updown-5m-...",
              "condition_id": "0x...",
              "question": "Bitcoin Up or Down - ...",
              "outcomes": ["Up", "Down"],
              "outcome_token_ids": ["...", "..."],
              "neg_risk": false,
              "tick_1e9": 10000000,
              "fee_schedule": {"exponent": 1, "rate_1e8": 7200000,
                               "taker_only": true, "rebate_rate_1e8": 20000000},
              "start_ts_s": 1776657000,
              "end_ts_s":   1776657300,
              "observed_at_ns": 1776657000000000000
            }

        On connect the server flushes the last ~128 events from its replay
        ring, then streams live. Dedups across multi-region edges.

        Example:
            async for m in seq.stream_new_markets():
                print(m["slug"], m["question"])
                if "btc-updown" in m["slug"]:
                    seq.buy(m["outcome_token_ids"][0], qty=5)
        """
        async for evt in self._lifecycle_stream("/v1/ws/new_markets"):
            yield evt

    async def stream_resolved_markets(self):
        """Async iterator yielding each market the moment it resolves.

        Backed by `/v1/ws/market_resolved`. Emits:

            {
              "kind": "market_resolved",
              "venue": "polymarket",
              "condition_id": "0x...",
              "winning_outcome": "Up",
              "winning_token_id": "...",   # paid out $1
              "losing_token_id":  "...",   # paid out $0
              "observed_at_ns": ...
            }

        Complements `stream_new_markets()` — subscribe to both to see the
        full lifecycle of every prediction market.
        """
        async for evt in self._lifecycle_stream("/v1/ws/market_resolved"):
            yield evt

    async def _lifecycle_stream(self, path: str):
        try:
            import websockets
        except ImportError as e:
            raise ImportError(
                "streaming requires the 'websockets' package — "
                "install with: pip install sequence-markets[stream]"
            ) from e

        ws_url = (
            self._base_url.replace("http://", "ws://", 1).replace("https://", "wss://", 1)
            + path
        )
        headers = {"Authorization": f"Bearer {self._api_key}"}
        ws = await websockets.connect(
            ws_url,
            additional_headers=headers,
            close_timeout=2,
            open_timeout=10,
        )
        try:
            async for raw in ws:
                try:
                    yield json.loads(raw)
                except json.JSONDecodeError:
                    continue
        finally:
            try:
                await ws.close()
            except Exception:
                pass

    def _get(self, path: str) -> Any:
        return self._request("GET", path)

    def _post(self, path: str, body: Any) -> Any:
        return self._request("POST", path, body)

    def _post_empty(self, path: str) -> None:
        self._request("POST", path)

    def _put(self, path: str, body: Any) -> None:
        self._request("PUT", path, body)

    def _patch(self, path: str, body: Any) -> Any:
        return self._request("PATCH", path, body)

    def _delete(self, path: str) -> None:
        self._request("DELETE", path)

    def _request(self, method: str, path: str, body: Any = None) -> Any:
        url = f"{self._base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        data = json.dumps(body).encode() if body else None

        # Retry policy:
        #   - 5xx (502/503/504): exp backoff 0.5/1/2s — Sequence is fronted
        #     by Caddy + load balancers and gateway-level errors are usually
        #     transient (rolling redeploy mid-flight, edge container restart).
        #   - 429 Too Many Requests: honor `Retry-After` header verbatim
        #     when present (ISO seconds), otherwise fall back to exp backoff.
        #     Caller-side concurrency caps (max_concurrent ctor arg) reduce
        #     how often this fires but don't eliminate it under bursts.
        #   - Network errors (URLError, timeout, BrokenPipe): always retry
        #     within budget. urllib raises these as URLError subclasses.
        #   - 4xx other than 429: fail-fast, no retry. The caller built a
        #     bad request; retrying won't fix it.
        # Synchronous semaphore (when configured) wraps the entire retry
        # window so concurrency caps are honored across attempts.
        attempts = self._max_retries + 1
        backoffs = [0.5, 1.0, 2.0]

        if self._sem is not None:
            self._sem.acquire()
        try:
            last_err: Optional[BaseException] = None
            for attempt in range(attempts):
                req = urllib.request.Request(
                    url, data=data, headers=headers, method=method,
                )
                try:
                    with urllib.request.urlopen(req, timeout=30) as resp:
                        raw = resp.read()
                        if not raw:
                            return None
                        return json.loads(raw)
                except urllib.error.HTTPError as e:
                    code = e.code
                    is_retryable = code in (429, 502, 503, 504)
                    if not is_retryable or attempt + 1 == attempts:
                        # Terminal — surface the body for the caller.
                        raw = e.read().decode(errors="replace")
                        try:
                            err = json.loads(raw)
                            msg = err.get("error", {})
                            if isinstance(msg, dict):
                                msg = msg.get("message", str(err))
                            elif isinstance(msg, str):
                                pass
                            else:
                                msg = str(err)
                        except (json.JSONDecodeError, AttributeError):
                            msg = raw[:200]
                        raise SequenceError(code, str(msg)) from None
                    # Decide sleep: 429 with Retry-After wins.
                    sleep_s = backoffs[min(attempt, len(backoffs) - 1)]
                    if code == 429:
                        retry_after = e.headers.get("Retry-After") if e.headers else None
                        if retry_after:
                            try:
                                sleep_s = max(sleep_s, float(retry_after))
                            except ValueError:
                                pass
                    time.sleep(sleep_s)
                    last_err = e
                except (urllib.error.URLError, ConnectionError, TimeoutError) as e:
                    if attempt + 1 == attempts:
                        raise SequenceError(0, f"network: {e}") from None
                    time.sleep(backoffs[min(attempt, len(backoffs) - 1)])
                    last_err = e
            # Defensive — loop exits either by return or by raise.
            raise SequenceError(0, f"retries exhausted: {last_err}")
        finally:
            if self._sem is not None:
                self._sem.release()


def _enc(s: str) -> str:
    return urllib.parse.quote(s, safe="")


class _BatchBuilder:
    """Builder returned by ``Sequence.batch(venue)``.

    Collects submits/cancels, then flushes on ``end()`` or when used as a
    context manager. The graph-level SDK path is serial today even on venues
    whose lower-level transports support native batch windows.

    Attributes:
        mode (str): ``"serial"`` today at the SDK graph layer.
        responses (list): per-op result dicts. Keys: ``submitted``
            (graph response body), ``cancelled`` (order_id), or ``error``
            (error string).
    """

    def __init__(self, client: "Sequence", venue: str):
        self._client = client
        self._venue = venue
        self._ops: List[Dict[str, Any]] = []
        self.mode: Optional[str] = None
        self.responses: List[Dict[str, Any]] = []

    def emulate(self) -> "_BatchBuilder":
        """Backward-compatible no-op; graph-level batching is serial today."""
        return self

    def buy(self, symbol: str, qty: float) -> "_BatchBuilder":
        """Enqueue a market buy."""
        self._ops.append({"op": "submit", "payload": self._simple(symbol, "buy", qty, None)})
        return self

    def sell(self, symbol: str, qty: float) -> "_BatchBuilder":
        """Enqueue a market sell."""
        self._ops.append({"op": "submit", "payload": self._simple(symbol, "sell", qty, None)})
        return self

    def buy_limit(self, symbol: str, qty: float, price: float) -> "_BatchBuilder":
        """Enqueue a limit buy. ``price`` is 0.0–1.0 for prediction markets."""
        self._ops.append({"op": "submit", "payload": self._simple(symbol, "buy", qty, price)})
        return self

    def sell_limit(self, symbol: str, qty: float, price: float) -> "_BatchBuilder":
        """Enqueue a limit sell."""
        self._ops.append({"op": "submit", "payload": self._simple(symbol, "sell", qty, price)})
        return self

    def cancel(self, order_id: str) -> "_BatchBuilder":
        """Enqueue a cancel."""
        self._ops.append({"op": "cancel", "order_id": order_id})
        return self

    def __len__(self) -> int:
        return len(self._ops)

    def __enter__(self) -> "_BatchBuilder":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        # Auto-flush on successful exit; swallow if the with-block itself
        # raised (caller sees their own exception).
        if exc_type is None:
            self.end()

    def end(self) -> Dict[str, Any]:
        """Flush. Returns ``{"mode": "serial", "responses": [...]}``."""
        self.mode = "serial"
        for op in self._ops:
            try:
                if op["op"] == "submit":
                    resp = self._client._post("/v1/orders", op["payload"])
                    self.responses.append({"submitted": resp})
                elif op["op"] == "cancel":
                    self._client._delete(f"/v1/orders/{_enc(op['order_id'])}")
                    self.responses.append({"cancelled": op["order_id"]})
            except SequenceError as e:
                self.responses.append({"error": str(e)})
            except Exception as e:  # noqa: BLE001
                self.responses.append({"error": f"{type(e).__name__}: {e}"})
        return {"mode": self.mode, "responses": self.responses}

    def _simple(
        self,
        symbol: str,
        side: str,
        qty: float,
        price: Optional[float],
    ) -> Dict[str, Any]:
        order_type: Any = "market"
        if price is not None:
            order_type = {"limit": {"price_1e9": int(price * 1e9)}}
        node = {
            "node_id": "order",
            "instrument": {"symbol": symbol, "type": "spot", "venue": self._venue},
            "side": side,
            "order_type": order_type,
            "quantity": {"fixed": {"qty_1e8": int(qty * 1e8)}},
            "execution": {},
            "activation": "root",
        }
        return {"nodes": [node], "edges": [], "is_sandbox": False}
