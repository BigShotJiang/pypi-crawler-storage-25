from unittest.mock import Mock

from classic.db_tools import Engine

from .dto import Task


def fake(rows):
    while True:
        yield


def test_queries_cache(engine: Engine):
    fake_compile = Mock(return_value=fake)
    query = engine.query('SELECT 1 WHERE FALSE').map_to(Task)
    query._compile_mapper = fake_compile

    fake_compile.assert_not_called()

    query.one()
    query.one()

    fake_compile.assert_called_once()
