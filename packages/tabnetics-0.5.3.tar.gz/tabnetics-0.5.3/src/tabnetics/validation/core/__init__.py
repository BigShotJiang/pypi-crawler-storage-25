"""Validation core helpers."""

