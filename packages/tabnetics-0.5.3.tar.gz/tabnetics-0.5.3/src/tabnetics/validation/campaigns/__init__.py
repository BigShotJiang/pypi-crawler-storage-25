"""Campaign-specific validation analyzers."""

