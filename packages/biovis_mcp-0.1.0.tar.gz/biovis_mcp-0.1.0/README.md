<p align="center">
  <img src="logo.jpg" alt="BioVis-MCP Logo" width="600">
</p>

# 🧬 BioVis-MCP: Automated Bioinformatics Visualization

> **"From raw data to publication-ready figures in seconds."**

`BioVis-MCP` is a high-performance Model Context Protocol (MCP) server that empowers Large Language Models (like Claude) with the ability to generate **publication-quality (300 DPI)** bioinformatics visualizations directly from raw biological data.

No more manual Matplotlib tweaking. Just send the data, and get a verified, manuscript-ready image path.

---

## ✨ Features (Phases 1-3)

### 📊 Visualization Suite
*   **Volcano Plots**: High-resolution visualization of differential expression, with automated significance highlighting (Up/Down regulated).
*   **PCA Plots**: Principal Component Analysis for sample relationship and variance insights.
*   **Expression Heatmaps**: Professional heatmaps with hierarchical clustering and customizable colormaps.
*   **MA Plots**: Classic M-versus-A plots for global genomic trends.
*   **Pathway Enrichment**: Horizontal bar charts and dynamic Bubble Charts (Gene Count vs. Significance).

### 📝 Reporting & AI Integration
*   **Smart Figure Captions**: Context-aware, statistically accurate scientific captions generated automatically.
*   **Comprehensive Reports**: Multi-figure assembly into professional **PDF** and **DOCX** documents.
*   **High DPI Standards**: All figures are generated at **300 DPI** using `bbox_inches='tight'` for Q1 journal compliance.

---

## 🛠️ Tech Stack
- **Framework**: FastMCP
- **Libraries**: Pandas, Scikit-learn, Scipy, Matplotlib, Seaborn
- **Export Formats**: PNG (Figures), PDF & DOCX (Reports)

---

## 🚀 Installation & Setup

### 1. Prerequisites
Ensure you have Python 3.10+ installed.

```bash
# Option A: Install from PyPI (Recommended)
pip install biovis-mcp

# Option B: Clone for development
git clone https://github.com/ZaEyAsa/biovis-mcp.git
cd biovis-mcp
pip install -e .
```

### 2. Connect to Claude Desktop
To integrate `BioVis-MCP` into your Claude Desktop, edit your `claude_desktop_config.json` file:

**Location (Windows):**
`%APPDATA%\Claude\claude_desktop_config.json`

**Add this configuration:**

```json
{
  "mcpServers": {
    "BioVis-MCP": {
      "command": "C:\\path\\to\\python.exe",
      "args": [
        "C:\\path\\to\\biovis-mcp\\server.py"
      ],
      "env": {
        "PYTHONPATH": "C:\\path\\to\\biovis-mcp"
      }
    }
  }
}
```

> [!IMPORTANT]
> - Replace `C:\\path\\to\\python.exe` with your actual Python executable path (find it using `where python` in CMD).
> - Replace `C:\\path\\to\\biovis-mcp` with the absolute path to your project directory.
> - Restart Claude Desktop after saving the configuration.

---

## 📖 Available Tools

*   `generate_volcano_plot(data, title, fc_threshold, pval_threshold)`
*   `generate_bar_enrichment(data, title, top_n, color)`
*   `generate_heatmap_plot(data, title, cluster, cmap)`
*   `generate_pca_plot(data, metadata, title, group_col)`
*   `generate_bubble_enrichment(data, title, top_n)`
*   `generate_ma_plot(data, title, pval_threshold)`
*   `get_figure_caption(tool_type, stats)`
*   `create_report(figures_with_captions, format, report_name)`

---

## 📁 Output Structure
- `/figures`: High-resolution PNG files.
- `/reports`: Formatted PDF and DOCX documents.

---

*Developed by ZaEyAsa — Your Advanced Agentic Bio-Visualization Assistant.*

---
<p align="center">
  <img src="logo.jpg" alt="BioVis-MCP Footer" width="150">
</p>
