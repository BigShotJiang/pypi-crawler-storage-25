import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
from sklearn.decomposition import PCA
from utils.style import set_pub_style, cleanup_plot

def plot_pca(data: list[dict], metadata: list[dict] = None, title: str = "PCA Plot", group_col: str = None):
    """
    Generate a Principal Component Analysis (PCA) plot.
    
    Expected schema for records in data:
    {
        "gene_id": str,
        "sample1": float,
        "sample2": float,
        ...
    }
    
    Expected schema for metadata (optional):
    {
        "sample_id": str,
        "condition": str,
        ...
    }
    """
    if not data:
        return {"status": "error", "message": "Data list is empty.", "code": "EMPTY_DATA"}
    
    try:
        df = pd.DataFrame(data)
        if "gene_id" not in df.columns:
            return {"status": "error", "message": "Missing required key: gene_id", "code": "MISSING_KEY"}
        
        df = df.set_index("gene_id")
        
        # PCA requires samples as rows
        pca_input = df.transpose()
        
        pca = PCA(n_components=2)
        pca_results = pca.fit_transform(pca_input)
        
        # Explained variance
        pc1_var = pca.explained_variance_ratio_[0] * 100
        pc2_var = pca.explained_variance_ratio_[1] * 100
        
        pca_df = pd.DataFrame(
            pca_results, 
            columns=['PC1', 'PC2'], 
            index=pca_input.index
        ).reset_index().rename(columns={'index': 'sample_id'})
        
        # Merge with metadata if provided
        hue = None
        if metadata and group_col:
            meta_df = pd.DataFrame(metadata)
            if group_col in meta_df.columns:
                pca_df = pca_df.merge(meta_df, on='sample_id', how='left')
                hue = group_col
            else:
                return {"status": "error", "message": f"group_col '{group_col}' not found in metadata.", "code": "INVALID_VALUE"}
                
        # Style
        set_pub_style()
        
        plt.figure(figsize=(10, 8))
        
        sns.scatterplot(data=pca_df, x='PC1', y='PC2', hue=hue, s=100, alpha=0.8)
        
        # Add labels for variance
        plt.xlabel(f'PC1 ({pc1_var:.2f}%)')
        plt.ylabel(f'PC2 ({pc2_var:.2f}%)')
        plt.title(title)
        
        cleanup_plot()
        
        # Output directory
        output_dir = "figures"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"pca_{timestamp}.png"
        filepath = os.path.abspath(os.path.join(output_dir, filename))
        
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return {
            "status": "success",
            "file_path": filepath,
            "stats": {
                "pc1_variance": f"{pc1_var:.2f}%",
                "pc2_variance": f"{pc2_var:.2f}%",
                "num_samples": len(pca_df)
            },
            "next_tool_hint": {
                 "tool": "plot_heatmap",
                 "reason": "Visualize sample relationships using Heatmap."
            }
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "RUNTIME_ERROR"}
