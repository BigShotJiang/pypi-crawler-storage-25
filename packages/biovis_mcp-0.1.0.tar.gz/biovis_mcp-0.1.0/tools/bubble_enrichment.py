import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
from utils.style import set_pub_style, cleanup_plot

def plot_bubble_enrichment(data: list[dict], title: str = "Enrichment Bubble Chart", top_n: int = 20):
    """
    Generate a bubble chart for pathway enrichment results.
    
    Expected schema for records in data:
    {
        "pathway_name": str,
        "gene_count": int,
        "p_value": float
    }
    """
    if not data:
        return {"status": "error", "message": "Data list is empty.", "code": "EMPTY_DATA"}
    
    try:
        df = pd.DataFrame(data)
        required_keys = ["pathway_name", "gene_count", "p_value"]
        for key in required_keys:
            if key not in df.columns:
                return {"status": "error", "message": f"Missing required key: {key}", "code": "MISSING_KEY"}
        
        # Validation: Check for p-values being 0
        if (df['p_value'] == 0).any():
             return {"status": "error", "message": "p_value cannot be 0 (log10 is undefined).", "code": "INVALID_VALUE"}

        # Calculate -log10(p-value)
        df['-log10_p'] = -np.log10(df['p_value'])
        
        # Sort and take Top N
        df['gene_count'] = pd.to_numeric(df['gene_count'])
        df = df.sort_values(by='gene_count', ascending=False).head(top_n)
        df = df.sort_values(by='gene_count', ascending=True) # Reverse for bottom-up plot
        
        # Style
        set_pub_style()
        
        plt.figure(figsize=(10, 0.6 * len(df) + 2))
        
        # Plotting
        scatter = plt.scatter(
            x=df['gene_count'], 
            y=df['pathway_name'].apply(lambda x: (x[:47] + '...') if len(x) > 50 else x), 
            s=df['gene_count'] * 10, # Size proportional to gene_count
            c=df['-log10_p'], # Color by -log10(p-value)
            cmap='YlOrRd', 
            alpha=0.8, 
            edgecolors='k'
        )
        
        # Colorbar
        cbar = plt.colorbar(scatter)
        cbar.set_label('-log10(p-value)')
        
        plt.xlabel('Gene Count')
        plt.title(title)
        
        # Add labels to the dots
        for idx, row in df.iterrows():
            plt.text(row['gene_count'], row['pathway_name'][:47] + '...' if len(row['pathway_name']) > 50 else row['pathway_name'], 
                     f'{int(row["gene_count"])}', fontsize=8, ha='center', va='center')
            
        cleanup_plot()
        
        # Output directory
        output_dir = "figures"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"bubble_{timestamp}.png"
        filepath = os.path.abspath(os.path.join(output_dir, filename))
        
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return {
            "status": "success",
            "file_path": filepath,
            "stats": {
                "total_pathways_input": len(data),
                "pathways_shown": len(df),
                "max_log10_p": f"{df['-log10_p'].max():.2f}"
            },
            "next_tool_hint": {
                 "tool": "search_literature",
                 "reason": "Search literature for the top enriched pathways."
            }
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "RUNTIME_ERROR"}
