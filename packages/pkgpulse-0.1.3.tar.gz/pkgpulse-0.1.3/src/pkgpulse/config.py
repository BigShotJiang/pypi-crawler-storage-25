from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11
    import tomli as tomllib


def _expand_env(value: Any) -> Any:
    if isinstance(value, str):
        return os.path.expandvars(os.path.expanduser(value))
    if isinstance(value, list):
        return [_expand_env(item) for item in value]
    if isinstance(value, dict):
        return {key: _expand_env(item) for key, item in value.items()}
    return value


@dataclass(slots=True)
class StateConfig:
    oldver: Path
    newver: Path


@dataclass(slots=True)
class NvcheckerConfig:
    keyfile: Path | None = None
    max_concurrency: int = 20
    tries: int = 1
    httplib: str | None = None
    http_timeout: int = 20
    source_configs: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass(slots=True)
class CheckSpec:
    entry: dict[str, Any]


@dataclass(slots=True)
class ActionSpec:
    type: str
    when: str = "changed"
    config: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TargetSpec:
    name: str
    template: Path
    output: Path
    context: dict[str, Any] = field(default_factory=dict)
    check: CheckSpec | None = None
    actions: list[ActionSpec] = field(default_factory=list)


@dataclass(slots=True)
class Config:
    source_path: Path
    state: StateConfig
    nvchecker: NvcheckerConfig
    targets: list[TargetSpec] = field(default_factory=list)

    @property
    def root(self) -> Path:
        return self.source_path.parent


def _resolve_path(base: Path, value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def load_config(path: Path) -> Config:
    with path.open("rb") as handle:
        raw = tomllib.load(handle)

    payload = raw.get("tool", {}).get("pkgpulse", raw)
    payload = _expand_env(payload)
    root = path.resolve().parent

    state_payload = payload.get("state", {})
    state = StateConfig(
        oldver=_resolve_path(root, state_payload.get("oldver", ".pkgpulse/oldver.json")),
        newver=_resolve_path(root, state_payload.get("newver", ".pkgpulse/newver.json")),
    )

    nv_payload = dict(payload.get("nvchecker", {}))
    nvchecker = NvcheckerConfig(
        keyfile=(_resolve_path(root, nv_payload["keyfile"]) if nv_payload.get("keyfile") else None),
        max_concurrency=int(nv_payload.get("max_concurrency", 20)),
        tries=int(nv_payload.get("tries", 1)),
        httplib=nv_payload.get("httplib"),
        http_timeout=int(nv_payload.get("http_timeout", 20)),
        source_configs=dict(nv_payload.get("source", {})),
    )

    target_items = payload.get("targets", payload.get("jobs", []))
    targets: list[TargetSpec] = []
    for item in target_items:
        actions: list[ActionSpec] = []
        for action_data in item.get("actions", []):
            action_copy = dict(action_data)
            action_type = action_copy.pop("type", action_copy.pop("kind", None))
            if not action_type:
                raise ValueError(f"target {item.get('name')!r} has an action without type")
            when = action_copy.pop("when", "changed")
            actions.append(ActionSpec(type=action_type, when=when, config=action_copy))

        check = None
        if "check" in item and item["check"] is not None:
            check = CheckSpec(entry=dict(item["check"]))
        elif "update" in item and item["update"] is not None:
            update_payload = dict(item["update"])
            update_payload.pop("kind", None)
            check = CheckSpec(entry=update_payload)

        targets.append(
            TargetSpec(
                name=item["name"],
                template=_resolve_path(root, item["template"]),
                output=_resolve_path(root, item["output"]),
                context=dict(item.get("context", {})),
                check=check,
                actions=actions,
            )
        )

    return Config(source_path=path.resolve(), state=state, nvchecker=nvchecker, targets=targets)
