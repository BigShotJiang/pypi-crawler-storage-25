from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .actions import ActionResult, build_action_context, dispatch_action

if TYPE_CHECKING:
    from .actions import ActionContext
    from .config import ActionSpec, Config, TargetSpec
    from .nvchecker import CheckResult
    from .render import RenderResult


def should_run_action(
    action: ActionSpec,
    check: CheckResult | None,
    render: RenderResult,
) -> bool:
    when = action.when
    if when == "always":
        return True
    if when == "changed":
        return render.changed
    if when == "updated":
        return check is not None and check.changed
    if when == "rendered":
        return render.changed
    raise ValueError(f"unsupported action when={when!r}")


@dataclass(slots=True)
class ActionPipeline:
    context: ActionContext
    actions: list[ActionSpec]

    def execute(self) -> list[ActionResult]:
        results: list[ActionResult] = []

        for action in self.actions:
            try:
                if not should_run_action(action, self.context.check, self.context.render):
                    results.append(
                        ActionResult(
                            kind=action.type,
                            ok=True,
                            detail="condition not met",
                            skipped=True,
                        )
                    )
                    continue

                results.append(dispatch_action(action, self.context))
            except Exception as exc:
                results.append(ActionResult(kind=action.type, ok=False, detail=str(exc)))

        return results


def run_actions(
    config: Config,
    target: TargetSpec,
    check: CheckResult | None,
    render: RenderResult,
) -> list[ActionResult]:
    context = build_action_context(config, target, check, render)
    return ActionPipeline(context=context, actions=target.actions).execute()
