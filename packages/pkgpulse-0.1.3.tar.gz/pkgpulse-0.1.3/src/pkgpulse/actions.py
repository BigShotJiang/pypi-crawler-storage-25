from __future__ import annotations

import os
import subprocess
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .render import build_runtime_context, make_environment, render_inline

if TYPE_CHECKING:
    from .config import ActionSpec, Config, TargetSpec
    from .nvchecker import CheckResult
    from .render import RenderResult


@dataclass(slots=True)
class ActionResult:
    kind: str
    ok: bool
    detail: str
    skipped: bool = False


@dataclass(slots=True)
class ActionContext:
    config: Config
    target: TargetSpec
    check: CheckResult | None
    render: RenderResult
    template_context: dict[str, Any]


def build_action_context(
    config: Config,
    target: TargetSpec,
    check: CheckResult | None,
    render: RenderResult,
) -> ActionContext:
    context = build_runtime_context(config, target, check)
    context["render"] = {
        "changed": render.changed,
        "output": str(render.output),
        "diff": render.diff,
    }
    return ActionContext(
        config=config,
        target=target,
        check=check,
        render=render,
        template_context=context,
    )


def _run_command(
    command: list[str] | str,
    *,
    cwd: Path,
    env: dict[str, str],
    shell: bool,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=str(cwd),
        env=env,
        shell=shell,
        text=True,
        capture_output=True,
        check=False,
    )


def _run_exec_action(
    action: ActionSpec,
    context: ActionContext,
    root: Path,
) -> ActionResult:
    env = make_environment(root)
    command = render_inline(action.config["command"], env, context.template_context)
    extra_env = render_inline(action.config.get("env", {}), env, context.template_context)
    cwd_value = render_inline(action.config.get("cwd", "."), env, context.template_context)
    shell = bool(action.config.get("shell", False))
    cwd = Path(cwd_value)
    if not cwd.is_absolute():
        cwd = (root / cwd).resolve()
    completed = _run_command(
        command,
        cwd=cwd,
        env={**os.environ, **{str(k): str(v) for k, v in extra_env.items()}},
        shell=shell,
    )
    detail = completed.stdout.strip() or completed.stderr.strip() or f"exit={completed.returncode}"
    return ActionResult(kind="exec", ok=completed.returncode == 0, detail=detail)


def _run_webhook_action(
    action: ActionSpec,
    context: ActionContext,
    root: Path,
) -> ActionResult:
    env = make_environment(root)
    url = render_inline(action.config["url"], env, context.template_context)
    method = str(render_inline(action.config.get("method", "POST"), env, context.template_context))
    body = render_inline(action.config.get("body", ""), env, context.template_context)
    headers = render_inline(action.config.get("headers", {}), env, context.template_context)
    request = urllib.request.Request(
        url,
        data=str(body).encode("utf-8"),
        method=method,
        headers={str(k): str(v) for k, v in headers.items()},
    )
    with urllib.request.urlopen(request, timeout=15) as response:
        return ActionResult(
            kind="webhook",
            ok=200 <= response.status < 300,
            detail=f"HTTP {response.status}",
        )


def _run_git_action(
    action: ActionSpec,
    context: ActionContext,
    root: Path,
) -> ActionResult:
    env = make_environment(root)
    paths = render_inline(
        action.config.get("paths", [str(context.target.output.relative_to(root))]),
        env,
        context.template_context,
    )
    if isinstance(paths, str):
        paths = [paths]

    add = _run_command(["git", "add", *paths], cwd=root, env=os.environ.copy(), shell=False)
    if add.returncode != 0:
        return ActionResult(kind="git", ok=False, detail=add.stderr.strip() or add.stdout.strip())

    diff = _run_command(
        ["git", "diff", "--cached", "--quiet"],
        cwd=root,
        env=os.environ.copy(),
        shell=False,
    )
    if diff.returncode == 0:
        return ActionResult(kind="git", ok=True, detail="no staged changes", skipped=True)

    message = render_inline(action.config["message"], env, context.template_context)
    command = ["git"]
    if action.config.get("author_name"):
        command.extend(["-c", f"user.name={action.config['author_name']}"])
    if action.config.get("author_email"):
        command.extend(["-c", f"user.email={action.config['author_email']}"])
    command.extend(["commit", "-m", str(message)])
    if action.config.get("signoff", False):
        command.append("--signoff")

    commit = _run_command(command, cwd=root, env=os.environ.copy(), shell=False)
    if commit.returncode != 0:
        return ActionResult(
            kind="git",
            ok=False,
            detail=commit.stderr.strip() or commit.stdout.strip(),
        )

    if action.config.get("push", False):
        push = _run_command(["git", "push"], cwd=root, env=os.environ.copy(), shell=False)
        if push.returncode != 0:
            return ActionResult(
                kind="git",
                ok=False,
                detail=push.stderr.strip() or push.stdout.strip(),
            )
        return ActionResult(kind="git", ok=True, detail=push.stdout.strip() or "pushed")

    return ActionResult(kind="git", ok=True, detail=commit.stdout.strip() or "committed")


def dispatch_action(action: ActionSpec, context: ActionContext) -> ActionResult:
    if action.type == "exec":
        return _run_exec_action(action, context, context.config.root)
    if action.type == "webhook":
        return _run_webhook_action(action, context, context.config.root)
    if action.type == "git":
        return _run_git_action(action, context, context.config.root)
    return ActionResult(kind=action.type, ok=False, detail="unknown action type")
