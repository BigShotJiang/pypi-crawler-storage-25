from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .config import load_config
from .pipeline import run_pipeline, select_targets
from .render import make_environment


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pkgpulse",
        description="Template-driven package recipe updater powered by nvchecker.",
    )
    parser.add_argument(
        "-c",
        "--config",
        type=Path,
        default=Path("pkgpulse.toml"),
        help="Path to the TOML config file.",
    )
    parser.add_argument(
        "-t",
        "--target",
        action="append",
        default=[],
        help="Limit the run to one or more named targets.",
    )

    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("check", help="Run update checks and refresh newver state.")
    subparsers.add_parser("render", help="Check and render outputs without running actions.")
    subparsers.add_parser("diff", help="Check and print diffs without writing outputs.")
    subparsers.add_parser("validate", help="Load config and compile templates.")
    run_parser = subparsers.add_parser(
        "run",
        help="Check, render, and execute configured actions.",
    )
    run_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Do not write outputs or execute actions.",
    )
    return parser


def _print_target_summary(result) -> None:
    if result.error:
        print(f"{result.target.name}: error: {result.error}")
        return

    if result.check is not None:
        state = "updated" if result.check.changed else "up-to-date"
        print(
            f"{result.target.name}: {state} version={result.check.version}"
            + (f" old={result.check.old_version}" if result.check.old_version else "")
        )
    else:
        print(f"{result.target.name}: static target")

    if result.render is not None:
        render_state = "changed" if result.render.changed else "unchanged"
        print(f"{result.target.name}: render {render_state} -> {result.render.output}")

    for action in result.actions:
        status = "skipped" if action.skipped else ("ok" if action.ok else "failed")
        print(f"{result.target.name}: action {action.kind} {status}: {action.detail}")


def _run_common(
    args: argparse.Namespace,
    *,
    write: bool,
    execute_actions: bool,
    promote_versions: bool,
    show_diffs: bool,
) -> int:
    config = load_config(args.config)
    targets = select_targets(config, args.target)
    run = run_pipeline(
        config,
        targets,
        render_outputs=True,
        write=write,
        execute_actions=execute_actions,
        promote_versions=promote_versions,
    )

    for name, error in sorted(run.checks.failures.items()):
        print(f"{name}: check failed: {error}")

    for target_result in run.targets:
        _print_target_summary(target_result)
        if show_diffs and target_result.render is not None and target_result.render.changed:
            print(target_result.render.diff.rstrip())

    return 0 if run.ok else 1


def main(argv: list[str] | None = None) -> int:
    try:
        parser = build_parser()
        args = parser.parse_args(argv)
        command = args.command or "run"

        if command == "check":
            config = load_config(args.config)
            targets = select_targets(config, args.target)
            run = run_pipeline(
                config,
                targets,
                render_outputs=False,
                write=False,
                execute_actions=False,
                promote_versions=False,
            )
            for name, error in sorted(run.checks.failures.items()):
                print(f"{name}: check failed: {error}")
            for target_result in run.targets:
                _print_target_summary(target_result)
            return 0 if run.ok else 1
        if command == "render":
            return _run_common(
                args,
                write=True,
                execute_actions=False,
                promote_versions=False,
                show_diffs=False,
            )
        if command == "diff":
            return _run_common(
                args,
                write=False,
                execute_actions=False,
                promote_versions=False,
                show_diffs=True,
            )
        if command == "validate":
            config = load_config(args.config)
            targets = select_targets(config, args.target)
            for target in targets:
                env = make_environment(target.template.parent)
                env.get_template(target.template.name)
                print(f"{target.name}: template ok -> {target.template}")
            return 0
        if command == "run":
            dry_run = bool(getattr(args, "dry_run", False))
            return _run_common(
                args,
                write=not dry_run,
                execute_actions=not dry_run,
                promote_versions=not dry_run,
                show_diffs=dry_run,
            )

        parser.print_help()
        return 1
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
