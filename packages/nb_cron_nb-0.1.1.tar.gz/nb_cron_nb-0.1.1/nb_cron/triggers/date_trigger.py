from datetime import datetime, timezone
from typing import Any, Dict, Optional

from nb_cron.triggers.base import BaseTrigger


class DateTrigger(BaseTrigger):
    """One-time trigger that fires at a specific datetime."""

    def __init__(self, run_time: datetime):
        if run_time.tzinfo is None:
            run_time = run_time.replace(tzinfo=timezone.utc)
        self.run_time = run_time

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        if previous_fire_time is not None:
            return None
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        if self.run_time > now:
            return self.run_time
        return None

    def get_trigger_info(self) -> Dict[str, Any]:
        return {"type": "date", "run_time": self.run_time.isoformat()}

    def get_description(self, lang: str = "en") -> str:
        time_str = self.run_time.strftime("%Y-%m-%d %H:%M:%S")
        if lang == "zh":
            return f"在 {time_str} 执行一次"
        return f"Run once at {time_str}"

    def __repr__(self) -> str:
        return f"DateTrigger({self.run_time.isoformat()})"
