from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional


class BaseTrigger(ABC):

    @abstractmethod
    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        """Calculate next fire time after `now`, given the previous fire time."""

    @abstractmethod
    def get_trigger_info(self) -> dict:
        """Return serializable trigger configuration."""

    @abstractmethod
    def get_description(self, lang: str = "en") -> str:
        """Return human-readable description of this trigger."""
