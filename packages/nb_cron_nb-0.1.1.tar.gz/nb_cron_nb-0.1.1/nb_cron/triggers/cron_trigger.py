from datetime import datetime, timezone
from typing import Any, Dict, Optional

from croniter import croniter

from nb_cron.triggers.base import BaseTrigger


def _user_to_croniter(expression: str) -> str:
    """
    Convert user format (sec min hour day month dow)
    to croniter format (min hour day month dow sec).
    """
    fields = expression.strip().split()
    sec, min_, hour, day, month, dow = fields
    return f"{min_} {hour} {day} {month} {dow} {sec}"


def _croniter_to_user(expression: str) -> str:
    """
    Convert croniter format (min hour day month dow sec)
    back to user format (sec min hour day month dow).
    """
    fields = expression.strip().split()
    min_, hour, day, month, dow, sec = fields
    return f"{sec} {min_} {hour} {day} {month} {dow}"


class CronTrigger(BaseTrigger):
    """
    Cron trigger that REQUIRES exactly 6 fields:
        second  minute  hour  day_of_month  month  day_of_week

    5-field expressions will raise ValueError immediately.

    Internally converts to croniter's format (min hour day month dow sec)
    for calculation.
    """

    def __init__(self, expression: str):
        self.expression = self._validate(expression)
        self._croniter_expr = _user_to_croniter(self.expression)

    @staticmethod
    def _validate(expression: str) -> str:
        fields = expression.strip().split()
        if len(fields) != 6:
            raise ValueError(
                f"nb_cron requires exactly 6-field cron (second minute hour day month weekday), "
                f"got {len(fields)} fields: '{expression}'. "
                f"Example: '0 */5 * * * *' means every 5 minutes at second 0."
            )
        croniter_expr = _user_to_croniter(expression)
        try:
            croniter(croniter_expr)
        except (ValueError, KeyError, TypeError) as e:
            raise ValueError(f"Invalid cron expression: '{expression}' ({e})")
        return expression.strip()

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        base = previous_fire_time if previous_fire_time else now
        if base.tzinfo is None:
            base = base.replace(tzinfo=timezone.utc)
        cron = croniter(self._croniter_expr, base)
        next_time = cron.get_next(datetime)
        if next_time.tzinfo is None:
            next_time = next_time.replace(tzinfo=timezone.utc)
        if next_time <= now and previous_fire_time:
            cron = croniter(self._croniter_expr, now)
            next_time = cron.get_next(datetime)
            if next_time.tzinfo is None:
                next_time = next_time.replace(tzinfo=timezone.utc)
        return next_time

    def get_trigger_info(self) -> Dict[str, Any]:
        return {"type": "cron", "expression": self.expression}

    def get_description(self, lang: str = "en") -> str:
        from nb_cron.cron_utils.translator import explain_cron
        return explain_cron(self.expression, lang)

    def __repr__(self) -> str:
        return f"CronTrigger('{self.expression}')"
