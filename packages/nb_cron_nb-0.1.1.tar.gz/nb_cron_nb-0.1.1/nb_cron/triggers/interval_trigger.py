from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from nb_cron.triggers.base import BaseTrigger


class IntervalTrigger(BaseTrigger):

    def __init__(
        self,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        start_time: Optional[datetime] = None,
    ):
        self.interval = timedelta(
            weeks=weeks, days=days, hours=hours,
            minutes=minutes, seconds=seconds,
        )
        if self.interval.total_seconds() <= 0:
            raise ValueError("Interval must be positive")
        self.start_time = start_time
        self._weeks = weeks
        self._days = days
        self._hours = hours
        self._minutes = minutes
        self._seconds = seconds

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        if previous_fire_time is not None:
            if previous_fire_time.tzinfo is None:
                previous_fire_time = previous_fire_time.replace(tzinfo=timezone.utc)
            next_time = previous_fire_time + self.interval
            if next_time <= now:
                skipped = int((now - next_time).total_seconds() / self.interval.total_seconds())
                next_time += self.interval * (skipped + 1)
                if next_time <= now:
                    next_time += self.interval
            return next_time
        if self.start_time is not None:
            st = self.start_time
            if st.tzinfo is None:
                st = st.replace(tzinfo=timezone.utc)
            if st > now:
                return st
            skipped = int((now - st).total_seconds() / self.interval.total_seconds())
            next_time = st + self.interval * (skipped + 1)
            if next_time <= now:
                next_time += self.interval
            return next_time
        # 首次调度：尽快执行（下一拍 tick 内），而不是先空等一个整周期。
        # 之后由 previous_fire_time 分支按 interval 推进。
        return now

    def get_trigger_info(self) -> Dict[str, Any]:
        return {
            "type": "interval",
            "weeks": self._weeks,
            "days": self._days,
            "hours": self._hours,
            "minutes": self._minutes,
            "seconds": self._seconds,
        }

    def get_description(self, lang: str = "en") -> str:
        parts_en = []
        parts_zh = []
        if self._weeks:
            parts_en.append(f"{self._weeks} week{'s' if self._weeks > 1 else ''}")
            parts_zh.append(f"{self._weeks}周")
        if self._days:
            parts_en.append(f"{self._days} day{'s' if self._days > 1 else ''}")
            parts_zh.append(f"{self._days}天")
        if self._hours:
            parts_en.append(f"{self._hours} hour{'s' if self._hours > 1 else ''}")
            parts_zh.append(f"{self._hours}小时")
        if self._minutes:
            parts_en.append(f"{self._minutes} minute{'s' if self._minutes > 1 else ''}")
            parts_zh.append(f"{self._minutes}分钟")
        if self._seconds:
            parts_en.append(f"{self._seconds} second{'s' if self._seconds > 1 else ''}")
            parts_zh.append(f"{self._seconds}秒")
        if lang == "zh":
            return "每" + "".join(parts_zh) + "执行一次"
        return "Every " + " ".join(parts_en)

    def __repr__(self) -> str:
        total = self.interval.total_seconds()
        return f"IntervalTrigger(every {total}s)"
