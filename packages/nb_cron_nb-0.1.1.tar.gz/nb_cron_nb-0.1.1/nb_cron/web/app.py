"""
One-line app factories for FastAPI / Flask / Django.

Usage::

    # FastAPI
    from nb_cron.web import get_fastapi_app
    app = get_fastapi_app(cron)          # uvicorn module:app

    # Flask
    from nb_cron.web import get_flask_app
    app = get_flask_app(cron)            # flask run / gunicorn module:app

    # Django - in urls.py
    from nb_cron.web import get_django_urls
    urlpatterns += get_django_urls(cron)
"""
from pathlib import Path

from nb_cron.web.static_mime import guess_asset_content_type, register_static_mimetypes

STATIC_DIR = Path(__file__).parent / "static"

# Fix Windows: .js must not be served as text/plain (breaks ES modules)
register_static_mimetypes()


def get_fastapi_app(cron, title: str = "nb_cron", **kwargs):
    try:
        from fastapi import FastAPI
        from fastapi.middleware.cors import CORSMiddleware
        from fastapi.responses import FileResponse, HTMLResponse
    except ImportError:
        raise ImportError("Install with: pip install nb_cron_nb[fastapi]")

    from nb_cron.api.fastapi_app import create_router

    app = FastAPI(title=title, **kwargs)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(create_router(cron))

    @app.get("/")
    async def redirect_to_ui():
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/nb_cron/ui/")

    if STATIC_DIR.exists():
        assets_root = (STATIC_DIR / "assets").resolve()

        @app.get("/nb_cron/ui/favicon.svg")
        async def serve_favicon():
            favicon = STATIC_DIR / "favicon.svg"
            if favicon.exists():
                return FileResponse(str(favicon), media_type="image/svg+xml")
            return HTMLResponse("", status_code=404)

        @app.get("/nb_cron/ui/assets/{asset_path:path}")
        async def serve_ui_assets(asset_path: str):
            """Explicit MIME types — Windows mimetypes often serve .js as text/plain."""
            from fastapi import HTTPException

            target = (STATIC_DIR / "assets" / asset_path).resolve()
            try:
                target.relative_to(assets_root)
            except ValueError:
                raise HTTPException(status_code=404, detail="Not found")
            if not target.is_file():
                raise HTTPException(status_code=404, detail="Not found")
            return FileResponse(
                str(target),
                media_type=guess_asset_content_type(asset_path),
            )

        @app.get("/nb_cron/ui/{rest_of_path:path}")
        async def serve_spa(rest_of_path: str = ""):
            index = STATIC_DIR / "index.html"
            if index.exists():
                return FileResponse(str(index))
            return HTMLResponse("<h1>nb_cron UI not built</h1><p>Run: cd nb_cron_ui && npm run build</p>")

        @app.get("/nb_cron/ui")
        async def serve_spa_root():
            index = STATIC_DIR / "index.html"
            if index.exists():
                return FileResponse(str(index))
            return HTMLResponse("<h1>nb_cron UI not built</h1><p>Run: cd nb_cron_ui && npm run build</p>")

    return app


def get_flask_app(cron, **kwargs):
    try:
        from flask import Flask, send_from_directory, send_file
        from flask_cors import CORS
    except ImportError:
        try:
            from flask import Flask, send_from_directory, send_file
        except ImportError:
            raise ImportError("Install with: pip install nb_cron_nb[flask]")

    from nb_cron.api.flask_app import create_blueprint

    app = Flask(__name__, **kwargs)
    try:
        from flask_cors import CORS
        CORS(app)
    except ImportError:
        pass

    app.register_blueprint(create_blueprint(cron))

    @app.route("/")
    def redirect_to_ui():
        from flask import redirect
        return redirect("/nb_cron/ui/")

    if STATIC_DIR.exists():
        @app.route("/nb_cron/ui/favicon.svg")
        def serve_favicon():
            return send_from_directory(str(STATIC_DIR), "favicon.svg", mimetype="image/svg+xml")

        @app.route("/nb_cron/ui/assets/<path:filename>")
        def serve_assets(filename):
            return send_from_directory(
                str(STATIC_DIR / "assets"),
                filename,
                mimetype=guess_asset_content_type(filename),
            )

        @app.route("/nb_cron/ui")
        @app.route("/nb_cron/ui/")
        @app.route("/nb_cron/ui/<path:path>")
        def serve_spa(path=""):
            index = STATIC_DIR / "index.html"
            if index.exists():
                return send_file(str(index))
            return "<h1>nb_cron UI not built</h1><p>Run: cd nb_cron_ui && npm run build</p>", 200

    return app


def get_django_urls(cron):
    try:
        from django.urls import path
        from django.http import FileResponse as DjFileResponse, HttpResponse
    except ImportError:
        raise ImportError("Install with: pip install nb_cron_nb[django]")

    from nb_cron.api.django_app import create_router

    try:
        from ninja import NinjaAPI
    except ImportError:
        raise ImportError("Install with: pip install nb_cron_nb[django]")

    api = NinjaAPI(urls_namespace="nb_cron")
    api.add_router("/nb_cron/api", create_router(cron))

    assets_dir = (STATIC_DIR / "assets").resolve()

    def serve_ui_asset(request, path):
        from django.http import Http404

        target = (STATIC_DIR / "assets" / path).resolve()
        try:
            target.relative_to(assets_dir)
        except ValueError:
            raise Http404("Not found")
        if not target.is_file():
            raise Http404("Not found")
        return DjFileResponse(
            str(target),
            content_type=guess_asset_content_type(path),
        )

    def serve_spa(request, rest=""):
        index = STATIC_DIR / "index.html"
        if index.exists():
            return DjFileResponse(str(index), content_type="text/html")
        return HttpResponse(
            "<h1>nb_cron UI not built</h1><p>Run: cd nb_cron_ui && npm run build</p>"
        )

    def redirect_to_ui(request):
        from django.http import HttpResponseRedirect
        return HttpResponseRedirect("/nb_cron/ui/")

    urls = [
        path("", redirect_to_ui),
        path("nb_cron/api/", api.urls),
        path("nb_cron/ui/assets/<path:path>", serve_ui_asset),
        path("nb_cron/ui/", serve_spa),
        path("nb_cron/ui/<path:rest>", serve_spa),
    ]
    return urls
