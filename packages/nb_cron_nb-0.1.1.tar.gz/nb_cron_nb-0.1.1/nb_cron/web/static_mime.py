"""
Ensure correct Content-Type for Vite-built assets.

On Windows, mimetypes.guess_type() often returns text/plain for .js,
which breaks <script type="module"> in browsers (strict MIME check).
"""
import mimetypes
from pathlib import Path

_STATIC_TYPES = (
    (".js", "application/javascript"),
    (".mjs", "application/javascript"),
    (".cjs", "application/javascript"),
    (".css", "text/css"),
    (".json", "application/json"),
    (".map", "application/json"),
    (".svg", "image/svg+xml"),
    (".wasm", "application/wasm"),
    (".woff2", "font/woff2"),
    (".woff", "font/woff"),
    (".ttf", "font/ttf"),
    (".ico", "image/x-icon"),
)


def register_static_mimetypes() -> None:
    """Register MIME types so Starlette StaticFiles / uvicorn serve correct headers."""
    for ext, ctype in _STATIC_TYPES:
        mimetypes.add_type(ctype, ext, strict=True)


def guess_asset_content_type(filename: str) -> str:
    """Return Content-Type for a file under assets/; safe for Windows."""
    ext = Path(filename).suffix.lower()
    for e, ctype in _STATIC_TYPES:
        if e == ext:
            return ctype
    guessed, _ = mimetypes.guess_type(filename)
    if guessed and guessed != "text/plain":
        return guessed
    return "application/octet-stream"


register_static_mimetypes()
