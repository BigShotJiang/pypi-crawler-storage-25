import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

_ISO_TZ_RE = re.compile(r"([+-]\d{2}:\d{2})$")


def _parse_iso(s: str) -> datetime:
    """Parse ISO datetime string, compatible with Python 3.7+."""
    tz_match = _ISO_TZ_RE.search(s)
    if tz_match:
        tz_str = tz_match.group(1)
        base_str = s[:tz_match.start()]
        dt = datetime.fromisoformat(base_str)
        sign = 1 if tz_str[0] == "+" else -1
        hours, minutes = int(tz_str[1:3]), int(tz_str[4:6])
        from datetime import timedelta
        tz = timezone(timedelta(hours=sign * hours, minutes=sign * minutes))
        dt = dt.replace(tzinfo=tz)
    else:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    return dt


class Job:
    __slots__ = (
        "job_id", "func_ref", "trigger_type", "trigger_args",
        "args", "kwargs", "name", "status", "max_instances",
        "next_run_time", "created_at", "updated_at",
    )

    def __init__(
        self,
        job_id: str,
        func_ref: str,
        trigger_type: str,
        trigger_args: Optional[Dict[str, Any]] = None,
        args: Optional[Tuple] = None,
        kwargs: Optional[Dict[str, Any]] = None,
        name: Optional[str] = None,
        status: str = "active",
        max_instances: int = 1,
        next_run_time: Optional[datetime] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
    ):
        self.job_id = job_id
        self.func_ref = func_ref
        self.trigger_type = trigger_type
        self.trigger_args = trigger_args or {}
        self.args = args or ()
        self.kwargs = kwargs or {}
        self.name = name or job_id
        self.status = status
        self.max_instances = max_instances
        self.next_run_time = next_run_time
        self.created_at = created_at or datetime.now(timezone.utc)
        self.updated_at = updated_at or datetime.now(timezone.utc)

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "job_id": self.job_id,
            "func_ref": self.func_ref,
            "trigger_type": self.trigger_type,
            "trigger_args": self.trigger_args,
            "args": list(self.args),
            "kwargs": self.kwargs,
            "name": self.name,
            "status": self.status,
            "max_instances": self.max_instances,
            "next_run_time": self.next_run_time.isoformat() if self.next_run_time else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Job":
        data = dict(data)
        for key in ("next_run_time", "created_at", "updated_at"):
            val = data.get(key)
            if isinstance(val, str):
                data[key] = _parse_iso(val)
        if "args" in data and isinstance(data["args"], list):
            data["args"] = tuple(data["args"])
        return cls(**data)

    def __repr__(self) -> str:
        return (
            f"Job(id={self.job_id!r}, func={self.func_ref!r}, "
            f"trigger={self.trigger_type}, status={self.status}, "
            f"next_run={self.next_run_time})"
        )
