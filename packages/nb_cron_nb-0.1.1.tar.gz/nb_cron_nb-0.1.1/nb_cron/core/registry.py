from typing import Callable, Dict, List, Optional


class FunctionRegistry:
    _registry: Dict[str, Callable] = {}

    @classmethod
    def register(cls, func: Callable) -> str:
        """注册函数，返回 cron_func_name。函数必须先通过 @cron_register 注册。"""
        cron_name = getattr(func, "cron_func_name", None)
        if not cron_name:
            raise ValueError(
                f"函数 {func.__name__!r} 未注册 cron_func_name。"
                f"请先使用 @cron_register('名称') 装饰器注册函数。"
            )
        cls._registry[cron_name] = func
        return cron_name

    @classmethod
    def register_by_name(cls, cron_func_name: str, func: Callable) -> None:
        """以稳定名称注册函数。"""
        func.cron_func_name = cron_func_name  # type: ignore[attr-defined]
        cls._registry[cron_func_name] = func

    @classmethod
    def resolve(cls, ref: str) -> Callable:
        if ref in cls._registry:
            return cls._registry[ref]
        raise ValueError(
            f"Function '{ref}' not found in registry. "
            f"Did you forget to use @cron_register('{ref}')?"
        )

    @classmethod
    def is_registered(cls, ref: str) -> bool:
        return ref in cls._registry

    @classmethod
    def get_all(cls) -> Dict[str, Callable]:
        return dict(cls._registry)

    @classmethod
    def get_named_functions(cls) -> List[str]:
        """返回所有已注册的函数名称列表。"""
        return list(cls._registry.keys())

    @classmethod
    def clear(cls) -> None:
        cls._registry.clear()


def cron_register(cron_func_name: str, func: Optional[Callable] = None) -> Callable:
    """
    注册函数到 nb_cron 函数注册表，绑定一个稳定名称。

    用法::

        @cron_register('daily_backup')
        def backup_db():
            ...

        backup_db.cron_func_name  # 'daily_backup'

        # 函数调用形式
        cron_register('send_email', send_email_func)
    """
    if func is not None:
        FunctionRegistry.register_by_name(cron_func_name, func)
        return func

    def decorator(fn: Callable) -> Callable:
        FunctionRegistry.register_by_name(cron_func_name, fn)
        return fn
    return decorator


def add_cron_register(cron_func_name: str, func: Callable) -> None:
    """
    注册函数到 nb_cron 函数注册表（非装饰器形式）。

    用法::

        add_cron_register('daily_backup', backup_func)
    """
    FunctionRegistry.register_by_name(cron_func_name, func)
