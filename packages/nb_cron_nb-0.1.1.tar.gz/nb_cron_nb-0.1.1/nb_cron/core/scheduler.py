import logging
import re
import signal
import threading
import time
from datetime import datetime, timedelta
from typing import Callable, List, Optional, Union

from nb_cron.core.job import Job
from nb_cron.core.registry import FunctionRegistry
from nb_cron.executors.base_executor import BaseExecutor
from nb_cron.executors.threadpool import _ExecutionResult
from nb_cron.executors.thread_executor import ThreadExecutor
from nb_cron.locks.base import BaseLock
from nb_cron.locks.memory_lock import MemoryLock
from nb_cron.metrics.collector import MetricsCollector
from nb_cron.stores.base import BaseStore
from nb_cron.stores.memory import MemoryStore
from nb_cron.triggers.base import BaseTrigger
from nb_cron.triggers.cron_trigger import CronTrigger
from nb_cron.triggers.date_trigger import DateTrigger
from nb_cron.triggers.interval_trigger import IntervalTrigger
from nb_cron.utils import get_local_timezone, now as _now

logger = logging.getLogger("nb_cron")

_EVERY_RE = re.compile(
    r"^@every\s+(\d+)\s*(s|sec|second|seconds|m|min|minute|minutes|h|hour|hours|d|day|days|w|week|weeks)$",
    re.IGNORECASE,
)

_UNIT_MAP = {
    "s": "seconds", "sec": "seconds", "second": "seconds", "seconds": "seconds",
    "m": "minutes", "min": "minutes", "minute": "minutes", "minutes": "minutes",
    "h": "hours", "hour": "hours", "hours": "hours",
    "d": "days", "day": "days", "days": "days",
    "w": "weeks", "week": "weeks", "weeks": "weeks",
}

_DATE_FORMATS = [
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%d",
    "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M",
    "%Y/%m/%d",
    "%Y年%m月%d日 %H:%M:%S",
    "%Y年%m月%d日 %H:%M",
    "%Y年%m月%d日",
]


def _try_parse_date(expr: str, tz=None) -> Optional[datetime]:
    for fmt in _DATE_FORMATS:
        try:
            dt = datetime.strptime(expr, fmt)
            return dt.replace(tzinfo=tz or get_local_timezone())
        except ValueError:
            continue
    return None


def _parse_expression(expression: str, trigger: Optional[str] = None, tz=None) -> BaseTrigger:
    """解析表达式为触发器对象。"""
    expr = expression.strip()
    if trigger is not None:
        trigger = trigger.lower()
        if trigger == "cron":
            return CronTrigger(expr)
        if trigger == "interval":
            m = _EVERY_RE.match(expr)
            if m:
                val = int(m.group(1))
                unit = _UNIT_MAP[m.group(2).lower()]
                return IntervalTrigger(**{unit: val})
            m2 = re.match(r"^(\d+)\s*(s|sec|second|seconds|m|min|minute|minutes|h|hour|hours|d|day|days|w|week|weeks)$", expr, re.IGNORECASE)
            if m2:
                val = int(m2.group(1))
                unit = _UNIT_MAP[m2.group(2).lower()]
                return IntervalTrigger(**{unit: val})
            raise ValueError(f"trigger='interval' 但表达式无法解析: '{expr}'。示例: '30s', '5m', '@every 2h'")
        if trigger == "date":
            dt = _try_parse_date(expr, tz)
            if dt is None:
                raise ValueError(f"trigger='date' 但表达式无法解析为日期: '{expr}'。示例: '2026-10-01 09:00:00'")
            return DateTrigger(dt)
        raise ValueError(f"不支持的 trigger 类型: '{trigger}'。可选: 'cron', 'interval', 'date'")
    m = _EVERY_RE.match(expr)
    if m:
        val = int(m.group(1))
        unit = _UNIT_MAP[m.group(2).lower()]
        return IntervalTrigger(**{unit: val})
    if len(expr.split()) == 6:
        return CronTrigger(expr)
    dt = _try_parse_date(expr, tz)
    if dt is not None:
        return DateTrigger(dt)
    raise ValueError(
        f"无法识别的表达式: '{expr}'。支持的格式：\n"
        f"  6-field cron: '0 30 9 * * 1-5'（秒 分 时 日 月 周）\n"
        f"  间隔:          '@every 30s / 5m / 2h'  或  trigger='interval', expression='30s'\n"
        f"  指定时间:      '2026-10-01 09:00:00'  或  trigger='date', expression='2026-10-01'"
    )


class NbCron:
    """
    The one and only scheduler class you need.

    Usage::

        from nb_cron import NbCron, cron_register

        cron = NbCron("my_project")  # name 必传，隔离不同项目
        # cron = NbCron("my_project", "redis://localhost:6379/0")

        @cron.job("0 */5 * * * *")
        @cron_register('report')
        def task_a(): ...

        cron.start()  # 不阻塞，Ctrl+C 退出
    """

    def __init__(
        self,
        name: str,
        store_url: Optional[str] = None,
        max_workers: int = 20,
        tick_seconds: float = 1.0,
        misfire_grace_seconds: int = 60,
        tz=None,
        executor: Optional[BaseExecutor] = None,
    ):
        if not name or not name.strip():
            raise ValueError("NbCron name 不能为空。请传一个唯一名称标识你的项目，例如 NbCron('my_project')")
        self.name = name.strip()
        self.tz = tz or get_local_timezone()
        self.store: BaseStore = self._create_store(store_url, self.name)
        self.lock: BaseLock = self._create_lock(store_url, self.name)
        self.executor: BaseExecutor = executor or ThreadExecutor(max_workers=max_workers)
        # 若执行器支持 bind_cron（如 FunboostExecutor），注入自身引用
        if hasattr(self.executor, "bind_cron"):
            self.executor.bind_cron(self)
        self.metrics = MetricsCollector(self.store)
        self._tick_seconds = tick_seconds
        self._misfire_grace = misfire_grace_seconds
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._pending: List[dict] = []
        self._store_url = store_url
        self._stop_completed = False

    def _now(self) -> datetime:
        return _now(self.tz)

    # ── Store / Lock factory ──

    @staticmethod
    def _create_store(url: Optional[str], name: str) -> BaseStore:
        if url is None:
            return MemoryStore()
        if url.startswith("redis://") or url.startswith("rediss://"):
            from nb_cron.stores.redis_store import RedisStore
            return RedisStore(url, name=name)
        if url.startswith("mongodb://") or url.startswith("mongodb+srv://"):
            from nb_cron.stores.mongo_store import MongoStore
            parts = url.rsplit("/", 1)
            db_name = parts[1] if len(parts) > 1 and parts[1] else "nb_cron"
            return MongoStore(url=url, db_name=db_name, name=name)
        from nb_cron.stores.sqlalchemy_store import SQLAlchemyStore
        return SQLAlchemyStore(url, name=name)

    @staticmethod
    def _create_lock(url: Optional[str], name: str) -> BaseLock:
        if url is None:
            return MemoryLock()
        if url.startswith("redis://") or url.startswith("rediss://"):
            from nb_cron.locks.redis_lock import RedisLock
            return RedisLock(url, name=name)
        if url.startswith("mongodb://") or url.startswith("mongodb+srv://"):
            from nb_cron.locks.mongo_lock import MongoLock
            parts = url.rsplit("/", 1)
            db_name = parts[1] if len(parts) > 1 and parts[1] else "nb_cron"
            return MongoLock(url=url, db_name=db_name, name=name)
        from nb_cron.locks.sqlalchemy_lock import SQLAlchemyLock
        return SQLAlchemyLock(url, name=name)

    # ── Decorator ──

    def job(
        self,
        expression: str,
        *,
        trigger: Optional[str] = None,
        job_id: Optional[str] = None,
        name: Optional[str] = None,
        args: tuple = (),
        kwargs: Optional[dict] = None,
        max_instances: int = 1,
    ) -> Callable:
        """
        装饰器，注册定时任务。函数必须先用 @cron_register 注册。

        :param expression: 触发表达式
        :param trigger: "cron" / "interval" / "date"，不传则自动推断
        """
        def decorator(func: Callable) -> Callable:
            ref = FunctionRegistry.register(func)
            jid = job_id or ref
            self._pending.append({
                "job_id": jid,
                "func_ref": ref,
                "expression": expression,
                "trigger": trigger,
                "name": name or getattr(func, "__name__", jid),
                "args": args,
                "kwargs": kwargs or {},
                "max_instances": max_instances,
            })
            return func
        return decorator

    # ── add_job ──

    def add_job(
        self,
        func: Union[Callable, str],
        expression: str,
        *,
        trigger: Optional[str] = None,
        job_id: Optional[str] = None,
        name: Optional[str] = None,
        args: tuple = (),
        kwargs: Optional[dict] = None,
        max_instances: int = 1,
    ) -> Job:
        if isinstance(func, str):
            ref = func
            if FunctionRegistry.is_registered(ref):
                pass
            elif not self.store.function_exists(ref):
                raise ValueError(
                    f"Function '{ref}' not found in registry or store. "
                    f"Did you forget to use @cron_register('{ref}')?"
                )
            func_name = name or ref
        else:
            ref = FunctionRegistry.register(func)
            func_name = name or getattr(func, "__name__", ref)
        jid = job_id or ref
        trigger_obj = _parse_expression(expression, trigger, tz=self.tz)
        cur = self._now()
        next_run = trigger_obj.get_next_fire_time(None, cur)
        trigger_info = trigger_obj.get_trigger_info()

        job = Job(
            job_id=jid,
            func_ref=ref,
            trigger_type=trigger_info["type"],
            trigger_args=trigger_info,
            args=args,
            kwargs=kwargs or {},
            name=func_name,
            status="active",
            max_instances=max_instances,
            next_run_time=next_run,
        )

        if self.store.job_exists(jid):
            self.store.update_job(job)
        else:
            self.store.add_job(job)

        self.store.register_function(ref)
        logger.info("Job added: %s -> next run: %s", jid, next_run)
        return job

    # ── Control ──

    def start(self) -> None:
        """
        启动调度器（非阻塞，立即返回）。

        - ``start()`` 后面的代码会继续执行。
        - 主线程跑完后进程**不会退出**，定时任务继续运行。
        - ``Ctrl+C`` 优雅停止。
        """
        if self._running:
            logger.warning("Scheduler already running")
            return
        self._flush_pending()
        self._sync_registry_to_store()
        self._running = True
        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=False,
            name="nb_cron-scheduler",
        )
        self._thread.start()
        self._install_signal_handler()
        logger.info("nb_cron [%s] scheduler started (tick=%.1fs, tz=%s)", self.name, self._tick_seconds, self.tz)

    def _install_signal_handler(self) -> None:
        if threading.current_thread() is not threading.main_thread():
            return
        def _handler(signum, frame):
            self.stop(wait=False)
        try:
            signal.signal(signal.SIGINT, _handler)
            signal.signal(signal.SIGTERM, _handler)
        except (OSError, ValueError):
            pass

    def stop(self, wait: bool = True) -> None:
        if self._stop_completed:
            return
        self._running = False
        if self._thread and wait:
            self._thread.join(timeout=10)
        self.executor.shutdown()
        self.store.close()
        self.lock.close()
        self._stop_completed = True
        logger.info("nb_cron [%s] scheduler stopped", self.name)

    def is_running(self) -> bool:
        return self._running

    # ── Job management ──

    def pause_job(self, job_id: str) -> None:
        job = self.store.get_job(job_id)
        if job:
            job.status = "paused"
            job.updated_at = self._now()
            self.store.update_job(job)

    def resume_job(self, job_id: str) -> None:
        job = self.store.get_job(job_id)
        if job:
            job.status = "active"
            trigger = self._rebuild_trigger(job)
            job.next_run_time = trigger.get_next_fire_time(None, self._now())
            job.updated_at = self._now()
            self.store.update_job(job)

    def remove_job(self, job_id: str) -> None:
        self.store.remove_job(job_id)
        logger.info("Job removed: %s", job_id)

    def trigger_job(self, job_id: str) -> None:
        job = self.store.get_job(job_id)
        if not job:
            raise ValueError(f"Job '{job_id}' not found")
        if FunctionRegistry.is_registered(job.func_ref):
            func = FunctionRegistry.resolve(job.func_ref)
            self.executor.submit(
                func_ref=job.func_ref,
                func=func,
                args=job.args,
                kwargs=job.kwargs,
                job_id=job_id,
                callback=lambda r: self._on_job_done(job_id, r),
            )
        else:
            job.next_run_time = self._now()
            job.status = "active"
            job.updated_at = self._now()
            self.store.update_job(job)

    def get_jobs(self) -> List[Job]:
        return self.store.get_all_jobs()

    def get_job(self, job_id: str) -> Optional[Job]:
        return self.store.get_job(job_id)

    # ── Internal ──

    def _flush_pending(self) -> None:
        for p in self._pending:
            try:
                trigger = _parse_expression(p["expression"], p.get("trigger"), tz=self.tz)
                cur = self._now()
                next_run = trigger.get_next_fire_time(None, cur)
                trigger_info = trigger.get_trigger_info()
                job = Job(
                    job_id=p["job_id"],
                    func_ref=p["func_ref"],
                    trigger_type=trigger_info["type"],
                    trigger_args=trigger_info,
                    args=p["args"],
                    kwargs=p["kwargs"],
                    name=p["name"],
                    max_instances=p["max_instances"],
                    next_run_time=next_run,
                )
                if self.store.job_exists(job.job_id):
                    self.store.update_job(job)
                else:
                    self.store.add_job(job)
                self.store.register_function(p["func_ref"])
                logger.info("Registered job: %s -> next run: %s", job.job_id, next_run)
            except Exception:
                logger.exception("Failed to register pending job: %s", p.get("job_id"))
        self._pending.clear()

    def _sync_registry_to_store(self) -> None:
        """将 FunctionRegistry 中所有已注册函数名同步到 store，
        确保只用 @cron_register 标记但未添加任务的函数也能在跨项目 Web UI 中被选择。"""
        for name in FunctionRegistry.get_named_functions():
            try:
                self.store.register_function(name)
            except Exception:
                logger.exception("Failed to sync function to store: %s", name)

    def _run_loop(self) -> None:
        while self._running:
            try:
                self._tick()
            except Exception:
                logger.exception("Scheduler tick error")
            time.sleep(self._tick_seconds)

    def _tick(self) -> None:
        cur = self._now()
        due_jobs = self.store.get_due_jobs(cur)
        for job in due_jobs:
            self._process_job(job, cur)

    def _process_job(self, job: Job, cur: datetime) -> None:
        if job.next_run_time is None:
            return
        grace = timedelta(seconds=self._misfire_grace)
        if cur - job.next_run_time > grace:
            logger.warning(
                "Misfired job %s (due=%s, now=%s, grace=%ss), skipping",
                job.job_id, job.next_run_time, cur, self._misfire_grace,
            )
            self._advance_next_run(job, cur)
            return

        fire_ts = int(job.next_run_time.timestamp())
        lock_key = f"{job.job_id}:{fire_ts}"
        if not self.lock.acquire(lock_key, ttl_seconds=max(300, self._misfire_grace * 2)):
            return

        try:
            func = FunctionRegistry.resolve(job.func_ref)
        except ValueError:
            error_msg = f"Function not found: {job.func_ref}"
            logger.error("Cannot resolve function for job %s: %s", job.job_id, job.func_ref)
            self.metrics.record(
                job_id=job.job_id, success=False, duration_ms=0, error=error_msg,
            )
            job.status = "error"
            job.updated_at = self._now()
            self.store.update_job(job)
            self._advance_next_run(job, cur)
            return

        logger.debug("Executing job %s", job.job_id)
        self.executor.submit(
            func_ref=job.func_ref,
            func=func,
            args=job.args,
            kwargs=job.kwargs,
            job_id=job.job_id,
            callback=lambda r: self._on_job_done(job.job_id, r),
        )
        self._advance_next_run(job, cur)

    def _advance_next_run(self, job: Job, cur: datetime) -> None:
        trigger = self._rebuild_trigger(job)
        next_run = trigger.get_next_fire_time(job.next_run_time, cur)
        self.store.update_next_run_time(job.job_id, next_run)

    def _on_job_done(self, job_id: str, result: _ExecutionResult) -> None:
        self.metrics.record(
            job_id=job_id,
            success=result.success,
            duration_ms=result.duration_ms,
            error=result.error,
        )
        if result.success:
            logger.debug("Job %s completed in %.1fms", job_id, result.duration_ms)
        else:
            logger.error("Job %s failed (%.1fms): %s", job_id, result.duration_ms, result.error)

    @staticmethod
    def _rebuild_trigger(job: Job) -> BaseTrigger:
        info = job.trigger_args
        t = info.get("type", job.trigger_type)
        if t == "cron":
            return CronTrigger(info["expression"])
        if t == "interval":
            return IntervalTrigger(
                weeks=info.get("weeks", 0),
                days=info.get("days", 0),
                hours=info.get("hours", 0),
                minutes=info.get("minutes", 0),
                seconds=info.get("seconds", 0),
            )
        if t == "date":
            return DateTrigger(datetime.fromisoformat(info["run_time"]))
        raise ValueError(f"Unknown trigger type: {t}")
