import uuid
from datetime import datetime, timedelta, timezone

from nb_cron.locks.base import BaseLock


class MongoLock(BaseLock):
    """Distributed lock based on MongoDB unique index + TTL."""

    def __init__(self, url: str = "mongodb://localhost:27017", db_name: str = "nb_cron", name: str = "nb_cron"):
        try:
            from pymongo import MongoClient
            from pymongo.errors import DuplicateKeyError
        except ImportError:
            raise ImportError(
                "pymongo package is required for MongoLock. "
                "Install with: pip install nb_cron_nb[mongo]"
            )
        self._client = MongoClient(url)
        self._collection = self._client[db_name][f"nb_cron_{name}_locks"]
        self._collection.create_index("lock_key", unique=True)
        self._collection.create_index("expire_at", expireAfterSeconds=0)
        self._token = str(uuid.uuid4())
        self._DuplicateKeyError = DuplicateKeyError

    def acquire(self, lock_key: str, ttl_seconds: int = 60) -> bool:
        now = datetime.now(timezone.utc)
        expire_at = now + timedelta(seconds=ttl_seconds)
        self._collection.delete_many({
            "lock_key": lock_key,
            "expire_at": {"$lte": now},
        })
        try:
            self._collection.insert_one({
                "lock_key": lock_key,
                "token": self._token,
                "expire_at": expire_at,
                "acquired_at": now,
            })
            return True
        except self._DuplicateKeyError:
            return False

    def release(self, lock_key: str) -> None:
        self._collection.delete_one({
            "lock_key": lock_key,
            "token": self._token,
        })

    def close(self) -> None:
        self._client.close()
