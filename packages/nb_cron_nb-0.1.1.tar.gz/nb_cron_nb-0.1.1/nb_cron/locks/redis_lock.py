import uuid

from nb_cron.locks.base import BaseLock


class RedisLock(BaseLock):
    """
    Distributed lock based on Redis SET NX PX.
    Guarantees exactly-once execution across multiple instances.
    """

    def __init__(self, url: str = "redis://localhost:6379/0", name: str = "nb_cron"):
        try:
            import redis
        except ImportError:
            raise ImportError(
                "redis package is required for RedisLock. "
                "Install with: pip install nb_cron_nb[redis]"
            )
        self._client = redis.Redis.from_url(url, decode_responses=True)
        self._token = str(uuid.uuid4())
        self._prefix = f"nb_cron:{name}"

    def acquire(self, lock_key: str, ttl_seconds: int = 60) -> bool:
        key = f"{self._prefix}:lock:{lock_key}"
        acquired = self._client.set(key, self._token, nx=True, px=ttl_seconds * 1000)
        return bool(acquired)

    def release(self, lock_key: str) -> None:
        key = f"{self._prefix}:lock:{lock_key}"
        lua = """
        if redis.call("get", KEYS[1]) == ARGV[1] then
            return redis.call("del", KEYS[1])
        else
            return 0
        end
        """
        self._client.eval(lua, 1, key, self._token)

    def close(self) -> None:
        self._client.close()
