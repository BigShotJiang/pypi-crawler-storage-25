import uuid
from datetime import datetime, timedelta, timezone

from nb_cron.locks.base import BaseLock


class SQLAlchemyLock(BaseLock):
    """Distributed lock using a SQL table with INSERT conflict detection."""

    def __init__(self, url: str = "sqlite:///nb_cron.db", name: str = "nb_cron"):
        try:
            from sqlalchemy import (
                Column, DateTime, MetaData, String, Table, create_engine,
            )
            from sqlalchemy.orm import sessionmaker
        except ImportError:
            raise ImportError(
                "sqlalchemy package is required for SQLAlchemyLock. "
                "Install with: pip install nb_cron_nb[sqlalchemy]"
            )
        self._engine = create_engine(url, pool_pre_ping=True)
        self._Session = sessionmaker(bind=self._engine)
        self._metadata = MetaData()
        self._table = Table(
            f"nb_cron_{name}_locks", self._metadata,
            Column("lock_key", String(512), primary_key=True),
            Column("token", String(64), nullable=False),
            Column("expire_at", DateTime(timezone=True), nullable=False),
        )
        self._metadata.create_all(self._engine)
        self._token = str(uuid.uuid4())

    def acquire(self, lock_key: str, ttl_seconds: int = 60) -> bool:
        now = datetime.now(timezone.utc)
        expire_at = now + timedelta(seconds=ttl_seconds)
        session = self._Session()
        try:
            session.execute(
                self._table.delete().where(self._table.c.expire_at <= now)
            )
            session.commit()

            existing = session.execute(
                self._table.select().where(self._table.c.lock_key == lock_key)
            ).fetchone()
            if existing:
                return False

            try:
                session.execute(
                    self._table.insert().values(
                        lock_key=lock_key,
                        token=self._token,
                        expire_at=expire_at,
                    )
                )
                session.commit()
                return True
            except Exception:
                session.rollback()
                return False
        finally:
            session.close()

    def release(self, lock_key: str) -> None:
        session = self._Session()
        try:
            session.execute(
                self._table.delete().where(
                    self._table.c.lock_key == lock_key,
                    self._table.c.token == self._token,
                )
            )
            session.commit()
        finally:
            session.close()

    def close(self) -> None:
        self._engine.dispose()
