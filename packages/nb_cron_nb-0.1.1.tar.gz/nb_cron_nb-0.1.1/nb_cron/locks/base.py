from abc import ABC, abstractmethod


class BaseLock(ABC):

    @abstractmethod
    def acquire(self, lock_key: str, ttl_seconds: int = 60) -> bool:
        """
        Try to acquire a distributed lock.
        Returns True if acquired, False if already held by another instance.
        The lock auto-expires after ttl_seconds.
        """

    @abstractmethod
    def release(self, lock_key: str) -> None:
        """Release a previously acquired lock."""

    def close(self) -> None:
        """Release resources (optional override)."""
