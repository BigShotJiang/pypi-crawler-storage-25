import threading
import time
from typing import Dict, Tuple

from nb_cron.locks.base import BaseLock


class MemoryLock(BaseLock):
    """In-process lock for single-instance deployments."""

    def __init__(self):
        self._locks: Dict[str, float] = {}  # key -> expire_timestamp
        self._mutex = threading.Lock()

    def acquire(self, lock_key: str, ttl_seconds: int = 60) -> bool:
        now = time.time()
        with self._mutex:
            expire = self._locks.get(lock_key, 0)
            if expire > now:
                return False
            self._locks[lock_key] = now + ttl_seconds
            return True

    def release(self, lock_key: str) -> None:
        with self._mutex:
            self._locks.pop(lock_key, None)

    def _cleanup_expired(self) -> None:
        now = time.time()
        with self._mutex:
            expired = [k for k, v in self._locks.items() if v <= now]
            for k in expired:
                del self._locks[k]
