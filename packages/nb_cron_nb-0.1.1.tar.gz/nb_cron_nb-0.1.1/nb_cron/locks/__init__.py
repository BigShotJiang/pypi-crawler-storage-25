from nb_cron.locks.base import BaseLock

__all__ = ["BaseLock"]
