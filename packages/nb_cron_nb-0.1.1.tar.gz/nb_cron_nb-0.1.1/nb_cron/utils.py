import asyncio
import logging
from datetime import datetime, timezone
from typing import Callable, Optional

logger = logging.getLogger("nb_cron")


def is_async_callable(func: Callable) -> bool:
    return asyncio.iscoroutinefunction(func) or (
        hasattr(func, "__call__") and asyncio.iscoroutinefunction(func.__call__)
    )


def get_local_timezone():
    """获取系统本地时区。"""
    return datetime.now(timezone.utc).astimezone().tzinfo


def now(tz=None) -> datetime:
    """获取当前时间。tz=None 时使用本地时区。"""
    if tz is None:
        tz = get_local_timezone()
    return datetime.now(tz)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def ensure_timezone(dt: datetime, tz=None) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=tz or get_local_timezone())
    return dt


def truncate_string(s: str, max_len: int = 500) -> str:
    if len(s) <= max_len:
        return s
    return s[:max_len - 3] + "..."


def format_duration(ms: float) -> str:
    if ms < 1000:
        return f"{ms:.0f}ms"
    if ms < 60000:
        return f"{ms / 1000:.1f}s"
    minutes = int(ms // 60000)
    seconds = (ms % 60000) / 1000
    return f"{minutes}m{seconds:.0f}s"
