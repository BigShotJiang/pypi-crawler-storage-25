"""Flask blueprint for nb_cron management API."""
from nb_cron.api import handlers


def create_blueprint(cron):
    """
    Create a Flask Blueprint bound to the given NbCron instance.
    All endpoints are prefixed with /nb_cron/api.
    """
    try:
        from flask import Blueprint, jsonify, request
    except ImportError:
        raise ImportError(
            "flask is required. Install with: pip install nb_cron_nb[flask]"
        )

    bp = Blueprint("nb_cron_api", __name__, url_prefix="/nb_cron/api")

    @bp.route("/jobs", methods=["GET"])
    def get_jobs():
        return jsonify(handlers.handle_get_jobs(cron))

    @bp.route("/jobs/<job_id>", methods=["GET"])
    def get_job(job_id):
        return jsonify(handlers.handle_get_job(cron, job_id))

    @bp.route("/jobs", methods=["POST"])
    def create_job():
        data = request.get_json(force=True)
        return jsonify(handlers.handle_create_job(cron, data))

    @bp.route("/jobs/<job_id>", methods=["DELETE"])
    def delete_job(job_id):
        return jsonify(handlers.handle_delete_job(cron, job_id))

    @bp.route("/jobs/<job_id>/pause", methods=["POST"])
    def pause_job(job_id):
        return jsonify(handlers.handle_pause_job(cron, job_id))

    @bp.route("/jobs/<job_id>/resume", methods=["POST"])
    def resume_job(job_id):
        return jsonify(handlers.handle_resume_job(cron, job_id))

    @bp.route("/jobs/<job_id>/trigger", methods=["POST"])
    def trigger_job(job_id):
        return jsonify(handlers.handle_trigger_job(cron, job_id))

    @bp.route("/jobs/<job_id>/metrics", methods=["GET"])
    def get_metrics(job_id):
        return jsonify(handlers.handle_get_metrics(cron, job_id))

    @bp.route("/dashboard/stats", methods=["GET"])
    def dashboard_stats():
        return jsonify(handlers.handle_dashboard_stats(cron))

    @bp.route("/cron/explain", methods=["GET"])
    def cron_explain():
        expression = request.args.get("expression", "")
        return jsonify(handlers.handle_cron_explain(expression))

    @bp.route("/functions", methods=["GET"])
    def get_functions():
        return jsonify(handlers.handle_get_functions(cron))

    @bp.route("/health", methods=["GET"])
    def health():
        return jsonify(handlers.handle_health(cron))

    return bp
