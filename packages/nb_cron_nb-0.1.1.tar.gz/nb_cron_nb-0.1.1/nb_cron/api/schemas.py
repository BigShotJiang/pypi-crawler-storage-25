from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class JobCreate(BaseModel):
    job_id: Optional[str] = None
    func_ref: str = Field(..., description="已注册的 cron_func_name（通过 @cron_register 注册）")
    expression: str = Field(..., description="触发表达式：cron / 间隔 / 日期时间")
    trigger: Optional[str] = Field(None, description="触发器类型: 'cron' / 'interval' / 'date'，不传则自动推断")
    name: Optional[str] = None
    args: List[Any] = Field(default_factory=list)
    kwargs: Dict[str, Any] = Field(default_factory=dict)
    max_instances: int = 1


class JobResponse(BaseModel):
    job_id: str
    func_ref: str
    trigger_type: str
    trigger_args: Dict[str, Any] = Field(default_factory=dict)
    name: str
    status: str
    max_instances: int = 1
    next_run_time: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class JobMetrics(BaseModel):
    total_runs: int = 0
    success_count: int = 0
    fail_count: int = 0
    last_run_at: Optional[str] = None
    last_success_at: Optional[str] = None
    last_error: Optional[str] = None
    last_error_at: Optional[str] = None
    avg_duration_ms: float = 0.0
    max_duration_ms: float = 0.0
    min_duration_ms: float = 0.0
    last_duration_ms: float = 0.0
    recent_results: List[Dict[str, Any]] = Field(default_factory=list)
    hourly_stats: List[Dict[str, Any]] = Field(default_factory=list)


class JobWithMetrics(JobResponse):
    metrics: Optional[JobMetrics] = None


class DashboardStats(BaseModel):
    job_count: int = 0
    active_count: int = 0
    paused_count: int = 0
    error_count: int = 0
    total_runs: int = 0
    total_success: int = 0
    total_fail: int = 0
    success_rate: float = 0.0
    hourly_stats: List[Dict[str, Any]] = Field(default_factory=list)


class CronExplain(BaseModel):
    expression: str
    zh: str
    en: str


class ApiResponse(BaseModel):
    success: bool = True
    message: str = "ok"
    data: Any = None
