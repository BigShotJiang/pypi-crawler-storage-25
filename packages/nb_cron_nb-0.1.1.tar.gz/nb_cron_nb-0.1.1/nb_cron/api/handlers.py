"""
Framework-agnostic request handlers.
Each function takes an NbCron instance and request data, returns a dict.
All data is read from the store — never from in-memory FunctionRegistry —
so a standalone web project can manage jobs across Git repositories.
"""
from typing import Any, Dict, List, Optional

from nb_cron.core.scheduler import NbCron
from nb_cron.cron_utils.translator import explain_cron


def handle_get_jobs(cron: NbCron) -> Dict[str, Any]:
    jobs = cron.get_jobs()
    all_metrics = cron.metrics.get_all_metrics()
    result = []
    for job in jobs:
        d = job.to_dict()
        m = all_metrics.get(job.job_id)
        d["metrics"] = m
        try:
            trigger = cron._rebuild_trigger(job)
            d["trigger_description_zh"] = trigger.get_description("zh")
            d["trigger_description_en"] = trigger.get_description("en")
        except Exception:
            d["trigger_description_zh"] = ""
            d["trigger_description_en"] = ""
        result.append(d)
    return {"success": True, "data": result}


def handle_get_job(cron: NbCron, job_id: str) -> Dict[str, Any]:
    job = cron.get_job(job_id)
    if not job:
        return {"success": False, "message": f"Job '{job_id}' not found", "data": None}
    d = job.to_dict()
    d["metrics"] = cron.metrics.get_metrics(job_id)
    try:
        trigger = cron._rebuild_trigger(job)
        d["trigger_description_zh"] = trigger.get_description("zh")
        d["trigger_description_en"] = trigger.get_description("en")
    except Exception:
        d["trigger_description_zh"] = ""
        d["trigger_description_en"] = ""
    return {"success": True, "data": d}


def handle_create_job(cron: NbCron, data: dict) -> Dict[str, Any]:
    func_ref = data.get("func_ref", "")
    expression = data.get("expression", "")
    trigger = data.get("trigger")
    job_id = data.get("job_id")
    name = data.get("name")
    args = tuple(data.get("args", []))
    kwargs = data.get("kwargs", {})
    max_instances = data.get("max_instances", 1)

    try:
        job = cron.add_job(
            func_ref, expression,
            trigger=trigger, job_id=job_id, name=name,
            args=args, kwargs=kwargs,
            max_instances=max_instances,
        )
        return {"success": True, "data": job.to_dict(), "message": "Job created"}
    except Exception as e:
        return {"success": False, "message": str(e), "data": None}


def handle_delete_job(cron: NbCron, job_id: str) -> Dict[str, Any]:
    job = cron.get_job(job_id)
    if not job:
        return {"success": False, "message": f"Job '{job_id}' not found"}
    cron.remove_job(job_id)
    return {"success": True, "message": f"Job '{job_id}' removed"}


def handle_pause_job(cron: NbCron, job_id: str) -> Dict[str, Any]:
    job = cron.get_job(job_id)
    if not job:
        return {"success": False, "message": f"Job '{job_id}' not found"}
    cron.pause_job(job_id)
    return {"success": True, "message": f"Job '{job_id}' paused"}


def handle_resume_job(cron: NbCron, job_id: str) -> Dict[str, Any]:
    job = cron.get_job(job_id)
    if not job:
        return {"success": False, "message": f"Job '{job_id}' not found"}
    cron.resume_job(job_id)
    return {"success": True, "message": f"Job '{job_id}' resumed"}


def handle_trigger_job(cron: NbCron, job_id: str) -> Dict[str, Any]:
    try:
        cron.trigger_job(job_id)
        return {"success": True, "message": f"Job '{job_id}' triggered"}
    except ValueError as e:
        return {"success": False, "message": str(e)}


def handle_get_metrics(cron: NbCron, job_id: str) -> Dict[str, Any]:
    m = cron.metrics.get_metrics(job_id)
    return {"success": True, "data": m}


def handle_dashboard_stats(cron: NbCron) -> Dict[str, Any]:
    stats = cron.metrics.get_dashboard_stats()
    jobs = cron.get_jobs()
    stats["active_count"] = sum(1 for j in jobs if j.status == "active")
    stats["paused_count"] = sum(1 for j in jobs if j.status == "paused")
    stats["error_count"] = sum(1 for j in jobs if j.status == "error")
    stats["job_count"] = len(jobs)
    return {"success": True, "data": stats}


def handle_cron_explain(expression: str) -> Dict[str, Any]:
    try:
        zh = explain_cron(expression, "zh")
        en = explain_cron(expression, "en")
        return {"success": True, "data": {"expression": expression, "zh": zh, "en": en}}
    except ValueError as e:
        return {"success": False, "message": str(e), "data": None}


def handle_get_functions(cron: NbCron) -> Dict[str, Any]:
    """返回所有已注册的函数名称列表（从 store 读取，支持跨项目）。"""
    names = cron.store.get_function_names()
    return {
        "success": True,
        "data": {
            "functions": names,
        },
    }


def handle_health(cron: NbCron) -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "name": cron.name,
            "running": cron.is_running(),
            "job_count": len(cron.get_jobs()),
            "store_type": type(cron.store).__name__,
            "lock_type": type(cron.lock).__name__,
            "tz": str(cron.tz),
        },
    }
