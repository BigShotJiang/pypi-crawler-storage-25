"""Django Ninja router for nb_cron management API."""
from nb_cron.api import handlers


def create_router(cron):
    """
    Create a Django Ninja Router bound to the given NbCron instance.
    Mount at /nb_cron/api in your Django urls.py.
    """
    try:
        from ninja import Router
    except ImportError:
        raise ImportError(
            "django-ninja is required. Install with: pip install nb_cron_nb[django]"
        )

    router = Router()

    @router.get("/jobs")
    def get_jobs(request):
        return handlers.handle_get_jobs(cron)

    @router.get("/jobs/{job_id}")
    def get_job(request, job_id: str):
        return handlers.handle_get_job(cron, job_id)

    @router.post("/jobs")
    def create_job(request, data: dict):
        return handlers.handle_create_job(cron, data)

    @router.delete("/jobs/{job_id}")
    def delete_job(request, job_id: str):
        return handlers.handle_delete_job(cron, job_id)

    @router.post("/jobs/{job_id}/pause")
    def pause_job(request, job_id: str):
        return handlers.handle_pause_job(cron, job_id)

    @router.post("/jobs/{job_id}/resume")
    def resume_job(request, job_id: str):
        return handlers.handle_resume_job(cron, job_id)

    @router.post("/jobs/{job_id}/trigger")
    def trigger_job(request, job_id: str):
        return handlers.handle_trigger_job(cron, job_id)

    @router.get("/jobs/{job_id}/metrics")
    def get_metrics(request, job_id: str):
        return handlers.handle_get_metrics(cron, job_id)

    @router.get("/dashboard/stats")
    def dashboard_stats(request):
        return handlers.handle_dashboard_stats(cron)

    @router.get("/cron/explain")
    def cron_explain(request, expression: str):
        return handlers.handle_cron_explain(expression)

    @router.get("/functions")
    def get_functions(request):
        return handlers.handle_get_functions(cron)

    @router.get("/health")
    def health(request):
        return handlers.handle_health(cron)

    return router
