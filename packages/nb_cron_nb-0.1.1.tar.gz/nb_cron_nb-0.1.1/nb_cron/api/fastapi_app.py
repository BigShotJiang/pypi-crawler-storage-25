"""FastAPI router for nb_cron management API."""
from typing import Optional

from nb_cron.api import handlers


def create_router(cron):
    """
    Create a FastAPI APIRouter bound to the given NbCron instance.
    All endpoints are prefixed with /nb_cron/api.
    """
    try:
        from fastapi import APIRouter, Query
        from fastapi.responses import JSONResponse
    except ImportError:
        raise ImportError(
            "fastapi is required. Install with: pip install nb_cron_nb[fastapi]"
        )

    router = APIRouter(prefix="/nb_cron/api", tags=["nb_cron"])

    @router.get("/jobs")
    def get_jobs():
        return JSONResponse(handlers.handle_get_jobs(cron))

    @router.get("/jobs/{job_id}")
    def get_job(job_id: str):
        return JSONResponse(handlers.handle_get_job(cron, job_id))

    @router.post("/jobs")
    async def create_job(data: dict):
        return JSONResponse(handlers.handle_create_job(cron, data))

    @router.delete("/jobs/{job_id}")
    def delete_job(job_id: str):
        return JSONResponse(handlers.handle_delete_job(cron, job_id))

    @router.post("/jobs/{job_id}/pause")
    def pause_job(job_id: str):
        return JSONResponse(handlers.handle_pause_job(cron, job_id))

    @router.post("/jobs/{job_id}/resume")
    def resume_job(job_id: str):
        return JSONResponse(handlers.handle_resume_job(cron, job_id))

    @router.post("/jobs/{job_id}/trigger")
    def trigger_job(job_id: str):
        return JSONResponse(handlers.handle_trigger_job(cron, job_id))

    @router.get("/jobs/{job_id}/metrics")
    def get_metrics(job_id: str):
        return JSONResponse(handlers.handle_get_metrics(cron, job_id))

    @router.get("/dashboard/stats")
    def dashboard_stats():
        return JSONResponse(handlers.handle_dashboard_stats(cron))

    @router.get("/cron/explain")
    def cron_explain(expression: str = Query(...)):
        return JSONResponse(handlers.handle_cron_explain(expression))

    @router.get("/functions")
    def get_functions():
        return JSONResponse(handlers.handle_get_functions(cron))

    @router.get("/health")
    def health():
        return JSONResponse(handlers.handle_health(cron))

    return router
