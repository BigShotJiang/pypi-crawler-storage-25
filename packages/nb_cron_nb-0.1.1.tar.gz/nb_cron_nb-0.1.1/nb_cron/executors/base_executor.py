"""
执行器基类。

nb_cron 的调度器负责「到时间触发」，执行器负责「真正运行任务」。

内置两个实现：
  - ThreadExecutor  — 默认，本地自适应线程池
  - FunboostExecutor — 把任务推入 funboost 队列，由 funboost worker 消费执行

可自定义执行器，只需继承 BaseExecutor 实现 submit()。

用法::

    from nb_cron import NbCron
    from nb_cron.executors.funboost_executor import FunboostExecutor

    executor = FunboostExecutor(BoosterParams(queue_name="my_queue", broker_kind=BrokerEnum.REDIS))
    cron = NbCron("my_project", "redis://localhost:6379/0", executor=executor)
"""
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, Optional, Tuple


class BaseExecutor(ABC):
    """
    执行器接口。

    调度器触发任务时调用 ``submit()``，执行器决定如何执行。
    - 本地执行：线程池直接运行
    - funboost：推送到队列，异步 worker 消费
    - 自定义：RQ / Celery / ... 任意消息队列
    """

    @abstractmethod
    def submit(
        self,
        func_ref: str,
        func: Callable,
        args: Tuple,
        kwargs: Dict[str, Any],
        job_id: str,
        callback: Optional[Callable] = None,
    ) -> None:
        """
        提交一次任务执行。

        Parameters
        ----------
        func_ref:
            函数的 cron_func_name，用于远程 worker 通过注册表重新解析。
        func:
            当前进程已解析的可调用对象（本地执行器直接用；远程执行器只用 func_ref）。
        args:
            位置参数。
        kwargs:
            关键字参数。
        job_id:
            任务 ID，用于 metrics 记录。
        callback:
            本地执行完成后的回调 ``callback(_ExecutionResult)``。
            远程执行器（如 funboost）执行发生在另一进程，此回调通常被忽略，
            由远程 worker 自行记录 metrics。
        """

    def shutdown(self, wait: bool = True) -> None:
        """释放资源（可选）。"""
