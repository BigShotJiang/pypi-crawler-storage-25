"""
Funboost 执行器。

任务触发时，nb_cron 不在本地执行函数，而是调用 funboost 的 .push() 把
(cron_func_name, args, kwargs, job_id) 推送到消息队列（Redis / RabbitMQ / ...），
由 funboost worker 进程消费执行，执行完毕后自动向 store 写入成功/失败指标。

安装依赖::

    pip install funboost

用法::

    from funboost import BoosterParams, BrokerEnum
    from nb_cron import NbCron, cron_register
    from nb_cron.executors.funboost_executor import FunboostExecutor

    executor = FunboostExecutor(
        BoosterParams(
            queue_name="nb_cron_dispatch",
            broker_kind=BrokerEnum.REDIS,
            concurrent_num=10,
            qps=20,
        )
    )
    # NbCron 构造时会自动把自身注入给 executor，worker 端直接复用 metrics
    cron = NbCron("my_project", "redis://localhost:6379/0", executor=executor)

    @cron.job("0 */5 * * * *", kwargs={"user_id": 42})
    @cron_register('my_task')
    def my_task(user_id: int):
        print(f"processing user {user_id}")

    # 启动 funboost consume（consume() 本身非阻塞）+ scheduler
    executor.consume()
    cron.start()

Worker 端单独进程（可横向扩展）::

    # worker.py
    from funboost import BoosterParams, BrokerEnum
    from nb_cron import NbCron
    from nb_cron.executors.funboost_executor import FunboostExecutor
    import my_tasks   # 触发 @cron_register，让注册表生效

    executor = FunboostExecutor(
        BoosterParams(queue_name="nb_cron_dispatch", broker_kind=BrokerEnum.REDIS)
    )
    cron = NbCron("my_project", "redis://localhost:6379/0", executor=executor)

    executor.consume()  # 或 executor.mp_consume(process_num=4)

自定义 metrics_recorder（高级，如同时上报 Prometheus）::

    def my_recorder(job_id, success, duration_ms, error):
        ...  # 自定义逻辑

    executor = FunboostExecutor(
        BoosterParams(...),
        metrics_recorder=my_recorder,
    )
"""
import logging
import time as _time
import traceback
from typing import Any, Callable, Dict, Optional, Tuple
import inspect

import asyncio
import threading



from nb_cron.executors.base_executor import BaseExecutor
from funboost import boost, BoosterParams, ConcurrentModeEnum

logger = logging.getLogger("nb_cron.funboost_executor")

tl = threading.local()


def _get_thread_local_loop() -> asyncio.AbstractEventLoop:
    if not hasattr(tl, 'asyncio_loop'):
        loop = asyncio.new_event_loop()
        tl.asyncio_loop = loop
    return tl.asyncio_loop

class FunboostExecutor(BaseExecutor):
    """
    将 nb_cron 任务推入 funboost 消息队列，由 funboost worker 异步消费执行。
    执行完毕后自动上报成功/失败指标。

    Parameters
    ----------
    booster_params:
        funboost ``BoosterParams`` 对象，支持 IDE 自动补全所有参数（queue_name、
        broker_kind、concurrent_num、qps、max_retry_times 等）。
    metrics_recorder:
        可选自定义指标回调，签名 ``(job_id, success, duration_ms, error_msg) -> None``。
        不传则使用 NbCron 注入的 metrics（推荐，自动写入 store）。
    """

    def __init__(
        self,
        booster_params: "BoosterParams",
        metrics_recorder: Optional[Callable[[str, bool, float, Optional[str]], None]] = None,
    ):
        self.booster_params = booster_params
        self.booster_params.concurrent_mode = ConcurrentModeEnum.THREADING # 用户无需指定并发模式，_nb_cron_dispatch函数内部自动处理asyncio和同步函数
        self._metrics_recorder = metrics_recorder
        # NbCron 构造时会自动赋值（见 NbCron.__init__）
        self._cron: Optional[Any] = None
        self.booster = self._build_booster()
        self.consume = self.booster.consume
        self.mp_consume = self.booster.mp_consume

    # ── NbCron 注入 ──────────────────────────────────────────────────

    def bind_cron(self, cron: Any) -> None:
        """由 NbCron.__init__ 自动调用，把 scheduler 实例注入进来，
        worker 端直接复用 cron.metrics.record() 写入指标，无需重建 store。"""
        self._cron = cron

    # ── 内部方法 ────────────────────────────────────────────────────

    def _get_metrics_recorder(self) -> Optional[Callable]:
        """
        指标记录器优先级：
          1. 自定义 metrics_recorder
          2. NbCron 注入的 cron.metrics.record（推荐）
          3. None（只打 debug 日志）
        """
        if self._metrics_recorder:
            return self._metrics_recorder
        if self._cron is not None:
            return self._cron.metrics.record
        return None

    def _build_booster(self):
        """构建 @boost 装饰的统一 dispatch 函数。"""
        booster_params = self.booster_params
        executor_ref = self

        @boost(booster_params)
        def _nb_cron_dispatch(
            cron_func_name: str,
            args: list,
            kwargs: dict,
            job_id: str,
        ):
            """
            funboost worker 消费的真正入口。
            解析 cron_func_name → 执行函数 → 上报成功/失败指标。
            """
            from nb_cron.core.registry import FunctionRegistry

            start = _time.monotonic()
            success = False
            error_msg: Optional[str] = None
            kwargs = kwargs or {}

            try:
                func = FunctionRegistry.resolve(cron_func_name)
                if inspect.iscoroutinefunction(func):
                    has_specify_async_loop = None
                    loop = booster_params.specify_async_loop
                    if loop is not None:
                        has_specify_async_loop = True
                    else:
                        has_specify_async_loop = False
                        loop = _get_thread_local_loop()
                    if has_specify_async_loop:
                        """
                        # 有些aio三方包，例如aiohttp的cleint需要确保实例化和发请求，必须在同一个loop运行，此时必须指定loop。 
                        # 如果指定了loop，用户记得还要去亲自去启动looploop.run_forever()，否则async def的函数不会被执行。
                        """
                        future = asyncio.run_coroutine_threadsafe(func(*args, **kwargs ), loop)
                        result = future.result()
                    else:
                        result = loop.run_until_complete(func(*args, **kwargs))
                else:
                    result = func(*args, **kwargs)
                success = True
                return result
            except Exception as exc:
                error_msg = str(exc)
                logger.error(
                    "funboost job FAILED: job_id=%s func=%s error=%s\n%s",
                    job_id, cron_func_name, exc, traceback.format_exc(),
                )
                raise
            finally:
                duration_ms = (_time.monotonic() - start) * 1000
                logger.debug(
                    "funboost job %s: func=%s success=%s duration=%.1fms",
                    job_id, cron_func_name, success, duration_ms,
                )
                recorder = executor_ref._get_metrics_recorder()
                if recorder:
                    try:
                        recorder(job_id, success, duration_ms, error_msg)
                    except Exception:
                        logger.warning(
                            "funboost metrics 上报失败: job_id=%s", job_id, exc_info=True
                        )
                else:
                    logger.debug(
                        "funboost metrics 未配置 recorder，跳过上报: job_id=%s", job_id
                    )

        return _nb_cron_dispatch

    # ── 公开接口 ────────────────────────────────────────────────────

    def submit(
        self,
        func_ref: str,
        func: Callable,
        args: Tuple,
        kwargs: Dict[str, Any],
        job_id: str,
        callback: Optional[Callable] = None,
    ) -> None:
        """推入 funboost 队列。callback 被忽略（执行在 worker 进程）。"""
        logger.debug(
            "push to funboost: job_id=%s func=%s queue=%s",
            job_id, func_ref, self.booster_params.queue_name,
        )
        self.booster.push(
            cron_func_name=func_ref,
            args=list(args),
            kwargs=kwargs or {},
            job_id=job_id,
        )

    
    def shutdown(self, wait: bool = True) -> None:
        pass
