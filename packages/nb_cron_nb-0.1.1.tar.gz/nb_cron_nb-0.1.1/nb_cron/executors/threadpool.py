import asyncio
import logging
import queue
import threading
import time
import traceback
from typing import Any, Callable, Optional

from nb_cron.utils import is_async_callable

logger = logging.getLogger("nb_cron.executor")

_SENTINEL = object()


class _ExecutionResult:
    __slots__ = ("success", "result", "error", "duration_ms")

    def __init__(self, success: bool, result: Any, error: Optional[str], duration_ms: float):
        self.success = success
        self.result = result
        self.error = error
        self.duration_ms = duration_ms


class AdaptiveThreadPool:
    """
    自适应线程池：按需创建 worker，空闲 idle_timeout 秒后自动退出。
    sync / async 任务共用同一池，并发统一受 max_workers 控制。
    不依赖 stdlib ThreadPoolExecutor（其 atexit 在 Python 3.9+ 会提前 shutdown）。
    """

    def __init__(self, max_workers: int = 20, idle_timeout: float = 5.0):
        self._max_workers = max_workers
        self._idle_timeout = idle_timeout
        self._queue: queue.Queue = queue.Queue()
        self._lock = threading.Lock()
        self._num_threads = 0
        self._num_idle = 0
        self._closed = False

    def submit(
        self,
        func: Callable,
        args: tuple = (),
        kwargs: Optional[dict] = None,
        callback: Optional[Callable[[_ExecutionResult], None]] = None,
    ) -> None:
        kwargs = kwargs or {}

        def _run():
            start = time.monotonic()
            try:
                if is_async_callable(func):
                    result = asyncio.run(func(*args, **kwargs))
                else:
                    result = func(*args, **kwargs)
                duration = (time.monotonic() - start) * 1000
                er = _ExecutionResult(True, result, None, duration)
            except Exception as e:
                duration = (time.monotonic() - start) * 1000
                tb = traceback.format_exc()
                logger.error("Job execution failed: %s\n%s", e, tb)
                er = _ExecutionResult(False, None, str(e), duration)
            if callback:
                try:
                    callback(er)
                except Exception:
                    logger.exception("Callback error")

        if self._closed:
            return
        self._queue.put(_run)
        with self._lock:
            if self._num_idle == 0 and self._num_threads < self._max_workers:
                self._num_threads += 1
                threading.Thread(
                    target=self._worker, name="nb_cron-worker",
                ).start()

    def _worker(self) -> None:
        with self._lock:
            self._num_idle += 1
        while True:
            try:
                task = self._queue.get(timeout=self._idle_timeout)
            except queue.Empty:
                with self._lock:
                    self._num_idle -= 1
                    self._num_threads -= 1
                return
            if task is _SENTINEL:
                self._queue.task_done()
                with self._lock:
                    self._num_idle -= 1
                    self._num_threads -= 1
                return
            with self._lock:
                self._num_idle -= 1
            try:
                task()
            except Exception:
                logger.exception("Unexpected error in worker")
            self._queue.task_done()
            with self._lock:
                self._num_idle += 1

    @property
    def num_threads(self) -> int:
        with self._lock:
            return self._num_threads

    def shutdown(self, wait: bool = True) -> None:
        self._closed = True
        if wait:
            self._queue.join()
        with self._lock:
            for _ in range(self._num_threads):
                self._queue.put(_SENTINEL)
