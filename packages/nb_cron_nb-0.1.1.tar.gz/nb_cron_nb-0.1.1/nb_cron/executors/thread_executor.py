"""
默认执行器：本地自适应线程池。
封装 AdaptiveThreadPool，实现 BaseExecutor 接口。
"""
from typing import Any, Callable, Dict, Optional, Tuple

from nb_cron.executors.base_executor import BaseExecutor
from nb_cron.executors.threadpool import AdaptiveThreadPool, _ExecutionResult


class ThreadExecutor(BaseExecutor):
    """
    本地线程池执行器（默认）。

    任务在当前进程的自适应线程池中直接执行，执行完成后触发 callback 记录 metrics。
    """

    def __init__(self, max_workers: int = 20, idle_timeout: float = 5.0):
        self._pool = AdaptiveThreadPool(max_workers=max_workers, idle_timeout=idle_timeout)

    def submit(
        self,
        func_ref: str,
        func: Callable,
        args: Tuple,
        kwargs: Dict[str, Any],
        job_id: str,
        callback: Optional[Callable[[_ExecutionResult], None]] = None,
    ) -> None:
        self._pool.submit(func, args=args, kwargs=kwargs, callback=callback)

    def shutdown(self, wait: bool = True) -> None:
        self._pool.shutdown(wait=wait)
