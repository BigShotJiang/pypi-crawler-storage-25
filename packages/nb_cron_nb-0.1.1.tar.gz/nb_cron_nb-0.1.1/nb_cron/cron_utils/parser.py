from datetime import datetime, timezone
from typing import Optional

from croniter import croniter


def _user_to_croniter(expression: str) -> str:
    """sec min hour day month dow -> min hour day month dow sec"""
    fields = expression.strip().split()
    sec, min_, hour, day, month, dow = fields
    return f"{min_} {hour} {day} {month} {dow} {sec}"


def validate_cron(expression: str) -> str:
    fields = expression.strip().split()
    if len(fields) != 6:
        raise ValueError(
            f"nb_cron requires exactly 6-field cron "
            f"(second minute hour day month weekday), "
            f"got {len(fields)} fields: '{expression}'. "
            f"Example: '0 */5 * * * *' means every 5 minutes at second 0."
        )
    croniter_expr = _user_to_croniter(expression)
    try:
        croniter(croniter_expr)
    except (ValueError, KeyError, TypeError) as e:
        raise ValueError(f"Invalid cron expression: '{expression}' ({e})")
    return expression


def next_fire_time(
    expression: str,
    base: Optional[datetime] = None,
) -> datetime:
    validate_cron(expression)
    croniter_expr = _user_to_croniter(expression)
    if base is None:
        base = datetime.now(timezone.utc)
    elif base.tzinfo is None:
        base = base.replace(tzinfo=timezone.utc)
    cron = croniter(croniter_expr, base)
    nxt = cron.get_next(datetime)
    if nxt.tzinfo is None:
        nxt = nxt.replace(tzinfo=timezone.utc)
    return nxt
