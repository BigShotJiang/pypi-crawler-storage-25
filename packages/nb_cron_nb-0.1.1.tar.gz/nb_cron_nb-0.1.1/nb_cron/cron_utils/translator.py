"""
Translate a 6-field cron expression to human-readable Chinese or English.

Format: second minute hour day_of_month month day_of_week
"""
from typing import List, Optional

WEEKDAY_EN = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
WEEKDAY_ZH = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
MONTH_EN = [
    "", "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]
MONTH_ZH = [
    "", "1月", "2月", "3月", "4月", "5月", "6月",
    "7月", "8月", "9月", "10月", "11月", "12月",
]


def explain_cron(expression: str, lang: str = "en") -> str:
    fields = expression.strip().split()
    if len(fields) != 6:
        raise ValueError(
            f"nb_cron requires exactly 6-field cron "
            f"(second minute hour day month weekday), "
            f"got {len(fields)} fields: '{expression}'."
        )
    second, minute, hour, dom, month, dow = fields
    if lang == "zh":
        return _translate_zh(second, minute, hour, dom, month, dow)
    return _translate_en(second, minute, hour, dom, month, dow)


def _translate_en(sec: str, min_: str, hour: str, dom: str, month: str, dow: str) -> str:
    parts: List[str] = []

    if sec == "*" and min_ == "*" and hour == "*" and dom == "*" and month == "*" and dow == "*":
        return "Every second"

    time_desc = _time_desc_en(sec, min_, hour)
    when_desc = _when_desc_en(dom, month, dow)

    if when_desc:
        parts.append(time_desc)
        parts.append(when_desc)
    else:
        parts.append(time_desc)

    return ", ".join(parts)


def _time_desc_en(sec: str, min_: str, hour: str) -> str:
    if sec == "*" and min_ == "*" and hour == "*":
        return "Every second"
    if min_ == "*" and hour == "*":
        return _field_desc_en(sec, "second")
    if hour == "*":
        sec_part = _at_field_en(sec, "second") if sec != "0" else ""
        min_part = _field_desc_en(min_, "minute")
        return f"{min_part}{sec_part}" if sec_part else min_part

    if _is_specific(hour) and _is_specific(min_) and _is_specific(sec):
        return f"At {_pad(hour)}:{_pad(min_)}:{_pad(sec)}"

    parts = []
    parts.append(_field_desc_en(hour, "hour"))
    if min_ != "*" and min_ != "0":
        parts.append(_at_field_en(min_, "minute"))
    if sec != "*" and sec != "0":
        parts.append(_at_field_en(sec, "second"))
    return " ".join(parts)


def _when_desc_en(dom: str, month: str, dow: str) -> str:
    parts = []
    if dow != "*":
        parts.append(f"on {_weekday_desc_en(dow)}")
    if dom != "*":
        parts.append(f"on day {_list_desc(dom)} of the month")
    if month != "*":
        parts.append(f"in {_month_desc_en(month)}")
    return " ".join(parts)


def _field_desc_en(field: str, unit: str) -> str:
    if field == "*":
        return f"every {unit}"
    if field.startswith("*/"):
        n = field[2:]
        return f"every {n} {unit}s" if n != "1" else f"every {unit}"
    if "-" in field and "/" in field:
        range_part, step = field.split("/")
        start, end = range_part.split("-")
        return f"every {step} {unit}s from {start} through {end}"
    if "-" in field:
        start, end = field.split("-")
        return f"every {unit} from {start} through {end}"
    if "," in field:
        return f"at {unit} {field}"
    return f"at {unit} {field}"


def _at_field_en(field: str, unit: str) -> str:
    if field == "*":
        return ""
    if field.startswith("*/"):
        return f" every {field[2:]} {unit}s"
    return f" at {unit} {field}"


def _weekday_desc_en(field: str) -> str:
    if "," in field:
        days = [_single_weekday_en(d.strip()) for d in field.split(",")]
        return ", ".join(days)
    if "-" in field:
        start, end = field.split("-")
        return f"{_single_weekday_en(start)} through {_single_weekday_en(end)}"
    return _single_weekday_en(field)


def _single_weekday_en(val: str) -> str:
    try:
        idx = int(val) % 7
        return WEEKDAY_EN[idx]
    except ValueError:
        return val


def _month_desc_en(field: str) -> str:
    if "," in field:
        months = [_single_month_en(m.strip()) for m in field.split(",")]
        return ", ".join(months)
    if "-" in field:
        start, end = field.split("-")
        return f"{_single_month_en(start)} through {_single_month_en(end)}"
    return _single_month_en(field)


def _single_month_en(val: str) -> str:
    try:
        idx = int(val)
        if 1 <= idx <= 12:
            return MONTH_EN[idx]
    except ValueError:
        pass
    return val


# ── Chinese translation ──

def _translate_zh(sec: str, min_: str, hour: str, dom: str, month: str, dow: str) -> str:
    if sec == "*" and min_ == "*" and hour == "*" and dom == "*" and month == "*" and dow == "*":
        return "每秒执行"

    parts: List[str] = []
    when = _when_desc_zh(dom, month, dow)
    if when:
        parts.append(when)
    time_part = _time_desc_zh(sec, min_, hour)
    parts.append(time_part)
    parts.append("执行")
    return "".join(parts)


def _time_desc_zh(sec: str, min_: str, hour: str) -> str:
    if sec == "*" and min_ == "*" and hour == "*":
        return "每秒"
    if min_ == "*" and hour == "*":
        return _field_desc_zh(sec, "秒")
    if hour == "*":
        result = _field_desc_zh(min_, "分钟")
        if sec != "0" and sec != "*":
            result += _at_field_zh(sec, "秒")
        elif sec == "0":
            result += "的第0秒"
        return result

    if _is_specific(hour) and _is_specific(min_) and _is_specific(sec):
        return f"{_pad(hour)}:{_pad(min_)}:{_pad(sec)}"

    parts = []
    parts.append(_field_desc_zh(hour, "小时"))
    if min_ != "*":
        if _is_specific(min_):
            parts.append(f"第{min_}分")
        else:
            parts.append(_field_desc_zh(min_, "分钟"))
    if sec != "*" and sec != "0":
        if _is_specific(sec):
            parts.append(f"第{sec}秒")
        else:
            parts.append(_field_desc_zh(sec, "秒"))
    elif sec == "0":
        parts.append("第0秒")
    return "".join(parts)


def _when_desc_zh(dom: str, month: str, dow: str) -> str:
    parts = []
    if month != "*":
        parts.append(_month_desc_zh(month))
    if dom != "*":
        parts.append(_dom_desc_zh(dom))
    if dow != "*":
        parts.append(_weekday_desc_zh(dow))
    return "".join(parts)


def _field_desc_zh(field: str, unit: str) -> str:
    if field == "*":
        return f"每{unit}"
    if field.startswith("*/"):
        n = field[2:]
        return f"每{n}{unit}"
    if "-" in field and "/" in field:
        range_part, step = field.split("/")
        start, end = range_part.split("-")
        return f"从第{start}到第{end}{unit}, 每{step}{unit}"
    if "-" in field:
        start, end = field.split("-")
        return f"第{start}到第{end}{unit}"
    if "," in field:
        return f"第{field}{unit}"
    return f"第{field}{unit}"


def _at_field_zh(field: str, unit: str) -> str:
    if field == "*":
        return ""
    if field.startswith("*/"):
        return f"每{field[2:]}{unit}"
    return f"第{field}{unit}"


def _weekday_desc_zh(field: str) -> str:
    if "," in field:
        days = [_single_weekday_zh(d.strip()) for d in field.split(",")]
        return "每" + "、".join(days)
    if "-" in field:
        start, end = field.split("-")
        return f"每{_single_weekday_zh(start)}至{_single_weekday_zh(end)}"
    return f"每{_single_weekday_zh(field)}"


def _single_weekday_zh(val: str) -> str:
    try:
        idx = int(val) % 7
        return WEEKDAY_ZH[idx]
    except ValueError:
        return val


def _month_desc_zh(field: str) -> str:
    if "," in field:
        months = [_single_month_zh(m.strip()) for m in field.split(",")]
        return "、".join(months)
    if "-" in field:
        start, end = field.split("-")
        return f"{_single_month_zh(start)}至{_single_month_zh(end)}"
    return _single_month_zh(field)


def _single_month_zh(val: str) -> str:
    try:
        idx = int(val)
        if 1 <= idx <= 12:
            return MONTH_ZH[idx]
    except ValueError:
        pass
    return val


def _dom_desc_zh(field: str) -> str:
    if "," in field:
        return f"每月{field}日"
    if "-" in field:
        start, end = field.split("-")
        return f"每月{start}日至{end}日"
    if field.startswith("*/"):
        return f"每{field[2:]}天"
    return f"每月{field}日"


# ── helpers ──

def _is_specific(field: str) -> bool:
    try:
        int(field)
        return True
    except ValueError:
        return False


def _list_desc(field: str) -> str:
    return field


def _pad(val: str) -> str:
    try:
        return f"{int(val):02d}"
    except ValueError:
        return val
