import copy
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional

from nb_cron.core.job import Job
from nb_cron.stores.base import BaseStore


class MemoryStore(BaseStore):

    def __init__(self):
        self._jobs: Dict[str, Job] = {}
        self._metrics: Dict[str, Dict[str, Any]] = {}
        self._functions: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def add_job(self, job: Job) -> None:
        with self._lock:
            if job.job_id in self._jobs:
                raise ValueError(f"Job '{job.job_id}' already exists")
            self._jobs[job.job_id] = copy.deepcopy(job)

    def update_job(self, job: Job) -> None:
        with self._lock:
            if job.job_id not in self._jobs:
                raise ValueError(f"Job '{job.job_id}' not found")
            self._jobs[job.job_id] = copy.deepcopy(job)

    def remove_job(self, job_id: str) -> None:
        with self._lock:
            self._jobs.pop(job_id, None)
            self._metrics.pop(job_id, None)

    def get_job(self, job_id: str) -> Optional[Job]:
        with self._lock:
            job = self._jobs.get(job_id)
            return copy.deepcopy(job) if job else None

    def get_all_jobs(self) -> List[Job]:
        with self._lock:
            return [copy.deepcopy(j) for j in self._jobs.values()]

    def get_due_jobs(self, now: datetime) -> List[Job]:
        with self._lock:
            result = []
            for job in self._jobs.values():
                if (
                    job.status == "active"
                    and job.next_run_time is not None
                    and job.next_run_time <= now
                ):
                    result.append(copy.deepcopy(job))
            return result

    def update_next_run_time(self, job_id: str, next_run_time: Optional[datetime]) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job:
                job.next_run_time = next_run_time

    def save_metrics(self, job_id: str, metrics: Dict[str, Any]) -> None:
        with self._lock:
            self._metrics[job_id] = copy.deepcopy(metrics)

    def get_metrics(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            m = self._metrics.get(job_id)
            return copy.deepcopy(m) if m else None

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        with self._lock:
            return {k: copy.deepcopy(v) for k, v in self._metrics.items()}

    def register_function(self, func_name: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        with self._lock:
            self._functions[func_name] = metadata or {}

    def get_function_names(self) -> List[str]:
        with self._lock:
            return list(self._functions.keys())
