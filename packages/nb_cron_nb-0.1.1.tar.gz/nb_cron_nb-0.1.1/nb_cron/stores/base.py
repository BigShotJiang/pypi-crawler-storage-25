from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

from nb_cron.core.job import Job


class BaseStore(ABC):

    @abstractmethod
    def add_job(self, job: Job) -> None:
        """Persist a new job. Raises if job_id already exists."""

    @abstractmethod
    def update_job(self, job: Job) -> None:
        """Update an existing job in-place."""

    @abstractmethod
    def remove_job(self, job_id: str) -> None:
        """Remove a job by id."""

    @abstractmethod
    def get_job(self, job_id: str) -> Optional[Job]:
        """Return a single job or None."""

    @abstractmethod
    def get_all_jobs(self) -> List[Job]:
        """Return all jobs."""

    @abstractmethod
    def get_due_jobs(self, now: datetime) -> List[Job]:
        """Return active jobs whose next_run_time <= now."""

    @abstractmethod
    def update_next_run_time(self, job_id: str, next_run_time: Optional[datetime]) -> None:
        """Update only the next_run_time for a job."""

    @abstractmethod
    def save_metrics(self, job_id: str, metrics: Dict[str, Any]) -> None:
        """Persist metrics dict for a job."""

    @abstractmethod
    def get_metrics(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Load metrics dict for a job."""

    @abstractmethod
    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Load metrics for all jobs.  {job_id: metrics_dict}"""

    # ── Function registry (cross-project support) ──

    @abstractmethod
    def register_function(self, func_name: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Persist a registered function name so it's visible across projects."""

    @abstractmethod
    def get_function_names(self) -> List[str]:
        """Return all registered function names."""

    def function_exists(self, func_name: str) -> bool:
        return func_name in self.get_function_names()

    def close(self) -> None:
        """Release resources (optional override)."""

    def job_exists(self, job_id: str) -> bool:
        return self.get_job(job_id) is not None
