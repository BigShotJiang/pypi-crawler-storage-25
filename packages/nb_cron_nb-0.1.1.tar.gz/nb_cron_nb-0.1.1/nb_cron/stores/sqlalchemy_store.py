import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from nb_cron.core.job import Job
from nb_cron.stores.base import BaseStore


class SQLAlchemyStore(BaseStore):

    def __init__(self, url: str = "sqlite:///nb_cron.db", name: str = "nb_cron"):
        try:
            from sqlalchemy import (
                Column, DateTime, Integer, MetaData, String, Table, Text,
                create_engine,
            )
            from sqlalchemy.orm import sessionmaker
        except ImportError:
            raise ImportError(
                "sqlalchemy package is required for SQLAlchemyStore. "
                "Install with: pip install nb_cron_nb[sqlalchemy]"
            )

        self._engine = create_engine(url, pool_pre_ping=True)
        self._Session = sessionmaker(bind=self._engine)
        self._metadata = MetaData()

        self._jobs_table = Table(
            f"nb_cron_{name}_jobs", self._metadata,
            Column("job_id", String(255), primary_key=True),
            Column("data", Text, nullable=False),
            Column("next_run_time", DateTime(timezone=True), index=True, nullable=True),
            Column("status", String(32), default="active", index=True),
        )

        self._metrics_table = Table(
            f"nb_cron_{name}_metrics", self._metadata,
            Column("job_id", String(255), primary_key=True),
            Column("data", Text, nullable=False),
        )

        self._functions_table = Table(
            f"nb_cron_{name}_functions", self._metadata,
            Column("func_name", String(255), primary_key=True),
            Column("data", Text, nullable=False),
        )

        self._metadata.create_all(self._engine)

    def add_job(self, job: Job) -> None:
        session = self._Session()
        try:
            existing = session.execute(
                self._jobs_table.select().where(
                    self._jobs_table.c.job_id == job.job_id
                )
            ).fetchone()
            if existing:
                raise ValueError(f"Job '{job.job_id}' already exists")
            session.execute(
                self._jobs_table.insert().values(
                    job_id=job.job_id,
                    data=json.dumps(job.to_dict()),
                    next_run_time=job.next_run_time,
                    status=job.status,
                )
            )
            session.commit()
        finally:
            session.close()

    def update_job(self, job: Job) -> None:
        session = self._Session()
        try:
            session.execute(
                self._jobs_table.update()
                .where(self._jobs_table.c.job_id == job.job_id)
                .values(
                    data=json.dumps(job.to_dict()),
                    next_run_time=job.next_run_time,
                    status=job.status,
                )
            )
            session.commit()
        finally:
            session.close()

    def remove_job(self, job_id: str) -> None:
        session = self._Session()
        try:
            session.execute(
                self._jobs_table.delete().where(self._jobs_table.c.job_id == job_id)
            )
            session.execute(
                self._metrics_table.delete().where(self._metrics_table.c.job_id == job_id)
            )
            session.commit()
        finally:
            session.close()

    def get_job(self, job_id: str) -> Optional[Job]:
        session = self._Session()
        try:
            row = session.execute(
                self._jobs_table.select().where(self._jobs_table.c.job_id == job_id)
            ).fetchone()
            if row is None:
                return None
            data = json.loads(row.data if hasattr(row, "data") else row[1])
            return Job.from_dict(data)
        finally:
            session.close()

    def get_all_jobs(self) -> List[Job]:
        session = self._Session()
        try:
            rows = session.execute(self._jobs_table.select()).fetchall()
            result = []
            for row in rows:
                data = json.loads(row.data if hasattr(row, "data") else row[1])
                result.append(Job.from_dict(data))
            return result
        finally:
            session.close()

    def get_due_jobs(self, now: datetime) -> List[Job]:
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        session = self._Session()
        try:
            rows = session.execute(
                self._jobs_table.select().where(
                    self._jobs_table.c.status == "active",
                    self._jobs_table.c.next_run_time <= now,
                    self._jobs_table.c.next_run_time.isnot(None),
                )
            ).fetchall()
            result = []
            for row in rows:
                data = json.loads(row.data if hasattr(row, "data") else row[1])
                result.append(Job.from_dict(data))
            return result
        finally:
            session.close()

    def update_next_run_time(self, job_id: str, next_run_time: Optional[datetime]) -> None:
        session = self._Session()
        try:
            row = session.execute(
                self._jobs_table.select().where(self._jobs_table.c.job_id == job_id)
            ).fetchone()
            if row is None:
                return
            data = json.loads(row.data if hasattr(row, "data") else row[1])
            data["next_run_time"] = next_run_time.isoformat() if next_run_time else None
            data["updated_at"] = datetime.now(timezone.utc).isoformat()
            session.execute(
                self._jobs_table.update()
                .where(self._jobs_table.c.job_id == job_id)
                .values(
                    data=json.dumps(data),
                    next_run_time=next_run_time,
                )
            )
            session.commit()
        finally:
            session.close()

    def save_metrics(self, job_id: str, metrics: Dict[str, Any]) -> None:
        session = self._Session()
        try:
            existing = session.execute(
                self._metrics_table.select().where(
                    self._metrics_table.c.job_id == job_id
                )
            ).fetchone()
            payload = json.dumps(metrics, default=str)
            if existing:
                session.execute(
                    self._metrics_table.update()
                    .where(self._metrics_table.c.job_id == job_id)
                    .values(data=payload)
                )
            else:
                session.execute(
                    self._metrics_table.insert().values(job_id=job_id, data=payload)
                )
            session.commit()
        finally:
            session.close()

    def get_metrics(self, job_id: str) -> Optional[Dict[str, Any]]:
        session = self._Session()
        try:
            row = session.execute(
                self._metrics_table.select().where(
                    self._metrics_table.c.job_id == job_id
                )
            ).fetchone()
            if row is None:
                return None
            return json.loads(row.data if hasattr(row, "data") else row[1])
        finally:
            session.close()

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        session = self._Session()
        try:
            rows = session.execute(self._metrics_table.select()).fetchall()
            result = {}
            for row in rows:
                jid = row.job_id if hasattr(row, "job_id") else row[0]
                data = row.data if hasattr(row, "data") else row[1]
                result[jid] = json.loads(data)
            return result
        finally:
            session.close()

    def register_function(self, func_name: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        session = self._Session()
        try:
            existing = session.execute(
                self._functions_table.select().where(
                    self._functions_table.c.func_name == func_name
                )
            ).fetchone()
            payload = json.dumps(metadata or {})
            if existing:
                session.execute(
                    self._functions_table.update()
                    .where(self._functions_table.c.func_name == func_name)
                    .values(data=payload)
                )
            else:
                session.execute(
                    self._functions_table.insert().values(func_name=func_name, data=payload)
                )
            session.commit()
        finally:
            session.close()

    def get_function_names(self) -> List[str]:
        session = self._Session()
        try:
            rows = session.execute(self._functions_table.select()).fetchall()
            return [row.func_name if hasattr(row, "func_name") else row[0] for row in rows]
        finally:
            session.close()

    def close(self) -> None:
        self._engine.dispose()
