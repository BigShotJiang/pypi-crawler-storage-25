from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from nb_cron.core.job import Job
from nb_cron.stores.base import BaseStore


class MongoStore(BaseStore):

    def __init__(self, url: str = "mongodb://localhost:27017", db_name: str = "nb_cron", name: str = "nb_cron"):
        try:
            from pymongo import MongoClient
        except ImportError:
            raise ImportError(
                "pymongo package is required for MongoStore. "
                "Install with: pip install nb_cron_nb[mongo]"
            )
        self._client = MongoClient(url)
        self._db = self._client[db_name]
        self._jobs = self._db[f"nb_cron_{name}_jobs"]
        self._metrics_col = self._db[f"nb_cron_{name}_metrics"]
        self._functions_col = self._db[f"nb_cron_{name}_functions"]
        self._jobs.create_index("job_id", unique=True)
        self._jobs.create_index("next_run_time")
        self._functions_col.create_index("func_name", unique=True)

    def add_job(self, job: Job) -> None:
        doc = job.to_dict()
        doc["_id"] = job.job_id
        if self._jobs.find_one({"job_id": job.job_id}):
            raise ValueError(f"Job '{job.job_id}' already exists")
        self._jobs.insert_one(doc)

    def update_job(self, job: Job) -> None:
        doc = job.to_dict()
        self._jobs.replace_one({"job_id": job.job_id}, doc, upsert=True)

    def remove_job(self, job_id: str) -> None:
        self._jobs.delete_one({"job_id": job_id})
        self._metrics_col.delete_one({"job_id": job_id})

    def get_job(self, job_id: str) -> Optional[Job]:
        doc = self._jobs.find_one({"job_id": job_id})
        if doc is None:
            return None
        doc.pop("_id", None)
        return Job.from_dict(doc)

    def get_all_jobs(self) -> List[Job]:
        result = []
        for doc in self._jobs.find():
            doc.pop("_id", None)
            result.append(Job.from_dict(doc))
        return result

    def get_due_jobs(self, now: datetime) -> List[Job]:
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        query = {
            "status": "active",
            "next_run_time": {"$ne": None, "$lte": now.isoformat()},
        }
        result = []
        for doc in self._jobs.find(query):
            doc.pop("_id", None)
            result.append(Job.from_dict(doc))
        return result

    def update_next_run_time(self, job_id: str, next_run_time: Optional[datetime]) -> None:
        self._jobs.update_one(
            {"job_id": job_id},
            {"$set": {
                "next_run_time": next_run_time.isoformat() if next_run_time else None,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }},
        )

    def save_metrics(self, job_id: str, metrics: Dict[str, Any]) -> None:
        metrics["job_id"] = job_id
        self._metrics_col.replace_one({"job_id": job_id}, metrics, upsert=True)

    def get_metrics(self, job_id: str) -> Optional[Dict[str, Any]]:
        doc = self._metrics_col.find_one({"job_id": job_id})
        if doc is None:
            return None
        doc.pop("_id", None)
        doc.pop("job_id", None)
        return doc

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        result = {}
        for doc in self._metrics_col.find():
            jid = doc.pop("job_id", None)
            doc.pop("_id", None)
            if jid:
                result[jid] = doc
        return result

    def register_function(self, func_name: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        doc = {"func_name": func_name, **(metadata or {})}
        self._functions_col.replace_one({"func_name": func_name}, doc, upsert=True)

    def get_function_names(self) -> List[str]:
        return [doc["func_name"] for doc in self._functions_col.find({}, {"func_name": 1})]

    def close(self) -> None:
        self._client.close()
