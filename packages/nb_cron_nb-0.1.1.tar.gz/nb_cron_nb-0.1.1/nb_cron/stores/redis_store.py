import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from nb_cron.core.job import Job
from nb_cron.stores.base import BaseStore


class RedisStore(BaseStore):

    def __init__(self, url: str = "redis://localhost:6379/0", name: str = "nb_cron"):
        try:
            import redis
        except ImportError:
            raise ImportError(
                "redis package is required for RedisStore. "
                "Install with: pip install nb_cron_nb[redis]"
            )
        self._client = redis.Redis.from_url(url, decode_responses=True)
        self._jobs_key = f"nb_cron:{name}:jobs"
        self._metrics_key = f"nb_cron:{name}:metrics"
        self._due_key = f"nb_cron:{name}:due"
        self._functions_key = f"nb_cron:{name}:functions"

    def add_job(self, job: Job) -> None:
        if self._client.hexists(self._jobs_key, job.job_id):
            raise ValueError(f"Job '{job.job_id}' already exists")
        pipe = self._client.pipeline()
        pipe.hset(self._jobs_key, job.job_id, json.dumps(job.to_dict()))
        if job.next_run_time and job.status == "active":
            score = job.next_run_time.timestamp()
            pipe.zadd(self._due_key, {job.job_id: score})
        pipe.execute()

    def update_job(self, job: Job) -> None:
        pipe = self._client.pipeline()
        pipe.hset(self._jobs_key, job.job_id, json.dumps(job.to_dict()))
        pipe.zrem(self._due_key, job.job_id)
        if job.next_run_time and job.status == "active":
            score = job.next_run_time.timestamp()
            pipe.zadd(self._due_key, {job.job_id: score})
        pipe.execute()

    def remove_job(self, job_id: str) -> None:
        pipe = self._client.pipeline()
        pipe.hdel(self._jobs_key, job_id)
        pipe.hdel(self._metrics_key, job_id)
        pipe.zrem(self._due_key, job_id)
        pipe.execute()

    def get_job(self, job_id: str) -> Optional[Job]:
        raw = self._client.hget(self._jobs_key, job_id)
        if raw is None:
            return None
        return Job.from_dict(json.loads(raw))

    def get_all_jobs(self) -> List[Job]:
        raw_map = self._client.hgetall(self._jobs_key)
        return [Job.from_dict(json.loads(v)) for v in raw_map.values()]

    def get_due_jobs(self, now: datetime) -> List[Job]:
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        score = now.timestamp()
        job_ids = self._client.zrangebyscore(self._due_key, "-inf", score)
        jobs = []
        for jid in job_ids:
            job = self.get_job(jid)
            if job and job.status == "active":
                jobs.append(job)
        return jobs

    def update_next_run_time(self, job_id: str, next_run_time: Optional[datetime]) -> None:
        raw = self._client.hget(self._jobs_key, job_id)
        if raw is None:
            return
        data = json.loads(raw)
        data["next_run_time"] = next_run_time.isoformat() if next_run_time else None
        data["updated_at"] = datetime.now(timezone.utc).isoformat()

        pipe = self._client.pipeline()
        pipe.hset(self._jobs_key, job_id, json.dumps(data))
        pipe.zrem(self._due_key, job_id)
        if next_run_time:
            pipe.zadd(self._due_key, {job_id: next_run_time.timestamp()})
        pipe.execute()

    def save_metrics(self, job_id: str, metrics: Dict[str, Any]) -> None:
        self._client.hset(self._metrics_key, job_id, json.dumps(metrics, default=str))

    def get_metrics(self, job_id: str) -> Optional[Dict[str, Any]]:
        raw = self._client.hget(self._metrics_key, job_id)
        if raw is None:
            return None
        return json.loads(raw)

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        raw_map = self._client.hgetall(self._metrics_key)
        return {k: json.loads(v) for k, v in raw_map.items()}

    def register_function(self, func_name: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        self._client.hset(self._functions_key, func_name, json.dumps(metadata or {}))

    def get_function_names(self) -> List[str]:
        return list(self._client.hkeys(self._functions_key))

    def close(self) -> None:
        self._client.close()
