import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from nb_cron.stores.base import BaseStore
from nb_cron.utils import truncate_string

MAX_RECENT_RESULTS = 10
HOURLY_SLOTS = 24


def _empty_metrics() -> Dict[str, Any]:
    return {
        "total_runs": 0,
        "success_count": 0,
        "fail_count": 0,
        "last_run_at": None,
        "last_success_at": None,
        "last_error": None,
        "last_error_at": None,
        "avg_duration_ms": 0.0,
        "max_duration_ms": 0.0,
        "min_duration_ms": 0.0,
        "last_duration_ms": 0.0,
        "recent_results": [],
        "hourly_stats": [{"hour": i, "success": 0, "fail": 0} for i in range(HOURLY_SLOTS)],
    }


class MetricsCollector:

    def __init__(self, store: BaseStore):
        self._store = store
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def record(
        self,
        job_id: str,
        success: bool,
        duration_ms: float,
        error: Optional[str] = None,
    ) -> None:
        now = datetime.now(timezone.utc)
        with self._lock:
            m = self._cache.get(job_id)
            if m is None:
                stored = self._store.get_metrics(job_id)
                m = stored if stored else _empty_metrics()
                self._cache[job_id] = m

            m["total_runs"] += 1
            m["last_run_at"] = now.isoformat()
            m["last_duration_ms"] = round(duration_ms, 2)

            if success:
                m["success_count"] += 1
                m["last_success_at"] = now.isoformat()
            else:
                m["fail_count"] += 1
                m["last_error"] = truncate_string(error or "Unknown error")
                m["last_error_at"] = now.isoformat()

            total = m["total_runs"]
            prev_avg = m["avg_duration_ms"]
            m["avg_duration_ms"] = round(prev_avg + (duration_ms - prev_avg) / total, 2)
            m["max_duration_ms"] = round(max(m["max_duration_ms"], duration_ms), 2)
            if m["min_duration_ms"] == 0:
                m["min_duration_ms"] = round(duration_ms, 2)
            else:
                m["min_duration_ms"] = round(min(m["min_duration_ms"], duration_ms), 2)

            recent: list = m.get("recent_results", [])
            recent.append({
                "time": now.isoformat(),
                "success": success,
                "duration_ms": round(duration_ms, 2),
                "error": truncate_string(error) if error else None,
            })
            if len(recent) > MAX_RECENT_RESULTS:
                recent[:] = recent[-MAX_RECENT_RESULTS:]
            m["recent_results"] = recent

            hour_idx = now.hour % HOURLY_SLOTS
            hourly: list = m.get("hourly_stats", [])
            if len(hourly) < HOURLY_SLOTS:
                hourly = [{"hour": i, "success": 0, "fail": 0} for i in range(HOURLY_SLOTS)]
                m["hourly_stats"] = hourly
            if success:
                hourly[hour_idx]["success"] += 1
            else:
                hourly[hour_idx]["fail"] += 1

            self._store.save_metrics(job_id, m)

    def get_metrics(self, job_id: str) -> Dict[str, Any]:
        with self._lock:
            cached = self._cache.get(job_id)
            if cached:
                return dict(cached)
        stored = self._store.get_metrics(job_id)
        return stored if stored else _empty_metrics()

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        stored = self._store.get_all_metrics()
        with self._lock:
            for jid, m in self._cache.items():
                stored[jid] = dict(m)
        return stored

    def get_dashboard_stats(self) -> Dict[str, Any]:
        all_m = self.get_all_metrics()
        total_runs = 0
        total_success = 0
        total_fail = 0
        job_count = len(all_m)
        for m in all_m.values():
            total_runs += m.get("total_runs", 0)
            total_success += m.get("success_count", 0)
            total_fail += m.get("fail_count", 0)

        hourly_agg = [{"hour": i, "success": 0, "fail": 0} for i in range(HOURLY_SLOTS)]
        for m in all_m.values():
            for slot in m.get("hourly_stats", []):
                idx = slot["hour"] % HOURLY_SLOTS
                hourly_agg[idx]["success"] += slot.get("success", 0)
                hourly_agg[idx]["fail"] += slot.get("fail", 0)

        return {
            "job_count": job_count,
            "total_runs": total_runs,
            "total_success": total_success,
            "total_fail": total_fail,
            "success_rate": round(total_success / total_runs * 100, 1) if total_runs else 0,
            "hourly_stats": hourly_agg,
        }
